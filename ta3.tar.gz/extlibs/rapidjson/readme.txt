git clone https://github.com/Tencent/rapidjson

git log -n1
commit 973dc9c06dcd3d035ebd039cfb9ea457721ec213 (HEAD -> master, origin/master, origin/HEAD)
Author: Leonard Chan <leonardchan@google.com>
Date:   Tue May 9 21:31:22 2023 +0000
#include "httpglobal.h"

const char* getQtWebAppLibVersion()
{
    return "1.6.4";
}


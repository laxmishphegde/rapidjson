#ifndef QT_NO_OPENSSL
    #include <QSslSocket>
    #include <QSslKey>
    #include <QSslCertificate>
    #include <QSslConfiguration>
#endif
#include <QDir>
#include "httpconnectionhandlerpool.h"

HttpConnectionHandlerPool::HttpConnectionHandlerPool(QSettings* settings, HttpRequestHandler* requestHandler)
    : QObject()
{
    Q_ASSERT(settings!=0);
    this->settings=settings;
    this->requestHandler=requestHandler;
    this->sslConfiguration=NULL;
    loadSslConfig();
    cleanupTimer.start(settings->value("cleanupInterval",1000).toInt());
    connect(&cleanupTimer, SIGNAL(timeout()), SLOT(cleanup()));
}


HttpConnectionHandlerPool::~HttpConnectionHandlerPool()
{
    // delete all connection handlers and wait until their threads are closed
    foreach(HttpConnectionHandler* handler, pool)
    {
       delete handler;
    }
    delete sslConfiguration;
    qDebug("HttpConnectionHandlerPool (%p): destroyed", this);
}


HttpConnectionHandler* HttpConnectionHandlerPool::getConnectionHandler()
{
    HttpConnectionHandler* freeHandler=0;
    mutex.lock();
    // find a free handler in pool
    foreach(HttpConnectionHandler* handler, pool)
    {
        if (!handler->isBusy())
        {
            freeHandler=handler;
            freeHandler->setBusy();
            break;
        }
    }
    // create a new handler, if necessary
    if (!freeHandler)
    {
        int maxConnectionHandlers=settings->value("maxThreads",100).toInt();
        if (pool.count()<maxConnectionHandlers)
        {
            freeHandler=new HttpConnectionHandler(settings,requestHandler,sslConfiguration);
            freeHandler->setBusy();
            pool.append(freeHandler);
        }
    }
    mutex.unlock();
    return freeHandler;
}


void HttpConnectionHandlerPool::cleanup()
{
    int maxIdleHandlers=settings->value("minThreads",1).toInt();
    int idleCounter=0;
    mutex.lock();
    foreach(HttpConnectionHandler* handler, pool)
    {
        if (!handler->isBusy())
        {
            if (++idleCounter > maxIdleHandlers)
            {
                delete handler;
                pool.removeOne(handler);
                qDebug("HttpConnectionHandlerPool: Removed connection handler (%p), pool size is now %i",handler,pool.size());
                break; // remove only one handler in each interval
            }
        }
    }
    mutex.unlock();
}
// This function converts string to QSsl enum
QSsl::SslProtocol getSslProtocolEnFromStr(QString& sslProtocolVersion)
{
    QSsl::SslProtocol  retSslProtocol = QSsl::UnknownProtocol;
#if (QT_VERSION >= QT_VERSION_CHECK(5, 12, 0)) 
#if QT_DEPRECATED_SINCE(5, 15)
    if (sslProtocolVersion.compare("SslV3") == 0)
        retSslProtocol = QSsl::SslV3;
    else if (sslProtocolVersion.compare("SslV2") == 0)
        retSslProtocol = QSsl::SslV2;
    else if (sslProtocolVersion.compare("TlsV1SslV3") == 0)
        retSslProtocol = QSsl::TlsV1SslV3;
#endif

#if QT_DEPRECATED_SINCE(5,0)
    if (sslProtocolVersion.compare("TlsV1") == 0)
        retSslProtocol = QSsl::TlsV1;
#else
    if (sslProtocolVersion.compare("TlsV1_0") == 0)
        retSslProtocol = QSsl::TlsV1_0;
    else if (sslProtocolVersion.compare("TlsV1_1") == 0)
        retSslProtocol = QSsl::TlsV1_1;
    else if (sslProtocolVersion.compare("TlsV1_2") == 0)
        retSslProtocol = QSsl::TlsV1_2;
    else if (sslProtocolVersion.compare("AnyProtocol") == 0)
        retSslProtocol = QSsl::AnyProtocol;
    else if (sslProtocolVersion.compare("SecureProtocols") == 0)
        retSslProtocol = QSsl::SecureProtocols;
    else if (sslProtocolVersion.compare("TlsV1_0OrLater") == 0)
        retSslProtocol = QSsl::TlsV1_0OrLater;
    else if (sslProtocolVersion.compare("TlsV1_1OrLater") == 0)
        retSslProtocol = QSsl::TlsV1_1OrLater;
    else if (sslProtocolVersion.compare("TlsV1_2OrLater") == 0)
        retSslProtocol = QSsl::TlsV1_2OrLater;
    else if (sslProtocolVersion.compare("DtlsV1_0") == 0)
        retSslProtocol = QSsl::DtlsV1_0;
    else if (sslProtocolVersion.compare("DtlsV1_0OrLater") == 0)
        retSslProtocol = QSsl::DtlsV1_0OrLater;
    else if (sslProtocolVersion.compare("DtlsV1_2") == 0)
        retSslProtocol = QSsl::DtlsV1_2;
    else if (sslProtocolVersion.compare("DtlsV1_2OrLater") == 0)
        retSslProtocol = QSsl::DtlsV1_2OrLater;
    else if (sslProtocolVersion.compare("TlsV1_3") == 0)
        retSslProtocol = QSsl::TlsV1_3;
    else if (sslProtocolVersion.compare("TlsV1_3OrLater") == 0)
        retSslProtocol = QSsl::TlsV1_3OrLater;
#endif
#else
    retSslProtocol = QSsl::TlsV1SslV3;
#endif
    return retSslProtocol;

}
void HttpConnectionHandlerPool::loadSslConfig()
{
    // If certificate and key files are configured, then load them
    QString sslKeyFileName=settings->value("sslKeyFile","").toString();
    QString sslCertFileName=settings->value("sslCertFile","").toString();
    QString sslProtocolVersion =settings->value("sslProtocolVersion","").toString(); /* PMSTA-47921 Sudeep 29092022*/
    if (!sslKeyFileName.isEmpty() && !sslCertFileName.isEmpty())
    {
        #ifdef QT_NO_OPENSSL
            qWarning("HttpConnectionHandlerPool: SSL is not supported");
        #else
            // Convert relative fileNames to absolute, based on the directory of the config file.
            QFileInfo configFile(settings->fileName());
            #ifdef Q_OS_WIN32
                if (QDir::isRelativePath(sslKeyFileName) && settings->format()!=QSettings::NativeFormat)
            #else
                if (QDir::isRelativePath(sslKeyFileName))
            #endif
            {
                sslKeyFileName=QFileInfo(configFile.absolutePath(),sslKeyFileName).absoluteFilePath();
            }
            #ifdef Q_OS_WIN32
                if (QDir::isRelativePath(sslCertFileName) && settings->format()!=QSettings::NativeFormat)
            #else
                if (QDir::isRelativePath(sslCertFileName))
            #endif
            {
                sslCertFileName=QFileInfo(configFile.absolutePath(),sslCertFileName).absoluteFilePath();
            }

            // Load the SSL certificate
            QFile certFile(sslCertFileName);
            if (!certFile.open(QIODevice::ReadOnly))
            {
                qCritical("HttpConnectionHandlerPool: cannot open sslCertFile %s", qPrintable(sslCertFileName));
                return;
            }
            QSslCertificate certificate(&certFile, QSsl::Pem);
            certFile.close();

            // Load the key file
            QFile keyFile(sslKeyFileName);
            if (!keyFile.open(QIODevice::ReadOnly))
            {
                qCritical("HttpConnectionHandlerPool: cannot open sslKeyFile %s", qPrintable(sslKeyFileName));
                return;
            }
			QString keyPassword = settings->value("sslKeypassword", "").toString();
			QSslKey sslKey;
			if (keyPassword.isEmpty())
			{
				QSslKey key(&keyFile, QSsl::Rsa, QSsl::Pem);
				sslKey = key;
			}
			else
			{
				QByteArray pass = keyPassword.toUtf8();
				QSslKey key(&keyFile, QSsl::Rsa, QSsl::Pem, QSsl::PrivateKey, pass);
				sslKey = key;
			}
            keyFile.close();

            // Create the SSL configuration
            sslConfiguration=new QSslConfiguration();

			//Load trustStore
			QString trustStoreFileName = settings->value("trustStoreFile", "").toString();
			if (!trustStoreFileName.isEmpty())
			{
#ifdef Q_OS_WIN32
				if (QDir::isRelativePath(trustStoreFileName) && settings->format() != QSettings::NativeFormat)
#else
				if (QDir::isRelativePath(trustStoreFileName))
#endif
				{
					trustStoreFileName = QFileInfo(configFile.absolutePath(), trustStoreFileName).absoluteFilePath();
				}

				QFile trustStoreFile(trustStoreFileName);
				if (!trustStoreFile.open(QIODevice::ReadOnly))
				{
					qCritical("HttpConnectionHandlerPool: cannot open trustStoreFile %s", qPrintable(trustStoreFileName));
					return;
				}
				trustStoreFile.close();

				/** Qt versions compatibility to add the certifiactes to socket's CA certificate Database. 
				**  QSslConfiguration::addCaCertificates function added in QT 5.15,
				**  for any lower QT version use QSslConfiguration::setCaCertificates function
				**/
#if (QT_VERSION >= QT_VERSION_CHECK(5, 15, 0))
				if(sslConfiguration->addCaCertificates(trustStoreFileName, QSsl::Pem, QSslCertificate::PatternSyntax::FixedString))
				{
					qDebug("certificates added to socket's CA certificate Database");
				}
				else
				{
					qDebug("Certificates not added to socket's CA certificate Database");
				}
#else
				QList<QSslCertificate> certs = QSslCertificate::fromPath(trustStoreFileName);
				sslConfiguration->setCaCertificates(certs);
#endif
				sslConfiguration->setPeerVerifyMode(QSslSocket::VerifyPeer);
			}
			else {
				sslConfiguration->setPeerVerifyMode(QSslSocket::VerifyNone);
			}

            sslConfiguration->setLocalCertificate(certificate);
            sslConfiguration->setPrivateKey(sslKey);

            QSsl::SslProtocol sslProtocol = getSslProtocolEnFromStr(sslProtocolVersion); /* PMSTA-47921 Sudeep 29092022 */
            sslConfiguration->setProtocol(sslProtocol); 

            qDebug("HttpConnectionHandlerPool: SSL settings loaded");
         #endif
    }
}

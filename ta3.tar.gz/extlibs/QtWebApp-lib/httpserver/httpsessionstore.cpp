/**
  @file
  @author Stefan Frings
*/

#include "httpsessionstore.h"
#include <QDateTime>
#include <QUuid>

extern QByteArray getRequestHeader(const HttpRequest& request, const QByteArray& hKey);

HttpSessionStore::HttpSessionStore(QSettings* settings, QObject* parent)
    :QObject(parent)
{
    cookieName=settings->value("cookieName","sessionid").toByteArray();
    expirationTime=settings->value("expirationTime",3600000).toInt();

    cookiePath = settings->value("cookiePath").toByteArray();
    cookieComment = settings->value("cookieComment").toByteArray();
    cookieDomain = settings->value("cookieDomain").toByteArray();
    
    if (expirationTime > 0)
    {
        connect(&cleanupTimer, SIGNAL(timeout()), this, SLOT(sessionTimerEvent()));
        cleanupTimer.start(60000);
    }
    else
    {
        qCritical("HttpSessionStore: Sessions never expire");
    }
    if (expirationTime <= 60000)
    {
        qCritical("HttpSessionStore: Sessions expire after %i milliseconds value too small, please review you settings", expirationTime);
    }
    qDebug("HttpSessionStore: Sessions expire after %i milliseconds, check every 1 min",expirationTime);
}

HttpSessionStore::~HttpSessionStore()
{
    cleanupTimer.stop();
}

QByteArray HttpSessionStore::getSessionId(HttpRequest& request, HttpResponse& response)
{
    // The session ID in the response has priority because this one will be used in the next request.
    mutex.lock();
    // Get the session ID from the response cookie
    QByteArray sessionId;

    /* Temporary workaround till stateless solution is implemented
     * For OAuth request, take session from response but not from request
     * even if there is not session cookie in the response.
     * Because the session in the response would have been set in the current processing, 
     * but in the request it might be a session of a previous basic auth response.
     */
	sessionId = response.getCookies().value(cookieName).getValue();
	const QByteArray authorizationHeader = getRequestHeader(request, "Authorization");
    /* take session from request cookie only for non bearer token request */
	if (authorizationHeader.isEmpty() == false && !authorizationHeader.startsWith("Bearer "))
	{
		if (sessionId.isEmpty())
		{
			// Get the session ID from the request cookie
			sessionId = request.getCookie(cookieName);
		}
	}

    // Clear the session ID if there is no such session in the storage.
    if (!sessionId.isEmpty())
    {
        if (!sessions.contains(sessionId))
        {
            qDebug("HttpSessionStore: received invalid session cookie with ID %s",sessionId.data());
            sessionId.clear();
        }
    }
    mutex.unlock();
    return sessionId;
}

HttpSession HttpSessionStore::getSession(HttpRequest& request, HttpResponse& response, bool allowCreate)
{
    QByteArray sessionId=getSessionId(request,response);
    mutex.lock();
    if (!sessionId.isEmpty())
    {
        HttpSession session=sessions.value(sessionId);
        if (!session.isNull())
        {
            mutex.unlock();
            // Refresh the session cookie // FME PMSTA-24869  do not refresh the session cookie as not required but only the session
            // response.setCookie(HttpCookie(cookieName,session.getId(),expirationTime/1000,cookiePath,cookieComment,cookieDomain));
            session.setLastAccess();
            return session;
        }
    }
    // Need to create a new session
    if (allowCreate)
    {
        HttpSession session(true);
        qDebug("HttpSessionStore: create new session with ID %s",session.getId().data());
        sessions.insert(session.getId(),session);
        response.setCookie(HttpCookie(cookieName,session.getId(),expirationTime/1000,cookiePath,cookieComment,cookieDomain));
        mutex.unlock();
        return session;
    }
    // Return a null session
    mutex.unlock();
    return HttpSession();
}

HttpSession HttpSessionStore::getSession(const QByteArray id)
{
    mutex.lock();
    HttpSession session=sessions.value(id);
    mutex.unlock();
    session.setLastAccess();
    return session;
}

void HttpSessionStore::sessionTimerEvent()
{
    mutex.lock();
    qint64 now=QDateTime::currentMSecsSinceEpoch();
    QMap<QByteArray,HttpSession>::iterator i = sessions.begin();
    while (i != sessions.end())
    {
        QMap<QByteArray,HttpSession>::iterator prev = i;
        ++i;
        HttpSession session=prev.value();
        qint64 lastAccess=session.getLastAccess();
        if (now-lastAccess>expirationTime)
        {
            qDebug("HttpSessionStore: session %s expired",session.getId().data());
            sessions.erase(prev);
        }
    }
    mutex.unlock();
}


/** Delete a session */
void HttpSessionStore::removeSession(HttpSession session)
{
    mutex.lock();
    sessions.remove(session.getId());
    mutex.unlock();
}

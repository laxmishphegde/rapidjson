/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**
**                     Copyright (C) 1993-1994 by UNICIBLE
**                             All Rights Reserved
**
**                          Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define AUDITLIB_C

/************************************************************************
**      Includes
*************************************************************************/
#define  STDIO_H
#define  CTYPE_H
#define  ERRNO_H
#define STDLIB_H
#define UNISTD_H
#define STRING_H
#define SIGNAL_H

#include <unidef.h>	/* Mandatory */

#include    <dba.h>
#include    <scptyl.h>
#include    <syslib.h>
#include    <date.h>
#include    <gen.h>
#include    <audit.h>
#include    <merclib.h>

/************************************************************************
**      Constants
*************************************************************************/
#define RECORDS_AT_ONCE 10
/************************************************************************
**      Macros Definitions
*************************************************************************/

/************************************************************************
**      Types  Definitions
*************************************************************************/

/************************************************************************
**      Global Functions
**
**  AUDIT_Proceed()
**  AUDIT_Halt()
**
*************************************************************************/

/************************************************************************
**      Static Functions
**
**
**
**
*************************************************************************/

/************************************************************************
**      Static Data Definitions
*************************************************************************/

/************************************************************************
**      Global Data Definitions
*************************************************************************/

extern SCPT_GENCONTEXTSUB_STP * genContextTab;
extern int                      genContextTabNb;

extern SCPT_GENCONTEXTSUB_STP * genContextBusEntityTab;     /* PMSTA-17089 - DDV - 131205 */
extern int                      genContextBusEntityTabNb;   /* PMSTA-17089 - DDV - 131205 */

extern AUDITFILTER_ST EV_AuditFilter;

/************************************************************************
**      Static Function Definitions
*************************************************************************/

/************************************************************************
**      Declarations
*************************************************************************/

extern char     *ResolveMap(char *, std::string);
extern int		ParseEntityData(const char *, char *, char ** , int);
extern int		Run_Map(char *, char *);
RET_CODE AUDIT_SendAllToMercator(DBA_DYNFLD_STP *, int, std::string);
/************************************************************************
**
**  Function    :   AUDIT_BuildSqlString()
**
**  Description :
**
**  Argument    :
**
*************************************************************************/
RET_CODE AUDIT_BuildSqlString(char *buffer, int len)
{
   char tmpText[256];

   sprintf(buffer , "select * from %s where map_id is not null and map_id > 0 ", SCPT_GetViewName(Audit, false).c_str()); /* PMSTA-26250  -DDV - 170523 */  /* PMSTA-32753 - DLA - 180903 */

   if(EV_AuditFilter.User[0])
   {
      sprintf(tmpText, "and user_c = '%s' ", EV_AuditFilter.User);
      strcat(buffer, tmpText);
   }

   if(EV_AuditFilter.Entity >= 0)
   {
      sprintf(tmpText, "and entity_dict_id = %" szFormatId" ", EV_AuditFilter.Entity);   /* DLA - PMSTA08801 - 100519 */
      strcat(buffer, tmpText);
   }

   if(EV_AuditFilter.Action >= 0)
   {
      sprintf(tmpText, "and action_e = %d ", EV_AuditFilter.Action);
      strcat(buffer, tmpText);
   }

   if(EV_AuditFilter.Module >= 0)
   {
      sprintf(tmpText, "and module_e = %d ", EV_AuditFilter.Module);
      strcat(buffer, tmpText);
   }

   if(EV_AuditFilter.BegDate[0])
   {
      sprintf(tmpText, "and creation_d >= %s ", EV_AuditFilter.BegDate);		/* PMSTA-18583 - TEB - 160321 */
      strcat(buffer, tmpText);
   }

   if(EV_AuditFilter.EndDate[0])
   {
	   sprintf(tmpText, "and creation_d <= %s ", EV_AuditFilter.EndDate);		/* PMSTA-18583 - TEB - 160321 */
      strcat(buffer, tmpText);
   }

   sprintf(tmpText, " order by creation_d ");
   strcat(buffer, tmpText);

   return AUDIT_SUCCEED;
}



/************************************************************************
**
**  Function    :   AUDIT_Proceed()
**
**  Description :
**
**  Argument    :
**
*************************************************************************/
RET_CODE AUDIT_Proceed()
{

   DBA_DYNFLD_STP *outAudit;
   int outAuditNbr;
   DBA_DYNFLD_STP bindSt = NULLDYNST;
   DbiConnection* dbiConn = nullptr;
   char sqlBuffer[1024];
   int status;
   int retCode;

   /* Get audit records */

   outAuditNbr = 0;
   if (EV_RdbmsVendor == Sybase)
   {
       if (DBA_SqlExec("set dateformat dmy", UNUSED, UNUSED) != RET_SUCCEED)
           return FALSE;
   }

   if ((dbiConn = DBA_GetDbiConnection(SqlServer)) == nullptr)
   {
      MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "Unable to get a connection");
      return FALSE;
   }


   AUDIT_BuildSqlString(sqlBuffer, 1024);

   if (dbiConn->sendCommand(sqlBuffer) != RET_SUCCEED)
	{
        DBA_EndConnection(&dbiConn);
        MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "Unable to send database command");
		return(RET_MEM_ERR_ALLOC);
	}

	/* Allocate memory for the bind structure */
	if ((bindSt = ALLOC_DYNST(A_Audit)) == NULL)
	{
        dbiConn->processAllResults(&status);
        DBA_EndConnection(&dbiConn);
		return(RET_MEM_ERR_ALLOC);
	}

	/* Bind result columns with an application bind structure */
    if (dbiConn->bindRecvDynSt(A_Audit, bindSt) != RET_SUCCEED)
	{
		FREE_DYNST(bindSt, A_Audit);
		dbiConn->cancelDbRequest(COMMAND_LEVEL, CANCEL_ALL);
        dbiConn->cancelDbRequest(COMMAND_LEVEL, CANCEL_ALL);
        DBA_EndConnection(&dbiConn);
        MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "Unable to bind columns");
		return(RET_DBA_ERR_SYBBIND);
	}

	/* Retrieve all rows in the result set */
    if ((retCode = dbiConn->readObjectData(A_Audit, bindSt, &outAuditNbr, &outAudit)) != RET_SUCCEED)
	{
		FREE_DYNST(bindSt, A_Audit);
        dbiConn->processAllResults(&status);
        DBA_EndConnection(&dbiConn);
        MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "Unable to read data");
		return(RET_DBA_ERR_DBPROBLEM);
	}

	FREE_DYNST(bindSt, A_Audit);
    dbiConn->processAllResults(&status);
    DBA_EndConnection(&dbiConn);

   if(outAuditNbr == 0)
   {
      DBA_FreeDynStTab(outAudit, outAuditNbr, A_Audit);
      MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "No audit records found");
      return AUDIT_SUCCEED;
   }

    std::string map_path;    
    GEN_GetApplInfo(ApplSubscriptionFilePath, map_path); /* PMSTA-48941 - JBC - 220423 */;
   /* call Mercator for all those events */

   if(AUDIT_SendAllToMercator(outAudit, outAuditNbr,map_path) != RET_SUCCEED)
   {
         DBA_FreeDynStTab(outAudit, outAuditNbr, A_Audit);
         MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "Call to mercator failed");
         return AUDIT_ERROR;
   }

   DBA_FreeDynStTab(outAudit, outAuditNbr, A_Audit);

   return AUDIT_SUCCEED;
}

/************************************************************************
**
**  Function    :   AUDIT_SendAllToMercator()
**
**  Description :   send many audit records to Mercator
**
**  Argument    :
**
*************************************************************************/
RET_CODE AUDIT_SendAllToMercator(DBA_DYNFLD_STP *auditList, int auditNbr, std::string map_path)
{

    int                  auditFlag = 1;
    int					   i = 0;
    size_t				   bufLen = 0;
    size_t     	    	   data_size = 0;
    size_t				   field_size = 0;
    int					   map_return = 0;
    char				      name[40];
    char				      *data_Buff = (char *)NULL;
    char				      *map_name = NULL;
    char		            *map_storage = NULL;
    char				      *single_Buff = NULL;
    char				      *Data = NULL;
    const char			  *Entity_name = NULL;
    int					   entity_nature;
    int					   action;
    char				      *hostname;
    ID_T				      function_id;
    char				      *user = NULL;
    char				      *map_code = NULL;
    int					   module;
    OBJECT_ENUM   		   Entity_id;
    ID_T				      Dict_Entity_id;
    char				      *Big_Buff = NULL;
    char				      field_buffer[512];
    DATETIME_T			   creation;
    DATE_FORMAT_ST		   format;
    HOUR_T				   hour;
    MINUTE_T			      minute;
    SECOND_T			      second;
    DBA_DYNFLD_STP		   aMap = NULLDYNST;
    ID_T				      mapId;
    ID_T				      tmpMapId;
    char                 strBuf[1024];
    int                  begin = 0, end = 1;
    int                  recCount = 0;
	int             applNoOfBatchStreamRec = 0;    /*PMSTA-41530-VSW-21082020*/
    int             noOfBatchStreamRec = RECORDS_AT_ONCE;

    GEN_GetApplInfo(ApplNoOfBatchStreamRec, &applNoOfBatchStreamRec);    /*PMSTA-41530-VSW-21082020*/

    if (applNoOfBatchStreamRec >= 0)
    {
       noOfBatchStreamRec = applNoOfBatchStreamRec;
    }

    if ((aMap = ALLOC_DYNST(A_Map)) == NULLDYNST)
    {
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
        return AUDIT_ERROR;
    }

    while (begin < auditNbr)
    {
        mapId = GET_ID(auditList[begin], A_Audit_MapId);

        while ((end < auditNbr) && ((tmpMapId = GET_ID(auditList[end], A_Audit_MapId)) == mapId))
            end++;

        /* Get the map code */
        SET_ID(aMap, A_Map_Id, mapId);

        if (DBA_Get2(Map, UNUSED, A_Map, aMap, A_Map, &aMap,
                     UNUSED,
                     UNUSED) != RET_SUCCEED)
        {
            sprintf(strBuf, "Cannot load map with id %" szFormatId, mapId);   /* DLA - PMSTA08801 - 100519 */
            MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, strBuf);
            begin = end;
            continue;
        }
        map_name = GET_NOTE(aMap, A_Map_Storage);
        if (map_name == NULL)
        {
            sprintf(strBuf, "Cannot retrieve map name ( map_id = %" szFormatId" )", mapId);   /* DLA - PMSTA08801 - 100519 */
            MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, strBuf);
            begin = end;
            continue;
        }
        map_storage = ResolveMap(map_name, map_path);
        if (!map_storage)
        {
            sprintf(strBuf, "Unable to resolve Environment variable in map path.");
            MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, strBuf);
            return AUDIT_ERROR;
        }
        map_code = GET_CODE(aMap, S_Map_Code);
        if (map_code == NULL)
        {
            sprintf(strBuf, "Cannot retrieve map code ( map_id = %" szFormatId" )", mapId);   /* DLA - PMSTA08801 - 100519 */
            MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, strBuf);
            begin = end;
            continue;
        }

        for (i = begin; i < end; i++)
        {

            Data = GET_TEXT(auditList[i], A_Audit_Data);
            if (!Data[0])
            {
                MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "Empty data field");
                continue;
            }
            Dict_Entity_id = GET_ID(auditList[i], A_Audit_EntityDictId);

            /* Now get entity name from the dictId */
            DBA_GetObjectEnum(Dict_Entity_id, &Entity_id);

            Entity_name   = DBA_GetDictEntitySqlName(Entity_id);
            action        = (int)GET_ENUM(auditList[i], A_Audit_ActionEn);
            creation      = GET_DATETIME(auditList[i], A_Audit_CreationDate);
            entity_nature = (int)GET_ENUM(auditList[i], A_Audit_EntityNatEn);
            function_id   = GET_ID(auditList[i], A_Audit_FctDictId);
            hostname      = GET_SYSNAME(auditList[i], A_Audit_Hostname);
            module        = (int)GET_ENUM(auditList[i], A_Audit_ModuleEn);
            user          = GET_SYSNAME(auditList[i], A_Audit_User);	/* DLA - PMSTA09887 - 101115 */

            format.ordre = Dmy;
            strcpy(format.yearSep, "/");
            strcpy(format.monthSep, "/");
            strcpy(format.daySep, "/");
            format.yearFormat = 1;
            format.monthFormat = 0;

            DATE_FormatToStr(name, creation.date, &format);

            TIME_Get(creation.time, &hour, &minute, &second);

            single_Buff = NULL;
            sprintf(field_buffer, "%d%c%s %d:%d:%d%c%s%c%d%c%" szFormatId"%c%s%c%s%c%d%c%s%c",   /* DLA - PMSTA08801 - 100519 */
                    action, RS_SEP, name, hour, minute, second, RS_SEP, Entity_name, RS_SEP, entity_nature, RS_SEP,
                    function_id, RS_SEP, hostname, RS_SEP, map_code, RS_SEP, module, RS_SEP, user, FS_SEP);
            field_size = strlen(field_buffer);
            single_Buff = (char *)CALLOC(field_size + 1, sizeof(char));
            strcpy(single_Buff, field_buffer);

            if (!ParseEntityData(Entity_name, Data, &data_Buff, auditFlag))
            {
                MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "ParseEntityData function returned NULL");
                if (data_Buff)
                    continue;
            }
            data_size = strlen(data_Buff);
            single_Buff = (char *)REALLOC(single_Buff, (data_size + field_size + 1) * sizeof(char));
            strcat(single_Buff, data_Buff);

            if (!single_Buff)
            {
                MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "ParseEntityData function returned NULL");
                FREE_DYNST(aMap, A_Map);
                return AUDIT_ERROR;
            }

            bufLen += strlen(single_Buff);

            if (!Big_Buff)
            {
                Big_Buff = (char *)CALLOC(bufLen + 1, sizeof(char));
                if (!Big_Buff)
                {
                    MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "Memory allocation error");
                    FREE_DYNST(aMap, A_Map);
                    return AUDIT_ERROR;
                }
                strcpy(Big_Buff, single_Buff);
            }
            else
            {
                Big_Buff = (char *)REALLOC(Big_Buff, (bufLen + 2) * sizeof(char));
                if (!Big_Buff)
                {
                    MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "Memory reallocation error");
                    FREE_DYNST(aMap, A_Map);
                    return AUDIT_ERROR;
                }
                strcat(Big_Buff, single_Buff);
            }
            FREE(single_Buff);

            recCount++;
            if(recCount == noOfBatchStreamRec)     /*PMSTA-41530-VSW-21082020*/
            {
                map_return = Run_Map(Big_Buff, map_storage);
                FREE(Big_Buff);
                Big_Buff = NULL;
                bufLen = 0;
                recCount = 0;
				break;
            }
        }
        if (recCount)
        {
            map_return = Run_Map(Big_Buff, map_storage);
            FREE(Big_Buff);
            Big_Buff = NULL;
            bufLen = 0;
            recCount = 0;
        }
        begin = end;
    }
    FREE(data_Buff);
    return AUDIT_SUCCEED;
}

/************************************************************************
**      END  auditlib.c                                        UNICIBLE
*************************************************************************/


















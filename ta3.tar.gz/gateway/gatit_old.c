/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/****************************************************************************
**	
**	
**  Function    :   libgatit.c 					
**  Description :   A shared library/DLL to act as an Application Adapter to Mercator.It 
**	                receives a pointer to the EXITPARAM structure used by 
**	                Mercator and performs either an Import or an Export 
**	                depending on which function Mercator selects.
**
**
******************************************************************************/

/* VERSION */ static char Sccsid[]="@(#)gatit.c 5.26\t01/04/25";

#ifdef __cplusplus
extern "C"{
#endif

#define BATCHEX_C
#ifdef SOLARIS	
#define _REENTRANT
#endif

#ifdef HPUX
#define _HPUX_SOURCE
#endif

/* Standard includes*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <time.h> /*NGA - 25/01/2002 - TASK 2759*/

#ifdef WIN32 /*NGA - 18/06/2002 - TASK 6181 : adapt libgatit for WIN32*/
#include <windows.h>
#include <conio.h>
#else
#include <pthread.h> /*NGA - 29/01/2002 - TASK 2759 : use pthread libs on HP also!*/
#include <unistd.h>
#endif


/* TripleA includes*/
#include "olitapi.h"
#include "olitsign.h"
#include "runmerc.h"

#define FALSE		0
#define TRUE		1
#define OPT_ENABLED	0x00000002
#define OPT_DISABLED	0x00000003
#define BLK_ENABLED	0x00000004
#define BLK_DISABLED	0x00000005
#define INIT_FLAG 	0x00000006
#define OPTI_SET	   0x00000007
#define ARG_SUCCESS	0x00000008
#define ARG_ERR   	0x00000009
#define OLIT_FAIL 	0x0000000A
/*NGA Defines - 25/01/2002 - TASK 2759*/
#define DEBUG_GATADAPT		"DEBUG_GATADAPT"	/*Name of the env var allowing logging*/
#define LOG_FILE_NAME		"gatit.log"			/*Name of the log file*/
#define DATE_MAX_LENGTH		25					/*Length of the date field in log file*/
#define MAX_LOG_FILE_NAME	1024				/*Max length of log file full name (incl path)*/
#define MAX_LOG_MESSAGE_LENGTH  1024			/*Max length of a log message*/
#define ADAPTER_ERROR		-99					/*Code returned by adapter on error*/
#define ADAPTER_WARNING		99					/*Code returned by adapter on warning*/
#define ADAPTER_SUCCESS		0					/*Code returned by adapter on success*/
	
#define LOG_NOT_OPENED		-1					/*fopen failedfor log file*/
#define LOG_PATH_TOO_LONG	-2					/*path of the log file is too long*/

#define LOGGING					0			
#define LOGGING_ERROR			1

#ifdef HPUX
#define LIBPATH			"SHLIB_PATH"
#elif defined SOLARIS
#define LIBPATH			"LD_LIBRARY_PATH"
#elif defined WIN32
#define LIBPATH			"PATH"
#else
#define LIBPATH			"LIBPATH"
#endif
/*NGA Defines - 18/06/2002 - TASK 6181 : public functions of DLL and path separator*/
#ifdef WIN32
#define DYN_LOADER_API __declspec(dllexport)
#define PATH_SEPARATOR '\\'
#else
#define DYN_LOADER_API
#define PATH_SEPARATOR '/'
#endif


/*End of NGA Defines*/
#ifndef WIN32 /*NGA - 18/06/2002 - TASK 6181 : adapt libgatit for WIN32*/
static pthread_mutex_t  lock = PTHREAD_MUTEX_INITIALIZER; /*NGA - 29/01/2002 - TASK 2759 : use pthread libs on HP also!*/
#endif


/************************************************************************
**
**	Global	Variables	
**
************************************************************************/
static AAA_OliContext_STP    Globalcontext;
static  int                  GlobOptimise=OPT_ENABLED;
static  int                  GlobBlock=BLK_ENABLED;
static  int                  oliSetFlag;
static  int                  initInterface; 
static  int	             init_status;
/*NGA Global variables - 25/01/2002 - Task 2759*/
FILE * logDescriptor=NULL;
char * messageTypes [2] = {"LOGGING","ERROR"};
char logMessage [MAX_LOG_MESSAGE_LENGTH];
int fullLog=0;
/*End of NGA Global variables.*/
/************************************************************************
**
**	Function Prototypes
**
************************************************************************/
DYN_LOADER_API void __stdcall DLLImPort(LPEXITPARAM );	
/*NGA - 29/01/2002 - Task 2759 - function DLLExpTest suppressed.*/
/*NGA - 29/01/2002 - Task 2759 - function SplitOutput suppressed.*/
int     	SplitCmd( char *** ,char *);
void		Discard(int , char **);
int 		PlatAPI( char * , int , char *);
int  		CheckCmd( char ** ,char ** , int , int, int *);
int         SetCmdOptions(int , int ,int,  char **, int *);
/*NGA - 18/06/2002 - Task 6181 - function LoadLib suppressed.*/
/*NGA Function prototypes - 25/01/2002 - TASK 2759: Log open, write and close.*/
int			initLogFile (char *);
int 		writeLogFile (char *, int);
int			closeLogFile ();
/*End of NGA Function prototypes.*/
/************************************************************************
**
**	Entry Point Function	
**
************************************************************************/
int __start(LPEXITPARAM lpep)
{

	int i;
	struct
	{
		char *lpszFunction;
		void *fnPtr;
	}astFunc[]=
	{
		"DLLImPort" , (void *)DLLImPort,
	};
#define NUM_FUNCTIONS (sizeof(astFunc)/sizeof(astFunc[0]))

/* find the address of the specified function  */

	for(i = 0 ; i < NUM_FUNCTIONS ; i++ )
	{
		if((strcmp(lpep -> szFile,astFunc[i].lpszFunction) == 0))
		{
			lpep ->lpv = astFunc[i].fnPtr;
			break;
		}
	}
	if(i == NUM_FUNCTIONS)
	{
		lpep ->lpv = NULL;
	}

	return(0);
}
/************************************************************************
**
**  Function            :     initLogFile - NGA - Creation 25/01/2002 - Task 2759
**
**  Description		:     opens log file (append). Log file is in $AAAMSG or in current directory.
**			      The log file is only created if $DEBUG_GATADAPT is defined in the env.
**
**  Arguments     	:     logFileName : name of the log file
**
**
**  Return        	:     status: O (successful) or negative number
**
************************************************************************/

int initLogFile (char * logFileName)
{
	char * envVariables [7] = {"AAAHOME","SYBASE","DSQUERY",LIBPATH,"AAABIN","AAALOGINDB","AAAMSG"};
	char logFullName [MAX_LOG_FILE_NAME];
	int i;
	if (getenv (DEBUG_GATADAPT))
		fullLog=1;
	
	if (getenv ("AAAMSG"))
	{
		if (strlen (getenv ("AAAMSG"))> (MAX_LOG_FILE_NAME - strlen (logFileName)))
			return LOG_PATH_TOO_LONG;
		strcpy (logFullName,getenv("AAAMSG"));
		strcat (logFullName,"/");
		strcat (logFullName,logFileName);
	}
	else
		strcpy (logFullName, logFileName);
	if (fullLog)
		remove (logFullName);
	if ((logDescriptor=fopen (logFullName, "a+")))
	{
		fprintf (logDescriptor, "Libgatit Log File\n-----------------\nSet DEBUG_GATADAPT for full logging.\n--------------------------------------------------\nCurrent environment variables:\n");
		for (i = 0; i<7; i++)
		{
			fprintf (logDescriptor,"%s=",envVariables [i]);
			if (getenv (envVariables [i]))
				fprintf (logDescriptor, "%s\n",getenv (envVariables [i]));
			else
				fprintf (logDescriptor, "NOT DEFINED\n");
		}
		fprintf (logDescriptor,"--------------------------------------------------\n");
		fflush (logDescriptor);
		
		return 0;
	}
	else
		return LOG_NOT_OPENED;

}
/************************************************************************
**
**  Function            :     writeLogFile - NGA - Creation 25/01/2002 - Task 2759
**
**  Description         :     writes in log file (append). Log file is in $AAAMSG or in current directory.
**
**  Arguments           :     logMessage : log or error message
**			      type : LOGGING or ERROR
**
**  Return              :     status: O (successful) or negative number
**
************************************************************************/

int writeLogFile (char * logMessage, int type)
{
	if (logDescriptor && !((type==LOGGING)&&(fullLog==0)))
	{
		time_t logTime;
	 	struct tm *pStructTime=NULL;
		char logDate [DATE_MAX_LENGTH];

		/*System time retrieving.*/
		time (&logTime);
		pStructTime = localtime (&logTime);
		sprintf (logDate,"%4d/%02d/%02d %02d:%02d:%02d",
		(pStructTime->tm_year + 1900),
		(pStructTime->tm_mon + 1),
		pStructTime->tm_mday,
		pStructTime->tm_hour,
		pStructTime->tm_min,
		pStructTime->tm_sec);

		/*Writing in log*/
		fprintf (logDescriptor,"DATE        : %s\nTYPE        : %s\nMESSAGE     :%s\n--------------------------------------------------\n",
		logDate,messageTypes [type],logMessage);
		fflush (logDescriptor);
	}
	return 0;
}
/************************************************************************
**
**  Function            :     closeLogFile - NGA - Creation 25/01/2002 - Task 2759
**
**  Description         :     closes log file. Log file is in $AAAMSG or in current directory.
**
**  Arguments           :     None
**
**
**  Return              :     status: O (successful) or negative number
**
************************************************************************/

int closeLogFile ()
{
if (logDescriptor)
	fclose (logDescriptor);
return 0;
}

/*NGA - 29/01/2002 - TASK 2759 : use pthread libs on HP also!, function called_once suppressed.*/

/************************************************************************
**
**  Function	:	SetCmdOptions 					
**
**  Description :   Sets the arguments to give to AAA_OliSetOpti 
**
**  Arguments    :  int,int,int,char **,int *
**					
**
**  Return      :   0 on success , 1 on memory allocation problem
**
************************************************************************/
int SetCmdOptions(int optimise, int blockflag, int blk_size, char ** opti_return, int  *blk_return)
{
    
    if((*opti_return = (char *)calloc(10, sizeof(char))) == NULL)
        return 1;
    if(optimise == OPT_ENABLED)
        strcpy(*opti_return,"ENABLE");
    else
        strcpy(*opti_return,"DISABLE");

    if(blockflag == BLK_ENABLED)
        *blk_return = blk_size;
    else
        *blk_return = -1;

    return 0;

}
/************************************************************************
**
**  Function    :   CheckCmd					
**  Description :   Checks the new command line against previous version 
**						  to determine if interface requires updating
**					
**					 
**  Arguments   :   char	**		table of args
**				    	  int				no of command line args
**		
**										
**
**  Return      :   int				
**
************************************************************************/
int CheckCmd( char ** argTable , char ** refArgs,  int nArgs , int globArgs, int * bSize)
{

    int i,j;
    int prog_name;
    unsigned char dash = 45;
    char opt = 0;
    char errmsg[128];
    int loc_block = BLK_DISABLED;
    int loc_optimise =OPT_DISABLED;
    
    initInterface = 0;
    oliSetFlag = 0;
    writeLogFile ("Checking command line arguments...",LOGGING); /*NGA - 28/01/2002 - Task 2759*/
    if(nArgs < 3)
    {
        strcpy(errmsg,"Connection options:" "Number of Arguments must be more than three");
        fprintf(stderr, errmsg);
	writeLogFile ("Number of arguments is lower than 3",LOGGING_ERROR); /*NGA - 28/01/2002 - Task 2759*/
        return ARG_ERR;  /* Argument misuse */
    }
    for(i = 0 ; i < nArgs ; i++)
    {
        if(i == 0)
            if(prog_name = strcmp(argTable[i], refArgs[i]))
	    {
                initInterface = INIT_FLAG;                      /* Need to reinitialise the Online Interface */
		writeLogFile ("Command line has changed (first argument)",LOGGING_ERROR); /*NGA - 28/01/2002 - Task 2759*/
	    }
            else
                continue;


        if(argTable[i][0] == dash)
            opt = (argTable[i][1]);
        else
            opt = (argTable[i][0]);


        switch(opt)
        {
        case 'U' :  /* User name */
                    if(argTable[i + 1] == (char *)NULL)
                    {
                        strcpy(errmsg,"Connection option ""-U"" : Triple-A User must be provided");
                        fprintf(stderr, errmsg);
			writeLogFile ("No user provided!",LOGGING_ERROR); /*NGA - 28/01/2002 - Task 2759*/
                        return ARG_ERR;                        /* Argument misuse */
                    }
                    for(j = 1 ; j < globArgs ; j++)
                    {
                        if(!strcmp(refArgs[j] , "-U"))
                        {
                            if(strcmp(refArgs[j+1] , argTable[i+1]))
                            {
                                initInterface = INIT_FLAG;             /* Need to reinitialise the Online Interface */
				writeLogFile ("Command line has changed (user)",LOGGING_ERROR); /*NGA - 28/01/2002 - Task 2759*/
                                i++;
                                break;
                            }
                            else
                            {
                                i++;
                                break;
                            }
                        }
                    }
                    if(j == globArgs)
		    {
                        initInterface = INIT_FLAG;
			writeLogFile ("Command line has changed (user)",LOGGING_ERROR); /*NGA - 28/01/2002 - Task 2759*/
		    }
		    sprintf (logMessage, "User is %s",argTable [i]); /*NGA - 28/01/2002 - Task 2759*/
		    writeLogFile (logMessage,LOGGING);
                    break;


        case 'P' :  /* Password */
                    if(argTable[i + 1] == (char *)NULL)
                    {
                        strcpy(errmsg,"Connection option ""-P"" : Triple-A Password must be provided");
                        fprintf(stderr, errmsg);
			writeLogFile ("No password provided!",LOGGING_ERROR); /*NGA - 28/01/2002 - Task 2759*/
                        return ARG_ERR;                     /* Argument misuse */
                    }
                    for(j = 1 ; j < globArgs ; j++)
                    {
                        if(!strcmp(refArgs[j] , "-P"))
                        {
                            if(strcmp(refArgs[j+1] , argTable[i+1]))
                            {
                                i++;
                                initInterface = INIT_FLAG;      /* Need to reinitialise the Online Interface */
				writeLogFile ("Command line has changed (password)",LOGGING_ERROR); /*NGA - 28/01/2002 - Task 2759*/
                                break;
                            }
                            else
                            {
                                i++;
                                break;
                            }
                        }
                    }
                    if(j == globArgs)
		    {
                        initInterface = INIT_FLAG;
			writeLogFile ("Command line has changed (password)",LOGGING_ERROR); /*NGA - 28/01/2002 - Task 2759*/
		    }
		    sprintf (logMessage, "Password is %s",argTable [i]); /*NGA - 28/01/2002 - Task 2759*/
  		    writeLogFile (logMessage,LOGGING);

                    break;

        case 'S' :  /* Server name */
                    if(argTable[i + 1] == (char *)NULL)
                    {
                        strcpy(errmsg,"Connection option ""-S"" : Specify a valid Financial Server");
                        fprintf(stderr, errmsg);
			writeLogFile ("No server name provided!",LOGGING_ERROR); /*NGA - 28/01/2002 - Task 2759*/
                        return ARG_ERR;                     /* Argument misuse */
                    }
                    for(j = 1 ; j < globArgs ; j++)
                    {
                        if(!strcmp(refArgs[j] , "-S"))
                        {
                            if(strcmp(refArgs[j+1] , argTable[i+1]))
                            {
                                i++;
                                initInterface = INIT_FLAG;      /* Need to reinitialise the Online Interface */ 
				writeLogFile ("Command line has changed (server name)",LOGGING_ERROR); /*NGA - 28/01/2002 - Task 2759*/
                                break;
                            }
                            else
                            {
                                i++;
                                break;
                            }
                        }
                    }
                    if(j == globArgs)
		    {
                        initInterface = INIT_FLAG;
			writeLogFile ("Command line has changed (server name)",LOGGING_ERROR); /*NGA - 28/01/2002 - Task 2759*/
		    }
		    sprintf (logMessage, "Server Name is %s",argTable [i]); /*NGA - 28/01/2002 - Task 2759*/
		    writeLogFile (logMessage,LOGGING);
                    break;


        case 'J' :  /* Character set */
                    if(argTable[i + 1] == (char *)NULL)
                    {
                        strcpy(errmsg,"Connection option ""-J"" : Character set must be provided");
                        fprintf(stderr, errmsg);
			writeLogFile ("No character set provided!",LOGGING_ERROR); /*NGA - 28/01/2002 - Task 2759*/
                        return ARG_ERR;                 /* Argument misuse */
                    }
                    for(j = 1 ; j < globArgs ; j++)
                    {
                        if(!strcmp(refArgs[j] , "-J"))
                        {
                            if(strcmp(refArgs[j+1] , argTable[i+1]))
                            {
                                initInterface = INIT_FLAG;               /* Need to reinitialise the Online Interface */ 
				writeLogFile ("Command line has changed (character set)",LOGGING_ERROR); /*NGA - 28/01/2002 - Task 2759*/
                                i++;
                                break;
                            }
                            else
                            {
                                i++;
                                break;
                            }
                        }
                    }
                    if(j == globArgs)
		    {
                        initInterface = INIT_FLAG;
			writeLogFile ("Command line has changed (character set)",LOGGING_ERROR); /*NGA - 28/01/2002 - Task 2759*/
		    }
		    sprintf (logMessage, "Character Set is %s",argTable [i]); /*NGA - 28/01/2002 - Task 2759*/
		    writeLogFile (logMessage,LOGGING);
                    break;

        case 'M' :  /* Mode */
                    if(argTable[i + 1] == (char *)NULL)
                    {
                        strcpy(errmsg,"Connection option ""-M"" : Mode must be provided");
                        fprintf(stderr, errmsg);
			writeLogFile ("No mode provided!",LOGGING_ERROR); /*NGA - 28/01/2002 - Task 2759*/
                        return ARG_ERR;                  /* Argument misuse */
                    }
                    for(j = 1 ; j < globArgs ; j++)
                    {
                        if(!strcmp(refArgs[j] , "-M"))
                        {
                            if(strcmp(refArgs[j+1] , argTable[i+1]))
                            {
                                initInterface = INIT_FLAG;    /* Need to reinitialise the Online Interface */
				writeLogFile ("Command line has changed (mode)",LOGGING_ERROR); /*NGA - 28/01/2002 - Task 2759*/
                                i++;
                                break; 
                            }
                            else
                            {
                                i++;
                                break;
                            }
                        }
                    }
                    if(j == globArgs)
		    {
                        initInterface = INIT_FLAG;
			writeLogFile ("Command line has changed (mode)",LOGGING_ERROR); /*NGA - 28/01/2002 - Task 2759*/
		    }
		    sprintf (logMessage, "Mode is %s",argTable [i]); /*NGA - 28/01/2002 - Task 2759*/
		    writeLogFile (logMessage,LOGGING);
                    break;

        case 'B' :  /* Block size */
                    if((argTable[i + 1] == (char *)NULL)||((i + 1) == nArgs))
                    {
                        strcpy(errmsg,"Connection option ""-B"" : A Block size must be provided");
                        fprintf(stderr, errmsg);
			writeLogFile ("No block size provided!",LOGGING_ERROR); /*NGA - 28/01/2002 - Task 2759*/
                        return ARG_ERR;                /* Argument misuse */
                    }
                    if(GlobBlock == BLK_ENABLED)
                    {
                        for(j = 1 ; j < globArgs ; j++)
                        {
                            if(!strcmp(refArgs[j] , "-B"))
                            {
                                if(strcmp(refArgs[j+1] , argTable[i+1]))  /* Block size is different */
                                {
                                    *bSize = atoi(argTable[i + 1]);
                                    loc_block   = BLK_ENABLED;
                                    oliSetFlag = OPTI_SET;
                                    i++;
                                    break;
                                }
                                else
                                {
                                    *bSize = atoi(argTable[i + 1]);  /* Block size is same */
                                    loc_block   = BLK_ENABLED;
                                    i++;
                                    break;
                                }
                            }
                        }
                    }
                    else
                    {
                        *bSize = atoi(argTable[i + 1]);
                        oliSetFlag  = OPTI_SET;
                        loc_block   = BLK_ENABLED;
                        i++;
                        break;
                    }
		    sprintf (logMessage, "Block size is %s",argTable [i]); /*NGA - 28/01/2002 - Task 2759*/
		    writeLogFile (logMessage,LOGGING);

                    break;
        case 'O' :  /* Optimisation */ 
                    if(GlobOptimise == OPT_DISABLED)  /* Command line has had -O added */ 
                    {
                        oliSetFlag   = OPTI_SET;
                        loc_optimise = OPT_ENABLED;
                        break;
                    }
                    else
                    {
                        loc_optimise = OPT_ENABLED;
                        break;           /* Command line is same with respect to -O option */  
                    }
                    break;
        }

    }
    if(loc_block == BLK_DISABLED)
    {   
	writeLogFile ("Block Mode disabled",LOGGING);  /*NGA - 28/01/2002 - Task 2759*/
        if(GlobBlock == BLK_ENABLED)
        {
            oliSetFlag = OPTI_SET;
            GlobBlock  = BLK_DISABLED;
        }
    }
    else
	writeLogFile ("Block Mode enabled",LOGGING);  /*NGA - 28/01/2002 - Task 2759*/
    {
        if(GlobBlock == BLK_DISABLED)
        {
            oliSetFlag = OPTI_SET;
            GlobBlock  = BLK_ENABLED;
        }
    }

    if(loc_optimise == OPT_DISABLED)
    {
	writeLogFile ("Optimisation mode disabled",LOGGING); /*NGA - 28/01/2002 - Task 2759*/
        if(GlobOptimise == OPT_ENABLED)
        {
            oliSetFlag = OPTI_SET;
            GlobOptimise=OPT_DISABLED;
        }
    }
    else
    {
	writeLogFile ("Optimisation mode enabled",LOGGING); /*NGA - 28/01/2002 - Task 2759*/

        if(GlobOptimise == OPT_DISABLED)
        {
            oliSetFlag = OPTI_SET;
            GlobOptimise=OPT_ENABLED;
        }
    }

    return ARG_SUCCESS;
}

/************************************************************************
**
**  Function    :   DLLImPort 					
**  Description :   Connects to the Online Interface and passes the data 
**						  from Mercator to Triple'A via this.
**					 
**  Arguments    :  lpInputStruct	Mercator structure containing pointers
**					     to the command line and data.
**					
**
**  Return      :   Nothing
**
************************************************************************/
DYN_LOADER_API void __stdcall DLLImPort(LPEXITPARAM  lpInputStruct)	
{
	FILE		*fp = NULL;
	int		nTokens;
	int		ErrorLineNum = 0; 
	int		LineCount =0;
	int		SuccessLineNum= 0;
	int		n = 0;
	int		blockSize = 0;
	int		nTok = 0;
	char		Result[256];
	char		**String = (char **)NULL;
	char		**TokString = (char **)NULL;
	static char	**GlobalString = (char **)NULL;
	static int	GlobalTokens;
	char		TokList[] =  " \t\r\n";
	char		*MapPath = (char *)NULL;
	char		*end_line = NULL;
	char		*optimise_flag = (char *)NULL;
	char		*Tokencopy = (char *)NULL;
	char		*keyword = "MAP ";
	char		*lpBuf = (char *)NULL;
	char		separator2[] = "\n";
	char		separator3[] = "\0";
	char		*map_seg = (char *)NULL;
	char		*first_seg = (char *)NULL;
	char		*first_segPtr = (char *)NULL;
	char		*map_line = (char *)NULL;
	char		*map = (char *)NULL;
	char		output_file[512];
	char		*file_path = (char *)NULL; 
	char		*basename = (char *)NULL;
	char		*InputData =  (char *)NULL;
	char		*second_seg = (char *)NULL;
	char		*InData = (char *)NULL;
/*NGA - 20/06/2002 - TASK 6181 : adapt libgatit for WIN32*/
	char		*CmdLine = (char*)NULL;
	int			CmdLineLength = 0;

	int		first_segLen;
	int		first_lineLen = 0;
	int		first_len;
	int		second_len;					
	int		failed_proc = 0;
	int		dwLen = 0;
	int		DataLen;
	int		map_return = 0;
	int		block_flag = 0;
	OLI_STATUS	CallReturn=RET_OK; /*NGA - 28/01/2002 - Task 2759*/
	OLI_STATUS	GetReturn=RET_OK; /*NGA - 28/01/2002 - Task 2759*/

	static OLI_STATUS		OliReturn=RET_OK;
	static AAA_OliContext_STP 	localcontext;
	

#ifdef WIN32 /*NGA - 18/06/2002 - TASK 6181 : adapt libgatit for WIN32*/
	CreateMutex (NULL , TRUE , "MUTEX_LOCK");
#else
   pthread_mutex_lock(&lock); /*NGA - 29/01/2002 - TASK 2759 : use pthread libs on HP also!*/
#endif

	initLogFile (LOG_FILE_NAME); /*NGA - 25/01/2002 - Task 2759*/
	writeLogFile ("Entered DLLImPort, mutex locked",LOGGING); /*NGA - 25/01/2002 - Task 2759*/
/*	lpInputStruct->lpDataToApp[(lpInputStruct->dwToLen)] = '\0';*//*NGA - 24/04/2002 - LN7504*/
	sprintf (logMessage, "CommandLine: %s",lpInputStruct->lpszCmdLine);
	CmdLineLength = strlen (lpInputStruct->lpszCmdLine);
	CmdLine = (char *) malloc (CmdLineLength + 1);
	strcpy (CmdLine, lpInputStruct->lpszCmdLine);
	writeLogFile (logMessage, LOGGING); /*NGA - 28/01/2002 - Task 2759*/
	nTokens = SplitCmd(&String , CmdLine);
		if(!GlobalTokens)
		{
			writeLogFile ("First call to DLLImPort, online library needs to be initialised",LOGGING);  /*NGA - 28/01/2002 - Task 2759*/
			GlobalString = (char **)malloc(nTokens * sizeof(char *));     
  			GlobalTokens = nTokens;
  			for(nTok = 0 ; nTok < nTokens ; nTok++)
  			{
  			       GlobalString[nTok] = strdup(String[nTok]);
  			}  
			if(CheckCmd(String, GlobalString,nTokens,GlobalTokens,&blockSize) == ARG_SUCCESS)
			{
				writeLogFile ("Command line is correct.",LOGGING);  /*NGA - 28/01/2002 - Task 2759*/
				if(init_status != OLIT_FAIL)
				{
					localcontext = (AAA_OliContext_ST *)calloc(1,sizeof(AAA_OliContext_ST));   
					OliReturn = AAA_OliInit( nTokens , String , localcontext);
 					Globalcontext = localcontext;  
					if(ST_ERROR(OliReturn))
					{
						sprintf (logMessage,"Call to AAA_OliInit failed, return code is: %d", OliReturn); /*NGA - 28/01/2002 - Task 2759*/
						writeLogFile (logMessage, LOGGING_ERROR);
						for(n = 0 ; n  < GlobalTokens ; n++)
							free(GlobalString[n]);
					   	free(GlobalString);
					   	GlobalTokens = 0;
					   	failed_proc = 1;
					 	init_status = OLIT_FAIL;
				  		strcpy(lpInputStruct ->szErrMsg, "libolit initialisation failed");
						lpInputStruct ->nReturn = ADAPTER_ERROR;
					}
				}
			}
			else
			{
				for(n = 0 ; n  < GlobalTokens ; n++)
					free(GlobalString[n]);
				free(GlobalString);
			      	GlobalTokens = 0;
				strcpy(lpInputStruct ->szErrMsg , "Command line error : ignoring this card");	   
				lpInputStruct ->nReturn = ADAPTER_WARNING;
				writeLogFile ("Command line was not correct, ignoring the map card.",LOGGING_ERROR);
				failed_proc = 1;
			}
		}
		else
		{
			writeLogFile ("It is not the first execution, libolit is already loaded and initialised.",LOGGING); /*NGA - 28/01/2002 - Task 2759*/
			if(CheckCmd(String, GlobalString,nTokens,GlobalTokens,&blockSize) == ARG_SUCCESS)
			{
    				if(initInterface == INIT_FLAG)	
				{
				strcpy(lpInputStruct ->szErrMsg , "Change of Command Line requires reinitialisation of Interface: ignoring card");	 
				lpInputStruct ->nReturn = ADAPTER_WARNING;
				writeLogFile ("Command line was not correct (it has changed), ignoring the map card.",LOGGING_ERROR);  /*NGA - 28/01/2002 - Task 2759*/
					failed_proc = 1;
				}
				else
				{
					for(n = 0 ; n  < GlobalTokens ; n++)
						free(GlobalString[n]);
					free(GlobalString);
     					GlobalString = (char **)realloc( NULL ,nTokens * sizeof(char *));
      					for(nTok = 0 ; nTok < nTokens ; nTok++)
      					{
        					GlobalString[nTok] = strdup(String[nTok]);
      					}	
					GlobalTokens  = nTokens;
					if(ST_SUCCESS(OliReturn))
					{
						if(oliSetFlag == OPTI_SET)
						{
							writeLogFile ("Block or optimisation needs to be reset (AAA_OliSetOpti)",LOGGING);  /*NGA - 28/01/2002 - Task 2759*/
							if(!SetCmdOptions(GlobOptimise,
								GlobBlock,
								blockSize,
								&optimise_flag,
								&block_flag))
							{
								AAA_OliSetOpti(optimise_flag,block_flag);
								writeLogFile ("Block or optimisation has been reset",LOGGING); /*NGA - 28/01/2002 - Task 2759*/
							}
							else
							{
								 strcpy(lpInputStruct ->szErrMsg , "Failed to reset block size or optimisation mode: aborting card");   
								 lpInputStruct ->nReturn = ADAPTER_WARNING;
								 writeLogFile ("Failed to reset block or optimisation",LOGGING_ERROR);
								failed_proc = 1;
							}
						}
					}
					else
					{
						strcpy(lpInputStruct ->szErrMsg , "Libolit not initialised properly: aborting card"); 
						lpInputStruct->nReturn = ADAPTER_ERROR;
						sprintf (logMessage, "The call to AAA_OliInit returned an error: %d",OliReturn); /*NGA - 28/01/2002 - Task 2759*/
						writeLogFile (logMessage, LOGGING_ERROR); /*NGA - 28/01/2002 - Task 2759*/
						failed_proc = 1;
					}
				}
			}
			else
			{
				strcpy(lpInputStruct ->szErrMsg , "Command line error : ignoring this card");	 
				lpInputStruct ->nReturn = ADAPTER_WARNING;
				writeLogFile ("Command line was not correct, ignoring the map card.",LOGGING_ERROR);  /*NGA - 28/01/2002 - Task 2759*/
				failed_proc = 1;
			}
		}

/* delete the temporary parameters table*/
	Discard(nTokens, String);
	if(!failed_proc)
	{
		if( ST_SUCCESS(OliReturn))
		{

			writeLogFile ("The online library is now ready to be used.",LOGGING); /*NGA - 28/01/2002 - Task 2759*/
			Tokencopy  =(char *)calloc((lpInputStruct->dwToLen)+5 , sizeof(char));
			memcpy(Tokencopy,lpInputStruct->lpDataToApp, lpInputStruct->dwToLen);
			Tokencopy[(lpInputStruct->dwToLen)] = '\0';    
			if((first_segPtr = strstr(Tokencopy , keyword )) != NULL)
			{
				writeLogFile ("Output has to be sent to a map",LOGGING); /*NGA - 28/01/2002 - Task 2759*/
				InputData = (char *)calloc((lpInputStruct->dwToLen) + 1 , sizeof(char) );
				end_line = strchr(Tokencopy, '\n');
				first_lineLen = end_line - Tokencopy; 
				first_segLen = (first_segPtr - Tokencopy);      
				if( first_segLen < first_lineLen ) /*   then keyword is on the first line    */
				{
					map_line = strtok(Tokencopy , separator2);  
					InData = strtok(NULL , separator3);	
					strcpy(InputData , InData );
					DataLen = strlen(InputData);
					strtok(map_line ,TokList);
					MapPath = strtok(NULL , TokList); 
				}
				else
				{
					first_seg = (char *)calloc(first_segLen + 5, sizeof(char) );
					memcpy(first_seg , Tokencopy , first_segLen );
					first_seg[first_segLen] = '\0';
					map_line = strtok(first_segPtr , separator2);	
					second_seg = strtok(NULL , separator3);
					first_len = strlen(first_seg);	
					second_len = strlen(second_seg);
					strcpy(	InputData , first_seg);
					strcat(InputData , second_seg );
					DataLen = strlen(InputData);
					strtok(map_line ,TokList);
					MapPath = strtok(NULL , TokList); 
					free(first_seg);
				}	
				sprintf (logMessage, "The map to call is %s",MapPath); /*NGA - 28/01/2002 - Task 2759*/
				writeLogFile (logMessage, LOGGING); /*NGA - 28/01/2002 - Task 2759*/
			}
			else
			{
				writeLogFile ("Output has to be sent to a text file",LOGGING); /*NGA - 28/01/2002 - Task 2759*/
				InputData = (char *)calloc((lpInputStruct->dwToLen) + 10 , sizeof(char) );
				strcpy(InputData , Tokencopy ); 
				DataLen = lpInputStruct->dwToLen ;    
			}
			if((CallReturn=AAA_OliCall(localcontext, InputData, (DataLen + 1))) == RET_OK)
			{
				writeLogFile ("The call to the online import (export) was successful!",LOGGING);
				while (((GetReturn=AAA_OliGet(localcontext , ( AAA_OliChEnum)Data, Result, 255))) == RET_OK)
				{
					dwLen += strlen(Result);
					 
					if(!lpBuf)
					{
						lpBuf = (char *)calloc(dwLen +1 , sizeof(char));
						strcpy(lpBuf,Result);
					}
					else
					{
						lpBuf = (char *)realloc(lpBuf, ( dwLen + 1) *sizeof(char)); 
						strcat(lpBuf, Result);
					}	 
				}
				if(lpBuf != (char *)NULL)
				{
					writeLogFile ("The output from the online import (export) has been successfully retrieved.",LOGGING);/*NGA - 28/01/2002 - Task 2759*/
					if(MapPath)
					{
						if(!(map_return = PlatAPI(lpBuf , dwLen , MapPath)))
						{
							writeLogFile ("Output map completed successfully.",LOGGING); /*NGA - 28/01/2002 - Task 2759*/
							lpInputStruct ->nReturn = ADAPTER_SUCCESS;
							strcpy(lpInputStruct ->szErrMsg , "Adapter completed successfully");   
							free(lpBuf);
						}
						else
						{
							strcpy(lpInputStruct ->szErrMsg , "Platform API returned an error running the map");   
							lpInputStruct ->nReturn = map_return;   
							sprintf (logMessage,"Output map failed with error code: %d",map_return); /*NGA - 28/01/2002 - Task 2759*/
							writeLogFile (logMessage,LOGGING_ERROR); /*NGA - 28/01/2002 - Task 2759*/
							free(lpBuf);
						}	
					}
					else
					{
       						if((file_path = getenv("AAA_GATEWAY_OUTPUT")))
						{
							if(!(map = strrchr(lpInputStruct->lpszMapDirectory,PATH_SEPARATOR)))
							{
								basename = lpInputStruct->lpszMapDirectory;
							}
							else
							{
								basename = map + 1;						
							}	
							sprintf(output_file ,"%s/%s.output",file_path,basename);
							sprintf (logMessage, "Output text file is %s",output_file); /*NGA - 29/01/2002 - Task 2759*/
							writeLogFile (logMessage, LOGGING); /*NGA - 29/01/2002 - Task 2759*/
							fp = fopen(output_file , "a" ); 
							if(fp)
							{
								fputs( lpBuf, fp);
								fclose(fp);
								writeLogFile ("Output data written successfully.",LOGGING); /*NGA - 28/01/2002 - Task 2759*/
								lpInputStruct ->nReturn = ADAPTER_SUCCESS;
								strcpy(lpInputStruct ->szErrMsg , "Adapter completed successfully");
							} 
							else
							{
								writeLogFile ("Unable to open output text file",LOGGING_ERROR); /*NGA - 29/01/2002 - Task 2759*/
								strcpy(lpInputStruct ->szErrMsg , "Unable to open output text file");
								lpInputStruct ->nReturn = ADAPTER_WARNING;
							}
						}
						else
						{
							strcpy(lpInputStruct ->szErrMsg, "AAA_GATEWAY_OUTPUT not defined");
							lpInputStruct ->nReturn = ADAPTER_WARNING;
							writeLogFile ("AAA_GATEWAY_OUTPUT variable is not defined!", LOGGING_ERROR); /*NGA - 29/01/2002 - Task 2759*/
						}
						free(lpBuf);
					}
				}
				else
				{
					sprintf (logMessage, "Error while retrieving output from online library, code is: %d",GetReturn); /*NGA - 28/01/2002 - Task 2759*/
					writeLogFile (logMessage, LOGGING_ERROR); /*NGA - 28/01/2002 - Task 2759*/
					strcpy(lpInputStruct ->szErrMsg , "AAA_OliGet function has returned an error");
					lpInputStruct ->nReturn = ADAPTER_WARNING;
				}
			}
			else
			{
				sprintf (logMessage, "Error while sending data to online library, code is: %d",CallReturn); /*NGA - 28/01/2002 - Task 2759*/
				writeLogFile (logMessage, LOGGING_ERROR); /*NGA - 28/01/2002 - Task 2759*/
				strcpy(lpInputStruct ->szErrMsg , "Sending data to the Online Interface failed");  
				lpInputStruct ->nReturn = ADAPTER_ERROR;
			}

		}
		else
		{
			strcpy(lpInputStruct ->szErrMsg , "Online Interface not initialised properly"); 
			lpInputStruct ->nReturn = ADAPTER_ERROR;
		}
	}
	
	if(Tokencopy)
		free(Tokencopy);
	if(InputData)
		free(InputData);
	if(optimise_flag)
		free(optimise_flag);
	if(CmdLine)
		free(CmdLine);
	closeLogFile (); /*NGA - 25/01/2002 - Task 2759*/

#ifdef WIN32 /*NGA - 18/06/2002 - TASK 6181 : adapt libgatit for WIN32*/
	ReleaseMutex ("MUTEX_LOCK");
#else
	pthread_mutex_unlock(&lock); /*NGA - 29/01/2002 - TASK 2759 : use pthread libs on HP also!*/
#endif

}

/************************************************************************
**
**  Function		:       SplitCmd
**
**  Description         :   Transforms a string into an argv model.
**
**  Arguments           :  Input       (in): Tokenised string
**                         String          (out)   : Resulting table of parameters
**
**  Return              :   number of parameters, i.e., argc
**
************************************************************************/
int SplitCmd(char ***String, char *Input)
{
	int nTokens = 0;
  	char *tok;
   	char separators[]   = " ,\t\n";
   	char                            *pszScan;
   
  /* If string starts with space or tab then increment Input  */
   
   	while (*Input && strchr(" \t", *Input) != NULL)
   	Input++;
   
   /*If the characters are enclosed in quotes then increment past this and set right hand quote to zero  */
   
  	if ((*Input == '\'') ||(*Input == '\"'))
  	{
  		Input++;
  		pszScan = Input + (strlen(Input) -1);
  	}
   	if ((*pszScan == '\'') ||(*pszScan == '\"'))
   	(*pszScan) = '\0';
   
   	*String = (char **)malloc(1 * sizeof(char *));
   
   	tok = strtok(Input, separators);
   	while(tok)
   	{
  	 	(*String)[nTokens++] = strdup(tok);
		sprintf(logMessage, "Element number %d in command: %s",nTokens,tok);
		writeLogFile (logMessage, LOGGING);
   		*String = (char **)realloc(*String, (nTokens+1)*sizeof(char *));
   		tok = strtok(NULL, separators);
   	}
   	return nTokens;
   }


/************************************************************************
**
**  Function    :   Discard 					
**  Description :   free the char ** variable created by the split method.
**
**  Argument    :   pszParameters (in)	: number of entries in pVector 
**					pVector		(in)	: table of parameters to be destroyed
**
**  Return      :   Nothing
**
************************************************************************/
void Discard(int nTokens, char *String[])
{
	int n;

	for ( n = 0 ; n < nTokens ; n++)
		free(String[n]);

	free(String);
}


/************************************************************************
**
**  Function    :   PlatAPI					
**  Description :   Calls RunMap function to execute a map to transform 
**                  exported data into client format
**					
**					 
**  Arguments    :  char *	data for map
**		    int		data length
**		    char *	map to execute
**					
**					
*
**  Return      :  int		map return status 
**
************************************************************************/
int	PlatAPI( char	*DataPointer , int DataLen , char *MapPtr)
{

	EXITPARAM			ExitParam;
//	FILE				*But;
	char				szbuf[1024];
	char				mapPath[1024];
	char				CommandOptions[]  = " -ie1s%d ";
	int				nlen = 0;

	strcpy(mapPath , MapPtr );
	strcat(mapPath , CommandOptions);
	sprintf(szbuf , mapPath , DataLen);
	nlen = strlen(szbuf);
	memset(&ExitParam, 0 , sizeof(EXITPARAM));
	ExitParam.lpDataToApp = (unsigned char *)malloc(DataLen + nlen + 10);
	if(!(ExitParam.lpDataToApp))
	{
		return 1;
	}
	ExitParam.dwSize = sizeof(EXITPARAM);
	ExitParam.lpv = NULL;

	memcpy( ExitParam.lpDataToApp, szbuf , nlen );
	memcpy(&ExitParam.lpDataToApp[nlen], DataPointer, DataLen +1 );
	
	RunMap(&ExitParam);
	free(ExitParam.lpDataToApp);
	return(ExitParam.nReturn);
}


#ifdef __cplusplus
}
#endif

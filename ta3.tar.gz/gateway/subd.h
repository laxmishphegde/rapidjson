/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**
**              Copyright (C) 1993-1994 by UNICIBLE
**                       All Rights Reserved
**
**                   Portfolio Management System
**
*************************************************************************/
#ifndef SUBD_H
#define SUBD_H

/* VERSION */ static char subdSid[]="@(#)subd.h I%\t01/02/15";

/************************************************************************
**      Constant & Macro definitions
*************************************************************************/
#define SUBD_HALT(x) SUBD_Halt(x, (char *)__FILE__, __LINE__)

/* some ret codes */
#define SUBD_SUCCEED		RET_SUCCEED
#define SUBD_MORE_EVENTS	SUBD_SUCCEED+1
#define SUBD_ERROR		SUBD_SUCCEED+2

#include "clusterconfig.h"

/************************************************************************
**      Structure & Type definitions
*************************************************************************/

typedef struct {
    SCPT_ARG_STP*           resultEvalTab;
    DBA_DYNFLD_STP*         fmtEltTab;
    int                     resultEvalTabNb;
} SUBD_RESULT_EVAL_TREE_ST, *SUBD_RESULT_EVAL_TREE_STP;

typedef struct {
    ID_T                        formatId;
    SUBD_RESULT_EVAL_TREE_STP   resultEvalTreePtr;
}SUBD_RESULT_EVAL_ST, *SUBD_RESULT_EVAL_STP;

/* PMSTA-34827 - JBC - 190218 */
typedef struct 
{
	int		    argc;
	char        **argv;
    int         threadNo;
} SUBD_THREAD_ARG_ST, * SUBD_THREAD_ARG_STP;


/*******************************************************************************
**     Classes
*******************************************************************************/

/* /* PMSTA-66218 - JBC - 20250221 : Helper Class for non-sequential multi-threading */
class SubdMultiQueue
{
    public:
        SubdMultiQueue() :
			m_blockSize(0),
			m_workerThreadCounter(0),
            m_isQueueEmpty(true)
        {
        }

        SubdMultiQueue(const SubdMultiQueue &) = delete;
        SubdMultiQueue & operator=(const SubdMultiQueue &) = delete;

    	// full replace of queue
        void splitEventsAndResize(std::vector<DBA_DYNFLD_STP> & eventTab, size_t blockSize, std::string busEntityCd)
        {
            assert(isEmpty());

            LockGuard  _(m_lock);  
            // leave first block for caller
            for(size_t i=blockSize;i<eventTab.size();i++)
            {
	            m_eventQueue.push(eventTab[i]);
            }
            m_blockSize = blockSize;
        	m_busEntityCd = busEntityCd;
            eventTab.resize(blockSize);
			m_isQueueEmpty.store(m_eventQueue.empty());
        }

        bool isEmpty()
        {
            return m_isQueueEmpty.load(); // less overhead in idle time
        }

        void getEventList(std::vector<DBA_DYNFLD_STP> & outEvents, std::string & busEntityCd, int & activeThreads)
        {   
            if(isEmpty() == false)
            {
                LockGuard   _(m_lock);
                for(int i = 0; i<m_blockSize;i++)
                {
					if(m_eventQueue.empty())
                    {
						break;
                    }
                    outEvents.push_back(m_eventQueue.front());
                    m_eventQueue.pop();
                }
                busEntityCd = m_busEntityCd;
                if(outEvents.empty() == false)
                {   // a thread is in process
	                activeThreads = m_workerThreadCounter.fetch_add(1) + 1;
                }
                if(m_eventQueue.empty())
                {
	                m_isQueueEmpty.store(true);
                }
            }
        }

        int getWorkerThreadCount()
        {
	        return m_workerThreadCounter.load();
        }

    	int decWorkerThread()
        {
	       return m_workerThreadCounter.fetch_sub(1) - 1;
        }

    private:
        Lock                        m_lock;
    	std::string                 m_busEntityCd;
    	size_t                      m_blockSize;
        std::queue<DBA_DYNFLD_STP>  m_eventQueue;
		AtomicInt                   m_workerThreadCounter;
    	AtomicBool                  m_isQueueEmpty;  // atomic to avoid lock
};
/*  PMSTA-34827 - JBC - 190218 
 *   
 *   Helper Class for subscription 
 *   
 */
class SubscriptionDaemon:public ThreadArg
{
    public:
        SubscriptionDaemon(ServiceCfg & serviceCfg, int daemonNumber, char * whereClause, int daemonFrequency, 
            int blockSize, bool keepEvent, int keepDays, int threadNo, int totalThreads, std::string busEntityCd, int commitRetry, int multiThreadMode);
        ~SubscriptionDaemon();

        SubscriptionDaemon             (const SubscriptionDaemon &) = delete;
        SubscriptionDaemon & operator= (const SubscriptionDaemon &) = delete;

        int         getThreadNumber();
		int         getTotalThreadCount();
        void        SUBD_Proceed(ThreadStateCycle & mainThreadState);
        bool        isPrimeThread();
    	bool        isMultiThreadOverride();
		int         getMultiThreadMode();
    	std::string getMultiThreadModeStr();

    private:
        RET_CODE                SUBD_GetLockedMapEvents(DbiConnectionHelper &, std::vector<DBA_DYNFLD_STP> & outLockedEvent, EVENT_STATUS_ENUM status, std::string beCd, ThreadStateCycle & mainThreadState);
        RET_CODE                SUBD_CustomEventSelect(DbiConnectionHelper &, std::vector<DBA_DYNFLD_STP> & outEvent, EVENT_STATUS_ENUM status, ID_T minEventId, DBA_DYNFLD_STP lockedEventStp);
        RET_CODE                SUBD_TreatAllEvents(std::vector<DBA_DYNFLD_STP> & events, ThreadStateCycle & mainThreadState);
        bool                    SUBD_LockEventMap(DbiConnectionHelper &, DBA_DYNFLD_STP  aEvent);
        RET_CODE                SUBD_UnlockEventMap(DbiConnectionHelper &);
        RET_CODE                SUBD_LoadEventsStatus(std::vector<DBA_DYNFLD_STP> & events, std::vector<DBA_DYNFLD_STP> & eventStatus);
        int                     TraceMessage(char *file, int line, ...);
        RET_CODE                SUBD_ChangeAllEventsStatus(DbiConnectionHelper &, std::vector<DBA_DYNFLD_STP> & events, int status, std::vector<DBA_DYNFLD_STP> & eventStatus, bool esonly);
        RET_CODE                SUBD_CheckEventUpdated(ID_T eventId, EVENT_STATUS_ENUM status);
        RET_CODE                SUBD_GetEventCount(DbiConnectionHelper &, int *eventCount, EVENT_STATUS_ENUM status);
        RET_CODE                SUBD_UpdateOpStatus(DbiConnectionHelper &, std::vector<DBA_DYNFLD_STP> & events, std::vector<DBA_DYNFLD_STP> & eventStatus);
        RET_CODE                SUBD_GetOpBusinessKey(DBA_DYNFLD_STP event, char * buffSql, int buffLen);
        RET_CODE                SUBD_PurgeEvents(DbiConnectionHelper &, FusionTimer &);
        RET_CODE                SUBD_DeleteEvent(DbiConnectionHelper &, std::vector<DBA_DYNFLD_STP> &);
        void                    SUBD_AddSubDFreq(const std::string, int daemonFreqSeconds);
        std::map<std::string,FusionTimer *> & SUBD_GetFreqMap();
        void                    SUBD_SetEventBusEntIdx(FIELD_IDX_T index);
        FIELD_IDX_T &           SUBD_GetEventBusEntIdx();
        bool                    SUBD_IsBusEntityValid(std::string &);
        RET_CODE                SUBD_TreatEventsByBlock(std::vector<DBA_DYNFLD_STP> & eventBlock,std::vector<DBA_DYNFLD_STP> & eventStatusBlock, std::string map_path, const bool sendToMercator, size_t & totalCounter, bool & isFatal, ThreadStateCycle & mainThreadState);

        ID_T                    m_serviceId;
        std::string             m_serviceCd;        
        int                     m_daemonNumber;
        std::string             m_whereClause;
        int                     m_daemonFrequency;
        int                     m_blockSize;
        bool                    m_keepEvent;
        int                     m_keepDays;
        int                     m_threadRank;
        int                     m_totalThreads;
        std::map<std::string,FusionTimer *> m_freqByBusEntCd;
        FIELD_IDX_T             m_eventOwnerBusEntIdx;
        std::string             m_singleBusEntityCd;
        int                     m_commitRetryNb; 
    	int                     m_multiThreadMode;
        
};


/************************************************************************
**      External definitions attached to : subdlib.c
*************************************************************************/
#ifdef EXTERN
#undef EXTERN
#endif
#ifdef  SUBDLIB_C
#define EXTERN
#else
#define EXTERN extern
#endif

EXTERN void                         SUBD_Proceed(const int);
EXTERN RET_CODE                     SUBD_SetEventUpdate();
EXTERN RET_CODE                     SUBD_InsEventUpdate();
EXTERN RET_CODE                     SUBD_GetEventUpdate();
EXTERN RET_CODE                     SUBD_GetOpBusinessKey();
EXTERN void                         SUBD_Halt(int, char *, int);
EXTERN RET_CODE                     SUBD_UpdateOneOpStatus(DBA_DYNFLD_STP , DbiConnectionHelper* , DBA_DYNFLD_STP );
EXTERN RET_CODE                     SUBD_UpdateManyOpStatus();
EXTERN FLAG_T	                    SUBD_IsFmtModifStatChanged();                                /* GRD - 002211 - REF5309 */
EXTERN SUBD_RESULT_EVAL_TREE_STP    SUBD_GetTree(ID_T formatId);                                 /* GRD - 002211 - REF5309 */
EXTERN void                         SUBD_StoreTree(ID_T formatId,
                                                   SUBD_RESULT_EVAL_TREE_STP resultEvalTreeStp); /* GRD - 002211 - REF5309 */
EXTERN RET_CODE                     SUBD_ExecFmt(SUBD_RESULT_EVAL_TREE_STP   resultEvalTreePtr,
                                                 DBA_DYNFLD_STP              *resultBaseVal,
                                                 DBA_DYNST_ENUM              inputSt,  
                                                 DBA_DYNFLD_STP              inputData);         /* GRD - 002211 - REF5309 */
EXTERN void SUBD_FreeAllTree();                                                                  /* GRD - 002211 - REF5309 */
EXTERN void SUBD_PrintFmt(SUBD_RESULT_EVAL_TREE_STP resultEvalTreePtr, DBA_DYNFLD_STP resultBaseValPtr);
extern void SUBD_ThreadMain(ThreadArg *);                   /* PMSTA-34827 - JBC - 190218 */


#endif  /* ifndef SUBD_H */
/************************************************************************
**      END  subd.h                                           UNICIBLE
*************************************************************************/

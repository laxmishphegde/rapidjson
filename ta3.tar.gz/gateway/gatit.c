/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#include <exception>

#include "unidef.h"
#include "gen.h"
#include <string>

#ifdef __cplusplus
extern "C"{
#endif

#define BATCHEX_C


#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdarg.h>
#include <time.h>
#include <errno.h>
#ifdef LINUX
#include <sys/time.h>
#endif
#include <limits.h>

#ifdef WIN32
#include <windows.h>
#include <conio.h>
#include <process.h>
#include <sys/timeb.h>
#else
#include <pthread.h>
#include <unistd.h>
#include <dlfcn.h>
#endif


#include <dstxpi.h>


#include "olitapi.h"
#include "olitsign.h"



#ifdef WIN32
#define NODL
#endif

#ifdef NODL
static MPIRC (*_mpiAdapterCreate)(HMPIADAPT *phObject,HMPICARD hCard,MPI_ADAPTER_VTABLE *pvTable) = mpiAdapterCreate;
static MPIRC (*_mpiObjectNewPropColl)(HMPIOBJ hObject,MPIPROP iOffset,int iCount,const int piTypes[]) = mpiObjectNewPropColl;
static MPIRC (*_mpiObjectDestroy)(HMPIOBJ hObject) = mpiObjectDestroy;
static MPIRC (*_mpiConnectionCreate)(HMPICONNECT *phObject,MPI_CONNECTION_VTABLE *pvTable) = mpiConnectionCreate;
static MPIRC (*_mpiPropertyGetObject)(HMPIOBJ hObject,MPIPROP iProperty,int iIndex,HMPIOBJ *phValue) = mpiPropertyGetObject;
static MPIRC (*_mpiStreamGetSize)(HMPISTREAM hStream,size_t *pnSize) = mpiStreamGetSize;
static MPIRC (*_mpiStreamRead)(HMPISTREAM hStream,void *pBuff,size_t nSize,size_t *pnActRead) = mpiStreamRead;
static MPIRC (*_mpiAdaptGetCardObject)(HMPIADAPT hAdapter,HMPICARD *phCard) = mpiAdaptGetCardObject;
static MPIRC (*_mpiCardGetMapObject)(HMPICARD hCard,HMPIMAP *phMap) = mpiCardGetMapObject;
static MPIRC (*_mpiPropertyGetText)(HMPIOBJ hObject,MPIPROP iProperty,int iIndex,const char **ppText,size_t *pnLen) = mpiPropertyGetText;
static MPIRC (*_mpiStreamWrite)(HMPISTREAM hStream,const void *pData,size_t nSize) = mpiStreamWrite;
static MPIRC (*_mpiPropertyGetInteger)(HMPIOBJ hObject,MPIPROP iProperty,int iIndex,int	*piValue) = mpiPropertyGetInteger;
static MPIRC (*_mpiPropertySetText)(HMPIOBJ hObject,MPIPROP iProperty,int iIndex,const char *pText,size_t nLen) = mpiPropertySetText;
static MPIRC (*_mpiPropertySetInteger)(HMPIOBJ hObject,MPIPROP iProperty,int iIndex,int iValue) = mpiPropertySetInteger;
#else
static MPIRC (*_mpiAdapterCreate)(HMPIADAPT *phObject,HMPICARD hCard,MPI_ADAPTER_VTABLE *pvTable) = NULL;
static MPIRC (*_mpiObjectNewPropColl)(HMPIOBJ hObject,MPIPROP iOffset,int iCount,const int piTypes[]) = NULL;
static MPIRC (*_mpiObjectDestroy)(HMPIOBJ hObject) = NULL;
static MPIRC (*_mpiConnectionCreate)(HMPICONNECT *phObject,MPI_CONNECTION_VTABLE *pvTable) = NULL;
static MPIRC (*_mpiPropertyGetObject)(HMPIOBJ hObject,MPIPROP iProperty,int iIndex,HMPIOBJ *phValue) = NULL;
static MPIRC (*_mpiStreamGetSize)(HMPISTREAM hStream,size_t *pnSize) = NULL;
static MPIRC (*_mpiStreamRead)(HMPISTREAM hStream,void *pBuff,size_t nSize,size_t *pnActRead) = NULL;
static MPIRC (*_mpiAdaptGetCardObject)(HMPIADAPT hAdapter,HMPICARD *phCard) = NULL;
static MPIRC (*_mpiCardGetMapObject)(HMPICARD hCard,HMPIMAP *phMap) = NULL;
static MPIRC (*_mpiPropertyGetText)(HMPIOBJ hObject,MPIPROP iProperty,int iIndex,const char **ppText,size_t *pnLen) = NULL;
static MPIRC (*_mpiStreamWrite)(HMPISTREAM hStream,const void *pData,size_t nSize) = NULL;
static MPIRC (*_mpiPropertyGetInteger)(HMPIOBJ hObject,MPIPROP iProperty,int iIndex,int	*piValue) = NULL;
static MPIRC (*_mpiPropertySetText)(HMPIOBJ hObject,MPIPROP iProperty,int iIndex,const char *pText,size_t nLen) = NULL;
static MPIRC (*_mpiPropertySetInteger)(HMPIOBJ hObject,MPIPROP iProperty,int iIndex,int iValue) = NULL;
#endif

#ifdef NODL
static OLI_STATUS (*_AAA_OliInit)(int , char **, AAA_OliContext_STP ) = AAA_OliInit;
static OLI_STATUS (*_AAA_OliClose)(AAA_OliContext_STP ) = AAA_OliClose;
static OLI_STATUS (*_AAA_OliCall)(AAA_OliContext_STP  , char * , long ) = AAA_OliCall;
static OLI_STATUS (*_AAA_OliGet)(AAA_OliContext_STP , AAA_OliChEnum , char * , long ) = AAA_OliGet;
#else
static OLI_STATUS (*_AAA_OliInit)(int , char **, AAA_OliContext_STP ) = NULL;
static OLI_STATUS (*_AAA_OliClose)(AAA_OliContext_STP ) = NULL;
static OLI_STATUS (*_AAA_OliCall)(AAA_OliContext_STP  , char * , long ) = NULL;
static OLI_STATUS (*_AAA_OliGet)(AAA_OliContext_STP , AAA_OliChEnum , char * , long ) = NULL;
#endif

int   LogMessage(char *, int, ...);

OLI_STATUS __AAA_OliInit(int argc, char ** argv, AAA_OliContext_STP context)
{
    OLI_STATUS status = RET_OK;

    try{
        status = _AAA_OliInit(argc, argv, context);
    }
    catch (std::exception &e)
    {
        LogMessage(
            (char *)__FILE__, __LINE__, "__AAA_OliInit: %s", e.what());
 
        status = EXCEPTION_ERROR;
    }

    return status; 
}

OLI_STATUS __AAA_OliClose(AAA_OliContext_STP context)
{
    OLI_STATUS status = RET_OK;

    try{
        status = _AAA_OliClose(context);
    }
    catch (std::exception &e)
    {
        LogMessage(
            (char *)__FILE__, __LINE__, "__AAA_OliClose: %s", e.what());

        status = EXCEPTION_ERROR;
    }

    return status; 
}

OLI_STATUS __AAA_OliCall(AAA_OliContext_STP  context, char * buffer, long size)
{
    OLI_STATUS status = RET_OK;

    try{
        status = _AAA_OliCall(context, buffer, size);
    }
    catch (std::exception &e)
    {
        LogMessage(
            (char *)__FILE__, __LINE__, "__AAA_OliCall: %s", e.what());

        status = EXCEPTION_ERROR;
    }

    return status; 
}

OLI_STATUS __AAA_OliGet(AAA_OliContext_STP context, AAA_OliChEnum channel, char * buffer, long size)
{
    OLI_STATUS status = RET_OK;

    try{
        status = _AAA_OliGet(context, channel, buffer, size);
    }
    catch (std::exception &e)
    {
        LogMessage(
            (char *)__FILE__, __LINE__, "__AAA_OliGet: %s", e.what());

        status = EXCEPTION_ERROR;
    }

    return status; 
}



typedef int BOOL;

typedef struct 
{
	unsigned int msgLen;
	char *message;
} OUTPUT_MESSAGE;

#define TRUE  1
#define FALSE 0
#define CHKERR(rc) if (rc != MPIRC_SUCCESS) goto EXCEPTION;

#ifdef WIN32
static DWORD dwTlsIndex;
#else
static pthread_key_t key;
static pthread_once_t key_once = PTHREAD_ONCE_INIT;

static void make_key()
{
    (void) pthread_key_create(&key, NULL);
}

#endif

#ifdef WIN32
BOOL WINAPI DllMain(HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpvReserved)
{
	LPVOID lpvData;
	BOOL fIgnore;

	switch(fdwReason)
	{
	case DLL_PROCESS_ATTACH:

		// Allocate a TLS index.

		if ((dwTlsIndex = TlsAlloc()) == TLS_OUT_OF_INDEXES) 
			return FALSE; 

		// No break: Initialize the index for first thread.

		// The attached process creates a new thread. 

	case DLL_THREAD_ATTACH: 

		// Initialize the TLS index for this thread.

		lpvData = (LPVOID) LocalAlloc(LPTR, sizeof(OUTPUT_MESSAGE)); 
		if (lpvData != NULL) 
			fIgnore = TlsSetValue(dwTlsIndex, lpvData); 

		break; 

		// The thread of the attached process terminates.

	case DLL_THREAD_DETACH: 

		// Release the allocated memory for this thread.

		lpvData = TlsGetValue(dwTlsIndex); 
		if (lpvData != NULL) 
			LocalFree((HLOCAL) lpvData); 

		break; 

		// DLL unload due to process termination or FreeLibrary. 

	case DLL_PROCESS_DETACH: 

		// Release the allocated memory for this thread.

		lpvData = TlsGetValue(dwTlsIndex); 
		if (lpvData != NULL) 
			LocalFree((HLOCAL) lpvData); 

		// Release the TLS index.

		TlsFree(dwTlsIndex); 
		break; 

	default: 
		break; 
	} 

	return TRUE; 
	UNREFERENCED_PARAMETER(hinstDLL); 
	UNREFERENCED_PARAMETER(lpvReserved); 
}

#endif

MPIRC GatitInitializeLibrary(void);
MPIRC GatitDestroyLibrary(void);
MPIRC GatitCreateAdapterInstance(HMPIADAPT *, HMPICARD);
MPIRC GatitDestroyAdapterInstance(HMPIADAPT);
MPIRC GatitCreateConnectionInstance(HMPICONNECT *);
MPIRC GatitDestroyConnectionInstance(HMPICONNECT);
MPIRC GatitGet(HMPIADAPT, HMPICONNECT);
MPIRC GatitPut(HMPIADAPT, HMPICONNECT);
MPIRC GatitBeginTransaction(HMPIADAPT, HMPICONNECT);
MPIRC GatitEndTransaction(HMPIADAPT, HMPICONNECT, MPITRANS);
MPIRC GatitValidateProperties(HMPIADAPT);
MPIRC GatitCompareConnection(HMPIADAPT, HMPICONNECT, MPICOMP *);
MPIRC GatitOnNotify(HMPIADAPT, int, int, HMPICONNECT);
MPIRC GatitConnect(HMPICONNECT, HMPIADAPT);
MPIRC GatitDisconnect(HMPICONNECT);

void  SetErrorCode(HMPIOBJ, int);

void WriteToOutputFile(char *, char *, int );
int   LogDataTrace(const char *, char *);  /* PMSTA-16755 - 050813 - PMO */
int   LogMessage(char *, int, ...);
int   InitLogFile(char *, int *);
int   LogPerfTrace(const char *, int);     /* PMSTA-16755 - 050813 - PMO */

/*
** This structure defines the number and type of adapter properties.
** It is referenced in CreateAdapterInstance.
*/

static const int GatitAdapterProperties[] =
{
   MPI_PROP_TYPE_TEXT,   /* AP_USERNAME */
   MPI_PROP_TYPE_TEXT,   /* AP_PASSWORD */
   MPI_PROP_TYPE_TEXT,   /* AP_SERVER   */
   MPI_PROP_TYPE_TEXT,   /* AP_CHARSET  */
   MPI_PROP_TYPE_TEXT,   /* AP_MODE     */
   MPI_PROP_TYPE_TEXT,   /* AP_BLOCK    */
   MPI_PROP_TYPE_TEXT    /* AP_OPTI     */
};

#define NUM_ADAPTER_PROPERTIES  sizeof(GatitAdapterProperties)/sizeof(int)

/* Adapter object properties - these should be offset from MPI_PROPBASE_USER */
enum
{
   AP_USERNAME = MPI_PROPBASE_USER,
   AP_PASSWORD,
   AP_SERVER,
   AP_CHARSET,
   AP_MODE,
   AP_BLOCK,
   AP_OPTI
};

/*
** This structure defines the number and type of connection properties
** It is referenced in CreateConnectionInstance.
*/
static const int GatitConnectProperties[] =
{
   MPI_PROP_TYPE_TEXT,   /* CP_USERNAME */
   MPI_PROP_TYPE_TEXT,   /* CP_PASSWORD */
   MPI_PROP_TYPE_TEXT,   /* CP_SERVER   */
   MPI_PROP_TYPE_TEXT,   /* CP_CHARSET  */
   MPI_PROP_TYPE_TEXT,   /* CP_MODE     */
   MPI_PROP_TYPE_TEXT,   /* CP_BLOCK    */
   MPI_PROP_TYPE_TEXT    /* CP_OPTI     */
};
#define NUM_CONNECT_PROPERTIES  sizeof(GatitConnectProperties)/sizeof(int)

/* Connection object properties - these should be offset from MPI_PROPBASE_USER */
enum
{
   CP_USERNAME = MPI_PROPBASE_USER,
   CP_PASSWORD,
   CP_SERVER,
   CP_CHARSET,
   CP_MODE,
   CP_BLOCK,
   CP_OPTI
};

/* Define adapter specific error messages */
#define ERR_E_CANT_CONNECT MAKEUSERERROR(1)

#ifdef WIN32
#define PATH_SEPARATOR '\\'
#else
#define PATH_SEPARATOR '/'
#endif

/******  VTABLE for Gatit adapter  ******/
/*The adapter must export the library virtual table, which must be given the same name as the library, with _config appended.*/
/* https://www.ibm.com/docs/en/ste/10.1.1?topic=adapters-adapter-registration-library-virtual-table */

/* gatit is the name of the library */
MPIEXPORT MPI_LIBRARY_VTABLE gatit_config = 
{
   sizeof(MPI_LIBRARY_VTABLE),                          /* size of this structure */
   GatitInitializeLibrary,                              /*pfInitializeLibrary*/
   GatitDestroyLibrary,                                 /*pfDestroyLibrary*/
   GatitCreateAdapterInstance,                          /*pfCreateAdapterInstance*/
   GatitDestroyAdapterInstance,                         /*pfDestroyAdapterInstance*/
   GatitCreateConnectionInstance,                       /*pfCreateConnectionInstance*/
   GatitDestroyConnectionInstance,                      /*pfDestroyConnectionInstance*/
   NULL,                                                /*pfCombinedListen*/
   NULL,                                                /* Mask of command line arguments defining connection */
   MPI_TRANSACTIONS_SINGLE,                             /* single, multiple or non-transactional */
   MPI_UNITOFWORK_LOGICAL,                              /* Unit of work - message or logical */
   FALSE,                                               /* Does the adapter support listener interface */
   FALSE,                                               /* Does the listener block (needs MPIN_ADAPTER_LISTENABORT) ? */
   FALSE,                                               /* Is the listener transactional (needs BeginTrans) ? */
   FALSE,                                               /* Does the adapter support retries */
                                                    /* Source settings */
   FALSE,                                               /* Should RM manage the source? */
   FALSE,                                               /* Does the adapter return warnings on sources? */
   MPI_SCOPE_MAP,                                       /* Which adapter Scope settings are supported for source? */
   MPI_ACTION_KEEP | MPI_ACTION_DELETE,                 /* Which OnSuccess settings are supported for source? */
   MPI_ACTION_ROLLBACK | MPI_ACTION_COMMIT,             /* Which  OnFailure settings are supported for source? */
   MPI_SCOPE_MAP,                                       /* Default Scope setting for source */
   MPI_ACTION_KEEP,                                     /* Default OnSuccess setting for source */
   MPI_ACTION_ROLLBACK,                                 /* Default OnFailure setting for source */
                                                    /* Target settings */
   FALSE,                                               /* Should RM manage the target? */
   FALSE,                                               /* Does the adapter return warnings on targets? */
   MPI_SCOPE_MAP | MPI_SCOPE_CARD,                      /* Which adapter scope settings are supported for target? *
   MPI_ACTION_CREATE,                                   /* Which OnSuccess settings are supported for target? */
   MPI_ACTION_ROLLBACK | MPI_ACTION_COMMIT,             /* Which  OnFailure settings are supported for target? */
   MPI_SCOPE_MAP,                                       /* Default Scope setting for target */
   MPI_ACTION_CREATE,                                   /* Default OnSuccess setting for target */
   MPI_ACTION_ROLLBACK                                  /* Default OnFailure setting for target */
};

/* The adapter object virtual table */
MPI_ADAPTER_VTABLE GatitAdapterTable =
{
	sizeof(MPI_ADAPTER_VTABLE),
	NULL,
	NULL,
	GatitGet,
	GatitPut,
	GatitBeginTransaction,
	GatitEndTransaction,
	NULL,
	GatitValidateProperties,
	NULL,
	GatitCompareConnection,
	GatitOnNotify
};

/* The connection object virtual table */
MPI_CONNECTION_VTABLE GatitConnectionTable = 
{
   sizeof(MPI_CONNECTION_VTABLE),
   GatitConnect,
   GatitDisconnect
};

/* Gatit specific global variables */
char *passArgv[64];
int nArgv;
AAA_OliContext_STP  localcontext = NULL;

#ifndef WIN32
pthread_mutex_t  gatit_lock = PTHREAD_MUTEX_INITIALIZER;
#else
CRITICAL_SECTION cs;
#endif

/****************************************************************************/
/*                                                                          */
/* Function:    GatitInitializeLibrary                                       */
/*                                                                          */
/* Description: Perform any library initialization that is required.        */
/*                                                                          */
/* Inputs:      None                                                        */
/*                                                                          */
/* Outputs:     None                                                        */
/*                                                                          */
/****************************************************************************/
MPIRC GatitInitializeLibrary(void)
{
   int x = 1;
   MPIRC rc = MPIRC_SUCCESS;

   LogPerfTrace("GatitInitializeLibrary", 0);

#ifdef WIN32
   InitializeCriticalSection( &cs );
#endif

    /* Do any initializition of the DLL here (creating critical sections etc) */
   if(getenv("LIBGATITWAIT"))
   {
      LogMessage((char *)__FILE__, __LINE__, "LIBGATITWAIT found, waiting...");
      while(x)
#ifdef WIN32
          Sleep(5000);
#else
          sleep(5);
#endif
   }

#ifndef WIN32
	  (void) pthread_once(&key_once, make_key);
#endif

#ifndef NODL
   static void *dl = NULL;

   pthread_mutex_lock(&gatit_lock);

   if (dl == NULL)
   {
     const char *name = getenv("LIBDSTXPI");

     if (name == NULL)
       name = "libdstxpi.so";

     if ((dl = dlopen(name, RTLD_NOW)) == NULL)
     {
       LogMessage((char *)__FILE__, __LINE__, "Failed to load LIBDSTXPI.");
       LogMessage((char *)__FILE__, __LINE__, dlerror());

       pthread_mutex_unlock(&gatit_lock);

       return MPIRC_E_3RD_PARTY_FAILED;
     }
     else
     if ((*((void **)(&_mpiAdapterCreate)) = dlsym(dl, "mpiAdapterCreate" )) == NULL ||
         (*((void **)(&_mpiObjectNewPropColl)) = dlsym(dl, "mpiObjectNewPropColl")) == NULL ||
         (*((void **)(&_mpiObjectDestroy)) = dlsym(dl, "mpiObjectDestroy" )) == NULL ||
         (*((void **)(&_mpiConnectionCreate)) = dlsym(dl, "mpiConnectionCreate" )) == NULL ||
         (*((void **)(&_mpiPropertyGetObject)) = dlsym(dl, "mpiPropertyGetObject" )) == NULL ||
         (*((void **)(&_mpiStreamGetSize)) = dlsym(dl, "mpiStreamGetSize" )) == NULL ||
         (*((void **)(&_mpiStreamRead)) = dlsym(dl, "mpiStreamRead" )) == NULL ||
         (*((void **)(&_mpiAdaptGetCardObject)) = dlsym(dl, "mpiAdaptGetCardObject" )) == NULL ||
         (*((void **)(&_mpiCardGetMapObject)) = dlsym(dl, "mpiCardGetMapObject" )) == NULL ||
         (*((void **)(&_mpiPropertyGetText)) = dlsym(dl, "mpiPropertyGetText" )) == NULL ||
         (*((void **)(&_mpiStreamWrite)) = dlsym(dl, "mpiStreamWrite" )) == NULL ||
         (*((void **)(&_mpiPropertyGetInteger)) = dlsym(dl, "mpiPropertyGetInteger" )) == NULL ||
         (*((void **)(&_mpiPropertySetText)) = dlsym(dl, "mpiPropertySetText" )) == NULL ||
         (*((void **)(&_mpiPropertySetInteger)) = dlsym(dl, "mpiPropertySetInteger" )) == NULL)
     {
        LogMessage((char *)__FILE__, __LINE__, "Failed to map functions from LIBDSTXPI.");

        dlclose(dl);
        dl = NULL;

        pthread_mutex_unlock(&gatit_lock);

        return MPIRC_E_3RD_PARTY_FAILED;
     }
     else
       LogMessage((char *)__FILE__, __LINE__, "LIBDSTXPI scucessfully loaded.");
   }   

   pthread_mutex_unlock(&gatit_lock);
#endif

   return rc;
}

/****************************************************************************/
/*                                                                          */
/* Function:    GatitDestroyLibrary                                         */
/*                                                                          */
/* Description: Cleans up any resources allocated by the library.           */
/*                                                                          */
/* Inputs:      None                                                        */
/*                                                                          */
/* Outputs:     None                                                        */
/*                                                                          */
/****************************************************************************/
MPIRC GatitDestroyLibrary(void)
{
   OLI_STATUS OliReturn=RET_OK;

   int i;

   /* Cleanup anything created in GatitInitializeLibrary */
   LogPerfTrace("GatitDestroyLibrary", 0);

   LogPerfTrace("AAA_OliClose", 0);

   OliReturn = __AAA_OliClose(localcontext);

   LogPerfTrace("AAA_OliClose", 1);

   if(ST_ERROR(OliReturn))
   {
      LogMessage((char *)__FILE__, __LINE__, "Cannot close interface, ret code : %d",
         OliReturn);
      return MPIRC_E_3RD_PARTY_FAILED;
   }

   for(i=0; i<nArgv; i++)
      free(passArgv[i]);
   nArgv = 0;

   /* Free localcontext */

   free(localcontext);

   localcontext = NULL;

   return MPIRC_SUCCESS;
}

/****************************************************************************/
/*                                                                          */
/* Function:    GatitCreateAdapterInstance                                  */
/*                                                                          */
/* Description: Create an adapter object for this adapter.  It is here that */
/*              the list of properties is registered.                       */
/*                                                                          */
/* Inputs:      hCard - Card object                                         */
/*                                                                          */
/* Outputs:     phAdapter - Returned adapter object                         */
/*                                                                          */
/****************************************************************************/
MPIRC GatitCreateAdapterInstance (HMPIADAPT *phAdapter,
                                 HMPICARD  hCard)
{
   MPIRC  rc;

   LogPerfTrace("GatitCreateAdapterInstance", 0);

   rc = _mpiAdapterCreate(phAdapter, hCard, &GatitAdapterTable );

   if (rc == MPIRC_SUCCESS)
   {
      /* Define the number and type of adapter properties */
      rc = _mpiObjectNewPropColl(*phAdapter, 
                                MPI_PROPBASE_USER, 
                                NUM_ADAPTER_PROPERTIES, 
                                GatitAdapterProperties);

      /* Do any other initialization of instance of adapter object */
   }
   else
      LogMessage((char *)__FILE__, __LINE__, "Cannot create adapter.");
   return rc;
}

/****************************************************************************/
/*                                                                          */
/* Function:    GatitDestroyAdapterInstance                                 */
/*                                                                          */
/* Description: Frees up any resources used by the adapter object, then     */
/*              destroys the object itself.                                 */
/*                                                                          */
/* Inputs:      hAdapter - Adapter object                                   */
/*                                                                          */
/* Outputs:     None                                                        */
/*                                                                          */
/****************************************************************************/
MPIRC GatitDestroyAdapterInstance(HMPIADAPT hAdapter)
{
   /* Free up any memory or data structures use by the adapter instance */

   LogPerfTrace("GatitDestroyAdapterInstance", 0);

   return(_mpiObjectDestroy(hAdapter));   
}

/****************************************************************************/
/*                                                                          */
/* Function:    GatitCreateConnectionInstance                               */
/*                                                                          */
/* Description: Create a connection object for this adapter.  It is here    */
/*              that the list of properties is registered.                  */
/*                                                                          */
/* Inputs:      None                                                        */
/*                                                                          */
/* Outputs:     phConnection - Connection object                            */
/*                                                                          */
/****************************************************************************/
MPIRC GatitCreateConnectionInstance(HMPICONNECT *phConnection)
{
   MPIRC  rc;

   LogPerfTrace("GatitCreateConnectionInstance", 0);

   rc = _mpiConnectionCreate(phConnection, &GatitConnectionTable);

   if (rc == MPIRC_SUCCESS)
   {
      /* Define the number and type of adapter properties */
      rc = _mpiObjectNewPropColl(*phConnection, 
                                MPI_PROPBASE_USER, 
                                NUM_CONNECT_PROPERTIES, 
                                GatitConnectProperties);

      /* Do any other initialization of instance of connection object */
   }
   else
      LogMessage((char *)__FILE__, __LINE__, "Cannot create connection.");
   return rc;
}

/****************************************************************************/
/*                                                                          */
/* Function:    GatitDestroyConnectionInstance                              */
/*                                                                          */
/* Description: Frees up any resources used by the connection object, then  */
/*              destroys the object itself.                                 */
/*                                                                          */
/* Inputs:      hConnection - Connection object                             */
/*                                                                          */
/* Outputs:     None                                                        */
/*                                                                          */
/****************************************************************************/
MPIRC GatitDestroyConnectionInstance(HMPICONNECT hConnection)
{
   /* Free up any memory or data structures use by the connection instance */

   LogPerfTrace("GatitDestroyConnectionInstance", 0);

   return(_mpiObjectDestroy(hConnection));   
}

char * getUniqueId()
{
    static char uniqueId[64];
#ifdef WIN32
   struct _timeb tp;
	  _ftime(&tp);
   sprintf(uniqueId, "%ld%ld%ld", _getpid(), tp.time, tp.millitm);
#else
   struct timeval tp;
   struct timezone tzp;
   gettimeofday(&tp, &tzp);
   sprintf(uniqueId, "%ld%ld%ld", (long) getpid(), tp.tv_sec, tp.tv_usec);    /* PMSTA-16755 - 050813 - PMO */
#endif
   return uniqueId;
}

/****************************************************************************/
/*                                                                          */
/* Function:    GatitPut                                                    */
/*                                                                          */
/* Description: Gets data from the stream and outputs it.  This function is */
/*              called for output cards or PUT function calls.              */
/*                                                                          */
/* Inputs:      hAdapter - Adapter object                                   */
/*              hConnection - Connection object                             */
/*                                                                          */
/* Outputs:     None                                                        */
/*                                                                          */
/****************************************************************************/
MPIRC	GatitPut(HMPIADAPT   hAdapter,
              HMPICONNECT hConnection)
{
   HMPISTREAM hStream;
   size_t nLen;
   size_t nSize;
   MPIRC  rc = MPIRC_SUCCESS;
   char *copyOfData = NULL;
   long nLengthOfData = 0;
   char *respData = NULL;
   int  lenOfResp = 0;
   char *mapPos, *endLine, *outPos;
   char mapPath[1024], logFilePath[1024], outputFile[1024];
   char Result[4096];
   char *filePath;
   HMPICARD hCard;
   HMPIMAP  hMap;
   char *szMapName;
   OLI_STATUS CallReturn=RET_OK;
   char *mapBaseName;

   LogPerfTrace("GatitPut", 0);

   /* Thread synchronisation */
#ifdef WIN32
   EnterCriticalSection(&cs);
#else
   pthread_mutex_lock(&gatit_lock);
#endif

   /* Get the stream object from which data will be obtained */
   rc = _mpiPropertyGetObject (hAdapter, MPIP_ADAPTER_DATA_TO_ADAPT, 0, &hStream); CHKERR(rc);

   /* get data from stream in the copyOfData buffer in memory */

   _mpiStreamGetSize(hStream, &nSize);
  
   copyOfData = (char *)malloc(nSize+1);

   if(copyOfData == NULL)
   {
      rc = MPIRC_E_ALLOC_FAILED;
      CHKERR(rc);
   }

   _mpiStreamRead(hStream, copyOfData, nSize, &nLen);
   copyOfData[nSize] = '\0';

   /* take out MAP pseudo command */

   mapPath[0] = '\0';

   mapPos = strstr(copyOfData, "MAP");
   if(mapPos != NULL)
   {
      if(mapPos != copyOfData)
      {
         if(*(mapPos-1) == '\n')
         {
            sscanf(mapPos, "%*s %s", mapPath);
            endLine = strstr(mapPos, "\n");
            memmove(mapPos, endLine+1, strlen(endLine)+1);
         }
      }
      else
      {
         sscanf(mapPos, "%*s %s", mapPath);
         endLine = strstr(mapPos, "\n");
         memmove(mapPos, endLine+1, strlen(endLine)+1);
      }
   }

   /* take out OUT pseudo command */

   logFilePath[0] = '\0';
   outPos = strstr(copyOfData, "OUT");
   if(outPos != NULL)
   {
      if(outPos != copyOfData)
      {
         if(*(outPos-1) == '\n')
         {
            sscanf(outPos, "%*s %s", logFilePath);
            endLine = strstr(outPos, "\n");
            memmove(outPos, endLine+1, strlen(endLine)+1);
         }
      }
      else
      {
         sscanf(outPos, "%*s %s", logFilePath);
         endLine = strstr(outPos, "\n");
         memmove(outPos, endLine+1, strlen(endLine)+1);
      }
   }

   /* Send the data to online interface */

   nLengthOfData = (long)strlen(copyOfData);
   
   LogDataTrace("IN ", copyOfData);
   LogPerfTrace("AAA_OliCall", 0);
   CallReturn = __AAA_OliCall(localcontext, copyOfData, nLengthOfData + 1);
   LogPerfTrace("AAA_OliCall", 1);
   
   if(CallReturn != RET_OK)
   {
      LogMessage((char *)__FILE__, __LINE__, "Call to AAA_OliCall failed, ret code:%d",
         CallReturn);
      rc =  MPIRC_E_3RD_PARTY_FAILED;
      CHKERR(rc);
   }

   /* Get the response from online interface */

   LogPerfTrace("AAA_OliGet", 0);
   while(((CallReturn = __AAA_OliGet(localcontext , ( AAA_OliChEnum)Data, Result, 4095))) == RET_OK )
   {
      LogPerfTrace((char *)"AAA_OliGet", 1);

      Result[4095] = '\0';

      LogDataTrace("OUT", Result);

      lenOfResp += strlen(Result);
          
      if(respData == NULL)
         respData = (char *)calloc(lenOfResp + 1 , sizeof(char));
      else
         respData = (char *)realloc(respData, (lenOfResp +1 ) * sizeof(char)); 

      if(respData == NULL)
      {
         rc =  MPIRC_E_ALLOC_FAILED;
         CHKERR(rc);
      }

      strcat(respData, Result);

      LogPerfTrace("AAA_OliGet", 0);
   }

   if(respData == NULL)
   {
      LogMessage((char *)__FILE__, __LINE__, "Cannot read data from interface, ret code:%d", CallReturn);
      rc =  MPIRC_E_3RD_PARTY_FAILED;
      CHKERR(rc);
   }

   /* Send the output to a file */

   if((filePath = getenv("AAA_GATEWAY_OUTPUT")))
   {
      /* get the name of the map */

      rc = _mpiAdaptGetCardObject(hAdapter , &hCard); CHKERR(rc);
      rc = _mpiCardGetMapObject(hCard , &hMap); CHKERR(rc);
      rc = _mpiPropertyGetText(hMap, MPIP_MAP_MAP_NAME, 0, (const char **)&szMapName, &nLen); CHKERR(rc);

      if((mapBaseName = strrchr(szMapName, PATH_SEPARATOR)) != NULL)
         mapBaseName++;
      else
         mapBaseName = szMapName;

      if(logFilePath[0] == '\0')
         strcpy(logFilePath, mapBaseName);

      if(getenv("UNIQUE_OUTPUT") != NULL)
      {
         sprintf(outputFile ,"%s%c%s%s",filePath, PATH_SEPARATOR, logFilePath, getUniqueId());
         WriteToOutputFile(outputFile, respData, 2);
      }
      else
      {
         sprintf(outputFile ,"%s%c%s.output",filePath, PATH_SEPARATOR, logFilePath);
         if(outPos != NULL)
            WriteToOutputFile(outputFile, respData, 1);
         else
            WriteToOutputFile(outputFile, respData, 0);
      }

   }


   /* Store the output also in memory */
   if(getenv("GATITSYNCMSG") != NULL)
   {
	   OUTPUT_MESSAGE *outMsg;

#ifdef WIN32
	   outMsg = (OUTPUT_MESSAGE *)TlsGetValue(dwTlsIndex); 
#else
      if ((outMsg = (OUTPUT_MESSAGE *)pthread_getspecific(key)) == NULL)
      {
          outMsg = (OUTPUT_MESSAGE *)calloc(1, sizeof(OUTPUT_MESSAGE));
         (void) pthread_setspecific(key, (void *)outMsg);
	  }
#endif
	   if(outMsg == NULL)
          LogMessage((char *)__FILE__, __LINE__, "Cannot retrieve thread local storage");
	   else
	   {
		   if(outMsg->msgLen < strlen(respData))
		   {
			   if(outMsg->message == NULL)
				   outMsg->message = (char *)calloc(1, strlen(respData) + 1);
			   else
			      outMsg->message = (char *)realloc((void *)outMsg->message, strlen(respData) + 1);
		   }
		   if(outMsg->message == NULL)
              LogMessage((char *)__FILE__, __LINE__, "Cannot allocate thread local storage");
		   else
		   {
		      strcpy(outMsg->message, respData);
			  outMsg->msgLen = strlen(respData);
		   }
	   }
   }

EXCEPTION:

   if (copyOfData != NULL)
       free(copyOfData);

   if (respData != NULL)
    free(respData);

#ifdef WIN32
   LeaveCriticalSection(&cs);
#else
   pthread_mutex_unlock(&gatit_lock);
#endif

   SetErrorCode (hAdapter, rc);
   return rc;
}

/****************************************************************************/
/*                                                                          */
/* Function:    GatitGet                                                    */
/*                                                                          */
/* Description: Return import messages previously stored in memory          */
/*              by the GatitPut function to the output card                 */
/*                                                                          */
/* Inputs:      hAdapter - Adapter object                                   */
/*              hConnection - Connection object                             */
/*                                                                          */
/* Outputs:     None                                                        */
/*                                                                          */
/****************************************************************************/

MPIRC GatitGet(HMPIADAPT   hAdapter, HMPICONNECT hConnection)
{
   HMPISTREAM hStream;
   MPIRC  rc = MPIRC_SUCCESS;
   OUTPUT_MESSAGE *outMsg;

	/* Get the handle to the stream object */

	rc = _mpiPropertyGetObject (hAdapter, MPIP_ADAPTER_DATA_FROM_ADAPT, 0, &hStream);
	CHKERR(rc);

	if(getenv("GATITSYNCMSG") != NULL)
	{

	/* Send the data */
#ifdef WIN32
       outMsg = (OUTPUT_MESSAGE *)TlsGetValue(dwTlsIndex); 
#else
       outMsg = (OUTPUT_MESSAGE *)pthread_getspecific(key);
#endif

       if(outMsg == NULL)
          LogMessage((char *)__FILE__, __LINE__, "Thread local storage pointer is NULL");
       else
           if(outMsg->msgLen > 0)
	      {
	         rc = _mpiStreamWrite (hStream, outMsg->message, outMsg->msgLen);
		     CHKERR(rc);
	      }
	}
	else
    {
       rc = _mpiStreamWrite (hStream, "GATITSYNCMSG variable not set.", 30);
       CHKERR(rc);
    }

EXCEPTION:

   SetErrorCode (hAdapter, rc);
   return MPIRC_W_END_OF_DATA;
;
}



/****************************************************************************/
/*                                                                          */
/* Function:    WriteToOutputFile                                           */
/*                                                                          */
/* Description: renameFlag = 0 , no OUT keyword, no UNIQUE_OUTPUT           */
/*              renameFlag = 1 , OUT keyword but no UNIQUE_OUTPUT           */
/*              renameFlag = 2 , UNIQUE_OUTPUT                              */
/*                                                                          */
/* Inputs:      fileName                                                    */
/*              dataToWrite                                                 */
/*              renameFlag                                                  */
/*                                                                          */
/* Outputs:     None                                                        */
/*                                                                          */
/****************************************************************************/

void WriteToOutputFile(char *fileName, char *dataToWrite, int renameFlag)
{
   FILE *fp;
   char tempFileName[1024];
   int appendMode = (getenv("GATADAPT_APPEND_MODE") != NULL);
   char *tmpSuffix;

   tmpSuffix = tmpnam(NULL);

   /* no OUT, no UNIQUE_OUTPUT */
   /* append to existing file or create if not exists */ 

   if(renameFlag == 0)    
   {
      strcpy(tempFileName, fileName);
      fp = fopen(tempFileName , "a" );      
      if(fp)
      {
         fputs(dataToWrite, fp);
         fclose(fp);
      }
      else
         LogMessage((char *)__FILE__, __LINE__, "Cannot open file %s(errno=%d)", tempFileName, errno);
   }

   /* OUT, no UNIQUE_OUTPUT */
   /* create unique temporary name */

   if(renameFlag == 1)
   {
      if(appendMode)
      { 
         /* append to destination file */
         fp = fopen(fileName, "a");
         if(fp != NULL)
         {
            fputs(dataToWrite, fp);
            fclose(fp);
         }
         else
            LogMessage((char *)__FILE__, __LINE__, "Cannot open file %s(errno=%d)", fileName, errno);
      }
      else
      {
         sprintf(tempFileName, "%s.%s.tmp", fileName, getUniqueId());
         fp = fopen(tempFileName , "w" ); 
         if(fp == NULL)
            LogMessage((char *)__FILE__, __LINE__, "Cannot open file %s(errno=%d)", fileName, errno);
         else
         {
            fputs(dataToWrite, fp);
            fclose(fp);
            
            /* check if destination file already exists */
            if((fp = fopen(fileName, "r")) != NULL)
            {
               fclose(fp);
               LogMessage((char *)__FILE__, __LINE__, "WARNING: destination file %s already exists, temporary file %s leaved in place.", fileName, tempFileName);
            }
            else
               if(rename(tempFileName, fileName) != 0)
                  LogMessage((char *)__FILE__, __LINE__, "Cannot rename file %s(errno=%d)", tempFileName, errno);
         }
      }
   }

   /* UNIQUE_OUTPUT */
   /* use filename.tmp as temporary file name */

   if(renameFlag == 2)
   {
      sprintf(tempFileName, "%s.tmp", fileName);
      fp = fopen(tempFileName , "w" ); 
      if(fp)
      {
         fputs(dataToWrite, fp);
         fclose(fp);
      }
      else
         LogMessage((char *)__FILE__, __LINE__, "Cannot open file %s(errno=%d)", tempFileName, errno);

      if(rename(tempFileName, fileName) != 0)
         LogMessage((char *)__FILE__, __LINE__, "Cannot rename file %s(errno=%d)", tempFileName, errno);
   }
}

/****************************************************************************/
/*                                                                          */
/* Function:    GatitBeginTransaction                                       */
/*                                                                          */
/* Description: Start a transaction - this is called on an open connection  */
/*              before any get or put calls.  For this adapter there is     */
/*              nothing to do.                                              */
/*                                                                          */
/* Inputs:      hAdapter - Adapter object                                   */
/*              hConnection - Connection object                             */
/*                                                                          */
/* Outputs:     None                                                        */
/*                                                                          */
/****************************************************************************/
MPIRC	GatitBeginTransaction(HMPIADAPT hAdapter,
                           HMPICONNECT hConnection)
{
   LogPerfTrace("GatitBeginTransaction", 0);
   SetErrorCode (hAdapter, MPIRC_SUCCESS);
   return MPIRC_SUCCESS;
}

/****************************************************************************/
/*                                                                          */
/* Function:    GatitEndTransaction                                         */
/*                                                                          */
/* Description: Commit or rollback the transaction.  This is called at the  */
/*              point defined by the card's scope (end of the card, map or  */
/*              burst).                                                     */
/*                                                                          */
/* Inputs:      hAdapter - Adapter object                                   */
/*              hConnection - Connection object                             */
/*              eAction - MPI_ACTION_COMMIT or MPI_ACTION_ROLLBACK          */
/*                                                                          */
/* Outputs:     None                                                        */
/*                                                                          */
/****************************************************************************/
MPIRC	GatitEndTransaction(HMPIADAPT hAdapter,
                         HMPICONNECT hConnection,
                         MPITRANS eAction)
{
   int    iContext;
   int    iOnSuccess;
   MPIRC  rc;

   /* 
   ** If this is output card then close the file.
   ** If input and action is to delete, then do so.
   */

   LogPerfTrace("GatitEndTransaction", 0);

   rc = _mpiPropertyGetInteger(hAdapter, MPIP_ADAPTER_CONTEXT, 0, &iContext); CHKERR(rc);
   rc = _mpiPropertyGetInteger(hAdapter, MPIP_ADAPTER_ON_SUCCESS, 0, &iOnSuccess); CHKERR(rc);

EXCEPTION:

   SetErrorCode (hAdapter, rc);
   return rc;
}

/****************************************************************************/
/*                                                                          */
/* Function:    GatitValidateProperties                                     */
/*                                                                          */
/* Description: Ensure that the properties are valid and consistent.        */
/*                                                                          */
/* Inputs:      hAdapter - Adapter object                                   */
/*                                                                          */
/* Outputs:     None                                                        */
/*                                                                          */
/****************************************************************************/
MPIRC	GatitValidateProperties(HMPIADAPT hAdapter)
{
   size_t nLen;
   char   *lpszCmdLine;
   MPIRC  rc = MPIRC_SUCCESS;
   char separators[]   = " ,\t\n'";
   char *p;
   char tok[256];
   char tmpStr[256];
   int flag;

   LogPerfTrace("GatitValidateProperties", 0);

   /* Thread synchronisation */
#ifdef WIN32
   EnterCriticalSection(&cs);
#else
   pthread_mutex_lock(&gatit_lock);
#endif

   flag = nArgv == 0;
   nArgv = 0;

   /* Set all properties to null */
   rc = _mpiPropertySetText(hAdapter, AP_USERNAME, 0, "", 0); CHKERR(rc);
   rc = _mpiPropertySetText(hAdapter, AP_PASSWORD, 0, "", 0); CHKERR(rc);
   rc = _mpiPropertySetText(hAdapter, AP_SERVER,   0, "", 0); CHKERR(rc);
   rc = _mpiPropertySetText(hAdapter, AP_CHARSET,  0, "", 0); CHKERR(rc);
   rc = _mpiPropertySetText(hAdapter, AP_MODE,     0, "", 0); CHKERR(rc);
   rc = _mpiPropertySetText(hAdapter, AP_BLOCK,    0, "", 0); CHKERR(rc);
   rc = _mpiPropertySetText(hAdapter, AP_OPTI,     0, "", 0); CHKERR(rc);

   /* Get the command line */
   rc = _mpiPropertyGetText(hAdapter, MPIP_ADAPTER_COMMANDLINE, 0, (const char **)&lpszCmdLine, &nLen); CHKERR(rc);

   p = lpszCmdLine;

   rc = _mpiPropertySetText(hAdapter, AP_OPTI, 0, "ENABLE", 6); CHKERR(rc);

   while(*p)
   {
      p += (int)strspn(p, separators);

      if(*p == '\0')
         break; 

      strncpy(tok,  p, (size_t)strcspn(p, separators));
      tok[strcspn(p, separators)] = '\0';

      if((strstr(tok, "gatit") == 0) && strcmp(tok, "DLLImPort")) 
         if (flag)
            passArgv[nArgv++] = strdup(tok);

      if(strncmp(p, "-U", 2) == 0)
      {
         p += 2;
         p += strspn(p, separators);
         strncpy(tmpStr, p, (size_t)strcspn(p, separators));
	      tmpStr[strcspn(p, separators)] = '\0';
         rc = _mpiPropertySetText(hAdapter, AP_USERNAME, 0, tmpStr, strlen(tmpStr)); CHKERR(rc);
         if (flag) 
            passArgv[nArgv++] = strdup(tmpStr);
      }   

      if(strncmp(p, "-P", 2) == 0)
      {
         p += 2;
         p += strspn(p, separators);
         strncpy(tmpStr, p, (size_t)strcspn(p, separators));
	      tmpStr[strcspn(p, separators)] = '\0';
         rc = _mpiPropertySetText(hAdapter, AP_PASSWORD, 0, tmpStr, strlen(tmpStr)); CHKERR(rc);
         if (flag)
            passArgv[nArgv++] = strdup(tmpStr);
      }   

      if(strncmp(p, "-S", 2) == 0)
      {
         p += 2;
         p += strspn(p, separators);
         strncpy(tmpStr, p, (size_t)strcspn(p, separators));
	      tmpStr[strcspn(p, separators)] = '\0';
         rc = _mpiPropertySetText(hAdapter, AP_SERVER, 0, tmpStr, strlen(tmpStr)); CHKERR(rc);
         if (flag)
            passArgv[nArgv++] = strdup(tmpStr);
      }   

      if(strncmp(p, "-J", 2) == 0)
      {
         p += 2;
         p += strspn(p, separators);
         strncpy(tmpStr, p, (size_t)strcspn(p, separators));
	      tmpStr[strcspn(p, separators)] = '\0';
         rc = _mpiPropertySetText(hAdapter, AP_CHARSET, 0, tmpStr, strlen(tmpStr)); CHKERR(rc);
         if (flag)
            passArgv[nArgv++] = strdup(tmpStr);
      }   

      if(strncmp(p, "-M", 2) == 0)
      {
         p += 2;
         p += strspn(p, separators);
         strncpy(tmpStr, p, (size_t)strcspn(p, separators));
	      tmpStr[strcspn(p, separators)] = '\0';
         rc = _mpiPropertySetText(hAdapter, AP_MODE, 0, tmpStr, strlen(tmpStr)); CHKERR(rc);
         if (flag)
            passArgv[nArgv++] = strdup(tmpStr);
      }   

      if(strncmp(p, "-B", 2) == 0)
      {
         p += 2;
         p += strspn(p, separators);
         strncpy(tmpStr, p, (size_t)strcspn(p, separators));
	      tmpStr[strcspn(p, separators)] = '\0';
         rc = _mpiPropertySetText(hAdapter, AP_BLOCK, 0, tmpStr, strlen(tmpStr)); CHKERR(rc);
         if (flag)
            passArgv[nArgv++] = strdup(tmpStr);
      }   

      if(strncmp(p, "-O", 2) == 0)
      {
         p += 2;
         strcpy(tmpStr, "ENABLE");
         rc = _mpiPropertySetText(hAdapter, AP_OPTI, 0, tmpStr, strlen(tmpStr)); CHKERR(rc);
      }   

      p += (int)strcspn(p, separators);
   }

EXCEPTION:

#ifdef WIN32
   LeaveCriticalSection(&cs);
#else
   pthread_mutex_unlock(&gatit_lock);
#endif

   SetErrorCode (hAdapter, rc);
   return rc;
}

/****************************************************************************/
/*                                                                          */
/* Function:    GatitValidateConnection                                     */
/*                                                                          */
/* Description: "Ping" the connection to make sure that it is still valid.  */
/*              This gets called periodically when a connection is to be    */
/*              reused.  The Event Server configuration determines whether  */
/*              this should be called, and if so how frequently.            */
/*                                                                          */
/* Inputs:      hAdapter - Adapter object                                   */
/*              hConnection - Connection object                             */
/*                                                                          */
/* Outputs:     None                                                        */
/*                                                                          */
/****************************************************************************/
MPIRC	GatitValidateConnection(HMPIADAPT   hAdapter, HMPICONNECT hConnection)
{
   MPIRC rc = MPIRC_SUCCESS;


   LogPerfTrace("GatitValidateConnection", 0);

   /* Try to see if libolit is still there */

   return rc;
}

/****************************************************************************/
/*                                                                          */
/* Function:    GatitCompareConnection                                      */
/*                                                                          */
/* Description: Compare the properties of the connection with those of the  */
/*              adapter.  The connection is an existing, open connection.   */
/*              The adapter object is one which has not yet been associated */
/*              with a connection object.  If this call returns             */
/*              MPI_CMP_EQUAL then this connection will be used for this    */
/*              adapter object.                                             */
/*                                                                          */
/* Inputs:      hAdapter - Adapter object                                   */
/*              hConnection - Connection object                             */
/*                                                                          */
/* Outputs:     peComp - MPI_CMP_*                                          */
/*                                                                          */
/****************************************************************************/
MPIRC	GatitCompareConnection(HMPIADAPT   hAdapter,
                            HMPICONNECT hConnection,
                            MPICOMP     *peComp)
{
   char   *lpszUsernameNew;
   char   *lpszPasswordNew;
   char   *lpszServerNew;
   char   *lpszCharsetNew;
   char   *lpszModeNew;
   char   *lpszBlockNew;
   char   *lpszOptiNew;
   char   *lpszUsernameCurr;
   char   *lpszPasswordCurr;
   char   *lpszServerCurr;
   char   *lpszCharsetCurr;
   char   *lpszModeCurr;
   char   *lpszBlockCurr;
   char   *lpszOptiCurr;
   size_t nLen;
   int    bActive;
   int    rc;

   LogPerfTrace("GatitCompareConnection", 0);

   rc = _mpiPropertyGetInteger(hConnection, MPIP_CONNECTION_INUSE, 0, &bActive); CHKERR(rc);

   if (!bActive)
      *peComp = MPI_CMP_LESS;
   else
      *peComp = MPI_CMP_EQUAL;

   return MPIRC_SUCCESS;


   /*
   ** The connection is the same if the command line is the same
   */

   rc = _mpiPropertyGetText(hConnection, CP_USERNAME, 0, (const char **)&lpszUsernameCurr, &nLen); CHKERR(rc);
   rc = _mpiPropertyGetText(hConnection, CP_PASSWORD, 0, (const char **)&lpszPasswordCurr, &nLen); CHKERR(rc);
   rc = _mpiPropertyGetText(hConnection, CP_SERVER, 0, (const char **)&lpszServerCurr, &nLen); CHKERR(rc);
   rc = _mpiPropertyGetText(hConnection, CP_CHARSET, 0, (const char **)&lpszCharsetCurr, &nLen); CHKERR(rc);
   rc = _mpiPropertyGetText(hConnection, CP_MODE, 0, (const char **)&lpszModeCurr, &nLen); CHKERR(rc);
   rc = _mpiPropertyGetText(hConnection, CP_BLOCK, 0, (const char **)&lpszBlockCurr, &nLen); CHKERR(rc);
   rc = _mpiPropertyGetText(hConnection, CP_OPTI, 0, (const char **)&lpszOptiCurr, &nLen); CHKERR(rc);


   rc = _mpiPropertyGetText(hAdapter, AP_USERNAME, 0, (const char **)&lpszUsernameNew, &nLen); CHKERR(rc);
   rc = _mpiPropertyGetText(hAdapter, AP_PASSWORD, 0, (const char **)&lpszPasswordNew, &nLen); CHKERR(rc);
   rc = _mpiPropertyGetText(hAdapter, AP_SERVER, 0, (const char **)&lpszServerNew, &nLen); CHKERR(rc);
   rc = _mpiPropertyGetText(hAdapter, AP_CHARSET, 0, (const char **)&lpszCharsetNew, &nLen); CHKERR(rc);
   rc = _mpiPropertyGetText(hAdapter, AP_MODE, 0, (const char **)&lpszModeNew, &nLen); CHKERR(rc);
   rc = _mpiPropertyGetText(hAdapter, AP_BLOCK, 0, (const char **)&lpszBlockNew, &nLen); CHKERR(rc);
   rc = _mpiPropertyGetText(hAdapter, AP_OPTI, 0, (const char **)&lpszOptiNew, &nLen); CHKERR(rc);



   if ((rc = strcmp(lpszUsernameCurr, lpszUsernameNew)) != 0)
   {
      *peComp = rc < 0 ? MPI_CMP_LESS : MPI_CMP_GREATER;
      return MPIRC_SUCCESS;
   }

   if ((rc = strcmp(lpszPasswordCurr, lpszPasswordNew)) != 0)
   {
      *peComp = rc < 0 ? MPI_CMP_LESS : MPI_CMP_GREATER;
      return MPIRC_SUCCESS;
   }

   if ((rc = strcmp(lpszServerCurr, lpszServerNew)) != 0)
   {
      *peComp = rc < 0 ? MPI_CMP_LESS : MPI_CMP_GREATER;
      return MPIRC_SUCCESS;
   }

   if ((rc = strcmp(lpszCharsetCurr, lpszCharsetNew)) != 0)
   {
      *peComp = rc < 0 ? MPI_CMP_LESS : MPI_CMP_GREATER;
      return MPIRC_SUCCESS;
   }

   if ((rc = strcmp(lpszModeCurr, lpszModeNew)) != 0)
   {
      *peComp = rc < 0 ? MPI_CMP_LESS : MPI_CMP_GREATER;
      return MPIRC_SUCCESS;
   }

   if ((rc = strcmp(lpszBlockCurr, lpszBlockNew)) != 0)
   {
      *peComp = rc < 0 ? MPI_CMP_LESS : MPI_CMP_GREATER;
      return MPIRC_SUCCESS;
   }

   if ((rc = strcmp(lpszOptiCurr, lpszOptiNew)) != 0)
   {
      *peComp = rc < 0 ? MPI_CMP_LESS : MPI_CMP_GREATER;
      return MPIRC_SUCCESS;
   }

   /* Everything matches!  The file can be shared */
   *peComp = MPI_CMP_EQUAL;

EXCEPTION:

   return rc;
}

/****************************************************************************/
/*                                                                          */
/* Function:    GatitOnNotify                                               */
/*                                                                          */
/* Description: An entry point to perform initialization for listeners,     */
/*              sources or targets.  The starts and stops are called        */
/*              before/after all calls to get, put or listen.               */
/*                                                                          */
/* Inputs:      hAdapter - Adapter object                                   */
/*              iID - the event                                             */
/*              iParam - not used.                                          */
/*              hConnection - Connection object                             */
/*                                                                          */
/* Outputs:     None                                                        */
/*                                                                          */
/****************************************************************************/
MPIRC	GatitOnNotify(HMPIADAPT hAdapter,
                   int iID,
                   int iParam,
                   HMPICONNECT hConnection)
{
   LogPerfTrace("GatitOnNotify", 0);

   switch (iID)
   {
   case MPIN_ADAPTER_GETSTART:	 /* Prior to any Get calls for the card */
      break;
   case MPIN_ADAPTER_GETSTOP:		 /* After all Get calls for the card */
      break;
   case MPIN_ADAPTER_PUTSTART: 	 /* Prior to any Put calls for the card */
      break;
   case MPIN_ADAPTER_PUTSTOP:		 /* After all Put calls for the card */
      break;
   case MPIN_ADAPTER_LISTENSTART: /* Prior to any Listen calls for the card */
      break;
   case MPIN_ADAPTER_LISTENSTOP:	 /* After all Listen calls for the card */
      break;
   case MPIN_ADAPTER_LISTENABORT: /* Called to abort a non-polling listener */
      break;
   case MPIN_ADAPTER_MAPABORT:    /* Called to notify that map has been aborted */
      break;
   default:
      break;
   }

   SetErrorCode (hAdapter, MPIRC_SUCCESS);
   return MPIRC_SUCCESS;
}

/****************************************************************************/
/*                                                                          */
/* Function:    GatitConnect                                                */
/*                                                                          */
/* Description: Connect to the resource and store the connection context    */
/*              in the connection object.                                   */
/*                                                                          */
/* Inputs:      hAdapter - Adapter object                                   */
/*              hConnection - Connection object                             */
/*                                                                          */
/* Outputs:     None                                                        */
/*                                                                          */
/****************************************************************************/
MPIRC	GatitConnect(HMPICONNECT hConnection,
                  HMPIADAPT hAdapter)
{
   size_t nLen;
   int    iContext;
   MPIRC  rc;
   char   *lpszUsername;
   char   *lpszPassword;
   char   *lpszServer;
   char   *lpszCharset;
   char   *lpszMode;
   char   *lpszBlock;
   char   *lpszOpti;
   OLI_STATUS OliReturn=RET_OK;
   int    i;

   LogPerfTrace("GatitConnect", 0);

   /* Thread synchronisation */
#ifdef WIN32
   EnterCriticalSection(&cs);
#else
   pthread_mutex_lock(&gatit_lock);
#endif

#ifndef WIN32
   static void *dl = NULL;

   if (dl == NULL)
   {
     const char *name = getenv("LIBOLIT");

     if (name == NULL)
       name = "libolit.so";

     if ((dl = dlopen(name, RTLD_NOW)) == NULL)
     {
       LogMessage((char *)__FILE__, __LINE__, "Failed to load LIBOLIT.");
       LogMessage((char *)__FILE__, __LINE__, dlerror());

       pthread_mutex_unlock(&gatit_lock);

       return MPIRC_E_3RD_PARTY_FAILED;
     }
     else
     if ((*((void **)(&_AAA_OliInit )) = dlsym(dl, "AAA_OliInit" )) == NULL ||
         (*((void **)(&_AAA_OliClose)) = dlsym(dl, "AAA_OliClose")) == NULL ||
         (*((void **)(&_AAA_OliCall )) = dlsym(dl, "AAA_OliCall" )) == NULL ||
         (*((void **)(&_AAA_OliGet  )) = dlsym(dl, "AAA_OliGet" )) == NULL)
     {
       LogMessage((char *)__FILE__, __LINE__, "Failed to map functions from LIBOLIT.");

       dlclose(dl);
       dl = NULL;

      pthread_mutex_unlock(&gatit_lock);

      return MPIRC_E_3RD_PARTY_FAILED;
     }
     else
       LogMessage((char *)__FILE__, __LINE__, "LIBOLIT scucessfully loaded.");
   }
#endif

   /* Context says where the call is coming from */
   rc = _mpiPropertyGetInteger(hAdapter, MPIP_ADAPTER_CONTEXT, 0, &iContext); CHKERR(rc);
   if (iContext == MPI_CONTEXT_SOURCE_EVENT)
   {
      /*
      ** If this is a source event, we can't use the concept of a connection -
      ** See GatitGet for more explanation
      */

#ifdef WIN32
         LeaveCriticalSection(&cs);
#else
          pthread_mutex_unlock(&gatit_lock);
#endif

      SetErrorCode (hConnection, MPIRC_SUCCESS);
      return MPIRC_SUCCESS;
   }

   /* Allocate localcontext and connect to online inetrface */

   if(localcontext == NULL)
   {
      localcontext = (AAA_OliContext_ST *)calloc(1, sizeof(AAA_OliContext_ST));
      if(localcontext == NULL)
	  {
         LogMessage((char *)__FILE__, __LINE__, "Failed to allocate local context.");

#ifdef WIN32
         LeaveCriticalSection(&cs);
#else
          pthread_mutex_unlock(&gatit_lock);
#endif

          return MPIRC_E_ALLOC_FAILED;
	  }

   /* Connect to libolit */

      LogPerfTrace("AAA_OliInit", 0);

      for(i=0; i<nArgv; i++)
         LogDataTrace("ARG", passArgv[i]);

      OliReturn = __AAA_OliInit( nArgv , passArgv , localcontext);

      LogPerfTrace("AAA_OliInit", 1);

      if(ST_ERROR(OliReturn))
	  {
         LogMessage((char *)__FILE__, __LINE__, "Cannot init interface, ret code : %d",
            OliReturn );

#ifdef WIN32
         LeaveCriticalSection(&cs);
#else
          pthread_mutex_unlock(&gatit_lock);
#endif
 
          return MPIRC_E_3RD_PARTY_FAILED;
	  }
   }

   /* Copy all properties from adatper to connection */
   rc = _mpiPropertyGetText(hAdapter, AP_USERNAME, 0, (const char **)&lpszUsername, &nLen); CHKERR(rc);
   rc = _mpiPropertyGetText(hAdapter, AP_PASSWORD, 0, (const char **)&lpszPassword, &nLen); CHKERR(rc);
   rc = _mpiPropertyGetText(hAdapter, AP_SERVER, 0, (const char **)&lpszServer, &nLen); CHKERR(rc);
   rc = _mpiPropertyGetText(hAdapter, AP_CHARSET, 0, (const char **)&lpszCharset, &nLen); CHKERR(rc);
   rc = _mpiPropertyGetText(hAdapter, AP_MODE, 0, (const char **)&lpszMode, &nLen); CHKERR(rc);
   rc = _mpiPropertyGetText(hAdapter, AP_BLOCK, 0, (const char **)&lpszBlock, &nLen); CHKERR(rc);
   rc = _mpiPropertyGetText(hAdapter, AP_OPTI, 0, (const char **)&lpszOpti, &nLen); CHKERR(rc);
  
   rc = _mpiPropertySetText(hConnection, CP_USERNAME, 0, lpszUsername, strlen(lpszUsername)); CHKERR(rc);
   rc = _mpiPropertySetText(hConnection, CP_PASSWORD, 0, lpszPassword, strlen(lpszPassword)); CHKERR(rc);
   rc = _mpiPropertySetText(hConnection, CP_SERVER, 0, lpszServer, strlen(lpszServer)); CHKERR(rc);
   rc = _mpiPropertySetText(hConnection, CP_CHARSET, 0, lpszCharset, strlen(lpszCharset)); CHKERR(rc);
   rc = _mpiPropertySetText(hConnection, CP_MODE, 0, lpszMode, strlen(lpszMode)); CHKERR(rc);
   rc = _mpiPropertySetText(hConnection, CP_BLOCK, 0, lpszBlock, strlen(lpszBlock)); CHKERR(rc);
   rc = _mpiPropertySetText(hConnection, CP_OPTI, 0, lpszOpti, strlen(lpszOpti)); CHKERR(rc);

EXCEPTION:

#ifdef WIN32
         LeaveCriticalSection(&cs);
#else
          pthread_mutex_unlock(&gatit_lock);
#endif

   SetErrorCode (hConnection, rc);
   return rc;
}

/****************************************************************************/
/*                                                                          */
/* Function:    GatitDisconnect                                             */
/*                                                                          */
/* Description: Disconnect from the resource.                               */
/*                                                                          */
/* Inputs:      hConnection - Connection object                             */
/*                                                                          */
/* Outputs:     None                                                        */
/*                                                                          */
/****************************************************************************/
MPIRC	GatitDisconnect(HMPICONNECT hConnection)
{
   MPIRC rc = MPIRC_SUCCESS;
   LogPerfTrace("GatitDisconnect", 0);
   return rc;
}


/****************************************************************************/
/*                                                                          */
/* Function:    SetErrorCode                                                */
/*                                                                          */
/* Description: Sets the error code and message properties of the object.   */
/*                                                                          */
/* Inputs:      hObject - object in error (adapter or connection)           */
/*              iRC     - the return code to set in the object              */
/*                                                                          */
/* Outputs:     None                                                        */
/*                                                                          */
/****************************************************************************/
void SetErrorCode(HMPIOBJ hObject, int iRC)
{
   int  i;
   const char *lpszMsg = NULL;                /* PMSTA-16755 - 050813 - PMO */
   struct
   {
      int  rc;
      const char *szErrMsg;
   } stErrors[] = 
   {
      MPIRC_SUCCESS,      "Success",
      ERR_E_CANT_CONNECT, "Failed to connect",
   };
   #define NUM_ERRORS (sizeof(stErrors)/sizeof(stErrors[0]))
   
   for (i = 0;  i < NUM_ERRORS;  i++)
   {
      if (0 != (iRC = stErrors[i].rc))        /* PMSTA-16755 - 050813 - PMO */
      {
         lpszMsg = stErrors[i].szErrMsg;
         break;
      }
   }

   if (lpszMsg == NULL)
   {
      lpszMsg = "Failure";
   }

   _mpiPropertySetInteger(hObject, MPIP_OBJECT_ERROR_CODE, 0, iRC);
   _mpiPropertySetText(hObject, MPIP_OBJECT_ERROR_MSG, 0, lpszMsg, strlen(lpszMsg));
}


/****************************************************************************/
/*                                                                          */
/* Some log functions.                                                      */
/*                                                                          */
/*                                                                          */
/****************************************************************************/

#ifdef HPUX
#define LIBPATH       "SHLIB_PATH"
#elif defined SOLARIS
#define LIBPATH       "LD_LIBRARY_PATH"
#elif defined WIN32
#define LIBPATH       "PATH"
#else
#define LIBPATH       "LIBPATH"
#endif

int InitLogFile(char *logFileName, int *debugLevel)
{
   char *debugLevelText;
   char *aaaMsg;
   FILE *fp;
   const char *envVars[9] = {"AAAHOME", "AAABIN", "AAALOGINDB", "AAAMSG", 
                       "SYBASE", "DSQUERY", LIBPATH, "AAA_GATEWAY_OUTPUT",
                       "UNIQUE_OUTPUT" };           /* PMSTA-16755 - 050813 - PMO */
   int i;

   debugLevelText = getenv("DEBUG_GATADAPT");
   if(debugLevelText != NULL)
   {
      *debugLevel = atoi(debugLevelText);
      if(*debugLevel < 0)
         *debugLevel = 0;
      if(*debugLevel > 9)
         *debugLevel = 9;
   }

   strcpy(logFileName, "gatit.log");
   aaaMsg = getenv("AAAMSG");

   if(aaaMsg != NULL)
   {
      if(strlen(aaaMsg) < 1014)
      {
         sprintf(logFileName, "%s%c", aaaMsg, PATH_SEPARATOR);
         strcat(logFileName, "gatit.log");
      }
   }

   remove(logFileName);

   fp = fopen(logFileName, "a+");
   if(fp == NULL)
      return 1;

   fprintf(fp, "Libgatit Log File\n");
   fprintf(fp, "-----------------\n");
   fprintf(fp, "Set DEBUG_GATADAPT for full logging.\n");
   fprintf(fp, "------------------------------------\n");
   fprintf(fp, "Current environment variables:\n");
   fprintf(fp, "------------------------------\n");

   for(i=0; i<9; i++)
   {
      fprintf(fp, "%s : ", envVars[i]);
      if(getenv(envVars[i]))
         fprintf(fp, "%s", getenv(envVars[i]));
      fprintf(fp, "\n");
   }

   fclose(fp);
   return 0;
}


int LogMessage(char *file, int line, ...)
{
   va_list ap;
   char *format;
   time_t currTime;
   struct tm localTime;
   char timeStamp[128];
   FILE *fp;
   static int firstTime = 1;
   static int debugLevel = 0;
   static char logFileName[1024];
   static long pid, tid, rolitProgram;

   if(firstTime)
   {
      firstTime = 0;
      InitLogFile(logFileName, &debugLevel);
   }

   currTime = time(0L);
#ifdef WIN32
   localTime = * localtime(&currTime);
#else
   localtime_r(&currTime, &localTime);
#endif
   sprintf(timeStamp, "%02d-%02d-%04d %02d:%02d:%02d ", localTime.tm_mday,
      localTime.tm_mon + 1, localTime.tm_year + 1900,
      localTime.tm_hour, localTime.tm_min, localTime.tm_sec);

#ifdef WIN32
	  pid = _getpid();
	  tid = GetCurrentThreadId();
#else
	  pid = getpid();
	  tid = pthread_self();
#endif
	  rolitProgram = 0x20002000;
	  if(getenv("ROLIT_PROGRAM") != NULL)
		  rolitProgram = atol(getenv("ROLIT_PROGRAM"));

   va_start(ap, line);

   fp = fopen(logFileName, "a+");
   if(fp == NULL)
      return 1;

   fprintf(fp, "-------------------------\n");
   fprintf(fp, "Time:    %s\n", timeStamp);
   fprintf(fp, "File:    %s Line: %d\n", file, line);
   fprintf(fp, "Pid:0x%08lx Tid:0x%08lx Rolit:0x%08lx\n", pid, tid, rolitProgram);    /* PMSTA-16755 - 050813 - PMO */
   fprintf(fp, "Message: ");
   format = va_arg(ap, char *);
   vfprintf(fp, format, ap); 
   fprintf(fp, "\n");
 
   fclose(fp);

   va_end(ap);
   return 0;
}

int LogDataTrace(const char *direction, char *stringToLog)                           /* PMSTA-16755 - 050813 - PMO */
{
   time_t          currTime;
   struct tm       localTime;
   char            timeStamp[1024];

   FILE           *fp;
   static char     logFileName[1024];
   static int      firstTime = 1;
   static int      activated = 0;
   long            pid;


#ifdef WIN32
   struct _timeb   timeMs;
#else
   struct timeval  timeMs;
   struct timezone tzp;
#endif

   if (firstTime) {
      firstTime = 0;
      if (getenv("GATITDUMPTRACE") != NULL) {
         strcpy(logFileName, getenv("GATITDUMPTRACE"));
         activated = 1;
      }
   }
   if (activated == 0)
      return 0;

   currTime = time(0L);


#ifdef WIN32
   localTime = *localtime(&currTime);
   _ftime(&timeMs);
   pid = _getpid();
   sprintf(timeStamp, "%02d/%02d/%04d %02d:%02d:%02d.%d", localTime.tm_mday,
      localTime.tm_mon + 1, localTime.tm_year + 1900,
      localTime.tm_hour, localTime.tm_min, localTime.tm_sec,
      timeMs.millitm);
#else
   localtime_r(&currTime, &localTime);
   gettimeofday(&timeMs, &tzp);
   pid = getpid();
   sprintf(timeStamp, "%02d/%02d/%04d %02d:%02d:%02d.%ld", localTime.tm_mday,        /* PMSTA-16755 - 050813 - PMO */
      localTime.tm_mon + 1, localTime.tm_year + 1900,
      localTime.tm_hour, localTime.tm_min, localTime.tm_sec,
      timeMs.tv_usec);
#endif


   fp = fopen(logFileName, "a+");
   if (fp == NULL)
      return 1;

   fprintf(fp, "%s - %06ld - %s - %s\n", timeStamp, pid, direction, stringToLog);    /* PMSTA-16755 - 050813 - PMO */

   fclose(fp);

   return 0;
}

int LogPerfTrace(const char *funcName, int action)         /* PMSTA-16755 - 050813 - PMO */
{
   time_t currTime;
   struct tm localTime;
   char timeStamp[1024];

   FILE *fp;
   static char logFileName[1024];
   static int firstTime = 1;
   char *aaaMsg;
   static double startTime, stopTime;
   static int activated = 0;
   static long pid, tid, rolitProgram;


#ifdef WIN32
	struct _timeb tpStart, tpStop;
#else
   struct timeval tpStart, tpStop;
   struct timezone tzp;
#endif

   
   if(firstTime)
   {
      if(getenv("GATITPERFTRACE") == NULL)
	  {
		  activated = 0;
		  firstTime = 0;
		  return 0;
	  }

      activated = 1;
      firstTime = 0;

      strcpy(logFileName, "gatitstat.log");
      aaaMsg = getenv("AAAMSG");

      if(aaaMsg != NULL)
      {
         if(strlen(aaaMsg) < 1014)
         {
            sprintf(logFileName, "%s%c", aaaMsg, PATH_SEPARATOR);
            strcat(logFileName, "gatitstat.log");
         }
      }
   }

   if(activated == 0)
      return 0;


   currTime = time(0L);
#ifdef WIN32
   localTime = * localtime(&currTime);
#else
   localtime_r(&currTime, &localTime);
#endif

   if(action == 0)
   {
#ifdef WIN32
      _ftime(&tpStart);
      startTime = (double)tpStart.time + (double)tpStart.millitm / 1000.0;
#else
      gettimeofday(&tpStart, &tzp);
      startTime = (double)tpStart.tv_sec + (double)tpStart.tv_usec / 1000000.0;
#endif
	  stopTime = startTime;
   }

   if(action == 1)
   {
#ifdef WIN32
      _ftime(&tpStop);
      stopTime = (double)tpStop.time + (double)tpStop.millitm / 1000.0;
#else
      gettimeofday(&tpStop, &tzp);
      stopTime = (double)tpStop.tv_sec + (double)tpStop.tv_usec / 1000000.0;
#endif
   }

#ifdef WIN32
	  pid = _getpid();
	  tid = GetCurrentThreadId();
#else
	  pid = 111;;
	  tid = 222;
#endif
	  rolitProgram = 0x20002000;
	  if(getenv("ROLIT_PROGRAM") != NULL)
		  rolitProgram = atol(getenv("ROLIT_PROGRAM"));

   sprintf(timeStamp, "%02d-%02d-%04d %02d:%02d:%02d %32.32s %9.5lf", localTime.tm_mday,
   localTime.tm_mon + 1, localTime.tm_year + 1900,
   localTime.tm_hour, localTime.tm_min, localTime.tm_sec, funcName, stopTime - startTime);

   fp = fopen(logFileName, "a+");
   if(fp == NULL)
      return 1;

   fprintf(fp, "0x%08lx 0x%08lx 0x%08lx ", pid, tid, rolitProgram);   /* PMSTA-16755 - 050813 - PMO */
   fprintf(fp, "%s\n", timeStamp);
   fclose(fp);

   return 0;
}

/* Function used only to obtain gatit version with a string command. Never called*/
void GetVersionFunc()
{
   printf("Gateway version : %s\n", AAAVersion::getVersion().getfullVersionInfo().c_str());
}


#ifdef __cplusplus
}
#endif

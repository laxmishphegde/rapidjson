/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**
**              Copyright (C) 1993-1994 by UNICIBLE
**                       All Rights Reserved
**
**                   Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define SUBD_C

/************************************************************************
**      Includes
*************************************************************************/

#define	 STDIO_H
#define	STDLIB_H
#define	STRING_H
#define	UNISTD_H
#define	SIGNAL_H
#define	SETJMP_H

#include <unidef.h>	/* Mandatory */
#include <sig.h>
#include <scptyl.h>
#include <subd.h>
#include <syslib.h>
#include <gen.h>
#include <dba.h>
#include <date.h>
#include <csrv.h>
#include "merclib.h"

#include "crypto.h"
#include "crypto-openssl.h"
#include "password.h"
#include "aaalogger.h"
#include "aaatelemetry.h"


/************************************************************************
**      Constants
*************************************************************************/

/************************************************************************
**      Macro Definitions
*************************************************************************/

/************************************************************************
**      Type  Definitions
*************************************************************************/

/************************************************************************
**      Declarations
*************************************************************************/
extern PTR      EV_ExtractFileTimerPtr;
extern void     MSG_InitLogFileName(const char *);
extern char     *SV_LogFileName;
// extern char     SV_ApplName[]; /* replace SV_ApplName by GEN_GetApplName() - FME- 190129 */
extern FLAG_T   SV_IsSubdApplFlg;

/************************************************************************
**      Global Functions
**
**  main()              Import Interface Entry Point
**
*************************************************************************/

/************************************************************************
**      Static Functions
**
**  SUBD_GetOption()
**  SUBD_Handler()
**  SUBD_Startup()
**  SUBD_Shutdown()
**
*************************************************************************/

STATIC int  SUBD_GetOption(int, char **);
STATIC void SUBD_Handler(int);
STATIC int  SUBD_Startup(char *);
STATIC void SUBD_Shutdown(bool);
       void SUBD_LogRejected(DBA_DYNFLD_STP);
       void SUBD_LogSucceed(DBA_DYNFLD_STP);

/************************************************************************
**      Static Data Definitions
*************************************************************************/

static int  SV_ServerMode = FALSE;
static int  SV_ServerInitFlg = TRUE;
static char SV_User[MAX_USERINFO_LEN +1];

static Atomic<ThreadState>  SV_ThreadSubDMain(ThreadState::Initialization);

// static jmp_buf SV_JumpBuffer;
CODE_T      EV_DbTimeZoneCd="";       /* PMSTA-30817 - DDV - 180501 */



/************************************************************************
**      Global Data Definitions
*************************************************************************/

int    *EV_ServerMode       = &SV_ServerMode;
int     EV_OptiMemFlg       = FALSE;
int     EV_TestNewScpt      = 1;
int     EV_GuiActivatedFlg  = 0;
int    *EV_ServerInitFlg    = &SV_ServerInitFlg;
int     EV_MaxEventsByBlock = 0;    /* DLA - PMSTA-29227 - 171117 */
int     EV_NumberOfThreads  = 1;
FLAG_T *EV_IntIsSubdApplFlg = &SV_IsSubdApplFlg;
char    SV_SuccFile[1024];
char    SV_RejectFile[1024];
int    EV_DaemonNumber     = 0;
char   *EV_WhereFile       = NULL;
char   *EV_AttFileName     = NULL;
char   *EV_RegistryFile    = NULL;
int  EV_DaemonFrequency  = 0;
ID_T    EV_serviceId = ZERO_ID;
std::string EV_SingleBusinessEntityCd;
int  EV_MultiThreadMode = 0;	/* PMSTA-66218 - JBC - 20250221 */

class InterruptedException : public std::exception
{
};

/************************************************************************
**      Static Function Definitions
*************************************************************************/


/************************************************************************
**
**  Function    :   SUBD_GetOption()
**
**  Description :   analyse command line parameters
**
**  Argument    :   argc
**                  argv
**
**  Return      :   0 on success, -1 elsewhere
**                  1 for exit request
**
*************************************************************************/
STATIC int SUBD_GetOption(int argc, char **argv)
{
	int     i;
	char    *p = (char*) NULL,
                nextArgv = 0;

	*SV_User = END_OF_STRING;

	/* For all parameters */
	for (i=1; i<argc ; i++)
	{
		if (!nextArgv && *argv[i] == '-')
		{
			if(argv[i][2] == END_OF_STRING)
			{
				nextArgv = argv[i][1];

				if (nextArgv == 'W')
					EV_WarningMsg = TRUE;
                else if (nextArgv == 'v')
                {
                    GEN_AnalyseVersion(nextArgv);
                    return 1;
                }
                else if (nextArgv == 'V')
				{
                        GEN_AnalyseVersion(nextArgv);
						               }
				else
					continue;
			}
			else    p = &argv[i][2];
		}
		else    p = argv[i];

		switch((nextArgv)?nextArgv:*(p-1))
		{
            case 'U' :
	            strcpy(SV_User, p);
                SYS_SetThreadUser(SV_User);
	            break;
            case 'P' :
            {
                PasswordEncrypted pE;
                pE.setClearPassword(PasswordClear(p));
                GEN_SetUserInfo(UserPasswd, &pE);
            }
            break;
            case 'd' :
                EV_DaemonNumber = atoi(p);
				            break;
            case 'f' :
                EV_DaemonFrequency = atoi(p);
	            break;
            case 'h' :
                EV_WhereFile = p;
                break;

            case 'a' :
                EV_AttFileName = p;
                break;

            case 'r' :
                EV_RegistryFile = p;
                break;

            case 'J':
	            if (GEN_SetCurCharset(p, CharsetCodeType_Rdbms, CharsetCodeNoCtx, EV_RdbmsVendor) != RET_SUCCEED)
                return -1;
                break;

            case 'K' : /* Output file charset */
                if (GEN_SetCurCharset(p, CharsetCodeType_Icu, CharsetCodeCtx_Output, EV_RdbmsVendor) != RET_SUCCEED)
                    return -1;
                if(strcmp(p, "cp850")  == 0 ||
                   strcmp(p, "cp437")  == 0 ||
                   strcmp(p, "roman8") == 0 ||
                   strcmp(p, "mac")    == 0)
                {
                    printf("Invalid output charset %s\n", p);
                    return -1;
                }
                break;

            case 'c' :  /*  Business Entity as input parameter  */  /*  HFI-PMSTA-26560-170806  */
                EV_SingleBusinessEntityCd = p;
                break;

            case 'B':  /* DLA - PMSTA-29227 - 171117 */
                EV_MaxEventsByBlock = atoi(p);
                break;

             case 'T':  /* PMSTA-34827 - JBC - 190218 */
                EV_NumberOfThreads = atoi(p);
                break;

            case 'C': /* DLA - PMSTA-28581 - 171201 */
                SYS_LoadCfgFile(p);
                break;

            case 'n': /* PMSTA-41113 - KNI - 270720 */
            {
                std::string serviceName = DBI_GetSqlServerName(std::string(SYS_GetoptArg()));
                break;
            }

             case 'M' :		/* PMSTA-66218 - JBC - 20250221 */
                EV_MultiThreadMode = atoi(p);
	            break;
	    }
	    nextArgv = 0;
	}

    PasswordEncrypted * pE = nullptr;
	GEN_GetUserInfo(UserPasswd, &pE);
    if (SV_User[0] == END_OF_STRING)
    {
        strcpy(SV_User, SYS_GetThreadUser().c_str());
    }

	if (*SV_User && (pE->isValidPassword() == false))
	{
        RET_CODE ret_code = SYS_AutoLogin(SV_User, *pE);

        if (ret_code == RET_SUCCEED)
        {
		    GEN_SetUserInfo(UserPasswd, pE);
        }
        else
        {
		    SYSNAME_T pwd;
		    AUTO_PASSWORD_CLEAR(pwd, sizeof(pwd));
		    SYS_GetPassword("Password", pwd, MAX_USERINFO_LEN + 1, 0);
		    pE->setClearPassword(PasswordClear(pwd));
		    GEN_SetUserInfo(UserPasswd, pE);
        }
	}

#ifdef AIX
	if (argc > 1)
		*argv[1] = '\0';
#endif

    if (*SV_User == END_OF_STRING || pE->isValidPassword() == false)
        return -1;

    return 0;
}

/************************************************************************
**
**  Function    :   SUBD_Handler()
**
**  Description :	catch SIGINT signal
**
**  Argument    :   signum
**
*************************************************************************/
STATIC void SUBD_Handler(int signum)
{
    if (signum == SIGINT)
    {
        signal(SIGINT, SIG_IGN);

        /*
           Since Mercator is multithreaded, the thread receiving the signal
           is not guaranted to be the one that executed the setjump or catch
           the exception. This lead the process to abnormal termination.
           So, in the wait to improve the termination code, let SUBD_HALT
           terminate the process
         */

        //longjmp(SV_JumpBuffer, 1);
        //throw InterruptedException();

        SUBD_HALT(signum);
    }
    else
    {
        SUBD_HALT(signum);
    }
}

/************************************************************************
**
**  Function    :   SUBD_Halt()
**
**  Description :
**
**  Argument    :   code
**                  file
**                  line
**
**  Last modif. : PMSTA-16293 - 210513 - PMO : Update source code - fix build
**
*************************************************************************/
void SUBD_Halt(int code, char *file, int line)
{
     // handled by a signal handler : code is limited cf : https://en.cppreference.com/w/cpp/utility/program/signal 

	std::cout << "Stopping 'Subscription' daemon notified, code is : " << code << " Will be handled within SUBSCRIPTION_DAEMON_FREQ sec..." << std::endl;

    SV_ThreadSubDMain.store(ThreadState::Leaving);
    SYS_SetProgramState(ProgramState::StartShutdown); /* PMSTA-47004 - FME - 20211116 */

}


/************************************************************************
**
**  Function    :   SUBD_Startup()
**
**  Description :	connection to server and usual initialisations
**
**  Argument    :   user
**                  password
**
**  Return      :   0 on success, -1 elsewhere
**
**  Last modif. : PMSTA-18094 - 130514 - PMO : Avoid extracting the user credentials from the GUI running on Windows (via dump, etc.)
**                PMSTA-35739 - 140519 - PMO : ThreadCleanupConnection does nothing in subd, import, GUI
**
*************************************************************************/
STATIC int SUBD_Startup(char *user)
{
    const std::string initialDirectory = SYS_GetCurrentDir();
    int status = 0;

    if (GEN_Initial() == RET_SUCCEED)
    {
        SYS_ChangeDir(initialDirectory.c_str());

        if (CSRV_Init(false) == RET_SUCCEED)  /* PMSTA-18094 - 130514 - PMO */
        {
            PasswordEncrypted *pE = nullptr;
            GEN_GetUserInfo(UserPasswd, &pE);

            if (GEN_AppLogin(user, *pE)       != RET_SUCCEED ||  /* PMSTA-18094 - 130514 - PMO */
                DBA_InitDictInfo()            != RET_SUCCEED ||
                DBA_LoadingTabInMemory()      != RET_SUCCEED ||
                DBA_CurrenciesMapInit()       != RET_SUCCEED)    /* REF5248 - RAK - 001005 */
            {
                status = -1;
            }
            else
            {
                DBA_LoadAndCheckDbTimeZone(false);          /* PMSTA-30187 - DDV - 180501 */
                (void)GEN_InitPoolConnectionFinal();        /* PMSTA-24563 - LJE - 160831 */
                SYS_StartThreadGeneralCallback();           /* PMSTA-35739 - 140519 - PMO */
                SYS_SetProgramState(ProgramState::Running); /* PMSTA-35739 - 140519 - PMO */
            }
        }
        else 
        {
            status = -1;
        }
    }
    else 
    {
        status = -1;
    }

    if (LoadDescFile(EV_AttFileName))
    {
        MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "Cannot load description file.");
        return -1;
    }

    return status;
}

/************************************************************************
**
**  Function    :   SUBD_Shutdown()
**
**  Description :   disconnect from Sybase
**
**  Argument    :   none
**
**  Return      :   none
**
**  Last modif. :   PMSTA-35739 - 140519 - PMO : ThreadCleanupConnection does nothing in subd, import, GUI
**
*************************************************************************/
STATIC void SUBD_Shutdown(bool isItxInit)
{
    SYS_SetProgramState(ProgramState::ShutdownThreadTerminating);   /* PMSTA-35739 - 140519 - PMO */
    SYS_StopThreadGeneralCallback();                                /* DLA - PMSTA-25639 - 170323 */
    if(isItxInit)													/* PMSTA-66218 - JBC - 20250221 */
    {
	     MERC_Shutdown();
    }   
    std::stringstream ss;
    ss << "Shutting down Subscription Daemon ";
    if(EV_DaemonNumber > 0)
    {
        ss << EV_DaemonNumber;
    }
   
	const AAALogger& logger = AAALogger::get(AAALogger::Logger::Application); /*PMSTA-58803 - ROH - 20240812*/
	logger.info(ss.str().c_str());



}

/************************************************************************
**      Global Function Definitions
*************************************************************************/


/************************************************************************
*   Function             : initCallback()
*
*   Description          : No special initialization at this level for the GUI
*
*   Arguments            : None
*
*   Functions call       : None
*
*   Return               : None
*
*   Creation Date        : PMSTA-19735 - 020415 - PMO : OpenServer / P1 / Thread handling
*
*   Last Modif.          : PMSTA-24076 - 180716 - PMO : Unstable connections
*
*************************************************************************/
void initCallback()
{
    SYS_SetCallBackThreadDataCtxGeneric(GEN_ThreadDataCtxGenericCreate
                                       ,GEN_ThreadDataCtxGenericAllocate
                                       ,GEN_ThreadDataCtxGenericInit
                                       ,GEN_ThreadDataCtxGenericPrepareApplicationData      /* PMSTA-24076 - 180716 - PMO */
                                       ,GEN_ThreadDataCtxGenericCleaningApplicationData     /* PMSTA-24076 - 180716 - PMO */
                                       ,GEN_ThreadDataCtxGenericDestroy);
}

/************************************************************************
**
**  Function    :   SUBD_ThreadMain()
**
**  Description :   Threaded Entry Point
**
**  Arguments   :   SUBD_THREAD_ARG_ST
**
**  Return      :
**
**  Last modif. :
**
*************************************************************************/
void SUBD_ThreadMain(ThreadArg * _threadArg)
{
    ThreadStateCycle threadStateCycle(SV_ThreadSubDMain);
    auto *    subDaemon     = dynamic_cast<SubscriptionDaemon *>(_threadArg);

    threadStateCycle.setRunning();

    /* this loop only runs once it either fails or exists gracefully */
    while(threadStateCycle.isRunning())
   {

        signal(SIGINT, SUBD_Handler);
        try
        {
            subDaemon->SUBD_Proceed(threadStateCycle);
        }
        catch (InterruptedException)
        {
            printf("interrupted\n");
        }

        if(SV_ThreadSubDMain.load() <= ThreadState::Running)
			SV_ThreadSubDMain.store(ThreadState::Leaving);

    }

}

/************************************************************************
**
**  Function    :   SUBD_CheckStopFile()
**
**  Description :   checks if the file system has a stop file indicating to kill
*                   the threads or the programm state has changed e.g by the signal handler SUBD_Halt
**
**  Arguments   :   removeFile - will delete file after finding use in main not threads
**
**  Return      :
**
**  Last modif. :  PMSTA-47004 - FME - 20211116 
*************************************************************************/
int SUBD_CheckStopFileOrStopState(bool removeFile)
{
    char tmpStr[1024];
    char daemonNbr[10];
    FILE *tmpFile;
    char *aaaHome;

    if (removeFile == false && (SYS_GetProgramState() > ProgramState::Running || SV_ThreadSubDMain.load() > ThreadState::Running))
    {
        return 1;
    }

    /* check if subdstop file exists and then stop the pumping */
    if ((aaaHome = SYS_GetEnv("AAAHOME")) != NULL)
    {
        daemonNbr[0] = '\0';
        if (EV_DaemonNumber > 0)
        {
            sprintf(daemonNbr, "%d", EV_DaemonNumber);
        }
#ifdef UNIX
        sprintf(tmpStr ,"%s/%s%s", aaaHome, "SUBDSTOP", daemonNbr);
#else
        sprintf(tmpStr, "%s\\%s%s", aaaHome, "SUBDSTOP", daemonNbr);
#endif
        tmpFile = fopen(tmpStr, "r");
        if (tmpFile)
        {
            fclose(tmpFile);
            if(removeFile)
            {
                remove(tmpStr);
            }
            SV_ThreadSubDMain.store(ThreadState::Leaving);  /* PMSTA-61685 - JBC - 20241112 */
            return 1;
        }
    }
    return 0;
}


/************************************************************************
**
**  Function    :   main()
**
**  Description :   Entry Point
**
**  Arguments   :
**
**  Return      :
**
*************************************************************************/
int main (int argc, char *argv[])
{
    int ret = 0;
    char                    *hideArgsFlg = nullptr;
    char                    *startupParam = nullptr;
    std::string             logFileName;
    char	                strBuf[512];
    char                    subdMsgPath[256];
    std::string             fileToOpen;
    FILE                    *queryFile;
    MemoryPool              mp;
    char                    *whereClause = nullptr;
    FLAG_T                  keepEvtFlg = FALSE;
    INT_T                   keepEvtDays = 0;
    INT_T                   subdTimeoutSecs = 0;

#ifndef _DEBUG
    try
    {
#endif
        AAALogger::Initializer loggerInit;          /* PMSTA-32895 - 140918 - FME Cluster Logger */
        GEN_ForceApplName("aaa_subd");                           /* PMSTA-54809 - 20231102 - FME Opentelemetry Log4cplus log appender */
        AAATelemetry::Initializer telemetryInitializer(/*startByDefault*/false);        /* PMSTA-40903 - 20200715 - FME Opentracing support */
        AaaMetaDict::load();

        initCallback();

        if(!SYS_CreateMainThreadDataStorage())
        {
            ret = 1;
        }

        int		actualArgNbr = 0;
        char	**actualArgTab = NULL;

        /* Read arguments in environment variable according to HIDE_ARGS value */
        if ((hideArgsFlg = SYS_GetEnv("HIDE_ARGS")) != NULL && strcmp(hideArgsFlg, "1") == 0 &&
            (startupParam = SYS_GetEnv("AAA_STARTUP_PARAMS")) != NULL)
        {
            /* Cut startupParam in argNbr and copy in argTab */
            if (GEN_TreatStartupParams(startupParam, argv, &actualArgNbr, &actualArgTab, mp) == FALSE)
            {
                return(0);
            }
        }
        else
        {
            actualArgNbr = argc;
            actualArgTab = argv;
        }

        OpenSSLProvider::setup();
        PasswordEncrypted::setup(SYS_GetIt);

        /* Send to GetOption */
        if ((ret = SUBD_GetOption(actualArgNbr, actualArgTab)) != 0)
        {
            if (ret == 1)
                return 0;

            fprintf(stderr,
                "usage: subd [-W] [-v] [-V] [-J <charset>] [-n <db service name>] -U <user> -P <password> -d <daemon_number> -h <where_clause> -A <attfile> [-c <business entity> ... ]\n"
                "       with  <-W>       : turn on warning messages logging             \n"
                "             <-v>       : display the application version              \n"
                "             <-V>       : display environment variables                \n"
                "             <-J>       : server charset, a valid character set. (iso_1, roman_8, ...).\n"
                "             <-n>       : DB Service Name for connecting to DB         \n"
                "             <-d>       : the number of this daemon \n"
                "             <-f>       : the execution frequency of this daemon \n"
                "             <-h>       : the name of the file containing a sql where condition. (-d must != 0)\n"
                "             <-K>       : output charset, iso_1, iso_5, iso_8, utf8.\n"
                "             <-a>       : alternative attribute description file\n"
                "             <-c>       : Business Entity (only use with multi-entity configuration)  \n"
                "             <-B>       : maximum number of events in an output block (0 = no max)\n" /* DLA - PMSTA-29227 - 171117 */
                "             <-T>       : Number of threads to launch. Threads by Map and Business Entity (T > 0) \n" /* PMSTA-34827 - JBC - 190218 */
                "             <-M>       : Thread Mode: 0 = Default. Events by Map/Entity ordered by creation_d. \n" /* PMSTA-66218 - JBC - 20250221 */            										
                "                                       NOTE: non-default modes with Temenos consultation only.\n"
                "                                       1 = Untreated Events by map/entity unordered. Parallel worker threads (T > 1).  \n"
                "                                                                       \n"
                "       and   <charset>  : Database charset                             \n"
                "             <user>     : SQL Server Username                          \n"
                "             <password> : SQL Server Password                          \n"
                "             <business entity> : Business entity to use                  ");
            return 1;
        }

         /* Initialize the locks table
          * PMSTA-19736 - 030315 - PMO
          */
        if (SYS_InitLockTable() != TRUE)
        {
            MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "SYS_InitLockTable() failed");
            return(1);
        }

        CURRENTCHARSETCODE_ENUM charsetCode = CurrentCharsetCode_IsNull;
        *EV_IntIsSubdApplFlg = TRUE;
        EV_WarningMsg = FALSE;

        GEN_SetApplInfo(ApplCurrentCharsetCodeEnum, &charsetCode);

        loggerInit.configure(true /*startWatcherThread*/);          /* PMSTA-32895 - 140119 - FME Cluster Logger */
        telemetryInitializer.configure();                              /* PMSTA-40903 - 20200715 - FME Opentracing support */


        DbiConnectionHelper dbiConnHelper;

        /* Startup meta dict etc */
        if (SUBD_Startup(SV_User))
        {
            fprintf(stderr, "subd: initialisation error (see log file)\n");
            return 1;
        }


       /*
        * Manage log file.
        * It is better to use a different log file for the daemon.
        *
        * The log file path could be:
        *      - AAASUBDMSG.
        *      - AAAMSG.
        *      - Current directory.
        */

        GEN_GetApplInfo(ApplDaemonLogFile, logFileName);
            if(EV_DaemonNumber != 0)
        {
            logFileName += SYS_Stringer(EV_DaemonNumber);
        }
        MSG_InitLogFileName(logFileName.c_str());

        if (SYS_GetEnv("AAASUBDMSG") == NULL)
        {
            if(SYS_GetEnv("AAAMSG"))
            {
                MSG_OpenMsgFile(SYS_GetEnv("AAAMSG"));
                strcpy(subdMsgPath, SYS_GetEnv("AAAMSG"));
            }
            else
            {
                MSG_OpenMsgFile((char *)".");
                strcpy(subdMsgPath, ".");
            }
        }
        else
        {
            MSG_OpenMsgFile(SYS_GetEnv("AAASUBDMSG"));
            strcpy(subdMsgPath, SYS_GetEnv("AAASUBDMSG"));
        }

        sprintf(strBuf, "Starting Subscription Daemon ( %s )", AAAVersion::getVersion().getfullVersionInfo().c_str());
      
		const AAALogger& logger = AAALogger::get(AAALogger::Logger::Application);  /*PMSTA-58803 - ROH - 20240812*/  
		logger.info(strBuf);


        /* Load query file */
        if(EV_DaemonNumber)
        {
            char msgText[512];
            long fLen;
            queryFile = fopen(EV_WhereFile, "r");
            if(queryFile == NULL)
            {
	            sprintf(msgText, "Cannot load or bad format of query file: %s", EV_WhereFile);
                MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, msgText);
	            SUBD_Shutdown(false);
	            return 1;
            }

            if(fseek(queryFile, 0, SEEK_END) != 0)
            {
	            sprintf(msgText, "Cannot fseek query file: %s", EV_WhereFile);
                MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, msgText);
	            SUBD_Shutdown(false);
	            return 1;
            }

            fLen = ftell(queryFile);
            if(fLen < 0)
            {
	            sprintf(msgText, "Cannot ftell query file: %s", EV_WhereFile);
                MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, msgText);
	            SUBD_Shutdown(false);
	            return 1;
            }

            if(fseek(queryFile, 0, SEEK_SET) != 0)
            {
	            sprintf(msgText, "Cannot fseek query file: %s", EV_WhereFile);
                MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, msgText);
	            SUBD_Shutdown(false);
	            return 1;
            }

            whereClause = (char *)CALLOC(fLen + 1, sizeof(char));
            if (whereClause == (char *)NULL)
            {
                MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
	            SUBD_Shutdown(false);
                return 1;
            }

            if(fread(whereClause, 1, (unsigned int)fLen, queryFile) != (unsigned int)fLen)
            {
	            sprintf(msgText, "Cannot read query from file: %s", EV_WhereFile);
                MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, msgText);
	            SUBD_Shutdown(false);
	            return 1;
            }

            whereClause[fLen] = '\0';
            fclose(queryFile);
        }
        else
        {
            whereClause = (char *)CALLOC(1, sizeof(char));
            sprintf(whereClause,"");
        }

        /* Initializing Mercator API */

        if (MERC_Startup(EV_RegistryFile))
        {
            return 1;
        }

        /*
         * Manage the 'keep event' flag.
         * (By default this flag is set to 'False').
         */

        GEN_GetApplInfo(ApplDaemonKeepTreatedEventsFlag, &keepEvtFlg);
        GEN_GetApplInfo(ApplDaemonKeepEventInterval, &keepEvtDays);
        std::stringstream oss;
        oss << "Event keep flag mode is set to " << (keepEvtFlg == TRUE ? "Yes." : "No.");
        if(keepEvtDays > 0)
        {
            oss <<  " Events will be purged after " << keepEvtDays << " days.";
        }

       

		logger.info(oss.str().c_str()); /*PMSTA-58803 - ROH - 20240812*/

        /*
         * Manage the 'succeded records file'.
         */

        GEN_GetApplInfo(ApplDaemonSucceededRecFile, fileToOpen);

        if (fileToOpen.length() > 0)
        {
            sprintf(SV_SuccFile, "%s/%s", subdMsgPath, fileToOpen.c_str());
            sprintf(strBuf, "Events successfully sent to Mercator are logged into %s", SV_SuccFile);
            logger.info(strBuf); /*PMSTA-58803 - ROH - 20240812*/
        }
        else
        {
            SV_SuccFile[0] = '\0';
         	logger.info("Events successfully sent to Mercator will not be logged into a file"); /*PMSTA-58803 - ROH - 20240812*/

        }

        /*
         * Manage the 'rejected records file'.
         */
        GEN_GetApplInfo(ApplDaemonRejectedRecFile, fileToOpen);

        if (fileToOpen.length() > 0)
        {
            sprintf(SV_RejectFile, "%s/%s", subdMsgPath, fileToOpen.c_str());
            sprintf(strBuf, "Events rejected by Mercator are logged into %s", SV_RejectFile);
            logger.info(strBuf); /*PMSTA-58803 - ROH - 20240812*/
        }
        else
        {
            SV_RejectFile[0] = '\0';
           	logger.info("Events rejected by Mercator will not be logged into a file"); /*PMSTA-58803 - ROH - 20240812*/

        }

        signal(SIGINT, SUBD_Handler);

        
        GEN_GetApplInfo(ApplSubscriptionDaemonTimeout, &subdTimeoutSecs);
        if(subdTimeoutSecs <= 0)
        {
            subdTimeoutSecs = 180;
        }

        /* Create Service */
        DBA_DYNFLD_STP aServiceConfig = mp.allocDynst(FILEINFO,A_ServiceConfig);
        SET_ENUM(aServiceConfig,A_ServiceConfig_NatEn,ServiceCfgNat_SubcriptionDaemon);
        SET_INT(aServiceConfig,A_ServiceConfig_TimeoutSec,subdTimeoutSecs);
        SET_FLAG_FALSE(aServiceConfig,A_ServiceConfig_AsyncFlg);
        std::string be;        
        if(GEN_IsMultiEntity())
        {
            be.append(" BusEntityCd [").append(EV_SingleBusinessEntityCd.empty() ? "All" : EV_SingleBusinessEntityCd).append("]");
        }
        SET_VARSTRING1000(aServiceConfig,A_ServiceConfig_ServiceInfo,SYS_Stringer("Subscription Daemon [",EV_DaemonNumber,"] Threads[", EV_NumberOfThreads, "] Blocks[", EV_MaxEventsByBlock,"]",be).c_str());

        ServiceCfg serviceCfg(aServiceConfig, false);
       
	    int commitRetryNb  = 0;        
        if(GEN_GetApplInfo(ApplSubscriptionCommitRetry, &commitRetryNb) != TRUE || commitRetryNb <= 0)
        {
            commitRetryNb = 10;
        }
		
        std::vector<SubscriptionDaemon *> subDaemons;

        for(int i=0;i<EV_NumberOfThreads;i++)
        {
            subDaemons.push_back(new SubscriptionDaemon(serviceCfg, EV_DaemonNumber, whereClause, EV_DaemonFrequency,
                EV_MaxEventsByBlock, keepEvtFlg, keepEvtDays, i+1, EV_NumberOfThreads,EV_SingleBusinessEntityCd,commitRetryNb,EV_MultiThreadMode));
        }

        for(int i=0;i<EV_NumberOfThreads;i++)
        {
            std::ostringstream locOss;
            locOss << "SUBD_ThreadMain";

            if (EV_DaemonNumber != 0 || EV_NumberOfThreads > 1)
            {
                locOss << EV_DaemonNumber << "_" << i+1;
            }

            subDaemons[i]->m_ownedByCaller = true;

            if (SYS_SpawnAdministrativeThread(SUBD_ThreadMain, subDaemons[i], locOss.str().c_str() ) == 0 )
			{
				(void)MSG_SendMesg(RET_SRV_LIB_ERR_GENERAL, 0, FILEINFO,
                    SYS_Stringer("Start of the Subscription Daemon ", EV_DaemonNumber," thread ",i+1," failed").c_str());
                break;
			}

            if(i==0)
            {   /* wait to start subsequent threads */
                SYS_MilliSleep(5000);
            }
        }

        /* let threads start */
        SYS_MilliSleep(5000);
        int retryCount = 0;

        /*
         * make sure threads start
         * then poll for a stop file
         */
        while(retryCount < 3)
        {
            if(SYS_GetThreadRunningCounter() == 0 && SV_ThreadSubDMain.load() <= ThreadState::Running)
            {
                retryCount++;
                SYS_MilliSleep(5000);
            }
            else if(SUBD_CheckStopFileOrStopState(false) != 0 || ThreadState::Leaving == SV_ThreadSubDMain.load() || ThreadState::Stopped == SV_ThreadSubDMain.load())
            {
                break;
            }
            else
            {
                for(int i=0;i<10 && ThreadState::Leaving != SV_ThreadSubDMain.load() && ThreadState::Stopped != SV_ThreadSubDMain.load();i++)
                {
                    SYS_MilliSleep(1000);
                }               
            }
        }

        /* cleanup */
		serviceCfg.stopAdminThread();	/* PMSTA-66218 - JBC - 20250221 */
        SYS_MilliSleep(500);
        SUBD_CheckStopFileOrStopState(true);
        SUBD_Shutdown(true);
        SYS_FreeMainThreadDataStorage(ret);


#ifndef _DEBUG
    }
    catch(...)
    {
        if (SYS_IsStateLoggingAllowed())                    /* PMSTA-36212 - 160719 - PMO */
        {
            exceptionHandler(FILEINFO, MSG_SendMesg);
        }
        else
        {
            exceptionHandler(FILEINFO, MSG_SendStderr);     /* PMSTA-36212 - 160719 - PMO */
        }
    }
#endif

    return ret;
}


/************************************************************************
**
**  Function    :   SUBD_LogSucceed()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
*************************************************************************/
void SUBD_LogSucceed(DBA_DYNFLD_STP event)
{
    DATETIME_ST    creationDate;
    DATETIME_ST    currentDate;
    DATETIME_ST    executionDate;
    HOUR_T         currHour, createHour, execHour;
    MINUTE_T       currMinute, createMinute, execMinute;
    SECOND_T       currSecond, createSecond, execSecond;
    YEAR_T         currYear, createYear, execYear;
    MONTH_T        currMonth, createMonth, execMonth;
    DAY_T          currDay, createDay, execDay;
    FILE           *fp;

    char *	  SV_hostName = GET_SYSNAME(event, A_Event_Hostname);
    char *	  SV_user = GET_SYSNAME(event, A_Event_User);	/* DLA - PMSTA09887 - 101115 */
    char *	  SV_entSqlName = GET_SYSNAME(event, A_Event_EntSqlName);
    char *	  SV_fctSqlName = GET_SYSNAME(event, A_Event_FctSqlName);
    char *	  SV_updStsName = GET_NAME(event, A_Event_UpdateStsName);
    char *	  SV_mapStorage = GET_NOTE(event, A_Event_MapStorage);
    char *	  SV_evtData = GET_TEXT(event, A_Event_Data);

    if (SV_SuccFile[0] == '\0')
    {
        return;
    }

    fp = fopen(SV_SuccFile, "a");
    if (fp == NULL)
    {
        MSG_SendMesg(RET_FILE_ERR_OPEN, 1, FILEINFO, SV_SuccFile);
        return;
    }

    DATE_CurrentDateTime(&currentDate);
    TIME_Get(currentDate.time, &currHour, &currMinute, &currSecond);
    DATE_Get(currentDate.date, &currYear, &currMonth, &currDay);

    creationDate = GET_DATETIME(event, A_Event_CreationDate);
    executionDate = GET_DATETIME(event, A_Event_ExecutionDate);

    TIME_Get(creationDate.time, &createHour, &createMinute, &createSecond);
    DATE_Get(creationDate.date, &createYear, &createMonth, &createDay);
    TIME_Get(executionDate.time, &execHour, &execMinute, &execSecond);
    DATE_Get(executionDate.date, &execYear, &execMonth, &execDay);

    fprintf(fp,
            "SUCCEED %2d/%2d/%04d %2d:%2d:%2d\n"
            "EVENT   %" szFormatId" %s %s %d %d %s %s %d %d %2d/%2d/%04d %2d:%2d:%2d %2d/%2d/%04d " /* DLA - PMSTA08801 - 100616 */
            "%2d:%2d:%2d %s %s\n"
            "DATA    %s\n",
            currMonth, currDay, currYear, currHour, currMinute, currSecond,
            GET_ID(event, A_Event_Id),
            (SV_hostName == (char *)NULL) ? "NULL" : SV_hostName,
            (SV_user == (char *)NULL) ? "NULL" : SV_user,
            GET_ENUM(event, A_Event_StatusEn),
            GET_ENUM(event, A_Event_NatureEn),
            (SV_entSqlName == (char *)NULL) ? "NULL" : SV_entSqlName,
            (SV_fctSqlName == (char *)NULL) ? "NULL" : SV_fctSqlName,
            GET_ENUM(event, A_Event_ActionEn),
            GET_ENUM(event, A_Event_ModuleEn),
            createMonth, createDay, createYear, createHour, createMinute, createSecond,
            execMonth, execDay, execYear, execHour, execMinute, execSecond,
            (SV_updStsName == (char *)NULL) ? "NULL" : SV_updStsName,
            (SV_mapStorage == (char *)NULL) ? "NULL" : SV_mapStorage,
            (SV_evtData == (char *)NULL) ? "NULL" : SV_evtData);

    fclose(fp);
}

/************************************************************************
**
**  Function    :   SUBD_LogRejected()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
*************************************************************************/
void SUBD_LogRejected(DBA_DYNFLD_STP event)
{
    DATETIME_ST    creationDate;
    DATETIME_ST    currentDate;
    DATETIME_ST    executionDate;
    HOUR_T         currHour, createHour, execHour;
    MINUTE_T       currMinute, createMinute, execMinute;
    SECOND_T       currSecond, createSecond, execSecond;
    YEAR_T         currYear, createYear, execYear;
    MONTH_T        currMonth, createMonth, execMonth;
    DAY_T          currDay, createDay, execDay;
    FILE           *fp;

    char *	  SV_hostName = GET_SYSNAME(event, A_Event_Hostname);
    char *	  SV_user = GET_SYSNAME(event, A_Event_User);	/* DLA - PMSTA09887 - 101115 */
    char *	  SV_entSqlName = GET_SYSNAME(event, A_Event_EntSqlName);
    char *	  SV_fctSqlName = GET_SYSNAME(event, A_Event_FctSqlName);
    char *	  SV_updStsName = GET_NAME(event, A_Event_UpdateStsName);
    char *	  SV_mapStorage = GET_NOTE(event, A_Event_MapStorage);
    char *	  SV_evtData = GET_TEXT(event, A_Event_Data);

    if (SV_RejectFile[0] == '\0')
    {
        return;
    }

    fp = fopen(SV_RejectFile, "a");
    if (fp == NULL)
    {
        MSG_SendMesg(RET_FILE_ERR_OPEN, 1, FILEINFO, SV_RejectFile);
        return;
    }

    DATE_CurrentDateTime(&currentDate);
    TIME_Get(currentDate.time, &currHour, &currMinute, &currSecond);
    DATE_Get(currentDate.date, &currYear, &currMonth, &currDay);

    creationDate = GET_DATETIME(event, A_Event_CreationDate);
    executionDate = GET_DATETIME(event, A_Event_ExecutionDate);

    TIME_Get(creationDate.time, &createHour, &createMinute, &createSecond);
    DATE_Get(creationDate.date, &createYear, &createMonth, &createDay);
    TIME_Get(executionDate.time, &execHour, &execMinute, &execSecond);
    DATE_Get(executionDate.date, &execYear, &execMonth, &execDay);

    fprintf(fp,
            "REJECTED %2d/%2d/%04d %2d:%2d:%2d\n"
            "EVENT    %" szFormatId" %s %s %d %d %s %s %d %d %2d/%2d/%04d %2d:%2d:%2d %2d/%2d/%04d "  /* DLA - PMSTA08801 - 100616 */
            "%2d:%2d:%2d %s %s\n"
            "DATA     %s\n",
            currMonth, currDay, currYear, currHour, currMinute, currSecond,
            GET_ID(event, A_Event_Id),
            (SV_hostName == (char *)NULL) ? "NULL" : SV_hostName,
            (SV_user == (char *)NULL) ? "NULL" : SV_user,
            GET_ENUM(event, A_Event_StatusEn),
            GET_ENUM(event, A_Event_NatureEn),
            (SV_entSqlName == (char *)NULL) ? "NULL" : SV_entSqlName,
            (SV_fctSqlName == (char *)NULL) ? "NULL" : SV_fctSqlName,
            GET_ENUM(event, A_Event_ActionEn),
            GET_ENUM(event, A_Event_ModuleEn),
            createMonth, createDay, createYear, createHour, createMinute, createSecond,
            execMonth, execDay, execYear, execHour, execMinute, execSecond,
            (SV_updStsName == (char *)NULL) ? "NULL" : SV_updStsName,
            (SV_mapStorage == (char *)NULL) ? "NULL" : SV_mapStorage,
            (SV_evtData == (char *)NULL) ? "NULL" : SV_evtData);

    fclose(fp);
}

/************************************************************************
**
**  Function    :   GEN_GetProgramType()
**
**  Description :   Return AAA programm type
**
**  Arguments   :
**
**  Return      :   AAAProgramType
**
**  Creation    :   PMSTA-54990 - DDV - 231201
**  Last modif. :
**
*************************************************************************/
AAAProgramType GEN_GetProgramType(void)
{
    return(AAAProgramType::Batch);
}

/************************************************************************
**      END  subd.c                                           UNICIBLE
*************************************************************************/

/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**
**              Copyright (C) 1998-2000 by ODYSSEY
**                       All Rights Reserved
**
**                   Portfolio Management System
**
*************************************************************************/
#ifndef AUDIT_H
#define AUDIT_H

/* VERSION */ static char auditSid[]="@(#)audit.h 5.1\t00/04/25";

/************************************************************************
**      Constant & Macro definitions
*************************************************************************/
#define AUDIT_HALT(x) AUDIT_Halt(x, __FILE__, __LINE__)

/* some ret codes */
#define AUDIT_SUCCEED RET_SUCCEED
#define AUDIT_ERROR (AUDIT_SUCCEED+1)
#define AUDIT_EXIT  (AUDIT_SUCCEED+2)

/************************************************************************
**      Structure & Type definitions
*************************************************************************/

/************************************************************************
**      External definitions attached to : auditlib.c
*************************************************************************/
#ifdef EXTERN
#undef EXTERN
#endif
#ifdef  AUDITLIB_C
#define EXTERN
#else
#define EXTERN extern
#endif

typedef struct {
	CODE_T	User;
	DICT_T	Entity;
	int		Action;
	int		Module;
	char	BegDate[60];  /* PMSTA-18583 - TEB - 160321 */
	char	EndDate[60];  /* PMSTA-18583 - TEB - 160321 */
} AUDITFILTER_ST;

EXTERN RET_CODE AUDIT_Proceed();
EXTERN void     AUDIT_Halt();

#endif  /* ifndef AUDIT_H */
/************************************************************************
**      END  audit.h                                           UNICIBLE
*************************************************************************/

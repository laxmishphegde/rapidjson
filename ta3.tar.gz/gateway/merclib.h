/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**
**              Copyright (C) 1993-1994 by UNICIBLE
**                       All Rights Reserved
**
**                   Portfolio Management System
**
*************************************************************************/
#ifndef MERCLIB_H
#define MERCLIB_H

/* VERSION */ static char auditmercSid[]="@(#)merclib.h 5.2\t00/11/24";

/************************************************************************
**      Constant & Macro definitions
*************************************************************************/

/************************************************************************
**      Structure & Type definitions
*************************************************************************/

EXTERN	RET_CODE	AUDIT_SendAllToMercator();
EXTERN	int			LoadDescFile(char * attFileName);
EXTERN  int         MERC_Startup(char * registryFile);
EXTERN  void        MERC_LogMapError();
EXTERN  void        MERC_Shutdown();
EXTERN  void        MERC_LogMapError();

#ifdef __cplusplus
extern "C" {
#endif

typedef struct subd_list_element *SUBD_LIST_ELEMENT_STP;

typedef struct subd_list_element {
   char                  entity[21];
   int                   nFields;
   char                  **fieldList;
   SUBD_LIST_ELEMENT_STP link;
} SUBD_LIST_ELEMENT_ST;

typedef struct {
  char *name;
  char *oldVal;
  char *newVal;
  char *dataTypeSqlname; /* PMSTA39500 - 18092020 - HLA */
} Field;

#define FS_SEP '\034'
#define GS_SEP '\035'
#define RS_SEP '\036'
#define US_SEP '\037'

#define FS_STR "\034"
#define GS_STR "\035"
#define RS_STR "\036"
#define US_STR "\037"

#ifdef __cplusplus
}
#endif

/************************************************************************
**      External definitions attached to : merclib.c
*************************************************************************/

#endif  /* ifndef MERCLIB_H */
/************************************************************************
**      END  merclib.h                                           UNICIBLE
*************************************************************************/




































































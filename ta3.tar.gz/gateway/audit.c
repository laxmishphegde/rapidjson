/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**
**              Copyright (C) 1998-2000 by ODYSSEY
**                       All Rights Reserved
**
**                   Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define AUDIT_C

/************************************************************************
**      Includes
*************************************************************************/

#define	STDIO_H
#define	STDLIB_H
#define	STRING_H
#define	UNISTD_H
#define	SIGNAL_H
#define	SETJMP_H

#include <unidef.h>	/* Mandatory */
#include <sig.h>
#include <audit.h>
#include <syslib.h>
#include <gen.h>
#include <dba.h>
#include <dict.h>
#include <date.h>
#include <csrv.h>
#include "merclib.h"

#include "crypto.h"
#include "crypto-openssl.h"
#include "password.h"
#include "aaalogger.h"

/************************************************************************
**      Constants
*************************************************************************/

/************************************************************************
**      Macro Definitions
*************************************************************************/

/************************************************************************
**      Type  Definitions
*************************************************************************/

/************************************************************************
**      Declarations
*************************************************************************/
extern PTR EV_ExtractFileTimerPtr;
extern void MSG_InitLogFileName(const char *);
extern char *SV_LogFileName;
//extern char     SV_ApplName[]; /* replace SV_ApplName by GEN_GetApplName() - FME- 190129 */
extern int LoadDescFile(char *);

/************************************************************************
**      Global Functions
**
**  main()              Import Interface Entry Point
**
*************************************************************************/

/************************************************************************
**      Static Functions
**
**  AUDIT_GetOption()
**  AUDIT_Startup()
**  AUDIT_Shutdown()
**
*************************************************************************/

STATIC int  AUDIT_GetConnectionOption(int, char **);
STATIC int  AUDIT_GetFilterOption(int, char **);
STATIC int  AUDIT_Startup(char *);
STATIC void AUDIT_Shutdown();
STATIC void AUDIT_Usage();

/************************************************************************
**      Static Data Definitions
*************************************************************************/

static int SV_ServerMode = FALSE;
static int SV_ServerInitFlg = TRUE;
static char	SV_User[MAX_USERINFO_LEN +1];

static jmp_buf SV_JumpBuffer;
char   *EV_RegistryFile    = NULL;
CODE_T      EV_DbTimeZoneCd="";       /* PMSTA-30817 - DDV - 180501 */

/************************************************************************
**      Global Data Definitions
*************************************************************************/

int *EV_ServerMode = &SV_ServerMode;

int  EV_OptiMemFlg = FALSE;

int  EV_TestNewScpt = 1;

int  EV_GuiActivatedFlg = 0;

int *EV_ServerInitFlg = &SV_ServerInitFlg;

AUDITFILTER_ST EV_AuditFilter;
char *EV_AttFileName = NULL;
/************************************************************************
**      Static Function Definitions
*************************************************************************/

/************************************************************************
**
**  Function    :   AUDIT_GetConnectionOption()
**
**  Description :	analyse command line parameters for database connection
**
**  Argument    :   argc
**                  argv
**
**  Return      :   AUDIT_SUCCEED on success, AUDIT_ERROR elsewhere
**                  AUDIT_EXIT for exit request
**
*************************************************************************/
STATIC int AUDIT_GetConnectionOption(int argc, char **argv)
{
	int     i;
	char    *p = (char*)NULL,
			nextArgv = 0;
	char    errMsg[128];

	*SV_User = END_OF_STRING;

	/* For all parameters */
	for (i=1; i<argc ; i++)
	{
		if (!nextArgv && *argv[i] == '-')
		{
			if(argv[i][2] == END_OF_STRING)
			{
				nextArgv = argv[i][1];

				if (nextArgv == 'W')
				{
					fprintf(stderr,"Warning messages logging is activated\n");
					EV_WarningMsg = TRUE;
				}
                else if (nextArgv == 'v')
                {
                   GEN_AnalyseVersion(nextArgv);
                   return AUDIT_EXIT;
                }
                else if (nextArgv == 'V')
				{
                        GEN_AnalyseVersion(nextArgv);
						               }
				else
					continue;
			}
			else    p = &argv[i][2];
		}
		else    p = argv[i];

		switch((nextArgv)?nextArgv:*(p-1))
		{
		case 'U' : /* User Name */
				if(p == NULL)
				{
					strcpy(errMsg,"Connection option ""-U"" : Triple-A User must be provided");
					MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, errMsg);
					strcat(errMsg,"\n");
					fprintf(stderr,errMsg);
					return AUDIT_ERROR;
				}
				strcpy(SV_User, p);
                SYS_SetThreadUser(SV_User);
				break;

		case 'P' : /* User Password */
                {
                    PasswordEncrypted pE;

				    if(p == NULL)
				    {
					    strcpy(errMsg,"Connection option ""-P"" : Password must be provided");
					    MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, errMsg);
					    strcat(errMsg,"\n");
					    fprintf(stderr,errMsg);
					    return AUDIT_ERROR;
				    }

                    pE.setClearPassword(PasswordClear(p));
                    GEN_SetUserInfo(UserPasswd, &pE);
                }
                break;

        case 'a':                       /* FME - PMSTA-32904 - 190205 */
            EV_AttFileName = p;
            break;

        case 'r' :
             EV_RegistryFile = p;
             break;

		case 'J': /* CharSet */
				if(p == NULL)
				{
					strcpy(errMsg,"Connection option ""-J"" : Character Set must be provided");
					MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, errMsg);
					strcat(errMsg,"\n");
					fprintf(stderr,errMsg);
					return AUDIT_ERROR;
				}
				if(GEN_SetCurCharset(p, CharsetCodeType_Rdbms, CharsetCodeNoCtx, EV_RdbmsVendor) != RET_SUCCEED)
				{
					sprintf(errMsg,"Option ""-J"" : Character Set '%s' is invalid",p);
					MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, errMsg);
					strcat(errMsg,"\n");
					fprintf(stderr,errMsg);
                    return AUDIT_ERROR;
				}
                break;
      case 'K' : /* Output file charset */
         if (GEN_SetCurCharset(p, CharsetCodeType_Icu, CharsetCodeCtx_Output, EV_RdbmsVendor) != RET_SUCCEED)
            return AUDIT_ERROR;
         if(strcmp(p, "cp850") == 0 ||
            strcmp(p, "cp437") == 0 ||
            strcmp(p, "roman8") == 0 ||
            strcmp(p, "mac") == 0)
         {
            printf("Invalid output charset %s\n", p);
            return AUDIT_ERROR;
         }
         break;

        case 'c' :  /*  Business Entity as input parameter  */  /*  HFI-PMSTA-26560-170806  */
                SYS_GetThread().setCurrBusinessEntity(p);
                break;

        case 'C': /* FME - PMSTA-32904 - 190205 */
            SYS_LoadCfgFile(p);
            break;

        case 'n': /* PMSTA-41113 - KNI - 310820 */
        {
            std::string dbServiceName = DBI_GetSqlServerName(std::string(SYS_GetoptArg()));
            break;
        }

		}
		nextArgv = 0;
	}

    PasswordEncrypted * pE = nullptr;
	GEN_GetUserInfo(UserPasswd, &pE);
    if (SV_User[0] == END_OF_STRING)
    {
        strcpy(SV_User, SYS_GetThreadUser().c_str());
    }

	if (*SV_User && (pE->isValidPassword() == false))
	{
        RET_CODE ret_code = SYS_AutoLogin(SV_User, *pE);

        if (ret_code == RET_SUCCEED)
        {
		    GEN_SetUserInfo(UserPasswd, pE);
        }
        else
        {
		    SYSNAME_T pwd;
		    AUTO_PASSWORD_CLEAR(pwd, sizeof(pwd));
		    SYS_GetPassword("Password", pwd, MAX_USERINFO_LEN + 1, 0);
		    pE->setClearPassword(PasswordClear(pwd));
		    GEN_SetUserInfo(UserPasswd, pE);
        }
	}

#ifdef AIX
	if (argc > 1)
		*argv[1] = '\0';
#endif

    if (*SV_User == END_OF_STRING || pE->isValidPassword() == false)
        return AUDIT_ERROR;

   return AUDIT_SUCCEED;
}

/************************************************************************
**
**  Function    :   AUDIT_GetFilterOption()
**
**  Description :	analyse command line parameters for audit filtering
**
**  Argument    :   argc
**                  argv
**
**  Return      :   AUDIT_SUCCEED on success, AUDIT_ERROR elsewhere
**
*************************************************************************/
STATIC int AUDIT_GetFilterOption(int argc, char **argv)
{
	int     i, tempInteger;
	char    *p = (char*)NULL, nextArgv = 0;
	char    errMsg[128];
	DATE_T     tempBegDate;
	DATETIME_T tempEndDate;		/* PMSTA-18583 - TEB - 160321 */
	DATE_FORMAT_ST fmt;
	YEAR_T  yyyy;
	MONTH_T mm;
	DAY_T   dd;

	DICT_ENTITY_STP dict;

	*SV_User = END_OF_STRING;
	tempBegDate = 0L;
	tempEndDate.date = 0L;
	tempEndDate.time = 0L;
	fmt.ordre = Dmy;
	strcpy(fmt.yearSep,  "/");
	strcpy(fmt.monthSep, "/");
	strcpy(fmt.daySep,   "/");
	fmt.yearFormat = 1;
	fmt.monthFormat = 0;

	for (i=1; i<argc ; i++)
	{
		if (!nextArgv && *argv[i] == '-')
		{
			if(argv[i][2] == END_OF_STRING)
			{
				nextArgv = argv[i][1];
					continue;
			}
			else    p = &argv[i][2];
		}
		else    p = argv[i];

		switch((nextArgv)?nextArgv:*(p-1))
		{
		case 'N': /* User Name */
				if(p == NULL)
				{
					strcpy(errMsg,"Filter option ""-N"" : UserName must be provided");
					MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, errMsg);
					strcat(errMsg,"\n");
					fprintf(stderr,errMsg);
					return AUDIT_ERROR;
				}
				if(strcmp(p,"ALL"))
					strcpy(EV_AuditFilter.User,p);
				break;

		case 'Y': /* Entity */
				if(p == NULL)
				{
					strcpy(errMsg,"Filter option ""-Y"" : Entity name must be provided");
					MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, errMsg);
					strcat(errMsg,"\n");
					fprintf(stderr,errMsg);
					return AUDIT_ERROR;
				}
				if(strcmp(p,"ALL"))
				{
					if(DBA_SearchEntityBySqlName(p,&dict) != RET_SUCCEED)
					{
						sprintf(errMsg,"Filter option ""-Y"" : Entity '%s' is invalid",p);
						MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, errMsg);
						strcat(errMsg,"\n");
						fprintf(stderr,errMsg);
						return AUDIT_ERROR;
					}
					EV_AuditFilter.Entity = dict->entDictId;
				}
				break;

		case 'A': /* Action */
				if(p == NULL)
				{
					strcpy(errMsg,"Filter option ""-A"" : Action must be provided");
					MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, errMsg);
					strcat(errMsg,"\n");
					fprintf(stderr,errMsg);
					return AUDIT_ERROR;
				}
				if(strcmp(p,"ALL"))
				{
					tempInteger = DBA_GetPermValEnum(Audit,A_Audit_ActionEn,p);
					if(tempInteger < 0)
					{
						sprintf(errMsg,"Filter option ""-A"" : Action '%s' is invalid",p);
						MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, errMsg);
						strcat(errMsg,"\n");
						fprintf(stderr,errMsg);
						return AUDIT_ERROR;
					}
					EV_AuditFilter.Action = tempInteger;
				}
				break;

		case 'M': /* Module */
				if(p == NULL)
				{
					strcpy(errMsg,"Filter option ""-M"" : Module must be provided");
					MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, errMsg);
					strcat(errMsg,"\n");
					fprintf(stderr,errMsg);
					return AUDIT_ERROR;
				}
				if(strcmp(p,"ALL"))
				{
					tempInteger = DBA_GetPermValEnum(Audit,A_Audit_ModuleEn,p);
					if(tempInteger < 0)
					{
						sprintf(errMsg,"Filter option ""-M"" : Module '%s' is invalid",p);
						MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, errMsg);
						strcat(errMsg,"\n");
						fprintf(stderr,errMsg);
						return AUDIT_ERROR;
					}
					EV_AuditFilter.Module = tempInteger;
				}
				break;

		case 'B': /* Begin Date */
				if(p == NULL)
				{
					strcpy(errMsg,"Filter option ""-B"" : Begin Date must be provided");
					MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, errMsg);
					strcat(errMsg,"\n");
					fprintf(stderr,errMsg);
					return AUDIT_ERROR;
				}
				if(strcmp(p,"NULL"))
				{
					tempBegDate = DATE_FormatToDate(p,&fmt);
                    /* DLA - PMSTA-29051 - 171108 */
                    if (tempBegDate == BAD_DATE)
                    {
                        NOTE_T tmp;
                        std::string DATE_ORDRE_ENUM_TAB[] = { "Ymd", "Dmy", "Mdy", "Iso" };
                        sprintf(tmp, "Invalid date: string received:\"%s\", unable to convert with these settings: order=%s, sep=%s, YearLen=%s, monthFormat=%s", p, DATE_ORDRE_ENUM_TAB[fmt.ordre].c_str(), fmt.monthSep, fmt.yearFormat == 0 ? "short(YY)" : "long(YYYY)", fmt.monthFormat == 0 ? "numeric(MM)" : "short(mmm)");
                        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "AUDIT_GetFilterOption", tmp);
                    }

					DATE_Get(tempBegDate, &yyyy, &mm, &dd);
					if(!DATE_Check(yyyy,mm,dd))
					{
						sprintf(errMsg,"Filter option ""-B"" : Begin Date '%s' is invalid",p);
						MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, errMsg);
						strcat(errMsg,"\n");
						fprintf(stderr,errMsg);
						return AUDIT_ERROR;
					}

					DATE_ToDbStr(EV_AuditFilter.BegDate, tempBegDate);   /* PMSTA-18583 - TEB - 160321 */
				}
				break;

		case 'E': /* End Date */
				if(p == NULL)
				{
					strcpy(errMsg,"Filter option ""-E"" : End Date must be provided");
					MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, errMsg);
					strcat(errMsg,"\n");
					fprintf(stderr,errMsg);
					return AUDIT_ERROR;
				}
				if(strcmp(p,"NULL"))
				{
					tempEndDate.date = DATE_FormatToDate(p,&fmt);								/* PMSTA-18583 - TEB - 160321 */
                    /* DLA - PMSTA-29051 - 171108 */
                    if (tempEndDate.date == BAD_DATE)
                    {
                        NOTE_T tmp;
                        std::string DATE_ORDRE_ENUM_TAB[] = { "Ymd", "Dmy", "Mdy", "Iso" };
                        sprintf(tmp, "Invalid date: string received:\"%s\", unable to convert with these settings: order=%s, sep=%s, YearLen=%s, monthFormat=%s", p, DATE_ORDRE_ENUM_TAB[fmt.ordre].c_str(), fmt.monthSep, fmt.yearFormat == 0 ? "short(YY)" : "long(YYYY)", fmt.monthFormat == 0 ? "numeric(MM)" : "short(mmm)");
                        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "DATE_FormatToDate", tmp);
                    }

					DATE_Get(tempEndDate.date, &yyyy, &mm, &dd);								/* PMSTA-18583 - TEB - 160321 */
					if(!DATE_Check(yyyy,mm,dd))
					{
						sprintf(errMsg,"Filter option ""-E"" : End1 Date '%s' is invalid",p);
						MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, errMsg);
						strcat(errMsg,"\n");
						fprintf(stderr,errMsg);
						return AUDIT_ERROR;
					}

					tempEndDate.time = TIME_Put(23, 59, 59);
					DATETIME_ToDbStr(EV_AuditFilter.EndDate, tempEndDate.date, tempEndDate.time);   /* PMSTA-18583 - TEB - 160321 */
				}
				break;

        case 'c' :  /*  Business Entity as input parameter  */  /*  HFI-PMSTA-26560-170806  */
                SYS_GetThread().setCurrBusinessEntity(p);
                break;
		}
		nextArgv = 0;
	}

	if(EV_AuditFilter.BegDate[0] && EV_AuditFilter.EndDate[0])
	{
		if(DATE_Cmp(tempBegDate,tempEndDate.date) > 0L)
		{
			sprintf(errMsg,"Wrong Date chronology : Begin date '%s' > End Date '%s'",
							EV_AuditFilter.BegDate, EV_AuditFilter.EndDate);
			MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, errMsg);
			strcat(errMsg,"\n");
			fprintf(stderr,errMsg);
		}
	}

#ifdef AIX
	if (argc > 1)
		*argv[1] = '\0';
#endif

    return AUDIT_SUCCEED;
}

/************************************************************************
**
**  Function    :   AUDIT_Startup()
**
**  Description :	connection to server and usual initialisations
**
**  Argument    :   user
**                  password
**
**  Return      :   0 on success, -1 elsewhere
**
**  Last modif. :   PMSTA-18094 - 130514 - PMO : Avoid extracting the user credentials from the GUI running on Windows (via dump, etc.)
**                  PMSTA-35739 - 140519 - PMO : ThreadCleanupConnection does nothing in subd, import, GUI
**
*************************************************************************/
STATIC int AUDIT_Startup(char *user)
{
   int status = 0;

   if (GEN_Initial() == RET_SUCCEED)
   {

	   if (CSRV_Init(false) == RET_SUCCEED)                                  /* PMSTA-18094 - 130514 - PMO */
	   {
		   PasswordEncrypted *pE = nullptr;
		   GEN_GetUserInfo(UserPasswd, &pE);

		   if (GEN_AppLogin(user, *pE) == RET_SUCCEED)      /* PMSTA-18094 - 130514 - PMO */
		   {
			   if (DBA_InitDictInfo() != RET_SUCCEED ||
				   DBA_LoadingTabInMemory() != RET_SUCCEED ||
                   DBA_CurrenciesMapInit() != RET_SUCCEED)  /* REF5248 - RAK - 001005 */
				   status = -1;

               DBA_LoadAndCheckDbTimeZone(false);                /* PMSTA-30187 - DDV - 180501 */
               (void)GEN_InitPoolConnectionFinal();               /* PMSTA-24563 - LJE - 160831 */
               SYS_StartThreadGeneralCallback();            /* DLA - PMSTA-25639 - 170323 */
               SYS_SetProgramState(ProgramState::Running);  /* PMSTA-35739 - 140519 - PMO */
		   }
		   else
			   status = -1;
	   }
      else
         status = -1;
   }
   else
      status = -1;

   if(LoadDescFile(EV_AttFileName))
   {
      MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO,
               "Cannot load description file.");
      return -1;
   }

	/* Initialize Filter for Audit Header */
	*EV_AuditFilter.User	= END_OF_STRING;
	EV_AuditFilter.Entity	= -1;
	EV_AuditFilter.Action	= -1;
	EV_AuditFilter.Module	= -1;
	*EV_AuditFilter.BegDate	= END_OF_STRING;
	*EV_AuditFilter.EndDate	= END_OF_STRING;

   return status;
}

/************************************************************************
**
**  Function    :   AUDIT_Shutdown()
**
**  Description :   disconnect from Sybase
**
**  Argument    :   none
**
**  Return      :   none
**
**  Last modif. :   PMSTA-35739 - 140519 - PMO : ThreadCleanupConnection does nothing in subd, import, GUI
**
*************************************************************************/
STATIC void AUDIT_Shutdown()
{
    SYS_SetProgramState(ProgramState::ShutdownThreadTerminating);   /* PMSTA-35739 - 140519 - PMO */
    SYS_StopThreadGeneralCallback();                                /* DLA - PMSTA-25639 - 170323 */
    MERC_Shutdown();
}

/************************************************************************
**
**  Function    :   AUDIT_Usage()
**
**  Description :   Prints usage message
**
**  Argument    :   none
**
**  Return      :   none
**
*************************************************************************/
STATIC void AUDIT_Usage()
{
      fprintf(stderr,
         "usage: audit [-W] [-v] [-V] [-J <charset>] [-n <db service name>] -U <user> -P <password> <filter options>     \n"
         "       with  <-W>       : turn on warning messages logging             \n"
         "             <-v>       : display the application version              \n"
         "             <-V>       : display environment variables                \n"
         "             <-J>       : a valid character set. (iso_1, roman_8, ...).\n"
         "             <-n>       : DB Service Name for connecting to DB         \n"
         "             <-a>       : alternative attribute description file       \n"
         "                                                                       \n"
         "       and   <charset>  : Database charset                             \n"
         "             <user>     : SQL Server Username                          \n"
         "             <password> : SQL Server Password                          \n"
         "                                                                       \n"
		 "       filter options                                                               \n"
		 "             <-N><UserName|""ALL""> : Any User who created events                   \n"
		 "             <-Y><Entity|""ALL"">   : Any Entity name taken from the metadictionary \n"
		 "             <-A><Action|""ALL"">   : Any Database actions : ""Insert"",""Update"",""Delete"" \n"
		 "             <-M><Module|""ALL"">   : Any Triple-A module : ""Gui"",""Import"",""Server"",""Other""\n"
		 "             <-B><BeginDate>      : Beginning of time period ""dd/mm/yyyy""         \n"
		 "             <-E><EndDate>        : Ending of time period ""dd/mm/yyyy""            \n");
}


/************************************************************************
**      Global Function Definitions
*************************************************************************/

/************************************************************************
*   Function             : initCallback()
*
*   Description          : No special initialization at this level for the GUI
*
*   Arguments            : None
*
*   Functions call       : None
*
*   Return               : None
*
*   Last Modif.          : PMSTA-24076 - 180716 - PMO : Unstable connections
*
*************************************************************************/
void initCallback()
{
    SYS_SetCallBackThreadDataCtxGeneric(GEN_ThreadDataCtxGenericCreate
                                       ,GEN_ThreadDataCtxGenericAllocate
                                       ,GEN_ThreadDataCtxGenericInit
                                       ,GEN_ThreadDataCtxGenericPrepareApplicationData      /* PMSTA-24076 - 180716 - PMO */
                                       ,GEN_ThreadDataCtxGenericCleaningApplicationData     /* PMSTA-24076 - 180716 - PMO */
                                       ,GEN_ThreadDataCtxGenericDestroy);
}

/************************************************************************
**
**  Function    :   mainAudit()
**
**  Description :   Entry Point
**
**  Arguments   :
**
**  Return      :
**
*************************************************************************/
int mainAudit(int argc, char **argv, AAALogger::Initializer& loggerInitializer)
{
   CURRENTCHARSETCODE_ENUM charsetCode = CurrentCharsetCode_IsNull;
   char *hideArgsFlg=NULL, *startupParam=NULL;

   charsetCode = CurrentCharsetCode_IsNull;
   int rc = AUDIT_SUCCEED;

   OpenSSLProvider::setup();
   PasswordEncrypted::setup(SYS_GetIt);
   MemoryPool mp;

   /* Initialize the locks table */
   if (SYS_InitLockTable() != TRUE)
   {
       MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "SYS_InitLockTable() failed");
       return(1);
   }
   GEN_ForceApplName("aaa_audit");  /* PMSTA-32895 - 140119 - FME Cluster Logger */
   EV_WarningMsg = FALSE;

   GEN_SetApplInfo(ApplCurrentCharsetCodeEnum, &charsetCode);

	MSG_InitLogFileName("audit.log");
	if(SYS_GetEnv("AAAMSG"))
		MSG_OpenMsgFile(SYS_GetEnv("AAAMSG"));
	else
		MSG_OpenMsgFile((char *)".");


   /* Read arguments in environment variable according to HIDE_ARGS value */
   if ((hideArgsFlg = SYS_GetEnv("HIDE_ARGS")) != NULL && strcmp(hideArgsFlg,"1") == 0 &&
		(startupParam = SYS_GetEnv("AAA_STARTUP_PARAMS")) != NULL)
	{
		int		argNbr=0;
		char	**argTab=NULL;

		/* Cut startupParam in argNbr and copy in argTab */
        if (GEN_TreatStartupParams(startupParam, argv, &argNbr, &argTab, mp) == FALSE)
        {
            return(0);
        }
        loggerInitializer.configure(false /*startWatcherThread*/);          /* PMSTA-32895 - 140119 - FME Cluster Logger */

		/* Send created argTab to GetOption */
		if ((rc = AUDIT_GetConnectionOption(argNbr,argTab)) != AUDIT_SUCCEED)
		{
            if (rc == AUDIT_EXIT)
            {
                return 0;
            }

			AUDIT_Usage();
			return AUDIT_ERROR;
		}

		if (AUDIT_Startup(SV_User))
		{
			fprintf(stderr, "Audit : initialisation error (see log file)\n");
	        return AUDIT_ERROR;
		}

		if (AUDIT_GetFilterOption(argNbr, argTab) != AUDIT_SUCCEED)
		{
			AUDIT_Usage();
			return AUDIT_ERROR;
		}
	}
	else
	{
       /* Send created argTab to GetOption */
		if ((rc = AUDIT_GetConnectionOption(argc,argv)) != AUDIT_SUCCEED)
		{
            if (rc == AUDIT_EXIT)
            {
                return 0;
            }

			AUDIT_Usage();
			return AUDIT_ERROR;
		}
        loggerInitializer.configure(false /*startWatcherThread*/);          /* PMSTA-32895 - 140119 - FME Cluster Logger */

		if (AUDIT_Startup(SV_User))
		{
			fprintf(stderr, "Audit : initialisation error (see log file)\n");
	        return AUDIT_ERROR;
		}

		if (AUDIT_GetFilterOption(argc, argv) != AUDIT_SUCCEED)
		{
			AUDIT_Usage();
			return AUDIT_ERROR;
		}
	}

   if (MERC_Startup(EV_RegistryFile))
   {
       return 1;
   }

   AUDIT_Proceed();
   AUDIT_Shutdown();

   return AUDIT_SUCCEED;
}

/************************************************************************
**
**  Function    :   main()
**
**  Description :   Entry Point
**
**  Arguments   :
**
**  Return      :
**
*************************************************************************/
int main(int argc, char *argv[])
{
    int ret = 0;

#ifndef _DEBUG
    try
    {
#endif
        AAALogger::Initializer loggerInit;          /* PMSTA-32895 - 140918 - FME Cluster Logger */
        AaaMetaDict::load();

        initCallback();

        if (true == SYS_CreateMainThreadDataStorage())
        {
            ret = mainAudit(argc, argv, loggerInit);
            SYS_FreeMainThreadDataStorage(ret);
        }
        else
        {
            ret = 1;
        }
#ifndef _DEBUG
    }
    catch (...)
    {
        if (SYS_IsStateLoggingAllowed())                    /* PMSTA-36212 - 160719 - PMO */
        {
            exceptionHandler(FILEINFO, MSG_SendMesg);
        }
        else
        {
            exceptionHandler(FILEINFO, MSG_SendStderr);     /* PMSTA-36212 - 160719 - PMO */
        }
    }
#endif

    return ret;
}

/************************************************************************
**
**  Function    :   GEN_GetProgramType()
**
**  Description :   Return AAA programm type
**
**  Arguments   :
**
**  Return      :   AAAProgramType
**
**  Creation    :   PMSTA-54990 - DDV - 231201
**  Last modif. :
**
*************************************************************************/
AAAProgramType GEN_GetProgramType(void)
{
	return(AAAProgramType::Batch);
}

/************************************************************************
**      END  audit.c                                           ODYSSEY
*************************************************************************/

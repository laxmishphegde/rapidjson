/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#include "rolit.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>

#ifdef SUN
#undef RET_OK
#endif

#include  "olitapi.h"
#include "olitsign.h"

static CLIENT *clnt = NULL;
int LogMessage(char *, int, ...);

OLI_STATUS AAA_OliInit(int argc, char **argv, AAA_OliContext_STP context)
{
   struct timeval timeout = { 14400, 0 };
   char *host = getenv("ROLIT_HOST");
   char *rp_string = getenv("ROLIT_PROGRAM");
   unsigned long prog_num = ROLIT_PROGRAM;

   if(host == NULL)
      host = "localhost";

   if(rp_string != NULL)
      prog_num = atol(rp_string);

   if (clnt != NULL || 
      (clnt = clnt_create( host, prog_num, ROLIT_VERSION, "tcp")) == NULL)
   {
      LogMessage(__FILE__, __LINE__, "Cannot create client, host:%s, prog_num:%d, version:%d", host, prog_num, ROLIT_VERSION);
      return NOCTX;
   }

   clnt_control(clnt, CLSET_TIMEOUT, (char *)&timeout);

   return RET_OK;
}

OLI_STATUS AAA_OliClose(AAA_OliContext_STP context)
{
   if(clnt == NULL)
   {
      LogMessage(__FILE__, __LINE__, "NULL client before clnt_destroy");
      return NOCTX;
   }

   clnt_destroy(clnt);

   clnt = NULL;

   return RET_OK;
}

OLI_STATUS AAA_OliCall( AAA_OliContext_STP context, char *buffer, long size)
{
   OLI_STATUS status = RET_OK;

   snd_agmt agmt;
   snd_rslt rslt;

   if(clnt == NULL)
   {
      LogMessage(__FILE__, __LINE__, "NULL client before send");
      return NOCTX;
   }

   agmt.buffer.data_val = buffer;
   agmt.buffer.data_len = size;

   memset(&rslt, 0, sizeof(rslt));

   if(rolit_snd_1(&agmt, &rslt, clnt) != RPC_SUCCESS)
   {
      LogMessage(__FILE__, __LINE__, "rolit_snd_1 failed");
      return NOCTX;
   }

   status = rslt.status;

   xdr_free((xdrproc_t)xdr_snd_rslt, (char *)&rslt);

   return status;
}

OLI_STATUS AAA_OliGet(AAA_OliContext_STP context, AAA_OliChEnum channel,
   char *buffer, long size)
{
    OLI_STATUS status = RET_OK;

    rcv_agmt agmt;
    rcv_rslt rslt;

    if (clnt == NULL)
    {
       LogMessage(__FILE__, __LINE__, "NULL client before receive");
       return NOCTX;
    }

    agmt.channel = (int)channel;

    agmt.length = size;

    memset(&rslt, 0, sizeof(rslt));

    if (rolit_rcv_1(&agmt, &rslt, clnt) != RPC_SUCCESS)
    {
       LogMessage(__FILE__, __LINE__, "rolit_rcv_1 failed");
       return NOCTX;
    }

    memcpy(buffer, rslt.buffer.data_val, size);

    status = rslt.status;

    xdr_free((xdrproc_t)xdr_rcv_rslt, (char *)&rslt);

    return status;
}

OLI_STATUS AAA_OliGetStatus(AAA_OliContext_STP context, unsigned char *severity,
   unsigned int *facility, unsigned int *code, char **message)
{
    OLI_STATUS status = RET_OK;

    sts_rslt rslt;

    static char *last = NULL;

    if (clnt == NULL)
    {
       LogMessage(__FILE__, __LINE__, "NULL client before rolit_sts_1");
       return NOCTX;
    }

    memset(&rslt, 0, sizeof(rslt));

    if (rolit_sts_1(NULL, &rslt, clnt) != RPC_SUCCESS)
    {
       LogMessage(__FILE__, __LINE__, "rolit_sts_1 failed");
       return NOCTX;
    }

    if (last != NULL)
       free(last);

    *message = last = strdup(rslt.message);

    *severity = (unsigned char)rslt.severity;
    *facility = (unsigned int )rslt.facility;
    *code     = (unsigned int )rslt.code    ;

    status = rslt.status;

    xdr_free((xdrproc_t)xdr_sts_rslt, (char *)&rslt);

    return status;
}

void AAA_OliSetOpti(char *action, int size)
{
    set_agmt agmt;

    if (clnt == NULL)
    {
       LogMessage(__FILE__, __LINE__, "NULL client before set");
       return;
    }

    agmt.action = action;
    agmt.size   = size  ;

    rolit_set_1(&agmt, NULL, clnt);
}

/*
 * Last modif. : PMSTA-16293 - 210513 - PMO : Update source code - fix build
 */
int LogMessage(char *file, int line, ...)
{
   va_list ap;                                     /* PMSTA-16293 - 210513 - PMO */
   char *format;
   time_t currTime;
   struct tm localTime;
   char timeStamp[128];
   FILE *fp;
   static int firstTime = 1;
   static char logFileName[1024];

   if(firstTime)
   {
      char *aaaMsg;

      firstTime = 0;
      strcpy(logFileName, "rolitd.log");
      aaaMsg = getenv("AAAMSG");

      if(aaaMsg != NULL && strlen(aaaMsg) < 1014)
         sprintf(logFileName, "%s/rolitd.log", aaaMsg);
      else 
         sprintf(logFileName, "/tmp/rolitd.log");

      remove(logFileName);

      fp = fopen(logFileName, "a+");
      if(fp == NULL)
         return 1;

      fclose(fp);
   }

   currTime = time(0L);
   localtime_r(&currTime, &localTime);
   sprintf(timeStamp, "%02d-%02d-%04d %02d:%02d:%02d ", localTime.tm_mday,
      localTime.tm_mon + 1, localTime.tm_year + 1900,
      localTime.tm_hour, localTime.tm_min, localTime.tm_sec);

   va_start(ap, line);

   fp = fopen(logFileName, "a+");
   if(fp == NULL)
      return 1;
   fprintf(fp, "------------------------------\n");
   fprintf(fp, "librolit: %s\n", timeStamp);
   fprintf(fp, "File:    %s Line: %d\n", file, line);
   fprintf(fp, "Message: ");
   format = va_arg(ap, char *);
   vfprintf(fp, format, ap); 
   fprintf(fp, "\n");
 
   fclose(fp);

   va_end(ap);
   return 0;
}

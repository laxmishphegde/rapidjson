/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifdef __cplusplus
extern "C"{
#endif

#define BATCHEX_C

#ifdef HPUX
#define _HPUX_SOURCE
#endif

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdarg.h>
#include <time.h>
#include <limits.h>

#ifdef WIN32
#include <windows.h>
#include <conio.h>
#include <process.h>
#include <sys/timeb.h>
#else
#include <pthread.h>
#include <unistd.h>
#include <dlfcn.h>
#endif

#include <dstxpi.h>

#ifdef WIN32
#define NODL
#endif

#ifdef NODL
static MPIRC (*_mpiAdapterCreate)(HMPIADAPT *phObject,HMPICARD hCard,MPI_ADAPTER_VTABLE *pvTable) = mpiAdapterCreate;
static MPIRC (*_mpiObjectNewPropColl)(HMPIOBJ hObject,MPIPROP iOffset,int iCount,const int piTypes[]) = mpiObjectNewPropColl;
static MPIRC (*_mpiObjectDestroy)(HMPIOBJ hObject) = mpiObjectDestroy;
static MPIRC (*_mpiConnectionCreate)(HMPICONNECT *phObject,MPI_CONNECTION_VTABLE *pvTable) = mpiConnectionCreate;
static MPIRC (*_mpiPropertyGetInteger)(HMPIOBJ hObject,MPIPROP iProperty,int iIndex,int	*piValue) = mpiPropertyGetInteger;
static MPIRC (*_mpiPropertySetText)(HMPIOBJ hObject,MPIPROP iProperty,int iIndex,const char *pText,size_t nLen) = mpiPropertySetText;
static MPIRC (*_mpiPropertyGetText)(HMPIOBJ hObject,MPIPROP iProperty,int iIndex,const char **ppText,size_t *pnLen) = mpiPropertyGetText;
static MPIRC (*_mpiPropertySetInteger)(HMPIOBJ hObject,MPIPROP iProperty,int iIndex,int iValue) = mpiPropertySetInteger;
#else
static MPIRC (*_mpiAdapterCreate)(HMPIADAPT *phObject,HMPICARD hCard,MPI_ADAPTER_VTABLE *pvTable) = NULL;
static MPIRC (*_mpiObjectNewPropColl)(HMPIOBJ hObject,MPIPROP iOffset,int iCount,const int piTypes[]) = NULL;
static MPIRC (*_mpiObjectDestroy)(HMPIOBJ hObject) = NULL;
static MPIRC (*_mpiConnectionCreate)(HMPICONNECT *phObject,MPI_CONNECTION_VTABLE *pvTable) = NULL;
static MPIRC (*_mpiPropertyGetInteger)(HMPIOBJ hObject,MPIPROP iProperty,int iIndex,int	*piValue) = NULL;
static MPIRC (*_mpiPropertySetText)(HMPIOBJ hObject,MPIPROP iProperty,int iIndex,const char *pText,size_t nLen) = NULL;
static MPIRC (*_mpiPropertyGetText)(HMPIOBJ hObject,MPIPROP iProperty,int iIndex,const char **ppText,size_t *pnLen) = NULL;
static MPIRC (*_mpiPropertySetInteger)(HMPIOBJ hObject,MPIPROP iProperty,int iIndex,int iValue) = NULL;
#endif


typedef int BOOL;

#define TRUE  1
#define FALSE 0
#define CHKERR(rc) if (rc != MPIRC_SUCCESS) goto EXCEPTION;

MPIRC GattestInitializeLibrary(void);
MPIRC GattestDestroyLibrary(void);
MPIRC GattestCreateAdapterInstance(HMPIADAPT *, HMPICARD);
MPIRC GattestDestroyAdapterInstance(HMPIADAPT);
MPIRC GattestCreateConnectionInstance(HMPICONNECT *);
MPIRC GattestDestroyConnectionInstance(HMPICONNECT);
MPIRC GattestPut(HMPIADAPT, HMPICONNECT);
MPIRC GattestBeginTransaction(HMPIADAPT, HMPICONNECT);
MPIRC GattestEndTransaction(HMPIADAPT, HMPICONNECT, MPITRANS);
MPIRC GattestValidateProperties(HMPIADAPT);
MPIRC GattestCompareConnection(HMPIADAPT, HMPICONNECT, MPICOMP *);
MPIRC GattestOnNotify(HMPIADAPT, int, int, HMPICONNECT);
MPIRC GattestConnect(HMPICONNECT, HMPIADAPT);
MPIRC GattestDisconnect(HMPICONNECT);
void  SetErrorCode(HMPIOBJ, int);

int   LogMessage(char *, int, ...);

/*
** This structure defines the number and type of adapter properties.
** It is referenced in CreateAdapterInstance.
*/

static const int GattestAdapterProperties[] =
{
   MPI_PROP_TYPE_TEXT,   /* AP_USERNAME */
   MPI_PROP_TYPE_TEXT,   /* AP_PASSWORD */
   MPI_PROP_TYPE_TEXT,   /* AP_SERVER   */
   MPI_PROP_TYPE_TEXT,   /* AP_CHARSET  */
   MPI_PROP_TYPE_TEXT,   /* AP_MODE     */
   MPI_PROP_TYPE_TEXT,   /* AP_BLOCK    */
   MPI_PROP_TYPE_TEXT    /* AP_OPTI     */
};
#define NUM_ADAPTER_PROPERTIES  sizeof(GattestAdapterProperties)/sizeof(int)

/* Adapter object properties - these should be offset from MPI_PROPBASE_USER */
enum
{
	AP_USERNAME = MPI_PROPBASE_USER,
   AP_PASSWORD,
   AP_SERVER,
   AP_CHARSET,
   AP_MODE,
   AP_BLOCK,
   AP_OPTI
};

/*
** This structure defines the number and type of connection properties
** It is referenced in CreateConnectionInstance.
*/
static const int GattestConnectProperties[] =
{
   MPI_PROP_TYPE_TEXT,   /* CP_USERNAME */
   MPI_PROP_TYPE_TEXT,   /* CP_PASSWORD */
   MPI_PROP_TYPE_TEXT,   /* CP_SERVER   */
   MPI_PROP_TYPE_TEXT,   /* CP_CHARSET  */
   MPI_PROP_TYPE_TEXT,   /* CP_MODE     */
   MPI_PROP_TYPE_TEXT,   /* CP_BLOCK    */
   MPI_PROP_TYPE_TEXT    /* CP_OPTI     */
};
#define NUM_CONNECT_PROPERTIES  sizeof(GattestConnectProperties)/sizeof(int)

/* Connection object properties - these should be offset from MPI_PROPBASE_USER */
enum
{
	CP_USERNAME = MPI_PROPBASE_USER,
   CP_PASSWORD,
   CP_SERVER,
   CP_CHARSET,
   CP_MODE,
   CP_BLOCK,
   CP_OPTI
};

/* Define adapter specific error messages */
#define ERR_E_CANT_CONNECT MAKEUSERERROR(1)

#ifdef WIN32
#define PATH_SEPARATOR '\\'
#else
#define PATH_SEPARATOR '/'
#endif

/******  VTABLE for Gattest adapter  ******/

/* gattest is the name of the library */
MPIEXPORT MPI_LIBRARY_VTABLE gattest_config = 
{
   sizeof(MPI_LIBRARY_VTABLE),
   GattestInitializeLibrary,
   GattestDestroyLibrary,  
   GattestCreateAdapterInstance,
   GattestDestroyAdapterInstance,
   GattestCreateConnectionInstance,
   GattestDestroyConnectionInstance,
   NULL,
   NULL,                    
   MPI_TRANSACTIONS_SINGLE, 
   MPI_UNITOFWORK_LOGICAL, 
   FALSE,                  
   FALSE,                
   FALSE,               
   FALSE,              
   FALSE,  
   FALSE,
   MPI_SCOPE_MAP, 
   MPI_ACTION_KEEP | MPI_ACTION_DELETE,
   MPI_ACTION_ROLLBACK | MPI_ACTION_COMMIT,
   MPI_SCOPE_MAP, 
   MPI_ACTION_KEEP,
   MPI_ACTION_ROLLBACK,
   FALSE,
   FALSE,
   MPI_SCOPE_MAP | MPI_SCOPE_CARD, 
   MPI_ACTION_CREATE,
   MPI_ACTION_ROLLBACK | MPI_ACTION_COMMIT, 
   MPI_SCOPE_MAP, 
   MPI_ACTION_CREATE,
   MPI_ACTION_ROLLBACK
};

/* The adapter object virtual table */
MPI_ADAPTER_VTABLE GattestAdapterTable =
{
	sizeof(MPI_ADAPTER_VTABLE),
	NULL,
	NULL,
	NULL,
	GattestPut,
	GattestBeginTransaction,
	GattestEndTransaction,
	NULL,
	GattestValidateProperties,
	NULL,
	GattestCompareConnection,
	GattestOnNotify
};

/* The connection object virtual table */
MPI_CONNECTION_VTABLE GattestConnectionTable = 
{
	sizeof(MPI_CONNECTION_VTABLE),
   GattestConnect,
   GattestDisconnect
};

/* Gattest specific global variables */
char *passArgv[64];
int nArgv;

#ifndef WIN32
pthread_mutex_t  gattest_lock = PTHREAD_MUTEX_INITIALIZER;
#else
CRITICAL_SECTION cs;
#endif

MPIRC GattestInitializeLibrary(void)
{
   LogMessage(__FILE__, __LINE__, "GattestInitializeLibrary()");

#ifdef WIN32
   InitializeCriticalSection(&cs);
#endif

#ifndef NODL
   static void *dl = NULL;

   if (dl == NULL)
   {
     const char *name = getenv("LIBDSTXPI");

     if (name == NULL)
       name = "libdstxpi.so";

     if ((dl = dlopen(name, RTLD_NOW)) == NULL)
     {
       LogMessage((char *)__FILE__, __LINE__, "Failed to load LIBDSTXPI.");
       LogMessage((char *)__FILE__, __LINE__, dlerror());

       return MPIRC_E_3RD_PARTY_FAILED;
     }
     else
     if ((*((void **)(&_mpiAdapterCreate)) = dlsym(dl, "mpiAdapterCreate" )) == NULL ||
         (*((void **)(&_mpiObjectNewPropColl)) = dlsym(dl, "mpiObjectNewPropColl")) == NULL ||
         (*((void **)(&_mpiObjectDestroy)) = dlsym(dl, "mpiObjectDestroy" )) == NULL ||
         (*((void **)(&_mpiConnectionCreate)) = dlsym(dl, "mpiConnectionCreate" )) == NULL ||
         (*((void **)(&_mpiPropertyGetInteger)) = dlsym(dl, "mpiPropertyGetInteger" )) == NULL ||
         (*((void **)(&_mpiPropertySetText)) = dlsym(dl, "mpiPropertySetText" )) == NULL ||
         (*((void **)(&_mpiPropertyGetText)) = dlsym(dl, "mpiPropertyGetText" )) == NULL ||
         (*((void **)(&_mpiPropertySetInteger)) = dlsym(dl, "mpiPropertySetInteger" )) == NULL)
     {
        LogMessage((char *)__FILE__, __LINE__, "Failed to map functions from LIBDSTXPI.");

        dlclose(dl);
        dl = NULL;

        return MPIRC_E_3RD_PARTY_FAILED;
     }
     else
       LogMessage((char *)__FILE__, __LINE__, "LIBDSTXPI scucessfully loaded.");
   }   
#endif

   return MPIRC_SUCCESS;
}

MPIRC GattestDestroyLibrary(void)
{
   LogMessage(__FILE__, __LINE__, "GattestDestroyLibrary()");
   return MPIRC_SUCCESS;
}

MPIRC GattestCreateAdapterInstance (HMPIADAPT *phAdapter,
                                 HMPICARD  hCard)
{
   MPIRC  rc;
   rc = _mpiAdapterCreate(phAdapter, hCard, &GattestAdapterTable );

   LogMessage(__FILE__, __LINE__, "GattestCreateAdapterInstance()");
   if (rc == MPIRC_SUCCESS)
   {
      /* Define the number and type of adapter properties */
      rc = _mpiObjectNewPropColl(*phAdapter, 
                                MPI_PROPBASE_USER, 
                                NUM_ADAPTER_PROPERTIES, 
                                GattestAdapterProperties);

      /* Do any other initialization of instance of adapter object */
   }
   else
      LogMessage(__FILE__, __LINE__, "Cannot create adapter %d", rc);
   return rc;
}

MPIRC GattestDestroyAdapterInstance(HMPIADAPT hAdapter)
{
   int i;

   LogMessage(__FILE__, __LINE__, "GattestDestroyAdapterInstance()");

   /* Free up any memory or data structures use by the adapter instance */

   for(i=0; i<nArgv; i++)
      free(passArgv[i]);
   nArgv = 0;

   return(_mpiObjectDestroy(hAdapter));   
}

MPIRC GattestCreateConnectionInstance(HMPICONNECT *phConnection)
{
   MPIRC  rc;

   LogMessage(__FILE__, __LINE__, "GattestCreateConnectionInstance()");

   rc = _mpiConnectionCreate(phConnection, &GattestConnectionTable);

   if (rc == MPIRC_SUCCESS)
   {
      /* Define the number and type of adapter properties */
      rc = _mpiObjectNewPropColl(*phConnection, 
                                MPI_PROPBASE_USER, 
                                NUM_CONNECT_PROPERTIES, 
                                GattestConnectProperties);

      /* Do any other initialization of instance of connection object */
   }
   else
      LogMessage(__FILE__, __LINE__, "Cannot create connection %d", rc);
   return rc;
}

MPIRC GattestDestroyConnectionInstance(HMPICONNECT hConnection)
{
   /* Free up any memory or data structures use by the connection instance */

   LogMessage(__FILE__, __LINE__, "GattestDestroyConnectionInstance()");
   return(_mpiObjectDestroy(hConnection));   
}

MPIRC	GattestPut(HMPIADAPT   hAdapter,
              HMPICONNECT hConnection)
{
   MPIRC  rc = MPIRC_SUCCESS;

   LogMessage(__FILE__, __LINE__, "GattestPut()");

EXCEPTION:
   SetErrorCode (hAdapter, rc);
   return rc;
}

MPIRC	GattestBeginTransaction(HMPIADAPT hAdapter,
                           HMPICONNECT hConnection)
{

   LogMessage(__FILE__, __LINE__, "GattestBeginTransaction()");

#ifdef WIN32
   EnterCriticalSection(&cs);
#else
   pthread_mutex_lock(&gattest_lock);
#endif

   SetErrorCode (hAdapter, MPIRC_SUCCESS);
   return MPIRC_SUCCESS;
}

MPIRC	GattestEndTransaction(HMPIADAPT hAdapter,
                         HMPICONNECT hConnection,
                         MPITRANS eAction)
{
   int    iContext;
   int    iOnSuccess;
   MPIRC  rc;

   /* 
   ** If this is output card then close the file.
   ** If input and action is to delete, then do so.
   */

   LogMessage(__FILE__, __LINE__, "GattestEndTransaction()");
   rc = _mpiPropertyGetInteger(hAdapter, MPIP_ADAPTER_CONTEXT, 0, &iContext); CHKERR(rc);
   rc = _mpiPropertyGetInteger(hAdapter, MPIP_ADAPTER_ON_SUCCESS, 0, &iOnSuccess); CHKERR(rc);
   if (iContext == MPI_CONTEXT_TARGET || iContext == MPI_CONTEXT_PUT)
   {
#ifdef WIN32
       LeaveCriticalSection(&cs);
#else
       pthread_mutex_unlock(&gattest_lock);
#endif
   }

EXCEPTION:

   SetErrorCode (hAdapter, rc);
   return rc;
}

MPIRC	GattestValidateProperties(HMPIADAPT hAdapter)
{
   size_t nLen;
   char   *lpszCmdLine = nullptr;
   MPIRC  rc = MPIRC_SUCCESS;
   char separators[]   = " ,\t\n'";
   char *p;
   char tok[256];
   char tmpStr[256];


   LogMessage(__FILE__, __LINE__, "GattestValidateProperties()");
   nArgv = 0;

   /* Set all properties to null */
   rc = _mpiPropertySetText(hAdapter, AP_USERNAME, 0, "", 0); CHKERR(rc);
   rc = _mpiPropertySetText(hAdapter, AP_PASSWORD, 0, "", 0); CHKERR(rc);
   rc = _mpiPropertySetText(hAdapter, AP_SERVER,   0, "", 0); CHKERR(rc);
   rc = _mpiPropertySetText(hAdapter, AP_CHARSET,  0, "", 0); CHKERR(rc);
   rc = _mpiPropertySetText(hAdapter, AP_MODE,     0, "", 0); CHKERR(rc);
   rc = _mpiPropertySetText(hAdapter, AP_BLOCK,    0, "", 0); CHKERR(rc);
   rc = _mpiPropertySetText(hAdapter, AP_OPTI,     0, "", 0); CHKERR(rc);

   /* Get the command line */
   rc = _mpiPropertyGetText(hAdapter, MPIP_ADAPTER_COMMANDLINE, 0, (const char **)&lpszCmdLine, &nLen); CHKERR(rc);

   p = lpszCmdLine;

   LogMessage(__FILE__, __LINE__, "Command line: %s", p);

   rc = _mpiPropertySetText(hAdapter, AP_OPTI, 0, "ENABLE", 6); CHKERR(rc);

   while(*p)
   {
      p += (int)strspn(p, separators);

      if(*p == '\0')
         break; 

      strncpy(tok,  p, (size_t)strcspn(p, separators));
      tok[strcspn(p, separators)] = '\0';

      if((strstr(tok, "gattest") == 0) && strcmp(tok, "DLLImPort")) 
         passArgv[nArgv++] = strdup(tok);

      if(strncmp(p, "-U", 2) == 0)
      {
         p += 2;
         p += strspn(p, separators);
         strncpy(tmpStr, p, (size_t)strcspn(p, separators));
	      tmpStr[strcspn(p, separators)] = '\0';
         rc = _mpiPropertySetText(hAdapter, AP_USERNAME, 0, tmpStr, strlen(tmpStr)); CHKERR(rc);
         passArgv[nArgv++] = strdup(tmpStr);
      }   

      if(strncmp(p, "-P", 2) == 0)
      {
         p += 2;
         p += strspn(p, separators);
         strncpy(tmpStr, p, (size_t)strcspn(p, separators));
	      tmpStr[strcspn(p, separators)] = '\0';
         rc = _mpiPropertySetText(hAdapter, AP_PASSWORD, 0, tmpStr, strlen(tmpStr)); CHKERR(rc);
         passArgv[nArgv++] = strdup(tmpStr);
      }   

      if(strncmp(p, "-S", 2) == 0)
      {
         p += 2;
         p += strspn(p, separators);
         strncpy(tmpStr, p, (size_t)strcspn(p, separators));
	      tmpStr[strcspn(p, separators)] = '\0';
         rc = _mpiPropertySetText(hAdapter, AP_SERVER, 0, tmpStr, strlen(tmpStr)); CHKERR(rc);
         passArgv[nArgv++] = strdup(tmpStr);
      }   

      if(strncmp(p, "-J", 2) == 0)
      {
         p += 2;
         p += strspn(p, separators);
         strncpy(tmpStr, p, (size_t)strcspn(p, separators));
	      tmpStr[strcspn(p, separators)] = '\0';
         rc = _mpiPropertySetText(hAdapter, AP_CHARSET, 0, tmpStr, strlen(tmpStr)); CHKERR(rc);
         passArgv[nArgv++] = strdup(tmpStr);
      }   

      if(strncmp(p, "-M", 2) == 0)
      {
         p += 2;
         p += strspn(p, separators);
         strncpy(tmpStr, p, (size_t)strcspn(p, separators));
	      tmpStr[strcspn(p, separators)] = '\0';
         rc = _mpiPropertySetText(hAdapter, AP_MODE, 0, tmpStr, strlen(tmpStr)); CHKERR(rc);
         passArgv[nArgv++] = strdup(tmpStr);
      }   

      if(strncmp(p, "-B", 2) == 0)
      {
         p += 2;
         p += strspn(p, separators);
         strncpy(tmpStr, p, (size_t)strcspn(p, separators));
	      tmpStr[strcspn(p, separators)] = '\0';
         rc = _mpiPropertySetText(hAdapter, AP_BLOCK, 0, tmpStr, strlen(tmpStr)); CHKERR(rc);
         passArgv[nArgv++] = strdup(tmpStr);
      }   

      if(strncmp(p, "-O", 2) == 0)
      {
         p += 2;
         strcpy(tmpStr, "ENABLE");
         rc = _mpiPropertySetText(hAdapter, AP_OPTI, 0, tmpStr, strlen(tmpStr)); CHKERR(rc);
      }   

      p += (int)strcspn(p, separators);
   }


EXCEPTION:

   SetErrorCode (hAdapter, rc);
   return rc;
}

/****************************************************************************/
/*                                                                          */
/* Function:    GattestValidateConnection                                     */
/*                                                                          */
/* Description: "Ping" the connection to make sure that it is still valid.  */
/*              This gets called periodically when a connection is to be    */
/*              reused.  The Event Server configuration determines whether  */
/*              this should be called, and if so how frequently.            */
/*                                                                          */
/* Inputs:      hAdapter - Adapter object                                   */
/*              hConnection - Connection object                             */
/*                                                                          */
/* Outputs:     None                                                        */
/*                                                                          */
/****************************************************************************/
MPIRC	GattestValidateConnection(HMPIADAPT   hAdapter, HMPICONNECT hConnection)
{
   LogMessage(__FILE__, __LINE__, "GattestValidateConnection()");
   return MPIRC_SUCCESS;
}

MPIRC	GattestCompareConnection(HMPIADAPT   hAdapter,
                            HMPICONNECT hConnection,
                            MPICOMP     *peComp)
{
   int    bActive;
   int    rc;

   LogMessage(__FILE__, __LINE__, "GattestCompareConnection()");
   rc = _mpiPropertyGetInteger(hConnection, MPIP_CONNECTION_INUSE, 0, &bActive); CHKERR(rc);

   if (!bActive)
      *peComp = MPI_CMP_LESS;
   else
      *peComp = MPI_CMP_EQUAL;

   return MPIRC_SUCCESS;


EXCEPTION:

   return rc;
}

MPIRC	GattestOnNotify(HMPIADAPT hAdapter,
                   int iID,
                   int iParam,
                   HMPICONNECT hConnection)
{
   LogMessage(__FILE__, __LINE__, "GattestOnNotify()");
   switch (iID)
   {
   case MPIN_ADAPTER_GETSTART:	 /* Prior to any Get calls for the card */
      break;
   case MPIN_ADAPTER_GETSTOP:		 /* After all Get calls for the card */
      break;
   case MPIN_ADAPTER_PUTSTART: 	 /* Prior to any Put calls for the card */
      break;
   case MPIN_ADAPTER_PUTSTOP:		 /* After all Put calls for the card */
      break;
   case MPIN_ADAPTER_LISTENSTART: /* Prior to any Listen calls for the card */
      break;
   case MPIN_ADAPTER_LISTENSTOP:	 /* After all Listen calls for the card */
      break;
   case MPIN_ADAPTER_LISTENABORT: /* Called to abort a non-polling listener */
      break;
   case MPIN_ADAPTER_MAPABORT:    /* Called to notify that map has been aborted */
      break;
   default:
      break;
   }

   SetErrorCode (hAdapter, MPIRC_SUCCESS);
   return MPIRC_SUCCESS;
}

MPIRC	GattestConnect(HMPICONNECT hConnection,
                  HMPIADAPT hAdapter)
{
   size_t nLen;
   int    iContext;
   MPIRC  rc;
   char   *lpszUsername;
   char   *lpszPassword;
   char   *lpszServer;
   char   *lpszCharset;
   char   *lpszMode;
   char   *lpszBlock;
   char   *lpszOpti;


   LogMessage(__FILE__, __LINE__, "GattestConnect()");
   /* Context says where the call is coming from */
   rc = _mpiPropertyGetInteger(hAdapter, MPIP_ADAPTER_CONTEXT, 0, &iContext); CHKERR(rc);
   if (iContext == MPI_CONTEXT_SOURCE_EVENT)
   {
      /*
      ** If this is a source event, we can't use the concept of a connection -
      ** See GattestGet for more explanation
      */
      SetErrorCode (hConnection, MPIRC_SUCCESS);
      return MPIRC_SUCCESS;
   }

   /* Copy all properties from adatper to connection */
   rc = _mpiPropertyGetText(hAdapter, AP_USERNAME, 0, (const char **)&lpszUsername, &nLen); CHKERR(rc);
   rc = _mpiPropertyGetText(hAdapter, AP_PASSWORD, 0, (const char **)&lpszPassword, &nLen); CHKERR(rc);
   rc = _mpiPropertyGetText(hAdapter, AP_SERVER, 0, (const char **)&lpszServer, &nLen); CHKERR(rc);
   rc = _mpiPropertyGetText(hAdapter, AP_CHARSET, 0, (const char **)&lpszCharset, &nLen); CHKERR(rc);
   rc = _mpiPropertyGetText(hAdapter, AP_MODE, 0, (const char **)&lpszMode, &nLen); CHKERR(rc);
   rc = _mpiPropertyGetText(hAdapter, AP_BLOCK, 0, (const char **)&lpszBlock, &nLen); CHKERR(rc);
   rc = _mpiPropertyGetText(hAdapter, AP_OPTI, 0, (const char **)&lpszOpti, &nLen); CHKERR(rc);
  
   rc = _mpiPropertySetText(hConnection, CP_USERNAME, 0, lpszUsername, strlen(lpszUsername)); CHKERR(rc);
   rc = _mpiPropertySetText(hConnection, CP_PASSWORD, 0, lpszPassword, strlen(lpszPassword)); CHKERR(rc);
   rc = _mpiPropertySetText(hConnection, CP_SERVER, 0, lpszServer, strlen(lpszServer)); CHKERR(rc);
   rc = _mpiPropertySetText(hConnection, CP_CHARSET, 0, lpszCharset, strlen(lpszCharset)); CHKERR(rc);
   rc = _mpiPropertySetText(hConnection, CP_MODE, 0, lpszMode, strlen(lpszMode)); CHKERR(rc);
   rc = _mpiPropertySetText(hConnection, CP_BLOCK, 0, lpszBlock, strlen(lpszBlock)); CHKERR(rc);
   rc = _mpiPropertySetText(hConnection, CP_OPTI, 0, lpszOpti, strlen(lpszOpti)); CHKERR(rc);

EXCEPTION:

   SetErrorCode (hConnection, rc);
   return rc;
}

MPIRC	GattestDisconnect(HMPICONNECT hConnection)
{
   LogMessage(__FILE__, __LINE__, "GattestDisconnect()");
   return MPIRC_SUCCESS;
}


void SetErrorCode(HMPIOBJ hObject, int iRC)
{
   int  i;
   char *lpszMsg = NULL;
   struct
   {
      int  rc;
      char *szErrMsg;
   } stErrors[] = 
   {
      MPIRC_SUCCESS,      "Success",
      ERR_E_CANT_CONNECT, "Failed to connect",
   };
   #define NUM_ERRORS (sizeof(stErrors)/sizeof(stErrors[0]))
   
   LogMessage(__FILE__, __LINE__, "SetErrorCode()");

   for (i = 0;  i < NUM_ERRORS;  i++)
   {
      if (iRC = stErrors[i].rc)
      {
         lpszMsg = stErrors[i].szErrMsg;
         break;
      }
   }

   if (lpszMsg == NULL)
   {
      lpszMsg = "Failure";
   }

   _mpiPropertySetInteger(hObject, MPIP_OBJECT_ERROR_CODE, 0, iRC);
   _mpiPropertySetText(hObject, MPIP_OBJECT_ERROR_MSG, 0, lpszMsg, strlen(lpszMsg));
}

/****************************************************************************/
/*                                                                          */
/* Some log functions.                                                      */
/*                                                                          */
/*                                                                          */
/****************************************************************************/

#ifdef HPUX
#define LIBPATH       "SHLIB_PATH"
#elif defined SOLARIS
#define LIBPATH       "LD_LIBRARY_PATH"
#elif defined WIN32
#define LIBPATH       "PATH"
#else
#define LIBPATH       "LIBPATH"
#endif

int InitLogFile(char *logFileName, int *debugLevel)
{
   char *debugLevelText;
   char *aaaMsg;
   FILE *fp;
   char *envVars[9] = {"AAAHOME", "AAABIN", "AAALOGINDB", "AAAMSG", 
                       "SYBASE", "DSQUERY", LIBPATH, "AAA_GATEWAY_OUTPUT",
                       "UNIQUE_OUTPUT" };
   int i;

   debugLevelText = getenv("DEBUG_GATADAPT");
   if(debugLevelText != NULL)
   {
      *debugLevel = atoi(debugLevelText);
      if(*debugLevel < 0)
         *debugLevel = 0;
      if(*debugLevel > 9)
         *debugLevel = 9;
   }

   strcpy(logFileName, "gattest.log");
   aaaMsg = getenv("AAAMSG");

   if(aaaMsg != NULL)
   {
      if(strlen(aaaMsg) < 1014)
      {
         sprintf(logFileName, "%s%c", aaaMsg, PATH_SEPARATOR);
         strcat(logFileName, "gattest.log");
      }
   }

   remove(logFileName);

   fp = fopen(logFileName, "a+");
   if(fp == NULL)
      return 1;

   fprintf(fp, "Libgattest Log File\n");
   fprintf(fp, "-----------------\n");
   fprintf(fp, "Set DEBUG_GATADAPT for full logging.\n");
   fprintf(fp, "------------------------------------\n");
   fprintf(fp, "Current environment variables:\n");
   fprintf(fp, "------------------------------\n");

   for(i=0; i<9; i++)
   {
      fprintf(fp, "%s : ", envVars[i]);
      if(getenv(envVars[i]))
         fprintf(fp, "%s", getenv(envVars[i]));
      fprintf(fp, "\n");
   }

   fclose(fp);
   return 0;
}


int LogMessage(char *file, int line, ...)
{
   va_list ap;
   char *format;
   time_t currTime;
   struct tm localTime;
   char timeStamp[128];
   FILE *fp;

   currTime = time(0L);
#ifdef WIN32
   localTime = * localtime(&currTime);
#else
   localtime_r(&currTime, &localTime);
#endif
   sprintf(timeStamp, "%02d-%02d-%04d %02d:%02d:%02d ", localTime.tm_mday,
      localTime.tm_mon + 1, localTime.tm_year + 1900,
      localTime.tm_hour, localTime.tm_min, localTime.tm_sec);

   va_start(ap, line);

   fp = fopen("/tmp/gattestempty.log", "a+");
   if(fp == NULL)
      return 1;

   fprintf(fp, "%s - ", timeStamp);
   format = va_arg(ap, char *);
   vfprintf(fp, format, ap); 
   fprintf(fp, "\n");
 
   fclose(fp);

   va_end(ap);
   return 0;
}

#ifdef __cplusplus
}
#endif

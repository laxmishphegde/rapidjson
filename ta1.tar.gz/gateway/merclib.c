/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**
**                     Copyright (C) 1993-1994 by UNICIBLE
**                             All Rights Reserved
**
**                          Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define MERCLIB_C

/************************************************************************
**      Includes
*************************************************************************/
#define  STDIO_H
#define  CTYPE_H
#define  ERRNO_H
#define STDLIB_H
#define UNISTD_H
#define STRING_H
#define SIGNAL_H

#include <unidef.h>	/* Mandatory */

#ifdef NTWIN
#include <windows.h>
#endif

#include <dba.h>
#include <syslib.h>
#include <gen.h>
#include <str.h>
#include <date.h>

#include <dstxpi.h>

#ifndef WIN32
#include <dlfcn.h>
#endif

typedef int BOOL;

#define TRUE  1
#define FALSE 0

#include "merclib.h"
/************************************************************************
**      Constants
*************************************************************************/
/************************************************************************
**      Macros Definitions
*************************************************************************/
/************************************************************************
**      Types  Definitions
*************************************************************************/
/************************************************************************
**      Global Functions
*************************************************************************/

/************************************************************************
**      Static Functions
*************************************************************************/
/************************************************************************
**      Static Data Definitions
*************************************************************************/
static SUBD_LIST_ELEMENT_ST SV_listpointer;

#ifdef WIN32
#define NODL
#endif

#ifdef NODL
static MPIRC (*_mpiMapLoadFile)(HMPIMAP *phMap,const char *pszMapName) = mpiMapLoadFile;
static MPIRC (*_mpiMapGetInputCardObject)(HMPIMAP hMap,int iCard,HMPICARD *phCard) = mpiMapGetInputCardObject;
static MPIRC (*_mpiCardOverrideAdapter)(HMPICARD hCard, const char *pszAlias, int iType) = mpiCardOverrideAdapter;
static MPIRC (*_mpiCardGetAdapterObject)(HMPICARD hCard,HMPIADAPT *phAdapter) = mpiCardGetAdapterObject;
static MPIRC (*_mpiPropertyGetObject)(HMPIOBJ hObject,MPIPROP iProperty,int iIndex,HMPIOBJ *phValue) = mpiPropertyGetObject;
static MPIRC (*_mpiStreamWrite)(HMPISTREAM hStream,const void *pData,size_t nSize) = mpiStreamWrite;
static MPIRC (*_mpiMapRun)(HMPIMAP hMap) = mpiMapRun;
static MPIRC (*_mpiPropertyGetInteger)(HMPIOBJ hObject,MPIPROP iProperty,int iIndex,int	*piValue) = mpiPropertyGetInteger;
static MPIRC (*_mpiMapUnload)(HMPIMAP hMap) = mpiMapUnload;
static MPIRC (*_mpiPropertyGetText)(HMPIOBJ hObject,MPIPROP iProperty,int iIndex,const char **ppText,size_t *pnLen) = mpiPropertyGetText;
static const char * (*_mpiErrorGetText)(MPIRC rc) = mpiErrorGetText;
static MPIRC (*_mpiInitAPI)(const char *lpszResourceConfigFile) = mpiInitAPI;
static MPIRC (*_mpiTermAPI)(void) = mpiTermAPI;
#else
static MPIRC (*_mpiMapLoadFile)(HMPIMAP *phMap,const char *pszMapName) = NULL;
static MPIRC (*_mpiMapGetInputCardObject)(HMPIMAP hMap,int iCard,HMPICARD *phCard) = NULL;
static MPIRC (*_mpiCardOverrideAdapter)(HMPICARD hCard, const char *pszAlias, int iType) = NULL;
static MPIRC (*_mpiCardGetAdapterObject)(HMPICARD hCard,HMPIADAPT *phAdapter) = NULL;
static MPIRC (*_mpiPropertyGetObject)(HMPIOBJ hObject,MPIPROP iProperty,int iIndex,HMPIOBJ *phValue) = NULL;
static MPIRC (*_mpiStreamWrite)(HMPISTREAM hStream,const void *pData,size_t nSize) = NULL;
static MPIRC (*_mpiMapRun)(HMPIMAP hMap) = NULL;
static MPIRC (*_mpiPropertyGetInteger)(HMPIOBJ hObject,MPIPROP iProperty,int iIndex,int	*piValue) = NULL;
static MPIRC (*_mpiMapUnload)(HMPIMAP hMap) = NULL;
static MPIRC (*_mpiPropertyGetText)(HMPIOBJ hObject,MPIPROP iProperty,int iIndex,const char **ppText,size_t *pnLen) = NULL;
static const char * (*_mpiErrorGetText)(MPIRC rc) = NULL;
static MPIRC (*_mpiInitAPI)(const char *lpszResourceConfigFile) = NULL;
static MPIRC (*_mpiTermAPI)(void) = NULL;

static void *dl = NULL;
#endif

/************************************************************************
**      Global Data Definitions
*************************************************************************/

/************************************************************************
**      Static Function Definitions
*************************************************************************/
/************************************************************************
**      Function Prototypes
*************************************************************************/
BOOL			AddItem(char *, int , char ** );
int 			ParseEntityData(const char *, char *, char ** , int);
int             ParseFormatData(const char *, char *, char **);
int				Run_Map(char *, char *);
char            *ResolveMap(char *);
BOOL            get_next_field(char **, char **, char **, char**, int, char **, char **, char**); /* PMSTA39500 - 18092020 - HLA */ /* PMSTA-66218 - JBC - 20250221 */
char			*ExpandVariables(const char *);
void MERC_LogMapError(HMPIMAP, char *, MPIRC);
int CopyAndReplace0xa(char *, char **);
/************************************************************************
**      External functions.
*************************************************************************/


/************************************************************************
**
**  Function    :   LoadDescFile					
**  Description :   Loads Description file into a Structure List
**					
**					
**					 
**  Arguments    :  listpointer - pointer to a SUBD_LIST_ELEMENT_STP structure
**					
**					
**
**  Return      :   int
**
************************************************************************/
int LoadDescFile(char * attFileName)
{
   FILE     *filePtr;
   std::string mappath;
   std::string mapfile;
   char     *Buffer = (char *)NULL;
   char     separator[] = ";";
   char     spaceTok[] = " ";
   char     ent[80];
   char     *endLine = NULL;
   char     *Tok = NULL;
   char     *startLine = NULL;
   char     **ListofFields = NULL;
   char     attribute_file[512]; 
   char     strBuf[255];
   int      outtoks = 0;
   int      numF= 0;
   size_t   fLen;
   char     *tmpPtr;
   char     *extendedFilePath;

   GEN_GetApplInfo(ApplEventMapFile, mapfile);

   if (mapfile.empty())
   {
       mapfile = "map.txt";
   }

	GEN_GetApplInfo(ApplEventMapPath, mappath);

    if (mappath.empty() || mappath.find_first_not_of(" \t\n") == std::string::npos)
		if(SYS_GetEnv("AAAHOME") == NULL)
			return 1;
		else
#ifdef UNIX
			sprintf(attribute_file ,"%s/%s",SYS_GetEnv("AAAHOME"),mapfile.c_str());
#else
			sprintf(attribute_file ,"%s\\%s",SYS_GetEnv("AAAHOME"),mapfile.c_str());
#endif
	else
#ifdef UNIX
		sprintf(attribute_file ,"%s/%s",mappath.c_str(),mapfile.c_str());
#else
		sprintf(attribute_file ,"%s\\%s",mappath.c_str(),mapfile.c_str());
#endif

	extendedFilePath = ExpandVariables(attribute_file);

   if(extendedFilePath == NULL)
   {
      sprintf(strBuf, "Error opening attribute description file (%s).",	attribute_file);
      MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, strBuf);
      return 1;
   }
   
   if(attFileName != NULL)
      filePtr = fopen(attFileName , "rt");
   else
      filePtr = fopen(extendedFilePath , "rt");

   FREE(extendedFilePath);

   if(filePtr == NULL)
   {
      sprintf(strBuf, "Error opening attribute description file (%s).",	attribute_file);
      MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, strBuf);
		return 1;
	}
   if(fseek(filePtr, 0, SEEK_END))
   {
      sprintf(strBuf, "Error reading attribute description file (%s).",	attribute_file);
      MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, strBuf);
      fclose(filePtr);
		return 1;
	}
   if((fLen = ftell(filePtr)) == -1L)
   {
      sprintf(strBuf, "Error reading attribute description file (%s).",	attribute_file);
      MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, strBuf);
      fclose(filePtr);
		return 1;
	}
   if(fseek(filePtr, 0, SEEK_SET))
   {
      sprintf(strBuf, "Error reading attribute description file (%s).",	attribute_file);
      MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, strBuf);
      fclose(filePtr);
		return 1;
	}

	Buffer = (char *)CALLOC(fLen+1 , sizeof(char));
   if(Buffer == NULL)
   {
      MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
      fclose(filePtr);
      return 1;
   }

    (void)fread(Buffer ,  1, fLen, filePtr );

   if(ferror(filePtr))
   {
      sprintf(strBuf, "Error reading attribute description file (%s).",	attribute_file);
      MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, strBuf);
      fclose(filePtr);
		return 1;
	}

   fclose(filePtr);

   tmpPtr = Buffer;

	while(((endLine = strchr(tmpPtr ,'\n')) != NULL))
	{
		startLine = tmpPtr;
		tmpPtr = endLine + 1;
		*endLine = '\0';
		Tok = SYS_StrTok(startLine , separator,&startLine );	/* PMSTA-66218 - JBC - 20250221 not thread safe */
		strcpy( ent , Tok);
		Tok = SYS_StrTok( NULL , spaceTok, &startLine );
		if((ListofFields = (char **)CALLOC(1 , sizeof(char **))) == NULL)
		{
			MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
         FREE(Buffer);
			return 1;
		}
		
		while(Tok)
		{
			ListofFields[outtoks++] = strdup(Tok);
			if((ListofFields = (char **)REALLOC(ListofFields ,
						   (outtoks +1)*sizeof(char**))) == NULL)
			{
				MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
            FREE(Buffer);
				return 1;
			}
			Tok = SYS_StrTok( NULL , spaceTok,&startLine);
      }
      numF = outtoks;
      outtoks = 0;
      if(!AddItem(ent , numF, ListofFields))
		{
         sprintf(strBuf, "Failed to add item (%s).", ent);
         MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, strBuf);
         FREE(Buffer);
			return 1;
		}
	}
   FREE(Buffer);
	return 0;
}

/************************************************************************
**
**  Function    :   AddItem					
**  Description :   Adds a new structure to the list and assigns the fields
**					of the structure					
**
**  Arguments    :  listpointer - pointer to a SUBD_LIST_ELEMENT structure
**					ent		- Entity name
**					numF		- Number of fields 
**					ListofFields
**
**
**  Return      :   pointer to SUBD_LIST_ELEMENT structure
**
************************************************************************/
BOOL AddItem(char *ent, int numF, char **ListofFields)
{
   SUBD_LIST_ELEMENT_STP newElement;
   SUBD_LIST_ELEMENT_STP listpointer = &SV_listpointer;
   static int firstTime = 1;

   if(firstTime)
   {
      listpointer->link = NULL;
      strcpy(listpointer->entity ,  ent);
      listpointer->nFields = numF;
      listpointer->fieldList = ListofFields;
      firstTime = 0;
      return TRUE;
   }
   while(listpointer -> link != NULL)
      listpointer = listpointer->link;
   newElement = (SUBD_LIST_ELEMENT_STP) malloc(sizeof(SUBD_LIST_ELEMENT_ST));
   if(newElement == NULL)
      return FALSE;
   listpointer->link = newElement;
   newElement -> link = NULL;
   strcpy(newElement -> entity ,  ent);
   newElement -> nFields = numF;
   newElement -> fieldList = ListofFields;
   return TRUE;
}

/* PMSTA-66218 - JBC - 20250221 remove character from src */
void STRING_remove(char *src, unsigned char c)
{   
    int i =0, j = 0;
    size_t len = strlen(src);
    MemoryPool mp;
    char * remTemp = (char *)mp.calloc(FILEINFO, len+1, sizeof(char));     /* PMSTA-66218 - JBC - 20250221 : thread unsafe static var  */

    for (i = 0; i < len; i++)
    {
        if ((unsigned char)src[i] != c)
        {
            remTemp[j] = src[i];
            j++;
        }
    }
    //add null char at end
    remTemp[j] = '\0';
    if(j<i)
    {
		strcpy(src,remTemp);
    }
}

BOOL get_next_field(char **Databuffer, char **Fname, char **Fnewval, char**Foldval, int AuditFlag, char **format, char **FtypeName, char **remDataBuffer) /* PMSTA39500 - 18092020 - HLA */ /* PMSTA-66218 - JBC - 20250221 */
{
   int	          flagSun1=FALSE, flagSun2=FALSE; /* PMSTA-66218 - JBC - 20250221  : thread unsafe static var  */
   char 		      *SunVal;
   char		      *NewVal, *OldVal;
   size_t         len;
   int		      FirstSun=FALSE,
                  SecondSun=FALSE;

   if(AuditFlag)
   {

      /* Step 1 : Get the field name */

      if(*Fname==NULL)
      {
         flagSun1 = flagSun2 = FALSE; /* reset flags because this is a new record */
         SYS_StrTok(*Databuffer, " ",&(*remDataBuffer));    /* Skip the 'action' field */ /* PMSTA-66218 - JBC - 20250221 : not thread safe */
      }

      *Fname = SYS_StrTok((char *)NULL, "=",&(*remDataBuffer));
      if(*Fname==NULL)
         return FALSE;

      if(flagSun2) /* skip leading ';' left during last SYS_StrTok call */
         *Fname = &(*Fname)[1];

      /* Step 2 : Get the NEW value of that field */
      *Fnewval = SYS_StrTok((char *)NULL, FS_STR,&(*remDataBuffer));
      if(*Fnewval == NULL)
         return FALSE;

      /* check for "little suns"... */
      FirstSun  = ((*Fnewval)[0] == US_SEP);
      if(FirstSun)
         SecondSun = ((*Fnewval)[strlen(*Fnewval)-1] == US_SEP);

      /*
       * Complete the field value if there is a "little sun" at the
       * beginning of the string, but no "little sun" at the end of it.
       * This means that the end of the field comes later in the
       * Databuffer... So let's go and catch it!
       */
      if(FirstSun && !SecondSun)
      {
         flagSun1 = TRUE;
         /* get string up to the next little sun */
         SunVal = SYS_StrTok((char *)NULL, US_STR,&(*remDataBuffer));
         if(SunVal == NULL)
            return FALSE;  

         /* Concatenate both parts into a new value field
          * and insert Underscore to replace the pipe
          * that was skipped by the previous call to SYS_StrTok
          */

         len = strlen(&(*Fnewval)[1]);
         len += strlen(SunVal);
         NewVal = (char *)CALLOC(len+2,sizeof(char));
         if(!NewVal)
         {
            MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
            return FALSE;
         }
         sprintf(NewVal, "%s_%s", &(*Fnewval)[1], SunVal);
         *Fnewval = NewVal;
      }
      else
         flagSun1 = FALSE;

      /* Step 3 : Get the OLD value of that field */

      *Foldval = SYS_StrTok((char *)NULL, flagSun1 ? FS_STR : RS_STR,&(*remDataBuffer));
      if(*Foldval == NULL)
        return FALSE;

      /* check for "little suns"... */
      FirstSun  = ((*Foldval)[0] == US_SEP);
      if(FirstSun)
         SecondSun = ((*Foldval)[strlen(*Foldval)-1] == US_SEP);

      /*
       * Complete the field value if there is a "little sun" at the
       * beginning of the string, but no "little sun" at the end of it.
       * This means that the end of the field comes later in the
       * Databuffer... So let's go and catch it!
       */
      if(FirstSun && !SecondSun)
      {
        flagSun2 = TRUE;
        /* get string up to the next little sun */
        SunVal = SYS_StrTok((char *)NULL, US_STR,&(*remDataBuffer));
        if(SunVal == NULL)
          return FALSE;

        /* Concatenate both parts into a new value field
         * and insert Underscore to replace the semicolumn
         * that was skipped by the previous call to SYS_StrTok
         */
        len = strlen(&(*Foldval)[1]);
        len += strlen(SunVal);
        OldVal = (char *)CALLOC(len+2,sizeof(char));
        if(!OldVal)
        {
          MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
          return FALSE;
        }
        sprintf(OldVal,"%s_%s",&(*Foldval)[1],SunVal);
        *Foldval = OldVal;
      }
      else
        flagSun2 = FALSE;

      /* Step 4 : Clean up strings 
      
      /* remove leading and trailing spaces from the field name */
      STRING_Trim(*Fname);

      /* remove leading and trailing "Suns" from the field values
       * (the ones that were not already processed) */
      STRING_remove(*Fnewval, US_SEP);	/* PMSTA-66218 - JBC - 20250221  : thread unsafe static var  */
      STRING_remove(*Foldval, US_SEP);	/* PMSTA-66218 - JBC - 20250221  : thread unsafe static var  */

      return TRUE;
  }
  else       /***** Subscription code *****/
  {
      if(*Fname==NULL)
      {
          flagSun2 = FALSE; /* reset flag because this is a new record */
          *Fname = SYS_StrTok(*Databuffer, "=",&(*remDataBuffer));
      }
      else
          *Fname = SYS_StrTok((char *)NULL, "=",&(*remDataBuffer));
      if(*Fname==NULL)
        return FALSE;

      if(flagSun2) /* skip leading ';' left during last SYS_StrTok call */
        *Fname = &(*Fname)[1];

      /*
       * Step 2 : Get the value of that field
       * ------
       */
      *Fnewval = SYS_StrTok((char *)NULL, RS_STR,&(*remDataBuffer));
      if(*Fnewval == NULL)
        return FALSE;

      /* check for "little suns"... */
      FirstSun  = ((*Fnewval)[0] == US_SEP);
      if(FirstSun)
         SecondSun = ((*Fnewval)[strlen(*Fnewval)-1] == US_SEP);

      /*
       * Complete the field value if there is a "little sun" at the
       * beginning of the string, but no "little sun" at the end of it.
       * This means that the end of the field comes later in the
       * Databuffer... So let's go and catch it!
       */
      if(FirstSun && !SecondSun)
      {
        flagSun2 = TRUE;
        /* get string up to the next little sun */
        SunVal = SYS_StrTok((char *)NULL, US_STR,&(*remDataBuffer));
        if(SunVal == NULL)
          return FALSE;

        /* Concatenate both parts into a new value field
         * and insert Underscore to replace the pipe
         * that was skipped by the previous call to SYS_StrTok
         */
        len = strlen(&(*Fnewval)[1]);
        len += strlen(SunVal);
        NewVal = (char *)CALLOC(len+2,sizeof(char));
        if(!NewVal)
        {
          MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
          return FALSE;
        }
        sprintf(NewVal,"%s;%s",&(*Fnewval)[1],SunVal);
        *Fnewval = NewVal;
      }
      else
        flagSun2 = FALSE;

      /*
       * Step 4 : Clean up strings
       * ------
       */
      /* remove leading and trailing spaces from the field name */
      STRING_Trim(*Fname);

      /* remove leading and trailing "Suns" from the field values
       * (the ones that were not already processed) */
      STRING_remove(*Fnewval, US_SEP);	/* PMSTA-66218 - JBC - 20250221 : thread unsafe static var  */

      bool isFormat = (**Fname != ':' && strchr(*Fname, ':') != NULL);
 
      if (format != NULL && isFormat)
      {
          char *scan = strchr(*Fname, ':');

          *scan = 0;
          *format = *Fname;
          *Fname = ++scan;

		  /* PMSTA39500 - 18092020 - HLA - Format Element Data Type */
		  scan = strchr(*Fname, ':');

		  if (scan != NULL) /*PMSTA48516 - HLA - 17082022 */
		  {
			  *scan = 0;
			  *FtypeName = ++scan;
		  }
      }
      else
      if ((format != NULL && !isFormat) ||
          (format == NULL && isFormat))
      {
          return get_next_field(Databuffer, Fname, Fnewval, Foldval, AuditFlag, format, FtypeName,remDataBuffer); /* PMSTA-66218 - JBC - 20250221 */
      }
      return TRUE;

      /***** End of Subscription code *****/
  }
}

/************************************************************************
**
**  Function    :   ParseEntityData					
**  Description :   Loads Description file into a Structure List
**					
**  Arguments    :  entityname		- Entity name
**					data            - data from event
**                  total_buf       - data to send to Mercator
**                  AuditF          - Is it data from audit
**
**  Return      :   int             - TRUE: success
**                                  - FALSE: failure
**
************************************************************************/
int ParseEntityData(const char *entityname, char *data, char **total_buf, int AuditF)
{
   SUBD_LIST_ELEMENT_STP listpointer = &SV_listpointer;

   Field	*dataField = NULL;
   int		nfield;
   char		*littleBuff1, *littleBuff2;

   char		*NewBuff = NULL, *OldBuff=NULL;
   size_t   NewBufLen = 0, OldBufLen = 0;
   size_t   littleLen1, littleLen2;

   char		strBuf[255];

   int		testcomp = -1; /* DLA - 010215 - 0 --> -1 */
   int		FieldsProcessed = 0;

   int		i = 0;
   int		n = 0;

   /* DLA - 010215 testcomp = strcmp(listpointer -> entity, entityname); */
   while(testcomp && listpointer!=NULL) /* DLA - 010215 - ajout du teste listpointer!=NULL */
   {
     testcomp = strcmp(listpointer -> entity, entityname);  /* DLA - 010215 - Inversion des 2 lignes car plantage si pas trouve */
     if(testcomp == 0)   /* VST - 010426 on arrivait tous le temps sur l'entite
                         suivante :-) */
	break;
     listpointer = listpointer -> link;
   }

   if(!testcomp)
   {
     char *tempData=NULL, *tempName=NULL, *tempNewValue=NULL, *tempOldValue=NULL, *remTempData = NULL;

     /* STEP 1 : Store all data names an values into a Field structure
      * ------
      */

     /* Copy data in a temporary buffer for processing */
     tempData = (char *)CALLOC(strlen(data)+2, sizeof(char));
     if(!tempData)
     {
       MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
       return FALSE;
     }
     strcpy(tempData, data);
     nfield = 0;

     /* get all field names and fields values, separated by 'RS_SEP' */
     while(get_next_field(&tempData, &tempName, &tempNewValue, &tempOldValue, AuditF, NULL, NULL, &remTempData))
     {
        if (*tempName == ':')
            tempName++;

       /* (re-)allocate Field structure size */
       if(!nfield)
         dataField = (Field *)CALLOC(1,sizeof(Field));
       else
         dataField = (Field *)REALLOC(dataField,(nfield+1) * sizeof(Field));
       if(!dataField)
       {
         MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
         FREE(tempData);
         return FALSE;
       }
     
       /* VST LN11787 */

       dataField[nfield].name   = (char *)CALLOC((strlen(tempName)+1),sizeof(char));
       if( !dataField[nfield].name )
       {
          MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
          FREE(tempData);
          return FALSE;
       }
       strcpy(dataField[nfield].name,tempName);


       if(CopyAndReplace0xa(tempNewValue, &(dataField[nfield].newVal)))
       {
          MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
          FREE(tempData);
          return FALSE;
       }

       if(AuditF)
          if(CopyAndReplace0xa(tempOldValue, &(dataField[nfield].oldVal)))
          {
             MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
             FREE(tempData);
             return FALSE;
          }

       nfield ++;
     } /* end of while(get_next_field()) */
     FREE(tempData);

     if(!nfield) /* NO FIELDS IN THE BUFFER... */
     {
       sprintf(strBuf, "No data fields for Entity (%s)", entityname);
       MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, strBuf);
       return FALSE;
     }

     /* STEP 2 : Flush all values into a working buffer, ordered as the Attfile
      * ------
      */

     for(n=0 ; n < (listpointer->nFields); n++ )
     {
       /* Search for Attribute name into Data names */
       for(i=0; i<nfield; i++)
       {
         if(!strcmp(dataField[i].name,listpointer->fieldList[n]))
           break;
       }
       if(i == nfield) /* Attribute name not found */
       {
		   if(AuditF)
		   {
				NewBufLen += 2;
				OldBufLen += 2;

				if(!NewBuff)
					NewBuff = (char *)CALLOC(NewBufLen, sizeof(char));
				else
					NewBuff = (char *)REALLOC(NewBuff, NewBufLen * sizeof(char));

				if(!NewBuff)
				{
					MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
					for(i=0; i<nfield; i++)
					{
						FREE(dataField[i].name);
						FREE(dataField[i].newVal);
						FREE(dataField[i].oldVal);
					}
					FREE(dataField);
					return FALSE;
				}

				if(!OldBuff)
	                OldBuff = (char *)CALLOC(OldBufLen, sizeof(char));
		        else
			        OldBuff = (char *)REALLOC(OldBuff, OldBufLen * sizeof(char));
				if(!OldBuff)
				{
					MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
					for(i=0; i<nfield; i++)
					{
	                    FREE(dataField[i].name);
		                FREE(dataField[i].newVal);
			            FREE(dataField[i].oldVal);
				    }
					FREE(dataField);
					return FALSE;
				}

				if(n > 0)
				{
			        strcat(NewBuff, RS_STR);
				    strcat(OldBuff, RS_STR);
				}

				FieldsProcessed++;
		   }
		   else
		   {
				NewBufLen += 2;

				if(!NewBuff)
					NewBuff = (char *)CALLOC(NewBufLen, sizeof(char));
				else
					NewBuff = (char *)REALLOC(NewBuff, NewBufLen * sizeof(char));

				if(!NewBuff)
				{
					MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
					for(i=0; i<nfield; i++)
					{
						FREE(dataField[i].name);
						FREE(dataField[i].newVal);
					}
					FREE(dataField);
					return FALSE;
				}
				if(n > 0)
			        strcat(NewBuff, RS_STR);

				FieldsProcessed++;
		   }

         continue;
       }

       /* allocate a little buffer for Field value and store formatted value */
       if(AuditF)
       {
            littleLen1 = (n > 0) ? strlen(dataField[i].newVal)+3 : strlen(dataField[i].newVal)+2;
            littleLen2 = (n > 0) ? strlen(dataField[i].oldVal)+3 : strlen(dataField[i].oldVal)+2;
            littleBuff1 = (char *)CALLOC(littleLen1,sizeof(char));
            littleBuff2 = (char *)CALLOC(littleLen2,sizeof(char));
            if(!littleBuff1 || !littleBuff2)
            {
                MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
                for(i=0; i<nfield; i++)
                {
                    FREE(dataField[i].name);
                    FREE(dataField[i].newVal);
                    FREE(dataField[i].oldVal);
                }
                FREE(dataField);
                if (littleBuff1) FREE(littleBuff1);
                if (littleBuff2) FREE(littleBuff2);
                return FALSE;
            }
            if(n > 0)
            {
               sprintf(littleBuff1, "%c%s", RS_SEP, dataField[i].newVal);
               sprintf(littleBuff2, "%c%s", RS_SEP, dataField[i].oldVal);
            }
            else
            {
               sprintf(littleBuff1, "%s", dataField[i].newVal);
               sprintf(littleBuff2, "%s", dataField[i].oldVal);
            }

            /* (re-)allocate space to add current values */
            NewBufLen += strlen(littleBuff1)+1;
            OldBufLen += strlen(littleBuff2)+1;
            if(!NewBuff)
                NewBuff = (char *)CALLOC(NewBufLen,sizeof(char));
            else
                NewBuff = (char *)REALLOC(NewBuff,NewBufLen * sizeof(char));
            if(!NewBuff)
            {
                MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
                for(i=0; i<nfield; i++)
                {
                    FREE(dataField[i].name);
                    FREE(dataField[i].newVal);
                    FREE(dataField[i].oldVal);
                }
                FREE(dataField);
                FREE(littleBuff1);
                FREE(littleBuff2);
                return FALSE;
            }
            if(!OldBuff)
                OldBuff = (char *)CALLOC(OldBufLen,sizeof(char));
            else
                OldBuff = (char *)REALLOC(OldBuff,OldBufLen * sizeof(char));
            if(!OldBuff)
            {
                MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
                for(i=0; i<nfield; i++)
                {
                    FREE(dataField[i].name);
                    FREE(dataField[i].newVal);
                    FREE(dataField[i].oldVal);
                }
                FREE(dataField);
                FREE(littleBuff1);
                FREE(littleBuff2);
                return FALSE;
            }

            /* Store values in their respective buffers */
            strcat(NewBuff,littleBuff1);
            strcat(OldBuff,littleBuff2);
            FieldsProcessed++;
            FREE(littleBuff1);
            FREE(littleBuff2);
       }
       else
       {    
           /***** Subscription code *****/
            littleLen1 = (n > 0) ? strlen(dataField[i].newVal)+3 : strlen(dataField[i].newVal)+2;
            littleBuff1 = (char *)CALLOC(littleLen1,sizeof(char));
            if(!littleBuff1)
            {
                MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
                for(i=0; i<nfield; i++)
                {
                    FREE(dataField[i].name);
                    FREE(dataField[i].newVal);
                }
                FREE(dataField);
                return FALSE;
            }

            if(n > 0)
               sprintf(littleBuff1, "%c%s", RS_SEP, dataField[i].newVal);
            else
               sprintf(littleBuff1, "%s", dataField[i].newVal);
            
            /* (re-)allocate space to add current values */
            NewBufLen += strlen(littleBuff1)+1;
            if(!NewBuff)
                NewBuff = (char *)CALLOC(NewBufLen,sizeof(char));
            else
                NewBuff = (char *)REALLOC(NewBuff,NewBufLen * sizeof(char));
            if(!NewBuff)
            {
                MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
                for(i=0; i<nfield; i++)
                {
                    FREE(dataField[i].name);
                    FREE(dataField[i].newVal);
                }
                FREE(dataField);
                FREE(littleBuff1);
                return FALSE;
            }

            /* Store values in the buffer */
            strcat(NewBuff,littleBuff1);
            FieldsProcessed++;
            FREE(littleBuff1);

            /***** End of Subscription code *****/

       }
     } /* end of for(n=0 ; n < (listpointer->nFields); n++ ) */

     if(!FieldsProcessed)
     {
       sprintf(strBuf, "No fields processed for Entity (%s)", entityname);
       MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, strBuf);
       return FALSE;
     }

     /* STEP 3 : Format final buffer and store working buffer
      * ------
      */

     /* Allocate final buffer */
     if(AuditF)
     {
        if(!(*total_buf))
        *total_buf = (char *)CALLOC(NewBufLen+1+OldBufLen+3,sizeof(char));
        else
        *total_buf = (char *)REALLOC(*total_buf,(NewBufLen+1+OldBufLen+3)*sizeof(char));
#ifdef UNIX
        sprintf(*total_buf, "%s%c%s\n", NewBuff, FS_SEP, OldBuff);
#else 
        sprintf(*total_buf, "%s%c%s\r\n", NewBuff, FS_SEP, OldBuff);
#endif
        for(i=0; i<nfield; i++)
        {
            FREE(dataField[i].name);
            FREE(dataField[i].newVal);
            FREE(dataField[i].oldVal);
        }
        FREE(dataField);
        FREE(NewBuff);
        FREE(OldBuff);
     }
     else
     {  
         /***** Subscription code *****/
        *total_buf = (char *)CALLOC(NewBufLen+3,sizeof(char));
#ifdef UNIX
        sprintf(*total_buf, "%s\n",NewBuff);
#else 
        sprintf(*total_buf, "%s\r\n",NewBuff);
#endif
        for(i=0; i<nfield; i++)
        {
            FREE(dataField[i].name);
            FREE(dataField[i].newVal);
        }
        FREE(dataField);
        FREE(NewBuff);
        /***** End of Subscription code *****/
     }
   }
   else
   {
     sprintf(strBuf, "Entity (%s) not found in reference list", entityname);
     MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, strBuf);
	 return FALSE;
   }
   return TRUE;
}

/************************************************************************
**
**  Function    :   ParseFormatData
**  Description :
**
**  Arguments    :  data            - data from event
**                  total_buf       - data to send to Mercator
**
**  Return      :   int             - TRUE: success
**                                  - FALSE: failure
**
************************************************************************/
int ParseFormatData(const char *format, char *data, char **total_buf)
{

    Field	*dataField = NULL;
    int		nfield;

    char	*buff = NULL;
    size_t	bufLen = 0;

    char	*littleBuff = NULL;
    size_t   littleBuffLen;

    int		i = 0;
    int		n = 0;

	char
		*tempData = NULL, *tempName = NULL, *tempTypeName = NULL,
            *tempNewValue = NULL, *tempOldValue = NULL, *tempFormat = NULL, *remTempData = NULL;
	DBA_DYNFLD_STP sFmtSt = NULL;

	/* PMSTA39500 - 18092020 - HLA */
	if ((sFmtSt = ALLOC_DYNST(S_Fmt)) == NULL)
	{
		return(RET_MEM_ERR_ALLOC);
	}

	SET_CODE(sFmtSt, S_Fmt_Cd, format);

	if (DBA_Get2(Fmt, UNUSED, S_Fmt, sFmtSt, S_Fmt, &sFmtSt, UNUSED, UNUSED, UNUSED) != RET_SUCCEED)
	{
		FREE_DYNST(sFmtSt, S_Fmt);
		return(RET_DBA_ERR_INVALID_FORMAT);
	}

    /* Copy data in a temporary buffer for processing */
    tempData = (char *)CALLOC(strlen(data) + 2, sizeof(char));
    if (!tempData)
    {
		FREE_DYNST(sFmtSt, S_Fmt);
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
        return FALSE;
    }

    strcpy(tempData, data);

    nfield = 0;
    /* get all field names and fields values, separated by 'RS_SEP' */
    while (get_next_field(&tempData, &tempName, &tempNewValue, &tempOldValue, false, &tempFormat, &tempTypeName, &remTempData))
    {

        /* (re-)allocate Field structure size */
        if (!nfield)
            dataField = (Field *)CALLOC(1, sizeof(Field));
        else
            dataField = (Field *)REALLOC(dataField, (nfield + 1) * sizeof(Field));
        if (!dataField)
        {
            MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
            FREE(tempData);
			FREE_DYNST(sFmtSt, S_Fmt);
            return FALSE;
        }

        /* VST LN11787 */

        dataField[nfield].name = (char *)CALLOC((strlen(tempName) + 1), sizeof(char));
        if (!dataField[nfield].name)
        {
            MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
            FREE(tempData);
			FREE_DYNST(sFmtSt, S_Fmt);
            return FALSE;
        }
        strcpy(dataField[nfield].name, tempName);

		/* PMSTA39500 - 18092020 - HLA */
		dataField[nfield].dataTypeSqlname = (char *)CALLOC((strlen(tempTypeName) + 1), sizeof(char));
		if (!dataField[nfield].dataTypeSqlname)
		{
			MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
			FREE(tempData);
			FREE_DYNST(sFmtSt, S_Fmt);
			return FALSE;
		}
		strcpy(dataField[nfield].dataTypeSqlname, tempTypeName);

        if (CopyAndReplace0xa(tempNewValue, &(dataField[nfield].newVal)))
        {
            MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
            FREE(tempData);
			FREE_DYNST(sFmtSt, S_Fmt);
            return FALSE;
        }

        nfield++;
    } /* end of while(get_next_field()) */

    FREE(tempData);

    for (n = 0; n < nfield; n++)
    {
        littleBuffLen = strlen(format) + strlen(dataField[n].name) + strlen(dataField[n].dataTypeSqlname) + strlen(dataField[n].newVal) + 5; /* PMSTA39500 - 18092020 - HLA */
        littleBuff = (char *)CALLOC(littleBuffLen, sizeof(char));
        if (!littleBuff)
        {
            MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
            for (i = 0; i < nfield; i++)
            {
                FREE(dataField[i].name);
                FREE(dataField[i].newVal);
				FREE(dataField[i].dataTypeSqlname);
            }
            FREE(dataField);
			FREE_DYNST(sFmtSt, S_Fmt);
            return FALSE;
        }
		/* PMSTA39500 - 18092020 - HLA */
		if (n == nfield - 1)
		{
			if (GET_ENUM(sFmtSt, S_Fmt_NatEn) == FmtNat_SubscriptionEnrichment)
			{
				sprintf(littleBuff, "%s%c%s%c%s%c", dataField[n].name, US_SEP, dataField[n].newVal, GS_SEP, dataField[n].newVal, GS_SEP);
			}
			else if (GET_ENUM(sFmtSt, S_Fmt_NatEn) == FmtNat_Subscription)
			{
				sprintf(littleBuff, "%s%c%s%c", dataField[n].name, US_SEP, dataField[n].newVal, GS_SEP);
			}
            else if (GET_ENUM(sFmtSt, S_Fmt_NatEn) == FmtNat_Export) /* PMSTA-61571 - Deepthi - 20241108 */
            {
                sprintf(littleBuff, "%s:%s%c%s%c", format, dataField[n].name, US_SEP,
                    dataField[n].newVal, GS_SEP);
            }
			else
			{
				sprintf(littleBuff, "%s%c%s%c%s%c", dataField[n].name, US_SEP, dataField[n].dataTypeSqlname, US_SEP, dataField[n].newVal, GS_SEP);
			}
		}
		else
		{
			if (GET_ENUM(sFmtSt, S_Fmt_NatEn) == FmtNat_SubscriptionEnrichment)
			{
				sprintf(littleBuff, "%s%c%s%c%s%c%c", dataField[n].name, US_SEP, dataField[n].newVal, GS_SEP, dataField[n].newVal, GS_SEP, FS_SEP);
			}
			else if (GET_ENUM(sFmtSt, S_Fmt_NatEn) == FmtNat_Subscription)
			{
				sprintf(littleBuff, "%s%c%s%c", dataField[n].name, US_SEP, dataField[n].newVal, GS_SEP);
			}
            else if (GET_ENUM(sFmtSt, S_Fmt_NatEn) == FmtNat_Export) /* PMSTA-61571 - Deepthi - 20241108 */
            {
                sprintf(littleBuff, "%s:%s%c%s%c", format, dataField[n].name, US_SEP,
                    dataField[n].newVal, GS_SEP);
            }
			else
			{
				sprintf(littleBuff, "%s%c%s%c%s%c%c", dataField[n].name, US_SEP, dataField[n].dataTypeSqlname, US_SEP, dataField[n].newVal, GS_SEP, FS_SEP);
			}
		}

        /* (re-)allocate space to add current values */
        bufLen += strlen(littleBuff) + 1;
        if (!buff)
            buff = (char *)CALLOC(bufLen, sizeof(char));
        else
            buff = (char *)REALLOC(buff, bufLen * sizeof(char));
 
        if (!buff)
        {
            MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
            for (i = 0; i < nfield; i++)
            {
                FREE(dataField[i].name);
                FREE(dataField[i].newVal);
				FREE(dataField[i].dataTypeSqlname);
            }
            FREE(dataField);
            FREE(littleBuff);
			FREE_DYNST(sFmtSt, S_Fmt);
            return FALSE;
        }

        /* Store values in the buffer */
        strcat(buff, littleBuff);
        FREE(littleBuff);
    }

    *total_buf = (char *)CALLOC(bufLen + 3, sizeof(char));
#ifdef UNIX
    sprintf(*total_buf, "%s\n", buff);
#else 
    sprintf(*total_buf, "%s\r\n", buff);
#endif
    for (i = 0; i < nfield; i++)
    {
        FREE(dataField[i].name);
        FREE(dataField[i].newVal);
		FREE(dataField[i].dataTypeSqlname);
    }
	FREE_DYNST(sFmtSt, S_Fmt);
    FREE(dataField);
    FREE(buff);

    return TRUE;
}


/************************************************************************
**
**  Function      : ResolveMap().
**
**  Description   : Resolves any Environment variables in the map path.
**                  The Field 'A_Map_Storage' could contain the following
**                  combination of values: (But at least a map name).
**                      - A map name.
**                      - A path.
**                      - An envirronnement variable.
**                  The appl param "SUBSCRIPTION_MAP_PATH" could also contain 
**                  a relative path.
**                  NB: Path found in 'SUBSCRIPTION_MAP_PATH' is added with the one
**                      found in the Field 'A_Map_Storage'.
**
**                  Ex: /net/Mercator/Instrument_Map.map
**                      $MAP_PATH/Instrument_Map.map
**                      /net/Mercator/$MAP_SUB_DIR/Instrument_Map.map
**
**  Arguments     : pointer to char.
**
**  Modifications : 18/01/01 - GRD - Ref.:REF5602.
*************************************************************************/
char *ResolveMap(char * map_name, std::string map_path)
{
	char		    *resolve_map = (char *)NULL;
	char			*expanded_map = NULL;
	char			*expanded_path = NULL;
	size_t          len;

    /*
     * Map location is calculated as followed:
     *      'SUBSCRIPTION_MAP_PATH', (if any) +
     *      content of the 'A_Map_Storage' field taken from 'map' table.
     *      (if an environnement variable is found in 'A_Map_Storage', it is 
     *      also used.
     * 18/01/01 - GRD - REF5602.
     */

    /* First, is there any map path in appl param? */
	if(map_path.length() > 0)
	{
		expanded_path = ExpandVariables(map_path.c_str());
	    if (expanded_path == NULL)
		{
        	MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
		    return NULL;
		}
	}

	if(strlen(map_name))
	{
		expanded_map = ExpandVariables(map_name);
	    if (expanded_map == NULL)
		{
			if(expanded_path)
				FREE(expanded_path);
        	MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
		    return NULL;
		}
	}

	len = 0;
	if(expanded_path)
		len += strlen(expanded_path);
	if(expanded_map)
		len += strlen(expanded_map);

    if ((resolve_map = (char *)CALLOC(len + 1 , sizeof(char))) == (char *)NULL)
	{
		if(expanded_path)
			FREE(expanded_path);
		if(expanded_map)
			FREE(expanded_map);
		MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
        return NULL;
    }

	if(expanded_path)
		strcpy(resolve_map, expanded_path);

	if(expanded_map)
		strcat(resolve_map, expanded_map);

	if(expanded_path)
		FREE(expanded_path);
	if(expanded_map)
		FREE(expanded_map);

    return(resolve_map);
}

/************************************************************************
**
**  Function      : ExpandVariables().
**
**  Description   : Expand any environment variables in the map path.
**                  Variable name is considered until ! isalnum()
**
**  Arguments     : pointer to char.
**  Return        : pointer to char with expanded variables. must be freed by the caller.
**
**  Modifications : 02-09-09 VST LN7797
*************************************************************************/
char *ExpandVariables(const char * string)
{
	char *result = NULL;
	char *dollarPos = NULL, *dollarEnd = NULL;
	char *varValue = NULL;
	char *emptyString = (char *)"";
	size_t iDollarBeg, iDollarEnd;

	result = (char *)CALLOC(strlen(string)+1 , sizeof(char));
	if(result == NULL)
	{
		MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
		return NULL;
	}
	strcpy(result, string);

	dollarPos = dollarEnd = strchr(result, (int)'$');

	iDollarBeg = dollarPos - result;

	if(dollarPos != NULL)
	{

		dollarPos++; 
		dollarEnd++;
		while(isalnum((int)(*dollarEnd)) || *dollarEnd == '_')
			dollarEnd++;
		*dollarEnd = '\0';
		iDollarEnd = dollarEnd - result;

		varValue = SYS_GetEnv(dollarPos);

		if(varValue == NULL)
			varValue = emptyString;

		result = (char *)REALLOC(result, strlen(string) + 1 + strlen(varValue));
		if(result == NULL)
		{
			MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
			return NULL;
		}
	
		strcpy(result + iDollarBeg, varValue);
		strcat(result, string + iDollarEnd);

	}

	return result;
}



/************************************************************************
**
**  Function    :   Run_Map					
**  Description :   Runs a Mercator Map
**
**  Arguments    :  listpointer	- pointer to a SUBD_LIST_ELEMENT_ST structure
**                  In_Buff - data for the Mercator map
**                  map_name - the map name(complete path) 
**					
**  Return      :   int	map return (success/failure)
**
************************************************************************/
int Run_Map(char *In_Buff, char *map_name)
{
   HMPIMAP   hMap;
   HMPIADAPT  hAdapter;
   HMPICARD  hCard;
   HMPISTREAM  hStream;
   MPIRC   rc;
   int iRC;
   char strBuf[1024];
   size_t inLen;
   UChar *ucBuff = NULL;
   char *utf8Buff = NULL;
   int    utf8Len = 0;
   int    ucLen = 0;
   CURRENTCHARSETCODE_ENUM  charsetCode = CurrentCharsetCode_IsNull;
   TEXT_CONVERSION_TYPE_ENUM  textConversionEn = TextConversion_Utf8;

   rc = _mpiMapLoadFile (&hMap, map_name);
   if(rc != MPIRC_SUCCESS)
   {
      sprintf(strBuf, "Cannot load map file %s. Return code %d", map_name, rc);
      MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, strBuf);
      return rc;
   }

   rc = _mpiMapGetInputCardObject (hMap, 1, &hCard);
   if(rc != MPIRC_SUCCESS)
   {
      MERC_LogMapError(hMap, (char *)"GetInputCard", rc);
      return rc;
   }

   rc = _mpiCardOverrideAdapter(hCard,NULL, MPI_ADAPTYPE_STREAM);
   if(rc != MPIRC_SUCCESS)
   {
      MERC_LogMapError(hMap, (char *)"CardOverrideAdapter", rc);
      return rc;
   }

   rc = _mpiCardGetAdapterObject (hCard, &hAdapter);
   if(rc != MPIRC_SUCCESS)
   {
      MERC_LogMapError(hMap, (char *)"CardGetAdapterObject", rc);
      return rc;
   }

   rc = _mpiPropertyGetObject (hAdapter, MPIP_ADAPTER_DATA_FROM_ADAPT, 0, 
      &hStream); 
   if(rc != MPIRC_SUCCESS)
   {
      MERC_LogMapError(hMap, (char *)"GetDataStream", rc);
      return rc;
   }

   inLen = strlen(In_Buff); 

   if (ICU4AAA_SQLServerUTF8 != 0)
   {
      /* translate XML to Unicode */

      ucBuff = (UChar *)CALLOC(inLen+1, sizeof(UChar));
      if(ucBuff == NULL)
      {
         MERC_LogMapError(hMap, (char *)"Allocate unicode buffer", 0);
         return !MPIRC_SUCCESS;
      }

      utf8Buff = (char *)CALLOC(inLen*3+1, sizeof(utf8Buff));
      if(utf8Buff == NULL)
      {
         MERC_LogMapError(hMap, (char *)"Allocate utf8 buffer", 0);
         return !MPIRC_SUCCESS;
      }

      rc = ICU4AAA_ConvertFromHTML((const char *)In_Buff, static_cast<int>(inLen), ucBuff, static_cast<int>(inLen), &ucLen);

      /* ((UChar *)ucBuff)[ucLen++] = (UChar)0; */

      /* Convert to output file charset */

      GEN_GetApplInfo(ApplCurrentCharsetOutputEnum, &charsetCode);
      switch (charsetCode)
      {
            case CurrentCharsetCode_Iso_1:
               textConversionEn = TextConversion_Iso1;
               break;
            case CurrentCharsetCode_Iso_5:
               textConversionEn = TextConversion_Iso5;
               break;
            case CurrentCharsetCode_Iso_8:
               textConversionEn = TextConversion_Iso8;
               break;
            case CurrentCharsetCode_UTF8:
               textConversionEn = TextConversion_Utf8;
               break;
      }

      rc = ICU4AAA_ConvertFromUChars((const UChar *)ucBuff, ucLen, utf8Buff, static_cast<int>(inLen*3), &utf8Len, textConversionEn);
      /* utf8Buff[utf8Len++] = '\0'; */
      if(rc == -1)
      {
         MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "Cannot convert output string from unicode.");
         return rc;
      }

      if(textConversionEn == TextConversion_None)
         utf8Len = SYS_StrLen(utf8Buff);

      rc = _mpiStreamWrite (hStream, utf8Buff, utf8Len);
      if(rc != MPIRC_SUCCESS)
      {
         MERC_LogMapError(hMap, (char *)"StreamWrite", rc);
         return rc;
      }
   }
   else
   {
      rc = _mpiStreamWrite (hStream, In_Buff, inLen);
      if(rc != MPIRC_SUCCESS)
      {
         MERC_LogMapError(hMap, (char *)"StreamWrite", rc);
         return rc;
      }
   }

   if(getenv("AAASUBDDEBUG"))
   {
      FILE *fp;

#ifdef UNIX
      fp = fopen("/tmp/aaasubddebug.log", "a");
#else
      fp = fopen("C:\\temp\\aaasubddebug.log", "a");
#endif

      if(fp)
      {
         fprintf(fp, "MAP : %s\n", map_name);
         fprintf(fp, "DAT : %s\n", In_Buff);
         if (ICU4AAA_SQLServerUTF8 != 0)
         {
            fprintf(fp, "OUT : %s\n", utf8Buff);
         }
         fclose(fp);
      }
   }

   rc = _mpiMapRun (hMap);
   if(rc != MPIRC_SUCCESS)
   {
      MERC_LogMapError(hMap, (char *)"MapRun", rc);
      return rc;
   }

   rc = _mpiPropertyGetInteger (hMap, MPIP_OBJECT_ERROR_CODE, 0, &iRC);
   if(rc != MPIRC_SUCCESS)
   {
      MERC_LogMapError(hMap, (char *)"PropertyGetInteger", rc);
      return rc;
   }

   if(iRC != MPIRC_SUCCESS)
   {
      MERC_LogMapError(hMap, (char *)"MapRun", iRC);
      return iRC;
   }


 
   rc = _mpiMapUnload (hMap); 
   if(rc != MPIRC_SUCCESS)
   {
      MERC_LogMapError(hMap, (char *)"MapUnload", rc);
      return rc;
   }

   if (ICU4AAA_SQLServerUTF8 != 0)
   {
      FREE(ucBuff);
      FREE(utf8Buff);
   }

   return rc;
}


/************************************************************************
**
**  Function    :   MERC_LogMapError
**  Description :   Put an error message from map
**
**  Return      :  
**
************************************************************************/

void MERC_LogMapError(HMPIMAP hMap, char * message, MPIRC lastCode)
{
   MPIRC   rc;
   char strBuf[1024];
   const char *szMsg = NULL;
   size_t nLen;
   int iRC = 0;

   rc = _mpiPropertyGetInteger (hMap, MPIP_OBJECT_ERROR_CODE, 0, &iRC);
   rc = _mpiPropertyGetText(hMap, MPIP_OBJECT_ERROR_MSG, 0, &szMsg, &nLen);
   if(rc == MPIRC_SUCCESS)
   {
      if(szMsg)
         sprintf(strBuf, "%s failed: %s , ( error code %d)", message, szMsg, iRC);
      else
         sprintf(strBuf, "%s failed: ( error code %d)", message, iRC);
      MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, strBuf);
   }
   sprintf(strBuf, "Last return code was (%d) - %s", lastCode, 
      _mpiErrorGetText(lastCode));
   MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, strBuf);
}

/************************************************************************
**
**  Function    :   MERC_Startup
**  Description :   Initialize mercator api
**
**  Return      :   int	0 success 1 failure
**
************************************************************************/

int MERC_Startup(char * registryFile)
{
   MPIRC   rc;
   char strBuf[1024];
   DBA_DYNFLD_STP inputSt=NULLDYNST,
                  applParam=NULLDYNST;
   char *pszParamName = (char *)"SUBSCRIPTION_REGISTRY_FILE";
   RET_CODE        ret;
   INFO_T          value;
   int getOptions = UNUSED;
   int connectNo = NO_VALUE;
   char *initParam;
   value[0] = '\0';

   /* LN9159 - 03062003 - VST */
   /* Check if system parameter SUBSCRIPTION_REGISTRY_FILE exists */
   /* Memory allocation */

   if ((inputSt = ALLOC_DYNST(S_ApplParam)) == NULLDYNST)
   {
      MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "S_ApplParam");
      return(RET_MEM_ERR_ALLOC);
   }
   if ((applParam = ALLOC_DYNST(A_ApplParam)) == NULLDYNST)
   {
      MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "S_ApplParam");
      FREE_DYNST(inputSt, S_ApplParam);
      return(RET_MEM_ERR_ALLOC);
   }

   initParam = NULL;

   /* If something was passed with -r option, then use it */
   if(registryFile != NULL)
      initParam = registryFile;
   else
   {
      /* Get system parameter */
      SET_NAME(inputSt, S_ApplParam_ParamName, pszParamName);

      if ((ret = DBA_Get2(ApplParam, UNUSED, S_ApplParam, inputSt, A_ApplParam , 
         &applParam, getOptions, &connectNo, UNUSED)) == RET_SUCCEED)
      {
         if (IS_NULLFLD(applParam, A_ApplParam_Value) == FALSE)
         {
            strcpy(value, GET_INFO(applParam, A_ApplParam_Value));
            initParam = value;
         }
      }
   }

   /* Free memory allocations */
   FREE_DYNST(inputSt, S_ApplParam);
   FREE_DYNST(applParam, A_ApplParam);


#ifndef NODL
   if (dl == NULL)
   {
     const char *name = getenv("LIBDSTXPI");

     if (name == NULL)
       name = "libdstxpi.so";

     if ((dl = dlopen(name, RTLD_NOW)) == NULL)
     {
       MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "Failed to load LIBDSTXPI.");
       return RET_GEN_ERR_PERSONAL;
     }
     else
     if ((*((void **)(&_mpiMapLoadFile)) = dlsym(dl, "mpiMapLoadFile" )) == NULL ||
         (*((void **)(&_mpiMapGetInputCardObject)) = dlsym(dl, "mpiMapGetInputCardObject")) == NULL ||
         (*((void **)(&_mpiCardOverrideAdapter)) = dlsym(dl, "mpiCardOverrideAdapter" )) == NULL ||
         (*((void **)(&_mpiCardGetAdapterObject)) = dlsym(dl, "mpiCardGetAdapterObject" )) == NULL ||
         (*((void **)(&_mpiPropertyGetObject)) = dlsym(dl, "mpiPropertyGetObject" )) == NULL ||
         (*((void **)(&_mpiStreamWrite)) = dlsym(dl, "mpiStreamWrite" )) == NULL ||
         (*((void **)(&_mpiMapRun)) = dlsym(dl, "mpiMapRun" )) == NULL ||
         (*((void **)(&_mpiPropertyGetInteger)) = dlsym(dl, "mpiPropertyGetInteger" )) == NULL ||
         (*((void **)(&_mpiMapUnload)) = dlsym(dl, "mpiMapUnload" )) == NULL ||
         (*((void **)(&_mpiPropertyGetText)) = dlsym(dl, "mpiPropertyGetText" )) == NULL ||
         (*((void **)(&_mpiErrorGetText)) = dlsym(dl, "mpiErrorGetText" )) == NULL ||
         (*((void **)(&_mpiInitAPI)) = dlsym(dl, "mpiInitAPI" )) == NULL ||
         (*((void **)(&_mpiTermAPI)) = dlsym(dl, "mpiTermAPI" )) == NULL)
     {
       dlclose(dl);
       dl = NULL;

       MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "Failed to map functions from LIBDSTXPI.");
       return RET_GEN_ERR_PERSONAL;
     }
   }
#endif

   rc = _mpiInitAPI(initParam);
   if(rc != MPIRC_SUCCESS)
   {
      sprintf(strBuf, "Failed to initialize Mercator API, status (%d)", rc);
      MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, strBuf);
      sprintf(strBuf, "mpiInitAPI called with : '%s'", value);
      MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, strBuf);
   }
   return rc;
}

/************************************************************************
**
**  Function    :   MERC_Shutdown
**  Description :   Terminate mercator api
**
**  Return      :   
**
************************************************************************/
void MERC_Shutdown()
{
   _mpiTermAPI();
}

int CopyAndReplace0xa(char *src, char **dest)
{
   int i, j, nbr;
 
   nbr = 0; 
   for(i=0; i<(int)strlen(src); i++)
      if(src[i] == 0x0a)
         nbr++;

   *dest = (char *)CALLOC(strlen(src)+nbr+1, sizeof(char));
   if(*dest == NULL)
      return 1;
 
   if(nbr == 0)
      strcpy(*dest, src);
   else
   {
      j = 0;
      for(i=0; i<(int)strlen(src); i++)
         if(src[i] == 0x0a)
         {
            (*dest)[j++] = '\\';
            (*dest)[j++] = 'n';
         }
         else
            (*dest)[j++] = src[i];
      (*dest)[j] = '\0';
   }
   return 0;
}

/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines      
*************************************************************************/
#define BATCHEX_C

/************************************************************************
**      Includes
*************************************************************************/
#include  <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include  "olitapi.h"
#include "olitsign.h"

/************************************************************************
**      Constants
*************************************************************************/
#define LINE_SIZE 4096
#define MAX_EINTR   10
#define EINTR        4
#define RET_OK							(0x00020000L)	/* Return OK */

/************************************************************************
**      Macro Definitions
*************************************************************************/

/************************************************************************
**      Type  Definitions
*************************************************************************/

/************************************************************************
**      Global Functions
*************************************************************************/
#ifdef _WIN32
	__declspec(dllimport) OLI_STATUS AAA_OliInit(int , char **, AAA_OliContext_STP );
	__declspec(dllimport) OLI_STATUS AAA_OliClose(AAA_OliContext_STP );
	__declspec(dllimport) OLI_STATUS AAA_OliCall(AAA_OliContext_STP  , char * , long );
	__declspec(dllimport) OLI_STATUS AAA_OliGet(AAA_OliContext_STP , AAA_OliChEnum , char * , long );
#else
	OLI_STATUS AAA_OliInit(int , char **, AAA_OliContext_STP );
	OLI_STATUS AAA_OliClose(AAA_OliContext_STP );
	OLI_STATUS AAA_OliCall(AAA_OliContext_STP  , char * , long );
	OLI_STATUS AAA_OliGet(AAA_OliContext_STP , AAA_OliChEnum , char * , long );
#endif

int main(int, char **);

/************************************************************************
**      Static Functions
*************************************************************************/
static int loadFile(char **);
static char *getString(char *, int , FILE *);
static int getLine(char *, int , FILE *);

/************************************************************************
**      Global Data Definitions 
*************************************************************************/

/************************************************************************
**      Static Data Definitions
*************************************************************************/

/************************************************************************
**
**  Function    :   main()
**
**  Description :   Batch files Interface Entry Point
**
**  Argument    :   argc    
**                  argv    
**
**  Return      :   0 on success, -1 elsewhere
**
************************************************************************/
int main (int argc , char ** argv)
{
    AAA_OliContext_ST context;    /* Online public structure */
    char *commands;               /* current command line */
    int retVal = 0;               /* process return value */
    char res[256];                /* result chunks buffer */
    OLI_STATUS oliRet = RET_OK;   /* Online API return values */

    /* Initializes process : Checks parameters, connects to the
       database, loads core functions */

    oliRet=AAA_OliInit(argc, argv, &context);
    if (ST_SUCCESS(oliRet))
    {
        /* Gets commands file */

        if(!loadFile(&commands))
        {
            /* Executes command file */

            if (AAA_OliCall(&context, commands, strlen(commands)+1) == RET_OK)
            {
                /* Gets result data and error */
                while ((AAA_OliGet(&context, Data ,res, 255)) == RET_OK)
                    fprintf(stdout, "%s", res);
                
                while ((AAA_OliGet(&context, Rejected , res, 255)) == RET_OK)
                    fprintf(stderr, "%s", res);
            }
        }
        else
            retVal=3;

        /* Terminate & Clean-up Process */
        if ((AAA_OliClose(&context) != RET_OK) && (retVal == 0 ))
            retVal=2;
    }
    else
        retVal = 1;

    return retVal;
}

/************************************************************************
**      Static Function Definitions
*************************************************************************/

/************************************************************************
**
**  Function    :   loadFile()
**
**  Description :   Load entire input file into buffer, the function
**                  takes care of the buffer allocation
**
**  Argument    :   buffer: unallocated char ** pointer     
**
**  Return      :   0 on success, 1 on failure
**
*************************************************************************/
static int loadFile(char **buffer)
{
    char line[LINE_SIZE];
    int size;
    int length;

    *buffer =
        (char *)malloc(size = 1);

    while ((length = getLine(line, LINE_SIZE, stdin)) != 0)
    {
        *buffer = 
            (char *)realloc(
                *buffer, size += length);

        memcpy(*buffer + size - length - 1, line, length);
    } 

    *(*buffer + size - 1) = '\0';

    if (strlen(*buffer) > 1)
        return 0;
    else
        return 1;
}

/************************************************************************
**
**  Function    :   getLine()
**
**  Description :   Get line on input stream, line can be splited in
**                  many ones using the '\' at end of line
**
**  Argument    :   line   : destination buffer     
**                  size   : maximum number of readable characters 
**                           the function can get
**                  stream : input stream
**
**  Return      :   line length (with CR included) or 0 if any problem
**                  occurs
**
*************************************************************************/
static int getLine(char *line, int size, FILE *stream)
{
    char *cursor = line;
    char *status;

    *cursor = '\0';

    if ((status = getString(cursor, size, stream)) != NULL)
    {
        int len = strlen(cursor);

        while (status != NULL &&
                   len >= 2 &&
                       cursor[len - 2] == '\\' &&
                       cursor[len - 1] =='\n')
        {
            cursor += len - 2;
            size   -= len - 2;

            *cursor = '\0';

            status = getString(cursor, size, stream);

            len = strlen(cursor);
        }
    }
    else
        *line = 0;

    return strlen(line);
}

/************************************************************************
**
**  Function    :   getString()
**
**  Description :   Get next line on input stream
**
**  Argument    :   string: destination buffer
**                  size  : maximum number of character the function
**                          can get    
**                  stream: input stream
**
**  Return      :   NULL if EOF encontered
**
*************************************************************************/
static char *getString(char *string, int size, FILE *stream)
{
    char *status;
    int n = 0;

    while ((status = fgets(string, size, stream)) == NULL &&
                !feof(stream) && errno == EINTR && n < MAX_EINTR)
    {
        n++;
    }

    return status;
}

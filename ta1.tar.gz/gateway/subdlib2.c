/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**
**                     Copyright (C) 1993-1994 by UNICIBLE
**                             All Rights Reserved
**
**                          Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define SUBDLIB_C

/************************************************************************
**      Includes
*************************************************************************/
#define  STDIO_H
#define  CTYPE_H
#define  ERRNO_H
#define STDLIB_H
#define UNISTD_H
#define STRING_H
#define SIGNAL_H

#include <unidef.h>	/* Mandatory */
#include <dba.h>
#include <dict.h>
#include <scptyl.h>
#include <syslib.h>
#include <date.h>
#include <str.h>
#include <gen.h>
#include <conv.h>
#include "subd.h"
#include "merclib.h"
#include "dbi.h"

/************************************************************************
**      Constants
*************************************************************************/

/************************************************************************
**      Macros Definitions
*************************************************************************/

/************************************************************************
**      Types  Definitions
*************************************************************************/

/************************************************************************
**      Global Functions
**
*************************************************************************/

/************************************************************************
**      Global Functions
**
**  SUBD_GetTree()
**  SUBD_FreeAllTree()
**  SUBD_StoreTree()
**  SUBD_EvalFmt()
**  SUBD_ExecFmt()
**  SUBD_IsFmtModifStatChanged()
**  SUBD_PrintFmt()
**  SUBD_PrintFmtToString()
**
*************************************************************************/

STATIC DBA_DYNFLD_STP       *SV_TabModifStatTab = NULLDYNSTPTR;
STATIC int                  SV_TabModifStatNbr = 0;
STATIC SUBD_RESULT_EVAL_STP SV_ResultEvalTab = (SUBD_RESULT_EVAL_STP)NULL;
STATIC int                  SV_ResultEvalTabNbr = 0;

extern DBA_DYNFLD_STP SUBD_BuildDynStFromString(DBA_DYNFLD_STP event, OBJECT_ENUM *pObject);

extern SCPT_GENCONTEXTSUB_STP * genContextBusEntityTab;     /* PMSTA-17089 - DDV - 131205 */
extern int                      genContextBusEntityTabNb;   /* PMSTA-17089 - DDV - 131205 */

extern int genContextTabNb;
extern SCPT_GENCONTEXTSUB_STP * genContextTab;

/************************************************************************
**
**  Function    :   SUBD_GetTree()
**
**  Description :   Tree optimization.
**
**  Arguments   :   ID
**
**  Cr�ation	:   GRD - 002211 - REF5309.
**
*************************************************************************/
SUBD_RESULT_EVAL_TREE_STP SUBD_GetTree(ID_T formatId)
{
    int                     i = 0;

    /*
     * Did Modif Stat change for formats?
     */

    if (SUBD_IsFmtModifStatChanged() == FALSE)
    {
        for (i = 0; i < SV_ResultEvalTabNbr; i++)
        {
            if (SV_ResultEvalTab[i].formatId == formatId)
            {
                return(SV_ResultEvalTab[i].resultEvalTreePtr);
            }
        }
    }
    else
    {
        /*
         * This cache is not good anymore. Free it.
         */

        SUBD_FreeAllTree();
    }

    return(SUBD_RESULT_EVAL_TREE_STP)NULL;  /* Not in cache. */
}

/************************************************************************
**
**  Function    :   SUBD_FreeAllTree()
**
**  Description :   Tree optimization.
**
**  Arguments   :   ID
**
**  Cr�ation	:   GRD - 002211 - REF5309.
**
*************************************************************************/
void SUBD_FreeAllTree()
{
    int     i = 0, j = 0;

    /* We have to free the data cache. */
    for (i = 0; i < SV_ResultEvalTabNbr; i++)
    {
        for (j = 0; j < SV_ResultEvalTab[i].resultEvalTreePtr->resultEvalTabNb; j++)
        {
            SCPT_FreeScptTree(SV_ResultEvalTab[i].resultEvalTreePtr->resultEvalTab[j]);
            FREE_DYNST(SV_ResultEvalTab[i].resultEvalTreePtr->fmtEltTab[j], Sum_FmtElt);
        }

        SV_ResultEvalTab[i].resultEvalTreePtr->resultEvalTabNb = 0;
        FREE(SV_ResultEvalTab[i].resultEvalTreePtr->resultEvalTab);
        FREE(SV_ResultEvalTab[i].resultEvalTreePtr->fmtEltTab);
    }

    FREE(SV_ResultEvalTab);
    SV_ResultEvalTabNbr = 0;
}

/************************************************************************
**
**  Function    :   SUBD_StoreTree()
**
**  Description :   Tree optimization.
**
**  Arguments   :   ID
**
**  Cr�ation	:   GRD - 002211 - REF5309.
**
*************************************************************************/
void SUBD_StoreTree(ID_T formatId, SUBD_RESULT_EVAL_TREE_STP resultEvalTreeStp)
{
    SV_ResultEvalTab = (SUBD_RESULT_EVAL_ST *)REALLOC(SV_ResultEvalTab, (++SV_ResultEvalTabNbr) * sizeof(SUBD_RESULT_EVAL_ST));
    SV_ResultEvalTab[SV_ResultEvalTabNbr - 1].resultEvalTreePtr = resultEvalTreeStp;
    SV_ResultEvalTab[SV_ResultEvalTabNbr - 1].formatId = formatId;
    return;
}

/************************************************************************
**
**  Function    :   SUBD_EvalFmt()
**
**  Description :   Evaluate format.
**
**  Arguments   :   ID
**
**  Cr�ation	:   GRD - 002211 - REF5309.
**
*************************************************************************/
/*
SUBD_RESULT_EVAL_TREE_STP SUBD_EvalFmt(DbiConnectionHelper & connHelper, ID_T formatId, OBJECT_ENUM objectEn)
{
    DBA_DYNFLD_STP	        getArg = (DBA_DYNFLD_STP) NULL;
    const DBA_DYNST_ENUM *outputStLst[] = { &Sum_FmtElt, &A_ScriptDef };
    DBA_DYNFLD_STP          *dataTab[2] = {NULLDYNSTPTR, NULLDYNSTPTR};
    DBA_DYNFLD_STP          *sumFmtEltTab = NULL;
    int		                lastIdx = 0;
    int                     rowTab[2] = {0,0};
    char                    *scptBuf = (char *)NULL;
    char                    *script = (char *)NULL;
    int                     i = 0, j = 0, k = 0;
    RET_CODE                ret = RET_SUCCEED;
    DATATYPE_ENUM           dataType = NullDataType;
    DICT_T                  dataTypeDictId;
    SUBD_RESULT_EVAL_TREE_STP   resultEvalTreeStp = (SUBD_RESULT_EVAL_TREE_STP)NULL;
    SCPT_ARG_STP            *genContBaseVal;
    int                     fmtEltNb = 0;
    ID_T                    fmtEltId = 0;	   // DLA - PMSTA08801 - 100519 
    DICT_ATTRIB_STP         attribSt;

    
     // First of all, look into the cache for the Tree.
     

    if ((resultEvalTreeStp = SUBD_GetTree(formatId)) == (SUBD_RESULT_EVAL_TREE_STP)NULL)
    {
        if (DBA_SearchAttribSqlName(FmtElt, "script_definition", &attribSt) != RET_SUCCEED)
        {
            return (SUBD_RESULT_EVAL_TREE_STP) NULL;
        }

        
        //Nothing in the cache, we have to evaluate and store the Tree.
        

        getArg = ALLOC_DYNST(Get_Arg);
        SET_ID(getArg, Get_Arg_Id, formatId);
        SET_ID(getArg, Get_Arg_AttribDictId, attribSt->attrDictId);

	    if (DBA_MultiSelect2(FmtElt,      UNUSED,
			                 Get_Arg,     getArg,
			                 outputStLst, dataTab,
			                 UNUSED,      UNUSED,
			                 rowTab,      UNUSED,
                             UNUSED) != RET_SUCCEED)
	    {
            FREE_DYNST(getArg, Get_Arg);
		    return (SUBD_RESULT_EVAL_TREE_STP) NULL;
	    }

        FREE_DYNST(getArg, Get_Arg);
	    sumFmtEltTab = dataTab[0];
	    fmtEltNb     = rowTab[0];
        scptBuf = (char *)CALLOC(GET_MAXDATALEN(NoteType), SCPTDEF_MAX_REC);    // PMSTA-33077 - DLA - 181012 
	    for(i = 0; i < fmtEltNb; i++)
	    {
	        // PRESUME THE SAME "ORDER BY" for data[0] (fmt_elt) & data[1] (script) 
	        fmtEltId = GET_ID(sumFmtEltTab[i], Sum_FmtElt_Id);

	        for (j = lastIdx; j < rowTab[1] && GET_ID(dataTab[1][j], A_ScriptDef_ObjId) != fmtEltId; j++);

	        // IF DEFINITION FOUND FOR CURRENT FORMAT_ELEMENT 
	        if(j < rowTab[1])
	        {
                int     cpt = 0;

		        scptBuf[0] = END_OF_STRING;

		        // CONCAT ALL DEFINITION RECORDS FOR THIS FMT_ELT
		        while (j < rowTab[1] && GET_ID(dataTab[1][j], A_ScriptDef_ObjId) == fmtEltId)
		        {
		            cpt++;

		            if(cpt < SCPTDEF_MAX_REC)
		            {
                        strcat(scptBuf, GET_STRING(dataTab[1][j], A_ScriptDef_Def));
		            }

		            j++;
		        } 

		        SET_STRING(sumFmtEltTab[i], Sum_FmtElt_Definition, scptBuf);
		        lastIdx = j;
	        }
	    }

	    DBA_FreeDynStTab(dataTab[1], rowTab[1], A_ScriptDef); 
        FREE(scptBuf);

        
        // Generate Tree and store it.
        
        resultEvalTreeStp = (SUBD_RESULT_EVAL_TREE_ST *)CALLOC(1, sizeof(SUBD_RESULT_EVAL_TREE_ST));
        genContBaseVal = (SCPT_ARG_ST **)CALLOC(fmtEltNb, sizeof(SCPT_ARG_STP));
        resultEvalTreeStp->fmtEltTab = (DBA_DYNFLD_STP *)CALLOC(fmtEltNb, sizeof(DBA_DYNFLD_STP));

	    for(i = 0; i < fmtEltNb; i++)
	    {
            script = GET_STRING(sumFmtEltTab[i], Sum_FmtElt_Definition);
            dataTypeDictId = GET_DICT(sumFmtEltTab[i], Sum_FmtElt_DataTpDictId);
            dataType = DATATYPE_DICT_TO_ENUM(dataTypeDictId);

            genContBaseVal[i] = (SCPT_ARG_ST *)CALLOC(1, sizeof(SCPT_ARG_ST));
            resultEvalTreeStp->fmtEltTab[i] = ALLOC_DYNST(Sum_FmtElt);

            if ((ret = SCPT_GenerateScptTree(script,
                                             objectEn,
                                             InternalSMode,
                                             dataType,
                                             &(genContBaseVal[i]))) != RET_SUCCEED)
            {
                // Free memory
                for (k = 0; k < i; k++)
                {
                    FREE(genContBaseVal[k]);
                    FREE_DYNST(resultEvalTreeStp->fmtEltTab[i], Sum_FmtElt);
                }

                FREE(genContBaseVal);
                FREE(resultEvalTreeStp->fmtEltTab);
                FREE(resultEvalTreeStp);
                return(SUBD_RESULT_EVAL_TREE_STP)NULL;
            }

            // We must use the current connection if any. 
            if (connHelper.isValidAndInit())
            {
                return NULL;
            }
            SET_INT((&(genContBaseVal[i]->connectNoFld)), 0, connHelper.getConnection()->getId());

            COPY_DYNST(resultEvalTreeStp->fmtEltTab[i], sumFmtEltTab[i], Sum_FmtElt);
        }

        resultEvalTreeStp->resultEvalTab   = genContBaseVal;
        resultEvalTreeStp->resultEvalTabNb = fmtEltNb;
        SUBD_StoreTree(formatId, resultEvalTreeStp);
    }

    return(resultEvalTreeStp);
}
*/

/************************************************************************
**
**  Function    :   SUBD_ExecFmt()
**
**  Description :   Evaluate format.
**
**  Arguments   :   ID
**
**  Cr�ation	:   GRD - 002211 - REF5309.
**
*************************************************************************/
RET_CODE SUBD_ExecFmt(SUBD_RESULT_EVAL_TREE_STP   resultEvalTreePtr,
                      DBA_DYNFLD_STP             *resultBaseValPtr,
                      DBA_DYNST_ENUM              inputSt,  
                      DBA_DYNFLD_STP              inputData)
{
    RET_CODE		retCode = RET_SUCCEED;
    int             i = 0;
    DBA_DYNFLD_STP  resultBaseValTmp = (DBA_DYNFLD_STP)NULL;
    DATATYPE_ENUM   dataType = NullDataType;
    DICT_T          dataTypeDictId;

    if (resultEvalTreePtr == (SUBD_RESULT_EVAL_TREE_STP)NULL)
    {
        return RET_SUCCEED;
    }

    if (inputData == (DBA_DYNFLD_STP)NULL)
    {
        return RET_SUCCEED;
    }

    resultBaseValTmp = (DBA_DYNFLD_STP)CALLOC(resultEvalTreePtr->resultEvalTabNb, sizeof(DBA_DYNFLD_ST));

    DBA_VerifOptiTab();		// Update the cache. 
 
    for (i = 0; i < resultEvalTreePtr->resultEvalTabNb; i++)
    {
        dataTypeDictId = GET_DICT(resultEvalTreePtr->fmtEltTab[i], Sum_FmtElt_DataTpDictId);
        dataType = DATATYPE_DICT_TO_ENUM(dataTypeDictId);

        if ((retCode = SCPT_ExecScptTree(resultEvalTreePtr->resultEvalTab[i],
                                         NULL,
                                         NULL,
                                         inputData,
                                         dataType,
                                         &(resultBaseValTmp[i]), 
										 NULLDYNST)) != RET_SUCCEED) /* PMSTA�443 - DDV - 121008 */
        {
            FREE(resultBaseValTmp);
            return(-1);
        }
    }

    *resultBaseValPtr = resultBaseValTmp;

    return RET_SUCCEED;
}

/************************************************************************
**
**  Function    :   SUBD_IsFmtModifStatChanged
**
**  Description :   Load TabModifStat and compare with current.
**
**  Arguments   :   
**
**  Return      :   RET_CODE	RET_SUCCEED					=> Current Fmt is Ok.
**								RET_DBA_ERR_INVALID_FORMAT	=> Current Fmt is invalid.
**
**  Cr�ation	:   GRD - 002211 - REF5309.
**
*************************************************************************/
FLAG_T SUBD_IsFmtModifStatChanged()
{
	int				dynNb = 0, i = 0, j = 0;
	OBJECT_ENUM		entity = NullEntity;
	RET_CODE		retCode = RET_SUCCEED;
	DICT_T			dictId = 0;
	DBA_DYNFLD_STP	*dynTab = NULLDYNSTPTR;
    FLAG_T          retFlg = FALSE;

	retCode = DBA_Select2(TabModifStat,
						  UNUSED,
						  NullDynSt,
						  NULL, 
						  A_TabModifStat,
						  &dynTab, 
						  UNUSED,
						  UNUSED,
						  &dynNb,
						  UNUSED,
						  UNUSED);

	if (retCode == RET_SUCCEED)
	{
        /*
         *  If first time called, then allocate and copy ModifStat.
         */

        if (SV_TabModifStatNbr == 0)
        {
            for (i = 0; i < dynNb; i++)
            {
                dictId = GET_DICT(dynTab[i], A_TabModifStat_DictId);
				DBA_GetObjectEnum(dictId, &entity);

                if ((entity == Fmt) || (entity == FmtElt) || (entity == FmtProf) ||
                    (entity == FmtProfCompo) || (entity == ScriptDef))
                {
                    SV_TabModifStatTab = (DBA_DYNFLD_STP *)REALLOC(SV_TabModifStatTab, (++SV_TabModifStatNbr * sizeof(DBA_DYNFLD_STP)));
                    SV_TabModifStatTab[SV_TabModifStatNbr - 1] = ALLOC_DYNST(A_TabModifStat);
                    COPY_DYNST(SV_TabModifStatTab[SV_TabModifStatNbr - 1], dynTab[i], A_TabModifStat);
                }
            }

            DBA_FreeDynStTab(dynTab, dynNb, A_TabModifStat);
            return TRUE;  /* We consider there has been a changed. */
        }

		for (i=0; i < dynNb; i++)
		{
			if (IS_NULLFLD(dynTab[i], A_TabModifStat_DictId) == FALSE)
			{
				dictId = GET_DICT(dynTab[i], A_TabModifStat_DictId);
				DBA_GetObjectEnum(dictId, &entity);

                if ((entity == Fmt) || (entity == FmtElt) || (entity == FmtProf) ||
                    (entity == FmtProfCompo) || (entity == ScriptDef))
                {
                    for (j = 0; j < SV_TabModifStatNbr; j++)
                    {
                        if (GET_DICT(SV_TabModifStatTab[j], A_TabModifStat_DictId) == dictId)
                        {
                            if (DBA_CmpDynFld(SV_TabModifStatTab[j],
										      dynTab[i],
										      A_TabModifStat_LastModifDate,
										      A_TabModifStat_LastModifDate,
										      DatetimeType,
										      FALSE) != 0)
                            {
                                COPY_DYNST(SV_TabModifStatTab[j], dynTab[i], A_TabModifStat);
                                retFlg = TRUE;  /* There was a change. */
                            }
                        }
                    }
                }
            }
        }

		DBA_FreeDynStTab(dynTab, dynNb, A_TabModifStat);
	}

	return retFlg;
}

/************************************************************************
**
**  Function    :   SUBD_PrintFmtToString
**
**  Description :   Print all columns of a format to a string
**
**  Arguments   :   
**
**  Return      :   
**
**  Cr�ation	:   VST - 002012 - REF5309.
**
*************************************************************************/
void SUBD_PrintFmtToString(SUBD_RESULT_EVAL_TREE_STP resultEvalTreePtr, 
                           DBA_DYNFLD_STP resultBaseValPtr, char **string)
{
   int     i = 0;
   DICT_T                  dataTypeDictId;
   PTR                     valPtr = NULL;
   char                    tmpDataBuf[500];
   char                    tmpString[500];
   DATATYPE_ENUM           dataType = NullDataType;
   DBA_DYNFLD_STP          dynStpTmp;
   const char		    *dataTypeSqlname;
   char					*formatEltName;

   if(!(*string))
      *string = (char *)CALLOC(256*resultEvalTreePtr->resultEvalTabNb, sizeof(char));
   else
      *string = (char *)REALLOC(*string, 256*resultEvalTreePtr->resultEvalTabNb*sizeof(char));

   for (i = 0; i < resultEvalTreePtr->resultEvalTabNb; i++)
   {
      dataTypeDictId = GET_DICT(resultEvalTreePtr->fmtEltTab[i], Sum_FmtElt_DataTpDictId);
      dataType = DATATYPE_DICT_TO_ENUM(dataTypeDictId);
      dynStpTmp = &resultBaseValPtr[i];
      valPtr = GET_FLDPTR_BY_DTP(dataType, dynStpTmp, 0);
      CONV_DataToStr(tmpDataBuf, sizeof(tmpDataBuf),
                       dataType,
                       GET_CONV_MASK(GET_DFLTCONVFMT(dataType)),
                       valPtr,
                       TRUE, TextConversion_None);

		    /* trim illegal characters */
  
		    STRING_Trim(tmpDataBuf);

		    dataTypeSqlname = DBA_GetDataTypeSQLNameC(dataType);
		    formatEltName = GET_NAME(resultEvalTreePtr->fmtEltTab[i], Sum_FmtElt_Name);

		    if(i==0)
			      sprintf(*string, "%s%c%s%c", formatEltName, US_SEP, 
                                          tmpDataBuf, GS_SEP);
      else
		    {
			      sprintf(tmpString, "%s%c%s%c", formatEltName, US_SEP, 
                                            tmpDataBuf, GS_SEP);
			      strcat(*string, tmpString);
		    }
      if(i<(resultEvalTreePtr->resultEvalTabNb-1))
         strcat(*string, FS_STR);
	  }
#ifdef UNIX
    strcat(*string, "\n");
#else 
    strcat(*string, "\r\n");
#endif
}

/************************************************************************
**
**  Function    :   SUBD_PrintFmt
**
**  Description :   Test function, never called
**
*************************************************************************/
void SUBD_PrintFmt(SUBD_RESULT_EVAL_TREE_STP resultEvalTreePtr, DBA_DYNFLD_STP resultBaseValPtr)
{
    int     i = 0;
    DICT_T                  dataTypeDictId;
    PTR                     valPtr = NULL;
    char                    tmpDataBuf[500];
    DATATYPE_ENUM           dataType = NullDataType;
    DBA_DYNFLD_STP          dynStpTmp;


    printf("Format : %s\n", GET_CODE(resultEvalTreePtr->fmtEltTab[0], Sum_FmtElt_FmtCd));

    for (i = 0; i < resultEvalTreePtr->resultEvalTabNb; i++)
    {
        dataTypeDictId = GET_DICT(resultEvalTreePtr->fmtEltTab[i], Sum_FmtElt_DataTpDictId);
        dataType = DATATYPE_DICT_TO_ENUM(dataTypeDictId);
        dynStpTmp = &resultBaseValPtr[i];
        valPtr = GET_FLDPTR_BY_DTP(dataType, dynStpTmp, 0);
        CONV_DataToStr(tmpDataBuf, sizeof(tmpDataBuf),
                       dataType,
                       GET_CONV_MASK(GET_DFLTCONVFMT(dataType)),
                       valPtr,
                       FALSE, TextConversion_None);
        printf("    Fmt elem : %20s type %16s %s\n",
                GET_NAME(resultEvalTreePtr->fmtEltTab[i], Sum_FmtElt_Name),
                (dataType == CodeType) ?       "CodeType" :
                (dataType == DateType) ?       "DateType" :
                (dataType == DatetimeType) ?   "DatetimeType" :
                (dataType == DictType) ?       "DictType" :
                (dataType == EnumType) ?       "EnumType" :
                (dataType == ExchangeType) ?   "ExchangeType" :
                (dataType == FlagType) ?       "FlagType" :
                (dataType == IdType) ?         "IdType" :
                (dataType == InfoType) ?       "InfoType" :
                (dataType == IntType) ?        "IntType" :
                (dataType == LongnameType) ?   "LongnameType" :
                (dataType == MaskType) ?       "MaskType" :
                (dataType == MethodType) ?     "MethodType" :
                (dataType == NameType) ?       "NameType" :
                (dataType == NoteType) ?       "NoteType" :
                (dataType == NumberType) ?     "NumberType" :
                (dataType == PercentType) ?    "PercentType" :
                (dataType == PeriodType) ?     "PeriodType" :
                (dataType == PhoneType) ?      "PhoneType" :
				(dataType == PriceType) ?      "PriceType" :
                (dataType == SmallintType) ?   "SmallintType" :
                (dataType == SysnameType) ?    "SysnameType" :
                (dataType == TimeType) ?       "TimeType" :
                (dataType == YearType) ?       "YearType" :
                (dataType == AmountType) ?     "AmountType" :
                (dataType == ShortinfoType) ?  "ShortinfoType" :
                (dataType == LongamountType) ? "LongamountType" :
                                               "Unknown datatype",
                tmpDataBuf);
    }
}

/************************************************************************
**      END  subdlib2.c                                        UNICIBLE
*************************************************************************/

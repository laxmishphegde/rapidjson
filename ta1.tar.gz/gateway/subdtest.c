/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#include <stdio.h>
#include <dstxpi.h>

#ifndef WIN32
#include <dlfcn.h>
#endif

#ifdef WIN32
#define NODL
#endif

#ifdef NODL
static MPIRC (*_mpiMapLoadFile)(HMPIMAP *phMap,const char *pszMapName) = mpiMapLoadFile;
static MPIRC (*_mpiMapGetInputCardObject)(HMPIMAP hMap,int iCard,HMPICARD *phCard) = mpiMapGetInputCardObject;
static MPIRC (*_mpiCardOverrideAdapter)(HMPICARD hCard, const char *pszAlias, int iType) = mpiCardOverrideAdapter;
static MPIRC (*_mpiCardGetAdapterObject)(HMPICARD hCard,HMPIADAPT *phAdapter) = mpiCardGetAdapterObject;
static MPIRC (*_mpiPropertyGetObject)(HMPIOBJ hObject,MPIPROP iProperty,int iIndex,HMPIOBJ *phValue) = mpiPropertyGetObject;
static MPIRC (*_mpiStreamWrite)(HMPISTREAM hStream,const void *pData,size_t nSize) = mpiStreamWrite;
static MPIRC (*_mpiMapRun)(HMPIMAP hMap) = mpiMapRun;
static MPIRC (*_mpiMapUnload)(HMPIMAP hMap) = mpiMapUnload;
static MPIRC (*_mpiInitAPI)(const char *lpszResourceConfigFile) = mpiInitAPI;
static MPIRC (*_mpiTermAPI)(void) = mpiTermAPI;
#else
static MPIRC (*_mpiMapLoadFile)(HMPIMAP *phMap,const char *pszMapName) = NULL;
static MPIRC (*_mpiMapGetInputCardObject)(HMPIMAP hMap,int iCard,HMPICARD *phCard) = NULL;
static MPIRC (*_mpiCardOverrideAdapter)(HMPICARD hCard, const char *pszAlias, int iType) = NULL;
static MPIRC (*_mpiCardGetAdapterObject)(HMPICARD hCard,HMPIADAPT *phAdapter) = NULL;
static MPIRC (*_mpiPropertyGetObject)(HMPIOBJ hObject,MPIPROP iProperty,int iIndex,HMPIOBJ *phValue) = NULL;
static MPIRC (*_mpiStreamWrite)(HMPISTREAM hStream,const void *pData,size_t nSize) = NULL;
static MPIRC (*_mpiMapRun)(HMPIMAP hMap) = NULL;
static MPIRC (*_mpiMapUnload)(HMPIMAP hMap) = NULL;
static MPIRC (*_mpiInitAPI)(const char *lpszResourceConfigFile) = NULL;
static MPIRC (*_mpiTermAPI)(void) = NULL;

static void *dl = NULL;
#endif

/************************************************************************
**
**  Function    :   Run_Map					
**  Description :   Runs a Mercator Map
**
**  Arguments    :  In_Buff - data for the Mercator map
**                  map_name - the map name(complete path) 
**					
**  Return      :   int	map return (success/failure)
**
************************************************************************/
int Run_Map(char *In_Buff, char *map_name)
{
   HMPIMAP   hMap;
   HMPIADAPT  hAdapter;
   HMPICARD  hCard;
   HMPISTREAM  hStream;
   MPIRC   rc;

   printf("Checking AAASUBDDEBUG variable\n");

   if(getenv("AAASUBDDEBUG"))
   {
      FILE *fp;
      fp = fopen("/tmp/aaasubddebug.log", "a");
      if(fp)
      {
         printf("Writing log file /tmp/aaasubddebug.log\n");
         fprintf(fp, "MAP : %s\n", map_name);
         fprintf(fp, "DAT : %s\n", In_Buff);
         fclose(fp);
      }
      else
         printf("Cannot create log file /tmp/aaasubddebug.log\n");
   }

   printf("Opening map\n");
   rc = _mpiMapLoadFile (&hMap, map_name);
   if(rc != MPIRC_SUCCESS)
   {
      printf("Cannot load map file %s. Return code %d\n", map_name, rc);
      return rc;
   }

   printf("Get input card object\n");
   rc = _mpiMapGetInputCardObject (hMap, 1, &hCard);
   if(rc != MPIRC_SUCCESS)
   {
      printf("Cannot get input card\n");
      return rc;
   }

   printf("Override input card\n");
   rc = _mpiCardOverrideAdapter(hCard,NULL, MPI_ADAPTYPE_STREAM);
   if(rc != MPIRC_SUCCESS)
   {
      fprintf(stderr, "Cannot override adapter\n");
      return rc;
   }

   printf("Get Adapter Object\n");
   rc = _mpiCardGetAdapterObject (hCard, &hAdapter);
   if(rc != MPIRC_SUCCESS)
   {
      fprintf(stderr, "Cannot get adapter object\n");
      return rc;
   }

   printf("Get Data From Adapter Property\n");
   rc = _mpiPropertyGetObject (hAdapter, MPIP_ADAPTER_DATA_FROM_ADAPT, 0, 
      &hStream); 
   if(rc != MPIRC_SUCCESS)
   {
      fprintf(stderr, "Cannot get property object\n");
      return rc;
   }

   size_t inLen = strlen(In_Buff);
   printf("Write %d bytes of data\n", static_cast<int>(inLen));
   rc = _mpiStreamWrite (hStream, In_Buff, inLen);
   if(rc != MPIRC_SUCCESS)
   {
      fprintf(stderr, "Cannot write output stream\n");
      return rc;
   }


   printf("Running map\n");
   rc = _mpiMapRun (hMap);
   if(rc != MPIRC_SUCCESS)
   {
      fprintf(stderr, "Run map failed\n");
      return rc;
   }

 
   printf("Unloading map\n");
   rc = _mpiMapUnload (hMap); 
   if(rc != MPIRC_SUCCESS)
   {
      fprintf(stderr, "Cannot run map\n");
      return rc;
   }

   return rc;
}

/************************************************************************
**
**  Function    :   MERC_Startup
**  Description :   Initialize mercator api
**
**  Return      :   int	0 success 1 failure
**
************************************************************************/

int MERC_Startup(char *initParam)
{
   MPIRC   rc;

#ifndef NODL
   if (dl == NULL)
   {
     const char *name = getenv("LIBDSTXPI");

     if (name == NULL)
       name = "libdstxpi.so";

     if ((dl = dlopen(name, RTLD_NOW)) == NULL)
     {
       printf("Failed to load LIBDSTXPI.\n");
       return MPIRC_E_3RD_PARTY_FAILED;
     }
     else
     if ((*((void **)(&_mpiMapLoadFile)) = dlsym(dl, "mpiMapLoadFile" )) == NULL ||
         (*((void **)(&_mpiMapGetInputCardObject)) = dlsym(dl, "mpiMapGetInputCardObject")) == NULL ||
         (*((void **)(&_mpiCardOverrideAdapter)) = dlsym(dl, "mpiCardOverrideAdapter" )) == NULL ||
         (*((void **)(&_mpiCardGetAdapterObject)) = dlsym(dl, "mpiCardGetAdapterObject" )) == NULL ||
         (*((void **)(&_mpiPropertyGetObject)) = dlsym(dl, "mpiPropertyGetObject" )) == NULL ||
         (*((void **)(&_mpiStreamWrite)) = dlsym(dl, "mpiStreamWrite" )) == NULL ||
         (*((void **)(&_mpiMapRun)) = dlsym(dl, "mpiMapRun" )) == NULL ||
         (*((void **)(&_mpiMapUnload)) = dlsym(dl, "mpiMapUnload" )) == NULL ||
         (*((void **)(&_mpiInitAPI)) = dlsym(dl, "mpiInitAPI" )) == NULL ||
         (*((void **)(&_mpiTermAPI)) = dlsym(dl, "mpiTermAPI" )) == NULL)
     {
       dlclose(dl);
       dl = NULL;

       printf("Failed to map functions from LIBDSTXPI.\n");
       return MPIRC_E_3RD_PARTY_FAILED;
     }
   }
#endif

   rc = _mpiInitAPI(initParam);
   if(rc != MPIRC_SUCCESS)
   {
      printf("Failed to initialize Mercator API, status (%d)", rc);
      printf("mpiInitAPI called with : '%s'", initParam);
   }
   return rc;
}

/************************************************************************
**
**  Function    :   MERC_Shutdown
**  Description :   Terminate mercator api
**
**  Return      :   
**
************************************************************************/
void MERC_Shutdown()
{
   _mpiTermAPI();
}

int main(int argc, char **argv)
{
   FILE *fp;
   char *buff;
   char *initParam;
   long fLen;

   if(argc == 3)
      initParam = NULL;
   else
      if(argc == 4)
         initParam = argv[3];
      else
      {
         printf("Usage: subdtest map_name, input_file_name [, registry_file_name ]\n");
         return 1;
      }
   
   fp = fopen(argv[2], "r");
   if(fp == NULL)
   {
      printf("Cannot open input file %s\n", argv[2]);
      return 1;
   }
   fseek(fp, 0, SEEK_END);
   fLen = ftell(fp);
   fseek(fp, 0, SEEK_SET);
   buff = (char *)malloc(fLen);
   if(buff == NULL)
   {
      printf("Cannot allocate memory\n");
      return 1;
   }
   if(fread(buff, 1, fLen, fp) != fLen)
   {
      printf("Cannot read input file.\n");
      return 1;
   }
   fclose(fp);
   printf("Input file %s loaded\n", argv[2]);

   if(MERC_Startup(initParam) != MPIRC_SUCCESS)
      return 1;

   Run_Map(buff, argv[1]);

   MERC_Shutdown();
   printf("Mercator shut down\n");
  
   return 0;
}

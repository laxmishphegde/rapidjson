/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define SUBDLIB_C

/************************************************************************
**      Includes
*************************************************************************/
#define  STDIO_H
#define  CTYPE_H
#define  ERRNO_H
#define STDLIB_H
#define UNISTD_H
#define STRING_H
#define SIGNAL_H

#include <unidef.h>  /* Mandatory */
#include <dba.h>
#include <conv.h>
#include <syslib.h>
#include <date.h>
#include <gen.h>
#include <scptyl.h>
#include <subd.h>
#include <stdarg.h>
#include <limits.h>
#include "merclib.h"
#include "dbiconnection.h"
#include "aaalogger.h"
#include "aaatelemetry.h"
#include "ddlgen.h"

/************************************************************************
**      Constants
*************************************************************************/

/************************************************************************
**      Macros Definitions
*************************************************************************/

/************************************************************************
**      Types  Definitions
*************************************************************************/

typedef int BOOL;

/************************************************************************
**      Global Functions
**
**  SUBD_Proceed()
**  SUBD_Halt()
**
*************************************************************************/

/************************************************************************
**      Static Functions
**
**
*************************************************************************/

/************************************************************************
**      Static Data Definitions
*************************************************************************/

/************************************************************************
**      Global Data Definitions
*************************************************************************/
static SubdMultiQueue SV_SubdMultiQueue;

/************************************************************************
**      Static Function Definitions
*************************************************************************/

/************************************************************************
**      External functions.
*************************************************************************/
extern void     SUBD_LogRejected(DBA_DYNFLD_STP event);
extern void     SUBD_LogSucceed(DBA_DYNFLD_STP event);
extern FLAG_T   DBA_FieldToExport(DBA_DYNST_ENUM inputSt,int field);
extern char     *ResolveMap(char *, std::string);
extern int      ParseEntityData(const char *, char *, char ** , int);
extern int      ParseFormatData(const char *, char *, char **);
extern int      Run_Map(char *, char *);
extern void     SUBD_PrintFmtToString(SUBD_RESULT_EVAL_TREE_STP, DBA_DYNFLD_STP, char **);
DBA_DYNFLD_STP  SUBD_BuildDynStFromString(DBA_DYNFLD_STP event, OBJECT_ENUM *pObject);
//int             SUBD_BuildStrWithFormat(DBA_DYNFLD_STP, char **);
extern RET_CODE SUBD_GetFormatName(ID_T, char *);
extern BOOL     get_next_field(char **, char **, char **, char**, int, char **, char **, char**); /* PMSTA39500 - 18092020 - HLA */ /* PMSTA-66218 - JBC - 20250221 */
RET_CODE        SUBD_DumpHeader(DBA_DYNFLD_STP, const char*, FMTNAT_ENUM,char *);
RET_CODE		SUBD_GetFormatNature(ID_T, FMTNAT_ENUM *);	/*PMSTA-46561 - 13102021 - sriharshabv*/


/************************************************************************
**      Global Function Definitions
*************************************************************************/
int             SUBD_CheckStopFileOrStopState(bool);
RET_CODE        SUBD_SendAllEventsToMercator(std::vector<DBA_DYNFLD_STP> &, std::string);
RET_CODE        SUBD_DumpHeader(DBA_DYNFLD_STP, const char*, char *, bool sendTraceIdtoITX);



/************************************************************************
**
**  Function    :   SubscriptionDaemon::SubscriptionDaemon
**
**  Description :   Constructor
**
**  Argument    :
*************************************************************************/
SubscriptionDaemon::SubscriptionDaemon(ServiceCfg & serviceCfg, int daemonNumber, char * whereClause, int daemonFrequency,
    int blockSize, bool keepEvent, int keepDays, int threadNo, int totalThreads, std::string busEntityCd, int commitRetryNb, int multiThreadMode) :
    m_serviceId(serviceCfg.getServiceId()),
    m_serviceCd(serviceCfg.getServiceCd()),
    m_daemonNumber(daemonNumber),
    m_whereClause(whereClause),
    m_daemonFrequency(daemonFrequency),
    m_blockSize(blockSize),
    m_keepEvent(keepEvent),
    m_keepDays(keepDays),
    m_threadRank(threadNo),
    m_totalThreads(totalThreads),
    m_singleBusEntityCd(busEntityCd),
    m_commitRetryNb(commitRetryNb),
    m_multiThreadMode(0)
{
    if(m_totalThreads > 0 && multiThreadMode >=0 && multiThreadMode <= 1) /* PMSTA-66218 - JBC - 20250221 */
    {
         m_multiThreadMode = multiThreadMode;
    }   
}


SubscriptionDaemon::~SubscriptionDaemon()
{
    for(auto it = m_freqByBusEntCd.begin(); it != m_freqByBusEntCd.end();++it)
    {
        delete it->second;
        it->second = nullptr;
    }
}


int SubscriptionDaemon::getThreadNumber()
{
    return m_threadRank;
}


int SubscriptionDaemon::getTotalThreadCount()
{
    return m_totalThreads;
}

/************************************************************************
**
**  Function    :   SubscriptionDaemon::isPrimeThread()
**
**  Description :  Identifies any thread = 1 to minimize threads
*                   attempting cleanup activities
**
**  Argument    :
*************************************************************************/
bool SubscriptionDaemon::isPrimeThread()
{
    return m_threadRank == 1;
}

/* PMSTA-66218 - JBC - 20250221 */
bool SubscriptionDaemon::isMultiThreadOverride()
{
    return m_multiThreadMode > 0;
}

int SubscriptionDaemon::getMultiThreadMode()
{
    return   m_multiThreadMode;
}

std::string SubscriptionDaemon::getMultiThreadModeStr()
{
    switch(m_multiThreadMode)
    {
		case 1:
    		return "MapByBEUnorderedParallel";
        default:
    		return "DefaultMapByBECreationDate";
    }        
}

/************************************************************************
**
**  Function    :   SubscriptionDaemon::SUBD_PurgeEvents()
**
**  Description :  Prime Thread will look for expired events to cleanup
*                   attempting cleanup activities
**
**  Argument    :
*************************************************************************/
RET_CODE SubscriptionDaemon::SUBD_PurgeEvents(DbiConnectionHelper & connHelper, FusionTimer & purgeTimer)
{
    RET_CODE ret = RET_SUCCEED;

	static bool firstTime = true;

    if(isPrimeThread() && m_keepEvent && m_keepDays > 0
		&& (firstTime || purgeTimer.isTimedOut()))
    {
		firstTime = false;
		purgeTimer.resetTimer();

        MemoryPool          mp;
        DBA_DYNFLD_STP      getArg = mp.allocDynst(FILEINFO, Get_Arg);
        DBA_DYNFLD_STP* aEventTab = nullptr;
        int                 aEventTabNb = 0;

        SET_ENUM(getArg, Get_Arg_Enum1, Event_Status_Succeed);
        SET_INT(getArg, Get_Arg_Integer, m_keepDays);

        if (connHelper.isValidAndInit() &&
            (ret = connHelper.dbaSelect(Event, UNUSED, getArg, A_Event, &aEventTab, &aEventTabNb)) == RET_SUCCEED
            && aEventTabNb > 0)
        {
            RequestHelper requestHelper(connHelper);
            connHelper.beginTransaction();
            /* delete the events and related status */
            for (int i = 0; i < aEventTabNb && ret == RET_SUCCEED; i++)
            {
                DBA_DYNFLD_STP sEvent = mp.allocDynst(FILEINFO, S_Event);
                SET_ID(sEvent, S_Event_Id, GET_ID(aEventTab[i], A_Event_Id));
                if (requestHelper.addProcedureCallForBatchMulti(Delete, Event, UNUSED, sEvent, 10) == false)
                {
                    DBA_FreeDynStTab(aEventTab, aEventTabNb, A_Event);
                    connHelper.endTransaction(false);

                    MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "Unable to call purge Event procedure.");
                    return SUBD_ERROR;
                }
            }
            ret = requestHelper.executeBatchMulti();
            connHelper.endTransaction(ret == RET_SUCCEED);
        }

        if (aEventTab != nullptr)
        {
            DBA_FreeDynStTab(aEventTab, aEventTabNb, A_Event);
            aEventTab = nullptr;
        }
    }

    return ret;
}

/************************************************************************
**
**  Function    :   SubscriptionDaemon::SUBD_DeleteEvent()
**
**  Description :  Manages Event delete per row;
**                 Transaction management must be outside this function.
**                 Note: event_status is not deleted as external systems
*                  can update it also.
**
**  Argument    :
*************************************************************************/
RET_CODE SubscriptionDaemon::SUBD_DeleteEvent(DbiConnectionHelper & connHelper,std::vector<DBA_DYNFLD_STP> & eventBlock)
{
    MemoryPool mp;
    RequestHelper requestHelper(connHelper);
    for(size_t i=0; i<eventBlock.size();i++)
    {
    DBA_DYNFLD_STP sEvent = mp.allocDynst(FILEINFO,S_Event);

        SET_ID(sEvent,S_Event_Id, GET_ID(eventBlock[i],A_Event_Id));
        if(requestHelper.addProcedureCallForBatchMulti(Delete,Event,UNUSED,sEvent) == false)
        {            
            MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "Unable to call Delete Event procedure.");
            return SUBD_ERROR;
        }
    }
	/* PMSTA-47289 - BSV - 180522 */
    if (connHelper.isValidAndInit() == false)
    {
       MSG_SendMesg(RET_DBA_ERR_NOFREESYNCCONN, 0, FILEINFO);
       return(DBA_CONN_NOT_FOUND);
    }
     
    requestHelper.executeBatchMulti();

    return requestHelper.getLastRetCode();

}


/************************************************************************
**
**  Function    :   SubscriptionDaemon::SUBD_Proceed()
**
**  Description :   Main daemon loop
**
**  Argument    : srvcIdkeep
**                threadNo
**
*************************************************************************/
void SubscriptionDaemon::SUBD_Proceed(ThreadStateCycle & mainThreadState)
{
    NUMBER_T     daemonFreqParm = 0;
    int        daemonFreqInt = 0;
    char         dataBuf[255];
    MemoryPool   mp;    
    std::vector<DBA_DYNFLD_STP> outEvent;

    if(mainThreadState.isRunning() == false)
    {
	    return;
    }

    if (m_daemonNumber != 0 || m_totalThreads > 1)
    {
        GEN_ForceApplName(SYS_Stringer("aaa_subd",m_daemonNumber,"_",getThreadNumber()));                                    /* PMSTA-32895 - 140119 - FME Cluster Logger */
    }

    /* DLA - PMSTA-28581 - 171201 */
    SYS_SetThreadUseServerUser(true);
    AAALocalConnectionProvider::initAdminSessionMap();

    GEN_GetApplInfo(ApplSubscriptionDaemonFreq, &daemonFreqParm);
    daemonFreqInt =  static_cast<int>(daemonFreqParm);    
    if(m_daemonFrequency > 0)
    {
        daemonFreqInt = m_daemonFrequency;
    }
    if(daemonFreqInt < 1)
    {
        daemonFreqInt = 3;
    }

    FusionTimer stopFileTimer("stopFileTimer");
    stopFileTimer.setTimeOutInSeconds(daemonFreqInt);
    auto busEntityCds = SYS_GetApplSessionRankedBusEntCds(true);
    
    if(GEN_IsMultiEntity())
    {
        auto dictAttrPtr = DBA_GetDictEntityStSafe(Event)->ownerBusinessEntAttrStp;
        SUBD_SetEventBusEntIdx(dictAttrPtr != nullptr ? dictAttrPtr->progN : NO_VALUE);
    }

    bool runFail = false;

    while(runFail == false && mainThreadState.isRunning())
    {
        /* PMSTA-49437 - JBC - 220623 scope connhelper */
        DbiConnectionHelper connHelper(AAATransactionEnum::NotTransactionnal, SqlServer, ROLE_ADMIN);
        RET_CODE ret = RET_SUCCEED;

        for (size_t beIdx = 0; beIdx < busEntityCds.size() && ret == RET_SUCCEED && mainThreadState.isRunning(); beIdx++)
        {
            std::string beCode = busEntityCds[beIdx].first;

            if(GEN_IsMultiEntity())
            {   /* check if dedicated BE */
                if(SUBD_IsBusEntityValid(beCode) == false)
                {
                    continue;
                }
                if (connHelper.isValidAndInit() == false)
                {   // break for new connection
                    MSG_SendMesg(RET_DBA_ERR_NOFREESYNCCONN, 0, FILEINFO);
                    SYS_MilliSleep(3000);
                    break;
                } 
                connHelper.setCurrBusinessEntity(beCode);
            }        
            /* Get the SUBSCRIPTION DAEMON FREQUENCY system parameter value */
            GEN_GetApplInfo(ApplSubscriptionDaemonFreq, &daemonFreqParm);
            daemonFreqInt =  static_cast<int>(daemonFreqParm);
            if (m_daemonFrequency > 0)
            {
                daemonFreqInt = m_daemonFrequency;
            }
            if(daemonFreqInt < 1)
            {
                daemonFreqInt = 3;
            }
            sprintf(dataBuf, "Frequency calls to Mercator is set to %d seconds for BE = %s.", daemonFreqInt,beCode.c_str());
               
				const AAALogger& logger = AAALogger::get(AAALogger::Logger::Application); /*PMSTA-58803 - ROH - 20240812*/
				logger.info(dataBuf);


            SUBD_AddSubDFreq(beCode,daemonFreqInt);    

            int failCount = 0;
            if(mainThreadState.isRunning() &&
                (ret = SUBD_GetEventCount(connHelper, &failCount, Event_Status_Failed)) == SUBD_SUCCEED
                && failCount > 0)
            {
                /* failures are processing one at a time */
                std::set<ID_T> failEventIds;
                bool contLoop = true;
                    
                for(int i = 0;i < failCount && contLoop && mainThreadState.isRunning();i++)
                {
                    ret = SUBD_GetLockedMapEvents(connHelper, outEvent, Event_Status_Failed,beCode, mainThreadState);
                   
                    if (ret != RET_SUCCEED)
                    {
                        MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "Failed to retrieve 'Failed' events");
                        break;
                    }

                    if(outEvent.empty())
                    {
                        break;
                    }

                    for(auto it = outEvent.begin(); it != outEvent.end() && mainThreadState.isRunning();++it)
                    {
                        std::vector<DBA_DYNFLD_STP> oneEvent;
                        oneEvent.push_back(*it);                        
                        auto eventId = GET_ID(*it,A_Event_Id);
                        if(failEventIds.count(eventId) != 0)
                        {
                            contLoop = false;
                            continue;
                        };
                        failEventIds.insert(eventId);

                        if((ret = SUBD_TreatAllEvents(oneEvent, mainThreadState)) != SUBD_SUCCEED)
                        {                           
                            MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, SYS_Stringer("Failed to manage event [",GET_ID(oneEvent[0],A_Event_Id),"] with status 'Failed'").c_str());
                        }
                    }

                    if(SUBD_UnlockEventMap(connHelper) != RET_SUCCEED)
                    {
                        MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "Failed to unlock lock_event_map");
                    }
                    DBA_FreeDynStVector(outEvent,A_Event);
                }            
            }              
            DBA_FreeDynStVector(outEvent,A_Event);
        }
        runFail =true;
    }

    DBA_FreeDynStVector(outEvent,A_Event);
    bool shutdownSUBD = false;
	FusionTimer purgeTimer("purgeTimer");
	purgeTimer.setTimeOutInSeconds(3600);  // once an hour
	purgeTimer.resetTimer();

     /* PMSTA-66218 - JBC - 20250221
     ** Class for non-sequential multi-threading. Treats all threads > 1 as workers and fills shared queue
     ** implemented for untreated only
     */
	 if(getTotalThreadCount() > 1 && isPrimeThread())
	 {
         std::string msg = SYS_Stringer("MultiThread Option M = ",getMultiThreadMode()," [",getMultiThreadModeStr(),"] Active").c_str();
         MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, msg.c_str());
		 TraceMessage((char *)__FILE__, __LINE__, msg.c_str());
	 }

    while(shutdownSUBD == false && mainThreadState.isRunning())
    {
        /* PMSTA-49437 - JBC - 220623 recycle connhelper */
        DbiConnectionHelper connHelper(AAATransactionEnum::NotTransactionnal, SqlServer, ROLE_ADMIN);        

        if(connHelper.isValidAndInit() == false)
        {   // sleep and retry again
            MSG_SendMesg(RET_DBA_ERR_CANNOTCONNECT, 0, FILEINFO);
            SYS_MilliSleep(3000);
            continue;
        }

        do
        {
            RET_CODE ret = RET_SUCCEED;
            try{			    
                
			    std::map<std::string,FusionTimer *> &  busEntityFreqMap =  SUBD_GetFreqMap();
                for(auto it = busEntityFreqMap.begin();it != busEntityFreqMap.end() && ret == SUBD_SUCCEED && mainThreadState.isRunning();++it)
                {
                    if(isMultiThreadOverride() && isPrimeThread() == false && SV_SubdMultiQueue.isEmpty()) /* PMSTA-66218 - JBC - 20250221 */
                    {	                    
	                     SYS_MilliSleep(200);
                    }
                    else
                    {
                        if(it->second->isTimedOut())
	                    {
	                        it->second->resetTimer();
	                    }
	                    else
	                    {
	                        SYS_MilliSleep(500);
	                        continue;
	                    }
                    }

                    DBA_FreeDynStVector(outEvent,A_Event);

                    if(isMultiThreadOverride() == false || isPrimeThread()) /* PMSTA-66218 - JBC - 20250221 */
                    {
	                    if (mainThreadState.isRunning() == false || (GEN_IsMultiEntity()  == false && connHelper.isValidAndInit() == false) || connHelper.setCurrBusinessEntity(it->first) == false)
	                    {   // exit for new connection
	                        break;
	                    }
                    }

                    int eventCnt = 0;
                    if((ret = SUBD_GetEventCount(connHelper, &eventCnt, Event_Status_Untreated)) == SUBD_SUCCEED
							&& eventCnt > 0)
                    {
                        /* get block of events for a locked map */                  
                        if ((ret = SUBD_GetLockedMapEvents(connHelper, outEvent, Event_Status_Untreated,it->first,mainThreadState)) != RET_SUCCEED)
                        {
                            MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "Failed to retrieve 'Untreated' events");
                            DBA_FreeDynStVector(outEvent, A_Event);
                            continue;
                        }


                        if(ret == RET_SUCCEED && outEvent.empty() == false && mainThreadState.isRunning())
                        {                       
                            if((ret = SUBD_TreatAllEvents(outEvent,mainThreadState)) != SUBD_SUCCEED)
                            {
                                MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "Failed to manage events with status 'Untreated'");
                            }

                            /* PMSTA-66218 - JBC - 20250221 */
                            /* non-prime threads with events only mark thread completed */
						    if(isMultiThreadOverride())
						    {   
                                if(isPrimeThread() == false)
                                {
	                                int cnt = SV_SubdMultiQueue.decWorkerThread();
                                    TraceMessage((char *)__FILE__, __LINE__, SYS_Stringer("MultiThreadOverride: Processed ",outEvent.size()," records. Active Threads remaining: ",cnt).c_str());   
                                }
                                else
                                {   // wait for all workers to finish
                                    TraceMessage((char *)__FILE__, __LINE__, SYS_Stringer("MultiThreadOverride: Prime Thread waiting for ",SV_SubdMultiQueue.getWorkerThreadCount()," worker threads.").c_str());
									while(mainThreadState.isRunning() && (SV_SubdMultiQueue.isEmpty() == false || SV_SubdMultiQueue.getWorkerThreadCount() > 0))
									{
										SYS_MilliSleep(200);
									}

                                    TraceMessage((char *)__FILE__, __LINE__,"MultiThreadOverride: All worker threads complete. Unlocking map.");
                                    // unlock by prime only.
                                    if(SUBD_UnlockEventMap(connHelper) != RET_SUCCEED)
		                            {
		                                MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "Failed to unlock lock_event_map");
		                            }
                                }
						    }
                            else if(SUBD_UnlockEventMap(connHelper) != RET_SUCCEED)
                            {
                                MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "Failed to unlock lock_event_map");
                            }
                        }
                    }
                }

                if(mainThreadState.isRunning() && ret == RET_SUCCEED)
                {
                    ret = SUBD_PurgeEvents(connHelper, purgeTimer);
                }
                        

                if(mainThreadState.isRunning() && isPrimeThread() && stopFileTimer.isTimedOut())
                {
                    shutdownSUBD = SUBD_CheckStopFileOrStopState(false) == 1;
                    stopFileTimer.resetTimer();
                }

                 DBA_FreeDynStVector(outEvent,A_Event);
        
            }	 /* PMSTA-47289 - BSV - 180522 */
            catch (std::exception &e)
            {
                MSG_LogMesg(RET_GEN_ERR_PERSONAL,1,FILEINFO, e.what());   
                SYS_MilliSleep(2000);
	            break;
            }

        } while(shutdownSUBD == false && mainThreadState.isRunning());
    }

     DBA_FreeDynStVector(outEvent,A_Event);
}



/************************************************************************
**
**  Function    :   SUBD_LoadEventsStatus()
**
**  Description :
**
**  Argument    :
**
*************************************************************************/
RET_CODE SubscriptionDaemon::SUBD_LoadEventsStatus(std::vector<DBA_DYNFLD_STP> & events, std::vector<DBA_DYNFLD_STP> & eventStatus)
{
    MemoryPool           mp;
    DbiConnectionHelper connHelper(AAATransactionEnum::NotTransactionnal, SqlServer, ROLE_ADMIN);
    DBA_DYNFLD_STP * aEventStatusTab = nullptr;
    int             aEventStatusNb = 0;

    if (events.empty())
    {
        return RET_GEN_ERR_INVARG;
    }

    DBA_DYNFLD_STP  aLockEventMap = mp.allocDynst(FILEINFO, A_LockEventMap);

    if (aLockEventMap == NULL)
    {
        return RET_MEM_ERR_ALLOC;
    }

    ID_T maxEventId = ZERO_ID;
    for(size_t i=0;i<events.size();i++)
    {
        maxEventId = std::max(maxEventId,GET_ID(events[i],A_Event_Id));
    }

    SET_ID(aLockEventMap, A_LockEventMap_Id, maxEventId);
    SET_NOTE(aLockEventMap,A_LockEventMap_MapStorage,GET_NOTE(events[0],A_Event_MapStorage));
    SET_CODE(aLockEventMap,A_LockEventMap_BusEntityCd,GET_CODE(events[0],A_Event_BusEntityCd));
    SET_ID(aLockEventMap,A_LockEventMap_ServiceId,m_serviceId);
    SET_INT(aLockEventMap,A_LockEventMap_Rank,(isMultiThreadOverride() ? 1 : m_threadRank));    /* PMSTA-66218 - JBC - 20250221 */

	/* PMSTA-47289 - BSV - 180522 */
    if (connHelper.isValidAndInit() == false)
    {
       MSG_SendMesg(RET_DBA_ERR_NOFREESYNCCONN, 0, FILEINFO);
       return(DBA_CONN_NOT_FOUND);
    }

    /* sel_all_event_status_by_lock */
    if(connHelper.dbaSelect(EventStatus,DBA_ROLE_CLUSTER,aLockEventMap,A_EventStatus,&aEventStatusTab, &aEventStatusNb) != RET_SUCCEED)
    {
        DBA_FreeDynStTab(aEventStatusTab,aEventStatusNb,A_EventStatus);
        return DBA_CONN_NOT_FOUND;
    }

     /* sort ids */
    std::map<ID_T,DBA_DYNFLD_STP> eventStatusMap;
    for (int i= 0; i < aEventStatusNb; i++)
    {
        eventStatusMap[GET_ID(aEventStatusTab[i],A_EventStatus_Id)] = aEventStatusTab[i];
    }

    /* match to expected events */
    for(size_t i=0;i<events.size();i++)
    {
        ID_T eventId = GET_ID(events[i],A_Event_Id);
        if(GET_FLAG(events[i],A_Event_EventStatusFlg) == TRUE)
        {
            if(eventStatusMap.count(eventId) != 0)
            {   // keep
                eventStatus.push_back(eventStatusMap[eventId]);
                eventStatusMap.erase(eventId);
            }
            else
            {   
                MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, SYS_Stringer("Failed to load event_status for event ",eventId,". event_status record required due to event.event_status_f = 1.").c_str());
                DBA_FreeDynStTab(aEventStatusTab,aEventStatusNb,A_EventStatus);
                return RET_DBA_ERR_NODATA;
            }
        }
        else
        {
            eventStatus.push_back(nullptr);
        }       
    }

    /* free remaining records in map */
    for(auto it = eventStatusMap.begin(); it != eventStatusMap.end();++it)
    {
        FREE_DYNST(it->second,A_EventStatus);
        it->second = nullptr;
    }

    return RET_SUCCEED;
}

/************************************************************************
**
**  Function    :   SUBD_TreatEventsByBlock()
**
**  Description :   deal with a block of events in single transaction
**                  allows control over send to marcator to test commit
**
**  Argument    :
**
*************************************************************************/
RET_CODE SubscriptionDaemon::SUBD_TreatEventsByBlock(std::vector<DBA_DYNFLD_STP> & eventBlock,std::vector<DBA_DYNFLD_STP> & eventStatusBlock, 
    std::string map_path, const bool sendToMercator, size_t & totalCounter, bool & isFatal, ThreadStateCycle & mainThreadState)
{
    RET_CODE    ret = RET_SUCCEED;
    char        txtBuf[512];
    DATETIME_T           eventCreatDate;
    HOUR_T               hour;
    MINUTE_T             minute;
    SECOND_T             second;
    YEAR_T               year;
    MONTH_T              month;
    DAY_T                day;
    DbiConnectionHelper connHelper(AAATransactionEnum::NotTransactionnal, SqlServer, ROLE_ADMIN);
    static bool         isNoRunMap = SYS_GetEnv("AAASUBDNORUNMAP") != nullptr; /* debug config */

    /* Open a transaction */
    if (mainThreadState.isRunning() == false || connHelper.isValidAndInit() == false || connHelper.getConnection()->beginTransaction() != RET_SUCCEED)
    {
        sprintf(txtBuf, "Unable to open a transaction for connection (%d).", connHelper.getConnection()->getId());
        MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, txtBuf);
        SUBD_ChangeAllEventsStatus(connHelper, eventBlock, Event_Status_Failed,eventStatusBlock, false);
        DBA_CreateTempTables(*connHelper.getConnection(), SUBD_DOM_OPE);/* DLA - PMSTA-11512 - 110224 */
        isFatal = true;
        return SUBD_ERROR;
    }

    /* call stored procedure to update operation es */
    if (mainThreadState.isRunning() == false || (ret = SUBD_UpdateOpStatus(connHelper, eventBlock, eventStatusBlock)) != SUBD_SUCCEED)
    {
        MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "Failed to update block of operation status.");
        connHelper.getConnection()->endTransaction(false);

        /* put this block to failed */
        ret = SUBD_ChangeAllEventsStatus(connHelper, eventBlock, Event_Status_Failed, eventStatusBlock, false);
        if (ret != SUBD_SUCCEED)
        {
            isFatal = true;
            return SUBD_ERROR;
        }
        DBA_CreateTempTables(*connHelper.getConnection(), SUBD_DOM_OPE);/* DLA - PMSTA-11512 - 110224 */
        connHelper.getConnection()->endTransaction(false);

        totalCounter += eventBlock.size();
        isFatal = false;
        return SUBD_ERROR;
    }

    AAATracer::AAASpan currentTraceSpan = AAATelemetry::GetTracer(AAATracer::TraceName::Subscription).startNewSpan("Processing Event Block");

    {
        std::ostringstream _oss;
        _oss << "processisng # " << eventBlock.size() << " event(s)";
        currentTraceSpan.log("toProcess", _oss.str());
    }

    /*
    * 2 possibilities depending on the 'keep event flag':
    *   - We want to delete each event sent to Mercator.
    *   - We just want to set its status to 'Succeed'.
    */
    for (size_t i = 0; i < eventBlock.size() && mainThreadState.isRunning(); i++)
    {
        {
            std::ostringstream _oss;
            _oss << "status to Event_Status_Succeed event id=" << GET_ID(eventBlock[i], A_Event_Id);
            currentTraceSpan.log("Update event", _oss.str());;
        }
    }

    if (mainThreadState.isRunning() == false || SUBD_ChangeAllEventsStatus(connHelper, eventBlock, Event_Status_Succeed, eventStatusBlock, m_keepEvent == false) != SUBD_SUCCEED)
    {
        connHelper.getConnection()->endTransaction(false);
        SUBD_ChangeAllEventsStatus(connHelper, eventBlock, Event_Status_Failed, eventStatusBlock, false);
        DBA_CreateTempTables(*connHelper.getConnection(), SUBD_DOM_OPE);/* DLA - PMSTA-11512 - 110224 */
        isFatal = true;
        return SUBD_ERROR;
    }
    
    if (mainThreadState.isRunning() && !m_keepEvent)
    {
         for (size_t i = 0; i < eventBlock.size() && mainThreadState.isRunning(); i++)
         {    
            TraceMessage((char *)__FILE__, __LINE__, "Delete event %" szFormatId,   GET_ID(eventBlock[i], A_Event_Id)); /* DLA - PMSTA08801 - 100616 */
         }

        if(mainThreadState.isRunning() == false || (ret = SUBD_DeleteEvent(connHelper, eventBlock)) != RET_SUCCEED)
        {
            eventCreatDate = GET_DATETIME(eventBlock[0], A_Event_CreationDate);
            TIME_Get(eventCreatDate.time, &hour, &minute, &second);
            DATE_Get(eventCreatDate.date, &year, &month, &day);

            sprintf(txtBuf,
                    "Error attempting to delete events. First event is "
                    "Id (%" szFormatId"), hostname (%s), " /* DLA - PMSTA08801 - 100616 */
                    "user (%s), entity (%s), creation date (%2d/%2d/%04d %2d:%2d:%2d)",
                    GET_ID(eventBlock[0], A_Event_Id),
                    GET_SYSNAME(eventBlock[0], A_Event_Hostname),
                    GET_SYSNAME(eventBlock[0], A_Event_User),	/* DLA - PMSTA09887 - 101115 */
                    GET_SYSNAME(eventBlock[0], A_Event_EntSqlName),
                    month, day, year, hour, minute, second);

            MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, txtBuf);
            connHelper.getConnection()->endTransaction(false);

            SUBD_ChangeAllEventsStatus(connHelper, eventBlock, Event_Status_Failed, eventStatusBlock, false);

            DBA_CreateTempTables(*connHelper.getConnection(), SUBD_DOM_OPE);/* DLA - PMSTA-11512 - 110224 */
            isFatal = true;
            currentTraceSpan.log("error","Deleting event").setTag("error", true).finish();
            return SUBD_ERROR;
        }
    }
        
    /* Was moved before update event status for deadlock reasons  */
    /* and re-moved here as LN7730                                */
    /* call Mercator for all those events                         */   

    /* Truncate temporary tables */
    if (mainThreadState.isRunning() == false || (ret = DBA_CreateTempTables(*connHelper.getConnection(), ALL_TEMP_TABLES)) != RET_SUCCEED)
    {
        MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "Unable to create temporary tables");
        connHelper.getConnection()->endTransaction(false);
        SUBD_ChangeAllEventsStatus(connHelper, eventBlock, Event_Status_Failed, eventStatusBlock, false);
        isFatal = true;
        return SUBD_ERROR;
    }

    /* only send once  */
    if(sendToMercator && isNoRunMap == false && mainThreadState.isRunning())
    {
        TraceMessage((char *)__FILE__, __LINE__, SYS_Stringer("Sending ",eventBlock.size()," events to ITX.").c_str());

	        ret = SUBD_SendAllEventsToMercator(eventBlock,map_path);

        if (ret != RET_SUCCEED)
        {
            std::string errormsg = SYS_Stringer("Failed to send all events to Mercator for map (", GET_NOTE(eventBlock[0], A_Event_MapStorage), " ).");
            MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, errormsg.c_str());
            TraceMessage((char *)__FILE__, __LINE__, errormsg.c_str());
            connHelper.getConnection()->endTransaction(false);

            {
                std::ostringstream _oss;
                _oss << "WTX processing done for # " << eventBlock.size() << " event(s)";
                currentTraceSpan.log("Update event", _oss.str()).setTag("error", true).finish();
            }

            /* put this block to failed */
            ret = SUBD_ChangeAllEventsStatus(connHelper,eventBlock, Event_Status_Failed, eventStatusBlock, false);
            if (ret != SUBD_SUCCEED)
            {
                isFatal = true;
                return SUBD_ERROR;
            }
            DBA_CreateTempTables(*connHelper.getConnection(), SUBD_DOM_OPE);/* DLA - PMSTA-11512 - 110224 */
            isFatal = false;
            return SUBD_ERROR;
        }
		TraceMessage((char *)__FILE__, __LINE__, SYS_Stringer("ITX Processed ",eventBlock.size()," events.").c_str());
        {
            std::ostringstream _oss;
            _oss << "ITX processing done for # " << eventBlock.size() << " event(s)";
            currentTraceSpan.log("Update event", _oss.str()).finish();
        }
    }

    if((ret = connHelper.getConnection()->endTransaction(true)) != RET_SUCCEED)       /* Commit changes. */
    {   /* allow retry */
        isFatal = false;
    }
    DBA_CreateTempTables(*connHelper.getConnection(), SUBD_DOM_OPE);/* DLA - PMSTA-11512 - 110224 */

    return ret;
}

/************************************************************************
**
**  Function    :   SUBD_TreatAllEvents()
**
**  Description :   deal with a block of events
**                  treat all events marked with eventStatus
**
**  Argument    :
**
*************************************************************************/
RET_CODE SubscriptionDaemon::SUBD_TreatAllEvents(std::vector<DBA_DYNFLD_STP> & events, ThreadStateCycle & mainThreadState)
{
    MemoryPool           mp;
    std::vector<DBA_DYNFLD_STP> outEventStatus;
    RET_CODE             ret = RET_SUCCEED;
    char                 txtBuf[512];
    DATETIME_T           eventCreatDate;
    HOUR_T               hour;
    MINUTE_T             minute;
    SECOND_T             second;
    YEAR_T               year;
    MONTH_T              month;
    DAY_T                day;
    char                 strDate[DATETIME_SQL_STRING_SIZE];	/* PMSTA-18583 - TEB - 160321 */
    static bool firstTime = true;
    static bool traceOn = false;
    DbiConnectionHelper connHelper(AAATransactionEnum::NotTransactionnal, SqlServer, ROLE_ADMIN);

    if (firstTime)
    {
        firstTime = false;
        if (getenv("AAASUBDTRACE") != NULL)
        {
            traceOn = true;
        }
    }

    /* Open a connection */
    if (connHelper.isValidAndInit() == false)
    {
        MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "Unable to get a connection");
        return SUBD_ERROR;
    }


    AAATracer::AAASpan currentTraceSpan = AAATelemetry::GetTracer(AAATracer::TraceName::Subscription).startNewSpan("Processing Events");

    {
        std::ostringstream _oss;
        _oss << "processisng " << events.size() << " event(s). First " << GET_ID(events[0],A_Event_Id) << " Last " << GET_ID(events[events.size()-1],A_Event_Id);
        currentTraceSpan.log("toProcess", _oss.str());

        if (traceOn)
	    {
	        TraceMessage((char *)__FILE__, __LINE__, _oss.str().c_str());
	    }   
    }

    if (SUBD_LoadEventsStatus(events, outEventStatus) != RET_SUCCEED)
    {
        currentTraceSpan.log("errorMessage", "Unable to load events from event_status").setTag("error", true).finish();
        MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "Unable to load events from event_status");
        DBA_FreeDynStVector(outEventStatus, A_EventStatus);
        return SUBD_ERROR;
    }

    if (traceOn && mainThreadState.isRunning())
    {
        for (size_t i = 0; i < events.size() && mainThreadState.isRunning(); i++)
        {
            eventCreatDate = GET_DATETIME(events[i], A_Event_CreationDate);
            TIME_Get(eventCreatDate.time, &hour, &minute, &second);
            DATE_Get(eventCreatDate.date, &year, &month, &day);

            DATETIME_ToDbStr(strDate, eventCreatDate.date, eventCreatDate.time);		/* PMSTA-18583 - TEB - 160321 */

            sprintf(txtBuf,
                    "%" szFormatId", %s, %s, %s, %s, %d", /* DLA - PMSTA08801 - 100616 */ /* PMSTA-18583 - TEB - 160321 */
                    GET_ID(events[i], A_Event_Id),
                    GET_SYSNAME(events[i], A_Event_EntSqlName),
                    strDate,                                                  /* PMSTA-18583 - TEB - 160321 */
                    (IS_NULLFLD(events[i], A_Event_UpdateStsName) == TRUE) ? "NULL" :
                    GET_NAME(events[i], A_Event_UpdateStsName),
                    GET_NOTE(events[i], A_Event_MapStorage),
                    GET_ENUM(events[i], A_Event_StatusEn));
            TraceMessage((char *)__FILE__, __LINE__, "Event : %s", txtBuf);
        }
    }

    /* Set all events to Running */
    if ((ret = connHelper.getConnection()->beginTransaction()) != RET_SUCCEED)
    {
        sprintf(txtBuf, "Unable to open a transaction for connection (%d).", connHelper.getConnection()->getId());
        MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, txtBuf);
        DBA_FreeDynStVector(outEventStatus, A_EventStatus);
        return SUBD_ERROR;
    }

    ret = SUBD_ChangeAllEventsStatus(connHelper,events,Event_Status_Running, outEventStatus, false);

    if (mainThreadState.isRunning() == false || ret != SUBD_SUCCEED)
    {
        connHelper.getConnection()->endTransaction(false);
        DBA_FreeDynStVector(outEventStatus, A_EventStatus);
        return SUBD_ERROR;
    }

    connHelper.getConnection()->endTransaction(true);/* COMMIT */

    /* we now parse events by host/format, so only the remaining
     * break points listed below are reviewed.
     */
    std::set<std::string> keySet;
    std::map<std::string, std::vector<DBA_DYNFLD_STP>> eventByHostFmt;
    std::map<std::string, std::vector<DBA_DYNFLD_STP>> eventStatByHostFmt;
   

    for(size_t i = 0; i< events.size() && mainThreadState.isRunning(); i++)
    {
        std::string key = IS_NULLFLD(events[i], A_Event_Hostname) ? "NULLHOST" : GET_SYSNAME(events[i], A_Event_Hostname);
		key.append("_").append(IS_NULLFLD(events[i], A_Event_FormatId) ? "NULLFMT" : std::to_string(GET_ID(events[i], A_Event_FormatId)));/* PMSTA-47907 - VSW - 040222 */
        
        keySet.insert(key);
        eventByHostFmt[key].push_back(events[i]);
        eventStatByHostFmt[key].push_back(outEventStatus[i]);
    }

    if(eventByHostFmt.empty())
    {
        return SUBD_ERROR;
    }
    std::string map_path;    
    GEN_GetApplInfo(ApplSubscriptionFilePath, map_path); /* PMSTA-48941 - JBC - 220423 */

    size_t  totalCounter = 0;
    size_t  keyCounter = 0;
    for(auto itKey = keySet.begin(); itKey != keySet.end() && mainThreadState.isRunning();++itKey)
    {
        std::vector<DBA_DYNFLD_STP> & hostFmtEvents = eventByHostFmt[*itKey];
        std::vector<DBA_DYNFLD_STP> & hostFmtEventStatus = eventStatByHostFmt[*itKey];

        if (traceOn && mainThreadState.isRunning())
        {
            TraceMessage((char *)__FILE__, __LINE__, SYS_Stringer("Block ",keyCounter," has ",hostFmtEvents.size()," events.").c_str());
            for (size_t i = 0; i < hostFmtEvents.size() && mainThreadState.isRunning(); i++)
            {
                eventCreatDate = GET_DATETIME(events[i], A_Event_CreationDate);
                TIME_Get(eventCreatDate.time, &hour, &minute, &second);
                DATE_Get(eventCreatDate.date, &year, &month, &day);

                DATETIME_ToDbStr(strDate, eventCreatDate.date, eventCreatDate.time);		/* PMSTA-18583 - TEB - 160321 */

                sprintf(txtBuf,
                        "%" szFormatId", %s, %s, %s, %s, %s, %d", /* DLA - PMSTA08801 - 100616 */  /* PMSTA-18583 - TEB - 160321 */
                        GET_ID(events[i], A_Event_Id),
                        GET_SYSNAME(events[i], A_Event_EntSqlName),
                        strDate,                                                  /* PMSTA-18583 - TEB - 160321 */
                        (IS_NULLFLD(events[i], A_Event_UpdateStsName) == TRUE) ? "NULL" :
                        GET_NAME(events[i], A_Event_UpdateStsName),
                        GET_NOTE(events[i], A_Event_MapStorage),
                        (IS_NULLFLD(events[i], A_Event_BusEntityCd) == TRUE) ? "NULL" :
                        GET_CODE(events[i], A_Event_BusEntityCd),
                        GET_ENUM(events[i], A_Event_StatusEn));
                TraceMessage((char *)__FILE__, __LINE__, "Event : %s", txtBuf);
            }
        }

        /* REF6963 - 010829 - CHU > */
        bool isFatal = true;;
        if((ret = SUBD_TreatEventsByBlock(hostFmtEvents,hostFmtEventStatus,map_path,true, totalCounter,isFatal, mainThreadState)) != RET_SUCCEED)
        {
            if(isFatal)
            {
              DBA_FreeDynStVector(outEventStatus, A_EventStatus);
              return SUBD_ERROR;
            }           
        }

        /* PMSTA-48941 - JBC - 220430 ensure transaction is commited. Mercator is successful. */
        /* if first event still running means commit issue. should not exist */
        int retryNb = 0;
        while(retryNb < m_commitRetryNb && SUBD_CheckEventUpdated(GET_ID(hostFmtEvents[0], A_Event_Id), Event_Status_Running) == RET_DBA_INFO_EXIST
            && mainThreadState.isRunning())
        {
            connHelper.getConnection()->setValidConnection(false);
            connHelper.isValidAndInit();
            /* still running note problem and try update again without mercator. */
            MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, 
                SYS_Stringer("Block update commit not successful for first eventId [",
                    GET_ID(hostFmtEvents[0], A_Event_Id),"] connection [",
                    connHelper.getConnection()->getId(),"] but Sent successfully to WTX. Retrying update [",retryNb+1,"].").c_str());
            
            size_t dummyCounter;
            isFatal = true;
            ret = SUBD_TreatEventsByBlock(hostFmtEvents,hostFmtEventStatus,map_path,false, dummyCounter,isFatal,mainThreadState);
            retryNb++;
        }

        if(ret != RET_SUCCEED)
        {
            if(isFatal || retryNb >= m_commitRetryNb)
            {
              DBA_FreeDynStVector(outEventStatus, A_EventStatus);
              return SUBD_ERROR;
            }
            /* run next set */
            continue;
        }
        /* pass to next block */
        totalCounter += hostFmtEvents.size();
        keyCounter++;
        if(keySet.size() > keyCounter)
        {
			TraceMessage((char *)__FILE__, __LINE__, "Go to next block, begin will be %d", static_cast<int>(totalCounter));
        }
    }

     TraceMessage((char *)__FILE__, __LINE__, SYS_Stringer("Processed ",totalCounter," Event(s) in ",keySet.size()," Block(s).").c_str());

    DBA_FreeDynStVector(outEventStatus, A_EventStatus);

    /* unlock already in parent function 
    if(SUBD_UnlockEventMap(connHelper) != RET_SUCCEED)
    {
        MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "Failed to unlock lock_event_map");
        return SUBD_ERROR;
    }
    */

    return SUBD_SUCCEED;
}

/************************************************************************
**
**  Function    :   SUBD_LockEventMap()
**
**  Description :   Attempts to lock a specific map/bus entity for processing
**
**  Argument    : map
**
*************************************************************************/
bool SubscriptionDaemon::SUBD_LockEventMap(DbiConnectionHelper & connHelper, DBA_DYNFLD_STP  aEvent)
{
    if(m_serviceId == ZERO_ID)
    {
        return false;
    }

    MemoryPool          mp;
    DBA_DYNFLD_STP      sLockEventMap =  mp.allocDynst(FILEINFO, S_LockEventMap);
    RET_CODE            ret = RET_SUCCEED;
    std::string         be = IS_NULLFLD(aEvent,A_Event_BusEntityCd) ? "NULL" : GET_CODE(aEvent,A_Event_BusEntityCd);

    SET_NOTE(sLockEventMap, S_LockEventMap_MapStorage, GET_NOTE(aEvent,A_Event_MapStorage));
    SET_CODE(sLockEventMap, S_LockEventMap_BusEntityCd,be.c_str());
    SET_ID(sLockEventMap, S_LockEventMap_ServiceId, m_serviceId);
    SET_INT(sLockEventMap, S_LockEventMap_Rank, m_threadRank);
    SET_INT(sLockEventMap, S_LockEventMap_ReturnStatus, -1);

    ret =  connHelper.dbaUpdate(LockEventMap, DBA_ROLE_CLUSTER, sLockEventMap);

    return ret == RET_SUCCEED &&  GET_INT(sLockEventMap, S_LockEventMap_ReturnStatus) == 0;
}

/************************************************************************
**
**  Function    :   SUBD_UnlockEventMap()
**
**  Description :   unlocks all maps associated with this service/thread
**
**  Argument    : map
**
*************************************************************************/
RET_CODE SubscriptionDaemon::SUBD_UnlockEventMap(DbiConnectionHelper & connHelper)
{
    if(m_serviceId == ZERO_ID)
    {
        return -1;
    }

    MemoryPool          mp;
    DBA_DYNFLD_STP      unlockArg = mp.allocDynst(FILEINFO, Get_Arg);

    SET_ID(unlockArg, Get_Arg_Id, m_serviceId );
    SET_INT(unlockArg, Get_Arg_Integer, m_threadRank);

	/* PMSTA-47289 - BSV - 180522 */
    if (connHelper.isValidAndInit() == false)
    {
        MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "Unable to get a connection");
        return SUBD_ERROR;
    }
    /* all ptf unlocked at once */
    /* unlock_portfolio_by_sid */
    return connHelper.dbaUpdate(LockEventMap, DBA_ROLE_CLUSTER, unlockArg);
}

/************************************************************************
**
**  Function    :   SUBD_GetLockedMapEvents()
**
**  Description :   queries and attemtps to lock a map, returning a
**                  second query of just events for the map
**
**  Argument    : map
**
*************************************************************************/
RET_CODE SubscriptionDaemon::SUBD_GetLockedMapEvents(DbiConnectionHelper & connHelper, std::vector<DBA_DYNFLD_STP> & outLockedEvent, EVENT_STATUS_ENUM status, std::string beCd, ThreadStateCycle & mainThreadState)
{
    /* treat all events marked as failed. */
    RET_CODE             ret = SUBD_SUCCEED;
    std::vector<DBA_DYNFLD_STP> mainEvents;   

    /* PMSTA-65355 - JBC - 20250205 */
    if(isMultiThreadOverride() && isPrimeThread() == false && status == Event_Status_Untreated)
    {   // look for work
		std::string toBeCd;
        int activeThreads = 0;
    	SV_SubdMultiQueue.getEventList(outLockedEvent,toBeCd,activeThreads);
        if(outLockedEvent.empty() == false)
        {
            TraceMessage((char *)__FILE__, __LINE__, SYS_Stringer("MultiThreadOverride: Pop ",outLockedEvent.size()," events from worker queue. Worker threads active: ",activeThreads).c_str());
	        if(GEN_IsMultiEntity() )
	        {   // set BE
		        connHelper.setCurrBusinessEntity(toBeCd);
	        }
        }        
        return SUBD_SUCCEED;
    }
    
    /* Open a connection */
    if (connHelper.isValidAndInit() == false)
    {
        MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "Unable to get a connection");
            return SUBD_ERROR;
    }

    std::set<std::string>   blockedMapBEKeys;  /* maps/BE pairs locked by other threads or already processed */
    ID_T                    maxEventId = ZERO_ID;   

    while(((ret = SUBD_CustomEventSelect(connHelper, mainEvents, status, maxEventId, nullptr)) == RET_SUCCEED)
        && mainEvents.empty() == false && mainThreadState.isRunning())
    {
        /* track last event id */
        maxEventId = GET_ID(mainEvents[mainEvents.size() - 1],A_Event_Id);
        blockedMapBEKeys.clear();

        for (size_t i = 0; i < mainEvents.size() && mainThreadState.isRunning(); i++)
        {            
            /* composite key */
            std::string mainMapBEKey = SYS_Stringer(GET_NOTE(mainEvents[i],A_Event_MapStorage),
                "~",(IS_NULLFLD(mainEvents[i],A_Event_BusEntityCd) ? "" : GET_CODE(mainEvents[i],A_Event_BusEntityCd)));
            if(GEN_IsMultiEntity())
            {
                mainMapBEKey.append(SYS_Stringer("~",GET_ID(mainEvents[i],SUBD_GetEventBusEntIdx())));
            }

            /* row treated or blocked already, or not the exepcted BE -> skip */
            if(blockedMapBEKeys.count(mainMapBEKey) != 0
                || (GEN_IsMultiEntity() 
                    && connHelper.isConnBusEntityIdEqualTo(GET_ID(mainEvents[i],SUBD_GetEventBusEntIdx())) == false)
             )
            {                
                continue;
            }

            /* attempt lock */
            if(mainThreadState.isRunning() && SUBD_LockEventMap(connHelper, mainEvents[i]))
            {
                /* PMSTA-34827 - JBC - 19021 */
                /* now that the map is locked, get block of events for map */
                if(mainThreadState.isRunning() && (ret = SUBD_CustomEventSelect(connHelper, outLockedEvent, status, ZERO_ID, mainEvents[i])) == RET_SUCCEED)
                {
                    /* PMSTA-66218 - JBC - 20250221 */                 
				    if(isMultiThreadOverride() && isPrimeThread() && status == Event_Status_Untreated 
                        && outLockedEvent.empty() == false && outLockedEvent.size() > m_blockSize)
				    {   // use block size when given, for unlimited block split across threads                      
                        size_t newBlockSize = m_blockSize > 0 ? m_blockSize : outLockedEvent.size() / static_cast<size_t>(getTotalThreadCount()) + 1;                        
                        // keep the block set, give rest to queue
                        TraceMessage((char *)__FILE__, __LINE__, SYS_Stringer("MultiThreadOverride: Added ",outLockedEvent.size()-newBlockSize," events to worker queue with block size ",newBlockSize,".").c_str());
                        SV_SubdMultiQueue.splitEventsAndResize(outLockedEvent,newBlockSize,beCd);
                    }

                    /* return to caller as we have rows to process */
                    DBA_FreeDynStVector(mainEvents, A_Event);
                    return SUBD_SUCCEED;
                }

                blockedMapBEKeys.insert(mainMapBEKey);
                DBA_FreeDynStVector(outLockedEvent, A_Event);
            }
            else
            {  /* mark handled and blocked */
               blockedMapBEKeys.insert(mainMapBEKey);
            }
        }
        DBA_FreeDynStVector(mainEvents, A_Event);
    }
    return SUBD_SUCCEED;
}

/************************************************************************
**
**  Function    :   SUBD_FindValueInEvent()
**
**  Description :   find a value for specified key in data string
**
**  Argument    :   data  - buffer with the data from event
**                  key   - key to find
**                  value - value for the key
**  Return values:  SUBD_SUCCEED key was found
**                  SUBD_ERROR   key not found
**
*************************************************************************/
RET_CODE SUBD_FindValueInEvent(char *data, char *key, char *value)
{
    char                     *pData = data;
    char                     *pKey, *pValue;
    size_t                    keyLen = 0, valueLen = 0;
    char                     *pSemiColon;
    char                     lKey[256], lValue[256], lValue2[256];
    char                     endOfValue[4];

    while ((pSemiColon = strstr(pData, RS_STR)) != NULL)
    {
        pKey = pData;
        pData = pSemiColon + 1;

        while (isspace(*pKey))
            pKey++;

        keyLen = strcspn(pKey, "= \t");

        strncpy(lKey, pKey, keyLen);
        lKey[keyLen] = '\0';

        pValue = strstr(pKey, "=");

        if (pValue == NULL)
            return SUBD_ERROR;

        pValue++;
        while (isspace(*pValue))
            pValue++;

        sprintf(endOfValue, "%c%s", RS_SEP, " \t");
        valueLen = strcspn(pValue, endOfValue);

        strncpy(lValue, pValue, valueLen);
        lValue[valueLen] = '\0';

        if (strcmp(lKey, key) == 0)
        {
            /* We must remove the string delimiter character set. */
            if ((unsigned char)lValue[0] == US_SEP)
            {
                pKey = lValue + 1;
                strcpy(lValue2, pKey);
                lValue2[strlen(lValue2) - 1] = '\0';
                strcpy(value, lValue2);
            }
            else
            {
                strcpy(value, lValue);
            }

            return SUBD_SUCCEED;
        }
    }

    //sprintf(strError, "Field %s not found in event data. (see next error message).", key);
    //MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, strError);
    //MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, data);

    return SUBD_ERROR;
}

/************************************************************************
**
**  Function    :   SUBD_GetOpBusinessKey()
**
**  Description :   fill the buffer with insert statement for dom_ope table
**
**  Argument    :   event     - Event dynamic structure
**                  buffSql   - buffer filled with sql statement
**                  buffLen   - buffer length
**
*************************************************************************/
RET_CODE SubscriptionDaemon::SUBD_GetOpBusinessKey(DBA_DYNFLD_STP event, char * buffSql, int buffLen)
{
    size_t       currLen = 0;
    char         value[256];
    RET_CODE     retCode;
    char         *data;
    char         tmpStr[512];
    int          newStatus;
    char         *updateStsName;
    int          statusValue;
    char         txtBuf[512];

    data = GET_TEXT(event, A_Event_Data);

    if (data == NULL)
    {
        MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "No data in event");
        return SUBD_ERROR;
    }

    sprintf(buffSql, "insert into #dom_ope (id,code,fusion_e,sequence_no_n,status_e,parent_oper_nat_e,source_code,new_status_e,error_code) values( 0, ");	 /* PMSTA-25656 - TEB - 161215 */ 	/* PMSTA-18583 - TEB - 160321 */
    currLen += 27;

    if ((retCode = SUBD_FindValueInEvent(data, (char *)"code", value)) != SUBD_SUCCEED)
        if ((retCode = SUBD_FindValueInEvent(data, (char *)":code", value)) != SUBD_SUCCEED)
        {
            MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "Business key not found");
            return SUBD_ERROR;
        }

    sprintf(tmpStr, "'%s', ", value);
    currLen += strlen(tmpStr);

    if (currLen > buffLen)
    {
        sprintf(txtBuf, "Length exceeded. currlen (%zd) > buffLen (%d)", currLen, buffLen);
        MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, txtBuf);
        return SUBD_ERROR;
    }

    strcat(buffSql, tmpStr);

    if ((retCode = SUBD_FindValueInEvent(data, (char *)"fusion_e", value)) != SUBD_SUCCEED)
        if ((retCode = SUBD_FindValueInEvent(data, (char *)":fusion_e", value)) != SUBD_SUCCEED)
        {
            //MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "Business key not found");
            //return SUBD_ERROR;
            strcpy(value, "NULL");
        }

    sprintf(tmpStr, "%s, ", value);
    currLen += strlen(tmpStr);

    if (currLen > buffLen)
    {
        sprintf(txtBuf, "Length exceeded. currlen (%zd) > buffLen (%d)", currLen, buffLen);
        MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, txtBuf);
        return SUBD_ERROR;
    }

    strcat(buffSql, tmpStr);

    if ((retCode = SUBD_FindValueInEvent(data, (char *)"sequence_no_n", value)) != SUBD_SUCCEED)
        if ((retCode = SUBD_FindValueInEvent(data, (char *)":sequence_no_n", value)) != SUBD_SUCCEED)
        {
            //MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "Business key not found");
            //return SUBD_ERROR;
            strcpy(value, "NULL");
        }

    sprintf(tmpStr, "%s, ", value);
    currLen += strlen(tmpStr);

    if (currLen > buffLen)
    {
        sprintf(txtBuf, "Length exceeded. currlen (%zd) > buffLen (%d)", currLen, buffLen);
        MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, txtBuf);
        return SUBD_ERROR;
    }

    strcat(buffSql, tmpStr);

    if ((retCode = SUBD_FindValueInEvent(data, (char *)"status_e", value)) != SUBD_SUCCEED)
        if ((retCode = SUBD_FindValueInEvent(data, (char *)":status_e", value)) != SUBD_SUCCEED)
        {
            //MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "Business key not found");
            //return SUBD_ERROR;
            strcpy(value, "NULL");
        }

    sprintf(tmpStr, "%s, ", value);
    currLen += strlen(tmpStr);

    if (currLen > buffLen)
    {
        sprintf(txtBuf, "Length exceeded. currlen (%zd) > buffLen (%d)", currLen, buffLen);
        MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, txtBuf);
        return SUBD_ERROR;
    }

    strcat(buffSql, tmpStr);

    /* calculate newStatus */
    statusValue = atoi(value);
    newStatus = statusValue;

    updateStsName = GET_NAME(event, A_Event_UpdateStsName);

    if (updateStsName[0])
        switch (updateStsName[0])
    {
        case '+':
            if (sscanf(updateStsName + 1, "%d", &newStatus) == 1)
                newStatus += statusValue;
            break;

        case '-':
            if (sscanf(updateStsName + 1, "%d", &newStatus) == 1)
                newStatus = statusValue - newStatus;
            break;

        default:
            sscanf(updateStsName, "%d", &newStatus);
            break;
    }

    if ((retCode = SUBD_FindValueInEvent(data, (char *)"parent_oper_nat_e", value)) != SUBD_SUCCEED)
        if ((retCode = SUBD_FindValueInEvent(data, (char *)":parent_oper_nat_e", value)) != SUBD_SUCCEED)
        {
            //MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "Business key not found");
            //return SUBD_ERROR;
            strcpy(value, "NULL");
        }

    sprintf(tmpStr, "%s, ", value);
    currLen += strlen(tmpStr);

    if (currLen > buffLen)
    {
        sprintf(txtBuf, "Length exceeded. currlen (%zd) > buffLen (%d)", currLen, buffLen);
        MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, txtBuf);
        return SUBD_ERROR;
    }

    strcat(buffSql, tmpStr);

    if ((retCode = SUBD_FindValueInEvent(data, (char *)"source_code", value)) != SUBD_SUCCEED)
        if ((retCode = SUBD_FindValueInEvent(data, (char *)":source_code", value)) != SUBD_SUCCEED)
        {
            //MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "Business key not found");
            //return SUBD_ERROR;
            strcpy(value, "NULL");
        }

    sprintf(tmpStr, "'%s', ", value);
    currLen += strlen(tmpStr);

    if (currLen > buffLen)
    {
        sprintf(txtBuf, "Length exceeded. currlen (%zd) > buffLen (%d)", currLen, buffLen);
        MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, txtBuf);
        return SUBD_ERROR;
    }

    strcat(buffSql, tmpStr);
    sprintf(tmpStr, "%d, ", newStatus);
    currLen += strlen(tmpStr);

    if (currLen > buffLen)
    {
        sprintf(txtBuf, "Length exceeded. currlen (%zd) > buffLen (%d)", currLen, buffLen);
        MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, txtBuf);
        return SUBD_ERROR;
    }

    strcat(buffSql, tmpStr);
    sprintf(tmpStr, "0) ");
    currLen += strlen(tmpStr);
    if (currLen > buffLen)
    {
        sprintf(txtBuf, "Length exceeded. currlen (%zd) > buffLen (%d)", currLen, buffLen);
        MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, txtBuf);
        return SUBD_ERROR;
    }

    strcat(buffSql, tmpStr);
    return SUBD_SUCCEED;
}

/************************************************************************
**
**  Function    :   SUBD_UpdateManyOpStatus()
**
**  Description :   update operation status if required
**
**  Argument    :
**
*************************************************************************/
RET_CODE SubscriptionDaemon::SUBD_UpdateOpStatus(DbiConnectionHelper & connHelper,std::vector<DBA_DYNFLD_STP> & events, std::vector<DBA_DYNFLD_STP> & eventStatus)
{
    if(events.size() != eventStatus.size())
    {
        return SUBD_ERROR;
    }
    MemoryPool              mp;
    DBA_DYNFLD_STP          extOpSt = (DBA_DYNFLD_STP)NULL;
    char                    buffSql[1024],
                            txtBuf[1500];
    OPSTAT_ENUM             accountingStatus = (OPSTAT_ENUM)0;
    ENUM_T                  origine = 1;
    RET_CODE                dbRetCode;
    char                    *entityName;
    char                    *statusUpdate;
    DATETIME_T              eventCreatDate;
    HOUR_T                  hour;
    MINUTE_T                minute;
    SECOND_T                second;
    YEAR_T                  year;
    MONTH_T                 month;
    DAY_T                   day;
    int                     opsToUpdate;

    /* Get the ACCOUNTING STATUS system parameter value */
    GEN_GetApplInfo(ApplAccountingStatus, &accountingStatus);

    opsToUpdate = 0;

    for (size_t i = 0; i < events.size(); i++)
    {
        /* Fill operation business key */
        entityName = GET_NAME(events[i], A_Event_EntSqlName);

        /* Update operation status only if extended operation. */
        if (strcmp(entityName, "ext_operation") != 0)
        {
            continue;
        }

        /* Update operation status only if needed. */
        if (IS_NULLFLD(events[i], A_Event_UpdateStsName) == TRUE)
        {
            continue;
        }

        if (GET_FLAG(events[i], A_Event_EventStatusFlg) == TRUE && GET_ENUM(eventStatus[i], A_EventStatus_UpdateStateEn) != EventRequestStatusEn_RequestSent)
        {
            continue;
        }

        statusUpdate = GET_NAME(events[i], A_Event_UpdateStsName);

        if (statusUpdate[0] == '\0')
        {
            continue;
        }

        TraceMessage((char *)__FILE__, __LINE__, "Updating op status : %s for event %" szFormatId, statusUpdate,  /* DLA - PMSTA08801 - 100616 */
                     GET_ID(events[i], A_Event_Id));

        /* Fill operation business key */
        if (SUBD_GetOpBusinessKey(events[i], buffSql, 512) != SUBD_SUCCEED)
        {
            eventCreatDate = GET_DATETIME(events[i], A_Event_CreationDate);
            TIME_Get(eventCreatDate.time, &hour, &minute, &second);
            DATE_Get(eventCreatDate.date, &year, &month, &day);

            sprintf(txtBuf,
                    "Error getting business key for event. "
                    "Id (%" szFormatId"), hostname (%s), " /* DLA - PMSTA08801 - 100616 */
                    "user (%s), entity (%s), creation date (%2d/%2d/%04d %2d:%2d:%2d)",
                    GET_ID(events[i], A_Event_Id),
                    GET_SYSNAME(eventStatus[i], A_Event_Hostname),
                    GET_SYSNAME(events[i], A_Event_User),	/* DLA - PMSTA09887 - 101115 */
                    entityName,
                    month, day, year, hour, minute, second);
            MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, txtBuf);
            return SUBD_ERROR;
        }

        dbRetCode = DBA_SqlExec(buffSql, *connHelper.getConnection());

        if (dbRetCode != RET_SUCCEED)
        {
            sprintf(txtBuf, "Failed executing request (%s) on connection (%d)", buffSql, connHelper.getConnection()->getId());
            MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, txtBuf);
            return SUBD_ERROR;
        }

        opsToUpdate++;
    }

    /* Execute the procedure only if at least one operation status
       update needed.
       */

    if (opsToUpdate == 0)
    {
        return SUBD_SUCCEED;
    }

    /* fill the input structure */
    if ((extOpSt = mp.allocDynst(FILEINFO, ExtOp)) == NULLDYNST)
    {
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
        return SUBD_ERROR;
    }

    SET_NUMBER(extOpSt, ExtOp_EvtNbr, opsToUpdate);
    SET_ENUM(extOpSt, ExtOp_FusRuleEn, accountingStatus);
    SET_ENUM(extOpSt, ExtOp_DbStatusEn, 1);
    SET_ENUM(extOpSt, ExtOp_LockNatEn, origine);

    dbRetCode = DBA_Update2(ExtOrder,
                            DBA_ROLE_UPDSTATUS_NOSUBSCRIPTION,
                            ExtOp,
                            extOpSt,
                            connHelper);

    if (dbRetCode != RET_SUCCEED)
    {
        connHelper.sendAllMsg();
        return SUBD_ERROR;
    }

    return SUBD_SUCCEED;
}


/************************************************************************
**
**  Function    :   SUBD_SendAllEventsToMercator()
**
**  Description :   send many events to Mercator
**
**  Arguments   :   DBA_DYNFLD_STP   - the list of events
**             int             - the event number
**
*************************************************************************/
RET_CODE SUBD_SendAllEventsToMercator(std::vector<DBA_DYNFLD_STP> & eventList, std::string map_path)
{
    char strBuf[512];
    char headerBuff[4096];
    char *mapName, *mapStorage = NULL;
    char *dataBuff = NULL;
    char *finalBuff = NULL;
    char *entityName = NULL, *data;
    size_t len, dataSize;
    int  mapReturn;
    ID_T formatId;    /* DLA - PMSTA08801 - 100519 */
	FMTNAT_ENUM formatNatE = FmtNat_NO_VALUE;		/*PMSTA-46561 - 13102021 - sriharshabv*/

    if (eventList.empty())
    {
        sprintf(strBuf, "No event records supplied for treatment.");
        MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, strBuf);
        return SUBD_ERROR;
    }

	// events are grouped by format so formats are the same for all events
    CODE_T format;

    bool bExistEntityField = false;
    bool bExistFormatField = false;

    char
        *tempData = NULL, *tempName = NULL, *tempFtypeName = NULL,
            *tempNewValue = NULL, *tempOldValue = NULL, *tempFormat = NULL, *remTempData = NULL; /* PMSTA-66218 - JBC - 20250221 */

    data = GET_TEXT(eventList[0], A_Event_Data);  // using first event

    if ((tempData = (char *)CALLOC(strlen(data) + 2, sizeof(char))) == NULL)
    {
        MSG_SendMesg(
            RET_MEM_ERR_ALLOC, 0, FILEINFO);

        return SUBD_ERROR;
    }

    strcpy(tempData, data);
    tempName = NULL;

    // is there field from format
    if (get_next_field(&tempData, &tempName, &tempNewValue, &tempOldValue, 0, &tempFormat, &tempFtypeName, &remTempData) == TRUE) /* PMSTA39500 - 18092020 - HLA */
    {
        bExistFormatField = true;
        strcpy(format, tempFormat);
    }
    else
        *format = 0;

    strcpy(tempData, data);
    tempName = NULL;
    remTempData = NULL;

    static int activated = -1;
    static Lock lock;
    static bool sendTraceIdtoITX = false;

    {
        LockGuard guard(lock);

        if (activated < 0)
        {
            char *p = SYS_GetEnv("AAA_SEND_EXTRA_FIELD_TO_ITX");

            if (p != NULL)
                activated = atoi(p);
            else
                activated = 0;

            if (activated < 0)
                activated = -activated;

            sendTraceIdtoITX = SYS_GetEnvBoolOrDefValue("AAA_SEND_TRACEID_TO_ITX", false);

        }
    }

    // is there field not from format
    while (get_next_field(&tempData, &tempName, &tempNewValue, &tempOldValue, 0, NULL, NULL, &remTempData)) /* PMSTA39500 - 18092020 - HLA */
    {
        if (*tempName == ':' && !activated)
            continue;

        bExistEntityField = true;
        break;
    }

    FREE(tempData);

    for (size_t i = 0; i < eventList.size(); i++)
    {
        mapName = GET_NOTE(eventList[i], A_Event_MapStorage);
        mapStorage = ResolveMap(mapName, map_path);
        if (!mapStorage)
        {
            sprintf(strBuf, "Memory error or Unable to resolve Environment variable in map path.");
            MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, strBuf);
            return SUBD_ERROR;
        }

        entityName = GET_SYSNAME(eventList[i], A_Event_EntSqlName);
        data = GET_TEXT(eventList[i], A_Event_Data);
        formatId = GET_ID(eventList[i], A_Event_FormatId);
		
		if (formatId > 0 && (SUBD_GetFormatNature(formatId, &formatNatE) != RET_SUCCEED)) {		/*PMSTA-46561 - 13102021 - sriharshabv*/
			formatNatE = FmtNat_NO_VALUE;
		}

        SUBD_DumpHeader(eventList[i], format, formatNatE, headerBuff);

        if (finalBuff == NULL)
        {
            finalBuff = (char *)CALLOC(strlen(headerBuff) + 1, sizeof(char));
        }
        else
        {
            len = strlen(finalBuff);
            finalBuff = (char *)REALLOC(finalBuff, (len + strlen(headerBuff) + 1)*sizeof(char));
        }

        if (finalBuff == NULL)
        {
            MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
            return SUBD_ERROR;
        }

        strcat(finalBuff, headerBuff);

        if (bExistEntityField)
        {
            if (!ParseEntityData(entityName, data, &dataBuff, 0))
            {
                sprintf(strBuf,
                    "Parse failed for entity (%s).",
                    entityName);
                MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, strBuf);
                FREE(dataBuff);
                FREE(finalBuff);
                return SUBD_ERROR;
            }


            dataSize = strlen(dataBuff);
            len = strlen(finalBuff);

            finalBuff = (char *)REALLOC(finalBuff, (len + dataSize + 1) * sizeof(char));

            if (finalBuff == NULL)
            {
                MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
                return SUBD_ERROR;
            }

            strcat(finalBuff, dataBuff);
            FREE(dataBuff);
        }

        if (bExistFormatField)
        {
            if (!ParseFormatData(format, data, &dataBuff))
            {
                sprintf(strBuf,
                    "Parse failed for entity (%s).",
                    entityName);
                MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, strBuf);
                FREE(dataBuff);
                FREE(finalBuff);
                return SUBD_ERROR;
            }


            dataSize = strlen(dataBuff);
            len = strlen(finalBuff);

            finalBuff = (char *)REALLOC(finalBuff, (len + dataSize + 1) * sizeof(char));

            if (finalBuff == NULL)
            {
                MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
                return SUBD_ERROR;
            }

            strcat(finalBuff, dataBuff);
            FREE(dataBuff);
        }

    }

    mapReturn = Run_Map(finalBuff, mapStorage);
    FREE(finalBuff);
    if (!mapReturn)
    {
        for (size_t i = 0; i < eventList.size(); i++)
        {
            SUBD_LogSucceed(eventList[i]);
        }
        FREE(mapStorage);
        return SUBD_SUCCEED;
    }
    else
    {
        sprintf(strBuf,
                "Failed to run map (%s) for entity (%s).",
                mapStorage,
                entityName);
        MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, strBuf);

        for (size_t i = 0; i < eventList.size(); i++)
        {
            SUBD_LogRejected(eventList[i]);
        }
        FREE(mapStorage);
        return SUBD_ERROR;
    }
}

/************************************************************************
**
**  Function    :   SUBD_BuildDynStFromString()
**
**  Description :   Build a dynamic structure from a string containing
**             "attribute=value" pairs...
**
**  Argument    :   Pointer to the new structure
**             or NULLDYNST if failed
**
*************************************************************************/
DBA_DYNFLD_STP SUBD_BuildDynStFromString(DBA_DYNFLD_STP event, OBJECT_ENUM *pObject)
{
    DBA_DYNFLD_STP      tempStp;
    DICT_ENTITY_STP     dict;
    char                *entityName;
    OBJECT_ENUM         object;
    DICT_ENTITY_STP     dictEntityStp = NULL;
    DICT_ATTRIB_STP     dictAttributeWrk = (DICT_ATTRIB_STP)NULL;
    char                *dataStr;
	char                *tempData = NULL, *tempName = NULL, *tempNewValue = NULL, *tempOldValue = NULL, *tempFtypeName = NULL, *remTempData = NULL;
    FLAG_T              Found = FALSE;
    INT64_T             n;
    PTR                 valPtr = NULL;
    int                 i;
	int                 strInLen;

    dataStr = GET_TEXT(event, A_Event_Data);

    if ((entityName = GET_NAME(event, A_Event_EntSqlName)) == NULL)
    {
        return NULLDYNST;
    }

    if (DBA_SearchEntityBySqlName(entityName, &dict) != RET_SUCCEED)
    {
        return NULLDYNST;
    }

    if (DBA_GetObjectEnum(dict->entDictId, &object) == FALSE)
    {
        return NULLDYNST;
    }

    if ((tempStp = ALLOC_DYNST(GET_EDITGUIST(object))) == NULLDYNST)
    {
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
        return NULLDYNST;
    }

    dictEntityStp = DBA_GetDictEntitySt(object);

    /* Copy data in a temporary buffer for processing */
    tempData = (char *)CALLOC(strlen(dataStr) + 2, sizeof(char));
    if (!tempData)
    {
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
        return NULLDYNST;
    }
    strcpy(tempData, dataStr);

    /* get all field names and fields values, separated by ';' */
    /* DLA 010215 */
    while (get_next_field(&tempData, &tempName, &tempNewValue, &tempOldValue, 0, NULL, &tempFtypeName, &remTempData))
    {
        Found = FALSE;
        for (auto attribIt = dictEntityStp->attr.begin(); attribIt != dictEntityStp->attr.end() && !Found; attribIt++)
        {
            dictAttributeWrk = (*attribIt); /* PMSTA-26108 - LJE - 170918 */
            i = dictAttributeWrk->progN;

            if (dictAttributeWrk->isPhysicalAttribute() &&
                (DBA_FieldToExport(GET_EDITGUIST(object), i) == TRUE) &&
                (strcmp(dictAttributeWrk->sqlName, "ud_id") != 0) &&
                (strcmp(dictAttributeWrk->sqlName, tempName) == 0))
            {
                Found = TRUE;

                if (strcmp(tempNewValue, "NULL") == 0)
                {
                    SET_NULL_FLD(tempStp, i);
                    continue;
                }


                switch (dictAttributeWrk->dataTpProgN)
                {
                case CodeType:
                case NameType:
                case LongnameType:
                case InfoType:
                case NoteType:
                case PhoneType:
                case SysnameType:
                case TextType:
                case LongStringType:
                case ShortinfoType:             /* REF5660 */
                case UrlType:
                    SET_STRING(tempStp, i, tempNewValue);
					break;

				case UniTextType:
				case UniUrlType:
				case UniCodeType:
				case UniInfoType:
				case UniLongnameType:
				case UniNameType:
				case UniNoteType:
				case UniPhoneType:
				case UniSysnameType:
				case UniShortinfoType:
				case UniString1000Type:
				case UniString2000Type:
				case UniString3000Type:
				case UniString4000Type:
				case UniString7000Type:
				case UniString15000Type:
					/*PMSTA-37190-ARUN-19092019*/
					strInLen = SYS_StrLen(tempNewValue);
					if (strInLen > 0)
					{
						UChar *uStr = (UChar *)CALLOC(strInLen + 1, sizeof(UChar));
						if (nullptr != uStr)
						{
							if (ICU4AAA_ConvertToUChars(tempNewValue, -1, uStr, strInLen + 1, NULL,
								ICU4AAA_SQLServerUTF8 == TRUE ? TextConversion_Utf8 : TextConversion_Xml) == 0)
							{
								SET_USTRING(tempStp, i, uStr);
							}
							FREE(uStr);
						}
					}
                    break;

                case IdType:
                    sscanf(
                        tempNewValue, szFormatIdSScanf, &n);
                    SET_ID(tempStp, i, n);
                    break;

                case DictType:
                    sscanf(
                        tempNewValue, szFormatIdSScanf, &n);
                    SET_DICT(tempStp, i, n);
                    break;

                case DatetimeType:
                    valPtr = GET_FLDPTR_BY_DTP(dictAttributeWrk->dataTpProgN, tempStp, i);
                    CONV_StrToData(tempNewValue, dictAttributeWrk->dataTpProgN,
                        "DD/MM/YYYY HH:II:SS", (PTR)valPtr, TRUE);
                    SET_NOTNULLFLG_T(tempStp, i);
                    break;

                case EnumType:
                case FlagType:
                case DateType:
                case TinyintType:
                case SmallintType:
                case LongintType:
                case NumberType:
                case PercentType:
                default:
                    valPtr = GET_FLDPTR_BY_DTP(dictAttributeWrk->dataTpProgN, tempStp, i);
                    CONV_StrToData(tempNewValue, dictAttributeWrk->dataTpProgN,
                        GET_CONV_MASK(GET_DFLTCONVFMT(dictAttributeWrk->dataTpProgN)),
                        (PTR)valPtr, TRUE);     /* ROI - 010225 - REF5635 */
                    SET_NOTNULLFLG_T(tempStp, i);
                    break;
                }
            }
        }
    }
    FREE(tempData);
    *pObject = object;
    return tempStp;
}


/************************************************************************
**
**  Function    :   SUBD_BuildStrWithFormat()
**
**  Description :   Build a string
**
**  Argument    :   event, buffer
**
** Return codes:   TRUE, FALSE
**
*************************************************************************/
/*
int SUBD_BuildStrWithFormat(DBA_DYNFLD_STP event, char ** totalBuff)
{

    DBA_DYNFLD_STP          aDynSt = NULLDYNST;
    OBJECT_ENUM             object;
    ID_T                    formatId;
    DBA_DYNFLD_STP          resultBaseValPtr = (DBA_DYNFLD_STP)NULL;
    SUBD_RESULT_EVAL_TREE_STP   resultEvalTreePtr = (SUBD_RESULT_EVAL_TREE_STP)NULL;

    aDynSt = SUBD_BuildDynStFromString(event, &object);
    formatId = GET_ID(event, A_Event_FormatId);

    if (aDynSt == NULLDYNST)
    {
        return FALSE;
    }

    if ((resultEvalTreePtr = SUBD_EvalFmt(GET_ID(event, A_Event_FormatId), object)) == (SUBD_RESULT_EVAL_TREE_STP)NULL)
    {
        FREE_DYNST(aDynSt, GET_EDITGUIST(object));
        return FALSE;
    }

    if (SUBD_ExecFmt(resultEvalTreePtr, &resultBaseValPtr, GET_EDITGUIST(object), aDynSt) != RET_SUCCEED)
    {
        FREE_DYNST(aDynSt, GET_EDITGUIST(object));
        return FALSE;
    }

    SUBD_PrintFmtToString(resultEvalTreePtr, resultBaseValPtr, totalBuff);
    FREE_DYNST(aDynSt, GET_EDITGUIST(object));
    return TRUE;
}
*/


RET_CODE SUBD_GetFormatName(ID_T formatId, char *formatName)
{
    MemoryPool          mp;
    DBA_DYNFLD_STP      sFormat = NULLDYNST;
    DBA_DYNFLD_STP      inputSt = NULLDYNST;

    if ((sFormat = mp.allocDynst(FILEINFO, S_Fmt)) == NULLDYNST)
    {
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
        return SUBD_ERROR;
    }

    if ((inputSt = mp.allocDynst(FILEINFO, Adm_Arg)) == NULLDYNST)
    {
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
        return SUBD_ERROR;
    }

    SET_ID(inputSt, Adm_Arg_Id, formatId);

    if (DBA_Get2(Fmt,
                 UNUSED,
                 Adm_Arg,
                 inputSt,
                 S_Fmt,
                 &sFormat,
                 UNUSED,
                 UNUSED) != RET_SUCCEED)
    {
        MSG_SendMesg(RET_DBA_ERR_NODATA, 0, FILEINFO);
        return SUBD_ERROR;
    }

    strcpy(formatName, GET_CODE(sFormat, S_Fmt_Cd));
    return SUBD_SUCCEED;
}

RET_CODE SUBD_GetFormatNature(ID_T formatId, FMTNAT_ENUM *natureE)
{
	MemoryPool          mp;
	DBA_DYNFLD_STP      sFormat = NULLDYNST;
	DBA_DYNFLD_STP      inputSt = NULLDYNST;
	//DBA_ERRMSG_INFOS_ST msgStructPtr;

	if ((sFormat = mp.allocDynst(FILEINFO, S_Fmt)) == NULLDYNST)
	{
		MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
		return SUBD_ERROR;
	}

	if ((inputSt = mp.allocDynst(FILEINFO, Adm_Arg)) == NULLDYNST)
	{
		MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
		return SUBD_ERROR;
	}

	SET_ID(inputSt, Adm_Arg_Id, formatId);

	if (DBA_Get2(Fmt,
		UNUSED,
		Adm_Arg,
		inputSt,
		S_Fmt,
		&sFormat,
		UNUSED,
		UNUSED,
		UNUSED) != RET_SUCCEED)
	{
		MSG_SendMesg(RET_DBA_ERR_NODATA, 0, FILEINFO);
		return SUBD_ERROR;
	}

	*natureE = (FMTNAT_ENUM)GET_ENUM(sFormat, S_Fmt_NatEn);

	return SUBD_SUCCEED;
}

RET_CODE SubscriptionDaemon::SUBD_CustomEventSelect(DbiConnectionHelper & connHelper, std::vector<DBA_DYNFLD_STP> & outEvent, EVENT_STATUS_ENUM eventStatusEn, ID_T minEventId, DBA_DYNFLD_STP lockedEventStp)
{
    std::stringstream    query;
    MemoryPool           mp;

	/* HLA - PMSTA32587 - 24082016 Converting to dynamic query framework */
    /* PMSTA-34827 - JBC - 190218 add block size, handle locking */
        query   << "#SELECT event all ev " << std::endl
	            << "#FROM " << std::endl
	            << "#WHERE " << std::endl
	            << "  status_e = " << eventStatusEn << std::endl
                << "  map_storage_c is not null " << std::endl;

    if(lockedEventStp == nullptr && minEventId != ZERO_ID)
    {
        query  << " id > " << minEventId << std::endl;
    }
    /* if we have a locked map, use it, else only get unlocked */
    if(lockedEventStp != nullptr)
    {
        /* PMSTA-50340 - FME - 2022-11-11 Escape the $ as otherwise DDLGen will expand it */

        std::string event_map_string = GET_NOTE(lockedEventStp, A_Event_MapStorage);
        SYS_StringFindAndReplaceAll(event_map_string,"$","\\$");
        
        query << "  map_storage_c = '" << event_map_string << "'" << std::endl;
        if(IS_NULLFLD(lockedEventStp,A_Event_BusEntityCd))
        {
            query   << "  business_entity_cd is null" << std::endl;
        }
        else
        {
         query   << "  business_entity_cd = '" << GET_CODE(lockedEventStp,A_Event_BusEntityCd) << "'" << std::endl;
        }
        /* PMSTA-48941 - JBC - 220505 */
        query   << "  event_status_f = " << (GET_FLAG(lockedEventStp,A_Event_EventStatusFlg) == TRUE ? 1 : 0) << std::endl;
    }
    else
    {
        query   << "  not exists (select 1 from  lock_event_map_vw lem" << std::endl
			    << "         	 where ev.map_storage_c = lem.map_storage_c " << std::endl
                << "         	 and #ISNULL(ev.business_entity_cd,ev.map_storage_c) = #ISNULL(lem.business_entity_cd,lem.map_storage_c) " << std::endl
			    << "             and lem.lock_f = 1 ) " << std::endl;
    }

    if(GEN_IsMultiEntity() && connHelper.getConnectedBusinessEntityId() != EV_MasterBusinessEntityId)   /* PMSTA-66218 - JBC - 20250221 */
    {   // explicit filter on owner_business_entity_id for efficiency as event_vw always adds master
	    query   << "  owner_business_entity_id = " << connHelper.getConnectedBusinessEntityId() << std::endl;
    }

    
    size_t orderPos = 0;
    if (m_daemonNumber && m_whereClause.empty() == false)
	{        
        // PMSTA-52980  everything before the order by goes in the where clause
        if((orderPos = DdlGen::find_word(m_whereClause,"order",0,std::string::npos," ",true)) != std::string::npos)
        {
            query << m_whereClause.substr(0,orderPos) << std::endl;
        }
        else
        {
            query << m_whereClause << std::endl;
        }
    }

    query   << "#END " << std::endl;

    DBI_INT status = 0;
	/* PMSTA-47289 - BSV - 180522 */
    if (connHelper.isValidAndInit() == false )
    {
        MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "Couldn't get Valid Connection dbConnection is NULL : ");
        return DBA_CONN_NOT_FOUND;
    }

    /* PMSTA-66218 - JBC - 20250221 : get all failed as they are processed 1-by-1 */
    int maxRows = m_blockSize > 0 && eventStatusEn != Event_Status_Failed ? m_blockSize : 0;   
    if(isMultiThreadOverride() && isPrimeThread() && eventStatusEn == Event_Status_Untreated)   /* PMSTA-66218 - JBC - 20250221 */
    {   // get events for all threads
	    maxRows *= getTotalThreadCount();
    }
    DBA_SetConnMaxRows(*connHelper.getConnection(),maxRows);
    connHelper.getConnection()->setReadOnly(true);

    /* PMSTA-52980 - JBC - 230515 */
    std::string prepQuery(query.str());
    DBA_DynSqlStrPrep(prepQuery, connHelper.getConnection()->m_connectToRDBMS);
    query.str("");
    query << prepQuery;

    // PMSTA-52980  add the order by 
	if (m_daemonNumber && m_whereClause.empty() == false && orderPos != std::string::npos)
	{
		query << m_whereClause.substr(orderPos) << std::endl;
	}
    else if(isMultiThreadOverride() == false)   /* PMSTA-66218 - JBC - 20250221 */
    {
        query << " order by creation_d " << std::endl;
    }	

    if (connHelper.getConnection()->sendCommand(query.str()) != RET_SUCCEED)
    {
        MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, SYS_Stringer("Unable to send sql command: ",query.str()).c_str());
        return RET_DBA_ERR_READ_DATA;
    }

    /* Allocate memory for the bind structure */
    DBA_DYNFLD_STP  bindSt = mp.allocDynst(FILEINFO, A_Event);
    if (bindSt == nullptr)
    {
        connHelper.getConnection()->processAllResults(&status);
        return(RET_MEM_ERR_ALLOC);
    }

    /* Bind result columns with an application bind structure */
    if (connHelper.getConnection()->bindRecvDynSt(A_Event, bindSt) != RET_SUCCEED)
    {
        connHelper.getConnection()->cancelDbRequest(COMMAND_LEVEL, CANCEL_ALL);
        MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "Unable to bind columns");
        return(RET_DBA_ERR_SYBBIND);
    }

    /* Retrieve all rows in the result set */
    int outEventNbr;
    DBA_DYNFLD_STP *outEventTab;

    if (connHelper.getConnection()->readObjectData(A_Event, bindSt, &outEventNbr, &outEventTab) != RET_SUCCEED)
    {
        connHelper.getConnection()->processAllResults(&status);
        MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "Unable to read data");
        return(RET_DBA_ERR_DBPROBLEM);
    }

    for(int i= 0; i < outEventNbr;i++)
    {
        outEvent.push_back(outEventTab[i]);
    }

    connHelper.getConnection()->processAllResults(&status);
    DBA_SetConnMaxRows(*connHelper.getConnection(),0);
    connHelper.getConnection()->setReadOnly(false);

    return RET_SUCCEED;
}

/*
*  Last modif. : PMSTA-16293 - 210513 - PMO : Update source code - fix build
*/
int SubscriptionDaemon::TraceMessage(char *file, int line, ...)
{
    va_list ap;               /* PMSTA-16293 - 210513 - PMO */
    char *format;
    time_t currTime;
    struct tm localTime;
    char timeStamp[128];
    FILE *fp;
    static int firstTime = 1;
    static char logFileName[1024];
    static int traceOn = 0;
    static Lock logLock;
    if(firstTime || traceOn == 1)
    {
		currTime = time(0L);

#ifdef WIN32
    localTime = *localtime(&currTime);
#else
    localtime_r(&currTime, &localTime);
#endif
    }

    if (firstTime)
    {
        char *aaaMsg;

        firstTime = 0;
        if (getenv("AAASUBDTRACE") != NULL)
        {
            traceOn = 1;
            // avoid overwrite of file	/* PMSTA-66218 - JBC - 20250221 */
            char fileTimestamp[1024]; 
             sprintf(fileTimestamp, "%04d%02d%02d_%02d%02d%02d", localTime.tm_year + 1900,
			        localTime.tm_mon + 1, localTime.tm_mday,
			        localTime.tm_hour, localTime.tm_min, localTime.tm_sec);
            auto baseFilename = SYS_Stringer("subd",m_daemonNumber,"_",fileTimestamp,".trc.log");
            sprintf(logFileName, baseFilename.c_str());
            aaaMsg = getenv("AAAMSG");

#ifdef UNIX
            if (aaaMsg != NULL && strlen(aaaMsg) < 1014)
                sprintf(logFileName, "%s/%s", aaaMsg, baseFilename.c_str());
            else
                sprintf(logFileName, "/tmp/%s", baseFilename.c_str());
#else
            if(aaaMsg != NULL && strlen(aaaMsg) < 1014)
                sprintf(logFileName, "%s\\%s", aaaMsg,  baseFilename.c_str());
            else
                sprintf(logFileName, "C:\\temp\\%s",  baseFilename.c_str());
#endif

            remove(logFileName);

            fp = fopen(logFileName, "a+");
            if (fp == NULL)
                return 1;

            fclose(fp);
        }
    }

    if (traceOn == 0)
        return 0;
        
    
    LockGuard _(logLock);	/* PMSTA-66218 - JBC - 20250221 */
    
    sprintf(timeStamp, "%04d/%02d/%02d %02d:%02d:%02d ", localTime.tm_year + 1900,
        localTime.tm_mon + 1, localTime.tm_mday,
        localTime.tm_hour, localTime.tm_min, localTime.tm_sec);

    va_start(ap, line);

    fp = fopen(logFileName, "a+");
    if (fp == NULL)
        return 1;
    fprintf(fp, "%s : T%d : ", timeStamp, m_threadRank);
    format = va_arg(ap, char *);
    vfprintf(fp, format, ap);
    fprintf(fp, "\n");

    fclose(fp);

    va_end(ap);
    return 0;
}

/************************************************************************
**
**  Function    :   SUBD_ChangeAllEventsStatus()
**
**  Description :   Must manage transaction outside function if desired
**
**  Argument    :   
**
** Return codes:
**
*************************************************************************/
RET_CODE SubscriptionDaemon::SUBD_ChangeAllEventsStatus(DbiConnectionHelper & connHelper, std::vector<DBA_DYNFLD_STP> & events, int status, std::vector<DBA_DYNFLD_STP> & eventStatus, bool esonly)
{  
    if(events.size() != eventStatus.size())
    {
        TraceMessage((char *)__FILE__, __LINE__, "Event and Event Status List not the same size!");
        return SUBD_ERROR;
    }

    MemoryPool           mp;
    RequestHelper        requestHelper(connHelper);
    RET_CODE             ret = RET_SUCCEED;
    char                 txtBuf[1024];
    DATETIME_T           eventCreatDate;
    HOUR_T               hour;
    MINUTE_T             minute;
    SECOND_T             second;
    YEAR_T               year;
    MONTH_T              month;
    DAY_T                day;

    /* PMSTA-46829  - Removed initialization as the variable i is already initialized above. It was causing performance issue. SSN 08112021 */
    for (size_t i = 0; i < events.size();i++)
    {
        int oldEventStatus = static_cast<int>(GET_ENUM(events[i], A_Event_StatusEn));

        if (esonly == false)
        {
            DBA_DYNFLD_STP       updEventArg = mp.allocDynst(FILEINFO, Get_Arg);
            SET_ID(updEventArg, Get_Arg_Id, GET_ID(events[i], A_Event_Id));
            SET_ENUM(updEventArg, Get_Arg_Enum1, status);


            TraceMessage((char *)__FILE__, __LINE__, "Changing status from %d to %d for event %" szFormatId, /* DLA - PMSTA08801 - 100616 */
                oldEventStatus, status,  GET_ID(events[i], A_Event_Id));

            if(requestHelper.addProcedureCallForBatchMulti(Update,Event,UNUSED,updEventArg,10) == false)
            {
                MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "Unable to call update Event status procedure.");
                return SUBD_ERROR;
            }
        }

        if (GET_FLAG(events[i], A_Event_EventStatusFlg) == TRUE)
        {            
            DBA_DYNFLD_STP       updEventStatusArg = mp.allocDynst(FILEINFO, Get_Arg);
            SET_ID(updEventStatusArg,Get_Arg_Id,GET_ID(eventStatus[i],A_EventStatus_Id));

            switch (status)
            {
                case Event_Status_Untreated:
                    SET_ENUM(eventStatus[i],
                        A_EventStatus_RequestStatusEn, EventRequestStatusEn_Untreated);
                    SET_ENUM(updEventStatusArg,Get_Arg_Enum1,EventRequestStatusEn_Untreated);
                    break;

                case Event_Status_Running:
                    SET_ENUM(eventStatus[i],
                        A_EventStatus_RequestStatusEn, EventRequestStatusEn_InProgress);
                    SET_ENUM(updEventStatusArg,Get_Arg_Enum1,EventRequestStatusEn_InProgress);
                    break;

                case Event_Status_Succeed:
                    SET_ENUM(eventStatus[i],
                        A_EventStatus_RequestStatusEn, EventRequestStatusEn_RequestSent);
                    SET_ENUM(updEventStatusArg,Get_Arg_Enum1,EventRequestStatusEn_RequestSent);
                    break;

                case Event_Status_Failed:
                    SET_ENUM(eventStatus[i],
                        A_EventStatus_RequestStatusEn, EventRequestStatusEn_RequestError);
                    SET_ENUM(updEventStatusArg,Get_Arg_Enum1,EventRequestStatusEn_RequestError);
                    break;

                default:
                    break;
            }

             TraceMessage((char *)__FILE__, __LINE__, "Changing request status to %d for event %" szFormatId, /* DLA - PMSTA08801 - 100616 */
                GET_ENUM(eventStatus[i],A_EventStatus_RequestStatusEn),GET_ID(events[i], A_Event_Id));
            
            if(requestHelper.addProcedureCallForBatchMulti(Update,EventStatus,UNUSED,updEventStatusArg,11) == false)
            {            
                MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "Unable to call update Event status procedure.");
                return SUBD_ERROR;
            }
        }
    }

    if (connHelper.isValidAndInit() == false)
    {
        MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "Unable to get a connection");
        return SUBD_ERROR;
    }

    requestHelper.executeBatchMulti();

    if((ret = requestHelper.getLastRetCode()) != RET_SUCCEED)
    {
        eventCreatDate = GET_DATETIME(events[0], A_Event_CreationDate);
        TIME_Get(eventCreatDate.time, &hour, &minute, &second);
        DATE_Get(eventCreatDate.date, &year, &month, &day);

        sprintf(txtBuf,
                "Error attempting to update event status to %d or request status. First event in batch is"
                " Id (%" szFormatId"), hostname (%s), " /* DLA - PMSTA08801 - 100616 */
                "user (%s), entity (%s), creation date (%2d/%2d/%04d %2d:%2d:%2d)",
                status,
                GET_ID(events[0], A_Event_Id),
                GET_SYSNAME(events[0], A_Event_Hostname),
                GET_SYSNAME(events[0], A_Event_User),	/* DLA - PMSTA09887 - 101115 */
                GET_SYSNAME(events[0], A_Event_EntSqlName),
                month, day, year, hour, minute, second);

        MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, txtBuf);
        return SUBD_ERROR;
    }
    return SUBD_SUCCEED;
}

/************************************************************************
**
**  Function    :   SUBD_CheckEventUpdated
**
**  Description :   in the case of a dirty read , checks if the event was really updated
**
**  Argument    :   eventId, status
**  Returns     :   RET_DBA_INFO_NODATA   - no record found
**                  RET_DBA_INFO_EXIST    - one record found
**                  RET_DBA_ERR_READ_DATA - more than one record found
**                  RET_MEM_ERR_ALLOC     - other error occurred
**
** Modif        :   PMSTA-41320 - DDV - 200806 - NUODB: subd fails to process events. 
**                                Rewrite the fucntion to use stored procedure instead of hand make query.
*************************************************************************/
RET_CODE SubscriptionDaemon::SUBD_CheckEventUpdated(ID_T eventId, EVENT_STATUS_ENUM status)
{
    MemoryPool          mp;
    DBA_DYNFLD_STP      getArg = mp.allocDynst(FILEINFO, Get_Arg);
    DBA_DYNFLD_STP      ioId = mp.allocDynst(FILEINFO, Io_Id);
    char                msgText[1024];
    DbiConnectionHelper connHelper(AAATransactionEnum::NotTransactionnal, SqlServer, ROLE_ADMIN);

    /* Retrieve current connection. */
    if (connHelper.isValidAndInit() == false)
    {
        MSG_SendMesg(RET_DBA_ERR_NOFREESYNCCONN, 0, FILEINFO);
        return(DBA_CONN_NOT_FOUND);
    }

    SET_ID(getArg, Get_Arg_Id, eventId);
    SET_ENUM(getArg, Get_Arg_Enum1, status);

    if (connHelper.dbaGet(Event, UNUSED, getArg, &ioId) != RET_SUCCEED)
    {
        /* PMSTA-47289 - BSV - 180522 */
        MSG_LogMesg(RET_DBA_ERR_READ_DATA, 0, FILEINFO);/*Avoiding the Crash changed the index*/
        return RET_DBA_ERR_READ_DATA;
    }

    if (GET_ID(ioId, Io_Id_Id) == 0)
    {
        return RET_DBA_INFO_NODATA;
    }

    if (GET_ID(ioId, Io_Id_Id) == 1)
    {
        return RET_DBA_INFO_EXIST;
    }

    sprintf(msgText, "More than one record found for event : %" szFormatId, eventId);
    MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, msgText);
    return RET_DBA_ERR_READ_DATA;
}

/************************************************************************
**
**  Function    :   SUBD_GetEventCount
**
**  Description :   Select number of untreated events from event table in dirty read mode
**
**  Argument    :   eventCount
**  Returns     :   RET_DBA_INFO_NODATA   - no record found
**                  RET_DBA_INFO_EXIST    - one record found
**                  RET_DBA_ERR_READ_DATA - more than one record found
**                  RET_MEM_ERR_ALLOC     - other error ucured
**
** Modif        :   PMSTA-41320 - DDV - 200806 - NUODB: subd fails to process events.
**                                Rewrite the fucntion to use stored procedure instead of hand make query.
*************************************************************************/
RET_CODE SubscriptionDaemon::SUBD_GetEventCount(DbiConnectionHelper & connHelper, int *eventCount, EVENT_STATUS_ENUM status)
{
    if(isMultiThreadOverride() && isPrimeThread() == false && status == Event_Status_Untreated)	/* PMSTA-66218 - JBC - 20250221 */
    {   // worker threads exit and check queue
	    *eventCount = 1;
        return SUBD_SUCCEED;
    }

    MemoryPool          mp;
    DBA_DYNFLD_STP      getArg = mp.allocDynst(FILEINFO, Get_Arg);
    DBA_DYNFLD_STP      ioId = mp.allocDynst(FILEINFO, Io_Id);
    RET_CODE            ret;

    /* Retrieve current connection. */
    if (connHelper.isValidAndInit() == false)
    {
        MSG_SendMesg(RET_DBA_ERR_NOFREESYNCCONN, 0, FILEINFO);
        return(DBA_CONN_NOT_FOUND);
    }

    SET_ENUM(getArg, Get_Arg_Enum1, status);

    if ((ret = connHelper.dbaGet(Event, UNUSED, getArg, &ioId)) != RET_SUCCEED)
    {
        /* PMSTA-47289 - BSV - 180522 */
        MSG_LogMesg(RET_DBA_ERR_READ_DATA, 0, FILEINFO);//Avoiding the Subscription crash
        return(ret);
    }

    if (GET_ID(ioId, Io_Id_Id) > INT_MAX)
    {
        *eventCount = INT_MAX;
    }
    else
    {
        *eventCount = (int) GET_ID(ioId, Io_Id_Id);
    }
    
    return SUBD_SUCCEED;
}


/************************************************************************
**
**  Function    :   SUBD_AddSubDFreq
**
**  Description :   keeps map of bus ent cd and wait frequencies
**
**  Argument    :   busEntityCd, daemonFreq
**  Returns     :  
**
** Modif        :  
*************************************************************************/
void SubscriptionDaemon::SUBD_AddSubDFreq(const std::string busEntityCd, int daemonFreqSeconds)
{
    if(m_freqByBusEntCd.count(busEntityCd) == 0)
    {
        FusionTimer * timer = new FusionTimer("daemonFreqTimer");
        timer->setTimeOutInSeconds(daemonFreqSeconds);
        m_freqByBusEntCd[busEntityCd] = timer;
    }
}


/************************************************************************
**
**  Function    :   SUBD_GetFreqMap
**
**  Description :   map for main loop
**
**  Argument    : 
**  Returns     :  
**
** Modif        :  
*************************************************************************/
std::map<std::string,FusionTimer *> & SubscriptionDaemon::SUBD_GetFreqMap()
{
   return m_freqByBusEntCd;
}

void SubscriptionDaemon::SUBD_SetEventBusEntIdx(FIELD_IDX_T index)
{
    m_eventOwnerBusEntIdx = index;
}

FIELD_IDX_T & SubscriptionDaemon::SUBD_GetEventBusEntIdx()
{
    return m_eventOwnerBusEntIdx;
}

/************************************************************************
**
**  Function    :   SUBD_IsBusinessEntityValid
**
**  Description :   in case where command line has specified a BE, this
**                   this function confirms what BEs are valid.
**  Argument    : 
**  Returns     :  
**
** Modif        :  
*************************************************************************/
bool SubscriptionDaemon::SUBD_IsBusEntityValid(std::string & busEntityCd)
{
    if(m_singleBusEntityCd.empty() == false)
    {
        return m_singleBusEntityCd == busEntityCd;
    }
    return true;
}

/*
 * Last modif. : PMSTA-16293 - 210513 - PMO : Update source code - fix build
 */
RET_CODE SUBD_DumpHeader(DBA_DYNFLD_STP event, const char* format, FMTNAT_ENUM formatNatE , char *strParam)
{
    /* Dump header fields to string strParam separated by RS_SEP and FS_SEP */

    int            action;
    int            module;
    int            status;
    int            nature;
    ID_T           fctResultId;		/* DLA - PMSTA08801 - 100519 */
    DATETIME_T     creationDate;
    DATETIME_T     executionDate;
    char *         mapName = NULL;
    char *         entityName = NULL;
    char *         functionName = NULL;
    char *         hostName = NULL;
    char *         user = NULL;
    char *         updateStatus = NULL;

    /* new fields for R4.20 */
    int            operationStatus;
    double         priority;
    char *         destinationCode = NULL;
    char *         operationCode = NULL;
    char *         subscriptionCode = NULL;
    INT64_T        opTimeStamp;

    /* new fields for 7.1.0 */
    CODE_T         busEntityCd;
    int            requestStatusEn;
    int            eventStatusFlg;
    CODE_T         groupingCd;
    ID_T           eventId;

    DATE_FORMAT_ST dateFormat;
    HOUR_T         hour;
    MINUTE_T       minute;
    SECOND_T       second;
    char           creationDateStr[128];
    char           executionDateStr[128];
    char           opTimeStampStr[20];
    char           tmpStr[1024];

    action = (int)GET_ENUM(event, A_Event_ActionEn);
    creationDate = GET_DATETIME(event, A_Event_CreationDate);
    mapName = GET_NOTE(event, A_Event_MapStorage);
    entityName = GET_SYSNAME(event, A_Event_EntSqlName);
    functionName = GET_SYSNAME(event, A_Event_FctSqlName);
    hostName = GET_SYSNAME(event, A_Event_Hostname);
    module = (int)GET_ENUM(event, A_Event_ModuleEn);
    user = GET_SYSNAME(event, A_Event_User);	/* DLA - PMSTA09887 - 101115 */
    status = GET_ENUM(event, A_Event_StatusEn);
    nature = GET_ENUM(event, A_Event_NatureEn);
    executionDate = GET_DATETIME(event, A_Event_ExecutionDate);
    updateStatus = GET_NAME(event, A_Event_UpdateStsName);
    fctResultId = GET_ID(event, A_Event_FunctionResultId);

    /* new fields for R4.20 */
    operationStatus = (int)GET_ENUM(event, A_Event_OperationStatusEn);
    priority = GET_NUMBER(event, A_Event_Priority);
    destinationCode = GET_CODE(event, A_Event_DestinationCd);
    operationCode = GET_CODE(event, A_Event_OperationCd);
    subscriptionCode = GET_CODE(event, A_Event_SubscriptionCd);

    /* new fields for R4.30.3 */
    opTimeStamp = GET_TIMESTAMP(event, A_Event_OpTimeStamp);

    /* new fields for 7.1.0 */ /* PMSTA-17593 - DDV - 100211 - Replace A_Event_BusEntityId by A_Event_BusEntityCd */
    if (IS_NULLFLD(event, A_Event_BusEntityCd) == TRUE)
        strcpy(busEntityCd, "NULL");
    else
        strcpy(busEntityCd, GET_CODE(event, A_Event_BusEntityCd));

    /* new fields for 7.1.0 */ /* PMSTA-17853 - DDV - 140326 - Add grouping code value */
    if (IS_NULLFLD(event, A_Event_GroupingCode) == TRUE)
        strcpy(groupingCd, "NULL");
    else
        strcpy(groupingCd, GET_CODE(event, A_Event_GroupingCode));

    requestStatusEn = (int)GET_ENUM(event, A_Event_RequestStatusEn);
    eventStatusFlg = (int)GET_FLAG(event, A_Event_EventStatusFlg);
    eventId = GET_ID(event, A_Event_Id);

    dateFormat.ordre = Dmy;
    strcpy(dateFormat.yearSep, "/");
    strcpy(dateFormat.monthSep, "/");
    strcpy(dateFormat.daySep, "/");
    dateFormat.yearFormat = 1;
    dateFormat.monthFormat = 0;

    if (creationDate.date == 0 && creationDate.time == 0)
        strcpy(creationDateStr, "NULL");
    else
    {
        DATE_FormatToStr(tmpStr, creationDate.date, &dateFormat);
        TIME_Get(creationDate.time, &hour, &minute, &second);
        sprintf(creationDateStr, "%s %d:%d:%d", tmpStr, hour, minute, second);   /* PMSTA-16293 - 210513 - PMO */
    }

    if (executionDate.date == 0 && executionDate.time == 0)
        strcpy(executionDateStr, "NULL");
    else
    {
        DATE_FormatToStr(tmpStr, executionDate.date, &dateFormat);
        TIME_Get(executionDate.time, &hour, &minute, &second);
        sprintf(executionDateStr, "%s %d:%d:%d", tmpStr, hour, minute, second);  /* PMSTA-16293 - 210513 - PMO */
    }


    /* ouput following fields

       action_e              *
       creation_d            *
       destination_c         *
       entity_sqlname_c      *
       execution_d           *
       format_id             *
       function_result_id    *
       function_sqlname_c    *
       grouping_code         *
       hostname_c            *
       id                    *
       map_storage_c         *
       module_e              *
       nature_e              *
       op_timestamp          *
       operation_c           *
       operation_status_e    *
       priority_n            *
       status_e              *
       subscription_c        *
       update_status_c       *
       user_c                *
       business_entity_id    *
       request_status_e      *
       event_status_f        *
       */

    strParam[0] = '\0';

    sprintf(tmpStr, "%d%c", action, RS_SEP);
    strcat(strParam, tmpStr);

    sprintf(tmpStr, "%s%c", busEntityCd, RS_SEP); /* PMSTA-17593 - DDV - 100211 - Replace A_Event_BusEntityId by A_Event_BusEntityCd */
    strcat(strParam, tmpStr);

    sprintf(tmpStr, "%s%c", creationDateStr, RS_SEP);
    strcat(strParam, tmpStr);

    sprintf(tmpStr, "%s%c", destinationCode != NULL ? destinationCode : "NULL", RS_SEP);
    strcat(strParam, tmpStr);

    sprintf(tmpStr, "%s%c", entityName, RS_SEP);
    strcat(strParam, tmpStr);

    sprintf(tmpStr, "%d%c", eventStatusFlg, RS_SEP);
    strcat(strParam, tmpStr);

    sprintf(tmpStr, "%s%c", executionDateStr, RS_SEP);
    strcat(strParam, tmpStr);

    sprintf(tmpStr, "%" szFormatId"%c", fctResultId, RS_SEP);
    strcat(strParam, tmpStr);

    sprintf(tmpStr, "%s%c", functionName != NULL ? functionName : "NULL", RS_SEP);
    strcat(strParam, tmpStr);

    sprintf(tmpStr, "%s%c", groupingCd, RS_SEP); /* PMSTA-17853 - DDV - 140326 - Get grouping code value */
    strcat(strParam, tmpStr);

    sprintf(tmpStr, "%s%c", hostName != NULL ? hostName : "NULL", RS_SEP);
    strcat(strParam, tmpStr);

    sprintf(tmpStr, "%" szFormatId"%c", eventId, RS_SEP); /* PMSTA-17871 - DDV - 140331 - Add id */
    strcat(strParam, tmpStr);

    sprintf(tmpStr, "%s%c", mapName != NULL ? mapName : "NULL", RS_SEP);
    strcat(strParam, tmpStr);

    sprintf(tmpStr, "%d%c", module, RS_SEP);
    strcat(strParam, tmpStr);

    sprintf(tmpStr, "%d%c", nature, RS_SEP);
    strcat(strParam, tmpStr);

    sprintf(opTimeStampStr, szFormatTimeStamp, opTimeStamp);
    sprintf(tmpStr, "%s%c", opTimeStampStr, RS_SEP);
    strcat(strParam, tmpStr);

    sprintf(tmpStr, "%s%c", operationCode != NULL ? operationCode : "NULL", RS_SEP);
    strcat(strParam, tmpStr);

    sprintf(tmpStr, "%d%c", operationStatus, RS_SEP);
    strcat(strParam, tmpStr);

    sprintf(tmpStr, "%lf%c", priority, RS_SEP);
    strcat(strParam, tmpStr);

    sprintf(tmpStr, "%d%c", requestStatusEn, RS_SEP);
    strcat(strParam, tmpStr);

    sprintf(tmpStr, "%d%c", status, RS_SEP);
    strcat(strParam, tmpStr);

    sprintf(tmpStr, "%s%c", subscriptionCode != NULL ? subscriptionCode : "NULL", RS_SEP);
    strcat(strParam, tmpStr);

    sprintf(tmpStr, "%s%c", updateStatus != NULL ? updateStatus : "NULL", RS_SEP);
    strcat(strParam, tmpStr);

    if (false) // sendTraceIdtoITX) // Need ITX Maps adaptation ! Done for A POC only
    {
        std::string traceIdExternalRepresentation = AAATelemetry::GetTracer(AAATracer::TraceName::Subscription).getActiveSpan().getTracePropagation();
        sprintf(tmpStr, "%s%c", traceIdExternalRepresentation.size() > 0 ? traceIdExternalRepresentation.c_str() : "NULL", RS_SEP);
    }

    /* PMSTA-61746 - Deepthi - 20241118 */
    if (*format == NULL)
    {
        formatNatE = FmtNat_Export;
    }

	if (formatNatE == FmtNat_Subscription || formatNatE == FmtNat_SubscriptionEnrichment
                || formatNatE == FmtNat_Export) {		/*PMSTA-46561 - 13102021 - sriharshabv*/ /* PMSTA-61571 - Deepthi - 20241108 */
		sprintf(tmpStr, "%s%c", user != NULL ? user : "NULL", RS_SEP);
		strcat(strParam, tmpStr);
		sprintf(tmpStr, "%s%c", *format ? format : "NULL", FS_SEP); // last one --> FS_SEP
		strcat(strParam, tmpStr);
	}
	else {
		sprintf(tmpStr, "%s%c", user != NULL ? user : "NULL", FS_SEP); // last one --> FS_SEP
		strcat(strParam, tmpStr);
	}

    return SUBD_SUCCEED;
}

/************************************************************************
**      END  subdlib.c
*************************************************************************/

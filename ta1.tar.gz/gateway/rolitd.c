/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#include "rolit.h"
#include <stdio.h>
#include <stdlib.h> /* getenv, exit */
#include <signal.h>
#include <string.h>
#include <stdarg.h>

#ifdef SUN
#undef RET_OK
#endif

#include  "olitapi.h"
#include "olitsign.h"

AAA_OliContext_ST context;

int rolit_shutdown = 0;

bool_t rolit_snd_1_svc(snd_agmt *argp, snd_rslt *result, struct svc_req *rqstp)
{
   bool_t retval = TRUE;

   result->status = AAA_OliCall( &context, argp->buffer.data_val,
      argp->buffer.data_len);

   return retval;
}

bool_t rolit_rcv_1_svc(rcv_agmt *argp, rcv_rslt *result, struct svc_req *rqstp)
{
   bool_t retval = TRUE;
   result->buffer.data_len = argp->length;
   result->buffer.data_val = (char *)malloc(argp->length);

   result->status = AAA_OliGet( &context, (AAA_OliChEnum)argp->channel, 
   result->buffer.data_val, result->buffer.data_len);

   return retval;
}

bool_t rolit_sts_1_svc(void *argp, sts_rslt *result, struct svc_req *rqstp)
{
   bool_t retval = TRUE;
   unsigned char severity;
   unsigned int  facility;
   unsigned int      code;

   char *message = NULL;

   result->status = AAA_OliGetStatus( &context, &severity, &facility, &code, &message);
   result->severity = (int)severity;
   result->facility = (int)facility;
   result->code     = (int)    code;

   result->message = message == NULL ? strdup("<none>") : strdup(message);

   return retval;
}

bool_t rolit_set_1_svc(set_agmt *argp, void *result, struct svc_req *rqstp)
{
   bool_t retval = TRUE;
   AAA_OliSetOpti(argp->action, argp->size);

   return retval;
}

bool_t rolit_sdn_1_svc(void *argp, void *result, struct svc_req *rqstp)
{
   bool_t retval = TRUE;
   rolit_shutdown = 1;

   return retval;
}

int rolit_program_1_freeresult(SVCXPRT *transp, xdrproc_t xdr_result, caddr_t result)
{
   (void) xdr_free(xdr_result, result);
   return TRUE;
}

/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#include "unidef.h"

#include <string.h>
#include <limits.h>

#include "sybconnection.h"
#include "sybbcp.h"
#include "rxa.h"

#include "conexcept.h"
#include "ddlgen.h"
#include "bkpublic.h"
#include "callstack.h"

using namespace std;

extern RXA_FCTPTR  EV_rxaFctStruct; /* DLA - PMSTA-23431 - 160824 */
extern int         EV_SybPacketSize;
extern CS_CONTEXT *EV_ApplContext;                                 /* application context */

#define ITER_NBR_FOR_DEADLOCK       4

#ifdef AAACONNECTIONTRACE
#include "callstack.h"
std::map<void *, std::string> SV_connectionTrace;
Lock                          SV_lock;
#endif

static std::map<std::string, std::string> defaultCharsetMap;

AAAConnection* SybConnection::createConnection(const AAAConnectionSpecification& spec, const int& id)
{
    return new SybConnection(spec, id);
}

SybConnection::SybConnection(const AAAConnectionSpecification& spec, const int& id)
    : DbiConnection(spec, id)
    , m_connection(nullptr)
    , m_command(nullptr)
    , m_mode(DBA_LANG)
    , m_lastSybClSeverity(-1)
    , m_currentCmd(Syb_Command_None)
    , m_sqlTraceStrPtr(nullptr)
    , m_blkdesc(nullptr)
{
    DBA_CONNECT_INFO_STP    connStp = this->getConnStructPtr();

    this->m_connectToRDBMS = Sybase;

    SYS_Bzero(&this->m_datafmt, sizeof(this->m_datafmt));

    connStp->maxRows                                = NO_VALUE;                               /* REF4520 */
    connStp->blockMode                              = 0;                                      /* DVP291 */
    connStp->subscriptionElem.eventNat              = Event_Nature_None;                      /* REF4204 */
    connStp->subscriptionElem.auditRecSt            = NullDynSt;                              /* REF4204 */
    connStp->subscriptionElem.auditRecStp           = NULL;                                   /* REF4204 */
    connStp->subscriptionElem.currAction            = NullAction;                             /* REF4204 */
    connStp->subscriptionElem.subscripCodifCompoStp = NULL;                                   /* REF4204 */
    connStp->subscriptionElem.subscripCodifCompoNmb = 0;                                      /* REF4204 */
    memset(&(connStp->subscriptionElem.creation_d), 0, sizeof(DATETIME_T));                   /* DLA - REF6935 - 020207 */
    connStp->preserveConfirmedFlg                   = FALSE;                                  /* REF11338 */
    connStp->passwordChange                         = false;                                  /* PMSTA-18094 - 130514 - PMO */
    connStp->timeOut                                = NO_VALUE;                               /* PMSTA-22163 - LJE - 160119 */
    connStp->poolConnectNo                          = id;
}

/************************************************************************
*   Function             :  SybConnection::~SybConnection()
*
*   Description          :  Destructor
*
*   Arguments            :  None
*
*   Return               :  None
*
*   Creation Date        :
*
*   Last Modification    :  PMSTA-26427 - 240217 - PMO : Dispatcher must run faster
*
*************************************************************************/
SybConnection::~SybConnection()
{
    this->doDisconnect();
}

/************************************************************************
*   Function             : SybConnection::getCS_COMMAND()
*
*   Description          : Retrieve the CS_COMMAND and log in case of error
*
*   Arguments            : file         : FILEINFO
*                          line         : FILEINFO
*                          dbiConn      : Connection to use
*                          functionName : Function Name
*
*   Functions call       :
*
*   Return               : CS_COMMAND * on Success
*                          nullptr in case of error
*
*   Creation date        : PMSTA-24981 - 151116 - PMO : pid: threadid: missing form trace
*
*   Last Modif. Date     :
*
*************************************************************************/
CS_COMMAND * SybConnection::getCS_COMMAND(const char * file, const int line, const std::string & functionName)
{
    CS_COMMAND *csCommand = this->m_command;

    /* Is it a valid command? */
    if (csCommand == nullptr)
    {
        std::string errMsg;

        if ((SYS_IsGuiMode() == TRUE) || (SERVER_IS_INIT() == TRUE))
        {
            SYS_StringFormat(errMsg, "Command (" szFormatPointer "), Thread(%s)", (void*)csCommand, SYS_GetThreadDescriptionForLog().c_str());
            (void)MSG_SendMesg(RET_GEN_ERR_INVARG, 1, file, line, functionName.c_str(), errMsg.c_str());
        }
        else
        {
            SYS_StringFormat(errMsg,
                             "%s. Invalid argument. Command (" szFormatPointer "), thread (%s)",
                             functionName.c_str(),
                             (void*)csCommand,
                             SYS_GetThreadDescriptionForLog().c_str());
            (void)MSG_SendStrToLog(errMsg);
        }
    }

    return csCommand;
}


/************************************************************************
*   Function             : SybConnection::getLabelRetCode()
*
*   Description          : Return the corresponding label
*
*   Arguments            : sybRetCode   Sybase ret code
*
*   Functions call       :
*
*   Return               : None
*
*   Creation date        : PMSTA-24981 - 151116 - PMO : pid: threadid: missing form trace
*
*   Last Modif. Date     :
*
*************************************************************************/
std::string SybConnection::getLabelRetCode(CS_RETCODE & sybRetCode)
{
    std::string ret;

    switch (sybRetCode)
    {
        case CS_BUSY:
            ret = "Busy";
            break;

        case CS_CANCELED:
            ret = "Canceled";
            break;

        case CS_END_DATA:
            ret = "END_DATA";
            break;

        case CS_END_RESULTS:
            ret = "END_RESULTS";
            break;

        case CS_FAIL:
            ret = "Failed";
            break;

        case CS_INTERRUPT:
            ret = "Interrupt";
            break;

        case CS_PENDING:
            ret = "Pending";
            break;

        case CS_QUIET:
            ret = "Quiet";
            break;

        case CS_ROW_FAIL:
            ret = "ROW_FAIL";
            break;

        case CS_SUCCEED:
            ret = "Succeed";
            break;

        case CS_TIMED_OUT:
            ret = "Timed out";
            break;

        case CS_TRYING:
            ret = "Trying";
            break;

        default:
            ret = "Unknown";
            break;
    }

    return ret;
}

/************************************************************************
**
**  Function    :   SybConnection::doConnect()
**
**  Description :
**
**  Argument    :
**
**  Return      :
**
**  Creation    :
**
**  Last modif. :
**
*************************************************************************/
bool SybConnection::doConnect()
{
    RET_CODE         ret = RET_SUCCEED;
    int              csConnectNo = this->getId();
    int              encryptionLevel = EncryptionLevel_None;
    CS_BOOL          lobparamsupport;
    char             hostName[MAX_USERINFO_LEN];

    char password[MAX_USERINFO_LEN + 1];
    AUTO_PASSWORD_CLEAR(password, sizeof(password));                /* PMSTA-18094 - 130514 - PMO */
    char drowssap[MAX_USERINFO_LEN + 1];
    AUTO_PASSWORD_CLEAR(drowssap, sizeof(drowssap));                /* PMSTA-18094 - 130514 - PMO */

    /* Allocate a CS_CONNECTION structure */
    if (EV_rxaFctStruct.pfn_ct_con_alloc(EV_ApplContext, &this->m_connection) != CS_SUCCEED)
    {
        this->m_lastResultRetCode = RET_DBA_ERR_ALLOCSYBCON;

        throw AAAInvalidConnectionStateException("connection cannot be created ", this->getDescription(), this->getId());
    }

    if ((EV_SybPacketSize >= 256) && (EV_SybPacketSize <= 9999))
    {
        if (SYB_CtConProps(*this, CS_SET, CS_PACKETSIZE, /* REF3847 / REF7264 - PMO */
                           &EV_SybPacketSize, CS_UNUSED, NULL) != CS_SUCCEED)
        {
            this->m_lastResultRetCode = RET_DBA_ERR_HANDLECONPROP;
            throw AAAInvalidConnectionStateException("connection cannot be correctly define", this->getDescription(), this->getId());
        }
    }

    /* Associate the user name and the password with the connection property */
    std::string userName = this->getSpecification().getCredentials().getUser();
    if (SYB_CtConProps(*this, CS_SET,
                       CS_USERNAME, (CS_VOID*)userName.c_str(), CS_NULLTERM, NULL) != CS_SUCCEED) /* REF3847 / REF7264 - PMO */
    {
        this->m_lastResultRetCode = RET_DBA_ERR_HANDLECONPROP;
        throw AAAInvalidConnectionStateException("connection cannot be correctly define", this->getDescription(), this->getId());
    }

    { /* Specify the connection type (Synchronous or Asynchronous) */

        CS_INT type = CS_SYNC_IO;

        if (SYB_CtConProps(*this, CS_SET, CS_NETIO, &type, CS_UNUSED, NULL) != CS_SUCCEED) /* REF3847 / REF7264 - PMO */
        {
            this->m_lastResultRetCode = RET_DBA_ERR_HANDLECONPROP;
            throw AAAInvalidConnectionStateException("connection cannot be correctly define", this->getDescription(), this->getId());
        }
    }


    SYS_GetHostName(hostName, sizeof(hostName));

    /* REF3847 */
    if (SYB_CtConProps(*this, CS_SET, CS_HOSTNAME, hostName, CS_NULLTERM, NULL) != CS_SUCCEED)   /* REF7264 - PMO */
    {
        this->m_lastResultRetCode = RET_DBA_ERR_HANDLECONPROP;
        throw AAAInvalidConnectionStateException("connection cannot be correctly define", this->getDescription(), this->getId());
    }


    /*
    * Set the sybase current charset for each client connection.
    * Ref.: DVP493, GRD 970609.
    */

    CURRENTCHARSETCODE_ENUM currentCharsetCode = this->getCurrCharsetEn();

    if (currentCharsetCode != CurrentCharsetCode_IsNull)
    {
        CS_LOCALE       *localDefault;
        const char * charsetName = GEN_GetCurCharset(currentCharsetCode, CharsetCodeType_Rdbms); /* DLA - REF9303 - 030826 */

        if (EV_rxaFctStruct.pfn_cs_loc_alloc(SYB_GetCsContext(), &localDefault) != CS_SUCCEED)
        {
            MSG_LogMesg(RET_GEN_ERR_CHARSETPROBLEMS, 2, FILEINFO);

            if (SYS_IsGuiMode() == TRUE)
            {
                MSG_DispMsgText(RET_DBA_ERR_HANDLECONPROP, "Problem configuring character sets");    /*  FIH-REF8683-030708  Add retCode */
            }

            this->m_lastResultRetCode = RET_DBA_ERR_HANDLECONPROP;
            throw AAAInvalidConnectionStateException("connection cannot be correctly define", this->getDescription(), this->getId());
        }

        if (EV_rxaFctStruct.pfn_cs_locale(SYB_GetCsContext(), CS_SET, localDefault,
                                          CS_LC_ALL, NULL, CS_UNUSED, NULL) != CS_SUCCEED)
        {
            EV_rxaFctStruct.pfn_cs_loc_drop(SYB_GetCsContext(), localDefault);
            MSG_LogMesg(RET_GEN_ERR_CHARSETPROBLEMS, 2, FILEINFO);

            if (SYS_IsGuiMode() == TRUE)
                MSG_DispMsgText(RET_DBA_ERR_HANDLECONPROP, "Problem configuring character sets");    /*  FIH-REF8683-030708  Add retCode */

            this->m_lastResultRetCode = RET_DBA_ERR_HANDLECONPROP;
            throw AAAInvalidConnectionStateException("connection cannot be correctly define", this->getDescription(), this->getId());
        }

        if (EV_rxaFctStruct.pfn_cs_locale(SYB_GetCsContext(), CS_SET, localDefault,
                                          CS_SYB_CHARSET, (CS_CHAR*)charsetName, CS_NULLTERM, NULL) != CS_SUCCEED)
        {
            EV_rxaFctStruct.pfn_cs_loc_drop(SYB_GetCsContext(), localDefault);
            MSG_LogMesg(RET_GEN_ERR_CHARSETPROBLEMS, 0, FILEINFO, charsetName);

            if (SYS_IsGuiMode() == TRUE)
                MSG_DispMsgText(RET_DBA_ERR_HANDLECONPROP, "Problem configuring character sets");    /*  FIH-REF8683-030708  Add retCode */

            this->m_lastResultRetCode = RET_DBA_ERR_HANDLECONPROP;
            throw AAAInvalidConnectionStateException("connection cannot be correctly define", this->getDescription(), this->getId());
        }

        if (SYB_CtConProps(*this, CS_SET, CS_LOC_PROP,   /* REF3847 / REF7264 - PMO */
            (void *)localDefault, CS_UNUSED, NULL) != CS_SUCCEED)
        {
            EV_rxaFctStruct.pfn_cs_loc_drop(SYB_GetCsContext(), localDefault);
            MSG_LogMesg(RET_GEN_ERR_CHARSETPROBLEMS, 1, FILEINFO, charsetName);

            if (SYS_IsGuiMode() == TRUE)
                MSG_DispMsgText(RET_DBA_ERR_HANDLECONPROP, "Problem configuring character sets");    /*  FIH-REF8683-030708  Add retCode */

            this->m_lastResultRetCode = RET_DBA_ERR_HANDLECONPROP;
            throw AAAInvalidConnectionStateException("connection cannot be correctly define", this->getDescription(), this->getId());
        }

        EV_rxaFctStruct.pfn_cs_loc_drop(SYB_GetCsContext(), localDefault);
    }

    const std::string appl_name(GEN_GetApplName());
    /* replace SV_ApplName by GEN_GetApplName() PMSTA-32904 - FME - 190129 */
    assert(appl_name.length() > 0); // The Application name must be setup before this call

    if (appl_name.length() > 0)
    {

        if (SYB_CtConProps(*this, CS_SET, CS_APPNAME,
            (void *)appl_name.c_str(), CS_NULLTERM, NULL) != CS_SUCCEED)
        {
            this->m_lastResultRetCode = RET_DBA_ERR_HANDLECONPROP;
            throw AAAInvalidConnectionStateException("connection cannot be correctly define", this->getDescription(), this->getId());
        }
    }
    else
    {
        this->m_lastResultRetCode = RET_DBA_ERR_HANDLECONPROP;
        throw AAAInvalidConnectionStateException("connection cannot be correctly define", this->getDescription(), this->getId());
    }

    if (SERVER_MODE() || SYS_IsDdlGenMode() == TRUE || SYS_IsSqlMode() == TRUE)
    {
        CS_BOOL              blkLogin = CS_TRUE;

        if (SYB_CtConProps(*this, CS_SET,
                           CS_BULK_LOGIN, &blkLogin, CS_UNUSED, NULL) != CS_SUCCEED)
        {
            this->m_lastResultRetCode = RET_DBA_ERR_HANDLECONPROP;
            throw AAAInvalidConnectionStateException("connection cannot be correctly define", this->getDescription(), this->getId());
        }
    }

    /* Allocate a CS_COMMAND structure */
    if (EV_rxaFctStruct.pfn_ct_cmd_alloc(this->m_connection, &this->m_command) != CS_SUCCEED)
    {
        this->m_lastResultRetCode = RET_DBA_ERR_ALLOCSYBCMD;
        throw AAAInvalidConnectionStateException("connection cannot be correctly define", this->getDescription(), this->getId());
    }

    static int
        SV_Flag_OCS1251 = -1;

    int flag_ocs1251 = 0;

    if (SV_Flag_OCS1251 == -1)
        SV_Flag_OCS1251 =
        SYS_GetEnv(
            "AAADISABLEOCS1251WORKAROUND") != NULL ? 0 : 1;

    if (SYS_IsSrvMode())
        flag_ocs1251 = SV_Flag_OCS1251;

    const char *server = this->getDescription().getServerName().c_str();

    if ((this->m_connection == NULL) || (server == NULL))
    {
        std::string errMsg;

        if ((SYS_IsGuiMode() == TRUE) || (SERVER_IS_INIT() == TRUE))
        {
            SYS_StringFormat(errMsg, "Connection (" szFormatPointer "), server (%s), thread (%s)", (void*)this->m_connection, server, SYS_GetThreadDescriptionForLog().c_str());        /* PMSTA-16124 - 250413 - PMO */
            MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "SYB_CtConnect", errMsg.c_str());
        }
        else
        {
            SYS_StringFormat(errMsg, "SYB_CtConnect. Invalid argument. Connection (" szFormatPointer "), server (%s), thread (%s)",                                                                         /* PMSTA-16124 - 250413 - PMO */
                (void*)this->m_connection, server, SYS_GetThreadDescriptionForLog().c_str());                                                                                           /* PMSTA-16124 - 250413 - PMO */
            MSG_SendStrToLog(errMsg);
        }

        return(false);
    }


    this->m_currentCmd = Syb_Command_Connect; /* Keep trace of the current command. */

    GEN_GetApplInfo(ApplEncryptionLevel, &encryptionLevel);

    if (encryptionLevel != EncryptionLevel_None)
    {
        if (this->getDescription().getType() == SqlServer)
        {
            {
                CS_BOOL flag = CS_TRUE;

                if (SYB_CtConProps(*this, CS_SET, CS_SEC_ENCRYPTION, (CS_VOID*)&flag, CS_UNUSED, NULL) != RET_SUCCEED)
                {
                    this->sendMsg(FILEINFO, "SYB_CtConnect: Unable to setup CS_SEC_ENCRYPTION");
                }
            }
            {   /* PMSTA-50363 - FME - 2022-09-28- support for net password encryption reqd = 2 */
                CS_BOOL flag = CS_TRUE;

                if (SYB_CtConProps(*this, CS_SET, CS_SEC_EXTENDED_ENCRYPTION, (CS_VOID*)&flag, CS_UNUSED, NULL) != RET_SUCCEED)
                {
                    this->sendMsg(FILEINFO, "SYB_CtConnect: Unable to setup CS_SEC_EXTENDED_ENCRYPTION");
                }
            }
        }
    }

    if (flag_ocs1251)
    {
        CS_BOOL     boolean = TRUE;

        if (SYB_CtConProps(*this, CS_SET, CS_ASYNC_NOTIFS, &boolean, CS_UNUSED, NULL) != CS_SUCCEED)
        {
            MSG_SendStrToLog("SYB_CtConnect: Unable to switch on CS_ASYNC_NOTIFS properties");
        }
    }

    /* DLA - PMSTA-928 - 061117 */
    int tmpPacketSize = 0;

    SYB_CtConProps(*this, CS_GET, CS_PACKETSIZE,
                   &tmpPacketSize, CS_UNUSED, NULL);

    if (EV_SybPacketSize != 0 && tmpPacketSize != EV_SybPacketSize)
    {
        if (SYB_CtConProps(*this, CS_SET, CS_PACKETSIZE,
                           &EV_SybPacketSize, CS_UNUSED, NULL) != CS_SUCCEED)
        {
            return(false);
        }
    }

    PasswordEncrypted pE = this->getSpecification().getCredentials().getPassword();
    PasswordClear pC = pE.getClearPassword();
    pC.copyPassword(password, sizeof(password));

        SYB_CtConProps(*this, CS_SET, CS_PASSWORD,
        (CS_VOID *)password, SYS_StrLen(password), NULL);


    if (this->getConnStructPtr()->timeOut != NO_VALUE)
    {
        CS_INT timeOut = this->getConnStructPtr()->timeOut;

        if (timeOut == 0)
        {
            timeOut = CS_NO_LIMIT;
        }
        SYB_CtConProps(*this, CS_SET, CS_TIMEOUT, (CS_VOID *)&timeOut, CS_UNUSED, NULL);
    }


    const AAALogger& connectionLog = AAALogger::get(AAALogger::Logger::Connections);
    if (connectionLog.isDebugEnabled())
    {
        std::string	logMessage = SYS_Stringer("Server Name: ", this->getDescription().getServerName(), " - ",
                                              "User : ", this->getSpecification().getCredentials().getUser(), " - ",
                                              "Connect No: ", this->getId(), " - ",
                                              "SybConnection::connect");

        if (connectionLog.isTraceEnabled())
        {
            logMessage += " - Callstack: \n" + SYS_GetCallStack(0, true);
        }

        connectionLog.info(logMessage);
    }

    DATE_START_TIMER(3, TIMER_MASK_SQLC);

    CS_RETCODE sybRetCode = EV_rxaFctStruct.pfn_ct_connect(this->m_connection, (RXA_CHAR *)server, CS_NULLTERM); /* MANDATORY */

#ifdef AAACONNECTIONTRACE
    SV_connectionTrace.insert(make_pair(this->m_connection, SYS_GetCallStack()));
#endif

    DATE_STOP_TIMER(3, TIMER_MASK_SQLC);

    /* PMSTA-18094 - 130514 - PMO */
    if (CS_SUCCEED == sybRetCode && TRUE == SYS_IsGuiMode())
    {
        this->clearPassword();
    }

    if (CS_PENDING == sybRetCode || CS_BUSY == sybRetCode)
    {
        m_isDBConnectRetryRequired = true;
    }

    if (flag_ocs1251)
    {
        CS_BOOL boolean = FALSE;

        if (SYB_CtConProps(*this, CS_SET, CS_ASYNC_NOTIFS, &boolean, CS_UNUSED, NULL) != CS_SUCCEED)
        {
            MSG_SendStrToLog("SYB_CtConnect: Unable to switch off CS_ASYNC_NOTIFS properties");
        }
    }


    /* 'Call to ct_connect failed...' appears too oftenly.
    * Even when the server has not finished its initialization.
    * We suppress this message in order not to disturb the log file.
    * We still can have this message displayed using this env. variable: AAAPRINTCONNECTFAILED.
    * 11/01/01 - GRD - REF5135.
    */

    if (SYS_GetEnvBoolOrDefValue("AAAPRINTCONNECTFAILED", false) && sybRetCode != CS_SUCCEED)
    {
        std::string errMsg;

        SYS_StringFormat(errMsg,
                         "Call to ct_connect failed. Connection (%x), server (%s), thread (%s), connection (%d), status (%s)",                                              /* PMSTA-16124 - 250413 - PMO */
                         csConnectNo,
                         server,
                         SYS_GetThreadDescriptionForLog().c_str(),
                         csConnectNo,
                         (sybRetCode == CS_FAIL) ? "Failed" :
                         (sybRetCode == CS_PENDING) ? "Pending" :
                         (sybRetCode == CS_BUSY) ? "Busy" :
                         "Unknown");

        this->sendMsg(FILEINFO, errMsg);
    }

    if (csConnectNo != DBA_CONN_NOT_FOUND)
    {
        this->m_currentCmd = Syb_Command_None;
    }

    if (EV_sqlFile != NULL)
    {
        std::string errMsg;

        SYS_StringFormat(errMsg,
                         "    ct_connect()     Connect=%-9d server=%s thread=" szFormatPointer " status=%-12.12s",                                                                        /* PMSTA-16124 - 250413 - PMO */
                         csConnectNo,
                         server,
                         SYS_GetThreadDescriptionForLog().c_str(),
                         (sybRetCode == CS_SUCCEED) ? "Succeed" :
                         (sybRetCode == CS_FAIL) ? "Failed" :
                         (sybRetCode == CS_PENDING) ? "Pending" :
                         (sybRetCode == CS_BUSY) ? "Busy" :
                         "Unknown");

        MSG_SendSqlTrace(errMsg.c_str());
    }

    if (sybRetCode != CS_SUCCEED && sybRetCode != CS_PENDING)
    {
        return(false);
    }

    sybRetCode = EV_rxaFctStruct.pfn_ct_capability(this->m_connection, CS_GET, CS_CAP_REQUEST,
                                                   CS_RPCPARAM_LOB, &lobparamsupport);

    if (lobparamsupport == CS_FALSE)
    {
        MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "Large objects as stored procedure parameters is disable!");

    }

    return (ret == RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   SybConnection::doDisconnect()
**
**  Description :
**
**  Argument    :
**
**  Return      :
**
**  Creation    :
**
**  Last modif. :
**
*************************************************************************/
bool SybConnection::doDisconnect()
{
    if (this->m_connection != nullptr)
    {
        if (this->m_command != nullptr)
        {
            SYB_CtCmdDrop(*this);
        }

#ifdef AAACONNECTIONTRACE
        SV_connectionTrace.erase(this->m_connection);
#endif

        const AAALogger& connectionLog = AAALogger::get(AAALogger::Logger::Connections);
        if (connectionLog.isDebugEnabled())
        {
            std::string	logMessage = SYS_Stringer("Server Name: ", this->getDescription().getServerName(), " - ",
                                                  "User : ", this->getSpecification().getCredentials().getUser(), " - ",
                                                  "Connect No: ", this->getId(), " - ",
                                                  "SybConnection::disconnect");

            if (connectionLog.isTraceEnabled())
            {
                logMessage += " - Callstack: \n" + SYS_GetCallStack(0, true);
            }

            connectionLog.info(logMessage);
        }

        CS_INT status = SYB_CtClose(*this, CS_FORCE_CLOSE);

        if (status == CS_SUCCEED)
        {
            /* Free memory allocation for the connection structure */
            SYB_CtConDrop(*this);
        }
    }

    this->m_currentCmd = Syb_Command_None;

    return true;
}


/************************************************************************
*   Function             : SybConnection::clearPassword()
*
*   Description          : Clear the password stored in clear into sybase connection
*
*   Arguments            :
*
*   Global var. modified : None
*
*   Return               : None
*
*   Creation date        : PMSTA-18094 - 130514 - PMO : Avoid extracting the user credentials from the GUI running on Windows (via dump, etc.)
*
*   Last modification    :
*
*************************************************************************/
void SybConnection::clearPassword()
{
    char        password[MAX_USERINFO_LEN + 1];
    CS_INT      outLen;

    if (SYB_CtConProps(*this, CS_GET, CS_PASSWORD, password, sizeof(password), &outLen) != CS_SUCCEED)
    {
        password[0] = 0;
        outLen = MAX_USERINFO_LEN;
    }
    else
    {
        if (outLen > 0)
        {
            outLen--;
        }
    }

    /* Clear the password */
    memset(password, '*', outLen);
    password[outLen] = 0;

    (void)SYB_CtConProps(*this, CS_SET, CS_PASSWORD, (CS_VOID *)password, SYS_StrLen(password), NULL);
    (void)EV_rxaFctStruct.pfn_ct_remote_pwd(this->m_connection, CS_CLEAR, NULL, CS_UNUSED, NULL, CS_UNUSED);
}

PTR SybConnection::getConnectionPtr()
{
    return this->m_connection;
}

PTR SybConnection::getCommandPtr()
{
    return this->m_command;
}

RET_CODE SybConnection::createStatement(const std::string &sql, DBA_ACTION_ENUM action)
{
    CS_RETCODE sybRetCode = CS_SUCCEED;
    
    this->startRequest();

    this->m_mode = DBA_RPC;
    if (action == Custom || action == NullAction || action == Special || action == AllStdProcs)
    {
        this->m_mode = DBA_LANG;
    }

    /* Register the request in the command structure */
    if ((sybRetCode = SYB_CtCommand(*this, this->m_mode, sql.c_str(), &this->m_sqlTraceStrPtr)) != CS_SUCCEED)
    {
        SYB_SendSqlTrace(&this->m_sqlTraceStrPtr);
        this->m_lastResultRetCode = this->convertToRetCode(sybRetCode);
    }

    return this->m_lastResultRetCode;
}

RET_CODE SybConnection::doAddBatch()
{
    if (this->getCurrProcedure() == nullptr)
    {
        if (this->getBatchMode() == BatchMode::TryBCP)
        {
            return this->doAddBatchBCP();
        }
        return this->doAddBatchLang();
    }
    else
    {
        if (this->m_batchSize == 0)
        {
            this->getSqlRequest().m_batchOutputSet.clear();
            this->m_batchStream.str(string());
            this->m_batchStream.clear();
        }

        string          recBuffer;

        DBI_PrintSqlReqBodyStart(recBuffer, this->getCurrProcedure());

        for (auto dynFldIt = this->getRequestParamMap().begin(); dynFldIt != this->getRequestParamMap().end(); ++dynFldIt)
        {
            DbiInOutData  *inputData = dynFldIt->second;
            DATATYPE_ENUM  fieldType = inputData->m_dataType;
            stringstream   recStream;

            if (inputData->m_bOutput)
            {
                string outParam = SYS_Stringer(inputData->m_sqlName, "_", this->m_batchSize);

                this->m_batchStream << endl << "declare " << outParam << " " << DBA_GetDictDataTpStp(fieldType)->sqlName << endl;

                recStream << outParam << " output";
            }
            else if (DBI_FldToDbDataStr(recStream, inputData->getDynFldStp(), 0, fieldType, true, Sybase) == RET_SRV_LIB_ERR_DB_OVERFLOW)
            {
                string buffer;
                SYS_Stringer(buffer, "Data overflow detected while executing procedure %s, parameter %s", this->getCurrProcedure()->procName, inputData->m_sqlName.c_str());

                MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, buffer.c_str());
            }

            if (dynFldIt == this->getRequestParamMap().begin())
            {
                this->m_batchStream << recBuffer;
            }
            else
            {
                this->m_batchStream << ",";
            }
            this->m_batchStream << recStream.str();
        }
        this->m_batchStream << " ";
    }
    return RET_SUCCEED;
}

RET_CODE SybConnection::doAddBatchDyn()
{
    return RET_SUCCEED;
}

RET_CODE SybConnection::bcpModifyDatafmt(DbiInOutData   *inputData)
{
    SYS_Bzero(&this->m_datafmt, sizeof(this->m_datafmt));

    this->m_datafmt.count = 1;

    if (inputData->isNull())
    {
        inputData->m_dataLength = 0;
    }
    else
    {
        inputData->m_dataLength = CS_UNUSED;
    }

    switch (inputData->m_dataType)
    {
        case CodeType:
        case InfoType:
        case LongnameType:
        case NameType:
        case PhoneType:
        case SysnameType:
        case LongSysnameType:
        case ShortinfoType:
        case UrlType:
        case NoteType:
            this->m_datafmt.datatype  = CS_CHAR_TYPE;
            this->m_datafmt.format    = CS_FMT_NULLTERM;
            this->m_datafmt.maxlength = GET_MAXLEN(inputData->m_dataType) + 1;
            if (inputData->isNull() == false)
            {
                inputData->m_dataLength = CAST_INT(strlen(inputData->getCharPtr()));
            }
            break;

        case DateType:
            this->m_datafmt.datatype  = CS_INT_TYPE;
            this->m_datafmt.format    = CS_FMT_UNUSED;
            this->m_datafmt.maxlength = sizeof(CS_INT);
            break;

        case DatetimeType:
            this->m_datafmt.datatype  = CS_FLOAT_TYPE;
            this->m_datafmt.format    = CS_FMT_UNUSED;
            this->m_datafmt.maxlength = sizeof(CS_FLOAT);
            break;

        case DictType:
            this->m_datafmt.datatype  = CS_BIGINT_TYPE;
            this->m_datafmt.maxlength = sizeof(CS_BIGINT);
            this->m_datafmt.format    = CS_FMT_UNUSED;
            this->m_datafmt.precision = 18;
            this->m_datafmt.scale     = 0;
            break;

        case EnumType:
            this->m_datafmt.datatype  = CS_TINYINT_TYPE;
            this->m_datafmt.format    = CS_FMT_UNUSED;
            this->m_datafmt.maxlength = sizeof(CS_TINYINT);
            break;

        case ExchangeType:
            this->m_datafmt.datatype  = CS_FLOAT_TYPE;
            this->m_datafmt.format    = CS_FMT_UNUSED;
            this->m_datafmt.maxlength = sizeof(CS_FLOAT);
            this->m_datafmt.precision = 18;
            this->m_datafmt.scale     = 0;
            break;

        case FlagType:
            this->m_datafmt.datatype  = CS_TINYINT_TYPE;
            this->m_datafmt.format    = CS_FMT_UNUSED;
            this->m_datafmt.maxlength = sizeof(CS_TINYINT);
            break;

        case IdType:
            this->m_datafmt.datatype  = CS_BIGINT_TYPE;
            this->m_datafmt.maxlength = sizeof(CS_BIGINT);
            this->m_datafmt.format    = CS_FMT_UNUSED;
            this->m_datafmt.precision = 18;
            this->m_datafmt.scale     = 0;
            break;

        case IntType:
        case MaskType:
            this->m_datafmt.datatype  = CS_INT_TYPE;
            this->m_datafmt.format    = CS_FMT_UNUSED;
            this->m_datafmt.maxlength = sizeof(CS_INT);
            break;

        case EnumMaskType:
            this->m_datafmt.datatype  = CS_BIGINT_TYPE;
            this->m_datafmt.maxlength = sizeof(CS_BIGINT);
            this->m_datafmt.format    = CS_FMT_UNUSED;
            break;

        case MethodType:
            this->m_datafmt.datatype  = CS_TINYINT_TYPE;
            this->m_datafmt.format    = CS_FMT_UNUSED;
            this->m_datafmt.maxlength = sizeof(CS_TINYINT);
            break;


        case NumberType:
            this->m_datafmt.datatype  = CS_FLOAT_TYPE;
            this->m_datafmt.format    = CS_FMT_UNUSED;
            this->m_datafmt.maxlength = sizeof(CS_FLOAT);
            this->m_datafmt.precision = 18;
            this->m_datafmt.scale     = 0;
            break;
            
        case PriceType:
            this->m_datafmt.datatype  = CS_FLOAT_TYPE;
            this->m_datafmt.format    = CS_FMT_UNUSED;
            this->m_datafmt.maxlength = sizeof(CS_FLOAT);
            this->m_datafmt.precision = 29;
            this->m_datafmt.scale     = 14;
            break;

        case PercentType:
            this->m_datafmt.datatype  = CS_FLOAT_TYPE;
            this->m_datafmt.format    = CS_FMT_UNUSED;
            this->m_datafmt.maxlength = sizeof(CS_FLOAT);
            this->m_datafmt.precision = 18;
            this->m_datafmt.scale     = 0;
            break;

        case PeriodType:
            this->m_datafmt.datatype  = CS_SMALLINT_TYPE;
            this->m_datafmt.format    = CS_FMT_UNUSED;
            this->m_datafmt.maxlength = sizeof(CS_SMALLINT);
            break;

        case SmallintType:
            this->m_datafmt.datatype  = CS_SMALLINT_TYPE;
            this->m_datafmt.format    = CS_FMT_UNUSED;
            this->m_datafmt.maxlength = sizeof(CS_SMALLINT);
            break;

        case LongintType:
            this->m_datafmt.datatype  = CS_BIGINT_TYPE;
            this->m_datafmt.maxlength = sizeof(CS_BIGINT);
            this->m_datafmt.format    = CS_FMT_UNUSED;
            break;

        case TimeStampType:
        case TimeStampTType:
            this->m_datafmt.datatype = CS_BINARY_TYPE;
            this->m_datafmt.format = CS_FMT_UNUSED;
            break;

        case BlobType:
            this->m_datafmt.datatype  = CS_IMAGE_TYPE;
            this->m_datafmt.format    = CS_FMT_UNUSED;
            this->m_datafmt.maxlength = INT_MAX;
            inputData->m_dataLength   = 0;
            break;

        case TextType:
            this->m_datafmt.datatype  = CS_TEXT_TYPE;
            this->m_datafmt.format    = CS_FMT_NULLTERM;
            this->m_datafmt.maxlength = INT_MAX;
            inputData->m_dataLength   = CAST_INT(strlen(inputData->getCharPtr()));
            break;

        case TinyintType:
            this->m_datafmt.datatype  = CS_TINYINT_TYPE;
            this->m_datafmt.format    = CS_FMT_UNUSED;
            this->m_datafmt.maxlength = sizeof(CS_TINYINT);
            break;

        case AmountType:
            this->m_datafmt.datatype  = CS_FLOAT_TYPE;
            this->m_datafmt.format    = CS_FMT_UNUSED;
            this->m_datafmt.maxlength = sizeof(CS_FLOAT);
            this->m_datafmt.precision = 18;
            this->m_datafmt.scale     = 0;
            break;

        case LongamountType:
            this->m_datafmt.datatype  = CS_FLOAT_TYPE;
            this->m_datafmt.format    = CS_FMT_UNUSED;
            this->m_datafmt.maxlength = sizeof(CS_FLOAT);
            this->m_datafmt.precision = 18;
            this->m_datafmt.scale     = 0;
            break;

        case String1000Type:
        case String2000Type:
        case String3000Type:
        case String4000Type:
        case String7000Type:
        case String15000Type:
            this->m_datafmt.datatype  = CS_LONGCHAR_TYPE;
            this->m_datafmt.format    = CS_FMT_NULLTERM;
            this->m_datafmt.maxlength = GET_MAXLEN(inputData->m_dataType) + 1;
            inputData->m_dataLength   = CAST_INT(strlen(inputData->getCharPtr()));
            break;

        case UniInfoType:
        case UniCodeType:
        case UniLongnameType:
        case UniNameType:
        case UniNoteType:
        case UniPhoneType:
        case UniShortinfoType:
        case UniSysnameType:
        case UniTextType:
        case UniUrlType:
        case UniString1000Type:
        case UniString2000Type:
        case UniString3000Type:
        case UniString4000Type:
        case UniString7000Type:
        case UniString15000Type:
            this->m_datafmt.datatype  = CS_UNICHAR_TYPE;
            this->m_datafmt.format    = CS_FMT_NULLTERM;
            this->m_datafmt.maxlength = (GET_MAXLEN(inputData->m_dataType) + 1) * sizeof(UChar);
            inputData->m_dataLength   = u_strlen(inputData->getUCharPtr()) * sizeof(UChar);
            break;

        case TimeType:
        case YearType:
        case ExtensionType:
        case ChainedTypeType:
        case ArrayType:
        case MultiArrayType:
        default:
            break;
    }

    if (inputData->m_dataLength == CS_UNUSED)
    {
        inputData->m_dataLength = this->m_datafmt.maxlength;
    }

    this->m_datafmt.locale = NULL;

    return RET_SUCCEED;
}

RET_CODE SybConnection::doAddBatchBCP()
{
    if (this->m_batchSize == 0)
    {
        this->m_batchBindVector.resize(this->getRequestParamMap().size());

        CS_CONNECTION     *csConnection     = this->m_connection;

        /*
        ** Start by getting the bulk descriptor ( a CS_BLKDESK structure )
        */
        if (EV_rxaFctStruct.pfn_blk_alloc(csConnection,
                                          SYBASE_BLK_VERSION,
                                          &this->m_blkdesc) != CS_SUCCEED)
        {
            return(RET_MEM_ERR_ALLOC);
        }

        CS_INT  identityProps = CS_TRUE;
        if (EV_rxaFctStruct.pfn_blk_props(this->m_blkdesc, CS_GET, BLK_IDENTITY, &identityProps, CS_UNUSED, NULL) != CS_SUCCEED)
        {
            return(RET_DBA_ERR_INSERT_FAILED);
        }

        if (this->m_insertIdentityOn != (identityProps == CS_TRUE))
        {
            identityProps = (this->m_insertIdentityOn ? CS_TRUE : CS_FALSE);

            if (EV_rxaFctStruct.pfn_blk_props(this->m_blkdesc, CS_SET, BLK_IDENTITY, &identityProps, CS_UNUSED, NULL) != CS_SUCCEED)
            {
                return(RET_DBA_ERR_INSERT_FAILED);
            }
        }

        CS_INT buffer = CS_TRUE;
        if (EV_rxaFctStruct.pfn_blk_props(this->m_blkdesc, CS_SET, ARRAY_INSERT, &buffer, CS_UNUSED, NULL) != CS_SUCCEED)
        {
            return(RET_DBA_ERR_INSERT_FAILED);
        }

        LONGSYSNAME_T tableName;
        nstrncpy(tableName, sizeof(tableName), this->m_batchTableSqlName.c_str(), LONGSYSNAME_T_LEN);
        tableName[LONGSYSNAME_T_LEN] = 0;

        if (EV_rxaFctStruct.pfn_blk_init(this->m_blkdesc,
                                         CS_BLK_IN,
                                         tableName,
                                         CS_NULLTERM) != CS_SUCCEED)
        {
            return(RET_DBA_ERR_INSERT_FAILED);
        }
    }

    /*
    ** Treat each column and bind it as an array
    */
    for (auto & dynFldIt : this->getRequestParamMap())
    {
        DbiInOutData   *inputData = dynFldIt.second;

        this->bcpModifyDatafmt(inputData);

        if (this->m_datafmt.datatype == CS_BINARY_TYPE)
        {
            CS_DATAFMT  csDataFmtSource;

            memset(&csDataFmtSource, 0, sizeof(csDataFmtSource));
            csDataFmtSource.datatype = CS_USER_TIMESTAMP;
            csDataFmtSource.maxlength = sizeof(TIMESTAMP_T);
            csDataFmtSource.status = this->m_datafmt.status | CS_DESCIN;

            this->m_datafmt.precision = 0;
            this->m_datafmt.scale = 0;
            this->m_datafmt.status = CS_INPUTVALUE | CS_TIMESTAMP;

            CS_BINARY* binaryPtr = static_cast<CS_BINARY*>(CALLOC(8, sizeof(CS_BINARY)));
            inputData->setPtrToFree(binaryPtr);

            EV_rxaFctStruct.pfn_cs_convert(SYB_GetCsContext(),
                &csDataFmtSource,
                &(inputData->getDynFldStp()->data.timeStampValue),
                &this->m_datafmt,
                binaryPtr,
                NULL);

            inputData->m_valuePtr = binaryPtr;
            inputData->m_dataLength = 8 * sizeof(CS_BINARY);
        }


        if (EV_rxaFctStruct.pfn_blk_bind(this->m_blkdesc,
                                         dynFldIt.first + 1,
                                         &this->m_datafmt,
                                         inputData->m_valuePtr,
                                         &inputData->m_dataLength,
                                         &inputData->m_nullInd) != CS_SUCCEED)
        {
            return(RET_DBA_ERR_INSERT_FAILED);
        }
    }

    if (EV_rxaFctStruct.pfn_blk_rowxfer(this->m_blkdesc) != CS_SUCCEED)
    {
        stringstream     valuesStream;

        valuesStream << "BCP Error on following data - entity: " << this->m_batchTableSqlName << endl;

        for (auto dynFldIt = this->getRequestParamMap().begin(); dynFldIt != this->getRequestParamMap().end(); ++dynFldIt)
        {
            if (dynFldIt != this->getRequestParamMap().begin())
            {
                valuesStream << ", ";
            }
            valuesStream << SYS_Stringer("Col ", (dynFldIt->first + 1)) << " (" << dynFldIt->second->m_sqlName << ") = ";

            DBI_FldToDbDataStr(valuesStream, dynFldIt->second->getDynFldStp(), 0, dynFldIt->second->m_dataType, true, Sybase, nullptr);
        }

        MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, valuesStream.str().c_str());

        return(RET_DBA_ERR_INSERT_FAILED);
    }

    return RET_SUCCEED;
}

RET_CODE SybConnection::doAddBatchLang()
{
    CS_RETCODE  sybRetCode = CS_SUCCEED;

    if (this->m_batchSize == 0)
    {
        this->m_batchBindVector.resize(this->getRequestParamMap().size());

        for (auto &dynFldIt : this->getRequestParamMap())
        {
            DbiInOutData   *inputData    = dynFldIt.second;
            SybBatchBind   &batchBind    = this->m_batchBindVector[dynFldIt.first];
            CS_DATAFMT     &csDataFmt    = batchBind.csDataFmt;
            string          paramName    = SYS_Stringer("@", dynFldIt.first + 1);
            DATATYPE_ENUM   fieldType    = inputData->m_dataType;


            csDataFmt.status  = CS_INPUTVALUE;
            csDataFmt.namelen = CS_NULLTERM;

            strncpy(csDataFmt.name, paramName.c_str(), CS_MAX_CHAR);
            csDataFmt.name[CS_MAX_CHAR-1] = 0;

            if (fieldType == IdType || fieldType == DictType)
            {
                csDataFmt.datatype = CS_BIGINT_TYPE;
            }
            else
            {
                csDataFmt.datatype = SYB_ConvApplToSybType(fieldType);
            }

            csDataFmt.precision = 18;
            csDataFmt.scale = 0;

            switch (csDataFmt.datatype)
            {
                case CS_DATETIME_TYPE:
                case CS_DATETIME4_TYPE:
                {
                    if (csDataFmt.datatype == CS_DATETIME_TYPE)
                    {
                        batchBind.len = sizeof(batchBind.numeric);
                        sybRetCode = EV_rxaFctStruct.pfn_ct_setparam(this->m_command, &csDataFmt, &batchBind.datetime, &batchBind.len, &batchBind.indicator);
                    }
                    else
                    {    /* Short date case */
                        batchBind.len = sizeof(batchBind.numeric);
                        sybRetCode = EV_rxaFctStruct.pfn_ct_setparam(this->m_command, &csDataFmt, &batchBind.datetimeSmall, &batchBind.len, &batchBind.indicator);
                    }
                }
                break;

                case CS_CHAR_TYPE:
                case CS_LONGCHAR_TYPE:
                case CS_TEXT_TYPE:
                    csDataFmt.maxlength = GET_MAXDATALEN(fieldType);
                    batchBind.charPtr = static_cast<char*>(m_batchMp.calloc(FILEINFO, csDataFmt.maxlength + 1, sizeof(char)));
                    sybRetCode = EV_rxaFctStruct.pfn_ct_setparam(this->m_command, &csDataFmt, batchBind.charPtr, &batchBind.len, &batchBind.indicator);
                    break;

                case CS_UNICHAR_TYPE:
                case CS_UNITEXT_TYPE:
                    csDataFmt.maxlength = GET_MAXDATALEN(fieldType);
                    batchBind.uniCharPtr = static_cast<UChar*>(m_batchMp.calloc(FILEINFO, csDataFmt.maxlength + 1, sizeof(UChar)));
                    sybRetCode = EV_rxaFctStruct.pfn_ct_setparam(this->m_command, &csDataFmt, batchBind.uniCharPtr, &batchBind.len, &batchBind.indicator);
                    break;

                case CS_BINARY_TYPE:
                    batchBind.len = sizeof(batchBind.numeric);
                    sybRetCode = EV_rxaFctStruct.pfn_ct_setparam(this->m_command, &csDataFmt, &batchBind.binary, &batchBind.len, &batchBind.indicator);
                    break;

                case CS_IMAGE_TYPE:
                    csDataFmt.maxlength = GET_MAXDATALEN(fieldType);
                    batchBind.imagePtr = static_cast<CS_IMAGE*>(m_batchMp.calloc(FILEINFO, csDataFmt.maxlength + 1, sizeof(CS_IMAGE)));
                    sybRetCode = EV_rxaFctStruct.pfn_ct_setparam(this->m_command, &csDataFmt, batchBind.imagePtr, &batchBind.len, &batchBind.indicator);
                    break;

                case CS_TINYINT_TYPE:
                    batchBind.len = sizeof(batchBind.tinyint);
                    sybRetCode = EV_rxaFctStruct.pfn_ct_setparam(this->m_command, &csDataFmt, &batchBind.tinyint, &batchBind.len, &batchBind.indicator);
                    break;

                case CS_SMALLINT_TYPE:
                    batchBind.len = sizeof(batchBind.smallint);
                    sybRetCode = EV_rxaFctStruct.pfn_ct_setparam(this->m_command, &csDataFmt, &batchBind.smallint, &batchBind.len, &batchBind.indicator);
                    break;

                case CS_INT_TYPE:
                    batchBind.len = sizeof(batchBind.intValue);
                    sybRetCode = EV_rxaFctStruct.pfn_ct_setparam(this->m_command, &csDataFmt, &batchBind.intValue, &batchBind.len, &batchBind.indicator);
                    break;

                case CS_BIGINT_TYPE:
                    csDataFmt.precision = LONGINT_T_LEN;
                    csDataFmt.scale     = LONGINT_T_DEC;
                    batchBind.len       = sizeof(batchBind.bigint);
                    sybRetCode          = EV_rxaFctStruct.pfn_ct_setparam(this->m_command, &csDataFmt, &batchBind.bigint, &batchBind.len, &batchBind.indicator);
                    break;

                case CS_NUMERIC_TYPE:
                    csDataFmt.datatype = CS_FLOAT_TYPE;
                case CS_FLOAT_TYPE:
                    batchBind.len = sizeof(batchBind.dblValue);
                    sybRetCode = EV_rxaFctStruct.pfn_ct_setparam(this->m_command, &csDataFmt, &batchBind.dblValue, &batchBind.len, &batchBind.indicator);
                    break;

                default:
                    SYS_BreakOnDebug();
                    break;
            }

            if (sybRetCode != CS_SUCCEED)
            {
                this->m_lastResultRetCode = RET_DBA_ERR_SETPARAM;
                return this->m_lastResultRetCode;
            }
        }
    }

    for (auto &dynFldIt : this->getRequestParamMap())
    {
        DbiInOutData   *inputData    = dynFldIt.second;

        SybBatchBind   &batchBind    = this->m_batchBindVector[dynFldIt.first];
        CS_DATAFMT     &csDataFmt    = batchBind.csDataFmt;
        DATATYPE_ENUM   fieldType    = inputData->m_dataType;

        fieldType = inputData->m_dataType;

        batchBind.indicator = CS_GOODDATA;
        if (inputData->isNull())
        {
            if (fieldType == FlagType)
            {
                SET_FLAG_FALSE(inputData->getDynFldStp(), 0);
            }
            else
            {
                batchBind.indicator = CS_NULLDATA;
            }
            continue;
        }

        switch (csDataFmt.datatype)
        {
            case CS_DATETIME_TYPE:
            case CS_DATETIME4_TYPE:
            {
                /* Compose the Sybase reference date (1 jan 1900) */
                DATE_T refDate = DATE_Put((YEAR_T)1900, (MONTH_T)1, (DAY_T)1);

                INT_T               thirdSecond = 0;
                SMALLINT_T          minutes = 0;
                long                daysNbr = 0;
                HOUR_T              hour;
                MINUTE_T            min;
                SECOND_T            second;

                switch (fieldType)
                {
                    case DateType:
                        DATE_DaysBetween(refDate, GET_DATE(inputData->getDynFldStp(), 0), AccrRule_Actual_365, &daysNbr, 0);
                        break;

                    case DatetimeType:
                    {
                        DATETIME_ST datetimeSt = GET_DATETIME(inputData->getDynFldStp(), 0);
                        DATE_DaysBetween(refDate, datetimeSt.date, AccrRule_Actual_365, &daysNbr, 0);
                        TIME_Get(datetimeSt.time, &hour, &min, &second);
                        thirdSecond = (INT_T)(hour * 3600 + min * 60 + second) * 300;
                    }
                    break;

                    default:
                        break;
                }

                if (csDataFmt.datatype == CS_DATETIME_TYPE)
                {
                    batchBind.datetime.dtdays = daysNbr;
                    batchBind.datetime.dttime = thirdSecond;
                }
                else
                {    /* Short date case */
                    batchBind.datetimeSmall.days = (unsigned short)daysNbr;
                    batchBind.datetimeSmall.minutes = minutes;
                }
            }
            break;

            case CS_CHAR_TYPE:
            case CS_LONGCHAR_TYPE:
            case CS_TEXT_TYPE:
                batchBind.len     = GET_FLD_STRLEN(inputData->getDynFldStp(), 0);
                nstrcpy(batchBind.charPtr, csDataFmt.maxlength, GET_STRING(inputData->getDynFldStp(), 0));
                batchBind.charPtr[csDataFmt.maxlength] = 0;
                break;

            case CS_UNICHAR_TYPE:
            case CS_UNITEXT_TYPE:
                batchBind.len        = GET_FLD_USTRLEN(inputData->getDynFldStp(), 0) * 2;
                u_strncpy(batchBind.uniCharPtr, GET_USTRING(inputData->getDynFldStp(), 0), csDataFmt.maxlength);
                batchBind.uniCharPtr[csDataFmt.maxlength] = 0;
                break;

            case CS_BINARY_TYPE:
            {
                CS_DATAFMT  csDataFmtSource;

                memset(&csDataFmtSource, 0, sizeof(csDataFmtSource));
                csDataFmtSource.datatype = CS_USER_TIMESTAMP;
                csDataFmtSource.maxlength = sizeof(TIMESTAMP_T);
                csDataFmtSource.status = csDataFmt.status | CS_DESCIN;

                csDataFmt.precision = 0;
                csDataFmt.scale = 0;
                csDataFmt.maxlength = sizeof(TIMESTAMP_T);
                csDataFmt.status |= CS_TIMESTAMP;

                sybRetCode = EV_rxaFctStruct.pfn_cs_convert(SYB_GetCsContext(),
                                                            &csDataFmtSource,
                                                            &(inputData->getDynFldStp()->data.timeStampValue),
                                                            &csDataFmt,
                                                            &batchBind.binary,
                                                            NULL);

                if (sybRetCode != CS_SUCCEED)
                {
                    this->m_lastResultRetCode = RET_DBA_ERR_SETPARAM;
                    return this->m_lastResultRetCode;
                }
            }
            break;

            case CS_TINYINT_TYPE:
                batchBind.tinyint = GET_TINYINT(inputData->getDynFldStp(), 0);
                break;

            case CS_SMALLINT_TYPE:
                batchBind.smallint = GET_SMALLINT(inputData->getDynFldStp(), 0);
                break;

            case CS_INT_TYPE:
                batchBind.intValue = GET_INT(inputData->getDynFldStp(), 0);
                break;

            case CS_BIGINT_TYPE:
                batchBind.bigint = GET_LONGLONG(inputData->getDynFldStp(), 0);
                break;

            case CS_FLOAT_TYPE:
                batchBind.dblValue = GET_DOUBLE(inputData->getDynFldStp(), 0);
                break;

            default:
                SYS_BreakOnDebug();
                break;
        }
    }

    sybRetCode = EV_rxaFctStruct.pfn_ct_send_params(this->m_command, CS_UNUSED);

    this->m_lastResultRetCode = this->convertToRetCode(sybRetCode);
    return this->m_lastResultRetCode;
}

RET_CODE SybConnection::doExecuteBatch()
{
    if (this->getCurrProcedure() == nullptr)
    {
        if (this->getBatchMode() == BatchMode::TryBCP)
        {
            RXA_INT outRowNb = 0;

            if (EV_rxaFctStruct.pfn_blk_done(this->m_blkdesc, CS_BLK_ALL, &outRowNb) != CS_SUCCEED)
            {
                DATE_STOP_TIMER(10, TIMER_MASK_DED);
                return(RET_DBA_ERR_INSERT_FAILED);
            }

            MSG_LogSrvMesg(UNUSED, UNUSED, SYS_Stringer("BCP wrote : (%1) saved ", this->m_batchTableSqlName).c_str(), IntType, outRowNb);

            if (EV_rxaFctStruct.pfn_blk_drop(this->m_blkdesc) == CS_FAIL)
            {
                this->m_blkdesc = nullptr;
                return(RET_DBA_ERR_INSERT_FAILED);
            }
            this->m_blkdesc = nullptr;

            return RET_SUCCEED;
        }

        CS_RETCODE sybRetCode = EV_rxaFctStruct.pfn_ct_send(this->m_command);

        SYS_MilliSleep(10); /* PMSTA-34344 - LJE - 201112 - I don't know why, but it seem work with the sleep... else I lost the last record sometimes */

        this->m_batchMp.freeAll();

        if (sybRetCode != CS_SUCCEED && sybRetCode != CS_PENDING)
        {
            SYB_SendSqlTrace(&this->m_sqlTraceStrPtr);
            this->m_lastResultRetCode = RET_DBA_ERR_DBPROBLEM;
            return this->m_lastResultRetCode;
        }

        CS_INT resultType;
        sybRetCode = SYB_CtResults(*this, &resultType);

        if (sybRetCode != CS_SUCCEED || resultType == CS_CMD_FAIL)
        {
            SYB_SendSqlTrace(&this->m_sqlTraceStrPtr);
            this->m_lastResultRetCode = RET_DBA_ERR_DBPROBLEM;
            return this->m_lastResultRetCode;
        }
    }
    else if (this->m_batchStream.str().empty() == false)
    {
        if (this->sendCommand(this->m_batchStream.str()) != RET_SUCCEED)
        {
            this->filterMsgInfos(&this->m_lastResultRetCode);

            if (FALSE == this->cancelDbRequest(COMMAND_LEVEL, CANCEL_ALL))
            {
                if (this->m_lastResultRetCode == RET_SRV_LIB_ERR_DEADLOCK)
                    return(RET_SRV_LIB_ERR_FATAL_DEADLOCK);
            }

            if (this->m_lastResultRetCode == RET_SRV_LIB_ERR_DEADLOCK)
                return this->m_lastResultRetCode;

            return(RET_DBA_ERR_DBPROBLEM);
        }
        this->m_lastResultRetCode = this->processAllBatchResults();


        if (this->m_lastResultRetCode != RET_SUCCEED) /* REF4001 - SSO - 991004 */
        {
            if (this->m_lastResultRetCode == RET_SRV_LIB_ERR_FATAL_DEADLOCK)
            {
                return(this->m_lastResultRetCode);
            }
        }

        this->m_batchStream.str(string());
        this->m_batchStream.clear();
    }

    this->m_lastResultRetCode = RET_SUCCEED;
    return this->m_lastResultRetCode;
}

/************************************************************************
*   Function             :  SybConnection:getColumnCount()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-nuodb - LJE - 190424
*
*   Last Modification    :
*
*************************************************************************/
int SybConnection::getColumnCount()
{
    return 0;
}


/************************************************************************
*   Function             :  SybConnection:getColumnName()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-nuodb - LJE - 190424
*
*   Last Modification    :
*
*************************************************************************/
RET_CODE SybConnection::getColumnName(int colNum, std::string &colName)
{
    return RET_SUCCEED;
}

/************************************************************************
*   Function             :  SybConnection:getColumnType()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-nuodb - LJE - 190424
*
*   Last Modification    :
*
*************************************************************************/
RET_CODE SybConnection::getColumnType(int, CTYPE_ENUM &)
{
    return 0;
}

/************************************************************************
*   Function             :  SybConnection:getPrecision()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-nuodb - LJE - 190424
*
*   Last Modification    :
*
*************************************************************************/
int SybConnection::getPrecision(int)
{
    return 0;
}

/************************************************************************
*   Function             :  SybConnection:getScale()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-nuodb - LJE - 190424
*
*   Last Modification    :
*
*************************************************************************/
int SybConnection::getScale(int)
{
    return 0;
}

/************************************************************************
*   Function             :  SybConnection:getColumnMaxLength()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-nuodb - LJE - 190424
*
*   Last Modification    :
*
*************************************************************************/
int SybConnection::getColumnMaxLength(int)
{
    return 0;
}

/************************************************************************
*   Function             :  SybConnection:getColumnDisplaySize()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-nuodb - LJE - 190424
*
*   Last Modification    :
*
*************************************************************************/
int SybConnection::getColumnDisplaySize(int)
{
    return 0;
}

/************************************************************************
*   Function             :  SybConnection:isBcpAllowed()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37374 - LJE - 201112
*
*   Last Modification    :
*
*************************************************************************/
bool SybConnection::isBcpAllowed()
{
    return true;
}

bool SybConnection::changePassword(const PasswordEncrypted& password)  /* DLA - PMSTA-21596 - 160519 */
{
    return changePassword(this->getDescription().getUser(), password);
}

bool SybConnection::changePassword(const  std::string& user, const PasswordEncrypted& password)
{
    DBA_CONNECT_INFO_STP connectStp = getConnStructPtr();
    char                 buffer[256];
    RET_CODE             ret = RET_SUCCEED;
    DBI_INT              status;
    std::string          maindb;

    GEN_GetApplInfo(ApplSqlDbName, maindb);
    connectStp->passwordChange = true;                                                              /* PMSTA-18094 - 130514 - PMO */
    /* PMSTA-18048 - SHR - 140521 */
    const int len = 1 + sprintf(buffer, "use master "
        "alter login \"%s\" with password \"%s\" modify password \"%s\" use %s ", user.c_str(), this->getSpecification().getCredentials().getPassword().getClearPassword().getPassword() , password.getClearPassword().getPassword(), maindb.c_str());

    const AAALogger& sqlTraceLog = AAALogger::get(AAALogger::Logger::SqlTrace);
    if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
    {
        auto &sqlTrace = this->getSqlTrace();
        sqlTrace.m_procedure = "DynSql.ChangePassword";
    }

    ret = this->sqlExecSt(buffer, &status);

    this->dispAllMsgText();

    DBA_PasswordClear(buffer, sizeof(buffer));                                                      /* PMSTA-18094 - 130514 - PMO */

    connectStp->passwordChange = false;                                                             /* PMSTA-18094 - 130514 - PMO */

    /* Clear the password from Sybase memory */
    sprintf(buffer, "%*s", len, "declare @chk int_t");                              /* PMSTA-18094 - 130514 - PMO */

    if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
    {
        auto &sqlTrace = this->getSqlTrace();
        sqlTrace.m_procedure = "DynSql.ChangePassword";
    }

    ret = this->sqlExecSt(buffer, &status);

    return ret == RET_SUCCEED;
}

void SybConnection::enableOutput()
{
}

void SybConnection::disableOutput()
{
}

/************************************************************************
*   Function             :  SybConnection::setConnMaxRows
*
*   Description          :  Set the max db read nbr value for select in connection
*
*   Arguments            :  max value to read
*
*   Return               :  RET_CODE
*
*   Creation Date        :  DLA - PMSTA-26898 - 17042
*
*************************************************************************/
RET_CODE SybConnection::setConnMaxRows(int maxRow)
{
    return SYB_CtOptions(*this, CS_SET, CS_OPT_ROWCOUNT, (CS_VOID *)&maxRow, CS_UNUSED, NULL);
}

void SybConnection::setDateTimeFormat(DATE_STYLE_ENUM  inDateTimeStyleEn)
{
    if (this->getDescription().getType() == SqlServer)
    {
        string               buffer = "set dateformat ";

        switch (inDateTimeStyleEn)
        {
            case DateStyle_DdMmYyyy:
            case DateStyle_DdMmYy:
                buffer.append("dmy");
                break;

            case DateStyle_YyyyDdMm24:
                buffer.append("ydm");
                break;

            case DateStyle_MmDdYyyy:
            case DateStyle_MmDdYy:
                buffer.append("mdy");
                break;

            default:
                /* Nothing to do */
                return;
        }

        const AAALogger& sqlTraceLog = AAALogger::get(AAALogger::Logger::SqlTrace);
        if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
        {
            auto &sqlTrace = this->getSqlTrace();
            sqlTrace.m_procedure = "DynSql.SetDateTimeFormat";
        }

        (void)this->sqlExecSt(buffer.c_str());
    }
}

void SybConnection::manageError()
{
    if (this->m_msgStack.empty() == false)
    {

    }
}

std::string SybConnection::getDefaultCharset()
{
    auto charSetIt = defaultCharsetMap.find(this->getSpecification().getServerName());
    if (charSetIt == defaultCharsetMap.end())
    {
        std::string defaultCharset;

        SYSNAME_T name;
        SYSNAME_T charset;
        string    text;
        ID_T      retrieved_value = 0;
        CS_INT    resultType = 0;
        RET_CODE  code = RET_SUCCEED;
        CS_INT    status = 0;
        CS_INT    count = 0;

        charset[0] = 0;
        name[0] = 0;

        text = "exec master..sp_configure 'default character set id'";

        if (SYB_CtCommand(*this, DBA_LANG, text.c_str(), NULL) != CS_SUCCEED)
        {
            return defaultCharset;
        }

        if (SYB_CtSend(*this) != CS_SUCCEED)
        {
            return defaultCharset;
        }

        while ((code = SYB_CtResults(*this, &resultType)) == CS_SUCCEED)
        {
            CS_INT    minimum, maximum, config_value, run_value;

            switch (resultType)
            {
                case CS_ROW_RESULT:
                    SYB_ColBind(*this, 1, CS_CHAR_TYPE, name);
                    SYB_ColBind(*this, 2, CS_INT_TYPE, &minimum);
                    SYB_ColBind(*this, 3, CS_INT_TYPE, &maximum);
                    SYB_ColBind(*this, 4, CS_INT_TYPE, &config_value);
                    SYB_ColBind(*this, 5, CS_INT_TYPE, &run_value);

                    while (SYB_CtFetch(*this, CS_UNUSED, CS_UNUSED, CS_UNUSED, &count) == RET_SUCCEED)
                    {
                        if (strncmp(name, "default character set id", 24) == 0)
                        {
                            retrieved_value = (ID_T)run_value;
                        }
                    }

                    break;

                case CS_STATUS_RESULT:
                    SYB_ColBind(*this, 1, CS_INT_TYPE, &status);

                    while (SYB_CtFetch(*this, CS_UNUSED, CS_UNUSED, CS_UNUSED, &count) == RET_SUCCEED)
                        ;

                    break;

                case CS_CMD_SUCCEED:

                    break;

                case CS_CMD_DONE:
                case CS_CMD_FAIL:

                    break;

                default:
                    break;
            }
        }

        /* REF8823 - DDV - 030324 - Load only one charset */
        text = SYS_Stringer("select name from master..syscharsets where id = ", retrieved_value, " and type < 2000 and csid = 0");
        if (SYB_CtCommand(*this, DBA_LANG, text.c_str(), NULL) != CS_SUCCEED)
        {
            return defaultCharset;
        }

        if (SYB_CtSend(*this) != CS_SUCCEED)
        {
            return defaultCharset;
        }

        while ((code = SYB_CtResults(*this, &resultType)) == CS_SUCCEED)
        {
            switch (resultType)
            {
                case CS_ROW_RESULT:

                    SYB_ColBind(*this, 1, CS_CHAR_TYPE, charset);

                    /* Only one row is to be retrieved. */
                    while (SYB_CtFetch(*this, CS_UNUSED, CS_UNUSED, CS_UNUSED, &count) == RET_SUCCEED);

                    defaultCharset = charset;

                    break;

                case CS_STATUS_RESULT:
                    SYB_ColBind(*this, 1, CS_INT_TYPE, &status);

                    while (SYB_CtFetch(*this, CS_UNUSED, CS_UNUSED, CS_UNUSED, &count) == RET_SUCCEED);

                    break;

                case CS_CMD_SUCCEED:
                    break;

                case CS_CMD_DONE:
                case CS_CMD_FAIL:
                    break;

                default:
                    break;
            }
        }

        defaultCharsetMap[this->getSpecification().getServerName()] = defaultCharset;
        return defaultCharset;
    }

    return charSetIt->second;
}

bool SybConnection::isUtf16Allowed()
{
    return this->getDefaultCharset() == "utf8";
}

std::string SybConnection::getConnectionCharset()
{
    CS_LOCALE	*localDefault = nullptr;
    CODE_T      charsetName;

    charsetName[0] = 0;

    if (EV_rxaFctStruct.pfn_cs_loc_alloc((CS_CONTEXT *)SYB_GetCsContext(), &localDefault) == CS_SUCCEED)
    {
        int         charsetNameL = 0;

        SYB_CtConProps(*this, CS_GET, CS_LOC_PROP, localDefault, CS_UNUSED, NULL);
        EV_rxaFctStruct.pfn_cs_locale((CS_CONTEXT *)SYB_GetCsContext(), CS_GET, localDefault, CS_SYB_CHARSET, charsetName, GET_MAXCHARLEN(CodeType), (CS_INT *)&charsetNameL);    /* PMSTA-33077 - DLA - 181012 */
        charsetName[charsetNameL] = END_OF_STRING;
        EV_rxaFctStruct.pfn_cs_loc_drop((CS_CONTEXT *)SYB_GetCsContext(), localDefault);
    }
    return charsetName;
}

RET_CODE SybConnection::setAppContextProperty(const std::string &propertyName, const std::string &propertyValue)
{
    stringstream command;

    CS_INT   type;
    CS_INT   result1 = -1;
    CS_INT   result2 = -1;
    CS_INT   count, status;
    RET_CODE retCode = RET_DBA_ERR_DBPROBLEM;
    NOTE_T   getValue;

    memset(getValue, 0, sizeof(NOTE_T));

    command << "select rm_appcontext('TASC_CONTEXT', '" << propertyName << "')";

    if (propertyValue.empty())
    {
        command << ", 0, ''";
    }
    else
    {
        command
            << ", set_appcontext('TASC_CONTEXT', '" << propertyName << "', '" << propertyValue + "')"
            << ", get_appcontext('TASC_CONTEXT', '" << propertyName  << "')";
    }

    if (SYB_CtCommand(*this, DBA_LANG, command.str().c_str(), NULL) != CS_SUCCEED)
    {
        stringstream msg;
        msg << "Set appContext error for connection=" << this->getId() << ", Properties=" << propertyName << ", Value=" << propertyValue;
        MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, msg.str().c_str());
        return RET_DBA_ERR_DBPROBLEM;
    }

    SYB_CtSend(*this);

    while (SYB_CtResults(*this, &type) == CS_SUCCEED)
    {
        switch (type)
        {
            case CS_ROW_RESULT:
                SYB_ColBind(*this, 1, CS_INT_TYPE, &result1);
                SYB_ColBind(*this, 2, CS_INT_TYPE, &result2);
                SYB_ColBind(*this, 3, CS_CHAR_TYPE, getValue);	/* PMSTA-24260 - TEB - 160804 */

                while (SYB_CtFetch(*this, CS_UNUSED, CS_UNUSED, CS_UNUSED, &count) == RET_SUCCEED)
                    ;

                if (propertyValue.empty())
                {
                    if (result1 == -1)
                    {
                        stringstream msg;
                        msg << "Remove appContext error for connection=" << this->getId() << ", Properties=" << propertyName;
                        MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, msg.str().c_str());
                        retCode = RET_SUCCEED; /* if the rm is not working an error will be raised on NEW else the appContext was not set*/
                    }
                    else
                    {
                        retCode = RET_SUCCEED;
                    }
                }
                else
                {
                    if (result2 == 0 && propertyValue.compare(getValue) == 0)
                    {
                        retCode = RET_SUCCEED;
                    }
                    else
                    {
                        stringstream msg;
                        msg << "Set appContext error for connection=" << this->getId() << ", Properties=" << propertyName << ", Value=" << propertyValue;
                        MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, msg.str().c_str());
                        retCode = RET_DBA_ERR_DBPROBLEM;
                    }
                }

                break;

            case CS_STATUS_RESULT: /* Maybe useless to remove in this case */
                SYB_ColBind(*this, 1, CS_INT_TYPE, &status);

                while (SYB_CtFetch(*this, CS_UNUSED, CS_UNUSED, CS_UNUSED, &count) == RET_SUCCEED)
                    ;

                break;

            default:
                break;
        }
    }

    if (this->cancelDbRequest(COMMAND_LEVEL, CANCEL_ALL) == FALSE)
    {
        stringstream msg;
        msg << "Set appContext error for connection=" << this->getId() << ", Properties=" << propertyName << ", Value=" << propertyValue;
        MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, msg.str().c_str());
        retCode = RET_DBA_ERR_DBPROBLEM;
    }
    return retCode;
}

RET_CODE SybConnection::prepareReceivedData()
{
    this->m_resultSetPos = 0;
    return RET_SUCCEED;
}

RET_CODE SybConnection::colBind(int colNum, 
                                DATATYPE_ENUM type, 
                                const std::string &, 
                                DBI_PTR dataPtr, 
                                size_t allocSize, 
                                DBI_INT *dataLength, 
                                DBI_SMALLINT *nullData,
                                bool dynFldFlag, 
                                unsigned char * nullIndicatorDynFld,
                                DbiInOutData* dbiInOutDataPtr)
{
    RET_CODE ret = RET_SUCCEED;
    CS_INT csType;

    /* PMSTA-27630 - TEB - 170627 */
    if (type == DateType || type == DatetimeType)
    {
        csType = CS_FLOAT_TYPE;
    }
    else
    {
        csType = SYB_GetSybTypeByCType(type);
    }

    ret = SYB_ColBind(*this, colNum, csType, dataPtr, dataLength, nullData);

    return ret;
}

RET_CODE SybConnection::fetch()
{
    RET_CODE retCode = this->bindRequestOutput();

    if (retCode != RET_SUCCEED)
    {
        return retCode;
    }

    /* Retrieve a row returned by the server */
    retCode = SYB_CtFetch(*this, CS_UNUSED, CS_UNUSED, CS_UNUSED, NULL);

    if (retCode == RET_DBA_INFO_NO_MORE_DATA)
    {
        this->m_lastResultType = CS_CMD_SUCCEED;
    }

    return(retCode);
}

RET_CODE SybConnection::getNextResultSet()
{
    this->m_resultSetPos++;

    CS_RETCODE sybRetCode = SYB_CtResults(*this, (CS_INT*)&this->m_lastResultType);
    if (sybRetCode != CS_SUCCEED)
    {
        this->m_lastResultRetCode = this->convertToRetCode(sybRetCode);
        return this->m_lastResultRetCode;
    }

    if (this->m_lastResultType != CS_CMD_DONE)
    {
        return(RET_DBA_INFO_NO_MORE_DATA);
    }

    SYB_CtResults(*this, (CS_INT*)&this->m_lastResultType);

    if (this->m_lastResultType != CS_ROW_RESULT)
    {
        if (this->m_lastResultType == 0)
        {
            this->m_lastResultType = CS_CMD_DONE;
        }

        return(RET_DBA_INFO_NO_MORE_DATA);
    }

    return(RET_SUCCEED);

}

/************************************************************************
*   Function             : SybConnection::setOneParameter()
*
*   Description          : Save the necessary parameters for the request
*                          in the CS_COMMAND structure
*
*   Arguments            :
*
*   Functions call       : None
*
*   Global var. modified : None
*
*   Return               : RET_SUCCEED            : if ok
*                          RET_DBA_ERR_ARGNOMATCH : if argument problem
*                          RET_DBA_ERR_SETPARAM   : if problem while binding fields
*
*
*************************************************************************/
RET_CODE SybConnection::setOneParameter(DbiInOutData      *inputData,
                                        const std::string &paramName,
                                        bool               isOutputParam,
                                        CS_DATAFMT        &csDataFmt)
{
    CS_DATETIME       datetime;
    CS_DATETIME4      datetimeSmall;
    INT_T             thirdSecond;
    SMALLINT_T        minutes;
    DBA_DYNSTDEF_STP  inputArg = NULL;
    CS_RETCODE        sybRetCode;
    long              daysNbr = 0;
    DATE_T            refDate;
    HOUR_T            hour;
    MINUTE_T          min;
    SECOND_T          second;
    DATATYPE_ENUM     fieldType;


    /* Init local variables */
    memset(&csDataFmt, 0, sizeof(csDataFmt));

    if (isOutputParam)
        csDataFmt.status = CS_RETURN;
    else
        csDataFmt.status = CS_INPUTVALUE;

    csDataFmt.namelen = CS_NULLTERM;

    strcpy(csDataFmt.name, paramName.c_str());

    fieldType = inputData->m_dataType;
    csDataFmt.datatype = SYB_ConvApplToSybType(fieldType);

    if ((csDataFmt.datatype == CS_TEXT_TYPE) && this->getDescription().getType() != SqlServer)
    {
        csDataFmt.datatype = CS_LONGCHAR_TYPE;
    }

    if (csDataFmt.datatype == CS_NUMERIC_TYPE)
    {
        if (fieldType == IdType || fieldType == DictType || fieldType == LongintType)
        {
            sybRetCode = SYB_ConvertFldToNumericAndSetParam(*this, fieldType,
                (double)inputData->getDataPtr()->longlongValue, csDataFmt);
        }
        else
        {
            sybRetCode = SYB_ConvertFldToNumericAndSetParam(*this, fieldType,
                                                            inputData->getDataPtr()->dbleValue, csDataFmt);
        }

        if (sybRetCode != RET_SUCCEED)
            return(RET_DBA_ERR_SETPARAM);

        return RET_SUCCEED;
    }
    else
    {
        csDataFmt.precision = 18;
        csDataFmt.scale = 0;
    }


    if (fieldType == FlagType && inputData->isNull())
    {
        SET_FLAG_FALSE(inputData->getDynFldStp(), 0);
    }

    /* If the current field has a NULL value */
    if (inputData->isNull())
    {
        sybRetCode = SYB_CtParam(*this, &csDataFmt, NULL, 0, -1);

        if (sybRetCode != CS_SUCCEED)
        {
            return(RET_DBA_ERR_SETPARAM);
        }

    }
    else
    {
        switch (csDataFmt.datatype)
        {
            case CS_DATETIME_TYPE:
            case CS_DATETIME4_TYPE:
                /* Compose the Sybase reference date (1 jan 1900) */
                refDate = DATE_Put((YEAR_T)1900, (MONTH_T)1, (DAY_T)1);

                thirdSecond = 0;
                minutes = 0;

                switch (fieldType)
                {
                    case DateType:
                        DATE_DaysBetween(refDate, GET_DATE(inputData->getDynFldStp(), 0), AccrRule_Actual_365, &daysNbr, 0);
                        break;

                    case DatetimeType:
                    {
                        DATETIME_ST datetimeSt = GET_DATETIME(inputData->getDynFldStp(), 0);
                        DATE_DaysBetween(refDate, datetimeSt.date, AccrRule_Actual_365, &daysNbr, 0);
                        TIME_Get(datetimeSt.time, &hour, &min, &second);
                        thirdSecond = (INT_T)(hour * 3600 + min * 60 + second) * 300;
                    }
                    break;

                    default:
                        break;
                }

                if (csDataFmt.datatype == CS_DATETIME_TYPE)
                {
                    datetime.dtdays = daysNbr;
                    datetime.dttime = thirdSecond;

                    sybRetCode = SYB_CtParam(*this, &csDataFmt, &datetime, CS_UNUSED, CS_UNUSED); /* REF3847 */
                }
                else
                {    /* Short date case */
                    datetimeSmall.days = (unsigned short)daysNbr;
                    datetimeSmall.minutes = minutes;

                    sybRetCode = SYB_CtParam(*this, &csDataFmt, &datetimeSmall, CS_UNUSED, CS_UNUSED); /* REF3847 */
                }

                break;

            case CS_CHAR_TYPE:
            case CS_LONGCHAR_TYPE: /* DLA - PMSTA07121 - 090213 */
            case CS_TEXT_TYPE:
                csDataFmt.maxlength = GET_FLD_STRLEN(inputData->getDynFldStp(), 0);
                sybRetCode = SYB_CtParam(*this, &csDataFmt, inputData->getDynFldStp()->data.strData.ptr,
                                         GET_FLD_STRLEN(inputData->getDynFldStp(), 0),
                                         CS_UNUSED);               /* REF3847 */
                break;

            case CS_UNICHAR_TYPE:
            case CS_UNITEXT_TYPE:
                csDataFmt.maxlength = GET_FLD_USTRLEN(inputData->getDynFldStp(), 0) * 2;
                sybRetCode = SYB_CtParam(*this, &csDataFmt, inputData->getDynFldStp()->data.strData.ptr,
                                         GET_FLD_USTRLEN(inputData->getDynFldStp(), 0) * 2,
                                         CS_UNUSED);               /* REF3847 */
                break;

            case CS_BINARY_TYPE:  /* REF11780 - 100406 - PMO */
            {
                CS_DATAFMT  csDataFmtSource;
                CS_BINARY   sybaseTimeStamp[8];

                memset(&csDataFmtSource, 0, sizeof(csDataFmtSource));
                csDataFmtSource.datatype = CS_USER_TIMESTAMP;
                csDataFmtSource.maxlength = sizeof(TIMESTAMP_T);
                csDataFmtSource.status = csDataFmt.status | CS_DESCIN;

                csDataFmt.precision = 0;
                csDataFmt.scale = 0;
                csDataFmt.maxlength = sizeof(TIMESTAMP_T);
                csDataFmt.status |= CS_TIMESTAMP;

                sybRetCode = EV_rxaFctStruct.pfn_cs_convert(SYB_GetCsContext(),
                                                            &csDataFmtSource,
                                                            &(inputData->getDynFldStp()->data.timeStampValue),
                                                            &csDataFmt,
                                                            &sybaseTimeStamp,
                                                            NULL);

                if (sybRetCode != CS_SUCCEED)
                {
                    return(RET_DBA_ERR_SETPARAM);
                }

                sybRetCode = SYB_CtParam(*this, &csDataFmt, &sybaseTimeStamp, sizeof(sybaseTimeStamp), CS_UNUSED);
            }
            break;

            default:
                sybRetCode = SYB_CtParam(*this, &csDataFmt, inputData->getDataPtr(), sizeof(inputArg[0]), CS_UNUSED);     /* REF3847 */
                break;
        }

    }

    if (sybRetCode != CS_SUCCEED)
    {
        return(RET_DBA_ERR_SETPARAM);
    }

    return (RET_SUCCEED);
}

/************************************************************************
*   Function             :  SybConnection::setParameters
*
*   Description          :
*
*   Arguments            :
*
*   Return               :  RET_CODE
*
*   Creation Date        :
*
*************************************************************************/
RET_CODE SybConnection::setParameters(char **sqlTraceStrPtr)
{
    this->m_lastResultRetCode = RET_SUCCEED;

    /* For MultiAccess output parameters*/
    if (this->getRequestParamMap().empty() == false)
    {
        int i = 1;
        for (auto dynFldIt = this->getRequestParamMap().begin(); dynFldIt != this->getRequestParamMap().end(); ++dynFldIt)
        {
            CS_DATAFMT      csDataFmt;
            string          paramName = (this->m_mode == DBA_LANG ? SYS_Stringer("@", i++) : dynFldIt->second->m_sqlName);
            bool            bOutput = (this->m_mode == DBA_LANG ? false : dynFldIt->second->m_bOutput);

            if (SYB_DefineCtParam(*this,
                                  dynFldIt->second,
                                  paramName,
                                  bOutput,
                                  csDataFmt,
                                  dynFldIt == this->getRequestParamMap().begin(),
                                  sqlTraceStrPtr) != RET_SUCCEED)
            {
                SYB_SendSqlTrace(sqlTraceStrPtr);
                return(RET_DBA_ERR_SETPARAM);
            }
        }
    }

    return this->m_lastResultRetCode;
}

RET_CODE SybConnection::copyNullFlagsAndLengthDynSt(DBA_DYNFLD_STP bindData, DBA_DYNST_ENUM dynStEnum)
{
    return SYB_CopyNullFlagsAndLengthDynSt(*this, bindData, dynStEnum);
}

RET_CODE SybConnection::processAllResults(DBI_INT       *status,
                                          OBJECT_ENUM    object,
                                          DBA_DYNST_ENUM dynSt ,
                                          DBA_DYNFLD_STP record,
                                          DBA_PROC_STP   procedure)
{
    /* REF3749 - SSO - 990703 verify if a fatal error occurred */
    int lastSybClSeverity = this->getLastSybClSeverity();                 /* PMSTA-32315 - 260718 - PMO */

    if (lastSybClSeverity == CS_SV_INTERNAL_FAIL || lastSybClSeverity == CS_SV_FATAL)
    {
        SYS_SetProgramState(ProgramState::ShutdownThreadTerminating);           /* PMSTA-31144 - 170518 - PMO */
        DBA_DeleteApplSessionOnExit(AppSessionInvalidationNat_Unexpected_exit); /* PMSTA-22549 - CHU - 160603 */

        /* must exit!!! */
        EV_rxaFctStruct.pfn_ct_exit(EV_ApplContext, CS_FORCE_EXIT);

        /* REF6059 - PMO. change error message */
        MSG_LogSrvMesg(UNUSED, UNUSED, "Serious error received from Sybase data server. The Triple'A application will be shutdown (exit).");
        SYS_Shutdown(EXIT_FAILURE);       /* DLA - PMSTA-26546 - 170314 */
    }
    else
    {
        /* OK */
        this->resetLastSybClSeverity();                                   /* PMSTA-32315 - 260718 - PMO */
    }

    CS_COMMAND *    csCommand = this->m_command;

    if (this->m_lastResultType == CS_ROW_RESULT)
    {
        while (this->fetch() == RET_SUCCEED)
        {
        }
    }

    if (this->m_lastResultType != CS_CMD_DONE &&
        this->m_lastResultType != 0)
    {
        if (this->m_lastResultType != CS_STATUS_RESULT &&
            this->m_lastResultType != CS_PARAM_RESULT)
        {
            DBI_INT resultType = 0;
            SYB_CtResults(*this, &resultType);
            this->m_lastResultType = resultType;
        }

        DATE_START_TIMER(1, TIMER_MASK_SQLC);

        do
        {
            switch (this->m_lastResultType)
            {
                case CS_CMD_DONE:
                case CS_CMD_FAIL:
                case CS_CMD_SUCCEED:
#ifdef AAADEBUG
                    CS_INT          rowcount;
                    if (TLS_Return(0))
                        EV_rxaFctStruct.pfn_ct_res_info(csCommand, CS_ROW_COUNT, &rowcount, CS_UNUSED, NULL);
#endif
                    break;

                case CS_PARAM_RESULT:
                    SYB_ProcessParamResult(*this, object, dynSt, record, procedure);/* PMSTA08801 - DDV - 091126 */
                    break;

                case CS_ROW_RESULT:
                    return RET_SUCCEED;
                    break;

                case CS_STATUS_RESULT:
                {
                    CS_DATAFMT      csDataFmt; /* DLA - REF9089 - 030903 */

                    if (EV_rxaFctStruct.pfn_ct_describe(csCommand, 1, &csDataFmt) == CS_SUCCEED) /* DLA - REF9089 - 030903 */
                    {
                        /* PMSTA08801 - DDV - 091207 - Sybase's return status is always int.
                        The status is no more used to return id, now output parameters are used */
                        if (csDataFmt.precision == 12 && csDataFmt.scale == 0 && csDataFmt.datatype == CS_NUMERIC_TYPE)
                            assert(1 == 2);
                    }
                    else
                        return(RET_DBA_ERR_DBPROBLEM);

                    /* Bind application status with returned value */
                    const int type = CS_INT_TYPE;           /* DLA - REF9089 - 030903 */

                    SYB_ColBind(*this, 1, type, status);  /* DLA - REF9089 - 030903 */

                    /* Retrieve the value and store it into status */
                    this->fetch();

                    while (this->fetch() == TRUE)
                        ;
                }
                break;

                case CS_COMPUTE_RESULT:
                case CS_CURSOR_RESULT:
                case CS_COMPUTEFMT_RESULT:
                case CS_ROWFMT_RESULT:
                case CS_MSG_RESULT:
                case CS_DESCRIBE_RESULT:
                    break;
            }
        } while (SYB_CtResults(*this, &this->m_lastResultType) == CS_SUCCEED); /* PMSTA08801 - DDV - 091207 - Code moved to avoid duplicate code for status results */
    }

    DATE_STOP_TIMER(1, TIMER_MASK_SQLC);

    return(this->releaseCommand());
}

/************************************************************************
*   Function             : SybConnection::processAllBatchResults()
*
*   Description          : Read all pending results or status after a request.
*
*   Arguments            : 
*
*   Global var. modified : None
*
*   Return               :
*
*   Creation date        :
*
*   Last Modif. Date     : 
*
*************************************************************************/
RET_CODE SybConnection::processAllBatchResults()
{
    RET_CODE                result = RET_SUCCEED;

    int lastSybClSeverity = this->getLastSybClSeverity();
    if (lastSybClSeverity == CS_SV_INTERNAL_FAIL || lastSybClSeverity == CS_SV_FATAL)
    {
        DBA_DeleteApplSessionOnExit(AppSessionInvalidationNat_Unexpected_exit);

        /* must exit!!! */
        EV_rxaFctStruct.pfn_ct_exit(SYB_GetCsContext(), CS_FORCE_EXIT);

        MSG_LogSrvMesg(UNUSED, UNUSED, "Serious error received from Sybase dataserver. The application will be shutdown (exit).");

        SYS_Shutdown(EXIT_FAILURE);        /* DLA - PMSTA-26546 - 170314 */
    }
    else
    {
        /* OK */
        this->resetLastSybClSeverity();
    }

    CS_INT lastResultType = this->m_lastResultType;
    
    INT_T rowNum = 0;

    do
    {
        switch (lastResultType)
        {
            case CS_CMD_SUCCEED:
            case CS_COMPUTE_RESULT:
            case CS_CURSOR_RESULT:
            case CS_COMPUTEFMT_RESULT:
            case CS_ROWFMT_RESULT:
            case CS_MSG_RESULT:
            case CS_DESCRIBE_RESULT:
                break;

            case CS_CMD_DONE:
                break;

            case CS_ROW_RESULT:
                break;

            case CS_CMD_FAIL:
                result = RET_SRV_LIB_ERR_COMMAND_ABORTED;
                break;

            case CS_PARAM_RESULT:
            {
                int             colNumber = 0;

                EV_rxaFctStruct.pfn_ct_res_info(this->m_command, CS_NUMDATA, &colNumber, CS_UNUSED, NULL);

                if (colNumber > 0)
                {
                    int i = 0;
                    for (auto &it : this->getRequestParamMap())
                    {
                        if (it.second->m_bOutput)
                        {
                            CS_DATAFMT      csDataFmt;

                            /* ct_describe to get a description of the parameter */
                            if (EV_rxaFctStruct.pfn_ct_describe(this->m_command, i + 1, &csDataFmt) == CS_SUCCEED)
                            {
                                SYB_BindRecvDynFld(it.second->getDynFldStp(),
                                                   i,
                                                   it.second->m_dataType,
                                                   i + 1,
                                                   &(it.second->m_nullInd),
                                                   &(it.second->m_dataLength),
                                                   this->m_command,
                                                   csDataFmt,
                                                   FALSE);
                            }
                        }
                    }

                    if (this->fetch() == TRUE)
                    {
                        for (auto &it : this->getRequestParamMap())
                        {
                            if (it.second->m_bOutput)
                            {
                                DbiBatchOutput newBatchOutput;

                                newBatchOutput.rowNum = rowNum++;

                                switch (it.second->m_dataType)
                                {
                                    case IdType:
                                    case DictType:
                                        newBatchOutput.id = GET_ID(it.second->getDynFldStp(), 0);
                                        break;

                                    case TimeStampType:
                                        newBatchOutput.rowVersion = GET_TIMESTAMP(it.second->getDynFldStp(), 0);
                                        break;

                                    default:
                                        SYS_BreakOnDebug();
                                        break;
                                }

                                this->getSqlRequest().m_batchOutputSet.insert(newBatchOutput);
                            }
                        }
                    }

                    while (this->fetch() == TRUE)
                        ;
                }
            }
            break;

            case CS_STATUS_RESULT:
            {
                DBA_ACTION_ENUM action = this->getCurrProcedure()->action;

                /* Bind application status with returned value */
                CS_INT status = 0;
                SYB_ColBind(*this, 1, CS_INT_TYPE, &status);

                /* Retrieve the value and store it into status */
                this->fetch();

                while (this->fetch() == TRUE)
                    ;

                if (this->m_msgStack.size() > 0)
                {
                    this->filterMsgInfos(&result);

                    if (action == InsUpd && result == RET_SRV_LIB_ERR_DUPLICATEKEY)
                    {
                        result = RET_SUCCEED;
                        break;
                    }

                    result = (result == RET_SRV_LIB_ERR_DEADLOCK)
                        ? RET_SRV_LIB_ERR_DEADLOCK
                        : RET_DBA_ERR_DBPROBLEM;

                }
                else
                {
                    if (status > 1)
                    {
                        assert(147 == 8801);
                    }
                    this->m_msgStack.clear();
                }
            }
            break;

            default:
                break;
        }
    } while ((SYB_CtResults(*this, &lastResultType)) == CS_SUCCEED);

    if (this->cancelDbRequest(COMMAND_LEVEL, CANCEL_ALL) == FALSE)
    {
        if (result == RET_SRV_LIB_ERR_DEADLOCK)
        {
            result = RET_SRV_LIB_ERR_FATAL_DEADLOCK;    /* REF3685 */
        }
    }

    return(result);
}


/************************************************************************
*   Function             : SybConnection::cancelDbRequest
*
*   Description          : Cancel all results pending
*
*   Arguments            : connectNo : a connection number in the connection
*                                      list
*                          level     : CONNECTION_LEVEL or COMMAND_LEVEL
*                          mode      : CANCEL_CURRENT or CANCEL_ATTN or
*                                      CANCEL_ALL
*
*   Functions call       : None
*
*   Global var. modified : None
*
*   Return               : TRUE if ok
*                          FALSE if problem
*
*   Creation date        : Juil. 94 - PEC
*
*   Last Modif. Date     :
*
*************************************************************************/
RET_CODE SybConnection::cancelDbRequest(int level, int mode)
{
    CS_RETCODE      sybRetCode = CS_SUCCEED;
    std::string     errMsg;                                   /* PMSTA-24981 - 151116 - PMO */

    if (((level != CONNECTION_LEVEL) && (level != COMMAND_LEVEL)) ||
        ((mode != CANCEL_CURRENT) && (mode != CANCEL_ATTN) && (mode != CANCEL_ALL)))
    {
        if ((SYS_IsGuiMode() == TRUE) || (SERVER_IS_INIT() == TRUE))
        {
            SYS_StringFormat(errMsg,
                             "Connection (" szFormatPointer "), thread (%s), level (%s), mode (%s)",                                                                             /* PMSTA-16124 - 250413 - PMO */
                             (void*)this->getConnStructPtr(),                                                                                                                  /* PMSTA-16124 - 250413 - PMO */
                             SYS_GetThreadDescriptionForLog().c_str(),                                                                                                           /* PMSTA-24981 - 151116 - PMO */
                             (level == CONNECTION_LEVEL) ? "Connection" :
                             (level == COMMAND_LEVEL) ? "Command" :
                             "Unknown",
                             (mode == CANCEL_CURRENT) ? "Cancel current" :
                             (mode == CANCEL_ATTN) ? "Cancel attn" :
                             (mode == CANCEL_ALL) ? "Cancel all" :
                             "Unknown");

            MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "SYB_CtCancel", errMsg.c_str());
        }
        else
        {
            SYS_StringFormat(errMsg,
                             "SYB_CtCancel. Invalid argument. Connection (" szFormatPointer "), thread (%s), level (%s), mode (%s)",                                             /* PMSTA-16124 - 250413 - PMO */
                             (void*)this->getConnStructPtr(),                                                                                                                  /* PMSTA-16124 - 250413 - PMO */
                             SYS_GetThreadDescriptionForLog().c_str(),                                                                                                           /* PMSTA-24981 - 151116 - PMO */
                             (level == CONNECTION_LEVEL) ? "Connection" :
                             (level == COMMAND_LEVEL) ? "Command" :
                             "Unknown",
                             (mode == CANCEL_CURRENT) ? "Cancel current" :
                             (mode == CANCEL_ATTN) ? "Cancel attn" :
                             (mode == CANCEL_ALL) ? "Cancel all" :
                             "Unknown");

            MSG_SendStrToLog(errMsg);
        }

        return(RET_GEN_ERR_INVARG);
    }

    int             csConnectNo  = this->getId(); /* DLA - 040109 */
    CS_CONNECTION * csConnection = this->m_connection;
    CS_COMMAND *    csCommand    = this->m_command;

    this->m_currentCmd = Syb_Command_Cancel; /* Keep trace of the current command. */


    if ((sybRetCode = EV_rxaFctStruct.pfn_ct_cancel((level == CONNECTION_LEVEL) ? csConnection : NULL,
        (level == COMMAND_LEVEL) ? csCommand : NULL,
                                                    (mode == CANCEL_CURRENT) ? CS_CANCEL_CURRENT :
                                                    (mode == CANCEL_ATTN) ? CS_CANCEL_ATTN :
                                                    CS_CANCEL_ALL)) != CS_SUCCEED)
    {
        SYS_StringFormat(errMsg,
                         "Call to ct_cancel failed. Connection (" szFormatPointer "), Command (" szFormatPointer "), Connection (%d), Mode (%s), Status (%s), Thread (%s)",      /* PMSTA-16124 - 250413 - PMO */
                         (void*)csConnection,                                                                                                                                    /* PMSTA-16124 - 250413 - PMO */
                         (void*)csCommand,                                                                                                                                       /* PMSTA-16124 - 250413 - PMO */
                         csConnectNo,
                         (mode == CANCEL_CURRENT) ? "Cancel current" :
                         (mode == CANCEL_ATTN) ? "Cancel attn" :
                         "Cancel all",
                         this->getLabelRetCode(sybRetCode).c_str(),                                                                                                      /* PMSTA-24981 - 151116 - PMO */

                         SYS_GetThreadDescriptionForLog().c_str());                                                                                                              /* PMSTA-24981 - 151116 - PMO */

        this->sendMsg(FILEINFO, errMsg);
    }


    this->m_currentCmd = Syb_Command_None;


    /***** SQL TRACE *****/
    if (EV_sqlFile != NULL)
    {
        SYS_StringFormat(errMsg,
                         "    ct_cancel()     %-12.12s Connect=%-9d CsCmd=" szFormatPointer " CsCon=" szFormatPointer " Type=%s Thread=",                                        /* PMSTA-16124 - 250413 - PMO */
                         this->getLabelRetCode(sybRetCode).c_str(),                                                                                                      /* PMSTA-24981 - 151116 - PMO */
                         csConnectNo,
                         (void*)csCommand,                                                                                                                                       /* PMSTA-16124 - 250413 - PMO */
                         (void*)csConnection,                                                                                                                                    /* PMSTA-16124 - 250413 - PMO */
                         (mode == CS_CANCEL_CURRENT) ? "CANCEL_CURRENT" :
                         (mode == CS_CANCEL_ATTN) ? "CANCEL_ATTN" :
                         "CANCEL_ALL");

        errMsg += SYS_GetThreadDescriptionForLog();                                                                                                                             /* PMSTA-24981 - 151116 - PMO */

        MSG_SendSqlTrace(errMsg.c_str());
    }


    this->m_resultSetPos = -1;

    return (sybRetCode == CS_SUCCEED ? RET_SUCCEED : RET_DBA_ERR_DBPROBLEM);
}


/************************************************************************
**
**  Function    :   SybConnection::disableIdentity()
**
**  Description :
**
**  Argument    :
**
**
**  Return      :
**
**  Creation    :
**
**  Last modif. :
**
*************************************************************************/
RET_CODE SybConnection::disableIdentity(std::string database, std::string table)
{
    DbiConnection::disableIdentity(database, table);

    RET_CODE ret = RET_SUCCEED;

    ret = this->useDb(database);

    if (ret == RET_SUCCEED)
    {
        std::stringstream insStream;
        insStream << "set identity_insert " << table << " on";

        RequestHelper requestHelper(this);
        requestHelper.setReadOnly(true);
        requestHelper.setCommand(insStream.str());
        ret = requestHelper.sendAndGetCommand();
    }

    if (ret == RET_SUCCEED)
    {
        this->m_disableIdentitySet.insert(make_pair(database, table));
    }
    return ret;
}

/************************************************************************
**
**  Function    :   SybConnection::enableIdentity()
**
**  Description :
**
**  Argument    :
**
**
**  Return      :
**
**  Creation    :
**
**  Last modif. :
**
*************************************************************************/
RET_CODE SybConnection::enableIdentity(std::string database, std::string table)
{
    DbiConnection::enableIdentity(database, table);

    RET_CODE ret = RET_SUCCEED;

    ret = this->useDb(database);

    if (ret == RET_SUCCEED)
    {
        std::stringstream insStream;
        insStream << "set identity_insert " << table << " off";

        RequestHelper requestHelper(this);
        requestHelper.setReadOnly(true);

        requestHelper.setCommand(insStream.str());
        ret = requestHelper.sendAndGetCommand();
    }

    if (ret == RET_SUCCEED)
    {
        this->m_disableIdentitySet.erase(make_pair(database, table));
    }
    return ret;
}


/************************************************************************
**
**  Function    :   SybConnection::getTransStat()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-25371 - LJE - 161129
**
*************************************************************************/
int SybConnection::getTransState()
{
    CS_RETCODE      code;
    CS_INT          count;
    CS_INT          status;
    CS_RETCODE      resultType;
    FLAG_T          cmdFailed = FALSE;

    stringstream    ddlObjText;
    stringstream    cmd;

    int             transstate = 0;

    cmd << "select get_trans_state()";

    if (SYB_CtCommand(*this, DBA_LANG, cmd.str().c_str(), NULL) != CS_SUCCEED)
    {
        return FALSE;
    }

    if (SYB_CtSend(*this) != CS_SUCCEED)
    {
        return FALSE;
    }

    while ((code = SYB_CtResults(*this, &resultType)) == CS_SUCCEED)
    {
        switch (resultType)
        {
            case CS_ROW_RESULT:
                SYB_ColBind(*this, 1, CS_INT_TYPE, &transstate);

                while (SYB_CtFetch(*this, CS_UNUSED, CS_UNUSED, CS_UNUSED, &count) == RET_SUCCEED)
                {
                }

                break;

            case CS_STATUS_RESULT:
                SYB_ColBind(*this, 1, CS_INT_TYPE, &status);

                while (SYB_CtFetch(*this, CS_UNUSED, CS_UNUSED, CS_UNUSED, &count) == RET_SUCCEED)
                    ;

                break;

            case CS_CMD_SUCCEED:
                break;

            case CS_CMD_DONE:
                break;
            case CS_CMD_FAIL:

                break;

            default:
                break;
        }
    }

    /* Cancel all pending results */
    if (this->cancelDbRequest(COMMAND_LEVEL, CANCEL_ALL) == FALSE)
    {
        return(FALSE);
    }

    if (code != CS_END_RESULTS || cmdFailed == TRUE)
    {
        char buffer[100];
        sprintf(buffer, "Unable to get transaction state");
        MSG_DispMsgText(RET_SUCCEED, buffer);
        return FALSE;
    }

    return transstate;
}


RET_CODE SybConnection::getLastCmdRetCode()
{
    return this->m_msgErrorHelper.getRetCode(static_cast<SYB_ERROR_CODE_ENUM>(this->m_msgStack.lastMsgNb));
}


RET_CODE SybConnection::getCmdRetCode(int msgIdx)
{
    if (msgIdx < this->m_msgStack.size())
    {
        return this->m_msgErrorHelper.getRetCode(static_cast<SYB_ERROR_CODE_ENUM>(this->m_msgStack.getMember(msgIdx).rdbmsMsgNb));
    }
    return RET_SUCCEED;
}

bool SybConnection::isSamePasswordMsg()
{
    if (this->m_msgStack.size() == 2 &&  /* PMSTA-13926 */
        this->m_msgStack.getMember(0).msgOrigin == ServerHandler &&
        this->m_msgStack.getMember(0).rdbmsMsgNb == 10316 && /* New password supplied is the same as the previous password. Please supply a different new password. */
        this->m_msgStack.getMember(1).msgOrigin == ServerHandler &&
        (this->m_msgStack.getMember(1).rdbmsMsgNb == 17720 || this->m_msgStack.getMember(1).rdbmsMsgNb == 11188))   /* PMSTA-18048 - DDV - 140602 - Fix user import error */
    {
        return true;

    }
    return false;
}

bool SybConnection::isWarningMsgToHide(const DbaErrmsgInfosClass &msgStructSt)
{
    if (msgStructSt.rdbmsMsgNb == 1918  || /* Non-clustered index (index id = xxx) is being rebuilt. */
        msgStructSt.rdbmsMsgNb == 13900 || /* Warning: a default (object id xxx) is defined on column 'xxx' being modified. Check the validity of the default value after this ALTER TAB */
                                             /* Warning: column 'xxx' is referenced by one or more rules or constraints. Verify the validity of the rules/constraints after this ALTER TABLE operation. */
        msgStructSt.rdbmsMsgNb == 13937 || /* Warning: The schema for table 'xxx' has changed. Drop and re-create each trigger on this table that uses the 'if update(column-name)' clause.*/
        msgStructSt.rdbmsMsgNb == 13904 || /* Warning: A logical RI constraint, using sp_primarykey/sp_foreignkey exists on column %.*s being modified. Verify the validity of the logical RI constraint after this ALTER TABLE operation. */
        msgStructSt.rdbmsMsgNb == 13925 || /* Warning: ALTER TABLE operation did not affect column '...'. */
        msgStructSt.rdbmsMsgNb == 13913 || /* Warning: column %.*s is referenced by one or more rules or constraints. Verify the validity of the rules/constraints after this ALTER TABLE operation. */
        msgStructSt.rdbmsMsgNb == 1708  || /* Warning: Row size (xxx bytes) could exceed row size limit, which is xxx bytes.  */ /* PMSTA-32604 - TEB - 180817 */
        msgStructSt.rdbmsMsgNb == 1768  || /* Warning: Potential offset of column %.*s (%d bytes) and subsequent variable-length columns in table %.*s exceeds limit of %d bytes for column-offset of variable-length columns in DOL tables. Future inserts to this table may fail. */
        msgStructSt.rdbmsMsgNb == 1771  || /* Warning: Maximum row size exceeds allowable width. It is being rounded down to %d bytes. */
        msgStructSt.rdbmsMsgNb == 4985)    /* Warning: trigger '%.*s' is already enabled. */
    {
        return true;
    }
    return false;
}

bool SybConnection::convParamFromPos(std::string &allParam, std::string::size_type &posParam, int paramNbr, const std::string& paramName)
{
    SYSNAME_T conStr;
    sprintf(conStr, "@%d", paramNbr);
    allParam.replace(posParam, paramName.size(), conStr);
    posParam += strlen(conStr);

    if (this->getCurrentAction() == Custom &&
        static_cast<int>(this->getRequestParamMap().size()) >= paramNbr &&
        this->getRequestParamMap()[paramNbr - 1]->m_bOutput)
    {
        allParam.replace(posParam, 0, " output");
    }

    return false;
}

RET_CODE SybConnection::convertToRetCode(int sybCode)
{
    return this->m_msgErrorHelper.getRetCode(static_cast<SYB_ERROR_CODE_ENUM>(sybCode));
}

/************************************************************************
*   Function             : SybConnection::doBeginTransaction()
*
*   Description          : Send a "begin tran" command to the server and retrieve
*                          returned status
*
*   Arguments            :
*
*   Return               : RET_SUCCEED              : if no problem was detected
*                          RET_DBA_ERR_DBPROBLEM    : if DB/connection problem
*
*************************************************************************/
RET_CODE SybConnection::doBeginTransaction()
{
    RET_CODE ret = RET_SUCCEED;
    DBI_INT  status = 0;

    if (this->sqlExecSt("begin tran", &status) != RET_SUCCEED)
    {
        ret = RET_DBA_ERR_DBPROBLEM;
    }

    return ret;
}

/************************************************************************
*   Function             : SybConnection::endTransaction()
*
*   Description          : Send a "commit tran" or "rollback tran" command to
*                          the server according to the given status.
*
*   WARNING              : if status is different from TRUE or FALSE or if given
*                          connection number is invalid, no command
*                          is sent to the server to close the transaction and the
*                          tables concerned by the transaction stays locked.
*
*   Arguments            : status       : TRUE or FALSE
*
*   Return               : RET_SUCCEED              : if no problem was detected
*                          RET_DBA_ERR_ARGNOMATCH   : if input argument problem
*
*************************************************************************/
RET_CODE SybConnection::doEndTransaction(const FLAG_T status)
{
    RET_CODE    ret = RET_SUCCEED;

    if (this->getDescription().getType() == SqlServer)
    {
        DBI_INT     result = 0;
        std::string sqlBuff;

        switch (status)
        {
            case FALSE:
                sqlBuff.assign("rollback tran");
                break;
            case TRUE:
                sqlBuff.assign("commit tran");
                break;
            default:
                ret = RET_DBA_ERR_ARGNOMATCH;
                break;
        }

        RequestHelper requestHelper(this);
        if (sqlBuff.empty() == false && this->sqlExecSt(sqlBuff.c_str(), &result) != RET_SUCCEED)
        {
            ret = RET_DBA_ERR_DBPROBLEM;
        }
    }
    return ret;
}

RET_CODE SybConnection::doSendCommand(DBA_DYNST_ENUM outputSt)
{
    /*
    Retrieve an available connection corresponding to right
    server and type
    */
    CS_RETCODE sybRetCode          = CS_SUCCEED;

    string requestToSend;

    if (this->m_batchStream.str().empty() == false)
    {
        requestToSend = this->m_batchStream.str();
        this->setCurrentAction(DBA_ACTION_ENUM::Custom);

        if (this->createStatement(requestToSend, this->getCurrentAction()) != RET_SUCCEED)
        {
            return this->m_lastResultRetCode;
        }
    }
    else
    {
        if (this->getCurrProcedure() == nullptr)
        {
            requestToSend = this->getRequestToSend();
        }
        else
        {
            requestToSend = this->getCurrProcedure()->procName;
        }

        if (this->createStatement(requestToSend, this->getCurrentAction()) != RET_SUCCEED)
        {
            return this->m_lastResultRetCode;
        }

        this->setParameters(&this->m_sqlTraceStrPtr);
    }

    /* Send the command to the server */
    sybRetCode = SYB_CtSend(*this);

    if (sybRetCode != CS_SUCCEED && sybRetCode != CS_PENDING)
    {
        SYB_SendSqlTrace(&this->m_sqlTraceStrPtr);
        return(DBA_CONN_PROBLEM);
    }

    /* Read the result type */
    CS_INT resultType = 0;
    sybRetCode = SYB_CtResults(*this, &resultType);

    this->m_lastResultRetCode = this->convertToRetCode(sybRetCode);
    this->m_lastResultType    = static_cast<int>(resultType);

    if (this->isConnected() == false)
    {
        SYB_SendSqlTrace(&this->m_sqlTraceStrPtr);
        return(RET_DBA_ERR_CANNOTCONNECT);
    }

    if (sybRetCode != CS_SUCCEED && sybRetCode != CS_PENDING)
    {
        SYB_SendSqlTrace(&this->m_sqlTraceStrPtr);
        return(RET_DBA_ERR_CANNOTCONNECT);
    }

    SYB_SendSqlTrace(&this->m_sqlTraceStrPtr);

    this->manageError();

    if (this->m_lastResultRetCode == RET_SUCCEED)
    {
        switch (resultType)
        {
            case CS_ROW_RESULT:
            case CS_COMPUTE_RESULT:
            case CS_CURSOR_RESULT:
            case CS_PARAM_RESULT:
            case CS_STATUS_RESULT:
            case CS_CMD_SUCCEED:
                return(RET_SUCCEED);
            default:
                this->processAllResults(&this->m_lastResultType);
                return(RET_DBA_ERR_DBPROBLEM);
        }
    }
    else
    {
        return this->m_lastResultRetCode;
    }
}

/************************************************************************
*   Function             : SybConnection::sendRequest()
*
*   Description          : Send a request to the server and retrieve the
*                          result type
*
*   Arguments            : connectNo : a connection number
*                          resType   : the type of result returned
*
*   Functions call       : None
*
*   Global var. modified : None
*
*   Return               : TRUE
*                          FALSE if problem in sending request
*
*   Last modif.          : PMSTA-26764 - 230317 - PMO : Core file generated
*
*************************************************************************/
RET_CODE SybConnection::sendRequest(DBI_INT * resultType)
{
    CS_RETCODE       retCode;

    this->setStartProcTime();

    *resultType = DBI_CMD_FAIL;

    /* Send the command to the server */
    retCode = SYB_CtSend(*this);

    if (retCode != CS_SUCCEED && retCode != CS_PENDING)
    {
        if (this->isValid() == false)
        {
            return(RET_DBA_ERR_CANNOTCONNECT);
        }
        return(FALSE);
    }

    CS_INT type;
    retCode = SYB_CtResults(*this, &type);
    *resultType = static_cast<int>(type);

    if (this->isValid() == false)
    {
        return(RET_DBA_ERR_CANNOTCONNECT);
    }

    /* MEMORIZE RETCODE AND RESULT TYPE IN THE CONNECTION STRUCTURE */
    this->m_lastResultRetCode = this->convertToRetCode(retCode);
    this->m_lastResultType    = *resultType;

    if (retCode != CS_SUCCEED && retCode != CS_PENDING)
        return(RET_DBA_ERR_DBPROBLEM);

    this->resetStartProcTime();

    return RET_SUCCEED;
}


/************************************************************************
*   Function             : SybConnection::doReleaseCommand()
*
*   Description : If Oracle statement in command PTR the we delete the Statement
*
*   Arguments : connectNo : the connection number in the connection
*                                      list.
*
*   Global var.modified : None
*
*   Return : TRUE if ok
*            FALSE if problem
*
*************************************************************************/
RET_CODE SybConnection::doReleaseCommand()
{
    return this->cancelDbRequest(COMMAND_LEVEL, CANCEL_ALL);
}

/************************************************************************
*   Function             : SybConnection::bindRecvDynSt()
*
*   Description          : Bind a Sybase result column in a result set with
*                          an application variable
*
*   Arguments            : connectNo  : a connection number in the conn. list
*                          dynStType  : the format number of the result data
*                          bindData   : the structure used for binding result
*                                      columns.
*
*   Functions call       : None
*
*   Global var. modified : None
*
*   Return               : RET_SUCCEED            : if ok
*                          RET_DBA_ERR_ARGNOMATCH : if argument problem
*                          RET_DBA_ERR_SYBBIND    : if problem while
*                                                   binding fields
*
*   Creation date        : April 94 - PEC
*   Last Modif. Date     : 30.08.95 - PEC - Added RET_CODE
*                          23.05.96 - PEC - Ref.: DVP067
*                          31.01.00 - GRD - Ref.: REF4204 Allow use of real Sybase CS_TEXT format.
*                          REF7264 - 011212 - PMO : Compilation errors and warnings with C++ compiler
*************************************************************************/
RET_CODE SybConnection::bindRecvDynSt(DBA_DYNST_ENUM dynStType, DBA_DYNFLD_STP bindData)
{
    CS_DATAFMT     csDataFmt;
    DBI_SMALLINT  *nullFlags = NULL;
    DBI_SMALLINT  *bindFlags = NULL;
    DBI_INT       *fieldLength = NULL;
    int            colIndex, dbColNum = -1, colNumber, i;

    /* Retrieve the field number of a dynamic struct. format */
    colNumber = GET_FLD_NBR(dynStType);
    EV_rxaFctStruct.pfn_ct_res_info(this->m_command, CS_NUMDATA, (CS_INT *)&dbColNum, CS_UNUSED, NULL);

    /* PMSTA-24913 - LJE - 161017 */
    if (dbColNum < 0)
    {
        MSG_LogMesg(RET_DBA_ERR_SYBBIND, 4, FILEINFO, this->getCurrProcedure()->procName);
        return(RET_DBA_ERR_SYBBIND);
    }

    /* REF7264 - PMO */
    if ((nullFlags = (DBI_SMALLINT*)CALLOC(colNumber, sizeof(DBI_SMALLINT))) == NULL)
    {
        return(RET_MEM_ERR_ALLOC);
    }

    /* REF7264 - PMO */
    if ((fieldLength = (DBI_INT*)CALLOC(colNumber, sizeof(DBI_INT))) == NULL)
    {
        return(RET_MEM_ERR_ALLOC);
    }

    /* PMSTA-17490 - DDV - 140124 - Set and keep default_c on fields not returned by database */
    if ((bindFlags = (DBI_SMALLINT *)CALLOC(colNumber, sizeof(DBI_SMALLINT))) == NULL)
    {
        FREE(nullFlags);
        FREE(fieldLength);
        return(RET_MEM_ERR_ALLOC);
    }

    /* Memorize null Flags and field length array in the Connection structure */
    DBA_SetNullFlagsAndLength(*this, nullFlags, fieldLength, bindFlags);

    colIndex = 0;
    for (i = 0; i < colNumber; i++)
    {
        /* Test if the current field is a non DB field (not returned
           by the request */
        if ((IS_DBFLD(dynStType, i) != TRUE &&
            (this->getDescription().getType() == SqlServer ||
             this->getDescription().getType() == FinServer ||
             this->getDescription().getType() == DispatchServer)) ||
            IS_TECHFLD(dynStType, i) == TRUE)
        {
            dbColNum++;
            /* The field isn't bound to the result set */
            nullFlags[i] = -1;
            fieldLength[i] = 0;
            bindFlags[i] = 0; /* PMSTA-17490 - DDV - 140124 - Set and keep default_c on fields not returned by database */
            continue;
        }
        else
        {
            colIndex++;
            bindFlags[i] = 1; /* PMSTA-17490 - DDV - 140124 - Set and keep default_c on fields not returned by database */
        }

        /* Retrieve the format of the source data */
        if (EV_rxaFctStruct.pfn_ct_describe(this->m_command, colIndex, &csDataFmt) != CS_SUCCEED) /* REF3955 - SSO - 000117 */
        {
            if (this->getCurrProcedure() != nullptr)
            {
                MSG_LogMesg(RET_DBA_ERR_SYBBIND, 4, FILEINFO, this->getCurrProcedure()->procName);
            }
            else
            {
                MSG_LogMesg(RET_DBA_ERR_SYBBIND, 0, FILEINFO);
            }
            return(RET_DBA_ERR_SYBBIND);
        }

        SYB_BindRecvDynFld(bindData, i, GET_FLD_TYPE(dynStType, i), colIndex, &(nullFlags[i]), &(fieldLength[i]), this->m_command, csDataFmt, FALSE); /* DLA - PMSTA08801 - 110103 */
    }

    /* TEMPORARY :
       if the returned col. number != Dynamic col. number, a message is written
    */
    /* WARNING : dbColNum is the total number of fields (physical and logical) */
    if (colNumber != dbColNum)
    {
        const char *dynStStrPtr;
        char        dynStString[60];

        if (GET_DYNST_ENTITY(dynStType) == NullEntity ||
            (dynStStrPtr = DBA_GetDictEntitySqlName(GET_DYNST_ENTITY(dynStType))) == NULL) /* PMSTA-11505 - LJE - 110622 */
        {
            sprintf(dynStString, "%d", dynStType);
        }
        else
        {
            strcpy(dynStString, dynStStrPtr);
        }

        if (this->getCurrProcedure() != nullptr)
        {
            MSG_LogMesg(RET_DBA_ERR_SYBBIND, 5, FILEINFO, dbColNum, colNumber, dynStString,
                        this->getCurrProcedure()->procName);
        }
        else
        {
            MSG_SendMesg(RET_DBA_ERR_SYBBIND, 1, FILEINFO, dbColNum, colNumber, dynStString);
        }
        SYS_BreakOnDebug();
    }

    return(RET_SUCCEED);
}

/************************************************************************
*   Function             : SYB_BindRecvDynSqlEntity()
*
*   Description          : Bind a Sybase result column in a result set with
*                          an application variable
*
*   Arguments            : connectNo  : a connection number in the conn. list
*                          object     : the OBJECT_ENUM of entity (for the "all" struct)
*                          bindData   : the structure used for binding result
*                                      columns.
*
*   Functions call       : None
*
*   Global var. modified : None
*
*   Return               : RET_SUCCEED            : if ok
*                          RET_DBA_ERR_ARGNOMATCH : if argument problem
*                          RET_DBA_ERR_SYBBIND    : if problem while
*                                                   binding fields
*
*   Creation date        : April 94 - PEC
*   Last Modif. Date     : 30.08.95 - PEC - Added RET_CODE
*                          16.11.95 - PEC - Added test with new function DBA_GetDictAttribCalcEn
*                                           to solve fields binding between client and financial
*                                           server dialog.
*                          31.01.00 - GRD - Ref.: REF4204 Allow use of real Sybase CS_TEXT format.
*                          REF7264 - 011212 - PMO : Compilation errors and warnings with C++ compiler
*                          PMSTA-2022 - 020407 - PMO : Memory leaks
*************************************************************************/
RET_CODE SybConnection::bindRecvDynSqlEntity(OBJECT_ENUM object, DBA_DYNST_ENUM dynStType, DBA_DYNFLD_STP bindData)
{
    CS_DATAFMT   csDataFmt;
    DBI_SMALLINT *nullFlags = NULL;
    DBI_INT      *fieldLength = NULL;
    int           colIndex, dbColNum = 0, i;
    DBI_SMALLINT *bindFlags = NULL;

    /* Retrieve the field number of a dynamic struct. format */
    int colNumber = GET_FLD_NBR(dynStType);
    EV_rxaFctStruct.pfn_ct_res_info(this->m_command, CS_NUMDATA, (CS_INT *)&dbColNum, CS_UNUSED, NULL);

    /* REF7264 - PMO */
    if ((nullFlags = (DBI_SMALLINT *)CALLOC(colNumber, sizeof(DBI_SMALLINT))) == NULL)
    {
        return(RET_MEM_ERR_ALLOC);
    }

    /* REF7264 - PMO */
    if ((fieldLength = (DBI_INT *)CALLOC(colNumber, sizeof(DBI_INT))) == NULL)
    {
        FREE(nullFlags);
        return(RET_MEM_ERR_ALLOC);
    }

    /* PMSTA-17490 - DDV - 140124 - Set and keep default_c on fields not returned by database */
    if ((bindFlags = (DBI_SMALLINT *)CALLOC(colNumber, sizeof(DBI_SMALLINT))) == NULL)
    {
        FREE(nullFlags);
        FREE(fieldLength);
        return(RET_MEM_ERR_ALLOC);
    }

    /* Memorize null Flags and field length array in the Connection structure */
    DBA_SetNullFlagsAndLength(*this, nullFlags, fieldLength, bindFlags);

    colIndex = 0;
    for (i = 0; i < colNumber; i++)
    {
        /* Test if the current field is a calculated field or not DB field (not returned
           by the request) */
        if (IS_DBFLD(dynStType, i) != TRUE ||
            (GET_EDITGUIST(object) == dynStType && DBA_GetDictAttribCalcEn(object, i) == DictAttr_Calculated) ||
            IS_TECHFLD(dynStType, i) == TRUE)   /* PMSTA-18593 - LJE - 151130 */
        {
            dbColNum++;
            /* The field isn't bound to the result set */
            nullFlags[i] = -1;
            fieldLength[i] = 0;
            bindFlags[i] = 0; /* PMSTA-17490 - DDV - 140124 - Set and keep default_c on fields not returned by database */
            continue;
        }
        else
        {
            colIndex++;
            bindFlags[i] = 1; /* PMSTA-17490 - DDV - 140124 - Set and keep default_c on fields not returned by database */
        }

        /* Retrieve the format of the source data */
        if (EV_rxaFctStruct.pfn_ct_describe(this->m_command, colIndex, &csDataFmt) != CS_SUCCEED) /* REF3955 - SSO - 000117 */
        {
            MSG_LogMesg(RET_DBA_ERR_SYBBIND, 0, FILEINFO);
            return(RET_DBA_ERR_SYBBIND);
        }

        switch (csDataFmt.datatype)
        {
            case CS_CHAR_TYPE:
            case CS_LONGCHAR_TYPE: /* DLA - PMSTA07121 - 090213 */
            case CS_TEXT_TYPE:      /* REF4204 */
                if (GET_CTYPE(GET_FLD_TYPE(dynStType, i)) != UniTextPtrCType)
                {
                    csDataFmt.format = CS_FMT_NULLTERM;

                    ALLOC_STRFLD(
                        bindData[i], csDataFmt.maxlength);

                    csDataFmt.maxlength += 1;

                    if (SYB_CtBind(this->m_command, colIndex, &csDataFmt,
                        (CS_VOID *)bindData[i].data.strData.ptr,
                                   (CS_INT *)&(fieldLength[i]),
                                   (CS_SMALLINT *)&(nullFlags[i]),
                                   GET_ANONYMIZE_ITEM(dynStType, i),
                                   GET_ANONYMIZE_SUBST(dynStType, i)) != CS_SUCCEED) /* REF3955 - SSO - 000117 */
                    {
                        MSG_LogMesg(RET_DBA_ERR_SYBBIND, 0, FILEINFO);
                        return(RET_DBA_ERR_SYBBIND);
                    }
                }
                else
                {
                    csDataFmt.datatype = CS_UNICHAR_FROM_TEXT_TYPE;
                    csDataFmt.format = CS_FMT_NULLTERM;

                    ALLOC_USTRFLD(
                        bindData[i], csDataFmt.maxlength);

                    csDataFmt.maxlength += 1;
                    csDataFmt.maxlength *= 2;

                    if (SYB_CtBind(this->m_command, colIndex, &csDataFmt,
                        (CS_VOID *)bindData[i].data.ustrData.ptr,
                                   (CS_INT *)&(fieldLength[i]),
                                   (CS_SMALLINT *)&(nullFlags[i]),
                                   GET_ANONYMIZE_ITEM(dynStType, i),
                                   GET_ANONYMIZE_SUBST(dynStType, i)) != CS_SUCCEED) /* REF3955 - SSO - 000117 */
                    {
                        MSG_LogMesg(RET_DBA_ERR_SYBBIND, 0, FILEINFO);
                        return(RET_DBA_ERR_SYBBIND);
                    }
                }

                break;

            case CS_UNICHAR_TYPE:   /* PCL-REF9303-030724 */

                csDataFmt.format = CS_FMT_NULLTERM;

                csDataFmt.maxlength /= 2;

                ALLOC_USTRFLD(
                    bindData[i], csDataFmt.maxlength);

                csDataFmt.maxlength += 1;
                csDataFmt.maxlength *= 2;

                if (SYB_CtBind(this->m_command, colIndex, &csDataFmt,
                    (CS_VOID *)bindData[i].data.ustrData.ptr,
                               (CS_INT *)&(fieldLength[i]),
                               (CS_SMALLINT *)&(nullFlags[i]),
                               GET_ANONYMIZE_ITEM(dynStType, i),
                               GET_ANONYMIZE_SUBST(dynStType, i)) != CS_SUCCEED) /* REF3955 - SSO - 000117 */
                {
                    MSG_LogMesg(RET_DBA_ERR_SYBBIND, 0, FILEINFO);
                    return(RET_DBA_ERR_SYBBIND);
                }

                break;

            case CS_DATETIME_TYPE:
                csDataFmt.format = CS_FMT_UNUSED;

                /*
                   Convert the Date switch field C type
                   REM : SYB_CtBind will automatically call SYB_ConvertDateToInt() if
                                     the field type is a long (DATE_T) and SYB_ConvertDateToDouble if
                                     the field type is a structure DATETIME_ST (Date and Time)
                            */

                csDataFmt.datatype = CS_FLOAT_TYPE;
                break;

            case CS_INT_TYPE:
                csDataFmt.format = CS_FMT_UNUSED;
                csDataFmt.datatype = CS_INT_TYPE;
                break;

            case CS_BIGINT_TYPE: /* PMSTA08801 - DLA - 091126 */
                csDataFmt.format = CS_FMT_UNUSED;
                csDataFmt.datatype = CS_BIGINT_TYPE;
                if (SYB_CtBind(this->m_command, colIndex, &csDataFmt, (CS_VOID *)&(bindData[i].data.longlongValue),
                               NULL, (CS_SMALLINT *)&(nullFlags[i]),
                               GET_ANONYMIZE_ITEM(dynStType, i),
                               GET_ANONYMIZE_SUBST(dynStType, i)) != CS_SUCCEED) /* REF3955 - SSO - 000117 */
                {
                    MSG_LogMesg(RET_DBA_ERR_SYBBIND, 0, FILEINFO);
                    return(RET_DBA_ERR_SYBBIND);
                }

                break;

            case CS_NUMERIC_TYPE:
                csDataFmt.format = CS_FMT_UNUSED;
                switch (csDataFmt.scale)
                {
                    case 0:
                        csDataFmt.datatype = CS_BIGINT_TYPE;
                        if (SYB_CtBind(this->m_command, colIndex, &csDataFmt,
                            (CS_VOID *)&(bindData[i].data.longlongValue),
                                       NULL, (CS_SMALLINT *)&(nullFlags[i]),
                                       GET_ANONYMIZE_ITEM(dynStType, i),
                                       GET_ANONYMIZE_SUBST(dynStType, i)) != CS_SUCCEED) /* REF3955 - SSO - 000117 */
                        {
                            MSG_LogMesg(RET_DBA_ERR_SYBBIND, 0, FILEINFO);
                            return(RET_DBA_ERR_SYBBIND);
                        }
                        break;

                    default:
                        csDataFmt.datatype = CS_FLOAT_TYPE;
                        break;
                }
                break;

            case CS_SMALLINT_TYPE:
                csDataFmt.format = CS_FMT_UNUSED;
                csDataFmt.datatype = CS_SMALLINT_TYPE;
                break;

            case CS_BINARY_TYPE:    /* REF11780 - 100406 - PMO */
                csDataFmt.format = CS_FMT_UNUSED;
                csDataFmt.datatype = CS_USER_TIMESTAMP;
                break;

        }

        if (csDataFmt.datatype == CS_INT_TYPE &&
            (IS_STRINGFLD(dynStType, i) || IS_USTRINGFLD(dynStType, i)))
        {
            // Avoid crash with SELECT NULL
            static CS_INT discard;

            if (SYB_CtBind(this->m_command, colIndex, &csDataFmt,
                (CS_VOID *)&discard,
                           NULL, (CS_SMALLINT *)&(nullFlags[i]),
                           GET_ANONYMIZE_ITEM(dynStType, i),
                           GET_ANONYMIZE_SUBST(dynStType, i)) != CS_SUCCEED) /* REF3955 - SSO - 000117 */
            {
                MSG_LogMesg(RET_DBA_ERR_SYBBIND, 0, FILEINFO);
                return(RET_DBA_ERR_SYBBIND);
            }
        }
        else
            if (csDataFmt.datatype != CS_CHAR_TYPE &&
                csDataFmt.datatype != CS_LONGCHAR_TYPE && /* DLA - PMSTA07121 - 090313 */
                csDataFmt.datatype != CS_BIGINT_TYPE &&
                csDataFmt.datatype != CS_TEXT_TYPE &&
                csDataFmt.datatype != CS_UNICHAR_TYPE &&
                csDataFmt.datatype != CS_UNICHAR_FROM_TEXT_TYPE)
            {
                if (SYB_CtBind(this->m_command, colIndex, &csDataFmt,
                    (CS_VOID *)&(bindData[i].data.dbleValue),
                               NULL, (CS_SMALLINT *)&(nullFlags[i]),
                               GET_ANONYMIZE_ITEM(dynStType, i),
                               GET_ANONYMIZE_SUBST(dynStType, i)) != CS_SUCCEED) /* REF3955 - SSO - 000117 */
                {
                    MSG_LogMesg(RET_DBA_ERR_SYBBIND, 0, FILEINFO);
                    return(RET_DBA_ERR_SYBBIND);
                }
            }
    }

    /* TEMPORARY :
       if the returned col. number != Dynamic col. number, a message is written
    */
    if (colNumber != dbColNum)
    {
        char dynStString[60];

        if (GET_DYNST_ENTITY(dynStType) == NullEntity) /* PMSTA-11505 - LJE - 110622 */
            sprintf(dynStString, "%d", dynStType);
        else
        {
            strcpy(dynStString, DBA_GetDictEntitySqlName(GET_DYNST_ENTITY(dynStType)));
        }

        MSG_SendMesg(RET_DBA_ERR_SYBBIND, 1, FILEINFO, dbColNum, colNumber, dynStString);
        SYS_BreakOnDebug();
    }

    return(RET_SUCCEED);
}


/************************************************************************
*   Function             : SybConnection::isDbTransactionRequired()
*
*   Description : If we must open a transaction
*
*
*   Global var.modified : None
*
*   Return :
*
*************************************************************************/
bool SybConnection::isDbTransactionRequired()
{
    if (SYS_GetEnvBoolOrDefValue("AAASYBASE_NO_TRANSACTION_REQUIRED", false))
    {
        return false;
    }
    return true;
}

/************************************************************************
*   Function             : SybConnection::isDdlGenOnTran()
*
*   Description          :
*
*
*   Global var.modified : None
*
*   Return :
*
*************************************************************************/
bool SybConnection::isDdlGenOnTran()
{
    return false;
}

SYB_MsgError::SYB_MsgError()
{
}

SYB_MsgError::~SYB_MsgError()
{
}

RET_CODE SYB_MsgError::getRetCode(SYB_ERROR_CODE_ENUM errorCodeE)
{
    switch (errorCodeE)
    {
        /* Add here Sybase Error Message to match with a RET_CODE */
        case SYB_ERROR_CODE_ENUM::MSGNB00001_SUCCEED:                   return  RET_SUCCEED;
        case SYB_ERROR_CODE_ENUM::MSGNB00515_ERR_NULLCOLVALUE1:         return  RET_SRV_LIB_ERR_NULLCOLVALUE;
        case SYB_ERROR_CODE_ENUM::MSGNB00530_ERR_NULLCOLVALUE2:         return  RET_SRV_LIB_ERR_NULLCOLVALUE;
        case SYB_ERROR_CODE_ENUM::MSGNB00640_ERR_NULLCOLVALUE3:         return  RET_SRV_LIB_ERR_NULLCOLVALUE;
        case SYB_ERROR_CODE_ENUM::MSGNB00546_ERR_FOREIGNKEY1:           return  RET_SRV_LIB_ERR_FOREIGNKEY;
        case SYB_ERROR_CODE_ENUM::MSGNB17560_ERR_FOREIGNKEY2:           return  RET_SRV_LIB_ERR_FOREIGNKEY;
        case SYB_ERROR_CODE_ENUM::MSGNB00548_ERR_CHECKCONSTRAINT:       return  RET_SRV_LIB_ERR_CHECKCONSTRAINT;
        case SYB_ERROR_CODE_ENUM::MSGNB02601_ERR_DUPLICATEKEY1:         return  RET_SRV_LIB_ERR_DUPLICATEKEY;
        case SYB_ERROR_CODE_ENUM::MSGNB02615_ERR_DUPLICATEKEY2:         return  RET_SRV_LIB_ERR_DUPLICATEKEY;
        case SYB_ERROR_CODE_ENUM::MSGNB03604_ERR_DUPLICATEKEY3:         return  RET_SRV_LIB_ERR_DUPLICATEKEY;
        case SYB_ERROR_CODE_ENUM::MSGNB07201_ERR_CONNFAILED1:           return  RET_SRV_LIB_ERR_CONNFAILED;
        case SYB_ERROR_CODE_ENUM::MSGNB07202_ERR_CONNFAILED2:           return  RET_SRV_LIB_ERR_CONNFAILED;
        case SYB_ERROR_CODE_ENUM::MSGNB07203_ERR_CONNFAILED3:           return  RET_SRV_LIB_ERR_CONNFAILED;
        case SYB_ERROR_CODE_ENUM::MSGNB07204_ERR_CONNFAILED4:           return  RET_SRV_LIB_ERR_CONNFAILED;
        case SYB_ERROR_CODE_ENUM::MSGNB07205_ERR_CONNFAILED5:           return  RET_SRV_LIB_ERR_CONNFAILED;
        case SYB_ERROR_CODE_ENUM::MSGNB07206_ERR_CONNFAILED6:           return  RET_SRV_LIB_ERR_CONNFAILED;
        case SYB_ERROR_CODE_ENUM::MSGNB07207_ERR_CONNFAILED7:           return  RET_SRV_LIB_ERR_CONNFAILED;
        case SYB_ERROR_CODE_ENUM::MSGNB07208_ERR_CONNFAILED8:           return  RET_SRV_LIB_ERR_CONNFAILED;
        case SYB_ERROR_CODE_ENUM::MSGNB07210_ERR_CONNFAILED9:           return  RET_SRV_LIB_ERR_CONNFAILED;
        case SYB_ERROR_CODE_ENUM::MSGNB07211_ERR_CONNFAILED10:          return  RET_SRV_LIB_ERR_CONNFAILED;
        case SYB_ERROR_CODE_ENUM::MSGNB07227_ERR_CONNFAILED11:          return  RET_SRV_LIB_ERR_CONNFAILED;
        case SYB_ERROR_CODE_ENUM::MSGNB00201_ERR_PARAMNOTSUPPLIED:      return  RET_SRV_LIB_ERR_PARAMNOTSUPPLIED;
        case SYB_ERROR_CODE_ENUM::MSGNB03607_ERR_DIVIDE_BY_ZERO:        return  RET_SRV_LIB_ERR_DIVIDE_BY_ZERO;
        case SYB_ERROR_CODE_ENUM::MSGNB00220_ERR_DB_OVERFLOW1:          return  RET_SRV_LIB_ERR_DB_OVERFLOW;
        case SYB_ERROR_CODE_ENUM::MSGNB00227_ERR_DB_OVERFLOW2:          return  RET_SRV_LIB_ERR_DB_OVERFLOW;
        case SYB_ERROR_CODE_ENUM::MSGNB00232_ERR_DB_OVERFLOW3:          return  RET_SRV_LIB_ERR_DB_OVERFLOW;
        case SYB_ERROR_CODE_ENUM::MSGNB00247_ERR_DB_OVERFLOW4:          return  RET_SRV_LIB_ERR_DB_OVERFLOW;
        case SYB_ERROR_CODE_ENUM::MSGNB00517_ERR_DB_OVERFLOW5:          return  RET_SRV_LIB_ERR_DB_OVERFLOW;
        case SYB_ERROR_CODE_ENUM::MSGNB03606_ERR_DB_OVERFLOW6:          return  RET_SRV_LIB_ERR_DB_OVERFLOW;
        case SYB_ERROR_CODE_ENUM::MSGNB00916_ERR_INVALID_USER_IN_DB:    return  RET_SRV_LIB_ERR_INVALID_USER_IN_DB;
        case SYB_ERROR_CODE_ENUM::MSGNB03621_ERR_COMMAND_ABORTED:       return  RET_SRV_LIB_ERR_COMMAND_ABORTED;
        case SYB_ERROR_CODE_ENUM::MSGNB01105_ERR_DB_IS_FULL:            return  RET_SRV_LIB_ERR_DB_IS_FULL;
        case SYB_ERROR_CODE_ENUM::MSGNB00303_ERR_DB_TABLE1:             return  RET_SRV_LIB_ERR_DB_TABLE;
        case SYB_ERROR_CODE_ENUM::MSGNB00304_ERR_DB_TABLE2:             return  RET_SRV_LIB_ERR_DB_TABLE;
        case SYB_ERROR_CODE_ENUM::MSGNB00556_ERR_DB_TABLE3:             return  RET_SRV_LIB_ERR_DB_TABLE;
        case SYB_ERROR_CODE_ENUM::MSGNB02767_ERR_DB_TABLE4:             return  RET_SRV_LIB_ERR_DB_TABLE;
        case SYB_ERROR_CODE_ENUM::MSGNB03723_ERR_DB_TABLE5:             return  RET_SRV_LIB_ERR_DB_TABLE;
        case SYB_ERROR_CODE_ENUM::MSGNB07908_ERR_DB_TABLE6:             return  RET_SRV_LIB_ERR_DB_TABLE;
        case SYB_ERROR_CODE_ENUM::MSGNB07934_ERR_DB_TABLE7:             return  RET_SRV_LIB_ERR_DB_TABLE;
        case SYB_ERROR_CODE_ENUM::MSGNB17394_ERR_DB_TABLE8:             return  RET_SRV_LIB_ERR_DB_TABLE;
        case SYB_ERROR_CODE_ENUM::MSGNB17395_ERR_DB_TABLE9:             return  RET_SRV_LIB_ERR_DB_TABLE;
        case SYB_ERROR_CODE_ENUM::MSGNB17396_ERR_DB_TABLE10:            return  RET_SRV_LIB_ERR_DB_TABLE;
        case SYB_ERROR_CODE_ENUM::MSGNB17397_ERR_DB_TABLE11:            return  RET_SRV_LIB_ERR_DB_TABLE;
        case SYB_ERROR_CODE_ENUM::MSGNB17398_ERR_DB_TABLE12:            return  RET_SRV_LIB_ERR_DB_TABLE;
        case SYB_ERROR_CODE_ENUM::MSGNB17399_ERR_DB_TABLE13:            return  RET_SRV_LIB_ERR_DB_TABLE;
        case SYB_ERROR_CODE_ENUM::MSGNB17400_ERR_DB_TABLE14:            return  RET_SRV_LIB_ERR_DB_TABLE;
        case SYB_ERROR_CODE_ENUM::MSGNB17401_ERR_DB_TABLE15:            return  RET_SRV_LIB_ERR_DB_TABLE;
        case SYB_ERROR_CODE_ENUM::MSGNB17492_ERR_DB_TABLE16:            return  RET_SRV_LIB_ERR_DB_TABLE;
        case SYB_ERROR_CODE_ENUM::MSGNB17563_ERR_DB_TABLE17:            return  RET_SRV_LIB_ERR_DB_TABLE;
        case SYB_ERROR_CODE_ENUM::MSGNB17742_ERR_DB_TABLE18:            return  RET_SRV_LIB_ERR_DB_TABLE;
        case SYB_ERROR_CODE_ENUM::MSGNB17743_ERR_DB_TABLE19:            return  RET_SRV_LIB_ERR_DB_TABLE;
        case SYB_ERROR_CODE_ENUM::MSGNB17744_ERR_DB_TABLE20:            return  RET_SRV_LIB_ERR_DB_TABLE;
        case SYB_ERROR_CODE_ENUM::MSGNB17745_ERR_DB_TABLE21:            return  RET_SRV_LIB_ERR_DB_TABLE;
        case SYB_ERROR_CODE_ENUM::MSGNB17746_ERR_DB_TABLE22:            return  RET_SRV_LIB_ERR_DB_TABLE;
        case SYB_ERROR_CODE_ENUM::MSGNB17747_ERR_DB_TABLE23:            return  RET_SRV_LIB_ERR_DB_TABLE;
        case SYB_ERROR_CODE_ENUM::MSGNB17748_ERR_DB_TABLE24:            return  RET_SRV_LIB_ERR_DB_TABLE;
        case SYB_ERROR_CODE_ENUM::MSGNB17749_ERR_DB_TABLE25:            return  RET_SRV_LIB_ERR_DB_TABLE;
        case SYB_ERROR_CODE_ENUM::MSGNB00504_ERR_STORED_PROC1:          return  RET_SRV_LIB_ERR_STORED_PROC;
        case SYB_ERROR_CODE_ENUM::MSGNB02804_ERR_STORED_PROC2:          return  RET_SRV_LIB_ERR_STORED_PROC;
        case SYB_ERROR_CODE_ENUM::MSGNB02806_ERR_STORED_PROC3:          return  RET_SRV_LIB_ERR_STORED_PROC;
        case SYB_ERROR_CODE_ENUM::MSGNB02812_ERR_STORED_PROC4:          return  RET_SRV_LIB_ERR_STORED_PROC;
        case SYB_ERROR_CODE_ENUM::MSGNB07712_ERR_STORED_PROC5:          return  RET_SRV_LIB_ERR_STORED_PROC;
        case SYB_ERROR_CODE_ENUM::MSGNB00771_ERR_STORED_PROC6:          return  RET_SRV_LIB_ERR_STORED_PROC;
        case SYB_ERROR_CODE_ENUM::MSGNB18041_ERR_STORED_PROC7:          return  RET_SRV_LIB_ERR_STORED_PROC;
        case SYB_ERROR_CODE_ENUM::MSGNB01139_ERR_DEADLOCK1:             return  RET_SRV_LIB_ERR_DEADLOCK;
        case SYB_ERROR_CODE_ENUM::MSGNB01205_ERR_DEADLOCK2:             return  RET_SRV_LIB_ERR_DEADLOCK;
        case SYB_ERROR_CODE_ENUM::MSGNB01248_ERR_DEADLOCK3:             return  RET_SRV_LIB_ERR_DEADLOCK;
        case SYB_ERROR_CODE_ENUM::MSGNB03210_ERR_DEADLOCK4:             return  RET_SRV_LIB_ERR_DEADLOCK;
        case SYB_ERROR_CODE_ENUM::MSGNB03309_ERR_DEADLOCK5:             return  RET_SRV_LIB_ERR_DEADLOCK;
        case SYB_ERROR_CODE_ENUM::MSGNB13093_ERR_DEADLOCK6:             return  RET_SRV_LIB_ERR_DEADLOCK;
        case SYB_ERROR_CODE_ENUM::MSGNB00229_ERR_PERM_DENIED1:          return  RET_SRV_LIB_ERR_PERM_DENIED;
        case SYB_ERROR_CODE_ENUM::MSGNB00230_ERR_PERM_DENIED2:          return  RET_SRV_LIB_ERR_PERM_DENIED;
        case SYB_ERROR_CODE_ENUM::MSGNB00262_ERR_PERM_DENIED3:          return  RET_SRV_LIB_ERR_PERM_DENIED;
        case SYB_ERROR_CODE_ENUM::MSGNB10330_ERR_PERM_DENIED4:          return  RET_SRV_LIB_ERR_PERM_DENIED;
        case SYB_ERROR_CODE_ENUM::MSGNB00257_ERR_CONVERSION:            return  RET_SRV_LIB_ERR_CONVERSION;
        case SYB_ERROR_CODE_ENUM::MSGNB00101_ERR_SYNTAX:
        case SYB_ERROR_CODE_ENUM::MSGNB00102_ERR_SYNTAX:
        case SYB_ERROR_CODE_ENUM::MSGNB00148_ERR_SYNTAX:
        case SYB_ERROR_CODE_ENUM::MSGNB00149_ERR_SYNTAX:
        case SYB_ERROR_CODE_ENUM::MSGNB00156_ERR_SYNTAX:
        case SYB_ERROR_CODE_ENUM::MSGNB00210_ERR_SYNTAX:
        case SYB_ERROR_CODE_ENUM::MSGNB00211_ERR_SYNTAX:
        case SYB_ERROR_CODE_ENUM::MSGNB00249_ERR_SYNTAX:
        case SYB_ERROR_CODE_ENUM::MSGNB01273_ERR_SYNTAX:
        case SYB_ERROR_CODE_ENUM::MSGNB05129_ERR_SYNTAX:
        case SYB_ERROR_CODE_ENUM::MSGNB02007_ERR_SYNTAX:
            return  RET_SRV_LIB_ERR_SYNTAX;
        case SYB_ERROR_CODE_ENUM::MSGNB04408_ERR_LIMITEXCEED:           return  RET_SRV_LIB_ERR_LIMITEXCEED;
        case SYB_ERROR_CODE_ENUM::MSGNB00701_ERR_PROC_CACHE_MEMORY:     return  RET_SRV_LIB_ERR_PROC_CACHE_MEMORY;
        case SYB_ERROR_CODE_ENUM::MSGNB03814_ERR_INV_PARAM_VALUE:       return  RET_SRV_LIB_ERR_INV_PARAM_VALUE;
        case SYB_ERROR_CODE_ENUM::MSGNB17720_ERR_NO_NUM_INPASSWORD1:    return  RET_SRV_LIB_ERR_NO_NUM_INPASSWORD;
        case SYB_ERROR_CODE_ENUM::MSGNB09551_ERR_NO_NUM_INPASSWORD2:    return  RET_SRV_LIB_ERR_NO_NUM_INPASSWORD;
        case SYB_ERROR_CODE_ENUM::MSGNB16908863_ERR_TIMED_OUT:          return  RET_SRV_LIB_ERR_TIMED_OUT;
        case SYB_ERROR_CODE_ENUM::MSGNB84083974_ERR_DISCONNECTED:       return  RET_DBA_ERR_DISCONNECTED;
        case SYB_ERROR_CODE_ENUM::MSGNB04002_ERR_LOGIN:                 return  RET_DBA_ERR_LOGIN;
        case SYB_ERROR_CODE_ENUM::MSGNB20289_INFO_EXTERNAL_SEQ:         return  RET_DBA_INFO_EXTERNAL_SEQ;
        case SYB_ERROR_CODE_ENUM::MSGNB02403_ERR_CHAR_SET_CONVERSION:   return  RET_SRV_INFO_CHARSET_CONV_ISSUE;
        case SYB_ERROR_CODE_ENUM::MSGNB0x1900000C_ERR_UNKNOWN_MSG:      return  RET_SRV_LIB_ERR_UNKNOWN_MSG;
        case SYB_ERROR_CODE_ENUM::MSGNB0x09000004_INFO_CLOSING_SUCCEED: return  RET_SRV_INFO_CLOSING_SUCCEED;
        default:
        RET_CODE err = static_cast<RET_CODE>(errorCodeE);
        if (isValidRetCode(err))
        {
            return err;
        }
        return RET_SRV_LIB_ERR_UNKNOWN_MSG;

    }
}

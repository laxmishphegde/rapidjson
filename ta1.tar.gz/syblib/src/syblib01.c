/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define SYBLIB01_C

/**************************************************************************
* Local Functions
*
* SYB_HandleMsg                : Callback function which handle the client library messages.
* SYB_HandleSrvMsg             : Callback function which handle the client library messages.
* SYB_InitContext              : Allocate an application context, install message handlers and conversion fcts
* SYB_ConvertDateToInt         : Conversion routine between Sybase Date format and application date
* SYB_ConvertSmallDateToDouble : Conversion routine between Sybase Date format and application date
* SYB_ConvertDateToDouble      : Conversion routine between Sybase Date format and application date
* SYB_ConvertDoubleToDate      : Conversion routine between application date and Sybase Date format (xaj - 0897)
* SYB_ConvertIntToDate         : Conversion routine between application date and Sybase Date format (xaj - 0897)
* SYB_ConvertNum12_0ToInt64    : Conversion routine between application INT64 and Sybase NUMERIC 12.0 (REF9089)
* SYB_ConvertInt64ToNum12_0    : Conversion routine between Sybase Numeric 12.0 and application INT64 (REF9089)
* SYB_ConvertNum9_0ToInt       : Conversion routine between application INT and Sybase NUMERIC 9.0 (to be deleted when migration to id64 is finished) (REF9089)
* SYB_ConvertIntToNum9_0       : Conversion routine between Sybase Numeric 9.0 and application INT (to be deleted when migration to id64 is finished) (REF9089)
* SYB_GetConnectAuth           : Retrieve all application data and limits from from table appl_param
* SYB_FreeConnection           : Close a connection previously etablished, free all allocated structures
* SYB_ServerNotification       : Handle Server Notifications
* SYB_FreeSybCliContext        : Free the application context
* SYB_CtCommand                : Memorize the command name in Language or RPC mode
* SYB_CtSend                   : Send the command previously initialized by SYB_CtCommand
* SYB_CtFetch                  : Retrieve a result row sent back by a server
* SYB_CtResults                : Get result types to be processed (Rows, status,...)
* SYB_CtCancel                 : Cancel all pending results
* SYB_CtConnectWithEncryptedPassword : Establish/open a connection with a server
* SYB_CtConnect                : Used by SYB_CtConnectWithEncryptedPassword
* SYB_GetCsContext             : Retrieve the CS_CONTEXT structure
* SYB_SetGeneralCharset        : Sets a character set code to the general context.
* SYB_PrintVersion             : Print the client library version loaded
*
**************************************************************************/

/************************************************************************
**      Include files
*************************************************************************/
#define STDIO_H
#define MATH_H
#define TIME_H
#define STDLIB_H
#define STRING_H
#define STDARG_H

#include "unidef.h"     /* Mandatory */
#include "os.h"

#ifndef DBA_H
#include "dba.h"
#endif
#include "dbi.h"

#include "proc.h"
#include "gen.h"
#include "syb.h"

#include "callstack.h"

#ifndef SYSLIB_H
#include "syslib.h" /* PMO - Rename our sys.h to syslib.h and use it */
#endif

#include "date.h"
#include "crypt.h"
#include <assert.h>
#include <conlocprovider.h>
#include <conprovider.h>
#include <sybconnection.h>
#include <conexcept.h>
#include "rxa.h"

#ifdef _WIN32
#pragma warning(disable:4127)
#pragma warning(disable:4146)
#endif

#include <gmp.h>

#ifdef _WIN32
#pragma warning(default:4127)
#pragma warning(default:4146)
#endif

#ifndef TLS_H
#include "tls.h"
#endif


#include <sstream>
using namespace std;

/************************************************************************
**      Static definitions & data
*************************************************************************/
CS_CONTEXT *                    EV_ApplContext;                                 /* application context */
static DBA_LOG_FAILED_INFO_ENUM SV_FirstLoginState = LoginPassed;
int                             EV_SybPacketSize = 0;                         /* DLA - PMSTA-928 - 061117 */

static void * (*SV_CallBack_PasswordInitialization)(void) = nullptr;     /* PMSTA-18094 - 130514 - PMO */
static bool(*SV_CallBack_PasswordEncrypt)(void *, const char *) = nullptr;     /* PMSTA-18094 - 130514 - PMO */
static bool(*SV_CallBack_PasswordDecrypt)(char *, const void *) = nullptr;     /* PMSTA-18094 - 130514 - PMO */
static void(*SV_CallBack_PasswordFree)(void *) = nullptr;     /* PMSTA-18094 - 130514 - PMO */

#define ERROR_SNOL(e, s, n, o, l) \
	( (CS_SEVERITY(e) == s) && (CS_NUMBER(e) == n) \
	&& (CS_ORIGIN(e) == o) && (CS_LAYER(e) == l ) )


/************************************************************************
**      External definitions & data
*************************************************************************/
extern int          SV_SqlTraceLevel;
extern int          EV_AAAInstallLevel;
extern int unsigned EV_SqlTraceMaxLen;  /* PMSTA12840-JPP-111006 */
extern RXA_FCTPTR   EV_rxaFctStruct;    /* DLA - PMSTA-23431 - 160824 */

extern bool EV_EnableMicrosecTime;

/************************************************************************
**      Prototypes
*************************************************************************/



/************************************************************************
*   Function             : SYB_SetCallBack_PasswordInitialization()
*
*   Description          : Define the callback function which handle the password initialization
*
*   Arguments            : pFunction    Function called by the callback
*
*   Global var. modified : SV_CallBack_PasswordInitialization
*
*   Return               : None
*
*   Creation date        : PMSTA-18094 - 130514 - PMO : Avoid extracting the user credentials from the GUI running on Windows (via dump, etc.)
*
*   Last modification    :
*
*************************************************************************/
void SYB_SetCallBack_PasswordInitialization(void * (*pFunction)(void))
{
    SV_CallBack_PasswordInitialization = pFunction;
}


/************************************************************************
*   Function             : SYB_SetCallBack_PasswordEncrypt()
*
*   Description          : Define the callback function which handle the password encryption
*
*   Arguments            : pFunction    Function called by the callback
*
*   Global var. modified : SV_CallBack_PasswordEncrypt
*
*   Return               : None
*
*   Creation date        : PMSTA-18094 - 130514 - PMO : Avoid extracting the user credentials from the GUI running on Windows (via dump, etc.)
*
*   Last modification    :
*
*************************************************************************/
void SYB_SetCallBack_PasswordEncrypt(bool(*pFunction)(void *, const char *))
{
    SV_CallBack_PasswordEncrypt = pFunction;
}


/************************************************************************
*   Function             : SYB_PasswordEncrypt()
*
*   Description          : Encrypion of password through the Callback function which handle the password encrypion
*
*   Arguments            : pEncryptedPassword   Handle of the password
*                          password             Password to encrypt
*
*   Global var. modified : None
*
*   Return               : None
*
*   Creation date        : PMSTA-18094 - 130514 - PMO : Avoid extracting the user credentials from the GUI running on Windows (via dump, etc.)
*
*   Last modification    :
*
*************************************************************************/
void SYB_PasswordEncrypt(void * pEncryptedPassword, const char * password)
{
    if (NULL != SV_CallBack_PasswordEncrypt)
    {
        SV_CallBack_PasswordEncrypt(pEncryptedPassword, password);
    }
}


/************************************************************************
*   Function             : SYB_SetCallBack_PasswordDecrypt()
*
*   Description          : Define the callback function which handle the password decryption
*
*   Arguments            : pFunction    Function called by the callback
*
*   Global var. modified : SV_CallBack_PasswordDecrypt
*
*   Return               : None
*
*   Creation date        : PMSTA-18094 - 130514 - PMO : Avoid extracting the user credentials from the GUI running on Windows (via dump, etc.)
*
*   Last modification    :
*
*************************************************************************/
void SYB_SetCallBack_PasswordDecrypt(bool(*pFunction)(char *, const void *))
{
    SV_CallBack_PasswordDecrypt = pFunction;
}


/************************************************************************
*   Function             : SYB_PasswordDecrypt()
*
*   Description          : Decrypion of password through the Callback function which handle the password decrypion
*
*   Arguments            : password             Password decrypted
*                          pEncryptedPassword   Handle of the password
*
*   Global var. modified : None
*
*   Return               : None
*
*   Creation date        : PMSTA-18094 - 130514 - PMO : Avoid extracting the user credentials from the GUI running on Windows (via dump, etc.)
*
*   Last modification    :
*
*************************************************************************/
void SYB_PasswordDecrypt(char* password, const void * pEncryptedPassword)
{
    if (NULL != SV_CallBack_PasswordDecrypt)
    {
        SV_CallBack_PasswordDecrypt(password, pEncryptedPassword);
    }
}


/************************************************************************
*   Function             : SYB_SetCallBack_PasswordFree()
*
*   Description          : Define the callback function which handle the free of the memory for password
*
*   Arguments            : pFunction    Function called by the callback
*
*   Global var. modified : SV_CallBack_PasswordFree
*
*   Return               : None
*
*   Creation date        : PMSTA-18094 - 130514 - PMO : Avoid extracting the user credentials from the GUI running on Windows (via dump, etc.)
*
*   Last modification    :
*
*************************************************************************/
void SYB_SetCallBack_PasswordFree(void(*pFunction)(void *))
{
    SV_CallBack_PasswordFree = pFunction;
}


/************************************************************************
*   Function             : SYB_FreePassword()
*
*   Description          : Memory free of password through the Callback function which handle the memory free of password
*
*   Arguments            : password             Password decrypted
*                          pEncryptedPassword   Handle of the password
*
*   Global var. modified : None
*
*   Return               : None
*
*   Creation date        : PMSTA-18094 - 130514 - PMO : Avoid extracting the user credentials from the GUI running on Windows (via dump, etc.)
*
*   Last modification    :
*
*************************************************************************/
void SYB_FreePassword(void ** passwordData)
{
    if (NULL != SV_CallBack_PasswordFree)
    {
        SV_CallBack_PasswordFree(*passwordData);
    }

    *passwordData = NULL;
}


/************************************************************************
*   Function             : SYB_CompareCtConnect()
*
*   Description          : Function
*
*
*   Arguments            : AAAConnection  : a reference on a connection.
*                          csConnection   : a pointer on a CS_CONNECTION struct.
*
*   Return               : true if found
*************************************************************************/
static bool SYB_CompareCtConnect(DbiConnection & dbiConn, void * csConnection)
{
    return dbiConn.getConnectionPtr() == csConnection;
}

/************************************************************************
*   Function             : SYB_SaveMsgInfos()
*
*   Description          : Save messages in message stack associated to each
*                          connection.
*
*
*   Arguments            : DbiConnection: the connection object
*                          msgOrigin    : from which Msg handler the msg comes
*                          msgNumber    : the number of the message
*                          severity     : the severity of the message
*                          state        :
*                          procedure    : the proc which generate the message
*                          serverName   : the server which send the message
*                          msgString    : the message string
*
*   Functions call       :
*
*
*   Global var. modified : None
*
*   Return               : RET_SUCCEED         : if ok
*                          RET_GEN_MAX_REACHED : if max stack is reached
*
*   Creation Date        : 03.11.95 - PEC
*   Last Modification    : 07.05.96 - PEC - Ref.: BUG029
*                          14.06.96 - PEC - Ref.: DVP144
*                          20.04.98 - GRD - REF1784.
*************************************************************************/
RET_CODE SYB_SaveMsgInfos(SybConnection&      dbiConn,
                          DBA_MSG_ORIGIN_ENUM msgOrigin,
                          int                 msgNumber,
                          int                 severity,
                          int                 state,
                          const char         *procedure,
                          const char         *serverName,
                          const char         *msgString,
                          int                 line, /* PMSTA-14452 - LJE - 130115 */
                          bool                bLogged)      /* DVP144 */
{
    /* PMSTA-43018- LJE - 220525 */
    if (msgOrigin == ServerHandler &&
        msgNumber == 99999 &&
        msgString != nullptr &&
        dbiConn.m_msgStack.size() > 0 &&
        atoi(msgString) == dbiConn.m_msgStack.getLastMember().rdbmsMsgNb)
    {
        dbiConn.m_msgStack.popLastMember();
        return RET_SUCCEED;
    }

    DbaMsgStackMemberClass &msgMember = dbiConn.m_msgStack.getNewMember();

    msgMember.msgOrigin            = msgOrigin;
    msgMember.rdbmsMsgNb           = msgNumber;
    msgMember.retCode              = SYB_MsgError::getRetCode(static_cast<SYB_ERROR_CODE_ENUM>(msgNumber));
    msgMember.severity             = severity;
    msgMember.state                = state;
    msgMember.isAlreadyWritedInLog = bLogged;
    msgMember.line                 = line;

    if (msgMember.severity == 10 && 
        msgMember.retCode  == RET_SRV_LIB_ERR_UNKNOWN_MSG)
    {
        msgMember.retCode = RET_SRV_INFO_GEN_WARNING;
    }

    /* Save the procedure name */
    if (procedure != NULL)
    {
        msgMember.procedure = procedure;
    }

    /* Save the server name */
    if (serverName != NULL)
    {
        msgMember.serverName = serverName;
    }

    /* Save the message string */
    if (msgString != NULL)
    {
        msgMember.msgString = msgString;
    }
    return(RET_SUCCEED);
}



/************************************************************************
*   Function             : SYB_HandleMsg()
*
*   Description          : Callback function which handle the client library
*                          messages.
*
*
*   Arguments            : ctx          : a pointer on a CS_CONTEXT struct.
*                          csConnection : a pointer on a CS_CONNECTION struct.
*                          csCliMsg     : a pointer on a CS_CLIENTMSG struct.
*
*   Functions call       : MSG_SendMesg
*
*   Global var. modified : None
*
*   Return               : CS_SUCCEED
*
*   Creation date        : Apr.  94 - PEC
*   Last modification    : 03.11.95 - PEC - Added call to function DBA_SaveMsgInfos.
*                          PMSTA-23966 - 060716 - PMO : Some RPC free the input argument structure. This lead to server crash
*                          PMSTA-33076 - 071218 - PMO : Financial server crash when stopping
*
*************************************************************************/
int CS_PUBLIC SYB_HandleMsg(CS_CONTEXT *, CS_CONNECTION *csConnection, CS_CLIENTMSG *csCliMsg)
{
    if (false == SYS_IsStateShutdownRequested())    /* PMSTA-33076 - 071218 - PMO / PMSTA-31039 - DLA - 180820 */
    {
        const AAALogger& connectionLog = AAALogger::get(AAALogger::Logger::Connections);
        if (connectionLog.isInfoEnabled())
        {
            std::string	logMessage = SYS_Stringer("Message Number: ", csCliMsg->msgnumber, " - ",
                                                  "Severity: ", csCliMsg->severity, " - ",
                                                  "State: ", csCliMsg->sqlstate, " - ",
                                                  "Text: ", csCliMsg->msgstring);
            if (connectionLog.isTraceEnabled())
            {
                logMessage += " - Callstack: \n" + SYS_GetCallStack(0, true);
            }

            connectionLog.info(logMessage);
        }

        SybConnection *dbiConn = nullptr;
        bool logFlg = false;

        /* Login failed because Server name is invalid (not in $SYBASE/interfaces file) */
        if (csCliMsg->msgnumber == 84083715)
        {
            SV_FirstLoginState = LogFailed_InvalidServerName;
        }

        /* Login failed because Server is not running */
        if (csCliMsg->msgnumber == 84083972)
        {
            SV_FirstLoginState = LogFailed_ServerNotRunning;
        }

        /* Retrieve the connection server name from the connection list */
        if (csConnection != NULL)
        {
            dbiConn = static_cast<SybConnection*>(AAALocalConnectionProvider::get().find(nullptr, nullptr, nullptr, SYB_CompareCtConnect, (void *)csConnection));
        }

        switch (CS_SEVERITY(csCliMsg->msgnumber))
        {
            case CS_SV_INFORM:
            case CS_SV_CONFIG_FAIL:
            case CS_SV_RETRY_FAIL:
            case CS_SV_API_FAIL:
            case CS_SV_RESOURCE_FAIL:
            case CS_SV_INTERNAL_FAIL:
                break;

            case CS_SV_FATAL:
            case CS_SV_COMM_FAIL:
                /* REF3749 - SSO - 990703 ALL CONNEXIONS ARE UNUSABLE */
                if (dbiConn != nullptr)
                {
                    dbiConn->setValidConnection(false);
                }
                break;
        }

        if (nullptr != dbiConn && nullptr != dbiConn->getConnStructPtr())
        {
            dbiConn->setLastSybClSeverity(CS_SEVERITY(csCliMsg->msgnumber));
        }

        /* Do not display error message , when server try to connect an another server:
        * 1 dispatcher try to connect to all fusion server
        * 2 fusion server try to connect to dispatcher
        */

        if ((csCliMsg->msgnumber == 84083972) || (csCliMsg->msgnumber == 84083715)) /* SME REF3734 */
        {
            return (CS_SUCCEED);
        }

        if (ERROR_SNOL(csCliMsg->msgnumber, CS_SV_RETRY_FAIL, 63, 2, 1))
        {
            /*
            ** Get the timeout period. This is not really necessary, but
            ** demonstrated to show the correlation between timeout errors
            ** and the CS_TIMEOUT context property.
            */
            CS_INT     timeout_val = 0;
            char       msgstring[255];


            if (dbiConn != nullptr)
            {
                SYB_CtConProps(*dbiConn, CS_GET, CS_TIMEOUT,
                               &timeout_val, CS_UNUSED, NULL);
            }

            if (timeout_val == 0)
            {
                EV_rxaFctStruct.pfn_ct_config(SYB_GetCsContext(), CS_GET, CS_TIMEOUT,
                                              &timeout_val, CS_UNUSED,
                                              NULL);
            }

            sprintf(msgstring,
                    "Server has not responded in at least %d seconds. Canceling.",
                    int(timeout_val)); /* PMSTA-23966 - 060716 - PMO */

            MSG_SendMesg(RET_CLI_LIB_ERR_LIBMSG, 0, FILEINFO,
                (dbiConn != NULL) ? dbiConn->getSpecification().getServerName().c_str() : "Unknown Server",
                         CS_SEVERITY(csCliMsg->msgnumber), CS_NUMBER(csCliMsg->msgnumber),
                         msgstring);

            logFlg = true;

            if (csConnection != NULL)
            {
                (CS_VOID)EV_rxaFctStruct.pfn_ct_cancel(csConnection, NULL, CS_CANCEL_ATTN);
            }
            else
            {
                return (CS_FAIL);
            }
        }
        else if ((dbiConn == nullptr) || (dbiConn->isExternalMsgManagement() == false))
        {
            MSG_SendMesg(RET_CLI_LIB_ERR_LIBMSG, 0, FILEINFO,
                         (dbiConn != NULL) ? dbiConn->getSpecification().getServerName().c_str() : "Unknown Server",
                         CS_SEVERITY(csCliMsg->msgnumber), CS_NUMBER(csCliMsg->msgnumber), /* REF3749 - SSO - 990703 */
                         csCliMsg->msgstring);

            logFlg = true;
        }

        csCliMsg->msgstring[csCliMsg->msgstringlen] = END_OF_STRING;

        if (dbiConn != nullptr)
        {
            /* Save the message in the message stack associated to the connection */
            SYB_SaveMsgInfos(*dbiConn,
                             ClientHandler,
                             (int)csCliMsg->msgnumber,
                             (int)csCliMsg->severity,
                             (int)csCliMsg->status,
                             NULL,
                             NULL,
                             csCliMsg->msgstring,
                             0,
                             logFlg);
        }
    }
    return(CS_SUCCEED);
}


/************************************************************************
*   Function             : SYB_HandleSrvMsg()
*
*   Description          : Callback function which handle the client library
*                          messages.
*
*
*   Arguments            : csContext    : a pointer on a CS_CONTEXT struct.
*                          csConnection : a pointer on a CS_CONNECTION struct.
*                          csSrvMsg     : a pointer on a CS_SERVERMSG struct.
*
*   Functions call       : DBA_GetConnServerName
*                          MSG_SendMesg
*
*   Global var. modified : None
*
*   Return               : CS_SUCCEED
*
*   Creation date        : Apr.  94 - PEC
*   Last modification    : 03.11.95 - PEC - Added call to function DBA_SaveMsgInfos.
*                          21.02.96 - PEC - Added handling of message 916 "Server user ... is
*                                           not a valid user on database ...".
*                          09.04.96 - PEC - Ref : BUG016
*                          20.08.96 - PEC - Ref : BUG102
*                          18.09.96 - PEC - Ref : DVP178+ -> Deadlock handling
*                          07.02.97 - PEC - Ref : BUG286  -> Added Tests
*                          30.06.98: SME REF2455 : added error 701 (not enought procedure cache)
*                          FIH - 990617 - REF3249
*                          20.10.99 - XSH - REF3802
*                          REF10729 - 041103 - PMO : Synchronisation import / fusion
*                          PMSTA-16082 - 7.0.0 - Dispatch server logs tons on log is the ASE has shutdown
*                          PMSTA-33076 - 071218 - PMO : Financial server crash when stopping
*
*************************************************************************/
int CS_PUBLIC SYB_HandleSrvMsg(CS_CONTEXT *, CS_CONNECTION *csConnection, CS_SERVERMSG *csSrvMsg)
{
    if (false == SYS_IsStateShutdownRequested())    /* PMSTA-33076 - 071218 - PMO / PMSTA-31039 - DLA - 180820 */
    {
        const AAALogger& connectionLog = AAALogger::get(AAALogger::Logger::Connections);
        if ((connectionLog.isInfoEnabled() && csSrvMsg->severity != 10) ||
            connectionLog.isDebugEnabled())
        {
            std::string	logMessage = SYS_Stringer("Message Number: ", csSrvMsg->msgnumber, " - ",
                                                  "Severity: ", csSrvMsg->severity, " - ",
                                                  "State: ", csSrvMsg->state, " - ",
                                                  "Proc.: ", csSrvMsg->proc, " - ",
                                                  "Text: ", csSrvMsg->text,
                                                  "Line: ", csSrvMsg->line);
            if (connectionLog.isTraceEnabled())
            {
                logMessage += " - Callstack: \n" + SYS_GetCallStack(0, true);
            }

            connectionLog.info(logMessage);
        }

        std::string             dbName;
        bool                    logFlg = false;

        /* Stop the financial server when the database is/will be down PMSTA-16082 - 230413 - PMO */
        const bool              dataBaseShutdown = 10 == csSrvMsg->severity && (6002 == csSrvMsg->msgnumber
                                                                                || 6003 == csSrvMsg->msgnumber
                                                                                || 6005 == csSrvMsg->msgnumber
                                                                                || 6006 == csSrvMsg->msgnumber
                                                                                );

        /* Login failed because the user cannot access to database  */
        if (csSrvMsg->msgnumber == 916)
        {
            SV_FirstLoginState = LogFailed_DbAccessDenied;
        }

        /* Login failed because the login used is invalid or not authorized  */
        if (csSrvMsg->msgnumber == 4002)
        {
            SV_FirstLoginState = LogFailed_InvalidLogin;
        }

        /*
        * If the message is the INFO message "Changed database context..."(severity no 10),
        * it is not recorded in the log
        */

        if (csSrvMsg->severity == 10 &&
            (csSrvMsg->msgnumber == 5701 ||
             csSrvMsg->msgnumber == 1918 ||   /* Non-clustered index (index id = %d) is being rebuilt. */
             csSrvMsg->msgnumber == 5703 ||
             csSrvMsg->msgnumber == 5704 ||   /* DVP493, Changed charset setting. */
             csSrvMsg->msgnumber == 3621 ||
             csSrvMsg->msgnumber == 2528 ||   /* PMSTA-37374 - LJE - 201214 - DBCC execution completed. If DBCC printed error messages, contact a user with System Administrator (SA) role.*/

             /* PMSTA-43914 - LJE - 210315 */
             csSrvMsg->msgnumber == 1805 ||   /* CREATE DATABASE: allocating... */
             csSrvMsg->msgnumber == 954 ||    /* Warning: The database 'aaamaindb' is using an unsafe virtual device 'main_data1'. The recovery of this database can not be guaranteed. */
             csSrvMsg->msgnumber == 12893 ||   /* Processed 155 allocation unit(s) out of 1550 units (allocation page 21248). 10% completed. */
             csSrvMsg->msgnumber == 3444 ||   /* Database 'aaamaindb' is now online. exec sp_addgroup triplea */
             csSrvMsg->msgnumber == 5005 ||   /* Extending database by 64000 pages... */
             csSrvMsg->msgnumber == 5038 ||   /* Warning: Using ALTER DATABASE to extend the log segment will cause user thresholds on the log segment within 128 pages of the last chance threshold to be disabled. */
             csSrvMsg->msgnumber == 5884 ||   /* This is an informational message. Unless otherwise specified, no action is required. */
             csSrvMsg->msgnumber == 2536 ||   /* Checking %.*s: Logical pagesize is %ld bytes */
             csSrvMsg->msgnumber == 2537 ||
             csSrvMsg->msgnumber == 2551 ||   /* The following segments have been defined for database %d (database name %S_DBID). */
             csSrvMsg->msgnumber == 2552 ||
             csSrvMsg->msgnumber == 2553 ||
             csSrvMsg->msgnumber == 2554 ||

             csSrvMsg->msgnumber == 2411 ||   /* BUG102 Message : No conversions will be done */
             csSrvMsg->msgnumber == 11065 ||   /* DLA - REF9557 - 031017 */
             csSrvMsg->msgnumber == 4986 ||    /* Warning: trigger 'INSERT' is already disabled. */
             csSrvMsg->msgnumber == 4987 ||    /* Enabling trigger 'INSERT'. */
             csSrvMsg->msgnumber == 4988 ||    /* Disabling trigger 'INSERT'. */
             (csSrvMsg->msgnumber >= 13900 && csSrvMsg->msgnumber <= 13999) ||   /* alter table warnings */
             csSrvMsg->msgnumber == 0))        /* BUG016 */
        {
            if (SYS_IsSqlMode() == TRUE)
            {
                if (csSrvMsg->msgnumber == 0)
                {
                    /* For #PRINT behavior */
                    cout << csSrvMsg->text << endl;
                }
                else if (csSrvMsg->msgnumber == 5884 ||
                         csSrvMsg->msgnumber == 2536 ||
                         csSrvMsg->msgnumber == 2537 ||
                         csSrvMsg->msgnumber == 2551 ||
                         csSrvMsg->msgnumber == 2552 ||
                         csSrvMsg->msgnumber == 2553 ||
                         csSrvMsg->msgnumber == 2554)
                {
                    cout << csSrvMsg->text;
                }
            }

            return(CS_SUCCEED);
        }

        /* REF3802 - XSH - 991020 - S */
        if (csSrvMsg->msgnumber == 7412)
        {
            MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "Space available in the log segment has fallen critically low in database");
            return(CS_SUCCEED);
        }
        /* REF3802 - XSH - 991020 - E */

        /* BEGIN BUG102 - PEC */
        /* Message : Cannot find the requested character set in Syscharsets: id = %d. */
        /* Message : Cannot find the requested character set in Syscharsets: name = '%.*s'. */

        if (csSrvMsg->msgnumber == 2408 || csSrvMsg->msgnumber == 2409)
        {
            return(CS_SUCCEED);
        }
        /* END   BUG102 - PEC */

        /* Retrieve the connection server name from the connection list */
        SybConnection *dbiConn = static_cast<SybConnection*>(AAALocalConnectionProvider::get().find(nullptr, nullptr, nullptr, SYB_CompareCtConnect, (void *)csConnection));

        if (csSrvMsg->text[csSrvMsg->textlen - 1] == '\n')
        {
            csSrvMsg->text[csSrvMsg->textlen - 1] = ' ';
        }

        csSrvMsg->text[csSrvMsg->textlen]    = END_OF_STRING;
        csSrvMsg->svrname[csSrvMsg->svrnlen] = END_OF_STRING;
        csSrvMsg->proc[csSrvMsg->proclen]    = END_OF_STRING;

        GEN_GetApplInfo(ApplSqlDbName, dbName);

        if (csSrvMsg->text[0] != END_OF_STRING)
        {
            /*** If GUI process  OR  Importation process ***/
            if (SYS_IsGuiMode() == TRUE || SYS_IsBatchMode() == TRUE || SYS_IsSqlMode() == TRUE)
            {
                DBA_ERRMSG_INFOS_ST msgStruct(FILEINFO);

                /* If the message is generated by a trigger */
                if (strstr(csSrvMsg->text, "lev=") != NULL)
                {
                    if (dbiConn != nullptr)
                    {
                        SYB_SaveMsgInfos(*dbiConn,
                                         ServerHandler,
                                         csSrvMsg->msgnumber,
                                         csSrvMsg->severity,
                                         csSrvMsg->state,
                                         csSrvMsg->proc,
                                         dbiConn->getSpecification().getServerName().c_str(),
                                         csSrvMsg->text,
                                         csSrvMsg->line,
                                         logFlg);
                    }
                    else
                    {
                        MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, csSrvMsg->text);
                    }

                    return(CS_SUCCEED);
                }

                msgStruct.msgOrigin = ServerHandler;
                msgStruct.rdbmsMsgNb = csSrvMsg->msgnumber;
                msgStruct.retCode = SYB_MsgError::getRetCode(static_cast<SYB_ERROR_CODE_ENUM>(csSrvMsg->msgnumber));     /* PMSTA-nuodb - LJE - 190710 */
                msgStruct.line = csSrvMsg->line; /* PMSTA-14452 - LJE - 121205 */

                msgStruct.serverName = csSrvMsg->svrname;
                msgStruct.procedure = csSrvMsg->proc;
                msgStruct.msgString = csSrvMsg->text;
                msgStruct.rdbmsMsgString = csSrvMsg->text;

                bool  ignoreLog = false; /* PMSTA-18048 - SHR - FIX user import error */

                switch (csSrvMsg->msgnumber)
                {
                    case 10316: /* PMSTA-13926 */
                    case 11188: /* PMSTA-18048 - DDV - 140602 - Fix user import error */
                        ignoreLog = true; /* PMSTA-18048 - SHR - FIX user import error */
                        /* fallthrough */
                    case 515:      /* Not Null constraints */
                    case 530:      /* Attempt to insert NULL ..... */
                    case 640:      /* Attempt to insert missing OAM entry failed ... */
                    case 2601:     /* Primary key constraint & Unique key constraints */
                    case 2615:     /* Primary key constraint & Unique key constraints */

                    case 101:      /* Syntax Error  */
                    case 102:      /* Syntax Error  */
                    case 148:      /* Syntax Error  */
                    case 149:      /* Syntax Error  */
                    case 156:      /* Syntax Error  */
                    case 210:      /* Syntax Error  */
                    case 211:      /* Syntax Error  */
                    case 249:      /* Syntax Error  */
                    case 1273:     /* Syntax Error  */
                    case 5129:     /* Syntax Error  */

                        /**** BEGIN DVP178+ ****/
                    case 1139:
                    case 1205:
                    case 1248:      /* Deadlocks messages */
                    case 3210:
                    case 3309:
                    case 13093:
                        /**** END  DVP178+ ****/

                    case 701:      /* not enough procedure cache memory */
                    case 4002:      /* Login failed GRD */
                    case 17720: /* PMSTA-13926 */
                    case 99999:
                        break;

                    default:
                        if ((ignoreLog == false) && ((dbiConn == nullptr) || (dbiConn->isExternalMsgManagement() == false)))    /* PMSTA-18048 - SHR - FIX user import error */
                        {
                            MSG_LogMesgWithMsgStruct(RET_SRV_LIB_ERR_UNKNOWN_MSG, &msgStruct, FILEINFO);
                        }
                        logFlg = TRUE;
                }
            }
            else            /* Server process. */
            {
                switch (csSrvMsg->msgnumber)
                {
                    case 515:      /* Not Null constraints */
                    case 530:      /* Attempt to insert NULL ..... */
                    case 640:      /* Attempt to insert missing OAM entry failed ... */
                    case 2601:     /* Primary key constraint & Unique key constraints */
                    case 2615:     /* Primary key constraint & Unique key constraints */

                    case 101:      /* Syntax Error */
                    case 102:      /* Syntax Error */
                    case 148:      /* Syntax Error */
                    case 149:      /* Syntax Error */
                    case 156:      /* Syntax Error */
                    case 210:      /* Syntax Error */
                    case 211:      /* Syntax Error */
                    case 249:      /* Syntax Error */
                    case 1273:     /* Syntax Error */
                    case 5129:     /* Syntax Error */

                        /**** BEGIN DVP178+ ****/
                    case 1139:
                    case 1205:
                    case 1248:      /* Deadlocks messages */
                    case 3210:
                    case 3309:
                    case 13093:
                        /**** END  DVP178+ ****/

                    case 701:      /* not enough procedure cache */
#ifndef AAADEBUGMSG
                        break;
#endif

                    default:
                        if (csSrvMsg->textlen > 0)
                        {
                            if ((csSrvMsg->proclen > 0) && ((dbiConn == nullptr) || (dbiConn->isExternalMsgManagement() == false)))
                            {
                                logFlg = TRUE;

                                /* REF10729 - 041103 - PMO
                                * Don't write this error message
                                */
                                if (RET_FUS_UPDATE_WHILE_FUSION_RUNNING1 == csSrvMsg->msgnumber
                                    || RET_FUS_UPDATE_WHILE_FUSION_RUNNING2 == csSrvMsg->msgnumber)
                                {
                                    /*
                                    *  Don't write this message
                                    */
                                }
                                else
                                {
                                    MSG_SendMesg(RET_SRV_LIB_ERR_SRVMSG,
                                                 1,
                                                 FILEINFO,
                                                 (dbiConn != NULL) ? dbiConn->getSpecification().getServerName().c_str() : "Unknown Server",
                                                 dbName.c_str(),
                                                 csSrvMsg->proc,
                                                 csSrvMsg->text);
                                }
                            }
                            else if (dbiConn == nullptr || dbiConn->isExternalMsgManagement() == false)
                            {
                                logFlg = TRUE;

                                MSG_SendMesg(RET_SRV_LIB_ERR_SRVMSG, 1, FILEINFO,
                                             (dbiConn != NULL) ? dbiConn->getSpecification().getServerName().c_str() : "Unknown Server",
                                             dbName.c_str(), "", csSrvMsg->text);

                            }

                            /* PMSTA-16082 - 230413 - PMO */
                            if (true == dataBaseShutdown)
                            {
                                MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "Stopping the financial server because the database is down");
                                SYS_Shutdown(EXIT_FAILURE);        /* DLA - PMSTA-26546 - 170314 */
                            }
                        }
                }
            }
        }

        if (csSrvMsg->msgnumber != 4002 &&
            csSrvMsg->msgnumber != 10316 && /* New password supplied is the same as the previous password.  Please supply a different new password. */
            csSrvMsg->msgnumber != 11188)   /* Cannot alter login. */
        {
            if (dbiConn != nullptr)
            {
                /* Save the message in the message stack associated to the connection */
                SYB_SaveMsgInfos(*dbiConn,
                                 ServerHandler,
                                 csSrvMsg->msgnumber,
                                 csSrvMsg->severity,
                                 csSrvMsg->state,
                                 csSrvMsg->proc,
                                 dbiConn->getSpecification().getServerName().c_str(),
                                 csSrvMsg->text,
                                 csSrvMsg->line, /* PMSTA-14452 - LJE - 130115 */
                                 logFlg);
            }
            else
            {
                /*  FIH-REF3249-990617  First login failed.                 */
                /*  More precise message display in function DBI_ScanCfg    */
                MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, csSrvMsg->text); /* BUG286 */
            }
        }
    }
    return(CS_SUCCEED);
}



/* Cleanup to avoid Warning */

#include <map>

std::map<void *, size_t>    SV_MapAllocation;                       /* PMSTA-18094 - 130514 - PMO */

static pthread_mutex_t      SV_MutexMapAllocation;                  /* PMSTA-18094 - 130514 - PMO */
static pthread_mutexattr_t  SV_MutexAttrMapAllocation;              /* PMSTA-18094 - 130514 - PMO */

static int statusMutexMapAllocation = OS_CreatePosixMutex(&SV_MutexMapAllocation, &SV_MutexAttrMapAllocation);

/* Sybase store password only on block of these sizes */
#define BLOCK_WITH_SYBASE_PASSWORD(size) ((1024 == size || 1064 == size))


/************************************************************************
*   Function             : SYB_Malloc()
*
*   Description          : Allocate a memory block. Wellknow Sybase memory block size are stored into the mapAllocation and processed later on demand for removing password
*                          Call the standard malloc function
*
*   Arguments            : size Memory block size
*
*   Functions call       : None
*
*   Global var. modified : None
*
*   Return               : None
*
*   Creation date        : PMSTA-18094 - 130514 - PMO : Avoid extracting the user credentials from the GUI running on Windows (via dump, etc.)
*
*   Last Modif. Date     :
*
*************************************************************************/
void * SYB_Malloc(size_t size)
{
    void * p = malloc(size);

    if (p != NULL && true == BLOCK_WITH_SYBASE_PASSWORD(size))
    {
        int lockStatus;

        (void)OS_LockPosixMutex(&SV_MutexMapAllocation, WAIT, FALSE, &lockStatus);

        SV_MapAllocation[p] = size;

        (void)OS_UnlockPosixMutex(&SV_MutexMapAllocation);
    }

    return p;
}


/************************************************************************
*   Function             : SYB_SearchClearPassword()
*
*   Description          : Search the password in the memory block provided.
*                          This apply only on some wellknow Sybase memory blocks
*
*   Arguments            : p        Pointer to the memory where password might be stored
*                          size     Size of the memory block
*                          pwd      Password to serach and remove
*                          pwdlen   Password length
*
*   Functions call       : None
*
*   Global var. modified : None
*
*   Return               : None
*
*   Creation date        : PMSTA-18094 - 130514 - PMO : Avoid extracting the user credentials from the GUI running on Windows (via dump, etc.)
*
*   Last Modif. Date     :
*
*************************************************************************/
void SYB_SearchClearPassword(char * p, size_t size, const char * pwd, size_t pwdlen)
{
    if (pwdlen > 0 && size > pwdlen && true == BLOCK_WITH_SYBASE_PASSWORD(size))
    {
        const size_t    sizeEnd = size - pwdlen;
        char *          tabPwd[3] = { NULL, NULL, NULL };
        int             idxtabPwd = 0;

        for (size_t idx = 0; idx < sizeEnd; idx++)
        {
            if (0 == strncmp(p + idx, pwd, pwdlen))
            {
                tabPwd[idxtabPwd] = p + idx;
                idxtabPwd++;

                if (3 == idxtabPwd)
                {
                    break;
                }
            }
        }

        if ((2 == idxtabPwd && 142 == (tabPwd[1] - tabPwd[0]))
            && ((1024 == size && 70 == (tabPwd[0] - p))
                || (1064 == size && 94 == (tabPwd[0] - p))
                )
            )
        {
            DBA_PasswordClear(tabPwd[0], pwdlen);
            DBA_PasswordClear(tabPwd[1], pwdlen);
        }
    }
}


/************************************************************************
*   Function             : SYB_Free()
*
*   Description          : Try to clear the password if it is found. After Free the memory
*
*   Arguments            : p    Pointer to the memory to free
*
*   Functions call       : None
*
*   Global var. modified : None
*
*   Return               : None
*
*   Creation date        : PMSTA-18094 - 130514 - PMO : Avoid extracting the user credentials from the GUI running on Windows (via dump, etc.)
*
*   Last Modif. Date     : PMSTA-19828 - 220115 - PMO : Bad memory read in the GUI
*
*************************************************************************/
void SYB_Free(void * p)
{
    if (NULL != p)
    {
        int lockStatus;

        (void)OS_LockPosixMutex(&SV_MutexMapAllocation, WAIT, FALSE, &lockStatus);

        std::map<void *, size_t>::const_iterator it = SV_MapAllocation.find(p);

        if (it != SV_MapAllocation.end())
        {
            SV_MapAllocation.erase(p);
        }

        (void)OS_UnlockPosixMutex(&SV_MutexMapAllocation);
    }

    free(p);
}


/************************************************************************
*   Function             : SYB_ClearPasswordSybaseMemory()
*
*   Description          : Browse memory allocated by Sybase and clear the password given in argument if found
*
*   Arguments            : pwd  Password to search
*
*   Functions call       : None
*
*   Global var. modified : None
*
*   Return               : None
*
*   Creation date        : PMSTA-18094 - 130514 - PMO : Avoid extracting the user credentials from the GUI running on Windows (via dump, etc.)
*
*   Last Modif. Date     :
*
*************************************************************************/
void SYB_ClearPasswordSybaseMemory(const char * pwd)
{
    const size_t  pwdlen = strlen(pwd);

    int lockStatus;

    (void)OS_LockPosixMutex(&SV_MutexMapAllocation, WAIT, FALSE, &lockStatus);

    for (std::map<void *, size_t>::const_iterator it = SV_MapAllocation.begin(); it != SV_MapAllocation.end(); ++it)
    {
        char *          p = (char *)it->first;         /* Memory block */
        const size_t    size = it->second;                  /* Block size   */

        SYB_SearchClearPassword(p, size, pwd, pwdlen);
    }

    (void)OS_UnlockPosixMutex(&SV_MutexMapAllocation);
}


/************************************************************************
*   Function             : SYB_InitializeContext()
*
*   Description          : Allocate an application context, install
*                          message handlers and conversion functions for
*                          dates fields.
*
*   Arguments            : installMemoryCallBack    If Sybase memory callback must be installed
*
*   Functions call       : None
*
*   Global var. modified : EV_ApplContext
*
*   Return               : RET_DBA_ERR_ALLOCSYBCTX : if context alloc. failed
*                          RET_DBA_ERR_INITSYBCTX  : if client initializ. failed
*                          RET_SUCCEED             : if ok
*
*   Creation date        : Apr. 94 - PEC
*   Last Modif. Date     : 29.8.95 - PEC
*                          21.7.03 - DLA
*                        : DLA - REF8960 - 030409
*                          PMSTA-18094 - 130514 - PMO : Avoid extracting the user credentials from the GUI running on Windows (via dump, etc.)
*                          PMSTA-21641 - 071115 - PMO : GUI Oracle Fusion fails
*                          PMSTA-30889 - 100418 - PMO : SYBASE VS ORACLE: financial server crash while running the PVN_PMSTA_9790 TaAutomator test case
*
*************************************************************************/
RET_CODE SYB_InitializeContext(const bool installMemoryCallBack)                    /* PMSTA-18094 - 130514 - PMO */
{
    /* Allocate the CS_CONTEXT structure */
    if (EV_rxaFctStruct.pfn_cs_ctx_alloc(SYBASE_VERSION, (void **)&EV_ApplContext) != CS_SUCCEED)
    {
        MSG_SendMesg(FILEINFO, "Sybase Context Allocation Error");                  /* PMSTA-21641 - 071115 - PMO */
        return(RET_DBA_ERR_ALLOCSYBCTX);
    }

    /* Initialize client application for Sybase version */
    if (EV_rxaFctStruct.pfn_ct_init(EV_ApplContext, SYBASE_VERSION) != CS_SUCCEED)
    {
        MSG_SendMesg(FILEINFO, "Sybase Context Initialization Error");              /* PMSTA-21641 - 071115 - PMO */
        return(RET_DBA_ERR_INITSYBCTX);
    }

    /* PMSTA-18094 - 130514 - PMO */
    if (true == installMemoryCallBack)
    {
        if (CS_SUCCEED != EV_rxaFctStruct.pfn_ct_config(EV_ApplContext, CS_SET, CS_USER_ALLOC, (CS_VOID*)SYB_Malloc, CS_UNUSED, NULL))
        {
            return RET_DBA_ERR_SETSYBCB;
        }

        if (CS_SUCCEED != EV_rxaFctStruct.pfn_ct_config(EV_ApplContext, CS_SET, CS_USER_FREE, (CS_VOID*)SYB_Free, CS_UNUSED, NULL))
        {
            return RET_DBA_ERR_SETSYBCB;
        }
    }

    /* Install callback functions */
    if ((EV_rxaFctStruct.pfn_ct_callback(EV_ApplContext, NULL, CS_SET, CS_CLIENTMSG_CB, (CS_VOID *)SYB_HandleMsg) != CS_SUCCEED) ||
        (EV_rxaFctStruct.pfn_ct_callback(EV_ApplContext, NULL, CS_SET, CS_SERVERMSG_CB, (CS_VOID *)SYB_HandleSrvMsg) != CS_SUCCEED) ||
        (EV_rxaFctStruct.pfn_ct_callback(EV_ApplContext, NULL, CS_SET, CS_NOTIF_CB, (CS_VOID *)SYB_ServerNotification) != CS_SUCCEED))
    {
        return(RET_DBA_ERR_SETSYBCB);
    }

    const RET_CODE ret = SYB_InstallConversionFcts();                               /* PMSTA-18094 - 130514 - PMO */

    CS_INT timeOut = CS_NO_LIMIT;
    char    *pTimeOut;

    if ((pTimeOut = getenv("AAATIMEOUT")) != NULL)
    {
        timeOut = atoi(pTimeOut);

        if (timeOut <= 0)
        {
            timeOut = CS_NO_LIMIT;
        }
    }

    if (EV_rxaFctStruct.pfn_ct_config(EV_ApplContext, CS_SET, CS_TIMEOUT, (CS_VOID *)&timeOut, CS_UNUSED, NULL) != CS_SUCCEED)
    {
        return RET_DBA_ERR_SETSYBCB;
    }

    if (RET_SUCCEED == ret)
    {   /* Register the function that will free the Sybase context when the program will finish PMSTA-30889 - 100418 - PMO */
        SYS_AddCallBackForProgramState(ProgramState::ShutdownGlobalMemoryFree, SYB_FreeSybCliContext);
    }

    /* PMSTA-nuodb - LJE - 190424 - Move here */
    char *p;
    if ((p = SYS_GetEnv("AAAPACKETSIZE")) != NULL)
    {
        EV_SybPacketSize = atoi(p);

        if (EV_SybPacketSize < 256 || EV_SybPacketSize>9999)
        {
            EV_SybPacketSize = 0;
        }
    }

    return ret;
}

/************************************************************************
*   Function             : SYB_ConvertDateToInt()
*
*   Description          : Conversion routine between Sybase Date format
*                          (CS_DATETIME4_TYPE/CS_DATETIME_TYPE) and application
*                          date (DATE_T type (long)).
*                          Callback routine called automatically by ct_bind().
*
*   Arguments            : csContext : a pointer on a CS_CONTEXT structure.
*                          srcfmt    : format of the source variable
*                          srcdata   : value of the source variable
*                          destfmt   : format of the destination variable
*                          destdata  : value of the destination variable
*                          destlen   : length of the destination variable
*
*   Functions call       : None
*
*   Global var. modified : None
*
*   Return               : Sybase values (cf function "cs_set_convert")
*
*   Creation date        : June 94 - PEC
*   Last Modif. Date     :
*************************************************************************/
CS_RETCODE CS_PUBLIC SYB_ConvertDateToInt(CS_CONTEXT *csContext, CS_DATAFMT *, CS_VOID *srcdata,
                                          CS_DATAFMT *, CS_VOID *destdata, CS_INT *)
{
    CS_DATEREC  csDateRec;
    DATE_T      tmpVar;

    memset(&csDateRec, 0, sizeof(CS_DATEREC));

    EV_rxaFctStruct.pfn_cs_dt_crack(csContext, CS_DATETIME_TYPE, srcdata, &csDateRec);

    tmpVar = (DATE_T)DATE_Put((YEAR_T)csDateRec.dateyear, (MONTH_T)(csDateRec.datemonth + 1), (DAY_T)csDateRec.datedmonth);

    memcpy(destdata, &tmpVar, sizeof(DATE_T));

    return(CS_SUCCEED);
}

/************************************************************************
*   Function             : SYB_ConvertIntToDate()
*
*   Description          : Conversion routine between application date
*                          (DATE_T type (long)) and Sybase Date format
*                          (CS_DATETIME4_TYPE/CS_DATETIME_TYPE)
*
*                          Callback routine called automatically by ct_bind().
*
*   Arguments            : csContext : a pointer on a CS_CONTEXT structure.
*                          srcfmt    : format of the source variable
*                          srcdata   : value of the source variable
*                          destfmt   : format of the destination variable
*                          destdata  : value of the destination variable
*                          destlen   : length of the destination variable
*
*   Functions call       : None
*
*   Global var. modified : None
*
*   Return               : Sybase values (cf function "cs_set_convert")
*
*   Creation date        : 08 97  XAJ
*
*   Last Modif. Date     : PMSTA-15918 - 070213 - PMO : Fusion on portfolio [T_AI_PE_ST] failed ; upd_exd_position : Attempt to insert NULL value into column 'end_d', table position
*
*************************************************************************/
CS_RETCODE CS_PUBLIC SYB_ConvertIntToDate(CS_CONTEXT *,
                                          CS_DATAFMT *, CS_VOID  *srcdata,
                                          CS_DATAFMT *, CS_VOID  *destdata,
                                          CS_INT     *destlen)
{
    DATE_T            refDate;
    long              daysNbr;

    /* Compose the Sybase reference date (1 jan 1900) */
    refDate = DATE_Put((YEAR_T)1900, (MONTH_T)1, (DAY_T)1);

    DATE_DaysBetween(refDate, (*(DATE_T*)srcdata), AccrRule_Actual_365, &daysNbr, 0);    /* PMSTA-15918 - 070213 - PMO */  /* PMSTA-22396  - SRIDHARA – 160430 */

    ((CS_DATETIME*)destdata)->dtdays = daysNbr;
    ((CS_DATETIME*)destdata)->dttime = 0;

    *destlen = sizeof(CS_DATETIME);

    return(CS_SUCCEED);
}

/************************************************************************
*   Function             : SYB_ConvertDoubleToDate()
*
*   Description          : Conversion routine between application date
*                          (DATE_T type (long)) and Sybase Date format
*                          (CS_DATETIME4_TYPE/CS_DATETIME_TYPE)
*
*                          Callback routine called automatically by ct_bind().
*
*   Arguments            : csContext : a pointer on a CS_CONTEXT structure.
*                          srcfmt    : format of the source variable
*                          srcdata   : value of the source variable
*                          destfmt   : format of the destination variable
*                          destdata  : value of the destination variable
*                          destlen   : length of the destination variable
*
*   Functions call       : None
*
*   Global var. modified : None
*
*   Return               : Sybase values (cf function "cs_set_convert")
*
*   Creation date        : 08 97  XAJ
*   Last Modif. Date     : PMSTA-15918 - 070213 - PMO : Fusion on portfolio [T_AI_PE_ST] failed ; upd_exd_position : Attempt to insert NULL value into column 'end_d', table position
*
*************************************************************************/
CS_RETCODE CS_PUBLIC SYB_ConvertDoubleToDate(CS_CONTEXT *,
                                             CS_DATAFMT *, CS_VOID  *srcdata,
                                             CS_DATAFMT *, CS_VOID  *destdata,
                                             CS_INT     *destlen)
{
    DATE_T            refDate;
    HOUR_T            hour;
    MINUTE_T          min;
    SECOND_T          second;
    long              daysNbr;

    /* Compose the Sybase reference date (1 jan 1900) */
    refDate = DATE_Put((YEAR_T)1900, (MONTH_T)1, (DAY_T)1);

    DATE_DaysBetween(refDate,
        ((DATETIME64_STP)(srcdata))->date(),
                     AccrRule_Actual_365,
                     &daysNbr, 0);                               /* PMSTA-15918 - 070213 - PMO */  /* PMSTA-22396  - SRIDHARA – 160430 */

    TIME_Get(((DATETIME64_STP)(srcdata))->time(),
             &hour,                                           /* PMSTA-15918 - 070213 - PMO */
             &min,                                            /* PMSTA-15918 - 070213 - PMO */
             &second);                                        /* PMSTA-15918 - 070213 - PMO */

    ((CS_DATETIME*)destdata)->dtdays = daysNbr;
    ((CS_DATETIME*)destdata)->dttime = (INT_T)(hour * 3600 + min * 60 + second) * 300;

    *destlen = sizeof(CS_DATETIME);

    return(CS_SUCCEED);
}

/************************************************************************
*   Function             : SYB_ConvertSmallDateToDouble()
*
*   Description          : Conversion routine between Sybase Date format
*                          (CS_DATETIME4_TYPE/CS_DATETIME_TYPE) and application
*                          date (DATETIME_ST structure).
*                          Callback routine called automatically by ct_bind().
*
*   Arguments            : csContext : a pointer on a CS_CONTEXT structure.
*                          srcfmt    : format of the source variable
*                          srcdata   : value of the source variable
*                          destfmt   : format of the destination variable
*                          destdata  : value of the destination variable
*                          destlen   : length of the destination variable
*
*   Functions call       : None
*
*   Global var. modified : None
*
*   Return               : Sybase values (cf function "cs_set_convert")
*
*   Creation date        : June 94 - PEC
*   Last Modif. Date     :
*************************************************************************/
CS_RETCODE CS_PUBLIC SYB_ConvertSmallDateToDouble(CS_CONTEXT *csContext, CS_DATAFMT *, CS_VOID *srcdata,
                                                  CS_DATAFMT *, CS_VOID *destdata, CS_INT *)
{
    CS_DATEREC    csDateRec;
    DATETIME64_ST datetime;

    memset(&csDateRec, 0, sizeof(CS_DATEREC));

    /* Extract the machine-readable date */
    EV_rxaFctStruct.pfn_cs_dt_crack(csContext, CS_DATETIME4_TYPE, srcdata, &csDateRec);

    /* Compose the date number */
    datetime.setDate(DATE_Put((YEAR_T)csDateRec.dateyear,
                              (MONTH_T)(csDateRec.datemonth + 1),
                              (DAY_T)csDateRec.datedmonth));

    /* PMSTA-45413 - LJE - 210714 */
    MICROSECOND_T microSec = 0;
    if (EV_EnableMicrosecTime)
    {
        if (csDateRec.datesecfrac != 0)
        {
            microSec = static_cast<MICROSECOND_T>(csDateRec.datesecfrac / 1000);
        }
        else
        {
            microSec = static_cast<MICROSECOND_T>(csDateRec.datemsecond * 1000);
        }
    }

    /* Compose the time number */
    datetime.setTime(TIME_Put((HOUR_T)csDateRec.datehour,
                              (MINUTE_T)csDateRec.dateminute,
                              (SECOND_T)csDateRec.datesecond,
                              microSec));

    /* Copy the result in the bound allocation */
    memcpy(destdata , &datetime, sizeof(DATETIME64_ST));

    return(CS_SUCCEED);
}

/************************************************************************
*   Function             : SYB_ConvertDateToDouble()
*
*   Description          : Conversion routine between Sybase Date format
*                          (CS_DATETIME4_TYPE/CS_DATETIME_TYPE) and application
*                          date (DATETIME_ST structure).
*                          Callback routine called automatically by ct_bind().
*
*   Arguments            : csContext : a pointer on a CS_CONTEXT structure.
*                          srcfmt    : format of the source variable
*                          srcdata   : value of the source variable
*                          destfmt   : format of the destination variable
*                          destdata  : value of the destination variable
*                          destlen   : length of the destination variable
*
*   Functions call       : None
*
*   Global var. modified : None
*
*   Return               : Sybase values (cf function "cs_set_convert")
*
*   Creation date        : June 94 - PEC
*   Last Modif. Date     :
*************************************************************************/
CS_RETCODE CS_PUBLIC SYB_ConvertDateToDouble(CS_CONTEXT *csContext, CS_DATAFMT *, CS_VOID *srcdata,
                                             CS_DATAFMT *, CS_VOID *destdata, CS_INT *)
{
    CS_DATEREC  csDateRec;
    DATETIME64_ST datetime;

    memset(&csDateRec, 0, sizeof(CS_DATEREC));

    /* Extract the machine-readable date */
    EV_rxaFctStruct.pfn_cs_dt_crack(csContext, CS_DATETIME_TYPE, srcdata, &csDateRec);

    /* Compose the date number */
    datetime.setDate(DATE_Put((YEAR_T)csDateRec.dateyear,
                              (MONTH_T)(csDateRec.datemonth + 1),
                              (DAY_T)csDateRec.datedmonth));

    /* PMSTA-45413 - LJE - 210714 */
    MICROSECOND_T microSec = 0;
    if (EV_EnableMicrosecTime)
    {
        if (csDateRec.datesecfrac != 0)
        {
            microSec = static_cast<MICROSECOND_T>(csDateRec.datesecfrac / 1000);
        }
        else
        {
            microSec = static_cast<MICROSECOND_T>(csDateRec.datemsecond * 1000);
        }
    }

    /* Compose the time number */
    datetime.setTime(TIME_Put((HOUR_T)csDateRec.datehour,
                              (MINUTE_T)csDateRec.dateminute,
                              (SECOND_T)csDateRec.datesecond,
                              microSec));

    /* Copy the result in the bound allocation */
    memcpy(destdata, &datetime, sizeof(DATETIME64_ST));

    return(CS_SUCCEED);
}

/************************************************************************
*   Function             : SYB_ConvertUnicodeToText()
*
*   Description          : Conversion routine between Sybase CS_TEXT_TYPE
*                          and application CS_UNICHAR_FROM_TEXT_TYPE.
*                          Callback routine called automatically by ct_bind().
*
*   Arguments            : csContext : a pointer on a CS_CONTEXT structure.
*                          srcfmt    : format of the source variable
*                          srcdata   : value of the source variable
*                          destfmt   : format of the destination variable
*                          destdata  : value of the destination variable
*                          destlen   : length of the destination variable
*
*   Return               : Sybase values (cf function "cs_set_convert")
*
*   Creation date        : REF9303 - 030731 - PCL
*
*************************************************************************/
CS_RETCODE CS_PUBLIC SYB_ConvertUnicodeToText(
    CS_CONTEXT *,
    CS_DATAFMT *srcfmt, CS_VOID *srcdata,
    CS_DATAFMT *destfmt, CS_VOID *destdata,
    CS_INT *destlen)
{
    int status;

    if (srcfmt->format != CS_FMT_UNUSED ||
        destfmt->format != CS_FMT_UNUSED &&
        destfmt->format != CS_FMT_NULLTERM)
        return CS_ENOXLT;

    if (destfmt->format == CS_FMT_NULLTERM)
    {
        status =
            ICU4AAA_ConvertToHTML(
            (const UChar *)srcdata, srcfmt->maxlength / 2,
                (char *)destdata, destfmt->maxlength - 1,
                (int *)destlen);

        ((char *)destdata)[(*destlen)++] = 0;
    }
    else
        status =
        ICU4AAA_ConvertToHTML(
        (const UChar *)srcdata, srcfmt->maxlength / 2,
            (char *)destdata, destfmt->maxlength,
            (int *)destlen);

    return status ? CS_TRUNCATED : CS_SUCCEED;
}

/************************************************************************
*   Function             : SYB_ConvertTextToUnicode()
*
*   Description          : Conversion routine between Sybase CS_TEXT_TYPE
*                          and application CS_UNICHAR_FROM_TEXT_TYPE.
*                          Callback routine called automatically by ct_bind().
*
*   Arguments            : csContext : a pointer on a CS_CONTEXT structure.
*                          srcfmt    : format of the source variable
*                          srcdata   : value of the source variable
*                          destfmt   : format of the destination variable
*                          destdata  : value of the destination variable
*                          destlen   : length of the destination variable
*
*   Return               : Sybase values (cf function "cs_set_convert")
*
*   Creation date        : REF9303 - 030731 - PCL
*
*************************************************************************/
CS_RETCODE CS_PUBLIC SYB_ConvertTextToUnicode(
    CS_CONTEXT *,
    CS_DATAFMT *srcfmt, CS_VOID *srcdata,
    CS_DATAFMT *destfmt, CS_VOID *destdata,
    CS_INT *destlen)
{
    int status;

    if (srcfmt->format != CS_FMT_UNUSED ||
        destfmt->format != CS_FMT_UNUSED &&
        destfmt->format != CS_FMT_NULLTERM)
        return CS_ENOXLT;

    if (destfmt->format == CS_FMT_NULLTERM)
    {
        status =
            ICU4AAA_ConvertFromHTML(
            (const char *)srcdata, srcfmt->maxlength,
                (UChar *)destdata, destfmt->maxlength / 2 - 1,
                (int *)destlen);

        ((UChar *)destdata)[(*destlen)++] = (UChar)0;
    }
    else
        status =
        ICU4AAA_ConvertFromHTML(
        (const char *)srcdata, srcfmt->maxlength,
            (UChar *)destdata, destfmt->maxlength / 2,
            (int *)destlen);

    *destlen *= 2;

    return status ? CS_TRUNCATED : CS_SUCCEED;
}

/************************************************************************
**
**  Function    : SYB_Float2Numeric

**  Description : Convert CS_FLOAT to CS_NUMERICdouble.
**
**  Arguments   : number    CS_FLOAT to convert
**                numeric   pointer to CS_NUMERIC to fill
**                    numeric->precision : must be preset to desired precision
**                    numeric->scale     : must be preset to desired scale
**
*************************************************************************/
#ifndef _WIN64
#define LIMBSIZE (int)sizeof(mp_limb_t)
#else
// different compilation definitions while building library build and
// building application leads to invalid mp_limb_t size under _WIN64
#define LIMBSIZE (int)sizeof(long long)
#endif

int SYB_Float2Numeric(CS_FLOAT number, CS_NUMERIC *numeric)
{
    /* b10tob256[b10 - 1] = ceil(log(pow(10, b10 - 1) - 1)/log(256))) */
    CS_BYTE b10tob256[] =
    {
         1,  1,  2,  2,  3,  3,  3,  4,
         4,  5,  5,  5,  6,  6,  7,  7,
         8,  8,  8,  9,  9, 10, 10, 10,
        11, 11, 12, 12, 13, 13, 13, 14,
        14, 15, 15, 15, 16, 16, 17, 17,
        18, 18, 18, 19, 19, 20, 20, 20,
        21, 21, 22, 22, 23, 23, 23, 24,
        24, 25, 25, 25, 26, 26, 27, 27,
        27, 28, 28, 29, 29, 30, 30, 30,
        31, 31, 32, 32, 32
    };

    char source[128];
    char target[128];

    int n;


    int zp;
    int sp;

    char *head;

    mpz_t mpz;

    int magnitude;

    int cf = 0; // carry flag


    // Get formated string

    sprintf(
        source, "%.*e\n", DBL_DIG - 1, number);

    /* get magnitude */

    magnitude = atoi((strchr(source, 'e') + 1));

    /* compute header length */

    zp = std::min(
        (int)numeric->precision,
        (int)numeric->precision - (int)numeric->scale -
        magnitude - 1);

    /* handle overflow */

    if (zp < 0)
        return -1;

    /* compute significant length */

    sp = std::min(DBL_DIG, numeric->precision - zp);

    /* get formated string (rounded) */

    if (sp != DBL_DIG && (magnitude >= 0 || numeric->scale + magnitude + 1 >= 0))
    {
        char *mark = strchr(source, '.');
        char *scan2 = mark;

        if (sp == 0)
        {
            scan2--;

            if (*scan2 >= '5')
                cf = 1;
        }
        else
        {
            scan2 = mark + sp;

            if (*scan2 >= '5')
            {
                cf = 1;

                scan2--;

                do
                {
                    if (*scan2 == '.')
                        scan2--;

                    if (*scan2 < '9' || !cf)
                    {
                        *scan2 += (char)cf;
                        cf = 0;
                    }
                    else
                    {
                        *scan2 = '0';
                        cf = 1;
                    }
                } while (scan2-- != mark - 1);
            }
        }
    }

    if (zp == 0 && cf)
        return -1;

    // Build mpz string
    head = source;
    char *scan = target;

    if (sp > 0 || cf)
        if (*head == '-')
            *scan++ = *head++;
        else
            *scan++ = ' ';

    for (n = 0; n < zp; n++)
        if (n == zp - 1 && cf)
            *scan++ = '1';
        else
            *scan++ = '0';

    if (sp > 0)
        *scan++ = *head;

    if (sp > 1)
        for (n = 0; n < sp - 1; n++)
            *scan++ = head[n + 2];

    while (scan != target + numeric->precision + 1)
        *scan++ = '0';

    *scan++ = 0;

    // Convert string to mpz

    mpz_init(mpz);
    mpz_set_str(
        mpz, target, 10);

    // Convert mpz to NUMERIC

    int nSource = mpz->_mp_size * LIMBSIZE;

    bool negative = nSource < 0;

    if (negative)
        nSource = -nSource;

    int nTarget = b10tob256[numeric->precision - 1];

    if (!SYS_IsBigEndian())
    {
        CS_BYTE *pSource = (CS_BYTE *)mpz->_mp_d;
        CS_BYTE *pTarget =
            numeric->array + nTarget;

        for (n = 0; n < nTarget; n++)
        {
            if (n >= nSource)
                *pTarget-- = 0;
            else
                *pTarget-- = *pSource++;
        }
    }
    else
    {
        CS_BYTE *pSource = NULL;
        CS_BYTE *pTarget =
            numeric->array + nTarget;

        for (n = 0; n < nTarget; n++)
        {
            if (n % LIMBSIZE == 0)
                pSource =
                (CS_BYTE *)mpz->_mp_d +
                (n / LIMBSIZE + 1) * LIMBSIZE - 1;

            if (n >= nSource)
                *pTarget-- = 0;
            else
                *pTarget-- = *pSource--;
        }
    }

    if (negative)
        numeric->array[0] = 1;

    // Clear mpz

    mpz_clear(mpz);

    return 0;
}

/************************************************************************
*   Function             : SYB_ConvertFloatToBumeric()
*
*   Description          : Conversion routine between Sybase CS_FLOAT_TYPE
*                          and CS_NUMERIC_TYPE.
*                          Callback routine called automatically by ct_bind().
*
*   Arguments            : csContext : a pointer on a CS_CONTEXT structure.
*                          srcfmt    : format of the source variable
*                          srcdata   : value of the source variable
*                          destfmt   : format of the destination variable
*                          destdata  : value of the destination variable
*                          destlen   : length of the destination variable
*
*   Return               : Sybase values (cf function "cs_set_convert")
*
*   Creation date        : 170208 - PCL
*
*************************************************************************/
CS_RETCODE CS_PUBLIC SYB_ConvertFloatToNumeric(
    CS_CONTEXT *context,
    CS_DATAFMT *srcfmt, CS_VOID *srcdata,
    CS_DATAFMT *destfmt, CS_VOID *destdata,
    CS_INT *destlen)
{
    int status;

    ((CS_NUMERIC *)destdata)->precision = (CS_BYTE)destfmt->precision;
    ((CS_NUMERIC *)destdata)->scale = (CS_BYTE)destfmt->scale;


    status =
        SYB_Float2Numeric(
            *((CS_FLOAT *)srcdata),
            (CS_NUMERIC *)destdata);


    *destlen = sizeof(CS_NUMERIC);

    return status ? CS_EDOMAIN : CS_SUCCEED;
}

/************************************************************************
*   Function             : SYB_FreeConnection()
*
*   Description          : Close a connection previously etablished,
*                          free all allocated structures (CS_CONNECTION and
*                          CS_COMMAND).
*
*   Arguments            : connection : a pointer on a DBA_CONNECT_INFO_STP
*                                       structure.
*   Functions call       : None
*
*   Global var. modified : None
*
*   Return               : RET_SUCCEED               : if ok
*                          RET_DBA_ERR_ARGNOMATCH    : if problem with input arg.
*                          RET_DBA_ERR_HANDLECONPROP : if cannot handle connection
*                                                      property (Login Status)
*
*   Creation date        : Apr.  94 - PEC
*
*   Last Modif Date      : 29.08.95 - PEC - Added RET_CODE
*                          05.02.96 - PEC - Suppressed call to SYB_CtCancel() which
*                                           created problems in writing to a dead pipe.
*                          29.09.99 - GRD - Ref.: REF3847.
*                          PMSTA-16329 - 090713 - PMO : Bad connection handling on error
*
*************************************************************************/
RET_CODE SYB_FreeConnection(SybConnection& dbiConn)
{

    return(RET_SUCCEED);
}


/************************************************************************
*   Function             : SYB_ServerNotification()
*
*   Description          : Handle Server Notifications
*
*   Arguments            : None
*
*   Functions call       : None
*
*   Global var. modified :
*
*   Return               : TRUE
*
*   Creation date        : June 94 - PEC
*   Last Modif. Date     :
*************************************************************************/
int CS_PUBLIC SYB_ServerNotification(CS_CONNECTION *, CS_CHAR *, CS_INT)
{
    return(CS_SUCCEED);
}

/************************************************************************
*   Function             : SYB_FreeSybCliContext()
*
*   Description          : Free the application context
*
*   Arguments            : None
*
*   Functions call       : None
*
*   Global var. modified : EV_ApplContext
*
*   Return               : None
*
*   Creation date        : Apr. 94 - PEC
*   Last Modif Date      : 29.8.95 - PEC - Added RET_CODE
*                          PMSTA-30889 - 100418 - PMO : SYBASE VS ORACLE: financial server crash while running the PVN_PMSTA_9790 TaAutomator test case
*
*************************************************************************/
void SYB_FreeSybCliContext()
{
    /* SSO - 000410 - works on NT for server -> activate it for purify (less mem leaks) */
    /* #if (!defined(NT) || !defined(_DEBUG))      ............ FIH-980907-Due to Sybase Bug    */
#ifdef NTWIN /* on unix, do it anyway */
    if (SERVER_MODE() == TRUE)
    {
#endif
        if (EV_rxaFctStruct.pfn_ct_exit(EV_ApplContext, CS_FORCE_EXIT) != CS_SUCCEED)
        {
            MSG_SendMesg(RET_GEN_ERR_NOACTION, 0, FILEINFO);                                    /* PMSTA-30889 - 100418 - PMO */
        }
        else
        {
            if (EV_rxaFctStruct.pfn_cs_ctx_drop(EV_ApplContext) == CS_SUCCEED)
            { // OK
                EV_ApplContext = nullptr;                                                       /* PMSTA-30889 - 100418 - PMO */
            }
            else
            { // Error
                MSG_SendMesg(RET_GEN_ERR_NOACTION, 0, FILEINFO);                                /* PMSTA-30889 - 100418 - PMO */
            }
        }
#ifdef NTWIN
    }
#endif
}

/************************************************************************
*   Function             : SYB_CtCommand()
*
*   Description          : Memorize the command name in Language or RPC mode
*
*   Arguments            : connectNo : a connection number in the connection
*                          mode      : DBA_RPC or DBA_LANG
*                          request   : pointer on the command name
*
*   Functions call       : None
*
*   Global var. modified : None
*
*   Return               : TRUE if ok
*                          FALSE if problem
*
*   Creation date        : Juil. 94 - PEC
*
*   Last Modif. Date     : 29.09.99 - GRD - Ref.: REF3847.
*                          REF7264 - 020129 - PMO : Compilation errors and warnings with C++ compiler
*                          PMSTA-13294 - 281111 - PMO : Avoid the error message "DBA_CheckConnectNbCoherence Invalid argument (connectNo)" when importing
*                          PMSTA-16124 - 250413 - PMO : Ensure coherence of printf / scanf formats with 32bits / 64 bits datatypes
*                          PMSTA-18094 - 130514 - PMO : Avoid extracting the user credentials from the GUI running on Windows (via dump, etc.)
*                          PMSTA-24981 - 151116 - PMO : pid: threadid: missing form trace
*
*************************************************************************/
CS_RETCODE SYB_CtCommand(SybConnection& dbiConn, int mode, const char *request, char **sqlTraceStrPtr)
{
    CS_RETCODE      sybRetCode = CS_SUCCEED;
    CS_COMMAND *command = dbiConn.getCS_COMMAND(FILEINFO, "SYB_CtCommand");

    if ((command == NULL) || (request == NULL) || ((mode != DBA_RPC) && (mode != DBA_LANG)))
    {
        std::string errMsg;                                                                                                                                         /* PMSTA-24981 - 151116 - PMO */

        if ((SYS_IsGuiMode() == TRUE) || (SERVER_IS_INIT() == TRUE))
        {
            SYS_StringFormat(errMsg, "Command (" szFormatPointer "), mode (%s), request (%s), thread (%s)",                                                         /* PMSTA-16124 - 250413 - PMO */
                (void*)command,                                                                                                                                     /* PMSTA-16124 - 250413 - PMO */
                             (mode == DBA_RPC) ? "DBA_RPC" :
                             (mode == DBA_LANG) ? "DBA_LANG" :
                             "Unknown",
                             request,
                             SYS_GetThreadDescriptionForLog().c_str());                                                                                                          /* PMSTA-24981 - 151116 - PMO */

            MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "SYB_CtCommand", errMsg.c_str());
        }
        else
        {
            SYS_StringFormat(errMsg, "SYB_CtCommand. Invalid argument. Command (" szFormatPointer "), mode (%s), request (%s), thread (%s)",                        /* PMSTA-16124 - 250413 - PMO */
                (void*)command,                                                                                                                                     /* PMSTA-16124 - 250413 - PMO */
                             (mode == DBA_RPC) ? "DBA_RPC" :
                             (mode == DBA_LANG) ? "DBA_LANG" :
                             "Unknown",
                             request,
                             SYS_GetThreadDescriptionForLog().c_str());                                                                                                          /* PMSTA-24981 - 151116 - PMO */

            MSG_SendStrToLog(errMsg);
        }

        return(CS_FAIL);
    }


    dbiConn.m_lastResultType = (int)0; /* PMSTA-24564 - LJE - 161221 */
    dbiConn.m_currentCmd = Syb_command_Command;

    if ((sybRetCode = EV_rxaFctStruct.pfn_ct_command(command,
                                                     (mode == DBA_RPC) ? CS_RPC_CMD : CS_LANG_CMD,
                                                     (char*)request, 
                                                     CS_NULLTERM, 
                                                     (mode == DBA_RPC) ? CS_UNUSED : CS_END)) != CS_SUCCEED)
    {
        std::string errMsg;                                                                                                                                         /* PMSTA-24981 - 151116 - PMO */

        SYS_StringFormat(errMsg,
                         "Call to ct_command failed. Command (" szFormatPointer "), connection (%d), mode (%s), request (%s), status (%s), thread (%s)",             /* PMSTA-16124 - 250413 - PMO */
                         (void*)command,                                                                                                                             /* PMSTA-16124 - 250413 - PMO */
                         dbiConn.getId(),
                         (mode == DBA_RPC) ? "DBA_RPC" : "DBA_LANG",
                         request,
                         dbiConn.getLabelRetCode(sybRetCode).c_str(),                                                                                          /* PMSTA-24981 - 151116 - PMO */
                         SYS_GetThreadDescriptionForLog().c_str());                                                                                                  /* PMSTA-24981 - 151116 - PMO */

        dbiConn.sendMsg(FILEINFO, errMsg);
    }



    dbiConn.m_currentCmd = Syb_Command_None;


    /***** SQL TRACE *****/
    if (EV_sqlFile != NULL)
    {
        const char  *pszRequest;        /*  FIH-REF10391-041125 */
        char		fmtEltInfo[256] = "";		/* PMSTA-17979 - TGU - 151001 */

        /*  FIH-REF10391-041125 */
        if (strncmp(request, "update appl_user_vw set gui_context_t", strlen("update appl_user_vw set gui_context_t")) == 0)
        {
            pszRequest = "update appl_user_vw set gui_context_t";
        }
        else
        {
            pszRequest = request;

            /* PMSTA-18094 - 130514 - PMO */

            if (true == dbiConn.getConnStructPtr()->passwordChange)
            { /* Change the password. No password in the sql trace */
                pszRequest = "alter login \"...\" with password \"...\" modify password \"...\"";
            }
        }

        char * sqlTrace = static_cast<char *>(CALLOC(1, 1024 + strlen(pszRequest)));  /* REF7264 - PMO */
        ID_T         propBEId = dbiConn.getConnSessionProperties().getBusinessEntityId();

        /* PMSTA-17979 - TGU - 151001 */
        if (SERVER_MODE() != TRUE || SERVER_IS_INIT() != TRUE || DBA_GetFmtEltInfo(fmtEltInfo) != TRUE)
        {
            fmtEltInfo[0] = '\0';
        }

        ID_T appcontextUserId = dbiConn.getConnSessionProperties().getUserId();
        ID_T appcontextDPId = dbiConn.getConnSessionProperties().getDataProfileId();
        string dbName = (dbiConn.getActualDbName().empty() == false ? dbiConn.getActualDbName() : "db_not_defined");
        string suUser = dbiConn.getDescription().getUser();

        if (fmtEltInfo[0] != '\0')
        {
            sprintf(sqlTrace,
                    "    ct_command(%s,%s,%" szFormatId",%" szFormatId",%" szFormatId")    %-12.12s Connect=%-9d CsCmd=" szFormatPointer " Mode=%-5.5s Thread=%s Request=\"%s",                    /* PMSTA-16124 - 250413 - PMO */
                    dbName.c_str(),
                    suUser.c_str(),
                    appcontextUserId,
                    appcontextDPId,
                    propBEId,
                    fmtEltInfo,
                    dbiConn.getId(),
                    (void*)command,                                                                                                                                                 /* PMSTA-16124 - 250413 - PMO */
                    (mode == DBA_RPC) ? "RPC" : "LANG",
                    SYS_GetThreadDescriptionForLog().c_str(),                                                                                                                       /* PMSTA-24981 - 151116 - PMO */
                    pszRequest);
        }
        else
        {
            sprintf(sqlTrace,
                    "    ct_command(%s,%s,%" szFormatId",%" szFormatId",%" szFormatId")    %-12.12s Connect=%-9d CsCmd=" szFormatPointer " Mode=%-5.5s Thread=%s Request=\"%s",                    /* PMSTA-16124 - 250413 - PMO */
                    dbName.c_str(),
                    suUser.c_str(),
                    appcontextUserId,
                    appcontextDPId,
                    propBEId,
                    dbiConn.getLabelRetCode(sybRetCode).c_str(),                                                                                                              /* PMSTA-24981 - 151116 - PMO */
                    dbiConn.getId(),
                    (void*)command,                                                                                                                                                 /* PMSTA-16124 - 250413 - PMO */
                    (mode == DBA_RPC) ? "RPC" : "LANG",
                    SYS_GetThreadDescriptionForLog().c_str(),                                                                                                                       /* PMSTA-24981 - 151116 - PMO */
                    pszRequest);
        }

        /* PMSTA12840-JPP-111006 */
        /* truncate pszRequest to EV_SqlTraceMaxLen directly in buffer */
        if (EV_SqlTraceMaxLen > 0 && mode == DBA_LANG && EV_SqlTraceMaxLen < strlen(pszRequest))
        {
            sqlTrace[strlen(sqlTrace) - strlen(pszRequest) + EV_SqlTraceMaxLen] = '\0';
            strcat(sqlTrace, "!");
        }


        /* REF10195 - LJE - 040407 */
        if (sqlTraceStrPtr == NULL)
        {
            strcat(sqlTrace, "\"");
            MSG_SendSqlTrace(sqlTrace);
            DBA_PasswordClear(sqlTrace, strlen(sqlTrace));    /* PMSTA-18094 - 130514 - PMO */
            FREE(sqlTrace);
        }
        else
        {
            *sqlTraceStrPtr = sqlTrace;
        }
    }

    return(sybRetCode);
}


/************************************************************************
*   Function             : SYB_CtSend()
*
*   Description          : Send the command previously initialized by
*                          SYB_CtCommand()
*
*   Arguments            : connectNo : a connection number in the connection
*                                      list
*
*   Functions call       : None
*
*   Global var. modified : None
*
*   Return               : RET_CODE
*
*   Creation date        : Juil. 94 - PEC
*
*   Last Modif. Date     : 29.09.99 - GRD - Ref.: REF3847.
*                          PMSTA-16124 - 250413 - PMO : Ensure coherence of printf / scanf formats with 32bits / 64 bits datatypes
*                          PMSTA-24981 - 151116 - PMO : pid: threadid: missing form trace
*
*************************************************************************/
CS_RETCODE SYB_CtSend(SybConnection &dbiConn)
{
#ifdef AAADEBUG
    CS_INT connStatus = 0, compId = 0;
    CS_RETCODE compStatus = 0;
#endif

    CS_COMMAND * command = dbiConn.getCS_COMMAND(FILEINFO, "SYB_CtSend");                                                                         /* PMSTA-24981 - 151116 - PMO */

    if (command == nullptr)
    {
        return RET_GEN_ERR_INVARG;
    }


#ifdef AAADEBUG
    if (TLS_Return(0))
    {
        sybRetCode = SYB_CtOptions(dbiConn, CS_GET, CS_OPT_ANSINULL,      /* REF3847 */      /*  FIH-REF11254-050617 Add cast with (CS_CONNECTION*)  */
            (CS_VOID *)&connStatus, sizeof(CS_INT), NULL);
        sybRetCode = SYB_CtConProps(dbiConn, CS_GET, CS_CON_STATUS, &connStatus, CS_UNUSED, NULL);
        sybRetCode = SYB_CtPoll(dbiConn, NULL, 2, NULL, &command, &compId, &compStatus);
    }
#endif


    dbiConn.m_currentCmd = Syb_Command_Send;


    DATE_START_TIMER(1, TIMER_MASK_SQLC);

    CS_RETCODE sybRetCode = EV_rxaFctStruct.pfn_ct_send(command);

    DATE_STOP_TIMER(1, TIMER_MASK_SQLC);

    if (sybRetCode != CS_SUCCEED)
    {
        std::string errMsg;                                                                                                                                         /* PMSTA-24981 - 151116 - PMO */

        SYS_StringFormat(errMsg, "Call to ct_send failed. Command (" szFormatPointer "), connection (%d), status (%s), thread (%s)",                                /* PMSTA-16124 - 250413 - PMO */
            (void*)command,                                                                                                                             /* PMSTA-16124 - 250413 - PMO */
                         dbiConn.getId(),
                         dbiConn.getLabelRetCode(sybRetCode).c_str(),                                                                                          /* PMSTA-24981 - 151116 - PMO */
                         SYS_GetThreadDescriptionForLog().c_str());                                                                                                  /* PMSTA-24981 - 151116 - PMO */

        dbiConn.sendMsg(FILEINFO, errMsg);
    }

    dbiConn.m_currentCmd = Syb_Command_None;


    /***** SQL TRACE *****/
    if (EV_sqlFile != NULL && SV_SqlTraceLevel != 3)
    {
        std::string errMsg;                                                                                                                                         /* PMSTA-24981 - 151116 - PMO */

        SYS_StringFormat(errMsg,
                         "    ct_send()       %-12.12s Connect=%-9d CsCmd=" szFormatPointer " Thread=",                                                              /* PMSTA-16124 - 250413 - PMO */
                         dbiConn.getLabelRetCode(sybRetCode).c_str(),                                                                                          /* PMSTA-24981 - 151116 - PMO */
                         dbiConn.getId(),
                         (void*)command);                                                                                                                            /* PMSTA-16124 - 250413 - PMO */

        errMsg += SYS_GetThreadDescriptionForLog();                                                                                                                 /* PMSTA-24981 - 151116 - PMO */

        MSG_SendSqlTrace(errMsg.c_str());
    }

    if (sybRetCode != CS_SUCCEED)
    {
        return(dbiConn.convertToRetCode(sybRetCode));
    }

    return(RET_SUCCEED);
}

/************************************************************************
*   Function             : SYB_CtBind()
*
*   Description          : Bind a Sybase result column in a result set with
*                          an application variable
*
*   Arguments            : like SYB_CtBind
*
*   Functions call       : None
*
*   Global var. modified : None
*
*   Return               :
*
*   Creation date        : REF11026 - LJE - 050209
*   Last Modif. Date     :
*************************************************************************/
CS_RETCODE SYB_CtBind(CS_COMMAND  *csCommand,
                      CS_INT       item,
                      CS_DATAFMT  *csDataFmtPtr,
                      CS_VOID     *dataPtr,
                      CS_INT      *outputLen,
                      CS_SMALLINT *indicator,
                      CS_INT       anonymizeItem,
                      char        *anonymizeSubst)
{

    CS_RETCODE csRet;

    csRet = EV_rxaFctStruct.pfn_ct_bind(csCommand, item, csDataFmtPtr, dataPtr, outputLen, indicator);

    return(csRet);
}

/************************************************************************
*   Function             : SYB_CtParam()
*
*   Description          :
*
*   Arguments            : connectNo : a connection number
*
*   Functions call       : None
*
*   Global var. modified : None
*
*   Return               : RET_CODE
*
*   Creation Date        : 29.09.99 - GRD - Ref.: REF3847.
*
*   Last modif.          : PMSTA-16124 - 250413 - PMO : Ensure coherence of printf / scanf formats with 32bits / 64 bits datatypes
*                          PMSTA-24981 - 151116 - PMO : pid: threadid: missing form trace
*
*************************************************************************/
CS_RETCODE SYB_CtParam(SybConnection& dbiConn, CS_DATAFMT *dataFmt, CS_VOID *data, CS_INT dataLen, CS_INT indicator)
{
    CS_RETCODE	sybRetCode = CS_SUCCEED;
    CS_COMMAND *csCommand = dbiConn.getCS_COMMAND(FILEINFO, "SYB_CtParam");

    /* Is it a valid command? */
    if (csCommand == nullptr)
    {
        std::string errMsg;                                                                                                                                             /* PMSTA-24981 - 151116 - PMO */

        if ((SYS_IsGuiMode() == TRUE) || (SERVER_IS_INIT() == TRUE))
        {
            SYS_StringFormat(errMsg, "Command (" szFormatPointer "), thread(%s)", (void*)csCommand, SYS_GetThreadDescriptionForLog().c_str());                          /* PMSTA-24981 - 151116 - PMO / PMSTA-16124 - 250413 - PMO */
            MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "SYB_CtParam", errMsg.c_str());
        }
        else
        {
            SYS_StringFormat(errMsg, "SYB_CtOptions. Invalid argument. Command (" szFormatPointer "), Thread (%s)",                                                     /* PMSTA-24981 - 151116 - PMO / PMSTA-16124 - 250413 - PMO */
                (void*)csCommand, SYS_GetThreadDescriptionForLog().c_str());                                                                                            /* PMSTA-16124 - 250413 - PMO */
            MSG_SendStrToLog(errMsg);
        }

        return(CS_FAIL);
    }

    dbiConn.m_currentCmd = Syb_Command_Param;

    if ((sybRetCode = EV_rxaFctStruct.pfn_ct_param(csCommand, dataFmt, data, dataLen, (CS_SMALLINT)(indicator & 0xFFFF))) != CS_SUCCEED) /* DLA - CMT03996 - 090326 */
    {
        std::string errMsg;                                                                                                                                             /* PMSTA-24981 - 151116 - PMO */

        SYS_StringFormat(errMsg, "Call to ct_param failed. Command (" szFormatPointer "), Thread (%s), Connection (%d), Status (%s)",                                   /* PMSTA-24981 - 151116 - PMO / PMSTA-16124 - 250413 - PMO */
            (void*)csCommand,                                                                                                                               /* PMSTA-16124 - 250413 - PMO */
                         SYS_GetThreadDescriptionForLog().c_str(),                                                                                                       /* PMSTA-24981 - 151116 - PMO */
                         dbiConn.getId(),
                         dbiConn.getLabelRetCode(sybRetCode).c_str());                                                                                             /* PMSTA-24981 - 151116 - PMO */

        MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, errMsg.c_str());
    }

    dbiConn.m_currentCmd = Syb_Command_None;

    /***** SQL TRACE *****/
    if (EV_sqlFile != NULL)
    {
        std::string errMsg;                                                                                                                                             /* PMSTA-24981 - 151116 - PMO */

        SYS_StringFormat(errMsg,
                         "    ct_param()     Command=" szFormatPointer " Thread=%s Connect=%-9d Status=%-12.12s",                                                        /* PMSTA-16124 - 250413 - PMO */
                         (void*)csCommand,                                                                                                                               /* PMSTA-16124 - 250413 - PMO */
                         SYS_GetThreadDescriptionForLog().c_str(),                                                                                                       /* PMSTA-24981 - 151116 - PMO */
                         dbiConn.getId(),
                         dbiConn.getLabelRetCode(sybRetCode).c_str());                                                                                             /* PMSTA-24981 - 151116 - PMO */

        MSG_SendSqlTrace(errMsg.c_str());
    }

    return(sybRetCode);
}

/************************************************************************
*   Function             : SYB_CtFetch()
*
*   Description          : Retrieve a result row sent back by a server
*
*   Arguments            : csCommand : pointer on a command structure
*                          type      :
*                          offset    :
*                          option    :
*                          rows      : pointer which will contain the number
*                                      of rows read.
*
*
*   Functions call       :
*
*   Global var. modified :
*
*   Return               : RET_CODE
*
*   Creation date        : Juil. 94 - PEC
*
*   Last Modif. Date     : PMSTA-16124 - 250413 - PMO : Ensure coherence of printf / scanf formats with 32bits / 64 bits datatypes
*                          PMSTA-24981 - 151116 - PMO : pid: threadid: missing form trace
*
*************************************************************************/
RET_CODE SYB_CtFetch(SybConnection& dbiConn, CS_INT type, CS_INT offset, CS_INT option, CS_INT *rows)
{
    CS_COMMAND * csCommand = dbiConn.getCS_COMMAND(FILEINFO, "SYB_CtFetch");                                                                           /* PMSTA-24981 - 151116 - PMO */

    if (csCommand == nullptr)
    {
        return RET_GEN_ERR_INVARG;
    }

    dbiConn.m_currentCmd = Syb_Command_Fetch;


    DATE_START_TIMER(1, TIMER_MASK_SQLC);

    CS_RETCODE sybRetCode = EV_rxaFctStruct.pfn_ct_fetch(csCommand, type, offset, option, rows);

    DATE_STOP_TIMER(1, TIMER_MASK_SQLC);

    if ((sybRetCode != CS_SUCCEED) && (sybRetCode != CS_END_DATA))
    {
        std::string errMsg;                                                                                                                                             /* PMSTA-24981 - 151116 - PMO */

        SYS_StringFormat(errMsg,
                         "Call to ct_fetch failed. Command (" szFormatPointer "), connection (%d), thread (%s), status (%s)",                                            /* PMSTA-16124 - 250413 - PMO */
                         (void*)csCommand,
                         dbiConn.getId(),
                         SYS_GetThreadDescriptionForLog().c_str(),                                                                                                       /* PMSTA-24981 - 151116 - PMO */
                         dbiConn.getLabelRetCode(sybRetCode).c_str());                                                                                             /* PMSTA-24981 - 151116 - PMO */

        dbiConn.sendMsg(FILEINFO, errMsg);                                                                                                                        /* PMSTA-24981 - 151116 - PMO */
    }


    dbiConn.m_currentCmd = Syb_Command_None;


    /***** SQL TRACE *****/
    if (EV_sqlFile != NULL && SV_SqlTraceLevel != 3)
    {
        static int counter = 0;

        if (sybRetCode == CS_SUCCEED)
            counter++;
        else
        {
            std::string errMsg;                                                                                                                                             /* PMSTA-24981 - 151116 - PMO */

            SYS_StringFormat(errMsg,
                             "    ct_fetch()      %-12.12s Connect=%-9d CsCmd=" szFormatPointer " after %d ct_fetch thread=",                                                /* PMSTA-16124 - 250413 - PMO */
                             dbiConn.getLabelRetCode(sybRetCode).c_str(),                                                                                              /* PMSTA-24981 - 151116 - PMO */
                             dbiConn.getId(),
                             (void*)csCommand,                                                                                                                               /* PMSTA-16124 - 250413 - PMO */
                             counter);

            errMsg += SYS_GetThreadDescriptionForLog();                                                                                                                     /* PMSTA-24981 - 151116 - PMO */

            counter = 0;

            MSG_SendSqlTrace(errMsg.c_str());
        }
    }

    switch (sybRetCode)
    {
        case CS_SUCCEED:
            return RET_SUCCEED;
        case CS_END_DATA:
            return RET_DBA_INFO_NO_MORE_DATA;
        case CS_PENDING:
        case CS_BUSY:
            return RET_DBA_ERR_PENDING;
        case CS_ROW_FAIL:
        case CS_FAIL:
        case CS_CANCELED:
        default:
            return RET_DBA_ERR_DBPROBLEM;
    }
}

/************************************************************************
*   Function             : SYB_CtResults()
*
*   Description          : Get result types to be processed (Rows, status,...)
*
*   Arguments            : csCommand : pointer on a command structure
*                          resultType : pointer on an integer which will
*                                       contain the result type for the next
*                                       result data to be read.
*
*
*   Functions call       :
*
*   Global var. modified :
*
*   Return               : RET_CODE
*
*   Creation date        : Juil. 94 - PEC
*
*   Last Modif. Date     : REF8014 - 021002 - PMO : BoundsChecker message
*                          PMSTA-16124 - 250413 - PMO : Ensure coherence of printf / scanf formats with 32bits / 64 bits datatypes
*
*************************************************************************/
CS_RETCODE SYB_CtResults(SybConnection& dbiConn, CS_INT *resultType)
{
    CS_COMMAND * csCommand = dbiConn.getCS_COMMAND(FILEINFO, "SYB_CtResults");                                                                       /* PMSTA-24981 - 151116 - PMO */

    if (csCommand == nullptr)
    {
        return CS_FAIL;
    }

    DATE_START_TIMER(1, TIMER_MASK_SQLC);

    /* If ct_results return CS_FAIL, resultType is unchanged REF8014 - PMO */
    *resultType = (CS_INT)0;

    CS_RETCODE sybRetCode = EV_rxaFctStruct.pfn_ct_results(csCommand, resultType);

    DATE_STOP_TIMER(1, TIMER_MASK_SQLC);

    if ((sybRetCode != CS_SUCCEED) && (sybRetCode != CS_END_RESULTS) && dbiConn.isExternalMsgManagement() == false)
    {
        std::string errMsg;

        SYS_StringFormat(errMsg,
                         "Call to ct_results failed. Command (" szFormatPointer "), thread (%s), type (%s), status (%s)",                                            /* PMSTA-16124 - 250413 - PMO */
                         (void*)csCommand,                                                                                                                           /* PMSTA-16124 - 250413 - PMO */
                         SYS_GetThreadDescriptionForLog().c_str(),                                                                                                   /* PMSTA-24981 - 151116 - PMO */
                         (*resultType == CS_CMD_DONE) ? "CMD_DONE" :
                         (*resultType == CS_CMD_FAIL) ? "CMD_FAIL" :
                         (*resultType == CS_CMD_SUCCEED) ? "CMD_SUCCEED" :
                         (*resultType == CS_COMPUTE_RESULT) ? "COMPUTE_RESULT" :
                         (*resultType == CS_CURSOR_RESULT) ? "CURSOR_RESULT" :
                         (*resultType == CS_PARAM_RESULT) ? "PARAM_RESULT" :
                         (*resultType == CS_ROW_RESULT) ? "ROW_RESULT" :
                         (*resultType == CS_STATUS_RESULT) ? "STATUS_RESULT" :
                         (*resultType == CS_COMPUTEFMT_RESULT) ? "COMPUTEFMT_RESULT" :
                         (*resultType == CS_ROWFMT_RESULT) ? "ROWFMT_RESULT" :
                         (*resultType == CS_MSG_RESULT) ? "MSG_RESULT" :
                         (*resultType == CS_DESCRIBE_RESULT) ? "DESCRIBE_RESULT" : "?",
                         dbiConn.getLabelRetCode(sybRetCode).c_str());                                                                                         /* PMSTA-24981 - 151116 - PMO */

        dbiConn.sendMsg(FILEINFO, errMsg);                                                                                                                    /* PMSTA-24981 - 151116 - PMO */
    }

    dbiConn.m_currentCmd = Syb_Command_None;


    /***** SQL TRACE *****/
    if ((EV_sqlFile != NULL) && (SV_SqlTraceLevel != 3))
    {
        std::string errMsg;

        SYS_StringFormat(errMsg,
                         "    ct_results()    %-12.12s Connect=%-9d CsCmd=" szFormatPointer " Type=%s thread=",                                                      /* PMSTA-16124 - 250413 - PMO */
                         dbiConn.getLabelRetCode(sybRetCode).c_str(),                                                                                          /* PMSTA-24981 - 151116 - PMO */
                         dbiConn.getId(),
                         (void*)csCommand,                                                                                                                           /* PMSTA-16124 - 250413 - PMO */
                         (*resultType == CS_CMD_DONE) ? "CMD_DONE" :
                         (*resultType == CS_CMD_FAIL) ? "CMD_FAIL" :
                         (*resultType == CS_CMD_SUCCEED) ? "CMD_SUCCEED" :
                         (*resultType == CS_COMPUTE_RESULT) ? "COMPUTE_RESULT" :
                         (*resultType == CS_CURSOR_RESULT) ? "CURSOR_RESULT" :
                         (*resultType == CS_PARAM_RESULT) ? "PARAM_RESULT" :
                         (*resultType == CS_ROW_RESULT) ? "ROW_RESULT" :
                         (*resultType == CS_STATUS_RESULT) ? "STATUS_RESULT" :
                         (*resultType == CS_COMPUTEFMT_RESULT) ? "COMPUTEFMT_RESULT" :
                         (*resultType == CS_ROWFMT_RESULT) ? "ROWFMT_RESULT" :
                         (*resultType == CS_MSG_RESULT) ? "MSG_RESULT" :
                         (*resultType == CS_DESCRIBE_RESULT) ? "DESCRIBE_RESULT" : "?");

        errMsg += SYS_GetThreadDescriptionForLog();                                                                                                                 /* PMSTA-24981 - 151116 - PMO */

        MSG_SendSqlTrace(errMsg.c_str());
    }

    return sybRetCode;
}

/************************************************************************
*   Function             : SYB_ProcessParamResult()
*
*   Description          : Process output parameters
*
*   Arguments            : connectNo : a connection number in the connection
*                                      list
*                          status    : pointer on an integer which will contain
*                                      status value if a status was read.
*
*   Functions call       : None
*
*   Global var. modified : None
*
*   Return               : TRUE if ok
*                          FALSE if problem
*
*   Creation date        : PMSTA08801 - DDV - 091207 - New function to treat output parameters
*   Last Modif. Date     :
*************************************************************************/
int SYB_ProcessParamResult(DbiConnection& dbiConn,
                           OBJECT_ENUM    object,
                           DBA_DYNST_ENUM dynStEnum,
                           DBA_DYNFLD_STP record,
                           DBA_PROC_STP   procedure)
{
    DBI_SMALLINT    *nullFlagTab = NULL;
    DBI_INT         *fieldLengthTab = NULL;
    INT_T           *fieldIdxTab = NULL;
    CS_DATAFMT      csDataFmt;
    int             i = 0, j = 0, colNumber = 0;

    CS_COMMAND * csCommand = (CS_COMMAND*)dbiConn.getCommandPtr(); /* REF7264 - PMO */

    EV_rxaFctStruct.pfn_ct_res_info(csCommand, CS_NUMDATA, &colNumber, CS_UNUSED, NULL);

    if (colNumber > 0)
    {
        if (procedure != NULL)
        {
            if ((nullFlagTab = static_cast<DBI_SMALLINT*>(CALLOC(colNumber, sizeof(DBI_SMALLINT)))) == NULL)
            {
                return(RET_MEM_ERR_ALLOC);
            }

            if ((fieldLengthTab = static_cast<DBI_INT*>(CALLOC(colNumber, sizeof(DBI_INT)))) == NULL)
            {
                FREE(nullFlagTab);
                return(RET_MEM_ERR_ALLOC);
            }

            if ((fieldIdxTab = static_cast<INT_T *>(CALLOC(colNumber, sizeof(int)))) == NULL)
            {
                FREE(nullFlagTab);
                FREE(fieldLengthTab);
                return(RET_MEM_ERR_ALLOC);
            }

            int outputPos = -1;
            for (i = 0; i < colNumber; i++)
            {
                nullFlagTab[i] = -1;
                fieldLengthTab[i] = 0;
                fieldIdxTab[i] = -1;

                /* ct_describe to get a description of the parameter */
                if (EV_rxaFctStruct.pfn_ct_describe(csCommand, i + 1, &csDataFmt) == CS_SUCCEED)
                {
                    if (csDataFmt.namelen > 0 && csDataFmt.name != NULL)
                    {
                        j = 0;
                        fieldIdxTab[i] = Null_Dynfld;

                        while (procedure->procParamDefPtr != NULL &&
                               procedure->procParamDefPtr[j].fldNbrPtr != UNUSED &&
                               fieldIdxTab[i] == -1)
                        {
                            if (strcmp(csDataFmt.name, procedure->procParamDefPtr[j].paramName) == 0)
                            {
                                if (procedure->procParamDefPtr[j].procParamTypeEn == ProcParamType_Output_Indexed && *(procedure->procParamDefPtr[j].outputFldNbrPtr) != Null_Dynfld)
                                    fieldIdxTab[i] = *(procedure->procParamDefPtr[j].outputFldNbrPtr);
                                else
                                    fieldIdxTab[i] = *(procedure->procParamDefPtr[j].fldNbrPtr);
                            }
                            j++;
                        }

                        if (fieldIdxTab[i] != Null_Dynfld && record != nullptr)
                        {
                            SYB_BindRecvDynFld(record,
                                               fieldIdxTab[i],
                                               GET_FLD_TYPE(dynStEnum, fieldIdxTab[i]),
                                               i + 1, 
                                               &(nullFlagTab[i]),
                                               &(fieldLengthTab[i]),
                                               csCommand,
                                               csDataFmt,
                                               procedure->procParamDefPtr[j - 1].procParamTypeEn == ProcParamType_Output_Indexed ? TRUE : FALSE); /* DLA - PMSTA08801 - 110103 */
                        }

                    }
                    else if (csDataFmt.namelen == 0) /* DLA - PMSTA08801 - 100301 in block mode no name for fields*/
                    {
                        if (record != NULLDYNST)
                        {
                            if (procedure->procParamDefPtr != NULL)
                            {
                                /* PMSTA-34344 - LJE - 190603 */
                                do
                                {
                                    outputPos++;
                                } while (procedure->procParamDefPtr[outputPos].procParamTypeEn != ProcParamType_Output_Indexed &&
                                         procedure->procParamDefPtr[outputPos].procParamTypeEn != ProcParamType_Output &&
                                         procedure->procParamDefPtr[outputPos].fldNbrPtr != UNUSED);

                                if (procedure->procParamDefPtr[outputPos].fldNbrPtr != UNUSED)
                                {
                                    if (procedure->procParamDefPtr[outputPos].procParamTypeEn == ProcParamType_Output_Indexed && *(procedure->procParamDefPtr[outputPos].outputFldNbrPtr) != Null_Dynfld)
                                        fieldIdxTab[i] = *(procedure->procParamDefPtr[outputPos].outputFldNbrPtr); /* DLA - PMSTA08801 - 101227 */
                                    else
                                        fieldIdxTab[i] = *(procedure->procParamDefPtr[outputPos].fldNbrPtr); /* DLA - PMSTA08801 - 101227 */

                                    SYB_BindRecvDynFld(record,
                                                       fieldIdxTab[i],
                                                       GET_FLD_TYPE(dynStEnum, i),
                                                       i + 1,
                                                       &(nullFlagTab[i]),
                                                       &(fieldLengthTab[i]),
                                                       csCommand,
                                                       csDataFmt,
                                                       procedure->procParamDefPtr[i].procParamTypeEn == ProcParamType_Output_Indexed ? TRUE : FALSE); /* DLA - PMSTA08801 - 110103 */
                                }
                            }
                        }
                    }
                    else
                    {
                        char msg[512];

                        /* error message, impossible to bind output parameter */
                        if (csDataFmt.namelen > 0 && csDataFmt.name != NULL)
                            sprintf(msg, "Binding output parameter (%s) failed on entity %s", csDataFmt.name, DBA_GetObjectCName(object));
                        else
                            sprintf(msg, "Binding output parameter failed on entity %s, no parameter name given.", DBA_GetObjectCName(object));

                        MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, msg);
                    }
                }
            }
        }
        else
        {
            /* PMSTA-43500 - LJE - 210330 */
            i = 0;
            for (auto &it : dbiConn.getRequestParamMap())
            {
                if (it.second->m_bOutput)
                {
                    /* ct_describe to get a description of the parameter */
                    if (EV_rxaFctStruct.pfn_ct_describe(csCommand, i + 1, &csDataFmt) == CS_SUCCEED)
                    {
                        SYB_BindRecvDynFld(it.second->getDynFldStp(),
                                           i,
                                           it.second->m_dataType,
                                           i + 1,
                                           &(it.second->m_nullInd),
                                           &(it.second->m_dataLength),
                                           csCommand,
                                           csDataFmt,
                                           FALSE);
                    }
                }
            }
        }

        if (dbiConn.fetch() == TRUE)
        {
            if (record != NULL)
            {
                for (i = 0; i < colNumber; i++)
                {
                    if (fieldIdxTab[i] >= 0)
                        DBA_CopyNullFlagsAndLengthDynFld(record, dynStEnum, fieldIdxTab[i], nullFlagTab[i], fieldLengthTab[i]);
                }
            }
            else
            {
                /* PMSTA-43500 - LJE - 210330 */
                for (auto &it : dbiConn.getRequestParamMap())
                {
                    if (it.second->m_bOutput)
                    {
                        it.second->initNullValue();
                        it.second->updOutputData();
                    }
                }
            }
        }

        while (dbiConn.fetch() == TRUE)
            ;

        FREE(nullFlagTab);
        FREE(fieldLengthTab);
        FREE(fieldIdxTab);
    }

    return(TRUE);
}

/************************************************************************
*   Function             : SYB_GetCsContext()
*
*   Description          : Retrieve the CS_CONTEXT structure
*
*   Arguments            : None
*
*   Functions call       : None
*
*   Global var. modified : None
*
*   Return               : a CS_CONTEXT pointer
*************************************************************************/
CS_CONTEXT *SYB_GetCsContext()
{
    return(EV_ApplContext);
}

/************************************************************************
*   Function             : SYB_ConvDynFldToSybData()
*
*   Description          :
*
*   Arguments            :
*                               fldPtr (may be NULL)
*
*   Functions call       :
*
*   Global var. modified :
*
*   Return               : RET_CODE
*
*   Last modif.          : REF7264 - 020129 - PMO : Compilation errors and warnings with C++ compiler
*                          PMSTA-15918 - 070213 - PMO : Fusion on portfolio [T_AI_PE_ST] failed ; upd_exd_position : Attempt to insert NULL value into column 'end_d', table position
*
*************************************************************************/
RET_CODE SYB_ConvDynFldToSybData(DBA_DYNFLD_STP fldPtr,
                                 DATATYPE_ENUM  dataType,
                                 SYB_DATA_UNP   retSybDataUnp,
                                 CS_DATAFMT     *retSybDataFmt,
                                 FLAG_T         autoConvNumToFloatFlg)
{
    CS_CONTEXT      *csContext = NULL;
    CS_DATAFMT      csDataFmtSrc;
    PTR             srcDataPtr;
    DATE_T          refDate;
    long            daysNbr;
    HOUR_T          hour;
    MINUTE_T        min;
    SECOND_T        second;

    csContext = SYB_GetCsContext();

    memset(retSybDataFmt, 0, sizeof(CS_DATAFMT));
    memset(&csDataFmtSrc, 0, sizeof(CS_DATAFMT));

    retSybDataFmt->name[0] = END_OF_STRING;
    retSybDataFmt->namelen = 0;
    retSybDataFmt->format = CS_FMT_UNUSED;
    retSybDataFmt->precision = 18;
    retSybDataFmt->scale = 0;
    retSybDataFmt->locale = NULL;

    if (fldPtr)
        srcDataPtr = GET_FLDPTR_BY_DTP(dataType, fldPtr, 0);
    else
        srcDataPtr = NULL;

    switch (dataType)
    {
        case AmountType:

            if (autoConvNumToFloatFlg == TRUE)
            {
                retSybDataFmt->datatype = CS_FLOAT_TYPE;
                retSybDataFmt->maxlength = sizeof(CS_FLOAT);

                if (srcDataPtr != NULL)
                {
                    retSybDataUnp->csFloat = *((CS_FLOAT *)srcDataPtr);
                }
            }
            else
            {
                csDataFmtSrc.datatype = CS_FLOAT_TYPE;
                csDataFmtSrc.maxlength = sizeof(CS_FLOAT);
                csDataFmtSrc.locale = NULL;
                retSybDataFmt->datatype = CS_NUMERIC_TYPE;
                retSybDataFmt->maxlength = sizeof(CS_NUMERIC);
			retSybDataFmt->precision = GET_MAXLEN(AmountType); /* PMSTA-36302 - DDV - 190624 - Make 6 digits amount optional */
			retSybDataFmt->scale = GET_DECIMAL(AmountType);    /* PMSTA-36302 - DDV - 190624 - Make 6 digits amount optional */

                if (srcDataPtr != NULL)
                {
                    EV_rxaFctStruct.pfn_cs_convert(csContext, &csDataFmtSrc, srcDataPtr, retSybDataFmt, &retSybDataUnp->csNumeric, NULL);
                }
            }
            break;

        case LongamountType:                                           /* DVP041 - 960429 - DED */

            if (autoConvNumToFloatFlg == TRUE)
            {
                retSybDataFmt->datatype = CS_FLOAT_TYPE;
                retSybDataFmt->maxlength = sizeof(CS_FLOAT);

                if (srcDataPtr != NULL)
                {
                    retSybDataUnp->csFloat = *((CS_FLOAT *)srcDataPtr);
                }
            }
            else
            {
                csDataFmtSrc.datatype = CS_FLOAT_TYPE;
                csDataFmtSrc.maxlength = sizeof(CS_FLOAT);
                csDataFmtSrc.locale = NULL;
                retSybDataFmt->datatype = CS_NUMERIC_TYPE;
                retSybDataFmt->maxlength = sizeof(CS_NUMERIC);
                retSybDataFmt->precision = LONGAMOUNT_T_LEN;
                retSybDataFmt->scale = LONGAMOUNT_T_DEC;

                if (srcDataPtr != NULL)
                {
                    EV_rxaFctStruct.pfn_cs_convert(csContext, &csDataFmtSrc, srcDataPtr, retSybDataFmt, &retSybDataUnp->csNumeric, NULL);
                }
            }
            break;

        case ExchangeType:
            if (autoConvNumToFloatFlg == TRUE)
            {
                retSybDataFmt->datatype = CS_FLOAT_TYPE;
                retSybDataFmt->maxlength = sizeof(CS_FLOAT);

                if (srcDataPtr != NULL)
                {
                    retSybDataUnp->csFloat = *((CS_FLOAT *)srcDataPtr);
                }
            }
            else
            {
                csDataFmtSrc.datatype = CS_FLOAT_TYPE;
                csDataFmtSrc.maxlength = sizeof(CS_FLOAT);
                csDataFmtSrc.locale = NULL;
                retSybDataFmt->datatype = CS_NUMERIC_TYPE;
                retSybDataFmt->maxlength = sizeof(CS_NUMERIC);
                retSybDataFmt->precision = EXCHANGE_T_LEN;
                retSybDataFmt->scale = EXCHANGE_T_DEC;

                if (srcDataPtr != NULL)
                {
                    EV_rxaFctStruct.pfn_cs_convert(csContext, &csDataFmtSrc, srcDataPtr, retSybDataFmt, &retSybDataUnp->csNumeric, NULL);
                }
            }
            break;

        case NumberType:
            if (autoConvNumToFloatFlg == TRUE)
            {
                retSybDataFmt->datatype = CS_FLOAT_TYPE;
                retSybDataFmt->maxlength = sizeof(CS_FLOAT);

                if (srcDataPtr != NULL)
                {
                    retSybDataUnp->csFloat = *((CS_FLOAT *)srcDataPtr);
                }
            }
            else
            {
                csDataFmtSrc.datatype = CS_FLOAT_TYPE;
                csDataFmtSrc.maxlength = sizeof(CS_FLOAT);
                csDataFmtSrc.locale = NULL;
                retSybDataFmt->datatype = CS_NUMERIC_TYPE;
                retSybDataFmt->maxlength = sizeof(CS_NUMERIC);
                retSybDataFmt->precision = NUMBER_T_LEN;
                retSybDataFmt->scale = NUMBER_T_DEC;

                if (srcDataPtr != NULL)
                {
                    EV_rxaFctStruct.pfn_cs_convert(csContext, &csDataFmtSrc, srcDataPtr, retSybDataFmt, &retSybDataUnp->csNumeric, NULL);
                }
            }
            break;

        case PercentType:
            if (autoConvNumToFloatFlg == TRUE)
            {
                retSybDataFmt->datatype = CS_FLOAT_TYPE;
                retSybDataFmt->maxlength = sizeof(CS_FLOAT);

                if (srcDataPtr != NULL)
                {
                    retSybDataUnp->csFloat = *((CS_FLOAT *)srcDataPtr);
                }
            }
            else
            {
                csDataFmtSrc.datatype = CS_FLOAT_TYPE;
                csDataFmtSrc.maxlength = sizeof(CS_FLOAT);
                csDataFmtSrc.locale = NULL;
                retSybDataFmt->datatype = CS_NUMERIC_TYPE;
                retSybDataFmt->maxlength = sizeof(CS_NUMERIC);
                retSybDataFmt->precision = PERCENT_T_LEN;
                retSybDataFmt->scale = PERCENT_T_DEC;

                if (srcDataPtr != NULL)
                {
                    EV_rxaFctStruct.pfn_cs_convert(csContext, &csDataFmtSrc, srcDataPtr, retSybDataFmt, &retSybDataUnp->csNumeric, NULL);
                }
            }
            break;
			
        case PriceType:
			if (autoConvNumToFloatFlg == TRUE)
			{
				retSybDataFmt->datatype = CS_FLOAT_TYPE;
				retSybDataFmt->maxlength = sizeof(CS_FLOAT);

				if (srcDataPtr != NULL)
				{
					retSybDataUnp->csFloat = *((CS_FLOAT *)srcDataPtr);
				}
			}
			else
			{
				csDataFmtSrc.datatype = CS_FLOAT_TYPE;
				csDataFmtSrc.maxlength = sizeof(CS_FLOAT);
				csDataFmtSrc.locale = NULL;
				retSybDataFmt->datatype = CS_NUMERIC_TYPE;
				retSybDataFmt->maxlength = sizeof(CS_NUMERIC);
				retSybDataFmt->precision = PRICE_T_LEN;
				retSybDataFmt->scale = PRICE_T_DEC;

				if (srcDataPtr != NULL)
				{
					EV_rxaFctStruct.pfn_cs_convert(csContext, &csDataFmtSrc, srcDataPtr, retSybDataFmt, &retSybDataUnp->csNumeric, NULL);
				}
			}
			break;	

        case DictType:
            if (autoConvNumToFloatFlg == TRUE)
            {
                retSybDataFmt->datatype = CS_FLOAT_TYPE;
                retSybDataFmt->maxlength = sizeof(CS_FLOAT);

                if (srcDataPtr != NULL)
                {
                    retSybDataUnp->csFloat = (CS_FLOAT)*((long *)srcDataPtr);
                }
            }
            else
            {
                csDataFmtSrc.datatype = CS_INT_TYPE;
                csDataFmtSrc.maxlength = sizeof(CS_INT);
                csDataFmtSrc.locale = NULL;
                retSybDataFmt->datatype = CS_NUMERIC_TYPE;
                retSybDataFmt->maxlength = sizeof(CS_NUMERIC);
                retSybDataFmt->precision = DICT_T_LEN;
                retSybDataFmt->scale = DICT_T_DEC;

                if (srcDataPtr != NULL)
                {
                    EV_rxaFctStruct.pfn_cs_convert(csContext, &csDataFmtSrc, srcDataPtr, retSybDataFmt, &retSybDataUnp->csNumeric, NULL);
                }
            }
            break;

        case IdType:
            if (autoConvNumToFloatFlg == TRUE)
            {
                retSybDataFmt->datatype = CS_FLOAT_TYPE;
                retSybDataFmt->maxlength = sizeof(CS_FLOAT);

                if (srcDataPtr != NULL)
                {
                    retSybDataUnp->csFloat = (CS_FLOAT)*((long *)srcDataPtr);
                }
            }
            else
            {
                csDataFmtSrc.datatype = CS_BIGINT_TYPE;
                csDataFmtSrc.maxlength = sizeof(CS_BIGINT);
                csDataFmtSrc.locale = NULL;
                retSybDataFmt->datatype = CS_NUMERIC_TYPE;
                retSybDataFmt->maxlength = sizeof(CS_NUMERIC);
                retSybDataFmt->precision = ID_T_LEN;
                retSybDataFmt->scale = ID_T_DEC;

                if (srcDataPtr != NULL)
                {
                    EV_rxaFctStruct.pfn_cs_convert(csContext, &csDataFmtSrc, srcDataPtr, retSybDataFmt, &retSybDataUnp->csNumeric, NULL);
                }
            }
            break;


        case EnumMaskType:			/* PMSTA13460 - TGU - 120424 */
            if (autoConvNumToFloatFlg == TRUE)
            {
                retSybDataFmt->datatype = CS_FLOAT_TYPE;
                retSybDataFmt->maxlength = sizeof(CS_FLOAT);

                if (srcDataPtr != NULL)
                {
                    retSybDataUnp->csFloat = (CS_FLOAT)*((long *)srcDataPtr);
                }
            }
            else
            {
                csDataFmtSrc.datatype = CS_BIGINT_TYPE;
                csDataFmtSrc.maxlength = sizeof(CS_BIGINT);
                csDataFmtSrc.locale = NULL;
                retSybDataFmt->datatype = CS_NUMERIC_TYPE;
                retSybDataFmt->maxlength = sizeof(CS_NUMERIC);
                retSybDataFmt->precision = ENUMMASK_T_LEN;
                retSybDataFmt->scale = ENUMMASK_T_DEC;

                if (srcDataPtr != NULL)
                {
                    EV_rxaFctStruct.pfn_cs_convert(csContext, &csDataFmtSrc, srcDataPtr, retSybDataFmt, &retSybDataUnp->csNumeric, NULL);
                }
            }
            break;

        case DateType:
            retSybDataFmt->datatype = CS_DATETIME_TYPE;
            retSybDataFmt->maxlength = sizeof(CS_DATETIME);
            refDate = DATE_Put((YEAR_T)1900, (MONTH_T)1, (DAY_T)1);
            DATE_DaysBetween(refDate, GET_DATE(fldPtr, 0), AccrRule_Actual_365, &daysNbr, 0);                  /* PMSTA-15918 - 070213 - PMO */  /* PMSTA-22396  - SRIDHARA – 160430 */
            retSybDataUnp->csDatetime.dtdays = daysNbr;
            retSybDataUnp->csDatetime.dttime = 0;
            break;

        case DatetimeType:
            retSybDataFmt->datatype = CS_DATETIME_TYPE;
            retSybDataFmt->maxlength = sizeof(CS_DATETIME);
            refDate = DATE_Put((YEAR_T)1900, (MONTH_T)1, (DAY_T)1);
            DATE_DaysBetween(refDate, GET_DATE(fldPtr, 0), AccrRule_Actual_365, &daysNbr, 0);                  /* PMSTA-15918 - 070213 - PMO */  /* PMSTA-22396  - SRIDHARA – 160430 */
            retSybDataUnp->csDatetime.dtdays = daysNbr;                                                     /* PMSTA-15918 - 070213 - PMO */
            TIME_Get(GET_DATETIME(fldPtr, 0).time, &hour, &min, &second);                                    /* PMSTA-15918 - 070213 - PMO */
            retSybDataUnp->csDatetime.dttime = (CS_INT)((hour * 3600 + min * 60 + second) * 300);
            break;

        case CodeType:
        case InfoType:
        case ShortinfoType:
        case LongnameType:
        case NameType:
        case NoteType:
        case PhoneType:
        case SysnameType:
        case LongSysnameType: /* PMSTA-14086 - LJE - 121008 */
        case TextType:
        case UrlType:
        case String1000Type: /* DLA - PMSTA07121 - 090210 */
        case String2000Type:
        case String3000Type:
        case String4000Type:
        case String7000Type:
        case String15000Type:

            retSybDataFmt->datatype = CS_VARCHAR_TYPE;
            retSybDataFmt->format = CS_FMT_NULLTERM;
            retSybDataFmt->maxlength = GET_MAXLEN(dataType);

            if (srcDataPtr != NULL)
            {
                strcpy(retSybDataUnp->csVarchar.str, (char *)srcDataPtr);  /* REF7264 - PMO */
                retSybDataUnp->csVarchar.len = (CS_SMALLINT)GET_FLD_STRLEN(fldPtr, 0);
            }
            break;

        case IntType:
            retSybDataFmt->datatype = CS_INT_TYPE;
            retSybDataFmt->maxlength = sizeof(CS_INT);

            if (srcDataPtr != NULL)
            {
                retSybDataUnp->csInt = *((CS_INT *)srcDataPtr);
            }
            break;

        case FlagType:
        case EnumType:
        case MethodType:
        case TinyintType:
            retSybDataFmt->datatype = CS_TINYINT_TYPE;
            retSybDataFmt->maxlength = sizeof(CS_TINYINT);

            if (srcDataPtr != NULL)
            {
                retSybDataUnp->csTinyint = *((CS_TINYINT *)srcDataPtr);
            }
            break;

        case LongintType:			/* PMSTA-20887 - LJE - 150909 */
            if (autoConvNumToFloatFlg == TRUE)
            {
                retSybDataFmt->datatype = CS_FLOAT_TYPE;
                retSybDataFmt->maxlength = sizeof(CS_FLOAT);

                if (srcDataPtr != NULL)
                {
                    retSybDataUnp->csFloat = (CS_FLOAT)*((long *)srcDataPtr);
                }
            }
            else
            {
                csDataFmtSrc.datatype = CS_BIGINT_TYPE;
                csDataFmtSrc.maxlength = sizeof(CS_BIGINT);
                csDataFmtSrc.locale = NULL;
                retSybDataFmt->datatype = CS_NUMERIC_TYPE;
                retSybDataFmt->maxlength = sizeof(CS_NUMERIC);
                retSybDataFmt->precision = LONGINT_T_LEN;
                retSybDataFmt->scale = LONGINT_T_DEC;

                if (srcDataPtr != NULL)
                {
                    EV_rxaFctStruct.pfn_cs_convert(csContext, &csDataFmtSrc, srcDataPtr, retSybDataFmt, &retSybDataUnp->csNumeric, NULL);
                }
            }
            break;

        case PeriodType:
        case SmallintType:
            retSybDataFmt->datatype = CS_SMALLINT_TYPE;
            retSybDataFmt->maxlength = sizeof(CS_SMALLINT);

            if (srcDataPtr != NULL)
            {
                retSybDataUnp->csSmallint = *((CS_SMALLINT *)srcDataPtr);
            }
            break;

        case MaskType:
        case TimeType:
        case YearType:
            break;

        default:
            break;
    }

    return(RET_SUCCEED);
}
/************************************************************************
*   Function             : SYB_ConfigureClientLibrary()
*
*   Description          : Configure The database client libraries after first initialisation connection
*
*   Arguments            :
*
*   Return               : RET_SUCCEED        : if no problem was detected
*
*   Creation Date        : PMSTA-51666 - FME - 2024-01-24
*   Last Modification    :
*
*************************************************************************/
RET_CODE SYB_ConfigureClientLibrary( int maxConnNbr)
{
    CS_CONTEXT* csContext = SYB_GetCsContext();

    if (EV_rxaFctStruct.pfn_ct_config(csContext, CS_SET, CS_MAX_CONNECT, &maxConnNbr, CS_UNUSED, UNUSED) != CS_SUCCEED)
    {
        MSG_LogMesg(RET_DBA_ERR_HANDLECONPROP, 0, FILEINFO);
        return(RET_DBA_ERR_HANDLECONPROP);
    }

    return (RET_SUCCEED);
}

/************************************************************************
*   Function             : SYB_SetGeneralCharset()
*
*   Description          :
*
*   Arguments            : currentCharsetCode : a valid charset code.
*
*   Return               : RET_SUCCEED        : if no problem was detected
*
*   Creation Date        : 11.06.97 - GRD - Ref.: DVP493.
*   Last Modification    : REF7264 - 011212 - PMO : Compilation errors and warnings with C++ compiler
*
*************************************************************************/
RET_CODE SYB_SetGeneralCharset(CURRENTCHARSETCODE_ENUM currentCharsetCode)
{
    CS_LOCALE *     localDefault;

    const char * charsetName = GEN_GetCurCharset(currentCharsetCode, CharsetCodeType_Rdbms); /* DLA - REF9303 - 030826 */

    CURRENTCHARSETCODE_ENUM defCurrCharSetEn = CurrentCharsetCode_IsNull;
    GEN_GetApplInfo(ApplCurrentCharsetCodeEnum, &defCurrCharSetEn);
    GEN_SetApplInfo(ApplDbCommCharsetCodeEnum, &defCurrCharSetEn);

    if (EV_rxaFctStruct.pfn_cs_loc_alloc(SYB_GetCsContext(), &localDefault) != CS_SUCCEED)
    {
        MSG_LogMesg(RET_GEN_ERR_CHARSETPROBLEMS, 2, FILEINFO);
        return(RET_DBA_ERR_HANDLECONPROP);
    }

    if (EV_rxaFctStruct.pfn_cs_locale(SYB_GetCsContext(), CS_SET, localDefault,
                                      CS_LC_ALL, NULL, CS_UNUSED, NULL) != CS_SUCCEED)
    {
        EV_rxaFctStruct.pfn_cs_loc_drop(SYB_GetCsContext(), localDefault);
        MSG_LogMesg(RET_GEN_ERR_CHARSETPROBLEMS, 2, FILEINFO);
        return(RET_DBA_ERR_HANDLECONPROP);
    }

    if (EV_rxaFctStruct.pfn_cs_locale(SYB_GetCsContext(), CS_SET, localDefault,
                                      CS_SYB_CHARSET, (CS_CHAR*)charsetName, CS_NULLTERM, NULL) != CS_SUCCEED)
    {
        EV_rxaFctStruct.pfn_cs_loc_drop(SYB_GetCsContext(), localDefault);
        MSG_LogMesg(RET_GEN_ERR_CHARSETPROBLEMS, 0, FILEINFO, charsetName);
        return(RET_DBA_ERR_HANDLECONPROP);
    }

    if (EV_rxaFctStruct.pfn_cs_config(SYB_GetCsContext(), CS_SET, CS_LOC_PROP, (void *)localDefault, CS_UNUSED, NULL) != CS_SUCCEED)
    {
        EV_rxaFctStruct.pfn_cs_loc_drop(SYB_GetCsContext(), localDefault);
        MSG_LogMesg(RET_GEN_ERR_CHARSETPROBLEMS, 3, FILEINFO, charsetName);
        return(RET_DBA_ERR_HANDLECONPROP);
    }

    EV_rxaFctStruct.pfn_cs_loc_drop(SYB_GetCsContext(), localDefault);

    return (RET_SUCCEED);
}

/************************************************************************
*   Function             : SYB_GetGeneralCharset()
*
*   Description          : Prints the current charset used by Sybase.
*                          Debug purposes.
*
*   Arguments            : None.
*
*   Return               : TRUE, FALSE.
*
*   Creation Date        : 07.08.97 - GRD
*   Last Modification    :
*
*************************************************************************/
int SYB_GetGeneralCharset()
{
    CODE_T          generalCharsetName;
    CS_LOCALE       *localDefault;
    CS_INT          charsetNameL = 0;


    memset(generalCharsetName, 0, sizeof(CODE_T));

    if (EV_rxaFctStruct.pfn_cs_loc_alloc(SYB_GetCsContext(), &localDefault) != CS_SUCCEED)
        return(FALSE);

    if (EV_rxaFctStruct.pfn_cs_locale(SYB_GetCsContext(), CS_SET, localDefault, CS_LC_ALL, NULL, CS_UNUSED, NULL) != CS_SUCCEED)
    {
        EV_rxaFctStruct.pfn_cs_loc_drop(SYB_GetCsContext(), localDefault);
        return(FALSE);
    }

    if (EV_rxaFctStruct.pfn_cs_locale((CS_CONTEXT *)SYB_GetCsContext(), CS_GET, localDefault, CS_SYB_CHARSET,
        (CS_CHAR *)generalCharsetName, GET_MAXDATALEN(CodeType), (CS_INT *)&charsetNameL) != CS_SUCCEED)    /* PMSTA-33077 - DLA - 181012 */
    {
        generalCharsetName[charsetNameL] = END_OF_STRING;
        EV_rxaFctStruct.pfn_cs_loc_drop(SYB_GetCsContext(), localDefault);
        return(FALSE);
    }

    EV_rxaFctStruct.pfn_cs_loc_drop(SYB_GetCsContext(), localDefault);

    printf("\n General charset: %s\n", generalCharsetName);

    return(TRUE);
}

/************************************************************************
**
** Function    : SYB_DatetimeToSybDataStr
**
** Description : REF4472
**
** Arguments   :
**
** Return      : RET_CODE
**
** Creation    : sme (Monday May 08 2000)
** Modification: REF8844 - LJE - 030401 : Add fldNbr
**
************************************************************************/
RET_CODE SYB_DatetimeToSybDataStr(char *str, DBA_DYNFLD_STP p, int fldNbr, int *length)
{
    YEAR_T y; MONTH_T m; DAY_T d;
    HOUR_T h; MINUTE_T mn; SECOND_T s;

    DATETIME_T datetime = GET_DATETIME(p, fldNbr); /* REF8844 - LJE - 030401 */
    DATE_Get(datetime.date, &y, &m, &d);
    TIME_Get(datetime.time, &h, &mn, &s);

    /***** BEGIN BUG204 date : 00/00/0000 *****/
    if (m == 0 || d == 0 || y == 0)
    {
        strcpy(str, " NULL");
        return RET_SUCCEED;
    }
    /***** END   BUG204 date : 00/00/0000 *****/

    int carNbr = sprintf(str, "\"%02d/%02d/%04d %02d:%02d:%02d\"", m, d, y, h, mn, s);

    if (length != nullptr)
        *length = carNbr;

    return RET_SUCCEED;
}

/************************************************************************
**
** Function    : SYB_PrintVersion
**
** Description : Print to stdout the SYBASE library actually loaded
**
** Arguments   :
**
** Return      : None
**
** Creation    : DLA
**
************************************************************************/
void SYB_PrintVersion()
{
    CS_CHAR buf[1024];
    CS_INT  outlen = 0;
    CS_INT  len = 0;


    if (EV_rxaFctStruct.pfn_ct_config(SYB_GetCsContext(), CS_GET, CS_VER_STRING, buf, CS_SIZEOF(buf), &outlen) == CS_SUCCEED)
    {
        if (outlen >= CS_SIZEOF(buf))
        {
            len = (CS_SIZEOF(buf) - 1);
        }
        else
        {
            len = outlen;
        }

        buf[len] = '\0';
        printf("%s\n\n", buf);
    }
}

/************************************************************************
**
** Function    : SYB_CheckUserRole
**
** Description : Check if the user define in the connection have the parameter role
**
** Arguments   :
**
** Return      : true if the current user have the role
**
************************************************************************/
bool SYB_CheckUserRole(SybConnection& dbiConn, const string& role)
{

    stringstream        sqlCmd;
    int                 status;
    CS_RETCODE          code;
    CS_RETCODE          type;
    CS_INT              hasRole = 0, count = 0;


    sqlCmd
        << "declare @has_role int" << endl
        << "select @has_role = has_role('" << role << "', 1)" << endl
        << "select @has_role" << endl;


    if (SYB_CtCommand(dbiConn, DBA_LANG, sqlCmd.str().c_str(), NULL) != CS_SUCCEED)
    {
        return FALSE;
    }

    DATE_START_TIMER(1, TIMER_MASK_SQLC);

    if (SYB_CtSend(dbiConn) != CS_SUCCEED)
    {
        return FALSE;
    }

    while ((code = SYB_CtResults(dbiConn, &type)) == CS_SUCCEED)
    {
        switch (type)
        {

            case CS_ROW_RESULT:
                SYB_ColBind(dbiConn, 1, CS_INT_TYPE, &hasRole);
                while (SYB_CtFetch(dbiConn, CS_UNUSED, CS_UNUSED, CS_UNUSED, &count) == RET_SUCCEED)
                    ;
                break;

            case CS_STATUS_RESULT:
                SYB_ColBind(dbiConn, 1, CS_INT_TYPE, &status);

                while (SYB_CtFetch(dbiConn, CS_UNUSED, CS_UNUSED, CS_UNUSED, &count) == RET_SUCCEED)
                    ;

                break;

            case CS_CMD_SUCCEED:
                break;

            case CS_CMD_DONE:
                break;                /* REF4152 - SSO - 991220 */
            case CS_CMD_FAIL:
                break;

            default:
                break;
        }

    }
    return hasRole == 1;
}

/************************************************************************
**
** Function    : SYB_CheckValidUserName
**
** Description : Check if the user define in the connection have the parameter role
**
** Arguments   :
**
** Return      : true if the current user have the role
**
************************************************************************/
bool SYB_CheckValidUserName(DbiConnection& dbiConn, const string& user_name)
{
    INT_T              *isValidPtr = nullptr;

    RequestHelper requestHelper(&dbiConn);
    requestHelper.setReadOnly(true);

    const AAALogger& sqlTraceLog = AAALogger::get(AAALogger::Logger::SqlTrace);
    if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
    {
        auto &sqlTrace = dbiConn.getSqlTrace();
        sqlTrace.m_procedure = "DynSql.CheckValidUserName";
        sqlTrace.m_mode = DbiSqlTrace::Mode::Lang;
    }

    requestHelper.addNewParamString(user_name, SysnameType);
    requestHelper.setCommand("select valid_name(?)");
    requestHelper.addNewOutputData(IntType);
    requestHelper.getBindVariablePtr(isValidPtr);

    requestHelper.sendAndGetCommand();

    return (isValidPtr != nullptr && *isValidPtr != 0);
}

/************************************************************************
**   END  syblib01.c                                                   **
*************************************************************************/

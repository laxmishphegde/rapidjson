/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/**************************** FUNCTION LIST *****************************
**
** SYB_BindRecvDynSt()  Sybase Bind of a received Buffer in a DYNST rec
**          All received data are in a Sybase known format
**          and are converted into our C formats
**
*************************************************************************/

/************************************************************************
**     Defines
*************************************************************************/
#define SYBLIB03_C
/************************************************************************
**     Include files
*************************************************************************/

#define STDIO_H
#define TIME_H

#define STDARG_H
#define STRING_H
#define STDLIB_H

#include <assert.h> /* DLA - REF9089 - 030513 */

#include <string>

#include <ctpublic.h>

#include "unidef.h"     /* Mandatory */

#ifndef GEN_H
#include "gen.h"
#endif

#ifndef DATE_H
#include "date.h"
#endif

#include "dba.h"

#ifndef PROC_H
#include "proc.h"
#endif

#ifndef MSG_H
#include "msg.h"
#endif

#ifndef SYB_H
#include "syb.h"
#endif

#ifndef SYSLIB_H
#include "syslib.h"     /* PMO - Rename our sys.h to syslib.h and use it */
#endif

#ifndef TLS_H
#include "tls.h"
#endif

#include "sybconnection.h"

#include <iomanip>
#include <cstring>

#include "ddlgenfromfile.h"
#include "ddlgenvar.h"
#include "aaasql.h"
#include "dbi.h"
#include "str.h"
#include "date.h"
#include "fussync.h"
#include "rxa.h"

#include <conv.h>

extern RXA_FCTPTR EV_rxaFctStruct; /* DLA - PMSTA-23431 - 160824 */

using namespace std;

/************************************************************************
*   Function             : DBA_GimmeNetRunning()
*
*   Description          : Retrieve running processes correponding to
*                          the given string from sybase.
*
*   Arguments            : An application name.
*                          Modules.
*
*   Functions call       :
*
*   Return               : RET_SUCCEED           : if ok.
*                          DBA_CONN_NOT_FOUND    : if connection failed.
*                          RET_DBA_ERR_DBPROBLEM : if problem with sybase.
*                          RET_GEN_ERR_INVARG    : if application name null.
*
*   Creation Date        : 01.04.1997: GRD - DVP404.
*   Last Modif           : 14.12.1998: GRD - REF3073.
*                          REF7264 - 0201225 - PMO : Compilation errors and warnings with C++ compiler
*                          PMSTA-17133 - 051113 - PMO : Many compilation warnings in C code especially " Converting a 64-bit type value to "int" causes truncation."
*                          PMSTA-30941 - 200418 - PMO : Fix gcc 8 compilations warnings related to the stabilization
*
*************************************************************************/
RET_CODE SYB_GimmeNetRunning(const char	*appName,		/* Application name to spy. *//* REF8728 - YST - 030218 */
                             short	*netCoreNb,
                             short	*netProdModNb,
                             short	*netAttribModNb,
                             short	*netRiskModNb,
                             short	*netAccModNb,
                             short	*netFundModNb,
                             short	*netCorpActionsModNb,
                             short	*netAdvAnalyticsModNb,
                             short	*netCompManagementModNb,
                             short	*netExcelReportModNb,
                             short	*netRAModNb,
                             short	*netACMModNb,
                             short	*netOMModNb)
{
    CS_INT      count = 0;
    CS_INT      resultType = 0;
    NAME_T      prgName; /* DLA - PMSTA09887 - 101116 */
	NAME_T		hostProcess; /* PMSTA-44740 - 042621 - sriharbv*/
    unsigned    appNumber;      /* PMSTA-17133 - 051113 - PMO */
    DBI_INT     status = 0;
    char        buffer[512];

	/* Verify data integrity. */
	if (appName == NULL)
	{
		return(RET_GEN_ERR_INVARG);
	}

	/* Retrieve current connection to sybase. */
	DbiConnection* dbiConn = DBA_GetDbiConnection(SqlServer, ROLE_ADMIN);
	if (dbiConn == nullptr)
	{
		MSG_SendMesg(RET_DBA_ERR_NOFREESYNCCONN, 0, FILEINFO);
		return(DBA_CONN_NOT_FOUND);
	}

	sprintf(buffer, "select distinct program_name,hostprocess from master..sysprocesses sp where program_name like \"%s%%\" and sp.dbid = db_id()", appName);    /* PMSTA-30941 - 200418 - PMO */ /* PMSTA-44740 - 042621 - sriharbv*/

	/* Must be initialized to zero. */
	*netCoreNb = 0;
	*netProdModNb = 0;
	*netAttribModNb = 0;
	*netRiskModNb = 0;
	*netAccModNb = 0;
	*netFundModNb = 0;
	*netCorpActionsModNb = 0;
	*netAdvAnalyticsModNb = 0;
	*netCompManagementModNb = 0;
	*netExcelReportModNb = 0;
	*netRAModNb = 0;
	*netACMModNb = 0;
	*netOMModNb = 0;

    SybConnection *sybConn = dynamic_cast<SybConnection*>(dbiConn);
	/* Define the language type to be used. */
	if (SYB_CtCommand(*sybConn, DBA_LANG, buffer, NULL) != CS_SUCCEED) /* REF10195 - LJE - 040407 */
	{
		dbiConn->cancelDbRequest(COMMAND_LEVEL, CANCEL_ALL);
		dbiConn->cancelDbRequest(COMMAND_LEVEL, CANCEL_ALL);
		DBA_EndConnection(&dbiConn,true);
		return(RET_DBA_ERR_CONNOTFOUND);
	}

	/* Send the command to the Server */
	if (SYB_CtSend(*sybConn) != CS_SUCCEED)
	{
        dbiConn->cancelDbRequest( COMMAND_LEVEL, CANCEL_ALL);
        dbiConn->cancelDbRequest( COMMAND_LEVEL, CANCEL_ALL);
		DBA_EndConnection(&dbiConn, true);
		MSG_RETURN(RET_DBA_ERR_DBPROBLEM);
	}

	/* Returned status. */
	if (SYB_CtResults(*sybConn, &resultType) != CS_SUCCEED) /* REF7264 - PMO */
	{
		dbiConn->cancelDbRequest(COMMAND_LEVEL, CANCEL_ALL);
		dbiConn->cancelDbRequest(COMMAND_LEVEL, CANCEL_ALL);
		DBA_EndConnection(&dbiConn);
		return(DBA_CONN_NOT_FOUND);
	}

	/* Type of data to retrieve. */
	SYB_ColBind(*sybConn, 1, CS_CHAR_TYPE, prgName); /* REF7264 - PMO */
	SYB_ColBind(*dbiConn, 2, CS_CHAR_TYPE, hostProcess); /* PMSTA-44740 - 042621 - sriharbv*/

	while (SYB_CtFetch(*sybConn, CS_UNUSED, CS_UNUSED, CS_UNUSED, &count) == RET_SUCCEED) /* REF7264 - PMO */
	{
		/* Sybase fills with spaces data less than its defined size. Supress spaces that ends strings. */
        char * charCursor = prgName + (SYS_StrLen(prgName) - 1);

		while ((*charCursor == ' ') && (charCursor != prgName))
		{
			*charCursor = '\0';
			charCursor--;
		}

		if (SYS_StrLen(prgName) == SYS_StrLen(appName))
		{
			continue;
		}

		/* Position cursor to the beggining of module descriptions. */
		charCursor = prgName + SYS_StrLen(appName);
		sprintf(buffer, charCursor);

		sscanf(buffer, "%X", &appNumber);

		*netCoreNb += 1;

		if ((appNumber & MODULE_MASK_PROD) != 0)
			*netProdModNb += 1;

		if ((appNumber & MODULE_MASK_ATTRIB) != 0)
			*netAttribModNb += 1;

		if ((appNumber & MODULE_MASK_RISK) != 0)
			*netRiskModNb += 1;

		if ((appNumber & MODULE_MASK_ACC) != 0)
			*netAccModNb += 1;

		if ((appNumber & MODULE_MASK_FUND) != 0)
			*netFundModNb += 1;

		if ((appNumber & MODULE_MASK_CORPACTION) != 0)
			*netCorpActionsModNb += 1;

		if ((appNumber & MODULE_MASK_ADVANAL) != 0)
			*netAdvAnalyticsModNb += 1;

		if ((appNumber & MODULE_MASK_COMPOMGR) != 0)
			*netCompManagementModNb += 1;

		if ((appNumber & MODULE_MASK_EXCEL) != 0)
			*netExcelReportModNb += 1;

		if ((appNumber & MODULE_MASK_RA) != 0)
			*netRAModNb += 1;

		if ((appNumber & MODULE_MASK_ACM) != 0)
			*netACMModNb += 1;

		if ((appNumber & MODULE_MASK_OM) != 0)
			*netOMModNb += 1;
	}

	dbiConn->processAllResults(&status);
	DBA_EndConnection(&dbiConn);

	return(RET_SUCCEED);
}

/************************************************************************
*   Function             : getDatatypeFromCT()
*
*   Description          :
*
*   Arguments            :
*
*   Functions call       :
*
*   Return               :
*
*   Last Modification    :
*************************************************************************/
STATIC DATATYPE_ENUM getDatatypeFromCT(CS_DATAFMT dataFmt)
{
    DATATYPE_ENUM dataType;
    string nativType;
    int precision = dataFmt.precision == 0 ? dataFmt.maxlength : dataFmt.precision, scale = dataFmt.scale;

    switch (dataFmt.datatype)
    {
        case CS_BIGINT_TYPE:
            if (precision < 14)
            {
                /* IdType */
                precision = 14;
            }
            break;

        case CS_FLOAT_TYPE:
            if (precision < 21)
            {
                /* NumberType */
                precision = 21;
                scale = 9;
            }
            break;

        default:
            break;
    }
    switch (dataFmt.datatype)
    {
        case CS_CHAR_TYPE:
        case CS_VARCHAR_TYPE:
        case CS_LONGCHAR_TYPE:
            nativType = "varchar";
            scale = -1;
            break;

        case CS_UNICHAR_TYPE:
            nativType = "univarchar";
            scale = -1;
            break;

        case CS_DATETIME_TYPE:
            nativType = "datetime";
            precision = -1;
            break;

        case CS_BIGINT_TYPE:
        case CS_FLOAT_TYPE:
        case CS_NUMERIC_TYPE:
            nativType = "numeric";
            break;

        case CS_TINYINT_TYPE:
            nativType = "tinyint";
            precision = -1;
            break;

        case CS_INT_TYPE:
            nativType = "int";
            precision = -1;
            break;

        case CS_SMALLINT_TYPE:
            nativType = "smallint";
            precision = -1;
            break;

        default:
            break;
    }

    dataType = DBA_GetDataTypeFromEquivType(Sybase, nativType, precision, scale);
    return dataType;
}


/************************************************************************
*   Function             : _SYB_ManagedSqlExec()
*
*   Description          : Send a character string representing a SQL Dynamic
*                          request. Bind status
*                          This is a sub function of SYB_ManagedSqlExec and must not be called directly
*
*   Arguments            : sqlContextStp
*                          status          : pointer on status to be binded
*                          msgStructPtr
*                          fusSync         : For synchronized fusion only
*
*   Functions call       :
*
*   Return               : RET_SUCCEED : if ok
*
*   Last Modification    : PMSTA-27421 - 290517 - PMO : Synchronized list is executed asynchronously on Sybase
*
*************************************************************************/
STATIC RET_CODE _SYB_ManagedSqlExec(AAASQL_CONTEXT_STP sqlContextStp, DBA_DYNFLD_STP fusSync)
{
    RET_CODE             ret = RET_SUCCEED, gblRet = RET_SUCCEED;
    SybConnection       *dbiConnPtr = dynamic_cast<SybConnection*>(sqlContextStp->connHelperPtr->getConnection());

    MemoryPool           mp;                                                /* PMSTA-27421 - 290517 - PMO */

    CS_INT               colNumber = 0, rowNumber = 0, cmdNumber = 0, i;
    CS_RETCODE       	 results_ok;
    CS_INT		         result_type;

    CS_DATAFMT           csDataFmt;
    bool                 bAssignVars = false;
    bool                 bISqlBehavior = (sqlContextStp->verboseLevel == VerboseLevel_iSQL || 
                                          sqlContextStp->verboseLevel == VerboseLevel_HideEmptyResultSet || 
                                          sqlContextStp->verboseLevel == VerboseLevel_Align);

    bool                 bStatusResult = false, bRowCount = false, bRowResult = false;
    bool                 bStopServer = (sqlContextStp->rpcName.compare("stop_server") == 0);
    bool                 bHideMessage = bStopServer || dbiConnPtr->isExternalMsgManagement();

    CURRENTCHARSETCODE_ENUM outputCharSet = CurrentCharsetCode_UTF8;
    CURRENTCHARSETCODE_ENUM charSet = dbiConnPtr->getCurrCharsetEn();

    GEN_GetApplInfo(ApplCurrentCharsetOutputEnum, &outputCharSet);
    
    dbiConnPtr->setExternalMsgManagement(bHideMessage);

    std::string dropProcCmd;
    if (sqlContextStp->scriptDdlGenPtr != nullptr &&
        sqlContextStp->scriptDdlGenPtr->m_bSendRequestWithProc)
    {
        DdlGen ddlGen(Empty,
                      TargetTable_Main,
                      *sqlContextStp->scriptDdlGenPtr);

        auto now = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch()).count();
        std::string tmpProcName(SYS_Stringer("tmp_proc_", now));

        dropProcCmd = ddlGen.getCmdIfExsists(ddlGen.getCmdSelObjInDb(dbiConnPtr->getActualDbName(), ddlGen.getEntitySqlName(), tmpProcName, DdlObj_SProc),
                                             "\t" + ddlGen.getDdlModif(ddlGen.getCmdDrop(dbiConnPtr->getActualDbName(), ddlGen.getEntitySqlName(), tmpProcName, DdlObj_SProc)),
                                             string());

        ddlGen.bodySqlBlock << dropProcCmd;
        ddlGen.cmdType = DDlCmdType_Drop;
        (void)ddlGen.flush();

        ddlGen.bodySqlBlock << ddlGen.getCmdCreate(dbiConnPtr->getActualDbName(),
                                                   ddlGen.getEntitySqlName(),
                                                   tmpProcName,
                                                   DdlObj_SProc);
        ddlGen.printBeginProc(ddlGen.bodySqlBlock.bodyStream(), nullptr);

        ddlGen.bodySqlBlock << sqlContextStp->sqlCmd;
        ddlGen.bodySqlBlock << endl << "end" << ddlGen.getCmdEndOfCmd() << endl;

        ddlGen.cmdType = DDlCmdType_Create;
        (void)ddlGen.flush();

        dbiConnPtr->startRequest();

        /* Register the request in the command structure */
        if (SYB_CtCommand(*dbiConnPtr, DBA_LANG, SYS_Stringer("exec ", tmpProcName).c_str(), NULL) != CS_SUCCEED)
        {
            return(RET_DBA_ERR_DBPROBLEM);
        }
    }
    else if (sqlContextStp->bSetParamDone == false)
    {
        dbiConnPtr->startRequest();

        if (sqlContextStp->rpcName.empty())
        {
            /* Register the request in the command structure */
            if (SYB_CtCommand(*dbiConnPtr, DBA_LANG, sqlContextStp->sqlCmd.c_str(), NULL) != CS_SUCCEED)
            {
                return(RET_DBA_ERR_DBPROBLEM);
            }
        }
        else
        {
            /* Register the request in the command structure */
            if (SYB_CtCommand(*dbiConnPtr, DBA_RPC, sqlContextStp->rpcName.c_str(), NULL) != CS_SUCCEED)
            {
                return(RET_DBA_ERR_DBPROBLEM);
            }
        }
    }

    bool                 bIsAddDataResultSet = (sqlContextStp->scriptDdlGenPtr != nullptr &&
                                                sqlContextStp->scriptDdlGenPtr->bKeepData == true &&
                                                sqlContextStp->scriptDdlGenPtr->bKeepResultSetData == false);

    /* PMSTA-37366 - LJE - 200429 */
    if (bIsAddDataResultSet)
    {
        sqlContextStp->scriptDdlGenPtr->freeResultSetData();
    }

    CS_COMMAND *    csCommand = dbiConnPtr->m_command;
    CS_RETCODE      sybRetCode   = SYB_CtSend(*dbiConnPtr);

    if (sybRetCode != CS_SUCCEED && sybRetCode != CS_PENDING)
    {
        return(RET_DBA_ERR_DBPROBLEM);
    }

    size_t resultSetIdx = 0;

    while ((results_ok = SYB_CtResults(*dbiConnPtr, &result_type)) == CS_SUCCEED)
    {
        switch (result_type)
        {
            case CS_ROW_RESULT:
            {
                bRowResult    = true;
                bStatusResult = false;
                bRowCount     = false;
                rowNumber     = 0;

                vector<DdlGenDataField> ddlGenDataFieldVector;

                EV_rxaFctStruct.pfn_ct_res_info(csCommand, CS_CMD_NUMBER, &cmdNumber, CS_UNUSED, NULL);
                EV_rxaFctStruct.pfn_ct_res_info(csCommand, CS_NUMDATA, &colNumber, CS_UNUSED, NULL);

                if (cmdNumber > 0 && colNumber > 0)
                {
                    AAASQL_OUTPUT_PARAM_STP outParamTab = (AAASQL_OUTPUT_PARAM_STP)mp.calloc(FILEINFO, colNumber, sizeof(AAASQL_OUTPUT_PARAM_ST));

                   
                    /* PMSTA-37366 - LJE - 200429 */
                    if (bIsAddDataResultSet)
                    {
                        ddlGenDataFieldVector.resize(colNumber);
                    }

                    stringstream  headStream;
                    stringstream  sepStream;

                    if (bISqlBehavior &&
                        sqlContextStp->bPrintHeader)
                    {
                        headStream << sqlContextStp->separator;
                        sepStream << sqlContextStp->separator;
                    }

                    for (i = 0; i < colNumber; i++)
                    {
                        /* rxaFctStruct.pfn_ct_describe to get a description of the parameter */
                        if (EV_rxaFctStruct.pfn_ct_describe(csCommand, i + 1, &csDataFmt) == CS_SUCCEED)
                        {
                            CS_DATAFMT	target_format;
                            size_t      alignNbr, maxlength = csDataFmt.maxlength;
                            DATATYPE_ENUM datatype = NullDataType;

                            memset(&target_format, 0, sizeof(target_format));

                            if (csDataFmt.datatype == CS_DATETIME_TYPE)
                            {
                                target_format = csDataFmt;
                                outParamTab[i].dataType = DatetimeType;
                                outParamTab[i].data = mp.calloc(FILEINFO, 1, sizeof(DBA_DYNFLDDATA_UN));

                                target_format.datatype = CS_FLOAT_TYPE;
                            }
                            else if (csDataFmt.datatype == CS_FLOAT_TYPE)
                            {
                                target_format = csDataFmt;
                                if (csDataFmt.usertype && csDataFmt.usertype < 100) /* value of dict_datatype table */
                                {
                                    datatype = (DATATYPE_ENUM)csDataFmt.usertype;
                                }

                                if (datatype == NullDataType)
                                {
                                    datatype = getDatatypeFromCT(csDataFmt);
                                }
                                if (datatype == NullDataType)
                                {
                                    datatype = NumberType;
                                }
                                outParamTab[i].dataType = PtrType;
                                outParamTab[i].data = mp.calloc(FILEINFO, 1, sizeof(DBA_DYNFLDDATA_UN));

                                maxlength = outParamTab[i].precision;
                            }
                            else if (csDataFmt.datatype == CS_BIGINT_TYPE)
                            {
                                target_format           = csDataFmt;
                                outParamTab[i].dataType = IdType;
                                outParamTab[i].data     = mp.calloc(FILEINFO, 1, sizeof(DBA_DYNFLDDATA_UN));
                                target_format.datatype  = CS_BIGINT_TYPE;
                            }
                            else
                            {
                                target_format.datatype = CS_LONGCHAR_TYPE;
                                target_format.maxlength = 30;
                                if (target_format.maxlength < csDataFmt.maxlength + 1)
                                {
                                    target_format.maxlength = csDataFmt.maxlength + 1;
                                }
                                target_format.count = 1;
                                target_format.format = CS_FMT_NULLTERM;
                                target_format.locale = NULL;

                                outParamTab[i].dataType = CodeType;
                                outParamTab[i].data = mp.calloc(FILEINFO, target_format.maxlength + 1, sizeof(char));
                            }
                            sybRetCode = EV_rxaFctStruct.pfn_ct_bind(csCommand, i + 1, &target_format, outParamTab[i].data, NULL, &(outParamTab[i].nullInd));

                            if (datatype == NullDataType)
                            {
                                datatype = getDatatypeFromCT(csDataFmt);
                            }
                            alignNbr = DBA_GetDataTypeAlignSize(datatype,
                                                                target_format.namelen,
                                                                maxlength,
                                                                (target_format.datatype == CS_BIGINT_TYPE ||
                                                                 target_format.datatype == CS_FLOAT_TYPE),
                                                                outParamTab[i].szAlignPos);

                            sepStream << STRING_FillPatern(string(), alignNbr, '-') << sqlContextStp->separator;

                            outParamTab[i].colWith = static_cast<int>(alignNbr);
                            outParamTab[i].dataSize = outParamTab[i].colWith;

                            if (outParamTab[i].dataType == PtrType)
                            {
                                outParamTab[i].precision = GET_MAXLEN(datatype);
                                outParamTab[i].scale = GET_CTYPE(datatype) == DoubleCType ? GET_DECIMAL(datatype) : (int)0;
                            }
                            else
                            {
                                outParamTab[i].precision = csDataFmt.precision;
                                outParamTab[i].scale = csDataFmt.scale;
                            }

                            if (sqlContextStp->maxScale >= 0 && outParamTab[i].scale > sqlContextStp->maxScale)
                            {
                                outParamTab[i].scale = sqlContextStp->maxScale;
                            }

                            if (bISqlBehavior &&
                                sqlContextStp->bPrintHeader)
                            {
                                char szFmt[128];
                                string headStr;

                                sprintf(szFmt, "%s%ds%s", "%-", int(alignNbr), sqlContextStp->separator.c_str());

                                if (sqlContextStp->bHeaderLowerCase)
                                {
                                    SYS_StringFormat(headStr, szFmt, lower(csDataFmt.name).c_str());
                                }
                                else
                                {
                                    SYS_StringFormat(headStr, szFmt, csDataFmt.name);
                                }

                                headStream << headStr;
                            }

                            strcpy(outParamTab[i].colName, csDataFmt.name);

                            if (strcmp(csDataFmt.name, "get_variable") == 0)
                            {
                                bAssignVars = true;
                            }

                            if (ddlGenDataFieldVector.empty() == false)
                            {
                                ddlGenDataFieldVector[i].setSqlName(outParamTab[i].colName);
                                ddlGenDataFieldVector[i].dataType = outParamTab[i].dataType;
                            }
                        }
                    }

                    if (bAssignVars == false &&
                        fusSync == nullptr &&
                        sqlContextStp->verboseLevel == VerboseLevel_iSQL &&
                        sqlContextStp->bPrintHeader)
                    {
                        cout << headStream.str() << endl;
                        cout << sepStream.str() << endl;
                    }

                    while (((sybRetCode = EV_rxaFctStruct.pfn_ct_fetch(csCommand, CS_UNUSED, CS_UNUSED, CS_UNUSED, NULL)) == CS_SUCCEED) ||
                        (sybRetCode == CS_ROW_FAIL))
                    {
                        if (sqlContextStp->rowCount != 0 && rowNumber == sqlContextStp->rowCount)
                        {
                            break;
                        }

                        if (rowNumber == 0 &&
                            bAssignVars == false &&
                            fusSync == nullptr &&
                            sqlContextStp->verboseLevel == VerboseLevel_HideEmptyResultSet &&
                            sqlContextStp->bPrintHeader)
                        {
                            cout << headStream.str() << endl;
                            cout << sepStream.str() << endl;
                        }

                        if (sybRetCode == CS_ROW_FAIL)
                        {
                            cout << "ct_fetch returned row fail " << endl;
                            ret = RET_DBA_ERR_DBPROBLEM;
                            continue;
                        }
                        rowNumber++;

                        if (bAssignVars == false &&
                            fusSync == nullptr &&
                            bISqlBehavior &&
                            sqlContextStp->bPrintHeader)
                        {
                            cout << sqlContextStp->separator;
                        }

                        for (i = 0; i < colNumber; i++)
                        {
                            if (bAssignVars && i == 0)
                            {
                                if (outParamTab[i].nullInd != 0 || strcmp((char*)outParamTab[i].data, "++VAR++") != 0)
                                {
                                    if (fusSync == nullptr &&
                                        bISqlBehavior &&
                                        sqlContextStp->bPrintHeader)
                                    {
                                        cout << headStream.str() << endl;
                                        cout << sepStream.str() << endl;
                                    }
                                    bAssignVars = false;
                                }
                                else
                                {
                                    continue;
                                }
                            }

                            if (bAssignVars)
                            {
                                DdlGenVar *currVar = sqlContextStp->ddlGenVarHelperPtr->getVariable(outParamTab[i].colName);
                                if (currVar)
                                {
                                    if (outParamTab[i].nullInd == 0)
                                    {
                                        if (outParamTab[i].dataType == DatetimeType ||
                                            outParamTab[i].dataType == DateType)

                                        {
                                            string name;
                                            DATETIME_ToSqlStr(name,
                                                              ((DBA_DYNFLDDATA_UN *)outParamTab[i].data)->datetime64St.dateTime(),
                                                              sqlContextStp->inDateTimeStyleEn,
                                                              outParamTab[i].dataType == DateType ? TimeStyle_None : TimeStyle_24);
                                            currVar->setValue(name);
                                        }
                                        else
                                        {
                                            currVar->setValue((char*)outParamTab[i].data);
                                        }

                                        currVar->bNullValue = false;
                                    }
                                    else
                                    {
                                        currVar->setValue("NULL");
                                        currVar->bNullValue = false;
                                    }
                                    currVar->bRuntimeValue = true;

                                }
                            }
                            else
                            {
                                string outStr;

                                if (outParamTab[i].nullInd == 0)
                                {
                                    if (outParamTab[i].dataType == DatetimeType ||
                                        outParamTab[i].dataType == DateType)
                                    {
                                        DATETIME_ToSqlStr(outStr,
                                                          ((DBA_DYNFLDDATA_UN *)outParamTab[i].data)->datetime64St.dateTime(),
                                                          sqlContextStp->outDateTimeStyleEn,
                                                          outParamTab[i].dataType == DateType ? TimeStyle_None : TimeStyle_24);
                                    }
                                    else if (outParamTab[i].dataType == PtrType)
                                    {
                                        outStr = CONV_DoubleToNumericString(*(double *)(outParamTab[i].data), outParamTab[i].precision, outParamTab[i].scale);
                                    }
                                    else if (outParamTab[i].dataType == IdType)
                                    {
                                        outStr = SYS_Stringer(((DBA_DYNFLDDATA_UN *)outParamTab[i].data)->longlongValue);
                                    }
                                    else
                                    {
                                        if (charSet != outputCharSet)
                                        {
                                            int lineLen = (int)strlen((char*)outParamTab[i].data) + 1, isoLen;
                                            UChar *lineUChar = (UChar*)CALLOC(lineLen, sizeof(UChar));

                                            ret = ICU4AAA_ConvertFromDefaultCharSet((char*)outParamTab[i].data, lineLen, lineUChar, lineLen, &isoLen);

                                            if (ret == 0)
                                            {
                                                char *outputData = nullptr;

                                                ret = ICU4AAA_ConvertToDefaultCharSet(lineUChar, -1, &outputData, &isoLen, outputCharSet); /* PMSTA - 36686 - AIS - 190828 */
                                                outStr = outputData;

                                                FREE(outputData);
                                            }

                                            FREE(lineUChar);
                                        }
                                        else
                                        {
                                            outStr = (char*)outParamTab[i].data;
                                        }
                                    }
                                }
                                else
                                {
                                    outStr = "NULL";
                                }

                                if (ddlGenDataFieldVector.empty() == false)
                                {
                                    if (outParamTab[i].nullInd == 0)
                                    {
                                        ddlGenDataFieldVector[i].value      = outStr;
                                        ddlGenDataFieldVector[i].bNullValue = false;
                                    }
                                    else
                                    {
                                        ddlGenDataFieldVector[i].bNullValue = true;
                                    }
                                }

                                if (fusSync == nullptr)
                                {
                                    if (bISqlBehavior &&
                                        (sqlContextStp->bPrintHeader || sqlContextStp->bPrintAllign) &&
                                        outParamTab[i].szAlignPos[0] != 0)
                                    {
                                        cout << STRING_FillPatern(outStr, outParamTab[i].colWith, ' ');
                                    }

                                    cout << outStr;

                                    if (bISqlBehavior &&
                                        (sqlContextStp->bPrintHeader || sqlContextStp->bPrintAllign) &&
                                        outParamTab[i].szAlignPos[0] == 0)
                                    {
                                        cout << STRING_FillPatern(outStr, outParamTab[i].colWith, ' ');
                                    }
                                    cout << sqlContextStp->separator;
                                }

                                /* PMSTA-27421 - 290517 - PMO */
                                if (nullptr != fusSync)
                                { // Keep the returned value for managing synchronized fusion
                                    FLAG_T            allocFlg = FALSE;
                                    DBA_CFIELDDEF_STP fieldStp = DBA_GetCFieldDef(Fus_Sync, Fus_Sync_RequestId, &allocFlg);

                                    if (nullptr != fieldStp && 0 == strcmp(fieldStp->sqlName, outParamTab[i].colName))
                                    {
                                        SET_ID(fusSync, Fus_Sync_RequestId, atol(outStr.c_str()));
                                    }
                                    else
                                    {
                                        fieldStp = DBA_GetCFieldDef(Fus_Sync, Fus_Sync_SyncModeFlg, &allocFlg);

                                        if (nullptr != fieldStp && 0 == strcmp(fieldStp->sqlName, outParamTab[i].colName))
                                        {
                                            SET_FLAG(fusSync, Fus_Sync_SyncModeFlg, atoi(outStr.c_str()));
                                        }
                                        else
                                        {
                                            fieldStp = DBA_GetCFieldDef(Fus_Sync, Fus_Sync_SyncTimeOut, &allocFlg);

                                            if (nullptr != fieldStp && 0 == strcmp(fieldStp->sqlName, outParamTab[i].colName))
                                            {
                                                SET_FLAG(fusSync, Fus_Sync_SyncTimeOut, atoi(outStr.c_str()));
                                            }
                                        }
                                    }

                                    if (TRUE == allocFlg)
                                    {
                                        mp.owner(static_cast<void*>(fieldStp));
                                    }
                                }
                            }
                        }

                        if (fusSync == nullptr)
                        {
                            cout << endl;
                        }

                        /* PMSTA-37366 - LJE - 200429 */
                        if (bIsAddDataResultSet)
                        {
                            sqlContextStp->scriptDdlGenPtr->addResultSetData(resultSetIdx, rowNumber - 1, ddlGenDataFieldVector);
                        }
                    }
                }
                resultSetIdx++;
            }
            break;

            case CS_CMD_SUCCEED:
                if (bRowCount == false && bRowResult == false)
                {
                    EV_rxaFctStruct.pfn_ct_res_info(csCommand, CS_ROW_COUNT, &rowNumber, CS_UNUSED, NULL);
                }
                break;

            case CS_CMD_DONE:
                if (bRowCount == false && bRowResult)
                {
                    if (fusSync == nullptr &&
                        sqlContextStp->verboseLevel != VerboseLevel_None &&
                        sqlContextStp->verboseLevel != VerboseLevel_Align &&
                        sqlContextStp->bPrintRowCount)
                    {
                        EV_rxaFctStruct.pfn_ct_res_info(csCommand, CS_ROW_COUNT, &rowNumber, CS_UNUSED, NULL);
                        if (rowNumber > 0)
                        {
                            cout << endl;
                        }

                        if (rowNumber == 1)
                        {
                            cout << "(" << rowNumber << " row affected)" << endl;
                        }
                        else
                        {
                            cout << "(" << rowNumber << " rows affected)" << endl;
                        }
                        bRowCount = true;
                    }
                    rowNumber = 0;
                }
                bRowResult = false;
                break;

            case CS_CMD_FAIL:
                ret = RET_DBA_ERR_DBPROBLEM;
                gblRet = ret;
                break;

            case CS_PARAM_RESULT:
                SYB_ProcessParamResult(*sqlContextStp->connHelperPtr->getConnection(),
                                       NullEntity,
                                       NullDynSt,
                                       NULL,
                                       NULL);
                break;

            case CS_CURSOR_RESULT:
                break;

            case CS_STATUS_RESULT:
                bStatusResult = true;

                if (bRowCount == false &&
                    fusSync == nullptr &&
                    sqlContextStp->verboseLevel != VerboseLevel_None &&
                    sqlContextStp->verboseLevel != VerboseLevel_Align &&
                    sqlContextStp->bPrintRowCount)
                {
                    if (rowNumber > 0)
                    {
                        cout << endl;
                    }

                    if (rowNumber == 1)
                    {
                        cout << "(" << rowNumber << " row affected)" << endl;
                    }
                    else
                    {
                        cout << "(" << rowNumber << " rows affected)" << endl;
                    }
                    bRowCount = true;
                }

                dbiConnPtr->filterMsgInfos(&ret);

                if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
                {
                    gblRet = ret;
                }

                if (EV_rxaFctStruct.pfn_ct_describe(csCommand, 1, &csDataFmt) == CS_SUCCEED)
                {
                    if (csDataFmt.precision == 12 && csDataFmt.scale == 0 && csDataFmt.datatype == CS_NUMERIC_TYPE)
                    {
                        assert(1 == 2);
                    }
                    else
                    {
                        INT_T status = 0;
                        /* Bind application status with returned value */
                        SYB_ColBind(*dbiConnPtr, 1, CS_INT_TYPE, &status);

                        /* Retrieve the value and store it into status */
                        while (dbiConnPtr->fetch() == TRUE)
                        {
                            if (sqlContextStp->verboseLevel != VerboseLevel_None &&
                                sqlContextStp->verboseLevel != VerboseLevel_Align)
                            {
                                cout << "(return status = " << status << ")" << endl;
                            }
                        }
                    }
                }
                break;

            default:
                cout << "TYPE : unknown results ";
                break;
        }
    }

    if (ret == RET_SUCCEED && results_ok == CS_CANCELED)
    {
        ret = RET_DBA_ERR_READ_DATA;
    }

    dbiConnPtr->filterMsgInfos(&ret);

    if (bStopServer && ret == RET_DBA_ERR_DISCONNECTED)
    {
        ret = RET_SUCCEED;
    }

    if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
    {
        gblRet = ret;
    }

    if (bStatusResult == false &&
        sqlContextStp->verboseLevel != VerboseLevel_None &&
        sqlContextStp->verboseLevel != VerboseLevel_Align)
    {
        cout << "(return status = " << ((RET_GET_LEVEL(gblRet) != RET_LEV_ERROR) ? 0 : gblRet) << ")" << endl;
    }

    if (dropProcCmd.empty() == false)
    {
        RequestHelper requestHelper(dbiConnPtr);
        requestHelper.setCommand(dropProcCmd);
        requestHelper.sendAndGetCommand();
    }

    return(gblRet);
}


/************************************************************************
*   Function             : SYB_ManagedSqlExec()
*
*   Description          : Send a character string representing a SQL Dynamic
*                          request. Bind status
*
*   Arguments            : context
*                          status          : pointer on status to be binded
*                          msgStructPtr
*
*   Functions call       :
*
*   Return               : RET_SUCCEED : if ok
*
*   Last Modification    : PMSTA-27421 - 290517 - PMO : Synchronized list is executed asynchronously on Sybase
*
*************************************************************************/
RET_CODE SYB_ManagedSqlExec(AAASQL_CONTEXT_STP sqlContextStp)
{
    RET_CODE            ret             = RET_SUCCEED;
    DBA_DYNFLD_STP      fusSync         = nullptr;

    try
    {
        MemoryPool  mp;
        const bool  startManualFusion = 0 == sqlContextStp->rpcName.compare("start_manual_fusion_by_cd");

        if (true == startManualFusion)
        {
            fusSync = mp.allocDynst(FILEINFO, Fus_Sync);
        }

        ret = _SYB_ManagedSqlExec(sqlContextStp, fusSync);

        if (RET_SUCCEED == ret && true == startManualFusion && TRUE == GET_FLAG(fusSync, Fus_Sync_SyncModeFlg))
        { // Processing of a synchronized fusion
            FusionSynchronization fusionSynchronization;
            fusionSynchronization.waitUntilJobFinished(fusSync);
        }
    }
    catch (...)
    {
        exceptionHandler(FILEINFO, MSG_SendMesg);
        ret = RET_MEM_ERR_ALLOC;    // Generally it is memory :-O
    }

    return ret;
}


/************************************************************************
**  Function    :   SYB_InsUpdSybUser
**
**  Description :   Insert or update a Sybase user.
**
**  Arguments   :   object        The user to check.
**  		        inputSt 	  A_ApplUser.
**                  inputData     A_ApplUser data.
**                  connectNo     Not used.
**                  msgStructPtr  Kind of error message.
**
**  Return      :   RET_SUCCEED                      If the user is DBO or SSO.
**                  RET_DBA_ERR_PASSWD_TOO_SHORT     If less than 6 characters.
**                  RET_GEN_ERR_INVARG               If no input data provided.
**
**  Creation    :   PMSTA-18593 - LJE - 150922
**  Modif.      :
**
*************************************************************************/
RET_CODE SYB_InsUpdSybUser(DBA_DYNFLD_STP       inputData,
                           DbiConnection&       dbiConn,
                           bool                 isInsert)
{
    std::string    aaalogindb, maindb, sqrdb, auditdb, tslpermdb;
    SYSNAME_T	   admLogin, code; /* DLA - PMSTA09887 - 101115 */
    char          *userPasswd;                        /*  HFI-PMSTA-16139-130328  */
    char		   buffer[256];
    AUTO_PASSWORD_CLEAR(buffer, sizeof(buffer));                                                        /* PMSTA-18094 - 130514 - PMO */
    char		   errMsg[256];
    RET_CODE       retCode = RET_SUCCEED,
        ret;
    DBI_INT        status = 0;
    DBA_DYNFLD_STP AdmArgStp;
    FLAG_T         hasDBLoginflg = TRUE;
 	DbiConnection* dbiConnAdm = nullptr;

    stringstream   sqlCmd;

    /* Check arguments */
    if (inputData == NULL)
    {
        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "SYB_InsUpdOraUser", "inputData");
        return(RET_GEN_ERR_INVARG);
    }

    code[0] = END_OF_STRING;

    if (IS_NULLFLD(inputData, A_ApplUser_Cd) == FALSE)
    {
        strcpy(code, GET_SYSNAME(inputData, A_ApplUser_Cd));
    }

    if (IS_NULLFLD(inputData, A_ApplUser_HasDbLoginFlg) == FALSE) /* PMSTA-14286 - EFE - 120608 */
    {
        hasDBLoginflg = GET_ENUM(inputData, A_ApplUser_HasDbLoginFlg);
    }

   	SYBASE_LOGIN_ACTION_ENUM loginActionEn = LoginActionEn_Nothing;
    FLAG_T lockActionFlg = FALSE;

	if (IS_NULLFLD(inputData, A_ApplUser_LoginActionEn) == FALSE)
		loginActionEn = (SYBASE_LOGIN_ACTION_ENUM)GET_ENUM(inputData, A_ApplUser_LoginActionEn);
    if (IS_NULLFLD(inputData, A_ApplUser_LockActionFlg) == FALSE)
        lockActionFlg = GET_FLAG(inputData, A_ApplUser_LockActionFlg);

    if (!hasDBLoginflg && loginActionEn != LoginActionEn_Drop)
        return retCode;

    if (nullptr != GET_SYSNAME(inputData, A_ApplUser_SuperUserLogin))
    {
        strcpy(admLogin, GET_SYSNAME(inputData, A_ApplUser_SuperUserLogin));
    }
    else
    {
        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "SYB_InsUpdSybUser", "ApplUser_SuperUserLogin");
        retCode = RET_SRV_LIB_ERR_INSERT_USER_FAILED;
    }

    aaalogindb = SYS_GetLoginDb();

    GEN_GetApplInfo(ApplSqlDbName, maindb);
    GEN_GetApplInfo(ApplSqrDbName, sqrdb);
    GEN_GetApplInfo(ApplAuditDbName, auditdb);
    GEN_GetApplInfo(ApplPermTslDbName, tslpermdb);  /* DLA - PMSTA-12296 - 110706 */


    /* The use of interface to create users needs to
    verify that the user given is administrator. */

    if (SYS_IsBatchMode())
    {
        if (DBA_CheckDbAdminUser(admLogin, PasswordEncrypted(PasswordClear(GET_SYSNAME(inputData, A_ApplUser_SuperUserPasswd)))) != RET_SUCCEED)
	    {
		    sprintf(errMsg, "user %s is not entitled to create/lock/unlock user %s", admLogin, code);
            DbaErrmsgInfosClass &msgStructSt = dbiConn.m_msgStructHeaderSt.getNewErrMsgInfoSt(FILEINFO);
            msgStructSt.msgString            = errMsg;
            msgStructSt.techMsg              = FALSE;
		    retCode                          = RET_SRV_LIB_ERR_INSERT_USER_FAILED;
	    }
    }

    if (retCode == RET_SUCCEED && DBA_OpenConnForUser(admLogin, PasswordEncrypted(PasswordClear(GET_SYSNAME(inputData, A_ApplUser_SuperUserPasswd))), &dbiConnAdm, ROLE_DBSO) != RET_SUCCEED)
    {
        sprintf(errMsg, "unable to open a connection with ROLE_DBSO, user %s", admLogin);
        DbaErrmsgInfosClass &msgStructSt = dbiConn.m_msgStructHeaderSt.getNewErrMsgInfoSt(FILEINFO);
        msgStructSt.msgString            = errMsg;
        msgStructSt.techMsg              = FALSE;
        retCode                          = RET_SRV_LIB_ERR_INSERT_USER_FAILED;
    }

    const AAALogger& sqlTraceLog = AAALogger::get(AAALogger::Logger::SqlTrace);
    if (retCode == RET_SUCCEED && hasDBLoginflg == TRUE && (isInsert || loginActionEn == LoginActionEn_Add))
    {
        if ((AdmArgStp = ALLOC_DYNST(Adm_Arg)) == NULL)
        {
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }

        SET_CODE(AdmArgStp, Adm_Arg_Sysname, code);

        retCode = DBA_Notif2(DictUser
                             , UNUSED
                             , Adm_Arg
                             , AdmArgStp
                             , DBA_SET_CONN | DBA_NO_CLOSE
                             , dbiConn
                             , UNUSED
                             );

        if (retCode == RET_SUCCEED && GET_INT(AdmArgStp, Adm_Arg_ReturnStatus) != 0) /* PMSTA-46607 - DDV - 211006 */
        {   /* insert */
            userPasswd = NULL;                          /*  HFI-PMSTA-16139-130328  */
            if (IS_NULLFLD(inputData, A_ApplUser_UserPassword) == FALSE)
            {
                /*  HFI-PMSTA-16139-130328  replace double quote in userPasswd  */
                userPasswd = GEN_ManageQuoteInPassword(GET_INFO(inputData, A_ApplUser_UserPassword));
                /*			strcpy(userPasswd, GET_SYSNAME(inputData, A_ApplUser_UserPasswd));  HFI-PMSTA-16139-130328  */
            }

            /* Test if password is long enough for SYBASE. */
            retCode = DBI_CheckMinPasswdLength(userPasswd, dbiConn);

            /* The use of interface to create users needs to
            verify that the user given is administrator. */
            if (retCode == RET_SUCCEED && DBI_CheckUserRole(*dbiConnAdm, "sso_role") == false)
            {
                ret = RET_DBA_INFO_NOTADMINISTRATOR;
                sprintf(errMsg, "user %s is not entitled to create user %s", admLogin, code);

                DbaErrmsgInfosClass &msgStructSt = dbiConn.m_msgStructHeaderSt.getNewErrMsgInfoSt(FILEINFO);
                msgStructSt.msgString            = errMsg;
                msgStructSt.techMsg              = FALSE;
                DBA_PasswordClear(userPasswd, strlen(userPasswd));            /* PMSTA-18094 - 130514 - PMO */
                retCode                          = RET_SRV_LIB_ERR_INSERT_USER_FAILED;
            }

            dbiConnAdm->getTargetSessionProperties().setDbName("master");

            if (retCode == RET_SUCCEED)
			{
                sprintf(buffer, "if not exists (select name from syslogins where name = '%s') "
                "begin create login \"%s\" with password \"%s\" end", code, code, userPasswd);

                if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
                {
                    auto &sqlTrace = dbiConnAdm->getSqlTrace();
                    sqlTrace.m_procedure = "DynSql.InsUpdSybUser";
                }
    			retCode = dbiConnAdm->sqlExecSt(buffer, &status);
            }

			if (retCode == RET_SUCCEED)
			{
				sprintf(buffer, "alter login \"%s\" modify default database %s", code, aaalogindb.c_str());

                if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
                {
                    auto &sqlTrace = dbiConnAdm->getSqlTrace();
                    sqlTrace.m_procedure = "DynSql.InsUpdSybUser";
                }

				retCode = dbiConnAdm->sqlExecSt(buffer, &status);
			}

            dbiConnAdm->getTargetSessionProperties().setDbName(aaalogindb);

			if (retCode == RET_SUCCEED)
			{
				sprintf(buffer, "if not exists (select name from sysusers where name = '%s') "
					"begin exec sp_adduser \"%s\", \"%s\", triplea end", code, code, code);

                if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
                {
                    auto &sqlTrace = dbiConnAdm->getSqlTrace();
                    sqlTrace.m_procedure = "DynSql.InsUpdSybUser";
                }

				retCode = dbiConnAdm->sqlExecSt(buffer, &status);
			}

			if (retCode == RET_SUCCEED)
			{
				sprintf(buffer, "use %s", maindb.c_str());

                if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
                {
                    auto &sqlTrace = dbiConnAdm->getSqlTrace();
                    sqlTrace.m_procedure = "DynSql.InsUpdSybUser";
                }

				retCode = dbiConnAdm->sqlExecSt(buffer, &status);
			}

			if (retCode == RET_SUCCEED)
			{
				sprintf(buffer, "if not exists (select name from sysusers where name = '%s') "
					"begin exec sp_adduser \"%s\", \"%s\", triplea end", code, code, code);

                if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
                {
                    auto &sqlTrace = dbiConnAdm->getSqlTrace();
                    sqlTrace.m_procedure = "DynSql.InsUpdSybUser";
                }

				retCode = dbiConnAdm->sqlExecSt(buffer, &status);
			}

            dbiConnAdm->getTargetSessionProperties().setDbName(sqrdb);

			if (retCode == RET_SUCCEED)
			{
				sprintf(buffer, "if not exists (select name from sysusers where name = '%s') "
					"begin exec sp_adduser \"%s\", \"%s\", triplea end", code, code, code);

                if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
                {
                    auto &sqlTrace = dbiConnAdm->getSqlTrace();
                    sqlTrace.m_procedure = "DynSql.InsUpdSybUser";
                }

				retCode = dbiConnAdm->sqlExecSt(buffer, &status);
			}

            dbiConnAdm->getTargetSessionProperties().setDbName(tslpermdb);

			if (retCode == RET_SUCCEED)
			{
				sprintf(buffer, "if not exists (select name from sysusers where name = '%s') "
					"begin exec sp_adduser \"%s\", \"%s\", triplea end", code, code, code);

                if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
                {
                    auto &sqlTrace = dbiConnAdm->getSqlTrace();
                    sqlTrace.m_procedure = "DynSql.InsUpdSybUser";
                }

				retCode = dbiConnAdm->sqlExecSt(buffer, &status);
			}

            if (auditdb[0] != END_OF_STRING)
			{
                dbiConnAdm->getTargetSessionProperties().setDbName(auditdb);

				if (retCode == RET_SUCCEED)
				{
					sprintf(buffer, "if not exists (select name from sysusers where name = '%s') "
						"begin exec sp_adduser \"%s\", \"%s\", triplea end", code, code, code);

                    if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
                    {
                        auto &sqlTrace = dbiConnAdm->getSqlTrace();
                        sqlTrace.m_procedure = "DynSql.InsUpdSybUser";
                    }

					retCode = dbiConnAdm->sqlExecSt(buffer, &status);
				}
			}

            /*  Free allocated memory               */  /*  HFI-PMSTA-16139-130328  */
            if (userPasswd != NULL)
            {
                DBA_PasswordClear(userPasswd, strlen(userPasswd));            /* PMSTA-18094 - 130514 - PMO */
                FREE(userPasswd);
            }
        }
        FREE_DYNST(AdmArgStp, Adm_Arg);
    }

    if (retCode == RET_SUCCEED && hasDBLoginflg == FALSE && loginActionEn == LoginActionEn_Drop)
    {
        dbiConnAdm->getTargetSessionProperties().setDbName(aaalogindb);
		if (retCode == RET_SUCCEED)
		{
		    sprintf(buffer, "if exists (select name from sysusers where name = '%s') "
			    "begin exec sp_dropuser \"%s\" end", code, code);

            if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
            {
                auto &sqlTrace = dbiConnAdm->getSqlTrace();
                sqlTrace.m_procedure = "DynSql.InsUpdSybUser";
            }

		    retCode = dbiConnAdm->sqlExecSt(buffer);
        }

        dbiConnAdm->getTargetSessionProperties().setDbName(maindb);

		if (retCode == RET_SUCCEED)
		{
		    sprintf(buffer, "if exists (select name from sysusers where name = '%s') "
			    "begin exec sp_dropuser \"%s\" end", code, code);

            if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
            {
                auto &sqlTrace = dbiConnAdm->getSqlTrace();
                sqlTrace.m_procedure = "DynSql.InsUpdSybUser";
            }

		    retCode = dbiConnAdm->sqlExecSt(buffer);
        }

        dbiConnAdm->getTargetSessionProperties().setDbName(sqrdb);

		if (retCode == RET_SUCCEED)
		{
		    sprintf(buffer, "if exists (select name from sysusers where name = '%s') "
			    "begin exec sp_dropuser \"%s\" end", code, code);

            if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
            {
                auto &sqlTrace = dbiConnAdm->getSqlTrace();
                sqlTrace.m_procedure = "DynSql.InsUpdSybUser";
            }

		    retCode = dbiConnAdm->sqlExecSt(buffer);
        }

		if (auditdb.empty() == false)
		{
            dbiConnAdm->getTargetSessionProperties().setDbName(auditdb);

        	if (retCode == RET_SUCCEED)
		    {
			    sprintf(buffer, "if exists (select name from sysusers where name = '%s') "
				    "begin exec sp_dropuser \"%s\" end", code, code);

                if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
                {
                    auto &sqlTrace = dbiConnAdm->getSqlTrace();
                    sqlTrace.m_procedure = "DynSql.InsUpdSybUser";
                }

			    retCode = dbiConnAdm->sqlExecSt(buffer);
            }
		}

        dbiConnAdm->getTargetSessionProperties().setDbName(tslpermdb);

		if (retCode == RET_SUCCEED)
		{
		    sprintf(buffer, "if exists (select name from sysusers where name = '%s') "
			    "begin exec sp_dropuser \"%s\" end", code, code);

            if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
            {
                auto &sqlTrace = dbiConnAdm->getSqlTrace();
                sqlTrace.m_procedure = "DynSql.InsUpdSybUser";
            }

		    retCode = dbiConnAdm->sqlExecSt(buffer);
        }

        dbiConnAdm->getTargetSessionProperties().setDbName("master");

		if (retCode == RET_SUCCEED)
		{
		    sprintf(buffer, "if exists (select name from syslogins where name = '%s') "
			    "begin exec sp_droplogin \"%s\" end", code, code);

            if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
            {
                auto &sqlTrace = dbiConnAdm->getSqlTrace();
                sqlTrace.m_procedure = "DynSql.InsUpdSybUser";
            }

		    retCode = dbiConnAdm->sqlExecSt(buffer);
        }

        if (retCode== RET_SUCCEED)
            hasDBLoginflg = FALSE;
    }


    if (retCode ==  RET_SUCCEED && hasDBLoginflg == TRUE && lockActionFlg == TRUE)
    {
        dbiConnAdm->getTargetSessionProperties().setDbName("master");
        if (retCode == RET_SUCCEED)
        {
            if (GET_FLAG(inputData, A_ApplUser_ActiveFlg) == FALSE)
                sprintf(buffer, "sp_locklogin %s, \"lock\"", code);
            else
                sprintf(buffer, "sp_locklogin %s, \"unlock\"", code);


            if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
            {
                auto &sqlTrace = dbiConnAdm->getSqlTrace();
                sqlTrace.m_procedure = "DynSql.InsUpdSybUser";
            }

            retCode = dbiConnAdm->sqlExecSt(buffer, &status);
        }
    }

    DBA_EndConnection(&dbiConnAdm);

    return retCode;
}

/************************************************************************
**  Function    :   SYB_InsApplUserById
**
**  Description :   Create a new user.
**
**  Arguments   :   object        The user to check.
**  		        inputSt 	  A_ApplUser.
**                  inputData     A_ApplUser data.
**                  connectNo     Not used.
**                  msgStructPtr  Kind of error message.
**
**  Return      :   RET_SUCCEED                      If the user is DBO or SSO.
**                  RET_DBA_ERR_PASSWD_TOO_SHORT     If less than 6 characters.
**                  RET_GEN_ERR_INVARG               If no input data provided.
**
**  Creation    :   PMSTA-18593 - LJE - 150922
**  Modif.      :
**
*************************************************************************/
RET_CODE SYB_InsApplUserById(DBA_DYNFLD_STP       inputData,
                             DbiConnection&       dbiConn)
{
    /* Check arguments */
    if (inputData == NULL)
    {
        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "SYB_InsApplUserById", "inputData");
        return(RET_GEN_ERR_INVARG);
    }

    RET_CODE retCode = SYB_InsUpdSybUser(inputData,
                                         dbiConn,
                                         true);
    return retCode;
}

/************************************************************************
**  Function    :   SYB_UpdApplUser
**
**  Description :   Update an existing user.
**                   Based on the value of A_ApplUser_LoginActionEn,
**
**  Arguments   :   object        The user to check.
**  		        inputSt 	  A_ApplUser.
**                  inputData     A_ApplUser data.
**                  connectNo     Not used.
**                  msgStructPtr  Kind of error message.
**
**  Return      :   RET_SUCCEED                      If the user is DBO or SSO.
**                  RET_DBA_ERR_PASSWD_TOO_SHORT     If less than 6 characters.
**                  RET_GEN_ERR_INVARG               If no input data provided.
**
**  Creation    :   PMSTA-18593 - LJE - 150922
**  Modif.      :
**
*************************************************************************/
RET_CODE SYB_UpdApplUser(OBJECT_ENUM          object,
                         DBA_DYNST_ENUM       inputSt,
                         DBA_DYNFLD_STP       inputData,
                         DbiConnection&       dbiConn)
{
    RET_CODE       retCode = RET_SUCCEED;

    /* Check arguments */
    if (inputData == NULL)
    {
        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "SYB_UpdApplUser", "inputData");
        return(RET_GEN_ERR_INVARG);
    }

    retCode = SYB_InsUpdSybUser(inputData,
                                dbiConn,
                                false);

    return retCode;
}

/************************************************************************
**
**  Function    :  SYB_ChangePasswd()
**
**  Description :   Change the password of the given user.
**
**  Arguments   :   adminUser
**  		    adminPasswd
**  		    userCode
**  		    newPasswd
**
**  Return      :   RET_SUCCEED
**                  RET_GEN_ERR_INVARG               If no good parameters.
**                  RET_DBA_ERR_PASSWD_TOO_SHORT     If less than 6 characters.
**
**  Creation    :   DVP290 - GRD - 961202
**
**  Modif.      :   ROI - 961206 - DVP271
**  Modif.      :   ROI - 970130 - BUG273
**  Modif.      :   FIH-REF7036-010919  Test DBA_SlExec return.
**                  EFE-REF11663-060608 : validity date problem
**                  PMSTA-18094 - 130514 - PMO : Avoid extracting the user credentials from the GUI running on Windows (via dump, etc.)
**
*************************************************************************/
RET_CODE SYB_ChangePasswd(SYSNAME_T adminUser,
                          SYSNAME_T adminPasswd,
                          SYSNAME_T userCode, /* DLA - PMSTA09887 - 101115 */
                          SYSNAME_T newPasswd)
{
    RET_CODE             ret = RET_SUCCEED;
    DbiConnection       *dbiConn = nullptr;
    char                 buffer[256];
    DBI_INT              status;
    char                *pszUserPasswd,             /*  HFI-PMSTA-16139-130328  */
                        *pszAdminPasswd;            /*  HFI-PMSTA-16139-130328  */
    std::string          maindb;                     /* PMSTA-18048 - SHR - 140521 */

    GEN_GetApplInfo(ApplSqlDbName, maindb); /*PMSTA-18048 - SHR - 140521 */

    if ((adminUser == NULL) || (adminPasswd == NULL) ||
        (userCode == NULL)
        ) MSG_RETURN(RET_GEN_ERR_INVARG);

    /* Test if password is long enough for SYBASE. */
    if (SYS_StrLen(newPasswd) < 6)
        MSG_RETURN(RET_DBA_ERR_PASSWD_TOO_SHORT);

    /*  Manage double quote in paswords    */  /*  HFI-PMSTA-16139-130328  */
    pszUserPasswd = GEN_ManageQuoteInPassword(newPasswd);
    pszAdminPasswd = GEN_ManageQuoteInPassword(adminPasswd);
    if ((pszUserPasswd == NULL) ||
        (pszAdminPasswd == NULL))
        MSG_RETURN(RET_GEN_ERR_INVARG);

    const AAALogger& sqlTraceLog = AAALogger::get(AAALogger::Logger::SqlTrace);

    if (strcmp(adminUser, userCode) == 0)
    {
        /* REF11663-EFE-060111                                     */
        /* the change password is made by the user himself         */
        /* so don't need to open a connection but only to get one  */
        /* in this case adminPasswd is the old password            */

        if ((dbiConn = DBA_GetDbiConnection(SqlServer, ROLE_ADMIN)) != nullptr)
        {
            /* Test if password is long enough for SYBASE. */
            ret = DBI_CheckMinPasswdLength(newPasswd, *dbiConn);
            if (ret == RET_SUCCEED)
            {
                DBA_CONNECT_INFO_STP connectStp = dbiConn->getConnStructPtr();                              /* PMSTA-18094 - 130514 - PMO */
                connectStp->passwordChange = true;                                                              /* PMSTA-18094 - 130514 - PMO */

                /* PMSTA-18048 - SHR - 140521 */
                const int len = 1 + sprintf(buffer, "use master "
                    "alter login \"%s\" with password \"%s\" modify password \"%s\" use %s ", userCode, pszAdminPasswd, pszUserPasswd, maindb.c_str());

                if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
                {
                    auto &sqlTrace = dbiConn->getSqlTrace();
                    sqlTrace.m_procedure = "DynSql.ChangePassword";
                }

                ret = dbiConn->sqlExecSt(buffer, &status);
                DBA_PasswordClear(buffer, sizeof(buffer));                                                      /* PMSTA-18094 - 130514 - PMO */

                connectStp->passwordChange = false;                                                             /* PMSTA-18094 - 130514 - PMO */

                /* Clear the password from Sybase memory */
                sprintf(buffer, "%*s", len, "sp_who");                                                          /* PMSTA-18094 - 130514 - PMO */

                if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
                {
                    auto &sqlTrace = dbiConn->getSqlTrace();
                    sqlTrace.m_procedure = "DynSql.ChangePassword";
                }

                (void)dbiConn->sqlExecSt(buffer, &status);                     /* PMSTA-18094 - 130514 - PMO */

                dbiConn->dispAllMsgText();
                if (ret != RET_SUCCEED)
                {
                    return ret;
                }
                DBA_EndConnection(&dbiConn);
            }
        }
    }
    else
    {
        if ((ret = DBA_OpenConnForUser(adminUser, PasswordEncrypted((PasswordClear(adminPasswd))), &dbiConn, ROLE_DBSO)) == RET_SUCCEED)
        {
            /* Test if password is long enough for SYBASE. */
            ret = DBI_CheckMinPasswdLength(newPasswd, *dbiConn);
            if (ret == RET_SUCCEED)
            {
                DBA_CONNECT_INFO_STP connectStp = dbiConn->getConnStructPtr();
                connectStp->passwordChange = true;                                                              /* PMSTA-18094 - 130514 - PMO */

                /* PMSTA-18048 - SHR - 140521 */
                const int len = 1 + sprintf(buffer, "use master "
                    "alter login \"%s\" with password \"%s\" modify password \"%s\" use %s ", userCode, pszAdminPasswd, pszUserPasswd, maindb.c_str());

                if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
                {
                    auto &sqlTrace = dbiConn->getSqlTrace();
                    sqlTrace.m_procedure = "DynSql.ChangePassword";
                }

                ret = dbiConn->sqlExecSt(buffer, &status);
                DBA_PasswordClear(buffer, sizeof(buffer));                                                      /* PMSTA-18094 - 130514 - PMO */

                connectStp->passwordChange = false;                                                             /* PMSTA-18094 - 130514 - PMO */

                /* Clear the password from Sybase memory */
                sprintf(buffer, "%*s", len, "declare @chk int_t");                              /* PMSTA-18094 - 130514 - PMO */

                if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
                {
                    auto &sqlTrace = dbiConn->getSqlTrace();
                    sqlTrace.m_procedure = "DynSql.ChangePassword";
                }

                (void)dbiConn->sqlExecSt(buffer, &status);

                dbiConn->dispAllMsgText();
                if (ret != RET_SUCCEED)
                {
                    return ret;
                }

                DBA_EndConnection(&dbiConn);
            }
        }
    }

    /*  Free allocated memory   */  /*  HFI-PMSTA-16139-130328  */
    if (pszUserPasswd != NULL)
        FREE(pszUserPasswd);
    if (pszAdminPasswd != NULL)
        FREE(pszAdminPasswd);

    switch (ret)
    {
        case RET_DBA_ERR_CANNOTCONNECT:
            MSG_RETURN(RET_SRV_LIB_ERR_INVALID_PASSWORD);

        case RET_SUCCEED:
            return ret;

        default:
            MSG_RETURN(ret);
    }
}

/************************************************************************
**   END  syblib03.c                                                   **
*************************************************************************/

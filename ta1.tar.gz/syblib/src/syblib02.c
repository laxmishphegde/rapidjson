/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/**************************** FUNCTION LIST *****************************
**
** SYB_BindRecvDynSt()  Sybase Bind of a received Buffer in a DYNST rec
**          All received data are in a Sybase known format
**          and are converted into our C formats
**
*************************************************************************/

/************************************************************************
**     Defines
*************************************************************************/
#define SYBLIB02_C

/************************************************************************
**     Include files
*************************************************************************/
#define STDIO_H
#define TIME_H
#define STDLIB_H
#define STDARG_H
#define STRING_H

#include <assert.h> /* DLA - REF9089 - 030513 */
#include <string>

#include <ctpublic.h>

#include "unidef.h"     /* Mandatory */

#ifndef GEN_H
#include "gen.h"
#endif

#ifndef DATE_H
#include "date.h"
#endif

#ifndef DBA_H
#include "dba.h"
#endif

#ifndef DBI_H
#include "dbi.h"
#endif

#ifndef PROC_H
#include "proc.h"
#endif

#ifndef MSG_H
#include "msg.h"
#endif

#ifndef SYB_H
#include "syb.h"
#endif

#ifndef SYSLIB_H
#include "syslib.h"     /* PMO - Rename our sys.h to syslib.h and use it */
#endif

#ifndef TLS_H
#include "tls.h"
#endif

#ifndef OPE_H
#include "ope.h"        /* Bad coding practice REF9167 - 030603 - PMO */
#endif


#include "dbiconnection.h"
#include "sybconnection.h"
#include "rxa.h"
#include "rpclib.h"

static RET_CODE SYB_DefineCtParam(OBJECT_ENUM, DBA_DYNST_ENUM, DBA_DYNFLD_STP, DBA_PROC_STP, SybConnection& , char*, int, int*, char**, FLAG_T); /* REF4665 - SSO - 000503 */

extern size_t(*DBA_GetDataSegmentSize)(void);
extern bool(*DBA_WarningMessageBox)(const char *);
/* REF10195 - LJE - 040408 */
extern int EV_SqlTraceParam;
extern RXA_FCTPTR EV_rxaFctStruct; /* DLA - PMSTA-23431 - 160824 */

STATIC void SYB_WriteInSqlTrace(char **, int, const char *, ...);   /* BSA-REF11860-060808 */

#define TRACE_PARAM ((EV_SqlTraceParam && EV_sqlFile) || EV_ExtractFile)

/************************************************************************
**     Static definitions & data
*************************************************************************/
extern TIMER_ST EV_ExtractFileTimer;
extern TIMER_STP EV_ExtractFileTimerPtr;
extern char      EV_SetProcParametersFlg;


extern RpcCollection EV_RpcCollection;

/************************************************************************
*   Function             : SYB_ConvertTimeStampToCTimeStamp()
*
*   Description          : Conversion routine between Sybase timestamp format
*                          (CS_BINARY_TYPE) and application TimeStamp.
*                          Callback routine called automatically by ct_bind().
*
*   Arguments            : csContext : a pointer on a CS_CONTEXT structure.
*                          srcfmt    : format of the source variable
*                          srcdata   : value of the source variable
*                          destfmt   : format of the destination variable
*                          destdata  : value of the destination variable
*                          destlen   : length of the destination variable
*
*   Functions call       : None
*
*   Global var. modified : None
*
*   Return               : Sybase values (cf function "cs_set_convert")
*
*   Creation date        : REF11780 - 100406 - PMO : Implementation of the Sybase timestamp field
*
*   Last Modif. Date     :
*
*************************************************************************/
CS_RETCODE CS_PUBLIC SYB_ConvertTimeStampToCTimeStamp(CS_CONTEXT *,
                                                      CS_DATAFMT *,
                                                      CS_VOID    *srcdata,
                                                      CS_DATAFMT *,
                                                      CS_VOID    *destdata,
                                                      CS_INT     *destlen)
{
    unsigned        idx;
    TIMESTAMP_T *   target = (TIMESTAMP_T *)destdata;
    CS_BINARY *     source = (CS_BINARY *)  srcdata;

    *target = 0;
    for (idx = 0; idx < sizeof (TIMESTAMP_T); idx++)
    {
        *target *= 256;
        *target += (CS_BINARY) *(source + idx);
    }

    *destlen = sizeof (TIMESTAMP_T);

    return CS_SUCCEED;
}

/************************************************************************
*   Function             : SYB_ConvertCTimeStampToTimeStamp()
*
*   Description          : Conversion routine between Sybase timestamp format
*                          (CS_BINARY_TYPE) and application TimeStamp.
*                          Callback routine called automatically by ct_bind().
*
*   Arguments            : csContext : a pointer on a CS_CONTEXT structure.
*                          srcfmt    : format of the source variable
*                          srcdata   : value of the source variable
*                          destfmt   : format of the destination variable
*                          destdata  : value of the destination variable
*                          destlen   : length of the destination variable
*
*   Functions call       : None
*
*   Global var. modified : None
*
*   Return               : Sybase values (cf function "cs_set_convert")
*
*   Creation date        : REF11780 - 100406 - PMO : Implementation of the Sybase timestamp field
*
*   Last Modif. Date     : PMSTA-9091 - 091209 - PMO : Impossible to delete or modify an operation
*
*************************************************************************/
CS_RETCODE CS_PUBLIC SYB_ConvertCTimeStampToTimeStamp(CS_CONTEXT *  ,
                                                      CS_DATAFMT *  ,
                                                      CS_VOID *     srcdata,
                                                      CS_DATAFMT *  ,
                                                      CS_VOID *     destdata,
                                                      CS_INT *      destlen)
{
    int             idx;
    CS_BINARY *     target = (CS_BINARY *)     destdata;
    TIMESTAMP_T     source = *((TIMESTAMP_T *) srcdata);

    *target = 0;
    for (idx = (int)sizeof (TIMESTAMP_T) - 1; idx >= 0; idx--)
    {
        *(target + idx) = (CS_BINARY) (source & 255);
        source >>= 8;   /* PMSTA-9091 - 091209 - PMO */
    }

    *destlen = sizeof (TIMESTAMP_T);

    return CS_SUCCEED;
}


/************************************************************************
*   Function             : SYB_InstallConversionFcts()
*
*   Description          : Install conversion functions between Sybase
*                          datatypes and application specific datatypes.
*
*   Arguments            :
*
*
*   Functions call       : None
*
*   Global var. modified : None
*
*   Return               : RET_SUCCEED             : if ok
*                          RET_DBA_ERR_ARGNOMATCH  : if argument problem
*                          RET_DBA_ERR_INITSYBCTX  : if installation of
*                                                    conversion fcts failed
*
*   Creation date        : Apr. 94 - PEC
*   Last Modif. Date     : 29.8.95 - PEC
*                          REF11780 - 100406 - PMO : Implementation of the Sybase timestamp field
*                          PMSTA-9262 - 090210 - PMO : Wrong timestamp returned for collect eval_entity output mode 1
*************************************************************************/
RET_CODE SYB_InstallConversionFcts(void)
{
    CS_CONTEXT      *csContext=NULL;
    CS_CONV_FUNC    function=NULL;
    CS_CONV_FUNC    *functionPtr=NULL;

    csContext = SYB_GetCsContext();

    if (csContext == NULL)
        return(RET_DBA_ERR_ARGNOMATCH);

    /* Install conversion routine between CS_DATETIME4_TYPE and int type */
    function = (CS_CONV_FUNC)SYB_ConvertDateToInt;
    functionPtr = &function;
    if (EV_rxaFctStruct.pfn_cs_set_convert(csContext, CS_SET, CS_DATETIME4_TYPE, CS_INT_TYPE, (RXA_CONV_FUNC*)functionPtr)
                                                  != CS_SUCCEED)
        return(RET_DBA_ERR_INITSYBCTX);

    /* Install conversion routine between CS_DATETIME_TYPE and int type */
    function = (CS_CONV_FUNC)SYB_ConvertDateToInt;
    functionPtr = &function;
    if (EV_rxaFctStruct.pfn_cs_set_convert(csContext, CS_SET, CS_DATETIME_TYPE, CS_INT_TYPE, (RXA_CONV_FUNC*)functionPtr)
                                                  != CS_SUCCEED)
        return(RET_DBA_ERR_INITSYBCTX);

    /* Install conversion routine between CS_DATETIME4_TYPE and DATETIME_ST type */
    function = (CS_CONV_FUNC)SYB_ConvertSmallDateToDouble;
    functionPtr = &function;
    if (EV_rxaFctStruct.pfn_cs_set_convert(csContext, CS_SET, CS_DATETIME4_TYPE, CS_FLOAT_TYPE, (RXA_CONV_FUNC*)functionPtr)
                                                  != CS_SUCCEED)
        return(RET_DBA_ERR_INITSYBCTX);

    /* Install conversion routine between CS_DATETIME_TYPE and DATETIME_ST type */
    function = (CS_CONV_FUNC)SYB_ConvertDateToDouble;
    functionPtr = &function;
    if (EV_rxaFctStruct.pfn_cs_set_convert(csContext, CS_SET, CS_DATETIME_TYPE, CS_FLOAT_TYPE, (RXA_CONV_FUNC*)functionPtr)
        != CS_SUCCEED)
        return(RET_DBA_ERR_INITSYBCTX);

    /* For BulkCopy Mode */
    function = (CS_CONV_FUNC)SYB_ConvertIntToDate;
    functionPtr = &function;
    if (EV_rxaFctStruct.pfn_cs_set_convert(csContext, CS_SET, CS_INT_TYPE, CS_DATETIME_TYPE, (RXA_CONV_FUNC*)functionPtr)
        != CS_SUCCEED)
        return(RET_DBA_ERR_INITSYBCTX);

    /* For BulkCopy Mode */
    function = (CS_CONV_FUNC)SYB_ConvertDoubleToDate;
    functionPtr = &function;
    if (EV_rxaFctStruct.pfn_cs_set_convert(csContext, CS_SET, CS_FLOAT_TYPE, CS_DATETIME_TYPE, (RXA_CONV_FUNC*)functionPtr)
        != CS_SUCCEED)
        return(RET_DBA_ERR_INITSYBCTX);

    /* Install conversion routine between CS_UNICHAR_FROM_TEXT_TYPE and CS_TEXT_TYPE */
    /* PCL-REF9303-030731 */
    function = (CS_CONV_FUNC)SYB_ConvertUnicodeToText;
    functionPtr = &function;
    if (EV_rxaFctStruct.pfn_cs_set_convert(csContext, CS_SET, CS_UNICHAR_FROM_TEXT_TYPE, CS_TEXT_TYPE, (RXA_CONV_FUNC*)functionPtr)
        != CS_SUCCEED)
        return(RET_DBA_ERR_INITSYBCTX);

    /* Install conversion routine between CS_TEXT_TYPE and CS_UNICHAR_FROM_TEXT_TYPE */
    /* PCL-REF9303-030731 */
    function = (CS_CONV_FUNC)SYB_ConvertTextToUnicode;
    functionPtr = &function;
    if (EV_rxaFctStruct.pfn_cs_set_convert(csContext, CS_SET, CS_TEXT_TYPE, CS_UNICHAR_FROM_TEXT_TYPE, (RXA_CONV_FUNC*)functionPtr)
        != CS_SUCCEED)
        return(RET_DBA_ERR_INITSYBCTX);

    /* Install conversion routine between CS_BINARY_TYPE and CS_USER_TIMESTAMP REF11780 - 100406 - PMO */
    function = (CS_CONV_FUNC)SYB_ConvertTimeStampToCTimeStamp;
    functionPtr = &function;
    if (EV_rxaFctStruct.pfn_cs_set_convert(csContext, CS_SET, CS_BINARY_TYPE, CS_USER_TIMESTAMP, (RXA_CONV_FUNC*)functionPtr)
        != CS_SUCCEED)
        return(RET_DBA_ERR_INITSYBCTX);

    /* Install conversion routine between CS_USER_TIMESTAMP and CS_BINARY_TYPE REF11780 - 100406 - PMO */
    function = (CS_CONV_FUNC)SYB_ConvertCTimeStampToTimeStamp;
    functionPtr = &function;
    if (EV_rxaFctStruct.pfn_cs_set_convert(csContext, CS_SET, CS_USER_TIMESTAMP, CS_BINARY_TYPE, (RXA_CONV_FUNC*)functionPtr)
        != CS_SUCCEED)
        return(RET_DBA_ERR_INITSYBCTX);

    /* Install conversion routine between CS_USER_TIMESTAMP (but CS_UBIGINT_TYPE is used) and CS_BINARY_TYPE / PMSTA-9262 - 090210 - PMO */
    function = (CS_CONV_FUNC)SYB_ConvertCTimeStampToTimeStamp;
    functionPtr = &function;
    if (EV_rxaFctStruct.pfn_cs_set_convert(csContext, CS_SET, CS_UBIGINT_TYPE, CS_BINARY_TYPE, (RXA_CONV_FUNC*)functionPtr)
        != CS_SUCCEED)
        return(RET_DBA_ERR_INITSYBCTX);

    /* Install conversion routine between CS_FLOAT_TYPE and CS_NUMERIC_TYPE */
    extern CS_RETCODE CS_PUBLIC SYB_ConvertFloatToNumeric(
                                CS_CONTEXT *context,
                                    CS_DATAFMT *srcfmt, CS_VOID *srcdata,
                                        CS_DATAFMT *destfmt, CS_VOID *destdata,
                                            CS_INT *destlen);

    static int SV_NoFloat2NumericHandler = -1;

    if (SV_NoFloat2NumericHandler < 0)
    {
        char *value = SYS_GetEnv("AAANOFLOAT2NUMERIC");

        if (value != NULL)
            SV_NoFloat2NumericHandler = atoi(value) != 0 ? 1 : 0;
        else
            SV_NoFloat2NumericHandler = 0;
    }

    if (!SV_NoFloat2NumericHandler)
    {
        function = (CS_CONV_FUNC)SYB_ConvertFloatToNumeric;
        functionPtr = &function;
        if (EV_rxaFctStruct.pfn_cs_set_convert(SYB_GetCsContext(), CS_SET, CS_FLOAT_TYPE, CS_NUMERIC_TYPE, (RXA_CONV_FUNC*)functionPtr)
            != CS_SUCCEED)
            return(RET_DBA_ERR_INITSYBCTX);
    }

    return(RET_SUCCEED);
}

/************************************************************************
*   Function             : SYB_ColBind()
*
*   Description          : Bind a Sybase result column in a result set with
*                          an application variable
*
*   Arguments            : csCommand : a CS_COMMAND structure pointer
*                          colNum    : a column number
*                          type      : type of the data to bind (Sybase type)
*                          dataPtr   : pointer on the variable to bind
*
*   Functions call       : None
*
*   Global var. modified : None
*
*   Return               : RET_SUCCEED            : if ok
*                          RET_DBA_ERR_ARGNOMATCH : if argument problem
*                          RET_DBA_ERR_SYBBIND    : if problem while
*                                                   binding fields
*
*   Creation date        : Apr. 94 - PEC
*   Last Modif. Date     : 30.8.95 - PEC - Added RET_CODE
*************************************************************************/
RET_CODE SYB_ColBind(DbiConnection& dbiConn, int colNum, int type, PTR dataPtr, DBI_INT *dataLength, DBI_SMALLINT *nullData)
{
    CS_DATAFMT  csDataFmt;
    CS_COMMAND *csCommand = (CS_COMMAND*)dbiConn.getCommandPtr();
    /* DLA - REF9089 - 030512 */

    if (csCommand == nullptr)
        return(RET_DBA_ERR_ARGNOMATCH);

    /* Retrieve the format of the source data (column) */
    if (EV_rxaFctStruct.pfn_ct_describe(csCommand, colNum, &csDataFmt) != CS_SUCCEED)
        return(RET_DBA_ERR_SYBBIND);

    switch (type)
    {
        case CS_BINARY_TYPE:    /* REF11780 - 100406 - PMO */
            csDataFmt.format = CS_FMT_UNUSED;
            csDataFmt.datatype = CS_USER_TIMESTAMP;
            /* Bind application variable */
            if (SYB_CtBind(csCommand, colNum, &csDataFmt, (CS_VOID *)dataPtr,
                NULL, (CS_SMALLINT *)nullData, 0, NULL) != CS_SUCCEED)
                return(RET_DBA_ERR_SYBBIND);
            break;

        case CS_INT_TYPE:
        case CS_FLOAT_TYPE:
        case CS_TINYINT_TYPE:
        case CS_NUMERIC_TYPE:
        case CS_SMALLINT_TYPE:
        case CS_DATETIME4_TYPE:
        case CS_DATETIME_TYPE:
        case CS_BIGINT_TYPE:    /* DLA - REF9089 - 030512 */
            /* DLA - PMSTA08801 - 091113 */
            if (type == CS_BIGINT_TYPE && csDataFmt.maxlength == DBA_GetCTypeSize(IntCType))
            {
                type = CS_INT_TYPE;

            }
            if ((type == CS_INT_TYPE || type == CS_NUMERIC_TYPE) && csDataFmt.maxlength == DBA_GetCTypeSize(LongLongCType)) /* PMSTA-23385 - LJE - 160714 */
            {
                type = CS_BIGINT_TYPE;
            }
            csDataFmt.format = CS_FMT_UNUSED;
            csDataFmt.datatype = type;
            /* Bind application variable */
            if (SYB_CtBind(csCommand, colNum, &csDataFmt, (CS_VOID *)dataPtr,
                NULL, (CS_SMALLINT *)nullData, 0, NULL) != CS_SUCCEED)
                return(RET_DBA_ERR_SYBBIND);
            break;

            /* REF3237 - PCL - 990122 SYB_CtBind called with datalength only if CS_CHAR_TYPE. */
        case CS_LONGCHAR_TYPE: /* DLA - PMSTA07121 - 090209 */
        case CS_CHAR_TYPE:
            csDataFmt.format = CS_FMT_NULLTERM;
            csDataFmt.datatype = type;
            csDataFmt.maxlength = csDataFmt.maxlength + 1;
            /* Bind application variable */
            if (SYB_CtBind(csCommand, colNum, &csDataFmt, (CS_VOID *)dataPtr,
                (CS_INT *)dataLength, (CS_SMALLINT *)nullData, 0, NULL) != CS_SUCCEED)
                return(RET_DBA_ERR_SYBBIND);
            break;

        case CS_UNICHAR_TYPE:
            csDataFmt.format = CS_FMT_NULLTERM;
            csDataFmt.datatype = type;

            /* PMSTA-43740 - LJE - 210305 */
            if (csDataFmt.usertype == CS_LONGCHAR_TYPE ||
                (csDataFmt.usertype > 100 && dbiConn.getCurrCharsetEn() != CurrentCharsetCode_UTF8))    /* PMSTA-43367 - LJE - 210427 */
            {
                csDataFmt.maxlength *= 2;
            }
            csDataFmt.maxlength = csDataFmt.maxlength + 2;
            /* Bind application variable */
            if (SYB_CtBind(csCommand, colNum, &csDataFmt, (CS_VOID *)dataPtr,
                (CS_INT *)dataLength, (CS_SMALLINT *)nullData, 0, NULL) != CS_SUCCEED)
                return(RET_DBA_ERR_SYBBIND);
            break;
    }

    return(RET_SUCCEED);
}

/************************************************************************
*   Function             : SYB_BindRecvDynFld()
*
*   Description          : Bind a Sybase result column in a dynFld
*
*   Arguments            : connectNo  : a connection number in the conn. list
*                          dynStType  : the format number of the result data
*                          bindData   : the structure used for binding result
*                                      columns.
*
*   Functions call       : None
*
*   Global var. modified : None
*
*   Return               : RET_SUCCEED            : if ok
*                          RET_DBA_ERR_ARGNOMATCH : if argument problem
*                          RET_DBA_ERR_SYBBIND    : if problem while
*                                                   binding fields
*
*   Creation date        : PMSTA08801 - DDV - 091208 - Code extracted from SYB_BindRecvDynSt to avoid code duplication for binding of ouput parameters
*   Last Modif. Date     :
*
*************************************************************************/
RET_CODE SYB_BindRecvDynFld(DBA_DYNFLD_STP bindData,
                            INT_T          fldIdx,
                            DATATYPE_ENUM  dataTypeEn,
                            INT_T          colIndex,
                            DBI_SMALLINT  *nullFlgPtr,
                            DBI_INT       *fieldLengthPtr,
                            CS_COMMAND    *csCommand,
                            CS_DATAFMT     csDataFmt,
                            FLAG_T         outputIndexed) /* DLA - PMSTA08801 - 110103 */
{
    DBA_DYNST_ENUM dynStType = GET_DYNSTENUM(bindData);

#ifdef AAADEBUGMSG
    char           attrib_buff[80];

    memset(attrib_buff, 0, sizeof(attrib_buff));

    if (csDataFmt.namelen > 0 && csDataFmt.name != NULL)
    {
        sprintf(attrib_buff, " (%.76s)", csDataFmt.name);

        /* PMSTA09979 - LJE - 100720 */
        if (SERVER_IS_INIT() == TRUE &&
            GET_CUST_ENTITY(dynStType) != NullEntity)  /* SKE 010222 */
        {
            OBJECT_ENUM objectEn = GET_CUST_ENTITY(dynStType);

            if (GET_EDITGUIST(objectEn) == dynStType &&
                strcmp(csDataFmt.name, "ud_id") != 0)
            {
                if (strcmp(DBA_GetDictAttribSqlName(objectEn, fldIdx), csDataFmt.name) != 0 &&
                    (csDataFmt.namelen < 1 ||
                     strcmp(DBA_GetDictAttribSqlName(objectEn, fldIdx), &csDataFmt.name[1]) != 0) && /* DLA - PMSTA08801 - 100225 - check without @ for output parameters */
                     (outputIndexed == FALSE)) /* DLA - PMSTA08801 - 110103 */
                {
                    MSG_LogMesg(RET_DBA_ERR_SYBBIND, 3, FILEINFO,
                                fldIdx, DBA_GetDictEntitySqlName(objectEn),
                                csDataFmt.name,
                                DBA_GetDictAttribSqlName(objectEn, fldIdx));
                }
            }
        }
    }
#endif

    switch (csDataFmt.datatype)
    {
        case CS_CHAR_TYPE:
        case CS_LONGCHAR_TYPE: /* DLA - PMSTA07121 - 090213 */
        case CS_TEXT_TYPE:      /* REF4204 */

#ifdef AAADEBUGMSG
            if ((GET_CTYPE(dataTypeEn) != CharPtrCType) &&
                (GET_CTYPE(dataTypeEn) != TextPtrCType) &&
                (GET_CTYPE(dataTypeEn) != UniCharPtrCType) && /* REF9303 - LJE - 030910 */
                (GET_CTYPE(dataTypeEn) != UniTextPtrCType))
            {
                char dynStString[256];

                /* REF9303 - LJE - 030910 */
                if (dynStType > NullDynSt)
                {
                    sprintf(dynStString, "%s", DBA_GetDynStCName(dynStType));
                }
                else
                {
                    sprintf(dynStString, "%d", dynStType);
                }
                strcat(dynStString, attrib_buff);

                MSG_LogMesg(RET_DBA_ERR_SYBBIND, 2, FILEINFO, fldIdx, dynStString,
                            csDataFmt.datatype, GET_CTYPE(dataTypeEn));
            }
#endif
            csDataFmt.format = CS_FMT_NULLTERM;

            ALLOC_STRFLD(
                bindData[fldIdx], csDataFmt.maxlength);

            csDataFmt.maxlength += 1;

            if (SYB_CtBind(csCommand, colIndex, &csDataFmt,
                (CS_VOID *)bindData[fldIdx].data.strData.ptr,
                           (CS_INT *)fieldLengthPtr,
                           (CS_SMALLINT *)nullFlgPtr,
                           GET_ANONYMIZE_ITEM(dynStType, fldIdx),
                           GET_ANONYMIZE_SUBST(dynStType, fldIdx)) != CS_SUCCEED) /* REF3955 - SSO - 000117 */
            {
                MSG_LogMesg(RET_DBA_ERR_SYBBIND, 0, FILEINFO);
                return(RET_DBA_ERR_SYBBIND);
            }
            break;

        case CS_UNICHAR_TYPE:   /* PCL-REF9303-030724 */
        case CS_UNITEXT_TYPE:   /* PMSTA-13109 - LJE - 111215 */

#ifdef AAADEBUGMSG
            if (GET_CTYPE(dataTypeEn) != UniCharPtrCType)
            {
                char dynStString[60];

                /* REF9303 - LJE - 030910 */
                if (dynStType > NullDynSt)
                {
                    sprintf(dynStString, "%s", DBA_GetDynStCName(dynStType));
                }
                else
                {
                    sprintf(dynStString, "%d", dynStType);
                }
                strcat(dynStString, attrib_buff);

                MSG_LogMesg(RET_DBA_ERR_SYBBIND, 2, FILEINFO, fldIdx, dynStString,
                            csDataFmt.datatype, GET_CTYPE(dataTypeEn));
            }
#endif
            csDataFmt.format = CS_FMT_NULLTERM;

            csDataFmt.maxlength /= 2;

            ALLOC_USTRFLD(
                bindData[fldIdx], csDataFmt.maxlength);

            csDataFmt.maxlength += 1;
            csDataFmt.maxlength *= 2;

            if (SYB_CtBind(csCommand, colIndex, &csDataFmt,
                (CS_VOID *)bindData[fldIdx].data.ustrData.ptr,
                           (CS_INT *)fieldLengthPtr,
                           (CS_SMALLINT *)nullFlgPtr,
                           GET_ANONYMIZE_ITEM(dynStType, fldIdx),
                           GET_ANONYMIZE_SUBST(dynStType, fldIdx)) != CS_SUCCEED) /* REF3955 - SSO - 000117 */
            {
                MSG_LogMesg(RET_DBA_ERR_SYBBIND, 0, FILEINFO);
                return(RET_DBA_ERR_SYBBIND);
            }

            break;

        case CS_DATETIME_TYPE:

#ifdef AAADEBUGMSG
            if (GET_CTYPE(dataTypeEn) != DateTimeStCType &&
                GET_CTYPE(dataTypeEn) != UIntCType)
            {
                char dynStString[60];

                /* REF9303 - LJE - 030910 */
                if (dynStType > NullDynSt)
                {
                    sprintf(dynStString, "%s", DBA_GetDynStCName(dynStType));
                }
                else
                {
                    sprintf(dynStString, "%d", dynStType);
                }
                strcat(dynStString, attrib_buff);

                MSG_LogMesg(RET_DBA_ERR_SYBBIND, 2, FILEINFO, fldIdx, dynStString,
                            csDataFmt.datatype, GET_CTYPE(dataTypeEn));
            }
#endif
            csDataFmt.format = CS_FMT_UNUSED;

            /*
               Convert the Date switch field C type
               REM : SYB_CtBind will automatically call SYB_ConvertDateToInt() if
                                 the field type is a long (DATE_T) and SYB_ConvertDateToDouble if
                                 the field type is a structure DATETIME_ST (Date and Time)
                        */

            csDataFmt.datatype = CS_FLOAT_TYPE;
            break;


        case CS_BINARY_TYPE:   /* REF11780 - 100406 - PMO */
            csDataFmt.format = CS_FMT_UNUSED;
            csDataFmt.datatype = CS_USER_TIMESTAMP;
            break;


        case CS_INT_TYPE:

#ifdef AAADEBUGMSG
            if (GET_CTYPE(dataTypeEn) != IntCType &&
                GET_CTYPE(dataTypeEn) != UIntCType &&
                GET_CTYPE(dataTypeEn) != LongLongCType)
            {
                char dynStString[60];

                /* REF9303 - LJE - 030910 */
                if (dynStType > NullDynSt)
                {
                    sprintf(dynStString, "%s", DBA_GetDynStCName(dynStType));
                }
                else
                {
                    sprintf(dynStString, "%d", dynStType);
                }
                strcat(dynStString, attrib_buff);

                MSG_LogMesg(RET_DBA_ERR_SYBBIND, 2, FILEINFO, fldIdx, dynStString,
                            csDataFmt.datatype, GET_CTYPE(dataTypeEn));
            }
#endif
            csDataFmt.format = CS_FMT_UNUSED;
            csDataFmt.datatype = CS_INT_TYPE;
            break;

        case CS_NUMERIC_TYPE:
            csDataFmt.format = CS_FMT_UNUSED;
            switch (csDataFmt.scale)
            {
                case 0:
#ifdef AAADEBUGMSG
                    if (GET_CTYPE(dataTypeEn) != LongLongCType) /* DLA - REF9089 - 030805 */ /* PMSTA08801 - DDV - 091126 */
                    {
                        char dynStString[60];

                        /* REF9303 - LJE - 030910 */
                        if (dynStType > NullDynSt)
                        {
                            sprintf(dynStString, "%s", DBA_GetDynStCName(dynStType));
                        }
                        else
                        {
                            sprintf(dynStString, "%d", dynStType);
                        }
                        strcat(dynStString, attrib_buff);

                        MSG_LogMesg(RET_DBA_ERR_SYBBIND, 2, FILEINFO, fldIdx, dynStString,
                                    csDataFmt.datatype, GET_CTYPE(dataTypeEn));
                    }
#endif
                    csDataFmt.datatype = CS_BIGINT_TYPE; /* DLA - PMSTA08801 - 091221 - Force implicite convert from num14.0 to int64 */
                    if (SYB_CtBind(csCommand, colIndex, &csDataFmt,
                        (CS_VOID *)&(bindData[fldIdx].data.longlongValue), /* PMSTA08801 - DDV - 091126 */
                                   NULL, (CS_SMALLINT *)nullFlgPtr,
                                   GET_ANONYMIZE_ITEM(dynStType, fldIdx),
                                   GET_ANONYMIZE_SUBST(dynStType, fldIdx)) != CS_SUCCEED)
                    {
                        MSG_LogMesg(RET_DBA_ERR_SYBBIND, 0, FILEINFO);
                        return(RET_DBA_ERR_SYBBIND);
                    }
                    break;

                default:
#ifdef AAADEBUGMSG
                    if (GET_CTYPE(dataTypeEn) != DoubleCType)
                    {
                        char dynStString[60];

                        /* REF9303 - LJE - 030910 */
                        if (dynStType > NullDynSt)
                        {
                            sprintf(dynStString, "%s", DBA_GetDynStCName(dynStType));
                        }
                        else
                        {
                            sprintf(dynStString, "%d", dynStType);
                        }
                        strcat(dynStString, attrib_buff);

                        MSG_LogMesg(RET_DBA_ERR_SYBBIND, 2, FILEINFO, fldIdx, dynStString,
                                    csDataFmt.datatype, GET_CTYPE(dataTypeEn));
                    }
#endif
                    csDataFmt.datatype = CS_FLOAT_TYPE;
                    break;
            }
            break;

        case CS_BIGINT_TYPE: /* DLA - PMSTA08801 - 091215 */
            if (SYB_CtBind(csCommand, colIndex, &csDataFmt,
                (CS_VOID *)&(bindData[fldIdx].data.longlongValue), /* PMSTA08801 - DDV - 091126 */
                           NULL, (CS_SMALLINT *)nullFlgPtr,
                           GET_ANONYMIZE_ITEM(dynStType, fldIdx),
                           GET_ANONYMIZE_SUBST(dynStType, fldIdx)) != CS_SUCCEED)
            {
                MSG_LogMesg(RET_DBA_ERR_SYBBIND, 0, FILEINFO);
                return(RET_DBA_ERR_SYBBIND);
            }
            break;


        case CS_SMALLINT_TYPE:

#ifdef AAADEBUGMSG
            if (GET_CTYPE(dataTypeEn) != ShortCType &&
                GET_CTYPE(dataTypeEn) != UShortCType)
            {
                char dynStString[60];

                /* REF9303 - LJE - 030910 */
                if (dynStType > NullDynSt)
                {
                    sprintf(dynStString, "%s", DBA_GetDynStCName(dynStType));
                }
                else
                {
                    sprintf(dynStString, "%d", dynStType);
                }
                strcat(dynStString, attrib_buff);

                MSG_LogMesg(RET_DBA_ERR_SYBBIND, 2, FILEINFO, fldIdx, dynStString,
                            csDataFmt.datatype, GET_CTYPE(dataTypeEn));

            }
#endif
            csDataFmt.format = CS_FMT_UNUSED;
            csDataFmt.datatype = CS_SMALLINT_TYPE;
            break;
    }

    if (csDataFmt.datatype != CS_BIGINT_TYPE &&
        csDataFmt.datatype != CS_CHAR_TYPE &&
        csDataFmt.datatype != CS_LONGCHAR_TYPE && /* DLA - PMSTA07121 - 090213 */
        csDataFmt.datatype != CS_TEXT_TYPE &&
        csDataFmt.datatype != CS_UNICHAR_TYPE &&
        csDataFmt.datatype != CS_UNICHAR_FROM_TEXT_TYPE)
    {

#ifdef AAADEBUGMSG
        if (csDataFmt.datatype == CS_TINYINT_TYPE && GET_CTYPE(dataTypeEn) != UCharCType)
        {
            char dynStString[60];

            /* REF9303 - LJE - 030910 */
            if (dynStType > NullDynSt)
            {
                sprintf(dynStString, "%s", DBA_GetDynStCName(dynStType));
            }
            else
            {
                sprintf(dynStString, "%d", dynStType);
            }
            strcat(dynStString, attrib_buff);

            MSG_LogMesg(RET_DBA_ERR_SYBBIND, 2, FILEINFO, fldIdx, dynStString,
                        csDataFmt.datatype, GET_CTYPE(dataTypeEn));

        }
#endif
        if (SYB_CtBind(csCommand, colIndex, &csDataFmt,
            (CS_VOID *)&(bindData[fldIdx].data.dbleValue),
                       NULL, (CS_SMALLINT *)nullFlgPtr,
                       GET_ANONYMIZE_ITEM(dynStType, fldIdx),
                       GET_ANONYMIZE_SUBST(dynStType, fldIdx)) != CS_SUCCEED) /* REF3955 - SSO - 000117 */
        {
            MSG_LogMesg(RET_DBA_ERR_SYBBIND, 0, FILEINFO);
            return(RET_DBA_ERR_SYBBIND);
        }
    }

    return(RET_SUCCEED);
}

/************************************************************************
*   Function             : SYB_CopyNullFlagsAndLength()
*
*   Description          : For specified field, copy the null flag and string
*                          length informations in the bind structure.
*
*   Arguments            : connectNo : the connection number
*                          bindData  : the structure array used for binding
*                          column : the index of the field
*                          type: the datatype of the field
*
*   Functions call       : None
*
*   Global var. modified : None
*
*   Return               : RET_SUCCEED            : if ok
*
*   Creation date        : Apr. 94 - PEC
*   Last Modif. Date     : 30.8.95 - PEC - Added RET_CODE
*                          28.05.98 - GRD - REF2165. Allow 64Ko size scripts.
*************************************************************************/
RET_CODE SYB_CopyNullFlagsAndLength(DbiConnection& dbiConn, DBA_DYNFLD_STP bindData, int column, DATATYPE_ENUM type)
{
    /* Retrieve Null flags and Field length informations for a row */
	DBI_SMALLINT  * nullFlags   = dbiConn.m_bindNullFlags;
    DBI_SMALLINT  * bindFlags   = dbiConn.m_bindFlags;

	/* PMSTA-17490 - DDV - 140124 - Set and keep default_c on fields not returned by database */
    if (bindFlags[column] == 1)
    {
        if (nullFlags[column] != -1)
        {
            SET_NOTNULLFLG_T(bindData, column);
        }
        else
        {
            SET_NOTNULLFLG_F(bindData, column);
        }
    }

    return(RET_SUCCEED);
}

/************************************************************************
*   Function             : SYB_CopyNullFlagsAndLengthDynSt()
*
*   Description          : For each field, copy the null flag and string
*                          length informations in the bind structure.
*
*   Arguments            : connectNo : the connection number
*                          bindData  : the structure array used for binding
*                          dynStEnum : the dynamic structure enum
*
*   Functions call       : None
*
*   Global var. modified : None
*
*   Return               : RET_SUCCEED            : if ok
*
*   Creation date        : REF8844 - LJE - 030411
*   Last Modif. Date     : REF11780 - 100406 - PMO : Implementation of the Sybase timestamp field
*
*************************************************************************/
RET_CODE SYB_CopyNullFlagsAndLengthDynSt(DbiConnection& dbiConn, DBA_DYNFLD_STP bindData, DBA_DYNST_ENUM dynStEnum)
{
    DBI_SMALLINT  *nullFlags = NULL;
    DBI_INT       *fieldLength = NULL;
    DBI_SMALLINT  *bindFlags = NULL;
    int      colNumber = GET_FLD_NBR(dynStEnum);

    /* Retrieve Null flags and Field length informations for a row */
    nullFlags   = dbiConn.m_bindNullFlags;
    fieldLength = dbiConn.m_bindFieldLength;
    bindFlags   = dbiConn.m_bindFlags;

    for (int i = 0; i < colNumber; i++)
    {
        /* PMSTA-17490 - DDV - 140124 - Set and keep default_c on fields not returned by database */
        if (bindFlags[i] == 1)
            DBA_CopyNullFlagsAndLengthDynFld(bindData, dynStEnum, i, nullFlags[i], fieldLength[i]);
    }
    return RET_SUCCEED;
}

/************************************************************************
*   Function             : SYB_GetDataFmtForNumeric()
*
*   Description          :
*
*   Arguments            : fieldType : the field type
*                          data      : a double value
*                          csDataFmt : format structure
*
*   Functions call       : None
*
*   Global var. modified : None
*
*   Return               : RET_SUCCEED            : if ok
*                          RET_DBA_ERR_SETPARAM   : if problem setting
*                                                   parameter
*
*   Creation date        : PMSTA-37366 - LJE - 200407
*   Last Modif. Date     :
*************************************************************************/
RET_CODE SYB_GetDataFmtForNumeric(DATATYPE_ENUM  fieldType,
                                  CS_DATAFMT     &csDataFmt,
                                  CS_DATAFMT     &csDataFmtSrc)
{
    switch (fieldType)
    {
        case DictType:
            csDataFmt.precision = DICT_T_LEN;
            csDataFmt.scale = DICT_T_DEC;
            csDataFmtSrc.datatype = CS_BIGINT_TYPE;      /*DLA - REF9089 - 030807 *//* PMSTA08801 - DDV - 091126 */
            csDataFmtSrc.maxlength = sizeof(CS_BIGINT);   /*DLA - REF9089 - 030807 *//* PMSTA08801 - DDV - 091126 */
            break;
        case IdType:
            csDataFmt.precision = ID_T_LEN;
            csDataFmt.scale = ID_T_DEC;
            csDataFmtSrc.datatype = CS_BIGINT_TYPE;      /*DLA - REF9089 - 030807 *//* PMSTA08801 - DDV - 091126 */
            csDataFmtSrc.maxlength = sizeof(CS_BIGINT);   /*DLA - REF9089 - 030807 *//* PMSTA08801 - DDV - 091126 */
            break;

            /* PMSTA-20887 - LJE - 150909 */
        case LongintType:
            csDataFmt.precision = LONGINT_T_LEN;
            csDataFmt.scale = ID_T_DEC;
            csDataFmtSrc.datatype = CS_BIGINT_TYPE;
            csDataFmtSrc.maxlength = sizeof(CS_BIGINT);
            break;

        case AmountType:
            csDataFmt.precision = GET_MAXLEN(AmountType);
            csDataFmt.scale = GET_DECIMAL(AmountType);
            csDataFmtSrc.datatype = CS_FLOAT_TYPE;
            csDataFmtSrc.maxlength = sizeof(CS_FLOAT);
            break;

        case LongamountType:                           /* DVP041 - 960429 - DED */
            csDataFmt.precision = LONGAMOUNT_T_LEN;
            csDataFmt.scale = LONGAMOUNT_T_DEC;
            csDataFmtSrc.datatype = CS_FLOAT_TYPE;
            csDataFmtSrc.maxlength = sizeof(CS_FLOAT);
            break;

        case ExchangeType:
            csDataFmt.precision = EXCHANGE_T_LEN;
            csDataFmt.scale = EXCHANGE_T_DEC;
            csDataFmtSrc.datatype = CS_FLOAT_TYPE;
            csDataFmtSrc.maxlength = sizeof(CS_FLOAT);
            break;

        case NumberType:
            csDataFmt.precision = NUMBER_T_LEN;
            csDataFmt.scale = NUMBER_T_DEC;
            csDataFmtSrc.datatype = CS_FLOAT_TYPE;
            csDataFmtSrc.maxlength = sizeof(CS_FLOAT);
            break;

        case PercentType:
            csDataFmt.precision = PERCENT_T_LEN;
            csDataFmt.scale = PERCENT_T_DEC;
            csDataFmtSrc.datatype = CS_FLOAT_TYPE;
            csDataFmtSrc.maxlength = sizeof(CS_FLOAT);
            break;
			
		case PriceType:
			/* Data is not defined in dev branch where as present in 25.4.07.A01 */
			/* if (data < PRICE_T_PREC && data > -PRICE_T_PREC)
				data = 0.0;
			else
				data = TLS_Round(data, TLS_GetNumericPrec(data, PRICE_T_DEC, NULL), RndRule_Nearest);
			*/
			csDataFmt.precision = PRICE_T_LEN;
			csDataFmt.scale = PRICE_T_DEC;
			csDataFmtSrc.datatype = CS_FLOAT_TYPE;
			csDataFmtSrc.maxlength = sizeof(CS_FLOAT);
			break;	
        default:
            break;
    }

    csDataFmtSrc.locale = NULL;

    csDataFmt.datatype  = CS_NUMERIC_TYPE;
    csDataFmt.maxlength = sizeof(CS_NUMERIC);
    csDataFmt.locale    = NULL;
    csDataFmt.format    = CS_FMT_UNUSED;

    return(RET_SUCCEED);
}

/************************************************************************
*   Function             : SYB_RoundDblValue()
*
*   Description          : 
*
*   Arguments            : fieldType : the field type
*                          data      : a double value
*
*   Functions call       : None
*
*   Global var. modified : None
*
*   Return               : RET_SUCCEED            : if ok
*                          RET_DBA_ERR_SETPARAM   : if problem setting
*                                                   parameter
*
*   Creation date        : PMSTA-37366 - LJE - 200603
*   Last Modif. Date     :
*************************************************************************/
RET_CODE SYB_RoundDblValue(DATATYPE_ENUM  fieldType, double        &data)
{
    switch (fieldType)
    {
        case AmountType:
            if (data < SV_AmountPrecision && data > -SV_AmountPrecision)
                data = 0.0;
            else
                data = TLS_Round(data, TLS_GetNumericPrec(data, GET_DECIMAL(AmountType), NULL), RndRule_Nearest);
            break;

        case LongamountType:                           /* DVP041 - 960429 - DED */
            if (data < LONGAMOUNT_T_PREC && data > -LONGAMOUNT_T_PREC)
                data = 0.0;
            else
                data = TLS_Round(data, TLS_GetNumericPrec(data, LONGAMOUNT_T_DEC, NULL), RndRule_Nearest);
            break;

        case ExchangeType:
            if (data < EXCHANGE_T_PREC && data > -EXCHANGE_T_PREC)
                data = 0.0;
            else
                data = TLS_Round(data, TLS_GetNumericPrec(data, EXCHANGE_T_DEC, NULL), RndRule_Nearest);
            break;

        case NumberType:
            if (data < NUMBER_T_PREC && data > -NUMBER_T_PREC)
                data = 0.0;
            else
                data = TLS_Round(data, TLS_GetNumericPrec(data, NUMBER_T_DEC, NULL), RndRule_Nearest);
            break;

        case PercentType:
            if (data < PERCENT_T_PREC && data > -PERCENT_T_PREC)
                data = 0.0;
            else
                data = TLS_Round(data, TLS_GetNumericPrec(data, PERCENT_T_DEC, NULL), RndRule_Nearest);
            break;

        default:
            break;
    }

    return RET_SUCCEED;
}

/************************************************************************
*   Function             : SYB_ConvertFldToNumeric()
*
*   Description          : Convert a field (double value) to a numeric type
*                          according to  precision and scale.
*
*   Arguments            : csCommand : command structure pointer
*                          fieldType : the field type
*                          data      : a double value
*                          csDataFmt : format structure
*
*   Functions call       : None
*
*   Global var. modified : None
*
*   Return               : RET_SUCCEED            : if ok
*                          RET_DBA_ERR_SETPARAM   : if problem setting
*                                                   parameter
*
*   Creation date        : PMSTA-37366 - LJE - 200407
*   Last Modif. Date     :
*************************************************************************/
RET_CODE SYB_ConvertFldToNumeric(DATATYPE_ENUM  fieldType,
                                 double         data,
                                 CS_DATAFMT     &csDataFmt,
                                 CS_DATAFMT     &csDataFmtSrc,
                                 CS_NUMERIC     &numeric)
{
    ID_T       dataId = 0;
    bool       bUseDataId = false;
    CS_RETCODE csRet;               /* PMSTA-33082 - DDV - 190510 - Manage error code to avoid data insertion when overflow occurs */

    switch (fieldType)
    {
        case DictType:
            bUseDataId = true;
            dataId = (ID_T)data; /* DLA - PSMTA08801 - 101229 */
            break;

        case IdType:
            bUseDataId = true;
            dataId = (ID_T)data; /* DLA - PSMTA08801 - 101229 */
            break;

        /* PMSTA-20887 - LJE - 150909 */
        case LongintType:
            bUseDataId = true;
            dataId = (LONGINT_T)data;
            break;

        default:
            break;
    }

    numeric.precision = (CS_BYTE)csDataFmt.precision;
    numeric.scale     = (CS_BYTE)csDataFmt.scale;

    if (bUseDataId)
    {
        csRet = EV_rxaFctStruct.pfn_cs_convert(SYB_GetCsContext(), &csDataFmtSrc, &dataId, &csDataFmt, &numeric, NULL);
    }
    else
    {
        SYB_RoundDblValue(fieldType, data);

        csRet = EV_rxaFctStruct.pfn_cs_convert(SYB_GetCsContext(), &csDataFmtSrc, &data, &csDataFmt, &numeric, NULL);
    }

    if (TLS_Return(0))
    {
        double dataOut = 0.;

        csRet = EV_rxaFctStruct.pfn_cs_convert(SYB_GetCsContext(), &csDataFmt, &numeric, &csDataFmtSrc, &dataOut, NULL);

        csDataFmt.locale = csDataFmtSrc.locale;
    }

    /* PMSTA-33082 - DDV - 190510 - Manage error code to avoid data insertion when overflow occurs */
    if (csRet != CS_SUCCEED)
    {
        return(RET_DBA_ERR_INVDATA);
    }
    
    return(RET_SUCCEED);
}

/************************************************************************
*   Function             : SYB_ConvertFldToNumericAndSetParam()
*
*   Description          : Convert a field (double value) to a numeric type
*                          according to  precision and scale.
*
*   Arguments            : csCommand : command structure pointer
*                          fieldType : the field type
*                          data      : a double value
*                          csDataFmt : format structure
*
*   Functions call       : None
*
*   Global var. modified : None
*
*   Return               : RET_SUCCEED            : if ok
*                          RET_DBA_ERR_SETPARAM   : if problem setting
*                                                   parameter
*
*   Creation date        : 3.10.95 - PEC
*   Last Modif. Date     : 29.09.99 - GRD - Ref.: REF3847.
*************************************************************************/
RET_CODE SYB_ConvertFldToNumericAndSetParam(SybConnection& dbiConn,
                                            DATATYPE_ENUM  fieldType,
                                            double         data,
                                            CS_DATAFMT     csDataFmt)
{
    CS_RETCODE csRet;
    RET_CODE   ret;

    CS_DATAFMT csDataFmtSrc;
    CS_NUMERIC numeric;
    memset(&numeric, 0, sizeof(CS_NUMERIC)); /* REF11026 - LJE - 050303 */
    memset(&csDataFmtSrc,0,sizeof(CS_DATAFMT));

    SYB_GetDataFmtForNumeric(fieldType, csDataFmt, csDataFmtSrc);

    /* PMSTA-33082 - DDV - 190510 - Manage error code to avoid data insertion when overflow occurs */
    if ((ret = SYB_ConvertFldToNumeric(fieldType, data, csDataFmt, csDataFmtSrc, numeric)) != RET_SUCCEED)
    {
        auto &msgStructSt = dbiConn.m_msgStructHeaderSt.getNewErrMsgInfoSt(FILEINFO);

        msgStructSt.techMsg = FALSE;
        msgStructSt.retCode = RET_DBA_ERR_SETPARAM;
        msgStructSt.msgString = "Arithmetic overflow occurred";

        return(RET_DBA_ERR_SETPARAM);
    }

    csRet = SYB_CtParam(dbiConn, &csDataFmt, &numeric, sizeof(CS_NUMERIC), CS_UNUSED);

    /* PMSTA-33082 - DDV - 190510 - Manage error code to avoid data insertion when overflow occurs */
    if(csRet != CS_SUCCEED)
    {
        auto &msgStructSt = dbiConn.m_msgStructHeaderSt.getNewErrMsgInfoSt(FILEINFO);

        msgStructSt.techMsg = FALSE;
        msgStructSt.retCode = RET_DBA_ERR_SETPARAM;
        msgStructSt.msgString = "SYB_CtParam failed";

        return(RET_DBA_ERR_SETPARAM);
    }

    return(RET_SUCCEED);
}

/************************************************************************
*   Function             : SYB_SetProcParameters()
*
*   Description          : Set the necessary parameters for the request
*                          in the CS_COMMAND structure
*
*   Arguments            : DbiConnection : the connection
*                          inputst   : the object request
*                          inputData : the input parameter structure
*                          procedure : a pointer on the choosen procedure
*
*   Functions call       : None
*
*   Global var. modified : None
*
*   Return               : RET_SUCCEED            : if ok
*                          RET_DBA_ERR_ARGNOMATCH : if argument problem
*                          RET_DBA_ERR_SETPARAM   : if problem while
*                                                   binding fields
*
*   Creation date        : Apr.  94 - PEC
*   Last Modif. Date     : 30.08.95 - PEC - Added RET_CODE
*                          08.06.99 - GRD - Ref.: REF3537.
*                          29.09.99 - GRD - Ref.: REF3847.
*                          02.02.00 - GRD - Ref.: REF4204.
*                          REF7264 - 011212 - PMO : Compilation errors and warnings with C++ compiler
*                          REF11780 - 100406 - PMO : Implementation of the Sybase timestamp field
*                          PMSTA-15918 - 070213 - PMO : Fusion on portfolio [T_AI_PE_ST] failed ; upd_exd_position : Attempt to insert NULL value into column 'end_d', table position
*                          PMSTA-16443 - 230713 - PMO : Add confirmation-to-continue messages in case not enough free memory is available for the GUI when loading data from a financial server
*
*************************************************************************/
RET_CODE SYB_SetProcParameters(SybConnection& dbiConn, DBA_DYNST_ENUM inputSt, DBA_DYNFLD_STP inputData, DBA_PROC_STP procedure)
{
    CS_DATAFMT          csDataFmt;
    CS_DATETIME         datetime;
    CS_DATETIME4        datetimeSmall;
    INT_T               thirdSecond;
    SMALLINT_T          minutes;
    DBA_PROCPARAM_STP   procParam = NULL;
    int                 paramIndex;
    CS_RETCODE          csRet = CS_SUCCEED;
    RET_CODE            ret = RET_SUCCEED;
    long                daysNbr = 0;        /* REF3305 - AKO - 990303 */
    long                tempLength = 0;
    DATE_T              refDate;
    HOUR_T              hour;
    MINUTE_T            min;
    SECOND_T            second;
    DATATYPE_ENUM       fieldType;
    char                *buf;               /*  FIH-REF11396-050905 Replace 500 by TEXT_T_LEN Else fatal error with text field with a lenght > 500  */
    int                 bufLen;
    int                 i = 0;
    int                 j = 0;
    char                *sqlTraceStr=NULL;  /* REF10195 - LJE - 040407 */
    char                *procName=NULL;     /* PMSTA07964 - LJE - 090317 */

    if (procedure == NULL)
    {
        return(RET_DBA_ERR_ARGNOMATCH);
    }

    /* PMSTA-34344 - LJE - 190521 */
    if (procedure->action == Update ||
        procedure->action == Insert)
    {
        OBJECT_ENUM object;
        DBA_GetObjectEnumByDynSt(inputSt, &object);
        DBA_SetMagicDate(inputData, inputSt, object);
    }


    dbiConn.startRequest(); /* PMSTA-nuodb - LJE - 190715 */

    /* PMSTA-11505 - LJE - 110617 */
    dbiConn.setCurrProcedure(procedure);

    /* Fill the CS_COMMAND with the request name */
	if (SYB_CtCommand(dbiConn, DBA_RPC, procName == NULL ? procedure->procName : procName, &sqlTraceStr) != CS_SUCCEED)
    {
		DbiConnection* dbiConnPtr = &dbiConn;
		DBA_EndConnection(&dbiConnPtr);
        /* REF10195 - LJE - 040407 */
        SYB_SendSqlTrace(&sqlTraceStr);
        return(RET_DBA_ERR_SETPARAM);
    }

    /* PMSTA07964 - LJE - 090317 */
    if (procName != NULL)
    {
        FREE(procName);
    }

    if(EV_ExtractFile)
    {
        EV_SetProcParametersFlg = TRUE;
        DATE_StopTimer(&EV_ExtractFileTimer, TIMER_MASK_GEN);

        fprintf(EV_ExtractFile,
            "%05d %5d.%03d %s %s ",
            ++EV_ExtractFileCpt,
            (int)EV_ExtractFileTimer.cumul.tv_sec,
            (int)EV_ExtractFileTimer.cumul.tv_usec/1000,
            (procedure->server == SqlServer)? "SQL":"FIN",
            procedure->procName);
    }

    paramIndex = 0;

    /* PMSTA08497 - DDV - 090806 - Use a variable to know the size of the buffer,
       and replace all sizeof on buf with this variable  */
    bufLen=GET_MAXDATALEN(TextType);
    buf = (char*) CALLOC(bufLen, sizeof(char));     /*  FIH-REF11396-050905 Replace 500 by TEXT_T_LEN Else fatal error with text field with a lenght > 500  */

    /* PMSTA-16443 - 230713 - PMO */
    if (NULL == buf)
    {
        return RET_MEM_ERR_ALLOC;
    }

    /*
     * The following action flags means that the input parameters will not be taken from dbaproc.c but from metadictionnary.
     * GRD - 990714 - REF3537.
     */

    if (procedure->procParamDefPtr == NULL &&
            (procedure->subObj == DBA_ROLE_COLLECT ||
             procedure->action == SelMetaDict))
    {
        OBJECT_ENUM object;
        const char *sqlName = NULL;
        char *      pTemp2; /* DLA - REF8728 */

        procParam = (DBA_PROCPARAM_STP)CALLOC(GET_FLD_NBR(inputSt) + 1, sizeof(DBA_PROCPARAM_ST));

        if (procParam == NULL)
        {
            /* REF10195 - LJE - 040407 */
            SYB_SendSqlTrace(&sqlTraceStr);
            FREE(buf);                      /*  FIH-REF11396-050906 */
            return(RET_DBA_ERR_SETPARAM);
        }

        DBA_GetObjectEnumByDynSt(inputSt, &object);

        if (procedure->subObj != DBA_ROLE_COLLECT)
        {
            DICT_ATTRIB_STP dictAttribStp = NULL;

            for (i = 0, j = 0; i < GET_FLD_NBR(inputSt); i++)
            {

                dictAttribStp = DBA_GetDictAttribSt(object, i);

                if (dictAttribStp == NULL || dictAttribStp->calcEn == DictAttr_NoMD || dictAttribStp->logicalFlg == TRUE)
                {
                    continue;
                }

                sqlName = dictAttribStp->sqlName;

                if ((sqlName != NULL) && (sqlName[0] != 0x00))
                {
                    char * pTemp; /* DLA - REF8728 */

                    procParam[j].fldNbrPtr = (FIELD_IDX_T*)CALLOC(1, sizeof(FIELD_IDX_T)); /* REF8844 - LJE - 030414 */
                    *(procParam[j].fldNbrPtr)    = i; /* REF8844 - LJE - 030411 */
                    procParam[j].mandatFlg = FALSE;
                    pTemp = (char*) CALLOC(strlen(sqlName) + 2, sizeof(char)); /* REF7264 - PMO */ /* DLA - REF8728 */
                    strcpy(pTemp, "@"); /* DLA - REF8728 */
                    strcat(pTemp, sqlName); /* DLA - REF8728 */
                    procParam[j].paramName = pTemp; /* DLA - REF8728 */
                    j++;
                }
            }
        }
        else
        {
            for(i = 0, j = 0; i < GET_FLD_NBR(inputSt); i++)
            {
                if (SYB_ConvApplToSybType(GET_FLD_TYPE(inputSt, i)) != CS_ILLEGAL_TYPE)
                {
                    sqlName = DBA_GetDictAttribSqlName(object, i);

                    if ((sqlName != NULL) && (sqlName[0] != 0x00))
                    {
                        char * pTemp; /* DLA - REF8728 */
                        procParam[j].fldNbrPtr = (FIELD_IDX_T*)CALLOC(1, sizeof(FIELD_IDX_T)); /* REF8844 - LJE - 030414 */
                        *(procParam[j].fldNbrPtr)    = i; /* REF8844 - LJE - 030411 */
                        procParam[j].mandatFlg = FALSE;
                        pTemp = (char*) CALLOC(strlen(sqlName) + 2, sizeof(char)); /* REF7264 - PMO */  /* DLA - REF8728 */
                        strcpy(pTemp, "@"); /* DLA - REF8728 */
                        strcat(pTemp, sqlName); /* DLA - REF8728 */
                        procParam[j].paramName = pTemp; /* DLA - REF8728 */
                        j++;
                    }
                }
            }
        }

        pTemp2 = (char *)CALLOC(1, sizeof(char)); /* REF7264 - LJE - 020205 */ /* DLA - REF8728 */
        pTemp2[0] = END_OF_STRING; /* DLA - REF8728 */
        procParam[j].paramName = pTemp2; /* DLA - REF8728 */

        procedure->procParamDefPtr = procParam;
    }
    else
    {
        procParam = procedure->procParamDefPtr;
    }

    if (procParam != NULL)
    {
        /* Set all necessary arguments */
        while (procParam[paramIndex].paramName != NULL &&
               procParam[paramIndex].paramName[0] != END_OF_STRING)
        {
            if(TRACE_PARAM)
            {
                if (procedure->server == SqlServer)
                {
                    /* REF10195 - LJE - 040408 */
                    SYB_WriteInSqlTrace(&sqlTraceStr,
                                        2 + SYS_StrLen(procParam[paramIndex].paramName),
                                        "%c%s=",
                                        (paramIndex)?',':' ',
                                        procParam[paramIndex].paramName);
                }
                else
                {
                    /* REF10195 - LJE - 040408 */
                    SYB_WriteInSqlTrace(&sqlTraceStr, 1, "%c",(paramIndex)?',':' ');
                }
            }

		    /* PMSTA-36323 - Prajin - 190621. Clear the Data Format Structure for each Parameter.*/
		    memset(&csDataFmt, 0, sizeof(CS_DATAFMT));
		    csDataFmt.namelen = CS_NULLTERM;

            /* Get parameter name for the current field in the Meta Dictionary */
            strcpy(csDataFmt.name, procParam[paramIndex].paramName);

            fieldType = GET_FLD_TYPE(inputSt, *(procParam[paramIndex].fldNbrPtr));

            if (procParam[paramIndex].procParamTypeEn == ProcParamType_Output) /* DLA - PMSTA08801 - 101207 */
                csDataFmt.status = CS_RETURN;
            else
                csDataFmt.status = CS_INPUTVALUE; /* PMSTA08801 - DDV - 091211 - Moved into the loop to set correctly output parameters */

            /* Convert Application datatype in Sybase datatype */
            csDataFmt.datatype = SYB_ServConvApplToSybType(fieldType);

            if (csDataFmt.status == CS_RETURN && (csDataFmt.datatype == CS_CHAR_TYPE || csDataFmt.datatype == CS_LONGCHAR_TYPE || csDataFmt.datatype == CS_TEXT_TYPE))
            {
                if (procParam[paramIndex].mandatFlg == TRUE) 
                {
                    std::stringstream msg;
                    msg << "IN-OUT parameter for char/text type not well managed on Sybase 16.SP04.PL03+."
                        << " Return length is truncated to length of the IN parameter when not- null."
                        << " Avoid by setting Output paramter to optional, input NULL for parameter, and only initiatlize / assign in the stored procedure.";
                    MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "SYB_SetProcParameters", msg.str().c_str());

                    SYS_BreakOnDebug();
                }
            }

            if (IS_NULLFLD(inputData, *(procParam[paramIndex].fldNbrPtr)) == TRUE &&
                IS_FLAGFLD(inputSt, *(procParam[paramIndex].fldNbrPtr)) == TRUE)
            {
                SET_FLAG(inputData, *(procParam[paramIndex].fldNbrPtr), 0);
            }

            /* If the current field has a NULL value */
            if (IS_NULLFLD(inputData, *(procParam[paramIndex].fldNbrPtr)) == TRUE)
            {
                /*
                 * We are going to call a RPC with parameters of type CS_TEXT_TYPE.
                 * Such parameter type is not allowed for using with RPC.
                 * This is why we replace it by CS_LONGCHAR_TYPE. REF4204.
                 */

                if ((csDataFmt.datatype == CS_TEXT_TYPE) && (procedure->server == FinServer || procedure->server == DispatchServer))
                {
                    csDataFmt.datatype = CS_LONGCHAR_TYPE;
                }

                /* DLA - PMSTA08801 - 101207 */
                csDataFmt.precision = SYB_GetSybasePrecisionForDataType(fieldType);
                csDataFmt.scale     = SYB_GetSybaseScaleForDataType(fieldType);

                /* -1 means that the field is NULL */
                if ((csRet = SYB_CtParam(dbiConn, &csDataFmt, NULL, 0, -1)) != CS_SUCCEED)   /* REF3847 */
                {
                    /* REF10195 - LJE - 040407 */
                    SYB_SendSqlTrace(&sqlTraceStr);
                    FREE(buf);                      /*  FIH-REF11396-050906 */
                    return(RET_DBA_ERR_SETPARAM);
                }

                if (TRACE_PARAM)
                {
                    SYB_WriteInSqlTrace(&sqlTraceStr, -1, "NULL"); /* REF10195 - LJE - 040408 */
                }
            }
            else
            {
                /* WARNING : this function SHOULD always return TRUE */
                if (procParam[paramIndex].procParamTypeEn != ProcParamType_Input_NoCheck && /* PMSTA14466-CHU-120614 */
                    SYB_CheckFieldCoherence(inputData, *(procParam[paramIndex].fldNbrPtr), fieldType) != TRUE)
                {
                    csRet = SYB_CtParam(dbiConn, &csDataFmt, NULL, 0, -1);  /* REF3847 */

                    MSG_SendMesg(RET_DBA_ERR_SETPARAM, 1, FILEINFO, csDataFmt.name, procedure->procName);

                    ++paramIndex;
                    continue;
                }

                csDataFmt.precision = 18;
                csDataFmt.scale = 0;

                switch (csDataFmt.datatype)
                {
                    case CS_DATETIME_TYPE:
                    case CS_DATETIME4_TYPE:
                        /* Compose the Sybase reference date (1 jan 1900) */
                        refDate = DATE_Put((YEAR_T)1900, (MONTH_T)1, (DAY_T)1);

                        thirdSecond = 0;
                        minutes = 0;

                        switch (fieldType)
                        {
                            case DateType:
                                DATE_DaysBetween(refDate, GET_DATE(inputData,
                                                                   *(procParam[paramIndex].fldNbrPtr)),
                                                 AccrRule_Actual_365, &daysNbr, 0);  /* PMSTA-22396  - SRIDHARA � 160430 */   /* PMSTA-15918 - 070213 - PMO */
                                break;

                        case DatetimeType:
                        {
                            DATETIME_ST datetimeSt = GET_DATETIME(inputData, *(procParam[paramIndex].fldNbrPtr));       /* ROI - 000930 - REF5274 */
                            DATE_DaysBetween(refDate, datetimeSt.date, AccrRule_Actual_365, &daysNbr, 0);        /* PMSTA-15918 - 070213 - PMO */  /* PMSTA-22396  - SRIDHARA � 160430 */
                            TIME_Get(datetimeSt.time, &hour, &min, &second);                                  /* PMSTA-15918 - 070213 - PMO */
                            thirdSecond = (INT_T)(hour * 3600 + min * 60 + second) * 300;
                        }
                        break;

                        default:
                            break;
                    }

                        switch (csDataFmt.datatype)
                        {
                            case CS_DATETIME_TYPE:
                                datetime.dtdays = daysNbr;
                                datetime.dttime = thirdSecond;

                                csRet = SYB_CtParam(dbiConn, &csDataFmt, &datetime, CS_UNUSED, CS_UNUSED); /* REF3847 */

                                if (TRACE_PARAM)
                                {
                                    DBI_FldToDbDataStr(buf, bufLen,
                                                       inputData,
                                                       *(procParam[paramIndex].fldNbrPtr), /* REF8844 - LJE - 030324 */
                                                       fieldType, UNUSED, true); /* PMSTA-42605 - DDV - 201124 - Traces must not impact data */

                                    SYB_WriteInSqlTrace(&sqlTraceStr, -1, buf); /* REF10195 - LJE - 040408 */
                                }
                                break;

                            case CS_DATETIME4_TYPE:
                                datetimeSmall.days = (unsigned short)daysNbr;
                                datetimeSmall.minutes = minutes;

                                /* REF3847 */
                                csRet = SYB_CtParam(dbiConn, &csDataFmt, &datetimeSmall, CS_UNUSED, CS_UNUSED);

                                if (TRACE_PARAM)
                                {
                                    DBI_FldToDbDataStr(buf, bufLen,
                                                       inputData,
                                                       *(procParam[paramIndex].fldNbrPtr),  /* REF8844 - LJE - 030324 */
                                                       fieldType, UNUSED, true); /* PMSTA-42605 - DDV - 201124 - Traces must not impact data */

                                    SYB_WriteInSqlTrace(&sqlTraceStr, -1, buf); /* REF10195 - LJE - 040408 */
                                }

                                break;

                            default:
                                csRet = CS_FAIL;
                        }
                        break;

                    case CS_NUMERIC_TYPE:
                        if (fieldType == IdType || fieldType == DictType) /* DLA - PSMTA08801 - 101229 */
                        {
                            ret = SYB_ConvertFldToNumericAndSetParam(dbiConn, fieldType,
                                                                            (double)inputData[*(procParam[paramIndex].fldNbrPtr)].data.longlongValue,  /* PMSTA08801 - DDV - 091126 */
                                                                            csDataFmt);
                        }
                        else
                        {
                            ret = SYB_ConvertFldToNumericAndSetParam(dbiConn, fieldType,
                                                                        (double)inputData[*(procParam[paramIndex].fldNbrPtr)].data.dbleValue,  /* PMSTA08801 - DDV - 091126 */
                                                                        csDataFmt);
                        }

                        if (TRACE_PARAM)
                        {
                            DBI_FldToDbDataStr(buf, bufLen,
                                                inputData,
                                                *(procParam[paramIndex].fldNbrPtr),
                                                fieldType, UNUSED, true); /* PMSTA-42605 - DDV - 201124 - Traces must not impact data */

                            SYB_WriteInSqlTrace(&sqlTraceStr, -1, buf); /* REF10195 - LJE - 040408 */
                        }
                        break;

                    case CS_TEXT_TYPE:     /* REF4204 */
                        /*
                            * We are going to call a RPC with parameters of type CS_TEXT_TYPE.
                            * Such parameter type is not allowed for using with RPC.
                            * This is why we replace it by CS_LONGCHAR_TYPE. REF4204.
                            */

                        if (dbiConn.getDescription().getType() == FinServer) /* DLA  PMSTA-22825 - 160317 */
                        {
                            csDataFmt.datatype = CS_LONGCHAR_TYPE;
                        }

                        if (GET_CTYPE(fieldType) == UniTextPtrCType)
                        {
                            char *html = (char *)CALLOC(1, sizeof(TEXT_T));

                            ICU4AAA_ConvertToHTML(
                                GET_UTEXT(inputData, *procParam[paramIndex].fldNbrPtr), -1,
                                html, sizeof(TEXT_T), NULL);

                            csRet = SYB_CtParam(dbiConn, &csDataFmt,
                                                    html,
                                                    SYS_StrLen(html),
                                                    CS_UNUSED);

                            if (TRACE_PARAM)
                            {
                                int capacity = GET_MAXLEN(fieldType) * 3 + 1;

                                char *string = (char*)CALLOC(1, capacity);

                                if (string != NULL)
                                {
                                    if (!ICU4AAA_ConvertToUTF8(
                                        inputData[*(procParam[paramIndex].fldNbrPtr)].data.ustrData.ptr,
                                        -1, string, capacity, NULL))
                                    {
                                        /* REF10195 - LJE - 040408 */
                                        SYB_WriteInSqlTrace(&sqlTraceStr, 2 + SYS_StrLen(string), "\"%s\"", string);
                                    }
                                    else
                                    {
                                        SYB_WriteInSqlTrace(&sqlTraceStr, -1, "\"N/A\""); /* REF10195 - LJE - 040408 */
                                    }

                                    FREE(string)
                                }
                                else
                                {
                                    SYB_WriteInSqlTrace(&sqlTraceStr, -1, "\"N/A\""); /* REF10195 - LJE - 040408 */
                                }
                            }

                            FREE(html);
                        }
                        else
                        {
                            csDataFmt.maxlength = GET_FLD_STRLEN(inputData, *(procParam[paramIndex].fldNbrPtr));
                            csRet = SYB_CtParam(dbiConn, &csDataFmt,
                                                    inputData[*(procParam[paramIndex].fldNbrPtr)].data.strData.ptr,
                                                    GET_FLD_STRLEN(inputData, *(procParam[paramIndex].fldNbrPtr)),
                                                    CS_UNUSED);

                            if (TRACE_PARAM)
                            {
                                DBI_FldToDbDataStr(buf, bufLen,
                                                    inputData,
                                                    *(procParam[paramIndex].fldNbrPtr), /* REF8844 - LJE - 030324 */
                                                    fieldType, UNUSED, true); /* PMSTA-42605 - DDV - 201124 - Traces must not impact data */

                                SYB_WriteInSqlTrace(&sqlTraceStr, -1, buf); /* REF10195 - LJE - 040408 */
                            }
                        }
                        break;

                    case CS_CHAR_TYPE: 
                    case CS_LONGCHAR_TYPE: /* DLA - PMSTA07121 - 090213 */
                        if ((inputSt == Fus_Arg) &&
                            ((*(procParam[paramIndex].fldNbrPtr) == Fus_Arg_PtfListId) ||
                            (*(procParam[paramIndex].fldNbrPtr) == Fus_Arg_PtfReqList))) /* Maguouille. */
                        {
                            csDataFmt.datatype = CS_LONGCHAR_TYPE;
                        }

                        if ((inputSt == Fusion_Status) &&
                            ((*(procParam[paramIndex].fldNbrPtr) == Fusion_Status_PtfListId) ||
                            (*(procParam[paramIndex].fldNbrPtr) == Fusion_Status_PtfStsList))) /* Maguouille. */
                        {
                            csDataFmt.datatype = CS_LONGCHAR_TYPE;
                        }

                        csRet = SYB_CtParam(dbiConn, &csDataFmt,            /* REF3847 */
                                                inputData[*(procParam[paramIndex].fldNbrPtr)].data.strData.ptr,
                                                GET_FLD_STRLEN(inputData, *(procParam[paramIndex].fldNbrPtr)),
                                                CS_UNUSED);

                        if (TRACE_PARAM)
                        {
                            /* REF10195 - LJE - 040408 */
                            SYB_WriteInSqlTrace(&sqlTraceStr,
                                                2 + SYS_StrLen(inputData[*(procParam[paramIndex].fldNbrPtr)].data.strData.ptr),
                                                "\"%s\"",
                                                inputData[*(procParam[paramIndex].fldNbrPtr)].data.strData.ptr);
                        }
                        break;

                    case CS_UNICHAR_TYPE:
                        csRet = SYB_CtParam(dbiConn, &csDataFmt,            /* REF3847 */
                                                inputData[*(procParam[paramIndex].fldNbrPtr)].data.ustrData.ptr,
                                                GET_FLD_USTRLEN(inputData, *(procParam[paramIndex].fldNbrPtr)) * 2,
                                                CS_UNUSED);

                        if (TRACE_PARAM)
                        {
                            int capacity = GET_MAXLEN(fieldType) * 3 + 1;

                            char *string = (char*)CALLOC(1, capacity);

                            if (string != NULL)
                            {
                                if (!ICU4AAA_ConvertToUTF8(
                                    inputData[*(procParam[paramIndex].fldNbrPtr)].data.ustrData.ptr,
                                    -1, string, capacity, NULL))
                                {
                                    /* REF10195 - LJE - 040408 */
                                    SYB_WriteInSqlTrace(&sqlTraceStr, 2 + SYS_StrLen(string), "\"%s\"", string);
                                }
                                else
                                {
                                    SYB_WriteInSqlTrace(&sqlTraceStr, -1, "\"N/A\""); /* REF10195 - LJE - 040408 */
                                }

                                FREE(string)
                            }
                            else
                            {
                                SYB_WriteInSqlTrace(&sqlTraceStr, -1, "\"N/A\""); /* REF10195 - LJE - 040408 */
                            }
                        }
                        break;

                    case CS_BINARY_TYPE:  /* REF11780 - 100406 - PMO */
                        CS_DATAFMT  csDataFmtSource;
                        CS_BINARY   sybaseTimeStamp[8];

                        memset(&csDataFmtSource, 0, sizeof(csDataFmtSource));
                        csDataFmtSource.datatype = CS_USER_TIMESTAMP;
                        csDataFmtSource.maxlength = sizeof(TIMESTAMP_T);
                        csDataFmtSource.status = csDataFmt.status | CS_DESCIN;

                        csDataFmt.precision = 0;
                        csDataFmt.scale = 0;
                        csDataFmt.maxlength = sizeof(TIMESTAMP_T);
                        csDataFmt.status |= CS_TIMESTAMP;

                        csRet = EV_rxaFctStruct.pfn_cs_convert(SYB_GetCsContext(),
                                                                    &csDataFmtSource,
                                                                    &(inputData[*(procParam[paramIndex].fldNbrPtr)].data.timeStampValue),
                                                                    &csDataFmt,
                                                                    &sybaseTimeStamp,
                                                                    NULL);

                        if (csRet != CS_SUCCEED)
                        {
                            return(RET_DBA_ERR_SETPARAM);
                        }

                        csRet = SYB_CtParam(dbiConn, &csDataFmt, &sybaseTimeStamp, sizeof(sybaseTimeStamp), CS_UNUSED);

                        if (TRACE_PARAM)
                        {
                            DBI_FldToDbDataStr(buf, bufLen,
                                                inputData,
                                                *(procParam[paramIndex].fldNbrPtr), /* REF8844 - LJE - 030324 */
                                                fieldType,
                                                UNUSED, true); /* PMSTA-42605 - DDV - 201124 - Traces must not impact data */
                            SYB_WriteInSqlTrace(&sqlTraceStr, -1, buf); /* REF10195 - LJE - 040408 */
                        }
                        break;

                    default:
                        tempLength = GET_FLD_MAXLEN(inputSt, *(procParam[paramIndex].fldNbrPtr));

                        csRet = SYB_CtParam(dbiConn, &csDataFmt,            /* REF3847 */
                                                &(inputData[*(procParam[paramIndex].fldNbrPtr)].data),
                                                (CS_INT)tempLength,
                                                CS_UNUSED);

                        if (TRACE_PARAM)
                        {
                            DBI_FldToDbDataStr(buf, bufLen,
                                                inputData,
                                                *(procParam[paramIndex].fldNbrPtr), /* REF8844 - LJE - 030324 */
                                                fieldType, UNUSED, true); /* PMSTA-42605 - DDV - 201124 - Traces must not impact data */

                            SYB_WriteInSqlTrace(&sqlTraceStr, -1, buf); /* REF10195 - LJE - 040408 */
                        }
                        break;
                }

                /* PMSTA-33082 - DDV - 190510 - Manage error code to avoid data insertion when overflow occurs */
                if (csRet != CS_SUCCEED || ret != RET_SUCCEED)
                {
                    /* REF10195 - LJE - 040407 */
                    SYB_SendSqlTrace(&sqlTraceStr);
                    FREE(buf);                      /*  FIH-REF11396-050906 */
                    return(RET_DBA_ERR_SETPARAM);
                }
            }

            ++paramIndex;
        }
    }

    if(EV_ExtractFile)
    {
        fputs("\n", EV_ExtractFile);
        fflush(EV_ExtractFile);
    }

    /* REF10195 - LJE - 040407 */
    SYB_SendSqlTrace(&sqlTraceStr);
    FREE(buf);                      /*  FIH-REF11396-050906 */
    return(RET_SUCCEED);
}

/************************************************************************
*   Function             : SYB_DefineCtParam()
*
*   Description          : Save the necessary parameters for the request
*                          in the CS_COMMAND structure
*
*   Arguments            : connectNo : the connection number
*                          inputst   : the object request
*                          inputData : the input arguments
*                          procedure : a pointer on the choosen procedure
*
*   Functions call       : None
*
*   Global var. modified : None
*
*   Return               : RET_SUCCEED            : if ok
*                          RET_DBA_ERR_ARGNOMATCH : if argument problem
*                          RET_DBA_ERR_SETPARAM   : if problem while binding fields
*
*       Cr�ation        : GRD - 981029 - REF2644.
*       Modif.          : ROI - 981102 - REF2644.
*                         GRD - 990929 - REF3847.
*                         GRD - 000203 - REF4204.
*                         REF4665 - SSO - 000503
*                         REF7320 - 020123 - PMO : Compilation warning with visual c++ in release mode
*                         REF7655 - 020624 - PMO : uninitialized structure
*                         REF11780 - 100406 - PMO : Implementation of the Sybase timestamp field
*                         PMSTA-15918 - 070213 - PMO : Fusion on portfolio [T_AI_PE_ST] failed ; upd_exd_position : Attempt to insert NULL value into column 'end_d', table position
*
*************************************************************************/
STATIC RET_CODE SYB_DefineCtParam(OBJECT_ENUM       object,
                  DBA_DYNST_ENUM    inputSt,
                  DBA_DYNFLD_STP    inputData,
                  DBA_PROC_STP      procedure,
                  SybConnection&    dbiConn,
                  char              *buf,
                  int               paramIndex,
                  int               *offsetIdx,
                  char              **sqlTraceStrPtr, /* REF10195 - LJE - 040408 */
                  FLAG_T            outputParamFlg) /* PMSTA08801 - DDV - 091210 */
{
    CS_DATAFMT        csDataFmt;
    CS_DATETIME       datetime;
    CS_DATETIME4      datetimeSmall;
    INT_T             thirdSecond;
    SMALLINT_T        minutes;
    DBA_DYNSTDEF_STP  inputArg=NULL;
    CS_RETCODE        retCode;
    long              daysNbr = 0;
    DATE_T            refDate;
    HOUR_T            hour;
    MINUTE_T          min;
    SECOND_T          second;
    DATATYPE_ENUM     fieldType;


    /* Init local variables */
    memset (&csDataFmt, 0, sizeof(csDataFmt));  /* REF7655 - PMO */

    if (outputParamFlg == TRUE) /* PMSTA08801 - DDV - 091210 */
        csDataFmt.status  = CS_RETURN;
    else
        csDataFmt.status  = CS_INPUTVALUE;

    csDataFmt.namelen = CS_NULLTERM;

    inputArg = GET_DYNSTDEFPTR(inputSt);

    DICT_ATTRIB_STP dictAttribStp = DBA_GetDictAttribSt(object, paramIndex);

    if (IS_DBFLD(inputSt, paramIndex) != TRUE || dictAttribStp->isPhysicalAttribute() == false) /* PMSTA-18593 - LJE - 150625 */
    {
        /* REF4665 - SSO - 000503: must shift offsetIdx also (arg not sent) */
        (*offsetIdx)++;
        return (RET_SUCCEED);
    }

    strcpy(csDataFmt.name, "@");
    strcat(csDataFmt.name, dictAttribStp->sqlName);

    if(TRACE_PARAM)
    {
        if (procedure->server == SqlServer)
        {
            /* REF10195 - LJE - 040408 */
            SYB_WriteInSqlTrace(sqlTraceStrPtr,
                                2 + SYS_StrLen(csDataFmt.name),
                                "%c%s=",(paramIndex != *offsetIdx)?',':' ',
                                csDataFmt.name);
        }
        else
        {
            /* REF10195 - LJE - 040408 */
            SYB_WriteInSqlTrace(sqlTraceStrPtr, 1, "%c",(paramIndex != *offsetIdx)?',':' ');
        }
    }

    fieldType = GET_FLD_TYPE(inputSt, paramIndex);
    csDataFmt.datatype = SYB_ConvApplToSybType(fieldType);

    /* PMSTA-24563 - LJE - 160908 */
    if ((csDataFmt.datatype == CS_TEXT_TYPE) && (procedure->server == FinServer || procedure->server == DispatchServer))
    {
        csDataFmt.datatype = CS_LONGCHAR_TYPE;
    }

    if (csDataFmt.datatype == CS_NUMERIC_TYPE)
    {
        if (IS_NULLFLD(inputData, paramIndex) == TRUE)
        {

            csDataFmt.precision = SYB_GetSybasePrecisionForDataType(fieldType);
            csDataFmt.scale = SYB_GetSybaseScaleForDataType(fieldType);

            retCode = SYB_CtParam(dbiConn, &csDataFmt, NULL, 0, -1);  /* REF3847 */

            if (retCode != CS_SUCCEED)
            {
                return(RET_DBA_ERR_SETPARAM);
            }

            if(TRACE_PARAM)
            {
                SYB_WriteInSqlTrace(sqlTraceStrPtr, -1, "NULL"); /* REF10195 - LJE - 040408 */
            }
        }
        else
        {
            if (fieldType == IdType || fieldType == DictType || fieldType == LongintType) /* DLA - PSMTA08801 - 101229 */
            {
                retCode = SYB_ConvertFldToNumericAndSetParam(dbiConn, fieldType,
                                 (double)inputData[paramIndex].data.longlongValue, csDataFmt);
            }
            else
            {
                retCode = SYB_ConvertFldToNumericAndSetParam(dbiConn, fieldType,
                                 inputData[paramIndex].data.dbleValue, csDataFmt);
            }

            if (retCode != CS_SUCCEED)
                return(RET_DBA_ERR_SETPARAM);

            if(TRACE_PARAM)
            {
                DBI_FldToDbDataStr(buf, sizeof(buf),
                            inputData,
                            paramIndex,  /* REF8844 - LJE - 030324 */
                            fieldType, UNUSED, true); /* PMSTA-42605 - DDV - 201124 - Traces must not impact data */
                SYB_WriteInSqlTrace(sqlTraceStrPtr, -1, buf); /* REF10195 - LJE - 040408 */
            }
        }

        return RET_SUCCEED;
    }
    else
    {
        csDataFmt.precision = 18;
        csDataFmt.scale = 0;
    }


    if (IS_FLAGFLD(inputSt, paramIndex) == TRUE && IS_NULLFLD(inputData, paramIndex) == TRUE)
    {
        SET_FLAG(inputData, paramIndex,0);
    }

    /* If the current field has a NULL value */
    if (_IS_NULLFLD(inputData, paramIndex) == TRUE) /* PMSTA13244 - DDV - 120123 - Trace DynFld usage */
    {
        /* REF9770 - LJE - 040123 */
        if(TRACE_PARAM)
        {
            SYB_WriteInSqlTrace(sqlTraceStrPtr, -1, "NULL"); /* REF10195 - LJE - 040408 */
        }

        retCode = SYB_CtParam(dbiConn, &csDataFmt, NULL, 0, -1);  /* REF3847 */

        if (retCode != CS_SUCCEED)
        {
            return(RET_DBA_ERR_SETPARAM);
        }

    }
    else
    {
        switch (csDataFmt.datatype)
        {
           case CS_DATETIME_TYPE:
           case CS_DATETIME4_TYPE:
            /* Compose the Sybase reference date (1 jan 1900) */
            refDate = DATE_Put((YEAR_T)1900, (MONTH_T)1, (DAY_T)1);

            thirdSecond = 0;
            minutes = 0;

            switch (fieldType)
            {
            case DateType:
                DATE_DaysBetween(refDate, GET_DATE(inputData, paramIndex), AccrRule_Actual_365, &daysNbr, 0);      /* PMSTA-15918 - 070213 - PMO */  /* PMSTA-22396  - SRIDHARA � 160430 */
                break;

            case DatetimeType:
            {
                DATETIME_ST datetimeSt = GET_DATETIME(inputData, paramIndex);   /* ROI - 000930 - REF5274 */
                DATE_DaysBetween(refDate, datetimeSt.date, AccrRule_Actual_365, &daysNbr, 0);                    /* PMSTA-15918 - 070213 - PMO */  /* PMSTA-22396  - SRIDHARA � 160430 */
                TIME_Get(datetimeSt.time, &hour, &min, &second);                                              /* PMSTA-15918 - 070213 - PMO */
                thirdSecond = (INT_T)(hour * 3600 + min * 60 + second) * 300;
            }
            break;

            default:
                break;
            }

            if (csDataFmt.datatype == CS_DATETIME_TYPE)
            {
                datetime.dtdays = daysNbr;
                datetime.dttime = thirdSecond;

                retCode = SYB_CtParam(dbiConn, &csDataFmt, &datetime, CS_UNUSED, CS_UNUSED); /* REF3847 */

                if(TRACE_PARAM)
                {
                    DBI_FldToDbDataStr(buf, sizeof(buf),
                                        inputData,
                                        paramIndex, /* REF8844 - LJE - 030324 */
                                        fieldType, UNUSED, true); /* PMSTA-42605 - DDV - 201124 - Traces must not impact data */
                    SYB_WriteInSqlTrace(sqlTraceStrPtr, -1, buf); /* REF10195 - LJE - 040408 */
                }
            }
            else
            {    /* Short date case */
                datetimeSmall.days = (unsigned short) daysNbr;
                datetimeSmall.minutes = minutes;

                retCode = SYB_CtParam(dbiConn, &csDataFmt, &datetimeSmall, CS_UNUSED, CS_UNUSED); /* REF3847 */

                if(TRACE_PARAM)
                {
                    DBI_FldToDbDataStr(buf, sizeof(buf),
                                        inputData,
                                        paramIndex, /* REF8844 - LJE - 030324 */
                                        fieldType, UNUSED, true); /* PMSTA-42605 - DDV - 201124 - Traces must not impact data */
                    SYB_WriteInSqlTrace(sqlTraceStrPtr, -1, buf); /* REF10195 - LJE - 040408 */
                }
            }

            break;

           case CS_CHAR_TYPE:
           case CS_LONGCHAR_TYPE: /* DLA - PMSTA07121 - 090213 */
           case CS_TEXT_TYPE:
               csDataFmt.maxlength = GET_FLD_STRLEN(inputData, paramIndex);
               retCode = SYB_CtParam(dbiConn, &csDataFmt, inputData[paramIndex].data.strData.ptr,
                          GET_FLD_STRLEN(inputData, paramIndex),
                          CS_UNUSED);               /* REF3847 */

            if(TRACE_PARAM)
            {
                /* REF10195 - LJE - 040408 */
                SYB_WriteInSqlTrace(sqlTraceStrPtr,
                    2 + SYS_StrLen(inputData[paramIndex].data.strData.ptr),
                    "\"%s\"",
                    inputData[paramIndex].data.strData.ptr);
            }

            break;

           case CS_UNICHAR_TYPE:
           case CS_UNITEXT_TYPE:
               csDataFmt.maxlength = GET_FLD_USTRLEN(inputData, paramIndex) * 2;
               retCode = SYB_CtParam(dbiConn, &csDataFmt, inputData[paramIndex].data.strData.ptr,
                          GET_FLD_USTRLEN(inputData, paramIndex) * 2,
                          CS_UNUSED);               /* REF3847 */

            if(TRACE_PARAM)
            {
                int capacity = GET_MAXLEN(fieldType) * 3 + 1;

                char *string = (char*)CALLOC(1, capacity);

                if (string != NULL)
                {
                    if (!ICU4AAA_ConvertToUTF8(
                                inputData[paramIndex].data.ustrData.ptr,
                                    -1, string, capacity, NULL))
                    {
                        /* REF10195 - LJE - 040408 */
                        SYB_WriteInSqlTrace(sqlTraceStrPtr, 2 + SYS_StrLen(string), "\"%s\"", string);
                    }
                    else
                    {
                        /* REF10195 - LJE - 040408 */
                        SYB_WriteInSqlTrace(sqlTraceStrPtr, -1, "\"N/A\"");
                    }

                    FREE(string)
                }
                else
                {
                    /* REF10195 - LJE - 040408 */
                    SYB_WriteInSqlTrace(sqlTraceStrPtr, -1, "\"N/A\"");
                }
            }

            break;

            case CS_BINARY_TYPE:  /* REF11780 - 100406 - PMO */
            {
                CS_DATAFMT  csDataFmtSource;
                CS_BINARY   sybaseTimeStamp[8];

                memset(&csDataFmtSource, 0, sizeof(csDataFmtSource));
                csDataFmtSource.datatype  = CS_USER_TIMESTAMP;
                csDataFmtSource.maxlength = sizeof(TIMESTAMP_T);
                csDataFmtSource.status    = csDataFmt.status | CS_DESCIN;

                csDataFmt.precision = 0;
                csDataFmt.scale     = 0;
                csDataFmt.maxlength = sizeof(TIMESTAMP_T);
                csDataFmt.status    |= CS_TIMESTAMP;

                retCode = EV_rxaFctStruct.pfn_cs_convert(SYB_GetCsContext(),
                                     &csDataFmtSource,
                                     &(inputData[paramIndex].data.timeStampValue),
                                     &csDataFmt,
                                     &sybaseTimeStamp,
                                     NULL);

                if (retCode != CS_SUCCEED)
                {
                    return(RET_DBA_ERR_SETPARAM);
                }

                retCode = SYB_CtParam(dbiConn, &csDataFmt, &sybaseTimeStamp, sizeof(sybaseTimeStamp), CS_UNUSED);

                if(TRACE_PARAM)
                {
                    DBI_FldToDbDataStr(buf, sizeof(buf),
                                        inputData,
                                        paramIndex, /* REF8844 - LJE - 030324 */
                                        fieldType,
                                        UNUSED, true); /* PMSTA-42605 - DDV - 201124 - Traces must not impact data */
                    SYB_WriteInSqlTrace(sqlTraceStrPtr, -1, buf); /* REF10195 - LJE - 040408 */
                }
            }
            break;

           default:
               retCode = SYB_CtParam(dbiConn, &csDataFmt, &(inputData[paramIndex].data),
                          sizeof(inputArg[paramIndex]), CS_UNUSED);     /* REF3847 */

            if(TRACE_PARAM)
            {
                DBI_FldToDbDataStr(buf, sizeof(buf),
                                    inputData,
                                    paramIndex, /* REF8844 - LJE - 030324 */
                                    fieldType, UNUSED, true); /* PMSTA-42605 - DDV - 201124 - Traces must not impact data */
                SYB_WriteInSqlTrace(sqlTraceStrPtr, -1, buf); /* REF10195 - LJE - 040408 */
            }
            break;
        }

    }

    if (retCode != CS_SUCCEED)
    {
        return(RET_DBA_ERR_SETPARAM);
    }

    return (RET_SUCCEED);
}



/************************************************************************
*   Function             : SYB_DefineCtParam()
*
*   Description          : Save the necessary parameters for the request
*                          in the CS_COMMAND structure
*
*   Arguments            : connectNo : the connection number
*                          inputst   : the object request
*                          inputData : the input arguments
*                          procedure : a pointer on the choosen procedure
*
*   Functions call       : None
*
*   Global var. modified : None
*
*   Return               : RET_SUCCEED            : if ok
*                          RET_DBA_ERR_ARGNOMATCH : if argument problem
*                          RET_DBA_ERR_SETPARAM   : if problem while binding fields
*
*
*************************************************************************/
RET_CODE SYB_DefineCtParam(SybConnection&     dbiConn,
                           DbiInOutData      *inputData,
                           const std::string &paramName,
                           bool               isOutputParam,
                           CS_DATAFMT        &csDataFmt,
                           bool               bFristParam,
                           char             **sqlTraceStrPtr)
{
    CS_DATETIME       datetime;
    CS_DATETIME4      datetimeSmall;
    INT_T             thirdSecond;
    SMALLINT_T        minutes;
    DBA_DYNSTDEF_STP  inputArg = NULL;
    CS_RETCODE        sybRetCode;
    long              daysNbr = 0;
    DATE_T            refDate;
    HOUR_T            hour;
    MINUTE_T          min;
    SECOND_T          second;
    DATATYPE_ENUM     fieldType;


    /* Init local variables */
    memset(&csDataFmt, 0, sizeof(csDataFmt));

    if (isOutputParam)
        csDataFmt.status = CS_RETURN;
    else
        csDataFmt.status = CS_INPUTVALUE;

    csDataFmt.namelen = CS_NULLTERM;

    strcpy(csDataFmt.name, paramName.c_str());

    if (TRACE_PARAM)
    {
        SYB_WriteInSqlTrace(sqlTraceStrPtr,
                            2 + SYS_StrLen(csDataFmt.name),
                            "%c%s=", bFristParam ? ' ' : ',',
                            csDataFmt.name);
    }

    fieldType = inputData->m_dataType;
    csDataFmt.datatype = SYB_ConvApplToSybType(fieldType);

    if ((csDataFmt.datatype == CS_TEXT_TYPE) && dbiConn.getDescription().getType() != SqlServer)
    {
        csDataFmt.datatype = CS_LONGCHAR_TYPE;
    }

    if (csDataFmt.datatype == CS_NUMERIC_TYPE)
    {
        if (inputData->isNull())
        {
            csDataFmt.precision = SYB_GetSybasePrecisionForDataType(fieldType);
            csDataFmt.scale = SYB_GetSybaseScaleForDataType(fieldType);

            sybRetCode = SYB_CtParam(dbiConn, &csDataFmt, NULL, 0, -1);  /* REF3847 */

            if (sybRetCode != CS_SUCCEED)
            {
                return(RET_DBA_ERR_SETPARAM);
            }

            if (TRACE_PARAM)
            {
                SYB_WriteInSqlTrace(sqlTraceStrPtr, -1, "NULL"); /* REF10195 - LJE - 040408 */
            }
        }
        else
        {
            if (fieldType == IdType || fieldType == DictType || fieldType == LongintType) /* DLA - PSMTA08801 - 101229 */
            {
                sybRetCode = SYB_ConvertFldToNumericAndSetParam(dbiConn, fieldType,
                    (double)inputData->getDataPtr()->longlongValue, csDataFmt);
            }
            else
            {
                sybRetCode = SYB_ConvertFldToNumericAndSetParam(dbiConn, fieldType,
                                                                inputData->getDataPtr()->dbleValue, csDataFmt);
            }

            if (sybRetCode != RET_SUCCEED)
                return(RET_DBA_ERR_SETPARAM);

            if (TRACE_PARAM)
            {
                char buf[500];
                DBI_FldToDbDataStr(buf, sizeof(buf),
                                   inputData->getDynFldStp(),
                                   0,
                                   fieldType, UNUSED, true); /* PMSTA-42605 - DDV - 201124 - Traces must not impact data */
                SYB_WriteInSqlTrace(sqlTraceStrPtr, -1, buf);
            }
        }

        return RET_SUCCEED;
    }
    else
    {
        csDataFmt.precision = 18;
        csDataFmt.scale = 0;
    }


    if (fieldType == FlagType && inputData->isNull())
    {
        SET_FLAG_FALSE(inputData->getDynFldStp(), 0);
    }

    /* If the current field has a NULL value */
    if (inputData->isNull())
    {
        if (TRACE_PARAM)
        {
            SYB_WriteInSqlTrace(sqlTraceStrPtr, -1, "NULL");
        }

        sybRetCode = SYB_CtParam(dbiConn, &csDataFmt, NULL, 0, -1);

        if (sybRetCode != CS_SUCCEED)
        {
            return(RET_DBA_ERR_SETPARAM);
        }

    }
    else
    {
        switch (csDataFmt.datatype)
        {
            case CS_DATETIME_TYPE:
            case CS_DATETIME4_TYPE:
                /* Compose the Sybase reference date (1 jan 1900) */
                refDate = DATE_Put((YEAR_T)1900, (MONTH_T)1, (DAY_T)1);

                thirdSecond = 0;
                minutes = 0;

                switch (fieldType)
                {
                    case DateType:
                        DATE_DaysBetween(refDate, GET_DATE(inputData->getDynFldStp(), 0), AccrRule_Actual_365, &daysNbr, 0);
                        break;

                    case DatetimeType:
                    {
                        DATETIME_ST datetimeSt = GET_DATETIME(inputData->getDynFldStp(), 0);
                        DATE_DaysBetween(refDate, datetimeSt.date, AccrRule_Actual_365, &daysNbr, 0);
                        TIME_Get(datetimeSt.time, &hour, &min, &second);
                        thirdSecond = (INT_T)(hour * 3600 + min * 60 + second) * 300;
                    }
                    break;

                    default:
                        break;
                }

                if (csDataFmt.datatype == CS_DATETIME_TYPE)
                {
                    datetime.dtdays = daysNbr;
                    datetime.dttime = thirdSecond;

                    sybRetCode = SYB_CtParam(dbiConn, &csDataFmt, &datetime, CS_UNUSED, CS_UNUSED); /* REF3847 */

                    if (TRACE_PARAM)
                    {
                        char buf[500];
                        DBI_FldToDbDataStr(buf, sizeof(buf),
                                           inputData->getDynFldStp(),
                                           0, /* REF8844 - LJE - 030324 */
                                           fieldType, UNUSED, true); /* PMSTA-42605 - DDV - 201124 - Traces must not impact data */
                        SYB_WriteInSqlTrace(sqlTraceStrPtr, -1, buf); /* REF10195 - LJE - 040408 */
                    }
                }
                else
                {    /* Short date case */
                    datetimeSmall.days = (unsigned short)daysNbr;
                    datetimeSmall.minutes = minutes;

                    sybRetCode = SYB_CtParam(dbiConn, &csDataFmt, &datetimeSmall, CS_UNUSED, CS_UNUSED); /* REF3847 */

                    if (TRACE_PARAM)
                    {
                        char buf[500];
                        DBI_FldToDbDataStr(buf, sizeof(buf),
                                           inputData->getDynFldStp(),
                                           0, /* REF8844 - LJE - 030324 */
                                           fieldType, UNUSED, true); /* PMSTA-42605 - DDV - 201124 - Traces must not impact data */
                        SYB_WriteInSqlTrace(sqlTraceStrPtr, -1, buf); /* REF10195 - LJE - 040408 */
                    }
                }

                break;

            case CS_CHAR_TYPE:
            case CS_LONGCHAR_TYPE: /* DLA - PMSTA07121 - 090213 */
            case CS_TEXT_TYPE:
                csDataFmt.maxlength = GET_FLD_STRLEN(inputData->getDynFldStp(), 0);
                sybRetCode = SYB_CtParam(dbiConn, &csDataFmt, inputData->getDynFldStp()->data.strData.ptr,
                                         GET_FLD_STRLEN(inputData->getDynFldStp(), 0),
                                         CS_UNUSED);               /* REF3847 */

                if (TRACE_PARAM)
                {
                    /* REF10195 - LJE - 040408 */
                    SYB_WriteInSqlTrace(sqlTraceStrPtr,
                                        2 + SYS_StrLen(inputData->getDynFldStp()->data.strData.ptr),
                                        "\"%s\"",
                                        inputData->getDynFldStp()->data.strData.ptr);
                }

                break;

            case CS_UNICHAR_TYPE:
            case CS_UNITEXT_TYPE:
                csDataFmt.maxlength = GET_FLD_USTRLEN(inputData->getDynFldStp(), 0) * 2;
                sybRetCode = SYB_CtParam(dbiConn, &csDataFmt, inputData->getDynFldStp()->data.strData.ptr,
                                         GET_FLD_USTRLEN(inputData->getDynFldStp(), 0) * 2,
                                         CS_UNUSED);               /* REF3847 */

                if (TRACE_PARAM)
                {
                    int capacity = GET_MAXLEN(fieldType) * 3 + 1;

                    char *string = (char*)CALLOC(1, capacity);

                    if (string != NULL)
                    {
                        if (!ICU4AAA_ConvertToUTF8(
                            inputData->getDynFldStp()->data.ustrData.ptr,
                            -1, string, capacity, NULL))
                        {
                            /* REF10195 - LJE - 040408 */
                            SYB_WriteInSqlTrace(sqlTraceStrPtr, 2 + SYS_StrLen(string), "\"%s\"", string);
                        }
                        else
                        {
                            /* REF10195 - LJE - 040408 */
                            SYB_WriteInSqlTrace(sqlTraceStrPtr, -1, "\"N/A\"");
                        }

                        FREE(string)
                    }
                    else
                    {
                        /* REF10195 - LJE - 040408 */
                        SYB_WriteInSqlTrace(sqlTraceStrPtr, -1, "\"N/A\"");
                    }
                }

                break;

            case CS_BINARY_TYPE:  /* REF11780 - 100406 - PMO */
            {
                CS_DATAFMT  csDataFmtSource;
                CS_BINARY   sybaseTimeStamp[8];

                memset(&csDataFmtSource, 0, sizeof(csDataFmtSource));
                csDataFmtSource.datatype = CS_USER_TIMESTAMP;
                csDataFmtSource.maxlength = sizeof(TIMESTAMP_T);
                csDataFmtSource.status = csDataFmt.status | CS_DESCIN;

                csDataFmt.precision = 0;
                csDataFmt.scale = 0;
                csDataFmt.maxlength = sizeof(TIMESTAMP_T);
                csDataFmt.status |= CS_TIMESTAMP;

                sybRetCode = EV_rxaFctStruct.pfn_cs_convert(SYB_GetCsContext(),
                                                            &csDataFmtSource,
                                                            &(inputData->getDynFldStp()->data.timeStampValue),
                                                            &csDataFmt,
                                                            &sybaseTimeStamp,
                                                            NULL);

                if (sybRetCode != CS_SUCCEED)
                {
                    return(RET_DBA_ERR_SETPARAM);
                }

                sybRetCode = SYB_CtParam(dbiConn, &csDataFmt, &sybaseTimeStamp, sizeof(sybaseTimeStamp), CS_UNUSED);

                if (TRACE_PARAM)
                {
                    char buf[500];
                    DBI_FldToDbDataStr(buf, sizeof(buf),
                                       inputData->getDynFldStp(),
                                       0, /* REF8844 - LJE - 030324 */
                                       fieldType,
                                       UNUSED, true); /* PMSTA-42605 - DDV - 201124 - Traces must not impact data */
                    SYB_WriteInSqlTrace(sqlTraceStrPtr, -1, buf); /* REF10195 - LJE - 040408 */
                }
            }
            break;

            default:
                sybRetCode = SYB_CtParam(dbiConn, &csDataFmt, inputData->getDataPtr(), sizeof(inputArg[0]), CS_UNUSED);     /* REF3847 */

                if (TRACE_PARAM)
                {
                    char buf[500];
                    DBI_FldToDbDataStr(buf, sizeof(buf),
                                       inputData->getDynFldStp(),
                                       0, /* REF8844 - LJE - 030324 */
                                       fieldType, UNUSED, true); /* PMSTA-42605 - DDV - 201124 - Traces must not impact data */
                    SYB_WriteInSqlTrace(sqlTraceStrPtr, -1, buf); /* REF10195 - LJE - 040408 */
                }
                break;
        }

    }

    if (sybRetCode != CS_SUCCEED)
    {
        return(RET_DBA_ERR_SETPARAM);
    }

    return (RET_SUCCEED);
}

/************************************************************************
*   Function             : SYB_SetInsUpdParameters()
*
*   Description          : Save the necessary parameters for the request
*                          in the CS_COMMAND structure
*
*   Arguments            : connectNo : the connection number
*                          inputst   : the object request
*                          inputData : the input arguments
*                          procedure : a pointer on the choosen procedure
*
*   Functions call       : None
*
*   Global var. modified : None
*
*   Return               : RET_SUCCEED            : if ok
*                          RET_DBA_ERR_ARGNOMATCH : if argument problem
*                          RET_DBA_ERR_SETPARAM   : if problem while
*                                                   binding fields
*
*   Creation date        : Apr. 94  - PEC
*   Last Modif. Date     : 30.08.95 - PEC - Added RET_CODE
*   Modif.      :   GRD - 981029 - REF2644
*                   ROI - 981102 - REF2644
*                   GRD - 990929 - REF3847.
*                   REF9167 - 030603 - PMO : Audit trail difference between 3.50 and R4
*                   PMSTA-15918 - 070213 - PMO : Fusion on portfolio [T_AI_PE_ST] failed ; upd_exd_position : Attempt to insert NULL value into column 'end_d', table position
*
*************************************************************************/
RET_CODE SYB_SetInsUpdParameters(SybConnection &dbiConn,
                                 OBJECT_ENUM    object,
                                 DBA_DYNST_ENUM inputSt,
                                 DBA_DYNFLD_STP inputData,
                                 DBA_PROC_STP   procedure,
                                 char           udFlg)
{
    CS_DATAFMT        csDataFmt;
    int               cpt, paramIndex;
    int               retCode;
    char              buf[500];
    int               offsetIdx = 0, i;
    char              *sqlTraceStr=NULL; /* REF10195 - LJE - 040407 */
    FLAG_T            outputFlg=FALSE;


    dbiConn.startRequest(); /* PMSTA-nuodb - LJE - 190715 */

     /* Fill the CS_COMMAND with the request name */
	if (SYB_CtCommand(dbiConn, DBA_RPC, procedure->procName, &sqlTraceStr) != CS_SUCCEED)
    {
        return(RET_DBA_ERR_SETPARAM);
    }

    if(EV_ExtractFile)
    {
        EV_SetProcParametersFlg = TRUE;
        DATE_StopTimer(&EV_ExtractFileTimer, TIMER_MASK_GEN);

        fprintf(EV_ExtractFile,
            "%05d %5d.%03d %s %s ",
            ++EV_ExtractFileCpt,
            (int)EV_ExtractFileTimer.cumul.tv_sec,
            (int)EV_ExtractFileTimer.cumul.tv_usec/1000,
            (procedure->server == SqlServer)? "SQL":"FIN",
            procedure->procName);
    }

    csDataFmt.namelen = CS_NULLTERM;

    if(udFlg == FALSE)
    {
        offsetIdx = paramIndex = 0;
        cpt = DBA_GetFirstCustFld(object);
    }
    else
    {
        offsetIdx = paramIndex = DBA_GetFirstCustFld(object);
        cpt = GET_FLD_NBR(inputSt);
    }

    DBA_SetMagicDate(inputData, inputSt, object);

    /* Set all necessary arguments */
    while (paramIndex < cpt)
    {
        /* PMSTA08801 - DDV - 091210 - check if it is an output parameter */
        outputFlg=FALSE;
        i=0;
        while (procedure->procParamDefPtr != NULL &&
               procedure->procParamDefPtr[i].fldNbrPtr != UNUSED)
        {
            /* PMSTA-26252 - LJE - 170303 */
            if ((*(procedure->procParamDefPtr[i].fldNbrPtr) == paramIndex) ||
                (paramIndex == 0 && procedure->procParamDefPtr[i].fldNbrPtr == procedure->remapIdIdxPtr))
            {
                if (procedure->procParamDefPtr[i].procParamTypeEn == ProcParamType_Output)
                {
                    outputFlg = TRUE;
                    break;
                }
                else if (procedure->procParamDefPtr[i].procParamTypeEn == ProcParamType_Output_Indexed)
                {
                    outputFlg = TRUE;
                    COPY_DYNFLD(inputData, GET_DYNSTENUM(inputData), *(procedure->procParamDefPtr[i].outputFldNbrPtr), inputData, GET_DYNSTENUM(inputData), *procedure->procParamDefPtr[i].fldNbrPtr);
                    break;
                }
            }
            i++;
        }

        if ((retCode = SYB_DefineCtParam(object, inputSt, inputData, procedure, dbiConn, buf, paramIndex, &offsetIdx, &sqlTraceStr, outputFlg)) != RET_SUCCEED)
        {
            /* REF10195 - LJE - 040407 */
            SYB_SendSqlTrace(&sqlTraceStr);
            return(retCode);
        }
        paramIndex++;
    }


    if(EV_ExtractFile)
    {
        fputs("\n", EV_ExtractFile);
        fflush(EV_ExtractFile);
    }

    /* REF10195 - LJE - 040407 */
    SYB_SendSqlTrace(&sqlTraceStr);
    return(RET_SUCCEED);
}

/************************************************************************
*   Function             : SYB_SetRpcParameters()
*
*   Description          : Save the necessary parameters for the request
*                          in the CS_COMMAND structure
*
*   Arguments            :
*
*   Functions call       : None
*
*   Global var. modified : None
*
*   Return               : RET_SUCCEED            : if ok
*                          RET_DBA_ERR_ARGNOMATCH : if argument problem
*                          RET_DBA_ERR_SETPARAM   : if problem while
*                                                   binding fields
*
*   Creation date        : PMSTA-24564 - LJE - 170124
*   Last Modif. Date     :
*
*************************************************************************/
RET_CODE SYB_SetRpcParameters(SybConnection &dbiConn,
                              OBJECT_ENUM    object,
                              DBA_DYNST_ENUM inputSt,
                              DBA_DYNFLD_STP inputData,
                              DBA_PROC_STP   procedure)
{
    int               offsetIdx = 0;
    RET_CODE          retCode;
    char              *sqlTraceStr = NULL;
    FLAG_T            outputFlg = FALSE;
    char              buf[500];

    const RpcProperties &   rpcProperties = EV_RpcCollection.getRpcProperties(procedure->procName);
    DbiBindDataDef httpBindDataDef = rpcProperties.getMapBindDataDef(rpcProperties.getRequestDynStEnum());

    /* Fill the CS_COMMAND with the request name */
    if (SYB_CtCommand(dbiConn, DBA_RPC, rpcProperties.getRpcName().c_str(), &sqlTraceStr) != CS_SUCCEED)
    {
        return(RET_DBA_ERR_SETPARAM);
    }

    if (EV_ExtractFile)
    {
        EV_SetProcParametersFlg = TRUE;
        DATE_StopTimer(&EV_ExtractFileTimer, TIMER_MASK_GEN);

        fprintf(EV_ExtractFile,
                "%05d %5d.%03d %s %s ",
                ++EV_ExtractFileCpt,
                (int)EV_ExtractFileTimer.cumul.tv_sec,
                (int)EV_ExtractFileTimer.cumul.tv_usec / 1000,
                (procedure->server == SqlServer) ? "SQL" : "FIN",
                procedure->procName);
    }

    DBA_SetMagicDate(inputData, inputSt, object);

    for (auto it = httpBindDataDef.bindData.begin(); it != httpBindDataDef.bindData.end(); it++)
    {
        if ((retCode = SYB_DefineCtParam(object, inputSt, inputData, procedure, dbiConn, buf, it->second.m_columnNbr, &offsetIdx, &sqlTraceStr, outputFlg)) != RET_SUCCEED)
        {
            SYB_SendSqlTrace(&sqlTraceStr);
            return(retCode);
        }
    }

    if (EV_ExtractFile)
    {
        fputs("\n", EV_ExtractFile);
        fflush(EV_ExtractFile);
    }

    SYB_SendSqlTrace(&sqlTraceStr);
    return(RET_SUCCEED);
}

/************************************************************************
*   Function             : SYB_GetSybasePrecisionForDataType()
*
*   Description          : Get the Sybase precision based on datatype
*
*   Arguments            : fieldType : the application field type
*
*   Functions call       : None
*
*   Global var. modified : None
*
*   Return               : The Sybase type
*
*   Modif                : DDV - PMSTA08801 - 091210
*
*************************************************************************/
CS_INT SYB_GetSybasePrecisionForDataType(DATATYPE_ENUM fieldType)
{
    return(GET_MAXLEN(fieldType));
}

/************************************************************************
*   Function             : SYB_GetSybaseScaleForDataType()
*
*   Description          : Get the Sybase scale based on datatype
*
*   Arguments            : fieldType : the application field type
*
*   Functions call       : None
*
*   Global var. modified : None
*
*   Return               : The Sybase type
*
*   Modif                : DDV - PMSTA08801 - 091210
*
*************************************************************************/
CS_INT SYB_GetSybaseScaleForDataType(DATATYPE_ENUM fieldType)
{
    return(GET_DECIMAL(fieldType));
}

/************************************************************************
*   Function             : SYB_ConvApplToSybType()
*
*   Description          : Convert an application TYPE to a Sybase TYPE
*                          Used to load data coming from SQL Server or
*                          put data going to SQL Server.
*
*   Arguments            : fieldType : the application field type
*
*   Functions call       : None
*
*   Global var. modified : None
*
*   Return               : The Sybase type
*
*   Modif                : GRD - 000203 - REF4204.
*                          REF11780 - 100406 - PMO : Implementation of the Sybase timestamp field
*
*************************************************************************/
EXTERN CS_INT SYB_ConvApplToSybType(DATATYPE_ENUM fieldType)
{
    CTYPE_ENUM applCType;

    switch (fieldType)
    {
        case EnumMaskType : /* PMSTA13640 - DDV - 120510 */
        case LongintType:   /* PMSTA-20887 - LJE - 150909 */
            return(CS_BIGINT_TYPE);

        case DateType :
        case DatetimeType :
            return(CS_DATETIME_TYPE);

        case String1000Type:            /* DLA - PMSTA-11860 - 110520 */
        case String2000Type:
        case String3000Type:
        case String4000Type:
        case String7000Type:
        case String15000Type:
            return(CS_LONGCHAR_TYPE);
            break;

        /* PMSTA-14001 - DDV - 120420 - Treat VarString type correctly */
        case VarString1000Type:
        case VarString2000Type:
        case VarString3000Type:
        case VarString4000Type:
        case VarString7000Type:
        case VarString15000Type:

            if (ICU4AAA_SQLServerUTF8)
                return(CS_UNICHAR_TYPE);
            else
                return(CS_LONGCHAR_TYPE);
            break;

        case BlobType:
            return (CS_IMAGE_TYPE);

        default:
            break;
    }

    applCType = GET_CTYPE(fieldType);

    switch (applCType)
    {
        case DoubleCType :
            return(CS_NUMERIC_TYPE);

        case CharPtrCType :
            return(CS_CHAR_TYPE);

        case IntCType :
        case UIntCType :
            return(CS_INT_TYPE);

        case ShortCType :
        case UShortCType :
            return(CS_SMALLINT_TYPE);

        case UCharCType :
            return(CS_TINYINT_TYPE);

        case UniTextPtrCType :
        case TextPtrCType :
            return(CS_TEXT_TYPE);       /* REF4204 */

        case UniCharPtrCType :
            return(CS_UNICHAR_TYPE);

        case LongLongCType : /* PMSTA08801 - DDV - 091126 */
            return(CS_NUMERIC_TYPE); /* DLA - REF9089 - 030806 */

        case TimeStampCType :   /* REF11780 - 100406 - PMO */
            return(CS_BINARY_TYPE);

        case BinaryCType :   /* DLA - PMSTA05995 - 080410 */
            return(CS_BINARY_TYPE);

        default:
            break;
    }

    return(CS_ILLEGAL_TYPE);
}

/************************************************************************
*   Function             : SYB_ServConvApplToSybType()
*
*   Description          :
*
*   Arguments            : fieldType : the application field type
*
*   Functions call       : None
*
*   Global var. modified : None
*
*   Return               : The Sybase type
*
*   Modif                : REF11780 - 100406 - PMO : Implementation of the Sybase timestamp field
*
*************************************************************************/
CS_INT SYB_ServConvApplToSybType(DATATYPE_ENUM fieldType)
{
    CTYPE_ENUM applCType;

    switch (fieldType)
    {
        case DateType :
        case DatetimeType :
            return(CS_DATETIME_TYPE);
        case IdType:
        case DictType:
            return(CS_NUMERIC_TYPE); /* not BIGINT ? 8801 */
/*          return(CS_INT_TYPE);  Problem of fusion server ?!??!?!? */
        case FlagType:
            return(CS_TINYINT_TYPE);

        case String1000Type:        /* DLA - PMSTA-11860 - 110520 */
        case String2000Type:
        case String3000Type:
        case String4000Type:
        case String7000Type:
        case String15000Type:
        case VarString1000Type:
        case VarString2000Type:
        case VarString3000Type:
        case VarString4000Type:
        case VarString7000Type:
        case VarString15000Type:
            return(CS_LONGCHAR_TYPE);

        default:
            break;
    }

    applCType = GET_CTYPE(fieldType);

    switch (applCType)
    {
        case DoubleCType :
            return(CS_NUMERIC_TYPE);

        case CharPtrCType :
            return(CS_CHAR_TYPE);

        case IntCType :
        case UIntCType :
            return(CS_INT_TYPE);

        case ShortCType :
        case UShortCType :
            return(CS_SMALLINT_TYPE);

        case UCharCType :
            return(CS_TINYINT_TYPE);

        case UniTextPtrCType :
        case TextPtrCType :
            if ((SYS_IsGuiMode() == TRUE) || (SYS_IsBatchMode() == TRUE))
                return(CS_TEXT_TYPE);
            else
                return(CS_LONGCHAR_TYPE);

        case UniCharPtrCType :
            return(CS_UNICHAR_TYPE);

        case LongLongCType : /* PMSTA08801 - DDV - 091126 */
            return(CS_BIGINT_TYPE); /* DLA - REF9089 - 030806 *//* PMSTA08801 - DDV - 091126 */

        case TimeStampCType :   /* REF11780 - 100406 - PMO */
            return(CS_BINARY_TYPE);

        case BinaryCType :   /* DLA - PMSTA05995 - 080410 */
            return(CS_BINARY_TYPE);

        default:
            break;
    }

    return(CS_ILLEGAL_TYPE);
}

/************************************************************************
*   Function             : SYB_GetSybTypeByCType()
*
*   Description          : Convert a C Type (int, short,...)to a Sybase TYPE
*                          (a #define value).
*                          Used to pass data between Open Server and client
*
*   Arguments            : fieldType : the application field type
*
*   Functions call       : None
*
*   Global var. modified : None
*
*   Return               : The Sybase type
*
*   Modif                : GRD - 000203 - REF4204.
*                          REF11780 - 100406 - PMO : Implementation of the Sybase timestamp field
*************************************************************************/
CS_INT SYB_GetSybTypeByCType(DATATYPE_ENUM fieldType)
{
    CTYPE_ENUM applCType;

    switch (fieldType)
    {
        case DateType:
        case DatetimeType :
            return(CS_DATETIME_TYPE);

        case    String1000Type:
        case    String2000Type:
        case    String3000Type:
        case    String4000Type:
        case    String7000Type:
        case    String15000Type:
        /*case    UniString1000Type: PMSTA-14001 - DDV - 120420 - CS_UNICHAR_TYPE must be used for all unicode datatype
        case    UniString2000Type:
        case    UniString3000Type:
        case    UniString4000Type:
        case    UniString7000Type:
        case    UniString15000Type:*/
            return(CS_LONGCHAR_TYPE);

        default:
            break;
    }

    applCType = GET_CTYPE(fieldType);

    switch (applCType)
    {
        case DoubleCType :
            return(CS_FLOAT_TYPE);

        case CharPtrCType :
            return(CS_CHAR_TYPE);

        case IntCType :
        case UIntCType :
            return(CS_INT_TYPE);

        case ShortCType :
        case UShortCType :
            return(CS_SMALLINT_TYPE);

        case UCharCType :
            return(CS_TINYINT_TYPE);

        case UniTextPtrCType :
        case TextPtrCType :
            return(CS_TEXT_TYPE);       /* REF4204 */

        case UniCharPtrCType :
            return(CS_UNICHAR_TYPE);

        case LongLongCType : /* PMSTA08801 - DDV - 091126 */
            return(CS_BIGINT_TYPE); /* DLA - REF9089 - 030806 */

        case TimeStampCType :   /* REF11780 - 100406 - PMO */
            return(CS_BINARY_TYPE);

        default:
            break;
    }

    return(CS_ILLEGAL_TYPE);
}

/************************************************************************
*   Function             : SYB_CheckFieldCoherence()
*
*   Description          : Check the field coherence.
*
*   Arguments            : inputData : a dynamic structure pointer
*                          fldNbr    : field number of interest in
*                                      the dynamic structure
*                          fldType   : the field datatype (AmountType,..)
*
*   Functions call       : None
*
*   Global var. modified : None
*
*   Return               : TRUE
*                          FALSE if problem in sending request
*************************************************************************/
int SYB_CheckFieldCoherence(DBA_DYNFLD_STP inputData, int fldNbr, DATATYPE_ENUM fldType)
{
    DATE_T       date;

    if (!inputData)
        return(FALSE);

    switch(fldType)
    {
    case IdType:
        {
        ID_T id;

        id = GET_ID(inputData, fldNbr);
        if (id <= 0)
            return(FALSE);
        return(TRUE);
        }

    case DateType:
        date = GET_DATE(inputData, fldNbr);
        if (date == 0)
            return(FALSE);
        return(TRUE);

    case DatetimeType:
        if (GET_DATETIMEST(inputData, fldNbr).date() == 0)
            return(FALSE);
        return(TRUE);

    default:
        break;
    }

    return(TRUE);
}

/************************************************************************
*   Function             : SYB_SendLangRequest()
*
*   Description          : Send a Language request to the server and retrieve the
*                          result type
*
*   Arguments            : connectNo : a connection number
*                          reqString : the request string
*                          resType   : the type of result returned
*
*   Functions call       : None
*
*   Global var. modified : None
*
*   Return               : RET_SUCCEED           : if ok
*                          RET_GEN_ERR_INVARG    : if problem with arguments
*                          RET_DBA_ERR_DBPROBLEM : if problem with connection/database
*
*   Creation Date        : 21.05.96 - PEC - Ref.: DVP061
*************************************************************************/
RET_CODE SYB_SendLangRequest(SybConnection& dbiConn, const char *reqString, int *resType)
{
    CS_INT          resultType;
    CS_RETCODE      retCode;

	if (SYB_CtCommand(dbiConn, DBA_LANG, reqString, NULL) != CS_SUCCEED)
    {
        return(RET_DBA_ERR_DBPROBLEM);
    }

    /* Send the command to the server */
	retCode = SYB_CtSend(dbiConn);

    if (retCode != CS_SUCCEED && retCode != CS_PENDING)
    {
		if (!dbiConn.isValid()) {
			return(RET_DBA_ERR_DBPROBLEM);
		}
        return(FALSE);
    }

	retCode = SYB_CtResults(dbiConn, &resultType);

    if (dbiConn.isValid() == false)
    {
        return(RET_DBA_ERR_DBPROBLEM);
    }


    /* MEMORIZE RETCODE AND RESULT TYPE IN THE CONNECTION STRUCTURE */
	dbiConn.m_lastResultRetCode = dbiConn.convertToRetCode(retCode);
	dbiConn.m_lastResultType    = resultType;

    *resType = resultType;

    if (retCode != CS_SUCCEED && retCode != CS_PENDING)
        return(RET_DBA_ERR_DBPROBLEM);

    return(RET_SUCCEED);
}

/************************************************************************
*   Function             : SYB_CtClose()
*
*   Description          :
*
*   Arguments            : connectNo   : a connection number
*                          closeOption : null or CS_FORCE_CLOSE.
*
*   Functions call       : None
*
*   Global var. modified : None
*
*   Return               : RET_CODE
*
*   Creation Date        : 27.09.99 - GRD - Ref.: REF3847.
*
*   Last modif.          : PMSTA-16124 - 250413 - PMO : Ensure coherence of printf / scanf formats with 32bits / 64 bits datatypes
*                          PMSTA-19735 - 020415 - PMO : OpenServer / P1 / Thread handling
*                          PMSTA-24981 - 151116 - PMO : pid: threadid: missing form trace
*
*************************************************************************/
RET_CODE SYB_CtClose(SybConnection& dbiConn, int closeOption)
{
    CS_RETCODE  sybRetCode  = CS_SUCCEED;

    if (dbiConn.m_connection != nullptr)
    {
        /* Is it valid close option? */
        if ((closeOption != CS_UNUSED) && (closeOption != CS_FORCE_CLOSE))
        {
            closeOption = CS_FORCE_CLOSE;
        }

        dbiConn.m_currentCmd = Syb_Command_Close; /* Keep trace of the current command. */

        if ((sybRetCode = EV_rxaFctStruct.pfn_ct_close(dbiConn.m_connection, closeOption)) != CS_SUCCEED)                    /* PMSTA-19735 - 020415 - PMO */
        {
            std::string errMsg;                                                                                                                                             /* PMSTA-24981 - 151116 - PMO */

            SYS_StringFormat(errMsg,
                             "Call to ct_close failed. Connection (" szFormatPointer "), Thread (%s), Close option (%s), Connection (%d), Status (%s)",                      /* PMSTA-16124 - 250413 - PMO */
                             (void*)dbiConn.m_connection, SYS_GetThreadDescriptionForLog().c_str(),                                        /* PMSTA-24981 - 151116 - PMO / PMSTA-16124 - 250413 - PMO */
                             (closeOption == CS_FORCE_CLOSE) ? "Force close" : "Null",
                             dbiConn.getId(),
                             dbiConn.getLabelRetCode(sybRetCode).c_str());                                                                                             /* PMSTA-24981 - 151116 - PMO */

            dbiConn.sendMsg(FILEINFO, errMsg);                                                                                                                        /* PMSTA-24981 - 151116 - PMO */
        }

        dbiConn.m_currentCmd = Syb_Command_None;

        /***** SQL TRACE *****/
        if (EV_sqlFile != NULL)
        {
            std::string errMsg;                                                                                                                                             /* PMSTA-24981 - 151116 - PMO */

            SYS_StringFormat(errMsg, "    ct_close()     Connect=%-9d Thread=%s Option=%-12.12s Status=%-12.12s",                                                            /* PMSTA-16124 - 250413 - PMO */
                             dbiConn.getId(), SYS_GetThreadDescriptionForLog().c_str(),                                                                                      /* PMSTA-24981 - 151116 - PMO */
                             (closeOption == CS_FORCE_CLOSE) ? "Forced" : "NULL",
                             dbiConn.getLabelRetCode(sybRetCode).c_str());                                                                                             /* PMSTA-24981 - 151116 - PMO */

            MSG_SendSqlTrace(errMsg);
        }
    }

    return sybRetCode != CS_SUCCEED ? sybRetCode : RET_SUCCEED;
}

/************************************************************************
*   Function             : SYB_CtConDrop()
*
*   Description          :
*
*   Arguments            : connectNo : a connection number
*
*   Functions call       : None
*
*   Global var. modified : None
*
*   Return               : RET_CODE
*
*   Creation Date        : 29.09.99 - GRD - Ref.: REF3847.
*
*   Last modif.          : PMSTA-16124 - 250413 - PMO : Ensure coherence of printf / scanf formats with 32bits / 64 bits datatypes
*                          PMSTA-24981 - 151116 - PMO : pid: threadid: missing form trace
*
*************************************************************************/
RET_CODE SYB_CtConDrop(SybConnection& dbiConn)
{
    CS_RETCODE      sybRetCode = CS_SUCCEED;
	CS_CONNECTION * connection = dbiConn.m_connection;

    /* Is it a valid connection? */
    if (connection == NULL)
    {
        if((SYS_IsGuiMode() == TRUE) || (SERVER_IS_INIT() == TRUE))
        {
            std::string errMsg;                                                                                                                                         /* PMSTA-24981 - 151116 - PMO */

            SYS_StringFormat(errMsg, "connection (" szFormatPointer "), Thread (%s)", (void*)connection, SYS_GetThreadDescriptionForLog().c_str());                     /* PMSTA-24981 - 151116 - PMO / PMSTA-16124 - 250413 - PMO */
            MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "SYB_CtConDrop", errMsg.c_str());
        }
        else
        {
            std::string errMsg;                                                                                                                                         /* PMSTA-24981 - 151116 - PMO */

            SYS_StringFormat(errMsg, "SYB_CtConDrop. Invalid argument. Connection (" szFormatPointer "), Thread (%s)",                                                  /* PMSTA-16124 - 250413 - PMO */
                (void*)connection, SYS_GetThreadDescriptionForLog().c_str());                                                                                           /* PMSTA-24981 - 151116 - PMO / PMSTA-16124 - 250413 - PMO */
            MSG_SendStrToLog(errMsg);
        }

        return(RET_GEN_ERR_INVARG);
    }

    dbiConn.m_currentCmd = Syb_Command_ConDrop; /* Keep trace of the current command. */

    if ((sybRetCode = EV_rxaFctStruct.pfn_ct_con_drop(connection)) != CS_SUCCEED)
    {
        std::string errMsg;                                                                                                                                             /* PMSTA-24981 - 151116 - PMO */

        SYS_StringFormat(errMsg, "Call to ct_con_drop failed. Connection (" szFormatPointer "), Thread (%s), Connection (%d),  Status (%s)",                            /* PMSTA-16124 - 250413 - PMO */
                        (void*)connection, SYS_GetThreadDescriptionForLog().c_str(), dbiConn.getId(),                                                                   /* PMSTA-24981 - 151116 - PMO / PMSTA-16124 - 250413 - PMO */
                         dbiConn.getLabelRetCode(sybRetCode).c_str());                                                                                             /* PMSTA-24981 - 151116 - PMO */

        dbiConn.sendMsg(FILEINFO, errMsg);                                                                                                                        /* PMSTA-24981 - 151116 - PMO */
    }

    dbiConn.m_connection = nullptr;
	dbiConn.m_currentCmd = Syb_Command_None;

    /***** SQL TRACE *****/
    if (EV_sqlFile != NULL)
    {
        std::string errMsg;                                                                                                                                             /* PMSTA-24981 - 151116 - PMO */

        SYS_StringFormat(errMsg,"    ct_con_drop()     Connect=%-9d Thread=%s Status=%-12.12s",                                                                         /* PMSTA-16124 - 250413 - PMO */
			            dbiConn.getId(), SYS_GetThreadDescriptionForLog().c_str(),                                                                                      /* PMSTA-24981 - 151116 - PMO */
                         dbiConn.getLabelRetCode(sybRetCode).c_str());                                                                                             /* PMSTA-24981 - 151116 - PMO */

        MSG_SendSqlTrace(errMsg);
    }

    return sybRetCode != CS_SUCCEED ? sybRetCode : RET_SUCCEED;
}

/************************************************************************
*   Function             : SYB_CtCmdDrop()
*
*   Description          :
*
*   Arguments            : connectNo : a connection number
*
*   Functions call       : None
*
*   Global var. modified : None
*
*   Return               : RET_CODE
*
*   Creation Date        : 29.09.99 - GRD - Ref.: REF3847.
*
*   Last modif.          : PMSTA-16124 - 250413 - PMO : Ensure coherence of printf / scanf formats with 32bits / 64 bits datatypes
*                          PMSTA-24981 - 151116 - PMO : pid: threadid: missing form trace
*
*************************************************************************/
RET_CODE SYB_CtCmdDrop(SybConnection & dbiConn)
{
    CS_RETCODE      sybRetCode  = CS_SUCCEED;
    CS_COMMAND *    csCommand   = dbiConn.m_command;

    if (csCommand != nullptr)
    {
        dbiConn.m_currentCmd = Syb_command_CmdDrop; /* Keep trace of the current command. */

        if ((sybRetCode = EV_rxaFctStruct.pfn_ct_cmd_drop(csCommand)) != CS_SUCCEED)
        {
            std::string errMsg;                                                                                                                                             /* PMSTA-24981 - 151116 - PMO */

            SYS_StringFormat(errMsg, "Call to ct_cmd_drop failed. Command (" szFormatPointer "), Thread (%s), Connection (%d), Status (%s)",                                /* PMSTA-16124 - 250413 - PMO */
                (void*)csCommand,                                                                                                                               /* PMSTA-16124 - 250413 - PMO */
                             SYS_GetThreadDescriptionForLog().c_str(),                                                                                                       /* PMSTA-24981 - 151116 - PMO */
                             dbiConn.getId(),
                             dbiConn.getLabelRetCode(sybRetCode).c_str());                                                                                             /* PMSTA-24981 - 151116 - PMO */

            dbiConn.sendMsg(FILEINFO, errMsg);                                                                                                                        /* PMSTA-24981 - 151116 - PMO */
        }
        dbiConn.m_command    = nullptr;
        dbiConn.m_currentCmd = Syb_Command_None;


        /***** SQL TRACE *****/
        if (EV_sqlFile != nullptr)
        {
            std::string errMsg;                                                                                                                                             /* PMSTA-24981 - 151116 - PMO */

            SYS_StringFormat(errMsg, "    ct_cmd_drop()     Connect=%-9d Thread=" szFormatPointer " Status=%-12.12s",                                                        /* PMSTA-16124 - 250413 - PMO */
                             dbiConn.getId(),
                             /*csCommand,  DLA - REF10747 - 041112 */
                             SYS_GetThreadDescriptionForLog().c_str(),                                                                                                       /* PMSTA-24981 - 151116 - PMO */
                             dbiConn.getLabelRetCode(sybRetCode).c_str());                                                                                             /* PMSTA-24981 - 151116 - PMO */

            MSG_SendSqlTrace(errMsg);
        }
    }
    return sybRetCode != CS_SUCCEED ? sybRetCode : RET_SUCCEED;
}

/************************************************************************
*   Function             : SYB_CtConProps()
*
*   Description          :
*
*   Arguments            : connectNo : a connection number
*
*   Functions call       : None
*
*   Global var. modified : None
*
*   Return               : RET_CODE
*
*   Creation Date        : 29.09.99 - GRD - Ref.: REF3847.
*
*   Last modif.          : PMSTA-16124 - 250413 - PMO : Ensure coherence of printf / scanf formats with 32bits / 64 bits datatypes
*                          PMSTA-16615 - 180713 - PMO : Bad keyword used into the sql trace
*                          PMSTA-21694 - 120516 - PMO : The stack trace is not available in msg on AIX
*                          PMSTA-24981 - 151116 - PMO : pid: threadid: missing form trace
*
*************************************************************************/
RET_CODE SYB_CtConProps(SybConnection& dbiConn, CS_INT action, CS_INT property, CS_VOID *buffer, CS_INT buflen, CS_INT *outlen)
{
    CS_RETCODE      sybRetCode   = CS_SUCCEED;
	CS_CONNECTION * csConnection = dbiConn.m_connection;

    if ((csConnection == NULL) || ((action != CS_SET) && (action != CS_GET) && (action != CS_CLEAR)))
    {
        if((SYS_IsGuiMode() == TRUE) || (SERVER_IS_INIT() == TRUE))
        {
            std::string errMsg;                                                                                                                                         /* PMSTA-24981 - 151116 - PMO */

            SYS_StringFormat(errMsg, "Connection (" szFormatPointer "), Thread (%s), Action (%s)",                                                                      /* PMSTA-16124 - 250413 - PMO */
                            (void*)csConnection,                                                                                                                        /* PMSTA-16124 - 250413 - PMO */
                            SYS_GetThreadDescriptionForLog().c_str(),                                                                                                   /* PMSTA-24981 - 151116 - PMO */
                            (action == CS_SET)   ? "Set"   :
                            (action == CS_GET)   ? "Get"   :
                            (action == CS_CLEAR) ? "Clear" :
                                           "Unknown");

            MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "SYB_CtConProps", errMsg.c_str());
        }
        else
        {
            std::string errMsg;                                                                                                                                         /* PMSTA-24981 - 151116 - PMO */

            SYS_StringFormat(errMsg, "SYB_CtConProps. Invalid argument. Connection (" szFormatPointer "), Thread (%s), Action (%s)",                                    /* PMSTA-16124 - 250413 - PMO */
                            (void*)csConnection,                                                                                                                        /* PMSTA-16124 - 250413 - PMO */
                            SYS_GetThreadDescriptionForLog().c_str(),                                                                                                   /* PMSTA-24981 - 151116 - PMO */
                            (action == CS_SET)   ? "Set"   :
                            (action == CS_GET)   ? "Get"   :
                            (action == CS_CLEAR) ? "Clear" :
                                            "Unknown");
            MSG_SendStrToLog(errMsg);
        }

        return(RET_GEN_ERR_INVARG);
    }


    dbiConn.m_currentCmd = Syb_Command_ConProps; /* Keep trace of the current command. */

#ifdef AIX
        /* PMSTA-21694 - 120516 - PMO
         * Workaround for AIX that dosen't support concurrency inside ct_con_props that call dlopen and might finish in deadlock
         */
        if (ProgramState::InitializationLock != SYS_GetProgramState())
        {
            LockGuard lock(ServLock_GetEnv, true, FILEINFO);
#endif

            sybRetCode = EV_rxaFctStruct.pfn_ct_con_props(csConnection, action, property, buffer, buflen, outlen);                                                      /* PMSTA-21694 - 120516 - PMO */

#ifdef AIX
        }
#endif

    if (CS_SUCCEED != sybRetCode)
    {
        std::string errMsg;                                                                                                                                             /* PMSTA-24981 - 151116 - PMO */

        SYS_StringFormat(errMsg,
                        "Call to ct_con_props failed for CsCon (" szFormatPointer "), Thread (%s), Connect (%d), Action (%s), Status (%s)",                             /* PMSTA-16615 - 180713 - PMO / PMSTA-16124 - 250413 - PMO */
                        (void*)csConnection,                                                                                                                            /* PMSTA-16124 - 250413 - PMO */
                        SYS_GetThreadDescriptionForLog().c_str(),                                                                                                       /* PMSTA-24981 - 151116 - PMO */
			            dbiConn.getId(),
                        (action == CS_SET) ? "CS_SET" :
                        (action == CS_GET) ? "CS_GET" :
                                     "CS_CLEAR",
                         dbiConn.getLabelRetCode(sybRetCode).c_str());                                                                                             /* PMSTA-24981 - 151116 - PMO */

        dbiConn.sendMsg(FILEINFO, errMsg);                                                                                                                        /* PMSTA-24981 - 151116 - PMO */
    }

     dbiConn.m_currentCmd = Syb_Command_None;

    /***** SQL TRACE *****/
    if (EV_sqlFile != nullptr)
    {
        std::string errMsg;                                                                                                                                             /* PMSTA-24981 - 151116 - PMO */

        SYS_StringFormat(errMsg,
                        "    ct_con_props()     CsCon=" szFormatPointer " Thread=%s Connect=%-9d Action=%-12.12s Status=%-12.12s",                                      /* PMSTA-16615 - 180713 - PMO / PMSTA-16124 - 250413 - PMO */
                        (void*)csConnection,                                                                                                                            /* PMSTA-16124 - 250413 - PMO */
                        SYS_GetThreadDescriptionForLog().c_str(),                                                                                                       /* PMSTA-24981 - 151116 - PMO */
                        dbiConn.getId(),
                        (action == CS_SET) ? "CS_SET" :
                        (action == CS_GET) ? "CS_GET" :
                                        "CS_CLEAR",
                         dbiConn.getLabelRetCode(sybRetCode).c_str());                                                                                             /* PMSTA-24981 - 151116 - PMO */

        MSG_SendSqlTrace(errMsg);
    }

    return sybRetCode != CS_SUCCEED ? sybRetCode : RET_SUCCEED;
}

/************************************************************************
*   Function             : SYB_CtOptions()
*
*   Description          :
*
*   Arguments            : connectNo : a connection number
*
*   Functions call       : None
*
*   Global var. modified : None
*
*   Return               : RET_CODE
*
*   Creation Date        : 29.09.99 - GRD - Ref.: REF3847.
*
*   Last modif.          : PMSTA-16124 - 250413 - PMO : Ensure coherence of printf / scanf formats with 32bits / 64 bits datatypes
*                          PMSTA-24981 - 151116 - PMO : pid: threadid: missing form trace
*
*************************************************************************/
RET_CODE SYB_CtOptions(SybConnection& dbiConn, CS_INT action, CS_INT option, CS_VOID *param, CS_INT paramlen, CS_INT *outlen)
{
    CS_RETCODE      sybRetCode  = CS_SUCCEED;
	CS_CONNECTION * csConnection = dbiConn.m_connection;

    if ((csConnection == NULL) || ((action != CS_SET) && (action != CS_GET) && (action != CS_CLEAR)))
    {
        if((SYS_IsGuiMode() == TRUE) || (SERVER_IS_INIT() == TRUE))
        {
            std::string errMsg;                                                                                                                                         /* PMSTA-24981 - 151116 - PMO */

            SYS_StringFormat(errMsg,
                            "Connection (" szFormatPointer "), Thread (%s), Action (%s)",                                                                               /* PMSTA-16124 - 250413 - PMO */
                            (void*)csConnection,                                                                                                                        /* PMSTA-16124 - 250413 - PMO */
                            SYS_GetThreadDescriptionForLog().c_str(),                                                                                                   /* PMSTA-24981 - 151116 - PMO */
                            (action == CS_SET)   ? "Set"   :
                            (action == CS_GET)   ? "Get"   :
                            (action == CS_CLEAR) ? "Clear" :
                                            "Unknown");

            MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "SYB_CtOptions", errMsg.c_str());
        }
        else
        {
            std::string errMsg;                                                                                                                                         /* PMSTA-24981 - 151116 - PMO */

            SYS_StringFormat(errMsg,
                            "SYB_CtOptions. Invalid argument. Connection (" szFormatPointer "), Thread (%s), Action (%s)",                                              /* PMSTA-16124 - 250413 - PMO */
                            (void*)csConnection,                                                                                                                        /* PMSTA-16124 - 250413 - PMO */
                            SYS_GetThreadDescriptionForLog().c_str(),                                                                                                   /* PMSTA-24981 - 151116 - PMO */
                            (action == CS_SET)   ? "Set"   :
                            (action == CS_GET)   ? "Get"   :
                            (action == CS_CLEAR) ? "Clear" :
                                           "Unknown");

            MSG_SendStrToLog(errMsg);
        }

        return(RET_GEN_ERR_INVARG);
    }


    dbiConn.m_currentCmd = Syb_Command_Options; /* Keep trace of the current command. */


    if ((sybRetCode = EV_rxaFctStruct.pfn_ct_options(csConnection, action, option, param, paramlen, outlen)) != CS_SUCCEED)
    {
        std::string errMsg;                                                                                                                                             /* PMSTA-24981 - 151116 - PMO */

        SYS_StringFormat(errMsg,
                        "Call to ct_options failed. Connection (" szFormatPointer "), Thread (%s), Connection (%d), Action (%s), Status (%s)",                          /* PMSTA-16124 - 250413 - PMO */
                        (void*)csConnection,                                                                                                                            /* PMSTA-16124 - 250413 - PMO */
                        SYS_GetThreadDescriptionForLog().c_str(),                                                                                                       /* PMSTA-24981 - 151116 - PMO */
                        dbiConn.getId(),
                        (action == CS_SET) ? "CS_SET" :
                        (action == CS_GET) ? "CS_GET" :
                                     "CS_CLEAR",
                         dbiConn.getLabelRetCode(sybRetCode).c_str());                                                                                             /* PMSTA-24981 - 151116 - PMO */

        dbiConn.sendMsg(FILEINFO, errMsg);                                                                                                                        /* PMSTA-24981 - 151116 - PMO */
    }

    dbiConn.m_currentCmd = Syb_Command_None;

    /***** SQL TRACE *****/
    if (EV_sqlFile != NULL)
    {
        std::string errMsg;                                                                                                                                             /* PMSTA-24981 - 151116 - PMO */

        SYS_StringFormat(errMsg,
                        "    ct_options()     Connect=" szFormatPointer ", Thread=%s Connection=%-9d Action=%-12.12s Status=%-12.12s",                                  /* PMSTA-16124 - 250413 - PMO */
                        (void*)csConnection,
                        SYS_GetThreadDescriptionForLog().c_str(),                                                                                                       /* PMSTA-24981 - 151116 - PMO */
			            dbiConn.getId(),
                        (action == CS_SET) ? "CS_SET" :
                        (action == CS_GET) ? "CS_GET" :
                                     "CS_CLEAR",
                         dbiConn.getLabelRetCode(sybRetCode).c_str());                                                                                             /* PMSTA-24981 - 151116 - PMO */

        MSG_SendSqlTrace(errMsg);
    }

    return sybRetCode != CS_SUCCEED ? sybRetCode : RET_SUCCEED;
}

/************************************************************************
*   Function             : SYB_CtPoll()
*
*   Description          :
*
*   Arguments            : connectNo : a connection number
*
*   Functions call       : None
*
*   Global var. modified : None
*
*   Return               : RET_CODE
*
*   Creation Date        : 29.09.99 - GRD - Ref.: REF3847.
*   Last modif.          : REF9956 - 020224 - PMO : FlexeLint message
*                          PMSTA-16124 - 250413 - PMO : Ensure coherence of printf / scanf formats with 32bits / 64 bits datatypes
*                          PMSTA-24981 - 151116 - PMO : pid: threadid: missing form trace
*
*************************************************************************/
RET_CODE SYB_CtPoll(SybConnection& dbiConn,
                    CS_CONTEXT *context,
                    CS_INT milliseconds,
                    CS_CONNECTION **compConn,
                    CS_COMMAND **compCmd,
                    CS_INT *compId,
                    CS_RETCODE *compStatus)
{
    CS_RETCODE      sybRetCode   = CS_SUCCEED;
	int             csConnectNo  = dbiConn.getId();
    CS_CONNECTION*  csConnection = dbiConn.m_connection;

    dbiConn.m_currentCmd = Syb_Command_Poll; /* Keep trace of the current command. */

    if ((sybRetCode = EV_rxaFctStruct.pfn_ct_poll(context, csConnection, milliseconds, compConn, compCmd, compId, compStatus)) != CS_SUCCEED)
    {
        std::string errMsg;                                                                                                                                         /* PMSTA-24981 - 151116 - PMO */

        SYS_StringFormat(errMsg,
                        "Call to ct_poll failed. Connection (" szFormatPointer "), Thread (%s), Context (" szFormatPointer "), Connection (%d), Status is (%s)",    /* PMSTA-16124 - 250413 - PMO */
                        (void *)csConnection,                                                                                                                       /* PMSTA-16124 - 250413 - PMO */
                        SYS_GetThreadDescriptionForLog().c_str(),                                                                                                   /* PMSTA-24981 - 151116 - PMO */
                        (void *)context,                                                                                                                            /* PMSTA-16124 - 250413 - PMO */
                        csConnectNo,
                         dbiConn.getLabelRetCode(sybRetCode).c_str());                                                                                         /* PMSTA-24981 - 151116 - PMO */

        dbiConn.sendMsg(FILEINFO, errMsg);                                                                                                                    /* PMSTA-24981 - 151116 - PMO */
    }


	dbiConn.m_currentCmd = Syb_Command_None;


    /***** SQL TRACE *****/
    if (EV_sqlFile != NULL)
    {
        std::string errMsg;                                                                                                                                         /* PMSTA-24981 - 151116 - PMO */

        SYS_StringFormat(errMsg,"    ct_poll()     Connect=" szFormatPointer " Thread=%s Connect=%-9d Status=%-12.12s",                                             /* PMSTA-16124 - 250413 - PMO */
                        (void *)csConnection,                                                                                                                       /* PMSTA-16124 - 250413 - PMO */
                        SYS_GetThreadDescriptionForLog().c_str(),                                                                                                   /* PMSTA-24981 - 151116 - PMO */
                        csConnectNo,
                         dbiConn.getLabelRetCode(sybRetCode).c_str());                                                                                         /* PMSTA-24981 - 151116 - PMO */

        dbiConn.sendMsg(FILEINFO, errMsg);                                                                                                                    /* PMSTA-24981 - 151116 - PMO */
    }

    return sybRetCode != CS_SUCCEED ? sybRetCode : RET_SUCCEED;
}


/************************************************************************
*   Function             : SYB_ProcessAllAccessResults()
*
*   Description          : Read all pending results or status after a request.
*
*   Arguments            : connectNo          : a connection number in the connection
*                                               list
*                          accessPtr          : data array
*                          msgStructPtrHeader : pointer on a header of message structure
*                          eltNbr             : Number of entry into accessPtr
*
*   Global var. modified : None
*
*   Return               :
*
*   Creation date        :
*
*   Last Modif. Date     : PMSTA-21324 - 251015 - PMO : Fusion crash in DBA_MultiAccess/SYB_ProcessAllAccessResults
*                          PMSTA-34975 - 240419 - PMO : SYB_ProcessParamResult: Invalid read + SIGSEGV
*
*************************************************************************/
RET_CODE SYB_ProcessAllAccessResults(SybConnection         &dbiConn,
                                     int                    eltIndex,
                                     int                    maxRecInBuf,
                                     DBA_ACCESS_STP         accessPtr,
                                     int *                  eltPos,
                                     DBA_DYNFLD_STP *       dataTab,
                                     DBA_ACTION_ENUM        actionArg,
                                     OBJECT_ENUM            objectArg,
                                     int *                  errStatusTab,
                                     const int              eltNbr,
                                     DBA_PROC_STP           procedureForDataTab) /* DLA - PMSTA08801 - 100325 */
{
    RET_CODE                result = RET_SUCCEED;
    int                     startEltIndex = eltIndex;/* REF4001 - SSO - 991011 */

    /* REF3749 - SSO - 990703 verify if a fatal error occured */
    int lastSybClSeverity = dbiConn.getLastSybClSeverity();                 /* PMSTA-32315 - 260718 - PMO */
    if (lastSybClSeverity == CS_SV_INTERNAL_FAIL || lastSybClSeverity == CS_SV_FATAL)
    {
        DBA_DeleteApplSessionOnExit(AppSessionInvalidationNat_Unexpected_exit); /* PMSTA-22549 - CHU - 160603 */

        /* must exit!!! */
        EV_rxaFctStruct.pfn_ct_exit(SYB_GetCsContext(), CS_FORCE_EXIT);

        /* REF6059 - PMO. change error message */   /*  HFI-PMSTA-22650-160411  remove Triple'A in comment*/
        MSG_LogSrvMesg(UNUSED, UNUSED, "Serious error received from Sybase dataserver. The application will be shutdown (exit).");

        SYS_Shutdown(EXIT_FAILURE);        /* DLA - PMSTA-26546 - 170314 */
    }
    else
    {
        /* OK */
        dbiConn.resetLastSybClSeverity();                               /* PMSTA-32315 - 260718 - PMO */
    }

    CS_INT lastResultType = dbiConn.m_lastResultType;
    DATE_START_TIMER(1, TIMER_MASK_SQLC);

    DBA_ACTION_ENUM         action       = NullAction;
    bool                    bUpdEltIndex = false;

    do
    {
        switch (lastResultType)
        {
            case CS_CMD_SUCCEED:
                break;

            case CS_COMPUTE_RESULT:
            case CS_CURSOR_RESULT:
            case CS_COMPUTEFMT_RESULT:
            case CS_ROWFMT_RESULT:
            case CS_MSG_RESULT:
            case CS_DESCRIBE_RESULT:
                break;

            case CS_CMD_DONE:
                if (bUpdEltIndex)
                {
                    eltIndex++;
                    /* DLA - PMSTA-10877 - 110105 */
                    while (eltIndex < eltNbr && accessPtr[eltIndex].action == NullAction)
                    {
                        eltIndex++;
                    }
                    bUpdEltIndex = false;
                }
                break;

            case CS_PARAM_RESULT:
                /* PMSTA08801 - DLA - 100226 - Read Sybase's output parameters */
                if (procedureForDataTab != nullptr)
                {
                    SYB_ProcessParamResult(dbiConn, objectArg, dataTab[eltIndex]->dynStEnum, dataTab[eltIndex], procedureForDataTab);/* PMSTA08801 - DLA - 100226 */
                    action = actionArg;
                }
                else
                {
                    DBA_PROC_STP procedure = DBA_GetStoredProcs(accessPtr[eltIndex].action,
                                                                accessPtr[eltIndex].object,
                                                                accessPtr[eltIndex].role,
                                                                accessPtr[eltIndex].entity,
                                                                accessPtr[eltIndex].data,
                                                                NullDynSt);
                    SYB_ProcessParamResult(dbiConn, accessPtr[eltIndex].object, accessPtr[eltIndex].entity, accessPtr[eltIndex].data, procedure);/* PMSTA08801 - DLA - 100226 / PMSTA-8801 - 020610 - PMO */
                    action = accessPtr[eltIndex].action;
                }

                break;

            case CS_ROW_RESULT:    /* REF11780 - 100406 - PMO */
                DBA_DYNFLD_STP  SqlResultSt;

                /* Memory allocation for extended operation record */
                if ((SqlResultSt = ALLOC_DYNST(Sql_Result)) == nullptr)
                {
                    MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "Sql_Result");
                    result = RET_SRV_LIB_ERR_COMMAND_ABORTED;
                }
                else
                {
                    /* All is right ? */
                    if (FALSE == DBA_ReadSqlBlockResult(dbiConn, Sql_Result, SqlResultSt) &&
                        eltNbr > 0 &&
                        nullptr != accessPtr &&
                        FALSE == IS_NULLFLD(SqlResultSt, Sql_Result_TimeStamp) &&
                        FALSE == IS_NULLFLD(SqlResultSt, Sql_Result_Id))
                    { /* Yes */
                        int idxAccess;

                        for (idxAccess = 0; idxAccess < eltNbr; idxAccess++)
                        {
                            /* Search the ext_op */
                            if (ExtOp == accessPtr[idxAccess].entity &&
                                Update == accessPtr[idxAccess].action &&
                                0 == CMP_ID(GET_ID((accessPtr[idxAccess].data), ExtOp_DbId), GET_ID(SqlResultSt, Sql_Result_Id)))
                            {
                                DBA_SetFieldTimeStamp(ExtOp, accessPtr[idxAccess].data, GET_TIMESTAMP(SqlResultSt, Sql_Result_TimeStamp));

                                /* Stop the search */
                                break;
                            }
                        }

                        if (idxAccess == eltNbr)
                        { /* Not found */
                            /* This is the case when we don't have the id into the structure
                             * and we receive the timestamp with it's id
                             */
                            for (idxAccess = 0; idxAccess < eltNbr; idxAccess++)
                            {
                                /* Search the ext_op */
                                if (ExtOp == accessPtr[idxAccess].entity                                &&
                                    Insert == accessPtr[idxAccess].action                                &&
                                    TRUE == IS_NULLFLD((accessPtr[idxAccess].data), ExtOp_DbId) &&
                                    TRUE == IS_NULLFLD((accessPtr[idxAccess].data), ExtOp_TimeStampNew))
                                {
                                    DBA_SetFieldTimeStamp(ExtOp, accessPtr[idxAccess].data, GET_TIMESTAMP(SqlResultSt, Sql_Result_TimeStamp));
                                    /* Stop the search */
                                    break;
                                }
                            }
                        }
                    }

                    FREE_DYNST(SqlResultSt, Sql_Result);
                }
                break;

            case CS_CMD_FAIL:
                if (dbiConn.m_msgStack.size() > 0)
                {
                    dbiConn.filterMsgInfos(&result);
                    dbiConn.m_msgStructHeaderSt.patchLastMsg(FILEINFO, eltIndex, eltIndex + maxRecInBuf - 1, (accessPtr ? accessPtr[eltIndex].action : actionArg));
                }
                result = RET_SRV_LIB_ERR_COMMAND_ABORTED;

                break;

            case CS_STATUS_RESULT:

                bUpdEltIndex = true;

                if (eltNbr > 0 && eltIndex >= eltNbr)
                {
                    MSG_SendMesg(FILEINFO, "MultiAccess receive too much status results");
                    result = RET_DBA_ERR_INVDATA;
                    break;
                }

            {
                /* Bind application status with returned value */
                CS_INT status = 0;             /* PMSTA-16918 - 090913 - PMO */
                SYB_ColBind(dbiConn, 1, CS_INT_TYPE, &status);

                /* Retrieve the value and store it into status */
                dbiConn.fetch();

                while (dbiConn.fetch() == TRUE)
                    ;

                if (accessPtr != nullptr)
                {
                    action = accessPtr[eltIndex].action;
                }
                else
                {
                    action = actionArg;
                }

                /* PMSTA-nuodb - LJE - 190903 */
                if (errStatusTab != UNUSED)
                {
                    errStatusTab[eltIndex] = status;
                }

                switch (action)
                {
                    case Insert:
                    case InsUpd:

                        if (dbiConn.m_msgStack.size() > 0)
                        {
                            /* Fusion strict error processing. PMSTA-14660 - 160712 - PMO */
                            if (NULL != dbiConn.getConnStructPtr()->msgOptions && true == dbiConn.getConnStructPtr()->msgOptions->strictErrorHandling)
                            {
                                dbiConn.getConnStructPtr()->msgOptions->fatalError = true;
                            }
                            dbiConn.filterMsgInfos(&result);

                            if (action == InsUpd && result == RET_SRV_LIB_ERR_DUPLICATEKEY)
                            {
                                result = RET_SUCCEED;
                                break;
                            }

                            /* REF3319 - SSO - 990415 : if deadlock, all block is in error */
                            if (result == RET_SRV_LIB_ERR_DEADLOCK
                                /* REF4001 - SSO - 991011: only if we where in transac (see DBA_FilterMsgInfos2) */
                                && dbiConn.m_transactCpt == -1)
                            {
                                dbiConn.m_msgStructHeaderSt.patchLastMsg(FILEINFO, startEltIndex, startEltIndex + maxRecInBuf - 1, action);
                            }
                            else
                            {
                                dbiConn.m_msgStructHeaderSt.patchLastMsg(FILEINFO, eltIndex, eltIndex, action);
                            }

                            if (result == RET_SRV_LIB_ERR_TRIGGER_MSG)
                            {
                                *eltPos = eltIndex;
                            }
                            else
                            {
                                result = (result == RET_SRV_LIB_ERR_DEADLOCK)   /* REF3685 */
                                    ? RET_SRV_LIB_ERR_DEADLOCK
                                    : RET_DBA_ERR_DBPROBLEM;
                            }

                        }
                        else
                        {
                            if (status > 1) /* Old ID management returned by status, normally no more used -> assert DLA - PMSTA08801 - 100226 */
                            {
                                assert(147 == 8801);
                            }
                            dbiConn.m_msgStack.clear();
                        }
                        break;

                    case Update:
                    case Delete:
                    case Notif:

                        if (status < 0 || dbiConn.m_msgStack.size() > 0)
                        {
                            /* Fusion strict error processing. PMSTA-14660 - 160712 - PMO */
                            if (nullptr != dbiConn.getConnStructPtr()->msgOptions && true == dbiConn.getConnStructPtr()->msgOptions->strictErrorHandling)
                            {
                                dbiConn.getConnStructPtr()->msgOptions->fatalError = true;
                            }

                            dbiConn.filterMsgInfos(&result);

                            /* REF3319 - SSO - 990415 : if deadlock, all block is in error */
                            if (result == RET_SRV_LIB_ERR_DEADLOCK
                                /* REF4001 - SSO - 991011: only if we where in transac (see DBA_FilterMsgInfos2) */
                                && dbiConn.m_transactCpt == -1)
                            {
                                dbiConn.m_msgStructHeaderSt.patchLastMsg(FILEINFO, startEltIndex, startEltIndex + maxRecInBuf - 1, action);
                            }
                            else
                            {
                                dbiConn.m_msgStructHeaderSt.patchLastMsg(FILEINFO, eltIndex, eltIndex, action);
                            }

                            if (result == RET_SRV_LIB_ERR_TRIGGER_MSG)
                            {
                                *eltPos = eltIndex;
                            }
                            else if (result != RET_DBA_INFO_EXTERNAL_SEQ) /* PMSTA-20887 - LJE - 150915 */
                            {
                                result = (result == RET_SRV_LIB_ERR_DEADLOCK)   /* REF3685 */
                                    ? RET_SRV_LIB_ERR_DEADLOCK
                                    : RET_DBA_ERR_DBPROBLEM;
                            }
                        }
                        else
                        {
                            dbiConn.m_msgStack.clear();
                        }

                        break;

                    default:
                        break;
                }

                DBA_PROC_STP procedure = nullptr;

                if (procedureForDataTab != nullptr)
                    procedure = procedureForDataTab;
                else
                {
                    procedure = DBA_GetStoredProcs(accessPtr[eltIndex].action, /* DLA - PMSTA08801 - 100323 */
                                                   accessPtr[eltIndex].object,
                                                   accessPtr[eltIndex].role,
                                                   accessPtr[eltIndex].entity,
                                                   accessPtr[eltIndex].data,
                                                   NullDynSt);
                }

                /* Strict error handling. For the fusion processing PMSTA-14660 - 160712 - PMO */
                switch (action)
                {
                    case Insert:
                    case InsUpd:
                    case Update:
                    case Delete:

                        if (status != 1 && status != 0 && NULL != dbiConn.getConnStructPtr()->msgOptions && true == dbiConn.getConnStructPtr()->msgOptions->strictErrorHandling)
                        {
                            dbiConn.getConnStructPtr()->msgOptions->fatalError = true;

                            char * dataStr = static_cast<char *>(CALLOC(EV_MaxFieldLenWithoutText, sizeof(char)));

                            if (NULL != dataStr)
                            {
                                try
                                {
                                    /* Prepare the error message */
                                    std::string sqlCmd = "Error while executing SQL (status:";

                                    { /* Add the status value */
                                        char szNumber[12];
                                        (void)snprintf(szNumber, sizeof(szNumber) / sizeof(szNumber[0]), "%d", status);
                                        sqlCmd += szNumber;
                                        sqlCmd += ") ";
                                    }

                                    /* Append the SQL command into sqlCmd */
                                    DBA_CreateSQLCall(sqlCmd, dataStr, EV_MaxFieldLenWithoutText, &accessPtr[eltIndex], procedure);

                                    MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, sqlCmd.c_str());
                                }
                                catch (std::exception &)
                                {
                                    MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "Creating SQL parameter error message");
                                    result = RET_SRV_LIB_ERR_COMMAND_ABORTED;
                                }
                                FREE(dataStr);
                            }
                            else
                            { /* Error */
                                MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "Creating SQL error message");
                                result = RET_SRV_LIB_ERR_COMMAND_ABORTED;
                            }
                        }
                        break;

                    default:
                        break;
                }
            }
            break;
        }
    } while ((SYB_CtResults(dbiConn, &lastResultType)) == CS_SUCCEED);

    if (result == RET_SUCCEED && 
        eltNbr != 0 && 
        eltIndex != eltNbr && 
        (eltIndex - startEltIndex) != maxRecInBuf)
    {
        MSG_SendMesg(FILEINFO, "MultiAccess receive not enough status results");
        result = RET_DBA_ERR_INVDATA;
    }


    /* REF3685 */
    /*
     * If the request has been deadlocked, we MUST call SYB_CtCancel.
     * If this call fails, we MUST close the connection and free all allocated structures.
     */

    if (dbiConn.cancelDbRequest(COMMAND_LEVEL, CANCEL_ALL) == FALSE)
    {
        if (result == RET_SRV_LIB_ERR_DEADLOCK)
        {
            result = RET_SRV_LIB_ERR_FATAL_DEADLOCK;    /* REF3685 */
        }
    }

    DATE_STOP_TIMER(1, TIMER_MASK_SQLC);

    return(result);
}

/*******************************************************************************
**
**  Function    :  SYB_SendSqlTrace()
**
**  Description :
**
**  Arguments   :  str ptr
**
**  Return      :
**
**  Creation    :
**  Last modif. :  REF10195 - LJE - 040408
**
*******************************************************************************/
void SYB_SendSqlTrace(char **sqlTraceStrPtr)
{
    if (*sqlTraceStrPtr != nullptr)
    {
        strcat((*sqlTraceStrPtr), "\"");
        MSG_SendSqlTrace((*sqlTraceStrPtr));
        FREE((*sqlTraceStrPtr));
    }
    return;
}

/************************************************************************
**
**  Function    :   SYB_WriteInSqlTrace()
**
**  Description :
**
**  Argument    :   sqlTraceStrPtr
**
**  Return      :
**
**  Creation    :
**  Last modif. :  REF10195 - LJE - 040408
**              :  REF11860 - 060808 - BSA : Compilation warnings with C++ compiler
**
*************************************************************************/
STATIC void SYB_WriteInSqlTrace(char **sqlTraceStrPtr, int len, const char* format, ...)
{
    va_list arg;

    if (format == NULL)
        return;

    va_start(arg, format);

    if (EV_ExtractFile)
    {
        vfprintf(EV_ExtractFile, format, arg);
    }

    if (*sqlTraceStrPtr != NULL && EV_SqlTraceParam > 0)
    {
        if (len < 0)
        {
            len = SYS_StrLen(format);
        }

        int sqlTraceLen = SYS_StrLen(*sqlTraceStrPtr);

        /* + 2 for the char '0' and the '"' final */
        if (sqlTraceLen + len + 2 > ((sqlTraceLen / 1024) + 1) * 1024)
        {
            *sqlTraceStrPtr = static_cast<char *>(REALLOC(*sqlTraceStrPtr, (((sqlTraceLen + len + 2)/1024) + 1) * 1024 * sizeof(char)));
        }

        vsprintf((*sqlTraceStrPtr)+sqlTraceLen, format, arg);
    }

    va_end(arg);
    return;
}

/************************************************************************
**   END  syblib02.c                                                   **
*************************************************************************/

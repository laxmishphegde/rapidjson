/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define SYBBCP_C

/************************************************************************
**      Include files
*************************************************************************/
#define STDIO_H
#define STRING_H
#define TIME_H
#define STDLIB_H

#include "unidef.h"     /* Mandatory */
#include "timer.h"      /* REF2421 - OCE - 980825 */
#include "dba.h"
#include "sybbcp.h"
#include "bkpublic.h"
#include "date.h"
#include "gen.h"
#include "syb.h"
#include "rxa.h"

extern int EV_SqlTraceParam; /* REF10392 - LJE - 040624 */
extern RXA_FCTPTR EV_rxaFctStruct; /* DLA - PMSTA-23431 - 160824 */

/************************************************************************
 *   P R I V A T E    F U N C T I O N S
 *************************************************************************/
STATIC RET_CODE    SYB_BcpExecInsert        (SYB_BLKDEF_STP, int*, const char*);    /* REF8728 - YST - 030213 */
STATIC void        SYB_BcpSqlTrace          (SYB_BLKDEF_STP, const char *str);      /* REF8728 - YST - 030213 */
STATIC void        SYB_BcpSqlTraceEnd       ();
STATIC void        SYB_BcpSqlTraceColBlkDef (SYB_BLKDEF_STP, int);                  /* REF10392 - LJE - 040623 */
STATIC RET_CODE    SYB_BcpModifyDatafmt     (SYB_BLKDEF_STP, int);
STATIC RET_CODE    SYB_BcpDone              (SYB_BLKDEF_STP, int *outRowNb, FLAG_T);/* PMSTA15705 - DDV - 121226 - Purify */

/************************************************************************
*************************************************************************
**
**    P U B L I C      F U N C T I O N S
**
*************************************************************************
*************************************************************************/



/*************************************************************************
*
*   Function             : SYB_BcpInInit
*
*   Description          : This function initializes a bulk copy
*                          It allocates a special work area which must be
*                          freed after each BCP operation in calling
*                          SYB_BcpEnd
*
*   Usage                : 1) SYB_BcpInInit
*                          2) loop { SYB_BcpInsert() }
*                          3) SYB_BcpEnd
*
*
*   Arguments            : connectNo   (in) : connection number to use during bulk copy - PMSTA12765 - DDV - 110916 - Give connection number instead of connection structure
*                                              This connection must not have any
*                                              pending result
*                          tableName    (in) : table name in wich bulk copies are done
*                          fieldType    (in) :
*                          colNb        (in) : number of column in 'tableName' table
*                          count        (in) : number of row to be bulk copied at one go.
*                          blkdef      (out) : a pointer to a virgin SYB_BLKDEF_ST
*
*   Functions call       :
*
*   Return               : RET_CODE
*
*   Modification         : REF8798 - YST - 030320 - insert PerfAttribData, StdPerfData etc. by BCP
*
*************************************************************************/
RET_CODE SYB_BcpInInit(DBI_BLKDEF_STP  parentBlkdef,
                       void          **blkdef)
{
    int               colNu     = 0;
    SYB_BLKDEF_STP    _blkdef   = NULL;
	CS_CONNECTION     *csConnection = (CS_CONNECTION *)parentBlkdef->dbiConnPtr->getConnectionPtr();

    /*
    ** Allocate a SYB_BLKDEF_ST structure
    */
    if ((_blkdef = (SYB_BLKDEF_STP)CALLOC(1, sizeof(SYB_BLKDEF_ST))) == NULL)
    {
        return(RET_MEM_ERR_ALLOC);
    }
    *blkdef=(void*)_blkdef;

    /*
    ** link child and parent blk definitions
    */

	_blkdef->parentDef = parentBlkdef;
	parentBlkdef->internal = *blkdef;

    /*
    ** Start by getting the bulk descriptor ( a CS_BLKDESK structure )
    */
    if (EV_rxaFctStruct.pfn_blk_alloc(csConnection, /* REF7264 - LJE - 020205 */
                                      SYBASE_BLK_VERSION,  /* PMSTA13362 - DDV - 120213 - Also do it for BCP version */
                                      &_blkdef->blkdesc) != CS_SUCCEED)
    {
        DBI_BcpFree(parentBlkdef);
        *blkdef = NULL;
        return(RET_MEM_ERR_ALLOC);
    }

    /*
    ** Allocate one CS_DATAFMT structure per column and keep the
    ** information during until the bulk copy batch is finished
    */
	if ((_blkdef->datafmt = (CS_DATAFMT *)CALLOC(_blkdef->parentDef->colNb, sizeof(CS_DATAFMT))) == NULL)
    {
		DBI_BcpFree(parentBlkdef);
		*blkdef = NULL;
        return(RET_MEM_ERR_ALLOC);
    }

    /*
    ** Allocate one int per column to save buffer length if needed.
    */
	if ((_blkdef->buflen = (int *)CALLOC(_blkdef->parentDef->colNb, sizeof(int))) == NULL)
    {
		DBI_BcpFree(parentBlkdef);
		*blkdef = NULL;
        return(RET_MEM_ERR_ALLOC);
    }

    /*
    ** Allocate a two-dimensionnal array of CS_SMALLINT for NULL value indicators
    ** Allocate the column first
    */
	if ((_blkdef->indicator = (CS_SMALLINT**)CALLOC(_blkdef->parentDef->colNb, sizeof(CS_SMALLINT*))) == NULL)
    {
		DBI_BcpFree(parentBlkdef);
		*blkdef = NULL;
        return(RET_MEM_ERR_ALLOC);
    }

    /*
    ** Allocate a two-dimensionnal array of buffer to be binded.
    ** Allocate the column first
    */
	if ((_blkdef->buffer = (CS_VOID**)CALLOC(_blkdef->parentDef->colNb, sizeof(CS_VOID**))) == NULL)  /*REF2421 - OCE - 980825 */
    {
		DBI_BcpFree(parentBlkdef);
		*blkdef = NULL;
        return(RET_MEM_ERR_ALLOC);
    }

    /*
    ** Allocate a two-dimensionnal array of CS_INT. Each CS_INT will indicate the buffer length
    ** Allocate the column first
    */
	if ((_blkdef->datalen = (CS_INT**)CALLOC(_blkdef->parentDef->colNb, sizeof(CS_INT*))) == NULL)
    {
		DBI_BcpFree(parentBlkdef);
		*blkdef = NULL;
        return(RET_MEM_ERR_ALLOC);
    }

    /*
    ** Get and save information on each column to size buffer allocation
    */
	for (colNu = 0; colNu < _blkdef->parentDef->colNb; colNu++)
    {
        /*
        ** Arrange '_blkdef->datafmt[colNu]' according to DATATYPE_ENUM (SYB_ConvertFldToNumericAndSetParam)
        */
        SYB_BcpModifyDatafmt(_blkdef, colNu);

        /*
        ** Allocate as many cells as there are rows for the current column buffer
        */
        _blkdef->parentDef->allocSize = _blkdef->parentDef->count * _blkdef->datafmt[colNu].maxlength;
		if ((_blkdef->buffer[colNu] = (CS_VOID*)CALLOC(_blkdef->parentDef->count, _blkdef->datafmt[colNu].maxlength)) == NULL)
        {
			DBI_BcpFree(parentBlkdef);
			*blkdef = NULL;
            return(RET_MEM_ERR_ALLOC);
        }
		if ((_blkdef->datalen[colNu] = (CS_INT*)CALLOC(_blkdef->parentDef->count, sizeof(CS_INT))) == NULL)
        {
			DBI_BcpFree(parentBlkdef);
			*blkdef = NULL;
            return(RET_MEM_ERR_ALLOC);
        }
		if ((_blkdef->indicator[colNu] = (CS_SMALLINT*)CALLOC(_blkdef->parentDef->count, sizeof(CS_SMALLINT))) == NULL)
        {
			DBI_BcpFree(parentBlkdef);
			*blkdef = NULL;
            return(RET_MEM_ERR_ALLOC);
        }
    }

    /* PMSTA-34344 - LJE - 201113 */
    CS_INT  identityProps = CS_TRUE;
    if (EV_rxaFctStruct.pfn_blk_props(_blkdef->blkdesc, CS_GET, BLK_IDENTITY, &identityProps, CS_UNUSED, NULL) != CS_SUCCEED)
    {
        SYB_BcpSqlTraceEnd();
        DBI_BcpFree(parentBlkdef);
        *blkdef = NULL;
        return(RET_DBA_ERR_INSERT_FAILED);
    }

    if (_blkdef->parentDef->bIdentityInserted != (identityProps == CS_TRUE))
    {
        identityProps = (_blkdef->parentDef->bIdentityInserted ? CS_TRUE : CS_FALSE);

        if (EV_rxaFctStruct.pfn_blk_props(_blkdef->blkdesc, CS_SET, BLK_IDENTITY, &identityProps, CS_UNUSED, NULL) != CS_SUCCEED)
        {
            SYB_BcpSqlTraceEnd();
            DBI_BcpFree(parentBlkdef);
            *blkdef = NULL;
            return(RET_DBA_ERR_INSERT_FAILED);
        }
    }

    /* PMSTA15705 - DDV - 121226 - Purify, blk_init done only once,
       then blk_done with CS_BLK_BATCH will be called for each block and it will be call one time with CS_BLK_ALL when finished */
    SYB_BcpSqlTrace(_blkdef, "blk_init()");         /* PMSTA-23981 - 070716 - PMO */
    if (EV_rxaFctStruct.pfn_blk_init(_blkdef->blkdesc,
                                     CS_BLK_IN,
                                     _blkdef->parentDef->tableName,
                                     CS_NULLTERM) != CS_SUCCEED)
    {
        SYB_BcpSqlTraceEnd();
        DBI_BcpFree(parentBlkdef);
        *blkdef = NULL;
        return(RET_DBA_ERR_INSERT_FAILED);
    }

    SYB_BcpSqlTraceEnd();

    return RET_SUCCEED;
}


/*************************************************************************
*
*   Function             : SYB_BcpInsert
*
*   Description          : this function insert a bloc of records by bulk copy
*
*   Usage                : 1) SYB_BcpInit
*                          2) loop { SYB_BcpInsert() }
*                          3) SYB_BcpEnd
*
*   Arguments            : record          (in) : array of DBA_DYNFLD_STP
*                          blkdef      (in/out) : a pointer to an initialised SYB_BLKDEF_ST
*                          outRowNb       (out) : number of rows really inserted
*
*   Side Effects         : THE FIRST DIMENSION 'record' ARRAY IS THE COLUMN NUMBER,
*                          THE SECOND ONE IS THE ROW NUMBER !
*
*   Functions call       : SYB_BcpExecInsert
*
*   Return               : RET_CODE
*
*   Modification         : REF8798 - YST - 030327 - add treatment _blkdef->firstCol
*                          PMSTA-25190 - 061116 - PMO : Fixes of some errors founded by AddressSanitizer
*
*************************************************************************/
RET_CODE SYB_BcpInsert(DBA_DYNFLD_STP   record ,
                       SYB_BLKDEF_STP   _blkdef,        /* PMSTA-25190 - 061116 - PMO */
                       int *            outRowNb,
                       const char *     objectName)     /* REF8728 - YST - 030213 */

{
    /*
    ** Treat each column and bind it as an array
    */
	for (int colNu = 0; colNu < _blkdef->parentDef->colNb; colNu++)
    {
        /*
        ** Treat NULL values the given row in this column
        */
		if (IS_NULLFLD(record, colNu + _blkdef->parentDef->firstCol) == TRUE)
        {
            if (_blkdef->parentDef->fieldType[colNu] == FlagType)
            {
                unsigned char     flag = 0;

				memcpy((char*)_blkdef->buffer[colNu] + _blkdef->parentDef->curRow * _blkdef->datafmt[colNu].maxlength,
                         &flag,
                         _blkdef->datafmt[colNu].maxlength) ;
				_blkdef->datalen[colNu][_blkdef->parentDef->curRow] = _blkdef->datafmt[colNu].maxlength;
            }
            else
            {
				_blkdef->datalen[colNu][_blkdef->parentDef->curRow] = 0;
            }

            /* BUG 10/10/97 found by PEN corrected by XAJ */
            /* BM-153 - DDV - 120309 - Also reset the string for unicode buffer */
			if (_blkdef->parentDef->curRow == 0 &&
               ((GET_CTYPE(_blkdef->parentDef->fieldType[colNu]) == CharPtrCType) ||
                (GET_CTYPE(_blkdef->parentDef->fieldType[colNu]) == UniCharPtrCType)))
            {
                *((char*)_blkdef->buffer[colNu]) = '\0';
                _blkdef->buflen[colNu] = 0 ;
            }

            _blkdef->indicator[colNu][_blkdef->parentDef->curRow] = CS_NULLDATA;
            continue;
        }

        /*
        ** Treat the given row in this column
        */
        if(GET_CTYPE(_blkdef->parentDef->fieldType[colNu]) == CharPtrCType)
        {
			if (_blkdef->parentDef->curRow == 0)
            {
                *((char*)_blkdef->buffer[colNu]) = '\0';
                _blkdef->buflen[colNu] = 0 ;
            }

			strcpy((char*)_blkdef->buffer[colNu] + _blkdef->buflen[colNu], record[colNu + _blkdef->parentDef->firstCol].data.strData.ptr);
			_blkdef->datalen[colNu][_blkdef->parentDef->curRow] = GET_STRING_LEN(record, colNu + _blkdef->parentDef->firstCol);
			_blkdef->buflen[colNu] += _blkdef->datalen[colNu][_blkdef->parentDef->curRow];
        }
        else if(GET_CTYPE(_blkdef->parentDef->fieldType[colNu]) == UniCharPtrCType)
        {
			if (_blkdef->parentDef->curRow == 0)
            {
                *((UChar*)_blkdef->buffer[colNu]) = '\0';
                _blkdef->buflen[colNu] = 0 ;
            }

			u_strcpy((UChar*)((char *)_blkdef->buffer[colNu] + _blkdef->buflen[colNu]), record[colNu + _blkdef->parentDef->firstCol].data.ustrData.ptr);
			_blkdef->datalen[colNu][_blkdef->parentDef->curRow] = GET_USTRING_LEN(record, colNu + _blkdef->parentDef->firstCol) * sizeof(UChar);
			_blkdef->buflen[colNu] += _blkdef->datalen[colNu][_blkdef->parentDef->curRow];
        }
        else
        {
			memcpy((char*)_blkdef->buffer[colNu] + _blkdef->parentDef->curRow * _blkdef->datafmt[colNu].maxlength,
				&record[colNu + _blkdef->parentDef->firstCol].data,
                  _blkdef->datafmt[colNu].maxlength) ;
			_blkdef->datalen[colNu][_blkdef->parentDef->curRow] = _blkdef->datafmt[colNu].maxlength;
        }

    }  /* for ( colNu = 0 ... ) */

    _blkdef->parentDef->curRow += 1;

    /*
    ** Now insert only if we have all the records
    */
    if (outRowNb)
    {
        *outRowNb = 0;
    }

	if (_blkdef->parentDef->curRow >= _blkdef->parentDef->count
        && SYB_BcpExecInsert( _blkdef, outRowNb, objectName) != RET_SUCCEED)
    {
        SYB_BcpDone(_blkdef, outRowNb, TRUE); /* PMSTA-16836 - DDV - 130926 */
        DBI_BcpFree(_blkdef->parentDef);			/* REF2421 - OCE - 980825 */
        return(RET_DBA_ERR_INSERT_FAILED);
    }

    return RET_SUCCEED;
}



/*************************************************************************
*
*   Function             : SYB_BcpEnd
*
*   Description          :
*
*   Arguments            :
*
*   Functions call       : None.
*
*   Return               : RET_CODE
*
*   Last Modification    : PMSTA-23981 - 070716 - PMO : Financial server crash when launching report
*
 *************************************************************************/
RET_CODE SYB_BcpEnd(SYB_BLKDEF_STP  _blkdef,       /* PMSTA-23981 - 070716 - PMO */
		            int *           outRowNb,
                    const char *    objectName)    /* REF8728 - YST - 030213 */
{
    if (_blkdef)
    {
        /*
        ** Now insert last block of records
        */
		if (_blkdef->parentDef->curRow > 0)
        {
            if (SYB_BcpExecInsert( _blkdef, outRowNb, objectName) != RET_SUCCEED)
            {
                if (outRowNb != NULL)
                    *outRowNb = 0;

                /* SYB_BcpDone(_blkdef, outRowNb);		   REF2421 - OCE - 980825 */
 		        /* PMSTA16848 - DDV - 130902 - Purify, call blk_done to clean blk struct (with CS_BLK_ALL) */
                SYB_BcpDone(_blkdef, outRowNb, TRUE);
	            SYB_BcpFree(_blkdef);				/* PMSTA-23981 - 070716 - PMO */ /* REF2421 - OCE - 980825 */

                return(RET_DBA_ERR_INSERT_FAILED);
            }
        }

 		/* PMSTA15705 - DDV - 121226 - Purify, call blk_done to clean blk struct (with CS_BLK_ALL) */
        SYB_BcpDone(_blkdef, outRowNb, TRUE);

        SYB_BcpFree(_blkdef);
    }

    return(RET_SUCCEED);
}


/************************************************************************
*************************************************************************
**
**    P R I V A T E      F U N C T I O N S
**
*************************************************************************
*************************************************************************/


/*************************************************************************
*
*   Function             : SYB_BcpDone
*
*   Description          : This function mark a complete bulk copy operation
*
*   Arguments            : blkdef      (in) : a pointer to a SYB_BLKDEF_ST in used
*                          action     (in) : precises either the bulk copy
*					operation is marked complete or cancelled  REF2421 - OCE - 980825
*                          outRowNb   (out) : number of rows bulk copied since
*                                             last call to SYB_BcpDone
*
*   Functions call       : None.
*
*   Return               : RET_CODE
*
*   Creation		  :
*
*   Last Modification    : REF3305 - AKO - 19990212
*                          PMSTA-23981 - 070716 - PMO : Financial server crash when launching report
*
 *************************************************************************/
STATIC RET_CODE SYB_BcpDone(SYB_BLKDEF_STP  _blkdef,                            /* PMSTA-23981 - 070716 - PMO */
                            int *           outRowNb,
                            FLAG_T          finalFlg)                           /* PMSTA15705 - DDV - 121226 - Purify */
{
    CS_INT            outRow    = 0 ; /* REF3305 */
    /* REF2421 - OCE - 980825 */
    /* Begin		  */
    CS_INT              mode = 2;

    /*
    ** Mark the complete bulk copy operation
    */
    if (_blkdef && _blkdef->blkdesc)
    {
 		/* PMSTA15705 - DDV - 121226 - Purify */
		if (finalFlg == TRUE)
		{
	        SYB_BcpSqlTrace(_blkdef, "blk_done(CS_BLK_ALL)");                   /* PMSTA-23981 - 070716 - PMO */
			mode=CS_BLK_ALL;
		}
		else
		{
	        SYB_BcpSqlTrace(_blkdef, "blk_done(CS_BLK_BATCH)");                 /* PMSTA-23981 - 070716 - PMO */
			mode=CS_BLK_BATCH;
		}

        CS_RETCODE ret = (EV_rxaFctStruct.pfn_blk_done(_blkdef->blkdesc, mode, &outRow));

        SYB_BcpSqlTraceEnd();

        if (ret != CS_SUCCEED)
        {
	        if (outRowNb != NULL)
		        *outRowNb = 0;
	        return(RET_DBA_ERR_INSERT_FAILED);
        }
    }
    if (outRowNb != NULL)
    *outRowNb = (int)outRow;

	/* REF9125 - RAK - 031104 - Verify that we have insert all the asked rows */
	if (outRow != _blkdef->parentDef->curRow)
		return(RET_DBA_ERR_INSERT_FAILED);
	else
		return(RET_SUCCEED);
}
/* End			  */
/* REF2421 - OCE - 980825 */


/*************************************************************************
*
*   Function             : SYB_BcpExec
*
*   Description          :
*
*   Arguments            :
*
*   Functions call       :
*
*   Return               : void
*
*   Last Modification    : REF4037 - PPA - 991011
*
 *************************************************************************/
STATIC RET_CODE SYB_BcpExecInsert(SYB_BLKDEF_STP    _blkdef,
				                  int               *outRowNb,
                                  const char        *objectName)    /* REF8728 - YST - 030213 */
{
    int            colNu     = 0;
    char           *display_buffer;  /* OCE - REF2421 - 980901 */
    CS_RETCODE     csRetCd;

    /*
    ** Ready to initialize bulk copy in table '_blkdef->tableName'
    */
    DATE_START_TIMER(10, TIMER_MASK_DED); /* OCE - REF2421 - 980901 */

    /*
    **  For each column
    */
	for (colNu = 0; colNu < _blkdef->parentDef->colNb; colNu++)
    {
        /*
        ** Get a description the column
        */
        if (EV_rxaFctStruct.pfn_blk_describe(_blkdef->blkdesc, colNu + 1, &_blkdef->datafmt[colNu]) != CS_SUCCEED)
        {
            DATE_STOP_TIMER(10, TIMER_MASK_DED); /* OCE - REF2421 - 980901 */
            SYB_BcpDone(_blkdef, outRowNb, FALSE);		/* REF3689 - OCE - 000508 *//* PMSTA15705 - DDV - 121226 - Purify */
            return(RET_DBA_ERR_INSERT_FAILED);
        }

		_blkdef->datafmt[colNu].count = _blkdef->parentDef->curRow;

        /*
        ** Arrange '_blkdef->datafmt[colNu]' according to DATATYPE_ENUM (SYB_ConvertFldToNumericAndSetParam)
        */
        SYB_BcpModifyDatafmt(_blkdef, colNu);

        SYB_BcpSqlTraceColBlkDef(_blkdef, colNu);

        if (EV_rxaFctStruct.pfn_blk_bind(_blkdef->blkdesc,
                                         colNu + 1,
                                         &_blkdef->datafmt[colNu],
                                         _blkdef->buffer[colNu],
                                         _blkdef->datalen[colNu],
                                         _blkdef->indicator[colNu]) != CS_SUCCEED)
        {
            DATE_STOP_TIMER(10, TIMER_MASK_DED); /* OCE - REF2421 - 980901 */
            SYB_BcpDone(_blkdef, outRowNb, FALSE);		/* REF3689 - OCE - 000508 *//* PMSTA15705 - DDV - 121226 - Purify */
            return(RET_DBA_ERR_INSERT_FAILED);
        }

        _blkdef->datafmt[colNu].count  = 0 ;
    }

    /*
    ** Bulk copy block of rows
    */
    SYB_BcpSqlTrace(_blkdef, "blk_rowxfer()");              /* PMSTA-23981 - 070716 - PMO */
    /*if (SV_rxaFctStruct.pfn_blk_rowxfer(_blkdef->blkdesc) == CS_FAIL)		 REF4256-PPA-10012000*/
    if ((csRetCd = EV_rxaFctStruct.pfn_blk_rowxfer(_blkdef->blkdesc)) != CS_SUCCEED)  /*REF4256-PPA-10012000*/
    {
        SYB_BcpSqlTraceEnd();
        DATE_STOP_TIMER(10, TIMER_MASK_DED); /* OCE - REF2421 - 980901 */
        SYB_BcpDone(_blkdef, outRowNb, FALSE);		/* REF3689 - OCE - 000508 *//* PMSTA15705 - DDV - 121226 - Purify */
        return(RET_DBA_ERR_INSERT_FAILED);
    }
    else
    {
        SYB_BcpSqlTraceEnd();
        if (SYB_BcpDone(_blkdef, outRowNb, FALSE) != RET_SUCCEED) /* PMSTA15705 - DDV - 121226 - Purify */
        {
            DATE_STOP_TIMER(10, TIMER_MASK_DED); /* OCE - REF2421 - 980901 */
            return(RET_DBA_ERR_INSERT_FAILED);
        }
    }

	_blkdef->parentDef->curRow = 0;

    /* REF4037 - RAK - 000302 */
    if ((display_buffer = (char *)CALLOC(150, sizeof(char *)))==(char *)NULL) /* REF7264 - LJE - 020205 */
        MSG_RETURN(RET_MEM_ERR_ALLOC);

    sprintf(display_buffer, "BCP wrote : (%%1) saved %s", objectName);
    MSG_LogSrvMesg(UNUSED, UNUSED, display_buffer, IntType, *outRowNb);
    FREE(display_buffer);

    return(RET_SUCCEED);
}


/*************************************************************************
*
*   Function             : SYB_BcpSqlTraceColBlkDef
*
*   Description          : This function initialize traces
*
*   Arguments            : blkdef      (in) : a pointer to an initialized SYB_BLKDEF_ST
*                          colNu       (in) : column number
*
*   Functions call       :
*
*   Return               : void
*
*                          REF10392 - LJE - 040624
*
*************************************************************************/
STATIC void SYB_BcpSqlTraceColBlkDef(SYB_BLKDEF_STP _blkdef, int colNu)
{
    int      i, bufStringIdx, bufLen;
    char    *sqlTrace, *posStr, *bufStr;

    if (EV_sqlFile != NULL && EV_SqlTraceParam > 1)
    {

        sqlTrace = (char *)CALLOC(1, 1024);

        sprintf(sqlTrace,
                "  BulkCopy   %s   table:%s   column#:%02d   record#:%04d  name:%-60.60s  datatype#:%02d : ",  /* DLA - PMSTA-12660 - 110826 */
                "blk_bind",
				_blkdef->parentDef->tableName,
                colNu,
				_blkdef->parentDef->curRow,
				_blkdef->datafmt[colNu].name,
				_blkdef->datafmt[colNu].datatype);

        MSG_SendSqlTrace(sqlTrace);
        FREE(sqlTrace);

        bufLen = (_blkdef->datafmt[colNu].maxlength + 30) * _blkdef->datafmt[colNu].count + 20;
        sqlTrace = (char *)CALLOC(bufLen , sizeof(char));
        posStr   = sqlTrace;

        strcpy(posStr, "  BulkCopy : ");
        posStr += strlen(posStr);

		/* REF10918 - RAK - 050113 - use index in buffer instead of i */
		bufStringIdx = 0;

        for (i=0; i<_blkdef->datafmt[colNu].count; i++)
        {
			switch (_blkdef->parentDef->fieldType[colNu])
		    {

        	    case NullDataType:
                case ExtensionType:
                case ChainedTypeType: /* PMSTA-34470 - LJE - 190122 */
                case MultiArrayType:
                case ArrayType:
                    strcpy(posStr, " ??? ");
                    break;

        	    case AmountType	 :
                    sprintf(posStr, "%f", ((AMOUNT_T*)_blkdef->buffer[colNu])[i]);
                    break;
        	    case NumberType :
                    sprintf(posStr, "%f", ((NUMBER_T*)_blkdef->buffer[colNu])[i]);
                    break;
        	    case PercentType:
                    sprintf(posStr, "%f", ((PERCENT_T*)_blkdef->buffer[colNu])[i]);
                    break;
        	    case LongamountType :
                    sprintf(posStr, "%f", ((LONGAMOUNT_T*)_blkdef->buffer[colNu])[i]);
                    break;

        	    case DateType	 :
                    {
                        YEAR_T y; MONTH_T m; DAY_T d;
                        DATE_Get(((DATE_T*)_blkdef->buffer[colNu])[i],&y,&m,&d);
                        sprintf(posStr, "%02d/%02d/%04d",d,m,y);
				    }
				    break;

        	    case DatetimeType:
                    {
                        YEAR_T y; MONTH_T m; DAY_T d; HOUR_T h;MINUTE_T min;SECOND_T s;
                        DATETIME64_ST datetime = ((DATETIME64_ST*)_blkdef->buffer[colNu])[i];

                        DATE_Get(datetime.date(),&y,&m,&d);
                        TIME_Get(datetime.time(),&h,&min,&s);

                        sprintf(posStr, "%02d/%02d/%04d %02d:%02d:%02d ",d,m,y,h,min,s); /* REF10918 - LJE - 050111 */
				    }
				    break;

        	    case TimeType   :
                    {
                        HOUR_T h;MINUTE_T min;SECOND_T s;
                        TIME_T time;

                        time = ((TIME_T*)_blkdef->buffer[colNu])[i];

                        TIME_Get(time,&h,&min,&s);

                        sprintf(posStr, "%02d:%02d:%02d ",h,min,s);
				    }
				    break;


        	    case EnumType:
                    sprintf(posStr, "%d", ((ENUM_T*)_blkdef->buffer[colNu])[i]);
                    break;
        	    case IntType:
                    sprintf(posStr, "%d", ((INT_T*)_blkdef->buffer[colNu])[i]);
                    break;
        	    case LongintType:
                    sprintf(posStr, "%" szFormatId, ((ID_T*)_blkdef->buffer[colNu])[i]);
                    break;
        	    case FlagType:
                    sprintf(posStr, "%d", ((FLAG_T*)_blkdef->buffer[colNu])[i]);
                    break;
        	    case TinyintType:
                    sprintf(posStr, "%d", ((TINYINT_T*)_blkdef->buffer[colNu])[i]);
                    break;
        	    case YearType   :
                    sprintf(posStr, "%d", ((YEAR_T*)_blkdef->buffer[colNu])[i]);
                    break;
        	    case IdType:
                    sprintf(posStr, "%" szFormatId, ((ID_T*)_blkdef->buffer[colNu])[i]); /* DLA - PMSTA08801 - 100211 */
                    break;
        	    case PeriodType :
                    sprintf(posStr, "%d", ((PERIOD_T*)_blkdef->buffer[colNu])[i]);
                    break;
        	    case SmallintType:
                    sprintf(posStr, "%d", ((SMALLINT_T*)_blkdef->buffer[colNu])[i]);
                    break;
        	    case MethodType:
                    sprintf(posStr, "%d", ((METHOD_T*)_blkdef->buffer[colNu])[i]);
                    break;
        	    case MaskType:
                    sprintf(posStr, "%d", ((MASK_T*)_blkdef->buffer[colNu])[i]);
                    break;

				case EnumMaskType:
					sprintf(posStr, "%" szFormatId, ((ENUMMASK_T*)_blkdef->buffer[colNu])[i]);
                    break;

        	    case DictType:
                    sprintf(posStr, "%" szFormatId, ((DICT_T*)_blkdef->buffer[colNu])[i]); /* DLA - PMSTA08801 - 100211 */
                    break;

        	    case ExchangeType:
                    sprintf(posStr, "%18.9f", ((EXCHANGE_T*)_blkdef->buffer[colNu])[i]);
                    break;
					
				case PriceType:
					sprintf(posStr, "%23.14f", ((PRICE_T*)_blkdef->buffer[colNu])[i]);
					break;	

        	    case CodeType:
        	    case NameType:
        	    case LongnameType:
        	    case PhoneType:
        	    case SysnameType:
                case LongSysnameType: /* PMSTA-14086 - LJE - 121008 */
        	    case TextType:
        	    case UrlType:
        	    case ShortinfoType:
                case NoteType:
                case InfoType:
                case String1000Type : /* DLA - PMSTA07121 - 090210 */
                case String2000Type :
                case String3000Type :
                case String4000Type :
                case String7000Type :
                case String15000Type:

					/* REF10918 - RAK - 050113 - use index in buffer instead of i */
					if (_blkdef->datalen[colNu][i] > 0)
					{
						bufStr = (char*)_blkdef->buffer[colNu];
						bufStr = &(bufStr[bufStringIdx]);

						strncpy(posStr, bufStr, _blkdef->datalen[colNu][i]);
						posStr[_blkdef->datalen[colNu][i]] = '\0';

						bufStringIdx += _blkdef->datalen[colNu][i];
					}
					break;

                case UniCodeType :
                case UniInfoType :
                case UniLongnameType :
                case UniNameType :
                case UniNoteType :
                case UniPhoneType :
                case UniShortinfoType :
                case UniSysnameType :
                case UniTextType :
                case UniUrlType :
                case UniString1000Type : /* DLA - PMSTA07121 - 090210 */
                case UniString2000Type :
                case UniString3000Type :
                case UniString4000Type :
                case UniString7000Type :
                case UniString15000Type:

					/* REF10918 - RAK - 050113 - use index in buffer instead of i */
					if (_blkdef->datalen[colNu][i] > 0)
					{
						bufStr = (char*)_blkdef->buffer[colNu];
						bufStr = &(bufStr[bufStringIdx]);

						ICU4AAA_ConvertToASCII((UChar*)bufStr, -1, posStr, bufLen-SYS_StrLen(sqlTrace), NULL);
						posStr[_blkdef->datalen[colNu][i]/sizeof(UChar)] = '\0';

						bufStringIdx += _blkdef->datalen[colNu][i];
					}
                    break;

    		}

            posStr += strlen(posStr);

            sprintf(posStr, ":%d:%d#", _blkdef->indicator[colNu][i], _blkdef->datalen[colNu][i]);
            posStr += strlen(posStr);

        }

        MSG_SendSqlTrace(sqlTrace);
        SYB_BcpSqlTraceEnd();
        FREE(sqlTrace);
    }
}

/*************************************************************************
*
*   Function             : SYB_BcpSqlTrace
*
*   Description          : This function initialize traces
*
*   Arguments            : blkdef      (in) : a pointer to an initialized SYB_BLKDEF_ST
*                          str         (in) : a commentary
*
*   Functions call       : MSG_SendSqlTrace
*
*   Return               : void
*
*   Last modif.          : PMSTA-16124 - 250413 - PMO : Ensure coherence of printf / scanf formats with 32bits / 64 bits datatypes
*                          PMSTA-23981 - 070716 - PMO : Financial server crash when launching report
*                          PMSTA-24981 - 151116 - PMO : pid: threadid: missing form trace
*
*************************************************************************/
STATIC void SYB_BcpSqlTrace(SYB_BLKDEF_STP _blkdef, const char *str)  /* PMSTA-23981 - 070716 - PMO / REF8728 - YST - 030213 */
{
    if (EV_sqlFile != nullptr)
    {
        std::string sqlTrace;                                   /* PMSTA-24981 - 151116 - PMO */

        SYS_StringFormat(sqlTrace,
                        "  BulkCopy   %s   table:%s   column#:%d   record#:%d Connect=%-9d Thread=",
                        str,
                        _blkdef->parentDef->tableName,
				        _blkdef->parentDef->colNb,
				        _blkdef->parentDef->curRow,
				        _blkdef->parentDef->connectNo);

        sqlTrace += SYS_GetThreadDescriptionForLog();           /* PMSTA-24981 - 151116 - PMO */

        MSG_SendSqlTrace(sqlTrace.c_str());
    }
}

/*************************************************************************
*
*   Function             : SYB_BcpSqlTraceEnd
*
*   Description          : This function terminates traces
*
*   Arguments            :
*
*   Functions call       :
*
*   Return               : void
*
*************************************************************************/
STATIC void SYB_BcpSqlTraceEnd()
{
    if (EV_sqlFile != NULL)
        MSG_SendSqlTrace("ct_cancel");
}




/*************************************************************************
*
*   Function             : SYB_BcpModifyDatafmt
*
*   Description          :
*
*   Arguments            :
*
*   Functions call       :
*
*   Return               : void
*
*************************************************************************/
STATIC RET_CODE SYB_BcpModifyDatafmt(SYB_BLKDEF_STP     _blkdef,
                                     int                 colNu)
{

    /*
    ** Arrange '_blkdef->datafmt[colNu]' according to DATATYPE_ENUM (SYB_ConvertFldToNumericAndSetParam)
    */
    switch (_blkdef->parentDef->fieldType[colNu])
    {
        case CodeType:
            _blkdef->datafmt[colNu].datatype = CS_CHAR_TYPE;
            _blkdef->datafmt[colNu].format = CS_FMT_NULLTERM;
            _blkdef->datafmt[colNu].maxlength = GET_MAXLEN(_blkdef->parentDef->fieldType[colNu]) + 1;
            break;

        case DateType:
            _blkdef->datafmt[colNu].datatype = CS_INT_TYPE;
            _blkdef->datafmt[colNu].format = CS_FMT_UNUSED;
            _blkdef->datafmt[colNu].maxlength = sizeof(CS_INT);
            break;

        case DatetimeType:
            _blkdef->datafmt[colNu].datatype = CS_FLOAT_TYPE;
            _blkdef->datafmt[colNu].format = CS_FMT_UNUSED;
            _blkdef->datafmt[colNu].maxlength = sizeof(CS_FLOAT);
            break;

        case DictType:
            _blkdef->datafmt[colNu].datatype = CS_BIGINT_TYPE;  /* PMSTA08801 - DLA - 091126 */
            _blkdef->datafmt[colNu].maxlength = sizeof(CS_BIGINT);
            _blkdef->datafmt[colNu].format = CS_FMT_UNUSED;
            _blkdef->datafmt[colNu].precision = 18;
            _blkdef->datafmt[colNu].scale = 0;
            break;

        case EnumType:
            _blkdef->datafmt[colNu].datatype = CS_TINYINT_TYPE;
            _blkdef->datafmt[colNu].format = CS_FMT_UNUSED;
            _blkdef->datafmt[colNu].maxlength = sizeof(CS_TINYINT);
            break;

        case ExchangeType:
            _blkdef->datafmt[colNu].datatype = CS_FLOAT_TYPE;
            _blkdef->datafmt[colNu].format = CS_FMT_UNUSED;
            _blkdef->datafmt[colNu].maxlength = sizeof(CS_FLOAT);
            _blkdef->datafmt[colNu].precision = 18;
            _blkdef->datafmt[colNu].scale = 0;
            break;

        case FlagType:
            _blkdef->datafmt[colNu].datatype = CS_TINYINT_TYPE;
            _blkdef->datafmt[colNu].format = CS_FMT_UNUSED;
            _blkdef->datafmt[colNu].maxlength = sizeof(CS_TINYINT);
            break;

        case IdType:
            _blkdef->datafmt[colNu].datatype = CS_BIGINT_TYPE; /* PMSTA08801 - DLA - 091126 */
            _blkdef->datafmt[colNu].maxlength = sizeof(CS_BIGINT);
            _blkdef->datafmt[colNu].format = CS_FMT_UNUSED;
            _blkdef->datafmt[colNu].precision = 18;
            _blkdef->datafmt[colNu].scale = 0;
            break;

        case InfoType:
            _blkdef->datafmt[colNu].datatype = CS_CHAR_TYPE;
            _blkdef->datafmt[colNu].format = CS_FMT_NULLTERM;
            _blkdef->datafmt[colNu].maxlength = GET_MAXLEN(_blkdef->parentDef->fieldType[colNu]) + 1;
            break;

        case IntType:
        case MaskType:
            _blkdef->datafmt[colNu].datatype = CS_INT_TYPE;
            _blkdef->datafmt[colNu].format = CS_FMT_UNUSED;
            _blkdef->datafmt[colNu].maxlength = sizeof(CS_INT);
            break;

        case EnumMaskType:
            _blkdef->datafmt[colNu].datatype = CS_BIGINT_TYPE; /* PMSTA13460 - TGU - 120423 */
            _blkdef->datafmt[colNu].maxlength = sizeof(CS_BIGINT);
            _blkdef->datafmt[colNu].format = CS_FMT_UNUSED;
            break;

        case LongnameType:
            _blkdef->datafmt[colNu].datatype = CS_CHAR_TYPE;
            _blkdef->datafmt[colNu].format = CS_FMT_NULLTERM;
            _blkdef->datafmt[colNu].maxlength = GET_MAXLEN(_blkdef->parentDef->fieldType[colNu]) + 1;
            break;

        case MethodType:
            _blkdef->datafmt[colNu].datatype = CS_TINYINT_TYPE;
            _blkdef->datafmt[colNu].format = CS_FMT_UNUSED;
            _blkdef->datafmt[colNu].maxlength = sizeof(CS_TINYINT);
            break;

        case NameType:
            _blkdef->datafmt[colNu].datatype = CS_CHAR_TYPE;
            _blkdef->datafmt[colNu].format = CS_FMT_NULLTERM;
            _blkdef->datafmt[colNu].maxlength = GET_MAXLEN(_blkdef->parentDef->fieldType[colNu]) + 1;
            break;

        case NumberType:
            _blkdef->datafmt[colNu].datatype = CS_FLOAT_TYPE;
            _blkdef->datafmt[colNu].format = CS_FMT_UNUSED;
            _blkdef->datafmt[colNu].maxlength = sizeof(CS_FLOAT);
            _blkdef->datafmt[colNu].precision = 18;
            _blkdef->datafmt[colNu].scale = 0;
            break;

        case PercentType:
            _blkdef->datafmt[colNu].datatype = CS_FLOAT_TYPE;
            _blkdef->datafmt[colNu].format = CS_FMT_UNUSED;
            _blkdef->datafmt[colNu].maxlength = sizeof(CS_FLOAT);
            _blkdef->datafmt[colNu].precision = 18;
            _blkdef->datafmt[colNu].scale = 0;
            break;

        case PeriodType:
            _blkdef->datafmt[colNu].datatype = CS_SMALLINT_TYPE;
            _blkdef->datafmt[colNu].format = CS_FMT_UNUSED;
            _blkdef->datafmt[colNu].maxlength = sizeof(CS_SMALLINT);
            break;

        case PhoneType:
            _blkdef->datafmt[colNu].datatype = CS_CHAR_TYPE;
            _blkdef->datafmt[colNu].format = CS_FMT_NULLTERM;
            _blkdef->datafmt[colNu].maxlength = GET_MAXLEN(_blkdef->parentDef->fieldType[colNu]) + 1;
            break;
			
		case PriceType:
			_blkdef->datafmt[colNu].datatype = CS_FLOAT_TYPE;
			_blkdef->datafmt[colNu].format = CS_FMT_UNUSED;
			_blkdef->datafmt[colNu].maxlength = sizeof(CS_FLOAT);
			_blkdef->datafmt[colNu].precision = 18;
			_blkdef->datafmt[colNu].scale = 0;
			break;	

        case SmallintType:
            _blkdef->datafmt[colNu].datatype = CS_SMALLINT_TYPE;
            _blkdef->datafmt[colNu].format = CS_FMT_UNUSED;
            _blkdef->datafmt[colNu].maxlength = sizeof(CS_SMALLINT);
            break;

        case LongintType:  /*  FIH-REF8832-030307  */
        case TimeStampType:
        case TimeStampTType:
            _blkdef->datafmt[colNu].datatype = CS_BIGINT_TYPE;
            _blkdef->datafmt[colNu].maxlength = sizeof(CS_BIGINT);
            _blkdef->datafmt[colNu].format = CS_FMT_UNUSED;
            break;

        case BlobType:     /*  FIH-REF8832-030307  */
            _blkdef->datafmt[colNu].datatype = CS_IMAGE_TYPE;
            _blkdef->datafmt[colNu].format = CS_FMT_UNUSED;
            _blkdef->datafmt[colNu].maxlength = sizeof(CS_IMAGE);
            break;

        case SysnameType:
            _blkdef->datafmt[colNu].datatype = CS_CHAR_TYPE;
            _blkdef->datafmt[colNu].format = CS_FMT_NULLTERM;
            _blkdef->datafmt[colNu].maxlength = GET_MAXLEN(_blkdef->parentDef->fieldType[colNu]) + 1;
            break;

        case LongSysnameType: /* PMSTA-14086 - LJE - 121008 */
            _blkdef->datafmt[colNu].datatype = CS_CHAR_TYPE;
            _blkdef->datafmt[colNu].format = CS_FMT_NULLTERM;
            _blkdef->datafmt[colNu].maxlength = GET_MAXLEN(_blkdef->parentDef->fieldType[colNu]) + 1;
            break;

        case TextType:
            _blkdef->datafmt[colNu].datatype = CS_TEXT_TYPE;
            _blkdef->datafmt[colNu].format = CS_FMT_NULLTERM;
            _blkdef->datafmt[colNu].maxlength = GET_MAXLEN(_blkdef->parentDef->fieldType[colNu]) + 1;
            break;

        case TinyintType:
            _blkdef->datafmt[colNu].datatype = CS_TINYINT_TYPE;
            _blkdef->datafmt[colNu].format = CS_FMT_UNUSED;
            _blkdef->datafmt[colNu].maxlength = sizeof(CS_TINYINT);
            break;

        case AmountType:
            _blkdef->datafmt[colNu].datatype = CS_FLOAT_TYPE;
            _blkdef->datafmt[colNu].format = CS_FMT_UNUSED;
            _blkdef->datafmt[colNu].maxlength = sizeof(CS_FLOAT);
            _blkdef->datafmt[colNu].precision = 18;
            _blkdef->datafmt[colNu].scale = 0;
            break;

        case ShortinfoType:
            _blkdef->datafmt[colNu].datatype = CS_CHAR_TYPE;
            _blkdef->datafmt[colNu].format = CS_FMT_NULLTERM;
            _blkdef->datafmt[colNu].maxlength = GET_MAXLEN(_blkdef->parentDef->fieldType[colNu]) + 1;
            break;

        case LongamountType:
            _blkdef->datafmt[colNu].datatype = CS_FLOAT_TYPE;
            _blkdef->datafmt[colNu].format = CS_FMT_UNUSED;
            _blkdef->datafmt[colNu].maxlength = sizeof(CS_FLOAT);
            _blkdef->datafmt[colNu].precision = 18;
            _blkdef->datafmt[colNu].scale = 0;
            break;

        case UrlType:      /*  FIH-REF8832-030218  */
        case NoteType:
            _blkdef->datafmt[colNu].datatype = CS_CHAR_TYPE;
            _blkdef->datafmt[colNu].format = CS_FMT_NULLTERM;
            _blkdef->datafmt[colNu].maxlength = GET_MAXLEN(_blkdef->parentDef->fieldType[colNu]) + 1;
            break;

            /*case MaskType:
             break;*/

        case TimeType:
        case YearType:
        case ExtensionType:
        case ChainedTypeType: /* PMSTA-34537 - LJE - 190129 */
        case ArrayType:
        case MultiArrayType:
            break;

        case String1000Type: /* DLA - PMSTA07121 - 090210 */
        case String2000Type:
        case String3000Type:
        case String4000Type:
        case String7000Type:
        case String15000Type:
            _blkdef->datafmt[colNu].datatype = CS_LONGCHAR_TYPE;
            _blkdef->datafmt[colNu].format = CS_FMT_NULLTERM;
            _blkdef->datafmt[colNu].maxlength = GET_MAXLEN(_blkdef->parentDef->fieldType[colNu]) + 1;
            break;

            /* PMSTA13335 - DDV - 111202 - Add unicode datatypes */
        case UniInfoType:
        case UniCodeType:
        case UniLongnameType:
        case UniNameType:
        case UniNoteType:
        case UniPhoneType:
        case UniShortinfoType:
        case UniSysnameType:
        case UniTextType:
        case UniUrlType:
        case UniString1000Type: /* PMSTA13599 - DDV - 120209 - Datatype is missing */
        case UniString2000Type: /* PMSTA13599 - DDV - 120209 - Datatype is missing */
        case UniString3000Type:
        case UniString4000Type:
        case UniString7000Type:
        case UniString15000Type:
            _blkdef->datafmt[colNu].datatype = CS_UNICHAR_TYPE;
            _blkdef->datafmt[colNu].format = CS_FMT_NULLTERM;
            _blkdef->datafmt[colNu].maxlength = (GET_MAXLEN(_blkdef->parentDef->fieldType[colNu]) + 1) * sizeof(UChar);
            break;

        default:
            break;
    }

    _blkdef->datafmt[colNu].locale = NULL;

    return RET_SUCCEED;
}

/*************************************************************************
*
*   Function             : SYB_BcpFree
*
*   Description          : This function frees memory used for bulkcpy
*
*   Arguments            : blkdef      (in) : a pointer to a SYB_BLKDEF_ST in used
*
*   Functions call       : None.
*
*   Return               : RET_CODE
*
*   Last modif.          : PMSTA-23981 - 070716 - PMO : Financial server crash when launching report
*
*************************************************************************/
void SYB_BcpFree(SYB_BLKDEF_STP & _blkdef)                                      /* PMSTA-23981 - 070716 - PMO */
{
    if (_blkdef)
    {
        for (int colNu = 0 ; colNu < _blkdef->parentDef->colNb ; colNu++)
        {
            if (_blkdef->buffer && _blkdef->buffer[colNu])
            {
                FREE(_blkdef->buffer[colNu]);
            }
            if (_blkdef->datalen && _blkdef->datalen[colNu])
            {
                FREE(_blkdef->datalen[colNu]);
            }
            if (_blkdef->indicator && _blkdef->indicator[colNu])
            {
                FREE(_blkdef->indicator[colNu]);
            }
        }

        if (_blkdef->blkdesc)
        {
            EV_rxaFctStruct.pfn_blk_drop(_blkdef->blkdesc);
            _blkdef->blkdesc = NULL;
        }

        FREE(_blkdef->datafmt);
        FREE(_blkdef->buflen);
        FREE(_blkdef->buffer);
        FREE(_blkdef->datalen);
        FREE(_blkdef->indicator);
        FREE(_blkdef);
    }
}

/************************************************************************
**      END             sybbcp.c
*************************************************************************/






/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef SybConnection_H_
#define SybConnection_H_
#include <vector>
#include "dbiconnection.h"
#include "unidef.h"
#include "gen.h"
#include "syb.h"
#include "date.h"

typedef struct DBI_BLKDEF_STRUCT *  DBI_BLKDEF_STP;

class SYB_MsgError : public DBI_MsgError
{
public:
    SYB_MsgError();
    virtual ~SYB_MsgError();
    SYB_MsgError &          operator=(const SYB_MsgError &) = delete;

    static RET_CODE         getRetCode(SYB_ERROR_CODE_ENUM);
};

class SybBatchBind
{
public:

    SybBatchBind()
        : len(0)
        , indicator(CS_NULLDATA)
        , dblValue(0.0)
        , tinyint(0)
        , smallint(0)
        , intValue(0)
        , bigint(0)
        , charPtr(nullptr)
        , uniCharPtr(nullptr)
        , imagePtr(nullptr)
    {
        memset(&this->csDataFmt, 0, sizeof(this->csDataFmt));
        memset(&this->csDataFmtSrc, 0, sizeof(this->csDataFmtSrc));
        memset(&this->numeric, 0, sizeof(this->numeric));
        memset(&this->datetime, 0, sizeof(this->datetime));
        memset(&this->datetimeSmall, 0, sizeof(this->datetimeSmall));
        memset(&this->binary, 0, sizeof(this->binary));
    };

    virtual ~SybBatchBind()
    {
    };

    SybBatchBind &operator=(const SybBatchBind &) = delete;

    CS_INT         len;
    CS_SMALLINT    indicator;

    CS_DATAFMT     csDataFmt;
    CS_DATAFMT     csDataFmtSrc;
    CS_NUMERIC     numeric;
    CS_FLOAT       dblValue;
    CS_DATETIME    datetime;
    CS_DATETIME4   datetimeSmall;
    CS_BINARY      binary[8];
    CS_TINYINT     tinyint;
    CS_SMALLINT    smallint;
    CS_INT         intValue;
    CS_BIGINT      bigint;
    CS_CHAR       *charPtr;
    UChar         *uniCharPtr;
    CS_IMAGE      *imagePtr;
};

class SybConnection : public DbiConnection
{
public:
	SybConnection(const AAAConnectionSpecification& spec, const int& id);
    virtual ~SybConnection();                                           /* PMSTA-24076 - 180716 - PMO */

    SybConnection            (const SybConnection &) = delete;          /* PMSTA-24076 - 180716 - PMO */
    SybConnection & operator=(const SybConnection &) = delete;          /* PMSTA-24076 - 180716 - PMO */


	static AAAConnection*  createConnection(const AAAConnectionSpecification& spec, const int& id);

    CS_COMMAND  *getCS_COMMAND(const char *, const int, const std::string &);
    std::string  getLabelRetCode(CS_RETCODE &);

	virtual bool doConnect();
    virtual bool doDisconnect();

    virtual PTR  getConnectionPtr();
    virtual PTR  getCommandPtr();

    virtual RET_CODE createStatement(const std::string &sql, DBA_ACTION_ENUM action);

    virtual RET_CODE         doAddBatch();
    RET_CODE                 doAddBatchLang();
    RET_CODE                 doAddBatchDyn();
    RET_CODE                 bcpModifyDatafmt(DbiInOutData*);
    RET_CODE                 doAddBatchBCP();
    virtual RET_CODE         doExecuteBatch();

    virtual int              getColumnCount();
    virtual RET_CODE         getColumnName(int, std::string &);
    virtual RET_CODE         getColumnType(int, CTYPE_ENUM &);
    virtual int              getPrecision(int);
    virtual int              getScale(int);
    virtual int              getColumnMaxLength(int);
    virtual int              getColumnDisplaySize(int);

    virtual bool             isBcpAllowed();

    virtual void manageError();
    virtual std::string getDefaultCharset();
    virtual std::string getConnectionCharset();
    virtual bool        isUtf16Allowed();

    virtual void clearPassword();

	bool changePassword(const PasswordEncrypted& password);
	bool changePassword(const  std::string& user, const PasswordEncrypted& password);

    void setDateTimeFormat(DATE_STYLE_ENUM  inDateTimeStyleEn);

    RET_CODE setAppContextProperty(const std::string &propertyName, const std::string &propertyValue);

    virtual RET_CODE doBeginTransaction();
    virtual RET_CODE doEndTransaction(const FLAG_T status);
    virtual RET_CODE getNextResultSet();
    virtual RET_CODE setParameters(char **sqlTraceStrPtr);

    RET_CODE setOneParameter(DbiInOutData      *inputData,
                             const std::string &paramName,
                             bool               isOutputParam,
                             CS_DATAFMT        &csDataFmt);

    virtual RET_CODE doSendCommand(DBA_DYNST_ENUM outputSt = NullDynSt);
    virtual int      sendRequest(DBI_INT * resultType);
    virtual RET_CODE doReleaseCommand();
    virtual bool     isDbTransactionRequired();
    virtual bool     isDdlGenOnTran();
    virtual RET_CODE prepareReceivedData();
    virtual RET_CODE bindRecvDynSt(DBA_DYNST_ENUM dynStType, DBA_DYNFLD_STP bindData);
    virtual RET_CODE bindRecvDynSqlEntity(OBJECT_ENUM object, DBA_DYNST_ENUM dynStType, DBA_DYNFLD_STP bindData);
    virtual RET_CODE colBind(int, DATATYPE_ENUM, const std::string&, DBI_PTR, size_t, DBI_INT*, DBI_SMALLINT*, bool dynFldFlag, unsigned char* nullIndicatorDynFld, DbiInOutData*);
    virtual RET_CODE fetch();
    virtual RET_CODE copyNullFlagsAndLengthDynSt(DBA_DYNFLD_STP, DBA_DYNST_ENUM);
    virtual RET_CODE processAllResults(DBI_INT *status, OBJECT_ENUM object = NullEntityCst, DBA_DYNST_ENUM dynStEnum = NullDynSt, DBA_DYNFLD_STP record = NULLDYNST, DBA_PROC_STP procedure = NULL);
    RET_CODE processAllBatchResults();

    virtual RET_CODE cancelDbRequest(int level, int mode);

    virtual RET_CODE setConnMaxRows(int);   /* DLA - PMSTA-26898 - 170426 */

    virtual void enableOutput();
    virtual void disableOutput();

    virtual int getTransState();

    virtual RET_CODE    disableIdentity(std::string, std::string);
    virtual RET_CODE    enableIdentity(std::string, std::string);

    virtual RET_CODE getLastCmdRetCode();
    virtual RET_CODE getCmdRetCode(int msgNo);

    virtual bool isSamePasswordMsg();
    virtual bool isWarningMsgToHide(const DbaErrmsgInfosClass &);

    virtual bool     convParamFromPos(std::string&, std::string::size_type&, int, const std::string&);

    virtual RET_CODE convertToRetCode(int);

    /* PMSTA-32315 - 260718 - PMO
     * Short ugly fix to avoid concurrency problem with SV_LastSybClSeverity
     * Refactoring has to be done with Sybase & Oracle data
     * There are also a lot of memeset on this object that has to be removed
     */
    int getLastSybClSeverity()
    {
        return this->m_lastSybClSeverity;
    }

    void setLastSybClSeverity(int severity)
    {
        /* keep the highest level */
        if (severity > this->m_lastSybClSeverity)
        {
            this->m_lastSybClSeverity = severity;
        }
    }

    void resetLastSybClSeverity()
    {
        this->m_lastSybClSeverity = -1;
    }

    CS_CONNECTION *              m_connection;                     /* pointer on CONNECTION structure, depends of the RDBMS */
    CS_COMMAND *                 m_command;                        /* pointer on COMMAND structure*/
    int                          m_mode;
    int                          m_lastSybClSeverity;              /* Last sybase client severity PMSTA-32315 - 260718 - PMO */
    SYB_COMMAND_ENUM             m_currentCmd;

private:
    std::vector<SybBatchBind>    m_batchBindVector;
    std::stringstream            m_batchStream;
    MemoryPool                   m_batchMp;

    char                        *m_sqlTraceStrPtr;
    SYB_MsgError                 m_msgErrorHelper;

    CS_DATAFMT	                 m_datafmt;	        /* hold the variable descriptions  */
    CS_BLKDESC	                *m_blkdesc;
};

#endif

/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef SYB_H
#define SYB_H

#include <string>
#include <stdarg.h>

#ifndef __CSPUBLIC_H__
#include <cspublic.h>
#endif

#include "conspec.h"
#include "dbi.h"

class SybConnection;

/************************************************************************
**      Constant & Macro definitions
*************************************************************************/

#define CS_UNICHAR_FROM_TEXT_TYPE (CS_USER_TYPE + 1)
#define CS_USER_TIMESTAMP         (CS_USER_TYPE + 3)    /* 2 is used by CS_INT64_TYPE          REF11780 - 100406 - PMO */

#define SYB_LINE_FEED  10

#define SYB_MAX_HEADER 1024
#define SYB_MAX_SEVERITY 50
#define SYB_MAX_TMPBUF 100

#define GET_NULLFLAGS(c)   (SV_ConnectionList[c].nullFlags)
#define GET_FIELDLENGTH(c) (SV_ConnectionList[c].fieldLength)

/* PMSTA13362 - DDV - 120315 - Move definition from sybserv.c, syblib01.c and sybbcp.ch into syb.h */
#define SYBASE_VERSION CS_VERSION_157 /* DLA - REF8845 - 030227 */ /* PMSTA-13362 - LJE - 120309 */
#define SYBASE_BLK_VERSION BLK_VERSION_157 /* PMSTA13362 - DDV - 120213 - Also do it for BCP version */

/************************************************************************
**      Structures & typedef definitions
*************************************************************************/
typedef struct DBA_PROC_STRUCT DBA_PROC_ST, *DBA_PROC_STP;

typedef union {
	CS_NUMERIC      csNumeric;
	CS_BIT          csBit;
	CS_DATETIME     csDatetime;
	CS_DATETIME4    csDatetime4;
	CS_VARCHAR	    csVarchar;
	CS_INT		    csInt;
	CS_SMALLINT	    csSmallint;
	CS_TINYINT	    csTinyint;
	CS_FLOAT	    csFloat;
	CS_VOID        *csVoidPtr;
	CS_CHAR	       *csChar;
	CS_LONGCHAR	   *csLongchar;
	CS_UNICHAR *    csUnichar;                      /* PMSTA-13866 - 070312 - PMO */
	CS_BINARY       csTimeStamp[TIMESTAMP_T_LEN];   /* PMSTA-13866 - 070312 - PMO */
	CS_BIGINT       csBigint;
} SYB_DATA_UN, *SYB_DATA_UNP;

typedef enum {				/* REF3847 */
	Syb_Command_None = 0,
	Syb_Command_Bind,
	Syb_Command_Cancel,
	Syb_Command_Capability,
	Syb_Command_Close,
	Syb_command_CmdDrop,
	Syb_command_Command,
	Syb_Command_ConAlloc,
	Syb_Command_ConDrop,
	Syb_Command_ConProps,
	Syb_Command_Config,
	Syb_Command_Connect,
	Syb_Command_Cursor,
	Syb_Command_Describe,
	Syb_Command_Diag,
	Syb_Command_Fetch,
	Syb_Command_Init,
	Syb_Command_Options,
	Syb_Command_Param,
	Syb_Command_Poll,
	Syb_Command_Results,
	Syb_Command_Send
} SYB_COMMAND_ENUM;

enum class SYB_ERROR_CODE_ENUM
{
    MSGNB00001_SUCCEED                   = 1,
    MSGNB00515_ERR_NULLCOLVALUE1         = 515,
    MSGNB00530_ERR_NULLCOLVALUE2         = 530,
    MSGNB00640_ERR_NULLCOLVALUE3         = 640,
    MSGNB00546_ERR_FOREIGNKEY1           = 546,
    MSGNB17560_ERR_FOREIGNKEY2           = 17560,
    MSGNB00548_ERR_CHECKCONSTRAINT       = 548,
    MSGNB02601_ERR_DUPLICATEKEY1         = 2601,
    MSGNB02615_ERR_DUPLICATEKEY2         = 2615,
    MSGNB03604_ERR_DUPLICATEKEY3         = 3604,
    MSGNB07201_ERR_CONNFAILED1           = 7201,
    MSGNB07202_ERR_CONNFAILED2           = 7202,
    MSGNB07203_ERR_CONNFAILED3           = 7203,
    MSGNB07204_ERR_CONNFAILED4           = 7204,
    MSGNB07205_ERR_CONNFAILED5           = 7205,
    MSGNB07206_ERR_CONNFAILED6           = 7206,
    MSGNB07207_ERR_CONNFAILED7           = 7207,
    MSGNB07208_ERR_CONNFAILED8           = 7208,
    MSGNB07210_ERR_CONNFAILED9           = 7210,
    MSGNB07211_ERR_CONNFAILED10          = 7211,
    MSGNB07227_ERR_CONNFAILED11          = 7227,
    MSGNB00201_ERR_PARAMNOTSUPPLIED      = 201,
    MSGNB03607_ERR_DIVIDE_BY_ZERO        = 3607,
    MSGNB00220_ERR_DB_OVERFLOW1          = 220,
    MSGNB00227_ERR_DB_OVERFLOW2          = 227,
    MSGNB00232_ERR_DB_OVERFLOW3          = 232,
    MSGNB00247_ERR_DB_OVERFLOW4          = 247,
    MSGNB00517_ERR_DB_OVERFLOW5          = 517,
    MSGNB03606_ERR_DB_OVERFLOW6          = 3606,
    MSGNB00916_ERR_INVALID_USER_IN_DB    = 916,
    MSGNB03621_ERR_COMMAND_ABORTED       = 3621,
    MSGNB01105_ERR_DB_IS_FULL            = 1105,
    MSGNB00303_ERR_DB_TABLE1             = 303,
    MSGNB00304_ERR_DB_TABLE2             = 304,
    MSGNB00556_ERR_DB_TABLE3             = 556,
    MSGNB02767_ERR_DB_TABLE4             = 2767,
    MSGNB03723_ERR_DB_TABLE5             = 3723,
    MSGNB07908_ERR_DB_TABLE6             = 7908,
    MSGNB07934_ERR_DB_TABLE7             = 7934,
    MSGNB17394_ERR_DB_TABLE8             = 17394,
    MSGNB17395_ERR_DB_TABLE9             = 17395,
    MSGNB17396_ERR_DB_TABLE10            = 17396,
    MSGNB17397_ERR_DB_TABLE11            = 17397,
    MSGNB17398_ERR_DB_TABLE12            = 17398,
    MSGNB17399_ERR_DB_TABLE13            = 17399,
    MSGNB17400_ERR_DB_TABLE14            = 17400,
    MSGNB17401_ERR_DB_TABLE15            = 17401,
    MSGNB17492_ERR_DB_TABLE16            = 17492,
    MSGNB17563_ERR_DB_TABLE17            = 17563,
    MSGNB17742_ERR_DB_TABLE18            = 17742,
    MSGNB17743_ERR_DB_TABLE19            = 17743,
    MSGNB17744_ERR_DB_TABLE20            = 17744,
    MSGNB17745_ERR_DB_TABLE21            = 17745,
    MSGNB17746_ERR_DB_TABLE22            = 17746,
    MSGNB17747_ERR_DB_TABLE23            = 17747,
    MSGNB17748_ERR_DB_TABLE24            = 17748,
    MSGNB17749_ERR_DB_TABLE25            = 17749,
    MSGNB00504_ERR_STORED_PROC1          = 504,
    MSGNB02804_ERR_STORED_PROC2          = 2804,
    MSGNB02806_ERR_STORED_PROC3          = 2806,
    MSGNB02812_ERR_STORED_PROC4          = 2812,
    MSGNB07712_ERR_STORED_PROC5          = 7712,
    MSGNB00771_ERR_STORED_PROC6          = 771,
    MSGNB18041_ERR_STORED_PROC7          = 18041,
    MSGNB01139_ERR_DEADLOCK1             = 1139,
    MSGNB01205_ERR_DEADLOCK2             = 1205,
    MSGNB01248_ERR_DEADLOCK3             = 1248,
    MSGNB03210_ERR_DEADLOCK4             = 3210,
    MSGNB03309_ERR_DEADLOCK5             = 3309,
    MSGNB13093_ERR_DEADLOCK6             = 13093,
    MSGNB00229_ERR_PERM_DENIED1          = 229,
    MSGNB00230_ERR_PERM_DENIED2          = 230,
    MSGNB00262_ERR_PERM_DENIED3          = 262,
    MSGNB10330_ERR_PERM_DENIED4          = 10330,
    MSGNB00257_ERR_CONVERSION            = 257,
    MSGNB00101_ERR_SYNTAX                = 101,
    MSGNB00102_ERR_SYNTAX                = 102,
    MSGNB00148_ERR_SYNTAX                = 148,
    MSGNB00149_ERR_SYNTAX                = 149,
    MSGNB00156_ERR_SYNTAX                = 156,
    MSGNB00210_ERR_SYNTAX                = 210,
    MSGNB00211_ERR_SYNTAX                = 211,
    MSGNB00249_ERR_SYNTAX                = 249,
    MSGNB01273_ERR_SYNTAX                = 1273,
    MSGNB05129_ERR_SYNTAX                = 5129,
    MSGNB02007_ERR_SYNTAX                = 2007,
    MSGNB04408_ERR_LIMITEXCEED           = 4408,
    MSGNB00701_ERR_PROC_CACHE_MEMORY     = 701,
    MSGNB03814_ERR_INV_PARAM_VALUE       = 3814,
    MSGNB17720_ERR_NO_NUM_INPASSWORD1    = 17720,
    MSGNB09551_ERR_NO_NUM_INPASSWORD2    = 9551,
    MSGNB16908863_ERR_TIMED_OUT          = 16908863,
    MSGNB84083974_ERR_DISCONNECTED       = 84083974,
    MSGNB04002_ERR_LOGIN                 = 4002,
    MSGNB20289_INFO_EXTERNAL_SEQ         = MSG_INFO_EXTERNAL_SEQ,
    MSGNB02403_ERR_CHAR_SET_CONVERSION   = 2403,
    MSGNB0x1900000C_ERR_UNKNOWN_MSG      = 0x1900000C,
    MSGNB0x09000004_INFO_CLOSING_SUCCEED = 0x09000004
};


/************************************************************************
**      BEGIN External definitions attached to : syblib01.c
*************************************************************************/

extern CS_RETCODE CS_PUBLIC    SYB_ConvertDateToInt(CS_CONTEXT *context, CS_DATAFMT *srcfmt, CS_VOID *,
							CS_DATAFMT *destfmt, CS_VOID *destdata, CS_INT *destlen);

extern CS_RETCODE CS_PUBLIC    SYB_ConvertSmallDateToDouble(CS_CONTEXT *context, CS_DATAFMT *srcfmt, CS_VOID *,
								CS_DATAFMT *destfmt, CS_VOID *destdata, CS_INT *destlen);

extern CS_RETCODE CS_PUBLIC    SYB_ConvertDateToDouble(CS_CONTEXT *context, CS_DATAFMT *srcfmt, CS_VOID *,
							CS_DATAFMT *destfmt, CS_VOID *destdata, CS_INT *destlen);

extern CS_RETCODE CS_PUBLIC SYB_ConvertUnicodeToText(   /*  PCL-REF9303-030731  */
								CS_CONTEXT *context,
									CS_DATAFMT *srcfmt, CS_VOID *srcdata,
										CS_DATAFMT *destfmt, CS_VOID *destdata,
											CS_INT *destlen);

extern CS_RETCODE CS_PUBLIC SYB_ConvertTextToUnicode(CS_CONTEXT *context,
													 CS_DATAFMT *srcfmt, CS_VOID *srcdata,
													 CS_DATAFMT *destfmt, CS_VOID *destdata,
													 CS_INT *destlen);

extern CS_RETCODE CS_PUBLIC SYB_ConvertNum12_0ToInt64( CS_CONTEXT *,  CS_DATAFMT *,
													   CS_VOID    *,  CS_DATAFMT *,
													   CS_VOID    *,  CS_INT     *); /* PCL/DLA - REF9089 - 030513 */

extern CS_RETCODE CS_PUBLIC SYB_ConvertInt64ToNum12_0( CS_CONTEXT *,  CS_DATAFMT *,
													   CS_VOID    *,  CS_DATAFMT *,
													   CS_VOID    *,  CS_INT     *); /* PCL/DLA - REF9089 - 030513 */

extern CS_RETCODE CS_PUBLIC SYB_ConvertNum9_0ToInt( CS_CONTEXT *,  CS_DATAFMT *,
													CS_VOID    *,  CS_DATAFMT *,
													CS_VOID    *,  CS_INT     *); /* PCL/DLA - REF9089 - 030513 */

extern CS_RETCODE CS_PUBLIC SYB_ConvertIntToNum9_0( CS_CONTEXT *,  CS_DATAFMT *,
													CS_VOID    *,  CS_DATAFMT *,
													CS_VOID    *,  CS_INT     *); /* PCL/DLA - REF9089 - 030513 */

extern CS_RETCODE CS_PUBLIC SYB_ConvertTimeStampToInt64(CS_CONTEXT *,
														CS_DATAFMT *,
														CS_VOID    *,
														CS_DATAFMT *,
														CS_VOID    *,
														CS_INT     *);

extern RET_CODE       SYB_ConvDynFldToSybData(DBA_DYNFLD_STP, DATATYPE_ENUM, SYB_DATA_UNP, CS_DATAFMT*, FLAG_T);

extern RET_CODE       SYB_InitializeContext(const bool);
extern void           SYB_FreeSybCliContext();

extern int CS_PUBLIC SYB_HandleMsg(CS_CONTEXT *, CS_CONNECTION *, CS_CLIENTMSG *);
extern int CS_PUBLIC SYB_HandleSrvMsg(CS_CONTEXT *, CS_CONNECTION *, CS_SERVERMSG *);
extern int CS_PUBLIC SYB_ServerNotification(CS_CONNECTION *, CS_CHAR *, CS_INT);

extern void           SYB_PrintVersion();            /* DLA  - 030724 */

extern           bool SYB_CheckUserRole(SybConnection&, const std::string& role);
extern           bool SYB_CheckValidUserName(DbiConnection& dbiConn, const std::string& user_name);

extern CS_CONTEXT     *SYB_GetCsContext();

extern RET_CODE       SYB_DatetimeToSybDataStr(char *, DBA_DYNFLD_STP, int, int *); /* REF8844 - LJE - 030401 */
extern RET_CODE       SYB_SetGeneralCharset(CURRENTCHARSETCODE_ENUM);
extern RET_CODE       SYB_ConfigureClientLibrary(int);

/* PMSTA-nuodb - LJE - 190521 */
extern CS_RETCODE     SYB_CtCommand(SybConnection&, int, const char *, char **),
                      SYB_CtParam(SybConnection&, CS_DATAFMT *, CS_VOID *, CS_INT, CS_INT),
                      SYB_CtSend(SybConnection&),
                      SYB_CtResults(SybConnection&, CS_INT *),
                      SYB_CtBind(CS_COMMAND*, CS_INT, CS_DATAFMT*, CS_VOID*, CS_INT*, CS_SMALLINT *, CS_INT, char*);

extern RET_CODE       SYB_CtFetch(SybConnection&, CS_INT, CS_INT, CS_INT, CS_INT *),
                      SYB_DefineCtParam(SybConnection&     dbiConn,
                                          DbiInOutData      *inputData,
                                          const std::string &paramName,
                                          bool               isOutputParam,
                                          CS_DATAFMT        &csDataFmt,
                                          bool               bFristParam,
                                          char             **sqlTraceStrPtr);

extern void           SYB_SendSqlTrace(char **sqlTraceStrPtr);

extern CS_RETCODE CS_PUBLIC SYB_ConvertIntToDate(CS_CONTEXT *, CS_DATAFMT *, CS_VOID *, CS_DATAFMT *, CS_VOID *, CS_INT *);
extern CS_RETCODE CS_PUBLIC SYB_ConvertDoubleToDate(CS_CONTEXT *, CS_DATAFMT *, CS_VOID *, CS_DATAFMT *, CS_VOID *, CS_INT *);

extern void     SYB_SetCallBack_PasswordInitialization(void * (*)(void));
extern void     SYB_SetCallBack_PasswordEncrypt(bool (*)(void *, const char *));
extern void     SYB_PasswordDecrypt(char*,  const void * );
extern void     SYB_PasswordEncrypt(void *, const char * );
extern void     SYB_SetCallBack_PasswordDecrypt(bool (*)(char *, const void *));
extern void     SYB_SetCallBack_PasswordFree(void (*)(void *));
extern void     SYB_FreePassword(void **);

/************************************************************************
**      BEGIN External definitions attached to : syblib02.c
*************************************************************************/

extern RET_CODE SYB_InstallConversionFcts(void),
                SYB_BindRecvDynFld(DBA_DYNFLD_STP, INT_T, DATATYPE_ENUM, INT_T, DBI_SMALLINT *, DBI_INT *, CS_COMMAND *csCommand, CS_DATAFMT, FLAG_T), /* PMSTA08801 - DDV - 091209 *//* DLA - PMSTA08801 - 110103 */
				SYB_CopyNullFlagsAndLength(DbiConnection&, DBA_DYNFLD_STP, int, DATATYPE_ENUM),
                SYB_ColBind(DbiConnection&, int, int, PTR, DBI_INT *dataLength = nullptr, DBI_SMALLINT *nullData = nullptr),
                SYB_GetDataFmtForNumeric(DATATYPE_ENUM, CS_DATAFMT&, CS_DATAFMT&),
                SYB_RoundDblValue(DATATYPE_ENUM, double &),
                SYB_ConvertFldToNumeric(DATATYPE_ENUM, double, CS_DATAFMT&, CS_DATAFMT&, CS_NUMERIC&),
                SYB_ConvertFldToNumericAndSetParam(SybConnection&, DATATYPE_ENUM, double, CS_DATAFMT),
				SYB_SetProcParameters(SybConnection&, DBA_DYNST_ENUM, DBA_DYNFLD_STP, DBA_PROC_STP),
				SYB_SetInsUpdParameters(SybConnection&, OBJECT_ENUM, DBA_DYNST_ENUM, DBA_DYNFLD_STP,
										DBA_PROC_STP, char);
extern RET_CODE SYB_CopyNullFlagsAndLengthDynSt(DbiConnection&, DBA_DYNFLD_STP, DBA_DYNST_ENUM); /* REF8844 - LJE - 030407 */

extern CS_INT SYB_GetSybasePrecisionForDataType(DATATYPE_ENUM);
extern CS_INT SYB_GetSybaseScaleForDataType(DATATYPE_ENUM);

extern CS_INT SYB_ConvApplToSybType(DATATYPE_ENUM);
extern CS_INT SYB_GetSybTypeByCType(DATATYPE_ENUM);
extern CS_INT SYB_ServConvApplToSybType(DATATYPE_ENUM);

extern int SYB_CheckFieldCoherence(DBA_DYNFLD_STP, int, DATATYPE_ENUM);

extern RET_CODE SYB_SendLangRequest(SybConnection&, const char *, int *);
extern RET_CODE SYB_ProcessAllAccessResults(SybConnection&,
											int,
											int,
											DBA_ACCESS_STP,
											int *,
											DBA_DYNFLD_STP *,
											DBA_ACTION_ENUM,
											OBJECT_ENUM,
											int *,
											const int,
											DBA_PROC_STP); /* DLA - PMSTA08801 - 100325 */

extern int SYB_ProcessParamResult(DbiConnection&, /* DLA - PMSTA08801 - 100301 */
								  OBJECT_ENUM,
								  DBA_DYNST_ENUM,
								  DBA_DYNFLD_STP,
								  DBA_PROC_STP);

extern RET_CODE SYB_CtClose(SybConnection&, int),
SYB_CtConDrop(SybConnection&),
SYB_CtCmdDrop(SybConnection&),
SYB_CtConProps(SybConnection&, CS_INT, CS_INT, CS_VOID *, CS_INT, CS_INT *),
SYB_CtOptions(SybConnection&, CS_INT, CS_INT, CS_VOID *, CS_INT, CS_INT *),
SYB_CtPoll(SybConnection&, CS_CONTEXT *, CS_INT, CS_CONNECTION **,
CS_COMMAND **, CS_INT *, CS_RETCODE *);

extern RET_CODE SYB_ReadFinFctResults(DbiConnection& , DBA_DATARESULT_STP *);

/************************************************************************
**      BEGIN External definitions attached to : syblib03.c
*************************************************************************/
extern RET_CODE SYB_GimmeNetRunning(const char	*appName,		/* Application name to spy. *//* REF8728 - YST - 030218 */
	short	*netCoreNb,
	short	*netProdModNb,
	short	*netAttribModNb,
	short	*netRiskModNb,
	short	*netAccModNb,
	short	*netFundModNb,
	short	*netCorpActionsModNb,
	short	*netAdvAnalyticsModNb,
	short	*netCompManagementModNb,
	short	*netExcelReportModNb,
	short	*netRAModNb,
	short	*netACMModNb,
	short	*netOMModNb);

extern RET_CODE SYB_ManagedSqlExec(AAASQL_CONTEXT_STP context);
extern RET_CODE SYB_InsApplUserById(DBA_DYNFLD_STP, DbiConnection&);
extern RET_CODE SYB_UpdApplUser(DBA_DYNFLD_STP, DbiConnection&);
extern RET_CODE SYB_ChangePasswd(SYSNAME_T adminUser,
                                 SYSNAME_T adminPasswd,
                                 SYSNAME_T userCode,
                                 SYSNAME_T newPasswd);

/************************************************************************
**      BEGIN External definitions attached to : sybdict.c
*************************************************************************/

#endif					/* ifndef SYB_H */
/************************************************************************
**      END        syb.h
*************************************************************************/

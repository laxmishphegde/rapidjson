/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef SYBBCP_H
#define SYBBCP_H

#include <cspublic.h>
#include <dbibcp.h>

/************************************************************************
**      Constant & Macro definitions
*************************************************************************/
/*
** Private structure (you shouldn't access to it)
**
** This structure is used by bulk copy method.
*/
typedef struct 
{
    CS_BLKDESC	    *blkdesc;                       /* Bulk copy low level structure */
    CS_VOID         **buffer;                       /* buffers to be binded */ /* OCE - REF2421 - 980901 */
    CS_INT          **datalen;                      /* 'datalen' bind information */
    CS_SMALLINT     **indicator;                    /* 'indicator' bind information */
    CS_DATAFMT      *datafmt;                       /* 'datafmt' bind information */
    int             *buflen;                        /* string buffer length array*/
	DBI_BLKDEF_STP  parentDef;					    /* global parent blk def*/
} SYB_BLKDEF_ST, *SYB_BLKDEF_STP;

/************************************************************************
**      BEGIN External definitions attached to : sybbcp.c
*************************************************************************/
#ifdef EXTERN
#undef EXTERN
#endif
#ifdef  SYBBCP_C
#define EXTERN
#else
#define EXTERN extern
#endif

/* insert options used with bulk copy method */   


extern RET_CODE      SYB_BcpInInit(DBI_BLKDEF_STP,  void **);					
extern RET_CODE      SYB_BcpInsert(DBA_DYNFLD_STP, SYB_BLKDEF_STP, int*, const char*);            
extern RET_CODE      SYB_BcpEnd(SYB_BLKDEF_STP, int*, const char*);                                 
extern void          SYB_BcpFree(SYB_BLKDEF_STP &);

extern FLAG_T        SYB_BcpModeOPFlg();
extern FLAG_T        SYB_BcpModePerfStorageFlg();
extern FLAG_T        SYB_BcpModeRepFlg();
extern RET_CODE      SYB_BcpInitEntity(OBJECT_ENUM, DBA_DYNST_ENUM, int, int, void **);

#endif                                               /* ifndef DBABCP_H */
/************************************************************************
**      END        sybbcp.h                                     UNICIBLE
*************************************************************************/

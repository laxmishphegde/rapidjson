/************************************************************************
**
**              Copyright (C) Temenos Software Luxembourg SA 1995-2021.
**                       All Rights Reserved
**
**                   Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define PGSLIB01_CPP

/************************************************************************
**      Include files
*************************************************************************/
#define STDIO_H
#define MATH_H
#define TIME_H
#define STDLIB_H
#define STRING_H
#define STDARG_H

#include "unidef.h"     /* Mandatory */
#include "gen.h"
#include "msg.h"
#include "date.h"
#include "dba.h"
#include "dbi.h"
#include "crypt.h"
#include "conlocprovider.h"
#include "dbiconnection.h"

#include "libpq-fe.h"
#include "pgsconnection.h"

#include "ddlgenfromfile.h"
#include "ddlgenvar.h"
#include "aaasql.h"

#include <conv.h>

#include "str.h"

#include <iomanip>

using namespace std;

/************************************************************************
*   Function             : PGS_InitializeContext()
*
*   Description          : 
*
*   Arguments            : 
*
*   Functions call       : None
*
*   Last modif.          :
*
*************************************************************************/
RET_CODE PGS_InitializeContext()
{
    PQinitOpenSSL(0, 0);
    return(RET_SUCCEED);
}


/************************************************************************
*   Function             : PGS_GetDatatypeFromDesc()
*
*   Description          :
*
*   Arguments            :
*
*   Functions call       :
*
*   Return               :
*
*   Last Modification    :
*************************************************************************/
DATATYPE_ENUM PGS_GetDatatypeFromDesc(CTYPE_ENUM cType, int &dataSize, int precision, int scale)
{
    DATATYPE_ENUM dataType, defaultDataType = NullDataType;
    string nativType;
    int defaultDataSize = 0;

    switch (cType)
    {
        case DoubleCType:
            nativType = "numeric";
            defaultDataType = NumberType;
            break;
        case CharPtrCType:
            nativType = "varchar";
            defaultDataType = String15000Type;
            defaultDataSize = 15000;
            break;
        case UIntCType:
        case IntCType:
            nativType = "int";
            defaultDataType = IntType;
            break;
        case ShortCType:
        case UShortCType:
            nativType = "smallint";
            defaultDataType = SmallintType;
            break;
        case UCharCType:
            nativType = "tinyint";
            defaultDataType = FlagType;
            break;
        case DateTimeStCType:
            defaultDataType = DatetimeType;
            break;
        case TextPtrCType:
            nativType = "text";
            defaultDataType = TextType;
            defaultDataSize = MAX_USHORT;
            break;
        case UniCharPtrCType:
            nativType = "univarchar";
            defaultDataType = String15000Type;
            defaultDataSize = 15000;
            break;
        case UniTextPtrCType:
            nativType = "unitext";
            defaultDataType = UniTextType;
            defaultDataSize = MAX_USHORT;
            break;
        case LongLongCType:
            nativType = "numeric";
            defaultDataType = IdType;
            break;
        case TimeStampCType:
            nativType = "timestamp";
            defaultDataType = TimeStampType;
            break;
        case BinaryCType:
            nativType = "binary";
            defaultDataType = BinaryType;
            break;

        case VarTextPtrCType:
        case VarCharPtrCType:
        case PtrCType:
        case ExtPtrCType:
        case ArrayPtrCType:
        case MultiArrayPtrCType:
            nativType = "unknown";
            break;
    }

    dataType = DBA_GetDataTypeFromEquivType(Sybase, nativType, precision, scale);

    if (dataType == NullDataType)
    {
        dataType = defaultDataType;
        if (defaultDataSize)
        {
            dataSize = defaultDataSize;
        }
    }
    return dataType;
}

/************************************************************************
**
** Function    : PGS_PrintVersion
**
** Description : Print to stdout the PostgreSQL library actually loaded
**
** Arguments   :
**
** Return      : None
**
************************************************************************/
void PGS_PrintVersion()
{
    char buff[128];
    sprintf(buff, "PostgreSQL client library version: %d", PQlibVersion());
    printf(buff);
}

/************************************************************************
**  Function    :   PGS_InsUpdPgsUser
**
**  Description :   Insert or update an PostgreSQL user.
**
**  Arguments   :   object        The user to check.
**  		        inputSt 	  A_ApplUser.
**                  inputData     A_ApplUser data.
**                  connectNo     Not used.
**                  msgStructPtr  Kind of error message.
**
**  Return      :   RET_SUCCEED                      If the user is DBO or SSO.
**                  RET_DBA_ERR_PASSWD_TOO_SHORT     If less than 6 characters.
**                  RET_GEN_ERR_INVARG               If no input data provided.
**
**  Creation    :   PMSTA-37366 - LJE - 191112
**
**  Modif.      :
**
*************************************************************************/
RET_CODE PGS_InsUpdPgsUser(DBA_DYNFLD_STP       inputData,
                             DbiConnection&       dbiConn,
                             bool                 isInsert)
{
    SYSNAME_T	   code = { 0 };
    char          *userPasswd;
    char		   buffer[256] = { 0 };
    AUTO_PASSWORD_CLEAR(buffer, sizeof(buffer));
    char		   errMsg[256];
    RET_CODE       retCode = RET_SUCCEED;
    DBA_DYNFLD_STP AdmArgStp;
    FLAG_T         hasDBLoginflg = TRUE;
    DbiConnection* dbiConnAdm = nullptr;
    SYSNAME_T	   admLogin;

    /* Check arguments */
    if (inputData == NULL)
    {
        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "PGS_InsUpdPgsUser", "inputData");
        return(RET_GEN_ERR_INVARG);
    }

    code[0] = END_OF_STRING;

    if (IS_NULLFLD(inputData, A_ApplUser_Cd) == FALSE)
    {
        strcpy(code, GET_SYSNAME(inputData, A_ApplUser_Cd));
    }

    if (IS_NULLFLD(inputData, A_ApplUser_HasDbLoginFlg) == FALSE) /* PMSTA-14286 - EFE - 120608 */
    {
        hasDBLoginflg = GET_ENUM(inputData, A_ApplUser_HasDbLoginFlg);
    }

    SYBASE_LOGIN_ACTION_ENUM loginActionEn = LoginActionEn_Nothing;
    FLAG_T lockActionFlg = FALSE;

    if (IS_NULLFLD(inputData, A_ApplUser_LoginActionEn) == FALSE)
        loginActionEn = (SYBASE_LOGIN_ACTION_ENUM)GET_ENUM(inputData, A_ApplUser_LoginActionEn);
    if (IS_NULLFLD(inputData, A_ApplUser_LockActionFlg) == FALSE)
        lockActionFlg = GET_FLAG(inputData, A_ApplUser_LockActionFlg);

    if (!hasDBLoginflg && loginActionEn != LoginActionEn_Drop)
        return retCode;

    if (nullptr != GET_SYSNAME(inputData, A_ApplUser_SuperUserLogin))
    {
        strcpy(admLogin, GET_SYSNAME(inputData, A_ApplUser_SuperUserLogin));
    }
    else
    {
        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "PGS_InsUpdPgsUser", "ApplUser_SuperUserLogin");
        retCode = RET_SRV_LIB_ERR_INSERT_USER_FAILED;
    }

    /* The use of interface to create users needs to
    verify that the user given is administrator. */

    if (retCode == RET_SUCCEED && SYS_IsBatchMode())
    {
        if (DBA_CheckDbAdminUser(admLogin, PasswordEncrypted(PasswordClear(GET_SYSNAME(inputData, A_ApplUser_SuperUserPasswd)))) != RET_SUCCEED)
        {
            sprintf(errMsg, "user %s is not entitled to create/lock/unlock user %s", admLogin, code);
            auto &msgStructSt = dbiConn.m_msgStructHeaderSt.getNewErrMsgInfoSt(FILEINFO);

            msgStructSt.msgString = errMsg;
            msgStructSt.techMsg = FALSE;
            retCode = RET_SRV_LIB_ERR_INSERT_USER_FAILED;
        }
    }

    if (retCode == RET_SUCCEED && DBA_OpenConnForUser(admLogin, PasswordEncrypted(PasswordClear(GET_SYSNAME(inputData, A_ApplUser_SuperUserPasswd))), &dbiConnAdm, ROLE_DBSO) != RET_SUCCEED)
    {
        sprintf(errMsg, "unable to open a connection with ROLE_DBSO, user %s", admLogin);
        auto &msgStructSt = dbiConn.m_msgStructHeaderSt.getNewErrMsgInfoSt(FILEINFO);
        msgStructSt.msgString = errMsg;
        msgStructSt.techMsg = FALSE;
        retCode = RET_SRV_LIB_ERR_INSERT_USER_FAILED;
    }

    bool isEmpty = true;

    if (retCode == RET_SUCCEED && hasDBLoginflg == TRUE && (isInsert || loginActionEn == LoginActionEn_Add))
    {
        if ((AdmArgStp = ALLOC_DYNST(Adm_Arg)) == NULL)
        {
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }

        SET_CODE(AdmArgStp, Adm_Arg_Sysname, code);

        retCode = DBA_Notif2(DictUser
                             , UNUSED
                             , Adm_Arg
                             , AdmArgStp
                             , DBA_SET_CONN | DBA_NO_CLOSE
                             , dbiConn
                             , UNUSED
        );

        if (retCode == RET_SUCCEED && GET_INT(AdmArgStp, Adm_Arg_ReturnStatus) != 0)
        {   /* insert */
            userPasswd = NULL;
            if (IS_NULLFLD(inputData, A_ApplUser_UserPassword) == FALSE)
            {
                /*  replace double quote in userPasswd  */
                userPasswd = GEN_ManageQuoteInPassword(GET_INFO(inputData, A_ApplUser_UserPassword));
            }

            /* Test if password is long enough for PostgreSQL. */
            if (userPasswd == NULL ||
                SYS_StrLen(code) < 1 || SYS_StrLen(userPasswd) < 6)
            {
                auto &msgStructSt = dbiConn.m_msgStructHeaderSt.getNewErrMsgInfoSt(FILEINFO);
                msgStructSt.msgString = "Invalid username or password";
                msgStructSt.techMsg = FALSE;

                retCode = RET_DBA_ERR_PASSWD_TOO_SHORT;
            }

            /* The use of interface to create users needs to
            verify that the user given is administrator. */
            if (retCode == RET_SUCCEED && DBI_CheckUserRole(*dbiConnAdm, "sso_role") == false)
            {
                sprintf(errMsg, "user %s is not entitled to create user %s", admLogin, code);
                auto &msgStructSt = dbiConn.m_msgStructHeaderSt.getNewErrMsgInfoSt(FILEINFO);
                msgStructSt.msgString = errMsg;
                msgStructSt.techMsg = FALSE;
                DBA_PasswordClear(userPasswd, strlen(userPasswd));            /* PMSTA-18094 - 130514 - PMO */
                retCode = RET_SRV_LIB_ERR_INSERT_USER_FAILED;
            }

            if (retCode == RET_SUCCEED)
            {
                RequestHelper requestHelper(dbiConnAdm);

                const AAALogger& sqlTraceLog = AAALogger::get(AAALogger::Logger::SqlTrace);
                if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
                {
                    auto &sqlTrace = dbiConnAdm->getSqlTrace();
                    sqlTrace.m_procedure = "DynSql.InsUpdPgsUser";
                    sqlTrace.m_mode = DbiSqlTrace::Mode::Lang;
                }

                int *countNbr = nullptr;
                requestHelper.addNewParamCharPtr(GET_SYSNAME(inputData, A_ApplUser_Cd), SysnameType);
                requestHelper.setCommand("select count(*) from pg_user pg where pg.usename = lower(?)");
                requestHelper.addNewOutputData(IntType);
                requestHelper.getBindVariablePtr(countNbr);

                std::string user;
                user = string(GET_SYSNAME(inputData, A_ApplUser_Cd));
                if (requestHelper.sendAndGetCommand() == RET_SUCCEED)
                {
                    if (countNbr != nullptr && *countNbr == 0)
                    {
                        std::string mainDbSqlName;
                        GEN_GetApplInfo(ApplSqlDbName, mainDbSqlName);

                        requestHelper.finishRequest();
                        if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
                        {
                            auto &sqlTrace = dbiConnAdm->getSqlTrace();
                            sqlTrace.m_procedure = "DynSql.InsUpdPgsUser";
                            sqlTrace.m_mode = DbiSqlTrace::Mode::Lang;
                        }

                        if (isdigit(user[0]))  /* PMSTA-57524 - 2024/07/31 -Suparna- Bind the User_Cd within double quote to allow numerics as code */
                        {
                            requestHelper.setCommand("create user \"" + user + "\" with password '" + userPasswd + "'");
                        }
                        else
                            requestHelper.setCommand("create user " + user + " with password '" + userPasswd + "'");
                        retCode = requestHelper.sendAndGetCommand();
                    }
                    else
                    {
                        requestHelper.finishRequest();
                        if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
                        {
                            auto &sqlTrace = dbiConnAdm->getSqlTrace();
                            sqlTrace.m_procedure = "DynSql.InsUpdPgsUser";
                            sqlTrace.m_mode = DbiSqlTrace::Mode::Lang;
                        }

                        if (isdigit(user[0]))
                        {
                            requestHelper.setCommand("alter user \"" + user + "\" with password '" + userPasswd + "'");
                        }
                        else
                            requestHelper.setCommand("alter user " + user + " with password '" + userPasswd + "'");
                        retCode = requestHelper.sendAndGetCommand();
                    }

                    if (retCode == RET_SUCCEED)
                    {
                        requestHelper.finishRequest();
                        if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
                        {
                            auto& sqlTrace = dbiConnAdm->getSqlTrace();
                            sqlTrace.m_procedure = "DynSql.GrantPgsUser";
                            sqlTrace.m_mode = DbiSqlTrace::Mode::Lang;
                        }

                        if (isdigit(user[0]))  /* PMSTA-57524 - 2024/07/31 -Suparna */
                        {

                            requestHelper.setCommand("grant TRIPLEA to \"" + user + "\"");
                        }
                        else
                            requestHelper.setCommand("grant TRIPLEA to " + user + ""); 
                        retCode = requestHelper.sendAndGetCommand();
                    }
                }
                isEmpty = false;
            }

            /*  Free allocated memory               */
            if (userPasswd != NULL)
            {
                DBA_PasswordClear(userPasswd, strlen(userPasswd));
                FREE(userPasswd);
            }
        }
        FREE_DYNST(AdmArgStp, Adm_Arg);
    }

    DBA_EndConnection(&dbiConnAdm);

    return retCode;
}

/************************************************************************
**  Function    :   PGS_InsApplUserById
**
**  Description :   Create a new user.
**
**  Arguments   :   object        The user to check.
**  		        inputSt 	  A_ApplUser.
**                  inputData     A_ApplUser data.
**                  connectNo     Not used.
**                  msgStructPtr  Kind of error message.
**
**  Return      :   RET_SUCCEED                      If the user is DBO or SSO.
**                  RET_DBA_ERR_PASSWD_TOO_SHORT     If less than 6 characters.
**                  RET_GEN_ERR_INVARG               If no input data provided.
**
**  Creation    :   PMSTA-37366 - LJE - 191112
**  Modif.      :
**
*************************************************************************/
RET_CODE PGS_InsApplUserById(DBA_DYNFLD_STP       inputData,
                               DbiConnection&       dbiConn)
{
    /* Check arguments */
    if (inputData == NULL)
    {
        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "PGS_InsApplUserById", "inputData");
        return(RET_GEN_ERR_INVARG);
    }

    RET_CODE retCode = PGS_InsUpdPgsUser(inputData,
                                           dbiConn,
                                           true);
    return retCode;
}


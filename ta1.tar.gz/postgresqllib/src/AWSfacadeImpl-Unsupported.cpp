#include "AWSfacadeImpl.h"

std::string AWSfacade::GenerateConnectAuthToken(const char* , const char* , unsigned , const char* ) const
{
   static std::string result;
   return result;
}


AWSfacade::AWSfacade()
{
}

AWSfacade::~AWSfacade()
{
}

std::unique_ptr<AWSfacade>
AWSfacadeFactory::Create()
{
    std::unique_ptr<AWSfacade> awsFacade( new AWSfacade());
    return awsFacade;
}

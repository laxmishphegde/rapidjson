/************************************************************************
**
**              Copyright (C) Temenos Software Luxembourg SA 1995-2021.
**                       All Rights Reserved
**
**                   Portfolio Management System
**
*************************************************************************/

#ifdef NTWIN
#pragma warning (push)
#endif

#include "unidef.h"

#ifdef WIN32
#include <winsock2.h>
#else
#include <arpa/inet.h>

#define htonll htobe64
#define ntohll be64toh

#endif

#include "dba.h"
#include "conexcept.h"
#include "conv.h"
#include "callstack.h"

#include "libpq-fe.h"
#include "pgsconnection.h"
#include "ddlgenfromfile.h"

#include "aaalogger.h"
#include "AWSfacade.h"
#include "AWSfacadeImpl.h"

#include <map>
#include <chrono>

#include <QDate>
#include <QTime>
#include <QDateTime>

#ifdef NTWIN
#pragma warning (pop)
#endif

extern bool EV_EnableMicrosecTime;

const int TIME_STRING_LENGTH   = 30;
const int NUMBER_STRING_LENGTH = 64;

const char* PARAM_STATMENT    = ""; // ParamStatment
const char* NO_PARAM_STATMENT = ""; // NoParamStatment

extern RET_CODE fetchMicrosecsFromDatetimeStr(const char*, MICROSECOND_T*);

AAAConnection* PgsConnection::createConnection(const AAAConnectionSpecification& spec, const int& id) {
    return new PgsConnection(spec, id);
}

static void pgsConnNoticeReceive(void* arg, const PGresult* res)
{
    PgsConnection* pgsConnection = static_cast<PgsConnection*>(arg);

    auto        severity = PQresultErrorField(res, PG_DIAG_SEVERITY);
    auto        sqlstate = PQresultErrorField(res, PG_DIAG_SQLSTATE);
    const char* msg      = PQresultErrorField(res, PG_DIAG_MESSAGE_PRIMARY);

    if (strcmp(severity, "NOTICE") == 0 ||
        strcmp(severity, "INFO") == 0)
    {
        const AAALogger& connectionLog = AAALogger::get(AAALogger::Logger::Connections);
        if (connectionLog.isDebugEnabled())
        {
            std::string	logMessage = SYS_Stringer("Severity: ", severity, " - ",
                                                  "SqlState: ", (sqlstate == nullptr ? "null" : sqlstate), " - ",
                                                  "Msg: ", msg);
            if (connectionLog.isTraceEnabled())
            {
                logMessage += " - Callstack: \n" + SYS_GetCallStack(0, true);
            }

            connectionLog.info(logMessage);
        }

        if (sqlstate == nullptr ||
            strcmp(sqlstate, "42P07") != 0) /* relation "xxx" already exists, skipping */
        {
            pgsConnection->addMessage(msg);
        }
    }
    else
    {
        pgsConnection->manageError(msg, res);
    }
}

/************************************************************************
**
**  Function    :   PgsConnection::PgsConnection()
**
**  Description :
**
**  Argument    :
**
**  Return      :
**
**  Creation    :
**
**  Last modif. :
**
*************************************************************************/
PgsConnection::PgsConnection(const AAAConnectionSpecification& spec, const int& id)
    : DbiConnection(spec, id)
    , m_connection(nullptr)
    , m_preparedStatement(nullptr)
    , m_statement(nullptr)
    , m_lastSqlCode(PGRES_EMPTY_QUERY)
    , m_bOutputInParam(false)
    , m_rowNumber(-1)
    , m_rowPos(-1)
{
    this->m_connectToRDBMS = PostgreSQL;

    DBA_CONNECT_INFO_STP connStp = getConnStructPtr();

    if (connStp)
    {
        connStp->maxRows                                = NO_VALUE;
        connStp->blockMode                              = 0;
        connStp->subscriptionElem.eventNat              = Event_Nature_None;
        connStp->subscriptionElem.auditRecSt            = NullDynSt;
        connStp->subscriptionElem.auditRecStp           = NULL;
        connStp->subscriptionElem.currAction            = NullAction;
        connStp->subscriptionElem.subscripCodifCompoStp = NULL;
        connStp->subscriptionElem.subscripCodifCompoNmb = 0;
        memset(&(connStp->subscriptionElem.creation_d), 0, sizeof(DATETIME_ST));
        connStp->preserveConfirmedFlg                   = FALSE;
        connStp->passwordChange                         = false;
        connStp->timeOut                                = NO_VALUE;
        connStp->poolConnectNo                          = id;
    }
}


/************************************************************************
*   Function             :  PgsConnection::~PgsConnection()
*
*   Description          :  Destructor
*
*   Arguments            :  None
*
*   Return               :  None
*
*   Creation Date        :
*
*   Last Modification    :
*
*************************************************************************/
PgsConnection::~PgsConnection()
{
    this->disconnect();
}


/************************************************************************
**
**  Function    :   PgsConnection::doConnect()
**
**  Description :
**
**  Argument    :
**
**  Return      :
**
**  Creation    :
**
**  Last modif. :
**
*************************************************************************/
bool PgsConnection::doConnect()
{
    const AAALogger& logger = AAALogger::get(AAALogger::Logger::Application);
    logger.log(AAALogger::Level::Info, this->getDescription().getServerName());

    const AAALogger& connectionLog = AAALogger::get(AAALogger::Logger::Connections);
    if (connectionLog.isDebugEnabled())
    {
        std::string	logMessage = SYS_Stringer("Server Name: ", this->getDescription().getServerName(), " - ",
                                              "User: ", this->getSpecification().getCredentials().getUser(), " - ",
                                              "Connect No: ", this->getId(), " - ",
                                              "PgsConnection::connect");

        if (connectionLog.isTraceEnabled())
        {
            logMessage += " - Callstack: \n" + SYS_GetCallStack(0, true);
        }

        connectionLog.info(logMessage);
    }

   
    const std::string serverName = this->getDescription().getServerName();

    static int connect_timeout = SYS_GetEnvIntOrDefValue("DSQUERY_CONNECT_TIMEOUT", 10);
    static bool  useIAM = DBAuthenticationMethod::get() == DBAuthenticationMethod::Value::iam;



    std::string dbUserName = this->getSpecification().getCredentials().getUser();


    std::stringstream conninfo;

    if (useIAM == false)
    {
        static std::string sslMode = SYS_GetEnvStringOrDefValue("DSQUERY_SSL_MODE", "prefer");

        conninfo
            << "postgresql://"
            << dbUserName << ":" << this->getSpecification().getCredentials().getPassword().getClearPassword().getPassword()
            << "@" << serverName << "?"
            << "connect_timeout=" << connect_timeout
            << "&sslmode=" << sslMode
            << "&application_name=" << GEN_GetApplName();
    }
    else
    {
        static bool once = true;
        if (once) {
            AAALogger::get(AAALogger::Logger::Configuration).info("Using IAM Configuration");
            once = false;
        }

        auto colonPos = serverName.find(':');
        auto slashPos = serverName.find('/');
        static std::string dbRegion = SYS_GetEnvStringOrDefValue("AWS_REGION", "eu-central-1");
        static std::string sslMode = SYS_GetEnvStringOrDefValue("DSQUERY_SSL_MODE", "require");
        
        std::string dbHost;
        if (colonPos == std::string::npos) {
            if (slashPos == std::string::npos) {
                dbHost = serverName;
            }
            else {
                dbHost = serverName.substr(0, slashPos);;
            }
        }
        else {
            dbHost = serverName.substr(0, colonPos);;
        }

        unsigned dbPort = 5432;
        auto len = slashPos - colonPos -1;
        if (colonPos != std::string::npos && len > 0)
        {
            try {
                dbPort = std::stoi(serverName.substr(colonPos+1, len));
            }
            catch (...) {};
        }

        std::string dbName = slashPos > serverName.length() ? "" : serverName.substr(slashPos+1);

        static bool firsttime = true;
        if (firsttime == true)
        {
            AWSFacadeProvider::SetAWSFacadeProvider(AWSfacadeFactory::Create());
            firsttime = false;
        }

        std::string authToken;
        // Use a cache as AWS token generation rate is limited
        static std::map<std::string, std::pair<std::string, std::chrono::time_point<std::chrono::steady_clock>>> authTokenMap;
        auto it = authTokenMap.find(dbUserName);

        if (it != authTokenMap.end())
        {
            auto ageMin = std::chrono::duration_cast<std::chrono::minutes> (std::chrono::steady_clock::now()- it->second.second );

            if (ageMin.count() > 14)
            {
                authToken = AWSFacadeProvider::GetAWSFacadeProvider()->GenerateConnectAuthToken(dbHost.c_str(), dbRegion.c_str(), dbPort, dbUserName.c_str());
                authTokenMap.emplace(std::make_pair(dbUserName, std::make_pair(authToken, std::chrono::steady_clock::now())));
            }
            else
            {
                authToken = it->second.first;
            }
        }
        else
        {
            authToken = AWSFacadeProvider::GetAWSFacadeProvider()->GenerateConnectAuthToken(dbHost.c_str(), dbRegion.c_str(), dbPort, dbUserName.c_str());
            authTokenMap.emplace(std::make_pair(dbUserName, std::make_pair(authToken, std::chrono::steady_clock::now())));
        }


 
        conninfo
            << "host=" << dbHost << " "
            << "port=" << dbPort << " "
            << "sslmode=" << sslMode << " "
            << "connect_timeout=" << connect_timeout << " "
            << "application_name=" << GEN_GetApplName() << " "
            << "dbname=" << dbName << " "
            << "user=" << dbUserName << " "
            << "password=" << authToken << " ";

        if (connectionLog.isDebugEnabled() ) 
        {
            std::stringstream dbg;
            dbg << "Try to connect using=" << conninfo.str();
            connectionLog.debug(dbg.str());
        }
    }


    this->m_connection = PQconnectdb(conninfo.str().c_str());

    ConnStatusType connectionStatus = PQstatus(this->m_connection);

    /* Check to see that the back-end connection was successfully made */
    if (connectionStatus != CONNECTION_OK)
    {
        std::stringstream  errorDescription;

        errorDescription << PQerrorMessage(this->m_connection) << " Error No: (" << connectionStatus << ")";

        if (SYS_GetEnvBoolOrDefValue("AAAPRINTCONNECTFAILED", false))
        {
            char  errMsg[1024];
            sprintf(errMsg,
                    "Call to PgsConnection::doConnect failed. Connection (" szFormatPointer "), server (%s), thread (" szFormatPointer "), connection (%d), status (%s)",
                    this->m_connection,
                    this->getDescription().getServerName().c_str(),
                    DBA_GetCurrThread(),
                    this->getId(),
                    errorDescription.str().c_str());

            if ((SYS_IsGuiMode() == TRUE) || (SERVER_IS_INIT() == TRUE))
            {
                MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, errMsg);
            }
            else
            {
                MSG_SendStrToLog(errMsg);
            }
        }

        this->doDisconnect();

        /* throw exception only if connection retry attempt not there */
        if (connectionStatus == CONNECTION_BAD || connectionStatus == CONNECTION_NEEDED)
        {
            m_isDBConnectRetryRequired = true;
        }
        else
        {
            throw AAACannotConnectDbException(errorDescription.str(), this->getDescription(), this->getId());

        }
    }

    PQsetNoticeReceiver(this->m_connection, pgsConnNoticeReceive, this);

    /*
     * Should PQclear PGresult whenever it is no longer needed to avoid memory
     * leaks
     */
    this->doReleaseCommand();

    if (EV_MaxNumberArgument == MAX_SHORT)
    {
        PQclear(this->m_statement);
        this->m_statement = PQexec(this->m_connection, "select setting from pg_settings where name = 'max_function_args'");
        this->m_lastSqlCode = PQresultStatus(this->m_statement);
        if (this->m_lastSqlCode != PGRES_TUPLES_OK)
        {
            fprintf(stderr, "select failed: %s", PQerrorMessage(this->m_connection));
            this->doReleaseCommand();
            this->doDisconnect();
            return false;
        }

        EV_MaxNumberArgument = atoi(PQgetvalue(this->m_statement, 0, 0));

        this->doReleaseCommand();
    }


    return true;
}


/************************************************************************
**
**  Function    :   PgsConnection::doDisconnect()
**
**  Description :
**
**  Argument    :
**
**  Return      :
**
**  Creation    :
**
**  Last modif. :
**
*************************************************************************/
bool PgsConnection::doDisconnect()
{
    if (this->m_connection != nullptr)
    {
        this->releaseCommand();

        const AAALogger& connectionLog = AAALogger::get(AAALogger::Logger::Connections);
        if (connectionLog.isDebugEnabled())
        {
            std::string	logMessage = SYS_Stringer("Server Name: ", this->getDescription().getServerName(), " - ",
                                                  "User : ", this->getSpecification().getCredentials().getUser(), " - ",
                                                  "Connect No: ", this->getId(), " - ",
                                                  "PgsConnection::disconnect");

            if (connectionLog.isTraceEnabled())
            {
                logMessage += " - Callstack: \n" + SYS_GetCallStack(0, true);
            }

            connectionLog.info(logMessage);
        }

        PQfinish(this->m_connection);
        this->m_connection = nullptr;

        this->m_currDbNameOption.clear();
    }

    return true;
}

PTR PgsConnection::getConnectionPtr()
{
    return this->m_connection;
}

PTR PgsConnection::getCommandPtr()
{
    return this->m_statement;
}

RET_CODE PgsConnection::createStatement(const std::string &sql, DBA_ACTION_ENUM action)
{
    this->startRequest();

    if (action == Custom && 
        this->m_onApplySessionProperties == false &&
        this->getScriptDdlGenPtr()->getDdlGenContextPtr()->m_inputVariableVector.empty() == false)
    {
        auto &inputVarVector   = this->getScriptDdlGenPtr()->getDdlGenContextPtr()->m_inputVariableVector;
        int   nParams          = CAST_INT(inputVarVector.size());
        Oid*  paramTypes       = static_cast<Oid*>(this->m_queryMp.calloc(FILEINFO, nParams, sizeof(Oid)));

        size_t i = 0;
        for (auto it = inputVarVector.begin(); it != inputVarVector.end(); ++it, ++i)
        {
            paramTypes[i] = this->getPostgreSQLDataType(it->m_dataTypeEn);
        }

        PQclear(this->m_preparedStatement);
        this->m_preparedStatement = PQprepare(this->m_connection, PARAM_STATMENT, sql.c_str(), nParams, paramTypes);
    }
    else if (this->getRequestParamMap().empty() == false)
    {
        auto& inputVarMap    = this->getRequestParamMap();
        int   nParams        = CAST_INT(inputVarMap.size());
        Oid*  paramTypes     = static_cast<Oid*>(this->m_queryMp.calloc(FILEINFO, nParams, sizeof(Oid)));

        for (auto &it : inputVarMap)
        {
            if (it.second->m_bOutputOnly == false)
            {
                paramTypes[it.first] = this->getPostgreSQLDataType((it.second->m_paramDataType != NullDataType ? it.second->m_paramDataType : it.second->m_dataType));
            }
            else
            {
                nParams--;
            }
        }

        PQclear(this->m_preparedStatement);
        this->m_preparedStatement = PQprepare(this->m_connection, PARAM_STATMENT, sql.c_str(), nParams, paramTypes);
    }
    else if (this->getColInfoVector().empty() == false)
    {
        auto& colInfoVector = this->getColInfoVector();
        int   nParams = CAST_INT(colInfoVector.size());
        Oid* paramTypes = static_cast<Oid*>(this->m_queryMp.calloc(FILEINFO, nParams, sizeof(Oid)));

        for (auto it = colInfoVector.begin(); it != colInfoVector.end(); ++it)
        {
            if (it->m_isDb)
            {
                paramTypes[it->m_columnPos] = this->getPostgreSQLDataType(it->m_dataType);
            }
            else
            {
                nParams--;
            }
        }

        PQclear(this->m_preparedStatement);
        this->m_preparedStatement = PQprepare(this->m_connection, PARAM_STATMENT, sql.c_str(), nParams, paramTypes);
    }
    else
    {
        if (action == Custom)
        {
            PQclear(this->m_statement);
            this->m_statement = PQexec(this->m_connection, sql.c_str());
        }
        else
        {
            PQclear(this->m_preparedStatement);
            this->m_preparedStatement = PQprepare(this->m_connection, NO_PARAM_STATMENT, sql.c_str(), 0, nullptr);
        }
    }

    if (this->m_lastSqlCode == PGRES_EMPTY_QUERY)
    {
        this->manageError();
        this->m_lastResultRetCode = this->getLastCmdRetCode();
    }

    const AAALogger& sqlTraceLog = AAALogger::get(AAALogger::Logger::SqlTrace);
    if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
    {
        auto &sqlTrace = this->getSqlTrace();
        sqlTrace.m_retCode = this->m_lastResultRetCode;
    }

    return this->m_lastResultRetCode;
}

RET_CODE PgsConnection::doAddBatch()
{
    if (this->getCurrProcedure() == nullptr &&
        this->getBatchMode() == BatchMode::TryBCP)
    {
        if (this->m_batchSize == 0)
        {
            std::stringstream cmdStream;
            cmdStream << "COPY " << this->m_batchTableSqlName << "(";

            bool bQuote = false;
            for (auto &dynFldIt : this->getRequestParamMap())
            {
                if (bQuote)
                {
                    cmdStream << ", ";
                }
                else
                {
                    bQuote = true;
                }

                cmdStream << dynFldIt.second->m_sqlName;
            }
            cmdStream << ") from STDIN WITH ( NULL 'null' , DELIMITER '" << this->getDelimiter() << "') ;";

            this->m_statement = PQexec(this->m_connection, cmdStream.str().c_str());
            this->manageError();
        }

        std::stringstream batchStream;

        bool bSep = false;
        for (auto& dynFldIt : this->getRequestParamMap())
        {
            DbiInOutData*       inputData = dynFldIt.second;
            DATATYPE_ENUM       fieldType = inputData->m_dataType;
            std::stringstream   recStream;

            if (DBI_FldToDbDataStr(recStream, inputData->getDynFldStp(), 0, fieldType, true, UnknownRdbms, nullptr) == RET_SRV_LIB_ERR_DB_OVERFLOW)
            {
                std::string buffer;
                SYS_Stringer(buffer, "Data overflow detected while executing procedure %s, parameter %s", this->getCurrProcedure()->procName, inputData->m_sqlName.c_str());
                MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, buffer.c_str());
            }

            if (bSep)
            {
                batchStream << this->getDelimiter();
            }
            else
            {
                bSep = true;
            }

            batchStream << recStream.str();
        }
        batchStream << "\n";

        auto res = PQputCopyData(this->m_connection,
                                 batchStream.str().c_str(),
                                 CAST_INT(batchStream.str().length()));

        if (res == -1)
        {
            this->manageError();
        }
        else if (res == 0)
        {
            if (this->executeBatch() == RET_SUCCEED)
            {
                this->doAddBatch();
            }
        }
    }
    else
    {
        DBI_INT lastResultType = 3; // DBI_FAIL;
        this->sendRequest(&lastResultType);
        return this->m_lastResultRetCode;
    }
    return RET_SUCCEED;

}

RET_CODE PgsConnection::doExecuteBatch()
{
    if (this->getCurrProcedure() == nullptr &&
        this->getBatchMode() == BatchMode::TryBCP)
    {
        const AAALogger& sqlTraceLog = AAALogger::get(AAALogger::Logger::SqlTrace);
        if (sqlTraceLog.isInfoEnabled())
        {
            auto& sqlTrace = this->getSqlTrace();
            sqlTrace.m_mode = DbiSqlTrace::Mode::Lang;
            sqlTrace.m_logLevel = AAALogger::Level::Info;
            sqlTrace.m_request << "PQputCopyEnd: " << this->m_batchSize << " PQputCopyData";
        }

        const char* errmsg = nullptr;
        if (PQputCopyEnd(this->m_connection, errmsg) == -1)
        {
            this->manageError();
        }
        else
        {
            auto res = PQgetResult(this->m_connection);
            if (PQresultStatus(res) != PGRES_COMMAND_OK) 
            {
                this->manageError(PQerrorMessage(this->m_connection), res);
            }
            PQclear(res);
        }
        this->manageError();
    }
    return this->m_lastResultRetCode;
}

/************************************************************************
*   Function             :  PgsConnection:getColumnCount()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-49178 - LJE - 220901
*
*   Last Modification    :
*
*************************************************************************/
int PgsConnection::getColumnCount()
{
    if (this->m_statement != nullptr)
    {
        auto columnCount = PQnfields(this->m_statement);
        if (columnCount == 1)
        { 
            Oid sqlType = PQftype(this->m_statement, 0);
            if (sqlType == VOIDOID)
            {
                columnCount = 0;
                this->m_lastResultType = DBI_CMD_SUCCEED;
            }
        }
        return columnCount;
    }
    return 0;
}


/************************************************************************
*   Function             :  PgsConnection:getColumnName()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-49178 - LJE - 220901
*
*   Last Modification    :
*
*************************************************************************/
RET_CODE PgsConnection::getColumnName(int colNum, std::string& colName)
{
    if (this->m_statement != nullptr)
    {
        const char* szColName = PQfname(this->m_statement, colNum - 1);

        if (szColName != nullptr)
        {
            colName = szColName;
            return RET_SUCCEED;
        }
    }

    return RET_DBA_ERR_DBPROBLEM;
}

/************************************************************************
*   Function             :  PgsConnection:getColumnType()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-49178 - LJE - 220901
*
*   Last Modification    :
*
*************************************************************************/
RET_CODE PgsConnection::getColumnType(int colNum, CTYPE_ENUM &cTypeEn)
{
    if (this->m_statement != nullptr)
    {
        Oid sqlType = PQftype(this->m_statement, colNum - 1);

        cTypeEn = this->getCType(sqlType);
    }
    return (cTypeEn == LastCtype ? RET_DBA_ERR_DBPROBLEM : RET_SUCCEED);
}

/************************************************************************
*   Function             :  PgsConnection:getPrecision()
*
*   Description          :  https://www.postgresql.org/message-id/slrnd6hnhn.27a.andrew+nonews@trinity.supernews.net
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-49178 - LJE - 220901
*
*   Last Modification    :
*
*************************************************************************/
int PgsConnection::getPrecision(int colNum)
{
    if (this->m_statement != nullptr)
    {
        int precision = PQfmod(this->m_statement, colNum - 1);

        if (precision < 0)
        {
            precision = this->getColumnMaxLength(colNum);
        }
        else
        {
            Oid sqlType = PQftype(this->m_statement, colNum - 1);
            switch (sqlType)
            {
                case BOOLOID:
                case INT8OID:
                case INT4OID:
                case INT2OID:
                case DATEOID:
                case TIMESTAMPOID:
                case VOIDOID:
                case BYTEAOID:
                    break;

                case NUMERICOID:
                    precision = ((precision - sizeof(int)) >> 16) & 0xffff;
                    break;

                case TEXTOID:
                case NAMEOID:
                case VARCHAROID:
                    precision = (precision - sizeof(int));
                    break;
            }
        }

        return precision;
    }
    return 0;
}

/************************************************************************
*   Function             :  PgsConnection:getScale()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-49178 - LJE - 220901
*
*   Last Modification    :
*
*************************************************************************/
int PgsConnection::getScale(int colNum)
{
    if (this->m_statement != nullptr)
    {
        int scale = PQfmod(this->m_statement, colNum - 1);

        if (scale > 0)
        {
            Oid sqlType = PQftype(this->m_statement, colNum - 1);
            if (sqlType == NUMERICOID)
            {
                scale = (((scale - sizeof(int)) & 0x7ff) ^ 1024) - 1024;
            }
        }
        return scale;
    }
    return 0;
}

/************************************************************************
*   Function             :  PgsConnection:getColumnMaxLength()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-49178 - LJE - 220901
*
*   Last Modification    :
*
*************************************************************************/
int PgsConnection::getColumnMaxLength(int colNum)
{
    if (this->m_statement != nullptr)
    {
        if (this->m_maxSizeMap.find(colNum - 1) == this->m_maxSizeMap.end())
        {
            int maxSize = PQfsize(this->m_statement, colNum - 1);

            if (maxSize == -1)
            {
                int rowNbr = PQntuples(this->m_statement);
                for (int i = 0; i < rowNbr; i++)
                {
                    if (PQgetisnull(this->m_statement, i, colNum - 1) == 0)
                    {
                        int currSize = PQgetlength(this->m_statement, i, colNum - 1);
                        if (currSize > maxSize)
                        {
                            maxSize = currSize;
                        }
                    }
                }
            }

            this->m_maxSizeMap[colNum - 1] = maxSize;
            return maxSize;
        }
        else
        {
            return this->m_maxSizeMap[colNum - 1];
        }
    }
    return 0;
}

/************************************************************************
*   Function             :  PgsConnection:getColumnDisplaySize()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-49178 - LJE - 220901
*
*   Last Modification    :
*
*************************************************************************/
int PgsConnection::getColumnDisplaySize(int colNum)
{
    return this->getColumnMaxLength(colNum);
}

/************************************************************************
*   Function             :  PgsConnection:isBcpAllowed()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :  PMSTA-37374 - LJE - 201112
*
*   Last Modification    :
*
*************************************************************************/
bool PgsConnection::isBcpAllowed()
{
    return true;
}

/************************************************************************
*   Function             : PgsConnection::clearPassword()
*
*   Description          :
*
*   Arguments            :
*
*   Global var. modified : None
*
*   Return               : None
*
*   Creation date        :
*
*   Last modification    :
*
*************************************************************************/
void PgsConnection::clearPassword()
{

}

/************************************************************************
*   Function             : PgsConnection::changePassword()
*
*   Description          :
*
*   Arguments            :
*
*   Global var. modified : None
*
*   Return               : None
*
*   Creation date        :
*
*   Last modification    :
*
*************************************************************************/
bool PgsConnection::changePassword(const PasswordEncrypted& password)
{
    return this->changePassword(this->getSpecification().getCredentials().getUser(), password);
}

/************************************************************************
*   Function             : PgsConnection::changePassword()
*
*   Description          :
*
*   Arguments            :
*
*   Global var. modified : None
*
*   Return               : None
*
*   Creation date        :
*
*   Last modification    :
*
*************************************************************************/
bool PgsConnection::changePassword(const  std::string& user, const PasswordEncrypted& password)
{
    RequestHelper requestHelper(this);

    PasswordClear newClearPassword = password.getClearPassword();
    const char* newClearPasswordStr = newClearPassword.getPassword();

    this->setCurrentAction(Special);
    this->m_sqlTraceHideEnd = "password '";
    if (isdigit(user[0]))  /* PMSTA-57524 - 2024-07-31 -Suparna- Bind the User_Cd within double quote to allow numerics as code */
    {
        requestHelper.setCommand("alter user \"" + user + "\" with password '" + newClearPasswordStr + "'");
    }
    else 
        requestHelper.setCommand("alter user " + user + " with password '" + newClearPasswordStr + "'");

    requestHelper.sendAndGetCommand();
    this->m_sqlTraceHideEnd.clear();

    return (RET_GET_LEVEL(requestHelper.getLastResultRetCode()) != RET_LEV_ERROR);
}

void PgsConnection::enableOutput()
{
}

void PgsConnection::disableOutput()
{
}

/************************************************************************
*   Function             :  PgsConnection::setConnMaxRows
*
*   Description          :  Set the max db read nbr value for select in connection
*
*   Arguments            :  max value to read
*
*   Return               :  RET_CODE
*
*   Creation Date        :
*
*************************************************************************/
RET_CODE PgsConnection::setConnMaxRows(int)
{
    RET_CODE ret = RET_SUCCEED;
    return ret;
}

/************************************************************************
*   Function             :  PgsConnection::setDefaultProperties
*
*   Description          :
*
*   Arguments            :
*
*   Return               :  RET_CODE
*
*   Creation Date        :
*
*************************************************************************/
RET_CODE PgsConnection::setDefaultProperties()
{
    RET_CODE ret = RET_SUCCEED;
    return ret;
}

/************************************************************************
*   Function             :  PgsConnection::setDateTimeFormat
*
*   Description          :
*
*   Arguments            :  max value to read
*
*   Return               :  none
*
*   Creation Date        :
*
*************************************************************************/
void PgsConnection::setDateTimeFormat(DATE_STYLE_ENUM)
{
}

/************************************************************************
*   Function             : PgsConnection::doBeginTransaction()
*
*   Description          : Send a "begin tran" command to the server and retrieve
*                          returned status
*
*   Arguments            :
*
*   Return               : RET_SUCCEED              : if no problem was detected
*                          RET_DBA_ERR_DBPROBLEM    : if DB/connection problem
*
*************************************************************************/
RET_CODE PgsConnection::doBeginTransaction()
{
    PQclear(this->m_statement);
    this->m_statement = PQexec(this->m_connection, "BEGIN TRANSACTION");
    this->manageError();
    return this->getLastCmdRetCode();
}

/************************************************************************
*   Function             : PgsConnection::doStartRequest()
*
*   Description          :
*
*   Arguments            :
*
*   Return               : RET_SUCCEED              : if no problem was detected
*                          RET_DBA_ERR_DBPROBLEM    : if DB/connection problem
*
*************************************************************************/
RET_CODE PgsConnection::doStartRequest()
{
    this->m_lastResultRetCode = RET_DBA_ERR_DBPROBLEM;
    this->m_lastSqlCode       = PGRES_EMPTY_QUERY;

    return RET_SUCCEED;
}

/************************************************************************
*   Function             : PgsConnection::endTransaction()
*
*   Description          : Send a "commit tran" or "rollback tran" command to
*                          the server according to the given status.
*
*   WARNING              : if status is different from TRUE or FALSE or if given
*                          connection number is invalid, no command
*                          is sent to the server to close the transaction and the
*                          tables concerned by the transaction stays locked.
*
*   Arguments            : status       : TRUE or FALSE
*
*   Return               : RET_SUCCEED              : if no problem was detected
*                          RET_DBA_ERR_ARGNOMATCH   : if input argument problem
*
*************************************************************************/
RET_CODE PgsConnection::doEndTransaction(const FLAG_T status)
{
    PQclear(this->m_statement);
    switch (status)
    {
        case FALSE:
            this->m_statement = PQexec(this->m_connection, "ROLLBACK TRANSACTION");
            break;
        case TRUE:
            this->m_statement = PQexec(this->m_connection, "COMMIT TRANSACTION");
            break;
    }
    this->manageError();

    return this->getLastCmdRetCode();
}

/************************************************************************
*   Function             :  PgsConnection::setParameters
*
*   Description          :
*
*   Arguments            :
*
*   Return               :  RET_CODE
*
*   Creation Date        :
*
*************************************************************************/
RET_CODE PgsConnection::setParameters()
{
    this->m_lastResultRetCode = RET_SUCCEED;
    this->m_bOutputInParam    = false;

    auto& paramMap = this->getRequestParamMap();

    for (auto &dynFldIt : paramMap)
    {
        DbiInOutData* outputDataPtr = dynFldIt.second;

        if (outputDataPtr->m_bOutput)
        {
            this->m_bOutputInParam = true;
        }

        if (IS_NULLFLD(outputDataPtr->getDynFldStp(), 0) == FALSE)
        {
            switch (GET_CTYPE(outputDataPtr->m_dataType))
            {
                case DoubleCType:
                    break;

                case IntCType:
                    if (outputDataPtr->m_dataType == BlobType)
                    {
                        SYS_BreakOnDebug();
                    }
                    break;

                case UIntCType:
                    break;

                case UCharCType:
                    break;

                case ShortCType:
                    break;

                case UShortCType:
                    break;

                case DateTimeStCType:
                    break;

                case CharPtrCType:
                case TextPtrCType:
                    break;

                case UniCharPtrCType:
                case UniTextPtrCType:
                    break;

                case LongLongCType:
                    break;

                case TimeStampCType:
                    break;

                case BinaryCType:
                    SYS_BreakOnDebug();
                    break;

                case ArrayPtrCType:
                case MultiArrayPtrCType:
                case VarCharPtrCType:
                case VarTextPtrCType:
                case ExtPtrCType:
                case PtrCType:
                default:
                    assert(GET_CTYPE(outputDataPtr->m_dataType) == LastCtype);
            }
        }
    }

    return (this->m_lastResultRetCode);
}

/************************************************************************
*   Function             :  PgsConnection::doSendCommand
*
*   Description          :
*
*   Arguments            :  max value to read
*
*   Return               :  RET_CODE
*
*   Creation Date        :
*
*************************************************************************/
RET_CODE PgsConnection::doSendCommand(DBA_DYNST_ENUM)
{
    this->m_lastResultRetCode = RET_SUCCEED;

    std::string    requestToSend = this->getRequestToSend();

    this->m_refCursorVector.clear();

    if ((this->m_lastResultRetCode = this->createStatement(requestToSend, this->getCurrentAction())) == RET_SUCCEED)
    {
        this->m_lastResultRetCode = this->sendRequest(&this->m_lastResultType);
    }

    if (this->m_lastResultRetCode == RET_SUCCEED)
    {
        (void)this->getNextResultSet();
    }

    return (this->m_lastResultRetCode);
}

/************************************************************************
*   Function             :  PgsConnection::sendRequest
*
*   Description          :
*
*   Arguments            :  max value to read
*
*   Return               :  RET_CODE
*
*   Creation Date        :
*
*************************************************************************/
RET_CODE PgsConnection::sendRequest(DBI_INT * resultType)
{
    this->m_lastResultRetCode = RET_SUCCEED;

    if (this->m_preparedStatement != nullptr &&
        (this->m_lastResultRetCode = this->setParameters()) == RET_SUCCEED)
    {
        if (this->getRequestParamMap().empty())
        {
            PQclear(this->m_statement);
            this->m_statement = PQexecPrepared(this->m_connection,
                                               NO_PARAM_STATMENT,
                                               0,
                                               nullptr,
                                               nullptr,
                                               nullptr,
                                               1);
        }
        else
        {
            int nParams = CAST_INT(this->getRequestParamMap().size());

            char** paramValues = static_cast<char**>(this->m_queryMp.calloc(FILEINFO, nParams, sizeof(char*)));
            int* paramLengths = static_cast<int*>(this->m_queryMp.calloc(FILEINFO, nParams, sizeof(int)));
            int* paramFormats = static_cast<int*>(this->m_queryMp.calloc(FILEINFO, nParams, sizeof(int)));

            for (auto &it : this->getRequestParamMap())
            {
                if (it.second->m_bOutputOnly == false)
                {
                    paramFormats[it.first] = 1;

                    if (it.second->m_nullInd == DBI_GOODDATA ||
                        IS_NULLFLD(it.second->getDynFldStp(), 0) == false)
                    {
                        paramValues[it.first] = (char*)(it.second->m_valuePtr);

                        switch (GET_CTYPE(it.second->m_dataType))
                        {
                            case DoubleCType:
                            {
                                unsigned int maxLen = GET_MAXLEN(it.second->m_dataType);
                                unsigned int maxDec = GET_DECIMAL(it.second->m_dataType);
                                char* buffer = static_cast<char*>(this->m_queryMp.calloc(FILEINFO, NUMBER_STRING_LENGTH, sizeof(char)));
                                if (CONV_DoubleToNumericString(GET_NUMBER(it.second->getDynFldStp(), 0), maxLen, maxDec, buffer) == 0)
                                {
                                    paramValues[it.first] = buffer;
                                }
                                paramFormats[it.first] = 0;
                                paramLengths[it.first] = 0;
                                break;
                            }

                            case IntCType:
                            case UIntCType:
                                if (it.second->m_dataType == BlobType)
                                {
                                    SYS_BreakOnDebug();
                                }
                                else
                                {
                                    *(int*)it.second->m_valuePtr = htonl(*(int*)it.second->m_valuePtr);
                                    paramLengths[it.first] = static_cast<int>(sizeof(int));
                                }
                                break;

                            case LongLongCType:
                            case TimeStampCType:
                                *(ID_T*)it.second->m_valuePtr = htonll(*(ID_T*)it.second->m_valuePtr);
                                paramLengths[it.first] = static_cast<int>(sizeof(ID_T));
                                break;

                            case UCharCType:
                                *(u_short*)it.second->m_valuePtr = htons(*(u_char*)it.second->m_valuePtr);
                                paramLengths[it.first] = static_cast<int>(sizeof(u_short));
                                break;

                            case ShortCType:
                            case UShortCType:
                                *(u_short*)it.second->m_valuePtr = htons(*(u_short*)it.second->m_valuePtr);
                                paramLengths[it.first] = static_cast<int>(sizeof(u_short));
                                break;

                            case DateTimeStCType:
                            {
                                paramFormats[it.first] = 0;

                                DATETIME_T     dateTimeSt = GET_DATETIME(it.second->getDynFldStp(), 0);

                                YEAR_T      yyyy;
                                MONTH_T       mm;
                                DAY_T         dd;
                                HOUR_T         h;
                                MINUTE_T       m;
                                SECOND_T       s;
                                MICROSECOND_T ms;

                                DATE_Get(GET_DATETIME(it.second->getDynFldStp(), 0).date, &yyyy, &mm, &dd);
                                TIME_Get(GET_DATETIME(it.second->getDynFldStp(), 0).time, &h, &m, &s, &ms);

                                if (yyyy > 0)
                                {
                                    char* buffer = static_cast<char*>(this->m_queryMp.calloc(FILEINFO, TIME_STRING_LENGTH, sizeof(char)));
                                    if (it.second->m_paramDataType == DateType)
                                    {
                                        sprintf(buffer, "%04d%02d%02d", yyyy, mm, dd);
                                    }
                                    else if (EV_EnableMicrosecTime)
                                    {
                                        sprintf(buffer, "%04d%02d%02dT%02d%02d%02d.%03d", yyyy, mm, dd, h, m, s, ms);
                                    }
                                    else
                                    {
                                        sprintf(buffer, "%04d%02d%02dT%02d%02d%02d", yyyy, mm, dd, h, m, s);
                                    }
                                    paramValues[it.first] = buffer;
                                }
                                else
                                {
                                    SYS_BreakOnDebug();

                                    paramValues[it.first] = nullptr;
                                    paramLengths[it.first] = 0;
                                }
                                break;
                            }
                            case CharPtrCType:
                            case TextPtrCType:
                                paramFormats[it.first] = 0;
                                paramLengths[it.first] = 0;
                                break;

                            case UniCharPtrCType:
                            case UniTextPtrCType:
                                SYS_BreakOnDebug();
                                break;

                            case BinaryCType:
                                SYS_BreakOnDebug();
                                break;

                            case ArrayPtrCType:
                            case MultiArrayPtrCType:
                            case VarCharPtrCType:
                            case VarTextPtrCType:
                            case ExtPtrCType:
                            case PtrCType:
                            default:
                                assert(GET_CTYPE(it.second->m_dataType) == LastCtype);
                        }
                    }
                    else
                    {
                        paramValues[it.first] = nullptr;
                        paramLengths[it.first] = 0;
                    }
                }
                else
                {
                    nParams--;
                }
            }

            PQclear(this->m_statement);
            this->m_statement = PQexecPrepared(this->m_connection,
                                               PARAM_STATMENT,
                                               nParams,
                                               paramValues,
                                               paramLengths,
                                               paramFormats,
                                               0);
        }

        this->manageError();

        if (this->m_lastSqlCode == PGRES_TUPLES_OK && 
            this->m_bOutputInParam)
        {
            if (this->getNextResultSet() == RET_SUCCEED &&
                this->m_rowNumber == 1)
            {
                this->m_rowPos = 0;

                int colNum = 0;
                for (auto &it : this->getRequestParamMap())
                {
                    if (it.second->m_bOutput)
                    {
                        this->applFetchedResult(colNum,
                                                it.second->m_dataType,
                                                it.second->m_valuePtr,
                                                it.second->getAllocSize(),
                                                &it.second->m_nullInd,
                                                &it.second->getDynFldStp()->flgMask);
                        it.second->updOutputData();

                        colNum++;
                    }
                }
                this->m_rowNumber = -1;
            }
            else
            {
                this->manageError("ERROR: Output parameter is expected but not received!");
            }
        }
    }

    if (this->m_lastSqlCode == PGRES_TUPLES_OK)
    {
        Oid sqlType = PQftype(this->m_statement, 0);

        if (sqlType == REFCURSOROID)
        {
            int rowNumber = PQntuples(this->m_statement);
            for (int rowPos = 0; rowPos < rowNumber; ++rowPos)
            {
                const char* valPtr = PQgetvalue(this->m_statement, rowPos, 0);
                this->m_refCursorVector.push_back(valPtr);
            }
        }

        *resultType = DBI_ROW_RESULT;
    }
    else if (this->m_lastSqlCode == PGRES_COMMAND_OK)
    {
        *resultType = DBI_CMD_SUCCEED;
    }
    else
    {
        *resultType = DBI_FAIL;
    }

    this->m_lastResultType = *resultType;

    return this->m_lastResultRetCode;
}

/************************************************************************
*   Function             : PgsConnection::doReleaseCommand()
*
*   Description : If Oracle statement in command PTR the we delete the Statement
*
*   Arguments : connectNo : the connection number in the connection
*                                      list.
*
*   Global var.modified : None
*
*   Return : TRUE if ok
*            FALSE if problem
*
*************************************************************************/
RET_CODE PgsConnection::doReleaseCommand()
{
    if (this->m_preparedStatement != nullptr)
    {
        PQclear(this->m_preparedStatement);
        this->m_preparedStatement = nullptr;
    }
    if (this->m_statement != nullptr)
    {
        PQclear(this->m_statement);
        this->m_statement = nullptr;
    }

    this->m_lastSqlCode     = PGRES_EMPTY_QUERY;
    this->m_rowNumber       = -1;
    this->m_rowPos          = -1;
    this->m_maxSizeMap.clear();
    this->m_queryMp.freeAll();
    this->m_refCursorVector.clear();

    return RET_SUCCEED;
}

/************************************************************************
*   Function             : DbiConnection::isForceBlockSqlCmd()
*
*   Description          :
*   Arguments            :
*
*   Return               :
*
*************************************************************************/
bool PgsConnection::isForceBlockSqlCmd()
{
    return true;
}

/************************************************************************
*   Function             : PgsConnection::isDbTransactionRequired()
*
*   Description : If we must open a transaction
*
*
*   Global var.modified : None
*
*   Return :
*
*************************************************************************/
bool PgsConnection::isDbTransactionRequired()
{
    return true;
}

/************************************************************************
*   Function             : PgsConnection::isDdlGenOnTran()
*
*   Description          :
*
*
*   Global var.modified : None
*
*   Return :
*
*************************************************************************/
bool PgsConnection::isDdlGenOnTran()
{
    return true;
}

/************************************************************************
*   Function             :  PgsConnection::getDefaultCharset
*
*   Description          :
*
*   Arguments            :
*
*   Return               :  The default charset
*
*   Creation Date        :
*
*************************************************************************/
std::string PgsConnection::getDefaultCharset()
{
    /* SELECT pg_encoding_to_char(encoding) FROM pg_database WHERE datname = 'yourdb'; */

    return "UTF8";
}

std::string PgsConnection::getConnectionCharset()
{
    return this->getDefaultCharset();
}

RET_CODE PgsConnection::setAppContextProperty(const std::string &propertyName, const std::string &propertyValue)
{
    RET_CODE retCode = RET_DBA_ERR_SETPARAM;
    int *rmValue = nullptr, *setValue = nullptr;
    char *getValue = nullptr;

    std::stringstream command;
    std::string mainDb;
    GEN_GetApplInfo(ApplSqlDbName, mainDb);

    command << "select " << mainDb << ".rm_appcontext('TASC_CONTEXT', '" << propertyName << "')";

    if (propertyValue.empty())
    {
        command << ", 0, ''";
    }
    else
    {
        command
            << ", " << mainDb << ".set_appcontext('TASC_CONTEXT', '" << propertyName << "', '" << propertyValue + "')"
            << ", " << mainDb << ".get_appcontext('TASC_CONTEXT', '" << propertyName << "')";
    }
    command << " from dual";

    RequestHelper requestHelper(this);

    requestHelper.setCommand(command.str());

    requestHelper.addNewOutputData(IntType);
    requestHelper.getBindVariablePtr(rmValue);
    requestHelper.addNewOutputData(IntType);
    requestHelper.getBindVariablePtr(setValue);
    requestHelper.addNewOutputData(NoteType);
    requestHelper.getBindVariablePtr(getValue);

    if (requestHelper.sendAndGetCommand() == RET_SUCCEED)
    {
        if (*rmValue != 0)
        {
            std::stringstream msg;
            msg << "Remove appContext error for connection=" << this->getId() << ", Properties=" << propertyName;
            MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, msg.str().c_str());
            retCode = RET_SUCCEED; /* if the rm is not working an error will be raised on NEW else the appContext was not set*/
        }

        if (*setValue == 0 && propertyValue.compare(getValue) == 0)
        {
            retCode = RET_SUCCEED;
        }
        else
        {
            std::stringstream msg;
            msg << "Set appContext error for connection=" << this->getId() << ", Properties=" << propertyName << ", Value=" << propertyValue;
            MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, msg.str().c_str());
        }
    }

    return retCode;
}

bool PgsConnection::isUtf16Allowed()
{
    return false;
}

RET_CODE PgsConnection::prepareReceivedData()
{
    this->m_resultSetPos = 0;
    return true;
}

RET_CODE PgsConnection::colBind(int                colNum,
                                DATATYPE_ENUM      type,
                                const std::string &colName,
                                DBI_PTR            dataPtr,
                                size_t             allocSize,
                                DBI_INT           *dataLength,
                                DBI_SMALLINT      *nullData,
                                bool               dynFldFlag,
                                unsigned char     *nullIndicatorDynFld,
                                DbiInOutData* dbiInOutDataPtr)
{
    if (static_cast<int>(this->getRequestBindDataVector().size()) < colNum)
    {
        this->getRequestBindDataVector().resize(colNum);
    }
    DbiBindData& bindData = this->getRequestBindDataVector()[static_cast<std::vector<DbiBindData, std::allocator<DbiBindData>>::size_type>(colNum) - 1];

    bindData.m_dataType        = type;
    bindData.m_columnNbr       = colNum;
    bindData.m_dbiInOutDataPtr = dbiInOutDataPtr;

    if (dynFldFlag &&
        (GET_CTYPE(type) == CharPtrCType ||
        GET_CTYPE(type) == TextPtrCType ||
        GET_CTYPE(type) == UniCharPtrCType ||
        GET_CTYPE(type) == UniTextPtrCType))
    {
        bindData.m_dataIn = *((void **)dataPtr);
    }
    else
    {
        bindData.m_dataIn = dataPtr;
    }
    bindData.m_dataLength          = dataLength;
    bindData.m_nullValue           = nullData;
    bindData.m_bDynFld             = dynFldFlag;
    bindData.m_nullIndicatorDynFld = nullIndicatorDynFld;
    bindData.m_allocSize           = allocSize;
    bindData.m_columnName          = colName;

    return RET_SUCCEED;
}

void PgsConnection::applFetchedResult(int           colNum, 
                                      DATATYPE_ENUM dataType, 
                                      void          *dataPtr, 
                                      size_t         allocSize,
                                      SMALLINT_T    *nullValue, 
                                      unsigned char *nullIndicatorDynFld)
{
    if (PQgetisnull(this->m_statement, this->m_rowPos, colNum) == 1)
    {
        *nullValue = DBI_NULLDATA;
    }
    else
    {
        *nullValue = DBI_GOODDATA;

        const char* valPtr = PQgetvalue(this->m_statement, this->m_rowPos, colNum);
        
        if (PQfformat(this->m_statement, colNum) == 0)
        {
            switch (GET_CTYPE(dataType))
            {
                case IntCType:
                    if (dataType == BlobType)
                    {
                        SYS_BreakOnDebug();
                    }
                    else
                    {
                        *(static_cast<int*>(dataPtr)) = atoi(valPtr);
                    }
                    break;

                case UIntCType:
                    *(static_cast<unsigned int*>(dataPtr)) = atoi(valPtr);
                    break;

                case ShortCType:
                    *(static_cast<short*>(dataPtr)) = static_cast<short>(atoi(valPtr));
                    break;

                case UCharCType:
                    if (valPtr[0] == 't')
                    {
                        *(static_cast<unsigned char*>(dataPtr)) = TRUE;
                    }
                    else if (valPtr[0] == 'f')
                    {
                        *(static_cast<unsigned char*>(dataPtr)) = FALSE;
                    }
                    else
                    {
                        *(static_cast<unsigned char*>(dataPtr)) = static_cast<unsigned char>(atoi(valPtr));
                    }
                    break;

                case UShortCType:
                    *(static_cast<unsigned short*>(dataPtr)) = static_cast<unsigned short>(atoi(valPtr));
                    break;

                case TimeStampCType:
                {
                    char* endptr = nullptr;
                    *(static_cast<TIMESTAMP_T*>(dataPtr)) = strtoull(valPtr, &endptr, 10);
                    break;
                }

                case LongLongCType:
                    *(static_cast<ID_T*>(dataPtr)) = atoll(valPtr);
                    break;

                case DoubleCType:
                    *(static_cast<double*>(dataPtr)) = atof(valPtr);
                    break;

                case CharPtrCType:
                case TextPtrCType:
                    strncpy((static_cast<char*>(dataPtr)), valPtr, allocSize - 1);
                    (static_cast<char*>(dataPtr))[allocSize - 1] = 0;
                    break;

                case DateTimeStCType:
                {
                    const QDateTime     qDateTime = QDateTime::fromString(valPtr, Qt::ISODate);
                    const QDate         qDate(qDateTime.date());
                    const QTime         qTime(qDateTime.time());

                    MICROSECOND_T       msec = 0;
                    if (EV_EnableMicrosecTime)
                    {
                        fetchMicrosecsFromDatetimeStr(valPtr, &msec);
                    }

                    DATETIME64_STP dateTime = static_cast<DATETIME64_STP>(dataPtr);
                    dateTime->setDate(DATE_Put(static_cast<YEAR_T>(qDate.year()), static_cast<MONTH_T>(qDate.month()), static_cast<DAY_T>(qDate.day())));
                    dateTime->setTime(TIME_Put(static_cast<HOUR_T>(qTime.hour()), static_cast<MINUTE_T>(qTime.minute()), static_cast<SECOND_T>(qTime.second()), msec));
                    break;
                }

                default:
                    SYS_BreakOnDebug();
            }

        }
        else
        {
            Oid sqlType = PQftype(this->m_statement, colNum);

            switch (sqlType)
            {
                case INT4OID:
                {
                    int ival = ntohl(*((uint32_t*)valPtr));

                    switch (GET_CTYPE(dataType))
                    {
                        case IntCType:
                            if (dataType == BlobType)
                            {
                                SYS_BreakOnDebug();
                            }
                            else
                            {
                                *(static_cast<int*>(dataPtr)) = ival;
                            }
                            break;

                        case UIntCType:
                            *(static_cast<unsigned int*>(dataPtr)) = ival;
                            break;

                        case ShortCType:
                            *(static_cast<short*>(dataPtr)) = static_cast<short>(ival);
                            break;

                        case UCharCType:
                            *(static_cast<unsigned char*>(dataPtr)) = static_cast<unsigned char>(ival);
                            break;

                        case UShortCType:
                            *(static_cast<unsigned short*>(dataPtr)) = static_cast<unsigned short>(ival);
                            break;

                        case TimeStampCType:
                            *(static_cast<TIMESTAMP_T*>(dataPtr)) = ival;
                            break;

                        case LongLongCType:
                            *(static_cast<ID_T*>(dataPtr)) = ival;
                            break;

                        case DoubleCType:
                            *(static_cast<double*>(dataPtr)) = ival;
                            break;

                        default:
                            SYS_BreakOnDebug();
                    }
                    break;
                }

                case INT8OID:
                {
                    ID_T ival = ntohll(*((ID_T*)valPtr));

                    switch (GET_CTYPE(dataType))
                    {
                        case LongLongCType:
                            *(static_cast<ID_T*>(dataPtr)) = ival;
                            break;

                        default:
                            SYS_BreakOnDebug();
                    }
                    break;
                }

                case TEXTOID:
                case NAMEOID:
                    strncpy((static_cast<char*>(dataPtr)), valPtr, allocSize - 1);
                    (static_cast<char*>(dataPtr))[allocSize - 1] = 0;
                    break;

                default:
                    SYS_BreakOnDebug();
            }
        }
    }

    if (nullIndicatorDynFld != nullptr)
    {
        SET_BIT((*nullIndicatorDynFld), BIT_NOTNULLFLG, *nullValue == DBI_GOODDATA ? TRUE : FALSE);
    }
}

RET_CODE PgsConnection::fetch()
{
    this->m_lastResultRetCode = this->bindRequestOutput();

    if (this->m_lastResultRetCode == RET_SUCCEED)
    {
        this->m_rowPos++;

        if (this->m_rowPos < this->m_rowNumber)
        {
            for (auto &it : this->getRequestBindDataVector())
            {
                int colNum = it.m_columnNbr - 1;

                this->applFetchedResult(colNum,
                                        it.m_dataType,
                                        it.m_dataIn,
                                        it.m_allocSize,
                                        it.m_nullValue,
                                        it.m_nullIndicatorDynFld);
            }
        }
        else
        {
            this->m_lastResultRetCode = RET_DBA_INFO_NO_MORE_DATA;
            this->m_lastResultType = DBI_CMD_SUCCEED;
        }
    }

    return this->m_lastResultRetCode;
}

RET_CODE PgsConnection::getNextResultSet()
{
    this->m_lastResultRetCode = RET_SUCCEED;

    if (this->m_refCursorVector.empty() == false)
    {
        this->m_resultSetPos++;

        if (this->m_resultSetPos < CAST_INT(this->m_refCursorVector.size()))
        {
            if (this->m_resultSetPos > 0)
            {
                PQclear(this->m_statement);
                this->m_statement = PQexec(this->m_connection, std::string("close \"" + this->m_refCursorVector[this->m_resultSetPos - 1] + "\"").c_str());
            }

            PQclear(this->m_statement);
            this->m_statement = PQexec(this->m_connection, std::string("fetch all in \"" + this->m_refCursorVector[this->m_resultSetPos] + "\"").c_str());

            this->manageError();

            this->m_rowNumber = -1;
        }
        else
        {
            if (this->m_resultSetPos > 0)
            {
                PQclear(this->m_statement);
                this->m_statement = PQexec(this->m_connection, "close all");
            }

            this->m_lastSqlCode = PGRES_EMPTY_QUERY;
        }
    }

    if (this->m_statement != nullptr &&
        this->m_lastSqlCode == PGRES_TUPLES_OK &&
        this->m_rowNumber == -1)
    {
        this->m_rowNumber = PQntuples(this->m_statement);
        this->m_rowPos = -1;
        this->m_maxSizeMap.clear();

        this->m_lastResultType = DBI_ROW_RESULT;
    }
    else
    {
        this->m_lastResultRetCode = RET_DBA_INFO_NO_MORE_DATA;
        this->m_lastResultType = DBI_CMD_SUCCEED;
    }
    return this->m_lastResultRetCode;
}

RET_CODE PgsConnection::copyNullFlagsAndLengthDynSt(DBA_DYNFLD_STP, DBA_DYNST_ENUM)
{
    return RET_SUCCEED;
}

/************************************************************************
**
**  Function    :   PgsConnection::processAllResults()
**
**  Description :
**
**  Argument    :
**
**  Return      :
**
**  Creation    :
**
**  Last modif. :
**
*************************************************************************/
RET_CODE PgsConnection::processAllResults(DBI_INT       *status,
                                          OBJECT_ENUM    ,
                                          DBA_DYNST_ENUM ,
                                          DBA_DYNFLD_STP record,
                                          DBA_PROC_STP   procedureStp)
{
    std::set<DbiBatchOutput>  batchOutputSet;

    if ((procedureStp != nullptr &&
        (procedureStp->procMask & PROCMASK_USE_TEMP_TABLE_PARAM) == PROCMASK_USE_TEMP_TABLE_PARAM) ||
        this->m_bOnBatchOutput)
    {
        this->m_bOnBatchOutput = false;

        RequestHelper requestHelper(this);

        requestHelper.setCommand("select row_num_n, id, row_version from #batch_output");

        INT_T       *rowNumPtr     = nullptr;
        ID_T        *idPtr         = nullptr;
        TIMESTAMP_T *rowVersionPtr = nullptr;

        requestHelper.addNewOutputData(IntType);
        requestHelper.getBindVariablePtr(rowNumPtr);
        requestHelper.addNewOutputData(IdType);
        requestHelper.getBindVariablePtr(idPtr);
        requestHelper.addNewOutputData(TimeStampTType);
        requestHelper.getBindVariablePtr(rowVersionPtr);

        const AAALogger& sqlTraceLog = AAALogger::get(AAALogger::Logger::SqlTrace);
        if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
        {
            auto& sqlTrace = this->getSqlTrace();
            sqlTrace.m_procedure = "DynSql.Batch.Read.batch_output";
            sqlTrace.m_mode = DbiSqlTrace::Mode::Lang;
        }

        this->setCurrentAction(Custom);

        if (requestHelper.sendCommandForFetch() == RET_SUCCEED)
        {
            while (requestHelper.fetch() == RET_SUCCEED)
            {
                DbiBatchOutput newBatchOutput;

                newBatchOutput.rowNum = *rowNumPtr;
                if (idPtr != nullptr)
                {
                    newBatchOutput.id = *idPtr;
                }
                if (rowVersionPtr != nullptr)
                {
                    newBatchOutput.rowVersion = *rowVersionPtr;
                }

                batchOutputSet.insert(newBatchOutput);
            }
        }

        requestHelper.setCommand("truncate table #batch_output");
        requestHelper.sendAndGetCommand();

        if (this->m_lastResultRetCode == RET_DBA_INFO_NO_MORE_DATA)
        {
            this->m_lastResultRetCode = RET_SUCCEED;
        }
    }

    if (batchOutputSet.empty() == false)
    {
        if (batchOutputSet.size() == 1 &&
            (record != nullptr || procedureStp == nullptr))
        {
            for (auto outputIt = batchOutputSet.begin(); outputIt != batchOutputSet.end(); ++outputIt)
            {
                for (auto &it : this->getRequestParamMap())
                {
                    if (it.second->m_bOutput)
                    {
                        if (it.second->m_dataType == IdType)
                        {
                            if (record != nullptr)
                            {
                                SET_ID(record, it.second->m_outputFieldIdx, outputIt->id);
                            }
                            else
                            {
                                SET_ID(it.second->getDynFldStp(), 0, outputIt->id);
                            }
                        }
                        else if (it.second->m_dataType == TimeStampType)
                        {
                            if (record != nullptr)
                            {
                                SET_TIMESTAMP(record, it.second->m_outputFieldIdx, outputIt->rowVersion);
                            }
                            else
                            {
                                SET_TIMESTAMP(it.second->getDynFldStp(), 0, outputIt->rowVersion);
                            }
                        }
                        else
                        {
                            SYS_BreakOnDebug();
                        }
                    }
                }
            }
        }
        else
        {
            this->getSqlRequest().m_batchOutputSet = batchOutputSet;
        }
    }

    if (this->m_lastResultRetCode == RET_DBA_INFO_NO_MORE_DATA)
    {
        this->m_lastResultRetCode = RET_SUCCEED;
    }

    if (status != nullptr)
    {
        *status = 1;  /* PMSTA-46731 - DDV - 211124 - 1 means SUCCESS and 0 means ERROR */
    }

    return(this->m_lastResultRetCode);
}


/************************************************************************
*   Function             : PgsConnection::cancellDbRequest()
*
*   Description          : Cancel all results pending
*
*   Arguments            : connectNo : a connection number in the connection
*                                      list
*                          level     : CONNECTION_LEVEL or COMMAND_LEVEL
*                          mode      : CANCEL_CURRENT or CANCEL_ATTN or
*                                      CANCEL_ALL
*
*   Functions call       : None
*
*   Global var. modified : None
*
*   Return               : TRUE if ok
*                          FALSE if problem
*
*
*************************************************************************/
RET_CODE PgsConnection::cancelDbRequest(int level, int mode)
{
    if (((level != CONNECTION_LEVEL) && (level != COMMAND_LEVEL)) || ((mode != CANCEL_CURRENT) && (mode != CANCEL_ATTN) && (mode != CANCEL_ALL)))
    {
        char          errMsg[256];

        if ((SYS_IsGuiMode() == TRUE) || (SERVER_IS_INIT() == TRUE))
        {
            sprintf(errMsg, "Connection (" szFormatPointer "), thread (" szFormatPointer "), level (%s), mode (%s)",
                (void*)this->getConnStructPtr(),
                DBA_GetCurrThread(),
                (level == CONNECTION_LEVEL) ? "Connection" :
                (level == COMMAND_LEVEL) ? "Command" :
                "Unknown",
                (mode == CANCEL_CURRENT) ? "Cancel current" :
                (mode == CANCEL_ATTN) ? "Cancel attn" :
                (mode == CANCEL_ALL) ? "Cancel all" :
                "Unknown");

            MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "PgsConnection::cancelDbRequest", errMsg);
        }
        else
        {
            sprintf(errMsg, "PgsConnection::cancelDbRequest. Invalid argument. Connection (" szFormatPointer "), thread (" szFormatPointer "), level (%s), mode (%s)",
                (void*)this->getConnStructPtr(),
                DBA_GetCurrThread(),
                (level == CONNECTION_LEVEL) ? "Connection" :
                (level == COMMAND_LEVEL) ? "Command" :
                "Unknown",
                (mode == CANCEL_CURRENT) ? "Cancel current" :
                (mode == CANCEL_ATTN) ? "Cancel attn" :
                (mode == CANCEL_ALL) ? "Cancel all" :
                "Unknown");

            MSG_SendStrToLog(errMsg);
        }

        return(RET_GEN_ERR_INVARG);
    }

    this->releaseCommand();

    return RET_SUCCEED;
}

/************************************************************************
**
**  Function    :   PgsConnection::setDefaultReadOnly()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-49178 - LJE - 220912
**
*************************************************************************/
void  PgsConnection::setDefaultReadOnly(DBA_PROC_STP procedureStp, RequestHelper *requestHelperPtr)
{
    if (procedureStp != nullptr &&
        (procedureStp->outputDynStPtr != nullptr ||
         procedureStp->multiOutputDynStPtr != nullptr))
    {
        this->setReadOnly(false);
        if (requestHelperPtr != nullptr)
        {
            requestHelperPtr->setReadOnly(false);
        }
    }
}

/************************************************************************
**
**  Function    :   PgsConnection::getTransState()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
int PgsConnection::getTransState()
{
    return 0;
}

std::string PgsConnection::endOfCmd()
{
    return ";";
}

RET_CODE PgsConnection::getLastCmdRetCode()
{
    return this->m_msgErrorHelper.getRetCode(this->m_lastSqlCode, nullptr, nullptr);
}


RET_CODE PgsConnection::getCmdRetCode(int msgIdx)
{
    if (msgIdx < this->m_msgStack.size())
    {
        return this->m_msgErrorHelper.getRetCode(this->m_msgStack.getMember(msgIdx).rdbmsMsgNb, nullptr, nullptr);
    }
    return RET_SUCCEED;
}

bool PgsConnection::isSamePasswordMsg()
{
    return false;
}

bool PgsConnection::isWarningMsgToHide(const DbaErrmsgInfosClass &)
{
    return false;
}

bool PgsConnection::convParamFromPos(std::string &allParam, std::string::size_type &posParam, int paramNbr, const std::string& paramName)
{
    SYSNAME_T conStr;
    sprintf(conStr, "$%d", paramNbr);
    allParam.replace(posParam, paramName.size(), conStr);
    posParam += strlen(conStr);

    return false;
}

RET_CODE PgsConnection::convertToRetCode(int pgsCode)
{
    if (pgsCode)
    {
        return this->m_msgErrorHelper.getRetCode(pgsCode, nullptr, nullptr);
    }
    return RET_SUCCEED;
}

Oid PgsConnection::getPostgreSQLDataType(DATATYPE_ENUM dataType)
{
    switch (GET_CTYPE(dataType))
    {
    case DoubleCType:
        return NUMERICOID;
        break;

    case UIntCType:
    case IntCType:
        if (dataType == BlobType)
        {
            return BYTEAOID;
        }
        else
        {
            return INT4OID;
        }
        break;

    case ShortCType:
    case UShortCType:
    case UCharCType:
        return INT2OID;
        break;

    case DateTimeStCType:
        return TIMESTAMPOID;
        break;

    case CharPtrCType:
    case UniCharPtrCType:
    case TextPtrCType:
    case UniTextPtrCType:
        return TEXTOID;
        break;

    case LongLongCType:
    case TimeStampCType:
    case BinaryCType:
        return INT8OID;
        break;

    case ArrayPtrCType:
    case MultiArrayPtrCType:
    case VarCharPtrCType:
    case VarTextPtrCType:
    case ExtPtrCType:
    case PtrCType:
    default:
        assert(dataType == LastCtype);
    }

    return 0;
}



CTYPE_ENUM PgsConnection::getCType(Oid sqlType)
{
    switch (sqlType)
    {
        case BOOLOID:
            return CharPtrCType;
            break;

        case INT8OID:
            return LongLongCType;
            break;

        case INT4OID:
            return IntCType;
            break;

        case INT2OID:
            return ShortCType;
            break;

        case NUMERICOID:
            return DoubleCType;
            break;

        case TEXTOID:
        case NAMEOID:
        case VARCHAROID:
            return CharPtrCType;
            break;

        case DATEOID:
        case TIMESTAMPOID:
            return DateTimeStCType;
            break;

        case VOIDOID:
            return CharPtrCType;
            break;

        case BYTEAOID:
            SYS_BreakOnDebug();
            return IntCType;
            break;

    }

    SYS_BreakOnDebug();
    return LastCtype;
}

void PgsConnection::manageError()
{
    PGresult* statement = (this->m_statement != nullptr ? this->m_statement : this->m_preparedStatement);

    if (statement != nullptr)
    {
        this->m_lastSqlCode = PQresultStatus(statement);

        if (this->m_lastSqlCode != PGRES_COMMAND_OK &&
            this->m_lastSqlCode != PGRES_TUPLES_OK &&
            this->m_lastSqlCode != PGRES_COPY_IN)
        {
            this->manageError(PQresultErrorMessage(statement), statement);
        }
    }
    else if (this->m_connection != nullptr)
    {
        this->manageError(PQerrorMessage(this->m_connection));
        if (RET_GET_LEVEL(this->m_lastResultRetCode) == RET_LEV_ERROR)
        {
            this->m_lastSqlCode = PGRES_FATAL_ERROR;

            this->setValidConnection(false);
        }
    }
    else
    {
        this->setValidConnection(false);
    }
}

void PgsConnection::manageError(const char* errorMessage, const PGresult* statement)
{
    if (errorMessage != nullptr && errorMessage[0] != 0)
    {
        DbaMsgStackMemberClass& msgMember = this->m_msgStack.getNewMember();

        char* severity = nullptr;
        char* sqlstate = nullptr;
        if (statement != nullptr)
        {
            severity = PQresultErrorField(statement, PG_DIAG_SEVERITY);
            sqlstate = PQresultErrorField(statement, PG_DIAG_SQLSTATE);
        }

        msgMember.msgOrigin        = ServerHandler;
        msgMember.rdbmsMsgNb       = this->m_lastSqlCode;
        msgMember.retCode          = this->m_msgErrorHelper.getRetCode(msgMember.rdbmsMsgNb, severity, sqlstate);
        msgMember.msgString        = errorMessage;
        this->m_lastResultRetCode  = msgMember.retCode;
        this->m_msgStack.lastMsgNb = msgMember.rdbmsMsgNb;

        if (severity != nullptr)
        {
            msgMember.severityStr = severity;

            if (strcmp(severity, "FATAL") == 0)
            {
                this->m_lastResultRetCode = RET_SRV_LIB_ERR_CONNFAILED;

                this->setValidConnection(false);
            }
        }
        else
        {
            auto connStatus = PQstatus(this->m_connection);
            if (connStatus == CONNECTION_BAD)
            {
                this->m_lastResultRetCode = RET_SRV_LIB_ERR_CONNFAILED;

                this->setValidConnection(false);
            }
        }

        if (sqlstate != nullptr)
        {
            bool bError = strcmp(sqlstate, "P0001") == 0;

            if (bError == false &&
                strcmp(sqlstate, "01000") == 0)
            {
                if (msgMember.msgString.find("Error - ") == 0)
                {
                    msgMember.msgString.erase(0, 8);
                    bError = true;

                    this->m_lastSqlCode = PGRES_FATAL_ERROR;
                    msgMember.rdbmsMsgNb = this->m_lastSqlCode;

                    this->m_lastResultRetCode = RET_DBA_ERR_WITH_COMMIT;
                    msgMember.retCode = msgMember.retCode;
                }
            }

            if (bError)
            {
                auto pos = msgMember.msgString.find_first_of("0123456789");
                if (pos != std::string::npos)
                {
                    msgMember.applMsgNb = atoi(msgMember.msgString.substr(pos, msgMember.msgString.find_first_not_of("0123456789", pos)).c_str());

                    switch (msgMember.applMsgNb)
                    {
                        case MSG_INFO_EXTERNAL_SEQ:
                            msgMember.retCode = RET_DBA_INFO_EXTERNAL_SEQ;
                    }
                }
            }

            msgMember.stateStr    = sqlstate;
        }

        const AAALogger& connectionLog = AAALogger::get(AAALogger::Logger::Connections);
        if (connectionLog.isInfoEnabled())
        {
            std::string	logMessage = SYS_Stringer("No: ", msgMember.retCode, " - ",
                                                  "NativeError: ", msgMember.rdbmsMsgNb, " - ",
                                                  "Severity: ", msgMember.severityStr, " - ",
                                                  "SqlState: ", msgMember.stateStr, " - ",
                                                  "ErrorMsg: ", msgMember.msgString);
            if (connectionLog.isTraceEnabled())
            {
                logMessage += " - Callstack: \n" + SYS_GetCallStack(0, true);
            }

            connectionLog.info(logMessage);
        }

        if (EV_ExtractFile)
        {
            std::string			sqlTraceStr("error in the upper call with error: ");
            fputs(sqlTraceStr.append(msgMember.msgString).c_str(), EV_ExtractFile);
            fputs("\n", EV_ExtractFile);
            fflush(EV_ExtractFile);
        }
    }
}

PGS_MsgError::PGS_MsgError()
{
}

PGS_MsgError::~PGS_MsgError()
{
}

RET_CODE PGS_MsgError::getRetCode(int errorCodeEn, const char* severity, const char*)
{
    switch (errorCodeEn)
    {
        case PGRES_COMMAND_OK:
        case PGRES_TUPLES_OK:
            return RET_SUCCEED;

        case PGRES_EMPTY_QUERY:
            return RET_DBA_INFO_NODATA;

        case PGRES_NONFATAL_ERROR:
            return RET_DBA_INFO_NO_MORE_DATA;

        case PGRES_BAD_RESPONSE:
        default:

            RET_CODE err = RET_DBA_ERR_DBPROBLEM;

            if (severity != nullptr)
            {
                if (strcmp(severity, "ERROR") == 0)
                {
                    err = RET_DBA_ERR_DBPROBLEM;
                }
                else if (strcmp(severity, "WARNING") == 0)
                {
                    err = RET_DBA_INFO_EXIST;
                }
                else if (strcmp(severity, "FATAL") == 0)
                {
                    err = RET_DBA_ERR_CONNLOST;
                }
            }

            return err;
    }
}

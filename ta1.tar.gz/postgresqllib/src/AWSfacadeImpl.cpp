#ifdef NTWIN
#pragma warning (push)
#pragma warning(disable:4996)
#endif


#include "AWSfacadeImpl.h"
#ifdef _WIN32
#pragma warning(disable:4996)
#endif

#include "aws/core/Aws.h"

#ifdef _WIN32
#pragma warning(default:4996)
#endif

#include "aws/rds/RDSClient.h"

#ifdef NTWIN
#pragma warning (pop)
#endif



std::string AWSfacade::GenerateConnectAuthToken(const char* dbHostName, const char* dbRegion, unsigned dbPort, const char* dbUserName) const
{

    Aws::Client::ClientConfiguration clientConfig;

    Aws::RDS::RDSClient RDSclient(clientConfig);

    Aws::String result = RDSclient.GenerateConnectAuthToken(dbHostName, dbRegion, dbPort, dbUserName);
    return result;

}


AWSfacade::AWSfacade()
{
    Aws::SDKOptions options;
    //    options.loggingOptions.logLevel = Aws::Utils::Logging::LogLevel::Trace;

    Aws::InitAPI(options);
}

AWSfacade::~AWSfacade()
{
    Aws::SDKOptions options;
    Aws::ShutdownAPI(options);
}


std::unique_ptr<AWSfacade>
AWSfacadeFactory::Create()
{
    std::unique_ptr<AWSfacade> awsFacade( new AWSfacade());
    return awsFacade;
}

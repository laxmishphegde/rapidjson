/************************************************************************
**
**              Copyright (C) Temenos Software Luxembourg SA 1995-2021.
**                       All Rights Reserved
**
**                   Portfolio Management System
**
*************************************************************************/
#ifndef PGSLIB_H
#define PGSLIB_H
#include "dbi.h"

class DbiConnection;

extern RET_CODE PGS_InitializeContext(); 

extern void     PGS_PrintVersion();

extern RET_CODE PGS_InsApplUserById(DBA_DYNFLD_STP, DbiConnection&);


#endif
/************************************************************************
**      END        sqlitelib.h
*************************************************************************/

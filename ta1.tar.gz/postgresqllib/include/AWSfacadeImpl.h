#pragma once
#include "AWSfacade.h"
#include  <chrono>


class AWSfacade : public AWSfacadeI {
public:

    virtual std::string GenerateConnectAuthToken(const char* dbHostName, const char* dbRegion, unsigned port, const char* dbUserName) const;

    AWSfacade();
    virtual ~AWSfacade();

};


class AWSfacadeFactory
{
public:
    /**
     * Create a AWSfacade.
     */
    static std::unique_ptr<AWSfacade> Create();

};

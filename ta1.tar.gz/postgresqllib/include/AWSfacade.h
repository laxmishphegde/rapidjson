#pragma once
#include <mutex>
#include <memory>

class AWSfacadeI {
public:

    virtual std::string GenerateConnectAuthToken(const char* dbHostName, const char* dbRegion, unsigned port, const char* dbUserName) const = 0;

};

class NoopAWSfacade : public AWSfacadeI {
public:

    virtual std::string GenerateConnectAuthToken(const char*, const char*, unsigned, const char*) const 
    { 
        return ""; 
    };

};

class AWSFacadeProvider
{
public:
    /**
     * Returns the singleton AWSFacadeProvider.
     *
     * By default, a no-op AWSFacadeProvider is returned. This will never return a
     * nullptr AWSFacadeProvider.
     */
    static std::shared_ptr<AWSfacadeI> GetAWSFacadeProvider() noexcept
    {
        std::lock_guard<std::mutex> guard(GetLock());
        return std::shared_ptr<AWSfacadeI>(GetProvider());
    }

    /**
     * Changes the singleton AWSFacadeProvider.
     */
    static void SetAWSFacadeProvider(std::shared_ptr<AWSfacadeI> tp) noexcept
    {
        std::lock_guard<std::mutex> guard(GetLock());
        GetProvider() = tp;
    }

private:
    static std::shared_ptr<AWSfacadeI>& GetProvider() noexcept
    {
        static std::shared_ptr<AWSfacadeI> provider(new NoopAWSfacade);
        return provider;
    }

    static std::mutex& GetLock() noexcept
    {
        static std::mutex lock;
        return lock;
    }
};
/************************************************************************
**
**              Copyright (C) Temenos Software Luxembourg SA 1995-2021.
**                       All Rights Reserved
**
**                   Portfolio Management System
**
*************************************************************************/
#ifndef PgsConnection_H_
#define PgsConnection_H_

#include "dbiconnection.h"

// workaround for postgres defining their OIDs in a private header file
#define BOOLOID 16
#define NAMEOID 19
#define INT8OID 20
#define INT2OID 21
#define INT4OID 23
#define TEXTOID 25
#define NUMERICOID 1700
#define FLOAT4OID 700
#define FLOAT8OID 701
#define ABSTIMEOID 702
#define RELTIMEOID 703
#define VARCHAROID 1043
#define DATEOID 1082
#define TIMEOID 1083
#define TIMETZOID 1266
#define TIMESTAMPOID 1114
#define TIMESTAMPTZOID 1184
#define OIDOID 2278
#define BYTEAOID 17
#define REGPROCOID 24
#define XIDOID 28
#define CIDOID 29
#define REFCURSOROID 1790
#define VOIDOID 2278

class PGS_MsgError : protected DBI_MsgError
{
public:
    PGS_MsgError();
    ~PGS_MsgError();
    PGS_MsgError &          operator=(const PGS_MsgError &) = delete;
    static RET_CODE         getRetCode(int, const char*, const char*);
};

class PgsConnection : public DbiConnection
{
public:
    PgsConnection(const AAAConnectionSpecification& spec, const int& id);
    virtual ~PgsConnection();

    PgsConnection            (const PgsConnection &) = delete;
    PgsConnection & operator=(const PgsConnection &) = delete;

    static AAAConnection*  createConnection(const AAAConnectionSpecification& spec, const int& id);

    virtual bool doConnect();
    virtual bool doDisconnect();
    virtual PTR  getConnectionPtr();
    virtual PTR  getCommandPtr();

    virtual RET_CODE createStatement(const std::string &sql, DBA_ACTION_ENUM action);

    virtual RET_CODE         doAddBatch();
    virtual RET_CODE         doExecuteBatch();

    virtual int              getColumnCount();
    virtual RET_CODE         getColumnName(int, std::string &);
    virtual RET_CODE         getColumnType(int, CTYPE_ENUM &);
    virtual int              getPrecision(int);
    virtual int              getScale(int);
    virtual int              getColumnMaxLength(int);
    virtual int              getColumnDisplaySize(int);

    virtual bool             isBcpAllowed();

    virtual void clearPassword();

    virtual void manageError();
    void         manageError(const char *, const PGresult* = nullptr);

    virtual std::string getDefaultCharset();
    virtual std::string getConnectionCharset();
    virtual bool        isUtf16Allowed();

    bool changePassword(const PasswordEncrypted& password);
    bool changePassword(const  std::string& user, const PasswordEncrypted& password);

    void setDateTimeFormat(DATE_STYLE_ENUM  inDateTimeStyleEn);

    RET_CODE setAppContextProperty(const std::string &propertyName, const std::string &propertyValue);

    virtual RET_CODE doStartRequest();
    virtual RET_CODE doBeginTransaction();
    virtual RET_CODE doEndTransaction(const FLAG_T status);
    virtual RET_CODE getNextResultSet();
    virtual RET_CODE setParameters();
    virtual RET_CODE doSendCommand(DBA_DYNST_ENUM outputSt = NullDynSt);    /* PMSTA-34344 - TEB - 190805 */
    virtual RET_CODE sendRequest(DBI_INT * resultType);
    virtual RET_CODE doReleaseCommand();
    virtual bool     isForceBlockSqlCmd();
    virtual bool     isDbTransactionRequired();
    virtual bool     isDdlGenOnTran();
    virtual RET_CODE prepareReceivedData();
    virtual RET_CODE colBind(int, DATATYPE_ENUM, const std::string&, DBI_PTR, size_t, DBI_INT*, DBI_SMALLINT*, bool dynFldFlag, unsigned char* nullIndicatorDynFld, DbiInOutData*);
    virtual RET_CODE fetch();
            void     applFetchedResult(int, DATATYPE_ENUM, void*, size_t, SMALLINT_T*, unsigned char*);

    virtual RET_CODE copyNullFlagsAndLengthDynSt(DBA_DYNFLD_STP, DBA_DYNST_ENUM);
    virtual RET_CODE processAllResults(DBI_INT       *status,
                                       OBJECT_ENUM    object,
                                       DBA_DYNST_ENUM dynSt,
                                       DBA_DYNFLD_STP record,
                                       DBA_PROC_STP   procedure);

    virtual RET_CODE cancelDbRequest(int level, int mode);

    virtual bool     isReadOnly()
    {
        return false;
    }
    virtual void     setDefaultReadOnly(DBA_PROC_STP, RequestHelper*);

    /* Command RDBMS depends part */
    virtual std::string             endOfCmd();

    virtual RET_CODE setDefaultProperties();
    virtual RET_CODE setConnMaxRows(int);
    
    virtual void enableOutput();
    virtual void disableOutput();

    virtual int getTransState();

    virtual RET_CODE getLastCmdRetCode();
    virtual RET_CODE getCmdRetCode(int msgNo);

    virtual bool isSamePasswordMsg();
    virtual bool isWarningMsgToHide(const DbaErrmsgInfosClass &);

    virtual bool        convParamFromPos(std::string&, std::string::size_type&, int, const std::string&);

    virtual RET_CODE                convertToRetCode(int);

    Oid                             getPostgreSQLDataType(DATATYPE_ENUM);

    CTYPE_ENUM                      getCType(Oid sqlType);

    PGconn                         *m_connection;                     /* pointer on CONNECTION structure, depends of the RDBMS */

protected:

    PGresult                       *m_preparedStatement;
    PGresult                       *m_statement;                      /* pointer on COMMAND structure*/

private:

    ExecStatusType           m_lastSqlCode;

    PGS_MsgError             m_msgErrorHelper;

    bool                     m_bOutputInParam;

    /* Statement values */
    int                      m_rowNumber;
    int                      m_rowPos;
    std::map<int, int>       m_maxSizeMap;

    std::vector<std::string> m_refCursorVector;

    std::string              m_currDbNameOption;

    MemoryPool               m_queryMp;
};

#endif

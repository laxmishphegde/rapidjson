/* SCID @(#)tstboot.c	1.14 (SimCorp) 99/07/06 14:31:32 */

/************************************************************************
*
*   project     SCecon
*
*   filename    boottest.c
*
*   this program tests the routines in the boot module of SCecon
*
************************************************************************/

/*** includes ***********************************************************/
#include <string.h>
#include <scalloc.h>
#include <str2conv.h>
#include <bootstrp.h>
#include <ioconv.h>
#include <tscalio.h>
#include <bondio.h>


/*** the main() routine *************************************************/

INTI boottest(char* txa, FILE* in, FILE* out)
{
    char       txpl[120];
    INTI       i, nx ;
    BOOLE      err, ok ;
    INTI       n1, n2, np, ns, diff, dif1, 
               nholi, nd, n, nshock ;
    FL64       cfac, fexp, d1, acc, dacc, delta, dum ;
    PLANARRAY  dtmp, disc ;
    FL64ARRAY  pvfl, pvFL, madj, shock, spread, prices, expshock ;
    FL64MATRIX weight ;
    PLANARRAY  corr, expplan ;
    FILLTYPE   ftype ;
    YYYYMMDD   ymd ;
    DATESTR    today, dzero ;
    DATEARRAY  settle, holidays;
    BSECARRAY  secs1 ;
    CALCONV    cal ;
    PMTFREQ    freq ;
    int        i1, i2 ;
    HOLI_STR   holi ;
    DISCFAC    df ;
    VOL_STR    vols, volf ;
    DFPARMS    what, dfp ;
    PERIODARRAY period ;
    DELTASET    ds ;

    /* warning avoidance */
    memset(&ds, 0, sizeof(ds));

    acc   = 0.00001 ;
    dacc  = 0.000001 ;
    dzero = Cldr_YMD2Datestr((YYYYMMDD) 0) ;

    diff = -1 ;

   if (!strcmp("Boot_BSEC2DF()", txa))
    {
        fprintf(out,"?; testing %s\n", txa) ;
        today = Read_DATESTR(in, out, "   Today             ");

        holi = Read_HOLI_STR(in, out);

        ftype = Read_FILLTYPE(in, out, "  Filltype ");

        dfp = Read_DFPARMS(in, out);

        n = Read_INTI(in, out, "  No. of securities   ");
        secs1   = Alloc_BSECARRAY(n) ;
        prices  = Alloc_FL64ARRAY(n) ;
        spread  = Alloc_FL64ARRAY(n) ;
        madj    = Alloc_FL64ARRAY(n) ;
        settle  = Alloc_DATEARRAY(n) ;
        for (i = 0 ; i < n ; i++)
        {
            fprintf(out, "SECURITY              %8d\n", (int) (i + 1)) ;
            secs1[i] = Read_BSEC(in, out, &prices[i], &spread[i],
                                 &madj[i], &settle[i]) ;
        }

        pvfl = pvFL = Read_FL64ARRAY(in, &nx) ;
        fprintf(out, "   Float PV's\n") ;
        Write_FL64ARRAY(out, pvFL, nx) ;
        if (nx != n)
            pvfl = NULL ;

        IOUtil_ParseLine(in, out);

        err  = Boot_BSEC2DF(&today, secs1, prices, spread, madj, pvfl,
                            settle, n, &holi, ftype, 0, n - 1, &dfp, &df);
        disc = df.disc ;

        diff = 0 ;
        fprintf(out, "\n") ;

        nd = Read_INTI(in, out, "  Exp no. of discfactors   ");
        if (err != True)
        {
            fprintf(out,"1; Something wrong - could not calibrate\n") ;
            diff = 1 ;
        }
        else if (GetPlanFill(disc) == nd)
        {
            fprintf(out,"   Exp.date  Exp.disc  Comp.date Comp.disc\n") ;

            for (i = 0 ; i < nd ; i++)
            {
                fscanf(in, "%ld %lf", &ymd, &d1) ;
                dif1 = (fabs(d1 - disc[0].f64[i]) > dacc) ;
                dif1 = dif1 || 
                       (Cldr_Datestr2YMD(&disc[0].day[i]) - ymd) != 0;
                fprintf(out, "%d; %ld %1.12lf %ld %1.12lf\n",
                        (int) dif1, ymd, d1, 
                        Cldr_Datestr2YMD(&disc[0].day[i]), disc[0].f64[i]) ;
                diff = diff || dif1 ;
            }
        }
        else
        {
            diff = 1 ;
            fprintf(out, "1; You expected %d entries, we found %d\n",
                    nd, GetPlanFill(disc)) ;

            fprintf(out, "Your expectation\n") ;
            for (i = 0 ; i < nd ; i++)
            {
                fscanf(in, "%ld %lf", &ymd, &d1) ;
                fprintf(out, "    %ld %1.8lf\n",
                        ymd, d1) ;
            }
            fprintf(out, "\nOur results\n") ;
            for (i = 0 ; i < GetPlanFill(disc) ; i++)
                fprintf(out, "    %ld %1.8lf\n",
                        Cldr_Datestr2YMD(&disc[0].day[i]), disc[0].f64[i]) ;
        }

        Free_PLANARRAY(disc, 1) ;
        Free_DATEARRAY(holi.holidays) ;
        Free_DATEARRAY(settle) ;

        Free_FL64ARRAY(madj) ;
        Free_FL64ARRAY(pvFL) ;
        Free_FL64ARRAY(prices) ;
        Free_FL64ARRAY(spread) ;
        Free_BSECARRAY(secs1) ;
    }

    else if (!strcmp("Boot_DeltaPrep()", txa))
    {
        fprintf(out,"?; testing %s\n", txa) ;
        
        today = Read_DATESTR(in, out, "   Today             ");
        holi = Read_HOLI_STR(in, out);
        ftype = Read_FILLTYPE(in, out, "  Filltype ");
        dfp = Read_DFPARMS(in, out);
        shock = Read_FL64ARRAY(in, &nshock) ;

        n = Read_INTI(in, out, "  No. of securities   ");
        secs1   = Alloc_BSECARRAY(n) ;
        prices  = Alloc_FL64ARRAY(n) ;
        spread  = Alloc_FL64ARRAY(n) ;
        madj    = Alloc_FL64ARRAY(n) ;
        settle  = Alloc_DATEARRAY(n) ;

        for (i = 0 ; i < n ; i++)
        {
            fprintf(out, "SECURITY              %8d\n", (int) (i + 1)) ;
            secs1[i] = Read_BSEC(in, out, &prices[i], &spread[i],
                                 &madj[i], &settle[i]) ;
        }

        pvfl = pvFL = Read_FL64ARRAY(in, &nx) ;
        fprintf(out, "   Float PV's\n") ;
        Write_FL64ARRAY(out, pvFL, nx) ;
        if (nx != n)
            pvfl = NULL ;
                         
        diff = 0 ;
        fprintf(out, "\n") ;

        ok = Boot_BSEC2DF(&today, secs1, prices, spread, madj, pvfl,
                          settle, n, &holi, ftype, 0, n - 1, &dfp, &df);

        if (ok == False)
        {
            fprintf(out,"1; Something wrong - could not calibrate\n") ;
            diff = 1 ;
        }
        else
            ds = Boot_DeltaPrep(&today, secs1, prices, spread, madj, NULL,
                                 settle, shock, n, &holi, ftype, &df, &ok);
        if (ok == True)
        {
            n = Read_INTI(in, out, "  No. of exp DF's   ");
            for (i = 0; i < n; i++)
            {
                expplan = Read_PLANARRAY(in) ;
                dif1 = Write_PlanDiff(expplan, &ds.shock[i], out) ;
                diff = diff || dif1 ;
                Free_PLANARRAY(expplan, 1) ;
            }
        }
        else
            diff = 1 ;

        fprintf(out, "%d; All OK\n", diff) ;

        IOUtil_ParseLine(in, out);

        Free_DISCFAC(&df) ;
        Free_DELTASET(&ds) ;
        Free_HOLI_STR(&holi) ;
        Free_DATEARRAY(settle) ;
        Free_FL64ARRAY(shock) ;
        Free_FL64ARRAY(madj) ;
        Free_FL64ARRAY(prices) ;
        Free_FL64ARRAY(pvFL) ;
        Free_FL64ARRAY(spread) ;
        Free_BSECARRAY(secs1) ;
    }

    else if (!strcmp("Boot_BH2MarginAdj()", txa))
    {
        fscanf(in, "%ld %d %d %s", &ymd, &i2, &i1, txpl) ;
        nholi = (INTI) i2 ;
        n     = (INTI) i1 ;

        secs1 = Alloc_BSECARRAY(n) ;
        prices  = Alloc_FL64ARRAY(n) ;
        spread  = Alloc_FL64ARRAY(n) ;
        settle  = Alloc_DATEARRAY(n) ;

        today = Cldr_YMD2Datestr(ymd) ;

        fprintf(out,"?; testing %s\n", txa) ;
        fprintf(out,"   today is           %8ld\n", ymd) ;

        holidays = Alloc_DATEARRAY(nholi) ;

        fprintf(out,"   the holidays are...\n") ;
        fprintf(out,"   holiday\n") ;
        for (i = 0 ; i < nholi ; i++)
        {
            fscanf(in, "%ld", &ymd) ;
            holidays[i] = Cldr_YMD2Datestr(ymd) ;
            fprintf(out,"   %8ld\n", ymd) ;
        }

        fprintf(out, "\n") ;

        for (i = 0 ; i < n ; i++)
        {
            fprintf(out, "SECURITY              %8d\n", (int) (i + 1)) ;
            secs1[i] = Read_BSEC(in, out, &prices[i], &spread[i],
                                 &dum, &settle[i]) ;
        }

        holi.nholi    = nholi ;
        holi.holidays = holidays ;

        vols = Set_VOL_STR(NULL, ACTACT, FORWFORW, LINEAR_FLAT_END);
        vols.vol = Read_PLANARRAY(in) ;
        fprintf(out,"   Spot Vols...\n") ;
        Write_PLANARRAY(out, vols.vol) ;

        volf = Set_VOL_STR(NULL, ACTACT, FORWFORW, LINEAR_FLAT_END);
        volf.vol = Read_PLANARRAY(in) ;
        fprintf(out,"   Forward Vols...\n") ;
        Write_PLANARRAY(out, volf.vol) ;

        corr     = Read_PLANARRAY(in) ;
        fprintf(out,"   Correlations...\n") ;
        Write_PLANARRAY(out, corr) ;

        madj = Boot_BH2MarginAdj(&today, secs1, settle, n, &vols, &volf,
                                 corr, &holi) ;

        diff = 0 ;
        fprintf(out, "\n    Exp.Adj    Calc.Adj\n") ;

        for (i = 0 ; i < n; i++)
        {
            fscanf(in, "%lf", &fexp) ;

            diff = diff || (fabs(fexp - madj[i]) > acc) ;
            fprintf(out,"%d; %lf %lf\n", fabs(fexp - madj[i]) > acc,
                    fexp, madj[i]) ;
        }

        fprintf(out,"   %s\n\n", txpl) ;

        Free_FL64ARRAY(madj) ;
        Free_FL64ARRAY(prices) ;
        Free_FL64ARRAY(spread) ;
        Free_DATEARRAY(holidays) ;
        Free_DATEARRAY(settle) ;
        Free_BSECARRAY(secs1) ;
        Free_PLANARRAY(vols.vol, 1) ;
        Free_PLANARRAY(volf.vol, 1) ;
        Free_PLANARRAY(corr, 1) ;
    }

    else if (!strcmp("Boot_LOG2MarginAdj()", txa))
    {
        fscanf(in, "%ld %d %s", &ymd, &i1, txpl) ;
        n = (INTI) i1 ;

        secs1  = Alloc_BSECARRAY(n) ;
        prices = Alloc_FL64ARRAY(n) ;
        spread = Alloc_FL64ARRAY(n) ;
        settle = Alloc_DATEARRAY(n) ;

        today = Cldr_YMD2Datestr(ymd) ;

        fprintf(out,"?; testing %s\n", txa) ;
        fprintf(out,"   today is           %8ld\n", ymd) ;

        for (i = 0 ; i < n ; i++)
        {
            fprintf(out, "SECURITY              %8d\n", (int) (i + 1)) ;
            secs1[i] = Read_BSEC(in, out, &prices[i], &spread[i],
                                 &dum, &settle[i]) ;
        }

        df = Read_DISCFAC(in, out) ;

        volf = Set_VOL_STR(NULL, ACTACT, FORWFORW, LINEAR_FLAT_END);
        volf.vol = Read_PLANARRAY(in) ;
        fprintf(out,"   Forward Vols...\n") ;
        Write_PLANARRAY(out, volf.vol) ;

        fscanf(in, "%lf", &cfac) ;
        fprintf(out,"   CorrFac            %8lf\n", cfac) ;

        holi = Set_HOLI_STR(NO_BUSADJUST, 0, NULL) ;

        madj = Boot_LOG2MarginAdj(&today, secs1, settle, n, &df, &volf, 
                                  cfac, &holi) ;

        diff = 0 ;
        fprintf(out, "\n    Exp.Adj    Calc.Adj\n") ;

        for (i = 0 ; i < n; i++)
        {
            fscanf(in, "%lf", &fexp) ;

            diff = diff || (fabs(fexp - madj[i]) > acc) ;
            fprintf(out,"%d; %lf %lf\n", fabs(fexp - madj[i]) > acc,
                    fexp, madj[i]) ;
        }
        
        fprintf(out,"   %s\n\n", txpl) ;

        Free_FL64ARRAY(madj) ;
        Free_FL64ARRAY(prices) ;
        Free_FL64ARRAY(spread) ;
        Free_DATEARRAY(holi.holidays) ;
        Free_DATEARRAY(settle) ;
        Free_BSECARRAY(secs1) ;
        Free_PLANARRAY(volf.vol, 1) ;
        Free_PLANARRAY(df.disc, 1) ;
    }

    else if (!strcmp("Boot_BlendDF()", txa))
    {
        fprintf(out,"   testing %s\n", txa) ;

        fscanf(in, "%d", &i1) ;
        nd = (INTI) i1 ;
        disc = Alloc_PLAN(nd) ;

        for (i = 0; i < nd; i++)
        {
            dtmp = Read_PLANARRAY(in) ;
            fprintf(out, "   DF #%d\n", i) ;
            Write_PLANARRAY(out, dtmp) ;
            disc[i].day    = dtmp->day ;
            disc[i].f64    = dtmp->f64 ;
            disc[i].filled = GetPlanFill(dtmp) ;
            Free_PLAN(dtmp) ;
        }

        dfp = Read_DFPARMS(in, out) ;

        fscanf(in, "%d", &i1) ;
        np = (INTI) i1 ;
        period = Alloc_PERIODARRAY(np) ;
        fprintf(out, "   Periods:\n") ;
        for (i = 0; i < np; i++)
        {
            period[i] = Read_PERIOD(in) ;
            Write_PERIOD(out, "", &period[i]) ;
        }

        weight = Read_FL64MATRIX(in, out, &n1, &n2) ;
        settle = Read_DATEARRAY(in, out, &ns) ;
        what   = Read_DFPARMS(in, out) ;
        dtmp   = Read_PLANARRAY(in) ;

        df = Boot_BlendDF(disc, nd, &dfp, period, np, weight, settle, ns,
                           &what) ;
        diff = 0 ;

        if (GetPlanFill(df.disc) != GetPlanFill(dtmp))
        {
            diff = 1 ;
            fprintf(out, "1; Count mismatch\n") ;
        }

        for (i = 0; i < GetPlanFill(dtmp) ; i++)
        {
            diff = diff|| fabs(dtmp->f64[i] - df.disc->f64[i]) > 0.00001 ||
                   Cldr_Datestr2YMD(&dtmp->day[i]) !=
                     Cldr_Datestr2YMD(&df.disc->day[i]) ;
            fprintf(out, "%d; %ld %lf %ld %lf\n",
                    diff, Cldr_Datestr2YMD(&dtmp->day[i]), dtmp->f64[i],
                    Cldr_Datestr2YMD(&df.disc->day[i]), df.disc->f64[i]) ;
        }

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_FL64MATRIX(weight) ;
        Free_DATEARRAY(settle) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_PLANARRAY(disc, nd) ;
        Free_PLANARRAY(dtmp, 1) ;
        Free_PERIODARRAY(period) ;
    }

    else if (!strcmp("Boot_GenrEquiShock()", txa))
    {
        fprintf(out,"?; testing %s\n", txa) ;
        today = Read_DATESTR(in, out, "   Today             ");

        cal = Read_CALCONV(in, out, "  Calendar ");
        freq = Read_PMTFREQ(in, out, "  Frequency ");
        delta = Read_FL64(in, out, "  Shock freq ");

        n = Read_INTI(in, out, "  No. of securities   ");
        secs1   = Alloc_BSECARRAY(n) ;
        prices  = Alloc_FL64ARRAY(n) ;
        spread  = Alloc_FL64ARRAY(n) ;
        madj    = Alloc_FL64ARRAY(n) ;
        settle  = Alloc_DATEARRAY(n) ;
        for (i = 0 ; i < n ; i++)
        {
            fprintf(out, "SECURITY              %8d\n", (int) (i + 1)) ;
            secs1[i] = Read_BSEC(in, out, &prices[i], &spread[i],
                                 &madj[i], &settle[i]) ;
        }

        Free_FL64ARRAY(spread);
        Free_FL64ARRAY(madj);
        Free_DATEARRAY(settle);

        IOUtil_ParseLine(in, out);

        shock = Boot_GenrEquiShock(secs1, n, prices, cal, freq, delta, 
                                     &today, &ok);

        expshock = Read_FL64ARRAY(in, &nd);
        diff = WriteFL64ARRAYDiff(True, expshock, nd, ok, shock, n,
          out, 0.0001);

        Free_FL64ARRAY(expshock) ;
        Free_FL64ARRAY(shock) ;
        Free_FL64ARRAY(prices) ;
        Free_BSECARRAY(secs1) ;
    }


    return diff ;
}


INTI maxsmoothtest(char* txa, FILE* in, FILE* out)
{
    DATESTR     today;
    DATEARRAY   settl;
    BSECARRAY fixpa;
    FL64ARRAY   price, spr, madj, pvfl, pvFL;
    INTI        nfixp, nx;
    HOLI_STR    holi;
    DFPARMS     dfp;
    DISCFAC     df/*, df1*/;
    CFLW_STR*   cflw;
    PLANARRAY   dtmp;
    INTI        diff, i;
    BOOLE       ok;
    FL64        smooth, p/*, p1*/, priceX, critfunc;

    diff = -1;

    if (!strcmp(txa, "MaxSmooth_BSEC2DF()"))
    {
      fprintf(out, "  testing %s\n\n", txa);

      today  = Read_DATESTR(in, out, "Today") ;
      smooth = Read_FL64(in, out, "Smoothness") ;
      holi   = Read_HOLI_STR(in, out);
      dfp    = Read_DFPARMS(in, out);

      nfixp = Read_INTI(in, out, "No. of Instruments");
      fixpa = Alloc_BSECARRAY(nfixp);
      price = Alloc_FL64ARRAY(nfixp);
      spr   = Alloc_FL64ARRAY(nfixp);
      madj  = Alloc_FL64ARRAY(nfixp);
      settl = Alloc_DATEARRAY(nfixp);
      for (i = 0; i < nfixp; i++)
        fixpa[i] = Read_BSEC(in, out, &price[i], &spr[i],
                             &madj[i], &settl[i]);

      pvfl = pvFL = Read_FL64ARRAY(in, &nx) ;
      fprintf(out, "   Float PV's\n") ;
      Write_FL64ARRAY(out, pvFL, nx) ;
      if (nx != nfixp)
          pvfl = NULL ;

      IOUtil_ParseLine(in, out);
      dtmp   = Read_PLANARRAY(in) ;

      ok = MaxSmooth_BSEC2DF(&today, price, fixpa, smooth, spr,
                             madj, pvfl, settl, nfixp, &holi,
                             &dfp, &df, &critfunc);
      fprintf(out, "*Criterion function: %lf\n", critfunc);
      diff = Write_PlanDiff(dtmp, df.disc, out);

      for (i = 0; i < nfixp; i++)
        if (fixpa[i].type == BOND || fixpa[i].type == BONDREPO)
          Free_FIXPAY(&fixpa[i].fixp);
        else if (fixpa[i].type == SWAPGENR)
          Free_SWAPFIX(&fixpa[i].sfix);
      Free_BSECARRAY(fixpa);
      Free_FL64ARRAY(price);
      Free_FL64ARRAY(spr);
      Free_FL64ARRAY(madj);
      Free_DATEARRAY(settl);
      Free_FL64ARRAY(pvFL) ;
      Free_HOLI_STR(&holi);
      Free_PLANARRAY(dtmp, 1);
      Free_DISCFAC(&df);
    }
    else if (!strcmp(txa, "MaxSmooth_BSEC2Price()"))
    {
      fprintf(out, "  testing %s\n\n", txa);

      today = Read_DATESTR(in, out, "Today");
      holi = Read_HOLI_STR(in, out);
      df = Read_DISCFAC(in, out);

      nfixp = Read_INTI(in, out, "No. Bonds");
      fixpa = Alloc_BSECARRAY(nfixp);
      price = Alloc_FL64ARRAY(nfixp);
      spr   = Alloc_FL64ARRAY(nfixp);
      madj  = Alloc_FL64ARRAY(nfixp);
      settl = Alloc_DATEARRAY(nfixp);
      for (i = 0; i < nfixp; i++)
        fixpa[i] = Read_BSEC(in, out, &price[i], &spr[i],
                             &madj[i], &settl[i]);

      pvfl = pvFL = Read_FL64ARRAY(in, &nx) ;
      fprintf(out, "   Float PV's\n") ;
      Write_FL64ARRAY(out, pvFL, nx) ;
      if (nx != nfixp)
          pvfl = NULL ;

      IOUtil_ParseLine(in, out);

      fprintf(out, "Sec.No.   Price  Diff\n");
      for (i = 0; i < nfixp; i++)
      {
        priceX = GetArrayEl(pvfl, i, nfixp, 100.0) ;
        cflw = BSEC_GenrCflw(&fixpa[i], price[i], priceX, &holi, 
                             &settl[i]);
        p = BSEC_DF2PriceDiff(&settl[i], &fixpa[i], cflw, spr[i], 
                              madj[i], priceX, &df, &holi, price[i]);
        fprintf(out, "%d   %lf   %lf\n", i, price[i], p);

        Free_CFLWARRAY(cflw, 1);
      }

      diff = 0;
  
      Free_BSECARRAY(fixpa);
      Free_FL64ARRAY(price);
      Free_FL64ARRAY(spr);
      Free_FL64ARRAY(madj);
      Free_DATEARRAY(settl);
      Free_FL64ARRAY(pvFL) ;
      Free_HOLI_STR(&holi);
      Free_DISCFAC(&df);

    }

    fflush(out);

    return diff;
}


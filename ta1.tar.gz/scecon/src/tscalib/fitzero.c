/* SCID @(#)fitzero.c	1.30 (SimCorp) 99/10/27 15:26:17 */

/***********************************************************************
*
*   project     SCecon
*
*   file name   fitzero.c
*
*   general     This file contains standard routines for zerocoupon
*               estimation.
*
************************************************************************/

/* includes ************************************************************/
#include <fitzero.h>
#include <f2proto.h>
#include <f2c.h>



/* defines  ************************************************************/

#define RAN_INDEX 97
#define ZERO_NO_SOLUTION 1000.0
#define ZERO_MINDUR      0.000001
#define GCV_EPS          0.0001
#define GCV_MAXIT        100
#define GCV_GUESS        10.0
#define GCV_DAMP         1.0
#define GCV_ACC          0.000000001
#define GCV_EPS          0.0001
#define GCV_LOWER        0.0001
#define GCV_UPPER        1000.0  
#define GCV_UPPER_SIZE   1.0E10  
#define GCV_UPPER_VOL    100  
#define ROUND_NOISE      1.0e-10
#define MEMORY           800000



/*,,SOH,,
************************************************************************
*
*                Fit_Cflw2TS()
*
*    interface   #include <fitzero.h>
*                FITPARMS Fit_Cflw2TS(ZEROPARMS      *zerop,
*                                     CRITERIONFUNC  *cfunc,
*                                     INTI           nsec,
*                                     PMTARRAY       pmt,
*                                     FL64ARRAY      prices,
*                                     FL64ARRAY      spread,
*                                     FL64ARRAY      bidask,
*                                     TSOVARRAY      tlambda,
*                                     ITERCTRL       *ictrl) ;
*
*    general     The function estimates the term structure of interest
*                rates for a given specification of a term structure
*                model.
*
*                The estimation of the term structure is performed
*                using non-linear optimization techniques.
*                The objective function is specified using the cfunc
*                argument but the general idea is to minimize price
*                deviations, ie. market price minus model price.
*                This objective can be weighted or unweighted. 
*
*                The securities that are relevant in this estimation
*                are fixed coupon and option-free bonds, ie. standard
*                straight bonds, typically all from the same market
*                segment - treasury etc. In order to handle bonds that
*                trade with some spread, a security specific spread
*                can be given for each of the bonds.
*
*                When estimating the model coefficients must be bounded.
*                The bounds must be supplied by the user. This can be
*                difficult, but under the type ZEROMODEL some default
*                values are provided.
*
*                In addition, for most models a starting guess must be 
*                provided in coefs at entry. Typically this guess is 
*                the result of a previous estimation, e.g. yesterdays 
*                result. However, when you start estimating, a coldstart 
*                toggle can be set by specifying the docold parameter as 
*                True. When doing so, the best coefficients from a 
*                randomized optimization will be used. However, setting 
*                docold to True, the algorithm will run considerably 
*                slower.
*
*                The output from the estimation will be filled in the
*                model coefficients in coefs.
*                These coefficients can be used to generate the term
*                structure rates. The rates calculated directly from
*                the models are all continuously compounded rates, so
*                use the routine Zero_GenrTS() to get suitably quoted
*                term structure rates.
*
*                Please note that since our implementation of the models
*                are handling some numerical issues, the coefficients
*                cannot always be interpreted as the theoretical ones,
*                so it is highly recommended to use Zero_GenrTS()
*
*                Sometimes, if data are inconsistent or extreme in some
*                way, the optimisation fails. In this case the return
*                value is False. If this happens review the input data
*                carefully.
*
*                The function works on terms rather than dates. This
*                is only for convenience. If data are held in date
*                format (ie. the splinedates and the payments) then
*                the only thing needed is to translate these using
*                Cldr_TermBetweenDates() prior to calling this function
*                in order to use terms.
*
*                Finally note that this function uses static variables
*                for communicating with the optimisation proces.
*
*    input       ZEROPARMS *zerop     The model setup. 
*                                     The zerop->parms holds the initial 
*                                     guess on the parameter values. A 
*                                     sensible choice could be the estimated
*                                     parameter values from a recent fit.
*                                     If the quality of the guess is poor
*                                     the cold start facility is worth 
*                                     considering.
*
*                                     For each coefficient, the lower
*                                     bound must be less than or equal
*                                     to the upper bound. zerop->model 
*                                     cannot be BOOTSTRAP
* 
*                CRITERIONFUNC *cfunc Used to define the criterion
*                                     function in the optimization.
*
*                INTI      nsec       Number of securities used in the
*                                     estimation. Positive number.
*
*                PMTARRAY  pmt        The cash flows of the securities.
*                                     Entries number from 0 to nsec-1
*                                     are used in the estimation.
*
*                FL64ARRAY prices     Array with nsec entries holding
*                                     dirty prices of the bonds in
*                                     pmt. If both ask and bid prices
*                                     are used this array should contain
*                                     ask prices. In this case the bid 
*                                     price should be supplied as a spread 
*                                     using the bidask argument.
*
*                FL64ARRAY spread     Array with nsec entries holding
*                                     the normal spread against the
*                                     term structure of the bonds.
*                                     Quoted as continuous rates in
*                                     fractions, ie. 0.004 corresponds
*                                     to 0.4% continuously compounded
*                                     spread.
*
*                FL64ARRAY bidask     Array with nsec entries holding
*                                     the bid-ask spread on the bond
*                                     prices
*
*                TSOVARRAY tlambda    Array containing information about
*                                     the parameter controlling the trade
*                                     off between smoothness and goodness
*                                     of fit. Large values favour smoothness.
*                                     This struct is only used if the trade 
*                                     off is time depended otherwise is must 
*                                     be set to NULL.
*
*                ITERCTRL  *ictrl     Iteration control.
*                                     Only uses acc, maxiter, shock
*                                     The meaning of shock is different
*                                     than according to the definition
*                                     in ITERCTRL. shock is the
*                                     initial step-size used in the 
*                                     algorithm.
*
*
*    output
*
*    returns     FITPARMS struct containing fitted parameter values and 
*                objective function value. Parms in the FITPARMS struct is 
*                allocated as Alloc_FL64ARRAY(zerop->ncoef). 
*
*    diagnostics
*
*    see also    Zero_Model2Price()
*                Zero_GenrTS()
*                Zero_GenrDF()
*
************************************************************************
,,EOH,,*/


FITPARMS Fit_Cflw2TS(ZEROPARMS*      zerop,
                     CRITERIONFUNC*  cfunc,
                     INTI            nsec,
                     PMTARRAY        pmt,
                     FL64ARRAY       prices,
                     FL64ARRAY       spread,
                     FL64ARRAY       bidask,
                     TSOVARRAY       tlambda,
                     ITERCTRL*       ictrl)
{
    FL64       a, dum, d, eps, idum, up, low, *ppx ;
    FL64ARRAY  *px, f, w, l1constr, rhside ;
    FL64MATRIX x ;
    INTI       i, j, k, ncons, nsample ;
    UN32       ix1, ix2, ix3 ;
    FL32ARRAY  r ;
    time_t     t ;
    integer    icontr, cc ;
    ZEROFITDATA* sDATA ;
    VOIDPTR    data ;
    FITPARMS   tsfit ;

    sDATA = (ZEROFITDATA*) SCecon_calloc(1, sizeof(ZEROFITDATA), True,
      "ZEROFITDATA");

    /* NOTE: Deliberate cast from ZEROFITDATA to VOIDPTR
             This casting is necessary in order to pass instrument data
             generally through the Harwell optimiser. 
             The only general type is VOIDPTR. */

    data = (VOIDPTR) sDATA;

    sDATA->sPMTS       = pmt ;
    sDATA->sFULLPRICE  = prices ;
    sDATA->sNORMALOAS  = spread ;
    sDATA->sTSDUR      = Alloc_FL64ARRAY(nsec) ;
    sDATA->sBIDASK     = bidask ;
    sDATA->sCFUNC      = cfunc ;
    sDATA->sNSEC       = nsec ;
    sDATA->sStepLambda = tlambda ;
    sDATA->sPARMS      = zerop ;

    /* Allocate */
    r = Alloc_FL32ARRAY(RAN_INDEX + 1) ;

    /* Number of constraints - and estimation samples */
    ncons   = 2 * zerop->ncoef ;
    if (cfunc->docold == True)
    {
      nsample = 10 ;
      /* Initialize random number generator */
      idum = (FL64) time(&t) ;
      dum  = Math_Ran1(&idum, &ix1, &ix2, &ix3, r, True, RAN_INDEX) ;
    }
    else
      nsample = 1 ;

    /* Allocate */
    f = Alloc_FL64ARRAY(nsample) ;
    x = Alloc_FL64MATRIX(nsample, zerop->ncoef) ;
    w = Alloc_FL64ARRAY(MEMORY) ;
    l1constr = Alloc_FL64ARRAY(zerop->ncoef * ncons + 1) ;
    rhside   = Alloc_FL64ARRAY(2 * zerop->ncoef + 1) ;

    /* Generate a sample of guesses - the first one being the initial guess
       Make sure all are feasible */
    for (i = 0 ; i < zerop->ncoef ; i++)
      x[0][i] = zerop->parms[i] ;

    for (i = 1 ; i < nsample ; i++)
    {
        for (j = 0 ; j < zerop->ncoef ; j++)
        {
            up  = zerop->bounds[j][1] ;
            low = zerop->bounds[j][0] ;
            dum = Math_Ran1(&idum, &ix1, &ix2, &ix3, r, False, RAN_INDEX) ;
            x[i][j] =  (up - low) * dum + low ; 
        }
    }

    /* Set constraints */
    k = 0 ;
    for (i = 0 ; i < zerop->ncoef ; i++)
    {
        j               = i * ncons + 2 * i ;
        l1constr[j]     = 1.0 ;
        l1constr[j + 1] = -1.0 ;

        /* This cumbersome code has been introduced to avoid UAE's when
           compiling/runnig DLL's with MSC 6.0 - we do not know why !? */
        a = -zerop->bounds[i][0] ;
        rhside[k++] = a ;
        a = zerop->bounds[i][1] ;
        rhside[k++] = a ;
    }

    /* Fill in weight factors */
    if(cfunc->noweights == 0)
    {
      for (i = 0 ; i < nsec ; i++)
        sDATA->sTSDUR[i] = 1.0 ;
    }
    else
    {
      for (i = 0 ; i < nsec ; i++)
        sDATA->sTSDUR[i] = ((fabs(cfunc->weights[i]) > ZERO_MINDUR)? 
                   cfunc->weights[i] : ZERO_MINDUR) ;
    }

    /* Loop over samples */
    for (i = 0 ; i < nsample ; i++)
    {
        /* Set iteration controls: */
        cc     = ictrl->maxiter < 1 ? 500 : ictrl->maxiter;
        d      = ictrl->shock < 0.0 ? 0.1 : ictrl->shock;
        eps    = ictrl->acc < 0.0 ? 0.00001 : ictrl->acc;
        icontr = 1 ;  /* Must have this value */

        /* Optimize */
        px  = x ;
        ppx = px[i] ;
  
        if (sDATA->sCFUNC->smparms.smcrit != NO_SMOOTH)
          /* We need an extra argument to hold information regarding 
             the smoothness */
          nsec++ ; 
        /* Note the cast to Harwell types */
        mi0cl1(Zero_abs_Prices, (integer) zerop->ncoef, (integer) nsec,
               (integer) ncons, (integer) 0, rhside, l1constr,
               ppx, &d, &eps, &cc, w, MEMORY, &icontr, data) ;
        if (sDATA->sCFUNC->smparms.smcrit != NO_SMOOTH)
          /* Back to original setting */
          nsec-- ;

        /* Compute objective */
        if (icontr < 0 || icontr > 2)
            f[i] = ZERO_NO_SOLUTION ;

        else
        {
            f[i] = 0.0 ;
            for (j = 0 ; j < nsec ; j++)
                f[i] += fabs(w[j]) ;
        }
    }

    /* Pick out best solution */
    tsfit.nparms = zerop->ncoef ;
    tsfit.parms  = Alloc_FL64ARRAY(zerop->ncoef) ;
    tsfit.obj    = f[0] ;
    for (j = 0, i = 1 ; i < nsample ; i++)
    {
        if (f[i] < tsfit.obj)
        {
            tsfit.obj = f[i] ;
            j = i ;
        }
    }

    for (i = 0 ; i < zerop->ncoef ; i++)
      tsfit.parms[i] = x[j][i] ;

    /* Free and return */
    Free_FL64ARRAY(f) ;
    Free_FL64MATRIX(x) ;
    Free_FL64ARRAY(w) ;
    Free_FL64ARRAY(l1constr) ;
    Free_FL64ARRAY(rhside) ;
    Free_FL64ARRAY(sDATA->sTSDUR) ;
    Free_FL32ARRAY(r) ;
    SCecon_free((VOIDPTR) sDATA);

    return tsfit ;
}


/*,,SOH,,
************************************************************************
*
*                Fit_BSEC2DF()
*
*    interface   #include <fitzero.h>
*                BOOLE Fit_BSEC2DF(DATESTR        *start,
*                                  ZEROPARMS      *zerop,
*                                  CRITERIONFUNC  *cfun,
*                                  INTI           nsec,
*                                  BSECARRAY      secs,
*                                  BOOLE          use_ba,
*                                  FL64ARRAY      aprices,
*                                  FL64ARRAY      bprices,
*                                  FL64ARRAY      spread,
*                                  FL64ARRAY      madj,
*                                  FL64ARRAY      pricesX,
*                                  DATEARRAY      settle,
*                                  HOLI_STR       *holi,
*                                  DATEARRAY      gridpts,
*                                  INTI           ngridpts,
*                                  ITERCTRL       *ictrl,
*                                  DFPARMS        *dfp,
*                                  DISCFAC        *df,
*                                  FITPARMS       *tsfit) ;
*
*    general     The function estimates the discount structure using
*                either non-linear estimation or bootstrapping.
*
*                The details of the functionality are described in
*                Fit_Cflw2TS() or Boot_BSEC2DF().
*
*                In contrast to Fit_Cflw2TS() this function takes
*                bond data as inputs rather than cash flows.
*
*                Finally note that this function uses static variables
*                for communicating with the optimisation proces, when
*                Non-linear estimation techniques are used.
*
*                Reference: MGH-99-06 "Aspects of Yield Curve Estimation
*                and Modelling"
*
*    input       DATESTR   *start     Date of analysis.
*
*                ZEROPARMS *zerop     The model setup. When zerop->model
*                                     is BOOTSTRAP the remaining entries 
*                                     need not be filled.
*
*                                     The zerop->parms holds the initial 
*                                     guess on the parameter values. A 
*                                     sensible choice could be the estimated
*                                     parameter values from a recent fit.
*                                     If the quality of the guess is poor
*                                     the cold start facility is worth 
*                                     considering.
*
*                                     For each coefficient, the lower
*                                     bound must be less than or equal
*                                     to the upper bound.
*
*                CRITERIONFUNC *cfun  Used to define the criterion
*                                     function in the optimization.
*
*                INTI      nsec       Number of securities used in the
*                                     estimation. Positive number.
*
*                BSECARRAY secs       The data describing the securities
*                                     When model is BOOTSTRAP any
*                                     security is possible. Otherwise
*                                     only bonds are used.
*                                     Dimension [nsec]
*
*                BOOLE     use_ba     If True both aprices and bprices
*                                     are used. Otherwise only aprices
*                                     is considered. If model is
*                                     BOOTSTRAP use_ba must be False.    
*  
*                FL64ARRAY aprices    Array with nsec entries holding
*                                     clean prices of the bonds in pmt.
*                                     If bprices is used this argument
*                                     should contain ask prices otherwise
*                                     the  prevailing price. If use_ba 
*                                     is True subsequent data processing 
*                                     is specified in cfunc.
*                                     Dimension [nsec]
*
*                FL64ARRAY bprices    Array with nsec entries holding
*                                     clean bid prices of the bonds in
*                                     pmt. This argument is optional 
*                                     and is only used if model is not
*                                     BOOTSTRAP. If use_ba is True 
*                                     subsequent data processing is 
*                                     specified in cfunc. Enter NULL if
*                                     not used. Dimension [nsec]|NULL
*
*                FL64ARRAY spread     Array with nsec entries holding
*                                     the normal spread against the
*                                     term structure of the bonds.
*                                     If model != BOOTSTRAP:
*                                     Quoted as continuous rates in %.
*                                     If model == BOOTSTRAP:
*                                     The spreads are quoted as (%):
*
*                                       MM   - Annual Moneymarket rate
*                                       FRA  - Annual Moneymarket rate
*                                       IRF  - Annual Moneymarket rate
*                                       SWAP - Annually compounded rate
*                                       BOND - Annually compounded rate
*                                       BONDREPO - Annually compounded
*
*                                     Dimension [nsec]
*
*               FL64ARRAY madj        Margin adjustment. Only used for
*                                     IRF. List with nsec entries.
*                                     Calculate with Boot_BH2MarginAdj()
*                                     Dimension [nsec]
*
*               FL64ARRAY pricesX     Extra price for some securities:
*
*                                     SWAP - FloatLeg PV. Default is 100
*                                     BONDREPO - Bond forward price
*                                                times Conversion Factor
*
*                                     Enter NULL if not used.
*                                     List with nsec entries or NULL.
*                                     Dimension [nsec]|NULL
*
*               DATEARRAY settle      List of contract settlement dates.
*                                     Array with nsec entries.
*                                     Each security in secs may have an
*                                     individual settlement day (e.g 2
*                                     or 3 days in the future).
*                                     These days are not to be confused
*                                     with FRAsettlement etc, ie. the
*                                     days on which FRA/IRF's expire.
*                                     Any settle day must satisfy:
*
*                                       start <= settle[i]
*
*                                     Dimension [nsec]
*
*                HOLI_STR  *holi      Container for data on business
*                                     day convention and non-week-end
*                                     holidays.
*
*                DATEARRAY gridpts    List of dates for generating the
*                                     discount factors.
*                                     Only used if zerop->model is not
*                                     BOOTSTRAP.
*                                     Dimension [ngridpts]
*
*                INTI      ngridpts   No. of elements in gridpts
*
*                ITERCTRL  *ictrl     Iteration control.
*                                     Only uses acc, maxiter, shock
*                                     The meaning of shock is different
*                                     than according to the definition
*                                     in ITERCTRL. shock is the
*                                     initial step-size used in the 
*                                     algorithm.
*                                      
*                DFPARMS   *dfp       Interpolation data.
*
*    output      DISCFAC   *df        Discount factor setup.
*                                     The disc element is allocated in
*                                     this routine as:
*
*                                         Alloc_PLANARRAY(1, N)
*
*                                     where N is stored in the count
*                                     element.
*                                     All other data are set from dfp.
*
*                FITPARMS  *tsfit     Fitted parameter values and objective
*                                     function value. Parms in the FITPARMS
*                                     struct is allocated as:
*
*                                         Alloc_FL64ARRAY(N)
*
*                                     where N is stored in the nparms
*                                     element. In case of BOOTSTRAP this 
*                                     struct is meaningless and parms is
*                                     set to NULL.
*
*    returns     True if all is OK, False if not.
*
*    diagnostics
*
*    see also    Zero_Model2Price()
*                Zero_GenrTS()
*                Boot_BSEC2DF()
*
*    wrapper     AP
*
************************************************************************
,,EOH,,*/

BOOLE Fit_BSEC2DF(DATESTR*        start,
                  ZEROPARMS*      zerop,
                  CRITERIONFUNC*  cfun,
                  INTI            nsec,
                  BSECARRAY       secs,
                  BOOLE           use_ba,
                  FL64ARRAY       aprices,
                  FL64ARRAY       bprices,
                  FL64ARRAY       spread,
                  FL64ARRAY       madj,
                  FL64ARRAY       pricesX,
                  DATEARRAY       settle,
                  HOLI_STR*       holi,
                  DATEARRAY       gridpts,
                  INTI            ngridpts,
                  ITERCTRL*       ictrl,
                  DFPARMS*        dfp,
                  DISCFAC*        df,
                  FITPARMS*       tsfit)
{
    INTI        nfill, i, ndisc, k, count, j ;
    CFLWARRAY   cflw_1 ;
    PMTARRAY    pmt_0, pmt ;
    FL64ARRAY   pz, sprl, bidask, prices, terms, tmpterms ;
    HOLI_STR    hol ;
    BUSCONV     bus ;
    BOOLE       trueY, ok ;
    YTMCONV     ytmc ;
    TRADEINFO   tr1 ;
    EXRULE      xc ;
    FIXPAY      fixp ;
    ITERCTRL    ictrl1 ;    
    FL64        ytm ;
    CRITERIONFUNC  cfunc ;
    INTIARRAY   index ;
    DATEARRAY   discdates, tmpdates ;
    TSOVARRAY   tlambda ;
    ZEROPARMS   newzerop ;

    Math_LaGuerre(start->y, start->m, start->d);

    /* First we check for a bootstrap approach */
    if (zerop->model == BOOTSTRAP)
    {
        tsfit->obj = 0.0 ;
        tsfit->parms = NULL ;
        tsfit->nparms = 0 ;
        ok = Boot_BSEC2DF(start, secs, aprices, spread, madj, pricesX, settle,
                          nsec, holi, FILLNONE, 0, nsec - 1, dfp, df);
        return ok ;
    }

    discdates = Alloc_DATEARRAY(1) ;
    ndisc = 1 ;
    discdates[0] = *start ;

    /* If we are not using bootstrap, we have to use some kind of fit.
       In order to use Fit_Cflw2TS() we first have to find the cash flows */
 
    pmt     = Alloc_PMT(nsec) ;
    sprl    = Alloc_FL64ARRAY(nsec) ;
    pz      = Alloc_FL64ARRAY(nsec) ;
    bidask  = Alloc_FL64ARRAY(nsec) ;
    prices  = Alloc_FL64ARRAY(nsec) ;
    hol     = *holi ;
    hol.bus = NO_BUSADJUST ;
    bus     = holi->bus ;

    /* Make local copy of criterion function */
    cfunc.norm       = cfun->norm ;
    cfunc.doMacaulay = cfun->doMacaulay ;
    cfunc.docold     = cfun->docold ;
    cfunc.bidask     = cfun->bidask ;

    /* Setup weighting scheme */
    cfunc.noweights  = nsec ;
    cfunc.weights    = Alloc_FL64ARRAY(nsec) ;

    if(!cfunc.doMacaulay)
    {
      if (nsec == cfun->noweights)
      {   /* Copy weights */
        for (i = 0; i < nsec; i++)    
          cfunc.weights[i] = cfun->weights[i] ;
      }
      else
      {   /* if the number of weights are incorrect override! */
        for (i = 0; i < nsec; i++)    
          cfunc.weights[i] = 1.0 ;
      }
    }

    /* Setup smoothing parameters */

    cfunc.smparms = cfun->smparms ;
    if (cfunc.smparms.smcrit != NO_SMOOTH)
    {
       if (GetPlanFill(cfun->smparms.tlambda) > 0)
       {  /* Copy stepped lambda: */
         cfunc.smparms.tlambda = Alloc_PLANARRAY(1, 
                               GetPlanFill(cfun->smparms.tlambda));
         for (i = 0; i < GetPlanFill(cfun->smparms.tlambda); i++)
           Cldr_InsertInPlan(&cfun->smparms.tlambda->day[i], 
                             cfun->smparms.tlambda->f64[i],
                             cfunc.smparms.tlambda, True);
       }
       else
       {
         cfunc.smparms.tlambda = NULL ;
         cfunc.smparms.lambda = cfun->smparms.lambda ;
       }
    }
    else
       cfunc.smparms.tlambda = NULL ;

    for (nfill = i = 0; i < nsec; i++)
    {
        if (secs[i].type == BONDSMPL)
        {
            xc = Set_EXRULE(EX_DAYS, secs[i].excdays, True,
                            secs[i].cal, &settle[i], 0,
                            &settle[i], &settle[i], False) ;
            fixp = Bond_Simple2FIXPAY(&settle[i], &secs[i].start,
                                      &secs[i].maturity, secs[i].coupon,
                                      secs[i].freq, BULLET, &xc, NULL,
                                      secs[i].cal, secs[i].eom) ;
        }
        else if (secs[i].type == BOND)
            fixp = secs[i].fixp ;
        else
            continue ;

        if(use_ba && !cfunc.bidask)
          prices[i] = (aprices[i] + bprices[i]) / 2.0 ;
        else
          prices[i] = aprices[i] ;
          
        if (prices[i] < 0.00001 ||
            Cldr_DateLE(&fixp.cday.last, &settle[i]) == True)
            continue ;

        bidask[i] = (cfunc.bidask? aprices[i] - bprices[i] : 0.0) ; 

        /* Generate flow */
        tr1    = bond_set_tradeinfo(&settle[i]) ;
        cflw_1 = Bond_GenrCflw(&tr1, &fixp, &hol) ;

        tmpdates = Cldr_MergeDates(discdates, ndisc, cflw_1->days, 
          cflw_1->filled, &ndisc);
        
        Free_DATEARRAY(discdates);
        discdates = tmpdates;

        /* Simple day fractions */
        trueY = (secs[i].bus != NO_BUSADJUST ? True : False) ;
        ytmc = Set_YTMCONV(COMPOUND, ANNUALLY, True, True, True, fixp.fix.cal, 
                           fixp.fix.cal, fixp.fix.cal, trueY, False) ;
        holi->bus = secs[i].bus ;

        pmt_0 = Bond_Cflw2Pmt(start, cflw_1, &ytmc, &fixp.cday, holi) ;
        pmt_0->payment[0] = - prices[i] + cflw_1->coupon[0] ;

        /* We move the payment information into a single PMTARRAY (pmt) */
        pmt[nfill].term    = pmt_0[0].term ;
        pmt[nfill].payment = pmt_0[0].payment ;
        pmt[nfill].count   = pmt_0[0].count ;

        sprl[nfill] = spread[i] / 100 ;
        nfill++ ;

        /* Calculate Macaulay Duration? */
        if(cfunc.doMacaulay)
        {
          Init_ITERCTRL(&ictrl1) ;
          ok   = Bond_YTM2Yield(&tr1, &fixp, &ytmc, holi, &ictrl1, &ytm) ;
          if (ok)
            cfunc.weights[i] = Bond_YTM2Duration(ytm, &tr1, &fixp, 
                                           &ytmc, holi) ;
          else
            cfunc.weights[i] = 1.0 ;
          cfunc.noweights ++ ;
        }

        /* Free on the run stuff */
        Free_CFLWARRAY(cflw_1, 1);
        Free_PMT(pmt_0) ;
    }

    /* Now the payment structures are in the pmt array and we may 
       generate the term structure */
    holi->bus = bus ;

    /* Set up smoothness features if feasible */
    if (cfunc.smparms.smcrit != NO_SMOOTH)
    {
       /* Safety check */
       if (zerop->model != SPLINEDISC &&
           zerop->model != SPLINEEXPO &&
           zerop->model != SPLINEYIELD &&
           zerop->model != SPLINEX &&
           zerop->model != SPLINEF &&
           zerop->model != SPLINETRANS)
           cfunc.smparms = Set_SMOOTHPARMS(NO_SMOOTH, 0.0, NULL);

       Cldr_DateSort(ndisc, discdates, ASCENDING) ;

       /* Compute total number of terms. Terms are used to set-up 
          the smoothness parameters */
       count = pmt[0].count ;
       for (i = 1; i < nfill ; i++)
         count += pmt[i].count ;

       tmpterms = Alloc_FL64ARRAY(count) ;
       terms    = Alloc_FL64ARRAY(count) ;

       for (k = i = 0; i < nfill ; i++)
         for (j = 0 ; j < pmt[i].count ; j++)
           tmpterms[k++] = pmt[i].term[j] ;

       /* Sort it all */
       index = Scutl_Indexx_FL64(count, tmpterms, ASCENDING) ;

       /* Do the permutations */
       Scutl_Permute_FL64(count, index, tmpterms) ;

       /* Get unique entries */
       for (k = i = 0 ; i < count - 1 ; i++)
         if (tmpterms[i + 1] - tmpterms[i] > ROUND_NOISE)
           terms[k++] = tmpterms[i] ;

       /* Remember possible last element */
       if (tmpterms[i] != tmpterms[i - 1])
         terms[k++] = tmpterms[i] ;

       Free_INTIARRAY(index) ;
       Free_FL64ARRAY(tmpterms) ;

       /* Transform time varying lambdas into continuous time -
          note the abuse of the tsov structure */
      if (cfunc.smparms.tlambda != NULL)
       {
         i = k = 0 ;
         tlambda = Alloc_TSOVARRAY(1, cfunc.smparms.tlambda->filled) ;
         /* "Flat ends" */
         if (Cldr_DateLE(start, &cfunc.smparms.tlambda->day[0]))
         {
           tlambda->term[k] = 0.0 ;
           tlambda->vol[k++]  = cfunc.smparms.tlambda->f64[0] ;
           i++ ;
         }
         /* Check if any element is usable */
         if (k == 0)
         {
           while (i < cfunc.smparms.tlambda->filled - 1 && k == 0)
           {
             if (Cldr_DateLE(&cfunc.smparms.tlambda->day[i], start) &&
              Cldr_DateLT(start, &cfunc.smparms.tlambda->day[i + 1]))
             {
               tlambda->term[k] = 0.0 ;
               tlambda->vol[k++]  = cfunc.smparms.tlambda->f64[i] ;
             }
             i++ ;
           }
         }
         /* Safety - no usable elements */
         if (k == 0)
         {
           Free_TSOVARRAY(tlambda, 1) ;
           tlambda = NULL ;
         }
         else
         {
           while (i < cfunc.smparms.tlambda->filled)
           {
             tlambda->term[k] = Cldr_TermBetweenDates(start,
                            &cfunc.smparms.tlambda->day[i],
                            0, ACTACT, LAST, NULL) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
             tlambda->vol[k++]  = cfunc.smparms.tlambda->f64[i] ;
             i++ ;
           }
           tlambda->count = k ;
         }
       }
       else
         tlambda = NULL ;

       /* The calendar is only used to form an initial guess on the
       parameters in the optimization so EU30E360 should be as good
       a choice as any */
       newzerop = SetUp_Tanggaard(zerop->model, nsec, pmt, pz, 
                  spread, bidask, EU30E360, discdates, k, terms, ictrl, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
       
       *tsfit = Fit_Cflw2TS(&newzerop, &cfunc, nfill, pmt, pz, sprl, 
                           bidask, tlambda, ictrl);
       if (tlambda != NULL)
         Free_TSOVARRAY(tlambda, 1) ;

       /* And finally we can generate the discount function */
       if (tsfit->obj < ZERO_NO_SOLUTION - 0.00001)
       {
         df->disc = Zero_GenrDF(tsfit->parms, newzerop.spld, 
                    newzerop.ncoef, newzerop.model, dfp->cal, 
                    start, gridpts, ngridpts, newzerop.use_prep, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
         ok = True ;
       }
       else
       {
         df->disc = Alloc_PLANARRAY(1, 1) ;
         ok = False ;
       }

       Free_ZEROPARMS(&newzerop) ;
       Free_FL64ARRAY(terms);
    }
    else
    {
      /* Safety */
      cfunc.smparms = Set_SMOOTHPARMS(NO_SMOOTH, 0, NULL);
      *tsfit = Fit_Cflw2TS(zerop, &cfunc, nfill, pmt, pz, sprl, 
                           bidask, NULL, ictrl);
      if (tsfit->obj < ZERO_NO_SOLUTION - 0.00001)             
      {
         df->disc = Zero_GenrDF(tsfit->parms, zerop->spld, 
                    zerop->ncoef, zerop->model, dfp->cal, 
                    start, gridpts, ngridpts, zerop->use_prep, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
         ok = True ;
      }
      else
      {
         df->disc = Alloc_PLANARRAY(1, 1) ;
         ok = False ;
      }
    }

    df->what  = dfp->what ;
    df->iconv = dfp->iconv ;
    df->cal   = dfp->cal ;
    df->irr   = dfp->irr ;
    df->freq  = dfp->freq ;
    
    Free_PMTARRAY(pmt, nsec);
    Free_FL64ARRAY(sprl) ;
    Free_FL64ARRAY(pz) ;
    Free_FL64ARRAY(bidask) ;
    Free_FL64ARRAY(prices) ;
    Free_DATEARRAY(discdates);
    Free_CRITERIONFUNC(&cfunc) ;

    return ok ;
}


/*
..
*/

PMTARRAY Alloc_PMT(INTI ns)
{
    PMTARRAY   a ;

    a = (PMTARRAY) SCecon_calloc(ns, sizeof(PMT_STR), True, 
      "Alloc_PMT()") ;

    return a ;
}


/*
..
*/

void Free_PMT(PMTARRAY pmt)
{
    SCecon_free((VOIDPTR) pmt) ;
}


/***********************************************************************
*
*                Zero_abs_Prices()
*
*    interface   #include <fitzero.h>
*
*                int Zero_abs_Prices(integer *ncoef, integer *nsec,
*                                    double *coefs, double *f,
*                                    void* data) ;
*
*    general     The function the absolute deviations between estimated
*                prices and actual prices.
*
*                Uses global statics defines in this file.
*
*                The purpose of the function is to be the function that
*                the optimizer calls during optimization.
*
*                This function is strictly private and should not be
*                used elsewhere.
*
*    input       integer  *ncoef      Pointer to the number of coeffi-
*                                     cients.
*                integer  *nsec       Pointer to the number of securi-
*                                     ties.
*                double   *coefs      Zero offset pointer to the model
*                                     coefficients currently estimeated.
*                void     *data       Contains data originting from a
*                                     ZEROFITDATA !!!
*
*    output      double   *f          Zero offset pointer to the abso-
*                                     lute deviations.
*
*    returns     A 0 as int
*
*    diagnostics
*
*    see also
*
************************************************************************/


int Zero_abs_Prices(integer* ncoef, integer* nsec, double* coefs, 
                       void*  data, double* f)
{
    INTI      i, number ;
    FL64      pi, dum, *spread, *price, dummy ;
    FL64ARRAY cof ;
    ZEROFITDATA *sDATA ;

    /* NOTE: Deliberate cast from VOIDPTR to ZEROFITDATA
             This casting is necessary in order to pass instrument data
             generally through the Harwell optimiser. 
             The only general type is VOIDPTR.  */

    sDATA  = (ZEROFITDATA*) data;
    cof    = Alloc_FL64ARRAY(*ncoef) ;
    spread = sDATA->sNORMALOAS ;
    price  = sDATA->sFULLPRICE ;

    for (i = 0 ; i < (INTI) *ncoef ; i++)
        cof[i] = coefs[i] ;

    if (sDATA->sCFUNC->smparms.smcrit != NO_SMOOTH)
    {
      /* It is worth considering a method for calculating lambda - e.g.
      GCV as suggested in Tanggard */
      f[*nsec - 1] = Calculate_smoothness(sDATA->sPARMS->model, 
                     sDATA->sCFUNC->smparms.lambda,
                     sDATA->sStepLambda,
                     sDATA->sCFUNC->smparms.smcrit, *ncoef, cof, 
                     sDATA->sPARMS->spld) ;
      number = *nsec - 1;
    }
    else
      number = *nsec ;

    for (i = 0 ; i < number ; i++)
    {
        pi = Zero_Model2Price(cof, sDATA->sPARMS->spld, 
                              sDATA->sPARMS->use_prep,
                              (INTI) *ncoef, sDATA->sPARMS->model, 
                              &sDATA->sPMTS[i], spread[i], 
                              ZERO_ORDER, &dum, &dum) ;

        dummy = price[i] - pi ;

        /* Is the model price inside the bid-ask spread? */
        if (sDATA->sCFUNC->bidask)
          if (dummy < 0 && -sDATA->sBIDASK[i] < dummy)
            dummy = 0.0 ;

        f[i] = pow(dummy, sDATA->sCFUNC->norm) / sDATA->sTSDUR[i] ;
    }

    Free_FL64ARRAY(cof) ;

    return (int) 0 ;
}



/*,,SOH,,
**************************************************************************
*
*               Free_ZEROPARMS()
*
*   interface   #include <fitzero.h>
*
*               void Free_ZEROPARMS(ZEROPARMS* x);
*
*   general     Frees memory allocated in x.
*
*   input       ZEROPARMS   *x     Specification of zero parameters
*
*   output
*
*   returns
*
*   diagnostics
*
*   see also
*
**************************************************************************
,,EOH,,*/
void Free_ZEROPARMS(ZEROPARMS*  x)
{
    Free_FL64ARRAY(x->parms);
    Free_FL64ARRAY(x->spld);
    Free_FL64MATRIX(x->bounds);
}


/*,,SOH,,
**************************************************************************
*
*               Free_CRITERIONFUNC()
*
*   interface   #include <fitzero.h>
*
*               void Free_CRITERIONFUNC(CRITERIONFUNC* x);
*
*   general     Frees memory allocated in x.
*
*   input       CRITERIONFUNC *x     Specification of criterion function
*
*   output
*
*   returns
*
*   diagnostics
*
*   see also
*
**************************************************************************
,,EOH,,*/
void Free_CRITERIONFUNC(CRITERIONFUNC* x)
{
    Free_FL64ARRAY(x->weights) ;
    Free_PLANARRAY(x->smparms.tlambda, 1);
}


/* This function calculates the smoothness term used in the 
   optimization problem. See MGH-06-99 for details.
   Note f''(x) = 2 b_i. Note in case of time varying lambda
   this function does not support the case where lambda
   change twice in between two nodes. However this case probably
   only has academic interest */

FL64 Calculate_smoothness(ZEROMODEL   model,
                          FL64        lambda,
                          TSOVARRAY   tlambda,
                          SMOOTHCRIT  smcrit,
                          INTI        ncoef,
                          FL64ARRAY   coef,
                          FL64ARRAY   spld)
{
    FL64ARRAY y2 ;
    INTI      i, k = 0 ;
    FL64      hi, temp, temp1, result = 0.0 ;
    
    y2 = Alloc_FL64ARRAY(ncoef) ;

    /* Calculate second derivatives */
    if (model != SPLINEF)
      Math_Cspl_Prep(spld, coef, ncoef, SPLINE_MAX * 1.1,
                     SPLINE_MAX * 1.1, y2) ;
    else
      Math_Cspl_Prep(spld, coef, ncoef, 0.0, 0.0, y2) ;

    /* This function is "expensiv" hence a little extra effort
    is made to identify the situation */
    if (tlambda == NULL)
    {
      if (smcrit == SECONDDIFF)
      {
        for (i = 0 ; i < ncoef - 1; i++)
          result += (SQR(y2[i]) + SQR(y2[i + 1]) + y2[i] * y2[i + 1])*
          (spld[i + 1] - spld[i]) ;
        result *= lambda / 3.0 ;
      }
      else /* Must be FIRSTDIFF */
      {
        for (i = 0 ; i < ncoef - 1; i++)
        {
          hi = spld[i + 1] - spld[i] ;
          result += (SQR(coef[i + 1]) - 2.0 * coef[i + 1] * coef[i] +
            SQR(coef[i])) / hi + SQR(hi) * hi * (4.0 * (SQR(y2[i + 1]) +
            SQR(y2[i])) + 7.0 * y2[i + 1] * y2[i]) / 180.0 ;
        }
        result *= lambda ;
      }
    }
    else 
    {
      if (smcrit == SECONDDIFF)
      {
        for (i = 0 ; i < ncoef - 1; i++)
        {
          /* "Flat ends" */
          temp = ((k < tlambda->count - 1) ? spld[i + 1] - 
                 tlambda->term[k + 1] : -1.0) ;
          if (temp > 0.0)
          {
            temp1 = (SQR(y2[i]) + SQR(y2[i + 1]) + y2[i] * y2[i + 1]) ;
            result += temp1 * (spld[i + 1] - spld[i] - temp) 
                            * tlambda->vol[k++] ;
            result += temp1 * temp * tlambda->vol[k] ;
          }
          else
            result += (SQR(y2[i]) + SQR(y2[i + 1]) + y2[i] * y2[i + 1])*
              (spld[i + 1] - spld[i]) * tlambda->vol[k] ;
        }
        result /= 3.0 ;
      }
      else /* Must be FIRSTDIFF */
      {
        for (i = 0 ; i < ncoef - 1; i++)
        {
          /* "Flat ends" */
          temp = ((k < tlambda->count - 1) ? spld[i + 1] - 
                 tlambda->term[k + 1] : -1.0) ;
          if (temp > 0.0)
          {
            /* This is only true as an approximation but for
            practical purposes this should be close enough */
            hi = spld[i + 1] - spld[i] - temp;
            result += (SQR(coef[i + 1]) - 2.0 * coef[i + 1] * coef[i] +
            SQR(coef[i])) / hi + SQR(hi) * hi * (4.0 * (SQR(y2[i + 1]) +
            SQR(y2[i])) + 7.0 * y2[i + 1] * y2[i]) * 
            tlambda->vol[k++] / 180.0 ;
            result += (SQR(coef[i + 1]) - 2.0 * coef[i + 1] * coef[i] +
            SQR(coef[i])) / temp + SQR(temp) * temp * (4.0 * (SQR(y2[i + 1]) +
            SQR(y2[i])) + 7.0 * y2[i + 1] * y2[i]) * 
            tlambda->vol[k] / 180.0 ;
          }
          else
          {
            hi = spld[i + 1] - spld[i] ;
            result += (SQR(coef[i + 1]) - 2.0 * coef[i + 1] * coef[i] +
            SQR(coef[i])) / hi + SQR(hi) * hi * (4.0 * (SQR(y2[i + 1]) +
            SQR(y2[i])) + 7.0 * y2[i + 1] * y2[i]) * 
            tlambda->vol[k] / 180.0 ;
          }
        }

      }
    }

    Free_FL64ARRAY(y2) ;

    return result ;
}


/* Privat .. Constraint optimization in many dimension is
impossible. Hence use the Nelson & Siegel model to get a 
good initial guess! Obvious the limits are totally arbitrary so
it remains to investigate if they are appropriate. */

ZEROPARMS SetUp_Tanggaard(ZEROMODEL   model,
                          INTI        nsec,
                          PMTARRAY    pmt,
                          FL64ARRAY   prices,
                          FL64ARRAY   spread,
                          FL64ARRAY   bidask,
                          CALCONV     cal,
                          DATEARRAY   discdates,
                          INTI        k,
                          FL64ARRAY   terms,
                          ITERCTRL*   ictrl,
						  HOLI_STR*   holi) 
{
    INTI           i ;
    ZEROPARMS      zero, resul ;
    CRITERIONFUNC  cfun ;
    TSARRAY        ts ;
    PLANARRAY      disc ;
    FITPARMS       tsfit ;

    resul.model    = model ;
    resul.ncoef    = k ;
    resul.use_prep = False ;

    resul.parms  = Alloc_FL64ARRAY(k) ;
    resul.spld   = Alloc_FL64ARRAY(k) ;
    resul.bounds = Alloc_FL64MATRIX(k, 2) ;

    /* Fit the Nelson & Siegle curve */
    SetUp_NelsonSiegel(&zero, &cfun) ;
    tsfit = Fit_Cflw2TS(&zero, &cfun, nsec, pmt, prices, spread, bidask,
                        NULL, ictrl) ;

    if (model == SPLINEDISC)
    {
      disc = Zero_GenrDF(tsfit.parms, zero.spld, zero.ncoef, zero.model, 
                         cal, &discdates[0], discdates, k, False, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
      for (i = 0 ; i < k ; i++)
      {
        resul.parms[i] = disc->f64[i] ;
        resul.spld[i] = terms[i] ;
        resul.bounds[i][0] = resul.parms[i] - 0.1 ;
        resul.bounds[i][1] = resul.parms[i] + 0.1 ;
      }
      Free_PLANARRAY(disc, 1);
    }
    else
    {
      ts = Zero_GenrTS(tsfit.parms, zero.spld, zero.ncoef, zero.model, 
           terms, k, CONTINUOUS, 0, False) ;
      
      switch (model)
      {

      case SPLINEYIELD:
      case SPLINEF:
      case SPLINEX:

        for (i = 0 ; i < k ; i++)
        {
          resul.parms[i] = ts->rate[i] / 100 ;
          resul.spld[i]  = terms[i] ;
          resul.bounds[i][0] = resul.parms[i] - 0.01 ;
          resul.bounds[i][1] = resul.parms[i] + 0.01 ;
        }
        break;

      case SPLINEEXPO:

        for (i = 0 ; i < k ; i++)
        {
          resul.parms[i] = terms[i] * ts->rate[i] / 100 ;
          resul.spld[i]  = terms[i] ;
          resul.bounds[i][0] = GETMAX(0.00001, resul.parms[i] - 0.01) ;
          resul.bounds[i][1] = resul.parms[i] + 0.01 ;
        }
        break;
      
      case SPLINETRANS:

        for (i = 0 ; i < k ; i++)
        {
          resul.parms[i] = ts->rate[i] * (terms[i] + 1) / 100.0 ;
          resul.spld[i]  = terms[i] ;
          resul.bounds[i][0] = resul.parms[i] - 0.01 ;
          resul.bounds[i][1] = resul.parms[i] + 0.01 ;
        }
        break ;

      default:
        ;
      }
    Free_TSARRAY(ts, 1) ;
    }

    Free_ZEROPARMS(&zero) ;
    Free_CRITERIONFUNC(&cfun) ;
    Free_FL64ARRAY(tsfit.parms) ;

    return resul ;
}


/* Privat */

void  SetUp_NelsonSiegel(ZEROPARMS*      zero, 
                         CRITERIONFUNC*  cfun) 
{
    INTI     i ;

    /* Set up the zeroparms */
    zero->model    = EXTNS ;
    zero->ncoef    = 6 ;
    zero->use_prep = False ;

    zero->parms  = Alloc_FL64ARRAY(6) ;
    zero->spld   = Alloc_FL64ARRAY(6) ;
    zero->bounds = Alloc_FL64MATRIX(6, 2) ;

    zero->parms[0] = 0.05 ;
    zero->parms[1] = 0.03 ;
    zero->parms[2] = 0.01 ;
    zero->parms[3] = 0.00 ;
    zero->parms[4] = 1.00 ;
    zero->parms[5] = 0.01 ;

    zero->bounds[0][0] = 0.00001 ;
    zero->bounds[1][0] = -1.0 ;
    zero->bounds[2][0] = -5.0 ;
    zero->bounds[3][0] =  0.0 ;
    zero->bounds[4][0] = 0.01 ;
    zero->bounds[5][0] = 0.01 ;

    zero->bounds[0][1] =  0.3 ;
    zero->bounds[1][1] =  1.0 ;
    zero->bounds[2][1] =  5.0 ;
    zero->bounds[3][1] =  0.0 ;
    zero->bounds[4][1] =  5.0 ;
    zero->bounds[5][1] =  5.0 ;

    for (i = 0 ; i < 6 ; i++)
      zero->spld[i] = 0.0 ;

    /* Set up the criterion function */
    cfun->norm = 2 ;
    cfun->doMacaulay = False ;
    cfun->noweights  = 0 ;
    cfun->weights    = NULL ;
    cfun->docold     = False ;
    cfun->bidask     = False ;
    cfun->smparms    = Set_SMOOTHPARMS(NO_SMOOTH, 0, NULL);
}


/*,,SOH,,
************************************************************************
*
*                Set_SMOOTHPARMS()
*
*   interface    #include <fitzero.h>
*                SMOOTHPARMS Set_SMOOTHPARMS(SMOOTHCRIT  smcrit,
*                                            FL64        lambda,
*                                            PLAN_STR*   tlambda) ;
*
*   general      This routine sets the members of the struct defined
*                in the function name. The pointer members are simply
*                assigned - without physical copying. The intention
*                of the Set_*() routines is that by using this
*                functionality, one avoids setting individual members
*                of structs in the application code.
*
*                When new members are inserted in structs the Set_*()
*                routine will be changed accordingly.
*
*                For details on the interpretation of the individual
*                struct members please check the struct definition.
*
*   input        SMOOTHCRIT smcrit      See general section.
*
*                FL64       lambda      See general section.
*
*                PLAN_STR*  tlambda     See general section.
*
*   output
*
*   returns      The filled out SMOOTHPARMS struct
*
*   diagnostics
*
*   see also     CRITERIONFUNC
*
************************************************************************
,,EOH,,*/

SMOOTHPARMS Set_SMOOTHPARMS(SMOOTHCRIT  smcrit,
                            FL64        lambda,
                            PLAN_STR*   tlambda)
{
  SMOOTHPARMS x;

  x.smcrit  = smcrit ;
  x.lambda  = lambda ;
  x.tlambda = tlambda ;

  return x;
}



#undef RAN_INDEX
#undef ZERO_NO_SOLUTION
#undef ZERO_MINDUR
#undef GCV_EPS
#undef GCV_MAXIT      
#undef GCV_GUESS      
#undef GCV_DAMP       
#undef GCV_ACC        
#undef GCV_EPS        
#undef GCV_LOWER      
#undef GCV_UPPER      
#undef GCV_UPPER_SIZE 
#undef GCV_UPPER_VOL  
#undef ROUND_NOISE
#undef MEMORY

#include <sccsid.h>
SCCSID(tscalvl_c,
  "@(#)tscalvl.c	1.9 (SimCorp) 99/08/09 17:15:57")


/************************************************************************
*
*   project     SCecon
*
*   file name   validate.c
*
*   general     This file contains routines for validating the
*               content of the data structures of SCecon
*
************************************************************************/

/*** includes **********************************************************/
#include <tscalvl.h>

/*** defines ***********************************************************/
#define valid_tol 0.000001




/*,,SOH,,
***********************************************************************
*                                                                      
*               Validate_ZEROMODEL()
*                                                                      
*   interface   #include <tscalvl.h>                                  
*               BOOLE     Validate_ZEROMODEL(ZEROMODEL r)              
*                                                                      
*   general     This function validates the content of the ZEROMODEL
*               data structure                                         
*                                                                      
*   input       ZEROMODEL  r  The ZEROMODEL data structure
*                                                                      
*   output                                                             
*                                                                      
*   returns     True if r is a valid ZEROMODEL, False if invalid       
*                                                                      
*   diagnostics                                                        
*                                                                      
*   see also    ZEROMODEL
*                                                                      
***********************************************************************
,,EOH,,*/
BOOLE Validate_ZEROMODEL(ZEROMODEL  r)
{
    /* check that r is valid */
    switch (r)
    {
    case CIR:
    case CIRNOM:      
    case CCW:      
    case DPOLY:      
    case IYEXT:      
    case SPLINEDISC:      
    case SPLINEEXPO:      
    case SPLINEYIELD:
    case VASICEK:      
    case LONGSCH:      
    case BOOTSTRAP:      
    case SPLINEX:      
    case SPLINEF:   
    case BSPLYLD:   
    case BRNSTYLD:
    case EXTNS:
    case SPLINETRANS:
        return True ;
    default:    
        return False ;    
    }
}


/*,,SOH,,
***********************************************************************
*                                                                      
*               Validate_SMOOTHCRIT()
*                                                                      
*   interface   #include <tscalvl.h>                                  
*               BOOLE     Validate_SMOOTHCRIT(SMOOTHCRIT r)              
*                                                                      
*   general     This function validates the content of the SMOOTHCRIT
*               data structure                                         
*                                                                      
*   input       SMOOTHCRIT r  The SMOOTHCRIT data structure
*                                                                      
*   output                                                             
*                                                                      
*   returns     True if r is a valid SMOOTHCRIT, False if invalid       
*                                                                      
*   diagnostics                                                        
*                                                                      
*   see also    SMOOTHCRIT
*                                                                      
***********************************************************************
,,EOH,,*/
BOOLE Validate_SMOOTHCRIT(SMOOTHCRIT  r)
{
    /* check that r is valid */
    switch (r)
    {
    case FIRSTDIFF:
    case SECONDDIFF:      
    case NO_SMOOTH:      
        return True ;
    default:    
        return False ;    
    }
}



/*,,SOH,,
***********************************************************************
*                                                                      
*               Validate_SMOOTHPARMS()
*                                                                      
*   interface   #include <tscalvl.h>                                  
*               VALIDATE Validate_SMOOTHPARMS(SMOOTHPARMS *x)
*                                                                      
*   general     This function validates the content of the 
*               SMOOTHPARMS data structure
*                                                                      
*   input       SMOOTHPARMS    *x   The SMOOTHPARMS structure.
*
*   output                                                             
*                                                                      
*   returns     Valid_data if the content of SMOOTHPARMS is 
*               valid.
*                                                                      
*   diagnostics
*               Refer to SMOOTHPARMS for a specification of valid 
*               data.
*              
*   see also    SMOOTHPARMS
*                                                                      
***********************************************************************
,,EOH,,*/

VALIDATE Validate_SMOOTHPARMS(SMOOTHPARMS*  x)
{
    VALIDATE v ;

    if (Validate_SMOOTHCRIT(x->smcrit) == False)
        return Invalid_filled ;

    if (x->smcrit != NO_SMOOTH)
    {
      if (x->tlambda == NULL)
      {
        if (x->lambda < 0)
          return Invalid_filled ;
      }
      else
      {
        v = Validate_PLAN_STR(x->tlambda) ;
        if (v != Valid_data)
          return v;
      }
    }

    return Valid_data;
}



/*,,SOH,,
***********************************************************************
*                                                                      
*               Validate_ZEROPARMS()
*                                                                      
*   interface   #include <tscalvl.h>                                  
*               VALIDATE Validate_ZEROPARMS(ZEROPARMS *x)
*                                                                      
*   general     This function validates the content of the ZEROPARMS
*               data structure                                         
*                                                                      
*   input       ZEROPARMS *x   The ZEROPARMS structure.
*                                                                      
*   output                                                             
*                                                                      
*   returns     Valid_data if the content of ZEROPARMS is 
*               valid.
*                                                                      
*   diagnostics
*               Refer to ZEROPARMS for a specification of valid data.
*              
*   see also    ZEROPARMS
*                                                                      
***********************************************************************
,,EOH,,*/
VALIDATE Validate_ZEROPARMS(ZEROPARMS*  x)
{
    VALIDATE v;

    if (Validate_ZEROMODEL(x->model) == False)
      return Invalid_process_type;

    if (x->ncoef < 0)
      return Invalid_filled ;

    v = Validate_FL64ARRAY(x->parms, x->ncoef, False, 0.0, False, 0.0);
    if (v != Valid_data)
        return v;

    if (x->bounds != NULL)
    {
      v = Validate_FL64MATRIX(x->bounds, x->ncoef, 2, False, 0.0, 
      False, 0.0);
      if (v != Valid_data)
          return v;
    }

    v = Validate_FL64ARRAY(x->spld, x->ncoef, False, 0.0, False, 0.0);
    if (v != Valid_data)
        return v;

    if (Validate_BOOLE(x->use_prep) == False)
        return Invalid_boole;

    return Valid_data;
}



/*,,SOH,,
***********************************************************************
*                                                                      
*               Validate_CRITERIONFUNC()
*                                                                      
*   interface   #include <tscalvl.h>                                  
*               VALIDATE Validate_CRITERIONFUNC(CRITERIONFUNC *x)
*                                                                      
*   general     This function validates the content of the 
*               CRITERIONFUNC data structure           
*                                                                      
*   input       CRITERIONFUNC *x   The CRITERIONFUNC structure.
*
*   output                                                             
*                                                                      
*   returns     Valid_data if the content of CRITERIONFUNC is 
*               valid.
*                                                                      
*   diagnostics
*               Refer to CRITERIONFUNC for a specification of valid 
*               data.
*              
*   see also    CRITERIONFUNC
*                                                                      
***********************************************************************
,,EOH,,*/
VALIDATE Validate_CRITERIONFUNC(CRITERIONFUNC*  x)
{
    VALIDATE v;

    if (x->norm <= 0 || x->noweights < 0)
      return Invalid_filled ;
    
    if (Validate_BOOLE(x->doMacaulay) == False)
        return Invalid_boole;

    if (x->noweights > 0)
    {    /* do not allow negative weights */
      v = Validate_FL64ARRAY(x->weights, x->noweights, True, 0.0, 
                             False, 0.0);
      if (v != Valid_data)
        return v;
    }

    if (Validate_BOOLE(x->docold) == False)
        return Invalid_boole;

    if (Validate_BOOLE(x->bidask) == False)
        return Invalid_boole;

    v = Validate_SMOOTHPARMS(&x->smparms) ;
    if (v != Valid_data)
        return v;

    return Valid_data;
}



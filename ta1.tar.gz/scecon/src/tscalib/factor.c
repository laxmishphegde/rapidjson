/* SCID @(#)factor.c	1.7 (SimCorp) 99/09/14 14:57:57 */

/************************************************************************
*
*   project     SCecon
*
*   file name   factor.c
*
*   general     This file contains routines for factor analysis
*
************************************************************************/


/* defines  ************************************************************/
#define DAY_TOL 0.001

/* includes ************************************************************/
#include <fitzero.h>


/*,,SOH,,
*************************************************************************
*
*                Zero_Model2Factors()
*
*    interface   #include <fitzero.h>
*                BOOLE Zero_Model2Factors(ZEROMODEL  model,
*                                         DATEARRAY  dates,
*                                         FL64MATRIX parms,
*                                         INTI       ndate,
*                                         INTI       ncoef,
*                                         FL64ARRAY  spld,
*                                         FL64ARRAY  tstimes,
*                                         INTI       nts,
*                                         FL64       tol,
*                                         BOOLE      use_prep,
*                                         FL64MATRIX loads,
*                                         FL64MATRIX correl,
*                                         INTI       *nfact) ;
*
*    general     The function finds the loadings and correlations for a
*                list of (historic) term structures of interest rates.
*                This type of analysis is usually referred to as factor
*                analysis or principal components analysis.
*
*                The loadings express the basic interest rate movements
*                that has taken place over the period.
*                The loadings are sorted according to explanatory power.*
*                The first is the most significant etc. (*nact returns
*                the effective number of loadings/factors given desired
*                tolerance (tol)).
*
*                The correlations explains the degree of explanatory
*                power offered by each loadings for each maturity.
*
*                The method used is state of the art numerical analysis.*
*                The principal components are found using Singular
*                Value Decomposition (SVD).
*
*                The decomposition is based on the period returns rather*
*                than the yields.
*
*                The loadings returned are formulated in annually com-
*                pounded interest rates using the EU30E360 calendar.
*
*                The loadings calculated are scaled so that the reflect
*                a unit standard deviation shock to the term structure
*                given the period volatility.
*
*                In some cases the factors cannot be found, but these
*                cases are pathological, and are never encountered in
*                practice.
*
*    input       ZEROMODEL  model     The yield curve model.
*
*                DATEARRAY  dates     The list of dates.
*
*                FL64MATRIX parms     Matrix of model parameters.
*                                     ndate rows and ncoef columns.
*                                     Parameters must match the model.
*
*                INTI       ndate     The number of elements in dates.
*
*                INTI       ncoef     The number of model coefficients.
*
*                FL64ARRAY  spld      The spline terms. An array with
*                                     with ncoef elements of terms in
*                                     fractional years.
*                                     Only needed for the spline models.*
*                                     Must be sorted in ascending order
*                                     and be positive numbers.
*
*                FL64ARRAY  tstimes   The maturities for the loadings.
*                                     nts elements in the array.
*
*                INTI       nts       The number of elements in tstimes.*
*
*                FL64       tol       The required degree of tolerance.
*                                     0.99 for 99%
*
*                BOOLE      use_prep  Specifies if the function Zero_prep
*                                     _splines() is used (True) or not 
*                                     (False). Using Zero_prep_splines 
*                                     might stabilize the two ends of the
*                                     spline. The setting of this 
*                                     parameter must be the same as when
*                                     the model was calibrated. Only used
*                                     if model is SPLINEYIELD, SPLINEDISC,
*                                     SPLINEEXPO, SPLINEX, SPLINEF, or 
*                                     SPLINETRANS.  
*
*    output      FL64MATRIX loads     The loadings. Preallocated matrix
*                                     with nts rows and at most nts
*                                     columns. At exit nfact columns are*
*                                     filled.
*                                     The loadings represent rates in %.*
*
*                FL64MATRIX correl    The correlations. Preallocated
*                                     matrix with nts+1 rows and at most*
*                                     nts columns. At exit nfact columns*
*                                     are filled.
*                                     The last extra row represents
*                                     the cumulative explanation for the*
*                                     respective factors across maturi-
*                                     ties.
*
*                INTI       *nfact    Number of factors.
*
*    returns     True if estimation went OK, False otherwise.
*
*    diagnostics
*
*    see also    Zero_GenrTS()
*
*************************************************************************
,,EOH,,*/

BOOLE Zero_Model2Factors(ZEROMODEL model, DATEARRAY dates, FL64MATRIX parms,
                         INTI ndate, INTI ncoef, FL64ARRAY spld, 
                         FL64ARRAY tstimes, INTI nts, FL64 tol, BOOLE
                         use_prep, FL64MATRIX loads, FL64MATRIX correl, 
                         INTI* nfact)
{
    INTI       i, j, nobs ;
    FL64       tmp ;
    FL64ARRAY  contr, w ;
    FL64MATRIX u, v, returns ;
    BOOLE      ok ;

    /* 0. Initialize */
    *nfact = nts ;

    returns = Alloc_FL64MATRIX(ndate, nts) ;
    u       = Alloc_FL64MATRIX(ndate, nts) ;
    v       = Alloc_FL64MATRIX(nts, nts) ;
    w       = Alloc_FL64ARRAY(nts) ;
    contr   = Alloc_FL64ARRAY(nts) ;

    /* To avoid divide by zero */
    tstimes[0] = GETMAX(tstimes[0], DAY_TOL) ;

    /* 1.0 Generate returns from the individual term structures */
    nobs = Zero_Genr_returns(returns, model, dates, parms, ndate, ncoef,
                             spld, tstimes, nts, use_prep) ;

    /* 1.1 Copy returns into u */
    for (i = 0 ; i < nobs ; i++)
      for (j = 0 ; j < nts ; j++)
        u[i][j] = returns[i][j] ;

    /* 2. Decompose return matrix using the SVD */
    ok = Math_SVD(u, nobs, nts, 30, w, v) ;

    /* 3. Scale the factors and cut till needed tolerance */
    if (ok == True)
    {
        /* Now: ReturnMatrix = U * Transpose(V). Where the columns of U
           have unit standard deviation.
           This is in essence the factor decomposition */
        Zero_scale_factors(u, nobs, nts, w, v, *nfact, contr) ;

        /* Find needed factors */
        tmp = 0.0 ;
        i   = 0 ;
        tol = GETMIN(1.0, tol) ;
        while (tmp < tol && i < *nfact)
        {
            tmp += contr[i] ;
            i++ ;
        }

        *nfact = i ;
    }

    /* 4. Find correlations */
    Zero_Genr_correl(returns, nobs, nts, u, *nfact, v, correl) ;

    /* 5. Transform estimated return loadings to rate loadings */
    for (i = 0 ; ok == True && i < nts ; i++)
    {
        for (j = 0 ; j < *nfact ; j++)
        {
            tmp = v[i][j] ;

            /* This is DAILY changes in zero yields. 
               Use Continuous rates for simplicity */
            loads[i][j] = -100.0 * tmp / tstimes[i] ;
        }
    }

    /* 5. Clean up and return */
    Free_FL64MATRIX(returns) ;
    Free_FL64MATRIX(u) ;
    Free_FL64MATRIX(v) ;
    Free_FL64ARRAY(w) ;
    Free_FL64ARRAY(contr) ;

    return ok ;
}


/*
*************************************************************************
*
*                Zero_Genr_returns()
*
*    interface   #include <fitzero.h>
*                INTI Zero_Genr_returns(FL64MATRIX returns,
*                                      ZEROMODEL model,
*                                      DATEARRAY dates,
*                                      FL64MATRIX parms,
*                                      INTI ndate,
*                                      INTI ncoef,
*                                      FL64ARRAY spld,
*                                      FL64ARRAY tstimes,
*                                      INTI nts,
*                                      BOOLE use_prep) ;
*
*    general     The function finds the period returns given a list of
*                historic term structures.
*
*    input       ZEROMODEL model      The yield curve model.
*
*                DATEARRAY dates      The list of dates. ZERO offset
*                                     array with ndate entries.
*
*                FL64MATRIX parms     Matrix of model parameters.
*                                     ndate rows and ncoef columns.
*                                     Parameters must match the model.
*
*                INTI ndate           The number of elements in dates.
*
*                INTI ncoef           The number of model coefficients.
*
*                FL64ARRAY spld       The spline terms. An array with
*                                     with ncoef elements of terms in
*                                     fractional years.
*                                     Only needed for the spline models.
*                                     Must be sorted in ascending order
*                                     and be positive numbers.
*
*                FL64ARRAY tstimes    The maturities for the loadings.
*                                     nts elements in the array.
*
*                INTI      nts        The number of elements in tstimes.
*
*                BOOLE     use_prep   Specifies if the function Zero_prep
*                                     _splines() is used (True) or not 
*                                     (False). Using Zero_prep_splines 
*                                     might stabilize the two ends of the
*                                     spline. The setting of this 
*                                     parameter must be the same as when
*                                     the model was calibrated. Only used
*                                     if model is SPLINEYIELD, SPLINEDISC,
*                                     SPLINEEXPO, SPLINEX, SPLINEF, or 
*                                     SPLINETRANS.  
*
*    output      FL64MATRIX returns   The loadings. Preallocated matrix
*                                     with nts rows and at most nts
*                                     columns. At exit nfact columns are*
*                                     filled.
*                                     The loadings represent rates in %.*
*
*    returns     True number of return observations
*
*    diagnostics
*
*    see also
*
*************************************************************************
*/


INTI Zero_Genr_returns(FL64MATRIX returns, ZEROMODEL model, DATEARRAY dates,
                       FL64MATRIX parms, INTI ndate, INTI ncoef, FL64ARRAY spld,
                       FL64ARRAY tstimes, INTI nts, BOOLE use_prep)
{
    TSARRAY    ts0, ts1 ;
    INTI       nr, i, j ;
    FL64       tmp, yld1, yld2, term ;
    DATESTR    d1, d2 ;

    ts0 = Zero_GenrTS(parms[0], spld, ncoef, model,
                       tstimes, nts, COMPOUND, 1, use_prep) ;
    d1  = dates[0] ;

    for (nr = 0, i = 1 ; i < ndate ; i++)
    {
        ts1 = Zero_GenrTS(parms[i], spld, ncoef, model,
                           tstimes, nts, COMPOUND, 1, use_prep) ;
        d2  = dates[i] ;

        /* Here we calculate the period return of a zero coupon bond with a
           given maturity (tstimes[i]). The returns are DAILY returns and NOT
           annual returns. This is done for numerical stability and sensibi-
           lity.
           In future versions the user should be able to choose the duration
           of the return (daily, annual etc). */

        /* Any Actual-based convention for counting actual number days 
           will work: */
        term  = Cldr_DaysBetweenDates(&d1, &d2, ACT365, NULL) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */

        for (j = 0 ; j < nts; j++)
        {
            yld1 = Yld_Get_TsRate(ts0, tstimes[j], CUBIC_SPLINE) / 100.0 ;
            yld2 = Yld_Get_TsRate(ts1, tstimes[j], CUBIC_SPLINE) / 100.0 ;
            tmp  = pow((1.0 + yld1)/(1.0 + yld2), tstimes[j]/term) - 1.0 ;
            returns[i - 1][j] = tmp ;
        }

        d1 = d2 ;
        for (j = 0 ; j < nts ; j++)
            ts0->rate[j] = ts1->rate[j] ;

        nr++ ;
        Free_TSARRAY(ts1, 1) ;
    }

    /* Clean up */
    Free_TSARRAY(ts0, 1) ;

    return nr ;
}


/*
*************************************************************************
*
*                Zero_scale_factors()
*
*    interface   #include <fitzero.h>
*                void Zero_scale_factors(FL64MATRIX u,
*                                       INTI m,
*                                       INTI n,
*                                       FL64ARRAY w,
*                                       FL64MATRIX v,
*                                       INTI nfact,
*                                       FL64ARRAY contr) ;
*
*    general     The function scales the loadings to unit standard devi-*
*                ation.
*
*    input       FL64MATRIX u         The U matrix of SVD
*                                     m*n matrix.
*
*                INTI m               The number of rows in U
*
*                INTI n               The number of columns in U.
*
*                FL64ARRAY w          The singular values.
*                                     n entries.
*
*                FL64MATRIX v         The V matrix of the SVD.
*                                     n*n matrix.
*
*                INTI nfact           The maximal number of factors.
*
*    output      FL64ARRAY contr      The scaled singular values.
*
*    returns
*
*    diagnostics
*
*    see also
*
*************************************************************************
*/


void Zero_scale_factors(FL64MATRIX u, INTI m, INTI n, FL64ARRAY w, 
                           FL64MATRIX v, INTI nfact, FL64ARRAY contr)
{
    INTI      i, j ;
    FL64ARRAY mu, sigma ;
    FL64      sumw ;

    mu    = Alloc_FL64ARRAY(nfact) ;
    sigma = Alloc_FL64ARRAY(nfact) ;

    /* m is number of observations, n is number of TS points */
    for (i = 0 ; i < m; i++)
    {
        for (j = 0 ; j < nfact ; j++)
        {
             mu[j]    += u[i][j] ;
             sigma[j] += SQR(u[i][j]) ;
        }
    }

    /* mu is the mean of the columns of u and
       sigma's the stdev of the columns of u */
    for (j = 0 ; j < nfact ; j++)
    {
        mu[j]   /= (FL64) m ;
        sigma[j] = sigma[j] / ((FL64) m) - SQR(mu[j]) ;
        sigma[j] = sqrt(sigma[j]) ;
    }

    /* Scale each column of U with the standard deviation of the column */
    for (i = 0 ; i < m ; i++)
      for (j = 0 ; j < nfact ; j++)
        u[i][j] = u[i][j] / sigma[j] ;

    /* Scale each column of V with standard deviation of the columns of U 
       and the singular values.
       Now: ReturnMatrix = U * Transpose(V), where the columns of U have
       unit standard deviation */
    for (i = 0 ; i < n ; i++)
      for (j = 0 ; j < nfact ; j++)
        v[i][j] = v[i][j] * w[j] * sigma[j] ;

    /* Generate Factor contributions */
    for (sumw = 0.0, j = 0 ; j < nfact ; j++)
        sumw += SQR(w[j] * sigma[j]) ;

    for (j = 0 ; j < nfact ; j++)
        contr[j] = SQR(w[j] * sigma[j]) / sumw ;

    /* Clean up */
    Free_FL64ARRAY(mu) ;
    Free_FL64ARRAY(sigma) ;
}


/*
*************************************************************************
*
*                Zero_Genr_correl()
*
*    interface   #include <fitzero.h>
*                void Zero_Genr_correl(FL64MATRIX actualreturns,
*                                     INTI ndates,
*                                     INTI nterms,
*                                     FL64MATRIX u,
*                                     INTI nfactor,
*                                     FL64MATRIX v,
*                                     FL64MATRIX correl) ;
*
*    general     The function finds the factor correlations.
*
*    input       FL64MATRIX actret    The actual returns.
*                                     ndates * nterms matrix.
*
*                INTI ndates          The number of rows in actret
*
*                INTI nterms          The number of columns in actret
*
*                FL64MATRIX u         The scaled U matrix of SVD
*                                     m*n matrix.
*
*                INTI nfactor         The actualnumber of factors.
*
*                FL64MATRIX v         The scaled V matrix of the SVD.
*                                     n*n matrix.
*
*    output      FL64ARRAY correl     The correlations.
*                                     (nterms+1)*nfactor matrix
*
*    returns
*
*    diagnostics
*
*    see also
*
*************************************************************************
*/


void Zero_Genr_correl(FL64MATRIX actualreturns, INTI ndates, INTI nterms,
                      FL64MATRIX u, INTI nfactor, FL64MATRIX v,
                      FL64MATRIX correl)
{
    FL64MATRIX fittedreturns ;
    FL64ARRAY  actterm, fitterm ;
    FL64       tmp, tmp1 ;
    INTI       i, j, k ;

    fittedreturns = Alloc_FL64MATRIX(ndates, nterms) ;
    actterm       = Alloc_FL64ARRAY(ndates) ;
    fitterm       = Alloc_FL64ARRAY(ndates) ;

    /* Matrix multiply to get fitted rors */
    /* successively add one factor */

    for (k = 0 ; k < nfactor ; k++)
    {
        for (i = 0 ; i < ndates ; i++)
        {
            for (j = 0 ; j < nterms ; j++)
            {
                 tmp  = u[i][k] ;
                 tmp *= v[j][k] ;
                 tmp1 = fittedreturns[i][j] ;
                 fittedreturns[i][j] = tmp1 + tmp ;
            }
        }

        /* Get correlation coefficient for individual maturities */
        for (j = 0 ; j < nterms ; j++)
        {
            for (i = 0 ; i < ndates ; i++)
            {
                 actterm[i] = actualreturns[i][j] ;
                 fitterm[i] = fittedreturns[i][j] ;
            }

            tmp = Stat_Correl(ndates, actterm, fitterm) ;
            correl[j][k] = tmp ;
        }

        tmp = Zero_correl_matrix(actualreturns, fittedreturns, ndates, nterms) ;
        correl[nterms][k] = tmp ;
    }

    /* Clean up */
    Free_FL64MATRIX(fittedreturns) ;
    Free_FL64ARRAY(actterm) ;
    Free_FL64ARRAY(fitterm) ;
}


/*
*************************************************************************
*
*                Zero_correl_matrix()
*
*    interface   #include <fitzero.h>
*                FL64 Zero_correl_matrix(FL64MATRIX x,
*                                        FL64MATRIX y,
*                                        INTI m,
*                                        INTI n) ;
*
*    general     The function finds the correlation between 2 matrices.
*
*    input       FL64MATRIX x         The first matrix.
*                                     m * n matrix
*
*                FL64MATRIX u         The second matrix.
*                                     m * n  matrix.
*
*                INTI m               The number of rows in x and y
*
*                INTI n               The number of columns in x and y
*
*    output
*
*    returns     The correlation
*
*    diagnostics
*
*    see also
*
*************************************************************************
*/


FL64 Zero_correl_matrix(FL64MATRIX x, FL64MATRIX y, INTI m, INTI n)
{
    INTI i, j ;
    FL64 yt, xt, syy, sxy, sxx, ay, ax ;

    syy = sxy = sxx = ay = ax = 0.0 ;

    for (i = 0 ; i < m ; i++)
    {
        for (j = 0 ; j < n ; j++)
        {
            ax += x[i][j] ;
            ay += y[i][j] ;
        }
    }

    ax /= (1.0 * n * m) ;
    ay /= (1.0 * n * m) ;

    for (i = 0 ; i < m ; i++)
    {
        for (j = 0 ; j < n ; j++)
        {
            xt   = x[i][j] - ax ;
            yt   = y[i][j] - ay ;
            sxx += xt * xt ;
            syy += yt * yt ;
            sxy += xt * yt ;
        }
    }

    return sxy / sqrt(sxx * syy) ;
}


#undef DAY_TOL

/* SCID @(#)bootstrp.c	1.17 (SimCorp) 99/05/21 13:54:53  */

/***********************************************************************
*
*       project         SCecon Library
*
*       file name       bootstrp.c
*
*       contains        bootstrapping of discount function
*
************************************************************************/

/*** includes **********************************************************/
#include <bootstrp.h>

/*** defines  **********************************************************/
#define PARSWAP_MAXIT  100
#define PARSWAP_ACC    0.0000001
#define PARSWAP_EPS    0.000001

#define IRG_MAXIT      100
#define IRG_MAXCHG     25.0
#define IRG_DAMP       0.9
#define IRG_ACC        0.000000001
#define IRG_EPS        0.0001
#define IRG_NEGVOL     -1
#define IRG_TOOMANY    -2

#define ZERO_TOL       0.000000001


/*
************************************************************************
*
*               Boot_MM_Disc()
*
*   interface   #include <bootstrp.h>
*               FL64 Boot_MM_Disc(DATESTR   *settle,
*                                 IRRCONV   irr,
*                                 INTI      terms,
*                                 TERMUNIT  unit,
*                                 FL64      par_rate,
*                                 FL64      spread,
*                                 CALCONV   cal,
*                                 EOMCONV   eom,
*                                 HOLI_STR  *holi,
*                                 BOOLE     fill,
*                                 DISCFAC   *df) ;
*
*   general     The function returns the discount factor implied by
*               a money market instrument.
*
*               It is assumed that the instrument only has 1 payment
*               at maturity.
*
*               Beyond generating the discount factor it is inserted
*               appropriately in the discount function. The discount
*               function must therefore be preallocated with sufficient
*               entries. If this is not the case the entry is not
*               inserted.
*
*               The use of this function will typically be within a
*               bootstrapping loop - in which the yield curve is
*               'stripped' by successively generating discount factors
*               from money market instruments - Deposits, Interest Rate
*               Futures, FRA's, Par Swaps and bonds.
*
*               The issue of credit quality of the individual securities
*               is handled via the spread. A nonzero spread implies that
*               the curve being bootstrapped is of a different credit
*               quality than this specific MM instrument.
*               If the spread is positive the curve has better credit
*               quality than this MM, and if it is negative this MM has
*               better credit quality than the curve.
*
*               The design of a bootstrap driver is straightforward
*               and involves mainly sorting the securities according
*               to maturities and then - off course - loopcontrol.
*               See Boot_BSEC2DF() as an example.
*
*   input       DATESTR   *settle  The day of contract settlement
*
*               IRRCONV   irr      DISCOUNT or SIMPLE_MM
*
*               INTI      terms    Number of units till maturity.
*
*               TERMUNIT  unit     Unit of maturity quoting.
*
*               FL64      par_rate The par rate of the instrument in
*                                  percent as quoted.
*
*               FL64      spread   The spread from the rating implied
*                                  by the par rate to the rating of
*                                  the curve that is being bootstrapped.
*                                  The spread is an annual money market
*                                  rate in %.
*
*               CALCONV   cal      The calendar convention.
*
*               EOMCONV   eom      The end of month convention.
*
*               HOLI_STR  *holi    Container for data on business
*                                  day convention and non-week-end
*                                  holidays.
*
*               BOOLE     fill     Fill all or not.
*
*               DISCFAC   *df      The discount function setup.
*                                  The discount structure is updated in
*                                  the function.
*   output
*
*   returns     the discount factor.
*
*   diagnostics
*
*   see also    Boot_FRA_Disc()
*               Boot_IRF_Disc()
*               Boot_Parswap_Disc()
*               Boot_Bond_Disc()
*               Boot_BSEC2DF()
*
************************************************************************
*/


FL64 Boot_MM_Disc(DATESTR* settle,
                  IRRCONV   irr,
                  INTI      terms,
                  TERMUNIT  unit,
                  FL64      par_rate,
                  FL64      spread,
                  CALCONV   cal,
                  EOMCONV   eom,
                  HOLI_STR*  holi,
                  BOOLE     fill,
                  DISCFAC*   df)
{
    FL64    period, par_mm, quote, disc ;
    DATESTR matur, day1 ;

    /* This is a spot or a forward contract */
    day1  = Cldr_NextBusinessDate(settle, holi) ;
    matur = Cldr_TermUnit2Date(&day1, terms, unit, cal, eom, holi) ;
    matur = Cldr_NextBusinessDate(&matur, holi) ;

    if (irr == SIMPLE_MM)
        quote = 100.0 - par_rate ;
    else
    {
        /* Translate discount basis to money market basis */
		period = Cldr_TermBetweenDates(&day1, &matur, 0, cal, eom, holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */
        disc   = TVMunit_NPV(period, par_rate, DISCOUNT, 1) ;
        par_mm = TVMunit_Yield(disc, period, SIMPLE_MM, 1) ;
        quote  = 100.0 - par_mm ;
    }

    disc  = Boot_IRF_Disc(settle, &matur, quote, spread, 0.0, cal, eom,
                          holi, fill, df) ;
    return disc ;
}


/*
************************************************************************
*
*               Boot_FRA_Disc()
*
*   interface   #include <bootstrp.h>
*               FL64 Boot_FRA_Disc(DATESTR    *settle,
*                                  INTI       term1,
*                                  INTI       term2,
*                                  TERMUNIT   unit,
*                                  FL64       par_rate,
*                                  FL64       spread,
*                                  CALCONV    cal,
*                                  EOMCONV    eom,
*                                  HOLI_STR   *holi,
*                                  BOOLE      fill,
*                                  DISCFAC    *df,
*                                  BOOLE      nest) ;
*
*   general     The function returns the discount factor implied by
*               a FRA and the discount function in df->disc.
*
*               Beyond generating the discount factor it is inserted
*               appropriately in the discount function. The discount
*               function must therefore be preallocated with sufficient
*               entries. If this is not the case the entry is not
*               inserted.
*
*               The use of this function will typically be within a
*               bootstrapping loop - in which the yield curve is
*               'stripped' by successively generating discount factors
*               from money market instruments - Deposits, Interest Rate
*               Futures, FRA's, Par Swaps and bonds.
*
*               The issue of credit quality of the individual securities
*               is handled via the spread. A nonzero spread implies that
*               the curve being bootstrapped is of a different credit
*               quality than this specific FRA.
*               If the spread is positive the curve has better credit
*               quality than this FRA, and if it is negative this FRA
*               has better credit quality than the curve.
*
*               The design of a bootstrap driver is straightforward
*               and involves mainly sorting the securities according
*               to maturities and then - off course - loopcontrol.
*               See Boot_BSEC2DF() as an example.
*
*               In this loop scheme an FRA cannot be the first security
*               since the FRA essentially is used to generate a forward
*               discount factor. To get the spot factor a previous spot
*               observation is needed, eg. from a deposit.
*
*   input       DATESTR   *settle  The day of contract settlement
*
*               INTI      term1    The term till start of the FRA in
*                                  unit's.
*
*               INTI      term2    The term till maturity of the FRA in
*                                  unit's.
*
*               TERMUNIT  unit     Unit of term quoting.
*
*               FL64      par_rate The par rate of the instrument in
*                                  percent.
*
*               FL64      spread   The spread from the rating implied
*                                  by the par rate to the rating of
*                                  the curve that is being bootstrapped.
*                                  The spread is an annual money market
*                                  rate in %.
*
*               CALCONV   cal      The calendar convention.
*
*               EOMCONV   eom      The end of month convention.
*
*               HOLI_STR  *holi    Container for data on business
*                                  day convention and non-week-end
*                                  holidays.
*
*               BOOLE     fill     Fill all or not.
*
*               DISCFAC   *df      The discount function setup.
*                                  Must contain at least 2 observations.
*                                  The discount structure is updated in
*                                  the function.
*
*               BOOLE     nest     How to handle businessdays. If set
*                                  to True, we use the Miron & Swannell
*                                  convention of moving FRA days.
*                                  If False we follow market standard.
*
*   output
*
*   returns     the discount factor.
*
*   diagnostics
*
*   see also    Boot_MM_Disc()
*               Boot_IRF_Disc()
*               Boot_Parswap_Disc()
*               Boot_Bond_Disc()
*               Boot_BSEC2DF()
*
************************************************************************
*/


FL64 Boot_FRA_Disc(DATESTR* settle,
                   INTI      term1,
                   INTI      term2,
                   TERMUNIT  unit,
                   FL64      par_rate,
                   FL64      spread,
                   CALCONV   cal,
                   EOMCONV   eom,
                   HOLI_STR*  holi,
                   BOOLE     fill,
                   DISCFAC*   df,
                   BOOLE     nest)
{
    FL64    disc ;
    DATESTR day1, start, matur ;
    SEQCONV roll ;
    PERIOD  per ;
    
    day1  = Cldr_NextBusinessDate(settle, holi) ;
    roll  = (nest == True ? CHAIN : ANCHOR) ;
    per   = Set_PERIOD(term1, unit) ;
    start = Cldr_NextROLL(&day1, roll, &per, cal, eom, holi) ;
    start = Cldr_NextBusinessDate(&start, holi) ;

    /* Be careful when finding second date */
    if (roll == CHAIN)
    {
        per   = Set_PERIOD(term2 - term1, unit) ;
        matur = Cldr_NextROLL(&start, roll, &per, cal, eom, holi) ;
    }
    else
    {
        per   = Set_PERIOD(term2, unit) ;
        matur = Cldr_NextROLL(&day1, roll, &per, cal, eom, holi) ;
    }

    matur = Cldr_NextBusinessDate(&matur, holi) ;

    disc  = Boot_IRF_Disc(&start, &matur, 100.0 - par_rate, spread, 0.0,
                          cal, eom, holi, fill, df) ;

    return disc ;
}


/*
************************************************************************
*
*               Boot_IMMFRA_Disc()
*
*   interface   #include <bootstrp.h>
*               FL64 Boot_IMMFRA_Disc(DATESTR    *start,
*                                     INTI       term1,
*                                     TERMUNIT   unit,
*                                     FL64       par_rate,
*                                     FL64       spread,
*                                     CALCONV    cal,
*                                     EOMCONV    eom,
*                                     HOLI_STR   *holi,
*                                     BOOLE      fill,
*                                     DISCFAC    *df) ;
*
*   general     The function returns the discount factor implied by
*               an IMMFRA and the discount function in df->disc.
*
*               Beyond generating the discount factor it is inserted
*               appropriately in the discount function. The discount
*               function must therefore be preallocated with sufficient
*               entries. If this is not the case the entry is not
*               inserted.
*
*               The use of this function will typically be within a
*               bootstrapping loop - in which the yield curve is
*               'stripped' by successively generating discount factors
*               from money market instruments - Deposits, Interest Rate
*               Futures, FRA's, Par Swaps and bonds.
*
*               The issue of credit quality of the individual securities
*               is handled via the spread. A nonzero spread implies that
*               the curve being bootstrapped is of a different credit
*               quality than this specific IMMFRA.
*               If the spread is positive the curve has better credit
*               quality than this IMMFRA, and if it is negative this 
*               IMMFRA has better credit quality than the curve.
*
*               The design of a bootstrap driver is straightforward
*               and involves mainly sorting the securities according
*               to maturities and then - off course - loopcontrol.
*               See Boot_BSEC2DF() as an example.
*
*               In this loop scheme an IMMFRA cannot be the first security
*               since the IMMFRA essentially is used to generate a forward
*               discount factor. To get the spot factor a previous spot
*               observation is needed, eg. from a deposit.
*
*               DATESTR   *start   The IMMFRA starts on the IMM date of the
*                                  month of this date.
*
*               INTI      term1    The term till maturity of the IMMFRA 
*                                  in unit's. The IMMFRA matures on the IMM
*                                  date of the month term1 units later than the
*                                  starting date.
*
*               TERMUNIT  unit     Unit of term quoting.
*
*               FL64      par_rate The par rate of the instrument in
*                                  percent.
*
*               FL64      spread   The spread from the rating implied
*                                  by the par rate to the rating of
*                                  the curve that is being bootstrapped.
*                                  The spread is an annual money market
*                                  rate in %.
*
*               CALCONV   cal      The calendar convention.
*
*               EOMCONV   eom      The end of month convention.
*
*               HOLI_STR  *holi    Container for data on business
*                                  day convention and non-week-end
*                                  holidays.
*
*               BOOLE     fill     Fill all or not.
*
*               DISCFAC   *df      The discount function setup.
*                                  Must contain at least 2 observations.
*                                  The discount structure is updated in
*                                  the function.
*
*   output
*
*   returns     the discount factor.
*
*   diagnostics
*
*   see also    Boot_MM_Disc()
*               Boot_IRF_Disc()
*               Boot_Parswap_Disc()
*               Boot_Bond_Disc()
*               Boot_BSEC2DF()
*
************************************************************************
*/


FL64 Boot_IMMFRA_Disc(DATESTR*  start,
                          INTI      term1,
                          TERMUNIT  unit,
                          FL64      par_rate,
                          FL64      spread,
                          CALCONV   cal,
                          EOMCONV   eom,
                          HOLI_STR*  holi,
                          BOOLE     fill,
                          DISCFAC*  df)
{
    FL64    disc ;
    DATESTR imm_start, imm_matur ;
    PERIOD  per ;
    
    imm_start = Cldr_IMMInMonth(start) ;
    per       = Set_PERIOD(term1, unit) ;
    imm_matur = Cldr_AddPeriod(&imm_start, &per, cal, eom, holi);

    disc  = Boot_IRF_Disc(&imm_start, &imm_matur, 100.0 - par_rate, spread,
                          0.0, cal, eom, holi, fill, df) ;

    return disc ;
}


/*
************************************************************************
*
*               Boot_IRF_Disc()
*
*   interface   #include <bootstrp.h>
*               FL64 Boot_IRF_Disc(DATESTR    *start,
*                                  DATESTR    *matur,
*                                  FL64       price,
*                                  FL64       spread,
*                                  FL64       madj,
*                                  CALCONV    cal,
*                                  EOMCONV    eom,
*                                  HOLI_STR   *holi,
*                                  BOOLE      fill,
*                                  DISCFAC    *df) ;
*
*   general     The function returns the discount factor implied by
*               an Interest Rate Future, quoted as 100 - annual rate.
*
*               Beyond generating the discount factor it is inserted
*               appropriately in the discount function. The discount
*               function must therefore be preallocated with sufficient
*               entries. If this is not the case the entry is not
*               inserted.
*
*               The use of this function will typically be within a
*               bootstrapping loop - in which the yield curve is
*               'stripped' by successively generating discount factors
*               from money market instruments - Deposits, Interest Rate
*               Futures, FRA's, Par Swaps and bonds.
*
*               The issue of credit quality of the individual securities
*               is handled via the spread. A nonzero spread implies that
*               the curve being bootstrapped is of a different credit
*               quality than this specific IRF.
*               If the spread is positive the curve has better credit
*               quality than this IRF, and if it is negative this IRF
*               has better credit quality than the curve.
*
*               The design of a bootstrap driver is straightforward
*               and involves mainly sorting the securities according
*               to maturities and then - off course - loopcontrol.
*               See Boot_BSEC2DF() as an example.
*
*               In this loop scheme an IRF cannot be the first security
*               since the IRF essentially is used to generate a forward
*               discount factor. To get the spot factor a previous spot
*               observation is needed (eg. from a deposit).
*
*   input       DATESTR   *start   The start date of the contract.
*
*               DATESTR   *matur   Maturity date of the contract.
*
*               FL64      price    The price in percent.
*
*               FL64      spread   The spread from the rating implied
*                                  by the par rate to the rating of
*                                  the curve that is being bootstrapped.
*                                  The spread is an annual money market
*                                  rate in %.
*
*               FL64      madj     Margin Adjustment (%).
*
*               CALCONV   cal      The calendar convention.
*
*               EOMCONV   eom      The end of month convention.
*
*               HOLI_STR  *holi    Container for data on business
*                                  day convention and non-week-end
*                                  holidays.
*
*               BOOLE     fill     Fill all or not.
*
*               DISCFAC   *df      The discount function setup.
*                                  Must contain at least 2 observations,
*                                  one for today, with a discount factor
*                                  of unity, and one later.
*                                  The discount structure is updated in
*                                  the function.
*
*   output
*
*   returns     the discount factor.
*
*   diagnostics
*
*   see also    Boot_MM_Disc()
*               Boot_FRA_Disc()
*               Boot_Parswap_Disc()
*               Boot_Bond_Disc()
*               Boot_BSEC2DF()
*
************************************************************************
*/


FL64 Boot_IRF_Disc(DATESTR* start,
                   DATESTR*   matur,
                   FL64      price,
                   FL64      spread,
                   FL64      madj,
                   CALCONV   cal,
                   EOMCONV   eom,
                   HOLI_STR*  holi,
                   BOOLE     fill,
                   DISCFAC*   df)
{
    FL64    d1, disc, period ;
    DATESTR today, xstart, xmatur ;

    /* Initialization */
    today  = df->disc->day[0] ;
    xstart = Cldr_NextBusinessDate(start, holi) ;
    xmatur = Cldr_NextBusinessDate(matur, holi) ;

    /* Get the forward discount factor */
    period = Cldr_TermBetweenDates(&xstart, &xmatur, 0, cal, eom, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
    disc   = TVMunit_NPV(period, (100.0 - price) - spread - madj, 
                         SIMPLE_MM, 1) ;

    /* Handle 0 days stub cash - specially */
    if (Cldr_DateEQ(&today, &xstart) == True)
        d1 = 1.0 ;
    else
        d1 = Disc_Interpolation(&xstart, df, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */

    if (df->iconv == CUBIC_SPLINE || fill == True)
        Cldr_InsertInPlan(&xstart, d1, df->disc, True) ;

    /* Chain to get the spot factor */
    disc *= d1 ;

    if (disc > 0.0)
        Cldr_InsertInPlan(&xmatur, disc, df->disc, True) ;

    return disc ;
}


/*
..Use this to model Average Rate Futures (e.g FF Futures)
*/


FL64 Boot_AVGIRF_Disc(DATESTR* start,
                      DATESTR*   matur,
                      INTI      term,
                      TERMUNIT  unit,
                      FL64      curr_avg,
                      FL64      price,
                      FL64      spread,
                      CALCONV   cal,
                      EOMCONV   eom,
                      HOLI_STR*  holi,
                      BOOLE     fill,
                      DISCFAC*   df)
{
    FL64     t, FF, dt, disc ;
    DATESTR  xstart, xmatur, today, prev, next ;
    INTI     i, n, n1, n2 ;
    PERIOD   per ;
    HOLI_STR hol ;

    xstart = Cldr_NextBusinessDate(start, holi) ;
    xmatur = Cldr_NextBusinessDate(matur, holi) ;
    hol    = Set_HOLI_STR(NO_BUSADJUST, 0, &today) ;

    /* Be careful out there */
    term  = GETMAX(term, 1) ;
    if (Cldr_DateLT(&xmatur, &xstart) == True)
        return 1.0 ;

    today = df->disc->day[0] ;
    disc  = 1.0 ;
    per   = Set_PERIOD(term, unit) ;
    prev  = xstart ;
    FF    = 100.0 - price - spread ;

    /* Is the future period broken ? */
    if (Cldr_DateLT(&xstart, &today) == True)
    {
        /* This is a broken period future */
        n1 = Cldr_PeriodsBetweenDates(&xstart, &today, &per, cal, eom, holi) ;
        n  = Cldr_PeriodsBetweenDates(&xstart, &xmatur, &per, cal, eom, holi) ;
        n2 = n - n1 ;

        /* Calculate average rate for remaining period */
        FF = ((FL64) n) * FF - curr_avg * (FL64) n1 ;
        FF = FF / (FL64) n2 ;

        /* Be careful about cases where quick calculation is possible (FF) */
        if (per.unit == DAYS && per.num == 1)
        {
            next = Cldr_TermUnit2Date(&prev, term, unit, cal, eom, holi) ;
            dt   = Cldr_TermBetweenDates(&prev, &next, 0, cal, LAST, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
            disc = TVMunit_NPV(dt, FF, SIMPLE_MM, 1) ;
            disc = pow(disc, (FL64) n2) ;
        }
        else
        {
            for (i = 0; i < n; i++)
            {
                next = Cldr_TermUnit2Date(&prev, term, unit, cal, eom, holi) ;
                if (Cldr_DateLE(&xmatur, &next) == True)
                    next = xmatur ;

                if (Cldr_DateLE(&today, &prev) == True)
                {
                    dt    = Cldr_TermBetweenDates(&prev, &next, 0, cal, LAST, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
                    disc *= TVMunit_NPV(dt, FF, SIMPLE_MM, 1) ;
                }

                prev = next ;
            }
        }

        t    = Cldr_TermBetweenDates(&today, &xmatur, 0, cal, LAST, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
        FF   = TVMunit_Yield(disc, t, SIMPLE_MM, 1) ;
        disc = Boot_IRF_Disc(&today, &xmatur, 100.0 - FF, 0.0, 0.0,
                             cal, eom, &hol, fill, df) ;
    }
    else
    {
        /* This future starts in the future */
        n1 = Cldr_PeriodsBetweenDates(&xstart, &xmatur, &per, cal, eom, holi) ;

        /* Be careful about cases where quick calculation is possible (FF) */
        if (per.unit == DAYS && per.num == 1)
        {
            next = Cldr_TermUnit2Date(&prev, term, unit, cal, eom, holi) ;
            dt   = Cldr_TermBetweenDates(&prev, &next, 0, cal, LAST, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
            disc = TVMunit_NPV(dt, FF, SIMPLE_MM, 1) ;
            disc = pow(disc, (FL64) n1) ;
        }
        else
        {
            /* Here do it the hard way */
            for (i = 0; i < n1; i++)
            {
                next = Cldr_TermUnit2Date(&prev, term, unit, cal, eom, holi) ;
                if (Cldr_DateLE(&xmatur, &next) == True)
                    next  = xmatur ;

                dt    = Cldr_TermBetweenDates(&prev, &next, 0, cal, LAST, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
                disc *= TVMunit_NPV(dt, FF, SIMPLE_MM, 1) ;
                prev  = next ;
            }
        }

        t    = Cldr_TermBetweenDates(&xstart, &xmatur, 0, cal, LAST, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
        FF   = TVMunit_Yield(disc, t, SIMPLE_MM, 1) ;
        disc = Boot_IRF_Disc(&xstart, &xmatur, 100.0 - FF, 0.0, 0.0,
                             cal, eom, &hol, fill, df) ;
    }

    return disc ;
}


/*
************************************************************************
*
*               Boot_Parswap_Disc()
*
*   interface   #include <bootstrp.h>
*               BOOLE Boot_Parswap_Disc(FL64       pvFL,
*                                       DATESTR    *effect,
*                                       INTI       terms,
*                                       TERMUNIT   unit,
*                                       FL64       fix_rate,
*                                       PMTFREQ    freq,
*                                       CALCONV    cal,
*                                       EOMCONV    eom,
*                                       HOLI_STR   *holi,
*                                       BOOLE      fill,
*                                       DISCFAC    *df) ;
*
*   general     The function computes the discount factor implied by
*               a par swap.
*
*               Beyond generating the discount factor it is inserted
*               appropriately in the discount function. The discount
*               function must therefore be preallocated with sufficient
*               entries. If this is not the case the entry is not
*               inserted.
*
*               The use of this function will typically be within a
*               bootstrapping loop - in which the yield curve is
*               'stripped' by successively generating discount factors
*               from money market instruments - Deposits, Interest Rate
*               Futures, FRA's, Par Swaps and bonds.
*
*               The issue of credit quality of the individual securities
*               is handled via the spread. A nonzero spread implies that
*               the curve being bootstrapped is of a different credit
*               quality than this specific swap.
*               If the spread is positive the curve has better credit
*               quality than this swap, and if it is negative this swap
*               has better credit quality than the curve.
*
*               The design of a bootstrap driver is straightforward
*               and involves mainly sorting the securities according
*               to maturities and then - off course - loopcontrol.
*               See Boot_BSEC2DF() as an example.
*
*               When semiannually paying par swaps are used in the
*               bootstrapping, interpolation is used to get all the
*               intermediate - say 1.5 year - discount factors.
*               In doing this we do not comply with the Miron & Swannel
*               setup, pp. 104 - 8. Instead we adopt a more intuitive
*               scheme of simply interpolating the intermediate entries
*               given the new factor. For instance, say we guess on a
*               2 year discount factor, we then interpolate using the
*               lindisc parameter to get 1.5 year factor.
*               This is computationally more involved, and requires
*               Newton iterations, but more intuitive, since the 1.5
*               year semiannual swaprate is not observable anyway.
*               At any rate the differences are minimal.
*
*               If no solution was found then False returned, otherwise
*               True is returned.
*
*   input       FL64      pvFL     Floating side PV (usually 100)
*
*               DATESTR   *effect  The start date of the swap.
*
*               INTI      terms    Number of units till maturity.
*
*               TERMUNIT  unit     Unit of maturity quoting.
*
*               FL64      fix_rate The swap rate in percent.
*
*               FL64      spread   The spread from the rating implied
*                                  by the par rate to the rating of
*                                  the curve that is being bootstrapped.
*                                  The spread is an annually compounded
*                                  rate in %.
*
*               PMTFREQ   freq     The payment frequency - any value
*                                  except NO_FREQUENCY.
*
*               CALCONV   cal      The calendar convention.
*
*               EOMCONV   eom      The end of month convention.
*
*               HOLI_STR  *holi    Container for data on business
*                                  day convention and non-week-end
*                                  holidays.
*
*               BOOLE     fill     Fill all or not.
*
*               DISCFAC   *df      The discount function setup.
*                                  Must contain at least 2 observations,
*                                  one for today, with a discount factor
*                                  of unity, and one later.
*                                  The discount structure is updated in
*                                  the function.
*
*   output
*
*   returns     True if all is OK, False if not.
*
*   diagnostics
*
*   see also    Boot_MM_Disc()
*               Boot_FRA_Disc()
*               Boot_IRF_Disc()
*               Boot_Bond_Disc()
*               Boot_BSEC2DF()
*
************************************************************************
*/

BOOLE Boot_Parswap_Disc(FL64  pvFL,
                        DATESTR*   effect,
                        INTI      terms,
                        TERMUNIT  unit,
                        FL64      fix_rate,
                        FL64      spread,
                        PMTFREQ   freq,
                        CALCONV   cal,
                        EOMCONV   eom,
                        HOLI_STR*  holi,
                        BOOLE     fill,
                        DISCFAC*   df)
{
    DATESTR     ddate, today;
    SWAPFIX     sfix ;
    BOOLE       ok ;
    PERIOD      tenor ;

    /* Set swap data */
    ddate = df->disc->day[0] ;
    today = Cldr_NextBusinessDate(effect, holi) ;
    tenor = Set_PERIOD(terms, unit) ;
    sfix  = SwapFix_Simple2SWAPFIX(effect, &tenor, freq, fix_rate, cal, eom) ;

    /* Bootstrap */
    ok = Boot_Swap_Disc(pvFL, &today, &sfix, spread, holi, fill, df) ;

    return ok ;
}


/*
..
*/


BOOLE Boot_Swap_Disc(FL64   pvFL,
                     DATESTR*   PVdate,
                     SWAPFIX*   sfix,
                     FL64      spread,
                     HOLI_STR*  holi,
                     BOOLE     fill,
                     DISCFAC*   df)
{
    BOOLE    ok ;
    CFLW_STR *cflw ;

    /* Generate flow */
    cflw  = SwapFix_GenrCflw(sfix, holi) ;
    
    /* Bootstrap */
    ok = Boot_Cflw_Disc(pvFL, PVdate, cflw, spread, holi, fill, True, df) ;

    /* Clean up */
    Free_CFLWARRAY(cflw, 1) ;

    return ok ;
}


/*
************************************************************************
*
*               Boot_Bond_Disc()
*
*   interface   #include <bootstrp.h>
*               BOOLE Boot_Bond_Disc(DATESTR    *today,
*                                    DATESTR    *end,
*                                    FIXPAY     *fixp,
*                                    FL64       clean,
*                                    FL64       fwd,
*                                    FL64       spread,
*                                    HOLI_STR   *holi,
*                                    BOOLE      fill,
*                                    DISCFAC    *df) ;
*
*   general     The function returns the discount factor implied by
*               a standard bond.
*
*               Beyond generating the discount factor it is inserted
*               appropriately in the discount function. The discount
*               function must therefore be preallocated with sufficient
*               entries. If this is not the case the entry is not
*               inserted.
*
*               The use of this function will typically be within a
*               bootstrapping loop - in which the yield curve is
*               'stripped' by successively generating discount factors
*               from money market instruments - Deposits, Interest Rate
*               Futures, FRA's, Par Swaps and bonds.
*
*               The issue of credit quality of the individual securities
*               is handled via the spread. A nonzero spread implies that
*               the curve being bootstrapped is of a different credit
*               quality than this specific bond.
*               If the spread is positive the curve has better credit
*               quality than this bond, and if it is negative this bond
*               has better credit quality than the curve.
*
*               The design of a bootstrap driver is straightforward
*               and involves mainly sorting the securities according
*               to maturities and then - off course - loopcontrol.
*               See Boot_BSEC2DF() as an example.
*
*               If no solution was found then False is returned,
*               otherwise True is returned.
*
*   input       DATESTR   *today   Today
*
*               DATESTR   *end     Period end
*
*               FIXPAY    *fixp    Bond definition
*
*               FL64      clean    The clean price of the bond
*
*               FL64      fwd      The forward price of the bond
*
*               FL64      spread   The spread from the rating implied
*                                  by the price to the rating of
*                                  the curve that is being bootstrapped.
*                                  The spread is an annually compounded
*                                  rate in %.
*
*               HOLI_STR  *holi    Container for data on business
*                                  day convention and non-week-end
*                                  holidays.
*
*               BOOLE     fill     Fill all or not.
*
*               DISCFAC   *df      The discount function setup.
*                                  Must contain at least 2 observations,
*                                  one for today, with a discount factor
*                                  of unity, and one later.
*                                  The discount structure is updated in
*                                  the function.
*
*   output
*
*   returns     True if all is OK, False if not.
*
*   diagnostics
*
*   see also    Boot_MM_Disc()
*               Boot_FRA_Disc()
*               Boot_IRF_Disc()
*               Boot_Parswap_Disc()
*               Boot_BSEC2DF()
*
************************************************************************
*/


BOOLE Boot_Bond_Disc(DATESTR* today,
                     DATESTR*   end,
                     FIXPAY*    fixp,
                     FL64      clean,    /* Spot */
                     FL64      fwd,      /* Forward */
                     FL64      spread,
                     HOLI_STR*  holi,
                     BOOLE     fill,
                     DISCFAC*   df)
{
    BOOLE      ok ;
    CFLWARRAY  xcflw ;
    TRADEINFO  tr1, tr2 ;

    /* Generate Cashflow */
    tr1 = bond_set_tradeinfo(today) ;
    tr2 = bond_set_tradeinfo(end) ;
    tr2.price = fwd ;
    xcflw = Bond_GenrPeriod(&tr1, &tr2, fixp, holi) ;
    Cldr_Move2BusinessDays(xcflw->days, xcflw->filled, holi) ;

    /* Bootstrap */
    ok = Boot_Cflw_Disc(clean, today, xcflw, spread, holi, fill, False, df) ;

    /* Clean up */
    Free_CFLWARRAY(xcflw, 1) ;

    return ok ;
}

/*
..
*/

BOOLE Boot_SwapFut_Disc(INTI      term,
                        TERMUNIT  unit,
                        FL64      price,
                        FL64      spread,
                        PMTFREQ   freq,
                        CALCONV   cal,
                        EOMCONV   eom,
                        DATESTR*  delivery,
                        FL64      coupon,
                        HOLI_STR* holi,
                        BOOLE     fill,
                        DISCFAC*  df)
{
  BOOLE     ok;
  PERIOD    tenor;
  SWAPFIX   sfix;
 
  tenor = Set_PERIOD(term, unit);
  sfix  = SwapFix_Simple2SWAPFIX(delivery, &tenor, freq, coupon, cal, eom);

  ok = Boot_Swap_Disc(price, delivery, &sfix, spread, holi, fill, df);
  return ok;
}

/*
..
*/

BOOLE Boot_Cflw_Disc(FL64   pvX,
                     DATESTR*   PVdate,
                     CFLW_STR*  cflw,
                     FL64      spread,
                     HOLI_STR*  holi,
                     BOOLE     fill,
                     BOOLE     ignore,
                     DISCFAC*   df)
{
    FL64        rts, d1 ;
    BOOLE       ok ;
    FL64ARRAY   csdecomp ;
    INTI        i, nfix ;
    DATESTR     xmatur, ddate ;
    DISCFAC     tmpdisc ;
    DFSPREAD    dfs ;
    BOOTINT     boot_data ;
    ITERCTRL    ctrl ;
    NR_ERR      err ;

    dfs  = Set_DFSPREAD(spread, COMPOUND, ANNUALLY, NULL) ;
    nfix = cflw->filled ;
    ddate  = df->disc->day[0] ;
    if (nfix > 0)
        xmatur = Cldr_NextBusinessDate(&cflw->days[nfix - 1], holi) ;
    else
        return False ;

    /* Initialise for iterations */
    Init_ITERCTRL(&ctrl) ;
    ctrl.maxiter = PARSWAP_MAXIT ;
    ctrl.lower = 0.0 ;
    ctrl.upper = 1.0 ;
    ctrl.damp = 1.0 ;
    ctrl.acc = PARSWAP_ACC ;
    ctrl.what_acc = 1 ;
    ctrl.gfreq = 1 ;
    ctrl.bisec = 1 ;
    ctrl.shock = 0.0 ;
    
    if (GetPlanFill(df->disc) > 1)
    {
      tmpdisc = Set_DISCFAC(df->disc, DI_SPOT, LINEAR_FLAT_END, ACTACT,
        COMPOUND, ANNUALLY);
      ctrl.init_guess = Disc_Interpolation(&xmatur, &tmpdisc, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
    }
    else
      ctrl.init_guess  = 0.5 ;

    Cldr_InsertInPlan(&xmatur, ctrl.init_guess, df->disc, True) ;
    d1     = Disc_Interpolation(PVdate, df, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */

    boot_data = Boot_SetBOOTINT(pvX, cflw, d1, &xmatur, &ddate, df, 
      &tmpdisc, &dfs, ignore, PARSWAP_EPS) ;

    err = Newton_Raphson(&Boot_NewtonRaphson, &boot_data, &ctrl, &rts, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
    ok = (err == NR_ROOT_FOUND ? True : False) ;

    /* In this case insert all grid points */
    if (df->iconv == CUBIC_SPLINE || fill == True)
    {
        csdecomp = Disc_IntpolArray(cflw->days, nfix, df, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */

        for (i = 0 ; i < nfix ; i++)
            Cldr_InsertInPlan(&cflw->days[i], csdecomp[i], df->disc, True) ;

        Free_FL64ARRAY(csdecomp) ;
    }

    return ok ;
}

/*
..
*/

BOOTINT Boot_SetBOOTINT(FL64       pvX,
                           CFLW_STR*  cflw,
                           FL64       d1,
                           DATESTR*   xmatur, 
                           DATESTR*   ddate,
                           DISCFAC*   df,
                           DISCFAC*   tmpdisc,
                           DFSPREAD*  dfs,
                           BOOLE      ignore,
                           FL64       shock) 
{
  BOOTINT boot_data ;

  boot_data.pvX = pvX ;
  boot_data.cflw = cflw ;
  boot_data.d1 = d1 ;
  boot_data.xmatur = xmatur ;
  boot_data.ddate = ddate ;
  boot_data.df= df ;
  boot_data.tmpdisc = tmpdisc;
  boot_data.dfs = dfs;
  boot_data.ignore = ignore;
  boot_data.shock = shock ;

  return boot_data ;
}

/*
.. 
*/

void Boot_GetBOOTINT(BOOTINT*   boot_data,
                        FL64*       pvX,
                        CFLW_STR**  cflw,
                        FL64*       d1,
                        DATESTR**   xmatur, 
                        DATESTR**   ddate,
                        DISCFAC**   df,
                        DISCFAC**   tmpdisc,
                        DFSPREAD**  dfs,
                        BOOLE*      ignore, 
                        FL64*       shock)
{
  *pvX = boot_data->pvX ;
  *cflw = boot_data->cflw ;
  *d1 = boot_data->d1 ;
  *xmatur = boot_data->xmatur ;
  *ddate = boot_data->ddate ;
  *df= boot_data->df;
  *tmpdisc = boot_data->tmpdisc ;
  *dfs = boot_data->dfs ;
  *ignore = boot_data->ignore ;
  *shock = boot_data->shock ;
}

/*
..
*/

extern BOOLE Boot_NewtonRaphson(FL64      x, 
                                VOIDPTR   y,
                                BOOLE     grad,
                                FL64*     fx, 
                                FL64*     dfx,
								VOIDPTR   holiPtr)
{
  FL64      pvX, d1, shock, fx1 ;
  CFLW_STR  *cflw ;
  DATESTR   *xmatur, *ddate ;
  DISCFAC   *df, *tmpdisc ;
  DFSPREAD  *dfs ;
  BOOLE     ignore ;
  HOLI_STR  *holi = (HOLI_STR*) (holiPtr);

  /* Get data from y */
  Boot_GetBOOTINT((BOOTINT*)y, &pvX, &cflw, &d1, &xmatur,
    &ddate, &df, &tmpdisc, &dfs, &ignore, &shock) ;
  shock = ((shock <= 0.0) ? PARSWAP_EPS : shock) ;

  /* Compute fx */
  Cldr_InsertInPlan(xmatur, x, df->disc, True) ;
  *tmpdisc = Disc_Spread2DF(df, dfs, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
  *fx = Swap_DF2NPV(ddate, cflw, ignore, tmpdisc, holi) - pvX * d1 ;   /* PMSTA-22396 - SRIDHARA � 160502 */
  Free_PLANARRAY(tmpdisc->disc, 1) ;

  /* Compute gradient */
  if (grad == True)
  {
    Cldr_InsertInPlan(xmatur, x + shock, df->disc, True) ;
    *tmpdisc = Disc_Spread2DF(df, dfs, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
    fx1 = Swap_DF2NPV(ddate, cflw, ignore, tmpdisc, holi) - pvX * d1 ;    /* PMSTA-22396 - SRIDHARA � 160502 */
    Free_PLANARRAY(tmpdisc->disc, 1) ;
    Cldr_InsertInPlan(xmatur, x, df->disc, True) ;

    *dfx = (fx1 - *fx) / shock ;
  }

  return True ;
}

/*,,SOH,,
************************************************************************
*
*               Boot_BSEC2DF()
*
*   interface   #include <bootstrp.h>
*               BOOLE Boot_BSEC2DF(DATESTR    *start,
*                                  BSECARRAY  secs,
*                                  FL64ARRAY  prices,
*                                  FL64ARRAY  spread,
*                                  FL64ARRAY  madj,
*                                  FL64ARRAY  pricesX,
*                                  DATEARRAY  settle,
*                                  INTI       nsec,
*                                  HOLI_STR   *holi,
*                                  FILLTYPE   ftype,
*                                  INTI       low,
*                                  INTI       up,
*                                  DFPARMS    *dfp,
*                                  DISCFAC    *df) ;
*
*   general     The function computes the discount function implied by
*               a list of securities.
*
*               The function uses bootstrapping techniques to generate
*               the discount function. In doing so holidays, calendars
*               and other market conventions are respected.
*
*               Upon exit the first element in the discount function is
*               start with a discount factor 1.0.
*
*               Note that an IRF or FRA (IMMFRA) cannot be the first 
*               security in the list since these securities generates 
*               forward discount factors. This is NOT checked, so somewhat
*               silly discount functions are found if this restriction
*               is not complied with.
*
*               The issue of credit quality of the individual securities
*               is handled via the spread. A nonzero spread implies that
*               the curve being bootstrapped is of a different credit
*               quality than this specific bond.
*
*               If the spread is positive the curve has better credit
*               quality than this security, and if it is negative this
*               security has better credit quality than the curve.
*
*               If all securities are of equal credit quality then a
*               uniform spread of 0 would be appropriate. This curve
*               then reflects the discount function for this particular
*               credit quality.
*
*               Non-zero spreads are relevant when securities of mixed
*               credit/liquidity quality are mixed in the bootstrapping.
*               E.g. government bonds would trade at 0 spread, whereas
*               other types of securities would trade at a positive
*               spread against the treasury curve.
*
*               All treasuries need not, however, trade at 0 premium.
*               Less liquid bonds might trade at some premium.
*
*               So the spread is RELATIVE to the curve that is being
*               bootstrapped.
*
*               The function returns True if all is OK, and False if
*               not. If False is returned, all disc.factors up to
*               nfilled - 1 are OK.
*
*               The securities are sorted according to maturity as in
*               Boot_GenrIndex().
*
*               The routine handles individual settle periods. I.e some
*               contracts settle in 2 days and others 'today' or in 7
*               days. The resulting discount factors are anchored on
*               start.
*
*               When using individual settle days, it must be recalled
*               that some security must link the discount factors on
*               start to the factors on the settle days. Therefore a
*               cash (MM) instrument must be used to this purpose.
*               If no such instrument is available the start date must
*               be on the nearest settleday.
*
*               up/low are used for controlling restarting of the boot-
*               strapping. For the STANDARD setting use:
*
*                          low = 0
*                          up  = nsec - 1    (C-style indexation)
*
*               otherwise use the required bounds. If restarting is
*               used then be sure that df->disc is allocated correctly,
*               since this tasks is only performed in this routine in
*               the standard case.
*
*   input       DATESTR   *start   The start date for the disc.function
*
*               BSECARRAY secs     The list of securities to use for
*                                  bootstrapping (nsec securities).
*                                  Dimension [nsec]
*
*               FL64ARRAY prices   The list of prices for the securiti-
*                                  es in secs (nsec prices sorted
*                                  similarly). The prices are quoted as:
*
*                                     MM   - Annual rate (%)
*                                     FRA/IMMFRA  - Annual rate (%)
*                                     SWAP/SWAPGENR - Annual rate (%)
*                                     IRF  - Price (%)
*                                     BOND/BONDSMPL - Clean price (%)
*                                     AVGIRF - Futures Price (%)
*                                     BONDREPO - Bond spot price (%)
*                                     SWAPFUT - Futures price (%)
*
*                                  The bond future could be adjusted for
*                                  a conversion factor (CTD).
*                                  Dimension [nsec]
*
*               FL64ARRAY spread   The list of spreads for the securiti-
*                                  es in secs (nsec prices sorted
*                                  similarly). The spreads are quoted
*                                  as (%)
*
*                                  MM   - Annual Moneymarket rate
*                                  FRA/IMMFRA  - Annual Moneymarket rate
*                                  IRF  - Annual Moneymarket rate
*                                  SWAP/SWAPGENR - Ann compound rate
*                                  BOND/BONDSMPL - Ann compound rate
*                                  BONDREPO - Annually compounded
*
*                                  Enter NULL if not used (default is 0)
*                                  Dimension [nsec]|NULL
*
*               FL64ARRAY madj     Margin adjustment. Only used for an
*                                  IRF. List with nsec entries.
*                                  Calculate with Boot_*2MarginAdj().
*                                  Enter NULL if not used (default is 0)
*                                  Dimension [nsec]|NULL
*
*               FL64ARRAY pricesX  Extra price for some securities:
*
*                                     SWAP - FloatLeg PV. Default is 100
*                                     BONDREPO - Bond forward price
*                                                times Conversion Factor
*
*                                  List with nsec entries or NULL.
*                                  Dimension [nsec]|NULL
*
*               DATEARRAY settle   List of contract settlement dates.
*                                  Array with nsec entries.
*                                  Each security in secs may have an
*                                  individual settlement day (e.g 2 or
*                                  3 days in the future).
*                                  These days are not to be confused
*                                  with FRAsettlement etc, ie. the days
*                                  on which FRA/IRF's expire.
*                                  Any settle day must satisfy:
*
*                                       start <= settle[i]
*
*                                  Dimension [nsec]
*
*               INTI      nsec     The number of securities in prices,
*                                  spread, settle, madj and secs.
*
*               HOLI_STR  *holi    Container for data on business
*                                  day convention and non-week-end
*                                  holidays.
*
*               FILLTYPE  ftype    Definition of how to fill in extra
*                                  grid points.
*
*               INTI      low      Lower index for restarting.
*                                  Default is 0.
*                                  APL CALLS - ALWAYS 0.
*
*               INTI      up       Upper index for restarting
*                                  Default is nsec - 1.
*                                  APL CALLS - ALWAYS nsec - 1.
*
*               DFPARMS   *dfp     Definition of interpolation setup.
*
*   output      DISCFAC   *df      The discount function setup.
*                                  If NON-restarting is done then
*                                  the disc element is allocated in this
*                                  routine as:
*
*                                     disc = Alloc_PLANARRAY(1, count)
*
*                                  where count is a number returned in
*                                  disc[0].count.
*                                  The discount function is a
*                                  mathematical solution allowing
*                                  negative forward rates
*
*   returns     True if all is OK, False if not.
*
*   diagnostics
*
*   see also    Boot_GenrIndex()
*               Fit_BSEC2DF()
*               Boot_BH2MarginAdj()
*               Boot_PCPAR2MarginAdj()
*               Boot_LOG2MarginAdj()
*               SwapFix_BONDSWAPSPR2CFrate()
*               SwapFix_FUTSWAPSPR2CFrate()
*
*   wrapper     AP
*
************************************************************************
,,EOH,,*/

BOOLE Boot_BSEC2DF(DATESTR* start,
                   BSECARRAY  secs,
                   FL64ARRAY  prices,
                   FL64ARRAY  spread,
                   FL64ARRAY  madj,
                   FL64ARRAY  pricesX,
                   DATEARRAY  settle,
                   INTI       nsec,
                   HOLI_STR*   holi,
                   FILLTYPE   ftype,
                   INTI       low,
                   INTI       up,
                   DFPARMS*    dfp,
                   DISCFAC*    df)
{
    INTI      allocsize, i, j ;
    INTIARRAY index ;
    BUSCONV   bus ;
    BOOLE     ok ;
    CALCONV   cal ;
    FIXPAY    fixp ;
    EXRULE    xc ;
    FL64      pr, ma, spr, pvX, opr ;
    BOOLE     fill ;

    /* Initialize */
    df->what  = dfp->what ;
    df->iconv = dfp->iconv ;
    df->cal   = dfp->cal ;
    df->irr   = dfp->irr ;
    df->freq  = dfp->freq ;

    index = Boot_GenrIndex(secs, settle, nsec, holi) ;
    if (low == 0 && up == nsec - 1)
    {
        allocsize = Boot_Allocsize(start, secs, settle, nsec,
                                   df->iconv, ftype);
        df->disc  = Alloc_PLANARRAY(1, allocsize) ;
        Cldr_InsertInPlan(start, 1.0, df->disc, True) ;
    }

    bus = holi->bus ;
    cal = df->cal ;
    ok  = True ;

    /* Loop around securities to get the discount
       function for the i'th security */
    for (j = low ; j <= up && ok == True ; j++)
    {
        /* Get the right index */
        i = index[j] ;

        /* Do we have a price ? */
        if (Cldr_DateLT(&settle[i], start) == True || prices[i] <= 0.00001)
            continue ;

        /* The first security to be used must have settlement at start date */
        if (df->disc->filled == 1 && !Cldr_DateEQ(&settle[i], start))
          return False;

        /* Set business day method */
        holi->bus = secs[i].bus ;
        df->cal   = secs[i].cal_ipol ;

        /* Read fl64 array elmnts */
        pvX  = GetArrayEl(pricesX, i, nsec, 100.0) ;
        spr  = GetArrayEl(spread, i, nsec, 0.0) ;
        ma   = GetArrayEl(madj, i, nsec, 0.0) ;
        pr   = GetArrayEl(prices, i, nsec, 0.0) ;
        fill = Boot_Genr_Fill(secs[i].type, ftype) ;

        switch(secs[i].type)
        {
            case MM :

                Boot_MM_Disc(&settle[i], secs[i].irr, secs[i].term1,
                             secs[i].unit, pr, spr,
                             secs[i].cal, secs[i].eom, holi, fill, df) ;
                break ;

            case FRA :

                Boot_FRA_Disc(&settle[i], secs[i].term1, secs[i].term2,
                              secs[i].unit, pr, spr, secs[i].cal,
                              secs[i].eom, holi, fill, df, secs[i].nest) ;
                break ;


            case IMMFRA :

                Boot_IMMFRA_Disc(&secs[i].start, secs[i].term1,
                                 secs[i].unit, pr, spr, secs[i].cal,
                                 secs[i].eom, holi, fill, df) ;
                break ;

            case SWAP :

                ok = Boot_Parswap_Disc(pvX, &settle[i], secs[i].term1,
                                       secs[i].unit, pr, spr, secs[i].freq,
                                       secs[i].cal, secs[i].eom, holi, fill,
                                       df) ;
                break ;

            case SWAPGENR :

                opr = secs[i].sfix.fix.fix_rate ;
                secs[i].sfix.fix.fix_rate = pr ;

                /* Note that by using settle one can include seasoned
                   swaps in bootstrapping */
                ok = Boot_Swap_Disc(pvX, &settle[i], &secs[i].sfix, spr, holi, 
                                    fill, df) ;
                secs[i].sfix.fix.fix_rate = opr ;
                break ;

            case IRF :

                Boot_IRF_Disc(&secs[i].start, &secs[i].maturity, pr, spr, ma,
                              secs[i].cal, secs[i].eom, holi, fill, df) ;
                break ;

            case BOND:

                /* Use the fixp element */
                ok = Boot_Bond_Disc(&settle[i], &secs[i].fixp.cday.last,
                                    &secs[i].fixp, pr, 100.0,
                                    spr, holi, fill, df) ;
                break ;

            case BONDSMPL:

                /* Here we do not use the fixp element */
                xc = Set_EXRULE(EX_DAYS, secs[i].excdays, True,
                                secs[i].cal, &settle[i], 0,
                                &settle[i], &settle[i], False) ;
                fixp = Bond_Simple2FIXPAY(&settle[i], &secs[i].start,
                                          &secs[i].maturity, secs[i].coupon,
                                          secs[i].freq, BULLET, &xc, NULL,
                                          secs[i].cal, secs[i].eom) ;
                ok = Boot_Bond_Disc(&settle[i],  &secs[i].maturity,
                                    &fixp, pr, 100.0, spr, holi, fill, df) ;
                break ;

            case AVGIRF:

                Boot_AVGIRF_Disc(&secs[i].start, &secs[i].maturity,
                                 secs[i].term1, secs[i].unit, secs[i].curr_avg,
                                 pr, spr, secs[i].cal, secs[i].eom,
                                 holi, fill, df) ;

                break ;

            case BONDREPO:

                    ok = Boot_Bond_Disc(&settle[i], &secs[i].maturity,
                                        &secs[i].fixp, pr, pvX, spr, holi,
                                        fill, df) ;
                break ;

            case SWAPFUT:
                ok = Boot_SwapFut_Disc(secs[i].term1,
                                       secs[i].unit, pr, spr, secs[i].freq,
                                       secs[i].cal, secs[i].eom,
                                       &secs[i].maturity, secs[i].coupon, holi,
                                       fill, df) ;
                break ;
        }
    }

    holi->bus = bus ;
    df->cal   = cal ;

    /* Clean up and return */
    Free_INTIARRAY(index) ;

    return ok ;
}


/*
..
*/

INTI Boot_Allocsize(DATESTR* today,
                    BSECARRAY  secs,
                    DATEARRAY  settle,
                    INTI       nsec,
                    INTPOLCONV iconv,
                    FILLTYPE   ftype)
{
    INTI  mon, years, ann, n, i ;
    BOOLE fill ;

    fill = Boot_Genr_Fill(FRA, ftype) ;

    if (iconv == CUBIC_SPLINE || fill == True)
    {
        for (n = 1, i = 0 ; i < nsec ; i++)
        {
            /* Just 1 or 2 observations */
            if (secs[i].type == MM)
                n += 2 ;

            /* This is more subtle - assume that all paydays are 
               non-gridpoints */
            else if (secs[i].type == SWAP || secs[i].type == BONDSMPL ||
                     secs[i].type == BONDREPO || secs[i].type == BOND ||
                     secs[i].type == SWAPGENR)
            {
                /* Number of annual payments */
                if (secs[i].type == SWAP || secs[i].type == BONDSMPL)
                {
                    mon = Cflw_MonthsBetweenPayments(secs[i].freq) ;
                    ann = (mon > 0 ? 12 / mon : 12) ;
                }
                else if (secs[i].type == BONDREPO || secs[i].type == BOND)
                {
                    mon = secs[i].fixp.cday.pseq.term ;
                    ann = (mon > 0 ? 12 / mon : 12) ;
                }
                else
                {
                    mon = secs[i].sfix.pday.pseq.term ;
                    ann = (mon > 0 ? 12 / mon : 12) ;
                }
             
                ann = GETMAX(1, ann) ;

                /* Multiply this by the number of years till maturity */
                if (secs[i].type == SWAP)
                    years = secs[i].term1 ;
                else if (secs[i].type == BONDSMPL)
                    years = secs[i].maturity.y - today->y ;
                else if (secs[i].type == BONDREPO || secs[i].type == BOND)
                    years = secs[i].fixp.cday.last.y - today->y ;
                else
                    years = secs[i].sfix.pday.last.y - today->y ;

                years++ ;
                ann *= GETMAX(1, years) ;
                n   += ann ;

                if (secs[i].type == BONDREPO)
                    n += 2 ;
            }

            /* Here just take the max */
            else if (secs[i].type == FRA || secs[i].type == IRF ||
                     secs[i].type == AVGIRF)
                n += 2 ;
        }
    }

    else
    {
        for (n = 1, i = 0; i < nsec; i++)
        {
            if (secs[i].type != MM || Cldr_DateEQ(today, &settle[i]) == True)
                n++ ;
            else
                /* Beware of cash settled in the future */
                n += 2 ;
        }
    }

    return n ;
}



/*,,SOH,,
************************************************************************
*
*               Boot_DeltaPrep()
*
*   interface   #include <bootstrp.h>
*               DELTASET Boot_DeltaPrep(DATESTR    *start,
*                                        BSECARRAY  secs,
*                                        FL64ARRAY  prices,
*                                        FL64ARRAY  spread,
*                                        FL64ARRAY  madj,
*                                        FL64ARRAY  pricesX,
*                                        DATEARRAY  settle,
*                                        FL64ARRAY  shock,
*                                        INTI       nsec,
*                                        HOLI_STR   *holi,
*                                        FILLTYPE   ftype,
*                                        DISCFAC    *df,
*                                        BOOLE      *ok) ;
*
*   general     The function computes a number of shocked discount
*               factor curves to be used for delta vector calculation.
*
*               This functionality is a preprocessor for a delta-vector
*               calculation.
*
*               Basically each new curve is made by bootstrapping the
*               curve associated with the shock to the i'th security.
*
*               For another type of shock see Disc_DeltaPrep()
*
*               The delta vector calculated here cannot be used for
*               Risk Position (VAR) calculations (*_*2RiskPos()).
*
*   input       DATESTR   *start   The start date for the disc.function
*
*               BSECARRAY secs     The list of securities to use for
*                                  bootstrapping (nsec securities).
*
*               FL64ARRAY prices   The list of prices for the securiti-
*                                  es in secs (nsec prices sorted
*                                  similarly). The prices are quoted as:
*
*                                     MM   - Annual rate (%)
*                                     FRA/IMMFRA - Annual rate (%)
*                                     SWAP/SWAPGENR - Annual rate (%)
*                                     IRF  - Price (%)
*                                     BOND/BONDSMPL - Clean price (%)
*                                     AVGIRF - Futures Price (%)
*                                     BONDREPO - Bond spot price (%)
*
*                                  The bond future could be adjusted for
*                                  a conversion factor (CTD).
*
*               FL64ARRAY spread   The list of spreads for the securiti-
*                                  es in secs (nsec prices sorted
*                                  similarly). The spreads are quoted
*                                  as (%)
*
*                                   MM   - Annual Moneymarket rate
*                                   FRA/IMMFRA - Annual Moneymarket rate
*                                   IRF  - Annual Moneymarket rate
*                                   SWAP/SWAPGENR - Ann compound rate
*                                   BOND/BONDSMPL - Ann compound rate
*                                   BONDREPO - Annually compounded
*
*                                  Enter NULL if not used (default is 0)
*
*               FL64ARRAY madj     Margin adjustment. Only used for an
*                                  IRF. List with nsec entries.
*                                  Calculate with Boot_BH2MarginAdj().
*                                  Enter NULL if not used (default is 0)
*
*               FL64ARRAY pricesX  Extra price for some securities:
*
*                                     SWAP - FloatLeg PV. Default is 100
*                                     BONDREPO - Bond forward price
*                                                times Conversion Factor
*
*                                  List with nsec entries or NULL.
*
*               DATEARRAY settle   List of contract settlement dates.
*                                  Array with nsec entries.
*                                  Each security in secs may have an
*                                  individual settlement day (e.g 2 or
*                                  3 days in the future).
*                                  These days are not to be confused
*                                  with FRAsettlement etc, ie. the days
*                                  on which FRA/IRF's expire.
*                                  Any settle day must satisfy:
*
*                                       start <= settle[i]
*
*               FL64ARRAY shock    List of security dependent shocksize.
*                                  Percentage term. Interpret as:
*
*                                     MM   - Rate shock
*                                     FRA/IMMFRA - Rate shock
*                                     IRF  - Price shock
*                                     SWAP/SWAPGENR - Rate shock
*                                     BOND/BONDSMPL - Price shock
*                                     BONDREPO - Price shock
*                                     AVGIRF   - Price shock
*
*               INTI      nsec     The number of securities in prices
*                                  settle, secs and shock
*
*               HOLI_STR  *holi    Container for data on business
*                                  day convention and non-week-end
*                                  holidays.
*
*               FILLTYPE  ftype    Definition of how to insert extra
*                                  gridpoints.
*
*               DISCFAC   *df      The discount function setup.
*                                  The disc must at entry be set equal
*                                  to the ORIGINAL (i.e nonshocked)
*                                  discount function.
*
*   output      BOOLE     *ok      True if all OK , False if not.
*
*   returns     DELTASET ds defined as:
*               ds.shock: Shocked discount function setup allocated as:
*
*                         Alloc_PLANARRAY(nsec, allocsize) ;
*
*               holding all the shocked discount factor curves.
*               ds.nshock  = nsec
*               ds.dom     = ds.zero = False
*               ds.dfwhich = DF_BOTH
*               ds.mid     = NULL
*               ds.token   = NULL
*               ds.size    = NULL
*
*   diagnostics
*
*   see also    Boot_BSEC2DF()
*               Disc_DeltaPrep()
*
************************************************************************
,,EOH,,*/

DELTASET Boot_DeltaPrep(DATESTR* start,
                         BSECARRAY  secs,
                         FL64ARRAY  prices,
                         FL64ARRAY  spread,
                         FL64ARRAY  madj,
                         FL64ARRAY  pricesX,
                         DATEARRAY  settle,
                         FL64ARRAY  shock,
                         INTI       nsec,
                         HOLI_STR*  holi,
                         FILLTYPE   ftype,
                         DISCFAC*   df,
                         BOOLE*     ok)
{
    PLANARRAY tmp, old, dfs ;
    INTI      j, i, allocsize ;
    DFPARMS   dfp ;
    DELTASET  ds ;

    dfp = Set_DFPARMS(df->what, df->iconv, df->cal, df->irr, df->freq) ;
    ds  = Set_DELTASET(NULL, nsec, False, DF_BOTH, False, NULL, NULL, 
                       COMPOUND, ANNUALLY, NULL) ;

    allocsize = Boot_Allocsize(start, secs, settle, nsec, df->iconv, ftype) ;
    ds.shock  = dfs = Alloc_PLANARRAY(nsec, allocsize) ;

    if (nsec <= 0)
        return ds ;

    old = Alloc_PLANARRAY(1, GetPlanFill(df->disc)) ;
    tmp = df->disc ;

    for (j = 0; j < GetPlanFill(df->disc); j++)
    {
         old->day[j] = df->disc->day[j] ;
         old->f64[j] = df->disc->f64[j] ;
    }

    for (i = nsec - 1; *ok == True && i >= 0; i--)
    {
        if (prices[i] >= 0.00001)
        {
            prices[i] += shock[i] ;
            *ok = Boot_BSEC2DF(start, secs, prices, spread, madj, pricesX,
                               settle, nsec, holi, ftype, i, nsec - 1, 
                               &dfp, df) ;
            prices[i] -= shock[i] ;
        }

        for (j = 0 ; j < GetPlanFill(df->disc); j++)
        {
             dfs[i].day[j] = df->disc->day[j] ;
             dfs[i].f64[j] = df->disc->f64[j] ;
        }

        dfs[i].filled = GetPlanFill(df->disc) ;

        /* Note that df->disc is NOT freed here because the bootstrapping
           is made in a restarting fashion - i.e. without allocating memory.
           Except in a particular case - which is: */
        if (i == 0 && prices[i] > 0.00001)
        {
            Free_PLANARRAY(df->disc, 1) ;
            df->disc = tmp ;
        }
    }

    for (j = 0; j < GetPlanFill(df->disc); j++)
    {
         df->disc->day[j] = old->day[j] ;
         df->disc->f64[j] = old->f64[j] ;
    }

    Free_PLANARRAY(old, 1) ;

    return ds ;
}


/*,,SOH,,
************************************************************************
*
*               Boot_LOG2MarginAdj()
*
*   interface   #include <bootstrp.h>
*               FL64ARRAY Boot_LOG2MarginAdj(DATESTR   *start,
*                                            BSECARRAY bsec,
*                                            DATEARRAY settle,
*                                            INTI      nsec,
*                                            DISCFAC   *df,
*                                            VOL_STR   *vol,
*                                            FL64      corrfac,
*                                            HOLI_STR  *holi)
*
*   general     The function computes the Margin Adjustment sometimes
*               needed for Interest Rate Futures when bootstrapping.
*
*               The model employed is an analytical expression for the
*               forward adjustment based on the volatilities of the
*               individual forwards and their correlation.
*
*               The benefits of this model is that the vols can be taken
*               directly from market data (i.e. FORWFORW cap/floor vols)
*
*               The only non-market data that enters is the correlation
*               factor (a usuful value could be between 0.9 and 0.95).
*               The factor expres the correlation (0 <= * <= 1) between
*               adjacent forwards. I.e. the correlation between fwd(i)
*               and fwd(j) is corrfac to the power of abs(i - j).
*               In this way fairly realistic correlation matrices can
*               be derived.
*
*   input       DATESTR   *start   The analysis date
*
*               BSECARRAY bsec     The list of securities to use for
*                                  bootstrapping (nsec securities).
*
*               DATEARRAY settle   List of contract settlement dates.
*                                  Array with nsec entries.
*                                  Any settle day must satisfy:
*
*                                       start <= settle[i]
*
*               INTI      nsec     The number of securities in bsec
*
*               DISCFAC   *df      Discount factor curve.
*                                  E.g. based on UNadjusted futures.
*                                  Used to finds forward rates.
*
*               VOL_STR   *vol     Vols of forward rates.
*                                  E.g. Cap/Floor FORWFORW vols.
*
*               FL64      corrfac  Correlation factor.
*                                  Correlation between adjacent forwards
*
*               HOLI_STR  *holi    Business day adjustment setup.
*
*   output
*
*   returns     List of Margin Adjustment's for all securities, 0 if
*               not an IRF. Set as a rate change in percent.
*               Allocated in the routine as Alloc_FL64ARRAY(nsec).
*
*   diagnostics
*
*   see also    Boot_BSEC2DF()
*
************************************************************************
,,EOH,,*/

/*,,SIC,,
Literature reference:
 Internal FRD note: JAS-96-10, "Margin Adjustment of Futures",
                    articles/jas/margadj.tex
,,EIC,,*/
FL64ARRAY Boot_LOG2MarginAdj(DATESTR* start,
                             BSECARRAY  bsec,
                             DATEARRAY  settle,
                             INTI       nsec,
                             DISCFAC*    df,     /* Used to find fwd rates */
                             VOL_STR*    vol,    /* FORWFORW vol */
                             FL64       corrfac, /* 0 < * <= 1 */  
                             HOLI_STR*   holi)
{
    FL64      cum ;
    COUNT     ix ;
    INTI      i ;
    FL64ARRAY madj ;
    INTIARRAY index ;
    FL64      t1, fac, alfai, voli, Ti, volk, Tk, Li, Lk, rik ;
    INTI      months ;
    BOOLE     notf ;
    DATESTR   IRFstart, IRFend ;

    madj  = Alloc_FL64ARRAY(nsec) ;
    index = Boot_GenrIndex(bsec, settle, nsec, holi) ;

    /* Loop to calculate margin adjustment */
    for (cum = 0.0, ix = 0; ix < nsec; ix++)
    {
        i = index[ix] ;

        /* Only adjust futures */
        if (bsec[i].type != IRF || ix == 0)
            continue ;

        /* Loop to find adjustment */
        notf     = True ;
        IRFstart = bsec[i].start ;
        IRFend   = bsec[i].maturity ;
        t1       = Cldr_TermBetweenDates(&IRFstart, &IRFend,
                                         12, EU30E360, LAST, holi) ;   /* PMSTA-22396 - SRIDHARA � 160502 */
        months   = (INTI) (t1 + 0.5) ;
        cum      = 0.0 ;

        /* Find values at maturity */
        Tk    = Cldr_TermBetweenDates(start, &IRFstart, 0, EU30E360, LAST, holi) ;   /* PMSTA-22396 - SRIDHARA � 160502 */
        volk  = Vol_Interpolation(&IRFstart, vol, holi) / 100.0 ;   /* PMSTA-22396 - SRIDHARA � 160502 */
        Lk    = Disc_DF2ForwRate(&IRFstart, &IRFend, bsec[i].cal, df,     
                                SIMPLE_MM, ANNUALLY, holi) / 100.0 ;   /* PMSTA-22396 - SRIDHARA � 160502 */
        rik   = 1.0 ;

        while (notf == True)
        {
			/* PMSTA-22396 - SRIDHARA � 160502 */
            alfai = Cldr_TermBetweenDates(&IRFstart, &IRFend,
                                          0, EU30E360, LAST, NULL) ;
            Li    = Disc_DF2ForwRate(&IRFstart, &IRFend, bsec[i].cal, df, 
                                    SIMPLE_MM, ANNUALLY, holi) / 100.0 ;
            voli  = Vol_Interpolation(&IRFstart, vol, holi) / 100.0 ;
            Ti    = Cldr_TermBetweenDates(start, &IRFstart, 0, EU30E360, LAST, NULL);

            /* Accumulate adjustment */
            fac  = alfai * Li ;
            cum += fac * sqrt(Ti) * voli * rik / (1.0 + fac) ;

            /* Here we ignore IMM effects etc */
            IRFend   = IRFstart ;
            IRFstart = Cldr_AddMonths(&IRFstart, - months, bsec[ix].eom) ;
            rik     *= corrfac ;

            if (Cldr_DateLE(&IRFstart, start) == True)
                notf = False ;
        }

        /* Multiply with rate st.dev */
        cum    *= sqrt(Tk) * volk * Lk ;
        madj[i] = cum * 100.0 ;
    }

    Free_INTIARRAY(index) ;

    return madj ;
}


/*,,SOH,,
************************************************************************
*
*               Boot_BH2MarginAdj()
*
*   interface   #include <bootstrp.h>
*               FL64ARRAY Boot_BH2MarginAdj(DATESTR   *start,
*                                           BSECARRAY bsec,
*                                           DATEARRAY settle,
*                                           INTI      nsec,
*                                           VOL_STR   *zvol,
*                                           VOL_STR   *fvol,
*                                           PLAN_STR  *corr,
*                                           HOLI_STR  *holi)
*
*   general     The function computes the Margin Adjustment sometimes
*               needed for Interest Rate Futures when bootstrapping.
*
*               The model employed is the Burghardt/Hoskins approach.
*
*               In order to calculate the adjustment 3 data are required
*
*                  Zero Rate Volatilities:
*                  These are the standard deviation of absolute changes
*                  of the CONTINUOUS Zero Rates.
*                  If this vol is quoted as Annually Compounded rates
*                  is should be scaled with 1/(1+r), where r is the
*                  relevant annually compounded spot rate.
*
*                  Forward Rate Volatilities:
*                  These are the standard deviation of absolute changes
*                  of the Forward Rates (Rates implied from IRF's).
*
*                  Correlations between Forward and Zero Rates:
*                  Typically this piece of data is pretty close to 1
*                  (0.93 - 0.99).
*
*               Burghardt/Hoskins have done Historical Estimations for
*               these data (CME). A quick fudge that brings the margin
*               adjustment within 1bp of the Burghardt/Hoskins data out
*               till 10 years is to let:
*
*                  Zero Rate Volatilities:     1.12
*                  Forward Rate Volatilities:  1.12
*                  Correlations between Forward and Zero Rates: 0.95
*
*               If the last future is at 5 Years a fudge would be:
*               (approximating B/H data within 0.5bp).
*
*                  Zero Rate Volatilities:     1.16
*                  Forward Rate Volatilities:  1.16
*                  Correlations between Forward and Zero Rates: 0.98
*
*               This should be quite sufficient for most purposes con-
*               sidering the uncertainty in estimating the numbers
*               involved in the first place. However, be aware that the
*               vols may change over time.
*
*   input       DATESTR   *start   The start date for the disc.function
*
*               BSECARRAY bsec     The list of securities to use for
*                                  bootstrapping (nsec securities).
*
*               DATEARRAY settle   List of contract settlement dates.
*                                  Array with nsec entries.
*                                  Any settle day must satisfy:
*
*                                       start <= settle[i]
*
*               INTI      nsec     The number of securities in bsec
*
*               VOL_STR   *zvol    Standard deviation of absolute
*                                  changes in Zero Rates.
*                                  Quoted on the futures start date.
*
*               VOL_STR   *fvol    Standard deviation of absolute
*                                  changes in Zero Rates.
*                                  Quoted on the futures start date.
*
*               PLAN_STR  *corr    Correlations between fvol's and
*                                  zvol's.
*                                  Quoted on the futures start date.
*
*               HOLI_STR  *holi    Business day adjustment setup.
*
*   output
*
*   returns     List of Margin Adjustment's for all securities, 0 if
*               not an IRF. Set as a rate change in percent.
*               Allocated in the routine as Alloc_FL64ARRAY(nsec).
*
*   diagnostics
*
*   see also    Boot_BSEC2DF()
*
************************************************************************
,,EOH,,*/

/*,,SIC,,
Literature reference:
 Burghardt & Hoskins: "A Question of Bias", RISK March 1995
,,EIC,,*/
FL64ARRAY Boot_BH2MarginAdj(DATESTR* start,
                            BSECARRAY bsec,
                            DATEARRAY settle,
                            INTI      nsec,
                            VOL_STR*   zvol,
                            VOL_STR*   fvol,
                            PLAN_STR*  corr,
                            HOLI_STR*  holi)
{
    FL64      t1, cum ;
    COUNT     ix ;
    BOOLE     after, M3 ;
    INTI      i1, i, months ;
    DATESTR   tmp, end ;
    FL64ARRAY madj ;
    INTIARRAY index ;

    madj  = Alloc_FL64ARRAY(nsec) ;
    index = Boot_GenrIndex(bsec, settle, nsec, holi) ;

    /* A 'pure' 3M Futures Strip ? - Speed enhancement if True */
    for (after = False, M3 = True, ix = 0; M3 == True && ix < nsec; ix++)
    {
        i = index[ix] ;

        if (ix == 0)
        {
            if (bsec[i].type != MM)
                M3 = False ;

            continue ;
        }

        if (bsec[i].type == IRF)
            t1 = Cldr_TermBetweenDates(&bsec[i].start, &bsec[i].maturity,
                                       12, EU30E360, LAST, NULL) ;   /* PMSTA-22396 - SRIDHARA � 160502 */
        else
            t1 = 0.0 ;

        /* Chk for back 2 back IRF Strip */
        months = (INTI) (t1 + 0.5) ;

        if (bsec[i].type == IRF && months == 3)
        {
            if (after == True)
            {
                M3 = False ;
                continue ;
            }

            if (ix == 1)
            {
                /* Match MMduration end date */
                i1  = index[0] ;
                end = Boot_Genrmaturity(&settle[i1], &bsec[i1], holi) ;

                if (Cldr_DateEQ(&bsec[i].start, &end) == False)
                    M3 = False ;

                /* This is a proxy - should work 'almost' always */
                tmp = Cldr_AddMonths(&bsec[i].start, - months, bsec[i].eom) ;
                if (Cldr_DateLE(start, &tmp) == True && bsec[i1].unit != DAYS)
                    M3 = False ;
            }
            else
            {
                i1 = index[ix - 1] ;

                /* Match previous end date */
                if (Cldr_DateEQ(&bsec[i].start, &bsec[i1].maturity) == False)
                    M3 = False ;
            }
        }
        else
        {
            after = True ;
            if (bsec[i].type == IRF)
                M3 = False ;
        }
    }

    /* Loop to calculate margin adjustment */
    for (cum = 0.0, ix = 0; ix < nsec; ix++)
    {
        i = index[ix] ;

        /* Only adjust futures */
        if (bsec[i].type != IRF || ix == 0)
            continue ;

        /* Accumulate futures drift */
        if (M3 == True)
            /* This is the standard strip */
            cum += Boot_Margin_Drift_IRF(start, bsec, i, zvol, fvol, corr,
                                         False) ;
        else
            cum = Boot_Margin_Drift_IRF(start, bsec, i, zvol, fvol, corr, 
                                        True) ;

        madj[i] = cum / 100.0 ;
    }

    Free_INTIARRAY(index) ;

    return madj ;
}


/*
..
*/


FL64 Boot_Margin_Drift_IRF(DATESTR* start,
                           BSECARRAY bsec,
                           INTI      ix,
                           VOL_STR*   zvol,
                           VOL_STR*   fvol,
                           PLAN_STR*  corr,
                           BOOLE     doall)
{
    FL64    t1, t, sv, sz, fv, ro, madj ;
    INTI    months ;
    BOOLE   notf ;
    DATESTR IRFstart ;

    if (bsec[ix].type != IRF)
        return 0.0 ;

    notf     = True ;
    IRFstart = bsec[ix].start ;
    t1       = Cldr_TermBetweenDates(&IRFstart, &bsec[ix].maturity,
                                     12, EU30E360, LAST, NULL) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
    months   = (INTI) (t1 + 0.5) ;
    madj     = 0.0 ;

    while (notf == True)
    {
        t = Cldr_TermBetweenDates(start, &IRFstart, 0, EU30E360, LAST, NULL) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */

        /* Here we use continuous rates - thereby the modified duration
           of a zero note is its term. */
        t    += ((FL64) months) / (2.0 * 12.0) ;
		/* PMSTA-22396 - SRIDHARA � 160502 */
        sv    = Vol_Interpolation(&IRFstart, zvol, NULL) ;
        sz    = t * sv ;
        fv    = Vol_Interpolation(&IRFstart, fvol, NULL) ;
        ro    = Cldr_Plan_Intpol(&IRFstart, corr, bsec[ix].cal, 
                                 LINEAR_FLAT_END, NULL) ;
        madj += ((FL64) months) * fv * sz * ro / 12.0 ;

        /* Here we ignore IMM effects etc */
        IRFstart = Cldr_AddMonths(&IRFstart, - months, bsec[ix].eom) ;

        if (doall == False || Cldr_DateLE(&IRFstart, start) == True)
            notf = False ;
    }

    return madj ;
}


/*,,SOH,,
************************************************************************
*
*               Boot_BlendDF()
*
*   interface   #include <bootstrp.h>
*               DISCFAC Boot_BlendDF(PLANARRAY   disc,
*                                     INTI        ndisc,
*                                     DFPARMS     *dfp,
*                                     PERIODARRAY period,
*                                     INTI        nperiod,
*                                     FL64MATRIX  weight,
*                                     DATEARRAY   dates,
*                                     INTI        ndates,
*                                     DFPARMS     *what) ;
*
*   general     The function bends a number of Discoutn Factor curves
*               according to a number of different conventions.
*
*               An example blending scheme is:
*
*               Period    MM-Curve FRA-Curve IRF-Curve Swap-Curve
*               -------------------------------------------------
*               1Y          0.3       0.3       0.3        0.1
*               2Y          0.0       0.0       0.3        0.7
*               3Y          0.0       0.0       0.3        0.7
*               4Y          0.0       0.0       0.3        0.7
*               5Y          0.0       0.0       0.3        0.7
*               6Y          0.0       0.0       0.0        1.0
*               7Y          0.0       0.0       0.0        1.0
*               8Y          0.0       0.0       0.0        1.0
*               9Y          0.0       0.0       0.0        1.0
*               10Y         0.0       0.0       0.0        1.0
*
*   input       PLANARRAY   disc    The list of DF's. ndisc curves.
*                                   First date in all curves assumed
*                                   to be the same.
*
*               INTI        ndisc   No. of curves in disc
*
*               DFPARMS     *dfp    Parameters for ALL DF's in disc.
*
*               PERIODARRAY period  Definition of blending periods.
*                                   Last period end after last date
*
*               INTI        nperiod No. of blending periods (period)
*
*               FL64MATRIX  weight  The weighting scheme for the blend:
*                                   nperiod rows and ndisc columns.
*                                   Each row must sum to 1.0
*
*               DATEARRAY   dates   List of dates for the output curve
*
*               INTI        ndates  No. of elements in dates.
*
*               DFPARMS     *what   How to blend:
*                                   ->what - in what to blend.
*                                   ->cal  - calendar for blending
*                                   ->irr  - rate conv for blending
*                                   ->freq - quoting of irr
*
*   output
*
*   returns     The blended Zero Curve (DF). The disc is allocated as:
*
*                         Alloc_PLANARRAY(1, 1 + ndates) ;
*
*   diagnostics
*
*   see also    Boot_BSEC2DF()
*               Disc_DeltaPrep()
*
************************************************************************
,,EOH,,*/

DISCFAC Boot_BlendDF(PLANARRAY disc,
                      INTI        ndisc,
                      DFPARMS*     dfp,      /* Quoting of disc's */
                      PERIODARRAY period,
                      INTI        nperiod,
                      FL64MATRIX  weight,    /* nperiod x ndisc */
                      DATEARRAY   dates,
                      INTI        ndates,
                      DFPARMS*     what)     /* cal, what  irr, qbas used */
{
    DISCFAC   df ;
    INTI      ix, i, j, qb, ip  ;
    FL64      bl, blvar, term, dset ;
    PLANARRAY dnew ;
    DATESTR   end, prev, next, start ;
    HOLI_STR  holi ;

    /* Allocate output array */
    dnew = Alloc_PLANARRAY(1, 1 + ndates) ;

    if (ndisc < 1 || GetPlanFill(disc)< 1 || nperiod < 1)
    {
        df = Set_DISCFAC(dnew, dfp->what, dfp->iconv,
                              dfp->cal, dfp->irr, dfp->freq) ;
        return df ;
    }

    /* First date in DF */
    start = prev = disc->day[0] ;
    dset  = 1.0 ;
    qb    = disc_set_qbas(what->freq) ;

    /* Insert first point */
    Cldr_InsertInPlan(&start, 1.0, dnew, True) ;

    /* Find first relevant date in the list */
    ix = Cldr_FindDateIndex(dates, ndates, &start, 0,
                             SEARCH_FORWARDS, NEXTINDEX) ;

    holi = Set_HOLI_STR(NO_BUSADJUST, 0, NULL) ;

    /* Loop over output dates and do the blending */
    for (ip = 0, i = ix; i < ndates; i++)
    {
        /* Set period end */
        next = dates[i] ;

        end = Cldr_AddPeriod(&start, &period[ip], dfp->cal, LAST, &holi) ;
        if (Cldr_DateLT(&end, &next) == True)
            ip++ ;

        ip = GETMIN(nperiod - 1, ip) ;

        /* Do the blending */
        for (bl = term = 0.0, j = 0; j < ndisc; j++)
        {
            df = Set_DISCFAC(&disc[j], dfp->what, dfp->iconv,
                                  dfp->cal, dfp->irr, dfp->freq) ;

            if (what->what != DI_FORW)
            {
                blvar = Disc_Interpolation(&next, &df, &holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */

                if (what->what == DI_SPOT)
                {
                    term  = Cldr_TermBetweenDates(&start, &next, 0, what->cal,
                                                  LAST, &holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
                    blvar = TVMunit_Yield(blvar, term, what->irr, qb) ;
                }
                else if (what->what == DI_GROWTH && fabs(blvar) > ZERO_TOL)
                    blvar = 1.0 / blvar ;
            }
            else
            {
                term  = Cldr_TermBetweenDates(&prev, &next, 0, 
                                              what->cal, LAST, &holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
                blvar = Disc_DF2ForwRate(&prev, &next, what->cal, &df,
                                        what->irr, what->freq, &holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
            }

            /* Now blend */
            bl += weight[ip][j] * blvar ;
        }

        if (what->what == DI_SPOT)
            dset = TVMunit_NPV(term, bl, what->irr, qb) ;

        else if (what->what == DI_DISC)
            dset = bl ;

        else if (what->what == DI_FORW)
            dset *= TVMunit_NPV(term, bl, what->irr, qb) ;

        else if (what->what == DI_GROWTH && fabs(bl) > ZERO_TOL)
            dset = 1.0 / bl ;

        /* Set new DF entry */
        Cldr_InsertInPlan(&dates[i], dset, dnew, True) ;

        /* Prepare for next loop */
        prev = next ;
    }

    /* Return */
    df = Set_DISCFAC(dnew, dfp->what, dfp->iconv,
                          dfp->cal, dfp->irr, dfp->freq) ;

    return df ;
}


/*,,SOH,,
***********************************************************************
*                                                                      
*               Boot_GenrEquiShock()                                 
*                                                                      
*   interface   #include <bootstrp.h>                                
*               FL64ARRAY Boot_GenrEquiShock(BSECARRAY bsec, 
*                                            INTI      nsec,
*                                            FL64ARRAY prices, 
*                                            CALCONV   cal,
*                                            PMTFREQ   freq, 
*                                            FL64      delta, 
*                                            DATESTR*  start, 
*                                            BOOLE*    ok);
*                                                                      
*   general     This routine computes equivalent shocks in market
*               quotes of bootstrap securities.
*
*               Equivalent shocks are computed by transforming
*               delta into shock that quoted in the same way
*               as the market quotes. The equivalent shock of a
*               1 month deposit using a 1 bp shock in the quartly 
*               interest rates is computed by compounding the 
*               1 month deposit rate into a 3 month rate which is then 
*               shocked by delta. The computed shock is then 
*               decompounded back to a 1 month rate.
*                                                                      
*               This is usefull if you want the bootstrap a curve
*               where a particular interest rate is shocked.
*                                                                      
*   input       BSECARRAY  bsec    The bootstrap securities.
*                                  Note that bsec[ix].type must be 
*                                  either MM, FRA, IRF, SWAP or 
*                                  BOND.
*                                        
*               INTI       nsec    Number of BSEC's in bsec
*                                                                      
*               FL64ARRAY  prices  Market quotes on the bootstrap
*                                  securities.
*                                                                      
*               CALCONV    cal     This calendar is used to determine
*                                  the year fraction of a single period
*                                  implied by freq (QUARTERLY implies a
*                                  3 months period)
*                                                                      
*               PMTFREQ    freq    Compounding frequency of the shock.
*                                  QUARTERLY means that the 3 months 
*                                  interest rates is shocked by delta.
*                                            
*               FL64       delta   Interest Rate shock quoted in basis
*                                  points. Enter 1.0 for a 1 bp shock.
*                                                                      
*               DATESTR*   start   The start of the period for the
*                                  interest rate to be shocked.
*                                  This, together with cal and freq, is
*                                  used to compute a day-count fraction
*                                  used when translating from the
*                                  shocked interest rate to other
*                                  interest rates.
*                                                               
*   output      BOOLE      *ok     The computation faile
*                                  This happens only if yield 
*                                  calculation for bonds using 
*                                  TVM_YieldByFormula() fails.
*                                                                      
*   returns     An array of shocks. The shocks are quoted in % of the
*               market quotes, ie in basis points. The array is 
*               allocated using
*                           Alloc_FL64ARRAY(nsec) ;
*                                                     
*   diagnostics                                                        
*                                                                      
*   see also    TVM_YieldByFormula()
*               Boot_DeltaPrep()
*               Boot_BSEC2DF()
*                                                                      
***********************************************************************
,,EOH,,*/

FL64ARRAY Boot_GenrEquiShock(BSECARRAY  bsec, 
                                INTI  nsec, 
                                FL64ARRAY  prices, 
                                CALCONV  cal, 
                                PMTFREQ  freq, 
                                FL64  delta, 
                                DATESTR*  start, 
                                BOOLE*  ok)
{
    FL64    delta_y, dpy1, dpy3, t1, t3,
            y1, y3 = 0, d1, d3, dp, tm, ai, df, dum, tdelta ;
    INTI    months, idx ;
    DATESTR start1, end1, end3 ;
    FL64ARRAY res;
    HOLI_STR holi ;

    res = Alloc_FL64ARRAY(nsec);
    *ok = True;

    /* We need this trivial holi_str ... */
    holi.nholi = 0 ;
    holi.bus = NO_BUSADJUST ;

    /* Note that business adjustment is ignored */

    months = Cflw_MonthsBetweenPayments(freq) ;
    end3   = Cldr_TermUnit2Date(start, months, MONTHS, cal, SAME, 
                                &holi) ;
	  	/* PMSTA-22396 - SRIDHARA � 160502 */
    d3     = (FL64) Cldr_DaysBetweenDates(start, &end3, cal, &holi) ;
    dpy3   = Cldr_DaysPerYear(start, &end3, 0, cal, SAME, &holi) ;
    t3     = d3 / dpy3 ;


    for (idx = 0; *ok && idx < nsec; idx++)
    {
        tdelta = delta;
        switch(bsec[idx].type)
        {
        case MM:
            /* Find equivalent freq-duration yield */
            end1 = Cldr_TermUnit2Date(start, bsec[idx].term1,
                                         bsec[idx].unit,
                                         bsec[idx].cal,
                                         bsec[idx].eom,
                                         &holi) ;
			/* PMSTA-22396 - SRIDHARA � 160502 */
            d1   = (FL64) Cldr_DaysBetweenDates(start, &end1, 
                                                bsec[idx].cal, &holi) ;
            dpy1 = Cldr_DaysPerYear(start, &end1, 0, bsec[idx].cal, 
                                    SAME, &holi) ;

            t1 = d1 / dpy1 ;
            y1 = prices[idx] / 100.0 ;
            y3 = (pow(1.0 + y1 * t1, t3 / t1) - 1.0) / t3 ;
            tdelta /= 100.0 ;
            res[idx] = (pow(1.0 + (y3 + tdelta) * t3, t1 / t3) - 1.0)
                      / t1 - y1 ;

            break ;

        case FRA:
            start1 = Cldr_TermUnit2Date(start, bsec[idx].term1,
                                            bsec[idx].unit,
                                            bsec[idx].cal,
                                            bsec[idx].eom,
                                            &holi) ;
            end1 = Cldr_TermUnit2Date(start, bsec[idx].term2,
                                          bsec[idx].unit,
                                          bsec[idx].cal,
                                          bsec[idx].eom,
                                          &holi) ;
			/* PMSTA-22396 - SRIDHARA � 160502 */
            d1   = (FL64) Cldr_DaysBetweenDates(&start1, &end1, 
                                                bsec[idx].cal, &holi) ;  
            dpy1 = Cldr_DaysPerYear(&start1, &end1, 0, bsec[idx].cal, 
                                    SAME, &holi) ;
            t1   = d1 / dpy1 ;
            y1   = prices[idx] / 100.0 ;
            y3   = (pow(1.0 + y1 * t1, t3 / t1) - 1.0) / t3 ;
            tdelta /= 100.0 ;
            res[idx]  = (pow(1.0 + (y3 + tdelta) * t3, t1 / t3) - 1.0) 
                        / t1 - y1 ;

            break ;

        case IRF:
            start1 = bsec[idx].start ;
            end1   = bsec[idx].maturity ;
			/* PMSTA-22396 - SRIDHARA � 160502 */
            d1   = (FL64) Cldr_DaysBetweenDates(&start1, &end1, 
                                                bsec[idx].cal, &holi) ;
            dpy1 = Cldr_DaysPerYear(&start1, &end1, 0, bsec[idx].cal, 
                                    SAME, &holi) ;
            t1   = d1 / dpy1 ;
            y1   = (100.0 - prices[idx] ) / 100.0 ;
            y3   = (pow(1.0 + y1 * t1, t3 / t1) - 1.0) / t3 ;
            tdelta /= 100.0 ;
            res[idx]  = (pow(1.0 + (y3 + tdelta) * t3, t1 / t3) - 1.0) 
                        / t1 - y1 ;
            res[idx] *= -1.0 ;

            break ;

        case SWAP:
            months = Cflw_MonthsBetweenPayments(bsec[idx].freq) ;
            end1   = Cldr_TermUnit2Date(start, months, MONTHS,
                                        bsec[idx].cal, bsec[idx].eom, 
                                        &holi) ;
			/* PMSTA-22396 - SRIDHARA � 160502 */
            d1   = (FL64) Cldr_DaysBetweenDates(start, &end1, 
                                                bsec[idx].cal, &holi) ;
            dpy1 = Cldr_DaysPerYear(start, &end1, 0, bsec[idx].cal, 
                                    SAME, &holi) ;

            t1 = d1 / dpy1 ;
            y1 = prices[idx] / 100.0 ;
            y3 = (pow(1.0 + y1 * t1, t3 / t1) - 1.0) / t3 ;
            tdelta /= 100.0 ;
            res[idx] = (pow(1.0 + (y3 + tdelta) * t3, t1 / t3) - 1.0) 
                      / t1 - y1 ;

            break ;

        case BOND:
            end1   = Cldr_TermUnit2Date(start, 
                                        bsec[idx].fixp.cday.pseq.term, 
                                        bsec[idx].fixp.cday.pseq.unit,
                                        bsec[idx].fixp.fix.cal,
                                        bsec[idx].fixp.cday.pseq.eom, 
                                        &holi) ;
			/* PMSTA-22396 - SRIDHARA � 160502 */
            d1   = (FL64) Cldr_DaysBetweenDates(start, &end1,
                                                bsec[idx].fixp.fix.cal, &holi) ;
            dpy1 = Cldr_DaysPerYear(start, &end1, 0,
                                    bsec[idx].fixp.fix.cal, SAME, &holi) ;

            t1 = d1 / dpy1 ;

			/* PMSTA-22396 - SRIDHARA � 160502 */
            tm = Cldr_TermBetweenDates(start, 
                                       &bsec[idx].fixp.cday.last, 0,
                                       bsec[idx].fixp.fix.cal,
                                       bsec[idx].fixp.cday.pseq.eom, &holi) ;
            df = (FL64) (Cldr_DaysBetweenDates(start, &end1, EU30E360, NULL))
                      / 360.0 ;
            ai = bsec[idx].fixp.fix.fix_rate * modf(tm / df, &dum) ;
            *ok = TVM_YieldByFormula(prices[idx] + ai,
                                      bsec[idx].fixp.fix.fix_rate * df,
                                      tm, BULLET, 0.00001, &y1) ;
            *ok = *ok && TVM_YieldByFormula(prices[idx] + ai + delta,
                                     bsec[idx].fixp.fix.fix_rate * df,
                                            tm, BULLET, 0.00001, &y3) ;
            if (*ok == False)
                continue;

            delta_y = y1 - y3 ;
            dp = delta / delta_y ;
            y1 /= 100.0 ;
            y3 = (pow(1.0 + y1 * t1, t3 / t1) - 1.0) / t3 ;
            tdelta /= 100.0 ;
            res[idx] = (pow(1.0 + (y3 + tdelta) * t3, t1 / t3) - 1.0) 
                       / t1 - y1 ;

            /* Move this yield delta into a price delta */
            res[idx] *= dp ;
            res[idx] *= -1.0 ;

            break ;

        default:
            ;
        }

        res[idx] *= 100.0 ;
    }

    return res;
}


/*
..
*/

BOOLE Boot_Genr_Fill(BSECTYPE  type, 
                        FILLTYPE  fill)
{
    if (fill == FILLNONE)
        return False ;

    else if (fill == FILLALL)
        return True ;
    else if (fill == FILLFRAIRF && (type == FRA || type == IMMFRA ||
                                    type == IRF))
        return True ;

      /* Default is FILLNONE: */
    return False;
}



#undef PARSWAP_MAXIT
#undef PARSWAP_ACC
#undef PARSWAP_EPS

#undef IRG_MAXIT
#undef IRG_MAXCHG
#undef IRG_DAMP
#undef IRG_ACC
#undef IRG_EPS
#undef IRG_NEGVOL
#undef IRG_TOOMANY

/* SCID @(#)zeromodl.c	1.13 (SimCorp) 99/09/07 16:22:23 */

/************************************************************************
*
*   project     SCecon
*
*   file name   zeromodl.c
*
*   general     This file contains standard routines for zerocoupon
*               estimation
*
************************************************************************/


/* includes ************************************************************/
#include <fitzero.h>


/* defines  ************************************************************/
#define SMALLSTEP 0.0001
#define MAXTA 100.0
#define MIN_TERM  0.00001


/*
Note this is a Bernstein polynomial as defined e.g. in Billingsley
"Probability and Measure", 1995, p. 87. Hence the approach is
different from Schaefer [81] where, first, the discount structure is 
fitted and, second, in this article the expression is derived from 
Bernstein polynomials.
*/


FL64 Zero_BRNSTYLD(FL64ARRAY coefs,
                   INTI      ncoefs,
                   FL64      tmax,
                   FL64      term,
                   FL64      spread)
{
    INTI k ;
    FL64 nk, x, y ;

    for (nk = 1.0, y = 0.0, k = 0; k < ncoefs; k++)
    {
        x  = term / tmax ;

        /* Use recurrence - Small numbers anyway */
        if (k > 0 && k < ncoefs - 1)
        {
            nk *= ((FL64) (ncoefs - k)) / (FL64) k ;
            y  += coefs[k] * nk * pow(x, (FL64) k) *
                                  pow(1.0 - x, (FL64) (ncoefs - k - 1)) ;
        }
        else if (k == 0)
            y += coefs[k] * nk * pow(1.0 - x, (FL64) (ncoefs - k - 1)) ;

        else if (k == ncoefs - 1)
        {
            nk *= ((FL64) (ncoefs - k)) / (FL64) k ;
            y  += coefs[k] * nk * pow(x, (FL64) k) ;
        }
    }

    return TVMunit_NPV(term, 100.0 * (y + spread), CONTINUOUS, 0) ;
}


/*
..
*/


FL64 Zero_BSPLYLD(FL64ARRAY coefs,   /* n + k elements */
                  FL64ARRAY knots,   /* nknots + k k = 3 */
                  INTI      nknots,  /* n + k k = 3 */
                  FL64      term,
                  FL64      spread)
{
    INTI i ;
    FL64 y ;

    /* Accumulate the continuous yield - Assume 3'rd order Basis - Spline */
    for (y = 0.0, i = 0; i < nknots; i++)
        y += coefs[i] * Math_Intpol_Bspline(term, i - 3, 3, 
                             nknots - 3, nknots + 3, knots) ;

    return TVMunit_NPV(term, 100.0 * (y + spread), CONTINUOUS, 0) ;
}


/*
..
*/


FL64ARRAY Zero_prep_BSPLYLD(FL64ARRAY spld,
                            INTI      nspld)
{
    FL64ARRAY newspld ;
    INTI      i ;

    newspld = Alloc_FL64ARRAY(nspld + 3) ;

    for (i = 0; i < nspld + 3; i++)
    {
        if (i >= nspld)
            newspld[i] = (10.0 * (FL64) (1 + i - nspld)) + spld[nspld - 1] ;
        else
            newspld[i] = spld[i] ;
    }

    return newspld ;
}


/************************************************************************
*
*                Zero_vasicek()
*
*    interface   #include <fitzero.h>
*
*                FL64 Zero_vasicek(FL64ARRAY coefs, FL64 term,
*                                  FL64 spread) ;
*
*    general     The function returns the discount function associated
*                with the coefficients of the Vasicek model.
*
*                The Vasicek is an equilibrium model of the interest
*                rates based on the assumption that the short rate
*                is determined by a one-factor stochastic proces.
*                This proces assumes that the short rate is normally
*                distributed.
*
*                The parameters of the proces are:
*
*                Kappa : The rate of mean reversal (how fast does the
*                        market adjust) - This should be between 0 and 1
*                Lambda: The market price of risk, or the risk premium -
*                Sigma : The instantaneous volatility of short rates -
*                        this should be positive
*                Theta : The steady state level of interest rates -
*                        of course positive
*                R     : The current short rate.
*
*                Lambda/Theta are not independent so in our
*                implementation we use 4 parameters:
*
*                Phi   : Theta - Lambda*Sigma
*                Kappa :
*                Sigma :
*                R     :
*
*                In the original Vasicek model, all these parameters are
*                fixed, except the current short rate, r, which is
*                variable. This is the single factor in the model. Under
*                that - strict - interpretation of the model, the long
*                term yields are given whereas short term yields may
*                move. However, we allow you to use the Vasicek
*                model in a slightly different manner: Instead of
*                postulating all parameters except R, and letting the
*                fitter determine R, you can let the fitter determine
*                all parameters of the model. This is not completely in
*                theoretical line with the original paper, but it allows
*                you to fit very nice looking term structures. This
*                version of the Vasicek model simply utilizes the
*                mathematical properties of the closed form solution
*                found by Vasicek, without attaching any deeper meaning
*                to it.
*
*    input       FL64ARRAY coefs      The coefficient array.
*                                     Array with 4 elements.
*                                     coefs[0] = Phi
*                                     coefs[1] = Kappa
*                                     coefs[2] = Sigma
*                                     coefs[3] = R
*                FL64     term        Term to the zero in fractional
*                                     years.
*                FL64     spread      The spread to the term structure
*                                     as continuous compounded yield
*                                     in fractions.
*
*    output
*
*    returns     The discount function for the term
*
*    diagnostics
*
*    see also    Zero_GenrTS()
*
************************************************************************/


FL64 Zero_vasicek(FL64ARRAY coefs, FL64 term, FL64 spread)
{
    FL64 s2, phi, a, y, r, at, bt ;

    phi   = coefs[0] ;
    a     = coefs[1] ;
    s2    = SQR(coefs[2]) ;
    r     = coefs[3] ;

    if (fabs(a) > 0.000001)
    {
        bt = (1.0 - exp(- a * term)) / a ;
        at = (bt - term) * (a * phi - s2 / 2.0) / (a * a) ;
        at = at - s2 * bt * bt / (4.0 * a) ;
    }
    else
    {
        /* Taylor approximation of the A(t,T) and B(t,T) expressions */
        bt = term ;
        at = phi * term * term / 2.0 ;
    }

    if (fabs(term) <= MIN_TERM)
        y = r ;
    else
        y = (r * bt - at) / term  ;

    return TVMunit_NPV(term, 100.0 * (y + spread), CONTINUOUS, 0) ;
}


/************************************************************************
*
*                Zero_ccw()
*
*    interface   #include <fitzero.h>
*
*                FL64    Zero_ccw(FL64ARRAY coefs, INTI  ncoef,
*                                 FL64    term, FL64    spread) ;
*
*    general     The function returns the discount function associated
*                with the coefficients of the CCW model.
*
*                The CCW model uses a polynomial of ncoef'th order in
*                the term structure. The model is described in:
*
*                    Chambers, Carleton, Waldman - A New Approach to
*                    Estimation of the Term Structure of Interest Rates,
*                    J. of Financial and Quantitative Analysis, sep. 84
*
*    input       FL64ARRAY coefs      The coefficient array.
*                                     Array with ncoef elements.
*                INTI     ncoef       No. of elements in coefs.
*                FL64     term        Term to the zero in fractional
*                                     years.
*                FL64     spread      The spread to the term structure
*                                     as continuous compounded yield
*                                     in fractions.
*
*    output
*
*    returns     The discount function for the term
*
*    diagnostics
*
*    see also    Zero_GenrTS()
*
************************************************************************/


FL64    Zero_ccw(FL64ARRAY coefs, INTI  ncoef, FL64    term, FL64    spread)
{
    INTI    i ;
    FL64    tmp, y ;

    tmp = 1.0 ;
    y   = 0.0 ;

    if (ncoef)
        y = coefs[0] ;

    for (i = 1 ; i < ncoef ; i++)
    {
        /* Scale by 10 to keep numerical stability */

        tmp *= term / 10.0 ;
        y   += coefs[i] * tmp ;
    }

    return TVMunit_NPV(term, 100.0 * (y + spread), CONTINUOUS, 0) ;
}


/************************************************************************
*
*                Zero_cir()
*
*    interface   #include <fitzero.h>
*
*                FL64    Zero_cir(FL64ARRAY coefs, FL64    term,
*                                 FL64    spread) ;
*
*    general     The function returns the discount function associated
*                with the coefficients of the CIR model.
*
*                The CIR model (Cox, Ingersoll and Ross, "A Theory of
*                the Term Structure of Interest Rates", Econometrica,
*                1985), is really a one factor equilibrium model of
*                interest rates.  It is derived from a stochastic
*                process of short rates, where the short term rate of
*                interest is mean reverting and the volatility is
*                proportional to the square root of the current short
*                rate. If rates go high, they tend to come down, if
*                they go low, they tend to come up.  (Interestingly,
*                this process itself is endogenously derived from the
*                uncertainty about future technology and economic
*                agents' preferences).  Based on this, CIR derive an
*                equation describing the term structure as a function of
*                five parameters:
*
*                Kappa : The rate of mean reversal (how fast does the
*                        market adjust) - This should be between 0 and 1
*                Lambda: The market price of risk, or the risk premium -
*                        This should be negative in the CIR formulation
*                        since risk corrected returns are lowered by
*                        increased risk aversion.
*                Sigma : The instantaneous volatility of short rates -
*                        this should be positive
*                Theta : The steady state level of interest rates -
*                        of course positive
*                R     : The current short rate.
*
*                Kappa/lambda/theta are not independent so in our
*                implementation we use 4 parameters:
*
*                Alpha : Kappa * Theta
*                Beta  : Kappa + Lambda
*                Sigma :
*                R     :
*
*                In the original CIR model, all of these parameters are
*                fixed, except the current short rate, r, which is
*                variable. This is the single factor in the model. Under
*                that - strict - interpretation of the model, the long
*                term yields are given whereas short term yields may
*                move. However, we allow you to use the CIR
*                model in a slightly different manner: Instead of
*                postulating all parameters except R, and letting the
*                fitter determine R, you can let the fitter determine
*                all parameters of the model. This is not completely in
*                theoretical line with the original paper, but it allows
*                you to fit very nice looking term structures. This
*                version of the CIR model simply utilizes the
*                mathematical properties of the closed form solution
*                found by CIR, without attaching any deeper meaning to
*                it.
*
*    input       FL64ARRAY coefs      The coefficient array.
*                                     Array with 4 elements.
*                                     coefs[0] = kappa*theta = alpha
*                                     coefs[1] = kappa + lambda = beta
*                                     coefs[2] = sigma
*                                     coefs[3] = r
*                FL64     term        Term to the zero in fractional
*                                     years.
*                FL64     spread      The spread to the term structure
*                                     as continuous compounded yield
*                                     in fractions.
*
*    output
*
*    returns     The discount function for the term
*
*    diagnostics
*
*    see also    Zero_GenrTS()
*
************************************************************************/


FL64 Zero_cir(FL64ARRAY coefs, FL64 term, FL64 spread)
{
    FL64 alpha, beta, sigma2, r, a, b, n, cgamma, y ;

    alpha = coefs[0] ;
    beta  = coefs[1] ;
    r     = coefs[3] ;

    sigma2 = SQR(coefs[2]);

    cgamma = sqrt(SQR(beta) + 2.0 * sigma2);

    if (cgamma * term > 30.0)
    {
        a = 2.0 * cgamma/(cgamma + beta) * exp((beta - cgamma) * term / 2.0) ;
        a = SQR(a);
        if (a > 0.0)
            a = pow(a, alpha/sigma2);
        b = 2.0/(cgamma + beta);
    }
    else
    {
        n = (cgamma + beta) * (exp(cgamma * term) - 1.0) + 2.0 * cgamma;
        a = 2.0 * cgamma * exp((beta + cgamma) * term / 2.0)/n ;
        a = SQR(a);
        if (a > 0.0)
            a = pow(a, alpha/sigma2);
        b = 2.0*(exp(cgamma * term) - 1.0)/n;
    }

    if (fabs(term) <= MIN_TERM)
        y = r ;
    else
        y = (a < 0.00001 ? 0.0 : (r * b - log(a))/term)  ;

    return TVMunit_NPV(term, 100.0 * (y + spread), CONTINUOUS, 0) ;
}


/************************************************************************
*
*                Zero_cirnom()
*
*    interface   #include <fitzero.h>
*
*                FL64    Zero_cirnom(FL64ARRAY coefs, FL64    term,
*                                    FL64    spread) ;
*
*    general     The function returns the discount function associated
*                with the coefficients of the nominal CIR model.
*
*                The CIRNOM model is equivalent to the CIR model except
*                for a 5'th parameter - the expected inflation. The
*                model is referred to as a nominal model with lognormal
*                price level. The original reference to this model is the
*                same paper in Econometrica (1985). 
*
*    input       FL64ARRAY coefs      The coefficient array.
*                                     Array with 5 elements.
*                                     coefs[0] = kappa*theta = alpha
*                                     coefs[1] = kappa + lambda = beta
*                                     coefs[2] = sigma
*                                     coefs[3] = r
*                                     coefs[4] = expected inflation rate
*                FL64     term        Term to the zero in fractional
*                                     years.
*                FL64     spread      The spread to the term structure
*                                     as continuous compounded yield
*                                     in fractions.
*
*    output
*
*    returns     The discount function for the term
*
*    diagnostics
*
*    see also    Zero_GenrTS()
*
************************************************************************/


FL64 Zero_cirnom(FL64ARRAY coefs, FL64    term, FL64    spread)
{
    FL64 pdot, p, y ;

    pdot = coefs[4] ;

    term = GETMAX(MIN_TERM, term) ;
    p = Zero_cir(coefs, term, 0.0) * exp(- pdot * term) ;
    y = TVMunit_Yield(p, term, CONTINUOUS, 0) ;

    return TVMunit_NPV(term, y + 100.0 * spread, CONTINUOUS, 0) ;
}


/************************************************************************
*
*                Zero_longsch()
*
*    interface   #include <fitzero.h>
*
*                FL64    Zero_longsch(FL64ARRAY coefs, FL64    term,
*                                     FL64    spread) ;
*
*    general     The function returns the discount function associated
*                with the coefficients of the Longstaff Schwartz two
*                factor term structure model.
*
*                This model is the most recent development in the field
*                of term structure modelling - to be published in 1992.
*                It is essentially a 2 factor model with the 2 factors
*                as the short rate and the volatility of the short rate.
*                From our point of view we use the model in a similar
*                way as we use the CIR model. Ie. we estimate the 8
*                parameters of the model without attaching any deeper
*                meaning to the parameters.
*                The parameters in the original formulation are a, b, c,
*                d, e, f, mu, theta, sigma and lambda (parameters in
*                the 2 stochastic differential equations to be solved).
*                The parameters are in our formulation transformed to
*                (following the authors) the following 8 parameters:
*
*                Alpha : mu * c^2
*                Beta  : (theta - sigma^2) * f^2
*                Gamma : a/c^2
*                Delta : b
*                Eta   : d/f^2
*                Nu    : e + lambda
*                R     : the current short rate
*                V     : the current short rate volatility
*
*    input       FL64ARRAY coefs      The coefficient array.
*                                     array with 8 elements ordered as
*                                     above.
*                FL64     term        Term to the zero in fractional
*                                     years.
*                FL64     spread      The spread to the term structure
*                                     as continuous compounded yield
*                                     in fractions.
*
*    output
*
*    returns     The discount function for the term
*
*    diagnostics
*
*    see also    Zero_GenrTS()
*
************************************************************************/


FL64 Zero_longsch(FL64ARRAY coefs, FL64 term, FL64 spread)
{
    FL64 alpha, beta, gamma, delta, eta, nu, r, v,
         tmp, a, b, c, d, phi, ksi, kappa, n, ep, ek, y ;

    alpha = coefs[0] ;
    beta  = coefs[1] ;
    gamma = coefs[2] ;
    delta = coefs[3] ;
    eta   = coefs[4] ;
    nu    = coefs[5] ;
    r     = coefs[6] ;
    v     = coefs[7] ;

    if (beta == alpha)
        beta += 0.0000001 ;

    tmp   = 2.0 * alpha + SQR(delta) ;
    if (tmp > 0.0000001)
        phi = sqrt(tmp) ;
    else
        phi = 0.0000001 ;

    tmp = 2.0 * beta + SQR(nu) ;
    if (tmp > 0.0000001)
        ksi = sqrt(tmp) ;
    else
        ksi = 0.0000001 ;

    kappa = gamma * (delta + phi) + eta * (nu + ksi) ;

    ep = exp(phi * term) - 1.0 ;
    ek = exp(ksi * term) - 1.0 ;
    n  = phi * ksi * (beta - alpha) ;

    a = 2.0 * phi / ( (delta + phi) * ep + 2.0 * phi ) ;
    b = 2.0 * ksi / ( (nu + ksi) * ek + 2.0 * ksi ) ;
    c = (alpha * phi * ek * b - beta * ksi * ep * a)/n ;
    d = (ksi * ep * a - phi * ek * b)/n ;

    if (fabs(term) < MIN_TERM)
        y = r ;
    else
        y = -(kappa*term + gamma*log(a*a) + eta*log(b*b) + c*r + d*v)/term ;

    return TVMunit_NPV(term, 100.0 * (y + spread), CONTINUOUS, 0) ;
}


/************************************************************************
*
*                Zero_dpoly()
*
*    interface   #include <fitzero.h>
*
*                FL64    Zero_dpoly(FL64ARRAY coefs, INTI  ncoef,
*                                   FL64    term, FL64    spread) ;
*
*    general     The function returns the discount function associated
*                with the coefficients of the discount function polyno-
*                mial model.
*
*                The model uses a polynomial of ncoef'th order in
*                the discount function.
*
*                This specification was suggested in "Measuring the 
*                Term Structure of Interest Rates", Journal of Business
*                1971, J. McCulloch.
*
*
*    input       FL64ARRAY coefs      The coefficient array.
*                                     Array with ncoef elements.
*                INTI     ncoef       No. of elements in coefs.
*                FL64     term        Term to the zero in fractional
*                                     years.
*                FL64     spread      The spread to the term structure
*                                     as continuous compounded yield
*                                     in fractions.
*
*    output
*
*    returns     The discount function for the term
*
*    diagnostics
*
*    see also    Zero_GenrTS()
*
************************************************************************/


FL64    Zero_dpoly(FL64ARRAY coefs, INTI  ncoef, FL64  term, FL64  spread)
{
    INTI    i ;
    FL64    y, tmp, p ;

    tmp  = p = 1.0 ;
    term = GETMAX(MIN_TERM, term) ;

    for (i = 0 ; i < ncoef ; i++)
    {
        /* Scale by 10 to keep numerical stability */
        tmp *= term / 10.0 ;
        p   += coefs[i] * tmp ;
    }
    if (p <= 0.0)
        p = 0.001 ;

    y = TVMunit_Yield(p, term, CONTINUOUS, 0) ;

    return TVMunit_NPV(term, y + 100.0 * spread, CONTINUOUS, 0) ;
}


/************************************************************************
*
*                Zero_iyext()
*
*    interface   #include <fitzero.h>
*
*                FL64    Zero_iyext(FL64ARRAY coefs, FL64    term,
*                                   FL64    spread) ;
*
*    general     The function returns the discount function associated
*                with the coefficients of the Nelson/Siegel model.
*
*                The extended Nelson and Siegel model (IYEXT) uses
*                Laguerre polynomials - or decay functions - to fit the
*                term structure. The advantage is that short term and
*                long term yields are then both bounded. A curve fitted
*                by the IYEXT model consists of a superimposition of
*                three functions. One determines the decay of short term
*                impacts, one determines the medium term decay, and one
*                determines the long term decay. The point where we
*                distinguish between short term and medium term is given
*                by the time scaling parameter.
*
*                The model has five parameters. The first is the long
*                term yield (continuously compounded). The 3 next are
*                coefficients that determine the decay behaviour in
*                the three segments of the curve. The 5'th is the time
*                scaling factor which must be strictly positive.
*
*    input       FL64ARRAY coefs      The coefficient array.
*                                     Array with 5 elements ordered as
*                                     above.
*                FL64     term        Term to the zero in fractional
*                                     years.
*                FL64     spread      The spread to the term structure
*                                     as continuous compounded yield
*                                     in fractions.
*
*    output
*
*    returns     The discount function for the term
*
*    diagnostics
*
*    see also    Zero_GenrTS()
*
************************************************************************/


FL64    Zero_iyext(FL64ARRAY coefs, FL64    term, FL64    spread)
{
    FL64    y, ta, temp ;

    if(term > MIN_TERM)
    {
      ta   = (coefs[4] < MIN_TERM ? term/MIN_TERM : term/coefs[4]) ;
      temp = exp(-ta) ;
      y    = coefs[0] + coefs[1] * temp + coefs[2] * ta * temp +
             coefs[3] * ((1.0 - temp)/ta - temp - ta * temp/2.0) ;
    }
    else /* Asymptotical value */
      y = coefs[0] + coefs[1] ;

    return TVMunit_NPV(term, 100.0 * (y + spread), CONTINUOUS, 0) ;
}


/************************************************************************
*
*                Zero_extns()
*
*    interface   #include <fitzero.h>
*
*                FL64    Zero_extns(FL64ARRAY coefs, FL64    term,
*                                   FL64    spread) ;
*
*    general     The function returns the discount function associated
*                with the coefficients of the Extended Nelson/Siegel 
*                model as described in Lars Svensson "Estimating and 
*                Interpreting Forward Interest Rates: Sweden 1992-1994.
*                IMF Working Paper, 1994. See also R. Bliss "Testing
*                Term Structure Estimation Methods", Advances in
*                Futures and Options Research.
*
*                The extended Nelson and Siegel model (EXTNS) uses
*                Laguerre polynomials - a combination of decay functions 
*                and polynomials - to fit the term structure. The 
*                advantage is that short term and long term yields are 
*                then both bounded. 
*
*                Compared to the original Nelson/Siegel model this 
*                specification allow for a second hump in the forward 
*                rate curve. Another advantages of this specification
*                is that several parsimonious models araise as nested
*                cases. By restricting the 4th parameter to zero the 
*                original Nelson/Siegel model arise as a nested case. 
*                Similar by setting the 3rd parameter to zero Bliss's 
*                extended Nelson/Siegel model arise.
*
*                The model has six parameters. The first is the long
*                term yield (continuously compounded). The 3 next are
*                coefficients that determine the decay behaviour in
*                the three segments of the curve. The 5'th and 6'th
*                are time scaling factors which both must be strictly 
*                positive. The sum of parameter one and two is 
*                asymptotically the instantaneous yield.
*
*    input       FL64ARRAY coefs      The coefficient array.
*                                     Array with 6 elements ordered as
*                                     above.
*                FL64     term        Term to the zero in fractional
*                                     years.
*                FL64     spread      The spread to the term structure
*                                     as continuous compounded yield
*                                     in fractions.
*
*    output
*
*    returns     The discount function for the term
*
*    diagnostics
*
*    see also    Zero_GenrTS()
*
************************************************************************/


FL64    Zero_extns(FL64ARRAY coefs, FL64    term, FL64    spread)
{
    FL64    y, tau1, tau2, temp1, temp2 ;

    if(term > MIN_TERM)
    {
      tau1  = (coefs[4] < MIN_TERM ? term/MIN_TERM : term/coefs[4]) ;
      tau2  = (coefs[5] < MIN_TERM ? term/MIN_TERM : term/coefs[5]) ;
      temp1 = exp(-tau1) ;
      temp2 = exp(-tau2) ;
      y     = coefs[0] + (coefs[1] + coefs[2])*(1 - temp1)/tau1 -
              coefs[2]*temp1 + coefs[3]*((1 - temp2)/tau2 - temp2) ;
    }
    else /* Asymptotical value */
      y = coefs[0] + coefs[1] ;
      
    return TVMunit_NPV(term, 100.0 * (y + spread), CONTINUOUS, 0) ;
}


/************************************************************************
*
*                Zero_prep_splines()
*
*    interface   #include <fitzero.h>
*
*                INTI Zero_prep_splines(FL64ARRAY coefs, FL64ARRAY spld,
*                                       INTI  ncoef, FL64ARRAY newcoefs,
*                                       FL64ARRAY newspld,
*                                       ZEROMODEL model) ;
*
*    general     The function prepares the modelparameters and spline-
*                dates for interpolation - this is for numerical stabi-
*                lity.
*
*    input       FL64ARRAY coefs      The coefficient array.
*                                     Array with ncoef elements.
*                FL64ARRAY spld       The splinedates array. Unit offset
*                                     Array with ncoef elements.
*                INTI     ncoef       Number of elements in coefs/spld.
*                ZEROMODEL model      The spline model used - one of
*                                     SPLINEDISC, SPLINEEXPO, SPLINEYIELD
*                                     or SPLINETRANS.
*
*    output      FL64ARRAY newcoefs   The coefficient array.
*                                     Array with ncoef + 4 elements.
*                                     Preallocated with Alloc_FL64ARRAY()
*                FL64ARRAY newspld    The splinedates array.
*                                     Array with ncoef + 4 elements.
*                                     Preallocated with Alloc_FL64ARRAY()
*
*    returns     No. of coefs.
*
*    diagnostics
*
*    see also    Zero_splines()
*
************************************************************************/


INTI Zero_prep_splines(FL64ARRAY coefs, FL64ARRAY spld, INTI  ncoef,
                       FL64ARRAY newcoefs, FL64ARRAY newspld, ZEROMODEL model)
{
    INTI    nx, i ;

    /* Set new set of spline dates */
    if (model != SPLINEX && model != SPLINEF && model != SPLINETRANS)
    {
        newspld[0] = 0.01 * spld[0] ;
        newspld[1] = 0.99 * spld[0] ;

        for (i = 0 ; i < ncoef ; i++)
            newspld[2 + i] = spld[i] ;

        newspld[ncoef + 2] = 1.01 * spld[ncoef - 1] ;
        newspld[ncoef + 3] = 2.0 * spld[ncoef - 1] ;
        nx = ncoef + 4 ;
    }
    else
    {
        for (i = 0 ; i < ncoef ; i++)
            newspld[i] = spld[i] ;

        nx = ncoef ;
    }

    /* Set new set of coefficients */
    switch (model)
    {
        case SPLINEX :
        case SPLINEF :
        case SPLINETRANS : 

            for (i = 0 ; i < ncoef ; i++)
                newcoefs[i] = coefs[i] ;
            break ;

        case SPLINEYIELD :

            newcoefs[0] = newcoefs[1] = coefs[0] ;

            for (i = 0 ; i < ncoef ; i++)
                newcoefs[2 + i] = coefs[i] ;

            newcoefs[ncoef + 2] = newcoefs[ncoef + 3] = coefs[ncoef - 1] ;
            break ;

        case SPLINEEXPO :

            newcoefs[0] = newspld[0]/newspld[2] * coefs[0] ;
            newcoefs[1] = newspld[1]/newspld[2] * coefs[0] ;

            for (i = 0 ; i < ncoef ; i++)
                newcoefs[2 + i] = coefs[i] ;

            newcoefs[ncoef + 2] = newspld[ncoef + 2]/newspld[ncoef + 1] *
                                  coefs[ncoef - 1] ;
            newcoefs[ncoef + 3] = newspld[ncoef + 3]/newspld[ncoef + 1] *
                                  coefs[ncoef - 1] ;
            break ;

        case SPLINEDISC :

            newcoefs[0] = pow(coefs[0], newspld[0]/newspld[2]) ;
            newcoefs[1] = pow(coefs[0], newspld[1]/newspld[2]) ;

            for (i = 0 ; i < ncoef ; i++)
                newcoefs[2 + i] = coefs[i] ;

            newcoefs[ncoef + 2] = pow(coefs[ncoef - 1], newspld[ncoef + 2]/
                                                        newspld[ncoef + 1]) ;
            newcoefs[ncoef + 3] = pow(coefs[ncoef - 1], newspld[ncoef + 3]/
                                                        newspld[ncoef + 1]) ;
            break ;

        default:
            ;
    }

    return nx ;
}


/************************************************************************
*
*                Zero_splines()
*
*    interface   #include <fitzero.h>
*
*                FL64    Zero_splines(FL64ARRAY coefs, FL64ARRAY spld,
*                                     FL64ARRAY y2,
*                                     INTI  ncoef, ZEROMODEL model,
*                                     FL64    term, FL64    spread) ;
*
*    general     The function returns the discount function associated
*                with the coefficients of the specified spline model
*
*                In the SPLINEYIELD model, we fit a chain of third
*                degree polynomials to the term structure. The
*                polynomials are chained in the knot points as input by
*                the user as terms, and the coefficients of the
*                polynomials are chosen such that the first and second
*                order derivatives of the interpolating function are
*                continuous in the knot points. Outside the range given
*                in the input knot points, the term structure will be
*                flat at the level in the first or last knot point.
*
*                In the SPLINEDISC model, we fit a chain of third degree
*                polynomials to the discount function (the mirror image
*                of the term structure).
*
*                In the SPLINEEXPO model, we fit a chain of third degree
*                polynomials to the term e = t*y(t) of the pricing
*                equation P = exp(-e). Hence the name exponential
*                spline.
*
*                In the SPLINETRANS model, we fit a chain of third degree
*                polynomials to a simple transformation of the yield curve 
*                u(t) = y(t)*(1+t) which leads to the pricing equation 
*                P = exp(-t/(1+t)u(t)). Hence the name transformed yield 
*                spline. This transformation was suggested by C.
*                Tanggaard "Nonparametric Smoothing of Yield Curves",
*                Working Paper HHA, 1995.
*
*    input       FL64ARRAY coefs      The coefficient array.
*                                     Array with ncoef elements.
*                FL64ARRAY spld       The spline dates.
*                                     array with ncoef elements.
*                FL64ARRAY y2         The second order derivatives.
*                                     Array with ncoef elements.
*                INTI     ncoef       No. of elements in coefs/spld/y2
*                ZEROMODEL model      The spline model used - one of
*                                     SPLINEDISC/SPLINEEXPO/SPLINEYIELD
*                FL64     term        Term to the zero in fractional
*                                     years.
*                FL64     spread      The spread to the term structure
*                                     as continuous compounded yield
*                                     in fractions.
*
*    output
*
*    returns     The discount function for the term
*
*    diagnostics
*
*    see also    Zero_prep_splines()
*                Zero_GenrTS()
*
************************************************************************/


FL64    Zero_splines(FL64ARRAY coefs, FL64ARRAY spld, FL64ARRAY y2,
                     INTI  ncoef, ZEROMODEL model,
                     FL64    term, FL64    spread)
{
    FL64    y, tp, yp ;

    if (model != SPLINEX && model != SPLINEF)
    {
        if (term < spld[0])
            tp = spld[0] ;
        else
        {
            if (term > spld[ncoef - 1])
                tp = spld[ncoef - 1] ;
            else
                tp = term ;
        }
    }
    else
        tp = term ;

    Math_Cspl_Intpol(spld, coefs, y2, ncoef, tp, &yp) ;

    switch (model)
    {
        case SPLINEYIELD :
        case SPLINEX :
        case SPLINEF :

            y = yp ;
            break ;

        case SPLINEDISC :

            if (yp <= 0.0)
                yp = 0.001 ;

            y  = TVMunit_Yield(yp, tp, CONTINUOUS, 0)/100.0 ;
            break ;

        case SPLINEEXPO :

          y = (tp > MIN_TERM ? yp/tp : 0.0) ;
            break ;

        case SPLINETRANS :

            y = yp / (1 + tp) ;
            break ;
        
        default:
            /* warning avoidance */
            y = 0.0 ;
            break ;
    }

    return TVMunit_NPV(term, 100.0 * (y + spread), CONTINUOUS, 0) ;
}

/*,,SOH,,
*************************************************************************
*
*                Zero_GenrTS()
*
*    interface   #include <fitzero.h>
*                TSARRAY Zero_GenrTS(FL64ARRAY coefs,
*                                     FL64ARRAY spld,
*                                     INTI      ncoef,
*                                     ZEROMODEL model,
*                                     FL64ARRAY term1,
*                                     INTI      nterm,
*                                     IRRCONV   irr,
*                                     INTI      qbas,
*                                     BOOLE     use_prep) ;
*
*    general     The function calculates a term structure from a set
*                of Term Structure model parameters.
*
*                These parameters may be given in by 'hand' or could
*                have been estimated using Fit_BSEC2DF()
*
*                The yields corresponding to the coefficients are quoted
*                as continuous rates. Here, however, there is an option
*                to translate these rates into compounded or simple
*                rates.
*
*                Please note that since our implementation of the models
*                are handling some numerical issues - the parameters
*                cannot always be interpreted as the theoretical ones.
*                So this function expects the coefficients to be in a
*                specific format - eg. as returned by Fit_BSEC2DF().
*
*    input       FL64ARRAY coefs      The coefficient array.
*                                     Array with ncoef elements.
*
*                FL64ARRAY spld       The spline terms.
*                                     Array with ncoef elements of terms
*                                     in fractional years.
*                                     Only needed for the spline models.
*                                     Sorted in ascending order and
*                                     positive numbers.
*
*                INTI     ncoef       No. of elements in coefs/spld
*
*                ZEROMODEL model      The model used.
*
*                FL64ARRAY term1      The terms for which rates are to
*                                     be found.
*
*                INTI      nterm      Number of elmts in term.
*
*                IRRCONV   irr        Interest rate convention
*
*                INTI      qbas       Quoting basis if irr is COMPOUND,
*                                     MOOSMULLER or US_TREASURY
*
*                BOOLE     use_prep   Setting this argument to True  
*                                     might stabilize the two ends of the
*                                     spline but the recommended setting is 
*                                     False. The setting must be the same as 
*                                     when the model was calibrated. Only used
*                                     if model is SPLINEYIELD, SPLINEDISC,
*                                     SPLINEEXPO, SPLINEX, SPLINEF, or 
*                                     SPLINETRANS.  
*
*    output
*
*    returns     Pointer to TSARRAY allocated in this function as:
*                Alloc_TSARRAY(1, nterm). All data are filled.
*
*    diagnostics
*
*    see also    Fit_BSEC2DF()
*                Zero_Model2Price()
*
*************************************************************************
,,EOH,,*/


TSARRAY Zero_GenrTS(FL64ARRAY coefs, FL64ARRAY spld, INTI  ncoef,
                     ZEROMODEL model, FL64ARRAY term1, INTI nterm, IRRCONV irr,
                     INTI qbas, BOOLE use_prep)
{
    INTI      i, nshow ;
    FL64      term, *terms, *rates, p ;
    FL64ARRAY y2, newcoefs, newspld ;
    TSARRAY   ts ;

    ts = Alloc_TSARRAY(1, nterm) ;

    nshow = ts->count = nterm ;
    ts->qbas = qbas ;
    ts->conv = irr ;
    terms = ts->term ;
    rates = ts->rate ;

    for (i = 0; i < nterm ; i++)
        terms[i] = term1[i] ;

    switch (model)
    {
        case BSPLYLD :

            newspld = Zero_prep_BSPLYLD(spld, ncoef) ;

            for (i = 0 ; i < nshow ; i++)
            {
                term     = GETMAX(MIN_TERM, terms[i]) ;
                p        = Zero_BSPLYLD(coefs, newspld, ncoef, term, 0.0) ;
                rates[i] = TVMunit_Yield(p, term, irr, qbas) ;
            }

            Free_FL64ARRAY(newspld) ;
            break ;

        case BRNSTYLD :

            for (i = 0 ; i < nshow ; i++)
            {
                term     = GETMAX(MIN_TERM, terms[i]) ;
                p        = Zero_BRNSTYLD(coefs, ncoef, spld[ncoef - 1],
                                         term, 0.0) ;
                rates[i] = TVMunit_Yield(p, term, irr, qbas) ;
            }
            break ;

        case VASICEK :

            for (i = 0 ; i < nshow ; i++)
            {
                term     = GETMAX(MIN_TERM, terms[i]) ;
                p        = Zero_vasicek(coefs, term, 0.0) ;
                rates[i] = TVMunit_Yield(p, term, irr, qbas) ;
            }
            break ;

        case CIR :

            for (i = 0 ; i < nshow ; i++)
            {
                term     = GETMAX(MIN_TERM, terms[i]) ;
                p        = Zero_cir(coefs, term, 0.0) ;
                rates[i] = TVMunit_Yield(p, term, irr, qbas) ;
            }
            break ;

        case CIRNOM :

            for (i = 0 ; i < nshow ; i++)
            {
                term     = GETMAX(MIN_TERM, terms[i]) ;
                p        = Zero_cirnom(coefs, term, 0.0) ;
                rates[i] = TVMunit_Yield(p, term, irr, qbas) ;
            }
            break ;

        case LONGSCH :

            for (i = 0 ; i < nshow ; i++)
            {
                term     = GETMAX(MIN_TERM, terms[i]) ;
                p        = Zero_longsch(coefs, term, 0.0) ;
                rates[i] = TVMunit_Yield(p, term, irr, qbas) ;
            }
            break ;

        case CCW :

            for (i = 0 ; i < nshow ; i++)
            {
                term     = GETMAX(MIN_TERM, terms[i]) ;
                p        = Zero_ccw(coefs, ncoef, term, 0.0) ;
                rates[i] = TVMunit_Yield(p, term, irr, qbas) ;
            }
            break ;

        case IYEXT :

            for (i = 0 ; i < nshow ; i++)
            {
                term     = GETMAX(MIN_TERM, terms[i]) ;
                p        = Zero_iyext(coefs, term, 0.0) ;
                rates[i] = TVMunit_Yield(p, term, irr, qbas) ;
            }
            break ;

        case EXTNS :

            for (i = 0 ; i < nshow ; i++)
            {
                term     = GETMAX(MIN_TERM, terms[i]) ;
                p        = Zero_extns(coefs, term, 0.0) ;
                rates[i] = TVMunit_Yield(p, term, irr, qbas) ;
            }
            break ;

        case DPOLY :

            for (i = 0 ; i < nshow ; i++)
            {
                term     = GETMAX(MIN_TERM, terms[i]) ;
                p        = Zero_dpoly(coefs, ncoef, term, 0.0) ;
                rates[i] = TVMunit_Yield(p, term, irr, qbas) ;
            }
            break ;

        case SPLINEYIELD :
        case SPLINEDISC  :
        case SPLINEEXPO  :
        case SPLINEX :
        case SPLINEF :
        case SPLINETRANS :

          if (use_prep)
          {
            newcoefs = Alloc_FL64ARRAY(ncoef + 4) ;
            newspld  = Alloc_FL64ARRAY(ncoef + 4) ;
            y2       = Alloc_FL64ARRAY(ncoef + 4) ;

            ncoef = Zero_prep_splines(coefs, spld, ncoef, newcoefs,
                                      newspld, model) ;
          }
          else
          {
            y2       = Alloc_FL64ARRAY(ncoef) ;
            newcoefs = coefs ;
            newspld  = spld ;
          }
          
          if (model != SPLINEF)
            Math_Cspl_Prep(newspld, newcoefs, ncoef, SPLINE_MAX*1.1,
                           SPLINE_MAX*1.1, y2) ;
          else
            Math_Cspl_Prep(newspld, newcoefs, ncoef, 0.0, 0.0, y2) ;

          for (i = 0 ; i < nshow ; i++)
          {
              term = GETMAX(MIN_TERM, terms[i]) ;
              p    = Zero_splines(newcoefs, newspld, y2, ncoef, model,
                                  term, 0.0) ;
              rates[i] = TVMunit_Yield(p, term, irr, qbas) ;
          }

          if (use_prep)
          {
            Free_FL64ARRAY(newcoefs) ;
            Free_FL64ARRAY(newspld) ;
          }
          Free_FL64ARRAY(y2) ;
          break ;

        default:
          ;
    }

    return ts ;
}


/*,,SOH,,
*************************************************************************
*
*                Zero_GenrDF()
*
*    interface   #include <fitzero.h>
*                PLANARRAY Zero_GenrDF(FL64ARRAY coefs,
*                                       FL64ARRAY spld,
*                                       INTI      ncoef,
*                                       ZEROMODEL model,
*                                       CALCONV   cal,
*                                       DATESTR   *today,
*                                       DATEARRAY days,
*                                       INTI      ndays,
*                                       BOOLE     use_prep) ;
*
*    general     The function calculates a discount function from a set
*                of Term Structure model parameters.
*
*                These parameters may be given in by 'hand' or could
*                have been estimated using Zero_Fit_DF()
*
*                The yields corresponding to the coefficients are quoted
*                as continuous rates. Here, however, these coefficients
*                are translated into the discount factors.
*
*                Please note that since our implementation of the models
*                are handling some numerical issues - the parameters
*                cannot always be interpreted as the theoretical ones.
*                So this function expects the coefficients to be in a
*                specific format - eg. as returned by Zero_Fit_DF().
*
*    input       FL64ARRAY coefs      The coefficient array.
*                                     Array with ncoef elements.
*
*                FL64ARRAY spld       The spline terms in fractional
*                                     years.
*                                     Array with ncoef elements of terms
*                                     Only needed for the spline models.
*                                     Sorted in ascending order.
*
*                INTI      ncoef      No. of elements in coefs/spld
*
*                ZEROMODEL model      The model used.
*
*                CALCONV   cal        Calendar convention
*
*                DATESTR   *today     The current date.
*
*                DATEARRAY days       List of days for discount factor
*                                     calculation.
*
*                INTI      ndays      # of elements in days
*
*                BOOLE     use_prep   Specifies if the function Zero_prep
*                                     _splines() is used (True) or not 
*                                     (False). Using Zero_prep_splines 
*                                     might stabilize the two ends of the
*                                     spline. The setting of this 
*                                     parameter must be the same as when
*                                     the model was calibrated. Only used
*                                     if model is SPLINEYIELD, SPLINEDISC,
*                                     SPLINEEXPO, SPLINEX, SPLINEF, or 
*                                     SPLINETRANS.  
*
*	       	    HOLI_STR    *holi	  Container for list of holidays.
*
*    output
*
*    returns     Pointer to PLANARRAY allocated in this routine as:
*                Alloc_PLANARRAY(1, ndays + 1). All data are set.
*
*    diagnostics
*
*    see also    Fit_BSEC2DF()
*                Zero_GenrTS()
*
*************************************************************************
,,EOH,,*/


PLANARRAY Zero_GenrDF(FL64ARRAY coefs, FL64ARRAY spld, INTI ncoef,
                         ZEROMODEL model, CALCONV cal, DATESTR* today,
						 DATEARRAY days, INTI ndays, BOOLE use_prep, HOLI_STR* holi)
{
    INTI      i, nshow ;
    FL64      term, *pf64 ;
    FL64ARRAY y2, newcoefs, newspld ;
    DATESTR   *pday ;
    PLANARRAY disc ;

    disc = Alloc_PLANARRAY(1, 1 + ndays) ;
    disc->filled = disc->count = 1 + ndays ;

    disc->day[0] = *today ;
    disc->f64[0] = 1.0 ;
    for (i = 1 ; i <= ndays ; i++)
        disc->day[i] = days[i - 1] ;

    nshow = ndays + 1 ;
    pf64  = disc->f64 ;
    pday  = disc->day ;

    switch (model)
    {
        case BSPLYLD :

            newspld = Zero_prep_BSPLYLD(spld, ncoef) ;
            for (i = 1 ; i < nshow ; i++)
            {
                term    = Cldr_TermBetweenDates(&pday[0], &pday[i],
                                                0, cal, LAST, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
                term    = GETMAX(MIN_TERM, term) ;
                pf64[i] = Zero_BSPLYLD(coefs, newspld, ncoef, term, 0.0) ;
            }

            Free_FL64ARRAY(newspld) ;
            break ;

        case BRNSTYLD :

            for (i = 1 ; i < nshow ; i++)
            {
                term    = Cldr_TermBetweenDates(&pday[0], &pday[i],
                                                0, cal, LAST, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
                term    = GETMAX(MIN_TERM, term) ;
                pf64[i] = Zero_BRNSTYLD(coefs, ncoef, spld[ncoef - 1],
                                        term, 0.0) ;
            }
            break ;

        case VASICEK :

            for (i = 1 ; i < nshow ; i++)
            {
                term    = Cldr_TermBetweenDates(&pday[0], &pday[i],
                                                0, cal, LAST, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
                term    = GETMAX(MIN_TERM, term) ;
                pf64[i] = Zero_vasicek(coefs, term, 0.0) ;
            }
            break ;

        case CIR :

            for (i = 1 ; i < nshow ; i++)
            {
                term    = Cldr_TermBetweenDates(&pday[0], &pday[i],
                                                0, cal, LAST, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
                term    = GETMAX(MIN_TERM, term) ;
                pf64[i] = Zero_cir(coefs, term, 0.0) ;
            }
            break ;

        case CIRNOM :

            for (i = 1 ; i < nshow ; i++)
            {
                term    = Cldr_TermBetweenDates(&pday[0], &pday[i],
                                                0, cal, LAST, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
                term    = GETMAX(MIN_TERM, term) ;
                pf64[i] = Zero_cirnom(coefs, term, 0.0) ;
            }
            break ;

        case LONGSCH :

            for (i = 1 ; i < nshow ; i++)
            {
                term    = Cldr_TermBetweenDates(&pday[0], &pday[i],
                                                0, cal, LAST, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
                term    = GETMAX(MIN_TERM, term) ;
                pf64[i] = Zero_longsch(coefs, term, 0.0) ;
            }
            break ;

        case CCW :

            for (i = 1 ; i < nshow ; i++)
            {
                term    = Cldr_TermBetweenDates(&pday[0], &pday[i],
                                                0, cal, LAST, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
                term    = GETMAX(MIN_TERM, term) ;
                pf64[i] = Zero_ccw(coefs, ncoef, term, 0.0) ;
            }
            break ;

        case IYEXT :

            for (i = 1 ; i < nshow ; i++)
            {
                term    = Cldr_TermBetweenDates(&pday[0], &pday[i],
                                                0, cal, LAST, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
                term    = GETMAX(MIN_TERM, term) ;
                pf64[i] = Zero_iyext(coefs, term, 0.0) ;
            }
            break ;

        case EXTNS :

            for (i = 1 ; i < nshow ; i++)
            {
                term    = Cldr_TermBetweenDates(&pday[0], &pday[i],
                                                0, cal, LAST, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
                term    = GETMAX(MIN_TERM, term) ;
                pf64[i] = Zero_extns(coefs, term, 0.0) ;
            }
            break ;

        case DPOLY :

            for (i = 1 ; i < nshow ; i++)
            {
                term    = Cldr_TermBetweenDates(&pday[0], &pday[i],
                                                0, cal, LAST, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
                term    = GETMAX(MIN_TERM, term) ;
                pf64[i] = Zero_dpoly(coefs, ncoef, term, 0.0) ;
            }
            break ;

        case SPLINEYIELD :
        case SPLINEDISC  :
        case SPLINEEXPO  :
        case SPLINEX :
        case SPLINEF :
        case SPLINETRANS :

          if (use_prep)
          {
            newcoefs = Alloc_FL64ARRAY(ncoef + 4) ;
            newspld  = Alloc_FL64ARRAY(ncoef + 4) ;
            y2       = Alloc_FL64ARRAY(ncoef + 4) ;

            ncoef = Zero_prep_splines(coefs, spld, ncoef, newcoefs,
                                      newspld, model) ;
          }
          else
          {
            y2       = Alloc_FL64ARRAY(ncoef) ;
            newcoefs = coefs ;
            newspld  = spld ;
          }
          
          if (model != SPLINEF)
                Math_Cspl_Prep(newspld, newcoefs, ncoef, SPLINE_MAX * 1.1,
                               SPLINE_MAX * 1.1, y2) ;
            else
                Math_Cspl_Prep(newspld, newcoefs, ncoef, 0.0, 0.0, y2) ;

            for (i = 1 ; i < nshow ; i++)
            {
                term    = Cldr_TermBetweenDates(&pday[0], &pday[i],
                                                0, cal, LAST, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
                term    = GETMAX(MIN_TERM, term) ;
                pf64[i] = Zero_splines(newcoefs, newspld, y2, ncoef, model,
                                       term, 0.0) ;
            }

          if (use_prep)
          {
            Free_FL64ARRAY(newcoefs) ;
            Free_FL64ARRAY(newspld) ;
          }
          Free_FL64ARRAY(y2) ;
          break ;

        default:
          ;
    }

    return disc ;
}


/*,,SOH,,
*************************************************************************
*
*                Zero_Model2Price()
*
*    interface   #include <fitzero.h>
*                FL64 Zero_Model2Price(FL64ARRAY coefs,
*                                      FL64ARRAY spld,
*                                      BOOLE     use_prep,
*                                      INTI      ncoef,
*                                      ZEROMODEL model,
*                                      PMT_STR   *pmt,
*                                      FL64      spread,
*                                      RISKCONV  risk,
*                                      FL64      *dp,
*                                      FL64      *ddp) ;
*
*    general     The function calculates the price and risk ratios
*                for a cashflow given a set of Term Structure model
*                parameters.
*
*                These parameters may be given in by 'hand' or could
*                have been estimated using Zero_Fit_TS()
*
*                The yields corresponding to the coefficients are quoted
*                as continuous rates.
*
*                The risk ratios are calculated using these continuous
*                rates, so the risk ratios must be interpreted as
*                the sensitivity against changes in the continuous rate.
*                For other risk ratios use Zero_GenrTS() followed by
*                TVM_Zero2Price().
*
*                Please note that since our implementation of the models
*                are handling some numerical issues - the parameters
*                cannot always be interpreted as the theoretical ones.
*                So this function expects the coefficients to be in a
*                specific format - eg. as returned by Zero_Fit_TS().
*
*    input       FL64ARRAY coefs      The coefficient array.
*                                     Array with ncoef elements.
*
*                FL64ARRAY spld       The spline terms.
*                                     Array with ncoef elements of terms
*                                     in fractional years.
*                                     Only needed for the spline models.
*                                     Sorted in ascending order and
*                                     positive numbers.
*
*                BOOLE     use_prep   Specifies if the function Zero_prep
*                                     _splines() is used (True) or not 
*                                     (False). Using Zero_prep_splines 
*                                     might stabilize the two ends of the
*                                     spline. The setting of this 
*                                     parameter must be the same as when
*                                     the model was calibrated. Only used
*                                     if model is SPLINEYIELD, SPLINEDISC,
*                                     SPLINEEXPO, SPLINEX, SPLINEF, or 
*                                     SPLINETRANS.  
*
*                INTI      ncoef      No. of elements in coefs/spld
*
*                ZEROMODEL model      The model used.
*
*                PMT_STR   *pmt       The cashflow to be valued.
*
*                FL64      spread     The spread to the term structure
*                                     as continuous compounded yield
*                                     in fractions.
*
*                RISKCONV  risk       The risk specification
*
*    output      FL64      *dp        The dollar duration
*
*                FL64      *ddp       The dollar convexity
*
*    returns     The price as FL64
*
*    diagnostics
*
*    see also    Fit_BSEC2DF()
*                Zero_GenrTS()
*                TVM_Zero2Price()
*
*************************************************************************
,,EOH,,*/


FL64 Zero_Model2Price(FL64ARRAY coefs, FL64ARRAY spld, BOOLE use_prep, 
                      INTI ncoef, ZEROMODEL model, PMT_STR* pmt,
                      FL64 spread, RISKCONV risk, FL64* dp, FL64* ddp)
{
    INTI      npmt, i ;
    FL64      tmp, npv, p, *terms, *payments ;
    FL64ARRAY y2, newcoefs, newspld ;

    tmp = *dp = *ddp = npv = 0.0 ;

    npmt     = pmt->count ;
    payments = pmt->payment ;
    terms    = pmt->term ;

    switch (model)
    {
        case BSPLYLD :

            newspld = Zero_prep_BSPLYLD(spld, ncoef) ;

            for (i = 0 ; i < npmt ; i++)
            {
                p    = payments[i] * Zero_BSPLYLD(coefs, newspld, ncoef,
                                                  terms[i], spread) ;
                npv += p ;

                if (risk != ZERO_ORDER)
                {
                    tmp  = terms[i] * p ;
                    *dp += tmp ;
                }

                if (risk == SECOND_ORDER)
                    *ddp += terms[i] * tmp ;
            }


            Free_FL64ARRAY(newspld) ;
            break ;

        case BRNSTYLD :

            for (i = 0 ; i < npmt ; i++)
            {
                p    = payments[i] * Zero_BRNSTYLD(coefs, ncoef,
                                                   spld[ncoef - 1],
                                                   terms[i], spread) ;
                npv += p ;

                if (risk != ZERO_ORDER)
                {
                    tmp  = terms[i] * p ;
                    *dp += tmp ;
                }
                if (risk == SECOND_ORDER)
                    *ddp += terms[i] * tmp ;
            }
            break ;

        case VASICEK :

            for (i = 0 ; i < npmt ; i++)
            {
                p    = payments[i] * Zero_vasicek(coefs, terms[i], spread) ;
                npv += p ;

                if (risk != ZERO_ORDER)
                {
                    tmp  = terms[i] * p ;
                    *dp += tmp ;
                }
                if (risk == SECOND_ORDER)
                    *ddp += terms[i] * tmp ;
            }
            break ;

        case CIR :

            for (i = 0 ; i < npmt ; i++)
            {
                p    = payments[i] * Zero_cir(coefs, terms[i], spread) ;
                npv += p ;

                if (risk != ZERO_ORDER)
                {
                    tmp  = terms[i] * p ;
                    *dp += tmp ;
                }
                if (risk == SECOND_ORDER)
                    *ddp += terms[i] * tmp ;
            }
            break ;

        case CIRNOM :

            for (i = 0 ; i < npmt ; i++)
            {
                p    = payments[i] * Zero_cirnom(coefs, terms[i], spread) ;
                npv += p ;

                if (risk != ZERO_ORDER)
                {
                    tmp  = terms[i] * p ;
                    *dp += tmp ;
                }
                if (risk == SECOND_ORDER)
                    *ddp += terms[i] * tmp ;
            }
            break ;

        case LONGSCH :

            for (i = 0 ; i < npmt ; i++)
            {
                p    = payments[i] * Zero_longsch(coefs, terms[i], spread) ;
                npv += p ;

                if (risk != ZERO_ORDER)
                {
                    tmp  = terms[i] * p ;
                    *dp += tmp ;
                }
                if (risk == SECOND_ORDER)
                    *ddp += terms[i] * tmp ;
            }
            break ;

        case CCW :

            for (i = 0 ; i < npmt ; i++)
            {
                p    = payments[i] * Zero_ccw(coefs, ncoef, terms[i], spread) ;
                npv += p ;

                if (risk != ZERO_ORDER)
                {
                    tmp  = terms[i] * p ;
                    *dp += tmp ;
                }
                if (risk == SECOND_ORDER)
                    *ddp += terms[i] * tmp ;
            }
            break ;

        case IYEXT :

            for (i = 0 ; i < npmt ; i++)
            {
                p    = payments[i] * Zero_iyext(coefs, terms[i], spread) ;
                npv += p ;

                if (risk != ZERO_ORDER)
                {
                    tmp  = terms[i] * p ;
                    *dp += tmp ;
                }
                if (risk == SECOND_ORDER)
                    *ddp += terms[i] * tmp ;
            }
            break ;

        case EXTNS :

            for (i = 0 ; i < npmt ; i++)
            {
                p    = payments[i] * Zero_extns(coefs, terms[i], spread) ;
                npv += p ;

                if (risk != ZERO_ORDER)
                {
                    tmp  = terms[i] * p ;
                    *dp += tmp ;
                }
                if (risk == SECOND_ORDER)
                    *ddp += terms[i] * tmp ;
            }
            break ;

        case DPOLY :

            for (i = 0 ; i < npmt ; i++)
            {
                p    = payments[i] * Zero_dpoly(coefs, ncoef, terms[i], spread);
                npv += p ;

                if (risk != ZERO_ORDER)
                {
                    tmp  = terms[i] * p ;
                    *dp += tmp ;
                }
                if (risk == SECOND_ORDER)
                    *ddp += terms[i] * tmp ;
            }
            break ;

        case SPLINEYIELD :
        case SPLINEDISC  :
        case SPLINEEXPO  :
        case SPLINEX :
        case SPLINEF :
        case SPLINETRANS :
          
          if (use_prep)
          {
            newcoefs = Alloc_FL64ARRAY(ncoef + 4) ;
            newspld  = Alloc_FL64ARRAY(ncoef + 4) ;
            y2       = Alloc_FL64ARRAY(ncoef + 4) ;

            ncoef = Zero_prep_splines(coefs, spld, ncoef, newcoefs,
                                      newspld, model) ;
          }
          else
          {
            y2       = Alloc_FL64ARRAY(ncoef) ;
            newcoefs = coefs ;
            newspld  = spld ;
          }
          
          if (model != SPLINEF)
            Math_Cspl_Prep(newspld, newcoefs, ncoef, SPLINE_MAX*1.1,
                           SPLINE_MAX*1.1, y2) ;
          else
            Math_Cspl_Prep(newspld, newcoefs, ncoef, 0.0, 0.0, y2) ;

          for (i = 0 ; i < npmt ; i++)
          {
              p = payments[i] * Zero_splines(newcoefs, newspld, y2,
                                             ncoef, model,
                                             terms[i], spread) ;
              npv += p ;

              if (risk != ZERO_ORDER)
              {
                  tmp  = terms[i] * p ;
                  *dp += tmp ;
              }
              if (risk == SECOND_ORDER)
                  *ddp += terms[i] * tmp ;
          }

          if (use_prep)
          {
            Free_FL64ARRAY(newcoefs) ;
            Free_FL64ARRAY(newspld) ;
          }
          Free_FL64ARRAY(y2) ;
          break ;

        default:
          ;
    }

    *dp  *= -1.0 ;
    *dp  /= 100.0 ;
    *ddp /= 10000.0 ;

    return npv ;
}



#undef SMALLSTEP
#undef MAXTA
#undef MIN_TERM

#include <sccsid.h>
SCCSID(tscalio_c,
  "@(#)tscalio.c	1.10 (SimCorp) 99/09/07 16:22:20")

/************************************************************************
*
*   Project     SCecon
*
*   file name   ioutils.c
*
*   general     This file contains file io functions
*
************************************************************************/

/* includes    *********************************************************/
#include <tscalio.h>
#include <ioconv.h>
#include <tscalvl.h>


FILLTYPE Str2FILLTYPE(TEXT txt)
{
    FILLTYPE ft = FILLTYPE_INIT ;

    Str_Uppercase(txt) ;

    if      (!strcmp(txt, "FILLNONE"))   ft = FILLNONE ;
    else if (!strcmp(txt, "FALSE"))      ft = FILLNONE ;
    else if (!strcmp(txt, "FILLALL"))    ft = FILLALL ;
    else if (!strcmp(txt, "TRUE"))       ft = FILLALL ;
    else if (!strcmp(txt, "FILLFRAIRF")) ft = FILLFRAIRF ;
    else
        SCecon_error("Unknown FILLTYPE\n", "str2FILLTYPE()",
                     SCECONABORT) ;

    return ft ;
}


/*
..
*/


ZEROMODEL Str2ZEROMODEL(TEXT txt)
{
    ZEROMODEL unit = ZEROMODEL_INIT ;

    Str_Uppercase(txt) ;

    if      (!strcmp(txt, "CCW"))              unit = CCW ;
    else if (!strcmp(txt, "CIR"))              unit = CIR ;
    else if (!strcmp(txt, "CIRNOM"))           unit = CIRNOM ;
    else if (!strcmp(txt, "DPOLY"))            unit = DPOLY ;
    else if (!strcmp(txt, "IYEXT"))            unit = IYEXT ;
    else if (!strcmp(txt, "EXTNS"))            unit = EXTNS ;
    else if (!strcmp(txt, "SPLINEDISC"))       unit = SPLINEDISC ;
    else if (!strcmp(txt, "SPLDSC"))           unit = SPLINEDISC ;
    else if (!strcmp(txt, "SPLDISC"))          unit = SPLINEDISC ;

    else if (!strcmp(txt, "SPLINEEXPO"))       unit = SPLINEEXPO ;
    else if (!strcmp(txt, "SPLEXP"))           unit = SPLINEEXPO ;

    else if (!strcmp(txt, "SPLINEYIELD"))      unit = SPLINEYIELD ;
    else if (!strcmp(txt, "SPLYLD"))           unit = SPLINEYIELD ;
    else if (!strcmp(txt, "SPLINETRANS"))      unit = SPLINETRANS ;

    else if (!strcmp(txt, "LONGSCH"))          unit = LONGSCH ;
    else if (!strcmp(txt, "VASICEK"))          unit = VASICEK ;
    else if (!strcmp(txt, "BOOTSTRAP"))        unit = BOOTSTRAP ;
    else if (!strcmp(txt, "SPLINEX"))          unit = SPLINEX ;
    else if (!strcmp(txt, "SPLX"))             unit = SPLINEX ;

    else if (!strcmp(txt, "SPLINEF"))          unit = SPLINEF ;
    else if (!strcmp(txt, "BSPLYLD"))          unit = BSPLYLD ;
    else if (!strcmp(txt, "BSPLINES"))         unit = BSPLYLD ;

    else if (!strcmp(txt, "BERNSTEIN"))        unit = BRNSTYLD ;
    else if (!strcmp(txt, "BRNSTYLD"))         unit = BRNSTYLD ;
    else
        SCecon_error("Unknown zero coupon model\n", "Str2ZEROMODEL()", 
            SCECONABORT) ;

    return unit ;
}


/*
..
*/


SMOOTHCRIT Str2SMOOTHCRIT(TEXT txt)
{
    SMOOTHCRIT unit = SMOOTHCRIT_INIT ;

    Str_Uppercase(txt) ;

    if (!strcmp(txt, "FIRSTDIFF"))             unit = FIRSTDIFF ;
    else if (!strcmp(txt, "SECONDDIFF"))       unit = SECONDDIFF ;
    else if (!strcmp(txt, "NO_SMOOTH"))        unit = NO_SMOOTH ;
    else if (!strcmp(txt, "NONE"))             unit = NO_SMOOTH ;
    else
        SCecon_error("Unknown smoothness criterion\n", "Str2SMOOTHCRIT()", 
            SCECONABORT) ;

    return unit ;
}


/*
..
*/


FILLTYPE Read_FILLTYPE(FILE* in, FILE* out, TEXT dscr)
{
    FILLTYPE dfw ;
    CH txb[MAX_KEYWORD_LENGTH];

      /* Comments, if any: */
    if (!IOUtil_ReadComment(in, out))
        Write_Comment(out, dscr);

    Read_TEXT(in, MAX_KEYWORD_LENGTH, txb);
    dfw = Str2FILLTYPE(txb);

    fprintf(out, " %s\n", txb);

    return dfw;
}

/*
..
*/



ZEROMODEL Read_ZEROMODEL(FILE* in, FILE* out, TEXT dscr)
{
    ZEROMODEL irr;
    CH txb[MAX_KEYWORD_LENGTH];

      /* Comments, if any: */
    if (!IOUtil_ReadComment(in, out))
        Write_Comment(out, dscr);

    Read_TEXT(in, MAX_KEYWORD_LENGTH, txb);
    irr = Str2ZEROMODEL(txb);

    fprintf(out, " %s\n", txb);

    return irr;
}


/* 
..
*/


SMOOTHCRIT Read_SMOOTHCRIT(FILE*in , FILE* out, TEXT dscr)
{ 
    SMOOTHCRIT smcrit ;
    CH txb[MAX_KEYWORD_LENGTH];

      /* Comments, if any: */
    if (!IOUtil_ReadComment(in, out))
        Write_Comment(out, dscr);

    Read_TEXT(in, MAX_KEYWORD_LENGTH, txb);
    smcrit = Str2SMOOTHCRIT(txb);

    fprintf(out, " %s\n", txb);

    return smcrit;
}


/* 
..
*/


SMOOTHPARMS Read_SMOOTHPARMS(FILE*in , FILE* out, TEXT dscr)
{ 
    SMOOTHPARMS smparms ;
    COUNT format ;
    
    /* Comments, if any: */
    if (!IOUtil_ReadComment(in, out))
        Write_Comment(out, dscr);

    format = Read_FormatId(in, out) ;

    switch (format)
    {
    case 1: /* Simplest possible */
        smparms = Set_SMOOTHPARMS(NO_SMOOTH, 0.0, NULL) ;
        break ;

    case 2:
        smparms.smcrit  = Read_SMOOTHCRIT(in, out, " Smoothness criterion ");
        smparms.lambda  = Read_FL64(in, out, " Lambda ") ;
        smparms.tlambda = Read_PLANARRAY(in);        
        Write_PLANARRAY(out, smparms.tlambda);
        break;
    }

  Write_VALIDATEError(out, Validate_SMOOTHPARMS(&smparms));

  return smparms ;
}


/*
..
*/


ZEROPARMS Read_ZEROPARMS(FILE*  in, FILE*  out)
{
    ZEROPARMS zerop;
    COUNT format, i;

    format = Read_FormatId(in, out) ;

    switch (format)
    {
    case 1:
        zerop.model    = Read_ZEROMODEL(in, out, "   Model  ");
        zerop.ncoef    = Read_INTI(in, out, "  No. of coefficients ");
        zerop.parms    = Alloc_FL64ARRAY(zerop.ncoef) ;
        zerop.bounds   = Alloc_FL64MATRIX(zerop.ncoef, 2) ;
        zerop.spld     = Alloc_FL64ARRAY(zerop.ncoef) ;
        zerop.use_prep = True ;

        fprintf(out,
            "   Model data:\n      Coefs  Spldates   Low       Up\n");

        for (i = 0; i < zerop.ncoef; i++)
        {
            fscanf(in, "%lf %lf %lf %lf",
                &zerop.parms[i], &zerop.spld[i], &zerop.bounds[i][0], 
                &zerop.bounds[i][1]) ;
            fprintf(out,"   %8.5lf  %8.5lf  %8.5lf  %8.5lf\n",
                zerop.parms[i], zerop.spld[i], zerop.bounds[i][0], 
                zerop.bounds[i][1]) ;
        }
        break;

    case 2:

        zerop.model    = Read_ZEROMODEL(in, out, "   Model  ");
        zerop.ncoef    = Read_INTI(in, out, "  No. of coefficients ");
        zerop.parms    = Alloc_FL64ARRAY(zerop.ncoef) ;
        zerop.bounds   = Alloc_FL64MATRIX(zerop.ncoef, 2) ;
        zerop.spld     = Alloc_FL64ARRAY(zerop.ncoef) ;

        fprintf(out,
            "   Model data:\n      Coefs  Spldates   Low       Up\n");

        for (i = 0; i < zerop.ncoef; i++)
        {
            fscanf(in, "%lf %lf %lf %lf",
                &zerop.parms[i], &zerop.spld[i], &zerop.bounds[i][0], 
                &zerop.bounds[i][1]) ;
            fprintf(out,"   %8.5lf  %8.5lf  %8.5lf  %8.5lf\n",
                zerop.parms[i], zerop.spld[i], zerop.bounds[i][0], 
                zerop.bounds[i][1]) ;
        }

        zerop.use_prep = Read_BOOLE(in, out, " Use prep spline? ");
        break;

    }

    Write_VALIDATEError(out, Validate_ZEROPARMS(&zerop));

    return zerop;
}



/*
..
*/


CRITERIONFUNC Read_CRITERIONFUNC(FILE*  in, FILE*  out)
{
    CRITERIONFUNC cfunc;
    COUNT format ;

    format = Read_FormatId(in, out) ;

    switch (format)
    {
    case 1: /* Simplest possible */
        cfunc.norm            = 1 ;
        cfunc.doMacaulay      = True ;
        cfunc.noweights       = 0 ;
        cfunc.weights         = NULL ; 
        cfunc.docold          = False ;
        cfunc.bidask          = False ;
        cfunc.smparms = Set_SMOOTHPARMS(NO_SMOOTH, 0.0, NULL) ;
        break ;

    case 2: /* This case correspons to the old situation */
        cfunc.norm            = 1 ;
        cfunc.doMacaulay      = Read_BOOLE(in, out, " Duration weights? ") ;
        cfunc.noweights       = 0 ;
        cfunc.weights         = NULL ; 
        cfunc.docold          = Read_BOOLE(in, out, " Cold optimization? ") ;
        cfunc.bidask          = False ;
        cfunc.smparms = Set_SMOOTHPARMS(NO_SMOOTH, 0.0, NULL) ;
        break ;

    case 3: /* More freedom in the specification */

        cfunc.norm            = 1 ;
        cfunc.doMacaulay      = Read_BOOLE(in, out, " Duration weights? ") ;
        cfunc.docold          = Read_BOOLE(in, out, " Cold optimization? ") ;
        cfunc.weights         = Read_FL64ARRAY(in, &cfunc.noweights) ; 
        cfunc.bidask          = False ;
        cfunc.smparms = Set_SMOOTHPARMS(NO_SMOOTH, 0.0, NULL) ;
        break ;

    case 4: /* Total freedom in the specification */
        cfunc.norm       = Read_INTI(in, out,  "   Optimize in norm     ") ;
        cfunc.doMacaulay = Read_BOOLE(in, out, "   Duration weights?    ") ;
        cfunc.weights    = Read_FL64ARRAY(in, &cfunc.noweights) ; 
        cfunc.docold     = Read_BOOLE(in, out, "   Cold optimization?   ") ;
        cfunc.bidask     = Read_BOOLE(in, out, "   Use bid-ask spread ? ") ;
        cfunc.smparms    = Read_SMOOTHPARMS(in , out, 
                           " Smoothness parameters ") ;
        break ;
    }

    Write_VALIDATEError(out, Validate_CRITERIONFUNC(&cfunc));

    return cfunc;
}



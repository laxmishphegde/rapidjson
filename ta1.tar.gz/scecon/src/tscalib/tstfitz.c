/* SCID @(#)tstfitz.c	1.12 (SimCorp) 99/09/07 16:22:21 */

/************************************************************************
*
*   project     SCecon
*
*   this program tests the routines in the fitzero module of SCecon
*
************************************************************************/

/*** includes ***********************************************************/
#include <string.h>
#include <scalloc.h>
#include <str2conv.h>
#include <fitzero.h>
#include <ioconv.h>
#include <tscalio.h>
#include <bondio.h>


INTI fitztest(char* txa, FILE* in, FILE* out)
{
    char          txb[25], txc[25], txd[25], txpl[100] ;
    INTI          i, ncoef, nts, npmt, nsec, ndates, nfound ;
    INTI          n, diff, dif1, qbas, j, ndays ;
    INTI          nbprices ;
    FL64          oas, fexp, fres, acc, *coefs, *spld, fexp1, fres1, 
                  fexp2, fres2 ;
    FL64          fitacc, **bounds, *prices, *spread, tol, *tstimes,
                  dacc, d1, tc, tcg, *madj, acc1, *bidask, *aprices, 
                  *bprices ;
    FL64MATRIX    corr, loads, parms ;
    PMT_STR       *pmt ;
    PLANARRAY     disc1, disc ;
    DATEARRAY     settle, dates, days ;
    DATESTR       today ;
    BOOLE         err, ok = 0, okexp, use_prep, use_ba = 0 ;
    ZEROMODEL     model ;
    TS_STR        *ts, *ts1 ;
    IRRCONV       irr ;
    RISKCONV      risk ;
    INTL          lg ;
    CALCONV       cal ;
    int           i1, i2, i3 ;
    BSECARRAY     secs1 ;
    YYYYMMDD      ymd ;
    HOLI_STR      holi ;
    DISCFAC       df ;
    ZEROPARMS     zerop ;
    CRITERIONFUNC cfunc ;
    PLAN_STR      dummy ;
    DFPARMS       dfp ;
    ITERCTRL      ictrl ;
    FITPARMS      tsfit ;

    acc  = 0.00001 ;
    dacc = 0.000001 ;

    diff = -1 ;

    if (!strcmp("Zero_GenrTS()", txa))
    {
        fscanf(in, "%d %s %d %s %d %s",
               &i1, txb, &i2, txc, &i3, txpl);
        ncoef = (INTI) i1 ;
        nts = (INTI) i2 ;
        qbas = (INTI) i3 ;

        model = Str2ZEROMODEL(txb) ;
        irr   = Str2IRRCONV(txc) ;

        fprintf(out,"   Testing %s\n", txa) ;
        fprintf(out,"   Model              %11s\n", txb) ;
        fprintf(out,"   Irrconv            %11s\n", txc) ;
        fprintf(out,"   Quoting basis      %11d\n", qbas) ;

        coefs = Alloc_FL64ARRAY(ncoef) ;
        spld  = Alloc_FL64ARRAY(ncoef) ;
        ts    = Alloc_TSARRAY(2, nts) ;

        ts[0].conv  = irr ;
        ts[0].qbas  = qbas ;
        ts[0].count = nts ;

        fprintf(out,"   Model data:\n      Coefs  Spldates\n") ;

        for (i = 0 ; i < ncoef ; i++)
        {
            fscanf(in, "%lf %lf", &coefs[i], &spld[i]) ;
            fprintf(out,"   %8.5lf  %8.5lf\n", coefs[i], spld[i]) ;
        }

        for (i = 0 ; i < nts ; i++)
            fscanf(in, "%lf %lf", &ts[0].term[i], &ts[1].rate[i]) ;

        /* This hard coded value is OK since the feature is tested
        through the calibration routine */
        use_prep = True ;

        ts1 = Zero_GenrTS(coefs, spld, ncoef, model,
                           ts[0].term, nts, irr, qbas, use_prep) ;

        diff = 0 ;

        fprintf(out,"   Result is:\n    Term   Exp.rate   Calc.Rate\n") ;
        for (i = 0 ; i < nts ; i++)
        {
            fres = ts1->rate[i] ;
            fexp = ts[1].rate[i] ;
            dif1 = (fabs(fres - fexp) > acc) ;
            fprintf(out, "%d;  %8.5lf %8.5lf  %8.5lf\n",
                    dif1, ts1->term[i], fexp, fres) ;
            if (dif1)
                diff = 1 ;
        }

        fprintf(out,"   %s\n\n", txpl) ;

        Free_FL64ARRAY(coefs) ;
        Free_FL64ARRAY(spld) ;
        Free_TSARRAY(ts, 2) ;
        Free_TSARRAY(ts1, 1) ;
    }

    else if (!strcmp("Zero_GenrDF()", txa))
    {
        fscanf(in, "%d %s %d %s %s",
               &i1, txb, &i2, txd, txpl);
        ncoef = (INTI) i1 ;
        nts = (INTI) i2 ;

        model = Str2ZEROMODEL(txb) ;
        cal   = Str2CALCONV(txd) ;

        fprintf(out,"   Testing %s\n", txa) ;
        fprintf(out,"   Model              %11s\n", txb) ;
        fprintf(out,"   Calendar           %11s\n", txd) ;

        coefs = Alloc_FL64ARRAY(ncoef) ;
        spld  = Alloc_FL64ARRAY(ncoef) ;
        disc  = Alloc_PLANARRAY(2, nts) ;
        disc[0].count = disc[0].filled = nts ;

        fprintf(out,"   Model data:\n      Coefs  Spldates\n") ;

        for (i = 0 ; i < ncoef ; i++)
        {
            fscanf(in, "%lf %lf", &coefs[i], &spld[i]) ;
            fprintf(out,"   %8.5lf  %8.5lf\n", coefs[i], spld[i]) ;
        }

        for (i = 0 ; i < nts ; i++)
        {
            fscanf(in, "%ld %lf", &lg, &disc[1].f64[i]) ;
            if (i == 0)
                today = Cldr_YMD2Datestr(lg) ;
            else
                disc[0].day[i - 1] = Cldr_YMD2Datestr(lg) ;
        }

        /* This hard coded value is OK since the feature is tested
        through the calibration routine */
        use_prep = True ;

        disc1 = Zero_GenrDF(coefs, spld, ncoef, model, cal,
                            &today, disc[0].day, nts - 1,
                            use_prep, &holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */

        diff = 0 ;

        fprintf(out,"   Result is:\n    Date   Exp.Disc   Calc.Disc\n") ;
        for (i = 0 ; i < nts ; i++)
        {
            fres = disc1->f64[i] ;
            fexp = disc[1].f64[i] ;
            dif1 = (fabs(fres - fexp) > acc) ;
            fprintf(out, "%d;  %8ld %8.5lf  %8.5lf\n",
                    dif1, Cldr_Datestr2YMD(&disc1->day[i]), fexp, fres) ;
            if (dif1)
                diff = 1 ;
        }

        fprintf(out,"   %s\n\n", txpl) ;

        Free_FL64ARRAY(coefs) ;
        Free_FL64ARRAY(spld) ;
        Free_PLANARRAY(disc, 2) ;
        Free_PLANARRAY(disc1, 1) ;
    }

    else if (!strcmp("Fit_Cflw2TS()", txa))
    {
        /* Warning avoidance */
        bidask = NULL;

        fscanf(in, "%d %s %d %d %lf %s",
               &i1, txb, &i2, &i3, &fitacc, txpl);
        ncoef = (INTI) i1 ;
        nsec  = (INTI) i2 ;
        nts   = (INTI) i3 ;

        model = Str2ZEROMODEL(txb) ;

        fprintf(out,"   Testing %s\n", txa) ;
        fprintf(out,"   %s\n", txpl) ;
        fprintf(out,"   Model               %11s\n", txb) ;
        fprintf(out,"   Fit accuracy (rate) %11lf\n", fitacc) ;

        coefs  = Alloc_FL64ARRAY(ncoef) ;
        spld   = Alloc_FL64ARRAY(ncoef) ;
        prices = Alloc_FL64ARRAY(nsec) ;
        spread = Alloc_FL64ARRAY(nsec) ;
        bounds = Alloc_FL64MATRIX(ncoef, 2) ;
        pmt    = Alloc_PMTARRAY(nsec, 100) ;

        fprintf(out,
          "   Model data:\n      Coefs  Spldates   Low       Up\n") ;

        for (i = 0 ; i < ncoef ; i++)
        {
            fscanf(in, "%lf %lf %lf %lf",
                   &coefs[i], &spld[i], &bounds[i][0], &bounds[i][1]) ;
            fprintf(out,"   %8.5lf  %8.5lf  %8.5lf  %8.5lf\n",
                    coefs[i], spld[i], bounds[i][0], bounds[i][1]) ;
        }

        fprintf(out,"\n   Optimization data:\n") ;

        cfunc = Read_CRITERIONFUNC(in, out) ;

        for (i = 0 ; i < cfunc.noweights ; i++)
        {
          fprintf(out,"\n   Bond #%d ", i) ;
          fprintf(out,"   Weight      %9.5lf", cfunc.weights[i]) ;
        }

        fprintf(out,"\n   Bond data:\n") ;

        for (i = 0 ; i < nsec ; i++)
        {
            fscanf(in, "%d %lf %lf", &i1, &prices[i], &spread[i]);
            pmt[i].count = (INTI) i1 ;
            fprintf(out,"\n   Bond #%d\n", i) ;
            fprintf(out,"   Price      %9.5lf\n", prices[i]) ;
            fprintf(out,"   OAS        %9.5lf\n", spread[i]) ;
            for (j = 0 ; j < pmt[i].count ; j++)
            {
                fscanf(in, "%lf %lf", &pmt[i].term[j], &pmt[i].payment[j]) ;
                fprintf(out,"   Term %8.5lf  Payment %9.5lf\n",
                        pmt[i].term[j], pmt[i].payment[j]) ;
            }
        }

        zerop.model    = model ;
        zerop.ncoef    = ncoef ;
        zerop.parms    = coefs ;
        zerop.bounds   = bounds ;
        zerop.spld     = spld ;
        zerop.use_prep = True ;

        Init_ITERCTRL(&ictrl);

        tsfit = Fit_Cflw2TS(&zerop, &cfunc, nsec, pmt, prices, spread, 
                            bidask, NULL, &ictrl) ;

        fprintf(out,"\n   Results:\n") ;
        fprintf(out,"   OK ??       %9d\n", ok) ;
        fprintf(out,"   Objective   %9.5lf\n", tsfit.obj) ;
        fprintf(out,"   Parameters\n") ;
        for (i = 0 ; i < ncoef ; i++)
            fprintf(out,"   Par# %d  value %11.7lf\n", i, tsfit.parms[i]) ;

        ts = Alloc_TSARRAY(2, nts) ;

        ts[0].conv  = COMPOUND ;
        ts[0].qbas  = 1 ;
        ts[0].count = nts ;

        for (i = 0 ; i < nts; i++)
            fscanf(in, "%lf %lf", &ts[0].term[i], &ts[1].rate[i]) ;

        ts1 = Zero_GenrTS(tsfit.parms, spld, ncoef, model,
                          ts[0].term, nts, COMPOUND, 1,
                          zerop.use_prep) ;

        fprintf(out,"\n   The TS is: (annually compounded)\n") ;
        diff = 0 ;
        for (i = 0 ; i < nts; i++)
        {
            dif1 = fabs(ts1->rate[i] - ts[1].rate[i]) > fitacc ;
            fprintf(out,
              "%d; Term %8.5lf  Exp.Rate %8.5lf  Calc.Rate %8.5lf\n",
              
                    dif1, ts1->term[i], ts[1].rate[i], ts1->rate[i]) ;
            if (dif1)
                diff = 1 ;
        }
        fprintf(out,"\n") ;

        Free_FL64ARRAY(coefs) ;
        Free_FL64ARRAY(spld) ;
        Free_FL64ARRAY(prices) ;
        Free_FL64ARRAY(spread) ;
        Free_CRITERIONFUNC(&cfunc) ;
        Free_FL64MATRIX(bounds) ;
        Free_PMTARRAY(pmt, nsec) ;
        Free_TSARRAY(ts, 2) ;
        Free_TSARRAY(ts1, 1) ;
        Free_FL64ARRAY(tsfit.parms) ;
    }

    else if (!strcmp("Fit_BSEC2DF()", txa))
    {
        fprintf(out,"   Testing %s\n", txa) ;

        today = Read_DATESTR(in, out, "   Today   ") ;
        holi  = Read_HOLI_STR(in, out) ;
        dfp   = Read_DFPARMS(in, out) ;
        zerop = Read_ZEROPARMS(in, out) ;
        cfunc = Read_CRITERIONFUNC(in, out) ;
        days  = Read_DATEARRAY(in, out, &ndays) ;
        tc    = Read_FL64(in, out, "   Coupon tax         ") ;
        tcg   = Read_FL64(in, out, "   Capital Gain Tax   ") ;
        n     = Read_INTI(in, out, "   No. of securities ") ;

        secs1   = Alloc_BSECARRAY(n) ;
        aprices = Alloc_FL64ARRAY(n) ;
        spread  = Alloc_FL64ARRAY(n) ;
        madj    = Alloc_FL64ARRAY(n) ;
        settle  = Alloc_DATEARRAY(n) ;

        /* Pure safety check */
        if (zerop.model == BOOTSTRAP)
          cfunc.bidask = False ;

        for (i = 0 ; i < n ; i++)
          {
            fprintf(out, "SECURITY              %8d\n", (int) (i + 1)) ;
            secs1[i] = Read_BSEC(in, out, &aprices[i], &spread[i],
                                 &madj[i], &settle[i]) ;
            
            if (secs1[i].type == BOND || secs1[i].type == BONDSMPL)
                secs1[i].fixp.tax = Set_TAXINFO(tc, tcg, aprices[i], False) ;
          }

        /* Get bid prices if any */
        bprices = Read_FL64ARRAY(in, &nbprices) ; 

        if (nbprices > 0)
          use_ba = True;

        if (n != nbprices)
        {
          cfunc.bidask = False ;
          use_ba = False ;
        }

        Init_ITERCTRL(&ictrl);
        /* to do */
        err = Fit_BSEC2DF(&today, &zerop, &cfunc, n, secs1, use_ba, aprices, 
                          bprices, spread, madj, NULL, settle, &holi, days, 
                          ndays, &ictrl, &dfp, &df, &tsfit) ;
        disc = df.disc ;

        IOUtil_ParseLine(in, out);

        dummy.filled = 0 ;
        ts = Disc_DF2TS(df.disc->day, df.disc->filled, &df,
            &dummy, COMPOUND, ANNUALLY, &holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */

        disc1 = Read_PLANARRAY(in);

        diff = 0 ;
        fprintf(out, "\n") ;

        if (err != True)
        {
            fprintf(out,"1; Something wrong - could not calibrate\n") ;
            diff = 1 ;
        }
        else if (GetPlanFill(disc) == GetPlanFill(disc1))
        {
            fprintf(out,"   Obj %lf\n", tsfit.obj) ;
            fprintf(out,
              "   Exp.date  Exp.disc  Comp.date Comp.disc  Comp.Rate\n")
              ;

            for (i = 0 ; i < GetPlanFill(disc1); i++)
            {
                d1 = disc1->f64[i] ;
                dif1 = (fabs(d1 - disc[0].f64[i]) > dacc) ;
                ymd  = Cldr_Datestr2YMD(&disc1->day[i]) ;
                dif1 = dif1 ||
                       (Cldr_Datestr2YMD(&disc->day[i]) - ymd) != 0;
                fprintf(out, "%d; %ld %1.8lf %ld %1.8lf %8.5lf\n",
                        (int) dif1, ymd, d1, 
                        Cldr_Datestr2YMD(&disc[0].day[i]),
                        disc[0].f64[i], ts->rate[i]) ;
                diff = diff || dif1 ;
            }
        }
        else
        {
            diff = 1 ;
            fprintf(out, "You expected %d entries, we found %d\n",
                    GetPlanFill(disc1), GetPlanFill(disc)) ;

            fprintf(out, "\nOur results\n") ;
            for (i = 0 ; i < GetPlanFill(disc); i++)
                fprintf(out, "    %ld %1.8lf\n",
                        Cldr_Datestr2YMD(&disc[0].day[i]), disc[0].f64[i]);
        }

        Free_PLANARRAY(disc, 1) ;
        Free_PLANARRAY(disc1, 1) ;
        Free_DATEARRAY(settle) ;
        Free_FL64ARRAY(madj) ;
        Free_FL64ARRAY(aprices) ;
        Free_FL64ARRAY(bprices) ;
        Free_FL64ARRAY(spread) ;
        Free_BSECARRAY(secs1) ;
        Free_HOLI_STR(&holi);
        Free_DATEARRAY(days);
        Free_ZEROPARMS(&zerop) ;
        Free_CRITERIONFUNC(&cfunc) ;
        Free_TSARRAY(ts, 1) ;
        Free_FL64ARRAY(tsfit.parms) ;
    }

    else if (!strcmp("Zero_Model2Price()", txa))
    {
        fscanf(in, "%lf %lf %lf %d %s %d %lf %s %s",
               &fexp, &fexp1, &fexp2, &i1, txb, &i2, &oas, txc, txpl);
        ncoef = (INTI) i1 ;
        npmt = (INTI) i2 ;

        model = Str2ZEROMODEL(txb) ;
        risk  = Str2RISKCONV(txc) ;

        fprintf(out,"   Testing %s\n", txa) ;
        fprintf(out,"   Model          %13s\n", txb) ;
        fprintf(out,"   Risk           %13s\n", txc) ;
        fprintf(out,"   OAS            %8.5lf\n", oas) ;

        coefs = Alloc_FL64ARRAY(ncoef) ;
        spld  = Alloc_FL64ARRAY(ncoef) ;
        pmt   = Alloc_PMTARRAY(1, npmt) ;

        fprintf(out,"   Model data:\n      Coefs  Spldates\n") ;

        for (i = 0 ; i < ncoef ; i++)
        {
            fscanf(in, "%lf %lf", &coefs[i], &spld[i]) ;
            fprintf(out,"   %8.5lf  %8.5lf\n", coefs[i], spld[i]) ;
        }

        fprintf(out,"   CashFlow:\n      Terms  Payments\n") ;

        pmt[0].count = npmt ;
        for (i = 0 ; i < npmt ; i++)
        {
            fscanf(in, "%lf %lf", &pmt[0].term[i], &pmt[0].payment[i]) ;
            fprintf(out,"   %8.5lf  %8.5lf\n",
                    pmt[0].term[i], pmt[0].payment[i]) ;
        }

        /* This hard coded value is OK since the feature is tested
        through the calibration routine */
        use_prep = True ;

        fres = Zero_Model2Price(coefs, spld, use_prep, ncoef, model, 
                                pmt, oas, risk, &fres1, &fres2) ;

        diff = fabs(fres - fexp) > acc   ||
               fabs(fres1 - fexp1) > acc ||
               fabs(fres2 - fexp2) > acc ;

        fprintf(out,"%d; Result is %9.5lf ; expected is %9.5lf\n",
                fabs(fres - fexp) > acc, fres, fexp) ;
        fprintf(out,"%d; Result is %9.5lf ; expected is %9.5lf\n",
                fabs(fres1 - fexp1) > acc, fres1, fexp1) ;
        fprintf(out,"%d; Result is %9.5lf ; expected is %9.5lf\n",
                fabs(fres2 - fexp2) > acc, fres2, fexp2) ;

        fprintf(out,"   %s\n\n", txpl) ;

        Free_FL64ARRAY(coefs) ;
        Free_FL64ARRAY(spld) ;
        Free_PMTARRAY(pmt, 1) ;
    }

    else if (!strcmp("Zero_Model2Factors()", txa))
    {
        fprintf(out,"   Testing %s\n", txa) ;

        model = Read_ZEROMODEL(in, out, "  Zero model    ") ;

        fprintf(out, "  Model dates:   ");
        dates = Read_DATEARRAY(in, out, &ndates);

        fprintf(out, "  Model parms:   ");
        parms = Read_FL64MATRIX(in, out, &ndates, &ncoef);

        fprintf(out, "  Model splines: ");
        spld = Read_FL64ARRAY(in, &ncoef);
        Write_FL64ARRAY(out, spld, ncoef);

        tol = Read_FL64(in, out, "  Tolerance   ");
        fprintf(out, "  Loading terms: ");
        tstimes = Read_FL64ARRAY(in, &nts);
        Write_FL64ARRAY(out, tstimes, nts);

        loads = Alloc_FL64MATRIX(nts, nts) ;
        corr = Alloc_FL64MATRIX(nts + 1, nts) ;
        okexp = Read_BOOLE(in, out, "  Exp status   ");
        acc1 = Read_FL64(in, out, "  Accept tolerance   ");

        /* This hard coded value is OK since the feature is tested
        through the calibration routine */
        use_prep = True ;

        ok = Zero_Model2Factors(model, dates, parms, ndates, 
            ncoef, spld, tstimes, nts, tol, use_prep, loads, corr, 
            &nfound);

        IOUtil_ParseLine(in, out);

        fprintf(out, "  Loadings:\n");
        diff = Write_FL64MATRIXdiff(in, out, ok, loads, nts, 
          nfound, okexp, acc1);

        fprintf(out, "  Correlations:\n");
        diff = Write_FL64MATRIXdiff(in, out, ok, corr, nts+1, 
          nfound, okexp, acc1) || diff;

        Free_FL64MATRIX(parms) ;
        Free_FL64MATRIX(loads) ;
        Free_FL64MATRIX(corr) ;
        Free_DATEARRAY(dates) ;
        Free_FL64ARRAY(spld) ;
        Free_FL64ARRAY(tstimes) ;
    }

    return diff ;
}

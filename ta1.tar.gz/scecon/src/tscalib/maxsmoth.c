/* SCID @(#)maxsmoth.c	1.11 (SimCorp) 99/10/27 15:26:18  */

/***********************************************************************
*
*       project         SCecon Library
*
*       file name       maxsmoth.c
*
*       contains        maximum smoothness discount function fitter
*
************************************************************************/

/*** includes **********************************************************/
#include <bootstrp.h>
#include <mm.h>



/*,,SOH,,
************************************************************************
*
*               MaxSmooth_BSEC2DF()
*
*   interface   #include <bootstrp.h>
*               BOOLE MaxSmooth_BSEC2DF(DATESTR    *today,
*                                  FL64ARRAY  quotes,
*                                  BSECARRAY  secs,
*                                  FL64       psmooth,   
*                                  FL64ARRAY  spread,
*                                  FL64ARRAY  madj,
*                                  FL64ARRAY  pricesX,
*                                  DATEARRAY  settl,
*                                  INTI       nsec,
*                                  HOLI_STR   *holi,
*                                  DFPARMS    *dfp,
*                                  DISCFAC    *df,
*                                  FL64       *smooth) ;
*
*   general     The function fits the forward rates required to price
*               the given securities so that maximum smoothness of the
*               forward rates is obtained.
*
*               Smoothness is measured by the first order derivative
*               of 'certain' forward rates wrt time as suggested by
*
*               V Firshling and J Yamamura,
*               "Fitting a Smooth Forward Rate Curve to Coupon Instruments",
*               J. Fixed Income, September 1996
*
*               By this method a discount function is constructed
*               containing all dates relevant (eg. all coupon dates for
*               par swaps) to the specified securities. The smoothness
*               is then measured using the continuously compounded
*               forward rates between these dates. Alternatively the
*               dates can be supplied by the user.
*
*               The function uses bootstrapping techniques to generate
*               the discount function. In doing so holidays, calendars
*               and other market conventions are respected.
*
*               Upon exit the first element in the discount function is
*               start with a discount factor 1.0.
*
*               The issue of credit quality of the individual securities
*               is handled via the spread. A nonzero spread implies that
*               the curve being bootstrapped is of a different credit
*               quality than this specific bond. For further details
*               on spreads refer to Boot_BSEC2DF().
*
*               The function returns True if all is OK, and False if
*               not. If False is returned, all disc.factors up to
*               nfilled - 1 are OK.
*
*               The routine handles individual settle periods. I.e some
*               contracts settle in 2 days and others 'today' or in 7
*               days. The resulting discount factors are anchored on
*               start.
*
*               When using individual settle days, it must be recalled
*               that some security must link the discount factors on
*               start to the factors on the settle days. Therefore a
*               cash (MM) instrument must be used to this purpose.
*               If no such instrument is available the start date must
*               be on the nearest settleday.
*
*   input       DATESTR   *today   The start date for the disc.function
*
*               FL64ARRAY quotes   The list of prices for the securiti-
*                                  es in secs (nsec prices sorted
*                                  similarly). The prices are quoted as:
*
*                                     MM   - Annual rate (%)
*                                     FRA/IMMFRA  - Annual rate (%)
*                                     SWAP/SWAPGENR - Annual rate (%)
*                                     IRF  - Price (%)
*                                     BOND/BONDSMPL - Clean price (%)
*                                     AVGIRF - Futures Price (%)
*                                     BONDREPO - Bond spot price (%)
*
*                                  The bond future could be adjusted for
*                                  a conversion factor (CTD).
*                                  Dimension [nsec]
*
*               BSECARRAY secs     The list of securities to use for
*                                  bootstrapping (nsec securities).
*                                  Dimension [nsec]
*
*               FL64      psmooth  This parameter controls the trade-off
*                                  between goodness-of-fit and smoothness.
*                                  Large values (e.g. 10000) emphasize 
*                                  goodness-of-fit and small values (e.g 1)
*                                  emphasize smoothness. 
*
*               FL64ARRAY spread   The list of spreads for the securiti-
*                                  es in secs (nsec prices sorted
*                                  similarly). The spreads are quoted
*                                  as (%)
*
*                                  MM   - Annual Moneymarket rate
*                                  FRA/IMMFRA  - Annual Moneymarket rate
*                                  IRF  - Annual Moneymarket rate
*                                  SWAP/SWAPGENR - Ann compound rate
*                                  BOND/BONDSMPL - Ann compound rate
*                                  BONDREPO - Annually compounded
*
*                                  Enter NULL if not used (default is 0)
*                                  Dimension [nsec]|NULL
*
*               FL64ARRAY madj     Margin adjustment. Only used for an
*                                  IRF. List with nsec entries.
*                                  Calculate with Boot_*2MarginAdj().
*                                  Enter NULL if not used (default is 0)
*                                  Dimension [nsec]|NULL
*
*               FL64ARRAY pricesX  Extra price for some securities:
*
*                                     SWAP - FloatLeg PV. Default is 100
*                                     BONDREPO - Bond forward price
*                                                times Conversion Factor
*
*                                  List with nsec entries or NULL.
*                                  Dimension [nsec]|NULL
*
*               DATEARRAY settl    List of contract settlement dates.
*                                  Array with nsec entries.
*                                  Each security in secs may have an
*                                  individual settlement day (e.g 2 or
*                                  3 days in the future).
*                                  These days are not to be confused
*                                  with FRAsettlement etc, ie. the days
*                                  on which FRA/IRF's expire.
*                                  Any settle day must satisfy:
*
*                                       start <= settle[i]
*
*                                  Dimension [nsec]
*
*               INTI      nsec     The number of securities in prices,
*                                  spread, settle, madj and secs.
*
*               HOLI_STR  *holi    Container for data on business
*                                  day convention and non-week-end
*                                  holidays.
*
*               DFPARMS   *dfp     Definition of interpolation setup.
*
*   output      DISCFAC   *df      The discount function setup.
*                                  If NON-restarting is done then
*                                  the disc element is allocated in this
*                                  routine as:
*
*                                     disc = Alloc_PLANARRAY(1, count)
*
*                                  where count is a number returned in
*                                  disc[0].count.
*                                  The discount function is a
*                                  mathematical solution allowing
*                                  negative forward rates
*
*               FL64      *smooth  Smoothness of the forward rates in
*                                  df.
*
*   returns     True if all is OK, False if not.
*
*   diagnostics
*
*   see also    Boot_BSEC2DF()
*               Fit_BSEC2DF()
*               Boot_BH2MarginAdj()
*               Boot_PCPAR2MarginAdj()
*               Boot_LOG2MarginAdj()
*               SwapFix_BONDSWAPSPR2CFrate()
*               SwapFix_FUTSWAPSPR2CFrate()
*
*   wrapper     AP
*
************************************************************************
,,EOH,,*/

BOOLE MaxSmooth_BSEC2DF(DATESTR*     today,
                        FL64ARRAY    quotes,
                        BSECARRAY    secs,
                        FL64         psmooth,
                        FL64ARRAY    spread,
                        FL64ARRAY    madj,
                        FL64ARRAY    pricesX,
                        DATEARRAY    settl,
                        INTI         nsec,
                        HOLI_STR*    holi,
                        DFPARMS*     dfp,
                        DISCFAC*     df,
                        FL64*        smooth)
{
  FL64          d, eps, *ppx, guess, up, low ;
  FL64ARRAY     w, l1constr, rhside ;
  INTI          i, j, k, ncons, ncoef ;
  integer       icontr, cc ;
  MAXSMOOTHINT  sDATA;
  VOIDPTR       data;
  BOOLE         ok;

  DATEARRAY  discdates, tmpdates;
  FL64ARRAY  forwrates, terms, discfacs;
  INTI       ndisc;
  CFLWARRAY  cflws, tmp;
  FL64       pvX;

  cflws = (CFLWARRAY) SCecon_calloc(nsec, sizeof(CFLW_STR), True, "MaxSmooth_BSEC2DF");

  for (i = 0; i < nsec; i++)
  {
    pvX = GetArrayEl(pricesX, i, nsec, 100.0) ;
    tmp = BSEC_GenrCflw(&secs[i], quotes[i], pvX, holi, &settl[i]);

    cflws[i] = *tmp;
    SCecon_free(tmp);
  }

  discdates = Alloc_DATEARRAY(1);
  ndisc = 1;
  discdates[0] = *today;

  for (i = 0; i < nsec; i++)
  {
    tmpdates = Cldr_MergeDates(discdates, ndisc, 
                               cflws[i].days, cflws[i].filled,
                               &ndisc);
    Free_DATEARRAY(discdates);
    discdates = tmpdates;
  }

  Cldr_DateSort(ndisc, discdates, ASCENDING);

  forwrates = Alloc_FL64ARRAY(ndisc - 1);
  terms     = Alloc_FL64ARRAY(ndisc - 1);
  discfacs  = Alloc_FL64ARRAY(ndisc);
  
  for (i = 0; i < ndisc - 1; i++)
    terms[i] = Cldr_TermBetweenDates(&discdates[i], &discdates[i + 1], 0,
                                  dfp->cal, LAST, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */

  *df = Set_DISCFAC(NULL, dfp->what, dfp->iconv, dfp->cal, dfp->irr, 
                    dfp->freq);

  df->disc = (PLAN_STR*) SCecon_calloc(1, sizeof(PLAN_STR), True, "MaxSmooth_BSEC2DF") ;
  df->disc->filled = df->disc->count = ndisc;
  df->disc->f64 = discfacs;
  df->disc->day = discdates;
  
  data = (VOIDPTR) &sDATA;

  sDATA.holi       = *holi;
  sDATA.bseca      = secs;
  sDATA.cflws      = cflws;
  sDATA.settl      = settl;
  sDATA.quotes     = quotes;
  sDATA.spread     = spread;
  sDATA.madj       = madj;
  sDATA.pricesX    = pricesX;
  sDATA.terms      = terms;
  sDATA.smoothness = psmooth ;
  sDATA.df         = *df;

  ncoef    = ndisc - 1;
  ncons    = 2 * ncoef ;
  l1constr = Alloc_FL64ARRAY(ncoef * ncons + 1) ;
  rhside   = Alloc_FL64ARRAY(2 * ncoef + 1) ;
  w        = Alloc_FL64ARRAY(800000) ;

  /* Set constraints */
  guess = 5.0;
  up = 50.0;
  low = 0.001;

  k = 0 ;
  for (i = 0 ; i < ncoef ; i++)
  {
    forwrates[i]    = guess;

    j               = i * ncons + 2 * i ;
    l1constr[j]     = 1.0 ;
    l1constr[j + 1] = -1.0 ;

    /* Lower bound: (with sign reversed) */
    rhside[k++] = - low ;
    /* Upper bound: */
    rhside[k++] = up ;
  }

  cc     = 500 ;
  d      = 0.1 ;
  eps    = 0.0001 ;
  icontr = 1 ;

  /* Optimize */
  ppx = forwrates ;
  nsec++ ;

  /* Note the cast to Harwell types */
  mi0cl1(MaxSmooth_Harwell, (integer) ncoef, (integer) nsec,
         (integer) ncons, (integer) 0, rhside, l1constr,
         ppx, &d, &eps, &cc, w, 800000, &icontr, data) ;

  /* Compute objective */
  if (icontr < 0 || icontr > 2)
  {
      ok      = False;
      *smooth = 100000.0 ;
  }
  else
  {  
      ok      = True;
      *smooth = 0.0 ;
      /* In some cases the optimizer changes the parameters
      slightly after the last function evaluation - hence
      an extra call is necessary */
      MaxSmooth_Harwell(&ncoef, &nsec, ppx, data, w);
      /* This measure includes smoothnes and goodness-of-fit in
      order to be consistent with Fit_BSEC2DF(.) */
      for (i = 0; i < nsec ; i++)
        *smooth += w[i] ;
  }

  nsec-- ;
  Free_FL64ARRAY(l1constr);
  Free_FL64ARRAY(rhside);
  Free_FL64ARRAY(w);
  Free_FL64ARRAY(terms);
  Free_FL64ARRAY(forwrates);
  Free_CFLWARRAY(cflws, nsec);

  return ok;
}


void FRA_Dates(DATESTR*   settl,
               INTI       term1,
               INTI       term2,
               TERMUNIT   unit,
               BOOLE      nest,
               CALCONV    cal,
               EOMCONV    eom,
               HOLI_STR*  hol,
               DATESTR*   start,
               DATESTR*   maturity)
{
  DATESTR day1;
  SEQCONV roll;
  PERIOD  per;

  day1  = Cldr_NextBusinessDate(settl, hol) ;
  roll  = (nest == True ? CHAIN : ANCHOR) ;
  per   = Set_PERIOD(term1, unit) ;
  *start = Cldr_NextROLL(&day1, roll, &per, cal, eom, hol) ;

  if (roll == CHAIN)
  {
      per       = Set_PERIOD(term2 - term1, unit) ;
      *maturity = Cldr_NextROLL(start, roll, &per, cal, eom, hol) ;
  }
  else
  {
      per       = Set_PERIOD(term2, unit) ;
      *maturity = Cldr_NextROLL(&day1, roll, &per, cal, eom, hol) ;
  }
}


/* AVGIRG is not supported! */
CFLW_STR* BSEC_GenrCflw(BSEC*      bsec, 
                        FL64       quote,
                        FL64       priceX,
                        HOLI_STR*  holi,
                        DATESTR*   settl)
{
  DATESTR   start, matur;
  PERIOD    per;
  CFLW_STR* cflw;
  TRADEINFO tr1, tr2;
  FIXPAY    fixp;
  SWAPFIX   sfix;
  EXRULE    xc;
  HOLI_STR  hol;

  hol = *holi;
  hol.bus = bsec->bus;
  cflw = NULL;

  switch (bsec->type)
  {
  case AVGIRF:
    /* Not supported */
    cflw = Alloc_CFLWARRAY(1, 0); 
    break;

  case MM:
    FRA_Dates(settl, 0, bsec->term1, bsec->unit, False,
              bsec->cal, bsec->eom, &hol, &start, &matur);

    cflw = Alloc_CFLWARRAY(1, 2); 
    Cflw_Insert_In_Cflw(&start, 0.0, 0.0, cflw);
    Cflw_Insert_In_Cflw(&matur, 0.0, 0.0, cflw);

    break;

  case FRA:
    FRA_Dates(settl, bsec->term1, bsec->term2, bsec->unit, False,
              bsec->cal, bsec->eom, &hol, &start, &matur);
    cflw = Alloc_CFLWARRAY(1, 2); 
    Cflw_Insert_In_Cflw(&start, 0.0, 0.0, cflw);
    Cflw_Insert_In_Cflw(&matur, 0.0, 0.0, cflw);
    break;

  case IMMFRA:
    start = Cldr_IMMInMonth(settl) ;
    per   = Set_PERIOD(bsec->term1, bsec->unit) ;
    matur = Cldr_NextROLL(&start, IMM, &per, bsec->cal, bsec->eom, 
                          &hol) ;
    cflw = Alloc_CFLWARRAY(1, 2); 
    Cflw_Insert_In_Cflw(&start, 0.0, 0.0, cflw);
    Cflw_Insert_In_Cflw(&matur, 0.0, 0.0, cflw);
    break;

  case IRF:
    cflw = Alloc_CFLWARRAY(1, 2); 
    start = Cldr_NextBusinessDate(&bsec->start, &hol) ;
    matur = Cldr_NextBusinessDate(&bsec->maturity, &hol) ;
    Cflw_Insert_In_Cflw(&start, 0.0, 0.0, cflw);
    Cflw_Insert_In_Cflw(&matur, 0.0, 0.0, cflw);
    break;

  case SWAPGENR:
    cflw = SwapFix_GenrCflw(&bsec->sfix, &hol);
    break;

  case SWAP:
    per = Set_PERIOD(bsec->term1, bsec->unit);
    sfix  = SwapFix_Simple2SWAPFIX(settl, &per, bsec->freq, quote, 
                                   bsec->cal, bsec->eom) ;
    cflw  = SwapFix_GenrCflw(&sfix, &hol) ;
    break;

  case BOND:
    tr1 = bond_set_tradeinfo(settl) ;
    tr2 = bond_set_tradeinfo(&bsec->fixp.cday.last) ;
    cflw = Bond_GenrPeriod(&tr1, &tr2, &bsec->fixp, &hol) ;
    Cldr_Move2BusinessDays(cflw->days, cflw->filled, &hol) ;
    break;

  case BONDSMPL:
    xc = Set_EXRULE(EX_DAYS, bsec->excdays, True,
                    bsec->cal, settl, 0, settl, settl, False) ;
    fixp = Bond_Simple2FIXPAY(settl, &bsec->start, &bsec->maturity, 
                              bsec->coupon, bsec->freq, BULLET, &xc, 
                              NULL, bsec->cal, bsec->eom) ;
    tr1 = bond_set_tradeinfo(settl) ;
    tr2 = bond_set_tradeinfo(&bsec->maturity) ;
    cflw = Bond_GenrPeriod(&tr1, &tr2, &fixp, &hol) ;
    Cldr_Move2BusinessDays(cflw->days, cflw->filled, &hol) ;
    break;

  case BONDREPO:
    tr1 = bond_set_tradeinfo(settl) ;
    tr2 = bond_set_tradeinfo(&bsec->maturity) ;
    tr2.price = priceX;
    cflw = Bond_GenrPeriod(&tr1, &tr2, &bsec->fixp, &hol) ;
    Cldr_Move2BusinessDays(cflw->days, cflw->filled, &hol) ;
    break;

  default:
    SCecon_error("This point should never be reached",
                 "BSEC_DF2Price()", SCECONABORT);
    break;
  }

  if (cflw != NULL)
    Cldr_Move2BusinessDays(cflw->days, cflw->filled, &hol) ;

  return cflw;
}


/* AVGIRG is not supported! */
FL64 BSEC_DF2PriceDiff(DATESTR*   settl,
                       BSEC*      bsec, 
                       CFLW_STR*  cflw,
                       FL64       spread,
                       FL64       madj,
                       FL64       pricesX,
                       DISCFAC*   df, 
                       HOLI_STR*  holi,
                       FL64       quote)
{
  HOLI_STR  hol;
  FRA_STR   fra;
  FL64      price, dum, diff, d1;
  DATESTR   start, matur;
  PERIOD    per;
  DFSPREAD  dfs;

  diff    = 0.0;
  hol     = *holi;
  hol.bus = bsec->bus;

  dfs  = Set_DFSPREAD(spread, CONTINUOUS, ANNUALLY, NULL) ;

  switch (bsec->type)
  {
  case AVGIRF:
    /* Not supported */
    price = 0.0; 
    break;

  case MM:
    FRA_Dates(settl, 0, bsec->term1, bsec->unit, False,
              bsec->cal, bsec->eom, &hol, &start, &matur);
    fra = Set_FRA_STR(&start, &matur, bsec->cal, 0.0, True, Q_FLAT,
                      NO_FREQUENCY, 
                      (bsec->irr == SIMPLE_MM ? MMRATE : BILLDISC), 
                      NULL);
    price = FRA_DF2Rate(&fra, df, &hol) + spread;

    diff = SCecon_fabs(price - quote);
    break;

  case FRA:
    FRA_Dates(settl, bsec->term1, bsec->term2, bsec->unit, False,
              bsec->cal, bsec->eom, &hol, &start, &matur);
    fra = Set_FRA_STR(&start, &matur, bsec->cal, 0.0, True, Q_FLAT,
                      NO_FREQUENCY, MMRATE, NULL);
    price = FRA_DF2Rate(&fra, df, &hol) + spread;

    diff = SCecon_fabs(price - quote);
    break;

  case IMMFRA:
    start = Cldr_IMMInMonth(settl) ;
    per   = Set_PERIOD(bsec->term1, bsec->unit) ;
    matur = Cldr_NextROLL(&start, IMM, &per, bsec->cal, bsec->eom, 
                          &hol) ;
    fra = Set_FRA_STR(&start, &matur, bsec->cal, 0.0, True, Q_FLAT,
                      NO_FREQUENCY, MMRATE, NULL);
    price = FRA_DF2Rate(&fra, df, &hol) + spread;

    diff = SCecon_fabs(price - quote);
    break;

  case IRF:
    fra = Set_FRA_STR(&bsec->start, &bsec->maturity, bsec->cal, 
                      0.0, False, Q_FLAT, NO_FREQUENCY, MMRATE, NULL);
    price = IRF_DF2Price(&fra, df, &hol) - spread - madj;

    diff = SCecon_fabs(price - quote);
    break;

  case SWAPGENR:
  case SWAP:
    /* ParSwap */
    price = Cflw_DF2Price(settl, df, cflw, NULL, &hol,
                      &dfs, NULL, &dum, &dum);
    d1    = Disc_Interpolation(settl, df, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */

    diff = SCecon_fabs(price - pricesX * d1);
    break;

  case BOND:
  case BONDSMPL:
  case BONDREPO:
    price = Cflw_DF2Price(settl, df, cflw, NULL, &hol,
                      &dfs, NULL, &dum, &dum);

    diff = SCecon_fabs(price - quote);
    break;

  default:
    SCecon_error("This point should never be reached",
                 "BSEC_DF2Price()", SCECONABORT);
    break;
  }

  return diff;
}



void MaxSmooth_ForwRate2DF(FL64ARRAY  terms,
                           FL64ARRAY  forws,
                           INTI       nterms,
                           FL64ARRAY  discfacs)
{
  INTI i;

  discfacs[0] = 1.0;
  
  for (i = 0; i < nterms; i++)
    discfacs[i + 1] = discfacs[i] * 
          TVMunit_NPV(terms[i], forws[i], CONTINUOUS, 0);
}



int MaxSmooth_Harwell(integer*  ncoef, 
                      integer*  nsec, 
                      double*   coefs, 
                      void*     data, 
                      double*   f)
{
  MAXSMOOTHINT* sDATA;
  BSECARRAY     secs;
  CFLWARRAY     cflws;
  DATEARRAY     settl;
  FL64ARRAY     terms, quotes, madj, spread, pricesX;
  DISCFAC       df;
  FL64          p, penalty, spr, pvX, ma, smoothness ;
  HOLI_STR      holi;
  INTI          i, temp = *nsec - 1 ;

  sDATA = (MAXSMOOTHINT*) data;

  holi       = sDATA->holi;
  secs       = sDATA->bseca;
  cflws      = sDATA->cflws;
  settl      = sDATA->settl;
  quotes     = sDATA->quotes;
  spread     = sDATA->spread;
  madj       = sDATA->madj;
  pricesX    = sDATA->pricesX;
  terms      = sDATA->terms;
  smoothness = sDATA->smoothness;
  df         = sDATA->df;
  
  MaxSmooth_ForwRate2DF(terms, (FL64ARRAY) coefs, *ncoef, df.disc->f64);

  f[0] = 0.0;
  for (i = 0; i < *ncoef - 1; i++)
    f[0] += SQR(coefs[i + 1] - coefs[i]) ;

  for (penalty = 0.0, i = 0; i < temp ; i++)
  {
    spr = GetArrayEl(spread, i, temp, 0.0) ;
    ma  = GetArrayEl(madj, i, temp, 0.0) ;
    pvX = GetArrayEl(pricesX, i, temp, 100.0) ;
    p   = BSEC_DF2PriceDiff(&settl[i], &secs[i], &cflws[i], spr, 
                            ma, pvX, &df, &holi, quotes[i]);
    f[i + 1] = smoothness * p ;
  }

  return (int) 0;
}


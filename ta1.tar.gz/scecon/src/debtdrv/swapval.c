/* SCID @(#)swapval.c	1.5 (SimCorp) 99/09/16 15:20:18 */

/************************************************************************
*
*       Project         SCecon
*
*       file name       swapval.c
*
*       contains        value of swap functions
*
************************************************************************/

/*** includes **********************************************************/
#include <swapval.h>

/*** defines  **********************************************************/
#define DELTA_TOL 0.0000000001


/*,,SOH,,
*************************************************************************
*
*              SwapFl_DF2NPV()
*
*    interface #include <swapval.h>
*              FL64 SwapFl_DF2NPV(DATESTR       *analys,
*                                 SWAPFLOAT     *sfl,
*                                 DISCFAC       *df_cflw,
*                                 DISCFAC       *df_disc,
*                                 CMCONVADJ     *cmadj,
*                                 HOLI_STR      *holi,
*                                 RISKSET       *risk,
*                                 FL64          *dp,
*                                 FL64          *ddp) ;
*
*    general   This routine calculates npv and simple risk ratios for
*              a floating leg.
*
*              The NPV is computed on the analysis date.
*
*              All payments between analys and the first date in df are
*              IGNORED.
*
*              Risk ratios are calculated as follows:
*
*                   risk->key      dp          ddp
*                   ---------      ---         ----
*                   KEY_DF         $Duration   $Convexity
*                   KEY_BPV        BPV
*
*              Note that the PV is not rescaled, i.e. the PV is
*              in absolute terms.
*
*    input     DATESTR       *analys Pointer to analysis date.
*
*              SWAPFLOAT     *sfl    Floating leg definition
*
*              DISCFAC       *df_cflw Discounting structure setup.
*                                    Used to generate payments
*
*              DISCFAC       *df_disc Discounting structure setup.
*                                    Used for discounting
*
*              CMCONVADJ     *cmadj  Data for Convexity Adjustment
*                                    Use NULL if no adjustment
*
*              HOLI_STR      *holi   Container for data on business
*                                    day convention and non-week-end
*                                    holidays.
*
*              RISKSET       *risk   Data for risk calculations
*                                    Use NULL for no Greeks.
*
*    output    FL64          *dp     Dollar duration
*
*              FL64          *ddp    Dollar convexity
*
*    returns   The present value
*
*    diagnostics
*
*    see also
*
*    wrapper   AP
*
*************************************************************************
,,EOH,,*/

FL64 SwapFl_DF2NPV(DATESTR* analys,
                   SWAPFLOAT* sfl,
                   DISCFAC*   df_cflw,
                   DISCFAC*   df_disc,
                   CMCONVADJ* cmadj,
                   HOLI_STR*  holi,
                   RISKSET*   risk,
                   FL64*      dp,
                   FL64*      ddp)
{
    CFLW_STR  *cflw ;
    FL64      shock, pv, pvu, pvd, dum ;
    DISCFAC   sdf_cflw, sdf_disc ;

    *dp = *ddp = 0.0 ;

    cflw = SwapFl_GenrCflw(analys, sfl, df_cflw, df_disc, cmadj, holi) ;
    pv   = Swap_DF2NPV(analys, cflw, True, df_disc, holi) ;   	/* PMSTA-22396 - SRIDHARA � 160502 */

    if (risk != NULL && (risk->key == KEY_DF || risk->key == KEY_BPV) &&
        risk->risk != ZERO_ORDER)
    {
        shock = Scutl_Default_Shock(risk->shock, risk->key) ;

		sdf_cflw = Disc_ShockRates(df_cflw, 1.0, risk, holi);   	/* PMSTA-22396 - SRIDHARA � 160502 */
		sdf_disc = Disc_ShockRates(df_disc, 1.0, risk, holi);   	/* PMSTA-22396 - SRIDHARA � 160502 */

        pvu = SwapFl_DF2NPV(analys, sfl, &sdf_cflw, &sdf_disc, 
                            cmadj, holi, NULL, &dum, &dum)
                              ;
        Free_PLANARRAY(sdf_disc.disc, 1) ;
        Free_PLANARRAY(sdf_cflw.disc, 1) ;

		sdf_cflw = Disc_ShockRates(df_cflw, -1.0, risk, holi);   	/* PMSTA-22396 - SRIDHARA � 160502 */
		sdf_disc = Disc_ShockRates(df_disc, -1.0, risk, holi);   	/* PMSTA-22396 - SRIDHARA � 160502 */

        pvd = SwapFl_DF2NPV(analys, sfl, &sdf_cflw, &sdf_disc, cmadj, 
                            holi, NULL, &dum, &dum)
                              ;
        Free_PLANARRAY(sdf_disc.disc, 1) ;
        Free_PLANARRAY(sdf_cflw.disc, 1) ;

        if (risk->key == KEY_BPV)
            shock = 1.0 ;

        *dp  = -(pvd - pvu) / (2.0 * shock) ;

        if (risk->risk == SECOND_ORDER && risk->key == KEY_DF)
            *ddp = (pvu + pvd - 2.0 * pv) / SQR(shock) ;
    }

    Free_CFLWARRAY(cflw, 1) ;

    return pv ;
}


/*,,SOH,,
*************************************************************************
*
*              SwapFix_DF2NPV()
*
*    interface #include <swapval.h>
*              FL64 SwapFix_DF2NPV(DATESTR       *analys,
*                                  SWAPFIX       *sfix,
*                                  HOLI_STR      *holi,
*                                  DISCFAC       *df,
*                                  RISKSET       *risk,
*                                  FL64          *dp,
*                                  FL64          *ddp);
*
*    general   This routine calculates npv and simple risk ratios for
*              a fixed leg.
*
*              The NPV is computed on the analysis date.
*
*              All payments between analys and the first date in df are
*              IGNORED.
*
*              Risk ratios are calculated as follows:
*
*                   risk->key      dp          ddp
*                   ---------      ---         ----
*                   KEY_DF         $Duration   $Convexity
*                   KEY_BPV        BPV
*
*              Note that the PV is not rescaled, i.e. the PV is
*              in absolute terms.
*
*    input     DATESTR       *analys Pointer to analysis date.
*
*              SWAPFIX       *sfix   Fixed leg definition
*
*              HOLI_STR      *holi   Container for data on business
*                                    day convention and non-week-end
*                                    holidays.
*
*              DISCFAC       *df     Discounting structure setup.
*
*              RISKSET       *risk   Data for risk calculations
*                                    Use NULL for no Greeks.
*
*    output    FL64           *dp    Dollar duration set if risk is
*                                    FIRST_ORDER
*
*              FL64           *ddp   Dollar convexity set if risk is
*                                    SECOND_ORDER
*
*    returns   The present value
*
*    diagnostics
*
*    see also
*
*    wrapper   AP
*
*************************************************************************
,,EOH,,*/

FL64 SwapFix_DF2NPV(DATESTR*    analys,
                    SWAPFIX*       sfix,
                    HOLI_STR*      holi,
                    DISCFAC*       df,
                    RISKSET*       risk,
                    FL64*          dp,
                    FL64*          ddp)
{
    CFLW_STR  *cflw ;
    FL64      shock, pv, pvu, pvd ;
    DISCFAC   sdf ;

    *dp = *ddp = 0.0 ;

    cflw = SwapFix_GenrCflw(sfix, holi) ;
	/* PMSTA-22396 - SRIDHARA � 160502 */
    pv   = Swap_DF2NPV(analys, cflw, True, df, holi) ;

    if (risk != NULL && (risk->key == KEY_DF || risk->key == KEY_BPV) &&
        risk->risk != ZERO_ORDER)
    {
        shock = Scutl_Default_Shock(risk->shock, risk->key) ;

		/* PMSTA - 22396 - SRIDHARA � 160502 */
        sdf = Disc_ShockRates(df, 1.0, risk, holi) ;
        pvu = Swap_DF2NPV(analys, cflw, True, &sdf, holi) ;
        Free_PLANARRAY(sdf.disc, 1) ;

		/*PMSTA - 22396 - SRIDHARA � 160502 */
        sdf = Disc_ShockRates(df, -1.0, risk, holi) ;
        pvd = Swap_DF2NPV(analys, cflw, True, &sdf, holi) ;
        Free_PLANARRAY(sdf.disc, 1) ;

        if (risk->key == KEY_BPV)
            shock = 1.0 ;

        *dp  = - (pvd - pvu) / (2.0 * shock) ;

        if (risk->risk == SECOND_ORDER && risk->key == KEY_DF)
            *ddp = (pvu + pvd - 2.0 * pv) / SQR(shock) ;
    }

    Free_CFLWARRAY(cflw, 1) ;

    return pv ;
}


/*,,SOH,,
*************************************************************************
*
*              SwapFix_DF2Delta()
*
*    interface #include <swapval.h>
*              FL64ARRAY SwapFix_DF2Delta(DATESTR       *analys,
*                                         SWAPFIX       *sfix,
*                                         HOLI_STR      *holi,
*                                         DISCFAC       *df,
*                                         DELTASET      *ds) ;
*
*   general    The function calculates the delta vector for a swap
*              fix leg using a list of predefined shocks to the zero
*              coupon curve.
*
*              The delta vector represents the PV differences
*              invoked by the curve shocks.
*
*    input     DATESTR       *analys Pointer to analysis date.
*
*              SWAPFIX       *sfix   Fixed leg definition
*
*              HOLI_STR      *holi   Container for data on business
*                                    day convention and non-week-end
*                                    holidays.
*
*              DISCFAC       *df     Discounting structure setup.
*
*              DELTASET      *ds     Data for delta calculation
*
*   output
*
*   returns     The delta vector allocated as:
*
*                         Alloc_FL64ARRAY(ds->nshock) ;
*
*               Returns the present value
*
*    diagnostics
*
*    see also
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/

FL64ARRAY SwapFix_DF2Delta(DATESTR*    analys,
                           SWAPFIX*       sfix,
                           HOLI_STR*      holi,
                           DISCFAC*       df,
                           DELTASET*      ds)
{
    CFLW_STR  *cflw ;
    FL64ARRAY dv ;
    HOLI_STR  hol ;

    hol = Set_HOLI_STR(NO_BUSADJUST, 0, NULL) ;

    cflw = SwapFix_GenrCflw(sfix, holi) ;
    dv   = Cflw_DF2Delta(analys, df, cflw, NULL, &hol, NULL, ds) ;

    Free_CFLWARRAY(cflw, 1) ;

    return dv ;
}


/*,,SOH,,
*************************************************************************
*
*              SwapFl_DF2Delta()
*
*    interface #include <swapval.h>
*              FL64ARRAY SwapFl_DF2Delta(DATESTR       *analys,
*                                        SWAPFLOAT     *sfl,
*                                        DISCFAC       *df_cflw,
*                                        DISCFAC       *df_disc,
*                                        CMCONVADJ     *cmadj,
*                                        HOLI_STR      *holi,
*                                        DELTASET      *ds) ;
*
*    general   The function calculates the delta vector for
*              a floatleg using a list of predefined shocks to the zero
*              coupon curve.
*
*              The delta vector represents the PV differences
*              invoked by the curve shocks.
*
*    input     DATESTR       *analys Pointer to analysis date.
*
*              SWAPFLOAT     *sfl    Floating leg definition.
*
*              DISCFAC       *df_cflw Discounting structure setup.
*                                    Used to generate payments
*
*              DISCFAC       *df_disc Discounting structure setup.
*                                    Used for discounting
*
*              CMCONVADJ     *cmadj  Data for Convexity Adjustment
*                                    Use NULL if no adjustment
*
*              HOLI_STR      *holi   Container for data on business
*                                    day convention and non-week-end
*                                    holidays.
*
*              DELTASET      *ds     Data for delta calculation.
*
*   output
*
*   returns     The delta vector allocated as:
*
*                         Alloc_FL64ARRAY(ds->nshock) ;
*
*    diagnostics
*
*    see also
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/                                                            

FL64ARRAY SwapFl_DF2Delta(DATESTR*    analys,
                         SWAPFLOAT*     sfl,
                         DISCFAC*       df_cflw,
                         DISCFAC*       df_disc,
                         CMCONVADJ*     cmadj,
                         HOLI_STR*      holi,
                         DELTASET*      ds)
{
    INTI      i ;
    FL64ARRAY dv ;
    FL64      p0, dum ;
    PLANARRAY old_cflw, old_disc, old ;
    DATESTR   fsprev, matur ;

    /* Initialise */
    dv        = Alloc_FL64ARRAY(ds->nshock) ;
    old_cflw  = df_cflw->disc ;
    old_disc  = df_disc->disc ;

    /* The unshocked price */
    p0 = SwapFl_DF2NPV(analys, sfl, df_cflw, df_disc, cmadj, holi, 
                       NULL, &dum, &dum) ;

    matur = Cldr_NextBusinessDate(&sfl->pday.last, holi) ;
    matur = Cldr_TermUnit2Date(&matur, 
                               (INTI) (1.0 + sfl->float1.index.LIBORdur),
                               sfl->float1.index.LIBORunit,
                               sfl->float1.fbase.cal, LAST, holi) ;

    for (i = 0; i < ds->nshock; i++)
    {
        if (ds->dfwhich == DF_BOTH)
        {
            fsprev = Disc_get_chgdate(NULL, old_cflw, &ds->shock[i]) ;
            fsprev = Disc_get_chgdate(&fsprev, old_disc, &ds->shock[i]) ;
        }
        else 
        {
            old = (ds->dfwhich == DF_CFLW ? old_cflw : old_disc) ;
            fsprev = Disc_get_chgdate(NULL, old, &ds->shock[i]) ;
        }

        if (fsprev.y > 0 && Cldr_DateLT(&matur, &fsprev) == False)
        {
            /* Use shocks in ds->shoch for both curves */
            if (ds->dfwhich == DF_BOTH)
                df_cflw->disc = df_disc->disc = &ds->shock[i] ;

            /* Use shocks in ds->shoch for cflw curve */
            else if (ds->dfwhich == DF_CFLW)
                df_cflw->disc = &ds->shock[i] ;

            /* Use shocks in ds->shoch for disc curve */
            else if (ds->dfwhich == DF_DISC)
                df_disc->disc = &ds->shock[i] ;

            dv[i] = SwapFl_DF2NPV(analys, sfl, df_cflw, df_disc, cmadj, holi,
                                  NULL, &dum, &dum) ;
            dv[i] -= p0 ;

            if (ds->zero == True)
            {
                /* Find shocked Zero PV */
                if (ds->dfwhich == DF_CFLW)
					dv[i] /= Disc_DF2BPV(&ds->mid[i], df_cflw, old_cflw, holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */
                else
					dv[i] /= Disc_DF2BPV(&ds->mid[i], df_disc, old_disc, holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */
            }
        }
        else
            dv[i] = 0.0 ;
    }

    df_disc->disc = old_disc ;
    df_cflw->disc = old_cflw ;

    return dv ;
}

/*,,SOH,,
*************************************************************************
*
*              AssetSwap_DF2Spread()
*
*    interface #include <swapval.h>
*              BOOLE AssetSwap_DF2Spread(DATESTR       *analys,
*                                        FL64          asset_p,
*                                        SWAPFIX       *sfix,
*                                        SWAPFLOAT     *sfl,
*                                        DISCFAC       *df_cflw,
*                                        DISCFAC       *df_disc,
*                                        CMCONVADJ     *cmadj,
*                                        HOLI_STR      *holi,
*                                        FL64          *spread) ;
*
*    general   The function calculates the asset swap spread for
*              a single currency asset swap.
*              This is the spread which makes the value of the floating leg 
*              equal to the 100.0 - asset price + the present
*              value of the fixed leg.
*
*              In the standard case:
*              1. All members of sfl are the same as the corresponding 
*                 members of sfix.
*              2. The notional of sfix and sfl is 100.0 at
*                 the analysis date.
*              3. The coupon and amortizations of sfix match the
*                 coupons and amortizations of the asset.
*
*              Asset swaps can be structured in a number of ways. For an
*              example of how the asset swap is defined here, see 
*              exhibit 18.3 in Satyajit Das, "Swaps & Financial Derivatives",
*              2nd edition, 1994.  
*              
*
*    input     DATESTR       *analys Pointer to analysis date.
*                                    This is the settlement date
*                                    for the asset swap.
*
*              FL64          asset_p Asset price including accrued interest
*                                    pr. notional 100.0 at the analysis 
*                                    date.
*
*              SWAPFIX       *sfix   The definition of the fixed leg. Usually
*                                    sfix->fix.fixrate is equal to the 
*                                    coupon of the underlying asset.
*
*              SWAPFLOAT     *sfl    Floating leg definition. 
*                                    sfl->float1.fbase.spread is not used. 
*
*              DISCFAC       *df_cflw Discounting structure setup.
*                                    Used to generate payments for the
*                                    floating leg.
*
*              DISCFAC       *df_disc Discounting structure setup.
*                                    Used for discounting the floating
*                                    leg payments as well as the fixed leg
*                                    payments.
*
*              CMCONVADJ     *cmadj  Data for Convexity Adjustment of the 
*                                    floating leg payments.
*                                    Use NULL if no adjustment
*
*              HOLI_STR      *holi   Container for data on business
*                                    day convention and non-week-end
*                                    holidays.
*
*   output     FL64          *spread The spread (sfl->float1.fbase.spread) 
*                                    which will make the PV of 
*                                    the asset swap equal to zero.
*
*   returns    True if solution found, False if not.
*
*   diagnostics
*
*   see also   AssetSwap_DF2PV()
*
*************************************************************************
,,EOH,,*/                                                            

BOOLE AssetSwap_DF2Spread(DATESTR       *analys,
                          FL64          asset_p,
                          SWAPFIX       *sfix,
                          SWAPFLOAT     *sfl,
                          DISCFAC       *df_cflw,
                          DISCFAC       *df_disc,
                          CMCONVADJ     *cmadj,
                          HOLI_STR      *holi,
                          FL64          *spread)
{

  FL64 fix_premium, dum1, dum2, float_npv ;

  fix_premium = SwapFix_DF2NPV(analys, sfix, holi, df_disc, NULL, &dum1, &dum2);

  float_npv = 100.0 - asset_p + fix_premium  ;

  return SwapFl_DF2Spread(analys, float_npv, sfl, df_disc, 
                          df_cflw, cmadj, holi, spread) ;
}

/*,,SOH,,
*************************************************************************
*
*              AssetSwap_DF2PV()
*
*    interface #include <swapval.h>
*              FL64 AssetSwap_DF2PV(DATESTR       *analys,
*                                   FL64          asset_p,
*                                   SWAPFIX       *sfix,
*                                   SWAPFLOAT     *sfl,
*                                   DISCFAC       *df_cflw,
*                                   DISCFAC       *df_disc,
*                                   CMCONVADJ     *cmadj,
*                                   HOLI_STR      *holi) ;
*
*    general   The function calculates the PV of a simple single currency 
*              asset swap.
*              This is basically equal to the asset price - 100.0 - 
*              the present value of the fixed leg + the value of the 
*              floating leg.
*
*              In the standard case:
*              1. All members of sfl are the same as the corresponding 
*                 members of sfix.
*              2. The notional of sfix and sfl is 100.0 at
*                 the analysis date.
*              3. The coupon and amortizations of sfix match the
*                 coupons and amortizations of the asset.
*
*              Asset swaps can be structured in a number of ways. For an
*              example of how the asset swap is defined here, see 
*              exhibit 18.3 in Satyajit Das, "Swaps & Financial Derivatives",
*              2nd edition, 1994.  
*              
*
*    input     DATESTR       *analys Pointer to analysis date.
*                                    This is the settlement date
*                                    for the asset swap.
*
*              FL64          asset_p Asset price including accrued interest
*                                    pr. notional 100.0 at the analysis date.
*
*              SWAPFIX       *sfix   The definition of the fixed leg. Usually
*                                    sfix->fix.fixrate is equal to the 
*                                    coupon of the underlying asset.
*
*              SWAPFLOAT     *sfl    Floating leg definition. 
*                                    sfl->float1.fbase.spread contains the
*                                    asset swap spread.
*
*              DISCFAC       *df_cflw Discounting structure setup.
*                                    Used to generate payments for the
*                                    floating leg.
*
*              DISCFAC       *df_disc Discounting structure setup.
*                                    Used for discounting the floating
*                                    leg payments as well as the fixed leg
*                                    payments.
*
*              CMCONVADJ     *cmadj  Data for Convexity Adjustment of the 
*                                    floating leg payments.
*                                    Use NULL if no adjustment
*
*              HOLI_STR      *holi   Container for data on business
*                                    day convention and non-week-end
*                                    holidays.
*
*   output     
*
*   returns    The asset swap PV from fixed coupon payer perspective pr.
*              notional 100.0 of the underlying asset.
*
*   diagnostics
*
*   see also   AssetSwap_DF2Spread()
*              SwapFix_DF2NPV()
*              SwapFl_DF2NPV()  
*
*************************************************************************
,,EOH,,*/                                                            

FL64 AssetSwap_DF2PV(DATESTR       *analys,
                     FL64          asset_p,
                     SWAPFIX       *sfix,
                     SWAPFLOAT     *sfl,
                     DISCFAC       *df_cflw,
                     DISCFAC       *df_disc,
                     CMCONVADJ     *cmadj,
                     HOLI_STR      *holi)
{

  FL64 fix_npv, dum1, dum2, float_npv ;

  fix_npv = SwapFix_DF2NPV(analys, sfix, holi, df_disc, NULL, &dum1, &dum2);

  float_npv = SwapFl_DF2NPV(analys, sfl, df_cflw, df_disc, cmadj, holi, NULL, 
    &dum1, &dum2); 

  return asset_p + float_npv - 100.0 - fix_npv ;
}

#undef DELTA_TOL

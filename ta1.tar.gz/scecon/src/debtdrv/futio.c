/* SCCS @(#)futio.c	1.9 (SimCorp) 99/06/14 10:50:44 */

/*********************************************************************
*                                                                     
*   Project     SCecon                                                
*                                                                     
*   general     This file contains example code for routines that     
*               converts strings to conventions used by SCecon 
*               routines.
*                                                                     
**********************************************************************
*/

/* includes    *******************************************************/
#include <futio.h>
#include <futvl.h>
#include <ioconv.h>
#include <bondio.h>


/*
..
*/



CFCONV Str2CFCONV(TEXT txt)
{
    CFCONV eom = CFCONV_INIT ;

    Str_Uppercase(txt) ;

    if      (!strcmp(txt, "LIFFE_GILT"))     eom = LIFFE_GILT ;
    else if (!strcmp(txt, "FLG"))            eom = LIFFE_GILT ;

    else if (!strcmp(txt, "LIFFE_BOBL"))     eom = LIFFE_BUND ;
    else if (!strcmp(txt, "FBA"))            eom = LIFFE_BUND ;
    else if (!strcmp(txt, "LIFFE_BUND"))     eom = LIFFE_BUND ;
    else if (!strcmp(txt, "FDB"))            eom = LIFFE_BUND ;

    else if (!strcmp(txt, "LIFFE_JGB"))      eom = LIFFE_JGB ;
    else if (!strcmp(txt, "FYB"))            eom = LIFFE_JGB ;

    else if (!strcmp(txt, "TSE_JGB"))        eom = TSE_JGB ;
    else if (!strcmp(txt, "JGB"))            eom = TSE_JGB ;

    else if (!strcmp(txt, "SIMEX_JGB"))      eom = SIMEX_JGB ;

    else if (!strcmp(txt, "LIFFE_BTP"))      eom = LIFFE_BTP ;
    else if (!strcmp(txt, "FIB"))            eom = LIFFE_BTP ;

    else if (!strcmp(txt, "MIF_BTP"))        eom = MIF_BTP ;

    else if (!strcmp(txt, "MEFF_BONOS"))     eom = MEFF_BONOS ;
    else if (!strcmp(txt, "MFF"))            eom = MEFF_BONOS ;

    else if (!strcmp(txt, "ME_CGB"))         eom = ME_CGB ;
    else if (!strcmp(txt, "MONEX_CGB"))      eom = ME_CGB ;
    else if (!strcmp(txt, "CGB"))            eom = ME_CGB ;

    else if (!strcmp(txt, "DTB_BOBL"))       eom = EUREX_BUND ;
    else if (!strcmp(txt, "DTB_BUND"))       eom = EUREX_BUND ;
    else if (!strcmp(txt, "BDL"))            eom = EUREX_BUND ;
    else if (!strcmp(txt, "BDM"))            eom = EUREX_BUND ;
    else if (!strcmp(txt, "EUREX_SCHATZ"))   eom = EUREX_BUND ;
    else if (!strcmp(txt, "EUREX_BOBL"))     eom = EUREX_BUND ;
    else if (!strcmp(txt, "EUREX_BUND"))     eom = EUREX_BUND ;
    else if (!strcmp(txt, "EUREX_BUXL"))     eom = EUREX_BUND ;

    else if (!strcmp(txt, "MATIF_NOT"))      eom = MATIF_NOT ;
    else if (!strcmp(txt, "PTB"))            eom = MATIF_NOT ;

    else if (!strcmp(txt, "CBOT_T_NOTE"))    eom = CBOT_T_NOTE ;
    else if (!strcmp(txt, "CBOT_T_BOND"))    eom = CBOT_T_BOND ;
    else if (!strcmp(txt, "LIFFE_T_BOND"))   eom = CBOT_T_BOND ;
    else if (!strcmp(txt, "FTB"))            eom = CBOT_T_BOND ;
    else if (!strcmp(txt, "US"))             eom = CBOT_T_BOND ;

    else if (!strcmp(txt, "CBOT_CGB"))       eom = CBOT_CGB ;
    
    else if (!strcmp(txt, "SOFFEX_SGB"))     eom = EUREX_SGB ;
    else if (!strcmp(txt, "EUREX_SGB"))      eom = EUREX_SGB ;
    
    else if (!strcmp(txt, "OM_STAT"))        eom = OM_STAT ;
    
    else if (!strcmp(txt, "NO_CFCONV"))      eom = NO_CFCONV ;
    else if (!strcmp(txt, "NONE"))           eom = NO_CFCONV ;
    
    else
      SCecon_error("Unknown conversion factor convention\n", 
            "Str2CFCONV()", SCECONABORT) ;

    return eom ;
}

/*
..
*/


CMADJTYPE Str2CMADJTYPE(TEXT txt)
{
    CMADJTYPE eom = NO_CMADJ;

    Str_Uppercase(txt) ;

    if      (!strcmp(txt, "NO_CMADJ"))       eom = NO_CMADJ ;
    else if (!strcmp(txt, "CMADJ_ORIG"))     eom = CMADJ_ORIG ;
    else if (!strcmp(txt, "CMADJ_PRATE"))    eom = CMADJ_PRATE ;
    else if (!strcmp(txt, "CMADJ_4TH"))      eom = CMADJ_4TH ;
    else if (!strcmp(txt, "CMADJ_4THCORR"))  eom = CMADJ_4THCORR ;
    else
        SCecon_error("CMADJTYPE unknown\n", "Str2CMADJTYPE()", 
            SCECONABORT) ;

    return eom ;
}


/*
..
*/


COMPMETHOD Str2COMPMETHOD(TEXT txt)
{
    COMPMETHOD unit = COMPMETHOD_INIT ;

    Str_Uppercase(txt) ;

    if      (!strcmp(txt, "NONE"))             unit = NONE ;
    else if (!strcmp(txt, "NO"))               unit = NONE ;
    else if (!strcmp(txt, "N"))                unit = NONE ;

    else if (!strcmp(txt, "REGCOMPOUND"))      unit = REGCOMPOUND ;
    else if (!strcmp(txt, "REGULAR"))          unit = REGCOMPOUND ;
    else if (!strcmp(txt, "REG"))              unit = REGCOMPOUND ;
    else if (!strcmp(txt, "R"))                unit = REGCOMPOUND ;

    else if (!strcmp(txt, "FLAT"))             unit = FLAT ;
    else if (!strcmp(txt, "F"))                unit = FLAT ;

    else if (!strcmp(txt, "TAM"))              unit = TAM ;
    else if (!strcmp(txt, "TAG"))              unit = TAM ;
    else if (!strcmp(txt, "T"))                unit = TAM ;

    else if (!strcmp(txt, "DECOMPOUND"))       unit = DECOMPOUND ;
    else if (!strcmp(txt, "DE"))               unit = DECOMPOUND ;
    else if (!strcmp(txt, "D"))                unit = DECOMPOUND ;
    else if (!strcmp(txt, "TEC"))              unit = DECOMPOUND ;

    else
        SCecon_error("Unknown compounding convention\n", 
            "Str2COMPMETHOD()", SCECONABORT) ;

    return unit ;
}


/*
..
*/


CTDCONV Str2CTDCONV(TEXT txt)
{
    CTDCONV r = CTDCONV_INIT ;

    Str_Uppercase(txt) ;

    if      (!strcmp(txt, "CTD_PROFIT"))      r = CTD_PROFIT ;
    else if (!strcmp(txt, "PROFIT"))          r = CTD_PROFIT ;

    else if (!strcmp(txt, "CTD_REPO"))        r = CTD_REPO ;
    else if (!strcmp(txt, "REPO"))            r = CTD_REPO ;

    else if (!strcmp(txt, "CTD_CONRATIO"))     r = CTD_CONRATIO ;
    else if (!strcmp(txt, "CONVERTION RATIO")) r = CTD_CONRATIO ;
    else if (!strcmp(txt, "CONVERTION"))       r = CTD_CONRATIO ;
    else if (!strcmp(txt, "CONVERSION"))       r = CTD_CONRATIO ;
    else
        SCecon_error("Unknown CTD criteria convention\n", 
          "Str2CTDCONV()", SCECONABORT) ;

    return r ;
}


/*
..
*/


LEGTYPE Str2LEGTYPE(TEXT txt)
{
    LEGTYPE eom = FIXEDLEG;

    Str_Uppercase(txt) ;

    if      (!strcmp(txt, "FLOATLEG"))       eom = FLOATLEG ;
    else if (!strcmp(txt, "FIXEDLEG"))       eom = FIXEDLEG ;
    else
        SCecon_error("legtype unknown\n", "Str2LEGTYPE()", 
            SCECONABORT) ;

    return eom ;
}


/*
..
*/


QOTCONV Str2QOTCONV(TEXT txt)
{
    QOTCONV qot = QOTCONV_INIT ;

    Str_Uppercase(txt) ;

    if      (!strcmp(txt, "Q_FLAT"))           qot = Q_FLAT ;
    else if (!strcmp(txt, "FLAT"))             qot = Q_FLAT ;
    else if (!strcmp(txt, "F"))                qot = Q_FLAT ;

    else if (!strcmp(txt, "Q_FLATFORW"))       qot = Q_FLATFORW ;
    else if (!strcmp(txt, "FLATFORW"))         qot = Q_FLATFORW ;
    else if (!strcmp(txt, "FLAT_FORW"))        qot = Q_FLATFORW ;
    else if (!strcmp(txt, "FLATFORWARD"))      qot = Q_FLATFORW ;
    else if (!strcmp(txt, "FLAT FORWARD"))     qot = Q_FLATFORW ;
    else if (!strcmp(txt, "FF"))               qot = Q_FLATFORW ;

    else if (!strcmp(txt, "Q_PERANNUM"))       qot = Q_PERANNUM ;
    else if (!strcmp(txt, "PERANNUM"))         qot = Q_PERANNUM ;
    else if (!strcmp(txt, "PER ANNUM"))        qot = Q_PERANNUM ;
    else if (!strcmp(txt, "PA"))               qot = Q_PERANNUM ;

    else if (!strcmp(txt, "Q_PERANNUMFORW"))   qot = Q_PERANNUMFORW ;
    else if (!strcmp(txt, "PERANNUMFORW"))       qot = Q_PERANNUMFORW ;
    else if (!strcmp(txt, "PERANNUM_FORW"))      qot = Q_PERANNUMFORW ;
    else if (!strcmp(txt, "PERANNUMFORWARD"))    qot = Q_PERANNUMFORW ;
    else if (!strcmp(txt, "PER ANNUM FORWARD"))  qot = Q_PERANNUMFORW ;
    else if (!strcmp(txt, "PAF"))                qot = Q_PERANNUMFORW ;
    else
        SCecon_error("Unknown quoting convention\n", "Str2QOTCONV()",
            SCECONABORT) ;

    return qot ;
}


/*
..
*/


CFCONV Read_CFCONV(FILE* in, FILE* out, TEXT dscr)
{
    CFCONV irr;
    CH txb[MAX_KEYWORD_LENGTH];

      /* Comments, if any: */
    if (!IOUtil_ReadComment(in, out))
        Write_Comment(out, dscr);

    Read_TEXT(in, MAX_KEYWORD_LENGTH, txb);
    irr = Str2CFCONV(txb);

    fprintf(out, " %s\n", txb);

    return irr;
}

/*
..
*/


CMADJTYPE Read_CMADJTYPE(FILE* in, FILE* out, TEXT dscr)
{
    CMADJTYPE irr;
    CH txb[MAX_KEYWORD_LENGTH];

      /* Comments, if any: */
    if (!IOUtil_ReadComment(in, out))
        Write_Comment(out, dscr);

    Read_TEXT(in, MAX_KEYWORD_LENGTH, txb);
    irr = Str2CMADJTYPE(txb);

    fprintf(out, " %s\n", txb);

    return irr;
}

/*
..
*/


COMPMETHOD Read_COMPMETHOD(FILE* in, FILE* out, TEXT dscr)
{
    COMPMETHOD irr;
    CH txb[MAX_KEYWORD_LENGTH];

      /* Comments, if any: */
    if (!IOUtil_ReadComment(in, out))
        Write_Comment(out, dscr);

    Read_TEXT(in, MAX_KEYWORD_LENGTH, txb);
    irr = Str2COMPMETHOD(txb);

    fprintf(out, " %s\n", txb);

    return irr;
}

/*
..
*/


CTDCONV Read_CTDCONV(FILE* in, FILE* out, TEXT dscr)
{
    CTDCONV irr;
    CH txb[MAX_KEYWORD_LENGTH];

      /* Comments, if any: */
    if (!IOUtil_ReadComment(in, out))
        Write_Comment(out, dscr);

    Read_TEXT(in, MAX_KEYWORD_LENGTH, txb);
    irr = Str2CTDCONV(txb);

    fprintf(out, " %s\n", txb);

    return irr;
}

/*
..
*/


LEGTYPE Read_LEGTYPE(FILE* in, FILE* out, TEXT dscr)
{
    LEGTYPE irr;
    CH txb[MAX_KEYWORD_LENGTH];

      /* Comments, if any: */
    if (!IOUtil_ReadComment(in, out))
        Write_Comment(out, dscr);

    Read_TEXT(in, MAX_KEYWORD_LENGTH, txb);
    irr = Str2LEGTYPE(txb);

    fprintf(out, " %s\n", txb);

    return irr;
}

/*
..
*/


QOTCONV Read_QOTCONV(FILE* in, FILE* out, TEXT dscr)
{
    QOTCONV irr;
    CH txb[MAX_KEYWORD_LENGTH];

      /* Comments, if any: */
    if (!IOUtil_ReadComment(in, out))
        Write_Comment(out, dscr);

    Read_TEXT(in, MAX_KEYWORD_LENGTH, txb);
    irr = Str2QOTCONV(txb);

    fprintf(out, " %s\n", txb);

    return irr;
}

/*
..
*/


FLOATRATE Read_FLOATRATE(FILE* in, FILE* out)
{
    FLOATRATE frate ;
    RATECONV  rt ;
    COUNT     type ;
    FL64      LIBORdur;
    TERMUNIT  LIBORunit; 
    PMTFREQ   LIBORfreq;
    CALCONV   LIBORcal ;

    type = Read_FormatId(in, out) ;

    fprintf(out, "* FLOATRATE:\n") ;

    switch (type)
    {
    case 1 :

        frate.fbase.coupon1 = Read_FL64(in, out, "Coupon1") ;
        frate.fbase.cal       = Read_CALCONV(in, out, "Day count") ;
        frate.fbase.effective = Read_DATESTR(in, out, "Effective") ;
        frate.fbase.spread = Read_FL64(in, out, "Spread") ;
        frate.fbase.is_fix    = Read_BOOLE(in, out, "Is Fixed") ;

        frate.factor = Read_FL64(in, out, "Factor") ;
        frate.backset = Read_BOOLE(in, out, "Backset") ;
        frate.delay.num = Read_INTI(in, out, "Delay Num") ;
        frate.delay.unit = Read_TERMUNIT(in, out, "Delay Unit") ;

        frate.method = Read_COMPMETHOD(in, out, "Comp.method") ;
        frate.compfreq = Read_PMTFREQ(in, out, "Comp.freq") ;

        LIBORdur = Read_FL64(in, out, "Index Dur") ;
        LIBORunit = Read_TERMUNIT(in, out, "Index Unit") ;
        LIBORfreq = Read_PMTFREQ(in, out, "Index Freq") ;

        rt = (LIBORfreq == NO_FREQUENCY ? MMRATE : PARYIELD) ;
        LIBORcal = (LIBORfreq == NO_FREQUENCY ? frate.fbase.cal : EU30E360) ;
        frate.index = Set_RATEINDEX(rt, LIBORdur, LIBORunit,
                                    LIBORfreq, LIBORcal, 0.0) ;

        frate.avgfl.avgdur = Read_FL64(in, out, "AVG dur") ;
        frate.avgfl.avgunit = Read_TERMUNIT(in, out, "AVG unit") ;
        frate.avgfl.avgmeth = Read_BOOLE(in, out, "AVG method") ;


        frate.stepspr = Read_PLANARRAY(in) ;
        fprintf(out,"* Spread list:\n") ;
        Write_PLANARRAY(out, frate.stepspr) ;

        frate.stepfac = Read_PLANARRAY(in) ;
        fprintf(out,"* Factor list:\n") ;
        Write_PLANARRAY(out, frate.stepfac) ;

        break ;

    case 2:

/*..insert swap test suite cases here !! */

        break ;

    case 3:

        frate.fbase.coupon1 = Read_FL64(in, out, "Coupon1") ;
        frate.fbase.cal       = Read_CALCONV(in, out, "Day count") ;
        frate.fbase.effective = Read_DATESTR(in, out, "Effective") ;
        frate.fbase.spread = Read_FL64(in, out, "Spread") ;
        frate.fbase.is_fix    = Read_BOOLE(in, out, "Is Fixed") ;

        frate.factor   = 1.0 ;
        frate.backset  = False ;
        frate.delay    = Set_PERIOD(0, DAYS) ;
        frate.method   = NONE ;
        frate.compfreq = ANNUALLY ;

        LIBORdur = Read_FL64(in, out, "Index Dur") ;
        LIBORunit = Read_TERMUNIT(in, out, "Index Unit") ;
        LIBORfreq = Read_PMTFREQ(in, out, "Index Freq") ;

        rt = (LIBORfreq == NO_FREQUENCY ? MMRATE : PARYIELD) ;
        LIBORcal = (LIBORfreq == NO_FREQUENCY ? frate.fbase.cal : EU30E360) ;
        frate.index = Set_RATEINDEX(rt, LIBORdur, LIBORunit,
                                    LIBORfreq, LIBORcal, 0.0) ;

        frate.avgfl.avgdur  = 0 ;
        frate.avgfl.avgunit = DAYS ;
        frate.avgfl.avgmeth = True ;

        frate.stepspr = frate.stepfac = NULL ;

        break ;
    }

    Write_VALIDATEError(out, Validate_FLOATRATE(&frate));

    return frate ;
}

/*
..
*/


FRA_STR Read_FRA_STR(FILE* in, FILE* out)
{
    FRA_STR   f ;
    YYYYMMDD  yyyymmdd1, yyyymmdd2, ymd3 ;
    char      txb[25], txc[25], txd[25], txe[25] ;
    FL64      rate ;
    COUNT type;

    type = Read_FormatId(in, out);

    switch (type)
    {
        /* read FRA */
        case 1:

            fscanf(in, "%ld %ld %s %lf %s",
                   &yyyymmdd1, &yyyymmdd2, txb, &rate, txc) ;

            f.settl = Cldr_YMD2Datestr(yyyymmdd1) ;
            f.matur = Cldr_YMD2Datestr(yyyymmdd2) ;
            f.cal = Str2CALCONV(txb) ;
            f.price = rate ;
            f.fra = True ;
            f.qot = Str2QOTCONV(txc) ;
            f.type = MMRATE ;
            f.pay = f.settl ;

            fprintf(out,"   settlement               %8ld\n", yyyymmdd1) ;
            fprintf(out,"   maturity                 %8ld\n", yyyymmdd2) ;
            fprintf(out,"   contract rate            %8lf\n", rate) ;
            fprintf(out,"   calendar convention         %8s\n", txb) ;
            fprintf(out,"   quoting conv.              %8s\n", txc) ;

            break ;

        /* read IRF */
        case 2:

            fscanf(in,  "%ld %ld %s %lf %s",
                   &yyyymmdd1, &yyyymmdd2, txb, &rate, txc) ;

            f.settl = Cldr_YMD2Datestr(yyyymmdd1) ;
            f.matur = Cldr_YMD2Datestr(yyyymmdd2) ;
            f.cal = Str2CALCONV(txb) ;
            f.price = rate ;
            f.fra = False ;
            f.freq = Str2PMTFREQ(txc) ;
            f.type = MMRATE ;

            fprintf(out,"   settlement                %8ld\n", yyyymmdd1) ;
            fprintf(out,"   maturity                  %8ld\n", yyyymmdd2) ;
            fprintf(out,"   contract rate             %8lf\n", rate) ;
            fprintf(out,"   calendar convention       %8s\n", txb) ;
            fprintf(out,"   payment frequency         %8s\n", txc) ;

            break ;

        /* read general FRA_STR */
        case 3:

            fscanf(in,  "%ld %ld %s %lf %s %s %s",
                   &yyyymmdd1, &yyyymmdd2, txb, &rate, txc, txd, txe) ;

            f.settl = Cldr_YMD2Datestr(yyyymmdd1) ;
            f.matur = Cldr_YMD2Datestr(yyyymmdd2) ;
            f.cal = Str2CALCONV(txb) ;
            f.price = rate ;
            f.fra  = Str2BOOLE(txc) ;
            f.qot  = Str2QOTCONV(txd) ;
            f.freq = Str2PMTFREQ(txe) ;
            f.type = MMRATE ;
            f.pay  = f.settl ;

            fprintf(out,"   settlement                %8ld\n", yyyymmdd1) ;
            fprintf(out,"   maturity                  %8ld\n", yyyymmdd2) ;
            fprintf(out,"   contract rate             %8lf\n", rate) ;
            fprintf(out,"   calendar convention       %8s\n", txb) ;
            fprintf(out,"   fra                       %8s\n", txc) ;
            fprintf(out,"   quoting conv.             %8s\n", txd) ;
            fprintf(out,"   payment frequency         %8s\n", txe) ;

            break ;

            /* Read simple FRA */
        case 4:

            fscanf(in, "%ld %ld %s %s", &yyyymmdd1, &yyyymmdd2, txb, txd) ;

            f.settl = Cldr_YMD2Datestr(yyyymmdd1) ;
            f.matur = Cldr_YMD2Datestr(yyyymmdd2) ;
            f.cal   = Str2CALCONV(txb) ;
            f.price = 0.0 ;
            f.fra   = True ;
            f.qot   = Q_FLAT ;
            f.type  = Str2RATECONV(txd) ;
            f.pay   = f.settl ;

            fprintf(out,"   settlement               %8ld\n", yyyymmdd1) ;
            fprintf(out,"   maturity                 %8ld\n", yyyymmdd2) ;
            fprintf(out,"   calendar convention      %8s\n", txb) ;
            fprintf(out,"   RATECONV     .           %8s\n", txd) ;

            break ;

        /* read FRA */
        case 5:

            fscanf(in, "%ld %ld %s %lf %s %s %ld",
                   &yyyymmdd1, &yyyymmdd2, txb, &rate, txc, txd, &ymd3) ;

            f.settl = Cldr_YMD2Datestr(yyyymmdd1) ;
            f.matur = Cldr_YMD2Datestr(yyyymmdd2) ;
            f.cal   = Str2CALCONV(txb) ;
            f.price = rate ;
            f.fra   = True ;
            f.qot   = Str2QOTCONV(txc) ;
            f.type  = Str2RATECONV(txd) ;
            f.pay   = Cldr_YMD2Datestr(ymd3) ;

            fprintf(out,"   settlement               %8ld\n", yyyymmdd1) ;
            fprintf(out,"   maturity                 %8ld\n", yyyymmdd2) ;
            fprintf(out,"   contract rate            %8lf\n", rate) ;
            fprintf(out,"   calendar convention      %8s\n", txb) ;
            fprintf(out,"   quoting conv.            %8s\n", txc) ;
            fprintf(out,"   RATECONV     .           %8s\n", txd) ;
            fprintf(out,"   PayDay                   %8ld\n", ymd3) ;

            break ;

            /* read IRF */
        case 6:

            fscanf(in,  "%ld %ld %s %lf %s %s",
                   &yyyymmdd1, &yyyymmdd2, txb, &rate, txc, txd) ;

            f.settl = Cldr_YMD2Datestr(yyyymmdd1) ;
            f.matur = Cldr_YMD2Datestr(yyyymmdd2) ;
            f.cal = Str2CALCONV(txb) ;
            f.price = rate ;
            f.fra = False ;
            f.freq = Str2PMTFREQ(txc) ;
            f.type  = Str2RATECONV(txd) ;

            fprintf(out,"   settlement                %8ld\n", yyyymmdd1) ;
            fprintf(out,"   maturity                  %8ld\n", yyyymmdd2) ;
            fprintf(out,"   contract rate             %8lf\n", rate) ;
            fprintf(out,"   calendar convention       %8s\n", txb) ;
            fprintf(out,"   payment frequency         %8s\n", txc) ;
            fprintf(out,"   IRFTYPE     .             %8s\n", txd) ;

            break ;
     }

    Write_VALIDATEError(out, Validate_FRA_STR(&f));

     return f ;
}

/*
..
*/


FRN Read_FRN(FILE* in, FILE* out)
{
    FRN        diff ;
    DATESTR    dzero, deffect, dfirst, dmatur ;
    YYYYMMDD   effect, first, matur ;
    int        i1 ;
    INTI       delay;
    PMTFREQ    compfreq, freq ;
    CALCONV    cal ;
    EOMCONV    eom ;
    SEQCONV    seq ;
    PAYDAYDEF  pday ;
    FLOATRATE  float1 ;
    FLOATBASE  fbase ;
    FL64       r1, spread, dur, factor, coupon1 ;
    BOOLE      avgm, is_fix, io, init_exch, backset ;
    BONDTYPE   bond ;
    COMPMETHOD method ;
    RATEINDEX  index ;
    AVGFLOAT   avgfl ;
    PERIOD     bdelay ;
    REPAYMNT   redemp ;
    PLAN_STR   *amort, *stepfac, *stepspr ;
    char       txb[25], txc[25], txd[25], txe[25] ;
    COUNT      type ;
    PAYDAYSEQ  pseq ;

    fprintf(out, "   FRN:\n") ;
    type = Read_FormatId(in, out) ;

    switch (type)
    {
        case 1:

            diff.repay  = Read_REPAYMNT(in, out) ;
            diff.rday   = Read_PAYDAYDEF(in, out) ;
            diff.float1 = Read_FLOATRATE(in, out) ;
            diff.pday   = Read_PAYDAYDEF(in, out) ;

            fscanf(in, "%d", &i1) ;
            diff.delay = (INTI) i1 ;
            fprintf(out, "   Delay          %8d\n", i1) ;
            break ;

        case 2:
        case 3:

            /* This is the 'original ' swaptest stuff */
            dzero = Cldr_YMD2Datestr((YYYYMMDD) 0) ;

            fscanf(in, "%ld", &effect) ;
            deffect = Cldr_YMD2Datestr(effect) ;

            fscanf(in, "%ld %ld %s %s %s %s",
                   &first, &matur, txb, txc, txd, txe) ;
            freq = Str2PMTFREQ(txb) ;
            eom  = Str2EOMCONV(txc) ;
            cal  = Str2CALCONV(txd) ;
            seq  = Str2SEQCONV(txe) ;
            dfirst = Cldr_YMD2Datestr(first) ;
            dmatur = Cldr_YMD2Datestr(matur) ;

            pday = cflw_set_payday(&dfirst, &dzero, &dmatur, False,
                                   Cflw_MonthsBetweenPayments(freq),
                                   MONTHS, NOODD, NOODD, seq, eom) ;

            fprintf(out,"   effective day      %8ld\n", effect) ;
            fprintf(out,"   first payday       %8ld\n", first) ;
            fprintf(out,"   maturity           %8ld\n", matur) ;
            fprintf(out,"   pay frequency      %8s\n", txb) ;
            fprintf(out,"   eomconv            %8s\n", txc) ;
            fprintf(out,"   calendar           %8s\n", txd) ;


            fscanf(in, "%lf", &coupon1) ;
            fprintf(out,"   first coupon       %3.4lf\n", coupon1) ;
            is_fix = True ;
            if (type == 3)
            {
                fscanf(in, "%s", txd) ;
                is_fix = Str2BOOLE(txd) ;
                fprintf(out,"   is_fix             %8s\n", txd) ;
            }

            fscanf(in, "%lf %lf", &factor, &spread) ;
            fprintf(out,"   factor             %3.4lf\n", factor) ;
            fprintf(out,"   spread             %3.4lf\n", spread) ;

            fbase = Set_FLOATBASE(coupon1, cal, &deffect, spread, is_fix) ;

            fscanf(in, "%s", txb) ;
            fprintf(out,"   backset ??         %8s\n", txb) ;
            backset  = Str2BOOLE(txb) ;

            bdelay = Set_PERIOD(0, DAYS) ;
            if (type == 3)
            {
                fscanf(in, "%d %s", &i1, txe) ;
                fprintf(out,"   Delay Num:         %8d\n", i1) ;
                fprintf(out,"   Delay Unit         %8s\n", txe) ;
                bdelay = Set_PERIOD((INTI) i1, Str2TERMUNIT(txe)) ;
            }

            fscanf(in, "%s %s", txc, txd) ;
            fprintf(out,"   comp.method        %8s\n", txc) ;
            fprintf(out,"   comp.freq.         %8s\n", txd) ;
            method   = Str2COMPMETHOD(txc) ;
            compfreq = Str2PMTFREQ(txd) ;

            index = Read_RATEINDEX(in, out) ;

            fscanf(in, "%lf %s", &dur, txb) ;
            fprintf(out,"   avg.  duration     %3.4lf\n", dur) ;
            fprintf(out,"   avgunit            %8s\n", txb) ;

            avgm = True ;
            if (type == 3)
            {
                fscanf(in, "%s", txe) ;
                avgm = Str2BOOLE(txe) ;
                fprintf(out,"   avgmethod          %8s\n", txe) ;
            }

            avgfl = Set_AVGFLOAT(dur, Str2TERMUNIT(txb), avgm) ;

            fscanf(in, "%d %s %s %s", &i1, txb, txc, txd) ;
            fprintf(out,"   delay              %8d\n", i1) ;
            fprintf(out,"   initial exchange ? %8s\n", txb) ;
            fprintf(out,"   interest only ??   %8s\n", txc) ;
            fprintf(out,"   bondtype           %8s\n", txd) ;

            delay = (INTI) i1 ;
            init_exch = Str2BOOLE(txb) ;
            io = Str2BOOLE(txc) ;
            bond = Str2BONDTYPE(txd) ;

            fprintf(out,"   the irregular amort schedule is...\n") ;
            fprintf(out,"       date  repayment\n") ;
            amort = Read_PLANARRAY(in) ;
            Write_PLANARRAY(out, amort) ;

            fprintf(out,"   the spread schedule is...\n") ;
            fprintf(out,"       date  spread\n") ;

            stepspr = Read_PLANARRAY(in) ;
            Write_PLANARRAY(out, stepspr) ;

            fprintf(out,"   the factor schedule is...\n") ;
            fprintf(out,"       date  factor\n") ;

            stepfac = Read_PLANARRAY(in) ;
            Write_PLANARRAY(out, stepfac) ;

            float1 = Set_FLOATRATE(&fbase, factor, backset, &bdelay,
                                          method, compfreq, &index, &avgfl,
                                          stepspr, stepfac) ;

            r1     = (init_exch == True ? 100.0 : 0.0) ;
            redemp = Set_REPAYMNT(bond, &dmatur, io, r1, NULL, amort,
                                  NULL, 0.0, 0.0) ;

            diff = Set_FRN(&redemp, &pday, &float1, &pday, delay) ;

            break ;

        case 4:

            diff.repay  = Read_REPAYMNT(in, out) ;
            diff.rday   = diff.pday = Read_PAYDAYDEF(in, out) ;
            diff.float1 = Read_FLOATRATE(in, out) ;
            diff.delay = 0 ;

            break ;

        case 5:
            fscanf(in,"%lf %lf", &coupon1, &spread) ;

            fprintf(out,"   LIBOR (next)   %lf\n", coupon1) ;
            fprintf(out,"   QM             %lf\n", spread) ;

            fscanf(in,"%ld %ld %s %s", &effect, &matur, txb, txc);

            fprintf(out,"   Eff            %ld\n", effect) ;
            fprintf(out,"   Last           %ld\n", matur) ;
            fprintf(out,"   Freq           %s\n", txb) ;
            fprintf(out,"   Cal            %s\n", txc) ;

            deffect = Cldr_YMD2Datestr(effect) ;
            dmatur  = Cldr_YMD2Datestr(matur) ;
            cal     = Str2CALCONV(txc) ;
            const INTI    freqInt = Cflw_MonthsBetweenPayments(Str2PMTFREQ(txb)) ;

            pseq = Set_PAYDAYSEQ(freqInt, MONTHS, NOODD, NOODD, ANCHOR, LAST) ;
            pday = Set_PAYDAYDEF(False, &deffect, NULL, &dmatur, False, &pseq,
                                 0, NULL) ;
            fbase  = Set_FLOATBASE(coupon1, cal, &deffect, spread, True) ;
            index  = Set_RATEINDEX(MMRATE, (FL64) freqInt, MONTHS, 
                                    NO_FREQUENCY, cal, 0.0) ;
            float1 = Set_FLOATRATE(&fbase, 1.0, False, NULL, NONE, ANNUALLY,
                                   &index, NULL, NULL, NULL) ;
            redemp = Set_REPAYMNT(BULLET, NULL, False, 0.0, NULL, NULL, NULL,
                                  0.0, 0.0) ;
            diff = Set_FRN(&redemp, &pday, &float1, &pday, 0) ;

            break ;
    }

    Write_VALIDATEError(out, Validate_FRN(&diff));

    return diff ;
}


/*
..
*/


FUTBOND Read_FUTBOND(FILE* in, FILE* out, DATESTR* settle)
{
    FUTBOND futb ;
    int     i1 ;
    INTI    i ;
    char    txb[25] ;
    COUNT type;

    type = Read_FormatId(in, out);

    switch (type)
    {
        case 1:

            futb.ddays = Read_DATEARRAY(in, out, &futb.ndays) ;

            fscanf(in, "%d", &i1) ;
            futb.nbond = (INTI) i1 ;

            futb.fixp = Alloc_FIXPAYARRAY(futb.nbond) ;

            for (i = 0; i < futb.nbond; i++)
                futb.fixp[i] = Read_FIXPAY(in, out, settle) ;

            fprintf(out, "   ConFac's\n") ;
            futb.cf = Read_FL64ARRAY(in, &i) ;
            Write_FL64ARRAY(out, futb.cf, i) ;

            fscanf(in, "%lf", &futb.futp) ;
            fprintf(out, "   Futures Price    %8lf\n", futb.futp) ;

            fscanf(in, "%s", txb) ;
            futb.margin = Str2BOOLE(txb) ;
            fprintf(out, "   Margining:       %8s\n", txb) ;

            futb.xdiv3w = False ;

            break ;

        case 2:

            futb.ddays = Read_DATEARRAY(in, out, &futb.ndays) ;

            fscanf(in, "%d", &i1) ;
            futb.nbond = (INTI) i1 ;

            futb.fixp = Alloc_FIXPAYARRAY(futb.nbond) ;

            for (i = 0; i < futb.nbond; i++)
                futb.fixp[i] = Read_FIXPAY(in, out, settle) ;

            fprintf(out, "   ConFac's\n") ;
            futb.cf = Read_FL64ARRAY(in, &i) ;
            Write_FL64ARRAY(out, futb.cf, i) ;

            fscanf(in, "%lf", &futb.futp) ;
            fprintf(out, "   Futures Price    %8lf\n", futb.futp) ;

            fscanf(in, "%s", txb) ;
            futb.margin = Str2BOOLE(txb) ;
            fprintf(out, "   Margining:       %8s\n", txb) ;

            futb.xdiv3w = False ;

            break ;

        case 3:

            futb.ddays = Read_DATEARRAY(in, out, &futb.ndays) ;

            fscanf(in, "%d", &i1) ;
            futb.nbond = (INTI) i1 ;

            futb.fixp = Alloc_FIXPAYARRAY(futb.nbond) ;

            fprintf(out,"   Deliverable Bonds:\n") ;
            for (i = 0; i < futb.nbond; i++)
                /* Read simple fixpay */
                futb.fixp[i] = Read_FIXPAY(in, out, settle) ;

            fprintf(out, "   ConFac's\n") ;
            futb.cf = Read_FL64ARRAY(in, &i) ;
            Write_FL64ARRAY(out, futb.cf, i) ;

            futb.futp = 0.0 ;
            futb.margin = False ;

            futb.xdiv3w = False ;

            break ;

        case 4:

            futb.ddays = Read_DATEARRAY(in, out, &futb.ndays) ;

            fscanf(in, "%d", &i1) ;
            futb.nbond = (INTI) i1 ;

            futb.fixp = Alloc_FIXPAYARRAY(futb.nbond) ;

            fprintf(out,"   Deliverable Bonds:\n") ;
            for (i = 0; i < futb.nbond; i++)
                /* Read simple fixpay */
                futb.fixp[i] = Read_FIXPAY(in, out, settle) ;

            fscanf(in, "%s", txb) ;
            futb.margin = Str2BOOLE(txb) ;
            fprintf(out, "   Margining:       %8s\n", txb) ;

            fscanf(in, "%lf", &futb.futp) ;
            fprintf(out, "   Futures Price    %8lf\n", futb.futp) ;

            fprintf(out, "   ConFac's\n") ;
            futb.cf = Read_FL64ARRAY(in, &i) ;
            Write_FL64ARRAY(out, futb.cf, i) ;

            futb.xdiv3w = False ;

            break;

        case 5:

            futb.ddays = Read_DATEARRAY(in, out, &futb.ndays) ;

            fscanf(in, "%d", &i1) ;
            futb.nbond = (INTI) i1 ;

            futb.fixp = Alloc_FIXPAYARRAY(futb.nbond) ;

            fprintf(out,"   Deliverable Bonds:\n") ;
            for (i = 0; i < futb.nbond; i++)
                /* Read simple fixpay */
                futb.fixp[i] = Read_FIXPAY(in, out, settle) ;

            fscanf(in, "%s", txb) ;
            futb.margin = Str2BOOLE(txb) ;
            fprintf(out, "   Margining:       %8s\n", txb) ;

            fprintf(out, "   ConFac's\n") ;
            futb.cf = Read_FL64ARRAY(in, &i) ;
            Write_FL64ARRAY(out, futb.cf, i) ;

            futb.futp = 0.0 ;
            futb.xdiv3w = False ;

            break ;

        case 6:

            futb.ddays = Read_DATEARRAY(in, out, &futb.ndays) ;

            fscanf(in, "%d", &i1) ;
            futb.nbond = (INTI) i1 ;

            futb.fixp = Alloc_FIXPAYARRAY(futb.nbond) ;

            for (i = 0; i < futb.nbond; i++)
                futb.fixp[i] = Read_FIXPAY(in, out, settle) ;

            fprintf(out, "   ConFac's\n") ;
            futb.cf = Read_FL64ARRAY(in, &i) ;
            Write_FL64ARRAY(out, futb.cf, i) ;

            fscanf(in, "%lf", &futb.futp) ;
            fprintf(out, "   Futures Price    %8lf\n", futb.futp) ;

            fscanf(in, "%s", txb) ;
            futb.margin = Str2BOOLE(txb) ;
            fprintf(out, "   Margining:       %8s\n", txb) ;
            
            futb.xdiv3w = False ;

            break ;

    }

    Write_VALIDATEError(out, Validate_FUTBOND(&futb));

    return futb ;
}


/*
..
*/


FUTBONDBM Read_FUTBONDBM(FILE* in, FILE* out)
{
    FUTBONDBM fut ;
    int       i1 ;
    INTI      i ;
    char      txb[25] ;
    YYYYMMDD  ymd ;
    COUNT     type ;
    FL64      cfy ;

    fprintf(out, "   FutBondBM\n") ;

    type = Read_FormatId(in, out) ;

    switch (type)
    {
        case 1:

            fscanf(in, "%s", txb) ;
            fut.cntr = Str2CFCONV(txb) ;
            fprintf(out, "   Contract:      %8s\n", txb) ;

            fscanf(in, "%ld", &ymd) ;
            fut.first = Cldr_YMD2Datestr((YYYYMMDD) ymd) ;
            fprintf(out, "   First:         %8ld\n", ymd) ;

            fscanf(in, "%ld", &ymd) ;
            fut.last = Cldr_YMD2Datestr((YYYYMMDD) ymd) ;
            fprintf(out, "   Last:          %8ld\n", ymd) ;

            fscanf(in, "%d", &i1) ;
            fut.nbond = (INTI) i1 ;

            fut.bonds = Alloc_BONDBMARRAY(fut.nbond) ;

            for (i = 0; i < fut.nbond; i++)
                fut.bonds[i] = Read_BONDBM(in, out) ;

            fscanf(in, "%lf", &cfy) ;
            fut.cf_yield = cfy ;
            fprintf(out, "   Conv. Fac. Yield   %lf\n", cfy) ;

            fut.do_cf = True ;
            fut.cf = NULL ;

            break ;
    }

    Write_VALIDATEError(out, Validate_FUTBONDBM(&fut));

    return fut ;
}


/*
..
*/


REPOBOND Read_REPOBOND(FILE* in, FILE* out)
{
    REPOBOND repo ;
    char     txb[15], txc[15], txd[15] ;
    YYYYMMDD ymd1, ymd2 ;
    FL64     sell, rate ;

    fscanf(in, "%ld %ld %lf %lf %s %s %s",
           &ymd1, &ymd2, &sell, &rate, txd, txb, txc) ;

    repo.sell_date  = Cldr_YMD2Datestr(ymd1) ;
    repo.buy_date   = Cldr_YMD2Datestr(ymd2) ;
    repo.sell_price = sell ;
    repo.rate       = rate ;
    repo.irr        = Str2IRRCONV(txd) ;
    repo.cal        = Str2CALCONV(txb) ;
    repo.reverse    = Str2BOOLE(txc) ;

    fprintf(out,"   sell_date   %ld\n", ymd1) ;
    fprintf(out,"   buy_date    %ld\n", ymd2) ;
    fprintf(out,"   sell_price  %lf\n", sell) ;
    fprintf(out,"   rate        %lf\n", rate) ;
    fprintf(out,"   IRR conv    %8s\n", txd) ;
    fprintf(out,"   Calendar    %8s\n", txb) ;
    fprintf(out,"   Reverse     %8s\n", txc) ;

    repo.bond = Read_FIXPAY(in, out, &repo.sell_date) ;

    Write_VALIDATEError(out, Validate_REPOBOND(&repo));
  
    return repo ;
}


/*
..
*/


FLOATBASE Read_FLOATBASE(FILE* in, FILE* out)
{
    FLOATBASE fbase ;
    YYYYMMDD  ymd ;
    char      txb[20], txc[20] ;

    fscanf(in, "%lf %s %ld %lf %s",
           &fbase.coupon1, txb, &ymd, &fbase.spread, txc) ;

    fprintf(out, "   Coupon1        %lf\n", fbase.coupon1) ;
    fprintf(out, "   Calconv        %s\n", txb) ;
    fprintf(out, "   Effective      %ld\n", ymd) ;
    fprintf(out, "   Spread         %lf\n", fbase.spread) ;
    fprintf(out, "   Is Fix ?       %s\n", txc) ;

    fbase.cal       = Str2CALCONV(txb) ;
    fbase.is_fix    = Str2BOOLE(txc) ;
    fbase.effective = Cldr_YMD2Datestr(ymd) ;

    Write_VALIDATEError(out, Validate_FLOATBASE(&fbase));

    return fbase ;
}

/*
..
*/


DIFFSWAP Read_DIFFSWAP(FILE* in, FILE* out)
{
  DIFFSWAP diff ;
  char     txb[20] ;
  COUNT      type ;

  fprintf(out, "   DIFFSWAP:\n") ;
  type = Read_FormatId(in, out) ;

  switch (type)
  {
    case 1:  /* for standard index --- MUST be used for HWCF! */
      diff.pday  = Read_PAYDAYDEF(in, out) ;
      diff.fbase = Read_FLOATBASE(in, out) ;
      
      fscanf(in, "%s", txb) ;
      diff.io = Str2BOOLE(txb) ;
      fprintf(out, "   IO             %s\n", txb) ;
      
      /* set index to standard */
      diff.index = Set_RATEINDEX(MMRATE, (FL64) diff.pday.pseq.term,
                        diff.pday.pseq.unit, NO_FREQUENCY, 
                        diff.fbase.cal, 0.0) ;
      diff.arrears = False ;

      break ;

    case 2:
      diff.pday  = Read_PAYDAYDEF(in, out) ;
      diff.fbase = Read_FLOATBASE(in, out) ;
      
      fscanf(in, "%s", txb) ;
      diff.io = Str2BOOLE(txb) ;
      fprintf(out, "   IO             %s\n", txb) ;
      
      diff.index = Read_RATEINDEX(in, out) ;
      diff.arrears = Read_BOOLE(in, out, "    Arrears? ") ;

      break ;
  }

  Write_VALIDATEError(out, Validate_DIFFSWAP(&diff));

  return diff ;
}


/*
..
*/

SWAPFLOAT Read_SWAPFLOAT(FILE* in, FILE* out)
{
    SWAPFLOAT  diff ;
    DATESTR    dzero, deffect, dfirst, dmatur ;
    YYYYMMDD   effect, first, matur ;
    int        i1 ;
    INTI       delay;
    PMTFREQ    compfreq, freq ;
    CALCONV    cal ;
    EOMCONV    eom ;
    SEQCONV    seq ;
    PAYDAYDEF  pday ;
    PAYDAYSEQ  pseq ;
    FLOATRATE  float1 ;
    FLOATBASE  fbase ;
    FL64       r1, spread, dur, factor, coupon1 ;
    BOOLE      avgm, is_fix, io, init_exch, backset ;
    BONDTYPE   bond ;
    COMPMETHOD method ;
    RATEINDEX  index ;
    AVGFLOAT   avgfl ;
    PERIOD     bdelay ;
    REPAYMNT   redemp ;
    PLAN_STR   *amort, *stepfac, *stepspr ;
    char       txb[25], txc[25], txd[25], txe[25], txf[25] ;
    COUNT      type ;

    fprintf(out, "   SWAPFLOAT:\n") ;
    type = Read_FormatId(in, out) ;

    switch (type)
    {
        case 1:

            diff.repay  = Read_REPAYMNT(in, out) ;
            diff.rday   = Read_PAYDAYDEF(in, out) ;
            diff.float1 = Read_FLOATRATE(in, out) ;
            diff.pday   = Read_PAYDAYDEF(in, out) ;

            fscanf(in, "%d", &i1) ;
            diff.delay = (INTI) i1 ;
            fprintf(out, "   Delay          %8d\n", i1) ;
            break ;

        case 2:
        case 3:

            /* This is the 'original ' swaptest stuff */
            dzero = Cldr_YMD2Datestr((YYYYMMDD) 0) ;

            deffect = Read_DATESTR(in, out, "   Effective day   ") ; 
            dfirst = Read_DATESTR(in, out, "   First payday   ") ; 
            dmatur = Read_DATESTR(in, out, "   Maturity   ") ; 
            freq = Read_PMTFREQ(in, out, "   Pay frequency   ") ; 
            eom = Read_EOMCONV(in, out, "   Eomconv   ") ;
            cal = Read_CALCONV(in, out, "   calendar   ") ;
            seq = Read_SEQCONV(in, out, "") ;

            pday = cflw_set_payday(&dfirst, &dzero, &dmatur, False,
                                   Cflw_MonthsBetweenPayments(freq),
                                   MONTHS, NOODD, NOODD, seq, eom) ;


            coupon1 = Read_FL64(in, out, "   First coupon   ") ; 
            is_fix = True ;
            if (type == 3)
                is_fix = Read_BOOLE(in, out, "   is_fix   ") ;

            factor = Read_FL64(in, out, "   Factor   ") ;
            spread = Read_FL64(in, out, "   Spread   ") ;

            fbase = Set_FLOATBASE(coupon1, cal, &deffect, spread, is_fix) ;

            backset = Read_BOOLE(in, out, "   Backset ??   ") ;

            bdelay = Set_PERIOD(0, DAYS) ;
            if (type == 3)
            {
                fscanf(in, "%d %s", &i1, txe) ;
                fprintf(out,"   Delay Num:         %8d\n", i1) ;
                fprintf(out,"   Delay Unit         %8s\n", txe) ;
                bdelay = Set_PERIOD((INTI) i1, Str2TERMUNIT(txe)) ;
            }

            method = Read_COMPMETHOD(in ,out, "   Comp.method   ") ;
            compfreq = Read_PMTFREQ(in, out, "   Comp.freq.   ") ;

            index = Read_RATEINDEX(in, out) ;

            fscanf(in, "%lf %s", &dur, txb) ;
            fprintf(out,"   avg.  duration     %3.4lf\n", dur) ;
            fprintf(out,"   avgunit            %8s\n", txb) ;

            avgm = True ;
            if (type == 3)
            {
                fscanf(in, "%s", txe) ;
                avgm = Str2BOOLE(txe) ;
                fprintf(out,"   avgmethod          %8s\n", txe) ;
            }

            avgfl = Set_AVGFLOAT(dur, Str2TERMUNIT(txb), avgm) ;

            fscanf(in, "%d %s %s %s", &i1, txb, txc, txd) ;
            fprintf(out,"   delay              %8d\n", i1) ;
            fprintf(out,"   initial exchange ? %8s\n", txb) ;
            fprintf(out,"   interest only ??   %8s\n", txc) ;
            fprintf(out,"   bondtype           %8s\n", txd) ;

            delay = (INTI) i1 ;
            init_exch = Str2BOOLE(txb) ;
            io = Str2BOOLE(txc) ;
            bond = Str2BONDTYPE(txd) ;

            fprintf(out,"   the irregular amort schedule is...\n") ;
            fprintf(out,"       date  repayment\n") ;
            amort = Read_PLANARRAY(in) ;
            Write_PLANARRAY(out, amort) ;

            fprintf(out,"   the spread schedule is...\n") ;
            fprintf(out,"       date  spread\n") ;

            stepspr = Read_PLANARRAY(in) ;
            Write_PLANARRAY(out, stepspr) ;

            fprintf(out,"   the factor schedule is...\n") ;
            fprintf(out,"       date  factor\n") ;

            stepfac = Read_PLANARRAY(in) ;
            Write_PLANARRAY(out, stepfac) ;

            float1 = Set_FLOATRATE(&fbase, factor, backset, &bdelay,
                                   method, compfreq, &index, &avgfl,
                                   stepspr, stepfac) ;

            r1     = (init_exch == True ? 100.0 : 0.0) ;
            redemp = Set_REPAYMNT(bond, NULL, io, r1, NULL, amort,
                                  NULL, 0.0, 0.0) ;

            diff = Set_SWAPFLOAT(&redemp, NULL, &float1, &pday, delay) ;

            break ;

        case 4:

            diff.repay  = Read_REPAYMNT(in, out) ;
            diff.rday   = diff.pday = Read_PAYDAYDEF(in, out) ;
            diff.float1 = Read_FLOATRATE(in, out) ;
            diff.delay = 0 ;

            break ;
        case 5:
            fscanf(in, "%ld %ld %ld %s %s %s %lf %s %lf %s",
                  &effect, &first, &matur, txb, txd, txe, &coupon1, txc,
                  &spread, txf) ;

            deffect = Cldr_YMD2Datestr(effect) ;
            is_fix  = Str2BOOLE(txc) ;
            dfirst  = Cldr_YMD2Datestr(first) ;
            dmatur  = Cldr_YMD2Datestr(matur) ;
            freq    = Str2PMTFREQ(txb) ;
            cal     = Str2CALCONV(txf) ;
            pseq    = Set_PAYDAYSEQ(Cflw_MonthsBetweenPayments(freq), 
                                    MONTHS, NOODD, NOODD, Str2SEQCONV(txe),
                                    Str2EOMCONV(txd)) ;
            pday = Set_PAYDAYDEF(True, &dfirst, NULL, &dmatur,
                                 False, &pseq, 0, NULL) ;

            fprintf(out,"\n   first date     %8ld\n", first) ;
            fprintf(out,"   last  date     %8ld\n", matur) ;
            fprintf(out,"   effective      %8ld\n", effect) ;
            fprintf(out,"   eom            %8s\n", txd) ;
            fprintf(out,"   freq           %8s\n", txb) ;
            fprintf(out,"   perconv        %8s\n", txe) ;
            fprintf(out,"   coupon1        %8lf\n", coupon1) ;
            fprintf(out,"   IS FIX         %8s\n", txc) ;
            fprintf(out,"   spread         %8lf\n", spread) ;


            /* Now read index data */
            index  = Read_RATEINDEX(in, out) ;
            fbase  = Set_FLOATBASE(coupon1, cal, &deffect, spread, is_fix);
            float1 = Set_FLOATRATE(&fbase, 1.0, False, NULL, NONE, ANNUALLY,
                                   &index, NULL, NULL, NULL) ;
            diff = Set_SWAPFLOAT(NULL, NULL, &float1, &pday, 0) ;

            break ;

        case 6:
            fscanf(in, "%ld %ld %ld %s %s %s %lf %s %lf %s %lf",
                  &effect, &first, &matur, txb, txd, txe, &coupon1, txc,
                  &spread, txf, &factor) ;

            deffect = Cldr_YMD2Datestr(effect) ;
            is_fix  = Str2BOOLE(txc) ;
            dfirst  = Cldr_YMD2Datestr(first) ;
            dmatur  = Cldr_YMD2Datestr(matur) ;
            freq    = Str2PMTFREQ(txb) ;
            cal     = Str2CALCONV(txf) ;
            pseq    = Set_PAYDAYSEQ(Cflw_MonthsBetweenPayments(freq), 
                                    MONTHS, NOODD, NOODD, Str2SEQCONV(txe),
                                    Str2EOMCONV(txd)) ;
            pday = Set_PAYDAYDEF(True, &dfirst, NULL, &dmatur,
                                 False, &pseq, 0, NULL) ;

            fprintf(out,"\n   first date     %8ld\n", first) ;
            fprintf(out,"   last  date     %8ld\n", matur) ;
            fprintf(out,"   effective      %8ld\n", effect) ;
            fprintf(out,"   eom            %8s\n", txd) ;
            fprintf(out,"   freq           %8s\n", txb) ;
            fprintf(out,"   perconv        %8s\n", txe) ;
            fprintf(out,"   coupon1        %8lf\n", coupon1) ;
            fprintf(out,"   IS FIX         %8s\n", txc) ;
            fprintf(out,"   spread         %8lf\n", spread) ;
            fprintf(out,"   factor         %8lf\n", factor) ;

            /* Now read index data */
            index  = Read_RATEINDEX(in, out) ;
            fbase  = Set_FLOATBASE(coupon1, cal, &deffect, spread, is_fix);
            float1 = Set_FLOATRATE(&fbase, factor, False, NULL, NONE, ANNUALLY,
                                   &index, NULL, NULL, NULL) ;
            diff = Set_SWAPFLOAT(NULL, NULL, &float1, &pday, 0) ;

            break ;
    }

    Write_VALIDATEError(out, Validate_SWAPFLOAT(&diff));

    return diff ;
}


/*
..
*/

CMCONVADJ Read_CMCONVADJ(FILE* in, FILE* out)
{
    CMCONVADJ cmadj ;
    char      txa[30] ;
    COUNT type;

    fprintf(out,"   CMCONVADJ:\n") ;

    type = Read_FormatId(in, out);

    switch (type)
    {
        case 1:

            fscanf(in, "%s", txa) ;
            fprintf(out,"   CMADJTYPE:    %8s\n", txa) ;
            cmadj.order = Str2CMADJTYPE(txa) ;

            cmadj.volCM    = Read_VOL_STR(in, out) ;
            cmadj.volLIBOR = Read_VOL_STR(in, out) ;

            fscanf(in, "%lf", &cmadj.corr) ;
            fprintf(out,"   Corr:         %lf\n", cmadj.corr) ;
    }

    Write_VALIDATEError(out, Validate_CMCONVADJ(&cmadj));

    return cmadj ;
}


/*
..
*/

RATEINDEX Read_RATEINDEX(FILE* in, FILE* out)
{
    RATEINDEX index ;
    RATECONV  rt ;
    PMTFREQ   freq ;
    TERMUNIT  unit ;
    CALCONV   cal ;
    FL64      dur, coupon ;
    char      txc[25] ;
    COUNT type;

    fprintf(out, "   RATEINDEX\n") ;

    type = Read_FormatId(in, out);

    switch (type)
    {
        case 1:
            fscanf(in, "%lf %s", &dur, txc) ;
            unit = Str2TERMUNIT(txc) ;
            fprintf(out,"   LIBORdur    %8lf\n", dur) ;
            fprintf(out,"   LIBORunit   %8s\n", txc) ;

            fscanf(in, "%s", txc) ;
            freq = Str2PMTFREQ(txc) ;
            fprintf(out,"   LIBORfreq   %8s\n", txc) ;

            rt = (freq == NO_FREQUENCY ? MMRATE : PARYIELD) ;
            cal = (freq == NO_FREQUENCY ? ACT360 : EU30E360) ;
            index = Set_RATEINDEX(rt, dur, unit, freq, cal, 0.0) ;
            break ;

        case 2:
            
            fscanf(in, "%s", txc) ;
            rt = Str2RATECONV(txc) ;
            fprintf(out,"   RateConv    %8s\n", txc) ;

            fscanf(in, "%lf %s", &dur, txc) ;
            unit = Str2TERMUNIT(txc) ;
            fprintf(out,"   LIBORdur    %8lf\n", dur) ;
            fprintf(out,"   LIBORunit   %8s\n", txc) ;

            fscanf(in, "%s", txc) ;
            freq = Str2PMTFREQ(txc) ;
            fprintf(out,"   LIBORfreq   %8s\n", txc) ;

            cal = (freq == NO_FREQUENCY ? ACT360 : EU30E360) ;
            index = Set_RATEINDEX(rt, dur, unit, freq, cal, 0.0) ;
            break ;

        case 3:
            rt = Read_RATECONV(in, out, "");
            dur = Read_FL64(in, out, "");
            unit = Read_TERMUNIT(in, out, "");
            freq = Read_PMTFREQ(in, out, "");
            cal = Read_CALCONV(in, out, "");
            index = Set_RATEINDEX(rt, dur, unit, freq, cal, 0.0) ;
            break;

        case 4:
            rt = Read_RATECONV(in, out, "");
            dur = Read_FL64(in, out, "");
            unit = Read_TERMUNIT(in, out, "");
            freq = Read_PMTFREQ(in, out, "");
            cal = Read_CALCONV(in, out, "");
            coupon = Read_FL64(in, out, "");
            index = Set_RATEINDEX(rt, dur, unit, freq, cal, coupon) ;
            break;
    }

    Write_VALIDATEError(out, Validate_RATEINDEX(&index));

    return index ;
}



/*
..
*/




INTI Write_CTDRESdiff(FILE* in, FILE* out, CTDRES* res, FL64 acc)
{
    INTI     n, dif1, diff, i ;
    YYYYMMDD ymd ;
    BOOLE    ok ;
    int      i1 ;
    FL64     f64 ;

    diff = 0 ;

    fscanf(in, "%d %d", &ok, &i1) ;
    n = (INTI) i1 ;

    diff = (ok != res->ok) ;

    if (n == res->ndeliv)
    {
        for (i = 0; i < n; i++)
        {
            fscanf(in, "%lf %d %ld", &f64, &i1, &ymd) ;
            dif1 = fabs(f64 - res->fwd_rpo[i]) > acc ;
            dif1 = dif1 || i1 != res->CTDix[i] ;
            dif1 = dif1 || ymd != Cldr_Datestr2YMD(&res->deliv[i]) ;
            fprintf(out, "%d; %lf %lf %d %d %ld %ld\n",
                    dif1, f64, res->fwd_rpo[i], i1, res->CTDix[i],
                    ymd, Cldr_Datestr2YMD(&res->deliv[i])) ;

            diff = diff || dif1 ;
        }
    }
    else
    {
        diff = 1 ;
        fprintf(out, "1; Fill mismatch\n") ;
        for (i = 0; i < n; i++)
            fscanf(in, "%lf %d %ld", &f64, &i1, &ymd) ;
    }


    return diff ;
}

/*
..
*/


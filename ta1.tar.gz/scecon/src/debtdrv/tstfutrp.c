/* SCID @(#)tstfutrp.c	1.5 (SimCorp) 99/02/19 14:13:57 */

/************************************************************************
*
*   project     SCecon
*
************************************************************************/

/*** includes ***********************************************************/
#include <string.h>

#include <futrp.h>
#include <futio.h>
#include <bondio.h>
#include <ioconv.h>

INTI futrpostest(char* txa, FILE* in, FILE* out)
{
    char            txb[25], txc[25], txpl[125] ;
    int             i1 ;
    FL64            notnal, tol, fwd, not ;
    HOLI_STR        holi ;
    BOOLE           zero, zerocflw, zerodisc, idxadj ;
    INTI            nbuck, diff, i, start, n, nbucket, nbuckcflw, nbuckdisc ;
    YYYYMMDD        ymd ;
    DATESTR         analys, dstart, today ;
    DISCFAC         df, df_cflw, df_disc ;
    BUCKETARRAY     bucket, bucket_cflw, bucket_disc ;
    DFSPREAD        dfs ;
    TRADEINFO       trade;
    DFSPREADARRAY   dfsarr ;
    DELTASET        ds, ds_cflw, ds_disc ;
    RISKPOSLIST     rpos, exprpos ;
    FUTBOND         futb;
    REPOBOND        repo;
    FRA_STR         fra;
    SWAPFIX         sfix;
    SWAPFLOAT       sfl ;
    VOL_STR         CMTvol ;
    CMCONVADJ       cmadj ;
    DFWHICH         which_cflw, which_disc ;
    FRN             frn ;
    INDEXFAC        fac, debfac, crefac ;
    INDEXBOND       idxbond ;
    INDEXLOAN       idxloan ;
    FXRISKSET       fxr;

    diff = -1 ;

    if (!strcmp("FutBond_DF2RiskPos()", txa))
    {
        fscanf(in,"%lf %ld", &tol, &start) ;

        dstart = Cldr_YMD2Datestr(start) ;     /* Settle */

        fprintf(out,"?; testing %s\n", txa) ;
        fprintf(out,"   Settle             %8ld\n", start) ;

        futb = Read_FUTBOND(in, out, &dstart) ;
        dfsarr = Read_DFSPREADARRAY(in, out, &n) ;

        fscanf(in, "%lf %lf", &fwd, &notnal) ;
        fprintf(out,"   Notional    %lf\n", notnal) ;
        fprintf(out,"   Fwd         %lf\n", fwd) ;
        
        df     = Read_DISCFAC(in, out) ;
        holi   = Read_HOLI_STR(in, out) ;
        bucket = Read_BUCKETARRAY(in, out, &nbucket) ;

        fscanf(in, "%s", txb) ;
        zero = Str2BOOLE(txb) ;
        fprintf(out,"   DECF        %8s\n", txb) ;

        fxr = Read_FXRISKSET(in, out) ;

        ds = Disc_DeltaPrep(&df, bucket, nbucket, &holi, True, df.irr,
                             df.freq, False, zero, DF_BOTH) ;

        rpos = FutBond_DF2RiskPos(&dstart, &futb, n, dfsarr, fwd, notnal, 
                                  &df, &holi, &ds, &fxr) ;

        exprpos.token = Alloc_RISKTOKENARRAY(rpos.npos) ;
        exprpos.pos   = Alloc_FL64ARRAY(rpos.npos) ;
        exprpos.npos  = rpos.npos ;

        for (i = 0; i < exprpos.npos; i++)
        {
            Read_RISKTOKEN(in, out, &exprpos.token[i]) ;
            fscanf(in, "%lf", &exprpos.pos[i]) ;
        }

        diff = Write_riskposdiff(exprpos, rpos, out, tol) ;

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_FUTBOND(&futb) ;
        Free_DFSPREADARRAY(dfsarr) ;

        Free_DATEARRAY(holi.holidays) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_DELTASET(&ds) ;
        Free_BUCKETARRAY(bucket) ;
        Free_RISKPOSLIST(&rpos);
        Free_RISKPOSLIST(&exprpos);
    }
    else if (!strcmp("RepoBond_DF2RiskPos()", txa))
    {
        fscanf(in, "%lf %ld", &tol, &ymd) ;

        analys = Cldr_YMD2Datestr(ymd) ;

        fprintf(out,"   Testing %s\n", txa) ;
        fprintf(out,"   analys      %ld\n", ymd) ;

        repo = Read_REPOBOND(in, out) ;
        fscanf(in, "%lf", &notnal) ;
        fprintf(out,"   Notional    %lf\n", notnal) ;
        df     = Read_DISCFAC(in, out) ;
        dfs    = Read_DFSPREAD(in, out) ;
        holi   = Read_HOLI_STR(in, out) ;
        bucket = Read_BUCKETARRAY(in, out, &nbucket) ;

        fscanf(in, "%s", txb) ;
        zero = Str2BOOLE(txb) ;
        fprintf(out,"   DECF        %8s\n", txb) ;

        fxr = Read_FXRISKSET(in, out) ;

        ds = Disc_DeltaPrep(&df, bucket, nbucket, &holi, True, df.irr,
                             df.freq, False, zero, DF_BOTH) ;

        rpos = RepoBond_DF2RiskPos(&analys, &repo, notnal, 
                                   &df, &dfs, &holi, &ds, &fxr) ;

        exprpos.token = Alloc_RISKTOKENARRAY(rpos.npos) ;
        exprpos.pos   = Alloc_FL64ARRAY(rpos.npos) ;
        exprpos.npos  = rpos.npos ;

        for (i = 0; i < exprpos.npos; i++)
        {
            Read_RISKTOKEN(in, out, &exprpos.token[i]) ;
            fscanf(in, "%lf", &exprpos.pos[i]) ;
        }

        diff = Write_riskposdiff(exprpos, rpos, out, tol) ;

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;
        
        Free_REPOBOND(&repo);
        Free_DATEARRAY(holi.holidays) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_DELTASET(&ds) ;
        Free_BUCKETARRAY(bucket) ;
        Free_RISKPOSLIST(&rpos);
        Free_RISKPOSLIST(&exprpos);
        Free_DFSPREAD(&dfs) ;
    }
    else if (!strcmp("FRA_DF2RiskPos()", txa))
    {
        fscanf(in, "%lf %ld", &tol, &ymd) ;

        analys = Cldr_YMD2Datestr(ymd) ;

        fprintf(out,"   Testing %s\n", txa) ;
        fprintf(out,"   analys      %ld\n", ymd) ;

        fra = Read_FRA_STR(in, out) ;

        fscanf(in, "%lf", &not) ;
        fprintf(out,"   Notional    %lf\n", not) ;
        df     = Read_DISCFAC(in, out) ;
        holi   = Read_HOLI_STR(in, out) ;
        bucket = Read_BUCKETARRAY(in, out, &nbuck) ;

        fscanf(in, "%s", txc) ;
        zero = Str2BOOLE(txc) ;
        fprintf(out,"   DECF        %8s\n", txc) ;

        fxr = Read_FXRISKSET(in, out) ;

        ds = Disc_DeltaPrep(&df, bucket, nbuck, &holi, True, df.irr,
                             df.freq, False, zero, DF_BOTH) ;

        rpos = FRA_DF2RiskPos(&analys, &fra, not, &df,
                              &holi, &ds, &fxr) ;

        exprpos.token = Alloc_RISKTOKENARRAY(rpos.npos) ;
        exprpos.pos   = Alloc_FL64ARRAY(rpos.npos) ;
        exprpos.npos  = rpos.npos ;

        for (i = 0; i < exprpos.npos; i++)
        {
            Read_RISKTOKEN(in, out, &exprpos.token[i]) ;
            fscanf(in, "%lf", &exprpos.pos[i]) ;
        }

        diff = Write_riskposdiff(exprpos, rpos, out, tol) ;

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_DATEARRAY(holi.holidays) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_DELTASET(&ds) ;
        Free_BUCKETARRAY(bucket) ;
        Free_RISKPOSLIST(&rpos);
        Free_RISKPOSLIST(&exprpos);
    }

    else if (!strcmp("IRF_DF2RiskPos()", txa))
    {
        fscanf(in, "%lf %ld", &tol, &ymd) ;

        analys = Cldr_YMD2Datestr(ymd) ;

        fprintf(out,"   Testing %s\n", txa) ;
        fprintf(out,"   analys      %ld\n", ymd) ;

        fra = Read_FRA_STR(in, out) ;

        fscanf(in, "%lf", &not) ;
        fprintf(out,"   Notional    %lf\n", not) ;
        df     = Read_DISCFAC(in, out) ;
        holi   = Read_HOLI_STR(in, out) ;
        bucket = Read_BUCKETARRAY(in, out, &nbuck) ;

        fscanf(in, "%s", txc) ;
        zero = Str2BOOLE(txc) ;
        fprintf(out,"   DECF        %8s\n", txc) ;

        fxr = Read_FXRISKSET(in, out) ;

        ds = Disc_DeltaPrep(&df, bucket, nbuck, &holi, True, df.irr,
                             df.freq, False, zero, DF_BOTH) ;

        rpos = IRF_DF2RiskPos(&analys, &fra, not, &df,
                              &holi, &ds, &fxr) ;

        exprpos.token = Alloc_RISKTOKENARRAY(rpos.npos) ;
        exprpos.pos   = Alloc_FL64ARRAY(rpos.npos) ;
        exprpos.npos  = rpos.npos ;

        for (i = 0; i < exprpos.npos; i++)
        {
            Read_RISKTOKEN(in, out, &exprpos.token[i]) ;
            fscanf(in, "%lf", &exprpos.pos[i]) ;
        }

        diff = Write_riskposdiff(exprpos, rpos, out, tol) ;

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_DATEARRAY(holi.holidays) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_DELTASET(&ds) ;
        Free_BUCKETARRAY(bucket) ;
        Free_RISKPOSLIST(&rpos);
        Free_RISKPOSLIST(&exprpos);
    }

    else if (!strcmp("SwapFix_DF2RiskPos()", txa))
    {
        fprintf(out,"   Testing %s\n", txa) ;

        fscanf(in, "%lf", &tol) ;

        sfix = Read_SWAPFIX(in, out) ;
        fscanf(in, "%lf", &notnal) ;
        fprintf(out,"   Notional    %lf\n", notnal) ;
        df     = Read_DISCFAC(in, out) ;
        holi   = Read_HOLI_STR(in, out) ;
        bucket = Read_BUCKETARRAY(in, out, &nbucket) ;

        fscanf(in, "%s", txb) ;
        zero = Str2BOOLE(txb) ;
        fprintf(out,"   DECF        %8s\n", txb) ;

        fxr = Read_FXRISKSET(in, out) ;

        ds = Disc_DeltaPrep(&df, bucket, nbucket, &holi, True, df.irr,
                             df.freq, False, zero, DF_BOTH) ;

        if (GetPlanFill(df.disc) > 0)
            analys = df.disc->day[0] ;
        else
            analys = Cldr_YMD2Datestr((YYYYMMDD) 19900101) ;

        rpos = SwapFix_DF2RiskPos(&analys, &sfix, notnal, &df,
                                  &holi, &ds, &fxr) ;

        exprpos.token = Alloc_RISKTOKENARRAY(rpos.npos) ;
        exprpos.pos   = Alloc_FL64ARRAY(rpos.npos) ;
        exprpos.npos  = rpos.npos ;

        for (i = 0; i < exprpos.npos; i++)
        {
            Read_RISKTOKEN(in, out, &exprpos.token[i]) ;
            fscanf(in, "%lf", &exprpos.pos[i]) ;
        }

        diff = Write_riskposdiff(exprpos, rpos, out, tol) ;

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_SWAPFIX(&sfix);
        Free_DATEARRAY(holi.holidays) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_DELTASET(&ds) ;
        Free_BUCKETARRAY(bucket) ;
        Free_RISKPOSLIST(&rpos);
        Free_RISKPOSLIST(&exprpos);
    }

    else if (!strcmp("SwapFl_DF2RiskPos()", txa))
    {
        fprintf(out,"   Testing %s\n", txa) ;

        fscanf(in,"%lf %ld", &tol, &ymd) ;
        today = Cldr_YMD2Datestr(ymd) ;
        fprintf(out,"   Analysdate    %8ld\n", ymd) ;

        sfl = Read_SWAPFLOAT(in, out) ;
        fscanf(in, "%lf", &notnal) ;
        fprintf(out,"   Notional    %lf\n", notnal) ;
        df_cflw = Read_DISCFAC(in, out) ;
        df_disc = Read_DISCFAC(in, out) ;
        CMTvol  = Read_VOL_STR(in, out) ;
        holi    = Read_HOLI_STR(in, out) ;

        bucket_cflw = Read_BUCKETARRAY(in, out, &nbuckcflw) ;
        fscanf(in, "%s", txb) ;
        zerocflw = Str2BOOLE(txb) ;
        fprintf(out,"   DECF        %8s\n", txb) ;
        fscanf(in, "%s", txb) ;
        which_cflw = Str2DFWHICH(txb) ;
        fprintf(out,"   Which       %8s\n", txb) ;

        bucket_disc = Read_BUCKETARRAY(in, out, &nbuckdisc) ;
        fscanf(in, "%s", txb) ;
        zerodisc = Str2BOOLE(txb) ;
        fprintf(out,"   DECF        %8s\n", txb) ;
        fscanf(in, "%s", txb) ;
        which_disc = Str2DFWHICH(txb) ;
        fprintf(out,"   Which       %8s\n", txb) ;

        fxr = Read_FXRISKSET(in, out) ;

        ds_cflw = Disc_DeltaPrep(&df_cflw, bucket_cflw, nbuckcflw, &holi, 
                                  True, df_cflw.irr, df_cflw.freq, False, 
                                  zerocflw, which_cflw) ;
        ds_disc = Disc_DeltaPrep(&df_disc, bucket_disc, nbuckdisc, &holi, 
                                  True, df_disc.irr, df_disc.freq, False, 
                                  zerodisc, which_disc) ;

        cmadj = Set_CMCONVADJ(CMADJ_ORIG, &CMTvol, NULL, 0.0) ;

        rpos = SwapFl_DF2RiskPos(&today, &sfl, notnal, &df_cflw, &df_disc, 
                                 &cmadj, &holi, &ds_cflw, &ds_disc, &fxr) ;

        fscanf(in, "%d", &i1) ;
        exprpos.npos = (INTI) i1 ;
        exprpos.token = Alloc_RISKTOKENARRAY(exprpos.npos) ;
        exprpos.pos   = Alloc_FL64ARRAY(exprpos.npos) ;

        for (i = 0; i < exprpos.npos; i++)
        {
            Read_RISKTOKEN(in, out, &exprpos.token[i]) ;
            fscanf(in, "%lf", &exprpos.pos[i]) ;
        }

        diff = Write_riskposdiff(exprpos, rpos, out, tol) ;

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_SWAPFLOAT(&sfl);
        Free_DATEARRAY(holi.holidays) ;
        Free_DELTASET(&ds_cflw) ;
        Free_DELTASET(&ds_disc) ;
        Free_PLANARRAY(df_cflw.disc, 1) ;
        Free_PLANARRAY(df_disc.disc, 1) ;
        Free_BUCKETARRAY(bucket_cflw) ;
        Free_BUCKETARRAY(bucket_disc) ;
        Free_PLANARRAY(CMTvol.vol, 1) ;
        Free_RISKPOSLIST(&rpos);
        Free_RISKPOSLIST(&exprpos);
    }

    else if (!strcmp("FRN_DF2RiskPos()", txa))
    {
        fprintf(out,"   Testing %s\n", txa) ;

        /* Read data */
        tol     = Read_FL64(in, out, "Tolerance   ") ;
        today   = Read_DATESTR(in, out, "Analysdate  ") ;
        frn     = Read_FRN(in, out) ;
        notnal  = Read_FL64(in, out, "Notional  ") ;
        df_cflw = Read_DISCFAC(in, out) ;
        df_disc = Read_DISCFAC(in, out) ;
        CMTvol  = Read_VOL_STR(in, out) ;
        holi    = Read_HOLI_STR(in, out) ;
        dfs     = Read_DFSPREAD(in, out) ;

        bucket_cflw = Read_BUCKETARRAY(in, out, &nbuckcflw) ;
        zerocflw    = Read_BOOLE(in, out, "DECF  ") ;  
        which_cflw  = Read_DFWHICH(in, out, "Which ") ;

        bucket_disc = Read_BUCKETARRAY(in, out, &nbuckdisc) ;
        zerodisc    = Read_BOOLE(in, out, "DECF  ") ;
        which_disc  = Read_DFWHICH(in, out, "Which ") ;

        fxr = Read_FXRISKSET(in, out) ;

        /* Initialise */
        ds_cflw = Disc_DeltaPrep(&df_cflw, bucket_cflw, nbuckcflw, &holi, 
                                  True, df_cflw.irr, df_cflw.freq, False, 
                                  zerocflw, which_cflw) ;
        ds_disc = Disc_DeltaPrep(&df_disc, bucket_disc, nbuckdisc, &holi, 
                                  True, df_disc.irr, df_disc.freq, False, 
                                  zerodisc, which_disc) ;

        cmadj   = Set_CMCONVADJ(CMADJ_ORIG, &CMTvol, NULL, 0.0) ;

        /* Calculate */
        rpos = FRN_DF2RiskPos(&today, &frn, notnal, &df_cflw, &df_disc, 
                              &cmadj, &holi, &dfs, &ds_cflw, &ds_disc,
                              &fxr) ;

        /* Read expected results */
        fscanf(in, "%d", &i1) ;
        exprpos.npos = (INTI) i1 ;
        exprpos.token = Alloc_RISKTOKENARRAY(exprpos.npos) ;
        exprpos.pos   = Alloc_FL64ARRAY(exprpos.npos) ;

        for (i = 0; i < exprpos.npos; i++)
        {
            Read_RISKTOKEN(in, out, &exprpos.token[i]) ;
            fscanf(in, "%lf", &exprpos.pos[i]) ;
        }

        /* Compare */
        diff = Write_riskposdiff(exprpos, rpos, out, tol) ;
    
        /* Comments */
        IOUtil_ParseLine(in, out) ;

        /* Free */
        Free_FRN(&frn);
        Free_DATEARRAY(holi.holidays) ;
        Free_DELTASET(&ds_cflw) ;
        Free_DELTASET(&ds_disc) ;
        Free_PLANARRAY(df_cflw.disc, 1) ;
        Free_PLANARRAY(df_disc.disc, 1) ;
        Free_BUCKETARRAY(bucket_cflw) ;
        Free_BUCKETARRAY(bucket_disc) ;
        Free_PLANARRAY(CMTvol.vol, 1) ;
        Free_RISKPOSLIST(&rpos);
        Free_RISKPOSLIST(&exprpos);
        Free_DFSPREAD(&dfs) ;
    }

    else if (!strcmp("IndexBond_DF2RiskPos()", txa))
    {
        fprintf(out,"   Testing %s\n", txa) ;

        /* Read data */
        tol     = Read_FL64(in, out, "Tolerance   ") ;
        analys  = Read_DATESTR(in, out, "Analys date  ") ;
        trade   = Read_TRADEINFO(in, out) ;
        idxbond = Read_INDEXBOND(in, out, &trade.settle) ;
        notnal  = Read_FL64(in, out, "Notional  ") ;
        fac     = Read_INDEXFAC(in, out) ;
        df      = Read_DISCFAC(in, out) ;
        dfs     = Read_DFSPREAD(in, out) ;
        holi    = Read_HOLI_STR(in, out) ;
        idxadj  = Read_BOOLE(in, out, "Index adjusted price  ") ;
        bucket  = Read_BUCKETARRAY(in, out, &nbuck) ;
        zero    = Read_BOOLE(in, out, "DECF  ") ;
        fxr     = Read_FXRISKSET(in, out) ;

        /* Initialise */
        ds = Disc_DeltaPrep(&df, bucket, nbuck, &holi, True, df.irr,
                             df.freq, False, zero, DF_BOTH) ;

        /* Calculate */
        rpos = IndexBond_DF2RiskPos(&analys, &trade, &idxbond, notnal, 
                                    &fac, &df, &dfs, &holi, idxadj,
                                    &ds, &fxr) ;

        /* Read expected results */
        fscanf(in, "%d", &i1) ;
        exprpos.npos  = (INTI) i1 ;
        exprpos.token = Alloc_RISKTOKENARRAY(exprpos.npos) ;
        exprpos.pos   = Alloc_FL64ARRAY(exprpos.npos) ;

        for (i = 0; i < exprpos.npos; i++)
        {
            Read_RISKTOKEN(in, out, &exprpos.token[i]) ;
            fscanf(in, "%lf", &exprpos.pos[i]) ;
        }

        /* Compare */
        diff = Write_riskposdiff(exprpos, rpos, out, tol) ;
    
        /* Comments */
        IOUtil_ParseLine(in, out) ;

        Free_FIXPAY(&idxbond.fixp) ;
        Free_PLANARRAY(fac.idxfac, 1) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_DATEARRAY(holi.holidays) ;
        Free_BUCKETARRAY(bucket) ;
        Free_DELTASET(&ds) ;
        Free_RISKPOSLIST(&rpos);
        Free_RISKPOSLIST(&exprpos);
        Free_DFSPREAD(&dfs) ;
    }

    else if (!strcmp("IndexLoan_DF2RiskPos()", txa))
    {
        fprintf(out,"   Testing %s\n", txa) ;

        /* Read data */
        tol     = Read_FL64(in, out, "Tolerance   ") ;
        analys  = Read_DATESTR(in, out, "Analys date  ") ;
        idxloan = Read_INDEXLOAN(in, out) ;
        notnal  = Read_FL64(in, out, "Notional  ") ;
        debfac  = Read_INDEXFAC(in, out) ;
        crefac  = Read_INDEXFAC(in, out) ;
        df      = Read_DISCFAC(in, out) ;
        dfs     = Read_DFSPREAD(in, out) ;
        holi    = Read_HOLI_STR(in, out) ;
        idxadj  = Read_BOOLE(in, out, "Index adjusted price  ") ;
        bucket  = Read_BUCKETARRAY(in, out, &nbuck) ;
        zero    = Read_BOOLE(in, out, "DECF  ") ;
        fxr     = Read_FXRISKSET(in, out) ;

        /* Initialise */
        ds = Disc_DeltaPrep(&df, bucket, nbuck, &holi, True, df.irr,
                             df.freq, False, zero, DF_BOTH) ;

        /* Calculate */
        rpos = IndexLoan_DF2RiskPos(&analys, &idxloan, notnal, &debfac, 
                                    &crefac, &df, &dfs, &holi, idxadj,
                                    &ds, &fxr) ;

        /* Read expected results */
        fscanf(in, "%d", &i1) ;
        exprpos.npos  = (INTI) i1 ;
        exprpos.token = Alloc_RISKTOKENARRAY(exprpos.npos) ;
        exprpos.pos   = Alloc_FL64ARRAY(exprpos.npos) ;

        for (i = 0; i < exprpos.npos; i++)
        {
            Read_RISKTOKEN(in, out, &exprpos.token[i]) ;
            fscanf(in, "%lf", &exprpos.pos[i]) ;
        }

        /* Compare */
        diff = Write_riskposdiff(exprpos, rpos, out, tol) ;
    
        /* Comments */
        IOUtil_ParseLine(in, out) ;

        Free_PLANARRAY(debfac.idxfac, 1) ;
        Free_PLANARRAY(crefac.idxfac, 1) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_DATEARRAY(holi.holidays) ;
        Free_BUCKETARRAY(bucket) ;
        Free_DELTASET(&ds) ;
        Free_RISKPOSLIST(&rpos);
        Free_RISKPOSLIST(&exprpos);
        Free_DFSPREAD(&dfs) ;
    }


    return diff ;
}




/*
..
*/



/* SCID @(#)tstfut.c	1.8 (SimCorp) 99/10/19 16:25:57 */

/************************************************************************
*
*   this program tests the routines in the futures module of SCecon.
*
************************************************************************/

/*** includes ***********************************************************/
#include <string.h>
#include <stdlib.h>

#include <future.h>
#include <futio.h>
#include <ioconv.h>
#include <bondio.h>

INTI futtest(char* txa, FILE* in, FILE* out)
{
    char        txb[25], txc[25], txd[25], txe[25], txpl[64];
    FL64        *f64, rate, forw = 0, spot, fprev, ai, f, cf, t, size, acc, 
                fexp, fres, fres1, fexp1, fres2, fexp2, coupon, 
                *cleanCTD, *dv, ytm, agreed_futp, futp, acc1 ;
    CALCONV     cal ;
    INTI        tmp, *index, *eindex, qb, i, dif1, diff, n, noas,
                dres3, dexp3, nbucket, ctd ;
    CTDCONV     sort ;
    IRRCONV     irr ;
    YYYYMMDD    ymd1, ymd, calc, start, effec ;
    DATESTR     analys, lexp4, lres4, dcalc, dstart, dend, dend1, 
                settle, deffec, deliv ;
    EOMCONV     eom ;
    BOOLE       zero, ok, margin, modf, calexdays;
    PMTFREQ     freq ;
    int         i1 ;
    FIXPAY      fxp ;
    DISCFAC     df ;
    HOLI_STR    holi ;
    YTMCONV     ytmc ;
    RISKSET     rs ;
    BUCKETARRAY bucket ;
    DFSPREAD    dfs ;
    CFCONV      cfc ;
    TRADEINFO   tr1 ;
    EXRULE      xc ;
    REPOBOND    repo ;
    FUTBOND     futb ;
    KEYCONV     what ;
    ITERCTRL    ictrl ;
    DFSPREADARRAY dfsarr ;
    DELTASET      ds ;
    RISKCONV    risk ;
    FUTBONDBM   futbm ;
    YTMSEG      yseg ;
    CTDRES      cres ;
    ODDCONV     stub_front ;

    acc = 0.00001 ;

    diff = -1 ;

    if (!strcmp(txa, "fut_conversion_ratio()"))
    {
        fscanf(in,"%lf %lf %lf %s", &fexp, &f, &cf, txpl);
        fres = fut_conversion_ratio(f, cf) ;
        diff = (fabs(fres - fexp) > acc);

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   futures price     %9.5lf\n", f) ;
        fprintf(out,"   conversion factor %9.5lf\n", cf) ;
        fprintf(out,
          "   result is %9.5lf ; expected is %9.5lf\n",
          fres, fexp) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }

    else if (!strcmp(txa, "fut_invoice_ctd()"))
    {
        fscanf(in,"%lf %lf %lf %lf %lf %s", &fexp, &f, &cf, &ai, &size,
                                                                  txpl);
        fres = fut_invoice_ctd(f, cf, ai, size) ;
        diff = (fabs(fres - fexp) > acc);

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   futures price     %9.5lf\n", f) ;
        fprintf(out,"   conversion factor %9.5lf\n", cf) ;
        fprintf(out,"   accrued interest  %9.5lf\n", ai) ;
        fprintf(out,"   contract size %9.2lf\n", size) ;
        fprintf(out,
          "   result is %9.5lf ; expected is %9.5lf\n",
          fres, fexp) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }

    else if (!strcmp(txa, "fut_market_value()"))
    {
        fscanf(in,"%lf %lf %lf %s", &fexp, &f, &fprev, txpl) ;
        fres = fut_market_value(f, fprev) ;
        diff = (fabs(fres - fexp) > acc);

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   current futures price  %9.5lf\n", f) ;
        fprintf(out,"   previous futures price %9.5lf\n", fprev) ;
        fprintf(out,
          "   result is %9.5lf ; expected is %9.5lf\n",
          fres, fexp) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }

    else if (!strcmp(txa, "fut_basis()"))
    {
        fscanf(in,"%lf %lf %lf %s", &fexp, &f, &spot, txpl) ;
        fres = fut_basis(f, spot) ;
        diff = (fabs(fres - fexp) > acc);

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   futures price  %9.5lf\n", f) ;
        fprintf(out,"   spot price     %9.5lf\n", spot) ;
        fprintf(out,
          "   result is %9.5lf ; expected is %9.5lf\n",
          fres, fexp) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }

    else if (!strcmp(txa, "fut_profit_ctd()"))
    {
        fscanf(in,"%lf %lf %lf %lf %s", &fexp, &f, &forw, &cf, txpl) ;
        fres = fut_profit_ctd(f, forw, cf) ;
        diff = (fabs(fres - fexp) > acc);

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   futures price                %9.5lf\n", f) ;
        fprintf(out,"   forward price of deliverable %9.5lf\n", forw) ;
        fprintf(out,"   conversion factor            %9.5lf\n", cf) ;
        fprintf(out,
          "   result is %9.5lf ; expected is %9.5lf\n",
          fres, fexp) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }

    else if (!strcmp(txa, "Fut_Price_performanceindex()"))
    {
        fscanf(in,"%lf %lf %lf %lf %s %d %s", &fexp, &f, &t, &rate, txb,
                                                               &i1, txpl) ;
        qb = (INTI) i1 ;
        irr = Str2IRRCONV(txb) ;
        fres = Fut_Price_performanceindex(f, t, rate, irr, qb) ;
        diff = (fabs(fres - fexp) > acc);

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   futures price   %9.5lf\n", f) ;
        fprintf(out,"   term tp expiry  %9.5lf\n", forw) ;
        fprintf(out,"   repo rate       %9.5lf\n", rate) ;
        fprintf(out,"   quoting basis   %9d\n", qb) ;
        fprintf(out,"   irr convention %s\n", txb) ;
        fprintf(out,
          "   result is %9.5lf ; expected is %9.5lf\n",
          fres, fexp) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }

    else if (!strcmp(txa, "Fut_select_ctd()"))
    {
        fscanf(in,"%d %s %s", &i1, txb, txpl) ;
        n = (INTI) i1 ;
        sort = Str2CTDCONV(txb) ;
        f64    = Alloc_FL64ARRAY(n) ;
        eindex = Alloc_INTIARRAY(n) ;
        for (i = 0 ; i < n ; i++)
        {
            fscanf(in, "%lf %d", &f64[i], &i1) ;
            eindex[i] = (INTI) i1 ;
        }

        index = Fut_select_ctd(f64, n, sort, &tmp) ;
        diff = 0 ;

        fprintf(out,"?; testing %s\n", txa) ;
        fprintf(out,"   selecting criteria %s\n", txb) ;
        fprintf(out,"   list of deliverables...\n") ;
        for (i = 0 ; i < n ; i++)
            fprintf(out," delivarable[%2d] %9.5lf\n", i, f64[i]) ;

        fprintf(out," results...\n") ;
        for (i = 0 ; i < n ; i++)
        {
            dif1 = (index[i] != eindex[i]) ;
            diff = (dif1 ? 1 : diff) ;
            fprintf(out,"%d; index[%2d] = %2d ; expected %2d\n",
                    dif1, i, index[i], eindex[i]) ;
        }
        fprintf(out,"   %s\n\n", txpl) ;

        Free_FL64ARRAY(f64) ;
        Free_INTIARRAY(index) ;
        Free_INTIARRAY(eindex) ;
    }

    else if (!strcmp(txa, "Fut_select_wildcard()"))
    {
        fscanf(in,"%d %s %s", &i1, txb, txpl) ;
        n = (INTI) i1 ;
        sort = Str2CTDCONV(txb) ;
        f64    = Alloc_FL64ARRAY(n) ;
        eindex = Alloc_INTIARRAY(n) ;
        for (i = 0 ; i < n ; i++)
        {
            fscanf(in, "%lf %d", &f64[i], &i1) ;
            eindex[i] = (INTI) i1 ;
        }
        index = Fut_select_wildcard(f64, n, sort, &tmp) ;
        diff = 0 ;

        fprintf(out,"?; testing %s\n", txa) ;
        fprintf(out,"   selecting criteria %s\n", txb) ;
        fprintf(out,"   list of deliverables...\n") ;
        for (i = 0 ; i < n ; i++)
            fprintf(out," delivarable[%2d] %9.5lf\n", i, f64[i]) ;

        fprintf(out," results...\n") ;
        for (i = 0 ; i < n ; i++)
        {
            dif1 = (index[i] != eindex[i]) ;
            diff = (dif1 ? 1 : diff) ;
            fprintf(out,"%d; index[%d] = %d expected %d\n",
                    dif1, i, index[i], eindex[i]) ;
        }
        fprintf(out,"   %s\n\n", txpl) ;

        Free_FL64ARRAY(f64) ;
        Free_INTIARRAY(index) ;
        Free_INTIARRAY(eindex) ;
    }

    else if (!strcmp(txa, "FutBond_CC2Price()"))
    {
        fscanf(in,"%lf %d %ld %ld", &fexp, &i1, &ymd, &start) ;

        dexp3 = (INTI) i1 ;      /* exp CTD */

        dstart = Cldr_YMD2Datestr(start) ;     /* Settle */
        lexp4  = Cldr_YMD2Datestr(ymd) ;       /* Exp. day */

        fprintf(out,"?; testing %s\n", txa) ;
        fprintf(out,"   Settle             %8ld\n", start) ;

        futb = Read_FUTBOND(in, out, &dstart) ;
        dfsarr = Read_DFSPREADARRAY(in, out, &noas) ;

        fprintf(out,"   CTD Clean prices:\n") ;
        cleanCTD = Read_FL64ARRAY(in, &n) ;
        Write_FL64ARRAY(out, cleanCTD, n) ;

        df   = Read_DISCFAC(in, out) ;
        holi = Read_HOLI_STR(in, out) ;

        IOUtil_ParseLine(in, out) ;

        tr1.settle = dstart ;
        tr1.brd    = False ;
        tr1.nom    = 100.0 ;
        tr1.xctrade.spec = False ;
        tr1.xptrade.spec = False ;

        fres = FutBond_CC2Price(&tr1, &futb, n, cleanCTD, noas, dfsarr,
                                &df, &holi, &dres3, &lres4) ;

        diff = fabs(fres - fexp) > 0.00001 || dexp3 != dres3 ||
               Cldr_DateEQ(&lres4, &lexp4) == False ;

        fprintf(out,"%d; Forw: Expected %lf Result %lf\n",
                fabs(fres - fexp) > 0.00001, fexp, fres) ;
        fprintf(out,"%d; CTD:  Expected %d Result %d\n",
                dexp3 != dres3, dexp3, dres3) ;
        fprintf(out,"%d; Date: Expected %ld Result %ld\n\n",
               Cldr_DateEQ(&lres4, &lexp4) == False,
               Cldr_Datestr2YMD(&lexp4), Cldr_Datestr2YMD(&lres4)) ;

        Free_DATEARRAY(holi.holidays) ;
        Free_FL64ARRAY(cleanCTD) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_FUTBOND(&futb) ;
        Free_DFSPREADARRAY(dfsarr) ;
    }

    else if (!strcmp(txa, "FutBond_DF2Price()"))
    {
        fscanf(in,"%lf %lf %lf %d %ld %ld",
               &fexp, &fexp1, &fexp2, &i1, &ymd, &start) ;

        dexp3 = (INTI) i1 ;      /* exp CTD */

        dstart = Cldr_YMD2Datestr(start) ;     /* Settle */
        lexp4  = Cldr_YMD2Datestr(ymd) ;       /* Exp. day */

        fprintf(out,"?; testing %s\n", txa) ;
        fprintf(out,"   Settle             %8ld\n", start) ;

        futb = Read_FUTBOND(in, out, &dstart) ;
        dfsarr = Read_DFSPREADARRAY(in, out, &n) ;

        df   = Read_DISCFAC(in, out) ;
        holi = Read_HOLI_STR(in, out) ;
        rs   = Read_RISKSET(in, out) ;

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n", txpl) ;

        fres = FutBond_DF2Price(&dstart, &futb, n, dfsarr, &df, &holi,
                                &rs, &fres1, &fres2, &dres3, &lres4) ;

        diff = fabs(fres - fexp) > 0.00001 ||
               fabs(fres1 - fexp1) > 0.00001 ||
               fabs(fres2 - fexp2) > 0.00001 ||
               dexp3 != dres3 ||
               Cldr_DateEQ(&lres4, &lexp4) == False ;

        fprintf(out,"%d; Forw: Expected %lf Result %lf\n",
                fabs(fres - fexp) > 0.00001, fexp, fres) ;
        fprintf(out,"%d; DP:   Expected %lf Result %lf\n",
                fabs(fres1 - fexp1) > 0.00001, fexp1, fres1) ;
        fprintf(out,"%d; DDP:  Expected %lf Result %lf\n",
                fabs(fres2 - fexp2) > 0.00001, fexp2, fres2) ;
        fprintf(out,"%d; CTD:  Expected %d Result %d\n",
                dexp3 != dres3, dexp3, dres3) ;
        fprintf(out,"%d; Date: Expected %ld Result %ld\n\n",
               Cldr_DateEQ(&lres4, &lexp4) == False,
               Cldr_Datestr2YMD(&lexp4), Cldr_Datestr2YMD(&lres4)) ;

        Free_FUTBOND(&futb) ;
        Free_DATEARRAY(holi.holidays) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_DFSPREADARRAY(dfsarr) ;
        Free_RISKSET(&rs);
    }

    else if (!strcmp(txa, "FutBond_YTM2Price()"))
    {
        fscanf(in,"%lf %lf %lf %d %ld", &fexp, &fexp1, &fexp2, &i1, &ymd) ;
        dexp3 = (INTI) i1 ;
        lexp4 = Cldr_YMD2Datestr((YYYYMMDD) ymd) ;

        fscanf(in, "%ld %lf", &ymd, &ytm) ;
        dstart = Cldr_YMD2Datestr(ymd) ;     /* Settle */

        fprintf(out,"?; testing %s\n", txa) ;
        fprintf(out,"   Analys             %8ld\n", ymd) ;
        fprintf(out,"   YTM                %8lf\n", ytm) ;

        futb = Read_FUTBOND(in, out, &dstart) ;
        ytmc = Read_YTMCONV(in, out) ;
        holi = Read_HOLI_STR(in, out) ;
        rs   = Read_RISKSET(in, out) ;
        fscanf(in, "%s", txpl) ;

        fres = FutBond_YTM2Price(&dstart, ytm, &futb, &ytmc, &holi,
                                 rs.risk, &fres1, &fres2, &dres3, &lres4) ;

        diff = fabs(fres - fexp) > 0.00001 ||
               fabs(fres1 - fexp1) > 0.00001 ||
               fabs(fres2 - fexp2) > 0.00001 ||
               dexp3 != dres3 ||
               Cldr_DateEQ(&lres4, &lexp4) == False ;

        fprintf(out,"%d; Forw: Expected %lf Result %lf\n",
                fabs(fres - fexp) > 0.00001, fexp, fres) ;
        fprintf(out,"%d; DP:   Expected %lf Result %lf\n",
                fabs(fres1 - fexp1) > 0.00001, fexp1, fres1) ;
        fprintf(out,"%d; DDP:  Expected %lf Result %lf\n",
                fabs(fres2 - fexp2) > 0.00001, fexp2, fres2) ;
        fprintf(out,"%d; CTD:  Expected %d Result %d\n",
                dexp3 != dres3, dexp3, dres3) ;
        fprintf(out,"%d; Date: Expected %ld Result %ld\n\n",
               Cldr_DateEQ(&lres4, &lexp4) == False,
               Cldr_Datestr2YMD(&lexp4), Cldr_Datestr2YMD(&lres4)) ;
        fprintf(out, "%s\n\n", txpl) ;

        Free_DATEARRAY(holi.holidays) ;
        Free_FUTBOND(&futb) ;
        Free_RISKSET(&rs);
    }

    else if (!strcmp(txa, "FutBond_YTM2Yield()"))
    {
        fscanf(in,"%lf", &fexp) ;

        fscanf(in, "%ld %lf %lf", &ymd, &forw, &cf) ;
        dstart = Cldr_YMD2Datestr(ymd) ;

        fprintf(out,"?; testing %s\n", txa) ;
        fprintf(out,"   Analysis           %8ld\n", ymd) ;
        fprintf(out,"   Futures Price      %8lf\n", forw) ;
        fprintf(out,"   ConFac             %8lf\n", cf) ;

        fxp  = Read_FIXPAY(in, out, &dstart) ;
        ytmc = Read_YTMCONV(in, out) ;
        holi = Read_HOLI_STR(in, out) ;
        fscanf(in, "%s", txpl) ;

        Init_ITERCTRL(&ictrl) ;

        ok = FutBond_YTM2Yield(&dstart, forw, cf, &fxp, &ytmc,
                                  &holi, &ictrl, &fres) ;

        diff = fabs(fres - fexp) > 0.00001 || ok == False ;

        fprintf(out,"%d; YTM: Expected %lf Result %lf\n",
                diff, fexp, fres) ;
        fprintf(out, "%s\n\n", txpl) ;

        Free_DATEARRAY(holi.holidays) ;
        Free_FIXPAY(&fxp);
    }

    else if (!strcmp(txa, "FutBond_CC2Impl()"))
    {
        fprintf(out,"?; testing %s\n", txa) ;

        /* Read data */
        fexp = Read_FL64(in, out, "   Expected   ") ;
        tr1 = Read_TRADEINFO(in, out) ;
        forw = Read_FL64(in, out, "   Futures price   ") ;
        futb = Read_FUTBOND(in, out, &tr1.settle) ;
        df = Read_DISCFAC(in, out) ;
        ytmc = Read_YTMCONV(in, out) ;
        holi = Read_HOLI_STR(in, out) ;
        dfs  = Read_DFSPREAD(in, out) ;
        what = Read_KEYCONV(in, out, "   KeyConv   ") ;
        Init_ITERCTRL(&ictrl) ;

        /* Calculate */
        ok = FutBond_CC2Impl(&tr1, futb.ddays, forw, futb.cf[0], futb.fixp, 
                             &holi, &dfs, &df, &ytmc, &ictrl, what, &fres) ;

        /* Compare */
        diff = Write_SingleDiff(ok, True, fres, fexp, 0.0001, out) ;

        /* Comments */
        IOUtil_ParseLine(in, out) ;

        Free_HOLI_STR(&holi) ;
        Free_DISCFAC(&df) ;
        Free_FUTBOND(&futb);
        Free_DFSPREAD(&dfs) ;
    }

    else if (!strcmp(txa, "FutBond_DF2Delta()"))
    {
        fscanf(in,"%ld", &start) ;

        dstart = Cldr_YMD2Datestr(start) ;     /* Settle */

        fprintf(out,"?; testing %s\n", txa) ;
        fprintf(out,"   Settle             %8ld\n", start) ;

        futb = Read_FUTBOND(in, out, &dstart) ;
        dfsarr = Read_DFSPREADARRAY(in, out, &n) ;

        df     = Read_DISCFAC(in, out) ;
        holi   = Read_HOLI_STR(in, out) ;
        bucket = Read_BUCKETARRAY(in, out, &nbucket) ;

        dfs.irr  = df.irr ;
        dfs.freq = df.freq ;

        ds = Disc_DeltaPrep(&df, bucket, nbucket, &holi, False, df.irr,
                             df.freq, False, False, DF_BOTH) ;
        dv = FutBond_DF2Delta(&dstart, &futb, n, dfsarr, &df, &holi, &ds,
          &ctd, &deliv) ;
        diff = 0 ;
        for (i = 0; i < nbucket; i++)
        {
            fscanf(in, "%lf", &fexp) ;
            diff = diff || fabs(fexp - dv[i]) > 0.00001 ;
            fprintf(out, "%d; %d exp %lf res %lf\n",
                    fabs(fexp - dv[i]) > 0.00001, i, fexp, dv[i]) ;
        }

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_FUTBOND(&futb) ;
        Free_DFSPREADARRAY(dfsarr) ;
        Free_DATEARRAY(holi.holidays) ;
        Free_FL64ARRAY(dv) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_DELTASET(&ds) ;
        Free_BUCKETARRAY(bucket) ;
    }


    else if (!strcmp(txa, "FutBond_ConFac()"))
    {
        fscanf(in,"%lf %lf %s %d", &fexp, &coupon, txb, &i1);
        fprintf(out,"?; testing %s\n", txa) ;
        fprintf(out,"   Coupon             %8lf\n", coupon) ;
        fprintf(out,"   Frequency          %8s\n", txb) ;
        fprintf(out,"   Exdays             %8d\n", i1) ;

        calexdays = Read_BOOLE(in, out, " Cal. ex. days   ");
        
        fscanf(in, "%s %s", txc, txd) ;
        fprintf(out,"   Calendar           %8s\n", txc) ;
        fprintf(out,"   EOM                %8s\n", txd) ;

        stub_front = Read_ODDCONV(in, out, "Odd conv.") ;

        fscanf(in, "%ld %ld %ld %ld %s %lf %s" , &ymd, &ymd1,
          &effec, &calc, txe, &rate, txpl) ;

        fprintf(out,"   First Matur        %8ld\n", ymd) ;
        fprintf(out,"   Last Matur         %8ld\n", ymd1) ;
        fprintf(out,"   Effective          %8ld\n", effec) ;
        fprintf(out,"   Delivery           %8ld\n", calc) ;
        fprintf(out,"   CF:                %8s\n", txe) ;
        fprintf(out,"   Yield              %8lf\n", rate) ;

        freq = Str2PMTFREQ(txb) ;
        cal  = Str2CALCONV(txc) ;
        eom  = Str2EOMCONV(txd) ;
        cfc  = Str2CFCONV(txe) ;

        xc = Set_EXRULE(EX_DAYS, (INTI) i1, calexdays, cal, &dend, 0, NULL,
                             NULL, False) ;

        dend  = Cldr_YMD2Datestr(ymd) ;
        dend1 = Cldr_YMD2Datestr(ymd1) ;
        deffec = Cldr_YMD2Datestr(effec) ;
        dcalc = Cldr_YMD2Datestr(calc) ;

        holi.nholi = 0 ;

        fres = FutBond_ConFac(coupon, freq, &xc, cal, eom, stub_front, 
          &dend, &dend1, &deffec ,&dcalc, cfc, rate, &holi) ;

        diff = fabs(fexp - fres) > acc ;

        fprintf(out,"   Result...\n") ;
        fprintf(out,"%d; Exp. CF %10.7lf Calc.CF %10.7lf\n",
                diff, fexp, fres) ;

        fprintf(out,"   %s\n\n", txpl) ;
    }

    else if (!strcmp(txa, "FutBondBM_CCREPO2Impl()"))
    {
        fprintf(out,"?; testing %s\n", txa) ;

        fscanf(in, "%lf %ld %lf", &acc1, &start, &forw) ;
        dstart = Cldr_YMD2Datestr(start) ;     
        fprintf(out,"   Settle             %8ld\n", start) ;
        fprintf(out,"   Forward Prices     %8lf\n", forw) ;

        futbm = Read_FUTBONDBM(in, out) ;
        
        fprintf(out,"   CTD Clean prices:\n") ;
        cleanCTD = Read_FL64ARRAY(in, &n) ;
        Write_FL64ARRAY(out, cleanCTD, n) ;

        fscanf(in, "%s", txb) ;
        yseg = Str2YTMSEG(txb) ;
        holi = Read_HOLI_STR(in, out) ;

        cres = FutBondBM_CCREPO2Impl(&dstart, forw, &futbm, 
                                     cleanCTD, n, yseg, &holi) ;
        diff = Write_CTDRESdiff(in, out, &cres, acc1) ;

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_FL64ARRAY(cleanCTD) ;
        Free_FUTBONDBM(&futbm) ;
        Free_CTDRES(&cres) ;
        Free_DATEARRAY(holi.holidays) ;
    }

    else if (!strcmp(txa, "FutBondBM_CCREPO2Price()"))
    {
        fprintf(out,"?; testing %s\n", txa) ;

        fscanf(in, "%lf %ld", &acc1, &start) ;
        dstart = Cldr_YMD2Datestr(start) ;     
        fprintf(out,"   Settle             %8ld\n", start) ;

        futbm = Read_FUTBONDBM(in, out) ;
        
        fprintf(out,"   CTD Clean prices:\n") ;
        cleanCTD = Read_FL64ARRAY(in, &n) ;
        Write_FL64ARRAY(out, cleanCTD, n) ;

        fscanf(in, "%lf", &rate) ;
        fprintf(out,"   Repo rate          %8lf\n", rate) ;

        fscanf(in, "%s", txb) ;
        yseg = Str2YTMSEG(txb) ;
        holi = Read_HOLI_STR(in, out) ;

        cres = FutBondBM_CCREPO2Price(&dstart, &futbm, cleanCTD, n, 
                                      rate, yseg, &holi) ;
        diff = Write_CTDRESdiff(in, out, &cres, acc1) ;

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_FL64ARRAY(cleanCTD) ;
        Free_FUTBONDBM(&futbm) ;
        Free_CTDRES(&cres) ;
        Free_DATEARRAY(holi.holidays) ;
    }


    else if (!strcmp(txa, "RepoBond_BuyBack()"))
    {
        fprintf(out,"?; testing %s\n", txa) ;
        fscanf(in, "%lf %ld", &fexp, &ymd) ;

        analys = Cldr_YMD2Datestr(ymd) ;
        fprintf(out, "  Analys     %8ld\n", ymd) ;

        repo = Read_REPOBOND(in, out) ;
        holi = Read_HOLI_STR(in, out) ;

        fres = RepoBond_BuyBack(&repo, &holi) ;
        diff = fabs(fexp - fres) > acc ;

        fprintf(out,"   Result...\n") ;
        fprintf(out,"%d; Exp. %10.7lf Calc. %10.7lf\n",
                diff, fexp, fres) ;

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_REPOBOND(&repo);
        Free_DATEARRAY(holi.holidays) ;
    }

    else if (!strcmp(txa, "RepoBond_CC2NPV()"))
    {
        fprintf(out,"?; testing %s\n", txa) ;
        fscanf(in, "%lf %ld %lf", &fexp, &ymd, &spot) ;

        analys = Cldr_YMD2Datestr(ymd) ;
        fprintf(out, "  Analys     %8ld\n", ymd) ;
        fprintf(out, "  Spot       %8lf\n", spot) ;

        repo = Read_REPOBOND(in, out) ;
        holi = Read_HOLI_STR(in, out) ;
        df   = Read_DISCFAC(in, out) ;
        dfs  = Read_DFSPREAD(in, out) ;

        fres = RepoBond_CC2NPV(&analys, spot, &repo, &holi, &df, &dfs) ;
        diff = fabs(fexp - fres) > acc ;

        fprintf(out,"   Result...\n") ;
        fprintf(out,"%d; Exp. %10.7lf Calc. %10.7lf\n", diff, fexp, fres) ;

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_REPOBOND(&repo);
        Free_DATEARRAY(holi.holidays) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_DFSPREAD(&dfs) ;
    }

    else if (!strcmp(txa, "RepoBond_DF2NPV()"))
    {
        fprintf(out,"?; testing %s\n", txa) ;
        fscanf(in, "%lf %lf %lf %ld", &fexp, &fexp1, &fexp2, &ymd) ;

        analys = Cldr_YMD2Datestr(ymd) ;
        fprintf(out, "  Analys     %8ld\n", ymd) ;

        repo = Read_REPOBOND(in, out) ;
        holi = Read_HOLI_STR(in, out) ;
        df   = Read_DISCFAC(in, out) ;
        rs   = Read_RISKSET(in, out) ;
        dfs  = Read_DFSPREAD(in, out) ;

        fres = RepoBond_DF2NPV(&analys, &repo, &holi,
                               &df, &dfs, &rs, &fres1, &fres2) ;

        diff = fabs(fexp - fres) > acc ||
               fabs(fexp1 - fres1) > acc ||
               fabs(fexp2 - fres2) > acc ;

        fprintf(out,"   Result...\n") ;
        fprintf(out,"%d; Exp. %10.7lf Calc. %10.7lf\n",
                fabs(fexp - fres) > acc, fexp, fres) ;
        fprintf(out,"%d; Exp. %10.7lf Calc. %10.7lf\n",
                fabs(fexp1 - fres1) > acc, fexp1, fres1) ;
        fprintf(out,"%d; Exp. %10.7lf Calc. %10.7lf\n",
                fabs(fexp2 - fres2) > acc, fexp2, fres2) ;

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_DATEARRAY(holi.holidays) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_REPOBOND(&repo);
        Free_RISKSET(&rs);
        Free_DFSPREAD(&dfs) ;
    }

    else if (!strcmp(txa, "RepoBond_DF2Delta()"))
    {
        fprintf(out,"?; testing %s\n", txa) ;
        fscanf(in, "%ld", &ymd) ;

        analys = Cldr_YMD2Datestr(ymd) ;
        fprintf(out, "  Analys     %8ld\n", ymd) ;

        repo = Read_REPOBOND(in, out) ;
        df   = Read_DISCFAC(in, out) ;
        dfs  = Read_DFSPREAD(in, out) ;
        holi = Read_HOLI_STR(in, out) ;
        bucket = Read_BUCKETARRAY(in, out, &nbucket) ;

        fscanf(in, "%s", txb) ;
        zero = Str2BOOLE(txb) ;
        fprintf(out,"   DECF        %8s\n", txb) ;

        ds = Disc_DeltaPrep(&df, bucket, nbucket, &holi, True, df.irr,
                             df.freq, False, zero, DF_BOTH) ;

        dv = RepoBond_DF2Delta(&analys, &repo, &df, &dfs, &holi, &ds) ;

        diff = 0 ;
        for (i = 0; i < nbucket; i++)
        {
            fscanf(in, "%lf", &fexp) ;
            diff = diff || fabs(fexp - dv[i]) > 0.00001 ;
            fprintf(out, "%d; %d exp %lf res %lf\n",
                    fabs(fexp - dv[i]) > 0.00001, i, fexp, dv[i]) ;
        }

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_REPOBOND(&repo);
        Free_DATEARRAY(holi.holidays) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_BUCKETARRAY(bucket) ;
        Free_FL64ARRAY(dv) ;
        Free_DELTASET(&ds) ;
        Free_DFSPREAD(&dfs) ;
    }

    else if (!strcmp(txa, "RepoBond_DF2Impl()"))
    {
        fprintf(out,"?; testing %s\n", txa) ;
        fscanf(in, "%lf", &fexp) ;

        repo = Read_REPOBOND(in, out) ;
        fscanf(in, "%lf", &futp) ;
        fprintf(out, "  Buy-back price   %8lf\n", futp) ;
        holi = Read_HOLI_STR(in, out) ;
        dfs  = Read_DFSPREAD(in, out) ;
        df   = Read_DISCFAC(in, out) ;
        ytmc = Read_YTMCONV(in, out) ;
        fscanf(in, "%s", txc) ;
        fprintf(out,"   KeyConv          %s\n", txc) ;
        what = Str2KEYCONV(txc) ;
        Init_ITERCTRL(&ictrl) ;
        
        ok = RepoBond_DF2Impl(&repo, futp, &holi, &dfs, &df,
                              &ytmc, &ictrl, what, &fres) ;

        diff = fabs(fexp - fres) > acc ;

        fprintf(out,"   Result...\n") ;
        fprintf(out,"%d; Exp. %10.7lf Calc. %10.7lf\n",
                fabs(fexp - fres) > acc, fexp, fres) ;

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_DATEARRAY(holi.holidays) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_REPOBOND(&repo);
        Free_DFSPREAD(&dfs) ;
    }

    else if (!strcmp(txa, "RepoBond_YTM2Price()"))
    {
        fprintf(out,"?; testing %s\n", txa) ;
        fscanf(in, "%lf %lf %lf %lf", &fexp, &fexp1, &fexp2, &ytm) ;

        fprintf(out, "  YTM            %8lf\n", ytm) ;

        repo = Read_REPOBOND(in, out) ;
        ytmc = Read_YTMCONV(in, out) ;
        holi = Read_HOLI_STR(in, out) ;
        fscanf(in, "%s %s", txb, txc) ;
        fprintf(out,"   RISKCONV          %s\n", txb) ;
        fprintf(out,"   modf              %s\n", txc) ;
        risk = Str2RISKCONV(txb) ;
        modf = Str2BOOLE(txc) ;

        fres = RepoBond_YTM2Price(ytm, &repo, &ytmc, &holi, risk, 
                                  modf, &fres1, &fres2) ;

        diff = fabs(fexp - fres) > acc ||
               fabs(fexp1 - fres1) > acc ||
               fabs(fexp2 - fres2) > acc ;

        fprintf(out,"   Result...\n") ;
        fprintf(out,"%d; Exp. %10.7lf Calc. %10.7lf\n",
                fabs(fexp - fres) > acc, fexp, fres) ;
        fprintf(out,"%d; Exp. %10.7lf Calc. %10.7lf\n",
                fabs(fexp1 - fres1) > acc, fexp1, fres1) ;
        fprintf(out,"%d; Exp. %10.7lf Calc. %10.7lf\n",
                fabs(fexp2 - fres2) > acc, fexp2, fres2) ;

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_DATEARRAY(holi.holidays) ;
        Free_REPOBOND(&repo);
    }

    else if (!strcmp(txa, "FutBond_PL2NPV()"))
    {
        fprintf(out,"?; testing %s\n", txa) ;
        fscanf(in, 
          "%lf %ld %ld %lf %lf %s",
          &fexp, &ymd, &ymd1, &futp, &agreed_futp, txb) ;

        settle = Cldr_YMD2Datestr(ymd) ;
        deliv = Cldr_YMD2Datestr(ymd1) ;
        fprintf(out,"   Analys                 %8ld\n", ymd) ;
        fprintf(out,"   Delivery               %8ld\n", ymd1) ;
        fprintf(out,"   Futures price          %8lf\n", futp) ;
        fprintf(out,"   Agreed Futures price   %8lf\n", agreed_futp) ;
        margin = Str2BOOLE(txb) ;

        df   = Read_DISCFAC(in, out) ;

		fres = FutBond_PL2NPV(&settle, &deliv, futp, agreed_futp, margin, &df, &holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */

        diff = fabs(fexp - fres) > acc ;

        fprintf(out,"   Result...\n") ;
        fprintf(out,"%d; Exp. %10.7lf Calc. %10.7lf\n",
                fabs(fexp - fres) > acc, fexp, fres) ;

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_PLANARRAY(df.disc, 1) ;
    }

    return diff ;
}


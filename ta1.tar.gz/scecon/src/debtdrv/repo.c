/* SCID @(#)repo.c	1.5 (SimCorp) 99/09/08 17:38:11 */

/************************************************************************
*
*   project     SCecon
*
*   file name   repo.c
*
*   general     This file contains routines for Repo contracts
*
************************************************************************/

/*** includes **********************************************************/
#include <future.h>


/*,,SOH,,
*************************************************************************
*
*               RepoBond_BuyBack()
*
*   interface   #include <future.h>
*               FL64 RepoBond_BuyBack(REPOBOND    *repo,
*                                     HOLI_STR    *holi) ;
*
*   general     This function calculates the buy-back price of a repo
*               i.e. the buyback price agreed upon in the repo terms.
*
*   input       REPOBOND    *repo   The repo definition
*
*               HOLI_STR    *holi    Holiday adjustment rules
*
*   output
*
*   returns     The buy-back price of the repo contract
*
*   diagnostics
*
*   see also
*
*************************************************************************
,,EOH,,*/

FL64 RepoBond_BuyBack(REPOBOND* repo,
                      HOLI_STR*    holi)
{
    TRADEINFO   ti ;
    FL64        dsc, t, cf, bbp ;
    INTI        ctd ;
    DATESTR     delv, sell, buy ;
    DISCFAC     df ;
    FUTBOND     futb ;

    /* Adjust for business days */
    sell = Cldr_NextBusinessDate(&repo->sell_date, holi) ;
    buy  = Cldr_NextBusinessDate(&repo->buy_date, holi) ;
    
    /* Initialise */
    ti  = bond_set_tradeinfo(&sell) ;
    cf  = 1.0 ;

    /* Set DF */
	t = Cldr_TermBetweenDates(&sell, &buy, 0, repo->cal, LAST, holi);   	/* PMSTA-22396 - SRIDHARA � 160502 */
    df.disc = Alloc_PLANARRAY(1, 2) ;
    Cldr_InsertInPlan(&sell, 1.0, df.disc, True) ;
    dsc = TVMunit_NPV(t, repo->rate, repo->irr, 0) ;
    Cldr_InsertInPlan(&buy, dsc, df.disc, True) ;
    df = Set_DISCFAC(df.disc, DI_SPOT, LINEAR_FLAT_END, repo->cal,
                     repo->irr, ANNUALLY) ;

    /* Do calculation */
    futb = Set_FUTBOND(1, &buy, 1, &repo->bond, &cf, 0.0, False, False) ;
    bbp  = FutBond_CC2Price(&ti, &futb, 1, &repo->sell_price, 0,
                            NULL, &df, holi, &ctd, &delv) ;

    /* Free */
    Free_PLANARRAY(df.disc, 1) ;

    /* Return */
    return bbp ;
}


/*,,SOH,,
*************************************************************************
*
*               RepoBond_CC2NPV()
*
*   interface   #include <future.h>
*               FL64 RepoBond_CC2NPV(DATESTR     *analys,
*                                    FL64        spot,
*                                    REPOBOND    *repo,
*                                    HOLI_STR    *holi,
*                                    DISCFAC     *df,
*                                    DFSPREAD    *dfs) ;
*
*   general     This function calculates the NPV of a bond repo based
*               on the current spot price of the underlying bond.
*
*               The function is quite general in taking account of a
*               number of bond curiosities.
*
*               Here the NPV is calculated from the spot price.
*               In RepoBond_DF2NPV() the term structure of interest
*               rates is used (rather than the spot price).
*
*   input       DATESTR     *analys The contract settle data
*
*               FL64        spot    Spot price of underlying bond
*
*               REPOBOND    *repo   Repo term sheet data
*
*               HOLI_STR    *holi   Holiday setup.
*
*               DISCFAC     *df     Discount factors.
*
*               DFSPREAD    *dfs    Spread to df of underlying bond
*
*   output
*
*   returns     The NPV of the repo contract
*
*   diagnostics
*
*   see also    RepoBond_DF2NPV()
*
*************************************************************************
,,EOH,,*/

FL64 RepoBond_CC2NPV(DATESTR*  analys,
                     FL64        spot,
                     REPOBOND*    repo,
                     HOLI_STR*    holi,
                     DISCFAC*     df,
                     DFSPREAD*    dfs)
{
    FL64      npv, tmp, cf, bbp, fwd_p1, fwd_p2 ;
    DATESTR   delv, sell, buy ;
    INTI      ctd ;
    TRADEINFO ti ;
    FUTBOND   futb ;

    /* Adjust for business days */
    sell = Cldr_NextBusinessDate(&repo->sell_date, holi) ;
    buy  = Cldr_NextBusinessDate(&repo->buy_date, holi) ;

    /* Initialise */
    ti  = bond_set_tradeinfo(analys) ;
    npv = 0.0 ;
    cf  = 1.0 ;

    /* A forward repo? */
    if (Cldr_DateLT(analys, &sell) == True)
    {
        futb   = Set_FUTBOND(1, &sell, 1, &repo->bond, &cf, 0.0, False, False);
        fwd_p1 = FutBond_CC2Price(&ti, &futb, 1, &spot, 1, dfs, df, 
                                  holi, &ctd, &delv) ;

        npv  = repo->sell_price - fwd_p1 ;
		npv *= Disc_Interpolation(&sell, df, holi);   	/* PMSTA-22396 - SRIDHARA � 160502 */
    }

    futb   = Set_FUTBOND(1, &buy, 1, &repo->bond, &cf, 0.0, False, False) ;
    bbp    = RepoBond_BuyBack(repo, holi) ;
    fwd_p2 = FutBond_CC2Price(&ti, &futb, 1, &spot, 1, dfs, df, holi, 
                              &ctd, &delv);
    tmp    = fwd_p2 - bbp ;
    tmp   *= Disc_Interpolation(&buy, df, holi) ;   	/* PMSTA-22396 - SRIDHARA � 160502 */

    npv += tmp ;
    Disc_forwval(df, analys, &npv, holi) ;   	/* PMSTA-22396 - SRIDHARA � 160502 */

    if (repo->reverse == True)
        npv *= -1.0 ;

    return npv ;
}


/*,,SOH,,
*************************************************************************
*
*               RepoBond_DF2NPV()
*
*   interface   #include <future.h>
*               FL64 RepoBond_DF2NPV(DATESTR     *analys,
*                                    REPOBOND    *repo,
*                                    HOLI_STR    *holi,
*                                    DISCFAC     *df,
*                                    DFSPREAD    *dfs,
*                                    RISKSET     *risk,
*                                    FL64        *dp,
*                                    FL64        *ddp) ;
*
*   general     This function calculates the NPV of a bond repo.
*
*               The function is quite general in taking account of a
*               number of bond curiosities.
*
*               The function does not use the spot price bond only the
*               current term structure of interest rates. For a spot
*               price based routine see RepoBond_CC2NPV().
*
*               Risk ratios are calculated as follows:
*
*                   risk->key      dp          ddp
*                   ---------      ---         ----
*                   KEY_DF         $Duration   $Convexity
*                   KEY_BPV        BPV
*
*   input       DATESTR     *analys Analysis date.
*
*               REPOBOND    *repo   The repo term sheet data
*
*               HOLI_STR    *holi   Holiday setup.
*
*               DISCFAC     *df     Discount factors.
*
*               DFSPREAD    *dfs    Spread to df of underlying bond
*
*               RISKSET     *risk   Risk set up
*                                   Use NULL for no risk ratios
*
*   output      FL64        *dp     Dollar duration
*
*               FL64        *ddp    Dollar convexity
*
*   returns     The NPV of the repo contract
*
*   diagnostics
*
*   see also    RepoBond_CC2NPV()
*
*************************************************************************
,,EOH,,*/

FL64 RepoBond_DF2NPV(DATESTR*  analys,
                     REPOBOND*    repo,
                     HOLI_STR*    holi,
                     DISCFAC*     df,
                     DFSPREAD*    dfs,
                     RISKSET*     risk,
                     FL64*        dp,
                     FL64*        ddp)
{
    FL64        npv ;
    CFLWARRAY   xcflw ;
    DATESTR     sell, buy ;

    /* Adjust for business days */
    sell = Cldr_NextBusinessDate(&repo->sell_date, holi) ;
    buy  = Cldr_NextBusinessDate(&repo->buy_date, holi) ;

    /* Extract the specific period flow */
    xcflw = RepoBond_GenrCflw(repo, holi) ;

    /* Calculate NPV */
    npv = RepoCflw_DF2Price(analys, df, xcflw, &buy, &repo->bond.repay.pp,
                            holi, dfs, risk, dp, ddp) ;

    /* Free CFLW */
    Free_CFLWARRAY(xcflw, 1) ;

    return npv ;
}



/*,,SOH,,
*************************************************************************
*
*               RepoBond_DF2Impl()
*
*   interface   #include <future.h>
*               BOOLE RepoBond_DF2Impl(REPOBOND    *repo,
*                                      FL64        bbp,
*                                      HOLI_STR    *holi,
*                                      DFSPREAD    *dfs,
*                                      DISCFAC     *df,
*                                      YTMCONV     *ytmc,
*                                      ITERCTRL    *ictrl,
*                                      KEYCONV     what,
*                                      FL64        *impl) ;
*
*   general     This function calculates the implied repo rate or spot
*               price implicit in the repo bond price.
*
*               The following ratios are calculated:
*
*                    what       Implied
*                    ------------------
*                    KEY_SPOT   Implied spot price
*                    KEY_REPO   Implied repo
*
*   input       REPOBOND    *repo        The repo contract specification*
*
*               FL64        bbp          The buyback price
*
*               HOLI_STR    *holi        Holiday setup.
*
*               DFSPREAD    *dfs         The spread against df.
*                                        Only used if what = KEY_SPOT
*
*               DISCFAC     *df          The Repo Discount Factors
*                                        Only used if what = KEY_SPOT
*
*               YTMCONV     *ytmc        Conventions for the repo rate
*                                        Only used if what = KEY_REPO.
*
*               ITERCTRL    *ictrl       Iteration control (repo calc)
*
*               KEYCONV     what         What to calculate
*
*   output      FL64        *impl        The implied measure in %
*
*   returns     True if all OK, False if not.
*
*   diagnostics
*
*   see also    RepoBond_CC2NPV()
*
*************************************************************************
,,EOH,,*/

BOOLE RepoBond_DF2Impl(REPOBOND* repo,
                       FL64      bbp,
                       HOLI_STR*  holi,
                       DFSPREAD*  dfs,
                       DISCFAC*   df,
                       YTMCONV*   ytmc,
                       ITERCTRL*  ictrl,
                       KEYCONV   what,
                       FL64*      impl)
{
    CFLWARRAY xcflw, cflw ;
    BOOLE     ok, use_gu ;
    FL64      gu, dummy, nom ;
    TRADEINFO settle, end ;
    EXINF     dum ;
    DATESTR   sell, buy ;

    /* Adjust for business days */
    sell = Cldr_NextBusinessDate(&repo->sell_date, holi) ;
    buy  = Cldr_NextBusinessDate(&repo->buy_date, holi) ;

    /* Initialise */
    ok = True ;

    /* Generate the original flow for this bond */
    cflw = Cflw_GenrCflw(&repo->bond.repay, &repo->bond.rday,
                         &repo->bond.fix, &repo->bond.cday, holi) ;

    /* Extract the specific period flow */
    nom     = (repo->reverse == True ? -100.0 : 100.0) ;
    settle  = Set_TRADEINFO(&sell, NULL, NULL, False, 100.0, nom, NULL, NULL) ;
    end     = Set_TRADEINFO(&buy, NULL, NULL, False, bbp, 100.0, NULL, NULL) ;
    xcflw   = Cflw_ExtractPeriod(&settle, &end, &repo->bond.fix,
                                 &repo->bond.cday.pseq, &repo->bond.accru,
                                 &repo->bond.exp, holi, True, cflw,
                                 &repo->bond.repay.pp,
                                 repo->bond.repay.aufab, &dum) ;
    /* Tax adjust */
    Bond_TaxAdjCflw(xcflw, &repo->bond.tax, &repo->bond.fix.effective,  
                    &repo->bond.cday.last) ;

    /* Be careful about guessing */
    gu = ictrl->init_guess ;
    use_gu = ictrl->use_init_guess ;
    ictrl->init_guess = (use_gu ? gu : 10.0) ;
    ictrl->use_init_guess = True ;

    if (what == KEY_REPO)
        ok = RepoCflw_YTM2Yield(repo->sell_price, xcflw, &buy,
                                ytmc, &repo->bond.cday, 
                                repo->bond.fix.fix_rate,
                                &repo->bond.repay.pp, 
                                holi, ictrl, impl) ;

    else if (what == KEY_SPOT)
        *impl = RepoCflw_DF2Price(&sell, df, xcflw, 
                                  &buy, &repo->bond.repay.pp, 
                                  holi, dfs, NULL, &dummy, &dummy) ;

    /* Clean up */
    ictrl->init_guess = gu ;
    ictrl->use_init_guess = use_gu ;

    Free_CFLWARRAY(xcflw, 1) ;
    Free_CFLWARRAY(cflw, 1) ;

    return ok ;
}


/*,,SOH,,
*************************************************************************
*
*              RepoBond_GenrCflw()
*
*    interface #include <future.h>
*              CFLWARRAY RepoBond_GenrCflw(REPOBOND    *repo,
*                                           HOLI_STR    *holi) ;
*
*    general   This function generates cash flow for repo bonds from
*              sell date to buy date
*
*    input     REPOBOND   *repo      The repo bond contract spec.
*
*              HOLI_STR   *holi      Business day adjustment data
*
*    returns   Pointer to cashflow generated. Allocated in this routine
*              as Alloc_CFLWARRAY(1, x), where x is calculated.
*
*    diagnostics
*
*    see also
*
*************************************************************************
,,EOH,,*/

CFLWARRAY RepoBond_GenrCflw(REPOBOND*   repo,
                             HOLI_STR*      holi)
{
    FL64        nom, bbp ;
    CFLWARRAY   cflw, xcflw ;
    TRADEINFO   settle, end ;
    EXINF       dummy ;
    DATESTR     sell, buy ;

    /* Adjust for business days */
    sell = Cldr_NextBusinessDate(&repo->sell_date, holi) ;
    buy  = Cldr_NextBusinessDate(&repo->buy_date, holi) ;

    /* Generate the original flow for this bond */
    cflw = Cflw_GenrCflw(&repo->bond.repay, &repo->bond.rday,
                         &repo->bond.fix, &repo->bond.cday, holi) ;

    /* Extract the specific period flow */
    bbp    = RepoBond_BuyBack(repo, holi) ;    
    nom    = (repo->reverse == True ? -100.0 : 100.0) ;
    settle = Set_TRADEINFO(&sell, NULL, NULL, False, 100.0, nom, NULL, NULL) ;
    end    = Set_TRADEINFO(&buy, NULL, NULL, False, bbp, 100.0, NULL, NULL) ;
    xcflw  = Cflw_ExtractPeriod(&settle, &end, &repo->bond.fix,
                                &repo->bond.cday.pseq, &repo->bond.accru,
                                &repo->bond.exp, holi, True, cflw,
                                &repo->bond.repay.pp, 
                                repo->bond.repay.aufab, &dummy) ;
    /* Tax adjust */
    Bond_TaxAdjCflw(xcflw, &repo->bond.tax, &repo->bond.fix.effective,  
                    &repo->bond.cday.last) ;

    /* Free CFLW */
    Free_CFLWARRAY(cflw, 1) ;

    return xcflw ;
}


/*,,SOH,,
*************************************************************************
*
*               RepoBond_DF2Delta()
*
*   interface   #include <future.h>
*               FL64ARRAY RepoBond_DF2Delta(DATESTR     *analys,
*                                           REPOBOND    *repo,
*                                           DISCFAC     *df,
*                                           DFSPREAD    *dfs,
*                                           HOLI_STR    *holi,
*                                           DELTASET    *ds) ;
*
*   general     The function calculates the delta vector for a repo
*               bond using a list of predefined shocks to
*               the zero-coupon curve.
*
*               The delta vector represents the price differences
*               invoked by the curve shocks.
*
*   input       DATESTR     *analys      Analysis date.
*
*               REPOBOND    *repo        Repo bond contract spec.
*
*               DISCFAC     *df          Discount factors.
*
*               DFSPREAD    *dfs         The spread against df.
*
*               HOLI_STR    *holi        Holiday setup.
*
*               DELTASET    *ds          Data for delta vector calc.
*
*   output
*
*   returns     The delta vector allocated as:
*
*                         Alloc_FL64ARRAY(ds->nshock) ;
*
*   diagnostics
*
*   see also    RepoBond_DF2NPV()
*               Disc_DeltaPrep()
*               Boot_DeltaPrep()
*
*************************************************************************
,,EOH,,*/

FL64ARRAY RepoBond_DF2Delta(DATESTR* analys,
                            REPOBOND* repo,
                            DISCFAC*  df,
                            DFSPREAD* dfs,
                            HOLI_STR* holi,
                            DELTASET* ds)
{
    CFLWARRAY   xcflw ;
    FL64ARRAY   dv ;
    DATESTR     buy ;

    /* Adjust for business days */
    buy  = Cldr_NextBusinessDate(&repo->buy_date, holi) ;
    
    /* Generate repo bond cflw */
    xcflw = RepoBond_GenrCflw(repo, holi) ;

    /* Calculate DeltaVector */
    dv = RepoCflw_DF2Delta(analys, df, xcflw, &buy,
                           &repo->bond.repay.pp ,holi, dfs, ds) ;              

    /* Free cflw */
    Free_CFLWARRAY(xcflw, 1) ;

    return dv ;
}


/*,,SOH,,
*************************************************************************
*
*               RepoBond_YTM2Price()
*
*   interface   #include <future.h>
*               FL64 RepoBond_YTM2Price(FL64      ytm,
*                                       REPOBOND  *repo,
*                                       YTMCONV   *ytmc,
*                                       HOLI_STR  *holi,
*                                       RISKCONV  risk,
*                                       BOOLE     modf,
*                                       FL64      *dp,
*                                       FL64      *ddp) ;
*
*   general     This function calculates the forward repo bond price.
*
*               The function is quite general in taking into account a
*               number of bond curiosities.
*
*               The function does not use the spot price bond only the
*               reporate of the repo contract. For a spot
*               price based routine see RepoBond_CC2price().
*
*               Risk ratios are calculated as follows:
*
*                   risk->key      dp          ddp
*                   ---------      ---         ----
*                   KEY_DF         $Duration   $Convexity
*                   KEY_BPV        BPV
*
*   input       FL64        ytm          The repo rate
*
*               REPOBOND    *repo        Repo contract spec.
*
*               YTMCONV     *ytmc        The conventions defined for
*                                        calculating the YTM.
*                                        ytmc->irr cannot be MAIR.
*
*               HOLI_STR    *holi        Holiday setup.
*
*               RISKCONV    risk         The risk setup.
*
*               BOOLE       modf         True means that ratios are
*                                        modified.
*                                        (i.e. scaled with the dirty
*                                        price), False means direct
*                                        derivatives.
*
*   output      FL64        *dp          Dollar duration
*
*               FL64        *ddp         Dollar convexity
*
*   returns     The
*
*   diagnostics
*
*   see also    RepoBond_CC2NPV()
*               RepoBond_DF2NPV()
*
*************************************************************************
,,EOH,,*/

FL64 RepoBond_YTM2Price(FL64   ytm,
                        REPOBOND*  repo,
                        YTMCONV*   ytmc,
                        HOLI_STR*  holi,
                        RISKCONV  risk,
                        BOOLE     modf,
                        FL64*      dp,
                        FL64*      ddp)
{
    FL64        p ;
    CFLWARRAY   xcflw ;
    DATESTR     buy ;

    /* Adjust for business days */
    buy  = Cldr_NextBusinessDate(&repo->buy_date, holi) ;

    /* Generate repo bond cflw */
    xcflw = RepoBond_GenrCflw(repo, holi) ;

    /* Calculate price */
    p = RepoCflw_YTM2Price(ytm, xcflw, &buy, ytmc, &repo->bond.cday, 
                           repo->bond.fix.fix_rate, &repo->bond.repay.pp, 
                           holi, risk, modf, dp, ddp) ;

    /* Free cflw */
    Free_CFLWARRAY(xcflw, 1) ;

    return p ;
}



/*,,SOH,,
*************************************************************************
*
*               Free_REPOBOND()
*
*    interface  #include <future.h>
*               void Free_REPOBOND(REPOBOND *fixp) ;
*
*    general    Free_REPOBOND() frees memory for a REPOBOND. All the
*               memory is suballocated in the fixp structure.
*
*    input      REPOBOND   *fixp       The bond data container
*
*    output
*
*    returns
*
*    diagnostics
*
*    see also
*
*************************************************************************
,,EOH,,*/


void Free_REPOBOND(REPOBOND* fixp)
{
    /* Free all suballocated memory */
    Free_FIXPAY(&fixp->bond);
}



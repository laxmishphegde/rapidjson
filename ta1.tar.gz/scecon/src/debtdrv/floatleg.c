/* @(#)floatleg.c	1.19 (SimCorp) 99/11/12 10:45:43 */

/************************************************************************
*
*       project         SCecon Library
*
*       file name       floatleg.c
*
*       contains        float leg functions for swap calculations
*
************************************************************************/

/*** includes **********************************************************/
#include <swapval.h>

/*** defines  **********************************************************/
#define SPREAD_FREQ      3
#define SPREAD_DAMP      0.9
#define SPREAD_ACC       0.00000001
#define SPREAD_GUESS     0.0 
#define SPREAD_MIN      -1000.0
#define SPREAD_MAX       1000.0
#define SPREAD_EPS       0.01
#define SPREAD_MAXIT     100
#define COUPON_TOL       0.00001
#define PRICE_TOL        0.000001


/*,,SOH,,
*************************************************************************
*
*              SwapFl_GenrCflw()
*
*    interface #include <swapval.h>
*              CFLWARRAY SwapFl_GenrCflw(DATESTR       *analys,
*                                         SWAPFLOAT     *sfl,
*                                         DISCFAC       *df,
*                                         DISCFAC       *df_dsc,
*                                         CMCONVADJ     *cmadj,
*                                         HOLI_STR      *holi) ;
*
*    general   This function generates cash flow for the floating leg
*              of an interest rate swap according to a number of con-
*              ventions.
*
*              The function handles floating legs at issue or at a
*              future date (seasoned legs).
*
*    input     DATESTR       *analys Analysis date.
*                                    Informs on relevant fixing periods
*                                    Default: df->disc->day[0]
*                                    analys >= Default
*
*              SWAPFLOAT     *sfl    The floating leg definition
*
*              DISCFAC       *df     Zero Curve
*                                    For cashflow generation
*
*              DISCFAC       *df_dsc Zero Curve
*                                    For convexity adjusting ONLY.
*                                    (i.e. not used for vanillas)
*                                    Enter NULL if not used.
*
*              CMCONVADJ     *cmadj  Data for Convexity Adjustment
*                                    Use NULL if no adjustment
*
*              HOLI_STR      *holi   Business-Day adjustment setup.
*
*    output
*
*    returns   Pointer to cashflow allocated as Alloc_CFLWARRAY(1, x)
*              where x is sufficiently large.
*
*    diagnostics
*
*    see also  SwapFl_GenrCoupons()
*              SwapFl_DF2Spread()
*
*    wrapper   AP
*
*************************************************************************
,,EOH,,*/

CFLWARRAY SwapFl_GenrCflw(DATESTR*   analys,
                              SWAPFLOAT* sfl,
                              DISCFAC*   df,
                              DISCFAC*   df_dsc,
                              CMCONVADJ* cmadj,
                              HOLI_STR*  holi)
{
    INTI       nc, na = 0, i, nfloat, idum, ixc, ixa ;
    DATEARRAY  tmpdays, cdays ;
    FL64ARRAY  coups ;
    FL64ARRAY  ratesTab = (FL64ARRAY) NULL;
    FL64       init_exch, *pfamort, *pfcoupon, *pfRatesTab;
    DATESTR    tmpday, *pfdays, effold, dteomatur ;
    PLAN_STR   plana ;
    BOOLE      io, amortize ;
    CFLWARRAY  cflw ;

    /* warning avoidance */
    memset(&plana, 0, sizeof(plana));

    /* 1.0 Initialize */
    io = sfl->repay.io ;
    init_exch = sfl->repay.init_exch ;

    effold = sfl->float1.fbase.effective ;
    if (Cldr_DateLT(&sfl->repay.teomatur, &effold) == True)
        dteomatur = sfl->rday.last ;
    else
        dteomatur = sfl->repay.teomatur ;

    if (sfl->pday.pseq.seq == TAM_T4M)
    {
        sfl->float1.fbase.effective = Cflw_Snap2(&effold, TAM_T4M,
                                                 sfl->pday.snap2, holi) ;
        dteomatur = Cflw_Snap2(&dteomatur, TAM_T4M, sfl->rday.snap2, holi) ;
    }

    /* 2.0 Generate the appropriate days */
    cdays = Cflw_Paydays(&sfl->pday, holi, &nc) ;

    /* 2.1 Generate the amortflow */
    switch (sfl->repay.type)
    {
        case BULLET:

            tmpday         = sfl->rday.last ;
            sfl->rday.last = dteomatur ;
            plana.day = Cflw_Paydays(&sfl->rday, holi, &na) ;
            plana.f64 = Alloc_FL64ARRAY(na) ;
            if (na > 0)
                plana.f64[na - 1] = 100.0 ;

            plana.filled = na ;
            sfl->rday.last = tmpday ;
            break ;

        case SERIAL:

            tmpday = sfl->rday.last ;

            if (Cldr_DateLE(&sfl->repay.teomatur, 
                            &sfl->float1.fbase.effective) == False)
                sfl->rday.last = dteomatur ;

            plana.day = Cflw_Paydays(&sfl->rday, holi, &na) ;
            plana.f64 = Alloc_FL64ARRAY(na) ;
            for (i = 0; i < na; i++)
                plana.f64[i] = 100.0 / (FL64) na ;

            /* Chk out for balloons in the amortflow */
            na = Cflw_Balloon(plana.day, na, &sfl->rday.last, plana.f64) ;
            plana.filled = na ;

            sfl->rday.last = tmpday ;

            break ;

        case NONREGULAR:

            na = GetPlanFill(sfl->repay.irreg) ;
            plana.day = Alloc_DATEARRAY(na) ;
            plana.f64 = Alloc_FL64ARRAY(na) ;
            for (i = 0; i < na; i++)
            {
                plana.f64[i] = sfl->repay.irreg->f64[i] ;
                plana.day[i] = sfl->repay.irreg->day[i] ;
            }

            /* Chk out for balloons in the amortflow */
            na = Cflw_Balloon(plana.day, na, &cdays[nc - 1], plana.f64) ;
            plana.filled = na ;

            break ;

        default:
            ;
    }

    /* 2.15 Adjust for businessdays */
    Cldr_Move2BusinessDays(plana.day, plana.filled, holi) ;

    /* 2.2 Generate the appropriate floating payments */
    coups = SwapFl_GenrCoupons(analys, &sfl->float1, &sfl->pday.pseq, &plana,
                                df, df_dsc, cmadj, holi, cdays, nc, &ratesTab); /* PMSTA10118 - DDV - 100623 */

    /* 2.3 Merge the dates and payments */
    cflw     = Alloc_CFLWARRAY(1, nc + 2 + na) ;
    pfdays   = cflw->days ;
    pfamort  = cflw->repay ;
    pfcoupon = cflw->coupon ;
    pfRatesTab = cflw->ratesTab; /* PMSTA10118 - DDV - 100628 - set the rate into cflw */
    cflw->count = nc + 2 + na ;

    amortize = (na > 0 ? True : False) ;

    if (amortize == True && io == False)
        tmpdays = Cldr_MergeDates(plana.day, na, cdays, nc, &nfloat) ;
    else
    {
        if (io == False && nc == 0)
        {
            /* This will handle obscure zero coupon legs */
            tmpdays = Alloc_DATEARRAY(1) ;
            nfloat  = 1 ;
            tmpdays[0] = sfl->pday.last ;
        }
        else
            tmpdays = Cldr_MergeDates(plana.day, 0, cdays, nc, &nfloat) ;
    }

    for (i = 0; i < nfloat ; i++)
        cflw->days[i] = tmpdays[i] ;

    if (fabs(init_exch) > PRICE_TOL)
        nfloat = Cldr_InsertDate(cflw->days, nfloat,
                                  &sfl->float1.fbase.effective, &idum) ;

    for (ixc = ixa = 0, i = 0 ; i < nfloat ; i++)
    {
        if (ixc < nc && Cldr_DateEQ(&pfdays[i], &cdays[ixc]) == True)
        {
            if (ratesTab != NULL)
                pfRatesTab[i] = ratesTab[ixc]; /* PMSTA10118 - DDV - 100623 */

            pfcoupon[i] = coups[ixc++] ;
        }

        if (ixa < na && Cldr_DateEQ(&pfdays[i], &plana.day[ixa]) == True &&
            amortize == True && io == False)
            pfamort[i] = plana.f64[ixa++] ;
    }

    if (amortize == False && io == False)
        pfamort[nfloat - 1] = 100.0 ;

    /* 3.0 Adjust for specialities - delay and initial exchange */
    if (sfl->delay)
    {
        if (holi->bus != NO_BUSADJUST)
        {
            for (i = 0 ; i < nfloat ; i++)
                pfdays[i] = Cldr_AddBusinessdays(&pfdays[i], (INTL) sfl->delay,
                                                 holi->nholi, holi->holidays) ;
        }
        else
        {
            for (i = 0 ; i < nfloat ; i++)
                pfdays[i] = Cldr_AddDays(&pfdays[i], (INTL) sfl->delay,
                                         sfl->float1.fbase.cal, holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */
        }
    }

    /* Note that initial exchange is NOT delayed */
    if (fabs(init_exch) > PRICE_TOL)
    {
        pfdays[0]  = Cldr_NextBusinessDate(&sfl->float1.fbase.effective, holi) ;
        pfamort[0] = - init_exch ;
    }

    /* 4.0 Clean up and return */
    sfl->float1.fbase.effective = effold ;

    Free_DATEARRAY(tmpdays) ;
    Free_DATEARRAY(cdays) ;
    Free_FL64ARRAY(coups) ;
    Free_FL64ARRAY(ratesTab) ;  /* PMSTA10118 - DDV - 100623 */
    Free_DATEARRAY(plana.day) ;
    Free_FL64ARRAY(plana.f64) ;

    cflw->filled = nfloat ;

    return cflw ;
}

/*,,SOH,,
************************************************************************
*
*
*              SwapFl_GenrCoupons()
*
*  interface   #include <swapval.h>
*              FL64ARRAY SwapFl_GenrCoupons(DATESTR *analys,
*                                           FLOATRATE *float1,
*                                           PAYDAYSEQ *pseq,
*                                           PLAN_STR *amort,
*                                           DISCFAC *df,
*                                           DISCFAC *df_dsc,
*                                           CMCONVADJ *cmadj,
*                                           HOLI_STR *holi,
*                                           DATEARRAY cdays,
*                                           INTI nfloat) ;
*
*  general     This function generates cash flow for the floating leg
*              of an swap according to a number of market conventions.
*
*              The function handles floating legs at issue or at a
*              future date (seasoned legs).
*              When more than one of the operations of averaging,
*              compounding/decompounding and multiplication with
*              a LIBOR factor is to be performed, the order of
*              application is as follows :
*              Lookup LIBOR
*              Average
*              Apply LIBOR-factor
*              Apply compounding rules
*
*              In particular, note that multiplication by LIBOR-factor
*              is prior to compounding.
*
*  input       DATESTR            *analys Analysis date.
*                                         Informs on relevant fixing
*                                         periods
*                                         Default: df->disc->day[0]
*                                         analys >= Default
*
*              FLOATRATE          *float1 The data needed for coupon
*                                         calc.
*
*              PAYDAYSEQ          *pseq   Payday sequencing
*
*              PLAN_STR           *amort  The amortization schedule.
*                                         Must sum to 100.
*
*              DISCFAC            *df     Zero Curve
*                                         For cashflow generation
*
*              DISCFAC            *df_dsc Zero Curve
*                                         For convexity adjusting ONLY.
*                                         (i.e. not used for vanillas)
*                                         Enter NULL if not used.
*
*              CMCONVADJ          *cmadj  Data for Convexity Adjustment
*                                         Use NULL if no adjusment
*
*              HOLI_STR           *holi   Business-Day adjustment setup.
*
*              DATEARRAY          cdays   Array of coupon paydays.
*                                         Business day adjusted - if
*                                         needed.
*
*              INTI               nfloat  No. of elements in cdays.
*
*  output      
*
*  returns     The coupon stream allocated in this routine as:
*
*              Alloc_FL64ARRAY(nfloat) ;
*
*  diagnostics
*
*  see also    SwapFl_GenrCflw()
*              SwapFl_DF2Spread()
*
************************************************************************
,,EOH,,*/

FL64ARRAY SwapFl_GenrCoupons(DATESTR*   analys,
                                  FLOATRATE* float1,
                                  PAYDAYSEQ* pseq,
                                  PLAN_STR*  amort,
                                  DISCFAC*   df,
                                  DISCFAC*   df_dsc,
                                  CMCONVADJ* cmadj,
                                  HOLI_STR*  holi,
                                  DATEARRAY  cdays,
                                  INTI       nfloat,
                                  FL64ARRAY  *ratesTabPtr) /* PMSTA10118 - DDV - 100623 */
{
    INTI       na, mcomp, i, ixf, ixs, ix, ne, ncomp, ixfloat, ixa, mfreq,
               nspr, nfac ;
    DATEARRAY  compdays, events ;
    DATESTR    *pfdays, *pevents, Lstart, Lend, start, end, date, pd0bus, c1day,
               prev, next, effective, effbus, *amday, Dvol, dtmp ;
    BOOLE      forw_fix, backset, averaging, use_first, plain,
               seasoned, TAMspec, first_odd ;
    FL64       rsaldo, csaldo, comp_per_amt, *pfcoupon, period, factor, spread, 
               coupon1, coupon, TAMperiod, TAMdays, TAMann, dur, ca ;
    COMPMETHOD method ;
    CALCONV    cal, calforw ;
    EOMCONV    eom ;
    TERMUNIT   unit ;
    PERIOD     per ;
    FL64       adjcoup, anncoup, alpha ;

    /* warning avoidance */
    memset(&prev, 0, sizeof(prev));
    first_odd = False ;

    Math_LaGuerre(analys->y, analys->m, analys->d);


    /* 0.0 Various initialization */
    pfdays   = cdays ;
    pfcoupon = Alloc_FL64ARRAY(nfloat) ;

    if (ratesTabPtr != NULL)
       (*ratesTabPtr) = Alloc_FL64ARRAY(nfloat);

    if (nfloat < 1 || GetPlanFill(df->disc) <= 1)
        return pfcoupon ;

    /* 0.1 - Pick data for convenience */
    eom       = pseq->eom ;
    effective = float1->fbase.effective ;
    coupon1   = float1->fbase.coupon1 ;
    factor    = float1->factor ;
    spread    = float1->fbase.spread ;
    backset   = float1->backset ;
    method    = float1->method ;
    dur       = float1->index.LIBORdur ;
    unit      = float1->index.LIBORunit ;
    /* Avoid strange calendar dependent use of fractional years*/
    if (unit == YEARS) 
    {
        unit = MONTHS ;
        dur *= 12.0 ;
    }
    cal       = float1->fbase.cal ;
    calforw   = (float1->method == TAM ?  ACT360 : float1->fbase.cal) ;

    /* 0.15 Pointers */
    amday = GetPlanDay(amort) ;
    na    = GetPlanFill(amort) ;
    nspr  = GetPlanFill(float1->stepspr) ;
    nfac  = GetPlanFill(float1->stepfac) ;

    /* 0.2 Chk that index duration is equal to pay frequency */
    plain = Cflw_Is_Harmonic(pseq->term, pseq->unit, &mfreq) ;
    plain = SwapFl_Is_Plain(float1, pseq, holi) ;

    /* 0.3 Chk that averaging duration is equal to pay frequency */
    averaging = SwapFl_Is_AVG(float1, pseq, holi) ;

    /* 0.4 For TEC10's: is the first period odd? */
    if (method == DECOMPOUND)
    {
      per = Set_PERIOD(pseq->term, pseq->unit) ;
      dtmp = Cldr_NextROLL(&effective, pseq->seq, &per, ACTACT, eom, holi) ;
      Cldr_Move2BusinessDays(&dtmp, 1, holi) ;
      first_odd = (Cldr_DateEQ(&dtmp, &cdays[0])) ? False : True ;
      first_odd = first_odd || Cldr_DateEQ(&effective, &cdays[0]) ;
    }

    /* 1.0 Set the compounding dates */
    mcomp = Cflw_MonthsBetweenPayments(float1->compfreq) ;

    if (mcomp >= mfreq)
    {
        mcomp = mfreq ;
        if (method != DECOMPOUND)
            method = NONE ;
    }
    else
    {
        /* Avoid silly situations */
        if (method != FLAT && method != REGCOMPOUND && method != TAM)
            mcomp = mfreq ;
    }

    compdays = SwapFl_Genr_Compdays(float1, pseq, False, holi, pfdays,
                                    nfloat, &ncomp);

    /* 2.0 The method in this function is to loop over the event dates. These
           dates are either a couponday, an amortization day or a compounding
           day (if the compounding frequency is larger than the payment
           frequency). So first we generate the total number of eventdates. */
    events  = Cldr_MergeDates(compdays, ncomp, amday, na, &ne) ;
    pevents = events ;

    /* 3.0 Loop over the events and generate the coupons on the fly */
    ixfloat = ixa = ixf = ixs = 0 ;
    csaldo  = (method == TAM ? 1.0 : 0.0) ;
    rsaldo  = 1.0 ;
    comp_per_amt = 0.0 ;

    /* 3.1 Use FirstCoupon ?? - Override for Backsets, except if the current
           date is after the first compounding date of the current coupon
           period, or the fixing-delay date. */
    use_first = True ;
    if (backset == True)
    {
        use_first = False ;

        /* Find previous payday */
        ix = Cldr_FindDateIndex(cdays, nfloat, analys, 0,
                                SEARCH_BISECTION, NEXTINDEX) - 1 ;
        if (ix < 0)
            prev = effective ;
        else
            prev = pfdays[ix] ;

        /* The first compounding date of this period is: */
        prev = Cldr_AddMonths(&prev, mcomp, eom) ;
        prev = Cldr_NextBusinessDate(&prev, holi) ;

        /* Adjust for fixing */
        next = Cldr_TermUnit2Date(&prev, -float1->delay.num,
                                  float1->delay.unit, cal, eom, holi) ;

        if (Cldr_DateLE(&next, analys) == True)
            use_first = True ;
    }

    /* 3.2 Initialise spread/factor */
    factor = Cldr_PlanLookup(factor, float1->stepfac, &effective, &ixf) ;
    spread = Cldr_PlanLookup(spread, float1->stepspr, &effective, &ixs) ;

    /* 3.21 Set up various logical switches - and business day adjustments */
    effbus = Cldr_NextBusinessDate(&effective, holi) ;
    pd0bus = Cldr_NextBusinessDate(analys, holi) ;

    forw_fix = Cldr_DateEQ(&effbus, &pfdays[0]) ||
              (Cldr_DateLT(&pd0bus, &effbus) && float1->fbase.is_fix == False);

    if (forw_fix == True)
        effective = effbus ;

    seasoned = Cldr_DateLT(&effective, &pd0bus) ;

    /* Set the day coupon1 points to */
    c1day = Cldr_YMD2Datestr((YYYYMMDD) 0) ;
    if (float1->fbase.is_fix == True && use_first == True &&
       (seasoned == True || forw_fix == False) )
    {
        if (backset == True)
            c1day = prev ;
        else
        {
            ix = Cldr_FindDateIndex(pevents, ne, analys, 0,
                                     SEARCH_BISECTION, NEXTINDEX) ;
            if (ix < ne)
                c1day = pevents[ix] ;
        }
    }

    /* CMT vol - if needed */
    Dvol = effective ;
    if (cmadj != NULL && cmadj->volCM.vc == FORWVOL && ne >= 1)
        Dvol = pevents[ne - 1] ;

    /* Loop over event days to generate floating payments */
    for (i = 0 ; i < ne ; i++)
    {
        /* 3.1 Next eventdate */
        date = pevents[i] ;

        /* 3.2 First generate the period length */
        if (i > 0)
            start = pevents[i - 1] ;
        else
            start = effective ;

        end    = pevents[i] ;
		/* PMSTA-22396 - SRIDHARA � 160502 */
        period = Cldr_DaysPerYear(&start, &end, 0, cal, eom, holi) ;
        period = ((FL64) Cldr_DaysBetweenDates(&start, &end, cal, holi)) / period ;

        /* 3.2.1 Read vols - if needed - at fixing date */
        if (cmadj != NULL && cmadj->volCM.vc == FORWFORW)
            Dvol = start ;

        /* 3.3 Now find the LIBOR days - ie. for coupon generation */
        if (backset == True)
        {
           if (plain == True && ixfloat < nfloat - 1 && method == NONE)
           {
                Lstart = pfdays[ixfloat] ;
                Lstart = Cldr_TermUnit2Date(&Lstart, -float1->delay.num,
                                            float1->delay.unit, 
                                            float1->index.LIBORcal, eom, 
                                            holi) ;
                Lend   = pfdays[ixfloat + 1] ;
                Lend   = Cldr_TermUnit2Date(&Lend, -float1->delay.num,
                                            float1->delay.unit, 
                                            float1->index.LIBORcal, eom, 
                                            holi) ;
            }
            else
            {
                /* Use the correct LIBOR duration */
                Lstart = end ;
                Lstart = Cldr_TermUnit2Date(&Lstart, -float1->delay.num,
                                            float1->delay.unit, 
                                            float1->index.LIBORcal, eom, 
                                            holi) ;
                Lend   = Cldr_Term2Date(&end, dur, unit, 
                  float1->index.LIBORcal, eom) ;
                Lend   = Cldr_NextBusinessDate(&Lend, holi) ;
            }
        }
        else
        {
            /* Not Backset */
            if (plain == True)
            {
                /* Standard fixing */
                Lstart = start ;
                Lend   = end ;
            }
            else
            {
                /* Use the correct LIBOR duration */
                Lstart = start ;
                Lend   = Cldr_Term2Date(&start, dur, unit, 
                  float1->index.LIBORcal, eom) ;
                Lend   = Cldr_NextBusinessDate(&Lend, holi) ;
            }
        }

        /* 3.4 Now find the forward rate by interpolation or as current LIBOR.
               Be careful about Seasoned TAM's */
        TAMspec = True ;
        if (method == TAM && seasoned == True &&
            Cldr_DateLT(&Lstart, &pd0bus) == False)
            TAMspec = False ;

        if (Cldr_DateLE(&date, &c1day) == True && TAMspec == True)
        {
            /* 3.4.1 This is the first/current LIBOR (incl. seasoned legs) */
            if (averaging == False || method == TAM)
                coupon = coupon1 ;
            else
                /* Do the averaging in the remainder of the current period */
                coupon = SwapFl_Genr_AVG(analys, &Lstart, &Lend, &end, &Dvol,
                                         float1, df, cmadj, eom, holi, True) ;

        }
        else
        {
            /* 3.4.2 This is future LIBOR */
            if (averaging == False)
                coupon = SwapFl_DF2ForwRate(&Lstart, &Lend, &end, &Dvol,
                                            &float1->index, backset,
											df, df_dsc, cmadj, &ca, holi);  /* PMSTA-23341 - SRIDHARA � 160517 */
            else
                /* Do the averaging */
                coupon = SwapFl_Genr_AVG(analys, &Lstart, &Lend, &end, &Dvol,
                                         float1, df, cmadj, eom, holi, False) ;
        }

        /* 3.41 Adjust for a Libor factor - the interpretation with compounding
                is ours */
        coupon *= factor ;

        /* 3.5 Now compound and accumulate the coupon */
        switch (method)
        {
            case NONE:

                csaldo += (coupon + spread) * period * rsaldo ;
                break ;

            case REGCOMPOUND:

                if (Cldr_DateLT(&Lstart, analys) == True)
                    csaldo = coupon ;
                else
                    csaldo = SwapFl_Genr_Regcompound(rsaldo, csaldo, period,
                                                     coupon, spread) ;
                break ;

            case FLAT:

                if (Cldr_DateLT(&Lstart, analys) == True)
                    csaldo = coupon ;
                else
                    csaldo = SwapFl_Genr_Flat(rsaldo, csaldo, period,
                                              coupon, spread) ;
                break ;

            case TAM:

                if (Cldr_DateLT(&start, analys) == True &&
                    Cldr_DateLE(analys, &end) == True)
                {
                    /* Here we interpret the input coupon1 as TAG of the
                       period passed from the last payday/issue */

                    /* Find previous payday/effective date */
                    ix = Cldr_FindDateIndex(pfdays, nfloat, analys, 0,
                                             SEARCH_BISECTION, NEXTINDEX) - 1 ;
                    if (ix < 0)
                        prev = effective ;
                    else
                        prev = pfdays[ix] ;

                    /* Find next compounding date */
                    ix = Cldr_FindDateIndex(compdays, ncomp, analys,
                                             ix, SEARCH_FORWARDS, SAMEINDEX) ;
                    if (ix < ncomp)
                        next = compdays[ix] ;

                    /* Find number of days till previous TAG-date
                       TAG follows an ACTACT calendar (from input calendar) */
					/* PMSTA-22396 - SRIDHARA � 160502 */
                    TAMdays = Cldr_DaysBetweenDates(&prev, &next, cal, holi) ;
                    TAMann  = Cldr_DaysPerYear(&prev, &next, 0, cal, eom, holi);

                    /* Remember csaldo is multiplicative !!! */
                    csaldo = 1.0 + coupon * TAMdays / (TAMann * 100.0) ;
                }

                else if (Cldr_DateLE(analys, &start) == True)
                {
                    /* This is a full period or completion of a broken period
                       T4M follows an ACT360 calendar */
					/* PMSTA-22396 - SRIDHARA � 160502 */
                    TAMperiod = Cldr_DaysPerYear(&start, &end, 0,
                                                   calforw, eom, holi) ;
                    TAMdays   = (FL64) Cldr_DaysBetweenDates(&start, &end,
                                                             calforw, holi);
                    TAMperiod = TAMdays / TAMperiod ;
                    comp_per_amt = (coupon + spread) * TAMperiod / 100.0 ;
                    csaldo      *= (1.0 + comp_per_amt) ;
                }
                else
                    /* Just dummy */
                    csaldo = 1.0 + coupon / 100.0 * period ;

                break ;

            case DECOMPOUND:

                /* Decompound the index fixing to find ANNUAL coupon */
                if (i == 0 && first_odd == True)
                { /* deal with first odd coupon */
                  anncoup = 1.0 + (coupon + spread) / 100.0 ;
                  anncoup = pow(anncoup, period) - 1.0 ;
                  anncoup *= 100 ;
                  alpha = 1.0 ;
                }
                else /* normal case */
                {
                  anncoup = Cflw_Decompound(coupon + spread, mcomp, 
                                      True, EPR_PER, NULL, NULL, cal, holi) ;   /* PMSTA-22396 - SRIDHARA � 160502 */
                  alpha = 12.0 / (FL64) mcomp ;
                }

                /* Adjust for the convexity of the root function *
                  Did not seem worthwhile...
                if (False && cmadj != NULL && cmadj->order != NO_CMADJ
                  && !Cldr_DateLE(&date, &c1day))
                {
                  cmvol = Vol_Interpolation(&Lstart, cmadj->volCM) ;
                  T = Cldr_TermBetweenDates(analys, &Lstart, 0, 
                                           cmadj->volCM.cal, eom) ;
                  adjcoup = (alpha - 1.0) / (2.0 * SQR(alpha)) ;
                  adjcoup *= SQR(cmvol * coupon / 10000) * T ;
                  adjcoup /= SQR(1.0 + (coupon + spread) / 100.0) ;
                  adjcoup = 1.0 - adjcoup ;
                }
                else */
                  adjcoup = 1.0 ;

                /* find adjusted PERIOD coupon */
                adjcoup = (anncoup / alpha + 100.0) * adjcoup - 100.0 ;

                /* update 'csaldo' */
                csaldo += rsaldo * adjcoup ;                
                break ;
        }

        /* 3.6 Set the coupon if this is a payday */
        if (ixfloat < nfloat && Cldr_DateEQ(&date, &pfdays[ixfloat]) == True)
        {
            if (method == TAM)
                csaldo = (csaldo - 1.0) * 100.0 ;

            /* PMSTA10118 - DDV - 100628 - set the rate into cflw */
            if (ratesTabPtr != NULL && (*ratesTabPtr) != NULL)
                (*ratesTabPtr)[ixfloat] = coupon;

            pfcoupon[ixfloat++] = csaldo ;

            /* 3.6.1 Init for next loop */
            csaldo = (method == TAM ? 1.0 : 0.0) ;
            comp_per_amt = 0.0 ;
        }

        /* 3.7 A repay day ??? - adjust the debt saldo */
        if (ixa < na && Cldr_DateEQ(&date, &amday[ixa]) == True)
            rsaldo -= amort->f64[ixa++] / 100.0 ;

        /* 3.8 A factor change day ?? - Watch out for more changes in the
               period, only take last though and move to eventday */
        factor = Cldr_PlanLookup(factor, float1->stepfac, &date, &ixf) ;

        /* 3.9 A spread change day ?? - Watch out for more changes in the
               period, only take last though and move to eventday */
        spread = Cldr_PlanLookup(spread, float1->stepspr, &date, &ixs) ;
    }

    /* 4.0 Clean up and free memory */
    Free_DATEARRAY(compdays) ;
    Free_DATEARRAY(events) ;

    return pfcoupon ;
}


/*,,SOH,,
*************************************************************************
*
*              SwapFl_DF2Spread()
*
*    interface #include <swapval.h>
*              BOOLE SwapFl_DF2Spread(DATESTR       *analys,
*                                     FL64          npv,
*                                     SWAPFLOAT     *sfl,
*                                     DISCFAC       *df_disc,
*                                     DISCFAC       *df_cflw,
*                                     CMCONVADJ     *cmadj,
*                                     HOLI_STR      *holi,
*                                     FL64          *spr) ;
*
*    general   This function calculates the spread implied in the
*              NPV of a floating leg of a swap - given the various
*              conventions for the leg.
*
*    input     DATESTR       *analys Pointer to analysis date, ie the
*                                    day on which npv is quoted.
*
*              FL64          npv     The NPV to solve for by varying
*                                    the spread.
*
*              SWAPFLOAT     *sfl    Floating leg definition
*
*              DISCFAC       *df_disc  Discounting structure setup.
*                                    Used for discounting
*
*              DISCFAC       *df_cflw  Discounting structure setup.
*                                    Used for generating LIBOR payments.
*
*              CMCONVADJ     *cmadj  Data for Convexity Adjusting
*                                    CMT/CMS swaps.
*
*              HOLI_STR      *holi   Business-Day adjustment setup.
*
*    output    FL64          *spr    The spread (in %).
*
*    returns   True if solution found, False if not.
*
*    diagnostics
*
*    see also  SwapFl_GenrCflw()
*              SwapFl_DF2CFSpread()
*
*    wrapper   AP
*
*************************************************************************
,,EOH,,*/


BOOLE SwapFl_DF2Spread(DATESTR* analys,
                          FL64    npv,
                          SWAPFLOAT* sfl,
                          DISCFAC* df_disc,
                          DISCFAC* df_cflw,
                          CMCONVADJ* cmadj,
                          HOLI_STR* holi,
                          FL64*     spr)
{
    BOOLE     ok ;
    CFLW_STR  *cflw ;
    PLAN_STR  *olds ;
    SWAPINT   swap_data ;
    ITERCTRL  ctrl ;
    NR_ERR    err ;

    /* Warning avoidance */
    cflw = NULL;

    Init_ITERCTRL(&ctrl) ;
    ctrl.maxiter = SPREAD_MAXIT ;
    ctrl.init_guess = SPREAD_GUESS ;
    ctrl.lower = SPREAD_MIN ;
    ctrl.upper = SPREAD_MAX ;
    ctrl.damp = SPREAD_DAMP ;
    ctrl.acc = SPREAD_ACC ;
    ctrl.what_acc = 1 ;
    ctrl.gfreq = SPREAD_FREQ ;
    ctrl.bisec = 2 ;
    ctrl.shock = 0.0 ;

    ok      = True ;

    /* Ignore stepped spreads */
    olds = sfl->float1.stepspr ;
    sfl->float1.stepspr = NULL ;

    swap_data = Swap_SetSWAPINT(analys, npv, NULL, sfl, df_disc, 
      df_cflw, cmadj, holi, cflw, SPREAD_EPS) ;

    err = Newton_Raphson(&Swap_NewtonRaphson, &swap_data, &ctrl, spr, holi) ;  /* PMSTA-22396 - SRIDHARA � 160502 */
    ok = (err == NR_ROOT_FOUND ? True : False) ;

    sfl->float1.stepspr      = olds ;
    sfl->float1.fbase.spread = *spr ;

    return ok ;
}




/*
..Returned is annual rate + ConvAdj is annual spread
..order == 0 -> No Adjustment
  order == 1 -> backward compatible (original adjustment)
  order == 2 -> with gradients calculated from periodical rates.
  order == 3 -> higher order (4th) approximation
  order == 4 -> as 3, but with correlation adjustment
*/

FL64 SwapFl_DF2ForwRate(DATESTR*   Lstart,
                            DATESTR*   Lend,
                            DATESTR*   Lpay,    /* Only used if CMADJ_4THCORR */
                            DATESTR*   Dvol,    /* NULL if no adjustment */
                            RATEINDEX* index,
                            BOOLE      backset,
                            DISCFAC*   df_cflw, /* CM */
                            DISCFAC*   df_disc, /* LIBOR - Only used if
                                                   CMADJ_4THCORR */
                            CMCONVADJ* cmadj,   /* NULL if no adjsutment */
                            FL64*      ConvAdj,
							HOLI_STR* holi)
{
    PAYDAYDEF pday ;
    PAYDAYSEQ pseq ;
    HOLI_STR  hol ;   /* PMSTA-23341 - SRIDHARA � 160517 */
    FL64      volT, qb, pv, term, ytm, pmt, T, Z, Q, D, CMT, corr,
              adj, vol, r2, CA, volLIBOR, volCM ;
    IRRCONV   irr ;
    BOOLE     do_simple ;
    PMTFREQ   gfreq, freq ;
    CMADJTYPE order ;
    BOOLE     ok;

    CMT = *ConvAdj = 0.0 ;

    if (GetPlanFill(df_cflw->disc) < 1)
        return 0.0 ;

    volCM = volLIBOR = corr = 0.0 ;
    order = NO_CMADJ ;
    if (cmadj != NULL && Dvol != NULL)
    {
        if (GetPlanFill(cmadj->volCM.vol) > 0)
			volCM = Vol_Interpolation(Dvol, &cmadj->volCM, holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */  /* PMSTA-23341 - SRIDHARA � 160517 */

        if (GetPlanFill(cmadj->volLIBOR.vol) > 0)
            volLIBOR = Vol_Interpolation(Dvol, &cmadj->volLIBOR, holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */  /* PMSTA-23341 - SRIDHARA � 160517 */

        corr  = cmadj->corr ;
        order = cmadj->order ;
    }

    /* Set relevant rates */
    irr   = FRA_RATECONV2IRRCONV(index->LIBORtype) ;
    gfreq = ANNUALLY ;
    do_simple = False ;

    /* Only do simple calc if specified */
    if (index->LIBORtype == PARYIELD || index->LIBORtype == REX)
        do_simple = False ;

    else if (index->LIBORfreq == NO_FREQUENCY && backset == False)
        do_simple = True ;

    else if (backset == True && volCM < COUPON_TOL)
        do_simple = True ;

    else if (irr == DISCOUNT)
        do_simple = True ;

    /* Now calculate simple forward */
    if (do_simple == True)
        return Disc_DF2ForwRate(Lstart, Lend, index->LIBORcal, df_cflw, 
                                irr, gfreq, holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */  /* PMSTA-23341 - SRIDHARA � 160517 */

    freq = (index->LIBORfreq == NO_FREQUENCY ? ANNUALLY : index->LIBORfreq);

    /* Now find the forward starting security's fixed coupon */
    pseq = Set_PAYDAYSEQ(Cflw_MonthsBetweenPayments(freq), MONTHS,
                         NOODD, NOODD, ANCHOR, LAST) ;
    pday = Set_PAYDAYDEF(True, Lstart, NULL, Lend, False, &pseq, 0, NULL) ;

    /* Here we ignore business day adjustments */
	/* PMSTA-23341 - SRIDHARA � 160517 */
    hol = Set_HOLI_STR(NO_BUSADJUST, 0, NULL) ;
    pv   = 100.0 * Disc_Interpolation(Lstart, df_cflw, holi) ;

    /* Find coupon on index security: */
    if (index->LIBORtype == REX)
    {
      ok = Bond_DF2RexYield(Lstart, (INTI) index->LIBORdur, 
                              index->LIBORunit, index->LIBORfreq,
                              index->coupon, index->LIBORcal, 
                              df_cflw, &CMT);
      if (!ok)
        CMT = 0.0;
    }
    else
      CMT = SwapFix_DF2CFrate(&df_cflw->disc->day[0], pv, &pday, 
                            Lstart, index->LIBORcal, df_cflw, &hol) ;  /* PMSTA-23341 - SRIDHARA � 160517 */

    /* Now convexity adjust the CMT rate */
    if (volCM > COUPON_TOL && order != NO_CMADJ)
    {
        qb   = (FL64) disc_set_qbas(freq) ;
        ytm  = CMT / qb ;
        pmt = (index->LIBORtype == REX ? index->coupon : CMT) / qb;

        /* Term is the maturity as number of periods */
        term = Cldr_TermBetweenDates(Lstart, Lend, 1, index->LIBORcal, 
                                      LAST, holi) * qb ;    /* PMSTA-22396 - SRIDHARA � 160502 */  /* PMSTA-23341 - SRIDHARA � 160517 */

        /* Scale the vol to the period from today till start */
        volT = Cldr_TermBetweenDates(&df_cflw->disc->day[0], Lstart,
                                     0, index->LIBORcal, LAST, holi) ;   /* PMSTA-22396 - SRIDHARA � 160502 */  /* PMSTA-23341 - SRIDHARA � 160517 */
        vol  = 0.0001 * SQR(volCM) * volT ;

        if (order == CMADJ_ORIG || order == CMADJ_PRATE)
        {
            /* Find the dollar duration and dollar convexity of the CMT */
            pv = TVM_NPVBondtype(pmt, ytm, term, BULLET, 
                                  SECOND_ORDER, &D, &Q) ;
            if (order == CMADJ_ORIG)
            {
                D = TVM_Risk_Per2Ann(ytm, -D, Q, qb, FIRST_ORDER) ;
                Q = TVM_Risk_Per2Ann(ytm, D, Q, qb, SECOND_ORDER) ;
            }
            else
            {
                D /= - qb ;
                Q /= SQR(qb) ;
            }

            /* Now we are ready to adjust */
            if (fabs(D) > PRICE_TOL)
                *ConvAdj = 0.5 * (Q / D) * vol * CMT * CMT ;
        }
        else if (order == CMADJ_4TH || order == CMADJ_4THCORR)
        {
            /* Do a higher order approximation */

            /* Calculate gradients correctly - faster using closed-forms */
            pv = SwapFl_CM2Price(Lstart, Lend, freq, CMT, CMT, &D, &Q, &T, &Z);

            D *= -CMT ;                                         /* B1 */
            Q *= 0.5 * CMT * CMT ;                              /* B2 */
            T *= CMT * CMT * CMT / (2.0 * 3.0) ;                /* B3 */
            Z *= CMT * CMT * CMT * CMT / (2.0 * 3.0 * 4.0) ;    /* B4 */

            if (fabs(D) > PRICE_TOL)
            {
                r2 = Q / D ;
                CA  = (0.5 + 2.0 * r2 + r2 * r2) * Q ;
                CA += (3.0 + 3.0 * r2) * T + 3.0 * Z ;
                CA *= vol * vol * CMT / D ;
                *ConvAdj = r2 * vol * CMT ;
                *ConvAdj += CA ;
            }

            if (order == CMADJ_4THCORR)
            {
                adj = SwapFl_CorrAdj_ForwRate(Lstart, Lpay, df_disc, volT,
                                              volCM / 100.0, volLIBOR / 100.0,
                                              corr, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */  /* PMSTA-23341 - SRIDHARA � 160517 */
                *ConvAdj = adj * (CMT + *ConvAdj) - CMT ;
            }
        }

        /* Correct adjusted forward Treasury/Swap rate */
        CMT += *ConvAdj ;
    }

    return CMT ;
}


/*,,SOH,,
*************************************************************************
*
*              SwapFl_DF2CFSpread()
*
*    interface #include <swapval.h>
*              FL64 SwapFl_DF2CFSpread(DATESTR    *analys,
*                                      FL64       npvLEG1,
*                                      FL64       npvLEG2,
*                                      PAYDAYDEF  *pdayLEG1,
*                                      DATESTR    *effLEG1,
*                                      CALCONV    calLEG1,
*                                      DISCFAC    *dfLEG2,
*                                      HOLI_STR   *holi) ;
*
*    general   This function finds the implied spread of LEG1 of a
*              basis swap. The legs are assumed to be in the same
*              currency.
*
*              It is assumed that the PV's of LEG1 and 2 have been cal-
*              culated already. The PV of LEG1 is of course without
*              the spread.
*
*              The discounting is performed using the discount factors
*              of LEG2.
*
*              Examples of basis swaps include:
*
*                       LEG1              LEG2
*                       ----------------------
*                       CMT               LIBOR
*                       CMS               LIBOR
*                       FF                LIBOR
*                       PRIME             LIBOR
*                       CMS               CMT
*
*              etc.
*
*              To do the simple formula only standard structures are
*              handled, e.g no compounding, averaging etc.
*
*    input     DATESTR    *analys   Pointer to analysis date, ie the
*                                   day on which npv is quoted.
*
*                                   When npvLEG1 is calculated using
*                                   SwapFl_HWTREE2NPV() then
*
*                                      df->disc->day[0] = analys
*
*              FL64       npvLEG1   The NPV for LEG1 found elsewhere.
*
*              FL64       npvLEG2   The NPV for LEG2 found elsewhere.
*
*              PAYDAYDEF  *pdayLEG1 The conventions needed for payday
*                                   generation for LEG1.
*
*              DATESTR    *effLEG1  The effective date of LEG1.
*
*              CALCONV    calLEG1   Calendar convention for LEG1.
*
*              DISCFAC    *dfLEG2   Discounting structure setup.
*                                   It is assumed that LEG2 DF's are
*                                   used for discounting. This is the
*                                   case in CMT swaps. when LEG2 is
*                                   LIBOR-linked.
*
*              HOLI_STR   *holi     Business-Day adjustment setup.
*
*    output
*
*    returns   The spread in %.
*
*    diagnostics
*
*    see also  SwapFl_GenrCflw()
*              SwapFl_DF2Spread()
*
*************************************************************************
,,EOH,,*/


FL64 SwapFl_DF2CFSpread(DATESTR* analys,
                        FL64       npvLEG1,
                        FL64       npvLEG2,
                        PAYDAYDEF*  pdayLEG1,
                        DATESTR*    effLEG1,
                        CALCONV    calLEG1,
                        DISCFAC*    dfLEG2,
                        HOLI_STR*   holi)
{
    FL64    spr, pv ;
    DATESTR matur ;

    /* Calculate the NPV of the spread */
    pv = npvLEG2 - npvLEG1 ;

    /* Adjust for the fictitious 100 introduced in SwapFix_DF2CFrate */
    matur = Cldr_NextBusinessDate(&pdayLEG1->last, holi) ;
    pv   += 100 * Disc_Interpolation(&matur, dfLEG2, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */

    /* Calculate the spread */
    spr = SwapFix_DF2CFrate(analys, pv, pdayLEG1, effLEG1, calLEG1,
                            dfLEG2, holi) ;

    return spr ;
}


/*,,SOH,,
*************************************************************************
*
*              SwapFl_GenrLIBORsaldo()
*
*    interface #include <swapval.h>
*              FL64 SwapFl_GenrLIBORsaldo(DATESTR   *analys,
*                                         FLOATRATE *frate,
*                                         PAYDAYDEF *pday,
*                                         PLAN_STR  *amort,
*                                         HOLI_STR  *holi,
*                                         PLAN_STR  *index) ;
*
*    general   This function calculates the current coupon saldo for a
*              floating swap leg - for a secondary / seasoned swap.
*
*              The data returned should be filled in the FLOATBASE
*              field coupon1, when doing valuation.
*
*              For vanilla swaps this is straight forward, and the
*              last index fixing is returned.
*
*              However, for average rate or compounded legs the saldo
*              calculation is non-trivial.
*
*              One special case is TAM swaps where the current saldo
*              is published elsewhere, as TAG(m) where m is the number
*              of months passed since last payday. Therefore for TAM
*              and TAG swaps we do not calculate any saldo.
*
*              Also note that the dates in index->day should be
*              the days on which the index is used (NOT the fixing
*              days). Typically the index is effective 2 business days
*              after fixing. Note also that index->f64 holds the
*              actual index values to be used on the corresponding
*              days.
*
*              The relevant days is index->day can be found using
*              SwapFl_GenrLIBORdays().
*
*              Finally beware of what the underlying index is: LIBOR,
*              CMT, CMS, Prime, JJ Kenny, FF etc.
*
*              Note that even though we don't calculate any saldo
*              for neither TAM nor TAG swaps, it is however possible
*              to do so by modifying the frate definition.
*              The TAM and TAG fixings are computed as monthly 
*              compounded T4M fixings. Having the required T4M fixings
*              inserted into index and setting frate->method = FLAT
*              and frate->compfreq = MONTHLY the TAM/TAG fixing
*              will be correctly computed. In turn it is also
*              possible to compute T4M fixings. These are computed
*              as the average of daily TMP (O/N rate) fixings during
*              a month. Having index containing the required TMP
*              fixings, set frate->method = NONE, and 
*              frate->avgfl.avgdur = 1.0, frate->avgfl.avgunit = DAYS,
*              and frate->avgfl.avgmeth = False, the correct
*              T4M fixings will be computed.
*
*    input     DATESTR   *analys The valuation date.
*
*              FLOATRATE *frate  The data needed for coupon calculation
*                                frate->fbase.coupon1 and
*                                frate->index not used.
*
*              PAYDAYDEF *pday   Payday definition of the coupondays
*
*              PLAN_STR  *amort  The amortization schedule with
*                                amort->filled data.
*                                The amortizations corresponding to
*                                amort. Must sum to 100.
*
*              HOLI_STR  *holi   Business-Day adjustment setup.
*
*              PLAN_STR  *index  The index fixing on (at least) the
*                                relevant days. If not all fixings are
*                                available linear interpolation is used.
*                                Note that inputs are on the PAY days
*                                of the leg and NOT on the FIX days.
*
*    output
*
*    returns   The current saldo - to be set in (FLOATBASE).coupon1.
*
*    diagnostics
*
*    see also  SwapFl_GenrCflw()
*
*************************************************************************
,,EOH,,*/


FL64 SwapFl_GenrLIBORsaldo(DATESTR* analys,
                            FLOATRATE* frate,
                            PAYDAYDEF* pday,
                            PLAN_STR*  amort,
                            HOLI_STR*  holi,
                            PLAN_STR*  index)
{
    DATEARRAY pfdays, compdays ;
    PAYDAYSEQ pseq ;
    DATESTR   Lstart, Lend, next, tmp, prev, effective, start ;
    BOOLE     avg ;
    FL64      rsaldo, saldo, coupon, period, factor, spread, avgdur ;
    INTI      nfloat, ixa, ixf, ixs, avgcount, i, ncomp, mfreq, mcomp,
              na, nspr, nfac ;
    CALCONV   cal ;
    TERMUNIT  avgunit ;


    saldo  = 0.0 ;
    rsaldo = 1.0 ;
    spread = frate->fbase.spread ;
    factor = frate->factor ;
    ixs    = ixf = ixa = 0 ;
    effective = frate->fbase.effective ;
    pseq = pday->pseq ;
    cal  = frate->fbase.cal ;
    na   = GetPlanFill(amort) ;
    nspr = GetPlanFill(frate->stepspr) ;
    nfac = GetPlanFill(frate->stepfac) ;
    avgdur = frate->avgfl.avgdur ;
    avgunit = frate->avgfl.avgunit ;
    if (avgunit == YEARS)
    {
      avgdur *= 12.0 ;
      avgunit = MONTHS ;
    }

    /* Averaging ? */
    avg = SwapFl_Is_AVG(frate, &pseq, holi) ;

    /* Compounding ? */
    Cflw_Is_Harmonic(pseq.term, pseq.unit, &mfreq) ;
    mcomp = Cflw_MonthsBetweenPayments(frate->compfreq) ;

    if (mcomp >= mfreq)
        /* Just avoid real compounding */
        frate->method = NONE ;

    /* Find previous/next payday */
    pfdays = Cflw_Paydays(pday, holi, &nfloat) ;
    i = Cldr_FindDateIndex(pfdays, nfloat, analys, 0,
                           SEARCH_BISECTION, NEXTINDEX) - 1 ;
    if (i >= 0)
        prev = pfdays[i] ;
    else
        prev = effective ;

    if (i + 1 < nfloat)
        next = pfdays[i + 1] ;
    else
        next = pfdays[nfloat - 1] ;

    /* Chk for all the simple cases */
    if (frate->method != FLAT && frate->method != REGCOMPOUND && avg == False)
    {
        Free_DATEARRAY(pfdays) ;

        if (frate->backset == False)
			return Cldr_Plan_Intpol(&prev, index, cal, LINEAR_EXTRAPOL, holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */
        else
        {
            /* Remember any fixing delays */
            tmp = Cldr_TermUnit2Date(&next, -frate->delay.num,
                                     frate->delay.unit, cal, pseq.eom, holi) ;
            if (Cldr_DateLE(&tmp, analys) == True)
				return Cldr_Plan_Intpol(&tmp, index, cal, LINEAR_EXTRAPOL, holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */
            else
                return 0.0 ;
        }
    }

    /* Find compounding days */
    compdays = SwapFl_Genr_Compdays(frate, &pseq, True, holi, pfdays,
                                    nfloat, &ncomp) ;

    /* Initialise spread/factor */
    factor = Cldr_PlanLookup(factor, frate->stepfac, &effective, &ixf) ;
    spread = Cldr_PlanLookup(spread, frate->stepspr, &effective, &ixs) ;

    /* Loop over compounding days */
    for (i = 0; i < ncomp; i++)
    {
        coupon = 0.0 ;
        Lstart = start = compdays[i] ;

        if (Cldr_DateLT(&start, &prev) == True)
            continue ;

        if (Cldr_DateLE(&next, &start) == True || i == ncomp)
            break ;

        Lend = compdays[i + 1] ;

        if (frate->backset == True)
            start = Cldr_TermUnit2Date(&Lend, -frate->delay.num,
                                       frate->delay.unit, cal, pseq.eom, holi) ;
        if (Cldr_DateLT(analys, &start) == True)
            break ;

        if (avg == True)
        {
            /* Backsetting not allowed */
            avgcount = 0 ;
            tmp      = start ;

            while (Cldr_DateLE(&tmp, analys) == True)
            {
                avgcount += 1 ;
                coupon   += Cldr_Plan_Intpol(&tmp, index, cal, 
                                             LINEAR_EXTRAPOL, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */

                /* Chaining ? */
                tmp = Cldr_Term2Date(&tmp, avgdur, avgunit, cal, pseq.eom) ;
                tmp = Cldr_NextBusinessDate(&tmp, holi) ;
            }

            if (avgcount != 0)
                coupon /= (FL64) avgcount ;
            else
                coupon = 0.0 ;
        }
        else
        {
            if (frate->backset == False)
                coupon = Cldr_Plan_Intpol(&start, index, cal, LINEAR_EXTRAPOL, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
            else
                coupon = Cldr_Plan_Intpol(&start, index, cal, LINEAR_EXTRAPOL, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
        }

        coupon *= factor ;
        period  = Cldr_TermBetweenDates(&Lstart, &Lend, 0, cal, pseq.eom, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */

        switch (frate->method)
        {
            case NONE:
                /* Only when averaging */
                saldo += coupon ;
                break ;

            case REGCOMPOUND:
                saldo = SwapFl_Genr_Regcompound(rsaldo, saldo, period,
                                                coupon, spread) ;
                break ;

            case FLAT:
                saldo = SwapFl_Genr_Flat(rsaldo, saldo, period,
                                         coupon, spread) ;
                break ;

            case TAM:
                /* Should NOT occur */
                break ;

            default:
                ;
        }

        /* A factor change day ?? */
        factor = Cldr_PlanLookup(factor, frate->stepfac, &start, &ixf) ;

        /* A spread change day ?? */
        spread = Cldr_PlanLookup(spread, frate->stepspr, &start, &ixs) ;

        /* Amortisations - only on pay/compound days ! */
        while (ixa < na &&
               Cldr_DateLE(&amort->day[ixa], &start) == True)
            rsaldo -= amort->f64[ixa++] / 100.0 ;
    }

    Free_DATEARRAY(compdays) ;
    Free_DATEARRAY(pfdays) ;

    return saldo ;
}


/*,,SOH,,
*************************************************************************
*
*              SwapFl_GenrLIBORdays()
*
*    interface #include <swapval.h>
*              DATEARRAY SwapFl_GenrLIBORdays(DATESTR   *analys,
*                                              FLOATRATE *frate,
*                                              PAYDAYDEF *pday,
*                                              HOLI_STR  *holi,
*                                              INTI      *ndays) ;
*
*    general   This function calculates the LIBOR fixing days that are
*              relevant for finding the PV for a secondary / seasoned
*              floating swap leg.
*
*              For vanilla swaps this is straight forward, and the
*              last index fixing date is returned.
*
*              However, for average rate or compounded legs the
*              routine returns the fixing days encountered so far.
*
*              One special case is TAM swaps where the current saldo
*              is published elsewhere, as TAG(m) where m is the number
*              of months passed since last payday. In this case the
*              previous payday is returned.
*
*              The days returned here, are the days where the LIBOR is
*              effective (used), and not the fixing dates. Typically
*              the fixing days are 2-3 days before the paydays.
*
*              The actual saldo can be calculated after calling this
*              routine using: SwapFl_GenrLIBORsaldo().
*
*    input     DATESTR   *analys The valuation date.
*
*              FLOATRATE *frate  The data needed for coupon calculation
*
*              PAYDAYDEF *pday   Payday definition of the coupondays
*
*              HOLI_STR  *holi   Business-Day adjustment setup.
*
*    output    INTI      *ndays  The number of historical fixing days.
*
*    returns   The list of fixing days allocated as:
*              Alloc_DATEARRAY(nx), where nx is sufficiently large.
*
*    diagnostics
*
*    see also  SwapFl_GenrCflw()
*
*************************************************************************
,,EOH,,*/


DATEARRAY SwapFl_GenrLIBORdays(DATESTR* analys,
                           FLOATRATE* frate,
                           PAYDAYDEF* pday,
                           HOLI_STR*  holi,
                           INTI*      ndays,
                           INDEXCONV  iConv)    /*  FPL-PMSTA00211-100825   */
{
    DATEARRAY compdays, pfdays, Ldays ;
    DATESTR   next, tmp, prev, effective ;
    PAYDAYSEQ pseq ;
    CALCONV   cal ;
    INTI      ix, ncomp, nfloat, i, j, mfreq, mcomp, fd ;
    BOOLE     avg ;
    FL64      avgdur ;
    TERMUNIT  avgunit ;

    effective = frate->fbase.effective ;
    cal       = frate->fbase.cal ;
    pseq      = pday->pseq ;

    avgdur = frate->avgfl.avgdur ;
    avgunit = frate->avgfl.avgunit ;
    if (avgunit == YEARS)
    {
      avgdur *= 12.0 ;
      avgunit = MONTHS ;
    }


    /* Averaging ? */
    avg = SwapFl_Is_AVG(frate, &pseq, holi) ;

    /* Compounding ? */
    Cflw_Is_Harmonic(pseq.term, pseq.unit, &mfreq) ;
    mcomp = Cflw_MonthsBetweenPayments(frate->compfreq) ;

    if (mcomp >= mfreq)
        /* Just avoid real compounding */
        frate->method = NONE ;

    /* Find previous payday */
    pfdays = Cflw_Paydays(pday, holi, &nfloat) ;
    i = Cldr_FindDateIndex(pfdays, nfloat, analys, 0,
                            SEARCH_BISECTION, iConv) - 1 ;  /*  FPL-PMSTA00211-100825 replace NEXTINDEX by iConv    */
    if (i >= 0)
        prev = pfdays[i] ;
    else
        prev = effective ;

    if (i + 1 < nfloat)
        next = pfdays[i + 1] ;
    else
        next = pfdays[nfloat - 1] ;

    /* Chk for all the simple cases */
    if (frate->method != FLAT && frate->method != REGCOMPOUND && avg == False)
    {
        Free_DATEARRAY(pfdays) ;

        *ndays   = 1 ;
        Ldays    = Alloc_DATEARRAY(1) ;

        if (frate->backset == False)
            Ldays[0] = prev ;
        else
        {
            /* Remember any fixing delays */
            tmp = Cldr_TermUnit2Date(&next, -frate->delay.num,
                                     frate->delay.unit, cal, pseq.eom, holi) ;
            if (Cldr_DateLE(&tmp, analys) == True)
                Ldays[0] = tmp ;
            else
                Ldays[0] = prev ;
        }

        return Ldays ;
    }

    /* Averaging or Compounding */
    if (avg == True)
    {
        /* Allocate sufficient memory */
        tmp = Cldr_Term2Date(&prev, avgdur, avgunit,
                             cal, pseq.eom) ;
        fd  = (INTI) Cldr_DaysBetweenDates(&prev, &tmp, cal, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
        fd  = GETMAX(fd, 1) ;

        Ldays = Alloc_DATEARRAY(5 + (mfreq * 32) / fd) ;

        /* Loop to fill in Index Days */
        tmp = prev ;
        i   = 0 ;

        while (Cldr_DateLE(&tmp, analys) == True && nfloat > 0 &&
               Cldr_DateLT(&tmp, &pfdays[nfloat - 1]) == True)
        {
            Ldays[i] = tmp ;

            /* Chaining ? */
            tmp = Cldr_Term2Date(&tmp, avgdur, avgunit, cal, pseq.eom) ;
            tmp = Cldr_NextBusinessDate(&tmp, holi) ;
            i++ ;
        }
    }
    else
    {
        /* Find compounding days */
        compdays = SwapFl_Genr_Compdays(frate, &pseq, True, holi, pfdays,
                                        nfloat, &ncomp) ;
        Ldays = Alloc_DATEARRAY(ncomp) ;

        for (i = j = 0 ; j < ncomp ; j++)
        {
            if (Cldr_DateLT(&compdays[j], &prev) == True)
                continue ;
            else if (Cldr_DateLT(analys, &compdays[j]) == True)
                break ;
            else if (nfloat > 0 &&
                     Cldr_DateLE(&pfdays[nfloat - 1], &compdays[j]) == True)
                break ;

            if (frate->backset == True)
            {
                ix = Cldr_FindDateIndex(pfdays, nfloat, &compdays[j], 0,
                                         SEARCH_BISECTION, SAMEINDEX) ;
                if (ix < nfloat &&
                    Cldr_DateEQ(&compdays[j], &pfdays[ix]) == False)
                    /* Remember fixing delay */
                    Ldays[i++] = Cldr_TermUnit2Date(&compdays[j],
                                                    -frate->delay.num,
                                                    frate->delay.unit, cal,
                                                    pseq.eom, holi) ;
            }
            else
                Ldays[i++] = compdays[j] ;
        }

        Free_DATEARRAY(compdays) ;
    }

    *ndays = i ;

    Free_DATEARRAY(pfdays) ;

    return Ldays ;
}




/*
..Checks if index is similar to underlying payment period
*/

BOOLE SwapFl_Is_Plain(FLOATRATE*  frate,
                         PAYDAYSEQ*  pseq,
                         HOLI_STR*   holi)
{
    BOOLE   plain ;
    FL64    frac, intp , dur ;
    DATESTR date, date1 ;
    INTI    mfreq ;
    TERMUNIT unit ;
    
    dur = frate->index.LIBORdur ;
    unit = frate->index.LIBORunit ;
    if (unit == YEARS)
    {
      dur *= 12.0 ;
      unit = MONTHS ;
    }

    
    plain = Cflw_Is_Harmonic(pseq->term, pseq->unit, &mfreq) ;
    frac  = modf(frate->index.LIBORdur, &intp) ;

    if (fabs(frac) > 0.001 && frate->method == NONE)
        plain = False ;
    else
    {
        /* Chk if frequencies are equal */
        date1 = Cldr_Term2Date(&frate->fbase.effective, dur,
                               unit , frate->fbase.cal, pseq->eom) ;
        date  = Cldr_TermUnit2Date(&frate->fbase.effective, pseq->term, 
                                   pseq->unit, frate->fbase.cal,
                                   pseq->eom, holi) ;

        if (Cldr_DateEQ(&date1, &date) == True && frate->method == NONE)
            plain = True ;
        else
            plain = False ;
    }

    return plain ;
}


/*
..
*/

BOOLE SwapFl_Is_Vanilla(FLOATRATE*  frate,
                           PAYDAYSEQ*  pseq,
                           REPAYMNT*   repay,
                           HOLI_STR*   holi)
{
    /* Redemption schedule */
    if (repay->type != BULLET)
        return False ;

    /* Factor */
    if (fabs(frate->factor - 1.0) > 0.0000000001)
        return False ;

    /* Backset */
    if (frate->backset == True)
        return False ;

    /* Compounding */
    if (frate->method != NONE)
        return False ;

    /* Index */
    if (SwapFl_Is_Plain(frate, pseq, holi) == False)
        return False ;        

    /* Averaging */
    if (SwapFl_Is_AVG(frate, pseq, holi) == True)
        return False ;

    /* Stepped stuff */
    if (GetPlanFill(frate->stepspr) > 0)
        return False ;

    /* Stepped stuff */
    if (GetPlanFill(frate->stepfac) > 0)
        return False ;

    return True ;
}


/*
..
*/

BOOLE SwapFl_Is_AVG(FLOATRATE*  frate, 
                       PAYDAYSEQ*  pseq,
                       HOLI_STR*   holi)
{
    BOOLE   avg ;
    DATESTR date1, date ;
    FL64    avgdur ;
    TERMUNIT avgunit ;

    avgdur = frate->avgfl.avgdur ;
    avgunit = frate->avgfl.avgunit ;
    if (avgunit == YEARS)
    {
      avgdur *= 12.0 ;
      avgunit = MONTHS ;
    }


    /* Averaging ? */
    date1 = Cldr_Term2Date(&frate->fbase.effective, frate->avgfl.avgdur,
                           frate->avgfl.avgunit, frate->fbase.cal, pseq->eom);
    date  = Cldr_TermUnit2Date(&frate->fbase.effective, pseq->term, pseq->unit,
                               frate->fbase.cal, pseq->eom, holi) ;
    if (Cldr_DateLT(&date1, &date) == True && frate->avgfl.avgdur > 0.0001)
        avg = True ;
    else
        avg = False ;

    return avg ;
}


/*
..
*/

FL64 SwapFl_Genr_AVG(DATESTR* analys, 
                         DATESTR* Lstart, 
                         DATESTR* Lend, 
                         DATESTR* end, 
                         DATESTR* Dvol, 
                         FLOATRATE* frate, 
                         DISCFAC* df, 
                         CMCONVADJ* cmadj, 
                         EOMCONV eom, 
                         HOLI_STR* holi, 
                         BOOLE use1)
{
    FL64     n64, t, d, coupon, ca, dur, idur ;
    INTI     num, n, n1, n2, avgcount ;
    DATESTR  prev, next ;
    PERIOD   per ;
    TERMUNIT unit, iunit ;
    CALCONV  calforw ;

    calforw = frate->fbase.cal;
    if (frate->method == TAM)
        calforw = ACT360 ;

    /* Do the averaging in the remainder of the current period */
    avgcount = 0 ;
    coupon   = 0.0 ;
    prev     = *Lstart ;
    next     = *Lend ;

    
    dur = frate->avgfl.avgdur ;
    unit = frate->avgfl.avgunit ;
    if (unit == YEARS)
    {
      dur *= 12.0 ;
      unit = MONTHS ;
    }

    idur = frate->index.LIBORdur ;
    iunit = frate->index.LIBORunit ;
    if (iunit == YEARS)
    {
      idur *= 12.0 ;
      iunit = MONTHS ;
    }

    

    if (frate->avgfl.avgmeth == False)
    {
        /* Here loop over ALL averaging periods */
        while (Cldr_DateLT(&prev, end) == True)
        {
            avgcount++ ;
            if (Cldr_DateLE(&prev, analys) == True && use1 == True)
                coupon = frate->fbase.coupon1 * (FL64) avgcount ;
            else
                /* Only do the Classical Convexity Adjustment */
                coupon += SwapFl_DF2ForwRate(&prev, &next, end, Dvol,
                                             &frate->index, 
                                             frate->backset, df, df,
                                             cmadj, &ca, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */

            /* Here we ignore businessdays !! */
            prev = Cldr_Term2Date(&prev, dur, unit, frate->fbase.cal, eom) ;
            next = Cldr_Term2Date(&prev, idur, iunit, frate->fbase.cal, eom) ;

            /* Safety first */
            if (Cldr_DateLE(&next, &prev) == True)
				next = Cldr_AddDays(&prev, (INTL)1, ACTACT, NULL);  	/* PMSTA-22396 - SRIDHARA � 160502 */
        }

        if (avgcount != 0)
            coupon /= (FL64) avgcount ;
        else
            coupon = 0.0 ;
    }
    else
    {
        /* Number of periods in the period is - be careful about FL64's */
        num  = (frate->avgfl.avgunit == YEARS ? 12 : 1 ) ;
        num *= (INTI) (frate->avgfl.avgdur + COUPON_TOL) ;
        per  = Set_PERIOD(num, unit) ;
        n    = Cldr_PeriodsBetweenDates(&prev, end, &per, calforw, eom, holi) ;

        /* Avoid broken periods so: Fictitious end date is: */
        per  = Set_PERIOD(n, unit) ;
        next = Cldr_AddPeriod(&prev, &per, calforw, eom, holi) ;
        per  = Set_PERIOD(num, unit) ;

        if (use1 == False)
        {
            /* The average over this period is: */
			/* PMSTA-22396 - SRIDHARA � 160502 */
            d = Disc_Interpolation(&next, df, holi) ;
            Disc_forwval(df, &prev, &d, holi) ;
            t = Cldr_TermBetweenDates(&prev, &next, 0, calforw, LAST, holi) ;

            /* Now calculate the coupon */
            if (n > 0 && t > COUPON_TOL && d > COUPON_TOL)
            {
                n64    = (FL64) n ;
                coupon = 100.0 * n64 * (pow(1.0 / d, 1.0 / n64) - 1.0) / t ;
            }
            else
                coupon = 0.0 ;
        }
        else
        {
            /* This is secondaries */
            n1 = Cldr_PeriodsBetweenDates(&prev, analys, &per, calforw,
                                          eom, holi) ;
            n2 = n - n1 ;

            /* The average over this period is: */
			/* PMSTA-22396 - SRIDHARA � 160502 */
            d = Disc_Interpolation(&next, df, holi) ;
            Disc_forwval(df, analys, &d, holi) ;
            t = Cldr_TermBetweenDates(analys, &next, 0, calforw, LAST, holi) ;

            /* Now calculate the average over the last period */
            if (n2 > 0 && t > COUPON_TOL && d > COUPON_TOL)
            {
                n64    = (FL64) n2 ;
                coupon = n64 * (pow(1.0 / d, 1.0 / n64) - 1.0) / t ;
            }
            else
                coupon = 0.0 ;

            /* Remember the original part */
            coupon *= 100.0 * (FL64) n2 ;
            coupon += frate->fbase.coupon1 * (FL64) n1 ;
            coupon /= (FL64) (n1 + n2) ;
        }
    }

    return coupon ;
}


/*
..Note that we use chaining here. Maybe chaining is the thing to do ?
..Awaits clarification (e.g. JJ)
*/

DATEARRAY SwapFl_Genr_Compdays(FLOATRATE* frate, 
                                  PAYDAYSEQ* pseq, 
                                  BOOLE eff,
                                  HOLI_STR* holi, 
                                  DATEARRAY pfdays,
                                  INTI nfloat, 
                                  INTI* n)
{
    INTI      i, mfreq, ncompalloc, mtmp, mcomp, ncomp ;
    BOOLE     comp, not_finished ;
    DATESTR   eff1, date, effective ;
    CALCONV   cal ;
    DATEARRAY compdays ;

    effective = frate->fbase.effective ;
    cal       = frate->fbase.cal ;
    comp      = (frate->method == NONE ? False : True) ;
    mcomp     = Cflw_MonthsBetweenPayments(frate->compfreq) ;
    Cflw_Is_Harmonic(pseq->term, pseq->unit, &mfreq) ;

    if (mcomp >= mfreq)
    {
        comp  = False ;
        mcomp = mfreq ;
    }
    else
    {
        /* Avoid silly situations */
        if (frate->method != FLAT && frate->method != REGCOMPOUND && 
            frate->method != TAM)
            mcomp = mfreq ;
    }

    /* Be careful when effective is in the future */
    if (Cldr_DateLT(&pfdays[0], &effective) == True)
        eff1 = Cldr_AddMonths(&pfdays[0], -mfreq, SAME) ;
    else
        eff1 = effective ;

    /* When allocating compound/coupon-days take care when effective date
       is in the far past */
    mtmp = ((INTI) Cldr_DaysBetweenDates(&eff1, &pfdays[0], cal, holi)) / 30 ;  /* PMSTA-22396 - SRIDHARA � 160502 */
    ncompalloc = nfloat * (1 + mfreq / mcomp) + mtmp + 5 ;

    compdays     = Alloc_DATEARRAY(ncompalloc) ;
    not_finished = True ;
    ncomp        = 0 ;

    if (eff == True)
    {
        compdays[0] = effective ;
        ++ncomp ;
    }

    if (comp == False)
    {
        compdays[ncomp] = pfdays[0] ;
        i = 1 ;
        ++ncomp ;
    }
    else
    {
        compdays[ncomp] = Cldr_AddMonths(&effective, mcomp, pseq->eom) ;
        compdays[ncomp] = Cldr_NextBusinessDate(&compdays[ncomp], holi) ;
        i           = 0 ;
        if (Cldr_DateLT(&pfdays[0], &compdays[ncomp]) == True)
        {
            compdays[ncomp] = pfdays[0] ;
            i = 1 ;
        }
        ++ncomp ;
    }

    not_finished = True ;
    if (nfloat == 1 && mcomp >= mfreq)
        not_finished = False ;

    while (not_finished == True)
    {
        if (mcomp == mfreq)
        {
            date = pfdays[i] ;
            i++ ;
        }
        else
        {
            /* Note that this is essentially chaining of compounding days
               maybe this is not strictly OK ?? */
            date = Cldr_AddMonths(&compdays[ncomp - 1], mcomp, pseq->eom) ;
            date = Cldr_NextBusinessDate(&date, holi) ;
            if (Cldr_DateLT(&date, &pfdays[i]) == False)
            {
                date = pfdays[i] ;
                i++ ;
            }
        }

        compdays[ncomp] = date ;
        not_finished = (nfloat <= i ? False : True) ;
        ncomp++ ;
    }

    *n = ncomp ;
    return compdays ;
}


/*
..
*/

FL64 SwapFl_Genr_Regcompound(FL64 rsaldo, FL64 csaldo, FL64 period,
                                FL64 coupon, FL64 spread)
{
    FL64 adj, comp ;

    adj     = 100.0 * rsaldo + csaldo ;
    comp    = (coupon + spread) * period * adj / 100.0 ;
    csaldo += comp ;

    return csaldo ;
}


/*
..
*/

FL64 SwapFl_Genr_Flat(FL64 rsaldo, FL64 csaldo, FL64 period,
                      FL64 coupon, FL64 spread)
{
    FL64 flat, comp, add ;

    flat    = csaldo ;
    comp    = (coupon + spread) * period * rsaldo ;
    add     = coupon * period * flat / 100.0 ;
    csaldo += add + comp ;

    return csaldo ;
}


/*,,SOH,,
*************************************************************************
*
*               SwapFl_VOLBOX2Vol()
*
*    interface  #include <swapval.h>
*               VOL_STR SwapFl_VOLBOX2Vol(DATESTR   *today,
*                                         VOLBOX    *vb,
*                                         SWAPFLOAT *fl,
*                                         DISCFAC   *df,
*                                         HOLI_STR  *holi) ;
*
*    general    The routine computes the volatility to be used in the
*               Convexity Adjustment for floating legs (CMT/CMS).
*
*    input      DATESTR   *today  Pointer to analysis date (NPV date)
*
*               VOLBOX    *vb     The volatility surface.
*
*               SWAPFLOAT *fl     Pointer to float leg data
*
*               DISCFAC   *df     Discount factor setup.
*
*               HOLI_STR  *holi   Businessday adjustment setup
*
*    output
*
*    returns    The volatility (as a percentage).
*
*    diagnostics
*
*    see also   SwapFl_DF2NPV()
*
*************************************************************************
,,EOH,,*/

VOL_STR SwapFl_VOLBOX2Vol(DATESTR*   today, 
                             VOLBOX*    vb, 
                             SWAPFLOAT* fl,
                             DISCFAC*   df, 
                             HOLI_STR*  holi)
{
    VOL_STR     vol ;
    INTI        i, nfix ;
    DATEARRAY   fdays ;
    FL64ARRAY   strikes ;
    PERIOD      dur ;
    DATESTR     tmpday ;
    FL64        v, CA ;

    /* First set Fixing Days */
    fdays = Cflw_Paydays(&fl->pday, holi, &nfix) ;

    /* Set the "swap maturities" and get the strikes */
    dur.num = (INTI) (fl->float1.index.LIBORdur + 0.5) ;
    dur.unit = fl->float1.index.LIBORunit ;
    if (dur.unit == YEARS)
    {
        dur.num  = (INTI) (12.0 * fl->float1.index.LIBORdur) ;
        dur.unit = MONTHS ;
    }

    strikes = Alloc_FL64ARRAY(nfix) ;
    for (i = 0; i < nfix; i++)
    {
        tmpday     = Cldr_TermUnit2Date(&fdays[i], dur.num, dur.unit,
                                        EU30E360, SAME, holi) ;
        strikes[i] = SwapFl_DF2ForwRate(&fdays[i], &tmpday, &tmpday, NULL,
                                        &fl->float1.index, False,
										df, df, NULL, &CA, holi);   /* PMSTA-23341 - SRIDHARA � 160517 */
    }

    /* Allocate for output */
    vol = Set_VOL_STR(NULL, vb->cal, vb->volconv, vb->ipol);
    vol.vol = Alloc_PLANARRAY(1, nfix) ;

    for (i = 0; i < nfix; i++)
    {
        v = Vol_Linear_Lookup(vb, today, &fdays[i],
                              strikes[i], &dur, holi) ;
        Cldr_InsertInPlan(&fdays[i], v, vol.vol, True) ;
    }

    /* Free */
    Free_DATEARRAY(fdays) ;
    Free_FL64ARRAY(strikes) ;

    return vol ;
}



/*,,SOH,,
*************************************************************************
*
*               Free_SWAPFLOAT()
*
*    interface  #include <swapval.h>
*               void Free_SWAPFLOAT(SWAPFLOAT *x) ;
*
*    general    Free_SWAPFLOAT() frees memory for a SWAPFLOAT. All the
*               memory is suballocated in the x structure.
*
*    input      SWAPFLOAT     *x       The floating leg data container.
*
*    output
*
*    returns
*
*    diagnostics
*
*    see also
*
*************************************************************************
,,EOH,,*/

void Free_SWAPFLOAT(SWAPFLOAT* x)
{
    /* Free all suballocated memory */
    Free_PAYDAYDEF(&x->rday);
    Free_PAYDAYDEF(&x->pday);
    Free_PLANARRAY(x->float1.stepspr, 1);
    Free_PLANARRAY(x->float1.stepfac, 1);
    Free_PLANARRAY(x->repay.aufab, 1) ;
    Free_PLANARRAY(x->repay.irreg, 1) ;
    Free_PLANARRAY(x->repay.pp.ppmts, 1) ;
}


/*
..
*/

FL64 SwapFl_CorrAdj_ForwRate(DATESTR* start,
                            DATESTR* pay,
                            DISCFAC* dfLIBOR,
                            FL64    T,
                            FL64    volCM,
                            FL64    volLIBOR,
							FL64    corr,
							HOLI_STR* holi)
{
    FL64 tmp, Lf, Lm, DCL, adj, Pf, Pfd, Pfdd, A, B, C ;

    adj = 1.0 ;

    /* Now calculate the adjustment factor if correlations are handled */
    if (volLIBOR > COUPON_TOL)
    {
		/* PMSTA-22396 - SRIDHARA � 160502 */
        DCL  = Cldr_TermBetweenDates(start, pay, 0, dfLIBOR->cal, LAST, holi) ;
        Lf   = Disc_DF2ForwRate(start, pay, dfLIBOR->cal, dfLIBOR,
                               SIMPLE_MM, ANNUALLY, holi) / 100.0 ;
        Pf   = TVMunit_NPV(DCL, 100.0 * Lf, SIMPLE_MM, 1) ;
        Pfd  = DCL * SQR(Pf) ;
        Pfdd = Pfd * Pf * 2.0 * DCL ;

        /* Solve for Lm - Adjusted mean */
        A = 0.5 * Pfdd * exp(SQR(volLIBOR) * T) ;
        B = -(Pfd + Pfdd * Lf) ;
        C = Pfdd * SQR(Lf) * 0.5 + Pfd * Lf ;

        if (fabs(A) > 0.00001 && fabs(Pf) > 0.00001)
        {
            Lm   = (-B - sqrt(SQR(B) - 4.0 * A * C)) / (2.0 * A) ;
            tmp  = exp(corr * volLIBOR * volCM * T) ;
            adj += Pfd * (Lf - Lm * tmp) / Pf ;
            adj += Pfdd * (SQR(Lf) - 2.0 * Lf * Lm * tmp) / (2.0 * Pf) ;
            adj += Pfdd * SQR(Lm) * exp(SQR(volLIBOR) * T) * SQR(tmp) / 
                                                            (2.0 * Pf) ;
        }
    }

    return adj ;
}


/*,,SOH,,
************************************************************************
*
*                Set_SWAPFLOAT()
*
*   interface    #include <swapval.h>
*                SWAPFLOAT Set_SWAPFLOAT(REPAYMNT*  repay,
*                                        PAYDAYDEF* rday,
*                                        FLOATRATE* fl,
*                                        PAYDAYDEF* pday,
*                                        INTI       delay) ;
*
*   general      This routine sets the members of the struct defined
*                in the function name. The pointer members are simply
*                assigned - without physical copying. The intention
*                of the Set_*() routines is that by using this
*                functionality, one avoids setting individual members
*                of structs in the application code.
*
*                When new members are inserted in structs the Set_*()
*                routine will be changed accordingly.
*
*                For details on the interpretation of the individual
*                struct members please check the struct definition.
*
*   input        REPAYMNT*  repay See general section.
*                                 Use NULL for defaults
*
*                PAYDAYDEF* rday  See general section.
*                                 Use NULL for defaults
*
*                FLOATRATE* fl    See general section.
*
*                PAYDAYDEF* pday  See general section.
*
*                INTI       delay See general section.
*
*   output
*
*   returns      The filled out SWAPFLOAT struct
*
*   diagnostics
*
*   see also     SWAPFLOAT
*
************************************************************************
,,EOH,,*/

SWAPFLOAT Set_SWAPFLOAT(REPAYMNT* repay, 
                           PAYDAYDEF* rday,
                           FLOATRATE* fl, 
                           PAYDAYDEF* pday, 
                           INTI delay)
{
    SWAPFLOAT sfl ;

    if (repay != NULL)
        sfl.repay = *repay ;
    else
        sfl.repay = Set_REPAYMNT(BULLET, NULL, False, 0.0, NULL,
                                 NULL, NULL, 0.0, 0.0) ;

    if (rday != NULL)
        sfl.rday  = *rday ;
    else
        sfl.rday = *pday ;

    sfl.float1 = *fl ;
    sfl.pday   = *pday ;
    sfl.delay  = delay ;

    return sfl ;
}


/*,,SOH,,
************************************************************************
*
*                Set_FLOATRATE()
*
*   interface    #include <swapval.h>
*                FLOATRATE Set_FLOATRATE(FLOATBASE* fbase,
*                                        FL64       factor,
*                                        BOOLE      backset,
*                                        PERIOD*    delay,
*                                        COMPMETHOD method,
*                                        PMTFREQ    compfreq,
*                                        RATEINDEX* index,
*                                        AVGFLOAT*  avgfl,
*                                        PLAN_STR*  stepspr,
*                                        PLAN_STR*  stepfac) ;
*
*   general      This routine sets the members of the struct defined
*                in the function name. The pointer members are simply
*                assigned - without physical copying. The intention
*                of the Set_*() routines is that by using this
*                functionality, one avoids setting individual members
*                of structs in the application code.
*
*                When new members are inserted in structs the Set_*()
*                routine will be changed accordingly.
*
*                For details on the interpretation of the individual
*                struct members please check the struct definition.
*
*   input        FLOATBASE* fbase    See general section.
*                                    Use NULL for dummies
*
*                FL64       factor   See general section.
*
*                BOOLE      backset  See general section.
*
*                PERIOD*    delay    See general section.
*                                    Use NULL for default
*
*                COMPMETHOD method   See general section.
*
*                PMTFREQ    compfreq See general section.
*
*                RATEINDEX* index    See general section.
*                                    Use NULL for dummies
*
*                AVGFLOAT*  avgfl    See general section.
*                                    Use NULL for default
*
*                PLAN_STR*  stepspr  See general section.
*                                    Use NULL for default
*
*                PLAN_STR*  stepfac  See general section.
*                                    Use NULL for default
*
*   output
*
*   returns      The filled out FLOATRATE struct
*
*   diagnostics
*
*   see also     FLOATRATE
*
************************************************************************
,,EOH,,*/

FLOATRATE Set_FLOATRATE(FLOATBASE* fbase,
                               FL64       factor,
                               BOOLE      backset,
                               PERIOD*     delay,
                               COMPMETHOD method,
                               PMTFREQ    compfreq,
                               RATEINDEX*  index,
                               AVGFLOAT*   avgfl,
                               PLAN_STR*   stepspr,
                               PLAN_STR*   stepfac)
{
    FLOATRATE fl ;

    if (fbase != NULL)
        fl.fbase = *fbase;
    else
        fl.fbase = Set_FLOATBASE(0.0, ACT360, NULL, 0.0, False) ;

    fl.factor   = factor ;
    fl.backset  = backset ;

    if (delay != NULL)
        fl.delay = *delay ;
    else
        fl.delay = Set_PERIOD(0, DAYS) ;

    fl.method   = method ;
    fl.compfreq = compfreq ;

    if (index != NULL)
        fl.index = *index ;
    else
        fl.index = Set_RATEINDEX(MMRATE, 6.0, MONTHS, NO_FREQUENCY, 
                         ACT360, 0.0) ;

    if (avgfl != NULL)
        fl.avgfl = *avgfl ;
    else
        fl.avgfl = Set_AVGFLOAT(500.0, YEARS, True) ;

    fl.stepspr  = stepspr ;
    fl.stepfac  = stepfac ;

    return fl ;
}


/*,,SOH,,
************************************************************************
*
*                Set_RATEINDEX()
*
*   interface    #include <swapval.h>
*                RATEINDEX Set_RATEINDEX(RATECONV LIBORtype,
*                                        FL64     LIBORdur,
*                                        TERMUNIT LIBORunit,
*                                        PMTFREQ  LIBORfreq,
*                                        CALCONV  LIBORcal,
*                                        FL64     coupon) ;
*
*   general      This routine sets the members of the struct defined
*                in the function name. The pointer members are simply
*                assigned - without physical copying. The intention
*                of the Set_*() routines is that by using this
*                functionality, one avoids setting individual members
*                of structs in the application code.
*
*                When new members are inserted in structs the Set_*()
*                routine will be changed accordingly.
*
*                For details on the interpretation of the individual
*                struct members please check the struct definition.
*
*   input        RATECONV LIBORtype See general section.
*
*                FL64     LIBORdur  See general section.
*
*                TERMUNIT LIBORunit See general section.
*
*                PMTFREQ  LIBORfreq See general section.
*
*                CALCONV  LIBORcal  See general section.
*
*                FL64     coupon    See general section.
*
*   output
*
*   returns      The filled out RATEINDEX struct
*
*   diagnostics
*
*   see also     RATEINDEX
*
************************************************************************
,,EOH,,*/

RATEINDEX Set_RATEINDEX(RATECONV LIBORtype,
                               FL64     LIBORdur,
                               TERMUNIT LIBORunit,
                               PMTFREQ  LIBORfreq,
                               CALCONV  LIBORcal,
                               FL64     coupon)
{
    RATEINDEX index ;

    index.LIBORtype = LIBORtype ;
    index.LIBORdur  = LIBORdur ;
    index.LIBORunit = LIBORunit ;
    index.LIBORfreq = LIBORfreq ;
    index.LIBORcal  = LIBORcal ;
    index.coupon    = coupon;

    return index ;
}


/*,,SOH,,
************************************************************************
*
*                Set_AVGFLOAT()
*
*   interface    #include <swapval.h>
*                AVGFLOAT Set_AVGFLOAT(FL64     avgdur,
*                                      TERMUNIT avgunit,
*                                      BOOLE    avgmethod) ;
*
*   general      This routine sets the members of the struct defined
*                in the function name. The pointer members are simply
*                assigned - without physical copying. The intention
*                of the Set_*() routines is that by using this
*                functionality, one avoids setting individual members
*                of structs in the application code.
*
*                When new members are inserted in structs the Set_*()
*                routine will be changed accordingly.
*
*                For details on the interpretation of the individual
*                struct members please check the struct definition.
*
*   input        FL64     avgdur    See general section.
*
*                TERMUNIT avgunit   See general section.
*
*                BOOLE    avgmethod See general section.
*
*   output
*
*   returns      The filled out AVGFLOAT struct
*
*   diagnostics
*
*   see also     AVGFLOAT
*
************************************************************************
,,EOH,,*/

AVGFLOAT Set_AVGFLOAT(FL64  avgdur,
                             TERMUNIT avgunit,
                             BOOLE    avgmethod)
{
    AVGFLOAT avg ;

    avg.avgdur    = avgdur ;
    avg.avgunit   = avgunit ;
    avg.avgmeth   = avgmethod ;

    return avg ;
}


/*,,SOH,,
************************************************************************
*
*                Set_FLOATBASE()
*
*   interface    #include <swapval.h>
*                FLOATBASE Set_FLOATBASE(FL64     coupon1,
*                                        CALCONV  cal,
*                                        DATESTR* effective,
*                                        FL64     spread,
*                                        BOOLE    is_fix) ;
*
*   general      This routine sets the members of the struct defined
*                in the function name. The pointer members are simply
*                assigned - without physical copying. The intention
*                of the Set_*() routines is that by using this
*                functionality, one avoids setting individual members
*                of structs in the application code.
*
*                When new members are inserted in structs the Set_*()
*                routine will be changed accordingly.
*
*                For details on the interpretation of the individual
*                struct members please check the struct definition.
*
*   input        FL64     coupon1   See general section.
*
*                CALCONV  cal       See general section.
*
*                DATESTR* effective See general section.
*                                   Use NULL for dummy value
*
*                FL64     spread    See general section.
*
*                BOOLE    is_fix    See general section.
*
*   output
*
*   returns      The filled out FLOATBASE struct
*
*   diagnostics
*
*   see also     FLOATBASE
*
************************************************************************
,,EOH,,*/

FLOATBASE Set_FLOATBASE(FL64 coupon1,
                               CALCONV cal,
                               DATESTR* effective,
                               FL64    spread,
                               BOOLE   is_fix)
{
    FLOATBASE fb;

    fb.coupon1   = coupon1 ;
    fb.cal       = cal ;

    if (effective != NULL)
        fb.effective = *effective ;
    else
        fb.effective = Cldr_YMD2Datestr((YYYYMMDD) 0) ;

    fb.spread    = spread ;
    fb.is_fix    = is_fix ;

    return fb ;
}


/*,,SOH,,
************************************************************************
*
*                Set_CMCONVADJ()
*
*   interface    #include <swapval.h>
*                CMCONVADJ Set_CMCONVADJ(CMADJTYPE order,
*                                        VOL_STR*  volCM,
*                                        VOL_STR*  volLIBOR,
*                                        FL64      corr) ;
*
*   general      This routine sets the members of the struct defined
*                in the function name. The pointer members are simply
*                assigned - without physical copying. The intention
*                of the Set_*() routines is that by using this
*                functionality, one avoids setting individual members
*                of structs in the application code.
*
*                When new members are inserted in structs the Set_*()
*                routine will be changed accordingly.
*
*                For details on the interpretation of the individual
*                struct members please check the struct definition.
*
*   input        CMADJTYPE order    See general section.
*
*                VOL_STR*  volCM    See general section.
*                                   Use NULL if no vol
*
*                VOL_STR*  volLIBOR See general section.
*                                   Use NULL if no vol
*
*                FL64      corr     See general section.
*
*   output
*
*   returns      The filled out CMCONVADJ struct
*
*   diagnostics
*
*   see also     CMCONVADJ
*
************************************************************************
,,EOH,,*/

CMCONVADJ Set_CMCONVADJ(CMADJTYPE order,
                           VOL_STR*  volCM,
                           VOL_STR*  volLIBOR,
                           FL64      corr)
{
    CMCONVADJ cmadj ;

    cmadj.order = order ;

    if (volCM != NULL)
        cmadj.volCM = *volCM ;
    else
        cmadj.volCM.vol = NULL ;

    if (volLIBOR != NULL)
        cmadj.volLIBOR = *volLIBOR ;
    else
        cmadj.volLIBOR.vol = NULL ;

    cmadj.corr = corr ;

    return cmadj ;
}


/*
..CM adjustment stuff
*/

FL64 SwapFl_CM2Price(DATESTR* start,
                     DATESTR* end,
                     PMTFREQ freq,
                     FL64    coupA,
                     FL64    ytmA,
                     FL64*    dp,
                     FL64*    ddp,
                     FL64*    dddp,
                     FL64*    ddddp)
{
    INTI n, i ;
    FL64 tmp, pmt, p, qb, C, y, t ;

    *dp = *ddp = *dddp = *ddddp = 0.0 ;

	n = (INTI)(0.001 + Cldr_TermBetweenDates(start, end, 0, EU30E360, LAST, NULL));  	/* PMSTA-22396 - SRIDHARA � 160502 */
    n *= 12 / Cflw_MonthsBetweenPayments(freq) ;
    qb = 12.0 / (FL64) Cflw_MonthsBetweenPayments(freq) ;
    C  = coupA / qb ;
    y  = ytmA / qb ;

    for (t = p = 0.0, i = 0; i < n; i++)
    {
        t  += 1.0 / qb ;
        pmt = (i == n - 1 ? 100.0 + C : C) ;

        tmp  = pmt * pow(1.0 + ytmA / (100.0 * qb), - qb * t) ;
        p   += tmp ;

        tmp *= - (qb * t) / ((1.0 + 0.01 * y) * qb * 100.0) ;
        *dp += tmp ;

        tmp  *= - (qb * t + 1.0) / ((1.0 + 0.01 * y) * qb * 100.0) ;
        *ddp += tmp ;

        tmp   *= - (qb * t + 2.0) / ((1.0 + 0.01 * y) * qb * 100.0) ;
        *dddp += tmp ;

        tmp    *= - (qb * t + 3.0) / ((1.0 + 0.01 * y) * qb * 100.0) ;
        *ddddp += tmp ;
    }

    return p ;
}


/*,,SOH,,
*************************************************************************
*
*               SwapFl_Simple2SWAPFLOAT()
*
*    interface  #include <swapval.h>
*               SWAPFLOAT SwapFl_Simple2SWAPFLOAT(DATESTR* effect,
*                                                 PERIOD*  tenor,
*                                                 PMTFREQ  freq,
*                                                 FL64     coupon1,
*                                                 FL64     spread,
*                                                 BOOLE    is_fix,
*                                                 CALCONV  cal,
*                                                 EOMCONV  eom) ;
*
*    general    The routine generates a SWAPFLOAT based on simple data.
*
*    input      DATESTR  *effect  The accrual start date
*
*               PERIOD   *tenor   The total swap term (i.e 5Y)
*
*               PMTFREQ  freq     The floating roll (e.g. semiann)
*
*               FL64     coupon1  The first fixing
*
*               FL64     spread   The spread against the index
*
*               BOOLE    is_fix   Is first payment fixed ?
*
*               CALCONV  cal      The daycount method
*
*               EOMCONV  eom      Month end adjustment
*
*    output
*
*    returns    The SWAPFLOAT data type
*
*    diagnostics
*
*    see also
*
*************************************************************************
,,EOH,,*/

SWAPFLOAT SwapFl_Simple2SWAPFLOAT(DATESTR* effect,
                                     PERIOD*  tenor,
                                     PMTFREQ  freq,
                                     FL64     coupon1,
                                     FL64     spread,
                                     BOOLE    is_fix,
                                     CALCONV  cal,
                                     EOMCONV  eom)
{
    SWAPFLOAT sfl ;
    PAYDAYDEF pday ;
    PAYDAYSEQ pseq ;
    FLOATRATE fl ;
    INTI      mon ;
    HOLI_STR  holi ;
    FLOATBASE fb ;
    RATEINDEX index ;
    DATESTR   matur ;

    holi  = Set_HOLI_STR(NO_BUSADJUST, 0, NULL) ;
    mon   = Cflw_MonthsBetweenPayments(freq) ;
    matur = Cldr_AddPeriod(effect, tenor, cal, eom, &holi) ;
    pseq  = Set_PAYDAYSEQ(mon, MONTHS, NOODD,  NOODD, ANCHOR, eom) ;
    pday  = Set_PAYDAYDEF(False, effect, NULL, &matur, False, &pseq,
                          0, NULL) ;
    fb    = Set_FLOATBASE(coupon1, cal, effect, spread, is_fix) ;
    index = Set_RATEINDEX(MMRATE, (FL64) mon, MONTHS, NO_FREQUENCY, cal, 0.0) ;
    fl    = Set_FLOATRATE(&fb, 1.0, False, NULL, NONE, NO_FREQUENCY,
                          &index, NULL, NULL, NULL) ;
    sfl   = Set_SWAPFLOAT(NULL, NULL, &fl, &pday, 0) ;

    return sfl ;
}


#undef SPREAD_FREQ
#undef SPREAD_DAMP
#undef SPREAD_ACC
#undef SPREAD_GUESS
#undef SPREAD_MAX
#undef SPREAD_MIN
#undef SPREAD_EPS
#undef SPREAD_MAXIT
#undef COUPON_TOL
#undef PRICE_TOL

/* SCID @(#)tstswap1.c	1.5 (SimCorp) 99/02/19 14:14:06 */

/************************************************************************
*
*   Project     SCecon
*
************************************************************************/

/*** includes ***********************************************************/
#include <string.h>
#include <futio.h>
#include <swapval.h>


int test_swapfl_DF2price(FILE* in, FILE* out)
{
    char        txpl[90] ;
    INTI        diff ;
    FL64        acc, fexp, fres, fres1, fres2, fexp1, fexp2 ;
    HOLI_STR    holi ;
    DISCFAC     df, dfa ;
    RISKSET     risk;
    SWAPFLOAT   sfl ;
    CMCONVADJ   cmadj ;
    DATESTR     analys ;

    acc = 0.00001 ;

    fscanf(in, "%s %lf %lf %lf", txpl, &fexp, &fexp1, &fexp2) ;

    sfl   = Read_SWAPFLOAT(in, out) ;
    df    = Read_DISCFAC(in, out) ;
    dfa   = Read_DISCFAC(in, out) ;
    cmadj = Read_CMCONVADJ(in, out) ;

    holi = Read_HOLI_STR(in, out) ;
    risk = Read_RISKSET(in, out) ;

    if (GetPlanFill(dfa.disc) > 0)
        analys = dfa.disc->day[0] ;
    else
        analys = Cldr_YMD2Datestr((YYYYMMDD) 19900101) ;

    fres = SwapFl_DF2NPV(&analys, &sfl,
                         &df, &dfa, &cmadj, &holi, &risk, &fres1, &fres2) ;

    diff = (fabs(fexp  - fres)   > acc) ||
           (fabs(fexp1 - fres1) > acc) ||
           (fabs(fexp2 - fres2) > acc) ;

    fprintf(out, "%d;  expected NPV is %9.5lf  result is %9.5lf\n",
            fabs(fexp  - fres) > acc, fexp, fres) ;
    fprintf(out, "%d;  expected  dp is %9.5lf  result is %9.5lf\n",
            fabs(fexp1  - fres1) > acc, fexp1, fres1) ;
    fprintf(out, "%d;  expected ddp is %9.5lf  result is %9.5lf\n",
            fabs(fexp2  - fres2) > acc, fexp2, fres2) ;
    fprintf(out,"   %s\n\n", txpl) ;

    /* NULL test */
    fres = SwapFl_DF2NPV(&analys, &sfl,
                         &df, &dfa, NULL, &holi, NULL, &fres1, &fres2) ;

    /* Be careful about freeing */
    Free_PLANARRAY(sfl.repay.irreg, 1) ;
    Free_PLANARRAY(sfl.float1.stepspr, 1) ;
    Free_PLANARRAY(sfl.float1.stepfac, 1) ;
    Free_DATEARRAY(holi.holidays) ;
    Free_PLANARRAY(df.disc, 1) ;
    Free_PLANARRAY(dfa.disc, 1) ;
    Free_PLANARRAY(cmadj.volCM.vol, 1) ;
    Free_PLANARRAY(cmadj.volLIBOR.vol, 1) ;

    return diff ;
}


/*
..
*/


int test_swapfl_genr_cflw(FILE* in, FILE* out)
{
    char        txb[25], txc[25], txd[25], txe[25], txm[25], txpl[90],
                txf[25], txh[25], txi[25], txj[25], txk[25], txl[25],
                txn[25], txo[25], txp[25], txq[25], txr[25], txs[25] ;
    INTI        dexp, i, ns, nf, diff, dif1, delay, na,
                nholi, nd, nfloat ;
    FL64        r1, r2, *amort, *fixcoupon, *fixamort,
                acc, spread, coupon1, factor, dur, avgdur,
                *aspr, *afac, vol ;
    PLANARRAY   disc ;
    PLAN_STR    plans, planf ;
    EOMCONV     eom ;
    CALCONV     cal, LIBORcal ;
    SEQCONV     per ;
    BUSCONV     bus ;
    BONDTYPE    type ;
    BOOLE       backset, io, init_exch, avgm ;
    DISCIPOL    ipol ;
    YYYYMMDD    effect, first, matur, ymd ;
    DATESTR     analys, dzero, day, deffect, dfirst, dmatur ;
    DATESTR     *fixdays, *holidays, *amortdays, *sprdays, *facdays ;
    PMTFREQ     compfreq, freq ;
    TERMUNIT    avgunit, unit ;
    COMPMETHOD  method ;
    INTPOLCONV  iconv ;
    int         i1, i2, i3, i4, i5, i6, i7 ;
    HOLI_STR    holi ;
    PAYDAYDEF   pday ;
    PLAN_STR    plana ;
    REPAYMNT    redemp ;
    CFLW_STR    *cflw ;
    FLOATRATE   float1 ;
    DISCFAC     df ;
    VOL_STR     CMTvol ;
    SWAPFLOAT   sfl ;
    PERIOD      del ;
    CMCONVADJ   cmadj ;
    RATECONV    rt ;
    FLOATBASE   fb ;
    RATEINDEX   indx ;
    AVGFLOAT    avgf ;

    acc   = 0.00001 ;
    dzero = Cldr_YMD2Datestr((YYYYMMDD) 0) ;

/*..use here Read_SWAPFLOAT(.., type = 3) - has been coded for this version */

    fscanf(in, "%ld %ld %ld %s %s %s %s %lf %s",
           &effect, &first, &matur, txb, txc, txd, txn, &coupon1, txs) ;

    deffect = Cldr_YMD2Datestr(effect) ;
    dfirst = Cldr_YMD2Datestr(first) ;
    dmatur = Cldr_YMD2Datestr(matur) ;

    freq = Str2PMTFREQ(txb) ;
    eom  = Str2EOMCONV(txc) ;
    cal  = Str2CALCONV(txd) ;
    per  = Str2SEQCONV(txn) ;

    pday = cflw_set_payday(&dfirst, &dzero, &dmatur, False,
                           Cflw_MonthsBetweenPayments(freq), MONTHS,
                           NOODD, NOODD, per, eom) ;

    fprintf(out,"   effective day      %8ld\n", effect) ;
    fprintf(out,"   first payday       %8ld\n", first) ;
    fprintf(out,"   maturity           %8ld\n", matur) ;
    fprintf(out,"   pay frequency      %8s\n", txb) ;
    fprintf(out,"   eomconv            %8s\n", txc) ;
    fprintf(out,"   calendar           %8s\n", txd) ;
    fprintf(out,"   per.conv           %8s\n", txn) ;
    fprintf(out,"   first coupon       %3.4lf\n", coupon1) ;
    fprintf(out,"   Is Fix ?           %s\n", txs) ;

    fscanf(in, "%lf %lf %s %d %s %s %s %lf %s %s %lf %lf %s %s",
           &factor, &spread, txi, &i1, txn, txj, txk, &dur, txl, txq, &vol,
           &avgdur, txp, txb) ;

    backset = Str2BOOLE(txi) ;
    del.num = (INTI) i1 ;
    del.unit = Str2TERMUNIT(txn) ;
    method = Str2COMPMETHOD(txj) ;
    compfreq = Str2PMTFREQ(txk) ;
    unit = Str2TERMUNIT(txl) ;
    avgunit = Str2TERMUNIT(txp) ;
    avgm    = Str2BOOLE(txb) ;

    fprintf(out,"   factor             %3.4lf\n", factor) ;
    fprintf(out,"   spread             %3.4lf\n", spread) ;
    fprintf(out,"   backset ??         %8s\n", txi) ;
    fprintf(out,"   Delay Num:         %8d\n", i1) ;
    fprintf(out,"   Delay Unit:        %8s\n", txn) ;
    fprintf(out,"   comp.method        %8s\n", txj) ;
    fprintf(out,"   comp.freq.         %8s\n", txk) ;
    fprintf(out,"   index duration     %3.4lf\n", dur) ;
    fprintf(out,"   index unit         %8s\n", txl) ;
    fprintf(out,"   index freq         %8s\n", txq) ;
    fprintf(out,"   index vol          %3.4lf\n", vol) ;
    fprintf(out,"   avg.  duration     %3.4lf\n", avgdur) ;
    fprintf(out,"   avgunit            %8s\n", txp) ;
    fprintf(out,"   AvgMethod          %8s\n", txb) ;

    fscanf(in, "%d %s %s %s %d %d %d %d %s %s %s %d %d %s",
           &i1, txe, txf, txr, &i2, &i6, &i7, &i3, txm, txo, txh, &i4, &i5,
             txpl) ;

    delay = (INTI) i1 ;
    na = (INTI) i2 ;
    nd = (INTI) i3 ;
    nholi = (INTI) i4 ;
    dexp = (INTI) i5 ;
    ns = (INTI) i6 ;
    nf = (INTI) i7 ;

    init_exch = Str2BOOLE(txe) ;
    io = Str2BOOLE(txf) ;
    type = Str2BONDTYPE(txr) ;
    bus = Str2BUSCONV(txh) ;
    ipol = Str2DISCIPOL(txm) ;
    iconv = Str2INTPOLCONV(txo) ;

    fprintf(out,"   delay              %8d\n", delay) ;
    fprintf(out,"   initial exchange ? %8s\n", txe) ;
    fprintf(out,"   interest only ??   %8s\n", txf) ;
    fprintf(out,"   discount ipol      %8s\n", txm) ;
    fprintf(out,"   intpol             %8s\n", txo) ;
    fprintf(out,"   business day conv  %8s\n", txh) ;
    fprintf(out,"   bondtype           %8s\n", txr) ;

    holidays  = Alloc_DATEARRAY(nholi) ;
    amortdays = Alloc_DATEARRAY(na) ;
    amort     = Alloc_FL64ARRAY(na) ;
    sprdays   = Alloc_DATEARRAY(ns) ;
    aspr      = Alloc_FL64ARRAY(ns) ;
    facdays   = Alloc_DATEARRAY(nf) ;
    afac      = Alloc_FL64ARRAY(nf) ;
    disc      = Alloc_PLANARRAY(1, nd) ;

    fprintf(out,"   the irregular amort schedule is...\n") ;
    fprintf(out,"       date  repayment\n") ;

    for (i = 0 ; i < na ; i++)
    {
        fscanf(in, "%ld %lf", &ymd, &amort[i]) ;
        amortdays[i] = Cldr_YMD2Datestr(ymd) ;
        fprintf(out,"   %8ld %9.5lf\n", ymd, amort[i]) ;
    }

    fprintf(out,"   the spread schedule is...\n") ;
    fprintf(out,"       date  spread\n") ;

    for (i = 0 ; i < ns ; i++)
    {
        fscanf(in, "%ld %lf", &ymd, &aspr[i]) ;
        sprdays[i] = Cldr_YMD2Datestr(ymd) ;
        fprintf(out,"   %8ld %9.5lf\n", ymd, aspr[i]) ;
    }

    fprintf(out,"   the factor schedule is...\n") ;
    fprintf(out,"       date  factor\n") ;

    for (i = 0 ; i < nf ; i++)
    {
        fscanf(in, "%ld %lf", &ymd, &afac[i]) ;
        facdays[i] = Cldr_YMD2Datestr(ymd) ;
        fprintf(out,"   %8ld %9.5lf\n", ymd, afac[i]) ;
    }

    fprintf(out,"   the discount function is...\n") ;
    fprintf(out,"       date  discount factor\n") ;

    for (i = 0 ; i < nd ; i++)
    {
        fscanf(in, "%ld %lf", &ymd, &disc[0].f64[i]) ;
        disc[0].day[i] = Cldr_YMD2Datestr(ymd) ;
        fprintf(out,"   %8ld %9.5lf\n", ymd, disc[0].f64[i]) ;
    }
    disc[0].count = disc[0].filled = nd ;

    fprintf(out,"   the holidays are...\n") ;
    fprintf(out,"   holiday\n") ;
    for (i = 0 ; i < nholi ; i++)
    {
        fscanf(in, "%ld", &ymd) ;
        holidays[i] = Cldr_YMD2Datestr(ymd) ;
        fprintf(out,"   %8ld\n", ymd) ;
    }

    holi = Set_HOLI_STR(bus, nholi, holidays) ;
    rt = (Str2PMTFREQ(txq) == NO_FREQUENCY ? MMRATE : PARYIELD) ;
    LIBORcal = (Str2PMTFREQ(txq) == NO_FREQUENCY ? cal : EU30E360) ;
    LIBORcal = (method == TAM ? ACT360 : LIBORcal) ;
    indx = Set_RATEINDEX(rt, dur, unit, Str2PMTFREQ(txq), LIBORcal, 0.0) ;
    avgf = Set_AVGFLOAT(avgdur, avgunit, avgm) ;

    planf.filled     = nf ;
    planf.day        = facdays ;
    planf.f64        = afac ;

    plans.filled     = ns ;
    plans.day        = sprdays ;
    plans.f64        = aspr ;

    fb = Set_FLOATBASE(coupon1, cal, &deffect, spread, Str2BOOLE(txs)) ;
    float1 = Set_FLOATRATE(&fb, factor, backset, &del, method, compfreq,
                           &indx, &avgf, &plans, &planf) ;

    plana.filled = na ;
    plana.f64    = amort ;
    plana.day    = amortdays ;

    r1     = (init_exch == True ? 100.0 : 0.0) ;
    redemp = Set_REPAYMNT(type, NULL, io, r1, NULL, &plana,
                          NULL, 0.0, 0.0) ;
    df     = Set_DISCFAC(disc, ipol, iconv, cal, CONTINUOUS, ANNUALLY) ;

    CMTvol = Set_VOL_STR(NULL, cal, FORWVOL, LINEAR_EXTRAPOL) ;
    CMTvol.vol = Alloc_PLANARRAY(1, 1) ;
    Cldr_InsertInPlan(&deffect, vol, CMTvol.vol, True) ;

    sfl   = Set_SWAPFLOAT(&redemp, &pday, &float1, &pday, delay) ;
    cmadj = Set_CMCONVADJ(CMADJ_ORIG, &CMTvol, NULL, 0.0) ;

    if (GetPlanFill(df.disc) > 0)
        analys = df.disc->day[0] ;
    else
        analys = Cldr_YMD2Datestr((YYYYMMDD) 19900101) ;

    cflw = SwapFl_GenrCflw(&analys, &sfl, &df, NULL, &cmadj, &holi) ;

    nfloat    = cflw->filled ;
    fixamort  = cflw->repay ;
    fixcoupon = cflw->coupon ;
    fixdays   = cflw->days ;

    if (nfloat == dexp)
    {
        diff = 0 ;

        fprintf(out,"   expected                       computed\n") ;
        fprintf(out,
          "       date    coupon    amort        date    coupon     amort \n")
          ;
        for (i = 0 ; i < nfloat ; i++)
        {
            fscanf(in, "%ld %lf %lf", &ymd, &r1, &r2) ;
            day  = Cldr_YMD2Datestr(ymd) ;
            dif1 = ((Cldr_DateEQ(&day, &fixdays[i]) == False) ||
                    (fabs(fixamort[i] - r2) > acc) ||
                    (fabs(fixcoupon[i] - r1) > acc));
            fprintf(out, "%d; %8ld %9.5lf %9.5lf ; %8ld %9.5lf %9.5lf\n",
                    dif1, ymd, r1, r2, Cldr_Datestr2YMD(&fixdays[i]),
                    fixcoupon[i], fixamort[i]) ;
            diff = dif1 || diff ;
        }
    }
    else
    {
        diff = 1 ;
        fprintf(out, 
          "%d; swap_extract_cashflow() = %d payments  expected = %d %s\n",
          
                diff, nfloat, dexp, txpl) ;

        fprintf(out, "   you expected this cash flow containing %d payments\n",
                dexp) ;
        fprintf(out, "        day    coupon   amort\n") ;
        for (i = 0 ; i < dexp ; i++)
        {
            fscanf(in, "%ld %lf %lf", &ymd, &r1, &r2) ;
            fprintf(out,"   %8ld %9.5lf %9.5lf\n", ymd, r1, r2) ;
        }

        fprintf(out, 
          "   but SCecon computed this cash flow containing %d payments\n",
          
                nfloat) ;
        fprintf(out, "        day    coupon   amort\n") ;
        for (i = 0 ; i < nfloat ; i++)
            fprintf(out, "%d; %8ld %9.5lf %9.5lf\n", 1,
                    Cldr_Datestr2YMD(&fixdays[i]),
                    fixcoupon[i], fixamort[i]) ;
    }

    fprintf(out,"   %s\n\n", txpl) ;

    Free_FL64ARRAY(amort) ;
    Free_DATEARRAY(amortdays) ;
    Free_FL64ARRAY(aspr) ;
    Free_DATEARRAY(sprdays) ;
    Free_FL64ARRAY(afac) ;
    Free_DATEARRAY(facdays) ;
    Free_DATEARRAY(holidays) ;

    Free_CFLWARRAY(cflw, 1) ;
    Free_PLANARRAY(disc, 1) ;
    Free_PLANARRAY(CMTvol.vol, 1) ;

    return diff ;
}

/*
..
*/



int test_swapEqty_DF2price(FILE* in, FILE* out)
{
    INTI        diff ;
    FL64        acc, fexp, fres ;
    YYYYMMDD    ymd ;
    DATESTR     analys ;
    DISCFAC     df_d, df_f ;
    HOLI_STR    holi ;
    SWAPFLOAT   sfl ;
    char        txpl[120] ;

    acc = 0.00001 ;

    fscanf(in, "%lf %ld", &fexp, &ymd) ;
    analys = Cldr_YMD2Datestr((YYYYMMDD) ymd) ;

    fprintf(out,"   Analysis Day   %8ld\n", ymd) ;

    sfl = Read_SWAPFLOAT(in, out) ;

    df_f.disc = Read_PLANARRAY(in) ;
    fprintf(out,"   Dividend DF is...\n") ;
    Write_PLANARRAY(out, df_f.disc) ;
    df_f = Set_DISCFAC(df_f.disc, DI_SPOT, LINEAR_EXTRAPOL,
                            EU30E360, CONTINUOUS, ANNUALLY);

    df_d.disc = Read_PLANARRAY(in) ;
    fprintf(out,"   Discounting DF is...\n") ;
    Write_PLANARRAY(out, df_d.disc) ;
    df_d = Set_DISCFAC(df_d.disc, DI_SPOT, LINEAR_EXTRAPOL,
                            EU30E360, CONTINUOUS, ANNUALLY);

    holi = Read_HOLI_STR(in, out) ;

    fres = SwapEqty_DF2NPV(&analys, &sfl, &df_f, &df_d, &holi) ;

    diff = (fabs(fexp  - fres)  > acc) ;

    fprintf(out, "%d;  expected NPV is %9.5lf  result is %9.5lf\n",
            fabs(fexp  - fres) > acc, fexp, fres) ;
    fscanf(in, "%s", txpl) ;
    fprintf(out,"   %s\n\n", txpl) ;

    /* Free all */
    Free_DATEARRAY(holi.holidays) ;
    Free_PLANARRAY(df_d.disc, 1) ;
    Free_PLANARRAY(df_f.disc, 1) ;
    Free_PLANARRAY(sfl.repay.irreg, 1) ;
    Free_PLANARRAY(sfl.repay.aufab, 1) ;
    Free_PLANARRAY(sfl.repay.pp.ppmts, 1) ;
    Free_PLANARRAY(sfl.float1.stepspr, 1) ;
    Free_PLANARRAY(sfl.float1.stepfac, 1) ;

    return diff ;
}

/*
..
*/


int test_swapCmdty_DF2price(FILE* in, FILE* out)
{
    INTI        diff ;
    FL64        acc, fexp, fres ;
    YYYYMMDD    ymd ;
    DATESTR     analys ;
    DISCFAC     df_st, df_d, df_f ;
    HOLI_STR    holi ;
    SWAPFLOAT   sfl ;
    char        txpl[120] ;

    acc = 0.00001 ;

    fscanf(in, "%lf %ld", &fexp, &ymd) ;
    analys = Cldr_YMD2Datestr((YYYYMMDD) ymd) ;

    fprintf(out,"   Analysis Day   %8ld\n", ymd) ;

    sfl = Read_SWAPFLOAT(in, out) ;

    df_f.disc = Read_PLANARRAY(in) ;
    fprintf(out,"   Convenience DF is...\n") ;
    Write_PLANARRAY(out, df_f.disc) ;
    df_f = Set_DISCFAC(df_f.disc, DI_SPOT, LINEAR_EXTRAPOL,
                            EU30E360, CONTINUOUS, ANNUALLY);

    df_st.disc = Read_PLANARRAY(in) ;
    fprintf(out,"   Storage Cost DF is...\n") ;
    Write_PLANARRAY(out, df_st.disc) ;
    df_st = Set_DISCFAC(df_st.disc, DI_SPOT, LINEAR_EXTRAPOL,
                             EU30E360, CONTINUOUS, ANNUALLY);

    df_d.disc = Read_PLANARRAY(in) ;
    fprintf(out,"   Discounting DF is...\n") ;
    Write_PLANARRAY(out, df_d.disc) ;
    df_d = Set_DISCFAC(df_d.disc, DI_SPOT, LINEAR_EXTRAPOL,
                            EU30E360, CONTINUOUS, ANNUALLY);

    holi = Read_HOLI_STR(in, out) ;

    fres = SwapCmdty_DF2NPV(&analys, &sfl, &df_f, &df_st, &df_d, &holi) ;

    diff = (fabs(fexp  - fres)  > acc) ;

    fprintf(out, "%d;  expected NPV is %9.5lf  result is %9.5lf\n",
            fabs(fexp  - fres) > acc, fexp, fres) ;
    fscanf(in, "%s", txpl) ;
    fprintf(out,"   %s\n\n", txpl) ;

    /* Free all */
    Free_DATEARRAY(holi.holidays) ;
    Free_PLANARRAY(df_d.disc, 1) ;
    Free_PLANARRAY(df_f.disc, 1) ;
    Free_PLANARRAY(df_st.disc, 1) ;
    Free_PLANARRAY(sfl.repay.irreg, 1) ;
    Free_PLANARRAY(sfl.repay.aufab, 1) ;
    Free_PLANARRAY(sfl.repay.pp.ppmts, 1) ;
    Free_PLANARRAY(sfl.float1.stepspr, 1) ;
    Free_PLANARRAY(sfl.float1.stepfac, 1) ;

    return diff ;
}

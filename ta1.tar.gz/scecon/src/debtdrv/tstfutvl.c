/* SCID @(#)tstfutvl.c	1.4 (SimCorp) 99/02/19 14:14:01 */

/************************************************************************
*
*   project     SCecon
*
************************************************************************/

/*** includes ***********************************************************/
#include <string.h>

#include <futvl.h>
#include <futio.h>
#include <bondvl.h>
#include <bondio.h>

INTI futvaltest(char* txa, FILE* in, FILE* out)
{
    char        txc[80], txe[80], txpl[80] ;
    INTI        diff ;
    VALIDATE    val, exp_val ;
    DATESTR     date, settle ;
    FRA_STR     fra ;
    REPOBOND    rb ;
    FLOATRATE   fltr ;
    YYYYMMDD    ymd1;
    SWAPFLOAT   swpflt ;
    DATESTR     dummy_date ;
    SWAPFIX     swpfix ;
    FUTBOND     futb ;
    
    date  = dummy_date = Cldr_YMD2Datestr((YYYYMMDD) 0) ;
    diff = -1 ;

    if (!strcmp("Validate_FRA_STR()", txa))
    {
        fscanf(in, "%s %s", txe, txpl) ;

        exp_val = Str2VALIDATE(txe) ;

        fprintf(out, "   \n Testing %s\n", txa) ;
        fprintf(out, "   %s\n", txpl) ;

        fra = Read_FRA_STR(in, out) ;
        val = Validate_FRA_STR(&fra) ;
        VALIDATE2Str(val, txc) ;

        diff = (val == exp_val ? 0 : 1) ;
        fprintf(out,"%d;  Exp %s Res %s\n", diff, txe, txc) ;
    }

    else if (!strcmp("Validate_REPOBOND()", txa))
    {
        fscanf(in, "%s %s", txe, txpl) ;

        exp_val = Str2VALIDATE(txe) ;

        fprintf(out, "   \n Testing %s\n", txa) ;
        fprintf(out, "   %s\n", txpl) ;

        rb      = Read_REPOBOND(in, out) ;
        val     = Validate_REPOBOND(&rb) ;
        VALIDATE2Str(val, txc) ;

        diff = (val == exp_val ? 0 : 1) ;
        fprintf(out,"%d;  Exp %s Res %s\n", diff, txe, txc) ;

        Free_FIXPAY(&rb.bond) ;
    }                              

    else if (!strcmp("Validate_FLOATRATE()", txa))
    {
        fprintf(out, "   \n Testing %s\n", txa) ;

        fscanf(in, "%s", txe) ;
        exp_val = Str2VALIDATE(txe) ;

        IOUtil_ParseLine(in, out);

        fltr = Read_FLOATRATE(in, out) ;

        val  = Validate_FLOATRATE(&fltr) ;
        VALIDATE2Str(val, txc) ;

        diff = (val == exp_val ? 0 : 1) ;
        fprintf(out,"%d;  Exp %s Res %s\n", diff, txe, txc) ;

        Free_PLANARRAY(fltr.stepspr, 1) ;
        Free_PLANARRAY(fltr.stepfac, 1) ;
    }
    else if (!strcmp("Validate_SWAPFLOAT()", txa))
    {
        fscanf(in, "%s %s", txe, txpl) ;

        exp_val = Str2VALIDATE(txe) ;

        fprintf(out, "   \n Testing %s\n", txa) ;
        fprintf(out, "   %s\n", txpl) ;

        swpflt = Read_SWAPFLOAT(in, out) ;

        val = Validate_SWAPFLOAT(&swpflt) ;
        VALIDATE2Str(val, txc) ;

        diff = (val == exp_val ? 0 : 1) ;
        fprintf(out,"%d;  Exp %s Res %s\n", diff, txe, txc) ;

        Free_PLANARRAY(swpflt.repay.pp.ppmts ,1) ;
        Free_PLANARRAY(swpflt.repay.irreg ,1) ;
           Free_PLANARRAY(swpflt.repay.aufab ,1) ;
        Free_PLANARRAY(swpflt.float1.stepspr ,1) ;
        Free_PLANARRAY(swpflt.float1.stepfac ,1) ;
    }


    else if (!strcmp("Validate_SWAPFIX()", txa))
    {
        fscanf(in, "%s %s", txe, txpl) ;

        exp_val = Str2VALIDATE(txe) ;

        fprintf(out, "   \n Testing %s\n", txa) ;
        fprintf(out, "   %s\n", txpl) ;

        swpfix = Read_SWAPFIX(in, out) ;

        val = Validate_SWAPFIX(&swpfix) ;
        VALIDATE2Str(val, txc) ;

        diff = (val == exp_val ? 0 : 1) ;
        fprintf(out,"%d;  Exp %s Res %s\n", diff, txe, txc) ;

        Free_PLANARRAY(swpfix.repay.pp.ppmts ,1) ;
        Free_PLANARRAY(swpfix.repay.irreg ,1) ;
        Free_PLANARRAY(swpfix.repay.aufab ,1) ;
        Free_PLANARRAY(swpfix.fix.stepcoup ,1) ;
    }

    else if (!strcmp("Validate_FUTBOND()", txa))
    {
        fscanf(in, "%s %s", txe, txpl) ;

        exp_val = Str2VALIDATE(txe) ;

        fprintf(out, "   \n Testing %s\n", txa) ;
        fprintf(out, "   %s\n", txpl) ;

        fscanf(in, "%ld", &ymd1) ;
        settle = Cldr_YMD2Datestr(ymd1) ;
        futb = Read_FUTBOND(in, out, &settle) ;

        val = Validate_FUTBOND(&futb) ;
        VALIDATE2Str(val, txc) ;

        diff = (val == exp_val ? 0 : 1) ;
        fprintf(out,"%d;  Exp %s Res %s\n", diff, txe, txc) ;

        Free_FUTBOND(&futb);
    }


    return diff ;
}

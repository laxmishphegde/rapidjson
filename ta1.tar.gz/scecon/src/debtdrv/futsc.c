/* @(#)futsc.c	1.6 (SimCorp) 99/09/29 12:10:53 */

/************************************************************************
*
*   project     SCecon
*
*   filename    scenario.c
*
*   contains    routines in the SCecon Library Scenario module
*
************************************************************************/
/***** list of to do's **************************************************
  TODO: ScenBPV for Fut instruments.
************************************************************************/


/***** includes ********************************************************/
#include <futsc.h>


/*,,SOH,,
*************************************************************************
*
*               SwapFix_DF2ScenBPV()
*
*   interface   #include <futsc.h>
*               FL64ARRAY SwapFix_DF2ScenBPV(DATESTR  *analys,
*                                         DISCFAC    *df,
*                                         FL64       fx_spot,
*                                         SWAPFIX    *sfx,
*                                         HOLI_STR   *holi,
*                                         DELTASET   *ds,
*                                         FXSHOCKSET *fxs);
*
*
*   general     The routine calculates the vector of scenario BPV's for
*               a fixed leg using a list of predefined shocks to the
*               zero coupon curve and a list of predefined FX shocks.
*               Each zero coupon curve shock corresponds to a single
*               FX shock.
*
*               The scenario BPV represents the price differences
*               invoked by the curve shocks between the shocked PV's
*               and the initial PV.
*
*               It is required that the number of zero coupon curve
*               shocks match the number of FX shocks, ie.
*
*                        fxs->nshock == ds->nshock
*
*               However, fxs may be set to NULL, in which case FX
*               shocking is ignored and the scenario BPV are calculated
*               in instrument ccys only. Otherwise BPV's are in
*               domestic (home ccy)
*
*               Scenarios may be used for evaluation of
*               - Randomly chosen curve/fx shocks,
*               - Historical scenarios/simulation,
*               - Expert scenarios,
*               - Worst case analysis, etc.
*
*   input       DATESTR    *analys      The analysis date.
*
*               DISCFAC    *df          Discounting structure setup.
*                                       The initial (unshocked) curve
*                                       should be in df->disc.
*
*               FL64       fx_spot      FX spot rate.
*                                       The initial (unshocked) rate.
*
*               SWAPFIX    *sfx         Fixed leg definition
*
*               HOLI_STR   *holi        Business day adjustment setup.
*
*               DELTASET   *ds          Curve shock definitions.
*
*               FXSHOCKSET *fxs         FX shock definitions.
*
*   output
*
*   returns     The vector of scenario BPV as:
*
*                         Alloc_FL64ARRAY(ds->nshock) ;
*
*   diagnostics
*
*   see also    Disc_ScenarioPrep()
*               Cflw_DF2ScenBPV()
*               Bond_DF2ScenBPV()
*
*************************************************************************
,,EOH,,*/


FL64ARRAY SwapFix_DF2ScenBPV(DATESTR* analys,
                        DISCFAC*    df,
                        FL64       fx_spot,
                        SWAPFIX*    sfx,
                        HOLI_STR*   holi,
                        DELTASET*   ds,
                        FXSHOCKSET* fxs)
{
    CFLW_STR  *cflw ;
    FL64ARRAY dv ;
    HOLI_STR  hol ;

    hol = Set_HOLI_STR(NO_BUSADJUST, 0, NULL) ;

    cflw = SwapFix_GenrCflw(sfx, holi) ;
    dv   = Cflw_DF2ScenBPV(analys, df, fx_spot, cflw, NULL, 
                           holi, NULL, ds, fxs) ;

    /* Free */
    Free_CFLWARRAY(cflw, 1) ;

    return dv ;
}


/*,,SOH,,
*************************************************************************
*
*               FRA_DF2ScenBPV()
*
*   interface   #include <futsc.h>
*               FL64ARRAY FRA_DF2ScenBPV(DATESTR  *analys,
*                                             DISCFAC    *df,
*                                             FL64       fx_spot,
*                                             FRA_STR    *fra,
*                                             HOLI_STR   *holi,
*                                             DELTASET   *ds,
*                                             FXSHOCKSET *fxs);
*
*   general     The routine calculates the vector of scenario BPV's for
*               a FRA using a list of predefined shocks to the
*               zero coupon curve and a list of predefined FX shocks.
*               Each zero coupon curve shock corresponds to a single
*               FX shock.
*
*               The scenario BPV represents the price differences
*               invoked by the curve shocks between the shocked PV's
*               and the initial PV.
*
*               It is required that the number of zero coupon curve
*               shocks match the number of FX shocks, ie.
*
*                        fxs->nshock == ds->nshock
*
*               However, fxs may be set to NULL, in which case FX
*               shocking is ignored and the scenario BPV are calculated
*               in instrument ccys only. Otherwise BPV's are in
*               domestic (home ccy)
*
*               Scenarios may be used for evaluation of
*               - Randomly chosen curve/fx shocks,
*               - Historical scenarios/simulation,
*               - Expert scenarios,
*               - Worst case analysis, etc.
*
*   input       DATESTR    *analys      The analysis date.
*
*               DISCFAC    *df          Discounting structure setup.
*                                       The initial (unshocked) curve
*                                       should be in df->disc.
*
*               FL64       fx_spot      FX spot rate.
*                                       The initial (unshocked) rate.
*
*               FRA_STR    *fra         The FRA definition.
*                                       fra->fra assumed as True.
*
*               HOLI_STR   *holi        Business day adjustment setup.
*
*               DELTASET   *ds          Curve shock definitions.
*
*               FXSHOCKSET *fxs         FX shock definitions.
*
*   output
*
*   returns     The vector of scenario BPV as:
*
*                         Alloc_FL64ARRAY(ds->nshock) ;
*
*   diagnostics
*
*   see also    Disc_ScenarioPrep()
*               FRA_DF2NPV()
*               Cflw_DF2ScenBPV()
*               Bond_DF2ScenBPV()
*
*************************************************************************
,,EOH,,*/

FL64ARRAY FRA_DF2ScenBPV(DATESTR* analys,
                        DISCFAC*    df,
                        FL64       fx_spot,
                        FRA_STR*   fra,
                        HOLI_STR*   holi,
                        DELTASET*   ds,
                        FXSHOCKSET* fxs)
{
    FL64ARRAY dv;
    INTI      size, i;
    FL64      p0, pShock, bpv, dum;

    dv = NULL;

    if (FXSHOCKSET_IsEmpty(fxs))
    {
        dv = FRA_DF2Delta(analys, fra, df, holi, ds);
    }
    else if (ds->nshock == fxs->nshock)
    {
        size = ds->nshock;

        /* The unshocked price */
        p0 = FRA_DF2NPV(analys, fra, df, holi, NULL, &dum, &dum) ;

        dv = FRA_DF2Delta(analys, fra, df, holi, ds);
        for(i = 0; i < size; i++)
        {
            pShock = dv[i] + p0;
            bpv = pShock * fxs->shocked[i] - p0 * fx_spot;
            dv[i] = bpv;
        }
    }

    return dv;
}

/*,,SOH,,
*************************************************************************
*
*               IRF_DF2ScenBPV()
*
*   interface   #include <futsc.h>
*               FL64ARRAY IRF_DF2ScenBPV(DATESTR  *analys,
*                                             DISCFAC    *df,
*                                             FL64       fx_spot,
*                                             FRA_STR    *irf,
*                                             HOLI_STR   *holi,
*                                             DELTASET   *ds,
*                                             FXSHOCKSET *fxs);
*
*   general     The routine calculates the vector of scenario BPV's for
*               an IRF using a list of predefined shocks to the
*               zero coupon curve and a list of predefined FX shocks.
*               Each zero coupon curve shock corresponds to a single
*               FX shock.
*
*               The scenario BPV represents the price differences
*               invoked by the curve shocks between the shocked PV's
*               and the initial PV.
*
*               It is required that the number of zero coupon curve
*               shocks match the number of FX shocks, ie.
*
*                        fxs->nshock == ds->nshock
*
*               However, fxs may be set to NULL, in which case FX
*               shocking is ignored and the scenario BPV are calculated
*               in instrument ccys only. Otherwise BPV's are in
*               domestic (home ccy)
*
*               Scenarios may be used for evaluation of
*               - Randomly chosen curve/fx shocks,
*               - Historical scenarios/simulation,
*               - Expert scenarios,
*               - Worst case analysis, etc.
*
*   input       DATESTR    *analys      The analysis date.
*
*               DISCFAC    *df          Discounting structure setup.
*                                       The initial (unshocked) curve
*                                       should be in df->disc.
*
*               FL64       fx_spot      FX spot rate.
*                                       The initial (unshocked) rate.
*
*               FRA_STR    *irf         The IRF definition.
*                                       IRF->IRF assumed as True.
*
*               HOLI_STR   *holi        Business day adjustment setup.
*
*               DELTASET   *ds          Curve shock definitions.
*
*               FXSHOCKSET *fxs         FX shock definitions.
*
*   output
*
*   returns     The vector of scenario BPV as:
*
*                         Alloc_FL64ARRAY(ds->nshock) ;
*
*   diagnostics
*
*   see also    Disc_ScenarioPrep()
*               IRF_DF2Price()
*               Cflw_DF2ScenBPV()
*               Bond_DF2ScenBPV()
*
*************************************************************************
,,EOH,,*/

FL64ARRAY IRF_DF2ScenBPV(DATESTR* analys,
                        DISCFAC*    df,
                        FL64       fx_spot,
                        FRA_STR*    irf,
                        HOLI_STR*   holi,
                        DELTASET*   ds,
                        FXSHOCKSET* fxs)
{
    FL64ARRAY dv;
    INTI      size, i;
    FL64      p0, pShock, bpv, dum;

    dv = NULL;

    if (FXSHOCKSET_IsEmpty(fxs))
    {
        dv = IRF_DF2Delta(analys, irf, df, holi, ds);
    }
    else if (ds->nshock == fxs->nshock)
    {
        size = ds->nshock;

        /* The unshocked price */
        p0 = IRF_DF2NPV(analys, irf, df, holi, NULL, &dum, &dum) ;

        dv = IRF_DF2Delta(analys, irf, df, holi, ds);
        for(i = 0; i < size; i++)
        {
            pShock = dv[i] + p0;
            bpv = pShock * fxs->shocked[i] - p0 * fx_spot;
            dv[i] = bpv;
        }
    }

    return dv;
}


/*,,SOH,,
*************************************************************************
*
*               RepoBond_DF2ScenBPV()
*
*   interface   #include <futsc.h>
*               FL64ARRAY RepoBond_DF2ScenBPV(DATESTR  *analys,
*                                         DISCFAC    *df,
*                                         FL64       fx_spot,
*                                         REPOBOND    *repo,
*                                         HOLI_STR   *holi,
*                                         DFSPREAD   *dfs,
*                                         DELTASET   *ds,
*                                         FXSHOCKSET *fxs);
*
*   general     The routine calculates the vector of scenario BPV's for
*               a bond repo using a list of predefined shocks to the
*               zero coupon curve and a list of predefined FX shocks.
*               Each zero coupon curve shock corresponds to a single
*               FX shock.
*
*               The scenario BPV represents the price differences
*               invoked by the curve shocks between the shocked PV's
*               and the initial PV.
*
*               It is required that the number of zero coupon curve
*               shocks match the number of FX shocks, ie.
*
*                        fxs->nshock == ds->nshock
*
*               However, fxs may be set to NULL, in which case FX
*               shocking is ignored and the scenario BPV are calculated
*               in instrument ccys only. Otherwise BPV's are in
*               domestic (home ccy)
*
*               Scenarios may be used for evaluation of
*               - Randomly chosen curve/fx shocks,
*               - Historical scenarios/simulation,
*               - Expert scenarios,
*               - Worst case analysis, etc.
*
*   input       DATESTR    *analys      The analysis date.
*
*               DISCFAC    *df          Discounting structure setup.
*                                       The initial (unshocked) curve
*                                       should be in df->disc.
*
*               FL64       fx_spot      FX spot rate.
*                                       The initial (unshocked) rate.
*
*               REPOBOND    *repo        Repo bond contract spec.
*
*               HOLI_STR   *holi        Business day adjustment setup.
*
*               DFSPREAD   *dfs         Spread against the curve.
*
*               DELTASET   *ds          Curve shock definitions.
*
*               FXSHOCKSET *fxs         FX shock definitions.
*
*   output
*
*   returns     The vector of scenario BPV as:
*
*                         Alloc_FL64ARRAY(ds->nshock) ;
*
*   diagnostics
*
*   see also    Disc_ScenarioPrep()
*               Cflw_DF2ScenBPV()
*               RepoCflw_DF2ScenBPV()
*
*************************************************************************
,,EOH,,*/

FL64ARRAY RepoBond_DF2ScenBPV(DATESTR* analys,
                        DISCFAC*    df,
                        FL64       fx_spot,
                        REPOBOND* repo,
                        HOLI_STR*   holi,
                        DFSPREAD*   dfs,
                        DELTASET*   ds,
                        FXSHOCKSET* fxs)
{
    CFLWARRAY   xcflw ;
    FL64ARRAY   dv ;
    DATESTR     sell, buy ;

    /* Adjust for business days */
    sell = repo->sell_date ;
    Cldr_Move2BusinessDays(&repo->sell_date, 1, holi) ;
    buy  = repo->buy_date ;
    Cldr_Move2BusinessDays(&repo->buy_date, 1, holi) ;
    
    /* Generate repo bond cflw */
    xcflw = RepoBond_GenrCflw(repo, holi) ;

    dv = RepoCflw_DF2ScenBPV(analys, df, fx_spot, xcflw, 
      &repo->buy_date, &repo->bond.repay.pp, holi, dfs, ds, fxs);

    /* Clean up */
    repo->sell_date = sell ;
    repo->buy_date = buy ;
    
    /* Free cflw */
    Free_CFLWARRAY(xcflw, 1) ;

    return dv ;
}



/*,,SOH,,
*************************************************************************
*
*               SwapFl_DF2ScenBPV()
*
*   interface   #include <futsc.h>
*               FL64ARRAY SwapFl_DF2ScenBPV(DATESTR  *analys,
*                                         DISCFAC    *df_cflw,
*                                         DISCFAC    *df_disc,
*                                         CMCONVADJ  *cmadj,
*                                         FL64       fx_spot,
*                                         SWAPFLOAT  *sfl,
*                                         HOLI_STR   *holi,
*                                         DELTASET   *ds_cflw,
*                                         DELTASET   *ds_disc,
*                                         FXSHOCKSET *fxs);
*
*   general     The routine calculates the vector of scenario BPV's for
*               a floating leg using a list of predefined shocks to the
*               zero coupon curve and a list of predefined FX shocks.
*               Each zero coupon curve shock corresponds to a single
*               FX shock.
*
*               The scenario BPV represents the price differences
*               invoked by the curve shocks between the shocked PV's
*               and the initial PV.
*
*               It is required that the number of zero coupon curve
*               shocks match the number of FX shocks, ie.
*
*                fxs->nshock == ds_cflw->nshock == ds_disc->nshock
*
*               However, fxs may be set to NULL, in which case FX
*               shocking is ignored and the scenario BPV are calculated
*               in instrument ccys only. Otherwise BPV's are in
*               domestic (home ccy)
*
*               Scenarios may be used for evaluation of
*               - Randomly chosen curve/fx shocks,
*               - Historical scenarios/simulation,
*               - Expert scenarios,
*               - Worst case analysis, etc.
*
*               Refer to SwapFl_DF2NPV() for pricing description.
*
*   input       DATESTR    *analys      The analysis date.
*
*               DISCFAC    *df_cflw     Discounting structure setup.
*                                       Used to generate payments
*                                       The initial (unshocked) curve
*                                       should be in df->cflw.
*
*               DISCFAC    *df_disc     Discounting structure setup.
*                                       Used for discounting
*                                       The initial (unshocked) curve
*                                       should be in df->disc.
*
*               CMCONVADJ  *cmadj       Data for Convexity Adjustment
*                                       Use NULL if no adjustment
*
*               FL64       fx_spot      FX spot rate.
*                                       The initial (unshocked) rate.
*
*               SWAPFLOAT  *sfl         Floating leg definition.
*
*               HOLI_STR   *holi        Business day adjustment setup.
*
*               DELTASET   *ds_cflw     Curve shock definitions for
*                                       the the curve in df_cflw.
*
*               DELTASET   *ds_disc     Curve shock definitions for
*                                       the the curve in df_disc.
*
*               FXSHOCKSET *fxs         FX shock definitions.
*
*   output
*
*   returns     The vector of scenario BPV as:
*
*                         Alloc_FL64ARRAY(ds->nshock) ;
*
*   diagnostics
*
*   see also    Disc_ScenarioPrep()
*               Cflw_DF2ScenBPV()
*               SwapFl_DF2NPV()
*
*************************************************************************
,,EOH,,*/

FL64ARRAY SwapFl_DF2ScenBPV(DATESTR* analys,
                        DISCFAC*    df_cflw,
                        DISCFAC*    df_disc,
                        CMCONVADJ*  cmadj,
                        FL64       fx_spot,
                        SWAPFLOAT*  sfl,
                        HOLI_STR*   holi,
                        DELTASET*   ds_cflw,
                        DELTASET*   ds_disc,
                        FXSHOCKSET* fxs)
{
    INTI      i, fx_size ;
    FL64ARRAY dv ;
    FL64      p0, dum, pShock, bpv ;
    PLANARRAY old_cflw, old_disc ;
    BOOLE noFx;

    dv = NULL;

    if (FXSHOCKSET_IsEmpty(fxs))
    {
      noFx = True;
      fx_size = 0;
    }
    else
    {
      fx_size = fxs->nshock;
      noFx = False;
    }

    if (ds_disc->nshock == ds_cflw->nshock && 
        (noFx || ds_cflw->nshock == fx_size))
    {
        /* Initialise */
        dv        = Alloc_FL64ARRAY(ds_cflw->nshock) ;
        old_cflw  = df_cflw->disc ;
        old_disc  = df_disc->disc ;

        /* The unshocked price */
        p0 = SwapFl_DF2NPV(analys, sfl, df_cflw,
                           df_disc, cmadj, holi, NULL, &dum, &dum);

        for (i = 0; i < ds_cflw->nshock; i++)
        {
            df_cflw->disc = &ds_cflw->shock[i];
            df_disc->disc = &ds_disc->shock[i];

            pShock = SwapFl_DF2NPV(analys, sfl, df_cflw, df_disc, 
                                   cmadj, holi, NULL, &dum, &dum) ;

            if (noFx)
              bpv = pShock - p0;
            else
              bpv = pShock * fxs->shocked[i] - p0 * fx_spot;

            dv[i] = bpv;
        }

        df_disc->disc = old_disc;
        df_cflw->disc = old_cflw;
    }

    return dv ;
}


/*,,SOH,,
*************************************************************************
*
*               FRN_DF2ScenBPV()
*
*   interface   #include <futsc.h>
*               FL64ARRAY FRN_DF2ScenBPV(DATESTR  *analys,
*                                         DISCFAC    *df_cflw,
*                                         DISCFAC    *df_disc,
*                                         CMCONVADJ  *cmadj,
*                                         FL64       fx_spot,
*                                         SWAPFLOAT  *frn,
*                                         HOLI_STR   *holi,
*                                         DELTASET   *ds_cflw,
*                                         DELTASET   *ds_disc,
*                                         FXSHOCKSET *fxs);
*
*   general     The routine calculates the vector of scenario BPV's for
*               a floating rate note using a list of predefined shocks
*               to the zero coupon curve and a list of predefined FX
*               shocks.
*               Each zero coupon curve shock corresponds to a single
*               FX shock.
*
*               The scenario BPV represents the price differences
*               invoked by the curve shocks between the shocked PV's
*               and the initial PV.
*
*               It is required that the number of zero coupon curve
*               shocks match the number of FX shocks, ie.
*
*                fxs->nshock == ds_cflw->nshock == ds_disc->nshock
*
*               However, fxs may be set to NULL, in which case FX
*               shocking is ignored and the scenario BPV are calculated
*               in instrument ccys only. Otherwise BPV's are in
*               domestic (home ccy)
*
*               Scenarios may be used for evaluation of
*               - Randomly chosen curve/fx shocks,
*               - Historical scenarios/simulation,
*               - Expert scenarios,
*               - Worst case analysis, etc.
*
*               Refer to FRN_DF2NPV() for pricing description.
*
*   input       DATESTR    *analys      The analysis date.
*
*               DISCFAC    *df_cflw     Discounting structure setup.
*                                       Used to generate payments
*                                       The initial (unshocked) curve
*                                       should be in df->cflw.
*
*               DISCFAC    *df_disc     Discounting structure setup.
*                                       Used for discounting
*                                       The initial (unshocked) curve
*                                       should be in df->disc.
*
*               CMCONVADJ  *cmadj       Data for Convexity Adjustment
*                                       Use NULL if no adjustment
*
*               FL64       fx_spot      FX spot rate.
*                                       The initial (unshocked) rate.
*
*               SWAPFLOAT  *frn         Floating rate note definition.
*
*               HOLI_STR   *holi        Business day adjustment setup.
*
*               DELTASET   *ds_cflw     Curve shock definitions for
*                                       the the curve in df_cflw.
*
*               DELTASET   *ds_disc     Curve shock definitions for
*                                       the the curve in df_disc.
*
*               FXSHOCKSET *fxs         FX shock definitions.
*
*   output
*
*   returns     The vector of scenario BPV as:
*
*                         Alloc_FL64ARRAY(ds->nshock) ;
*
*   diagnostics
*
*   see also    Disc_ScenarioPrep()
*               SwapFl_DF2ScenBPV()
*
*************************************************************************
,,EOH,,*/

FL64ARRAY FRN_DF2ScenBPV(DATESTR* analys,
                        DISCFAC*    df_cflw,
                        DISCFAC*    df_disc,
                        CMCONVADJ*  cmadj,
                        FL64       fx_spot,
                        SWAPFLOAT*  frn,
                        HOLI_STR*   holi,
                        DELTASET*   ds_cflw,
                        DELTASET*   ds_disc,
                        FXSHOCKSET* fxs)
{
    return SwapFl_DF2ScenBPV(analys, df_cflw, df_disc,
               cmadj, fx_spot, frn, holi, ds_cflw,
               ds_disc, fxs);
}





/*,,SOH,,
*************************************************************************
*
*               FutBond_DF2ScenBPV()
*
*   interface   #include <futsc.h>
*               FL64ARRAY FutBond_DF2ScenBPV(DATESTR       *analys,
*                                            FL64          fx_spot,
*                                            FUTBOND       *futb,
*                                            INTI          noas,
*                                            DFSPREADARRAY dfsarr,
*                                            DISCFAC       *df,
*                                            HOLI_STR      *holi,
*                                            DELTASET      *ds,
*                                            FXSHOCKSET    *fxs) ;
*
*   general     The routine calculates the vector of scenario BPV's for
*               a bond future using a list of predefined
*               shocks to the zero coupon curve and a list of
*               predefined FX shocks.
*               Each zero coupon curve shock corresponds to a single
*               FX shock.
*
*               The scenario BPV represents the price differences
*               invoked by the curve shocks between the shocked PV's
*               and the initial PV.
*
*               It is required that the number of zero coupon curve
*               shocks match the number of FX shocks, ie.
*
*                        fxs->nshock == ds->nshock
*
*               However, fxs may be set to NULL, in which case FX
*               shocking is ignored and fx_spot is used for all PV
*               calculations.
*
*               Scenarios may be used for evaluation of
*               - Randomly chosen curve/fx shocks,
*               - Historical scenarios/simulation,
*               - Expert scenarios,
*               - Worst case analysis, etc.
*
*
*    input      DATESTR       *analys  Pointer to analysis date
*                                      (NPV date).
*
*               FL64          fx_spot  Spot exchange rate. Price in
*                                      domestic currency of foreign
*                                      currency units.
*                                      The initial (unshocked) rate.
*
*               FUTBOND       *futb    Futures contract spec.
*
*               INTI          noas     No. of oas
*
*               DFSPREADARRAY dfsarr   Spreads.
*
*               DISCFAC       *df      Discount factors.
*
*               HOLI_STR      *holi    Holiday adjustment setup
*
*               DELTASET      *ds      Curve shock definitions.
*
*               FXSHOCKSET    *fxs     FX shock definitions.
*
*   output
*
*   returns     The vector of scenario BPV as:
*
*                         Alloc_FL64ARRAY(ds->nshock) ;
*
*   diagnostics
*
*   see also    Disc_ScenarioPrep()
*               FutBond_DF2Price()
*               FutBond_DF2Delta()
*               Bond_DF2ScenBPV()
*
*************************************************************************
,,EOH,,*/

FL64ARRAY FutBond_DF2ScenBPV(DATESTR*       analys,
                                FL64           fx_spot,
                                FUTBOND*       futb,      
                                INTI           noas,       
                                DFSPREADARRAY  dfsarr,   
                                DISCFAC*       df,        
                                HOLI_STR*      holi,      
                                DELTASET*      ds,
                                FXSHOCKSET*    fxs)
{
    FL64ARRAY dv ;
    INTI      size, i, ctd ;
    FL64      p0, pShock, dum, f0, dv0 ;
    TRADEINFO settle ;
    PLANARRAY old ;
    DATESTR   delv ;

    dv = NULL;

    /* No FX shocks */
    if (FXSHOCKSET_IsEmpty(fxs))
        dv = FutBond_DF2Delta(analys, futb, noas, dfsarr, df, holi, ds, 
        &ctd, &delv) ;

    else if (ds->nshock == fxs->nshock)
    {
        size = ds->nshock ;

        /* The unshocked price */
        f0 = FutBond_DF2Price(analys, futb, noas, dfsarr, df, holi, NULL, 
                              &dum, &dum, &ctd, &delv) ;

        p0 = (f0 - futb->futp) * fx_spot ;

		dv0 = Disc_MarginAdjust(futb->margin, p0, analys, &delv, df, holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */

        settle = Set_TRADEINFO(&delv, NULL, NULL, False, 100.0, 100.0, 
                               NULL, NULL) ;
        dv = Bond_DF2Delta(&delv, &settle, &futb->fixp[ctd], df, holi, 
                           &dfsarr[ctd], ds) ;

        old = df->disc ;

        for (i = 0; i < size; i++)
        {
            /* Be careful to handle forwards correctly */
            pShock = (dv[i] + f0 - futb->futp) * fxs->shocked[i] ;

            df->disc = &ds->shock[i] ;
            dv[i] = Disc_MarginAdjust(futb->margin, pShock, analys, 
                                          &delv, df, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */

            dv[i] -= dv0 ;

            /* Adjust for conversion factors */
            if (fabs(futb->cf[ctd]) > 0.000001)     /* Changed for what seems the more logical PMSTA-36650 - 260719 - PMO */
                dv[i] /= futb->cf[ctd] ;
        }

        df->disc = old ;
    }

    return dv ;
}

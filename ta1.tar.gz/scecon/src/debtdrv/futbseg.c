/* SCID @(#)futbseg.c	1.6 (SimCorp) 99/10/19 16:25:55 */

/************************************************************************
*
*       project         SCecon
*
*       file name       futbseg.c
*
*       contains        Bond futures calculations
*
************************************************************************/


/*** includes **********************************************************/
#include <future.h>


/*,,SOH,,
*************************************************************************
*
*               FutBondBM_ConFac()
*
*   interface   #include <future.h>
*               FL64ARRAY FutBondBM_ConFac(FUTBONDBM *fut,
*                                          HOLI_STR  *holi) ;
*
*   general     This function calculates the futures contract conversion*
*               factor. Notice that some defaulting is taking place. 
*               For a more general conversion factor calculation, see
*               FutBond_ConFac()
*
*   input       FUTBONDBM   *fut   The futures contract data
*                                  fut->cf NOT used.
*
*               HOLI_STR    *holi  Holiday setup.
*
*   output
*
*   returns     The conversion factors.
*               Allocated as Alloc_FL64ARRAY(fut->nbond) ;
*
*   diagnostics
*
*   see also    FutBondBM_CCREPO2Impl()
*               FutBond_ConFac()
*
*************************************************************************
,,EOH,,*/


FL64ARRAY FutBondBM_ConFac(FUTBONDBM* fut,
                           HOLI_STR*  holi) 
{
    FL64ARRAY cf ;
    FIXPAY    fixp ;
    DATESTR   settle ;
    PMTFREQ   freq ;
    INTI      i ;

    /* Initialise */
    cf     = Alloc_FL64ARRAY(fut->nbond) ;
    settle = fut->first ;

    for (i = 0; i < fut->nbond; i++)
    {
        fixp = BondBM_BONDBM2FIXPAY(&settle, &fut->bonds[i], ISMA360ANN) ;
        freq = Cflw_Months2PmtFreq(fixp.cday.pseq.term) ;

        cf[i] = FutBond_ConFac(fixp.fix.fix_rate, freq, &fixp.accru.exr, 
                               fixp.fix.cal, fixp.cday.pseq.eom, 
                               fut->bonds[i].stub_front, NULL, 
                               &fixp.cday.last, &fixp.fix.effective,
                               &settle, fut->cntr, fut->cf_yield, holi);

        Free_FIXPAY(&fixp) ;
    }

    return cf ;
}


/*,,SOH,,
*************************************************************************
*
*               FutBondBM_CCREPO2Price()
*
*   interface   #include <future.h>
*               CTDRES FutBondBM_CCREPO2Price(DATESTR   *settle,
*                                             FUTBONDBM *fut,
*                                             FL64ARRAY spot,
*                                             INTI      nspot,
*                                             FL64      repo,
*                                             YTMSEG    repocnv,
*                                             HOLI_STR  *holi) ;
*
*   general     This function calculates the forward bond price using
*               the cost of carry model (CC).
*
*               In addition to the individual forward prices (per bond)
*               the CTD index and the delivery date per bond are
*               returned.
*
*   input       DATESTR   *settle  The contract settle date
*
*               FUTBONDBM *fut     The futures contract data
*
*               FL64ARRAY spot     List of nbond spot prices
*
*               INTI      nspot    # of entries in spot
*
*               FL64      repo     The repo rate
*
*               YTMSEG    repocnv  The repo rate convention (usually
*                                  REPO360 or REPO365).
*
*               HOLI_STR  *holi    Holiday setup.
*
*   output
*
*   returns     A CTDRES struct where the members have been allocated
*               with fut->nbond entries. ok indicates success / failure.*
*               if ok is False no all pointers are set to NULL
*
*   diagnostics
*
*   see also    FutBondBM_CCREPO2Impl()
*
*************************************************************************
,,EOH,,*/


CTDRES FutBondBM_CCREPO2Price(DATESTR* settle, 
                              FUTBONDBM* fut,
                              FL64ARRAY spot,
                              INTI      nspot,
                              FL64      repo,     
                              YTMSEG    repocnv,
                              HOLI_STR* holi)
{
    CTDRES    res ;
    INTI      i, n, ddum ;
    TRADEINFO tr1 ;
    FUTBOND   fut1, fut2 ;
    DISCFAC   df ;
    YTMCONV   ytmc ;
    DFPARMS   dfp ;

    /* Initialise */
    n    = GETMIN(nspot, fut->nbond) ;
    tr1  = bond_set_tradeinfo(settle) ;
    ytmc = BondBM_YTMSEG2YTMCONV(repocnv) ;

    /* Set DF */
    dfp = Set_DFPARMS(DI_SPOT, LINEAR_FLAT_END, ytmc.cal_first,
                      ytmc.irr, ytmc.qb_ytm) ;
	df = Disc_TS2DF(settle, &fut->last, &repo, 1, &dfp, holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */

    /* Set FUTBOND */
    fut1 = FutBondBM_FUTBONDBM2FUTBOND(settle, fut, holi) ;

    /* Allocate outputs */
    res.ndeliv  = n ;
    res.ok      = True ;
    res.fwd_rpo = Alloc_FL64ARRAY(n) ;
    res.deliv   = Alloc_DATEARRAY(n) ;

    /* Loop over bonds to find the forward price / delivery date */
    for (i = 0; i < n; i++)
    {
        /* When finding the delivery date we only need to consider the
           first or last delivery date - due to linearity in term to 
           maturity */
        fut2 = Set_FUTBOND(fut1.ndays, fut1.ddays, 1, &fut1.fixp[i],
                           &fut1.cf[i], 0.0, True, fut1.xdiv3w) ;

        /* Calculate futures price per bond on first / last delivery date */
        res.fwd_rpo[i] = FutBond_CC2Price(&tr1, &fut2, 1, &spot[i], 
                        0, NULL, &df, holi, &ddum, &res.deliv[i]) ;
    }

    /* Find the lowest conversation ratio -> CTD */
    res.CTDix = Scutl_Indexx_FL64(n, res.fwd_rpo, ASCENDING) ;

    /* Clean up + return data */
    Free_PLANARRAY(df.disc, 1) ;
    Free_FUTBOND(&fut1) ;

    return res ;
}


/*,,SOH,,
*************************************************************************
*
*               FutBondBM_CCREPO2Impl()
*
*   interface   #include <future.h>
*               CTDRES FutBondBM_CCREPO2Impl(DATESTR   *settle,
*                                            FL64      fwd,
*                                            FUTBONDBM *fut,
*                                            FL64ARRAY spot,
*                                            INTI      nspot,
*                                            YTMSEG    repocnv,
*                                            HOLI_STR  *holi) ;
*
*   general     This function calculates the implied repo rate
*               implicit in the bond futures price.
*
*               In addition to the individual repo rates (per bond)
*               the CTD index and the delivery date per bond are
*               returned.
*
*   input       DATESTR   *settle  The contract settle date
*
*               FL64      fwd      The futures price
*
*               FUTBONDBM *fut     The futures contract data
*
*               FL64ARRAY spot     List of nbond spot prices
*
*               INTI      nspot    # of entries in spot
*
*               YTMSEG    repocnv  The repo rate convention (usually
*                                  REPO360 or REPO365).
*
*               HOLI_STR  *holi    Holiday setup.
*
*   output
*
*   returns     A CTDRES struct where the members have been allocated
*               with fut->nbond entries. ok indicates success / failure.*
*               if ok is False no all pointers are set to NULL
*
*   diagnostics
*
*   see also    FutBondBM_CCREPO2Price()
*
*************************************************************************
,,EOH,,*/

CTDRES FutBondBM_CCREPO2Impl(DATESTR* settle, 
                             FL64      fwd,
                             FUTBONDBM* fut,
                             FL64ARRAY spot,
                             INTI      nspot,
                             YTMSEG    repocnv,
                             HOLI_STR* holi)
{
    CTDRES    res ;
    INTI      j, i, ix, n, ndays ;
    TRADEINFO tr1 ;
    FL64      mimpl, impl ;
    DATEARRAY ddays ;
    YTMCONV   ytmc ;
    BOOLE     found, ok ;
    ITERCTRL  ictrl ;
    FUTBOND   fut1 ;

    /* warning avoidance */
    ix = 0 ;

    /* Initialise */
    n     = GETMIN(nspot, fut->nbond) ;
    tr1   = bond_set_tradeinfo(settle) ;
    ytmc  = BondBM_YTMSEG2YTMCONV(repocnv) ;
    Init_ITERCTRL(&ictrl) ;

    /* Set FUTBOND */
    fut1 = FutBondBM_FUTBONDBM2FUTBOND(settle, fut, holi) ;

    /* Allocate outputs */
    res.ndeliv  = n ;
    res.fwd_rpo = Alloc_FL64ARRAY(n) ;
    res.deliv   = Alloc_DATEARRAY(n) ;

    /* Loop over bonds to find the forward price / delivery date */
    for (ok = True, i = 0; i < n; i++)
    {
        /* When finding the delivery date we only need to consider the
           first or last delivery date - due to monotoneity in term to 
           maturity */
        tr1.price = spot[i] ;

        ddays = FutBond_Xdiv_Adjust(settle, fut1.ddays, fut1.ndays, 
                                    &fut1.fixp[i], fut1.xdiv3w, holi, &ndays);

        /* Calculate implied repo per bond on first / last delivery date */
        for (found = False, mimpl = 0.0, j = 0; ok == True && j < ndays; j++)
        {
            if (Cldr_DateLT(settle, &ddays[j]) == True)
            {
                ok = FutBond_CC2Impl(&tr1, &ddays[j], fwd, fut1.cf[i], 
                                     &fut1.fixp[i], holi, NULL, NULL, &ytmc, 
                                     &ictrl, KEY_REPO, &impl) ;
                if (j == 0 || impl > mimpl)
                {
                    ix    = j ;
                    mimpl = impl ;
                    found = True ;
                }
            }
            else
                impl = - SCFUTHUGE_VAL ;
        }

        /* Find delivery date */
        if (found == True)
        {
            res.fwd_rpo[i] = mimpl ;
            res.deliv[i]   = ddays[ix] ;
        }
        else
        {
            res.fwd_rpo[i] = - SCFUTHUGE_VAL ;
            res.deliv[i]   = Cldr_YMD2Datestr((YYYYMMDD) 0) ;
        }

        Free_DATEARRAY(ddays) ;
    }

    /* Find the maximal implied repo -> CTD */
    if (ok == True)
    {
        res.CTDix = Scutl_Indexx_FL64(n, res.fwd_rpo, DESCENDING) ;
        res.ok    = True ;
    }
    else
    {
        /* Clean up */
        Free_FL64ARRAY(res.fwd_rpo) ;
        Free_DATEARRAY(res.deliv) ;
        res.CTDix   = NULL ;
        res.fwd_rpo = NULL ;
        res.deliv   = NULL ;
        res.ndeliv = 0 ;
        res.ok     = False ;
    }

    /* Clean up + return data */
    Free_FUTBOND(&fut1) ;

    return res ;
}


/*,,SOH,,
*************************************************************************
*
*               FutBondBM_FUTBONDBM2FUTBOND()
*
*   interface   #include <future.h>
*               FUTBOND FutBondBM_FUTBONDBM2FUTBOND(DATESTR   *settle,
*                                                   FUTBONDBM *fut,
*                                                   HOLI_STR  *holi) ;
*
*   general     This function translates a standardised futures contract*
*               data type (FUTBONDBM) to the general type (FUTBOND).
*
*   input       DATESTR   *settle  The contract settle date
*
*               FUTBONDBM *fut     The futures contract data
*
*               HOLI_STR  *holi    Holiday setup.
*
*   output
*
*   returns     The FUTBONDBM struct. ddays and cf are allocated with
*               ndays / nbond entries
*
*   diagnostics
*
*   see also    FutBondBM_CCREPO2Impl()
*
*************************************************************************
,,EOH,,*/

FUTBOND FutBondBM_FUTBONDBM2FUTBOND(DATESTR* settle,
                                    FUTBONDBM* fut,
                                    HOLI_STR*  holi) 
{
    FUTBOND     fut1 ; 
    INTI        i, ndays ;
    DATEARRAY   ddays ;
    FL64ARRAY   cf ;
    FIXPAYARRAY fixp ;
    BOOLE       xdiv3w ;
    HOLI_STR    hol ;

    ddays = Alloc_DATEARRAY(2) ;

    /* Delivery days */
    if (Cldr_DateEQ(&fut->first, &fut->last) == True)
    {
        ndays    = 1 ;
        ddays[0] = Cldr_NextBusinessDate(&fut->first, holi) ;
    }
    else
    {
        ndays    = 2 ;
        hol      = Set_HOLI_STR(NEXTINMONTH, holi->nholi, holi->holidays) ;
        ddays[0] = Cldr_NextBusinessDate(&fut->first, holi) ;
        ddays[1] = Cldr_NextBusinessDate(&fut->last, holi) ;
    }

    /* Calculate Conversion Factors - if required */
    if (fut->do_cf == True)
        cf = FutBondBM_ConFac(fut, holi) ;
    else
    {
        cf = Alloc_FL64ARRAY(fut->nbond) ;
        for (i = 0; i < fut->nbond; i++)
            cf[i] = fut->cf[i] ;
    }

    /* Handle bonds */
    fixp = Alloc_FIXPAYARRAY(fut->nbond) ;
    
    for (i = 0; i < fut->nbond; i++)
        fixp[i] = BondBM_BONDBM2FIXPAY(settle, &fut->bonds[i], ISMA360ANN) ;

    /* Be careful about special 3-week ex-dividend period */
    xdiv3w = (fut->cntr == LIFFE_GILT ? True : False) ;
    fut1   = Set_FUTBOND(ndays, ddays, fut->nbond, fixp, cf, 
                                0.0, True, xdiv3w) ;

    return fut1 ;
}


/*,,SOH,,
*************************************************************************
*
*               Free_FUTBOND()
*
*    interface  #include <future.h>
*               void Free_FUTBOND(FUTBOND *fut) ;
*
*    general    Free_FUTBOND() frees memory for a FUTBOND. All memory
*               is suballocated in the fut structure.
*
*    input      FUTBOND     *fut      The data container
*
*    output
*
*    returns
*
*    diagnostics
*
*    see also
*
*************************************************************************
,,EOH,,*/


void Free_FUTBOND(FUTBOND* fut)
{
    Free_DATEARRAY(fut->ddays) ;
    Free_FIXPAYARRAY(fut->fixp) ;
    Free_FL64ARRAY(fut->cf) ;
}


/*,,SOH,,
*************************************************************************
*
*               Free_FUTBONDBM()
*
*    interface  #include <future.h>
*               void Free_FUTBONDBM(FUTBONDBM *fut) ;
*
*    general    Free_FUTBONDBM() frees memory for a FUTBONDBM. All memory*
*               is suballocated in the fut structure.
*
*    input      FUTBONDBM  *fut      The data container
*
*    output
*
*    returns
*
*    diagnostics
*
*    see also
*
*************************************************************************
,,EOH,,*/


void Free_FUTBONDBM(FUTBONDBM* fut)
{
    Free_FL64ARRAY(fut->cf) ;
    Free_BONDBMARRAY(fut->bonds) ;
}


/*,,SOH,,
*************************************************************************
*
*               Free_CTDRES()
*
*    interface  #include <future.h>
*               void Free_CTDRES(CTDRES *res) ;
*
*    general    Free_CTDRES() frees memory for a CTDRES. All memory
*               is suballocated in the res structure.
*
*    input      CTDRES   *res      The data container
*
*    output
*
*    returns
*
*    diagnostics
*
*    see also
*
*************************************************************************
,,EOH,,*/


void Free_CTDRES(CTDRES* res)
{
    Free_FL64ARRAY(res->fwd_rpo) ;
    Free_INTIARRAY(res->CTDix) ;
    Free_DATEARRAY(res->deliv) ;
}

/* SCID @(#)tstfutsc.c	1.4 (SimCorp) 99/02/19 14:13:59 */

/************************************************************************
*
*   Project     SCecon
*
*   this program tests the routines in the scen.fcts module of SCecon
*
************************************************************************/


/*** includes ***********************************************************/
#include <string.h>
#include <stdlib.h>
#include <scalloc.h>

#include <futsc.h>
#include <futio.h>
#include <bondio.h>
#include <ioconv.h>

INTI futscentest(char* txa, FILE* in, FILE* out)
{
    FL64         acc ;
    INTI         diff ;
    PMTFREQ      freq ;
    HOLI_STR     holi ;
    IRRCONV      irr ;
    DELTASET     ds, ds_disc, ds_cflw ;
    SCENARIOLIST scen ;
    DISCFAC      df, df_disc, df_cflw ;
    FL64         fx_spot ;
    FL64ARRAY    shocks, dv, dvexp ;
    INTI         nshock, nshockexp, noas ;
    FXSHOCKSET   fxs ;
    DATESTR      analys ;
    DFSPREAD     dfs;
    BOOLE        dom, ok, okexp ;
    SWAPFIX      sfx;
    FRA_STR      fra, irf;
    REPOBOND     repo;
    CMCONVADJ    cmadj;
    SWAPFLOAT    sfl;
    CCYCODE      ccy;
    FUTBOND      futb ;
    DFSPREADARRAY dfsarr ;

    acc = 0.00001 ;
    diff = -1 ;

    if (!strcmp("SwapFix_DF2ScenBPV()", txa))
    {
        fprintf(out,"   Testing %s\n", txa) ;

        strncpy(ccy, "USD", CCY_LENGTH);
        analys = Read_DATESTR(in, out, "   analys    ");
        fx_spot = Read_FL64(in, out, "Fx Spot   "); 

        df     = Read_DISCFAC(in, out) ;
        sfx    = Read_SWAPFIX(in, out) ;
        holi   = Read_HOLI_STR(in, out) ;
        scen = Read_SCENARIOLIST(in, out) ;

        shocks = Read_FL64ARRAY(in, &nshock);
        Write_FL64ARRAY(out, shocks, nshock);

        irr = Read_IRRCONV(in, out, "  Shock IRR   ");
        freq = Read_PMTFREQ(in, out, "  Shock Freq  ");
        dom = Read_BOOLE(in, out, "   Domestic  ");

        ds = Disc_ScenarioPrep(&df, &scen, &holi, irr, freq, dom) ;

        fxs = FX_ShockPrep(fx_spot, shocks, nshock, &ccy) ;

        dv = SwapFix_DF2ScenBPV(&analys, &df, fx_spot, &sfx, 
          &holi, &ds, &fxs) ;

        ok = True;
        okexp = Read_BOOLE(in, out, "  Exp status ");
        dvexp = Read_FL64ARRAY(in, &nshockexp);
        acc = Read_FL64(in, out, "Tolerance ");

        diff = WriteFL64ARRAYDiff(okexp, dvexp, nshockexp, 
            ok, dv, nshock, out, acc);

        IOUtil_ParseLine(in, out);

        Free_SWAPFIX(&sfx);
        Free_DATEARRAY(holi.holidays) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_DELTASET(&ds) ;
        Free_SCENARIOLIST(&scen) ;
        Free_FL64ARRAY(dv) ;
        Free_FXSHOCKSET(&fxs);
        Free_FL64ARRAY(shocks);
        Free_FL64ARRAY(dvexp);
    }


    else if (!strcmp("FRA_DF2ScenBPV()", txa))
    {
        fprintf(out,"   Testing %s\n", txa) ;

        strncpy(ccy, "USD", CCY_LENGTH);
        analys = Read_DATESTR(in, out, "   analys    ");
        fx_spot = Read_FL64(in, out, "Fx Spot   "); 

        df     = Read_DISCFAC(in, out) ;
        fra    = Read_FRA_STR(in, out) ;
        holi   = Read_HOLI_STR(in, out) ;
        scen = Read_SCENARIOLIST(in, out) ;

        shocks = Read_FL64ARRAY(in, &nshock);
        Write_FL64ARRAY(out, shocks, nshock);

        irr = Read_IRRCONV(in, out, "  Shock IRR   ");
        freq = Read_PMTFREQ(in, out, "  Shock Freq  ");
        dom = Read_BOOLE(in, out, "   Domestic  ");

        ds = Disc_ScenarioPrep(&df, &scen, &holi, irr, freq, dom) ;

        fxs = FX_ShockPrep(fx_spot, shocks, nshock, &ccy) ;

        dv = FRA_DF2ScenBPV(&analys, &df, fx_spot, &fra, 
          &holi, &ds, &fxs) ;

        ok = True;
        okexp = Read_BOOLE(in, out, "  Exp status ");
        dvexp = Read_FL64ARRAY(in, &nshockexp);
        acc = Read_FL64(in, out, "Tolerance ");

        diff = WriteFL64ARRAYDiff(okexp, dvexp, nshockexp, 
            ok, dv, nshock, out, acc);

        IOUtil_ParseLine(in, out);

        Free_DATEARRAY(holi.holidays) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_DELTASET(&ds) ;
        Free_SCENARIOLIST(&scen) ;
        Free_FL64ARRAY(dv) ;
        Free_FXSHOCKSET(&fxs);
        Free_FL64ARRAY(shocks);
        Free_FL64ARRAY(dvexp);
    }


    else if (!strcmp("IRF_DF2ScenBPV()", txa))
    {
        fprintf(out,"   Testing %s\n", txa) ;

        strncpy(ccy, "USD", CCY_LENGTH);
        analys = Read_DATESTR(in, out, "   analys    ");
        fx_spot = Read_FL64(in, out, "Fx Spot   "); 

        df     = Read_DISCFAC(in, out) ;
        irf    = Read_FRA_STR(in, out) ;
        holi   = Read_HOLI_STR(in, out) ;
        scen = Read_SCENARIOLIST(in, out) ;

        shocks = Read_FL64ARRAY(in, &nshock);
        Write_FL64ARRAY(out, shocks, nshock);

        irr = Read_IRRCONV(in, out, "  Shock IRR   ");
        freq = Read_PMTFREQ(in, out, "  Shock Freq  ");
        dom = Read_BOOLE(in, out, "   Domestic  ");

        ds = Disc_ScenarioPrep(&df, &scen, &holi, irr, freq, dom) ;

        fxs = FX_ShockPrep(fx_spot, shocks, nshock, &ccy) ;

        dv = IRF_DF2ScenBPV(&analys, &df, fx_spot, &irf, 
          &holi, &ds, &fxs) ;

        ok = True;
        okexp = Read_BOOLE(in, out, "  Exp status ");
        dvexp = Read_FL64ARRAY(in, &nshockexp);
        acc = Read_FL64(in, out, "Tolerance ");

        diff = WriteFL64ARRAYDiff(okexp, dvexp, nshockexp, 
            ok, dv, nshock, out, acc);

        IOUtil_ParseLine(in, out);

        Free_DATEARRAY(holi.holidays) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_DELTASET(&ds) ;
        Free_SCENARIOLIST(&scen) ;
        Free_FL64ARRAY(dv) ;
        Free_FXSHOCKSET(&fxs);
        Free_FL64ARRAY(shocks);
        Free_FL64ARRAY(dvexp);
    }

    else if (!strcmp("RepoBond_DF2ScenBPV()", txa))
    {
        fprintf(out,"   Testing %s\n", txa) ;

        strncpy(ccy, "USD", CCY_LENGTH);
        analys = Read_DATESTR(in, out, "   analys    ");
        fx_spot = Read_FL64(in, out, "Fx Spot   "); 

        df     = Read_DISCFAC(in, out);
        repo   = Read_REPOBOND(in, out);
        holi   = Read_HOLI_STR(in, out);
        dfs    = Read_DFSPREAD(in, out);
        scen = Read_SCENARIOLIST(in, out);

        shocks = Read_FL64ARRAY(in, &nshock);
        Write_FL64ARRAY(out, shocks, nshock);

        irr = Read_IRRCONV(in, out, "  Shock IRR   ");
        freq = Read_PMTFREQ(in, out, "  Shock Freq  ");
        dom = Read_BOOLE(in, out, "   Domestic  ");

        ds = Disc_ScenarioPrep(&df, &scen, &holi, irr, freq, dom) ;

        fxs = FX_ShockPrep(fx_spot, shocks, nshock, &ccy) ;

        dv = RepoBond_DF2ScenBPV(&analys, &df, fx_spot, &repo, 
          &holi, &dfs, &ds, &fxs) ;

        ok = True;
        okexp = Read_BOOLE(in, out, "  Exp status ");
        dvexp = Read_FL64ARRAY(in, &nshockexp);
        acc = Read_FL64(in, out, "Tolerance ");

        diff = WriteFL64ARRAYDiff(okexp, dvexp, nshockexp, 
            ok, dv, nshock, out, acc);

        IOUtil_ParseLine(in, out);

        Free_REPOBOND(&repo);
        Free_DATEARRAY(holi.holidays) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_DELTASET(&ds) ;
        Free_SCENARIOLIST(&scen) ;
        Free_FL64ARRAY(dv) ;
        Free_FXSHOCKSET(&fxs);
        Free_FL64ARRAY(shocks);
        Free_FL64ARRAY(dvexp);
        Free_DFSPREAD(&dfs) ;
    }

    else if (!strcmp("SwapFl_DF2ScenBPV()", txa) ||
             !strcmp("FRN_DF2ScenBPV()", txa))
    {
        fprintf(out,"   Testing %s\n", txa) ;

        strncpy(ccy, "USD", CCY_LENGTH);
        analys = Read_DATESTR(in, out, "   analys    ");
        fx_spot = Read_FL64(in, out, "Fx Spot   "); 

        sfl = Read_SWAPFLOAT(in, out) ;

        fprintf(out,"   index vol\n") ;
        holi    = Read_HOLI_STR(in, out) ;
        df_cflw = Read_DISCFAC(in, out) ;
        df_disc = Read_DISCFAC(in, out) ;
        cmadj   = Read_CMCONVADJ(in, out);
        scen = Read_SCENARIOLIST(in, out);

        shocks = Read_FL64ARRAY(in, &nshock);
        Write_FL64ARRAY(out, shocks, nshock);

        irr = Read_IRRCONV(in, out, "  Shock IRR   ");
        freq = Read_PMTFREQ(in, out, "  Shock Freq  ");
        dom = Read_BOOLE(in, out, "   Domestic  ");

        ds_cflw = Disc_ScenarioPrep(&df_cflw, &scen, &holi, 
            irr, freq, dom) ;

        ds_disc = Disc_ScenarioPrep(&df_disc, &scen, &holi, 
            irr, freq, dom) ;

        fxs = FX_ShockPrep(fx_spot, shocks, nshock, &ccy) ;

        if (!strcmp("FRN_DF2ScenBPV()", txa))
        {
              /* Try with NULL if fxs->nshock == 0 */
            if (fxs.nshock == 0)
              dv = FRN_DF2ScenBPV(&analys, &df_cflw, &df_disc, 
                  &cmadj, fx_spot, &sfl, &holi, &ds_cflw, &ds_disc, 
                  NULL);
            else
              dv = FRN_DF2ScenBPV(&analys, &df_cflw, &df_disc, 
                  &cmadj, fx_spot, &sfl, &holi, &ds_cflw, &ds_disc, 
                  &fxs);
        }
        else
        {
              /* Try with NULL if fxs->nshock == 0 */
            if (fxs.nshock == 0)
              dv = SwapFl_DF2ScenBPV(&analys, &df_cflw, &df_disc, 
                  &cmadj, fx_spot, &sfl, &holi, &ds_cflw, &ds_disc, 
                  NULL);
            else
              dv = SwapFl_DF2ScenBPV(&analys, &df_cflw, &df_disc, 
                  &cmadj, fx_spot, &sfl, &holi, &ds_cflw, &ds_disc, 
                  &fxs);
        }

        ok = True;
        okexp = Read_BOOLE(in, out, "  Exp status ");
        dvexp = Read_FL64ARRAY(in, &nshockexp);
        acc = Read_FL64(in, out, "Tolerance ");

        nshock = ds_cflw.nshock;
        diff = WriteFL64ARRAYDiff(okexp, dvexp, nshockexp, 
            ok, dv, nshock, out, acc);

        IOUtil_ParseLine(in, out);

        Free_SWAPFLOAT(&sfl);
        Free_DATEARRAY(holi.holidays) ;
        Free_PLANARRAY(cmadj.volCM.vol, 1) ;
        Free_PLANARRAY(cmadj.volLIBOR.vol, 1) ;
        Free_PLANARRAY(df_disc.disc, 1) ;
        Free_PLANARRAY(df_cflw.disc, 1) ;
        Free_DELTASET(&ds_disc) ;
        Free_DELTASET(&ds_cflw) ;
        Free_SCENARIOLIST(&scen) ;
        Free_FL64ARRAY(dv) ;
        Free_FXSHOCKSET(&fxs);
        Free_FL64ARRAY(shocks);
        Free_FL64ARRAY(dvexp);
    }



    else if (!strcmp("FutBond_DF2ScenBPV()", txa))
    {
        fprintf(out,"   Testing %s\n", txa) ;

        /* Read data */
        analys  = Read_DATESTR(in, out, "   analys    ") ;
        fx_spot = Read_FL64(in, out, "   Fx Spot   ") ; 
        futb    = Read_FUTBOND(in, out, &analys) ;
        dfsarr  = Read_DFSPREADARRAY(in, out, &noas) ;
        df      = Read_DISCFAC(in, out) ;
        holi    = Read_HOLI_STR(in, out) ;

        /* Curve shocks */
        scen    = Read_SCENARIOLIST(in, out) ;

        /* FX shocks */
        shocks = Read_FL64ARRAY(in, &nshock) ;
        Write_FL64ARRAY(out, shocks, nshock) ;

        irr  = Read_IRRCONV(in, out, "  Shock IRR    ") ;
        freq = Read_PMTFREQ(in, out, "  Shock Freq   ") ;
        dom  = Read_BOOLE(in, out, "  Domestic     ") ;

        /* Initialise */
        ds    = Disc_ScenarioPrep(&df, &scen, &holi, irr, freq, dom) ;
        strncpy(ccy, "USD", CCY_LENGTH);
        fxs   = FX_ShockPrep(fx_spot, shocks, nshock, &ccy) ;

        ok = True ;

        /* Try with NULL if fxs->nshock */
        if (fxs.nshock == 0)
            dv = FutBond_DF2ScenBPV(&analys, fx_spot, &futb, noas, dfsarr, &df,
                                    &holi, &ds, NULL) ;
        else
            dv = FutBond_DF2ScenBPV(&analys, fx_spot, &futb, noas, dfsarr, &df,
                                    &holi, &ds, &fxs) ;


        okexp = Read_BOOLE(in, out, "  Exp status ") ;
        dvexp = Read_FL64ARRAY(in, &nshockexp) ;
        acc = Read_FL64(in, out, "Tolerance ") ;

        nshock = ds.nshock;
        diff = WriteFL64ARRAYDiff(okexp, dvexp, nshockexp, ok, dv, nshock, out,
                                  acc) ;

        IOUtil_ParseLine(in, out) ;

        Free_FUTBOND(&futb) ;
        Free_DATEARRAY(holi.holidays) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_DFSPREADARRAY(dfsarr) ;
        Free_DELTASET(&ds) ;
        Free_SCENARIOLIST(&scen) ;
        Free_FL64ARRAY(dv) ;
        Free_FXSHOCKSET(&fxs) ;
        Free_FL64ARRAY(shocks) ;
        Free_FL64ARRAY(dvexp) ;
    }


    return diff ;
}



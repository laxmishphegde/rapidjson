/* SCID @(#)futdisc.c	1.20 (SimCorp) 99/10/19 16:25:55 */

/************************************************************************
*
*       project         SCecon
*
*       file name       futdisc.c
*
*       contains        Bond and Commodity futures calculations
*
************************************************************************/


/*** includes **********************************************************/
#include <future.h>


/*,,SOH,,
*************************************************************************
*
*               FutBond_CC2Price()
*
*   interface   #include <future.h>
*               FL64 FutBond_CC2Price(TRADEINFO   *settle,
*                                     FUTBOND     *futb,
*                                     INTI        nspot,
*                                     FL64ARRAY   spot,
*                                     INTI        noas,
*                                     DFSPREADARRAY dfsarr,
*                                     DISCFAC     *df,
*                                     HOLI_STR    *holi,
*                                     INTI        *ctd,
*                                     DATESTR     *delv) ;
*
*   general     This function calculates the forward bond price using
*               the cost of carry model (CC).
*
*               The function is quite general in taking into account a
*               number of bond curiosities.
*
*               Here the forward price is calculated from the spot price*
*               In FutBond_DF2Price() the term structure of interest
*               rates is used (rather than the spot price).
*
*   input       TRADEINFO   *settle      The contract settle data
*                                        settle->price NOT used
*
*               FUTBOND     *futb        The futures specification.
*
*               INTI        nspot        No. of spot prices and spread,
*                                        must be equal to futb->nbond
*
*               FL64ARRAY   spot         List of spot prices for bonds
*                                        nbond entries
*                                        Dimension [nspot]
*
*               INTI        noas         No. of elements in dfsarr
*
*               DFSPREADARRAY dfsarr     Spreads to df
*                                        Set to NULL if no spread
*                                        Dimension [noas]|NULL
*
*               DISCFAC     *df          Repo Discount Factor curve
*                                        Generate with Disc_TS2DF()
*
*               HOLI_STR    *holi        Holiday setup.
*
*
*   output      INTI        *ctd         The cheapest to deliver bond
*
*               DATESTR     *delv        The delivery date
*
*   returns     The forward price adjusted for conversion factors
*
*   diagnostics
*
*   see also    FutBond_DF2Price()
*               FutBond_YTM2Price()
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/

FL64 FutBond_CC2Price(TRADEINFO*  settle,
                      FUTBOND*        futb,
                      INTI            nspot,
                      FL64ARRAY       spot,
                      INTI            noas,
                      DFSPREADARRAY   dfsarr,
                      DISCFAC*        df,
                      HOLI_STR*       holi,
                      INTI*           ctd,
                      DATESTR*        delv)
{
    INTI      ndays, nb, j, i ;
    FL64      f0, f, dum, scale ;
    CFLWARRAY cflw, xcflw, xcflw1 ;
    HOLI_STR  hol ;
    FIXPAY    *fixp ;
    TRADEINFO end ;
    DFSPREAD  *dfs ;
    EXINF     xinf, dummy ;
    DATEARRAY ddays ;

    /* warning avoidance */
    xcflw = xcflw1 = NULL ;

    *ctd  = 0 ;
    *delv = Cldr_YMD2Datestr((YYYYMMDD) 0) ;

    if (GetPlanFill(df->disc) < 1)
        return 0.0 ;

    end.brd = False ;
    end.price = 0.0 ;
    end.xctrade.spec = False ;
    end.xptrade.spec = False ;

    nb = GETMIN(nspot, futb->nbond) ;

    for (f = SCFUTHUGE_VAL, i = 0; i < nb; i++)
    {
        /* Generate the original flow for this bond */
        fixp = &futb->fixp[i] ;
        hol  = bond_set_holi(holi, &fixp->fix) ;
        cflw = Cflw_GenrCflw(&fixp->repay, &fixp->rday,
                              &futb->fixp[i].fix, &fixp->cday, &hol) ;

        if (fixp->repay.type != BULLET)
        {
            end.settle  = fixp->cday.last ;
            settle->nom = 100.0 ;

            xcflw1 = Cflw_ExtractPeriod(settle, &end, &fixp->fix,
                                        &fixp->cday.pseq, &fixp->accru,
                                        &fixp->exp, &hol, True, cflw,
                                        &fixp->repay.pp, fixp->repay.aufab,
                                        &dummy) ;
        }

        /* Find adjusted delivery days */
        ddays = FutBond_Xdiv_Adjust(&settle->settle, futb->ddays, futb->ndays, 
                                    fixp, futb->xdiv3w, holi, &ndays) ;

        for (j = 0; j < ndays; j++)
        {
            /* Do a Cost of Carry for this bond on this delivery date */
            if (Cldr_DateLT(&settle->settle, &ddays[j]) == False)
                 continue ;

            /* The current PV */
			f0 = spot[i] * Disc_Interpolation(&settle->settle, df, holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */

            /* Extract the specific period flow */
            end.settle  = ddays[j] ;
            settle->nom = 100.0 ;
            xcflw = Cflw_ExtractPeriod(settle, &end, &fixp->fix,
                                       &fixp->cday.pseq, &fixp->accru,
                                       &fixp->exp, &hol, True, cflw,
                                       &fixp->repay.pp, fixp->repay.aufab,
                                       &xinf) ;

            /* Tax adjust */
            Bond_TaxAdjCflw(xcflw, &fixp->tax, &fixp->fix.effective,
                            &fixp->cday.last) ;

            /* Find the PV of the period flow - incl AI's */
            dfs = (noas != 0 ? &dfsarr[i] : NULL) ;
            f0 -= RepoCflw_DF2Price(&settle->settle, df, xcflw, 
                                    &ddays[j], &fixp->repay.pp, 
                                    holi, dfs, NULL, &dum, &dum) ;

            /* Find the notional at maturity */
            if (fixp->repay.type != BULLET)
            {
                scale = Cflw_DebtPerDate(&ddays[j], xcflw1->filled, 
                                         xcflw1->days, xcflw1->repay, 
                                         xinf.exp_end, 0) / 100.0 ; 
                f0 = SafeDivide(f0, scale, 0.0001, 1.0) ;
            }

            /* Discount till maturity */
			Disc_forwval(df, &ddays[j], &f0, holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */

            /* Adjust for conversion factors */
            if (fabs(futb->cf[i]) > 0.000001)
                f0 /= futb->cf[i] ;

            /* 3.6 Compare and update CTD */
            if (f0 < f)
            {
                f     = f0 ;
                *ctd  = i ;
                *delv = ddays[j] ;
            }

            Free_CFLWARRAY(xcflw, 1) ;
        }

        if (fixp->repay.type != BULLET)
            Free_CFLWARRAY(xcflw1, 1) ;

        Free_CFLWARRAY(cflw, 1) ;
        Free_DATEARRAY(ddays) ;
    }

    return f ;
}


/*,,SOH,,
*************************************************************************
*
*               FutBond_DF2Price()
*
*   interface   #include <future.h>
*               FL64 FutBond_DF2Price(DATESTR     *analys,
*                                     FUTBOND     *futb,
*                                     INTI        noas,
*                                     DFSPREADARRAY dfsarr,
*                                     DISCFAC     *df,
*                                     HOLI_STR    *holi,
*                                     RISKSET     *risk,
*                                     FL64        *dp,
*                                     FL64        *ddp,
*                                     INTI        *ctd,
*                                     DATESTR     *delv) ;
*
*   general     This function calculates the forward bond price for
*               a forward contract on a list of deliverable bonds.
*
*               The function is quite general in taking into account a
*               number of bond curiosities.
*
*               The function does not use the spot price bond only the
*               current term structure of interest rates. For a spot
*               price based routine see FutBond_CC2Price().
*
*               Risk ratios are calculated as follows:
*
*                   risk->key      dp          ddp
*                   ---------      ---         ----
*                   KEY_DF         $Duration   $Convexity
*                   KEY_BPV        BPV
*
*   input       DATESTR     *analys      Analysis date.
*
*               FUTBOND     *futb        Futures contract spec.
*
*               INTI        noas         No. of elements in dfsarr
*                                        If noas > 0 and noas < futb->nbond,
*                                        only the first noas bonds are
*                                        considered
*
*               DFSPREADARRAY dfsarr     Spreads.
*                                        Set to NULL if no spread
*                                        Dimension [noas]
*
*               DISCFAC     *df          Zero discount factors.
*
*               HOLI_STR    *holi        Holiday setup.
*
*               RISKSET     *risk        Risk set up
*                                        Use NULL for no risk ratios
*
*   output      FL64        *dp          Dollar duration
*
*               FL64        *ddp         Dollar convexity
*
*               INTI        *ctd         Cheapest to deliver bond
*
*               DATESTR     *delv        Delivery day
*
*   returns     The forward price adjusted for conversion factors
*
*   diagnostics
*
*   see also    FutBond_CC2Price()
*               FutBond_YTM2Price()
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/

FL64 FutBond_DF2Price(DATESTR* analys,
                      FUTBOND*     futb,
                      INTI        noas,
                      DFSPREADARRAY dfsarr,
                      DISCFAC*     df,
                      HOLI_STR*    holi,
                      RISKSET*     risk,
                      FL64*        dp,
                      FL64*        ddp,
                      INTI*        ctd,
                      DATESTR*     delv)
{
    INTI      ndays, nb, j, i ;
    FL64      fu, fd, shock, f0, f, dum ;
    CFLWARRAY xcflw, cflw ;
    DISCFAC   ds1 ;
    HOLI_STR  hol ;
    TRADEINFO settle, end ;
    FIXPAY    *fixp ;
    DFSPREAD  *dfs ;
    EXINF     dummy ;
    DATEARRAY ddays ;

    *dp = *ddp = 0.0 ;
    *ctd  = 0 ;
    *delv = Cldr_YMD2Datestr((YYYYMMDD) 0) ;

    if (noas > 0)
        nb = GETMIN(noas, futb->nbond) ;
    else
        nb = futb->nbond ;

    for (f = SCFUTHUGE_VAL, i = 0; i < nb; i++)
    {
        /* Generate the original flow for this bond */
        fixp = &futb->fixp[i] ;
        hol  = bond_set_holi(holi, &fixp->fix) ;
        cflw = Cflw_GenrCflw(&fixp->repay, &fixp->rday,
                              &fixp->fix, &fixp->cday, &hol) ;

        /* Find adjusted delivery days */
        ddays = FutBond_Xdiv_Adjust(analys, futb->ddays, futb->ndays, fixp,
                                    futb->xdiv3w, holi, &ndays) ;

        for (j = 0; j < ndays; j++)
        {
            /* Extract the specific period flow */
            settle = bond_set_tradeinfo(&ddays[j]) ;
            end    = bond_set_tradeinfo(&fixp->cday.last) ;
            xcflw  = Cflw_ExtractPeriod(&settle, &end, &fixp->fix,
                                         &fixp->cday.pseq, &fixp->accru,
                                         &fixp->exp, &hol, True, cflw,
                                         &fixp->repay.pp, fixp->repay.aufab,
                                         &dummy) ;

            Bond_TaxAdjCflw(xcflw, &fixp->tax, &fixp->fix.effective,
                            &fixp->cday.last) ;

            /* Find the forward price */
            dfs = (noas != 0 ? &dfsarr[i] : NULL) ;
            f0 = Cflw_DF2Price(&ddays[j], df, xcflw, &fixp->repay.pp,
                               holi, dfs, NULL, &dum, &dum) ;

            /* Adjust for delivery system */
            if (fabs(futb->cf[i]) > 0.000001)
                f0 /= futb->cf[i] ;

            /* Compare and update CTD */
            if (f0 < f)
            {
                f     = f0 ;
                *ctd  = i ;
                *delv = ddays[j] ;
            }

            Free_CFLWARRAY(xcflw, 1) ;

        }

        Free_CFLWARRAY(cflw, 1) ;
        Free_DATEARRAY(ddays) ;
    }

    /* Remember risk setting */
    if (risk != NULL && (risk->key == KEY_DF || risk->key == KEY_BPV) &&
        risk->risk != ZERO_ORDER)
    {
        dfs = (noas != 0 ? &dfsarr[*ctd] : NULL) ;
        settle.settle = *delv ;

        /* Shock rates up */
        shock = Scutl_Default_Shock(risk->shock, risk->key) ;
		ds1 = Disc_ShockRates(df, 1.0, risk, holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */

        /* Find forward price */
        fu = Bond_DF2Price(delv, &settle, &futb->fixp[*ctd], &ds1, holi,
                           dfs, NULL, &dum, &dum) ;
        if (fabs(futb->cf[*ctd]) > 0.000001)
            fu /= futb->cf[*ctd] ;

        /* Find forward price - contract price, and discount till settle */
        fu -= futb->futp ;
		fu = Disc_MarginAdjust(futb->margin, fu, analys, delv, &ds1, holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */
        Free_PLANARRAY(ds1.disc, 1) ;

        /* Shock rates down */
        ds1 = Disc_ShockRates(df, -1.0, risk, holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */

        /* Find forward price */
        fd = Bond_DF2Price(delv, &settle, &futb->fixp[*ctd], &ds1, holi,
                           dfs, NULL, &dum, &dum) ;
        if (fabs(futb->cf[*ctd]) > 0.000001)
            fd /= futb->cf[*ctd] ;

        /* Find forward price - contract price, and discount till settle */
        fd -= futb->futp ;
		fd = Disc_MarginAdjust(futb->margin, fd, analys, delv, &ds1, holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */
        Free_PLANARRAY(ds1.disc, 1) ;

        /* Set risk ratios */
        if (risk->key == KEY_BPV)
            shock = 1.0 ;

        *dp = - (fd - fu) / (2.0 * shock) ;

        if (risk->risk == SECOND_ORDER && risk->key == KEY_DF)
        {
            f0  = f - futb->futp ;
			f0 = Disc_MarginAdjust(futb->margin, f0, analys, delv, df, holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */

            *ddp = (fu + fd - 2.0 * f0) / SQR(shock) ;
        }
    }

    return f ;
}


/*,,SOH,,
*************************************************************************
*
*               FutBond_YTM2Price()
*
*   interface   #include <future.h>
*               FL64 FutBond_YTM2Price(DATESTR   *analys,
*                                      FL64      ytm,
*                                      FUTBOND   *futb,
*                                      YTMCONV   *ytmc,
*                                      HOLI_STR  *holi,
*                                      RISKCONV  risk,
*                                      FL64      *dp,
*                                      FL64      *ddp,
*                                      INTI      *ctd,
*                                      DATESTR   *delv) ;
*
*   general     This function calculates the forward bond price for
*               a forward contract on a list of deliverable bonds.
*
*               The function is quite general in taking into account a
*               number of bond curiosities.
*
*               The function does not use the spot price bond only the
*               yield of the futurtes contract. For a spot
*               price based routine see FutBond_CC2Price().
*
*               Risk ratios are calculated as follows:
*
*                   risk->key      dp          ddp
*                   ---------      ---         ----
*                   KEY_DF         $Duration   $Convexity
*                   KEY_BPV        BPV
*
*   input       DATESTR     *analys      Analysis date.
*
*               FL64        ytm          The futures contract yield
*
*               FUTBOND     *futb        Futures contract spec.
*
*               YTMCONV     *ytmc        Conventions for the repo rate
*
*               HOLI_STR    *holi        Holiday setup.
*
*               RISKCONV    risk         Risk order
*
*   output      FL64        *dp          Dollar duration
*
*               FL64        *ddp         Dollar convexity
*
*               INTI        *ctd         Cheapest to deliver bond
*
*               DATESTR     *delv        Delivery day
*
*   returns     The forward price adjusted for conversion factors
*
*   diagnostics
*
*   see also    FutBond_CC2Price()
*               FutBond_DF2Price()
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/

FL64 FutBond_YTM2Price(DATESTR* analys,
                       FL64      ytm,
                       FUTBOND*   futb,
                       YTMCONV*   ytmc,
                       HOLI_STR*  holi,
                       RISKCONV  risk,
                       FL64*      dp,
                       FL64*      ddp,
                       INTI*      ctd,
                       DATESTR*   delv)
{
    TRADEINFO settle, end ;
    CFLWARRAY cflw, xcflw ;
    FIXPAY    *fixp ;
    HOLI_STR  hol ;
    FL64      fterm, fd, fu, f0, fdum, shock, f ;
    INTI      ndays, i, j, qb ;
    EXINF     dummy ;
    DATEARRAY ddays ;

    *dp = *ddp = 0.0 ;
    *ctd  = 0 ;
    *delv = Cldr_YMD2Datestr((YYYYMMDD) 0) ;

    settle.brd = False ;
    settle.nom = 100.0 ;
    settle.xctrade.spec = False ;
    settle.xptrade.spec = False ;

    for (f = SCFUTHUGE_VAL, i = 0; i < futb->nbond; i++)
    {
        /* Generate the original flow for this bond */
        fixp = &futb->fixp[i] ;
        hol  = bond_set_holi(holi, &fixp->fix) ;
        cflw = Cflw_GenrCflw(&fixp->repay, &fixp->rday,
                              &fixp->fix, &fixp->cday, &hol) ;

        /* Find adjusted delivery days */
        ddays = FutBond_Xdiv_Adjust(analys, futb->ddays, futb->ndays, fixp,
                                    futb->xdiv3w, holi, &ndays) ;

        for (j = 0; j < ndays; j++)
        {
            /* Extract the specific period flow */
            settle.settle = ddays[j] ;
            end   = bond_set_tradeinfo(&fixp->cday.last) ;
            xcflw = Cflw_ExtractPeriod(&settle, &end, &fixp->fix,
                                        &fixp->cday.pseq, &fixp->accru,
                                        &fixp->exp, &hol, True, cflw,
                                        &fixp->repay.pp, fixp->repay.aufab,
                                        &dummy) ;

            Bond_TaxAdjCflw(xcflw, &fixp->tax, &fixp->fix.effective,
                            &fixp->cday.last) ;

            /* Find the forward price */
            f0 = Cflw_YTM2Price(ytm, xcflw, ytmc, &fixp->cday, 
                                fixp->fix.fix_rate, &fixp->repay.pp, 
                                holi, ZERO_ORDER, False, &fdum, &fdum) ;

            /* Adjust for delivery system */
            if (fabs(futb->cf[i]) > 0.000001)
                f0 /= futb->cf[i] ;

            /* Compare and update CTD */
            if (f0 < f)
            {
                f     = f0 ;
                *ctd  = i ;
                *delv = ddays[j] ;
            }

            Free_CFLWARRAY(xcflw, 1) ;
        }

        Free_CFLWARRAY(cflw, 1) ;
        Free_DATEARRAY(ddays) ;
    }

    /* Do risk calculations */
    if (risk != ZERO_ORDER)
    {
        settle.settle = *delv ;
        shock = Scutl_Default_Shock(-1.0, KEY_REPO) ;
		fterm = Cldr_TermBetweenDates(analys, delv, 0, ytmc->cal_first, LAST, holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */
        qb    = disc_set_qbas(ytmc->qb_ytm) ;

        /* Find forward price */
        fu = Bond_YTM2Price(ytm + shock, &settle, &futb->fixp[*ctd], ytmc, holi,
                            ZERO_ORDER, False, &fdum, &fdum) ;

        if (fabs(futb->cf[*ctd]) > 0.000001)
            fu /= futb->cf[*ctd] ;

        /* Find forward price - contract price, and discount till settle */
        fu -= futb->futp ;
        if (futb->margin == False)
            fu *= TVMunit_NPV(fterm, ytm + shock, ytmc->irr, qb) ;

        /* Find forward price */
        fd = Bond_YTM2Price(ytm - shock, &settle, &futb->fixp[*ctd], ytmc, holi,
                            ZERO_ORDER, False, &fdum, &fdum) ;

        if (fabs(futb->cf[*ctd]) > 0.000001)
            fd /= futb->cf[*ctd] ;

        /* Find forward price - contract price, and discount till settle */
        fd -= futb->futp ;
        if (futb->margin == False)
            fd *= TVMunit_NPV(fterm, ytm - shock, ytmc->irr, qb) ;

        /* Set risk ratios */
        *dp = - (fd - fu) / (2.0 * shock) ;

        if (risk == SECOND_ORDER)
        {
            f0  = f - futb->futp ;
            if (futb->margin == False)
                f0 *= TVMunit_NPV(fterm, ytm, ytmc->irr, qb) ;

            *ddp = (fu + fd - 2.0 * f0) / SQR(shock) ;
        }
    }

    return f ;
}


/*,,SOH,,
*************************************************************************
*
*               FutBond_YTM2Yield()
*
*   interface   #include <future.h>
*               BOOLE FutBond_YTM2Yield(DATESTR   *deliv,
*                                       FL64      futp,
*                                       FL64      cf,
*                                       FIXPAY    *fixp,
*                                       YTMCONV   *ytmc,
*                                       HOLI_STR  *holi,
*                                       ITERCTRL  *ictrl,
*                                       FL64      *ytm) ;
*
*   general     This function calculates the yield of a future contract
*               based on the bond futures price.
*
*               Note that this routine does NOT use the FUTBOND data
*               structure. This is because you need to know the assumed
*               delivery date before calling this routine. This is
*               entered in deliv - and calculated using for example
*               FutBond_CC2Price() or FutBond_YTM2Price()
*
*   input       DATESTR     *deliv       The futures delivery date
*
*               FL64        futp         The futures market price
*
*               FL64        cf           Conversion factor for the bond
*
*               FIXPAY      *fixp        The bond data.
*
*               YTMCONV     *ytmc        Conventions for the repo rate
*
*               HOLI_STR    *holi        Holiday setup.
*
*               ITERCTRL    *ictrl       Iteration control (repo calc)
*
*   output      FL64        *ytm         The implied measure in %
*
*   returns     True if all OK, False if not.
*
*   diagnostics
*
*   see also    FutBond_YTM2Price()
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/

/*,,SIC,,
..pinden idag !!??  -> hvis ej margining -> flyttes frem
                    -> hvis margining -> skal staa idag
,,EIC,,*/


BOOLE FutBond_YTM2Yield(DATESTR* deliv,
                        FL64      futp,
                        FL64      cf,
                        FIXPAY*    fixp,
                        YTMCONV*   ytmc,
                        HOLI_STR*  holi,
                        ITERCTRL*  ictrl,
                        FL64*      ytm)
{
    TRADEINFO settle ;
    BOOLE     ok ;

    settle = bond_set_tradeinfo(deliv) ;
    settle.price = futp * cf ;

    ok = Bond_YTM2Yield(&settle, fixp, ytmc, holi, ictrl, ytm) ;

    return ok ;
}


/*,,SOH,,
*************************************************************************
*
*               FutBond_CC2Impl()
*
*   interface   #include <future.h>
*               BOOLE FutBond_CC2Impl(TRADEINFO   *settle,
*                                     DATESTR     *deliv,
*                                     FL64        futp,
*                                     FL64        cf,
*                                     FIXPAY      *fixp,
*                                     HOLI_STR    *holi,
*                                     DFSPREAD    *dfs,
*                                     DISCFAC     *df,
*                                     YTMCONV     *ytmc,
*                                     ITERCTRL    *ictrl,
*                                     KEYCONV     what,
*                                     FL64        *impl) ;
*
*   general     This function calculates the implied repo rate or spot
*               price implicit in the bond futures price.
*
*               The following ratios are calculated:
*
*                    what       Implied
*                    ------------------
*                    KEY_SPOT   Implied spot price
*                    KEY_REPO   Implied repo
*
*               Note that this routine does NOT use the FUTBOND data
*               structure. This is because you need to know the assumed
*               delivery date before calling this routine. This is
*               entered in deliv - and calculated using for example
*               FutBond_CC2Price()
*
*   input       TRADEINFO   *settle      The contract settle data
*                                        spot price is in settle->price
*
*               DATESTR     *deliv       The futures delivery date
*
*               FL64        futp         The futures market price
*
*               FL64        cf           Conversion factor for the bond
*
*               FIXPAY      *fixp        The bond data.
*
*               HOLI_STR    *holi        Holiday setup.
*
*               DFSPREAD    *dfs         The spread against df.
*                                        Only used if what = KEY_SPOT
*                                        Set to NULL if no spread
*
*               DISCFAC     *df          The Repo Discount Factors
*                                        Only used if what = KEY_SPOT
*                                        Generate with Disc_TS2DF()
*
*               YTMCONV     *ytmc        Conventions for the repo rate
*                                        Only used if what = KEY_REPO.
*
*               ITERCTRL    *ictrl       Iteration control (repo calc)
*
*               KEYCONV     what         What to calculate
*
*   output      FL64        *impl        The implied measure in %
*
*   returns     True if all OK, False if not.
*
*   diagnostics
*
*   see also    FutBond_CC2Price()
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/

BOOLE FutBond_CC2Impl(TRADEINFO* settle, /* incl spot price */
                      DATESTR*   deliv,
                      FL64      futp,
                      FL64      cf,
                      FIXPAY*    fixp,    /* any deliv bond */
                      HOLI_STR*  holi,
                      DFSPREAD*  dfs,
                      DISCFAC*   df,
                      YTMCONV*   ytmc,
                      ITERCTRL*  ictrl,
                      KEYCONV   what,
                      FL64*      impl)
{
    CFLWARRAY cflw, xcflw ;
    HOLI_STR  hol ;
    BOOLE     ok, use_gu ;
    FL64      gu, dp ;
    TRADEINFO matur ;
    EXINF     dummy ;

    /* Initialise */
    ok  = True ;
    hol = bond_set_holi(holi, &fixp->fix) ;

    /* Generate the original flow for this bond */
    cflw = Cflw_GenrCflw(&fixp->repay, &fixp->rday,
                         &fixp->fix, &fixp->cday, &hol) ;

    /* Extract residual flow */
    settle->nom = 100.0 ;
    matur = bond_set_tradeinfo(deliv) ;
    matur.price = cf * futp ;
    xcflw = Cflw_ExtractPeriod(settle, &matur, &fixp->fix, &fixp->cday.pseq,
                               &fixp->accru, &fixp->exp, &hol, True, cflw,
                               &fixp->repay.pp, fixp->repay.aufab, &dummy) ;

    /* Tax adjust */
    Bond_TaxAdjCflw(xcflw, &fixp->tax, &fixp->fix.effective, &fixp->cday.last) ;

    /* Be careful about guessing */
    gu = ictrl->init_guess ;
    use_gu = ictrl->use_init_guess ;
    ictrl->init_guess = (use_gu ? gu : 10.0) ;
    ictrl->use_init_guess = True ;

    if (what == KEY_REPO)
        ok = RepoCflw_YTM2Yield(settle->price, xcflw, deliv,
                                ytmc, &fixp->cday, fixp->fix.fix_rate,
                                &fixp->repay.pp, holi, ictrl, impl) ;
    else if (what == KEY_SPOT)
        *impl = RepoCflw_DF2Price(&settle->settle, df, xcflw, 
                                  deliv, &fixp->repay.pp,
                                  holi, dfs, NULL, &dp, &dp) ;

    /* Clean up */
    ictrl->init_guess = gu ;
    ictrl->use_init_guess = use_gu ;

    Free_CFLWARRAY(xcflw, 1) ;
    Free_CFLWARRAY(cflw, 1) ;

    return ok ;
}


/*,,SOH,,
*************************************************************************
*
*               FutBond_DF2Delta()
*
*   interface   #include <future.h>
*               FL64ARRAY FutBond_DF2Delta(DATESTR     *analys,
*                                          FUTBOND     *futb,
*                                          INTI        noas,
*                                          DFSPREADARRAY dfsarr,
*                                          DISCFAC     *df,
*                                          HOLI_STR    *holi,
*                                          DELTASET    *ds,
*                                          INTI        *ctd,
*                                          DATESTR     *delv) ;
*
*   general     The function calculates the delta vector for
*               a CTD future bond using a list of predefined shocks to
*               the zero-coupon curve.
*
*               Note that the routine can be called with a list of bonds
*               or a single bond (the CTD bond). If called with a list
*               the CTD is found using the current zero curve. This CTD
*               is then used for delta vector calculation.
*
*               The performance of this routine depends strongly on the
*               number of deliverable bonds and on the number of
*               delivery dates.
*               Calculation time can therefore be reduced considerable
*               if the deliverable bond and the delivery date is
*               well-known. In this case you should only pass one bond
*               and one delivery date as arguments to the routine.
*
*               The delta vector represents the PV differences
*               invoked by the curve shocks.
*
*   input       DATESTR     *analys      Analysis date.
*
*               FUTBOND     *futb        Futures contract spec.
*
*               INTI        noas         No. of elements in dfsarr
*
*               DFSPREADARRAY dfsarr     Spreads.
*                                        Set to NULL if no spread
*                                        Dimension [noas]
*
*               DISCFAC     *df          Discount factors.
*
*               HOLI_STR    *holi        Holiday setup.
*
*               DELTASET    *ds          Data for delta vector calc.
*
*   output      INTI        *ctd         Cheapest to deliver bond
*
*               DATESTR     *delv        Delivery day
*
*   returns     The delta vector allocated as:
*
*                         Alloc_FL64ARRAY(ds->nshock) ;
*
*   diagnostics
*
*   see also    Bond_DF2Price()
*               Disc_DeltaPrep()
*               Boot_DeltaPrep()
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/

FL64ARRAY FutBond_DF2Delta(DATESTR*  analys,
                           FUTBOND*     futb,
                           INTI        noas,
                           DFSPREADARRAY dfsarr,
                           DISCFAC*     df,
                           HOLI_STR*    holi,
                           DELTASET*    ds,
                           INTI        *ctd,
                           DATESTR     *delv)
{
    FL64ARRAY dv ;
    FL64      dv0, fi, f0, dum ;
    INTI      i ;
    PLANARRAY old ;
    TRADEINFO settle ;
    DFSPREAD  *dfs ;

    /* Initialise */
    old = df->disc ;

    settle.brd = False ;
    settle.nom = 100.0 ;
    settle.xctrade.spec = False ;
    settle.xptrade.spec = False ;

    /* First find the CTD bond and the delivery date. 
       If there is only one deliverable bond and one 
       delivery date, it isn't necessary to call
       FutBond_DF2price to determine ctd and delv */
    if (futb->nbond == 1 && futb->ndays == 1)
    {
        *ctd  = 0 ;
        *delv = futb->ddays[0] ;
    }
    else
        dum = FutBond_DF2Price(analys, futb, noas, dfsarr,
                               df, holi, NULL, &dum, &dum, ctd, delv) ;

    /* Find the delta vector */
    settle.settle = *delv ;
    dfs = (noas != 0 ? &dfsarr[*ctd] : NULL) ;
    f0 = Bond_DF2Price(delv, &settle, &futb->fixp[*ctd], df, holi,
                       dfs, NULL, &dum, &dum) ;
    dv = Bond_DF2Delta(delv, &settle, &futb->fixp[*ctd], df, holi, dfs, ds) ;
    dv0 = Disc_MarginAdjust(futb->margin, f0 - futb->futp, 
                                analys, delv, df, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */

    for (i = 0; i < ds->nshock; i++)
    {
        /* Be careful to handle forwards correctly */
        fi = dv[i] + f0 - futb->futp ;

        df->disc = &ds->shock[i] ;
        dv[i] = Disc_MarginAdjust(futb->margin, fi, analys, delv, df, holi) -
                                      dv0 ;    /* PMSTA-22396 - SRIDHARA � 160502 */

        /* Adjust for conversion factors */
        if (fabs(futb->cf[*ctd]) > 0.000001)    /* Changed for what seems the more logical PMSTA-36650 - 260719 - PMO */
            dv[i] /= futb->cf[*ctd] ;
    }

    /* Clean up */
    df->disc = old ;

    return dv ;
}


/*,,SOH,,
*************************************************************************
*
*               FutBond_ConFac()
*
*   interface   #include <future.h>
*               FL64 FutBond_ConFac(FL64      coupon,
*                                   PMTFREQ   freq,
*                                   EXRULE    *exc,
*                                   CALCONV   cal,
*                                   EOMCONV   eom,
*                                   ODDCONV   stub_front,
*                                   DATESTR   *redemp1,
*                                   DATESTR   *redemp2,
*                                   DATESTR   *effec,
*                                   DATESTR   *deliv,
*                                   CFCONV    system,
*                                   FL64      yield,
*                                   HOLI_STR  *holi) ;
*
*   general     This function calculates the Conversion Factors for a
*               deliverable bond given a CTD delivery system.
*
*               Note that the algorithm for LIFFE_GILT does NOT handle
*               issues that are partly paid.
*
*               Last update of algorithms: June 1999. 
*
*   input       FL64      coupon     The bond coupon
*
*               PMTFREQ   freq       The payment frequency
*                                    Cannot be NO_FREQUENCY.
*
*               EXRULE    *exc       Ex-Coupon definition
*                                    Only used for UK Gilts.
*
*               CALCONV   cal        Calendar convention
*
*               EOMCONV   eom        End of Month convention
*
*               ODDCONV   stub_front Odd convention for 
*                                    first period. Standard value is NOODD. 
*                                    Must be set. 
*
*               DATESTR   *redemp1   The first possible redemption.
*                                    for Callable UK Gilts, LIFFE_GILT.
*                                    Otherwise first coupon date of bonds
*                                    starting with an odd period as 
*                                    indicated by stub_front.
*                                    Use NULL if not used.
*
*               DATESTR   *redemp2   The last possible redemption.
*                                    (Maturity date)
*
*               DATESTR   *effec     The effective date of the bond.
*                                    Used for MEFF_BONOS to handle
*                                    the case where the issue date
*                                    is not the same as the effective
*                                    date.
*                                    Otherwise used for bonds starting
*                                    with an odd period as indicated by
*                                    stub_front
*                                    Use NULL if not used.
*
*               DATESTR   *deliv     The delivery date
*                                    See above for interpretation
*
*               CFCONV    system     The Conversion Factor Setup
*
*               FL64      yield      The notional yield for the contract
*
*               HOLI_STR  *holi      Holiday setup
*                                    Only used for MATIF_NOT and LIFFE_GILT.
*
*   output
*
*   returns     The Conversion Factor
*
*   diagnostics
*
*   see also
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/


FL64 FutBond_ConFac(FL64  coupon,
                    PMTFREQ   freq,
                    EXRULE*    exc,
                    CALCONV   cal,
                    EOMCONV   eom,
                    ODDCONV   stub_front,
                    DATESTR*   redemp1,
                    DATESTR*   redemp2,
                    DATESTR*   effec,
                    DATESTR*   deliv,
                    CFCONV    system,
                    FL64      yield,
                    HOLI_STR* holi)
{
    FL64     s, r, t ,d1 ,d2 , ai, x, x2, y, y2, z, zn, n1, yper, cper,
             scale, f, cf, oneplusy, accruint, oddcoupext, inidiscper;
    BOOLE    trunc, ex ;
    INTI     months, n, num, qbas, round_off, i ;
    DATESTR  deliv1, deliv2, pdate, pdate2, r1, r2, redemp, next, d_2,
             dummydate, first, feb96, nov98, may99, aug99, nov99;
    EXTRADE  extr ;

    /* warning avoidance */
    round_off = 0 ;
    cf = 0.0 ;

    if (yield < 0.000000001 && system != NO_CFCONV)
      return cf;

    trunc = False ;

    /* Initialize various variables */
    r2 = *redemp2 ;

    /* Number of annual payments */
    months = Cflw_MonthsBetweenPayments(freq) ;
    months = GETMIN(12, months) ;
    if (months == 0)
      return cf ;
    n = 12 / months ;

    /* Last previous paydays */
    pdate = Cldr_FindPrevTerm(deliv, &r2, months, eom) ;

    /* Find the next coupon date */
    next = Cldr_AddMonths(&pdate, months, eom) ;

    /* Delimiter dates for calculation method changes */
    feb96 = Cldr_YMD2Datestr(19960201);
    nov98 = Cldr_YMD2Datestr(19981101);
    aug99 = Cldr_YMD2Datestr(19990801);
    may99 = Cldr_YMD2Datestr(19990501);
    nov99 = Cldr_YMD2Datestr(19991101);

    switch (system)
    {
      case LIFFE_GILT :

        /* The source for the method is official Liffe material */
        
        /* History of Liffe futures on Gilts:
           - January 1st 1996: ex-coupon date was changed from 37 calendar days 
             to 7 business days before coupon. For guilts, the ex-coupon date 
             is the last date that the bond is traded WITH coupon. In SCecon
             the ex-coupon date is the first date where the bond is traded
             without coupon. The special extended ex-coupon period is 21
             calendar days unchanged.
           - March 1996: Ex-coupon criteria in price factor calculation changed
             (KBO guess).
           - June 1998: The yield used for price factor calculation is now 7%
             (down from 9%).
           - July 31st 1998: The special 21 day extended coupon period where
             the bond may trade both with and without coupon is abandoned.
           - November 1998: Accrued interest calculation in price factor
             calculation changed from 182.5 days to actual days in period
             basis.
           - September 1999: Revised price factor algorithm. SCecon does
             not take partly payments and odd coupon into account when
             calculating prie factor.
        */
        round_off = 7 ;

        deliv1   = *deliv ;
        deliv1.d = 1 ;
        pdate = Cldr_FindPrevTerm(&deliv1, &r2, months, eom) ;

        /* Find the next coupon date */
        next = Cldr_AddMonths(&pdate, months, eom) ;

        r1 = GetArrayEl(redemp1, 0, 1, r2) ;

        /* Find the "theoretical" redemption date. Equals r2 if the
           Gilt is non-callable or has a coupon lower than notional
           yield. Otherwise r1 is used. */
        if (Cldr_DateEQ(&r1, &r2) == True)
          redemp = r1 ;
        else if (coupon >= yield)
          redemp = r1 ;
        else if (coupon < yield)
          redemp = r2 ;

		/* PMSTA-22396 - SRIDHARA � 160502 */
        /* Find the period yield and the periodic coupon. */
        n1 = (FL64) Cldr_TermBetweenDates(&next, &redemp, n, cal, eom, holi) ;
        x  = (FL64) Cldr_DaysBetweenDates(&deliv1, &next, cal, holi) ;
        y = (FL64) Cldr_DaysBetweenDates(&pdate, &next, cal, holi) ;

        /* Is the bond ex-coupon -- in the entire period !! */
        extr.spec = False ;
        deliv2    = deliv1 ;
        deliv2.d  = Cldr_LastDayInMonth(deliv1.y, deliv1.m) ;

        ex = Cflw_XdayCalc(&deliv1, &pdate, &next, redemp2, exc, &extr,
                           holi) ;

        if (Cldr_DateLE(deliv, &feb96))
          ex = ex || Cflw_XdayCalc(&deliv2, &pdate, &next, redemp2, exc,
                                   &extr, holi) ;

        if (Cldr_DateLE(deliv, &aug99)) /* (I) + (II) */
        {
          cf  = (ex == False ? coupon / 2.0 : 0.0);
          cf += 100.0 * coupon * (1.0 - pow(1.0 + yield/200.0, -n1)) / yield;
          cf += 100.0 * pow(1.0 + yield/200.0, -n1);
          cf *= pow((1.0 + yield/200.0), -x / 182.5);

          if (Cldr_DateLE(deliv, &nov98)) /* (I) */
          {
            if (ex == False)
              cf -= 0.5 * coupon * (y - x) / 182.5;
            else
              cf += 0.5 * coupon * x / 182.5;
          }
          else /* (II) */
          {
            if (ex == False)
              cf -= 0.5 * coupon * (y - x) / y;
            else
              cf += 0.5 * coupon * x / y;
          }
        }
        else /* (III) */
        {
          /* For readability, the same structure and notation as in the Liffe
             material has been kept. */
          s = y;
          r = x;
		  t = (FL64)Cldr_DaysBetweenDates(&pdate, &deliv1, cal, holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */

          /* Take care of ex-coupon, long or short first period */
          if (ex == False)
          {
             /* Currently we can not handle odd first period */
            d1 = coupon / 2.0 ;
            d2 = coupon / 2.0 ;
          }
          else
          {
            d1 = 0.0 ;
            d2 = coupon / 2.0 ;
          }
          
          /* ai should be calculated differently for long or short odd
             periods */
          if (ex == False)
            ai = t / s * 0.5 * coupon;
          else
            ai = (t/s - 1) * 0.5 * coupon;

          oneplusy = 1.0 + yield/200.0;

          cf = pow(oneplusy, -r/s) *
               (d1 + d2/oneplusy + coupon*100/yield *
                                   (1/oneplusy - pow(oneplusy, -n1)) +
                100*pow(oneplusy, -n1)) - ai;
        }

        cf *= 0.01 ;
        break ;

      case LIFFE_BUND:
      case EUREX_BUND:
      case EUREX_SGB:
      case OM_STAT:
        qbas = 1 ;
        round_off = 6 ;

        if ((system == LIFFE_BUND && Cldr_DateLT(&may99, deliv)) ||
            (system == EUREX_BUND && Cldr_DateLT(&nov99, deliv)))
        {
          /* The source for the method is official LIFFE material, 
             issued 22/10/1998 */

          round_off = 6 ;

          yield /= (FL64) 100.0;
          t     = (FL64) 1.0 + yield / (FL64) n;

          /* First find x, the number of days from and including the
             delivery day up to but excluding the next interest payment
             date (calculated on the basis of actual number of days) */

		  x = (FL64)Cldr_DaysBetweenDates(deliv, &next, ACTACT, NULL);   	/* PMSTA-22396 - SRIDHARA � 160502 */

          /* The find y, the number of days from and including the 
             last coupon payment date up to but excluding the
             next coupon payment (calculated on the basis of actual 
             number of days). The true accruel date for the first coupon
             payment is not taken into consideration */

		  y = (FL64)Cldr_DaysBetweenDates(&pdate, &next, ACTACT, NULL);   	/* PMSTA-22396 - SRIDHARA � 160502 */

          if (system == LIFFE_BUND && effec != NULL &&
              effec->d != 0 && redemp1 != NULL &&
              redemp1->d != 0 && Cldr_DateLT(deliv, redemp1)
              && stub_front != NOODD)
          {
            next = *redemp1;
            pdate = Cldr_AddMonths(&next, -months, eom);
            x  = (FL64) Cldr_DaysBetweenDates(deliv, &next, ACTACT, NULL) ;   	/* PMSTA-22396 - SRIDHARA � 160502 */
            y  = (FL64) Cldr_DaysBetweenDates(effec, &next, ACTACT, NULL) ;   	/* PMSTA-22396 - SRIDHARA � 160502 */
          }

          /* Normal/regular case */
          accruint = (y - x) * coupon / (y * (FL64) n);
          oddcoupext = 0.0;
          inidiscper = x / y;
          
          /* Odd period start of bond (and delivery date before first coupon) */
          if ((system == EUREX_BUND || system == EUREX_SGB) &&
            effec != NULL && effec->d != 0 && redemp1 != NULL &&
            redemp1->d != 0 && Cldr_DateLT(deliv, redemp1) && 
            stub_front != NOODD)
          {
            x2 = (FL64) Cldr_DaysBetweenDates(effec, deliv, ACTACT, NULL) ;   	/* PMSTA-22396 - SRIDHARA � 160502 */
            
            if (stub_front == SHORTODD)
            {
              /* Short odd */
              oddcoupext = -accruint;
              accruint = coupon * x2 / (y * (FL64) n);
              /* The regular coupon is lowered with the same amount as the
                 accrued interest */
              oddcoupext += accruint;
            }
            else
            {
              /* Long odd */
              next = *redemp1;
              pdate = Cldr_AddMonths(&next, -months, eom);
              pdate2 = Cldr_AddMonths(&pdate, -months, eom);
              x  = (FL64) Cldr_DaysBetweenDates(deliv, &next, ACTACT, NULL) ;   	/* PMSTA-22396 - SRIDHARA � 160502 */
              y  = (FL64) Cldr_DaysBetweenDates(&pdate, &next, ACTACT, NULL) ;   	/* PMSTA-22396 - SRIDHARA � 160502 */
              y2 = (FL64) Cldr_DaysBetweenDates(&pdate2, &pdate, ACTACT, NULL) ;   	/* PMSTA-22396 - SRIDHARA � 160502 */

              oddcoupext = (x + x2 - y) * coupon / (y2 * (FL64) n);

              if (Cldr_DateLT(deliv, &pdate))
              {
                /* Delivery in first part of long odd period */
                accruint = x2 * coupon / (y2 * (FL64) n);
                inidiscper = 1 + (x - y) / y2;
              }
              else
              {
                /* Delivery in last part of long odd period */
                accruint = coupon * 
                          ((x + x2 - y) / (y2 * (FL64) n) +
                          (y - x) / (y * (FL64) n));
              }
            }
          }

          /* Next, find the number of remaining half years from
              the next coupon date to the final maturity date. */
		  n1 = Cldr_TermBetweenDates(&next, &r2, n, cal, eom, holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */

          /* Finally, compute the conversion factor. */
          f  = (FL64) pow(t, -n1) ;
          cf = pow(t, - inidiscper) * (oddcoupext + (t - f) * coupon / yield +
               (FL64) 100.0 * f) - accruint;
          cf /= (FL64) 100.0;
        }
        else
        {
          /* The source for the method is official Liffe and DTB material */

          /* First find f = the number of whole months (rounded down) till
             next coupon, and n1 the number of whole years till maturity. */
			f = floor(Cldr_TermBetweenDates(deliv, &next, 12, cal, eom, holi));  	/* PMSTA-22396 - SRIDHARA � 160502 */
          f /= (FL64) 12 ;
		  n1 = Cldr_TermBetweenDates(&next, &r2, n, cal, eom, holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */

          /* Take care if we are closer than a month to the next coupon */
          if (!f)
          {
            f   = 1.0 ;
            n1 -= 1.0 ;
          }

          /* Find the periodic yield and the periodic coupon */
          yper = Yld_Ann2Per(yield, 1.0/(FL64) n, qbas, COMPOUND) ;
          cper = Yld_Ann2Per(coupon, 1.0/(FL64) n, 0, SIMPLE_MM) ;

          /* Now we are ready to do the computation of the factor */
          cf = 0.01 * TVM_NPV_Bullet(cper, yper, f + n1) ;

          /* Now handle the accrued part of the cf */
          ai = Yld_Ann2Per(coupon/100.0, 1.0 - f, 0, SIMPLE_MM) ;
          cf = cflw_dirty2clean(cf, ai) ;
        }
        break ;

      case TSE_T_BOND :
      case CBOT_T_BOND:

        /* This applies to US Treasury bond futures and 10-year note
           futures */
        round_off = 4 ;

        /* First find the number of whole years, n1, and the number
           of months rounded down to whole quarters, z, between
           first delivery day and maturity. */

		/* PMSTA-22396 - SRIDHARA � 160502 */
        n1 = floor(Cldr_TermBetweenDates(deliv, &r2, 1, cal, eom, holi)) ;
        z  = floor(Cldr_TermBetweenDates(deliv, &r2, 12, cal, eom, holi)) ;
        z -= 12.0 * n1 ;

        z = floor(z / 3.0) * 3.0 ;

        if (z < 7.0)
        {
          f = z / 6.0 ;
          x = 2.0 * n1;
        }
        else
        {
          f = 0.5 ;
          x = 2.0 * n1 + 1.0;
        }

        y = 1.0 + yield / 200.0 ;

        /* Now compute the conversion factor */
        cf = pow(y, -f) * (coupon / 200.0 + pow(y, -x)
             + coupon / yield * (1.0 - pow(y, -x)))
             - coupon / 200.0 * (1.0 -f) ;

        break ;

      case CBOT_T_NOTE:

        /* This applies to US Treasury 2- and 5-year note futures */
        round_off = 4 ;

        /* First find the number of whole years, n1, and the number of
           whole months, z, between first delivery day and maturity. */
		/* PMSTA-22396 - SRIDHARA � 160502 */
        n1 = floor(Cldr_TermBetweenDates(deliv, &r2, 1, cal, eom, holi)) ;
        z  = floor(Cldr_TermBetweenDates(deliv, &r2, 12, cal, eom, holi)) ;
        if (n1 < 3.0)
          z += 1.0 ;

        z -= 12.0 * n1 ;

        if (z < 7.0)
        {
          f = z / 6.0 ;
          x = 2.0 * n1 ;
        }
        else
        {
          f = z / 6.0 - 1.0 ;
          x = 2.0 * n1 + 1.0 ;
        }

        y = 1.0 + yield / 200.0 ;

        /* Now compute the conversion factor */
        cf = pow(y, -f) * (coupon / 200.0 + pow(y, -x)
             + coupon / yield * (1.0 - pow(y, -x)))
             - coupon / 200.0 * (1.0 -f) ;

        break ;

      case LIFFE_BTP :
      case MIF_BTP :

        if (Cldr_DateLT(&may99, deliv))
        {
          /* The source for the method is official LIFFE material, 
             issued 22/10/1998 */

          round_off = 6 ;

          yield /= (FL64) 100.0;
          t     = (FL64) 1.0 + yield / (FL64) n;

          /* First find x, the number of days from and including the
             delivery day up to but excluding the next interest payment
             date (calculated on the basis of actual number of days) */

          x  = (FL64) Cldr_DaysBetweenDates(deliv, &next, ACTACT, NULL) ;  /* PMSTA-22396 - SRIDHARA � 160502 */

          /* The find y, the number of days from and including the 
             last coupon payment date up to but excluding the
             next coupon payment (calculated on the basis of actual 
             number of days). The true accruel date for the first coupon
             payment is not taken into consideration */

          y  = (FL64) Cldr_DaysBetweenDates(&pdate, &next, ACTACT, NULL) ;  /* PMSTA-22396 - SRIDHARA � 160502 */

          /* Next, find the number of remaining half years from
              the next coupon date to the final maturity date. */

          n1 = Cldr_TermBetweenDates(&next, &r2, n, cal, eom, holi);      /* PMSTA-22396 - SRIDHARA � 160502 */

          /* Finally, compute the conversion factor. */

          f  = (FL64) pow(t, -n1) ;
          cf = pow(t, - x / y) * (coupon / (FL64) n + (1.0 - f) * 
            coupon / yield +
            (FL64) 100.0 * f) - (y - x) * coupon / (y * (FL64) n);
          cf /= (FL64) 100.0;
        }
        else
        {
          /* The source for the method is official LIFFE */

          qbas = 2 ;
          round_off = 6 ;

          yield /= (FL64) 100.0;
          n1    = (FL64) 1.0 + yield / (FL64) 2.0;

          /* First find x, the number of days from and including the
             delivery day up to but excluding the next interest payment
             date (calculated on the basis of actual number of days) */

          x  = (FL64) Cldr_DaysBetweenDates(deliv, &next, ACTACT, NULL) ;  /* PMSTA-22396 - SRIDHARA � 160502 */

          /* The find y, the fraction of a year from and including
              the Delivery Day up to but excluding the next
              coupon payment date ( calculated on the basis of
              EU30E360 convention). */

          y  = (FL64) Cldr_DaysBetweenDates(deliv, &next, EU30E360, NULL) ;  /* PMSTA-22396 - SRIDHARA � 160502 */
          y -= (FL64) 1.0;
          y /= (FL64) 360.0;

          /* Next, find m, the number of remaining half years from
              the next coupon date to the final maturity date. */

          t = Cldr_TermBetweenDates(&next, &r2, qbas, EU30E360, eom, holi) ;  /* PMSTA-22396 - SRIDHARA � 160502 */

          /* Finally, compute the conversion factor.
              Begin by doing some intermediates. */

          x /= (FL64) 182.5 ;
          x  = (FL64) pow(n1, -x) ;
          f  = (FL64) pow(n1, -t) ;

          cf = x * (coupon / (FL64) 2.0 + (1.0 - f) * coupon / yield +
                   (FL64) 100.0 * f) - coupon * ((FL64) 0.5 -  y) ;

          cf /= (FL64) 100.0;
        }
        break ;

      case LIFFE_JGB :
      case SIMEX_JGB :
      case TSE_JGB:
        /* The source for the method is official Liffe and TSE material */
        trunc     = True ;
        qbas      = 2 ;
        round_off = 6 ;

        /* Delivery - always 20th */
        deliv2   = *deliv ;
        deliv2.d = 20 ;

        /* Last previous paydays - always relative to 20th */
        r2.d  = 20 ;
        pdate = Cldr_FindPrevTerm(&deliv2, &r2, months, eom) ;

        /* Find the next coupon date */
        if (Cldr_DateEQ(&pdate, &deliv2) == True)
          next = deliv2 ;
        else
          next = Cldr_AddMonths(&pdate, months, eom) ;

        /* First find f = the number of whole months (rounded down) till
           next coupon, and n1 the number of whole years till maturity. */
        f  = floor(Cldr_TermBetweenDates(&deliv2, &next, 12, cal, eom, holi)) ;   /* PMSTA-22396 - SRIDHARA � 160502 */
        f /= (FL64) 6 ;
		n1 = Cldr_TermBetweenDates(&next, &r2, n, cal, eom, holi);  /* PMSTA-22396 - SRIDHARA � 160502 */

        /* Possibly f, n1 needs to be modified whenever there are more
           than 10 or 20 Years to maturity -> according to TSE material,
           but no examples have been found */

        /* Now calculate cf */
        cf  = 1.0 + yield / 200.0 - pow(1.0 + yield / 200.0, - n1) ;
        cf *= coupon / yield ;
        cf += pow(1.0 + yield / 200.0, - n1) ;
        cf *= pow(1.0 + yield / 200.0, - f) ;
        cf -= coupon * (1.0 - f) / 200.0 ;

        break ;

      case MEFF_BONOS :

      /* The source for the method is official MEFF */
        qbas      = 1 ;
        round_off = 7 ;

        cf = 0.0 ;

           /* Take care of forward starting BONOS */
        if (effec != NULL)
        {
          first = Cldr_AddMonths(effec, months, eom) ;

          if (Cldr_DateLT(&next, &first))
          {
            next = first ;
            pdate = *effec ;
          }
        }

          /* first compute number of payments */
		n1 = Cldr_TermBetweenDates(&next, &r2, n, cal, eom, holi);  /* PMSTA-22396 - SRIDHARA � 160502 */

          /* Find the periodic yield and the periodic coupon   */
        yper = Yld_Ann2Per(yield, 1.0/(FL64) n, qbas, COMPOUND) ;
        cper = Yld_Ann2Per(coupon, 1.0/(FL64) n, 0, SIMPLE_MM) ;

		f = (FL64)Cldr_DaysBetweenDates(deliv, &next, cal, holi);  /* PMSTA-22396 - SRIDHARA � 160502 */
		f /= (FL64)Cldr_DaysBetweenDates(&pdate, &next, cal, holi);  /* PMSTA-22396 - SRIDHARA � 160502 */

          /* Take care of the case where the first coupon 
             lies more than one period after the delivery date */
        if (f > 1.0)
        {
          f = (INTI) f ;
          f = (FL64) f ;
          z = (FL64) Cldr_DaysBetweenDates(deliv, &pdate, cal, holi) ;    /* PMSTA-22396 - SRIDHARA � 160502 */
          dummydate = Cldr_AddMonths(&pdate, -months, eom) ;
          z /= (FL64) Cldr_DaysBetweenDates(&dummydate, &pdate, 
                                            cal, holi) ;              /* PMSTA-22396 - SRIDHARA � 160502 */
          f += z ;
        }

        for (i = 0 ; i <= n1 ; i++)
        {
          /* Now we are ready to do the computation of the factor */
          cf += 0.01 * cper * TVMunit_NPV(f + (FL64) i, yper, COMPOUND, 1);
          if (fabs(n1 - (FL64) i) < 0.000000001)
            cf += TVMunit_NPV(f + (FL64) i, yper, COMPOUND, 1);
        }

        /* Now handle the accrued part of the cf */
        next = Cldr_AddMonths(&pdate, 12 / n, eom) ;

        /* Except if delivery day precedes the first coupon day
           and the deliverable bond will have accrued no interest
           by that day, f/y = 1 */
		/* PMSTA-22396 - SRIDHARA � 160502 */
        f  = (FL64) Cldr_DaysBetweenDates(deliv, &next, cal, holi) ;
        y  = (FL64) Cldr_DaysBetweenDates(&pdate, &next, cal, holi) ;
        f /= y ;

        ai = 0.01 * coupon * (1.0 - f) ;

          /* Take care of the case where the first coupon 
             lies more than one period after the delivery date */
        if (f > 1.0)
          ai = 0.0 ;

        cf = cflw_dirty2clean(cf, ai) ;

        break ;

      case ME_CGB : /* Montreal Exchange Government Bond Future */
      case CBOT_CGB:

        /* The source for the method is Goldman Sachs :
           Mark Huie:
           "Futures on Canadian Government Bonds : An Introduction"
           Goldman Sachs Fixed Income Research, February 1992
           and official MONEX material */

        qbas      = 1 ;
        round_off = 4 ;

        /* Use first date in delivery month */
        deliv1   = *deliv ;
        deliv1.d = 1 ;

        /* Last previous payday */
        pdate = Cldr_FindPrevTerm(&deliv1, &r2, months, eom) ;

        /* Find the next coupon date */
        next = Cldr_AddMonths(&pdate, months, eom) ;

        /* n1 is the number of half years from the first day of the
           delivery month to the first day of the delivery month at
           or prior to the final maturity date.
           f is the fractional part of n1 - either 0.0 or 0.5 */

        r2.d = 1 ;
        while (r2.m != 3 && r2.m != 6 && r2.m != 9 && r2.m != 12)
          r2 = Cldr_AddMonths(&r2, -1, eom) ;

        f  = Cldr_TermBetweenDates(&deliv1, &r2, n, EU30E360, eom, holi) ;  /* PMSTA-22396 - SRIDHARA � 160502 */
        n1 = floor(f) ;
        f -= n1 ;
        f  = floor(2.0 * f) / 2.0 ;

        /* Compute conversion factor */
        cf  = coupon / 2.0 ;
        cf += 100.0 * coupon * (1.0 - pow((1.0 + yield/200.0), -n1)) /
          yield ;
        cf += 100.0 * pow((1.0 + yield/200.0), -n1) ;
        cf *= pow((1.0 + yield/200.0), -f) ;
        cf -= coupon * (1.0 - f) / 2.0 ;
        cf *= 0.01 ;

        break ;

      case MATIF_NOT:  /* French notionnel bond future */

        qbas      = 1;
        round_off = 6;

        /* Compute the reconciliation date, 3 business days prior to delivery */
        d_2 = Cldr_AddBusinessdays(deliv, -3, holi->nholi,
                                   holi->holidays);

        /* Compute the number of days between d_2 (included) and
            the day (not included) of the next coupon */
        x = (FL64) Cldr_DaysBetweenDates(&d_2, &next, cal, holi);    /* PMSTA-22396 - SRIDHARA � 160502 */

        /* Compute the number of days between consecutive annual coupons */
        y = (FL64) Cldr_DaysBetweenDates(&pdate, &next, cal, holi);   /* PMSTA-22396 - SRIDHARA � 160502 */

        /* Compute the number of whole calendar years between delivery
            and maturity  */
        num = (INTI) (Cldr_TermBetweenDates(&d_2, &r2, qbas,
                                            cal, eom, holi) + 0.0000001) ;   /* PMSTA-22396 - SRIDHARA � 160502 */

        accruint = coupon * (1.0 - x / y);

        oddcoupext = 0.0;
        inidiscper = x / y;

        if (effec != NULL && effec->d != 0 && redemp1 != NULL &&
            redemp1->d != 0 && Cldr_DateLT(&d_2, redemp1) && 
            stub_front != NOODD)
        {
          x2 = (FL64) Cldr_DaysBetweenDates(effec, &d_2, ACTACT, NULL);    /* PMSTA-22396 - SRIDHARA � 160502 */
          
          /* redemp1 holds the first coupon payment and determines whether the
             odd period is short or long */
          if (stub_front == SHORTODD)
          {
            /* Short odd */
            oddcoupext = -accruint;
            accruint = coupon * x2 / (y * (FL64) n);
            /* The regular coupon is lowered with the same amount as the
               accrued interest */
            oddcoupext += accruint;
          }
          else
          {
            /* Long odd */
            next = *redemp1;
            pdate = Cldr_AddMonths(&next, -months, eom);
            pdate2 = Cldr_AddMonths(&pdate, -months, eom);
			/* PMSTA-22396 - SRIDHARA � 160502 */
            x  = (FL64) Cldr_DaysBetweenDates(&d_2, &next, ACTACT, NULL);
            y  = (FL64) Cldr_DaysBetweenDates(&pdate, &next, ACTACT, NULL);
            y2 = (FL64) Cldr_DaysBetweenDates(&pdate2, &pdate, ACTACT, NULL);

            oddcoupext = (x + x2 - y) * coupon / (y2 * (FL64) n);

            if (Cldr_DateLT(&d_2, &pdate))
            {
              /* Delivery in first part of long odd period */
              accruint = x2 * coupon / (y2 * (FL64) n);
              inidiscper = 1 + (x - y) / y2;
              num--;
            }
            else
            {
              /* Delivery in last part of long odd period */
              accruint = coupon * 
                        ((x + x2 - y) / (y2 * (FL64) n) +
                        (y - x) / (y * (FL64) n));
            }
          }
        }

        /* Now compute some intermediate results  */
        z  = 1.0 + (yield / 100.0);
        z  = 1.0 / z;
        zn = pow(z, (FL64) num);
        
        /* Now compute the conversion factor */
        cf  = pow(z, inidiscper) * (coupon + oddcoupext +
                coupon * 100 / yield * (1 - zn) + 100.0 * zn ) - accruint;

        cf /= 100.0;

        break;

      case NO_CFCONV:  
          
        round_off = 1 ;
        cf = 1.0 ;
        break ;
    }

    /* Finally round off */
    scale = pow(10.0, (FL64) round_off) ;

    if (trunc == False)
      /* cf = (FL64) (floor(0.5 + cf * scale)) / scale ; */
      cf = Math_Round(cf, round_off) ; 
    else
      /* cf = (FL64) (floor(cf * scale)) / scale ; */
      cf = SCecon_floor(cf * scale) / scale ; 

    return cf ;
}


/*
..
*/

/*,,SOH,,
*************************************************************************
*
*               FutBond_PL2NPV()
*
*   interface   #include <future.h>
*               FL64 FutBond_PL2NPV(DATESTR     *analys,
*                                   DATESTR     *deliv,   
*                                   FL64        futp,
*                                   FL64        agreed_futp,
*                                   BOOLE       margin,
*                                   DISCFAC     *df) ;
*
*   general     This function calculates npv of a Bond Futures
*               
*               In case of a future, this is simply the difference
*               between the future price and the agreed price. 
*               Otherwise this is discounted from delivery to analysis
*               date.
*
*   input       DATESTR     *analys     The analysis date. 
*                                       Only used if margin is False.
*
*               DATESTR     *deliv      The delivery date.
*                                       Only used if margin is False.
*
*               FL64        futp        The future price.
*
*               FL64        agreed_futp The agreed price.
*
*               BOOLE       margin      True for Futures and False for
*                                       Forwards.
*
*               DISCFAC     *df         Discount Factor curve
*                                       Only used if margin is False.
*
*	       	    HOLI_STR    *hol	  Container for list of holidays.
*
*
*   output
*
*   returns     The net present value
*
*   diagnostics
*
*   see also    FutBond_DF2Price()
*               FutBond_YTM2Price()
*
*************************************************************************
,,EOH,,*/

FL64 FutBond_PL2NPV(DATESTR*    analys,
                    DATESTR*    deliv,
                    FL64        futp,
                    FL64        agreed_futp,
                    BOOLE       margin,
                    DISCFAC*    df,
					HOLI_STR*   holi)
{
  FL64    tmp ;

  tmp = futp - agreed_futp ;

  tmp = Disc_MarginAdjust(margin, tmp, analys, deliv, df, holi) ;  /* PMSTA-22396 - SRIDHARA � 160502 */

  return tmp ;
}


/*
..chk whether any Ex-Dividend adjustments (Gilt)
*/

DATEARRAY FutBond_Xdiv_Adjust(DATESTR* settle,
                              DATEARRAY days, 
                              INTI      ndays,
                              FIXPAY*    fixp,
                              BOOLE     xdiv3w,
                              HOLI_STR*  holi,
                              INTI*      andays) /* output */
{
    DATEARRAY pdays, adays ;
    DATESTR   next, xd, xd3, ws3, we3 ;
    INTI      count, ix, j, i ;
    HOLI_STR  hol ;

    /* Initialise */
    *andays = ndays ;
    adays   = Alloc_DATEARRAY(ndays + 2) ;

    /* Return if simple */
    if (ndays <= 1 || xdiv3w == False)
    {
       for (j = i = 0; i < ndays; i++)
       {
           if (Cldr_DateLE(settle, &days[i]) == True)
               adays[j++] = days[i] ;
       }

       *andays = j ;
       return adays ;
    }

    /* Find ex-dividend date */
    hol   = Set_HOLI_STR(NO_BUSADJUST, 0, NULL) ;
    pdays = Cflw_Paydays(&fixp->cday, &hol, &count) ;
    ix    = Cldr_FindDateIndex(pdays, count, &days[0], 0, 
                                SEARCH_FORWARDS, SAMEINDEX) ;
    ix    = GETMIN(ix, count - 1) ;
    next  = pdays[ix] ;
    xd    = Cflw_Exday(&days[0], &next, &fixp->accru.exr, holi) ;

    /* Deduct 3 weeks */
	/* PMSTA-22396 - SRIDHARA � 160502 */
    xd3 = Cldr_AddDays(&xd, (INTL) -21, ACTACT, NULL) ;

    /* Remember prev / next business date +/- 1 */
    ws3 = Cldr_AddBusinessdays(&xd3, (INTL) -2, holi->nholi, holi->holidays) ;
    we3 = Cldr_AddBusinessdays(&xd, (INTL) 2, holi->nholi, holi->holidays) ;

    /* Now adjust the period - day by day */
    for (*andays = i = 0; i < ndays; i++)
    {
        if ((Cldr_DateLT(&days[i], &ws3) == True ||
            Cldr_DateLT(&we3, &days[i]) == True) &&
            Cldr_DateLE(settle, &days[i]) == True)
        {
            adays[*andays] = days[i] ;
            ++*andays ;
        }
    }

    /* Remember period ends - first / last adjusted */
    if (ws3.m == days[0].m && Cldr_DateLE(settle, &ws3) == True)
    {
        adays[*andays] = ws3 ;
        ++*andays ;
    }

    if (we3.m == days[0].m && Cldr_DateLE(settle, &we3) == True)
    {
        adays[*andays] = we3 ;
        ++*andays ;
    }

    /* Sort ascendingly */
    Cldr_DateSort(*andays, adays, ASCENDING) ;

    /* Clean up */
    Free_DATEARRAY(pdays) ;

    /* Return */
    return adays ;
}


/*
..
*/


/*,,SOH,,
************************************************************************
*
*                Set_FUTBOND()
*
*   interface    #include <future.h>
*                FUTBOND Set_FUTBOND(INTI        ndays,
*                                    DATEARRAY   ddays,
*                                    INTI        nbond,
*                                    FIXPAYARRAY fixp,
*                                    FL64ARRAY   cf,
*                                    FL64        futp,
*                                    BOOLE       margin,
*                                    BOOLE       xdiv3w) ;
*
*   general      This routine sets the members of the struct defined
*                in the function name. The pointer members are simply
*                assigned - without physical copying. The intention
*                of the Set_*() routines is that by using this
*                functionality, one avoids setting individual members
*                of structs in the application code.
*
*                When new members are inserted in structs the Set_*()
*                routine will be changed accordingly.
*
*                One exception to this principle applies. Whenever
*                OPTADD and vanilla members are used, only the
*                vanilla members are set in the Set_*() routines. The
*                non-vanilla and exotic members are set to defaults,
*                and must be set elsewhere - if needed.
*
*                For details on the interpretation of the individual
*                struct members please check the struct definition.
*
*   input        INTI        ndays  See general section.
*
*                DATEARRAY   ddays  See general section.
*
*                INTI        nbond  See general section.
*
*                FIXPAYARRAY fixp   See general section.
*
*                FL64ARRAY   cf     See general section.
*
*                FL64        futp   See general section.
*
*                BOOLE       margin See general section.
*
*                BOOLE       xdiv3w See general section.
*
*   output
*
*   returns      The filled out FUTBOND struct
*
*   diagnostics
*
*   see also     FUTBOND
*
************************************************************************
,,EOH,,*/

FUTBOND Set_FUTBOND(INTI     ndays,
                           DATEARRAY   ddays,
                           INTI        nbond,
                           FIXPAYARRAY fixp,
                           FL64ARRAY   cf,
                           FL64        futp,
                           BOOLE       margin,
                           BOOLE       xdiv3w)
{
    FUTBOND futb ;

    futb.ndays  = ndays ;
    futb.ddays  = ddays ;
    futb.nbond  = nbond ;
    futb.fixp   = fixp ;
    futb.cf     = cf ;
    futb.futp   = futp ;
    futb.margin = margin ;
    futb.xdiv3w = xdiv3w ;

    return futb ;
}

/*
..
*/



#undef HUGE_VAL

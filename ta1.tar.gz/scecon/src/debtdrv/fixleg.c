/* SCID @(#)fixleg.c	1.8 (SimCorp) 99/02/19 14:12:55 */

/************************************************************************
*
*       project         SCecon Library
*
*       file name       fixleg.c
*
*       contains        fixed leg functions for swap calculations
*
************************************************************************/

/*** includes **********************************************************/
#include <swapval.h>


/*** defines  **********************************************************/
#define FIXRATE_FREQ      3
#define FIXRATE_DAMP      0.9
#define FIXRATE_ACC       0.00000001
#define FIXRATE_GUESS     10.0
#define FIXRATE_MIN       -1000.0
#define FIXRATE_MAX       1000.0
#define FIXRATE_EPS       0.01
#define FIXRATE_MAXIT     100



/*,,SOH,,
*************************************************************************
*
*              SwapFix_DF2Rate()
*
*    interface #include <swapval.h>
*              BOOLE SwapFix_DF2Rate(DATESTR     *analys,
*                                    FL64        npv,
*                                    SWAPFIX     *sfix,
*                                    DISCFAC     *df,
*                                    HOLI_STR    *holi,
*                                    FL64        *rate) ;
*
*    general   This function finds the implied fixed rate, swap rate,
*              for a given fixed leg and for a given npv of the
*              floating leg.
*
*              This is a general routine that uses Newton-Raphson. For
*              a routine using closed-formulae use SwapFix_DF2CFrate()
*
*              Note that stepped coupon schedules are ignored in this
*              routine.
*
*    input     DATESTR    *analys   Pointer to analysis date, ie the
*                                   day on which npv is quoted.
*
*              FL64       npv       The NPV to solve for by varying
*                                   the fixed_rate.
*
*              SWAPFIX    *sfix     Fixed leg definition
*
*              DISCFAC    *df       Discounting structure setup.
*
*              HOLI_STR   *holi     Business day adjustment setup
*
*    output    FL64       *rate     The swaprate
*
*    returns   True if solution found, False if not.
*
*    diagnostics
*
*    see also  SwapFix_GenrCflw()
*              SwapFix_DF2CFrate()
*
*    wrapper   AP
*
*************************************************************************
,,EOH,,*/


BOOLE SwapFix_DF2Rate(DATESTR*  analys,
                           FL64        npv,
                           SWAPFIX*     sfix,
                           DISCFAC*     df,
                           HOLI_STR*    holi,
                           FL64*        rate)
{
    CFLW_STR  *cflw ;
    BOOLE     ok ;
    PLAN_STR  *oldp ;
    SWAPINT   swap_data ;
    ITERCTRL  ctrl ;
    NR_ERR    err ;

    /* Warning avoidance */
    cflw = NULL;

    Init_ITERCTRL(&ctrl) ;
    ctrl.maxiter = FIXRATE_MAXIT ;
    ctrl.init_guess = FIXRATE_GUESS ;
    ctrl.lower = FIXRATE_MIN ;
    ctrl.upper = FIXRATE_MAX ;
    ctrl.damp = FIXRATE_DAMP ;
    ctrl.acc = FIXRATE_ACC ;
    ctrl.what_acc = 1 ;
    ctrl.gfreq = FIXRATE_FREQ ;
    ctrl.bisec = 2 ;
    ctrl.shock = 0.0 ;

    ok      = True ;
    *rate   = 0.0 ;

    /* Ignore stepped swaprates */
    oldp = sfix->fix.stepcoup ;
    sfix->fix.stepcoup = NULL ;

    swap_data = Swap_SetSWAPINT(analys, npv, sfix, NULL, 
      df, NULL, NULL, holi, cflw, FIXRATE_EPS) ;

	err = Newton_Raphson(&Swap_NewtonRaphson, &swap_data, &ctrl, rate, holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */
    ok = (err == NR_ROOT_FOUND ? True : False) ;

    sfix->fix.stepcoup = oldp ;
    sfix->fix.fix_rate = *rate ;

    return ok ;
}

/*
..
*/

SWAPINT Swap_SetSWAPINT(DATESTR*      analys,
                            FL64          npv,
                            SWAPFIX*      sfix,
                            SWAPFLOAT*    sfl,
                            DISCFAC*      df_disc,
                            DISCFAC*      df_cflw,
                            CMCONVADJ*    cmadj,
                            HOLI_STR*     holi,
                            CFLW_STR*     cflw,
                            FL64          shock) 
{
  SWAPINT swap_data ;

  swap_data.analys = analys ;
  swap_data.npv = npv ;
  swap_data.sfix = sfix ;
  swap_data.sfl = sfl ;
  swap_data.df_disc = df_disc ;
  swap_data.df_cflw = df_cflw ;
  swap_data.cmadj = cmadj ;
  swap_data.holi = holi ;
  swap_data.cflw = cflw ;
  swap_data.shock = shock ;

  return swap_data ;
}

/*
..
*/

void Swap_GetSWAPINT(SWAPINT*       swap_data,
                         DATESTR**      analys,
                         FL64*          npv,
                         SWAPFIX**      sfix,
                         SWAPFLOAT**    sfl,
                         DISCFAC**      df_disc,
                         DISCFAC**      df_cflw,
                         CMCONVADJ**    cmadj,
                         HOLI_STR**     holi,
                         CFLW_STR**     cflw,
                         FL64*          shock) 
{

  *analys = swap_data->analys  ;
  *npv = swap_data->npv  ;
  *sfix = swap_data->sfix  ;
  *sfl = swap_data->sfl  ;
  *df_disc = swap_data->df_disc  ;
  *df_cflw = swap_data->df_cflw  ;
  *cmadj = swap_data->cmadj  ;
  *holi = swap_data->holi  ;
  *cflw = swap_data->cflw  ;
  *shock = swap_data->shock  ;
}

/*
..
*/

BOOLE Swap_NewtonRaphson(FL64    x, 
                            void*    y,
                            BOOLE   grad,
                            FL64*    fx, 
                            FL64*    dfx,
							void*    hol) 
{
  DATESTR     *analys ;
  FL64        npv, shock, fx1 ;
  SWAPFIX     *sfix ;
  SWAPFLOAT   *sfl ;
  DISCFAC     *df_disc ;
  DISCFAC     *df_cflw ;
  CMCONVADJ   *cmadj ;
  HOLI_STR    *holi = (HOLI_STR *)hol;   /* PMSTA-29444 - SRIDHARA - 050318 */
  CFLW_STR    *cflw ;

  /* Get data from y */
  Swap_GetSWAPINT((SWAPINT*)y, &analys, &npv, &sfix, &sfl, &df_disc,
    &df_cflw, &cmadj, &holi, &cflw, &shock) ;
  shock = ((shock <= 0.0) ? FIXRATE_EPS : shock) ;


  /* Compute fx */
  if (sfl == NULL)
  {
    sfix->fix.fix_rate = x ;
    cflw = SwapFix_GenrCflw(sfix, holi) ;
	*fx = Swap_DF2NPV(analys, cflw, True, df_disc, holi) - npv;  	/* PMSTA-22396 - SRIDHARA � 160502 */
    Free_CFLWARRAY(cflw, 1) ;
  }
  else
  {
     sfl->float1.fbase.spread = x ;
     cflw = SwapFl_GenrCflw(analys, sfl, df_cflw, df_disc, cmadj, holi) ;
     *fx  = Swap_DF2NPV(analys, cflw, True, df_disc, holi) - npv ;   /* PMSTA-22396 - SRIDHARA � 160502 */
     Free_CFLWARRAY(cflw, 1) ;
  }

  /* Calculate gradient */
  if (grad == True)
  {
    if (sfl == NULL)
    {
      sfix->fix.fix_rate = x + shock;
      cflw = SwapFix_GenrCflw(sfix, holi) ;
      fx1  = Swap_DF2NPV(analys, cflw, True, df_disc, holi) - npv ;   /* PMSTA-22396 - SRIDHARA � 160502 */
      Free_CFLWARRAY(cflw, 1) ;
    }
    else
    {
       sfl->float1.fbase.spread = x + shock;
       cflw = SwapFl_GenrCflw(analys, sfl, df_cflw, df_disc, cmadj, holi) ;
       fx1  = Swap_DF2NPV(analys, cflw, True, df_disc, holi) - npv ;
       Free_CFLWARRAY(cflw, 1) ;
    }

    *dfx = (fx1 - *fx) / shock ;
  }

  return True ;
}

/*,,SOH,,
*************************************************************************
*
*              SwapFix_DF2CFrate()
*
*    interface #include <swapval.h>
*              FL64 SwapFix_DF2CFrate(DATESTR    *analys,
*                                     FL64       npv,
*                                     PAYDAYDEF  *pday,
*                                     DATESTR    *effective,
*                                     CALCONV    cal,
*                                     DISCFAC    *df,
*                                     HOLI_STR   *holi) ;
*
*    general   This function finds the implied fixed rate, swap rate,
*              for a given fixed leg and for a given npv of the
*              floating leg.
*
*              This routine uses a closed-formulae, for a more general
*              routine check-out SwapFix_DF2Rate().
*
*              To do the simple formula only simple structures are
*              handled - like plain vanilla, IMM, forward structures
*              etc.
*
*    input     DATESTR    *analys   Pointer to analysis date, ie the
*                                   day on which npv is quoted.
*
*              FL64       npv       The NPV to solve for by varying
*                                   the fixed_rate.
*
*              PAYDAYDEF  *pday     The conventions needed for payday
*                                   generation forcoupons
*
*              DATESTR    *effective The effective date of the leg.
*
*              CALCONV    cal       Calendar convention
*
*              DISCFAC    *df       Discounting structure setup.
*
*              HOLI_STR   *holi     Business day adjustment setup
*
*    output
*
*    returns   The swaprate
*
*    diagnostics
*
*    see also  SwapFix_GenrCflw()
*              SwapFix_DF2Rate()
*
*************************************************************************
,,EOH,,*/


FL64 SwapFix_DF2CFrate(DATESTR* analys,
                       FL64       npv,
                       PAYDAYDEF*  pday,
                       DATESTR*    effective,
                       CALCONV    cal,
                       DISCFAC*    df,
                       HOLI_STR*   holi)
{
    INTI      i, ndays ;
    FL64      da, fixrate, denom, daycount ;
    DATESTR   day ;
    DATEARRAY days ;
    FL64ARRAY ival ;

    /* 1.0 Generate the paydays */
    days = Cflw_Paydays(pday, holi, &ndays) ;

	/* PMSTA-22396 - SRIDHARA � 160502 */
    /* 2.0 Interpolate */
    ival = Disc_IntpolArray(days, ndays, df, holi) ;
    da   = Disc_Interpolation(analys, df, holi) ;

    /* 3.0 Find the day counts */
    for (denom = 0.0, i = 0 ; i < ndays ; i++)
    {
        if (i == 0)
            day = *effective ;
        else
            day = days[i - 1] ;

        daycount = Cldr_TermBetweenDates(&day, &days[i], 0, cal,
                                         pday->pseq.eom, holi) ;
        denom   += ival[i] * daycount ;
    }

    /* 4.0 Solve for the rate */
    if (fabs(denom) > FIXRATE_ACC)
        fixrate = (npv * da - 100.0 * ival[ndays - 1]) / denom ;
    else
        fixrate = 0.0 ;

    /* 5.0 Free memory */
    Free_DATEARRAY(days) ;
    Free_FL64ARRAY(ival) ;

    return fixrate ;
}


/*,,SOH,,
*************************************************************************
*
*              SwapFix_BONDSWAPSPR2CFrate()
*
*    interface #include <swapval.h>
*              BOOLE SwapFix_BONDSWAPSPR2CFrate(DATESTR   *analys,
*                                               FIXPAY    *fixp,
*                                               PAYDAYDEF *swapday,
*                                               CALCONV   swapcal,
*                                               FL64      bondprc,
*                                               BOOLE     is_price,
*                                               YTMCONV   *ytmc,
*                                               FL64      swapspr,
*                                               HOLI_STR  *holi,
*                                               FL64      *ytm,
*                                               FL64      *swaprate) ;
*
*    general   This function finds the implied fixed rate, swap rate,
*              for a given fixed leg based on a bond yield adjusted
*              with a swap spread.
*
*              This methodology is standard for pricing vanilla swaps
*              in the US market.
*
*              When pricing non-benchmark duration (e.g. 12Y) one can
*              can enter the bond price as a yield.
*
*              If rates are quoted of mid yields, simply find mid price
*              and use this (the error is below 6th decimal).
*
*              Only simple swap structures are handled.
*
*              Note that we have not implemented any fudged formulas
*              but only the 'true' calculation of the implied swaprate
*              given the associated bond yield.
*
*    input     DATESTR    *analys   Analysis date, (bond price date)
*
*              FIXPAY     *fixp     Bond. See BondBM_BONDBM2FIXPAY()
*                                   for translation to this format.
*
*              PAYDAYDEF  *swapday  Swap paydays.
*
*              CALCONV    swapcal   Swap Calendar convention
*
*              FL64       bondprc   The bond price or yield
*
*              BOOLE      is_price  True is bondprc is price. False if
*                                   bondprc is a yield.
*
*              YTMCONV    *ytmc     The bond yield convention
*                                   See BondBM_YTMSEG2YTMCONV().
*
*              FL64       swapspr   The swap spread
*
*              HOLI_STR   *holi     Business day adjustment setup
*
*    output    FL64       *ytm      The bond yield found
*
*              FL64       *swaprate The swaprate
*
*    returns   True if all ok, False otherwise
*
*    diagnostics
*
*    see also  SwapFix_GenrCflw()
*              SwapFix_DF2CFrate()
*              SwapFix_FUTSWAPSPR2CFrate()
*
*************************************************************************
,,EOH,,*/

/*,,SIC,,
..bondBM_BONDSEG2FIXPAY()
..BONDSEG + YTMSEG  ->->->-> evt ny function !?
..SWAPFIXBM (matur_period, cal, freq, eom)
..swapfix_simple2SWAPFIX()
..Free_SWAPFIX() routine.....
,,EIC,,*/


BOOLE SwapFix_BONDSWAPSPR2CFrate(DATESTR* analys,
                                 FIXPAY*    fixp,
                                 PAYDAYDEF* swapday,
                                 CALCONV   swapcal,
                                 FL64      bondprc,
                                 BOOLE     is_price,
                                 YTMCONV*   ytmc,
                                 FL64      swapspr,
                                 HOLI_STR*  holi,
                                 FL64*      ytm,
                                 FL64*      swaprate)
{
    BOOLE     ok ;
    FL64      pv, daycount, ydisc, denom, pv100 ;
    TRADEINFO trade ;
    ITERCTRL  ictrl ;
    INTI      qb, i ;
    FL64ARRAY terms ;
    CFLW_STR  cflw ;
    DATESTR   day ;
    HOLI_STR  noholi ;

    /* Initialise */
    ok = True ;
    *swaprate = *ytm = 0.0 ;
    Init_ITERCTRL(&ictrl) ;
    trade = bond_set_tradeinfo(analys) ;
    trade.price = bondprc ;
    noholi = Set_HOLI_STR(NO_BUSADJUST, 0, NULL) ;
    
    /* Calculate yield - Not Holiday Adjusted */
    if (is_price == True)
        ok = Bond_YTM2Yield(&trade, fixp, ytmc, &noholi, &ictrl, ytm) ;
    else
        *ytm = bondprc ;

    /* Now calculate swaprates as implied 'coupon' */
    if (ok == True)
    {
        /* Adjust for swap spreads */
        ydisc = *ytm + swapspr ;

        /* Genr. swapdays */
        cflw.repay = cflw.coupon = NULL ;
        cflw.days  = Cflw_Paydays(swapday, &noholi, &cflw.filled) ;
        terms      = Bond_GenrTerms(analys, &cflw, ytmc, swapday, holi) ;

        /* YTM quoting */
        qb = disc_set_qbas(ytmc->qb_ytm) ;

        /* Loop to find coefficients */
        for (denom = pv100 = 0.0, i = 0 ; i < cflw.filled; i++)
        {
            if (i == 0)
                day = *analys ;
            else
                day = cflw.days[i - 1] ;

            daycount = Cldr_TermBetweenDates(&day, &cflw.days[i], 0, swapcal,
                                             swapday->pseq.eom, holi) ;  /* PMSTA-22396 - SRIDHARA � 160502 */
            pv       = TVMunit_NPV(terms[i], ydisc, ytmc->irr, qb) ;
            denom   += daycount * pv ;

            if (i == cflw.filled - 1)
                pv100 = 100.0 * pv ;
        }                                            

        /* Calculate rate */
        if (fabs(denom) > FIXRATE_ACC)
            *swaprate = (100.0 - pv100) / denom ;
        else
            *swaprate = 0.0 ;

        Free_DATEARRAY(cflw.days) ;
        Free_FL64ARRAY(terms) ;
    }

    return ok ;
}


/*,,SOH,,
*************************************************************************
*
*              SwapFix_FUTSWAPSPR2CFrate()
*
*    interface #include <swapval.h>
*               BOOLE SwapFix_FUTSWAPSPR2CFrate(DATESTR   *analys,
*                                               DATESTR   *deliv,
*                                               FIXPAY    *fixp,
*                                               FL64      cf,
*                                               PAYDAYDEF *swapday,
*                                               CALCONV   swapcal,
*                                               FL64      futp,
*                                               FL64      repo,
*                                               YTMCONV   *ytmc_repo,
*                                               YTMCONV   *ytmc,
*                                               FL64      swapspr,
*                                               HOLI_STR  *holi,
*                                               FL64      *ytm,
*                                               FL64      *swaprate) ;
*
*    general   This function finds the implied fixed rate, swap rate,
*              for a given fixed leg based on a bond yield adjusted
*              with a swap spread. The bond yield is derived from a
*              bond futures price.
*
*              If rates are quoted of mid yields, simply find mid price
*              and use this (the error is below 6th decimal).
*
*              Only simple swap structures are handled.
*
*              Note that we have not implemented any fudged formulas
*              but only the 'true' calculation of the implied swaprate
*              given the associated bond yield.
*
*              For CTD futures the CTD bond and the delivery date must
*              have been found prior to calling this routine.
*
*    input     DATESTR    *analys   Analysis date, (bond price date)
*
*              DATESTR    *deliv    The futures delivery date
*
*              FIXPAY     *fixp     CTD Bond. See BondBM_BONDBM2FIXPAY()*
*                                   for translation to this format.
*
*              FL64       cf        Conversion factor for CTD bond
*
*              PAYDAYDEF  *swapday  Swap paydays.
*
*              CALCONV    swapcal   Swap Calendar convention
*
*              FL64       futp      The futures price
*
*              FL64       repo      The repo rate for the future
*
*              YTMCONV    *ytmc_repo The repo yield convention
*
*              YTMCONV    *ytmc     The bond yield convention
*                                   See BondBM_YTMSEG2YTMCONV().
*
*              FL64       swapspr   The swap spread
*
*              HOLI_STR   *holi     Business day adjustment setup
*
*    output    FL64       *ytm      The bond yield found
*
*              FL64       *swaprate The swaprate
*
*    returns   True if all ok, False otherwise
*
*    diagnostics
*
*    see also  SwapFix_GenrCflw()
*              SwapFix_DF2CFrate()
*              SwapFix_BONDSWAPSPR2CFrate()
*
*************************************************************************
,,EOH,,*/


BOOLE SwapFix_FUTSWAPSPR2CFrate(DATESTR* analys,
                                DATESTR*   deliv,
                                FIXPAY*    fixp,
                                FL64      cf,
                                PAYDAYDEF* swapday,
                                CALCONV   swapcal,
                                FL64      futp,
                                FL64      repo,
                                YTMCONV*   ytmc_repo,
                                YTMCONV*   ytmc,
                                FL64      swapspr,
                                HOLI_STR*  holi,
                                FL64*      ytm,
                                FL64*      swaprate)
{
    BOOLE     ok ;
    DFPARMS   dfp ;
    DISCFAC   df ;
    TRADEINFO trade ;
    ITERCTRL  ictrl ;
    FL64      spot ;

    /* Initialise */
    ok    = True ;
    trade = bond_set_tradeinfo(analys) ;
    Init_ITERCTRL(&ictrl) ;
/*
..put next 10 lines in futBond_CCREPO2price() / impl()
*/
    /* Translate repo to DF */
    dfp = Set_DFPARMS(DI_SPOT, LINEAR_FLAT_END,
                           ytmc_repo->cal_first,
                           ytmc_repo->irr, ytmc_repo->qb_ytm) ;
    df  = Disc_TS2DF(analys, deliv, &repo, 1, &dfp, holi) ;    /* PMSTA-22396 - SRIDHARA � 160502 */

    /* Now find the spot price */
    ok = FutBond_CC2Impl(&trade, deliv, futp, cf, fixp, holi, NULL,
                         &df, ytmc_repo, &ictrl, KEY_SPOT, &spot) ;

    /* Find swap rate */
    if (ok == True)
        ok = SwapFix_BONDSWAPSPR2CFrate(analys, fixp, swapday, swapcal,
                                        spot, True, ytmc, swapspr, holi,
                                        ytm, swaprate) ;

    /* Clean up */
    Free_PLANARRAY(df.disc, 1) ;

    return ok ;
}


/*,,SOH,,
*************************************************************************
*
*              SwapFix_DF2SwapCurve()
*
*    interface #include <swapval.h>
*              FL64ARRAY SwapFix_DF2SwapCurve(DISCFAC   *df,
*                                             DATESTR   *forw,
*                                             INTIARRAY months,
*                                             INTI      nt,
*                                             CALCONV   cal,
*                                             PAYDAYSEQ *pseq,
*                                             HOLI_STR  *holi) ;
*
*    general   This function finds the par swap curve at any future
*              point in time for the specified swap structures.
*
*    input     DISCFAC    *df       Discounting structure setup.
*
*              DATESTR    *forw     The forward date for the curve
*
*              INTIARRAY  months    List of swap maturities in MONTHS.
*
*              INTI       nt        No. of elements in months.
*
*              CALCONV    cal       Calendar convention
*
*              PAYDAYSEQ  *pseq     Paydays sequencing convention
*
*              HOLI_STR   *holi     Business day adjustment setup
*
*    output
*
*    returns   List of swaprates as FL64ARRAY allocated as:
*                         Alloc_FL64ARRAY(nt)
*
*    diagnostics
*
*    see also  SwapFix_GenrCflw()
*              SwapFix_DF2CFrate()
*
*************************************************************************
,,EOH,,*/


FL64ARRAY SwapFix_DF2SwapCurve(DISCFAC* df,
                         DATESTR*   forw,
                         INTIARRAY months,
                         INTI      nt,
                         CALCONV   cal,
                         PAYDAYSEQ* pseq,
                         HOLI_STR*  holi)
{
    INTI       i ;
    FL64ARRAY  fs ;
    PAYDAYDEF  pday ;
    PERIOD     per ;

    pday  = Set_PAYDAYDEF(True, forw, NULL, forw, False, pseq, 0, NULL) ;
    fs    = Alloc_FL64ARRAY(nt) ;

    for (i = 0; i < nt; i++)
    {
        per       = Set_PERIOD(months[i], MONTHS) ;
        pday.last = Cldr_NextROLL(forw, pseq->seq, &per, cal, pseq->eom, holi);

        /* Calculate rate */
        fs[i] = SwapFix_DF2CFrate(forw, 100.0, &pday, forw, cal, df, holi) ;
    }

    return fs ;
}



#undef FIXRATE_FREQ
#undef FIXRATE_DAMP
#undef FIXRATE_ACC
#undef FIXRATE_GUESS
#undef FIXRATE_MIN
#undef FIXRATE_MAX
#undef FIXRATE_EPS
#undef FIXRATE_MAXIT

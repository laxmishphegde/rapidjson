/* SCID @(#)tstmm.c	1.3 (SimCorp) 99/02/19 14:14:03 */

/************************************************************************
*
*   project     SCecon
*
************************************************************************/

/*** includes **********************************************************/
#include <string.h>
#include <stdio.h>

#include <mm.h>
#include <futio.h>


INTI mmtest(char* txa, FILE* in, FILE* out)
{
    char        txc[25], txe[25], txpl[120] ;
    CALCONV     cal ;
    QOTCONV     qc ;
    INTI        nbuck, i, diff ;
    DATESTR     analys, dateinput1, dateinput2 ;
    YYYYMMDD    yyyymmdd1, yyyymmdd2, ymd ;
    FL64        fexp, fres, acc, p, rate2, disc, fres1, fres2,
                fexp1, fexp2, *dv ;
    HOLI_STR    holi ;
    DISCFAC     df ;
    RISKSET     rs ;
    FRA_STR     fra ;
    BUCKETARRAY bucket ;
    DELTASET    ds ;
    BOOLE       ok ;
    KEYCONV     key;

    acc = 0.00001 ;
    diff = -1 ;

    if (!strcmp("MM_AnnForw2Qot()", txa))
    {
        fscanf(in, "%lf %lf %ld %ld %s %s %lf %s", &fexp, &disc,
               &yyyymmdd1, &yyyymmdd2, txc, txe, &p, txpl);

        cal = Str2CALCONV(txc) ;
        qc  = Str2QOTCONV(txe) ;
        dateinput1 = Cldr_YMD2Datestr(yyyymmdd1);
        dateinput2 = Cldr_YMD2Datestr(yyyymmdd2);

		fres = MM_AnnForw2Qot(disc, &dateinput1, &dateinput2, cal, qc, p, &holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */

        diff = (fabs(fres - fexp) > acc);

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   disc.factor   %4.4lf\n", disc) ;
        fprintf(out,"   settlement    %8ld\n", yyyymmdd1) ;
        fprintf(out,"   maturity      %8ld\n", yyyymmdd2) ;
        fprintf(out,"   cal           %8s\n", txc) ;
        fprintf(out,"   qouting       %8s\n", txe) ;
        fprintf(out,"   price annforw %4.4lf\n", p) ;
        fprintf(out,"   result is %8lf ; expected is %8lf\n", fres, fexp) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }

    else if (!strcmp("FRA_DF2Rate()", txa))
    {
        fscanf(in, "%lf", &fexp) ;
        fprintf(out,"  testing %s\n", txa) ;

        fra  = Read_FRA_STR(in, out) ;
        df   = Read_DISCFAC(in, out) ;
        holi = Read_HOLI_STR(in, out) ;
        fscanf(in, "%s", txpl) ;

        fres = FRA_DF2Rate(&fra, &df, &holi);

        diff = (fabs(fres - fexp) > acc);
        fprintf(out,
          "%d; result is %8lf ; expected is %8lf\n",
          diff, fres, fexp) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_DATEARRAY(holi.holidays) ;
        Free_PLANARRAY(df.disc, 1) ;
    }

    else if (!strcmp("FRA_DF2Impl()", txa))
    {
        fscanf(in, "%lf %ld", &fexp, &ymd) ;
        fprintf(out,"  testing %s\n", txa) ;
        fprintf(out,"   Analysis:        %8ld\n", ymd) ;            
        analys = Cldr_YMD2Datestr(ymd) ;            

        fra  = Read_FRA_STR(in, out) ;                        
        df   = Read_DISCFAC(in, out) ;
        holi = Read_HOLI_STR(in, out) ;
        fscanf(in, "%s", txc) ;
        fprintf(out,"   KeyRatio         %s\n", txc) ;
        key = Str2KEYCONV(txc) ;
        fscanf(in, "%s", txpl) ;                                  

        ok = FRA_DF2Impl(&analys, &fra, &df, &holi, key, &fres) ;

        diff = (fabs(fres - fexp) > acc) && ok == True ;
        fprintf(out,"%d; result is %8lf ; expected is %8lf\n", 
                    diff, fres, fexp) ;            
        fprintf(out,"   %s\n\n", txpl) ;

        Free_DATEARRAY(holi.holidays) ;
        Free_PLANARRAY(df.disc, 1) ;
    }

    else if (!strcmp("FRA_FRABBA2NPV()", txa))
    {
        fscanf(in, "%lf %ld", &fexp, &ymd) ;
        fprintf(out,"  testing %s\n", txa) ;
        fprintf(out,"   Analysis:        %8ld\n", ymd) ;
        analys = Cldr_YMD2Datestr(ymd) ;

        fra  = Read_FRA_STR(in, out) ;

        fscanf(in, "%lf", &rate2) ;
        fprintf(out,"   Settlement Rate  %8lf\n", rate2) ;
        df   = Read_DISCFAC(in, out) ;
        holi = Read_HOLI_STR(in, out) ;
        fscanf(in, "%s", txpl) ;

        fres = FRA_FRABBA2NPV(&analys, &fra, rate2, &df, &holi) ;

        diff = (fabs(fres - fexp) > acc);
        fprintf(out, "%d; result is %8lf ; expected is %8lf\n",
                diff, fres, fexp) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_DATEARRAY(holi.holidays) ;
        Free_PLANARRAY(df.disc, 1) ;
    }

    else if (!strcmp("FRA_DF2NPV()", txa))
    {
        fscanf(in, "%lf %lf %lf %ld", &fexp, &fexp1, &fexp2, &ymd) ;
        fprintf(out,"  testing %s\n", txa) ;
        fprintf(out,"   Analysis:        %8ld\n", ymd) ;
        analys = Cldr_YMD2Datestr(ymd) ;

        fra = Read_FRA_STR(in, out) ;

        df   = Read_DISCFAC(in, out) ;
        holi = Read_HOLI_STR(in, out) ;
        rs   = Read_RISKSET(in, out) ;
        fscanf(in, "%s", txpl) ;

        fres = FRA_DF2NPV(&analys, &fra,
                            &df, &holi, &rs, &fres1, &fres2) ;

        diff = (fabs(fres - fexp) > acc)   ||
               (fabs(fres1 - fexp1) > acc) ||
               (fabs(fres2 - fexp2) > acc) ;

        fprintf(out,"%d; result is %8lf ; expected is %8lf\n",
                fabs(fres - fexp) > acc, fres, fexp) ;
        fprintf(out,"%d;    result is %8lf ; expected is %8lf\n",
                fabs(fres1 - fexp1) > acc, fres1, fexp1) ;
        fprintf(out,"%d;    result is %8lf ; expected is %8lf\n",
                fabs(fres2 - fexp2) > acc, fres2, fexp2) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_RISKSET(&rs) ;
        Free_DATEARRAY(holi.holidays) ;
        Free_PLANARRAY(df.disc, 1) ;
    }

    else if (!strcmp("FRA_DF2Delta()", txa))
    {
        fscanf(in, "%ld", &ymd) ;
        fprintf(out,"  testing %s\n", txa) ;
        fprintf(out,"   Analysis:        %8ld\n", ymd) ;
        analys = Cldr_YMD2Datestr(ymd) ;

        fra  = Read_FRA_STR(in, out) ;
        df   = Read_DISCFAC(in, out) ;
        holi = Read_HOLI_STR(in, out) ;
        bucket = Read_BUCKETARRAY(in, out, &nbuck) ;

        ds = Disc_DeltaPrep(&df, bucket, nbuck, &holi, False, df.irr,
                             df.freq, False, False, DF_BOTH) ;
        dv = FRA_DF2Delta(&analys, &fra, &df, &holi, &ds) ;

        diff = 0 ;
        for (i = 0; i < nbuck; i++)
        {
            fscanf(in, "%lf", &fexp) ;
            diff = diff || (fabs(fexp - dv[i]) > 0.00001) ;
            fprintf(out, "%d; %d exp %lf res %lf\n",
                    (fabs(fexp - dv[i]) > 0.00001), i, fexp, dv[i]) ;
        }

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_DATEARRAY(holi.holidays) ;
        Free_FL64ARRAY(dv) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_DELTASET(&ds) ;
        Free_BUCKETARRAY(bucket) ;
    }

    else if (!strcmp("IRF_DF2Price()", txa))
    {
        fscanf(in, "%lf", &fexp) ;
        fprintf(out,"  testing %s\n", txa) ;

        fra  = Read_FRA_STR(in, out) ;
        df   = Read_DISCFAC(in, out) ;
        holi = Read_HOLI_STR(in, out) ;
        fscanf(in, "%s", txpl) ;

        fres = IRF_DF2Price(&fra, &df, &holi);

        diff = (fabs(fres - fexp) > acc);
        fprintf(out,
          "%d; result is %8lf ; expected is %8lf\n",
          diff, fres, fexp) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_DATEARRAY(holi.holidays) ;
        Free_PLANARRAY(df.disc, 1) ;
    }

    else if (!strcmp("IRF_FRABBA2NPV()", txa))
    {
        fscanf(in, "%lf %ld", &fexp, &ymd) ;
        fprintf(out,"  testing %s\n", txa) ;
        fprintf(out,"   Analysis:        %8ld\n", ymd) ;
        analys = Cldr_YMD2Datestr(ymd) ;

        fra  = Read_FRA_STR(in, out) ;

        fscanf(in, "%lf", &rate2) ;
        fprintf(out,"   Settlement Rate  %8lf\n", rate2) ;
        holi = Read_HOLI_STR(in, out) ;
        fscanf(in, "%s", txpl) ;

        fres = IRF_FRABBA2NPV(&analys, &fra, rate2, &holi) ;

        diff = (fabs(fres - fexp) > acc);
        fprintf(out,  "%d; result is %8lf ; expected is %8lf\n",
                diff, fres, fexp) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_DATEARRAY(holi.holidays) ;
    }

    else if (!strcmp("IRF_DF2NPV()", txa))
    {
        fscanf(in, "%lf %lf %lf %ld", &fexp, &fexp1, &fexp2, &ymd) ;
        fprintf(out,"  testing %s\n", txa) ;
        fprintf(out,"   Analysis:        %8ld\n", ymd) ;
        analys = Cldr_YMD2Datestr(ymd) ;

        fra  = Read_FRA_STR(in, out) ;
        df   = Read_DISCFAC(in, out) ;
        holi = Read_HOLI_STR(in, out) ;
        rs   = Read_RISKSET(in, out) ;
        fscanf(in, "%s", txpl) ;

        fres = IRF_DF2NPV(&analys, &fra, &df, &holi, &rs, &fres1, &fres2) ;

        diff = (fabs(fres - fexp) > acc)   ||
               (fabs(fres1 - fexp1) > acc) ||
               (fabs(fres2 - fexp2) > acc) ;

        fprintf(out,"%d; result is %8lf ; expected is %8lf\n",
                fabs(fres - fexp) > acc, fres, fexp) ;
        fprintf(out,"%d;    result is %8lf ; expected is %8lf\n",
                fabs(fres1 - fexp1) > acc, fres1, fexp1) ;
        fprintf(out,"%d;    result is %8lf ; expected is %8lf\n",
                fabs(fres2 - fexp2) > acc, fres2, fexp2) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_RISKSET(&rs) ;
        Free_DATEARRAY(holi.holidays) ;
        Free_PLANARRAY(df.disc, 1) ;
    }

    else if (!strcmp("IRF_DF2Delta()", txa))
    {
        fscanf(in, "%ld", &ymd) ;
        fprintf(out,"  testing %s\n", txa) ;
        fprintf(out,"   Analysis:        %8ld\n", ymd) ;
        analys = Cldr_YMD2Datestr(ymd) ;

        fra  = Read_FRA_STR(in, out) ;
        df   = Read_DISCFAC(in, out) ;
        holi = Read_HOLI_STR(in, out) ;
        bucket = Read_BUCKETARRAY(in, out, &nbuck) ;

        ds = Disc_DeltaPrep(&df, bucket, nbuck, &holi, False, df.irr,
                             df.freq, False, False, DF_BOTH) ;
        dv = IRF_DF2Delta(&analys, &fra, &df, &holi, &ds) ;

        diff = 0 ;
        for (i = 0; i < nbuck; i++)
        {
            fscanf(in, "%lf", &fexp) ;
            diff = diff || (fabs(fexp - dv[i]) > 0.00001) ;
            fprintf(out, "%d; %d exp %lf res %lf\n",
                    (fabs(fexp - dv[i]) > 0.00001), i, fexp, dv[i]) ;
        }

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_DATEARRAY(holi.holidays) ;
        Free_FL64ARRAY(dv) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_DELTASET(&ds) ;
        Free_BUCKETARRAY(bucket) ;
    }


    return diff ;
}

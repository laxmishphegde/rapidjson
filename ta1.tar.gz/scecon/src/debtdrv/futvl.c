/* SCCS @(#)futvl.c	1.7 (SimCorp) 99/06/14 10:50:46 */

/************************************************************************
*
*   project     SCecon
*
*   general     This file contains routines for validating the
*               content of the data structures of SCecon
*
************************************************************************/

/*** includes **********************************************************/
#include <futvl.h>
#include <bondvl.h>
#include <validate.h>

/*** defines ***********************************************************/
#define valid_tol 0.000001



/*,,SOH,,
***********************************************************************
*                                                                      
*               Validate_CFCONV()
*                                                                      
*   interface   #include <futvl.h>                                  
*               BOOLE     Validate_CFCONV(CFCONV r)              
*                                                                      
*   general     This function validates the content of the CFCONV
*               data structure                                         
*                                                                      
*   input       CFCONV  r  The CFCONV data structure
*                                                                      
*   output                                                             
*                                                                      
*   returns     True if r is a valid CFCONV, False if invalid       
*                                                                      
*   diagnostics                                                        
*                                                                      
*   see also    CFCONV
*                                                                      
***********************************************************************
,,EOH,,*/
BOOLE Validate_CFCONV(CFCONV  r)
{
    /* check that r is valid */
    switch (r)
    {
    case NO_CFCONV:
    case CBOT_T_BOND:
    case CBOT_T_NOTE:
    case CBOT_CGB:
    case LIFFE_GILT:
    case LIFFE_BUND:
    case LIFFE_JGB:
    case LIFFE_BTP:
    case EUREX_BUND:
    case EUREX_SGB:
    case MATIF_NOT:
    case MIF_BTP:
    case OM_STAT:
    case MEFF_BONOS:
    case ME_CGB:
    case TSE_T_BOND:
    case TSE_JGB:
    case SIMEX_JGB:

      return True ;
    default:    
        return False ;    
    }
}


/*,,SOH,,
*************************************************************************
*
*               Validate_CMADJTYPE()
*
*   interface   #include <futvl.h>
*               BOOLE     Validate_CMADJTYPE(CMADJTYPE r)
*
*   general     This function validates the content of the CMADJTYPE
*               data structure
*
*   input       CMADJTYPE  r  The CMADJTYPE data structure
*
*   output
*
*   returns     True if r is a valid CMADJTYPE, False if invalid
*
*   diagnostics
*
*   see also    CMADJTYPE
*
*************************************************************************
,,EOH,,*/


BOOLE Validate_CMADJTYPE(CMADJTYPE r)
{
    /* check that r is valid */
    switch (r)
    {
        case NO_CMADJ:
        case CMADJ_ORIG:
        case CMADJ_PRATE:
        case CMADJ_4TH:
        case CMADJ_4THCORR:
            return True ;
            break ;
        default :
            return False ;
            break ;
    }
}


/*,,SOH,,
*************************************************************************
*
*               Validate_COMPMETHOD()
*
*   interface   #include <futvl.h>
*               BOOLE Validate_COMPMETHOD(COMPMETHOD c)
*
*   general     This function validates the content of the COMPMETHOD
*               data structure
*
*   input       COMPMETHOD   c    The COMPMETHOD data structure
*
*   output
*
*   returns     True if c is a valid COMPMETHOD, False if invalid
*
*   diagnostics
*
*   see also    COMPMETHOD
*
*************************************************************************
,,EOH,,*/

BOOLE Validate_COMPMETHOD(COMPMETHOD c)
{
    switch (c)
    {
        case NONE:
        case REGCOMPOUND:
        case FLAT:
        case TAM:
        case DECOMPOUND:
            return True ;
        default:
            return False ;
    }
}


/*,,SOH,,
*************************************************************************
*
*               Validate_QOTCONV()
*
*   interface   #include <futvl.h>
*               BOOLE Validate_QOTCONV(QOTCONV qotconv)
*
*   general     This function validates the content of the QOTCONV
*               data structure
*
*   input       QOTCONV qotconv   The QOTCONV data structure
*
*   output
*
*   returns     True if qotconv is a valid QOTCONV, False if invalid
*
*   diagnostics
*
*   see also    QOTCONV
*
*************************************************************************
,,EOH,,*/


BOOLE Validate_QOTCONV(QOTCONV qotconv)
{
    /* check that qotconv is a valid QOTCONV */
    switch (qotconv)
    {
        case Q_FLAT :
        case Q_FLATFORW :
        case Q_PERANNUM :
        case Q_PERANNUMFORW :
            return True ;
        default :
            return False ;
    }
}



/*,,SOH,,
***********************************************************************
*                                                                      
*               Validate_CTDRES()
*                                                                      
*   interface   #include <futvl.h>                                  
*               VALIDATE Validate_CTDRES(CTDRES *x)
*                                                                      
*   general     This function validates the content of the CTDRES
*               data structure                                         
*                                                                      
*   input       CTDRES *x   The CTDRES structure.
*                                                                      
*   output                                                             
*                                                                      
*   returns     Valid_data if the content of CTDRES is 
*               valid.
*                                                                      
*   diagnostics
*               Refer to CTDRES for a specification of valid data.
*              
*   see also    CTDRES
*                                                                      
***********************************************************************
,,EOH,,*/
VALIDATE Validate_CTDRES(CTDRES*  x)
{
    VALIDATE v;

    if (Validate_BOOLE(x->ok) == False)
        return Invalid_boole;

    v = Validate_FL64ARRAY(x->fwd_rpo, x->ndeliv, False, 0.0, False, 
      0.0);
    if (v != Valid_data)
        return v;

    v = Validate_DATEARRAY(x->deliv, x->ndeliv);
    if (v != Valid_data)
        return v;

    /* TODO: Validate CTDix as well ? */

    return Valid_data;
}



/*,,SOH,,
*************************************************************************
*
*               Validate_FRA_STR()
*
*   interface   #include <futvl.h>
*               VALIDATE Validate_FRA_STR(FRA_STR *fra) ;
*
*   general     This function validates the content of the FRA_STR
*               data structure
*
*   input       FRA_STR *fra      The FRA_STR data structure
*
*   output
*
*   returns     Valid_data if the content of fra_str is valid,
*               Invalid_settl if settl is an invalid date,
*               Invalid_matur if matur is an invalid date,
*               Invalid_cal if cal is an invalid CALCONV,
*               Invalid_fra if fra is not True or False,
*               Invalid_price_fra if fra is True and price < 0,
*               Invalid_qot if qot is an invalid QOTCONV,
*               Invalid_price_irf if fra is False and price > 100,
*               Invalid_freq if freq is an invalid PMTFREQ
*
*   diagnostics
*
*   see also    FRA_STR
*
*************************************************************************
,,EOH,,*/


VALIDATE Validate_FRA_STR(FRA_STR* fra)
{
    /* check that settl is a valid date */
    if (Cldr_CheckDate(&fra->settl) == False)
        return Invalid_settl ;

    /* check that matur is a valid date */
    if (Cldr_CheckDate(&fra->matur) == False)
        return Invalid_matur ;

    /* check that cal is a valid CALCONV */
    if (Validate_CALCONV(fra->cal) == False)
        return Invalid_cal ;

    /* check that cal is a valid FRATYPE */
    if (Validate_RATECONV(fra->type) == False)
        return Invalid_rateconv ;

    /* check that fra is True or False */
    if (fra->fra != False && fra->fra != True)
        return Invalid_fra ;

    /* check that price is valid and qot resp. freq is a valid QOTCONV resp.
      PMTFREQ */
    if (fra->fra == True)
    {
        /* if fra is True the price should be greater than or equal to 0 */
        if (fra->price < -valid_tol)
            return Invalid_price_fra ;
        else if (Validate_QOTCONV(fra->qot) == False)
            return Invalid_qot ;

        if (Cldr_CheckDate(&fra->pay) == False)
            return Invalid_payday ;

        /* check that settl is earlier than or equal to payday */
        if (Cldr_DateLT(&fra->pay, &fra->settl) == True)
            return Settl_after_payday ;
    }
    else
    {
        /* if fra is False the price should be less than or equal to 100 */
        if (fra->price > 100.0 + valid_tol)
            return Invalid_price_irf ;
        else if (Validate_PMTFREQ(fra->freq) == False)
            return Invalid_freq ;
    }

    return Valid_data ;
}


/*,,SOH,,
*************************************************************************
*
*               Validate_FRN()
*
*   interface   #include <futvl.h>
*               VALIDATE Validate_FRN(FRN *frn)
*
*   general     This function validates the content of the FRN
*               data structure
*
*   input       FRN    *frn     The FRN data structure
*
*   output
*
*   returns     Valid_data if the content of frn is valid,
*               If the content of any of the data structures PAYDAYDEF,
*                   FLOATRATE, or REPAYMNT is invalid an error message
*                   from one of the corresponding validation routines
*                   is returned
*
*   diagnostics
*
*   see also    FRN
*
*************************************************************************
,,EOH,,*/

VALIDATE Validate_FRN(FRN* frn)
{
    VALIDATE v ;

    v = Validate_PAYDAYDEF(&frn->pday, False) ;
    if (v != Valid_data)
        return v ;

    v = Validate_FLOATRATE(&frn->float1) ;
    if (v != Valid_data)
        return v ;

    v = Validate_PAYDAYDEF(&frn->rday, True) ;
    if (v != Valid_data)
        return v ;

    v = Validate_REPAYMNT(&frn->repay, &frn->pday.last, True, True) ;
    if (v != Valid_data)
        return v ;

    return Valid_data ;
}


/*,,SOH,,
*************************************************************************
*
*               Validate_FUTBOND()
*
*   interface   #include <futvl.h>
*               VALIDATE Validate_FUTBOND(FUTBOND *f)
*
*   general     This function validates the content of the FUTBOND data
*               structure
*
*   input       FUTBOND   *f      The FUTBOND data structure
*
*   output
*
*   returns     Valid_data if the content of c is valid
*               Invalid_filled if ndays < 0
*               If the content of ddays is invalid an error message
*                    from Validate_DATEARRAY() is returned
*               Invalid_filled if nbond < 0
*               If the content of fixp is invalid an error message
*                    from Validate_FIXPAY() is returned
*               Out_of_range if any of the entries in cf is <= 0
*               Invalid_price if futp < valid_tol
*               Invalid_boole if margin is not True or False
*
*   diagnostics
*
*   see also    FUTBOND
*
*************************************************************************
,,EOH,,*/

VALIDATE Validate_FUTBOND(FUTBOND* f)
{
    VALIDATE v ;
    BOOLE    ok = True ;
    INTI     i ;

    if (f->ndays < 0)
        return Invalid_filled ;

    v = Validate_DATEARRAY(f->ddays, f->ndays) ;
    if (v != Valid_data)
        return v ;

    if (f->nbond < 0)
        return Invalid_filled ;

    for (i = 0; i < f->nbond && ok == True; i++)
    {
        v = Validate_FIXPAY(&f->fixp[i], True) ;
        if (v != Valid_data)
            ok = False ;
    }
    if (ok == False)
        return v ;

    v = Validate_FL64ARRAY(f->cf, f->nbond, True, 0, False, 0) ;
    if (v != Valid_data)
        return v ;

    if (f->futp < -valid_tol)
        return Invalid_price ;

    if (!Validate_BOOLE(f->margin))
        return Invalid_boole ;

    if (!Validate_BOOLE(f->xdiv3w))
        return Invalid_boole ;

    return Valid_data ;
}


/*,,SOH,,
***********************************************************************
*                                                                      
*               Validate_FUTBONDBM()
*                                                                      
*   interface   #include <futvl.h>                                  
*               VALIDATE Validate_FUTBONDBM(FUTBONDBM *x)
*                                                                      
*   general     This function validates the content of the 
*               FUTBONDBM data structure
*                                                                      
*   input       FUTBONDBM *x     The FUTBONDBM data structure
*                                                                      
*   output                                                             
*                                                                      
*   returns     Valid_data if the content of FUTBONDBM is valid.
*                                                                      
*   diagnostics
*               Refer to FUTBONDBM for a specification of valid 
*               data.
*              
*   see also    FUTBONDBM
*                                                                      
***********************************************************************
,,EOH,,*/

VALIDATE Validate_FUTBONDBM(FUTBONDBM*  x)
{
    VALIDATE v;

    if (x->cf != NULL)
    {
        v = Validate_FL64ARRAY(x->cf, x->nbond, True, -valid_tol, 
            False, 0.0);
        if (v != Valid_data)
          return v;
    }

    v = Validate_BONDBMARRAY(x->bonds, x->nbond);
    if (v != Valid_data)
      return v;

    if (Cldr_CheckDate(&x->first) == False)
        return Invalid_first ;

    if (Cldr_CheckDate(&x->last) == False)
        return Invalid_last ;

    if (Validate_CFCONV(x->cntr) == False)
        return Invalid_cfconv ;

    if (!Validate_BOOLE(x->do_cf))
        return Invalid_boole ;

    return Valid_data;
}



/*,,SOH,,
*************************************************************************
*
*               Validate_REPOBOND()
*
*   interface   #include <futvl.h>
*               VALIDATE Validate_REPOBOND(REPOBOND *r)
*
*   general     This function validates the content of the REPOBOND
*               data structure
*
*   input       REPOBOND  *r      The REPOBOND data structure
*
*   output
*
*   returns     Valid_data if the content of r is valid,
*               Invalid_boole if reverse is not True or False
*               Invalid_sell_date if sell_date is an invalid DATESTR
*               Invalid_buy_date if buy_date is an invalid DATESTR
*               Invalid_cal if cal is an invalid calendar convention
*               Invalid_repo_period if sell date is later then buy_date
*               If bond is an invalid fixpay an error message from
*                   Validate_FIXPAY() is returned
*
*   diagnostics
*
*   see also    REPOBOND
*
*************************************************************************
,,EOH,,*/


VALIDATE Validate_REPOBOND(REPOBOND* r)
{
    VALIDATE tmp ;

    if (Validate_BOOLE(r->reverse) == False)
        return Invalid_boole ;

    if (Cldr_CheckDate(&r->sell_date) == False)
        return Invalid_sell_date ;

    if (Cldr_CheckDate(&r->buy_date) == False)
        return Invalid_buy_date ;

    if (Validate_CALCONV(r->cal) == False)
        return Invalid_cal ;

    if (Validate_IRRCONV(r->irr) == False)
        return Invalid_irr ;

    if (Cldr_DateLE(&r->sell_date, &r->buy_date) == False)
        return Invalid_repo_period ;

    tmp = Validate_FIXPAY(&r->bond, True) ;
    if (tmp != Valid_data)
        return tmp ;

    return Valid_data ;
}


/*,,SOH,,
*************************************************************************
*
*               Validate_SWAPFLOAT()
*
*   interface   #include <futvl.h>
*               VALIDATE Validate_SWAPFLOAT(SWAPFLOAT *fixpay)
*
*   general     This function validates the content of the SWAPFLOAT
*               data structure
*
*   input       SWAPFLOAT *fixpay The SWAPFLOAT data structure
*
*   output
*
*   returns     Valid_data if the content of fixpay is valid,
*               If the content of any of the data structures PAYDAYDEF,
*                   FLOATRATE, or REPAYMNT is invalid an error message
*                   from one of the corresponding validation routines
*                   is returned
*
*   diagnostics
*
*   see also    SWAPFLOAT
*
*************************************************************************
,,EOH,,*/


VALIDATE Validate_SWAPFLOAT(SWAPFLOAT* fixpay)
{
    VALIDATE v ;

    v = Validate_PAYDAYDEF(&fixpay->pday, False) ;
    if (v != Valid_data)
        return v ;

    v = Validate_FLOATRATE(&fixpay->float1) ;
    if (v != Valid_data)
        return v ;

    v = Validate_PAYDAYDEF(&fixpay->rday, True) ;
    if (v != Valid_data)
        return v ;

    v = Validate_REPAYMNT(&fixpay->repay, &fixpay->pday.last, True,
        True) ;
    if (v != Valid_data)
        return v ;

    return Valid_data ;
}


/*,,SOH,,
***********************************************************************
*                                                                      
*               Validate_FLOATRATE()                                   
*                                                                      
*   interface   #include <futvl.h>                                  
*               VALIDATE Validate_FLOATRATE(FLOATRATE   *flt) ;    
*                                                                      
*   general     This function validates the content of the FLOATRATE   
*               data structure                                         
*                                                                      
*   input       FLOATRATE   *flt      The FLOATRATE data structure     
*                                                                      
*   output                                                             
*                                                                      
*   returns     Valid_data if the content of FLOATRATE is valid,       
*               If fbase is an invalid FLOATBASE an error message      
*                   from Validate_FLOATBASE() is returned              
*               If index is an invalid RATEINDEX an error message      
*                   from Validate_RATEINDEX() is returned              
*               Invalid_boole if backset is not True or False          
*               Invalid_period if delay is not a valid PERIOD data     
*                   structure                                          
*               Invalid_compounding if method is not a valid COMPMETHOD
*                    data structure                                    
*               Invalid_freq if compfreq is not a valid PMTFREQ        
*               Invalid_averaging if avgfl.avgdur is less than 0       
*               Invalid_termunit if avgfl.avgunit is not a valid 
*                   TERMUNIT.
*               If stepspr is an invalid PLAN_STR an error message     
*                   from Validate_PLAN_STR() is returned               
*               If stepfac is an invalid PLAN_STR an error message     
*                   from Validate_PLAN_STR() is returned               
*                                                                      
*   diagnostics                                                        
*                                                                      
*   see also    FLOATRATE                                              
*                                                                      
***********************************************************************
,,EOH,,*/


VALIDATE Validate_FLOATRATE(FLOATRATE* flt)
{
    VALIDATE    tmp ;

    tmp = Validate_FLOATBASE(&flt->fbase) ;
    if (tmp != Valid_data)
        return tmp ;

    tmp = Validate_RATEINDEX(&flt->index) ;
    if (tmp != Valid_data)
        return tmp ;

    if (!Validate_BOOLE(flt->backset))
        return Invalid_boole ;

    if (!Validate_PERIOD(&flt->delay))
        return Invalid_period ;

    if (!Validate_COMPMETHOD(flt->method))
        return Invalid_compounding ;

    if (!Validate_PMTFREQ(flt->compfreq))
        return Invalid_freq ;

    tmp = Validate_AVGFLOAT(&flt->avgfl) ;
    if (tmp != Valid_data)
        return tmp ;

    tmp = Validate_PLAN_STR(flt->stepspr) ;
    if (tmp != Valid_data)
        return tmp ;

    tmp = Validate_PLAN_STR(flt->stepfac) ;
    if (tmp != Valid_data)
        return tmp ;

    return Valid_data ;
}


/*,,SOH,,
*************************************************************************
*
*               Validate_FLOATBASE()
*
*   interface   #include <futvl.h>
*               VALIDATE Validate_FLOATBASE(FLOATBASE *fb)
*
*   general     This function validates the content of the FLOATBASE
*               data structure
*
*   input       FLOATBASE  *fb    The FLOATBASE data structure
*
*   output
*
*   returns     Valid_data if the content of FLOATBASE is valid,
*               Invalid_cal if cal is an invalid calendar convention
*               Invalid_boole if is_fix is not True or False
*
*   diagnostics
*
*   see also    FLOATBASE
*
*************************************************************************
,,EOH,,*/


VALIDATE Validate_FLOATBASE(FLOATBASE* fb)
{
    if (!Validate_CALCONV(fb->cal))
        return Invalid_cal ;
    if (!Validate_BOOLE(fb->is_fix))
        return Invalid_boole ;

    return Valid_data ;
}


/*,,SOH,,
*************************************************************************
*
*               Validate_RATEINDEX()
*
*   interface   #include <futvl.h>
*               VALIDATE Validate_RATEINDEX(RATEINDEX *r)
*
*   general     This function validates the content of the RATEINDEX
*               data structure
*
*   input       RATEINDEX  *r     The RATEINDEX data structure
*
*   output
*
*   returns     Valid_data if the content of RATEINDEX is valid,
*               Invalid_LIBOR_period if LIBORdur is less than 0 and
*                   LIBORunit is an invalid TERMUNIT
*               Invalid_LIBOR_frequency if LIBORfreq is an invalid
*                   PMTFREQ
*
*   diagnostics
*
*   see also    RATEINDEX
*
*************************************************************************
,,EOH,,*/


VALIDATE Validate_RATEINDEX(RATEINDEX* r)
{
    if (r->LIBORdur < -valid_tol || !Validate_TERMUNIT(r->LIBORunit))
        return Invalid_LIBOR_period ;
    if (!Validate_PMTFREQ(r->LIBORfreq))
        return Invalid_LIBOR_frequency ;
    if (Validate_RATECONV(r->LIBORtype) == False)
        return Invalid_rateconv ;
    if (Validate_CALCONV(r->LIBORcal) == False)
        return Invalid_cal ;

    return Valid_data ;
}


/*,,SOH,,
*************************************************************************
*
*               Validate_CMCONVADJ()
*
*   interface   #include <futvl.h>
*               VALIDATE Validate_CMCONVADJ(CMCONVADJ *cm)
*
*   general     This function validates the content of the CMCONVADJ
*               data structure
*
*   input       CMCONVADJ *cm     The CMCONVADJ data structure
*
*   output
*
*   returns     Valid_data if the content of data type is valid,
*
*   diagnostics
*
*   see also    CMCONVADJ
*
*************************************************************************
,,EOH,,*/

VALIDATE Validate_CMCONVADJ(CMCONVADJ* cm)
{
    VALIDATE v ;

    if (cm == NULL)
        return Valid_data ;

    v = Validate_VOL_STR(&cm->volCM) ;
    if (v != Valid_data)
        return v ;

    v = Validate_VOL_STR(&cm->volLIBOR) ;
    if (v != Valid_data)
        return v ;

    if (Validate_CMADJTYPE(cm->order) == False)
        return Invalid_CMAdjOrder ;

    if (-1.0 - valid_tol > cm->corr || 1.0 + valid_tol < cm->corr)
        return Invalid_Correlation ;

    return Valid_data ;
}

/*,,SOH,,
*************************************************************************
*
*               Validate_AVGFLOAT()
*
*   interface   #include <futvl.h>
*               VALIDATE Validate_AVGFLOAT(AVGFLOAT *cm)
*
*   general     This function validates the content of the AVGFLOAT
*               data structure
*
*   input       AVGFLOAT *cm     The AVGFLOAT data structure
*
*   output
*
*   returns     Valid_data if the content of fixpay is valid,
*
*   diagnostics
*
*   see also    AVGFLOAT
*
*************************************************************************
,,EOH,,*/

VALIDATE Validate_AVGFLOAT(AVGFLOAT* cm)
{
    if (cm->avgdur < -valid_tol)
        return Invalid_averaging ;

    if (Validate_TERMUNIT(cm->avgunit) == False)
        return Invalid_termunit ;

    if (Validate_BOOLE(cm->avgmeth) == False)
        return Invalid_boole ;

    return Valid_data ;
}




/*,,SOH,,
***********************************************************************
*                                                                      
*               Validate_DIFFSWAP()
*                                                                      
*   interface   #include <futvl.h>                                  
*               VALIDATE Validate_DIFFSWAP(DIFFSWAP *x)
*                                                                      
*   general     This function validates the content of the DIFFSWAP
*               data structure                                         
*                                                                      
*   input       DIFFSWAP *x   The DIFFSWAP structure.
*                                                                      
*   output                                                             
*                                                                      
*   returns     Valid_data if the content of DIFFSWAP is 
*               valid.
*                                                                      
*   diagnostics
*               Refer to DIFFSWAP for a specification of valid data.
*              
*   see also    DIFFSWAP
*                                                                      
***********************************************************************
,,EOH,,*/
VALIDATE Validate_DIFFSWAP(DIFFSWAP*  x)
{
    VALIDATE v;

    if (Validate_BOOLE(x->io) == False)
        return Invalid_boole;

    if (Validate_BOOLE(x->arrears) == False)
        return Invalid_boole;

    v = Validate_FLOATBASE(&x->fbase);
    if (v != Valid_data)
        return v;

    v = Validate_PAYDAYDEF(&x->pday, False);
    if (v != Valid_data)
        return v;

    v = Validate_RATEINDEX(&x->index);
    if (v != Valid_data)
        return v;

    return Valid_data;
}



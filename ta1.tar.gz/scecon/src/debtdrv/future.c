/* SCID @(#)future.c	1.3 (SimCorp) 99/02/19 14:13:27 */

/************************************************************************
*
*   project     SCecon
*
*   filename    future.c
*
*   contains    routines in the SCecon Futures library.
*
************************************************************************/

/***** includes ********************************************************/
#include <future.h>

/***** functions *******************************************************/

/*
*************************************************************************
*
*               Fut_Price_performanceindex()
*
*    interface  #include <future.h>
*               FL64 Fut_Price_performanceindex(FL64    value0,
*                                               FL64    t,
*                                               FL64    rate,
*                                               IRRCONV irr,
*                                               INTI    qbas) ;
*
*    general    Fut_Price_performanceindex() calculates the futures
*               price for a future on a performance index base on the
*               cost of carry model.
*
*               A performance index is an index where all payments in
*               the life of the future is incorporated in the index,
*               so that no corrections of dividents and repayments
*               during the life of the future are needed.
*
*               This is in contrast to a price index where such
*               corrections are have to be done in order to evaluate
*               futures.
*
*               The cost of carry model for a future on a performance
*               index is therefore very straightforward.
*
*               Examples of performance indices include the Frankfurt
*               stock market index, DAX, whereas the Copenhagen stock
*               market index, KFX, is an example of a price index.
*
*    input      FL64    value0 The initial value of the index.
*
*               FL64    t      The term to maturity of the future.
*
*               FL64    rate   The discounting rate in percent.
*
*               IRRCONV irr    The yield convention. Eligible values
*                              are :
*
*                                   SIMPLE_MM
*                                   COMPOUND
*
*               INTI    qbas   The quoting basis - needed if irr is
*                              COMPOUND.
*
*    output
*
*    returns    the futures price as FL64.
*
*    diagnostics
*
*    see also   fut_price()
*
*************************************************************************
*/


FL64    Fut_Price_performanceindex(FL64 value0, FL64    t, FL64    rate,
                                   IRRCONV irr, INTI  qbas)
{
    FL64    price ;

    switch(irr)
    {
        case COMPOUND:
            price = value0*tvmunit_compound(rate, - t, qbas) ;
            break ;

        case SIMPLE_MM:
            price = value0/tvmunit_simple(rate, t) ;
            break ;
        default:
            /* warning avoidance */
            price = 0.0 ;
            break ;
    }
    return price ;
}


/*
*************************************************************************
*
*               Fut_select_ctd()
*
*    interface  #include <future.h>
*               INTIARRAY Fut_select_ctd(FL64ARRAY f64,
*                                        INTI      n,
*                                        CTDCONV   code,
*                                        INTI      *ix) ;
*
*    general    Fut_select_ctd() finds the CTD bond given an array,
*               f64, of either conversion ratios, implied repo rates
*               or profits computed previously for a CTD bond futures
*               contract.
*
*               The CTD is returned as the index in f64, and the array,
*               index, is filled with the sorted indices in f64.
*               (index[0] is the index for the CTD, index[1] is the
*               index in f64 for the number 2 bond etc.).
*
*    input      FL64ARRAY f64   Reference to an arry of FL64 data to
*                               be indexed according to code.
*
*               INTI      n     The number of elements in f64.
*
*               CTDCONV   code  The code according to which the f64
*                               should be sorted.
*
*    output     INTI      *ix   The index for the CTD bond, or -1 if n
*                               equals 0.
*
*    returns    Pointer to the list of sorted data in f64. Allocated in
*               this routine as Alloc_INTIARRAY(n)
*
*    diagnostics
*
*    see also   Fut_select_wildcard()
*               fut_price_CTD()
*
*************************************************************************
*/


INTIARRAY Fut_select_ctd(FL64ARRAY f64,
                         INTI      n,
                         CTDCONV   code,
                         INTI*      ix)
{
    INTIARRAY index ;

    switch (code)
    {
        case CTD_PROFIT:
        case CTD_REPO:

            /* In these cases sort in descending order */
            index = Scutl_Indexx_FL64(n, f64, DESCENDING) ;
            break ;

        case CTD_CONRATIO:

            /* In this case sort in ascending order */
            index = Scutl_Indexx_FL64(n, f64, ASCENDING) ;
            break ;
        default:
            /* warning avoidance */
            index = NULL ;
            break ;
    }

    *ix = (n > 0 ? index[0] : -1) ;

    return index ;
}


/*
*************************************************************************
*
*               Fut_select_wildcard()
*
*    interface  #include <future.h>
*               INTIARRAY Fut_select_wildcard(FL64ARRAY f64,
*                                             INTI      n,
*                                             CTDCONV   code,
*                                             INTI      *ix) ;
*
*    general    Fut_select_wildcard() finds the delivery date for a
*               future with an option to choose the delivery date.
*
*               The delivery date is found based on f64 - an array
*               of either conversion ratios, implied repo rates or
*               profits computed previously for a set of possible
*               delivery dates.
*
*               The delivery date is returned as the index in f64, and
*               the array index is filled with the sorted indices in
*               f64 (index[0] is the index for the delivery date,
*               index[1] is the index in f64 for the second best
*               delivery date).
*
*    input      FL64ARRAY f64   Reference to an array of FL64 data to
*                               be indexed according to code.
*
*               INTI      n     The number of elements in f64.
*
*               CTDCONV   code  The code according to which the f64
*                               should be sorted.
*
*    output     INTI      *ix   The index for the CTD bond, or -1 if n
*                               equals 0.
*
*    returns    Pointer to the list of sorted data in f64. Allocated in
*               this routine as Alloc_INTIARRAY(n)
*
*    diagnostics
*
*    see also   fut_select_CTD()
*               fut_price_CTDwild()
*
*************************************************************************
*/


INTIARRAY Fut_select_wildcard(FL64ARRAY f64, INTI n, CTDCONV code, INTI* ix)
{
    INTIARRAY index ;

    switch (code)
    {
        case CTD_PROFIT:
        case CTD_REPO:

            /* In these cases sort in descending order */
            index = Scutl_Indexx_FL64(n, f64, DESCENDING) ;
            break ;

        case CTD_CONRATIO:

            /* In this case sort in ascending order */
            index = Scutl_Indexx_FL64(n, f64, ASCENDING) ;
            break ;
        default:
            /* warning avoidance */
            index = NULL ;
            break ;
    }

    *ix = (n > 0 ? index[0] : -1) ;

    return index ;
}

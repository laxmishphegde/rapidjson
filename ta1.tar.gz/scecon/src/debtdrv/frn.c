/* @(#)frn.c	1.9 (SimCorp) 99/07/15 17:19:59 */

/************************************************************************
*
*   project     SCecon
*
*   filename    frn.c
*
*   contains    routines in the SCecon Library FRN module
*
************************************************************************/

/*** includes **********************************************************/
#include <frn.h>


/*** defines ***********************************************************/
#define FRN_ACC 0.0000000001
#define FRN_TOL 0.000001
#define FRN_MIN (FL64) -99.9999
#define FRN_SHOCK                0.01

#define YTM_MAXIT    (INTI)   150
#define YTM_FREQ     (INTI)     5
#define YTM_MIN_GRAD (FL64) - 5.0
#define YTM_EPS      (FL64)   0.0001


/*,,SOH,,
*************************************************************************
*
*              FRN_YTM2Price()
*
*    interface #include <frn.h>
*              BOOLE FRN_YTM2Price(DATESTR*  analys,
*                                  FL64      ytm,
*                                  FRN*      frn,
*                                  YTMCONV*  ytmc,
*                                  HOLI_STR* holi,
*                                  RISKCONV  risk,
*                                  BOOLE     modf,
*                                  FL64*     p,
*                                  FL64*     dp,
*                                  FL64*     ddp) ;
*
*    general   The function calculates the price of a FRN given a YTM.
*
*              The method employed here to derive a spread annuity cash-*
*              flow, and using this to value the FRN.
*
*              Spread annuities only make sense for VANILLA FRN's.
*
*    input     DATESTR    *analys The analysis date.
*
*              FL64       ytm     The yield to maturity (%)
*
*              FRN        *frn    The FRN definition
*                                 Next coupon assumed to be fixed
*
*              YTMCONV    *ytmc   The conventions for ytm
*                                 ytmc->irr CANNOT be JGBYTM
*
*              HOLI_STR   *holi   Business date adjustment setup
*
*              RISKCONV   risk    The risk setup.
*
*              BOOLE      modf    True means that ratios are modi-
*                                 (i.e. scaled with the dirty
*                                 price), False means direct
*                                 derivatives.
*
*    output    FL64       *p      The clean price
*
*              FL64       *dp     The dollar duration
*
*              FL64       *ddp    The dollar convexity
*
*    returns   True if FRN is vanilla, False if not.
*
*    diagnostics
*
*    see also  FRN_YTM2Yield()
*
*    wrapper   AP
*
*************************************************************************
,,EOH,,*/

BOOLE FRN_YTM2Price(DATESTR*   analys,
                        FL64       ytm,
                        FRN*       frn,
                        YTMCONV*   ytmc,
                        HOLI_STR*  holi,
                        RISKCONV   risk,                    
                        BOOLE      modf,                    
                        FL64*      p,
                        FL64*      dp,
                        FL64*      ddp)
{
    BOOLE     ok ;
    CFLWARRAY cflw ;

    /* Initialise */
    *p = *dp = *ddp = 0.0 ;

    /* Only calculate for vanillas */
    ok = SwapFl_Is_Vanilla(&frn->float1, &frn->pday.pseq, &frn->repay, holi);

    if (ok == False) 
        return ok ;

    /* Generate spread annuity flow */
    cflw = FRN_YTM2Cflw(analys, frn, holi) ;

    /* Calculate numbers */
    /* It may be wrong to call with frn->float1.fbase.coupon1 as coupon */
    *p = Cflw_YTM2Price(ytm, cflw, ytmc, &frn->pday, frn->float1.fbase.coupon1,
                        NULL, holi, risk, modf, dp, ddp) ;

    /* Clean up */
    Free_CFLWARRAY(cflw, 1) ;

    return True ;
}


/*,,SOH,,
*************************************************************************
*
*               FRN_YTM2PV01()
*
*   interface   #include <frn.h>
*               BOOLE FRN_YTM2PV01(FL64       ytm,
*                                  DATESTR    *analys,
*                                  FRN        *frn,
*                                  YTMCONV    *ytmc,
*                                  HOLI_STR   *holi,
*                                  FL64       yshift,
*                                  BOOLE      mean,
*                                  FL64       *pvb) ;
*
*   general     The function calculates the price value of a given
*               yield shift for a FRN.
*
*
*   input       FL64      ytm           Yield to Maturity (%)
*
*               DATESTR   *analys       The analysis date.
*
*               FRN       *frn          The FRN definition
*                                       Next coupon assumed to be fixed
*
*               YTMCONV   *ytmc         The conventions defined for
*                                       calculating the YTM.
*                                       ytmc->irr CANNOT be JGBYTM
*
*               HOLI_STR  *holi         Container for data on business
*                                       day convention and non-week-end
*                                       holidays.
*
*               FL64      yshift        The shift in the ytm, percentage*
*                                       input.
*
*               BOOLE     mean          False means that a directional
*                                       shift is used. True means that
*                                       an average value from an up and
*                                       down shift is returned.
*
*   output      FL64      *pvb          The Price Value of a Yield shift*
*
*   returns     True if all OK, False if not.
*
*   diagnostics
*
*   see also    FRN_YTM2Price()
*
*************************************************************************
,,EOH,,*/
BOOLE FRN_YTM2PV01(FL64       ytm,
                      DATESTR*   analys,
                      FRN*       frn,
                      YTMCONV*   ytmc,
                      HOLI_STR*  holi,
                      FL64       yshift,
                      BOOLE      mean,
                      FL64*      pvb)
{
    CFLWARRAY cflw ;
    BOOLE     ok ;

    /* Initialise */
    *pvb = 0.0 ;

    /* Only calculate for vanillas */
    ok = SwapFl_Is_Vanilla(&frn->float1, &frn->pday.pseq, &frn->repay, holi) ;

    if (ok == False) 
        return ok ;

    /* Generate spread annuity flow */
    cflw = FRN_YTM2Cflw(analys, frn, holi) ;

    /* It may be wrong to call with frn->float1.fbase.coupon1 as coupon */
    *pvb = Cflw_YTM2PV01(ytm, cflw, ytmc, &frn->pday, 
                         frn->float1.fbase.coupon1,
                         NULL, holi, yshift, mean) ;

    Free_CFLWARRAY(cflw, 1) ;

    return ok ;
}



/*,,SOH,,
*************************************************************************
*
*               FRN_YTM2YV01()
*
*   interface   #include <frn.h>
*               BOOLE FRN_YTM2YV01(DATESTR*   analys,
*                                  FL64       price,
*                                  FRN*       frn,
*                                  YTMCONV    *ytmc,
*                                  HOLI_STR   *holi,
*                                  ITERCTRL   *ictrl,
*                                  FL64       pshift,
*                                  BOOLE      mean,
*                                  FL64       *yvb) ;
*
*   general     The function calculates the yield value of a given
*               price shift for a bond.
*
*    input      DATESTR   *analys       The analysis date.
*
*               FL64      price         The clean price (%)
*
*               FRN       *frn          The FRN definition
*                                       Next coupon assumed to be fixed
*
*               YTMCONV   *ytmc         The conventions defined for
*                                       calculating the YTM.
*                                       ytmc->irr CANNOT be JGBYTM
*
*               HOLI_STR  *holi         Container for data on business
*                                       day convention and non-week-end
*                                       holidays.
*
*               ITERCTRL  *ictrl        Iteration control
*
*               FL64      pshift        The shift in the price, percen-
*                                       tage input.
*
*               BOOLE     mean          False means that a directional
*                                       shift is used. True means that
*                                       an average value from an up and
*                                       down shift is returned.
*
*   output      FL64      *yvb          The Yield value of a price shift*
*
*   returns     True if all OK, False if not.
*
*   diagnostics
*
*   see also    FRN_YTM2Yield()
*
*************************************************************************
,,EOH,,*/

BOOLE FRN_YTM2YV01(DATESTR*   analys,
                      FL64       price,
                      FRN*       frn,
                      YTMCONV*   ytmc,
                      HOLI_STR*  holi,
                      ITERCTRL*  ictrl,
                      FL64       pshift,
                      BOOLE      mean,
                      FL64*      yvb)
{
    CFLWARRAY cflw ;
    BOOLE     ok ;

    /* Initialise */
    *yvb = 0.0 ;

    /* Only calculate for vanillas */
    ok = SwapFl_Is_Vanilla(&frn->float1, &frn->pday.pseq, &frn->repay, holi) ;

    if (ok == False) 
        return ok ;

    /* Generate spread annuity flow */
    cflw = FRN_YTM2Cflw(analys, frn, holi) ;

    /* It may be wrong to call with frn->float1.fbase.coupon1 as coupon */
    ok = Cflw_YTM2YV01(price, cflw, ytmc, &frn->pday, 
                       frn->float1.fbase.coupon1, NULL, holi, 
                       ictrl, pshift, mean, yvb) ;

    Free_CFLWARRAY(cflw, 1) ;

    return ok ;
}



/*,,SOH,,
*************************************************************************
*
*              FRN_YTM2Yield()
*
*    interface #include <frn.h>
*              BOOLE FRN_YTM2Yield(DATESTR*  analys,
*                                  FL64      price,
*                                  FRN*      frn,
*                                  YTMCONV*  ytmc,
*                                  HOLI_STR* holi,
*                                  ITERCTRL* ictrl,
*                                  FL64*     ytm) ;
*
*    general   The function calculates the YTM of a FRN given the price.*
*
*              The method employed here to derive a spread annuity cash-*
*              flow, and using this to value the FRN.
*
*              Spread annuities only make sense for VANILLA FRN's.
*
*    input     DATESTR    *analys The analysis date.
*
*              FL64       price   The clean price (%)
*
*              FRN        *frn    The FRN definition
*                                 Next coupon assumed to be fixed
*
*              YTMCONV    *ytmc   The conventions for ytm
*                                 ytmc->irr CANNOT be JGBYTM
*
*              HOLI_STR   *holi   Business date adjustment setup
*
*              ITERCTRL   *ictrl  Iteration control
*
*    output    FL64       *ytm    The Yield to Maturity.
*
*    returns   True if FRN is vanilla and calculation ok, False if not.
*
*    diagnostics
*
*    see also  FRN_YTM2Price()
*
*    wrapper   AP
*
*************************************************************************
,,EOH,,*/

BOOLE FRN_YTM2Yield(DATESTR*   analys,
                       FL64       price,
                       FRN*       frn,
                       YTMCONV*   ytmc,
                       HOLI_STR*  holi,
                       ITERCTRL*  ictrl,
                       FL64*      ytm)
{
    BOOLE     ok ;
    CFLWARRAY cflw ;

    /* Initialise */
    *ytm = 0.0 ;

    /* Only calculate for vanillas */
    ok = SwapFl_Is_Vanilla(&frn->float1, &frn->pday.pseq, &frn->repay, holi);

    if (ok == False) 
        return ok ;

    /* Generate spread annuity flow */
    cflw = FRN_YTM2Cflw(analys, frn, holi) ;

    /* Calculate numbers */
    /* It may be wrong to call with frn->float1.fbase.coupon1 as coupon */
    ok = Cflw_YTM2Yield(price, cflw, ytmc, &frn->pday, 
                        frn->float1.fbase.coupon1, NULL, 
                        holi, ictrl, ytm);

    /* Clean up */
    Free_CFLWARRAY(cflw, 1) ;

    return True ;
}


/*
..
*/

CFLWARRAY FRN_YTM2Cflw(DATESTR*   analys,
                          FRN*       frn,
                          HOLI_STR*  holi)
{
    AIRESULT  aires ;
    DATEARRAY days ;
    INTI      i, nd ;
    CFLWARRAY cflw ;
    DATESTR   prev ;
    FL64      dt, amort, coupon ;

    /* Adjust for accrued interest */
    aires = FRN_Accruint(analys, frn, holi, NEXTINDEX) ;    /*  FPL-PMSTA00211-100826 add NEXTINDEX */

    /* Generate paydays */
    days = Cflw_Paydays(&frn->pday, holi, &nd) ;
    cflw = Alloc_CFLWARRAY(1, nd + 1) ;
    Cflw_Insert_In_Cflw(analys, 0.0, -aires.AI, cflw) ;

    /* Transform to cflw */
    for (i = 0; i < nd; i++)
    {
        if (Cldr_DateLE(&days[i], analys) == True)
            continue ;

        if (GetCflwFill(cflw) == 1)
        {
            /* Term for this LIBOR period */
            if (i > 0)
                prev = days[i - 1] ;
            else
                prev = frn->float1.fbase.effective ;

            dt = Cldr_TermBetweenDates(&prev, &days[i], 0, 
                                       frn->float1.fbase.cal, LAST, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */

            /* Next payment - known libor + spread, 100 redeemed */
            coupon = (frn->float1.fbase.coupon1 + 
                      frn->float1.fbase.spread) * dt ;
            amort = 100.0 ;
        }
        else
        {
            dt = Cldr_TermBetweenDates(&days[i-1], &days[i], 0, 
                                       frn->float1.fbase.cal,
									   frn->pday.pseq.eom, holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */

            /* Future payments - spread annuity */
            coupon = dt * frn->float1.fbase.spread ;
            amort  = 0.0 ;
        }
        
        /* Insert payment */
        Cflw_Insert_In_Cflw(&days[i], amort, coupon, cflw) ;
    }

    /* Clean up */
    Free_DATEARRAY(days) ;
    
    return cflw ;
}


/*,,SOH,,
*************************************************************************
*
*              FRN_SM2SmplMrgn()
*
*    interface #include <frn.h>
*              FL64 FRN_SM2SmplMrgn(DATESTR   *analys,
*                                   FL64      price,
*                                   FRN       *frn,
*                                   FL64      Lnext,
*                                   HOLI_STR  *holi,
*                                   BOOLE     *ok) ;
*
*    general   The routine calculates simple margin
*              according to the recommended formula in "Floating Rate
*              Notes - Methods of Analysis" by Richard Williams, CSFB
*
*              According to this formula, the return of a FRN over
*              the index or basis rate consists of two parts, the
*              quoted margin and a capital gain or loss measured on
*              an annual basis.
*
*              Simple margin only makes sense for VANILLA FRN's.
*
*    input     DATESTR   *analys Analysis date.
*
*              FL64      price   The clean FRN price
*
*              FRN       *frn    The FRN definition
*                                Next coupon assumed to be fixed
*
*              FL64      Lnext   The index rate till first coupon day
*
*              HOLI_STR  *holi   Business date adjustment setup
*
*    output    BOOLE     *ok     True if Vanilla, False if not
*
*    returns   The simple margin in percent
*              0 is returned if ok is False
*
*    diagnostics
*
*    see also
*
*************************************************************************
,,EOH,,*/

FL64 FRN_SM2SmplMrgn(DATESTR*   analys,
                        FL64       price,    
                        FRN*       frn,
                        FL64       Lnext,
                        HOLI_STR*  holi,
                        BOOLE*     ok)
{
    FL64      t0, t1, tN, C, sm, AI, qm ;
    DATESTR   prev, next, matur ;
    DATEARRAY paydays ;
    INTI      np, ix ;
    AIRESULT  aires ;

    /* Only calculate for vanillas */
    *ok = SwapFl_Is_Vanilla(&frn->float1, &frn->pday.pseq, &frn->repay, holi);

    if (*ok == False) 
        return 0.0 ;

    /* Initialise various variables */
    aires = FRN_Accruint(analys, frn, holi, NEXTINDEX) ;    /*  FPL-PMSTA00211-100826 add NEXTINDEX */
    AI = aires.AI ;
    C  = frn->float1.fbase.coupon1 ;
    qm = frn->float1.fbase.spread ;

    paydays = Cflw_Paydays(&frn->pday, holi, &np) ;
    ix = Cldr_FindDateIndex(paydays, np, analys, -1, SEARCH_BISECTION,
                             NEXTINDEX) ;

    if (ix < 0 || ix >= np || np <= 0 || frn->float1.fbase.is_fix == False)
    {
        *ok = False ;
        Free_DATEARRAY(paydays) ;
        return 0.0 ;
    }

    /* Find various dates */
    next  = paydays[ix] ;
    matur = paydays[np - 1] ;
    prev  = Cldr_TermUnit2Date(&next, -frn->pday.pseq.term, frn->pday.pseq.unit,
                               frn->float1.fbase.cal, frn->pday.pseq.eom, holi);

	/* PMSTA-22396 - SRIDHARA � 160502 */
    /* Find various terms */
    t1 = Cldr_TermBetweenDates(analys, &next, 0, frn->float1.fbase.cal, LAST, holi);
    tN = Cldr_TermBetweenDates(analys, &matur, 0, frn->float1.fbase.cal, LAST, holi);
    t0 = Cldr_TermBetweenDates(&prev, &next, 0, frn->float1.fbase.cal, LAST, holi);

    C = (C + qm) * t0 ;

    /* Now calculate */
    sm  = price + AI + (Lnext + qm) * t1 - C ;
    sm  = 100.0 - sm ;
    sm /= tN ;
    sm += qm ;

    /* Return */
    Free_DATEARRAY(paydays) ;
    return sm ;
}


/*,,SOH,,
*************************************************************************
*
*              FRN_SM2Price()
*
*    interface #include <frn.h>
*              FL64 FRN_SM2Price(DATESTR   *analys,
*                                FL64      sm,
*                                FRN       *frn,
*                                FL64      Lnext,
*                                HOLI_STR  *holi,
*                                BOOLE     *ok) ;
*
*    general   The routine calculates price given a simple margin
*              according to the recommended formula in "Floating Rate
*              Notes - Methods of Analysis" by Richard Williams, CSFB
*
*              According to this formula, the return of a FRN over
*              the index or basis rate consists of two parts, the
*              quoted margin and a capital gain or loss measured on
*              an annual basis.
*
*              Simple margin only makes sense for VANILLA FRN's.
*
*    input     DATESTR   *analys Analysis date.
*
*              FL64      sm      The simple margin (%)
*
*              FRN       *frn    The FRN definition
*                                Next coupon assumed to be fixed
*
*              FL64      Lnext   The index rate till first coupon day
*
*              HOLI_STR  *holi   Business date adjustment setup
*
*    output    BOOLE     *ok     True if Vanilla, False if not
*
*    returns   The clean price
*              0 is returned if ok is False
*
*    diagnostics
*
*    see also
*
*************************************************************************
,,EOH,,*/

FL64 FRN_SM2Price(DATESTR*   analys,
                     FL64       sm,    
                     FRN*       frn,
                     FL64       Lnext,
                     HOLI_STR*  holi,
                     BOOLE*     ok)
{
    FL64      t0, t1, tN, C, p, AI, qm ;
    DATESTR   prev, next, matur ;
    DATEARRAY paydays ;
    INTI      np, ix ;
    AIRESULT  aires ;

    /* Only calculate for vanillas */
    *ok = SwapFl_Is_Vanilla(&frn->float1, &frn->pday.pseq, &frn->repay, holi);

    if (*ok == False) 
        return 0.0 ;

    /* Initialise various variables */
    aires = FRN_Accruint(analys, frn, holi, NEXTINDEX) ;    /*  FPL-PMSTA00211-100826 add NEXTINDEX */
    AI = aires.AI ;
    C  = frn->float1.fbase.coupon1 ;
    qm = frn->float1.fbase.spread ;

    paydays = Cflw_Paydays(&frn->pday, holi, &np) ;
    ix = Cldr_FindDateIndex(paydays, np, analys, -1, SEARCH_BISECTION,
                             NEXTINDEX) ;

    if (ix < 0 || ix >= np || np <= 0 || frn->float1.fbase.is_fix == False)
    {
        *ok = False ;
        Free_DATEARRAY(paydays) ;
        return 0.0 ;
    }

    /* Find various dates */
    next  = paydays[ix] ;
    matur = paydays[np - 1] ;
    prev  = Cldr_TermUnit2Date(&next, -frn->pday.pseq.term, frn->pday.pseq.unit,
                               frn->float1.fbase.cal, frn->pday.pseq.eom, holi);

	/* PMSTA-22396 - SRIDHARA � 160502 */
    /* Find various terms */
    t1 = Cldr_TermBetweenDates(analys, &next, 0, frn->float1.fbase.cal, LAST, holi);
    tN = Cldr_TermBetweenDates(analys, &matur, 0, frn->float1.fbase.cal, LAST, holi);
    t0 = Cldr_TermBetweenDates(&prev, &next, 0, frn->float1.fbase.cal, LAST, holi);

    C = (C + qm) * t0 ;

    /* Now calculate */
    p  = (sm - qm) * tN ;
    p -= AI + (Lnext + qm) * t1 - C ;
    p -= 100.0 ;
    p *= -1.0 ;

    /* Return */
    Free_DATEARRAY(paydays) ;
    return p ;
}


/*,,SOH,,
*************************************************************************
*
*              FRN_DM2Price()
*
*    interface #include <frn.h>
*              FL64 FRN_DM2Price(DATESTR   *analys,
*                                FL64      dm,
*                                FRN       *frn,
*                                FL64      Lcurr,
*                                FL64      Lasm,
*                                HOLI_STR  *holi,
*                                BOOLE     *ok) ;
*
*    general   The function calculates price of a FRN according to
*              the recommended formula in "Floating Rate Notes -
*              Methods of Analysis" by Richard Williams, CSFB.
*
*              NB: Note that we have implemented the true formula as
*              recommended by CSFB - and not any of the simplified
*              formulae (e.g. the one with constant number of days in
*              each coupon period).
*
*              Model parameters are 1) Current LIBOR and 2) assumed
*              future LIBOR rates (used as coupon/discounting proxy) and*
*              3) the discounted margin.
*
*              Discounted margin only makes sense for VANILLA FRN's.
*
*    input     DATESTR    *analys The analysis date.
*
*              FL64       dm      Discounted margin.
*
*              FRN        *frn    The FRN definition
*                                 Next coupon assumed to be fixed
*                                 Quoted margin in spread
*
*              FL64       Lcurr   Current (LIBOR) index rate
*
*              FL64       Lasm    Assumed future (LIBOR) index rate
*
*              HOLI_STR   *holi   Business date adjustment setup
*
*    output    BOOLE      *ok     True if Vanilla, False if not
*
*    returns   The clean price
*              0 is returned if ok is False
*
*    diagnostics
*
*    see also  FRN_DM2DiscMrgn()
*
*    wrapper   AP
*
*************************************************************************
,,EOH,,*/

FL64 FRN_DM2Price(DATESTR*   analys,
                     FL64       dm,
                     FRN*       frn,
                     FL64       Lcurr,
                     FL64       Lasm,
                     HOLI_STR*  holi,
                     BOOLE*     ok)
{
    FL64      t1, coupon1, p, dum ;
    INTI      i, n, nd ;
    DATESTR   prev ;
    DATEARRAY days ;
    FL64ARRAY terms, amort ;
    AIRESULT  aires ;

    /* warning avoidance */
    coupon1 = 0.0 ;

    /* Only calculate for vanillas */
    *ok = SwapFl_Is_Vanilla(&frn->float1, &frn->pday.pseq, &frn->repay, holi);

    if (*ok == False) 
        return 0.0 ;

    /* Generate paydays */
    days  = Cflw_Paydays(&frn->pday, holi, &nd) ;
    terms = Alloc_FL64ARRAY(nd) ;
    amort = Alloc_FL64ARRAY(nd) ;

    /* Transform to terms */
    for (n = 0, i = 0; i < nd; i++)
    {
        if (Cldr_DateLE(&days[i], analys) == True)
            continue ;

        if (n == 0)
        {
            terms[n] = Cldr_TermBetweenDates(analys, &days[i], 0, 
                                             frn->float1.fbase.cal, LAST, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */

            /* Term for this LIBOR period */
            if (i > 0)
                prev = days[i - 1] ;
            else
                prev = frn->float1.fbase.effective ;

            t1 = Cldr_TermBetweenDates(&prev, &days[i], 0, 
                                       frn->float1.fbase.cal, LAST, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
            coupon1 = (frn->float1.fbase.coupon1 + 
                       frn->float1.fbase.spread) * t1 ;
        }
        else
            terms[n] = Cldr_TermBetweenDates(&days[i-1], &days[i], 0, 
                                             frn->float1.fbase.cal,
                                             frn->pday.pseq.eom, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
        n++ ;
    }

    /* Bullets for now */
    if (n > 0)
        amort[n - 1] = 100.0 ;

    p = FRN_Discountmargin2Price(dm, &dum, &dum, ZERO_ORDER, coupon1, 
                                 frn->float1.fbase.spread,
                                 n, terms, amort, Lcurr, Lasm) ;

    /* Adjust for accrued interest */
    aires = FRN_Accruint(analys, frn, holi, NEXTINDEX) ;    /*  FPL-PMSTA00211-100826 add NEXTINDEX */
    p = p - aires.AI ;

    Free_DATEARRAY(days) ;
    Free_FL64ARRAY(terms) ;
    Free_FL64ARRAY(amort) ;

    return p ;
}


/*,,SOH,,
*************************************************************************
*
*              FRN_DM2DiscMrgn()
*
*    interface #include <frn.h>
*              BOOLE FRN_DM2DiscMrgn(DATESTR*  analys,
*                                    FL64      price,
*                                    FRN*      frn,
*                                    FL64      Lcurr,
*                                    FL64      Lasm,
*                                    HOLI_STR* holi,
*                                    FL64*     dm) ;
*
*    general   The function calculates Discounted Margin for a FRN
*              according to the recommended formula in "Floating Rate
*              Notes - Methods of Analysis" by Richard Williams, CSFB.
*
*              NB: Note that we have implemented the true formula as
*              recommended by CSFB - and not any of the simplified
*              formulae (e.g. the one with constant number of days in
*              each coupon period).
*
*              Model parameters are 1) Current LIBOR and 2) assumed
*              future LIBOR rates (used as coupon/discounting proxy) and*
*              3) the discounted margin.
*
*              Discounted margin only makes sense for VANILLA FRN's.
*
*    input     DATESTR    *analys The analysis date.
*
*              FL64       price   Clean FRN price
*
*              FRN        *frn    The FRN definition
*                                 Next coupon assumed to be fixed
*                                 Quoted margin in spread
*
*              FL64       Lcurr   Current (LIBOR) index rate
*
*              FL64       Lasm    Assumed future (LIBOR) index rate
*
*              HOLI_STR   *holi   Business date adjustment setup
*
*    output    FL64       *dm     The Discounted Margin
*
*    returns   True if all is OK, False if not (i.e no solution or non-
*              vanilla instrument)
*
*    diagnostics
*
*    see also   FRN_DM2DiscMrgn()
*
*    wrapper   AP
*
*************************************************************************
,,EOH,,*/

BOOLE FRN_DM2DiscMrgn(DATESTR*   analys,
                         FL64       price,
                         FRN*       frn,  
                         FL64       Lcurr,
                         FL64       Lasm,
                         HOLI_STR*  holi,
                         FL64*      dm)
{
    FL64      t1, coupon1 ;
    BOOLE     ok ;
    INTI      i, n, nd ;
    DATESTR   prev ;
    DATEARRAY days ;
    FL64ARRAY terms, amort ;
    AIRESULT  aires ;

    /* warning avoidance */
    coupon1 = 0.0 ;

    *dm = 0.0 ;

    /* Only calculate for vanillas */
    ok = SwapFl_Is_Vanilla(&frn->float1, &frn->pday.pseq, &frn->repay, holi);

    if (ok == False) 
        return ok ;

    /* Generate paydays */
    days  = Cflw_Paydays(&frn->pday, holi, &nd) ;
    terms = Alloc_FL64ARRAY(nd) ;
    amort = Alloc_FL64ARRAY(nd) ;

    /* Transform to terms */
    for (n = 0, i = 0; i < nd; i++)
    {
        if (Cldr_DateLE(&days[i], analys) == True)
            continue ;

        if (n == 0)
        {
            terms[n] = Cldr_TermBetweenDates(analys, &days[i], 0, 
                                             frn->float1.fbase.cal, LAST, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
            /* Term for this LIBOR period */
            if (i > 0)
                prev = days[i - 1] ;
            else
                prev = frn->float1.fbase.effective ;

            t1 = Cldr_TermBetweenDates(&prev, &days[i], 0, 
                                       frn->float1.fbase.cal, LAST, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
            coupon1 = (frn->float1.fbase.coupon1 + 
                       frn->float1.fbase.spread) * t1 ;
        }
        else
            terms[n] = Cldr_TermBetweenDates(&days[i-1], &days[i], 0, 
                                             frn->float1.fbase.cal,
                                             frn->pday.pseq.eom, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
        n++ ;
    }

    /* Bullets for now */
    if (n > 0)
        amort[n - 1] = 100.0 ;

    /* Adjust for accrued interest */
    aires = FRN_Accruint(analys, frn, holi, NEXTINDEX) ;    /*  FPL-PMSTA00211-100826 add NEXTINDEX */
    price += aires.AI ;

    ok = FRN_Price2Discountmargin(price, coupon1, frn->float1.fbase.spread,
                                  n, terms, amort, Lcurr, Lasm, dm) ;

    Free_DATEARRAY(days) ;
    Free_FL64ARRAY(terms) ;
    Free_FL64ARRAY(amort) ;

    /* Set output to a safe value if iteration procedure failed: */
    if (ok == False)
        *dm = 0.0;

    return ok ;
}


/*
*************************************************************************
*
*               FRN_Discountmargin2Price()
*
*    interface  #include <frn.h>
*               FL64 FRN_Discountmargin2Price(FL64      dmargin,
*                                             FL64      *dp,
*                                             FL64      *ddp,
*                                             RISKCONV  risk,
*                                             FL64      c,
*                                             FL64      qm,
*                                             INTI      n,
*                                             FL64ARRAY cl,
*                                             FL64ARRAY amort,
*                                             FL64      ix,
*                                             FL64      ax) ;
*
*    general    FRN_Discountmargin2Price() calculates price of a FRN
*               according to the recommended formula in "Floating
*               Rate Notes - Methods of Analysis" by Richard
*               Williams, CSFB
*
*               In addition FRN_Discountmargin2Price() calculates the
*               dollar duration if risk is set to FIRST_ORDER and the
*               dollar duration as well as the dollar convexity if
*               risk is set to SECOND_ORDER.
*               If risk is set to ZERO_ORDER dollar duration and
*               convexity is set to zero.
*
*               The future cashflow is  NOT held constant when shocking
*               the rates for finding the risk ratios - instead a shock
*               to the assumed  rate implies a shock to the future
*               cashflow. CSFB is not specific on this issue so this is
*               our interpretation.
*
*               NB: Note that we have implemented the true formula as
*               recommended by CSFB - and not any of the simplified
*               formulae (e.g. the one with constant number of days in
*               each coupon period). Also note that the amortization
*               facility provided here has not been suggested by CSFB,
*               but is a simple extension.
*
*    input      FL64      dm    Discounted margin.
*
*               RISKCONV  risk  Indicator for risk calculation.
*
*               FL64      c     First coupon payment from FRN.
*                               Scaled with the period.
*
*               FL64      qm    Quoted margin of FRN, annual percent.
*
*               INTI      n     Number of future payments from
*                               the FRN.
*
*               FL64ARRAY  cl   The term between subsequent coupons
*                               in fraction of years, array with n
*                               entries. The first entry is the term
*                               till next payment.
*
*               FL64ARRAY  amort The amortizations corresponding to cl.
*                                Array with n entries that sum to 100.
*                                Note that these securities are almost
*                                always bullets.
*
*               FL64      ix    Current index rate, annual percent.
*
*               FL64      ax    Assumed future index rate, annual
*                               percent.
*
*    output     FL64    * dp    Dollar duration of FRN. Set if
*                               risk is FIRST_ORDER/SECOND_ORDER.
*
*               FL64    * ddp   Dollar convexity of FRN. Set if
*                               risk is SECOND_ORDER.
*
*    returns    dirty price as FL64.
*
*    diagnostics
*
*    see also   FRN_Price2Discountmargin()
*               FRN_Simplemargin2Price()
*
*************************************************************************
*/

FL64 FRN_Discountmargin2Price(FL64  dmargin,
                                 FL64*     dp,
                                 FL64*     ddp,
                                 RISKCONV  risk,
                                 FL64      coupon,
                                 FL64      qmargin,
                                 INTI      n,
                                 FL64ARRAY  clength,
                                 FL64ARRAY  amort,
                                 FL64      index,
                                 FL64      assumed)
{
    INTI    i;
    FL64    debt, rate, *cl, *pamort, p, plo, phi, dytm, payment ;

    cl     = clength ;
    pamort = amort ;

    dytm = 0.01 ;
    debt = p = *dp = *ddp = 0.0;

    for (i = n - 1 ; i >= 0 ; i--)
    {
        /* Set the assumed i'th payment */
        debt    += pamort[i] ;
        payment  = (i == 0 ? coupon : ((assumed + qmargin) * cl[i])) ;
        payment *= debt / 100.0 ;
        payment += pamort[i] ;

        /* Set the period discount rate - using simple discounting */
        rate = dmargin + (i == 0 ? index : assumed) ;

        /* Discount */
        p += payment ;
        p *= tvmunit_simple(rate, cl[i]) ;
    }

    if (SCecon_fabs(debt) < FRN_TOL)
        p = 0.0;
    else
        p /= debt * 0.01 ;

    if (risk != ZERO_ORDER)
    {
        plo = FRN_Discountmargin2Price(dmargin, dp, ddp, ZERO_ORDER, coupon,
                                       qmargin, n, clength, amort, index - dytm,
                                       assumed - dytm) ;

        phi = FRN_Discountmargin2Price(dmargin, dp, ddp, ZERO_ORDER, coupon,
                                       qmargin, n, clength, amort, index + dytm,
                                       assumed + dytm) ;

        if (risk != ZERO_ORDER)
            *dp  = -(plo - phi)/(2.0 * dytm);

        if (risk == SECOND_ORDER)
            *ddp = (plo + phi - 2.0 * p)/SQR(dytm);
    }

    return p ;
}


/*
*************************************************************************
*
*               FRN_Price2Discountmargin()
*
*    interface  #include <frn.h>
*               BOOLE FRN_Price2Discountmargin(FL64      pv,
*                                              FL64      c,
*                                              FL64      qm,
*                                              INTI      n,
*                                              FL64ARRAY cl,
*                                              FL64ARRAY amort,
*                                              FL64      ix,
*                                              FL64      ax,
*                                              FL64      *res) ;
*
*    general    FRN_Price2Discountmargin() calculates the discounted
*               margin of a FRN according to the recommended
*               formula in "Floating Rate Notes - Methods of
*               Analysis" by Richard Williams, CSFB
*
*    input      FL64      pv    Dirty price of FRN.
*
*               FL64      c     First coupon from FRN.
*
*               FL64      qm    Quoted margin af FRN, annual percent.
*
*               INTI      n     Number of whole coupon periods in
*                               the remaining life of the FRN.
*
*               FL64ARRAY  cl   The term between subsequent coupons
*                               in fraction of years, array with n
*                               entries. The first entry is the term
*                               till next payment.
*
*               FL64ARRAY  amort The amortizations corresponding to cl.
*                                Array with n entries that sum to 100.
*                                Note that these securities are almost
*                                always bullets.
*
*               FL64      ix    Index rate for first period, annual
*                               percent.
*
*               FL64      ax    Assumed index rate for future
*                               coupon periods, annual percent.
*
*    output     FL64      *res  The discounted margin
*
*    returns    True if all is OK, False if not
*
*    diagnostics
*
*    see also   FRN_Discountmargin2Price()
*
*************************************************************************
*/

BOOLE   FRN_Price2Discountmargin(FL64 price,
                                 FL64    coupon,
                                 FL64    qmargin,
                                 INTI    n,
                                 FL64ARRAY clength,
                                 FL64ARRAY amort,
                                 FL64    index,
                                 FL64    assumed,
                                 FL64*    res)
{
    return FRN_root(price, coupon, qmargin, n, clength, amort, index, assumed,
                    FRN_ACC, FRN_MIN, res) ;
}


/************************************************************************
*
*               FRN_root()
*
*    interface  #include <frn.h>
*               BOOLE   FRN_root(FL64    price,
*                                FL64    coupon,
*                                FL64    qmargin,
*                                INTI    n,
*                                FL64ARRAY clength,
*                                FL64ARRAY amort,
*                                FL64    index,
*                                FL64    assumed,
*                                FL64    yacc,
*                                FL64    min,
*                                FL64    *res) ;
*
*    general    FRN_root() finds the root of a input function using
*               Newton-Raphson iterations.
*
*               This is not a general rootfinding routine. It has been
*               tailored to the problems encountered in standard
*               financial calculations. Here we know that the function
*               at hand is convex in the standard setup, and that there
*               is only ONE unique positive root to locate. Hence
*               the Newton-Raphson algorithm is stable under weak
*               assumptions - even if we do not update the gradient
*               in each iteration.
*               If the problem is not a standard one the routine might
*               not be adequate for finding the root.
*               In particular we have omitted the switching procedure
*               between Newton-Raphson and bisection - since this is
*               time consuming and of little practical use (since the
*               standard setup is stable).
*
*               For problems where multiple roots may exist we find
*               one root (most likely the one closest to the right
*               of origo) - this could be the case if the cashflow
*               has payments with different signs (alternating).
*
*               Finally notice that we only look for roots larger than
*               -1 - or -100%.
*
*    input      FL64     price   Price of bond per 100 outstanding.
*
*               FL64      c     First coupon from FRN.
*
*               FL64      qm    Quoted margin af FRN.
*
*               INTI      n     Number of whole coupon periods in
*                               the remaining life of the FRN.
*
*               FL64ARRAY  cl   The term between subsequent coupons
*                               in fraction of years, array with n
*                               entries. The first entry is the term
*                               till next payment.
*
*               FL64ARRAY  amort The amortizations corresponding to cl.
*                               Array with n entries that
*                               sum to 100.
*                               Note that these securities are almost
*                               almost bullets.
*
*               FL64      ix    Index rate for first coupon period.
*
*               FL64      ax    Assumed index rate for future
*                               coupon periods.
*
*               FL64     yacc    Accuracy as measured on the function
*                                value and not on the input values.
*
*               FL64     min     The minimally attainable root,
*                                typically -99.99 %.
*
*    output     FL64     *res    The root
*
*    returns    True if OK, False if not
*
*    diagnostics
*
*    see also    math_rootfinder() for a general rootfinder.
*
************************************************************************/


BOOLE   FRN_root(FL64 price,
                 FL64    coupon,
                 FL64    qmargin,
                 INTI    n,
                 FL64ARRAY clength,
                 FL64ARRAY amort,
                 FL64    index,
                 FL64    assumed,
                 FL64    yacc,
                 FL64    min,
                 FL64*    res)
{
    INTI    iter, freq ;
    BOOLE   update, converged ;
    FL64    f, df, f1, grad_min, rts, ddum;

    /* warning avoidance */
    f = df = 0.0 ;

    iter = 1 ;
    freq = YTM_FREQ ;
    update = converged = False ;
    rts = 0.0 ;
    grad_min = GETMAX(min/10.0 , YTM_MIN_GRAD) ;

    while (iter <= YTM_MAXIT && converged == False)
    {
        /* update guess using dollar duration, but not in first loop */
        if (iter > 1)
        {
            /* update gradients every freq' time */
            if (!((iter - 2) % freq))
                update = True;
            else
                update = False;

            /* Calculate gradients if needed */

            if (update == True)
            {
                /* Here we shock the discounted margin. We cannot use the
                   first order derivative since this is found by shocking
                   the money market rates (index/assumed) */
                f = FRN_Discountmargin2Price(rts, &ddum, &ddum, ZERO_ORDER,
                                             coupon, qmargin, n, clength,
                                             amort, index, assumed) - price ;
                f1 = FRN_Discountmargin2Price(rts + FRN_SHOCK, &ddum, &ddum,
                                              ZERO_ORDER, coupon, qmargin,
                                              n, clength, amort, index,
                                              assumed) - price ;
                df = (f1 - f)/FRN_SHOCK ;
            }
            if (df)
                rts -= f/df;

            rts = ((rts > min) ? rts : min + YTM_EPS) ;

            /* Check for stability otherwise update gradients always */
            if (rts <= grad_min)
                freq = 1 ;
        }
        /* Evaluate the price deviation of the new rate */
        f = FRN_Discountmargin2Price(rts, &ddum, &ddum, ZERO_ORDER,
                                     coupon, qmargin, n, clength, amort,
                                     index, assumed) - price ;

        /* Check convergence */

        converged = ((fabs(f) >= yacc) ? False : True) ;
        ++iter ;
    }
    *res = rts ;

    if (iter >= YTM_MAXIT)
        return False ;
    else
        return True ;
}


/*,,SOH,,
*************************************************************************
*
*              FRN_GenrCflw()
*
*    interface #include <frn.h>
*              CFLWARRAY FRN_GenrCflw(DATESTR       *analys,
*                                      FRN           *frn,
*                                      DISCFAC       *df,
*                                      DISCFAC       *df_dsc,
*                                      CMCONVADJ     *cmadj,
*                                      HOLI_STR      *holi) ;
*
*    general   This function generates cash flow for an FRN.
*              Using time-varying spreads a large number of FRN-types
*              can be handled - including: inverse floaters, vanillas,
*              super floaters plus time-varying structures.
*
*              Note that ex-coupon and ex-principal is not handled here.*
*
*              The function handles FRN's at issue or at a future date.
*
*    input     DATESTR       *analys Analysis date.
*                                    Informs on the actual fixing period*
*                                    Default: df->disc->day[0]
*                                    analys >= Default
*
*              FRN           *frn    The FRN definition
*                                    Use SwapFl_GenrLIBORSaldo() to
*                                    find frn->float1.fbase.coupon1
*
*              DISCFAC       *df     Discounting structure setup.
*                                    For cashflow generation
*
*              DISCFAC       *df_dsc Discounting structure setup.
*                                    For convexity adjusting ONLY.
*                                    (i.e. not used for vanillas)
*                                    Enter NULL if not used.
*
*              CMCONVADJ     *cmadj  Data for Convexity Adjustment
*                                    Use NULL if no adjustment
*
*              HOLI_STR      *holi   Container for data on business
*                                    day convention and non-week-end
*                                    holidays.
*
*    output
*
*    returns   Pointer to cashflow allocated as Alloc_CFLWARRAY(1, x)
*              where x is sufficiently large.
*
*    diagnostics
*
*    see also  FRN_DF2Price()
*
*    wrapper   AP
*
*************************************************************************
,,EOH,,*/

CFLWARRAY FRN_GenrCflw(DATESTR*  analys,
                           FRN*  frn,
                           DISCFAC*       df,
                        DISCFAC*       df_dsc,
                        CMCONVADJ*     cmadj,
                        HOLI_STR*      holi)
{
    SWAPFLOAT swapfl ;

    swapfl = Set_SWAPFLOAT(&frn->repay, &frn->rday, &frn->float1,
                           &frn->pday, frn->delay) ;
    
    return SwapFl_GenrCflw(analys, &swapfl, df, df_dsc, cmadj, holi) ;
}


/*,,SOH,,
*************************************************************************
*
*              FRN_GenrPeriod()
*
*    interface #include <frn.h>
*              CFLWARRAY FRN_GenrPeriod(DATESTR       *analys,
*                                        FRN           *frn,
*                                        DISCFAC       *df,
*                                        DISCFAC       *df_dsc,
*                                        CMCONVADJ     *cmadj,
*                                        HOLI_STR      *holi) ;
*
*    general   This function generates cash flow for an FRN from
*              analysis date till maturity.
*
*              Note that for Backset (Non-Compounded) FRN's the Accrued
*              Interest is 0 and this is reflected in the period flow.
*
*    input     DATESTR       *analys Analysis date.
*                                    Default: df->disc->day[0]
*                                    analys >= Default
*
*              FRN           *frn    The FRN definition
*                                    Use SwapFl_GenrLIBORSaldo() to
*                                    find frn->float1.fbase.coupon1
*
*              DISCFAC       *df     Discounting structure setup.
*                                    For cashflow generation
*
*              DISCFAC       *df_dsc Discounting structure setup.
*                                    For convexity adjusting ONLY.
*                                    (i.e. not used for vanillas)
*                                    Enter NULL if not used.
*
*              CMCONVADJ     *cmadj  Data for Convexity Adjustment
*                                    Use NULL if no adjustment
*
*              HOLI_STR      *holi   Container for data on business
*                                    day convention and non-week-end
*                                    holidays.
*
*    output
*
*    returns   Pointer to cashflow allocated as Alloc_CFLWARRAY(1, x)
*              where x is sufficiently large.
*
*    diagnostics
*
*    see also  FRN_DF2Price()
*
*    wrapper   AP
*
*************************************************************************
,,EOH,,*/

CFLWARRAY FRN_GenrPeriod(DATESTR*    analys,
                             FRN*        frn,
                             DISCFAC*    df,
                             DISCFAC*    df_dsc,
                             CMCONVADJ*  cmadj,
                             HOLI_STR*   holi)
{
    CFLWARRAY cflw1, xcflw ;
    AIRESULT  aires ;
    INTI      i ;

    /* Generate Basic Cashflow */
    cflw1 = FRN_GenrCflw(analys, frn, df, df_dsc, cmadj, holi) ;

    if (cflw1->filled <= 0)
        return cflw1 ;

    /* Get Period till Maturity */
    xcflw = Cflw_ExtractCflw(analys, &cflw1->days[cflw1->filled - 1],
                              cflw1, -1, False, False, False, False,holi) ;
    /*PMSTA-40263-ARUN-29102020*/

    /* Insert Accrued Interest */
    for (i = cflw1->filled - 1; i >= 0; i--)
    {
        /* Note - sufficient allocation */
        xcflw->days[i + 1]   = xcflw->days[i] ;
        xcflw->repay[i + 1]  = xcflw->repay[i] ;
        xcflw->coupon[i + 1] = xcflw->coupon[i] ;
    }

    if (xcflw->filled > 0)
    {
        aires = FRN_Accruint(analys, frn, holi, NEXTINDEX) ;    /*  FPL-PMSTA00211-100826 add NEXTINDEX */

        xcflw->filled   += 1 ;
        xcflw->days[0]   = *analys ;
        xcflw->repay[0]  = 0.0 ;
        xcflw->coupon[0] = - aires.AI ;
    }

    /* Clean Up */
    Free_CFLWARRAY(cflw1, 1) ;

    return xcflw ;
}


/*,,SOH,,
*************************************************************************
*
*              FRN_DF2Price()
*
*    interface #include <frn.h>
*              FL64 FRN_DF2Price(DATESTR       *analys,
*                                FRN           *frn,
*                                DISCFAC       *df_cflw,
*                                DISCFAC       *df_disc,
*                                CMCONVADJ     *cmadj,
*                                HOLI_STR      *holi,
*                                DFSPREAD      *dfs,
*                                RISKSET       *risk,
*                                FL64          *dp,
*                                FL64          *ddp) ;
*
*    general   This routine calculates price and simple risk ratios for
*              a FRN.
*
*              Risk is calculated via shocks to the discount function.
*
*              Risk ratios are calculated as follows:
*
*                   risk->key      dp          ddp
*                   ---------      ---         ----
*                   KEY_DF         $Duration   $Convexity
*                   KEY_BPV        BPV
*
*              The Price is computed on the analysis date and quoted
*              per 100 notional on this date.
*
*    input     DATESTR       *analys Analysis date.
*
*              FRN           *frn    The FRN definition
*                                    Use SwapFl_GenrLIBORSaldo() to
*                                    find frn->float1.fbase.coupon1
*
*              DISCFAC       *df_cflw Discounting structure setup.
*                                    Used to generate payments
*
*              DISCFAC       *df_disc Discounting structure setup.
*                                    Used for discounting
*
*              CMCONVADJ     *cmadj  Data for Convexity Adjustment
*                                    Use NULL if no adjustment
*
*              HOLI_STR      *holi   Container for data on business
*                                    day convention and non-week-end
*                                    holidays.
*
*              DFSPREAD      *dfs    Spread against the discount curve.
*                                    Enter NULL if no spread.
*
*              RISKSET       *risk   Data for risk calculations
*                                    Use NULL for no risk ratios
*
*    output    FL64          *dp     Dollar duration
*
*              FL64          *ddp    Dollar convexity
*
*    returns   The clean price
*
*    diagnostics
*
*    see also
*
*    wrapper   AP
*
*************************************************************************
,,EOH,,*/

FL64 FRN_DF2Price(DATESTR*    analys,
                  FRN*     frn,
                  DISCFAC*       df_cflw,
                  DISCFAC*       df_disc,
                  CMCONVADJ*     cmadj,
                  HOLI_STR*      holi,
                  DFSPREAD*      dfs,
                  RISKSET*       risk,
                  FL64*          dp,
                  FL64*          ddp)
{
    FL64      shock, p, pvu, pvd, dum ;
    DISCFAC   sdf_cflw, sdf_disc, ds ;
    CFLWARRAY cflw ;

      /* Initialise */
    *dp = *ddp = 0.0 ;

      /* Spread to the discount curve */
	ds = Disc_Spread2DF(df_disc, dfs, holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */
    
    cflw = FRN_GenrPeriod(analys, frn, df_cflw, &ds, cmadj, holi) ;
	p = Swap_DF2NPV(analys, cflw, False, &ds, holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */

    if (risk != NULL && (risk->key == KEY_DF || risk->key == KEY_BPV) &&
        risk->risk != ZERO_ORDER)
    {
        shock = Scutl_Default_Shock(risk->shock, risk->key) ;

		sdf_cflw = Disc_ShockRates(df_cflw, 1.0, risk, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
        sdf_disc = Disc_ShockRates(df_disc, 1.0, risk, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */

        pvu = FRN_DF2Price(analys, frn, &sdf_cflw, &sdf_disc, cmadj, 
                           holi, dfs, NULL, &dum, &dum)
                              ;
        Free_PLANARRAY(sdf_disc.disc, 1) ;
        Free_PLANARRAY(sdf_cflw.disc, 1) ;

		 	/* PMSTA-22396 - SRIDHARA � 160502 */
        sdf_cflw = Disc_ShockRates(df_cflw, -1.0, risk, holi) ;
        sdf_disc = Disc_ShockRates(df_disc, -1.0, risk, holi) ;

        pvd = FRN_DF2Price(analys, frn, &sdf_cflw, &sdf_disc, cmadj, 
                           holi, dfs, NULL, &dum, &dum)
                              ;
        Free_PLANARRAY(sdf_disc.disc, 1) ;
        Free_PLANARRAY(sdf_cflw.disc, 1) ;

        if (risk->key == KEY_BPV)
            shock = 1.0 ;

        *dp  = -(pvd - pvu) / (2.0 * shock) ;

        if (risk->risk == SECOND_ORDER && risk->key == KEY_DF)
            *ddp = (pvu + pvd - 2.0 * p) / SQR(shock) ;
    }

    Free_CFLWARRAY(cflw, 1) ;
    Free_PLANARRAY(ds.disc, 1) ;

    return p ;
}


/*,,SOH,,
*************************************************************************
*
*              FRN_Accruint()
*
*    interface #include <frn.h>
*              AIRESULT FRN_Accruint(DATESTR       *analys,
*                                    FRN           *sfl,
*                                    HOLI_STR      *holi) ;
*
*    general   This function calculates the accrued interest for a FRN
*
*              Note that for Backset (Non-Compounded) FRN's the Accrued
*              Interest is 0.
*
*    input     DATESTR       *analys Analysis date
*                                    Default: df->disc->day[0]
*                                    analys >= Default
*
*              FRN           *sfl    The FRN definition
*                                    Use SwapFl_GenrLIBORSaldo() to
*                                    find sfl->float1.fbase.coupon1
*
*              HOLI_STR      *holi   Business-Day adjustment setup.
*
*    output
*
*    returns   AIRESULT container with results
*
*    diagnostics
*
*    see also  FRN_GenrCflw()
*
*    wrapper   AP
*
*************************************************************************
,,EOH,,*/

AIRESULT FRN_Accruint(DATESTR*    analys,
                         FRN*        sfl,
                         HOLI_STR*   holi,
                         INDEXCONV   iConv)     /*  FPL-PMSTA00211-100826  for full coupon flag */
{
    FL64       fix_rate, spread, LIBORfix, factor ;
    INTI       spreadidx ;
    AIRESULT   aires ;
    TRADEINFO  settle ;
    FIXRATE    fix ;
    CFLW_STR   *cflw ;
    ACCRUINT   accru ;
    COMPMETHOD method ;
    DISCFAC    df ;
    DATESTR    analys1 ;

    /* Initialise */
    method = sfl->float1.method ;
    spreadidx = 0;

    /* Define dummy DF for cflw generation */
    df = Set_DISCFAC(NULL, DI_SPOT, LINEAR_FLAT_END, EU30E360,
                     CONTINUOUS, ANNUALLY) ;
    df.disc = Alloc_PLANARRAY(1, 2) ;
    Cldr_InsertInPlan(analys, 1.0, df.disc, True) ;
    analys1 = Cldr_AddMonths(analys, 12, LAST) ;
    Cldr_InsertInPlan(&analys1, 0.9, df.disc, True) ;

    /* The remaining cases are more standardised.
       First Generate Non-Adjusted Flow */
    cflw   = FRN_GenrCflw(analys, sfl, &df, &df, NULL, holi) ;
    settle = bond_set_tradeinfo(analys) ;

    /* Calculate rate for this period - Note that averaging and TAM 
       fits into this approach. */
    spread = Cldr_PlanLookup(sfl->float1.fbase.spread, 
                             sfl->float1.stepspr, analys, &spreadidx);
    factor = Cldr_PlanLookup(sfl->float1.factor,
                             sfl->float1.stepfac, analys, &spreadidx) ;
    LIBORfix = sfl->float1.fbase.coupon1 ;
    if (sfl->float1.fbase.is_fix == True)
        fix_rate = factor * LIBORfix + spread ;
    else
        fix_rate = 10.0 ;

    /* Set data for accrued calculation */
    const FIXDCOMP decmp = (method == DECOMPOUND ? EPR_PER : NODCOMP) ;
    const COUPONBASE cbase = (method == DECOMPOUND ? EVENCOUP : ODDCOUP) ;
    fix   = Set_FIXRATE(fix_rate, sfl->float1.fbase.cal, 
                        &sfl->float1.fbase.effective, NULL, 
                        0.0, cbase, cbase, False,
                        False, NULL, True, NULL, decmp) ;
    accru = Set_ACCRUINT(sfl->float1.fbase.cal, cbase, cbase, False, False,
                         SIMPLE_MM, 1, False, False, False, NULL) ;

    /* Do the calculation */
    aires = Cflw_Accruint(&settle, cflw, &fix, &sfl->pday.pseq, 
                          &accru, holi, NULL, iConv) ;          /*  FPL-PMSTA00211-100826   */

    /* Chk for oddities */
    if (method == FLAT || method == REGCOMPOUND)
    {
        /* Here coupon1 is this saldo so far */
        aires.AI_per_day *= sfl->float1.fbase.coupon1 / aires.AI ;
        aires.AI          = sfl->float1.fbase.coupon1 ;
    }

    else if (sfl->float1.fbase.is_fix == False || sfl->float1.backset == True)
    {
        /* Here coupon1 is this saldo so far */
        aires.AI_per_day *= 0.0 ;
        aires.AI          = 0.0 ;
    }

    if (Cldr_DateLT(analys, &sfl->float1.fbase.effective) == True &&
        cflw->filled > 0)
        /* Forward Starting */
        aires.next = cflw->days[0] ;

    Free_CFLWARRAY(cflw, 1) ;
    Free_PLANARRAY(df.disc, 1) ;

    return aires ;
}


/*,,SOH,,
*************************************************************************
*
*              FRN_DF2Delta()
*
*    interface #include <frn.h>
*              FL64ARRAY FRN_DF2Delta(DATESTR       *analys,
*                                     FRN           *frn,
*                                     DISCFAC       *df_cflw,
*                                     DISCFAC       *df_disc,
*                                     CMCONVADJ     *cmadj,
*                                     HOLI_STR      *holi,
*                                     DFSPREAD      *dfs,
*                                     DELTASET      *ds) ;
*
*    general   The function calculates the delta vector for
*              a FRN using a list of predefined shocks to the zero
*              coupon curve.
*
*              The delta vector represents the price differences
*              invoked by the curve shocks.
*
*    input     DATESTR       *analys  Pointer to analysis date.
*                                     Default: df->disc->day[0]
*                                     analys >= Default
*
*              FRN           *frn     The FRN definition
*                                     Use SwapFl_GenrLIBORSaldo() to
*                                     find frn->float1.fbase.coupon1
*
*              DISCFAC       *df_cflw Discounting structure setup.
*                                     Used to generate payments
*
*              DISCFAC       *df_disc Discounting structure setup.
*                                     Used for discounting
*
*              CMCONVADJ     *cmadj   Data for Convexity Adjustment
*                                     Use NULL if no adjustment
*
*              HOLI_STR      *holi    Container for data on business
*                                     day convention and non-week-end
*                                     holidays.
*
*              DFSPREAD      *dfs     Spread against the discount curve.
*                                     Use NULL if no spread.
*
*              DELTASET      *ds      Data for delta calculation.
*
*   output
*
*   returns     The delta vector allocated as:
*
*                         Alloc_FL64ARRAY(ds->nshock) ;
*
*    diagnostics
*
*    see also
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/

FL64ARRAY FRN_DF2Delta(DATESTR*       analys,
                          FRN*           frn,
                          DISCFAC*       df_cflw,
                          DISCFAC*       df_disc,
                          CMCONVADJ*     cmadj,
                          HOLI_STR*      holi,
                          DFSPREAD*      dfs,
                          DELTASET*      ds)
{
    INTI      i ;
    FL64ARRAY dv ;
    FL64      p0, dum ;
    PLANARRAY old_cflw, old_disc, old ;
    DATESTR   fsprev, matur ;

    /* Initialise */
    dv        = Alloc_FL64ARRAY(ds->nshock) ;
    old_cflw  = df_cflw->disc ;
    old_disc  = df_disc->disc ;

    /* The unshocked price */
    p0 = FRN_DF2Price(analys, frn, df_cflw, df_disc, cmadj, holi, 
                      dfs, NULL, &dum, &dum) ;

    matur = Cldr_NextBusinessDate(&frn->pday.last, holi) ;
    matur = Cldr_TermUnit2Date(&matur, 
                               (INTI) (1.0 + frn->float1.index.LIBORdur),
                               frn->float1.index.LIBORunit,
                               frn->float1.fbase.cal, LAST, holi) ;

    for (i = 0; i < ds->nshock; i++)
    {
        if (ds->dfwhich == DF_BOTH)
        {
            fsprev = Disc_get_chgdate(NULL, old_cflw, &ds->shock[i]) ;
            fsprev = Disc_get_chgdate(&fsprev, old_disc, &ds->shock[i]) ;
        }
        else 
        {
            old = (ds->dfwhich == DF_CFLW ? old_cflw : old_disc) ;
            fsprev = Disc_get_chgdate(NULL, old, &ds->shock[i]) ;
        }

        if (fsprev.y > 0 && Cldr_DateLT(&matur, &fsprev) == False)
        {
            /* Use shocks in ds->shoch for both curves */
            if (ds->dfwhich == DF_BOTH)
                df_cflw->disc = df_disc->disc = &ds->shock[i] ;

            /* Use shocks in ds->shoch for cflw curve */
            else if (ds->dfwhich == DF_CFLW)
                df_cflw->disc = &ds->shock[i] ;

            /* Use shocks in ds->shoch for disc curve */
            else if (ds->dfwhich == DF_DISC)
                df_disc->disc = &ds->shock[i] ;

            dv[i] = FRN_DF2Price(analys, frn, df_cflw, df_disc, cmadj, holi,
                                 dfs, NULL, &dum, &dum) ;
            dv[i] -= p0 ;

            if (ds->zero == True)
            {
                /* Find shocked Zero PV */
                if (ds->dfwhich == DF_CFLW)
					dv[i] /= Disc_DF2BPV(&ds->mid[i], df_cflw, old_cflw,  holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */
                else
					dv[i] /= Disc_DF2BPV(&ds->mid[i], df_disc, old_disc, holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */
            }
        }
        else
            dv[i] = 0.0 ;
    }

    df_disc->disc = old_disc ;
    df_cflw->disc = old_cflw ;

    return dv ;
}


/*,,SOH,,
*************************************************************************
*
*               Free_FRN()
*
*    interface  #include <frn.h>
*               void Free_FRN(FRN *x) ;
*
*    general    The routine frees memory for a FRN. All the
*               memory is suballocated in the x structure.
*
*    input      FRN       *x       The floating leg data container.
*
*    output
*
*    returns
*
*    diagnostics
*
*    see also
*
*************************************************************************
,,EOH,,*/

void Free_FRN(FRN* x)
{
    /* Free all suballocated memory */
    Free_PAYDAYDEF(&x->rday);
    Free_PAYDAYDEF(&x->pday);
    Free_PLANARRAY(x->float1.stepspr, 1);
    Free_PLANARRAY(x->float1.stepfac, 1);
    Free_PLANARRAY(x->repay.aufab, 1) ;
    Free_PLANARRAY(x->repay.irreg, 1) ;
    Free_PLANARRAY(x->repay.pp.ppmts, 1) ;
}


/*
..
*/

/*,,SOH,,
************************************************************************
*
*                Set_FRN()
*
*   interface    #include <frn.h>
*                FRN Set_FRN(REPAYMNT*  repay,
*                            PAYDAYDEF* rday,
*                            FLOATRATE* fl,
*                            PAYDAYDEF* pday,
*                            INTI       delay) ;
*
*   general      This routine sets the members of the struct defined
*                in the function name. The pointer members are simply
*                assigned - without physical copying. The intention
*                of the Set_*() routines is that by using this
*                functionality, one avoids setting individual members
*                of structs in the application code.
*
*                When new members are inserted in structs the Set_*()
*                routine will be changed accordingly.
*
*                One exception to this principle applies. Whenever
*                OPTADD and vanilla members are used, only the
*                vanilla members are set in the Set_*() routines. The
*                non-vanilla and exotic members are set to defaults,
*                and must be set elsewhere - if needed.
*
*                For details on the interpretation of the individual
*                struct members please check the struct definition.
*
*   input        REPAYMNT*  repay See general section.
*                                 NULL set a Bullet structure
*
*                PAYDAYDEF* rday  See general section.
*                                 NULL set a Bullet structure
*
*                FLOATRATE* fl    See general section.
*
*                PAYDAYDEF* pday  See general section.
*
*                INTI       delay See general section.
*
*   output
*
*   returns      The filled out FRN struct
*
*   diagnostics
*
*   see also     FRN
*
************************************************************************
,,EOH,,*/

FRN Set_FRN(REPAYMNT* repay, PAYDAYDEF* rday,
               FLOATRATE* fl, PAYDAYDEF* pday, INTI delay)
{
    FRN sfl ;

    if (repay != NULL)
        sfl.repay = *repay ;
    else
        sfl.repay = Set_REPAYMNT(BULLET, NULL, False, 0.0, NULL,
                                 NULL, NULL, 0.0, 0.0) ;

    if (rday != NULL)
        sfl.rday  = *rday ;
    else
        sfl.rday = *pday ;

    sfl.float1 = *fl ;
    sfl.pday   = *pday ;
    sfl.delay  = delay ;

    return sfl ;
}


#undef FRN_ACC
#undef FRN_TOL
#undef FRN_MIN
#undef FRN_SHOCK
#undef YTM_MAXIT
#undef YTM_FREQ
#undef YTM_MIN_GRAD
#undef YTM_EPS

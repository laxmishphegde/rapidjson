/* @(#)tstswapv.c	1.8 (SimCorp) 99/09/06 11:33:01 */

/************************************************************************
*
*   Project     SCecon
*
*   this program tests the routines in the swap module of SCecon
*
************************************************************************/

/*** includes ***********************************************************/
#include <string.h>

#include <swapval.h>
#include <futio.h>
#include <ioconv.h>
#include <bondio.h>
                    
/*** Prototypes *********************************************************/
int test_swapfl_DF2price(FILE *in, FILE *out) ;
int test_swapEqty_DF2price(FILE *in, FILE *out) ;
int test_swapCmdty_DF2price(FILE *in, FILE *out) ;
int test_swapfl_genr_cflw(FILE *in, FILE *out) ;

INTI swaptest(char* txa, FILE* in, FILE* out)
{
    char        txb[25], txc[25], txd[25], txm[25], txpl[140],
                txh[25], txi[25], txj[25], 
                txk[25], txl[25], txo[25], txp[25], txq[25] ;
    INTI        dexp, i, nt, ns, nf, nfix, diff, dif1, na, nholi, nd, 
                nbucket, format ;
    FL64        *amort, *fixcoupon, *expcoup,
                acc, spread, coupon1, fexp, fres, npv, factor, dur, avgdur,
                *aspr, *afac, fres1, fres2, fexp1, fexp2, vol, npv2, *fs, *dv,
                acc1, cf, repo ;
    PLANARRAY   disc, LIBOR, pamort ;
    PLAN_STR    plans, planf ;
    EOMCONV     eom ;
    CALCONV     cal, LIBORcal ;
    BUSCONV     bus ;
    BOOLE       ok, backset, zero, ins ;
    DISCIPOL    ipol ;
    YYYYMMDD    effect, ymd ;
    DATESTR     vdate, analys, deffect, dfirst ;
    DATESTR     *fixdays, *holidays, *amortdays, *sprdays, *facdays ;
    PMTFREQ     compfreq, freq ;
    TERMUNIT    avgunit, unit ;
    COMPMETHOD  method ;
    INTPOLCONV  iconv ;
    int         i1, i2, i3, i4, i6, i7 ;
    HOLI_STR    holi ;
    PAYDAYDEF   pday ;
    PLAN_STR    plana ;
    CFLW_STR    *cflw, *xpcflw ;
    FLOATRATE   float1 ;
    DISCFAC     df, dfa, df_dsc ;
    RISKSET     risk;
    INTIARRAY   months ;
    BUCKETARRAY bucket ;
    PAYDAYSEQ   pseq ;
    VOL_STR     CMTvol ;
    SWAPFIX     sfix ;
    SWAPFLOAT   sfl ;
    CMCONVADJ   cmadj ;
    DELTASET    ds ;
    FIXPAY      fixp ;
    YTMCONV     ytmc, ytmcr ;
    RATECONV    rt ;

    acc   = 0.00001 ;
    diff = -1 ;

    if (!strcmp("SwapFl_GenrCflw()", txa))
    {
        fprintf(out,"?; testing %s\n", txa) ;
        
        /* Old or new test format? */
        format = Read_INTI(in, out, "   Format   ") ;

        /* Old test format */
        if (format == 0)
            diff = test_swapfl_genr_cflw(in, out) ;
        /* New test format */
        else if (format == 1) 
        {
            /* Read data */
            analys = Read_DATESTR(in, out, "   Analys   ") ;            
            sfl    = Read_SWAPFLOAT(in, out) ;
            df     = Read_DISCFAC(in, out) ;
            df_dsc = Read_DISCFAC(in, out) ;
            cmadj  = Read_CMCONVADJ(in, out) ;
            holi   = Read_HOLI_STR(in, out) ;
            
            /* Read Exp. cflw */
            xpcflw =  Read_CFLWARRAY(in, out) ;

            /* Calculate */
            cflw = SwapFl_GenrCflw(&analys, &sfl, &df, &df_dsc, &cmadj, &holi);

            /* Comments */
            IOUtil_ParseLine(in, out) ;

            /* Compare */
            diff = Write_CflwDiff(xpcflw, cflw, out) ;

            /* Free */
            Free_SWAPFLOAT(&sfl) ;
            Free_DISCFAC(&df) ;
            Free_DISCFAC(&df_dsc) ;
            Free_VOL_STR(&cmadj.volCM) ;
            Free_VOL_STR(&cmadj.volLIBOR) ;
            Free_HOLI_STR(&holi) ;
            Free_CFLWARRAY(xpcflw, 1) ;
            Free_CFLWARRAY(cflw, 1) ;
        }          
        else
            /* Unknown format */
            diff = 1 ;
    }

    else if (!strcmp("SwapFl_GenrCoupons()", txa))
    {
        fprintf(out,"?; testing %s\n", txa) ;
        analys = Read_DATESTR(in, out, "   Analys       ") ;            

        fscanf(in, "%ld %s %s %s %lf %lf %lf %s %s %s",
               &effect, txb, txc, txd, &coupon1, &factor, &spread,
               txi, txj, txk);
        fscanf(in, "%lf %s %s %lf %lf %s %d %d %d %d",
               &dur, txl, txq, &vol, &avgdur, txp,
               &i1, &i6, &i7, &i2);
        fscanf(in, "%s %s %s %d %d %s",
               txm, txo, txh, &i3, &i4, txpl) ;

        na = (INTI) i1 ;
        nd = (INTI) i2 ;
        nholi = (INTI) i3 ;
        dexp = (INTI) i4 ;
        ns = (INTI) i6 ;
        nf = (INTI) i7 ;

        freq = Str2PMTFREQ(txb) ;
        eom  = Str2EOMCONV(txc) ;
        cal  = Str2CALCONV(txd) ;
        bus = Str2BUSCONV(txh) ;
        backset = Str2BOOLE(txi) ;
        method = Str2COMPMETHOD(txj) ;
        compfreq = Str2PMTFREQ(txk) ;
        unit = Str2TERMUNIT(txl) ;
        ipol = Str2DISCIPOL(txm) ;
        iconv = Str2INTPOLCONV(txo) ;
        avgunit = Str2TERMUNIT(txp) ;

        deffect = Cldr_YMD2Datestr(effect) ;

        holidays  = Alloc_DATEARRAY(GETMAX(1, nholi)) ;
        amortdays = Alloc_DATEARRAY(GETMAX(1, na)) ;
        amort     = Alloc_FL64ARRAY(GETMAX(1, na)) ;
        sprdays   = Alloc_DATEARRAY(ns) ;
        aspr      = Alloc_FL64ARRAY(ns) ;
        facdays   = Alloc_DATEARRAY(nf) ;
        afac      = Alloc_FL64ARRAY(nf) ;
        fixdays   = Alloc_DATEARRAY(dexp) ;
        expcoup   = Alloc_FL64ARRAY(dexp) ;
        disc      = Alloc_PLANARRAY(1, nd) ;

        fprintf(out,"   effective day      %8ld\n", effect) ;
        fprintf(out,"   pay frequency      %8s\n", txb) ;
        fprintf(out,"   eomconv            %8s\n", txc) ;
        fprintf(out,"   calendar           %8s\n", txd) ;
        fprintf(out,"   first coupon       %3.4lf\n", coupon1) ;
        fprintf(out,"   factor             %3.4lf\n", factor) ;
        fprintf(out,"   spread             %3.4lf\n", spread) ;
        fprintf(out,"   backset ??         %8s\n", txi) ;
        fprintf(out,"   comp.method        %8s\n", txj) ;
        fprintf(out,"   comp.freq.         %8s\n", txk) ;
        fprintf(out,"   index duration     %3.4lf\n", dur) ;
        fprintf(out,"   index unit         %8s\n", txl) ;
        fprintf(out,"   index freq         %8s\n", txq) ;
        fprintf(out,"   index vol          %3.4lf\n", vol) ;
        fprintf(out,"   avg.  duration     %3.4lf\n", avgdur) ;
        fprintf(out,"   avg.  unit         %8s\n", txp) ;
        fprintf(out,"   ipol discount      %8s\n", txm) ;
        fprintf(out,"   intpol             %8s\n", txo) ;
        fprintf(out,"   business day conv  %8s\n", txh) ;

        fprintf(out,"   the amort schedule is...\n") ;
        fprintf(out,"       date  repayment\n") ;

        for (i = 0 ; i < na ; i++)
        {
            fscanf(in, "%ld %lf", &ymd, &amort[i]) ;
            amortdays[i] = Cldr_YMD2Datestr(ymd) ;
            fprintf(out,"   %8ld %9.5lf\n", ymd, amort[i]) ;
        }

        fprintf(out,"   the spread schedule is...\n") ;
        fprintf(out,"       date  spread\n") ;

        for (i = 0 ; i < ns ; i++)
        {
            fscanf(in, "%ld %lf", &ymd, &aspr[i]) ;
            sprdays[i] = Cldr_YMD2Datestr(ymd) ;
            fprintf(out,"   %8ld %9.5lf\n", ymd, aspr[i]) ;
        }

        fprintf(out,"   the factor schedule is...\n") ;
        fprintf(out,"       date  factor\n") ;

        for (i = 0 ; i < nf ; i++)
        {
            fscanf(in, "%ld %lf", &ymd, &afac[i]) ;
            facdays[i] = Cldr_YMD2Datestr(ymd) ;
            fprintf(out,"   %8ld %9.5lf\n", ymd, afac[i]) ;
        }

        fprintf(out,"   the discount function is...\n") ;
        fprintf(out,"       date  discount factor\n") ;

        for (i = 0 ; i < nd ; i++)
        {
            fscanf(in, "%ld %lf", &ymd, &disc[0].f64[i]) ;
            disc[0].day[i] = Cldr_YMD2Datestr(ymd) ;
            fprintf(out,"   %8ld %9.5lf\n", ymd, disc[0].f64[i]) ;
        }
        disc[0].count = disc[0].filled = nd ;

        fprintf(out,"   the holidays are...\n") ;
        fprintf(out,"   holiday\n") ;
        for (i = 0 ; i < nholi ; i++)
        {
            fscanf(in, "%ld", &ymd) ;
            holidays[i] = Cldr_YMD2Datestr(ymd) ;
            fprintf(out,"   %8ld\n", ymd) ;
        }
        for (i = 0 ; i < dexp ; i++)
        {
            fscanf(in, "%ld %lf", &ymd, &expcoup[i]) ;
            fixdays[i] = Cldr_YMD2Datestr(ymd) ;
        }

        holi = Set_HOLI_STR(bus, nholi, holidays) ;

        float1.fbase.effective = deffect ;
        float1.fbase.cal       = cal;
        float1.fbase.coupon1   = coupon1;
        float1.fbase.is_fix    = True ;
        float1.factor    = factor;
        float1.fbase.spread    = spread;
        float1.backset   = backset;
        float1.delay     = Set_PERIOD(0, DAYS) ;
        float1.method    = method;
        float1.compfreq  = compfreq;

        rt = (Str2PMTFREQ(txq) == NO_FREQUENCY ? MMRATE : PARYIELD) ;
        LIBORcal = (Str2PMTFREQ(txq) == NO_FREQUENCY ? cal : EU30E360) ;
        float1.index = Set_RATEINDEX(rt, dur, unit, Str2PMTFREQ(txq), 
                        LIBORcal, 0.0) ;
        float1.avgfl = Set_AVGFLOAT(avgdur, avgunit, False) ;

        planf.filled     = nf ;
        planf.day        = facdays ;
        planf.f64        = afac ;
        float1.stepfac   = &planf ;

        plans.filled     = ns ;
        plans.day        = sprdays ;
        plans.f64        = aspr ;
        float1.stepspr   = &plans ;

        plana.filled = na ;
        plana.f64    = amort ;
        plana.day    = amortdays ;

        df = Set_DISCFAC(disc, ipol, iconv, cal, 
                              CONTINUOUS, ANNUALLY) ;
        pseq      = Set_PAYDAYSEQ(Cflw_MonthsBetweenPayments(freq),
                       MONTHS, NOODD, NOODD, ANCHOR, eom);
        CMTvol = Set_VOL_STR(NULL, cal, FORWVOL, LINEAR_EXTRAPOL) ;
        CMTvol.vol = Alloc_PLANARRAY(1, 1) ;
        Cldr_InsertInPlan(&deffect, vol, CMTvol.vol, True) ;

        cmadj = Set_CMCONVADJ(CMADJ_ORIG, &CMTvol, NULL, 0.0) ;

        fixcoupon = SwapFl_GenrCoupons(&analys, &float1, &pseq, &plana, 
                                        &df, NULL,
                                        &cmadj, &holi, fixdays, dexp, NULL) ;

        diff = 0 ;
        fprintf(out,"       date exp.coupon comp.coupon\n") ;
        for (i = 0 ; i < dexp ; i++)
        {
            dif1 = (fabs(fixcoupon[i] - expcoup[i]) > acc);
            fprintf(out, "%d; %8ld %9.5lf %9.5lf\n",
                    dif1, Cldr_Datestr2YMD(&fixdays[i]),
                    expcoup[i], fixcoupon[i]) ;
            diff = dif1 || diff ;
        }
        fprintf(out,"   %s\n\n", txpl) ;

        Free_FL64ARRAY(amort) ;
        Free_DATEARRAY(amortdays) ;
        Free_FL64ARRAY(aspr) ;
        Free_DATEARRAY(sprdays) ;
        Free_FL64ARRAY(afac) ;
        Free_DATEARRAY(facdays) ;
        Free_DATEARRAY(holidays) ;
        Free_DATEARRAY(fixdays) ;
        Free_FL64ARRAY(fixcoupon) ;
        Free_FL64ARRAY(expcoup) ;
        Free_PLANARRAY(disc, 1) ;
        Free_PLANARRAY(CMTvol.vol, 1) ;
    }

    else if (!strcmp("SwapFix_DF2Rate()", txa))
    {
        fprintf(out,"?; testing %s\n", txa) ;
        fexp   = Read_FL64(in, out, "   Exp           ") ;
        analys = Read_DATESTR(in, out, "   Analys        ") ;
        npv    = Read_FL64(in, out, "   NPV           ") ;
        sfix   = Read_SWAPFIX(in, out) ;
        df     = Read_DISCFAC(in, out) ;
        holi   = Read_HOLI_STR(in, out) ;

        ok = SwapFix_DF2Rate(&analys, npv, &sfix, &df, &holi, &fres) ;

        diff = Write_SingleDiff(ok, True, fres, fexp, acc, out) ;
        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_DATEARRAY(holi.holidays) ;
        Free_SWAPFIX(&sfix) ;
        Free_PLANARRAY(df.disc, 1) ;
    }

    else if (!strcmp("SwapFix_BONDSWAPSPR2CFrate()", txa))
    {
        fscanf(in, "%lf %lf %lf", &fexp, &fexp1, &acc1) ;

        fscanf(in, "%ld", &ymd) ;
        analys = Cldr_YMD2Datestr((YYYYMMDD) ymd) ;
        fprintf(out,"   Analysis           %8ld\n", ymd) ;
        fixp = Read_FIXPAY(in, out, &analys) ;
        pday = Read_PAYDAYDEF(in, out) ;
        fscanf(in, "%s", txb) ;
        cal = Str2CALCONV(txb) ;
        fprintf(out,"   Calconv            %8s\n", txb) ;
        fscanf(in, "%lf", &npv) ;
        fprintf(out,"   BondPrice          %8lf\n", npv) ;
        fscanf(in, "%s", txb) ;
        zero = Str2BOOLE(txb) ;
        fprintf(out,"   Is Price           %8s\n", txb) ;
        ytmc = Read_YTMCONV(in, out) ;
        fscanf(in, "%lf", &spread) ;
        fprintf(out,"   SwapSpread         %8lf\n", spread) ;
        holi = Read_HOLI_STR(in, out) ;

        ok = SwapFix_BONDSWAPSPR2CFrate(&analys, &fixp, &pday, cal,
                                        npv, zero, &ytmc, spread, &holi,
                                        &fres, &fres1) ;
        diff = 1 ;
        if (ok == False)
            fprintf(out,"1; Cannot solve for swaprate\n") ;
        else
        {
            diff = fabs(fexp - fres) > acc1 ||
                   fabs(fexp1 - fres1) > acc1  ;
            fprintf(out, "%d;  exp %9.5lf %9.5lf res %9.5lf %9.5lf\n",
                    diff, fexp, fexp1, fres, fres1) ;
        }

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_DATEARRAY(holi.holidays) ;
    }


    else if (!strcmp("SwapFix_FUTSWAPSPR2CFrate()", txa))
    {
        fscanf(in, "%lf %lf %lf", &fexp, &fexp1, &acc1) ;

        fscanf(in, "%ld", &ymd) ;
        analys = Cldr_YMD2Datestr((YYYYMMDD) ymd) ;
        fprintf(out,"   Analysis           %8ld\n", ymd) ;
        fscanf(in, "%ld", &ymd) ;
        vdate  = Cldr_YMD2Datestr((YYYYMMDD) ymd) ;
        fprintf(out,"   Delivery           %8ld\n", ymd) ;
        fixp = Read_FIXPAY(in, out, &analys) ;
        fscanf(in, "%lf", &cf) ;
        fprintf(out,"   ConFac             %8lf\n", cf) ;
        pday = Read_PAYDAYDEF(in, out) ;
        fscanf(in, "%s", txb) ;
        cal = Str2CALCONV(txb) ;
        fprintf(out,"   Calconv            %8s\n", txb) ;
        fscanf(in, "%lf", &npv) ;
        fprintf(out,"   FutPrice           %8lf\n", npv) ;
        fscanf(in, "%lf", &repo) ;
        fprintf(out,"   RepoRate           %8lf\n", repo) ;
        ytmcr = Read_YTMCONV(in, out) ;
        ytmc  = Read_YTMCONV(in, out) ;
        fscanf(in, "%lf", &spread) ;
        fprintf(out,"   SwapSpread         %8lf\n", spread) ;
        holi = Read_HOLI_STR(in, out) ;

        ok = SwapFix_FUTSWAPSPR2CFrate(&analys, &vdate, &fixp, cf,
                                       &pday, cal, npv, repo,
                                       &ytmcr, &ytmc, spread, &holi,
                                       &fres, &fres1) ;
        diff = 1 ;
        if (ok == False)
            fprintf(out,"1; Cannot solve for swaprate\n") ;
        else
        {
            diff = fabs(fexp - fres) > acc1 ||
                   fabs(fexp1 - fres1) > acc1  ;
            fprintf(out, "%d;  exp %9.5lf %9.5lf res %9.5lf %9.5lf\n",
                    diff, fexp, fexp1, fres, fres1) ;
        }

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_DATEARRAY(holi.holidays) ;
    }

    else if (!strcmp("SwapFix_DF2CFrate()", txa))
    {
        fprintf(out,"?; testing %s\n", txa) ;
        
        /* Read data */
        fexp    = Read_FL64(in, out, "   Exp              ") ;
        analys  = Read_DATESTR(in, out, "   Analysis date    ") ;
        npv     = Read_FL64(in, out, "   NPV              ") ;
        deffect = Read_DATESTR(in, out, "   Effective date   ") ;
        pday    = Read_PAYDAYDEF(in, out) ;
        cal     = Read_CALCONV(in, out, "   Calendar      ") ;
        df      = Read_DISCFAC(in, out) ;
        holi    = Read_HOLI_STR(in ,out) ;

        /* Calculate */
        fres = SwapFix_DF2CFrate(&analys, npv, &pday, &deffect, cal,
                                 &df, &holi) ;

        /* Compare */
        diff = Write_SingleDiff(True, True, fres, fexp, acc, out) ;

        /* Comments */
        IOUtil_ParseLine(in, out) ;

        /* Free */               
        Free_HOLI_STR(&holi) ;
        Free_DISCFAC(&df) ;
    }

    else if (!strcmp("SwapFix_DF2SwapCurve()", txa))
    {
        fprintf(out,"?; testing %s\n", txa) ;

        /* Read data */
        df = Read_DISCFAC(in, out) ;
        dfirst = Read_DATESTR(in, out, "   Forward   ") ;
        months = Read_INTIARRAY(in, &nt) ;
        Write_INTIARRAY(out, months, nt) ;
        cal = Read_CALCONV(in, out, "   Calendar conv   ") ;
        pseq = Read_PAYDAYSEQ(in, out) ;
        holi = Read_HOLI_STR(in, out) ;

        fs = SwapFix_DF2SwapCurve(&df, &dfirst, months, nt,
                                  cal, &pseq, &holi) ;

        diff = 0 ;
        for (i = 0; i < nt; i++)
        {
            fres = fs[i] ;
            fscanf(in, "%lf", &fexp) ;
            diff = diff || (fabs(fexp - fres) > acc) ;
            fprintf(out, 
              "%d;  Period %d expected rate is %9.5lf  result is %9.5lf\n",
              
                    (fabs(fexp - fres) > acc), months[i], fexp, fres) ;
        }

        /* Comments */
        IOUtil_ParseLine(in, out) ;

        /* Free.. */
        Free_HOLI_STR(&holi) ;
        Free_DISCFAC(&df) ;
        Free_FL64ARRAY(fs) ;
        Free_INTIARRAY(months) ;
    }

    else if (!strcmp("SwapFl_DF2Spread()", txa))
    {
        fprintf(out,"?; testing %s\n", txa) ;

        /* Comments */
        IOUtil_ParseLine(in, out) ;

        fexp = Read_FL64(in, out, "   Exp res   ") ;

        analys = Read_DATESTR(in, out, "   Analysis date   ") ;
        npv = Read_FL64(in, out, "   NPV   ") ;
        sfl = Read_SWAPFLOAT(in, out) ;
        CMTvol = Read_VOL_STR(in ,out) ;
        holi = Read_HOLI_STR(in, out) ;
        /* discounting discount function */
        df = Read_DISCFAC(in, out) ;
        /* cashflow discount function */
        dfa = Read_DISCFAC(in, out) ;

        cmadj = Set_CMCONVADJ(CMADJ_ORIG, &CMTvol, NULL, 0.0) ;

        ok = SwapFl_DF2Spread(&analys, npv, &sfl,
                              &df, &dfa, &cmadj, &holi, &fres) ;

        if (ok == False)
        {
            fprintf(out,"1; Cannot solve for spread\n") ;
            diff = 1 ;
        }
        else
            diff = Write_SingleDiff(ok, True, fres, fexp, acc, out) ;
              
        Free_SWAPFLOAT(&sfl) ;
        Free_HOLI_STR(&holi) ;
        Free_DISCFAC(&df) ;
        Free_DISCFAC(&dfa) ;
        Free_VOL_STR(&CMTvol) ;
    }

    else if (!strcmp("SwapFl_DF2CFSpread()", txa))
    {
        fprintf(out,"?; testing %s\n", txa) ;

        fexp = Read_FL64(in, out, "   Exp res   ") ;
        analys = Read_DATESTR(in, out, "   Analysis date   ") ;
        npv = Read_FL64(in, out, "   NPV leg1   ") ;
        npv2 = Read_FL64(in, out, "   NPV leg2   ") ;
        pday = Read_PAYDAYDEF(in, out) ;
        deffect = Read_DATESTR(in, out, "   Effective   ") ;
        cal = Read_CALCONV(in, out, "   Calendar conv   ") ;
        df = Read_DISCFAC(in, out) ;
        holi = Read_HOLI_STR(in, out) ;

        /* Calculate */
        fres = SwapFl_DF2CFSpread(&analys, npv, npv2, &pday, &deffect,
                                  cal, &df, &holi) ;

        /* Compare */
        diff = Write_SingleDiff(True, True, fres, fexp, acc, out) ;

        /* Comments */
        IOUtil_ParseLine(in, out) ;

        /* Free.. */
        Free_HOLI_STR(&holi) ;
        Free_DISCFAC(&df) ;
    }

    else if (!strcmp("SwapFl_DF2NPV()", txa))
    {
        fprintf(out,"?; testing %s\n", txa) ;
        diff = test_swapfl_DF2price(in, out) ;
    }

    else if (!strcmp("SwapFix_DF2NPV()", txa))
    {
        fscanf(in, "%lf %lf %lf", &fexp, &fexp1, &fexp2) ;
        
        fprintf(out,"?; testing %s\n", txa) ;
        fscanf(in, "%ld", &ymd) ;
        fprintf(out,"   Analysis           %8ld\n", ymd) ;
        analys = Cldr_YMD2Datestr(ymd) ;

        sfix = Read_SWAPFIX(in, out) ;
        df   = Read_DISCFAC(in, out) ;
        holi = Read_HOLI_STR(in, out) ;

        fscanf(in, "%s", txpl) ;

        risk = Set_RISKSET(KEY_DF, SECOND_ORDER, -1.0,
                           COMPOUND, ANNUALLY, NULL, True) ;

        fres = SwapFix_DF2NPV(&analys, &sfix, &holi,
                              &df, &risk, &fres1, &fres2) ;

        diff = (fabs(fexp  - fres)   > acc) ||
               (fabs(fexp1 - fres1) > acc) ||
               (fabs(fexp2 - fres2) > acc) ;

        fprintf(out, "%d;  expected NPV is %9.5lf  result is %9.5lf\n",
                fabs(fexp  - fres) > acc, fexp, fres) ;
        fprintf(out, "%d;  expected  dp is %9.5lf  result is %9.5lf\n",
                fabs(fexp1  - fres1) > acc, fexp1, fres1) ;
        fprintf(out, "%d;  expected ddp is %9.5lf  result is %9.5lf\n",
                fabs(fexp2  - fres2) > acc, fexp2, fres2) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_SWAPFIX(&sfix);
        Free_DATEARRAY(holi.holidays) ;
        Free_PLANARRAY(df.disc, 1) ;
    }

    else if (!strcmp("SwapFix_DF2Delta()", txa))
    {
        fprintf(out,"?; testing %s\n", txa) ;
        sfix = Read_SWAPFIX(in, out) ;

        df     = Read_DISCFAC(in, out) ;
        holi   = Read_HOLI_STR(in, out) ;
        bucket = Read_BUCKETARRAY(in, out, &nbucket) ;

        zero = Read_BOOLE(in, out, "DECF") ;
        ins = Read_BOOLE(in, out, "Insert Points") ;

        ds = Disc_DeltaPrep(&df, bucket, nbucket, &holi, ins, df.irr,
                             df.freq, False, zero, DF_BOTH) ;

        if (GetPlanFill(df.disc) > 0)
            analys = df.disc->day[0] ;
        else
            analys = Cldr_YMD2Datestr((YYYYMMDD) 19900101) ;

        dv = SwapFix_DF2Delta(&analys, &sfix, &holi, &df, &ds) ;

        diff = 0 ;
        for (i = 0; i < nbucket; i++)
        {
            fscanf(in, "%lf", &fexp) ;
            diff = diff || fabs(fexp - dv[i]) > 0.00001 ;
            fprintf(out, "%d; %d exp %lf res %lf\n",
                    fabs(fexp - dv[i]) > 0.00001, i, fexp, dv[i]) ;
        }

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_SWAPFIX(&sfix);
        Free_DATEARRAY(holi.holidays) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_DELTASET(&ds) ;
        Free_BUCKETARRAY(bucket) ;
        Free_FL64ARRAY(dv) ;
    }

    else if (!strcmp("SwapFl_DF2Delta()", txa))
    {
        fprintf(out,"?; testing %s\n", txa) ;
        fscanf(in, "%s", txpl) ;

        sfl = Read_SWAPFLOAT(in, out) ;

        fprintf(out,"   index vol\n") ;
        CMTvol = Read_VOL_STR(in, out) ;
        holi   = Read_HOLI_STR(in, out) ;
        df     = Read_DISCFAC(in, out) ;
        dfa    = Read_DISCFAC(in, out) ;
        bucket = Read_BUCKETARRAY(in, out, &nbucket) ;

        fscanf(in, "%s", txb) ;
        zero = Str2BOOLE(txb) ;
        fprintf(out,"   DECF        %8s\n", txb) ;

        ds  = Disc_DeltaPrep(&df, bucket, nbucket, &holi, False, df.irr,
                              df.freq, False, zero, DF_BOTH) ;

        cmadj = Set_CMCONVADJ(CMADJ_ORIG, &CMTvol, NULL, 0.0) ;

        if (GetPlanFill(dfa.disc) > 0)
            analys = dfa.disc->day[0] ;
        else
            analys = Cldr_YMD2Datestr((YYYYMMDD) 19900101) ;

        dv = SwapFl_DF2Delta(&analys, &sfl, &df, &dfa, &cmadj, &holi, &ds) ;

        diff = 0 ;
        for (i = 0; i < nbucket; i++)
        {
            fscanf(in, "%lf", &fexp) ;
            diff = diff || fabs(fexp - dv[i]) > 0.00001 ;
            fprintf(out, "%d; %d exp %lf res %lf\n",
                    fabs(fexp - dv[i]) > 0.00001, i, fexp, dv[i]) ;
        }

        fprintf(out,"   %s\n\n", txpl) ;


        Free_SWAPFLOAT(&sfl);
        Free_DATEARRAY(holi.holidays) ;
        Free_DELTASET(&ds) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_PLANARRAY(dfa.disc, 1) ;
        Free_BUCKETARRAY(bucket) ;
        Free_FL64ARRAY(dv) ;
        Free_PLANARRAY(CMTvol.vol, 1) ;
    }

    else if (!strcmp("AssetSwap_DF2Spread()", txa))
    {
        fprintf(out,"?; testing %s\n", txa) ;
        fscanf(in, "%s", txpl) ;

        ok = IOUtil_ReadComment(in, out) ;

        sfix   = Read_SWAPFIX(in, out) ;
        npv = Read_FL64(in, out, " Asset value") ;

        sfl = Read_SWAPFLOAT(in, out) ;

        fprintf(out,"   index vol\n") ;
        CMTvol = Read_VOL_STR(in, out) ;
        holi   = Read_HOLI_STR(in, out) ;
        df     = Read_DISCFAC(in, out) ;
        dfa    = Read_DISCFAC(in, out) ;

        cmadj = Set_CMCONVADJ(CMADJ_ORIG, &CMTvol, NULL, 0.0) ;

        if (GetPlanFill(dfa.disc) > 0)
            analys = dfa.disc->day[0] ;
        else
            analys = Cldr_YMD2Datestr((YYYYMMDD) 19900101) ;

        ok = AssetSwap_DF2Spread(&analys, npv, &sfix, &sfl, 
          &df, &dfa, &cmadj, &holi, &fres) ;

        diff = 0 ;
        if (ok)
        {
          fscanf(in, "%lf", &fexp) ;
          diff = diff || fabs(fexp - fres) > 0.00001 ;
          fprintf(out, "%d; exp %lf res %lf\n",
                  fabs(fexp - fres) > 0.00001, fexp, fres) ;
        }
        else 
        {
          diff = 1 ;
          fprintf(out, "1; Calculation failed.\n") ;
        }

        fprintf(out,"   %s\n\n", txpl) ;

        Free_SWAPFIX(&sfix) ;
        Free_SWAPFLOAT(&sfl);
        Free_DATEARRAY(holi.holidays) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_PLANARRAY(dfa.disc, 1) ;
        Free_PLANARRAY(CMTvol.vol, 1) ;
    }

    else if (!strcmp("AssetSwap_DF2PV()", txa))
    {
        fprintf(out,"?; testing %s\n", txa) ;
        fscanf(in, "%s", txpl) ;

        ok = IOUtil_ReadComment(in, out) ;

        sfix   = Read_SWAPFIX(in, out) ;
        npv = Read_FL64(in, out, " Asset value") ;

        sfl = Read_SWAPFLOAT(in, out) ;

        fprintf(out,"   index vol\n") ;
        CMTvol = Read_VOL_STR(in, out) ;
        holi   = Read_HOLI_STR(in, out) ;
        df     = Read_DISCFAC(in, out) ;
        dfa    = Read_DISCFAC(in, out) ;

        cmadj = Set_CMCONVADJ(CMADJ_ORIG, &CMTvol, NULL, 0.0) ;

        if (GetPlanFill(dfa.disc) > 0)
            analys = dfa.disc->day[0] ;
        else
            analys = Cldr_YMD2Datestr((YYYYMMDD) 19900101) ;

        fres = AssetSwap_DF2PV(&analys, npv, &sfix, &sfl, 
          &df, &dfa, &cmadj, &holi) ;

        diff = 0 ;
        fscanf(in, "%lf", &fexp) ;
        diff = diff || fabs(fexp - fres) > 0.00001 ;
        fprintf(out, "%d; exp %lf res %lf\n",
                  fabs(fexp - fres) > 0.00001, fexp, fres) ;

        fprintf(out,"   %s\n\n", txpl) ;

        Free_SWAPFIX(&sfix) ;
        Free_SWAPFLOAT(&sfl);
        Free_DATEARRAY(holi.holidays) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_PLANARRAY(dfa.disc, 1) ;
        Free_PLANARRAY(CMTvol.vol, 1) ;
    }

    else if (!strcmp("SwapFl_GenrLIBORsaldo()", txa))
    {
        fscanf(in, "%lf %ld", &fexp, &ymd) ;

        vdate = Cldr_YMD2Datestr(ymd) ;

        fprintf(out,"?; testing %s\n", txa) ;
        fprintf(out,"   Value Date     %8ld\n", ymd) ;

        /* Read Floatrate */
        float1 = Read_FLOATRATE(in, out) ;

        /* Paydays */
        pday = Read_PAYDAYDEF(in, out) ;

        /* Read Amort */
        pamort = Read_PLANARRAY(in) ;
        fprintf(out,"   Amortisations:\n") ;
        Write_PLANARRAY(out, pamort) ;

        /* Read holi */
        holi = Read_HOLI_STR(in, out) ;

        /* Read LIBOR */
        LIBOR = Read_PLANARRAY(in) ;
        fprintf(out,"   LIBOR list:\n") ;
        Write_PLANARRAY(out, LIBOR) ;

        fres = SwapFl_GenrLIBORsaldo(&vdate, &float1, &pday, pamort,
                                      &holi, LIBOR) ;

        diff = fabs(fres - fexp) > acc ;
        fprintf(out, "%d;  exp is %9.5lf  res is %9.5lf\n",
                diff, fexp, fres) ;

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_PLANARRAY(pamort, 1) ;
        Free_PLANARRAY(LIBOR, 1) ;
        Free_PLANARRAY(float1.stepspr, 1) ;
        Free_PLANARRAY(float1.stepfac, 1) ;
        Free_DATEARRAY(holi.holidays) ;
    }

    else if (!strcmp("SwapFl_GenrLIBORdays()", txa))
    {
        fscanf(in, "%ld", &ymd) ;

        vdate = Cldr_YMD2Datestr(ymd) ;

        fprintf(out,"?; testing %s\n", txa) ;
        fprintf(out,"   Value Date     %8ld\n", ymd) ;

        /* Read Floatrate */
        float1 = Read_FLOATRATE(in, out) ;

        /* Paydays */
        pday = Read_PAYDAYDEF(in, out) ;

        /* Read holi */
        holi = Read_HOLI_STR(in, out) ;

        fixdays = SwapFl_GenrLIBORdays(&vdate, &float1, &pday, &holi,
          &nfix, SAMEINDEX) ;

        fscanf(in, "%d", &i1) ;
        dexp = (INTI) i1 ;

        if (nfix != dexp)
        {
            diff = 1 ;
            fprintf(out, "1;  Diff. in number of days\n") ;
            for (i = 0; i < dexp; i++)
                fscanf(in, "%ld", &ymd) ;
        }
        else
        {

            for (diff = i = 0; i < dexp; i++)
            {
                fscanf(in, "%ld", &ymd) ;
                diff = diff || Cldr_Datestr2YMD(&fixdays[i]) != ymd ;
                fprintf(out, "%d;  Exp %ld Res %ld\n",
                        diff, Cldr_Datestr2YMD(&fixdays[i]), ymd) ;
            }
        }

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_PLANARRAY(float1.stepspr, 1) ;
        Free_PLANARRAY(float1.stepfac, 1) ;
        Free_DATEARRAY(fixdays) ;
        Free_DATEARRAY(holi.holidays) ;
    }

    else if (!strcmp("SwapEqty_DF2NPV()", txa))
    {
        fprintf(out,"?; testing %s\n", txa) ;
        diff = test_swapEqty_DF2price(in, out) ;
    }

    else if (!strcmp("SwapCmdty_DF2NPV()", txa))
    {
        fprintf(out,"?; testing %s\n", txa) ;
        diff = test_swapCmdty_DF2price(in, out) ;
    }

    return diff ;
}


/*
..
*/



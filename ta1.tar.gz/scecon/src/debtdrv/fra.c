/* SCID @(#)fra.c	1.4 (SimCorp) 99/02/19 14:13:00 */

/************************************************************************
*
*   Project     SCecon
*
*   file name   fra.c
*
*   general     This file contains routines for Forward Rate Agreement
*               calculations.
*
************************************************************************/

/* includes ************************************************************/
#include <mm.h>

/*,,SOH,,
*************************************************************************
*
*               FRA_FRABBA2NPV()
*
*    interface  #include <mm.h>
*               FL64 FRA_FRABBA2NPV(DATESTR    *analysis,
*                                   FRA_STR    *fra,
*                                   FL64       srate,
*                                   DISCFAC    *df,
*                                   HOLI_STR   *holi) ;
*
*    general    FRA_FRABBA2NPV() calculates the net present value of a
*               FRA according to the BBA conventions.
*
*    input      DATESTR   *analysis    Pointer to analysis date.
*
*               FRA_STR   *fra         The FRA definition.
*                                      fra->fra assumed as True.
*
*               FL64      srate        Settlement rate in percent.
*
*               DISCFAC   *df          Discount function setup.
*
*               HOLI_STR  *holi        Container for data on business
*                                      day convention and non-week-end
*                                      holidays.
*
*    output
*
*    returns    The net present value as FL64 in %
*
*    diagnostics
*
*    see also   FRA_DF2Rate()
*               FRA_DF2NPV()
*
*    wrapper    AP
*
*************************************************************************
,,EOH,,*/


FL64 FRA_FRABBA2NPV(DATESTR* analysis,
                    FRA_STR*   fra,
                    FL64      srate,
                    DISCFAC*  df,
                    HOLI_STR*  holi)
{
    FL64    poff, npv, disc1, disc2 ;
    DATESTR ppay ;

    /* Avoid dummy cases */
    if (GetPlanFill(df->disc) < 1 ||
        Cldr_DateLT(&fra->settl, analysis) == True)
        return 0.0 ;

    /* Calculate npv according to Q_PERANNUMFORW */
    poff = FRA_Payoff(fra, srate, holi) ;

    /* Discount and convert to desired quoting convention */
    ppay  = Cldr_NextBusinessDate(&fra->pay, holi) ;
	disc1 = Disc_Interpolation(&ppay, df, holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */

    if ((fra->qot == Q_PERANNUMFORW || fra->qot == Q_FLATFORW) &&
        fra->type == MMRATE)
        disc1 = disc2 = 1.0 ;
    else
		disc2 = Disc_Interpolation(analysis, df, holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */

    npv = poff * disc1 ;

    /* Discount till analysis */
    if (fabs(disc2) > 0.000001)
        npv /= disc2 ;
    else
        npv = 0.0 ;

    return npv ;
}


/*,,SOH,,
*************************************************************************
*
*               FRA_DF2NPV()
*
*    interface  #include <mm.h>
*               FL64 FRA_DF2NPV(DATESTR    *analys,
*                               FRA_STR    *fra,
*                               DISCFAC    *df,
*                               HOLI_STR   *holi,
*                               RISKSET    *risk,
*                               FL64       *dp,
*                               FL64       *ddp) ;
*
*    general    FRA_DF2NPV() calculates the net present value of a
*               FRA according to the specified conventions.
*
*               Risk ratios are calculated as follows:
*
*                   risk->key      dp          ddp
*                   ---------      ---         ----
*                   KEY_DF         $Duration   $Convexity
*                   KEY_BPV        BPV
*
*    input      DATESTR   *analys      Pointer to analysis date.
*
*               FRA_STR   *fra         The FRA definition.
*                                      fra->fra assumed as True.
*
*               DISCFAC   *df          Discount function setup.
*
*               HOLI_STR  *holi        Container for data on business
*                                      day convention and non-week-end
*                                      holidays.
*
*               RISKSET   *risk        The risk calculation definition
*                                      Use NULL for no risk ratios
*
*    output     FL64      *dp          The dollar duration
*
*               FL64      *ddp         The dollar convexity
*
*    returns    The net present value as FL64 in %
*
*    diagnostics
*
*    see also   FRA_DF2Rate()
*               FRA_FRABBA2NPV()
*
*    wrapper    AP
*
*************************************************************************
,,EOH,,*/


FL64 FRA_DF2NPV(DATESTR* analys,
                FRA_STR*  fra,
                DISCFAC*  df,
                HOLI_STR* holi,
                RISKSET*  risk,
                FL64*     dp,
                FL64*     ddp)
{
    FL64      shock, pvu, pvd, pv, srate, dum ;
    DISCFAC   sdf ;

    *dp = *ddp = 0.0 ;

    srate = FRA_DF2Rate(fra, df, holi) ;
    pv    = FRA_FRABBA2NPV(analys, fra, srate, df, holi) ;

    if (risk != NULL && (risk->key == KEY_DF || risk->key == KEY_BPV) &&
        risk->risk != ZERO_ORDER)
    {
        shock = Scutl_Default_Shock(risk->shock, risk->key) ;

		sdf = Disc_ShockRates(df, 1.0, risk, holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */
        pvu = FRA_DF2NPV(analys, fra, &sdf, holi, NULL, &dum, &dum) ;
        Free_PLANARRAY(sdf.disc, 1) ;

		sdf = Disc_ShockRates(df, -1.0, risk, holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */
        pvd = FRA_DF2NPV(analys, fra, &sdf, holi, NULL, &dum, &dum) ;
        Free_PLANARRAY(sdf.disc, 1) ;

        if (risk->key == KEY_BPV)
            shock = 1.0 ;

        *dp = -(pvd - pvu) / (2.0 * shock) ;

        if (risk->risk == SECOND_ORDER && risk->key == KEY_DF)
            *ddp = (pvu + pvd - 2.0 * pv) / SQR(shock) ;
    }

    return pv ;
}


/*,,SOH,,
*************************************************************************
*
*               FRA_DF2Rate()
*
*    interface  #include <mm.h>
*               FL64 FRA_DF2Rate(FRA_STR    *fra,
*                                DISCFAC    *df,
*                                HOLI_STR   *holi) ;
*
*    general    FRA_DF2Rate() finds the future interest rate from
*               settlement to maturity of the Forward Rate Agreement
*
*    input      FRA_STR   *fra         The FRA definition
*                                      fra->fra assumed as True.
*                                      fra->qot is not used.
*
*               DISCFAC   *df          Discount function setup.
*
*               HOLI_STR  *holi        Container for data on business
*                                      day convention and non-week-end
*                                      holidays.
*
*    output
*
*    returns    The forward rate from settlement to maturity date
*               as FL64.
*
*    diagnostics
*
*    see also  FRA_DF2NPV()
*
*    wrapper    AP
*
*************************************************************************
,,EOH,,*/


FL64 FRA_DF2Rate(FRA_STR* fra,
                 DISCFAC*   df,
                 HOLI_STR*  holi)
{
    FL64    rate ;
    DATESTR dsett, dmat ;
    IRRCONV irr ;

    if (GetPlanFill(df->disc) < 1)
        return 0.0 ;

    /* Initialise */
    dsett = Cldr_NextBusinessDate(&fra->settl, holi) ;
    dmat  = Cldr_NextBusinessDate(&fra->matur, holi) ;
    irr   = (fra->type == BILLDISC ? DISCOUNT : SIMPLE_MM) ;

    if (Cldr_DateLT(&dsett, &df->disc->day[0]) == True)
        rate = 0.0 ;
    else
		rate = Disc_DF2ForwRate(&dsett, &dmat, fra->cal, df, irr, ANNUALLY, holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */

    return rate ;
}


/*,,SOH,,
*************************************************************************
*
*               FRA_DF2Impl()
*
*    interface  #include <mm.h>
*               BOOLE FRA_DF2Impl(DATESTR    *analys,
*                                 FRA_STR    *fra,
*                                 DISCFAC    *df,
*                                 HOLI_STR   *holi,
*                                 KEYCONV    what,
*                                 FL64       *impl) ;
*
*    general    Given a DF, FRA_DF2Impl() can be used to find one out
*               following three interest rates:
*
*               The implied interest rate is calculated as follows:
*
*                   what           impl
*                   -------        ----
*                   K_FRA          The future interest rate from
*                                  settlement to maturity of the FRA
*
*                   K_SHORT        The interest rate from analys to
*                                  settlement of the FRA
*
*                   K_LONG         The interest rate from analys to
*                                  maturity of the FRA
*
*               If a term structure of interest rates (TS) is given,
*               Disc_TS2DF() can be used to translates a TS into a
*               discount factor structure (DF).
*
*    input      DATESTR   *analys      The analysis date
*
*               FRA_STR   *fra         The FRA definition
*                                      fra->fra assumed as True.
*                                      fra->qot is not used.
*
*               DISCFAC   *df          Discount function setup.
*
*               HOLI_STR  *holi        Container for data on business
*                                      day convention and non-week-end
*                                      holidays.
*
*               KEYCONV   what         What implied rate to calculate
*
*   output      FL64      *impl        The implied rate. Quoted as
*                                      df->irr, df->freq.
*
*   returns     True if OK, False if not
*
*
*   diagnostics
*
*   see also  FRA_DF2Rate()
*
*************************************************************************
,,EOH,,*/


BOOLE FRA_DF2Impl(DATESTR* analys,
                  FRA_STR*    fra,
                  DISCFAC*    df,
                  HOLI_STR*   holi,
                  KEYCONV    what,
                  FL64*       impl)
{
    DATESTR dsett, dmat ;
    BOOLE   ok ;

    ok = True ;

    /* Business adjustment */
    dsett = Cldr_NextBusinessDate(&fra->settl, holi) ;
    dmat  = Cldr_NextBusinessDate(&fra->matur, holi) ;

    /* FRA */
    if (what == KEY_FRA)
        *impl = Disc_DF2ForwRate(&dsett, &dmat, fra->cal,
                                df, df->irr, df->freq, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
    /* SHORT */
    else if (what == KEY_SHORT)
        *impl = Disc_DF2ForwRate(analys, &dsett, fra->cal,
                                df, df->irr, df->freq, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
    /* LONG */
    else if (what == KEY_LONG)
        *impl = Disc_DF2ForwRate(analys, &dmat, fra->cal,
                                df, df->irr, df->freq, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
    return ok ;
}


/*,,SOH,,
*************************************************************************
*
*               FRA_DF2Delta()
*
*    interface  #include <mm.h>
*               FL64ARRAY FRA_DF2Delta(DATESTR    *analys,
*                                      FRA_STR    *fra,
*                                      DISCFAC    *df,
*                                      HOLI_STR   *holi,
*                                      DELTASET   *ds) ;
*
*   general     FRA_DF2Delta() calculates the delta vector for
*               a FRA using a list of predefined shocks to the zero
*               coupon curve.
*
*               The delta vector represents the price differences
*               invoked by the curve shocks.
*
*    input      DATESTR   *analys      Pointer to analysis date.
*
*               FRA_STR   *fra         The FRA definition.
*                                      fra->fra assumed as True.
*
*               DISCFAC   *df          Discount function setup.
*
*               HOLI_STR  *holi        Container for data on business
*                                      day convention and non-week-end
*                                      holidays.
*
*               DELTASET  *ds          Data for delta calculation
*
*
*    output
*
*    returns    The delta vector allocated as:
*
*                         Alloc_FL64ARRAY(ds->nshock) ;
*
*    diagnostics
*
*    see also   FRA_DF2Rate()
*               FRA_FRABBA2NPV()
*
*    wrapper    AP
*
*************************************************************************
,,EOH,,*/


FL64ARRAY FRA_DF2Delta(DATESTR* analys,
                  FRA_STR*   fra,
                  DISCFAC*   df,
                  HOLI_STR*  holi,
                  DELTASET*  ds)
{
    FL64ARRAY dv ;
    INTI      i ;
    DATESTR   fsprev, mat ;
    FL64      dum, p0 ;
    PLANARRAY old ;

    dv = Alloc_FL64ARRAY(ds->nshock) ;

    /* Various initialisation */
    old       = df->disc ;
    mat       = Cldr_NextBusinessDate(&fra->matur, holi) ;

    p0 = FRA_DF2NPV(analys, fra, df, holi, NULL, &dum, &dum) ;

    for (i = 0; i < ds->nshock; i++)
    {
        fsprev = Disc_get_chgdate(NULL, old, &ds->shock[i]) ;

        if (fsprev.y > 0 && Cldr_DateLT(&mat, &fsprev) == False)
        {
            df->disc = &ds->shock[i] ;
            dv[i]    = FRA_DF2NPV(analys, fra, df, holi, NULL, &dum, &dum) ;
            dv[i]   -= p0 ;

            if (ds->zero == True)
                /* Find shocked Zero PV */
				dv[i] /= Disc_DF2BPV(&ds->mid[i], df, old, holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */
        }
        else
            dv[i] = 0.0 ;
    }

    df->disc = old ;

    return dv ;
}



/*
..
*/


IRRCONV FRA_RATECONV2IRRCONV(RATECONV fra)
{
    IRRCONV irr ;

    irr = SIMPLE_MM ;

    if (fra == MMRATE)
        irr = SIMPLE_MM ;
    else if (fra == BILLDISC)
        irr = DISCOUNT ;
    else if (fra == BILLYIELD)
        irr = SIMPLE_MM ;

    return irr ;
}


/*
..
*/

/*,,SOH,,
************************************************************************
*
*                Set_FRA_STR()
*
*   interface    #include <mm.h>
*                FRA_STR Set_FRA_STR(DATESTR  *settl,
*                                    DATESTR  *matur,
*                                    CALCONV  cal,
*                                    FL64     price,
*                                    BOOLE    fra,
*                                    QOTCONV  qot,
*                                    PMTFREQ  freq,
*                                    RATECONV type,
*                                    DATESTR  *pay) ;
*
*   general      This routine sets the members of the struct defined
*                in the function name. The pointer members are simply
*                assigned - without physical copying. The intention
*                of the Set_*() routines is that by using this
*                functionality, one avoids setting individual members
*                of structs in the application code.
*
*                When new members are inserted in structs the Set_*()
*                routine will be changed accordingly.
*
*                One exception to this principle applies. Whenever
*                OPTADD and vanilla members are used, only the
*                vanilla members are set in the Set_*() routines. The
*                non-vanilla and exotic members are set to defaults,
*                and must be set elsewhere - if needed.
*
*                For details on the interpretation of the individual
*                struct members please check the struct definition.
*
*   input        DATESTR  *settl See general section.
*
*                DATESTR  *matur See general section.
*
*                CALCONV  cal    See general section.
*
*                FL64     price  See general section.
*
*                BOOLE    fra    See general section.
*
*                QOTCONV  qot    See general section.
*
*                PMTFREQ  freq   See general section.
*
*                RATECONV type   See general section.
*
*                DATESTR  *pay   See general section.
*
*   output
*
*   returns      The filled out FRA_STR struct
*
*   diagnostics
*
*   see also     FRA_STR
*
************************************************************************
,,EOH,,*/

FRA_STR Set_FRA_STR(DATESTR*  settl,
                       DATESTR*  matur,
                       CALCONV   cal,
                       FL64      price,
                       BOOLE     fra,
                       QOTCONV   qot,
                       PMTFREQ   freq,
                       RATECONV  type,
                       DATESTR*  pay)
{
    FRA_STR frao ;

    frao.settl = *settl ;
    frao.matur = *matur ;
    frao.cal   = cal ;
    frao.price = price ;
    frao.fra   = fra ;
    frao.qot   = qot ;
    frao.freq  = freq ;
    frao.type  = type ;

    if (pay != NULL)
        frao.pay = *pay ;
    else
        frao.pay = *settl ;

    return frao ;
}


/*
..payoff at settle
..FRA's only
*/

FL64 FRA_Payoff(FRA_STR* fra,
                FL64     srate,
                HOLI_STR* holi)
{
    FL64    agreed, poff, dt ;
    DATESTR dsett, dmat ;
    IRRCONV irr ;

    /* warning avoidance */
    poff = 0.0 ;

    /* Businessday adjust */
    dsett = Cldr_NextBusinessDate(&fra->settl, holi) ;
    dmat  = Cldr_NextBusinessDate(&fra->matur, holi) ;

    /* Set some data */
    agreed = fra->price ;
	dt = Cldr_TermBetweenDates(&dsett, &dmat, 0, fra->cal, LAST, holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */
    irr    = FRA_RATECONV2IRRCONV(fra->type) ;

    if (fra->type == MMRATE)
    {
        /* Payoff at maturity -- illustrate payoff in detail as a deposit */
        if (fra->qot == Q_PERANNUM || fra->qot == Q_PERANNUMFORW)
            poff = (100.0 + srate) - (100.0 + agreed) ;
        else
            poff = (100.0 + srate * dt) - (100.0 + agreed * dt) ;

        /* Now discount payoff to settle -- if required */
        poff *= TVMunit_NPV(dt, srate, irr, 0) ;
    }
    else if (fra->type == BILLDISC)
    {
        /* Here the maturity payment is 100, and a discount at settle */
        poff = TVMunit_NPV(dt, agreed, irr, 0) -
               TVMunit_NPV(dt, srate, irr, 0) ;
        poff *= 100.0 ;
/*        poff = (100.0 - agreed * dt) - (100.0 - srate * dt) ;*/

        /* So do NOT discount payoff from maturity */
    }

    else if (fra->type == BILLYIELD)
    {
        /* Here the maturity payment is 100 - but rate is quoted as yield */
        poff = TVMunit_NPV(dt, agreed, irr, 0) -
               TVMunit_NPV(dt, srate, irr, 0) ;
        poff *= 100.0 ;

        /* So do NOT discount payoff from maturity */
    }

    /* Discounting from paydate is NOT done here since this is a
       payoff function */

    return poff ;
}

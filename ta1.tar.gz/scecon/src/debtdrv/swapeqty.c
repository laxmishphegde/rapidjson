/* SCID @(#)swapeqty.c	1.4 (SimCorp) 99/02/19 14:13:45 */

/************************************************************************
*
*       project         SCecon Library
*
*       file name       swapeqty.c
*
*       contains        float leg functions for equity and commodity
*                       related swap structures
*
************************************************************************/

/*** includes **********************************************************/
#include <swapval.h>


/*,,SOH,,
*************************************************************************
*
*              SwapEqty_DF2NPV()
*
*    interface #include <swapval.h>
*              FL64 SwapEqty_DF2NPV(DATESTR       *analys,
*                                   SWAPFLOAT     *eqsw,
*                                   DISCFAC       *df_div,
*                                   DISCFAC       *df_disc,
*                                   HOLI_STR      *holi) ;
*
*    general   This routine calculates npv and simple risk ratios for
*              a floating leg based on an Equity Index.
*
*              The payments on the leg is forecasted using the discount
*              factor curve (df_div). This curve can be generated from
*              Term Structures of Dividend Yields using Disc_TS2DF().
*
*              Term Stucture of Dividend Yield can be backed out of
*              forward prices - use futEqty_CC2implyld().
*
*    input     DATESTR   *analys  Pointer to analysis date.
*
*              SWAPFLOAT *eqsw    The float leg definition
*
*              DISCFAC   *df_div  Discount function of dividend
*                                 yields. Used to generate index-related*
*                                 payments.
*
*              DISCFAC   *df_disc Discounting structure setup.
*                                 Used for discounting
*
*              HOLI_STR  *holi    Business day adjustment setup
*
*    output
*
*    returns   The present value
*
*    diagnostics
*
*    see also  SwapFl_DF2NPV()
*              SwapCmdty_DF2NPV()
*
*************************************************************************
,,EOH,,*/

FL64 SwapEqty_DF2NPV(DATESTR* analys,
                     SWAPFLOAT* eqsw,
                     DISCFAC*   df_div,
                     DISCFAC*   df_disc,
                     HOLI_STR*  holi)
{
    FL64      npv, dp ;
    DISCFAC   index ;

    /* Now generate a simulated index - essentially the forward curve */
	index = Disc_MergeDF(df_disc, df_div, holi);   	/* PMSTA-22396 - SRIDHARA � 160502 */

    /* Get the right conventions */
    index = Set_DISCFAC(index.disc, df_div->what, df_div->iconv,
                             df_div->cal, df_div->irr, df_div->freq) ;

    /* Ready to PV */
    npv = SwapFl_DF2NPV(analys, eqsw, &index, df_disc, NULL, holi,
                        NULL, &dp, &dp) ;

    Free_PLANARRAY(index.disc, 1) ;

    return npv ;
}


/*,,SOH,,
*************************************************************************
*
*              SwapCmdty_DF2NPV()
*
*    interface #include <swapval.h>
*              FL64 SwapCmdty_DF2NPV(DATESTR       *analys,
*                                    SWAPFLOAT     *cmsw,
*                                    DISCFAC       *df_conv,
*                                    DISCFAC       *df_stor,
*                                    DISCFAC       *df_disc,
*                                    HOLI_STR      *holi) ;
*
*    general   This routine calculates npv and simple risk ratios for
*              a floating leg based on a Commodity Index.
*
*              The payments on the leg is forecasted using the discount
*              factor curves (df_conv and df_stor). These curves can
*              be generated from Term Structures of Convenience Yield
*              and Storage Costs using disc_TS2df().
*
*              Term Structures of Convenience Yields and Storage Costs
*              are often merged into a single Term Structure, when
*              backed out of forward prices - use FutCmdty_CC2Implyld().*
*
*    input     DATESTR    *analys    Pointer to analysis date.
*
*              SWAPFLOAT  *cmsw      Float leg definition
*
*              DISCFAC    *df_conv   Discount function of convenience
*                                    yields. Used to generate payments.
*
*              DISCFAC    *df_stor   Discount function of storage costs
*                                    Used to generate payments
*
*              DISCFAC    *df_disc   Discounting structure setup.
*                                    Used for discounting
*
*              HOLI_STR   *holi      Container for data on business
*                                    day convention and non-week-end
*                                    holidays.
*
*    output
*
*    returns   The present value
*
*    diagnostics
*
*    see also  SwapFl_DF2NPV()
*              SwapEqty_DF2NPV()
*
*************************************************************************
,,EOH,,*/


FL64 SwapCmdty_DF2NPV(DATESTR* analys,
                      SWAPFLOAT* cmsw,
                      DISCFAC*   df_conv,
                      DISCFAC*   df_stor,
                      DISCFAC*   df_disc,
                      HOLI_STR*  holi)
{
    FL64        npv, dp ;
    DISCFAC     index, cc_df ;

    /* Combine the DISCFAC's 'conv_df' and 'stor_df' */
	cc_df = Disc_MergeDF(df_conv, df_stor, holi);   	/* PMSTA-22396 - SRIDHARA � 160502 */

    /* Now generate a simulated index - essentially the forward curve */
	index = Disc_MergeDF(df_disc, &cc_df, holi);   	/* PMSTA-22396 - SRIDHARA � 160502 */

    /* Get the right conventions */
    index = Set_DISCFAC(index.disc, cc_df.what, cc_df.iconv,
                        cc_df.cal, cc_df.irr, cc_df.freq) ;

    /* Ready to PV */
    npv = SwapFl_DF2NPV(analys, cmsw, &index, df_disc, NULL, holi,
                        NULL, &dp, &dp) ;

    Free_PLANARRAY(cc_df.disc, 1) ;
    Free_PLANARRAY(index.disc, 1) ;

    return npv ;
}

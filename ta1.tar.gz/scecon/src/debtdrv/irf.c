/* SCID @(#)irf.c	1.4 (SimCorp) 99/02/19 14:13:36 */

/************************************************************************
*
*   Project     SCecon
*
*   file name   irf.c
*
*   general     This file contains routines for Interest Rate Future
*               calculations.
*
************************************************************************/

/* includes ************************************************************/
#include <mm.h>


/*,,SOH,,
*************************************************************************
*
*               IRF_FRABBA2NPV()
*
*    interface  #include <mm.h>
*               FL64 IRF_FRABBA2NPV(DATESTR    *analysis,
*                                   FRA_STR    *irf,
*                                   FL64       sprice,
*                                   HOLI_STR   *holi) ;
*
*    general    IRF_FRABBA2NPV() calculates the net present value of
*               an interest rate future using standard margin based
*               pricing.
*
*    input      DATESTR   *analysis    Pointer to analysis date.
*
*               FRA_STR   *irf         The IRF definition.
*                                      irf->fra is assumed as False.
*                                      irf->qot is not used.
*
*               FL64      sprice       Settlement price.
*
*               HOLI_STR  *holi        Container for data on business
*                                      day convention and non-week-end
*                                      holidays.
*
*    output
*
*    returns    The net present value as FL64 in %
*
*    diagnostics
*
*    see also   IRF_DF2Price()
*
*    wrapper    AP
*
*************************************************************************
,,EOH,,*/


FL64 IRF_FRABBA2NPV(DATESTR* analysis,
                    FRA_STR*    irf,
                    FL64       sprice,
                    HOLI_STR*   holi)
{
    FL64 poff ;

    /* Avoid dummy cases */
    if (Cldr_DateLT(&irf->settl, analysis) == True)
        return 0.0 ;

    /* Find payoff */
    poff = IRF_Payoff(irf, sprice, holi) ;

    return poff ;
}


/*,,SOH,,
*************************************************************************
*
*               IRF_DF2NPV()
*
*    interface  #include <mm.h>
*               FL64 IRF_DF2NPV(DATESTR    *analys,
*                               FRA_STR    *irf,
*                               DISCFAC    *df,
*                               HOLI_STR   *holi,
*                               RISKSET    *risk,
*                               FL64       *dp,
*                               FL64       *ddp) ;
*
*    general    IRF_DF2NPV() calculates the net present value of
*               an interest rate future according to the
*               conventions.
*
*               Risk ratios are calculated as follows:
*
*                   risk->key      dp          ddp
*                   ---------      ---         ----
*                   KEY_DF         $Duration   $Convexity
*                   KEY_BPV        BPV
*
*    input      DATESTR   *analys      Pointer to analysis date.
*
*               FRA_STR   *irf         The IRF definition.
*                                      irf->fra is assumed as False.
*
*               DISCFAC   *df          Discount function setup.
*
*               HOLI_STR  *holi        Container for data on business
*                                      day convention and non-week-end
*                                      holidays.
*
*               RISKSET   *risk        The risk calculation definition
*                                      Use NULL for no risk ratios
*
*    output     FL64      *dp          The dollar duration
*
*               FL64      *ddp         The dollar convexity
*
*    returns    The net present value as FL64 in %
*
*    diagnostics
*
*    see also   IRF_DF2Price()
*
*    wrapper    AP
*
*************************************************************************
,,EOH,,*/


FL64 IRF_DF2NPV(DATESTR* analys,
                FRA_STR*    irf,
                DISCFAC*    df,
                HOLI_STR*   holi,
                RISKSET*    risk,
                FL64*       dp,
                FL64*       ddp)
{
    FL64      pvu, pvd, shock, pv, sprice, dum ;
    DISCFAC   sdf ;

    /* Initialise */
    *dp = *ddp = 0.0 ;

    /* Avoid this */
    if (GetPlanFill(df->disc) < 1 ||
        Cldr_DateLT(&irf->settl, analys) == True)
        return 0.0 ;

    sprice = IRF_DF2Price(irf, df, holi) ;
    pv     = IRF_FRABBA2NPV(analys, irf, sprice, holi) ;

    if (risk != NULL && (risk->key == KEY_DF || risk->key == KEY_BPV) &&
        risk->risk != ZERO_ORDER)
    {
        shock = Scutl_Default_Shock(risk->shock, risk->key) ;

		sdf = Disc_ShockRates(df, 1.0, risk, holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */
        pvu = IRF_DF2NPV(analys, irf, &sdf, holi, NULL, &dum, &dum) ;
        Free_PLANARRAY(sdf.disc, 1) ;

		sdf = Disc_ShockRates(df, -1.0, risk, holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */
        pvd = IRF_DF2NPV(analys, irf, &sdf, holi, NULL, &dum, &dum) ;
        Free_PLANARRAY(sdf.disc, 1) ;

        if (risk->key == KEY_BPV)
            shock = 1.0 ;

        if (risk->risk == FIRST_ORDER || risk->risk == SECOND_ORDER)
            *dp  = -(pvd - pvu) / (2.0 * shock) ;

        if (risk->risk == SECOND_ORDER && risk->key == KEY_DF)
            *ddp = (pvu + pvd - 2.0 * pv) / SQR(shock) ;
    }

    return pv ;
}


/*,,SOH,,
*************************************************************************
*
*               IRF_DF2Price()
*
*    interface  #include <mm.h>
*               FL64 IRF_DF2Price(FRA_STR    *irf,
*                                 DISCFAC    *df,
*                                 HOLI_STR   *holi) ;
*
*    general    IRF_DF2Price() finds the expected IRF price, that
*               corresponds to a future LIBOR rate.
*
*    input      FRA_STR   *irf         The IRF definition.
*                                      irf->fra is assumed as False.
*
*               DISCFAC   *df          Discount function setup.
*
*               HOLI_STR  *holi        Container for data on business
*                                      day convention and non-week-end
*                                      holidays.
*
*    output
*
*    returns    The IRF price corresponding to a forward rate from
*               settlement to maturity date, as a FL64.
*
*    diagnostics
*
*    see also  IRF_FRABBA2NPV()
*
*    wrapper    AP
*
*************************************************************************
,,EOH,,*/


FL64 IRF_DF2Price(FRA_STR* irf,
                  DISCFAC*    df,
                  HOLI_STR*   holi)
{
    FL64    rate, price ;
    DATESTR dsett, dmat ;
    IRRCONV irr ;

    /* Avoid dummy cases */
    if (GetPlanFill(df->disc) < 1)
        return 0.0 ;

    /* Initialise */
    dsett = Cldr_NextBusinessDate(&irf->settl, holi) ;
    dmat  = Cldr_NextBusinessDate(&irf->matur, holi) ;
    irr   = (irf->type == BILLDISC ? DISCOUNT : SIMPLE_MM) ;

    if (Cldr_DateLT(&dsett, &df->disc->day[0]) == True)
        price = 0.0 ;
    else
    {
        rate  = Disc_DF2ForwRate(&dsett, &dmat, irf->cal, df, irr, ANNUALLY, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
        price = 100.0 - rate ;
    }

    return price ;
}


/*,,SOH,,
*************************************************************************
*
*               IRF_DF2Delta()
*
*    interface  #include <mm.h>
*               FL64ARRAY IRF_DF2Delta(DATESTR   *analys,
*                                      FRA_STR    *irf,
*                                      DISCFAC    *df,
*                                      HOLI_STR   *holi,
*                                      DELTASET   *ds) ;
*
*   general     IRF_DF2Delta() calculates the delta vector for
*               a IRF using a list of predefined shocks to the zero
*               coupon curve.
*
*               The delta vector represents the price differences
*               invoked by the curve shocks.
*
*    input      DATESTR   *analys      Pointer to analysis date.
*
*               FRA_STR   *irf         The IRF definition.
*                                      irf->fra assumed as False.
*
*               DISCFAC   *df          Discount function setup.
*
*               HOLI_STR  *holi        Container for data on business
*                                      day convention and non-week-end
*                                      holidays.
*
*               DELTASET  *ds          Delta defining data
*
*
*    output
*
*    returns    The delta vector allocated as:
*
*                         Alloc_FL64ARRAY(ds->nshock) ;
*
*    diagnostics
*
*    see also   IRF_DF2Price()
*               IRF_FRABBA2NPV()
*
*    wrapper    AP
*
*************************************************************************
,,EOH,,*/


FL64ARRAY IRF_DF2Delta(DATESTR* analys,
                  FRA_STR*   irf,
                  DISCFAC*   df,
                  HOLI_STR*  holi,
                  DELTASET*  ds)
{
    FL64ARRAY dv ;
    INTI      i ;
    DATESTR   mat, fsprev ;
    FL64      dum, p0 ;
    PLANARRAY old ;

    dv = Alloc_FL64ARRAY(ds->nshock) ;

    /* Various initialisation */
    old       = df->disc ;
    mat       = Cldr_NextBusinessDate(&irf->matur, holi) ;

    p0 = IRF_DF2NPV(analys, irf, df, holi, NULL, &dum, &dum) ;

    for (i = 0; i < ds->nshock; i++)
    {
        fsprev = Disc_get_chgdate(NULL, old, &ds->shock[i]) ;

        if (fsprev.y > 0 && Cldr_DateLT(&mat, &fsprev) == False)
        {
            df->disc = &ds->shock[i] ;
            dv[i]    = IRF_DF2NPV(analys, irf, df, holi, NULL, &dum, &dum) ;
            dv[i]   -= p0 ;

            if (ds->zero == True)
                /* Find shocked Zero PV */
				dv[i] /= Disc_DF2BPV(&ds->mid[i], df, old, holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */
        }
        else
            dv[i] = 0.0 ;
    }

    df->disc = old ;

    return dv ;
}



/*
..payoff at settle
..IRF's only
*/


FL64 IRF_Payoff(FRA_STR* irf,
                FL64     sprice,
                HOLI_STR* holi)
{
    FL64    srate, agreed, poff, dt ;
    DATESTR dsett, dmat ;

    /* warning avoidance */
    poff = 0.0 ;

    /* Businessday adjust */
    dsett = Cldr_NextBusinessDate(&irf->settl, holi) ;
    dmat  = Cldr_NextBusinessDate(&irf->matur, holi) ;

    /* Set some data */
    agreed = irf->price ;
    if (irf->freq != NO_FREQUENCY)
        dt = ((FL64) Cflw_MonthsBetweenPayments(irf->freq)) / 12.0;
    else
		dt = Cldr_TermBetweenDates(&dsett, &dmat, 0, irf->cal, LAST, holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */

    if (irf->type == MMRATE)
    {
        /* Payoff at settlement */
        poff = (sprice - agreed) * dt ;

        /* So do NOT discount payoff from maturity */
    }
    else if (irf->type == BILLDISC)
    {
        /* Payoff at settlement */
        poff = (sprice - agreed) * dt ;

        /* So do NOT discount payoff from maturity */
    }

    else if (irf->type == BILLYIELD)
    {
        /* Payoff at settlement -- find eqv rates */
        srate  = 100.0 - sprice ;
        agreed = 100.0 - agreed ;
        poff   = TVMunit_NPV(dt, srate, SIMPLE_MM, 0) -
                 TVMunit_NPV(dt, agreed, SIMPLE_MM, 0) ;
        poff  *= 100.0 ;

        /* So do NOT discount payoff from maturity */
    }

    return poff ;
}

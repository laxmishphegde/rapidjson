/* @(#)tstfrn.c	1.5 (SimCorp) 99/02/19 14:13:52 */

/************************************************************************
*
*   project     SCecon
*
*   this program tests the routines in the Floating Rate Note  module
*   of SCecon
*
************************************************************************/

/*** includes ***********************************************************/
#include <string.h>
#include <scalloc.h>
#include <stdlib.h>

#include <futio.h>
#include <frn.h>
#include <ioconv.h>
#include <bondio.h>

INTI frntest(char* txa, FILE* in, FILE* out)
{
    char        txb[30], txc[30], txpl[120] ;
    FL64        acc1, acc, fexp1, fexp2, fexp3, fres1, fres2, fres3 ;
    FL64        sm, price, coup, dm, qm, ix, ax, p1, Lnext ;
    FL64        ytm, *dv, *cl, Lcurr, Lasm, *amort, shift ;
    INTI        i, n1, diff, nbucket ;
    BOOLE       modf, zero, ok, mean ;
    int         i1 ;
    DATESTR     analys ;
    RISKCONV    risk ;
    FRN         frn ;
    DISCFAC     df, dfa ;
    CMCONVADJ   cmadj ;
    HOLI_STR    holi ;
    DFSPREAD    dfs ;
    RISKSET     rs ;
    AIRESULT    aires, aiexp ;
    CFLWARRAY   cflw, cflwx ;
    BUCKETARRAY bucket ;
    DELTASET    ds ;
    VOL_STR     CMTvol ;
    YTMCONV     ytmc ;
    ITERCTRL    ictrl ;

    acc = 0.00001 ;

    diff = -1 ;

    if (!strcmp(txa, "FRN_Discountmargin2Price()"))
    {
        fscanf(in,"%lf %lf %lf %lf %s %lf %lf %d %lf %lf %s",
               &fexp1, &fexp2, &fexp3, &dm, txc, &coup, &qm,
               &i1, &ix, &ax, txpl);

        n1 = (INTI) i1 ;
        cl    = Alloc_FL64ARRAY(n1) ;
        amort = Alloc_FL64ARRAY(n1) ;
        for (i = 0 ; i < n1 ; i++)
             fscanf(in, "%lf %lf", &cl[i], &amort[i]) ;

        risk  = Str2RISKCONV(txc) ;
        fres1 = FRN_Discountmargin2Price(dm, &fres2, &fres3, risk, coup, qm,
                                         n1, cl, amort, ix, ax);

        diff = (fabs(fexp1 - fres1) > acc ||
                fabs(fexp2 - fres2) > acc ||
                fabs(fexp3 - fres3) > acc) ;

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   discounted margin         %10.5lf\n", dm) ;
        fprintf(out,"   first coupon              %10.5lf\n", coup) ;
        fprintf(out,"   quoted margin             %10.5lf\n", qm) ;
        fprintf(out,"   number of future payments %10d\n", n1) ;
        fprintf(out,"   current index rate        %10.5lf\n", ix) ;
        fprintf(out,"   assumed future index rate %10.5lf\n", ax) ;
        fprintf(out,"   risk toggle %s\n", txc) ;

        fprintf(out,"%d; p   = %10.5lf; expected = %10.5lf\n",
                (fabs(fres1 - fexp1) > acc), fres1, fexp1);
        fprintf(out,"%d; dp  = %10.5lf; expected = %10.5lf\n",
                (fabs(fres2 - fexp2) > acc), fres2, fexp2);
        fprintf(out,"%d; ddp = %10.5lf; expected = %10.5lf\n",
                (fabs(fres3 - fexp3) > acc), fres3, fexp3);
        fprintf(out,"   term between payments + amortizations...\n") ;
        fprintf(out,"   termnumber:  term     amort\n") ;
        for (i = 0 ; i < n1 ; i++)
            fprintf(out,"      %3d   %lf %lf\n", i, cl[i], amort[i]) ;

        fprintf(out,"   %s\n\n", txpl) ;
        Free_FL64ARRAY(cl) ;
        Free_FL64ARRAY(amort) ;
    }

    else if (!strcmp(txa, "FRN_Price2Discountmargin()"))
    {
        fscanf(in,"%lf %lf %lf %lf %d %lf %lf %s",
               &fexp1, &p1, &coup, &qm, &i1, &ix, &ax,
               txpl);

        n1 = (INTI) i1 ;
        cl = Alloc_FL64ARRAY(n1) ;
        amort = Alloc_FL64ARRAY(n1) ;
        for (i = 0 ; i < n1 ; i++)
             fscanf(in, "%lf %lf", &cl[i], &amort[i]) ;

        ok = FRN_Price2Discountmargin(p1, coup, qm, n1, cl, amort,
                                         ix, ax, &fres1) ;
        diff = (fabs(fexp1 - fres1) > acc) ;

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   dirty price of FRN        %10.5lf\n", p1) ;
        fprintf(out,"   first coupon              %10.5lf\n", coup) ;
        fprintf(out,"   quoted margin             %10.5lf\n", qm) ;
        fprintf(out,"   number of future payments %10d\n", n1) ;
        fprintf(out,"   current index rate        %10.5lf\n", ix) ;
        fprintf(out,"   assumed future index rate %10.5lf\n", ax) ;
        fprintf(out,"   error code                %10d\n", ok) ;
        fprintf(out,
          "   result is %10.5lf ; expected is %10.5lf\n",
          fres1, fexp1) ;
        fprintf(out,"   term between payments + amortizations...\n") ;
        fprintf(out,"   termnumber:  term    amort\n") ;
        for (i = 0 ; i < n1 ; i++)
            fprintf(out,"      %3d   %lf %lf\n", i, cl[i], amort[i]) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_FL64ARRAY(cl) ;
        Free_FL64ARRAY(amort) ;
    }

    else if (!strcmp(txa, "FRN_YTM2Price()"))
    {
        fprintf(out,"?; testing %s\n", txa) ;
        fexp1  = Read_FL64(in, out, "   Expected P   ") ;
        fexp2  = Read_FL64(in, out, "   Expected dP  ") ;
        fexp3  = Read_FL64(in, out, "   Expected ddP ") ;

        analys = Read_DATESTR(in, out, "   Analys       ") ;
        ytm    = Read_FL64(in, out, "   YTM          ") ;
        frn    = Read_FRN(in, out) ;
        ytmc   = Read_YTMCONV(in, out) ;        
        holi   = Read_HOLI_STR(in, out) ;
        risk   = Read_RISKCONV(in, out, "   RiskConv     ") ;
        modf   = Read_BOOLE(in, out, "   Modified ?   ") ;

        ok = FRN_YTM2Price(&analys, ytm, &frn, &ytmc, &holi, risk, modf,
                           &fres1, &fres2, &fres3) ;

        diff = Write_RiskDiff(True, ok, fres1, fres2, fres3,
                              fexp1, fexp2, fexp3, acc, out) ;

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_FRN(&frn);
        Free_DATEARRAY(holi.holidays) ;
    }

    else if (!strcmp(txa, "FRN_YTM2PV01()"))
    {
        fprintf(out,"?; testing %s\n", txa) ;

        /* Expected Result */
        fexp1  = Read_FL64(in, out, "   Expected result   ") ;

        /* Read DATA */
        ytm    = Read_FL64(in, out, "   YTM          ") ;
        analys = Read_DATESTR(in, out, "   Analys       ") ;
        frn    = Read_FRN(in, out) ;
        ytmc   = Read_YTMCONV(in, out) ;        
        holi   = Read_HOLI_STR(in, out) ;
        shift  = Read_FL64(in, out, "   Yshift       ") ; 
        mean   = Read_BOOLE(in, out, "   Mean         ") ;

        /* Calculate */
        ok = FRN_YTM2PV01(ytm, &analys, &frn, &ytmc, &holi, 
                          shift, mean, &fres1) ;

        /* Compare */
        diff = Write_SingleDiff(ok, True, fres1, fexp1, 0.000001, out) ;

        /* Comments */
        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_FRN(&frn);
        Free_DATEARRAY(holi.holidays) ;
    }

    else if (!strcmp(txa, "FRN_YTM2YV01()"))
    {
        fprintf(out,"?; testing %s\n", txa) ;

        /* Expected Result */
        fexp1  = Read_FL64(in, out, "   Expected result   ") ;
        acc1   = Read_FL64(in, out, "   Accuracy    ") ;

        /* Read DATA */
        analys = Read_DATESTR(in, out, "   Analys       ") ;
        price  = Read_FL64(in, out, "   Price        ") ;
        frn    = Read_FRN(in, out) ;
        ytmc   = Read_YTMCONV(in, out) ;        
        holi   = Read_HOLI_STR(in, out) ;
        ictrl  = Read_ITERCTRL(in, out) ;
        shift  = Read_FL64(in, out, "   Pshift       ") ; 
        mean   = Read_BOOLE(in, out, "   Mean         ") ;

        /* Calculate */
        ok = FRN_YTM2YV01(&analys, price, &frn, &ytmc, &holi, &ictrl,
                          shift, mean, &fres1) ;
        /* Compare */
        diff = Write_SingleDiff(ok, True, fres1, fexp1, acc1, out) ;

        /* Comments */
        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_FRN(&frn);
        Free_DATEARRAY(holi.holidays) ;
    }

    else if (!strcmp(txa, "FRN_YTM2Yield()"))
    {
        fprintf(out,"?; testing %s\n", txa) ;
        fexp1  = Read_FL64(in, out, "   Expected YTM ") ;
        acc1   = Read_FL64(in, out, "   Accuracy    ") ;

        analys = Read_DATESTR(in, out, "   Analys       ") ;
        price  = Read_FL64(in, out, "   Price        ") ;
        frn    = Read_FRN(in, out) ;
        ytmc   = Read_YTMCONV(in, out) ;        
        holi   = Read_HOLI_STR(in, out) ;
        ictrl  = Read_ITERCTRL(in, out) ;

        ok = FRN_YTM2Yield(&analys, price, &frn, &ytmc, &holi, &ictrl, &fres1);
        diff = Write_SingleDiff(True, True, fres1, fexp1, acc1, out) ;

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_FRN(&frn);
        Free_DATEARRAY(holi.holidays) ;
    }

    else if (!strcmp(txa, "FRN_DM2Price()"))
    {
        fprintf(out,"?; testing %s\n", txa) ;
        fexp1  = Read_FL64(in, out, "   Expected P   ") ;
        analys = Read_DATESTR(in, out, "   Analys       ") ;
        dm     = Read_FL64(in, out, "   DM           ") ;
        frn    = Read_FRN(in, out) ;
        Lcurr  = Read_FL64(in, out, "   Curr LIBOR   ") ;
        Lasm   = Read_FL64(in, out, "   Asm LIBOR    ") ;
        holi   = Read_HOLI_STR(in, out) ;

        fres1 = FRN_DM2Price(&analys, dm, &frn, Lcurr, Lasm, &holi, &ok) ;
        diff  = Write_SingleDiff(True, True, fres1, fexp1, acc, out) ;

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_FRN(&frn);
        Free_DATEARRAY(holi.holidays) ;
    }

    else if (!strcmp(txa, "FRN_DM2DiscMrgn()"))
    {
        fprintf(out,"?; testing %s\n", txa) ;
        fexp1  = Read_FL64(in, out, "   Expected DM  ") ;
        analys = Read_DATESTR(in, out, "   Analys       ") ;
        price  = Read_FL64(in, out, "   Price        ") ;
        frn    = Read_FRN(in, out) ;
        Lcurr  = Read_FL64(in, out, "   Curr LIBOR   ") ;
        Lasm   = Read_FL64(in, out, "   Asm LIBOR    ") ;
        holi   = Read_HOLI_STR(in, out) ;

        ok = FRN_DM2DiscMrgn(&analys, price, &frn, Lcurr, Lasm, &holi, &fres1) ;
        diff = Write_SingleDiff(True, True, fres1, fexp1, acc, out) ;

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_FRN(&frn);
        Free_DATEARRAY(holi.holidays) ;
    }

    else if (!strcmp("FRN_GenrCflw()", txa))
    {
        fprintf(out,"?; testing %s\n", txa) ;
        
        analys = Read_DATESTR(in, out, "   Analys       ") ;
        frn    = Read_FRN(in, out) ;
        df     = Read_DISCFAC(in, out) ;
        dfa    = Read_DISCFAC(in, out) ;
        cmadj  = Read_CMCONVADJ(in, out) ;
        holi   = Read_HOLI_STR(in, out) ;

        cflw = FRN_GenrCflw(&analys, &frn, &df, &dfa, &cmadj, &holi) ;

        cflwx = Read_CFLWARRAY(in, out) ;
        diff  = Write_CflwDiff(cflwx, cflw, out) ;

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_FRN(&frn) ;
        Free_DATEARRAY(holi.holidays) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_PLANARRAY(dfa.disc, 1) ;
        Free_PLANARRAY(cmadj.volCM.vol, 1) ;
        Free_PLANARRAY(cmadj.volLIBOR.vol, 1) ;
        Free_CFLWARRAY(cflw, 1) ;
        Free_CFLWARRAY(cflwx, 1) ;
    }

    else if (!strcmp("FRN_GenrPeriod()", txa))
    {
        fprintf(out,"?; testing %s\n", txa) ;
        analys = Read_DATESTR(in, out, "   Analys       ") ;
        frn   = Read_FRN(in, out) ;
        df    = Read_DISCFAC(in, out) ;
        dfa   = Read_DISCFAC(in, out) ;
        cmadj = Read_CMCONVADJ(in, out) ;
        holi  = Read_HOLI_STR(in, out) ;

        cflw  = FRN_GenrPeriod(&analys, &frn, &df, &dfa, &cmadj, &holi) ;

        cflwx = Read_CFLWARRAY(in, out) ;
        diff  = Write_CflwDiff(cflwx, cflw, out) ;

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_FRN(&frn) ;
        Free_DATEARRAY(holi.holidays) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_PLANARRAY(dfa.disc, 1) ;
        Free_PLANARRAY(cmadj.volCM.vol, 1) ;
        Free_PLANARRAY(cmadj.volLIBOR.vol, 1) ;
        Free_CFLWARRAY(cflw, 1) ;
        Free_CFLWARRAY(cflwx, 1) ;
    }

    else if (!strcmp("FRN_Accruint()", txa))
    {
        fprintf(out,"?; testing %s\n", txa) ;
        aiexp  = Read_AIRESULT(in) ;
        analys = Read_DATESTR(in, out, "   Analys       ") ;
        frn    = Read_FRN(in, out) ;
        holi   = Read_HOLI_STR(in, out) ;

        aires  = FRN_Accruint(&analys, &frn, &holi, NEXTINDEX) ;    /*  FPL-PMSTA00211-100826 add NEXTINDEX */

        diff = 0 ;

        if (fabs(aires.AI - aiexp.AI) > 0.00001 || 
            aiexp.AIdays != aires.AIdays)
            diff = 1 ;
        if (fabs(aires.AI_per_day - aiexp.AI_per_day) > 0.00001)
            diff = 1 ;
        if (aires.exc != aiexp.exc)
            diff = 1 ;
        if (Cldr_Datestr2YMD(&aires.next) != Cldr_Datestr2YMD(&aiexp.next) )
            diff = 1 ;

        fprintf(out, "%d; exp %lf res %lf\n",
                fabs(aires.AI - aiexp.AI) > 0.00001, aiexp.AI, aires.AI) ;
        fprintf(out, "%d; exp %d res %d\n",
                aires.AIdays != aiexp.AIdays, aiexp.AIdays, aires.AIdays) ;
        fprintf(out, "%d; exp %lf res %lf\n",
                fabs(aires.AI_per_day - aiexp.AI_per_day) > 0.00001,
                aiexp.AI_per_day, aires.AI_per_day) ;
        fprintf(out, "%d; exp %d res %d\n",
                aires.exc != aiexp.exc, aiexp.exc, aires.exc) ;
        fprintf(out, "%d; exp %d res %d\n",
                Cldr_Datestr2YMD(&aires.next) != 
                Cldr_Datestr2YMD(&aiexp.next),
                Cldr_Datestr2YMD(&aiexp.next), 
                Cldr_Datestr2YMD(&aires.next) ) ;

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_FRN(&frn);
        Free_DATEARRAY(holi.holidays) ;
    }

    else if (!strcmp("FRN_DF2Delta()", txa))
    {
        fprintf(out,"?; testing %s\n", txa) ;
        analys = Read_DATESTR(in, out, "   Analys       ") ;
        frn    = Read_FRN(in, out) ;
        df     = Read_DISCFAC(in, out) ;
        dfa    = Read_DISCFAC(in, out) ;
        fprintf(out,"   index vol\n") ;
        CMTvol = Read_VOL_STR(in, out) ;
        cmadj  = Set_CMCONVADJ(CMADJ_ORIG, &CMTvol, NULL, 0.0) ;
        holi   = Read_HOLI_STR(in, out) ;
        dfs    = Read_DFSPREAD(in, out) ;
        bucket = Read_BUCKETARRAY(in, out, &nbucket) ;

        fscanf(in, "%s", txb) ;
        zero = Str2BOOLE(txb) ;
        fprintf(out,"   DECF        %8s\n", txb) ;

        ds  = Disc_DeltaPrep(&df, bucket, nbucket, &holi, False, df.irr,
                              df.freq, False, zero, DF_BOTH) ;

        dv = FRN_DF2Delta(&analys, &frn, &df, &dfa, &cmadj, &holi, &dfs, &ds) ;

        diff = 0 ;
        for (i = 0; i < nbucket; i++)
        {
            fscanf(in, "%lf", &fexp1) ;
            diff = diff || fabs(fexp1 - dv[i]) > 0.00001 ;
            fprintf(out, "%d; %d exp %lf res %lf\n",
                    fabs(fexp1 - dv[i]) > 0.00001, i, fexp1, dv[i]) ;
        }
        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_FRN(&frn);
        Free_DATEARRAY(holi.holidays) ;
        Free_DELTASET(&ds) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_PLANARRAY(dfa.disc, 1) ;
        Free_BUCKETARRAY(bucket) ;
        Free_FL64ARRAY(dv) ;
        Free_PLANARRAY(CMTvol.vol, 1) ;
        Free_DFSPREAD(&dfs) ;
    }

    else if (!strcmp("FRN_DF2Price()", txa))
    {
        fprintf(out,"?; testing %s\n", txa) ;
        fscanf(in, "%s %lf %lf %lf", txpl, &fexp1, &fexp2, &fexp3) ;

        analys = Read_DATESTR(in, out, "   Analys       ") ;
        frn    = Read_FRN(in, out) ;
        df     = Read_DISCFAC(in, out) ;
        dfa    = Read_DISCFAC(in, out) ;
        cmadj  = Read_CMCONVADJ(in, out) ;
        holi   = Read_HOLI_STR(in, out) ;
        dfs    = Read_DFSPREAD(in, out) ;
        rs     = Set_RISKSET(KEY_DF, SECOND_ORDER, -1.0,
                             COMPOUND, ANNUALLY, NULL, True) ;

        fres1 = FRN_DF2Price(&analys, &frn, &df, &dfa, &cmadj, &holi, 
                             &dfs, &rs, &fres2, &fres3) ;
        diff = Write_RiskDiff(True, True, fres1, fres2, fres3,
                              fexp1, fexp2, fexp3, acc, out) ;

        Free_FRN(&frn) ;
        Free_DATEARRAY(holi.holidays) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_PLANARRAY(dfa.disc, 1) ;
        Free_PLANARRAY(cmadj.volCM.vol, 1) ;
        Free_PLANARRAY(cmadj.volLIBOR.vol, 1) ;
        Free_DFSPREAD(&dfs) ;
    }

    else if (!strcmp("FRN_SM2SmplMrgn()", txa))
    {
        fprintf(out,"?; testing %s\n", txa) ;
        fexp1  = Read_FL64(in, out, "   Expected SM  ") ;
        analys = Read_DATESTR(in, out, "   Analys       ") ;
        price  = Read_FL64(in, out, "   Price        ") ;
        frn    = Read_FRN(in, out) ;
        Lnext  = Read_FL64(in, out, "   LIBOR        ") ;
        holi   = Read_HOLI_STR(in, out) ;

        fres1 = FRN_SM2SmplMrgn(&analys, price, &frn, Lnext, &holi, &ok) ;
        diff  = Write_SingleDiff(True, True, fres1, fexp1, acc, out) ;

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_FRN(&frn);
        Free_DATEARRAY(holi.holidays) ;
    }

    else if (!strcmp("FRN_SM2Price()", txa))
    {
        fprintf(out,"?; testing %s\n", txa) ;
        fexp1  = Read_FL64(in, out, "   Expected P   ") ;
        analys = Read_DATESTR(in, out, "   Analys       ") ;
        sm     = Read_FL64(in, out, "   SM           ") ;
        frn    = Read_FRN(in, out) ;
        Lnext  = Read_FL64(in, out, "   LIBOR        ") ;
        holi   = Read_HOLI_STR(in, out) ;

        fres1 = FRN_SM2Price(&analys, sm, &frn, Lnext, &holi, &ok) ;
        diff  = Write_SingleDiff(True, True, fres1, fexp1, acc, out) ;

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_FRN(&frn);
        Free_DATEARRAY(holi.holidays) ;
    }

    return diff ;
}

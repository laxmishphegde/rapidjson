/* SCID @(#)mm.c	1.3 (SimCorp) 99/02/19 14:13:38 */

/************************************************************************
*
*   project     SCecon
*
*   file name   mm.c
*
*   general     This file contains routines for moneymarket calcs.
*
************************************************************************/

/* includes ************************************************************/

#include <mm.h>


#define MIN_TICK 0.0001

/*
*************************************************************************
*
*               MM_AnnForw2Qot()
*
*    interface  #include <mm.h>
*               FL64 MM_AnnForw2Qot(FL64      disc,
*                                   DATESTR   *start,
*                                   DATESTR   *matur,
*                                   CALCONV   cal,
*                                   QOTCONV   qot,
*                                   FL64      price) ;
*
*    general    MM_AnnForw2Qot() transforms a price quoted as annual
*               forward rate to the qoute specified in qot.
*
*               The function is relevant when pricing FRA's, IRF's,
*               IRG's and cap/floor's.
*
*               All dates must be adjusted for non-business days before
*               calling this routine.
*
*    input      FL64      disc         Discount factor from matur to
*                                      analysis date (eg. 'today').
*
*               DATESTR   *start       Pointer to the start date
*                                      (eg. FRA, IRF start date)
*
*               DATESTR   *matur       Pointer to maturity   date.
*                                      (eg. FRA, IRF maturity date)
*
*               CALCONV   cal          The calendar convention.
*
*               QOTCONV   qot          Quoting convention
*
*               FL64      price        Price to be transformed
*
*	       	    HOLI_STR  *hol	       Container for list of holidays.
*
*    output
*
*    returns    The net present value as FL64.
*
*    diagnostics
*
*    see also   Disc_Interpolation()
*
*************************************************************************
*/


FL64 MM_AnnForw2Qot(FL64   disc,
                      DATESTR*   start,
                      DATESTR*   matur,
                      CALCONV   cal,
                      QOTCONV   qot,
                      FL64      price,
					  HOLI_STR* holi)
{
    FL64 tfra ;

	tfra = Cldr_TermBetweenDates(start, matur, 0, cal, LAST, holi);   	/* PMSTA-22396 - SRIDHARA � 160502 */

    if (qot == Q_FLAT || qot == Q_PERANNUM)
        price *= disc ;
    if (qot == Q_FLAT || qot == Q_FLATFORW)
        price *= tfra ;

    return price ;
}


/*
*************************************************************************
*
*               MM_Ticksize_Adjust()
*
*    interface  #include <mm.h>
*               FL64 MM_Ticksize_Adjust(FL64 rate,
*                                       FL64 ticksize) ;
*
*    general    The routine adjusts for ticksize.
*
*    input      FL64      rate         The quote to be adjusted
*
*               FL64      ticksize     The accuracy of the resulting
*                                      rate. For instance, 7.8656 will
*                                      be rounded to 7.87 if a ticksize
*                                      of 0.01 is specified.
*                                      Use 0 to for maximum accuracy.
*
*    output
*
*    returns    The adjusted quote
*
*    diagnostics
*
*    see also
*
*************************************************************************
*/


FL64 MM_Ticksize_Adjust(FL64 rate,
                        FL64 ticksize)
{
    FL64 ratemod ;

    ratemod = rate ;

    if (fabs(ticksize) > MIN_TICK)
    {
        ratemod = fmod(rate, ticksize) ;
        ratemod = rate - ratemod + ticksize * ((ratemod / ticksize) >= 0.5) ;
    }

    return ratemod ;
}


#undef MIN_TICK

/* SCID @(#)futrp.c	1.6 (SimCorp) 99/09/29 12:10:52  */

/************************************************************************
*
*       Project         SCecon
*
*       file name       riskpos.c
*
*       contains        risk position calculations
*
************************************************************************/

/*** includes **********************************************************/
#include <futrp.h>


/*** defines  **********************************************************/
#define DISC_TOLR  (FL64)    0.00000001
#define DIV_TOL    (FL64)    0.00000001



/*,,SOH,,
*************************************************************************
*
*               FRA_DF2RiskPos()
*
*   interface   #include <futrp.h>
*               RISKPOSLIST FRA_DF2RiskPos(DATESTR   *analys,
*                                          FRA_STR   *fra,
*                                          FL64      Notnal,
*                                          DISCFAC   *df,
*                                          HOLI_STR  *holi,
*                                          DELTASET  *ds,
*                                          FXRISKSET *FXr) ;
*
*   general     The routine calculates the Risk Position for an FRA
*               using a list of predefined shocks to the zero curve.
*
*               The Risk Position is the core input for VAR calculation.*
*               The Risk Position calculated for this position must be
*               added to the total Risk Position. Once this total Risk
*               Position is available VAR can be calculated with the
*               routine VAR_MATRIX2VAR().
*
*               The decision whether to use price or yield vol is
*               signalled in ds->zero. Note that this must be the same
*               for all risk factors encountered in the total VAR
*               calculation.
*
*               The risk factors affecting a fixed cashflow are:
*
*                   Interest Rates (Government, Swap or Money Market)
*                   FX (if Instrument CCY differs from Home CCY)
*
*               These entries are found in the returned RISKPOSLIST
*
*   input       DATESTR   *analys       The analysis date.
*
*               FRA_STR   *fra          The FRA definition.
*                                       fra->fra assumed as True.
*
*
*               FL64      Notnal        The notional holding (position)
*                                       Amount in Instrument CCY
*
*               DISCFAC   *df           Discounting structure setup.
*                                       The initial (unshocked) curve
*                                       should be in df->disc.
*
*               HOLI_STR  *holi         Business adjustment setup
*
*               DELTASET  *ds           Delta vector defining data
*                                       Set with Disc_DeltaPrep()
*
*               FXRISKSET *FXr          Data for FX risk generation
*
*   output
*
*   returns     The Risk Position allocated as:
*
*                         Alloc_RISKTOKENARRAY(ds->nshock + 1) ;
*                         Alloc_FL64ARRAY(ds->nshock + 1) ;
*
*   diagnostics
*
*   see also    Disc_DeltaPrep()
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/


RISKPOSLIST FRA_DF2RiskPos(DATESTR* analys,
                           FRA_STR*   fra,
                           FL64      Notnal,
                           DISCFAC*   df,
                           HOLI_STR*  holi,
                           DELTASET*  ds,
                           FXRISKSET* FXr) 
{
    RISKPOSLIST  rpos ;
    FL64ARRAY    dv ;
    FL64         FX, pv, dum, fac, pct ;
    INTI         allocsize, i ;

    /* warning avoidance */
    pct = 0.0 ;

    /* Initialise */
    FX = (!SCecon_strncmp(FXr->token.ccy, FXr->home, CCY_LENGTH) ? 
            1.0 : FXr->rate) ;

    /* Allocate output */
    allocsize  = rpos.npos = ds->nshock + 1 ;
    rpos.token = Alloc_RISKTOKENARRAY(allocsize) ;
    rpos.pos   = Alloc_FL64ARRAY(allocsize) ;

    /* Generate delta vector */
    dv = FRA_DF2Delta(analys, fra, df, holi, ds) ;
    
    /* Translate to Risk Position */
    for (i = 0; i < ds->nshock; i++)
    {
        /* dv wrt zeros has already been pct adjusted */
        pct = 100.0 ;

        /* Find adjustment factor */
		fac = Disc_DF2RiskPosFac(analys, df, ds, i, holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */

        /* Do the calculation */
        rpos.pos[i]   = dv[i] * fac * FX * Notnal / pct ;
        VAR_RiskTokenCpy(&rpos.token[i], &ds->token[i]) ;
    }

    /* FX risk contribution - if required */
    VAR_RiskTokenCpy(&rpos.token[ds->nshock], &FXr->token) ;

    if (!SCecon_strncmp(FXr->token.ccy, FXr->home, CCY_LENGTH) == False)
    {
        /* PV in pct in Home CCY */
        pv = FRA_DF2NPV(analys, fra, df, holi, NULL, &dum, &dum) ;

        /* Remember FX contribution - PV in Home CCY */
        rpos.pos[ds->nshock] = pv * Notnal * FX / pct ;
    }
    else
        rpos.pos[ds->nshock] = 0.0 ;

    /* Clean up */
    Free_FL64ARRAY(dv) ;

    return rpos ;
}


/*,,SOH,,
*************************************************************************
*
*               FutBond_DF2RiskPos()
*
*   interface   #include <futrp.h>
*               RISKPOSLIST FutBond_DF2RiskPos(DATESTR      *analys,
*                                           FUTBOND         *futb,
*                                           INTI            noas,
*                                           DFSPREADARRAY   dfsarr,
*                                           FL64            fwd,
*                                           FL64            Notnal,
*                                           DISCFAC         *df,
*                                           HOLI_STR        *holi,
*                                           DELTASET        *ds,
*                                           FXRISKSET       *FXr) ;
*
*   general     The routine calculates the Risk Position for an CTD
*               future bond using a list of predefined shocks to the
*               zero curve.
*
*               Note that the routine can be called with a list of bonds*
*               or a single bond (the CTD bond). If called with a list
*               the CTD is found using the current zero curve. This CTD
*               is then used for delta vector calculation.
*
*               The performance of this routine depends strongly on the
*               number of deliverable bonds and on the number of
*               delivery dates.
*               Calculation time can therefore be reduced considerable
*               if the deliverable bond and the delivery date is
*               well-known. In this case you should only pass one bond
*               and one delivery date as arguments to the routine.
*
*               The Risk Position is the core input for VAR calculation.*
*               The Risk Position calculated for this position must be
*               added to the total Risk Position. Once this total Risk
*               Position is available VAR can be calculated with the
*               routine VAR_MATRIX2VAR().
*
*               The decision whether to use price or yield vol is
*               signalled in ds->zero. Note that this must be the same
*               for all risk factors encountered in the total VAR
*               calculation.
*
*               The risk factors affecting a fixed cashflow are:
*
*                   Interest Rates (Government, Swap or Money Market)
*                   FX (if Instrument CCY differs from Home CCY)
*
*               These entries are found in the returned RISKPOSLIST
*
*   input       DATESTR   *analys       The analysis date.
*
*               FUTBOND   *futb         Futures contract spec.
*
*               INTI      noas          Number of spreads
*
*               DFSPREADARRAY dfsarr    Spreads.
*                                       Dimension [noas]
*
*               FL64      fwd           The forward bond price.
*
*               FL64      Notnal        The notional holding (position)
*                                       Amount in Instrument CCY
*
*               DISCFAC   *df           Discounting structure setup.
*                                       The initial (unshocked) curve
*                                       should be in df->disc.
*
*               HOLI_STR  *holi         Business adjustment setup
*
*               DELTASET  *ds           Delta vector defining data
*                                       Set with Disc_DeltaPrep()
*
*               FXRISKSET *FXr          Data for FX risk generation
*
*   output
*
*   returns     The Risk Position allocated as:
*
*                         Alloc_RISKTOKENARRAY(ds->nshock + 1) ;
*                         Alloc_FL64ARRAY(ds->nshock + 1) ;
*
*   diagnostics
*
*   see also    Disc_DeltaPrep()
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/

/*,,SIC,,
..Kald kun med CTD bond
,,EIC,,*/


RISKPOSLIST FutBond_DF2RiskPos(DATESTR* analys,
                               FUTBOND*   futb,
                               INTI      noas,
                               DFSPREADARRAY dfsarr,
                               FL64      fwd,
                               FL64      Notnal,
                               DISCFAC*   df,
                               HOLI_STR*  holi,
                               DELTASET*  ds,
                               FXRISKSET* FXr) 
{
    RISKPOSLIST  rpos ;
    FL64ARRAY    dv ;
    FL64         FX, pv, fac, pct ;
    INTI         allocsize, i, ctd ;
    DATESTR      delv ;

    /* warning avoidance */
    pct = 0.0 ;

    /* Initialise */
    FX = (!SCecon_strncmp(FXr->token.ccy, FXr->home, CCY_LENGTH) ? 
            1.0 : FXr->rate) ;

    /* Allocate output */
    allocsize  = rpos.npos = ds->nshock + 1 ;
    rpos.token = Alloc_RISKTOKENARRAY(allocsize) ;
    rpos.pos   = Alloc_FL64ARRAY(allocsize) ;

    /* Generate delta vector */
    dv = FutBond_DF2Delta(analys, futb, noas, dfsarr, df, holi, ds, 
      &ctd, &delv) ;

    /* Translate to Risk Position */
    for (i = 0; i < ds->nshock; i++)
    {
        /* dv wrt zeros has already been pct adjusted */
        pct = 100.0 ;

        /* Find adjustment factor */
		fac = Disc_DF2RiskPosFac(analys, df, ds, i, holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */

        /* Do the calculation */
        rpos.pos[i]   = dv[i] * fac * FX * Notnal / pct ;
        VAR_RiskTokenCpy(&rpos.token[i], &ds->token[i]) ;
    }

    /* FX risk contribution - if required */
    VAR_RiskTokenCpy(&rpos.token[ds->nshock], &FXr->token) ;

    if (!SCecon_strncmp(FXr->token.ccy, FXr->home, CCY_LENGTH) == False)
    {
        /* PV in pct in Home CCY */
		pv = FutBond_PL2NPV(analys, &delv, fwd, futb->futp, futb->margin, df, holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */
        /* Remember FX contribution - PV in Home CCY */
        rpos.pos[ds->nshock] = pv * Notnal * FX / pct ;
    }
    else
        rpos.pos[ds->nshock] = 0.0 ;

    /* Clean up */
    Free_FL64ARRAY(dv) ;

    return rpos ;
}


/*,,SOH,,
*************************************************************************
*
*               IRF_DF2RiskPos()
*
*   interface   #include <futrp.h>
*               RISKPOSLIST IRF_DF2RiskPos(DATESTR   *analys,
*                                          FRA_STR   *irf,
*                                          FL64      Notnal,
*                                          DISCFAC   *df,
*                                          HOLI_STR  *holi,
*                                          DELTASET  *ds,
*                                          FXRISKSET *FXr) ;
*
*   general     The routine calculates the Risk Position for an IRF
*               using a list of predefined shocks to the zero curve.
*
*               The Risk Position is the core input for VAR calculation.*
*               The Risk Position calculated for this position must be
*               added to the total Risk Position. Once this total Risk
*               Position is available VAR can be calculated with the
*               routine VAR_MATRIX2VAR().
*
*               The decision whether to use price or yield vol is
*               signalled in ds->zero. Note that this must be the same
*               for all risk factors encountered in the total VAR
*               calculation.
*
*               The risk factors affecting a fixed cashflow are:
*
*                   Interest Rates (Government, Swap or Money Market)
*                   FX (if Instrument CCY differs from Home CCY)
*
*               These entries are found in the returned RISKPOSLIST
*
*   input       DATESTR   *analys       The analysis date.
*
*               FRA_STR   *irf          The IRF definition.
*                                       fra->fra assumed as True.
*
*
*               FL64      Notnal        The notional holding (position)
*                                       Amount in Instrument CCY
*
*               DISCFAC   *df           Discounting structure setup.
*                                       The initial (unshocked) curve
*                                       should be in df->disc.
*
*               HOLI_STR  *holi         Business adjustment setup
*
*               DELTASET  *ds           Delta vector defining data
*                                       Set with Disc_DeltaPrep()
*
*               FXRISKSET *FXr          Data for FX risk generation
*
*   output
*
*   returns     The Risk Position allocated as:
*
*                         Alloc_RISKTOKENARRAY(ds->nshock + 1) ;
*                         Alloc_FL64ARRAY(ds->nshock + 1) ;
*
*   diagnostics
*
*   see also    Disc_DeltaPrep()
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/


RISKPOSLIST IRF_DF2RiskPos(DATESTR* analys,
                           FRA_STR*   irf,
                           FL64      Notnal,
                           DISCFAC*   df,
                           HOLI_STR*  holi,
                           DELTASET*  ds,
                           FXRISKSET* FXr) 
{
    RISKPOSLIST  rpos ;
    FL64ARRAY    dv ;
    FL64         FX, pv, dum, fac, pct ;
    INTI         allocsize, i ;

    /* warning avoidance */
    pct = 0.0 ;

    /* Initialise */
    FX = (!SCecon_strncmp(FXr->token.ccy, FXr->home, CCY_LENGTH) ? 
            1.0 : FXr->rate) ;

    /* Allocate output */
    allocsize  = rpos.npos = ds->nshock + 1 ;
    rpos.token = Alloc_RISKTOKENARRAY(allocsize) ;
    rpos.pos   = Alloc_FL64ARRAY(allocsize) ;

    /* Generate delta vector */
    dv = IRF_DF2Delta(analys, irf, df, holi, ds) ;
    
    /* Translate to Risk Position */
    for (i = 0; i < ds->nshock; i++)
    {
        /* dv wrt zeros has already been pct adjusted */
        pct = 100.0 ;

        /* Find adjustment factor */
		fac = Disc_DF2RiskPosFac(analys, df, ds, i, holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */

        /* Do the calculation */
        rpos.pos[i]   = dv[i] * fac * FX * Notnal / pct ;
        VAR_RiskTokenCpy(&rpos.token[i], &ds->token[i]) ;
    }

    /* FX risk contribution - if required */
    VAR_RiskTokenCpy(&rpos.token[ds->nshock], &FXr->token) ;

    if (!SCecon_strncmp(FXr->token.ccy, FXr->home, CCY_LENGTH) == False)
    {
        /* PV in pct in Home CCY */
        pv = IRF_DF2NPV(analys, irf, df, holi, NULL, &dum, &dum) ;

        /* Remember FX contribution - PV in Home CCY */
        rpos.pos[ds->nshock] = pv * Notnal * FX / pct ;
    }
    else
        rpos.pos[ds->nshock] = 0.0 ;

    /* Clean up */
    Free_FL64ARRAY(dv) ;

    return rpos ;
}



/*,,SOH,,
*************************************************************************
*
*               SwapFix_DF2RiskPos()
*
*   interface   #include <futrp.h>
*               RISKPOSLIST  SwapFix_DF2RiskPos(DATESTR   *analys,
*                                               SWAPFIX   *sfix,
*                                               FL64      Notnal,
*                                               DISCFAC   *df,
*                                               HOLI_STR  *holi,
*                                               DELTASET  *ds,
*                                               FXRISKSET *FXr) ;
*
*   general     The routine calculates the Risk Position for a swap fix
*               leg using a list of predefined shocks to the zero curve.*
*
*               The Risk Position is the core input for VAR calculation.*
*               The Risk Position calculated for this position must be
*               added to the total Risk Position. Once this total Risk
*               Position is available VAR can be calculated with the
*               routine VAR_MATRIX2VAR().
*
*               The decision whether to use price or yield vol is
*               signalled in ds->zero. Note that this must be the same
*               for all risk factors encountered in the total VAR
*               calculation.
*
*               The risk factors affecting a fixed cashflow are:
*
*                   Interest Rates (Government, Swap or Money Market)
*                   FX (if Instrument CCY differs from Home CCY)
*
*               These entries are found in the returned RISKPOSLIST
*
*   input       DATESTR   *analys       The analysis date
*
*               SWAPFIX   *sfix         Fixed leg definition
*
*               FL64      Notnal        The notional holding (position)
*                                       Amount in Instrument CCY
*
*               DISCFAC   *df           Discounting structure setup.
*                                       The initial (unshocked) curve
*                                       should be in df->disc.
*
*               HOLI_STR  *holi         Business adjustment setup
*
*               DELTASET  *ds           Delta vector defining data
*                                       Set with Disc_DeltaPrep()
*
*               FXRISKSET *FXr          Data for FX risk generation
*
*   output
*
*   returns     The Risk Position allocated as:
*
*                         Alloc_RISKTOKENARRAY(ds->nshock + 1) ;
*                         Alloc_FL64ARRAY(ds->nshock + 1) ;
*
*   diagnostics
*
*   see also    Disc_DeltaPrep()
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/


RISKPOSLIST SwapFix_DF2RiskPos(DATESTR*    analys,
                               SWAPFIX*       sfix,
                               FL64          Notnal,
                               DISCFAC*       df,
                               HOLI_STR*      holi,
                               DELTASET*      ds,
                               FXRISKSET*     FXr)
{
    CFLWARRAY   cflw ;
    RISKPOSLIST rpos ;
    HOLI_STR    hol ;

    /* Initialise */
    hol = Set_HOLI_STR(NO_BUSADJUST, 0, NULL) ;

    /* Extract cflw */
    cflw = SwapFix_GenrCflw(sfix, holi) ;

    /* Calculate Risk Positions */
    rpos = Cflw_DF2RiskPos(analys, cflw, NULL, Notnal, df, NULL, 
                           &hol, ds, FXr) ;

    /* Free cflw */
    Free_CFLWARRAY(cflw, 1) ;

    return rpos ;
}


/*,,SOH,,
*************************************************************************
*
*               RepoBond_DF2RiskPos()
*
*   interface   #include <futrp.h>
*               RISKPOSLIST RepoBond_DF2RiskPos(DATESTR   *analys,
*                                               REPOBOND  *repo,
*                                               FL64      Notnal,
*                                               DISCFAC   *df,
*                                               DFSPREAD  *dfs,
*                                               HOLI_STR  *holi,
*                                               DELTASET  *ds,
*                                               FXRISKSET *FXr) ;
*
*   general     The routine calculates the Risk Position for
*               an arbitrary repo bond using a list of predefined
*               shocks to the zero curve.
*
*               The Risk Position is the core input for VAR calculation.*
*               The Risk Position calculated for this position must be
*               added to the total Risk Position. Once this total Risk
*               Position is available VAR can be calculated with the
*               routine VAR_MATRIX2VAR().
*
*               The decision whether to use price or yield vol is
*               signalled in ds->zero. Note that this must be the same
*               for all risk factors encountered in the total VAR
*               calculation.
*
*               The risk factors affecting a fixed cashflow are:
*
*                   Interest Rates (Government, Swap or Money Market)
*                   FX (if Instrument CCY differs from Home CCY)
*
*               These entries are found in the returned RISKPOSLIST
*
*   input       DATESTR   *analys       The analysis date.
*
*               REPOBOND  *repo         Repo contract spec.
*
*               FL64      Notnal        The notional holding (position)
*                                       Amount in Instrument CCY
*
*               DISCFAC   *df           Discounting structure setup.
*                                       The initial (unshocked) curve
*                                       should be in df->disc.
*
*               DFSPREAD  *dfs          Spread against the curve.
*
*               HOLI_STR  *holi         Business adjustment setup
*
*               DELTASET  *ds           Delta vector defining data
*                                       Set with Disc_DeltaPrep()
*
*               FXRISKSET *FXr          Data for FX risk generation
*
*   output
*
*   returns     The Risk Position allocated as:
*
*                         Alloc_RISKTOKENARRAY(ds->nshock + 1) ;
*                         Alloc_FL64ARRAY(ds->nshock + 1) ;
*
*   diagnostics
*
*   see also    Disc_DeltaPrep()
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/


RISKPOSLIST RepoBond_DF2RiskPos(DATESTR* analys,
                                REPOBOND*  repo,
                                FL64      Notnal,
                                DISCFAC*   df,
                                DFSPREAD*  dfs,
                                HOLI_STR*  holi,
                                DELTASET*  ds,
                                FXRISKSET* FXr) 
{
    RISKPOSLIST  rpos ;
    CFLWARRAY    xcflw ;
    DATESTR      sell, buy ;

    /* Adjust for business days */
    sell = repo->sell_date ;
    Cldr_Move2BusinessDays(&repo->sell_date, 1, holi) ;
    buy  = repo->buy_date ;
    Cldr_Move2BusinessDays(&repo->buy_date, 1, holi) ;

    /* Extract the specific period flow */
    xcflw = RepoBond_GenrCflw(repo, holi) ;

    rpos = RepoCflw_DF2RiskPos(analys, xcflw, &repo->buy_date, 
                               &repo->bond.repay.pp, Notnal, 
                               df, dfs, holi, ds, FXr) ;

    /* Clean up */
    repo->sell_date = sell ;
    repo->buy_date  = buy ;
    
    /* Free cflw */
    Free_CFLWARRAY(xcflw, 1) ;

    return rpos ;
}


/*,,SOH,,
*************************************************************************
*
*               SwapFl_DF2RiskPos()
*
*   interface   #include <futrp.h>
*               RISKPOSLIST SwapFl_DF2RiskPos(DATESTR   *analys,
*                                             SWAPFLOAT *sfl,
*                                             FL64      Notnal,
*                                             DISCFAC   *df_cflw,
*                                             DISCFAC   *df_disc,
*                                             CMCONVADJ *cmadj,
*                                             HOLI_STR  *holi,
*                                             DELTASET  *ds_cflw,
*                                             DELTASET  *ds_disc,
*                                             FXRISKSET *FXr) ;
*
*   general     The routine calculates the Risk Position for a swap
*               float leg using a list of predefined shocks to the
*               zero curve.
*
*               The Risk Position is the core input for VAR calculation.*
*               The Risk Position calculated for this position must be
*               added to the total Risk Position. Once this total Risk
*               Position is available VAR can be calculated with the
*               routine VAR_MATRIX2VAR().
*
*               The decision whether to use price or yield vol is
*               signalled in ds_cflw->zero and ds_disc->zero.
*               Note that this must be the same for all risk factors
*               encountered in the total VAR calculation.
*
*               The risk factors affecting a fixed cashflow are:
*
*                   Interest Rates (Government, Swap or Money Market)
*                   FX (if Instrument CCY differs from Home CCY)
*
*               These entries are found in the returned RISKPOSLIST
*
*   input       DATESTR     *analys     The analysis date
*
*               SWAPFLOAT   *sfl        Floating leg definition.
*
*               FL64        Notnal      The notional holding (position)
*                                       Amount in Instrument CCY
*
*               DISCFAC     *df_cflw    Discounting structure setup.
*                                       Used to generate payments
*
*               DISCFAC     *df_disc    Discounting structure setup.
*                                       Used for discounting
*
*               CMCONVADJ  *cmadj       Data for Convexity Adjustment
*                                       Use NULL if no adjustment
*
*               HOLI_STR    *holi       Container for data on business
*                                       day convention and non-week-end
*                                       holidays.
*
*               DELTASET    *ds_cflw    Data for delta calculation
*                                       ds->dfwhich should be DF_CFLW or*
*                                       DF_BOTH.
*                                       Use DF_BOTH whenever the 2 DF's
*                                       are equal.
*
*               DELTASET    *ds_disc    Data for delta calculation
*                                       Not used if ds_cflw->dfwhich is
*                                       DF_BOTH.
*                                       ds->dfwhich should be DF_DISC.
*
*               FXRISKSET   *FXr        Data for FX risk generation
*
*   output
*
*   returns     The Risk Position allocated as:
*
*                   Alloc_RISKTOKENARRAY(ds_cflw->nshock +
*                                           ds_disc->nshock + 1) ;
*                   Alloc_FL64ARRAY(ds_cflw->nshock +
*                                           ds_disc->nshock + 1) ;
*
*   diagnostics
*
*   see also    Disc_DeltaPrep()
*
*************************************************************************
,,EOH,,*/

RISKPOSLIST SwapFl_DF2RiskPos(DATESTR*   analys,
                              SWAPFLOAT*     sfl,
                              FL64          Notnal,
                              DISCFAC*       df_cflw,
                              DISCFAC*       df_disc,
                              CMCONVADJ*     cmadj,
                              HOLI_STR*      holi,
                              DELTASET*      ds_cflw,
                              DELTASET*      ds_disc,
                              FXRISKSET*     FXr)
{
    RISKPOSLIST  rpos, rpostmp, rposlist ;
    FL64ARRAY    dv_cflw, dv_disc ;
    FL64         FX, pv, dum, fac, pct ;
    INTI         allocsize, i, nshock ;

    /* warning avoidance */
    pct = 0.0 ;
    dv_disc = NULL;

    /* Initialise */
    FX = (!SCecon_strncmp(FXr->token.ccy, FXr->home, CCY_LENGTH) ? 
            1.0 : FXr->rate) ;

    rpostmp.npos  = 0 ;
    rpostmp.token = NULL ;
    rpostmp.pos   = NULL ;

    nshock     = ds_cflw->nshock + ds_disc->nshock ;
    allocsize  = nshock + 1 ;
    rpos.token = Alloc_RISKTOKENARRAY(allocsize) ;
    rpos.pos   = Alloc_FL64ARRAY(allocsize) ;
    rpos.npos  = 0 ; 
             
    /* Generate delta vector by shocking df_cflw */
    dv_cflw = SwapFl_DF2Delta(analys, sfl, df_cflw, df_disc, 
                              cmadj, holi, ds_cflw) ;

    /* Generate delta vector by shocking df_disc */
    if (ds_cflw->dfwhich != DF_BOTH)
        dv_disc = SwapFl_DF2Delta(analys, sfl, df_cflw, df_disc, 
                                  cmadj, holi, ds_disc) ;

    /* Translate to Risk Position (df_cflw) */
    for (i = 0; i < ds_cflw->nshock; i++)
    {
        /* dv wrt zeros has already been pct adjusted */
        pct = 100.0 ;

        /* Find adjustment factor */
		fac = Disc_DF2RiskPosFac(analys, df_cflw, ds_cflw, i, holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */

        /* Do the calculation */
        rpos.pos[i] = dv_cflw[i] * fac * FX * Notnal / pct ;
        VAR_RiskTokenCpy(&rpos.token[i], &ds_cflw->token[i]) ;
        rpos.npos += 1 ;
    }

    /* Translate to Risk Position (df_disc) */
    for (i = 0; ds_cflw->dfwhich != DF_BOTH && i < ds_disc->nshock ; i++)
    {
        /* dv wrt zeros has already been pct adjusted */
        pct = 100.0 ;

        /* Find adjustment factor */
		fac = Disc_DF2RiskPosFac(analys, df_disc, ds_disc, i, holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */

        /* Do the calculation */
        rpos.pos[i + ds_cflw->nshock] = dv_disc[i] * fac * FX * Notnal / pct ;
        VAR_RiskTokenCpy(&rpos.token[i + ds_cflw->nshock], &ds_disc->token[i]);
        rpos.npos += 1 ;
    }

    /* FX risk contribution - if required */
    VAR_RiskTokenCpy(&rpos.token[rpos.npos], &FXr->token) ;

    if (!SCecon_strncmp(FXr->token.ccy, FXr->home, CCY_LENGTH) == False)
    {
        /* PV in pct in Home CCY */
        pv = SwapFl_DF2NPV(analys, sfl, df_cflw, df_disc, cmadj, holi, NULL,
                           &dum, &dum) ;

        /* Remember FX contribution - PV in Home CCY */
        rpos.pos[rpos.npos] = pv * Notnal * FX / pct ;
    }
    else
        rpos.pos[rpos.npos] = 0.0 ;

    rpos.npos += 1 ;
    rposlist = VAR_MergeRISKPOSLIST(&rpos, &rpostmp) ;

    /* Clean up */
    Free_RISKPOSLIST(&rpos) ;
    Free_RISKPOSLIST(&rpostmp) ;
    Free_FL64ARRAY(dv_cflw) ;
    if (ds_cflw->dfwhich != DF_BOTH)
        Free_FL64ARRAY(dv_disc) ;

    return rposlist ;
}



/*,,SOH,,
*************************************************************************
*
*               FRN_DF2RiskPos()
*
*   interface   #include <futrp.h>
*               RISKPOSLIST FRN_DF2RiskPos(DATESTR      *analys,
*                                             FRN       *frn,
*                                             FL64      Notnal,
*                                             DISCFAC   *df_cflw,
*                                             DISCFAC   *df_disc,
*                                             CMCONVADJ *cmadj,
*                                             HOLI_STR  *holi,
*                                             DFSPREAD  *dfs,
*                                             DELTASET  *ds_cflw,
*                                             DELTASET  *ds_disc,
*                                             FXRISKSET *FXr) ;
*
*   general     The routine calculates the Risk Position for a FRN
*               using a list of predefined shocks to the zero curve.
*
*               The Risk Position is the core input for VAR calculation.*
*               The Risk Position calculated for this position must be
*               added to the total Risk Position. Once this total Risk
*               Position is available VAR can be calculated with the
*               routine VAR_MATRIX2VAR().
*
*               The decision whether to use price or yield vol is
*               signalled in ds_cflw->zero and ds_disc->zero.
*               Note that this must be the same for all risk factors
*               encountered in the total VAR calculation.
*
*               The risk factors affecting a fixed cashflow are:
*
*                   Interest Rates (Government, Swap or Money Market)
*                   FX (if Instrument CCY differs from Home CCY)
*
*               These entries are found in the returned RISKPOSLIST
*
*   input       DATESTR     *analys     The analysis date
*
*               FRN         *frn        The FRN definition
*                                       Use SwapFl_GenrLIBORSaldo() to
*                                       find frn->float1.fbase.coupon1
*
*               FL64        Notnal      The notional holding (position)
*                                       Amount in Instrument CCY
*
*               DISCFAC     *df_cflw    Discounting structure setup.
*                                       Used to generate payments
*
*               DISCFAC     *df_disc    Discounting structure setup.
*                                       Used for discounting
*
*               CMCONVADJ  *cmadj       Data for Convexity Adjustment
*                                       Use NULL if no adjustment
*
*               HOLI_STR    *holi       Container for data on business
*                                       day convention and non-week-end
*                                       holidays.
*
*               DFSPREAD    *dfs        Spread against the discount curve.
*                                       Use NULL if no spread.
*
*               DELTASET    *ds_cflw    Data for delta calculation
*                                       ds->dfwhich should be DF_CFLW or*
*                                       DF_BOTH.
*                                       Use DF_BOTH whenever the 2 DF's
*                                       are equal.
*
*               DELTASET    *ds_disc    Data for delta calculation
*                                       Not used if ds_cflw->dfwhich is
*                                       DF_BOTH.
*                                       ds->dfwhich should be DF_DISC.
*
*               FXRISKSET   *FXr        Data for FX risk generation
*
*   output
*
*   returns     The Risk Position allocated as:
*
*                   Alloc_RISKTOKENARRAY(ds_cflw->nshock +
*                                           ds_disc->nshock + 1) ;
*                   Alloc_FL64ARRAY(ds_cflw->nshock +
*                                           ds_disc->nshock + 1) ;
*
*   diagnostics
*
*   see also    Disc_DeltaPrep()
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/

RISKPOSLIST FRN_DF2RiskPos(DATESTR*     analys,
                               FRN*         frn,
                               FL64         Notnal,
                               DISCFAC*     df_cflw,
                               DISCFAC*     df_disc,
                               CMCONVADJ*   cmadj,
                               HOLI_STR*    holi,
                               DFSPREAD*    dfs,
                               DELTASET*    ds_cflw,
                               DELTASET*    ds_disc,
                               FXRISKSET*   FXr)
{
    RISKPOSLIST  rpos, rpostmp, rposlist ;
    FL64ARRAY    dv_cflw, dv_disc ;
    FL64         FX, pv, dum, fac, pct ;
    INTI         allocsize, i, nshock ;
    DISCFAC      dfs_disc ;

    /* warning avoidance */
    dv_disc = NULL;
    pct = 0.0 ;

    /* Initialise */
    FX = (!SCecon_strncmp(FXr->token.ccy, FXr->home, CCY_LENGTH) ? 
            1.0 : FXr->rate) ;

    rpostmp.npos  = 0 ;
    rpostmp.token = NULL ;
    rpostmp.pos   = NULL ;

    nshock     = ds_cflw->nshock + ds_disc->nshock ;
    allocsize  = nshock + 1 ;
    rpos.token = Alloc_RISKTOKENARRAY(allocsize) ;
    rpos.pos   = Alloc_FL64ARRAY(allocsize) ;
    rpos.npos  = 0 ; 


	dfs_disc = Disc_Spread2DF(df_disc, dfs, holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */
             
    /* Generate delta vector by shocking df_cflw */
    dv_cflw = FRN_DF2Delta(analys, frn, df_cflw, df_disc, cmadj, holi,
                           dfs, ds_cflw);

    /* Generate delta vector by shocking df_disc */
    if (ds_cflw->dfwhich != DF_BOTH)
        dv_disc = FRN_DF2Delta(analys, frn, df_cflw, df_disc, cmadj, holi, 
                               dfs, ds_disc);

    /* Translate to Risk Position (df_cflw) */
    for (i = 0; i < ds_cflw->nshock; i++)
    {
        /* dv wrt zeros has already been pct adjusted */
        pct = 100.0 ;

        /* Find adjustment factor */
		fac = Disc_DF2RiskPosFac(analys, df_cflw, ds_cflw, i, holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */

        /* Do the calculation */
        rpos.pos[i] = dv_cflw[i] * fac * FX * Notnal / pct ;
        VAR_RiskTokenCpy(&rpos.token[i], &ds_cflw->token[i]) ;
        rpos.npos += 1 ;
    }

    /* Translate to Risk Position (df_disc) */
    for (i = 0; ds_cflw->dfwhich != DF_BOTH && i < ds_disc->nshock ; i++)
    {
        /* dv wrt zeros has already been pct adjusted */
        pct = 100.0 ;

        /* Find adjustment factor */
        fac = Disc_DF2RiskPosFac(analys, &dfs_disc, ds_disc, i, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */

        /* Do the calculation */
        rpos.pos[i + ds_cflw->nshock] = dv_disc[i] * fac * FX * Notnal / pct ;
        VAR_RiskTokenCpy(&rpos.token[i + ds_cflw->nshock], &ds_disc->token[i]);
        rpos.npos += 1 ;
    }

    /* FX risk contribution - if required */
    VAR_RiskTokenCpy(&rpos.token[rpos.npos], &FXr->token) ;

    if (!SCecon_strncmp(FXr->token.ccy, FXr->home, CCY_LENGTH) == False)
    {
        /* PV in pct in Home CCY */
        pv = FRN_DF2Price(analys, frn, df_cflw, df_disc, cmadj, holi, dfs,
                          NULL, &dum, &dum) ;

        /* Remember FX contribution - PV in Home CCY */
        rpos.pos[rpos.npos] = pv * Notnal * FX / pct ;
    }
    else
        rpos.pos[rpos.npos] = 0.0 ;

    rpos.npos += 1 ;
    rposlist = VAR_MergeRISKPOSLIST(&rpos, &rpostmp) ;

    /* Clean up */
    Free_RISKPOSLIST(&rpos) ;
    Free_RISKPOSLIST(&rpostmp) ;
    Free_FL64ARRAY(dv_cflw) ;
    Free_PLANARRAY(dfs_disc.disc, 1) ;
    if (ds_cflw->dfwhich != DF_BOTH)
        Free_FL64ARRAY(dv_disc) ;

    return rposlist ;
}


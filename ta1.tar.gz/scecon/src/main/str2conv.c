/* SCID @(#)str2conv.c	1.168 (SimCorp) 99/11/08 12:19:13 */

/*********************************************************************
*                                                                     
*   Project     SCecon                                                
*                                                                     
*   file name   str2conv.c                                            
*                                                                     
*   general     This file contains example code for routines that     
*               converts strings to conventions used by SCecon 
*               routines.
*                                                                     
**********************************************************************
*/

/* includes    *******************************************************/
#include <str2conv.h>


/*
..
*/

void Str_Uppercase(TEXT s)
{
    for (; *s ; s++)
        *s = (CH) toupper(*s) ;
}


/*
..
*/


EOMCONV Str2EOMCONV(TEXT txt)
{
    EOMCONV eom = EOMCONV_INIT ;

    Str_Uppercase(txt) ;

    if      (!strcmp(txt, "S"))       eom = SAME ;
    else if (!strcmp(txt, "SAME"))    eom = SAME ;
    else if (!strcmp(txt, "L"))       eom = LAST ;
    else if (!strcmp(txt, "LAST"))    eom = LAST ;
    else if (!strcmp(txt, "LAST360")) eom = LAST360 ;
    else
        SCecon_error("Unknown end-of-month convention\n", 
          "Str2EOMCONV()", SCECONABORT) ;

    return eom ;
}


/*
..
*/


CALCONV Str2CALCONV(TEXT txt)
{
    CALCONV cal = CALCONV_INIT ;

    Str_Uppercase(txt) ;

    if      (!strcmp(txt, "ACTACT"))   cal = ACTACT ;
    else if (!strcmp(txt, "ACT/ACT"))  cal = ACTACT ;

    else if (!strcmp(txt, "ACTAFB"))   cal = ACTAFB ;
    else if (!strcmp(txt, "ACT/AFB"))  cal = ACTAFB ;

    else if (!strcmp(txt, "ACTEUROBOND"))   cal = ACTEUROBOND ;
    else if (!strcmp(txt, "ACT/EUROBOND"))  cal = ACTEUROBOND ;

    else if (!strcmp(txt, "ACTFRF"))   cal = ACTFRF ;
    else if (!strcmp(txt, "ACT/FRF"))  cal = ACTFRF ;

    else if (!strcmp(txt, "EU30360"))  cal = EU30360 ;
    else if (!strcmp(txt, "30/360"))   cal = EU30360 ;

    else if (!strcmp(txt, "EU30E360")) cal = EU30E360 ;
    else if (!strcmp(txt, "30E/360"))  cal = EU30E360 ;

    else if (!strcmp(txt, "EU30EP360")) cal = EU30EP360 ;
    else if (!strcmp(txt, "30EP/360"))  cal = EU30EP360 ;

    else if (!strcmp(txt, "EU30E365")) cal = EU30E365 ;
    else if (!strcmp(txt, "30E/365"))  cal = EU30E365 ;
    else if (!strcmp(txt, "30/365"))   cal = EU30E365 ;

    else if (!strcmp(txt, "US30360"))  cal = US30360 ;

    else if (!strcmp(txt, "US30E360")) cal = US30E360 ;

    else if (!strcmp(txt, "ACT360"))   cal = ACT360 ;
    else if (!strcmp(txt, "ACT/360"))  cal = ACT360 ;

    else if (!strcmp(txt, "ACT365"))   cal = ACT365 ;
    else if (!strcmp(txt, "ACT/365"))  cal = ACT365 ;

    else if (!strcmp(txt, "ACTNL365")) cal = ACTNL365 ;
    else if (!strcmp(txt, "ACTNL/365")) cal = ACTNL365 ;

    else if (!strcmp(txt, "ACTLEAP"))  cal = ACTLEAP ;
    else if (!strcmp(txt, "ACT/LEAP")) cal = ACTLEAP ;

	else if (!strcmp(txt, "BUS252"))   cal = BUS252;   	/* PMSTA-22396 - SRIDHARA � 160502 */

    else
        SCecon_error("Unknown calendar convention\n", "Str2CALCONV()", 
            SCECONABORT) ;

    return cal ;
}

/*
..
*/


BUSCONV Str2BUSCONV(TEXT txt)
{
    BUSCONV bus = BUSCONV_INIT ;

    Str_Uppercase(txt) ;

    if      (!strcmp(txt, "NEXT"))            bus = NEXT ;
    else if (!strcmp(txt, "FIRST"))           bus = NEXT ;
    else if (!strcmp(txt, "FOLLOWING"))       bus = NEXT ;

    else if (!strcmp(txt, "NEXTINMONTH"))     bus = NEXTINMONTH ;
    else if (!strcmp(txt, "MOD. FOLLOWING"))  bus = NEXTINMONTH ;
    else if (!strcmp(txt, "PREVIOUS"))        bus = PREVIOUS ;
    else if (!strcmp(txt, "PREVIOUSINMONTH")) bus = PREVIOUSINMONTH ;
    else if (!strcmp(txt, "CLOSEST"))         bus = CLOSEST ;
    else if (!strcmp(txt, "CLOSESTINMONTH"))  bus = CLOSESTINMONTH ;
    else if (!strcmp(txt, "NO_BUSADJUST"))    bus = NO_BUSADJUST ;
    else if (!strcmp(txt, "NO ADJUSTMENT"))   bus = NO_BUSADJUST ;
    else if (!strcmp(txt, "NONE"))            bus = NO_BUSADJUST ;
    else if (!strcmp(txt, "NO"))              bus = NO_BUSADJUST ;
    else
        SCecon_error("Unknown business day convention\n", 
            "Str2BUSCONV()", SCECONABORT) ;

    return bus ;
}


/*
..
*/


SEQCONV Str2SEQCONV(TEXT txt)
{
    SEQCONV per = SEQCONV_INIT ;

    Str_Uppercase(txt) ;

    if      (!strcmp(txt, "CHAIN"))        per = CHAIN ;
    else if (!strcmp(txt, "C"))            per = CHAIN ;
    else if (!strcmp(txt, "ANCHOR"))       per = ANCHOR ;
    else if (!strcmp(txt, "A"))            per = ANCHOR ;
    else if (!strcmp(txt, "FORW"))         per = ANCHOR ;
    else if (!strcmp(txt, "FWD"))          per = ANCHOR ;
    else if (!strcmp(txt, "ANCHORBACK"))   per = ANCHORBACK ;
    else if (!strcmp(txt, "AB"))           per = ANCHORBACK ;
    else if (!strcmp(txt, "BACK"))         per = ANCHORBACK ;
    else if (!strcmp(txt, "ANCHORSHIFT"))  per = ANCHORSHIFT ;
    else if (!strcmp(txt, "IMM"))          per = IMM ;
    else if (!strcmp(txt, "CAD_BA"))       per = CAD_BA ;
    else if (!strcmp(txt, "CADBA"))        per = CAD_BA ;
    else if (!strcmp(txt, "LASTBUS"))      per = LASTBUS ;
    else if (!strcmp(txt, "IMM_ZAR"))      per = IMM_ZAR ;
    else if (!strcmp(txt, "IMMZAR"))       per = IMM_ZAR ;
    else if (!strcmp(txt, "ZAR"))          per = IMM_ZAR ;
    else if (!strcmp(txt, "TAM_T4M"))      per = TAM_T4M ;
    else if (!strcmp(txt, "TAM"))          per = TAM_T4M ;
    else if (!strcmp(txt, "T4M"))          per = TAM_T4M ;
    else
        SCecon_error("Unknown roll convention\n", "Str2SEQCONV()", 
                     SCECONABORT) ;

    return per ;
}


/*
..
*/


IRRCONV Str2IRRCONV(TEXT txt)
{
    IRRCONV irr = IRRCONV_INIT ;

    Str_Uppercase(txt) ;

    if      (!strcmp(txt, "COMPOUND"))            irr = COMPOUND ;
    else if (!strcmp(txt, "BOND"))                irr = COMPOUND ;
    else if (!strcmp(txt, "ISMA"))                irr = COMPOUND ;
    else if (!strcmp(txt, "SIA"))                 irr = COMPOUND ;

    else if (!strcmp(txt, "US_TREASURY"))         irr = US_TREASURY ;
    else if (!strcmp(txt, "USTREASURY"))          irr = US_TREASURY ;
    else if (!strcmp(txt, "UST"))                 irr = US_TREASURY ;

    else if (!strcmp(txt, "SIMPLE_MM"))           irr = SIMPLE_MM ;
    else if (!strcmp(txt, "SIMPLE"))              irr = SIMPLE_MM ;
    else if (!strcmp(txt, "MM"))                  irr = SIMPLE_MM ;

    else if (!strcmp(txt, "SIMPLE_REPO"))         irr = SIMPLE_REPO ;
    else if (!strcmp(txt, "REPO"))                irr = SIMPLE_REPO ;

    else if (!strcmp(txt, "CONTINUOUS"))          irr = CONTINUOUS ;
    else if (!strcmp(txt, "ACADEMIC"))            irr = CONTINUOUS ;
    else if (!strcmp(txt, "CONT"))                irr = CONTINUOUS ;

    else if (!strcmp(txt, "DISCOUNT"))            irr = DISCOUNT ;
    else if (!strcmp(txt, "DISC"))                irr = DISCOUNT ;

    else if (!strcmp(txt, "COMPOUNDSIMPLE"))      irr = COMPOUNDSIMPLE ;
    else if (!strcmp(txt, "CS"))                  irr = COMPOUNDSIMPLE ;
    else if (!strcmp(txt, "SIAMM"))               irr = COMPOUNDSIMPLE ;
    else if (!strcmp(txt, "ISMAMM"))              irr = COMPOUNDSIMPLE ;
    else if (!strcmp(txt, "BONDMM"))              irr = COMPOUNDSIMPLE ;

    else if (!strcmp(txt, "COMPOUNDSIMPLE_ODD"))  irr = COMPOUNDSIMPLE_ODD ;
    else if (!strcmp(txt, "CSO"))                 irr = COMPOUNDSIMPLE_ODD ;
    else if (!strcmp(txt, "ISMAMM_ODD"))          irr = COMPOUNDSIMPLE_ODD ;
    else if (!strcmp(txt, "BONDMM_ODD"))          irr = COMPOUNDSIMPLE_ODD ;

    else if (!strcmp(txt, "MOOSMULLER"))          irr = MOOSMULLER ;
    else if (!strcmp(txt, "MOOS"))                irr = MOOSMULLER ;

    else if (!strcmp(txt, "BRAESSFANGMEYER"))     irr = BRAESSFANGMEYER ;
    else if (!strcmp(txt, "BRF"))                 irr = BRAESSFANGMEYER ;

    else if (!strcmp(txt, "MAIR"))                irr = MAIR ;

    else if (!strcmp(txt, "JGBYTM"))              irr = JGBYTM ;
    else if (!strcmp(txt, "JGB"))                 irr = JGBYTM ;
    else
        SCecon_error("Unknown interest rate convention\n", 
          "Str2IRRCONV()", SCECONABORT) ;

    return irr ;
}


/*
..
*/


RISKCONV Str2RISKCONV(TEXT txt)
{
    RISKCONV r = RISKCONV_INIT ;

    Str_Uppercase(txt) ;

    if      (!strcmp(txt, "ZERO_ORDER"))      r = ZERO_ORDER ;
    else if (!strcmp(txt, "ZERO"))            r = ZERO_ORDER ;
    else if (!strcmp(txt, "Z"))               r = ZERO_ORDER ;
    else if (!strcmp(txt, "CLEAN"))           r = ZERO_ORDER ;
    else if (!strcmp(txt, "PRICE"))           r = ZERO_ORDER ;
    else if (!strcmp(txt, "P"))               r = ZERO_ORDER ;

    else if (!strcmp(txt, "FIRST_ORDER"))     r = FIRST_ORDER ;
    else if (!strcmp(txt, "FIRST"))           r = FIRST_ORDER ;
    else if (!strcmp(txt, "F"))               r = FIRST_ORDER ;

    else if (!strcmp(txt, "SECOND_ORDER"))    r = SECOND_ORDER ;
    else if (!strcmp(txt, "SECOND"))          r = SECOND_ORDER ;
    else if (!strcmp(txt, "S"))               r = SECOND_ORDER ;
    else
        SCecon_error("Unknown risk convention\n", "Str2RISKCONV()", 
            SCECONABORT) ;

    return r ;
}


/*
..
*/


SHOCKCONV Str2SHOCKCONV(TEXT txt)
{
    SHOCKCONV r = SHOCKCONV_INIT ;

    Str_Uppercase(txt) ;

    if      (!strcmp(txt, "PARALLEL"))           r = PARALLEL ;
    else if (!strcmp(txt, "MULTIPLICATIVE"))     r = MULTIPLICATIVE ;
    else if (!strcmp(txt, "FACTOR_SHOCK"))       r = FACTOR_SHOCK ;
    else
        SCecon_error("Unknown shock convention\n", "Str2SHOCKCONV()", 
            SCECONABORT) ;

    return r ;
}


/*
..
*/


INTPOLCONV Str2INTPOLCONV(TEXT txt)
{
    INTPOLCONV r = INTPOLCONV_INIT ;

    Str_Uppercase(txt) ;

    if      (!strcmp(txt, "LINEAR_EXTRAPOL"))   r = LINEAR_EXTRAPOL ;
    else if (!strcmp(txt, "LINEAR"))            r = LINEAR_EXTRAPOL ;
    else if (!strcmp(txt, "LIN"))               r = LINEAR_EXTRAPOL ;
    else if (!strcmp(txt, "L"))                 r = LINEAR_EXTRAPOL ;

    else if (!strcmp(txt, "LINEAR_FLAT_END"))   r = LINEAR_FLAT_END ;
    else if (!strcmp(txt, "LINEAR_FLAT"))       r = LINEAR_FLAT_END ;

    else if (!strcmp(txt, "INCL_EXCL"))         r = INCL_EXCL ;
    else if (!strcmp(txt, "EXCL_INCL"))         r = EXCL_INCL ;
    else if (!strcmp(txt, "CUBIC_SPLINE"))      r = CUBIC_SPLINE ;
    else if (!strcmp(txt, "CSPL"))              r = CUBIC_SPLINE ;
    else if (!strcmp(txt, "CUBIC"))             r = CUBIC_SPLINE ;
    else if (!strcmp(txt, "C"))                 r = CUBIC_SPLINE ;
    else
        SCecon_error("Unknown interpolation convention\n", 
          "Str2INTPOLCONV()", SCECONABORT) ;

    return r ;
}


/*
..
*/


SEARCHCONV Str2SEARCHCONV(TEXT txt)
{
    SEARCHCONV r = SEARCHCONV_INIT ;

    Str_Uppercase(txt) ;

    if      (!strcmp(txt, "SEARCH_FORWARDS"))   r = SEARCH_FORWARDS ;
    else if (!strcmp(txt, "SEARCH_BACKWARDS"))  r = SEARCH_BACKWARDS ;
    else if (!strcmp(txt, "SEARCH_BISECTION"))  r = SEARCH_BISECTION ;
    else
        SCecon_error("Unknown search convention\n", "Str2SEARCHCONV()",
          SCECONABORT) ;

    return r ;
}


/*
..
*/


INDEXCONV Str2INDEXCONV(TEXT txt)
{
    INDEXCONV r = INDEXCONV_INIT ;

    Str_Uppercase(txt) ;

    if      (!strcmp(txt, "NEXTINDEX"))      r = NEXTINDEX ;
    else if (!strcmp(txt, "PREVINDEX"))      r = PREVINDEX ;
    else if (!strcmp(txt, "SAMEINDEX"))      r = SAMEINDEX ;
    else
        SCecon_error("Unknown index convention\n", "Str2INDEXCONV()", 
            SCECONABORT) ;

    return r ;
}


/*
..
*/


PMTFREQ Str2PMTFREQ(TEXT txt)
{
    PMTFREQ r = PMTFREQ_INIT ;

    Str_Uppercase(txt) ;

    if      (!strcmp(txt, "TRIANNUALLY"))      r = TRIANNUALLY ;
    else if (!strcmp(txt, "TREAARLIG"))         r = TRIANNUALLY ;
    else if (!strcmp(txt, "TREOERLIG"))         r = TRIANNUALLY ;
    else if (!strcmp(txt, "TREaaRLIG"))         r = TRIANNUALLY ;
    else if (!strcmp(txt, "TRE�RLIG"))          r = TRIANNUALLY ;
    else if (!strcmp(txt, "TRE�RLIG"))          r = TRIANNUALLY ;
    else if (!strcmp(txt, "TRE�RLIG"))          r = TRIANNUALLY ;
    else if (!strcmp(txt, "TRE�RLIG"))          r = TRIANNUALLY ;
    else if (!strcmp(txt, "TRIA"))              r = TRIANNUALLY ;

    else if (!strcmp(txt, "BIANNUALLY"))       r = BIANNUALLY ;
    else if (!strcmp(txt, "TOAARLIG"))          r = BIANNUALLY ;
    else if (!strcmp(txt, "TOAARLIG"))          r = BIANNUALLY ;
    else if (!strcmp(txt, "TOOERLIG"))          r = BIANNUALLY ;
    else if (!strcmp(txt, "TOaaRLIG"))          r = BIANNUALLY ;
    else if (!strcmp(txt, "TO�RLIG"))           r = BIANNUALLY ;
    else if (!strcmp(txt, "TO�RLIG"))           r = BIANNUALLY ;
    else if (!strcmp(txt, "TO�RLIG"))           r = BIANNUALLY ;
    else if (!strcmp(txt, "TO�RLIG"))           r = BIANNUALLY ;
    else if (!strcmp(txt, "BIA"))               r = BIANNUALLY ;

    else if (!strcmp(txt, "ANNUALLY"))         r = ANNUALLY ;
    else if (!strcmp(txt, "ANNUAL"))           r = ANNUALLY ;
    else if (!strcmp(txt, "A"))                r = ANNUALLY ;
    else if (!strcmp(txt, "AARLIG"))            r = ANNUALLY ;
    else if (!strcmp(txt, "AARLIG"))            r = ANNUALLY ;
    else if (!strcmp(txt, "OERLIG"))            r = ANNUALLY ;
    else if (!strcmp(txt, "aaRLIG"))            r = ANNUALLY ;
    else if (!strcmp(txt, "�RLIG"))             r = ANNUALLY ;
    else if (!strcmp(txt, "�RLIG"))             r = ANNUALLY ;
    else if (!strcmp(txt, "�RLIG"))             r = ANNUALLY ;
    else if (!strcmp(txt, "�RLIG"))             r = ANNUALLY ;

    else if (!strcmp(txt, "SEMIANNUALLY"))     r = SEMIANNUALLY ;
    else if (!strcmp(txt, "SEMIANNUAL"))       r = SEMIANNUALLY ;
    else if (!strcmp(txt, "S"))                r = SEMIANNUALLY ;
    else if (!strcmp(txt, "HALVAARLIG"))        r = SEMIANNUALLY ;
    else if (!strcmp(txt, "HALVAARLIG"))        r = SEMIANNUALLY ;
    else if (!strcmp(txt, "HALVOERLIG"))        r = SEMIANNUALLY ;
    else if (!strcmp(txt, "HALVaaRLIG"))        r = SEMIANNUALLY ;
    else if (!strcmp(txt, "SA"))                r = SEMIANNUALLY ;
    else if (!strcmp(txt, "HALV�RLIG"))        r = SEMIANNUALLY ;
    else if (!strcmp(txt, "HALV�RLIG"))        r = SEMIANNUALLY ;
    else if (!strcmp(txt, "HALV�RLIG"))        r = SEMIANNUALLY ;
    else if (!strcmp(txt, "HALV�RLIG"))        r = SEMIANNUALLY ;

    else if (!strcmp(txt, "FOURTHMONTHLY"))    r = FOURTHMONTHLY ;
    else if (!strcmp(txt, "FM"))               r = FOURTHMONTHLY ;

    else if (!strcmp(txt, "QUARTERLY"))        r = QUARTERLY ;
    else if (!strcmp(txt, "QUARTER"))          r = QUARTERLY ;
    else if (!strcmp(txt, "Q"))                r = QUARTERLY ;
    else if (!strcmp(txt, "KVARTALSVIS"))      r = QUARTERLY ;
    else if (!strcmp(txt, "KVARTAL"))          r = QUARTERLY ;

    else if (!strcmp(txt, "BIMONTHLY"))        r = BIMONTHLY ;
    else if (!strcmp(txt, "BM"))               r = BIMONTHLY ;

    else if (!strcmp(txt, "MONTHLY"))          r = MONTHLY ;
    else if (!strcmp(txt, "MAANEDLIG"))         r = MONTHLY ;
    else if (!strcmp(txt, "MAANEDLIG"))         r = MONTHLY ;
    else if (!strcmp(txt, "MOENEDLIG"))         r = MONTHLY ;
    else if (!strcmp(txt, "MaaNEDLIG"))         r = MONTHLY ;
    else if (!strcmp(txt, "M�NEDLIG"))         r = MONTHLY ;
    else if (!strcmp(txt, "M�NEDLIG"))         r = MONTHLY ;
    else if (!strcmp(txt, "M�NEDLIG"))         r = MONTHLY ;
    else if (!strcmp(txt, "M�NEDLIG"))         r = MONTHLY ;
    else if (!strcmp(txt, "M"))                r = MONTHLY ;

    else if (!strcmp(txt, "NO_FREQUENCY"))     r = NO_FREQUENCY ;
    else if (!strcmp(txt, "IRREGULAR"))        r = NO_FREQUENCY ;
    else if (!strcmp(txt, "UREGELMAESSIG"))    r = NO_FREQUENCY ;
    else if (!strcmp(txt, "NONE"))             r = NO_FREQUENCY ;
    else if (!strcmp(txt, "NO"))               r = NO_FREQUENCY ;
    else if (!strcmp(txt, "UREGELM�SSIG"))     r = NO_FREQUENCY ;

    else
        SCecon_error("Unknown payment frequency convention\n", 
          "Str2PMTFREQ()", SCECONABORT) ;

    return r ;
}


/*
..
*/


BONDTYPE Str2BONDTYPE(TEXT txt)
{
    BONDTYPE r = BONDTYPE_INIT ;

    Str_Uppercase(txt) ;

    if      (!strcmp(txt, "BULLET"))      r = BULLET ;
    else if (!strcmp(txt, "B"))           r = BULLET ;
    else if (!strcmp(txt, "STL"))         r = BULLET ;
    else if (!strcmp(txt, "ST. L"))       r = BULLET ;
    else if (!strcmp(txt, "STAAENDE LAAN")) r = BULLET ;
    else if (!strcmp(txt, "ST�ENDE L�N"))  r = BULLET ;

    else if (!strcmp(txt, "SERIAL"))      r = SERIAL ;
    else if (!strcmp(txt, "S"))           r = SERIAL ;
    else if (!strcmp(txt, "SERIE"))       r = SERIAL ;
    else if (!strcmp(txt, "SERIELAAN"))    r = SERIAL ;
    else if (!strcmp(txt, "SERIEL�N"))     r = SERIAL ;

    else if (!strcmp(txt, "ANNUITY"))      r = ANNUITY ;
    else if (!strcmp(txt, "A"))            r = ANNUITY ;
    else if (!strcmp(txt, "ANNUITET"))     r = ANNUITY ;
    else if (!strcmp(txt, "ANNUITETSLAAN")) r = ANNUITY ;
    else if (!strcmp(txt, "ANNUITETSL�N")) r = ANNUITY ;

    else if (!strcmp(txt, "NONREGULAR"))  r = NONREGULAR ;
    else if (!strcmp(txt, "IRREGULAR"))   r = NONREGULAR ;
    else if (!strcmp(txt, "ODD"))         r = NONREGULAR ;
    else if (!strcmp(txt, "SPECIAL"))     r = NONREGULAR ;
    else if (!strcmp(txt, "PLAN"))        r = NONREGULAR ;

    else if (!strcmp(txt, "PERPETUAL"))    r = PERPETUAL ;

    else if (!strcmp(txt, "SERIAL_PCT"))   r = SERIAL_PCT ;

    else if (!strcmp(txt, "ANNUITY_PCT"))  r = ANNUITY_PCT ;

    else if (!strcmp(txt, "ANNUITY_PREP"))  r = ANNUITY_PREP ;
    else
        SCecon_error("Unknown bond type\n", "Str2BONDTYPE()", 
          SCECONABORT) ;

    return r ;
}


/*
..
*/


KEYCONV Str2KEYCONV(TEXT txt)
{
    KEYCONV r = KEYCONV_INIT ;

    Str_Uppercase(txt) ;

    if      (!strcmp(txt, "KEY_PRICE"))         r = KEY_PRICE ;
    else if (!strcmp(txt, "FUTURE"))            r = KEY_PRICE ;

    else if (!strcmp(txt, "KEY_VOL"))           r = KEY_VOL ;
    else if (!strcmp(txt, "VOLATILITY"))        r = KEY_VOL ;
    else if (!strcmp(txt, "VOL"))               r = KEY_VOL ;
    else if (!strcmp(txt, "VEGA"))              r = KEY_VOL ;

    else if (!strcmp(txt, "KEY_SIZE"))          r = KEY_SIZE ;

    else if (!strcmp(txt, "KEY_DF"))            r = KEY_DF ;
    else if (!strcmp(txt, "DF"))                r = KEY_DF ;

    else if (!strcmp(txt, "KEY_MATURITY"))      r = KEY_MATURITY ;
    else if (!strcmp(txt, "EXPIRY"))            r = KEY_MATURITY ;
    else if (!strcmp(txt, "THETA"))             r = KEY_MATURITY ;

    else if (!strcmp(txt, "KEY_FIRSTDELIVERY")) r = KEY_FIRSTDELIVERY ;

    else if (!strcmp(txt, "KEY_REPO"))          r = KEY_REPO ;
    else if (!strcmp(txt, "REPO"))              r = KEY_REPO ;

    else if (!strcmp(txt, "KEY_STRIKE"))        r = KEY_STRIKE ;
    else if (!strcmp(txt, "STRIKE"))            r = KEY_STRIKE ;

    else if (!strcmp(txt, "KEY_GAP"))           r = KEY_GAP ;

    else if (!strcmp(txt, "KEY_A"))             r = KEY_A ;
    else if (!strcmp(txt, "A"))                 r = KEY_A ;

    else if (!strcmp(txt, "KEY_SIGMA"))         r = KEY_SIGMA ;
    else if (!strcmp(txt, "SIGMA"))             r = KEY_SIGMA ;

    else if (!strcmp(txt, "KEY_SPOT"))          r = KEY_SPOT ;
    else if (!strcmp(txt, "SPOT"))              r = KEY_SPOT ;

    else if (!strcmp(txt, "KEY_SPREAD"))        r = KEY_SPREAD ;

    else if (!strcmp(txt, "KEY_DIVYLD"))        r = KEY_DIVYLD ;

    else if (!strcmp(txt, "KEY_PROB"))          r = KEY_PROB ;

    else if (!strcmp(txt, "KEY_BPV"))           r = KEY_BPV ;
    else if (!strcmp(txt, "BPV"))               r = KEY_BPV ;

    else if (!strcmp(txt, "KEY_YTM"))           r = KEY_YTM ;

    else if (!strcmp(txt, "KEY_MATURITY_BPV"))  r = KEY_MATURITY_BPV ;
    else if (!strcmp(txt, "THETABPV"))          r = KEY_MATURITY_BPV ;

    else if (!strcmp(txt, "KEY_FRA"))           r = KEY_FRA ;

    else if (!strcmp(txt, "KEY_LONG"))          r = KEY_LONG ;

    else if (!strcmp(txt, "KEY_SHORT"))         r = KEY_SHORT ;

    else if (!strcmp(txt, "KEY_GAMMAX"))        r = KEY_GAMMAX ;

    else if (!strcmp(txt, "KEY_INDEX"))         r = KEY_INDEX ;

    else
        SCecon_error("Unknown key ratio type\n", "Str2KEYCONV()", 
            SCECONABORT) ;

    return r ;
}


/*
..
*/


BOOLE Str2BOOLE(TEXT txt)
{
    BOOLE r = -1 ;

    Str_Uppercase(txt) ;

    if      (!strcmp(txt, "TRUE"))      r = True ;
    else if (!strcmp(txt, "WAHR"))      r = True ;
    else if (!strcmp(txt, "SAND"))      r = True ;
    else if (!strcmp(txt, "T"))         r = True ;

    else if (!strcmp(txt, "FALSE"))     r = False ;
    else if (!strcmp(txt, "FALSCH"))    r = False ;
    else if (!strcmp(txt, "FALSK"))     r = False ;
    else if (!strcmp(txt, "F"))         r = False ;

    else
        SCecon_error("Unknown logic type\n", "Str2BOOLE()", 
            SCECONABORT) ;

    return r ;
}


/*
..
*/


ALIGNCONV Str2ALIGNCONV(TEXT txt)
{
    ALIGNCONV r = ALIGNCONV_INIT ;

    Str_Uppercase(txt) ;

    if      (!strcmp(txt, "RIGHT"))     r = RIGHT;
    else if (!strcmp(txt, "R"))         r = RIGHT ;

    else if (!strcmp(txt, "LEFT"))      r = LEFT ;
    else if (!strcmp(txt, "L"))         r = LEFT ;

    else if (!strcmp(txt, "CENTER"))    r = CENTER ;
    else if (!strcmp(txt, "C"))         r = CENTER ;
    else if (!strcmp(txt, "M"))         r = CENTER ;

    else
        SCecon_error("Unknown aligning convention\n", 
            "Str2ALIGNCONV()", SCECONABORT) ;

    return r ;
}


/*
..
*/


SORTCONV Str2SORTCONV(TEXT txt)
{
    SORTCONV r = SORTCONV_INIT ;

    Str_Uppercase(txt) ;

    if      (!strcmp(txt, "ASCENDING"))     r = ASCENDING ;
    else if (!strcmp(txt, "DESCENDING"))    r = DESCENDING ;
    else
        SCecon_error("Unknown sorting convention\n", "Str2SORTCONV()", 
            SCECONABORT) ;

    return r ;
}


/*
..
*/


TERMUNIT Str2TERMUNIT(TEXT txt)
{
    TERMUNIT unit = TERMUNIT_INIT ;

    Str_Uppercase(txt) ;

    if      (!strcmp(txt, "DAYS"))        unit = DAYS ;
    else if (!strcmp(txt, "DAY"))         unit = DAYS ;
    else if (!strcmp(txt, "DS"))          unit = DAYS ;
    else if (!strcmp(txt, "D"))           unit = DAYS ;

    else if (!strcmp(txt, "BUSDAYS"))     unit = BUSDAYS ;
    else if (!strcmp(txt, "BDAYS"))       unit = BUSDAYS ;
    else if (!strcmp(txt, "BD"))          unit = BUSDAYS ;
    else if (!strcmp(txt, "B"))           unit = BUSDAYS ;

    else if (!strcmp(txt, "WEEKS"))       unit = WEEKS ;
    else if (!strcmp(txt, "WEEK"))        unit = WEEKS ;
    else if (!strcmp(txt, "W"))           unit = WEEKS ;

    else if (!strcmp(txt, "MONTHS"))      unit = MONTHS ;
    else if (!strcmp(txt, "MONTH"))       unit = MONTHS ;
    else if (!strcmp(txt, "M"))           unit = MONTHS ;

    else if (!strcmp(txt, "YEARS"))       unit = YEARS ;
    else if (!strcmp(txt, "YEAR"))        unit = YEARS ;
    else if (!strcmp(txt, "Y"))           unit = YEARS ;

    else
        SCecon_error("Unknown term unit\n", "Str2TERMUNIT()", 
            SCECONABORT) ;

    return unit ;
}


/*
..
*/


VOLCONV Str2VOLCONV(TEXT txt)
{
    VOLCONV vol = VOLCONV_INIT ;

    Str_Uppercase(txt) ;

    if      (!strcmp(txt, "FORWFORW"))  vol = FORWFORW ;
    else if (!strcmp(txt, "FORW FORW")) vol = FORWFORW ;
    else if (!strcmp(txt, "FF"))        vol = FORWFORW ;
    else if (!strcmp(txt, "CAPLETVOL")) vol = FORWFORW ;
    else if (!strcmp(txt, "CAPLET"))    vol = FORWFORW ;

    else if (!strcmp(txt, "FORWARD"))  vol = FORWVOL ;
    else if (!strcmp(txt, "F"))        vol = FORWVOL ;
    else if (!strcmp(txt, "FORWVOL"))  vol = FORWVOL ;
    else if (!strcmp(txt, "CAPVOL"))   vol = FORWVOL ;
    else if (!strcmp(txt, "CAP"))      vol = FORWVOL ;
    else
        SCecon_error("Unknown volatility convention\n", 
            "Str2VOLCONV()", SCECONABORT) ;

    return vol ;
}


/*
..
*/



DISCIPOL Str2DISCIPOL(TEXT txt)
{
    DISCIPOL eom = DISCIPOL_INIT ;

    Str_Uppercase(txt) ;

    if      (!strcmp(txt, "DISC"))        eom = DI_DISC ;
    else if (!strcmp(txt, "DI_DISC"))     eom = DI_DISC ;
    else if (!strcmp(txt, "TRUE"))        eom = DI_DISC ;
    else if (!strcmp(txt, "D"))           eom = DI_DISC ;

    else if (!strcmp(txt, "DI_SPOT"))     eom = DI_SPOT ;
    else if (!strcmp(txt, "SPOT"))        eom = DI_SPOT ;
    else if (!strcmp(txt, "FALSE"))       eom = DI_SPOT ;
    else if (!strcmp(txt, "S"))           eom = DI_SPOT ;

    else if (!strcmp(txt, "DI_GROWTH"))   eom = DI_GROWTH ;
    else if (!strcmp(txt, "GROWTH"))      eom = DI_GROWTH ;
    else if (!strcmp(txt, "G"))           eom = DI_GROWTH ;

    else if (!strcmp(txt, "DI_FORW"))     eom = DI_FORW ;
    else if (!strcmp(txt, "FORW"))        eom = DI_FORW ;
    else if (!strcmp(txt, "F"))           eom = DI_FORW ;
    else
        SCecon_error("Unknown discount factor interpolation type\n",
          "Str2DISCIPOL()", SCECONABORT) ;

    return eom ;
}


/*
..
*/


INWHATVOL Str2INWHATVOL(TEXT txt)
{
    INWHATVOL iw = STDEV;

    if (!strcmp("VOL", txt))            iw = VOL ;
    else if (!strcmp("VAR", txt))       iw = VAR ;
    else if (!strcmp("STDEV", txt))     iw = STDEV ;
    else
        SCecon_error("inwhatvol unknown\n", "Str2INWHATVOL()", 
            SCECONABORT) ;

    return iw ;
}

/*
..
*/


VALIDATE Str2VALIDATE(TEXT txt)
{
    VALIDATE    val = INVALID_VALIDATE;

    Str_Uppercase(txt) ;
    for (int i = 0; EV_ValidateTab[i].enVal != INVALID_VALIDATE ; i++)
    {
        if (strcmp(txt, EV_ValidateTab[i].pszText) == 0)
        {
            val = EV_ValidateTab[i].enVal;
            break;
        }
    }       
    return val ;
}

/*
..
*/


/*
..
*/


DFWHICH Str2DFWHICH(TEXT txt)
{
    DFWHICH ft = DFWHICH_INIT ;

    Str_Uppercase(txt) ;

    if      (!strcmp(txt, "DF_DISC"))    ft = DF_DISC ;
    else if (!strcmp(txt, "DF_CFLW"))    ft = DF_CFLW ;
    else if (!strcmp(txt, "DF_BOTH"))    ft = DF_BOTH ;
    else
        SCecon_error("Unknown DFWHICH\n", "str2DFWHICH()",
                     SCECONABORT) ;

    return ft ;
}


/*
..
*/

WEEKDAY Str2WEEKDAY(TEXT  txt)
{
    WEEKDAY x = MONDAY;

    Str_Uppercase(txt) ;

    if      (!strcmp(txt, "MONDAY"))     x = MONDAY ;
    else if (!strcmp(txt, "MON"))        x = MONDAY ;
    else if (!strcmp(txt, "M"))          x = MONDAY ;

    else if (!strcmp(txt, "TUESDAY"))    x = TUESDAY ;
    else if (!strcmp(txt, "TUE"))        x = TUESDAY ;
    else if (!strcmp(txt, "T"))          x = TUESDAY ;

    else if (!strcmp(txt, "WEDNESDAY"))  x = WEDNESDAY ;
    else if (!strcmp(txt, "WED"))        x = WEDNESDAY ;
    else if (!strcmp(txt, "W"))          x = WEDNESDAY ;

    else if (!strcmp(txt, "THURSDAY"))   x = THURSDAY ;
    else if (!strcmp(txt, "THU"))        x = THURSDAY ;
    else if (!strcmp(txt, "TH"))         x = THURSDAY ;

    else if (!strcmp(txt, "FRIDAY"))     x = FRIDAY ;
    else if (!strcmp(txt, "FRI"))        x = FRIDAY ;
    else if (!strcmp(txt, "F"))          x = FRIDAY ;

    else if (!strcmp(txt, "SATURDAY"))   x = SATURDAY ;
    else if (!strcmp(txt, "SAT"))        x = SATURDAY ;
    else if (!strcmp(txt, "SA"))         x = SATURDAY ;

    else if (!strcmp(txt, "SUNDAY"))     x = SUNDAY ;
    else if (!strcmp(txt, "SUN"))        x = SUNDAY ;
    else if (!strcmp(txt, "SU"))         x = SUNDAY ;

    else if (!strcmp(txt, "DAY"))        x = DAY ;
    else if (!strcmp(txt, "DAYS"))       x = DAY ;
    else if (!strcmp(txt, "D"))          x = DAY ;

    else
        SCecon_error("Unknown weekday convention\n", "Str2WEEKDAY()",
          SCECONABORT) ;

    return x;
}

/*
..
*/

ANCHORDAY Str2ANCHORDAY(TEXT  txt)
{
    ANCHORDAY x = JANUARY_1;

    Str_Uppercase(txt) ;

    if      (!strcmp(txt, "JANUARY_1"))     x = JANUARY_1 ;
    else if (!strcmp(txt, "JANUARY"))       x = JANUARY_1 ;
    else if (!strcmp(txt, "JAN"))           x = JANUARY_1 ;

    else if (!strcmp(txt, "FEBRUARY_1"))    x = FEBRUARY_1 ;
    else if (!strcmp(txt, "FEBRUARY"))      x = FEBRUARY_1 ;
    else if (!strcmp(txt, "FEB"))           x = FEBRUARY_1 ;

    else if (!strcmp(txt, "MARCH_1"))       x = MARCH_1 ;
    else if (!strcmp(txt, "MARCH"))         x = MARCH_1 ;
    else if (!strcmp(txt, "MAR"))           x = MARCH_1 ;

    else if (!strcmp(txt, "APRIL_1"))       x = APRIL_1 ;
    else if (!strcmp(txt, "APRIL"))         x = APRIL_1 ;
    else if (!strcmp(txt, "APR"))           x = APRIL_1 ;

    else if (!strcmp(txt, "MAY_1"))         x = MAY_1 ;
    else if (!strcmp(txt, "MAY"))           x = MAY_1 ;

    else if (!strcmp(txt, "JUNE_1"))        x = JUNE_1 ;
    else if (!strcmp(txt, "JUNE"))          x = JUNE_1 ;
    else if (!strcmp(txt, "JUN"))           x = JUNE_1 ;

    else if (!strcmp(txt, "JULY_1"))        x = JULY_1 ;
    else if (!strcmp(txt, "JULY"))          x = JULY_1 ;
    else if (!strcmp(txt, "JUL"))           x = JULY_1 ;

    else if (!strcmp(txt, "AUGUST_1"))      x = AUGUST_1 ;
    else if (!strcmp(txt, "AUGUST"))        x = AUGUST_1 ;
    else if (!strcmp(txt, "AUG"))           x = AUGUST_1 ;

    else if (!strcmp(txt, "SEPTEMBER_1"))   x = SEPTEMBER_1 ;
    else if (!strcmp(txt, "SEPTEMBER"))     x = SEPTEMBER_1 ;
    else if (!strcmp(txt, "SEP"))           x = SEPTEMBER_1 ;

    else if (!strcmp(txt, "OCTOBER_1"))     x = OCTOBER_1 ;
    else if (!strcmp(txt, "OCTOBER"))       x = OCTOBER_1 ;
    else if (!strcmp(txt, "OCT"))           x = OCTOBER_1 ;

    else if (!strcmp(txt, "NOVEMBER_1"))    x = NOVEMBER_1 ;
    else if (!strcmp(txt, "NOVEMBER"))      x = NOVEMBER_1 ;
    else if (!strcmp(txt, "NOV"))           x = NOVEMBER_1 ;

    else if (!strcmp(txt, "DECEMBER_1"))    x = DECEMBER_1 ;
    else if (!strcmp(txt, "DECEMBER"))      x = DECEMBER_1 ;
    else if (!strcmp(txt, "DEC"))           x = DECEMBER_1 ;

    else if (!strcmp(txt, "EASTER_SUN"))    x = EASTER_SUN ;
    else if (!strcmp(txt, "EASTER"))        x = EASTER_SUN ;
    else if (!strcmp(txt, "EAST"))          x = EASTER_SUN ;
    else if (!strcmp(txt, "EAS"))           x = EASTER_SUN ;

    else if (!strcmp(txt, "PENTECOST_SUN")) x = PENTECOST_SUN ;
    else if (!strcmp(txt, "PENTECOST"))     x = PENTECOST_SUN ;
    else if (!strcmp(txt, "PENT"))          x = PENTECOST_SUN ;
    else if (!strcmp(txt, "PEN"))           x = PENTECOST_SUN ;

    else if (!strcmp(txt, "ADVENT_SUN1"))   x = ADVENT_SUN1 ;
    else if (!strcmp(txt, "ADVENT_SUN"))    x = ADVENT_SUN1 ;
    else if (!strcmp(txt, "ADVENT"))        x = ADVENT_SUN1 ;
    else if (!strcmp(txt, "ADV"))           x = ADVENT_SUN1 ;

    else
        SCecon_error("Unknown anchor day convention\n", 
          "Str2ANCHORDAY()", SCECONABORT) ;

    return x ;
}




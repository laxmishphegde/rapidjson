/* SCID @(#)ifl1.c	1.8 (SimCorp) 99/02/19 14:15:40 */

#include <f2proto.h>

/* WARNING: FUNCTION-ARG BELOW */
int calc(
/* void (*fdf)(integer *, integer *, double *, double *), */
   int (*fdf)(integer *, integer *, double *, void *, double *),
         F2CONST  integer *n,
         F2CONST  integer *m,
         F2CONST  double x[],
         void *data,
         double df[],
         double f[])
{
    integer df_dim1 = *m;

    /* f2c maps two-dimensional FORTRAN arrays onto
       one-dimensional c arrays
       and uses zero as lower bound
    */
    int i,j;
    F2CONST double h = 1e-3; /* advanced use : change step length here */
    double hx, c;

    fdf(n,m,x,data,f);


    for (i=0; i<*n; i++) {
        c= x[i];
        hx = (c) ? c*h : h;
        x[i] = c+hx;
        fdf(n,m,x,data,&df[i*df_dim1]);
        x[i] = c; /* restore x[i] */
        for (j=0; j<df_dim1; j++)
            df[j+i*df_dim1] = (df[j+i*df_dim1] -f[j])/hx;
    }
    return 0 ;
}

/* WARNING: FUNCTION-ARG BELOW */
int mi0cl1(
/*    void (*fdf)(integer *, integer *, double *, double *), */
      int (*fdf)(integer *, integer *, double *, void *, double *),
      integer N,
      integer M,
      integer L,
      integer LEQ,
      F2CONST double c[],
      F2CONST double dc[],
      double x[],
      double *dx,
      double *eps,
      integer *maxfun,
      double *w,
      integer IW,
      integer *icontr,
      void    *data)
{
    F2CONST integer n = N;
    F2CONST integer m = M;
    F2CONST integer l = L;
    F2CONST integer leq = LEQ;
    F2CONST integer iw=IW;

    mincl1_(calc, fdf, &n, &m, &l, &leq, c, dc, x, dx, eps, maxfun, w, &iw,
      icontr, data);
    return 0 ;
}

/* Peter Hegelund ,Numerical Institute, Technical University of Denmark
   function to handle FORTRAN DSIGN function
   (an alternative to linking with F77lib)
   910214
*/

double d_sign(double *a, double *b)
{
    if (*b >= 0.0)
        return (double) dabs(*a);
    else
        return (double) -dabs(*a);
}




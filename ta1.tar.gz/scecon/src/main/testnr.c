/* SCID @(#)testnr.c	1.7 (SimCorp) 99/10/01 14:49:15 */

/************************************************************************
*
*   project     SCecon
*
*   functions to test Newton-Raphson routine 
*
************************************************************************/

/*** includes ***********************************************************/
#include <string.h>
#include <str2conv.h>
#include <validate.h>
#include <ioconv.h>

/* test function no. 1 */
BOOLE newton_f1(FL64  x, void*  y, BOOLE  grad, FL64*  fx, FL64*  dfx, void*  hol)
{
	/* PMSTA-29444 - SRIDHARA - 050318 */
	HOLI_STR    holi = (*(HOLI_STR *)hol);
	holi = Set_HOLI_STR(NO_BUSADJUST, 0, NULL);
	  
  if (0 <= x && x <= 1)
    *fx = 0;
  else if (1 < x)
    *fx = 1;
  else
    return False;
  if (grad == True)
    *dfx = 0;
  y = y;
  return True;
}

/* test function no. 2 */
BOOLE newton_f2(FL64  x, void*  y, BOOLE  grad, FL64*  fx, FL64*  dfx, void*  hol)
{
	/* PMSTA-29444 - SRIDHARA - 050318 */
	HOLI_STR    holi = (*(HOLI_STR *)hol);
	holi = Set_HOLI_STR(NO_BUSADJUST, 0, NULL);

  *fx = x*x;
  if (grad == True)
    *dfx = 2*x;
  y = y;
  return True;
}

/* test function no. 3 */
BOOLE newton_f3(FL64  x, void*  y, BOOLE  grad, FL64*  fx, FL64*  dfx, void*  hol)
{
	/* PMSTA-29444 - SRIDHARA - 050318 */
	HOLI_STR    holi = (*(HOLI_STR *)hol);
	holi = Set_HOLI_STR(NO_BUSADJUST, 0, NULL);

  if (x <= 0)
  {
    *fx = 0;
    *dfx = 0;
  }
  else
  {
    *fx = x*x;
    if (grad == True)
      *dfx = 2*x;
  }
  y = y;
  return True;
}

/* test function no. 4 */
BOOLE newton_f4(FL64  x, void*  y, BOOLE  grad, FL64*  fx, FL64*  dfx, void*  hol)
{
	/* PMSTA-29444 - SRIDHARA - 050318 */
	HOLI_STR    holi = (*(HOLI_STR *)hol);
	holi = Set_HOLI_STR(NO_BUSADJUST, 0, NULL);

  if (x >= 0)
  {
    *fx = 0;
    *dfx = 0;
  }
  else
  {
    *fx = x*x;
    if (grad == True)
      *dfx = 2*x;
  }
  y = y;
  return True;
}

/* test function no. 5 */
BOOLE newton_f5(FL64  x, void*  y, BOOLE  grad, FL64*  fx, FL64*  dfx, void*  hol)
{
	/* PMSTA-29444 - SRIDHARA - 050318 */
	HOLI_STR    holi = (*(HOLI_STR *)hol);
	holi = Set_HOLI_STR(NO_BUSADJUST, 0, NULL);

  *fx = x*x*x + 1;
  if (grad == True)
    *dfx =3*x*x;
  y = y;
  return True;
}

/* test function no. 6 */
BOOLE newton_f6(FL64  x, void*  y, BOOLE  grad, FL64*  fx, FL64*  dfx, void*  hol)
{
	/* PMSTA-29444 - SRIDHARA - 050318 */
	HOLI_STR    holi = (*(HOLI_STR *)hol);
	holi = Set_HOLI_STR(NO_BUSADJUST, 0, NULL);

  *fx = x*x*x - 1;
  if (grad == True)
    *dfx =3*x*x;
  y = y;
  return True;
}

/* test function no. 7 */
BOOLE newton_f7(FL64  x, void*  y, BOOLE  grad, FL64*  fx, FL64*  dfx, void*  hol)
{
	/* PMSTA-29444 - SRIDHARA - 050318 */
	HOLI_STR    holi = (*(HOLI_STR *)hol);
	holi = Set_HOLI_STR(NO_BUSADJUST, 0, NULL);

  *fx = sin(x) + 0.5;
  if (grad == True)
    *dfx = cos(x);
  y = y;
  return True;
}

/* test function no. 8 */
BOOLE newton_f8(FL64  x, void*  y, BOOLE  grad, FL64*  fx, FL64*  dfx, void*  hol)
{
	/* PMSTA-29444 - SRIDHARA - 050318 */
	HOLI_STR    holi = (*(HOLI_STR *)hol);
	holi = Set_HOLI_STR(NO_BUSADJUST, 0, NULL);

  *fx = log(x) + 1;
  if (grad == True)
    *dfx = 1/x;
  y = y;
  return True;
}

/* test function no. 9 */
BOOLE newton_f9(FL64  x, void*  y, BOOLE  grad, FL64*  fx, FL64*  dfx, void*  hol)
{
	/* PMSTA-29444 - SRIDHARA - 050318 */
	HOLI_STR    holi = (*(HOLI_STR *)hol);
	holi = Set_HOLI_STR(NO_BUSADJUST, 0, NULL);

  *fx = log(-x) + 1;
  if (grad == True)
    *dfx = 1/x;
  y = y;
  return True;
}

/* test function no. 10 */
BOOLE newton_f10(FL64  x, void*  y, BOOLE  grad, FL64*  fx, FL64*  dfx, void*  hol)
{
	/* PMSTA-29444 - SRIDHARA - 050318 */
	HOLI_STR    holi = (*(HOLI_STR *)hol);
	holi = Set_HOLI_STR(NO_BUSADJUST, 0, NULL);

  if (x == 1)
    *fx = 1;
  else if (x == -1)
    *fx = -1;
  if (grad == True) 
    *dfx = 0.5;
  y = y;
  return True;
}


INTI Newton_Raphson_test(char* txa, FILE* in, FILE* out)
{
    INTI        diff = -1;

    if  (!strcmp(txa, "Newton_Raphson()"))
    {
        FL64        acc, fres, x = 0 ;
        INTI        fno, okres ;
        ITERCTRL    ctrl;
        NR_ERR      ok = NR_CONSTANT_ZERO;

	    /* PMSTA-22396 - SRIDHARA � 160502 */
	    HOLI_STR    holi;
	    holi = Set_HOLI_STR(NO_BUSADJUST, 0, NULL);

        acc   = 0.0001 ;

        fprintf(out, "%s\n", txa);

        ctrl = Read_ITERCTRL(in, out);
        fno = Read_INTI(in, out, "Function No ");
        okres = Read_INTI(in, out, "Expected NR_ERR ");
        fres = Read_FL64(in, out, "Expected Root   ");
    
		/* PMSTA-22396 - SRIDHARA � 160502 */
        if (fno == 1)       
          ok = Newton_Raphson(&newton_f1, &fno, &ctrl, &x, &holi);
        else if (fno == 2)       
          ok = Newton_Raphson(&newton_f2, &fno, &ctrl, &x, &holi);
        else if (fno == 3)       
          ok = Newton_Raphson(&newton_f3, &fno, &ctrl, &x, &holi);
        else if (fno == 4)       
          ok = Newton_Raphson(&newton_f4, &fno, &ctrl, &x, &holi);
        else if (fno == 5)       
          ok = Newton_Raphson(&newton_f5, &fno, &ctrl, &x, &holi);
        else if (fno == 6)       
          ok = Newton_Raphson(&newton_f6, &fno, &ctrl, &x, &holi);
        else if (fno == 7)       
          ok = Newton_Raphson(&newton_f7, &fno, &ctrl, &x, &holi);
        else if (fno == 8)       
          ok = Newton_Raphson(&newton_f8, &fno, &ctrl, &x, &holi);
        else if (fno == 9)       
          ok = Newton_Raphson(&newton_f9, &fno, &ctrl, &x, &holi);
        else if (fno == 10)       
          ok = Newton_Raphson(&newton_f10, &fno, &ctrl, &x, &holi);

        fprintf(out, "* NR_ERR          :  %d \n", 
          ok) ;
        fprintf(out, "* Root            :  %lf \n",
          x) ;

        diff = (ok != okres);

        if (okres == NR_ROOT_FOUND || okres == NR_CONSTANT_ZERO)
          diff = diff || fabs(fres - x) > acc;
        
        if (diff == True)
          fprintf(out, "1; ");
        else
          fprintf(out, "0; ");
       
        IOUtil_ParseLine(in, out) ;

    }

    return diff ;
}


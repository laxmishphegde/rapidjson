/* SCID @(#)scutl.c	1.28 (SimCorp) 99/02/25 09:35:10 */

/************************************************************************
*
*   project     SCecon
*
*   filename    scutl.c
*
*   contains    routines in the SCecon Library Utilities library
*
************************************************************************/

/***** includes ********************************************************/
#include <scutl.h>

#ifdef SC_LICENSEDATE
#include <time.h>
#endif

/***** defines  ********************************************************/
#define SHOCK_TOL 0.0000000001

/*,,SOH,,
*************************************************************************
*
*               Scutl_Indexx_FL64()
*
*    interface  #include <scutl.h>
*               INTIARRAY Scutl_Indexx_FL64(INTI      n,
*                                           FL64ARRAY arr,
*                                           SORTCONV  sort) ;
*
*    general    Returns a sort index for a FL64 array. Depending on
*               the sort convention the index is sorted ascendingly
*               or descendingly.
*
*               The elements in the index are the sequence in which the
*               elements must be taken in order to be sorted according
*               to sort. For instance, if index[0] is 5 then the fifth
*               element of arr is the first in the ordered list etc.
*
*    input      INTI      n     The number of elements in arr
*
*               FL64ARRAY arr   Array of values to be indexed.
*
*               SORTCONV  sort  Convention for the sorting.
*
*    output
*
*    returns    Array of indices of the sorted array. Allocated in this
*               routine with n entries as Alloc_INTIARRAY(n)
*
*    diagnostics
*
*    see also   Scutl_Indexx_INTI()
*               Scutl_Permute_FL64()
*
*************************************************************************
,,EOH,,*/


INTIARRAY Scutl_Indexx_FL64(INTI n, FL64ARRAY arr, SORTCONV sort)
{
    INTI      i, j, b ;
    FL64      a, *aa ;
    INTIARRAY index ;

    index = Alloc_INTIARRAY(n) ;
    aa    = Alloc_FL64ARRAY(n) ;

    for (j = 0 ; j < n ; j++)
    {
        index[j] = j ;
        aa[j]    = arr[j] ;
    }

    for (j = 1 ; j < n ; j++)
    {
        a = aa[j] ;
        b = index[j] ;
        i = j - 1 ;
        if (sort == ASCENDING)
        {
            while (i >= 0 && a < aa[i])
            {
                aa[i + 1]    = aa[i] ;
                index[i + 1] = index[i] ;
                i-- ;
            }
        }
        else if (sort == DESCENDING)
        {
            while (i >= 0 && a > aa[i])
            {
                aa[i + 1]    = aa[i] ;
                index[i + 1] = index[i] ;
                i-- ;
            }
        }
        aa[i + 1]    = a ;
        index[i + 1] = b ;
    }

    Free_FL64ARRAY(aa) ;

    return index ;
}


/*,,SOH,,
*************************************************************************
*
*               Scutl_Indexx_INTI()
*
*    interface  #include <scutl.h>
*               INTIARRAY Scutl_Indexx_INTI(INTI      n,
*                                           INTIARRAY arr,
*                                           SORTCONV  sort) ;
*
*    general    Returns a sort index for a INTIARRAY. Depending on
*               the sort convention the index is sorted ascendingly
*               or descendingly.
*
*               The elements in the index are the sequence in which the
*               elements must be taken in order to be sorted according
*               to sort. For instance, if index[0] is 5 then the fifth
*               element of arr is the first in the ordered list etc.
*
*    input      INTI      n     The number of elements in arr
*
*               INTIARRAY arr   Array of values to be indexed.
*
*               SORTCONV  sort  Convention for the sorting.
*
*    output
*
*    returns    Array of indices of the sorted array. Allocated in this
*               routine with n entries as Alloc_INTIARRAY(n)
*
*    diagnostics
*
*    see also   Scutl_Indexx_FL64()
*
*************************************************************************
,,EOH,,*/


INTIARRAY Scutl_Indexx_INTI(INTI n, INTIARRAY arr, SORTCONV sort)
{
    INTI      i, j, b ;
    INTI      a, *aa ;
    INTIARRAY index ;

    index = Alloc_INTIARRAY(n) ;
    aa    = Alloc_INTIARRAY(n) ;

    for (j = 0 ; j < n ; j++)
    {
        index[j] = j ;
        aa[j]    = arr[j] ;
    }

    for (j = 1 ; j < n ; j++)
    {
        a = aa[j] ;
        b = index[j] ;
        i = j - 1 ;
        if (sort == ASCENDING)
        {
            while (i >= 0 && a < aa[i])
            {
                aa[i + 1]    = aa[i] ;
                index[i + 1] = index[i] ;
                i-- ;
            }
        }
        else if (sort == DESCENDING)
        {
            while (i >= 0 && a > aa[i])
            {
                aa[i + 1]    = aa[i] ;
                index[i + 1] = index[i] ;
                i-- ;
            }
        }
        aa[i + 1]    = a ;
        index[i + 1] = b ;
    }

    Free_INTIARRAY(aa) ;

    return index ;
}


/*,,SOH,,
*************************************************************************
*
*               Scutl_Permute_FL64()
*
*    interface  #include <scutl.h>
*               void Scutl_Permute_FL64(INTI      n,
*                                       INTIARRAY index,
*                                       FL64ARRAY arr) ;
*
*    general    Permutes a list of FL64's using a sort index. The sort
*               index could have been found using Scutl_Indexx_FL64().
*
*    input      INTI      n     The number of elements in arr and
*                               index.
*
*               INTIARRAY index Array of indices of the sorted array
*
*    output     FL64ARRAY arr   Array of values to be sorted.
*
*    returns
*
*    diagnostics
*
*    see also   Scutl_Indexx_FL64()
*
*************************************************************************
,,EOH,,*/

void Scutl_Permute_FL64(INTI n, 
                           INTIARRAY index,
                           FL64ARRAY arr)
{
    INTI      i ;
    FL64ARRAY wks ;

    wks = Alloc_FL64ARRAY(n) ;

    for (i = 0 ; i < n ; i++)
        wks[i] = arr[i] ;

    for (i = 0 ; i < n ; i++)
        arr[i] = wks[index[i]] ;

    Free_FL64ARRAY(wks) ;
}


/*,,SOH,,
*************************************************************************
*
*               Scutl_Permute_INTI()
*
*    interface  #include <scutl.h>
*               void Scutl_Permute_INTI(INTI      n,
*                                       INTIARRAY index,
*                                       INTIARRAY arr) ;
*
*    general    Permutes a list of INTI's using a sort index. The sort
*               index could have been found using Scutl_Indexx_INTI().
*
*    input      INTI      n     The number of elements in arr and
*                               index.
*
*               INTIARRAY index Array of indices of the sorted array
*
*    output     INTIARRAY arr   Array of values to be sorted.
*
*    returns
*
*    diagnostics
*
*    see also   Scutl_Indexx_INTI()
*
*************************************************************************
,,EOH,,*/

void Scutl_Permute_INTI(INTI n, 
                           INTIARRAY index,
                           INTIARRAY arr)
{
    INTI      i ;
    INTIARRAY wks ;

    wks  = Alloc_INTIARRAY(n) ;

    for (i = 0 ; i < n ; i++)
        wks[i] = arr[i] ;

    for (i = 0 ; i < n ; i++)
        arr[i] = wks[index[i]] ;

    Free_INTIARRAY(wks) ;
}

/*
..
*/


FL64 Scutl_Default_Shock(FL64 shock, KEYCONV key)
{
    FL64 sh ;

    sh = shock ;

    if      (sh < SHOCK_TOL && key == KEY_VOL)      sh = 1.0 ;
    else if (sh < SHOCK_TOL && key == KEY_SPOT)     sh = 0.0001 ;
    else if (sh < SHOCK_TOL && key == KEY_REPO)     sh = 0.01 ;
    else if (sh < SHOCK_TOL && key == KEY_PRICE)    sh = 0.0001 ;
    else if (sh < SHOCK_TOL && key == KEY_STRIKE)   sh = 0.01 ;
    else if (sh < SHOCK_TOL && key == KEY_DF)       sh = 0.01 ;
    else if (sh < SHOCK_TOL && key == KEY_BPV)      sh = 0.01 ;
    else if (sh < SHOCK_TOL && key == KEY_A)        sh = 0.01 ;
    else if (sh < SHOCK_TOL && key == KEY_SPREAD)   sh = 0.01 ;
    else if (sh < SHOCK_TOL && key == KEY_DIVYLD)   sh = 0.01 ;
    else if (sh < SHOCK_TOL && key == KEY_SIGMA)    sh = 0.0001 ;
    else if (sh < SHOCK_TOL && key == KEY_PROB)     sh = 0.0001 ;
    else if (sh < SHOCK_TOL && key == KEY_MATURITY) sh = 1.0 ;     /* 1 day */
    else if (sh < SHOCK_TOL && key == KEY_MATURITY_BPV) sh = 1.0 ;     /* 1 day
      */
    else if (sh < SHOCK_TOL && key == KEY_FIRSTDELIVERY) sh = 1.0 ;/* 1 day */
    else if (sh < SHOCK_TOL && key == KEY_YTM)      sh = 0.01 ;
    else if (sh < SHOCK_TOL && key == KEY_GAMMAX)   sh = 0.01 ;

    return sh ;
}


/* If SC_LICENSEDATE is defined, then it must be defined as a date
   in the YYYYMMDD format, eg SC_LICENSEDATE=19980103 for
   January 3rd, 1998.
   Using this the library will issue an error message and abort
   execution. Once the license expires, the only way out is a new
   library!
*/
/*
   INTI Math_LaGuerre (INTI x1, INTI x2, INTI x3)

   Aborts if it system date is beyond SC_LICENSEDATE or
   if the date (y=x1,m=x2,m=x3) is beyond SC_LICENSEDATE

   returns   x1 + x2 + x3
*/
INTI Math_LaGuerre(INTI  x1, INTI  x2, INTI  x3)
{
  static TEXT cc = "This is SCEcon - SimCorp Software";
  INTI cl, i, n, m, nr, mr;
#ifdef SC_LICENSEDATE
  time_t lt;
  struct tm *newt;
  INTI sdy, sdm, sdd, ldy, ldm, ldd;
  INTL ymd;
#endif

  cl = 31; /* Length of cc */
  nr = 2701; /* Sum of char values */
  mr = 91; /* Alternating sum of char values */

  for(n = m = i = 0; i < cl; i++)
  {
    n += cc[i];
    m += (i % 2 == 0 ? cc[i] : -cc[i]);
  }

  if (n != nr && m != mr)
  {
    SCecon_error("Library Corrupt", "SCEcon License Manager", 
        SCECONCONTINUE);

    exit(1);
  }

#ifdef SC_LICENSEDATE
  time(&lt);
  newt = localtime(&lt);
  sdy = 1900 + newt->tm_year;
  sdm = newt->tm_mon+1;
  sdd = newt->tm_mday;

  ymd = (INTL) SC_LICENSEDATE;
  ldy = (INTI ) (ymd/10000) ;
  ymd      -= 10000L*ldy ;
  ldm = (INTI ) (ymd)/100 ;
  ymd      -= 100L*ldm ;
  ldd = (INTI ) ymd ;

  if ((sdy > ldy) ||
      (sdy == ldy && sdm > ldm) ||
      (sdy == ldy && sdm == ldm && sdd > ldd))
  {
    SCecon_error("License Expired", "SCEcon License Manager", 
        SCECONCONTINUE);

    exit(1);
  }
/*
  if ((x1 > ldy) ||
      (x1 == ldy && x2 > ldm) ||
      (x1 == ldy && x2 == ldm && x3 > ldd))
  {
    SCecon_error("Unlimited use is denied", 
        "SCEcon License Manager", SCECONCONTINUE);

    exit(1);
  }*/

#endif

  return x1 + x2 + x3;
}



#undef SHOCK_TOL


/*
..
*/
/* Utility to subdivide FL64ARRAY of (increasing) terms 
   ----------------------------------------------------
   Create new array based on input array 'in' consisting of the
   array 'in' with 'ratio'-1 elements evenly spaced values inserted
   between the elements of in. output array is cutoff with largest
   value not greater than 'last'.

  Ex: in = {0.0, 0.5, 1.0}
      ratio = 4
      last = 0.75
   
      out = {0.0, 0.125, 0.25, 0.375, 0.5, 0.625, 0.75}

*/


FL64ARRAY   Scutl_SubdivideFL64ARRAY(FL64ARRAY    in,
                            INTI         nin,
                            INTI         ratio,
                            FL64         last,
                            INTI*        nout)
{
  FL64ARRAY out, tmp ;
  INTI      i, j, jx ;
  BOOLE     done ;
  FL64      rt ;  

  jx = 0 ;
  rt = (FL64) ratio ;

  /* allocate for workspace */
  *nout = (nin - 1) * ratio + 1 ;
  tmp = Alloc_FL64ARRAY(*nout) ;

  for (i = 0, done = False; i < nin - 1 && done == False; i++)
    for (j = 0; j < ratio && done == False; j++)
      if ((tmp[i*ratio+j] = in[i] + (in[i+1] - in[i]) * (FL64) j / rt) 
          >= last)
        {
          done = True ;
          jx = i * ratio + j ;
        }
  if (done == True) 
    *nout = jx + 1 ;
  else
    tmp[*nout-1] = in[nin-1] ;

  /* copy to output */
  out = Alloc_FL64ARRAY(*nout) ;
  for (i = 0; i < *nout; i++)
    out[i] = tmp[i] ;

  /* free */
  Free_FL64ARRAY(tmp) ;

  /* return */
  return out ;
}




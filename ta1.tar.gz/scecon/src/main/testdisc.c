/* SCID @(#)testdisc.c	1.12 (SimCorp) 99/02/19 14:16:57 */

/************************************************************************
*
*   Project     SCecon
*
*   this program tests the routines in the disc.fcts module of SCecon
*
************************************************************************/


/*** includes ***********************************************************/
#include <string.h>
#include <stdlib.h>
#include <scalloc.h>
#include <disc.h>
#include <str2conv.h>
#include <ioconv.h>


INTI disctest(char* txa, FILE* in, FILE* out)
{
    char        txb[25], txc[25], txd[25], txe[25], txpl[150] ;
    FL64        acc, fres, fexp, spr ;
    INTI        nloads, dif1, qbas, i, diff, n, na, nd, ndates ;
    INTI        nrates;
    DISCIPOL    ipol ;
    YYYYMMDD    ymd, ymd2 ;
    DATESTR     today, analys, date, end ;
    DATEARRAY   dates ;
    PLANARRAY   dfexp, disc1, disc, dstr, loads ;
    CALCONV     cal ;
    IRRCONV     irr ;
    FL64ARRAY   dfac, efac, fixcoupon, expcoup, fixamort, rates ;
    DATEARRAY   fixdays ;
    INTPOLCONV  iconv ;
    TSARRAY     ts ;
    int         i1, i2, i4 ;
    DISCFAC     df1, df ;
    PMTFREQ     freq ;
    RISKSET     risk ;
    BUCKETARRAY bucket ;
    BOOLE       ins ;
    HOLI_STR    holi ;
    DFPARMS     dfp ;
    DELTASET    ds ;
    ZRATEARRAY  zrates ;
    ZRATE_STR   ztmp ;
    DFSPREAD    dfs ;

    acc = 0.00001 ;

    diff = -1 ;

    if (!strcmp("Disc_Interpolation()", txa))
    {
        fprintf(out,"   testing %s\n", txa) ;
        fexp = Read_FL64(in, out, "   Expected DF     ") ;
        date = Read_DATESTR(in, out, "   Expected Date   ") ;
        df   = Read_DISCFAC(in, out) ;
        fres = Disc_Interpolation(&date, &df, &holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */

        diff = Write_SingleDiff(True, True, fres, fexp, acc, out) ;
        fscanf(in, "%s", txpl);
        fprintf(out,"   %s\n\n", txpl) ;
        Free_PLANARRAY(df.disc, 1) ;
    }

    else if (!strcmp("Disc_IntpolArray()", txa))
    {
        fprintf(out,"   testing %s\n", txa) ;

        acc = Read_FL64(in, out, "  Tolerance ");

        df = Read_DISCFAC(in, out);

        dates = Read_DATEARRAY(in, out, &nd) ;

        dfac = Disc_IntpolArray(dates, nd, &df, &holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */

        IOUtil_ParseLine(in, out);
        efac = Read_FL64ARRAY(in, &nd);

        diff = WriteFL64ARRAYDiff(True, efac, nd, True, dfac, nd,
          out, acc);

        Free_PLANARRAY(df.disc, 1) ;
        Free_FL64ARRAY(dfac) ;
        Free_FL64ARRAY(efac) ;
        Free_DATEARRAY(dates) ;
    }

    else if (!strcmp("Disc_DF2TS()", txa))
    {
        fprintf(out,"\n   testing %s\n", txa) ;

        acc = Read_FL64(in, out, "  Tolerance ");
        df = Read_DISCFAC(in, out);        
        dates = Read_DATEARRAY(in, out, &nd);

        loads = Read_PLANARRAY(in);
        Write_PLANARRAY(out, loads);
    
        irr = Read_IRRCONV(in, out, "TS irr conv  ");
        freq = Read_PMTFREQ(in, out, "TS comp freq ");

		ts = Disc_DF2TS(dates, nd, &df, loads, irr, freq, &holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */

        IOUtil_ParseLine(in, out);

        diff = Write_TSDiff(in, out, ts, acc);

        Free_PLANARRAY(df.disc, 1) ;
        Free_PLANARRAY(loads, 1);
        Free_DATEARRAY(dates) ;
        Free_TSARRAY(ts, 1) ;
    }

    else if (!strcmp("Disc_TS2DF()", txa))
    {
        fprintf(out,"\n   testing %s\n", txa) ;

        analys = Read_DATESTR(in, out, "  Analys   ");

        dfp = Read_DFPARMS(in, out);  /* format 2 */

        fprintf(out,"   TS is...\n") ;
        dates = Read_DATEARRAY(in, out, &ndates);
        rates = Read_FL64ARRAY(in, &nrates);
        Write_FL64ARRAY(out, rates, nrates);

		df = Disc_TS2DF(&analys, dates, rates, nrates, &dfp, &holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */

        IOUtil_ParseLine(in, out);

        dfexp = Read_PLANARRAY(in);
        diff = Write_PlanDiff(dfexp, df.disc, out) ;

        Free_DATEARRAY(dates) ;
        Free_FL64ARRAY(rates) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_PLANARRAY(dfexp, 1) ;
    }

    else if (!strcmp("Disc_ShockRates()", txa))
    {
        fscanf(in, "%d %d %s %s %d %s",
               &i1, &i2, txc, txe, &i4, txpl);

        n  = (INTI) i1 ; /* disc */
        nloads = (INTI) i2 ; /* loads */
        cal  = Str2CALCONV(txc) ;
        qbas = (INTI) i4 ;
        irr  = Str2IRRCONV(txe) ;

        dstr  = Alloc_PLANARRAY(4, GETMAX(n, nloads)) ;

        fprintf(out,"\n   testing %s\n", txa) ;
        fprintf(out,"   calendar       %8s\n", txc) ;
        fprintf(out,"   irrconv        %8s\n", txe) ;
        fprintf(out,"   qbas           %8d\n", i4) ;
        fprintf(out,"   disc. fct. table is...\n") ;

        for (i = 0 ; i < n ; i++)
        {
            fscanf(in,"%ld %lf %lf",
                   &ymd, &dstr[0].f64[i], &dstr[1].f64[i]) ;
            dstr[0].day[i] = Cldr_YMD2Datestr(ymd) ;
            dstr[1].day[i] = Cldr_YMD2Datestr(ymd) ;
            fprintf(out,"   date[%2d] %8ld  disc[%2d] %10.5lf\n",
                    i, ymd, i, dstr[0].f64[i]) ;
        }
        dstr[0].filled = dstr[0].count = n ;
        dstr[1].filled = dstr[1].count = n ;

        fprintf(out,"   loading table is...\n") ;

        for (i = 0 ; i < nloads ; i++)
        {
            fscanf(in,"%ld %lf", &ymd, &dstr[3].f64[i]) ;
            dstr[3].day[i] = Cldr_YMD2Datestr(ymd) ;
            fprintf(out,"   date[%2d] %8ld  load[%2d] %10.5lf\n",
                    i, ymd, i, dstr[1].f64[i]) ;
        }
        dstr[3].filled = dstr[3].count = nloads ;

        dstr[2].filled = 0 ;
        dstr[2].count = n ;
        df.disc  = dstr ;
        df.cal   = cal ;
        df.irr   = CONTINUOUS ;
        df.freq  = ANNUALLY ;

        freq = Cflw_Months2PmtFreq(12 / GETMAX(1, qbas) ) ;
        risk = Set_RISKSET(KEY_DF, SECOND_ORDER, 1.0, irr, freq,
                                &dstr[3], True) ;

        df1 = Disc_ShockRates(&df, 1.0, &risk, &holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
        disc1 = df1.disc ;

        fprintf(out,"   date     exp.disc act.disc\n") ;
        diff = 0 ;
        for (i = 0; i < n ; i++)
        {
            dif1 = fabs(dstr[1].f64[i] - disc1->f64[i]) > acc ||
                   Cldr_DateEQ(&dstr[1].day[i], &disc1->day[i]) == False ;
            diff = diff || dif1 ;
            fprintf(out,"%d; %8ld %8lf %8lf\n",
                    dif1, Cldr_Datestr2YMD(&dstr[1].day[i]),
                    dstr[1].f64[i], disc1->f64[i]) ;
        }
        fprintf(out,"   %s\n\n", txpl) ;

        Free_PLANARRAY(dstr, 4) ;
        Free_PLANARRAY(disc1, 1) ;
    }

    else if (!strcmp("Disc_DeltaPrep()", txa))
    {
        fprintf(out,"   testing %s\n", txa) ;

        acc = Read_FL64(in, out, "  Tolerance ");

        holi = Read_HOLI_STR(in, out);

        df = Read_DISCFAC(in, out);

        bucket = Read_BUCKETARRAY(in, out, &nloads);

        irr = Read_IRRCONV(in, out, "  Shock Irr Conv ");
        freq = Read_PMTFREQ(in, out, "  Shock Comp. Freq ");
        ins = Read_BOOLE(in, out, "  Ins?   ");

        ds = Disc_DeltaPrep(&df, bucket, nloads, &holi, ins, irr, freq,
          False, False, DF_BOTH);

        IOUtil_ParseLine(in, out);

        diff = Write_PlansDiff(in, out, ds.shock, ds.nshock);

        Free_PLANARRAY(df.disc, 1) ;
        Free_DELTASET(&ds) ;
        Free_HOLI_STR(&holi) ;
        Free_BUCKETARRAY(bucket) ;
    }




    else if (!strcmp("Disc_DF2ForwRate()", txa))
    {
        fprintf(out," ?; testing %s\n", txa) ;
      
        fexp = Read_FL64(in, out, "  Exp. forw rate  ");

        acc = Read_FL64(in, out, "  Tolerance ");

        date = Read_DATESTR(in, out, "  Start date ");
        end = Read_DATESTR(in, out, "  End date   ");

        df = Read_DISCFAC(in, out);

        cal = Read_CALCONV(in, out, "  Forw. Rate Calendar  ");
        irr = Read_IRRCONV(in, out, "  Forw. Rate Irr conv  ");
        freq = Read_PMTFREQ(in, out, "  Forw. Rate Comp. Freq  ");

        IOUtil_ParseLine(in, out);

		fres = Disc_DF2ForwRate(&date, &end, cal, &df, irr, freq, &holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */

        diff = (fabs(fres - fexp) > acc);
        fprintf(out,"%d; result is %8lf ; expected is %8lf\n",
                diff, fres, fexp) ;

        Free_PLANARRAY(df.disc, 1) ;
    }

    else if (!strcmp("Disc_DF2NPV()", txa))
    {
        fscanf(in, "%lf %ld %d %d %s %s %s %s %ld %s",
               &fexp, &ymd, &i1, &i2, txb, txd, txc, txe, &ymd2, txpl) ;
        na = (INTI) i1 ;
        nd = (INTI) i2 ;

        ipol  = Str2DISCIPOL(txb) ;
        iconv = Str2INTPOLCONV(txd) ;
        cal   = Str2CALCONV(txc) ;
        irr   = Str2IRRCONV(txe) ;
        analys = Cldr_YMD2Datestr(ymd) ;
        end    = Cldr_YMD2Datestr(ymd2) ;

        fixdays   = Alloc_DATEARRAY(na) ;
        fixcoupon = Alloc_FL64ARRAY(na) ;
        expcoup   = Alloc_FL64ARRAY(na) ;
        fixamort  = Alloc_FL64ARRAY(na) ;
        disc      = Alloc_PLANARRAY(1, nd) ;

        fprintf(out,"?; testing %s\n", txa) ;
        fprintf(out,"   analysis           %8ld\n", ymd) ;
        fprintf(out,"   ipol in            %8s\n", txb) ;
        fprintf(out,"   intpol             %8s\n", txd) ;
        fprintf(out,"   calendar           %8s\n", txc) ;
        fprintf(out,"   Irr                %8s\n", txe) ;
        fprintf(out,"   Maturity           %8ld\n", ymd2) ;

        fprintf(out,"   the pay schedule is...\n") ;
        fprintf(out,"       date  coupon   repayment\n") ;

        for (i = 0 ; i < na ; i++)
        {
            fscanf(in, "%ld %lf %lf", &ymd, &fixcoupon[i], &fixamort[i]) ;
            fixdays[i] = Cldr_YMD2Datestr(ymd) ;
            fprintf(out,"   %8ld %9.5lf %9.5lf\n",
                    ymd, fixcoupon[i], fixamort[i]) ;
        }
        fprintf(out,"   the discount function is...\n") ;
        fprintf(out,"       date  discount factor\n") ;

        for (i = 0 ; i < nd ; i++)
        {
            fscanf(in, "%ld %lf", &ymd, &disc[0].f64[i]) ;
            disc[0].day[i] = Cldr_YMD2Datestr(ymd) ;
            fprintf(out,"   %8ld %9.5lf\n", ymd, disc[0].f64[i]) ;
        }
        disc[0].count = disc[0].filled = nd ;

        df = Set_DISCFAC(disc, ipol, iconv, cal, irr, ANNUALLY) ;

        fres = Disc_DF2NPV(&analys, fixdays, fixcoupon, fixamort, na, &df,
                           &end, False, expcoup, &holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
        diff = (fabs(fexp - fres) > acc) ;

        fprintf(out, "%d;  expected NPV is %9.5lf  result is %9.5lf\n",
                diff, fexp, fres) ;

        fprintf(out,"   %s\n\n", txpl) ;

        Free_DATEARRAY(fixdays) ;
        Free_FL64ARRAY(fixcoupon) ;
        Free_FL64ARRAY(expcoup) ;
        Free_FL64ARRAY(fixamort) ;
        Free_PLANARRAY(disc, 1) ;
    }

    else if (!strcmp("Disc_Spread2DF()", txa))
    {
        fscanf(in, "%d %s %lf %s", &i2, txc, &spr, txpl) ;
        nd = (INTI) i2 ;
        disc = Alloc_PLANARRAY(3, nd) ;
        disc[0].count = disc[1].count = disc[2].count = nd ;
        disc[0].filled = nd ;
        disc[1].filled = 0 ;
        disc[2].filled = nd ;

        cal = Str2CALCONV(txc) ;

        fprintf(out,"?; testing %s\n", txa) ;
        fprintf(out,"   calendar           %8s\n", txc) ;

        fprintf(out,"   the input discount function is...\n") ;
        fprintf(out,"   Date       Disc.factor\n") ;

        for (i = 0 ; i < nd ; i++)
        {
            fscanf(in, "%ld %lf", &ymd, &disc[0].f64[i]) ;
            disc[0].day[i] = Cldr_YMD2Datestr(ymd) ;
            fprintf(out,"   %8ld %9.5lf\n", ymd, disc[0].f64[i]) ;
        }

        /* Read expected disc */
        for (i = 0 ; i < nd ; i++)
        {
            fscanf(in, "%ld %lf", &ymd, &disc[2].f64[i]) ;
            disc[2].day[i] = Cldr_YMD2Datestr(ymd) ;
        }

        df.disc  = disc ;
        df.cal   = cal ;
        df.irr   = CONTINUOUS ;
        df.freq  = ANNUALLY ;

        dfs = Set_DFSPREAD(spr, COMPOUND, ANNUALLY, NULL) ;
        df1 = Disc_Spread2DF(&df, &dfs, &holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
        disc1 = df1.disc ;

        fprintf(out,"   the results are..\n") ;
        fprintf(out,"   Expected_disc     Actual_disc\n") ;
        diff = 0 ;
        for (i = 0 ; i < nd ; i++)
        {
            dif1 = fabs(disc[2].f64[i] - disc1->f64[i]) > acc ||
                   Cldr_Datestr2YMD(&disc[2].day[i]) !=
                     Cldr_Datestr2YMD(&disc1->day[i]) ;

            diff = diff|| dif1 ;

            fprintf(out, "%d; %ld %lf %ld %lf\n", dif1,
                          Cldr_Datestr2YMD(&disc[2].day[i]),
                          disc[2].f64[i],
                          Cldr_Datestr2YMD(&disc1->day[i]),
                          disc1->f64[i]) ;
        }

        Free_PLANARRAY(disc, 3) ;
        Free_PLANARRAY(disc1, 1) ;
    }

    else if (!strcmp("Disc_Zeros2DF()", txa))
    {
        fprintf(out,"   testing %s\n", txa) ;

        fscanf(in, "%s %ld %d", txpl, &ymd, &i1) ;
        n     = (INTI) i1 ;
        today = Cldr_YMD2Datestr(ymd) ;

        zrates = Alloc_ZRATEARRAY(n) ;

        for (i = 0; i < n; i++)
        {
            ztmp = Read_ZRATE_STR(in, out) ;
            zrates[i].period.num  = ztmp.period.num ;
            zrates[i].period.unit = ztmp.period.unit ;
            zrates[i].rate        = ztmp.rate ;
            zrates[i].irr         = ztmp.irr ;
            zrates[i].freq        = ztmp.freq ;
            zrates[i].cal         = ztmp.cal ;
            zrates[i].bus         = ztmp.bus ;
            zrates[i].eom         = ztmp.eom ;
        }

        holi  = Read_HOLI_STR(in, out) ;
        dfp   = Read_DFPARMS(in, out) ;

        dfexp = Read_PLANARRAY(in) ;

        df   = Disc_Zeros2DF(&today, zrates, n, &holi, &dfp) ;
        diff = 0 ;

        if (GetPlanFill(df.disc) != GetPlanFill(dfexp))
        {
            diff = 1 ;
            fprintf(out, "1; Count mismatch\n") ;
        }
        else
        {
            for (i = 0; i < GetPlanFill(dfexp) ; i++)
            {
                diff = diff || 
                    fabs(dfexp->f64[i] - df.disc->f64[i]) > 0.00001 ||
                       Cldr_Datestr2YMD(&dfexp->day[i]) !=
                       Cldr_Datestr2YMD(&df.disc->day[i]) ;
                fprintf(out, "%d; %ld %lf %ld %lf\n",
                        diff, Cldr_Datestr2YMD(&dfexp->day[i]), 
                        dfexp->f64[i], Cldr_Datestr2YMD(&df.disc->day[i]), 
                        df.disc->f64[i]) ;
            }
        }

        fprintf(out,"   %s\n\n", txpl) ;

        Free_PLANARRAY(df.disc, 1) ;
        Free_PLANARRAY(dfexp, 1) ;
        Free_ZRATEARRAY(zrates) ;
        Free_DATEARRAY(holi.holidays) ;
    }


    return diff ;
}

/* SCID @(#)dateadd.c	1.30 (SimCorp) 99/11/11 10:30:11 */

/************************************************************************
*
*   project     SCecon
*
*   file name   dateadd.c
*
*   general     This file contains standard routines for calendar
*               calculations
*
************************************************************************/

/* includes ************************************************************/
#include <cldr.h>


/*,,SOH,,
*************************************************************************
*
*               Cldr_AddDays()
*
*   interface   #include <cldr.h>
*               DATESTR Cldr_AddDays(DATESTR *datein,
*                                    INTL    ds,
*                                    CALCONV cal) ;
*
*   general     Cldr_AddDays() adds input number of days ds to input
*               date datein, with respect to the calendar convention
*               cal.
*
*               This routine works as the inverse of the routine
*               Cldr_DaysBetweenDates().
*
*               This means, that not all combinations of datein, ds
*               and cal are meaningful.
*               Thus adding 1 day to february 28, 1989 using EU30360
*               gives no meaning, since the number of days between
*               february 28 and march 1 using EU30360 is 3.
*
*               However to avoid the need for complex input checking
*               Cldr_AddDays() finds the first calender date after the
*               last date that has a number of days from datein,
*               calculated with respect to the calender convention in
*               question, that is less than ds.
*
*               Thus 1 day added to february 28, 1989 using EU30360
*               yields march 1, 1989, and -1 day added to march 1, 1989
*               yields february 28, 1989 using EU30360.
*
*   input       DATESTR *datein  Pointer to the input date.
*
*               INTL    ds       The number of days.
*
*               CALCONV cal      The calendar convention.
*
*	       	    HOLI_STR *holi	 Container for list of holidays.
*
*   output
*
*   returns     the input date plus ds days as a DATESTR.
*
*   diagnostics
*
*   see also    Cldr_AddBusinessdays()
*               Cldr_AddMonths()
*               Cldr_DaysBetweenDates()
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/


DATESTR Cldr_AddDays(DATESTR* datein,
                     INTL      ds,
                     CALCONV   cal,
					 HOLI_STR*  holi)
{
    DATESTR tmp, dateout, date1, date2 ;
    INTL    max1, decr, add, dplus;
    INTI    dd, years ;

    tmp = dateout = *datein ;
    if (ds == (INTL) 0)
        return dateout ;

    if (cal == ACTACT || cal == ACT360 || cal == ACT365 || cal == ACTLEAP ||
        cal == ACTAFB || cal == ACTEUROBOND || cal == ACTFRF)
        dateout = Cldr_Julian2Date(Cldr_Date2Julian(datein) + ds) ;

    else if (cal == ACTNL365)
    {
        years = (INTI) (ds / 365) ;
        dplus = ds - (INTL) (years * 365) ;

        /* Now calculate */
        tmp.y  += years ;
        dateout = Cldr_Julian2Date(Cldr_Date2Julian(&tmp) + dplus) ;
        dd      = Cldr_29FebCount(&tmp, &dateout) ;
        if (dateout.m == 2 && dateout.d == 29)
            dd += 1 ;
        if (dd > 0)
            dateout = Cldr_Julian2Date(Cldr_Date2Julian(&dateout) + dd) ;
    }

	/* PMSTA-22396 - SRIDHARA � 160502 */
	else if (cal == BUS252)
	{
		dateout = Cldr_AddNextBusinessdays(datein, ds, holi);
	}


    else if (cal == EU30360  || cal == US30360 || cal == EU30EP360 ||
             cal == EU30E360 || cal == US30E360 || cal == EU30E365)
    {
        add  = ds + (INTL) datein->d ;
        max1 = (INTL) (datein->m == 2 ? 28 : 30) ;

        /* Distinguish between various cases. */

        /* 1. Here we add/subtract a number of days within a month */
        if (add > (INTL) 0 && add <= max1 && datein->d != 31)
        {
            dateout   = *datein ;
            dateout.d = datein->d + (INTI) ds ;
        }

        /* 2. This is also easy */
        else if (ds == (INTL) 30 && datein->d != 31 && datein->d != 1)
            dateout = Cldr_AddMonths(&dateout, 1, SAME) ;

        /* 3. This is also easy */
        else if (ds == (INTL) - 30 && datein->d != 31)
            dateout = Cldr_AddMonths(&dateout, - 1, SAME) ;

        /* 4. This is more delicate - here we use Cldr_DaysBetweenDates() to
              enforce the inverse relation as described above.
              The method consists of iterating between upper/lower bounds on the
              resulting date - until the difference is as desired. To speed
              up the calculations we use a bisection algorithm. We do not
              bisect the entire way since the 'function' is discontinuous as
              discussed above. Instead we bisect until the upper/lower are
              not more than 2 days apart. */
        else
        {
            decr = (INTL) -1 ;

            /* date2 is the upper datebound and date1 is the lower */

            if (ds >= (INTL) 0)
            {
                dplus = ((INTL) 7) + ((INTL) 7) * ds/(INTL) 360;
                date2 = Cldr_Julian2Date(Cldr_Date2Julian(datein) + ds + dplus);
                date1 = Cldr_Julian2Date(Cldr_Date2Julian(datein) + ds + decr) ;
            }
            else
            {
                dplus = ((INTL) - 7) + ((INTL) 7) * ds/(INTL) 360;
                date2 = Cldr_Julian2Date(Cldr_Date2Julian(datein) +
                                                                ds + (INTL) 2);
                date1 = Cldr_Julian2Date(Cldr_Date2Julian(datein) + ds + dplus);
            }

            dateout = date2 ;
            add     = Cldr_DaysBetweenDates(&date1, &date2, ACTACT, NULL) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */

            while (add > (INTL) 3)
            {
                dateout = date2 ;
                tmp     = Cldr_AddDays(&date1, add >> 1, ACTACT, NULL) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
                if (Cldr_DaysBetweenDates(datein, &tmp, cal, holi) < ds)
                    date1 = tmp ;
                else
                    date2 = tmp ;

                add = Cldr_DaysBetweenDates(&date1, &date2, ACTACT, NULL) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
            }

            /* Finally iterate the last few days */
            if (ds > (INTL) 0)
            {
                while (Cldr_DaysBetweenDates(datein, &date2, cal, holi) >= ds)
                {
                    dateout = date2;
                    date2   = Cldr_AddDays(&date2, decr, ACTACT, NULL) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
                }
            }
            else
            {
                while (Cldr_DaysBetweenDates(datein, &date1, cal, holi) <= ds)
                {
                    dateout = date1;
                    date1   = Cldr_AddDays(&date1, - decr, ACTACT, NULL) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
                }
            }
        }

        if ((cal == EU30E365 || cal == EU30E360 || cal == US30E360) &&
            dateout.d == 31)
            dateout.d = 30 ;

        if (cal == EU30EP360 && dateout.d == 31)
        {
            if (ds > (INTL) 0)
                dateout = Cldr_AddDays(&dateout, (INTL) 1, ACTACT, NULL) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
            else
                dateout.d = 30 ;
        }
    }

    return dateout ;
}


/*,,SOH,,
*************************************************************************
*
*                Cldr_DaysBetweenDates()
*
*    interface   #include <cldr.h>
*                INTL Cldr_DaysBetweenDates(DATESTR *datein1,
*                                           DATESTR *datein2,
*                                           CALCONV cal) ;
*
*    general     Cldr_DaysBetweenDates() calculates the number of
*                days between the two input dates with respect to
*                the calendar convention, cal.
*
*    input       DATESTR  *datein1    Start date.
*
*                DATESTR  *datein2    End date.
*
*                CALCONV   cal        The calendar convention.
*
*	       		 HOLI_STR  *holi	  Container for list of holidays.
*
*    output
*
*    returns     the number of days as INTL.
*
*    diagnostics
*
*    see also    Cldr_AddDays()
*                Cldr_AddMonths()
*                Cldr_TermBetweenDates()
*
*    wrapper     AP
*
*************************************************************************
,,EOH,,*/


INTL Cldr_DaysBetweenDates(DATESTR* datein1,
                           DATESTR*  datein2,
                           CALCONV   cal,
						   HOLI_STR *holi)
{
    INTI    thirty ;
    INTL    tmp ;
    DATESTR dtmp, date2, date1 ;
    BOOLE   sgn ;

    thirty = 30 ;
    date1  = *datein1 ;
    date2  = *datein2 ;
    sgn    = False ;

    switch (cal)
    {
        case ACTACT  :
        case ACT365  :
        case ACT360  :
        case ACTLEAP :
        case ACTAFB  :
        case ACTEUROBOND :
        case ACTFRF  :

            return (INTL) (Cldr_Date2Julian(datein2) -
                           Cldr_Date2Julian(datein1)) ;
        case ACTNL365 :

            tmp  = Cldr_Date2Julian(datein2) - Cldr_Date2Julian(datein1) ;
            if (Cldr_DateLT(datein1, datein2) == True)
                tmp -= (INTL) Cldr_29FebCount(datein1, datein2) ;
            else
                tmp += (INTL) Cldr_29FebCount(datein1, datein2) ;
            return tmp ;

        case US30E360 :
        case EU30E360 :
        case EU30E365 :

            date1.d = GETMIN(thirty, date1.d) ;
            date2.d = GETMIN(thirty, date2.d) ;
            break ;

        case EU30EP360 :

            if (Cldr_DateLT(&date2, &date1) == True)
            {
                sgn   = True ;
                dtmp  = date1 ;
                date1 = date2 ;
                date2 = dtmp ;
            }

            date1.d = GETMIN(thirty, date1.d) ;
            
            if (date2.d == 31)
                date2 = Cldr_AddDays(&date2, (INTL) 1, ACTACT, NULL) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */

            break ;

        case EU30360 :
        case US30360 :

            if (Cldr_DateLT(&date2, &date1) == True)
            {
                sgn   = True ;
                dtmp  = date1 ;
                date1 = date2 ;
                date2 = dtmp ;
            }

            date1.d = GETMIN(thirty, date1.d) ;
            if (date1.d == thirty && date2.d > thirty)
                date2.d = thirty ;

            break ;
			/* PMSTA-22396 - SRIDHARA � 160502 */
		case BUS252:
            /* PMSTA-31096 - DDV - 180423 - Check that holi is not null to avoid crash */
            if (holi != NULL)
            {
			    return(Cldr_BusDaysBetweenDates(datein1, datein2, holi));
            }
            else
            {
                return((INTL) (Cldr_Date2Julian(datein2) -
                                Cldr_Date2Julian(datein1))) ;
            }
	
    }

    tmp  = ((INTL) 360) * (INTL) (date2.y - date1.y) ;
    tmp += (INTL) (thirty * (date2.m - date1.m)) ;
    tmp += (INTL) (date2.d - date1.d) ;
    if (sgn == True)
        tmp *= (INTL) -1 ;

    return tmp ;
}


/*,,SOH,,
*************************************************************************
*
*                Cldr_AddMonths()
*
*    interface   #include <cldr.h>
*                DATESTR Cldr_AddMonths(DATESTR *datein,
*                                       INTI    ms,
*                                       EOMCONV eom) ;
*
*    general     Cldr_AddMonths() calculates the date, dateout, ms
*                months after the date, datein, with respect to the
*                end of month convention, eom.
*
*    input       DATESTR *datein    Pointer to the input date.
*
*                INTI     ms        The number of months.
*
*                EOMCONV  eom       The end of month convention.
*
*    output
*
*    returns     the date ms months after the input date as DATESTR.
*
*    diagnostics
*
*    see also    Cldr_AddDays(),
*                Cldr_DaysBetweenDates(),
*                Cldr_TermBetweenDates()
*
*    wrapper     AP
*
*************************************************************************
,,EOH,,*/


DATESTR Cldr_AddMonths(DATESTR* datein,
                       INTI     ms,
                       EOMCONV  eom)
{
    DATESTR dateout ;
    INTI    dlast ;

    if (ms == 0)
        return *datein ;

    dateout.y = (datein->y) + ms / 12 ;
    dateout.m = datein->m + ms - 12 * (dateout.y - datein->y) ;
    dateout.d = datein->d ;

    if (dateout.m > 12)
    {
        dateout.m -= 12 ;
        ++dateout.y ;
    }

    else if (dateout.m < 1)
    {
        dateout.m += 12 ;
        --dateout.y ;
    }

    dlast = Cldr_LastDayInMonth(dateout.y, dateout.m) ;

    if (dateout.d > dlast)
        dateout.d = dlast ;

    switch (eom)
    {
        case SAME:
            if (datein->d == Cldr_LastDayInMonth(datein->y, datein->m))
                dateout.d = (datein->d > dlast ? dlast : datein->d) ;
            break ;

        case LAST:
            if (datein->d == Cldr_LastDayInMonth(datein->y, datein->m))
                dateout.d = dlast ;
            break ;

        case LAST360:
            if (dateout.d == 31)
                dateout.d = 30 ;
            if (datein->m == 2 && datein->d >= 28)
                dateout.d = 30 ;
            if (dateout.m == 2 && dateout.d > 28)
                dateout.d = 28 ;
            break ;
    }

    return dateout ;
}


/*,,SOH,,
*************************************************************************
*
*                Cldr_NextWeekday()
*
*    interface   #include <cldr.h>
*                DATESTR Cldr_NextWeekday(DATESTR *datein,
*                                         INTI    w) ;
*
*    general     Calculates the first day after the input day, that
*                has a week day number of w.
*
*    input       DATESTR  *datein   Pointer to the input date
*
*                INTI     w         Weekday number, 1 being monday.
*
*    output
*
*    returns     the first day after datein, that has the weekday
*                number w as DATESTR.
*
*    diagnostics
*
*    see also    Cldr_Weekday()
*
*************************************************************************
,,EOH,,*/


DATESTR Cldr_NextWeekday(DATESTR* datein,
                         INTI    w)
{
    INTI   wd;
    DATESTR dateout ;

    wd      = Cldr_Weekday(datein);
    dateout = Cldr_Julian2Date(Cldr_Date2Julian(datein) +
                                      ((INTL) ((w - wd) + 7 * (w < wd))));
    return dateout ;
}


/*
*************************************************************************
*
*                Cldr_Genr_Dates_Count()
*
*    interface   #include <cldr.h>
*
*                INTI Cldr_Genr_Dates_Count(DATESTR *d1,
*                                               DATESTR *d2,
*                                               INTI    add,
*                                               CALCONV cal) ;
*
*    general     Cldr_Genr_Dates_Count() counts the number of dates
*                in the period from date1 to date2 with an interval of
*                add. Date1 is included in the count.
*                It is not checked whether the days generated are
*                business days or holidays.
*                After calling this function the dates can be generated
*                with Cldr_Genr_Dates().
*
*    input       DATESTR *d1     Pointer to first input date.
*
*                DATESTR *d2     Pointer to second input date. Not
*                                earlier than date1.
*
*                INTI    add     The interval in days between the
*                                dates to be put in the period.
*                                Must be a positive number.
*
*                CALCONV cal     The calendar convention.
*
*	       		HOLI_STR *holi	 Container for list of holidays.
*
*    output
*
*    returns     The number of dates found in the period as INTI.
*
*    diagnostics
*
*    see also    Cldr_Genr_Dates()
*
*************************************************************************
*/


INTI Cldr_Genr_Dates_Count(DATESTR* d1,
                               DATESTR*  d2,
                               INTI     add,
                               CALCONV  cal,
							   HOLI_STR* holi)
{
    DATESTR day, date1, date2 ;
    INTI   ix ;
    BOOLE   found ;

    date1 = *d1 ;
    date2 = *d2 ;

    ix = 1 ;
    day = date1 ;
    found = (Cldr_DateEQ(&date1, &date2) == True ? True : False) ;

    while (found == False)
    {
        ix++ ;
        day = Cldr_AddDays(&day, (INTL) add, cal, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
        if (Cldr_DateLT(&day, &date2) == False)
            found = True ;
    }
    return ix ;
}


/*
*************************************************************************
*
*                Cldr_Genr_Dates()
*
*    interface   #include <cldr.h>
*                INTI Cldr_Genr_Dates(DATESTR   *d1,
*                                         DATESTR   *d2,
*                                         INTI      add,
*                                         CALCONV   cal,
*                                         DATEARRAY dates,
*                                         ALIGNCONV align) ;
*
*    general     Cldr_Genr_Dates() generates an array of dates
*                in the period from date1 to date2 with an interval
*                between the dates of add days.
*
*                The dates will always be organised in an ascending
*                order.
*
*                The function is useful when a list of dates are to be
*                generated, eg. all fixed date holidays in a period,
*                say 5'th of june from 1991 till 2030).
*                Also the routine is useful for generating time grids,
*                eg. for analysis of the wildcard option in a Gilt
*                future, say weekly spacing in the delivery month.
*
*                It is not checked whether the days generated are
*                business days or holidays, so you should adjust for
*                this else where.
*
*                The align parameter is used when add does not exactly
*                fit the period specified between date1 and date2.
*                In these cases align is used to decide how to align.
*                Note that when using CENTER as align the choice is
*                not unique. However we have chosen a solution where
*                the number of dates is always the same independent of
*                the alignment method.
*
*    input       DATESTR    *d1     Pointer to first input date.
*
*                DATESTR    *d2     Pointer to second input date. Not
*                                   earlier than date1.
*
*                INTI       add     The interval between the dates to
*                                   be put in the period.
*                                   Must be a positive number.
*
*                CALCONV    cal     The calendar convention.
*
*                ALIGNCONV  align   The alignment convention.
*
*	       	     HOLI_STR   *holi	Container for list of holidays.
*
*    output      DATEARRAY  dates   The days in the period as filled by
*                                   the function.
*                                   Must be prellocated using the
*                                   routine Alloc_DATEARRAY()().
*                                   See Cldr_Genr_Dates_Count() for
*                                   details on the minimal size of dates*
*
*    returns     The number of elements in dates as INTI.
*
*    diagnostics
*
*    see also    Cldr_Genr_Dates_Count()
*
*************************************************************************
*/


INTI Cldr_Genr_Dates(DATESTR* d1,
                         DATESTR*   d2,
                         INTI     add,
                         CALCONV   cal,
                         DATEARRAY dates,
                         ALIGNCONV align,
						 HOLI_STR* holi)
{
    BOOLE   found ;
    INTI   ix, j, up ;
    INTL   diff ;
    DATESTR date1, date2, day ;

    /* warning avoidance */
    ix = 0 ;

    date1 = *d1 ;
    date2 = *d2 ;

    found = (Cldr_DateEQ(&date1, &date2) == True ? True : False) ;

    switch (align)
    {
        case LEFT:
        case CENTER:

            ix = 0 ;
            dates[0] = day = date1 ;

            while (found == False)
            {
                ix++ ;
                day = Cldr_AddDays(&day, (INTL) add, cal, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
                if (Cldr_DateLE(&day, &date2) == True)
                    dates[ix] = day ;
                else
                    dates[ix] = date2 ;

                if (Cldr_DateEQ(&dates[ix], &date2) == True)
                    found = True ;
            }
            if (align == CENTER && ix >= 1)
            {
                diff  = Cldr_DaysBetweenDates(&dates[ix - 1], &dates[ix], cal, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
                diff += Cldr_DaysBetweenDates(&dates[0], &dates[1], cal, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
                diff /= (INTL) 2 ;
                diff -= (INTL) add ;
                up    = ix - 1 ;
                if (up != 0)
                {
                    for (j = 1 ; j <= up ; j++)
                        dates[j] = Cldr_AddDays(&dates[j], (INTL) diff, cal, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
                }
            }
            break ;

        case RIGHT:

            day   = date1 ;
            date1 = date2 ;
            date2 = day ;
            add   = - add ;

            ix = 0 ;
            dates[0] = day = date1 ;

            while (found == False)
            {
                ix++ ;
                day = Cldr_AddDays(&day, (INTL) add, cal, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
                if (Cldr_DateLT(&day, &date2) == False)
                    dates[ix] = day ;
                else
                    dates[ix] = date2 ;

                if (Cldr_DateEQ(&dates[ix], &date2) == True)
                    found = True ;
            }

            up = ix/2 ;
            for (j = 0 ; j <= up ; j++)
            {
                day = dates[j] ;
                dates[j] = dates[ix - j] ;
                dates[ix - j] = day ;
            }
            break ;
    }

    return ix + 1 ;
}


/*,,SOH,,
*************************************************************************
*
*                Cldr_DaysPerYear()
*
*    interface   #include <cldr.h>
*                FL64 Cldr_DaysPerYear(DATESTR *date,
*                                      DATESTR *end,
*                                      INTI    m,
*                                      CALCONV cal,
*                                      EOMCONV eom) ;
*
*    general     The function calculates the number of days per year
*                according to the given calendar convention. For the 
*                definitions of the number of days per year, please see 
*                CALCONV.
*
*                The result of the function should be used as the
*                denominator in the day count fraction when calculating
*                accrued interest and coupons. The numerator may be
*                calculated using Cldr_DaysBetweenDays().
*
*                This method also applies when computing coupons according 
*                to the standard ISMA convention (using EVENCOUP as 
*                COUPONBASE). In this case one enters the number of months m
*                in a regular period and the function returns 12/m times
*                the number of days in the period. So the number of days
*                per year inherent in the calendar convention is not used in
*                in this case.
*
*                When computing standard day count fractions (using e.g. 
*                ODDCOUP as COUPONBASE) one sets m equal to zero and the
*                function returns the number of days per year given by 
*                the calendar convention.
*
*                A comment on the result when using ACTLEAP is needed.
*                Here a day count fraction may actually be the sum of two
*                day fractions: One for a leap year and one for a
*                non-leap year. In this case, the value returned is the 
*                implied denominator so that the day fraction can be computed 
*                the usual way as days in the period divided by days per year.
*
*                Consider the following example using ACTLEAP :
*
*                       81 days in 1991 and 22 days in 1992
*
*                This gives the day count fraction:
*
*                       81/365 + 22/366 = 0.2820271
*
*                This function returns 365.213133, such that the standard
*                day count fraction
*
*                       (81 + 22)/365.213133 = 0.2820271
*
*                gives the same result.
*                Accrued interest is calculated as the actual coupon payment
*                times the fraction of accrual days over the coupon period
*                days. The accrued interest is therefore calculated as the
*                annual coupon times number of accrual days divided by
*                number of days per year as computed by this function.
*
*                A similar comment applies for ACTAFB in periods longer than
*                one year. Here the day count fraction is the sum of at least 
*                two day count fractions. In this case, the value returned is 
*                the implied denominator so that the day fraction can be 
*                computed the usual way as days in the period divided by days 
*                per year.
*
*                Consider the following example using ACTAFB: Effective day
*                is 1 January 2000 with coupon payment 1 July 2001. The period
*                is split into a 182 day period from 1 January 2000 to 1 July
*                2000 and a 365 day period from 1 July 2000 to 1 July 2001.
*                The day count fraction becomes:
*
*                        182/366 + 365/365 = 1.497268
*
*                The function returns 365.3321167 such that
*
*                         (182 + 365)/365.3321167 = 1.497268
*             
*                gives the same result.
*                Accrued interest is calculated as for ACTLEAP.
*
*                The above procedures are only used when m is 0, otherwise
*                the above mentioned procedure is used.
*
*
*    input       DATESTR  *date         Pointer to the start period date.
*
*                DATESTR  *end          Pointer to the end period date.
*                                       This is needed for non-zero
*                                       m and calendar conventions ACTAFB,
*                                       ACTEUROBOND, ACTFRF, ACTLEAP.
*
*                INTI      m            The number of months in a regular 
*                                       period.
*                                       If 0 then the number of days per year
*                                       inherent in cal is returned.
*                                       If non-zero then the number of days 
*                                       in the period times 12/m is returned.
*
*                CALCONV   cal          The calendar convention.
*
*                EOMCONV   eom          The end of month convention.
*
*	       	     HOLI_STR  *holi	    Container for list of holidays.
*
*    output
*
*    returns     The number of days per year according to the calendar
*                convention.
*
*    diagnostics
*
*    see also    Cldr_DaysBetweenDates()
*                Cldr_TermBetweenDates()
*                Cflw_MonthsBetweenPayments()
*
*    wrapper     AP
*
*************************************************************************
,,EOH,,*/


FL64 Cldr_DaysPerYear(DATESTR* date,
                      DATESTR* end,
                      INTI     m,
                      CALCONV  cal,
                      EOMCONV  eom,
					  HOLI_STR* holi)
{
    DATESTR dnext, dprev ;
    FL64    p, d, sumd, y ;

    /* warning avoidance */
    p = 0.0 ;

    if (m == 0)
    {
          /* 365-days conventions. */
        if (cal == ACT365 || cal == EU30E365 || cal == ACTNL365)

            p = 365.0 ;

          /* Original SCecon actual-actual convention. */
        else if (cal == ACTACT)
        {
            dnext = Cldr_AddMonths(date, 12, eom) ;
            p     = (FL64) Cldr_DaysBetweenDates(date, &dnext, cal, NULL);  	/* PMSTA-22396 - SRIDHARA � 160502 */
        }

		/* 252 days convention */  	/* PMSTA-22396 - SRIDHARA � 160502 */
		else if (cal == BUS252)
		{
			p = 252.0;
		}

          /* AFB convention. */
        else if (cal == ACTAFB)
        {
            /* Split period into sub-periods of length one year - counting
               backwards - plus an initial stub period.
               dprev, dnext are the start and end date of next subperiod.
               For each subperiod, compute number of days, d, and number
               of days in the year, y. Accumulate days in sumd and
               day count fractions in p. The result is then sumd/p. */
            sumd = p = 0 ;
            dnext = *end ;

            /* Loop over sub-periods. */
            while (Cldr_DateLT(date, &dnext))
            {
                /* Find next sub-period. */
                dprev = dnext ;
                dnext = Cldr_AddMonths(&dprev, -12, eom) ;
                if (Cldr_DateLT(&dnext, date))
                {
                    dnext = *date ;
                    d     = Cldr_DaysBetweenDates(&dnext, &dprev, cal, NULL) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
                    y     = (Cldr_29FebCount(&dnext, &dprev) > 0 ? 
                            366.0 : 365.0) ;
                }
                else
                    y = d = Cldr_DaysBetweenDates(&dnext, &dprev, cal, NULL) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */

                /* Accumlate days and day fractions. */
                sumd += d ;
                p    += d / y ;
            }

            p = SafeDivide(sumd, p, 0.001, 365.0) ;
        }
          /* Eurobond convention. */
        else if (cal == ACTEUROBOND)
        {
          dnext = Cldr_AddMonths(date, 12, eom) ;
          if (Cldr_DateEQ(end, &dnext))
              p = (Cldr_29FebCount(date, end) > 0 ? 366.0 : 365.0) ;
          else
              p = (Cldr_IsLeap(end->y) ? 366.0 : 365.0) ;
        }
          /* French convention. */
        else if (cal == ACTFRF)
        {
            dnext = Cldr_AddMonths(end, -12, eom) ;
            p     = (FL64) Cldr_DaysBetweenDates(&dnext, end, cal, NULL) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
        }
          /* ISDA convention. */
        else if (cal == ACTLEAP)
        {
            /* Split period into sub-periods within same year.
               dprev, dnext are the start and end date of next subperiod.
               For each subperiod, compute number of days, d, and number
               of days in the year, y. Accumulate days in sumd and
               day count fractions in p. The result is then sumd/p.
               
               Note, that periods are calculated from, and including, the
               start date to, but excluding, the end date. Therefore the
               intermediate new year day should be Janauary 1. */
            sumd = p = 0 ;
            dnext = *date ;

            /* Loop over sub-periods. */
            while (Cldr_DateLT(&dnext, end))
            {
                /* Find next sub-period. */
                dprev = dnext ;
                if (dprev.y == end->y)
                    dnext = *end ;
                else
                {
                    dnext.y = dnext.y + 1 ;
                    dnext.m = 1 ;
                    dnext.d = 1 ;
                }

                /* Compute period days and year days. */
                d     = Cldr_DaysBetweenDates(&dprev, &dnext, cal, NULL) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
                y     = (Cldr_IsLeap(dprev.y) ? 366.0 : 365.0) ;
                  
                /* Accumlate days and day fractions. */
                sumd += d ;
                p    += d / y ;
            }

            p = SafeDivide(sumd, p, 0.001, 
              (Cldr_IsLeap(end->y) ? 366.0 : 365.0)) ;
        }
          /* 360-days conventions. */
        else
            p = 360.0 ;
    }
      /* EVENCOUP version. */
    else
    {
        p     = (FL64) Cldr_DaysBetweenDates(date, end, cal, holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */
        p    *= ((FL64) 12) / (FL64) m ;
    }

    return p;
}


/*,,SOH,,
*************************************************************************
*
*                Cldr_TermUnit2Date()
*
*    interface   #include <cldr.h>
*                DATESTR Cldr_TermUnit2Date(DATESTR  *today,
*                                           INTI     term,
*                                           TERMUNIT unit,
*                                           CALCONV  cal,
*                                           EOMCONV  eom,
*                                           HOLI_STR *holi) ;
*
*    general     The function calculates the maturity of a money market
*                contract using the number of termunits.
*
*                We do not adjust for businessdays here, so account for
*                that elsewhere.
*
*    input       DATESTR   *today       Pointer to the start date.
*
*                INTI      term         The number of termunits.
*
*                TERMUNIT  unit         The unit of terms.
*
*                CALCONV   cal          The calendar convention.
*
*                EOMCONV   eom          The end of month convention.
*
*                HOLI_STR  *holi        Holiday info
*
*    output
*
*    returns     the maturity date of the contract.
*
*    diagnostics
*
*    see also    
*
*    wrapper     AP
*
*************************************************************************
,,EOH,,*/


DATESTR Cldr_TermUnit2Date(DATESTR* today,
                               INTI      term,
                               TERMUNIT  unit,
                               CALCONV   cal,
                               EOMCONV   eom,
                               HOLI_STR*  holi)
{
    DATESTR d_end ;

    /* warning avoidance */
    memset(&d_end, 0, sizeof(d_end));

    switch (unit)
    {
        case DAYS :
            d_end = Cldr_AddDays(today, (INTL) term, cal, holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */
            break ;

        case BUSDAYS :
            d_end = Cldr_AddBusinessdays(today, (INTL) term, holi->nholi,
                                         holi->holidays) ;
            break ;

        case WEEKS :
            d_end = Cldr_AddDays(today, (INTL) (7*term), cal, holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */
            break ;

        case MONTHS :
            d_end = Cldr_AddMonths(today, term, eom) ;
            break ;

        case YEARS :
            d_end = Cldr_AddMonths(today, 12 * term, eom) ;
            break ;
    }

    return d_end ;
}


/*
..
*/


DATEARRAY Cldr_Step2Dates(STEPARRAY step,
                          INTI      nstep,
                          DATESTR*   today,
                          INTI*      ndays,
                          CALCONV   cal,
                          EOMCONV   eom,
                          BOOLE     incl_today)
{
    INTI     i, j, k, max_ndays ;
    DATESTR  trial_date, last_day, *out_days, *days;
    HOLI_STR holi ;

    holi.nholi = 0 ;
    holi.bus   = NO_BUSADJUST ;

    /* First, we have to compute the maximal number of days in the
       resulting array */
    for ( max_ndays = i = 0; i < nstep; i++)
        max_ndays += step[i].nstep + 1;

    days     = Alloc_DATEARRAY( ++max_ndays );
    last_day = days[0] = *today;

    for (k = i = 0; i < nstep; i++)
    {
        trial_date = *today;
        while (Cldr_DateLT(&trial_date, &last_day) == True)
            trial_date = Cldr_TermUnit2Date(&trial_date, step[i].dur,
                                            step[i].unit, cal, eom, &holi);

        if (Cldr_DateEQ(&last_day, &trial_date) == False)
            k++;

        days[k] = trial_date;
        for (j = 0; j < step[i].nstep; j++)
        {
            k++ ;
            days[k] = Cldr_TermUnit2Date(&days[k-1], step[i].dur,
                                         step[i].unit, cal, eom, &holi);
        }

        last_day = days[k] ;
    }

    /* At this point we need to know which dates to return  */
    if (incl_today == True)
    {
         *ndays = k + 1;
         out_days = Alloc_DATEARRAY(*ndays) ;  /* Array including 'today'  */
         for ( i = 0; i < *ndays; i++)
            out_days[i] = days[i] ;

         Free_DATEARRAY(days) ;
         return(out_days) ;
    }

    *ndays   = k ;
    out_days = Alloc_DATEARRAY(*ndays) ;  /* Array excluding 'today'  */
    for (i = 0; i < *ndays; i++)
        out_days[i] = days[i + 1] ;

    Free_DATEARRAY(days);

    return out_days ;
}



/*
   This function generates dates matching the discretisation defined
   in 'steps'. Dates corresponding to a single entry in 'steps'
   will be evenly distanced.

   Ex: An entry in 'steps' of {3, YEARS, 4} will generate 
       4 evenly distanced dates per year for 3 years, ie 12 evenly
       distanced dates spanning a period of 3 years starting on 'today'

  The output array is allocated to contain '*ndates' entries, the first
  of which will always be 'today'.

  The construction of the dates will stop early is the date 'lastm'
  has been reached (or passed). This ensures that dates are generated
  to span between 'today' and 'lastm' without extending further on.
*/

DATEARRAY Cldr_Steps2Dates(STEPARRAY  steps,
                           INTI       nstep,
                           DATESTR*   today,
                           DATESTR*   lastm,
                           CALCONV    cal,
                           INTI*      ndates,
						   HOLI_STR*  holi)
{
  DATEARRAY dates;
  INTI      i, n, j, nstept;
  DATESTR   dtmp1, dtmp2;
  FL64      t0, t1, dt;
  BOOLE     early_stop;

  early_stop = False;
  t0 = 0.0;
  dtmp2 = dtmp1 = *today;
  for (n = 1, i = 0; i < nstep; i++)
  {
    dtmp2 = Cldr_Term2Date(&dtmp1, (FL64) steps[i].dur - t0, steps[i].unit,
                           cal, LAST);
    
    t1 = Cldr_TermBetweenDates(&dtmp1, &dtmp2, 0, cal, LAST, holi) + t0;   /* PMSTA-22396 - SRIDHARA � 160502 */

    n += (INTI) ceil((t1 - t0) * (FL64) steps[i].nstep) + 1;

    dtmp1 = dtmp2;
    t0 = t1;
  }

  dates = Alloc_DATEARRAY(n);

  t0 = 0.0;
  dates[0] = dtmp2 = dtmp1 = *today;
  for (n = 0, i = 0; i < nstep && !early_stop; i++)
  {
    dtmp1 = dates[n];
    dtmp2 = Cldr_Term2Date(&dtmp1, (FL64) steps[i].dur - t0, steps[i].unit,
                           cal, LAST);
    t1 = Cldr_TermBetweenDates(&dtmp1, &dtmp2, 0, cal, LAST, holi) + t0;  /* PMSTA-22396 - SRIDHARA � 160502 */
    nstept = (INTI) ceil((t1 - t0) * (FL64) steps[i].nstep);
    dt = GETMIN(t1 - t0, 1 / (FL64) steps[i].nstep);

    /* Append dates spaced by 'dt' years */
    for (j = 0; j < nstept - 1 && !early_stop; j++, dtmp1 = dates[n])
    {
      dates[++n] = Cldr_Term2Date(&dtmp1, dt, YEARS, cal, LAST);
      early_stop = (lastm != NULL && Cldr_DateLE(lastm, &dates[n]));
    }
    if (early_stop)
      break;

    /* Final step for this stepsize must match stepsize duration
       exactly: */
    dates[++n] = dtmp2;

    dtmp1 = dtmp2;
    t0 = t1;

    if (lastm != NULL && Cldr_DateLE(lastm, &dates[n]))
      break;
  }
  
  *ndates = n + 1;

  return dates;
}



/*,,SOH,,
*************************************************************************
*
*                Cldr_29FebCount()
*
*    interface   #include <cldr.h>
*                INTI Cldr_29FebCount(DATESTR *date1,
*                                      DATESTR *date2) ;
*
*    general     The function calculates the number of 29/feb's from,
*                and including, the start date to, but excluding, the
*                end date.
*
*    input       DATESTR  *date1      Pointer to the start date.
*
*                DATESTR  *date2      Pointer to the end  date.
*
*    output
*
*    returns     the number of 29/febs
*
*    diagnostics
*
*    see also    Cldr_AddDays()
*                Cldr_TermBetweenDates()
*
*************************************************************************
,,EOH,,*/


INTI Cldr_29FebCount(DATESTR* date1, DATESTR* date2)
{
    DATESTR first, last, tmp, feb29 ;
    INTI    count ;

    if (Cldr_DateLT(date1, date2) == True)
    {
        first = *date1 ;
        last  = *date2 ;
    }
    else
    {
        first = *date2 ;
        last  = *date1 ;
    }

    if (Cldr_IsLeap(first.y) == False)
    {
        first.y += 1 ;
        first.m  = 1 ;
        first.d  = 1 ;
    }

    count = 0 ;
    tmp   = first ;
    feb29.y = first.y ;
    feb29.m = 2 ;
    feb29.d = 29 ;

    if (Cldr_IsLeap(first.y) == True && Cldr_DateLE(&first, &feb29) == True &&
        Cldr_DateLT(&feb29, &last) == True)
    {
        if (Cldr_DateLT(&first, &last) == True)
            count = 1 ;
    }

    tmp = Cldr_AddMonths(&tmp, 12, LAST) ;

    while (Cldr_DateLT(&tmp, &last) == True)
    {
        if (Cldr_IsLeap(tmp.y) == True)
            count++ ;

        tmp = Cldr_AddMonths(&tmp, 12, LAST) ;
    }

    return count ;
}


/*,,SOH,,
*************************************************************************
*
*                Cldr_DaysBetweenDatesArray()
*
*    interface   #include <cldr.h>
*                INTLARRAY Cldr_DaysBetweenDatesArray(DATESTR   *d1,
*                                                      DATEARRAY d2,
*                                                      INTI      n,
*                                                      CALCONV   cal) ;
*
*    general     The function calculates the number of
*                days between the two input dates with respect to
*                the calendar convention, cal.
*
*    input       DATESTR    *d1       Pointer to the start date.
*
*                DATEARRAY  d2        List of end dates
*                                     Dimension [n]
*
*                INTI       n         # of dates in d2.
*
*                CALCONV    cal       The calendar convention.
*
*	       	     HOLI_STR   *holi	  Container for list of holidays.
*
*    output
*
*    returns     List of days - allocated in the routine as:
*
*                        Alloc_INTLARRAY(n)
*
*    diagnostics
*
*    see also    Cldr_AddDays()
*                Cldr_AddMonths()
*                Cldr_TermBetweenDates()
*
*    wrapper     AP
*
*************************************************************************
,,EOH,,*/


INTLARRAY Cldr_DaysBetweenDatesArray(DATESTR* d1,
                                DATEARRAY d2,
                                INTI      n,
                                CALCONV   cal,
								HOLI_STR *holi)
{
    INTI      i ;
    INTLARRAY out ;

    out = Alloc_INTLARRAY(n) ;

    for (i = 0; i < n ; i++)
        out[i] = Cldr_DaysBetweenDates(d1, &d2[i], cal, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */

    return out ;
}


/*
..
*/


/*,,SOH,,
************************************************************************
*
*                Set_PERIOD()
*
*   interface    #include <cldr.h>
*                PERIOD Set_PERIOD(INTI     num,
*                                  TERMUNIT unit) ;
*
*   general      This routine sets the members of the struct defined
*                in the function name. The pointer members are simply
*                assigned - without physical copying. The intention
*                of the Set_*() routines is that by using this
*                functionality, one avoids setting individual members
*                of structs in the application code.
*
*                When new members are inserted in structs the Set_*()
*                routine will be changed accordingly.
*
*                One exception to this principle applies. Whenever
*                OPTADD and vanilla members are used, only the
*                vanilla members are set in the Set_*() routines. The
*                non-vanilla and exotic members are set to defaults,
*                and must be set elsewhere - if needed.
*
*                For details on the interpretation of the individual
*                struct members please check the struct definition.
*
*   input        INTI     num  See general section.
*
*                TERMUNIT unit See general section.
*
*   output
*
*   returns      The filled out PERIOD struct
*
*   diagnostics
*
*   see also     PERIOD
*
************************************************************************
,,EOH,,*/

PERIOD Set_PERIOD(INTI num, TERMUNIT unit)
{
    PERIOD per ;

    per.num  = num ;
    per.unit = unit ;

    return per ;
}

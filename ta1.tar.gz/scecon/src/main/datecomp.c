/* SCID @(#)datecomp.c	1.24 (SimCorp) 99/02/19 14:15:12 */

/************************************************************************
*
*   project     SCecon
*
*   file name   datecomp.c
*
*   general     This file contains standard routines for calendar
*               calculations
*
************************************************************************/

/* includes ************************************************************/
#include <cldr.h>
#include <string.h>

/* defines  ************************************************************/
#define DAY_TOL  0.001

/*,,SOH,,
*************************************************************************
*
*               Cldr_DateEQ()
*
*   interface   #include <cldr.h>
*               BOOLE Cldr_DateEQ(DATESTR *d1,
*                                 DATESTR *d2) ;
*
*   general     Cldr_DateEQ() checks, if d1 is equal to d2.
*
*   input       DATESTR  *d1        Pointer to the first date.
*
*               DATESTR  *d2        Pointer to the second date.
*
*   output
*
*   returns     True if dates are equal otherwise False as BOOLE.
*
*   diagnostics
*
*   see also    Cldr_DateLE()
*               Cldr_DateLT()
*
*************************************************************************
,,EOH,,*/


BOOLE Cldr_DateEQ(DATESTR* d1,
                  DATESTR* d2)
{
    return
        ((d1->d == d2->d && d1->m == d2->m && d1->y == d2->y) ? True : False) ;
}


/*,,SOH,,
*************************************************************************
*
*               Cldr_DateLT()
*
*   interface   #include <cldr.h>
*               BOOLE Cldr_DateLT(DATESTR *d1,
*                                 DATESTR *d2) ;
*
*   general     Cldr_DateLT() checks, if d1 is earlier than d2.
*
*   input       DATESTR  *d1        Pointer to the first date.
*
*               DATESTR  *d2        Pointer to the second date.
*
*   output
*
*   returns     True if d1 is earlier than d2 otherwise False as BOOLE.
*
*   diagnostics
*
*   see also    Cldr_DateEQ()
*               Cldr_DateLE()
*
*************************************************************************
,,EOH,,*/


BOOLE Cldr_DateLT(DATESTR* d1,
                  DATESTR* d2)
{
    /* Speeding up again, 7/31/91, HED, and much improved by SBG, 8/02/91 */
    if (d1->y != d2->y)
        return ((d1->y < d2->y) ? True : False) ;
    if (d1->m != d2->m)
        return ((d1->m < d2->m) ? True : False) ;

    return ((d1->d < d2->d) ? True : False) ;
}


/*,,SOH,,
*************************************************************************
*
*               Cldr_DateLE()
*
*   interface   #include <cldr.h>
*               BOOLE Cldr_DateLE(DATESTR *d1,
*                                 DATESTR *d2) ;
*
*   general     Cldr_DateLE() checks, if d1 is equal to or earlier
*               than d2.
*
*   input       DATESTR  *d1        Pointer to the first date.
*
*               DATESTR  *d2        Pointer to the second date.
*
*   output
*
*   returns     True if d1 is equal to or earlier than d2, otherwise
*               False as BOOLE.
*
*   diagnostics
*
*   see also    Cldr_DateEQ()
*               Cldr_DateLT()
*
*************************************************************************
,,EOH,,*/


BOOLE Cldr_DateLE(DATESTR* d1,
                  DATESTR* d2)
{
    /* Speed up, 7/31/91, HED */
    return (Cldr_DateLT(d2,d1) == True ? False : True) ;
}


/*,,SOH,,
*************************************************************************
*
*               Cldr_IsLeap()
*
*   interface   #include <cldr.h>
*               BOOLE Cldr_IsLeap(INTI  y);
*
*   general     Cldr_IsLeap() checks if input year is a leap year
*               or not.
*
*               Leap are defined by the rule that the year
*               must be divisible by 4. The exception to this rule
*               are the years divisible by 100 which must be divisible
*               by 400 in order to be leap years.
*
*               In this way 1996, 2004, and 2008 are leap years.
*               Further 1800 and 190 were not leap years as well. 
*               But the is in fact a leap year.
*               This was confirmed by the US Naval Observatory,
*               The Royal Greenwich Observatory as well as the 
*               Danish Government.
*
*   input       INTI    y        The input year.
*
*   output
*
*   returns     True if input year is a leap year, False if not.
*
*   diagnostics
*
*   see also    Cldr_LastDayInMonth()
*
*************************************************************************
,,EOH,,*/


BOOLE Cldr_IsLeap(INTI y)
{
    if (0 == (y % 400))
        return True;
    if (0 == (y % 100))
        return False;

    return (0 == (y % 4) ? True : False);
}


/*,,SOH,,
*************************************************************************
*
*                Cldr_MergeDates()
*
*    interface   #include <cldr.h>
*                DATEARRAY Cldr_MergeDates(DATEARRAY dates1,
*                                          INTI      n1,
*                                          DATEARRAY dates2,
*                                          INTI      n2,
*                                          INTI      *nm) ;
*
*    general     Cldr_MergeDates() merges two arrays of dates.
*                Duplicate entries are merged into one entry in
*                the merged array.
*
*                The resulting date array is ordered ascendingly.
*
*    input       DATEARRAY dates1 Reference to first input date array.
*                                 Dates must be sorted ascendingly.
*
*                INTI      n1     The number of entries in dates1.
*
*                DATEARRAY dates2 Reference to second input date array.
*                                 Dates must be sorted ascendingly.
*
*                INTI      n2     The number of entries in dates2.
*
*    output      INTI      *nm    The number of elements in the merged
*                                 list
*
*    returns     Pointer to list holding the merged date array.
*                Allocated in this routine as: Alloc_DATEARRAY(n1 + n2)
*
*    diagnostics
*
*    see also
*
*************************************************************************
,,EOH,,*/

DATEARRAY Cldr_MergeDates(DATEARRAY dates1,
                          INTI      n1,
                          DATEARRAY dates2,
                          INTI      n2,
                          INTI*      nm)
{
    INTI      n, ix1, ix2 ;
    BOOLE     finished ;
    DATEARRAY dates ;

    dates  = Alloc_DATEARRAY(n1 + n2) ;

    n = ix1 = ix2 = 0 ;
    finished = ((ix1 >= n1 && ix2 >= n2) ? True : False) ;

    while (finished == False)
    {
        /* Compare element ix1 and ix2 of the two arrays. */
        if (ix1 >= n1)
        {
            Cldr_AppendDate(dates, &n, dates2, n2, &ix2);
        }
        else if (ix2 >= n2)
        {
            Cldr_AppendDate(dates, &n, dates1, n1, &ix1);
        }

        else if (n1 > 0 && n2 > 0 &&
                 Cldr_DateLT(&dates1[ix1], &dates2[ix2]) == True)
            Cldr_AppendDate(dates, &n, dates1, n1, &ix1);

        else if (n1 > 0 && n2 > 0 &&
                 Cldr_DateEQ(&dates1[ix1], &dates2[ix2]) == True)
        {
            Cldr_AppendDate(dates, &n, dates1, n1, &ix1);
            ix2++ ;
        }
        else
            Cldr_AppendDate(dates, &n, dates2, n2, &ix2);

        /* Control whether we are out of input entries. */
        if (ix1 >= n1 && ix2 >= n2)
            finished = True ;
    }
    *nm = n ;

    return dates ;
}


/*,,SOH,,
*************************************************************************
*
*               Cldr_FindDateIndex()
*
*   interface   #include <cldr.h>
*               INTI Cldr_FindDateIndex(DATEARRAY  dates,
*                                        INTI       count,
*                                        DATESTR    *basisdate,
*                                        INTI       start,
*                                        SEARCHCONV conv,
*                                        INDEXCONV  iconv) ;
*
*   general     The function finds the index for the first coming
*               date after or the last prior to basisdate or maybe
*               a date in dates, depending on the convention in iconv.
*
*               The search can be conducted with a variety of search
*               techniques to be chosen by the application. The optimal
*               technique depends on the amount of knowledge available.
*
*               If basisdate is in the near future you should probably
*               choose a simple sequential forward search.
*               If the date could be anything it will on average be
*               reasonable to use a bisection algorithm to locate the
*               date, which on average would require about LOG10(count)
*               comparisons.
*               If the date is in the end of the date array choose a
*               backwards sequential search.
*
*   input       DATEARRAY dates     Array of payment dates with count
*                                   entries.
*                                   This array of dates must be sorted
*                                   in ascending order.
*
*               INTI     count      The number of elements in dates.
*
*               DATESTR  *basisdate Pointer to the date for which we
*                                   look for an index.
*
*               INTI     start      the search for the index starts in
*                                   this value.
*
*               SEARCHCONV conv     Search convention that specifies
*                                   the search technique used.
*
*               INDEXCONV iconv     Convention that specifies the
*                                   indexation technique used.
*
*   output
*
*   returns     The return value depends on the indexation convention.
*
*                   NEXTINDEX - The index for the first coming payment
*                               date after basisdate.
*                               If basisdate = dates[i] then i+1 is
*                               returned.
*                               If basisdate is later than the last
*                               day in dates, dates[count-1], then
*                               count is returned.
*                               If count is zero then 0 is returned.
*
*                   PREVINDEX - The index of the first date prior to
*                               basisdate.
*                               If basisdate = dates[i] then i-1 is
*                               returned.
*                               If basisdate is later than the last
*                               day in dates, dates[count-1], then
*                               count-1 is returned.
*                               If count is zero then -1 is returned.
*
*                   SAMEINDEX - As NEXTINDEX, except if basisdate is
*                               equal to dates[i] then i is returned.
*
*   diagnostics
*
*   see also    Cldr_FindTermIndex()
*
*************************************************************************
,,EOH,,*/


INTI  Cldr_FindDateIndex(DATEARRAY dates,
                          INTI       count,
                          DATESTR*    basisdate,
                          INTI       start,
                          SEARCHCONV conv,
                          INDEXCONV  iconv)
{
    INTI    jm, jl, ju, uploop ;

    /* warning avoidance */
    ju = 0 ;

    /* First handle a standard situation */
    if (count == 0)
        return (iconv == PREVINDEX ? -1 : 0) ;

    if (Cldr_DateLT(basisdate, &dates[0]) == True)
        return (iconv == PREVINDEX ? -1 : 0) ;

    /* Now search according to the NEXTINDEX convention. */
    switch (conv)
    {
        case SEARCH_BISECTION:

            jl = GETMAX(0, start - 1) ;
            ju = count ;
            while (ju - jl > 1)
            {
                jm = (jl + ju) >> 1 ;
                if (Cldr_DateLT(basisdate, &dates[jm]) == True)
                    ju = jm ;
                else
                    jl = jm ;
            }
            break ;

        case SEARCH_FORWARDS:
            for (ju = GETMAX(0, start-1) ; ju < count ; ju++)
                if (Cldr_DateLT(basisdate, &dates[ju]) == True)
                    break ;
            break ;

        case SEARCH_BACKWARDS:

            uploop = GETMAX(0, start - 1) ;
            for (ju = count - 1; ju >= uploop ; ju--)
                if (Cldr_DateLT(basisdate, &dates[ju]) == False)
                    break ;
            ju++ ;
            break ;
    }

    /* Correct the result if iconv is not NEXTINDEX. */
    if (iconv == PREVINDEX)
        ju-- ;

    if (iconv == PREVINDEX && Cldr_DateEQ(basisdate, &dates[ju]) == True)
        ju-- ;

    if (iconv == SAMEINDEX && ju < count && ju > 0 &&
         Cldr_DateEQ(basisdate, &dates[ju - 1]) == True)
        ju-- ;

    if (iconv == SAMEINDEX && ju >= count &&
         Cldr_DateEQ(basisdate, &dates[count - 1]) == True)
        ju = count - 1 ;

    return ju ;
}


/*,,SOH,,
*************************************************************************
*
*               Cldr_FindTermIndex()
*
*   interface   #include <cldr.h>
*               INTI  Cldr_FindTermIndex(FL64ARRAY  terms,
*                                         INTI       count,
*                                         FL64       basisterm,
*                                         INTI       start,
*                                         SEARCHCONV conv,
*                                         INDEXCONV  iconv) ;
*
*   general     The function finds the index for the first coming
*               term after basisterm or the last prior to basisterm or
*               maybe a term in terms, depending on the convention in
*               iconv.
*
*               The search can be conducted with a variety of search
*               techniques to be chosen by the application. The optimal
*               technique depends on the amount of knowledge available.
*
*               If basisterm is in the near future you should probably
*               choose a simple sequential forward search.
*               If the term could be anything it will on average be
*               reasonable to use a bisection algorithm to locate the
*               term, which on average would require about LOG10(count)
*               comparisons.
*               If the term is in the end of the date array choose a
*               backwards sequential search.
*
*   input       FL64ARRAY  terms    The array of payment terms.
*                                   This array is ordered in ascending
*                                   order.
*
*               INTI     count      The number of elements in terms.
*
*               FL64     basisterm  The term for which we look for an
*                                   index.
*
*               INTI     start      The search for the index starts in
*                                   this value.
*
*               SEARCHCONV conv     Search convention that specifies
*                                   the search technique used.
*
*               INDEXCONV iconv     Convention that specifies the
*                                   indexation technique used.
*
*   output
*
*   returns     The return value depends on the indexation convention:
*
*                   NEXTINDEX - The index for the first coming term
*                               after basisterm.
*                               If basisterm = terms[i] then i+1 is
*                               returned.
*                               If basisterm is later than the last
*                               element in term, terms[count-1], then
*                               count is returned.
*                               If count is zero then 0 is returned.
*
*                   PREVINDEX - The index of the first term prior to
*                               basisterm.
*                               If basisterm = terms[i] then i-1 is
*                               returned.
*                               If basisterm is later than the last
*                               element in terms, terms[count-1], then
*                               count-1 is returned.
*                               If count is zero then -1 is returned.
*
*                   SAMEINDEX - As NEXTINDEX, except that if basisterm
*                               is equal to terms[i] then i is returned.*
*
*               If basisterm is within a day (0.001) of terms[i], this
*               is not accepted as being 'smaller than' and the relevant
*               index is returned.
*
*   diagnostics
*
*   see also    Cldr_FindDateIndex()
*
*************************************************************************
,,EOH,,*/


INTI  Cldr_FindTermIndex(FL64ARRAY terms,
                          INTI       count,
                          FL64       basisterm,
                          INTI       start,
                          SEARCHCONV conv,
                          INDEXCONV  iconv)
{
    return Scutl_Find_Termindex(terms, count, basisterm, start, conv, iconv) ;
}


/*,,SOH,,
*************************************************************************
*
*               Cldr_DateSort()
*
*   interface   #include <cldr.h>
*               void Cldr_DateSort(INTI      n,
*                                   DATEARRAY dates,
*                                   SORTCONV  sort) ;
*
*   general     The function sorts an array of dates. The sorting
*               convention determines how the sorting is performed.
*
*               dates are modified during computations.
*
*   input       INTI      n         The number of elements in dates.
*
*               DATEARRAY dates     The array of dates.
*
*               SORTCONV  sort      A sort convention that specifies
*                                   the sorting.
*
*   output                          The DATEARRAY dates is sorted.
*
*   returns
*
*   diagnostics
*
*   see also    Cldr_FindDateIndex()
*
*************************************************************************
,,EOH,,*/


void Cldr_DateSort(INTI n, DATEARRAY dates, SORTCONV sort)
{
    INTI      h, i, j, r ;
    DATESTR   date;
    DATEARRAY ddates;

    if (n <= 1)
        return ;

    ddates = Alloc_DATEARRAY(1 + n) ;

    /* Here we transform the pointer to a unit offset - since the algorithm
       expects this */
    for (i = 0; i < n; i++)
        ddates[i + 1] = dates[i] ;

    h = (n >> 1) + 1 ;
    r = n ;

    /* During the heap setup phase, the "hiring" index h will be decremented
       to 0 after which the "retirement" loop begins in which the index r
       gets decremented to 0 as the sorting proceeds.                   */

    for (;;)
    {
        if (h > 1)         /* Yes, we are hiring now!  */
            date = ddates[--h] ;
        else
        {                     /* Retirement-and-promotion (sorting) phase */
            date = ddates[r] ;
            ddates[r] = ddates[1] ;
            if (--r == 1)
            {
                ddates[1] = date ;
                break ;
            }
        }
        /* This piece of code actually does the placement of dates BOTH
           in the heap (during hiring) and in the sorted list (during
           retirement-promotion).   */
        i = h ;
        j = h << 1 ;

        while (j <= r)
        {
            if (j < r && Cldr_DateLT(&ddates[j],&ddates[j+1]) == True)
                ++j ;
            if (Cldr_DateLT(&date,&ddates[j]) == True)
            {
                ddates[i] = ddates[j] ;
                j += (i=j) ;
            }
            else
                j = r + 1 ;
        }

        ddates[i] = date ;  /* Put date into its slot */
    }

    if (sort == DESCENDING)
    {
        r = n/2 ;
        for (i = 1 ; i <= r ; i++)
        {
            date    = ddates[i] ;
            ddates[i]  = ddates[n - i + 1] ;
            ddates[n - i + 1] = date ;
        }
    }

    /* Back to zero offset */
    for (i = 0; i < n; i++)
        dates[i] = ddates[i + 1] ;

    Free_DATEARRAY(ddates) ;
}


/*,,SOH,,
*************************************************************************
*
*               Cldr_InsertDate()
*
*   interface   #include <cldr.h>
*               INTI  Cldr_InsertDate(DATEARRAY dates,
*                                      INTI      n,
*                                      DATESTR   *date,
*                                      INTI      *ix) ;
*
*   general     The function inserts a date in a dataarray at the
*               appropriate place.
*               The original array is sorted ascendingly.
*
*   input       DATEARRAY dates     The array of dates into which
*                                   date is inserted.
*
*               INTI      n         The number of elements in dates.
*
*               DATESTR   *date     The date to be inserted.
*
*   output      INTI      *ix       The index of date in the modified
*                                   array.
*
*   returns     The number of entries in the modified array.
*
*   diagnostics
*
*   see also    Cldr_MergeDates()
*
*************************************************************************
,,EOH,,*/


INTI  Cldr_InsertDate(DATEARRAY dates, INTI  n,
                       DATESTR* date, INTI*  ix)
{
    INTI    j, i ;

    i = Cldr_FindDateIndex(dates, n, date, 0,
                            SEARCH_BISECTION, SAMEINDEX) ;
    if (i >= n)
    {
        dates[n] = *date ;
        *ix  = n ;
        n++ ;
    }
    else if (Cldr_DateEQ(date, &dates[i]) == True)
        *ix = i ;

    else
    {
        for (j = n - 1 ; j >= i ; j--)
            dates[j + 1] = dates[j] ;

        dates[i] = *date ;
        n++ ;
        *ix = i ;
    }

    return n ;
}


/*,,SOH,,
*************************************************************************
*
*               Cldr_FindPrevTerm()
*
*   interface   #include <cldr.h>
*               DATESTR Cldr_FindPrevTerm(DATESTR *today,
*                                         DATESTR *pday,
*                                         INTI    months,
*                                         EOMCONV eom) ;
*
*   general     The function finds the last payday prior to today.
*               In doing so no oddities like odd payment days are
*               respected, so only regular paydays are found.
*
*               If today is a payday then today is returned.
*
*   input       DATESTR   *today    The current date.
*
*               DATESTR   *pday     A future payday, not earlier than
*                                   today.
*
*               INTI      months    Months between payments. Must be
*                                   a positive number.
*
*               EOMCONV   eom       End of month convention.
*
*   output
*
*   returns     The last payday prior to today
*
*   diagnostics
*
*   see also    Cldr_FindNextTerm()
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/


DATESTR Cldr_FindPrevTerm(DATESTR* today, DATESTR* pday,
                          INTI  months, EOMCONV eom)
{
    BOOLE   found ;
    DATESTR prev ;

    prev  = *pday ;
    found = False ;

    while (found == False)
    {
        prev = Cldr_AddMonths(&prev, - months, eom) ;
        if (Cldr_DateLE(&prev, today) == True)
            found = True ;
    }

    return prev ;
}


/*,,SOH,,
*************************************************************************
*
*               Cldr_FindNextTerm()
*
*   interface   #include <cldr.h>
*               DATESTR Cldr_FindNextTerm(DATESTR *today,
*                                         DATESTR *pday,
*                                         INTI    months,
*                                         EOMCONV eom) ;
*
*   general     The function finds the next payday after today.
*               In doing so no oddities like odd payment days are
*               respected, so only regular paydays are found.
*
*               If today is a payday then the next payday is returned.
*
*   input       DATESTR   *today    The current date.
*
*               DATESTR   *pday     A previous payday, earlier than
*                                   today.
*
*               INTI      months    Months between payments. Must be
*                                   a positive number.
*
*               EOMCONV   eom       End of month convention.
*
*   output
*
*   returns     The next payday after today.
*
*   diagnostics
*
*   see also    Cldr_FindPrevTerm()
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/


DATESTR Cldr_FindNextTerm(DATESTR* today, DATESTR* pday,
                          INTI  months, EOMCONV eom)
{
    BOOLE   found ;
    DATESTR next ;

    next  = *pday ;
    found = False ;

    while (found == False)
    {
        next = Cldr_AddMonths(&next, months, eom) ;
        if (Cldr_DateLT(today, &next) == True)
            found = True ;
    }

    return next ;
}


/*,,SOH,,
*************************************************************************
*
*               Cldr_UniqueDates()
*
*   interface   #include <cldr.h>
*               DATEARRAY Cldr_UniqueDates(INTI       n,
*                                            DATEARRAY dates,
*                                            INTI      *count) ;
*
*   general     The function finds the unique dates in the list dates.
*               The list of unique dates is returned.
*
*   input       INTI      n         The number of elements in dates.
*
*               DATEARRAY dates     The array of dates.
*                                   Sorted ascendingly.
*
*   output      INTI      *count    Number of unique elements in dates.
*
*   returns     A DATEARRAY with the unique dates. The array is alloca-
*               ted in this routine as: Alloc_DATEARRAY(n)
*
*   diagnostics
*
*   see also   Cldr_DateSort()
*
*************************************************************************
,,EOH,,*/


DATEARRAY Cldr_UniqueDates(INTI n, DATEARRAY dates, INTI* count)
{
    INTI      i ;
    DATEARRAY out ;

    out = Alloc_DATEARRAY(n) ;

    for (*count = 0, i = 0; i < n; i++)
    {
        if (i == 0)
        {
            out[*count] = dates[i] ;
            ++*count ;
        }

        else if (Cldr_DateEQ(&out[*count - 1], &dates[i]) == False)
        {
            out[*count] = dates[i] ;
            ++*count ;
        }
    }

    return out ;
}


/* Appends dates1[*ix1] to dates, ie at dates[(*n)++], only
   if dates[(*n) - 1] <> dates1[*ix1]. *ix1 is incremented by 1
   in any case.
*/
void Cldr_AppendDate(DATEARRAY  dates, INTI*  n,  
                     DATEARRAY  dates1, INTI  n1, INTI*  ix1)
{
  if (*n == 0 && *ix1 < n1)
  {
    dates[*n] = dates1[*ix1];
    ++*n;
    ++*ix1;
  }
  else if (*n > 0 && 
           Cldr_DateEQ(&dates[(*n) - 1], &dates1[*ix1]) == True)
  {
    ++*ix1;
  }
  else if (*n > 0 && 
           Cldr_DateEQ(&dates[(*n) - 1], &dates1[*ix1]) == False)
  {
    dates[*n] = dates1[*ix1];
    ++*n;
    ++*ix1;
  }
}


#undef DAY_TOL

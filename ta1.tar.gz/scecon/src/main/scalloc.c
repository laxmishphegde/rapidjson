/* SCID @(#)scalloc.c	1.47 (SimCorp) 99/11/03 17:51:32 */

/************************************************************************
*
*       project         SCecon
*
*       filename        scalloc.c
*
*       contains        SCecon standard allocation routines
*
************************************************************************/

#include <scutl.h>

#include <stdarg.h>

/*,,SOH,,
***********************************************************************
*
*               Alloc_FL32ARRAY()
*
*   interface   #include <scalloc.h>
*
*               FL32ARRAY  Alloc_FL32ARRAY(INTI  nh) ;
*
*   general     Allocates a vector of FL32 with given range
*
*   input       INTI  nh     Upper range of vector
*
*   output
*
*   returns     reference to allocated array[nl..nh]
*
*   diagnostics aborts calling SCecon_error()
*               with the message   "Allocation failed"
*                        routine   "Alloc_FL32ARRAY()"
*                        actioncode SCECONABORT
*               if allocation fails
*
*   see also    Free_FL32ARRAY()
*
***********************************************************************
,,EOH,,*/
FL32ARRAY Alloc_FL32ARRAY(INTI nh)
{
    FL32ARRAY v ;

    v = (FL32ARRAY) SCecon_calloc(nh, sizeof(FL32), True,
      "Alloc_FL32ARRAY()") ;

    return v ;
}


/*,,SOH,,
************************************************************************
*
*               Free_FL32ARRAY()
*
*   interface   #include <scalloc.h>
*
*               void Free_FL32ARRAY(FL32ARRAY v);
*
*   general     Frees memory allocated to FL32 by Alloc_FL32ARRAY().
*
*   input       FL32ARRAY v  Reference to vector allocated by 
*                            Alloc_FL32ARRAY()
*
*   output
*
*   returns
*
*   diagnostics
*
*   see also    Alloc_FL32ARRAY()
*
***********************************************************************
,,EOH,,*/
void Free_FL32ARRAY(FL32ARRAY v)
{
    SCecon_free((VOIDPTR) v) ;
}

/*,,SOH,,
*************************************************************************
*
*               Alloc_FL64ARRAY()
*
*   interface   #include <scalloc.h>
*               FL64ARRAY  Alloc_FL64ARRAY(INTI nh) ;
*
*   general     Allocates a vector of FL64 with n entries with zero
*               off-set, that is
*
*                       vector[0...n-1].
*
*               Returns memory with zero'ed entries.
*
*   input       INTI  nh     Upper range of vector.
*
*   output
*
*   returns     reference to allocated array.
*
*   diagnostics aborts calling SCecon_error()
*               with the message   "Allocation failed"
*                        routine   "Alloc_FL64ARRAY()"
*                        actioncode SCECONABORT
*               if allocation fails
*
*   see also    Free_FL64ARRAY()
*
*************************************************************************
,,EOH,,*/


FL64ARRAY Alloc_FL64ARRAY(INTI nh)
{
    FL64ARRAY v ;

    v = (FL64ARRAY) SCecon_calloc(nh, sizeof(FL64), True,
      "Alloc_FL64ARRAY()") ;

    return v ;
}


/*,,SOH,,
*************************************************************************
*
*               Alloc_INTIARRAY()
*
*   interface   #include <scalloc.h>
*               INTIARRAY Alloc_INTIARRAY(INTI  nh) ;
*
*   general     Allocates a vector of INTI with zero off-set and n
*               elements, that is
*
*                       vector[0...n-1].
*
*               Returns memory with zero'ed entries.
*
*   input       INTI  nh     Upper range of vector
*
*   output
*
*   returns     reference to allocated array.
*
*   diagnostics aborts calling SCecon_error()
*               with the message   "Allocation failed"
*                        routine   "Alloc_INTIARRAY()"
*                        actioncode SCECONABORT
*               if allocation fails
*
*   see also    Free_INTIARRAY()
*
*************************************************************************
,,EOH,,*/


INTIARRAY Alloc_INTIARRAY(INTI nh)
{
    INTIARRAY v ;

    v = (INTIARRAY) SCecon_calloc(nh, sizeof(INTI), True,
      "Alloc_INTIARRAY()") ;

    return v ;
}


/*,,SOH,,
*************************************************************************
*
*               Alloc_INTLARRAY()
*
*   interface   #include <scalloc.h>
*               INTLARRAY Alloc_INTLARRAY(INTI  nh) ;
*
*   general     Allocates a vector of INTL with zero off-set and n
*               elements, that is
*
*                       vector[0...n-1].
*
*               Returns memory with zero'ed entries.
*
*   input       INTI  nh     Upper range of vector
*
*   output
*
*   returns     reference to allocated array.
*
*   diagnostics aborts calling SCecon_error()
*               with the message   "Allocation failed"
*                        routine   "Alloc_INTLARRAY()"
*                        actioncode SCECONABORT
*               if allocation fails
*
*   see also    Free_INTLARRAY()
*
*************************************************************************
,,EOH,,*/


INTLARRAY Alloc_INTLARRAY(INTI nh)
{
    INTLARRAY v ;

    v = (INTLARRAY) SCecon_calloc(nh, sizeof(INTL), True,
      "Alloc_INTLARRAY()") ;

    return v ;
}


/*,,SOH,,
*************************************************************************
*
*               Alloc_FL64MATRIX()
*
*   interface   #include <scalloc.h>
*               FL64MATRIX Alloc_FL64MATRIX(INTI  nrh,
*                                                 INTI  nch) ;
*
*    general    Allocates an FL64MATRIX with zero off-set and given
*               row and column ranges, that is
*
*                       matrix[0...nrh-1][0...nch-1].
*
*               Returns memory with zero'ed entries.
*
*    input      INTI  nrh    Upper range of rows.
*
*               INTI  nch    Upper range of columns.
*
*    output
*
*    returns    Reference to allocated matrix.
*
*    diagnostics aborts calling SCecon_error()
*                with the message   "Allocation failed"
*                         routine   "Alloc_FL64MATRIX()"
*                         actioncode SCECONABORT
*                if allocation fails
*
*    see also    Free_FL64MATRIX()
*
*************************************************************************
,,EOH,,*/


FL64MATRIX Alloc_FL64MATRIX(INTI nrh, INTI nch)
{
  INTI      i, nrow ;
  FL64MATRIX m ;

    /* One-chunk-allocation scheme:
     * -----------------------------------------------------------------
     * Instead of allocating an array of row pointers and each row
     * separately, all needed memory is allocated in one chunk. The
     * main advantage by this scheme is, that the number of rows is
     * not necessary for the corresponding free action, making it both
     * easier and less error-prone to free.
     *
     * It is simply allocated as the needed memory for the row pointers
     * and all the values in one chunk, as e.g. with this 2 row and 3
     * column matrix "m":
     *
     *                 "Wasted" space for alignment if odd
     *                 number of row pointers (sizeof(ptr))
     *                               |
     *     -----------------------------------------------------
     *     |    m[0]    |    m[1]   |X| start of row 0 values  |
     *     | ptr2row 0  | ptr2row 1 |X|        m[0][0]         |
     *     -----------------------------------------------------
     *     |                         |                         |
     *     |         m[0][1]         |         m[0][2]         |
     *     -----------------------------------------------------
     *     | start of row 0 values   |                         |
     *     |         m[1][0]         |         m[1][1]         |
     *     -----------------------------------------------------
     *     |                         |        deadbeef         |
     *     |         m[1][2]         |     (not allocated)     |
     *     -----------------------------------------------------
     *
     * Note that values here are 64 bit, while pointers are 32 bit.
     * -----------------------------------------------------------------
     */

  nrh = GETMAX(1, nrh) ;
  nch = GETMAX(1, nch) ;

    /* If number of pointers needed is odd, allocate an extra
     * alignment element (needed on some compilers):
     */
  if( nrh % 2 )
    nrow = nrh + 1 ;
  else
    nrow = nrh ;

  m = (FL64MATRIX) SCecon_calloc(
    nrow * sizeof(FL64ARRAY) + nrh * nch * sizeof(FL64), 1, True, 
    "Alloc_FL64MATRIX()") ;

    /* Set up row pointers to value area: */
  for (i = 0 ; i < nrh ; i++)
    m[i] = (FL64ARRAY)( (char *)m + nrow * sizeof(FL64ARRAY) +
      i * nch * sizeof(FL64) );

  return m ;
}


/*,,SOH,,
*************************************************************************
*
*               Alloc_INTIMATRIX()
*
*   interface   #include <scalloc.h>
*               INTIMATRIX Alloc_INTIMATRIX(INTI  nrh,
*                                                 INTI  nch) ;
*
*    general    Allocates an INTIMATRIX with zero off-set and given
*               row and column ranges, that is
*
*                       matrix[0...nrh-1][0...nch-1].
*
*               Returns memory with zero'ed entries.
*
*    input      INTI  nrh    Upper range of rows.
*
*               INTI  nch    Upper range of columns.
*
*    output
*
*    returns    reference to allocated matrix.
*
*    diagnostics aborts calling SCecon_error()
*                with the message   "Allocation failed"
*                         routine   "Alloc_INTIMATRIX()"
*                         actioncode SCECONABORT
*                if allocation fails
*
*    see also    Free_INTIMATRIX()
*
*************************************************************************
,,EOH,,*/


INTIMATRIX Alloc_INTIMATRIX(INTI nrh, INTI  nch)
{
  INTI      i ;
  INTIMATRIX m ;

    /* For a detailed explanation of the one-chunk allocation scheme,
     * see the comment inside the Alloc_FL64MATRIX function.
     *
     * Alignment is skipped as values are 32 bit (so far!).
     */

  nrh = GETMAX(1, nrh) ;
  nch = GETMAX(1, nch) ;

  m = (INTIMATRIX) SCecon_calloc(
    nrh * sizeof(INTIARRAY) + nrh * nch * sizeof(INTI), 1, True,
    "Alloc_INTIMATRIX()") ;

    /* Set up row pointers to value area: */
  for (i = 0 ; i < nrh ; i++)
    m[i] = (INTIARRAY)( (char *)m + nrh * sizeof(INTIARRAY) +
      i * nch * sizeof(INTI) );

  return m ;
}


/*,,SOH,,
*************************************************************************
*
*               Alloc_BOOLEMATRIX()
*
*   interface   #include <scalloc.h>
*               BOOLEMATRIX Alloc_BOOLEMATRIX(INTI  nrh,
*                                             INTI  nch) ;
*
*    general    Allocates an BOOLEMATRIX with zero off-set and given
*               row and column ranges, that is
*
*                       matrix[0...nrh-1][0...nch-1].
*
*               Returns memory with zero'ed entries.
*
*    input      INTI  nrh    Upper range of rows.
*
*               INTI  nch    Upper range of columns.
*
*    output
*
*    returns    reference to allocated matrix.
*
*    diagnostics aborts calling SCecon_error()
*                with the message   "Allocation failed"
*                         routine   "Alloc_BOOLEMATRIX()"
*                         actioncode SCECONABORT
*                if allocation fails
*
*    see also    Free_BOOLEMATRIX()
*
***********************************************************************
,,EOH,,*/
BOOLEMATRIX Alloc_BOOLEMATRIX(INTI nrh, INTI nch)
{
  INTI      i ;
  BOOLEMATRIX m ;

    /* For a detailed explanation of the one-chunk allocation scheme,
     * see the comment inside the Alloc_FL64MATRIX function.
     *
     * Alignment is skipped as values are 32 bit (so far!).
     */

  nrh = GETMAX(1, nrh) ;
  nch = GETMAX(1, nch) ;

  m = (BOOLEMATRIX) SCecon_calloc(
    nrh * sizeof(BOOLEARRAY) + nrh * nch * sizeof(BOOLE), 1, True,
    "Alloc_BOOLEMATRIX()") ;

    /* Set up row pointers to value area: */
  for (i = 0 ; i < nrh ; i++)
    m[i] = (BOOLEARRAY)( (char *)m + nrh * sizeof(BOOLEARRAY) +
      i * nch * sizeof(BOOLE) );

  return m ;
}


/*,,SOH,,
*************************************************************************
*
*               Free_FL64ARRAY()
*
*   interface   #include <scalloc.h>
*               void Free_FL64ARRAY(FL64ARRAY v) ;
*
*   general     Frees memory allocated to FL64 by the routine
*               Alloc_FL64ARRAY().
*
*   input       FL64ARRAY v   Reference to vector allocated by
*                             Alloc_FL64ARRAY().
*   output
*
*   returns
*
*   diagnostics
*
*   see also    Alloc_FL64ARRAY()
*
*************************************************************************
,,EOH,,*/


void Free_FL64ARRAY(FL64ARRAY v)
{
    SCecon_free((VOIDPTR) v) ;
}


/*,,SOH,,
*************************************************************************
*
*               Free_INTIARRAY()
*
*   interface   #include <scalloc.h>
*               void Free_INTIARRAY(INTIARRAY v) ;
*
*   general     Frees memory allocated to INTI by the routine
*               Alloc_INTIARRAY().
*
*   input       INTIARRAY v   Reference to array allocated by
*                             Alloc_INTIARRAY().
*   output
*
*   returns
*
*   diagnostics
*
*   see also    Alloc_INTIARRAY()
*
*************************************************************************
,,EOH,,*/


void Free_INTIARRAY(INTIARRAY v)
{
    SCecon_free((VOIDPTR) v) ;
}


/*,,SOH,,
*************************************************************************
*
*               Free_INTLARRAY()
*
*   interface   #include <scalloc.h>
*               void Free_INTLARRAY(INTLARRAY v) ;
*
*   general     Frees memory allocated to INTL by the routine
*               Alloc_INTLARRAY().
*
*   input       INTLARRAY v   Reference to array allocated by
*                             Alloc_INTLARRAY().
*   output
*
*   returns
*
*   diagnostics
*
*   see also    Alloc_INTLARRAY()
*
*************************************************************************
,,EOH,,*/


void Free_INTLARRAY(INTLARRAY v)
{
    SCecon_free((VOIDPTR) v) ;
}


/*,,SOH,,
*************************************************************************
*
*               Free_FL64MATRIX()
*
*   interface   #include <scalloc.h>
*
*               void Free_FL64MATRIX(FL64MATRIX m ) ;
*
*   general     Frees memory allocated to FL64 by the routine
*               Alloc_FL64MATRIX().
*
*   input       FL64MATRIX  m    Reference to matrix allocated by
*                                Alloc_FL64MATRIX().
*
*   output
*
*   returns
*
*   diagnostics
*
*   see also    Alloc_FL64MATRIX()
*
*************************************************************************
,,EOH,,*/


void Free_FL64MATRIX(FL64MATRIX  m)
{
    SCecon_free((VOIDPTR) m) ;
}


/*,,SOH,,
*************************************************************************
*
*               Free_INTIMATRIX()
*
*   interface   #include <scalloc.h>
*               void Free_INTIMATRIX(INTIMATRIX m) ;
*
*   general     Frees memory allocated to INTI  by the routine
*               Alloc_INTIMATRIX().
*
*   input       INTIMATRIX   m     Reference to matrix allocated by
*                                  Alloc_INTIMATRIX().
*
*   output
*
*   returns
*
*   diagnostics
*
*   see also    Alloc_INTIMATRIX()
*
*************************************************************************
,,EOH,,*/


void Free_INTIMATRIX(INTIMATRIX  m)
{
    SCecon_free((VOIDPTR) m) ;
}


/*,,SOH,,
***********************************************************************
*
*               Free_BOOLEMATRIX()
*
*   interface   #include <scalloc.h>
*               void Free_BOOLEMATRIX(BOOLEMATRIX m) ;
*
*   general     Frees memory allocated to BOOLE by the routine
*               Alloc_BOOLEMATRIX().
*
*   input       BOOLEMATRIX  m   Reference to matrix allocated by
*                                Alloc_BOOLEMATRIX().
*
*   output
*
*   returns
*
*   diagnostics
*
*   see also    Alloc_BOOLEMATRIX()
*
***********************************************************************
,,EOH,,*/


void Free_BOOLEMATRIX(BOOLEMATRIX  m)
{
    SCecon_free((VOIDPTR) m) ;
}


/*,,SOH,,
*************************************************************************
*
*               Alloc_BOOLEARRAY()
*
*   interface   #include <scalloc.h>
*               BOOLEARRAY Alloc_BOOLEARRAY(INTI  nh);
*
*   general     Allocates a vector of BOOLE with zero off-set and n
*               elements, that is
*
*                       vector[0...n-1].
*
*               Returns memory with zero'ed entries.
*
*   input       INTI  nh     Upper range of vector
*
*   output
*
*   returns     reference to allocated array.
*
*   diagnostics aborts calling SCecon_error()
*               with the message   "Allocation failed"
*                        routine   "Alloc_BOOLEARRAY()"
*                        actioncode SCECONABORT
*               if allocation fails
*
*   see also    Free_BOOLEARRAY()
*
*************************************************************************
,,EOH,,*/


BOOLEARRAY Alloc_BOOLEARRAY(INTI nh)
{
    BOOLEARRAY v ;

    v = (BOOLEARRAY) SCecon_calloc(nh, sizeof(BOOLE), True,
      "Alloc_BOOLEARRAY()") ;

    return v ;
}


/*,,SOH,,
*************************************************************************
*
*               Free_BOOLEARRAY()
*
*   interface   #include <scalloc.h>
*               void Free_BOOLEARRAY(BOOLEARRAY v) ;
*
*   general     Frees memory allocated to BOOLE by the routine
*               Alloc_BOOLEARRAY().
*
*   input       BOOLEARRAY v  Reference to array allocated by
*                             Alloc_BOOLEARRAY().
*   output
*
*   returns
*
*   diagnostics
*
*   see also    Alloc_BOOLEARRAY()
*
*************************************************************************
,,EOH,,*/


void Free_BOOLEARRAY(BOOLEARRAY v)
{
    SCecon_free((VOIDPTR) v) ;
}

/*,,SOH,,
*************************************************************************
*
*               Alloc_CCYCODEARRAY()
*
*    interface  #include <scalloc.h>
*               CCYCODEARRAY Alloc_CCYCODEARRAY(INTI n) ;
*
*    general    Alloc_CCYCODEARRAY()() allocates memory for an
*               [0...(n-1)] array of CCYCODEARRAY's.
*               Returns memory with zero'ed entries
*
*    input      INTI    n       The number of entries in CCYCODEARRAY list
*
*    output
*
*    returns    reference to the vector of type CCYCODEARRAY
*
*    diagnostics aborts calling SCecon_error()
*                with the message   "Allocation failed"
*                         routine   "Alloc_CCYCODEARRAY()"
*                         actioncode SCECONABORT
*                if allocation fails
*
*    see also   Free_CCYCODEARRAY()
*
*************************************************************************
,,EOH,,*/


CCYCODEARRAY Alloc_CCYCODEARRAY(INTI n)
{
  CCYCODEARRAY a;

  a = (CCYCODEARRAY) SCecon_calloc(n, sizeof(CCYCODE), True,
    "Alloc_CCYCODEARRAY()") ;

  return a ;
}

/*,,SOH,,
*************************************************************************
*
*               Free_CCYCODEARRAY()
*
*    interface  #include <scalloc.h>
*               void Free_CCYCODEARRAY(CCYCODEARRAY vector) ;
*
*    general    Free_CCYCODEARRAY() frees memory for an array
*               of CCYCODE's allocated by Alloc_CCYCODEARRAY()
*
*    input      CCYCODEARRAY vector       The array. 
*
*    output
*
*    returns
*
*    diagnostics
*
*    see also   Alloc_CCYCODEARRAY()
*
*************************************************************************
,,EOH,,*/


void Free_CCYCODEARRAY(CCYCODEARRAY vector)
{
  if (vector == NULL)
    return;

  SCecon_free((VOIDPTR) vector) ;
  
}

/*,,SOH,,
*************************************************************************
*
*               Alloc_RISKTOKENARRAY()
*
*   interface   #include <scalloc.h>
*               RISKTOKENARRAY Alloc_RISKTOKENARRAY(INTI  n) ;
*
*   general     Allocates a vector of RISKTOKEN with zero off-set and n
*               elements, that is
*
*                       vector[0...n-1].
*
*               Returns memory with zero'ed entries.
*
*   input       INTI  n      Upper range of vector
*
*   output
*
*   returns     reference to allocated array.
*
*   diagnostics aborts calling SCecon_error()
*               with actioncode SCECONABORT
*               if allocation fails
*
*   see also    Free_RISKTOKENARRAY()
*
*************************************************************************
,,EOH,,*/


RISKTOKENARRAY Alloc_RISKTOKENARRAY(INTI n)
{
    RISKTOKENARRAY v ;

    n = GETMAX(n, 1) ;

    v = (RISKTOKENARRAY) SCecon_calloc(n, sizeof(RISKTOKEN), True,
      "Alloc_RISKTOKENARRAY()") ;

    return v ;
}


/*,,SOH,,
*************************************************************************
*
*               Free_RISKTOKENARRAY()
*
*   interface   #include <scalloc.h>
*               void Free_RISKTOKENARRAY(RISKTOKENARRAY v) ;
*
*   general     Frees memory allocated to RISKTOKEN by the routine
*               Alloc_RISKTOKENARRAY().
*
*   input       RISKTOKENARRAY v  Reference to array allocated by
*                                 Alloc_RISKTOKENARRAY().
*   output
*
*   returns
*
*   diagnostics
*
*   see also    Alloc_RISKTOKENARRAY()
*
*************************************************************************
,,EOH,,*/


void Free_RISKTOKENARRAY(RISKTOKENARRAY v)
{
    SCecon_free((VOIDPTR) v) ;
}



/*,,SOH,,
*************************************************************************
*
*               Alloc_FL64SMATRIX()
*
*   interface   #include <scalloc.h>
*               FL64SMATRIX Alloc_FL64SMATRIX(INTI  n)
*
*    general    Allocates an FL64SMATRIX, ie, the lower half (incl
*               diagonal of a square n x n matrix. Only the elements
*
*                       matrix[i][j]  with  0 <= j <= i < n
*
*               are allocated.
*
*               Returns memory with zero'ed entries.
*
*    input      INTI  n      Size of matrix.
*
*    output
*
*    returns    Reference to allocated matrix.
*
*    diagnostics aborts calling SCecon_error()
*                with the message   "Alloc failed"
*                         routine   "Alloc_FL64SMATRIX()"
*                         actioncode SCECONABORT
*                if allocation fails
*
*    see also    Free_FL64SMATRIX()
*
*************************************************************************
,,EOH,,*/

FL64SMATRIX Alloc_FL64SMATRIX(INTI  n)
{
  INTI i, nval, nrow ;
  FL64SMATRIX s ;

    /* For a detailed explanation of the one-chunk allocation scheme,
     * see the comment inside the Alloc_FL64MATRIX function.
     *
     * The specialty with unequal row lengths is dealt with in the
     * nval needed value counter.
     */

  n = GETMAX(n, 1) ;

    /* If total number of pointers needed is odd, allocate an extra
     * alignment element (needed on some compilers):
     */
  if( n % 2 )
    nrow = n + 1 ;
  else
    nrow = n ;

  nval = 0;
  for (i = 0 ; i < n ; i++)
    nval += i+1;

  s = (FL64MATRIX) SCecon_calloc(
    nrow * sizeof(FL64ARRAY) + nval * sizeof(FL64), 1, True,
    "Alloc_FL64SMATRIX()") ;

    /* Set up row pointers to value area: */
  nval = 0;
  for (i = 0 ; i < n ; i++)
  {
    s[i] = (FL64ARRAY)( (char *)s + nrow * sizeof(FL64ARRAY) +
      nval * sizeof(FL64) );
    nval += i+1;
  }

  return s ;
}

/*,,SOH,,
*************************************************************************
*
*               Free_FL64SMATRIX()
*
*   interface   #include <scalloc.h>
*
*               void Free_FL64SMATRIX(FL64SMATRIX s) ;
*
*   general     Frees memory allocated to FL64SMATRIX by the routine
*               Alloc_FL64SMATRIX().
*
*   input       FL64SMATRIX s    Reference to matrix allocated by
*                                Alloc_FL64SMATRIX().
*
*   output
*
*   returns
*
*   diagnostics
*
*   see also    Alloc_FL64SMATRIX()
*
*************************************************************************
,,EOH,,*/

void Free_FL64SMATRIX(FL64SMATRIX  s)
{
  SCecon_free((VOIDPTR) s) ;
}


/*,,SOH,,
*************************************************************************
*
*               Alloc_INTIBOX()
*
*   interface   #include <scalloc.h>
*               INTIBOX  Alloc_INTIBOX(INTI n1,
*                                      INTI n2,
*                                      INTI n3);
*
*   general     Allocates a box of INTI with n entries with zero
*               off-set, that is
*
*                       box[0..n1-1][0..n2-1][0..n3-1]
*
*               Returns memory with zero'ed entries.
*
*   input       INTI  n1     Upper range of box   .
*
*               INTI  n2     Medium range of box   .
*
*               INTI  n3     Lower range of box   .
*
*   output
*
*   returns     reference to allocated array.
*
*   diagnostics aborts calling SCecon_error()
*               with the message   "Allocation failed"
*                        routine   "Alloc_INTIBOX()"
*                        actioncode SCECONABORT
*               if allocation fails
*
*   see also    Free_INTIBOX()
*
*************************************************************************
,,EOH,,*/
INTIBOX Alloc_INTIBOX(INTI  n1, INTI  n2, INTI  n3)
{
  INTIBOX ib ;
  INTI i, j ;

    /* For a detailed explanation of the one-chunk allocation scheme,
     * see the comments inside the Alloc_FL64BOX and MATRIX functions.
     *
     * Alignment is skipped as values are 32 bit (so far!).
     */

  n1 = GETMAX(1, n1) ;
  n2 = GETMAX(1, n2) ;
  n3 = GETMAX(1, n3) ;

  ib = (INTIBOX) SCecon_calloc(
    n1 * sizeof(INTIMATRIX) + n1 * n2 * sizeof(INTIARRAY) +
    n1 * n2 * n3 * sizeof(INTI), 1, True,
    "Alloc_INTIBOX()") ;

  for (i = 0 ; i < n1 ; i++)
  {
      /* Set up matrix pointers to row pointer area: */
    ib[i] = (INTIMATRIX)( (char *)ib + n1 * sizeof(INTIMATRIX) +
      i * n2 * sizeof(INTIARRAY) );

      /* Set up row pointers to value area: */
    for (j = 0 ; j < n2 ; j++)
      ib[i][j] = (INTIARRAY)( (char *)ib + n1 * sizeof(INTIMATRIX) +
        n1 * n2 * sizeof(INTIARRAY) + (i * n2 + j) * n3 * sizeof(INTI));
  }

  return ib ;
}


/*,,SOH,,
*************************************************************************
*
*               Free_INTIBOX()
*
*   interface   #include <scalloc.h>
*
*               void Free_INTIBOX(INTIBOX    ib) ;
*
*   general     Frees memory allocated to UN32 by the routine
*               Alloc_INTIBOX().
*
*   input       INTIBOX  ib   Reference to matrix allocated by
*                                Alloc_INTIBOX().
*
*   output
*
*   returns
*
*   diagnostics
*
*   see also    Alloc_INTIBOX()
*
*************************************************************************
,,EOH,,*/
void Free_INTIBOX(INTIBOX  ib)
{
    SCecon_free((VOIDPTR) ib) ;
}


/*,,SOH,,
***********************************************************************
*
*               Alloc_UN32ARRAY()
*
*   interface   #include <scalloc.h>
*               UN32ARRAY Alloc_UN32ARRAY(UN32  n);
*
*   general     Allocates a vector of UN32 with zero off-set and n
*               elements, that is
*
*                       vector[0...n-1].
*
*               Returns memory with zero'ed entries.
*
*   input       UN32  n     Upper range of vector
*
*   output
*
*   returns     reference to allocated array.
*
*   diagnostics aborts calling SCecon_error()
*               with the message   "Allocation failed"
*                        routine   "Alloc_UN32ARRAY()"
*                        actioncode SCECONABORT
*               if allocation fails
*
*   see also    Free_UN32ARRAY()
*
************************************************************************
,,EOH,,*/
UN32ARRAY   Alloc_UN32ARRAY(UN32  n)
{
    UN32ARRAY ua ;

    n = GETMAX(n, 1) ;

    ua = (UN32ARRAY) SCecon_calloc(n, sizeof(UN32), True,
      "Alloc_UN32ARRAY()") ;

    return ua ;
}


/*,,SOH,,
************************************************************************
*
*               Free_UN32ARRAY()
*
*   interface   #include <scalloc.h>
*               void Free_UN32ARRAY(UN32ARRAY ua) ;
*
*   general     Frees memory allocated to UN32 by the routine
*               Alloc_UN32ARRAY().
*
*   input       UN32ARRAY ua  Reference to array allocated by
*                             Alloc_UN32ARRAY().
*   output
*
*   returns
*
*   diagnostics
*
*   see also    Alloc_UN32ARRAY()
*
************************************************************************
,,EOH,,*/
void Free_UN32ARRAY(UN32ARRAY  ua)
{
    SCecon_free((VOIDPTR) ua) ;
}


/*,,SOH,,
************************************************************************
*
*               Alloc_UN32MATRIX()
*
*   interface   #include <scalloc.h>
*               UN32MATRIX Alloc_UN32MATRIX(INTI  nr,
*                                           UN32  nc) ;
*
*    general    Allocates an UN32MATRIX with zero off-set and given
*               row and column ranges, that is
*
*                       matrix[0...nr-1][0...nc-1].
*
*               Returns memory with zero'ed entries.
*
*    input      INTI  nr    Upper range of rows.
*
*               UN32  nc    Upper range of columns.
*
*    output
*
*    returns    Reference to allocated matrix.
*
*    diagnostics aborts calling SCecon_error()
*                with the message   "Allocation failed"
*                         routine   "Alloc_UN32MATRIX()"
*                         actioncode SCECONABORT
*                if allocation fails
*
*    see also    Free_UN32MATRIX()
*
************************************************************************
,,EOH,,*/
UN32MATRIX  Alloc_UN32MATRIX(INTI  nr, UN32  nc)
{
  INTI        i ;
  UN32MATRIX  um ;

    /* For a detailed explanation of the one-chunk allocation scheme,
     * see the comment inside the Alloc_FL64MATRIX function.
     *
     * Alignment is skipped as values are 32 bit.
     */

  nr = GETMAX(1, nr) ;
  nc = GETMAX(1, nc) ;

  um = (UN32MATRIX) SCecon_calloc(
    nr * sizeof(UN32ARRAY) + nr * nc * sizeof(UN32), 1, True,
    "Alloc_UN32MATRIX()") ;

    /* Set up row pointers to value area: */
  for (i = 0 ; i < nr ; i++)
    um[i] = (UN32ARRAY)( (char *)um + nr * sizeof(UN32ARRAY) +
      i * nc * sizeof(UN32) );

  return um ;
}


/*,,SOH,,
*************************************************************************
*
*               Free_UN32MATRIX()
*
*   interface   #include <scalloc.h>
*
*               void Free_UN32MATRIX(UN32MATRIX um) ;
*
*   general     Frees memory allocated to UN32 by the routine
*               Alloc_UN32MATRIX().
*
*   input       UN32MATRIX  um   Reference to matrix allocated by
*                                Alloc_UN32MATRIX().
*
*   output
*
*   returns
*
*   diagnostics
*
*   see also    Alloc_UN32MATRIX()
*
*************************************************************************
,,EOH,,*/
void Free_UN32MATRIX(UN32MATRIX  um) 
{
    SCecon_free((VOIDPTR) um) ;
}


/*,,SOH,,
***********************************************************************
*
*               Alloc_FL64BOX()
*
*   interface   #include <scalloc.h>
*               FL64BOX  Alloc_FL64BOX(INTI n1,
*                                      INTI n2,
*                                      INTI n3);
*
*   general     Allocates a box of FL64 with n entries with zero
*               off-set, that is
*
*                       box[0..n1-1][0..n2-1][0..n3-1]
*
*               Returns memory with zero'ed entries.
*
*   input       INTI  n1     Upper range of box   .
*
*               INTI  n2     Medium range of box   .
*
*               INTI  n3     Lower range of box   .
*
*   output
*
*   returns     reference to allocated array.
*
*   diagnostics aborts calling SCecon_error()
*               with the message   "Allocation failed"
*                        routine   "Alloc_FL64BOX()"
*                        actioncode SCECONABORT
*               if allocation fails
*
*   see also    Free_FL64BOX()
*
***********************************************************************
,,EOH,,*/

FL64BOX Alloc_FL64BOX(INTI  n1, INTI  n2, INTI  n3)
{
  FL64BOX b ;
  INTI i, j, nrow ;

    /* One-chunk-allocation scheme as in FL64MATRIX, except of course,
     * that there is an extra layer of pointers. Also refer to the
     * comment inside Alloc_FL64MATRIX for more information.
     *
     * The corresponding example with dimension 2, 3, 2, i.e. one box,
     * built as n1=2 matrices, n1*n2=6 rows and n1*n2*n3=12 values looks
     * like this:
     *
     *                              "Wasted" space for alignment if odd
     *                              number of row pointers (sizeof(ptr))
     *                                                               |
     *     -----------------------------------------------------     |
     *     |    b[0]    |    b[1]    |   b[0][0]  |   b[0][1]  |     |
     *     | ptr2mtx 0  | ptr2mtx 1  |ptr2row 0,0 |ptr2row 0,1 |     |
     *     -------------------------------------------------------   |
     *     |   b[0][2]  |   b[1][0]  |   b[1][1]  |   b[1][2]  |X|___|
     *     |ptr2row 0,2 |ptr2row 1,0 |ptr2row 1,1 |ptr2row 1,2 |X|
     *     -------------------------------------------------------
     *     | start of row 0,0 values |                         |
     *     |       b[0][0][0]        |       b[0][0][1]        |
     *     -----------------------------------------------------
     *     | start of row 0,1 values |                         |
     *     |       b[0][1][0]        |       b[0][1][1]        |
     *     -----------------------------------------------------
     *     | start of row 0,2 values |                         |
     *     |       b[0][2][0]        |       b[0][2][1]        |
     *     -----------------------------------------------------
     *     | start of row 1,0 values |                         |
     *     |       b[1][0][0]        |       b[1][0][1]        |
     *     -----------------------------------------------------
     *     | start of row 1,1 values |                         |
     *     |       b[1][1][0]        |       b[1][1][1]        |
     *     -----------------------------------------------------
     *     | start of row 1,2 values |                         |
     *     |       b[1][2][0]        |       b[1][2][1]        |
     *     -----------------------------------------------------
     */

  n1 = GETMAX(1, n1) ;
  n2 = GETMAX(1, n2) ;
  n3 = GETMAX(1, n3) ;

    /* If total number of pointers needed is odd, allocate an extra
     * alignment element (needed on some compilers):
     */
  if( (n1 + n1 * n2) % 2 )
    nrow = n1 * n2 + 1 ;
  else
    nrow = n1 * n2 ;

  b = (FL64BOX) SCecon_calloc(
    n1 * sizeof(FL64MATRIX) + nrow * sizeof(FL64ARRAY) +
    n1 * n2 * n3 * sizeof(FL64), 1, True, "Alloc_FL64BOX()") ;

  for (i = 0 ; i < n1 ; i++)
  {
      /* Set up matrix pointers to row pointer area: */
    b[i] = (FL64MATRIX)( (char *)b + n1 * sizeof(FL64MATRIX) +
      i * n2 * sizeof(FL64ARRAY) );

      /* Set up row pointers to value area: */
    for (j = 0 ; j < n2 ; j++)
      b[i][j] = (FL64ARRAY)( (char *)b + n1 * sizeof(FL64MATRIX) +
        nrow * sizeof(FL64ARRAY) + (i * n2 + j) * n3 * sizeof(FL64));
  }

  return b ;
}

/*,,SOH,,
***********************************************************************
*
*               Alloc_FL64DIM4()
*
*   interface   #include <scalloc.h>
*               FL64DIM4  Alloc_FL64DIM4(INTI n1,
*                                        INTI n2,
*                                        INTI n3,
*                                        INTI n4) ;
*
*   general     Allocates a 4 dimensional box of FL64 with n entries with zero
*               off-set, that is
*
*                       box[0..n1-1][0..n2-1][0..n3-1][0..n4-1]
*
*               Returns memory with zero'ed entries.
*
*   input       INTI  n1     First dimension.
*
*               INTI  n2     Second dimension.
*
*               INTI  n3     Third dimension.
*
*               INTI  n4     Fourth dimension.
*
*   output
*
*   returns     reference to allocated box.
*
*   diagnostics aborts calling SCecon_error()
*               with the message   "Allocation failed"
*                        routine   "Alloc_FL64DIM4()"
*                        actioncode SCECONABORT
*               if allocation fails
*
*   see also    Free_FL64DIM4()
*
***********************************************************************
,,EOH,,*/

FL64DIM4  Alloc_FL64DIM4(INTI n1, INTI n2, INTI n3, INTI n4)
{
  FL64DIM4 b ;
  INTI i, j, k, nrow ;

    /* One-chunk-allocation scheme as in FL64BOX, except of course,
     * that there is an extra layer of pointers. Also refer to the
     * comment inside Alloc_FL64BOX for more information. */

  n1 = GETMAX(1, n1) ;
  n2 = GETMAX(1, n2) ;
  n3 = GETMAX(1, n3) ;
  n4 = GETMAX(1, n4) ;

    /* If total number of pointers needed is odd, allocate an extra
     * alignment element (needed on some compilers):
     */
  if( (n1 + n1 * n2 + n1*n2*n3) % 2 )
    nrow = n1 * n2 * n3 + 1 ;
  else
    nrow = n1 * n2 * n3 ;

  b = (FL64DIM4) SCecon_calloc(n1 * sizeof(FL64BOX) + 
    n1 * n2 * sizeof(FL64MATRIX) + nrow * sizeof(FL64ARRAY) +
    n1 * n2 * n3 * n4 * sizeof(FL64), 1, True,
    "Alloc_FL64DIM4()") ;

  for (i = 0; i < n1; i++)
  {
    b[i] = (FL64BOX)( (char *)b + n1 * sizeof(FL64BOX) +
      i * n2 * sizeof(FL64MATRIX)) ;

    for (j = 0 ; j < n2 ; j++)
    {
        /* Set up matrix pointers to matrix pointer area: */
      b[i][j] = (FL64MATRIX)( (char *)b + n1 * sizeof(FL64BOX) +
        n1 * n2 * sizeof(FL64MATRIX) + 
        (i * n2 + j) * n3 * sizeof(FL64ARRAY)) ;

        /* Set up row pointers to value area: */
      for (k = 0 ; k < n3 ; k++)
        b[i][j][k] = (FL64ARRAY)( (char *)b + n1 * sizeof(FL64BOX) + 
          n1 * n2 * sizeof(FL64MATRIX) + nrow * sizeof(FL64ARRAY) + 
          ((i * n2 + j) * n3 + k) * n4 * sizeof(FL64)) ;
    }
  }

  return b ;
}


/*,,SOH,,
************************************************************************
*
*               Free_FL64BOX()
*
*   interface   #include <scalloc.h>
*
*               void Free_FL64BOX(FL64BOX    b) ;
*
*   general     Frees memory allocated to FL64 by the routine
*               Alloc_FL64BOX().
*
*   input       FL64BOX  b    Reference to matrix allocated by
*                                Alloc_FL64BOX().
*
*   output
*
*   returns
*
*   diagnostics
*
*   see also    Alloc_FL64BOX()
*
************************************************************************
,,EOH,,*/
void Free_FL64BOX(FL64BOX  b)
{
    SCecon_free((VOIDPTR) b) ;
}

/*,,SOH,,
************************************************************************
*
*               Free_FL64DIM4()
*
*   interface   #include <scalloc.h>
*
*               void Free_FL64DIM4(FL64DIM4    b) ;
*
*   general     Frees memory allocated to FL64 by the routine
*               Alloc_FL64DIM4().
*
*   input       FL64DIM4  b    Reference to matrix allocated by
*                              Alloc_FL64DIM4().
*
*   output
*
*   returns
*
*   diagnostics
*
*   see also    Alloc_FL64DIM4()
*
************************************************************************
,,EOH,,*/
void Free_FL64DIM4(FL64DIM4  b)
{
    SCecon_free((VOIDPTR) b) ;
}

/*,,SOH,,
************************************************************************
*
*                Set_FL64LIST()
*
*   interface    #include <scalloc.h>
*                FL64LIST Set_FL64LIST(FL64ARRAY array,
*                                      INTI      size) ;
*
*   general      This routine sets the members of the struct defined
*                in the function name. The pointer members are simply
*                assigned - without physical copying. The intention
*                of the Set_*() routines is that by using this
*                functionality, one avoids setting individual members
*                of structs in the application code.
*
*                When new members are inserted in structs the Set_*()
*                routine will be changed accordingly.
*
*                For details on the interpretation of the individual
*                struct members please check the struct definition.
*
*   input        FL64ARRAY array  See general section.
*
*                INTI      size   Size of the array
*
*   output
*
*   returns      The filled out FL64LIST struct
*
*   diagnostics
*
*   see also     FL64LIST
*
************************************************************************
,,EOH,,*/


FL64LIST Set_FL64LIST(FL64ARRAY  array,
                         INTI       size)
{
  FL64LIST list;
  list.array = array;
  list.size = size;
  return list;
}



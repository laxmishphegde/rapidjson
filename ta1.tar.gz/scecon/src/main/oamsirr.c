/************************************************************************
*
*   project     SCecon
*
*   filename    oamsirr.c
*
*   contains    routines in the SCecon Library IRR module (Internal Rate Return)
*
************************************************************************/

/***** includes ********************************************************/
#include "oamsirr.h"

/************************************************************************
**
**  Function    : Irr_OamsCompute()
**
**  Description : IRR (internal rate of return) computation
**
**  Arguments   : irrConv		IRR convention
**                iniMktVal		initial market value
**                flowArray		array filled with flows
**                periodArray	array filled with the periods
**                flowNbr		number of element in arrays
**                ctrl			iteration control
**                irr			returned and computed IRR
**
**  Return      : BOOLE
**
**  Creation  	: REF10663 - TEB - 041125
**
**  Modification: 
**
*************************************************************************/
BOOLE Irr_OamsCompute(IRRCONV     irrConv,
                      FL64        iniMktVal,
                      FL64ARRAY   flowArray,
                      FL64ARRAY   periodArray,
                      INTI        flowNbr,
					  ITERCTRL    *ctrl,
                      FL64*       irr)
{
	NR_ERR      err;
	BOOLE		ok;
	IRR_ST		irr_param;

	/* PMSTA-22396 - SRIDHARA � 160502 */
	HOLI_STR holi;
	holi = Set_HOLI_STR(NO_BUSADJUST, 0, NULL);

    /* Initialise */
	Init_ITERCTRL(ctrl) ;

	/* This settings seems to be efficient */
/* DDB - PMSTA-4263 : change 150 -> 500
    ctrl->maxiter	= 150 ;
*/
    ctrl->maxiter	= 500 ;
    ctrl->init_guess = 0.01 ;
    ctrl->lower		= -1 ;
    ctrl->upper		= 1;
    ctrl->damp		= 1 ;
/*    ctrl->acc		= 0.0000000001 ; */
    ctrl->acc		= 0.0000001 ;	/* DDB - 071008 - as precision in Triple'a is 5 numbers for %, we drop 2 zeros */
    ctrl->what_acc	= 1 ;
    ctrl->gfreq		= 5 ;
    ctrl->bisec		= 1 ;
    ctrl->shock		= 0.0 ;

    irr_param.period=periodArray;
    irr_param.flow=flowArray;
    irr_param.nbFlow=flowNbr;
    irr_param.initMV=iniMktVal;

	switch(irrConv)
	{
	case COMPOUND:
		err = Newton_Raphson(&IRRCompound_NewtonRaphson, &irr_param, ctrl, irr, &holi); 	/* PMSTA-22396 - SRIDHARA � 160502 */
		break;
	case COMPOUNDSIMPLE:
		err = Newton_Raphson(&IRRCompoundSimple_NewtonRaphson, &irr_param, ctrl, irr, &holi); 	/* PMSTA-22396 - SRIDHARA � 160502 */
		break;
	default:
		err = NR_FUNCTION_COMPUTATION_ERR;
		break;
	}

    ok = (err == NR_ROOT_FOUND ? True : False) ;
    return ok ;
}


/************************************************************************
**
**  Function    : IRRCompound_NewtonRaphson()
**
**  Description : Formula for compound IRR (sysparam =0)
**
**  Arguments   : standard args for Newton Raphson
**
**  Return      : BOOLE
**
**  Creation  	: REF10663 - TEB - 041125
**
**  Modification: 
**
*************************************************************************/
BOOLE IRRCompound_NewtonRaphson(FL64  x, void*  y, BOOLE  grad, FL64*  fx, FL64*  dfx, void* hol)
{
	/* PMSTA-29444 - SRIDHARA - 050318 */
	HOLI_STR    holi = (*(HOLI_STR *)hol);
	holi = Set_HOLI_STR(NO_BUSADJUST, 0, NULL);

	IRR_STP irr_param;
	int i, j;
	double SA, tmpDiv;

	/* Init */
	irr_param = (IRR_STP )y;
	*fx = 0.0;

	/* To avoid zero divisions */
	if (x == -1)
	{
		return True;
	}

	for (i=0; i< (irr_param->nbFlow-1); i++)
	{
		SA = 0.0;
		for (j=0; j<=i; j++)
		{
			SA = SA+irr_param->period[j];
		}

		tmpDiv = pow((1+x),SA);
		if (tmpDiv !=0.0)
		{
			*fx = (*fx) + irr_param->flow[i]/tmpDiv;
		}
		else
		{
			return True;
		}
	}

	*fx = (*fx) - irr_param->initMV + irr_param->flow[(irr_param->nbFlow-1)] / (1+x);

	if (grad == True)
	{
		*dfx = 0.0;

		for (i=0; i< (irr_param->nbFlow-1); i++)
		{
			SA = 0.0;
			for (j=0; j<=i; j++)
			{
				SA = SA+irr_param->period[j];
			}

			tmpDiv = pow((1+x),(SA+1));
			if (tmpDiv !=0.0)
			{
				*dfx = (*dfx) - (irr_param->flow[i]*SA)/tmpDiv -  irr_param->flow[(irr_param->nbFlow-1)] /((1+x)*(1+x)) ;
			}
			else
			{
				return True;
			}
		}
	}

	return True;
}


/************************************************************************
**
**  Function    : IRRCompoundSimple_NewtonRaphson()
**
**  Description : Formula for compound simple IRR (sysparam =1)
**
**  Arguments   : standard args for Newton Raphson
**
**  Return      : BOOLE
**
**  Creation  	: REF10663 - TEB - 041125
**
**  Modification: 
**
*************************************************************************/
BOOLE IRRCompoundSimple_NewtonRaphson(FL64  x, void*  y, BOOLE  grad, FL64*  fx, FL64*  dfx, void *hol)
{
	/* PMSTA-29444 - SRIDHARA - 050318 */
	HOLI_STR    holi = (*(HOLI_STR *)hol);
	holi = Set_HOLI_STR(NO_BUSADJUST, 0, NULL);

	IRR_STP irr_param;
	int i, j;
	double SA, tmpDiv;

	/* Init */
	irr_param = (IRR_STP )y;
	*fx = 0.0;

	/* To avoid zero divisions */
	if (x == -1)
	{
		return True;
	}

	for (i=0; i< (irr_param->nbFlow-1); i++)
	{
		SA = 0.0;
		for (j=0; j<=i; j++)
		{
			SA = SA+irr_param->period[j];
		}

		tmpDiv = 1+x*SA;
		if (tmpDiv != 0)
		{
			*fx = (*fx) + irr_param->flow[i]/tmpDiv;
		}
		else
		{
			return True;
		}
	}

	*fx = (*fx) - irr_param->initMV + irr_param->flow[(irr_param->nbFlow-1)] / (1+x);

	if (grad == True)
	{
		*dfx = 0.0;

		for (i=0; i< (irr_param->nbFlow-1); i++)
		{
			SA = 0.0;
			for (j=0; j<=i; j++)
			{
				SA = SA+irr_param->period[j];
			}

			tmpDiv = 1+x*SA;
			if (tmpDiv != 0)
			{
				*dfx = (*dfx) - (irr_param->flow[i]*SA)/(tmpDiv*tmpDiv)  -  irr_param->flow[(irr_param->nbFlow-1)] /((1+x)*(1+x)) ;
			}
			else
			{
				return True;
			}
		}
	}

	return True;
}

/************************************************************************
**      END  oamsirr.c                                          
*************************************************************************/

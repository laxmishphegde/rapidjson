/* SCID @(#)plan.c	1.28 (SimCorp) 99/08/10 10:22:18 */

/************************************************************************
*
*   project     SCecon
*
*   file name   plan.c
*
*   general     This file contains standard routines for calendar
*               calculations
*
************************************************************************/

/* includes ************************************************************/
#include <cldr.h>
#include <pmt.h>


/*,,SOH,,
*************************************************************************
*
*                Cldr_Holding2Amort()
*
*    interface   #include <cldr.h>
*                PLAN_STR* Cldr_Holding2Amort(DATESTR   *start,
*                                             DATESTR   *matur,
*                                             PLAN_STR  *holding);
*
*    general     The function translates a structure of nominal holdings
*                into a corresponding structure of amortisations.
*
*                The initial holding must be 100. The figures must be
*                scaled to ensure this. A holding structure that
*                doubles during the life of a contract will start
*                with 100 and change to 200 at a later date.
*                A holding structure that halves during the life of a
*                contract will start with 100 and change to 50 at a later
*                date.
*
*                If the holding on the start date is different from 100,
*                this will be ignored.
*
*    input       DATESTR   *start    Pointer to input date.
*
*                DATESTR   *matur    Pointer to input date.
*
*                PLAN_STR  *holding  The holding structure defines the
*                                    notional amount of an instrument.
*                                    If no holding schedule is defined,
*                                    use NULL. Each entry in the holding
*                                    structure defines the holding from
*                                    start (inclusive) to the next date
*                                    specified (exclusive) or matur.
*                                    The holding must be 100 on the start
*                                    date.
*
*    output
*
*    returns    The amortisation structure. Allocated in this routine
*               as: Alloc_PLANARRAY(1, n), where n is the number of
*               elements in the holding structure plus one.
*
*    diagnostics
*
*    see also
*
*************************************************************************
,,EOH,,*/

PLAN_STR* Cldr_Holding2Amort(DATESTR*   start,
                                DATESTR*   matur,
                                PLAN_STR*  holding)
{
  PLAN_STR  *amort;
  INTI      i, filled, nhold;
  FL64      prevhold;

  if (holding == NULL)
    return NULL;

  nhold = GetPlanFill(holding);

  /* Max one extra amortisations is inserted (at the end). */
  amort = Alloc_PLANARRAY(1, nhold+1);

  /* Previous holding */
  prevhold = 100.0;
  filled = 0;
  i = 0;

  /* Ignore holdings before and on start date */
  while (i < nhold && Cldr_DateLE(&holding->day[i], start))
  {
    i++;
  }

  while (i < nhold && Cldr_DateLT(&holding->day[i], matur))
  {
    amort->day[filled] = holding->day[i];
    amort->f64[filled++] = prevhold - holding->f64[i];
    prevhold = holding->f64[i++];
  }

  if (prevhold > PMT_TOL)
  {
    /* Instrument is not fully amortised */
    amort->day[filled] = *matur;
    amort->f64[filled++] = prevhold;
  }
  amort->filled = filled;

  return amort;
}

    
/*,,SOH,,
*************************************************************************
*
*                Cldr_InsertInPlan()
*
*    interface   #include <cldr.h>
*                INTI  Cldr_InsertInPlan(DATESTR   *date,
*                                        FL64      f64,
*                                        PLAN_STR  *plan,
*                                        BOOLE     override) ;
*
*    general     The function inserts a day/f64 combination in a
*                PLAN_STR.
*
*                If no space is available (filled == count in plan)
*                then nothing is done unless the date is already in
*                the plan and override is True.
*
*                This function is used in the bootstrp module when
*                volatility/discount functions are sequentially
*                generated - and filled into a PLAN_STR.
*
*    input       DATESTR   *date     Pointer to input date.
*
*                FL64      f64       the float related to date.
*
*                PLAN_STR  *plan     Plan structure
*                                    NULL or ->filled = 0 for empty
*
*                BOOLE     override  If True an entry on the actual day
*                                    is overwritten otherwise left
*                                    unchanged.
*
*    output
*
*    returns     Number of filled data in the plan.
*
*    diagnostics
*
*    see also    Cldr_InsertInPlanYMD()
*
*************************************************************************
,,EOH,,*/

INTI  Cldr_InsertInPlan(DATESTR* date,
                          FL64      f64,
                          PLAN_STR*  plan,
                          BOOLE override)
{
    DATESTR  *pdays ;
    FL64     *pf64 ;
    INTI     i, ix, nfill, ncount ;
    BOOLE    space ;

    space = True ;

    pdays  = GetPlanDay(plan) ;
    pf64   = GetPlanF64(plan) ;
    nfill  = GetPlanFill(plan) ;
    ncount = GetPlanCount(plan) ;

    /* check sizes first */
    if (nfill > ncount)
        space = False ;
    if (nfill == ncount && override == False)
        space = False ;
    if (ncount <= 0)
        space = False ;

    if (space == True)
    {
        /* Find index of next element */
        ix = Cldr_FindDateIndex(pdays, nfill, date, 0,
                                 SEARCH_BISECTION, SAMEINDEX) ;

        /* After the last ?? */
        if (ix >= nfill)
        {
            if (nfill < ncount)
            {
                pf64[nfill]  = f64 ;
                pdays[nfill] = *date ;
                plan->filled++, nfill++ ;
            }
        }

        /* Equal to an element */
        else if (Cldr_DateEQ(date, &pdays[ix]) == True)
        {
            if (override == True)
            {
                pf64[ix]  = f64 ;
                pdays[ix] = *date ;
            }
        }

        /* Just insert and move upwards */
        else
        {
            if (nfill < ncount)
            {
                for (i = nfill - 1 ; i >= ix ; i--)
                {
                    pf64[i + 1]  = pf64[i] ;
                    pdays[i + 1] = pdays[i] ;
                }
                pf64[ix]  = f64 ;
                pdays[ix] = *date ;
                plan->filled++, nfill++ ;
            }
        }
    }

    return nfill ;
}


/*,,SOH,,
*************************************************************************
*
*                Cldr_InsertInPlanYMD()
*
*    interface   #include <cldr.h>
*                INTI  Cldr_InsertInPlanYMD(YYYYMMDD  date,
*                                        FL64      f64,
*                                        PLAN_STR  *plan,
*                                        BOOLE     override) ;
*
*    general     The function inserts a day/f64 combination in a
*                PLAN_STR using Cldr_InsertInPlan().
*
*    input       YYYYMMDD  date      The input date.
*
*                FL64      f64       the float related to date.
*
*                PLAN_STR  *plan     Plan structure
*                                    NULL or ->filled = 0 for empty
*
*                BOOLE     override  If True an entry on the actual day
*                                    is overwritten otherwise left
*                                    unchanged.
*
*    output
*
*    returns     Number of filled data in the plan.
*
*    diagnostics
*
*    see also    Cldr_YMD2Datestr()
*                Cldr_InsertInPlan()
*
*************************************************************************
,,EOH,,*/
INTI  Cldr_InsertInPlanYMD(YYYYMMDD date,
                          FL64      f64,
                          PLAN_STR*  plan,
                          BOOLE override)
{
    DATESTR  ddate ;

    ddate = Cldr_YMD2Datestr(date);

    return Cldr_InsertInPlan(&ddate, f64, plan, override);
}


/************************************************************************
*
*               Cldr_Plan_Intpol()
*
*    interface  #include <cldr.h>
*               FL64 Cldr_Plan_Intpol(DATESTR    *date,
*                                     PLAN_STR   *d,
*                                     CALCONV    cal,
*                                     INTPOLCONV iconv) ;
*
*    general    The function performs interpolation in a PLANARRAY
*               using day count as x-values.
*
*               Only simple linear interpolation is used.
*
*               Any adjustment for businessdays must be performed
*               prior to calling this function.
*
*    input      DATESTR   *date   The date for which an interpolated
*                                 value is sought.
*                                 Must be after the first date in the
*                                 PLANARRAY.
*
*               PLAN_STR  *d      The plan in which to interpolate
*
*               CALCONV   cal     Calendar convention for interpolating
*                                 between dates
*
*               INTPOLCONV iconv  Interpolation convention for
*                                 interpolating between dates.
*                                 Can be LINEAR_EXTRALPOL or
*                                 LINEAR_FLAT_END
*
*	       	    HOLI_STR  *holi	  Container for list of holidays.
*
*    output
*
*    returns    The interpolated factor. If date is before
*               the first day, 0.0 is returned.
*
*    diagnostics
*
*    see also   Math_Interpolation()
*
************************************************************************/


FL64 Cldr_Plan_Intpol(DATESTR* date, PLAN_STR*  d, 
                         CALCONV cal, INTPOLCONV iconv,
						 HOLI_STR* holi)
{
    INTI     ix, nfill ;
    DATESTR  *pday, d_tlo, d_tup ;
    FL64     *pf64, disc, dlo, dup ;
    INTL     ds1, ds2 ;

    nfill = GetPlanFill(d) ;
    pday  = GetPlanDay(d) ;
    pf64  = GetPlanF64(d) ;

    /* Branch to find relevant case */
    if (nfill == 0)
        disc = 0.0 ;

    else if (nfill == 1)
        disc = pf64[0] ;

    else if (Cldr_DateLT(date, &pday[0]) == True)
        disc = pf64[0] ;

    else if (iconv == LINEAR_FLAT_END && 
             Cldr_DateLT(&pday[nfill - 1], date) == True)
        disc = pf64[nfill - 1] ;

    else if (nfill == 2)
    {
		/* PMSTA-22396 - SRIDHARA � 160502 */
        ds1 = Cldr_DaysBetweenDates(&pday[0], date, cal, holi) ;
        ds2 = Cldr_DaysBetweenDates(&pday[0], &pday[1], cal, holi) ;

        disc = Math_linintpol(0.0, (FL64) ds2, pf64[0], pf64[1],
                             (FL64) ds1, True) ;
    }
    else
    {
        /* Now look for interpolation */
        ix = Cldr_FindDateIndex(d->day, nfill, date, 0,
                                 SEARCH_BISECTION, SAMEINDEX) ;

        if (ix == 0)
            disc = pf64[0] ;

        else
        {
            if (ix < nfill)
            {
                /* This is the standard case */
                dlo = pf64[ix - 1] ;
                dup = pf64[ix] ;
                d_tlo = pday[ix - 1] ;
                d_tup = pday[ix] ;
            }
            else
            {
                /* Here prepare for extrapolation */
                dlo = pf64[ix - 2] ;
                dup = pf64[ix - 1] ;
                d_tlo = pday[ix - 2] ;
                d_tup = pday[ix - 1] ;
            }

			/* PMSTA-22396 - SRIDHARA � 160502 */
            ds1 = Cldr_DaysBetweenDates(&d_tlo, date, cal, holi) ;
            ds2 = Cldr_DaysBetweenDates(&d_tlo, &d_tup, cal, holi) ;

            /* Do linear interpolation */
            disc = Math_linintpol(0.0, (FL64) ds2, dlo, dup, (FL64) ds1, True) ;
        }
    }

    return disc ;
}


/*,,SOH,,
************************************************************************
*
*                Set_PLAN_STR()
*
*   interface    #include <cldr.h>
*                PLAN_STR Set_PLAN_STR(INTI      count,
*                                      INTI      filled,
*                                      DATEARRAY day,
*                                      FL64ARRAY f64) ;
*
*   general      This routine sets the members of the struct defined
*                in the function name. The pointer members are simply
*                assigned - without physical copying. The intention
*                of the Set_*() routines is that by using this
*                functionality, one avoids setting individual members
*                of structs in the application code.
*
*                When new members are inserted in structs the Set_*()
*                routine will be changed accordingly.
*
*                For details on the interpretation of the individual
*                struct members please check the struct definition.
*
*   input        INTI      count    See general section.
*
*                INTI      filled   See general section.
*
*                DATEARRAY day      See general section.
*
*                FL64ARRAY f64      See general section.
*
*   output
*
*   returns      The filled out PLAN_STR struct
*
*   diagnostics
*
*   see also     PLAN_STR
*
************************************************************************
,,EOH,,*/

PLAN_STR Set_PLAN_STR(INTI       count,                
                         INTI       filled,               
                         DATEARRAY  day,                  
                         FL64ARRAY  f64)
{
    PLAN_STR plan ;

    plan.count  = count ;
    plan.filled = filled ;
    plan.day    = day ;
    plan.f64    = f64 ;

    return plan ;
}



/*,,SOH,,
************************************************************************
*
*                Cldr_PlanLookup()
*
*   interface    #include <cldr.h>
*                FL64 Cldr_PlanLookup (FL64      def,                
*                                      PLAN_STR* plan,               
*                                      DATESTR*  day,
*                                      INTI*     ix)       
*
*   general      This function looks up the value for a date in a plan. 
*                If the plan is empty or the first date in the plan is
*                after the inputdate, the default value is returned.
*                Otherwise the value corresponding to the date in the 
*                plan immediately before the input date is returned.
*
*                This is in particular useful to find the actual strike
*                in a stepped strike setting.
*
*   input        FL64      def    The default value.
*
*                PLAN_STR  *plan  The plan of dates and values.
*
*                DATESTR   *day   The date for which a value is sought.
*
*   inout        INTI      *ix    Index pointing to plan. 
*                                 If ix points to a date after date, then 
*                                 def is returned.
*                                 On exit ix points to the value after the
*                                 returned value in the structure, if one
*                                 was found. Otherwise, ix is returned 
*                                 unchanged.
*
*   output       
*
*   returns      The value corresponding to *day.
*
*   diagnostics
*
*   see also     Cldr_Plan_Intpol
*
***********************************************************************
,,EOH,,*/

FL64 Cldr_PlanLookup(FL64      def,                
                     PLAN_STR* plan,               
                     DATESTR*  day,
                     INTI*     ix)             
                        
{
  FL64ARRAY f64;
  DATEARRAY days;
  INTI i, n, old_ix;
  FL64 result;

  n = GetPlanFill(plan) ;
  result = def;
  if (0 < n && *ix < n)
  {
    /* Grab arrays and move pointer ahead according to *ix: */
    f64  = GetPlanF64(plan) ;
    f64 += *ix;
    days  = GetPlanDay(plan) ;
    days += *ix;
    n -= *ix;

    old_ix = *ix;

    /* Do search in resulting date array: */
    if (old_ix == 0)
      /* We starting, so the right one might be anywhere in the array.
         Do bisectional search: */
      i = Cldr_FindDateIndex(days, n, day,
                            0, SEARCH_BISECTION, NEXTINDEX) ;
    else
      /* Starting inside array, so we are probably just moving one step
         ahead. Therefore we do forward search: */
      i = Cldr_FindDateIndex(days, n, day,
                            0, SEARCH_FORWARDS, NEXTINDEX) ;

    /* We now have 
             (i > 0 implies days[i - 1] <= day) 
       and 
             (i < n implies day < days[i]) 
    */
    if (0 < i && i < n)
    {
      *ix = i + old_ix;
      result = f64[i - 1] ;
    }
    else if (0 < i && i == n)
    {
      *ix = i + old_ix;
      result = f64[n - 1];
    }
  }

  return result;
}



/* SCID @(#)cldr2trm.c	1.23 (SimCorp) 99/06/14 13:26:15 */

/************************************************************************
*
*   project     SCecon
*
*   file name   cldr2trm.c
*
*   general     This file contains standard routines for calendar
*               calculations
*
************************************************************************/

/* includes ************************************************************/

#include <cldr.h>


/*,,SOH,,
*************************************************************************
*
*               Cldr_TermBetweenDates()
*
*    interface  #include <cldr.h>
*               FL64 Cldr_TermBetweenDates(DATESTR *inPrimo,
*                                          DATESTR *inUltimo,
*                                          INTI    qb,
*                                          CALCONV cal,
*                                          EOMCONV eom) ;
*
*    general    Cldr_TermBetweenDates() calculates the time between
*               the two input dates in fractional periods, taking
*               into account the number of annual periods, end of
*               month convention and calendar convention.
*
*               If input freq is 0 then the usual daycount fraction
*               returned.
*               If freq is higher - 1, 2, 4, 6 or 12 - then the term
*               is found by "counting" backwards from date2 to date1
*               by simply adding the 'period' sufficiently often.
*
*               In this way the following results are found if date1
*               is 19880110 and date2 is 19890110.
*
*                   freq  EU30360  ACT360  ACT365  ACTACT  ACTLEAP
*                   ----------------------------------------------
*                     0      1     1.0167  1.0027     1    1.00007
*                     1      1       1        1       1       1
*                     2      2       2        2       2       2
*                     4      4       4        4       4       4
*                     6      6       6        6       6       6
*                    12     12      12       12      12      12
*
*               For uneven periods the results will vary with the
*               calendar.
*
*    input      DATESTR   *inPrimo      Pointer to the first date in
*                                       the period.
*
*               DATESTR   *inUltimo     Pointer to the last date in the
*                                       period.
*
*               INTI      qb            The number of annual periods,
*                                       eg. 1 is annual, 12 is monthly
*                                       etc.
*                                       Eligible values are 0, 1, 2, 4
*                                       6 or 12.
*
*               CALCONV   cal           The calendar convention.
*
*               EOMCONV   eom           The end of month convention.
*
*	       	    HOLI_STR  *holi	        Container for list of holidays.
*
*    output
*
*    returns    the time between the two dates in fraction of the
*               unit period length as FL64.
*
*    diagnostics
*
*    see also   Cldr_DaysBetweenDates()
*               Cldr_Dates2Terms()
*               Cldr_Ymd2Terms()
*               Cldr_ComputeTerms()
*
*    wrapper    AP
*
*************************************************************************
,,EOH,,*/


FL64 Cldr_TermBetweenDates(DATESTR* inPrimo,
                           DATESTR*  inUltimo,
                           INTI      qb,      /* frequency */
                           CALCONV   cal,
                           EOMCONV   eom,
						   HOLI_STR* holi)
{
    DATESTR d1, d2, db;
    FL64    d, p, term;
    BOOLE   sign;

	/* PMSTA-23331 - SRIDHARA � 160516 */
	FL64  busFactor = 252.0 / 365.0;
	FL64  maxDaysInYear = 365.0;

    /* warning avoidance */
    memset(&db, 0, sizeof(db));

    if (qb == 0)
    {
        term  = (FL64) Cldr_DaysBetweenDates(inPrimo, inUltimo, cal, holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */
        term /= Cldr_DaysPerYear(inPrimo, inUltimo, 0, cal, eom, holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */
        return term ;
    }

    sign = Cldr_DateLT(inUltimo, inPrimo);

    if (sign == True)
    {
        d1        = *inUltimo;
        *inUltimo = *inPrimo;
        *inPrimo  = d1;
    }

    d1   = *inUltimo;
    term = 0.0;

	/* PMSTA-23331 - SRIDHARA � 160516 */
	if (cal == BUS252)
	{
		term = (FL64)Cldr_DaysBetweenDates(inPrimo, inUltimo, cal, holi);

		switch (qb)
		{
		case 12:
			/* 1 month = �30 days */
			term = term / (30.0 * busFactor);
			break;

			/* 1 quarter = �90 days */
		case 4:
			term = term / (90.0 * busFactor);
			break;

			/* 1 semester = �180 days */
		case 2:
			term = term / (180.0 * busFactor);
			break;

			/* 1 year = �360 days */
		case 1:
			term = term / ((double)maxDaysInYear * busFactor);
			break;

		default:
			break;
		}
	}
	else
	{

		while (Cldr_DateLT(inPrimo, &d1) == True)
		{
			db = d1;
			d1 = d2 = Cldr_AddMonths(&d1, -12 / qb, eom);
			term += 1.0;
		}

		if (Cldr_DateEQ(&d1, inPrimo) == False)
		{
			d2 = db;
			if (cal == ACT365 || cal == EU30E365 || cal == ACTNL365)
				p = 365.0 / ((FL64)qb);

			else if (cal == ACT360 || cal == EU30360 || cal == EU30E360 ||
				cal == US30360 || cal == US30E360)
				p = 360.0 / ((FL64)qb);

			else
				p = (FL64)Cldr_DaysBetweenDates(&d1, &d2, cal, holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */

			d = (FL64)Cldr_DaysBetweenDates(inPrimo, &d2, cal, holi); 	/* PMSTA-22396 - SRIDHARA � 160502 */
			term -= (1.0 - d / p);
		}
	}

    if (sign == True)
    {
        d1        = *inUltimo;
        *inUltimo = *inPrimo;
        *inPrimo  = d1;
        term     *= -1.0;
    }

    return term;
}


/*,,SOH,,
*************************************************************************
*
*               Cldr_Ymd2Terms()
*
*   interface   #include <cldr.h>
*               FL64ARRAY Cldr_Ymd2Terms(YYYYMMDD  date1,
*                                        INTI      count,
*                                        YMDARRAY  date2,
*                                        CALCONV   cal,
*                                        EOMCONV   eom,
*                                        INTI      qbas) ;
*
*   general     Cldr_Ymd2Terms() calculates the terms between the
*               start date, date1, and each of the dates in the
*               array of dates, date2.
*
*   input       YYYYMMDD  date1  The first day of the period.
*
*               INTI      count  The number of dates in date2
*
*               YMDARRAY  date2  Array of the final days of the period.
*
*               CALCONV   cal    The calendar convention.
*
*               EOMCONV   eom    The end of month convention.
*
*               INTI      qbas   The number of annual periods, Must be
*                                one of 0, 1, 2, 4, 6 or 12.
*                                See function Cldr_TermBetweenDates()
*                                for details.
*
*	       	    HOLI_STR  *holi	 Container for list of holidays.
*
*   output
*
*   returns     The array of terms between date1 and the days of date2.
*               Allocated in this routine as Alloc_FL64ARRAY(count)
*
*   diagnostics
*
*   see also    Cldr_YMD2Datestr()
*               Cldr_Dates2Terms()
*               Cldr_ComputeTerms()
*
*************************************************************************
,,EOH,,*/


FL64ARRAY Cldr_Ymd2Terms(YYYYMMDD date1,
                         INTI     count,
                         YMDARRAY date2,
                         CALCONV  cal,
                         EOMCONV  eom,
                         INTI     qbas,
						 HOLI_STR* holi)       /* frequency */
{
    INTI      i ;
    DATESTR   primo, ultimo ;
    FL64ARRAY terms ;

    terms = Alloc_FL64ARRAY(count) ;

    /* Loop over all the dates and compute the terms one at a time */
    primo = Cldr_YMD2Datestr(date1) ;

    for (i = 0 ; i < count ; i++)
    {
        ultimo   = Cldr_YMD2Datestr(date2[i]) ;
        terms[i] = Cldr_TermBetweenDates(&primo, &ultimo, qbas, cal, eom, holi) ; 	/* PMSTA-22396 - SRIDHARA � 160502 */
    }

    return terms ;
}

/*,,SOH,,
*************************************************************************
*
*               Cldr_Dates2Terms()
*
*   interface   #include <cldr.h>
*               FL64ARRAY Cldr_Dates2Terms(DATESTR   *date1,
*                                          INTI      count,
*                                          DATEARRAY date2,
*                                          CALCONV   cal,
*                                          EOMCONV   eom,
*                                          INTI      qbas) ;
*
*   general     Cldr_Dates2Terms() calculates the terms between the
*               array  of dates (date2) and the primo date date1.
*
*   input       DATESTR   *date1   The first day of the period.
*
*               INTI      count    The number of dates in date2.
*
*               DATEARRAY date2    Array of final days of the period
*
*               CALCONV   cal      The calendar convention.
*
*               EOMCONV   eom      The end of month convention.
*
*               INTI      qbas     The number of annual periods. Must be
*                                  one of 0, 1, 2, 4, 6 or 12.
*                                  See function Cldr_TermBetweenDates()
*                                  for details.
*
*	       	    HOLI_STR  *holi	   Container for list of holidays.
*
*   output
*
*   returns     The array of terms between date1 and the days of date2.
*               Allocated in this routine as Alloc_FL64ARRAY(count)
*
*   diagnostics
*
*   see also    Cldr_ComputeTerms()
*
*************************************************************************
,,EOH,,*/


FL64ARRAY Cldr_Dates2Terms(DATESTR* date1,
                           INTI     count,
                           DATEARRAY date2,
                           CALCONV  cal,
                           EOMCONV  eom,
                           INTI     qbas,
						   HOLI_STR* holi)
{
    INTI      i ;
    FL64ARRAY terms ;

    terms = Alloc_FL64ARRAY(count) ;

    /* Loop over all the dates and compute the terms one at a time */
    for (i = 0 ; i < count ; i++)
        terms[i] = Cldr_TermBetweenDates(date1, &date2[i], qbas, cal, eom, holi) ;   	/* PMSTA-22396 - SRIDHARA � 160502 */

    return terms ;
}


/*,,SOH,,
*************************************************************************
*
*               Cldr_ComputeTerms()
*
*    interface  #include <cldr.h>
*               FL64ARRAY Cldr_ComputeTerms(DATESTR   *start,
*                                            INTI      count,
*                                            DATEARRAY days,
*                                            INTI      norig,
*                                            DATEARRAY origdays,
*                                            INTI      freq,
*                                            CALCONV   cal_per1,
*                                            CALCONV   cal_per2,
*                                            EOMCONV   eom) ;
*
*    general    This function computes terms in fractional years from
*               start to each of the elements in days.
*
*               Here we use two calendar conventions - according to
*               Norwegian conventions. In all fractional periods, ie.
*               less than a whole period, we use cal_per1 and in all
*               unbroken periods we use cal_per2.
*
*               A period is broken if the last day in the period in not
*               contained in origdays. origdays is the list of days
*               from which days are extracted (typically a period
*               cashflow generated with cflw_extract_cashflow()) .
*
*    input      DATESTR   *start    The start day from which terms are
*                                   computed.
*
*               INTI      count     Number of elements in days.
*
*               DATEARRAY days      Array of payment days with count
*                                   entries.
*                                   Dimension [count]
*
*               INTI      norig     Number of elements in origdays.
*
*               DATEARRAY origdays  Array of payment days with norig
*                                   entries.
*                                   Dimension [norig]
*
*               INTI      freq      The number of annual periods. Must
*                                   be one of 0, 1, 2, 4, 6 or 12.
*                                   See function Cldr_TermBetweenDates()
*                                   for details.
*
*               CALCONV   cal_per1  The calender convention used for
*                                   calculating the term from start to
*                                   the first payment term.
*
*               CALCONV   cal_per2  The calender convention used for
*                                   calculating the terms from start to
*                                   the payment terms proceeding the
*                                   first payment term.
*
*               EOMCONV   eom       The end of month convention.
*
*	       	    HOLI_STR  *holi	    Container for list of holidays.
*
*    output
*
*    returns    The terms between start and days. Allocated in this
*               routine as Alloc_FL64ARRAY(count)
*
*    diagnostics
*
*    see also   Cldr_Dates2Terms()
*
*    wrapper    AP
*
*************************************************************************
,,EOH,,*/

FL64ARRAY Cldr_ComputeTerms(DATESTR* start,
                             INTI      count,
                             DATEARRAY days,
                             INTI      norig,
                             DATEARRAY origdays,
                             INTI      freq,
                             CALCONV   cal_per1,
                             CALCONV   cal_per2,
                             EOMCONV   eom,
							 HOLI_STR* holi)
{
    FL64ARRAY ts ;
    INTI      ixp, ixn, i ;
    CALCONV   cal ;

    /* warning avoidance */
    ixn = 0 ;

    ts = Alloc_FL64ARRAY(count) ;

    if (count == 0)
        return ts ;

    for (i = 0 ; i < count ; i++)
    {
        if (i == 0)
        {
            /* Is start and the first day contained in origdays ?? */
            ixp = Cldr_FindDateIndex(origdays, norig, start, 0,
                                      SEARCH_BISECTION, SAMEINDEX) ;

            ixn = Cldr_FindDateIndex(origdays, norig, &days[i], ixp,
                                      SEARCH_FORWARDS, SAMEINDEX) ;

            if (ixp < norig && Cldr_DateEQ(&origdays[ixp], start) == True &&
                ixn < norig && Cldr_DateEQ(&origdays[ixn], &days[i]) == True)
                cal = cal_per2 ;
            else
                cal = cal_per1 ;

            ts[0] = Cldr_TermBetweenDates(start, &days[0], freq, cal, eom, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
        }
        else
        {
            /* Is the actual and previous day contained in origdays ?? */
            ixp = ixn ;
            ixn = Cldr_FindDateIndex(origdays, norig, &days[i], ixp,
                                      SEARCH_FORWARDS, SAMEINDEX) ;

            if (ixp < norig && Cldr_DateEQ(&origdays[ixp], &days[i - 1]) ==
              True &&
                ixn < norig && Cldr_DateEQ(&origdays[ixn], &days[i]) == True)
                cal = cal_per2 ;
            else
                cal = cal_per1 ;

            ts[i] = ts[i - 1] + Cldr_TermBetweenDates(&days[i - 1], &days[i],
                                                      freq, cal, eom, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
        }
    }

    return ts ;
}


/*,,SOH,,
************************************************************************
*
*              Cldr_Term2Date()
*
*  interface   #include <cldr.h>
*              DATESTR Cldr_Term2Date(DATESTR *today,
*                                     FL64 dur,
*                                     TERMUNIT unit,
*                                     CALCONV cal,
*                                     EOMCONV eom) ;
*
*  general     The function calculates the best guess on a date lying
*              a number of (possibly fractional) terms ahead.
*
*              This function works as the closest possible inverse of
*              Cldr_TermBetweenDates(), when Cldr_TermBetweenDates is
*              called with qb=0. Note that this means that the result
*              of Cldr_Term2Date when adding 12 months is different
*              from the result when adding 1 year, if the calendar
*              convention is e.g. ACT360.
*              To achieve a straight "1 year from today" calculation
*              call explicitly with unit=MONTHS instead of YEARS
*              and 12*dur for duration, or use
*              Cldr_TermUnit2Date() if dur is really an integer.
*
*
*  input       DATESTR  *today Pointer to the start date.
*
*              FL64     dur    The number of termunits.
*                              Can be fractional (eg. 1.25)
*
*              TERMUNIT unit   The unit of dur.
*                              Cannot be BUSDAYS.
*
*              CALCONV  cal    The calendar convention.
*
*              EOMCONV  eom    The end of month convention.
*
*  output
*
*  returns     the best guess on the future date.
*
*  diagnostics
*
*  see also    Cldr_TermUnit2Date()
*              Cldr_AddPeriod()
*
*  wrapper     AP
*
************************************************************************
,,EOH,,*/


DATESTR Cldr_Term2Date(DATESTR* today,
                       FL64      dur,
                       TERMUNIT  unit,
                       CALCONV   cal,
                       EOMCONV   eom)
{
    DATESTR d_end, d_end1 ;
    FL64    dpy, intp, frac, xtra ;
    INTI    days, term ;
    HOLI_STR holi;

    /* warning avoidance */
    days = 0 ;
    holi = Set_HOLI_STR(NO_BUSADJUST, 0, NULL);


    /* Get whole number of units */
    frac = modf(dur, &intp) ;
    xtra = (dur > 0.0 ? 0.5 : - 0.5) ;
    term = (INTI) (intp + xtra) ;

    /* Add whole number of units */
    switch (unit)
    {
        case DAYS :
            d_end = Cldr_AddDays(today, (INTL) term, cal, &holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
            days  = SCecon_floori(frac + xtra) ;
            break ;

        case WEEKS :
			d_end = Cldr_AddDays(today, (INTL)(7 * term), cal, &holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */
            days  = SCecon_floori(7.0 * frac + xtra) ;
            break ;

        case MONTHS :
            d_end = Cldr_AddMonths(today, term, eom) ;
            d_end1 = Cldr_AddMonths(today, term+1, eom) ;
            dpy = Cldr_DaysBetweenDates(&d_end,&d_end1,cal, &holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */
            /* This might be improved */
            days  = SCecon_floori(dpy * frac + xtra) ;
            break ;

        case YEARS : 
            d_end = Cldr_AddMonths(today, 12, eom) ;
            dpy   = Cldr_DaysPerYear(today, &d_end, 0, cal, eom, &holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */
            d_end = *today ;
            /* NOTE : this calc is only an inverse to Cldr_TermBetweenDates
            when that function is called with qb=0.
            with qb>0 a better inverse would be to let
            d_end be Cldr_AddMonths(today, 12*term, eom) and the
            next line be 
            days  = SCecon_floori(dpy * frac + xtra) ; 
            such that dayfractions are only used for the fractional
            part of the year, whereas the integer part of dur is caculated
            by directly adding years */
            days  = SCecon_floori(dpy * dur + xtra) ; 
            break ;

        default:
            ;
    }

    /* Transform fractions to number of days */
    d_end = Cldr_AddDays(&d_end, (INTL) days, cal, &holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */

    return d_end ;
}


DATESTR Cldr_Years2Date(DATESTR* today,
                       FL64      years,
                       CALCONV   cal,
                       EOMCONV   eom)
{
    DATESTR  dtmp;
    HOLI_STR dholi;

    dholi = Set_HOLI_STR(NO_BUSADJUST, 0, NULL);

    if (years - SCecon_floor(years) < 1e-6)
      dtmp = Cldr_TermUnit2Date(today, SCecon_floori(years), YEARS, 
                                cal, eom, &dholi);
    else
      dtmp = Cldr_Term2Date(today, years, YEARS, cal, eom);

    return dtmp;
}


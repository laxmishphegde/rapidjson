/* SCID @(#)testtvm.c	1.5 (SimCorp) 99/02/19 14:17:06 */

/************************************************************************
*
*   project     SCecon
*
*   this program tests the routines in the time value of money module
*   of SCecon
*
************************************************************************/

/*** includes ***********************************************************/
#include <string.h>
#include <tvm.h>
#include <stdlib.h>
#include <stdio.h>
#include <scalloc.h>
#include <str2conv.h>


INTI tvmtest(char* txa, FILE* in, FILE* out)
{
    char     txb[25], txc[25], txpl[64] ;
    FL64     acc, fexp, fexp1, fexp2, fres, fres1, fres2, y1, rp ;
    FL64     ann, coup, dp, p1, t1 ;
    INTI     diff ;
    BONDTYPE type ;
    RISKCONV risk ;
    BOOLE    ok ;

    acc   = 0.00001 ;
    diff = -1 ;

    if (!strcmp(txa, "tvm_modified_duration()"))
    {
        fscanf(in, "%lf %lf %lf %s", &fexp1, &dp, &p1, txpl);
        fres1 = tvm_modified_duration(dp, p1);
        diff = (fabs(fexp1 - fres1) > acc) ;

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   dollar duration %8.5lf\n", dp) ;
        fprintf(out,"   dirty price     %8.5lf\n", p1) ;
        fprintf(out,
          "   result is %8.5lf ; expected is %8.5lf\n",
          fres1, fexp1) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }
    else if (!strcmp(txa, "tvm_duration()"))
    {
        fscanf(in, "%lf %lf %lf %lf %s", &fexp1, &dp, &p1, &y1, txpl);
        fres1 = tvm_duration(dp, p1, y1);
        diff = (fabs(fexp1 - fres1) > acc) ;

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   dollar duration  %8.5lf\n", dp) ;
        fprintf(out,"   dirty price      %8.5lf\n", p1) ;
        fprintf(out,"   compounded yield %8.5lf\n", y1) ;
        fprintf(out,
          "   result is %8.5lf ; expected is %8.5lf\n",
          fres1, fexp1) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }
    else if (!strcmp(txa, "tvm_correction_factor()"))
    {
        fscanf(in, "%lf %lf %s", &fexp1, &dp, txpl);
        fres1 = tvm_correction_factor(dp);
        diff = (fabs(fexp1 - fres1) > acc) ;

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   dollar duration  %8.5lf\n", dp) ;
        fprintf(out,
          "   result is %8.5lf ; expected is %8.5lf\n",
          fres1, fexp1) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }
    else if (!strcmp(txa, "TVM_NPVBondtype()"))
    {
        fscanf(in, "%lf %lf %lf %lf %lf %lf %s %s %s",
               &fexp, &fexp1, &fexp2, &ann, &y1, &t1, txb, txc, txpl);

        type = Str2BONDTYPE(txb) ;
        risk = Str2RISKCONV(txc) ;
        fres = TVM_NPVBondtype(ann, y1, t1, type, risk, &fres1, &fres2);
        diff = (fabs(fexp - fres) > acc || fabs(fexp1 - fres1) > acc ||
                fabs(fexp2 - fres2) > acc) ;

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   Payment          %8.5lf\n", ann) ;
        fprintf(out,"   compounded yield %8.5lf\n", y1) ;
        fprintf(out,"   maturity         %8.5lf\n", t1) ;
        fprintf(out,"   bondtype         %8s\n", txb) ;
        fprintf(out,"   riskconv         %8s\n", txc) ;
        fprintf(out,
          "   result is %8.5lf ; expected is %8.5lf\n",
          fres, fexp) ;
        fprintf(out,
          "             %8.5lf ; expected is %8.5lf\n",
          fres1, fexp1) ;
        fprintf(out,
          "             %8.5lf ; expected is %8.5lf\n",
          fres2, fexp2) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }
    else if (!strcmp(txa, "TVM_Risk_Per2Ann()"))
    {
        fscanf(in, "%lf %lf %lf %lf %lf %s %s",
               &fexp, &rp, &ann, &y1, &t1, txb, txpl);

        risk = Str2RISKCONV(txb) ;
        fres = TVM_Risk_Per2Ann(rp, ann, y1, t1, risk) ;
        diff = fabs(fexp - fres) > acc ;

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   Periodic yield   %8.5lf\n", rp) ;
        fprintf(out,"   Periodic dp      %8.5lf\n", ann) ;
        fprintf(out,"   Periodic ddp     %8.5lf\n", y1) ;
        fprintf(out,"   Period           %8.5lf\n", t1) ;
        fprintf(out,"   riskconv         %8s\n", txb) ;
        fprintf(out,
          "   result is %8.5lf ; expected is %8.5lf\n",
          fres, fexp) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }
    else if (!strcmp(txa, "TVM_YieldByFormula()"))
    {
        fscanf(in, 
          "%lf %lf %lf %lf %s %s",
          &fexp1, &p1, &coup, &t1, txb, txpl);

        type = Str2BONDTYPE(txb) ;
        ok = TVM_YieldByFormula(p1, coup, t1, type, 1.0E-10, &fres1) ;
        diff = (fabs(fexp1 - fres1) > acc) ;

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   present value    %8.5lf\n", p1) ;
        fprintf(out,"   periodic payment %8.5lf\n", coup) ;
        fprintf(out,"   maturity         %8.5lf\n", t1) ;
        fprintf(out,"   bondtype         %s\n", txb) ;
        fprintf(out,"   error code       %8d\n", ok) ;
        fprintf(out,
          "   result is %8.5lf ; expected is %8.5lf\n",
          fres1, fexp1) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }
    else if (!strcmp(txa, "tvm_current_yield()") )
    {
        fscanf(in, "%lf %lf %lf %s", &fexp1, &coup, &p1, txpl);
        fres1 = tvm_current_yield(coup, p1) ;
        diff  = (fabs(fexp1 - fres1) > acc) ;

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   periodic coupon  %8.5lf\n", coup) ;
        fprintf(out,"   dirty price      %8.5lf\n", p1) ;
        fprintf(out,
          "   result is %8.5lf ; expected is %8.5lf\n",
          fres1, fexp1) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }


    return diff ;
}

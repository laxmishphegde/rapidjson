/* SCID @(#)mincl1.c	1.9 (SimCorp) 99/02/19 14:15:56 */

/* mincl1.f -- translated by f2c (version of 26 July 1990  10:54:47).
   You must link the resulting object file with the libraries:
        -lF77 -lI77 -lm -lc   (in that order)
*/

#include <f2proto.h>

/* Table of constant values */

static integer c__0 = 0;
static integer c__1 = 1;

/*   Extra external subroutine to allow a driver to e.g. approx. */
/*   gradients. */
/*   CHECKD fixed .. PHF/910425 */

#ifndef NO_FPTR2FPTR
int mincl1_(int (*calc)(int (*fdf)(integer *, integer *, double *, 
                                   void *, double *),
                        integer *, integer *, double *, void *, 
                        double *, double *),
            int (*fdf) (integer *, integer *, double *, void *, double *),
            integer    *n,
            integer    *m,
            integer    *l,
            integer    *leq,
            doublereal *c,
            doublereal *dc,
            doublereal *x,
            doublereal *dx,
            doublereal *eps,
            integer    *maxfun,
            doublereal *w,
            integer    *iw,
            integer    *icontr,
            void       *data)

#else

int mincl1_(calc, fdf, n, m, l, leq, c, dc, x, dx, eps, maxfun, w, iw, 
            icontr, data)

int (*fdf)() ;
int (*calc) () ;
integer    *n ;
integer    *m ;
integer    *l ;
integer    *leq ;
doublereal *c ;
doublereal *dc ;
doublereal *x ;
doublereal *dx ;
doublereal *eps ;
integer    *maxfun ;
doublereal *w ;
integer    *iw ;
integer    *icontr ;
void       *data ;

#endif
{
    /* System generated locals */
    integer dc_dim1, dc_offset;

    /* Local variables */
    integer keqs;
    doublereal d[4];
    integer i, nkstc, nkstf;
    logical optim;
    integer nkstl, id[6], na, nb;
    integer nf, nn, nr, nu, nw, na1, nf1, nf2, nw1, nx1, nw2, nw3, ndf, ncl,
            nas, nks, nwl, iwr, nwm, nxx, ndf1, nks0, nwl1, nwm1;


/*   MINCL1 MINIMIZES THE SUM OF ABS VALUES OF A SET OF NON-LINEAR */
/*   FUNCTIONS SUBJECT TO LINEAR EQUALITY AND INEQUALITY CONSTRAINTS. */
/*   (LINEARLY CONSTRAINED MINIMIZATION OF THE L1-NORM OF A */
/*   VECTOR FUNCTION). */
/*   THIS SUBROUTINE CALLS THE SUBROUTINE L1NLS DESCRIBED IN */
/*   JORGEN HALD, 'A 2-STAGE ALGORITHM FOR NONLINEAR L1 OPTIMIZATION', */
/*   REPORT NI-81-03, INSTITUTE FOR NUMERICAL ANALYSIS, TECHNICAL UNI- */
/*   VERSITY OF DENMARK, 1981. */

/*   FOR A PROGRAM DESCRIPTION SEE: */
/*   KAJ MADSEN, OLE TINGLEFF, PER CHRISTIAN HANSEN & WOJCIECH OWCZARZ: */

/*   'ROBUST SUBROUTINES FOR NON-LINEAR OPTIMIZATION', REPORT NI 90-06, */

/*   INSTITUTE FOR NUMERICAL ANALYSIS, TECHNICAL UNIVERSITY OF DENMARK, */

/*   APRIL 1990. */


    /* Parameter adjustments */
    --w;
    --x;
    dc_dim1 = *l;
    dc_offset = dc_dim1 + 1;
    dc -= dc_offset;
    --c;

    /* Function Body */
    optim = *icontr > 0;
/*     CHECK INPUT QUANTITIES */
    iwr = (*m << 1) * *n + *n * 5 * *n + *m * 5 + *n * 10 + (*l << 2);
    *icontr = 0;
    if (*n <= 0)
        *icontr = -2;

    if (*m <= 0)
        *icontr = -3;

    if (*l < 0)
        *icontr = -4;

    if (*leq < 0 || *leq > *l || *leq >= *n)
        *icontr = -5;

    if (*dx <= 0.)
        *icontr = -9;

    if (*eps <= 0.)
        *icontr = -10;

    if (*maxfun <= 0)
        *icontr = -11;

    if (*iw < iwr)
        *icontr = -13;

    if (*icontr < 0)
        return 0;


/*     EXIT BECAUSE OF INPUT ERROR */

    if (optim)
        goto L200;

    na = 1;
    na1 = na + *n * *m;
    nf = na1 + *n * *m;
    nf1 = nf + *m;
    nf2 = nf1 + *m;
    checkd_(calc, fdf, n, m, &x[1], dx, d, id, &w[na], &w[na1], &w[nf],
            &w[nf1], &w[nf2], data);
    for (i = 1; i <= 4; ++i)
/* L110: */
        w[i] = d[i - 1];

    for (i = 1; i <= 6; ++i)
/* L120: */
        w[i + 4] = (doublereal) id[i - 1];

    return 0;
/*     ****  EXIT, GRADIENTS CHECKED   **** */

L200:

/*     OPTIMIZATION */

/*     SPLIT UP THE WORK AREA */
    nn = *n + *n;
    nf = 1;
    nf1 = nf + *m;
    ndf = nf1 + *m;
    ndf1 = ndf + *m * *n;
    nx1 = ndf1 + *m * *n;
    nb = nx1 + *n;
    nu = nb + *n * *n;
    nr = nu + *n * *n;
    na = nu;
    ncl = na + nn * nn;
    nwl = ncl + *l;
    nwl1 = nwl + *l;
    nxx = nwl1 + *l;
    nw = nxx + *n;
    nw1 = nw + *n;
    nw2 = nw1 + *n;
    nw3 = nw2 + *n;
    nwm = nw3 + *n;
    nwm1 = nwm + *m;
    nas = nwm1 + *m;
    nks = nas + *n;
    nks0 = nks + *n;
    nkstc = nks0 + *n;
    nkstf = nkstc + *l;
    nkstl = nkstf + *m;
    keqs = 3;
    l1nls_(calc, fdf, n, m, l, leq, &c[1], &dc[dc_offset], &x[1], dx, eps,
            maxfun, &keqs, &nn, &w[nf], &w[nf1], &w[ndf], &w[ndf1], &w[nx1],
            &w[nb], &w[nu], &w[nr], &w[na], &w[ncl], &w[nwl], &w[nwl1], 
            &w[nxx], &w[nw], &w[nw1], &w[nw2], &w[nw3], &w[nwm], &w[nwm1], 
            &w[nas], (int *) &w[nks], (int *) &w[nks0],
            (int *) &w[nkstc], (int *) &w[nkstf],
            (int *) &w[nkstl], icontr, data);
    return 0;
} /* mincl1_ */


#ifndef NO_FPTR2FPTR
int checkd_(int (*calc)(int (*fdf)(integer *, integer *, double *, 
                                   void *, double *),
                        integer *, integer *, double *, void *, 
                        double *, double *),
            int (*fdf) (integer *, integer *, double *, void *, double *),
            integer    *n,
            integer    *m,
            doublereal *x,
            doublereal *stepl,
            doublereal *diff,
            integer    *indx,
            doublereal *a,
            doublereal *a1,
            doublereal *f,
            doublereal *f1,
            doublereal *f2,
            void       *data)
#else

int checkd_(calc, fdf, n, m, x, stepl, diff, indx, a, a1, f, f1, f2, data)

int (*fdf)() ;
int (*calc) () ;
integer    *n ;
integer    *m ;
doublereal *x ;
doublereal *stepl ;
doublereal *diff ;
integer    *indx ;
doublereal *a ;
doublereal *a1 ;
doublereal *f ;
doublereal *f1 ;
doublereal *f2 ;
void       *data ;

#endif
{
    /* System generated locals */
    integer a_dim1, a_offset, a1_dim1, a1_offset, i_1, i_2;

    /* Local variables */
    doublereal amax, step, c;
    integer i, j;
    doublereal s, db, dc, df;
    integer ib, ic, jc, jb, jf;
    logical chb, chf;
    doublereal aji;
/* Removed PSA
    doublereal aij;
*/
    logical chm;
    integer iif;

    /* warning avoidance */ 
    jf = iif = jb = ib = jc = ic = 0 ;

    /* Parameter adjustments */
    --f2;
    --f1;
    --f;
    a1_dim1 = *m;
    a1_offset = a1_dim1 + 1;
    a1 -= a1_offset;
    a_dim1 = *m;
    a_offset = a_dim1 + 1;
    a -= a_offset;
    --indx;
    --diff;
    --x;

    /* Function Body */
    amax = 0.;
    dc = 0.;
    df = 0.;
    db = 0.;
    (*calc)(fdf, n, m, &x[1], data, &a[a_offset], &f[1]);
    i_1 = *n;
    for (i = 1; i <= i_1; ++i)
    {
        c = x[i];
        if (c == 0.)
        {
            step = *stepl;
        }
        else
        {
            step = *stepl * c;
        }
        x[i] = c + step;
        (*calc)(fdf, n, m, &x[1], data, &a1[a1_offset], &f1[1]);
        x[i] = c - step * .5;
        (*calc)(fdf, n, m, &x[1], data, &a1[a1_offset], &f2[1]);
        i_2 = *m;
        for (j = 1; j <= i_2; ++j)
        {
            aji = a[j + i * a_dim1];
/* .. Removed PSA
            s = abs(aij);
*/
/* .. Inserted instead */
            s = abs(aji);

            if (amax < s)
            {
                amax = s;
            }
            diferr_(&f[j], &f1[j], &f2[j], &aji, &step, &dc, &df, &db, &chm,
                    &chf, &chb);
            if (! chm)
            {
                goto L1;
            }
            jc = j;
            ic = i;
L1:
            if (! chf)
            {
                goto L2;
            }
            jf = j;
            iif = i;
L2:
            if (! chb)
            {
                goto L3;
            }
            jb = j;
            ib = i;
L3:
            ;
        }
/* L4: */
        x[i] = c;
    }
    diff[1] = amax;
    diff[2] = df;
    diff[3] = db;
    diff[4] = dc;
    indx[1] = jf;
    indx[2] = iif;
    indx[3] = jb;
    indx[4] = ib;
    indx[5] = jc;
    indx[6] = ic;
    return 0;
} /* checkd_ */


int diferr_(doublereal *ym,
            doublereal *yf,
            doublereal *yb,
            doublereal *diff,
            doublereal *stepl,
            doublereal *erm,
            doublereal *erf,
            doublereal *erb,
            logical    *chm,
            logical    *chf,
            logical    *chb)
{
    doublereal s;

    s = (*yf - *ym) / *stepl - *diff;
    *chf = abs(s) > abs(*erf);
    if (*chf)
    {
        *erf = s;
    }
    s = (*ym - *yb) * 2. / *stepl - *diff;
    *chb = abs(s) > abs(*erb);
    if (*chb)
    {
        *erb = s;
    }
    s = (*ym + *yf / 3. - *yb * 4. / 3.) / *stepl - *diff;
    *chm = abs(s) > abs(*erm);
    if (*chm)
    {
        *erm = s;
    }
    return 0;
} /* diferr_ */


#ifndef NO_FPTR2FPTR
int l1nls_(int (*calc)(int (*fdf)(integer *, integer *, double *, 
                                  void *, double *),
                       integer *, integer *, double *, void *, 
                       double *, double *),
            int (*fdf) (integer *, integer *, double *, void *, double *),
           integer *n,
           integer *m,
           integer *l,
           integer *leq,
           doublereal *c,
           doublereal *dc,
           doublereal *x,
           doublereal *dx,
           doublereal *eps,
           integer *maxfun,
           integer *keqs,
           integer *nn,
           doublereal *f,
           doublereal *f1,
           doublereal *df,
           doublereal *df1,
           doublereal *x1,
           doublereal *b,
           doublereal *u,
           doublereal *r,
           doublereal *a,
           doublereal *cloc,
           doublereal *wl,
           doublereal *wl1,
           doublereal *xx,
           doublereal *w,
           doublereal *w1,
           doublereal *w2,
           doublereal *w3,
           doublereal *wm,
           doublereal *wm1,
           doublereal *aset,
           integer *kset,
           integer *kset0,
           integer *kstatc,
           integer *kstatf,
           integer *kstatl,
           integer *icontr,
           void    *data)

#else

int l1nls_(calc,
           fdf,
           n,
           m,
           l,
           leq,
           c,
           dc,
           x,
           dx,
           eps,
           maxfun,
           keqs,
           nn,
           f,
           f1,
           df,
           df1,
           x1,
           b,
           u,
           r,
           a,
           cloc,
           wl,
           wl1,
           xx,
           w,
           w1,
           w2,
           w3,
           wm,
           wm1,
           aset,
           kset,
           kset0,
           kstatc,
           kstatf,
           kstatl,
           icontr,
           data)

int (*fdf)() ;
int (*calc) () ;
integer *n ;
integer *m ;
integer *l ;
integer *leq ;
doublereal *c ;
doublereal *dc ;
doublereal *x ;
doublereal *dx ;
doublereal *eps ;
integer *maxfun ;
integer *keqs ;
integer *nn ;
doublereal *f ;
doublereal *f1 ;
doublereal *df ;
doublereal *df1 ;
doublereal *x1 ;
doublereal *b ;
doublereal *u ;
doublereal *r ;
doublereal *a ;
doublereal *cloc ;
doublereal *wl ;
doublereal *wl1 ;
doublereal *xx ;
doublereal *w ;
doublereal *w1 ;
doublereal *w2 ;
doublereal *w3 ;
doublereal *wm ;
doublereal *wm1 ;
doublereal *aset ;
integer *kset ;
integer *kset0 ;
integer *kstatc ;
integer *kstatf ;
integer *kstatl ;
integer *icontr ;
void    *data;

#endif
{
    /* System generated locals */
    integer dc_dim1, dc_offset, df_dim1, df_offset, df1_dim1, df1_offset,
            u_dim1, u_offset, r_dim1, r_offset, b_dim1, b_offset, a_dim1,
            a_offset, i_1, i_2;
    doublereal d_1, d_2;

    /* Local variables */
    integer nact;
    doublereal seps;
    integer nact0, i, j, k;
    doublereal t;
    logical accum;
    integer ncall;
    integer nstep;
    doublereal fl1ref;
    integer ii, li;
    integer kk;
    doublereal xn;
    integer keqset, nshift;
    doublereal fl1, dx0, xxnmax, fl10, fl11;
    integer lnn;
    doublereal xxn;

/*     SEPS IS AN EXPRESSION FOR THE MACHINE ACCURACY */
    /* Parameter adjustments */
    --kstatl;
    --kstatf;
    --kstatc;
    --kset0;
    --kset;
    --aset;
    --wm1;
    --wm;
    --w3;
    --w2;
    --w1;
    --w;
    --xx;
    --wl1;
    --wl;
    --cloc;
    a_dim1 = *nn;
    a_offset = a_dim1 + 1;
    a -= a_offset;
    r_dim1 = *n;
    r_offset = r_dim1 + 1;
    r -= r_offset;
    u_dim1 = *n;
    u_offset = u_dim1 + 1;
    u -= u_offset;
    b_dim1 = *n;
    b_offset = b_dim1 + 1;
    b -= b_offset;
    --x1;
    df1_dim1 = *m;
    df1_offset = df1_dim1 + 1;
    df1 -= df1_offset;
    df_dim1 = *m;
    df_offset = df_dim1 + 1;
    df -= df_offset;
    --f1;
    --f;
    --x;
    dc_dim1 = *l;
    dc_offset = dc_dim1 + 1;
    dc -= dc_offset;
    --c;

    /* Function Body */
    seps = 2.220446049250313e-16;
/*     SET SOME CONSTANTS */
    li = *l - *leq;
    lnn = *l + *nn;
/*     INITIALIZE */
    keqset = 0;
    ncall = 0;
    nshift = 0;
    nstep = 0;
    dx0 = *dx;
    fl1ref = 1e73;
    xn = 0.;
    i_1 = *n;
    for (i = 1; i <= i_1; ++i)
    {
/* Computing 2nd power */
        d_1 = x[i];
        xn += d_1 * d_1;
        i_2 = *n;
        for (j = 1; j <= i_2; ++j)
        {
/* L10: */
            b[i + j * b_dim1] = 0.;
        }
/* L20: */
        b[i + i * b_dim1] = 1.;
    }
    xn = sqrt(xn);
/*     FIND A FEASIBLE POINT */
    if (*l == 0)
    {
        goto L100;
    }
    matvec_(&dc[dc_offset], &x[1], l, l, n, &cloc[1]);
    i_1 = *l;
    for (i = 1; i <= i_1; ++i)
    {
/* L30: */
        cloc[i] += c[i];
    }
    nact = 0;
    feasi_(&cloc[1], &dc[dc_offset], l, leq, &li, n, &xx[1], &nact, &kset[1],
            &aset[1], &u[u_offset], &r[r_offset], &w1[1], &w2[1], &wl[1],
            &wl1[1], &w[1], &kstatc[1], icontr, &accum, &seps);
    if (*icontr != 0)
    {
        return 0;
    }
    xn = 0.;
    i_1 = *n;
    for (i = 1; i <= i_1; ++i)
    {
        x[i] += xx[i];
/* L50: */
/* Computing 2nd power */
        d_1 = x[i];
        xn += d_1 * d_1;
    }
    xn = sqrt(xn);
    matvec_(&dc[dc_offset], &x[1], l, l, n, &cloc[1]);
    i_1 = *l;
    for (i = 1; i <= i_1; ++i)
    {
/* L60: */
        cloc[i] += c[i];
    }
/*     CALCULATE FUNCTION VALUES IN THE FIRST FEASIBLE POINT */
L100:
    (*calc)(fdf, n, m, &x[1], data, &df[df_offset], &f[1]);
    fl10 = 0.;
    i_1 = *m;
    for (i = 1; i <= i_1; ++i)
    {
/* L110: */
        fl10 += (d_1 = f[i], abs(d_1));
    }
    nact0 = 0;
    ncall = 1;

/*       ITERATIVE LOOP STARTS HERE */

L150:
    nact = nact0;
    if (nact == 0)
    {
        goto L165;
    }
    i_1 = nact;
    for (i = 1; i <= i_1; ++i)
    {
/* L160: */
        kset[i] = kset0[i];
    }
/*     SOLVE THE LINEAR SUBPROBLEM */
L165:
    l1lp_(&f[1], &df[df_offset], &cloc[1], &dc[dc_offset], m, n, l, leq, &li,
            dx, &xxn, &xx[1], &nact, &kset[1], &aset[1], &u[u_offset],
            &r[r_offset], &w1[1], &w2[1], &f1[1], &wm[1], &wl[1], &wl1[1],
            &kstatf[1], &kstatc[1], &kstatl[1], &wm1[1], &w[1], &seps, &accum,
            &fl1, icontr);
    if (fl1 < fl10)
    {
        goto L170;
    }
    if (xxn > *eps * xn)
    {
        goto L500;
    }
    goto L510;
/*     CALCULATE FUNCTION VALUES IN THE NEW POINT */
L170:
    i_1 = *n;
    for (i = 1; i <= i_1; ++i)
    {
/* L175: */
        x1[i] = x[i] + xx[i];
    }
    (*calc)(fdf, n, m, &x1[1], data, &df1[df1_offset], &f1[1]);
    ++ncall;
    fl11 = 0.;
    i_1 = *m;
    for (i = 1; i <= i_1; ++i)
    {
/* L180: */
        fl11 += (d_1 = f1[i], abs(d_1));
    }
/*     REVISE THE STEP LENGTH */
    if (fl10 - fl11 > (fl10 - fl1) * .75)
    {
        *dx = xxn * 2.;
    }
    if (fl10 - fl11 < (fl10 - fl1) * .25)
    {
        *dx = xxn * .25;
    }
/*     EXCLUDE BOUNDS FROM THE ACTIVE SET. */
    k = 0;
    if (nact == 0)
    {
        goto L225;
    }
    i_1 = nact;
    for (i = 1; i <= i_1; ++i)
    {
        ii = kset[i];
        if (ii > *l && ii <= lnn)
        {
            goto L220;
        }
        ++k;
        kset[k] = kset[i];
        if (ii <= *l)
        {
            goto L210;
        }
        ii -= lnn;
        i_2 = *n;
        for (j = 1; j <= i_2; ++j)
        {
/* L205: */
            r[j + k * r_dim1] = df[ii + j * df_dim1];
        }
        goto L220;
L210:
        i_2 = *n;
        for (j = 1; j <= i_2; ++j)
        {
/* L215: */
            r[j + k * r_dim1] = dc[ii + j * dc_dim1];
        }
L220:
        ;
    }
/*     CALCULATE MULTIPLIERS FOR THE REDUCED SET. */
L225:
    i_1 = *n;
    for (i = 1; i <= i_1; ++i)
    {
        w[i] = 0.;
/* L230: */
        w1[i] = 0.;
    }
    i_1 = *m;
    for (i = 1; i <= i_1; ++i)
    {
        if (kstatf[i] >= 0)
        {
            goto L240;
        }
        i_2 = *n;
        for (j = 1; j <= i_2; ++j)
        {
            w[j] -= df[i + j * df_dim1];
/* L235: */
            w1[j] -= df1[i + j * df1_dim1];
        }
        goto L250;
L240:
        if (kstatf[i] == 0)
        {
            goto L250;
        }
        i_2 = *n;
        for (j = 1; j <= i_2; ++j)
        {
            w[j] += df[i + j * df_dim1];
/* L245: */
            w1[j] += df1[i + j * df1_dim1];
        }
L250:
        ;
    }
    i_1 = *n;
    for (i = 1; i <= i_1; ++i)
    {
/* L255: */
        aset[i] = -w[i];
    }
    nact = 0;
    if (k == 0)
    {
        goto L280;
    }
    addcol_(&u[u_offset], &r[r_offset], n, &nact, &k, &aset[1], &w2[1], &c__0,
             &c__1, &seps);
    if (nact < k)
    {
        keqset = *keqs - 2;
    }
    rsolv_(&r[r_offset], n, &nact, &aset[1], &aset[1]);
/*     UPDATE THE HESSIAN APPROXIMATION */
    i_1 = nact;
    for (i = 1; i <= i_1; ++i)
    {
        k = kset[i];
        if (k <= lnn)
        {
            goto L270;
        }
        kk = k - lnn;
        t = aset[i];
        i_2 = *n;
        for (j = 1; j <= i_2; ++j)
        {
            w1[j] += t * df1[kk + j * df1_dim1];
/* L260: */
            w[j] += t * df[kk + j * df_dim1];
        }
L270:
        ;
    }
L280:
    i_1 = *n;
    for (i = 1; i <= i_1; ++i)
    {
/* L285: */
        w2[i] = w1[i] - w[i];
    }
    bfgs_(&b[b_offset], n, &w2[1], &xx[1], &w[1], &seps);
/*     TEST IF THE NEW POINT IS ACCEPTABLE */
    if (fl10 - fl11 <= (fl10 - fl1) * .01)
    {
        goto L370;
    }
/*     COMPARE THE NEW ACTIVE SET WITH THE PRECEEDING */
    if (nact0 != nact)
    {
        goto L310;
    }
    if (nact == 0)
    {
        goto L305;
    }
    i_1 = nact;
    for (i = 1; i <= i_1; ++i)
    {
        k = kset[i];
        i_2 = nact;
        for (j = 1; j <= i_2; ++j)
        {
            if (k == kset0[j])
            {
                goto L300;
            }
/* L290: */
        }
        goto L310;
L300:
        ;
    }
L305:
    if (fl11 < fl10 * (float).99)
    {
        goto L310;
    }
    ++keqset;
    goto L320;
L310:
    keqset = 1;
/*     INTRODUCE THE NEW POINT */
L320:
    ++nstep;
    xn = 0.;
    fl10 = fl11;
    nact0 = nact;
    i_1 = *n;
    for (i = 1; i <= i_1; ++i)
    {
        x[i] = x1[i];
/* Computing 2nd power */
        d_1 = x[i];
        xn += d_1 * d_1;
        i_2 = *m;
        for (j = 1; j <= i_2; ++j)
        {
/* L330: */
            df[j + i * df_dim1] = df1[j + i * df1_dim1];
        }
    }
    xn = sqrt(xn);
    i_2 = *m;
    for (i = 1; i <= i_2; ++i)
    {
/* L340: */
        f[i] = f1[i];
    }
    if (*l == 0)
    {
        goto L350;
    }
    matvec_(&dc[dc_offset], &x[1], l, l, n, &cloc[1]);
    i_2 = *l;
    for (i = 1; i <= i_2; ++i)
    {
/* L345: */
        cloc[i] += c[i];
    }
L350:
    if (nact0 == 0)
    {
        goto L370;
    }
    i_2 = nact0;
    for (i = 1; i <= i_2; ++i)
    {
/* L360: */
        kset0[i] = kset[i];
    }
L370:
    if (ncall > *maxfun)
    {
        goto L500;
    }
/*     TEST OF CONVERGENCE CRITERION */
    if (xxn <= *eps * xn)
    {
        goto L510;
    }
    if (xxn <= seps * xn)
    {
        goto L500;
    }
/*     TEST FOR SWITCH TO STAGE2 */
    if (nstep < *n)
    {
        goto L150;
    }
    if (fl10 > fl1ref || keqset < *keqs)
    {
        goto L150;
    }
    if (nact == *leq)
    {
        goto L450;
    }
    i_2 = nact;
    for (i = 1; i <= i_2; ++i)
    {
        k = kset[i];
        t = aset[i];
        if (k > *leq && k <= *l && t >= 0.)
        {
            goto L150;
        }
        if (k > lnn && abs(t) >= 1.)
        {
            goto L150;
        }
/* L390: */
    }
/*     SHIFT TO STAGE2 */
L450:
    ++nshift;
    fl1ref = fl10 * .999999;
/* Computing MAX */
    d_1 = dx0, d_2 = *dx * 10.;
    xxnmax = FORTRAN_MAX(d_1,d_2);
    l1sta2_(calc, fdf, n, m, l, leq, &c[1], &cloc[1], &dc[dc_offset], &x[1],
            &xxnmax, &b[b_offset], &nact, &kset[1], &aset[1], &kstatf[1],
            &kstatc[1], &a[a_offset], &xx[1], nn, &f[1], &df[df_offset], &x1[1],
            &f1[1], &df1[df1_offset], &w1[1], &w2[1], &w3[1], &wl[1], &wm[1],
            eps, maxfun, &ncall, &xxn, &nstep, &seps, icontr, data);
    if (*icontr < 3)
    {
        goto L510;
    }
    fl10 = 0.;
    i_2 = *m;
    for (i = 1; i <= i_2; ++i)
    {
/* L460: */
        fl10 += (d_1 = f[i], abs(d_1));
    }
/* Computing MAX */
    d_1 = *dx, d_2 = xxn / 2.;
    *dx = FORTRAN_MAX(d_1,d_2);
    keqset = 1;
    goto L150;
/*     RETURN */
L500:
    *icontr = 2;
L510:
    *maxfun = ncall;
    *keqs = nshift;
    *eps = xxn;
    return 0;
} /* l1nls_ */


#ifndef NO_FPTR2FPTR
int l1sta2_(int (*calc)(int (*fdf)(integer *, integer *, double *, 
                                   void *, double *),
                        integer *, integer *, double *, void *, 
                        double *, double *),
            int (*fdf) (integer *, integer *, double *, void *, double *),
            integer    *n,
            integer    *m,
            integer    *l,
            integer    *leq,
            doublereal *c,
            doublereal *cloc,
            doublereal *dc,
            doublereal *x,
            doublereal *xxnmax,
            doublereal *b,
            integer    *nact,
            integer    *kset,
            doublereal *aset,
            integer    *kstatf,
            integer    *kstatc,
            doublereal *dz,
            doublereal *zz,
            integer    *nn,
            doublereal *f,
            doublereal *df,
            doublereal *x1,
            doublereal *f1,
            doublereal *df1,
            doublereal *w,
            doublereal *w1,
            doublereal *aset1,
            doublereal *wl,
            doublereal *wm,
            doublereal *eps,
            integer    *maxfun,
            integer    *ncall,
            doublereal *xxn,
            integer    *nstep,
            doublereal *seps,
            integer    *icontr,
            void       *data)
#else

int l1sta2_(calc,
            fdf,
            n,
            m,
            l,
            leq,
            c,
            cloc,
            dc,
            x,
            xxnmax,
            b,
            nact,
            kset,
            aset,
            kstatf,
            kstatc,
            dz,
            zz,
            nn,
            f,
            df,
            x1,
            f1,
            df1,
            w,
            w1,
            aset1,
            wl,
            wm,
            eps,
            maxfun,
            ncall,
            xxn,
            nstep,
            seps,
            icontr,
            data)

int (*fdf)() ;
int (*calc) () ;
integer    *n ;
integer    *m ;
integer    *l ;
integer    *leq ;
doublereal *c ;
doublereal *cloc ;
doublereal *dc ;
doublereal *x ;
doublereal *xxnmax ;
doublereal *b ;
integer    *nact ;
integer    *kset ;
doublereal *aset ;
integer    *kstatf ;
integer    *kstatc ;
doublereal *dz ;
doublereal *zz ;
integer    *nn ;
doublereal *f ;
doublereal *df ;
doublereal *x1 ;
doublereal *f1 ;
doublereal *df1 ;
doublereal *w ;
doublereal *w1 ;
doublereal *aset1 ;
doublereal *wl ;
doublereal *wm ;
doublereal *eps ;
integer    *maxfun ;
integer    *ncall ;
doublereal *xxn ;
integer    *nstep ;
doublereal *seps ;
integer    *icontr ;
void       *data;

#endif
{
    /* System generated locals */
    integer dc_dim1, dc_offset, b_dim1, b_offset, dz_dim1, dz_offset, df_dim1,
             df_offset, df1_dim1, df1_offset, i_1, i_2;
    doublereal d_1;

    /* Local variables */
    doublereal alfa;
    doublereal step;
    integer i, j, k;
    doublereal s, t, sseps;
    integer n1, nstep2, li, kk, jn;
    doublereal xn;
    integer nz;
    doublereal resref;
    integer le1;
    doublereal fl1;
    doublereal xn1;
    integer lnn;
    doublereal res, xxn1;


/*     STAGE-2 (QUASI-NEWTON) ALGORITHM FOR LINEARLY CONSTRAINED */
/*     L1 OPTIMIZATION. */

/*     INITIALIZE */
    /* Parameter adjustments */
    --wm;
    --wl;
    --aset1;
    --w1;
    --w;
    df1_dim1 = *m;
    df1_offset = df1_dim1 + 1;
    df1 -= df1_offset;
    --f1;
    --x1;
    df_dim1 = *m;
    df_offset = df_dim1 + 1;
    df -= df_offset;
    --f;
    --zz;
    dz_dim1 = *nn;
    dz_offset = dz_dim1 + 1;
    dz -= dz_offset;
    --kstatc;
    --kstatf;
    --aset;
    --kset;
    b_dim1 = *n;
    b_offset = b_dim1 + 1;
    b -= b_offset;
    --x;
    dc_dim1 = *l;
    dc_offset = dc_dim1 + 1;
    dc -= dc_offset;
    --cloc;
    --c;

    /* Function Body */
    li = *l - *leq;
    le1 = *leq + 1;
    lnn = *l + *n + *n;
    n1 = *n + 1;
    *icontr = 0;
    sseps = sqrt(*seps);
    nz = *n + *nact;
    nstep2 = 0;
    *xxn = 0.;
    resref = 1e73;

/*     ITERATIVE LOOP STARTS HERE */

/*     SET UP THE ITERATION MATRIX AND THE RIGHTHAND SIDE */
L50:
    i_1 = *n;
    for (i = 1; i <= i_1; ++i)
    {
        i_2 = *n;
        for (j = 1; j <= i_2; ++j)
        {
/* L60: */
            dz[i + j * dz_dim1] = b[i + j * b_dim1];
        }
/* L70: */
        zz[i] = 0.;
    }
    i_1 = *m;
    for (i = 1; i <= i_1; ++i)
    {
        if (kstatf[i] >= 0)
        {
            goto L80;
        }
        i_2 = *n;
        for (j = 1; j <= i_2; ++j)
        {
/* L75: */
            zz[j] += df[i + j * df_dim1];
        }
        goto L100;
L80:
        if (kstatf[i] == 0)
        {
            goto L100;
        }
        i_2 = *n;
        for (j = 1; j <= i_2; ++j)
        {
/* L90: */
            zz[j] -= df[i + j * df_dim1];
        }
L100:
        ;
    }
    if (*nact == 0)
    {
        goto L200;
    }
    i_1 = *nact;
    for (j = 1; j <= i_1; ++j)
    {
        k = kset[j];
        jn = j + *n;
        if (k > *l)
        {
            goto L140;
        }
        zz[jn] = -cloc[k];
        i_2 = *n;
        for (i = 1; i <= i_2; ++i)
        {
            dz[i + jn * dz_dim1] = dc[k + i * dc_dim1];
/* L130: */
            dz[jn + i * dz_dim1] = dz[i + jn * dz_dim1];
        }
        goto L160;
L140:
        kk = k - lnn;
        zz[jn] = -f[kk];
        i_2 = *n;
        for (i = 1; i <= i_2; ++i)
        {
            dz[i + jn * dz_dim1] = df[kk + i * df_dim1];
/* L150: */
            dz[jn + i * dz_dim1] = dz[i + jn * dz_dim1];
        }
L160:
        i_2 = nz;
        for (i = n1; i <= i_2; ++i)
        {
/* L170: */
            dz[i + jn * dz_dim1] = 0.;
        }
        t = aset[j];
        i_2 = *n;
        for (i = 1; i <= i_2; ++i)
        {
/* L180: */
            zz[i] -= t * dz[jn + i * dz_dim1];
        }
/* L190: */
    }
/*     CALCULATE THE QUASI-NEWTON STEP */
L200:
    linsys_(&dz[dz_offset], &zz[1], nn, &nz, &k, seps);
    if (k == nz)
    {
        goto L205;
    }
    *icontr = 3;
    return 0;
/*     CONTROL STEP LENGTH */
L205:
    xxn1 = 0.;
    alfa = 1.;
    i_1 = *n;
    for (i = 1; i <= i_1; ++i)
    {
/* L210: */
/* Computing 2nd power */
        d_1 = zz[i];
        xxn1 += d_1 * d_1;
    }
    xxn1 = sqrt(xxn1);
    if (xxn1 > *xxnmax)
    {
        alfa = *xxnmax / xxn1;
    }
    if (alfa < .1)
    {
        *icontr = 4;
    }
/*     WILL OTHER CONSTRAINTS OR FUNCTIONS BECOME ACTIVE? */
    matvec_(&df[df_offset], &zz[1], m, m, n, &wm[1]);
    matvec_(&dc[dc_offset], &zz[1], l, l, n, &wl[1]);
    step = 1e73;
    if (li == 0)
    {
        goto L240;
    }
    i_1 = *l;
    for (i = le1; i <= i_1; ++i)
    {
        if (kstatc[i] != 0)
        {
            goto L230;
        }
        t = wl[i];
        if (t >= -1e-50)
        {
            goto L230;
        }
        t = -cloc[i] / t;
        if (t > step)
        {
            goto L230;
        }
        step = t;
L230:
        ;
    }
L240:
    i_1 = *m;
    for (i = 1; i <= i_1; ++i)
    {
        t = wm[i];
        k = kstatf[i];
        if (abs(k) != 1 || k * t >= -1e-50)
        {
            goto L250;
        }
        t = f[i] * -25. / t;
        if (t >= step)
        {
            goto L250;
        }
        step = t;
L250:
        ;
    }
    if (step > alfa)
    {
        goto L275;
    }
    *icontr = 4;
    alfa = step;
/*     SCALE THE STEP */
L275:
    i_1 = nz;
    for (i = 1; i <= i_1; ++i)
    {
/* L280: */
        zz[i] = alfa * zz[i];
    }
    xxn1 = abs(alfa) * xxn1;
/*     CALCULATE FUNCTION VALUES IN THE NEW POINT */
    xn1 = 0.;
    i_1 = *n;
    for (i = 1; i <= i_1; ++i)
    {
        x1[i] = x[i] + zz[i];
/* L290: */
/* Computing 2nd power */
        d_1 = x1[i];
        xn1 += d_1 * d_1;
    }
    xn1 = sqrt(xn1);
    ++(*ncall);
    (*calc)(fdf, n, m, &x1[1], data, &df1[df1_offset], &f1[1]);
    if (*nact == 0)
    {
        goto L297;
    }
    i_1 = *nact;
    for (i = 1; i <= i_1; ++i)
    {
/* L295: */
        aset1[i] = aset[i] + zz[i + *n];
    }
L297:
    if (*l == 0)
    {
        goto L305;
    }
    matvec_(&dc[dc_offset], &x1[1], l, l, n, &wl[1]);
    i_1 = *l;
    for (i = 1; i <= i_1; ++i)
    {
/* L300: */
        wl[i] += c[i];
    }
/*     CALCULATE RESIDUALS */
L305:
    i_1 = *n;
    for (i = 1; i <= i_1; ++i)
    {
        w[i] = 0.;

/* L310: */
        w1[i] = 0.;
    }
    i_1 = *m;
    for (i = 1; i <= i_1; ++i)
    {
        if (kstatf[i] >= 0)
        {
            goto L320;
        }
        i_2 = *n;
        for (j = 1; j <= i_2; ++j)
        {
            w[j] -= df[i + j * df_dim1];
/* L315: */
            w1[j] -= df1[i + j * df1_dim1];
        }
        goto L330;
L320:
        if (kstatf[i] == 0)
        {
            goto L330;
        }
        i_2 = *n;
        for (j = 1; j <= i_2; ++j)
        {
            w[j] += df[i + j * df_dim1];
/* L325: */
            w1[j] += df1[i + j * df1_dim1];
        }
L330:
        ;
    }
    res = 0.;
    if (*nact == 0)
    {
        goto L370;
    }
    i_1 = *nact;
    for (j = 1; j <= i_1; ++j)
    {
        k = kset[j];
        t = aset1[j];
        if (k > *l)
        {
            goto L340;
        }
        i_2 = *n;
        for (i = 1; i <= i_2; ++i)
        {
            s = t * dc[k + i * dc_dim1];
            w[i] += s;
/* L335: */
            w1[i] += s;
        }
/* Computing 2nd power */
        d_1 = wl[k];
        res += d_1 * d_1;
        goto L360;
L340:
        kk = k - lnn;
        i_2 = *n;
        for (i = 1; i <= i_2; ++i)
        {
            w[i] += t * df[kk + i * df_dim1];
/* L350: */
            w1[i] += t * df1[kk + i * df1_dim1];
        }
/* Computing 2nd power */
        d_1 = f1[kk];
        res += d_1 * d_1;
L360:
        ;
    }
L370:
    i_1 = *n;
    for (i = 1; i <= i_1; ++i)
    {
/* L380: */
/* Computing 2nd power */
        d_1 = w1[i];
        res += d_1 * d_1;
    }
    res = sqrt(res);
/*     UPDATE THE HESSIAN APPROXIMATION */
    if (xxn1 < *seps * 100. * xn1)
    {
        goto L395;
    }
    i_1 = *n;
    for (i = 1; i <= i_1; ++i)
    {
/* L390: */
        w1[i] -= w[i];
    }
    bfgs_(&b[b_offset], n, &w1[1], &zz[1], &w[1], seps);
/*     TEST IF THE RESIDUAL HAS DECREASED */
L395:
    if (res <= resref * .999)
    {
        goto L480;
    }
    if (*icontr > 2)
    {
        return 0;
    }
/*     IF NO  - TEST FOR MACHINE ACCURACY */
    if (xxn1 > sseps * (*xxnmax + xn1) || nstep2 < 2)
    {
        goto L400;
    }
    *icontr = 2;
    if (xxn1 > *eps * xn1)
    {
        return 0;
    }
    *icontr = 1;
    if (*nact < *n)
    {
        return 0;
    }
    *icontr = 0;
    return 0;
L400:
    *icontr = 5;
    return 0;
/*     IF YES - INTRODUCE THE NEW POINT */
L480:
    ++nstep2;
    ++(*nstep);
    i_1 = *n;
    for (i = 1; i <= i_1; ++i)
    {
        x[i] = x1[i];
        i_2 = *m;
        for (j = 1; j <= i_2; ++j)
        {
/* L490: */
            df[j + i * df_dim1] = df1[j + i * df1_dim1];
        }
    }
    xn = xn1;
    *xxn = xxn1;
    fl1 = 0.;
    i_2 = *m;
    for (i = 1; i <= i_2; ++i)
    {
        fl1 += (d_1 = f1[i], abs(d_1));
/* L500: */
        f[i] = f1[i];
    }
    resref = res;
    if (*nact == 0)
    {
        goto L520;
    }
    i_2 = *nact;
    for (i = 1; i <= i_2; ++i)
    {
        k = kset[i];
        s = aset1[i];
        aset[i] = s;
        if (k > *l)
        {
            s = abs(s) - 1.;
        }
/* L510: */
        if (k > *leq && s > 0.)
        {
            *icontr = 6;
        }
    }
L520:
    if (*l == 0)
    {
        goto L535;
    }
    i_2 = *l;
    for (j = 1; j <= i_2; ++j)
    {
/* L530: */
        cloc[j] = wl[j];
    }
/*     TEST IF THE ACTIVE SET IS COMPLETE */
L535:
    i_2 = *m;
    for (i = 1; i <= i_2; ++i)
    {
        if (kstatf[i] > 0 && f[i] < -res)
        {
            *icontr = 7;
        }
/* L540: */
        if (kstatf[i] < 0 && f[i] > res)
        {
            *icontr = 7;
        }
    }
/*     TEST CONVERGENCE CRITERION */
    if (*icontr > 2)
    {
        return 0;
    }
    if (*xxn > *eps * xn)
    {
        goto L550;
    }
    if (*nact < *n)
    {
        *icontr = 1;
    }
    return 0;
L550:
    if (*xxn > *seps * xn && *ncall <= *maxfun)
    {
        goto L50;
    }
    *icontr = 2;
    return 0;
} /* l1sta2_ */


int l1lp_(doublereal *f,
          doublereal *df,
          doublereal *c,
          doublereal *dc,
          integer    *m,
          integer    *n,
          integer    *ic,
          integer    *le,
          integer    *li,
          doublereal *xnmax,
          doublereal *xn,
          doublereal *x,
          integer    *nact,
          integer    *kset,
          doublereal *aset,
          doublereal *u,
          doublereal *r,
          doublereal *dl,
          doublereal *h,
          doublereal *fup,
          doublereal *dldf,
          doublereal *cup,
          doublereal *dldc,
          integer    *kstatf,
          integer    *kstatc,
          integer    *kstatl,
          doublereal *stepf,
          doublereal *w,
          doublereal *seps,
          logical    *accum,
          doublereal *fl1,
          integer    *icontr)
{
    /* System generated locals */
    integer df_dim1, df_offset, dc_dim1, dc_offset, u_dim1, u_offset, r_dim1,
            r_offset, i_1, i_2;
    doublereal d_1, d_2, d_3;

    /* Local variables */
    doublereal amax;
    integer ncyc, kmax = 0;
    doublereal step;
    integer nact1;
    doublereal a;
    integer i, j, k, l;
    doublereal s, t;
    integer kc, kf;
    integer kk;
    doublereal sc, sf;
    integer ln;
    logical lindep;
    integer nactin;
    doublereal steplc;
    integer le1;
    doublereal dlh;
    integer kln, klp, lnn;
    doublereal eps, sln, slp, xxn, dln2;


/*     THE SUBROUTINE SOLVES A LINEARLY CONSTRAINED */
/*     LINEAR L1 PROBLEM. */
/*     THE STARTING POINT MUST BE FEASIBLE. */

    /* warning avoidance */
    kf = kln = klp = kc = 0 ;

/*     INITIALIZE */

    /* Parameter adjustments */
    --w;
    --stepf;
    --kstatl;
    --kstatc;
    --kstatf;
    --dldc;
    --cup;
    --dldf;
    --fup;
    --h;
    --dl;
    r_dim1 = *n;
    r_offset = r_dim1 + 1;
    r -= r_offset;
    u_dim1 = *n;
    u_offset = u_dim1 + 1;
    u -= u_offset;
    --aset;
    --kset;
    --x;
    dc_dim1 = *ic;
    dc_offset = dc_dim1 + 1;
    dc -= dc_offset;
    --c;
    df_dim1 = *m;
    df_offset = df_dim1 + 1;
    df -= df_offset;
    --f;

    /* Function Body */
    le1 = *le + 1;
    l = *le + *li;
    ln = l + *n;
    lnn = ln + *n;
    *xn = 0.;
    eps = *n * *seps;
    *accum = FALSE_;
    lindep = FALSE_;
    ncyc = 0;
    *icontr = 0;
    *fl1 = 1e73;
    i_1 = *n;
    for (i = 1; i <= i_1; ++i)
    {
        kstatl[i] = 0;
/* L10: */
        x[i] = 0.;
    }
    i_1 = *m;
    for (i = 1; i <= i_1; ++i)
    {
        kstatf[i] = 1;
        if (f[i] < 0.)
        {
            kstatf[i] = -1;
        }
/* L15: */
        fup[i] = f[i];
    }
/*     ACTIVATE INITIAL ACTIVE SET OF CONSTRAINTS */
    nactin = *nact;
    *nact = 0;
    if (l == 0)
    {
        goto L100;
    }
    i_1 = l;
    for (i = 1; i <= i_1; ++i)
    {
        kstatc[i] = 0;
/* L20: */
        cup[i] = c[i];
    }
    if (*le == 0)
    {
        goto L50;
    }
    i_1 = *le;
    for (i = 1; i <= i_1; ++i)
    {
        i_2 = *n;
        for (j = 1; j <= i_2; ++j)
        {
/* L30: */
            r[j + i * r_dim1] = dc[i + j * dc_dim1];
        }
        kset[i] = i;
/* L40: */
        kstatc[i] = 1;
    }
    addcol_(&u[u_offset], &r[r_offset], n, nact, le, &h[1], &w[1], accum,
            &c__0, &eps);
    if (*nact == *le)
    {
        goto L50;
    }
    *icontr = 3;
    return 0;
L50:
    if (nactin < le1)
    {
        goto L100;
    }
    i_1 = nactin;
    for (k = le1; k <= i_1; ++k)
    {
        kk = kset[k];
        if (kk < le1 || kk > l)
        {
            goto L70;
        }
        nact1 = *nact + 1;
        if (nact1 > *n)
        {
            goto L100;
        }
        i_2 = *n;
        for (i = 1; i <= i_2; ++i)
        {
/* L60: */
            r[i + nact1 * r_dim1] = dc[kk + i * dc_dim1];
        }
        uttrns_(&u[u_offset], n, nact, accum, &r[nact1 * r_dim1 + 1], &w[1]);
        addcol_(&u[u_offset], &r[r_offset], n, nact, &c__1, &h[1], &w[1],
                accum, &c__0, &eps);
        if (*nact < nact1)
        {
            goto L70;
        }
        eps += *seps * 2.;
        kset[nact1] = kk;
        kstatc[kk] = 1;
L70:
        ;
    }
/*     CALCULATE THE RESTRICTED GRADIENT. */
L100:
    *fl1 = 0.;
    i_1 = *n;
    for (i = 1; i <= i_1; ++i)
    {
/* L105: */
        h[i] = 0.;
    }
    i_1 = *m;
    for (i = 1; i <= i_1; ++i)
    {
        *fl1 += (d_1 = fup[i], abs(d_1));
        k = kstatf[i];
        if (k > -1)
        {
            goto L120;
        }
        i_2 = *n;
        for (j = 1; j <= i_2; ++j)
        {
/* L110: */
            h[j] -= df[i + j * df_dim1];
        }
L120:
        if (k < 1)
        {
            goto L140;
        }
        i_2 = *n;
        for (j = 1; j <= i_2; ++j)
        {
/* L130: */
            h[j] += df[i + j * df_dim1];
        }
L140:
        ;
    }
/*     TRANSFORM THE RESTRICTED GRADIENT. */
    i_1 = *n;
    for (i = 1; i <= i_1; ++i)
    {
/* L150: */
        dl[i] = -h[i];
    }
    uttrns_(&u[u_offset], n, nact, accum, &dl[1], &w[1]);
/*     CHECK IF THE CURRENT POINT IS A DEAD POINT. */
L200:
    t = 0.;
    nact1 = *nact + 1;
    dln2 = 0.;
    if (*nact == *n)
    {
        goto L220;
    }
    i_1 = *n;
    for (i = nact1; i <= i_1; ++i)
    {
/* L210: */
/* Computing 2nd power */
        d_1 = dl[i];
        dln2 += d_1 * d_1;
    }
L220:
    if (nact1 == 1)
    {
        goto L240;
    }
    i_1 = *nact;
    for (i = 1; i <= i_1; ++i)
    {
/* L230: */
/* Computing 2nd power */
        d_1 = dl[i];
        t += d_1 * d_1;
    }
L240:
    t += dln2;
    if (t == 0.)
    {
        goto L900;
    }
    if (dln2 > eps * eps * t)
    {
        goto L395;
    }
/*     DEAD POINT - CALCULATE MULTIPLIERS. */
    if (*nact == *le)
    {
        goto L900;
    }
    rsolv_(&r[r_offset], n, nact, &dl[1], &aset[1]);
    amax = -1e73;
    i_1 = *nact;
    for (k = le1; k <= i_1; ++k)
    {
        a = aset[k];
        if (kset[k] > lnn)
        {
            a = abs(a) - 1.;
        }
        if (a <= amax)
        {
            goto L250;
        }
        kmax = k;
        amax = a;
L250:
        ;
    }
    if (amax <= 0.)
    {
        goto L900;
    }
/*     DELETE A FUNCTION FROM THE ACTIVE SET. */
    kk = kset[kmax];
    if (kk <= lnn)
    {
        goto L310;
    }
    kk -= lnn;
    a = aset[kmax];
    if (a < 0.)
    {
        goto L280;
    }
    kstatf[kk] = 1;
    i_1 = *n;
    for (i = 1; i <= i_1; ++i)
    {
/* L260: */
        h[i] += df[kk + i * df_dim1];
    }
    i_1 = kmax;
    for (i = 1; i <= i_1; ++i)
    {
/* L270: */
        dl[i] -= r[i + kmax * r_dim1];
    }
    goto L330;
L280:
    kstatf[kk] = -1;
    i_1 = *n;
    for (i = 1; i <= i_1; ++i)
    {
/* L290: */
        h[i] -= df[kk + i * df_dim1];
    }
    i_1 = kmax;
    for (i = 1; i <= i_1; ++i)
    {
/* L300: */
        dl[i] += r[i + kmax * r_dim1];
    }
    goto L330;
/*     DEACTIVATE A CONSTRAINT. */
L310:
    if (kk > l)
    {
        goto L320;
    }
    kstatc[kk] = 0;
    goto L330;
L320:
    if (kk > ln)
    {
        goto L325;
    }
    kstatl[kk - l] = 0;
    goto L330;
L325:
    kstatl[kk - ln] = 0;
/*     REMOVE THE CORRESPONDING COLUMN IN R. */
L330:
    if (*accum)
    {
        goto L340;
    }
    *accum = TRUE_;
    haccum_(&u[u_offset], n, nact, &w[1]);
L340:
    delcol_(&kmax, &u[u_offset], &r[r_offset], n, nact, &dl[1], &c__1);
    eps += *seps * 2.;
    if (kmax > *nact)
    {
        goto L360;
    }
    i_1 = *nact;
    for (i = kmax; i <= i_1; ++i)
    {
/* L350: */
        kset[i] = kset[i + 1];
    }
/*     REMOVE LINEAR DEPENDENCE LABELS. */
L360:
    if (! lindep)
    {
        goto L200;
    }
    lindep = FALSE_;
    i_1 = *m;
    for (i = 1; i <= i_1; ++i)
    {
        if (kstatf[i] == 2)
        {
            kstatf[i] = 1;
        }
/* L370: */
        if (kstatf[i] == -2)
        {
            kstatf[i] = -1;
        }
    }
    i_1 = *n;
    for (i = 1; i <= i_1; ++i)
    {
/* L380: */
        if (kstatl[i] == 2)
        {
            kstatl[i] = 0;
        }
    }
    if (*li == 0)
    {
        goto L200;
    }
    i_1 = l;
    for (i = le1; i <= i_1; ++i)
    {
/* L390: */
        if (kstatc[i] == 2)
        {
            kstatc[i] = 0;
        }
    }
    goto L200;
/*     CALCULATE THE DIRECTION OF SEARCH. */
L395:
    if (*nact == 0)
    {
        goto L405;
    }
    i_1 = *nact;
    for (i = 1; i <= i_1; ++i)
    {
/* L400: */
        dl[i] = 0.;
    }
L405:
    utrns_(&u[u_offset], n, nact, accum, &dl[1], &w[1]);
    dlh = 0.;
    i_1 = *n;
    for (i = 1; i <= i_1; ++i)
    {
/* L410: */
        dlh += dl[i] * h[i];
    }
/*     PROJECT GRADIENTS ON THE DIRECTION OF SEARCH. */
    matvec_(&df[df_offset], &dl[1], m, m, n, &dldf[1]);
    matvec_(&dc[dc_offset], &dl[1], ic, &l, n, &dldc[1]);
/*     CALCULATE THE STEP LENGTHS. */
    i_1 = *m;
    for (i = 1; i <= i_1; ++i)
    {
        s = dldf[i];
        k = kstatf[i];
        stepf[i] = 1e73;
        if (abs(k) != 1 || k * s >= -1e-50)
        {
            goto L420;
        }
        stepf[i] = -fup[i] / s;
L420:
        ;
    }
L425:
    slp = 1e73;
    sln = 1e73;
    i_1 = *n;
    for (i = 1; i <= i_1; ++i)
    {
        if (kstatl[i] != 0)
        {
            goto L440;
        }
        s = dl[i];
        if (s * s < eps * eps * dln2)
        {
            goto L440;
        }
        t = (*xnmax - x[i]) / s;
        if (s < 0. || t >= slp)
        {
            goto L430;
        }
        slp = t;
        klp = i;
L430:
        t = -(*xnmax + x[i]) / s;
        if (s > 0. || t >= sln)
        {
            goto L440;
        }
        sln = t;
        kln = i;
L440:
        ;
    }
    sc = 1e73;
    if (*li == 0)
    {
        goto L460;
    }
    i_1 = l;
    for (i = le1; i <= i_1; ++i)
    {
        s = dldc[i];
        if (kstatc[i] != 0 || s >= -1e-50)
        {
            goto L450;
        }
        t = -cup[i] / s;
        if (t >= sc)
        {
            goto L450;
        }
        kc = i;
        sc = t;
L450:
        ;
    }
L460:
    steplc = FORTRAN_MIN(slp,sln);
    steplc = FORTRAN_MIN(steplc,sc);
    nact1 = *nact + 1;
/*     DO LINE SEARCH. */
L500:
    sf = 1e73;
    i_1 = *m;
    for (i = 1; i <= i_1; ++i)
    {
        s = stepf[i];
        if (s >= sf)
        {
            goto L510;
        }
        kf = i;
        sf = s;
L510:
        ;
    }
    step = FORTRAN_MIN(steplc,sf);
    if (sf > step)
    {
        goto L630;
    }
    t = dlh - (kstatf[kf] << 1) * dldf[kf];
    if (t >= 0.)
    {
        goto L600;
    }
    dlh = t;
    kstatf[kf] = -kstatf[kf];
    stepf[kf] = 1e73;
    goto L500;
/*     ACTIVATE A FUNCTION. */
L600:
    i_1 = *n;
    for (i = 1; i <= i_1; ++i)
    {
/* L610: */
        r[i + nact1 * r_dim1] = df[kf + i * df_dim1];
    }
    uttrns_(&u[u_offset], n, nact, accum, &r[nact1 * r_dim1 + 1], &w[1]);
    addcol_(&u[u_offset], &r[r_offset], n, nact, &c__1, &dl[1], &w[1], accum,
            &c__0, &eps);
    if (*nact == nact1)
    {
        goto L620;
    }
    kstatf[kf] <<= 1;
    stepf[kf] = 1e73;
    lindep = TRUE_;
    goto L500;
L620:
    kset[*nact] = kf + lnn;
    kstatf[kf] = 0;
    goto L700;
/*     -  OR A CONSTRAINT. */
L630:
    if (sc > step)
    {
        goto L660;
    }
    i_1 = *n;
    for (i = 1; i <= i_1; ++i)
    {
/* L640: */
        r[i + nact1 * r_dim1] = dc[kc + i * dc_dim1];
    }
    uttrns_(&u[u_offset], n, nact, accum, &r[nact1 * r_dim1 + 1], &w[1]);
    addcol_(&u[u_offset], &r[r_offset], n, nact, &c__1, &dl[1], &w[1], accum,
            &c__0, &eps);
    if (*nact == nact1)
    {
        goto L650;
    }
    kstatc[kc] = 2;
    lindep = TRUE_;
    goto L425;
L650:
    kstatc[kc] = 1;
    kset[*nact] = kc;
    goto L700;
/*     -  OR A BOUND. */
L660:
    i_1 = *n;
    for (i = 1; i <= i_1; ++i)
    {
/* L670: */
        r[i + nact1 * r_dim1] = 0.;
    }
    if (sln == slp)
    {
        sln = 2e73;
    }
    if (step == sln)
    {
        r[kln + nact1 * r_dim1] = 1.;
    }
    if (step == slp)
    {
        r[klp + nact1 * r_dim1] = -1.;
    }
    uttrns_(&u[u_offset], n, nact, accum, &r[nact1 * r_dim1 + 1], &w[1]);
    addcol_(&u[u_offset], &r[r_offset], n, nact, &c__1, &dl[1], &w[1], accum,
            &c__0, &eps);
    if (*nact == nact1)
    {
        goto L680;
    }
    lindep = TRUE_;
    if (step == sln)
    {
        kstatl[kln] = 2;
    }
    if (step == slp)
    {
        kstatl[klp] = 2;
    }
    goto L425;
L680:
    if (step == sln)
    {
        goto L690;
    }
    kset[*nact] = klp + l;
    kstatl[klp] = 1;
    goto L700;
L690:
    kset[*nact] = kln + ln;
    kstatl[kln] = -1;
L700:
    eps += *seps * 2.;
/*     INTRODUCE THE NEW POINT. */
    *xn = 0.;
    xxn = 0.;
    ++ncyc;
    if (ncyc > *n << 1)
    {
        goto L900;
    }
    i_1 = *n;
    for (i = 1; i <= i_1; ++i)
    {
        s = step * dl[i];
/* Computing MAX */
        d_1 = xxn, d_2 = abs(s);
        xxn = FORTRAN_MAX(d_1,d_2);
        x[i] += s;
/* L800: */
/* Computing MAX */
        d_2 = *xn, d_3 = (d_1 = x[i], abs(d_1));
        *xn = FORTRAN_MAX(d_2,d_3);
    }
    if (xxn > eps * *xn)
    {
        ncyc = 0;
    }
    i_1 = *m;
    for (i = 1; i <= i_1; ++i)
    {
/* L810: */
        fup[i] += step * dldf[i];
    }
    if (l == 0)
    {
        goto L100;
    }
    i_1 = l;
    for (i = 1; i <= i_1; ++i)
    {
/* L820: */
        cup[i] += step * dldc[i];
    }
    goto L100;
/*     RETURN */
L900:
    if (*nact < *n)
    {
        *icontr = 2;
    }
    i_1 = *nact;
    for (i = 1; i <= i_1; ++i)
    {
/* L910: */
        if (kset[i] > l && kset[i] <= lnn)
        {
            *icontr = 1;
        }
    }
    if (*icontr == 1)
    {
        *xn = *xnmax;
    }
    if (ncyc > *n << 1)
    {
        *icontr = 4;
    }
    return 0;
} /* l1lp_ */


int feasi_(doublereal *c,
           doublereal *dc,
           integer    *ic,
           integer    *le,
           integer    *li,
           integer    *n,
           doublereal *x,
           integer    *nact,
           integer    *kset,
           doublereal *aset,
           doublereal *u,
           doublereal *r,
           doublereal *dl,
           doublereal *right,
           doublereal *cup,
           doublereal *dldc,
           doublereal *w,
           integer    *kstat,
           integer    *icontr,
           logical    *accum,
           doublereal *seps)
{
    /* System generated locals */
    integer dc_dim1, dc_offset, u_dim1, u_offset, r_dim1, r_offset, i_1, i_2;
    doublereal d_1;

    /* Local variables */
    doublereal alfa, amin;
    integer leli;
    doublereal amax, anes, fmin;
    integer nact1, i, j, k = 0;
    doublereal t;
    integer kk;
    logical object;
    integer nactin;
    integer le1;
    doublereal eps;
    integer new_;
    doublereal dln2;


/*     THE SUBROUTINE FINDS A FEASIBLE POINT FOR A SET OF LINEAR */
/*     EQUALITY AND INEQUALITY CONSTRAINTS. */

    /* warning avoidance */
    new_ = 0 ;

/*     INITIALIZE */
    /* Parameter adjustments */
    --kstat;
    --w;
    --dldc;
    --cup;
    --right;
    --dl;
    r_dim1 = *n;
    r_offset = r_dim1 + 1;
    r -= r_offset;
    u_dim1 = *n;
    u_offset = u_dim1 + 1;
    u -= u_offset;
    --aset;
    --kset;
    --x;
    dc_dim1 = *ic;
    dc_offset = dc_dim1 + 1;
    dc -= dc_offset;
    --c;

    /* Function Body */
    eps = (*n + 10) * *seps;
    *accum = FALSE_;
    nactin = *nact;
    *nact = 0;
    le1 = *le + 1;
    leli = *le + *li;
    i_1 = *n;
    for (i = 1; i <= i_1; ++i)
    {
/* L10: */
        x[i] = 0.;
    }
    *icontr = 0;
    if (leli == 0)
    {
        return 0;
    }
    i_1 = leli;
    for (i = 1; i <= i_1; ++i)
    {
/* L15: */
        kstat[i] = 0;
    }
/*     MAKE ACTIVE THE EQUALITY CONSTRAINTS PLUS OTHER CONSTRAINTS */
/*     AS DEFINED IN KSET. */
    if (*le == 0)
    {
        goto L35;
    }
    if (*le > *n)
    {
        goto L600;
    }
    i_1 = *le;
    for (i = 1; i <= i_1; ++i)
    {
        right[i] = -c[i];
        i_2 = *n;
        for (j = 1; j <= i_2; ++j)
        {
/* L20: */
            r[j + i * r_dim1] = dc[i + j * dc_dim1];
        }
        kset[i] = i;
/* L30: */
        kstat[i] = 1;
    }
    addcol_(&u[u_offset], &r[r_offset], n, nact, le, &right[1], &w[1], accum,
            &c__0, &eps);
    if (*nact < *le)
    {
        goto L600;
    }
L35:
    if (nactin < 1)
    {
        goto L60;
    }
    i_1 = nactin;
    for (k = 1; k <= i_1; ++k)
    {
        kk = kset[k];
        if (kk < le1 || kk > leli)
        {
            goto L50;
        }
        nact1 = *nact + 1;
        if (nact1 > *n)
        {
            goto L60;
        }
        i_2 = *n;
        for (i = 1; i <= i_2; ++i)
        {
/* L40: */
            r[i + nact1 * r_dim1] = dc[kk + i * dc_dim1];
        }
        uttrns_(&u[u_offset], n, nact, accum, &r[nact1 * r_dim1 + 1], &w[1]);
        addcol_(&u[u_offset], &r[r_offset], n, nact, &c__1, &right[1], &w[1],
                accum, &c__0, &eps);
        if (*nact < nact1)
        {
            goto L50;
        }
        right[nact1] = -c[kk];
        kset[nact1] = kk;
        kstat[kk] = 1;
L50:
        ;
    }
L60:
    rtsolv_(&r[r_offset], n, nact, &right[1], &x[1]);
    if (*nact == *n)
    {
        goto L80;
    }
    nact1 = *nact + 1;
    i_1 = *n;
    for (i = nact1; i <= i_1; ++i)
    {
/* L70: */
        x[i] = 0.;
    }
L80:
    utrns_(&u[u_offset], n, nact, accum, &x[1], &w[1]);
/*     UPDATE THE CONSTRAINTS. */
    matvec_(&dc[dc_offset], &x[1], ic, &leli, n, &cup[1]);
    i_1 = leli;
    for (i = 1; i <= i_1; ++i)
    {
/* L100: */
        cup[i] += c[i];
    }
/*     INITIALIZE INEQUALITY CONSTRAINT LOOP. */
    i_1 = leli;
    for (i = le1; i <= i_1; ++i)
    {
/* L120: */
        if (cup[i] < 0. && kstat[i] == 0)
        {
            kstat[i] = -1;
        }
    }
/*     ACTIVATE VIOLATED INEQUALITY CONSTRAINTS ONE BY ONE. */
/*     USE THE STRONGEST VIOLATED AS OBJECTIVE CONSTRAINT. */
L150:
    fmin = 1e73;
    i_1 = leli;
    for (i = le1; i <= i_1; ++i)
    {
        if (kstat[i] != -1)
        {
            goto L160;
        }
        if (cup[i] >= fmin)
        {
            goto L160;
        }
        fmin = cup[i];
        new_ = i;
L160:
        ;
    }
    if (fmin >= 0.)
    {
        return 0;
    }
    i_1 = *n;
    for (i = 1; i <= i_1; ++i)
    {
/* L170: */
        right[i] = dc[new_ + i * dc_dim1];
    }
    uttrns_(&u[u_offset], n, nact, accum, &right[1], &w[1]);
    kstat[new_] = 1;
/*     DEAD POINT? */
L200:
    if (*nact == *n)
    {
        goto L240;
    }
    t = 0.;
    dln2 = 0.;
    if (*nact == 0)
    {
        goto L220;
    }
    i_1 = *nact;
    for (i = 1; i <= i_1; ++i)
    {
/* Computing 2nd power */
        d_1 = right[i];
        t += d_1 * d_1;
/* L210: */
        dl[i] = 0.;
    }
L220:
    nact1 = *nact + 1;
    i_1 = *n;
    for (i = nact1; i <= i_1; ++i)
    {
/* Computing 2nd power */
        d_1 = right[i];
        dln2 += d_1 * d_1;
/* L230: */
        dl[i] = right[i];
    }
    t += dln2;
    if (t > 1e-40 && dln2 > eps * eps * t)
    {
        goto L300;
    }
/*     - YES - CALCULATE MULTIPLIERS AND SKIP AN ACTIVE */
/*     CONSTRAINT IF POSSIBLE. */
L240:
    if (*nact == *le)
    {
        goto L600;
    }
    rsolv_(&r[r_offset], n, nact, &right[1], &aset[1]);
    amax = -1e73;
    i_1 = *nact;
    for (i = le1; i <= i_1; ++i)
    {
        if (aset[i] < amax)
        {
            goto L250;
        }
        k = i;
        amax = aset[i];
L250:
        ;
    }
    if (amax <= 0.)
    {
        goto L600;
    }
    kstat[kset[k]] = 0;
    i_1 = leli;
    for (i = le1; i <= i_1; ++i)
    {
/* L260: */
        if (kstat[i] == -2)
        {
            kstat[i] = 0;
        }
    }
    if (*accum)
    {
        goto L270;
    }
    *accum = TRUE_;
    haccum_(&u[u_offset], n, nact, &w[1]);
L270:
    delcol_(&k, &u[u_offset], &r[r_offset], n, nact, &right[1], &c__1);
    if (k > *nact)
    {
        goto L200;
    }
    i_1 = *nact;
    for (i = k; i <= i_1; ++i)
    {
/* L280: */
        kset[i] = kset[i + 1];
    }
    goto L200;
/*     - NO  - CALCULATE STEP DIRECTION. */
L300:
    utrns_(&u[u_offset], n, nact, accum, &dl[1], &w[1]);
/*     PROJECT GRADIENTS ON STEP DIRECTION. */
    matvec_(&dc[dc_offset], &dl[1], ic, &leli, n, &dldc[1]);
/*     CALCULATE STEP LENGTH ANES TO MAKE THE OBJECTIVE CONSTRAINT */
/*     EQUAL ZERO, AND CALCULATE THE STEP LENGTH AMIN TO THE */
/*     NEAREST INACTIVE CONSTRAINT UNDER CONSIDERATION. */
    anes = -cup[new_] / dln2;
L310:
    amin = 1e73;
    i_1 = leli;
    for (i = le1; i <= i_1; ++i)
    {
        if (kstat[i] != 0)
        {
            goto L320;
        }
        t = dldc[i];
        if (t >= -1e-50)
        {
            goto L320;
        }
        t = -cup[i] / t;
        if (t > amin)
        {
            goto L320;
        }
        amin = t;
        k = i;
L320:
        ;
    }
/*     WILL THE OBJECTIVE CONSTRAINT GET ACTIVE */
/*     IF NOT, MAKE ACTIVE THE CLOSEST. */
    object = anes <= amin;
    alfa = FORTRAN_MIN(amin,anes);
    nact1 = *nact + 1;
    if (object)
    {
        goto L370;
    }
    i_1 = *n;
    for (i = 1; i <= i_1; ++i)
    {
/* L350: */
        r[i + nact1 * r_dim1] = dc[k + i * dc_dim1];
    }
    uttrns_(&u[u_offset], n, nact, accum, &r[nact1 * r_dim1 + 1], &w[1]);
    addcol_(&u[u_offset], &r[r_offset], n, nact, &c__1, &right[1], &w[1],
            accum, &c__1, &eps);
    if (nact1 == *nact)
    {
        goto L360;
    }
    kstat[k] = -2;
    goto L310;
L360:
    kstat[k] = 1;
    kset[*nact] = k;
/*     TAKE THE STEP. */
L370:
    if (alfa == 0.)
    {
        goto L410;
    }
    i_1 = *n;
    for (i = 1; i <= i_1; ++i)
    {
/* L380: */
        x[i] += alfa * dl[i];
    }
    i_1 = leli;
    for (i = 1; i <= i_1; ++i)
    {
        t = cup[i] + alfa * dldc[i];
        if (kstat[i] == -1 && t >= 0.)
        {
            kstat[i] = 0;
        }
/* L400: */
        cup[i] = t;
    }
L410:
    if (! object)
    {
        goto L200;
    }
/*     ACTIVATE THE OBJECTIVE CONSTRAINT. */
    i_1 = *n;
    for (i = 1; i <= i_1; ++i)
    {
/* L500: */
        r[i + nact1 * r_dim1] = right[i];
    }
    addcol_(&u[u_offset], &r[r_offset], n, nact, &c__1, &right[1], &w[1],
            accum, &c__0, &eps);
    if (*nact == nact1)
    {
        goto L510;
    }
    kstat[new_] = 0;
    goto L150;
L510:
    kset[*nact] = new_;
    goto L150;
/*     NO FEASIBLE POINTS. */
L600:
    *icontr = 3;
    return 0;
} /* feasi_ */



int linsys_(doublereal *a,
            doublereal *b,
            integer    *idim,
            integer    *n,
            integer    *nr,
            doublereal *seps)
{
    /* System generated locals */
    integer a_dim1, a_offset, i_1, i_2, i_3;
    doublereal d_1;

    /* Local variables */
    integer i, j, k;
    doublereal s;
    integer i0, k1, n1;
    doublereal am;

/*     THE SUBROUTINE SOLVES A SYSTEM OF LINEAR EQUATIONS */
/*     USING GAUSSIAN ELIMINATION */
    /* Parameter adjustments */
    --b;
    a_dim1 = *idim;
    a_offset = a_dim1 + 1;
    a -= a_offset;

    /* Function Body */
    *nr = 0;
/*     A IS CONSIDERED TO BE OF RANK K-1 IF THE ABSOLUTE VALUE */
/*     OF THE K'TH PIVOT IS LESS THAN K*SEPS. */
    if ((i_1 = *n - 1) < 0)
    {
        goto L200;
    } else if (i_1 == 0)
    {
        goto L1;
    }
    else
    {
        goto L10;
    }
L1:
    if ((d_1 = a[a_dim1 + 1], abs(d_1)) < 1e-50)
    {
        return 0;
    }
    *nr = 1;
    b[1] /= a[a_dim1 + 1];
    return 0;
/*     EQUILIBRATION IN THE INFINITY NORM. */
L10:
    i_1 = *n;
    for (i = 1; i <= i_1; ++i)
    {
        am = (d_1 = a[i + a_dim1], abs(d_1));
        i_2 = *n;
        for (j = 2; j <= i_2; ++j)
        {
            s = (d_1 = a[i + j * a_dim1], abs(d_1));
/* L20: */
            if (am < s)
            {
                am = s;
            }
        }
        if (am < 1e-50)
        {
            am = 1.;
        }
        b[i] /= am;
        i_2 = *n;
        for (j = 1; j <= i_2; ++j)
        {
/* L30: */
            a[i + j * a_dim1] /= am;
        }
    }
/*     ELIMINATION */
    n1 = *n - 1;
    i_2 = n1;
    for (k = 1; k <= i_2; ++k)
    {
        *nr = k - 1;
/*     FIND PIVOTAL ROW. */
        am = (d_1 = a[k + k * a_dim1], abs(d_1));
        i0 = k;
        k1 = k + 1;
        i_1 = *n;
        for (i = k1; i <= i_1; ++i)
        {
            s = (d_1 = a[i + k * a_dim1], abs(d_1));
            if (s <= am)
            {
                goto L40;
            }
            am = s;
            i0 = i;
L40:
            ;
        }
        if (am < (k << 1) * *seps)
        {
            return 0;
        }
        if (i0 == k)
        {
            goto L60;
        }
/*     INTERCHANGE EQUATIONS K AND I0 */
        i_1 = *n;
        for (j = k; j <= i_1; ++j)
        {
            s = a[k + j * a_dim1];
            a[k + j * a_dim1] = a[i0 + j * a_dim1];
/* L50: */
            a[i0 + j * a_dim1] = s;
        }
        s = b[k];
        b[k] = b[i0];
        b[i0] = s;
/*     STORE PIVOT IN AM AND ELIMINATE IN ROWS K+1 TO N. */
L60:
        am = a[k + k * a_dim1];
        i_1 = *n;
        for (i = k1; i <= i_1; ++i)
        {
            s = a[i + k * a_dim1] / am;
            i_3 = *n;
            for (j = k1; j <= i_3; ++j)
            {
/* L70: */
                a[i + j * a_dim1] -= s * a[k + j * a_dim1];
            }
/* L80: */
            b[i] -= s * b[k];
        }
    }
    *nr = n1;
    if ((d_1 = a[*n + *n * a_dim1], abs(d_1)) < (*n << 1) * *seps)
    {
        return 0;
    }
/*     A HAS FULL RANK */
    *nr = *n;
/*     BACK SUBSTITUTION. */
    b[*n] /= a[*n + *n * a_dim1];
    k = *n;
    i_1 = *n;
    for (i = 2; i <= i_1; ++i)
    {
        k1 = k;
        --k;
        s = b[k];
        i_2 = *n;
        for (j = k1; j <= i_2; ++j)
        {
/* L90: */
            s -= a[k + j * a_dim1] * b[j];
        }
/* L100: */
        b[k] = s / a[k + k * a_dim1];
    }
L200:
    return 0;
} /* linsys_ */

int bfgs_(doublereal *b,
          integer    *n,
          doublereal *y,
          doublereal *xx,
          doublereal *w,
          doublereal *seps)
{
    /* System generated locals */
    integer b_dim1, b_offset, i_1, i_2;
    doublereal d_1, d_2;

    /* Local variables */
    integer i, j;
    doublereal t;
    integer i1;
    doublereal eps, wxx, yxx;

/*     UPDATES A HESSIAN APPROXIMATION USING BFGS-FORMULA. */
    /* Parameter adjustments */
    --w;
    --xx;
    --y;
    b_dim1 = *n;
    b_offset = b_dim1 + 1;
    b -= b_offset;

    /* Function Body */
    eps = (*n + 10) * *seps;
    i_1 = *n;
    for (i = 1; i <= i_1; ++i)
    {
        t = 0.;
        i_2 = *n;
        for (j = 1; j <= i_2; ++j)
        {
/* L10: */
            t += b[i + j * b_dim1] * xx[j];
        }
/* L20: */
        w[i] = t;
    }
    yxx = 0.;
    wxx = 0.;
    i_1 = *n;
    for (i = 1; i <= i_1; ++i)
    {
        yxx += y[i] * xx[i];
/* L30: */
        wxx += w[i] * xx[i];
    }
    if (wxx < 1e-40 || yxx < eps * wxx)
    {
        return 0;
    }
    i_1 = *n;
    for (i = 1; i <= i_1; ++i)
    {
/* L40: */
/* Computing 2nd power */
        d_1 = y[i];
/* Computing 2nd power */
        d_2 = w[i];
        b[i + i * b_dim1] = b[i + i * b_dim1] + d_1 * d_1 / yxx - d_2 * d_2 /
                wxx;
    }
    if (*n == 1)
    {
        return 0;
    }
    i_1 = *n;
    for (i = 2; i <= i_1; ++i)
    {
        i1 = i - 1;
        i_2 = i1;
        for (j = 1; j <= i_2; ++j)
        {
            b[i + j * b_dim1] = b[i + j * b_dim1] + y[i] * y[j] / yxx - w[i] *
                     w[j] / wxx;
/* L50: */
            b[j + i * b_dim1] = b[i + j * b_dim1];
        }
    }
    return 0;
} /* bfgs_ */

int addcol_(doublereal *u,
            doublereal *r,
            integer    *n,
            integer    *kcol,
            integer    *knew,
            doublereal *right,
            doublereal *w,
            logical    *accum,
            logical    *lright,
            doublereal *eps)
{
    /* System generated locals */
    integer u_dim1, u_offset, r_dim1, r_offset, i_1, i_2, i_3;
    doublereal d_1;

    /* Local variables */
    doublereal alfa, beta;
    integer i, j, k;
    doublereal s, t;
    integer k1, k2, kk;
    doublereal tt;

/*     UPDATES HOUSEHOLDER FACTORIZATION. */
/*     THE NEW COLUMNS MUST HAVE BEEN TRANSFORMED */
/*     AS RIGHTHAND SIDES. */
    /* Parameter adjustments */
    --w;
    --right;
    r_dim1 = *n;
    r_offset = r_dim1 + 1;
    r -= r_offset;
    u_dim1 = *n;
    u_offset = u_dim1 + 1;
    u -= u_offset;

    /* Function Body */
    k1 = *kcol + 1;
    k2 = *kcol + *knew;
/*     COLUMN LOOP STARTS HERE */
    i_1 = k2;
    for (k = k1; k <= i_1; ++k)
    {
        s = 0.;
        t = 0.;
        if (k == 1)
        {
            goto L20;
        }
        kk = k - 1;
        i_2 = kk;
        for (i = 1; i <= i_2; ++i)
        {
/* L10: */
/* Computing 2nd power */
            d_1 = r[i + k * r_dim1];
            t += d_1 * d_1;
        }
L20:
        i_2 = *n;
        for (i = k; i <= i_2; ++i)
        {
/* L30: */
/* Computing 2nd power */
            d_1 = r[i + k * r_dim1];
            s += d_1 * d_1;
        }
        t += s;
        t = sqrt(t);
        s = sqrt(s);
/*       RETURN IF THE NEW COLUMN DEPENDS LINEARLY ON THE */
/*       PRECEEDING COLUMNS */
        if (t == 0.)
        {
            return 0;
        }
        if (s < t * *eps)
        {
            return 0;
        }
/*       PERFORM HOUSEHOLDER TRANSFORMATION */
        tt = r[k + k * r_dim1];
        t = abs(tt);
        alfa = sqrt(s * (s + t));
        beta = -d_sign(&s, &tt);
        r[k + k * r_dim1] = beta;
        w[k] = (tt - beta) / alfa;
        if (k == *n)
        {
            goto L80;
        }
        kk = k + 1;
        i_2 = *n;
        for (i = kk; i <= i_2; ++i)
        {
/* L40: */
            w[i] = r[i + k * r_dim1] / alfa;
        }
/*       TRANSFORM THE REMAINING COLUMNS */
        if (k == k2)
        {
            goto L80;
        }
        i_2 = k2;
        for (j = kk; j <= i_2; ++j)
        {
            t = 0.;
            i_3 = *n;
            for (i = k; i <= i_3; ++i)
            {
/* L50: */
                t += w[i] * r[i + j * r_dim1];
            }
            i_3 = *n;
            for (i = k; i <= i_3; ++i)
            {
/* L60: */
                r[i + j * r_dim1] -= t * w[i];
            }
/* L70: */
        }
/*       TRANSFORM THE RIGHTHAND SIDE */
L80:
        if (! (*lright))
        {
            goto L110;
        }
        t = 0.;
        i_2 = *n;
        for (i = k; i <= i_2; ++i)
        {
/* L90: */
            t += w[i] * right[i];
        }
        i_2 = *n;
        for (i = k; i <= i_2; ++i)
        {
/* L100: */
            right[i] -= t * w[i];
        }
/*       ACCUMULATE THE TRANSFORMATIONS IN U */
/*       U MUST HAVE BEEN INITIALIZED */
L110:
        if (*accum)
        {
            goto L130;
        }
        i_2 = *n;
        for (i = k; i <= i_2; ++i)
        {
/* L120: */
            u[i + k * u_dim1] = w[i];
        }
        goto L200;
L130:
        i_2 = *n;
        for (i = 1; i <= i_2; ++i)
        {
            t = 0.;
            i_3 = *n;
            for (j = k; j <= i_3; ++j)
            {
/* L140: */
                t += u[i + j * u_dim1] * w[j];
            }
            i_3 = *n;
            for (j = k; j <= i_3; ++j)
            {
/* L150: */
                u[i + j * u_dim1] -= t * w[j];
            }
/* L160: */
        }
L200:
        ++(*kcol);
    }
    return 0;
} /* addcol_ */

int delcol_(integer    *k,
            doublereal *u,
            doublereal *r,
            integer    *n,
            integer    *kcol,
            doublereal *right,
            logical    *lright)
{
    /* System generated locals */
    integer u_dim1, u_offset, r_dim1, r_offset, i_1, i_2;

    /* Local variables */
    doublereal a, c;
    integer i, j;
    doublereal s, x, y;
    integer j1, k1, kk;

/*     DELETES COLUMN NO. K IN THE FACTORIZED MATRIX. */
/*     K MUST SATISFY      1.LE.K.LE.KCOL */
/*     U MUST HAVE BEEN ACCUMULATED. */
/*     DELETE COLUMN NUMBER K */
    /* Parameter adjustments */
    --right;
    r_dim1 = *n;
    r_offset = r_dim1 + 1;
    r -= r_offset;
    u_dim1 = *n;
    u_offset = u_dim1 + 1;
    u -= u_offset;

    /* Function Body */
    --(*kcol);
    if (*k > *kcol)
    {
        return 0;
    }
    i_1 = *kcol;
    for (j = *k; j <= i_1; ++j)
    {
        j1 = j + 1;
        i_2 = j1;
        for (i = 1; i <= i_2; ++i)
        {
/* L10: */
            r[i + j * r_dim1] = r[i + j1 * r_dim1];
        }
    }
/*     TRANSFORM TO UPPER TRIANGULAR FORM */
/*     USING STANDARD GIVENS TRANSFORMATIONS */
    i_2 = *kcol;
    for (kk = *k; kk <= i_2; ++kk)
    {
        k1 = kk + 1;
        x = r[kk + kk * r_dim1];
        y = r[k1 + kk * r_dim1];
        a = sqrt(x * x + y * y);
        c = x / a;
        s = y / a;
        r[kk + kk * r_dim1] = c * x + s * y;
        if (kk == *kcol)
        {
            goto L60;
        }
        i_1 = *kcol;
        for (j = k1; j <= i_1; ++j)
        {
            x = r[kk + j * r_dim1];
            y = r[k1 + j * r_dim1];
            r[kk + j * r_dim1] = c * x + s * y;
/* L50: */
            r[k1 + j * r_dim1] = c * y - s * x;
        }
L60:
        if (! (*lright))
        {
            goto L70;
        }
        x = right[kk];
        y = right[k1];
        right[kk] = c * x + s * y;
        right[k1] = c * y - s * x;
/*       ACCUMULATE THE TRANSFORMATIONS */
L70:
        i_1 = *n;
        for (i = 1; i <= i_1; ++i)
        {
            x = u[i + kk * u_dim1];
            y = u[i + k1 * u_dim1];
            u[i + kk * u_dim1] = c * x + s * y;
/* L80: */
            u[i + k1 * u_dim1] = c * y - s * x;
        }
/* L100: */
    }
    return 0;
} /* delcol_ */


int uttrns_(doublereal *u,
            integer    *n,
            integer    *kcol,
            logical    *accum,
            doublereal *r,
            doublereal *w)
{
    /* System generated locals */
    integer u_dim1, u_offset, i_1, i_2;

    /* Local variables */
    integer i, k;
    doublereal t;

/*     TRANSFORM THE VECTOR R AS A RIGHTHAND SIDE. */
/*     IF THE TRANSFORMATIONS HAVE BEEN ACCUMULATED */
/*     DO SIMPLE MATRIX-MULTIPLICATION. */
/*     ELSE TRANSFORM LIKE RIGHTHAND SIDES. */
    /* Parameter adjustments */
    --w;
    --r;
    u_dim1 = *n;
    u_offset = u_dim1 + 1;
    u -= u_offset;

    /* Function Body */
    if (*accum)
    {
        goto L100;
    }
    if (*kcol == 0)
    {
        return 0;
    }
    i_1 = *kcol;
    for (k = 1; k <= i_1; ++k)
    {
        t = 0.;
        i_2 = *n;
        for (i = k; i <= i_2; ++i)
        {
/* L10: */
            t += r[i] * u[i + k * u_dim1];
        }
        i_2 = *n;
        for (i = k; i <= i_2; ++i)
        {
/* L20: */
            r[i] -= t * u[i + k * u_dim1];
        }
/* L30: */
    }
    return 0;
L100:
    i_1 = *n;
    for (i = 1; i <= i_1; ++i)
    {
/* L110: */
        w[i] = r[i];
    }
    i_1 = *n;
    for (k = 1; k <= i_1; ++k)
    {
        t = 0.;
        i_2 = *n;
        for (i = 1; i <= i_2; ++i)
        {
/* L120: */
            t += u[i + k * u_dim1] * w[i];
        }
/* L130: */
        r[k] = t;
    }
    return 0;
} /* uttrns_ */

int utrns_(doublereal *u,
           integer    *n,
           integer    *kcol,
           logical    *accum,
           doublereal *r,
           doublereal *w)
{
    /* System generated locals */
    integer u_dim1, u_offset, i_1, i_2;

    /* Local variables */
    integer i, j, k;
    doublereal t;
    integer k1, kk;

/*     TRANSFORM THE VECTOR R OPPOSITE A RIGHTHAND SIDE. */
    /* Parameter adjustments */
    --w;
    --r;
    u_dim1 = *n;
    u_offset = u_dim1 + 1;
    u -= u_offset;

    /* Function Body */
    k1 = *kcol + 1;
    if (*accum)
    {
        goto L100;
    }
    if (*kcol == 0)
    {
        return 0;
    }
    i_1 = *kcol;
    for (kk = 1; kk <= i_1; ++kk)
    {
        k = k1 - kk;
        t = 0.;
        i_2 = *n;
        for (j = k; j <= i_2; ++j)
        {
/* L10: */
            t += u[j + k * u_dim1] * r[j];
        }
        i_2 = *n;
        for (j = k; j <= i_2; ++j)
        {
/* L20: */
            r[j] -= t * u[j + k * u_dim1];
        }
/* L30: */
    }
    return 0;
L100:
    i_1 = *n;
    for (i = 1; i <= i_1; ++i)
    {
/* L110: */
        w[i] = r[i];
    }
    i_1 = *n;
    for (i = 1; i <= i_1; ++i)
    {
        t = 0.;
        i_2 = *n;
        for (j = 1; j <= i_2; ++j)
        {
/* L120: */
            t += u[i + j * u_dim1] * w[j];
        }
/* L130: */
        r[i] = t;
    }
    return 0;
} /* utrns_ */


int rsolv_(doublereal *r,
           integer    *n,
           integer    *kcol,
           doublereal *right,
           doublereal *x)
{
    /* System generated locals */
    integer r_dim1, r_offset, i_1;

    /* Local variables */
    integer j, k;
    doublereal t;
    integer k1;

/*     PERFORM BACK SUBSTITUTION ON RIGHT. */
/*     CALCULATE ALFA USING BACK SUBSTITUTION ON R */
    /* Parameter adjustments */
    --x;
    --right;
    r_dim1 = *n;
    r_offset = r_dim1 + 1;
    r -= r_offset;

    /* Function Body */
    k = *kcol;
    k1 = k + 1;
L10:
    if (k == 0)
    {
        return 0;
    }
    t = right[k];
    if (k1 > *kcol)
    {
        goto L30;
    }
    i_1 = *kcol;
    for (j = k1; j <= i_1; ++j)
    {
/* L20: */
        t -= x[j] * r[k + j * r_dim1];
    }
L30:
    x[k] = t / r[k + k * r_dim1];
    k1 = k;
    --k;
    goto L10;
} /* rsolv_ */


int rtsolv_(doublereal *r,
            integer    *n,
            integer    *kcol,
            doublereal *right,
            doublereal *x)
{
    /* System generated locals */
    integer r_dim1, r_offset, i_1, i_2;

    /* Local variables */
    integer i, j;
    doublereal t;
    integer i1;

/*     PERFORM BACK SUBSTITUTION ON RIGHT USING THE */
/*     TRANSPOSED TRIANGULAR MATRIX. */
    /* Parameter adjustments */
    --x;
    --right;
    r_dim1 = *n;
    r_offset = r_dim1 + 1;
    r -= r_offset;

    /* Function Body */
    if (*kcol == 0)
    {
        return 0;
    }
    x[1] = right[1] / r[r_dim1 + 1];
    if (*kcol == 1)
    {
        return 0;
    }
    i_1 = *kcol;
    for (i = 2; i <= i_1; ++i)
    {
        i1 = i - 1;
        t = right[i];
        i_2 = i1;
        for (j = 1; j <= i_2; ++j)
        {
/* L10: */
            t -= x[j] * r[j + i * r_dim1];
        }
/* L20: */
        x[i] = t / r[i + i * r_dim1];
    }
    return 0;
} /* rtsolv_ */


int haccum_(doublereal *u,
            integer    *n,
            integer    *kcol,
            doublereal *w)
{
    /* System generated locals */
    integer u_dim1, u_offset, i_1, i_2, i_3;
    doublereal d_1;

    /* Local variables */
    integer i, j, k, l;
    doublereal s, t;
    integer i1, k1, kk, kp1;

/*     ACCUMULATES HOUSEHOLDER VECORS STORED IN LOWER TRIANGLE */
/*     OF THE FIRST KCOL COLUMNS OF U IN AN ORTHONORMAL MATRIX U. */
/*     THE HOUSEHOLDER VECTORS MUST HAVE TWO NORM EQUAL TO TWO. */
/*     KCOL.GE.1 . */
/*     INITIALIZE USING LAST TRANSFORMATION */
    /* Parameter adjustments */
    --w;
    u_dim1 = *n;
    u_offset = u_dim1 + 1;
    u -= u_offset;

    /* Function Body */
    k1 = *kcol + 1;
    i_1 = *n;
    for (i = *kcol; i <= i_1; ++i)
    {
/* L10: */
        w[i] = u[i + *kcol * u_dim1];
    }
    i_1 = *n;
    for (i = *kcol; i <= i_1; ++i)
    {
/* L20: */
/* Computing 2nd power */
        d_1 = w[i];
        u[i + i * u_dim1] = 1. - d_1 * d_1;
    }
    if (*kcol == *n)
    {
        goto L40;
    }
    i_1 = *n;
    for (i = k1; i <= i_1; ++i)
    {
        i1 = i - 1;
        t = w[i];
        i_2 = i1;
        for (j = *kcol; j <= i_2; ++j)
        {
            s = -t * w[j];
            u[i + j * u_dim1] = s;
/* L30: */
            u[j + i * u_dim1] = s;
        }
    }
L40:
    if (*kcol == 1)
    {
        return 0;
    }
/*     ACCUMULATE REMAINING TRANSFORMATIONS */
    i_2 = *kcol;
    for (kk = 2; kk <= i_2; ++kk)
    {
        k = k1 - kk;
        i_1 = *n;
        for (i = k; i <= i_1; ++i)
        {
/* L50: */
            w[i] = u[i + k * u_dim1];
        }
        t = w[k];
        kp1 = k + 1;
/* Computing 2nd power */
        d_1 = t;
        u[k + k * u_dim1] = 1. - d_1 * d_1;
        i_1 = *n;
        for (i = kp1; i <= i_1; ++i)
        {
/* L60: */
            u[i + k * u_dim1] = -t * w[i];
        }
        i_1 = *n;
        for (l = kp1; l <= i_1; ++l)
        {
            s = 0.;
            i_3 = *n;
            for (i = kp1; i <= i_3; ++i)
            {
/* L70: */
                s += w[i] * u[i + l * u_dim1];
            }
            u[k + l * u_dim1] = -t * s;
            i_3 = *n;
            for (i = kp1; i <= i_3; ++i)
            {
/* L80: */
                u[i + l * u_dim1] -= s * w[i];
            }
/* L90: */
        }
/* L100: */
    }
    return 0;
} /* haccum_ */


int limit_(doublereal *xnmax2,
           doublereal *x,
           doublereal *xn2,
           doublereal *p,
           doublereal *pn2,
           doublereal *alfa,
           integer    *n)
{
    /* System generated locals */
    integer i_1;

    /* Local variables */
    doublereal b;
    integer i;
    doublereal t, am, ap, xtp;

/*     LIMIT THE STEP LENGTH ALFA. */
    /* Parameter adjustments */
    --p;
    --x;

    /* Function Body */
    xtp = 0.;
    i_1 = *n;
    for (i = 1; i <= i_1; ++i)
    {
/* L10: */
        xtp += x[i] * p[i];
    }
    b = xtp / *pn2;
    t = sqrt(b * b + (*xnmax2 - *xn2) / *pn2);
    ap = t - b;
    am = -t - b;
    if (*alfa > ap)
    {
        *alfa = ap;
    }
    if (*alfa < am)
    {
        *alfa = am;
    }
    return 0;
} /* limit_ */


int matvec_(doublereal *a,
            doublereal *x,
            integer    *ia,
            integer    *m,
            integer    *n,
            doublereal *y)
{
    /* System generated locals */
    integer a_dim1, a_offset, i_1, i_2;

    /* Local variables */
    integer i, j;
    doublereal t;

    /* Parameter adjustments */
    --y;
    --x;
    a_dim1 = *ia;
    a_offset = a_dim1 + 1;
    a -= a_offset;

    /* Function Body */
    if (*m == 0)
    {
        return 0;
    }
    i_1 = *m;
    for (i = 1; i <= i_1; ++i)
    {
        t = 0.;
        i_2 = *n;
        for (j = 1; j <= i_2; ++j)
        {
/* L10: */
            t += a[i + j * a_dim1] * x[j];
        }
/* L20: */
        y[i] = t;
    }
    return 0;
} /* matvec_ */


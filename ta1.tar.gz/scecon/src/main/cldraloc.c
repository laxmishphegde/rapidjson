/* SCID @(#)cldraloc.c	1.18 (SimCorp) 99/10/27 14:25:37 */

/************************************************************************
*
*   project     SCecon
*
*   file name   cldraloc.c
*
*   general     This file contains allocating routines for calendar
*               calculations
*
************************************************************************/

#include <cldr.h>


/*,,SOH,,
*************************************************************************
*
*               Alloc_DATEARRAY()
*
*    interface  #include <cldr.h>
*               DATEARRAY Alloc_DATEARRAY(INTI n);
*
*    general    Alloc_DATEARRAY() allocates memory for an
*               [0...(n-1)] array of DATESTR's.
*               Returns memory with zero'ed entries
*
*    input      INTI    n       The number of entries in the array
*
*    output
*
*    returns    reference to the vector of type DATESTR
*
*    diagnostics aborts calling SCecon_error()
*                with the message   "Allocation failed"
*                         routine   "Alloc_DATEARRAY()"
*                         actioncode SCECONABORT
*                if allocation fails
*
*    see also   Free_DATEARRAY()
*
*************************************************************************
,,EOH,,*/


DATEARRAY Alloc_DATEARRAY(INTI n)
{
    DATEARRAY a;

    a = (DATEARRAY) SCecon_calloc(n, sizeof(DATESTR), True, 
      "Alloc_DATEARRAY()") ;

    return a ;
}


/*,,SOH,,
*************************************************************************
*
*               Free_DATEARRAY()
*
*    interface  #include <cldr.h>
*               void Free_DATEARRAY(DATEARRAY date) ;
*
*    general    Free_DATEARRAY() frees memory for an array
*               of DATESTR's allocated by Alloc_DATEARRAY()
*
*    input      DATEARRAY date          Reference to the array of dates
*
*    output
*
*    returns
*
*    diagnostics
*
*    see also   Alloc_DATEARRAY()
*
*************************************************************************
,,EOH,,*/


void Free_DATEARRAY(DATEARRAY date)
{
    SCecon_free((VOIDPTR) date) ;
}

/*,,SOH,,
*************************************************************************
*
*               Alloc_YMDARRAY()
*
*    interface  #include <cldr.h>
*               YMDARRAY Alloc_YMDARRAY(INTI n) ;
*
*    general    Alloc_YMDARRAY()  allocates memory for a
*               [0...(n-1)] array of dates in YYYYMMDD format
*               Returns memory with zero'ed entries
*
*    input      INTI    n    The number of entries in the array
*
*    output
*
*    returns    reference to the vector of type YYYYMMDD.
*
*    diagnostics aborts calling SCecon_error()
*                with the message   "Allocation failed"
*                         routine   "Alloc_YMDARRAY()"
*                         actioncode SCECONABORT
*                if allocation fails
*
*    see also   Free_YMDARRAY()
*
*************************************************************************
,,EOH,,*/


YMDARRAY Alloc_YMDARRAY(INTI n)
{
    YMDARRAY a ;

    a = (YMDARRAY) SCecon_calloc(n, sizeof(YYYYMMDD), True, 
      "Alloc_YMDARRAY()") ;

    return a ;
}


/*,,SOH,,
*************************************************************************
*
*               Free_YMDARRAY()
*
*    interface  #include <cldr.h>
*               void Free_YMDARRAY(YMDARRAY date) ;
*
*    general    Free_YMDARRAY() frees memory for an [0...(n-1)]
*               array of YYYYMMDD's allocated by Alloc_YMDARRAY().
*
*    input      YMDARRAY  date          Reference to the array
*
*    output
*
*    returns
*
*    diagnostics
*
*    see also   Alloc_YMDARRAY()
*
*************************************************************************
,,EOH,,*/


void Free_YMDARRAY(YMDARRAY date)
{
    SCecon_free((VOIDPTR) date) ;
}


/*,,SOH,,
*************************************************************************
*
*               Alloc_STEPARRAY()
*
*    interface  #include <cldr.h>
*               STEPARRAY Alloc_STEPARRAY(INTI n);
*
*    general    Alloc_STEPARRAY() allocates memory for an
*               [0...(n-1)] array of STEP_STR's.
*               Returns memory with zero'ed entries
*
*    input      INTI    n       The number of entries in list
*
*    output
*
*    returns    reference to the vector of type STEP_STR
*
*    diagnostics aborts calling SCecon_error()
*                with the message   "Allocation failed"
*                         routine   "Alloc_STEPARRAY()"
*                         actioncode SCECONABORT
*                if allocation fails
*
*    see also   Free_STEPARRAY()
*
*************************************************************************
,,EOH,,*/


STEPARRAY Alloc_STEPARRAY(INTI n)
{
    STEPARRAY a;

    a = (STEPARRAY) SCecon_calloc(n, sizeof(STEP_STR), True,
      "Alloc_STEPARRAY()") ;

    return a ;
}


/*,,SOH,,
*************************************************************************
*
*               Free_STEPARRAY()
*
*    interface  #include <cldr.h>
*               void Free_STEPARRAY(STEPARRAY date) ;
*
*    general    Free_STEPARRAY() frees memory for an array
*               of STEP_STR's allocated by Alloc_STEPARRAY()
*
*    input      STEPARRAY date          Reference to the array
*
*    output
*
*    returns
*
*    diagnostics
*
*    see also   Alloc_STEPARRAY()
*
*************************************************************************
,,EOH,,*/


void Free_STEPARRAY(STEPARRAY date)
{
    SCecon_free((VOIDPTR) date) ;
}


/*,,SOH,,
*************************************************************************
*
*               Free_HOLI_STR()
*
*    interface  #include <cldr.h>
*               void Free_HOLI_STR(HOLI_STR *h) ;
*
*    general    The routine free a HOLI_STR.
*
*    input      HOLI_STR  *h           Reference to the array
*
*    output
*
*    returns
*
*    diagnostics
*
*    see also
*
*************************************************************************
,,EOH,,*/

void Free_HOLI_STR(HOLI_STR*  h)
{
    if (h != NULL)
        Free_DATEARRAY(h->holidays) ;
}


/*,,SOH,,
***********************************************************************
*                                                         
*               Alloc_HOLIRULEARRAY()                     
*                                                         
*    interface  #include <cldr.h>                         
*               HOLIRULEARRAY Alloc_HOLIRULEARRAY(INTI n);
*                                                       
*    general    HOLIRULEARRAY() allocates memory for an 
*               [0...(n-1)] array of HOLIRULE's.           
*               Returns memory with zero'ed entries       
*                                                         
*    input      INTI    n       The number of entries in the array
*                                                      
*    output                                            
*                                                      
*    returns    reference to the vector of type HOLIRULE
*                                             
*    diagnostics aborts calling SCecon_error()
*                with the message   "Allocation failed"
*                         routine   "Alloc_HOLIRULEARRAY()"
*                         actioncode SCECONABORT
*                if allocation fails
*                                   
*    see also   Free_HOLIRULEARRAY()
*                                                      
***********************************************************************
,,EOH,,*/

HOLIRULEARRAY Alloc_HOLIRULEARRAY(INTI  n)
{
    return (HOLIRULEARRAY) SCecon_calloc(n, sizeof(HOLIRULE), True, "Alloc_HOLIRULEARRAY()") ;
}

/*,,SOH,,
*************************************************************************
*                                                               
*               Free_HOLIRULEARRAY()                            
*                                                               
*    interface  #include <cldr.h>                               
*               void Free_HOLIRULEARRAY(HOLIRULEARRAY array) ;  
*                                                               
*    general    Free_HOLIRULEARRAY() frees memory for an array  
*               of HOLIRULE's allocated by Alloc_HOLIRULEARRAY()
*                                                               
*    input      HOLIRULEARRAY array   Reference to the array of 
*                                     HOLIRULE's 
*                                                               
*    output                                                     
*                                                               
*    returns                                                    
*                                                               
*    diagnostics                                                
*                                                               
*    see also   Alloc_HOLIRULEARRAY()                           
*                                                               
*************************************************************************
,,EOH,,*/


void Free_HOLIRULEARRAY(HOLIRULEARRAY  array)
{
    SCecon_free(array);
}


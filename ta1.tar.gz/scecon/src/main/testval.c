/* SCID @(#)testval.c	1.11 (SimCorp) 99/02/19 14:17:15 */

/************************************************************************
*
*   project     SCecon
*
************************************************************************/

/*** includes ***********************************************************/
#include <string.h>
#include <str2conv.h>
#include <validate.h>

INTI valtest(char* txa, FILE* in, FILE* out)
{
    char        txb[80], txc[80], txe[80], txpl[80] ;
    INTI        diff ;
    VALIDATE    val, exp_val ;
    DATESTR     date ;
    DISCFAC     df ;
    FL64ARRAY   fl64array ;
    INTI        n ;
    BOOLE       lbound, ubound, sign ;
    FL64        lb, ub ;
    PLANARRAY   plan_str ;
    SORTCONV    sc ;
    DATESTR     dummy_date ;
    HOLI_STR    holi ;
    DFSPREAD    dfs ;
    VOL_STR     vol ;
    RISKSET     risk ;

    date  = dummy_date = Cldr_YMD2Datestr((YYYYMMDD) 0) ;
    diff = -1 ;

    if (!strcmp("Validate_DISCFAC()", txa))
    {
        fscanf(in, "%s %s", txe, txpl) ;

        exp_val = Str2VALIDATE(txe) ;

        fprintf(out, "   \n Testing %s\n", txa) ;
        fprintf(out, "   %s\n", txpl) ;

        df  = Read_DISCFAC(in, out) ;
        val = Validate_DISCFAC(&df) ;
        VALIDATE2Str(val, txc) ;

        diff = (val == exp_val ? 0 : 1) ;
        fprintf(out,"%d;  Exp %s Res %s\n", diff, txe, txc) ;

        Free_PLANARRAY(df.disc, 1) ;
    }

    else if (!strcmp("Validate_FL64ARRAY()", txa))
    {
        fscanf(in, "%s %s", txe, txpl) ;

        exp_val = Str2VALIDATE(txe) ;

        fprintf(out, "   \n Testing %s\n", txa) ;
        fprintf(out, "   %s\n", txpl) ;

        fl64array = Read_FL64ARRAY(in, &n) ;
        Write_FL64ARRAY(out, fl64array, n) ;
        fscanf(in, "%s %lf %s %lf", txb, &lb, txc, &ub) ;
        lbound = Str2BOOLE(txb) ;
        ubound = Str2BOOLE(txc) ;
        fprintf(out, "  Lower bound             %8s\n", txb) ;
        fprintf(out, "  Value of lower bound        %4.4lf\n", lb) ;
        fprintf(out, "  Upper bound             %8s\n", txc) ;
        fprintf(out, "  Value of upper bound        %4.4lf\n", ub) ;

        val       = Validate_FL64ARRAY(fl64array, n, lbound, lb, ubound,
          ub) ;
        VALIDATE2Str(val, txc) ;

        diff = (val == exp_val ? 0 : 1) ;
        fprintf(out,"%d;  Exp %s Res %s\n", diff, txe, txc) ;

        Free_FL64ARRAY(fl64array) ;
    }

    else if (!strcmp("Validate_PLAN_STR()", txa))
    {
        fscanf(in, "%s %s", txe, txpl) ;

        exp_val = Str2VALIDATE(txe) ;

        fprintf(out, "   \n Testing %s\n", txa) ;
        fprintf(out, "   %s\n", txpl) ;

        plan_str = Read_PLANARRAY(in) ;
        Write_PLANARRAY(out, plan_str) ;

        val = Validate_PLAN_STR(plan_str) ;
        VALIDATE2Str(val, txc) ;

        diff = (val == exp_val ? 0 : 1) ;
        fprintf(out,"%d;  Exp %s Res %s\n", diff, txe, txc) ;

        Free_PLANARRAY(plan_str, 1) ;
    }

    else if (!strcmp("Validate_PLAN_STR_SUM100()", txa))
    {
        fscanf(in, "%s %s", txe, txpl) ;

        exp_val = Str2VALIDATE(txe) ;

        fprintf(out, "   \n Testing %s\n", txa) ;
        fprintf(out, "   %s\n", txpl) ;

        plan_str = Read_PLANARRAY(in) ;
        Write_PLANARRAY(out, plan_str) ;

        val = Validate_PLAN_STR_SUM100(plan_str) ;
        VALIDATE2Str(val, txc) ;

        diff = (val == exp_val ? 0 : 1) ;
        fprintf(out,"%d;  Exp %s Res %s\n", diff, txe, txc) ;

        Free_PLANARRAY(plan_str, 1) ;
    }

    else if (!strcmp("Validate_PLAN_STR_SORTED()", txa))
    {
        fscanf(in, "%s %s", txe, txpl) ;

        exp_val = Str2VALIDATE(txe) ;

        fprintf(out, "   \n Testing %s\n", txa) ;
        fprintf(out, "   %s\n", txpl) ;

        plan_str = Read_PLANARRAY(in) ;
        Write_PLANARRAY(out, plan_str) ;

        fscanf(in, "%s", txb) ;
        sc = Str2SORTCONV(txb) ;
        fprintf(out, "   Sorting Convention:   %8s\n", txb) ;

        val = Validate_PLAN_STR_SORTED(plan_str, sc) ;
        VALIDATE2Str(val, txc) ;

        diff = (val == exp_val ? 0 : 1) ;
        fprintf(out,"%d;  Exp %s Res %s\n", diff, txe, txc) ;

        Free_PLANARRAY(plan_str, 1) ;
    }

    else if (!strcmp("Validate_PLAN_STR_SIGN()", txa))
    {
        fscanf(in, "%s %s", txe, txpl) ;

        exp_val = Str2VALIDATE(txe) ;

        fprintf(out, "   \n Testing %s\n", txa) ;
        fprintf(out, "   %s\n", txpl) ;

        plan_str = Read_PLANARRAY(in) ;
        Write_PLANARRAY(out, plan_str) ;

        fscanf(in, "%s", txb) ;
        sign = Str2BOOLE(txb) ;
        fprintf(out, "   Sign:   %8s\n", txb) ;

        val = Validate_PLAN_STR_SIGN(plan_str, sign) ;
        VALIDATE2Str(val, txc) ;

        diff = (val == exp_val ? 0 : 1) ;
        fprintf(out,"%d;  Exp %s Res %s\n", diff, txe, txc) ;

        Free_PLANARRAY(plan_str, 1) ;
    }

    else if (!strcmp("Validate_HOLI_STR()", txa))
    {
        fscanf(in, "%s %s", txe, txpl) ;

        exp_val = Str2VALIDATE(txe) ;

        fprintf(out, "   \n Testing %s\n", txa) ;
        fprintf(out, "   %s\n", txpl) ;

        holi = Read_HOLI_STR(in, out) ;

        val = Validate_HOLI_STR(&holi) ;
        VALIDATE2Str(val, txc) ;

        diff = (val == exp_val ? 0 : 1) ;
        fprintf(out,"%d;  Exp %s Res %s\n", diff, txe, txc) ;

        Free_DATEARRAY(holi.holidays) ;
    }

    else if (!strcmp("Validate_DFSPREAD()", txa))
    {
        fscanf(in, "%s %s", txe, txpl) ;

        exp_val = Str2VALIDATE(txe) ;

        fprintf(out, "   \n Testing %s\n", txa) ;
        fprintf(out, "   %s\n", txpl) ;

        dfs = Read_DFSPREAD(in, out) ;

        val = Validate_DFSPREAD(&dfs) ;
        VALIDATE2Str(val, txc) ;

        diff = (val == exp_val ? 0 : 1) ;
        fprintf(out,"%d;  Exp %s Res %s\n", diff, txe, txc) ;

        Free_DFSPREAD(&dfs) ;
    }

    else if (!strcmp("Validate_VOL_STR()", txa))
    {
        fscanf(in, "%s %s", txe, txpl) ;

        exp_val = Str2VALIDATE(txe) ;

        fprintf(out, "   \n Testing %s\n", txa) ;
        fprintf(out, "   %s\n", txpl) ;

        vol = Read_VOL_STR(in, out) ;

        val = Validate_VOL_STR(&vol) ;
        VALIDATE2Str(val, txc) ;

        diff = (val == exp_val ? 0 : 1) ;
        fprintf(out,"%d;  Exp %s Res %s\n", diff, txe, txc) ;

        Free_PLANARRAY(vol.vol, 1) ;
    }

    else if (!strcmp("Validate_RISKSET()", txa))
    {
        fscanf(in, "%s %s", txe, txpl) ;

        exp_val = Str2VALIDATE(txe) ;

        fprintf(out, "   \n Testing %s\n", txa) ;
        fprintf(out, "   %s\n", txpl) ;

        risk = Read_RISKSET(in, out) ;

        val = Validate_RISKSET(&risk) ;
        VALIDATE2Str(val, txc) ;

        diff = (val == exp_val ? 0 : 1) ;
        fprintf(out,"%d;  Exp %s Res %s\n", diff, txe, txc) ;

        Free_PLANARRAY(risk.loads, 1) ;
    }

    return diff ;
}

/* SCID @(#)vol.c	1.38 (SimCorp) 99/10/28 17:41:56 */

/************************************************************************
*
*   project     SCecon
*
*   filename    vol.c
*
*   contains    routines in the SCecon Volatility library
*
************************************************************************/

/***** includes ********************************************************/
#include <vol.h>
#include <validate.h>

/***** defines  ********************************************************/
#define TERM_TOL  0.001
#define VOL_TOL   1.0E-10


/*,,SOH,,
*************************************************************************
*
*               Vol_Ann2Per()
*
*    interface  #include <vol.h>
*               FL64 Vol_Ann2Per(FL64 vol,
*                                FL64 t) ;
*
*    general    The function returns the periodic volatility from the
*               annual volatility.
*
*    input      FL64    vol   The annual volatility in percent.
*
*               FL64    t     The period in fractional years.
*
*    output
*
*    returns    the periodic volatility.
*
*    diagnostics
*
*    see also
*
*************************************************************************
,,EOH,,*/


FL64 Vol_Ann2Per(FL64 vol, FL64 t)
{
    return vol * sqrt(t) ;
}


/*,,SOH,,
*************************************************************************
*
*               Vol_Per2Ann()
*
*    interface  #include <vol.h>
*               FL64 Vol_Per2Ann(FL64 vol,
*                                FL64 t) ;
*
*    general    The function returns the annual volatility from
*               the periodic volatility.
*               If the period is less than a day - then zero annual
*               volatility is returned.
*
*    input      FL64    vol   The periodic volatility in percent.
*
*               FL64    t     The period in fractional years.
*
*    output
*
*    returns    the annual volatility.
*
*    diagnostics
*
*    see also
*
*************************************************************************
,,EOH,,*/


FL64 Vol_Per2Ann(FL64 vol, FL64 t)
{
    return (fabs(t) > TERM_TOL ? vol/sqrt(t) : 0.0) ;
}


/*
*************************************************************************
*
*               Vol_Get_Vol()
*
*    interface  #include <vol.h>
*               TSOVARRAY Vol_Get_Vol(TSOV_STR   *tsin,
*                                    FL64ARRAY  terms,
*                                    INTI       n,
*                                    INTPOLCONV intpol) ;
*
*    general    Vol_Get_Vol() finds the volatilities corresponding to
*               terms and returns these.
*
*    input      TSOV_STR   *tsin   Reference to the input volatility
*                                  structure.
*
*               FL64ARRAY  terms   Reference to array of terms, at
*                                  which vols are to be found.
*
*               INTI       n       The number of elements in terms.
*
*               INTPOLCONV intpol  The interpolation convention.
*
*    output
*
*    returns    Pointer to the volatility structure. Allocated in this
*               routine as: Alloc_TSOVARRAY(1, tsin->count)
*
*    diagnostics
*
*    see also   Vol_Interpolation()
*
*************************************************************************
*/


TSOVARRAY Vol_Get_Vol(TSOV_STR* tsin,
                     FL64ARRAY  terms,
                     INTI       n,
                     INTPOLCONV intpol)
{
    INTI      i ;
    TSOVARRAY tsout ;
    FL64      *tmp ;

    tsout = Alloc_TSOVARRAY(1, n) ;
    tsout->count = n ;

    tmp = Math_IntpolArray(terms, n, tsin->count, tsin->term, tsin->vol,
                            intpol) ;

    for (i = 0 ; i < n ; i++)
    {
        tsout->term[i] = terms[i] ;
        tsout->vol[i]  = tmp[i] ;
    }

    Free_FL64ARRAY(tmp) ;

    return tsout ;
}


/*,,SOH,,
*************************************************************************
*
*               Vol_Interpolation()
*
*    interface  #include <vol.h>
*               FL64 Vol_Interpolation(DATESTR   *date,
*                                      VOL_STR   *v) ;
*
*    general    The function performs interpolation in a VOL_STR
*               using day counts as x-values.
*
*               Only simple linear interpolation is used. Before the
*               first observation the curve is assumed to be flat.
*
*               Any adjustment for businessdays must be performed
*               prior to calling this function.
*
*    input      DATESTR   *date   The date for which an interpolated
*                                 volatility is sought.
*
*               VOL_STR   *v      The volatilities in which to 
*                                 interpolate. Also contains conventions
*                                 defining the interpolation.
*
*	       	    HOLI_STR  *holi	  Container for list of holidays.
*
*    output
*
*    returns    The interpolated volatility.
*               If vol contains no observations, 0.0 is returned.
*
*    diagnostics
*
*    see also   Math_Interpolation()
*
*    wrapper    AP
*
*************************************************************************
,,EOH,,*/


FL64 Vol_Interpolation(DATESTR* date, VOL_STR*  v, HOLI_STR* holi)
{
    INTI     nfill ;
    FL64     res, *pf64 ;
    DATESTR  *pday ;

    nfill = GetPlanFill(v->vol) ;
    pf64  = GetPlanF64(v->vol) ;
    pday  = GetPlanDay(v->vol) ;

    if (!Validate_INTPOLCONV(v->iconv))
        res = 0.0;

    if (nfill == 0)
        res = 0.0 ;

    else if (nfill == 1)
        res = pf64[0] ;

    else if (Cldr_DateLT(date, &pday[0]) == True)
        res = pf64[0] ;

    else if (Cldr_DateLT(&pday[nfill - 1], date))
        res = Cldr_Plan_Intpol(date, v->vol, v->cal, v->iconv, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
    else
        res = Cldr_Plan_Intpol(date, v->vol, v->cal, v->iconv, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */

    return res ;
}


/*
..handles default shock = 100 bp
..ds == True -> days are shocked
*/


VOL_STR Vol_Shock_Vol(VOL_STR* vol, FL64 shock, BOOLE ds)
{
    PLANARRAY tmp;
    VOL_STR vols ;
    INTI    i ;
    INTL    days ;
    DATESTR day ;

	/* PMSTA-22396 - SRIDHARA � 160502 */
	HOLI_STR holi;
	holi = Set_HOLI_STR(NO_BUSADJUST, 0, NULL);

    tmp = Alloc_PLANARRAY(1, GetPlanFill(vol->vol)) ;
    vols = Set_VOL_STR(tmp, vol->cal, vol->vc, vol->iconv); 

    if (shock <= 0.0001)
        shock = 1.0 ;

    for (i = 0; i < GetPlanFill(vol->vol) ; i++)
    {
        if (ds == False)
            Cldr_InsertInPlan(&vol->vol->day[i], vol->vol->f64[i] + shock,
                                vols.vol, True) ;
        else
        {
            days = (INTL) (shock + 0.0001) ;
            day  = Cldr_AddDays(&vol->vol->day[i], days, vol->cal, &holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
            Cldr_InsertInPlan(&day, vol->vol->f64[i], vols.vol, True) ;
        }
    }

    return vols ;
}


/*
*************************************************************************
*
*               Vol_Get_TSOVqot()
*
*    interface  #include <vol.h>
*               FL64 Vol_Get_TSOVqot(TSOV_STR   *tsin,
*                                    FL64       term,
*                                    INTPOLCONV intpol) ;
*
*    general    The funciton finds the vol at maturity term
*               from the input TSOV tsovin.
*               Intpol is a convention used to interpolate.
*
*    input      TSOV_STR   *tsovin  Reference to the input TSOV
*
*               FL64       term    Term for desired vol quote
*
*               INTPOLCONV intpol  The interpolation convention
*
*    output
*
*    returns    vol in percent.
*
*    diagnostics
*
*    see also   Vol_Get_Vol()
*
*************************************************************************
*/


FL64 Vol_Get_TSOVqot(TSOV_STR* tsin,
                     FL64       term,
                     INTPOLCONV intpol)
{
    FL64 res ;

    res = Math_Interpolation(term, tsin->count, tsin->term, tsin->vol, intpol) ;

    return res ;
}


/*,,SOH,,
**************************************************************************
*
*                Vol_Spot2Forw()
*
*    interface   #include <vol.h>
*                FL64 Vol_Spot2Forw(DATESTR *today,
*                                  VOL_STR *ts,
*                                  DATESTR *date1,
*                                  DATESTR *date2)
*
*    general     The function computes forward volatilities from a spot
*                volatility term structure (assuming no auto-correlation)*
*                Interpolations are linear
*                All volatilities are annually quoted
*
*    input       DATESTR     *today    'spot date' for spot volatilities
*
*                VOL_STR     *ts       term structure of spot vols
*
*                DATESTR     *date1    first date of forward period
*
*                DATESTR     *date2    last date of forward period
*
*	       	     HOLI_STR    *holi	  Container for list of holidays.
*
*    output
*
*    returns     Forward volatility for period between date1 and date2
*
*    diagnostics
*
*    see also    
*
**************************************************************************
,,EOH,,*/


FL64 Vol_Spot2Forw(DATESTR* today,
                  VOL_STR* ts,    /* term strucure of spot vol's */
                  DATESTR* date1,
                  DATESTR* date2,
				  HOLI_STR* holi)
{
    FL64        vol1, vol2, term1, term2, tmp, diff, vol ;

	/* PMSTA-22396 - SRIDHARA � 160502 */
    /* get the (spot) vol's on input dates    */
    vol1 = Vol_Interpolation(date1, ts, holi) ;
    vol2 = Vol_Interpolation(date2, ts, holi) ;

    /* get the terms for the input dates */
    term1 = Cldr_TermBetweenDates(today, date1, 0, ts->cal, SAME, holi) ;
    term2 = Cldr_TermBetweenDates(today, date2, 0, ts->cal, SAME, holi) ;

    if ((diff = term2 - term1) <= 0.0)
        return 0.0 ;

    /* do the spot to forward calculation (assuming no auto-correlation) */
    tmp = term2 * vol2 * vol2 ;
    tmp -= term1 * vol1 * vol1 ;
    if (tmp < 0.0)
        return 0.0 ;

    tmp /= diff ;
    vol  = sqrt(tmp) ;

    return vol ;
}


/*    This function performs a look-up in a general volatility structure.
    All interpolation is linear with flat extrapolation outside the
    index range(s) of the input volatility matrix.
*/


FL64    Vol_Linear_Lookup(  VOLBOX*   tsov,
                            DATESTR*     today,
                            DATESTR*     optmatur,
                            FL64        strike,
                            PERIOD*      swapmatur,
                            HOLI_STR*    holi)
{
    FL64        vol ;
    INTI        om, s, sm ;
    FL64        ddd, ddu, dud, duu, udd, udu, uud, uuu ; /* the 8 corners */
    FL64        dom, ds, dsm, uom, us, usm ;             /* the up and down
      dists */
    FL64        tu, td, t, tmp ;
    FL64        dh, dl, dn, dpy ;
    VOLBOX      *ts ;
    DATESTR     tmpdate ;
    BOOLE        new1 ;

    /* warning avoidance */
    vol = 0.0 ;

    /* make sure the index arrays encompass the input point */
    ts = Vol_Extrapol(tsov, optmatur, strike, swapmatur, holi, &new1) ;

     /* find the grid point coordinates of the 8 corners */
    for (om = 0; om < ts->filled_OM
            && Cldr_DateLT(&ts->optmatur[om], optmatur); om++)
        ;
    for (s = 0; s < ts->filled_S && strike > ts->strike[s]; s++)
        ;
    for (sm = 0; sm < ts->filled_SM && Cldr_PeriodST(&ts->swapmatur[sm],
                        swapmatur, optmatur, holi, ts->cal, ts->eom); sm++)
        ;

    /* find the relevant volatility horizons */
	/* PMSTA-22396 - SRIDHARA � 160502 */
    t = Cldr_TermBetweenDates(today, optmatur, 0, ts->cal, ts->eom, holi) ;
    tu = Cldr_TermBetweenDates(today, &ts->optmatur[om], 0, ts->cal, ts->eom, holi) ;
    td = Cldr_TermBetweenDates(today, &ts->optmatur[om - 1], 0, ts->cal,
      ts->eom, holi) ;

    /* get #days per year */
    tmpdate = Cldr_AddMonths(today, 12, ts->eom) ;
    dpy = Cldr_DaysPerYear(today, &tmpdate, 0, tsov->cal, ts->eom, holi) ;

    /* find the vol's at the 8 corners */
    ddd = ts->vol[om - 1][s - 1][sm - 1] ;
    ddu = ts->vol[om - 1][s - 1][sm] ;
    dud = ts->vol[om - 1][s][sm - 1] ;
    duu = ts->vol[om - 1][s][sm] ;
    udd = ts->vol[om][s - 1][sm - 1] ;
    udu = ts->vol[om][s - 1][sm] ;
    uud = ts->vol[om][s][sm - 1] ;
    uuu = ts->vol[om][s][sm] ;

    /* get the interpolation quantities at the 8 corners */
    switch (ts->in_what)
    {
        case VAR:  /* transform vol's to var's */
            ddd *= td * ddd ;
            ddu *= td * ddu ;
            dud *= td * dud ;
            duu *= td * duu ;
            udd *= tu * udd ;
            udu *= tu * udu ;
            uud *= tu * uud ;
            uuu *= tu * uuu ;
            break ;

        case STDEV:   /* transform vol's to st.dev's */
            ddd *= sqrt(td) ;
            ddu *= sqrt(td) ;
            dud *= sqrt(td) ;
            duu *= sqrt(td) ;
            udd *= sqrt(tu) ;
            udu *= sqrt(tu) ;
            uud *= sqrt(tu) ;
            uuu *= sqrt(tu) ;
            break ;

        case VOL:  /* do nothing */
        default:
            break ;
    }

	/* PMSTA-22396 - SRIDHARA � 160502 */
    /* find up and down dists */
    dom = Cldr_TermBetweenDates(&ts->optmatur[om - 1], optmatur, 0, ts->cal,
      ts->eom, holi) ;
    uom = Cldr_TermBetweenDates(optmatur, &ts->optmatur[om], 0, ts->cal,
      ts->eom, holi) ;
    ds  = strike - ts->strike[s - 1] ;
    us  = ts->strike[s] - strike ;
    dl = (FL64) Cldr_DaysInPeriod(optmatur, &ts->swapmatur[sm - 1], ts->cal,
      ts->eom, holi) ;
    dh = (FL64) Cldr_DaysInPeriod(optmatur, &ts->swapmatur[sm], ts->cal,
      ts->eom, holi) ;
    dn = (FL64) Cldr_DaysInPeriod(optmatur, swapmatur, ts->cal, ts->eom, holi) ;
    dsm = (dn - dl) / dpy ;
    usm = (dh - dn) / dpy ;

    /* do the interpolation */
    /* (if something other than linear interpolation is required this should be
      moved
        to a separate function)  */
    tmp  = ddd * uom * us * usm ;
    tmp += ddu * uom * us * dsm ;
    tmp += dud * uom * ds * usm ;
    tmp += duu * uom * ds * dsm ;
    tmp += udd * dom * us * usm ;
    tmp += udu * dom * us * dsm ;
    tmp += uud * dom * ds * usm ;
    tmp += uuu * dom * ds * dsm ;

    tmp /= (dom + uom) * (ds + us) * (dsm + usm) ;

    /* compute vol from interpolated quantitiy */
    switch (ts->in_what)
    {
        case VAR:
            tmp /= t ;
            vol = sqrt(tmp) ;
            break ;

        case STDEV:
            vol = tmp / sqrt(t) ;
            break ;

        case VOL:
            vol = tmp ;
        default:
            break ;
    }

    /* Free */
    if (new1)
        Free_VOLBOX(ts) ;

    /* return */
    return vol ;
}


/*     This function takes a vol matrix and a 3D point. It returns a volatility
    matrix identical to the input one on all the grid points of the input vol
    matrix but extended if necessary (by constant extrapolation) to encompass
    also the input point.
    If one of the 'filled' members of the input vol matrix is zero the output
      vol
    matrix will have two entries in the corresponding index array---one on
      either
    side of the input point.
*/


VOLBOX *Vol_Extrapol(VOLBOX*   ts,
                     DATESTR*     optmatur,
                     FL64        strike,
                     PERIOD*      swapmatur,
                     HOLI_STR*    holi,
                     BOOLE*       new1)
{
    VOLBOX  *tse ;
    BOOLE   lom = False, hom = False, ls = False,
            hs = False, lsm = False, hsm = False ;
    INTI    i, j, k ;

    /* find out the relative location of the input point */
    if (!ts->filled_OM)
        lom = hom = True ;
    else if (Cldr_DateLE(optmatur, &ts->optmatur[0]))
        lom = True ;
    else if (Cldr_DateLE(&ts->optmatur[ts->filled_OM - 1], optmatur))
        hom = True ;
    if (!ts->filled_S)
        ls = hs = True ;
    else if (strike <= ts->strike[0])
        ls = True ;
    else if (strike >= ts->strike[ts->filled_S - 1])
        hs = True ;
    if (!ts->filled_SM)
        lsm = hsm = True ;
    else if (Cldr_PeriodSE(swapmatur, &ts->swapmatur[0], optmatur, holi,
                                            ts->cal, ts->eom))
        lsm = True ;
    else if (Cldr_PeriodSE(&ts->swapmatur[ts->filled_SM - 1], swapmatur,
                                        optmatur, holi, ts->cal, ts->eom))
        hsm = True ;

    if (!lom && !hom && !ls && !hs && !lsm && !hsm)
    {
        *new1 = False ;
        return ts ;
    }
    else
        *new1 = True ;

    /* allocate for output */
    tse = Alloc_VOLBOX(ts->filled_OM + lom + hom, ts->filled_S + ls + hs,
                            ts->filled_SM + lsm + hsm) ;

    /* copy over some data */
    tse->price_vol = ts->price_vol ;
    tse->cal = ts->cal ;
    tse->eom = ts->eom ;
    tse->in_what = ts->in_what ;
    tse->ipol = ts->ipol ;
    tse->volconv = ts->volconv ;

    /* copy over the index arrays */
    tse->filled_OM = ts->filled_OM + lom + hom ;
    if (lom)
        tse->optmatur[0] = Cldr_AddDays(optmatur, -7, ACTACT, NULL) ;   	/* PMSTA-22396 - SRIDHARA � 160502 */
    for (i = 0; i < ts->filled_OM; i++)
        tse->optmatur[i + lom] = ts->optmatur[i] ;
    if (hom)
        tse->optmatur[tse->filled_OM - 1] = Cldr_AddDays(optmatur, 7, ACTACT, NULL) ;   	/* PMSTA-22396 - SRIDHARA � 160502 */

    tse->filled_S = ts->filled_S + ls + hs ;
    if (ls)
        tse->strike[0] = strike - 10.0  ;
    for (i = 0; i < ts->filled_S; i++)
        tse->strike[i + ls] = ts->strike[i] ;
    if (hs)
        tse->strike[tse->filled_S - 1] = strike + 10.0 ;

    tse->filled_SM = ts->filled_SM + lsm + hsm ;
    if (lsm)
        tse->swapmatur[0].num = swapmatur->num - 1 ;
    for (i = 0; i < ts->filled_SM; i++)
        tse->swapmatur[i + lsm] = ts->swapmatur[i] ;
    if (hsm)
    {
        tse->swapmatur[tse->filled_SM - 1].unit = swapmatur->unit ;
        tse->swapmatur[tse->filled_SM - 1].num = swapmatur->num + 1 ;
    }

    /* copy over the vol's */
    for (i = lom; i < tse->filled_OM - hom; i++)
        for (j = ls; j < tse->filled_S - hs; j++)
            for(k = lsm; k < tse->filled_SM - hsm; k++)
                tse->vol[i][j][k] = ts->vol[i - lom][j - ls][k - lsm] ;

    /* add the extrapolated vol's */
    if (lom)
        for (j = ls; j < tse->filled_S - hs; j++)
            for(k = lsm; k < tse->filled_SM - hsm; k++)
                tse->vol[0][j][k] = tse->vol[1][j][k] ;

    if (hom)
        for (j = ls; j < tse->filled_S - hs; j++)
            for(k = lsm; k < tse->filled_SM - hsm; k++)
                tse->vol[tse->filled_OM - 1][j][k] = tse->vol[tse->filled_OM -
                  2][j][k] ;

    if (ls)
        for (i = 0; i < tse->filled_OM; i++)
            for(k = lsm; k < tse->filled_SM - hsm; k++)
                tse->vol[i][0][k] = tse->vol[i][1][k] ;

    if (hs)
        for (i = 0; i < tse->filled_OM; i++)
            for(k = lsm; k < tse->filled_SM - hsm; k++)
                tse->vol[i][tse->filled_S - 1][k] = tse->vol[i][tse->filled_S -
                  2][k] ;

    if (lsm)
        for (i = 0; i < tse->filled_OM; i++)
            for (j = 0; j < tse->filled_S; j++)
                tse->vol[i][j][0] = tse->vol[i][j][1] ;

    if (hsm)
        for (i = 0; i < tse->filled_OM; i++)
            for (j = 0; j < tse->filled_S; j++)
                tse->vol[i][j][tse->filled_SM - 1] =
                  tse->vol[i][j][tse->filled_SM - 2] ;

    /*  return */
    return tse ;
}

/*
..
*/


/*,,SOH,,
************************************************************************
*
*                Set_VOL_STR()
*
*   interface    #include <vol.h>
*                VOL_STR Set_VOL_STR(PLAN_STR*  vol,
*                                    CALCONV    cal,
*                                    VOLCONV    vc,
*                                    INTPOLCONV iconv) ;
*
*   general      This routine sets the members of the struct defined
*                in the function name. The pointer members are simply
*                assigned - without physical copying. The intention
*                of the Set_*() routines is that by using this
*                functionality, one avoids setting individual members
*                of structs in the application code.
*
*                When new members are inserted in structs the Set_*()
*                routine will be changed accordingly.
*
*                One exception to this principle applies. Whenever
*                OPTADD and vanilla members are used, only the
*                vanilla members are set in the Set_*() routines. The
*                non-vanilla and exotic members are set to defaults,
*                and must be set elsewhere - if needed.
*
*                For details on the interpretation of the individual
*                struct members please check the struct definition.
*
*   input        PLAN_STR*   vol See general section.
*
*                CALCONV     cal See general section.
*
*                VOLCONV     vc  See general section.
*
*                INTPOLCONV  iconv  See general section.
*
*   output
*
*   returns      The filled out VOL_STR struct
*
*   diagnostics
*
*   see also     VOL_STR
*
************************************************************************
,,EOH,,*/

VOL_STR Set_VOL_STR(PLAN_STR* vol, CALCONV cal, VOLCONV vc, 
                       INTPOLCONV  iconv)
{
    VOL_STR vol_str ;

    vol_str.vol = vol ;
    vol_str.cal = cal ;
    vol_str.vc  = vc ;
    vol_str.iconv = iconv ;

    return vol_str ;
}



/*
..
*/


FL64 Vol_Bivariate2Vol(FL64  vol1,
                          FL64  vol2,
                          FL64  corr)
{
  FL64 vol;    
  
  vol = SQR(vol1) + SQR(vol2) - 2.0 * corr * vol1 * vol2;
  
  vol = (vol > VOL_TOL ? sqrt(vol) : 0.0);

  return vol;
}


#undef VOL_TOL
#undef TERM_TOL

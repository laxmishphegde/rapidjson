/* SCID @(#)tvmunit.c	1.27 (SimCorp) 99/02/19 14:17:27 */

/************************************************************************
*
*   project     SCecon
*
*   filename    tvmunit.c
*
*   contains    routines in the SCecon Library Time Value of Money
*               of Unit payments module.
*
************************************************************************/

/*** includes **********************************************************/
#include <tvmunit.h>
#include <tvm.h>


/*** defines  **********************************************************/
#define IRR_ACC   (FL64)     0.0000000001
#define IRR_MAXIT (INTI)   150
#define IRR_GUESS (FL64)    10.0
#define IRR_MIN   (FL64)     0.0
#define IRR_MAX   (FL64)  1000.0
#define IRR_FREQ  (INTI)     1
#define IRR_DAMP  (FL64)     1.0
#define DAY_TOL   (FL64)     0.001


/*,,SOH,,
*************************************************************************
*
*               TVMunit_Yield2Yield()
*
*    interface  #include <tvmunit.h>
*               FL64 TVMunit_Yield2Yield(DATESTR* start,
*                                        DATESTR* end,
*                                        FL64     rate1,
*                                        IRRCONV  irr1,
*                                        PMTFREQ  freq1,
*                                        CALCONV  cal1,
*                                        IRRCONV  irr2,
*                                        PMTFREQ  freq2,
*                                        CALCONV  cal2) ;
*
*    general    The function translates an interest rate (rate1) from
*               one quoting to another quoting.
*
*    input      DATESTR   *start  The start of the rate period.
*
*               DATESTR   *end    The end of the rate period.
*
*               FL64      rate1   The input rate (%)
*
*               IRRCONV   irr1    Rate convention for rate1
*
*               PMTFREQ   freq1   Quoting of rate1.
*
*               CALCONV   cal1    Calendar for rate1
*
*               IRRCONV   irr2    Rate convention for output rate
*
*               PMTFREQ   freq2   Quoting of output rate
*
*               CALCONV   cal2    Calendar for output rate
*
*    output
*
*    returns    The new rate for output quoting conventions
*
*    diagnostics
*
*    see also
*
*    wrapper    AP
*
*************************************************************************
,,EOH,,*/

FL64 TVMunit_Yield2Yield(DATESTR*  start,
                            DATESTR*  end,
                            FL64      rate1,
                            IRRCONV   irr1,
                            PMTFREQ   freq1,
                            CALCONV   cal1,
                            IRRCONV   irr2,
                            PMTFREQ   freq2,
                            CALCONV   cal2)
{
    FL64 PV, t1, t2, rate2 ;
    INTI qb1, qb2 ;

	/* PMSTA-22396 - SRIDHARA � 160502 */
	HOLI_STR holi;
	holi = Set_HOLI_STR(NO_BUSADJUST, 0, NULL);

    /* Find rate1 PV */
    qb1 = TVMunit_set_qbas(freq1) ;
    t1  = Cldr_TermBetweenDates(start, end, 0, cal1, LAST, &holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
    PV  = TVMunit_NPV(t1, rate1, irr1, qb1) ;

    /* Translate this to new rate */
    qb2 = TVMunit_set_qbas(freq2) ;
    t2  = Cldr_TermBetweenDates(start, end, 0, cal2, LAST, &holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
    rate2 = TVMunit_Yield(PV, t2, irr2, qb2) ;

    return rate2 ;
}


/************************************************************************
*
*               tvmunit_moosmuller()
*
*   interface   #include <tvmunit.h>
*
*               FL64 tvmunit_moosmuller(FL64 r,
*                 FL64 t,
*                 FL64 dt,
*                 INTI qb) ;
*
*   general     tvmunit_moosmuller() calculates the present value of a
*               unit payment as function of yield using the Moosmuller
*               method.
*
*   input       FL64      r     Annual Moosmuller yield in percent.
*               FL64      t     Time to payment as fractional years.
*               FL64      dt    Last period of t. Used to indicate
*                               short last period.
*               INTI      qb    Quoting basis of the yield.
*
*   output
*
*   returns     The present value as FL64
*
*   diagnostics
*
*   see also
*
************************************************************************/

FL64 tvmunit_moosmuller(FL64 r,
                        FL64 t,
                        FL64  dt,
                        INTI qb)
{
    FL64 bas, npv, rper, fpart1, ipart1, fpart2, ipart2 ;

    /* First find the periodic rate from the annual */
    bas  = (FL64) qb ;
    rper = (tvmunit_compound(r, - 1.0 / bas, 1) - 1.0) * 100.0 ;

    /* Find the fractional/integer parts of the first part of the term */
    fpart1 = modf((t - dt) * bas, &ipart1) ;

    /* Find the fractional/integer parts of the second part of the term */
    fpart2 = modf(dt * bas, &ipart2) ;

    /* Discount by mixing compounding/moneymarket rate 
       using the period rate */
    npv = tvmunit_compound(rper, ipart1, 1) * tvmunit_simple(rper, fpart1) *
      tvmunit_compound(rper, ipart2, 1) * tvmunit_simple(rper, fpart2);

    return npv ;
}


/************************************************************************
*
*               TVMunit_USTreasury()
*
*   interface   #include <tvmunit.h>
*
*               FL64 TVMunit_USTreasury(FL64 r, FL64 t, INTI qb) ;
*
*   general     TVMunit_USTreasury() calculates the present value of a
*               unit payment as function of yield using the US Treasury
*               method.
*
*   input       FL64      r     Annual US Treasury yield in percent.
*               FL64      t     Time to payment as fractional years.
*               INTI      qb    Quoting basis of the yield.
*
*   output
*
*   returns     The present value as FL64
*
*   diagnostics
*
*   see also
*
************************************************************************/


FL64 TVMunit_USTreasury(FL64 r,
                        FL64 t,
                        INTI qb)
{
    FL64 bas, ipart, fpart, npv ;

    /* Find the fractional/integer parts of the term */
    bas   = (FL64) qb ;
    fpart = modf(t * bas, &ipart) ;

    /* Discount by mixing compounding/moneymarket yield */
    npv = tvmunit_compound(r, ipart / bas, qb) * tvmunit_simple(r, fpart / bas);

    return npv ;
}


/************************************************************************
*
*               TVMunit_Braessfangmeyer()
*
*   interface   #include <tvmunit.h>
*               FL64 TVMunit_Braessfangmeyer(FL64 r, FL64 t, FL64 m) ;
*
*   general     TVMunit_Braessfangmeyer() is a function for calculating
*               the present value of a unit payment as a function of
*               Braess-Fangmeyer yield
*
*   input       FL64    r       The Braess Fangmeyer yield in percent
*               FL64    t       Time to payment in fraction of years
*               FL64    m       Time to maturity in fraction of years
*
*   output
*
*   returns     The present value as FL64
*
*   diagnostics
*
*   see also
*
************************************************************************/

FL64 TVMunit_Braessfangmeyer(FL64 r, FL64 t, FL64 m)
{
    FL64 t1, tmp, pf, pv ;
/*
    tmp  = floor(t) ;
    r   /= 100.0 ;

    return pow(1.0 + r, -tmp) / (1.0 + r * (t - tmp)) ;
*/
    r /= 100.0 ;

    if (SCecon_fabs(m - t) > DAY_TOL)
    {
        /* First find value at maturity */
        t1  = m - t ;
        tmp = floor(t1) ;
        pf  = pow(1.0 + r, -tmp) / (1.0 + r * (t1 - tmp)) ;

        /* Now find PV */
        tmp = floor(m) ;
        pv  = pow(1.0 + r, -tmp) / (1.0 + r * (m - tmp)) ;
        pv /= pf ;
    }
    else
    {
        tmp = floor(t) ;
        pv  = pow(1.0 + r, -tmp) / (1.0 + r * (t - tmp)) ;
    }

    return pv ;
}


/************************************************************************
*
*               TVMunit_Simplerepo()
*
*   interface   #include <tvmunit.h>
*               FL64 TVMunit_Simplerepo(FL64 r, FL64 t, FL64 m) ;
*
*   general     The routine is a function for calculating
*               the present value of a unit payment as a function of
*               a SIMPLE_REPO yield
*
*   input       FL64    r       The yield in percent
*               FL64    t       Time to payment in fraction of years
*               FL64    m       Time to maturity in fraction of years
*
*   output
*
*   returns     The present value as FL64
*
*   diagnostics
*
*   see also
*
************************************************************************/

FL64 TVMunit_Simplerepo(FL64 r, FL64 t, FL64 m)
{
    FL64 pf, pv ;

    if (m > t + DAY_TOL)
    {
        /* First find value at maturity */
        pf = 1.0 / tvmunit_simple(r, m - t) ; 

        /* Now find PV */
        pv = tvmunit_simple(r, m) / pf ;
    }

    else if (m < t - DAY_TOL)
    {
        /* First find value at maturity */
        pf = tvmunit_simple(r, t - m) ; 

        /* Now find PV */
        pv = pf * tvmunit_simple(r, m) ;
    }
    else
        pv = tvmunit_simple(r, t) ;

    return pv ;
}


/*
..
*/

FL64 TVMunit_JGBYTM(FL64  r,   /* Yield in % */
                       FL64  t,   /* Term */
                       FL64  C)   /* Coupon in % */
{
    FL64 tmp, p ;

    p = 100.0 + C * t ;
    tmp = 1.0 + r * t / 100.0 ;
    
    if (SCecon_fabs(tmp) > IRR_ACC)
        p /= tmp ;
    else 
        p = 0.0 ;

    return p ;    
}


/*
..
*/

FL64 TVMunit_JGBYTM2rate(FL64  npv,  /* npv of unit pmt */
                            FL64  t,
                            FL64  C)    /* Coupon in % */
{
    FL64 y ;

    if (SCecon_fabs(t) > IRR_ACC && SCecon_fabs(npv) > IRR_ACC)
        y = 100.0 * (C / 100.0 + (1.0 - npv) / t) / npv ;
    else
        y = 0.0 ;

    return y ;
}


/*,,SOH,,
*************************************************************************
*
*               TVMunit_NPV()
*
*    interface  #include <tvmunit.h>
*               FL64 TVMunit_NPV(FL64    t,
*                                FL64    rate,
*                                IRRCONV irr,
*                                INTI    qb) ;
*
*    general    The function calculates the net present value of a
*               unit payment at term t for a given yield and interest
*               rate convention.
*
*               When using BraeesFangmeyer we do not know the maturity.
*               Therefore the function only discounts till today.
*
*    input      FL64    t       The term for the payment in fractional
*                               years.
*
*               FL64    rate    The discounting rate in percent.
*
*               IRRCONV irr     The interest rate convention. The
*
*               INTI    qb      The quoting basis. Only used if irr
*                               requires it.
*
*    output
*
*    returns    the net present value of the unit payment.
*
*    diagnostics
*
*    see also   TVMunit_Mair()
*               TVMunit_Yield()
*               TVMunit_Term()
*
*    wrapper    AP
*
*************************************************************************
,,EOH,,*/

FL64 TVMunit_NPV(FL64 t, FL64 rate, IRRCONV irr, INTI qb)
{
    FL64    npv ;

    npv = 0.0 ;

    switch (irr)
    {
        case COMPOUND:
        case COMPOUNDSIMPLE:
        case COMPOUNDSIMPLE_ODD:
        case MAIR:
            /* Later -- insert reinvestment rate --this is OK for now */
            if (irr == MAIR)
                qb = 1 ;

            npv = tvmunit_compound(rate, t, qb) ;
            break ;

        case US_TREASURY:
            npv = TVMunit_USTreasury(rate, t, qb) ;
            break ;

        case CONTINUOUS:
            npv = tvmunit_continuous(rate, t) ;
            break ;

        case SIMPLE_MM:
            npv = tvmunit_simple(rate, t) ;
            break ;

        case MOOSMULLER:
            npv = tvmunit_moosmuller(rate, t, 0.0, qb) ;
            break ;

        case BRAESSFANGMEYER:
/*..insert maturity here */
            npv = TVMunit_Braessfangmeyer(rate, t, t) ;
            break ;

        case SIMPLE_REPO:
/*..insert maturity here */
            npv = TVMunit_Simplerepo(rate, t, t) ;
            break ;

        case DISCOUNT:
            npv = tvmunit_discount(rate, t) ;
            break ;

		/* PMSTA-35405 - RAK - 190621 - one year later last report */
		case YEAR_FRACTION:
			npv = tvmunit_yearfraction(rate, t);
			break;

        case JGBYTM:
            npv =  TVMunit_JGBYTM(rate, t, 0.0) ;

        default:
            npv = 0.0 ;
            break ;
    }

    return npv ;
}


/*,,SOH,,
*************************************************************************
*
*               TVMunit_Yield()
*
*    interface  #include <tvmunit.h>
*               FL64 TVMunit_Yield(FL64    npv,
*                                  FL64    t,
*                                  IRRCONV irr,
*                                  INTI    qb) ;
*
*    general    The function calculates the rate implicit in the net
*               present value (npv) of a unit payment in t years,
*               according to the interest rate convention and quoting
*               basis.
*
*    input      FL64    npv     The net present value of a unit payment
*                               in t years. Must be positive and less
*                               than or equal to 1.0
*
*               FL64    t       The term for the payment in fractional
*                               years. Must be nonzero.
*
*               IRRCONV irr     The yield convention.
*
*               INTI    qb      The quoting basis. Only used when irr
*                               requires it.
*
*    output
*
*    returns    The implied yield in percent.
*
*    diagnosis
*
*    see also   TVMunit_NPV()
*               TVMunit_Term()
*
*    wrapper    AP
*
*************************************************************************
,,EOH,,*/

FL64 TVMunit_Yield(FL64 npv, FL64 t, IRRCONV irr, INTI qb)
{
    TVMTYPE type ;
    TVMINT  tvm_data ;
    ITERCTRL ctrl ;
    FL64    rate ;
    NR_ERR  err ;  

	/* PMSTA-22396 - SRIDHARA � 160502 */
	HOLI_STR holi;
	holi = Set_HOLI_STR(NO_BUSADJUST, 0, NULL);

    /* initialise */
    rate = 0.0 ;
    if (SCecon_fabs(t) <= IRR_ACC || npv <= IRR_ACC)
        return 0.0 ;

    if (npv > 1.0 && irr != CONTINUOUS && irr != COMPOUND && irr != SIMPLE_MM)
        return 0.0 ;

    switch (irr)
    {
       case COMPOUND:
       case COMPOUNDSIMPLE:
       case COMPOUNDSIMPLE_ODD:
       case MAIR:
            /* Later -- insert reinvestment rate --this is OK for now */
           if (irr == MAIR)
               qb = 1 ;
           rate = tvmunit_compound2rate(npv, t, qb) ;
           break ;

        case CONTINUOUS:
            rate = tvmunit_continuous2rate(npv, t) ;
            break ;

        case SIMPLE_MM:
        case SIMPLE_REPO:
            rate = tvmunit_simple2rate(npv, t) ;
            break ;

        case DISCOUNT:
            rate = tvmunit_discount2rate(npv, t) ;
            break ;

        case MOOSMULLER:
        case BRAESSFANGMEYER:
        case US_TREASURY:

            type = UNIT_TVM ;

            Init_ITERCTRL(&ctrl) ;
            ctrl.maxiter = IRR_MAXIT ;
            ctrl.init_guess = IRR_GUESS ;
            ctrl.lower = IRR_MIN ;
            ctrl.upper = IRR_MAX ;
            ctrl.damp = IRR_DAMP ;
            ctrl.acc = IRR_ACC ;
            ctrl.what_acc = 1 ;
            ctrl.gfreq = IRR_FREQ ;
            ctrl.bisec = 2 ;
            ctrl.shock = 0.0 ;

            tvm_data = TVM_SetTVMINT(type, npv, t, 0.0, NULL, 0, 
              irr, qb, BULLET, NULL, NULL, LINEAR_EXTRAPOL, 0.01) ;

            err = Newton_Raphson(&TVM_NewtonRaphson, &tvm_data, &ctrl, &rate, &holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
            /* We assume that a solution is always found - which is quite OK */

            break ;

        case JGBYTM:
            rate = TVMunit_JGBYTM2rate(npv, t, 0.0) ;
            break ;

        default:
            rate = 0.0 ;
            break ;
    }

    return rate ;
}


/*,,SOH,,
*************************************************************************
*
*               TVMunit_Term()
*
*    interface  #include <tvmunit.h>
*               FL64 TVMunit_Term(FL64    npv,
*                                 FL64    r,
*                                 IRRCONV irr,
*                                 INTI    qb) ;
*
*    general    The function calculates the term implicit in the net
*               present value of a unit payment discounted with the
*               yield - respecting the interest rate convention
*
*    input      FL64    npv     The net present value of a unit payment
*                               in t years. Must be positive.
*
*               FL64    r       The rate in percent. Must be non-zero.
*
*               IRRCONV irr     The interest rate convention. The
*                               following conventions are allowed:
*
*                                            COMPOUND
*                                            CONTINUOUS
*                                            SIMPLE_MM
*                                            DISCOUNT
*
*                INTI   qb      The quoting basis. Only used, when irr
*                               is COMPOUND.
*
*    output
*
*    returns    The implied term in fractional years.
*
*    diagnosis
*
*    see also   TVMunit_NPV()
*               TVMunit_Yield()
*
*************************************************************************
,,EOH,,*/

FL64 TVMunit_Term(FL64 npv, FL64    r, IRRCONV irr, INTI  qb)
{
    FL64    term ;

    term = 0.0 ;

    switch (irr)
    {
       case COMPOUND:
           term = tvmunit_compound2term(npv, r, qb) ;
           break ;

        case CONTINUOUS:
            term = tvmunit_continuous2term(npv, r) ;
            break ;

        case SIMPLE_MM:
            term = tvmunit_simple2term(npv, r) ;
            break ;

        case DISCOUNT:
            term = tvmunit_discount2term(npv, r) ;
            break ;

        default:
            ;
    }
    return term ;
}


/*
..
*/

FL64 TVMunit_Calc_Deriv(FL64 pDD, FL64 pD, FL64 p, FL64 pU,
                        FL64 pUU, FL64 delta, INTI order)
{
    FL64 delt, dN, dU, dD, dM  ;

    if (order <= 0 || order > 4 || SCecon_fabs(delta) < IRR_ACC)
        return p ;

    switch (order)
    {
        case 1:
            dN = (pU - pD) / (2.0 * delta) ;
            break ;

        case 2:
            delt = 0.5 * delta ;
            dD   = TVMunit_Calc_Deriv(0.0, pD, 0.0, p, 0.0, delt, 1) ;
            dU   = TVMunit_Calc_Deriv(0.0, p, 0.0, pU, 0.0, delt, 1) ;
            dN   = (dU - dD) / delta ;
            break ;

        case 3:

            dU = TVMunit_Calc_Deriv(0.0, p, pU, pUU, 0.0, delta, 2) ;
            dD = TVMunit_Calc_Deriv(0.0, pDD, pD, p, 0.0, delta, 2) ;
            dN = (dU - dD) / (2.0 * delta) ;
            break ;

        case 4 :

            dU = TVMunit_Calc_Deriv(0.0, p, pU, pUU, 0.0, delta, 2) ;
            dD = TVMunit_Calc_Deriv(0.0, pDD, pD, p, 0.0, delta, 2) ;
            dM = TVMunit_Calc_Deriv(0.0, pD, p, pU, 0.0, delta, 2) ;
            dN = (dU + dD - 2.0 * dM) / SQR(delta) ;
            break ;
        default:
          dN = 0.0 ;
          break ;
    }

    return dN ;
}


/*
..
*/

INTI TVMunit_Months_Between_Payments(PMTFREQ  freq)
{
    INTI months ;


    switch (freq)
    {
        case TRIANNUALLY:
            months = 36 ;
            break ;
        case BIANNUALLY:
            months = 24 ;
            break ;
        case ANNUALLY:
            months = 12 ;
            break ;
        case SEMIANNUALLY:
            months = 6 ;
            break ;
        case FOURTHMONTHLY:
            months = 4 ;
            break ;
        case QUARTERLY:
            months = 3 ;
            break ;
        case BIMONTHLY:
            months = 2 ;
            break ;
        case MONTHLY:
            months = 1 ;
            break ;
        case NO_FREQUENCY:
        default:
            months = 0 ;
            break ;
    }
    return months ;
}


/*
..
*/

INTI TVMunit_set_qbas(PMTFREQ  freq)
{
    INTI qbas ;

    qbas  = TVMunit_Months_Between_Payments(freq) ;
    qbas  = GETMAX(1, qbas) ;
    qbas  = GETMIN(12, qbas) ;
    qbas  = 12 / qbas ;

    return qbas ;
}

#undef IRR_ACC   
#undef IRR_MAXIT 
#undef IRR_GUESS 
#undef IRR_MIN   
#undef IRR_MAX   
#undef IRR_FREQ  
#undef IRR_DAMP  
#undef DAY_TOL   

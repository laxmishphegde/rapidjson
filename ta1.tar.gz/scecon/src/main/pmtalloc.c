/* SCID @(#)pmtalloc.c	1.17 (SimCorp) 99/10/27 14:25:40 */

/************************************************************************
*
*    project    SCecon
*
*    filename   pmtalloc.c
*
*    general    allocating routines for the cflw module of SCecon
*
************************************************************************/

#include <stdlib.h>
#include <pmt.h>


/*,,SOH,,
***************************************************************************
*
*                Alloc_PMTARRAY()
*
*    interface   #include <pmt.h>
*                PMTARRAY Alloc_PMTARRAY(INTI ns,
*                                        INTI np) ;
*
*    general     Allocates memory for an array that can hold information
*                about ns payment structures.
*                Returns memory with zero'ed entries.
*
*    input       INTI  ns     Number of structures.
*
*                INTI  np     Number of terms and payments per PMT_STR.
*
*    output
*
*    returns     reference to allocated PMT_STR array.
*
*    diagnostics aborts calling SCecon_error()
*                with the message   "Allocation failed"
*                         routine   "Alloc_PMTARRAY()"
*                         actioncode SCECONABORT
*                if allocation fails.
*
*    see also    Free_PMTARRAY()
*
***************************************************************************
,,EOH,,*/


PMTARRAY Alloc_PMTARRAY(INTI ns, INTI  np)
{
    PMTARRAY   a ;
    INTI       i;

    a = (PMTARRAY) SCecon_calloc(ns, sizeof(PMT_STR), True,
      "Alloc_PMTARRAY()") ;

    for (i = 0 ; i < ns ; i++)
    {
        a[i].term    = Alloc_FL64ARRAY(np) ;
        a[i].payment = Alloc_FL64ARRAY(np) ;
    }

    return a ;
}


/*,,SOH,,
***************************************************************************
*
*                Free_PMTARRAY()
*
*    interface   #include <pmt.h>
*                void Free_PMTARRAY(PMTARRAY s,
*                                   INTI     ns) ;
*
*    general     Frees memory for a given number of PMTARRAYS's allocated
*                by Alloc_PMTARRAY().
*
*    input       PMTARRAY s   The structs already allocated.
*
*                INTI     ns  Number of structs in s.
*
*    output
*
*    returns
*
*    diagnostics
*
*    see also    Alloc_PMTARRAY()
*
***************************************************************************
,,EOH,,*/


void Free_PMTARRAY(PMTARRAY s, INTI ns)
{
    INTI  i ;

    if (!s)
        return ;

    ns  = GETMAX(1, ns) ;

    for (i = 0 ; i < ns ; i++)
    {
        Free_FL64ARRAY(s[i].term) ;
        Free_FL64ARRAY(s[i].payment) ;
    }

    SCecon_free((VOIDPTR) s) ;
}



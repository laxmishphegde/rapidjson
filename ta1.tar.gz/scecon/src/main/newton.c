/* SCID @(#)newton.c	1.17 (SimCorp) 99/09/07 13:26:21 */

/************************************************************************
*
*   project     SCecon
*
*   filename    newton.c
*
*   contains    SCecon newton-raphson routines.
*
************************************************************************/

/***** includes ********************************************************/
#include <scutl.h>
#include <cldr.h>   	/* PMSTA-22396 - SRIDHARA � 160502 */

/***** defines  ********************************************************/
/* If changing these defined numbers, please do the changes in the
   header of Newton_Rahpson() as well */
#define SHOCKSIZE 0.01
  /* Used for ctrl->shock */
#define MAXIT   100
  /* Used for ctrl->maxiter */
#define ACC_ROOT 0.000001
  /* Used for ctrl->acc */
#define MIN_GRAD 0.000001

/***** functions *******************************************************/

/*
************************************************************************
*                                                                       
*             Newton_Raphson()                                          
*                                                                       
*   interface #include <scutl.h>
*             NR_ERR Newton_Raphson(                                     
*                             BOOLE (*fctn)(FL64, void*, BOOLE, FL64*, FL64*), 
*                             void *y,                                  
*                             ITERCTRL *ctrl,                           
*                             FL64 *x) ;                               
*                                                                 
*   general   The routine finds the root of a function in a given       
*             interval using the Newton-Raphson method.                 
*                                                                       
*             If the function is known to have a root then the function
*             Math_RootBracket() may be used to bracket the root.
*
*   input     BOOLE    *fctn(FL64, void*, BOOLE, FL64*, FL64*)
*                             The input function f 
*                             with fixed data y and variable x.         
*                             Use as (*fctn)(x, y, True/False, f(x), f'(x)) 
*                             which should return True if things work out.
*                             Toggle True/False determine whether or not 
*                             to compute f'(x).    
*                                                                       
*             void*    y      Fixed data to be passed to f.             
*                                                                       
*             ITERCTRL *ctrl  Iteration Control.
*                        
*                             maxiter controls the number of iterations 
*                             Default is MAXIT. 
*                        
*                             initguess should be between 
*                             lower and upper.
*                             Defaults are NOT allowed.
*                             use_init_guess, use_lower, use_upper are ignored.
*    
*                             damp is used for damping: Should be       
*                             between 0.0 and 1.0; 1.0 means no damping.
*                             default is 1.0. 
*                     
*                             acc controls accuracy.          
*                             Default is ACC_ROOT.
*
*                             what_acc determines what the acc is applied
*                             to: 0 means to x, 1 means to f(x).
*                             Default is 0.
*                      
*                             gfreq means that the gradient is only updated
*                             every gfreq time.
*                             Default is 1.
*
*                             bisec determines which algorithm to use:
*                             0 means standard Newton-Raphson. 
*                             Recommended selection if the function is 
*                             not stable for calculation at the lower 
*                             and upper bounds.
*                             1 means Newton-Raphson with 
*                             bisection. Recommended selection if a 
*                             sensible bracket is known.
*                             2 means Newton-Raphson with bisection 
*                             and use of Math_RootBracket() based on 
*                             init_guess prior to the root finding.
*                             The found bracket will always be inside
*                             the bracket [lower, upper].
*                             Recommended selection if a tight bracket 
*                             is not known.
*                             Default is 1.
*
*                             shock is used for checking multiple roots,
*                             i.e. if x, x +/- shock are roots.     
*                             Default er SHOCKSIZE. shock = 0.0 means 
*                             no checking for multiple roots.
*
*	     HOLI_STR    *holi	  Container for list of holidays.
*                                                                         
*   output    FL64     *x     The root                                    
*                                                                         
*   returns   NR_ERR indicating how the algorithm terminated.
*             NR_ROOT_FOUND means that a single root was found.              
*                                                                         
*   diagnostics                                                           
*                                                                         
*   see also                                                              
*                                                                         
************************************************************************
*/  

/* WARNING: Non-standard Function header. K&R below: */
NR_ERR Newton_Raphson(NEWTONRAPHSON_FCT fctn,
  void *y,
  ITERCTRL *ctrl,
  FL64 *x, void* hol)
{
  INTI      i, maxiter, gfreq;
  FL64      xl, xh, fxl = 0, fxh, fx, dfx = 0, damping, damp, dx, tmp, acc, 
            shock;
  BOOLE     what_acc, bisec_ok, grad, ok;
  NR_ERR    err;
  ITERCTRL  bracket_ctrl;

  /* Initialize */
  i = 1;
  damping = 1.0;
  err = NR_CONT;

  /* Set iteration control */
  maxiter = (( ctrl->maxiter <= 0) ? MAXIT : ctrl->maxiter);
  damp = (((0.0 < ctrl->damp) &&  (ctrl->damp < 1.0)) ? 
    ctrl->damp : 1.0);
  acc = (( ctrl->acc <= 0.0) ? ACC_ROOT : ctrl->acc);
  what_acc = ((ctrl->what_acc == 1) ? True : False); 
  gfreq = ((ctrl->gfreq <= 0) ? 1 : ctrl->gfreq);
  bisec_ok = ((ctrl->bisec == 0) ? False : True);
  shock = (( ctrl->shock < 0.0) ? SHOCKSIZE : ctrl->shock);

  *x = ctrl->init_guess; 
  xl = ctrl->lower;
  xh = ctrl->upper;
  err = (((xl <= *x) && (*x <= xh)) ? err : NR_WRONG_BRACKET);

  /* printf("NR xi %.2lf xl %.2lf xh %.2lf ", *x, xl, xh); */

  /* Bracket the root */
  if (err == NR_CONT && ctrl->bisec == 2)
  {
    Init_ITERCTRL(&bracket_ctrl);
    bracket_ctrl.maxiter = maxiter;
    tmp = fabs(ctrl->init_guess) * 0.1;
    tmp = (tmp < MIN_GRAD ? 1.0 : tmp);
    bracket_ctrl.lower = GETMAX(ctrl->lower, ctrl->init_guess - tmp);
    bracket_ctrl.upper = GETMIN(ctrl->upper, ctrl->init_guess + tmp);
    ok = Math_RootBracket(fctn, y, &bracket_ctrl, &xl, &xh, hol);  /* PMSTA-29444 - SRIDHARA - 050318 */
    if (ok == False)
    {
      *x = ctrl->init_guess; 
      xl = ctrl->lower;
      xh = ctrl->upper;
    }
    else
    {
      xl = GETMAX(ctrl->lower, xl); 
      xh = GETMIN(ctrl->upper, xh);
      *x = 0.5 * (xl + xh);
    }
  }

  /* Compute f(xl), f(xh) */
  if (err == NR_CONT && bisec_ok == True)
	  err = ((*fctn)(xl, y, False, &fxl, &dfx, hol) &&   /* PMSTA-29444 - SRIDHARA - 050318 */
	  (*fctn)(xh, y, False, &fxh, &dfx, hol) ?
        err : NR_FUNCTION_COMPUTATION_ERR);

  while (err == NR_CONT)
  {
        
    /* Update gradient every gfreq time */
    grad = ((((i - 1) % gfreq) == 0) ? True : False);

    /* Compute f(x), f'(x) */
    err = ((*fctn)(*x, y, grad, &fx, &tmp, hol) ? err : NR_FUNCTION_COMPUTATION_ERR);  /* PMSTA-29444 - SRIDHARA - 050318 */
    if (grad == True)
      dfx = tmp ;

    if (err == NR_CONT)
    {
      
      /* f'(x) = 0, i.e. local extrema */
      if (fabs(dfx) < MIN_GRAD)
      {
        err = NR_LOCAL_EXTR;
        dx = tmp = 1.0;
      }
      else
      {
        dx = fx / dfx;
        tmp = ((what_acc == True ) ? 1.0 : dfx);
      }

      /* f(x) = 0, i.e. root found */
      if (fabs(fx / tmp) < acc)
      {
        err = NR_ROOT_FOUND;

        /* Check for possible constant 0 section, i.e. if
         f(x + shock) = 0 or f(x - shock) = 0 */
        if (shock > 0.0)
        {
          err = ((*fctn)(GETMIN(*x + shock, xh), y, False, &fxh, &dfx, hol) &&   /* PMSTA-29444 - SRIDHARA - 050318 */
            (*fctn)(GETMAX(*x - shock, xl), y, False, &fxl, &dfx, hol) ? 
            err : NR_FUNCTION_COMPUTATION_ERR);
          if ((*x + shock <= xh && fabs(fxh / tmp) < acc) ||
            (*x - shock >= xl && fabs(fxl / tmp) < acc))
            err = NR_CONSTANT_ZERO;
        }
      }
      
      /* f(x) != 0, i.e. not a root */
      else
      {
        /* Newton-Raphson step */
        tmp = *x - damping * dx;

        /* Newton-Raphson step possible */
        if ((err != NR_LOCAL_EXTR) && (xl <= tmp) && (tmp <= xh))
          
           *x = tmp;

        /* A local extrema or Newton-Raphson step out of bounds 
             and bisection ok */
        else if (bisec_ok == True)
        { 
          err = NR_CONT;
          gfreq = 1;
          damping *= damp;

          /* Choose new x using bisection */
          tmp = 0.5 * (xh + xl);
          err = ((*fctn)(tmp, y, True, &fx, &dfx, hol) ?   /* PMSTA-29444 - SRIDHARA - 050318 */
            err : NR_FUNCTION_COMPUTATION_ERR); 
          *x = tmp;

          /* Change xh if root is between xl and x */
          if (fxl * fx <= 0.0)
          {
            xh = *x;
            fxh = fx;
          }
          /* Otherwise change xl; may loose root */
          else 
          {
            xl = *x;
            fxl = fx;
          }
        }
        /* A local extrema or Newton-Raphson step out of bounds */
        else
          err = ((err == NR_LOCAL_EXTR) ? err : NR_GUESS_OUTSIDE_BRACKET);
      }
    }

    ++i;
    err = ((i <= maxiter) ? err : NR_MAXITER_EXCEEDED); 
  } /* end while */
  
/* printf("xl %.2lf xh %.2lf xmin %.2lf xmax %.2lf x %.2lf err %d i %d \n", 
  xl, xh, xmin, xmax, *x, err, i); */

  return err;
} 

#undef MAXIT
#undef SHOCKSIZE
#undef ACC_ROOT
#undef MIN_GRAD




#define FACTOR 1.618034
#define MAXIT  1000

/*
************************************************************************
*                                                                       
*             Math_RootBracket()                                          
*                                                                       
*   interface #include <scutl.h>
*             BOOLE Math_RootBracket(
*                            BOOLE (*fctn)(FL64, VOIDPTR, BOOLE, FL64*, FL64*),
*                            VOIDPTR  pdata, 
*                            ITERCTRL *ctrl,
*                            FL64     *x1, 
*                            FL64     *x2)
*                                                                 
*   general   The routine brackets the root of a function.
*             The initial guessed interval [ctrl->lower,ctrl->upper] 
*             is expanded by golden expansion until a root is bracketed
*             by the output values of x1 and x2.
*                             
*             The argument list of the function pointer defined to
*             compute f'(x) as well although this information is not 
*             used here. This was done to attain consistency with
*             Newton_Raphson() and to reduce the need for special
*             ad hoc functions which are only used for this purpose.
*
*             This function is useful to bracket the root of a function
*             (which is known to have a root somewhere) before trying to
*             find it using Newton_Raphson()
*
*   input     BOOLE    *fctn(FL64, void*, BOOLE, FL64*, FL64*)
*                             The input function f 
*                             with fixed data y and variable x.         
*                             Use as (*fctn)(x, y, True/False, f(x), f'(x)) 
*                             which should return True if things work out.
*                             Toggle True/False determine whether or not 
*                             to compute f'(x).    
*                                                                       
*             void*    y      Fixed data to be passed to f.             
*                                                                       
*             ITERCTRL *ctrl  Iteration Control.
*                        
*                             maxiter controls the number of iterations,
*                             ie max. no. of recursive expansions to be 
*                             tried.
*                             Default is MAXIT. 
*             
*                             lower contains the lower bound of the
*                             initial interval guess.
*                                          
*                             upper contains the upper bound of the
*                             initial interval guess. upper and lower
*                             must be different.
*                                          
*   output    FL64     *x1    The lower bound of the interval 
*                             containing a root
*
*             FL64     *x1    The upper bound of the interval
*                             containing a root
*                                                                         
*   returns   BOOLE which is True if a root was bracketed.
*                            False if a root was not bracketed within
*                            the iteration limit.
*                                                                         
*   diagnostics                                 
*             If ctrl->lower == ctrl->upper then an error message is
*             printed using SCecon_printf().
*                                                                         
*   see also Newton_Raphson()
*                                                                         
************************************************************************
*/  

BOOLE Math_RootBracket(NEWTONRAPHSON_FCT funcd,
                       VOIDPTR pdata, ITERCTRL *ctrl,
					   FL64* x1, FL64* x2, VOIDPTR hol)
{
  INTI j, maxiter;
  FL64 f1, f2 = 0, df;
  BOOLE ok;

  /* Get initial interval guess: */
  *x1 = ctrl->lower;
  *x2 = ctrl->upper;

  maxiter = (ctrl->maxiter == -1 ? MAXIT : ctrl->maxiter);

  if (*x1 == *x2)
  {
    SCecon_printf(SCECONERROR, "Math_RootBracket():",
                               " Bad initial range");
    return False;
  }

  /* PMSTA-29444 - SRIDHARA - 050318 */
  ok = (*funcd)(*x1, pdata, False, &f1, &df, hol);
  ok = ok && (*funcd)(*x2, pdata, False, &f2, &df, hol);

  for (j = 1; ok && j < maxiter; j++)
  {
    if (f1 * f2 < 0.0)
    {
/* printf("j %d ", j); */
      return True;
    }
    if (SCecon_fabs(f1) < SCecon_fabs(f2))
      ok = (*funcd)(*x1 += FACTOR * (*x1 - *x2), pdata, False, &f1, &df, hol);  /* PMSTA-29444 - SRIDHARA - 050318 */
    else
      ok = (*funcd)(*x2 += FACTOR * (*x2 - *x1), pdata, False, &f2, &df, hol);  /* PMSTA-29444 - SRIDHARA - 050318 */
  }
/* printf("j %d ", j); */
  return False;
}

#undef FACTOR
#undef MAXIT

#define FACTOR 2
#define MAXIT  10

/*
************************************************************************
*                                                                       
*             Math_PosRootBracket()                                          
*                                                                       
*   interface #include <scutl.h>
*             BOOLE Math_PosRootBracket(
*                            BOOLE (*fctn)(FL64, VOIDPTR, BOOLE, FL64*, FL64*),
*                            VOIDPTR  pdata, 
*                            ITERCTRL *ctrl,
*                            FL64     *x1, 
*                            FL64     *x2)
*                                                                 
*   general   The routine brackets the root of a function with a positive
*             domain. The initial guessed interval [ctrl->lower,
*             ctrl->upper] is expanded by a fixed factor until a root is 
*             bracketed by the output values of x1 and x2.
*                             
*             This function is useful to bracket the root of a function
*             (which is known to have a root somewhere) before trying to
*             find it using Newton_Raphson()
*
*   input     BOOLE    *fctn(FL64, void*, BOOLE, FL64*, FL64*)
*                             The input function f 
*                             with fixed data y and variable x.         
*                             Use as (*fctn)(x, y, True/False, f(x), f'(x)) 
*                             which should return True if things work out.
*                             Toggle True/False determine whether or not 
*                             to compute f'(x).    
*                                                                       
*             void*    y      Fixed data to be passed to f.             
*                                                                       
*             ITERCTRL *ctrl  Iteration Control.
*                        
*                             maxiter controls the number of iterations,
*                             ie max. no. of recursive expansions to be 
*                             tried.
*                             Default is MAXIT. 
*             
*                             lower contains the lower bound of the
*                             initial interval guess.
*                                          
*                             upper contains the upper bound of the
*                             initial interval guess. upper and lower
*                             must be different.
*                                          
*   output    FL64     *x1    The lower bound of the interval 
*                             containing a root
*
*             FL64     *x1    The upper bound of the interval
*                             containing a root
*                                                                         
*   returns   BOOLE which is True if a root was bracketed.
*                            False if a root was not bracketed within
*                            the iteration limit.
*                                                                         
*   diagnostics                                 
*             If ctrl->lower >= ctrl->upper or ctrl->lower < 0.0
*             then an error message is
*             printed using SCecon_printf().
*                                                                         
*   see also Newton_Raphson()
*                                                                         
************************************************************************
*/  

BOOLE Math_PosRootBracket(NEWTONRAPHSON_FCT funcd,
                       VOIDPTR pdata, ITERCTRL *ctrl,
					   FL64* x1, FL64* x2, VOIDPTR hol)
{
  INTI j, maxiter;
  FL64 f1, f2 = 0, df1, df2 = 0;
  BOOLE ok;

  /* Get initial interval guess: */
  *x1 = ctrl->lower;
  *x2 = ctrl->upper;

  maxiter = (ctrl->maxiter == -1 ? MAXIT : ctrl->maxiter);

  if ((*x1 >= *x2) || (*x1 < 0.0))
  {
    SCecon_printf(SCECONERROR, "Math_PosRootBracket():",
                               " Bad initial range");
    return False;
  }

  ok = True;

  for (j = 1; ok && j < maxiter; j++)
  {
	  /* PMSTA-29444 - SRIDHARA - 050318 */
    ok = (*funcd)(*x1, pdata, True, &f1, &df1, hol);
    ok = ok && (*funcd)(*x2, pdata, True, &f2, &df2, hol);

    if (f1 * f2 < 0.0)
      return True;
    /* Now look at gradients to find the direction */
    else if (df2 > 0.0 && df1 > 0.0 && f2 < 0.0)
      *x2 *= FACTOR ;
    else if (df1 > 0.0 && df2 > 0.0 && f1 > 0.0)
      *x1 /= FACTOR ;
    else if (df1 < 0.0 && df2 < 0.0 && f1 < 0.0)
      *x1 /= FACTOR ;
    else if (df2 < 0.0 && df1 < 0.0 && f2 > 0.0)
      *x2 *= FACTOR ;
    else
    {
       *x1 /= FACTOR ;
       *x2 *= FACTOR ;
    }
  }

  return False;
}

#undef FACTOR
#undef MAXIT


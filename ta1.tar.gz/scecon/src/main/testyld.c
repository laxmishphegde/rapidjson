/* SCID @(#)testyld.c	1.3 (SimCorp) 99/02/19 14:17:20 */

/************************************************************************
*
*   project     SCecon
*
*   this program tests the routines in the yield module of SCecon.
*
************************************************************************/


/*** includes ***********************************************************/
#include <string.h>
#include <yld.h>
#include <stdlib.h>
#include <scalloc.h>
#include <str2conv.h>

INTI yldtest(char* txa, FILE* in, FILE* out)
{
    char       txb[40], txd[40], txpl[70];
    FL64ARRAY  terms, rates ;
    FL64       per, term, size, acc, fexp, fexp1, fres,fres1, pr,y1, y2, t1, t2;
    INTI       i, dif1, diff, n, qb, n1 ;
    SHOCKCONV  type ;
    INTPOLCONV ipol ;
    TSARRAY    tsstr1, tsstr ;
    IRRCONV    irr ;
    int        i1, i2, i3 ;

    acc = 0.00001 ;
    diff = -1 ;

    if (!strcmp(txa, "yld_compound2continuous()"))
    {
        fscanf(in,"%lf %lf %d %s", &fexp1, &y1, &i1, txpl);
        qb = (INTI) i1 ;
        fres1 = yld_compound2continuous(y1, qb);
        diff = (fabs(fres1 - fexp1) > acc);

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   input yield   %8.5lf\n", y1) ;
        fprintf(out,"   quoting basis %8d\n", qb) ;
        fprintf(out,"   result is %8.5lf ; expected is %8.5lf\n",
                                                          fres1, fexp1) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }

    else if (!strcmp(txa, "yld_continuous2compound()"))
    {
        fscanf(in,"%lf %lf %d %s", &fexp1, &y1, &i1, txpl);
        qb = (INTI) i1 ;
        fres1 = yld_continuous2compound(y1, qb);
        diff = (fabs(fres1 - fexp1) > acc);

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   input yield   %8.5lf\n", y1) ;
        fprintf(out,"   quoting basis %8d\n", qb) ;
        fprintf(out,"   result is %8.5lf ; expected is %8.5lf\n",
                                                          fres1, fexp1) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }

    else if (!strcmp(txa, "Yld_ForwardRate_Compound()"))
    {
        fscanf(in, "%lf %lf %lf %lf %lf %d %s", &fexp1, &y1, &t1, &y2, &t2,
                                                             &i1, txpl);
        qb = (INTI) i1 ;
        fres1 = Yld_ForwardRate_Compound(y1, t1, y2, t2, qb);
        diff = (fabs(fres1 - fexp1) > acc);

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   repo rate    %8.5lf\n", y1) ;
        fprintf(out,"   repo term    %8.5lf\n", t1) ;
        fprintf(out,"   long rate    %8.5lf\n", y2) ;
        fprintf(out,"   long term    %8.5lf\n", t2) ;
        fprintf(out,"   quoting basis %8d\n", qb) ;
        fprintf(out,"   result is %8.5lf ; expected is %8.5lf\n",
                                                          fres1, fexp1) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }

    else if (!strcmp(txa, "Yld_ForwardRate_Continuous()"))
    {
        fscanf(in, "%lf %lf %lf %lf %lf %s", &fexp1, &y1, &t1, &y2, &t2,
                                                                    txpl);
        fres1 = Yld_ForwardRate_Continuous(y1, t1, y2, t2);
        diff = (fabs(fres1 - fexp1) > acc);

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   repo rate    %8.5lf\n", y1) ;
        fprintf(out,"   repo term    %8.5lf\n", t1) ;
        fprintf(out,"   long rate    %8.5lf\n", y2) ;
        fprintf(out,"   long term    %8.5lf\n", t2) ;
        fprintf(out,"   result is %8.5lf ; expected is %8.5lf\n",
                                                          fres1, fexp1) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }

    else if (!strcmp(txa, "Yld_ForwardRate_Simple()"))
    {
        fscanf(in, "%lf %lf %lf %lf %lf %s", &fexp1, &y1, &t1, &y2, &t2,
                                                                    txpl);
        fres1 = Yld_ForwardRate_Simple(y1, t1, y2, t2);
        diff = (fabs(fres1 - fexp1) > acc);

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   repo rate    %8.5lf\n", y1) ;
        fprintf(out,"   repo term    %8.5lf\n", t1) ;
        fprintf(out,"   long rate    %8.5lf\n", y2) ;
        fprintf(out,"   long term    %8.5lf\n", t2) ;
        fprintf(out,"   result is %8.5lf ; expected is %8.5lf\n",
                                                          fres1, fexp1) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }

    else if (!strcmp(txa, "Yld_Spot2Forw_Rate()"))
    {
        fscanf(in, "%lf %lf %lf %lf %lf %d %s %s", &fexp1, &y1, &t1,
               &y2, &t2, &i1, txb, txpl);
        qb = (INTI) i1 ;
        irr = Str2IRRCONV(txb) ;
        fres1 = Yld_Spot2Forw_Rate(y1, t1, y2, t2, qb, irr);
        diff = (fabs(fres1 - fexp1) > acc);

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   repo rate    %8.5lf\n", y1) ;
        fprintf(out,"   repo term    %8.5lf\n", t1) ;
        fprintf(out,"   long rate    %8.5lf\n", y2) ;
        fprintf(out,"   long term    %8.5lf\n", t2) ;
        fprintf(out,"   quoting basis %8d\n", qb) ;
        fprintf(out,"   irr convention %s\n", txb) ;
        fprintf(out,"   result is %8.5lf ; expected is %8.5lf\n",
                                                          fres1, fexp1) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }

    else if (!strcmp("yld_simple_ann2per()", txa))
    {
        fscanf(in, "%lf %lf %lf %s", &fexp, &pr, &per, txpl);
        fres = yld_simple_ann2per(pr, per);
        diff = (fabs(fres - fexp) > acc);

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   annual yield   %8.5lf\n", pr) ;
        fprintf(out,"   period length  %8.5lf\n", per) ;
        fprintf(out,"   result is %8.5lf ; expected is %8.5lf\n",
                                                          fres, fexp) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }

    else if (!strcmp("yld_simple_per2ann()", txa))
    {
        fscanf(in, "%lf %lf %lf %s", &fexp, &pr, &per, txpl);
        fres = yld_simple_per2ann(pr, per);
        diff = (fabs(fres - fexp) > acc);

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   periodic yield %8.5lf\n", pr) ;
        fprintf(out,"   period length  %8.5lf\n", per) ;
        fprintf(out,"   result is %8.5lf ; expected is %8.5lf\n",
                                                          fres, fexp) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }

    else if (!strcmp("yld_compound_ann2per()", txa))
    {
        fscanf(in, "%lf %lf %lf %d %s", &fexp, &pr, &per, &i1, txpl);
        qb = (INTI) i1 ;
        fres = yld_compound_ann2per(pr, per, qb);
        diff = (fabs(fres - fexp) > acc);

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   annual yield  %8.5lf\n", pr) ;
        fprintf(out,"   period length %8.5lf\n", per) ;
        fprintf(out,"   quoting basis %8d\n", qb) ;
        fprintf(out,"   result is %8.5lf ; expected is %8.5lf\n",
                                                          fres, fexp) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }

    else if (!strcmp("yld_compound_per2ann()", txa))
    {
        fscanf(in, "%lf %lf %lf %d %s", &fexp, &pr, &per, &i1, txpl);
        qb = (INTI) i1 ;
        fres = yld_compound_per2ann(pr, per, qb);
        diff = (fabs(fres - fexp) > acc);

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   periodic yield %8.5lf\n", pr) ;
        fprintf(out,"   period length  %8.5lf\n", per) ;
        fprintf(out,"   quoting basis  %8d\n", qb) ;
        fprintf(out,"   result is %8.5lf ; expected is %8.5lf\n",
                                                          fres, fexp) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }

    else if (!strcmp("yld_continuous_ann2per()", txa))
    {
        fscanf(in, "%lf %lf %lf %s", &fexp, &pr, &per, txpl);
        fres = yld_continuous_ann2per(pr, per);
        diff = (fabs(fres - fexp) > acc);

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   annual yield  %8.5lf\n", pr) ;
        fprintf(out,"   period length %8.5lf\n", per) ;
        fprintf(out,"   result is %8.5lf ; expected is %8.5lf\n",
                                                          fres, fexp) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }

    else if (!strcmp("yld_continuous_per2ann()", txa))
    {
        fscanf(in, "%lf %lf %lf %s", &fexp, &pr, &per, txpl);
        fres = yld_continuous_per2ann(pr, per);
        diff = (fabs(fres - fexp) > acc);

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   periodic yield %8.5lf\n", pr) ;
        fprintf(out,"   period length  %8.5lf\n", per) ;
        fprintf(out,"   result is %8.5lf ; expected is %8.5lf\n",
                                                          fres, fexp) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }

    else if (!strcmp("Yld_Ann2Per()", txa))
    {
        fscanf(in, 
          "%lf %lf %lf %d %s %s",
          &fexp, &pr, &per, &i1, txb, txpl);
        qb = (INTI) i1 ;
        irr = Str2IRRCONV(txb) ;
        fres = Yld_Ann2Per(pr, per, qb, irr);
        diff = (fabs(fres - fexp) > acc);

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   annual yield   %8.5lf\n", pr) ;
        fprintf(out,"   period length  %8.5lf\n", per) ;
        fprintf(out,"   quoting basis  %8d\n", qb) ;
        fprintf(out,"   irr convention %s\n", txb) ;
        fprintf(out,"   result is %8.5lf ; expected is %8.5lf\n",
                                                          fres, fexp) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }

    else if (!strcmp("Yld_Per2Ann()", txa))
    {
        fscanf(in, 
          "%lf %lf %lf %d %s %s",
          &fexp, &pr, &per, &i1, txb, txpl);
        qb = (INTI) i1 ;
        irr = Str2IRRCONV(txb) ;
        fres = Yld_Per2Ann(pr, per, qb, irr);
        diff = (fabs(fres - fexp) > acc);

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   periodic yield %8.5lf\n", pr) ;
        fprintf(out,"   period length  %8.5lf\n", per) ;
        fprintf(out,"   quoting basis  %8d\n", qb) ;
        fprintf(out,"   irr convention %s\n", txb) ;
        fprintf(out,"   result is %8.5lf ; expected is %8.5lf\n",
                                                          fres, fexp) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }

    else if (!strcmp("Yld_Shock_Rates()", txa))
    {
        fscanf(in, "%d %s %lf %s", &i1, txb, &size, txpl);
        n = (INTI) i1 ;
        type = Str2SHOCKCONV(txb) ;
        tsstr = Alloc_TSARRAY(2, n) ;
        for (i = 0 ; i < n ; i++)
            fscanf(in,"%lf %lf %lf %lf", &tsstr[0].term[i],
                                         &tsstr[0].rate[i],
                                         &tsstr[1].rate[i],
                                         &tsstr[0].loading[i]) ;
        tsstr[0].count = n ;

        fprintf(out,"?; testing %s\n", txa) ;
        fprintf(out,"   number of elements in ts %8d\n", n) ;
        fprintf(out,"   shock type               %s\n", txb) ;
        fprintf(out,"   shock size               %8.5lf\n", size) ;
        fprintf(out,"   input term structure is...\n") ;
        for (i = 0 ; i < n ; i++)
        {
            fprintf(out,
              "   term[%d] %8.5lf; rate[%d] %8.5lf; loading[%d] %8.5lf\n",
              
                                   i, tsstr[0].term[i],
                                   i, tsstr[0].rate[i],
                                   i, tsstr[0].loading[i]) ;
        }

        Yld_Shock_Rates(tsstr, type, size) ;

        fprintf(out,"   results are...\n") ;
        for (diff = i = 0 ; i < n ; i++)
        {
            dif1 = (fabs(tsstr[0].rate[i] - tsstr[1].rate[i]) > acc) ;
            diff = (diff || dif1) ;
            fprintf(out,
"%d; term[%2d] %8.5lf expected %8.5lf shocked %8.5lf loading %8.5lf\n",
              
                    dif1, i, tsstr[0].term[i], tsstr[1].rate[i],
                    tsstr[0].rate[i], tsstr[0].loading[i]) ;
        }
        fprintf(out,"   %s\n\n", txpl) ;

        Free_TSARRAY(tsstr, 2) ;
    }

    else if (!strcmp("Yld_GetRates()", txa))
    {
        fscanf(in, "%lf %s %lf %d %s", &fexp, txb, &term, &i1, txpl);
        n = (INTI) i1 ;
        ipol  = Str2INTPOLCONV(txb) ;
        tsstr = Alloc_TSARRAY(1, n) ;
        terms = Alloc_FL64ARRAY(1) ;
        terms[0] = term ;
        for (i = 0 ; i < n ; i++)
            fscanf(in,"%lf %lf", &tsstr[0].term[i], &tsstr[0].rate[i]) ;
        tsstr[0].count = n ;

        tsstr1 = Yld_GetRates(&tsstr[0], terms, 1, ipol) ;
        fres   = tsstr1->rate[0] ;

        diff = (fabs(fres - fexp) > acc);

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   ipol convention          %s\n", txb) ;
        fprintf(out,"   input term               %8.5lf\n", term) ;
        fprintf(out,"   number of elements in ts %8d\n", n) ;
        fprintf(out,"   result is %8.5lf ; expected is %8.5lf\n",
                                                          fres, fexp) ;
        fprintf(out,"   input ts is...\n") ;

        for (i = 0 ; i < n ; i++)
            fprintf(out,"   term[%2d] %8.5lf  rate[%2d] %8.5lf\n",
                    i, tsstr[0].term[i], i, tsstr[0].rate[i]) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_TSARRAY(tsstr, 1) ;
        Free_TSARRAY(tsstr1, 1) ;
        Free_FL64ARRAY(terms) ;
    }
    else if (!strcmp("Yld_Get_TsRate()", txa))
    {
        fscanf(in, "%lf %s %lf %d %s", &fexp, txb, &term, &i1, txpl);
        n = (INTI) i1 ;
        ipol  = Str2INTPOLCONV(txb) ;
        tsstr = Alloc_TSARRAY(1, n) ;
        for (i = 0 ; i < n ; i++)
            fscanf(in,"%lf %lf", &tsstr[0].term[i], &tsstr[0].rate[i]) ;
        tsstr[0].count = n ;

        fres = Yld_Get_TsRate(tsstr, term, ipol) ;
        diff = (fabs(fres - fexp) > acc);

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   ipol convention          %s\n", txb) ;
        fprintf(out,"   input term               %8.5lf\n", term) ;
        fprintf(out,"   number of elements in ts %8d\n", n) ;
        fprintf(out,"   result is %8.5lf ; expected is %8.5lf\n",
                                                          fres, fexp) ;
        fprintf(out,"   input ts is...\n") ;

        for (i = 0 ; i < n ; i++)
            fprintf(out,"   term[%2d] %8.5lf  rate[%2d] %8.5lf\n",
                    i, tsstr[0].term[i], i, tsstr[0].rate[i]) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_TSARRAY(tsstr, 1) ;
    }

    else if (!strcmp("Yld_Spot2Forw_Ts()", txa))
    {
        fscanf(in, "%d %lf %d %s %s %d %s",
               &i1, &term, &i2, txb, txd, &i3, txpl);
        n = (INTI) i1 ;
        n1 = (INTI) i2 ;
        qb = (INTI) i3 ;

        ipol  = Str2INTPOLCONV(txb) ;
        tsstr = Alloc_TSARRAY(1, GETMAX(n, n1)) ;
        terms = Alloc_FL64ARRAY(n1) ;
        rates = Alloc_FL64ARRAY(n1) ;
        for (i = 0 ; i < n ; i++)
            fscanf(in,"%lf %lf", &tsstr[0].term[i], &tsstr[0].rate[i]) ;

        tsstr[0].count = n ;
        tsstr[0].conv  = Str2IRRCONV(txd) ;
        tsstr[0].qbas  = qb ;

        for (i = 0 ; i < n1 ; i++)
            fscanf(in,"%lf %lf", &terms[i], &rates[i]) ;

        tsstr1 = Yld_Spot2Forw_Ts(&tsstr[0], terms, n1, term, ipol) ;

        for (diff = 0, i = 0 ; i < n1 ; i++)
            diff = diff || (fabs(tsstr1->rate[i] - rates[i]) > acc) ;

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   ipol convention          %s\n", txb) ;
        fprintf(out,"   duration                 %8.5lf\n", term) ;
        fprintf(out,"   number of elements in spot ts %8d\n", n) ;
        fprintf(out,"   number of elements in forward ts %8d\n", n1) ;

        fprintf(out,"   spot ts is...\n") ;
        for (i = 0 ; i < n ; i++)
            fprintf(out,"   term[%2d] %8.5lf  rate[%2d] %8.5lf\n",
                    i, tsstr[0].term[i], i, tsstr[0].rate[i]) ;

        fprintf(out,"   forward ts is...\n") ;
        for (i = 0 ; i < n1 ; i++)
            fprintf(out,
"   %d; term[%2d] %8.5lf  rate[%2d] %8.5lf  exp[%2d] %8.5lf\n",
              
                    fabs(tsstr1->rate[i] - rates[i]) > acc,
                    i, tsstr1->term[i], i, tsstr1->rate[i], i, rates[i]) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_TSARRAY(tsstr, 1) ;
        Free_TSARRAY(tsstr1, 1) ;
        Free_FL64ARRAY(terms) ;
        Free_FL64ARRAY(rates) ;
    }

    return diff ;
}

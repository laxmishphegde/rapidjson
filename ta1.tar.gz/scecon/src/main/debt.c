/* SCID @(#)debt.c	1.13 (SimCorp) 99/02/19 14:15:19 */

/************************************************************************
*
*   project     SCecon
*
*   filename    debt.c
*
*   general     This file contains standard cash flow routines of
*               SCecon Library
*
************************************************************************/

/* includes ************************************************************/
#include <pmt.h>

/* defines  ************************************************************/

#define COUP_TOL 0.00001


/*,,SOH,,
*************************************************************************
*
*               Cflw_OutstandingDebt()
*
*   interface   #include <pmt.h>
*               FL64ARRAY Cflw_OutstandingDebt(FL64ARRAY repayment1,
*                                               INTI      n) ;
*
*   general     Calculates the outstanding debt at any time from a
*               cashflow.
*
*   input       FL64ARRAY  repayment1   Array of repayment schedule.
*                                       Must sum to 100.
*
*               INTI       n            Entries in repayment.
*
*   output
*
*   returns     Pointer to the list of outstanding debt. Allocated in
*               this routine as Alloc_FL64ARRAY(n)
*               Each element is a number between 0 and 1.
*               The element debt[i] should be interpreted as the
*               outstanding debt from time[i-1] until and
*               excluding time[i].
*
*   diagnostics
*
*   see also    Cflw_FractionDebt(),
*               Cflw_RepaidDebt()
*               Cflw_DebtPerDate()
*
*************************************************************************
,,EOH,,*/


FL64ARRAY Cflw_OutstandingDebt(FL64ARRAY repayment1,
                                INTI       n)
{
    FL64ARRAY debt1 ;
    FL64      paidback ;
    INTI      i ;

    debt1     = Alloc_FL64ARRAY(n) ;

    paidback = 0.0 ;
    if (0 < n)
        debt1[0] = 1.0 ;

    for (i = 0 ; i < n - 1 ; i++)
    {
        paidback    += repayment1[i] ;
        debt1[i + 1] = (100.0 - paidback)/100.0 ;
    }

    return debt1 ;
}


/*,,SOH,,
*************************************************************************
*
*               Cflw_RepaidDebt()
*
*   interface   #include <pmt.h>
*               FL64ARRAY Cflw_RepaidDebt(FL64ARRAY repayment1,
*                                          INTI      n) ;
*
*   general     Calculates how much of a loan, that has been repaid
*               at any time during the life of a bond.
*
*   input       FL64ARRAY  repayment1   Array of repayment schedule.
*                                       Must sum to 100.
*
*               INTI       n            Entries in repayment
*
*   output
*
*   returns     Pointer to the list of repay status. Allocated in
*               this routine as Alloc_FL64ARRAY(n).
*               Each element is a number between 0 and 1.
*
*   diagnostics
*
*   see also    Cflw_FractionDebt()
*               Cflw_OutstandingDebt()
*
*************************************************************************
,,EOH,,*/


FL64ARRAY Cflw_RepaidDebt(FL64ARRAY repayment1,
                           INTI       n)
{
    FL64ARRAY repaid1 ;
    FL64      paidback ;
    INTI      i;

    repaid1 = Alloc_FL64ARRAY(n) ;

    paidback = 0.0 ;

    for (i = 0 ; i < n ; i++)
    {
        paidback  += repayment1[i];
        repaid1[i] = paidback/100.0 ;
    }

    return repaid1 ;
}


/*,,SOH,,
*************************************************************************
*
*               Cflw_FractionDebt()
*
*   interface   #include <pmt.h>
*               FL64ARRAY Cflw_FractionDebt(FL64ARRAY repayment1,
*                                            INTI      n) ;
*
*   general     Cflw_FractionDebt() calculates the ratio between
*               the repayments and the outstanding debt at any time
*               during the life of a bond, delivered in weights .
*
*   input       FL64ARRAY  repayment1   Array of repayment schedule.
*                                       Must sum to 100.
*
*               INTI       n            Number of entries in repayment
*
*   output
*
*   returns     Pointer to the list of ratios. Allocated in
*               this routine as Alloc_FL64ARRAY(n)
*               Each element is a number between 0 and 1.
*
*
*   diagnostics
*
*   see also    Cflw_OutstandingDebt()
*               Cflw_RepaidDebt()
*
*************************************************************************
,,EOH,,*/


FL64ARRAY Cflw_FractionDebt(FL64ARRAY repayment1,
                             INTI      n)
{
    FL64ARRAY weight1 ;
    FL64      paidback ;
    INTI      i ;

    weight1 = Alloc_FL64ARRAY(n) ;

    paidback = 0.0 ;

    for (i = 0 ; i < n ; i++)
    {
        weight1[i] = (fabs(100.0 - paidback) > PMT_TOL ?
                     (repayment1[i]/(100.0 - paidback)) : 0.0) ;
        paidback  += repayment1[i];
    }

    return weight1 ;
}


/*,,SOH,,
*************************************************************************
*
*               Cflw_OutstandingAnnuity()
*
*   interface   #include <pmt.h>
*               FL64 Cflw_OutstandingAnnuity(FL64 cp,
*                                             INTI ncflw,
*                                             INTI rest) ;
*
*   general     Cflw_OutstandingAnnuity() calculates the outstanding
*               debt when rem repayments out of originally ncflw
*               remain to be paid of an initial debt of 100.
*
*   input       FL64      cp    The periodic coupon in percent.
*
*               INTI      ncflw The original number of repayments.
*
*               INTI      rest  The remaining number of repayments
*
*   output
*
*   returns
*
*   diagnostics
*
*   see also    Cflw_OutstandingDebt()
*               Cflw_OutstandingSerial()
*               Cflw_RepaidDebt()
*
*************************************************************************
,,EOH,,*/


FL64    Cflw_OutstandingAnnuity(FL64 cp, INTI  ncflw, INTI  rest)
{
    FL64    rg, ann, a0 ;

    if (ncflw == 0 || rest == 0)
        return 0.0 ;

    if (fabs(cp) < COUP_TOL)
        return Cflw_OutstandingSerial(ncflw, rest) ;

    ann = Cflw_Annuity(cp, ncflw, False) ;

    /* a0 is the first repayment - per initial 100 */
    a0  = ann - cp ;
    rg  = 100.0 ;
    cp /= 100.0 ;

    rg -= a0*(pow(1.0 + cp, (FL64   ) (ncflw - rest)) - 1.0)/cp ;

    return rg ;
}


/*,,SOH,,
*************************************************************************
*
*               Cflw_OutstandingSerial()
*
*   interface   #include <pmt.h>
*               FL64 Cflw_OutstandingSerial(INTI ncflw,
*                                            INTI rest) ;
*
*   general     Cflw_OutstandingSerial()  calculates the outstanding
*               debt when rem repayments out of originally ncflw
*               remain to be paid of an initial debt of 100.
*
*   input       INTI      ncflw The original number of repayments.
*
*               INTI      rest  The remaining number of repayments.
*
*   output
*
*   returns
*
*   diagnostics
*
*   see also    Cflw_OutstandingDebt()
*               Cflw_RepaidDebt()
*               Cflw_OutstandingAnnuity()
*
*************************************************************************
,,EOH,,*/


FL64    Cflw_OutstandingSerial(INTI ncflw, INTI  rest)
{
    if (ncflw == 0)
        return 0.0 ;
    else
        return 100.0 * ((FL64) rest)/((FL64) ncflw) ;
}

#undef COUP_TOL

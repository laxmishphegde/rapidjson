/* @(#)ann2per.c	1.10 (SimCorp) 99/02/19 14:14:56 */

/************************************************************************
*
*   project     SCecon
*
*   filename    ann2per.c
*
*   contains    routines in the SCecon Library Yield for calculating
*               anual/periodic rates.
*
************************************************************************/

/***** includes ********************************************************/

#include <yld.h>

/*
*************************************************************************
*
*               Yld_Ann2Per()
*
*    interface  #include <yld.h>
*               FL64 Yld_Ann2Per(FL64    annualrate,
*                                FL64    basis,
*                                INTI    qbas,
*                                IRRCONV irr) ;
*
*    general    Yld_Ann2Per() calculates the periodic rate from the
*               annual rate for the specified yield convention.
*
*               The period rate is here interpreted as follows : Find
*               the rate r  that satisfies the following relation
*                         P
*
*                        fv(irr, r , qbas, period) = 1 + r
*                                 A                       P
*
*               Where fv means forward value, and r  is the annual rate.
*                                                  A
*
*               This functionality can be used to :
*
*                   - Find the semiannual coupon given the annual
*                     coupon.
*                   - Convert compounded yield quoted for instance
*                     semiannually to annually quoted.
*                   - Find discounting factors = (1 + r )
*                                                      P
*
*               If you want to convert semiannually quoted compunded
*               yield to quarterly quoted yield compounded, then
*               first use this function to get the annually quoted
*               yield. Next use Yld_Per2Ann() to convert the annually
*               quoted yield to the quarterly quoted yield.
*
*    input      FL64    annualrate Annual yield in percent.
*
*               FL64    basis      Period length in fractional years.
*
*               INTI    qbas       Quoting basis of the yield - needed
*                                  if irr is COMPOUND.
*
*               IRRCONV irr        The yield convention. Can be one of
*
*                                         COMPOUND
*                                         CONTINUOUS
*                                         SIMPLE_MM
*                                         DISCOUNT
*
*    output
*
*    returns    the periodic rate in percent.
*
*    diagnostics
*
*    see also   Yld_Per2Ann()
*
*************************************************************************
*/


FL64    Yld_Ann2Per(FL64 annualrate,
                            FL64    basis,
                            INTI    qbas,
                            IRRCONV irr)
{
    FL64    tmp ;

    switch (irr)
    {
        case COMPOUND:

            tmp = yld_compound_ann2per(annualrate, basis, qbas) ;
            break ;

        case CONTINUOUS:

            tmp = yld_continuous_ann2per(annualrate, basis) ;
            break ;

        case SIMPLE_MM:

            tmp = yld_simple_ann2per(annualrate, basis) ;
            break ;

        case DISCOUNT:

            tmp = yld_discount_ann2per(annualrate, basis) ;
            break ;
        default:
            /* warning avoidance */
            tmp = 0.0 ;
            break;
    }
    return tmp ;
}


/*
*************************************************************************
*
*               Yld_Per2Ann()
*
*    interface  #include <yld.h>
*               FL64 Yld_Per2Ann(FL64    periodrate,
*                                FL64    basis,
*                                INTI    qbas,
*                                IRRCONV irr) ;
*
*    general    Yld_Per2Ann() calculates the annual rate from the
*               period rate for the specified yield convention.
*
*               The annual rate is here interpreted as follows : Find
*               the rate r  that satisfies the following relation
*                         A
*
*                 fv(irr, r , qbas, period) = 1 + r
*                          A                       P
*
*               Where fv means forward value, and r  is the annual rate.
*                                                  A
*
*    input      FL64    periodrate Annual yield in percent.
*
*               FL64    basis      Number of annual periods.
*
*               INTI    qbas       Quoting basis of the yield - needed
*                                  if irr is COMPOUND.
*
*               IRRCONV irr        The yield convention. Can be one of
*
*                                         COMPOUND
*                                         CONTINUOUS
*                                         SIMPLE_MM
*                                         DISCOUNT
*
*    output
*
*    returns    the annual rate in percent.
*
*    diagnostics
*
*    see also   Yld_Ann2Per()
*
*************************************************************************
*/


FL64    Yld_Per2Ann(FL64 periodrate,
                            FL64    basis,
                            INTI    qbas,
                            IRRCONV irr)
{
    FL64    tmp ;

    switch (irr)
    {
        case COMPOUND:

            tmp = yld_compound_per2ann(periodrate, basis, qbas) ;
            break ;

        case CONTINUOUS:

            tmp = yld_continuous_per2ann(periodrate, basis) ;
            break ;

        case SIMPLE_MM:

            tmp = yld_simple_per2ann(periodrate, basis) ;
            break ;

        case DISCOUNT:

            tmp = yld_simple_per2ann(periodrate, basis) ;
            break ;
        default:
            /* warning avoidance */
            tmp = 0.0 ;
            break;
    }
    return tmp ;
}

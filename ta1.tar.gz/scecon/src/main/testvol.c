/* SCID @(#)testvol.c	1.7 (SimCorp) 99/02/19 14:17:18 */

/************************************************************************
*
*   project     SCecon
*
*   this program tests the routines in the utilities module of SCecon
*
************************************************************************/

/*** includes ***********************************************************/
#include <string.h>
#include <vol.h>
#include <stdlib.h>
#include <scutl.h>
#include <str2conv.h>
#include <ioconv.h>


INTI voltest(char* txa, FILE* in, FILE* out)
{
    char       txb[25], txc[25], txpl[64] ;
    FL64       *terms, std, acc, fres, fexp, t, term, strike ;
    INTI       i, n, diff ;
    TSOVARRAY  tsstr1, tsstr ;
    INTPOLCONV ipol ;
    DATESTR    today, date, date1, date2 ;
    INTL       ymd, ymd1 ;
    PLANARRAY   dstr ;
    CALCONV    cal ;
    int        i1 ;
    VOL_STR    ts ;
    VOLBOX    *vm ;
    PERIOD        p ;
    HOLI_STR   holi ;

    acc = 0.00001 ;
    diff = -1 ;

    if (!strcmp("Vol_Ann2Per()", txa))
    {
        fscanf(in, "%lf %lf %lf %s", &fexp, &std, &t, txpl);
        fres = Vol_Ann2Per(std, t) ;
        diff = (fabs(fres - fexp) > acc);

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   annual volatility %10.5lf\n", std) ;
        fprintf(out,"   period length     %10.5lf\n", t) ;
        fprintf(out,
          "   result is %10.5lf ; expected is %10.5lf\n",
          fres, fexp) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }

    else if (!strcmp("Vol_Per2Ann()", txa))
    {
        fscanf(in, "%lf %lf %lf %s", &fexp, &std, &t, txpl);
        fres = Vol_Per2Ann(std, t) ;
        diff = (fabs(fres - fexp) > acc);

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   periodic volatility %10.5lf\n", std) ;
        fprintf(out,"   period length       %10.5lf\n", t) ;
        fprintf(out,
          "   result is %10.5lf ; expected is %10.5lf\n",
          fres, fexp) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }

    else if (!strcmp("Vol_Get_Vol()", txa))
    {
        fscanf(in, "%lf %s %lf %d %s", &fexp, txb, &term, &i1, txpl);
        n = (INTI) i1 ;
        ipol  = Str2INTPOLCONV(txb) ;
        tsstr = Alloc_TSOVARRAY(1, n) ;
        terms = Alloc_FL64ARRAY(1) ;
        terms[0] = term ;
        for (i = 0 ; i < n ; i++)
            fscanf(in,"%lf %lf", &tsstr[0].term[i], &tsstr[0].vol[i]) ;

        tsstr[0].count = n ;

        tsstr1 = Vol_Get_Vol(&tsstr[0], terms, 1, ipol) ;
        fres = tsstr1->vol[0] ;
        diff = (fabs(fres - fexp) > acc);

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   ipol convention          %s\n", txb) ;
        fprintf(out,"   input term               %8.5lf\n", term) ;
        fprintf(out,"   number of elements in ts %8d\n", n) ;
        fprintf(out,"   result is %8.5lf ; expected is %8.5lf\n",
                                                          fres, fexp) ;
        fprintf(out,"   input tsov is...\n") ;

        for (i = 0 ; i < n ; i++)
            fprintf(out,"   term[%2d] %8.5lf  rate[%2d] %8.5lf\n",
                    i, tsstr[0].term[i], i, tsstr[0].vol[i]) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_TSOVARRAY(tsstr, 1) ;
        Free_TSOVARRAY(tsstr1, 1) ;
        Free_FL64ARRAY(terms) ;
    }
    else if (!strcmp("Vol_Interpolation()", txa))
    {
        fscanf(in, "%lf %ld %d %s %s", &fexp, &ymd, &i1, txc, txpl);
        n = (INTI) i1 ;
        cal  = Str2CALCONV(txc) ;
        date = Cldr_YMD2Datestr(ymd) ;
        dstr = Alloc_PLANARRAY(1, n) ;

        fprintf(out,"   testing %s\n", txa) ;
        fprintf(out,"   date           %8ld\n", ymd) ;
        fprintf(out,"   calendar       %8s\n", txc) ;
        fprintf(out,"   vol. fct. table is...\n") ;

        for (i = 0 ; i < n ; i++)
        {
            fscanf(in,"%ld %lf", &ymd, &dstr[0].f64[i]) ;
            dstr[0].day[i] = Cldr_YMD2Datestr(ymd) ;
            fprintf(out,"   date[%2d] %8ld  disc[%2d] %10.5lf\n",
                    i, ymd, i, dstr[0].f64[i]) ;
        }
        dstr[0].filled = dstr[0].count = n ;

        ts = Set_VOL_STR(dstr, cal, FORWFORW, LINEAR_FLAT_END);

        fres = Vol_Interpolation(&date, &ts, &holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */

        diff = (fabs(fres - fexp) > acc);
        fprintf(out,"%d; result is %8lf ; expected is %8lf\n",
                diff, fres, fexp) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_PLANARRAY(dstr, 1) ;
    }


    else if(!strcmp("Vol_Spot2Forw()", txa))
    {
        fprintf(out,"   testing %s\n", txa) ;
        
        /* Read data */
        fexp = Read_FL64(in, out, "   Exp.   ") ;
        today = Read_DATESTR(in, out, "   Today   ") ;
        date1 = Read_DATESTR(in, out, "   First forward date   ") ;
        date2 = Read_DATESTR(in, out, "   Last forward date   ") ;
        ts = Read_VOL_STR(in, out) ;

        /* Calculate */
        fres = Vol_Spot2Forw(&today, &ts, &date1, &date2, &holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
        
        /* Comments */
        IOUtil_ParseLine(in, out);

        /* Compare */
        diff = Write_SingleDiff(True, True, fres, fexp, acc, out) ;

        /* Free.. */
        Free_VOL_STR(&ts) ;
    }
    else if (!strcmp("Vol_Linear_Lookup()", txa))
    {
        fscanf(in, "%s", txpl) ;

        fscanf(in, "%lf %ld %ld %lf", &fexp, &ymd, &ymd1, &strike) ;

        today = Cldr_YMD2Datestr(ymd) ;
        date1 = Cldr_YMD2Datestr(ymd1) ;
        p = Read_PERIOD(in) ;

        fprintf(out, "Testing %s\n", txa) ;
        fprintf(out, "%s\n", txpl) ;
        fprintf(out, "Today: %ld\n", ymd) ;
        fprintf(out, "Option Maturity: %ld\n", ymd1) ;
        fprintf(out, "Strike: %lf\n", strike) ;
        Write_PERIOD(out, "Swap maturity:", &p) ;

        vm = Read_VOLBOX(in, out) ;

        holi = Set_HOLI_STR(NO_BUSADJUST, 0, &today) ;
        fres = Vol_Linear_Lookup(vm, &today, &date1, strike, &p, &holi) ;

        diff = (fabs(fres - fexp) > acc);
        fprintf(out,"%d; result is %8lf ; expected is %8lf\n\n",
                diff, fres, fexp) ;

        Free_VOLBOX(vm) ;
    }

    return diff ;
}

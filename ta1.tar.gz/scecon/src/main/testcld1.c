/* SCID @(#)testcld1.c	1.11 (SimCorp) 99/07/26 10:42:13 */

/************************************************************************
*
*   project     SCecon
*
*   this program tests the routines in the calendar module of SCecon
*
************************************************************************/

/*** includes ***********************************************************/
#include <string.h>
#include <cldr.h>
#include <scalloc.h>
#include <str2conv.h>
#include <ioconv.h>

/*** the routine ********************************************************/

INTI  cldrtst1(char* txa, FILE* in, FILE* out)
{
    char       txb[25], txc[25], txd[25], txe[25], txpl[80] ;
    INTL       ds1, dprev, dsettle, lexp, lres ;
    BUSCONV    bcon ;
    EOMCONV    eom ;
    BOOLE      override ;
    CALCONV    cal2, cal1, cal ;
    TERMUNIT   unit;
    SEARCHCONV sconv ;
    INDEXCONV  iconv ;
    ALIGNCONV  align ;
    SORTCONV   sort ;
    INTI       qbas, i, count, w, diff, dexp, dres;
    INTI       nstep, dif1, count1, n1, n2, n, n3, ix, ixexp ;
    FL64       fexp, fres, acc, t1, fln, def ;
    DATESTR    *bdays, *days, daysettle, date, dateres, dateinput1, dateinput2;
    DATESTR    lastm;
    YYYYMMDD   yyyymmdd1, yyyymmdd2, ymd, ymd1 ;
    FL64ARRAY  expterms, terms ;
    DATEARRAY  holiday, dates, expdates, daytheo, dates1, dates2, dates3,
               resdates;
    YMDARRAY   ymds ;
    PLANARRAY  plan, planres, planexp ;
    STEPARRAY  step ;
    int        i1, i2, i3 ;
    HOLI_STR   holi ;
    PERIOD     per ;
    SEQCONV    roll ;

    acc = 0.00001 ;
    diff = -1 ;

    if (!strcmp(txa, "Cldr_NextBusinessDate()"))
    {
         fscanf(in, "%ld %ld %s %d %s", &lexp, &yyyymmdd1, txb, &i1, txpl) ;
         count = (INTI) i1 ;
         holiday = Alloc_DATEARRAY(count);
         for (i = 0 ; i < count ; i++)
         {
            fscanf(in,"%ld", &yyyymmdd2);
            holiday[i] = Cldr_YMD2Datestr(yyyymmdd2);
         }
         bcon = Str2BUSCONV(txb) ;
         dateinput1 = Cldr_YMD2Datestr(yyyymmdd1);

         holi.bus = bcon ;
         holi.nholi = count ;
         holi.holidays = holiday ;

         dateres = Cldr_NextBusinessDate(&dateinput1, &holi);
         lres = Cldr_Datestr2YMD(&dateres);
         diff = (lres != lexp);

         fprintf(out,"%d; testing %s\n", diff, txa) ;
         fprintf(out,"   date   %8ld\n", yyyymmdd1) ;
         fprintf(out,"   bcon   %8s\n", txb) ;
         fprintf(out,"   result is %8ld ; expected is %8ld\n", lres, lexp) ;
         fprintf(out,"   input holidays are\n") ;

         for(i = 0 ; i < count ; i++)
         {
             yyyymmdd2 = Cldr_Datestr2YMD(&holiday[i]);
             fprintf(out, "   holiday[%3d] is %8ld\n", i, yyyymmdd2);
         }
         Free_DATEARRAY(holiday);
         fprintf(out,"   %s\n\n", txpl) ;
    }

    if (!strcmp(txa, "Cldr_NextBusinessDateArray()"))
    {
      fprintf(out,"   testing %s\n", txa) ;

      fprintf(out,"   holi: \n") ;
      holi     = Read_HOLI_STR(in, out);

      fprintf(out,"   input dates: \n") ;
      dates    = Read_DATEARRAY(in, out, &dres);

      fprintf(out,"   expected result: \n") ;
      expdates = Read_DATEARRAY(in, out, &dexp);

      resdates = Cldr_NextBusinessDateArray(dates, dres, &holi);

      if (dres != dexp)
      {
       fprintf(out,
         "1; Exp. no. of dates (%d) differs from actal no. of dates (%d).\n",
         dexp, dres);
       diff = 1;
      }
      else
      {
        diff = 0;
        for (i = 0; i < dres; i++)
        {
          lres = Cldr_Datestr2YMD(&resdates[i]);
          lexp = Cldr_Datestr2YMD(&expdates[i]);
          dif1 = (lres != lexp);
          diff = diff || dif1;
          fprintf(out,"%d; result is %8ld ; expected is %8ld\n", dif1, lres,
            lexp);
        }
      }

      Free_HOLI_STR(&holi);
      Free_DATEARRAY(dates);
      Free_DATEARRAY(expdates);
      Free_DATEARRAY(resdates);

      fscanf(in, "%s", txpl) ;
      fprintf(out,"   %s\n\n", txpl) ;
    }

    else if (!strcmp(txa, "Cldr_LastBusinessDay()"))
    {
         fscanf(in, "%ld %ld %d %s", &lexp, &yyyymmdd1, &i1, txpl) ;
         count = (INTI) i1 ;
         holiday = Alloc_DATEARRAY(count);
         for (i = 0 ; i < count ; i++)
         {
            fscanf(in,"%ld", &yyyymmdd2);
            holiday[i] = Cldr_YMD2Datestr(yyyymmdd2);
         }

         dateinput1 = Cldr_YMD2Datestr(yyyymmdd1);

         holi.nholi    = count ;
         holi.holidays = holiday ;

         dateres = Cldr_LastBusinessDay(&dateinput1, &holi) ;
         lres = Cldr_Datestr2YMD(&dateres);
         diff = (lres != lexp);

         fprintf(out,"%d; testing %s\n", diff, txa) ;
         fprintf(out,"   date   %8ld\n", yyyymmdd1) ;
         fprintf(out,"   result is %8ld ; expected is %8ld\n", lres, lexp) ;
         fprintf(out,"   input holidays are\n") ;

         for(i = 0 ; i < count ; i++)
         {
             yyyymmdd2 = Cldr_Datestr2YMD(&holiday[i]);
             fprintf(out, "   holiday[%3d] is %8ld\n", i, yyyymmdd2);
         }

         Free_DATEARRAY(holiday);
         fprintf(out,"   %s\n\n", txpl) ;
    }

    else if (!strcmp(txa, "Cldr_BusDaysBetweenDates()"))
    {
         fscanf(in, 
           "%ld %ld %ld %d %s",
           &lexp, &yyyymmdd1, &yyyymmdd2, &i1, txpl) ;

         dateinput1 = Cldr_YMD2Datestr(yyyymmdd1) ;
         dateinput2 = Cldr_YMD2Datestr(yyyymmdd2) ;

         fprintf(out,"   testing %s\n", txa) ;
         fprintf(out,"   date1  %8ld\n", yyyymmdd1) ;
         fprintf(out,"   date2  %8ld\n", yyyymmdd2) ;
         fprintf(out,"   input holidays are\n") ;

         count = (INTI) i1 ;
         holiday = Alloc_DATEARRAY(count);
         for (i = 0 ; i < count ; i++)
         {
            fscanf(in,"%ld", &yyyymmdd2);
            fprintf(out, "   holiday[%3d] is %8ld\n", i, yyyymmdd2);
            holiday[i] = Cldr_YMD2Datestr(yyyymmdd2);
         }

         holi.nholi    = count ;
         holi.holidays = holiday ;

         lres = Cldr_BusDaysBetweenDates(&dateinput1, &dateinput2, &holi) ;
         diff = (lres != lexp) ;

         fprintf(out,"%d; result is %8ld ; expected is %8ld\n",
                 diff, lres, lexp) ;

         Free_DATEARRAY(holiday) ;
         fprintf(out,"   %s\n\n", txpl) ;
    }

    else if (!strcmp(txa, "Cldr_Move2BusinessDays()"))
    {
         fscanf(in, "%s %d %d %s", txb, &i1, &i2, txpl) ;

         count = (INTI) i1 ;
         n = (INTI) i2 ;
         holiday = Alloc_DATEARRAY(count);
         days    = Alloc_DATEARRAY(n);
         bdays   = Alloc_DATEARRAY(n);

         for (i = 0 ; i < count ; i++)
         {
            fscanf(in,"%ld", &yyyymmdd2);
            holiday[i] = Cldr_YMD2Datestr(yyyymmdd2);
         }
         for (i = 0 ; i < n ; i++)
         {
            fscanf(in,"%ld %ld", &yyyymmdd1, &yyyymmdd2);
            days[i]  = Cldr_YMD2Datestr(yyyymmdd1);
            bdays[i] = Cldr_YMD2Datestr(yyyymmdd2);
         }
         bcon = Str2BUSCONV(txb) ;

         holi.bus = bcon ;
         holi.nholi = count ;
         holi.holidays = holiday ;

         Cldr_Move2BusinessDays(days, n, &holi);

         for (diff = 0, i = 0 ; i < n ; i++)
             diff = diff || (Cldr_DateEQ(&days[i], &bdays[i]) == False) ;

         fprintf(out,"%d; testing %s\n", diff, txa) ;
         fprintf(out,"   bcon   %8s\n", txb) ;
         fprintf(out,"   input holidays are\n") ;

         for(i = 0 ; i < count ; i++)
         {
             yyyymmdd2 = Cldr_Datestr2YMD(&holiday[i]);
             fprintf(out, "   holiday[%3d] is %8ld\n", i, yyyymmdd2);
         }
         fprintf(out,"   business days are    expected are\n") ;
         for (i = 0 ; i < n ; i++)
             fprintf(out, "   %ld              %ld\n",
                     Cldr_Datestr2YMD(&days[i]), Cldr_Datestr2YMD(&bdays[i])) ;

         Free_DATEARRAY(holiday);
         Free_DATEARRAY(days);
         Free_DATEARRAY(bdays);
         fprintf(out,"   %s\n\n", txpl) ;
    }

    else if (!strcmp(txa, "Cldr_IsBusinessDate()"))
    {
         fscanf(in, "%d %ld %d %s", &i2, &yyyymmdd1, &i1, txpl);
         count = (INTI) i1 ;
         dexp  = (INTI) i2 ;
         holiday = Alloc_DATEARRAY(count);
         for (i = 0 ; i < count ; i++)
         {
             fscanf(in,"%ld", &yyyymmdd2);
             holiday[i] = Cldr_YMD2Datestr(yyyymmdd2);
         }

         dateinput1 = Cldr_YMD2Datestr(yyyymmdd1);
         dres = Cldr_IsBusinessDate(&dateinput1, count, holiday);
         diff = (dres != dexp);

         fprintf(out,"%d; testing %s\n", diff, txa) ;
         fprintf(out,"   date   %8ld\n", yyyymmdd1) ;
         fprintf(out,"   result is %2d ; expected is %2d\n", dres, dexp) ;
         fprintf(out,"   %s\n", txpl) ;
         fprintf(out,"   input holidays are\n") ;

         for(i = 0 ; i < count ; i++)
         {
            yyyymmdd2 = Cldr_Datestr2YMD(&holiday[i]);
            fprintf(out, "   holiday[%3d] is %ld\n", i, yyyymmdd2);
         }

         Free_DATEARRAY(holiday);
         fprintf(out,"\n") ;

    }

    else if (!strcmp(txa, "Cldr_AddBusinessdays()"))
    {
         fscanf(in, "%ld %ld %ld %d %s", &lexp, &yyyymmdd1, &ds1,
                                         &i1, txpl);
         count = (INTI) i1 ;
         holiday = Alloc_DATEARRAY(count);
         for (i = 0 ; i < count ; i++)
         {
            fscanf(in,"%ld", &yyyymmdd2);
            holiday[i] = Cldr_YMD2Datestr(yyyymmdd2);
         }

         dateinput1 = Cldr_YMD2Datestr(yyyymmdd1);
         dateres = Cldr_AddBusinessdays(&dateinput1, ds1, count, holiday);
         lres = Cldr_Datestr2YMD(&dateres);

         diff = (lres != lexp);

         fprintf(out,"%d; testing %s\n", diff, txa) ;
         fprintf(out,"   date           %8ld\n", yyyymmdd1) ;
         fprintf(out,"   business dates %8d\n", ds1) ;
         fprintf(out,"   result is %8ld ; expected is %8ld\n", lres, lexp) ;
         fprintf(out,"   %s\n", txpl) ;
         fprintf(out,"   input holidays are\n") ;

         for (i = 0 ; i < count ; i++)
         {
            yyyymmdd2 = Cldr_Datestr2YMD(&holiday[i]);
            fprintf(out, "   holiday[%3d] is %ld\n", i, yyyymmdd2);
         }
         Free_DATEARRAY(holiday);
         fprintf(out,"\n") ;
    }

    else if (!strcmp("Cldr_TermBetweenDates()", txa))
    {
        fscanf(in, "%lf %ld %ld %d %s %s %s", &fexp, &yyyymmdd1,
                                   &yyyymmdd2, &i1, txb, txc, txpl);
        qbas = (INTI) i1 ;
        cal = Str2CALCONV(txb) ;
        eom = Str2EOMCONV(txc) ;
        dateinput1 = Cldr_YMD2Datestr(yyyymmdd1);
        dateinput2 = Cldr_YMD2Datestr(yyyymmdd2);


		/* PMSTA-22396 - SRIDHARA � 160502 */
		holi = Read_HOLI_STR(in, out);
		fres = Cldr_TermBetweenDates(&dateinput1, &dateinput2,
                                                         qbas, cal, eom, &holi);
        diff = (fabs(fexp - fres) > acc) ;

         fprintf(out,"%d; testing %s\n", diff, txa) ;
         fprintf(out,"   start date %8ld\n", yyyymmdd1) ;
         fprintf(out,"   end   date %8ld\n", yyyymmdd2) ;
         fprintf(out,"   frequency  %8d\n", qbas) ;
         fprintf(out,"   cal        %8s\n", txb) ;
         fprintf(out,"   eom        %8s\n", txc) ;
         fprintf(out,"   result is %8.5lf ; expected is %8.5lf\n", fres, fexp) ;
         fprintf(out,"   %s\n\n", txpl) ;

		 /* PMSTA-22396 - SRIDHARA � 160502 */
		 Free_DATEARRAY(holi.holidays);
    }

    else if (!strcmp("Cldr_Genr_Dates_Count()", txa))
    {
        fscanf(in, "%d %ld %ld %d %s %s", &dexp, &yyyymmdd1, &yyyymmdd2,
                                          &i1, txb, txpl);

        count = (INTI) i1 ;
        cal = Str2CALCONV(txb) ;
        dateinput1 = Cldr_YMD2Datestr(yyyymmdd1);
        dateinput2 = Cldr_YMD2Datestr(yyyymmdd2);

		/* PMSTA-22396 - SRIDHARA � 160502 */
		holi = Read_HOLI_STR(in, out);
		dres = Cldr_Genr_Dates_Count(&dateinput1, &dateinput2,
                                         count, cal, &holi) ;
        diff = (dexp != dres) ;

         fprintf(out,"%d; testing %s\n", diff, txa) ;
         fprintf(out,"   start date   %8ld\n", yyyymmdd1) ;
         fprintf(out,"   end   date   %8ld\n", yyyymmdd2) ;
         fprintf(out,"   day interval %8d\n", count) ;
         fprintf(out,"   cal          %8s\n", txb) ;
         fprintf(out,"   result is %4d ; expected is %4d\n", dres, dexp) ;
         fprintf(out,"   %s\n\n", txpl) ;

		 /* PMSTA-22396 - SRIDHARA � 160502 */
		 Free_DATEARRAY(holi.holidays);
    }

    else if (!strcmp("Cldr_Genr_Dates()", txa))
    {
        fscanf(in, "%ld %ld %d %s %s %d %s", &yyyymmdd1, &yyyymmdd2,
                                          &i2, txb, txc, &i1, txpl);
        count = (INTI) i1 ;
        w = (INTI) i2 ;
        cal   = Str2CALCONV(txb) ;
        align = Str2ALIGNCONV(txc) ;
        dateinput1 = Cldr_YMD2Datestr(yyyymmdd1);
        dateinput2 = Cldr_YMD2Datestr(yyyymmdd2);

		/* PMSTA-22396 - SRIDHARA � 160502 */
		holi = Read_HOLI_STR(in, out);
        count1 = Cldr_Genr_Dates_Count(&dateinput1, &dateinput2,
                                           w, cal, &holi) ;
        if (count != count1)
        {
            diff = 1 ;

            fprintf(out,"%d; testing %s\n", diff, txa) ;
            fprintf(out,"   start date   %8ld\n", yyyymmdd1) ;
            fprintf(out,"   end   date   %8ld\n", yyyymmdd2) ;
            fprintf(out,"   day interval %8d\n", w) ;
            fprintf(out,"   count        %8d\n", count) ;
            fprintf(out,"   cal          %8s\n", txb) ;
            fprintf(out,"   align        %8s\n", txc) ;
            fprintf(out,
              "   input count %d is faulty, should be %d\n",
              count, count1) ;
            fprintf(out,"   %s\n\n", txpl) ;

            for (i = 0 ; i < count ; i++)
                fscanf(in, "%ld", &ymd) ;
        }
        else
        {
            dates    = Alloc_DATEARRAY(count) ;
            expdates = Alloc_DATEARRAY(count) ;
            n = Cldr_Genr_Dates(&dateinput1, &dateinput2, w, cal,
                                    dates, align, &holi);  /* PMSTA-22396 - SRIDHARA � 160502 */
            diff = 0 ;
            for (i = 0 ; i < count ; i++)
            {
                fscanf(in, "%ld", &ymd) ;
                expdates[i] = Cldr_YMD2Datestr(ymd) ;
                dif1 = (Cldr_DateEQ(&dates[i], &expdates[i]) == True ?
                                                                  0 : 1) ;
                diff = (dif1 ? 1 : diff) ;
            }

            fprintf(out,"%d; testing %s\n", diff, txa) ;
            fprintf(out,"   start date   %8ld\n", yyyymmdd1) ;
            fprintf(out,"   end   date   %8ld\n", yyyymmdd2) ;
            fprintf(out,"   day interval %8d\n", w) ;
            fprintf(out,"   cal          %8s\n", txb) ;
            fprintf(out,"   align        %8s\n", txc) ;
            fprintf(out,"   results are\n") ;

            for (i = 0 ; i < count ; i++)
                fprintf(out,"%d; expected date = %8ld computed date = %8ld\n",
                        (Cldr_DateEQ(&dates[i], &expdates[i]) == False),
                         Cldr_Datestr2YMD(&expdates[i]), 
                         Cldr_Datestr2YMD(&dates[i]));
            fprintf(out,"   %s\n\n", txpl) ;
            Free_DATEARRAY(dates) ;
            Free_DATEARRAY(expdates) ;
        }
		Free_DATEARRAY(holi.holidays);  	/* PMSTA-22396 - SRIDHARA � 160502 */
    }

    else if (!strcmp("Cldr_Ymd2Terms()", txa))
    {
        fscanf(in, "%ld %d %s %s %d %s", &yyyymmdd1, &i2,
                                         txb, txc, &i1, txpl) ;
        count = (INTI) i1 ;
        qbas  = (INTI) i2 ;
        cal = Str2CALCONV(txb) ;
        eom = Str2EOMCONV(txc) ;
        expterms = Alloc_FL64ARRAY(count) ;
        ymds     = Alloc_YMDARRAY(count) ;

        for (i = 0 ; i < count ; i++)
            fscanf(in, "%ld %lf", &ymds[i], &expterms[i]) ;

		/* PMSTA-22396 - SRIDHARA � 160502 */
		holi = Read_HOLI_STR(in, out);
        terms = Cldr_Ymd2Terms(yyyymmdd1, count, ymds, cal, eom, qbas, &holi) ;

        diff = 0 ;
        for (i = 0 ; i < count ; i++)
        {
            dif1 = (fabs(terms[i] - expterms[i]) > acc ? True : False) ;
            diff = (dif1 ? 1 : diff) ;
        }

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   date      %8ld\n", yyyymmdd1) ;
        fprintf(out,"   cal       %8s\n", txb) ;
        fprintf(out,"   eom       %8s\n", txc) ;
        fprintf(out,"   frequency %8d\n", qbas) ;
        fprintf(out,"   results are\n") ;

        for (i = 0 ; i < count ; i++)
            fprintf(out,"%d; expected term = %lf  computed term = %lf\n",
                    (fabs(terms[i] - expterms[i]) > acc),
                    expterms[i], terms[i]) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_FL64ARRAY(terms) ;
        Free_FL64ARRAY(expterms) ;
        Free_YMDARRAY(ymds) ;
		Free_DATEARRAY(holi.holidays);  	/* PMSTA-22396 - SRIDHARA � 160502 */

    }
    else if (!strcmp("Cldr_Dates2Terms()", txa))
    {
        fscanf(in, "%ld %d %s %s %d %s", &yyyymmdd1, &i2,
                                         txb, txc, &i1, txpl) ;
        count = (INTI) i1 ;
        qbas  = (INTI) i2 ;
        cal = Str2CALCONV(txb) ;
        eom = Str2EOMCONV(txc) ;
        dateinput1 = Cldr_YMD2Datestr(yyyymmdd1) ;
        expterms = Alloc_FL64ARRAY(count) ;
        dates    = Alloc_DATEARRAY(count) ;

        for (i = 0 ; i < count ; i++)
        {
            fscanf(in, "%ld %lf", &yyyymmdd2, &expterms[i]) ;
            dates[i] = Cldr_YMD2Datestr(yyyymmdd2) ;
        }

		/* PMSTA-22396 - SRIDHARA � 160502 */
		holi = Read_HOLI_STR(in, out);
        terms = Cldr_Dates2Terms(&dateinput1, count, dates, cal, eom, qbas, &holi) ;

        diff = 0 ;
        for (i = 0 ; i < count ; i++)
        {
            dif1 = (fabs(terms[i] - expterms[i]) > acc ? True : False) ;
            diff = (dif1 ? 1 : diff) ;
        }

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   date      %8ld\n", yyyymmdd1) ;
        fprintf(out,"   cal       %8s\n", txb) ;
        fprintf(out,"   eom       %8s\n", txc) ;
        fprintf(out,"   frequency %8d\n", qbas) ;
        fprintf(out,"   results are\n") ;

        for (i = 0 ; i < count ; i++)
            fprintf(out,"%d; expected term = %lf  computed term = %lf\n",
                    (fabs(terms[i] - expterms[i]) > acc),
                    expterms[i], terms[i]) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_FL64ARRAY(terms) ;
        Free_FL64ARRAY(expterms) ;
        Free_DATEARRAY(dates) ;
		Free_DATEARRAY(holi.holidays);  	/* PMSTA-22396 - SRIDHARA � 160502 */
    }
    else if (!strcmp("Cldr_ComputeTerms()", txa))
    {
        fscanf(in, "%ld %d %s %s %s %d %d %s", &yyyymmdd1, &i3,
                                         txb, txc, txd, &i2, &i1, txpl) ;
        count = (INTI) i1 ;
        n = (INTI) i2 ;
        qbas = (INTI) i3 ;
        cal1 = Str2CALCONV(txb) ;
        cal2 = Str2CALCONV(txc) ;
        eom  = Str2EOMCONV(txd) ;
        dateinput1 = Cldr_YMD2Datestr(yyyymmdd1) ;
        expterms = Alloc_FL64ARRAY(count) ;
        dates    = Alloc_DATEARRAY(count) ;
        dates1   = Alloc_DATEARRAY(n) ;

        for (i = 0 ; i < n ; i++)
        {
            fscanf(in, "%ld", &yyyymmdd2) ;
            dates1[i] = Cldr_YMD2Datestr(yyyymmdd2) ;
        }
        for (i = 0 ; i < count ; i++)
        {
            fscanf(in, "%ld %lf", &yyyymmdd2, &expterms[i]) ;
            dates[i] = Cldr_YMD2Datestr(yyyymmdd2) ;
        }

		/* PMSTA-22396 - SRIDHARA � 160502 */
		holi = Read_HOLI_STR(in, out);
        terms = Cldr_ComputeTerms(&dateinput1, count, dates, n, dates1, qbas,
                                   cal1, cal2, eom, &holi) ;

        diff = 0 ;
        for (i = 0 ; i < count ; i++)
        {
            dif1 = (fabs(terms[i] - expterms[i]) > acc ? True : False) ;
            diff = (dif1 ? 1 : diff) ;
        }

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   date      %8ld\n", yyyymmdd1) ;
        fprintf(out,"   frequency %8d\n", qbas) ;
        fprintf(out,"   cal1      %8s\n", txb) ;
        fprintf(out,"   cal2      %8s\n", txc) ;
        fprintf(out,"   eom       %8s\n", txd) ;
        fprintf(out,"   original dates:\n") ;

        for (i = 0 ; i < n ; i++)
            fprintf(out,"    date %ld\n", Cldr_Datestr2YMD(&dates1[i]) ) ;

        fprintf(out,"   results are\n") ;
        for (i = 0 ; i < count ; i++)
            fprintf(out,
              "%d; date %ld expected term = %lf  computed term = %lf\n",
              
                    (fabs(terms[i] - expterms[i]) > acc),
                    Cldr_Datestr2YMD(&dates[i]),
                    expterms[i], terms[i]) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_FL64ARRAY(terms) ;
        Free_FL64ARRAY(expterms) ;
        Free_DATEARRAY(dates) ;
        Free_DATEARRAY(dates1) ;
		Free_DATEARRAY(holi.holidays);  	/* PMSTA-22396 - SRIDHARA � 160502 */
    }
    else if (!strcmp("Cldr_MergeDates()", txa))
    {
        fscanf(in, "%d %d %d %s", &i1, &i2, &i3, txpl) ;
        n1 = (INTI) i1 ;
        n2 = (INTI) i2 ;
        n3 = (INTI) i3 ;

        dates1 = Alloc_DATEARRAY(n1) ;
        dates2 = Alloc_DATEARRAY(n2) ;
        dates3 = Alloc_DATEARRAY(n3) ;

        for (i = 0 ; i < n1 ; i++)
        {
            fscanf(in, "%ld", &ymd) ;
            dates1[i] = Cldr_YMD2Datestr(ymd) ;
        }

        for (i = 0 ; i < n2 ; i++)
        {
            fscanf(in, "%ld", &ymd) ;
            dates2[i] = Cldr_YMD2Datestr(ymd) ;
        }

        for (i = 0 ; i < n3 ; i++)
        {
            fscanf(in, "%ld", &ymd) ;
            dates3[i] = Cldr_YMD2Datestr(ymd) ;
        }

        dates = Cldr_MergeDates(dates1, n1, dates2, n2, &n) ;

        diff = (n == n3 ? 0 : 1) ;

        fprintf(out,"%d; testing %s\n", (int) diff, txa) ;
        fprintf(out,"   input date arrays are\n") ;

        for (i = 0 ; i < GETMAX(n1, n2) ; i++)
        {
            if (i < n1)
                fprintf(out, "   inputdate1[%d]      %ld", (int) i,
                        Cldr_Datestr2YMD(&dates1[i])) ;
            else
                fprintf(out, "                              ") ;
            if (i < n2)
                fprintf(out, "   inputdate2[%d]      %ld", (int) i,
                        Cldr_Datestr2YMD(&dates2[i])) ;
            fprintf(out, "\n") ;
        }

        fprintf(out,"   merged date array is\n") ;

        for (i = 0 ; i < GETMAX(n3, n) ; i++)
        {
            if (i < n3)
                fprintf(out, "   exp.outputday[%d]   %ld", (int) i,
                        Cldr_Datestr2YMD(&dates3[i])) ;
            else
                fprintf(out, "                           ") ;
            if (i < n)
                fprintf(out, "   calc.outputday[%d]  %ld", (int) i,
                        Cldr_Datestr2YMD(&dates[i])) ;
            fprintf(out, "\n") ;
        }
        fprintf(out,"   %s\n\n", txpl) ;
        Free_DATEARRAY(dates1) ;
        Free_DATEARRAY(dates2) ;
        Free_DATEARRAY(dates3) ;
        Free_DATEARRAY(dates) ;
    }
    else if (!strcmp("Cldr_DaysPerYear()", txa))
    {
        fscanf(in, "%lf %ld %ld %d %s %s %s", &fexp, &yyyymmdd1, &yyyymmdd2,
                                          &i1, txb, txc, txpl);
        qbas = (INTI) i1 ;
        cal = Str2CALCONV(txb) ;
        eom = Str2EOMCONV(txc) ;
        dateinput1 = Cldr_YMD2Datestr(yyyymmdd1);
        dateinput2 = Cldr_YMD2Datestr(yyyymmdd2);

		/* PMSTA-22396 - SRIDHARA � 160502 */
		holi = Read_HOLI_STR(in, out);
        fres = Cldr_DaysPerYear(&dateinput1, &dateinput2, qbas, cal, eom, &holi);
        diff = (fabs(fexp - fres) > acc) ;

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   date      %8ld\n", yyyymmdd1) ;
        fprintf(out,"   end       %8ld\n", yyyymmdd2) ;
        fprintf(out,"   frequency %8d\n", qbas) ;
        fprintf(out,"   cal       %8s\n", txb) ;
        fprintf(out,"   eom       %8s\n", txc) ;
        fprintf(out,"   result is %8.5lf ; expected is %8.5lf\n",fres, fexp) ;
        fprintf(out,"   %s\n\n", txpl) ;

		Free_DATEARRAY(holi.holidays);  	/* PMSTA-22396 - SRIDHARA � 160502 */
	
    }

    else if (!strcmp("Cldr_TermUnit2Date()", txa))
    {
        fscanf(in, "%ld %ld %d %s %s %s %s", &lexp, &yyyymmdd1,
                                          &i1, txd, txb, txc, txpl);
        n = (INTI) i1 ;
        cal  = Str2CALCONV(txb) ;
        eom  = Str2EOMCONV(txc) ;
        unit = Str2TERMUNIT(txd) ;
        dateinput1 = Cldr_YMD2Datestr(yyyymmdd1);

        holi.nholi = 0;

        dateres = Cldr_TermUnit2Date(&dateinput1, n, unit, cal, eom, &holi) ;
        lres = Cldr_Datestr2YMD(&dateres) ;
        diff = lexp != lres ;

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   date      %8ld\n", yyyymmdd1) ;
        fprintf(out,"   maturity  %8d\n", n) ;
        fprintf(out,"   unit      %8s\n", txd) ;
        fprintf(out,"   cal       %8s\n", txb) ;
        fprintf(out,"   eom       %8s\n", txc) ;
        fprintf(out,"   result is %8d ; expected is %8d\n", lres, lexp) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }

    else if (!strcmp("Cldr_AddPeriod()", txa))
    {
        fscanf(in, "%ld %ld %d %s %s %s %s",
               &lexp, &yyyymmdd1, &i1, txd, txb, txc, txpl);
        n = (INTI) i1 ;
        cal  = Str2CALCONV(txb) ;
        eom  = Str2EOMCONV(txc) ;
        unit = Str2TERMUNIT(txd) ;
        dateinput1 = Cldr_YMD2Datestr(yyyymmdd1);
        holi.nholi = 0;
        per.num = n ;
        per.unit = unit ;

        dateres = Cldr_AddPeriod(&dateinput1, &per, cal, eom, &holi) ;
        lres = Cldr_Datestr2YMD(&dateres) ;
        diff = lexp != lres ;

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   date      %8ld\n", yyyymmdd1) ;
        fprintf(out,"   maturity  %8d\n", n) ;
        fprintf(out,"   unit      %8s\n", txd) ;
        fprintf(out,"   cal       %8s\n", txb) ;
        fprintf(out,"   eom       %8s\n", txc) ;
        fprintf(out,"   result is %8d ; expected is %8d\n", lres, lexp) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }

    else if (!strcmp("Cldr_NextROLL()", txa))
    {
        fscanf(in, "%ld %ld %s %d %s %s %s",
               &lexp, &yyyymmdd1, txe, &i1, txd, txb, txc);
        n = (INTI) i1 ;
        roll = Str2SEQCONV(txe) ;
        cal  = Str2CALCONV(txb) ;
        eom  = Str2EOMCONV(txc) ;
        unit = Str2TERMUNIT(txd) ;
        dateinput1 = Cldr_YMD2Datestr(yyyymmdd1);
        per.num = n ;
        per.unit = unit ;

        fprintf(out,"testing %s\n", txa) ;
        fprintf(out,"   date      %8ld\n", yyyymmdd1) ;
        fprintf(out,"   maturity  %8d\n", n) ;
        fprintf(out,"   Roll      %8s\n", txe) ;
        fprintf(out,"   unit      %8s\n", txd) ;
        fprintf(out,"   cal       %8s\n", txb) ;
        fprintf(out,"   eom       %8s\n", txc) ;

        holi = Read_HOLI_STR(in, out) ;

        dateres = Cldr_NextROLL(&dateinput1, roll, &per, cal, eom, &holi) ;

        lres = Cldr_Datestr2YMD(&dateres) ;
        diff = lexp != lres ;
        fprintf(out,"%d; result is %8d ; expected is %8d\n", diff, lres, lexp) ;
        
        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;
        
        Free_DATEARRAY(holi.holidays) ;
    }

    else if (!strcmp("Cldr_DaysInPeriod()", txa))
    {
        fscanf(in, "%ld %ld %d %s %s %s %s",
               &lexp, &yyyymmdd1, &i1, txd, txb, txc, txpl);
        n = (INTI) i1 ;
        cal  = Str2CALCONV(txb) ;
        eom  = Str2EOMCONV(txc) ;
        unit = Str2TERMUNIT(txd) ;
        dateinput1 = Cldr_YMD2Datestr(yyyymmdd1) ;
        holi.nholi = 0 ;
        per.num = n ;
        per.unit = unit ;

        lres = Cldr_DaysInPeriod(&dateinput1, &per, cal, eom, &holi) ;
        diff = lexp != lres ;

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   date      %8ld\n", yyyymmdd1) ;
        fprintf(out,"   Dur       %8d\n", n) ;
        fprintf(out,"   Unit      %8s\n", txd) ;
        fprintf(out,"   cal       %8s\n", txb) ;
        fprintf(out,"   eom       %8s\n", txc) ;
        fprintf(out,"   result is %8d ; expected is %8d\n", lres, lexp) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }

    else if (!strcmp("Cldr_PeriodsBetweenDates()", txa))
    {
        fscanf(in, "%ld %ld %ld %d %s %s %s %s",
               &lexp, &yyyymmdd1, &yyyymmdd2, &i1, txd, txb, txc, txpl);
        n = (INTI) i1 ;
        cal  = Str2CALCONV(txb) ;
        eom  = Str2EOMCONV(txc) ;
        unit = Str2TERMUNIT(txd) ;
        dateinput1 = Cldr_YMD2Datestr(yyyymmdd1) ;
        dateinput2 = Cldr_YMD2Datestr(yyyymmdd2) ;
        holi.nholi = 0 ;
        per.num = n ;
        per.unit = unit ;

        lres = Cldr_PeriodsBetweenDates(&dateinput1, &dateinput2, &per,
                                        cal, eom, &holi) ;
        diff = lexp != lres ;

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   Start     %8ld\n", yyyymmdd1) ;
        fprintf(out,"   End       %8ld\n", yyyymmdd2) ;
        fprintf(out,"   Dur       %8d\n", n) ;
        fprintf(out,"   Unit      %8s\n", txd) ;
        fprintf(out,"   cal       %8s\n", txb) ;
        fprintf(out,"   eom       %8s\n", txc) ;
        fprintf(out,"   result is %8d ; expected is %8d\n", lres, lexp) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }

    else if (!strcmp("Cldr_Term2Date()", txa))
    {
        fscanf(in, "%ld %ld %lf %s %s %s %s", &lexp, &yyyymmdd1,
                                              &fln, txd, txb, txc, txpl);
        cal  = Str2CALCONV(txb) ;
        eom  = Str2EOMCONV(txc) ;
        unit = Str2TERMUNIT(txd) ;
        dateinput1 = Cldr_YMD2Datestr(yyyymmdd1);
        dateres = Cldr_Term2Date(&dateinput1, fln, unit, cal, eom);
        lres = Cldr_Datestr2YMD(&dateres) ;
        diff = lexp != lres ;

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   date      %8ld\n", yyyymmdd1) ;
        fprintf(out,"   maturity  %3.4lf\n", fln) ;
        fprintf(out,"   unit      %8s\n", txd) ;
        fprintf(out,"   cal       %8s\n", txb) ;
        fprintf(out,"   eom       %8s\n", txc) ;
        fprintf(out,"   result is %8d ; expected is %8d\n", lres, lexp) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }
    else if (!strcmp("Cldr_FindDateIndex()", txa))
    {
        fscanf(in, "%d %ld %d %s %s %s", &i2, &dsettle, &i1, txb, txc, txpl);
        n = (INTI) i1 ;
        dexp = (INTI) i2 ;
        daysettle = Cldr_YMD2Datestr(dsettle) ;
        daytheo = Alloc_DATEARRAY(n) ;
        sconv = Str2SEARCHCONV(txb) ;
        iconv = Str2INDEXCONV(txc) ;
        for (i = 0; i < n ; i++)
        {
            fscanf(in, "%ld", &dprev) ;
            daytheo[i] = Cldr_YMD2Datestr(dprev) ;
        }
        dres = Cldr_FindDateIndex(daytheo, n, &daysettle, 1, sconv, iconv) ;
        diff = (dres != dexp) ;

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   date              %10ld\n", dsettle) ;
        fprintf(out,"   search convention %10s\n", txb) ;
        fprintf(out,"   interpolation     %10s\n", txc) ;
        fprintf(out,"   input date array is\n") ;
        for (i = 0 ; i < n ; i++)
            fprintf(out,
              "   date[%3d] = %8ld\n",
              i, Cldr_Datestr2YMD(&daytheo[i])) ;
        fprintf(out,"   result is %3d ; expected is %3d\n", dres, dexp) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_DATEARRAY(daytheo) ;
    }
    else if (!strcmp("Cldr_FindTermIndex()", txa))
    {
        fscanf(in, "%d %lf %d %s %s %s", &i1, &t1, &i2, txb, txc, txpl);
        dexp = (INTI) i1 ;
        n = (INTI) i2 ;

        sconv = Str2SEARCHCONV(txb) ;
        iconv = Str2INDEXCONV(txc) ;
        terms = Alloc_FL64ARRAY(n) ;
        for (i = 0 ; i < n ; i++)    fscanf(in, "%lf", &terms[i]) ;

        dres = Cldr_FindTermIndex(terms, n, t1, 1, sconv, iconv) ;
        diff = (dres != dexp) ;

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   term              %10.5lf\n", t1) ;
        fprintf(out,"   search convention %10s\n", txb) ;
        fprintf(out,"   interpolation     %10s\n", txc) ;
        fprintf(out,"   input term array is\n") ;
        for (i = 0 ; i < n ; i++)
            fprintf(out,"   term[%3d] = %8.5lf\n", i, terms[i]) ;
        fprintf(out,"   result is %3d ; expected is %3d\n", dres, dexp) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_FL64ARRAY(terms) ;
    }

    else if (!strcmp("Cldr_DateSort()", txa))
    {
        fscanf(in, "%s %d %s", txb, &i1, txpl);
        n = (INTI) i1 ;

        sort   = Str2SORTCONV(txb) ;
        dates  = Alloc_DATEARRAY(n) ;
        dates1 = Alloc_DATEARRAY(n) ;
        dates2 = Alloc_DATEARRAY(n) ;

        for (i = 0 ; i < n ; i++)
        {
            fscanf(in, "%ld %ld", &yyyymmdd1, &yyyymmdd2) ;
            dates2[i] = dates[i] = Cldr_YMD2Datestr(yyyymmdd1) ;
            dates1[i] = Cldr_YMD2Datestr(yyyymmdd2) ;
        }

        Cldr_DateSort(n, dates, sort) ;

        for (diff = 0, i = 0 ; i < n ; i++)
            if (Cldr_DateEQ(&dates[i], &dates1[i]) == False)
                diff = 1 ;

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   sort     %10s\n", txb) ;
        fprintf(out,"   Input dates:\n") ;
        for (i = 0 ; i < n ; i++)
            fprintf(out,"   date[%d]  %8ld\n", i, Cldr_Datestr2YMD(&dates2[i]));

        fprintf(out,"   Sorted dates:\n") ;
        for (i = 0 ; i < n ; i++)
            fprintf(out,"   date[%d]  %8ld\n", i, Cldr_Datestr2YMD(&dates[i]));

        fprintf(out,"\n") ;
        Free_DATEARRAY(dates) ;
        Free_DATEARRAY(dates1) ;
        Free_DATEARRAY(dates2) ;
    }

    else if (!strcmp("Cldr_InsertDate()", txa))
    {
        fscanf(in, "%ld %d %d %s", &ymd, &i1, &i2, txpl);
        n = (INTI) i1 ;
        n1 = (INTI) i2 ;

        dates  = Alloc_DATEARRAY(n1) ;
        dates1 = Alloc_DATEARRAY(n1) ;
        dates2 = Alloc_DATEARRAY(n1) ;

        for (i = 0 ; i < n ; i++)
        {
            fscanf(in, "%ld", &yyyymmdd1) ;
            dates2[i] = dates[i] = Cldr_YMD2Datestr(yyyymmdd1) ;
        }

        for (i = 0 ; i < n1 ; i++)
        {
            fscanf(in, "%ld", &yyyymmdd1) ;
            dates1[i] = Cldr_YMD2Datestr(yyyymmdd1) ;
        }

        date = Cldr_YMD2Datestr(ymd) ;
        n2 = Cldr_InsertDate(dates, n, &date, &i) ;

        for (diff = 0, i = 0 ; i < n1 ; i++)
            if (Cldr_DateEQ(&dates[i], &dates1[i]) == False)
                diff = 1 ;

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   date     %ld\n", ymd) ;
        fprintf(out,"   Input dates:\n") ;
        for (i = 0 ; i < n ; i++)
            fprintf(out,"   date[%d]  %8ld\n", i, Cldr_Datestr2YMD(&dates2[i]));

        fprintf(out,"   Output dates:\n") ;
        for (i = 0 ; i < n2 ; i++)
            fprintf(out,"   date[%d]  %8ld\n", i, Cldr_Datestr2YMD(&dates[i])) ;

        fprintf(out,"\n") ;
        Free_DATEARRAY(dates) ;
        Free_DATEARRAY(dates1) ;
        Free_DATEARRAY(dates2) ;
    }

    else if (!strcmp("Cldr_Holding2Amort()", txa))
    {
        fscanf(in, "%s", txpl);
        fprintf(out,"testing Cldr_Holding2Amort\n%s\n", txpl) ;

        dateinput1 = Read_DATESTR(in, out, "Start date      ");
        dateinput2 = Read_DATESTR(in, out, "Maturity date   ");

        plan = Read_PLANARRAY(in);

        fprintf(out,"  Holding structure:\n");
        Write_PLANARRAY(out, plan);

        planres = Cldr_Holding2Amort(&dateinput1, &dateinput2, plan);

        planexp = Read_PLANARRAY(in);

        diff = Write_PlanDiff(planexp, planres, out);

        Free_PLANARRAY(plan, 1);
        Free_PLANARRAY(planexp, 1);
        Free_PLANARRAY(planres, 1);
    }
    else if (!strcmp("Cldr_InsertInPlan()", txa))
    {
        fscanf(in, "%ld %lf %s %d %d %s", &dsettle, &t1, txb, &i1, &i2, txpl);
        n = (INTI) i1 ;
        n1 = (INTI) i2 ;
        daysettle = Cldr_YMD2Datestr(dsettle) ;
        override  = Str2BOOLE(txb) ;
        plan      = Alloc_PLANARRAY(2, GETMAX(n, n1)) ;

        for (i = 0 ; i < n ; i++)
        {
            fscanf(in, "%ld %lf", &dprev, &plan[0].f64[i]) ;
            plan[0].day[i] = Cldr_YMD2Datestr(dprev) ;
        }
        plan[0].filled = n ;
        plan[0].count  = GETMAX(n, n1) + 1 ;

        for (i = 0; i < n1 ; i++)
        {
            fscanf(in, "%ld %lf", &dprev, &plan[1].f64[i]) ;
            plan[1].day[i] = Cldr_YMD2Datestr(dprev) ;
        }
        plan[1].filled = n1 ;
        plan[1].count  = GETMAX(n, n1) ;

        dres = Cldr_InsertInPlan(&daysettle, t1, &plan[0], override) ;

        diff = (dres != n1) ;

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   date              %10ld\n",  dsettle) ;
        fprintf(out,"   f64               %7.3lf\n", t1) ;
        fprintf(out,"   override ?        %10s\n",   txb) ;
        fprintf(out,"   expected plan array is                ") ;
        fprintf(out,"output plan array is\n") ;
        for (i = 0 ; i < GETMAX(plan[0].filled, plan[1].filled) ; i++)
        {
            if (i < plan[0].filled && i < plan[1].filled)
            {
                dif1 = (plan[0].f64[i] != plan[1].f64[i]) ;
                dif1 = dif1 || (!Cldr_DateEQ(&plan[0].day[i], &plan[1].day[i]));
            }
            else
                dif1 = 1 ;
            diff = diff || dif1 ;
            if (i < plan[1].filled)
                fprintf(out,"%d; date[%2d] = %8ld f64[%2d] = %5.2lf",
                        dif1,
                        i, Cldr_Datestr2YMD(&plan[1].day[i]), i, 
                        plan[1].f64[i]);
            else
                fprintf(out,"                                 ") ;

            if (i < plan[0].filled)
                fprintf(out,"   date[%2d] = %8ld f64[%2d] = %5.2lf\n",
                        i, Cldr_Datestr2YMD(&plan[0].day[i]), i, 
                        plan[0].f64[i]);
            else
                fprintf(out,"\n") ;

        }
        fprintf(out,"   %s\n\n", txpl) ;

        Free_PLANARRAY(plan, 2) ;
    }

    else if (!strcmp("Cldr_Step2Dates()", txa))
    {
        fscanf(in,
          "%d %d %ld %s %s %s %s ",
          &i1, &i2, &ymd, txb, txc, txd, txpl) ;

        nstep = (INTI) i1 ;
        n     = (INTI) i2 ;

        date = Cldr_YMD2Datestr(ymd) ;

        step  = Alloc_STEPARRAY(nstep) ;
        dates = Alloc_DATEARRAY(n) ;

        cal = Str2CALCONV( txb );
        eom = Str2EOMCONV( txc );
        override = Str2BOOLE( txd );

        fprintf(out,"\n   testing %s\n", txa) ;
        fprintf(out,"   The step struct\n") ;
        for (i = 0; i < nstep; i++)
        {
            fscanf(in, "%d %s %d", &i1, txb, &i2) ;
            step[i].dur   = (INTI) i1 ;
            step[i].unit  = Str2TERMUNIT(txb) ;
            step[i].nstep = (INTI) i2 ;
            fprintf(out, "   %d %s %d\n", i1, txb, i2) ;
        }

        for (i = 0; i < n ; i++)
        {
            fscanf(in, "%ld", &ymd) ;
            dates[i] = Cldr_YMD2Datestr(ymd) ;
        }

        dates1 = Cldr_Step2Dates(step, nstep, &date, &n1, cal, eom, override) ;

        if (n1 == n)
        {
            diff = 0 ;
            for (i = 0; i < n ; i++)
            {
                dif1 = Cldr_DateEQ(&dates[i], &dates1[i]) == False ;
                diff = diff || dif1 ;
                fprintf(out, "%d; exp %ld res %ld\n",
                        dif1, Cldr_Datestr2YMD(&dates[i]),
                        Cldr_Datestr2YMD(&dates1[i]) ) ;
            }
        }
        else
        {
            diff = 1 ;
            fprintf(out,"1; You expected %d dates we found %d\n", n, n1) ;
            for (i = 0; i < n ; i++)
                fprintf(out, "   res %ld\n",
                        Cldr_Datestr2YMD(&dates1[i]) ) ;
        }
        Free_DATEARRAY(dates) ;
        Free_DATEARRAY(dates1) ;
        Free_STEPARRAY(step) ;
    }

    else if (!strcmp("Cldr_Steps2Dates()", txa))
    {
        fscanf(in,
          "%d %d %ld %ld %s %s ",
          &i1, &i2, &ymd, &ymd1, txb, txpl) ;

        nstep = (INTI) i1 ;
        n     = (INTI) i2 ;

        date = Cldr_YMD2Datestr(ymd) ;
        lastm = Cldr_YMD2Datestr(ymd1) ;

        step  = Alloc_STEPARRAY(nstep) ;
        dates = Alloc_DATEARRAY(n) ;

        cal = Str2CALCONV( txb );

        fprintf(out,"\n   testing %s\n", txa) ;
        fprintf(out,"   The step struct\n") ;
        for (i = 0; i < nstep; i++)
        {
            fscanf(in, "%d %s %d", &i1, txb, &i2) ;
            step[i].dur   = (INTI) i1 ;
            step[i].unit  = Str2TERMUNIT(txb) ;
            step[i].nstep = (INTI) i2 ;
            fprintf(out, "   %d %s %d\n", i1, txb, i2) ;
        }

        for (i = 0; i < n ; i++)
        {
            fscanf(in, "%ld", &ymd) ;
            dates[i] = Cldr_YMD2Datestr(ymd) ;
        }

		/* PMSTA-22396 - SRIDHARA � 160502 */
		holi = Read_HOLI_STR(in, out);

        if (Cldr_Datestr2YMD(&lastm) == 0)
			dates1 = Cldr_Steps2Dates(step, nstep, &date, NULL, cal, &n1, &holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */
        else
			dates1 = Cldr_Steps2Dates(step, nstep, &date, &lastm, cal, &n1, &holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */

        if (n1 == n)
        {
            diff = 0 ;
            for (i = 0; i < n ; i++)
            {
                dif1 = Cldr_DateEQ(&dates[i], &dates1[i]) == False ;
                diff = diff || dif1 ;
                fprintf(out, "%d; exp %ld res %ld\n",
                        dif1, Cldr_Datestr2YMD(&dates[i]),
                        Cldr_Datestr2YMD(&dates1[i]) ) ;
            }
        }
        else
        {
            diff = 1 ;
            fprintf(out,"1; You expected %d dates we found %d\n", n, n1) ;
            for (i = 0; i < n1 ; i++)
                fprintf(out, "   res %ld\n",
                        Cldr_Datestr2YMD(&dates1[i]) ) ;
        }
        Free_DATEARRAY(dates) ;
        Free_DATEARRAY(dates1) ;
        Free_STEPARRAY(step) ;
		Free_DATEARRAY(holi.holidays);   	/* PMSTA-22396 - SRIDHARA � 160502 */
    }

    else if (!strcmp(txa, "Cldr_PlanLookup()"))
    {
      fprintf(out,"\n   testing %s\n", txa) ;

      IOUtil_ParseLine(in, out);

      fexp = Read_FL64(in, out, "Expected result");
      ixexp = Read_INTI(in, out, "Expected index");

      def = Read_FL64(in, out, "Default");
      plan = Read_PLANARRAY(in);
      Write_PLANARRAY(out, plan);
      date = Read_DATESTR(in, out, "Lookup date");
      ix = Read_INTI(in, out, "Start index");

      fres = Cldr_PlanLookup(def, plan, &date, &ix);

      diff = Write_SingleDiff(True, True, fres, fexp, 0.0, out);
      diff = diff | Write_SingleDiff(True, True, ix, ixexp, 0.0, out);

      Free_PLANARRAY(plan, 1);
    }

    return diff ;
}

/* SCID @(#)period.c	1.16 (SimCorp) 99/10/27 14:25:38 */

/************************************************************************
*
*   project     SCecon
*
*   file name   period.c
*
*   general     This file contains standard routines for calendar
*               calculations
*
************************************************************************/

/* includes ************************************************************/
#include <cldr.h>

#define MAX_LOOP 36600 /* PMSTA16410 - DDV - 130529 - Change limit from 10000 to 36600 (around 100 years when unit is days) */


/*,,SOH,,
*************************************************************************
*
*                Cldr_PeriodST()
*
*
*    interface   #include <cldr.h>
*                BOOLE Cldr_PeriodST(PERIOD   *p1,
*                                    PERIOD   *p2,
*                                    DATESTR  *d,
*                                    HOLI_STR *holi,
*                                    CALCONV  cal,
*                                    EOMCONV  eom) ;
*
*    general     The function compares the lengths of two time periods
*
*    input       PERIOD    *p1          Pointer to first period.
*
*                PERIOD    *p2          Pointer to second period.
*
*                DATESTR   *d           Pointer to starting date
*
*                HOLI_STR  *holi        Holiday info
*
*                CALCONV   cal          The calendar convention.
*
*                EOMCONV   eom          The end of month convention.
*
*    output
*
*    returns     'True' if 'p1' is strictly shorter than 'p2'
*                'False' if not
*
*    diagnostics
*
*    see also    Cldr_PeriodSE()
*                Cldr_PeriodEQ()
*
*************************************************************************
,,EOH,,*/


BOOLE Cldr_PeriodST(PERIOD* p1, PERIOD* p2, DATESTR* d, HOLI_STR* holi,
                    CALCONV cal, EOMCONV eom)
{
    if (p1->unit == p2->unit)
        return (p1->num < p2->num) ;

    return (Cldr_DaysInPeriod(d, p1, cal, eom, holi)
             < Cldr_DaysInPeriod(d, p2, cal, eom, holi)) ;
}


/*,,SOH,,
*************************************************************************
*
*                Cldr_PeriodEQ()
*
*
*    interface   #include <cldr.h>
*                BOOLE Cldr_PeriodEQ(PERIOD   *p1,
*                                    PERIOD   *p2,
*                                    DATESTR  *d,
*                                    HOLI_STR *holi,
*                                    CALCONV  cal,
*                                    EOMCONV  eom) ;
*
*    general     The function compares the lengths of two time periods
*
*    input       PERIOD    *p1          Pointer to first period.
*
*                PERIOD    *p2          Pointer to second period.
*
*                DATESTR   *d           Pointer to starting date
*
*                HOLI_STR  *holi        Holiday info
*
*                CALCONV   cal          The calendar convention.
*
*                EOMCONV   eom          The end of month convention.
*
*    output
*
*    returns     'True' if 'p1' and 'p2' have equal lengths
*                'False' if not
*
*    diagnostics
*
*    see also    Cldr_PeriodSE()
*                Cldr_PeriodST()
*
*************************************************************************
,,EOH,,*/

BOOLE Cldr_PeriodEQ(PERIOD* p1, PERIOD* p2, DATESTR* d, HOLI_STR* holi,
                    CALCONV cal, EOMCONV eom)
{
    if (p1->unit == p2->unit)
        return (p1->num == p2->num) ;

    return (Cldr_DaysInPeriod(d, p1, cal, eom, holi)
            == Cldr_DaysInPeriod(d, p2, cal, eom, holi)) ;
}


/*,,SOH,,
*************************************************************************
*
*                Cldr_PeriodSE()
*
*
*    interface   #include <cldr.h>
*                BOOLE Cldr_PeriodSE(PERIOD   *p1,
*                                    PERIOD   *p2,
*                                    DATESTR  *d,
*                                    HOLI_STR *holi,
*                                    CALCONV  cal,
*                                    EOMCONV  eom) ;
*
*    general     The function compares the lengths of two time periods
*
*    input       PERIOD    *p1          Pointer to first period.
*
*                PERIOD    *p2          Pointer to second period.
*
*                DATESTR   *d           Pointer to starting date
*
*                HOLI_STR  *holi        Holiday info
*
*                CALCONV   cal          The calendar convention.
*
*                EOMCONV   eom          The end of month convention.
*
*    output
*
*    returns     'True' if length of 'p1' is less than or equal to
*                 length of 'p2'
*                 'False' if not
*
*    diagnostics
*
*    see also    Cldr_PeriodEQ()
*                Cldr_PeriodST()
*
*************************************************************************
,,EOH,,*/

BOOLE Cldr_PeriodSE(PERIOD* p1, PERIOD* p2, DATESTR* d, HOLI_STR* holi,
                    CALCONV cal, EOMCONV eom)
{
    if (p1->unit == p2->unit)
        return (p1->num <= p2->num) ;

    return (Cldr_DaysInPeriod(d, p1, cal, eom, holi)
            <= Cldr_DaysInPeriod(d, p2, cal, eom, holi)) ;
}


/*,,SOH,,
*************************************************************************
*
*                Cldr_DaysInPeriod()
*
*    interface   #include <cldr.h>
*                INTL Cldr_DaysInPeriod(DATESTR  *date,
*                                       PERIOD   *p,
*                                       CALCONV  cal,
*                                       EOMCONV  eom,
*                                       HOLI_STR *holi) ;
*
*    general     The function calculates the number of days in a period.*
*
*    input       DATESTR   *date        Pointer to the start date.
*
*                PERIOD    *p           The period
*
*                CALCONV   cal          The calendar convention.
*
*                EOMCONV   eom          The end of month convention.
*
*                HOLI_STR  *holi        Holiday info
*
*    output
*
*    returns     the number of days
*
*    diagnostics
*
*    see also
*
*************************************************************************
,,EOH,,*/


INTL Cldr_DaysInPeriod(DATESTR* date, PERIOD* p, CALCONV cal,
                       EOMCONV eom, HOLI_STR* holi)
{
    DATESTR d ;
    INTL    b ;

    d = Cldr_AddPeriod(date, p, cal, eom, holi) ;
    b = Cldr_DaysBetweenDates(date, &d, cal, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */

    return b ;
}


/*,,SOH,,
*************************************************************************
*
*                Cldr_AddPeriod()
*
*    interface   #include <cldr.h>
*                DATESTR Cldr_AddPeriod(DATESTR  *in,
*                                       PERIOD   *per,
*                                       CALCONV  cal,
*                                       EOMCONV  eom,
*                                       HOLI_STR *holi) ;
*
*    general     The function adds a period to a date
*
*    input       DATESTR   *in          Pointer to the start date.
*
*                PERIOD    *per         The period
*
*                CALCONV   cal          The calendar convention.
*
*                EOMCONV   eom          The end of month convention.
*
*                HOLI_STR  *holi        Holiday info
*
*    output
*
*    returns     The new date
*
*    diagnostics
*
*    see also
*
*    wrapper     AP
*
*************************************************************************
,,EOH,,*/


DATESTR Cldr_AddPeriod(DATESTR* in,
                       PERIOD*   per,
                       CALCONV  cal,
                       EOMCONV  eom,
                       HOLI_STR* holi)
{
    DATESTR d ;

    d = *in ;
    if (per != NULL)
        d = Cldr_TermUnit2Date(in, per->num, per->unit, cal, eom, holi) ;

    return d ;
}


/*,,SOH,,
*************************************************************************
*
*                Cldr_PeriodsBetweenDates()
*
*    interface   #include <cldr.h>
*                INTI Cldr_PeriodsBetweenDates(DATESTR  *first,
*                                              DATESTR  *last,
*                                              PERIOD   *per,
*                                              CALCONV  cal,
*                                              EOMCONV  eom,
*                                              HOLI_STR *holi) ;
*
*    general     The function finds the number of periods between two
*                dates.
*
*    input       DATESTR   *first       Pointer to the start date.
*
*                DATESTR   *last        The last date
*
*                PERIOD    *per         The period
*
*                CALCONV   cal          The calendar convention.
*
*                EOMCONV   eom          The end of month convention.
*
*                HOLI_STR  *holi        Holiday info
*
*    output
*
*    returns     The number of periods
*
*    diagnostics
*
*    see also
*
*************************************************************************
,,EOH,,*/


INTI Cldr_PeriodsBetweenDates(DATESTR* first,
                              DATESTR*  last,
                              PERIOD*   per,
                              CALCONV  cal,
                              EOMCONV  eom,
                              HOLI_STR* holi)
{
    INTI    sig, num ;
    DATESTR d1, d2, tmp ;

    sig = 1 ;
    d1 = *first ;
    d2 = *last ;
    if (Cldr_DateLT(&d2, &d1) == True)
    {
        sig = -1 ;
        d2  = *first ;
        d1  = *last ;
    }

    for (num = 0, tmp = d1; num < MAX_LOOP; num++)
    {
        if (Cldr_DateLT(&tmp, &d2) == False)
           break ;

        tmp = Cldr_AddPeriod(&tmp, per, cal, eom, holi) ;
    }

    return sig * num ;
}


/*,,SOH,,
*************************************************************************
*
*               Alloc_PERIODARRAY()
*
*    interface  #include <cldr.h>
*               PERIODARRAY Alloc_PERIODARRAY(INTI n);
*
*    general    Alloc_PERIODARRAY() allocates memory for an
*               [0...(n-1)] array of PERIOD's.
*               Returns memory with zero'ed entries
*
*    input      INTI    n       The number of entries in the array
*
*    output
*
*    returns    reference to the vector of type PERIOD
*
*    diagnostics aborts calling SCecon_error()
*                with the message   "Allocation failed"
*                         routine   "Alloc_PERIODARRAY()"
*                         actioncode SCECONABORT
*                if allocation fails
*
*    see also   Free_PERIODARRAY()
*
*************************************************************************
,,EOH,,*/


PERIODARRAY Alloc_PERIODARRAY(INTI n)
{
    PERIODARRAY a;

    a = (PERIODARRAY) SCecon_calloc (n, sizeof(PERIOD), True,
      "Alloc_PERIODARRAY()") ;

    return a ;
}


/*,,SOH,,
*************************************************************************
*
*               Free_PERIODARRAY()
*
*    interface  #include <cldr.h>
*               void Free_PERIODARRAY(PERIODARRAY v) ;
*
*    general    Free_PERIODARRAY() frees memory for an array
*               of PERIOD's allocated by Alloc_PERIODARRAY()
*
*    input      PERIODARRAY v       Reference to the array of dates
*
*    output
*
*    returns
*
*    diagnostics
*
*    see also   Alloc_PERIODARRAY()
*
*************************************************************************
,,EOH,,*/


void Free_PERIODARRAY(PERIODARRAY v)
{
    SCecon_free((VOIDPTR) v) ;
}


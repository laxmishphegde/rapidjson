/* SCID @(#)payments.c	1.18 (SimCorp) 99/10/29 13:39:19 */

/************************************************************************
*
*   project     SCecon
*
*   filename    payments.c
*
*   general     This file contains standard cash flow routines of
*               SCecon Library
*
************************************************************************/

/* includes ************************************************************/
#include <pmt.h>

/* defines  ************************************************************/
#define RATE_TOL 0.000001

/*,,SOH,,
*************************************************************************
*
*               Cflw_MonthsBetweenPayments()
*
*   interface   #include <pmt.h>
*               INTI Cflw_MonthsBetweenPayments(PMTFREQ freq) ;
*
*   general     The function calculates the number of months between
*               between regular payments based on the code for payment
*               payment frequency.
*
*               If freq is NO_FREQUENCY then 0 is returned, implying
*               that no regularity is to be found.
*
*               The function is used when laying out cashflows and when
*               generating accrued interest/coupons.
*
*   input       PMTFREQ   freq    Code for interval between payments
*
*   output
*
*   returns     the number of months between payments.
*
*   diagnostics
*
*   see also    Cflw_Paydays()
*               Cflw_Months2PmtFreq()
*               Cflw_PaydaysCount()
*               Cldr_DaysPerYear()
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/

INTI Cflw_MonthsBetweenPayments(PMTFREQ freq)
{
    return TVMunit_Months_Between_Payments(freq)  ;
}


/*,,SOH,,
*************************************************************************
*
*               Cflw_Months2PmtFreq()
*
*   interface   #include <pmt.h>
*               PMTFREQ Cflw_Months2PmtFreq(INTI m) ;
*
*   general     The function calculates the payment frequency implied
*               by the number of months in m.
*
*   input       INTI      m       Number of months between payments
*
*   output
*
*   returns     the payment frequency as PMTFREQ.
*
*   diagnostics
*
*   see also    Cflw_Paydays()
*               Cflw_PaydaysCount()
*               Cldr_DaysPerYear()
*               Cflw_MonthsBetweenPayments()
*
*************************************************************************
,,EOH,,*/


PMTFREQ Cflw_Months2PmtFreq(INTI m)
{
    PMTFREQ freq ;

    switch (m)
    {
        case 36:
            freq = TRIANNUALLY ;
            break ;
        case 24:
            freq = BIANNUALLY ;
            break ;
        case 12:
            freq = ANNUALLY ;
            break ;
        case 6:
            freq = SEMIANNUALLY ;
            break ;
        case 4:
            freq = FOURTHMONTHLY ;
            break ;
        case 3:
            freq = QUARTERLY ;
            break ;
        case 2:
            freq = BIMONTHLY ;
            break ;
        case 1:
            freq = MONTHLY ;
            break ;
        default:
            freq = NO_FREQUENCY ;
            break ;
    }
    return freq ;
}



/*,,SOH,,
*************************************************************************
*
*               Cflw_Annuity()
*
*    interface  #include <pmt.h>
*
*               FL64 Cflw_Annuity(FL64  pr,
*                                 INTI  n,
*                                 BOOLE prepaid) ;
*
*    general    Cflw_Annuity() calculates the annuity payment for a
*               straight annuity loan.
*
*               With period rate c and n number of payments the annuity
*               payment for a standard annuity loan is given as:
*                   
*                           c/(1-(1+c)^{-n})
*
*               For a prepaid annuity loan the annuity payment is
*               given as:
*
*                           c/(1-(1-c)^{n})               
*
*    input      FL64    pr          The nominal periodic interest rate
*                                   in percent.
*
*               INTI    n           The number of future payments from
*                                   the loan.
*                                   Must be a positive number.
*
*               BOOLE   prepaid     If prepaid is True the coupons are
*                                   paid at the start of the coupon
*                                   calculation periods.
*                                   If prepaid is False coupons are
*                                   paid in arrears.
*    output
*
*    returns    the annuity payment as FL64.
*
*    diagnostics
*
*    see also
*
*************************************************************************
,,EOH,,*/

FL64 Cflw_Annuity(FL64 pr, INTI  n, BOOLE  prepaid)
{
    if (SCecon_fabs(pr) < RATE_TOL)
        return 100.0/(FL64) n ;
    else if (prepaid)
    {
        /* periodic interest exceeding 100%, makes negative
           amortisations required. This is not supported. */
        if (pr >= 100.0)
            return 0.0;

        return pr / (1.0 - pow(1.0 - pr/100.0, (FL64) n)) ;
    }
    else
        return pr / (1.0 - pow(1.0 + pr/100.0 , (FL64) -n)) ;
}


/*
*************************************************************************
*
*               Cflw_Bondtype2Payments()
*
*   interface   #include <pmt.h>
*
*               void Cflw_Bondtype2Payments(FL64      prate,
*                                           INTI      n,
*                                           BONDTYPE  type,
*                                           BOOLE     ppann,
*                                           FL64ARRAY repay,
*                                           FL64ARRAY coupon) ;
*
*   general     Cflw_Bondtype2Payments() calculates payments for various
*               standard bonds. The repayment scheme is fed back
*               via the arrays repay and coupon.
*
*               For annuity loans it is possible to specify varying
*               period rates. Generating prepaid annuities is also an
*               option.
*
*   input       FL64      prate         Constant periodic coupon rate in 
*                                       percent. Can be zero. 
*                                       For annuities prate is only used 
*                                       if prates is NULL.
*
*               FL64ARRAY prates        Varying periodic coupon rates in 
*                                       percent used for annuities.
*                                       Use NULL to use the constant period
*                                       rate prate.
*                                       Allocated as Alloc_FL64ARRAY(n).
*                                   
*               INTI      n             Number of payments of the loan.
*
*               BONDTYPE  type          The bondtype. Must be one of
*
*                                               BULLET
*                                               SERIAL
*                                               ANNUITY
*                                               ANNUITY_PREP
*
*               BOOLE     ppann         If ppann is True the
*                                       amortisations are calculated as
*                                       if the coupons are paid at the
*                                       start of the coupon calculation
*                                       periods.
*                                       This only makes a difference for
*                                       annuity loans.
*
*   output      FL64ARRAY  repay        Array of repayments.
*                                       Must be preallocated with n
*                                       entries.
*                                       The repayments sums to 100.
*
*               FL64ARRAY  coupon       Array of coupon payments.
*                                       Must be preallocated with n
*                                       entries.
*                                       The coupons are in percent of
*                                       the nominal outstanding.
*
*   returns
*
*   diagnostics
*
*   see also    Cflw_GenrCflw()
*
*************************************************************************
*/


void Cflw_Bondtype2Payments(FL64       prate,
                            FL64ARRAY  prates,
                            INTI       n,
                            BONDTYPE   type,
                            BOOLE      ppann,
                            FL64ARRAY  repay,
                            FL64ARRAY  coupon)
{
    switch (type)
    {
        /* ppann omly makes a difference for annuities. */ 

        case SERIAL:
            cflw_payments_serial(prate, n, repay, coupon) ;
            break ;
        case ANNUITY:
        case ANNUITY_PREP:
            cflw_payments_annuity(prate, prates, n, ppann, repay, coupon) ;
            break ;
        case BULLET:
        default:
            cflw_payments_bullet(prate, n, repay, coupon) ;
            break ;

    }
}


/************************************************************************
*
*               cflw_payments_bullet()
*
*   interface   #include <pmt.h>
*
*               void cflw_payments_bullet(FL64      prate,
*                                         INTI      n,
*                                         FL64ARRAY repay,
*                                         FL64ARRAY coupon) ;
*
*   general     cflw_payments_bullet() calculates payments for a
*               straight bullet loan. The repayment scheme is fed
*               back via the arrays repay and coupon.
*
*   input       FL64      prate         Periodic coupon rate in percent.
*
*               INTI      n             Number of payments from the
*                                       bond.
*
*   output      FL64ARRAY  repay        Array of repayments.
*                                       Must be preallocated using
*                                       Alloc_FL64ARRAY().
*                                       The repayments sums to 100.
*
*               FL64ARRAY  coupon       Array of coupon payments.
*                                       Must be preallocated using
*                                       Alloc_FL64ARRAY().
*                                       The coupons are in percent of
*                                       the nominal outstanding.
*
*   returns
*
*   diagnostics
*
*   see also    cflw_payments_annuity()
*
************************************************************************/


void cflw_payments_bullet(FL64       prate,
                          INTI       n,
                          FL64ARRAY  repay,
                          FL64ARRAY  coupon)
{
    INTI  i;

    if (n <= 0)
      return ;

    for (i = 0 ; i < n ; i++)
    {
        repay[i]  = 0.0;
        coupon[i] = prate;
    }

    repay[n - 1] = 100.0;
}


/************************************************************************
*
*               cflw_payments_serial()
*
*   interface   #include <pmt.h>
*
*               void cflw_payments_serial(FL64    prate,
*                                         INTI  n,
*                                         FL64ARRAY repay, 
*                                         FL64ARRAY coupon);
*
*   general     cflw_payments_serial() calculates payments for a
*               straight serial loan. The repayment scheme is fed back
*               via the arrays repay and coupon.
*
*   input       FL64      prate         Periodic coupon rate in percent.*
*                                       Can be zero.
*               INTI      n             Number of payments from the
*                                       bond (positive number)
*
*   output      FL64ARRAY  repay        Array of repayments
*                                       allocated with Alloc_FL64ARRAY()
*                                       prior to calling this function.
*                                       The repayments sums to 100.
*               FL64ARRAY  coupon       Array of coupon payments
*                                       allocated with Alloc_FL64ARRAY()
*                                       prior to calling this function.
*                                       The coupons are in percent of
*                                       the nominal outstanding.
*
*   returns
*
*   diagnostics
*
*   see also    cflw_payments_annuity(),
*               cflw_payments_bullet()
*
************************************************************************/


void cflw_payments_serial(FL64      prate,
                          INTI      n,
                          FL64ARRAY repay,
                          FL64ARRAY coupon)
{
    FL64    debt, amount ;
    INTI    i;

    if (n <= 0)
      return ;

    debt = 100.0 ;
    amount = 100.0/(FL64) n ;

    for (i = 0 ; i < n ; i++)
    {
        repay[i]  = amount ;
        coupon[i] = debt*prate/100.0;
        debt     -= repay[i];
    }
}


/************************************************************************
*
*               cflw_payments_annuity()
*
*   interface   #include <pmt.h>
*
*               void cflw_payments_annuity(FL64      prate,
*                                          FL64ARRAY prates,
*                                          INTI      n,
*                                          BOOLE     ppan,
*                                          FL64ARRAY repay,
*                                          FL64ARRAY coupon);
*
*   general     cflw_payments_annuity() calculates payments for both
*               regular and prepaid annuity loans. The coupon rate
*               for each period may be entered both as a single constant
*               rate or as a time-varying list. The former may for instance
*               be used for EU30E360-based loan while the latter is relevant
*               for ACTACT-based loans.
*
*               The formulas used are described below:
*               p  : the (constant) annuity payment.
*               r_i: i'th repayment (output).
*               c_i: i'th coupon payment (output).
*                    p = c_i + r_i.
*               d_i: outstanding debt prior to the i'th payment, 
*                    d_1 = initial debt, d_i = d_{i-1} - r_{i-1}.
*               C_i: i'th period coupon rates in % (input).
*                    C_i = coupon/m for simple annuity with m payments
*                    per year.
*                    standard (arrears) c_i = C_i*d_i.
*                    prepaid (advance) c_i = C_{i+1}*d_{i+1}.
*
*               Standard:
*
*               p = d_1 / sum_{i=1}^n prod_{j=1}^i 1/(1+C_i)
*                 If C_i is constant p = d_1 * c / (1 - (1+C)^-n)
*
*               Repayment and coupons computed from i=1 to n as:
*               c_i = C_i*d_i with d_1 = 100.
*               r_i = p - c_i.
*
*               Prepaid:
*
*               p = d_1 / sum_{i=1}^n prod_{j=1}^{i-1} (1-C_i)
*                 If C_i is constant p = d_1 * c / (1 - (1-C)^n)
*
*               Repayment and coupons computed from i=n to 1 as:
*               c_i = C_{i+1}*d_{i+1} with d_{n+1}=0
*               r_i = p - c_i.
*
*               Formulas can be proven by induction on n.
*
*   input       FL64      prate     Constant periodic coupon rate in 
*                                   percent. Can be zero. Only used 
*                                   if prates is NULL.
*
*               FL64ARRAY prates    Varying periodic coupon rates in percent.
*                                   Use NULL to use the constant period
*                                   rate prate.
*                                   Allocated as Alloc_FL64ARRAY(n).
*                                   
*               INTI      n         Number of payments of the loan.
*                                   
*               BOOLE     ppann     If ppann is True the
*                                   amortisations are calculated as
*                                   if the coupons are paid at the
*                                   start of the coupon calculation
*                                   periods. 
*
*   output      FL64ARRAY  repay    Array of repayments
*                                   allocated as Alloc_FL64ARRAY(n)
*                                   prior to calling this function.
*                                   The repayments sums to 100.
*
*               FL64ARRAY  coupon   Array of coupon payments
*                                   allocated as Alloc_FL64ARRAY(n)
*                                   prior to calling this function.
*                                   The coupons are in percent of
*                                   the nominal outstanding.
*
*   returns
*
*   diagnostics
*
*   see also    cflw_payments_bullet(),
*               cflw_payments_serial()
*
************************************************************************/


void cflw_payments_annuity(FL64       prate,
                           FL64ARRAY  prates,
                           INTI       n,
                           BOOLE      ppann,
                           FL64ARRAY  repay,
                           FL64ARRAY  coupon)
{
  INTI      i ;
  FL64      payment, debt ;
  BOOLE     equalrates ;

  if (n <= 0)
    return ;

    /* Check if all period rates are equal. */
  equalrates = True ;
  if (prates != NULL)
    for (i = 1, prate = prates[0]; i < n && equalrates ; i++)
      equalrates = fabs(prate - prates[i]) < RATE_TOL ;

    /* Standard (arrears) case. */
  if (!ppann)
  {
      /* Constant period rate. */
    if (equalrates)
    {
        /* Compute annuity payment. */
      payment = Cflw_Annuity(prate, n, False) ;

        /* Compute payments. */
      debt = 100.0 ;
      prate *= 0.01 ; 
      for (i = 0 ; i < n ; i++)
      {
        coupon[i] = debt * prate ;
        repay[i] = payment - coupon[i] ;
        debt -= repay[i] ;
      }
    }
      /* Varying period rates. */
    else 
    {
        /* Compute annuity payment. */
      payment = 0.0 ;
      for (i = n - 1; i >= 0; i--)
        payment = 1.0 / (1.0 + GETMAX(prates[i], -100.0 + RATE_TOL) * 0.01) * 
          (1.0 + payment) ;
      payment = SafeDivide(100.0, payment, RATE_TOL, 0.0) ;

        /* Compute payments. */
      debt = 100.0 ;
      for (i = 0 ; i < n ; i++)
      {
        coupon[i] = debt * prates[i] * 0.01 ;
        repay[i] = payment - coupon[i] ;
        debt -= repay[i] ;
      }
    }
  }
    /* Prepaid (advance) case. */
  else 
  {
      /* Constant period rate. */
    if (equalrates)
    {
      /* Compute annuity payment. */
      payment = Cflw_Annuity(prate, n, True) ;

        /* Compute payments starting backwards. */
      coupon[n - 1] = 0.0 ;
      repay[n - 1] = payment ;
      debt = payment ;
      prate *= 0.01 ;
      for (i = n - 2; i >= 0; i--)
      {
        coupon[i] = prate * debt ;
        repay[i] = payment - coupon[i] ;
        debt += repay[i] ;
      }
    }
      /* Varying period rates. */
      else
    {
      /* Compute annuity payment. */
      payment = 0.0 ;
      for (i = n - 1; i >= 1; i--)
        payment = (1.0 - prates[i] * 0.01) * (1.0 + payment) ;
      payment = 1.0 + payment ;
      payment = SafeDivide(100.0, payment, RATE_TOL, 0.0) ;

        /* Compute payments starting backwards. */
      coupon[n - 1] = 0.0 ;
      repay[n - 1] = payment ;
      debt = payment ;
      for (i = n - 2; i >= 0; i--)
      {
        coupon[i] = prates[i + 1] * debt * 0.01 ;
        repay[i] = payment - coupon[i] ;
        debt += repay[i] ;
      }
    }
  }
}


#undef RATE_TOL

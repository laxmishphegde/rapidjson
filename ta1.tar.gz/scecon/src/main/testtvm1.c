/* SCID @(#)testtvm1.c	1.3 (SimCorp) 99/02/19 14:17:09 */

/************************************************************************
*
*   project     SCecon
*
************************************************************************/

/*** includes ***********************************************************/
#include <string.h>
#include <scalloc.h>
#include <tvm.h>
#include <stdlib.h>
#include <str2conv.h>

/*** the routine *************************************************/


INTI tvmtest1(char* txa, FILE* in, FILE* out)
{
    char       txb[25], txc[25], txd[25], txpl[64] ;
    FL64       acc, fexp1, fexp2, fexp3, fres1, fres2, fres3, y1 ;
    FL64       time, debt, *grates, p1, oas ;
    INTI       n, n1, diff, qb, count, i ;
    RISKCONV   risk ;
    INTPOLCONV iconv ;
    PMT_STR    *pmt1 ;
    TS_STR     *tsstr ;
    IRRCONV    irr ;
    BOOLE      ok ;
    int        i1, i2, i3 ;

    acc = 0.00001 ;
    diff = -1 ;

    if (!strcmp(txa, "TVM_Yield2Price()"))
    {
        fscanf(in, "%lf %lf %lf %lf %s %d %lf %s %d %s", &fexp1, &fexp2,
               &fexp3, &y1, txc, &i1, &debt, txb, &i2, txpl);
        qb = (INTI) i1 ;
        count = (INTI) i2 ;

        risk = Str2RISKCONV(txc) ;
        irr  = Str2IRRCONV(txb) ;
        grates = Alloc_FL64ARRAY(count) ;
        pmt1 = Alloc_PMTARRAY(1, count);
        pmt1[0].count = count;
        for (i = 0 ; i < count ; i++)
            fscanf(in,"%lf %lf %lf", &pmt1[0].payment[i],
                                     &pmt1[0].term[i],
                                     &grates[i]) ;

        fres1 = TVM_Yield2Price(y1, risk, qb, debt, irr,
                                grates, pmt1, &fres2, &fres3);
        diff = (fabs(fexp1 - fres1) > acc || fabs(fexp2 - fres2) > acc ||
                fabs(fexp3 - fres3) > acc) ;

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   yield            %8.5lf\n", y1) ;
        fprintf(out,"   quoting basis    %8d\n", qb) ;
        fprintf(out,"   irr convention %s\n", txb) ;
        fprintf(out,"   risk %s\n", txc) ;
        fprintf(out,"   outstanding debt %8.5lf\n", debt) ;

        fprintf(out,"%d; p   = %10.5lf ; expected = %10.5lf\n",
                (fabs(fres1 - fexp1) > acc), fres1, fexp1);
        fprintf(out,"%d; dp  = %10.5lf ; expected = %10.5lf\n",
                (fabs(fres2 - fexp2) > acc), fres2, fexp2);
        fprintf(out,"%d; ddp = %10.5lf ; expected = %10.5lf\n",
                (fabs(fres3 - fexp3) > acc), fres3, fexp3);
        for (i = 0 ; i < count ; i++)
            fprintf(out, 
"   payment[%d] = %10.5lf, term[%d] = %10.5lf,  grate[%d] = %10.5lf\n",
              
                    i, pmt1[0].payment[i], i, pmt1[0].term[i], i, grates[i]);
        fprintf(out,"   %s\n\n", txpl) ;

        Free_PMTARRAY(pmt1, 1);
        Free_FL64ARRAY(grates) ;
    }

    else if (!strcmp(txa, "TVM_Yield2Theta()"))
    {
        fscanf(in, "%lf %lf %d %lf %s %lf %lf %d %s", &fexp1,
               &y1, &i1, &debt, txb, &p1, &time, &i2, txpl);
        qb = (INTI) i1 ;
        count = (INTI) i2 ;

        irr  = Str2IRRCONV(txb) ;
        grates = Alloc_FL64ARRAY(count) ;
        pmt1 = Alloc_PMTARRAY(1, count);
        pmt1[0].count = count;
        for (i = 0 ; i < count ; i++)
            fscanf(in,"%lf %lf %lf", &pmt1[0].payment[i],
                                     &pmt1[0].term[i],
                                     &grates[i]) ;

        fres1 = TVM_Yield2Theta(y1, qb, irr, grates, pmt1, debt, p1, time);
        diff = (fabs(fexp1 - fres1) > acc) ;

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   yield            %8.5lf\n", y1) ;
        fprintf(out,"   quoting basis    %8d\n", qb) ;
        fprintf(out,"   irr convention %s\n", txb) ;
        fprintf(out,"   outstanding debt %8.5lf\n", debt) ;
        fprintf(out,"   dirty price      %8.5lf\n", p1) ;
        fprintf(out,"   time passed      %8.5lf\n", time) ;

        fprintf(out,"%d; th  = %10.5lf ; expected = %10.5lf\n",
                (fabs(fres1 - fexp1) > acc), fres1, fexp1);
        for (i = 0 ; i < count ; i++)
            fprintf(out, 
"   payment[%d] = %10.5lf, term[%d] = %10.5lf,  grate[%d] = %10.5lf\n",
              
                    i, pmt1[0].payment[i], i, pmt1[0].term[i], i, grates[i]);
        fprintf(out,"   %s\n\n", txpl) ;

        Free_PMTARRAY(pmt1, 1);
        Free_FL64ARRAY(grates) ;
    }

    else if (!strcmp(txa, "TVM_Zero2Price()"))
    {
        fscanf(in, "%lf %lf %lf %s %s %d %lf %lf %d %d %s %s", &fexp1, &fexp2,
               &fexp3, txd, txc, &i1, &debt, &oas, &i2, &i3, txb, txpl);
        qb = (INTI) i1 ;
        count = (INTI) i2 ;
        n = (INTI) i3 ;

        risk  = Str2RISKCONV(txc) ;
        iconv = Str2INTPOLCONV(txb) ;
        irr   = Str2IRRCONV(txd) ;
        pmt1    = Alloc_PMTARRAY(1, count);
        tsstr   = Alloc_TSARRAY(1, n);
        pmt1[0].count  = count ;
        tsstr[0].count = n ;
        tsstr[0].conv = irr ;
        tsstr[0].qbas = qb ;
        for (i = 0 ; i < count ; i++)
            fscanf(in,"%lf %lf", &pmt1[0].payment[i],
                                 &pmt1[0].term[i]) ;

        for (i = 0 ; i < n ; i++)
            fscanf(in,"%lf %lf %lf", &tsstr[0].term[i],
                                     &tsstr[0].rate[i],
                                     &tsstr[0].loading[i]) ;
        fres1 = TVM_Zero2Price(tsstr, risk, debt, oas, iconv,
                               pmt1, &fres2, &fres3) ;
        diff = (fabs(fexp1 - fres1) > acc || fabs(fexp2 - fres2) > acc ||
                fabs(fexp3 - fres3) > acc) ;

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   irr convention %s\n", txd) ;
        fprintf(out,"   quoting basis    %8d\n", qb) ;
        fprintf(out,"   oas              %8.5lf\n", oas) ;
        fprintf(out,"   risk %s\n", txc) ;
        fprintf(out,"   interpolation %s\n", txb) ;
        fprintf(out,"   outstanding debt %8.5lf\n", debt) ;

        fprintf(out,"%d; p   = %10.5lf; expected = %10.5lf\n",
                (fabs(fres1 - fexp1) > acc), fres1, fexp1);
        fprintf(out,"%d; dp  = %10.5lf; expected = %10.5lf\n",
                (fabs(fres2 - fexp2) > acc), fres2, fexp2);
        fprintf(out,"%d; ddp = %10.5lf; expected = %10.5lf\n",
                (fabs(fres3 - fexp3) > acc), fres3, fexp3);
        for (i = 0 ; i < count ; i++)
            fprintf(out, "   payment[%d] = %10.5lf, term[%d] = %10.5lf\n",
                    i, pmt1[0].payment[i], i, pmt1[0].term[i]) ;

        for (i = 0 ; i < n ; i++)
            fprintf(out, 
"   term[%d] = %10.5lf  rates[%d] = %10.5lf  loadings[%d] = %10.5lf\n",
              
                    i, tsstr[0].term[i], i, tsstr[0].rate[i],
                    i, tsstr[0].loading[i]) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_PMTARRAY(pmt1, 1) ;
        Free_TSARRAY(tsstr, 1) ;
    }

    else if (!strcmp(txa, "TVM_Zero2Theta()"))
    {
        fscanf(in, "%lf %s %d %lf %lf %d %d %s %lf %lf %s", &fexp1,
               txd, &i1, &debt, &oas, &i2, &i3, txb, &p1, &time, txpl);

        qb = (INTI) i1 ;
        count = (INTI) i2 ;
        n = (INTI) i3 ;

        iconv = Str2INTPOLCONV(txb) ;
        irr   = Str2IRRCONV(txd) ;
        pmt1    = Alloc_PMTARRAY(1, count);
        tsstr   = Alloc_TSARRAY(1, n);
        pmt1[0].count  = count ;
        tsstr[0].count = n ;
        tsstr[0].conv  = irr ;
        tsstr[0].qbas  = qb ;
        for (i = 0 ; i < count ; i++)
            fscanf(in,"%lf %lf", &pmt1[0].payment[i],
                                 &pmt1[0].term[i]) ;

        for (i = 0 ; i < n ; i++)
            fscanf(in,"%lf %lf %lf", &tsstr[0].term[i],
                                     &tsstr[0].rate[i],
                                     &tsstr[0].loading[i]) ;
        fres1 = TVM_Zero2Theta(tsstr, oas, iconv, pmt1, debt, p1, time) ;
        diff = (fabs(fexp1 - fres1) > acc) ;

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   irr convention %s\n", txd) ;
        fprintf(out,"   quoting basis    %8d\n", qb) ;
        fprintf(out,"   oas              %8.5lf\n", oas) ;
        fprintf(out,"   interpolation %s\n", txb) ;
        fprintf(out,"   outstanding debt %8.5lf\n", debt) ;
        fprintf(out,"   dirty price      %8.5lf\n", p1) ;
        fprintf(out,"   time passed      %8.5lf\n", time) ;

        fprintf(out,"%d; th  = %10.5lf; expected = %10.5lf\n",
                (fabs(fres1 - fexp1) > acc), fres1, fexp1);
        for (i = 0 ; i < count ; i++)
            fprintf(out, "   payment[%d] = %10.5lf, term[%d] = %10.5lf\n",
                    i, pmt1[0].payment[i], i, pmt1[0].term[i]) ;

        for (i = 0 ; i < n ; i++)
            fprintf(out, 
"   term[%d] = %10.5lf  rates[%d] = %10.5lf  loadings[%d] = %10.5lf\n",
              
                    i, tsstr[0].term[i], i, tsstr[0].rate[i],
                    i, tsstr[0].loading[i]) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_PMTARRAY(pmt1, 1) ;
        Free_TSARRAY(tsstr, 1) ;
    }

    else if (!strcmp(txa, "TVM_Zero2Spread()"))
    {
        fscanf(in, "%lf %s %d %lf %d %d %s %lf %lf %s", &fexp1,
               txd, &i1, &debt, &i2, &i3, txb, &p1, &y1, txpl);
        qb = (INTI) i1 ;
        count = (INTI) i2 ;
        n = (INTI) i3 ;

        iconv = Str2INTPOLCONV(txb) ;
        irr   = Str2IRRCONV(txd) ;
        pmt1    = Alloc_PMTARRAY(1, count);
        tsstr   = Alloc_TSARRAY(1, n);
        pmt1[0].count  = count ;
        tsstr[0].count = n ;
        tsstr[0].conv = irr ;
        tsstr[0].qbas = qb ;
        for (i = 0 ; i < count ; i++)
            fscanf(in,"%lf %lf", &pmt1[0].payment[i],
                                 &pmt1[0].term[i]) ;

        for (i = 0 ; i < n ; i++)
            fscanf(in,"%lf %lf %lf", &tsstr[0].term[i],
                                     &tsstr[0].rate[i],
                                     &tsstr[0].loading[i]) ;
        ok = TVM_Zero2Spread(tsstr, debt, iconv, pmt1, p1, y1, &fres1) ;
        diff = (fabs(fexp1 - fres1) > acc) ;

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   irr convention %s\n", txd) ;
        fprintf(out,"   quoting basis    %8d\n", qb) ;
        fprintf(out,"   dirty price     %8.5lf\n", p1) ;
        fprintf(out,"   guess (oas)     %8.5lf\n", y1) ;
        fprintf(out,"   interpolation %s\n", txb) ;
        fprintf(out,"   outstanding debt %8.5lf\n", debt) ;
        fprintf(out,"   error code    %8d\n", ok) ;

        fprintf(out,"%d; oas = %10.5lf; expected = %10.5lf\n",
                (fabs(fres1 - fexp1) > acc), fres1, fexp1);
        for (i = 0 ; i < count ; i++)
            fprintf(out, "   payment[%d] = %10.5lf, term[%d] = %10.5lf\n",
                    i, pmt1[0].payment[i], i, pmt1[0].term[i]) ;

        for (i = 0 ; i < n ; i++)
            fprintf(out, 
"   term[%d] = %10.5lf  rates[%d] = %10.5lf  loadings[%d] = %10.5lf\n",
              
                    i, tsstr[0].term[i], i, tsstr[0].rate[i],
                    i, tsstr[0].loading[i]) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_PMTARRAY(pmt1, 1) ;
        Free_TSARRAY(tsstr, 1) ;
    }

    else if (!strcmp(txa, "TVM_Price2Yield()"))
    {
        fscanf(in, "%lf %lf %d %s %lf %d %s",
               &fexp1, &p1, &i1, txb, &debt, &i2, txpl);
        qb = (INTI) i1 ;
        n1 = (INTI) i2 ;
        irr = Str2IRRCONV(txb) ;
        grates = Alloc_FL64ARRAY(n1) ;
        pmt1 = Alloc_PMTARRAY(1, n1);
        pmt1[0].count = n1;

        for (i = 0 ; i < n1 ; i++)
            fscanf(in,"%lf %lf %lf", &pmt1[0].payment[i],
                                     &pmt1[0].term[i],
                                     &grates[i]) ;

        ok = TVM_Price2Yield(p1, qb, irr, grates, debt, pmt1, 1.0E-10, &fres1) ;
        diff = (fabs(fexp1 - fres1) > acc) ;

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   dirty price      %8.5lf\n", p1) ;
        fprintf(out,"   irr convention %s\n", txb) ;
        fprintf(out,"   quoting basis    %8d\n", qb) ;
        fprintf(out,"   outstanding debt %8.5lf\n", debt) ;
        fprintf(out,"   error code       %8d\n", ok) ;
        fprintf(out,
          "   result is %8.5lf ; expected is %8.5lf\n",
          fres1, fexp1) ;

        for (i = 0 ; i < n1 ; i++)
            fprintf(out,
"   payments[%3d] = %10.5lf, term[%3d] = %10.5lf, grates[%d] = %10.5lf\n",
              
                    i, pmt1[0].payment[i], i, pmt1[0].term[i], i, grates[i]);
        fprintf(out,"   %s\n\n", txpl) ;

        Free_FL64ARRAY(grates) ;
        Free_PMTARRAY(pmt1, 1);
    }

    return diff ;
}

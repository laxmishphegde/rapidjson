#include <sccsid.h>
SCCSID(regress_c,
  "@(#)regress.c	1.12 (SimCorp) 99/10/01 14:47:57")

/************************************************************************
*
*   project     SCecon
*
*   file name   regress.c
*
*   general     This file contains functions for making least-squares
*               fitting using non-linear functions
*
************************************************************************/


/***** includes  *******************************************************/
#include <regress.h>
#include <assert.h>

/*,,SIC,,
*************************************************************************
*
*               Stat_LeastSquaresRegress()
*
*   xinterface   #include <regress.h>
*               void Stat_LeastSquaresRegress(FL64MATRIX  x,
*                                             FL64ARRAY   y,
*                                             BOOLEARRAY  exclude,
*                                             INTI        nobs,
*                                             INTI        nfac,
*                                             FUNCBASE    fbase,
*                                             INTI        pow,
*                                             INTI        ncoef,
*                                             FL64ARRAY   coefs,
*                                             FL64        chisqacc,
*                                             INTI        maxiter,
*                                             FL64*       chisq,
*                                             INTI*       iter);
*
*   xgeneral     Calculates coefficients for best fit using least squares
*               regression for a given function base.
*
*   xinput      FL64ARRAY  x            Value of underlying variables for
*                                       all observations [nobs, nfac].
*
*               FL64ARRAY  y            Function value for all observations
*                                       [nobs].
*
*               BOOLEARRAY exclude      Indicating to include (False)
*                                       or exclude (True) each observation.
*                                       [nobs]
*               
*               INTI       nobs         Number of observations.
*
*               INTI       nfac         Number of underlying variables.
*
*               FUNCBASE   fbase        Class of base functions.
*
*               INTI       pow          Power/order of function base.
*
*               INTI       ncoef        Number of coefficients.
*
*               FL64ARRAY  coefs        Coefficients [ncoef].
*
*               FL64       chisqacc     Minimum accuracy of chi-squared.
*
*               INTI       maxiter      Maximum number of iterations.
*
*   xoutput     FL64*      chisq        Chi-squared.
*
*               INTI*      iter         Actual number of iterations.
*
*   xreturns     void.
*
*   xdiagnostics
*
*   xsee also    Stat_FuncVal
*               Stat_CoefNo
*
*************************************************************************
,,EIC,,*/
void Stat_LeastSquaresRegress(FL64MATRIX  x,
                              FL64ARRAY   y,
                              BOOLEARRAY  exclude,
                              INTI        nobs,
                              INTI        nfac,
                              FUNCBASE    fbase,
                              INTI        pow,
                              INTI        ncoef,
                              FL64ARRAY   coefs,
                              FL64        chisqacc,
                              INTI        maxiter,
                              FL64*       chisq,
                              INTI*       iter)
{
  void (*bfunc)(FL64ARRAY, INTI, INTI, FL64ARRAY, FL64 *, FL64ARRAY, INTI);
  FL64MATRIX  covar;
  FL64MATRIX  alpha;
  FL64        alambda;
  FL64        oldchisq;
  INTI        i;
  BOOLE       convergence;

  i = 0;

  switch (fbase)
  {
  case POWER:
    /* Assumption: nfac == 1 */
    bfunc = &basefunc_power;
    break;
  case MULTIPOWER:
    /* The "multipower" function is slow but general.
       It should therefore only be used for research. */
    bfunc = &basefunc_multipower;
    break;
  default:
    *chisq = -1;
    return;
  }
  covar = Alloc_FL64MATRIX(ncoef, ncoef);
  alpha = Alloc_FL64MATRIX(ncoef, ncoef);
  alambda = -1.0; /* A value less than zero triggers default value. */
  *iter = 0;
  *chisq = 0.0;
  convergence = False;
  do
  {
    oldchisq = *chisq;
    mrqmin(x, y, exclude, nobs, nfac, pow, coefs, ncoef, covar, alpha, 
        chisq, bfunc, &alambda);
    (*iter)++;

    /* Convergence is assumed only if chisq has been reduced, but not
       by more than a relative precentage of chisqacc.*/
    convergence = (oldchisq >= *chisq && oldchisq / *chisq - 1 < chisqacc);
  }
  while (*iter < maxiter && !convergence);

  alambda = 0.0;
  mrqmin(x, y, exclude, nobs, nfac, pow, coefs, ncoef, covar, alpha, 
      chisq, bfunc, &alambda);

/*
  for (i = 0; i < ncoef; i++)
    if (fabs(coefs[i]) / sqrt(covar[i][i] / nobs) < 2.0)
      printf("%d/%d: coef=%lf is insignificant!\n", i, ncoef, coefs[i]);
*/

  Free_FL64MATRIX(covar);
  Free_FL64MATRIX(alpha);
}


/*,,SIC,,
*************************************************************************
*
*               Stat_FuncVal()
*
*   xinterface   #include <regress.h>
*               FL64 Stat_FuncVal(FL64ARRAY   x,
*                                 INTI        nfac,
*                                 FUNCBASE    fbase,
*                                 INTI        pow,
*                                 INTI        ncoef,
*                                 FL64ARRAY   coefs);
*
*   xgeneral     Calculates the function value of a set of base functions
*               given coefficients and values of x.
*
*   xinput       FL64ARRAY  x            Value of underlying variables [nfac].
*
*               INTI       nfac         Number of underlying variables.
*
*               FUNCBASE   fbase        Class of functions to be valued.
*
*               INTI       pow          Power/order of function base.
*
*               INTI       ncoef        Number of coefficients.
*
*               FL64ARRAY  coefs        Coefficients [ncoef].
*
*   xoutput      
*
*   xreturns     Function value.
*
*   xdiagnostics
*
*   xsee also    Stat_LeastSquaresRegress
*               Stat_CoefNo
*
*************************************************************************
,,EIC,,*/
FL64 Stat_FuncVal(FL64ARRAY   x,
                  INTI        nfac,
                  FUNCBASE    fbase,
                  INTI        pow,
                  INTI        ncoef,
                  FL64ARRAY   coefs)
{
  FL64  y;

  switch (fbase)
  {
  case POWER:
    basefunc_power(x, nfac, pow, coefs, &y, NULL, ncoef);
    break;
  case MULTIPOWER:
    basefunc_multipower(x, nfac, pow, coefs, &y, NULL, ncoef);
    break;
  default:
    y = 0;
  }
  return y;
}

/*,,SIC,,
*************************************************************************
*
*               Stat_CoefNo()
*
*   xinterface   #include <regress.h>
*               INTI Stat_CoefNo(FUNCBASE  fbase,
*                                INTI      nfac,
*                                INTI      pow);
*
*   xgeneral     Calculates the number of coefficients needed for a given
*               function base and a number of underlying variables.
*                
*
*   xinput       FUNCBASE   fbase        Class of base functions.
*
*               INTI       nfac         Number of underlying variables.
*
*               INTI       pow          Power/order of function base.
*
*   xoutput      
*
*   xreturns     Number of coefficients for function base.
*
*   xdiagnostics
*
*   xsee also    Stat_LeastSquaresRegress
*               Stat_FuncVal
*
*************************************************************************
,,EIC,,*/
extern INTI Stat_CoefNo(FUNCBASE  fbase,
                        INTI      nfac,
                        INTI      pow)
{
  switch (fbase)
  {
  case POWER:
    return pow + 1;
  case MULTIPOWER:
    return PascalsTriangle(nfac + pow, GETMIN(nfac, pow));
  default:
    return 0;
  }
}

/******** Private functions **********/

#define SWAP(a,b) {temp=(a);(a)=(b);(b)=temp;}

/* Numerical Recipes in C, 2nd Edition, Chapter 15.5 (software version 2.08). */
/* The functions has been simplified and changed to base 0 array indexing */

/* Levenberg-Marquardt method, attempting to reduce the value chi-squared of
a fit between a set of data points x[0..nobs-1][], y[0..nobs-1], and a nonlinear
function dependent on ma coefficients a[0..ma-1].
The array exclude[0..nobs-1] determines which observations are actually
included in the regression.
The program returns current best-fit values for the parameters a[0..ma-1].
The arrays covar[0..ma-1][0..ma-1], alpha[0..ma-1][0..ma-1] are used as working
space during most iterations. Supply a routine funcs(x,a,yfit,dyda,ma) that
evaluates the fitting function yfit, and its derivatives dyda[1..ma] with
respect to the fitting parameters a at x. On the first call provide an initial
guess for the parameters a, and set alamda<0 for initialization (which then
sets alamda=.001). If a step succeeds chisq becomes smaller and alamda decreases
by a factor of 10. If a step fails alamda grows by a factor of 10. You must
call this routine repeatedly until convergence is achieved. Then, make one
final call with alamda=0, so that covar[0..ma-1][0..ma-1] returns the covariance
matrix, and alpha the curvature matrix. (Parameters held fixed will return
zero covariances.) */
void mrqmin(FL64MATRIX  x,
            FL64ARRAY   y,
            BOOLEARRAY  exclude,
            INTI        nobs,
            INTI        nfac,
            INTI        pow,
            FL64ARRAY   a,
            INTI        ma,
            FL64**      covar,
            FL64**      alpha,
            FL64*       chisq,
            void        (*funcs)(FL64ARRAY, INTI, INTI, FL64ARRAY, FL64 *,
                            FL64ARRAY, INTI),
            FL64*       alamda)
{
  INTI j, k, l;
  static FL64 ochisq, *atry, *beta, *da, **oneda;

  if (*alamda < 0.0) 
  {
    /* Initialization. */
    atry    = Alloc_FL64ARRAY(ma);
    beta    = Alloc_FL64ARRAY(ma);
    da      = Alloc_FL64ARRAY(ma);
    oneda   = Alloc_FL64MATRIX(ma ,1);
    *alamda = 0.001;
    mrqcof(x, y, exclude, nobs, nfac, pow, a, ma, alpha, beta, chisq, funcs);

    ochisq=(*chisq);
    for (j = 0; j < ma; j++) 
      atry[j] = a[j];
  }

  /* Alter linearized fitting matrix, by augmenting diagonal elements. */
  for (j = 0; j < ma; j++)
  {
    for (k = 0; k < ma; k++)
      covar[j][k] = alpha[j][k];
    covar[j][j] = alpha[j][j] * (1.0 + (*alamda));
    oneda[j][0] = beta[j];
  }

  gaussj(covar, ma, oneda, 1); /* Matrix solution. */

  for (j = 0; j < ma; j++)
    da[j] = oneda[j][0];

  /* Once converged, evaluate covariance matrix. */
  if (*alamda == 0.0) 
  { 
    Free_FL64MATRIX(oneda);
    Free_FL64ARRAY(da);
    Free_FL64ARRAY(beta);
    Free_FL64ARRAY(atry);
    return;
  
  }
  for (l = 0; l < ma; l++) /* Did the trial succeed? */
    atry[l] = a[l] + da[l];

  mrqcof(x, y, exclude, nobs, nfac, pow, atry, ma, covar, da, chisq, funcs);
  if (*chisq < ochisq) 
  { 
    /* Success, accept the new solution. */
    *alamda *= 0.1;
    ochisq = (*chisq);
    for (j = 0; j < ma; j++)
    {
      for (k = 0; k < ma; k++)
        alpha[j][k] = covar[j][k];
      beta[j] = da[j];
    }
    for (l = 0; l < ma; l++)
      a[l] = atry[l];
  }
  else
  { 
    /* Failure, increase alamda and return. */
    *alamda *= 10.0;
    *chisq = ochisq;
  }
}

/* Used by mrqmin to evaluate the linearized fitting matrix alpha, and vector
   beta as in (15.5.8), and calculate chi-squared. */
void mrqcof(FL64MATRIX  x,
            FL64ARRAY   y,
            BOOLEARRAY  exclude,
            INTI        nobs,
            INTI        nfac,
            INTI        pow,
            FL64ARRAY   a,
            INTI        ma,
            FL64**      alpha,
            FL64ARRAY   beta,
            FL64*       chisq,
            void        (*funcs)(FL64ARRAY, INTI, INTI, FL64ARRAY, FL64 *,
                            FL64ARRAY, INTI))
{
  INTI i, j, k, l, m;
  FL64 ymod, wt, dy, *dyda;

  dyda = Alloc_FL64ARRAY(ma);

  for (j = 0; j < ma; j++) 
  { 
    /* Initialize (symmetric) alpha, beta. */
    for (k = 0; k <= j; k++)
      alpha[j][k] = 0.0;
    beta[j] = 0.0;
  }

  /* Summation loop over all data. */
  *chisq = 0.0;
  for (i = 0; i < nobs; i++) 
  { 
    if (exclude[i] == False)
    {
      (*funcs)(x[i], nfac, pow, a, &ymod, dyda, ma);
      dy = y[i] - ymod;
      for (l = 0; l < ma; l++)
      {
        wt = dyda[l];
        for (m = 0; m <= l;m++)
          alpha[l][m] += wt * dyda[m];
        beta[l] += dy*wt;
      }
      *chisq += dy * dy; /* And find chi-squared. */
    }
  }

  /* Fill in the symmetric side. */
  for (j = 1; j < ma; j++) 
    for (k = 0; k < j; k++)
      alpha[k][j] = alpha[j][k];

  Free_FL64ARRAY(dyda);
}


/* Numerical Recipes in C, 2nd Edition, Chapter 2.1 (software version 2.08). */
/* Linear equation solution by Gauss-Jordan elimination, equation (2.1.1) above.
a[0..n-1][0..n-1] is the input matrix. b[0..n-1][0..m-1] is input containing the
m right-hand side vectors. On output, a is replaced by its matrix inverse, and
b is replaced by the corresponding set of solution vectors. */
void gaussj(FL64 **a,
            INTI n,
            FL64 **b,
            INTI m)
{
  INTI *indxc, *indxr, *ipiv;
  INTI i, icol, irow, j, k, l, ll;
  FL64 big, dum, pivinv, temp;

  icol = irow = 0;

  /* The integer arrays ipiv, indxr, and indxc are
     used for bookkeeping on the pivoting. */
  indxc = Alloc_INTIARRAY(n); 
  indxr = Alloc_INTIARRAY(n);
  ipiv = Alloc_INTIARRAY(n);

  for (j = 0; j < n; j++)
    ipiv[j] = 0;

  /* This is the main loop over the columns to be reduced.*/
  for (i = 0; i < n; i++) 
  {
    big = 0.0;

    /* Outer loop of the search for a pivot element. */ 
    for (j = 0; j < n; j++) 
      if (ipiv[j] != 1)
        for (k = 0; k < n; k++) 
        {
          if (ipiv[k] == 0)
          {
            if (fabs(a[j][k]) >= big)
            {
              big = fabs(a[j][k]);
              irow = j;
              icol = k;
            }
          }
          else
            if (ipiv[k] > 1)
            {
              /* TBW: Error handling must be more delicate */
              SCecon_error("Couldn't find pivot element.\n"
                           "Possible multicollinearity.\n"
                           "Singular Matrix-1", "gaussj()", SCECONABORT);
            }
        }
    ++(ipiv[icol]);

    /* We now have the pivot element, so we interchange rows, if needed, to put
    the pivot element on the diagonal. The columns are not physically
    interchanged, only relabeled: indxc[i], the column of the ith pivot element,
    is the ith column that is reduced, while indxr[i] is the row in which that
    pivot element was originally located. If indxr[i] != indxc[i] there is an
    implied column interchange. With this form of bookkeeping, the solution
    b's will end up in the correct order, and the inverse matrix will be
    scrambled by columns. */
    if (irow != icol)
    {
      for (l = 0; l < n; l++)
        SWAP(a[irow][l], a[icol][l])
      for (l = 0; l < m; l++)
        SWAP(b[irow][l], b[icol][l])
    }

    /* We are now ready to divide the pivot row by the pivot 
       element, located at irow and icol.                   
    */ 
    indxr[i] = irow; 
    indxc[i] = icol; 
    if (a[icol][icol] == 0.0)
    {
      /* TBW: Error handling must be more delicate */
      SCecon_error("Pivot element is zero.\n"
                   "Possible multicollinearity.\n"
                   "Singular Matrix-2", "gaussj()", SCECONABORT);
    }

    pivinv = 1.0 / a[icol][icol];
    a[icol][icol] = 1.0;
    for (l = 0; l < n; l++)
      a[icol][l] *= pivinv;
    for (l = 0; l < m; l++)
      b[icol][l] *= pivinv;

    /* Next, we reduce the rows... */
    for (ll = 0; ll < n; ll++) 
      if (ll != icol) 
      { 
        /* ...except for the pivot one, of course. */
        dum = a[ll][icol];
        a[ll][icol] = 0.0;
        for (l = 0; l < n; l++)
          a[ll][l] -= a[icol][l]*dum;
        for (l = 0; l < m; l++)
          b[ll][l] -= b[icol][l]*dum;
      }
  }

  /* This is the end of the main loop over columns of the reduction. It only
  remains to unscramble the solution in view of the column interchanges.
  We do this by interchanging pairs of columns in the reverse order that the
  permutation was built up. */
  for (l = n-1; l >= 0; l--)
  {
    if (indxr[l] != indxc[l])
      for (k = 0; k < n; k++)
        SWAP(a[k][indxr[l]], a[k][indxc[l]]);
  } 
  /* And we are done. */

  Free_INTIARRAY(ipiv);
  Free_INTIARRAY(indxr);
  Free_INTIARRAY(indxc);
}

/********** Base functions for regression ************/

/* Powers of x */
/* y = a0 + a1 * x + a2 * x^2 + a3 * x^3 + ... */
/* dy/dai = x^i */
void basefunc_power(FL64ARRAY  x,    /* Underlying variables */
#ifndef __cplusplus
                    INTI       nfac, /* Number of underlying variables */
#else
                    INTI          ,  /* Number of underlying variables */
#endif                                         
#ifndef __cplusplus
                    INTI       pow,  /* Power */
#else
                    INTI          ,  /* Power */
#endif
                    FL64ARRAY  a,    /* Coefficients */
                    FL64*      y,    /* Function value */
                    FL64ARRAY  dyda, /* dy/da */
                    INTI       na)   /* Number of coefficients */
{
  INTI i;
  FL64 deriv;

  /* Function only works for one dimension. */
#ifndef __cplusplus
  assert(nfac == 1);
  assert(pow + 1 == na);
#endif
  *y = 0.0;
  deriv = 1.0;

  /* a0 + a1 * x + a2 * x^2 + a3 * x^3 ... 
     is calculated as:
     a0 + x * (a1 + x * (a2 + x * (a3 + ...)))

     Derivatives wrt. the coefficients:
     dy/da0 = 1
     dy/da1 = x
     dy/da2 = x*x
     dy/da3 = x*x*x
     ...
  */
  for (i = 0; i < na; i++)
  {
    *y *= x[0];
    *y += a[na -1 - i];
    if (dyda)
    {
      dyda[i] = deriv;
      deriv *= x[0];
    }
  }
}

/* Powers of x1 and x2 */
/* y = a0 + a1 * x1 + a2 * x2 + a3 * x1^2 + a4 * x1 * x2 + a5 * x2^2 */
void basefunc_secondpower(FL64ARRAY  x,    /* Underlying variables */
#ifndef __cplusplus
                          INTI       nfac, /* Number of underlying variables */
#else
                          INTI          ,  /* Number of underlying variables */
#endif                                         
#ifndef __cplusplus
                          INTI       pow,  /* Power */
#else
                          INTI          ,  /* Power */
#endif
                          FL64ARRAY  a,    /* Coefficients */
                          FL64*      y,    /* Function value */
                          FL64ARRAY  dyda, /* dy/da */
                          INTI       na)   /* Number of coefficients */
{ 
  INTI m;
  FL64 d[6];

  /* This function is for two underlying variables to the second power.
     For more variables or higher powers, use the slower function:
     basefunc_multipower */
#ifndef __cplusplus
  assert(nfac == 2);
  assert(pow <= 2);
#endif
  assert(na <= 6);

  switch (na)
  {
  case 6:
    d[5] = x[1]*x[1];
  case 5:
    d[4] = x[0]*x[1];
  case 4:
    d[3] = x[0]*x[0];
  case 3:
    d[2] = x[1];
  case 2:
    d[1] = x[0];
  case 1:
    d[0] = 1.0;
  }

  *y = 0.0;
  for (m = 0; m < na; m++)
    *y += a[m] * d[m];

  if (dyda) /* dyda not NULL */
    for (m = 0; m < na; m++)
      dyda[m] = d[m];
}

/* Calculate number of coefficients for a given combination of power and
   factors. */
/* Not very efficient, but it works fine for testing and research */
/* Positions in the triangle are indexed with base 1 */
INTI PascalsTriangle(INTI r, INTI c)
{
/* The slow and easy way is recursion: 
  if (r <= 1 || c <= 1)
    return 1;
  return PascalsTriangle(r, c - 1) + PascalsTriangle(r - 1, c);*/

/* The fast-track is iteration: */
  INTI rt, ct, i, n;
  FL64 p;

  rt = GETMAX(r, c);
  ct = GETMIN(r, c);

  n = rt - ct;

  p = 1.0;
  for (i = 1; i <= n; i++)
    p *= ((FL64) i + ct) / ((FL64) i);

  /* Note that by definition p will end up being an integer number. */

  return (INTI) p;
}


/*
  Generate all combinations of products of variables with a given power.
  When all variables/factors have been treated (end of recursion) then
  update function value (y) and derivatives dy/da (dyda).
  Utility function for basefunc_multipower.

  The function func_powerpermute is recursive. The stop condition
  (leaf in the recursive tree) is that all the factors have been 'treated'.
  In each leaf, the array 'factorpowers' holds the power of each of the factors.
  The value of the leaf/part is calculated and propagated upwards in the tree.

  Example:
  Three factors (x1, x2 and x3) to the third power. A lookup in Pascals triangle
  yields a total of 20 parts consisting of 10 parts of power 3,
  6 parts of power 2, 3 parts of power 1 and 1 part of power 0 (constant).

  The function basefunc_multipower calls the function func_powerpermute
  4 times with appropriate pointers to the coefficent and derivative arrays
  (once for 3rd power parts , once for 2nd power parts ...).

  The first call of func_powerpermute is for finding all 10 parts of 3rd
  power (remainfac=3, remainpow=3). The first factor (x1) is set to power 3,
  leaving 0 power for the next two factors (x2 and x3), hence the first part
  will be x1^3. Next, the first factor is set to power 2 and then the function
  calls itself to distribute power 1 on the remaining two factors
  (remainfac=2, remainpow=1). Consequentely the next two parts are
  x1^2 * x2 and x1^2 * x3.
  The algorithm continues in this fashion yielding the parts: x1 * x2^2,
  x1 * x2 * x3, x1 * x3^2, x2^3, x2^2 * x3, x2 * x3^2, x3^3 totalling 10
  parts with power 3.
*/
void func_powerpermute(FL64ARRAY  x,         /* Underlying variables */
                       INTI       nfac,      /* Number of underlying variables*/
                       INTI       remainfac, /* No of vars not treated yet */
                       INTI       remainpow, /* Remaining power */
                       FL64ARRAY  a,         /* Coefficients */
                       FL64*      y,         /* Function value */
                       FL64ARRAY  dyda,      /* dy/da */
                       INTIARRAY  factorpowers, /* Powers of the variables */
                       INTI*      ix)        /* Index for current coefficient */
{
  INTI stopp;
  INTI p;
  INTI i;
  FL64 yloc; /* Function value of one part in the polynomium before
                mulitplication with coefficient */

  /* Leaf in the recursive tree, all the factors have been traversed. */
  if (remainfac == 0)
  {
    yloc = 1.0;
    for (i = 0; i < nfac; i++)
    {
      for (p = 1; p <= factorpowers[i]; p++)
        yloc *= x[i];
    }

    /* The running total with the contribution of this part */
    *y += a[*ix] * yloc;

    /* dy/dai equals the value of the part without coefficient */
    if (dyda)
      dyda[*ix] = yloc;
    (*ix)++;
    return;
  }

  stopp = 0;
  if (remainfac == 1)
    /* All the remaining 'power' is used on the last factor */
    stopp = remainpow;
  for (p = remainpow; p >= stopp ; p--)
  {
    /* Assign 'p' power to the current factor and 'remainpow - p' to the
       remaining factors. */
    factorpowers[nfac - remainfac] = p;
    func_powerpermute(x, nfac, remainfac - 1, remainpow - p, a, y, dyda,
        factorpowers, ix);
  }
}                

/* Powers of x1, x2, ..., xk.
y = a0 + a1 * x1 + a2 * x2 + ... + ak * xk + ak+1 * x1^2 + ak+2 * x1 * x2 + ...
*/
void basefunc_multipower(FL64ARRAY  x,    /* Underlying variables */
                         INTI       nfac, /* Number of underlying variables */
                         INTI       pow,  /* Power */
                         FL64ARRAY  a,    /* Coefficients */
                         FL64*      y,    /* Function value */
                         FL64ARRAY  dyda, /* dy/da */
                         INTI       na)   /* Number of coefficients */
{
  INTI      p;
  INTI      aidx; /* Running total index in coefficient array */
  INTI      ix;   /* Local index in coefficient array */
  INTIARRAY factorpowers; /* Array of power for each factor */

  /* special cases with better performance */
  if (pow == 1)
  {
    basefunc_power(x, nfac, pow, a, y, dyda, na);
    return;
  }
  if (nfac == 2 && pow <= 2)
  {
    basefunc_secondpower(x, nfac, pow, a, y, dyda, na);
    return;
  }

  /* Slow but general case */
  aidx = 0;
  *y = 0.0;

  /* For each integer power up to pow, generate terms with that power by
     calling the function func_powerpermute
     For any term the power of each of the variables in that term is
     stored in factorpowers */
  factorpowers = Alloc_INTIARRAY(nfac);
  for (p = 0; p <= pow; p++)
  {
    ix = 0;
    if (dyda)
      func_powerpermute(x, nfac, nfac, p, &a[aidx], y, &dyda[aidx],
          factorpowers, &ix);
    else
      func_powerpermute(x, nfac, nfac, p, &a[aidx], y, NULL, factorpowers, &ix);

    aidx += ix;
  }
  Free_INTIARRAY(factorpowers);
}


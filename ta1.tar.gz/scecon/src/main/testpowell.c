/* SCCS: @(#)testpowell.c	1.3 (SimCorp) 99/11/01 09:42:24 */

/************************************************************************
*
*   project     SCecon
*
*   functions to test BracketMin_NoGrad routine 
*
************************************************************************/

/*** includes ***********************************************************/
#include <string.h>
#include <str2conv.h>
#include <validate.h>
#include <ioconv.h>





/*  POWELL_FCT_TYPE_TAG and POWELL_FCT_TAG used for 
    the testing of BracketMin_NoGrad */

typedef enum test_powell_fct_type_tag
{ 
    PFT_POLYNOMIAL = 0, 
    PFT_EXPONENTIAL,
    PFT_PICEWISE_LINEAR,
    PFT_STEP_FUNCTION
}   TEST_POWELL_FCT_TYPE ;
  
 
/* A polynomial of degree two is used in this structure.
   Hence, if (fct_type == PFT_POLYNOMIAL) f(x)=c_1+c_2*x+c_3*x*x   
   If (ct_type == PFT_EXPONENTIAL) f(x)=exp(c_1*x)+c_2exp(c_3*x) 
   If (ct_type == PFT_PICEWISE_LINEAR      {(c_1-c_2)*10+c_1*x if x<=-10
                                      f(x)={             c_2*x if -10<x<=10
                                           {(c_2-c_3)*10+c_3*x if x>10
   If (ct_type == PFT_STEP_FUNCTION f(x)=c_1*(x<=-10)
                                        +c_2*(x>-10)*(x<=10)+c_3*(x>10) */

typedef struct test_powell_fct_tag
{   
    TEST_POWELL_FCT_TYPE fct_type;
    FL64                 c_1;
    FL64                 c_2;
    FL64                 c_3;
}   TEST_POWELL_FCT ;


FL64 powell_function(FL64  alpha, 
                     void  *pdata, 
                     FL64ARRAY  p, 
                     FL64ARRAY  q, 
                     BOOLE *ok)
{
  TEST_POWELL_FCT *qdata;
  FL64 tmp = 0, tmp_x;

  qdata = (TEST_POWELL_FCT*) pdata;
  tmp_x = p[0] + alpha*q[0];
  
  if (qdata->fct_type == PFT_POLYNOMIAL) 
  {
    tmp = qdata->c_1 + (qdata->c_2 + qdata->c_3 * tmp_x) * tmp_x;
  } 
  else if (qdata->fct_type == PFT_EXPONENTIAL) 
  {
    tmp = exp(qdata->c_1 * tmp_x) + qdata->c_2 * exp(qdata->c_3 * tmp_x);
  } 
  else if (qdata->fct_type == PFT_PICEWISE_LINEAR) 
  {
    tmp = 10 * ((qdata->c_1 - qdata->c_2) + qdata->c_1 * tmp_x) 
             * (tmp_x <= -10)
        + qdata->c_2 * tmp_x * (tmp_x > -10) * (tmp_x <= 10)
        + ((qdata->c_2 - qdata->c_3) * 10 + qdata->c_3 * tmp_x) * (tmp_x > 10);
  } 
  else if (qdata->fct_type == PFT_STEP_FUNCTION) 
  {
    tmp = qdata->c_1 * (tmp_x <= -10) 
        + qdata->c_2 * (tmp_x > -10) * (tmp_x <= 10) 
        + qdata->c_3 * (tmp_x > 10);
  } 
  else 
    *ok = False;

  return tmp;
}


INTI BracketMin_NoGrad_test(char* txa, FILE* in, FILE* out)
{
    FL64        xa, xb, xc, fa = 0, fb = 0, fc = 0, temp = 0;
    FL64ARRAY   p, q;
    BOOLE       test_result, ok;
    INTI diff;
    TEST_POWELL_FCT  pdata;
    ok = True;
    diff = -1;
 
    #define test_SWAP(a,b,c,d) {temp = (a); (a) = (b); (b) = (temp);\
                                temp = (c); (c) = (d); (d) = (temp);}

    /* Sufficient to do the test in one dimension, furthermore,
       set the direction to one and origon to zero */
    p = Alloc_FL64ARRAY(1);
    q = Alloc_FL64ARRAY(1);
    p[0] = 0;
    q[0] = 1;


    if  (!strcmp(txa, "BracketMin_NoGrad()"))
    {
        diff = 1;
        fprintf(out, "%s\n", txa);

        pdata.fct_type = (TEST_POWELL_FCT_TYPE) (Read_INTI(in, out, "Function type "));
        pdata.c_1 = Read_FL64(in, out, "c_1");
        pdata.c_2 = Read_FL64(in, out, "c_2");
        pdata.c_3 = Read_FL64(in, out, "c_3");
        xa = Read_FL64(in, out, "xa");
        xb = Read_FL64(in, out, "xb");
        xc = Read_FL64(in, out, "xc");
        test_result = Read_BOOLE(in, out, "Does this example work?") ;
        BracketMin_NoGrad(&xa, &xb, &xc, &fa, &fb, &fc,
           &pdata, &powell_function, p, q, &ok);
  
        /* examine BracketMin_NoGrad returned correct */
        /* First order the entries in the (x,f) matrice */
        if (xa > xb) 
          test_SWAP(xa,xb,fa,fb);
        if (xa > xc) 
          test_SWAP(xa,xc,fa,fc);
        if (xb > xc) 
          test_SWAP(xb,xc,fb,fc);
        if ((fa >= fb) && (fc >= fb)) 
        {
            if (test_result) 
              diff = 0;
        } 
        else
          /* Let the test be true, in the situationo where 
             it is known the test gives an error */
          if (!test_result) 
            diff = 0;
                  
        /* Print for ok or not */
        if (diff == True)
          fprintf(out, "1; ");
        else
          fprintf(out, "0; ");
       
        IOUtil_ParseLine(in, out) ;

    }

    Free_FL64ARRAY(p);
    Free_FL64ARRAY(q);

    return diff ;
}


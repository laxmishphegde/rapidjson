/* SCID @(#)forward.c	1.12 (SimCorp) 99/02/19 14:15:36 */

/************************************************************************
*
*   project     SCecon
*
*   filename    forward.c
*
*   contains    routines in the SCecon Library Yield for calculating
*               forward rates.
*
************************************************************************/

/***** includes ********************************************************/

#include <yld.h>
#include <stdlib.h>

/***** defines  ********************************************************/

#define TERM_TOL 0.00001

/************************************************************************
*
*               Yld_ForwardRate_Compound()
*
*    interface  #include <yld.h>
*               FL64 Yld_ForwardRate_Compound(FL64 y1,
*                                             FL64 t1,
*                                             FL64 y2,
*                                             FL64 t2,
*                                             INTI qb) ;
*
*    general    Yld_ForwardRate_Compound() calculates the annually
*               compounded zero coupon forward rate from t1 to t2.
*
*    input      FL64      y1    Zero coupon yield corresponding to
*                               t1. Annual rate in percent with quoting
*                               basis qbas.
*
*               FL64      t1    Time in fraction of years corresponding
*                               to y1.
*
*               FL64      y2    Zero coupon yield corresponding to
*                               t2. Annual rate in percent with quoting
*                               basis qbas.
*
*               FL64      t2    Time in fraction of years corresponding
*                               to y2.
*
*               INTI      qbas  Quoting basis of the yields y1 and y2.
*
*    output
*
*    returns    The annually compounded forward rate as FL64 , or
*               0.0 if t1 equals t2.
*
*    diagnostics
*
*    see also
*
*
************************************************************************/


FL64    Yld_ForwardRate_Compound(FL64 rate1,
                                 FL64    term1,
                                 FL64    rate3,
                                 FL64    term3,
                                 INTI    qbas)
{
    FL64    d1, d3, f ;

    if (fabs(term3 - term1) > TERM_TOL)
    {
        /* First find the term1/term3 discounting factors */

        d1 = tvmunit_compound(rate1, term1, qbas) ;
        d3 = tvmunit_compound(rate3, term3, qbas) ;
        f  = tvmunit_compound2rate(d3/d1, term3 - term1, qbas) ;
    }
    else f = 0.0 ;

    return f ;
}


/************************************************************************
*
*               Yld_ForwardRate_Continuous()
*
*    interface  #include <yld.h>
*
*               FL64    Yld_ForwardRate_Continuous(FL64    y1,
*                                                  FL64    t1, FL64    y2, FL64
     t2) ;   *
*
*    general    Yld_ForwardRate_Continuous() calculates the
*               continuously compounded zero coupon forward rate
*               from t1 to t2.
*
*    input      FL64      y1    Continuous ytm corresponding to time 1.
*               FL64      t1    Time in fraction of years to time 1.
*               FL64      y2    Continuous ytm corresponding to time 2.
*               FL64      t2    Time in fractions of years to time 2.
*
*    output
*
*    returns    The continuously compounded forward rate as FL64   , or
*               0.0 if t1 equals t2.
*
*    diagnostics
*
*    see also
*
*
************************************************************************/


FL64    Yld_ForwardRate_Continuous(FL64 rate1,
                                   FL64    term1,
                                   FL64    rate3,
                                   FL64    term3)
{
    FL64    d1, d3, f ;

    if (fabs(term3 - term1) > TERM_TOL)
    {
        /* First find the term1/term3 discounting factors */

        d1 = tvmunit_continuous(rate1, term1) ;
        d3 = tvmunit_continuous(rate3, term3) ;
        f  = tvmunit_continuous2rate(d3/d1, term3 - term1) ;
    }
    else f = 0.0 ;

    return f ;
}


/************************************************************************
*
*               Yld_ForwardRate_Simple()
*
*    interface  #include <yld.h>
*
*               FL64    Yld_ForwardRate_Simple(FL64    y1, FL64    t1,
*                                              FL64    y2, FL64    t2) ;*
*
*    general    Yld_ForwardRate_Simple() calculates the simple forward
*               rate from t1 to t2.
*
*    input      FL64      y1    Simple annual rate corresponding to
*                               time t1.
*               FL64      t1    Time in fraction of years to time 1.
*               FL64      y2    Simple annual rate corresponding to
*                               time t2.
*               FL64      t2    Time in fractions of years to time 2.
*
*    output
*
*    returns    The simple annualized forward rate FL64   , or 0.0
*               if t1 equals t2.
*
*    diagnostics
*
*    see also
*
************************************************************************/


FL64    Yld_ForwardRate_Simple(FL64 rate1,
                               FL64    term1,
                               FL64    rate3,
                               FL64    term3)
{
    FL64    d1, d3, f ;

    if (fabs(term3 - term1) > TERM_TOL)
    {
        /* First find the term1/term3 discounting factors */

        d1 = tvmunit_simple(rate1, term1) ;
        d3 = tvmunit_simple(rate3, term3) ;
        f  = tvmunit_simple2rate(d3/d1, term3 - term1) ;
    }
    else f = 0.0 ;

    return f ;
}


/*
*************************************************************************
*
*               Yld_Spot2Forw_Rate()
*
*    interface  #include <yld.h>
*               FL64 Yld_Spot2Forw_Rate(FL64    rate1,
*                                       FL64    term1,
*                                       FL64    rate3,
*                                       FL64    term3,
*                                       INTI    qb,
*                                       IRRCONV irr) ;
*
*    general    Yld_Spot2Forw_Rate() calculates the forward rate from
*               t1 to t2 for the convention irr.
*
*    input      FL64    rate1   Annual rate corresponding to time t1
*                               in percent and quoted as qb.
*
*               FL64    term1    Time in fraction of years.
*
*               FL64    rate3   Annual rate corresponding to time t2
*                               in percent and quoted as qb.
*
*               FL64    term3   Time in fractions of years
*
*               INTI    qb      The quoting basis of the yields. Only
*                               needed if irr is COMPOUND.
*
*               IRRCONV irr     The yield convention. Can be any of
*
*                                         COMPOUND
*                                         CONTINUOUS
*                                         SIMPLE_MM
*
*    output
*
*    returns    The annualized forward rate FL64, or 0.0 if t1 equals t2*
*
*    diagnostics
*
*    see also   Yld_Spot2Forw_Ts()
*               disc_getforwrate()
*
*************************************************************************
*/


FL64    Yld_Spot2Forw_Rate(FL64 rate1,
                                FL64    term1,
                                FL64    rate3,
                                FL64    term3,
                                INTI    qb,
                                IRRCONV irr)
{
    FL64    tmp ;

    switch (irr)
    {
        case COMPOUND:

            tmp = Yld_ForwardRate_Compound(rate1, term1, rate3, term3, qb) ;
            break ;

        case CONTINUOUS:

            tmp = Yld_ForwardRate_Continuous(rate1, term1, rate3, term3) ;
            break ;

        case SIMPLE_MM:

            tmp = Yld_ForwardRate_Simple(rate1, term1, rate3, term3) ;
            break ;
        default:
            /* warning avoidance */
            tmp = 0.0 ;
            break ;
    }
    return tmp ;
}


/*
*************************************************************************
*
*               Yld_Spot2Forw_Ts()
*
*    interface  #include <yld.h>
*               TSARRAY Yld_Spot2Forw_Ts(TS_STR     *tsin,
*                                        FL64ARRAY  terms,
*                                        INTI       nterms,
*                                        FL64       duration,
*                                        INTPOLCONV iconv) ;
*
*    general    Yld_Spot2Forw_Ts() generates a forward term structure
*               from the spotrates in tsin.
*
*    input      TS_STR    *tsin     Reference to the input spot term
*                                   structure.
*                                   The irrconv element of tsin can be
*                                   one of
*
*                                            SIMPLE_MM
*                                            COMPOUND
*                                            CONTINUOUS
*
*               FL64ARRAY  terms    The fractional terms for which the
*                                   forward rates are calculated.
*
*               INTI       nterms   The number of terms in terms.
*
*               FL64       duration The duration of the forward rates.
*
*               INTPOLCONV iconv    The interpolation convention.
*
*    output
*
*    returns    Pointer to the term structure. The term strcuture is
*               allocated in here as:
*
*                    Alloc_TSARRAY(1, nterms)
*
*               The rates are annualized.
*
*    diagnostics
*
*    see also   Yld_Spot2Forw_Rate()
*               disc_getforwrate()
*
*************************************************************************
*/


TSARRAY Yld_Spot2Forw_Ts(TS_STR*  tsin,
                         FL64ARRAY  terms,
                         INTI       nterms,
                         FL64       duration,
                         INTPOLCONV iconv)
{
    INTI     i ;
    TSARRAY  ts2 ;
    FL64     *r2, *t2 ;
    FL64ARRAY yf, yl ;

    ts2 = Alloc_TSARRAY(1, nterms) ;

    r2  = ts2->rate ;
    t2  = ts2->term ;

    ts2->count = nterms ;
    ts2->qbas  = tsin->qbas ;
    ts2->conv  = tsin->conv ;

    yf = Math_IntpolArray(terms, nterms, tsin->count, tsin->term,
                           tsin->rate, iconv) ;

    for (i = 0 ; i < nterms ; i++)
        terms[i] += duration ;

    yl = Math_IntpolArray(terms, nterms, tsin->count, tsin->term,
                           tsin->rate, iconv) ;

    for (i = 0 ; i < nterms ; i++)
    {
        terms[i] -= duration ;
        r2[i] = Yld_Spot2Forw_Rate(yf[i], terms[i], yl[i],
                                   terms[i] + duration,
                                   tsin->qbas, tsin->conv) ;
        t2[i] = terms[i] ;
    }

    Free_FL64ARRAY(yf) ;
    Free_FL64ARRAY(yl) ;

    return ts2 ;
}


#undef TERM_TOL

#include <sccsid.h>
SCCSID(scstat_c,
  "@(#)scstat.c	1.32 (SimCorp) 99/09/13 12:02:19")

/************************************************************************
*
*   project     SCecon
*
*   filename    scstat.c
*
*   contains    routines in the SCecon Statistics library
*
************************************************************************/

/***** includes ********************************************************/
#include <scmath.h>
#include <float.h>
#include <tvm.h>

/***** defines  ********************************************************/
#define STD_MIN      0.000000001
#define MEAN_TOL     0.000000001
#define CORR_TOL     0.00000000000000000001
#define N02_EXTREME  10.0

#define STAT_ACC   (FL64)     0.0000000001
#define STAT_GUESS (FL64)     1.0
#define STAT_MIN   (FL64)     0.0
#define STAT_MAX   (FL64)  1000.0
#define STAT_MAXIT (INTI)   150
#define STAT_FREQ  (INTI)     1
#define STAT_EPS   (FL64)     0.0001
#define STAT_DAMP  (FL64)     1.0
#define TINY                  1.2e-7


/*,,SOH,,
*************************************************************************
*
*               Stat_Mean()
*
*    interface  #include <scmath.h>
*               FL64 Stat_Mean(INTI nobs,
                               FL64ARRAY x) ;                           *
*
*    general    Stat_Mean() calculates the mean of stochastic variable
*
*               The variable x has been observed nobs times, and all
*               observations are equally likely.
*
*    input      INTI      nobs The number of observations in x
*
*               FL64ARRAY x    The observations.
*
*    output
*
*    returns    the mean
*
*    diagnostics
*
*    see also
*
*************************************************************************
,,EOH,,*/


FL64 Stat_Mean(INTI nobs, FL64ARRAY x)
{
    INTI i ;
    FL64 mean ;

    if (nobs < 1)
       return 0.0 ;

    for (mean = 0.0, i = 0 ; i < nobs ; i++)
        mean += x[i] ;

    mean /= (FL64) nobs ;

    return mean ;
}


/*,,SOH,,
*************************************************************************
*
*               Stat_Stdev()
*
*    interface  #include <scmath.h>
*               FL64 Stat_Stdev(INTI nobs, FL64ARRAY x) ;
*
*    general    Stat_Stdev() calculates the standard deviation of a
*               stochastic variable.
*
*               The variable x has been observed nobs times, and all
*               observations are equally likely
*
*    input      INTI      nobs The number of observations in x
*
*               FL64ARRAY x    The observations.
*
*    output
*
*    returns    the standard deviation
*
*    diagnostics
*
*    see also
*
*************************************************************************
,,EOH,,*/


FL64 Stat_Stdev(INTI nobs, FL64ARRAY x)
{
    INTI i ;
    FL64 mean, stdev ;

    if (nobs <= 1)
       return 0.0 ;

    /* Calculate as sqrt(E(x^2) - E(x)^2) */
    for (stdev = 0.0, i = 0 ; i < nobs ; i++)
        stdev += x[i] * x[i] ;

    stdev /= (FL64) nobs ;
    mean   = Stat_Mean(nobs, x) ;
    stdev -= mean * mean ;

    return sqrt(GETMAX(0.0, stdev)) ;
}


/*,,SOH,,
*************************************************************************
*
*               Stat_Correl()
*
*    interface  #include <scmath.h>
*               FL64 Stat_Correl(INTI nobs, FL64ARRAY x, FL64ARRAY y) ;
*
*    general    Stat_Correl() calculates the correlation coefficient
*               between 2 arrays.
*
*               The variables x/y has been observed nobs times, and all
*               observations are equally likely
*
*    input      INTI      nobs The number of observations in x, y
*
*               FL64ARRAY x    Observations
*
*               FL64ARRAY y    Observations
*
*    output
*
*    returns    the correlation coefficient
*
*    diagnostics
*
*    see also
*
*************************************************************************
,,EOH,,*/


FL64 Stat_Correl(INTI nobs, FL64ARRAY x, FL64ARRAY y)
{
    INTI      i ;
    FL64      mux, muy, ro, vx, vy, vxy, tmp ;
    FL64ARRAY xy ;

    /* Allocate */
    xy  = Alloc_FL64ARRAY(nobs) ;

    /* Get variance of x variate */
    mux = Stat_Mean(nobs, x) ;
    vx  = Stat_Stdev(nobs, x) ;
    vx  = vx ;

    /* Get variance of y variate */
    muy = Stat_Mean(nobs, y) ;
    vy  = Stat_Stdev(nobs, y) ;
    vy  = vy ;

    /* Get the covariance of x and y */
    for (i = 0; i < nobs; i++)
        xy[i] = (x[i] - mux) * (y[i] - muy) ;

    vxy = Stat_Mean(nobs, xy) ;

    /* Get the correlation coefficient */
    tmp = vx * vy ;
    if (fabs(tmp) > CORR_TOL)
        ro = vxy / tmp ;
    else
    {
        if (fabs(vxy) > CORR_TOL)
            ro = 0.0 ;
        else
            ro = 1.0 ;
    }

    /* Clean up */
    Free_FL64ARRAY(xy) ;

    return ro ;
}


/*,,SOH,,
*************************************************************************
*
*               Stat_NormalizedNormal()
*
*    interface  #include <scmath.h>
*               FL64 Stat_NormalizedNormal(FL64 x) ;
*
*    general    Stat_NormalizedNormal() calculates a cumulative normal
*               distribution N(0,1) for a given x value.
*
*               The result is an approximation but the accuracy is 
*               better than 1.5E-7 for all x.
*
*               The approximation is faster and more accurate than 
*               previous methods as suggested in e.g. Abramowitz and 
*               Stegun. See
*
*                   B. Moro
*                   "Fast Computation of Cumulative Normal Distribution
*                   Function", Working Paper, TMG Financial Products 
*
*                   M. Broadie and J. Detemple
*                   "Recent Advances in Numerical Methods for Pricing
*                   Derivative Securities", Working Paper, 1996
*                   (Note the typo!)
*
*    input      FL64    x     The x value.
*
*    output
*
*    returns    the cumulative normal distribution for the x.
*
*    diagnostics
*
*    see also
*
*************************************************************************
,,EOH,,*/

FL64 Stat_NormalizedNormal(FL64 x)
{

#define   A0  0.398942270991
#define   A1  0.020133760596
#define   A2  0.002946756074
#define   B1  0.217134277847
#define   B2  0.018576112465
#define   B3  0.000643163695
#define   C0  1.398247031184
#define   C1 -0.360040248231
#define   C2  0.022719786588
#define   D0  1.460954518699
#define   D1 -0.305459640162
#define   D2  0.038611796258
#define   D3 -0.003787400686

    FL64 t, temp;

    if (x >= N01_EXTREME)
        return 1.0 ;

    else if (x <= - N01_EXTREME)
        return 0.0 ;

    t  = (( x >= 0.0 ) ? x: -x);
    if (t <= 1.87)
    { 
      /* For 0 <= x <= 1.87 */
      temp = t * t ;
      t = 0.5 + t * ( A0 + temp * ( A1 + temp * A2 ))/
                    (1 + temp * (B1 + temp * (B2 + B3 * temp))) ;
    }
    else
    { /* For 1.87 < x < 6 */
      t = (C0 + t * (C1 + C2 * t))/
          (D0 + t * (D1 + t * (D2 + D3 * t))) ;
      
      t *= t ;
      t *= t ;
      t *= t ;
      t *= t ;
      t = 1 - t ;    
    }    

    return ((x >= 0.0) ? t : 1.0 - t);

#undef    A0
#undef    A1
#undef    A2
#undef    B1
#undef    B2
#undef    B3
#undef    C0
#undef    C1
#undef    C2
#undef    D0
#undef    D1
#undef    D2
#undef    D3
}



/*,,SOH,,
*************************************************************************
*
*               Stat_CumulativeNormal()
*
*    interface  #include <scmath.h>
*               FL64 Stat_CumulativeNormal(FL64 x,
*                                           FL64 mean,
*                                           FL64 std) ;
*
*    general    The function returns the cumulative normal distribution
*               at the value x of the stochastic variable at hand.
*               The normal distribution has mean, mean, and standard
*               deviation, std.
*
*    input      FL64    x     The x value of the stochastic variable.
*
*               FL64    mean  The mean of the normal distribution.
*
*               FL64    std   The standard deviation.
*
*    output
*
*    returns    the cumulative normal distribution.
*
*    diagnostics
*
*    see also
*
*************************************************************************
,,EOH,,*/

FL64 Stat_CumulativeNormal(FL64 x, FL64 mean, FL64 std)
{
    if (SCecon_fabs(std) < STD_MIN)
    {
        if (x >= mean - MEAN_TOL)
            return 1.0 ;
        else
            return 0.0 ;
    }
    else
        return Stat_NormalizedNormal((x - mean) / std) ;
}



/*,,SOH,,
*************************************************************************
*
*               Stat_InvNormalizedNormal()
*
*    interface  #include <scmath.h>
*               FL64 Stat_InvNormalizedNormal(FL64 p) ;
*
*    general    This function returns the inverse of the cumulated
*               normal distribution. We take advantage of the symmetry,
*               monotonicity, and convexity of the cumulated normal
*               distribution.
*               Precision is at least 5.0e-8.
*
*               NB: Input must lie in unit interval
*               (no check implemented in the function).
*
*    input      FL64    p   The cumulated normal probability.
*
*    output
*
*    returns    the inverse of cumulative normal distribution.
*
*    diagnostics
*
*    see also   Stat_BIS_InvNormalizedNormal()
*
*************************************************************************
,,EOH,,*/


FL64  Stat_InvNormalizedNormal(FL64  p)
{
    FL64    x0, x, e, pp, nx, nx0 ;

    /* set up */
    x = 0.0 ;
    nx0 = 0.0 ;
    nx = 0.5 ;
    e = fabs(p - 0.5) ;
    pp = e + 0.5 ;

    /* bracket root (ie, find x such that root is between x-1 and x */
    for (; e > TINY;)
    {
        nx0 = nx ;
        x += 1.0 ;
        e = pp - (nx = Stat_NormalizedNormal(x)) ;
    }

    /* secant search */
    for (x0 = x - 1.0, e /= nx - nx0; -e > TINY;)
    {
        x += e ;
        e = pp - (nx = Stat_NormalizedNormal(x)) ;
        e *= (x - x0) / (nx - nx0) ;
    }

    /* return result */
    return (p >= 0.5) ? x : -x ;
}



/*,,SOH,,
*************************************************************************
*
*               Stat_BIS_InvNormalizedNormal()
*
*    interface  #include <scmath.h>
*               FL64 Stat_BIS_InvNormalizedNormal(FL64 p) ;
*
*    general    Compute the inverse of the cumulative normalized normal
*               distribution.
*               Here we use an algorithm due to B. Moro as reported in:
*                "Quasi-Monte Carlo Methods in Numerical Finance"
*                    by
*                 Corwin Joy, Phelim P Boyle, and Ken Seng Tan
*                    in
*                 Management Science, 42 (June 1996), pp 926-38.
*
*               This function is about four times as fast as the
*               "clever" secant search implemented in
*               Stat_InvNormalizedNormal() and its accuracy is not
*               limited by the accuracy of the evaluation function
*               Stat_NormalizedNormal()
*
*    input      FL64    p   The cumulated normal probability.
*
*    output
*
*    returns    the inverse of cumulative normal distribution.
*
*    diagnostics
*
*    see also   Stat_InvNormalizedNormal()
*
*************************************************************************
,,EOH,,*/

FL64  Stat_BIS_InvNormalizedNormal(FL64  p)
{
    FL64    a[5], b[5], c[9], k[2], x, y, z, t1, t2, d1, d2, td ;
    INTI    i ;

    if (fabs((y = 0.5 - p)) <= 0.42)
    {   /* use rational approximation */
        /* set expansion coefficients */
        a[0] = 2.50662823884 ;
        a[1] = -18.61500062529 ;
        a[2] = 41.39119773534 ;
        a[3] = -25.44106049637 ;
        a[4] = 0.0 ;
        b[0] = 1.00 ;
        b[1] = -8.47351093090 ;
        b[2] = 23.08336743743 ;
        b[3] = -21.06224101826 ;
        b[4] = 3.13082909833 ;

        for (t1 = t2 = 0.0, i = 0, z = 1.0; i < 5; i++)
        {
            t1 += a[i] * z ;
            t2 += b[i] * z ;
            z *= y * y ;
        }
        return (-y * t1 / t2) ;
    }
    if (p <= FLT_MIN)
        return FLT_MAX ;
    if (1 - p <= FLT_MIN)
        return FLT_MAX ;
    
    /* use Chebyshev approximation */
    c[0] = 7.7108870705487895 ;
    c[1] = 2.7772013533685169 ;
    c[2] = 0.3614964129261002 ;
    c[3] = 0.0373418233434554 ;
    c[4] = 0.0028297143036967 ;
    c[5] = 0.0001625716917922 ;
    c[6] = 0.0000080173304740 ;
    c[7] = 0.0000003840919865 ;
    c[8] = 0.0000000129707170 ;
    k[0] = 0.4179886424926431 ;
    k[1] = 4.2454686881376569 ;
    
    z = k[0] * (2.0 * log(-log(0.5 - fabs(y))) - k[1]) ;

    /* do Clenshaw iteration */
    for (d1 = d2 = 0.0, i = 8; i >= 1; i--)
    {
        td = 2.0 * z * d1 - d2 + c[i] ;
        d2 = d1 ;
        d1 = td ;
    }
    x = z * d1 - d2 + 0.5 * c[0] ;

    return ((y < 0.0) ? x : -x) ;
}



/*,,SOH,,
*************************************************************************
*
*               Stat_ConfidenceNormal()
*
*    interface  #include <scmath.h>
*               BOOLE Stat_ConfidenceNormal(FL64 conf,
*                                            FL64 mean,
*                                            FL64 std,
*                                            FL64 *limit) ;
*
*    general    The function returns the bound around the mean that will*
*               contain 'conf' % of the probability mass in a normal
*               distribution with mean and stdev as given. If conf is
*               95% then
*
*                        mean +- limit
*
*               contains 95% of the probability mass.
*
*    input      FL64    conf   The confidence limits (eg. 0.97 for 97%
*                              confidence limits)
*
*               FL64    mean   The mean of the normal distribution.
*
*               FL64    std    The standard deviation.
*
*	       	    HOLI_STR *holi Container for list of holidays.
*
*    output     FL64    *limit The confidence limit
*
*    returns    True if all is OK and False if not.
*
*    diagnostics
*
*    see also
*
*    wrapper    AP
*
*************************************************************************
,,EOH,,*/

BOOLE Stat_ConfidenceNormal(FL64 conf, FL64 mean, FL64 std, FL64* limit, void* holi)
{
    TVMTYPE type ;
    TVMINT  tvm_data ;
    ITERCTRL ctrl ;
    FL64    rts ;
    BOOLE   ok ;
    NR_ERR  err ;

    type = STAT_TVM ;

    Init_ITERCTRL(&ctrl) ;
    ctrl.maxiter = STAT_MAXIT ;
    ctrl.init_guess = STAT_GUESS ;
    ctrl.lower = STAT_MIN ;
    ctrl.upper = STAT_MAX ;
    ctrl.damp = STAT_DAMP ;
    ctrl.acc = STAT_ACC ;
    ctrl.what_acc = 1 ;
    ctrl.gfreq = STAT_FREQ ;
    ctrl.bisec = 2 ;
    ctrl.shock = 0.0 ;

    tvm_data = TVM_SetTVMINT(type, conf, mean, std, NULL, 0, 
      CONTINUOUS, 0, BULLET, NULL, NULL, LINEAR_EXTRAPOL, STAT_EPS) ;

	err = Newton_Raphson(&TVM_NewtonRaphson, &tvm_data, &ctrl, &rts, holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */
    ok = (err == NR_ROOT_FOUND ? True : False) ;

    *limit = rts * std ;

    return ok ;
}


/*,,SOH,,
*************************************************************************
*
*               Stat_CumulativeLognormal()
*
*    interface  #include <scmath.h>
*               FL64 Stat_CumulativeLognormal(FL64    x,
*                                              FL64    mean,
*                                              FL64    std) ;
*
*    general    The function returns the cumulative lognormal distribu-
*               tion at the value x of the stochastic variable at hand.
*               The lognormal distribution has mean, mean, and standard
*               deviation, std.
*
*    input      FL64    x     The x value of the stochastic variable.
*
*               FL64    mean  The mean of the distribution.
*                             Must be positive.
*
*               FL64    std   The standard deviation
*
*    output
*
*    returns    the cumulative lognormal distribution.
*
*    diagnostics
*
*    see also
*
*************************************************************************
,,EOH,,*/

FL64 Stat_CumulativeLognormal(FL64 x, FL64 mean, FL64 std)
{
    FL64 tmp, alfa, beta ;

    if (x < 0.0)
        return 0.0 ;
    else
    {
        if (mean > MEAN_TOL)
        {
            tmp  = log(1.0 + SQR(std / mean)) ;
            alfa = log(mean) - 0.5 * tmp ;
            beta = sqrt(tmp) ;
            return Stat_CumulativeNormal(log(x), alfa, beta) ;
        }
        else
            return 1.0 ;
    }
}


/*,,SOH,,
*************************************************************************
*
*               Stat_Binomial()
*
*    interface  #include <scmath.h>
*               BOOLE Stat_Binomial(INTI n,
*                                   INTI p,
*                                   FL64 prob,
*                                   FL64 *res) ;
*
*    general    The function returns the probability of p outcomes with
*               probability (prob) in n tries.
*
*               For the standard binomial distribution use prob = 1/2.
*               p can take on values from 0 to n.
*
*               If n or p is extreme the routine fails and returns
*               False.
*
*    input      INTI    n     The number of possible outcomes.
*
*               INTI    p     The desired number of outcomes.
*
*               FL64    prob  The probability of the outcome.
*                             Must be between 0 and 1.
*
*    output     FL64    *res  The probability
*
*    returns    True if all OK, False if not.
*
*    diagnostics
*
*    see also
*
*************************************************************************
,,EOH,,*/


BOOLE Stat_Binomial(INTI n, INTI p, FL64 prob, FL64* res)
{
    FL64  p1 = 0, p2 = 0 ;
    BOOLE ok ;

    *res = 1.0 ;
    ok   = True ;

    if (p == 0 && n == 0)
        return True ;

    if (p < n)
        ok = Beta_Incompl((FL64) (p + 1), (FL64) (n - (p + 1) + 1), prob, &p1) ;
    if (p > 0)
        ok = ok && Beta_Incompl((FL64) p, (FL64) (n - p + 1), prob, &p2) ;

    if (p == 0 && ok)
        *res = 1.0 - p1 ;
    else if (p > 0 && p < n && ok)
        *res = p2 - p1 ;
    else if (p == n && ok)
        *res = p2 ;

    return ok ;
}


/************************************************************************
*
*               Beta_Incompl()
*
*    interface  #include <scmath.h>
*
*               BOOLE Beta_Incompl(INTI p, INTI b, FL64 prob, FL64 *res) ;
*
*    general    The function returns the probability of p or more
*               outcomes in n trials.
*               For the standard binomial distribution use prob = 1/2.
*
*    input      INTI    p     The number of desired outcomes.
*               INTI    b     n - p + 1 (!) where n is the number of
*                             possible outcomes.
*               FL64    prob  The probability of the outcome.
*                             Must be between 0 and 1.
*    output     FL64    *res  The result
*
*    returns    True if OK, False if not
*
*    diagnostics
*
*    see also
*
************************************************************************/

BOOLE Beta_Incompl(FL64 a, FL64 b, FL64 z, FL64* res)
{
    FL64  temp, beta ;
    BOOLE ok ;

    if (z == 0.0 || z == 1.0)
        beta = 0.0 ;
    else
        beta = exp(Log_Gamma(a + b) - Log_Gamma(a) - Log_Gamma(b) + a * log(z) +
                   b * log(1.0 - z));

    if (z < (a + 1.0)/(a + b + 2.0))
    {
        ok = Beta_Contfrac(a, b, z, &temp);
        if (ok)
            *res = beta * temp / a;
    }
    else
    {
        ok = Beta_Contfrac(b, a, 1.0 - z, &temp) ;
        if (ok)
            *res = 1.0 - beta * temp / b ;
    }
    return ok ;
}


/************************************************************************
*
*               Log_Gamma()
*
*    interface  #include <scmath.h>
*
*               FL64    Log_Gamma(FL64    z) ;
*
*    general    The function returns the log of the gamma function.
*               Full accuracy is obtained for z > 1.
*
*    input      FL64    z    The argument for the gamma function.
*
*    output
*
*    returns    The log of the gamma function.
*
*    diagnostics
*
*    see also
*
************************************************************************/


FL64 Log_Gamma(FL64 z)
{
    FL64    temp, sum ;
    FL64    c_zero, magical_numbers[6] ;
    INTI    i ;

    /* Here are the "magical numbers" found by Lanczos */
    c_zero = 1.000000000190015;
    magical_numbers[0] =  76.18009173 ;
    magical_numbers[1] = -86.50532033 ;
    magical_numbers[2] = 24.01409822 ;
    magical_numbers[3] = -1.231739516 ;
    magical_numbers[4] =  0.120858003e-2 ;
    magical_numbers[5] = -0.536382e-5 ;

    /* We begin by computing the sum in Lanczo's formula */
    for ( sum = c_zero, i = 0; i < 6; i++)
        sum += magical_numbers[i] / (z + (FL64) i + 1.0);

    temp = (z + 0.5) * log(z + 5.5) - z - 5.5 ;

    return temp + log(2.50662827465 * sum / z);
}


/************************************************************************
*
*               Beta_Contfrac()
*
*    interface  #include <scmath.h>
*
*               FL64 Beta_Contfrac(FL64 p, FL64 b, FL64 prob, FL64 *res) ;
*
*    general    The function returns the continued fraction of the
*               incomplete beta function.
*
*    input      FL64    p     The number of desired outcomes.
*               FL64    b     n - p + 1 (!) where n is the number of
*                             possible outcomes.
*               FL64    prob  The probability of the outcome.
*                             Must be between 0 and 1.
*    output     FL64    *res  The result
*
*    returns    True if all ok, False if not
*
*    diagnostics
*
*    see also
*
************************************************************************/

#define BETACF_ITMAX 100
#define BETACF_FPP   3.0e-7


BOOLE Beta_Contfrac(FL64 a, FL64 b, FL64 z, FL64* res)
{
    FL64    qap, qam, qab, em, tem, d ;
    FL64    bz, bm = 1.0, bp, bpp ;
    FL64    az = 1.0, am = 1.0, ap, app, aold ;
    INTI    i;

    qab = a + b ;
    qap = a + 1.0 ;
    qam = a - 1.0 ;
    bz  = 1.0 - qab * z / qap ;
    for (i = 1 ; i <= BETACF_ITMAX ; i++)
    {
        em   = (FL64) i ;
        tem  = em + em ;
        d    = em * (b - em) * z / ((qam + tem) * (a + tem)) ;
        ap   = az + d * am ;
        bp   = bz + d * bm ;
        d    = -(a + em) * (qab + em) * z / ((qap + tem) * (a + tem)) ;
        app  = ap + d * az ;
        bpp  = bp + d * bz ;
        aold = az ;
        am   = ap / bpp ;
        bm   = bp / bpp ;
        az   = app / bpp ;
        bz   = 1.0 ;
        if (fabs(az - aold) < (BETACF_FPP * fabs(az)))
        {
            *res = az ;
            return True ;
        }
    }

    /* a or b too big, or too may iterations */
    return False ;
}


/*,,SOH,,
*************************************************************************
*
*               Stat_BivariateNormal()
*
*    interface  #include <scmath.h>
*               FL64 Stat_BivariateNormal(FL64  x,
*                                         FL64  y,
*                                         FL64  corr,
*                                         BOOLE fixacc,
*                                         FL64  acc) ;
*
*    general    Stat_BivariateNormal() calculates a cumulative
*               bivariate normal distribution for given values.
*
*               In case fixacc is True, we use the standard 
*               approximation, see
*
*                  John Hull: "Options, Futures and Other Derivative
*                              Securities", 2ed, Prentice-Hall, 1993.
*                  Originally (except for a typo correction) from
*                  Z. Drezner: "Computation of the Bivariate Normal
*                               Integral", in Mathematics of
*                               Computation, 32 (January 1978) pp 277-9
*
*               The result is an approximation but accurate to within
*               1.0E-4.
*
*               If fixacc is False, we use the tetrachoric series if the
*               correlation is below 0.618, and otherwise we use the
*               series expansion described in
*
*                  O. A. Vasicek: "A series expansion for the bivariate
*                                  normal integral", in Journal of 
*                                  Computational Finance, 1998, 1(4).
*
*               In any case we handle the perfect correlation 
*               and the perfect negative correlation case by calculating
*               the one-dimensional normal distribution which the 
*               bivariate normal distribution simplifies to in this situation.
*
*               If speed is crucial, fixacc should be True. In case
*               very precise estimates are needed, fixacc should be False.
*
*    input      FL64    x       The first variate
*
*               FL64    y       The second variate
*
*               FL64    corr    The correlation between x and y.
*
*               BOOLE   fixacc  If this is True, the method described
*                               in Hull is used, otherwise the 
*                               method described in Vasicek is used.
*
*               FL64    acc     Accuracy. Only used if fixacc is False
*                               and corr is not 1.0 or -1.0.
*
*    output
*
*    returns    the cumulative normal distribution.
*
*    diagnostics
*
*    see also
*
*************************************************************************
,,EOH,,*/


FL64 Stat_BivariateNormal(FL64 x, FL64 y, FL64 corr, BOOLE fixacc, FL64 acc)
{
  FL64 res ;

  if (corr >= 1.0 - STD_MIN)
    res = Stat_NormalizedNormal(GETMIN(x,y)) ;
  else if (corr <= -1.0 + STD_MIN)
  {
    if (y <= -x)
      res = 0.0 ;
    else 
     res = Stat_NormalizedNormal(y) - Stat_NormalizedNormal(-x) ;
  }
  else if (fixacc)
    res = Stat_BivariateNormal_Drezner(x, y, corr) ;
  else
    res = Stat_BivariateNormal_Vasicek(x, y, corr, acc) ;

  return res ;
}

/*,,SIC,,
*************************************************************************
*
*               Stat_BivariateNormal_Vasicek()
*
*    interface  #include <scmath.h>
*               FL64 Stat_BivariateNormal_Vasicek(FL64  x,
*                                                 FL64  y,
*                                                 FL64  corr,
*                                                 FL64  acc) ;
*
*    general    Stat_BivariateNormal_Vasicek() calculates a cumulative
*               bivariate normal distribution for given values.
*
*               We use the tetrachoric series if the
*               correlation is below 0.618, and otherwise we use the
*               series expansion described in
*
*                  O. A. Vasicek: "A series expansion for the bivariate
*                                  normal integral", in Journal of 
*                                  Computational Finance, 1998, 1(4).
*
*    input      FL64    x       The first variate
*
*               FL64    y       The second variate
*
*               FL64    corr    The correlation between x and y. 
*                               Cannot be 1 or -1. Use 
*                               Stat_Bivariate_Normal in this case.
*
*               FL64    acc     Accuracy, e.g. 0.0001. 
*
*    output
*
*    returns    the cumulative normal distribution.
*
*    diagnostics
*
*    see also
*
*************************************************************************
,,EIC,,*/

FL64 Stat_BivariateNormal_Vasicek(FL64 x, FL64 y, FL64 corr, FL64 acc)
{
  FL64 Hex_old, Hex_new, Hex_temp, Hey_old, Hey_new, Hey_temp ;
  FL64 dens_x, dens_y, old_value, new_value, rho, corr_x, corr_y ;
  FL64 Ak, Bk, num, diff, limit, precision ;
  INTI i ;


  acc = (fabs(acc) > STD_MIN ? fabs(acc) : STD_MIN) ;
  
    /* We use the tetrachoric series of the square correlation is less than
       a half and otherwise we use the method suggested by Vasicek */
  if (fabs(corr) < 0.618)
  {
      
      /* Be careful of not dividing by zero */
    x = GETMAX(-N02_EXTREME, GETMIN(x, N02_EXTREME)) ;
    y = GETMAX(-N02_EXTREME, GETMIN(y, N02_EXTREME)) ;

      /* Initialize the hermitian polynomials */
    Hex_old = 1.0 ;
    Hey_old = 1.0 ;
    Hex_new = x ;
    Hey_new = y ;
    dens_x = exp(-0.5 * x * x) / sqrt(2.0 * sc_PI) ;
    dens_y = exp(-0.5 * y * y) / sqrt(2.0 * sc_PI) ;
    i = 2 ;
    num = 2.0 ;
    rho = corr * corr ;

    old_value = 0.0 ;
    new_value = Stat_NormalizedNormal(x) * Stat_NormalizedNormal(y) ;
    new_value += dens_x * dens_y * Hex_old * Hey_old * corr ;
    new_value += dens_x * dens_y * Hex_new * Hey_new * rho / num ;
    
      /* Calculate whatever is necessary to determine the accuracy */
    limit = acc * (1 - corr) / (1.086435 * 1.086435) ;
    limit /= dens_x * dens_y * exp(0.25 * (x * x + y * y)) ;
    precision = fabs(rho * corr)  / 3.0 ;

      /* The recursive updating formula for the Hermite polynomials can be
         found in Gradshteyn and Ryzhik, p. xxxvii */
    while (precision > limit)
    {
      
      Hex_temp = x * Hex_new - ((FL64) (i - 1)) * Hex_old ;
      Hey_temp = y * Hey_new - ((FL64) (i - 1)) * Hey_old ;
      Hex_old = Hex_new ;
      Hey_old = Hey_new ;
      Hex_new = Hex_temp ;
      Hey_new = Hey_temp ;
      rho *= corr ;
      num *= (FL64) ++i ;
      diff = dens_x * dens_y * Hex_new * Hey_new * rho / num ;
      new_value += diff ;
      precision = fabs(rho * corr) / ((FL64) (i + 1)) ;
    }
  }
  else
  {
    if (x * y == 0.0)
    {
      if (x == 0.0)
        x = y ;
      Bk = sqrt(1 - corr * corr) * exp(- x * x / (2 * (1 - corr * corr))) ;
      Bk /= 2 * sc_PI ;
      Ak = - fabs(x) * Stat_NormalizedNormal(-fabs(x)/(sqrt(1-corr*corr))) ;
      Ak /= sqrt(2 * sc_PI) ;
      Ak += Bk ;
      i = 1 ;
      
      new_value = Ak ;

        /* Calculate whatever is necessary to determine the accuracy */
      limit = corr * corr * 4 * sc_PI * acc ;

      precision = sqrt(1 - corr  * corr) ;


      while (precision / (0.5 + (FL64) i)  > acc)
      {
        Bk *= (2 * i - 1) * (2 * i - 1) * (1 - corr * corr) /
          (2 * i * (2 * i + 1)) ;
        Ak *= -(2 * i - 1) * x * x / (2 * i * (2 * i + 1)) ;
        Ak += Bk ;
        new_value += Ak ;
        precision *= (1 - corr * corr) ;
        i++ ;
      }

      if (corr < 0.0)
      {
        if (x > 0.0)
          new_value += Stat_NormalizedNormal(x) - 0.5 ; 
      }
      else
      {
        if (x < 0.0)
          new_value = Stat_NormalizedNormal(x) - new_value ;
        else
          new_value = 0.5 - new_value ;
      }

    }
    else 
    {
      corr_x = corr * x - y ;
      corr_x /= sqrt(x * x - 2 * corr * x * y + y * y) ;
      if (x < 0.0)
        corr_x *= -1.0 ;
      corr_y = corr * y - x ;
      corr_y /= sqrt(x * x - 2 * corr * x * y + y * y) ;
      if (y < 0.0)
        corr_y *= -1.0 ;
      new_value = Stat_BivariateNormal_Vasicek(x, 0.0, corr_x, acc / 2.0) 
        + Stat_BivariateNormal_Vasicek(y, 0.0, corr_y, acc / 2.0) ;
      if (x * y < 0.0)
        new_value -= 0.5 ;
    }
  }

  return GETMAX(new_value, 0.0) ;
}

/*,,SIC,,
*************************************************************************
*
*               Stat_BivariateNormal_Drezner()
*
*    interface  #include <scmath.h>
*               FL64 Stat_BivariateNormal_Drezner(FL64 a,
*                                                 FL64 b,
*                                                 FL64 c) ;
*
*    general    Stat_BivariateNormal_Drezner() calculates a cumulative
*               bivariate normal distribution M(*) for given values.
*
*               The result is an approximation but accurate to within
*               1.0E-4.
*
*               The approximation is standard. See
*
*                  John Hull: "Options, Futures and Other Derivative
*                              Securities", 2ed, Prentice-Hall, 1993.
*                  Originally (except for a typo correction) from
*                  Z. Drezner: "Computation of the Bivariate Normal
*                               Integral", in Mathematics of
*                               Computation, 32 (January 1978) pp 277-9
*
*    input      FL64    a     The first variate
*
*               FL64    b     The second variate
*
*               FL64    c     The correlation between a and b. 
*
*    output
*
*    returns    the cumulative normal distribution.
*
*    diagnostics
*
*    see also
*
*************************************************************************
,,EIC,,*/


FL64 Stat_BivariateNormal_Drezner(FL64 a, FL64 b, FL64 c)
{
    FL64 res, tmp, c1, c2 ;
    INTI type ;

    res = 0.0 ;

    a = GETMAX(-N01_EXTREME, GETMIN(a, N01_EXTREME));
    b = GETMAX(-N01_EXTREME, GETMIN(b, N01_EXTREME));

    tmp = sqrt(a * a - 2.0 * a * b * c + b * b) ;
/*
    if (fabs(tmp) < STD_MIN)
       tmp = STD_MIN ;
*/
    if (fabs(a) < STD_MIN)
        a = 2.0 * STD_MIN * (a > 0.0 ? 1.0 : -1.0) ;

    if (fabs(b) < STD_MIN)
        b = 2.0 * STD_MIN * (b > 0.0 ? 1.0 : -1.0) ;

    if (fabs(c) < STD_MIN)
        c = 2.0 * STD_MIN * (c > 0.0 ? 1.0 : -1.0) ;

    if (fabs(c - 1.0) < STD_MIN)
        c = 1.0 - STD_MIN ;

    if (fabs(c + 1.0) < STD_MIN)
        c = - 1.0 + STD_MIN ;

    type = 0;
    if (a <= 0.0)
        type = 0 ;
    else
        type = 1 ;

    if (b <= 0.0)
        type += 0 ;
    else
        type += 2 ;

    if (c <= 0.0)
        type += 0 ;
    else
        type += 4 ;

    switch (type)
    {
        case 0: /* All Negative */
            res = Cum_Biv_Norm_Neg(a, b, c) ;
            break ;

        case 1: /* a > 0, Others Negative */

            if (fabs(tmp) < STD_MIN || fabs(c * a - b) < STD_MIN)
                c1 = STD_MIN ;
            else
                c1 = (c * a - b) / tmp ;
            if (fabs(tmp) < STD_MIN || fabs(c * b - a) < STD_MIN)
                c2 = STD_MIN ;
            else
                c2 = -(c * b - a) / tmp ;

            if (c1 > 0.0)
              res = Stat_BivariateNormal_Drezner(a, -2.0 * STD_MIN, c1) ;
            else
              res = Stat_BivariateNormal_Drezner(a, 2.0 * STD_MIN, c1) ;

            if (c2 > 0.0)
              res += Stat_BivariateNormal_Drezner(b, 2.0 * STD_MIN, c2) ;
            else
              res += Stat_BivariateNormal_Drezner(b, -2.0 * STD_MIN, c2) ;

            res -= 0.5 ;
/*
            res = Stat_BivariateNormal_Drezner(a, 0.0, c1) +
                  Stat_BivariateNormal_Drezner(b, 0.0, c2) - 0.5 ;
*/
            break ;

        case 2: /* b > 0, Others Negative */

            if (fabs(tmp) < STD_MIN || fabs(c * a - b) < STD_MIN)
                c1 = STD_MIN ;
            else
                c1 = -(c * a - b) / tmp ;
            if (fabs(tmp) < STD_MIN || fabs(c * b - a) < STD_MIN)
                c2 = STD_MIN ;
            else
                c2 = (c * b - a) / tmp ;


/*
            c1 = -(c * a - b) / tmp ;
            c2 = (c * b - a) / tmp ;
*/
            if (c1 > 0.0)
              res = Stat_BivariateNormal_Drezner(a, 2.0 * STD_MIN, c1) ;
            else
              res = Stat_BivariateNormal_Drezner(a, -2.0 * STD_MIN, c1) ;

            if (c2 > 0.0)
              res += Stat_BivariateNormal_Drezner(b, -2.0 * STD_MIN, c2) ;
            else
              res += Stat_BivariateNormal_Drezner(b, 2.0 * STD_MIN, c2) ;

            res -= 0.5 ;
/*
            res = Stat_BivariateNormal_Drezner(a, 0.0, c1) +
                  Stat_BivariateNormal_Drezner(b, 0.0, c2) - 0.5 ;
*/
            break ;

        case 3:
            res = Stat_NormalizedNormal(a) + Stat_NormalizedNormal(b) - 1.0 +
                  Cum_Biv_Norm_Neg(-a, -b, c) ;

            break ;

        case 4: /* c > 0, Others Negative */

            if (fabs(tmp) < STD_MIN || fabs(c * a - b) < STD_MIN)
                c1 = STD_MIN ;
            else
                c1 = -(c * a - b) / tmp ;
            if (fabs(tmp) < STD_MIN || fabs(c * b - a) < STD_MIN)
                c2 = STD_MIN ;
            else
                c2 = -(c * b - a) / tmp ;

/*
            c1 = -(c * a - b) / tmp ;
            c2 = -(c * b - a) / tmp ;
*/

              /* Avoid unfortunate situation. Without this hack N(0,0,0.5) 
                 becomes 0.5 where the correct figure is 0.33 */
            if (a == -2.0 * STD_MIN && b == -2.0 * STD_MIN)
            {
              if (c > 0.0)
                res = Stat_BivariateNormal_Drezner(a, -b, c) ;
              else
                res = Stat_BivariateNormal_Drezner(a, b, c) ;
            }
            else
            {
              if (c1 > 0.0)
                res = Stat_BivariateNormal_Drezner(a, 2.0 * STD_MIN, c1) ;
              else
                res = Stat_BivariateNormal_Drezner(a, -2.0 * STD_MIN, c1) ;

              if (c2 > 0.0)
                res += Stat_BivariateNormal_Drezner(b, 2.0 * STD_MIN, c2) ;
              else
                res += Stat_BivariateNormal_Drezner(b, -2.0 * STD_MIN, c2) ;
            }


/*
            res = Stat_BivariateNormal_Drezner(a, 0.0, c1) +
                  Stat_BivariateNormal_Drezner(b, 0.0, c2) ;
*/
            break ;

        case 5:
            res = Stat_NormalizedNormal(b) - Cum_Biv_Norm_Neg(-a, b, -c) ;
            break ;

        case 6:
            res = Stat_NormalizedNormal(a) - Cum_Biv_Norm_Neg(a, -b, -c) ;
            break ;

        case 7: /* All positive */

            if (fabs(tmp) < STD_MIN || fabs(c * a - b) < STD_MIN)
                c1 = STD_MIN ;
            else
                c1 = (c * a - b) / tmp ;
            if (fabs(tmp) < STD_MIN || fabs(c * b - a) < STD_MIN)
                c2 = STD_MIN ;
            else
                c2 = (c * b - a) / tmp ;

/*
            c1 = (c * a - b) / tmp ;
            c2 = (c * b - a) / tmp ;
*/

              
            if (c1 > 0.0)
                res = Stat_BivariateNormal_Drezner(a, -2.0 * STD_MIN, c1) ;
            else
                res = Stat_BivariateNormal_Drezner(a, 2.0 * STD_MIN, c1) ;

            if (c2 > 0.0)
                res += Stat_BivariateNormal_Drezner(b, -2.0 * STD_MIN, c2) ;
            else
                res += Stat_BivariateNormal_Drezner(b, 2.0 * STD_MIN, c2) ;

/*
            res = Stat_BivariateNormal_Drezner(a, 0.0, c1) +
                  Stat_BivariateNormal_Drezner(b, 0.0, c2) ;
*/
            break ;
    }
    
    return res ;
}

/*
   This function returns an approximate value for the cumulative bivariate
   normal distribution (with unit diagonal elements of the covariance matrix)
   when a, b, and c are all non-positive.
*/


FL64 Cum_Biv_Norm_Neg(FL64 a, FL64 b, FL64 c)
{
    FL64 res ;
    FL64 ai[4], bi[4] ;
    FL64 atmp, btmp, tmp ;
    INTI i, j ;

    /* Define "magic" numbers */
    ai[0] = 0.3253030 ; ai[1] = 0.4211071 ; ai[2] = 0.1334425 ; ai[3] =
      0.006374323 ;
    bi[0] = 0.1337764 ; bi[1] = 0.6243247 ; bi[2] = 1.3425378 ; bi[3] =
      2.2626645 ;

    if (c > 1.0 - STD_MIN)
        c = 1.0 - STD_MIN ;

    if (c < -1.0 + STD_MIN)
        c = - 1.0 + STD_MIN ;

    tmp = sqrt(1.0 - c * c) ;

    atmp = a / (sqrt(2.0) * tmp) ;
    btmp = b / (sqrt(2.0) * tmp) ;

    for (i = 0, res = 0.0; i < 4; i++)
    {
        for (j = 0; j < 4; j++)
            res += ai[i] * ai[j] * f_anc(bi[i], bi[j], atmp, btmp, c) ;
    }
    res *= tmp ;
    res /= sc_PI ;


    return res ;
}


/*
..
*/


FL64 f_anc(FL64 x, FL64 y, FL64 a, FL64 b, FL64 c)
{
    FL64 tmp ;

    tmp = a * (2.0 * x - a) + b * (2.0 * y - b) + 2.0 * c * (x - a) * (y - b) ;

    return exp(tmp) ;
}


#undef BETACF_ITMAX
#undef BETACF_FPP

#undef STD_MIN
#undef MEAN_TOL
#undef N02_EXTREME

#undef STAT_ACC
#undef STAT_GUESS
#undef STAT_MIN  
#undef STAT_MAXIT
#undef STAT_MAX  
#undef STAT_FREQ
#undef STAT_EPS
#undef STAT_DAMP
#undef TINY

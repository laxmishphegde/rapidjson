/* SCID @(#)rates.c	1.10 (SimCorp) 99/02/19 14:16:19 */

/************************************************************************
*
*   project     SCecon
*
*   filename    rates.c
*
*   contains    routines in the SCecon Library Yield.
*
************************************************************************/

/***** includes ********************************************************/
#include <yld.h>

/*
*************************************************************************
*
*               Yld_Shock_Rates()
*
*    interface  #include <yld.h>
*               void Yld_Shock_Rates(TS_STR    *tsstr,
*                                    SHOCKCONV shocktype,
*                                    FL64      shocksize) ;
*
*    general    Yld_Shock_Rates() shocks a given termstructure a given
*               amount (shocksize) corresponding to a given shocktype.
*
*    input      TS_STR    *tsstr    Reference to the termstructure,
*                                   that is to be shocked.
*                                   The rates are assumed to be in
*                                   percent.
*
*               SHOCKCONV shocktype The shocktype.
*
*               FL64      shocksize The size of the shock.
*                                   If PARALLEL this is a level in
*                                   percent that the term structure is
*                                   moved.
*                                   If shocktype is MULTIPLICATIVE
*                                   it is the fractional part of the
*                                   factor (factor = 1.0 + shocksize).
*                                   If shocktype is FACTOR_SHOCK then
*                                   this is the amount the loadings in
*                                   tsstr->loading[i] are shocked.
*
*    output                         tsstr is updated for each term in
*                                   the structure.
*
*    returns
*
*    diagnostics
*
*    see also
*
*************************************************************************
*/


void Yld_Shock_Rates(TS_STR* tsstr,
                     SHOCKCONV shocktype,
                     FL64      shocksize)
{
    FL64    tmp ;
    INTI    i, count ;
    FL64    *rate, *loading ;

    rate    = tsstr->rate ;
    loading = tsstr->loading ;
    count   = tsstr->count ;

    switch (shocktype)
    {
        case PARALLEL:

            for (i = 0 ; i < count ; i++)
                rate[i] += shocksize ;
            break ;

        case MULTIPLICATIVE:

            for (i = 0 ; i < count ; i++)
            {
                tmp = (1.0 + rate[i]/100.0)*(1.0 + shocksize) ;
                rate[i] = 100.0 * (tmp - 1.0) ;
            }
            break ;

        case FACTOR_SHOCK:

            for (i = 0 ; i < count ; i++)
                rate[i] += shocksize * loading[i] ;
            break ;
    }
}


/*
*************************************************************************
*
*               Yld_GetRates()
*
*    interface  #include <yld.h>
*               TSARRAY Yld_GetRates(TS_STR     *tsin,
*                                    FL64ARRAY  terms,
*                                    INTI       n,
*                                    INTPOLCONV intpol) ;
*
*    general    Yld_GetRates() finds the rates and loadings
*               corresponding to terms in the term structure tsin and
*               delivers these in tsout.
*
*    input      TS_STR     *tsin   Reference to the input term
*                                  structure.
*
*               FL64ARRAY  terms   Reference to array of terms, at
*                                  which rates are to be found.
*
*               INTI       n       The number of elements in terms.
*
*               INTPOLCONV intpol  The interpolation convention.
*
*    output                        Pointer to the term structure.
*                                  Allocated in the function
*                                  as:  Alloc_TSARRAY(1, n) ;
*
*    returns
*
*    diagnostics
*
*    see also   Yld_Get_TsRate()
*
*************************************************************************
*/

TSARRAY Yld_GetRates(TS_STR*  tsin,
                     FL64ARRAY  terms,
                     INTI       n,
                     INTPOLCONV intpol)
{
    INTI      i ;
    TSARRAY   out ;
    FL64ARRAY tmp, tmp1 ;

    out = Alloc_TSARRAY(1, n) ;

    out->count = n ;
    out->qbas  = tsin->qbas ;
    out->conv  = tsin->conv ;

    tmp  = Math_IntpolArray(terms, n, tsin->count, tsin->term, tsin->rate,
                             intpol) ;
    tmp1 = Math_IntpolArray(terms, n, tsin->count, tsin->term, tsin->loading,
                             intpol) ;

    for (i = 0 ; i < n ; i++)
    {
        out->rate[i]    = tmp[i] ;
        out->loading[i] = tmp1[i] ;
        out->term[i]    = terms[i] ;
    }

    Free_FL64ARRAY(tmp) ;
    Free_FL64ARRAY(tmp1) ;

    return out ;
}


/*
*************************************************************************
*
*               Yld_Get_TsRate()
*
*    interface  #include <yld.h>
*               FL64 Yld_Get_TsRate(TS_STR     *tsin,
*                                   FL64       term,
*                                   INTPOLCONV intpol) ;
*
*    general    Yld_Get_TsRate() finds the rate at maturity term
*               from the input term structure tsin.
*               intpol is a convention used to interpolate.
*
*    input      TS_STR     *tsin   Reference to the input term
*                                  structure.
*
*               FL64       term    Term for desired rate.
*
*               INTPOLCONV intpol  The interpolation convention
*
*    output
*
*    returns    rate in percent.
*
*    diagnostics
*
*    see also   Yld_GetRates()
*
*************************************************************************
*/


FL64 Yld_Get_TsRate(TS_STR*  tsin,
                    FL64       term,
                    INTPOLCONV intpol)
{
    FL64 res ;

    res = Math_Interpolation(term, tsin->count, tsin->term, tsin->rate,
                             intpol) ;

    return res ;
}


/*
*************************************************************************
*
*                Yld_FL64ARRAY2TSARRAY()
*
*    interface   #include <yld.h>
*
*    syntax      void Yld_FL64ARRAY2TSARRAY(INTI      n,
*                                           FL64ARRAY term,
*                                           FL64ARRAY rate,
*                                           FL64ARRAY loading,
*                                           INTI      qbas,
*                                           IRRCONV   irr,
*                                           TSARRAY   ts) ;
*
*    general     The function takes the term/rate/loading's and put
*                these data in a term structure struct, ts.
*
*    input       INTI      n       The number of elements in term, rate
*                                  and loading.
*
*                FL64ARRAY term    Array of terms corresponding to rate,*
*                                  and loading in fractional years.
*
*                FL64ARRAY rate    Array of rates for the terms in term.*
*
*                FL64ARRAY loading The factor loadings corresponding to
*                                  term.
*
*                INTI      qbas     The term structure quoting basis.
*
*                IRRCONV   irr      The yield convention.
*
*    output      TSARRAY   ts      Reference to a structure that are to
*                                  be filled with the input data.
*                                  Must be preallocated using routine
*                                  Alloc_TSARRAY().
*
*    returns
*
*    diagnostics
*
*    see also    Alloc_TSARRAY()
*
*************************************************************************
*/


void Yld_FL64ARRAY2TSARRAY(INTI n, FL64ARRAY term, FL64ARRAY rate,
                           FL64ARRAY loading,
                           INTI qbas, IRRCONV irr, TSARRAY ts)
{
    INTI    i ;
    TS_STR  *t ;
    FL64    *term1, *rate1, *loading1 ;
    FL64    *term2, *rate2, *loading2 ;

    t = ts ;

    t->count = n ;
    t->conv  = irr ;
    t->qbas  = qbas ;

    term1    = term ;
    rate1    = rate ;
    loading1 = loading ;

    term2    = t->term ;
    rate2    = t->rate ;
    loading2 = t->loading ;

    for (i = 0 ; i < n ; i++)
    {
        term2[i]    = term1[i] ;
        rate2[i]    = rate1[i] ;
        loading2[i] = loading1[i] ;
    }
}

/* SCID @(#)holidays.c	1.16 (SimCorp) 99/02/19 14:15:38 */

/************************************************************************
*
*   project     SCecon
*
*   file name   holidays.c
*
*   general     This file contains standard routines for holiday
*               calculations.
*
************************************************************************/

/* includes ************************************************************/
#include <cldr.h>

/*,,SOH,,
*************************************************************************
*
*               Cldr_EasterSunday()
*
*   interface   #include <cldr.h>
*               DATESTR Cldr_EasterSunday(INTI  sYear);
*
*   general     The function finds the date for easter sunday in the
*               year specified.
*
*               Notice that easter sunday is not always the same as
*               the Greek Orthodox easter sunday.
*
*               Easter sunday also serves as the basis for calculating
*               various other holy days. These are found as the date
*               for easter sunday plus a certain number of days, using
*               the ACTACT calendar convention.
*               A - possibly incomplete - list of easter sunday derived
*               holidays is:
*
*                       Holiday             Add days
*                       -------             --------
*                       easter monday           1
*                       easter friday          -2
*                       easter thursday        -3
*                       pentecost monday       50
*                       passover/ascension     39
*                       bededag (danish)       26
*                       fronleichnam           60
*
*               The purpose of this function is not to give a list of
*               international holidays, but to provide a function based
*               on which you can derive the holidays relevant for your
*               application.
*
*               This function can be used to generate some of the
*               floating holidays in Christian countries.
*
*               See also Cldr_Advent() for christmas related holidays.
*
*   input       INTI      sYear     The year at hand.
*
*   output
*
*   returns     easter sunday as DATESTR.
*
*   diagnostics
*
*   see also    Cldr_IsBusinessDate()
*               Cldr_NextBusinessDate()
*               Cldr_AddBusinessdays()
*               Cldr_GenrHolidaysByRules()
*               Cldr_Advent()
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/


DATESTR Cldr_EasterSunday(INTI sYear)
{
   INTI        sGoNum, sCentury, sGregorian, sClavi, sExDays, sEpact ;
   INTI        sDay, sMonth ;
   DATESTR     out ;

   sMonth      = 3 ;
   sGoNum      = 1 + sYear%19 ;
   sCentury    = 1 + sYear / 100 ;
   sGregorian  = ( ((INTI )(3 * sCentury)) / 4 ) - 12 ;
   sClavi      = ( sCentury - ( 16 + ((INTI )(sCentury - 18)) / 25 ) ) / 3 ;
   sExDays     = ( ((INTI )(5 * sYear)) / 4 ) - ( sGregorian + 10 ) ;
   sEpact      = ( (11 * sGoNum) + 20 + sClavi - sGregorian ) % 30 ;

   if (sEpact < 0)
       sEpact += 30 ;
   if ((sEpact == 24) || ( (sEpact == 25) && (sGoNum > 11)) )
       sEpact += 1 ;

   sDay = 44 - sEpact ;
   if (sDay < 21)
       sDay += 30 ;

   sDay = sDay + 7 - (sExDays + sDay) % 7 ;
   if (sDay > 31)
   {
      sDay  -= 31 ;
      sMonth = 4 ;
   }

   out.d = sDay ;
   out.m = sMonth ;
   out.y = sYear ;
   return out ;
}


/*,,SOH,,
*************************************************************************
*
*               Cldr_Advent()
*
*   interface   #include <cldr.h>
*               DATESTR Cldr_Advent(INTI sYear) ;
*
*   general     The function finds the date for advent, ie. the 4'th
*               sunday before christmas, in the year specified.
*
*               Advent also serves as the basis for calculating
*               various other holidays. These are found as the date
*               for advent plus a certain number of days, using
*               the ACTACT calendar convention.
*
*               A - possibly incomplete - list of advent derived
*               holidays is:
*
*                       Holiday             Add days
*                       ----------------------------
*                       buss & betetag         11
*
*   input       INTI      sYear     The year at hand.
*
*   output
*
*   returns     advent as DATESTR
*
*   diagnostics
*
*   see also    Cldr_IsBusinessDate()
*               Cldr_NextBusinessDate()
*               Cldr_AddBusinessdays()
*               Cldr_GenrHolidaysByRules()
*               Cldr_EasterSunday()
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/



DATESTR Cldr_Advent(INTI sYear)
{
    INTI    w ;
    DATESTR xmas ;

    xmas.y = sYear ;
    xmas.m = 12 ;
    xmas.d = 24 ;

    w = Cldr_Weekday(&xmas) ;
    return Cldr_AddDays(&xmas, (INTL) -(w + 21), ACTACT, NULL) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
}


/*,,SOH,,
***********************************************************************
*                                                                      
*               Cldr_GenrHolidaysByRules()                             
*                                                                      
*   interface   #include <cldr.h>                                      
*               DATEARRAY Cldr_GenrHolidaysByRules(INTI start_year,
*                                         INTI          end_year,    
*                                         HOLIRULEARRAY rules,
*                                         INTI          nrules,
*                                         BOOLE         weekend_incl,
*                                         INTI*         n) ;
*                                         
*                                   
*   general     This function generates a list of holidays in range    
*               of years. The holidays are defined by a list of
*               generic rules.   
*                                                                       
*               Notice that easter sunday is not always the same as    
*               the Greek Orthodox easter sunday.                      
*                                                                       
*               The generated list of holidays is usefull when
*               setting the HOLI_STR.
*                                                                       
*   input       INTI          start_year   The year at hand.                  
*                                                                       
*               INTI          end_year     The year at hand.                  
*                                                                       
*               HOLIRULEARRAY rules        The generic holiday rules.
*                                          Refer to HOLIRULE for 
*                                          example data.
*                                                                       
*               INTI          nrules       No. of holiday rules.
*                                         
*               BOOLE         weekend_incl Toggle for inclusion of 
*                                          weekend holidays. False 
*                                          examplemeans that holidays 
*                                          falling in aweekend are 
*                                          excluded.
*                                                                      
*   output      INTI*         n            The number of holidays 
*                                          returned.
*                                                                      
*   returns     List of holidays allocated using
*
*                   Alloc_DATEARRAY(nholi) ;
*
*               where
*
*                   nholi = (end_year - start_year + 1) * nrules ;
*
*               which is never less than n.
*                                                                      
*   diagnostics                                                        
*                                                                      
*   see also    Cldr_EasterSunday()    
*               Cldr_Advent()          
*                                      
***********************************************************************
,,EOH,,*/


DATEARRAY Cldr_GenrHolidaysByRules(INTI        start_year,
                                 INTI        end_year,
                                 HOLIRULEARRAY  rules,
                                 INTI        nrules,
                                 BOOLE       weekend_incl,
                                 INTI*   n)
{
    INTI      tmp, i, j, nholi ;
    DATESTR   pdate, anchor, tmpdate ;
    DATEARRAY pholidays;

    INTI term, offset_sat, offset_sun, dayinmonth;
    WEEKDAY weekday;
    ANCHORDAY anchorday;

    /* Initialisation */
    *n = 0 ;
    nholi = (end_year + 1 - start_year) * nrules ;
    pholidays = Alloc_DATEARRAY(nholi);

    for (i = start_year ; i <= end_year ; i++)
    {
        /* Loop over rules for this year */
        for (j = 0 ; j < nrules ; j++)
        {
            term = rules[j].term ;
            weekday = rules[j].unit ;
            dayinmonth = rules[j].day ;
            anchorday = rules[j].anchor ;
            offset_sat = rules[j].offset_sat ;
            offset_sun = rules[j].offset_sun ;

            /* First get anchors */
            anchor = Cldr_Anchorday2Datestr(dayinmonth, anchorday, i);

            /* Then move to weekday */
            switch (weekday)
            {
            case MONDAY :
            case TUESDAY :
            case WEDNESDAY :
            case THURSDAY :
            case FRIDAY :
            case SATURDAY :
            case SUNDAY :
                pdate = Cldr_DateByWeekdays(term, weekday, &anchor) ;
                break ;
            case DAY :
            default :
                tmpdate = Cldr_DateByDays(term, &anchor) ;
                pdate = Cldr_WeekendOffsetDays(offset_sat, offset_sun, 
                                               &tmpdate);
                break ;
            } 

            /* Finally, check that pdate should be included */
            tmp = Cldr_Weekday(&pdate) ;
            if (tmp <= 5 || weekend_incl == True)
            {
                pholidays[*n] = pdate ;
                (*n)++ ;
            }
        } /* Rules for this year */
    } /* Years */

    return pholidays ;
}


/*,,SOH,,
**********************************************************************
*                                                                     
*                Set_HOLIRULE()                                       
*                                                                     
*   interface    #include <cldr.h>                                    
*                HOLIRULE Set_HOLIRULE(INTI      term,   
*                                      WEEKDAY   unit,   
*                                      INTI      day,   
*                                      ANCHORDAY anchor, 
*                                      INTI      offset_sat,
*                                      INTI      offset_sun);
*                                                                     
*   general      This routine sets the members of the struct defined  
*                in the function name. The intention   
*                of the Set_*() routines is that by using this        
*                functionality, one avoids setting individual members 
*                of structs in the application code.                  
*                                                                     
*                When new members are inserted in structs the Set_*() 
*                routine will be changed accordingly.                 
*                                                                     
*                For details on the interpretation of the individual  
*                struct members please check the struct definition.   
*                                                                     
*   input        INTI      term       See general section.
*                                                        
*                WEEKDAY   unit       See general section.
*                                                        
*                INTI      day        See general section.
*                                                                     
*                ANCHORDAY anchor     See general section.  
*                                                                     
*                INTI      offset_sat See general section.  
*                                                                     
*                INTI      offset_sun See general section.  
*                                                                     
*   output                                                            
*                                                                     
*   returns      The filled out HOLIRULE struct.
*                                                                     
*   diagnostics                                                       
*                                                                     
*   see also     HOLIRULE
*                                                                     
**********************************************************************
,,EOH,,*/

HOLIRULE Set_HOLIRULE(INTI       term,   
                                WEEKDAY    unit,   
                                INTI       day,   
                                ANCHORDAY  anchor, 
                                INTI       offset_sat,
                                INTI       offset_sun)
{
    HOLIRULE rule ;

    rule.term = term ;
    rule.unit = unit ;
    rule.day = day ;
    rule.anchor = anchor ;
    rule.offset_sat = offset_sat ;
    rule.offset_sun = offset_sun ;

    return rule ;
}

/*
..
*/

/* Generate a holiday taking an anchor and adding a number of 
   a certain weekday, eg 4 mondays.
   Note that after means on or after, i.e. 1 mondays after 7/4/97 
   is 7/4/97 and 1 mondays after 8/4/97 is 14/4/97.
   Before means strictly before, i.e. 1 mondays before 7/4/97 is 
   31/3/97 
   w must be either of MONDAY, TUESDAY, ..., SUNDAY */

DATESTR Cldr_DateByWeekdays(INTI    n,       
                                   WEEKDAY    w,       
                                   DATESTR*  anchor)
{
    INTI wl, dd, w1 ;

    switch (w)
    {
    case MONDAY : 
      w1 = 1 ;
      break ;
    case TUESDAY :
      w1 = 2 ;
      break ;
    case WEDNESDAY :
      w1 = 3 ;
      break ;
    case THURSDAY :
      w1 = 4 ;
      break ;
    case FRIDAY :
      w1 = 5 ;
      break ;
    case SATURDAY :
      w1 = 6 ;
      break ;
    case SUNDAY :
    default:
      w1 = 7 ;
      break ;
    };

    wl = Cldr_Weekday(anchor) ;

    /* days to first required weekday */
    dd = (w1 - wl) + 7 * (w1 < wl) ;

    if (n > 0)
      return Cldr_AddDays(anchor, dd + 7 * (n-1), ACTACT, NULL) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
    else
      return Cldr_AddDays(anchor, dd + 7 * n, ACTACT, NULL) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
}




/* Generate a holiday taking an anchor and adding a number of days.
   Note that after means on or after, i.e. 1 days after 1/1/91 is 1/1/91.
   Before means strictly before, i.e. 1 days before 1/1/91 is 31/12/90 */

DATESTR Cldr_DateByDays(INTI  days,
                          DATESTR*  anchor)
{
    if (days > 0)
        return Cldr_AddDays(anchor, days - 1, ACTACT, NULL) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
    else
        return Cldr_AddDays(anchor, days, ACTACT, NULL) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
}


/* Generate a holiday by adding offset_sat days to day if day is a
   saturday, or by adding offset_sun days to day if day is a sunday. */

DATESTR Cldr_WeekendOffsetDays(INTI  offset_sat,
                           INTI  offset_sun,
                           DATESTR*  day)
{
    INTI weekday_no;
    DATESTR out;

    out = *day;

    weekday_no = Cldr_Weekday(day);

    if (weekday_no == 6)
        /* Saturday */
        out = Cldr_AddDays(day, offset_sat, ACTACT, NULL) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
    else if (weekday_no == 7)
        /* Sunday */
        out = Cldr_AddDays(day, offset_sun, ACTACT, NULL) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
    
    return out;
} 


/* Generate a holiday by an anchorday in a year.
   if anchorday indicates a months, day is the day of the month
   if anchorday indicates an irregular holiday, eg. easter,
   day is not used.
*/
DATESTR Cldr_Anchorday2Datestr(INTI  day, 
                                  ANCHORDAY  anchorday,
                                  INTI  year)
{
    DATESTR out, ddd;

    /* first get anchors */
    out.y = year ;
    out.d = day;

    switch (anchorday)
    {
    case JANUARY_1 :
        out.m = 1 ;
        break ;
    case FEBRUARY_1 :
        out.m = 2 ;
        break ;
    case MARCH_1 :
        out.m = 3 ;
        break ;
    case APRIL_1 :
        out.m = 4 ;
        break ;
    case MAY_1   :
        out.m = 5 ;
        break ;
    case JUNE_1  :
        out.m = 6 ;
        break ;
    case JULY_1  :
        out.m = 7 ;
        break ;
    case AUGUST_1 :
        out.m = 8 ;
        break ;
    case SEPTEMBER_1 :
        out.m = 9 ;
        break ;
    case OCTOBER_1 :
        out.m = 10 ;
        break ;
    case NOVEMBER_1 :
        out.m = 11 ;
        break ;
    case DECEMBER_1 :
        out.m = 12 ;
        break ;
    case EASTER_SUN :
        out = Cldr_EasterSunday(year) ;
        break ;
    case PENTECOST_SUN :
        ddd = Cldr_EasterSunday(year) ;
        out = Cldr_AddDays(&ddd, 49, ACTACT, NULL) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
        break ;
    case ADVENT_SUN1 :
        out = Cldr_Advent(year) ;
        break ;
    default :
        /* This should never be reached! */
        out.y = year ;
        out.m = 1 ;
        out.d = 1 ;
        break ;
    } /* months */

    return out;
}



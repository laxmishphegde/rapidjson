/* SCID @(#)immdays.c	1.23 (SimCorp) 99/02/19 14:15:43 */

/************************************************************************
*
*   project     SCecon
*
*   file name   immdays.c
*
*   general     This file contains standard routines for calendar
*               calculations
*
************************************************************************/

/* includes ************************************************************/
#include <cldr.h>


/*,,SOH,,
*************************************************************************
*
*                Cldr_NextIMM()
*
*    interface   #include <cldr.h>
*                DATESTR Cldr_NextIMM(DATESTR *datein,
*                                     BOOLE   realIMM) ;
*
*    general     Cldr_NextIMM() calculates the next IMM date from the
*                input date.
*
*                Cldr_NextIMM() does not find the next business day if
*                the third wednesday in the appropriate months happens
*                to be a holiday.
*
*                if the input date is an IMM date the following is
*                found.
*
*                IMM days are the third wednesday in the months March,
*                June, September and December, however, we allow for
*                'pseudo' IMM days, that are the 3'rd wednesday in any
*                month.
*
*    input       DATESTR  *datein       Pointer to the input date.
*
*                BOOLE    realIMM       Chk for real or pseudo IMM day.
*                                       True means only real IMM,
*                                       False means pseudo's allowed.
*
*    output
*
*    returns     the next IMM date as DATESTR.
*
*    diagnostics
*
*    see also    Cldr_DateIsIMM()
*
*    wrapper     AP
*
*************************************************************************
,,EOH,,*/


DATESTR Cldr_NextIMM(DATESTR* datein, BOOLE realIMM)
{
    DATESTR date, dateimm ;
    BOOLE   found ;
    INTI    rem ;

    /* warning avoidance */
    memset(&dateimm, 0, sizeof(dateimm));

    found = False ;
    if (realIMM == True)
        rem = datein->m - (datein->m / 3) * 3 ;
    else
        rem = 0 ;

    if (rem == 0)
    {
        /* Now are we positively in an IMM month - so find the 3'rd
           wednesday in the month */
        date = *datein ;
        date.d = 1 ;

        while (Cldr_Weekday(&date) != 3)
            ++date.d ;
        dateimm = Cldr_AddDays(&date, (INTL ) 14, ACTACT, NULL) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */

        /* Are we before the 3'rd wednesday in the month (strictly less) */
        if (Cldr_DateLT(datein, &dateimm) == True)
            found = True ;
    }

    if (found == False)
    {
        /* We are after the last 3'rd wednesday, so find the next IMM month */
        if (realIMM == True)
            date = Cldr_AddMonths(datein, 3 - rem, SAME) ;
        else
            date = Cldr_AddMonths(datein, 1, SAME) ;

        date.d = 1 ;

        /* Find first coming wednesday and add 14 days to this */
        while (Cldr_Weekday(&date) != 3)
            ++date.d ;

        dateimm = Cldr_AddDays(&date, (INTL) 14, ACTACT, NULL) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
    }

    return dateimm ;
}


/*,,SOH,,
*************************************************************************
*
*                Cldr_DateIsIMM()
*
*    interface   #include <cldr.h>
*                BOOLE Cldr_DateIsIMM(DATESTR *datein,
*                                     BOOLE   realIMM) ;
*
*    general     Cldr_DateIsIMM() checks whether a given date is an
*                IMM date. There is no check on holidays or business
*                days.
*
*                IMM days are the third wednesday in the months March,
*                June, September and December, however, we allow for
*                'pseudo' IMM days, that are the 3'rd wednesday in any
*                month.
*
*    input       DATESTR  *datein       Pointer to the input date.
*
*                BOOLE    realIMM       Chk for real or pseudo IMM day.
*                                       True means only real IMM,
*                                       False means pseudo's allowed.
*
*    output
*
*    returns     True if the date is an IMM day otherwise False.
*
*    diagnostics
*
*    see also    Cldr_NextIMM()
*
*    wrapper     AP
*
*************************************************************************
,,EOH,,*/


BOOLE Cldr_DateIsIMM(DATESTR* datein, BOOLE realIMM)
{
    DATESTR date, date1 ;
    INTI    rem ;

    if (realIMM == True)
        rem = datein->m - (datein->m / 3) * 3 ;
    else
        rem = 0 ;

    if (rem != 0)
        return False ;

    /* We are in an IMM month - now find the actual IMM day in this month */
    date = *datein ;
    date.d = 1 ;

    while (Cldr_Weekday(&date) != 3)
        ++date.d ;
    date1 = Cldr_AddDays(&date, (INTL) 14, ACTACT, NULL) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */

    if (Cldr_DateEQ(datein, &date1) == True)
        return True ;
    else
        return False ;
}


/*,,SOH,,
*************************************************************************
*
*                Cldr_IMMInMonth()
*
*    interface   #include <cldr.h>
*                DATESTR Cldr_IMMInMonth(DATESTR *datein) ;
*
*    general     Cldr_IMMInMonth() calculates the IMM BA date
*                in the same month as the input date.
*
*    input       DATESTR  *datein       Pointer to the input date.
*
*    output
*
*    returns     the date as DATESTR.
*
*    diagnostics
*
*    see also    Cldr_NextIMM()
*
*************************************************************************
,,EOH,,*/


DATESTR Cldr_IMMInMonth(DATESTR* datein)
{
    DATESTR d1, d2 ;

    d1   = *datein;
    d1.d = 1 ;
    d2   = Cldr_NextIMM(&d1, False) ;

    return d2 ;
}


/*,,SOH,,
*************************************************************************
*
*                Cldr_NextCAD_BA()
*
*    interface   #include <cldr.h>
*                DATESTR Cldr_NextCAD_BA(DATESTR *datein,
*                                        BOOLE   realCAD_BA) ;
*
*    general     cldr_nextCA_BA() calculates the next Canadian BA date
*                from the input date.
*
*                Cldr_NextCAD_BA() does not find the next business day
*                if CAD BA day in the appropriate months happens
*                to be a holiday.
*
*                if the input date is an CAD BA date the following is
*                found.
*
*                CAD BA days are the mondays 2 days prior to the third
*                wednesdays in the months March, June, September and
*                December, however, we allow for 'pseudo' CAD BA days,
*                that are the 3'rd wednesday in any month.
*
*    input       DATESTR  *datein       Pointer to the input date.
*
*                BOOLE    realCAD_BA    Chk for real or pseudo BA day.
*                                       True means only real CAD BA,
*                                       False means pseudo's allowed.
*
*    output
*
*    returns     the next CAD BA date as DATESTR.
*
*    diagnostics
*
*    see also    Cldr_DateIsCAD_BA()
*
*    wrapper     AP
*
*************************************************************************
,,EOH,,*/


DATESTR Cldr_NextCAD_BA(DATESTR* datein, BOOLE realCAD_BA)
{
    DATESTR tmp, dateCAD_BA ;

    if (Cldr_DateIsCAD_BA(datein, realCAD_BA) == True)
        tmp = Cldr_AddDays(datein, 2, ACTACT, NULL) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
    else
        tmp = *datein ;

    dateCAD_BA = Cldr_NextIMM(&tmp, realCAD_BA) ;
    dateCAD_BA = Cldr_AddDays(&dateCAD_BA, - (IN32) 2, ACTACT, NULL) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */

    /* This only happens if datein is between CAD_BA date and
       IMM in the month */
    if (Cldr_DateLT(&dateCAD_BA, &tmp) == True)
    {
        tmp        = Cldr_AddDays(datein, 2, ACTACT, NULL) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
        dateCAD_BA = Cldr_NextIMM(&tmp, realCAD_BA) ;
        dateCAD_BA = Cldr_AddDays(&dateCAD_BA, - (IN32) 2, ACTACT, NULL) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
    }

    return dateCAD_BA ;
}


/*,,SOH,,
*************************************************************************
*
*                Cldr_DateIsCAD_BA()
*
*    interface   #include <cldr.h>
*                BOOLE Cldr_DateIsCAD_BA(DATESTR *datein,
*                                        BOOLE   realCAD_BA) ;
*
*    general     Cldr_DateIsCAD_BA() checks whether a given date is an
*                CAD BA date. There is no check on holidays or business
*                days.
*
*                CAD BA days are the mondays 2 days prior to the third
*                wednesdays in the months March, June, September and
*                December, however, we allow for 'pseudo' CAD BA days,
*                that are the 3'rd wednesday in any month.
*
*    input       DATESTR  *datein       Pointer to the input date.
*
*                BOOLE    realCAD_BA    Chk for real or pseudo CAD_BA day*
*                                       True means only real CAD_BA,
*                                       False means pseudo's allowed.
*
*    output
*
*    returns     True if the date is an CAD_BA day otherwise False.
*
*    diagnostics
*
*    see also    Cldr_NextCAD_BA()
*
*    wrapper     AP
*
*************************************************************************
,,EOH,,*/


BOOLE Cldr_DateIsCAD_BA(DATESTR* datein, BOOLE realCAD_BA)
{
    DATESTR date, date1 ;
    INTI    rem ;

    if (realCAD_BA == True)
        rem = datein->m - (datein->m / 3) * 3 ;
    else
        rem = 0 ;

    if (rem != 0)
        return False ;

    /* We are in an CAD_BA month - find the actual CAD_BA day in this month */
    date   = *datein ;
    date.d = 1 ;

    while (Cldr_Weekday(&date) != 3)
        ++date.d ;

    date1 = Cldr_AddDays(&date, (INTL) 14, ACTACT, NULL) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
	date1 = Cldr_AddDays(&date1, -(INTL)2, ACTACT, NULL);  	/* PMSTA-22396 - SRIDHARA � 160502 */

    if (Cldr_DateEQ(datein, &date1) == True)
        return True ;
    else
        return False ;
}


/*,,SOH,,
*************************************************************************
*
*                Cldr_CAD_BAInMonth()
*
*    interface   #include <cldr.h>
*                DATESTR Cldr_CAD_BAInMonth(DATESTR *datein) ;
*
*    general     Cldr_CAD_BAInMonth() calculates the Canadian BA date
*                in the same month as the input date.
*
*                Cldr_CAD_BAInMonth() does not find the next business
*                day if CAD BA day in the appropriate months happens
*                to be a holiday.
*
*                if the input date is an CAD BA date the it is returned
*
*                CAD BA days are the mondays 2 days prior to the third
*                wednesdays in the months March, June, September and
*                December, however, we allow for 'pseudo' CAD BA days,
*                that are the 3'rd wednesday in any month.
*
*    input       DATESTR  *datein       Pointer to the input date.
*
*    output
*
*    returns     the CAD BA date as DATESTR.
*
*    diagnostics
*
*    see also    Cldr_NextCAD_BA()
*
*************************************************************************
,,EOH,,*/


DATESTR Cldr_CAD_BAInMonth(DATESTR* datein)
{
    DATESTR d1, d2 ;

    d1   = *datein ;
    d1.d = 1 ;
    d2   = Cldr_NextCAD_BA(&d1, False) ;

    return d2 ;
}


/*,,SOH,,
*************************************************************************
*
*                Cldr_NextIMM_ZAR()
*
*    interface   #include <cldr.h>
*                DATESTR Cldr_NextIMM_ZAR(DATESTR *datein,
*                                         BOOLE   realIMM) ;
*
*    general     The routine calculates the next IMM (ZAR)date from the
*                input date.
*
*                See SEQCONV for doc on IMM_ZAR
*
*    input       DATESTR  *datein       Pointer to the input date.
*
*                BOOLE    realIMM       Chk for real or pseudo IMM day.
*                                       True means only real IMM,
*                                       False means pseudo's allowed.
*
*    output
*
*    returns     the next IMM date as DATESTR.
*
*    diagnostics
*
*    see also    Cldr_DateIsIMM_ZAR()
*
*************************************************************************
,,EOH,,*/


DATESTR Cldr_NextIMM_ZAR(DATESTR* datein, BOOLE realIMM)
{
    DATESTR date, dateimm ;
    BOOLE   found ;
    INTI    rem ;

    /* warning avoidance */
    memset(&dateimm, 0, sizeof(dateimm));

    found = False ;
    if (realIMM == True)
        rem = (1 + datein->m) - ((1 + datein->m) / 3) * 3 ;
    else
        rem = 0 ;

    if (rem == 0)
    {
        /* Now are we positively in an IMM (ZAR) month -
           so find the 3'rd thursday in the month */
        date   = *datein ;
        date.d = 1 ;

        while (Cldr_Weekday(&date) != 4)
            ++date.d ;
        dateimm = Cldr_AddDays(&date, (INTL) 14, ACTACT, NULL) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */

        /* Are we before the 3'rd thursday in the month (strictly less) */
        if (Cldr_DateLT(datein, &dateimm) == True)
            found = True ;
    }

    if (found == False)
    {
        /* We are after the last 3'rd thursday, so find the next IMM month */
        if (realIMM == True)
            date = Cldr_AddMonths(datein, 3 - rem, SAME) ;
        else
            date = Cldr_AddMonths(datein, 1, SAME) ;

        date.d = 1 ;

        /* Find first coming thursday and add 14 days to this */
        while (Cldr_Weekday(&date) != 4)
            ++date.d ;

		dateimm = Cldr_AddDays(&date, (INTL)14, ACTACT, NULL);  	/* PMSTA-22396 - SRIDHARA � 160502 */
    }

    return dateimm ;
}


/*,,SOH,,
*************************************************************************
*
*                Cldr_DateIsIMM_ZAR()
*
*    interface   #include <cldr.h>
*                BOOLE Cldr_DateIsIMM_ZAR(DATESTR *datein,
*                                         BOOLE   realIMM) ;
*
*    general     The routine checks whether a given date is an IMM
*                (ZAR) date. There is no check on holidays or business
*                days.
*
*                See SEQCONV for doc on IMM_ZAR
*
*    input       DATESTR  *datein       Pointer to the input date.
*
*                BOOLE    realIMM       Chk for real or pseudo IMM day.
*                                       True means only real IMM,
*                                       False means pseudo's allowed.
*
*    output
*
*    returns     True if the date is an IMM day otherwise False.
*
*    diagnostics
*
*    see also    Cldr_NextIMM_ZAR()
*
*************************************************************************
,,EOH,,*/


BOOLE Cldr_DateIsIMM_ZAR(DATESTR* datein, BOOLE realIMM)
{
    DATESTR date, date1 ;
    INTI    rem ;

    if (realIMM == True)
        rem = 1 + datein->m - ((1 + datein->m) / 3) * 3 ;
    else
        rem = 0 ;

    if (rem != 0)
        return False ;

    /* We are in an IMM_ZAR month - now find the actual IMM_ZAR day
       in this month */
    date = *datein ;
    date.d = 1 ;

    while (Cldr_Weekday(&date) != 4)
        ++date.d ;
	date1 = Cldr_AddDays(&date, (INTL)14, ACTACT, NULL);  	/* PMSTA-22396 - SRIDHARA � 160502 */

    if (Cldr_DateEQ(datein, &date1) == True)
        return True ;
    else
        return False ;
}


/*,,SOH,,
*************************************************************************
*
*                Cldr_IMM_ZARInMonth()
*
*    interface   #include <cldr.h>
*                DATESTR Cldr_IMM_ZARInMonth(DATESTR *datein) ;
*
*    general     The routine calculates the IMM (ZAR) date
*                in the same month as the input date.
*
*                See SEQCONV for doc on IMM_ZAR
*
*    input       DATESTR  *datein       Pointer to the input date.
*
*    output
*
*    returns     the date as DATESTR.
*
*    diagnostics
*
*    see also    Cldr_NextIMM_ZAR()
*
*************************************************************************
,,EOH,,*/


DATESTR Cldr_IMM_ZARInMonth(DATESTR* datein)
{
    DATESTR d1, d2 ;

    d1   = *datein;
    d1.d = 1 ;
    d2   = Cldr_NextIMM_ZAR(&d1, False) ;

    return d2 ;
}


/*,,SOH,,
*************************************************************************
*
*                Cldr_NextROLL()
*
*    interface   #include <cldr.h>
*                DATESTR Cldr_NextROLL(DATESTR  *in,
*                                      SEQCONV  roll,
*                                      PERIOD   *per,
*                                      CALCONV  cal,
*                                      EOMCONV  eom,
*                                      HOLI_STR *holi) ;
*
*    general     The function adds a period to a date given a convention*
*                for how to calculate next roll date.
*
*                The input date reflects the roll convention.
*
*                roll           inputdate (in)       Holi Adjust
*                ------------------------------------------------
*                ANCHOR         original issue           No
*                ANCHORSHIFT    original issue           No
*                ANCHORBACK     maturity                 No
*                CHAIN          previous rolldate        Yes
*                IMM            previous rolldate        No
*                IMM_ZAR        previous rolldate        No
*                CAD_BA         previous rolldate        No
*                LASTBUS        previous rolldate        Yes
*                TAM_T4M        previous rolldate        No
*
*                The routine does not handle odd periods. For a routine
*                that handles all oddities see Cflw_Paydays().
*
*    input       DATESTR   *in          Pointer to the start date.
*
*                SEQCONV   roll         The roll convention
*
*                PERIOD    *per         The period
*                                       Set to NULL if simple snapping.
*
*                CALCONV   cal          The calendar convention.
*
*                EOMCONV   eom          The end of month convention.
*
*                HOLI_STR  *holi        Holiday info
*
*    output
*
*    returns     The next roll date
*
*    diagnostics
*
*    see also
*
*************************************************************************
,,EOH,,*/

DATESTR Cldr_NextROLL(DATESTR* in,
                         SEQCONV  roll,
                         PERIOD*   per,
                         CALCONV  cal,
                         EOMCONV  eom,
                         HOLI_STR* holi)
{
    DATESTR out ;

    out = Cldr_AddPeriod(in, per, cal, eom, holi) ;

    switch (roll)
    {
        case ANCHOR:
        case ANCHORSHIFT:
        case ANCHORBACK:
            break ;

        case CHAIN:
            out = Cldr_NextBusinessDate(&out, holi) ;
            break ;

        case IMM:
            out = Cldr_IMMInMonth(&out) ;
            break ;

        case IMM_ZAR:
            out = Cldr_IMM_ZARInMonth(&out) ;
            break ;

        case CAD_BA:
            out = Cldr_CAD_BAInMonth(&out) ;
            break ;

        case LASTBUS:
            out = Cldr_LastBusinessDay(&out, holi) ;
            break ;

        case TAM_T4M:

            if (out.d > 15)
            {
                out.d = 1 ;
                out = Cldr_AddMonths(&out, 1, SAME) ;
            }
            else
                out.d = 1 ;

            break ;
    }

    return out ;
}

/* SCID @(#)testtvmu.c	1.5 (SimCorp) 99/02/19 14:17:13 */

/************************************************************************
*
*   project     SCecon
*
*   this program tests the routines in the time value of money module
*   of SCecon (unit operations).
*
************************************************************************/

/*** includes ***********************************************************/
#include <string.h>
#include <tvmunit.h>
#include <stdlib.h>
#include <stdio.h>
#include <scalloc.h>
#include <str2conv.h>
#include <ioconv.h>


INTI tvmutest(char* txa, FILE* in, FILE* out)
{
    char    txb[25], txpl[120] ;
    FL64    acc, fexp1, fres1, y1, grate, t1, t3, r ;
    INTI    diff, qb ;
    IRRCONV irr, irr1 ;
    int     i1 ;
    DATESTR start, end ;
    CALCONV cal, cal1 ;
    PMTFREQ f, f1 ;

    acc   = 0.00001 ;
    diff = -1 ;

    if (!strcmp(txa, "TVMunit_Mair()") )
    {
        fscanf(in, "%lf %lf %lf %lf %lf %s", &fexp1, &y1, &t1, &grate, &t3,
                                                                      txpl);
        fres1 = TVMunit_Mair(y1, t1, grate, t3);
        diff = (fabs(fexp1 - fres1) > acc) ;

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   yield             %8.5lf\n", y1) ;
        fprintf(out,"   term              %8.5lf\n", t1) ;
        fprintf(out,"   reinvestment rate %8.5lf\n", grate) ;
        fprintf(out,"   maturity          %8.5lf\n", t3) ;
        fprintf(out, "   result is %8lf ; expected is %8lf\n", fres1, fexp1) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }

    else if (!strcmp(txa, "TVMunit_Yield2Yield()") )
    {
        fprintf(out,"testing %s\n", txa) ;
        fexp1 = Read_FL64(in, out, "   Expected Rate    ");
        start = Read_DATESTR(in, out, "   Start Date       ");
        end   = Read_DATESTR(in, out, "   Start Date       ");
        r     = Read_FL64(in, out, "   Input Rate       ");
        irr   = Read_IRRCONV(in, out, "   Irr1             ");
        f     = Read_PMTFREQ(in, out, "   Freq1            ");
        cal   = Read_CALCONV(in, out, "   CalConv1         ");
        irr1  = Read_IRRCONV(in, out, "   Irr2             ");
        f1    = Read_PMTFREQ(in, out, "   Freq2            ");
        cal1  = Read_CALCONV(in, out, "   CalConv2         ");

        fres1 = TVMunit_Yield2Yield(&start, &end, r, irr, f, cal, 
                                    irr1, f1, cal1) ;
        diff = Write_SingleDiff(True, True, fres1, fexp1, 0.00001, out) ;

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }

    else if (!strcmp(txa, "TVMunit_NPV()") )
    {
        fscanf(in, "%lf %lf %lf %s %d %s", &fexp1, &t1, &y1, txb, &i1, txpl);
        qb = (INTI) i1 ;
        irr = Str2IRRCONV(txb) ;
        fres1 = TVMunit_NPV(t1, y1, irr, qb) ;
        diff = (fabs(fexp1 - fres1) > acc) ;

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   yield          %8.5lf\n", y1) ;
        fprintf(out,"   term           %8.5lf\n", t1) ;
        fprintf(out,"   quoting basis  %8d\n", qb) ;
        fprintf(out,"   irr convention %s\n", txb) ;
        fprintf(out,
          "   result is %8lf ; expected is %8lf\n",
          fres1, fexp1) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }
    else if (!strcmp(txa, "TVMunit_Yield()") )
    {
        fscanf(in, 
          "%lf %lf %lf %s %d %s",
          &fexp1, &y1, &t1, txb, &i1, txpl);
        qb = (INTI) i1 ;
        irr = Str2IRRCONV(txb) ;
        fres1 = TVMunit_Yield(y1, t1, irr, qb) ;
        diff = (fabs(fexp1 - fres1) > acc) ;

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   present value  %8.5lf\n", y1) ;
        fprintf(out,"   term           %8.5lf\n", t1) ;
        fprintf(out,"   quoting basis  %8d\n", qb) ;
        fprintf(out,"   irr convention %s\n", txb) ;
        fprintf(out,
          "   result is %12.9lf ; expected is %12.9lf\n",
          fres1, fexp1) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }
    else if (!strcmp(txa, "TVMunit_Term()") )
    {
        fscanf(in, 
          "%lf %lf %lf %s %d %s",
          &fexp1, &y1, &t1, txb, &i1, txpl);
        qb = (INTI) i1 ;
        irr = Str2IRRCONV(txb) ;
        fres1 = TVMunit_Term(y1, t1, irr, qb) ;
        diff = (fabs(fexp1 - fres1) > acc) ;

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   present value  %8.5lf\n", y1) ;
        fprintf(out,"   yield          %8.5lf\n", t1) ;
        fprintf(out,"   quoting basis  %8d\n", qb) ;
        fprintf(out,"   irr convention %s\n", txb) ;
        fprintf(out,
          "   result is %8lf ; expected is %8lf\n",
          fres1, fexp1) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }

    return diff ;
}

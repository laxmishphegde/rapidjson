/* SCID @(#)sctoken.c	1.5 (SimCorp) 99/02/19 14:16:35 */

/************************************************************************
*
*   Project     SCecon
*
*   file name   rtoken.c
*
*   general     This file contains routines needed for risk token
*               manipulations
*
*    see also the satelite modules 'PRTFL' and 'SCRM'
*
************************************************************************/

/* includes    *********************************************************/
#include <scutl.h>


/*,,SOH,,
*************************************************************************
*
*               VAR_MergeRISKPOSLIST()
*
*    interface  #include <scutl.h>
*               RISKPOSLIST VAR_MergeRISKPOSLIST(
*                   RISKPOSLIST *rp1,
*                   RISKPOSLIST *rp2);
*
*    general    Merges two RISKPOSLIST adding position having the
*               same RISKTOKEN.
*
*    input      RISKPOSLIST     *rp1    Reference to a list of risk
*                                       positions.
*
*               RISKPOSLIST     *rp2    Reference to a list of risk
*                                       positions.
*
*    output
*
*    returns    RISKPOSLIST holding risk position for a list of
*               unique RISKTOKEN. If either of the input RISKPOSLIST
*               is empty the other is copied.
*               The member pointers of the returned struct is allocated
*               using Alloc_RISKTOKENARRAY() and Alloc_FL64ARRAY()
*               using the member npos as the size.
*
*    diagnostics
*
*    see also
*               Free_RISKPOSLIST().
*               VAR_SortRISKPOSLIST().
*
*    wrapper    AP
*
*************************************************************************
,,EOH,,*/

RISKPOSLIST VAR_MergeRISKPOSLIST(
    RISKPOSLIST* rp1,
    RISKPOSLIST* rp2)
{
    RISKPOSLIST rp;
    INTI i, j;
    INTIARRAY idx1, idx2;

    rp.npos = 0;
    rp.token = NULL;
    rp.pos = NULL;

      /* Ensure ordering: */
    idx1 = VAR_SortRISKPOSLIST(rp1);
    idx2 = VAR_SortRISKPOSLIST(rp2);
    Free_INTIARRAY(idx1);
    Free_INTIARRAY(idx2);

    /* Find a list of unique risk tokens: */
    rp.token = VAR_UniqueRISKTOKENARRAY(rp1->token, rp1->npos, 
                                         rp2->token, rp2->npos, &rp.npos);
    rp.pos = Alloc_FL64ARRAY(rp.npos);

    /* Add position from rp1: */
    for(i = 0; i < rp1->npos; i++)
        for(j = 0; j < rp.npos; j++)
            if (VAR_RiskTokenEQ(&rp1->token[i], &rp.token[j]) == True)
                rp.pos[j] += rp1->pos[i];

    /* Add position from rp2: */
    for(i = 0; i < rp2->npos; i++)
        for(j = 0; j < rp.npos; j++)
            if (VAR_RiskTokenEQ(&rp2->token[i], &rp.token[j]) == True)
                rp.pos[j] += rp2->pos[i];

    return rp;
}



/*,,SOH,,
*************************************************************************
*
*               VAR_RiskTokenLT()
*
*    interface  #include <scutl.h>
*               BOOLE VAR_RiskTokenLT(RISKTOKEN *rf1, RISKTOKEN *rf2)
*
*    general    Compares two risk tokens to see if the first is strictly*
*               less than the second.
*
*               The ordering is defined as lexicographic ordering on
*               the data members 'ccy' and 'rclass' with 'ccy' as the
*               more significant.
*
*               All alphabetic characters in the text strings must be
*               Str_Uppercase.
*
*    input      RISKTOKEN   *rf1    pointer to first risk token
*
*               RISKTOKEN   *rf2    pointer to second risk token
*
*    output
*
*    returns    'True' if first risk token less then second,
*               'False' otherwise
*
*    diagnostics
*
*    see also   VAR_RiskTokenEQ()
*               VAR_RiskTokenLE()
*               VAR_RiskTokenCmp()
*
*************************************************************************
,,EOH,,*/


BOOLE   VAR_RiskTokenLT(RISKTOKEN* rf1, RISKTOKEN* rf2)
{
    INTI    c ;

    /* compare ccy's */
    if ((c = strncmp(rf1->ccy, rf2->ccy, CCY_LENGTH)) < 0)
        return True ;
    else if (c > 0)
        return False ;
    /* compare rclass's iff ccy's equal */
    if (strncmp(rf1->rclass, rf2->rclass, CLASS_LENGTH) >= 0) 
        return False ;
    else 
        return True ;
}


/*,,SOH,,
*************************************************************************
*
*               VAR_RiskTokenEQ()
*
*    interface  #include <scutl.h>
*               BOOLE VAR_RiskTokenEQ(RISKTOKEN *rf1, RISKTOKEN *rf2) ;
*
*    general    Compares two risk tokens to see if they are equal.
*
*               All alphabetic characters in the text strings must be
*               Str_Uppercase.
*
*    input      RISKTOKEN   *rf1    pointer to first risk token
*
*               RISKTOKEN   *rf2    pointer to second risk token
*
*    output
*
*    returns    'True' if the two risk token are equal,
*               'False' otherwise
*
*    diagnostics
*
*    see also   VAR_RiskTokenLT()
*               VAR_RiskTokenLE()
*               VAR_RiskTokenCmp()
*
*************************************************************************
,,EOH,,*/

BOOLE VAR_RiskTokenEQ(RISKTOKEN* rf1, RISKTOKEN* rf2)
{
    /* compare ccy's */
    if (strncmp(rf1->ccy, rf2->ccy, CCY_LENGTH) || 
            strncmp(rf1->rclass, rf2->rclass, CLASS_LENGTH))
        return False ;
    else 
        return True ;
}


/*,,SOH,,
*************************************************************************
*
*               VAR_RiskTokenLE()
*
*    interface  #include <scutl.h>
*               BOOLE   VAR_RiskTokenLE(RISKTOKEN *rf1, RISKTOKEN *rf2)
*
*    general    Compares two risk tokens to see if the first is less
*               than or equal to the second.
*
*               The ordering is defined as lexicographic ordering on
*               the data members 'ccy' and 'rclass' with 'ccy' as the
*               more significant.
*
*               All alphabetic characters in the text strings must be
*               Str_Uppercase.
*
*    input      RISKTOKEN   *rf1    pointer to first risk token
*
*               RISKTOKEN   *rf2    pointer to second risk token
*
*    output
*
*    returns    'True' if first risk token less than or equal to the
*               second, 'False' otherwise
*
*    diagnostics
*
*    see also   VAR_RiskTokenEQ()
*               VAR_RiskTokenLT()
*               VAR_RiskTokenCmp()
*
*************************************************************************
,,EOH,,*/

BOOLE   VAR_RiskTokenLE(RISKTOKEN* rf1, RISKTOKEN* rf2)
{
    INTI    c ;

    /* compare ccy's */
    if ((c = strncmp(rf1->ccy, rf2->ccy, CCY_LENGTH)) < 0)
        return True ;
    else if (c > 0)
        return False ;
    /* compare rclass's iff ccy's equal */
    if (strncmp(rf1->rclass, rf2->rclass, CLASS_LENGTH) > 0) 
        return False ;
    else 
        return True ;
}


/*,,SOH,,
*************************************************************************
*
*               VAR_RiskTokenCmp()
*
*    interface  #include <scutl.h>
*               INTI    VAR_RiskTokenCmp(RISKTOKEN *rf1,
*                                        RISKTOKEN *rf2,
*                                        BOOLE     wc) ;
*
*    general    Compares two risk tokens.
*
*               This function works as an analog of the <string.h>
*               C function 'strcmp()': it compares first the 'ccy' and
*               then the 'rclass' data members of the two risk tokens
*               and returns the first non-zero difference encountered
*               ---or zero if no differences were found.
*
*               If the 'wc' toggle is 'True' character positions holding*
*               the 'WILDCARD_FOR_CHAR' (defined in VAR.H to be '?') are*
*               ignored and the comparison ends if a
*               'WILDCARD_FOR_STRING' (defined in VAR.H to be '*') is
*               encountered.
*
*    input      RISKTOKEN   *rf1    pointer to first risk token
*
*               RISKTOKEN   *rf2    pointer to second risk token
*
*               BOOLE       wc      wildcard toggle
*
*    output
*
*    returns    The first non-zero ASCII difference encountered
*               ---or zero if no differences were found.
*
*    diagnostics
*
*    see also   VAR_RiskTokenEQ()
*               VAR_RiskTokenLT()
*               VAR_RiskTokenLE()
*
*************************************************************************
,,EOH,,*/


INTI    VAR_RiskTokenCmp(RISKTOKEN* rf1, RISKTOKEN* rf2, BOOLE wc)
{
    INTI    c ;
    char    *s1, *s2 ;

    /* compare ccy's */
    s1 = rf1->ccy ;
    s2 = rf2->ccy ;
    c = (wc) ? wc_strncmp(s1, s2, CLASS_LENGTH) : 
                    strncmp(s1, s2, CCY_LENGTH) ;
    if (c)
        return c ;

    /* compare class' if ccy's equal */
    s1 = rf1->rclass ;
    s2 = rf2->rclass ;
    c = (wc) ? wc_strncmp(s1, s2, CLASS_LENGTH) : 
                    strncmp(s1, s2, CLASS_LENGTH) ;

    return c ;
}


/*,,SOH,,
*************************************************************************
*
*               VAR_RiskTokenCpy()
*
*    interface  #include <scutl.h>
*               void    VAR_RiskTokenCpy(RISKTOKEN *rt1,
*                                        RISKTOKEN *rt2) ;
*
*    general    Copies the second risk token onto the first.
*
*    input      RISKTOKEN   *rt1    pointer to first risk token
*
*               RISKTOKEN   *rt2    pointer to second risk token
*
*    output
*
*    returns
*
*    diagnostics
*
*    see also
*
*************************************************************************
,,EOH,,*/

void VAR_RiskTokenCpy(RISKTOKEN* rt1, RISKTOKEN* rt2)
{
    strncpy(rt1->ccy, rt2->ccy, sizeof(CCYCODE) - 1);           // minus one to 
    rt1->ccy[sizeof(CCYCODE) - 1] = 0;                          // ensure null termination

    strncpy(rt1->rclass, rt2->rclass, sizeof(RISKCLASS) - 1);   // minus one to
    rt1->rclass[sizeof(RISKCLASS) - 1] = 0;                     // ensure null termination
}


/*,,SOH,,
*************************************************************************
*
*               VAR_UniqueRISKTOKENARRAY()
*
*    interface  #include <scutl.h>
*               RISKTOKENARRAY VAR_UniqueRISKTOKENARRAY(
*                   RISKTOKENARRAY rt1, INTI nrt1,
*                   RISKTOKENARRAY rt2, INTI nrt2,
*                   INTI *nrt)
*
*    general    Merge two sorted arrays of unique risk tokens creating
*               a new sorted array of unique risk tokens containing the
*               risk of both the input arrays.
*
*    input      RISKTOKENARRAY  rt1      array of unique risk tokens.
*
*               INTI            nrt1     size of the array (rt1).
*
*               RISKTOKENARRAY  rt2      array of unique risk tokens.
*
*               INTI            nrt2     size of the array (rt2).
*
*    output     INTI            *nrt     size of the returned array.
*
*    returns    RISKTOKENARRAY holding the unique risk tokens of
*               both arrays.
*               The returned array is allocated using
*               Alloc_RISKTOKENARRAY() using *nrt as the size.
*
*    diagnostics
*               The input arrays will be sorted if necessary.
*
*    see also
*               Free_RISKTOKENARRAY().
*               VAR_SortRISKTOKENARRAY().
*
*************************************************************************
,,EOH,,*/

RISKTOKENARRAY VAR_UniqueRISKTOKENARRAY(
    RISKTOKENARRAY rt1, INTI nrt1,
    RISKTOKENARRAY rt2, INTI nrt2,
    INTI* nrt)
{
    RISKTOKENARRAY rt ;
    INTI           count, diff, i, i1, i2 ;
    BOOLE          stop, lstTokenSet, copy ;
    INTIARRAY      sortindex1, sortindex2 ;
    RISKTOKEN      lstToken, candidate;


    /* Initialise */
    rt    = NULL ;
    count = i1 = i2 = 0 ;
    stop  = False ;
    lstTokenSet = False;

    sortindex1 = VAR_SortRISKTOKENARRAY(rt1, nrt1);
    sortindex2 = VAR_SortRISKTOKENARRAY(rt2, nrt2);
    Free_INTIARRAY(sortindex1);
    Free_INTIARRAY(sortindex2);

    count = 0;
    while (!stop)
    {
        /* investigate both arrays: */
        if (i1 < nrt1 && i2 < nrt2)
        {
            diff = VAR_RiskTokenCmp(&rt1[i1], &rt2[i2], False);

            if (diff < 0)
            {
                VAR_RiskTokenCpy(&candidate, &rt1[i1]);
                i1++;
            }
            else if (diff == 0)
            {
                VAR_RiskTokenCpy(&candidate, &rt1[i1]);
                i1++;
                i2++;
            }
            else
            {
                VAR_RiskTokenCpy(&candidate, &rt2[i2]);
                i2++;
            }
        }
        else if (i1 < nrt1)
        {
            VAR_RiskTokenCpy(&candidate, &rt1[i1]);
            i1++;
        }
        else if (i2 < nrt2)
        {
            VAR_RiskTokenCpy(&candidate, &rt2[i2]);
            i2++;
        }
        else
            stop = True;

        if (!stop)
        {
          if (lstTokenSet)
          {
            copy = VAR_RiskToken_Unique_cpy(&lstToken, &candidate);
            if (copy)
              count++;
          }
          else
          {
            VAR_RiskTokenCpy(&lstToken, &candidate);
            lstTokenSet = True;
            count++;
          }
        }
    }

    *nrt = count;
    rt = Alloc_RISKTOKENARRAY(count);

    i = i1 = i2 = 0;
    lstTokenSet = False;
    while (i < count)
    {
        /* investigate both arrays: */
        if (i1 < nrt1 && i2 < nrt2)
        {
            diff = VAR_RiskTokenCmp(&rt1[i1], &rt2[i2], False);

            if (diff < 0)
            {
                VAR_RiskTokenCpy(&candidate, &rt1[i1]);
                i1++;
            }
            else if (diff == 0)
            {
                VAR_RiskTokenCpy(&candidate, &rt1[i1]);
                i1++;
                i2++;
            }
            else
            {
                VAR_RiskTokenCpy(&candidate, &rt2[i2]);
                i2++;
            }
        }
        else if (i1 < nrt1)
        {
            VAR_RiskTokenCpy(&candidate, &rt1[i1]);
            i1++;
        }
        else 
        {
            VAR_RiskTokenCpy(&candidate, &rt2[i2]);
            i2++;
        }    

        if (lstTokenSet)
        {
          copy = VAR_RiskToken_Unique_cpy(&lstToken, &candidate);
          VAR_RiskTokenCpy(&rt[i], &candidate);
          if (copy)
            i++;
        }
        else
        {
          VAR_RiskTokenCpy(&rt[i], &candidate);
          VAR_RiskTokenCpy(&lstToken, &candidate);
          lstTokenSet = True;
          i++;
        }
    }

    return rt;
}

/*,,SOH,,
*************************************************************************
*
*               VAR_SortRISKTOKENARRAY()
*
*    interface  #include <scutl.h>
*               INTIARRAY  VAR_SortRISKTOKENARRAY(RISKTOKENARRAY rp,
*                                                 INTI           nrp);
*
*    general    Sorts a RISKTOKENARRAY (using a heap sort).
*
*               The ordering is defined as lexicographic ordering on
*               the data members 'ccy' and 'rclass' with 'ccy' as the
*               more significant.
*
*
*    input      RISKTOKENARRAY  rp      array to be sorted
*
*               INTI            nrp     size of array
*
*    output
*
*    returns    INTIARRAY holding sorting mapping: the index n entry of
*               this array holds the original position (ie, before
*               sorting) of the index n entry of the sorted array.
*
*    diagnostics
*               On termination the input RISKTOKENARRAY is sorted
*
*    see also   VAR_SortVARCOVMATRIX()
*               VAR_SortRISKPOSLIST()
*
*************************************************************************
,,EOH,,*/

INTIARRAY   VAR_SortRISKTOKENARRAY(RISKTOKENARRAY rp,
                                   INTI             nrp)
{
    UN32        i, j, ii, k, ix ;
    RISKTOKEN   r ;
    INTIARRAY   idx ;

    /* allocate for output */
    idx = Alloc_INTIARRAY(nrp) ;

    /* initialise sorting mapping */
    for (i = 0; i < (UN32) nrp; i++)
        idx[i] = i ;

    if (nrp <= 1)
        return idx ;  /* nothing to do */

    /* we use a heap sort */
    k = (UN32) nrp >> 1 ;
    ii = (UN32) nrp - 1 ;

    for (;;)
    {
        if (k > 0)
        {
            r = rp[--k] ;
            ix = idx[k] ;
        }
        else
        {
            r = rp[ii] ;
            ix = idx[ii] ;
            rp[ii] = rp[0] ;
            idx[ii] = idx[0] ;
            if (--ii == 0)
            {
                rp[0] = r ;
                idx[0] = ix ;
                break ;
            }
        }

        i = k ;
        j = k + k + 1 ;
        while (j <= ii)
        {
            if (j < ii && VAR_RiskTokenLT(&rp[j], &rp[j+1]))
                j++ ;
            if (VAR_RiskTokenLT(&r, &rp[j]))
            {
                rp[i] = rp[j] ;
                idx[i] = idx[j] ;
                i = j ;
                j += 1 ;
                j <<= 1 ;
                j -= 1 ;
            }
            else
                j = ii + 1 ;
        }
        rp[i] = r ;
        idx[i] = ix ;
    }
    return idx ;
}


/*,,SOH,,
*************************************************************************
*
*               VAR_SortRISKPOSLIST()
*
*    interface  #include <scutl.h>
*               INTIARRAY   VAR_SortRISKPOSLIST(RISKPOSLIST *pos)
*
*    general    Sorts the RISKTOKENARRAY member, 'cov->token', of a
*               RISKPOSLIST and permutes volatility array accordingly.
*
*    input      RISKPOSLIST     *pos    pointer to struct holding
*                                       list of risk positions
*
*    output
*
*    returns    Returns an array of indices indicating in which
*               order the entries of pos->token would be if they were
*               sorted ascendingly.
*               The array is allocated as
*
*                  Alloc_INTIARRAY(pos->npos);
*
*    diagnostics
*               On termination the RISKTOKENARRAY member of the input
*               RISKPOSLIST has been sorted and the FL64ARRAY member
*               permuted accordingly.
*
*    see also   VAR_SortRISKTOKENARRAY()
*               VAR_SortVARCOVMATRIX()
*
*    wrapper    AP
*
*************************************************************************
,,EOH,,*/


INTIARRAY   VAR_SortRISKPOSLIST(RISKPOSLIST* pos)
{
    INTIARRAY   idx ;

    /* sort the RISKTOKENs */
    idx = VAR_SortRISKTOKENARRAY(pos->token, pos->npos) ;

    /* permute the FL64ARRAY accordingly */
    permute_FL64ARRAY(pos->pos,  pos->npos, idx) ;

    return idx ;
}



/*,,SOH,,
*************************************************************************
*
*               Free_RISKPOSLIST()
*
*    interface  #include <scutl.h>
*               void Free_RISKPOSLIST(RISKPOSLIST* rp);
*
*    general    Frees all pointers in rp - not rp itself.
*
*    input      RISKPOSLIST   *rp        Risk Position list
*                                          properly allocated.
*
*    output
*
*    returns
*
*    diagnostics
*
*    see also
*
*************************************************************************
,,EOH,,*/

void Free_RISKPOSLIST(RISKPOSLIST* rp)
{
  Free_RISKTOKENARRAY(rp->token) ;
  Free_FL64ARRAY(rp->pos) ;
}




/* extension of 'string.h' C library function 'strncmp' to support 
   wild cards in the input character string arguments */

INTI    wc_strncmp(char* s1, char* s2, INTI len)
{
    INTI    i ;

    for (i = 0; (*s1 != WILDCARD_FOR_STRING && *s2 != WILDCARD_FOR_STRING) && 
           (*s1 == WILDCARD_FOR_CHAR || *s2 == WILDCARD_FOR_CHAR || 
            *s1 == *s2); i++, s1++, s2++)
        if (i >= len || *s1 == '\0')
            return 0 ;
     
    return (*s1 == WILDCARD_FOR_STRING || *s2 == WILDCARD_FOR_STRING) ? 0 : 
                *s1 - *s2 ;
}


INTI    wc_strcmp(char* s1, char* s2) 
{
    for (; (*s1 != WILDCARD_FOR_STRING && *s2 != WILDCARD_FOR_STRING) && 
           (*s1 == WILDCARD_FOR_CHAR || *s2 == WILDCARD_FOR_CHAR || *s1 == *s2);
            s1++, s2++)
        if (*s1 == '\0')
            return 0 ;
     
    return (*s1 == WILDCARD_FOR_STRING || *s2 == WILDCARD_FOR_STRING) ? 0 : 
                *s1 - *s2 ;
}
        
/*
*************************************************************************
*
*               permute_FL64ARRAY()
*
*    interface  #include <scutl.h>
*               void    permute_FL64ARRAY(FL64ARRAY     a,
*                                         INTI          n,
*                                         INTIARRAY     idx) ;
*
*    general    Permute entries of FL64ARRAY according to given
*               permutation.
*
*               The routine performs a genuine 'in-place' permutation
*               with no internal memory allocation.
*
*    input      FL64ARRAY   a   array to be permuted
*
*               INTI        n   size of array(s)
*
*               INTIARRAY   idx permutation: the index 'idx[i]' entry
*                               of 'a' will be moved to index 'i'.
*
*    output                 On termination the input FL64ARRAY
*                           is permuted
*
*    returns
*
*    diagnostics
*
*    see also
*
*************************************************************************
*/


void    permute_FL64ARRAY(FL64ARRAY a,  INTI n, INTIARRAY  idx)
{
    INTI        i, k ;
    FL64        tmp ;
    BOOLEARRAY  chk ;

    /* allocate for and initialize check list */
    chk = Alloc_BOOLEARRAY(n) ;
    for (i = 0; i < n; i++)
        chk[i] = (i == idx[i]) ? True : False ; 

    /* initialise permutation */
    for (k = 0; k < n && chk[k]; k++)
        ;
    if (k == n)
    {
        Free_BOOLEARRAY(chk) ;
        return ;
    }
    tmp = a[k] ;

    /* start moving */
    for (;;)
    {
        a[k] = a[idx[k]] ;
        chk[k] = True ;
        k = idx[k] ;
        if (chk[idx[k]] == True)
        {
            /* reset for new cyclic permutation */
            a[k] = tmp ;
            chk[k] = True ;
            for (k = 0; k < n && chk[k]; k++)
                ;
            if (k == n) 
                break ;
            tmp = a[k] ;
        }
    }

    /* free */
    Free_BOOLEARRAY(chk) ;
}


/*
..
 Copy newToken to oldToken unless they are identical.
 Returns true if newToken and oldToken are different.
*/


BOOLE VAR_RiskToken_Unique_cpy(
    RISKTOKEN* oldToken,
    RISKTOKEN* newToken)
{

    BOOLE eq;

    eq = VAR_RiskTokenEQ(oldToken, newToken);

    if (eq == False)
      VAR_RiskTokenCpy(oldToken, newToken);          

    return !eq;
}


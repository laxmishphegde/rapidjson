#include <sccsid.h>
SCCSID(powell_c,
  "@(#)powell.c	1.26 (SimCorp) 99/10/28 14:17:19")

/************************
Implementation of gradient-less maximisation routines:

  Powell: multi-variate
  Brent:  uni-variate

*************************/

/***** includes  *****************************************************/
#include <scmath.h>

/***** defines   *****************************************************/
#define ITMAX 200


/*,,SIC,,
************************************************************************
*
*               Powell()
*
*
*    references Numerical Recipes
*
*    interface  #include <scmath.h>
*               BOOLE Powell(FL64ARRAY          x,
*                            VOIDPTR            pdata, 
*                            FL64MATRIX         xi,   
*                            INTI               n,
*                            FL64               ftol, 
*                            FL64               fmin, 
*                            POWELLPROGRESS_FCT f_prg, 
*                            BRENT_FCT          f_1dim,       
*                            POWELL_FCT         f_ndim,       
*                            INTI               *iter, 
*                            FL64               *fret, 
*                            BOOLE              *ok)
*  
*    general    This a general function for finding mimimum of a function 
*               of multiple variable using no explicit gradient information.
*               
*               The method is general purpose and can be used for
*               un-constrained optimisation when no gradient based
*               method is feasible to use.
*
*               The Powell method is a so-called direction-set method
*               using bracketing and Brent direction-search to determine
*               good directions.
*
*               The method searches in multiple directions starting at x 
*               with a given  set of directions xi.
*               The method loops a number of times until either a minimum is 
*               found or the iteration limit is exceed - in which case a 
*               warning is issued. Each loop falls into two searches:
*               - First we search along each direction in a set of directions.
*                 This set is given as input and may be set to the unit vectors.
*                 The net direction is recorded as well as the direction giving
*                 the largest function decrease.
*               - If the net direction appears to give good function decrease
*                 a search along the net direction is done. This final direction
*                 then replaces the best direction recorded above.
*
*               The prototypes of the problemspecific functions,
*               f_prg, f_1dim and f_ndim are all defined to accept
*               a VOIDPTR input as their problem specific input.
*               The input actually passed is contained in pdata,
*               so there is an additional constraint, not
*               enforced at compile time, that the VOIDPTR passed
*               to f_prg, f_1dim and f_ndim should point to the
*               same piece of data.  Typical use involves designing
*               a problem specific struct containing the entire
*               problem paremetrisation and using that in all
*               three problem specific functions.
*
*               
*    input      FL64ARRAY          x        Initial point. Upon return the 
*                                           abscissa of the minimum 
*                                           Dimension [n]. 
*               
*               VOIDPTR            pdata    Problem specific data. See above
*               
*               FL64MATRIX         xi       Initial direction set. 
*                                           Dimension [n,n] 
*               
*               INTI               n        The size of the parameter vector.
*               
*               FL64               ftol     Tolerance used to identify the 
*                                           minimum.
*               
*               FL64               fmin     Highest function value to be 
*                                           considered a minimum.
*               
*               POWELLPROGRESS_FCT f_prg    Progress report function.
*               
*               BRENT_FCT          f_1dim   Direction potential value function.
*                  
*               POWELL_FCT         f_ndim   Global potential value function.
*                  
*    output     INTI               *iter    No. of iterations used 
*                  
*               FL64               *fret    Function value at x 
*                  
*               BOOLE              *ok      Calculation status for f_1dim and 
*                                           f_ndim.
*                                           True means everything went ok.
*                                           False means something went wrong.
*
*    returns    True if the procedure achieved a minimum and False
*               if not.
*
*    diagnostics
*               Progress reporting is done using f_prg.
*
*    see also   
*
*    wrapper    
*
***********************************************************************
,,EIC,,*/
BOOLE Powell(FL64ARRAY          x,  
             VOIDPTR            pdata,
             FL64MATRIX         xi,   
             INTI               n,
             FL64               ftol, 
             FL64               fmin, 
             POWELLPROGRESS_FCT f_prg, 
             BRENT_FCT          f_1dim,       
             POWELL_FCT         f_ndim,       
             INTI               *iter, 
             FL64               *fret, 
             BOOLE              *ok)
{
  BOOLE   abort;
  INTI    i, ibig, j ;
  FL64    t, fptt, fp, del ;
  FL64    *pt, *ptt, *xit ;

  pt = Alloc_FL64ARRAY(n) ;
  ptt = Alloc_FL64ARRAY(n) ;
  xit = Alloc_FL64ARRAY(n) ;

  abort = False;
/*  SCecon_printf(SCECONPROGRESS, "P");*/

  /* Compute potential function at initial point and save the
     point */    
  *fret = (*f_ndim)(x, pdata, ok) ;
  for (j = 0; j < n; j++) 
    pt[j] = x[j] ;

  /* The grand loop */
  for (*iter = 1; *ok; (*iter)++) 

  {
    abort = (*f_prg)(pdata, *iter, *fret);
    if (abort)
      break;

/*    SCecon_printf(SCECONPROGRESS, ":");*/
    fp = (*fret) ;
    ibig = 0 ; /* This holds the index of the direction in the 
                  set of direction giving the largest decrease */
    del = 0.0 ; /* This will hold the largest ordinate decrease */

    /* Now, loop over the directions */
    for (i = 0; i < n && *ok; i++) 
    {
/*      SCecon_printf(SCECONPROGRESS, ".");*/
      for (j = 0; j < n; j++) 
        xit[j] = xi[j][i] ;
      fptt = (*fret) ;

      /* Find the minimum along current direction */
      DirectionMin_NoGrad(x, pdata, xit, n, f_1dim, fret, ok) ;
  
      /* Mark this direction if it gave the largest
         decrease so far */
      if (fabs(fptt-(*fret)) > del) 
      {
        del = fabs(fptt-(*fret)) ;
        ibig = i ;
      }
    }

    /* Did we achieve a minimum */
    if (2.0 * fabs(fp-(*fret)) <= ftol * (fabs(fp)+fabs(*fret)) 
        || fabs(*fret) < fmin) 
    {
      Free_FL64ARRAY(pt) ;
      Free_FL64ARRAY(ptt) ;
      Free_FL64ARRAY(xit) ;
      return abort;
    }

    /* Abort if iteration limit was reached */
    if (*iter == ITMAX) 
    {
      SCecon_error("Search for minimum failed", "Powell()", 
                   SCECONCONTINUE);
      *ok = False;
      break ;
    }

    for (j = 0; j < n && *ok; j++) 
    {
      ptt[j] = 2.0 * x[j] - pt[j] ; /* Extrapolated average direction 
                                       in this step */
      xit[j] = x[j] - pt[j] ;       /* The average direction 
                                       achieved in this step */
      pt[j] = x[j] ;  /* The minimum point achieved sofar */         
    }
    /* Function value at extrapolated point: */
    fptt = (*f_ndim)(ptt, pdata, ok) ; 

    /* If we got a significant decrease then search along
       the average direction for a minimum point */
    if (fptt < fp && *ok) 
    {
      t = 2.0 * (fp - 2.0 * (*fret) + fptt) * 
              SQR(fp - (*fret) - del) 
              - del * SQR(fp-fptt) ;
      if (t < 0.0) 
      {
        /* Search in average direction */
        DirectionMin_NoGrad(x, pdata, xit, n, f_1dim, fret, ok);

        /* Store the scaled direction by replacing the best direction
           determined above */
        for (j = 0; j < n && *ok; j++) 
          xi[j][ibig] = xit[j] ;
      }
    }
  }
  Free_FL64ARRAY(pt) ;
  Free_FL64ARRAY(ptt) ;
  Free_FL64ARRAY(xit) ;

  return abort;
}


#undef ITMAX

#define TOL 2.0e-4

/*,,SIC,,
************************************************************************
*
*               DirectionMin_NoGrad()
*
*
*    references Numerical Recipes
*
*    interface  #include <scmath.h>
*               void DirectionMin_NoGrad(FL64ARRAY point,
*                           VOIDPTR     pdata,
*                           FL64ARRAY   direction,
*                           INTI        n,
*                           BRENT_FCT   f_1dim,
*                           FL64        *fret,
*                           BOOLE       *ok)
*  
*    general    This a general function for finding mimimum of a function 
*               in a given direction.
*               
*               The method is general purpose and can be used for
*               un-constrained optimisation when no gradient based
*               method is feasible to use.
*
*               To bracket the minium, the method use Golden Section.
*               Brents method is used for final minimization in the bracket.
*  
*               Finds the direction minimum from the point 'point' in the 
*               direction 'direction' of the function 'f_1dim'.
*               The minimum is found by first bracketing it to a small 
*               interval using the BracketMin_NoGrad() function and then 
*               locating the minimum within that interval using the function 
*               Brent(). Upon finding the minimum 'point' holds the abcissa 
*               where 'f_1dim' attains the minimum and the 'direction' the 
*               direction scaled to the length required to get to the minimum 
*               from the old value of 'point'. 
*               
*    input      FL64ARRAY          point    Initial point. Upon return the 
*                                           abscissa of the minimum 
*                                           Dimension [n]. 
*               
*               VOIDPTR            pdata    Problem specific data 
*               
*               FL64MATRIX         direction Initial direction set. 
*                                           Dimension [n,n] 
*               
*               INTI               n        The size of the parameter vector.
*               
*               BRENT_FCT          f_1dim   Direction potential value function.
*                  
*    output     FL64               *fret    Function value at point 
*                  
*               BOOLE              *ok      Calculation status for f_1dim.
*                                           True means everything went ok.
*                                           False means something went wrong.
*
*    returns    True if the procedure achieved a minimum and False
*               if not.
*
*    diagnostics
*
*    see also   
*
*    wrapper    
*
***********************************************************************
,,EIC,,*/
void DirectionMin_NoGrad(FL64ARRAY point,
            VOIDPTR     pdata,
            FL64ARRAY   direction,
            INTI        n,
            BRENT_FCT   f_1dim,
            FL64        *fret,
            BOOLE       *ok)
{
  INTI j;
  FL64 xx, xmin, fx, fb, fa, bx, ax;

  ax = 0.0;
  xx = 1.0;
  bx = 2.0;

  /* Bracket the minimum in one dimension by the points
     ax, xx, and bx */
  BracketMin_NoGrad(&ax, &xx, &bx, &fa, &fx, &fb, pdata, f_1dim, 
                    point, direction, ok);

  /* Apply Brent method for one-dimensional minimization 
     wihtin the interval [ax;bx] */
  *fret = Brent(ax, xx, bx, f_1dim, pdata, point, direction, TOL, &xmin, ok);

  /* Scale xi to the size minimizing func 
     and add this to x */ 
  for (j = 0; j < n; j++) 
  {
    direction[j] *= xmin;
    point[j] += direction[j];
  }
}

#undef TOL

#define GOLD 1.618034
#define GLIMIT 100.0
#define TINY 1.0e-20
#define SIGN(a,b) ((b) > 0.0 ? fabs(a) : -fabs(a))
#define SHFT(a,b,c,d) (a)=(b);(b)=(c);(c)=(d);

/* Direction bracketing of a minimum using Golden Section
   and parabolic fit.
   
   Brackets the abcissa of the function, func, minimum, using
   parabolic fit. If parabolic fit fails, then the interval
   is magnified as inverse golden section and parabolic fit is
   retried.
   The function will bracket the minimum although it may happen
   that the bracket is rather wide.
*/

/* The BracketMin_NoGrad() requires that the function to be 
   minimised is sufficient smooth and a minima exists, where 
   is no return code for succes or not (if no minima exists).
*/

void BracketMin_NoGrad(FL64        *ax,
            FL64        *bx,
            FL64        *cx,
            FL64        *fa,
            FL64        *fb,
            FL64        *fc,
            VOIDPTR     pdata,
            BRENT_FCT   f_1dim,
            FL64ARRAY   point,
            FL64ARRAY   direction,
            BOOLE       *ok)
{
  FL64 limit, u, r, q, fu, dum, f_min, x_min;
  BOOLE success_up, success_down;

/*  SCecon_printf(SCECONPROGRESS, "M");*/

  *fa = (*f_1dim)(*ax, pdata, point, direction, ok) ;
  *fb = (*f_1dim)(*bx, pdata, point, direction, ok) ;

  /* Ensure that (ax,fa) holds a function value
     greater than (bx,fb) */
  if (*fb > *fa) 
  {
    SHFT(dum,*ax,*bx,dum)
    SHFT(dum,*fb,*fa,dum)
  }

  /* Now make a smart guess: the golden mean of ax and bx */
  *cx = (*bx) + GOLD * (*bx - *ax) ;
  *fc = (*f_1dim)(*cx, pdata, point, direction, ok) ;

  /* Check for constancy regions: */

  success_down = True;
  if (SCecon_fabs(*fb - *fc) < 1.0e-8 && *ok)
  {
    /* Hit constancy region. 
       Try move away in direction *cx from *bx. */
    limit = (*bx) + GLIMIT * (*cx - *bx) ;

    success_down = False;
    f_min = *fc;
    x_min = *cx;
    while ((limit - *cx) * (*cx - *bx) > 0.0 && !success_down)
    {
      *cx = (*bx) + GOLD * (*cx - *bx) ;
      *fc = (*f_1dim)(*cx, pdata, point, direction, ok);
      if (f_min > *fc)
      {
        /* Found change in function. Use current point
           and twice extrapolation by golden section */
        success_down = True;
        *ax = x_min;
        *fa = f_min;
        *bx = (*ax * (GOLD - 1.0) + *cx) / GOLD ;
        *fb = (*f_1dim)(*bx, pdata, point, direction, ok);
      }
    }
  }

  success_up = True;
  if (SCecon_fabs(*fb - *fa) < 1.0e-8 && *ok)
  {
    /* Hit constancy region. 
       Try move away in direction *ax from *bx. */
    limit = (*ax) - GLIMIT * (*bx - *ax) ;

    success_up = False;
    f_min = *fa;
    x_min = *ax;
    while ((limit - *ax) * (*ax - *bx) > 0.0 && !success_up)
    {
      *ax = (*ax) - GOLD * (*bx - *ax) ;
      *fa = (*f_1dim)(*ax, pdata, point, direction, ok);
      if (f_min > *fa)
      {
        /* Found change in function. Use current point
           and twice extrapolation by golden section */
        success_up = True;
        *cx = x_min;
        *fc = f_min;
        *bx = (*ax * (GOLD - 1.0) + *cx) / GOLD ;
        *fb = (*f_1dim)(*bx, pdata, point, direction, ok);
      }
    }
  }
  if (!success_down || !success_up)
  {
    SCecon_error("Potential function seemingly constant", 
                 "BracketMin_NoGrad()", 
                 SCECONCONTINUE);
    return;
  }

  /* Now we will tighten the bracket */
  while (*fb > *fc && *ok) 
  {
/*    SCecon_printf(SCECONPROGRESS, ".");*/
    /* First we try a parabolic fit and use
       the parabolic extremum as a guess */
    r = (*bx - *ax) * (*fb - *fc) ;
    q = (*bx - *cx) * (*fb - *fa) ;
    u = (*bx) - ((*bx - *cx) * q - (*bx - *ax) * r) /
      (2.0 * SIGN(GETMAX(fabs(q - r), TINY), q - r)) ;
    
    /* Outer limit which must not be passed */
    limit = (*bx) + GLIMIT * (*cx - *bx) ;
    if ((*bx - u) * (u - *cx) > 0.0) 
    { 
      /* Parabolic extremum is between bx and cx - try it */
      fu = (*f_1dim)(u, pdata, point, direction, ok) ;
      if (fu < *fc) 
      {
        /* We improved between bx and cx 
           - all done */
        *ax = (*bx) ;
        *bx = u ;
        *fa = (*fb) ;
        *fb = fu ;
        return ;
      } 
      else if (fu > *fb)  
      {
        /* We improved between ax and u 
           - all done */
        *cx = u ;
        *fc = fu ;
        return ;
      }
      /* Parabolic fit didn't work.
         Instead we try golden section which is safe but slower.
         Magnify interval by golden expansion */
      u = (*cx) + GOLD * (*cx - *bx) ;
      fu = (*f_1dim)(u, pdata, point, direction, ok) ;
      /* This is the only possible function valuation within 
         the while loop */
    } 
    else if ((*cx - u) * (u - limit) > 0.0) 
    {
      /* Parabolic fit between cx and outer limit */
      fu = (*f_1dim)(u, pdata, point, direction, ok) ;
      if (fu < *fc) 
      {
        /* This seems ok. Thus we may use cx, u, and cx
           magnified. */
        SHFT(*bx, *cx, u, *cx + GOLD * (*cx - *bx))
        SHFT(*fb, *fc, fu, (*f_1dim)(u, pdata, point, direction, ok))
      }
    } 
    else if ((u - limit) * (limit - *cx) >= 0.0) 
    {
      /* Restrain parabolic u to outer limit */
      u = limit ;
      fu = (*f_1dim)(u, pdata, point, direction, ok) ;
    } 
    else  
    {
      /* Parabolic fit didn't work.
         Instead we try golden section which is safe but slower.
         Magnify interval by golden expansion */
      u = (*cx) + GOLD * (*cx - *bx) ;
      fu = (*f_1dim)(u, pdata, point, direction, ok) ;
    }

    /* Now use: bx, cx, and u */
    SHFT(*ax, *bx, *cx, u)
    SHFT(*fa, *fb, *fc, fu)
  }
}

#undef GOLD
#undef GLIMIT
#undef TINY
#undef SIGN
#undef SHFT


#define ITMAX 100
#define CGOLD 0.3819660112501
/* In NR this is 0.3819660  */
#define ZEPS 1.0e-10
#define SIGN(a,b) ((b) > 0.0 ? fabs(a) : -fabs(a))
#define SHFT(a,b,c,d) (a)=(b);(b)=(c);(c)=(d);

/* Directional search for minimum within a given bracket 

   Using bracket [ax;bx;cx] within which f attains its
   minimum the function locates the abcissa minimum
   with precision tol 
*/
FL64  Brent(FL64        ax,
            FL64        bx,
            FL64        cx,
            BRENT_FCT   f_1dim,
            VOIDPTR     pdata,
            FL64ARRAY   point,
            FL64ARRAY   direction,
            FL64        tol,
            FL64        *xmin,
            BOOLE       *ok)
{
  INTI iter ;
  FL64 a, b, d, etemp, fu, fv, fw, fx, p, q, r, tol1, tol2, u, v, w, x, xm ;
  
  FL64 e = 0.0 ; /* This holds the distance moved in the step before last */

  *ok = True;

  /* warning avoidance */
  d = 0.0 ;

  /* a and b must be in ascending order */
  a = ((ax < cx) ? ax : cx) ;
  b = ((ax > cx) ? ax : cx) ;

/*  SCecon_printf(SCECONPROGRESS, "B");*/

  /* Preparations */
  x = w = v = bx ;
  fw = fv = fx = (*f_1dim)(x, pdata, point, direction, ok);

  /* Grand loop - at most ITMAX loopings */
  for (iter = 1; iter <= ITMAX && *ok; iter++) 
  {
/*    SCecon_printf(SCECONPROGRESS, ".");*/
    xm = 0.5 * (a + b) ;
    tol2 = 2.0 * (tol1 = tol * fabs(x) + ZEPS) ;

    /* Did we finish ? */
    if (fabs(x - xm) <= (tol2 - 0.5 * (b - a))) 
    {
      *xmin = x ;
      return fx ;
    }

    /* Try parabolic fit if the step before last
       was "large". */
    if (fabs(e) > tol1) 
    {
      r = (x - w) * (fx - fv) ;
      q = (x - v) * (fx - fw) ;
      p = (x - v) * q - (x - w) * r ;
      q = 2.0 * (q - r) ;
      if (q > 0.0) 
        p = -p ;
      q = fabs(q) ;
      etemp = e ;
      e = d ;

      /* Now test the parabolic fit */
      if (fabs(p) >= fabs(0.5 * q * etemp) || p <= q * (a - x) 
                        || p >=  q * (b - x))
        /* The parabolic fit is not good. We use golden section
           of the larger of [a;x] and [b;x] */
        d = CGOLD * (e = (x >= xm ? a - x : b - x)) ;
      else 
      {
        /* Exploit the parabolic fit */
        d = p / q ;
        u = x + d ;
        if (u - a < tol2 || b - u < tol2)
          d = SIGN(tol1, xm - x) ;
      }
    } 
    else
      /* Didn't want to try parabolic fit. We thus use the
         golden section of the larger of [a;x] and [b;x] */
      d = CGOLD * (e = (x >= xm ? a - x : b - x)) ;

    u = (fabs(d) >= tol1 ?  x + d : x + SIGN(tol1, d)) ;
    fu = (*f_1dim)(u, pdata, point, direction, ok) ;
    /* This is the single function evaluation per loop */

    /* Prepare for next loop - bookkeeping */
    if (fu <= fx) 
    {
      if (u >= x) 
        a = x ; 
      else 
        b = x ;
      SHFT(v, w, x, u)
      SHFT(fv, fw, fx, fu)
    } 
    else 
    {
      if (u < x) 
        a = u ; 
      else 
        b = u ;
      if (fu <= fw || w == x) 
      {
        v = w ;
        w = u ;
        fv = fw ;
        fw = fu ;
      } 
      else if (fu <= fv || v == x || v == w) 
      {
        v = u ;
        fv = fu ;
      }
    }
  }

  /* Didn't succeed before ITMAX limit was breached */
  SCecon_error("Directional search failed", "Brent()", SCECONCONTINUE);
  *ok = False;

  *xmin = x ;
  return fx;
}

#undef ITMAX
#undef CGOLD
#undef ZEPS
#undef SIGN







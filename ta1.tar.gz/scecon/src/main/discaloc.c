/* SCID @(#)discaloc.c	1.16 (SimCorp) 99/10/27 14:25:37 */

/************************************************************************
*
*   project     SCecon
*
*   filename    disc.c
*
*   contains    routines in the SCecon Library DF module
*
************************************************************************/

/***** includes ********************************************************/
#include <disc.h>


/*,,SOH,,
*************************************************************************
*
*               Alloc_BUCKETARRAY()
*
*    interface  #include <disc.h>
*               BUCKETARRAY Alloc_BUCKETARRAY(INTI n);
*
*    general    Alloc_BUCKETARRAY() allocates memory for an
*               [0...(n-1)] array of BUCKET's.
*               Returns memory with zero'ed entries
*
*    input      INTI    n       The number of entries in BUCKET list
*
*    output
*
*    returns    reference to the vector of type BUCKET
*
*    diagnostics aborts calling SCecon_error()
*                with the message   "Allocation failed"
*                         routine   "Alloc_BUCKETARRAY()"
*                         actioncode SCECONABORT
*                if allocation fails
*
*    see also   Free_BUCKETARRAY()
*
*************************************************************************
,,EOH,,*/


BUCKETARRAY Alloc_BUCKETARRAY(INTI n)
{
    BUCKETARRAY a;

    a = (BUCKETARRAY) SCecon_calloc(n, sizeof(BUCKET), True,
      "Alloc_BUCKETARRAY()") ;

    return a ;
}


/*,,SOH,,
*************************************************************************
*
*               Free_BUCKETARRAY()
*
*    interface  #include <disc.h>
*               void Free_BUCKETARRAY(BUCKETARRAY date) ;
*
*    general    Free_BUCKETARRAY() frees memory for an array
*               of BUCKET's allocated by Alloc_BUCKETARRAY()
*
*    input      BUCKETARRAY date          Reference to the array
*
*    output
*
*    returns
*
*    diagnostics
*
*    see also   Alloc_BUCKETARRAY()
*
*************************************************************************
,,EOH,,*/


void Free_BUCKETARRAY(BUCKETARRAY date)
{
    SCecon_free((VOIDPTR) date) ;
}


/*,,SOH,,
*************************************************************************
*
*               Alloc_DFSPREADARRAY()
*
*    interface  #include <disc.h>
*               DFSPREADARRAY Alloc_DFSPREADARRAY(INTI n);
*
*    general    Alloc_DFSPREADARRAY() allocates memory for an
*               [0...(n-1)] array of DFSPREAD's.
*               Returns memory with zero'ed entries
*
*    input      INTI    n       The number of entries in DFSPREAD list
*
*    output
*
*    returns    reference to the vector of type DFSPREAD
*
*    diagnostics aborts calling SCecon_error()
*                with the message   "Allocation failed"
*                         routine   "Alloc_DFSPREADARRAY()"
*                         actioncode SCECONABORT
*                if allocation fails
*
*    see also   Free_DFSPREADARRAY()
*
*************************************************************************
,,EOH,,*/


DFSPREADARRAY Alloc_DFSPREADARRAY(INTI n)
{
    DFSPREADARRAY a;

    a = (DFSPREADARRAY) SCecon_calloc(n, sizeof(DFSPREAD), True,
      "Alloc_DFSPREADARRAY()") ;

    return a ;
}


/*,,SOH,,
*************************************************************************
*
*               Free_DFSPREADARRAY()
*
*    interface  #include <disc.h>
*               void Free_DFSPREADARRAY(DFSPREADARRAY date) ;
*
*    general    Free_DFSPREADARRAY() frees memory for an array
*               of DFSPREAD's allocated by Alloc_DFSPREADARRAY()
*
*    input      DFSPREADARRAY date          Reference to the array
*
*    output
*
*    returns
*
*    diagnostics
*
*    see also   Alloc_DFSPREADARRAY()
*
*************************************************************************
,,EOH,,*/


void Free_DFSPREADARRAY(DFSPREADARRAY date)
{
    SCecon_free((VOIDPTR) date) ;
}


/*,,SOH,,
*************************************************************************
*
*               Alloc_ZRATEARRAY()
*
*    interface  #include <disc.h>
*               ZRATEARRAY Alloc_ZRATEARRAY(INTI n);
*
*    general    Alloc_ZRATEARRAY() allocates memory for an
*               [0...(n-1)] array of ZRATE_STR's.
*               Returns memory with zero'ed entries
*
*    input      INTI    n       The number of entries in ZRATE_STR list
*
*    output
*
*    returns    reference to the vector of type ZRATE_STR
*
*    diagnostics aborts calling SCecon_error()
*                with the message   "Allocation failed"
*                         routine   "Alloc_ZRATEARRAY()"
*                         actioncode SCECONABORT
*                if allocation fails
*
*    see also   Free_ZRATEARRAY()
*
*************************************************************************
,,EOH,,*/


ZRATEARRAY Alloc_ZRATEARRAY(INTI n)
{
    ZRATEARRAY a;

    a = (ZRATEARRAY) SCecon_calloc(n, sizeof(ZRATE_STR), True, 
      "Alloc_ZRATEARRAY()") ;

    return a ;
}


/*,,SOH,,
*************************************************************************
*
*               Free_ZRATEARRAY()
*
*    interface  #include <disc.h>
*               void Free_ZRATEARRAY(ZRATEARRAY zrate) ;
*
*    general    Free_ZRATEARRAY() frees memory for an array
*               of ZRATE_STR's allocated by Alloc_ZRATEARRAY()
*
*    input      ZRATEARRAY zrate        Reference to the array
*
*    output
*
*    returns
*
*    diagnostics
*
*    see also   Alloc_ZRATEARRAY()
*
*************************************************************************
,,EOH,,*/


void Free_ZRATEARRAY(ZRATEARRAY zrate)
{
    SCecon_free((VOIDPTR) zrate) ;
}



/*,,SOH,,
*************************************************************************
*
*               Free_DELTASET()
*
*    interface  #include <disc.h>
*               void Free_DELTASET(DELTASET *ds) ;
*
*    general    Free_DELTASET() frees memory for a DELTASET struct
*
*    input      DELTASET   *ds    Reference to the DELTASET type
*
*    output
*
*    returns
*
*    diagnostics
*
*    see also
*
*************************************************************************
,,EOH,,*/


void Free_DELTASET(DELTASET* ds)
{
    Free_PLANARRAY(ds->shock, ds->nshock) ;
    Free_DATEARRAY(ds->mid) ;
    Free_RISKTOKENARRAY(ds->token) ;
    Free_FL64ARRAY(ds->size) ;
}


/*,,SOH,,
*************************************************************************
*
*               Free_RISKSET()
*
*    interface  #include <disc.h>
*               void Free_RISKSET(RISKSET *ds) ;
*
*    general    Free_RISKSET() frees memory for a RISKSET struct
*
*    input      RISKSET   *ds    Reference to the RISKSET type
*
*    output
*
*    returns
*
*    diagnostics
*
*    see also
*
*************************************************************************
,,EOH,,*/


void Free_RISKSET(RISKSET* ds)
{
    Free_PLANARRAY(ds->loads, 1) ;
}


/*,,SOH,,
*************************************************************************
*
*               Free_DISCFAC()
*
*    interface  #include <disc.h>
*               void Free_DISCFAC(DISCFAC *d) ;
*
*    general    The routine free a DISCFAC
*
*    input      DISCFAC   *d           Reference to the array
*
*    output
*
*    returns
*
*    diagnostics
*
*    see also
*
*************************************************************************
,,EOH,,*/

void Free_DISCFAC(DISCFAC*  d)
{
    if (d != NULL)
        Free_PLANARRAY(d->disc, 1) ;
}

/*,,SOH,,
*************************************************************************
*
*               Alloc_DISCFACARRAY()
*
*    interface  #include <disc.h>
*               DISCFACARRAY Alloc_DISCFACARRAY(INTI n) ;
*
*    general    Alloc_DISCFACARRAY() allocates memory for an
*               [0...(n-1)] array of DISCFAC's.
*               Returns memory with zero'ed entries
*
*    input      INTI    n       The number of entries in DISCFAC list
*
*    output
*
*    returns    reference to the vector of type DISCFAC
*
*    diagnostics aborts calling SCecon_error()
*                with the message   "Allocation failed"
*                         routine   "Alloc_DISCFACARRAY()"
*                         actioncode SCECONABORT
*                if allocation fails
*
*    see also   Free_DISCFACARRAY()
*
*************************************************************************
,,EOH,,*/


DISCFACARRAY Alloc_DISCFACARRAY(INTI n)
{
  DISCFACARRAY a;

  a = (DISCFACARRAY) SCecon_calloc(n, sizeof(DISCFAC), True,
    "Alloc_DISCFACARRAY()") ;

  return a ;
}

/*,,SOH,,
*************************************************************************
*
*               Free_DISCFACARRAY()
*
*    interface  #include <disc.h>
*               void Free_DISCFACARRAY(DISCFACARRAY vector,
*                                      INTI n) ;
*
*    general    Free_DISCFACARRAY() frees memory for an array
*               of DISCFAC's allocated by Alloc_DISCFACARRAY()
*
*    input      DISCFACARRAY vector        The array.
*
*               INTI          n            Size of vector.
*
*    output
*
*    returns
*
*    diagnostics
*
*    see also   Alloc_DISCFACARRAY()
*
*************************************************************************
,,EOH,,*/


void Free_DISCFACARRAY(DISCFACARRAY vector, INTI n)
{

  INTI i ;

  if (vector == NULL || n == 0)
    return;

  for (i = 0; i < n; i++)
    Free_DISCFAC(&vector[i]);
  
  SCecon_free((VOIDPTR) vector) ;
  
}

/*,,SOH,,
*************************************************************************
*
*               Free_DFSPREAD()
*
*    interface  #include <disc.h>
*               void Free_DFSPREAD(DFSPREAD *d) ;
*
*    general    The routine free a DFSPREAD
*
*    input      DFSPREAD  *d           Reference to the data type
*
*    output
*
*    returns
*
*    diagnostics
*
*    see also
*
*************************************************************************
,,EOH,,*/

void Free_DFSPREAD(DFSPREAD*  d)
{
    if (d != NULL)
        Free_PLANARRAY(d->spr_list, 1) ;
}


/* SCID @(#)dateval.c	1.17 (SimCorp) 99/02/19 14:15:17 */

/************************************************************************
*
*   project     SCecon
*
*   file name   dateval.c
*
*   general     This file contains standard routines for calendar
*               calculations
*
************************************************************************/

/* includes ************************************************************/
#include <cldr.h>


/*,,SOH,,
*************************************************************************
*
*               Cldr_LastDayInMonth()
*
*   interface   #include <cldr.h>
*               INTI Cldr_LastDayInMonth(INTI y,INTI  m) ;
*
*   general     Cldr_LastDayInMonth() finds the last day of month m
*               in the year y.
*
*   input       INTI    y        The year.
*
*               INTI    m        The month.
*
*   output
*
*   returns     the last day in the month m in year y as INTI.
*
*   diagnostics
*
*   see also    Cldr_IsLeap()
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/


INTI  Cldr_LastDayInMonth(INTI y,
                          INTI  m)
{
    if ((m == 4) || (m == 6) || (m == 9) || (m == 11) )
        return 30;
    if (m == 2)
    {
        if (Cldr_IsLeap(y))
            return 29;
        else
            return 28;
    }
    return 31;
}


/*,,SOH,,
*************************************************************************
*
*                Cldr_CheckDate()
*
*   interface   #include <cldr.h>
*               BOOLE Cldr_CheckDate(DATESTR *date) ;
*
*   general     Cldr_CheckDate() checks if input date is a valid date
*               or not.
*
*   input       DATESTR  *date   Pointer to date.
*
*   output
*
*   returns     True if date is valid, False if not.
*
*   diagnostics
*
*   see also
*
*************************************************************************
,,EOH,,*/


BOOLE Cldr_CheckDate(DATESTR* date)
{
    if (date->y == 0)
        return False;
    if ((date->m < 1) || (date->m > 12) || (date->d < 1) || (date->d > 31))
        return False;
    if (date->d > Cldr_LastDayInMonth(date->y, date->m))
        return False;
    return True;
}


/*,,SOH,,
************************************************************************
*                                                                       
*               Cldr_IsNullDate()                                       
*                                                                       
*   interface   #include <cldr.h>                                       
*               BOOLE Cldr_IsNullDate(DATESTR *date) ;                  
*                                                                       
*   general     Cldr_CheckDate() checks if input date is a null date    
*               or not.                                                 
*                                                                       
*   input       DATESTR  *date   Pointer to date.                       
*                                                                       
*   output                                                              
*                                                                       
*   returns     True if date is null, False if not.                    
*                                                                       
*   diagnostics                                                         
*                                                                       
*   see also                                                            
*                                                                       
************************************************************************
,,EOH,,*/

BOOLE Cldr_IsNullDate(DATESTR*  date) 
{
    if (date == NULL)
        return True;
    else if (date->y == 0 && date->m == 0 && date->d == 0)
        return True;
    else
        return False;
}

/*,,SOH,,
*************************************************************************
*
*              Cldr_Date2Julian()
*
*   interface  #include <cldr.h>
*              INTL Cldr_Date2Julian(DATESTR *datein) ;
*
*   general    Cldr_Date2Julian() converts the input date to the
*              corresponding julian date number.
*
*              Algorithm follows Communications of the ACM, August
*              1963, volume 6, Number 8, page 444.
*
*              This algorithm is not valid before September 14, 1752.
*
*   input      DATESTR *datein      Pointer to date
*
*   output
*
*   returns    the julian date number as INTL.
*
*   diagnostics
*
*   see also   Cldr_Julian2Date()
*
*   wrapper    AP
*
*************************************************************************
,,EOH,,*/


INTL  Cldr_Date2Julian(DATESTR* datein)
{
    INTL    c, ya ;
    INTI    y, m, d;

    /* Revised 8/2/91, HED, based on SBG algorithm from ACM, Vol. 6, No.8
       (Aug. 1963), p.444 */

    y = datein->y;
    m = datein->m;
    d = datein->d;

    /* To avoid problems with 30-Feb (KLA induced) -- periodic interest ! */
    d = GETMIN(d, Cldr_LastDayInMonth(y, m)) ;

    if (m > 2)
        m -= 3 ;
    else
    {
        m += 9 ;
        y-- ;
    }
    c  = y / 100 ;
    ya = y - 100*c ;
    return ((146097L*c)>>2) + ((1461L*ya)>>2) + (153L*m + 2L)/5L + d +
           1721119L ;
}


/*,,SOH,,
*************************************************************************
*
*                Cldr_Julian2Date()
*
*    interface   #include <cldr.h>
*                DATESTR Cldr_Julian2Date(INTL  julian) ;
*
*    general     Cldr_Julian2Date() converts the julian date number
*                to the corresponding date according to the gregorian
*                calendar.
*
*                Algorithm follows Communications of the ACM, August
*                1963, volume 6, Number 8, page 444.
*
*                This algorithm is not valid before September 14, 1752.
*
*    input       INTL      julian    The julian date number.
*
*    output
*
*    returns     the corresponding gregorian date as DATESTR.
*
*    diagnostics
*
*    see also    Cldr_Date2Julian()
*
*    wrapper     AP
*
*************************************************************************
,,EOH,,*/


DATESTR Cldr_Julian2Date(INTL julian)
{
    INTL    j, y, m, d ;
    DATESTR dateout ;

    /* Modified, 8/2/91, HED, based on same algorithm as in date2jul() */
    j = julian - 1721119L ;
    y = ((j << 2) - 1L) / 146097L ;
    j = (j << 2) - 1L - 146097L*y ;
    d = (j >> 2) ;
    j = ((d << 2) + 3L) / 1461L ;
    d = (d << 2) + 3L - 1461L*j ;
    d = (d + 4L) >> 2 ;
    m = (5L*d - 3L) / 153L ;
    d = 5L*d - 3L - 153L*m ;
    d = (d + 5L)/5L ;
    y = 100L*y + j ;
    if (m < 10L)
        m += 3L ;
    else
    {
        m -= 9L ;
        y++ ;
    }

    dateout.y = (INTI ) y ;
    dateout.m = (INTI ) m ;
    dateout.d = (INTI ) d ;
    return dateout ;
}

/*,,SOH,,
*************************************************************************
*
*                Cldr_Weekday()
*
*    interface   #include <cldr.h>
*                INTI Cldr_Weekday(DATESTR *date) ;
*
*    general     Cldr_Weekday() finds the week day of the input
*                date as INTI  between 1 and 7, 1 being monday.
*
*    input       DATESTR  *date    Pointer to input date
*
*    output
*
*    returns     the week day number as INTI . If the input date
*                is a monday, 1 is returned, is it a tuesday, then
*                2 is returned etc.
*
*    diagnostics
*
*    see also    Cldr_NextIMM()
*                Cldr_IsBusinessDate()
*
*    wrapper     AP
*
*************************************************************************
,,EOH,,*/


INTI Cldr_Weekday(DATESTR* date)
{
    INTL    jdate ;
    INTI    modula ;

    /* May have a problem with non-portability of %, SBG, 7/31/91 */
    /* Speed increase my friends, 7/31/91, HED */

    jdate = Cldr_Date2Julian(date);
    modula = 1 + (INTI )(jdate % 7);
    return modula ;
}


/*,,SOH,,
*************************************************************************
*
*                Cldr_WeekNumber()
*
*    interface   #include <cldr.h>
*                INTI Cldr_WeekNumber(DATESTR *date) ;
*
*    general     The routine finds the week number of the input date
*                according to international standards:
*
*                The week of 1-Jan is week number 1 if it is on a
*                monday, tuesday, wednesday or thursday, otherwise it
*                it the week number of the last week of the previous
*                year.
*
*    input       DATESTR  *date    Pointer to input date
*
*    output
*
*    returns     the weeknumber
*
*    diagnostics
*
*    see also    Cldr_Weekday()
*
*    wrapper     AP
*
*************************************************************************
,,EOH,,*/


INTI Cldr_WeekNumber(DATESTR* date)
{
    INTI    days, day11, weeks, week11 ;
    DATESTR start, end, jan11 ;

    /* Find the week day number of the 1-Jan of the actual year */
    jan11   = *date ;
    jan11.m = 1 ;
    jan11.d = 1 ;
    day11   = Cldr_Weekday(&jan11) ;

    /* This leads to the week number of the 1-Jan */
    week11 = (day11 <= 4 ? 1 : 0) ;

    /* Now find the week number of the actual date */
    days  = (INTI) Cldr_DaysBetweenDates(&jan11, date, ACTACT, NULL) ; 	/* PMSTA-22396 - SRIDHARA � 160502 */
    weeks = days / 7 ;
    days  = days - weeks * 7 ;
    end   = Cldr_AddDays(&jan11, (INTL) (7 * weeks), ACTACT, NULL) ; 	/* PMSTA-22396 - SRIDHARA � 160502 */

    if (Cldr_Weekday(&end) > Cldr_Weekday(date))
        weeks++ ;

    /* Remember the initial offset */
    weeks += week11 ;

    /* Be careful about days in the first week of next year */
    jan11.y = date->y + 1 ;
    jan11.m = 1 ;
    jan11.d = 1 ;
    day11   = Cldr_Weekday(&jan11) ;

    if (day11 <= 4 && day11 > 1)
    {
        /* If in the same week as 1/1 but before then... */
        start = Cldr_AddDays(&jan11, -(INTL) (day11 - 1), ACTACT, NULL) ; 	/* PMSTA-22396 - SRIDHARA � 160502 */

        if (Cldr_DateLE(&start, date) == True)
            weeks = 1 ;
    }

    /* Be careful if in the first days of the year */
    if (weeks == 0 && date->m == 1)
    {
        /* This is recursive - but not dangerous since only one level */
        end.y = date->y - 1 ;
        end.m = 12 ;
        end.d = 31 ;
        weeks = Cldr_WeekNumber(&end) ;
    }

    return weeks ;
}

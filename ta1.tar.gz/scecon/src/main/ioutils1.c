/* SCID @(#)ioutils1.c	1.174 (SimCorp) 99/10/28 14:57:44 */

/************************************************************************
*
*   Project     SCecon
*
*   file name   ioutils1.c
*
*   general     This file contains file io functions
*
************************************************************************/

/* includes    *********************************************************/
#include <str2conv.h>
#include <ioconv.h>


/*
..
*/

HOLIRULEARRAY Read_HOLIRULEARRAY(FILE*  in, 
                                    FILE*  out,
                                    INTI*  nrules)
{
    CH            txb[50], txc[50];
    HOLIRULEARRAY rules;
    COUNT         type;
    INTI          i;
    INTI          term, day, offset_sat, offset_sun;
    WEEKDAY       unit;
    ANCHORDAY     anchor;

    type = Read_FormatId(in, out) ;
  
    *nrules = Read_INTI(in, out, "   No. of rules   ");
    rules = Alloc_HOLIRULEARRAY(*nrules);

    switch (type)
    {
    case 1:
        for (i = 0; i < *nrules; i++)
        {
            fscanf(in, "%d %s %s", &term, txb, txc);
            unit = Str2WEEKDAY(txb);
            anchor = Str2ANCHORDAY(txc);
            fprintf(out, "   %d:  %d %s %s\n", i, term, txb, 
              txc);
            offset_sat = 0;
            offset_sun = 0;
            day = 1;
            rules[i] = Set_HOLIRULE(term, unit, day, anchor, 
                                    offset_sat, offset_sun) ;
        }
        break;
    case 2:
        for (i = 0; i < *nrules; i++)
        {
            fscanf(in, "    %d %s %s %d %d", &term, txb, txc,
              &offset_sat, &offset_sun);
            unit = Str2WEEKDAY(txb);
            anchor = Str2ANCHORDAY(txc);
            fprintf(out, "%d:  %d %s %s %d %d\n", i, term, 
              txb, txc, offset_sat, offset_sun);
            day = 1;
            rules[i] = Set_HOLIRULE(term, unit, day, anchor, 
                                    offset_sat, offset_sun) ;
        }
        break;
    case 3:
        for (i = 0; i < *nrules; i++)
        {
            fscanf(in, "    %d %s %d %s %d %d", &term, txb, &day, 
              txc, &offset_sat, &offset_sun);
            unit = Str2WEEKDAY(txb);
            anchor = Str2ANCHORDAY(txc);
            fprintf(out, "  %d: %d %s %d %s %d %d\n", i, term, txb, 
              day, txc, offset_sat, offset_sun);
            rules[i] = Set_HOLIRULE(term, unit, day, anchor, 
                                    offset_sat, offset_sun) ;
        }
        break;
    default:
        fprintf(out, "ERROR: Illegal format number.\n");
        fflush(out);
        SCecon_error("Illegal format number.",
            "Read_HOLIRULEARRAY()", SCECONABORT);
    }

    return rules;
}


            
/*
..
*/

PERIOD Read_PERIOD(FILE* in)
{
    PERIOD    p ;
    char       s[256] ;

    fscanf(in, "%d %s", &p.num, s) ;

    p.unit = Str2TERMUNIT(s) ;

    return p ;
}


/*
..
*/

void Write_PERIOD(FILE* out, char* txt, PERIOD* p)
{
    char    s[256] ;

    TERMUNIT2Str(p->unit, s) ;

    fprintf(out, "   %s %d %s\n", txt, p->num, s) ;
}


/*
..
*/

VOLBOX *Read_VOLBOX(FILE* in, FILE* out)
{
    VOLBOX  *vb ;
    INTI    i, j, k, a, b, c, l = 0 ;
    INTL    ymd ;
    char    tx1[56], tx2[56], tx3[56], tx4[56], tx5[56], tx6[56] ;

    /* read in */
    fscanf(in, "%d %d %d", &a, &b, &c) ;

    vb = Alloc_VOLBOX(a, b, c) ;

    vb->filled_OM = a ;
    vb->filled_S = b ;
    vb->filled_SM = c ;

    for (i = 0; i < a; i++)
    {
        fscanf(in, "%ld", &ymd) ;
        vb->optmatur[i] = Cldr_YMD2Datestr(ymd) ;
    }
    for (i = 0; i < b; i++)
        fscanf(in, "%lf", &vb->strike[i]) ;
    for (i = 0; i < c; i++)
        vb->swapmatur[i] = Read_PERIOD(in) ;

    for (k = 0; k < c; k++)
        for (j = 0; j < b; j++)
            for (i = 0; i < a; i++)
                fscanf(in, "%lf", &vb->vol[i][j][k]) ;

    fscanf(in, "%s %s %s %s %s %s", tx1, tx2, tx3, tx4, tx5, tx6) ;

    vb->volconv = Str2VOLCONV(tx1) ;
    vb->ipol = Str2INTPOLCONV(tx2) ;
    vb->in_what = Str2INWHATVOL(tx3) ;
    vb->cal = Str2CALCONV(tx4) ;
    vb->eom = Str2EOMCONV(tx5) ;
    vb->price_vol = Str2BOOLE(tx6) ;

    /* write out */
    fprintf(out, "\nVol Box\n") ;
    fprintf(out, "Option maturity range: %d\n", a) ;
    for (i = 0; i < a; i++)
        fprintf(out, "%ld\n", Cldr_Datestr2YMD(&vb->optmatur[i])) ;
    fprintf(out, "Strike range: %d\n", b) ;
    for (i = 0; i < b; i++)
        fprintf(out, "%lf\n", vb->strike[i]) ;
    fprintf(out, "Swap maturity range: %d\n", c) ;
    for (i = 0; i < c; i++)
        Write_PERIOD(out, "", &vb->swapmatur[i]) ;

    fprintf(out, "\nVolatilities:\n") ;
    for (k = 0; k < c; k++)
        for (j = 0; j < b; j++)
            for (i = 0; i < a; i++)
            {
                /* this to avoid too long lines */
                if (l < 5)
                {
                    fprintf(out, "%lf\t", vb->vol[i][j][k]) ;
                    l++ ;
                }
                else
                {
                    l = 0 ;
                    fprintf(out, "%lf\n", vb->vol[i][j][k]) ;
                }
            }

    fprintf(out, "\nVol Conv: %s\n", tx1) ;
    fprintf(out, "Ipol Conv: %s\n", tx2) ;
    fprintf(out, "In What Vol: %s\n", tx3) ;
    fprintf(out, "Cal Conv: %s\n", tx4) ;
    fprintf(out, "Eom Conv: %s\n", tx5) ;
    fprintf(out, "Price Vol? %s\n", tx6) ;

    Write_VALIDATEError(out, Validate_VOLBOX(vb));

    return vb ;
}


/*
..
*/

DFSPREAD Read_DFSPREAD(FILE* in, FILE* out)
{
    DFSPREAD xt ;
    char     txb[15] ;
    COUNT    type;

    fprintf(out,"   DFSPREAD:\n") ;
    type = Read_FormatId(in, out);

    switch (type)
    {
        case 1:

            fscanf(in, "%lf", &xt.spread) ;
            fprintf(out,"   Spread      %8lf\n", xt.spread) ;

            fscanf(in, "%s", txb) ;
            xt.irr = Str2IRRCONV(txb) ;
            fprintf(out,"   Irr         %8s\n", txb) ;

            fscanf(in, "%s", txb) ;
            xt.freq = Str2PMTFREQ(txb) ;
            fprintf(out,"   Freq:       %8s\n", txb) ;

            xt.spr_list = NULL ;

            break ;

        case 2:

            fscanf(in, "%lf", &xt.spread) ;
            fprintf(out,"   Spread      %8lf\n", xt.spread) ;

            xt.irr  = COMPOUND ;
            xt.freq = ANNUALLY ;
            xt.spr_list = NULL ;

            break ;

        case 3:

            xt.spread = 0.0 ;
            xt.irr    = COMPOUND ;
            xt.freq   = ANNUALLY ;
            xt.spr_list = NULL ;

            break ;

        case 4:

            fscanf(in, "%lf", &xt.spread) ;
            fprintf(out,"   Spread      %8lf\n", xt.spread) ;

            fscanf(in, "%s", txb) ;
            xt.irr = Str2IRRCONV(txb) ;
            fprintf(out,"   Irr         %8s\n", txb) ;

            fscanf(in, "%s", txb) ;
            xt.freq = Str2PMTFREQ(txb) ;
            fprintf(out,"   Freq:       %8s\n", txb) ;

            xt.spr_list = Read_PLANARRAY(in) ;
            fprintf(out,"   Spread List:\n") ;
            Write_PLANARRAY(out, xt.spr_list) ;
            break ;
    }

    Write_VALIDATEError(out, Validate_DFSPREAD(&xt));

    return xt ;
}


/*
..
*/


void Write_ValidateStatus(VALIDATE val)
{
    char txval[80] ;

    VALIDATE2Str(val, txval) ;
    if (val != Valid_data)
        printf("Invalid Data: %s\n", txval) ;
}


/*
..
*/

RISKSET Read_RISKSET(FILE* in, FILE* out)
{
    RISKSET o ;
    COUNT type;

    o = Set_RISKSET(KEY_DF, SECOND_ORDER, -1.0, COMPOUND, ANNUALLY,
          NULL, True);

    type = Read_FormatId(in, out);

    switch (type)
    {
        case 1:
            o.key = Read_KEYCONV(in, out, "Shocking");
            break ;

        case 2:
            o.key = Read_KEYCONV(in, out, "Shocking");
            o.shock = Read_FL64(in, out, "Shock");
            o.irr = Read_IRRCONV(in, out, "IRR");
            o.freq = Read_PMTFREQ(in, out, "IRR Quoting");
            break ;

        case 3:
            o.key = Read_KEYCONV(in, out, "Shocking");
            o.shock = Read_FL64(in, out, "Shock");
            break ;

        case 4:
            o.key = Read_KEYCONV(in, out, "Shocking");
            o.risk = Read_RISKCONV(in, out, "Risk");
            break ;

        case 5:

            o.key = KEY_DF ;
            break ;

        case 6:
            o.irr = Read_IRRCONV(in, out, "IRR");
            o.freq = Read_PMTFREQ(in, out, "IRR Quoting");

            IOUtil_ReadComment(in, out);
            o.loads = Read_PLANARRAY(in) ;
            Write_PLANARRAY(out, o.loads) ;

            break ;

        case 7:
            o.key = Read_KEYCONV(in, out, "Shocking");
            o.irr = Read_IRRCONV(in, out, "IRR");
            o.freq = Read_PMTFREQ(in, out, "IRR Quoting");
            break ;

        case 8:
            o.dom = Read_BOOLE(in, out, "Domestic RR");
            break ;

        case 9:
            o.key = Read_KEYCONV(in, out, "Shocking");
            o.irr = Read_IRRCONV(in, out, "IRR");
            o.freq = Read_PMTFREQ(in, out, "IRR Quoting");
            o.dom = Read_BOOLE(in, out, "Domestic RR");
            break ;

        case 10:
            o.key = Read_KEYCONV(in, out, "Shocking");
            o.risk = Read_RISKCONV(in, out, "Risk");
            o.shock = Read_FL64(in, out, "Shock");
            break ;

        case 11:
            o.key = Read_KEYCONV(in, out, "Shocking");
            o.risk = Read_RISKCONV(in, out, "Risk");
            o.dom = Read_BOOLE(in, out, "Domestic RR");
            break ;
    }

    Write_VALIDATEError(out, Validate_RISKSET(&o));

    return o ;
}


/*
..
*/


DISCFAC Read_DISCFAC(FILE* in, FILE* out)
{
    DISCFAC df ;
    DFPARMS dfp ;

      /* Format id is used in Read_DFPARMS */
    dfp = Read_DFPARMS(in, out) ;

    df.cal   = dfp.cal ;
    df.iconv = dfp.iconv ;
    df.what  = dfp.what ;
    df.irr   = dfp.irr ;
    df.freq  = dfp.freq ;

    IOUtil_ReadComment(in, out);
    df.disc = Read_PLANARRAY(in) ;
    Write_PLANARRAY(out, df.disc) ;

    Write_VALIDATEError(out, Validate_DISCFAC(&df));

    return df ;
}

/*
..
*/


VOL_STR Read_VOL_STR(FILE* in, FILE* out)
{
    VOL_STR vol ;
    COUNT type;

    fprintf(out,"   VOL_STR:\n") ;

    type = Read_FormatId(in, out);

    switch (type)
    {
        case 1:
            vol.cal = Read_CALCONV(in, out, "   Calendar  ");
            vol.vc = Read_VOLCONV(in, out, "   VolConc  ");
            vol.iconv = LINEAR_EXTRAPOL ;

            vol.vol = Read_PLANARRAY(in) ;
            fprintf(out,"   Vol's are:\n") ;
            Write_PLANARRAY(out, vol.vol) ;
            break ;

        case 2:

            vol.cal = Read_CALCONV(in, out, "   Calendar  ");
            vol.vc  = FORWFORW ;
            vol.iconv = LINEAR_EXTRAPOL ;

            vol.vol = Read_PLANARRAY(in) ;
            fprintf(out,"   Vol's are:\n") ;
            Write_PLANARRAY(out, vol.vol) ;
            break ;

        case 3:

            vol.cal = Read_CALCONV(in, out, "   Calendar  ");
            vol.iconv = Read_INTPOLCONV(in, out, "   Interpolation  ");
            vol.vc  = FORWFORW ;

            vol.vol = Read_PLANARRAY(in) ;
            fprintf(out,"   Vol's are:\n") ;
            Write_PLANARRAY(out, vol.vol) ;
            break ;

        case 4:
            vol.cal = Read_CALCONV(in, out, "   Calendar  ");
            vol.vc = Read_VOLCONV(in, out, "   VolConc  ");
            vol.iconv = LINEAR_FLAT_END ;

            vol.vol = Read_PLANARRAY(in) ;
            fprintf(out,"   Vol's are:\n") ;
            Write_PLANARRAY(out, vol.vol) ;
            break ;
    }

    Write_VALIDATEError(out, Validate_VOL_STR(&vol));

    return vol ;
}


/*
..
*/

INTI Write_RiskDiff(BOOLE  okres, 
                        BOOLE  okexp,
                        FL64   fres, 
                        FL64   fres1, 
                        FL64   fres2,
                        FL64   fexp, 
                        FL64   fexp1, 
                        FL64   fexp2, 
                        FL64   acc, 
                        FILE*  out)
{
    INTI diff ;

    /* warning avoidance */
    diff = 0;

    if (okres != okexp)
    {
        fprintf(out,"1; OK = %d expected = %d\n", okexp, okres) ;
        return 1 ;
    }
    else 
        fprintf(out,"0; OK = %d expected = %d\n", okexp, okres) ;

    if (okres == True)
    {
        /* Here ok is OK */
        diff = (fabs(fres - fexp) > acc || fabs(fres1 - fexp1) > acc ||
                fabs(fres2 - fexp2) > acc);
        fprintf(out,"%d; 0. order derivative %e expected = %e\n",
                (fabs(fres - fexp) > acc), fres, fexp);
        fprintf(out,"%d; 1. order derivative %e expected = %e\n",
                (fabs(fres1 - fexp1) > acc), fres1, fexp1);
        fprintf(out,"%d; 2. order derivative %e expected = %e\n",
                (fabs(fres2 - fexp2) > acc), fres2, fexp2);
    }
    return diff ;
}


/*
..
*/

INTI Write_SingleDiff(BOOLE  okres, 
                         BOOLE  okexp,
                         FL64   fres, 
                         FL64   fexp, 
                         FL64   acc, 
                         FILE*  out)
{
    INTI diff ;

    /* warning avoidance */
    diff = 0;

    if (okres != okexp)
    {
        fprintf(out,"1; OK = %d expected = %d\n", okres, okexp) ;
        return 1 ;
    }
    else
        fprintf(out,"0; OK = %d expected = %d\n", okres, okexp) ;

    if (okres == True)
    {
        diff = fabs(fres - fexp) > acc ;
        fprintf(out,"%d; 0. order derivative %8.5lf expected = %8.5lf\n",
                (fabs(fres - fexp) > acc), fres, fexp);
    }
    return diff ;
}


/*
..
*/

INTI Write_DeltaDiff(BOOLE okres, 
                        BOOLE okexp,
                        FL64ARRAY dvres, 
                        INTI ndvres, 
                        FL64ARRAY dvexp,
                        INTI ndvexp,
                        FL64 acc, 
                        FILE* out)
{
    INTI i, diff ;

    diff = 1 ;

    if (okres != okexp)
        fprintf(out,"1; Cannot find Delta Vector\n") ;
    else if (ndvexp != ndvres)
        fprintf(out,"1; Expected and Actual Numbers of DVs Differ\n") ;
    else
    {
        for (diff = i = 0; i < ndvres; i++)
        {
            diff = diff || fabs(dvexp[i] - dvres[i]) > acc ;
            fprintf(out, "%d; %d exp %lf res %lf\n",
                    fabs(dvexp[i] - dvres[i]) > acc, i, dvexp[i], dvres[i]) ;
        }
    }

    return diff ;
}


/*
..
*/

DFSPREADARRAY Read_DFSPREADARRAY(FILE* in,
                                FILE* out,
                                INTI* ns)
{
    DFSPREADARRAY dfs ;
    char txa[25], txb[25] ;
    INTI i ;
    COUNT type;

    /* warning avoidance */
    dfs = NULL;

    type = Read_FormatId(in, out);
    fscanf(in, "%d", ns) ;

    if (*ns == 0)
        return NULL ;

    switch (type)
    {
        case 0:
            /* Allocate */
            dfs = Alloc_DFSPREADARRAY(*ns) ;

            /* Read data */
            fprintf(out,"   Spread Array is...\n") ;
            fprintf(out,"   Spread    Irr    Freq\n") ;
            for (i = 0 ; i < *ns ; i++)
            {
                fscanf(in, "%lf %s %s", &dfs[i].spread, txa, txb) ;
                dfs[i].irr = Str2IRRCONV(txa) ;
                dfs[i].freq = Str2PMTFREQ(txb) ;
                fprintf(out, "   %lf %s %s\n", dfs[i].spread, txa, txb) ;
            }
            break ;
        case 1:
            /* Allocate */
            dfs = Alloc_DFSPREADARRAY(*ns) ;

            /* Read data */
            fprintf(out,"   Spread Array is...\n") ;
            fprintf(out,"   Spread\n") ;
            for (i = 0 ; i < *ns ; i++)
            {
                fscanf(in, "%lf", &dfs[i].spread) ;
                dfs[i].irr = COMPOUND  ;
                dfs[i].freq = ANNUALLY ;
                fprintf(out, "   %lf\n", dfs[i].spread) ;
            }
            break ;
        case 2:
            dfs = Alloc_DFSPREADARRAY(*ns) ;

            for (i = 0 ; i < *ns ; i++)
            {
                dfs[i].spread = 0 ;
                dfs[i].irr = COMPOUND  ;
                dfs[i].freq = ANNUALLY ;
            }
            break ;
    }

    Write_VALIDATEError(out, Validate_DFSPREADARRAY(dfs, *ns));

    return dfs ;
}


/*
..
*/

ITERCTRL Read_ITERCTRL(FILE* in,
                          FILE* out)
{
    ITERCTRL ictrl ;
    COUNT type;

    /* Read data */
    fprintf(out,"   ITERCTRL ...\n") ;

    type = Read_FormatId(in, out);

    if (type == 1)
    {
        Init_ITERCTRL(&ictrl) ;
        ictrl.init_guess = Read_FL64(in, out, "    Init guess: ") ;
        ictrl.use_init_guess = Read_BOOLE(in, out, "   Use init guess? ") ;
    }
    else if (type == 2)
        Init_ITERCTRL(&ictrl) ;
    else if (type == 3)
    {
        Init_ITERCTRL(&ictrl) ;
        ictrl.init_guess = Read_FL64(in, out, "    Init guess: ") ;
        ictrl.use_init_guess = Read_BOOLE(in, out, "   Use init guess? ") ;
        ictrl.acc = Read_FL64(in, out, "    Acc: ") ;
    }
    else if (type == 4)
    {
        Init_ITERCTRL(&ictrl) ;
        ictrl.init_guess = Read_FL64(in, out, "    Init guess: ") ;
        ictrl.use_init_guess = Read_BOOLE(in, out, "   Use init guess? ") ;
        ictrl.lower = Read_FL64(in, out, "    Lower: ") ;
        ictrl.use_lower = Read_BOOLE(in, out, "   Use lower? ") ;
        ictrl.upper = Read_FL64(in, out, "    Upper: ") ;
        ictrl.use_upper = Read_BOOLE(in, out, "   Use upper? ") ;
    }
    else if (type == 5)
    {
        Init_ITERCTRL(&ictrl) ;
        ictrl.maxiter = Read_INTI(in, out, "    Maxiter: ") ;
        ictrl.init_guess = Read_FL64(in, out, "    Init guess: ") ;
        ictrl.use_init_guess = Read_BOOLE(in, out, "   Use init guess? ") ;
        ictrl.lower = Read_FL64(in, out, "    Lower: ") ;
        ictrl.use_lower = Read_BOOLE(in, out, "   Use lower? ") ;
        ictrl.upper = Read_FL64(in, out, "    Upper: ") ;
        ictrl.use_upper = Read_BOOLE(in, out, "   Use upper? ") ;
        ictrl.acc = Read_FL64(in, out, "    Acc: ") ;
        ictrl.damp = Read_FL64(in, out, "    Damp: ") ;
        ictrl.gfreq = Read_INTI(in, out, "    Gfreq: ") ;
        ictrl.shock = Read_FL64(in, out, "    Shock: ") ;
    }
    else if (type == 6)
    {
        Init_ITERCTRL(&ictrl) ;
        ictrl.maxiter = Read_INTI(in, out, "    Maxiter: ") ;
        ictrl.init_guess = Read_FL64(in, out, "    Init guess: ") ;
        ictrl.use_init_guess = Read_BOOLE(in, out, "   Use init guess? ") ;
        ictrl.lower = Read_FL64(in, out, "    Lower: ") ;
        ictrl.use_lower = Read_BOOLE(in, out, "   Use lower? ") ;
        ictrl.upper = Read_FL64(in, out, "    Upper: ") ;
        ictrl.use_upper = Read_BOOLE(in, out, "   Use upper? ") ;
        ictrl.acc = Read_FL64(in, out, "    Acc: ") ;
        ictrl.what_acc = Read_INTI(in, out, "    What_acc: ") ;
        ictrl.damp = Read_FL64(in, out, "    Damp: ") ;
        ictrl.gfreq = Read_INTI(in, out, "    Gfreq: ") ;
        ictrl.shock = Read_FL64(in, out, "    Shock: ") ;
    }
    else if (type == 7)
    {
        Init_ITERCTRL(&ictrl) ;
        ictrl.maxiter = Read_INTI(in, out, "    Maxiter: ") ;
        ictrl.init_guess = Read_FL64(in, out, "    Init guess: ") ;
        ictrl.use_init_guess = Read_BOOLE(in, out, "   Use init guess? ") ;
        ictrl.lower = Read_FL64(in, out, "    Lower: ") ;
        ictrl.use_lower = Read_BOOLE(in, out, "   Use lower? ") ;
        ictrl.upper = Read_FL64(in, out, "    Upper: ") ;
        ictrl.use_upper = Read_BOOLE(in, out, "   Use upper? ") ;
        ictrl.acc = Read_FL64(in, out, "    Acc: ") ;
        ictrl.what_acc = Read_INTI(in, out, "    What_acc: ") ;
        ictrl.damp = Read_FL64(in, out, "    Damp: ") ;
        ictrl.gfreq = Read_INTI(in, out, "    Gfreq: ") ;
        ictrl.bisec = Read_INTI(in, out, "    Bisec: ") ;
        ictrl.shock = Read_FL64(in, out, "    Shock: ") ;
    }

    Write_VALIDATEError(out, Validate_ITERCTRL(&ictrl));

    return ictrl ;
}


/*
..
*/

DFPARMS Read_DFPARMS(FILE* in, FILE* out)
{
    DFPARMS dfp ;
    COUNT type;

    fprintf(out,"* DFPARMS:\n") ;
    type = Read_FormatId(in, out);

    switch (type)
    {
        case 1:

            dfp.cal = Read_CALCONV(in, out, "Calendar");
            dfp.iconv = Read_INTPOLCONV(in, out, "Interpolation");
            dfp.what = Read_DISCIPOL(in, out, "Interpolation In");
            dfp.irr = Read_IRRCONV(in, out, "IRR");
            dfp.freq = Read_PMTFREQ(in, out, "IRR Quoting");
            break ;

        case 2:

            dfp.irr = Read_IRRCONV(in, out, "IRR");
            dfp.freq = Read_PMTFREQ(in, out, "IRR Quoting");
            dfp.cal = Read_CALCONV(in, out, "Calendar");

            dfp.iconv = LINEAR_EXTRAPOL ;
            dfp.what  = DI_SPOT ;

            break ;

        case 3:

            dfp.cal   = EU30E360 ;
            dfp.iconv = LINEAR_EXTRAPOL ;
            dfp.what  = DI_SPOT ;
            dfp.irr   = COMPOUND ;
            dfp.freq  = ANNUALLY ;

            break ;

        case 4:

            dfp.cal   = EU30E360 ;
            dfp.iconv = LINEAR_EXTRAPOL ;
            dfp.what  = DI_SPOT ;
            dfp.irr   = CONTINUOUS ;
            dfp.freq  = ANNUALLY ;

            break ;

        case 5:

            dfp.what = Read_DISCIPOL(in, out, "Interpolation In");
            dfp.iconv = Read_INTPOLCONV(in, out, "Interpolation");
            dfp.cal = Read_CALCONV(in, out, "Calendar");
            dfp.irr   = CONTINUOUS ;
            dfp.freq  = ANNUALLY ;

            break ;

        case 6:

            dfp.what = Read_DISCIPOL(in, out, "Interpolation In");
            dfp.iconv = Read_INTPOLCONV(in, out, "Interpolation");
            dfp.cal = Read_CALCONV(in, out, "Calendar");
            dfp.irr   = COMPOUND ;
            dfp.freq  = ANNUALLY ;

            break ;

        case 7:

            dfp.cal = Read_CALCONV(in, out, "Calendar");
            dfp.iconv = LINEAR_EXTRAPOL ;
            dfp.what  = DI_SPOT ;
            dfp.irr   = COMPOUND ;
            dfp.freq  = ANNUALLY ;

            break ;

        case 8:

            dfp.cal = Read_CALCONV(in, out, "Calendar");
            dfp.iconv = LINEAR_EXTRAPOL ;
            dfp.what  = DI_SPOT ;
            dfp.irr   = CONTINUOUS ;
            dfp.freq  = ANNUALLY ;

            break ;

        case 9:

            dfp.what = Read_DISCIPOL(in, out, "Interpolation In");
            dfp.iconv = Read_INTPOLCONV(in, out, "Interpolation");
            dfp.cal = Read_CALCONV(in, out, "Calendar");
            dfp.irr = Read_IRRCONV(in, out, "IRR");
            dfp.freq = Read_PMTFREQ(in, out, "IRR Quoting");
            break ;

    }

    Write_VALIDATEError(out, Validate_DFPARMS(&dfp));

    return dfp ;
}


/*
..
*/


FL64MATRIX Read_FL64MATRIX(FILE* in, FILE* out, INTI* n1, INTI* n2)
{
    FL64MATRIX f ;
    int        i1, i2 ;
    INTI       i, j ;

    fscanf(in, "%d %d", &i1, &i2) ;
    *n1 = (INTI) i1 ;
    *n2 = (INTI) i2 ;
    f = Alloc_FL64MATRIX((INTI) i1, (INTI) i2) ;
    for (i = 0; i < i1; i++)
    {
        for (j = 0; j < i2; j++)
        {
            fscanf(in, "%lf", &f[i][j]) ;
            fprintf(out, " %lf", f[i][j]) ;
        }

        fprintf(out, "\n") ;
    }

    Write_VALIDATEError(out, Validate_FL64MATRIX(f, i1, i2, False,
      0.0, False, 0.0));

    return f ;
}


/*
..
*/

INTI Write_PlanDiff(PLANARRAY exp, PLANARRAY res, FILE* out)
{
    INTI     i, diff, dif1 ;
    YYYYMMDD ymd, ymd1 ;

    diff = 1 ;

    fprintf(out, "\nThe Output Plan is\n") ;

    fprintf(out,"OK   Expected            Calculated\n") ;
    fprintf(out,"     Date     Fl64       Date     Fl64\n") ;

    if (GetPlanFill(res) == GetPlanFill(exp))
    {
        for (diff = i = 0 ; i < GetPlanFill(res) ; i++)
        {
            ymd  = Cldr_Datestr2YMD(&res->day[i]) ;
            ymd1 = Cldr_Datestr2YMD(&exp->day[i]) ;
            dif1 = ymd != ymd1 ||
                    fabs(res->f64[i] - exp->f64[i]) >= 0.00001 ;
            diff = diff || dif1 ;
            fprintf(out, "%d;  %8ld %15.14lf %8ld %15.14lf\n",
                        dif1, ymd1, exp->f64[i], ymd, res->f64[i]) ;
        }
    }

    else
    {
        fprintf(out, "1; Fill mismatch %d %d\n\n",
                GetPlanFill(res), GetPlanFill(exp)) ;
        fprintf(out, "Got: Date     Fl64\n");
        for (i = 0; i < GetPlanFill(res); i++)
        {
            ymd = Cldr_Datestr2YMD(&res->day[i]);
            fprintf(out, " ?;  %8ld %15.14lf\n", ymd, res->f64[i]);
        }

        fprintf(out, "Exp: Date     Fl64\n");
        for (i = 0; i < GetPlanFill(exp); i++)
        {
            ymd = Cldr_Datestr2YMD(&exp->day[i]);
            fprintf(out, " ?;  %8ld %15.14lf\n", ymd, exp->f64[i]);
        }
    }
    return diff ;
}


/*
..
*/

IRRATE Read_IRRATE(FILE* in, FILE* out)
{
    IRRATE  irr ;
    char    txb[25], txc[25] ;

    fprintf(out,"   IRRATE:\n") ;

    fscanf(in, "%lf %s %s", &irr.rate, txb, txc) ;

    fprintf(out,"   irr         %s\n", txb) ;
    fprintf(out,"   qbas        %s\n", txc) ;

    irr.irr  = Str2IRRCONV(txb) ;
    irr.freq = Str2PMTFREQ(txc) ;

    return irr ;
}


/*
..
*/


ZRATE_STR Read_ZRATE_STR(FILE* in, FILE* out)
{
    ZRATE_STR  zrates ;
    char       txb[25], txc[25], txd[25], txe[25], txf[25] ;

    fprintf(out,"   ZRATE_STR:\n") ;

    zrates.period = Read_PERIOD(in) ;

    fscanf(in, "%lf %s %s %s %s %s", &zrates.rate, txb, txc, txd, txe, txf) ;

    fprintf(out,"   irr         %s\n", txb) ;
    fprintf(out,"   qbas        %s\n", txc) ;
    fprintf(out,"   cal         %s\n", txd) ;
    fprintf(out,"   bus         %s\n", txe) ;
    fprintf(out,"   eom         %s\n", txf) ;

    zrates.irr  = Str2IRRCONV(txb) ;
    zrates.freq = Str2PMTFREQ(txc) ;
    zrates.cal  = Str2CALCONV(txd) ;
    zrates.bus  = Str2BUSCONV(txe) ;
    zrates.eom  = Str2EOMCONV(txf) ;

    Write_VALIDATEError(out, Validate_ZRATE_STR(&zrates));

    return zrates ;
}

/*
..
*/


INTI WriteFL64ARRAYDiff(BOOLE okexp, FL64ARRAY dvexp, INTI nshockexp, 
                        BOOLE ok, FL64ARRAY dv, INTI nshock, 
                        FILE* out, FL64 tol)
{
    INTI diff, diff1, i;

    diff = 0 ;
    if (okexp == ok)
    {
        fprintf(out, "0; Result status: %d\n", ok);
        if (nshockexp == nshock)
        {
            for (i = 0; i < nshock; i++)
            {
                diff1 = fabs(dvexp[i] - dv[i]) > tol ;
                fprintf(out, "%d; %d exp %10.7lf res %10.7lf\n",
                        diff1, i, dvexp[i], dv[i]) ;
                diff = diff || diff1;
            }
        }
        else
        {
            fprintf(out, "1; Arraysizes mismatch.\n");
            diff = 1;
        }
    }
    else
    {
        fprintf(out, "1; Result status mismatch, ");
        fprintf(out, "Exp: %d, Act: %d\n", okexp, ok);
        diff = 1;
    }

    return diff;
}

/*
..
*/

INTI WriteFL64ARRAYRelDiff(BOOLE okexp, FL64ARRAY dvexp, INTI nshockexp, 
                        BOOLE ok, FL64ARRAY dv, INTI nshock, 
                        FILE* out, FL64 tol)
{
    INTI diff, diff1, i;

    diff = 0 ;
    if (okexp == ok)
    {
        fprintf(out, "0; Result status: %d\n", ok);
        if (nshockexp == nshock)
        {
            for (i = 0; i < nshock; i++)
            {
                if (fabs(dvexp[i]) > 1.0e-10)
                  diff1 = fabs(dv[i] / dvexp[i] - 1) > tol ;
                else
                  diff1 = fabs(dv[i] - dvexp[i]) > tol ;
                fprintf(out, "%d; %d exp %10.7lf res %10.7lf\n",
                        diff1, i, dvexp[i], dv[i]) ;
                diff = diff || diff1;
            }
        }
        else
        {
            fprintf(out, "1; Arraysizes mismatch.\n");
            diff = 1;
        }
    }
    else
    {
        fprintf(out, "1; Result status mismatch, ");
        fprintf(out, "Exp: %d, Act: %d\n", okexp, ok);
        diff = 1;
    }

    return diff;
}

/*
..
*/

INTI Write_PlansDiff(FILE*  in, FILE*  out, PLANARRAY  res, 
    INTI  nres)
{
    INTI diff, nexp, i;
    PLANARRAY exp;

    diff = 0;
    nexp = Read_INTI(in, out, "  Exp. no of plans  ");

    if (nexp != nres)
    {
        fprintf(out, "1; Sizes mismatch: Exp %d, Act %d.\n", 
            nexp, nres);
        return 1;
    }

    diff = 0 ;
    for (i = 0; i < nexp; i++)
    {
        exp = Read_PLANARRAY(in);
        diff = diff || Write_PlanDiff(exp, &res[i], out);
        Free_PLANARRAY(exp, 1);
    }

    return diff;
}

/*
..
*/

INTI Write_TSDiff(FILE*  in, FILE*  out, TS_STR*  ts, FL64  acc)
{
    INTI i, n, nexp, diff;
    FL64 rate, loading, term;
    INTL ymd;
    DATESTR date;

    /* warning avoidance */
    diff = 0;

    n = ts->count;
    nexp = Read_INTI(in, out, "Expected TS size ");

    fprintf(out, "   date     exp.term act.term exp.rate ");
    fprintf(out, "act.rate exp.load. act.load\n");

    if (n != nexp)
    {
      fprintf(out, "1; TS size mismatch: Exp %d, Actual %d.\n", 
        nexp, n);
      return 1;
    }

    for (i = 0; i < nexp; i++)
    {
        fscanf(in,"%ld %lf %lf %lf", &ymd, &term, &rate, &loading);

        date = Cldr_YMD2Datestr(ymd) ;
        diff = (fabs(ts->term[i] - term) > acc) ||
               (fabs(ts->rate[i] - rate) > acc) ||
               (fabs(ts->loading[i] - loading) > acc);
        fprintf(out,"%d; %8ld %8lf %8lf %8lf %8lf %8lf %8lf\n",
                diff, ymd, term, ts->term[i], rate, ts->rate[i],
                loading, ts->loading[i]);
    }

    return diff;
}



/* SCID @(#)volalloc.c	1.22 (SimCorp) 99/10/27 14:25:40 */

/************************************************************************
*
*    project    SCecon
*
*    filename   volalloc.c
*
*    general    allocating routines for the vol module of SCecon
*
************************************************************************/

#include <stdlib.h>
#include <vol.h>


/*,,SOH,,
***************************************************************************
*
*                Alloc_TSOVARRAY()
*
*    interface   #include <vol.h>
*                TSOVARRAY Alloc_TSOVARRAY(INTI ns,
*                                          INTI np) ;
*
*    general     Allocates memory for an array that can hold information
*                about ns volatility structures.
*
*                Returns memory with zero'ed entries.
*
*    input       INTI  ns     Number of structures.
*
*                INTI  np     Number of terms and vols per TSOV_STR.
*
*    output
*
*    returns     reference to allocated TSOV_STR array.
*
*    diagnostics aborts calling SCecon_error()
*                with the message   "Allocation failed"
*                         routine   "Alloc_TSOVARRAY"
*                         actioncode SCECONABORT
*                if allocation fails.
*
*    see also    Free_TSOVARRAY()
*
***************************************************************************
,,EOH,,*/


TSOVARRAY Alloc_TSOVARRAY(INTI ns, INTI  np)
{
    TSOVARRAY   a ;
    INTI        i;

    a = (TSOVARRAY) SCecon_calloc(ns, sizeof(TSOV_STR), True,
      "Alloc_TSOVARRAY") ;

    for (i = 0 ; i < ns ; i++)
    {
        a[i].term = Alloc_FL64ARRAY(np) ;
        a[i].vol  = Alloc_FL64ARRAY(np) ;
    }

    return a ;
}


/*,,SOH,,
***************************************************************************
*
*                Free_TSOVARRAY()
*
*    interface   #include <vol.h>
*                void Free_TSOVARRAY(TSOVARRAY s,
*                                    INTI      ns) ;
*
*    general     Frees memory for a given number of TSOVARRAYS's allocated
*                by Alloc_TSOVARRAY().
*
*    input       TSOVARRAY s   The structs already allocated.
*
*                INTI      ns  Number of structs in s.
*
*    output
*
*    returns
*
*    diagnostics
*
*    see also    Alloc_TSOVARRAY()
*
***************************************************************************
,,EOH,,*/


void Free_TSOVARRAY(TSOVARRAY s, INTI  ns)
{
    INTI  i ;
    TSOV_STR *vol ;

    vol = s ;
    ns  = GETMAX(1, ns) ;

    for (i = 0 ; i < ns ; i++)
    {
        Free_FL64ARRAY(vol[i].term) ;
        Free_FL64ARRAY(vol[i].vol) ;
    }

    SCecon_free((VOIDPTR) vol) ;
}


/*,,SOH,,
***************************************************************************
*
*                Alloc_VOLBOX()
*
*    interface   #include <vol.h>
*                VOLBOX * Alloc_VOLBOX(INTI count_OM,
*                                        INTI count_S,
*                                        INTI count_SM) ;
*
*    general     Allocates memory for an array that can hold information
*                about a 3D vol structure.
*
*                Returns memory with zero'ed entries.
*
*    input       INTI  count_OM  No. of option maturities
*
*                INTI  count_S   No. of strikes
*
*                INTI  count_SM  No. of swap maturities.
*
*    output
*
*    returns     reference to allocated 3D structure
*
*    diagnostics aborts calling SCecon_error()
*                with the message   "Allocation failed"
*                         routine   "Alloc_VOLBOX()"
*                         actioncode SCECONABORT
*                if allocation fails.
*
*    see also    Free_VOLBOX()
*
***************************************************************************
,,EOH,,*/


VOLBOX *Alloc_VOLBOX(INTI count_OM, INTI count_S, INTI count_SM)
{
    VOLBOX    *vm ;
    INTI        i, j ;

    vm = (VOLBOX *) SCecon_calloc(1, sizeof(VOLBOX), True, "Alloc_VOLBOX()") ;

    vm->count_OM = count_OM ;
    vm->count_S = count_S ;
    vm->count_SM = count_SM ;

    /* Allocate 'index arrays' */
    vm->optmatur = Alloc_DATEARRAY(count_OM) ;
    vm->strike = Alloc_FL64ARRAY(count_S) ;
    vm->swapmatur = Alloc_PERIODARRAY(count_SM) ;

    /* Allocate volatility matrix */
    vm->vol = (FL64***) SCecon_calloc(count_OM, sizeof(FL64 **), True, 
      "Alloc_VOLBOX()") ;

    for (i = 0; i < count_OM; i++)
    {
        vm->vol[i] = (FL64 **) SCecon_calloc(count_S, sizeof(FL64 *), True,
          "Alloc_VOLBOX()") ;

        for (j = 0; j < count_S; j++)
            vm->vol[i][j] = Alloc_FL64ARRAY(count_SM) ;
    }

    return vm ;
}


/*,,SOH,,
***************************************************************************
*
*                Free_VOLBOX()
*
*    interface   #include <vol.h>
*                void Free_VOLBOX(VOLBOX *tsov) ;
*
*    general     Frees memory for a given number of VOLBOX's allocated
*                by Alloc_VOLBOX().
*
*    input       VOLBOX *tsov  The structs already allocated.
*
*    output
*
*    returns
*
*    diagnostics
*
*    see also    Alloc_VOLBOX()
*
***************************************************************************
,,EOH,,*/


void Free_VOLBOX(VOLBOX* tsov)
{
    INTI i, j ;

    /* Free 'index arrays' */
    Free_DATEARRAY(tsov->optmatur) ;
    Free_FL64ARRAY(tsov->strike) ;
    Free_PERIODARRAY(tsov->swapmatur) ;

    /* Free volatility matrix */
    for (i = 0; i < tsov->count_OM; i++)
    {
        for (j = 0; j < tsov->count_S; j++)
            Free_FL64ARRAY(tsov->vol[i][j]) ;
       SCecon_free((VOIDPTR) tsov->vol[i]) ;
    }

    SCecon_free((VOIDPTR) tsov->vol) ;
    SCecon_free((VOIDPTR) tsov) ;
}


/*,,SOH,,
*************************************************************************
*
*               Free_VOL_STR()
*
*    interface  #include <vol.h>
*               void Free_VOL_STR(VOL_STR *v) ;
*
*    general    The routine frees a VOL_STR
*
*    input      VOL_STR   *v           Reference to the array
*
*    output
*
*    returns
*
*    diagnostics
*
*    see also
*
*************************************************************************
,,EOH,,*/

void Free_VOL_STR(VOL_STR* v)
{
    if (v != NULL)
        Free_PLANARRAY(v->vol, 1) ;
}



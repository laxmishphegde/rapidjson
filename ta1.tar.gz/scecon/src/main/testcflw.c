/* SCID @(#)testcflw.c	1.12 (SimCorp) 99/10/27 13:05:21 */

/************************************************************************
*
*   project     SCecon
*
*   filename    cflwtest.c
*
*   this program tests the routines in the cash flow module of SCecon
*
************************************************************************/

/*** includes ***********************************************************/
#include <string.h>
#include <scalloc.h>
#include <str2conv.h>
#include <pmt.h>
#include <ioconv.h>


/*** prototyping  *******************************************************/


INTI cflwtest(char* txa, FILE* in, FILE* out)
{
    char      txb[25], txpl[64];
    INTI      n , i, count ;
    INTI      diff, dif1 ;
    FL64      fexp, fres, ai, npv, pr, debt, prate;
    FL64      acc, *eweight, *weight ;
    FL64ARRAY erepay, ecoupon, repay, coupon, prates ;
    BOOLE     prepaid ;
    BONDTYPE  bt ;
    int       i1, i2 ;

    acc = 0.00001 ;

    diff = -1 ;

    if (!strcmp("Cflw_Annuity()", txa))
    {
        fscanf(in, "%lf %lf %d %s %s", &fexp, &pr, &i1, txb, txpl);
        n = (INTI) i1 ;
        prepaid = Str2BOOLE(txb) ;
        fres = Cflw_Annuity(pr, n, prepaid);
        diff = (fabs(fres - fexp) > acc) ;

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   periodic coupon    %8.5lf\n", pr) ;
        fprintf(out,"   number of payments %8d\n", n) ;
        fprintf(out,"   prepaid            %8s\n", txb) ;
        fprintf(out,"   result is %8lf ; expected is %8lf\n", fres, fexp) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }

    else if (!strcmp("Cflw_OutstandingAnnuity()", txa))
    {
        fscanf(in, "%lf %lf %d %d %s", &fexp, &pr, &i1, &i2, txpl);
        n = (INTI) i1 ;
        count = (INTI) i2 ;
        fres = Cflw_OutstandingAnnuity(pr, n, count);
        diff = (fabs(fres - fexp) > acc) ;

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   periodic coupon          %8.5lf\n", pr) ;
        fprintf(out,"   orig. number of payments %8d\n", n) ;
        fprintf(out,"   number of rem. payments  %8d\n", count) ;
        fprintf(out,"   result is %8lf ; expected is %8lf\n", fres, fexp) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }

    else if (!strcmp("Cflw_OutstandingSerial()", txa))
    {
        fscanf(in, "%lf %d %d %s", &fexp, &i1, &i2, txpl);
        n = (INTI) i1 ;
        count = (INTI) i2 ;
        fres = Cflw_OutstandingSerial(n, count);
        diff = (fabs(fres - fexp) > acc) ;

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   orig. number of payments %8d\n", n) ;
        fprintf(out,"   number of rem. payments  %8d\n", count) ;
        fprintf(out,"   result is %8lf ; expected is %8lf\n", fres, fexp) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }

    else if (!strcmp(txa, "Cflw_RepaidDebt()"))
    {
        fscanf(in, "%d %s", &i1, txpl);
        n = (INTI) i1 ;

        repay  = Alloc_FL64ARRAY(n);
        eweight = Alloc_FL64ARRAY(n);
        for (i = 0 ; i < n ; i++)
            fscanf(in,"%lf %lf", &eweight[i], &repay[i]);

        weight = Cflw_RepaidDebt(repay, n);

        fprintf(out,"?; testing %s\n", txa) ;
        fprintf(out,"   number of payments %8d\n", n) ;
        fprintf(out,"   the repayment schedule is...\n") ;
        for (i = 0 ; i < n ; i++)
            fprintf(out,"   repayment[%2d] %10.5lf\n", i, repay[i]) ;

        diff = 0 ;
        for (i = 0 ; i < n ; i++)
        {
            dif1 = (fabs(weight[i] - eweight[i]) > acc) ;
            diff = (dif1 ? 1 : diff) ;
            fprintf(out,"%d; result[%2d] %8.5lf ; expected[%2d] %8.5lf\n",
                        diff, i, weight[i], i, eweight[i]);
        }
        fprintf(out,"   %s\n\n", txpl) ;

        Free_FL64ARRAY(eweight);
        Free_FL64ARRAY(weight);
        Free_FL64ARRAY(repay);
    }

    else if (!strcmp(txa, "Cflw_OutstandingDebt()"))
    {
        fscanf(in, "%d %s", &i1, txpl);
        n = (INTI) i1 ;

        repay  = Alloc_FL64ARRAY(n);
        eweight = Alloc_FL64ARRAY(n);
        for (i = 0 ; i < n ; i++)
            fscanf(in,"%lf %lf", &eweight[i], &repay[i]);

        weight = Cflw_OutstandingDebt(repay, n) ;

        fprintf(out,"?; testing %s\n", txa) ;
        fprintf(out,"   number of payments %8d\n", n) ;
        fprintf(out,"   the repayment schedule is...\n") ;
        for (i = 0 ; i < n ; i++)
            fprintf(out,"   repayment[%2d] %10.5lf\n", i, repay[i]) ;

        diff = 0 ;
        for (i = 0 ; i < n ; i++)
        {
            dif1 = (fabs(weight[i] - eweight[i]) > acc) ;
            diff = (dif1 ? 1 : diff) ;
            fprintf(out,"%d; result[%2d] %8.5lf ; expected[%2d] %8.5lf\n",
                        diff, i, weight[i], i, eweight[i]);
        }
        fprintf(out,"   %s\n\n", txpl) ;

        Free_FL64ARRAY(eweight);
        Free_FL64ARRAY(weight);
        Free_FL64ARRAY(repay);
    }

    else if (!strcmp(txa, "Cflw_Bondtype2Payments()"))
    {
        fprintf(out,"?; testing %s\n", txa) ;

        prate = Read_FL64(in, out, "Constant period rate: ");
        prates = Read_FL64ARRAY(in, &n);
        fprintf(out, "Varying period rates: \n");
        Write_FL64ARRAY(out, prates, n);
        n = Read_INTI(in, out, "Number of payments: ");
        bt = Read_BONDTYPE(in, out, "Bond type: ");
        prepaid = Read_BOOLE(in, out, "Prepaid?: ");
        fscanf(in, "%s", txpl);

        erepay  = Alloc_FL64ARRAY(n);
        ecoupon = Alloc_FL64ARRAY(n);
        for (i = 0 ; i < n ; i++)
            fscanf(in,"%lf %lf", &erepay[i], &ecoupon[i]);

        repay  = Alloc_FL64ARRAY(n);
        coupon = Alloc_FL64ARRAY(n);

        Cflw_Bondtype2Payments(prate, prates, n, bt, prepaid, repay, coupon);

        fprintf(out,"   resulting cash flows...\n") ;
        fprintf(out,"          computed              expected\n") ;
        fprintf(out,
          "   number repayment    coupon   repayment    coupon\n")
          ;

        diff = 0 ;
        for (i = 0 ; i < n ; i++)
        {
            dif1 = (fabs(repay[i] - erepay[i]) > acc ||
                    fabs(coupon[i] - ecoupon[i]) > acc) ;
            diff = (dif1 ? 1 : diff) ;
            fprintf(out,"%d;   [%2d] %9.5lf %9.5lf ; %9.5lf %9.5lf\n",
                    diff, i, repay[i], coupon[i], erepay[i], ecoupon[i]);
        }
        fprintf(out,"   %s\n\n", txpl) ;

        Free_FL64ARRAY(prates);
        Free_FL64ARRAY(erepay);
        Free_FL64ARRAY(ecoupon);
        Free_FL64ARRAY(repay);
        Free_FL64ARRAY(coupon);
    }

    else if (!strcmp("cflw_dirty2clean()", txa))
    {
        fscanf(in, "%lf %lf %lf %s", &fexp, &pr, &ai, txpl);
        fres = cflw_dirty2clean(pr, ai);
        diff = (fabs(fres - fexp) > acc) ;

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   dirty price %9.5lf\n", pr) ;
        fprintf(out,"   accrued     %9.5lf\n", ai) ;
        fprintf(out,
          "   result is %9.5lf ; expected is %9.5lf\n",
          fres, fexp) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }

    else if (!strcmp("cflw_clean2dirty()", txa))
    {
        fscanf(in, "%lf %lf %lf %s", &fexp, &pr, &ai, txpl);
        fres = cflw_clean2dirty(pr, ai);
        diff = (fabs(fres - fexp) > acc) ;

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   clean price %9.5lf\n", pr) ;
        fprintf(out,"   accrued     %9.5lf\n", ai) ;
        fprintf(out,
          "   result is %9.5lf ; expected is %9.5lf\n",
          fres, fexp) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }

    else if (!strcmp("cflw_npv2dirty()", txa))
    {
        fscanf(in, "%lf %lf %lf %s", &fexp, &npv, &debt, txpl);
        fres = cflw_npv2dirty(npv, debt);
        diff = (fabs(fres - fexp) > acc) ;

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   net present value %9.5lf\n", npv) ;
        fprintf(out,"   outstanding debt  %9.5lf\n", debt) ;
        fprintf(out,
          "   result is %9.5lf ; expected is %9.5lf\n",
          fres, fexp) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }

    else if (!strcmp("cflw_dirty2npv()", txa))
    {
        fscanf(in, "%lf %lf %lf %s", &fexp, &pr, &debt, txpl);
        fres = cflw_dirty2npv(pr, debt);
        diff = (fabs(fres - fexp) > acc) ;

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   dirty price      %9.5lf\n", pr) ;
        fprintf(out,"   outstanding debt %9.5lf\n", debt) ;
        fprintf(out,
          "   result is %9.5lf ; expected is %9.5lf\n",
          fres, fexp) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }



    return diff ;
}

/* SCID @(#)dateconv.c	1.12 (SimCorp) 99/02/19 14:15:14 */

/************************************************************************
*
*   project     SCecon
*
*   file name   dateconv.c
*
*   general     This file contains standard routines for calendar
*               calculations
*
************************************************************************/

/* includes ************************************************************/
#include <cldr.h>

/*,,SOH,,
*************************************************************************
*
*               Cldr_Date2md()
*
*   interface   #include <cldr.h>
*               MMDD Cldr_Date2md(DATESTR *date) ;
*
*   general     Cldr_Date2md() is a function for converting the input
*               date of type DATESTR to a type MMDD.
*
*   input       DATESTR  *date      The input date.
*
*   output
*
*   returns     the date as MMDD.
*
*   diagnostics
*
*   see also    Cldr_Datestr2YMD()
*
*************************************************************************
,,EOH,,*/


MMDD Cldr_Date2md(DATESTR* date)
{
    return 100*date->m + date->d ;
}


/*,,SOH,,
*************************************************************************
*
*               Cldr_YMD2Datestr()
*
*   interface   #include <cldr.h>
*               DATESTR Cldr_YMD2Datestr(YYYYMMDD ymd) ;
*
*   general     Cldr_YMD2Datestr() converts the input date of type
*               YYYYMMDD to type DATESTR.
*               The input date should be after christ (AC). If not
*               the conversion is wrong.
*
*   input       YYYYMMDD   ymd      The input date.
*
*   output
*
*   returns     the output date as a DATESTR.
*
*   diagnostics
*
*   see also    Cldr_Datestr2YMD()
*
*************************************************************************
,,EOH,,*/


DATESTR Cldr_YMD2Datestr(YYYYMMDD ymd)
{
    DATESTR dateout ;

    /* Speed enhancements, 7/31/91, HED */
    dateout.y = (INTI ) (ymd/10000) ;
    ymd      -= 10000L*dateout.y ;
    dateout.m = (INTI ) (ymd)/100 ;
    ymd      -= 100L*dateout.m ;
    dateout.d = (INTI ) ymd ;

    return dateout ;
}


/*,,SOH,,
*************************************************************************
*
*               Cldr_Datestr2YMD()
*
*   interface   #include <cldr.h>
*               YYYYMMDD Cldr_Datestr2YMD(DATESTR *date) ;
*
*   general     Cldr_Datestr2YMD() converts the input date of type
*               DATESTR to type YYYYMMDD.
*
*   input       DATESTR *date       The input date
*
*   output
*
*   returns     the converted date as YYYYMMDD.
*
*   diagnostics
*
*   see also    Cldr_YMD2Datestr()
*
*************************************************************************
,,EOH,,*/


YYYYMMDD Cldr_Datestr2YMD(DATESTR* date)
{
    return (YYYYMMDD) (10000L*date->y + 100L*date->m + date->d) ;
}

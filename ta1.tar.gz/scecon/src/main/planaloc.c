/* SCID @(#)planaloc.c	1.16 (SimCorp) 99/10/27 14:25:39 */

/************************************************************************
*
*    project    SCecon
*
*    filename   planaloc.c
*
*    general    allocating routines for the cldr module of SCecon
*
************************************************************************/

#include <stdlib.h>
#include <cldr.h>


/*,,SOH,,
*************************************************************************
*
*                Alloc_PLANARRAY()
*
*    interface   #include <cldr.h>
*                PLANARRAY Alloc_PLANARRAY(INTI ns,
*                                          INTI np) ;
*
*    general     Allocates memory for an array that can hold information
*                about ns plan structures.
*                Returns memory with zero'ed entries
*
*                The count elements are filled with np.
*
*    input       INTI  ns     Number of structures.
*
*                INTI  np     Number of day/f64 elements per PLAN_STR.
*
*    output
*
*    returns     Reference to allocated PLAN_STR array.
*
*    diagnostics aborts calling SCecon_error()
*                with the message   "Allocation failed"
*                         routine   "Alloc_PLANARRAY()"
*                         actioncode SCECONABORT
*                if allocation fails.
*
*    see also    Free_PLANARRAY()
*
*************************************************************************
,,EOH,,*/


PLANARRAY Alloc_PLANARRAY(INTI ns, INTI  np)
{
    PLANARRAY   a ;
    INTI        i;

    a = (PLANARRAY) SCecon_calloc(ns, sizeof(PLAN_STR), True,
      "Alloc_PLANARRAY()") ;

    for (i = 0 ; i < ns ; i++)
    {
        a[i].count = np ;
        a[i].day = Alloc_DATEARRAY(np) ;
        a[i].f64 = Alloc_FL64ARRAY(np) ;
    }

    return a ;
}


/*,,SOH,,
*************************************************************************
*
*                Free_PLANARRAY()
*
*    interface   #include <cldr.h>
*                void Free_PLANARRAY(PLANARRAY s,
*                                    INTI      ns) ;
*
*    general     Frees memory for a given number of PLANARRAYS's
*                allocated by Alloc_PLANARRAY().
*
*    input       PLANARRAY s   The structs already allocated.
*
*                INTI      ns  Number of structs in s.
*
*    output
*
*    returns
*
*    diagnostics
*
*    see also    Alloc_PLANARRAY()
*
***************************************************************************
,,EOH,,*/


void Free_PLANARRAY(PLANARRAY s, INTI ns)
{
    INTI  i ;
    PLAN_STR *plan ;

    if (!s)
        return ;

    ns   = GETMAX(1, ns) ;
    plan = s ;

    for (i = 0 ; i < ns ; i++)
    {
        Free_DATEARRAY(plan[i].day) ;
        Free_FL64ARRAY(plan[i].f64) ;
    }

    SCecon_free((VOIDPTR) plan) ;
}


/*
..
*/


PLANARRAY Alloc_PLAN(INTI ns)
{
    PLANARRAY   a ;

    a = (PLANARRAY) SCecon_calloc(ns, sizeof(PLAN_STR), True,
      "Alloc_PLAN()") ;

    return a ;
}


/*
..
*/


void Free_PLAN(PLANARRAY s)
{
    SCecon_free((VOIDPTR) s) ;
}

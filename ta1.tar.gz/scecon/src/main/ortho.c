#include <sccsid.h>
SCCSID(ortho_c,
  "@(#)ortho.c	1.15 (SimCorp) 99/07/14 15:23:15")
/* source file for orthogonal decomposition routines */

/***** includes  *******************************************************/
#include <scutl.h>


/*
Math_MatrixVectorMult: Matrix-vector multiplication
---------------------------------------------------

Post-multiplies a quadratic matrix by a vector.
*/
void Math_MatrixVectorMult(INTI       dim,
                                 FL64MATRIX inv,
                                 FL64ARRAY  icov,
                                 FL64ARRAY  out)
{
  INTI i, j;

  for (i = 0; i < dim; i++)
  {
    out[i] = 0.0 ;
    for (j = 0; j < dim; j++)
      out[i] += inv[i][j] * icov[j] ;
  }
}



/*
..
*/
void Free_ORTODECOMP(ORTODECOMP*  x)
{
  Free_FL64ARRAY(x->l);
  Free_FL64MATRIX(x->v);
}


/*
Derives eigen-decomposition for a symmetric matrix
taking only the 'nfac' most important eigen-vectors.
*/
ORTODECOMP Math_SYM2OrthoDecomp(FL64MATRIX  smtrx, 
                                   INTI        dim, 
                                   INTI        nfac,
                                   INTI        maxit,
                                   BOOLE*      ok)
{
  INTIARRAY  index;
  FL64MATRIX mtmp;
  FL64ARRAY  vtmp;
  ORTODECOMP od;
  INTI       i, j;

  od.n = dim;
  od.nfac = nfac;
  od.v = Alloc_FL64MATRIX(dim, nfac);
  od.l = Alloc_FL64ARRAY(nfac);

  mtmp = Alloc_FL64MATRIX(dim, dim);
  vtmp = Alloc_FL64ARRAY(dim);

  *ok = (od.v && od.l && mtmp && vtmp);

  for (i = 0; i < dim && *ok; i++)
  {
    mtmp[i][i] = smtrx[i][i];
    for (j = i + 1; j < dim; j++)
      mtmp[j][i] = mtmp[i][j] = smtrx[i][j];
  }


  *ok = *ok && Math_SYM2OD(dim, mtmp, vtmp, maxit);

  index = Scutl_Indexx_FL64(dim, vtmp, DESCENDING);

  for (j = 0; j < nfac; j++)
  {
    od.l[j] = vtmp[index[j]];
    for (i = 0; i < dim; i++)
      od.v[i][j] = mtmp[i][index[j]];
  }

  Free_INTIARRAY(index);
  Free_FL64ARRAY(vtmp);
  Free_FL64MATRIX(mtmp);

  return od;
}



/*
Translates a symmetric matrix into eigen-value scaled
orthogonal decomposition.
*/
BOOLE Math_SYM2ODS(INTI  dim, FL64MATRIX  smtrx, INTI  maxit)
{
    BOOLE           ok ;
    FL64ARRAY       ev ;
    INTI           i, j ;
    
    ev = Alloc_FL64ARRAY(dim) ;
    
    ok = Math_SYM2OD(dim, smtrx, ev, maxit) ;
    
    for (i = 0; ok && i < dim; i++)
    {
        if (ev[i] <= 0.0)
            ok = False ;
        else
            ev[i] = sqrt(ev[i]) ;
    }

    for (i = 0; ok && i < dim; i++)
        for (j = 0; j < dim; j++)
            smtrx[i][j] *= ev[j] ;

    Free_FL64ARRAY(ev) ;

    return ok ;
}


/* Transformation of a symmetric matrix smtrx to orthogonal decomposition 
   Done by this:
   - First transform smtrx to a tri-diagonal form 
      (diagonal and off-diagonal, all others zero)
     This is done by Math_SYM2TD()
   - Second transform the tri-diagonal form into
     the orthogonal form yielding the eigenvalues (ev) and 
     eigenvectors (smtrx)
*/
BOOLE Math_SYM2OD(INTI  dim, FL64MATRIX  smtrx, 
                     FL64ARRAY  ev, INTI  maxit)
{
    FL64ARRAY    tmp ;
    BOOLE        ok ;
    
    /* allocate */
    tmp = Alloc_FL64ARRAY(dim) ;
    
    /* put matrix on tri-diagonal form */
    Math_SYM2TD(smtrx, dim, ev, tmp) ;
    
    /* find eigenvalues and orthogonal matrix */
    ok = Math_TD2OD(ev, tmp, dim, smtrx, maxit) ;

    /* Free */
    Free_FL64ARRAY(tmp) ;
    
  /* return */
  return ok ;
}


/*
Computes the determinant of a symmetric matrix
*/
BOOLE Math_SYM2Det(INTI  nfac, 
                      INTI  dim, 
                      FL64MATRIX  matrix, 
                      INTI   maxit,
                      FL64*  determ)
{
  FL64MATRIX mtrx;
  FL64ARRAY  ev;
  FL64       v;
  INTI       i, j, k, l;
  BOOLE      ok;

  mtrx = Alloc_FL64MATRIX(dim, dim);
  ev = Alloc_FL64ARRAY(dim);

  for (i = 0; i < dim; i++)
    for (j = 0; j < dim; j++)
      mtrx[i][j] = matrix[i][j];

  ok = Math_SYM2OD(dim, mtrx, ev, maxit);

  /* Rearrange eigenvalues and -vectors in decreasing order */
  for (l = 0; ok && l < dim; l++)
  {
    v = ev[k=l] ;
    for (j = l + 1; j < dim; j++)
      if (ev[j] >= v)
        v = ev[k=j] ;
    if (k != l)
    {
      ev[k] = ev[l] ;
      ev[l] = v ;
      for (j = 0; j < dim; j++)
      {
        v = mtrx[j][l] ;
        mtrx[j][l] = mtrx[j][k] ;
        mtrx[j][k] = v ;
      }
    }
  }

  *determ = 1.0;
  for (i = 0; ok && i < nfac; i++)
    *determ *= ev[i];

  Free_FL64MATRIX(mtrx);
  Free_FL64ARRAY(ev);

  return ok;
}


/* Translate a tri-diagonal matrix into ortogonal (eigen-vector) 
   representation
*/
BOOLE Math_TD2OD(FL64ARRAY  diag, 
                    FL64ARRAY  off, 
                    INTI  dim, 
                    FL64MATRIX  mtrx, 
                    INTI  maxit)
{
  INTI    k, i, cnt, j, n ;
  FL64    tmp, temp, ttemp, ttmp, x, y, z, xx, zz ;
  
  for (j = 1; j < dim; j++)
    off[j - 1] = off[j] ;

  off[dim - 1] = 0.0 ;
  
  for (k = 0; k < dim; k++)
  {
    cnt = 0 ;
    do
    {
      for (i = k; i < dim - 1; i++)
      {
        y = fabs(diag[i]) + fabs(diag[i+1]) ;
        if (fabs(off[i]) + y == y) 
          break ;
      }
      /* i == dim - 1  always !! */
      if (i != k)
      {
        if (cnt++ == maxit)
          return False ;
        ttmp = (diag[k + 1] - diag[k]) / (2.0 * off[k]) ;
        temp = sqrt((ttmp * ttmp) + 1.0) ; 
        zz = (ttmp < 0) ? -fabs(temp) : fabs(temp) ;
        ttmp = diag[i] - diag[k] + off[k] / (ttmp + zz) ;
        tmp = z = 1.0 ;
        ttemp = 0.0 ;
        for (j = i - 1; j >= k; j--)
        {
          x = tmp * off[j] ;
          xx = z * off[j] ;
          if (fabs(x) >= fabs(ttmp))
          {
            z = ttmp / x ;
            temp = sqrt((z * z) + 1.0) ;
            off[j + 1] = x * temp ;
            z *= (tmp = 1.0 / temp) ;
          }
          else
          {
            tmp = x / ttmp;
            temp = sqrt((tmp * tmp) + 1.0) ;
            off[j + 1] = ttmp * temp ;
            tmp *= (z = 1.0 / temp) ;
          }
          ttmp = diag[j + 1] - ttemp ;
          temp = (diag[j] - ttmp) * tmp + 2.0 * z * xx ;
          ttemp = tmp * temp ;
          diag[j + 1] = ttmp + ttemp ;
          ttmp = z * temp - xx ;
          /* ... */
          for (n = 0; n < dim; n++)
          {
           /* Attemp to avoid floating-point underflow:*/
            x = (-1e-50 < mtrx[n][j + 1] &&
                 mtrx[n][j + 1] < 1e-50 ? x = 0.0 : 
                 mtrx[n][j + 1]) ;
            mtrx[n][j + 1] = tmp * mtrx[n][j] + z * x ;
            mtrx[n][j] = z * mtrx[n][j] - tmp * x ;
          }
        }
        diag[k] = diag[k] - ttemp ;
        off[k] = ttmp ;
        off[i] = 0.0 ;
      }
    }    
    while (i != k) ;
  }
  return True ;
}
                                     
        
/* Reduces the symmetric matrix mtrx to tri-diagonal form using
   the Householder reduction method.
   On return mtrx holds the matrix effecting the transformation.
   diag holds the diagonal elements of the triangular matrix, and
   off holds the off-diagonal elements, with off[0]=0.0
*/
void Math_SYM2TD(FL64MATRIX  mtrx, 
                    INTI  dim, 
                    FL64ARRAY  diag, 
                    FL64ARRAY  off)
{
  INTI    n, m, i, j ;
  FL64    fac, ttemp, temp, ttmp, tmp ;
  
  for (j = dim - 1; j > 0; j--)
  {
    n = j - 1 ;
    temp = fac = 0.0 ;
    if (n > 0)
    {
      for (m = 0; m <= n; m++) 
        fac += fabs(mtrx[j][m]) ;
      if (fac == 0.0) 
        /* Skip transformation */
        off[j] = mtrx[j][n] ;
      else
      {
        for (m = 0; m <= n; m++)
        {
          mtrx[j][m] /= fac ; /* Use scaled elems for transformation*/
          temp += mtrx[j][m] * mtrx[j][m] ; /* form sigma in temp */
        }
        tmp = mtrx[j][n] ;
        ttmp = tmp > 0 ? -sqrt(temp) : sqrt(temp) ;
        off[j] = fac * ttmp ;
        temp -= tmp * ttmp ; /* Now temp is eq(11.2.4) of NR */
        mtrx[j][n] = tmp - ttmp ; /* Store "u" in i'th row of mtrx */
        tmp = 0.0 ;
        for (i = 0; i <= n; i++)
        {
          /* Next statement can be omitted if eigenvectors are not 
             wanted */
          mtrx[i][j] = mtrx[j][i] / temp ; 
                          /* Store "u"/temp in i'th col of mtrx */
          ttmp = 0.0 ; /* Form an element of mtrx*u in  ttmp */

          for (m = 0; m <= i; m++)
              ttmp += mtrx[i][m] * mtrx[j][m] ;
          for (m = i + 1; m <= n; m++)
              ttmp += mtrx[m][i] * mtrx[j][m] ;
          off[i] = ttmp / temp ; 
                      /* Form element of "p" in temporarily unused
                                          element of off */
          tmp += off[i] * mtrx[j][i] ; 
        }

        ttemp = tmp / (2.0 * temp) ; /* Form "K", eq(11.2.11) */
        for (i = 0; i <= n; i++)   
             /* Form "q" and store off overwriting "p" */
        {
          tmp = mtrx[j][i] ;     /* Note that off[n] = off[j-1] */
          off[i] = ttmp = off[i] - ttemp * tmp ;
          for (m = 0; m <= i; m++)  /* Reduce mtrx, eq(11.2.13) */
            mtrx[i][m] -= (tmp * off[m] + ttmp * mtrx[j][m]) ;
        }
      }
    }    
    else
        off[j] = mtrx[j][n] ;
    diag[j] = temp ;
  }

  /* Next statement can be omitted if eigenvectors are not wanted */
  diag[0] = 0.0 ;
  off[0] = 0.0 ;
  
  for (j = 0; j < dim; j++)
  {
    n = j - 1 ;
    if (diag[j])
    {
      for (i = 0; i <= n; i++)
      {
        ttmp = 0.0 ;
        for (m = 0; m <= n; m++)
          ttmp += mtrx[j][m] * mtrx[m][i] ;
        for (m = 0; m <= n; m++)
          mtrx[m][i] -= ttmp * mtrx[m][j] ;
      }
    }
    diag[j] = mtrx[j][j] ;
    mtrx[j][j] = 1.0 ;
    for (i = 0; i <= n; i++)
      mtrx[i][j] = mtrx[j][i] = 0.0 ;
  }
}                



/*    Routine for performing the Cholesky decomposition of a real, 
    symmetric and positive definite matrix. The algorithm proceeds 
    recursively and stops if it encounters an ill-defined operation
      (division by zero, square root of negative number). If an 
    ill-defined operation is encountered the function returns "False" 
    and writes (as an integer) the row number (counted with zero 
    off-set) at which failure was encountered in the address given 
    by '*fail'.
*/
    
BOOLE    Math_CholeskyDecomp(INTI  dim, /* dimension of matrices */
         FL64MATRIX  d,   /* input matrix */
         FL64MATRIX  a,   /* output matrix - must have been allocated */
         INTI*       fail)  /* row number at which failure ocurred */
{
  BOOLE    ok = True ;
  INTI    i, j, k ;

  for (i = *fail; i < dim && ok; i++)
    for (j = 0; j <= i && ok; j++)                                
    {
      for (k = 0, a[i][j] = d[i][j]; k < j; k++)
        a[i][j] -= a[i][k] * a[j][k] ;
      if (i == j)
      {                
        if (a[i][j] <= 0.0)
        {
          ok = False ;         
          *fail = i ;
        }
        else 
          a[i][j] = sqrt(a[i][j]) ;
      }
      else
        a[i][j] /= a[j][j] ;
    }

  return ok ;
}


/* invert symmetric (non-singular) matrix by first doing Cholesky 
   decomposition output 'out' must have been allocated with 'dim' 
   x 'dim' entries
*/
BOOLE   Math_InvertSmtrx(INTI  dim,
                      FL64MATRIX  in,
                      FL64MATRIX  out,
                      FL64*       determ)
{
  INTI        i, j, k, fail ;
  FL64        tmp ;
  FL64MATRIX  inv ;

  /* do Cholesky */
  fail = 0 ;
  if (!Math_CholeskyDecomp(dim, in, out, &fail)) 
    return False ;

  *determ = 1.0;

  /* invert 'out' */
  inv = Alloc_FL64MATRIX(dim, dim) ;
  for (i = 0; i < dim; i++)
  {
    inv[i][i] = 1.0 / out[i][i] ;
    for (j = 0; j < i; j++)
    {
      for (k = j, tmp = 0.0; k < i; k++)
        tmp += out[i][k] * inv[k][j] ;
      inv[i][j] = -tmp / out[i][i] ;
    }
    *determ *= out[i][i] * out[i][i];
  }

  /* compute inverse of 'in' */
  for (i = 0; i < dim; i++)
    for (j = 0; j < dim; j++)
    {
      out[i][j] = 0.0 ;
      for (k = GETMAX(i, j); k < dim; k++)
        out[i][j] += inv[k][i] * inv[k][j] ;
    }

  /* free */
  Free_FL64MATRIX(inv) ;

  /* return */
  return True ;
}

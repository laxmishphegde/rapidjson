/* SCID @(#)testmem.c	1.5 (SimCorp) 99/02/19 14:17:00 */

/***********************************************************************
*
*   project     SCecon
*
*   this program tests the routines in the yield module of SCecon.
*
***********************************************************************/


/*** includes *********************************************************/
#include <stdlib.h>
#include <scalloc.h>
#include <str2conv.h>
#include <ioconv.h>

INTI memtest(char* txa, FILE* in, FILE* out)
{
    INTI       diff, dif1, n1, n2, n3, i, j, k;
    FL64BOX    box;
    FL64MATRIX matrix;
    INTIBOX    ibox;
    INTIMATRIX imatrix;

    diff = -1;

    if (!strcmp(txa, "memtest:FL64BOX()"))
    {
      fprintf(out, "?; testing %s\n", txa);

      IOUtil_ParseLine(in, out);
      n1 = Read_INTI(in, out, "Size 1st dimension ");
      n2 = Read_INTI(in, out, "Size 2st dimension ");
      n3 = Read_INTI(in, out, "Size 3st dimension ");

      box = Alloc_FL64BOX(n1, n2, n3);
      for (i = 0; i < n1; i++)
        for (j = 0; j < n2; j++)
          for (k = 0; k < n3; k++)
            box[i][j][k] = 1.0e6 * (FL64) i 
                                      + 1.0e3 * (FL64) j + (FL64) k;

      diff = 0;
      for (i = 0; i < n1; i++)
        for (j = 0; j < n2; j++)
          for (k = 0; k < n3; k++)
          {
            dif1 = (box[i][j][k] != 1.0e6 * (FL64) i  
                                    + 1.0e3 * (FL64) j + (FL64) k);
            if (dif1)
              fprintf(out, "1; (%d, %d, %d)\n", i, j, k);
            diff = diff || dif1;
          }
      Free_FL64BOX(box);

      if (!diff)
        fprintf(out, "0; Memory was ok.\n");
      else 
        fprintf(out, "1; Memory was corrupted.\n");
    }

    else if (!strcmp(txa, "memtest:FL64MATRIX()"))
    {
      fprintf(out, "?; testing %s\n", txa);

      IOUtil_ParseLine(in, out);
      n1 = Read_INTI(in, out, "Size 1st dimension ");
      n2 = Read_INTI(in, out, "Size 2st dimension ");

      matrix = Alloc_FL64MATRIX(n1, n2);
      for (i = 0; i < n1; i++)
        for (j = 0; j < n2; j++)
          matrix[i][j] = 1.0e3 * (FL64) i + (FL64) j; 

      dif1 = diff = 0;
      for (i = 0; i < n1; i++)
        for (j = 0; j < n2; j++)
        {
          dif1 = (matrix[i][j] != 1.0e3 * (FL64) i + (FL64) j);
          if (dif1)
            fprintf(out, "1; (%d, %d)\n", i, j);
          diff = diff || dif1;
        }
      Free_FL64MATRIX(matrix);

      if (!diff)
        fprintf(out, "0; Memory was ok.\n");
      else 
        fprintf(out, "1; Memory was corrupted.\n");
    }

    else if (!strcmp(txa, "memtest:INTIBOX()"))
    {
      fprintf(out, "?; testing %s\n", txa);

      IOUtil_ParseLine(in, out);
      n1 = Read_INTI(in, out, "Size 1st dimension ");
      n2 = Read_INTI(in, out, "Size 2st dimension ");
      n3 = Read_INTI(in, out, "Size 3st dimension ");

      ibox = Alloc_INTIBOX(n1, n2, n3);
      for (i = 0; i < n1; i++)
        for (j = 0; j < n2; j++)
          for (k = 0; k < n3; k++)
            ibox[i][j][k] = 1000000 *  i + 1000 * j + k;

      diff = 0;
      for (i = 0; i < n1; i++)
        for (j = 0; j < n2; j++)
          for (k = 0; k < n3; k++)
          {
            dif1 = (ibox[i][j][k] != 1000000 *  i + 1000 * j + k);
            if (dif1)
              fprintf(out, "1; (%d, %d, %d)\n", i, j, k);
            diff = diff || dif1;
          }
      Free_INTIBOX(ibox);

      if (!diff)
        fprintf(out, "0; Memory was ok.\n");
      else 
        fprintf(out, "1; Memory was corrupted.\n");
    }

    else if (!strcmp(txa, "memtest:INTIMATRIX()"))
    {
      fprintf(out, "?; testing %s\n", txa);

      IOUtil_ParseLine(in, out);
      n1 = Read_INTI(in, out, "Size 1st dimension ");
      n2 = Read_INTI(in, out, "Size 2st dimension ");

      imatrix = Alloc_INTIMATRIX(n1, n2);
      for (i = 0; i < n1; i++)
        for (j = 0; j < n2; j++)
          imatrix[i][j] = 1000 * i + j; 

      dif1 = diff = 0;
      for (i = 0; i < n1; i++)
        for (j = 0; j < n2; j++)
        {
          dif1 = (imatrix[i][j] != 1000 * i + j);
          if (dif1)
            fprintf(out, "1; (%d, %d)\n", i, j);
          diff = diff || dif1;
        }
      Free_INTIMATRIX(imatrix);

      if (!diff)
        fprintf(out, "0; Memory was ok.\n");
      else 
        fprintf(out, "1; Memory was corrupted.\n");
    }

    return diff ;
}

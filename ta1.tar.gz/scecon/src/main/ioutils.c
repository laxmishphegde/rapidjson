/* SCID @(#)ioutils.c	1.146 (SimCorp) 99/10/26 09:11:33 */

/************************************************************************
*
*   Project     SCecon
*
*   file name   ioutils.c
*
*   general     This file contains file io functions
*
************************************************************************/

/* includes    *********************************************************/
#include <str2conv.h>
#include <ioconv.h>


/*
  This function creates a new filename by replacing an
  extension '.in' by extension '.out'.
*/

void Filename_In2Out(char* inname, char* outname)
{
    int i;
    size_t len = strlen(inname) ;

    strcpy(outname, inname) ;
    for (i = (int)(len - 1); i >= 0 && inname[i] != '\\' && inname[i] != '.'; i--)
        ;

    if (inname[i] != '\\')
        outname[i] = '\0' ;

    strcat(outname, ".out") ;
}

/*
..
*/

/*
  Documentation of comment handling
  ---------------------------------

  Comments start with an asterisk '*' and end at the first newline.
  If a comment is wrapped over more lines, each line must start with
  an asterisk.
  Comments are parsed to the output file (without the asterisk).
  To parse comments use the function IOUtil_ReadComment().

  All Read functions reading a format id implicitly supports
  comments through the function Read_FormatId(), eg.
  Read_DISCFAC - see '* DF' in the example below.

  The Read functions for the following types:
  - basic types, eg. FL64 and INTI
  - DATESTR
  - enums, eg. EOMCONV
  support comments before the actual value. The comment 
  '* Rate shocking convention' in the example below
  is an example of this.

  An example of a test case in an input file:
>>
  RepoCflw_DF2ScenBPV()
  19910101
  1.0
  * DF
  1 EU30E360 LINEAR_EXTRAPOL DI_SPOT COMPOUND ANNUALLY
  3
  19910101 1.0
  19920101 0.9090909
  19930101 0.8264463
  * Cflw
  1
  3
  19910101 0.0 10.0
  19920101 0.0 10.0
  19930101 100.0 10.0
  19930101
  * PP
  2
  0 NO_BUSADJUST
  * Spread
  2 0.0 
  * Curve scenario - FX scenario
  1 1
  1 1
  12 MONTHS 0.0
  1
  0.0 
   * Rate shocking convention
   * Note that the asterisk must be the first non-space char
   * on the line.
  COMPOUND ANNUALLY False
  True 1 0.0
  0.00001
  1.MBP.9610.no.shock
<<
This will give the following output:
>>
     Testing RepoCflw_DF2ScenBPV()
     analys:    19910101
  Fx Spot:   1.000000
     DISCFAC:
     DFPARMS:
  DF
   * Using format #1
     calendar    EU30E360
     iconv       LINEAR_EXTRAPOL
     discipol    DI_SPOT
     irr         COMPOUND
     qbas        ANNUALLY
     Disc.Fac's are:
     19910101 1.000000
     19920101 0.909091
     19930101 0.826446
  Cflw
   * Using format #1
     CFLW is...
     Date       Repay    Coupon
     19910101    0.00000   10.00000
     19920101    0.00000   10.00000
     19930101  100.00000   10.00000
     Maturity:  19930101
     PP_STR
  PP
   * Using format #2
     BusConv NO_BUSADJUST
     holidays...
     DFSPREAD:
  Spread
   * Using format #2
     Spread      0.000000
  Curve scenario - FX scenario
   * Using format #1
     # of Scenarios 1
   * Using format #1
     Bucket Array is...
     Duration  Unit    Shock
     12 MONTHS 0.000000
     0.000000
  Rate shocking convention
  Note that the asterisk must be the first non-space char
  on the line.
    Shock IRR   :COMPOUND
    Shock Freq  :ANNUALLY
     Domestic  FALSE
    Exp status: TRUE
  Tolerance: 0.000010
  0; Result status: 1
  0; 0 exp  0.0000000 res  0.0000000
  1.MBP.9610.no.shock
<<

*/


/* 
   This function spools over space as defined
   by the function 'isspace' until a non-space 
   character is reached.
*/

int IOUtil_SkipSpace(FILE* in)
{   
  int ch;

  ch = fgetc(in);
  while (isspace(ch) && !feof(in) && !ferror(in))
    ch = fgetc(in);

  ungetc(ch, in);

  return ch;
}


/*
   This function skips intial spacing using
   IOUtil_SkipSpace() and copies the text between
   the initial space and the first newline to
   the output file.
*/

void IOUtil_SkipLine(FILE* in)
{
  int ch;

  ch = fgetc(in);
  while (ch != '\n' && !ferror(in) && !feof(in))
  {
    ch = fgetc(in);
  }
}


void IOUtil_ParseLine(FILE* in, FILE* out)
{
  int ch;

  IOUtil_SkipSpace(in);

  ch = fgetc(in);
  while (ch != '\n' && !ferror(in) && !feof(in))
  {
    fputc(ch, out);
    ch = fgetc(in);
  }

  fputc(ch, out);
}


void IOUtil_ParseComment(FILE* in, FILE* out)
{
  int ch;

  IOUtil_SkipSpace(in);

  ch = fgetc(in);
  while (ch != '\n' && ch != ':' && !ferror(in) && !feof(in))
  {
    fputc(ch, out);
    ch = fgetc(in);
  }

  fputc(ch, out);
}


/*
   This function skips intial spacing using
   IOUtil_SkipSpace() and copies subsequent 
   comments between to the output file.
   Comment markers are identified by the function
   IOUtil_IsComment(). Comment markers are copied
   to the output file. Successive comments
   are supported.
*/

BOOLE IOUtil_ReadComment(FILE* in, FILE* out)
{ 
  BOOLE found = False ;
  BOOLE first = True ;
  int ch ;

  /* spool over space:*/
  ch = IOUtil_SkipSpace(in) ;

  /* ch isn't extracted from the file, so do it:*/
  ch = fgetc(in);

  /* Read through one or more comment lines:*/
  while (IOUtil_IsComment(ch) && !feof(in) && !ferror(in))
  {
    found = True;

    if (!first)
      fputc('\n', out) ;

    fputc(ch, out) ;
    fputc(' ', out) ;
    IOUtil_ParseComment(in, out) ;

      /* Skip space on the next line: */
    IOUtil_SkipSpace(in) ;

    ch = fgetc(in) ;
    first = False ;
  }

  ungetc(ch, in) ;

  return found ;
}


/*
   This function identifies a comment marker
   as a '*'.
*/

BOOLE IOUtil_IsComment(int ch)
{
  if (ch == '*')
    return True;
  else
    return False;
}




COUNT Read_FormatId(FILE* in, FILE* out)
/* Only use unsigned format IDs !! */
{
    unsigned int id;

      /* Comments, if any: */
    if (!IOUtil_ReadComment(in, out))
        fprintf(out, "* Using format no:");
      
    fscanf(in, "%u", &id);
    fprintf(out, " %u\n", id);

    return id;
}



INTI Compare_Single(FILE*  in, FILE*  out, BOOLE  okres, 
                       FL64  res, FL64  acc)
{
    CH txa[50], txb[50], txc[50], txdummy[50] ;
    BOOLE oka, okb ;
    FL64 fla, flb ;
    INTI diff1, diff2 ;

    IOUtil_ReadComment(in, out) ;

    Read_TEXT(in, 50, txdummy) ;
    Read_TEXT(in, 50, txa) ;
    Read_TEXT(in, 50, txb) ;

    oka = Str2BOOLE(txa) ;
    okb = Str2BOOLE(txb) ;

    BOOLE2Str(okres, txc) ;

    diff1 = (oka != okres);
    fprintf(out, "%d; %s %s\n", diff1, txa, txc) ;

    fscanf(in, "%s %lf %lf", txdummy, &fla, &flb) ;

    diff2 = SCecon_fabs(fla - res) > acc;
    fprintf(out, "%d; %lf %lf\n", diff2, fla, res);

    return diff1 || diff2 ;
}


INTI Compare_Risk(FILE*  in, FILE*  out, BOOLE  okres, FL64  res, 
                   FL64  res1, FL64  res2, FL64  acc)
{
    CH txa[50], txb[50], txc[50], txdummy[50] ;
    BOOLE oka, okb ;
    FL64 fla, flb ;
    INTI diff1, diff2, diff3, diff0 ;

    IOUtil_ReadComment(in, out) ;

    Read_TEXT(in, 50, txdummy) ;
    Read_TEXT(in, 50, txa) ;
    Read_TEXT(in, 50, txb) ;

    oka = Str2BOOLE(txa) ;
    okb = Str2BOOLE(txb) ;

    BOOLE2Str(okres, txc) ;

    diff0 = (oka != okres);
    fprintf(out, "%d; %s %s\n", diff0, txa, txc) ;

    fscanf(in, "%s %lf %lf", txdummy, &fla, &flb) ;
    diff1 = SCecon_fabs(fla - res) > acc;
    fprintf(out, "%d; %lf %lf\n", diff1, fla, res);

    fscanf(in, "%s %lf %lf", txdummy, &fla, &flb) ;
    diff2 = SCecon_fabs(fla - res1) > acc;
    fprintf(out, "%d; %lf %lf\n", diff2, fla, res1);

    fscanf(in, "%s %lf %lf", txdummy, &fla, &flb) ;
    diff3 = SCecon_fabs(fla - res2) > acc;
    fprintf(out, "%d; %lf %lf\n", diff3, fla, res2);

    return diff1 || diff2 || diff3 || diff0 ;
}



/*
..
*/


PLANARRAY Read_PLANARRAY(FILE* in)
{
    PLANARRAY plan ;
    YYYYMMDD  ymd ;
    INTI      n, i ;
    int       i1 ;

    fscanf(in, "%d", &i1) ;
    n = (INTI) i1 ;

    if (n < 1)
        return NULL ;

    /* Allocate */
    plan = Alloc_PLANARRAY(1, n) ;
    plan->filled = n ;

    /* Read date, f64 */
    for (i = 0; i < n; i++)
    {
        fscanf(in, "%ld %lf", &ymd, &plan->f64[i]) ;
        plan->day[i] = Cldr_YMD2Datestr(ymd) ;
    }

    return plan ;
}

/*
..
*/


void Write_PLANARRAY(FILE* out, PLANARRAY plan)
{
    YYYYMMDD  ymd ;
    INTI      i ;

    /* Write */
    fprintf(out, " %d\n", GetPlanFill(plan));

    for (i = 0; i < GetPlanFill(plan); i++)
    {
        ymd = Cldr_Datestr2YMD(&plan->day[i]) ;
        fprintf(out, "   %ld %lf\n", ymd, plan->f64[i]) ;
    }
}

/*
..
*/


FL64ARRAY Read_FL64ARRAY(FILE* in, INTI* n)
{
    FL64ARRAY f64 ;
    INTI      i ;
    int       i1 ;

    fscanf(in, "%d", &i1) ;
    *n = (INTI) i1 ;

    /* Allocate */
    f64 = Alloc_FL64ARRAY(*n) ;

    /* Read */
    for (i = 0; i < *n; i++)
        fscanf(in, "%lf", &f64[i]) ;

    return f64 ;
}

/*
..
*/

void Write_FL64ARRAY(FILE* out, FL64ARRAY f64, INTI n)
{
    INTI i ;

    /* Write */
    for (i = 0; i < n; i++)
        fprintf(out, "   %lf\n", f64[i]) ;
}


/*
..
*/

INTIARRAY Read_INTIARRAY(FILE* in, INTI* n)
{
    INTIARRAY inti ;
    INTI      i ;
    int       i1 ;

    fscanf(in, "%d", &i1) ;
    *n = (INTI) i1 ;

    /* Allocate */
    inti = Alloc_INTIARRAY(*n) ;

    /* Read */
    for (i = 0; i < *n; i++)
        fscanf(in, "%d", &inti[i]) ;

    return inti ;
}

/*
..
*/

void Write_INTIARRAY(FILE* out, INTIARRAY inti, INTI n)
{
    INTI i ;

    /* Write */
    for (i = 0; i < n; i++)
        fprintf(out, "   %d\n", inti[i]) ;
}


/*
..
*/

HOLI_STR Read_HOLI_STR(FILE* in, FILE* out)
{

    HOLI_STR  holi ;
    INTI      i ;

    holi.nholi = Read_INTI(in, out, "No. of holidays");
    holi.bus = Read_BUSCONV(in, out, "Business Day Method");

    /* Allocate */
    holi.holidays = Alloc_DATEARRAY(holi.nholi) ;
    holi.busi_const_fact = (BUSCONSTFACTOR)ScaleFctRequired; /*PMSTA-40263-ARUN-29102020*/

    /* Read / Write */
    for (i = 0; i < holi.nholi; i++)
        holi.holidays[i] = Read_DATESTR(in, out, "") ;

    Write_VALIDATEError(out, Validate_HOLI_STR(&holi));

    return holi ;
}

/*
..
*/


STEPARRAY Read_STEPARRAY(FILE* in, FILE* out, INTI* nstep)
{
    STEPARRAY step ;
    INTI      i ;
    int       i1, i2 ;
    char      txb[50] ;

    fscanf(in, "%d", &i1) ;
    *nstep = (INTI) i1 ;

    /* Allocate */
    step = Alloc_STEPARRAY(*nstep) ;

    /* Read data */
    fprintf(out,"   Step array is...\n") ;
    fprintf(out,"   Duration  Unit    #Steps\n") ;
    for (i = 0 ; i < *nstep ; i++)
    {
        fscanf(in,"%d %s %d", &i1, txb, &i2) ;
        step[i].dur   = (INTI) i1 ;
        step[i].unit  = Str2TERMUNIT(txb) ;
        step[i].nstep = (INTI) i2 ;

        fprintf(out,"    %d %10s         %d\n", i1, txb, i2) ;
    }

    Write_VALIDATEError(out, Validate_STEPARRAY(step, *nstep));

    return step ;
}

/*
..
*/


BUCKETARRAY Read_BUCKETARRAY(FILE* in, FILE* out, INTI* nb)
{
    BUCKETARRAY bucket ;
    INTI        i ;
    int         i1 ;
    char        txb[15] ;
    COUNT       type ;

    type = Read_FormatId(in, out) ;

    fscanf(in, "%d", &i1) ;
    *nb = (INTI) i1 ;

    /* Allocate */
    bucket = Alloc_BUCKETARRAY(*nb) ;

    /* Read data */
    fprintf(out,"   Bucket Array is...\n") ;

    switch (type)
    {
        case 1:

            fprintf(out,"   Duration  Unit    Shock\n") ;
            for (i = 0 ; i < *nb ; i++)
            {
                fscanf(in, "%d %s %lf", &i1, txb, &bucket[i].shock) ;
                bucket[i].term = (INTI) i1 ;
                bucket[i].unit = Str2TERMUNIT(txb) ;
                fprintf(out, "   %d %s %lf\n", i1, txb, bucket[i].shock) ;
            }

            break ;

        case 2:

            fprintf(out,"   CCY  Class Duration  Unit    Shock\n") ;
            for (i = 0 ; i < *nb ; i++)
            {
                fscanf(in, "%s", bucket[i].token.ccy) ;
                fprintf(out,"    %s ", bucket[i].token.ccy) ;

                fscanf(in, "%s", bucket[i].token.rclass) ;
                fprintf(out,"%s ", bucket[i].token.rclass) ;

                fscanf(in, "%d %s %lf", &i1, txb, &bucket[i].shock) ;
                bucket[i].term = (INTI) i1 ;
                bucket[i].unit = Str2TERMUNIT(txb) ;
                fprintf(out, "%d %s %lf\n", i1, txb, bucket[i].shock) ;
            }

            break ;
    }

    Write_VALIDATEError(out, Validate_BUCKETARRAY(bucket, *nb));

    return bucket ;
}


/*
..
*/




DATEARRAY Read_DATEARRAY(FILE* in, FILE* out, INTI* n)
{
    DATEARRAY day ;
    YYYYMMDD  ymd ;
    INTI      i ;
    int       i1 ;

    fscanf(in, "%d", &i1) ;
    *n = (INTI) i1 ;

    /* Allocate */
    day = Alloc_DATEARRAY(*n) ;

    /* Read */
    for (i = 0; i < *n; i++)
    {
        fscanf(in, "%ld", &ymd) ;
        day[i] = Cldr_YMD2Datestr((YYYYMMDD) ymd) ;
        fprintf(out, "    %ld\n", ymd) ;
    }

    return day ;
}


/*
..
*/
void Write_FL64MATRIX(FL64MATRIX m, 
                      INTI       n1, 
                      INTI       n2, 
                      INTI       decimal_places,
                      FILE*      out)
{
  INTI i, j;

  fprintf(out, "Matrix is %d x %d.\n", n1, n2);
  for (i = 0; i < n1; i++)
  {
    for (j = 0; j < n2; j++)
      fprintf(out, "%*.*lf  ", decimal_places + 2, decimal_places, m[i][j]);
    fprintf(out, "\n");
  }
}




/*
..
*/


INTI Write_FL64MATRIXdiff(FILE*  in, FILE*  out, BOOLE  ok, 
        FL64MATRIX  act, INTI  actrows, INTI  actcols, 
        BOOLE  okexp, FL64  tol)
{
    FL64MATRIX exp;
    INTI expcols, exprows, diff, i, j;

    exp = Read_FL64MATRIX(in, out, &exprows, &expcols);

    if (ok == False)
    {
        if (ok == okexp)
            diff = 0;
        else
            diff = 1 ;
        fprintf(out,"%d; Cannot find matrix\n", diff) ;
    }
    else if (okexp != ok)
    {
        fprintf(out,"1;   Unexpected success\n") ;
        diff = 1 ;
    }
    else if (expcols != actcols)
    {
        fprintf(out,"   Exp # cols %d, found %d\n", expcols, 
          actcols) ;
        diff = 1 ;
        fprintf(out,"   Matrix found:\n") ;
        for (i = 0; i < actrows ; i++)
        {
            for (j = 0; j < actcols; j++)
                fprintf(out, " %lf", act[i][j]) ;
            fprintf(out, "\n") ;
        }
    }

    else
    {
        diff = 0 ;

        fprintf(out,"   Matrix found:\n") ;
        for (i = 0; i < actrows ; i++)
        {
            for (j = 0; j < actcols; j++)
            {
                fprintf(out, " %lf", act[i][j]) ;
                if (fabs(act[i][j] - exp[i][j]) > tol)
                {
                    fprintf(out, "%s", "*") ;
                    diff = 1 ;
                }
            }
            fprintf(out, "\n") ;
        }
    }
    fprintf(out,"%d;\n", diff) ;

    Free_FL64MATRIX(exp);

    return diff;
}

INTI Write_FL64ARRAYdiff(FILE*  in, FILE*  out, BOOLE  ok, 
        FL64ARRAY  act, INTI  actrows,  
        BOOLE  okexp, FL64  tol)
{
    FL64ARRAY exp;
    INTI  exprows, diff, i ;

    exp = Read_FL64ARRAY(in, &exprows);

    fprintf(out,"   Array expected:\n") ;
      for (i = 0; i < exprows ; i++)
        fprintf(out, " %lf\n", exp[i]) ;

    if (ok == False)
    {
        if (ok == okexp)
            diff = 0;
        else
            diff = 1 ;
        fprintf(out,"%d; Cannot find array\n", diff) ;
    }
    else if (okexp != ok)
    {
        fprintf(out,"1;   Unexpected success\n") ;
        diff = 1 ;
    }
    else if (exprows != actrows)
    {
        fprintf(out,"   Exp # rows %d, found %d\n", exprows, 
          actrows) ;
        diff = 1 ;
        fprintf(out,"   Array found:\n") ;
        for (i = 0; i < actrows ; i++)
            fprintf(out, " %lf\n", act[i]) ;
    }

    else
    {
        diff = 0 ;

        fprintf(out,"   Array found:\n") ;
        for (i = 0; i < actrows ; i++)
        {
            
          fprintf(out, " %lf", act[i]) ;
          if (fabs(act[i] - exp[i]) > tol)
          {
            fprintf(out, "%s", "*") ;
            diff = 1 ;
          }
          fprintf(out, "\n") ;
        }
    }
    fprintf(out,"%d;\n", diff) ;

    Free_FL64ARRAY(exp);

    return diff;
}


void Write_VALIDATEError(FILE*  out, VALIDATE  val)
{
    CH txb[100];

    if (val != Valid_data)  
    {
        VALIDATE2Str(val, txb);
        strcat(txb, "\0");
        Write_ValidateStatus(val);
        fprintf(out, "*2; Validating - %s \n", txb);
    }
}

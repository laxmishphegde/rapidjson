/* SCID @(#)tvmprice.c	1.25 (SimCorp) 99/02/19 14:17:25 */

/************************************************************************
*
*   project     SCecon
*
*   filename    tvmprice.c
*
*   contains    routines in the SCecon Library Time Value of Money
*               module to calculate price as a function of yield
*
************************************************************************/

/*** defines  **********************************************************/
#define DAY_TOL    (FL64) 0.001
#define RATE_TOL   (FL64) 0.00001
#define TERM_TOL   (FL64) 0.0001
#define SHOCK_SIZE (FL64) 0.01

/*** includes **********************************************************/
#include <tvm.h>
#include <aaatelemetry.h>

#ifdef AIX
#include <math.h>
#else
#include <cmath>
#endif

/*,,SOH,,
*************************************************************************
*
*               TVM_NPVBondtype()
*
*    interface  #include <tvm.h>
*               FL64 TVM_NPVBondtype(FL64     pmt,
*                                     FL64     ytm,
*                                     FL64     term,
*                                     BONDTYPE type,
*                                     RISKCONV risk,
*                                     FL64     *dp,
*                                     FL64     *ddp) ;
*
*    general    TVM_NPVBondtype() calculates the present value and
*               risk ratios of a standard bond.
*
*               Notice that the risk ratios are calculated by shocking
*               the periodic yields, can be subsequently tranlated to
*               annualized ratios with TVM_Risk_Per2Ann().
*
*    input      FL64      pmt   Periodical coupon from the bond
*                               in percent.
*
*               FL64      ytm   Periodically compounded yield to
*                               maturity of the bond in percent.
*
*               FL64      term  Maturity as fractions of the period
*                               between payments.
*
*               BONDTYPE  type  The type of the bond. Choose one of
*
*                                         BULLET
*                                         ANNUITY
*                                         SERIAL
*
*               RISKCONV  risk  The risk specification.
*
*    output     FL64      *dp   The dollar duration.
*
*               FL64      *ddp  The dollar convexity.
*
*    returns    the present value of a unit bond as FL64.
*
*    diagnostics
*
*    see also   TVM_Risk_Per2Ann()
*               TVM_Yield2Price()
*
*************************************************************************
,,EOH,,*/


FL64    TVM_NPVBondtype(FL64 pmt,
                         FL64    ytm,
                         FL64    term,
                         BONDTYPE type,
                         RISKCONV risk,
                         FL64*    dp,
                         FL64*    ddp)
{
    FL64    dytm, pv, plo, phi, dum, ann ;

    /* warning avoidance */
    pv = 0.0 ;

    *dp = *ddp = 0.0 ;

    if (type == SERIAL)
        pv = TVM_NPV_Serial(pmt, ytm, term) ;
    else if (type == BULLET)
        pv = TVM_NPV_Bullet(pmt, ytm, term) ;
    else if (type == ANNUITY)
    {
        ann = Cflw_Annuity(pmt, (INTI ) (TERM_TOL + term), False) ;
        pv  = TVM_NPV_Annuity(ann, ytm, term) ;
    }

    /* Do risk */
    if (risk != ZERO_ORDER)
    {
        dytm = SHOCK_SIZE ;
        plo = TVM_NPVBondtype(pmt, ytm - dytm, term, type,
                               ZERO_ORDER, &dum, &dum) ;
        phi = TVM_NPVBondtype(pmt, ytm + dytm, term, type,
                               ZERO_ORDER, &dum, &dum) ;
        *dp = - (plo - phi) / (2.0 * dytm);
        if (risk == SECOND_ORDER)
            *ddp = (phi + plo - 2.0 * pv) / SQR(dytm) ;
    }

    return pv ;
}


/*,,SOH,,
*************************************************************************
*
*               TVM_Risk_Per2Ann()
*
*    interface  #include <tvm.h>
*               FL64 TVM_Risk_Per2Ann(FL64     rp,
*                                     FL64     dp,
*                                     FL64     ddp,
*                                     FL64     qb,
*                                     RISKCONV risk) ;
*
*    general    This function transforms a periodically calculated
*               risk ratio to an 'annualized' risk ratio.
*
*               To be called after TVM_NPVBondtype().
*
*    input      FL64      rp    The periodical yield in percent.
*
*               FL64      dp    The periodical first order risk ratio.
*
*               FL64      ddp   The periodical second order risk ratio.
*
*               FL64      qb    The number of periods per annuum. Must
*                               be a positive number.
*
*               RISKCONV  risk  The risk specification. Choose one of
*
*                                        FIRST_ORDER
*                                        SECOND_ORDER
*
*    output
*
*    returns    annualized dollar duration if risk is specified as
*               FIRST_ORDER, or the annualized dollar convexity if
*               risk is specified as SECOND_ORDER.
*
*    diagnostics
*
*    see also   TVM_NPVBondtype()
*
*************************************************************************
,,EOH,,*/

FL64 TVM_Risk_Per2Ann(FL64 rp,
                         FL64    dp,
                         FL64    ddp,
                         FL64    qb,
                         RISKCONV risk)
{
    FL64    ddpa ;

    if (risk == FIRST_ORDER)
        return dp/(qb*(1.0 + 0.01*rp)) ;

    ddpa  = ddp ;
    ddpa += 0.01*dp*(qb - 1.0)/(1.0 + 0.01*rp) ;
    ddpa /= qb*qb*pow(1 + 0.01*rp, 2.0*qb - 2.0) ;

    return ddpa ;
}


/************************************************************************
*
*               TVM_NPV_Annuity()
*
*    interface  #include <tvm.h>
*
*               FL64    TVM_NPV_Annuity(FL64    ann, FL64    pr,
*                                       FL64    t);
*
*    general    TVM_NPV_Annuity() calculates the present value
*               of a straight  annuity loan using a closed form formula
*
*    input      FL64      ann   Periodical payment from the annuity
*                               bond per initial 100 outstanding.
*               FL64      pr    Periodically compounded yield to
*                               maturity of the bond in percent.
*               FL64      t     Term to maturity of the bond
*                               in fractions of payment periods.
*
*    output
*
*    returns    The present value of a unit bond as FL64
*
*    diagnostics
*
*    see also   TVM_NPV_Bullet()
*
************************************************************************/

FL64 TVM_NPV_Annuity(FL64 annuity,
                        FL64    prate,
                        FL64    term)
{
    FL64    f, pv, ytm ;
    BOOLE   payd ;

    ytm  = prate / 100.0 ;
    f    = floor(term) ;
    payd = (SCecon_fabs(term - f) >= DAY_TOL ? False : True) ;

    /* Find the present value */
    if (SCecon_fabs(ytm) > RATE_TOL)
        pv = annuity * (1.0 - pow(1.0 + ytm, -f)) / ytm ;
    else
        pv = annuity * f ;

    /* Correct for the first coming coupon and discount till today
       - if not a payday */
    if (payd == False)
    {
        pv += annuity ;
        pv *= tvmunit_compound(prate, term - f, 1) ;
    }

    return pv;
}


/************************************************************************
*
*               TVM_NPV_Bullet()
*
*    interface  #include <tvm.h>
*
*               FL64    TVM_NPV_Bullet(FL64    c, FL64    pr,
*                                      FL64    t);
*
*    general    TVM_NPV_Bullet() calculates the present value
*               of a straight bullet loan based on a closed formula.
*
*    input      FL64      c     Periodical payment from the bullet
*                               loan per initial 100 outstanding.
*               FL64      pr    Periodically compounded yield to
*                               maturity of the bond in percent.
*               FL64      t     Term to maturity of the bond as
*                               fraction of payment period length.
*
*    output
*
*    returns    The present value of a unit bond as FL64
*
*    diagnostics
*
*    see also   TVM_NPV_Annuity()
*
************************************************************************/

FL64 TVM_NPV_Bullet(FL64 coupon,
                       FL64 prate,
                       FL64 term)
{
    FL64  f, pv;
    BOOLE payd ;

    f    = floor(term) ;
    payd = (SCecon_fabs(term - f) >= DAY_TOL ? False : True) ;

    /* Find the present value on the next payday - as the sum of the coupon
       annuity and the zerocoupon payment from the amortization */
    pv   = TVM_NPV_Annuity(coupon, prate, f);
    pv  += 100.0 * tvmunit_compound(prate, f, 1);

    /* Correct for the first coming coupon and discount till today
       - if not a payday */
    if (payd == False)
    {
        pv += coupon;
        pv *= tvmunit_compound(prate, term - f, 1);
    }

    return pv ;
}


/************************************************************************
*
*               TVM_NPV_Serial()
*
*    interface  #include <tvm.h>
*
*               FL64    TVM_NPV_Serial(FL64    c, FL64    pr,
*                                      FL64    t);
*
*    general    TVM_NPV_Serial() calculates the present value
*               of a straight serial loan using a closed formula
*
*    input      FL64      c     Periodical coupon from the
*                               serial loan per initial 100 outstanding.*
*               FL64      pr    Periodically compounded yield to
*                               maturity of the bond in percent.
*               FL64      t     Term to maturity of the bond as
*                               fraction of payment period length.
*
*    output
*
*    returns    The present value of a unit bond as FL64
*
*    diagnostics
*
*    see also   TVM_NPV_Annuity()
*
************************************************************************/


FL64 TVM_NPV_Serial(FL64 coupon,
                       FL64    prate,
                       FL64    term)
{
    FL64    n, f, pv, tmp, ytm ;
    BOOLE   payd ;

    /* payd tells whether we are on a payday */
    f    = floor(term) ;
    payd = (SCecon_fabs(term - f) > DAY_TOL ? False : True) ;

    /* n is number of outstanding payments */
    n   = (payd == False ? f + 1.0 : f) ;
    ytm = prate / 100.0 ;

    /* Find the present value on the next payday */
    if (SCecon_fabs(ytm) > RATE_TOL)
    {
        tmp = pow(1.0 + ytm, n - 1.0) ;
        pv  = (100.0/n + coupon)*(1.0 + (1.0 - 1.0/tmp)/ytm) ;
        pv -= coupon/n*((tmp*(1.0 + ytm) - 1.0 - n*ytm)/(ytm*ytm*tmp)) ;
    }
    else
        pv  = 100.0 + coupon*(n + 1.0)/2.0 ;

    /* Discount till today */

    if (payd == False)
        pv *= tvmunit_compound(prate, term - f, 1);
    else
        pv *= tvmunit_compound(prate, 1.0, 1);

    return pv ;
}


/*,,SOH,,
*************************************************************************
*
*               TVM_Yield2Price()
*
*    interface  #include <tvm.h>
*               FL64 TVM_Yield2Price(FL64      ytm,
*                                    RISKCONV  risk,
*                                    INTI      basis,
*                                    FL64      debt,
*                                    IRRCONV   irr,
*                                    FL64ARRAY rerates,
*                                    PMT_STR   *paym,
*                                    FL64      *dp,
*                                    FL64      *ddp) ;
*
*    general    TVM_Yield2Price() calculates dirty price, dollar
*               duration and dollar convexity as function of yield
*               to maturity for the payment stream in paym using the
*               required interest rate convention.
*
*    input      FL64      ytm       Annual yield to maturity of the
*                                   bond in percent.
*
*               RISKCONV  risk      Switch for risk calculation.
*
*               INTI      basis     Quoting basis of the yield. Only
*                                   used if irr is COMPOUND, MOOSMULLER,
*                                   COMPOUNDSIMPLE or COMPOUNDSIMPLE_ODD.
*
*               FL64      debt      Outstanding debt per initial 100.
*
*               IRRCONV   irr       The interest rate convention.
*
*               FL64ARRAY rerates   Array of reinvestment rates in
*                                   percent.
*                                   Must be allocated with as many
*                                   entries as paym->count
*                                   The rates corresponds to the terms
*                                   in paym.
*                                   Only needed if irr is MAIR,
*                                   otherwise just give an empty array.
*
*               PMT_STR  *paym      Structure of payments from the bond
*                                   The terms part of paym contains the
*                                   terms for the payments in fractions
*                                   of years.
*                                   The payments should not include any
*                                   accrued interest at the valuation
*                                   day.
*
*    output     FL64      *dp       Dollar duration of the bond.
*                                   Computed if risk is FIRST_ORDER or
*                                   SECOND_ORDER.
*
*               FL64      *ddp      Dollar convexity of the bond.
*                                   Computed if risk is SECOND_ORDER.
*
*    returns    The dirty price of the cashflow.
*
*    diagnostics
*
*    see also   TVM_Price2Yield()
*               TVM_Zero2Price()
*
*************************************************************************
,,EOH,,*/

FL64    TVM_Yield2Price(FL64   ytm,
                        RISKCONV  risk,
                        INTI      basis,
                        FL64      debt,
                        IRRCONV   irr,
                        FL64ARRAY rerates,
                        PMT_STR*    paym,
                        FL64*      dp,
                        FL64*      ddp)
{
    FL64 matur, price ;

    /* warning avoidance */
    price = 0.0 ;

    switch (irr)
    {
        case COMPOUND:
            price = TVM_Compound2Price(ytm, dp, ddp, risk, basis, debt,
                                       paym) ;
            break ;

        case US_TREASURY:
            price = TVM_USTreasury2Price(ytm, dp, ddp, risk, basis, debt,
                                         paym) ;
            break ;

        case COMPOUNDSIMPLE:
            price = TVM_CompoundSimple2Price(ytm, dp, ddp, risk,
                                             basis, debt, paym) ;
            break ;

        case COMPOUNDSIMPLE_ODD:
            price = TVM_CompoundSimpleOdd2Price(ytm, dp, ddp, risk,
                                             basis, debt, paym) ;
            break ;

        case CONTINUOUS:
            price = TVM_Continuous2Price(ytm, dp, ddp, risk, debt, paym) ;
            break ;

        case SIMPLE_MM:
            price = TVM_Simple2Price(ytm, dp, ddp, risk, debt, paym) ;
            break ;

        case MOOSMULLER:
            price = TVM_Moosmuller2Price(ytm, dp, ddp, risk, basis, debt,
                                         paym);
            break ;

        case MAIR:
            price = TVM_Mair2Price(ytm, dp, ddp, risk, rerates, debt, paym);
            break ;

        case BRAESSFANGMEYER:
            price = TVM_Braessfangmeyer2Price(ytm, dp, ddp, risk, debt,
                                              paym);
            break ;

        case SIMPLE_REPO:
            if (paym->count > 0)
                matur = paym->term[paym->count - 1] ;
            else
                matur = 0.0 ;

            /* Strictly speakuing we need the ex-adjusted maturity date */
            price = TVM_Simplerepo2Price(ytm, dp, ddp, risk, debt,
                                         paym, matur) ;
            break ;


        case DISCOUNT:
            price = TVM_Discount2Price(ytm, dp, ddp, risk, debt, paym);
            break ;

        default:
            ;
    }
    return price ;
}


/*
..
*/

FL64    TVM_Compound2Price(FL64   ytm,
                           FL64*     dp,
                           FL64*     ddp,
                           RISKCONV  risk,
                           INTI      basis,
                           FL64      debt,
                           PMT_STR*    paym)
{
    FL64    p, ytmc, base ;

    base = (FL64) basis;
    p = *dp = *ddp = 0.0;

    /* If the outstanding debt is zero then  ... */
    if (!debt)
        return 0.0 ;

    /* Transform to continuously compounded yield */
    ytmc = yld_compound2continuous(ytm, basis) ;

    /* Compute in this yield setup */
    p = TVM_Continuous2Price(ytmc, dp, ddp, risk, debt, paym) ;

    /* Now rescale to the desired setup */
    if (risk == SECOND_ORDER)
    {
        *ddp -= *dp / (100.0 * base) ;
        *ddp /= SQR((1.0 + ytm / (base * 100.0))) ;
    }

    if (risk == FIRST_ORDER || risk == SECOND_ORDER)
        *dp  /= (1.0 + ytm / (base * 100.0)) ;

    return p ;
}


/*
..
*/

FL64    TVM_USTreasury2Price(FL64   ytm,
                           FL64*     dp,
                           FL64*     ddp,
                           RISKCONV  risk,
                           INTI      basis,
                           FL64      debt,
                           PMT_STR*    paym)
{
    INTI dc, count, dur, conv, i;
    FL64 *t, *pr, p, pv, phi, plo, dytm  ;

    /* warning avoidance */
    plo = phi = 0.0 ;

    p = *dp = *ddp = 0.0;

    /* If the outstanding debt is zero then  ... */

    if (!debt)
        return 0.0 ;

    dur  = (risk == SECOND_ORDER || risk == FIRST_ORDER ? 1 : 0) ;
    conv = (risk == SECOND_ORDER ? 1 : 0) ;
    dc   = (conv || dur) ;
    dytm = SHOCK_SIZE ;

    t   = paym->term ;
    pr  = paym->payment ;

    count = paym->count ;

    for (i = 0 ; i < count ; t++, pr++, i++)
    {
        pv = (*pr)*TVMunit_USTreasury(ytm, *t, basis) ;
        if (dc)
        {
            plo = (*pr)*TVMunit_USTreasury(ytm - dytm, *t, basis) ;
            phi = (*pr)*TVMunit_USTreasury(ytm + dytm, *t, basis) ;
        }

        p += pv;
        if (dur)
            *dp  -= (plo - phi) / (2.0 * dytm);

        if (conv)
            *ddp += (phi + plo - 2.0 * pv) / SQR(dytm) ;
    }

    debt /= 100.0 ;

    if (dur)
        *dp  /= debt ;

    if (conv)
        *ddp /= debt ;

    return p / debt ;
}


/*
..
*/

FL64    TVM_Continuous2Price(FL64   ytm,
                             FL64*     dp,
                             FL64*     ddp,
                             RISKCONV  risk,
                             FL64      debt,
                             PMT_STR*    paym)
{
    INTI    count, dur, conv, i;
    FL64    *t, *pr, p, pv;

    p = *dp = *ddp = 0.0;

    /* If the outstanding debt is zero then  ... */
    if (!debt)
        return 0.0 ;

    dur  = (risk == SECOND_ORDER || risk == FIRST_ORDER ? 1 : 0) ;
    conv = (risk == SECOND_ORDER ? 1 : 0) ;

    t   = paym->term ;
    pr  = paym->payment ;

    count = paym->count ;

    for (i = 0 ; i < count ; t++, pr++, i++)
    {
        pv  = (*pr) * tvmunit_continuous(ytm, *t);
        p  += pv;
        if (dur)
            *dp  -= pv * (*t) ;

        if (conv)
            *ddp += pv * SQR(*t);
    }
    debt /= 100.0 ;

    if (dur)
        *dp  /= debt * 100.0 ;

    if (conv)
        *ddp /= debt * 10000.0 ;

    return p/debt ;
}


/*
..
*/

FL64    TVM_Simple2Price(FL64   ytm,
                         FL64*     dp,
                         FL64*     ddp,
                         RISKCONV  risk,
                         FL64      debt,
                         PMT_STR*    paym)
{
    INTI    dc, count, dur, conv, i;
    FL64    *t, *pr, p, pv, phi, plo, dytm  ;

    /* warning avoidance */
    plo = phi = 0.0 ;

    p = *dp = *ddp = 0.0;

    /* If the outstanding debt is zero then  ... */

    if (!debt)
        return 0.0 ;

    dur  = (risk == SECOND_ORDER || risk == FIRST_ORDER ? 1 : 0) ;
    conv = (risk == SECOND_ORDER ? 1 : 0) ;
    dc   = (conv || dur) ;
    dytm = SHOCK_SIZE ;

    t   = paym->term ;
    pr  = paym->payment ;

    count = paym->count ;

    for (i = 0 ; i < count ; t++, pr++, i++)
    {
        
		pv = (*pr)*tvmunit_simple(ytm, *t);

        if (dc)
        {
            plo = (*pr)*tvmunit_simple(ytm - dytm, *t) ;
            phi = (*pr)*tvmunit_simple(ytm + dytm, *t) ;
        }

        p += pv;
        if (dur)
            *dp  -= (plo - phi)/(2.0*dytm);

        if (conv)
            *ddp += (phi + plo - 2.0*pv)/SQR(dytm) ;
    }

    debt /= 100.0 ;

    if (dur)
        *dp  /= debt ;

    if (conv)
        *ddp /= debt ;

    return p/debt ;
}


/*
..
*/

FL64    TVM_CompoundSimple2Price(FL64   ytm,
                                 FL64*     dp,
                                 FL64*     ddp,
                                 RISKCONV  risk,
                                 INTI      basis,
                                 FL64      debt,
                                 PMT_STR*    paym)
{
    INTI count ;

    count = paym->count ;

    if (count == 1)
        return TVM_Simple2Price(ytm, dp, ddp, risk, debt, paym) ;
    else
        return TVM_Compound2Price(ytm, dp, ddp, risk, basis, debt, paym) ;
}


/*
..
*/

FL64    TVM_CompoundSimpleOdd2Price(FL64       ytm,
                                       FL64*      dp,
                                       FL64*      ddp,
                                       RISKCONV   risk,
                                       INTI       basis,
                                       FL64       debt,
                                       PMT_STR*   paym)
{
    FL64 *term ;
    INTI count ;

    count = paym->count ;
    term  = paym->term ;
 
    if (count > 0 && term[count - 1] <= 1.0)
        return TVM_Simple2Price(ytm, dp, ddp, risk, debt, paym) ;
    else
        return TVM_Compound2Price(ytm, dp, ddp, risk, basis, debt, paym) ;
}


/*
..
*/

FL64    TVM_Braessfangmeyer2Price(FL64   ytm,
                                  FL64*     dp,
                                  FL64*     ddp,
                                  RISKCONV  risk,
                                  FL64      debt,
                                  PMT_STR*    paym)
{
    INTI    dc, count, dur, conv, i;
    FL64    matur, *t, *pr, p, pv, phi, plo, dytm  ;

    phi = plo = p = *dp = *ddp = 0.0;

    /* If the outstanding debt is zero then  ... */

    if (!debt)
        return 0.0 ;

    dur  = (risk == SECOND_ORDER || risk == FIRST_ORDER ? 1 : 0) ;
    conv = (risk == SECOND_ORDER ? 1 : 0) ;
    dc   = (conv || dur) ;
    dytm = SHOCK_SIZE ;

    t     = paym->term ;
    pr    = paym->payment ;

    count = paym->count ;
    matur = t[count - 1] ;

    for (i = 0 ; i < count ; t++, pr++, i++)
    {
/*
        tmp = TVMunit_Braessfangmeyer(ytm, matur - *t) ;
        pv  = (*pr) * TVMunit_Braessfangmeyer(ytm, matur) / tmp ;
*/
        pv  = (*pr) * TVMunit_Braessfangmeyer(ytm, *t, matur) ;
        if (dc)
        {
/*
            tmp = TVMunit_Braessfangmeyer(ytm - dytm, matur - *t) ;
            plo = (*pr) * TVMunit_Braessfangmeyer(ytm - dytm, matur) / tmp ;
            tmp = TVMunit_Braessfangmeyer(ytm + dytm, matur - *t) ;
            phi = (*pr) * TVMunit_Braessfangmeyer(ytm + dytm, matur) / tmp ;
*/
            plo = (*pr) * TVMunit_Braessfangmeyer(ytm - dytm, *t, matur) ;
            phi = (*pr) * TVMunit_Braessfangmeyer(ytm + dytm, *t, matur) ;

        }

        p += pv;
        if (dur)
            *dp  -= (plo - phi)/(2.0*dytm);

        if (conv)
            *ddp += (phi + plo - 2.0*pv)/SQR(dytm) ;
    }

    debt /= 100.0 ;

    if (dur)
        *dp  /= debt ;

    if (conv)
        *ddp /= debt ;

    return p / debt ;
}


/*
..
*/

FL64 TVM_Simplerepo2Price(FL64   ytm,
                          FL64*     dp,
                          FL64*     ddp,
                          RISKCONV  risk,
                          FL64      debt,
                          PMT_STR*  paym,
                          FL64      matur)
{
    INTI    dc, count, dur, conv, i;
    FL64    *t, *pr, p, pv, phi, plo, dytm  ;

    phi = plo = p = *dp = *ddp = 0.0;

    /* If the outstanding debt is zero then  ... */
    if (!debt)
        return 0.0 ;

    dur  = (risk == SECOND_ORDER || risk == FIRST_ORDER ? 1 : 0) ;
    conv = (risk == SECOND_ORDER ? 1 : 0) ;
    dc   = (conv || dur) ;
    dytm = SHOCK_SIZE ;

    t     = paym->term ;
    pr    = paym->payment ;
    count = paym->count ;

    for (i = 0 ; i < count ; t++, pr++, i++)
    {
        pv  = (*pr) * TVMunit_Simplerepo(ytm, *t, matur) ;
        if (dc)
        {
            plo = (*pr) * TVMunit_Simplerepo(ytm - dytm, *t, matur) ;
            phi = (*pr) * TVMunit_Simplerepo(ytm + dytm, *t, matur) ;
        }

        p += pv;
        if (dur)
            *dp  -= (plo - phi) / (2.0 * dytm);

        if (conv)
            *ddp += (phi + plo - 2.0 * pv) / SQR(dytm) ;
    }

    debt /= 100.0 ;

    if (dur)
        *dp  /= debt ;

    if (conv)
        *ddp /= debt ;

    return p / debt ;
}


/*
..
*/

FL64    TVM_Moosmuller2Price(FL64   ytm,
                             FL64*     dp,
                             FL64*     ddp,
                             RISKCONV  risk,
                             INTI      basis,
                             FL64      debt,
                             PMT_STR*    paym)
{
    INTI    dc, count, dur, conv, i;
    FL64    dt, *t, *pr, p, pv, phi, plo, dytm  ;

    phi = plo = p = *dp = *ddp = 0.0;

    /* If the outstanding debt is zero then  ... */

    if (!debt)
        return 0.0 ;

    dur  = (risk == SECOND_ORDER || risk == FIRST_ORDER ? 1 : 0) ;
    conv = (risk == SECOND_ORDER ? 1 : 0) ;
    dc   = (conv || dur) ;
    dytm = SHOCK_SIZE ;

    t   = paym->term ;
    pr  = paym->payment ;
    count = paym->count ;

    for (i = 0 ; i < count ; t++, pr++, i++)
    {
        if (i == 0)
          dt = 0;
        else
          dt = *t - *(t-1);

        pv = (*pr)*tvmunit_moosmuller(ytm, *t, dt, basis);
        if (dc)
        {
            plo = (*pr)*tvmunit_moosmuller(ytm - dytm, *t, dt, basis) ;
            phi = (*pr)*tvmunit_moosmuller(ytm + dytm, *t, dt, basis) ;
        }

        p += pv;
        if (dur)
            *dp  -= (plo - phi)/(2.0*dytm);

        if (conv)
            *ddp += (phi + plo - 2.0*pv)/SQR(dytm) ;
    }

    debt /= 100.0 ;

    if (dur)
        *dp  /= debt ;
    if (conv)
        *ddp /= debt ;

    return p/debt ;
}



/*
..
*/

FL64    TVM_Mair2Price(FL64   ytm,
                       FL64*     dp,
                       FL64*     ddp,
                       RISKCONV  risk,
                       FL64ARRAY  rerate,
                       FL64      debt,
                       PMT_STR*    paym)
{
    INTI    dc, count, dur, conv, i;
    FL64    *reinv, matur, *t, *pr, p, pv, phi, plo, dytm  ;

    phi = plo = p = *dp = *ddp = 0.0;

    /* If the outstanding debt is zero then  ... */

    if (!debt)
        return 0.0 ;

    dur  = (risk == SECOND_ORDER || risk == FIRST_ORDER ? 1 : 0) ;
    conv = (risk == SECOND_ORDER ? 1 : 0) ;
    dc   = (conv || dur) ;
    dytm = SHOCK_SIZE ;

    t     = paym->term ;
    pr    = paym->payment ;
    reinv = rerate ;

    count = paym->count ;
    matur = t[count - 1] ;

    for (i = 0 ; i < count ; reinv++, t++, pr++, i++)
    {
        pv = (*pr)*TVMunit_Mair(ytm, *t, *reinv, matur);
        if (dc)
        {
            plo = (*pr)*TVMunit_Mair(ytm - dytm, *t, *reinv, matur) ;
            phi = (*pr)*TVMunit_Mair(ytm + dytm, *t, *reinv, matur) ;
        }

        p += pv;
        if (dur)
            *dp  -= (plo - phi)/(2.0*dytm);

        if (conv)
            *ddp += (phi + plo - 2.0*pv)/SQR(dytm) ;
    }

    debt /= 100.0 ;

    if (dur)
        *dp  /= debt ;

    if (conv)
        *ddp /= debt ;

    return p/debt ;
}


/*
..
*/

FL64    TVM_Discount2Price(FL64   ytm,
                           FL64*     dp,
                           FL64*     ddp,
                           RISKCONV  risk,
                           FL64      debt,
                           PMT_STR*    paym)
{
    INTI    dc, count, dur, conv, i;
    FL64    *t, *pr, p, pv, phi, plo, dytm  ;

    phi = plo = p = *dp = *ddp = 0.0;

    /* If the outstanding debt is zero then  ... */

    if (!debt)
        return 0.0 ;

    dur  = (risk == SECOND_ORDER || risk == FIRST_ORDER ? 1 : 0) ;
    conv = (risk == SECOND_ORDER ? 1 : 0) ;
    dc   = (conv || dur) ;
    dytm = SHOCK_SIZE ;

    t     = paym->term ;
    pr    = paym->payment ;

    count = paym->count ;

    for (i = 0 ; i < count ; t++, pr++, i++)
    {
        pv = (*pr)*tvmunit_discount(ytm, *t);
        if (dc)
        {
            plo = (*pr)*tvmunit_discount(ytm - dytm, *t) ;
            phi = (*pr)*tvmunit_discount(ytm + dytm, *t) ;
        }

        p += pv;
        if (dur)
            *dp  -= (plo - phi)/(2.0*dytm);

        if (conv)
            *ddp += (phi + plo - 2.0*pv)/SQR(dytm) ;
    }

    debt /= 100.0 ;

    if (dur)
        *dp /= debt ;

    if (conv)
        *ddp /= debt ;

    return p/debt ;
}


/*,,SOH,,
*************************************************************************
*
*               TVM_Zero2Price()
*
*    interface  #include <tvm.h>
*               FL64 TVM_Zero2Price(TS_STR     *ts,
*                                   RISKCONV   risk,
*                                   FL64       debt,
*                                   FL64       spread,
*                                   INTPOLCONV iconv,
*                                   PMT_STR    *paym,
*                                   FL64       *dp,
*                                   FL64       *ddp) ;
*
*    general    TVM_Zero2Price() calculates dirty price, dollar factor
*               sensitivity and dollar factor convexity as a function
*               of a zero coupon term structure for the payment stream
*               in paym.
*
*    input      TS_STR     *ts    Term structure for discounting.
*                                 The rates are annual in percent and
*                                 quoted as according the the conv and
*                                 qbas elements of ts. The interest
*                                 rate convention of ts must be one of
*
*                                       COMPOUND
*                                       CONTINUOUS
*                                       SIMPLE_MM
*                                       COMPOUNDSIMPLE
*                                       COMPOUNDSIMPLE_ODD
*                                       MOOSMULLER
*                                       BRAESSFANGMEYER
*                                       DISCOUNT
*                                       SIMPLE_REPO
*
*                                 The terms are in fractional years.
*                                 If you want the standard key ratios
*                                 insert 1.0 in the loadings element
*                                 of ts.
*
*               RISKCONV   risk   Switch for risk calculation.
*
*               FL64       debt   Outstanding debt per initial 100.
*
*               FL64       spread Interest rate spread relative to ts.
*                                 Annual rate in percent quoted as ts.
*
*               INTPOLCONV iconv  Interpolation convention - used for
*                                 setting up discounting rates.
*
*               PMT_STR    *paym  Structure of payments from bond.
*                                 The terms part of paym contains the
*                                 terms for the payments in fractions
*                                 of years.
*                                 The payments should not include any
*                                 accrued interest at the valuation day.
*
*    output     FL64       *dp    Factor dollar sensitivity of the
*                                 bond. Only calculated if risk is
*                                 either FIRST_ORDER or SECOND_ORDER.
*
*               FL64       *ddp   Factor dollar convexity of the bond,
*                                 calculated if risk is SECOND_ORDER.
*
*    returns    the dirty price of the cashflow.
*
*    diagnostics
*
*    see also   TVM_Yield2Price()
*
*    wrapper    AP
*
*************************************************************************
,,EOH,,*/

FL64 TVM_Zero2Price(TS_STR*  ts,
                    RISKCONV   risk,
                    FL64       debt,
                    FL64       spread,
                    INTPOLCONV iconv,
                    PMT_STR*     paym,
                    FL64*      dp,
                    FL64*      ddp)
{
    FL64    p, plo, phi, dflds ;
    TSARRAY ts1 ;
    INTI    count ;

    p = *dp = *ddp = 0.0;

    /* If the outstanding debt is zero then  ... */
    if (!debt)
        return 0.0 ;

    /* Various initialization */
    dflds = 0.01 ;
    debt /= 100.0 ;

    count = paym->count ;

    ts1 = Yld_GetRates(ts, paym->term, count, iconv) ;
    Yld_Shock_Rates(ts1, PARALLEL, spread) ;

    /* Find the net present value */
    p = TVM_Value_PMTARRAY(paym, ts1) ;

    /* Shock to find factor sensitivities */
    if (risk != ZERO_ORDER)
    {
        Yld_Shock_Rates(ts1, FACTOR_SHOCK, dflds) ;
        plo = TVM_Value_PMTARRAY(paym, ts1) ;

        Yld_Shock_Rates(ts1, FACTOR_SHOCK, -2.0*dflds) ;
        phi = TVM_Value_PMTARRAY(paym, ts1) ;

        if (risk != ZERO_ORDER)
            *dp  -= (phi - plo)/(2.0 * dflds * debt);

        if (risk == SECOND_ORDER)
            *ddp = (plo + phi - 2.0 * p)/(SQR(dflds) * debt);
    }
    Free_TSARRAY(ts1, 1) ;

    return p/debt ;
}


/*
..
*/

FL64 TVM_Value_PMTARRAY(PMT_STR* pmtstr,
                           TS_STR*   tsstr)
{
    INTI    c, i ;
    IRRCONV irr ;
    FL64    matur, *r, *t, *p, npv, *t1 ;
    INTI    qb ;

    npv = 0.0 ;

    qb  = tsstr->qbas ;
    irr = tsstr->conv ;
    t   = tsstr->term ;
    r   = tsstr->rate ;

    c   = pmtstr->count ;
    p   = pmtstr->payment ;
    t1  = pmtstr->term ;
  
    switch (irr)
    {
       case COMPOUND:
            for (i = 0 ; i < c ; p++, r++, t++, i++)
                npv += (*p)*tvmunit_compound(*r, *t, qb) ;
            break ;

       case US_TREASURY:
            for (i = 0 ; i < c ; p++, r++, t++, i++)
                npv += (*p)*TVMunit_USTreasury(*r, *t, qb) ;
            break ;

        case CONTINUOUS:
            for (i = 0 ; i < c ; p++, r++, t++, i++)
                npv += (*p)*tvmunit_continuous(*r, *t) ;
            break ;

        case SIMPLE_MM:
            for (i = 0 ; i < c ; p++, r++, t++, i++)
                npv += (*p)*tvmunit_simple(*r, *t) ;
            break ;

       case COMPOUNDSIMPLE:
            if (c == 1)
                npv += (*p) * tvmunit_simple(*r, *t) ;
            else
            {
                for (i = 0 ; i < c ; p++, r++, t++, i++)
                    npv += (*p) * tvmunit_compound(*r, *t, qb) ;
            }
            break ;

       case COMPOUNDSIMPLE_ODD:
            if (c < 1)
                break;
            
            if (t1[c - 1] <= 1.0)
                /* Simple (1 year and less): */
                for (i = 0 ; i < c ; p++, r++, t++, i++)
                    npv += (*p)*tvmunit_simple(*r, *t) ;
            else
              /* Compound (more than 1 year): */
                for (i = 0 ; i < c ; p++, r++, t++, i++)
                    npv += (*p)*tvmunit_compound(*r, *t, qb) ;
            break ;

        case MOOSMULLER:
            for (i = 0 ; i < c ; p++, r++, t++, i++)
            {
              if (i == 0)
                npv += (*p) * tvmunit_moosmuller(*r, *t, 0, qb) ;
              else
                npv += (*p) * tvmunit_moosmuller(*r, *t, *t - *(t-1), qb) ;
            }
            break ;

        case BRAESSFANGMEYER:
            matur = t[c - 1] ;

            for (i = 0 ; i < c ; p++, r++, t++, i++)
            {
/*
                tmp  = TVMunit_Braessfangmeyer(*r, matur - *t) ;
                npv += (*p) * TVMunit_Braessfangmeyer(*r, matur) / tmp ;
*/
                npv += (*p) * TVMunit_Braessfangmeyer(*r, *t, matur) ;
            }
            break ;

        case SIMPLE_REPO:
            matur = t[c - 1] ;

            for (i = 0 ; i < c ; p++, r++, t++, i++)
                npv += (*p) * TVMunit_Simplerepo(*r, *t, matur) ;
            break ;

        case DISCOUNT:
            for (i = 0 ; i < c ; p++, r++, t++, i++)
                npv += (*p) * tvmunit_discount(*r, *t) ;
            break ;

        default:
            ;
    }

    return npv ;
}


#undef DAY_TOL
#undef RATE_TOL
#undef TERM_TOL
#undef SHOCK_SIZE

/* SCID @(#)tvmyield.c	1.22 (SimCorp) 99/02/19 14:17:32 */

/************************************************************************
*
*    project    SCecon
*
*    filename   tvmyield.c
*
*    contains   routines in the SCecon Library Time Value of Money
*               module to calculate yields of bonds as function of
*               price
*
************************************************************************/

/*** includes **********************************************************/
#include <tvm.h>

/*** defines ***********************************************************/
#define YTM_ACC   (FL64)     0.0000000001
#define YTM_GUESS (FL64)    10.0
#define YTM_MIN   (FL64)   -49.9999
#define YTM_MAX   (FL64)  1000.0
#define YTM_MAXIT (INTI)   150
#define YTM_FREQ  (INTI)     1
#define YTM_EPS   (FL64)     0.0001
#define YTM_DAMP  (FL64)     1.0

#define OAS_MAXITER (INTI) 100       /* Max. number of iterations */
#define OAS_EPS     (FL64)   0.0001  /* Perturbation for numerical derivative */
#define OAS_TOL     (FL64)   0.000001  /* Tolerance 0.01% on OAS */
#define OAS_MIN     (FL64) -99.9999  /* Minimum value of OAS */
#define OAS_MAX     (FL64) 100.0
#define OAS_FREQ    (INTI)   3       /* Frequency for updating gradients */


/*,,SOH,,
*************************************************************************
*
*               TVM_Price2Yield()
*
*    interface  #include <tvm.h>
*               BOOLE TVM_Price2Yield(FL64      price,
*                                     INTI      basis,
*                                     IRRCONV   irr,
*                                     FL64ARRAY rerates,
*                                     FL64      debt,
*                                     PMT_STR   *paym,
*                                     FL64      acc,
*                                     FL64      *ytm) ;
*
*    general    TVM_Price2Yield() calculates the yield to maturity of
*               a bond corresponding to the input price respecting
*               the input interest rate convention.
*
*    input      FL64      price Dirty price of the bond in %.
*
*               INTI      basis Quoting basis of the unknown yield.
*                               Only needed if irr is COMPOUND,
*                               MOOSMULLER, COMPOUNDSIMPLE or
*                               COMPOUNDSIMPLE_ODD.
*
*               IRRCONV   irr   The yield convention in which the
*                               yield should be quoted.
*
*               FL64ARRAY  rerates Array of reinvestment rates in
*                               percent. Must be allocated with as many
*                               entries as paym->count
*                               The rates corresponds to the terms in
*                               paym.
*                               Only needed if irr is MAIR, otherwise
*                               just give an empty array.
*
*               FL64      debt  Outstanding debt per initial 100.
*
*               PMT_STR   *paym Structure of payments from the bond.
*                               The terms part of paym contains the
*                               terms for the payments in fractions
*                               of years.
*                               The payments should not include any
*                               accrued interest at the valuation day.
*
*               FL64      acc   Desired price  accuracy. Choose from
*                               1.0E-5 to 1.0E-10
*
*    output     FL64      *ytm  The YTM
*
*    returns    True if OK, False if not.
*
*    diagnostics
*
*    see also   TVM_Yield2Price()
*               TVM_YieldByFormula()
*
*************************************************************************
,,EOH,,*/


BOOLE TVM_Price2Yield(FL64   price,
                        INTI      basis,
                        IRRCONV   irr,
                        FL64ARRAY  rerates,
                        FL64      debt,
                        PMT_STR*  paym,
                        FL64      acc,
                        FL64*      ytm)
{
    FL64    *term, min ;

    min = YTM_MIN ;

    if (irr == SIMPLE_MM)
    {
        term = paym->term ;

        min = ((irr == SIMPLE_MM && paym->count) ?
                GETMAX(YTM_MIN, -100.0/term[paym->count - 1]) : YTM_MIN) ;
    }

    return TVM_Root(price, basis, irr, rerates, debt, paym, acc, min, ytm);
}


/*,,SOH,,
*************************************************************************
*
*               TVM_Zero2Spread()
*
*    interface  #include <tvm.h>
*               BOOLE TVM_Zero2Spread(TS_STR     *ts,
*                                     FL64       debt,
*                                     INTPOLCONV iconv,
*                                     PMT_STR    *paym,
*                                     FL64       dirty,
*                                     FL64       guess,
*                                     FL64       *oas) ;
*
*    general    TVM_Zero2Spread() calculates the interest rate spread
*               relative to the term structure.
*               The spread is the annual spread over the zero coupon
*               curve that explains the dirty price given the top rate
*               term structure.
*               If the dirty price is equal to the yield curve price
*               then the spread is zero. More often, however, the
*               spread is positive indicating that the cashflow has a
*               poorer credit rating than the cash flows that constitute
*               the yield curve.
*
*               The spread is found by an iterative procedure. To speed
*               up this iteration you can supply a first guess.
*               An intelligent guess is usually the previous spread
*
*    input      TS_STR     *ts   Term structure for discounting.
*                                The rates are annual in percent and
*                                quoted as specified in the conv and
*                                qbas elements of ts. The interest
*                                rate convention of ts must be one of
*
*                                      COMPOUND
*                                      CONTINUOUS
*                                      SIMPLE_MM
*                                      COMPOUNDSIMPLE
*                                      COMPOUNDSIMPLE_ODD
*                                      MOOSMULLER
*                                      BRAESSFANGMEYER
*                                      DISCOUNT
*
*                                The terms are in fractional years.
*
*               FL64       debt  Outstanding debt per initial 100.
*
*               INTPOLCONV iconv Interpolation convention - used for
*                                setting up discounting rates.
*
*               PMT_STR    *paym Structure of payments from bond
*                                The terms part of paym contains the
*                                terms for the payments in fractions
*                                of years.
*                                The payments should not include any
*                                accrued interest at the valuation day.
*
*               FL64       dirty The market price of the cashflow.
*
*               FL64       guess The initial guess - typically the
*                                previous spread.
*
*    output     FL64       *oas  The annual spread in %
*
*    returns    True if OK, False if not
*
*    diagnostics
*
*    see also   TVM_Zero2Price()
*
*    wrapper    AP
*
*************************************************************************
,,EOH,,*/


BOOLE TVM_Zero2Spread(TS_STR*  ts,
                      FL64       debt,
                      INTPOLCONV iconv,
                      PMT_STR*     paym,
                      FL64       dirty,
                      FL64       guess,
                      FL64*       oas)
{
    TVMTYPE   type ;
    TVMINT    tvm_data ;
    ITERCTRL  ctrl ;
    NR_ERR    err ;
    BOOLE     ok ;

	/* PMSTA-22396 - SRIDHARA � 160502 */
	HOLI_STR holi;
	holi = Set_HOLI_STR(NO_BUSADJUST, 0, NULL);

    type = ZERO_TVM ;

    Init_ITERCTRL(&ctrl) ;
    ctrl.maxiter = OAS_MAXITER ;
    ctrl.init_guess = guess ;
    ctrl.lower = GETMIN(OAS_MIN, ctrl.init_guess) ;
    ctrl.upper = GETMAX(OAS_MAX, ctrl.init_guess) ;
    ctrl.damp = 1.0 ;
    ctrl.acc = OAS_TOL ;
    ctrl.what_acc = 1 ;
    ctrl.gfreq = OAS_FREQ ;
    ctrl.bisec = 2 ;
    ctrl.shock = 0.0 ;

    tvm_data = TVM_SetTVMINT(type, dirty, debt, 0.0, NULL, 0, 
      CONTINUOUS, 0, BULLET, paym, ts, iconv, OAS_EPS) ;

	err = Newton_Raphson(&TVM_NewtonRaphson, &tvm_data, &ctrl, oas, &holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */
    ok = (err == NR_ROOT_FOUND ? True : False) ;

    return ok ;
}


/*,,SOH,,
*************************************************************************
*
*               TVM_YieldByFormula()
*
*    interface  #include <tvm.h>
*               BOOLE TVM_YieldByFormula(FL64     pv,
*                                          FL64     pmt,
*                                          FL64     t,
*                                          BONDTYPE type,
*                                          FL64     acc,
*                                          FL64     *ytm) ;
*
*    general    TVM_YieldByFormula() calculates the periodically
*               compounded yield for straight bonds by formula.
*
*    input      FL64      pv    Price of the bond per 100 outstanding.
*
*               FL64      pmt   Periodical payment from the bond in
*                               percent.
*                                 For annuities - the annuity.
*                                 For bullets   - the periodic coupon
*                                 For serials   - the periodic coupon
*
*               FL64      t     Maturity in fractions of the period
*                               between payments.
*
*               BONDTYPE  type  Choose one of:
*
*                                         BULLET
*                                         ANNUITY
*                                         SERIAL
*
*               FL64      acc   Desired price accuracy. Choose from
*                               from 1.0E-5 to 1.0E-10
*
*    output     FL64      *ytm  The YTM as annual %
*
*    returns    True if all is OK, False if not
*
*    diagnostics
*
*    see also   TVM_Price2Yield()
*               TVM_NPVBondtype()
*
*************************************************************************
,,EOH,,*/


BOOLE TVM_YieldByFormula(FL64  pv,
                             FL64     pmt,
                             FL64     t,
                             BONDTYPE type,
                             FL64     acc,
                             FL64*     ytm)
{
    TVMTYPE tvm_type ;
    TVMINT  tvm_data ;
    ITERCTRL ctrl ;
    NR_ERR  err ;
    BOOLE   ok ;

	/* PMSTA-22396 - SRIDHARA � 160502 */
	HOLI_STR holi;
	holi = Set_HOLI_STR(NO_BUSADJUST, 0, NULL);

    tvm_type = YIELD_TVM ;

    Init_ITERCTRL(&ctrl) ;
    ctrl.maxiter = YTM_MAXIT ;
    ctrl.init_guess = ((fabs(pmt) > YTM_EPS) ? pmt : YTM_GUESS) ;
    ctrl.lower = GETMIN(YTM_MIN, ctrl.init_guess) ;
    ctrl.upper = GETMAX(YTM_MAX, ctrl.init_guess) ;
    ctrl.damp = YTM_DAMP ;
    ctrl.acc = ((acc <= 0.0) ? YTM_ACC : acc) ;
    ctrl.what_acc = 1 ;
    ctrl.gfreq = YTM_FREQ ;
    ctrl.bisec = 2 ;
    ctrl.shock = 0.0 ;

    tvm_data = TVM_SetTVMINT(tvm_type, pv, t, pmt, NULL, 0, 
      CONTINUOUS, 0, type, NULL, NULL, LINEAR_EXTRAPOL, YTM_EPS) ;

    err = Newton_Raphson(&TVM_NewtonRaphson, &tvm_data, &ctrl, ytm, &holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */
    ok = (err == NR_ROOT_FOUND ? True : False) ;

    return ok ;
}


/************************************************************************
*
*               TVM_Root()
*
*    interface  #include <tvm.h>
*
*               BOOLE TVM_Root(FL64     price,
*                                INTI     qb,
*                                IRRCONV  irr,
*                                FL64ARRAY rerate,
*                                FL64     debt,
*                                PMT_STR  *pmt,
*                                FL64     yacc,
*                                FL64     min,
*                                FL64     *ytm) ;
*
*    general    TVM_Root() finds the root of a input function using
*               Newton-Raphson iterations.
*
*               This is not a general rootfinding routine. It has been
*               tailored to the problems encountered in standard
*               financial calculations. Here we know that the function
*               at hand is convex in the standard setup, and that there
*               is only ONE unique positive root to locate. Hence
*               the Newton-Raphson algorithm is stable under weak
*               assumptions - even if we do not update the gradient
*               in each iteration.
*               If the problem is not a standard one the routine might
*               not be adequate for finding the root.
*               In particular we have omitted the switching procedure
*               between Newton-Raphson and bisection - since this is
*               time consuming and of little practical use (since the
*               standard setup is stable).
*
*               For problems where multiple roots may exist we find
*               one root (most likely the one closest to the right
*               of origo) - this could be the case if the cashflow
*               has payments with different signs (alternating).
*
*               Finally notice that we only look for roots larger than
*               -1 (or rather -100%).
*
*    input      FL64     price   Price of bond per 100 outstanding
*               INTI     qb      Quoting basis of the unknown yield.
*                                Only needed if irr is COMPOUND,
*                                MOOSMULLER, COMPOUNDSIMPLE or
*                                COMPOUNDSIMPLE_ODD.
*               IRRCONV  irr     The yield convention in which the yield*
*                                shold be quoted.
*               FL64ARRAY rerate Array of reinvestment rates (%) -
*                                allocated with
*                                pmt->count entries by Alloc_FL64ARRAY().
*               FL64     debt    Outstanding debt
*               PMT_STR  *pmt     Structure of payments from bond -
*               FL64     yacc    Accuracy as measured on the function
*                                value and not on the input values.
*               FL64     min     The minimally attainable root
*                                typically -99.99 %)
*
*    output     FL64     *ytm
*
*    returns    True if OK, False if not
*
*    diagnostics
*
*    see also    math_rootfinder() for a general rootfinder.
*
************************************************************************/


BOOLE   TVM_Root(FL64  price, INTI  qb, IRRCONV irr, FL64ARRAY rerate,
                 FL64    debt, PMT_STR*   pmt,
                 FL64    yacc, FL64    min, FL64* ytm)
{
    TVMTYPE type ;
    TVMINT  tvm_data ;
    ITERCTRL ctrl ;
    NR_ERR  err ;
    BOOLE   ok ;

	/* PMSTA-22396 - SRIDHARA � 160502 */
	HOLI_STR holi;
	holi = Set_HOLI_STR(NO_BUSADJUST, 0, NULL);

    type = ROOT_TVM ;

    Init_ITERCTRL(&ctrl) ;
    ctrl.maxiter = YTM_MAXIT ;
    ctrl.init_guess = YTM_GUESS ;
    ctrl.lower = GETMIN(min, ctrl.init_guess) ;
    ctrl.upper =  YTM_MAX ;
    ctrl.damp = YTM_DAMP ;
    ctrl.acc = ((yacc <= 0.0) ? YTM_ACC : yacc) ;
    ctrl.what_acc = 1 ;
    ctrl.gfreq = YTM_FREQ ;
    ctrl.bisec = 2 ;
    ctrl.shock = 0.1 ;

    tvm_data = TVM_SetTVMINT(type, price, debt, 0.0, rerate, 0, 
      irr, qb, BULLET, pmt, NULL, LINEAR_EXTRAPOL, 0.0) ;

    err = Newton_Raphson(&TVM_NewtonRaphson, &tvm_data, &ctrl, ytm, &holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */
    ok = (err == NR_ROOT_FOUND ? True : False) ;

    return ok ;
}

/*
..
*/

TVMINT TVM_SetTVMINT(TVMTYPE    type,
                         FL64       npv,
                         FL64       t,
                         FL64       std,
                         FL64ARRAY  rerate,
                         INTI       n,
                         IRRCONV    irr,
                         INTI       qb,
                         BONDTYPE   bond,
                         PMT_STR*   pmt,
                         TS_STR*    ts,
                         INTPOLCONV  iconv,
                         FL64       shock) 
{
  TVMINT tvm_data ;

  tvm_data.type = type ;
  tvm_data.npv = npv ;
  tvm_data.t = t ;
  tvm_data.std = std ;
  tvm_data.rerate = rerate ;
  tvm_data.n = n ;
  tvm_data.irr = irr ;
  tvm_data.qb = qb ;
  tvm_data.bond = bond ;
  tvm_data.pmt = pmt ;
  tvm_data.ts = ts ;
  tvm_data.iconv = iconv ;
  tvm_data.shock = shock ;

  return tvm_data ;
}

/*
..
*/

void TVM_GetTVMINT(TVMINT*     tvm_data,
                       TVMTYPE*    type,
                       FL64*       npv,
                       FL64*       t,
                       FL64*       std,
                       FL64ARRAY*  rerate,
                       INTI*       n,
                       IRRCONV*    irr,
                       INTI*       qb,
                       BONDTYPE*   bond,
                       PMT_STR**   pmt,
                       TS_STR**    ts,
                       INTPOLCONV*  iconv,
                       FL64*       shock) 
{
  *type = tvm_data->type ;
  *npv = tvm_data->npv ;
  *t = tvm_data->t ;
  *std = tvm_data->std ;
  *rerate = tvm_data->rerate ;
  *n = tvm_data->n ;
  *irr = tvm_data->irr ;
  *qb = tvm_data->qb ;
  *bond = tvm_data->bond ;
  *pmt = tvm_data->pmt ;
  *ts = tvm_data->ts ;
  *iconv = tvm_data->iconv ;
  *shock = tvm_data->shock ;
}

/*
..
*/

BOOLE TVM_NewtonRaphson(FL64    x, 
                           void*   y,
                           BOOLE   grad,
                           FL64*   fx, 
                           FL64*   dfx,
						   void*   hol) 
{
  /* PMSTA-29444 - SRIDHARA - 050318 */
  HOLI_STR    holi = (*(HOLI_STR *)hol);
  holi = Set_HOLI_STR(NO_BUSADJUST, 0, NULL);

  TVMTYPE   type ;
  FL64      npv, t, std, shock, fx1, dum ;
  FL64ARRAY rerate ;
  INTI      n, qb, i ;
  IRRCONV   irr ;
  BONDTYPE  bond ;
  PMT_STR   *pmt ;
  TS_STR    *ts ;
  INTPOLCONV iconv ;


  /* Get data from y */
  TVM_GetTVMINT((TVMINT*)y, &type, &npv, &t, &std, &rerate,
    &n, &irr, &qb, &bond, &pmt, &ts, &iconv, &shock) ;
  shock = ((shock <= 0.0) ? YTM_EPS : shock ) ;

  switch (type)
  {
    case UNIT_TVM :

      *fx  = TVMunit_NPV(t, x, irr, qb) - npv ;
      break ;

    case DISC_TVM :

      for (*fx = 1.0, i = 0; i < n; i++)
        *fx *= TVMunit_NPV(rerate[i], x, irr, qb) ;
      *fx -= npv ;
      break ;

    case STAT_TVM :

      *fx = Stat_CumulativeNormal(t + x * std, t, std) -
            Stat_CumulativeNormal(t - x * std, t, std) - npv ;
      break ;

    case YIELD_TVM :

      *fx = TVM_NPVBondtype(std, x, t, bond, ZERO_ORDER, &dum, &dum) - npv ;
      break ;

    case ROOT_TVM :

      *fx = TVM_Yield2Price(x, ZERO_ORDER, qb, t, irr, rerate, pmt, 
        &dum, &dum) - npv ;
      break ;

    case ZERO_TVM :

      *fx = TVM_Zero2Price(ts, ZERO_ORDER, t, x,
                           iconv, pmt, &dum, &dum) - npv ;
      break ;
  } ;

  if (grad == True)
  {
    switch (type)
    {
      case UNIT_TVM :
      
        fx1  = TVMunit_NPV(t, x + shock, irr, qb) - npv ;
        *dfx = (fx1 - *fx) / shock ;        
        break ;

      case DISC_TVM :

        for (fx1 = 1.0, i = 0; i < n; i++)
          fx1 *= TVMunit_NPV(rerate[i], x + shock, irr, qb) ;
        *fx -= npv ;
        *dfx = (fx1 - *fx) / shock ;        
        break ;

      case STAT_TVM :

        
        fx1 = Stat_CumulativeNormal(t + (x + shock) * std, t, std) -
          Stat_CumulativeNormal(t - (x + shock) * std, t, std) - npv ;
        *dfx = (fx1 - *fx) / shock ;        
        break ;
      case YIELD_TVM :

        fx1 = TVM_NPVBondtype(std, x + shock, t, bond, ZERO_ORDER, &dum, &dum) 
          - npv ;
        *dfx = (fx1 - *fx) / shock ;        
        break ;

      case ROOT_TVM :

        fx1 = TVM_Yield2Price(x, FIRST_ORDER, qb, t, irr, rerate, pmt, 
          dfx, &dum) - npv ;
        break ;

      case ZERO_TVM :

        fx1 = TVM_Zero2Price(ts, ZERO_ORDER, t, x + shock,
                           iconv, pmt, &dum, &dum) - npv ;
        *dfx = (fx1 - *fx) / shock ;        
        break ;
    } ;
  }

  return True ;

}

#undef YTM_ACC
#undef YTM_GUESS
#undef YTM_MIN
#undef YTM_MAX
#undef YTM_MAXIT
#undef YTM_FREQ
#undef YTM_DAMP
#undef YTM_EPS

#undef OAS_MAXITER
#undef OAS_EPS
#undef OAS_TOL
#undef OAS_MIN
#undef OAS_MAX
#undef OAS_FREQ

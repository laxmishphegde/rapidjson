/* SCID @(#)testmath.c	1.5 (SimCorp) 99/10/01 14:51:41 */

/***********************************************************************
*
*   project     SCecon
*
*   this program tests the routines in the yield module of SCecon.
*
***********************************************************************/


/*** includes *********************************************************/
#include <stdlib.h>
#include <scalloc.h>
#include <str2conv.h>
#include <ioconv.h>

INTI mathtest(char* txa, FILE* in, FILE* out)
{
    INTI       diff, n1, n2, i1, i2, i3;
    FL64MATRIX matrix, inv;
    FL64ARRAY  res_v, v;
    FL64       determ, tmp  ;
    BOOLE      ok;

    diff = -1;

    if (!strcmp(txa, "Math_InvertSmtrx()"))
    {
      fprintf(out, "?; testing %s\n", txa);

      IOUtil_ParseLine(in, out);

      matrix = Read_FL64MATRIX(in, out, &n1, &n2);
      inv = Alloc_FL64MATRIX(n1, n2);

      if (n1 != n2)
      {
        fprintf(out, "1; Non-quadratic matrix\n");
        diff = 1;
      }
      else
      {
        determ = 1.0;
        ok = Math_InvertSmtrx(n1, matrix, inv, &determ);

        if (!ok)
        {
          fprintf(out, "1; Could not invert matrix\n");
          diff = 1;
        }
        else
        {
          for (i1 = 0; i1 < n1; i1++)
          {
            for (i2 = 0; i2 < n2; i2++)
            {
              tmp = 0.0;
              for (i3 = 0; i3 < n2; i3++)
                tmp += matrix[i1][i3] * inv[i3][i2];
              fprintf(out, "% 8.6lf", tmp);
              if (i1 != i2 && fabs(tmp) > 1.0e-6 || 
                  i1 == i2 && fabs(tmp - 1.0) > 1.0e-6)
                fprintf(out, "%s", "*");
              fprintf(out, "  ");
            }
            fprintf(out, "\n");
          }
          fprintf(out, "\n\n");
          diff = Write_FL64MATRIXdiff(in, out, True,  inv, n1, n2, 
                                      True, 1.0e-4);
        }
      }

      Free_FL64MATRIX(matrix);
      Free_FL64MATRIX(inv);
    }


    else if (!strcmp(txa, "Math_SYM2OD()"))
    {
      fprintf(out, "?; testing %s\n", txa);

      IOUtil_ParseLine(in, out);

      matrix = Read_FL64MATRIX(in, out, &n1, &n2);
      v = Alloc_FL64ARRAY(n1);

      if (n1 != n2)
      {
        fprintf(out, "1; Non-quadratic matrix\n");
        diff = 1;
      }
      else
      {
        determ = 1.0;
        ok = Math_SYM2OD(n1, matrix, v, 100);

        if (!ok)
        {
          fprintf(out, "1; Could not invert matrix\n");
          diff = 1;
        }
        else
        {
          fprintf(out, "\n\n");
          diff = Write_FL64MATRIXdiff(in, out, True, matrix, n1, n2, 
                                      True, 1.0e-6);
          res_v = Read_FL64ARRAY(in, &n2);
          diff = diff | WriteFL64ARRAYDiff(True, res_v, n2, True,
                        v, n1, out, 1.0e-6);
          Free_FL64ARRAY(res_v);
        }
      }

      Free_FL64MATRIX(matrix);
      Free_FL64ARRAY(v);
    }

    else if (!strcmp(txa, "run:Math_SYM2OD()"))
    {
      fprintf(out, "?; testing %s\n", txa);

      IOUtil_ParseLine(in, out);

      matrix = Read_FL64MATRIX(in, out, &n1, &n2);
      v = Alloc_FL64ARRAY(n1);

      if (n1 != n2)
      {
        fprintf(out, "1; Non-quadratic matrix\n");
        diff = 1;
      }
      else
      {
        determ = 1.0;
        ok = Math_SYM2OD(n1, matrix, v, 100);

        if (!ok)
        {
          fprintf(out, "1; Could not decompose matrix.\n");
          diff = 1;
        }
        else
        {
          fprintf(out, "\n\n");
          
          fprintf(out, "Eigen-vectors:\n");
          Write_FL64MATRIX(matrix, n1, n2, 13, out);
          fprintf(out, "Eigen-values:\n");
          Write_FL64MATRIX(&v, 1, n1, 13, out);
          fprintf(out, "\n");
        }
      }

      Free_FL64MATRIX(matrix);
      Free_FL64ARRAY(v);
      diff = 0;
    }

    return diff ;
}

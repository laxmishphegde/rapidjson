/* SCID @(#)duration.c	1.20 (SimCorp) 99/02/19 14:15:29 */

/************************************************************************
*
*   project     SCecon
*
*   filename    duration.c
*
*   contains    routines in the SCecon Library Time Value of Money
*               module to calculate price as a function of yield
*
************************************************************************/

/*** includes **********************************************************/
#include <tvm.h>


/*,,SOH,,
*************************************************************************
*
*               TVM_Yield2Duration()
*
*    interface  #include <tvm.h>
*               FL64 TVM_Yield2Duration(FL64      ytm,
*                                       INTI      basis,
*                                       IRRCONV   irr,
*                                       FL64ARRAY rerate,
*                                       PMT_STR   *paym) ;
*
*    general    TVM_Yield2Duration() calculates duration as a function
*               of yield to maturity for the payment stream in paym
*               using the required interest rate convention.
*               The duration is here interpreted as the present value
*               weighted sum of terms.
*
*    input      FL64      ytm   Yield to maturity of the bond in
*                               percent.
*
*               INTI      basis Quoting basis of the yield.
*
*               IRRCONV   irr   The interest rate convention of the
*                               yield.
*
*               FL64ARRAY rerate Array of reinvestment rates in percent.
*                               Allocated with as many entries as
*                               paym->count.
*                               The rates must correspond to the terms
*                               in paym.
*                               Only used is irr is MAIR.
*
*               PMT_STR   *paym Reference to structure of payments
*                               The terms part of paym contains the
*                               terms for the payments in fractional
*                               years.
*                               The payments should not include any
*                               accrued interest at the valuation day,
*                               since the function calculates the
*                               dirty price from the flow.
*
*    output
*
*    returns    The duration of the cashflow in years.
*
*    diagnostics
*
*    see also   TVM_Zero2Duration()
*
*************************************************************************
,,EOH,,*/


FL64    TVM_Yield2Duration(FL64   ytm,
                           INTI      basis,
                           IRRCONV   irr,
                           FL64ARRAY  rerate,
                           PMT_STR*    paym)
{
    FL64    dur ;

    switch (irr)
    {
        case COMPOUND:
            dur = TVM_Compound2Duration(ytm, basis, paym) ;
            break ;

        case US_TREASURY:
            dur = TVM_USTreasury2Duration(ytm, basis, paym) ;
            break ;

        case COMPOUNDSIMPLE:
            dur = TVM_CompoundSimple2Duration(ytm, basis, paym) ;
            break ;

        case COMPOUNDSIMPLE_ODD:
            dur = TVM_CompoundSimpleOdd2Duration(ytm, basis, paym) ;
            break ;

        case CONTINUOUS:
            dur = TVM_Continuous2Duration(ytm, paym) ;
            break ;

        case SIMPLE_MM:
            dur = TVM_Simple2Duration(ytm, paym) ;
            break ;

        case MOOSMULLER:
            dur = TVM_Moosmuller2Duration(ytm, basis, paym);
            break ;

        case BRAESSFANGMEYER:
            dur = TVM_Braessfangmeyer2Duration(ytm, paym);
            break ;

        case SIMPLE_REPO:
            dur = TVM_Simplerepo2Duration(ytm, paym);
            break ;

        case MAIR:
            dur = TVM_Mair2Duration(ytm, rerate, paym);
            break ;

        case DISCOUNT:
            dur = TVM_Discount2Duration(ytm, paym) ;
            break ;

        default:
            /* warning avoidance */
            dur = 0.0 ;
            break ;
    }
    return dur ;
}


/************************************************************************
*
*               TVM_Compound2Duration()
*
*    interface  #include <tvm.h>
*               FL64 TVM_Compound2Duration(FL64     ytm,
*                                          INTI     basis,
*                                          PMT_STR *  paym) ;
*
*    general    TVM_Compound2Duration() calculates duration as a
*               function of compounded yield to maturity for the
*               payment stream in paym using the compounded yield
*               convention.
*               The duration is here interpreted as the present value
*               weighted sum of terms.
*
*               The routine is implemented such that the compounded
*               yield, ytm, is translated to continuously compounded
*               yield. The computations are then performed for this
*               yield.
*
*               The reason for this is that the CPU performance is
*               significantly better. On average this implementation
*               will be in the order of 33 - 67 % faster than the
*               default procedure. Only for cases where all the terms
*               are in whole basis periods will the procedure used here
*               be outperformed by the default procedure. Since this is
*               a special cases we have chosen to use the procedure,
*               that performs best on generic cashflows.
*
*    input      FL64      ytm  Yield to maturity of the bond in
*                              percent.
*
*               INTI      basis Quoting basis of the yield.
*
*               PMT_STR *   paym Reference to structure of payments
*                              The terms part of paym contains the
*                              terms for the payments in fractions
*                              of years.
*
*    output
*
*    returns    The duration of the cashflow in years.
*
*    diagnostics
*
*    see also
*
************************************************************************/


FL64    TVM_Compound2Duration(FL64   ytm,
                              INTI      basis,
                              PMT_STR*    paym)
{
    FL64    ytmc ;

    /* Transform to continuously compounded yield */

    ytmc = yld_compound2continuous(ytm, basis) ;

    return TVM_Continuous2Duration(ytmc, paym) ;
}


/************************************************************************
*
*               TVM_Continuous2Duration()
*
*    interface  #include <tvm.h>
*               FL64 TVM_Continuous2Duration(FL64     ytm,
*                                            PMT_STR *  paym) ;
*
*    general    TVM_Continuous2Duration() calculates duration as a
*               function of the continuously compounded yield to
*               maturity for the payment stream in paym.
*               The duration is here interpreted as the present value
*               weighted sum of terms.
*
*    input      FL64      ytm   Continuously compounded yield to
*                               maturity of the bond in percent.
*
*               PMT_STR *   paym  Reference to structure of payments
*
*    output
*
*    returns    The duration of the cashflow in years.
*
*    diagnostics
*
*    see also   tvm_price2continuous()
*
************************************************************************/


FL64    TVM_Continuous2Duration(FL64   ytm,
                                PMT_STR*    paym)
{
    INTI    i, count ;
    FL64    dur, p, pv;
    FL64    *term, *payment ;

    term    = paym->term ;
    payment = paym->payment ;
    count   = paym->count ;

    for (p = dur = 0.0, i = 0 ; i < count ; i++)
    {
        pv   = payment[i] * tvmunit_continuous(ytm, term[i]);
        p   += pv;
        dur += term[i] * pv ;
    }

    return (p ? dur / p : 0.0) ;
}


/************************************************************************
*
*               TVM_Simple2Duration()
*
*    interface  #include <tvm.h>
*               FL64 TVM_Simple2Duration(FL64     ytm,
*                                        PMT_STR *  paym) ;
*
*    general    TVM_Simple2Duration() calculatesduration as a function
*               of simple money market yield for the payment stream in
*               paym.
*               The duration is here interpreted as the present value
*               weighted sum of terms.
*
*    input      FL64      ytm   Simple money market yield to maturity
*                               of the bond in percent.
*
*               PMT_STR *   paym  Reference to structure of payments
*
*    output
*
*    returns    The duration of the cashflow (in years)
*
*    diagnostics
*
*    see also   tvm_price2simple()
*
************************************************************************/


FL64    TVM_Simple2Duration(FL64   ytm,
                            PMT_STR*    paym)
{
    INTI    i, count ;
    FL64    dur, p, pv;
    FL64    *term, *payment ;

    term    = paym->term ;
    payment = paym->payment ;
    count   = paym->count ;

    for (p = dur = 0.0, i = 0 ; i < count ; i++)
    {
        pv   = payment[i] * tvmunit_simple(ytm, term[i]);
        p   += pv;
        dur += term[i] * pv ;
    }

    return (p ? dur/p : 0.0) ;
}


/************************************************************************
*
*               TVM_USTreasury2Duration()
*
*    interface  #include <tvm.h>
*               FL64 TVM_USTreasury2Duration(FL64     ytm,
*                                            INTI     qb,
*                                            PMT_STR *  paym) ;
*
*    general    The routine calculates duration as a function
*               of US Treasury yield for the payment stream in
*               paym.
*
*               The duration is here interpreted as the present value
*               weighted sum of terms.
*
*    input      FL64      ytm   Simple money market yield to maturity
*                               of the bond in percent.
*
*               INTI      qb    Quoting basis of the yield.
*
*               PMT_STR * paym  Reference to structure of payments
*
*    output
*
*    returns    The duration of the cashflow (in years)
*
*    diagnostics
*
*    see also   tvm_price2ustreasury()
*
************************************************************************/


FL64 TVM_USTreasury2Duration(FL64   ytm,
                             INTI      qb,
                             PMT_STR*   paym)
{
    INTI    i, count ;
    FL64    dur, p, pv;
    FL64    *term, *payment ;

    term    = paym->term ;
    payment = paym->payment ;
    count   = paym->count ;

    for (p = dur = 0.0, i = 0 ; i < count ; i++)
    {
        pv   = payment[i] * TVMunit_USTreasury(ytm, term[i], qb);
        p   += pv;
        dur += term[i] * pv ;
    }

    return (p ? dur / p : 0.0) ;
}


/************************************************************************
*
*               TVM_Discount2Duration()
*
*    interface  #include <tvm.h>
*
*               FL64 TVM_Discount2Duration(FL64     ytm,
*                                          PMT_STR *  paym) ;
*
*    general    TVM_Discount2Duration() calculates duration as a
*               function of discount yield for the payment stream
*               in paym.
*               The duration is here interpreted as the present
*               value weighted sum of terms.
*
*    input      FL64      ytm   Discount yield in percent.
*
*               PMT_STR *   paym  Reference to structure of payments
*
*    output
*
*    returns    The duration of the cashflow in years.
*
*    diagnostics
*
*    see also
*
************************************************************************/


FL64    TVM_Discount2Duration(FL64   ytm,
                              PMT_STR*    paym)
{
    INTI    i, count ;
    FL64    dur, p, pv;
    FL64    *term, *payment ;

    term    = paym->term ;
    payment = paym->payment ;
    count   = paym->count ;

    for (p = dur = 0.0, i = 0 ; i < count ; i++)
    {
        pv   = payment[i] * tvmunit_discount(ytm, term[i]);
        p   += pv;
        dur += term[i] * pv ;
    }

    return (p ? dur/p : 0.0) ;
}


/************************************************************************
*
*               TVM_CompoundSimple2Duration()
*
*    interface  #include <tvm.h>
*               FL64 TVM_CompoundSimple2Duration(FL64     ytm,
*                                                INTI     basis,
*                                                PMT_STR *  paym) ;
*
*    general    TVM_CompoundSimple2Duration() calculates duration
*               as a function of compounded yield/simple
*               to maturity for the payment stream in paym.
*               The simple yield is valid in the last payment period.
*               The duration is here interpreted as the present value
*               weighted sum of terms.
*
*    input      FL64      ytm  Yield to maturity of the bond (percent)
*               INTI      basis Quoting basis of the yield (ytm).
*                              (if ytm is compounded).
*               PMT_STR * paym Reference to structure of payments
*                              The terms part of paym contains the
*                              terms for the payments in fractions of
*                              years.
*
*    output
*
*    returns    The duration of the cashflow (in years)
*
*    diagnostics
*
*    see also   tvm_price2compoundsimple()
*
************************************************************************/


FL64    TVM_CompoundSimple2Duration(FL64   ytm,
                                    INTI      basis,
                                    PMT_STR*    paym)
{
    INTI    count ;

    count = paym->count ;

    if (count == 1)
        return TVM_Simple2Duration(ytm, paym) ;
    else
        return TVM_Compound2Duration(ytm, basis, paym) ;
}


/************************************************************************
*
*               TVM_CompoundSimpleOdd2Duration()
*
*    interface  #include <tvm.h>
*               FL64 TVM_CompoundSimpleOdd2Duration(FL64     ytm,
*                                                   INTI     basis,
*                                                   PMT_STR *  paym) ;
*
*    general    TVM_CompoundSimpleOdd2Duration() calculates duration
*               as a function of compounded yield/simple
*               to maturity for the payment stream in paym.
*               The simple yield is valid in the last year of the
*               cashflow.
*               The duration is here interpreted as the present value
*               weighted sum of terms.
*
*    input      FL64      ytm   Yield to maturity of the bond (percent)
*               INTI      basis Quoting basis of the yield (ytm).
*                               (if ytm is compounded).
*               PMT_STR * paym  Reference to structure of payments
*                               The terms part of paym contains the
*                               terms for the payments in fractions of
*                               years.
*
*    output
*
*    returns    The duration of the cashflow (in years)
*
*    diagnostics
*
*    see also   TVM_CompoundSimpleOdd2Price()
*
************************************************************************/

FL64    TVM_CompoundSimpleOdd2Duration(FL64      ytm,
                                          INTI      basis,
                                          PMT_STR*  paym)
{
    INTI    count ;
    FL64    *term ;

    count = paym->count ;
    term  = paym->term ;

    if (count > 0 && term[count - 1] <= 1.0)
        return TVM_Simple2Duration(ytm, paym) ;
    else
        return TVM_Compound2Duration(ytm, basis, paym) ;
}

/************************************************************************
*
*               TVM_Braessfangmeyer2Duration()
*
*    interface  #include <tvm.h>
*
*               FL64    TVM_Braessfangmeyer2Duration(FL64    ytm,
*                                                    PMT_STR *  paym) ;
*
*    general    TVM_Braessfangmeyer2Duration() calculates
*               duration as a function of Braess Fangmeyer
*               yield for the payment stream in paym.
*               The duration is here interpreted as the present value
*               weighted sum of terms.
*
*    input      FL64      ytm   BraessFangmeyer yield to maturity of
*                               the bond (in percent)
*               PMT_STR *   paym  Reference to structure of payments
*
*    output
*
*    returns    The duration of the cashflow (in years)
*
*    diagnostics
*
*    see also   tvm_price2braessfangmeyer()
*
************************************************************************/


FL64    TVM_Braessfangmeyer2Duration(FL64   ytm,
                                     PMT_STR*    paym)
{
    INTI    i, count ;
    FL64    matur, dur, p, pv;
    FL64    *term, *payment ;

    term    = paym->term ;
    payment = paym->payment ;
    count   = paym->count ;
    matur   = term[count - 1] ;

    for (p = dur = 0.0, i = 0 ; i < count ; i++)
    {
/*
        tmp  = TVMunit_Braessfangmeyer(ytm, matur - term[i]) ;
        pv   = payment[i] * TVMunit_Braessfangmeyer(ytm, matur) / tmp ;
*/
        pv   = payment[i] * TVMunit_Braessfangmeyer(ytm, term[i], matur) ;
        p   += pv;
        dur += term[i] * pv ;
    }

    return (p ? dur/p : 0.0) ;
}


/*
..
*/


FL64 TVM_Simplerepo2Duration(FL64   ytm,
                             PMT_STR*    paym)
{
    INTI    i, count ;
    FL64    matur, dur, p, pv;
    FL64    *term, *payment ;

    term    = paym->term ;
    payment = paym->payment ;
    count   = paym->count ;
    matur   = term[count - 1] ;

    for (p = dur = 0.0, i = 0 ; i < count ; i++)
    {
        pv   = payment[i] * TVMunit_Simplerepo(ytm, term[i], matur) ;
        p   += pv;
        dur += term[i] * pv ;
    }

    return (p ? dur/p : 0.0) ;
}


/************************************************************************
*
*               TVM_Moosmuller2Duration()
*
*    interface  #include <tvm.h>
*
*               FL64    TVM_Moosmuller2Duration(FL64    ytm,
*                                               INTI  basis,
*                                               PMT_STR *paym);
*
*    general    TVM_Moosmuller2Duration() calculates
*               duration as a function of Moosmuller
*               yield to maturity for the payment stream in paym.
*               The duration is here interpreted as the present value
*               weighted sum of terms.
*
*    input      FL64      ytm   Annual Moosmuller yield to maturity of
*                               the bond (in percent).
*               INTI      basis Quoting basis of the yield (ytm).
*               PMT_STR   *paym Structure of payments from bond
*                               The terms part of paym contains the
*                               terms for the payments in fractions of
*                               years.
*
*    output
*
*    returns    The duration of the cashflow (in years)
*
*    diagnostics
*
*    see also   tvm_price2moosmuller()
*
************************************************************************/


FL64    TVM_Moosmuller2Duration(FL64   ytm,
                                INTI      basis,
                                PMT_STR*    paym)
{
    INTI    i, count ;
    FL64    dur, p, pv;
    FL64    *term, *payment ;

    term    = paym->term ;
    payment = paym->payment ;
    count   = paym->count ;

    for (p = dur = 0.0, i = 0 ; i < count ; i++)
    {
      if (i == 0)
        pv   = payment[i] * tvmunit_moosmuller(ytm, term[i], 0, basis) ;
      else
        pv   = payment[i] * 
          tvmunit_moosmuller(ytm, term[i], term[i] - term[i-1], basis) ;
      p   += pv;
      dur += term[i] * pv ;
    }

    return (p ? dur/p : 0.0) ;
}



/************************************************************************
*
*               TVM_Mair2Duration()
*
*    interface  #include <tvm.h>
*
*               FL64    TVM_Mair2Duration(FL64    ytm,
*                                         FL64ARRAY rerate,
*                                         PMT_STR *paym) ;
*
*    general    TVM_Mair2Duration() calculates
*               duration as a function of Mair
*               yield to maturity for the payment stream in paym.
*               The duration is here interpreted as the present value
*               weighted sum of terms.
*
*    input      FL64      ytm   Annual Mair yield to maturity of
*                               the bond (in percent).
*               FL64ARRAY rerate Array of reinvestment rates. Allocated
*                               with paym->count
*                               entries with Alloc_FL64ARRAY(). The rates (%)
*                               corresponds to the terms in paym.
*               PMT_STR   *paym Structure of payments from bond
*                               The terms part of paym contains the
*                               terms for the payments in fractions of
*                               years.
*
*    output
*
*    returns    The duration of the cashflow (in years)
*
*    diagnostics
*
*    see also   tvm_price2mair()
*
************************************************************************/


FL64    TVM_Mair2Duration(FL64   ytm,
                          FL64ARRAY rerate,
                          PMT_STR*    paym)
{
    INTI    i, count ;
    FL64    matur, dur, p, pv;
    FL64    *term, *payment ;

    term    = paym->term ;
    payment = paym->payment ;
    count   = paym->count ;
    matur   = term[count - 1] ;

    for (p = dur = 0.0, i = 0 ; i < count ; i++)
    {
        pv   = payment[i] * TVMunit_Mair(ytm, term[i], rerate[i], matur) ;
        p   += pv;
        dur += term[i] * pv ;
    }

    return (p ? dur/p : 0.0) ;
}


/*,,SOH,,
*************************************************************************
*
*               TVM_Zero2Duration()
*
*    interface  #include <tvm.h>
*               FL64 TVM_Zero2Duration(TS_STR     *ts,
*                                      FL64       spread,
*                                      INTPOLCONV iconv,
*                                      PMT_STR    *paym) ;
*
*    general    TVM_Zero2Duration() calculates the Fisher-Weill
*               duration as a function of the term structure for
*               the payment stream in paym.
*               The duration is here interpreted as the present value
*               weighted sum of terms.
*
*    input      TS_STR     *ts    Term structure for discounting.
*                                 The rates of ts are annual in percent
*                                 and quoted according to the qbas and
*                                 conv elements of ts.
*                                 The terms are in fractional years.
*
*               FL64       spread Interest rate spread relative to ts.
*                                 Anuual rate in percent quoted as ts.
*
*               INTPOLCONV iconv  Interpolation convention used for
*                                 setting up discounting rates.
*
*               PMT_STR    *paym  Structure of payments from bond.
*                                 The terms part of paym contains the
*                                 terms for the payments in fractions
*                                 of years.
*                                 The payments should not include any
*                                 accrued interest at the valuation day,
*                                 since the function calculates the
*                                 dirty price from the flow.
*
*    output
*
*    returns    the duration of the cashflow in years.
*
*    diagnostics
*
*    see also   TVM_Zero2Price()
*               TVM_Yield2Duration()
*
*    wrapper    AP
*
*************************************************************************
,,EOH,,*/


FL64    TVM_Zero2Duration(TS_STR* ts, FL64    spread, INTPOLCONV iconv,
                          PMT_STR*   paym)
{
    FL64    pv, p, dur, lastterm ;
    INTI    i, count, qbas ;
    TSARRAY ts1 ;
    IRRCONV irr ;
    FL64    *rate, *term, *payment ;

    count   = paym->count ;

    ts1 = Yld_GetRates(ts, paym->term, count, iconv) ;

    rate    = ts1->rate ;
    term    = paym->term ;
    payment = paym->payment ;

    irr     = ts1->conv ;
    qbas    = ts1->qbas ;

    if (count > 0 && irr == COMPOUNDSIMPLE_ODD)
    {
        lastterm = term[count-1] ;

        /* Simple compounding is only applicable for cashflows of one year
           and less:                                                        */
        if (lastterm <= 1.0)
            irr = SIMPLE_MM ;
        else
            irr = COMPOUND ;
    }

    if (irr == COMPOUNDSIMPLE && count == 1)
        irr = SIMPLE_MM ;
    else if (irr == COMPOUNDSIMPLE && count > 1)
        irr = COMPOUND ;

    for (dur = p = 0.0, i = 0 ; i < count ; i++)
    {
        pv   = payment[i] * TVMunit_NPV(term[i], rate[i] + spread, irr, qbas);
        p   += pv ;
        dur += pv * term[i] ;
    }

    Free_TSARRAY(ts1, 1) ;

    return (p ? dur / p : 0.0) ;
}


/*,,SOH,,
*************************************************************************
*
*               TVM_RemainingLife()
*
*   interface   #include <tvm.h>
*               FL64 TVM_RemainingLife(FL64ARRAY terms,
*                                       INTI      n) ;
*
*   general     The function calculates the remaining life of a bond
*               in fractional periods.
*
*   input       FL64ARRAY terms  Reference to terms in fractional
*                                periods of payments from a bond.
*
*               INTI     n       The number of elements in terms.
*
*   output
*
*   returns     the remaining life.
*
*   diagnostics
*
*   see also    TVM_AvgRemainingLife()
*
*************************************************************************
,,EOH,,*/


FL64    TVM_RemainingLife(FL64ARRAY terms, INTI  n)
{
    FL64 res ;

    if (n > 0)
        res = terms[n - 1] ;
    else
        res = 0.0 ;

    return res ;
}


/*,,SOH,,
*************************************************************************
*
*               TVM_AvgRemainingLife()
*
*   interface   #include <tvm.h>
*               FL64 TVM_AvgRemainingLife(FL64ARRAY amort,
*                                           FL64ARRAY terms,
*                                           INTI      n) ;
*
*   general     The function calculates the average remaining life in
*               fractional periods for a given payment stream.
*
*   input       FL64ARRAY amort  Reference to amortizations of the
*                                flow.
*
*               FL64ARRAY terms  Reference to terms for the cashflow.
*
*               INTI     n       The number of elements in terms and
*                                amort.
*
*   output
*
*   returns     the average remaining life.
*
*   diagnostics
*
*   see also    TVM_RemainingLife()
*
*************************************************************************
,,EOH,,*/


FL64    TVM_AvgRemainingLife(FL64ARRAY amort, FL64ARRAY terms, INTI  n)
{
    return Math_WeightedAvg(n, terms, amort) ;
}


/*,,SOH,,
*************************************************************************
*
*               TVM_Zero2Theta()
*
*    interface  #include <tvm.h>
*               FL64 TVM_Zero2Theta(TS_STR     *ts,
*                                   FL64       spread,
*                                   INTPOLCONV iconv,
*                                   PMT_STR    *paym,
*                                   FL64       debt,
*                                   FL64       dirty,
*                                   FL64       time) ;
*
*    general    TVM_Zero2Theta() calculates the theta as function of
*               the term structure for the payment stream in paym.
*
*               The theta is here calculated by shocking the terms in
*               pmt a period of time and then recalculating the dirty
*               price.
*
*               The theta can be interpreted as the continuously
*               compounded return or time value, if you please.
*
*               Note that if you choose a shock, time, that is larger
*               than the period till next ex coupon, ex principal or
*               next payment this in NOT accounted for, since relevant
*               information not available.
*               So if you want to use large time values you might have
*               to calculate theta in your own code.
*               On the other hand it is recommendable to use small
*               time shocks, say less than a day, since this is a good
*               approximation to the continuously compounded return,
*               which is probably what you want.
*
*    input      TS_STR     *ts    Term structure for discounting.
*                                 The rates are annual in percent and
*                                 quoted as the qbas and conv elements
*                                 of ts indicate.
*                                 The interest rate convention of ts
*                                 must be one of:
*
*                                     COMPOUND
*                                     CONTINUOUS
*                                     SIMPLE_MM
*                                     COMPOUNDSIMPLE
*                                     COMPOUNDSIMPLE_ODD
*                                     MOOSMULLER
*                                     BRAESSFANGMEYER
*                                     DISCOUNT
*
*                                 The terms element of ts is measured
*                                 in fractional years.
*
*               FL64       spread Interest rate spread relative to ts
*                                 annual rate in percent quoted as ts.
*
*               INTPOLCONV iconv  Interpolation convention used for
*                                 term structure interpolation.
*
*               PMT_STR    *paym  Structure of payments from the bond.
*                                 The terms part of paym contains the
*                                 terms for the payments in fractions
*                                 of years.
*                                 The payments should not include any
*                                 accrued interest at the valuation day,
*                                 since the function calculates the
*                                 dirty price from the flow.
*
*               FL64       debt   The outstanding debt per initial 100.
*
*               FL64       dirty  The dirty price at term zero, ie. the
*                                 net present value of the cashflow.
*
*               FL64       time   The time passed in evaluating theta,
*                                 or rather the shock size. Must be a
*                                 positive number.
*
*    output
*
*    returns    the theta in percent per year.
*
*    diagnostics
*
*    see also   TVM_Zero2Duration()
*               TVM_Zero2Price()
*
*************************************************************************
,,EOH,,*/


FL64    TVM_Zero2Theta(TS_STR* ts, FL64    spread, INTPOLCONV iconv,
                       PMT_STR*   paym, FL64    debt, FL64    dirty,
                       FL64    time)
{
    FL64    *t, dirty1, dp, ddp ;
    INTI    uploop, i ;

    t      = paym->term ;
    uploop = paym->count;

    /* Shock the terms for the cashflow */
    for (i = 0 ; i < uploop ; i++)
        t[i] -= time ;

    dirty1 = TVM_Zero2Price(ts, ZERO_ORDER, debt, spread,
                            iconv, paym, &dp, &ddp) ;

    /* Reset the terms */
    for (i = 0 ; i < uploop ; i++)
        t[i] += time ;

    return (dirty1 - dirty)/time ;
}


/*,,SOH,,
*************************************************************************
*
*               TVM_Yield2Theta()
*
*    interface  #include <tvm.h>
*               FL64 TVM_Yield2Theta(FL64      ytm,
*                                    INTI      qb,
*                                    IRRCONV   irr,
*                                    FL64ARRAY g,
*                                    PMT_STR   *paym,
*                                    FL64      debt,
*                                    FL64      dirty,
*                                    FL64      time) ;
*
*    general    TVM_Yield2Theta() calculates theta as a function
*               of yield to maturity for the payment stream in paym
*               using the required interest rate convention.
*
*               The theta is here calculated by shocking the terms in
*               pmt a period of time and then recalculating the dirty
*               price.
*
*               The theta can be interpreted as the continuously
*               compounded return - or time value, if you please.
*
*               Note that if you choose a shock (time) that is larger
*               than the period till next ex coupon, ex principal or
*               next payment this in NOT accounted for, since relevant
*               information is not available.
*               So if you want to use large time values you might have
*               to calculate theta in your own code.
*               code.
*               On the other hand it is recommendable to use small
*               time shocks, say less than a day, since this is a good
*               approximation to the continuously compounded return
*               which is probably what you want.
*
*    input      FL64      ytm   Yield to maturity of the bond in
*                               percent.
*
*               INTI      qb    Quoting basis of the yield.
*
*               IRRCONV   irr   The interest rate convention of the
*                               yield.
*
*               FL64ARRAY g     Array of reinvestment rates in percent.
*                               Allocated with as many entries as
*                               paym->count
*                               The rates must correspond to the terms
*                               in paym. Only used is irr is MAIR.
*
*               PMT_STR   *paym Reference to structure of payments
*                               The terms part of paym contains the
*                               terms for the payments in fractional
*                               years.
*                               The payments should not include any
*                               accrued interest at the valuation day,
*                               since the function calculates the
*                               dirty price from the flow.
*
*               FL64      debt  The outstanding debt per initial 100.
*
*               FL64      dirty The dirty price at term zero, ie. the
*                               net present value of the cash flow.
*
*               FL64      time  The time passed in evaluating theta,
*                               or rather the shock size. Must be a
*                               positive number.
*
*    output
*
*    returns    the theta of the cashflow in percent per year.
*
*    diagnostics
*
*    see also   TVM_Zero2Theta()
*
*************************************************************************
,,EOH,,*/


FL64    TVM_Yield2Theta(FL64 ytm, INTI  qb, IRRCONV irr, FL64ARRAY g,
                        PMT_STR*   paym, FL64    debt, FL64    dirty,
                        FL64    time)
{
    FL64    *t, dirty1, dp, ddp ;
    INTI    i, uploop ;

    t      = paym->term ;
    uploop = paym->count;

    /* Shock the terms for the cashflow */
    for (i = 0 ; i < uploop ; i++)
        t[i] -= time ;

    dirty1 = TVM_Yield2Price(ytm, ZERO_ORDER, qb, debt, irr,
                             g, paym, &dp, &ddp) ;

    /* Reset the terms */
    for (i = 0 ; i < uploop ; i++)
        t[i] += time ;

    return (dirty1 - dirty)/time ;
}

/* SCID @(#)testcldr.c	1.10 (SimCorp) 99/02/19 14:16:55 */

/************************************************************************
*
*   project     SCecon
*
*   this program tests the routines in the calendar module of SCecon
*
************************************************************************/

/*** includes ***********************************************************/
#include <string.h>
#include <cldr.h>
#include <scalloc.h>
#include <str2conv.h>
#include <ioconv.h>

/*** prototyping  *******************************************************/

INTI cldrtest(char* txa, FILE* in, FILE* out)
{
    char      txb[25], txpl[80] ;
    INTL      ds1, jul, lexp, lres ;
    CALCONV   cal ;
    EOMCONV   eom ;
    INTI      ms, w, diff, diff1, i, dexp, dres;
    INTI      y, m, gridstep, ndates, n, ymd1, ymd2, n1 ;
    DATESTR   dateres, dateinput1, dateinput2, first, last, datex ;
    DATEARRAY dates, expdates, holidays;
    YYYYMMDD  yyyymmdd1, yyyymmdd2, ymd ;
    HOLI_STR  holi;
    int       i1, i2, i3 ;
    INTLARRAY il ;
    BOOLE     pseudo, weekend ;
    HOLIRULEARRAY rules ;

    diff = -1 ;

    if (!strcmp("Cldr_AddDays()", txa))
    {
        fscanf(in, "%ld %ld %ld %s %s", &lexp, &yyyymmdd1, &ds1, txb, txpl);
        cal = Str2CALCONV(txb) ;
        dateinput1 = Cldr_YMD2Datestr(yyyymmdd1);
        dateres = Cldr_AddDays(&dateinput1, ds1, cal, &holi);   	/* PMSTA-22396 - SRIDHARA � 160502 */
        lres = Cldr_Datestr2YMD(&dateres);
        diff = (lres != lexp);

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   date %8ld\n", yyyymmdd1) ;
        fprintf(out,"   days %8ld\n", ds1) ;
        fprintf(out,"   cal  %8s\n", txb) ;
        fprintf(out,"   result is %8ld ; expected is %8ld\n", lres, lexp) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }

    else if (!strcmp("Cldr_DaysBetweenDates()", txa))
    {
        fscanf(in, "%ld %ld %ld %s %s", &lexp, &yyyymmdd1, &yyyymmdd2, txb,
                                                                      txpl);
        cal = Str2CALCONV(txb) ;
        dateinput1 = Cldr_YMD2Datestr(yyyymmdd1);
        dateinput2 = Cldr_YMD2Datestr(yyyymmdd2);

        lres = Cldr_DaysBetweenDates(&dateinput1, &dateinput2, cal, &holi);   	/* PMSTA-22396 - SRIDHARA � 160502 */
        diff = (lres != lexp);

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   start date %8ld\n", yyyymmdd1) ;
        fprintf(out,"   end   date %8ld\n", yyyymmdd2) ;
        fprintf(out,"   cal        %8s\n", txb) ;
        fprintf(out,"   result is %8ld ; expected is %8ld\n", lres, lexp) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }

    else if (!strcmp("Cldr_DaysBetweenDatesArray()", txa))
    {
        fscanf(in, "%ld %ld %ld %s %s", &lexp, &yyyymmdd1, &yyyymmdd2, txb,
                                                                      txpl);
        cal = Str2CALCONV(txb) ;
        dateinput1 = Cldr_YMD2Datestr(yyyymmdd1);
        dateinput2 = Cldr_YMD2Datestr(yyyymmdd2);

        il = Cldr_DaysBetweenDatesArray(&dateinput1, &dateinput2, 1, cal, &holi);   	/* PMSTA-22396 - SRIDHARA � 160502 */
        lres = il[0];
        diff = (il[0] != lexp);

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   start date %8ld\n", yyyymmdd1) ;
        fprintf(out,"   end   date %8ld\n", yyyymmdd2) ;
        fprintf(out,"   cal        %8s\n", txb) ;
        fprintf(out,"   result is %8ld ; expected is %8ld\n", lres, lexp) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_INTLARRAY(il) ;
    }

    else if (!strcmp("Cldr_29FebCount()", txa))
    {
        fscanf(in, "%d %ld %ld %s", &dexp, &yyyymmdd1, &yyyymmdd2, txpl) ;
        dateinput1 = Cldr_YMD2Datestr(yyyymmdd1);
        dateinput2 = Cldr_YMD2Datestr(yyyymmdd2);
        dres = Cldr_29FebCount(&dateinput1, &dateinput2);
        diff = (dres != dexp);

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   start date %8ld\n", yyyymmdd1) ;
        fprintf(out,"   end   date %8ld\n", yyyymmdd2) ;
        fprintf(out,"   result is %d ; expected is %d\n", dres, dexp) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }

    else if (!strcmp(txa, "Cldr_IsLeap()"))
    {
        fscanf(in, "%d %d %s", &i1, &i2, txpl);
        dexp = (INTI) i1 ;
        y = (INTI) i2 ;

        dres = Cldr_IsLeap(y);
        diff = (dres != dexp);

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   input year %8ld\n", y) ;
        fprintf(out,"   result is %2d ; expected is %2d\n", dres, dexp) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }

    else if (!strcmp(txa, "Cldr_Date2md()"))
    {
        fscanf(in, "%d %ld %s", &i1, &ymd, txpl);
        dexp = (INTI) i1 ;
        dateres = Cldr_YMD2Datestr(ymd) ;
        dres = Cldr_Date2md(&dateres);
        diff = (dres != dexp);

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   input date %8ld\n", ymd) ;
        fprintf(out,"   result is %4d ; expected is %4d\n", dres, dexp) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }

    else if (!strcmp(txa, "Cldr_DateEQ()"))
    {
        fscanf(in, "%d %ld %ld %s", &i1, &yyyymmdd1, &yyyymmdd2, txpl);
        dexp = (INTI) i1 ;
        dateinput1 = Cldr_YMD2Datestr(yyyymmdd1);
        dateinput2 = Cldr_YMD2Datestr(yyyymmdd2);
        dres = (INTI ) Cldr_DateEQ(&dateinput1, &dateinput2);
        diff = (dres != dexp);

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   first  date %8ld\n", yyyymmdd1) ;
        fprintf(out,"   second date %8ld\n", yyyymmdd2) ;
        fprintf(out,"   result is %4d ; expected is %4d\n", dres, dexp) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }

    else if(!strcmp(txa, "Cldr_DateLT()"))
    {
        fscanf(in, "%d %ld %ld %s", &i1, &yyyymmdd1, &yyyymmdd2, txpl);
        dexp = (INTI) i1 ;
        dateinput1 = Cldr_YMD2Datestr(yyyymmdd1);
        dateinput2 = Cldr_YMD2Datestr(yyyymmdd2);
        dres = (INTI ) Cldr_DateLT(&dateinput1, &dateinput2);
        diff = (dres != dexp);

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   first  date %8ld\n", yyyymmdd1) ;
        fprintf(out,"   second date %8ld\n", yyyymmdd2) ;
        fprintf(out,"   result is %4d ; expected is %4d\n", dres, dexp) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }

    else if (!strcmp(txa, "Cldr_DateLE()"))
    {
        fscanf(in, "%d %ld %ld %s", &i1, &yyyymmdd1, &yyyymmdd2, txpl);
        dexp = (INTI) i1 ;
        dateinput1 = Cldr_YMD2Datestr(yyyymmdd1);
        dateinput2 = Cldr_YMD2Datestr(yyyymmdd2);
        dres = (INTI ) Cldr_DateLE(&dateinput1, &dateinput2);
        diff = (dres != dexp);

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   first  date %8ld\n", yyyymmdd1) ;
        fprintf(out,"   second date %8ld\n", yyyymmdd2) ;
        fprintf(out,"   result is %4d ; expected is %4d\n", dres, dexp) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }

    else if (!strcmp(txa, "Cldr_Date2Julian()"))
    {
        fscanf(in, "%ld %ld %s", &lexp, &yyyymmdd1, txpl);
        dateinput1 = Cldr_YMD2Datestr(yyyymmdd1);
        lres = Cldr_Date2Julian(&dateinput1);
        diff = (lres != lexp);

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   input date %8ld\n", yyyymmdd1) ;
        fprintf(out,"   result is %8ld ; expected is %8ld\n", lres, lexp) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }

    else if (!strcmp(txa, "Cldr_Julian2Date()"))
    {
        fscanf(in, "%ld %ld %s", &lexp, &jul, txpl);
        dateres = Cldr_Julian2Date(jul);
        lres = Cldr_Datestr2YMD(&dateres);
        diff = (lres != lexp);

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   julian date %8ld\n", jul) ;
        fprintf(out,"   result is %8ld ; expected is %8ld\n", lres, lexp) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }

    else if (!strcmp(txa, "Cldr_CheckDate()"))
    {
        fscanf(in, "%d %ld %s", &i1, &yyyymmdd1, txpl);
        dexp = (INTI) i1 ;
        dateinput1 = Cldr_YMD2Datestr(yyyymmdd1);
        dres = Cldr_CheckDate(&dateinput1);
        diff = (dres != dexp);

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   input date %8ld\n", yyyymmdd1) ;
        fprintf(out,"   result is %2d ; expected is %2d\n", dres, dexp) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }

    else if (!strcmp(txa, "Cldr_LastDayInMonth()"))
    {
        fscanf(in, "%d %d %d %s", &i1, &i2, &i3, txpl);
        dexp =(INTI) i1 ;
        y    =(INTI) i2 ;
        m    =(INTI) i3 ;
        dres = Cldr_LastDayInMonth(y, m);
        diff = (dres != dexp);

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   input year  %4d\n", y) ;
        fprintf(out,"   input month %4d\n", m) ;
        fprintf(out,"   result is %2d ; expected is %2d\n", dres, dexp) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }

    else if (!strcmp(txa, "Cldr_Weekday()"))
    {
        fscanf(in, "%d %ld %s", &i1, &yyyymmdd1, txpl);
        dexp = (INTI) i1 ;
        dateinput1 = Cldr_YMD2Datestr(yyyymmdd1);
        dres = Cldr_Weekday(&dateinput1);
        diff = (dres != dexp);

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   input date %8ld\n", yyyymmdd1) ;
        fprintf(out,"   result is %2d ; expected is %2d\n", dres, dexp) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }

    else if (!strcmp(txa, "Cldr_WeekNumber()"))
    {
        fscanf(in, "%d %ld %s", &i1, &yyyymmdd1, txpl);
        dexp = (INTI) i1 ;
        dateinput1 = Cldr_YMD2Datestr(yyyymmdd1);
        dres = Cldr_WeekNumber(&dateinput1);
        diff = (dres != dexp);

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   input date %8ld\n", yyyymmdd1) ;
        fprintf(out,"   result is %2d ; expected is %2d\n", dres, dexp) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }

    else if (!strcmp(txa, "Cldr_NextWeekday()"))
    {
        fscanf(in, "%ld %ld %d %s", &lexp, &yyyymmdd1, &i1, txpl);
        w = (INTI) i1 ;
        dateinput1 = Cldr_YMD2Datestr(yyyymmdd1);
        dateres = Cldr_NextWeekday(&dateinput1, w);
        lres = Cldr_Datestr2YMD(&dateres);
        diff = (lres != lexp);

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   input date    %8ld\n", yyyymmdd1) ;
        fprintf(out,"   weekdaynumber %8d\n", w) ;
        fprintf(out,"   result is %8ld ; expected is %8ld\n", lres, lexp) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }

    else if (!strcmp(txa, "Cldr_NextIMM()"))
    {
        fscanf(in, "%ld %ld %s %s", &lexp, &yyyymmdd1, txb, txpl);
        dateinput1 = Cldr_YMD2Datestr(yyyymmdd1);
        pseudo = Str2BOOLE(txb) ;
        dateres = Cldr_NextIMM(&dateinput1, pseudo) ;
        lres = Cldr_Datestr2YMD(&dateres);
        diff = (lres != lexp);

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   input date %8ld\n", yyyymmdd1) ;
        fprintf(out,"   realIMM ?  %8s\n", txb) ;
        fprintf(out,"   result is %8ld ; expected is %8ld\n", lres, lexp) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }

    else if (!strcmp(txa, "Cldr_DateIsIMM()"))
    {
        fscanf(in, "%d %ld %s %s", &i1, &yyyymmdd1, txb, txpl);
        dexp = (INTI) i1 ;
        pseudo = Str2BOOLE(txb) ;
        dateinput1 = Cldr_YMD2Datestr(yyyymmdd1);
        dres = Cldr_DateIsIMM(&dateinput1, pseudo) ;
        diff = (dres != dexp);

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   input date %8ld\n", yyyymmdd1) ;
        fprintf(out,"   realCAD_BA ?  %8s\n", txb) ;
        fprintf(out,"   result is %2d ; expected is %2d\n", dres, dexp) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }

    else if (!strcmp(txa, "Cldr_NextCAD_BA()"))
    {
        fscanf(in, "%ld %ld %s %s", &lexp, &yyyymmdd1, txb, txpl);
        dateinput1 = Cldr_YMD2Datestr(yyyymmdd1);
        pseudo = Str2BOOLE(txb) ;
        dateres = Cldr_NextCAD_BA(&dateinput1, pseudo) ;
        lres = Cldr_Datestr2YMD(&dateres);
        diff = (lres != lexp);

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   input date %8ld\n", yyyymmdd1) ;
        fprintf(out,"   realIMM ?  %8s\n", txb) ;
        fprintf(out,"   result is %8ld ; expected is %8ld\n", lres, lexp) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }

    else if (!strcmp(txa, "Cldr_DateIsCAD_BA()"))
    {
        fscanf(in, "%d %ld %s %s", &i1, &yyyymmdd1, txb, txpl);
        dexp = (INTI) i1 ;
        pseudo = Str2BOOLE(txb) ;
        dateinput1 = Cldr_YMD2Datestr(yyyymmdd1);
        dres = Cldr_DateIsCAD_BA(&dateinput1, pseudo) ;
        diff = (dres != dexp);

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   input date %8ld\n", yyyymmdd1) ;
        fprintf(out,"   realCAD_BA ?  %8s\n", txb) ;
        fprintf(out,"   result is %2d ; expected is %2d\n", dres, dexp) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }

    else if (!strcmp(txa, "Cldr_NextIMM_ZAR()"))
    {
        fscanf(in, "%ld %ld %s %s", &lexp, &yyyymmdd1, txb, txpl);
        dateinput1 = Cldr_YMD2Datestr(yyyymmdd1);
        pseudo = Str2BOOLE(txb) ;
        dateres = Cldr_NextIMM_ZAR(&dateinput1, pseudo) ;
        lres = Cldr_Datestr2YMD(&dateres);
        diff = (lres != lexp);

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   input date %8ld\n", yyyymmdd1) ;
        fprintf(out,"   realIMM ?  %8s\n", txb) ;
        fprintf(out,"   result is %8ld ; expected is %8ld\n", lres, lexp) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }

    else if (!strcmp(txa, "Cldr_DateIsIMM_ZAR()"))
    {
        fscanf(in, "%d %ld %s %s", &i1, &yyyymmdd1, txb, txpl);
        dexp = (INTI) i1 ;
        pseudo = Str2BOOLE(txb) ;
        dateinput1 = Cldr_YMD2Datestr(yyyymmdd1);
        dres = Cldr_DateIsIMM_ZAR(&dateinput1, pseudo) ;
        diff = (dres != dexp);

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   input date %8ld\n", yyyymmdd1) ;
        fprintf(out,"   realIMM_ZAR?  %8s\n", txb) ;
        fprintf(out,"   result is %2d ; expected is %2d\n", dres, dexp) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }

    else if (!strcmp(txa, "Cldr_AddMonths()"))
    {
        fscanf(in, "%ld %ld %d %s %s", &lexp, &yyyymmdd1, &i1, txb, txpl);
        ms = (INTI) i1 ;
        eom = Str2EOMCONV(txb) ;
        dateinput1 = Cldr_YMD2Datestr(yyyymmdd1);
        dateres = Cldr_AddMonths(&dateinput1, ms, eom);
        lres = Cldr_Datestr2YMD(&dateres);
        diff = (lres != lexp);

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   date   %8ld\n", yyyymmdd1) ;
        fprintf(out,"   months %8ld\n", (long) ms) ;
        fprintf(out,"   eom    %8s\n", txb) ;
        fprintf(out,"   result is %8ld ; expected is %8ld\n", lres, lexp) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }
    else if (!strcmp(txa, "Cldr_FindNextTerm()"))
    {
        fscanf(in, "%ld %ld %ld %d %s %s", &lexp, &yyyymmdd1, &yyyymmdd2,
                                           &i1, txb, txpl);
        ms = (INTI) i1 ;
        eom = Str2EOMCONV(txb) ;
        dateinput1 = Cldr_YMD2Datestr(yyyymmdd1);
        dateinput2 = Cldr_YMD2Datestr(yyyymmdd2);
        dateres = Cldr_FindNextTerm(&dateinput1, &dateinput2, ms, eom);
        lres = Cldr_Datestr2YMD(&dateres);
        diff = (lres != lexp);

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   today  %8ld\n", yyyymmdd1) ;
        fprintf(out,"   payday %8ld\n", yyyymmdd2) ;
        fprintf(out,"   months %8ld\n", (long) ms) ;
        fprintf(out,"   eom    %8s\n", txb) ;
        fprintf(out,"   result is %8ld ; expected is %8ld\n", lres, lexp) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }
    else if (!strcmp(txa, "Cldr_FindPrevTerm()"))
    {
        fscanf(in, "%ld %ld %ld %d %s %s", &lexp, &yyyymmdd1, &yyyymmdd2,
                                           &i1, txb, txpl);
        ms = (INTI) i1 ;
        eom = Str2EOMCONV(txb) ;
        dateinput1 = Cldr_YMD2Datestr(yyyymmdd1);
        dateinput2 = Cldr_YMD2Datestr(yyyymmdd2);
        dateres = Cldr_FindPrevTerm(&dateinput1, &dateinput2, ms, eom);
        lres = Cldr_Datestr2YMD(&dateres);
        diff = (lres != lexp);

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   today  %8ld\n", yyyymmdd1) ;
        fprintf(out,"   payday %8ld\n", yyyymmdd2) ;
        fprintf(out,"   months %8ld\n", (long) ms) ;
        fprintf(out,"   eom    %8s\n", txb) ;
        fprintf(out,"   result is %8ld ; expected is %8ld\n", lres, lexp) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }
    else if (!strcmp(txa, "Cldr_EasterSunday()"))
    {
        fscanf(in, "%ld %d %s", &lexp, &i1, txpl);
        ms = (INTI) i1 ;
        dateres = Cldr_EasterSunday(ms);
        lres = Cldr_Datestr2YMD(&dateres);
        diff = (lres != lexp);

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   year      %8d\n", ms) ;
        fprintf(out,"   result is %8ld ; expected is %8ld\n", lres, lexp) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }
    else if (!strcmp(txa, "Cldr_Advent()"))
    {
        fscanf(in, "%ld %d %s", &lexp, &i1, txpl);
        ms = (INTI) i1 ;
        dateres = Cldr_Advent(ms);
        lres = Cldr_Datestr2YMD(&dateres);
        diff = (lres != lexp);

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   year      %8d\n", ms) ;
        fprintf(out,"   result is %8ld ; expected is %8ld\n", lres, lexp) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }

    else if (!strcmp(txa, "Cldr_FindDelvDays()"))
    {
        fprintf(out,"Testing %s\n", txa) ;

        first = Read_DATESTR(in, out, "  First ");
        last = Read_DATESTR(in, out, "  Last ");
        gridstep = Read_INTI(in, out, "  Gridstep ");
        cal = Read_CALCONV(in, out, "  Cal  ");
        holi = Read_HOLI_STR(in, out);
        
        IOUtil_ParseLine(in, out);

        dates = Cldr_FindDelvDays(&first,
                             &last,
                             gridstep,
                             cal,
                             &holi,
                             &ndates);
        expdates = Read_DATEARRAY(in, out, &n);
        if (n != ndates)
        {
          fprintf(out, "1; Sizes mismatch, exp: %d, act: %d\n", n, 
              ndates);
          diff = 1;
        }
        else
        {
          diff = 0;
          for (i = 0; i < n; i++)
          {
            diff1 = (Cldr_DateEQ(&expdates[i], &dates[i]) == False);
            fprintf(out, "%d; %ld, %ld\n", diff1, 
              Cldr_Datestr2YMD(&expdates[i]),
              Cldr_Datestr2YMD(&dates[i]));
            diff = diff || diff1;
          }
        }
        Free_HOLI_STR(&holi);
        Free_DATEARRAY(dates);
        Free_DATEARRAY(expdates);
    }

    else if (!strcmp("Cldr_GenrHolidaysByRules()", txa))
    {
        diff = 0;
        fprintf(out,"?; testing %s\n", txa) ;
        ymd1 = Read_INTI(in, out, "  Start year   ");
        ymd2 = Read_INTI(in, out, "  End year   ");

        weekend = Read_BOOLE(in, out, "  Week ends   ");

        rules = Read_HOLIRULEARRAY(in, out, &n1);

        IOUtil_ParseLine(in, out);

        holidays = Cldr_GenrHolidaysByRules(ymd1, ymd2, 
            rules, n1, weekend, &n);

        Cldr_DateSort(n, holidays, ASCENDING);

        Free_HOLIRULEARRAY(rules);

        for (i = 0; i < n; i++)
        {
            fscanf(in, "%ld", &ymd);
            datex = Cldr_YMD2Datestr(ymd);
            diff1 = Cldr_DateEQ(&datex, &holidays[i]) == False;
            fprintf(out, "%d; Exp: %ld,  Act: %ld\n", diff1, ymd, 
                Cldr_Datestr2YMD(&holidays[i]));
            diff = diff || diff1;
        }

        Free_DATEARRAY(holidays) ;
    }

    return diff ;
}

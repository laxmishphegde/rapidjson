
/* SCID @(#)ioconv.c	1.29 (SimCorp) 99/08/12 14:30:33 */

/************************************************************************
*
*   Project     SCecon
*
*   file name   ioconv.c
*
*   general     This file contains file io functions for enums and
*               simple types
*
************************************************************************/

/* includes    *********************************************************/

#include <str2conv.h>
#include <ioconv.h>



/* functions   *********************************************************/

/*

  The Read functions for the following types:

  - basic types, eg. FL64 and INTI
  - DATESTR
  - enums, eg. EOMCONV

  support comments before the actual value.

*/

void Write_Comment(FILE*  out, TEXT  txt)
{
    if (txt != NULL && strlen(txt) > 0)
        fprintf(out, "* %s: ", txt);
}


void Read_TEXT(FILE* in, INTI size, TEXT txt)
{
    int ch;
    INTI i;
    
    i = 0;

    IOUtil_SkipSpace(in);

    ch = fgetc(in);
    while (!isspace(ch) && i < size)
    {
      txt[i] = (CH) ch;
      i++;
      ch = fgetc(in);
    }
    ungetc(ch, in);

    if (i < size)
      txt[i] = '\0';
}



/*
..
*/


FL64 Read_FL64(FILE* in, FILE* out, TEXT dscr)
{
    FL64 f;
    double ldf;

      /* Comments, if any: */
    if (!IOUtil_ReadComment(in, out))
        Write_Comment(out, dscr);

    fscanf(in, "%lf", &ldf);
    fprintf(out, " %lf\n", ldf);
    f = (FL64) ldf;

    return f;
}


/*
..
*/


INTI Read_INTI(FILE* in, FILE* out, TEXT dscr)
{
    INTI d;
    long ld;

      /* Comments, if any: */
    if (!IOUtil_ReadComment(in, out))
        Write_Comment(out, dscr);

    fscanf(in, "%ld", &ld);
    fprintf(out, " %ld\n", ld);

    d = (INTI) ld;
    return d;
}


/*
..
*/


INTL Read_INTL(FILE* in, FILE* out, TEXT dscr)
{
    INTL l;
    long ll;

      /* Comments, if any: */
    if (!IOUtil_ReadComment(in, out))
        Write_Comment(out, dscr);

    fscanf(in, "%ld", &ll);
    fprintf(out, " %ld\n", ll);

    l = (INTL) ll;
    return l;
}


/*
..
*/


UN32 Read_UN32(FILE* in, FILE* out, TEXT dscr)
{
    UN32 l;
    unsigned long ll;

      /* Comments, if any: */
    if (!IOUtil_ReadComment(in, out))
        Write_Comment(out, dscr);

    fscanf(in, "%lu", &ll);
    fprintf(out, " %lu\n", ll);

    l = (UN32) ll;
    return l;
}


/*
..
*/


COUNT Read_COUNT(FILE* in, FILE* out, TEXT dscr)
{
    COUNT c;
    unsigned long ulc;

      /* Comments, if any: */
    if (!IOUtil_ReadComment(in, out))
        Write_Comment(out, dscr);

    fscanf(in, "%lu", &ulc);
    fprintf(out, " %lu\n", ulc);

    c = (COUNT) ulc;
    return c;
}


/*
..
*/


DATESTR Read_DATESTR(FILE* in, FILE* out, TEXT dscr)
{
    DATESTR d, d1;
    long ymd;

    d1 = Cldr_YMD2Datestr(0);

      /* Comments, if any: */
    if (!IOUtil_ReadComment(in, out))
        Write_Comment(out, dscr);

    fscanf(in, "%ld", &ymd);
    d = Cldr_YMD2Datestr((YYYYMMDD) ymd);

    if (Cldr_CheckDate(&d) == False && 
            Cldr_IsNullDate(&d) == False)
        fprintf(out, " *2; %s%ld ---  Invalid_date\n", dscr, ymd);
    else
        fprintf(out, " %ld\n", ymd);

    return d;
}


/*
..
*/


IRRCONV Read_IRRCONV(FILE* in, FILE* out, TEXT dscr)
{
    IRRCONV irr;
    CH txb[MAX_KEYWORD_LENGTH];

      /* Comments, if any: */
    if (!IOUtil_ReadComment(in, out))
        Write_Comment(out, dscr);

    Read_TEXT(in, MAX_KEYWORD_LENGTH, txb);
    irr = Str2IRRCONV(txb);

    fprintf(out, " %s\n", txb);

    return irr;
}


/*
..
*/


PMTFREQ Read_PMTFREQ(FILE* in, FILE* out, TEXT dscr)
{
    PMTFREQ irr;
    CH txb[MAX_KEYWORD_LENGTH];

      /* Comments, if any: */
    if (!IOUtil_ReadComment(in, out))
        Write_Comment(out, dscr);

    Read_TEXT(in, MAX_KEYWORD_LENGTH, txb);
    irr = Str2PMTFREQ(txb);

    fprintf(out, " %s\n", txb);

    return irr;
}



/*
..
*/


BOOLE Read_BOOLE(FILE* in, FILE* out, TEXT dscr)
{
    BOOLE irr;
    CH txb[MAX_KEYWORD_LENGTH];

      /* Comments, if any: */
    if (!IOUtil_ReadComment(in, out))
        Write_Comment(out, dscr);

    Read_TEXT(in, MAX_KEYWORD_LENGTH, txb);
    irr = Str2BOOLE(txb);

    fprintf(out, " %s\n", txb);

    return irr;
}

/*
..
*/


EOMCONV Read_EOMCONV(FILE* in, FILE* out, TEXT dscr)
{
    EOMCONV irr;
    CH txb[MAX_KEYWORD_LENGTH];

      /* Comments, if any: */
    if (!IOUtil_ReadComment(in, out))
        Write_Comment(out, dscr);

    Read_TEXT(in, MAX_KEYWORD_LENGTH, txb);
    irr = Str2EOMCONV(txb);

    fprintf(out, " %s\n", txb);

    return irr;
}


/*
..
*/


CALCONV Read_CALCONV(FILE* in, FILE* out, TEXT dscr)
{
    CALCONV irr;
    CH txb[MAX_KEYWORD_LENGTH];

      /* Comments, if any: */
    if (!IOUtil_ReadComment(in, out))
        Write_Comment(out, dscr);

    Read_TEXT(in, MAX_KEYWORD_LENGTH, txb);
    irr = Str2CALCONV(txb);

    fprintf(out, " %s\n", txb);

    return irr;
}

/*
..
*/


BUSCONV Read_BUSCONV(FILE* in, FILE* out, TEXT dscr)
{
    BUSCONV irr;
    CH txb[MAX_KEYWORD_LENGTH];

      /* Comments, if any: */
    if (!IOUtil_ReadComment(in, out))
        Write_Comment(out, dscr);

    Read_TEXT(in, MAX_KEYWORD_LENGTH, txb);
    irr = Str2BUSCONV(txb);

    fprintf(out, " %s\n", txb);

    return irr;
}

/*
..
*/


SEQCONV Read_SEQCONV(FILE* in, FILE* out, TEXT dscr)
{
    SEQCONV irr;
    CH txb[MAX_KEYWORD_LENGTH];

      /* Comments, if any: */
    if (!IOUtil_ReadComment(in, out))
        Write_Comment(out, dscr);

    Read_TEXT(in, MAX_KEYWORD_LENGTH, txb);
    irr = Str2SEQCONV(txb);

    fprintf(out, " %s\n", txb);

    return irr;
}

/*
..
*/


BONDTYPE Read_BONDTYPE(FILE* in, FILE* out, TEXT dscr)
{
    BONDTYPE irr;
    CH txb[MAX_KEYWORD_LENGTH];

      /* Comments, if any: */
    if (!IOUtil_ReadComment(in, out))
        Write_Comment(out, dscr);

    Read_TEXT(in, MAX_KEYWORD_LENGTH, txb);
    irr = Str2BONDTYPE(txb);

    fprintf(out, " %s\n", txb);

    return irr;
}

/*
..
*/


SEARCHCONV Read_SEARCHCONV(FILE* in, FILE* out, TEXT dscr)
{
    SEARCHCONV irr;
    CH txb[MAX_KEYWORD_LENGTH];

      /* Comments, if any: */
    if (!IOUtil_ReadComment(in, out))
        Write_Comment(out, dscr);

    Read_TEXT(in, MAX_KEYWORD_LENGTH, txb);
    irr = Str2SEARCHCONV(txb);

    fprintf(out, " %s\n", txb);

    return irr;
}

/*
..
*/


INDEXCONV Read_INDEXCONV(FILE* in, FILE* out, TEXT dscr)
{
    INDEXCONV irr;
    CH txb[MAX_KEYWORD_LENGTH];

      /* Comments, if any: */
    if (!IOUtil_ReadComment(in, out))
        Write_Comment(out, dscr);

    Read_TEXT(in, MAX_KEYWORD_LENGTH, txb);
    irr = Str2INDEXCONV(txb);

    fprintf(out, " %s\n", txb);

    return irr;
}

/*
..
*/


KEYCONV Read_KEYCONV(FILE* in, FILE* out, TEXT dscr)
{
    KEYCONV irr;
    CH txb[MAX_KEYWORD_LENGTH];

      /* Comments, if any: */
    if (!IOUtil_ReadComment(in, out))
        Write_Comment(out, dscr);

    Read_TEXT(in, MAX_KEYWORD_LENGTH, txb);
    irr = Str2KEYCONV(txb);

    fprintf(out, " %s\n", txb);

    return irr;
}

/*
..
*/


INTPOLCONV Read_INTPOLCONV(FILE* in, FILE* out, TEXT dscr)
{
    INTPOLCONV irr;
    CH txb[MAX_KEYWORD_LENGTH];

      /* Comments, if any: */
    if (!IOUtil_ReadComment(in, out))
        Write_Comment(out, dscr);

    Read_TEXT(in, MAX_KEYWORD_LENGTH, txb);
    irr = Str2INTPOLCONV(txb);

    fprintf(out, " %s\n", txb);

    return irr;
}

/*
..
*/


RISKCONV Read_RISKCONV(FILE* in, FILE* out, TEXT dscr)
{
    RISKCONV irr;
    CH txb[MAX_KEYWORD_LENGTH];

      /* Comments, if any: */
    if (!IOUtil_ReadComment(in, out))
        Write_Comment(out, dscr);

    Read_TEXT(in, MAX_KEYWORD_LENGTH, txb);
    irr = Str2RISKCONV(txb);

    fprintf(out, " %s\n", txb);

    return irr;
}

/*
..
*/


SHOCKCONV Read_SHOCKCONV(FILE* in, FILE* out, TEXT dscr)
{
    SHOCKCONV irr;
    CH txb[MAX_KEYWORD_LENGTH];

      /* Comments, if any: */
    if (!IOUtil_ReadComment(in, out))
        Write_Comment(out, dscr);

    Read_TEXT(in, MAX_KEYWORD_LENGTH, txb);
    irr = Str2SHOCKCONV(txb);

    fprintf(out, " %s\n", txb);

    return irr;
}

/*
..
*/


ALIGNCONV Read_ALIGNCONV(FILE* in, FILE* out, TEXT dscr)
{
    ALIGNCONV irr;
    CH txb[MAX_KEYWORD_LENGTH];

      /* Comments, if any: */
    if (!IOUtil_ReadComment(in, out))
        Write_Comment(out, dscr);

    Read_TEXT(in, MAX_KEYWORD_LENGTH, txb);
    irr = Str2ALIGNCONV(txb);

    fprintf(out, " %s\n", txb);

    return irr;
}

/*
..
*/


SORTCONV Read_SORTCONV(FILE* in, FILE* out, TEXT dscr)
{
    SORTCONV irr;
    CH txb[MAX_KEYWORD_LENGTH];

      /* Comments, if any: */
    if (!IOUtil_ReadComment(in, out))
        Write_Comment(out, dscr);

    Read_TEXT(in, MAX_KEYWORD_LENGTH, txb);
    irr = Str2SORTCONV(txb);

    fprintf(out, " %s\n", txb);

    return irr;
}

/*
..
*/


TERMUNIT Read_TERMUNIT(FILE* in, FILE* out, TEXT dscr)
{
    TERMUNIT irr;
    CH txb[MAX_KEYWORD_LENGTH];

      /* Comments, if any: */
    if (!IOUtil_ReadComment(in, out))
        Write_Comment(out, dscr);

    Read_TEXT(in, MAX_KEYWORD_LENGTH, txb);
    irr = Str2TERMUNIT(txb);

    fprintf(out, " %s\n", txb);

    return irr;
}

/*
..
*/


VOLCONV Read_VOLCONV(FILE* in, FILE* out, TEXT dscr)
{
    VOLCONV irr;
    CH txb[MAX_KEYWORD_LENGTH];

      /* Comments, if any: */
    if (!IOUtil_ReadComment(in, out))
        Write_Comment(out, dscr);

    Read_TEXT(in, MAX_KEYWORD_LENGTH, txb);
    irr = Str2VOLCONV(txb);

    fprintf(out, " %s\n", txb);

    return irr;
}

/*
..
*/


DISCIPOL Read_DISCIPOL(FILE* in, FILE* out, TEXT dscr)
{
    DISCIPOL irr;
    CH txb[MAX_KEYWORD_LENGTH];

      /* Comments, if any: */
    if (!IOUtil_ReadComment(in, out))
        Write_Comment(out, dscr);

    Read_TEXT(in, MAX_KEYWORD_LENGTH, txb);
    irr = Str2DISCIPOL(txb);

    fprintf(out, " %s\n", txb);

    return irr;
}

/*
..
*/


INWHATVOL Read_INWHATVOL(FILE* in, FILE* out, TEXT dscr)
{
    INWHATVOL irr;
    CH txb[MAX_KEYWORD_LENGTH];

      /* Comments, if any: */
    if (!IOUtil_ReadComment(in, out))
        Write_Comment(out, dscr);

    Read_TEXT(in, MAX_KEYWORD_LENGTH, txb);
    irr = Str2INWHATVOL(txb);

    fprintf(out, " %s\n", txb);

    return irr;
}

/*
..
*/


VALIDATE Read_VALIDATE(FILE* in, FILE* out, TEXT dscr)
{
    VALIDATE irr;
    CH txb[MAX_KEYWORD_LENGTH];

      /* Comments, if any: */
    if (!IOUtil_ReadComment(in, out))
        Write_Comment(out, dscr);

    Read_TEXT(in, MAX_KEYWORD_LENGTH, txb);
    irr = Str2VALIDATE(txb);

    fprintf(out, " %s\n", txb);

    return irr;
}

/*
..
*/


DFWHICH Read_DFWHICH(FILE* in, FILE* out, TEXT dscr)
{
    DFWHICH dfw ;
    CH txb[MAX_KEYWORD_LENGTH];

      /* Comments, if any: */
    if (!IOUtil_ReadComment(in, out))
        Write_Comment(out, dscr);

    Read_TEXT(in, MAX_KEYWORD_LENGTH, txb);
    dfw = Str2DFWHICH(txb);

    fprintf(out, " %s\n", txb);

    return dfw;
}

/*
..
*/


WEEKDAY Read_WEEKDAY(FILE* in, FILE* out, TEXT dscr)
{
    WEEKDAY dfw ;
    CH txb[MAX_KEYWORD_LENGTH];

      /* Comments, if any: */
    if (!IOUtil_ReadComment(in, out))
        Write_Comment(out, dscr);

    Read_TEXT(in, MAX_KEYWORD_LENGTH, txb);
    dfw = Str2WEEKDAY(txb);

    fprintf(out, " %s\n", txb);

    return dfw;
}


/*
..
*/

ANCHORDAY Read_ANCHORDAY(FILE* in, FILE* out, TEXT dscr)
{
    ANCHORDAY dfw ;
    CH txb[MAX_KEYWORD_LENGTH];

      /* Comments, if any: */
    if (!IOUtil_ReadComment(in, out))
        Write_Comment(out, dscr);

    Read_TEXT(in, MAX_KEYWORD_LENGTH, txb);
    dfw = Str2ANCHORDAY(txb);

    fprintf(out, " %s\n", txb);

    return dfw;
}


/*
..
*/


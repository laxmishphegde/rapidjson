/* SCID @(#)testscul.c	1.17 (SimCorp) 99/08/18 18:50:12 */

/************************************************************************
*
*   project     SCecon
*
*   this program tests the routines in the utilities module of SCecon
*
************************************************************************/

/*** includes ***********************************************************/
#include <string.h>
#include <stdlib.h>
#include <scalloc.h>
#include <scutl.h>
#include <str2conv.h>
#include <ioconv.h>

INTI scultest(char* txa, FILE* in, FILE* out)
{
    char       txb[25], txpl[64];
    FL64ARRAY  x1a, x2a, w, earr, arr, x, y, newarr ;
    FL64       b, c, abc, acc, fres, fexp, x0, x1, mean, std, prob, x10, x20;
    FL64       lastt, prec ;
    INTI       k, j, i, diff, diff1, n, p, m, nx1, nx2, round, ratio, nout ;
    INTIARRAY  eiarr, iarr, index, eindex ;
    INTPOLCONV ipol ;
    SORTCONV   sort ;
    SEARCHCONV conv;
    INDEXCONV  iconv;
    int        i1, i2, i3 ;
    BOOLE      ok, fixacc ;
    FL64MATRIX a, a1, v ;

	/* PMSTA-22396 - SRIDHARA � 160502 */
	HOLI_STR holi;
	holi = Set_HOLI_STR(NO_BUSADJUST, 0, NULL);

    acc = 0.00001 ;
    diff = -1 ;

    if (!strcmp("Scutl_SubdivideFL64ARRAY()", txa))
    {
        fprintf(out, "%s\n", txa);
        
        arr = Read_FL64ARRAY(in, &nx1);
        Write_FL64ARRAY(out, arr, nx1);
        ratio = Read_INTI(in, out, "Ratio");
        lastt = Read_FL64(in, out, "Last term");

        newarr = Scutl_SubdivideFL64ARRAY(arr, nx1, ratio, lastt, &nout);

        earr = Read_FL64ARRAY(in, &nx2);

        fprintf(out, "Split array:\n");
        diff = WriteFL64ARRAYDiff(True, earr, nx2, True, newarr, nout, out, 
                                  0.000001);

        Free_FL64ARRAY(arr);
        Free_FL64ARRAY(earr);
        Free_FL64ARRAY(newarr);
    }
    
    else if (!strcmp("Scutl_Find_Termindex()", txa))
    {
        fprintf(out, "%s", txa);
        
        arr = Read_FL64ARRAY(in, &n);
        Write_FL64ARRAY(out, arr, n);

        x0 = Read_FL64(in, out, "Key ");
        i = Read_INTI(in, out, "StartIndex ");
  
        conv = Read_SEARCHCONV(in, out, "Search");
        iconv = Read_INDEXCONV(in, out, "Index");
     
        j = Scutl_Find_Termindex(arr, n, x0, i, conv, iconv);

        k = Read_INTI(in, out, "ExpRes ");

        IOUtil_ParseLine(in, out);

        diff = Write_SingleDiff(True, True, (FL64) j, (FL64) k, 
          acc, out) ;
        Free_FL64ARRAY(arr);

    }
    else if (!strcmp("Math_Interpolation()", txa))
    {
        fscanf(in, "%lf %lf %d %s %s", &fexp, &x0, &i1, txb, txpl);
        n = (INTI) i1 ;
        ipol = Str2INTPOLCONV(txb) ;
        x = Alloc_FL64ARRAY(n) ;
        y = Alloc_FL64ARRAY(n) ;
        for (i = 0 ; i < n ; i++)
            fscanf(in,"%lf %lf", &x[i], &y[i]) ;

        fres = Math_Interpolation(x0, n, x, y, ipol) ;

        diff = (fabs(fres - fexp) > acc);

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   x-value %8.5lf\n", x0) ;
        fprintf(out,"   interpolation  %s\n", txb) ;
        fprintf(out,"   result is %8lf ; expected is %8lf\n", fres, fexp) ;

        fprintf(out,"   x/y table is...\n") ;
        for (i = 0 ; i < n ; i++)
            fprintf(out,"   x[%2d] %10.5lf  y[%2d] %10.5lf\n",
                    i, x[i], i, y[i]) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_FL64ARRAY(x) ;
        Free_FL64ARRAY(y) ;
    }

    else if (!strcmp("Math_IntpolArray()", txa))
    {
        fscanf(in, "%lf %lf %d %s %s", &fexp, &x0, &i1, txb, txpl) ;
        n = (INTI) i1 ;
        ipol = Str2INTPOLCONV(txb) ;
        x = Alloc_FL64ARRAY(n) ;
        y = Alloc_FL64ARRAY(n) ;
        for (i = 0 ; i < n ; i++)
            fscanf(in,"%lf %lf", &x[i], &y[i]) ;

        w = Math_IntpolArray(&x0, 1, n, x, y, ipol) ;

        diff = (fabs(w[0] - fexp) > acc);

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   x-value %8.5lf\n", x0) ;
        fprintf(out,"   interpolation  %s\n", txb) ;
        fprintf(out,"   result is %8lf ; expected is %8lf\n", w[0], fexp) ;

        fprintf(out,"   x/y table is...\n") ;
        for (i = 0 ; i < n ; i++)
            fprintf(out,"   x[%2d] %10.5lf  y[%2d] %10.5lf\n",
                    i, x[i], i, y[i]) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_FL64ARRAY(x) ;
        Free_FL64ARRAY(y) ;
        Free_FL64ARRAY(w) ;
    }

    else if (!strcmp("Math_2Dinterpolation()", txa))
    {
        fscanf(in, "%lf %lf %lf %d %d %s %s",
               &fexp, &x10, &x20, &i1, &i2, txb, txpl);

        nx1 = (INTI) i1 ;
        nx2 = (INTI) i2 ;
        ipol = Str2INTPOLCONV(txb) ;
        fprintf(out,"?; testing %s\n", txa) ;
        fprintf(out,"   x1-value %8.5lf\n", x10) ;
        fprintf(out,"   x2-value %8.5lf\n", x20) ;
        fprintf(out,"   Interpolation  %s\n", txb) ;

        x1a = Alloc_FL64ARRAY(nx1) ;
        x2a = Alloc_FL64ARRAY(nx2) ;
        v   = Alloc_FL64MATRIX(nx1, nx2) ;

        fprintf(out,"   The function table is...\n   ") ;
        for (i = 0 ; i < nx1 ; i++)
        {
            fscanf(in,"%lf", &x1a[i]) ;
            fprintf(out,"%lf ", x1a[i]) ;
        }
        fprintf(out,"\n") ;

        for (j = 0 ; j < nx2 ; j++)
        {
            fscanf(in,"%lf", &x2a[j]) ;
            fprintf(out,"   %lf ", x2a[j]) ;

            for (i = 0 ; i < nx1 ; i++)
            {
                fscanf(in,"%lf", &v[i][j]) ;
                fprintf(out,"%lf ", v[i][j]) ;
            }
            fprintf(out,"\n") ;
        }

        fres = Math_2Dinterpolation(x10, x20, x1a, nx1, x2a, nx2, v, ipol) ;
        diff = (fabs(fres - fexp) > acc);

        fprintf(out,
          "%d; result is %8lf ; expected is %8lf\n",
          diff, fres, fexp) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_FL64ARRAY(x1a) ;
        Free_FL64ARRAY(x2a) ;
        Free_FL64MATRIX(v) ;
    }

    else if (!strcmp("Math_Intpol_Bspline()", txa))
    {
        fscanf(in, "%lf %lf %d %d %d", &fexp, &x0, &i1, &i2, &i3);

        p = (INTI) i1 ;
        k = (INTI) i2 ;
        n = (INTI) i3 ;

        fprintf(out,"   testing %s\n", txa) ;
        fprintf(out,"   t-value     %8.5lf\n", x0) ;
        fprintf(out,"   p           %8d\n", i1) ;
        fprintf(out,"   k           %8d\n", i2) ;
        fprintf(out,"   n           %8d\n", i3) ;

        x = Read_FL64ARRAY(in, &m) ;
        fprintf(out,"   Knot Points:\n") ;
        Write_FL64ARRAY(out, x, m) ;

        fres = Math_Intpol_Bspline(x0, p, k, n, n + 2*k, x) ;
        diff = (fabs(fres - fexp) > acc);
        fprintf(out,
          "%d; result is %10.5lf ; expected is %10.5lf\n",
          diff, fres, fexp) ;
        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_FL64ARRAY(x) ;
    }

    else if (!strcmp("Math_WeightedAvg()", txa))
    {
        fscanf(in, "%lf %d %s", &fexp, &i1, txpl);

        n = (INTI) i1 ;
        x = Alloc_FL64ARRAY(n) ;
        y = Alloc_FL64ARRAY(n) ;

        for (i = 0 ; i < n ; i++)
            fscanf(in,"%lf %lf", &x[i], &y[i]) ;

        fres = Math_WeightedAvg(n, x, y) ;

        diff = (fabs(fres - fexp) > acc);

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,
          "   result is %10.5lf ; expected is %10.5lf\n",
          fres, fexp) ;

        fprintf(out,"   input values to be weighted...\n") ;
        for (i = 0 ; i < n ; i++)
            fprintf(out,"   value[%2d] %10.5lf  weight[%2d] %10.5lf\n",
                    i, x[i], i, y[i]) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_FL64ARRAY(x) ;
        Free_FL64ARRAY(y) ;
    }

    else if (!strcmp("Math_SVD()", txa))
    {
        fscanf(in, "%d %d %s", &i1, &i2, txpl);

        m = (INTI) i1 ;
        n = (INTI) i2 ;

        a = Alloc_FL64MATRIX(m, n) ;
        a1 = Alloc_FL64MATRIX(m, n) ;
        v = Alloc_FL64MATRIX(n, n) ;
        w = Alloc_FL64ARRAY(n) ;

        fprintf(out,"   testing %s\n", txa) ;

        for (i = 0; i < m; i++)
        {
            for (j = 0; j < n; j++)
            {
                fscanf(in,"%lf", &a[i][j]) ;
                a1[i][j] = a[i][j] ;
            }
        }

        ok = Math_SVD(a, m, n, 30, w, v) ;
        if (ok == False)
        {
            printf("1; cannot do SVD\n") ;
            diff = 1 ;
        }
        else
        {
            diff = 0 ;
            fprintf(out, "   The U matrix....\n") ;
            for (i = 0; i < m; i++)
            {
                for (j = 0; j < n; j++)
                    fprintf(out,"  %lf", a[i][j]) ;
                fprintf(out,"\n") ;
            }

            fprintf(out, "   The W matrix....\n ") ;
            for (i = 0; i < n; i++)
                fprintf(out,"  %lf", w[i]) ;
            fprintf(out,"\n") ;

            fprintf(out, "   The V matrix....\n ") ;
            for (i = 0; i < n; i++)
            {
                for (j = 0; j < n; j++)
                    fprintf(out,"  %lf", v[i][j]) ;
                fprintf(out,"\n") ;
            }

            fprintf(out, "   Chk of the U matrix (UT*U = I) ....\n ") ;
            for (i = 0; i < n; i++)
            {
                for (j = 0; j < n; j++)
                {
                    for (abc = 0.0, k = 0; k < m; k++)
                        abc += a[k][i] * a[k][j] ;

                    if (fabs(abc) > acc && j != i)
                        diff = 1 ;

                    if (fabs(abc - 1.0) > acc && j == i)
                        diff = 1 ;

                    fprintf(out,"  %lf", abc) ;
                }
                fprintf(out,"\n") ;
            }

            fprintf(out, "   Chk of the V matrix (V*VT = I) ....\n ") ;
            for (i = 0; i < n; i++)
            {
                for (j = 0; j < n; j++)
                {
                    for (abc = 0.0, k = 0; k < n; k++)
                        abc += v[i][k] * v[j][k] ;

                    if (fabs(abc) > acc && j != i)
                        diff = 1 ;

                    if (fabs(abc - 1.0) > acc && j == i)
                        diff = 1 ;

                    fprintf(out,"  %lf", abc) ;
                }
                fprintf(out,"\n") ;
            }

            fprintf(out, "   Chk of U*W*VT - A = 0 ....\n") ;

            for (i = 0; i < m; i++)
            {
                for (j = 0; j < n; j++)
                {
                    for (abc = 0.0, k = 0; k < n; k++)
                        abc += w[k]*a[i][k]*v[j][k] ;

                    if (fabs(abc - a1[i][j]) > acc)
                        diff = 1 ;
                    fprintf(out,"  %lf", abc - a1[i][j]) ;
                }
                fprintf(out,"\n") ;
            }
        }
        fprintf(out,"%d; %s\n\n", diff, txpl) ;

        Free_FL64MATRIX(a) ;
        Free_FL64MATRIX(a1) ;
        Free_FL64MATRIX(v) ;
        Free_FL64ARRAY(w) ;
    }

    else if (!strcmp("Scutl_Indexx_FL64()", txa))
    {
        fscanf(in, "%d %s %s", &i1, txb, txpl);

        n = (INTI) i1 ;
        sort   = Str2SORTCONV(txb) ;
        arr    = Alloc_FL64ARRAY(n) ;
        eindex = Alloc_INTIARRAY(n) ;
        for (i = 0 ; i < n ; i++)
        {
            fscanf(in,"%lf %d", &arr[i], &i1) ;
            eindex[i] = (INTI) i1 ;
        }

        index = Scutl_Indexx_FL64(n, arr, sort) ;
        diff = 0 ;

        fprintf(out,"?; testing %s\n", txa) ;
        fprintf(out,"   sorted  %s\n", txb) ;
        fprintf(out,"   input array...\n") ;
        for (i = 0 ; i < n ; i++)
            fprintf(out,"  array[%2d] %10.5lf\n", i, arr[i]) ;
        fprintf(out,"   results...\n") ;

        for (i = 0 ; i < n ; i++)
        {
            diff1 = (index[i] != eindex[i]) ;
            diff = (diff1 ? 1 : diff) ;
            fprintf(out,"%d; index[%d] %d   expected[%d] %d\n",
                    diff1, i, index[i], i, eindex[i]) ;
        }
        fprintf(out,"   %s\n\n", txpl) ;

        Free_FL64ARRAY(arr) ;
        Free_INTIARRAY(index) ;
        Free_INTIARRAY(eindex) ;
    }

    else if (!strcmp("Scutl_Permute_FL64()", txa))
    {
        fscanf(in, "%d %s", &i1, txpl);

        n = (INTI) i1 ;
        arr    = Alloc_FL64ARRAY(n) ;
        earr   = Alloc_FL64ARRAY(n) ;
        index  = Alloc_INTIARRAY(n) ;
        for (i = 0 ; i < n ; i++)
        {
            fscanf(in,"%lf %d %lf", &arr[i], &i1, &earr[i]) ;
            index[i] = (INTI) i1 ;
        }
        fprintf(out,"?; testing %s\n", txa) ;
        fprintf(out,"   input array...\n") ;
        for (i = 0 ; i < n ; i++)
            fprintf(out,"   array[%2d] %10.5lf index[%2d] %5d\n",
                    i, arr[i], i, index[i]) ;

        Scutl_Permute_FL64(n, index, arr) ;
        diff = 0 ;

        fprintf(out,"   results...\n") ;

        for (i = 0 ; i < n ; i++)
        {
            diff1 = (fabs(earr[i] - arr[i]) > acc);
            diff = (diff1 ? 1 : diff) ;
            fprintf(out,"%d; arr[%d] %lf   expected[%d] %lf\n",
                    diff1, i, arr[i], i, earr[i]) ;
        }
        fprintf(out,"   %s\n\n", txpl) ;

        Free_FL64ARRAY(arr) ;
        Free_FL64ARRAY(earr) ;
        Free_INTIARRAY(index) ;
    }

    else if (!strcmp("Scutl_Permute_INTI()", txa))
    {
        fscanf(in, "%d %s", &i1, txpl);

        n = (INTI) i1 ;
        iarr   = Alloc_INTIARRAY(n) ;
        eiarr  = Alloc_INTIARRAY(n) ;
        index  = Alloc_INTIARRAY(n) ;
        for (i = 0 ; i < n ; i++)
        {
            fscanf(in,"%d %d %d", &iarr[i], &i1, &eiarr[i]) ;
            index[i] = (INTI) i1 ;
        }
        fprintf(out,"?; testing %s\n", txa) ;
        fprintf(out,"   input array...\n") ;
        for (i = 0 ; i < n ; i++)
            fprintf(out,"   array[%2d] %5d index[%2d] %5d\n",
                    i, iarr[i], i, index[i]) ;

        Scutl_Permute_INTI(n, index, iarr) ;
        diff = 0 ;

        fprintf(out,"   results...\n") ;

        for (i = 0 ; i < n ; i++)
        {
            diff1 = (fabs((FL64)(eiarr[i] - iarr[i])) > acc/100.0);
            diff = (diff1 ? 1 : diff) ;
            fprintf(out,"%d; arr[%d] %d   expected[%d] %d \n",
                    diff1, i, iarr[i], i, eiarr[i]) ;
        }
        fprintf(out,"   %s\n\n", txpl) ;

        Free_INTIARRAY(iarr) ;
        Free_INTIARRAY(eiarr) ;
        Free_INTIARRAY(index) ;
    }

    else if (!strcmp("Scutl_Indexx_INTI()", txa))
    {
        fscanf(in, "%d %s %s", &i1, txb, txpl);

        n = (INTI) i1 ;
        sort   = Str2SORTCONV(txb) ;
        iarr   = Alloc_INTIARRAY(n) ;
        eindex = Alloc_INTIARRAY(n) ;
        for (i = 0 ; i < n ; i++)
        {
            fscanf(in,"%d %d", &iarr[i], &i1) ;
            eindex[i] = (INTI) i1 ;
        }

        index = Scutl_Indexx_INTI(n, iarr, sort) ;
        diff = 0 ;

        fprintf(out,"?; testing %s\n", txa) ;
        fprintf(out,"   sorted  %s\n", txb) ;
        fprintf(out,"   input array...\n") ;
        for (i = 0 ; i < n ; i++)
            fprintf(out,"  array[%2d] %10d\n", i, iarr[i]) ;
        fprintf(out,"   results...\n") ;

        for (i = 0 ; i < n ; i++)
        {
            diff1 = (index[i] != eindex[i]) ;
            diff = (diff1 ? 1 : diff) ;
            fprintf(out,"%d; index[%d] %d   expected[%d] %d\n",
                    diff1, i, index[i], i, eindex[i]) ;
        }
        fprintf(out,"   %s\n\n", txpl) ;

        Free_INTIARRAY(iarr) ;
        Free_INTIARRAY(index) ;
        Free_INTIARRAY(eindex) ;
    }

    else if (!strcmp("Stat_Mean()", txa))
    {
        fscanf(in, "%lf %d %s", &fexp, &i1, txpl);

        n = (INTI) i1 ;
        arr = Alloc_FL64ARRAY(n) ;

        for (i = 0; i < n; i++)
            fscanf(in, "%lf", &arr[i]) ;

        fres = Stat_Mean(n, arr) ;
        diff = (fabs(fres - fexp) > acc);

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   Data values are:\n") ;
        for (i = 0; i < n; i++)
            fprintf(out,"   %lf\n", arr[i]) ;

        fprintf(out,
          "   result is %8.5lf ; expected is %8.5lf\n",
          fres, fexp) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_FL64ARRAY(arr) ;
    }

    else if (!strcmp("Stat_Stdev()", txa))
    {
        fscanf(in, "%lf %d %s", &fexp, &i1, txpl);
        n = (INTI) i1 ;
        arr = Alloc_FL64ARRAY(n) ;

        for (i = 0; i < n; i++)
            fscanf(in, "%lf", &arr[i]) ;

        fres = Stat_Stdev(n, arr) ;
        diff = (fabs(fres - fexp) > acc);

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   Data values are:\n") ;
        for (i = 0; i < n; i++)
            fprintf(out,"   %lf\n", arr[i]) ;

        fprintf(out,
          "   result is %8.5lf ; expected is %8.5lf\n",
          fres, fexp) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_FL64ARRAY(arr) ;
    }

    else if (!strcmp("Stat_Correl()", txa))
    {
        fscanf(in, "%lf %d %s", &fexp, &i1, txpl);
        n = (INTI) i1 ;
        arr = Alloc_FL64ARRAY(n) ;
        y = Alloc_FL64ARRAY(n) ;

        for (i = 0; i < n; i++)
            fscanf(in, "%lf %lf", &arr[i], &y[i]) ;

        fres = Stat_Correl(n, arr, y) ;
        diff = (fabs(fres - fexp) > acc);

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   Data values are:\n") ;
        for (i = 0; i < n; i++)
            fprintf(out,"   %lf %lf\n", arr[i], y[i]) ;

        fprintf(out,
          "   result is %8.5lf ; expected is %8.5lf\n",
          fres, fexp) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_FL64ARRAY(arr) ;
        Free_FL64ARRAY(y) ;
    }

    else if (!strcmp("Stat_NormalizedNormal()", txa))
    {
        fscanf(in, "%lf %lf %s", &fexp, &x1, txpl);
        fres = Stat_NormalizedNormal(x1) ;
        diff = (fabs(fres - fexp) > acc);

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   x-value  %8.5lf\n", x1) ;
        fprintf(out,
          "   result is %8.5lf ; expected is %8.5lf\n",
          fres, fexp) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }

    else if (!strcmp("Stat_BivariateNormal()", txa))
    {
        fscanf(in, "%lf ", &fexp) ;
        fprintf(out,"testing %s\n", txa) ;

        x1 = Read_FL64(in, out, "x") ;
        b = Read_FL64(in, out, "y") ;
        c = Read_FL64(in, out, "corr") ;
        fixacc = Read_BOOLE(in, out, "fixacc ?") ;
        prec = Read_FL64(in, out, "Accuracy") ;
        fscanf(in, " %s", txpl) ;

        fres = Stat_BivariateNormal(x1, b, c, fixacc, prec) ;
        diff = (fabs(fres - fexp) > acc);
        
        fprintf(out,
          "%d;   result is %8.5lf ; expected is %8.5lf\n",
          diff, fres, fexp) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }

    else if (!strcmp("Stat_CumulativeNormal()", txa))
    {
        fscanf(in, "%lf %lf %lf %lf %s", &fexp, &x1, &mean, &std, txpl);
        fres = Stat_CumulativeNormal(x1, mean, std) ;
        diff = (fabs(fres - fexp) > acc);

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   x-value            %10.5lf\n", x1) ;
        fprintf(out,"   mean               %10.5lf\n", mean) ;
        fprintf(out,"   standard deviation %10.5lf\n", std) ;
        fprintf(out,
          "   result is %10.5lf ; expected is %10.5lf\n",
          fres, fexp) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }

    else if (!strcmp("Stat_CumulativeLognormal()", txa))
    {
        fscanf(in, "%lf %lf %lf %lf %s", &fexp, &x1, &mean, &std, txpl);
        fres = Stat_CumulativeLognormal(x1, mean, std) ;
        diff = (fabs(fres - fexp) > acc);

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   x-value            %10.5lf\n", x1) ;
        fprintf(out,"   mean               %10.5lf\n", mean) ;
        fprintf(out,"   standard deviation %10.5lf\n", std) ;
        fprintf(out,
          "   result is %10.5lf ; expected is %10.5lf\n",
          fres, fexp) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }

    else if (!strcmp("Stat_ConfidenceNormal()", txa))
    {
        fscanf(in, "%lf %lf %lf %lf %s", &fexp, &x1, &mean, &std, txpl);
        ok = Stat_ConfidenceNormal(x1, mean, std, &fres, &holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */
        diff = (fabs(fres - fexp) > acc);

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   status is          %10d\n", ok) ;
        fprintf(out,"   conf.limit         %10.5lf\n", x1) ;
        fprintf(out,"   mean               %10.5lf\n", mean) ;
        fprintf(out,"   standard deviation %10.5lf\n", std) ;
        fprintf(out,
          "   result is %10.5lf ; expected is %10.5lf\n",
          fres, fexp) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }

    else if (!strcmp("Stat_Binomial()", txa))
    {
        fscanf(in, "%lf %d %d %lf %s", &fexp, &i1, &i2, &prob, txpl);
        n = (INTI) i1 ;
        p = (INTI) i2 ;

        ok = Stat_Binomial(n, p, prob, &fres) ;
        diff = (fabs(fres - fexp) > acc) ;

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   number of outcomes         %7d\n", (int) n) ;
        fprintf(out,"   desired number of outcomes %7d\n", (int) p) ;
        fprintf(out,"   probability                %2.4lf\n", prob) ;
        fprintf(out,"   error code                 %d\n", ok) ;
        fprintf(out,
          "   result is %10.5lf ; expected is %10.5lf\n",
          fres, fexp) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }

    else if (!strcmp("Math_Round()", txa))
    {
        fprintf(out,"   %s\n\n", txa) ;

        acc = Read_FL64(in, out, "   Tolerance       ") ; 
        fexp = Read_FL64(in, out, "   Expected        ") ;   
        b = Read_FL64(in, out, "   FL64            ") ;
        round = Read_INTI(in, out, "   No of decimals  ") ;

        fres = Math_Round(b, round) ;

        diff  = Write_SingleDiff(True, True, fres, fexp, acc, out) ;

        IOUtil_ParseLine(in, out) ;
    }

    else if (!strcmp("Math_Floor()", txa))
    {
        fprintf(out,"   %s\n\n", txa) ;

        acc = Read_FL64(in, out, "   Tolerance       ") ; 
        fexp = Read_FL64(in, out, "   Expected        ") ;   
        b = Read_FL64(in, out, "   To round        ") ;
        c = Read_FL64(in, out, "   Scale Limit     ") ;

        fres = Math_Floor(b, c) ;

        diff  = Write_SingleDiff(True, True, fres, fexp, acc, out) ;

        IOUtil_ParseLine(in, out) ;
    }

    else if (!strcmp("SCecon_ceil()", txa))
    {
        fprintf(out,"   %s\n\n", txa) ;

        acc = Read_FL64(in, out, "   Tolerance       ") ; 
        fexp = Read_FL64(in, out, "   Expected        ") ;   
        b = Read_FL64(in, out, "   FL64            ") ;

        fres = SCecon_ceil(b) ;

        diff  = Write_SingleDiff(True, True, fres, fexp, acc, out) ;

        fprintf(out, "Match built-in routine ceil():\n");

        if (b < 0.0)
          fexp = -ceil(-b);
        else
          fexp = ceil(b);

        diff  = diff ||
            Write_SingleDiff(True, True, fres, fexp, acc, out) ;

        IOUtil_ParseLine(in, out) ;
    }

    else if (!strcmp("SCecon_floor()", txa))
    {
        fprintf(out,"   %s\n\n", txa) ;

        acc = Read_FL64(in, out, "   Tolerance       ") ; 
        fexp = Read_FL64(in, out, "   Expected        ") ;   
        b = Read_FL64(in, out, "   FL64            ") ;

        fres = SCecon_floor(b) ;

        if (b < 0.0)
          fexp = -floor(-b);
        else
          fexp = floor(b);

        diff  = Write_SingleDiff(True, True, fres, fexp, acc, out) ;

        fprintf(out, "Match built-in routine floor():\n");

        if (b < 0.0)
          fexp = -floor(-b);
        else
          fexp = floor(b);

        diff  = diff ||
            Write_SingleDiff(True, True, fres, fexp, acc, out) ;

        IOUtil_ParseLine(in, out) ;
    }

    return diff ;
}

/* SCID @(#)yldalloc.c	1.13 (SimCorp) 99/10/27 14:25:41 */

/************************************************************************
*
*   project     SCecon
*
*   filename    yldalloc.c
*
*   contains    routines in the SCecon Library Yield for allocating
*               memory.
*
************************************************************************/

/***** includes ********************************************************/
#include <yld.h>


/*,,SOH,,
*************************************************************************
*
*                Alloc_TSARRAY()
*
*    interface   #include <yld.h>
*                TSARRAY  Alloc_TSARRAY(INTI nstr,
*                                       INTI np) ;
*
*    general     Allocates memory for an array that can hold the
*                information about nstr term structures.
*                Returns memory with zero'ed entries.
*
*    input       INTI  nstr   Number of structures.
*
*                INTI  np     Number of entries in each TS_STR
*
*    output
*
*    returns     Reference to allocated TSARRAY.
*
*    diagnostics aborts calling SCecon_error()
*                with the message   "Allocation failed"
*                         routine   "Alloc_TSARRAY()"
*                         actioncode SCECONABORT
*                if allocation fails
*
*    see also    Free_TSARRAY()
*
*************************************************************************
,,EOH,,*/


TSARRAY Alloc_TSARRAY(INTI nstr, INTI  np)
{
    TSARRAY    a ;
    INTI       i ;

    a = (TSARRAY) SCecon_calloc(nstr, sizeof(TS_STR), True, 
      "Alloc_TSARRAY()") ;

    for (i = 0 ; i < nstr ; ++i)
    {
        a[i].term    = Alloc_FL64ARRAY(np) ;
        a[i].rate    = Alloc_FL64ARRAY(np) ;
        a[i].loading = Alloc_FL64ARRAY(np) ;
    }

    return a ;
}

/*,,SOH,,
*************************************************************************
*
*                Free_TSARRAY()
*
*    interface   #include <yld.h>
*                void Free_TSARRAY(TSARRAY s,
*                                  INTI    nstr) ;
*
*    general     Frees memory for a nstr number of TSARRAY's allocated
*                by Alloc_TSARRAY()
*
*    input       TSARRAY s     Reference to TSARRAY already allocated
*
*                INTI    nstr  Number of structs in s.
*
*    output
*
*    returns
*
*    diagnostics
*
*    see also    Alloc_TSARRAY()
*
*************************************************************************
,,EOH,,*/


void Free_TSARRAY(TSARRAY s, INTI nstr)
{
    INTI    i ;

    nstr = GETMAX(1, nstr) ;

    for (i = 0 ; i < nstr ; i++)
    {
        Free_FL64ARRAY(s[i].term) ;
        Free_FL64ARRAY(s[i].rate) ;
        Free_FL64ARRAY(s[i].loading) ;
    }

    SCecon_free((VOIDPTR) s) ;
}

/* SCID @(#)testtvm2.c	1.5 (SimCorp) 99/02/19 14:17:11 */

/************************************************************************
*
*   project     SCecon
*
*   This program tests the routines in the time value of money module
*   of SCecon. The program only tests some of the programmes in the
*   TVM module - the remaining functions are tested by tvmtest (main).
*
************************************************************************/

/*** includes ***********************************************************/
#include <string.h>
#include <scalloc.h>
#include <tvm.h>
#include <stdlib.h>
#include <str2conv.h>

/*** the routine *************************************************/

INTI tvmtest2(char* txa, FILE* in, FILE* out)
{
    char    txb[25], txc[25], txpl[64] ;
    FL64    acc, fexp1, fres1, y1 = 0, oas ;
    FL64    *grates, *terms ;
    INTI    diff, n, qb, count, i ;
    INTPOLCONV iconv ;
    PMT_STR *pmt1 ;
    IRRCONV irr ;
    TS_STR  *tsstr ;
    int     i1, i2, i3 ;

    acc = 0.00001 ;
    diff = -1 ;

    if (!strcmp(txa, "TVM_Yield2Duration()"))
    {
        fscanf(in, "%lf %lf %d %s %d %s", &fexp1, &y1, &i1, txb, &i2, txpl);
        qb = (INTI) i1 ;
        count = (INTI) i2 ;

        irr = Str2IRRCONV(txb) ;
        grates = Alloc_FL64ARRAY(count) ;
        pmt1 = Alloc_PMTARRAY(1, count);
        pmt1[0].count = count;
        for (i = 0 ; i < count ; i++)
            fscanf(in,"%lf %lf %lf", &pmt1[0].payment[i],
                                     &pmt1[0].term[i],
                                     &grates[i]) ;

        fres1 = TVM_Yield2Duration(y1, qb, irr, grates, pmt1);
        diff = (fabs(fexp1 - fres1) > acc) ;

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   yield            %8.5lf\n", y1) ;
        fprintf(out,"   quoting basis    %8d\n", qb) ;
        fprintf(out,"   irr convention %s\n", txb) ;
        fprintf(out,
          "   result is %8.5lf ; expected is %8.5lf\n",
          fres1, fexp1) ;

        for (i = 0 ; i < count ; i++)
            fprintf(out, 
"   payment[%d] = %10.5lf, term[%d] = %10.5lf, grates[%d] = %10.5lf\n",
              
                    i, pmt1[0].payment[i], i, pmt1[0].term[i], i, grates[i]);
        fprintf(out,"   %s\n\n", txpl) ;

        Free_FL64ARRAY(grates) ;
        Free_PMTARRAY(pmt1, 1);
    }

    else if (!strcmp(txa, "TVM_Zero2Duration()"))
    {
        fscanf(in, "%lf %d %lf %d %d %s %s %s", &fexp1, &i1, &oas, &i2, &i3,
                                                txc, txb, txpl);
        qb = (INTI) i1 ;
        count = (INTI) i2 ;
        n = (INTI) i3 ;
        iconv         = Str2INTPOLCONV(txb) ;
        pmt1    = Alloc_PMTARRAY(1, count);
        tsstr   = Alloc_TSARRAY(1, n);
        tsstr[0].conv = Str2IRRCONV(txc) ;
        pmt1[0].count  = count ;
        tsstr[0].count = n ;
        tsstr[0].qbas = qb ;
        for (i = 0 ; i < count ; i++)
            fscanf(in,"%lf %lf", &pmt1[0].payment[i],
                                 &pmt1[0].term[i]) ;
        for (i = 0 ; i < n ; i++)
            fscanf(in,"%lf %lf", &tsstr[0].term[i],
                                 &tsstr[0].rate[i]) ;

        fres1 = TVM_Zero2Duration(tsstr, oas, iconv, pmt1) ;
        diff = (fabs(fexp1 - fres1) > acc) ;

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   irr convention %s\n", txc) ;
        fprintf(out,"   oas              %8.5lf\n", y1) ;
        fprintf(out,"   quoting basis    %8d\n", qb) ;
        fprintf(out,"   interpolation %s\n", txb) ;
        fprintf(out,
          "   result is %8.5lf ; expected is %8.5lf\n",
          fres1, fexp1) ;

        for (i = 0 ; i < count ; i++)
            fprintf(out, "   payment[%d] = %10.5lf, term[%d] = %10.5lf\n",
                    i, pmt1[0].payment[i], i, pmt1[0].term[i]) ;

        for (i = 0 ; i < n ; i++)
            fprintf(out, "   term[%d] = %10.5lf  rates[%d] = %10.5lf\n",
                    i, tsstr[0].term[i], i, tsstr[0].rate[i]) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_PMTARRAY(pmt1, 1) ;
        Free_TSARRAY(tsstr, 1) ;
    }
    else if (!strcmp(txa, "TVM_RemainingLife()"))
    {
        fscanf(in, "%lf %d %s", &fexp1, &i2, txpl) ;
        count = (INTI) i2 ;

        terms = Alloc_FL64ARRAY(count) ;
        for (i = 0 ; i < count ; i++)
            fscanf(in,"%lf", &terms[i]) ;

        fres1 = TVM_RemainingLife(terms, count) ;
        diff = (fabs(fexp1 - fres1) > acc) ;

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,
          "   result is %8.5lf ; expected is %8.5lf\n",
          fres1, fexp1) ;

        for (i = 0 ; i < count ; i++)
            fprintf(out, "   term[%d] = %10.5lf\n", i, terms[i]) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_FL64ARRAY(terms) ;
    }

    else if (!strcmp(txa, "TVM_AvgRemainingLife()"))
    {
        fscanf(in, "%lf %d %s", &fexp1, &i2, txpl) ;
        count = (INTI) i2 ;

        pmt1 = Alloc_PMTARRAY(1, count);
        pmt1[0].count = count;
        for (i = 0 ; i < count ; i++)
            fscanf(in,"%lf %lf", &pmt1[0].term[i], &pmt1[0].payment[i]) ;

        fres1 = TVM_AvgRemainingLife(pmt1[0].payment,
                                       pmt1[0].term, pmt1[0].count) ;
        diff = (fabs(fexp1 - fres1) > acc) ;

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,
          "   result is %8.5lf ; expected is %8.5lf\n",
          fres1, fexp1) ;
        for (i = 0 ; i < count ; i++)
            fprintf(out, "   term[%d] = %10.5lf, amort[%d] = %10.5lf\n",
                    i, pmt1[0].term[i], i, pmt1[0].payment[i]) ;
        fprintf(out,"   %s\n\n", txpl) ;


        Free_PMTARRAY(pmt1, 1);
    }

    return diff ;
}

/* SCID @(#)busidays.c	1.30 (SimCorp) 99/08/05 14:17:23 */

/************************************************************************
*
*   project     SCecon
*
*   file name   busidays.c
*
*   general     This file contains standard routines for calendar
*               calculations
*
************************************************************************/

/* includes ************************************************************/
#include <cldr.h>


/*,,SOH,,
*************************************************************************
*
*               Cldr_IsBusinessDateHoliStr()
*
*	interface  #include <cldr.h>
*				BOOLE Cldr_IsBusinessDateHoliStr(DATESTR	*date,
*												 HOLI_STR	*holi);
*
*    general    Cldr_IsBusinessDateHoliStr() checks if the input day is a
*               business day or Holiday. It checks for both DEFAULT as well as BUSINESSSPEC
*               business day rule of the calender
*
*    input      DATESTR   *date      Pointer to input date.
*
*               HOLI_STR  *holi     Container for list of Non Week End Holidays for DEFAULT rule.
*                                   Container for list of Week End  and also Non Week End HOlidays for Business Spec Rule.
*    output
*
*    returns     True if date is a business day, False if the date is holiday.
*
*   Creation	 PMSTA-22396 - SRIDHARA � 160525
*
*    diagnostics
*
*    see also    Cldr_AddBusinessdays()
*                Cldr_NextBusinessDate()
*                Cldr_Weekday()
*
*    wrapper     AP
*
*************************************************************************
,,EOH,,*/

BOOLE Cldr_IsBusinessDateHoliStr(DATESTR* date, HOLI_STR*   holi)
{

	if (holi->busi_date_rule == DEFAULT)
	{
		return(Cldr_IsBusinessDate(date, holi->nholi, holi->holidays));
	}
	else
	{
		if (Cldr_IsHoliDate(date, holi->nholi, holi->holidays) == True)
			return(False);
		else
			return(True);
	}
}

/*,,SOH,,
*************************************************************************
*
*               Cldr_IsBusinessDate()
*
*    interface  #include <cldr.h>
*               BOOLE Cldr_IsBusinessDate(DATESTR   *date,
*                                        INTI      number,
*                                        DATEARRAY hday);
*
*    general    Cldr_IsBusinessDate() checks if the input day is a
*               business day or not.for only business date rule : DEFAULT .
*
*    input      DATESTR   *date      Pointer to input date.
*
*               INTI      number     The number of days in holiday.
*
*               DATEARRAY hday       Ascendingly ordered array with
*                                    number entries of user defined
*                                    non weekend holidays.
*                                    Dimension [number]
*
*    output
*
*    returns     True if date is a business day, False if not.
*
*    Modification PMSTA-22396 - SRIDHARA � 160525
*
*    diagnostics
*
*    see also    Cldr_AddBusinessdays()
*                Cldr_NextBusinessDate()
*                Cldr_Weekday()
*
*    wrapper     AP
*
*************************************************************************
,,EOH,,*/


BOOLE Cldr_IsBusinessDate(DATESTR* date,
                          INTI      number,
                          DATEARRAY hday)
{
	INTI        w;

	/* Rule out some standard cases */
	w = Cldr_Weekday(date);
	if (w > 5)
		return False;

	if (Cldr_IsHoliDate(date, number, hday) == True)
		return(False);
	else
		return(True);
}

/*,,SOH,,
*************************************************************************
*
*               Cldr_IsHoliDate()
*
*    interface  #include <cldr.h>
*				BOOLE Cldr_IsHoliDate(DATESTR   *date,
*									  INTI      number,
*									  DATEARRAY hday);
*
*    general    Cldr_IsHoliDate() checks if the input day is a
*               HOliday or not.
*
*    input      DATESTR   *date      Pointer to input date.
*
*               INTI      number     The number of days in holiday.
*
*               DATEARRAY hday       Ascendingly ordered array with
*                                    number entries of user defined
*                                    weekend and non weekend holidays.
*                                    Dimension [number]
*
*    output
*
*    returns     True if date is a Holiday, False if not.
*
*   Creation	 PMSTA-22396 - SRIDHARA � 160525
*
*    diagnostics
*
*    see also    Cldr_AddBusinessdays()
*                Cldr_NextBusinessDate()
*                Cldr_Weekday()
*
*    wrapper     AP
*
*************************************************************************
,,EOH,,*/


BOOLE Cldr_IsHoliDate(DATESTR* date,
					  INTI      number,
					  DATEARRAY hday)
{
	INTI    i;
	BOOLE   res;

	if (number == 0)
		return False;

	/* Use the standard search routine */
	i = Cldr_FindDateIndex(hday, number, date, 0,
		SEARCH_BISECTION, SAMEINDEX);

	res = (i < number && Cldr_DateEQ(date, &hday[i]) == True ? True : False);

	return res;
}


/*,,SOH,,
*************************************************************************
*
*               Cldr_AddBusinessdays()
*
*   interface   #include <cldr.h>
*               DATESTR Cldr_AddBusinessdays(DATESTR   *datein,
*                                            INTL      ds,
*                                            INTI      number,
*                                            DATEARRAY hday) ;
*
*   general     Cldr_AddBusinessdays() finds the day ds business days
*               after the input business date, datein.
*
*   input       DATESTR   *datein  Pointer to input business date.
*
*               INTL      ds       The number of business days to be
*                                  added to the input date.
*                                  If ds is 0 dateout=datein.
*
*               INTI      number   The number of elements in the array
*                                  of holidays.
*
*               DATEARRAY hday     Ascendingly ordered array with
*                                  number entries of user defined
*                                  non weekend holidays.
*                                  Dimension [number]
*
*   output
*
*   returns     The date ds business days after datein.
*
*               Note that if datein is not a businessdate
*               output is the ds'th businessdate after datein so
*               the output of Cldr_AddBusinessdays(datein,1,...)
*               is not identical to the output from
*               Cldr_NextBusinessDate(datein,...) where
*               a businessdayadjustment convention is used.
*
*   diagnostics
*
*   see also    Cldr_IsBusinessDate()
*               Cldr_AddDays()
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/


DATESTR Cldr_AddBusinessdays(DATESTR* datein,
                             INTL     ds,
                             INTI      number,
                             DATEARRAY hday,
                             CALCONV    accrRule)
{
    INTI    inc ;
    INTL    i, ds1 ;
    DATESTR tmp, dateout ;

    dateout = *datein ;
    inc     = (ds > (INTL) 0 ? 1 : -1) ;
    ds1     = (ds > (INTL) 0 ? ds : -ds) ;

    for (i = (INTL) 1 ; i <= ds1 ; i++)
    {
        dateout = Cldr_AddDays(&dateout, (INTL) inc, accrRule, NULL) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
        while (Cldr_IsBusinessDate(&dateout, number, hday) == False)
        {
            tmp = Cldr_AddDays(&dateout, (INTL) inc, accrRule, NULL) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */

            /* Be careful about being stuck in the loop */
            if (Cldr_DateEQ(&tmp, &dateout) == True)
                return dateout ;

            dateout = tmp ;
        }
    }

    return dateout ;
}


/*,,SOH,,
*************************************************************************
*
*               Cldr_AddNextBusinessdays()
*
*   interface   #include <cldr.h>
*               DATESTR Cldr_AddNextBusinessdays(DATESTR   *datein,
*                                                INTL       ds,
*                                                HOLI_STR*  holi) ;
*
*   general     Cldr_AddNextBusinessdays() finds the day ds business days
*               after the input business date, datein.
*
*   input       DATESTR   *datein  Pointer to input business date.
*
*               INTL      ds       The number of business days to be
*                                  added to the input date.
*                                  If ds is 0 dateout=datein.
*
*               HOLI_STR  *holi     Container for list of Non Week End Holidays for DEFAULT rule.
*                                   Container for list of Week End  and also Non Week End HOlidays for Business Spec Rule.
*   output
*
*   returns     The date ds business days after datein.
*
*               Note that if datein is not a businessdate
*               output is the ds'th businessdate after datein so
*               the output of Cldr_AddBusinessdays(datein,1,...)
*               is not identical to the output from
*               Cldr_NextBusinessDate(datein,...) where
*               a businessdayadjustment convention is used.
*
*   diagnostics
*   Creation    PMSTA-22396 - SRIDHARA � 160525
*
*   see also    Cldr_IsBusinessDate()
*               Cldr_AddDays()
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/


DATESTR Cldr_AddNextBusinessdays(DATESTR    *datein,
	INTL        ds,
	HOLI_STR    *holi)
{
	INTI    inc;
	INTL    i, ds1;
	DATESTR tmp, dateout;

	dateout = *datein;
	inc = (ds > (INTL)0 ? 1 : -1);
	ds1 = (ds > (INTL)0 ? ds : -ds);

	for (i = (INTL)1; i <= ds1; i++)
	{
		dateout = Cldr_AddDays(&dateout, (INTL)inc, ACTACT, NULL);
		while (Cldr_IsBusinessDateHoliStr(&dateout, holi) == False)
		{
			tmp = Cldr_AddDays(&dateout, (INTL)inc, ACTACT, NULL);

			/* Be careful about being stuck in the loop */
			if (Cldr_DateEQ(&tmp, &dateout) == True)
				return dateout;

			dateout = tmp;
		}
	}

	return dateout;
}

/*,,SOH,,
*************************************************************************
*
*               Cldr_NextBusinessDate()
*
*    interface  #include <cldr.h>
*               DATESTR Cldr_NextBusinessDate(DATESTR   *datein,
*                                             HOLI_STR  *holi) ;
*
*    general    Finds the appropriate business date if input date is
*               not a business day, with respect to the business day
*               convention, bcon.
*
*    input      DATESTR   *datein   Input date.
*
*               HOLI_STR  *holi     Container for data on business
*                                   day convention and non-week-end
*                                   holidays.
*    output
*
*    returns    the next business date as DATESTR.
*
*    diagnostics
*
*    see also   Cldr_AddBusinessdays()
*               Cldr_IsBusinessDate()
*               Cldr_NextBusinessDateArray()
*
*    wrapper    AP
*
*************************************************************************
,,EOH,,*/

DATESTR Cldr_NextBusinessDate(DATESTR* datein,
                                 HOLI_STR*  holi)
{
    DATESTR   dateout, nextday, prevday;
    BOOLE     monthchangedforwards, monthchangedbackwards, previsclosest;
    INTI      number ;
    DATEARRAY holidays ;
    BUSCONV   bcon ;

    /* warning avoidance */
    memset(&dateout, 0, sizeof(dateout));
    memset(&nextday, 0, sizeof(nextday));
    memset(&prevday, 0, sizeof(prevday));
    previsclosest = monthchangedforwards = monthchangedbackwards = 0 ;

    if (holi == NULL)
        return *datein ;

    number   = holi->nholi ;
    holidays = holi->holidays ;
    bcon     = holi->bus ;

    /* Is this a business day ?? */
    if (bcon == NO_BUSADJUST ||
        Cldr_IsBusinessDate(datein, number, holidays) == True)
        return *datein ;

    /* datein is a holiday - find next business day */
    if (bcon != PREVIOUS)
        nextday = Cldr_AddBusinessdays(datein, (INTL) 1, number, holidays);
    if (bcon != NEXT)
        prevday = Cldr_AddBusinessdays(datein, (INTL) -1, number, holidays);

    if (bcon == PREVIOUSINMONTH || bcon == CLOSESTINMONTH)
        monthchangedbackwards = (datein->m != prevday.m  ?  True : False) ;

    if (bcon == NEXTINMONTH || bcon == CLOSESTINMONTH)
        monthchangedforwards  = (datein->m != nextday.m  ?  True : False) ;

	/* PMSTA-22396 - SRIDHARA � 160502 */
    if (bcon == CLOSEST || bcon == CLOSESTINMONTH)
        previsclosest = (Cldr_DaysBetweenDates(datein, &nextday, ACTACT, NULL) >
                         Cldr_DaysBetweenDates(&prevday, datein, ACTACT, NULL)  ?
                                                                 True : False) ;

    switch(bcon)
    {
        case NEXT:

            dateout = nextday ;
            break;

        case CLOSEST:

            if (previsclosest)   dateout = prevday ;
            else                 dateout = nextday ;
            break;

        case PREVIOUS:

            dateout = prevday ;
            break ;

        case NEXTINMONTH:

            if (monthchangedforwards) dateout = prevday ;
            else                      dateout = nextday ;
            break;

        case CLOSESTINMONTH:

            if (previsclosest)
            {
                if (monthchangedbackwards)  dateout = nextday ;
                else                        dateout = prevday ;
            }
            else
            {
                if (monthchangedforwards)   dateout = prevday ;
                else                        dateout = nextday ;
            }
            break ;

        case PREVIOUSINMONTH:

            if (monthchangedbackwards) dateout = nextday ;
            else                       dateout = prevday ;
            break ;

        default:
            ;
    }
    return dateout ;
}

/*,,SOH,,
*************************************************************************
*
*               Cldr_NextBusinessDateArray()
*
*    interface  #include <cldr.h>
*               DATEARRAY Cldr_NextBusinessDateArray(DATEARRAY  datein,
*                                                    INTI       n,
*                                                    HOLI_STR  *holi) ;
*
*    general    Finds a list of appropriate business dates if 
*               corresponding input date is not a business day, with
*               respect to the business day convention.
*
*    input      DATEARRAY datein    Input date array, datein[n].
*
*               INTI      n         No. of dates in datein.
*
*               HOLI_STR  *holi     Container for data on business
*                                   day convention and non-week-end
*                                   holidays.
*    output
*
*    returns    List of next business dates as DATEARRAY allocated
*               as Alloc_DATEARRAY(n).
*
*    diagnostics
*
*    see also   Cldr_NextBusinessDate
*
*    wrapper    AP
*
*************************************************************************
,,EOH,,*/

DATEARRAY Cldr_NextBusinessDateArray(DATEARRAY  datein,
                                     INTI       n,
                                     HOLI_STR*  holi)
{
  INTI      i ;
  DATEARRAY out ;

  out = Alloc_DATEARRAY(n) ;

  for (i = 0; i < n ; i++)
    out[i] = Cldr_NextBusinessDate(&datein[i], holi) ;

  return out ;
}



/*,,SOH,,
*************************************************************************
*
*               Cldr_Move2BusinessDays()
*
*    interface  #include <cldr.h>
*               void Cldr_Move2BusinessDays(DATEARRAY days,
*                                           INTI      nd,
*                                           HOLI_STR  *holi) ;
*
*    general    This function moves an array of dates to business days.
*               Note, that the input array of dates is modified during
*               computations.
*
*    input      DATEARRAY days      Input array of dates. Upon
*                                   completion the elements in
*                                   days are moved to businessdays
*                                   according to bus.
*                                   Dimension [nd]
*
*               INTI      nd        Number of elements in days.
*
*               HOLI_STR  *holi     Container for data on business
*                                   day convention and non-week-end
*                                   holidays.
*
*    output                         The modified days.
*
*    returns
*
*    diagnostics
*
*    see also   Cldr_AddBusinessdays()
*               Cldr_IsBusinessDate()
*               Cldr_NextBusinessDate()
*
*    wrapper    AP
*
*************************************************************************
,,EOH,,*/

void Cldr_Move2BusinessDays(DATEARRAY days,
                            INTI      nd,
                            HOLI_STR*  holi)
{
    INTI i ;

    if (holi == NULL)
        return ;

    for (i = 0 ; i < nd ; i++)
        days[i] = Cldr_NextBusinessDate(&days[i], holi) ;
}


/*,,SOH,,
*************************************************************************
*
*               Cldr_LastBusinessDay()
*
*    interface  #include <cldr.h>
*               DATESTR Cldr_LastBusinessDay(DATESTR   *date,
*                                            HOLI_STR  *holi) ;
*
*    general    Cldr_LastBusinessDay() finds the LAST business date of
*               the month in which date lies.
*
*    input      DATESTR   *date     Pointer to input date.
*
*               HOLI_STR  *holi     Holiday setup.
*                                   holi->bus not used.
*
*    output
*
*    returns     The last business date.
*
*    diagnostics
*
*    see also    Cldr_AddBusinessdays()
*                Cldr_NextIMM()
*
*    wrapper     AP
*
*************************************************************************
,,EOH,,*/

DATESTR Cldr_LastBusinessDay(DATESTR* date,
                                HOLI_STR* holi)
{
    DATESTR last ;
    INTI    i ;

    last   = *date ;
    last.d = Cldr_LastDayInMonth(last.y, last.m) ;

    /* Do this instead of 'while' to avoid any chance of infinite loops */
    for (i = 31; i >= 2; i--)
    {
        if (Cldr_IsBusinessDate(&last, holi->nholi, holi->holidays) == True)
            break ;

        last = Cldr_AddBusinessdays(&last, (INTL) -1, holi->nholi,
                                    holi->holidays) ;
    }

    return last ;
}


/*,,SOH,,
*************************************************************************
*
*               Cldr_BusDaysBetweenDates()
*
*    interface  #include <cldr.h>
*               INTL Cldr_BusDaysBetweenDates(DATESTR   *date1,
*                                             DATESTR   *date2,
*                                             HOLI_STR  *holi) ;
*
*    general    Finds the number of business days between the 2 input
*               dates.
*
*    input      DATESTR   *date1    Start date.
*
*               DATESTR   *date2    End date.
*
*               HOLI_STR  *holi     Container for data on business
*                                   day convention and non-week-end
*                                   holidays.
*    output
*
*    returns    The number of business days.
*
*    diagnostics
*
*    see also   Cldr_AddBusinessdays()
*               Cldr_IsBusinessDate()
*
*************************************************************************
,,EOH,,*/

INTL Cldr_BusDaysBetweenDates(DATESTR* date1,
                                 DATESTR*   date2,
                                 HOLI_STR*  holi)
{
    INTL    count ;
    DATESTR start, end ;
    BOOLE   tgl ;

    count = (INTL) 0 ;

    if (Cldr_DateEQ(date1, date2) == True)
        return count ;

    else if (Cldr_DateLT(date1, date2) == True)
    {
        start = *date1 ;
        end   = *date2 ;
        tgl   = False ;
    }

    else
    {
        start = *date2 ;
        end   = *date1 ;
        tgl   = True ;
    }

    while (Cldr_DateLT(&start, &end) == True)
    {
		/* PMSTA-22396 - SRIDHARA � 160525 */
        start = Cldr_AddDays(&start, (INTL) 1, ACTACT, NULL) ;
		if (Cldr_IsBusinessDateHoliStr(&start, holi) == True)
			++count;
    }

    if (tgl == True)
        count = - count ;

    return count ;
}


/*,,SOH,,
***********************************************************************
*                                                                       
*               Cldr_FindDelvDays()
*                                                                       
*    interface  #include <cldr.h>                                       
*               DATEARRAY Cldr_FindDelvDays(DATESTR  *first,
*                                           DATESTR  *last,
*                                           INTI     gridstep,
*                                           CALCONV  cal,
*                                           HOLI_STR *holi,
*                                           INTI     *ndelv) ;
*                                                                       
*    general    Finds business days between first and last. The
*               first date is first (moved to a business date), the
*               next date is 'gridstep' days after first, etc.
*               The last date is no later than last. If first and
*               last are the same date, this date is returned always.
*               Of the dates found by this principle, only those that 
*               are actual business days are included in the returned 
*               array.
*               This function is usefull to generate delivery dates
*               for CTD futures.
*                                                                       
*    input      DATESTR   *first    The starting date.                  
*                                                                       
*               DATESTR   *last     The latest possible date.
*                                                            
*               INTI      gridstep  Grid size.
*                                   
*               CALCONV   cal       Day-counting rule.
*                                                                       
*               HOLI_STR  *holi     Business day adjustment setup.
*                                   
*    output     INTI      *ndelv    Size of returned array.
*                                                                       
*    returns    The business days between first and last spaced
*               with gridstep days. The array is allocated as:
*                   Alloc_DATEARRAY(*ndelv);
*                                                                       
*    diagnostics                                                        
*                                                                       
*    see also   Cldr_NextBusinessDate()                                
*               Cldr_AddDays()                                   
*                                                                       
***********************************************************************
,,EOH,,*/

DATEARRAY Cldr_FindDelvDays(DATESTR*   first,
                               DATESTR*   last,
                               INTI       gridstep,
                               CALCONV    cal,
                               HOLI_STR*  holi,
                               INTI*      ndelv)
{
    INTI     i, max_delvdates ;
    DATESTR  add, delvdate0, *delvdates0, *delvdates;

    if (Cldr_DateEQ(first, last) == False)
    {
        /* First, we find an upper limit on number of days  */
        max_delvdates = (INTI) Cldr_DaysBetweenDates(first, last, cal, holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */
        max_delvdates = (INTI) (max_delvdates / gridstep) + 2;

        /* Allocate memory for intermediate datearray  */
        delvdates0 = Alloc_DATEARRAY(max_delvdates);

        /* Compute intermediate datearray:  */
        add = delvdates0[0] = Cldr_NextBusinessDate(first, holi);
        /* Start at first moved to business date. */
        *ndelv = 1 ;

        for (i = 1; i < max_delvdates; i++)
        {
            add = delvdate0 = Cldr_AddDays(&add, gridstep, cal, holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */
             /* Move gridstep calendar days ahead. */
            if (Cldr_IsBusinessDate(&delvdate0, holi->nholi, 
                  holi->holidays) && Cldr_DateLE(&delvdate0, last))
            {
                /* store date if it is a business date and not after
                   last. */
                delvdates0[*ndelv] = delvdate0 ;
                ++*ndelv ;
            }
        }

        /* Allocate memory for output datearray */
        delvdates = Alloc_DATEARRAY(*ndelv);

        /* Copy delivery dates to output */
        for ( i = 0; i < *ndelv; i++)
            delvdates[i] = delvdates0[i];

        /* Clean up  */
        Free_DATEARRAY(delvdates0);
    }
    else
    {
        /* first and last identical. return first by default: */
        *ndelv = 1 ;
        delvdates = Alloc_DATEARRAY(*ndelv);
        delvdates[0] = *first ;
    }

    return delvdates;
}


/*,,SOH,,
************************************************************************
*
*                Set_HOLI_STR()
*
*   interface    #include <cldr.h>
*                HOLI_STR Set_HOLI_STR(BUSCONV   bus,
*                                      INTI      nholi,
*                                      DATEARRAY holidays) ;
*
*   general      This routine sets the members of the struct defined
*                in the function name. The pointer members are simply
*                assigned - without physical copying. The intention
*                of the Set_*() routines is that by using this
*                functionality, one avoids setting individual members
*                of structs in the application code.
*
*                When new members are inserted in structs the Set_*()
*                routine will be changed accordingly.
*
*                One exception to this principle applies. Whenever
*                OPTADD and vanilla members are used, only the
*                vanilla members are set in the Set_*() routines. The
*                non-vanilla and exotic members are set to defaults,
*                and must be set elsewhere - if needed.This Function 
*                handles  DEFAULT business day rule of the calender
*
*                For details on the interpretation of the individual
*                struct members please check the struct definition.
*
*   input        BUSCONV   bus      See general section.
*
*                INTI      nholi    See general section.
*
*                DATEARRAY holidays See general section.
*
*   output
*
*   returns      The filled out HOLI_STR struct
*
*   diagnostics
*
*   see also     HOLI_STR
*
************************************************************************
,,EOH,,*/

HOLI_STR Set_HOLI_STR(BUSCONV bus,
                      INTI      nholi,
                      DATEARRAY holidays)
{
	return Low_Set_HOLI_STR(bus, nholi, holidays, DEFAULT);  /* PMSTA-22396 - SRIDHARA � 160525 */

}

/*,,SOH,,
************************************************************************
*
*                Low_Set_HOLI_STR()
*
*   interface    #include <cldr.h>
*                HOLI_STR Low_Set_HOLI_STR(BUSCONV   bus,
*										   INTI      nholi,
*                                          DATEARRAY holidays) ;
*
*   general      This routine sets the members of the struct defined
*                in the function name. The pointer members are simply
*                assigned - without physical copying. The intention
*                of the Set_*() routines is that by using this
*                functionality, one avoids setting individual members
*                of structs in the application code.
*
*                When new members are inserted in structs the Set_*()
*                routine will be changed accordingly.
*
*                One exception to this principle applies. Whenever
*                OPTADD and vanilla members are used, only the
*                vanilla members are set in the Set_*() routines. The
*                non-vanilla and exotic members are set to defaults,
*                and must be set elsewhere - if needed.This Function
*                handles  BUSSPECIFIC business day rule of the calender
*
*                For details on the interpretation of the individual
*                struct members please check the struct definition.
*
*   input        BUSCONV   bus      See general section.
*
*                INTI      nholi    See general section.
*
*                DATEARRAY holidays See general section.
*
*				 BUSDATERULE calType  See general section.
*
*   output
*
*   returns      The filled out HOLI_STR struct
*
*   Creation	 PMSTA-22396 - SRIDHARA � 160525
*
*   diagnostics
*
*   see also     HOLI_STR
*
************************************************************************
,,EOH,,*/

HOLI_STR Low_Set_HOLI_STR(BUSCONV bus,
						  INTI      nholi,
						  DATEARRAY holidays,
						  BUSDATERULE calType)
{
	HOLI_STR holi;

	holi.bus = bus;
	holi.nholi = nholi;
	holi.holidays = holidays;
	holi.busi_date_rule = calType;
    holi.busi_const_fact = (BUSCONSTFACTOR)ScaleFctRequired; /*PMSTA-40263-ARUN-29102020*/
	return holi;
}

/* SCID @(#)disc.c	1.122 (SimCorp) 99/07/15 11:19:08 */
/*
%full_filespec: disc.c!22.0.bng-0:csrc:lau1=1 %
%created_by:    sridhara %
%date_created:  Wed Sep 21 13:08:10 2016 %
*/

/************************************************************************
*
*   project     SCecon
*
*   filename    disc.c
*
*   contains    routines in the SCecon Library DF module
*
************************************************************************/

/***** includes ********************************************************/
#include <disc.h>
#include <scutl.h>
#include <tvm.h>

/***** defines  ********************************************************/
#define DISC_TOLR  (FL64)    0.00000001
#define DAY_TOL    (FL64)    0.001
#define IRR_ACC    (FL64)    0.0000000001
#define IRR_GUESS  (FL64)   10.0
#define IRR_MIN    (FL64)    0.0
#define IRR_MAX    (FL64) 1000.0
#define IRR_MAXIT  (INTI)  150
#define IRR_FREQ   (INTI)    1
#define IRR_DAMP   (FL64)    0.9
#define REPAY_TOL  (FL64)   50.0
#define COUPON_TOL (FL64)   0.1

/*,,SOH,,
*************************************************************************
*
*               Disc_Interpolation()
*
*    interface  #include <disc.h>
*               FL64 Disc_Interpolation(DATESTR    *date,
*                                       DISCFAC    *df) ;
*
*    general    The function performs interpolation in a discount
*               function according to various conventions.
*
*               Any adjustment for businessdays must be performed
*               prior to calling this function.
*
*               If the actual date is prior to the first date in the
*               discount function, then 0 is returned.
*
*    input      DATESTR   *date   The date for which a discount factor
*                                 is sought.
*
*               DISCFAC   *df     The discount function setup.
*
*	       	    HOLI_STR  *holi	  Container for list of holidays.
*
*    output
*
*    returns    The interpolated discount factor. If date is before
*               the first discount factor, 0.0 is returned.
*
*    diagnostics
*
*    see also   Math_Interpolation()
*               Vol_Interpolation()
*               Disc_IntpolArray()
*
*    wrapper    AP
*
*************************************************************************
,,EOH,,*/

FL64 Disc_Interpolation(DATESTR* date, DISCFAC* df, HOLI_STR *holi)
{
    INTI       qbas, ix, nfill ;
    DATESTR    *pday, d_tlo, d_tup ;
    FL64ARRAY  ival ;
    FL64       dpy, *pf64, rlow, rup, rate, disc, dlo, dup, alpha ;
    INTL       dsa, ds1, ds2, ds10, ds20 ;
    PLAN_STR   *d ;
    DISCIPOL   what ;
    INTPOLCONV iconv ;
    CALCONV    cal ;

    /* warning avoidance */
    disc = 0.0 ;

    d     = df->disc ;
    what  = df->what ;
    iconv = df->iconv ;
    cal   = df->cal ;

    nfill = GetPlanFill(d) ;
    pday  = GetPlanDay(d) ;
    pf64  = GetPlanF64(d) ;

    qbas  = disc_set_qbas(df->freq) ;

    /* Branch to find relevant case */
    if (nfill < 2)
        disc = 0.0 ;

    else if (Cldr_DateLT(date, &pday[0]) == True)
        disc = 0.0 ;

    else if (Cldr_DateEQ(date, &pday[0]) == True)
        disc = pf64[0] ;

    else if (nfill == 2)
    {
        if (what == DI_DISC)
            disc = Cldr_Plan_Intpol(date, d, cal, iconv, holi) ;  /* PMSTA-22396 - SRIDHARA � 160502 */
        else
        {
			/* PMSTA-22396 - SRIDHARA � 160502 */
            ds1 = Cldr_DaysBetweenDates(&pday[0], date, cal, holi) ;  
            ds2 = Cldr_DaysBetweenDates(&pday[0], &pday[1], cal, holi) ;

            if (what == DI_SPOT || what == DI_FORW)
            {
                /* Here assume flat yield */
                dpy  = Cldr_DaysPerYear(&pday[0], &pday[1], 0, cal, LAST, holi) ;  /* PMSTA-22396 - SRIDHARA � 160502 */
                rate = TVMunit_Yield(pf64[1], ((FL64) ds2) / dpy, df->irr,
                                     qbas) ;
                disc = TVMunit_NPV(((FL64) ds1) / dpy, rate, df->irr, qbas) ;
            }
            else if (what == DI_GROWTH)
            {
                /* Here assume linear growth */
                alpha = 1.0 / pf64[1] ;
                alpha = 1.0 + (alpha - 1.0) * ((FL64) ds1) / (FL64) ds2 ;
                disc  = 1.0 / alpha ;
            }
        }
    }

    else if (iconv == CUBIC_SPLINE && what != DI_FORW)
    {
        ival = Disc_IntpolArray(date, 1, df, holi) ;  /* PMSTA-22396 - SRIDHARA � 160502 */
        disc = ival[0] ;

        Free_FL64ARRAY(ival) ;
    }
    else
    {
        if (what == DI_DISC)
            disc = Cldr_Plan_Intpol(date, d, cal, iconv, holi) ;  /* PMSTA-22396 - SRIDHARA � 160502 */
        else
        {
            /* Now look for interpolation - note that ix > 0 */
            ix = Cldr_FindDateIndex(d->day, nfill, date, 0,
                                     SEARCH_BISECTION, SAMEINDEX) ;

            if (ix < nfill)
            {
                /* This is the standard case */
                dlo   = pf64[ix - 1] ;
                dup   = pf64[ix] ;
                d_tlo = pday[ix - 1] ;
                d_tup = pday[ix] ;
            }
            else
            {
                /* Here prepare for extrapolation */
                dlo   = pf64[ix - 2] ;
                dup   = pf64[ix - 1] ;
                d_tlo = pday[ix - 2] ;
                d_tup = pday[ix - 1] ;

                /* Sometimes flat endings */
                if (iconv == LINEAR_FLAT_END && what != DI_FORW)
                {
                    dlo   = dup ;
                    d_tlo = d_tup ;
                }
            }

			/* PMSTA-22396 - SRIDHARA � 160502 */
            ds1 = Cldr_DaysBetweenDates(&d_tlo, date, cal, holi) ;
            ds2 = Cldr_DaysBetweenDates(&d_tlo, &d_tup, cal, holi) ;

            if (Cldr_DateEQ(&d_tlo, date) == True)
                /* We are interpolating on a gridpoint (low-end) */
                disc = dlo;
            else if (Cldr_DateEQ(&d_tup, date) == True)
                /* We are interpolating on a gridpoint (high-end) */
                disc = dup;
            else if (what == DI_SPOT)
            {
                /* Do linear interpolation in the implied continuous yield. */
/*                alpha = ((FL64) ds1) / (FL64) ds2 ; */
                
                /* In the period till first observation the 'low' yield is 
                   undefined. Instead we interpolate as exp(-y2 * alpha) - 
                   ie. assuming flat rates beyond the lower rate observation */
                if (ix == 1)
                {
                    /* Here assume flat yield */
					/* PMSTA-22396 - SRIDHARA � 160502 */
                    dpy  = Cldr_DaysPerYear(&d_tlo, &d_tup, 0, cal, LAST, holi);
                    rate = TVMunit_Yield(dup, ((FL64) ds2) / dpy, df->irr,
                                         qbas) ;
                    disc = TVMunit_NPV(((FL64) ds1) / dpy, rate, df->irr, qbas);
                }
                else
                {
					/* PMSTA-22396 - SRIDHARA � 160502 */
                    ds10 = Cldr_DaysBetweenDates(&pday[0], &d_tlo, cal, holi) ;
                    ds10 = (ds10 ? ds10 : (INTL) 1) ;
                    ds20 = Cldr_DaysBetweenDates(&pday[0], &d_tup, cal, holi) ;
                    dsa  = Cldr_DaysBetweenDates(&pday[0], date, cal, holi) ;

                    /* Now calculate the discount factor */
                    dpy  = Cldr_DaysPerYear(&d_tlo, date, 0, cal, LAST, holi) ;   /* PMSTA-22396 - SRIDHARA � 160502 */
                    rlow = TVMunit_Yield(dlo, ((FL64) ds10)/dpy, df->irr, qbas);
                    rup  = TVMunit_Yield(dup, ((FL64) ds20)/dpy, df->irr, qbas);
                    rate = Math_linintpol(0.0, ((FL64) ds2)/dpy, rlow, rup,
                                          ((FL64) ds1)/dpy, True) ;
                    disc = TVMunit_NPV(((FL64) dsa)/dpy, rate, df->irr, qbas) ;
                }
            }
            else if (what == DI_GROWTH)
            {
                alpha = Math_linintpol(0.0, (FL64) ds2, 1.0 / dlo, 1.0 / dup,
                                       (FL64) ds1, True) ;
                disc  = 1.0 / alpha ;
            }
            else if (what == DI_FORW)
            {
                /* Find forward rate associated with the single grid period */
				/* PMSTA-22396 - SRIDHARA � 160502 */
                dpy  = Cldr_DaysPerYear(&d_tlo, date, 0, cal, LAST, holi) ;
                rate = TVMunit_Yield(dup/dlo, ((FL64) ds2)/dpy, df->irr, qbas);

                /* Now use this forward rate in the specified period */
                disc = dlo * TVMunit_NPV(((FL64) ds1)/dpy, rate, df->irr, qbas);
            }
        }
    }

    return disc ;
}


/*,,SOH,,
*************************************************************************
*
*               Disc_IntpolArray()
*
*    interface  #include <disc.h>
*               FL64ARRAY Disc_IntpolArray(DATEARRAY  dates,
*                                           INTI       n,
*                                           DISCFAC    *disc) ;
*
*    general    The function performs interpolation in a discount
*               function according to various conventions.
*
*               Any adjustment for businessdays must be performed
*               prior to calling this function.
*
*               If the actual dates are prior to the first date in the
*               discount function, then 0 is returned.
*
*    input      DATEARRAY dates   The dates for which discount factors
*                                 are sought.
*                                 Dimension [n]
*
*               INTI      n       Number of elements in dates.
*
*               DISCFAC   *disc   The discount function setup.
*
*	       	    HOLI_STR  *holi	  Container for list of holidays.
*
*    output
*
*    returns    The interpolated values. Allocated in this routine as:
                Alloc_FL64ARRAY(n).
*
*    diagnostics
*
*    see also   Math_Interpolation()
*               Disc_Interpolation()
*
*    wrapper    AP
*
*************************************************************************
,,EOH,,*/

FL64ARRAY Disc_IntpolArray(DATEARRAY dates,
                            INTI n,
                            DISCFAC*  disc,
							HOLI_STR *holi)
{
    INTI       qbas, ndisc, i, nval ;
    FL64       *pf64, term ;
    FL64ARRAY  ival, y_val, x0_days, x_days ;
    DATESTR    today, *pday ;
    PLAN_STR   *d ;
    DISCIPOL   what ;
    INTPOLCONV iconv ;
    CALCONV    cal ;

    /* warning avoidance */
    qbas = nval = 0 ;

    d     = disc->disc ;
    what  = disc->what ;
    iconv = disc->iconv ;
    cal   = disc->cal ;

    if (iconv == CUBIC_SPLINE && what != DI_FORW)
    {
        ndisc    = GetPlanFill(d) ;
        pday     = GetPlanDay(d) ;
        pf64     = GetPlanF64(d) ;
        y_val    = Alloc_FL64ARRAY(ndisc) ;
        x_days   = Alloc_FL64ARRAY(ndisc) ;
        x0_days  = Alloc_FL64ARRAY(n) ;

        today = pday[0] ;

        for (i = 0 ; i < n ; i++)
            x0_days[i] = (FL64) Cldr_DaysBetweenDates(&today, &dates[i], cal, holi);   /* PMSTA-22396 - SRIDHARA � 160502 */

        if (what == DI_DISC)
        {
            for (i = 0 ; i < ndisc ; i++)
            {
                x_days[i] = (FL64) Cldr_DaysBetweenDates(&today, &pday[i], cal, holi);   /* PMSTA-22396 - SRIDHARA � 160502 */
				/*< PMSTA14465-JPP-120615 - CLONE - Valuation in USD leg of EUR/USD Forward not correct */
				if ((i>0) && (x_days[i] == 0)) 
				{
					x_days[i] = 1; 
				}
				/* PMSTA14465-JPP-120615 >*/
                y_val[i]  = pf64[i] ;
            }

            nval = ndisc ;
        }
        else if (what == DI_SPOT)
        {
            qbas = disc_set_qbas(disc->freq) ;

            for (i = 0 ; i < ndisc - 1 ; i++)
            {
                x_days[i] = (FL64) Cldr_DaysBetweenDates(&today,
                                                         &pday[i + 1], cal, holi);   /* PMSTA-22396 - SRIDHARA � 160502 */
                term      = Cldr_TermBetweenDates(&today, &pday[i + 1],
                                                  0, cal, LAST, holi);   /* PMSTA-22396 - SRIDHARA � 160502 */
                y_val[i]  = TVMunit_Yield(pf64[i + 1], term, disc->irr, qbas) ;
            }

            nval = ndisc - 1 ;
        }

        else if (what == DI_GROWTH)
        {
            for (i = 0 ; i < ndisc ; i++)
            {
                x_days[i] = (FL64) Cldr_DaysBetweenDates(&today, &pday[i], cal, holi);   /* PMSTA-22396 - SRIDHARA � 160502 */
                y_val[i]  = 1.0 / pf64[i] ;
            }

            nval = ndisc ;
        }

        /* Do the interpolation */
        ival = Math_IntpolArray(x0_days, n, nval, x_days, y_val, CUBIC_SPLINE);

        /* Translate rates to discount factors */
        if (what == DI_SPOT)
        {
            for (i = 0 ; i < n ; i++)
            {
                term    = Cldr_TermBetweenDates(&today, &dates[i],
                                                0, cal, LAST, holi);   /* PMSTA-22396 - SRIDHARA � 160502 */
                ival[i] = TVMunit_NPV(term, ival[i], disc->irr, qbas) ;
            }
        }

        /* Translate growth factors into discount factors */
        else if (what == DI_GROWTH)
        {
            for (i = 0 ; i < n ; i++)
                ival[i] = 1.0 / ival[i] ;
        }

        /* Chk out various annoying cases */
        for (i = 0 ; i < n ; i++)
        {
            if (x0_days[i] < 0.0)
                ival[i] = 0.0 ;
        }

        if (ndisc < 2)
        {
            for (i = 0 ; i < n ; i++)
                ival[i] = 0.0 ;
        }

        Free_FL64ARRAY(y_val) ;
        Free_FL64ARRAY(x_days) ;
        Free_FL64ARRAY(x0_days) ;
    }

    else
    {
        ival = Alloc_FL64ARRAY(n) ;

        /* Do linear interpolation */
        for (i = 0 ; i < n ; i++)
            ival[i] = Disc_Interpolation(&dates[i], disc, holi);   /* PMSTA-22396 - SRIDHARA � 160502 */
    }

    return ival ;
}


/*,,SOH,,
*************************************************************************
*
*               Disc_DF2TS()
*
*    interface  #include <disc.h>
*               TSARRAY Disc_DF2TS(DATEARRAY  dates,
*                                  INTI       n,
*                                  DISCFAC    *df,
*                                  PLAN_STR   *loads,
*                                  IRRCONV    irrc,
*                                  PMTFREQ    freq) ;
*
*    general    The function translates a discount structure to a
*               term structure of interest rates.
*
*    input      DATEARRAY dates   The dates for which interest rates
*                                 are sought.
*                                 Dimension [n]
*
*               INTI      n       Number of elements in dates.
*
*               DISCFAC   *df     The discount function setup.
*
*               PLAN_STR  *loads  The loadings (%) for shocking.
*                                 If loads has 0 entries then loa-
*                                 dings of 0 size is generated.
*                                 If loads has 1 entry then loa-
*                                 dings of equal size is generated.
*                                 Otherwise loadings is generated via
*                                 linear interpolation.
*
*               IRRCONV   irrc    Rate convention for the term structure*
*
*               PMTFREQ   freq    Quoting af yield. Must be supplied if
*                                 irr requires it.
*
*	       	    HOLI_STR  *h oli	  Container for list of holidays.
*
*    output
*
*    returns    The term structure of interest rates. Allocated in this
*               routine as:   Alloc_TSARRAY(1, n)
*               disc->cal is used as calendar for the rates.
*
*    diagnostics
*
*    see also
*
*    wrapper    AP
*
*************************************************************************
,,EOH,,*/

TSARRAY Disc_DF2TS(DATEARRAY dates,
                      INTI n,
                      DISCFAC*  df,
                      PLAN_STR* loads,
                      IRRCONV   irrc,
                      PMTFREQ   freq,
					  HOLI_STR *holi)
{
    FL64ARRAY ival ;
    INTI      qbas, i ;
    DATESTR   today ;
    TSARRAY   ts ;
    PLAN_STR  *disc ;
    CALCONV    cal ;

    disc = df->disc ;
    cal  = df->cal ;
    qbas = disc_set_qbas(freq) ;

    ts = Alloc_TSARRAY(1, n) ;
    if (n <= 0 || GetPlanFill(df->disc) <= 0)
        return ts ;

    ts->conv  = irrc ;
    ts->qbas  = qbas ;
    ts->count = n ;

    today = disc->day[0] ;

    ival = Disc_IntpolArray(dates, n, df, holi);   /* PMSTA-22396 - SRIDHARA � 160502 */

    for (i = 0 ; i < n ; i++)
    {
        ts->term[i] = Cldr_TermBetweenDates(&today, &dates[i], 0, cal, LAST, holi);   /* PMSTA-22396 - SRIDHARA � 160502 */
        if (ts->term[i] > DAY_TOL)
            ts->rate[i] = TVMunit_Yield(ival[i], ts->term[i], irrc, qbas) ;
        else
            ts->rate[i] = 0.0 ;

        ts->loading[i] = Cldr_Plan_Intpol(&dates[i], loads, cal, 
                                          LINEAR_FLAT_END, holi);   /* PMSTA-22396 - SRIDHARA � 160502 */
    }

    Free_FL64ARRAY(ival) ;

    return ts ;
}


/*
..
*/

TSARRAY Disc_DF2TSfwd(DATESTR* analys,
                      DATEARRAY dates,
                      INTI      n,
                      DISCFAC*   df,
                      PLAN_STR*  loads,
                      IRRCONV   irrc,
                      PMTFREQ   freq)
{
    FL64ARRAY ival ;
    FL64      term, rate, anchor ;
    INTI      qbas, i, j ;
    TSARRAY   ts ;
    PLAN_STR  *disc ;
    CALCONV    cal ;

	/* PMSTA-22396 - SRIDHARA � 160502 */
	HOLI_STR holi;
	holi = Set_HOLI_STR(NO_BUSADJUST, 0, NULL);

    disc = df->disc ;
    cal  = df->cal ;
    qbas = disc_set_qbas(freq) ;

    ts = Alloc_TSARRAY(1, n) ;
    if (n <= 0 || GetPlanFill(df->disc) <= 0)
        return ts ;

	/* PMSTA-22396 - SRIDHARA � 160502 */
    anchor = Disc_Interpolation(analys, df, &holi) ;
    ival   = Disc_IntpolArray(dates, n, df, &holi) ;

    for (j = i = 0 ; i < n ; i++)
    {
        term = Cldr_TermBetweenDates(analys, &dates[i], 0, cal, LAST, &holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
        if (term > DAY_TOL && SCecon_fabs(anchor) > DISC_TOLR)
            rate = TVMunit_Yield(ival[i] / anchor, term, irrc, qbas) ;
        else
            continue ;

        ts->term[j] = term ;
        ts->rate[j] = rate ;
        ts->loading[j] = Cldr_Plan_Intpol(&dates[i], loads, cal, 
                                          LINEAR_FLAT_END, &holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
        j++ ;
    }

    ts->count = j ;
    ts->conv  = irrc ;
    ts->qbas  = qbas ;

    /* Clean Up */
    Free_FL64ARRAY(ival) ;

    return ts ;
}


/*,,SOH,,
*************************************************************************
*
*               Disc_TS2DF()
*
*    interface  #include <disc.h>
*               DISCFAC Disc_TS2DF(DATESTR   *today,
*                                  DATEARRAY dates,
*                                  FL64ARRAY rates,
*                                  INTI      n,
*                                  DFPARMS   *dfp) ;
*
*    general    The function translates a term structure of interest
*               rates into a discount factor structure.
*
*    input      DATESTR   *today  The anchor date of the TS
*
*               DATEARRAY dates   The dates on which interest rates are
*                                 quoted.
*                                 Dimension [n]
*
*               FL64ARRAY rates   The rates on dates.
*                                 Dimension [n]
*
*               INTI      n       Number of elements in dates/rates
*
*               DFPARMS   *dfp    Discount factor interpolation setup.
*
*	       	    HOLI_STR  *holi	  Container for list of holidays.
*
*    output
*
*    returns    DISCFAC holding the discount function setup. All ele-
*               ments are set here. The disc element is allocated with
*               sufficient entries.
*
*    diagnostics
*
*    see also   Disc_DF2TS()
*
*    wrapper    AP
*
*************************************************************************
,,EOH,,*/

DISCFAC Disc_TS2DF(DATESTR* today,
                   DATEARRAY   dates,
                   FL64ARRAY   rates,
                   INTI        n,
                   DFPARMS*    dfp,
				   HOLI_STR *holi)
{
    INTI     qbas, i ;
    FL64     term, disc ;
    DISCFAC  df ;
    PLAN_STR *dsc ;

    dsc = Alloc_PLANARRAY(1, 1 + n) ;
    df  = Set_DISCFAC(dsc, dfp->what, dfp->iconv, dfp->cal,
                           dfp->irr, dfp->freq) ;

    Cldr_InsertInPlan(today, 1.0, df.disc, True) ;

    qbas = disc_set_qbas(dfp->freq) ;

    for (i = 0; i < n; i++)
    {
		term = Cldr_TermBetweenDates(today, &dates[i], 0, df.cal, LAST, holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */
        if (term < DAY_TOL)
            continue ;

        disc = TVMunit_NPV(term, rates[i], dfp->irr, qbas) ;
        Cldr_InsertInPlan(&dates[i], disc, df.disc, True) ;
    }

    return df ;
}


/*,,SOH,,
*************************************************************************
*
*               Disc_ShockRates()
*
*    interface  #include <disc.h>
*               DISCFAC Disc_ShockRates(DISCFAC   *df,
*                                        FL64      fac,
*                                        RISKSET   *risk) ;
*
*    general    The function shocks a discount structure.
*
*               The shocks can be maturity dependent. This is handled
*               via the shock vector (risk->loads).
*
*               Any adjustment for businessdays must be performed
*               prior to calling this function.
*
*    input      DISCFAC   *df     The discount function setup.
*
*               FL64      fac     Factor on shock
*
*               RISKSET   *risk   The shocking setup.
*
*	       	    HOLI_STR  *holi	  Container for list of holidays.
*
*    output
*
*    returns    The shocked discount function setup. The disc element
*               is allocated in this routine as:
*
*                         Alloc_PLANARRAY(1, df->disc->filled) ;
*
*
*    diagnostics
*
*    see also
*
*************************************************************************
,,EOH,,*/

DISCFAC Disc_ShockRates(DISCFAC* df,
                           FL64     fac,
                           RISKSET* risk,
						   HOLI_STR* holi)
{
    INTI      qbas, i ;
    PLANARRAY disc1 ;
    DATESTR   today;
    FL64      def, shock ;
    PLAN_STR  *disc ;
    DISCFAC   df1 ;

    disc = df->disc ;
    qbas = disc_set_qbas(risk->freq) ;
    def  = Scutl_Default_Shock(risk->shock, KEY_DF) ;

    /* Initialise */
    disc1 = Alloc_PLANARRAY(1, GetPlanFill(disc)) ;

    for (i = 0 ; i < GetPlanFill(disc) && i < GetPlanCount(disc1); i++)
    {
        today = disc->day[0] ;

        if (i > 0)
        {
            if (GetPlanFill(risk->loads) > 0)
                shock = 0.01 * Cldr_Plan_Intpol(&disc->day[i], risk->loads,
                                                df->cal, LINEAR_FLAT_END, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
            else
                /* Shock in bps */
                shock = def ;

            disc1->f64[i] = Disc_Shock_Single(&today, &disc->day[i],
                                              disc->f64[i], fac * shock, 
                                              df->cal, risk->irr, qbas, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
        }
        else
            disc1->f64[i] = 1.0 ;

        disc1->day[i] = disc->day[i] ;
        disc1->filled++ ;
    }

    df1 = Set_DISCFAC(disc1, df->what, df->iconv, df->cal,
                           df->irr, df->freq) ;

    return df1 ;
}


/*
..
*/

DISCFAC Disc_Shock_Dates(DISCFAC* df,
                         INTI      days,
						 HOLI_STR* holi)
{
    DISCFAC   df1 ;
    PLANARRAY disc1 ;
    INTI      i ;

    /* Initialise */
    disc1 = Alloc_PLANARRAY(1, GetPlanFill(df->disc)) ;

    for (i = 0; i < GetPlanFill(df->disc); i++)
    {
        disc1->f64[i] = df->disc->f64[i] ;
        disc1->day[i] = Cldr_AddDays(&df->disc->day[i], (INTL) days, df->cal, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
        disc1->filled++ ;
    }

    df1 = Set_DISCFAC(disc1, df->what, df->iconv, df->cal,
                           df->irr, df->freq) ;

    return df1 ;
}


/*,,SOH,,
*************************************************************************
*
*               Disc_DF2ForwRate()
*
*    interface  #include <disc.h>
*               FL64 Disc_DF2ForwRate(DATESTR    *start,
*                                    DATESTR    *end,
*                                    CALCONV    cal,
*                                    DISCFAC    *df,
*                                    IRRCONV    irr,
*                                    PMTFREQ    freq) ;
*
*    general    The function finds the forward rate implied by the
*               start and end dates according to the conventions
*               specified.
*
*               All adjustment for businessdays must be performed
*               prior to calling this function.
*
*    input      DATESTR  *start The date for which the forward rate is
*                               sought.
*                               Must be after the first date in the
*                               discount function.
*
*               DATESTR  *end   The last date of the period for the
*                               forward rate.
*                               Must be later than start.
*
*               CALCONV  cal    Calender convention for calculating
*                               the forward rate.
*
*               DISCFAC  *df    The discount function setup.
*
*               IRRCONV  irr    The convention for the forward rate.
*
*               PMTFREQ  freq   Quoting basis of the yield, used if
*                               irr requires it.
*
*	       	    HOLI_STR  *holi	  Container for list of holidays.
*
*    output
*
*    returns    The forward rate as percentage annual rate.
*               If the data are not consistent then 0.0 is returned.
*
*    diagnostics
*
*    see also   
*
*************************************************************************
,,EOH,,*/

FL64 Disc_DF2ForwRate(DATESTR* start,
                      DATESTR* end,
                      CALCONV cal,
                      DISCFAC* df,
                      IRRCONV irr,
                      PMTFREQ freq,
					  HOLI_STR* holi)
{
    FL64 f, dper, d1, d2, pv ;
    INTI qbas ;

/*
...paa sigt DI_FORW special code
*/

    qbas = disc_set_qbas(freq) ;
	/* PMSTA-22396 - SRIDHARA � 160502 */
    dper = Cldr_DaysPerYear(start, end, 0, cal, LAST, holi) ;  	
    if (SCecon_fabs(dper) > DISC_TOLR)
        dper = ((FL64) Cldr_DaysBetweenDates(start, end, cal, holi)) / dper ;

	/* PMSTA-22396 - SRIDHARA � 160502 */
    d1 = Disc_Interpolation(start, df, holi) ;
    d2 = Disc_Interpolation(end, df, holi) ;

    if (SCecon_fabs(d1) > DISC_TOLR)
        pv = d2 / d1 ;
    else
        pv = 0.0 ;

    /* If negative d1 or d2 is found then f is not defined */
    if (SCecon_fabs(dper) > DISC_TOLR && pv > DISC_TOLR)
        f = TVMunit_Yield(pv, dper, irr, qbas) ;
    else
        f = 0.0 ;

    return f ;
}


/*,,SOH,,
*************************************************************************
*
*              Disc_DF2NPV()
*
*    interface #include <disc.h>
*              FL64 Disc_DF2NPV(DATESTR    *analys,
*                               DATEARRAY  dates,
*                               FL64ARRAY  coupons,
*                               FL64ARRAY  amorts,
*                               INTI       npmt,
*                               DISCFAC    *df,
*                               DATESTR    *matur,
*                               BOOLE      ignore,
*                               FL64ARRAY  npvdecomp) ;
*
*    general   This function generates the NPV of a series of payments
*              by using a discount function.
*
*              In addition the NPV of the individual payments are
*              returned in npvdecomp.
*
*              The NPV is computed on the analysis (analys) date.
*              Analys is after or equal to first date of the discount
*              function, the day where the discount factor is unity.
*
*              All payments between analys and the first date in df are
*              IGNORED.
*
*    input     DATESTR    *analys   The analys date.
*
*              DATEARRAY  dates     The paydates.
*
*              FL64ARRAY  coupons   The coupon payments.
*
*              FL64ARRAY  amorts    The repayments.
*
*              INTI       npmt      Number of entries in dates, coupons
*                                   and amorts.
*
*              DISCFAC    *df       The discount function setup.
*
*              DATESTR    *matur    The maturity date - only needed if
*                                   df->irr is SIMPLE_REPO.
*                                   If not to be used enter NULL
*
*              BOOLE      ignore    True if payments on analys are
*                                   ignored, False otherwise.
*
*	       	    HOLI_STR  *holi	  Container for list of holidays.
*
*    output    FL64ARRAY  npvdecomp The NPV of the individual payments.
*                                   Preallocated with npmt entries
*                                   Use NULL if not requested.
*
*    returns   NPV of the payment series.
*
*    diagnostics
*
*    see also
*
*************************************************************************
,,EOH,,*/

FL64 Disc_DF2NPV(DATESTR* analys,
                 DATEARRAY dates,
                 FL64ARRAY coupons,
                 FL64ARRAY amorts,
                 INTI npmt,
                 DISCFAC* df,
                 DATESTR* matur,
                 BOOLE  ignore,
                 FL64ARRAY npvdecomp,
				 HOLI_STR* holi)
{
    INTI      i ;
    FL64      ipm, da, xnpv, npv, r, t, FV ;
    FL64ARRAY ival ;
    DATESTR   today ;

    /* Interpolate in one shot */
	/* PMSTA-22396 - SRIDHARA � 160502 */
    ival = Disc_IntpolArray(dates, npmt, df, holi) ;
    da   = Disc_Interpolation(analys, df, holi) ;

    today = Cldr_YMD2Datestr((YYYYMMDD) 19900101) ; /* dummy */
    if (GetPlanFill(df->disc) > 0)
        today = df->disc->day[0] ;

    /* Assume that this is a repo cashflow.
       Later the maturity date must be entered as argument */
    if (df->irr == SIMPLE_REPO && npmt > 1 && matur != NULL)
    {
        if (SCecon_fabs(da) > DISC_TOLR)
            ipm = Disc_Interpolation(matur, df, holi) / da ;
        else
            ipm = 0.0 ;

        for (npv = 0.0, i = 0 ; i < npmt ; i++)
        {
            /* Ignore payments before PVdate */
            if (Cldr_DateLT(&dates[i], analys) == True)            
                continue ;

            if (Cldr_DateEQ(&dates[i], analys) == True && ignore == True)
                continue ;
            
            /* Find MM rate at the paydate */
            t = Cldr_TermBetweenDates(&today, &dates[i], 0, df->cal, LAST, holi) ;   /* PMSTA-22396 - SRIDHARA � 160502 */
            r = TVMunit_Yield(ival[i], t, SIMPLE_MM, 1) ;

            /* Find Forward Value */
            t = Cldr_TermBetweenDates(&dates[i], matur, 0, df->cal, LAST, holi) ;   /* PMSTA-22396 - SRIDHARA � 160502 */
            if (t > 0.0)
                FV = 1.0 / TVMunit_NPV(t, r, SIMPLE_MM, 1) ;
            else
                FV = TVMunit_NPV(-t, r, SIMPLE_MM, 1) ;

            /* Discount till Analysis */
            xnpv = FV * (coupons[i] + amorts[i]) ;
            if (Cldr_DateLT(&today, &dates[i]) == True)
                xnpv *= ipm ;

            /* Sum up */
            npv += xnpv ;

            if (npvdecomp != NULL)
                npvdecomp[i] = xnpv ;
        }
    }

    else
    {
        for (npv = 0.0, i = 0 ; i < npmt ; i++)
        {
            /* Ignore payments before PVdate */
            if (Cldr_DateLT(&dates[i], analys) == True)            
                continue ;

            if (Cldr_DateEQ(&dates[i], analys) == True && ignore == True)
                continue ;

            if (SCecon_fabs(da) > DISC_TOLR)
                xnpv = (coupons[i] + amorts[i]) * ival[i] / da ;
            else
                xnpv = 0.0 ;

            npv += xnpv ;

            if (npvdecomp != NULL)
                npvdecomp[i] = xnpv ;
        }
    }

    Free_FL64ARRAY(ival) ;

    return npv ;
}

/* PMSTA-35405 - RAK - 190621 - one year later last report */
FL64 Disc_DF2NPV2(DATESTR* analys,
	DATEARRAY dates,
	FL64ARRAY coupons,
	FL64ARRAY amorts,
	INTI		npmt,
	DISCFAC*	df,
	BOOLE     ignore)
{
	INTI      i, j;
	FL64      xnpv, npv, amort;

	for (npv = 0.0, i = j = 0; i < npmt && j < df->disc->filled; i++, j++)
	{
		/* Ignore payments before PVdate */
		if (Cldr_DateLT(&dates[i], analys) == True)
			continue;

		if (Cldr_DateEQ(&dates[i], analys) == True && ignore == True)
			continue;

		if (Cldr_DateEQ(&dates[i], &(df->disc->day[j])))
		{
			if (amorts[i] > 1.00000001)
				amort = amorts[i];
			else
				amort = amorts[i] * 100;

			xnpv = (coupons[i] + amort) * df->disc->f64[j];

			npv += xnpv;
		}
	}

	return npv;
}


/*,,SOH,,
*************************************************************************
*
*              Disc_Spread2DF()
*
*    interface #include <disc.h>
*              DISCFAC Disc_Spread2DF(DISCFAC   *df,
*                                     DFSPREAD  *dfs) ;
*
*    general   This function transforms a discount function that is
*              shifted a number of basis points from an original
*              discount function.
*
*    input     DISCFAC    *df       The original discount function.
*
*              DFSPREAD   *dfs      Spread to add to the curve.
*
*	       	    HOLI_STR  *holi	  Container for list of holidays.
*
*    output
*
*    returns   The new 'spreaded' discount function setup. The disc
*              element is allocated in this routine as:
*
*                         Alloc_PLANARRAY(1, df->disc->filled) ;
*
*    diagnostics
*
*    see also
*
*************************************************************************
,,EOH,,*/

DISCFAC Disc_Spread2DF(DISCFAC*  df,
                          DFSPREAD* dfs,
						  HOLI_STR* holi)
{
    DISCFAC   df1 ;
    RISKSET   risk ;
    FL64      fac ;

    if (Disc_CheckDfSpreadEmpty(dfs))
    {
        /* No spreads at all. */
        fac = 0.0;
        risk = Set_RISKSET(KEY_DF, ZERO_ORDER, 0.0, df->irr, df->freq,
                           NULL, True) ;
        df1 = Disc_ShockRates(df, fac, &risk, holi) ;   /* PMSTA-22396 - SRIDHARA � 160502 */
        return df1 ;
    }

    if (GetPlanFill(dfs->spr_list) < 1)
    {
        /* General spread. */
        risk = Set_RISKSET(KEY_DF, ZERO_ORDER, dfs->spread, dfs->irr, 
                           dfs->freq, NULL, True) ;
        fac  = 0.0 ;    
        fac  = (dfs->spread > DISC_TOLR ? 1.0 : fac) ;
        fac  = (dfs->spread <  - DISC_TOLR ? 100.0 * dfs->spread : fac) ;
    }
    else
    {
        /* Time-varying spreads. */
        risk = Set_RISKSET(KEY_DF, ZERO_ORDER, 0.0, dfs->irr, dfs->freq,
                           dfs->spr_list, True) ;
        fac  = 100.0 ;    
    }
    
    df1  = Disc_ShockRates(df, fac, &risk, holi) ;   /* PMSTA-22396 - SRIDHARA � 160502 */ 

    return df1 ;
}


/*,,SOH,,
*************************************************************************
*
*               Disc_DeltaPrep()
*
*    interface  #include <disc.h>
*               DELTASET Disc_DeltaPrep(DISCFAC     *df,
*                                       BUCKETARRAY bucket,
*                                       INTI        nbuck,
*                                       HOLI_STR    *holi,
*                                       BOOLE       ins,
*                                       IRRCONV     irr,
*                                       PMTFREQ     freq,
*                                       BOOLE       dom,
*                                       BOOLE       zero,
*                                       DFWHICH     dfwhich) ;
*
*    general    The function shocks a discount structure using shocks
*               in various buckets.
*
*               This functionality is a preprocessor for a delta-vector
*               or risk position calculation.
*
*               The shocks used here are on the spot rates. bucket
*               define the MID-points of each interval. The mid point
*               is shocked 100% whereas other points in the interval
*               around the midpoint are scaled linearly down to a scale
*               factor of 0% at the adjoining points.
*
*               The shocks for the outer buckets (first and last) are
*               done slightly different - since here all rates from the
*               mid point and 'out' are shocked by the same amount.
*
*               Note that when using shocked discount factor
*               curves, the anchor date (i.e.  the date with
*               discount factor 1) for the set of shocked curves
*               must be the analysis date.  If a date later than
*               the anchor date of the discount function is used
*               as analysis date, the pricing routines will have
*               to discount the PV forward from anchor date to
*               analysis date.  Thus the shock to the first bucket
*               will be used for pricing even for cashflows that
*               only have much later payments, introducing an
*               erroneous nonzero 1st delta-vector element.
*
*
*               For another type of shock see Boot_DeltaPrep()
*
*    input      DISCFAC     *df    The discount function setup.
*
*               BUCKETARRAY bucket The bucketing definition
*                                  Dimension [nbuck]
*
*               INTI        nbuck  No. of buckets in bucket
*
*               HOLI_STR    *holi  Holiday setup
*
*               BOOLE       ins    Insert bucket days ?
*                                  Recommended value - True.
*
*               IRRCONV     irr    Convention for the type of spot rates*
*                                  that are shocked.
*
*               PMTFREQ     freq   The quoting of irr.
*
*               BOOLE       dom    Domestic (True) or foreign (False)
*
*               BOOLE       zero   Yield or zero equivalent delta's
*
*               DFWHICH     dfwhich How to shock when dealing with multi*
*                                  curve securities
*
*    output
*
*    returns    A DELTASET ds holding:
*               ds.shock: Shocked discount function setup allocated as:
*
*                    Alloc_PLANARRAY(nbuck, df->disc->filled + nbuck) ;
*
*               holding all the shocked discount factor curves.
*               ds.nshock  = nbuck
*               ds.dom     = dom
*               ds.dfwhich = dfwhich
*               ds.zero    = zero
*               ds.mid     = List of nbuck mid dates allocated as:
*                            Alloc_DATEARRAY(nbuck) ;
*               ds.token   = tokens from bucket (nbuck elements)
*               ds.size    = List of shocksizes (%) allocated as:
*                            Alloc_FL64ARRAY(nbuck) ;
*
*
*    diagnostics
*
*    see also   Boot_DeltaPrep()
*
*    wrapper    AP
*
*************************************************************************
,,EOH,,*/

DELTASET Disc_DeltaPrep(DISCFAC*    df,
                             BUCKETARRAY bucket,
                             INTI        nbuck,
                             HOLI_STR*   holi,
                             BOOLE       ins,
                             IRRCONV     irr,
                             PMTFREQ     freq,
                             BOOLE       dom,
                             BOOLE       zero,
                             DFWHICH     dfwhich)
{
    INTI      qbas, k, j, i, num ;
    PLANARRAY dfs ;
    DATESTR   mid, day, first, last ;
    FL64      scale, shock ;
    DISCFAC   newdf ;
    DELTASET  ds ;

    ds = Set_DELTASET(NULL, nbuck, dom, dfwhich, zero, NULL, NULL, 
                      irr, freq, NULL) ;

    ds.shock = dfs = Alloc_PLANARRAY(nbuck, GetPlanFill(df->disc) + nbuck) ;
    ds.token = Alloc_RISKTOKENARRAY(nbuck) ;
    ds.mid   = Alloc_DATEARRAY(nbuck) ;
    ds.size  = Alloc_FL64ARRAY(nbuck) ;

    if (nbuck <= 0)
        return ds ;

    if (GetPlanFill(df->disc) < 1)
        return ds ;

    /* Initialise */
    if (ins == True)
        newdf = Disc_insert_buckdates(df, bucket, nbuck, holi) ;
    else
        newdf = *df ;

    qbas = disc_set_qbas(freq) ;
    mid  = newdf.disc->day[0] ;
    last = Cldr_TermUnit2Date(&newdf.disc->day[0], bucket[0].term,
                              bucket[0].unit, ACTACT, LAST, holi);
    last = Cldr_NextBusinessDate(&last, holi) ;

    for (i = 0; i < nbuck; i++)
    {
        first = mid ;
        mid   = last ;

        if (i < nbuck - 1)
        {
            last = Cldr_TermUnit2Date(&newdf.disc->day[0], bucket[i + 1].term,
                                      bucket[i + 1].unit, ACTACT, LAST, holi);
            last = Cldr_NextBusinessDate(&last, holi) ;
        }
        else
            /* Make sure that we are beyond last potential pay date */
            last = Cldr_TermUnit2Date(&last, 500, YEARS, ACTACT, LAST, holi);

        shock = bucket[i].shock ;

        for (k = 0, j = 0; j < newdf.disc->filled; j++)
        {
            day = newdf.disc->day[j] ;
            dfs[i].day[k] = day ;
            dfs[i].f64[k] = newdf.disc->f64[j] ;

            /* In bucket period */
            if (Cldr_DateLT(&first, &day) == True &&
                Cldr_DateLT(&day, &last) == True)
            {
                if (Cldr_DateLE(&day, &mid) == True)
                {
					/* PMSTA-22396 - SRIDHARA � 160502 */
                    scale  = Cldr_DaysBetweenDates(&first, &day, newdf.cal, holi) ;
                    num = Cldr_DaysBetweenDates(&first, &mid, newdf.cal, holi) ;
                    if (num == 0)
                        scale = (Cldr_DateEQ(&day, &mid) == True ? 1.0 : 0.0) ;
                    else
                        scale /= num ;
                }
                else
                {
					/* PMSTA-22396 - SRIDHARA � 160502 */
                    scale  = Cldr_DaysBetweenDates(&day, &last, newdf.cal, holi) ;
                    num = Cldr_DaysBetweenDates(&mid, &last, newdf.cal, holi) ;
                    if (num == 0)
                        scale = (Cldr_DateEQ(&day, &mid) == True ? 1.0 : 0.0) ;
                    else                       
                        scale /= num ;
                }

                /* Handle outside of bucket points specially */
                if (i == 0 && Cldr_DateLT(&day, &mid) == True)
                    scale = 1.0 ;

                if (i == nbuck - 1 && Cldr_DateLT(&mid, &day) == True)
                    scale = 1.0 ;

                dfs[i].f64[k] = Disc_Shock_Single(&newdf.disc->day[0],
                                                  &day, newdf.disc->f64[j],
                                                  scale * shock,
                                                  newdf.cal, irr, qbas, holi) ;   /* PMSTA-22396 - SRIDHARA � 160502 */
            }

            k++ ;
        }

        dfs[i].filled = k ;
        dfs[i].count  = df->disc->filled + nbuck ;

        ds.mid[i]   = mid ;
        VAR_RiskTokenCpy(&ds.token[i], &bucket[i].token) ;
        ds.size[i]  = shock ;
    }

    if (ins == True)
        Free_PLANARRAY(newdf.disc, 1) ;

    return ds ;
}



/*
..
*/

INTI disc_set_qbas(PMTFREQ freq)
{
    return TVMunit_set_qbas(freq) ;
}


/*
..
*/

FL64 Disc_Shock_Single(DATESTR* today, 
                          DATESTR* date, 
                          FL64 disc, 
                          FL64 shock,
                          CALCONV cal, 
                          IRRCONV irr, 
                          INTI qbas,
						  HOLI_STR* holi)
{
    FL64 term, rate, npv ;

    /* Find term till date */
	term = Cldr_TermBetweenDates(today, date, 0, cal, LAST, holi);   /* PMSTA-22396 - SRIDHARA � 160502 */

    /* Find the rate in % */
    rate = TVMunit_Yield(disc, term, irr, qbas) ;

    /* Set the output */
    npv = TVMunit_NPV(term, rate + shock, irr, qbas) ;

    return npv ;
}


/*
..
*/

DISCFAC Disc_insert_buckdates(DISCFAC* df, BUCKETARRAY bucket,
                                 INTI nbucket, HOLI_STR* holi)
{
    INTI      nd, i ;
    DISCFAC   newdf ;
    DATEARRAY dates, bdays ;
    FL64ARRAY disc ;

    newdf = Set_DISCFAC(NULL, df->what, df->iconv, df->cal, df->irr,
                           df->freq) ;
    newdf.disc = Alloc_PLANARRAY(1, GetPlanFill(df->disc) + nbucket) ;

    bdays = Alloc_DATEARRAY(nbucket) ;
    for (i = 0; i < nbucket; i++)
    {
        bdays[i] = Cldr_TermUnit2Date(&df->disc->day[0], bucket[i].term,
                                      bucket[i].unit, ACTACT, LAST, holi);
        bdays[i] = Cldr_NextBusinessDate(&bdays[i], holi) ;
    }

    dates = Cldr_MergeDates(df->disc->day, GetPlanFill(df->disc),
                            bdays, nbucket, &nd) ;

    disc = Disc_IntpolArray(dates, nd, df, holi) ;   /* PMSTA-22396 - SRIDHARA � 160502 */

    for (i = 0; i < nd; i++)
        Cldr_InsertInPlan(&dates[i], disc[i], newdf.disc, True) ;

    Free_DATEARRAY(bdays) ;
    Free_DATEARRAY(dates) ;
    Free_FL64ARRAY(disc) ;

    return newdf ;
}


/*
..pv is value on df->disc->day[0]
*/

BOOLE Disc_forwval(DISCFAC* df, DATESTR* analys, FL64* pv, HOLI_STR* holi)
{
    FL64  da ;
    BOOLE ok ;

    ok = True ;
    da = Disc_Interpolation(analys, df, holi) ;   /* PMSTA-22396 - SRIDHARA � 160502 */
    if (SCecon_fabs(da) > DISC_TOLR)
        *pv /= da ;
    else
    {
        *pv = 0.0 ;
        ok  = False ;
    }

    return ok ;
}


/*
..disc is set to the forward discount factor for the period 
  from start to end
  returns False if start
*/

BOOLE Disc_ForwDisc(DISCFAC*  df, 
                       DATESTR*  start, 
                       DATESTR*  end, 
                       FL64*  disc,
					   HOLI_STR* holi)
{
    BOOLE ok;

    *disc = 1.0 ;

    ok = False;
    if (GetPlanDay(df->disc) != NULL && 
            Cldr_DateLE(df->disc->day, start) == True)
    {
        *disc = Disc_Interpolation(end, df, holi) ;   /* PMSTA-22396 - SRIDHARA � 160502 */
        ok = True ;
    }
    ok   = ok && Disc_forwval(df, start, disc, holi) ;   /* PMSTA-22396 - SRIDHARA � 160502 */

    return ok;
}


FL64 Disc_MarginAdjust(BOOLE margin,
                           FL64    futp,
                           DATESTR* analys,
                           DATESTR* deliv,
                           DISCFAC* df,
						   HOLI_STR* holi)
{
    if (margin == False)
    {
		/* PMSTA-22396 - SRIDHARA � 160502 */
        futp *= Disc_Interpolation(deliv, df, holi) ;
        Disc_forwval(df, analys, &futp, holi) ;
    }

    return futp ;
}



/*
..this routine does ONLY interpolate in a given grid interval to find the
  rate. I.e. the rate is ONLY used for interpolation. E.g. in a 1M grid
  the 3M rate is defined as the 1M rate !!
  ->-> This means that dur is only used if the grid period is larger than
  duration
*/

FL64 Disc_DF2fwd(DISCFAC* df, DATESTR* date,
                    IRRCONV irr, PMTFREQ freq, INTI term, TERMUNIT unit,
                    FL64* dsc)
{
    FL64      tm, tm1, d1, d2, fwd ;
    FL64ARRAY t ;
    INTI      qbas, i, ix ;
    DATESTR   tmp1, tmp, next, prev ;
    HOLI_STR  holi ;

    holi.bus   = NO_BUSADJUST ;
    holi.nholi = 0 ;

    qbas = disc_set_qbas(freq) ;

    /* Find next grid point - ix > 0 is assumed. I.e. date > Discdate */
    ix = Cldr_FindDateIndex(GetPlanDay(df->disc), GetPlanFill(df->disc), date,
                             0, SEARCH_BISECTION, SAMEINDEX) ;

    /* This is extrapolation */
    if (ix >= GetPlanFill(df->disc))
       ix-- ;

    d1   = *dsc = df->disc->f64[ix - 1] ;
    d2   = df->disc->f64[ix] ;
    prev = df->disc->day[ix - 1] ;
    next = df->disc->day[ix] ;

    tmp  = Cldr_TermUnit2Date(&prev, term, unit, df->cal, LAST, &holi) ;
	/* PMSTA-22396 - SRIDHARA � 160502 */
    tm   = Cldr_TermBetweenDates(&prev, &next, 0, df->cal, LAST, &holi) ;
    tm1  = Cldr_TermBetweenDates(&prev, &tmp, 0, df->cal, LAST, &holi) ;

    /* Alloc safely */
    t = Alloc_FL64ARRAY(5 + (INTI) (tm / tm1)) ;

    i = 0 ;
    tmp = prev ;

    /* Now find the rate with given irr, duration that matches this df */
    while (Cldr_DateLT(&tmp, &next) == True)
    {
        tmp1 = Cldr_TermUnit2Date(&tmp, term, unit, df->cal, LAST, &holi) ;
        t[i] = Cldr_TermBetweenDates(&tmp, &tmp1, 0, df->cal, LAST, &holi) ;  /* PMSTA-22396 - SRIDHARA � 160502 */
        tmp  = tmp1 ;
/*
printf("%d %lf\n", i, t[i]) ;
*/
        i++ ;
    }

    if (i == 1)
        /* This case is easy */
        fwd = TVMunit_Yield(d2 / d1, tm, irr, qbas) ;
    else
        /* Now iterate to find forward rate */
        fwd = Disc_fwdYield(d2 / d1, t, i, irr, qbas, &holi) ;  /* PMSTA-22396 - SRIDHARA � 160502 */

    /* Now calculate the relevant discount factor */
    tmp1 = prev ;
    tmp  = Cldr_TermUnit2Date(&prev, term, unit, df->cal, LAST, &holi) ;
    i    = 0 ;
    while (Cldr_DateLT(&tmp, date) == True)
    {
        *dsc *= TVMunit_NPV(t[i], fwd, irr, qbas) ;
        tmp1  = tmp ;
        tmp   = Cldr_TermUnit2Date(&tmp, term, unit, df->cal, LAST, &holi) ;
        i++ ;
    }

    /* Handle the final 'residual' period */
    tm    = Cldr_TermBetweenDates(&tmp1, date, 0, df->cal, LAST, &holi) ;  /* PMSTA-22396 - SRIDHARA � 160502 */
    *dsc *= TVMunit_NPV(tm, fwd, irr, qbas) ;

    Free_FL64ARRAY(t) ;

    return fwd ;
}


/*
..npv > 0, npv < 1
*/

FL64 Disc_fwdYield(FL64 npv, FL64ARRAY t, INTI n, IRRCONV irr, INTI qb, HOLI_STR* holi)
{
    TVMTYPE type ;
    TVMINT  tvm_data ;
    ITERCTRL ctrl ;
    FL64    rate ;
    NR_ERR  err ;

    type = DISC_TVM ;

    Init_ITERCTRL(&ctrl) ;
    ctrl.maxiter = IRR_MAXIT ;
    ctrl.init_guess = IRR_GUESS ;
    ctrl.lower = IRR_MIN ;
    ctrl.upper = IRR_MAX ;
    ctrl.damp = IRR_DAMP ;
    ctrl.acc = IRR_ACC ;
    ctrl.what_acc = 1 ;
    ctrl.gfreq = IRR_FREQ ;
    ctrl.bisec = 1 ;
    ctrl.shock = 0.0 ;

    tvm_data = TVM_SetTVMINT(type, npv, 0.0, 0.0, t, n, 
      irr, qb, BULLET, NULL, NULL, LINEAR_EXTRAPOL, 0.01) ;

	err = Newton_Raphson(&TVM_NewtonRaphson, &tvm_data, &ctrl, &rate, holi);  /* PMSTA-22396 - SRIDHARA � 160502 */
    /* We assume that a solution is always found - which is quite OK */

    return rate ;
}


/*,,SOH,,
************************************************************************
*
*                Set_DISCFAC()
*
*   interface    #include <disc.h>
*                DISCFAC Set_DISCFAC(PLAN_STR*  disc,
*                                    DISCIPOL   ipol,
*                                    INTPOLCONV iconv,
*                                    CALCONV    cal,
*                                    IRRCONV    irr,
*                                    PMTFREQ    freq) ;
*
*   general      This routine sets the members of the struct defined
*                in the function name. The pointer members are simply
*                assigned - without physical copying. The intention
*                of the Set_*() routines is that by using this
*                functionality, one avoids setting individual members
*                of structs in the application code.
*
*                When new members are inserted in structs the Set_*()
*                routine will be changed accordingly.
*
*                One exception to this principle applies. Whenever
*                OPTADD and vanilla members are used, only the
*                vanilla members are set in the Set_*() routines. The
*                non-vanilla and exotic members are set to defaults,
*                and must be set elsewhere - if needed.
*
*                For details on the interpretation of the individual
*                struct members please check the struct definition.
*
*   input        PLAN_STR*  disc  See general section.
*
*                DISCIPOL   ipol  See general section.
*
*                INTPOLCONV iconv See general section.
*
*                CALCONV    cal   See general section.
*
*                IRRCONV    irr   See general section.
*
*                PMTFREQ    freq  See general section.
*
*   output
*
*   returns      The filled out DISCFAC struct
*
*   diagnostics
*
*   see also     DISCFAC
*
************************************************************************
,,EOH,,*/

DISCFAC Set_DISCFAC(PLAN_STR* disc, DISCIPOL ipol, INTPOLCONV iconv,
                         CALCONV cal, IRRCONV irr, PMTFREQ freq)
{
    DISCFAC df ;

    df.disc  = disc ;
    df.what  = ipol ;
    df.iconv = iconv ;
    df.cal   = cal ;
    df.irr   = irr ;
    df.freq  = freq ;

    return df ;
}


/*
..
*/

DISCFAC Disc_Logshock_Rates(DISCFAC* df,
                            FL64      fac,
                            RISKSET*   risk,
							HOLI_STR* holi)
{
  INTI      qbas, i ;
  PLANARRAY disc1 ;
  DATESTR   today, *pday, *pday1 ;
  FL64      def, *pf64, *pf641, shock ;
  PLAN_STR  *disc ;
  CALCONV   cal ;
  DISCFAC   df1 ;

  disc = df->disc ;
  cal  = df->cal ;
  qbas = disc_set_qbas(risk->freq) ;
  def  = Scutl_Default_Shock(risk->shock, KEY_DF) ;

  /* Initialise */
  disc1 = Alloc_PLANARRAY(1, GetPlanFill(disc)) ;

  pday  = GetPlanDay(disc) ;
  pf64  = GetPlanF64(disc) ;

  pday1  = GetPlanDay(disc1) ;
  pf641  = GetPlanF64(disc1) ;

  for (i = 0 ; i < GetPlanFill(disc) && i < GetPlanCount(disc1) ; i++)
  {
    today = pday[0] ;

    if (i > 0)
    {
      if (GetPlanFill(risk->loads) > 0)
        shock = 0.01 * Cldr_Plan_Intpol(&pday[i], risk->loads, 
                                        cal, LINEAR_FLAT_END, holi);  /* PMSTA-22396 - SRIDHARA � 160502 */
      else
        /* Shock in bps */
        shock = def ;

      pf641[i] = Disc_Logshock_Single(&today, &pday[i], pf64[i], fac * shock,
                                      cal, risk->irr, qbas, holi);  /* PMSTA-22396 - SRIDHARA � 160502 */
    }
    else
        pf641[i] = 1.0 ;

    pday1[i] = pday[i] ;

    disc1->filled++ ;
  }

  df1 = Set_DISCFAC(disc1, df->what, df->iconv, df->cal,
                         df->irr, df->freq) ;

  return df1 ;
}


/*
..
*/

FL64 Disc_Logshock_Single(DATESTR* today, DATESTR* date, FL64 disc, 
                             FL64 shock, CALCONV cal, IRRCONV irr, INTI qbas, HOLI_STR* holi)
{
  FL64 term, rate, npv ;

  /* Find term till date */
  term = Cldr_TermBetweenDates(today, date, 0, cal, LAST, holi);  /* PMSTA-22396 - SRIDHARA � 160502 */

  /* Find the rate in % */
  rate = TVMunit_Yield(disc, term, irr, qbas) ;

  /* Set the output */
  npv = TVMunit_NPV(term, rate * exp(shock), irr, qbas) ;

  return npv ;
}


/*
..output must always be usable for division (not zero)
*/

FL64 Disc_DF2BPV(DATESTR* date, DISCFAC* shocked, PLAN_STR* orig, HOLI_STR* holi)
{
    FL64     dZ ;
    PLAN_STR *old ;

    /* Find shocked Zero PV */
    old = shocked->disc ;
    dZ  = - Disc_Interpolation(date, shocked, holi);  /* PMSTA-22396 - SRIDHARA � 160502 */
    shocked->disc = orig ;
    dZ += Disc_Interpolation(date, shocked, holi);  /* PMSTA-22396 - SRIDHARA � 160502 */
    shocked->disc = old ;

    /* Make sure that dZ can be used for division */
    if (SCecon_fabs(dZ) < 0.0000000001)
        dZ = 1.0 ;

    return - dZ ;
}



/*
..
*/

DATESTR Disc_get_chgdate(DATESTR* prev, PLAN_STR* old, PLAN_STR* shock)
{
    DATESTR fsprev ;
    INTI    j ;

    if (prev == NULL)
        fsprev = Cldr_YMD2Datestr((INTL) 0) ;
    else
        fsprev = *prev ;

    /* Note that this will also work if extra dates has been inserted in shock
      */
    for (j = 0; j < GetPlanFill(old); j++)
    {
        if (SCecon_fabs(old->f64[j] - shock->f64[j]) > 0.0000000001)
        {
            if (j > 0 && Cldr_DateLE(&old->day[j], &fsprev) == False)
                fsprev = old->day[j - 1] ;
            break ;
        }
    }

    return fsprev ;
}


/*,,SOH,,
*************************************************************************
*
*               Disc_Zeros2DF()
*
*   interface   #include <disc.h>
*               DISCFAC Disc_Zeros2DF(DATESTR     *start,
*                                     ZRATEARRAY  zrates,
*                                     INTI        nrates,
*                                     HOLI_STR    *holi,
*                                     DFPARMS     *dfp) ;
*
*   general     The function takes a number of zero coupon rates and
*               translates them into Discount Factors according to a
*               number of different conventions.
*
*   input       DATESTR     *start   The start date for the
*                                    disc.function.
*
*               ZRATEARRAY  zrates   Specification of the zero rates
*
*               INTI        nrates   No. of zero coupon rates.
*
*               HOLI_STR    *holi    Holidays set-up.
*
*               DFPARMS     *dfp     Parameters for DF's in disc.
*
*   output
*
*   returns     The Zero Coupon Curve (DF). The disc is allocated as:
*
*                         Alloc_PLANARRAY(1, 1 + nrates) ;
*
*   diagnostics
*
*   see also    Zero_GenrDF()
*
*************************************************************************
,,EOH,,*/

DISCFAC Disc_Zeros2DF(DATESTR*    start,
                         ZRATEARRAY    zrates,     
                         INTI          nrates,
                         HOLI_STR*      holi,
                         DFPARMS*       dfp) 
{
    DATESTR end ; 
    DISCFAC df ;
    FL64    t, npv ;
    INTI    qb, i ;

    /* Initialise DF */    
    df = Set_DISCFAC(NULL, dfp->what, dfp->iconv, dfp->cal, dfp->irr, 
                          dfp->freq) ;

    /* Allocate memory */
    df.disc = Alloc_PLANARRAY(1, nrates + 1) ;
    Cldr_InsertInPlan(start, 1.0, df.disc, False) ;

    /* Loop over zero coupon rates */
    for (i = 0; i < nrates; i++)
    {
        end = Cldr_AddPeriod(start, &zrates[i].period, zrates[i].cal, 
                             zrates[i].eom, holi) ;
        end = Cldr_NextBusinessDate(&end, holi) ;
        t   = Cldr_TermBetweenDates(start, &end, 0, zrates[i].cal, 
                                    zrates[i].eom, holi);  /* PMSTA-22396 - SRIDHARA � 160502 */
        qb  = disc_set_qbas(zrates[i].freq) ;
        npv = TVMunit_NPV(t, zrates[i].rate, zrates[i].irr, qb) ;

        Cldr_InsertInPlan(&end, npv, df.disc, False) ;
    }

    return df ;
}



/*
*************************************************************************
*
*               Disc_MergeDF()
*
*   interface   #include <disc.h>
*               DISCFAC Disc_MergeDF(DISCFAC* df_conv,
*                                    DISCFAC* df_stor)
*
*   general     This function subtracts storage cost from convenience
*               yields, both given as discount function.
*
*               The subtraction is done by dividing df_conv factors
*               by df_stor factors. The resulting discount function
*               contains all dates present if both df_conv and df_stor.
*
*   input       DISCFAC     *df_conv The discount function holding
*                                    convenience yield
*
*               DISCFAC     *df_stor The discount function holding
*                                    storage costs
*
*	       	    HOLI_STR    *holi	 Container for list of holidays.
*
*   output
*
*   returns     The merged discount function. The disc is allocated as:
*
*                         Alloc_PLANARRAY(1, 1 + count) ;
*
*               where count refers to the count element of DISCFAC.
*
*   diagnostics
*
*   see also    Disc_Genr_DF()
*
*************************************************************************
*/
DISCFAC Disc_MergeDF(DISCFAC* df_conv,
                          DISCFAC* df_stor,
						  HOLI_STR* holi)
{
    DISCFAC   df, cc_df ;
    PLAN_STR  disc ;
    FL64ARRAY tmp ;
    INTI      i, ccdff, cyf, stcf ;
    DATEARRAY cyd, stcd ;

    cyf = GetPlanFill(df_conv->disc) ;
    cyd = GetPlanDay(df_conv->disc) ;

    stcf = GetPlanFill(df_stor->disc) ;
    stcd = GetPlanDay(df_stor->disc) ;

    /* Combine the DISCFAC's 'conv_df' and 'stor_df' */
    disc.day = Cldr_MergeDates(cyd, cyf, stcd, stcf, &disc.filled) ;
    cc_df    = Set_DISCFAC(&disc, df_conv->what, df_conv->iconv,
                                df_conv->cal, df_conv->irr, df_conv->freq) ;

    /* Find convenience df on all dates */
    if (cyf > 0)
        disc.f64 = Disc_IntpolArray(disc.day, disc.filled, df_conv, holi);  /* PMSTA-22396 - SRIDHARA � 160502 */
    else
    {
        disc.f64 = Alloc_FL64ARRAY(disc.filled) ;
        for (i = 0; i < disc.filled; i++)
            disc.f64[i] = 1.0 ;
    }

    /* Divide by storage cost df */
    if (stcf > 0)
    {
        tmp = Disc_IntpolArray(disc.day, disc.filled, df_stor, holi);  /* PMSTA-22396 - SRIDHARA � 160502 */
        for (i = 0; i < disc.filled && fabs(tmp[i]) > 0.0000001 ; i++)
            disc.f64[i] /= tmp[i] ;

        Free_FL64ARRAY(tmp) ;

        if (!cyf)
            cc_df = Set_DISCFAC(&disc, df_stor->what, df_stor->iconv,
                                     df_stor->cal, df_stor->irr, df_stor->freq);
    }

    ccdff = GetPlanFill(cc_df.disc) ;

    df.disc = Alloc_PLANARRAY(1, ccdff) ;
    for (i = 0; i < ccdff; i++)
        Cldr_InsertInPlan(&cc_df.disc->day[i], cc_df.disc->f64[i],
                            df.disc, True) ;

    df = Set_DISCFAC(df.disc, cc_df.what, cc_df.iconv,
                          cc_df.cal, cc_df.irr, cc_df.freq) ;

    Free_DATEARRAY(disc.day) ;
    Free_FL64ARRAY(disc.f64) ;

    return df ;
}



/*,,SOH,,
************************************************************************
*
*                Set_RISKSET()
*
*   interface    #include <disc.h>
*                RISKSET Set_RISKSET(KEYCONV   key,
*                                    RISKCONV  risk,
*                                    FL64      shock,
*                                    IRRCONV   irr,
*                                    PMTFREQ   freq,
*                                    PLAN_STR* loads,
*                                    BOOLE     dom) ;
*
*   general      This routine sets the members of the struct defined
*                in the function name. The pointer members are simply
*                assigned - without physical copying. The intention
*                of the Set_*() routines is that by using this
*                functionality, one avoids setting individual members
*                of structs in the application code.
*
*                When new members are inserted in structs the Set_*()
*                routine will be changed accordingly.
*
*                One exception to this principle applies. Whenever
*                OPTADD and vanilla members are used, only the
*                vanilla members are set in the Set_*() routines. The
*                non-vanilla and exotic members are set to defaults,
*                and must be set elsewhere - if needed.
*
*                For details on the interpretation of the individual
*                struct members please check the struct definition.
*
*   input        KEYCONV   key   See general section.
*
*                RISKCONV  risk  See general section.
*
*                FL64      shock See general section.
*
*                IRRCONV   irr   See general section.
*
*                PMTFREQ   freq  See general section.
*
*                PLAN_STR* loads See general section.
*
*                BOOLE     dom   See general section.
*
*   output
*
*   returns      The filled out RISKSET struct
*
*   diagnostics
*
*   see also     RISKSET
*
************************************************************************
,,EOH,,*/

RISKSET Set_RISKSET(KEYCONV key,
                         RISKCONV risk,
                         FL64     shock,
                         IRRCONV  irr,
                         PMTFREQ  freq,
                         PLAN_STR* loads,
                         BOOLE    dom)
{
    RISKSET r ;

    r.key   = key ;
    r.risk  = risk ;
    r.shock = shock ;
    r.irr   = irr ;
    r.freq  = freq ;
    r.loads = loads ;
    r.dom   = dom ;

    return r ;
}


/*,,SOH,,
************************************************************************
*
*                Set_DFPARMS()
*
*   interface    #include <disc.h>
*                DFPARMS Set_DFPARMS(DISCIPOL   what,
*                                    INTPOLCONV iconv,
*                                    CALCONV    cal,
*                                    IRRCONV    irr,
*                                    PMTFREQ    freq) ;
*
*   general      This routine sets the members of the struct defined
*                in the function name. The pointer members are simply
*                assigned - without physical copying. The intention
*                of the Set_*() routines is that by using this
*                functionality, one avoids setting individual members
*                of structs in the application code.
*
*                When new members are inserted in structs the Set_*()
*                routine will be changed accordingly.
*
*                One exception to this principle applies. Whenever
*                OPTADD and vanilla members are used, only the
*                vanilla members are set in the Set_*() routines. The
*                non-vanilla and exotic members are set to defaults,
*                and must be set elsewhere - if needed.
*
*                For details on the interpretation of the individual
*                struct members please check the struct definition.
*
*   input        DISCIPOL   what  See general section.
*
*                INTPOLCONV iconv See general section.
*
*                CALCONV    cal   See general section.
*
*                IRRCONV    irr   See general section.
*
*                PMTFREQ    freq  See general section.
*
*   output
*
*   returns      The filled out DFPARMS struct
*
*   diagnostics
*
*   see also     DFPARMS
*
************************************************************************
,,EOH,,*/

DFPARMS Set_DFPARMS(DISCIPOL what, INTPOLCONV iconv,
                         CALCONV cal, IRRCONV irr, PMTFREQ freq)
{
    DFPARMS dfp ;

    dfp.what  = what ;
    dfp.iconv = iconv ;
    dfp.cal   = cal ;
    dfp.irr   = irr ;
    dfp.freq  = freq ;

    return dfp ;
}


/*,,SOH,,
************************************************************************
*
*                Set_DELTASET()
*
*   interface    #include <disc.h>
*                DELTASET Set_DELTASET(PLANARRAY      shock,
*                                      INTI           nshock,
*                                      BOOLE          dom,
*                                      DFWHICH        dfwhich,
*                                      BOOLE          zero,
*                                      DATEARRAY      mid,
*                                      RISKTOKENARRAY token,
*                                      IRRCONV        irr,
*                                      PMTFREQ        freq,
*                                      FL64ARRAY      size) ;
*
*   general      This routine sets the members of the struct defined
*                in the function name. The pointer members are simply
*                assigned - without physical copying. The intention
*                of the Set_*() routines is that by using this
*                functionality, one avoids setting individual members
*                of structs in the application code.
*
*                When new members are inserted in structs the Set_*()
*                routine will be changed accordingly.
*
*                One exception to this principle applies. Whenever
*                OPTADD and vanilla members are used, only the
*                vanilla members are set in the Set_*() routines. The
*                non-vanilla and exotic members are set to defaults,
*                and must be set elsewhere - if needed.
*
*                For details on the interpretation of the individual
*                struct members please check the struct definition.
*
*   input        PLANARRAY      shock   See general section.
*
*                INTI           nshock  See general section.
*
*                BOOLE          dom     See general section.
*
*                DFWHICH        dfwhich See general section.
*
*                BOOLE          zero    See general section.
*
*                DATEARRAY      mid     See general section.
*
*                RISKTOKENARRAY token   See general section.
*
*                IRRCONV        irr     See general section.
*
*                PMTFREQ        freq    See general section.
*
*                FL64ARRAY      size    See general section.
*
*   output
*
*   returns      The filled out DELTASET struct
*
*   diagnostics
*
*   see also     DELTASET
*
************************************************************************
,,EOH,,*/

DELTASET Set_DELTASET(PLANARRAY shock,
                           INTI      nshock,
                           BOOLE     dom,
                           DFWHICH   dfwhich,
                           BOOLE     zero,
                           DATEARRAY mid,
                           RISKTOKENARRAY token,
                           IRRCONV   irr,
                           PMTFREQ   freq,
                           FL64ARRAY size)
{
    DELTASET ds ;

    ds.shock   = shock;
    ds.nshock  = nshock;
    ds.dom     = dom ;
    ds.dfwhich = dfwhich ;
    ds.zero    = zero ;
    ds.mid     = mid ;
    ds.token   = token ;
    ds.irr     = irr ;
    ds.freq    = freq ;
    ds.size    = size ;

    return ds ;
}


/*,,SOH,,
************************************************************************
*
*                Set_DFSPREAD()
*
*   interface    #include <disc.h>
*                DFSPREAD Set_DFSPREAD(FL64     spread,
*                                      IRRCONV  irr,
*                                      PMTFREQ  freq,
*                                      PLAN_STR *spr_list) ;
*
*   general      This routine sets the members of the struct defined
*                in the function name. The pointer members are simply
*                assigned - without physical copying. The intention
*                of the Set_*() routines is that by using this
*                functionality, one avoids setting individual members
*                of structs in the application code.
*
*                When new members are inserted in structs the Set_*()
*                routine will be changed accordingly.
*
*                For details on the interpretation of the individual
*                struct members please check the struct definition.
*
*   input        FL64     spread    See general section.
*
*                IRRCONV  irr       See general section.
*
*                PMTFREQ  freq      See general section.
*
*                PLAN_STR *spr_list See general section.
*
*   output
*
*   returns      The filled out DFSPREAD struct
*
*   diagnostics
*
*   see also     DFSPREAD
*
************************************************************************
,,EOH,,*/

DFSPREAD Set_DFSPREAD(FL64 spread, 
                         IRRCONV irr, 
                         PMTFREQ freq,
                         PLAN_STR* spr_list)
{
    DFSPREAD dfs ;

    dfs.spread = spread ;
    dfs.irr    = irr ;
    dfs.freq   = freq ;
    dfs.spr_list = spr_list ;

    return dfs ;
}



/*,,SOH,,
************************************************************************
*
*                Set_ZRATE_STR()
*
*   interface    #include <disc.h>
*                ZRATE_STR Set_ZRATE_STR(PERIOD* period,
*                                        FL64    rate,
*                                        IRRCONV irr,
*                                        PMTFREQ freq,
*                                        CALCONV cal,
*                                        BUSCONV bus,
*                                        EOMCONV eom) ;
*
*   general      This routine sets the members of the struct defined
*                in the function name. The pointer members are simply
*                assigned - without physical copying. The intention
*                of the Set_*() routines is that by using this
*                functionality, one avoids setting individual members
*                of structs in the application code.
*
*                When new members are inserted in structs the Set_*()
*                routine will be changed accordingly.
*
*                One exception to this principle applies. Whenever
*                OPTADD and vanilla members are used, only the
*                vanilla members are set in the Set_*() routines. The
*                non-vanilla and exotic members are set to defaults,
*                and must be set elsewhere - if needed.
*
*                For details on the interpretation of the individual
*                struct members please check the struct definition.
*
*   input        PERIOD* period See general section.
*
*                FL64    rate   See general section.
*
*                IRRCONV irr    See general section.
*
*                PMTFREQ freq   See general section.
*
*                CALCONV cal    See general section.
*
*                BUSCONV bus    See general section.
*
*                EOMCONV eom    See general section.
*
*   output
*
*   returns      The filled out ZRATE_STR struct
*
*   diagnostics
*
*   see also     ZRATE_STR
*
************************************************************************
,,EOH,,*/

ZRATE_STR Set_ZRATE_STR(PERIOD*  period, 
                             FL64       rate, 
                             IRRCONV    irr, 
                             PMTFREQ    freq,
                             CALCONV    cal,
                             BUSCONV    bus,
                             EOMCONV    eom)
{
    ZRATE_STR   zrate ;

    zrate.period = *period ;
    zrate.rate   = rate ;
    zrate.irr    = irr ;
    zrate.freq   = freq ;
    zrate.cal    = cal ;
    zrate.bus    = bus ;
    zrate.eom    = eom ;

    return zrate ;
}




#undef DISC_TOLR
#undef DAY_TOL
#undef IRR_ACC
#undef IRR_GUESS
#undef IRR_MIN
#undef IRR_MAX
#undef IRR_MAXIT
#undef IRR_FREQ
#undef IRR_DAMP
#undef REPAY_TOL  
#undef COUPON_TOL 


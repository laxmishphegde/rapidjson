/* SCID @(#)scmath.c	1.48 (SimCorp) 99/09/14 15:02:05 */

/************************************************************************
*
*   project     SCecon
*
*   filename    scmath.c
*
*   contains    Some Math Routines
*
************************************************************************/

/***** includes ********************************************************/
#include <scmath.h>
#include <scutl.h>
#include <float.h>

/***** defines  ********************************************************/
#define MAXIT     100
#define RATE_TOL  0.000001
#define VALUE_TOL 0.0000000001
#define ROUND_NOISE 1.0e-10
#define FLOOR_LIMIT 1.0e12
#define CUT_OFF   1.0e-20
#define DAY_TOL   0.001

#define SIGN(A,B) ((B) >= 0.0  ? SCecon_fabs(A) : -SCecon_fabs(A))
#define HYPOT(F,G) (sqrt((F)*(F)+(G)*(G)))



/************************************************************************
*
*               Math_linintpol()
*
*    interface  #include <scmath.h>
*               FL64 Math_linintpol(FL64  xlow,
*                                   FL64  xup,
*                                   FL64  ylow,
*                                   FL64  yup,
*                                   FL64  x0,
*                                   BOOLE extrapol) ;
*
*    general    The function performs linear interpolation with extra-
*               polation or flat ends. The interpolation is based on
*               lower and upper (x, y) values.
*
*    input      FL64  xlow      The lower x value.
*
*               FL64  xup       The upper x value (xup >= xlow)
*
*               FL64  ylow      The lower y value.
*
*               FL64  yup       The upper y value.
*
*               FL64  x0        The x value for which an interpolated
*                               y value is sought.
*
*               BOOLE extrapol  True or False
*
*    output
*
*    returns    The y value for x0.
*
*    diagnostics
*
*    see also
*
************************************************************************/


FL64 Math_linintpol(FL64 xlow,
                    FL64  xup,
                    FL64  ylow,
                    FL64  yup,
                    FL64  x0,
                    BOOLE extrapol)
{
    FL64 alpha, y0 ;

    if (x0 > xup && extrapol == False)
        return yup ;

    if (x0 <= xlow && extrapol == False)
        return ylow ;

    if (SCecon_fabs(xlow - xup) < RATE_TOL)
        return (ylow + yup)/2.0 ;

    alpha = (yup - ylow)/(xup - xlow) ;
    y0    = ylow + alpha * (x0 - xlow) ;

    return y0 ;
}


/*,,SOH,,
*************************************************************************
*
*               Math_IntpolArray()
*
*    interface  #include <scmath.h>
*               FL64ARRAY Math_IntpolArray(FL64ARRAY  x0,
*                                           INTI       m,
*                                           INTI       n,
*                                           FL64ARRAY  x,
*                                           FL64ARRAY  y,
*                                           INTPOLCONV conv) ;
*
*    general    The function performs interpolation according to
*               various conventions.
*
*               This function interpolates on a list of input values.
*
*    input      FL64ARRAY  x0   The x-values for which an interpolated
*                               y-value is sought.
*                               Dimension [m]
*
*               INTI       m    The number of elements in x0.
*
*               INTI       n    The number of corresponding (x, y)
*                               values.
*
*               FL64ARRAY  x    The x-values that are used in the
*                               interpolation.
*                               Must be sorted in ascending order and
*                               all values are distinct.
*                               Dimension [n]
*
*               FL64ARRAY  y    The y-values that are used in the
*                               interpolation.
*                               Dimension [n]
*
*               INTPOLCONV conv The interpolation convention.
*
*    output
*
*    returns    The interpolated values corresponding to x0.
*               Is allocated in this routine as Alloc_FL64ARRAY(m)
*
*    diagnostics
*
*    see also   Math_Interpolation()
*
*    wrapper    AP
*
*************************************************************************
,,EOH,,*/


FL64ARRAY Math_IntpolArray(FL64ARRAY x0,
                            INTI       m,
                            INTI       n,
                            FL64ARRAY  x,
                            FL64ARRAY  y,
                            INTPOLCONV conv)
{
    FL64ARRAY ay2, y0 ;
    INTI      j, i ;

    y0 = Alloc_FL64ARRAY(m) ;

    /* At first - the exceptions */
    if (n == 0)
        return y0 ;

    else if (n == 1)
    {
        for (i = 0 ; i < m ; i++)
            y0[i] = y[0] ;

        return y0;
    }

    switch (conv)
    {
        case LINEAR_EXTRAPOL:

            for (i = 0 ; i < m ; i++)
            {
                /* Case 1 - Below the lower end point  */

                if (x0[i] <= x[0])
                    y0[i] = Math_linintpol(x[0], x[1], y[0], y[1],
                                           x0[i], True) ;

                /* Case 2 - Above the upper end point  */
                else if (x0[i] >= x[n-1])
                    y0[i] = Math_linintpol(x[n-2], x[n-1], y[n-2], y[n-1],
                                           x0[i], True) ;

                /* Case 3 - in between 2 points */
                else
                {
                    for (j = 0 ; x[j] < x0[i] ; j++)
                        ;
                    y0[i] = Math_linintpol(x[j-1], x[j], y[j-1], y[j],
                                           x0[i], True) ;
                }
            }

            break ;

        case LINEAR_FLAT_END:

            for (i = 0 ; i < m ; i++)
            {
                /* Case 1 - Below the lower end point  */
                if (x0[i] <= x[0])
                    y0[i] = y[0] ;

                /* Case 2 - Above the upper end point  */
                else if (x0[i] >= x[n-1])
                    y0[i] = y[n-1] ;

                /* Case 3 - in between 2 points */
                else
                {
                    for (j = 0 ; x[j] < x0[i] ; j++)
                        ;
                    y0[i] = Math_linintpol(x[j-1], x[j], y[j-1], y[j],
                                           x0[i], False) ;
                }
            }

            break ;

        case EXCL_INCL:

            for (i = 0 ; i < m ; i++)
            {
                /* Case 1 - Below the lower end point  */
                if (x0[i] <= x[0])
                    y0[i] = y[0] ;

                /* Case 2 - Above the upper end point  */
                else if (x0[i] >= x[n-1])
                    y0[i] = y[n-1] ;

                /* Case 3 - in between 2 points */
                else
                {
                    for (j = 0 ; x[j] + VALUE_TOL <= x0[i] ; j++)
                        ;
                    y0[i] = y[j] ;
                }
            }

            break ;

        case INCL_EXCL:

            for (i = 0 ; i < m ; i++)
            {
                /* Case 1 - Below the lower end point  */
                if (x0[i] <= x[0])
                    y0[i] = y[0] ;

                /* Case 2 - Above the upper end point  */
                else if (x0[i] >= x[n-1])
                    y0[i] = y[n-1] ;

                /* Case 3 - in between 2 points */
                else
                {
                    for (j = 0 ; x[j] - VALUE_TOL < x0[i]; j++)
                        ;
                    y0[i] = y[j-1] ;
                }
            }

            break ;

        case CUBIC_SPLINE:

            ay2 = Alloc_FL64ARRAY(n) ;

            /* Use ZERO second order derivatives in the ends */
            Math_Cspl_Prep(x, y, n, SPLINE_MAX * 1.1, SPLINE_MAX * 1.1, ay2) ;

            for (i = 0 ; i < m ; i++)
                Math_Cspl_Intpol(x, y, ay2, n, x0[i], &y0[i]) ;

            Free_FL64ARRAY(ay2) ;

            break ;
    }

    return y0 ;
}


/*,,SOH,,
*************************************************************************
*
*               Math_Interpolation()
*
*    interface  #include <scmath.h>
*               FL64 Math_Interpolation(FL64       x0,
*                                       INTI       n,
*                                       FL64ARRAY  x,
*                                       FL64ARRAY  y,
*                                       INTPOLCONV conv) ;
*
*    general    The function performs interpolation according to
*               various conventions.
*
*               In this version only a single value is interpolated.
*
*    input      FL64       x0   The x-value for which an interpolated
*                               y-value is sought.
*
*               INTI       n    The number of corresponding (x, y)
*                               values.
*
*               FL64ARRAY  x    The x-values that are used in the
*                               interpolation.
*                               Must be sorted in ascending order and
*                               all values are distinct.
*
*               FL64ARRAY  y    The y-values that are used in the
*                               interpolation.
*
*               INTPOLCONV conv The interpolation convention.
*
*    output
*
*    returns    The interpolated value corresponding to x0.
*
*    diagnostics
*
*    see also   Math_IntpolArray()
*
*************************************************************************
,,EOH,,*/


FL64 Math_Interpolation(FL64    x0,
                        INTI       n,
                        FL64ARRAY  x,
                        FL64ARRAY  y,
                        INTPOLCONV conv)
{
    FL64ARRAY res ;
    FL64      a ;

    res = Math_IntpolArray(&x0, 1, n, x, y, conv) ;
    a   = res[0] ;
    Free_FL64ARRAY(res) ;

    return a ;
}


/*,,SOH,,
*************************************************************************
*
*               Math_2Dinterpolation()
*
*    interface  #include <scmath.h>
*               FL64 Math_2Dinterpolation(FL64       x10,
*                                         FL64       x20,
*                                         FL64ARRAY  x1,
*                                         INTI       nx1,
*                                         FL64ARRAY  x2,
*                                         INTI       nx2,
*                                         FL64MATRIX y,
*                                         INTPOLCONV conv) ;
*
*    general    The function performs interpolation according to
*               various conventions in 2 dimensions.
*
*               In this version only a single value is interpolated.
*
*    input      FL64       x10  The x1-value for which an interpolated
*                               y-value is sought.
*
*               FL64       x20  The x2-value for which an interpolated
*                               y-value is sought.
*
*               FL64ARRAY  x1   The x1-values that are used in the
*                               interpolation.
*                               Must be sorted in ascending order and
*                               all values are distinct.
*                               Dimension [nx1]
*
*               INTI       nx1  The number of x1-values.
*
*               FL64ARRAY  x2   The x2-values that are used in the
*                               interpolation.
*                               Must be sorted in ascending order and
*                               all values are distinct.
*                               Dimension [nx2]
*
*               INTI       nx2  The number of x2-values.
*
*               FL64MATRIX y    The y-values that are used in the
*                               interpolation. y = f(x1, x2).
*                               Dimension [nx1,nx2]
*
*               INTPOLCONV conv The interpolation convention. Must be
*                               CUBIC_SPLINE or LINEAR_EXTRAPOL.
*
*    output
*
*    returns    The interpolated value corresponding to (x1, x2).
*
*    diagnostics
*
*    see also   Math_Interpolation()
*
*    wrapper    AP
*
*************************************************************************
,,EOH,,*/


FL64 Math_2Dinterpolation(FL64    x10,
                          FL64       x20,
                          FL64ARRAY  x1,
                          INTI       nx1,
                          FL64ARRAY  x2,
                          INTI       nx2,
                          FL64MATRIX y,
                          INTPOLCONV conv)
{
    INTI       i, j ;
    FL64       a, y1, y2, y3, y4, t, u, x2l, x2u, x1l, x1u ;
    FL64MATRIX ddp ;
    FL64ARRAY  tmp1, tmp2 ;

    if (nx1 == 0 || nx2 == 0)
        return 0.0 ;

    if (nx1 == 1 || nx2 == 1)
        conv = LINEAR_EXTRAPOL ;

    if (conv == LINEAR_EXTRAPOL)
    {
        /* Find corner indices in x1 direction */
        for (i = 0; i < nx1 && x1[i] < x10 ; i++)
            ;

        i-- ;
        if (i == nx1 - 1)
           i-- ;

        i = GETMAX(0, i) ;
        x1u = x1l = x1[i] ;
        if (nx1 > 1)
            x1u = x1[i + 1] ;

        /* Find corner indices in x2 direction */
        for (j = 0; j < nx2 && x2[j] < x20 ; j++)
            ;
        j-- ;
        if (j == nx2 - 1)
           j-- ;
        j = GETMAX(0, j) ;
        x2u = x2l = x2[j] ;
        if (nx2 > 1)
            x2u = x2[j + 1] ;

        /* Interpolate */
        y4 = y3 = y2 = y1 = y[i][j] ;
        if (nx1 > 1)
            y2 = y[i + 1][j] ;
        if (nx2 > 1 && nx1 > 1)
            y3 = y[i + 1][j + 1] ;
        if (nx2 > 1)
            y4 = y[i][j + 1] ;

        t = x1u - x1l ;
        if (SCecon_fabs(t) > VALUE_TOL)
            t = (x10 - x1l) / t ;
        else
            t = 0.0 ;

        u = x2u - x2l ;
        if (SCecon_fabs(u) > VALUE_TOL)
            u = (x20 - x2l) / u ;
        else
            u = 0.0 ;

        a  = (1.0 - t) * (1.0 - u) * y1 + t * (1.0 - u) * y2 +
             t * u * y3 + (1.0 - t) * u * y4 ;
    }
    else
    {
        /* Do Bicubic Splining. */

        ddp  = Alloc_FL64MATRIX(nx1, nx2) ;
        tmp1 = Alloc_FL64ARRAY(nx1) ;
        tmp2 = Alloc_FL64ARRAY(nx1) ;

        /* First interpolate in the x2 - direction */
        for (j = 0; j < nx1; j++)
            Math_Cspl_Prep(x2, y[j], nx2, 1.1 * SPLINE_MAX,
                           1.1 * SPLINE_MAX, ddp[j]) ;

        for (j = 0; j < nx1; j++)
            Math_Cspl_Intpol(x2, y[j], ddp[j], nx2, x20, &tmp1[j]) ;

        /* Next interpolate in the x1 - direction */
        Math_Cspl_Prep(x1, tmp1, nx1, 1.1 * SPLINE_MAX, 1.1 * SPLINE_MAX, tmp2);
        Math_Cspl_Intpol(x1, tmp1, tmp2, nx1, x10, &a) ;

        Free_FL64MATRIX(ddp) ;
        Free_FL64ARRAY(tmp1) ;
        Free_FL64ARRAY(tmp2) ;
    }

    return a ;
}


/*****************************************************************************
*
*               Math_Cspl_Prep()
*
*    interface  #include <scmath.h>
*
*               void Math_Cspl_Prep(FL64ARRAY x, FL64ARRAY y, INTI n,
*                                   FL64 dy1, FL64 dyn, FL64ARRAY ddy) ;
*
*    general    Given arrays x and y containing a tabulated
*               function, i.e.
*                      y(i) = f(x(i))
*               where
*                      x(i) < x(i + 1)
*               and given values dy1 and dyn for the first derivative of
*               the interpolating function at points 1 and n respectively,
*               this routine returns an array ddy that contains the
*               second derivatives of the interpolating function at the
*               tabulated points x(i).
*
*               If yp1 and/or ypn are equal to SPLINE_MAX or larger, the
*               routine is signalled to set the corresponding boundary
*               condition for a natural spline, with zero second order
*               derivative at that boundary.
*
*               The function allocates a temporary array of size n-1. This
*               array is freed upon completion of the sorting.
*
*    input      FL64ARRAY x    Array of X-axis values
*
*               FL64ARRAY y    Array of Y = f(x) values
*
*               INTI  n        size of x and y (at least 2)
*
*               FL64    dy1    First order derivative in x[0]
*
*               FL64    dyn    First order derivative in x[n-1]
*
*    output     FL64ARRAY ddy  Pointer to second order derivatives for y
*
*    returns
*
*    diagnostics
*
*    see also   Math_Cspl_Intpol()
*
*****************************************************************************/


void Math_Cspl_Prep(FL64ARRAY x,
                  FL64ARRAY y,
                  INTI      n,
                  FL64      dy1,
                  FL64      dyn,
                  FL64ARRAY ddy)
{
    INTI      i ;
    FL64      denom, betan, gamman, *gamma ;
    FL64      denom1, denom2 ;

    denom1 = denom2 = 0.0 ;

    denom = betan = gamman = 0.0 ;

    gamma = Alloc_FL64ARRAY(n - 1) ;

    /* One should not be confused by the fact that in the following ddy[]
       is used to store some intermediate results (to save memory)   */

    /* The lower boundary condition is set "natural" */
    if (dy1 > SPLINE_MAX)
        ddy[0] = gamma[0] = 0.0 ;

    else
    {      
        /* or to have specified first derivative */
        ddy[0] = -0.5 ;
        denom = x[1] - x[0] ;
        gamma[0] = SafeDivide(3.0, denom, RATE_TOL, 1.0) ;
        gamma[0] *= (SafeDivide(y[1]-y[0], denom, RATE_TOL, 1.0) - dy1) ; 
        /*gamma[0] = (3.0 / (x[1]-x[0])) * ((y[1]-y[0]) / (x[1]-x[0])-dy1);*/
    }

    /* Here we store the coefficients of the equivalent linear system with
       only TWO variables in each equation (ddy stores the coefficient, beta,
       of the linear piece).  */
    for (i = 1 ; i < n - 1 ; i++)
    {
        denom   = 2.0 * (x[i+1] - x[i-1]) + (x[i] - x[i-1]) * ddy[i-1] ;
        ddy[i] = - SafeDivide(x[i+1] - x[i], denom, RATE_TOL, 1.0) ;
        denom1 = x[i+1] - x[i] ;
        denom2 = x[i] - x[i-1] ;
        gamma[i] = SafeDivide(y[i+1] - y[i], denom1, RATE_TOL, 1.0) ;
        gamma[i] -= SafeDivide(y[i] - y[i-1], denom2, RATE_TOL, 1.0) ;
        gamma[i]  = SafeDivide(6.0 * gamma[i] - denom2 * gamma[i-1],
                               denom, RATE_TOL, 1.0) ;
        /*gamma[i] = (y[i+1]-y[i])/(x[i+1]-x[i])-(y[i]-y[i-1])/(x[i]-x[i-1]); 
        gamma[i]  = (6.0 * gamma[i] - (x[i] - x[i-1]) * gamma[i-1]) / denom ;*/
    }

    /* Upper boundary is set "natural" */
    if (dyn > SPLINE_MAX)
        betan = gamman = 0.0 ;
    else
    {
        /* or to have specified first derivative */
        betan = 0.5 ;
        denom = x[n-1] - x[n-2] ;
        gamman = SafeDivide(3.0, denom, RATE_TOL, 1.0) ;
        gamman *= (dyn - SafeDivide(y[n-1] - y[n-2], denom, RATE_TOL, 1.0)) ;
        /*gamman=(3.0/(x[n-1]-x[n-2]))*(dyn-(y[n-1]-y[n-2])/(x[n-1]-x[n-2]));*/
    }
    /* Compute the n'th value of ddy first */
    denom = betan * ddy[n-2] + 1.0 ;
    ddy[n-1] = SafeDivide(gamman - betan * gamma[n-2], denom, RATE_TOL, 1.0) ;
    /* ddy[n-1] = (gamman - betan * gamma[n-2]) / (betan * ddy[n-2] + 1.0); */

    /* and solve the simpler linear system by back substitution */
    for (i = n - 2 ; i >= 0 ; i--)
        ddy[i] = ddy[i] * ddy[i+1] + gamma[i] ;

    Free_FL64ARRAY(gamma) ;
}


/*****************************************************************************
*
*               Math_Cspl_Intpol()
*
*    interface  #include <scmath.h>
*
*               void Math_Cspl_Intpol(FL64ARRAY xdef,
*                                     FL64ARRAY ydef,
*                                     FL64ARRAY ddy,
*                                     INTI      n,
*                                     FL64      x,
*                                     FL64      *y) ;
*
*    general    Given arrays xdef and ydef which tabulate
*               a function (with the xdef's in order) and given the
*               array ddy which is the output from Math_Cspl_Prep,
*               and given a value of x, this routine returns a
*               cubic-spline interpolated value y.
*
*    input      FL64ARRAY xdef X-axis array, must be ordered
*                              ascendingly and be distinct.
*                              If not the result will be zero.
*
*               FL64ARRAY ydef F(xdef) array
*
*               FL64ARRAY ddy  Array of 2. order derivatives as output from
*                              Math_Cspl_Prep()
*
*               INTI  n      size of arrays (at least 2)
*
*               FL64    x    X value
*
*    output     FL64    *y   pointer to output value (see also under *xdef).
*
*    returns
*
*    diagnostics
*
*    see also   Math_Cspl_Prep()
*
*****************************************************************************/

void Math_Cspl_Intpol(FL64ARRAY xdef, FL64ARRAY ydef, FL64ARRAY ddy, INTI n,
                         FL64 x, FL64* y)
{
    INTI    i, i0, in ;
    FL64    xdiff, xup, xdown ;

    xdiff = xup = xdown = 0.0 ;

    /* First we need to find out in which interval x lies.
       For this we use bisection. */

    i0 = 0 ;
    in = n - 1 ;
    while (in - i0 > 1)
    {
        i = (in + i0) >> 1 ;
        if (xdef[i] > x)
            in = i ;
        else
            i0 = i ;
    }

    /* Okay x lies between xdef[i0] and xdef[in] */
    xdiff = xdef[in] - xdef[i0] ;

    /* The xdef's must be distinct */
    xup = (SCecon_fabs(xdiff) > VALUE_TOL ? (xdef[in] - x)/xdiff : 0.0) ;
    xdown = (SCecon_fabs(xdiff) > VALUE_TOL ? (x - xdef[i0])/xdiff : 0.0) ;

    /* Cubic spline polynomial is now evaluated */
    *y = xup * ydef[i0] + xdown * ydef[in]
         + ((xup*xup*xup - xup) * ddy[i0]
         + (xdown*xdown*xdown - xdown) * ddy[in]) * (xdiff*xdiff) / 6.0 ;
}


/*,,SOH,,
*************************************************************************
*
*               Math_WeightedAvg()
*
*    interface  #include <scmath.h>
*               FL64 Math_WeightedAvg(INTI      n,
*                                      FL64ARRAY val,
*                                      FL64ARRAY wght) ;
*
*    general    The function computes the weighted average of value
*               and weight.
*
*    input      INTI      n      The number of elements in value and
*                                weight.
*
*               FL64ARRAY val    Array of values to be weighted.
*
*               FL64ARRAY wght   Array of weights.
*
*    output
*
*    returns    The weighted average as FL64.
*
*    diagnostics
*
*    see also
*
*************************************************************************
,,EOH,,*/


FL64    Math_WeightedAvg(INTI  n,
                          FL64ARRAY val,
                          FL64ARRAY wght)
{
    INTI    i ;
    FL64    sum, wa ;

    sum = wa = 0.0 ;
    for (i = 0 ; i < n ; i++)
    {
        wa  += val[i] * wght[i] ;
        sum += wght[i] ;
    }
    wa = (SCecon_fabs(sum) > VALUE_TOL ? (wa/sum) : 0.0) ;

    return wa ;
}

/*,,SOH,,
*************************************************************************
*
*               Math_SVD()
*
*    interface  #include <scmath.h>
*               BOOLE Math_SVD(FL64MATRIX a1,
*                              INTI       m,
*                              INTI       n,
*                              INTI       maxit,
*                              FL64ARRAY  pw1,
*                              FL64MATRIX v1) ;
*
*    general    The function computes the singular value decomposition
*               of a matrix a. Sometimes this is always referred to as
*               principal components analysis.
*
*               The SVD is defined by:
*
*                                    T
*                      A = U * W * V
*
*               Where U and V are orthonormal matrices. W is diagonal
*               with the singular values sorted descendingly on the
*               diagonal.
*
*               On exit the U matrix is in a, and the W and V matrices
*               are in w and v.
*
*               Note that m >= n is required, otherwise False is retur-
*               ned. Also the routine might not converge, and False is
*               returned.
*               In the first case append dummy 0 rows to a. In the se-
*               cond case try to increase maxit.
*
*               A good default value for maxit is 30 (for practical
*               purposes this always works).
*
*    input      FL64MATRIX a1    The input matrix. Zero offset in both
*                                dimensions. Allocated as
*                                Alloc_FL64MATRIX(m, n), ie. m rows
*                                and n columns.
*
*               INTI       m     The number of elements in value and
*
*               INTI       n     The number of elements in value and
*
*               INTI       maxit The number of iterations (use 30).
*
*    output     FL64ARRAY  pw1   The matrix holding the singular
*                                values at exit. Preallocated as
*                                Alloc_FL64ARRAY(n),
*                                ie, with m elements
*
*               FL64MATRIX v1    Zero offset in both  dimensions.
*                                Allocated as
*                                Alloc_FL64MATRIX(n, n), ie. n rows
*                                and n columns.
*
*    returns    True if all is OK, False if not.
*
*    diagnostics
*
*    see also
*
*************************************************************************
,,EOH,,*/

BOOLE Math_SVD(FL64MATRIX a1, 
                  INTI m, 
                  INTI n, 
                  INTI maxit,
                  FL64ARRAY pw1, 
                  FL64MATRIX v1)
{
    INTI       split, num_it, i, j, k, l, p, q ;
    FL64       u, w, h, t, d, x, y ;
    FL64       tmp, tmp1, r, g, e ;
    FL64       *sing_val, *nvec ;
    FL64MATRIX a, v ;
    INTIARRAY  index ;
    BOOLE      ok ;

    /* warning avoidance */
    k = q = 0 ;

    /* Error: Augment A with extra rows */
    if (m < n)
        return False ;

    /* Initialisation */
    r = g = e = 0.0 ;
    ok = True ;

    nvec     = Alloc_FL64ARRAY(n + 1) ;
    sing_val = Alloc_FL64ARRAY(n + 1) ;
    a        = Alloc_FL64MATRIX(m + 1, n + 1) ;
    v        = Alloc_FL64MATRIX(n + 1, n + 1) ;

    /* Copy over from input array into UNIT offset arrays */
    for (i = 0 ; i < m ; i++)
    {
        for (j = 0 ; j < n ; j++)
        {
            tmp = a1[i][j] ;
            a[i + 1][j + 1] = tmp ;
        }
    }

    /* HOUSEHOLDER reduction */
    for (i = 1 ; i <= n ; i++)
    {
        k = i + 1 ;
        nvec[i] = e * g ;
        g = t = e = 0.0 ;
        if (i <= m)
        {
            for (j = i ; j <= m ; j++)
                  e += SCecon_fabs(a[j][i]) ;
            if (e)
            {
                for (j = i ; j <= m ; j++)
                {
                      tmp = a[j][i] ;
                      a[j][i] = tmp / e ;

                      tmp = a[j][i] ;
                      t  += tmp * tmp ;
                }

                w = a[i][i] ;
                g = -SIGN(sqrt(t),w) ;
                h = w * g - t ;
                a[i][i] = w - g ;

                if (i != n)
                {
                    for (l = k ; l <= n ; l++)
                    {
                        for (t = 0.0, j = i ; j <= m ; j++)
                        {
                              tmp  = a[j][i] ;
                              tmp *= a[j][l] ;
                              t   += tmp ;
                        }
                        w = t/h ;
                        for (j = i ; j <= m ; j++)
                        {
                              tmp  = a[j][i] ;
                              tmp1 = a[j][l] ;
                              a[j][l] = tmp1 + w * tmp ;
                        }
                    }
                }
                for (j = i ; j <= m ; j++)
                {
                      tmp  = a[j][i] ;
                      a[j][i] = tmp * e ;
                }
            }
        }
        sing_val[i] = e * g ;
        g = t = e = 0.0 ;
        if (i <= m && i != n)
        {
            for (j = k ; j <= n ; j++)
            {
                  tmp = a[i][j] ;
                  e  += SCecon_fabs(tmp) ;
            }
            if (e)
            {
                for (j = k ; j <= n ; j++)
                {
                      tmp = a[i][j] / e ;
                      a[i][j] = tmp ;
                      t += tmp * tmp ;
                }

                w = a[i][k] ;
                g = -SIGN(sqrt(t),w) ;
                h = w * g - t ;
                a[i][k] = w - g ;
                for (j = k ; j <= n ; j++)
                {
                    tmp    = a[i][j] ;
                    nvec[j] = tmp / h ;
                }

                if (i != m)
                {
                    for (l = k ; l <= m ; l++)
                    {
                        for (t = 0.0, j = k ; j <= n ; j++)
                        {
                              tmp  = a[l][j] ;
                              tmp1 = a[i][j] ;
                              t   += tmp * tmp1 ;
                        }
                        for (j = k ; j <= n ; j++)
                        {
                              tmp  = a[l][j] ;
                              a[l][j] = tmp+t*nvec[j] ;
                        }
                    }
                }

                for (j = k ; j <= n ; j++)
                {
                    tmp  = a[i][j] * e ;
                    a[i][j] = tmp ;
                }
            }
        }
        r = GETMAX(r, SCecon_fabs(sing_val[i])+SCecon_fabs(nvec[i]) ) ;
    }

    /* Accumulation of right hand side transforms */
    for (i = n ; i >= 1 ; i--)
    {
        if (i < n)
        {
            if (g)
            {
                for (l = k ; l <= n ; l++)
                {
                    tmp  = a[i][l] ;
                    tmp1 = a[i][k] ;
                    v[l][i] = (tmp / tmp1) / g ;
                }

                for (l = k ; l <= n ; l++)
                {
                    for (t = 0.0, j = k ; j <= n ; j++)
                    {
                        tmp  = a[i][j] ;
                        tmp1 = v[j][l] ;
                        t   += tmp * tmp1 ;
                    }
                    for (j = k ; j <= n ; j++)
                    {
                        tmp  = v[j][i] ;
                        tmp1 = v[j][l] ;
                        v[j][l] = tmp1 + t * tmp ;
                    }
                }
            }
            for (l = k ; l <= n ; l++)
            {
                v[i][l] = 0.0 ;
                v[l][i] = 0.0 ;
            }
        }
        v[i][i] = 1.0 ;
        g = nvec[i] ;
        k = i ;
    }

    for (i = n ; i >= 1 ; i--)
    {
        k = i + 1 ;
        g = sing_val[i] ;
        if (i < n)
            for (l = k ; l <= n ; l++)
                a[i][l] = 0.0 ;

        if (g)
        {
            g = 1.0 / g ;
            if (i != n)
            {
                for (l = k ; l <= n ; l++)
                {
                    for (t = 0.0, j = k ; j <= m ; j++)
                    {
                        tmp  = a[j][i] ;
                        tmp1 = a[j][l] ;
                        t   += tmp * tmp1 ;
                    }

                    tmp  = a[i][i] ;
                    w    = (t / tmp) * g ;
                    for (j = i ; j <= m ; j++)
                    {
                        tmp  = a[j][i] ;
                        tmp1 = a[j][l] ;
                        a[j][l] = tmp1 + tmp * w ;
                    }
                }
            }
            for (l = i ; l <= m ; l++)
            {
                tmp = a[l][i] ;
                a[l][i] = tmp * g ;
            }
        }
        else
        {
            for (l = i ; l <= m ; l++)
              a[l][i] = 0.0 ;
        }

        /* ++a[i][i] */
        tmp = a[i][i] ;
        a[i][i] = tmp + 1.0 ;
    }

    /* Diagonalization of the bidiagonal form */

    /* Loop over singular values */
    for (j = n ; ok == True && j >= 1 ; j--)
    {
        /* Loop over allowed iterations */
        for (num_it = 1 ; ok == True && num_it <= maxit ; num_it++)
        {
            split = 1 ;

            /* Test for splitting */
            for (k = j ; k >= 1 ; k--)
            {
                q = k - 1 ;

                if (SCecon_fabs(nvec[k])+r == r)
                {
                    split = 0 ;
                    break ;
                }
                if (SCecon_fabs(sing_val[q])+r == r)
                    break ;
            }
            if (split)
            {
                u = 0.0 ;
                t = 1.0 ;

                for (i = k ; i <= j ; i++)
                {
                    w = t * nvec[i] ;
                    if (SCecon_fabs(w)+r != r)
                    {
                        g = sing_val[i] ;
                        h = HYPOT(w, g) ;
                        sing_val[i] = h ;
                        h = 1.0 / h ;
                        u = g * h ;
                        t = (-w * h) ;
                        for (l = 1 ; l <= m ; l++)
                        {
                            x = a[l][q] ;
                            y = a[l][i] ;
                            a[l][q] = x * u + y * t ;
                            a[l][i] = y * u - x * t ;
                        }
                    }
                }
            }
            y = sing_val[j] ;

            if (k == j)
            { /* convergence */
                if (y < 0.0)
                { /* singular value made nonnegative */
                    sing_val[j] = -y ;
                    for (l = 1 ; l <= n ; l++)
                    {
                        tmp = v[l][j] ;
                        v[l][j] = - tmp ;
                    }
                }
                break ;
            }

            if (num_it == maxit)
                ok = False ;

            d  = sing_val[k] ;
            q = j - 1 ;
            x = sing_val[q] ;
            g = nvec[q] ;
            h = nvec[j] ;
            w = ((x-y)*(x+y) + (g-h)*(g+h))/(2.0*h*x) ;
            g = HYPOT(w,1.0) ;
            w = ((d-y)*(d+y) + h*((x/(w+SIGN(g,w)))-h))/d ;

            u = t = 1.0 ;
            for (l = k ; l <= q ; l++)
            {
                i = l + 1 ;
                g = nvec[i] ;
                x = sing_val[i] ;
                h = t*g ;
                g = u*g ;
                y = HYPOT(w,h) ;
                nvec[l] = y ;
                u = w/y ;
                t = h/y ;
                w = d*u + g*t ;
                g = g*u - d*t ;
                h = x*t ;
                x = x*u ;
                for (p = 1 ; p <= n ; p++)
                {
                      d = v[p][l] ;
                      y = v[p][i] ;
                      v[p][l] = d * u + y * t ;
                      v[p][i] = y * u - d * t ;
                }
                y = HYPOT(w,h) ;

                sing_val[l] = y ;
                if (y)
                {
                    y = 1.0/y ;
                    u = w*y ;
                    t = h*y ;
                }
                w = (u*g) + (t*x) ;
                d = (u*x) - (t*g) ;
                for (p = 1 ; p <= m ; p++)
                {
                      x = a[p][l] ;
                      y = a[p][i] ;
                      a[p][l] = x * u + y * t ;
                      a[p][i] = y * u - x * t ;
                }
            }
            nvec[k] = 0.0 ;
            nvec[j] = w ;
            sing_val[j] = d ;
        }
    }

    /* SVD is finished - Now prepare for returning */
    if (ok == True)
    {
        /* Copy over into ZERO offset arrays */
        for (i = 0 ; i < m ; i++)
        {
            for (j = 0 ; j < n ; j++)
            {
                tmp = a[i + 1][j + 1] ;
                a1[i][j] = tmp ;
            }
        }

        for (i = 0 ; i < n ; i++)
        {
            pw1[i] = sing_val[i + 1] ;

            for (j = 0 ; j < n ; j++)
            {
                tmp = v[i + 1][j + 1] ;
                v1[i][j] = tmp ;
            }
        }

        /* Sort it all */
        index = Scutl_Indexx_FL64(n, sing_val, DESCENDING) ;

        /* Do the permutations */
        Scutl_Permute_FL64(n, index, sing_val) ;

        for (i = 0 ; i < m ; i++)
            Scutl_Permute_FL64(n, index, a[i]) ;

        for (i = 0 ; i < n ; i++)
            Scutl_Permute_FL64(n, index, v[i]) ;

        Free_INTIARRAY(index) ;
    }

    /* Clean up */
    Free_FL64ARRAY(nvec) ;
    Free_FL64ARRAY(sing_val) ;
    Free_FL64MATRIX(a) ;
    Free_FL64MATRIX(v) ;

    return ok ;
}

/*
..private - unit offset
*/

void Math_LUsolv(FL64MATRIX a,  /* LU decomposition of A */
            INTI  n,          /* Size of A */
            INTIARRAY perm,   /* permutation vector as output from LUdecomp */
            FL64ARRAY b)      /* Right hand side - return solution vector */
{
    INTI  i, j, i0, idx ;
    FL64    elem ;

    /* Initialisation */
    i0 = 0 ;
    elem = 0.0 ;

    /* Here we do the forward substitution */
    for (i = 1; i <= n ; i++)
    {
        /* First we must undo the permutation */
        idx    = perm[i] ;
        elem   = b[idx] ;
        b[idx] = b[i] ;

        /* Have we found any non-zero elements of b[] sofar? */
        if (i0 != 0)
        {
            for (j = i0 ; j < i ;j++)
                elem -= a[i][j] * b[j] ;
        }

        /* Update i0 if this element is non-zero */
        else if (elem != 0.0)
            i0 = i ;

        /* Save the element in b[] */
        b[i] = elem ;
    }

    /* Now we do the backward substitution */
    for (i = n ; i >= 1 ; i--)
    {
        elem = b[i] ;
        for (j = i + 1 ; j <= n ; j++)
            elem -= a[i][j] * b[j] ;

        b[i] = elem / a[i][i] ;
    }
}

/*
..private - unit offset
*/

BOOLE Math_LUdecomp(FL64MATRIX a,/* On input  coefficient matrix,
                                       output as LU deco */
             INTI       n,          /* Size of a */
             INTIARRAY  perm,       /* permutation vector */
             FL64*       parity)    /* (pointer to) parity of "perm" */
{
    INTI     i, i0, j, k ;
    FL64     max, x, elem ;
    FL64     *impl_scl ;
    BOOLE    ok ;

    /* Initialize variables */
    i0 = 0 ;
    *parity = 1.0;
    max  = x = elem = 0.0 ;
    ok   = True ;

    impl_scl = Alloc_FL64ARRAY(n + 1) ;

    /* We begin by getting the implicit scaling factors */
    for (i = 1 ; i <= n ; i++)
    {
        max = 0.0 ;
        /* Loop over elements of i'th row */
        for (j = 1 ; j <= n ; j++)
            if (SCecon_fabs(a[i][j]) > max)
                max = SCecon_fabs(a[i][j]);

        /* Check for singularity */
        if (max == 0.0)
        {
            Free_FL64ARRAY(impl_scl) ;
            return False ;
        }

        /* Save scaling for i'th row in impl_scl[i+1] */
        impl_scl[i] = 1.0 / max ;
    }

    /* Here comes Crout's method */
    for (j = 1 ; j <= n ; j++)
    {
        for (i = 1 ; i < j ; i++)
        {
            elem = a[i][j] ;
            for (k = 1 ; k < i ; k++)
                elem -= a[i][k] * a[k][j] ;

            a[i][j] = elem ;
        }

        /* Look for pivot */
        max = 0.0 ;

        for (i = j ; i <= n ; i++)
        {
            elem = a[i][j] ;
            for (k = 1 ; k < j ;k++)
                elem -= a[i][k] * a[k][j] ;

            a[i][j] = elem ;

            /* Update pivot */
            if ( (x = impl_scl[i] * SCecon_fabs(elem)) >= max)
            {
                max = x ;
                i0 = i ;
            }
        }

        if (j != i0)
        {
            for (k = 1 ; k <= n ; k++)
            {
                x        = a[i0][k] ;
                a[i0][k] = a[j][k] ;
                a[j][k] = x ;
            }

            /* update parity and scaling */
            *parity = -(*parity) ;
            impl_scl[i0] = impl_scl[j] ;
        }

        /* update permutation vactor */
        perm[j] = i0 ;
        if (a[j][j] == 0.0)
            a[j][j] = CUT_OFF ;

        /* Here we divide by the pivot */
        if (j != n)
        {
            x = 1.0 / a[j][j] ;

            for (i = j + 1 ; i <= n ; i++)
                a[i][j] *= x ;
        }
    }

    Free_FL64ARRAY(impl_scl) ;

    return ok ;
}



FL64 Math_Determinant(FL64MATRIX  m,
                           INTI        n)
{
  FL64       d;
  INTI       i, j;
  FL64MATRIX tmp;
  INTIARRAY  perm;

  tmp = Alloc_FL64MATRIX(n + 1, n + 1);
  perm = Alloc_INTIARRAY(n + 1);

  for (i = 0; i < n; i++)
    for (j = 0; j < n; j++)
      tmp[i + 1][j + 1] = m[i][j];

  d = 0.0;

  Math_LUdecomp(tmp, n, perm, &d);

  for (i = 0; i < n; i++)
    d *= tmp[i + 1][i + 1];


  Free_FL64MATRIX(tmp);
  Free_INTIARRAY(perm);

  return d;
}


/*,,SOH,,
*************************************************************************
*
*               Init_ITERCTRL()
*
*    interface  #include <scmath.h>
*               void Init_ITERCTRL(ITERCTRL *ictrl) ;
*
*    general    Initialises an iteration control struct for default
*               values.
*
*    input      ITERCTRL *ictrl  Iteration control struct
*
*    output
*
*    returns
*
*    diagnostics
*
*    see also
*
*************************************************************************
,,EOH,,*/


void Init_ITERCTRL(ITERCTRL* ictrl)
{
    ictrl->maxiter        = -1 ;
    ictrl->init_guess     = -1.0 ;
    ictrl->use_init_guess = False ;
    ictrl->lower          = -1.0 ;
    ictrl->use_lower      = False ;
    ictrl->upper          = -1.0 ;
    ictrl->use_upper      = False ;
    ictrl->damp           = -1.0 ;
    ictrl->acc            = -1.0 ;
    ictrl->what_acc       = -1 ;
    ictrl->gfreq          = -1 ;
    ictrl->bisec          = -1 ;
    ictrl->shock          = -1.0 ;
}


/*
..Dedicated to DF / TS Calculations
..Calculate B(k, p, t) -> k'th order spline for spline point p at time t.

..Assume that the knot points are non-negative - unique and sorted ascendingly

..p = -k,-k+1,...,0,...,n-1 -> n + k potential values

..t >= 0
..k >= 1 && n >= 1

..knots contains all predetermined plus auxiliary knot points. n are
  given in a userIF, and 2 * k defined elsewhere - outside of the range
  of the interpoaltion interval [a, b] -> say [0, 30] in TS context.
  This is the Cox - de Boer recursion formula which can be found in
  de Boer "A Practical Guide to Splines", Springer-Verlag, 1978
*/

FL64 Math_Intpol_Bspline(FL64   t,        /* time */
                         INTI      p,        /* Actual knot point */
                         INTI      k,        /* Spline Order */
                         INTI      n,        /* Number of given knot points */
                         INTI      dim,      /* size of knots */
                         FL64ARRAY knots)    /* should have n + 2 * k values */
{
    FL64 bpk, tmp ;
    INTI i, ix ;

    /* warning avoidance */
    bpk = 0 ;

    if (n < k || k < 1)
        return 0.0 ;

    ix = Scutl_Find_Termindex(knots, n + 2 * k, t, 0, SEARCH_FORWARDS,
                              NEXTINDEX) - 1 ;
    i = ix - k ;

    /* t is not allowed to be above knots[n + k - 1] */
    t = GETMIN(t, knots[n + k - 1]) ;

    /* Filter out the 0 case */
    if (i > p + k + 1 || i < p || ix < 0)
        return 0.0 ;

    /* Now we know that a value must be returned:
       Use Powell's recurrence algorithm */
    if (k == 1)
    {
        /* No recurrence - fix values */
        if (p != i && p != i - 1)
            bpk = 0.0 ;
        else if (p == i)
        {
            bpk  = (t - knots[ix]) / (knots[ix + 1] - knots[ix]) ;
            bpk /= (knots[ix + 2] - knots[ix]) ;
        }
        else if (p == i - 1)
        {
            bpk  = (knots[ix + 1] - t) / (knots[ix + 1] - knots[ix - 1]) ;
            bpk /= (knots[ix + 1] - knots[ix]) ;
        }
    }
    else
    {
        if (p + 2 * k + 1 >= dim)
            tmp = 0.0;
        else
            tmp = knots[p + 2 * k + 1] ;

        /* Use recurrence */
        bpk  = (t - knots[p + k]) *
               Math_Intpol_Bspline(t, p, k - 1, n, dim - 1, knots + 1) ;
        bpk += (tmp - t) *
               Math_Intpol_Bspline(t, p + 1, k - 1, n, dim - 1, knots + 1) ;
        bpk /= tmp - knots[p + k] ;
    }

    return bpk ;
}



/* Private ... Following de Boer */

/* FL64ARRAY Math_Diff_Bspline(INTI   difforder,   Order of the differentiation 
                            INTI      k,        Spline Order 
                            INTI      n,         Number of given knot points 
                            INTI*     dim,       size of knots 
                            FL64ARRAY knots,     time 
                            FL64ARRAY coefs)     should have n + 2 * k values 
{
  INTI      i, j ;

  newcoefs = Alloc_FL64ARRAY(n + 1) ;

  for (j = 0 ; j < difforder; j++)
  {
    dim = k - 1 ;
    newcoefs[0] = dim * (coefs[0]) / (knots[dim] - knots[0]) ;
    for (i = 1 ; i < n + 1 ; i++)
      newcoefs[i] = dim * (coefs[i] - coefs[i-1]) / (knots[i + dim] - 
                    knots[i]) ;
    newcoefs[n+1] = dim * (-coefs[n]) / (knots[n + 1 + dim] - 
                    knots[n + 1]) ;
  }

  return newcoefs ;
} */







/*
..
*/


INTI Scutl_Find_Termindex(FL64ARRAY terms,
                          INTI       count,
                          FL64       basisterm,
                          INTI       start,
                          SEARCHCONV conv,
                          INDEXCONV  iconv)
{
    INTI jm, jl, ju, uploop ;
    FL64 obasis ;

    /* First handle various standard situations */
    if (count == 0)
        return (iconv == PREVINDEX ? -1 : 0) ;

    if (basisterm < terms[0])
        return (iconv == PREVINDEX ? -1 : 0) ;

    /* Now search according to the NEXTINDEX convention. */
    obasis = basisterm ;
    basisterm += (iconv == NEXTINDEX ? DAY_TOL : (- DAY_TOL));

    switch (conv)
    {
        case SEARCH_BISECTION:

            jl = GETMAX(0, start - 1) ;
            ju = count ;
            while (ju - jl > 1)
            {
                jm = (jl + ju) >> 1 ;
                if (basisterm < terms[jm])
                    ju = jm ;
                else
                    jl = jm ;
            }
            break ;

        case SEARCH_FORWARDS:

            for (ju = GETMAX(0, start - 1) ; ju < count ; ju++)
                if (basisterm < terms[ju])  break ;
            break ;

        case SEARCH_BACKWARDS:

            uploop = GETMAX(0, start - 1) ;
            for (ju = count - 1; ju >= uploop ; ju--)
                if (basisterm >= terms[ju])  break ;
            ju++ ;
            break ;
        default:
            /* warning avoidance */
            ju = 0 ;
            break ;
    }
    /* Correct the result if iconv is not NEXTINDEX. */

    if (iconv == PREVINDEX)
        ju-- ;

    if (iconv == PREVINDEX && SCecon_fabs(obasis - terms[ju]) < DAY_TOL)
        ju-- ;

    if (iconv == SAMEINDEX && ju < count && ju > 1 &&
        SCecon_fabs(obasis - terms[ju - 2]) < DAY_TOL)
        ju-- ;

    if (iconv == SAMEINDEX && ju >= count &&
        SCecon_fabs(obasis - terms[count - 1]) < DAY_TOL)
        ju = count ;

    return ju ;
}


/*
..
*/

/* This function rounds 'x*limit' to nearest integer
   and returns the result divided by 'limit' */

FL64 Math_Floor(FL64  x, FL64  limit)
{
  FL64 tmp1, tmp2;

  tmp1 = x * limit;
  tmp2 = SCecon_floor(tmp1);
/*
printf("MF: x=%10.3lf, limit=%10.3le, tmp1=%10.3lf, "
       "tmp2=%10.3lf, d %d %lf\n", x, limit, tmp1, tmp2, tmp1-tmp2>=0.5, 
       tmp1-tmp2+0.5);
*/
  if (tmp1 - tmp2 >= 0.5)
    return (tmp2 + 1.0)/limit;
  else
    return tmp2/limit;

}

/* This function rounds 'x' to 'roundOff' places. 
   Note that only rounding can only be done within 
   10 significant digits. Remaining digits will be discarded
   in the rounding procedure!
*/
FL64 Math_Round(FL64  x, INTI  roundOff)
{
  FL64 round, scale, tmp, tmpx ;
  
  scale = pow(10.0, (FL64) roundOff) ;

  /* Take care of negative x's */
  tmpx = SCecon_fabs(x) ;

   /* First, round to 10 significant digits.
      This is necessary to avoid underflor/overflow, eg
      1.5 might really enter as 1.49999999999999 which rounds to 1.0
      rather than 2.0
    */
  tmp = Math_Floor(tmpx, FLOOR_LIMIT);

    /* Round the truncated 'tmp' to 'roundOff' places */
  round = (FL64) (SCecon_floor(
        0.5 + tmp * scale + ROUND_NOISE)) ;


  round = SafeDivide(round, scale, RATE_TOL, 0.0) ;
/*
printf("MR: tmpx=%10.8lf, tmp=%10.8lf, rnd=%10.8lf\n", tmpx, tmp, round);
*/
  /* Take care of negative x's */
  round = (x < -RATE_TOL ? - round : round) ;
  
  return round;
}




#define M1 259200L
#define IA1 7141L
#define IC1 54773L
#define RM1 (1.0/M1)
#define M2 134456L
#define IA2 8121L
#define IC2 28411L
#define RM2 (1.0/M2)
#define M3 243000L
#define IA3 4561L
#define IC3 51349L


/*
**********************************************************************
*
*                Math_Ran1()
*
*    interface   #include <scmath.h>
*
*                FL64 Math_Ran1(FL64    *idum, UN32 *ix1, UN32 *ix2,
*                             UN32 *ix3, FL32ARRAY r, BOOLE init,
*                             INTI count) ;
*
*    general     Generates a random number
*
*    input       FL64     *idum       Seed - only used when initializing
*                                     Set as (eg.) (FL64   ) time(&t) ;
*                BOOLE    init        Initialize variables if True
*
*                INTI    count        Size of the array 'r'.
*
*    output      UN32    *ix1         Seed first routine
*                                     Must be used in subsequent calls
*                UN32    *ix2         Seed second routine
*                                     Must be used in subsequent calls
*                UN32    *ix3         Seed third routine
*                                     Must be used in subsequent calls
*                FL32ARRAY r[count]   Unit offset array with 97
*                                     entries holding random numbers.
*                                     Set by this routine, but allocated
*                                     elsewhere with Alloc_FL32ARRAY()
*                                     Must be used in subsequent calls
*
*    returns     Random number between 0 and 1
*
*    diagnostics
*
*    see also
*
**********************************************************************/
FL64    Math_Ran1(FL64* idum, UN32* ix1, UN32* ix2,
             UN32* ix3, FL32ARRAY r, BOOLE init, INTI  count)
{
    FL32    temp ;
    INTI    j ;

    /* Initialize if .. */

    if (init == True)
    {
        *ix1   = (IC1 + (UN32)(*idum)) % M1 ; /* Seed first routine */
        *ix1   = (IA1 * (*ix1) + IC1) % M1 ;
        *ix2   = (*ix1) % M2 ;                 /* Use to seed second routine */
        *ix1   = (IA1 * (*ix1) + IC1) % M1 ;
        *ix3   = (*ix1) % M3 ;                 /* And the third routine */

        /* Fill table with sequential uniform deviates generated by the first
           two routines */

        for (j = 1 ; j <= count ; j++)
        {
            *ix1  = (IA1 * (*ix1) + IC1) % M1 ;
            *ix2  = (IA2 * (*ix2) + IC2) % M2 ;

            /* Low and high order pieces combined */
            r[j] = (FL32) ((*ix1 + *ix2 * RM2) * RM1) ;
        }
    }
    /* Start when not initializing. Generate next numbers */

    *ix1 = (IA1 * (*ix1) + IC1) % M1 ;
    *ix2 = (IA2 * (*ix2) + IC2) % M2 ;
    *ix3 = (IA3 * (*ix3) + IC3) % M3 ;
    j    = 1 + (INTI) ((count * (*ix3))/M3) ;
    /* Use third sequence to get number between 1 and 97 */

    temp  = r[j] ;
    r[j] = (FL32) ((*ix1 + *ix2 * RM2) * RM1) ; /* Refill entry */

    return (FL64) temp ;
}

#undef M1
#undef IA1
#undef IC1
#undef RM1
#undef M2
#undef IA2
#undef IC2
#undef RM2
#undef M3
#undef IA3
#undef IC3



/* Private ... This function multiplies two matrices, 
   A and B, of dimensions dim1 times dim2 and dim2 
   times dim3. Fills preallocated dim1 times dim3 
   matrix C */

void Math_Mult(FL64MATRIX a, FL64MATRIX b, INTI dim1, INTI dim2,
               INTI dim3, FL64MATRIX c)
{
  INTI i, j, k;

  for (i = 0; i < dim1; i++)
  for (j = 0; j < dim3; j++)
  {
    c[i][j] = 0.0 ; 
    for (k = 0; k < dim2; k ++)
      c[i][j] += a[i][k] * b[k][j];
    if (SCecon_fabs(c[i][j]) < ROUND_NOISE)
      c[i][j] = 0.0;
  }

  return ;
}


/* Private --- Find the inverse af an n times n matrix.
   See numerical recipes p. 48 */

FL64MATRIX Math_Inverse (FL64MATRIX a,  
                         INTI n)
{
  INTIARRAY perm;   
  FL64ARRAY b, col;
  FL64MATRIX y, a1;
  INTI i, j;

  b    = Alloc_FL64ARRAY(n+1);
  col  = Alloc_FL64ARRAY(n+1);
  y    = Alloc_FL64MATRIX(n, n);
  a1   = Alloc_FL64MATRIX(n+1, n+1);
  perm = Alloc_INTIARRAY(n+1);

    /* Make copy since the Math_LU* functions are unit offset */
  for (i = 0; i < n; i++)
    for (j = 0; j < n; j++)
      a1[i+1][j+1] = a[i][j];

  Math_LUdecomp(a1, n, perm, b);
  for (j = 1; j <= n; j++)
  {
    for (i = 1; i <= n; i++)
      col[i] = 0.0;
    col[j] = 1.0;
    Math_LUsolv(a1, n, perm, col);
    for (i = 1; i <= n; i++)
      y[i-1][j-1] = col[i];
  }
  
  Free_FL64ARRAY(b);
  Free_FL64ARRAY(col);
  Free_FL64MATRIX(a1); 
  Free_INTIARRAY(perm);

  return y;
}


/* Private -- Returns the transpose af an n times m matrix.*/ 

FL64MATRIX Math_Transpose(FL64MATRIX a,  
                          INTI n,
                          INTI m)
{
  FL64MATRIX trans ;
  INTI i, j ;

  trans = Alloc_FL64MATRIX(m, n);

  for (i = 0; i < n; i++)
    for (j = 0; j < m; j++)
     trans[j][i] = a[i][j] ;

  return trans ;

}


#undef SIGN
#undef HYPOT
#undef MAXIT
#undef RATE_TOL
#undef VALUE_TOL
#undef CUT_OFF
#undef DAY_TOL
#undef ROUND_NOISE



/*,,SOH,,
************************************************************************
*
*                Math_exp_cutoff()
*
*   interface    #include <scmath.h>
*                FL64 Math_exp_cutoff(FL64 x)
*
*   general      This routine computes the exponential function.
*                The return value is truncated to zero for small values
*                (less than -100) of the operand.
*                The return value is truncated to an upper bound for
*                large values (higher than 200) of the operand.
*                The upper bound is set to exp(200).
*
*   input        FL64   x         The operand.
*
*   output
*
*   returns      The exponential function of the operand.
*
*   diagnostics
*
*   see also     
*
************************************************************************
,,EOH,,*/
FL64 Math_exp_cutoff(FL64 x)
{
  if (x < -100.0)
    return 0.0;
  else if (x > 200.0)
    return exp(200.0);
  else
    return exp(x);
}


/*,,SOH,,
************************************************************************
*
*                Math_sqrt_cutoff()
*
*   interface    #include <scmath.h>
*                FL64 Math_sqrt_cutoff(FL64 x)
*
*   general      This routine computes the square root.
*                The return value is truncated to zero for negative 
*                values of the operand.
*
*   input        FL64   x         The operand.
*
*   output
*
*   returns      The square root function of the operand.
*
*   diagnostics
*
*   see also     
*
************************************************************************
,,EOH,,*/
FL64 Math_sqrt_cutoff(FL64 x)
{
  if (x < 0.0)
    return 0.0;
  else
    return sqrt(x);
}



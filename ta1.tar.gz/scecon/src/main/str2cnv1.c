/* SCID @(#)str2cnv1.c	1.2 (SimCorp) 99/02/19 14:16:42 */

/*********************************************************************
*                                                                     
*   Project     SCecon                                                
*                                                                     
*   file name   str2cnv1.c
*                                                                     
*   general     This file contains example code for routines that     
*               converts strings to conventions used by SCecon 
*               routines.
*                                                                     
**********************************************************************
*/

/* includes    *******************************************************/
#include <str2conv.h>

void BOOLE2Str(BOOLE  x, TEXT  txt)
{
    if (x == False)
        strcpy(txt, "FALSE");
    else if (x == True)
        strcpy(txt, "TRUE");
}


/*
..
*/


void TERMUNIT2Str(TERMUNIT u, char* s)
{
    if (u == DAYS)
        strcpy(s, "DAYS") ;
    else if (u == BUSDAYS)
        strcpy(s, "BUSDAYS") ;
    else if (u == WEEKS)
        strcpy(s, "WEEKS") ;
    else if (u == MONTHS)
        strcpy(s, "MONTHS") ;
    else if (u == YEARS)
        strcpy(s, "YEARS") ;
}


/*
..
*/

const VALIDATE_ST EV_ValidateTab[] = {
    { Valid_data,                                "VALID_DATA"                                 },
    { Invalid_accrfac,                           "INVALID_ACCRFAC"                            },
    { Invalid_accrfac_prepaid,                   "INVALID_ACCRFAC_PREPAID"                    },
    { Invalid_averaging,                         "INVALID_AVERAGING"                          },
    { Invalid_bondtype,                          "INVALID_BONDTYPE"                           },
    { Invalid_boole,                             "INVALID_BOOLE"                              },
    { Invalid_bp_tax,                            "INVALID_BP_TAX"                             },
    { Invalid_buy_date,                          "INVALID_BUY_DATE"                           },
    { Invalid_cal,                               "INVALID_CAL"                                },
    { Invalid_caldays,                           "INVALID_CALDAYS"                            },
    { Invalid_cb_accru,                          "INVALID_CB_ACCRU"                           },
    { Invalid_cbase,                             "INVALID_CBASE"                              },
    { Invalid_cbodd,                             "INVALID_CBODD"                              },
    { Invalid_cbodd_accru,                       "INVALID_CBODD_ACCRU"                        },
    { Invalid_compounding,                       "INVALID_COMPOUNDING"                        },
    { Invalid_conversion_factor,                 "INVALID_CONVERSION_FACTOR"                  },
    { Invalid_date,                              "INVALID_DATE"                               },
    { Invalid_datearray,                         "INVALID_DATEARRAY"                          },
    { Invalid_deliv,                             "INVALID_DELIV"                              },
    { Invalid_dex,                               "INVALID_DEX"                                },
    { Invalid_effective,                         "INVALID_EFFECTIVE"                          },
    { Invalid_eomconv,                           "INVALID_EOMCONV"                            },
    { Invalid_exdays,                            "INVALID_EXDAYS"                             },
    { Invalid_filled,                            "INVALID_FILLED"                             },
    { Invalid_first,                             "INVALID_FIRST"                              },
    { Invalid_fixing,                            "INVALID_FIXING"                             },
    { Invalid_fra,                               "INVALID_FRA"                                },
    { Invalid_freq,                              "INVALID_FREQ"                               },
    { Invalid_holpre,                            "INVALID_HOLPRE"                             },
    { Invalid_incl,                              "INVALID_INCL"                               },
    { Invalid_io,                                "INVALID_IO"                                 },
    { Invalid_irr,                               "INVALID_IRR"                                },
    { Invalid_irreg,                             "INVALID_IRREG"                              },
    { Invalid_jgb,                               "INVALID_JGB"                                },
    { Invalid_last,                              "INVALID_LAST"                               },
    { Invalid_lastaccr,                          "INVALID_LASTACCR"                           },
    { Invalid_matur,                             "INVALID_MATUR"                              },
    { Invalid_nirreg,                            "INVALID_NIRREG"                             },
    { Invalid_npday,                             "INVALID_NPDAY"                              },
    { Invalid_oddconv,                           "INVALID_ODDCONV"                            },
    { Invalid_optadd,                            "INVALID_OPTADD"                             },
    { Invalid_opttype,                           "INVALID_OPTTYPE"                            },
    { Invalid_paydayseq,                         "INVALID_PAYDAYSEQ"                          },
    { Invalid_paying,                            "INVALID_PAYING"                             },
    { Invalid_period,                            "INVALID_PERIOD"                             },
    { Invalid_pday,                              "INVALID_PDAY"                               },
    { Invalid_pp_price,                          "INVALID_PP_PRICE"                           },
    { Invalid_pre,                               "INVALID_PRE"                                },
    { Invalid_premiumtype,                       "INVALID_PREMIUMTYPE"                        },
    { Invalid_prepaid,                           "INVALID_PREPAID"                            },
    { Invalid_price_fra,                         "INVALID_PRICE_FRA"                          },
    { Invalid_price_irf,                         "INVALID_IRF"                                },
    { Invalid_qbas,                              "INVALID_QBAS"                               },
    { Invalid_qot,                               "INVALID_QOT"                                },
    { Invalid_repo_period,                       "INVALID_REPO_PERIOD"                        },
    { Invalid_schuldsch,                         "INVALID_SCHULDSCH"                          },
    { Invalid_seclast,                           "INVALID_SECLAST"                            },
    { Invalid_sell_date,                         "INVALID_SELL_DATE"                          },
    { Invalid_seqconv,                           "INVALID_SEQCONV"                            },
    { Invalid_settl,                             "INVALID_SETTL"                              },
    { Invalid_snap2,                             "INVALID_SNAP2"                              },
    { Invalid_tax_c,                             "INVALID_TAX_C"                              },
    { Invalid_sum,                               "INVALID_SUM"                                },
    { Invalid_tax_cg,                            "INVALID_TAX_CG"                             },
    { Invalid_teomatur,                          "INVALID_TEOMATUR"                           },
    { Invalid_term,                              "INVALID_TERM"                               },
    { Invalid_termunit,                          "INVALID_TERMUNIT"                           },
    { Invalid_xconv,                             "INVALID_XCONV"                              },
    { Invalid_xpday,                             "INVALID_XPDAY"                              },
    { Invalid_BRDfeb,                            "INVALID_BRDFEB"                             },
    { Invalid_CGB184,                            "INVALID_CGB184"                             },
    { Invalid_LIBOR_frequency,                   "INVALID_LIBOR_FREQUENCY"                    },
    { Invalid_LIBOR_period,                      "INVALID_LIBOR_PERIOD"                       },
    { Array_not_sorted,                          "ARRAY_NOT_SORTED"                           },
    { Array_empty,                               "ARRAY_EMPTY"                                },
    { Cday_last_not_equal_rday_last,             "CDAY_LAST_NOT_EQUAL_RDAY_LAST"              },
    { Days_not_sorted,                           "DAYS_NOT_SORTED"                            },
    { Days_not_unique,                           "DAYS_NOT_UNIQUE"                            },
    { Dex_after_cday_last,                       "DEX_AFTER_CDAY_LAST"                        },
    { Effective_after_first,                     "EFFECTIVE_AFTER_FIRST"                      },
    { Effective_after_lastaccr,                  "EFFECTIVE_AFTER_LASTACCR"                   },
    { Effective_later_than_stepcoup,             "EFFECTIVE_LATER_THAN_STEPCOUP"              },
    { First_after_first_irreg_day,               "FIRST_AFTER_FIRST_IRREG_DAY"                },
    { First_after_last,                          "FIRST_AFTER_LAST"                           },
    { First_disc_not_unity,                      "FIRST_DISC_NOT_UNITY"                       },
    { Last_after_last_irreg_day,                 "LAST_AFTER_LAST_IRREG_DAY"                  },
    { Last_date_in_day_later_than_cday_last,     "LAST_DATE_IN_DAY_LATER_THAN_CDAY_LAST"      },
    { Last_date_in_pday_later_than_cday_last,    "LAST_DATE_IN_PDAY_LATER_THAN_CDAY_LAST"     },
    { Last_date_in_xpday_later_than_cday_last,   "LAST_DATE_IN_XPDAY_LATER_THAN_CDAY_LAST"    },
    { Last_later_than_stepcoup,                  "LAST_LATER_THAN_STEPCOUP"                   },
    { Lastaccr_after_last,                       "LASTACCR_AFTER_LAST"                        },
    { Out_of_range,                              "OUT_OF_RANGE"                               },
    { Settl_after_matur,                         "SETTL_AFTER_MATUR"                          },
    { Teomatur_after_last,                       "TEOMATUR_AFTER_LAST"                        },
    { Xpday_after_pday,                          "XPDAY_AFTER_PDAY"                           },
    { Dpay_before_dfix,                          "DPAY_BEFORE_DFIX"                           },
    { Trade_after_settle,                        "TRADE_AFTER_SETTLE"                         },
    { Invalid_discipol,                          "INVALID_DISCIPOL"                           },
    { Invalid_intpolconv,                        "INVALID_INTPOLCONV"                         },
    { Invalid_irrconv,                           "INVALID_IRRCONV"                            },
    { Invalid_num_avg,                           "INVALID_NUM_AVG"                            },
    { Davg1_after_davgN,                         "DAVG1_AFTER_DAVGN"                          },
    { Invalid_alpha,                             "INVALID_ALPHA"                              },
    { Invalid_barrier,                           "INVALID_BARRIER"                            },
    { Invalid_gap,                               "INVALID_GAP"                                },
    { Invalid_scale,                             "INVALID_SCALE"                              },
    { Invalid_knocktype,                         "INVALID_KNOCKTYPE"                          },
    { Invalid_payoff,                            "INVALID_PAYOFF"                             },
    { Invalid_rebate,                            "INVALID_REBATE"                             },
    { Invalid_strike,                            "INVALID_STRIKE"                             },
    { Invalid_xtrem,                             "INVALID_XTREM"                              },
    { Invalid_prem,                              "INVALID_PREM"                               },
    { Dchoose_after_dfix,                        "DCHOOSE_AFTER_DFIX"                         },
    { DavgN_after_dfix,                          "DAVGN_AFTER_DFIX"                           },
    { Dset_after_dfix,                           "DSET_AFTER_DFIX"                            },
    { Matur_after_dfix,                          "MATUR_AFTER_DFIX"                           },
    { Wrong_sign_in_array,                       "WRONG_SIGN_IN_ARRAY"                        },
    { Invalid_coupon,                            "INVALID_COUPON"                             },
    { Invalid_issue_price,                       "INVALID_ISSUE_PRICE"                        },
    { Invalid_notional,                          "INVALID_NOTIONAL"                           },
    { Invalid_LIBORfix,                          "INVALID_LIBORFIX"                           },
    { Invalid_rpct_first,                        "INVALID_RPCT_FIRST"                         },
    { Invalid_busconv,                           "INVALID_BUSCONV"                            },
    { Fix_start_after_fix_end,                   "FIX_START_AFTER_FIX_END"                    },
    { Fix_start_after_pay_day,                   "FIX_END_AFTER_PAY_DAY"                      },
    { Invalid_price,                             "INVALID_PRICE"                              },
    { Invalid_base,                              "INVALID_BASE"                               },
    { Invalid_volconv,                           "INVALID_VOLCONV"                            },
    { Invalid_b76sm,                             "INVALID_B76SM"                              },
    { Invalid_keyconv,                           "INVALID_KEYCONV"                            },
    { Invalid_riskconv,                          "INVALID_RISKCONV"                           },
    { NULL_pointer,                              "NULL_POINTER"                               },
    { Invalid_AIdays,                            "INVALID_AIDAYS"                             },
    { Invalid_CMAdjOrder,                        "INVALID_CMADJORDER"                         },
    { Invalid_Correlation,                       "INVALID_CORRELATION"                        },
    { Invalid_Debtor_rate,                       "INVALID_DEBTOR_RATE"                        },
    { Invalid_lattice_size,                      "INVALID_LATTICE_SIZE"                       },
    { NEGATIVE_VOL,                              "NEGATIVE_VOL"                               },
    { NONPOSDEF_CORR,                            "NONPOSDEF_CORR"                             },
    { Invalid_rateconv,                          "Invalid_rateconv"                           },
    { Invalid_payday,                            "Invalid_payday"                             },
    { Settl_after_payday,                        "Settl_after_payday"                         },
    { Invalid_nextfix,                           "Invalid_nextfix"                            },
    { Nextfix_before_effective,                  "Nextfix_before_effective"                   },
    { Invalid_bondseg,                           "Invalid_bondseg"                            },
    { Invalid_issue,                             "Invalid_issue"                              },
    { Invalid_bsectype,                          "Invalid_bsectype"                           },
    { Type_not_bullet,                           "Type_not_bullet"                            },
    { Call_before_hurdle,                        "Call_before_hurdle"                         },
    { Maturity_before_call,                      "Maturity_before_call"                       },
    { Invalid_call_price,                        "Invalid_call_price"                         },
    { Invalid_call_hurdle,                       "Invalid_call_hurdle"                        },
    { Invalid_conversion_price,                  "Invalid_conversion_price"                   },
    { Invalid_kfdebtor_rate,                     "Invalid_kfdebtor_rate"                      },
    { Invalid_step,                              "Invalid_step"                               },
    { Invalid_sigma,                             "Invalid_sigma"                              },
    { Invalid_process_type,                      "Invalid_process_type"                       },
    { Invalid_chg_time,                          "Invalid_chg_time"                           },
    { Invalid_cttype,                            "Invalid_cttype"                             },
    { Invalid_cfconv,                            "Invalid_cfconv"                             },

    { INVALID_VALIDATE,                          ""                                           }

};


void VALIDATE2Str(VALIDATE val, TEXT txt)
{
    const char  *pszText = "***INVALID_VALIDATE***";
    for (int i = 0; EV_ValidateTab[i].enVal != INVALID_VALIDATE; i++)
    {
        if (EV_ValidateTab[i].enVal == val)
        {
            pszText = EV_ValidateTab[i].pszText;
            break;
        }
    }
    strcpy(txt, pszText) ;
}


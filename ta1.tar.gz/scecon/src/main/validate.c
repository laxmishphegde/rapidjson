/* SCID @(#)validate.c	1.104 (SimCorp) 99/11/08 12:19:22 */

/************************************************************************
*
*   project     SCecon
*
*   file name   validate.c
*
*   general     This file contains routines for validating the
*               content of the data structures of SCecon
*
************************************************************************/

/*** includes **********************************************************/
#include <validate.h>

/*** defines ***********************************************************/
#define valid_tol 0.000001

/*,,SOH,,
*************************************************************************
*
*               Validate_RISKCONV()
*
*   interface   #include <validate.h>
*               BOOLE     Validate_RISKCONV(RISKCONV r)
*
*   general     This function validates the content of the RISKCONV
*               data structure
*
*   input       RISKCONV  r  The RISKCONV data structure
*
*   output
*
*   returns     True if r is a valid RISKCONV, False if invalid
*
*   diagnostics
*
*   see also    RISKCONV
*
*************************************************************************
,,EOH,,*/


BOOLE Validate_RISKCONV(RISKCONV r)
{
    /* check that r is valid */
    switch (r)
    {
        case ZERO_ORDER :
        case FIRST_ORDER :
        case SECOND_ORDER :
            return True ;
        default :
            return False ;
    }
}



/*,,SOH,,
*************************************************************************
*
*               Validate_KEYCONV()
*
*   interface   #include <validate.h>
*               BOOLE     Validate_KEYCONV(KEYCONV k)
*
*   general     This function validates the content of the KEYCONV
*               data structure
*
*   input       KEYCONV  k  The KEYCONV data structure
*
*   output
*
*   returns     True if k is a valid KEYCONV, False if invalid
*
*   diagnostics
*
*   see also    KEYCONV
*
*************************************************************************
,,EOH,,*/


BOOLE Validate_KEYCONV(KEYCONV k)
{
    /* check that k is valid */
    switch (k)
    {
        case KEY_PRICE :
        case KEY_VOL :
        case KEY_MATURITY :
        case KEY_FIRSTDELIVERY :
        case KEY_REPO :
        case KEY_STRIKE :
        case KEY_SIZE :
        case KEY_DF :
        case KEY_GAP :
        case KEY_A :
        case KEY_SIGMA :
        case KEY_SPREAD :
        case KEY_DIVYLD :
        case KEY_SPOT :
        case KEY_PROB :
        case KEY_BPV :
        case KEY_YTM :
        case KEY_MATURITY_BPV :
        case KEY_FRA:
        case KEY_SHORT:
        case KEY_LONG:
        case KEY_GAMMAX:
        case KEY_INDEX:
            return True ;
        default :
            return False ;
    }
}


/*,,SOH,,
*************************************************************************
*
*               Validate_RISKSET()
*
*   interface   #include <validate.h>
*               VALIDATE Validate_RISKSET(RISKSET *r)
*
*   general     This function validates the content of the RISKSET
*               data structure
*
*   input       RISKSET   *r  The RISKSET data structure
*
*   output
*
*   returns     Valid_data if the content of r is valid or if r is NULL
*               Invalid_matur if matur is an invalid date
*               If the content of div is invalid an error message
*                    from Validate_PLAN_STR() is returned
*               Invalid_cal if cal is an invalid calendar convention
*
*
*   diagnostics
*
*   see also    RISKSET
*
*************************************************************************
,,EOH,,*/


VALIDATE Validate_RISKSET(RISKSET* r)
{
    VALIDATE v ;

    if (r == NULL)
        return Valid_data ;

    if (!Validate_KEYCONV(r->key))
        return Invalid_keyconv ;

    if (!Validate_RISKCONV(r->risk))
        return Invalid_riskconv ;

    if (!Validate_IRRCONV(r->irr))
        return Invalid_irrconv ;

    if (!Validate_PMTFREQ(r->freq))
        return Invalid_freq ;

    if (r->key == KEY_DF || r->key == KEY_BPV)
    {
        v = Validate_PLAN_STR(r->loads) ;
        if (v != Valid_data)
            return v ;
    }

    if (!Validate_BOOLE(r->dom))
        return Invalid_boole ;

    return Valid_data ;
}


/*,,SOH,,
*************************************************************************
*
*               Validate_ITERCTRL()
*
*   interface   #include <validate.h>
*               VALIDATE Validate_ITERCTRL(ITERCTRL *f)
*
*   general     This function validates the content of the ITERCTRL
*               data structure
*
*   input       ITERCTRL   *f  The ITERCTRL data structure
*
*   output
*
*   returns     Valid_data if the content of f is valid
*
*
*   diagnostics
*
*   see also    ITERCTRL
*
*************************************************************************
,,EOH,,*/


VALIDATE Validate_ITERCTRL(ITERCTRL* f)
{
    /* warning avoidance */
    f = NULL ;

    return Valid_data ;
}

/*,,SOH,,
*************************************************************************
*
*               Validate_ZRATE_STR()
*
*   interface   #include <validate.h>
*               VALIDATE Validate_ZRATE_STR(ZRATE_STR *f)
*
*   general     This function validates the content of the ZRATE_STR
*               data structure
*
*   input       ZRATE_STR   *f  The ZRATE_STR data structure
*
*   output
*
*   returns     Valid_data if the content of f is valid
*
*
*   diagnostics
*
*   see also    ZRATE_STR
*
*************************************************************************
,,EOH,,*/


VALIDATE Validate_ZRATE_STR(ZRATE_STR* f)
{
    if (Validate_PERIOD(&f->period) == False)
        return Invalid_period ;

    if (!Validate_PMTFREQ(f->freq))
        return Invalid_freq ;

    if (!Validate_CALCONV(f->cal))
        return Invalid_cal ;

    if (!Validate_BUSCONV(f->bus))
        return Invalid_busconv ;

    if (!Validate_EOMCONV(f->eom))
        return Invalid_eomconv ;

    return Valid_data ;
}

/*,,SOH,,
*************************************************************************
*
*               Validate_VOLCONV()
*
*   interface   #include <validate.h>
*               BOOLE     Validate_VOLCONV(VOLCONV volconv)
*
*   general     This function validates the content of the VOLCONV
*               data structure
*
*   input       VOLCONV  volconv  The VOLCONV data structure
*
*   output
*
*   returns     True if volconv is a valid VOLCONV, False if invalid
*
*   diagnostics
*
*   see also    VOLCONV
*
*************************************************************************
,,EOH,,*/


BOOLE Validate_VOLCONV(VOLCONV volconv)
{
    /* check that volconv is valid */
    switch (volconv)
    {
        case FORWFORW :
        case FORWVOL :
              return True ;
        default :
            return False ;
    }
}


/*,,SOH,,
*************************************************************************
*
*               Validate_VOL_STR()
*
*   interface   #include <validate.h>
*               VALIDATE Validate_VOL_STR(VOL_STR *vol)
*
*   general     This function validates the content of the VOL_STR
*               data structure
*
*   input       VOL_STR   *vol  The VOL_STR data structure
*
*   output
*
*   returns     Valid_data if the content of vol is valid
*               If the content of ppmts is invalid an error message
*                    from Validate_PLAN_STR() is returned
*               If the content of ppmts is invalid an error message
*                    from Validate_PLAN_STR_SIGN() is returned
*               Invalid_volconv if vc is an invalid VOLCONV
*               Invalid_cal if cal is an invalid CALCONV
*
*   diagnostics
*
*   see also    VOL_STR
*
*************************************************************************
,,EOH,,*/


VALIDATE Validate_VOL_STR(VOL_STR* vol)
{
    VALIDATE  v ;

    v = Validate_PLAN_STR(vol->vol);
    if (v != Valid_data)
        return v ;
    else
    {
        v = Validate_PLAN_STR_SIGN(vol->vol, True) ;
        if (v != Valid_data)
            return v ;
    }

    if (!Validate_VOLCONV(vol->vc))
        return Invalid_volconv ;

    if (!Validate_CALCONV(vol->cal))
        return Invalid_cal ;

    if (!Validate_INTPOLCONV(vol->iconv))
        return Invalid_intpolconv ;

    return Valid_data ;
}


/*,,SOH,,
*************************************************************************
*
*               Validate_DFSPREAD()
*
*   interface   #include <validate.h>
*               VALIDATE Validate_DFSPREAD(DFSPREAD *dfs)
*
*   general     This function validates the content of the DFSPREAD
*               data structure
*
*   input       DFSPREAD   *dfs       The DFSPREAD data structure
*
*   output
*
*   returns     Valid_data if the content of dfs is valid
*               Invalid_irrconv if irr is an invalid IRRCONV
*               Invalid_freq if freq is an invalid PMTFREQ
*
*   diagnostics
*
*   see also    DFSPREAD
*
*************************************************************************
,,EOH,,*/

VALIDATE Validate_DFSPREAD(DFSPREAD* dfs)
{
    VALIDATE v ;
    
    if (dfs == NULL)
        return Valid_data ;
    
    if (fabs(dfs->spread) > valid_tol)
    {
        if (!Validate_IRRCONV(dfs->irr))
            return Invalid_irrconv ;

        if (!Validate_PMTFREQ(dfs->freq))
            return Invalid_freq ;

        v = Validate_PLAN_STR(dfs->spr_list) ;
        if (v != Valid_data)
            return v ;
    }

    return Valid_data ;
}


/*,,SOH,,
*************************************************************************
*
*               Validate_BUSCONV()
*
*   interface   #include <validate.h>
*               BOOLE     Validate_BUSCONV(BUSCONV busconv)
*
*   general     This function validates the content of the BUSCONV
*               data structure
*
*   input       BUSCONV  busconv  The BUSCONV data structure
*
*   output
*
*   returns     True if busconv is a valid BUSCONV, False if invalid
*
*   diagnostics
*
*   see also    BUSCONV
*
*************************************************************************
,,EOH,,*/


BOOLE Validate_BUSCONV(BUSCONV busconv)
{
    /* check that busconv is valid */
    switch (busconv)
    {
        case NEXT :
        case NEXTINMONTH :
        case CLOSEST :
        case CLOSESTINMONTH :
        case PREVIOUS :
        case PREVIOUSINMONTH :
        case NO_BUSADJUST :
              return True ;
        default :
            return False ;
    }
}


/*,,SOH,,
*************************************************************************
*
*               Validate_HOLI_STR()
*
*   interface   #include <validate.h>
*               VALIDATE Validate_HOLI_STR(HOLI_STR *h)
*
*   general     This function validates the content of the HOLI_STR
*               data structure
*
*   input       HOLI_STR     *h         The HOLI_STR data structure
*
*   output
*
*   returns     Valid_data if the content of s is valid
*               Invalid_busconv if bus is an invalid BUSCONV
*               If the content of holidays is invalid an error message
*                    from Validate_DATEARRAY() is returned
*
*   diagnostics
*
*   see also    HOLI_STR
*
*************************************************************************
,,EOH,,*/


VALIDATE Validate_HOLI_STR(HOLI_STR* h)
{
    VALIDATE v ;

    if (!Validate_BUSCONV(h->bus))
        return Invalid_busconv ;

    v = Validate_DATEARRAY(h->holidays, h->nholi) ;
    if (v != Valid_data)
        return v ;

    return Valid_data ;
}


/*,,SOH,,
*************************************************************************
*
*               Validate_DISCIPOL()
*
*   interface   #include <validate.h>
*               BOOLE Validate_DISCIPOL(DISCIPOL d)
*
*   general     This function validates the content of the DISCIPOL
*               data structure
*
*   input       DISCIPOL  d       The DISCIPOL data structure
*
*   output
*
*   returns     True if d is a valid DISCIPOL, False if invalid
*
*   diagnostics
*
*   see also    DISCIPOL
*
*************************************************************************
,,EOH,,*/


BOOLE Validate_DISCIPOL(DISCIPOL d)
{
    /* check that d is valid */
    switch (d)
    {
        case DI_SPOT :
        case DI_DISC :
        case DI_GROWTH :
        case DI_FORW :
            return True ;
        default :
            return False ;
    }
}


/*,,SOH,,
*************************************************************************
*
*               Validate_INTPOLCONV()
*
*   interface   #include <validate.h>
*               BOOLE Validate_INTPOLCONV(INTPOLCONV intpol)
*
*   general     This function validates the content of the INTPOLCONV
*               data structure
*
*   input       INTPOLCONV   intpol   The INTPOLCONV data structure
*
*   output
*
*   returns     True if intpol is a valid INTPOLCONV, False if invalid
*
*   diagnostics
*
*   see also    INTPOLCONV
*
*************************************************************************
,,EOH,,*/


BOOLE Validate_INTPOLCONV(INTPOLCONV intpol)
{
    /* check that intpol is valid */
    switch (intpol)
    {
        case LINEAR_EXTRAPOL :
        case LINEAR_FLAT_END :
        case EXCL_INCL :
        case INCL_EXCL :
        case CUBIC_SPLINE :
            return True ;
        default :
            return False ;
    }
}


/*,,SOH,,
*************************************************************************
*
*               Validate_IRRCONV()
*
*   interface   #include <validate.h>
*               BOOLE Validate_IRRCONV(IRRCONV irrconv)
*
*   general     This function validates the content of the IRRCONV
*               data structure
*
*   input       IRRCONV irrconv   The IRRCONV data structure
*
*   output
*
*   returns     True if irrconv is a valid IRRCONV, False if invalid
*
*   diagnostics
*
*   see also    IRRCONV
*
*************************************************************************
,,EOH,,*/


BOOLE Validate_IRRCONV(IRRCONV irrconv)
{
    /* check that irrconv is valid */
    switch (irrconv)
    {
        case CONTINUOUS :
        case COMPOUND :
        case SIMPLE_MM :
        case COMPOUNDSIMPLE :
        case COMPOUNDSIMPLE_ODD :
        case BRAESSFANGMEYER :
        case MOOSMULLER :
        case MAIR :
        case DISCOUNT :
        case US_TREASURY :
        case JGBYTM :
        case SIMPLE_REPO:
            return True ;
        default :
            return False ;
    }
}


/*,,SOH,,
*************************************************************************
*
*               Validate_DISCFAC()
*
*   interface   #include <validate.h>
*               VALIDATE Validate_DISCFAC(DISCFAC *d)
*
*   general     This function validates the content of the DISCFAC
*               data structure
*
*    input      DISCFAC *d        The DISCFAC data structure
*
*   output
*
*   returns     Valid_data if the content of DISCFAC is valid,
*               NULL_ponter if d is NULL
*
*               If the PLAN_STR data structure holding the discount
*                   factors is invalid an error message from
*                   Validate_PLAN_STR() is returned
*               First_disc_not_unity if the first discount factor isn't
*                   unity
*               Invalid_discipol if what is not a valid DISCIPOL
*               Invalid_intpolconv if iconv is not a valid INTPOLCONV
*               Invalid_cal if cal is not a valid calendar convention
*               Invalid_irrconv if what is DI_SPOT or DI_FORW and irr
*                   is not a valid IRRCONV
*               Invalid_pmtfreq if irr is COMPOUND, MOOSMULLER, or
*                   US_TREASURY and freq is not a valid PMTFREQ
*
*   diagnostics
*
*   see also    DISCFAC
*
*************************************************************************
,,EOH,,*/


VALIDATE Validate_DISCFAC(DISCFAC* d)
{
    VALIDATE   tmp ;

    if (d == NULL)
        return NULL_pointer ;

    if (GetPlanFill(d->disc) > 0)
    {
        tmp = Validate_PLAN_STR(d->disc) ;
        if (tmp != Valid_data)
            return tmp ;

        if (d->disc->f64[0] < 1.0 - valid_tol || 
               d->disc->f64[0] > 1.0 + valid_tol)
            return First_disc_not_unity ;
    }
    else if (GetPlanFill(d->disc) < 0)
        return Invalid_filled;

    if (Validate_DISCIPOL(d->what) == False)
        return Invalid_discipol ;

    if (Validate_INTPOLCONV(d->iconv) == False)
        return Invalid_intpolconv ;

    if (Validate_CALCONV(d->cal) == False)
        return Invalid_cal ;

    if ((d->what == DI_SPOT || d->what == DI_FORW) && 
            Validate_IRRCONV(d->irr) == False)
        return Invalid_irrconv ;

    if ((d->irr == COMPOUND || d->irr == MOOSMULLER || 
        d->irr == US_TREASURY) && Validate_PMTFREQ(d->freq) == False)
        return Invalid_freq ;

    return Valid_data ;
}

/*,,SOH,,
*************************************************************************
*
*               Validate_DFPARMS()
*
*   interface   #include <validate.h>
*               VALIDATE Validate_DFPARMS(DFPARMS *d)
*
*   general     This function validates the content of the DFPARMS
*               data structure
*
*    input      DFPARMS *d        The DFPARMS data structure
*
*   output
*
*   returns     Valid_data if the content of DFPARMS is valid,
*               Invalid_discipol if what is not a valid DISCIPOL
*               Invalid_intpolconv if iconv is not a valid INTPOLCONV
*               Invalid_cal if cal is not a valid calendar convention
*               Invalid_irrconv if what is DI_SPOT or DI_FORW and irr
*                   is not a valid IRRCONV
*               Invalid_pmtfreq if irr is COMPOUND, MOOSMULLER, or
*                   US_TREASURY and freq is not a valid PMTFREQ
*
*   diagnostics
*
*   see also    DFPARMS
*
*************************************************************************
,,EOH,,*/


VALIDATE Validate_DFPARMS(DFPARMS* d)
{
    if (Validate_DISCIPOL(d->what) == False)
        return Invalid_discipol ;

    if (Validate_INTPOLCONV(d->iconv) == False)
        return Invalid_intpolconv ;

    if (Validate_CALCONV(d->cal) == False)
        return Invalid_cal ;

    if ((d->what == DI_SPOT || d->what == DI_FORW) && 
        Validate_IRRCONV(d->irr) == False)
        return Invalid_irrconv ;

    if ((d->irr == COMPOUND || d->irr == MOOSMULLER || d->irr == US_TREASURY) &&
            Validate_PMTFREQ(d->freq) == False)
        return Invalid_freq ;

    return Valid_data ;
}


/*,,SOH,,
*************************************************************************
*
*               Validate_BONDTYPE()
*
*   interface   #include <validate.h>
*               BOOLE Validate_BONDTYPE(BONDTYPE bondtype)
*
*   general     This function validates the content of the BONDTYPE
*               data structure
*
*   input       BONDTYPE    bondtype    The BONDTYPE data structure
*
*   output
*
*   returns     True if bondtype is a valid BONDTYPE, False if invalid
*
*   diagnostics
*
*   see also    BONDTYPE
*
*************************************************************************
,,EOH,,*/


BOOLE Validate_BONDTYPE(BONDTYPE bondtype)
{
    /* check that bondtype is valid */
    switch (bondtype)
    {
        case BULLET :
        case SERIAL :
        case ANNUITY :
        case PERPETUAL :
        case NONREGULAR :
        case SERIAL_PCT :
        case ANNUITY_PCT :
        case ANNUITY_PREP :
            return True ;
        default :
            return False ;
    }
}


/*,,SOH,,
*************************************************************************
*
*               Validate_CALCONV()
*
*   interface   #include <validate.h>
*               BOOLE Validate_CALCONV(CALCONV calconv)
*
*   general     This function validates the content of the CALCONV
*               data structure
*
*   input        CALCONV  calconv The CALCONV data structure
*
*   output
*
*   returns     True if calconv is a valid CALCONV, False if invalid
*
*   diagnostics
*
*   see also    CALCONV
*
*************************************************************************
,,EOH,,*/


BOOLE Validate_CALCONV(CALCONV calconv)
{
    /* check that calconv is valid */
    switch (calconv)
    {
        case ACTACT :
        case ACTLEAP :
        case ACTAFB :
        case ACTEUROBOND :
        case ACTFRF :
        case EU30360 :
        case EU30E360 :
        case EU30EP360:
        case EU30E365 :
        case US30360 :
        case US30E360 :
        case ACT365 :
        case ACTNL365 :
        case ACT360:
		case BUS252:    	/* PMSTA-22396 - SRIDHARA � 160502 */
            return True ;
        default :
            return False ;
    }
}


/*,,SOH,,
*************************************************************************
*
*               Validate_DATEARRAY()
*
*   interface   #include <validate.h>
*               VALIDATE  Validate_DATEARRAY(DATEARRAY    pdates,
*                                            INTI         nday) ;
*
*   general     This function first validates the nday dates in
*               datearray and then checks if the dates are ordered
*               ascendingly and are unique
*
*   input       DATEARRAY   pdates      The DATEARRAY data structure
*               INTI        nday        Number of days in datearray
*
*   output
*
*   returns     Valid_data if the dates in datearray are valid, ordered
*                   ascendingly, and unique, or if pdates is NULL.
*               Invalid_filled if nday is <= 0
*               Invalid_date if one of the dates are invalid
*               Days_not_sorted if the dates are unsorted
*               Days_not_unique if the dates are not unique
*
*   diagnostics
*
*   see also    DATESTR
*
*************************************************************************
,,EOH,,*/

VALIDATE Validate_DATEARRAY(DATEARRAY pdates, INTI nday)
{
    INTI    i ;

    if (nday < 0)
        return Invalid_filled ;

    if (pdates == NULL)
        return Valid_data ;

    for (i = 0 ; i < nday ; i++)
    {
        if (!Cldr_CheckDate(&pdates[i]))
            return Invalid_date ;

        if (i > 0 && Cldr_DateLT(&pdates[i], &pdates[i - 1]) == True)
            return Days_not_sorted ;

        if (i > 0 && Cldr_DateEQ(&pdates[i], &pdates[i - 1]) == True)
            return Days_not_unique ;
    }

    return Valid_data ;
}


/*,,SOH,,
*************************************************************************
*
*               Validate_EOMCONV()
*
*   interface   #include <validate.h>
*               BOOLE Validate_EOMCONV(EOMCONV eomconv)
*
*   general     This function validates the content of the EOMCONV
*               data structure
*
*   input       EOMCONV eomconv   The EOMCONV data structure
*
*   output
*
*   returns     True if eomconv is a valid EOMCONV, False if invalid
*
*   diagnostics
*
*   see also    EOMCONV
*
*************************************************************************
,,EOH,,*/


BOOLE Validate_EOMCONV(EOMCONV eomconv)
{
    /* check that eomconv is valid */
    switch (eomconv)
    {
        case LAST :
        case SAME :
        case LAST360 :
            return True ;
        default :
            return False ;
    }
}


/*,,SOH,,
*************************************************************************
*
*               Validate_PLAN_STR()
*
*   interface   #include <validate.h>
*               VALIDATE Validate_PLAN_STR(PLAN_STR     *plan) ;
*
*
*   general     This function validates the content of the PLAN_STR
*               data structure. The function checks that the dates in
*               day are valid, ordered ascendingly, and unique.
*
*   input       PLAN_STR    *plan        The PLAN_STR data structure
*
*   output
*
*   returns     Valid_data if the content if PLAN_STR is valid or if
*                   PLAN_STR is NULL,
*               Invalid_filled if filled is < 0,
*               If datearray is an invalid datearray an error message
*                   from Validate_DATEARRAY() is returned
*
*   diagnostics
*
*   see also    PLAN_STR
*
*************************************************************************
,,EOH,,*/

VALIDATE Validate_PLAN_STR(PLAN_STR* plan)
{
    VALIDATE tmp ;

    if (plan == NULL)
        return Valid_data ;

    /* check that filled >= 0 */
    if (GetPlanFill(plan) < 0)
        return Invalid_filled ;

    /* if (plan->filled > 0) */
    if (GetPlanFill(plan) > 0)
    {
        /* check that day is a valid datearray */
        tmp = Validate_DATEARRAY(plan->day, plan->filled) ;
        if (tmp != Valid_data)
            return tmp ;
    }

    return Valid_data ;
}


/*,,SOH,,
*************************************************************************
*
*               Validate_PLAN_STR_SIGN()
*
*   interface   #include <validate.h>
*               VALIDATE Validate_PLAN_STR_SIGN(PLAN_STR     *plan,
*                                               BOOLE        sign) ;
*
*
*   general     This function returns Valid_data if all entries in the
*               FL64ARRAY are either positive or negative
*
*   input       PLAN_STR  *plan       The PLAN_STR data structure
*               BOOLE     sign        If sign is True all entries in
*                                     plan_str->f64 should be positive
*                                     False indicate that all entries
*                                     should be negative
*
*   output
*
*   returns     Valid_data if the content if PLAN_STR is valid or if
*                   PLAN_STR is NULL,
*               Invalid_filled if filled is < 0,
*               Wrong_sign_in_array if one of the entries in f64 has
*                   a 'wrong' sign
*
*   diagnostics
*
*   see also    PLAN_STR
*
*************************************************************************
,,EOH,,*/


VALIDATE Validate_PLAN_STR_SIGN(PLAN_STR* plan,    BOOLE sign)
{
    INTI    i ;
    BOOLE   ok = True ;

    if (plan == NULL)
        return Valid_data ;

    /* check that filled >= 0 */
    if (GetPlanFill(plan) < 0)
        return Invalid_filled ;

    /* check that all entries in f64 are positive */
    /* if (plan->filled > 0) */
    if (GetPlanFill(plan) > 0)
    {
        if (sign == True)
        {
            for (i = 0; i < plan->filled  && ok == True ; i++)
                if (plan->f64[i] < -valid_tol)
                    ok = False ;
        }
        else
        /* check that all entries in f64 are negative */
        {
            for (i = 0; i < plan->filled  && ok == True ; i++)
                if (plan->f64[i] > -valid_tol)
                    ok = False ;
        }

        if (ok == False)
            return Wrong_sign_in_array ;
    }

    return Valid_data ;
}


/*,,SOH,,
*************************************************************************
*
*               Validate_PLAN_STR_SORTED()
*
*   interface   #include <validate.h>
*               VALIDATE Validate_PLAN_STR_SORTED(PLAN_STR    *plan,
*                                                 SORTCONV    sc    ) ;
*
*   general     This function returns Valid_data if the entries in the
*               FL64ARRAY in the PLAN_STR are sorted according to the
*               given sorting convention. Otherwise an error message is
*               returned
*
*   input       PLAN_STR    *plan        The PLAN_STR data structure
*               SORTCONV     sc            The sorting convention
*
*   output
*
*   returns     Valid_data if the content if PLAN_STR is valid or if
*                   PLAN_STR is NULL,
*               Invalid_filled if filled is < 0,
*               Array_not_sorted if the entries in f64
*                   are not sorted according to the given convention
*
*   diagnostics
*
*   see also    PLAN_STR
*
*************************************************************************
,,EOH,,*/


VALIDATE Validate_PLAN_STR_SORTED(PLAN_STR* plan, SORTCONV sc)
{
    INTI i ;

    if (plan == NULL)
        return Valid_data ;

    /* check that filled >= 0 */
    if (GetPlanFill(plan) < 0)
        return Invalid_filled ;

    /* if (plan->filled > 0) */
    if (GetPlanFill(plan) > 0)
    {
        for (i = 0; i < plan->filled; i++)
            if (i > 0 && ((plan->f64[i] + valid_tol >= plan->f64[i - 1] && sc ==
              DESCENDING) ||
                (plan->f64[i] <= plan->f64[i - 1] + valid_tol && sc ==
                  ASCENDING)))
            return Array_not_sorted ;
    }

    return Valid_data ;
}



/*,,SOH,,
*************************************************************************
*
*               Validate_PLAN_STR_SUM100()
*
*   interface   #include <validate.h>
*               VALIDATE Validate_PLAN_STR_SUM100(PLAN_STR  *plan) ;
*
*   general     This function returns Valid_data if the entries in the
*               FL64ARRAY in the PLAN_STR sum up to 100. Otherwise an
*               error message is returned
*
*   input       PLAN_STR    *plan        The PLAN_STR data structure
*
*   output
*
*   returns     Valid_data if the content if PLAN_STR is valid or if
*                   PLAN_STR is NULL,
*               Invalid_filled if filled is < 0,
*               Invalid_sum if entries in f64 does not sum to 100,
*
*   diagnostics
*
*   see also    PLAN_STR
*
*************************************************************************
,,EOH,,*/


VALIDATE Validate_PLAN_STR_SUM100(PLAN_STR* plan)
{
    FL64    sum = 0.0;
    INTI    i ;

    if (plan == NULL)
        return Valid_data ;

    /* check that filled >= 0 */
    if (GetPlanFill(plan) < 0)
        return Invalid_filled ;

    /* check that entries in f64 sum to 100 */
    /* if (plan->filled > 0) */
    if (GetPlanFill(plan) > 0)
    {
        for (i=0; i <= plan->filled -1; i++)
            sum += plan->f64[i] ;
        if (fabs(sum-100.0) > valid_tol)
            return Invalid_sum ;
    }

    return Valid_data ;
}


/*,,SOH,,
*************************************************************************
*
*               Validate_PMTFREQ()
*
*   interface   #include <validate.h>
*               BOOLE Validate_PMTFREQ(PMTFREQ pmtfreq)
*
*   general     This function validates the content of the PMTFREQ
*               data structure
*
*   input       PMTFREQ  pmtfreq  The PMTFREQ data structure
*
*   output
*
*   returns     True if pmtfreq is a valid PMTFREQ, False if invalid
*
*   diagnostics
*
*   see also    PMTFREQ
*
*************************************************************************
,,EOH,,*/


BOOLE Validate_PMTFREQ(PMTFREQ pmtfreq)
{
    /* check that pmtfreq is a valid PMTFREQ */
    switch (pmtfreq)
    {
        case TRIANNUALLY :
        case BIANNUALLY :
        case ANNUALLY :
        case SEMIANNUALLY :
        case FOURTHMONTHLY :
        case QUARTERLY :
        case BIMONTHLY :
        case MONTHLY :
        case NO_FREQUENCY :
            return True ;
        default :
            return False ;
    }
}


/*,,SOH,,
*************************************************************************
*
*               Validate_SEQCONV()
*
*   interface   #include <validate.h>
*               BOOLE Validate_SEQCONV(SEQCONV seqconv)
*
*   general     This function validates the content of the SEQCONV
*               data structure
*
*   input       SEQCONV  seqconv  The SEQCONV data structure
*
*   output
*
*   returns     True if seqconv is a valid SEQCONV, False if invalid
*
*   diagnostics
*
*   see also    SEQCONV
*
*************************************************************************
,,EOH,,*/


BOOLE Validate_SEQCONV(SEQCONV seqconv)
{
    /* check that seqconv is a valid SEQCONV */
    switch (seqconv)
    {
        case ANCHOR :
        case ANCHORBACK :
        case CHAIN :
        case IMM :
        case IMM_ZAR :
        case CAD_BA :
        case ANCHORSHIFT :
        case LASTBUS :
        case TAM_T4M :
            return True ;
        default :
            return False ;
    }
}


/*,,SOH,,
*************************************************************************
*
*               Validate_TERMUNIT()
*
*   interface   #include <validate.h>
*               BOOLE Validate_TERMUNIT(TERMUNIT termunit)
*
*   general     This function validates the content of the TERMUNIT
*               data structure
*
*   input       TERMUNIT    termunit    The TERMUNIT data structure
*
*   output
*
*   returns     True if termunit is a valid TERMUNIT, False if invalid
*
*   diagnostics
*
*   see also    TERMUNIT
*
*************************************************************************
,,EOH,,*/


BOOLE Validate_TERMUNIT(TERMUNIT termunit)
{
    /* check that termunit is a valid TERMUNIT */
    switch (termunit)
    {
        case DAYS :
        case BUSDAYS :
        case WEEKS :
        case MONTHS :
        case YEARS :
            return True ;
        default :
            return False ;
    }
}


/*,,SOH,,
*************************************************************************
*
*               Validate_BOOLE()
*
*   interface   #include <validate.h>
*               BOOLE    Validate_BOOLE(BOOLE b)
*
*   general     This function validates the content of the BOOLE
*               data structure
*
*   input       BOOLE  b          The BOOLE data structure
*
*   output
*
*   returns     True is b is either True or False, otherwise False
*
*   diagnostics
*
*   see also    BOOLE
*
*************************************************************************
,,EOH,,*/


BOOLE Validate_BOOLE(BOOLE b)
{
    if (b != True && b != False)
        return False ;

    return True ;
}


/*,,SOH,,
*************************************************************************
*
*               Validate_PERIOD()
*
*   interface   #include <validate.h>
*               BOOLE Validate_PERIOD(PERIOD *p)
*
*   general     This function validates the content of the PERIOD
*               data structure
*
*   input       PERIOD    *p      The PERIOD data structure
*
*   output
*
*   returns     True if the content p is valid PERIOD, otherwise False
*
*   diagnostics
*
*   see also    PERIOD
*
*************************************************************************
,,EOH,,*/


BOOLE Validate_PERIOD(PERIOD* p)
{
    if (p->num < 0)
        return False ;

    if (Validate_TERMUNIT(p->unit) == False)
        return False;

    return True ;
}


/*,,SOH,,
*************************************************************************
*
*              Validate_FL64ARRAY()
*
*   interface  #include <validate.h>
*              VALIDATE Validate_FL64ARRAY(FL64ARRAY    pf,
*                                           INTI         c,
*                                           BOOLE        lbound,
*                                           FL64         lb,
*                                           BOOLE        ubound,
*                                           FL64         ub) ;
*
*   general     This function validates the content of the FL64ARRAY
*                data structure
*
*   input       FL64ARRAY pf      The FL64ARRAY data structure
*
*               INTI      c       Number of elements in pf
*
*               BOOLE     lbound  If lbound if True the entries in
*                                 pf should be greater than lb
*
*               FL64      lb      Lower bound for entries in pf.
*                                  Only used if lbound is True
*
*               BOOLE     ubound  If ubound if True the entries in
*                                 pf should be smaller than ub
*
*               FL64      ub      Upper bound for entries in pf.
*                                 Only used if ubound is True
*   output
*
*   returns     Valid_data if the content of  is valid,
*               Out_of_range if lbound or ubound is true and some of the*
*                    entries in pf are below resp. above lb resp. ub
*   diagnostics
*
*   see also
*
*************************************************************************
,,EOH,,*/

VALIDATE Validate_FL64ARRAY(FL64ARRAY pf,
                            INTI c,
                            BOOLE lbound,
                            FL64 lb,
                            BOOLE ubound,
                            FL64 ub)
{
    INTI i ;
    for (i = 0; i < c; i++)
        if ((lbound == True && pf[i] < lb) || (ubound == True && pf[i] > ub))
            return Out_of_range ;

    return Valid_data ;
}

/*,,SOH,,
***********************************************************************
*                                                                      
*              Validate_BOOLEARRAY()                                   
*                                                                      
*   interface  #include <validate.h>                                   
*              VALIDATE Validate_BOOLEARRAY(BOOLEARRAY  pf,            
*                                           INTI        c) ;          
*                                                                      
*   general     This function validates the content of the BOOLEARRAY  
*                data structure                                        
*                                                                      
*   input       BOOLEARRAY pf      The BOOLEARRAY data structure       
*                                                                      
*               INTI       c       Number of elements in pf             
*                                                                      
*   output                                                             
*                                                                      
*   returns     Valid_data if the content of  is valid,                
*
*   diagnostics                                                        
*                                                                      
*   see also                                                           
*                                                                      
***********************************************************************
,,EOH,,*/

VALIDATE Validate_BOOLEARRAY(BOOLEARRAY pf,
                            INTI c)
{
    INTI i ;
    for (i = 0; i < c; i++)
        if (Validate_BOOLE(pf[i]) == False)
            return Invalid_boole ;

    return Valid_data ;
}


/*,,SOH,,
***********************************************************************
*                                                                      
*               Validate_BUCKET()
*                                                                      
*   interface   #include <validate.h>                                  
*               VALIDATE Validate_BUCKET(BUCKET *x)
*                                                                      
*   general     This function validates the content of the BUCKET
*               data structure                                         
*                                                                      
*   input       BUCKET *x   The Bucket structure.
*                                                                      
*   output                                                             
*                                                                      
*   returns     Valid_data if the content of Bucket is 
*               valid.
*                                                                      
*   diagnostics
*               Refer to BUCKET for a specification of valid data.
*              
*   see also    BUCKET
*                                                                      
***********************************************************************
,,EOH,,*/

VALIDATE Validate_BUCKET(BUCKET*  x)
{
    if (x->term < 0)
        return Invalid_term;

    if (Validate_TERMUNIT(x->unit) == False)
        return Invalid_termunit;

    return Valid_data;
}

/*,,SOH,,
***********************************************************************
*                                                                      
*               Validate_STEP_STR()
*                                                                      
*   interface   #include <validate.h>                                  
*               VALIDATE Validate_STEP_STR(STEP_STR *x)
*                                                                      
*   general     This function validates the content of the STEP_STR
*               data structure                                         
*                                                                      
*   input       STEP_STR *x   The STEP_STR structure.
*                                                                      
*   output                                                             
*                                                                      
*   returns     Valid_data if the content of STEP_STR is 
*               valid.
*                                                                      
*   diagnostics
*               Refer to STEP_STR for a specification of valid data.
*              
*   see also    STEP_STR
*                                                                      
***********************************************************************
,,EOH,,*/

VALIDATE Validate_STEP_STR(STEP_STR*  x)
{
    if (x->dur < 0)
        return Invalid_term;

    if (Validate_TERMUNIT(x->unit) == False)
        return Invalid_termunit;

    if (x->nstep <= 0)
        return Invalid_step;

    return Valid_data;
}


/*,,SOH,,
***********************************************************************
*                                                                      
*               Validate_BUCKETARRAY()
*                                                                      
*   interface   #include <validate.h>                                  
*               VALIDATE Validate_BUCKETARRAY(BUCKETARRAY x,
*                                             INTI      n);
*                                                                      
*   general     This function validates the content of the BUCKETARRAY
*               data structure                                         
*                                                                      
*   input       BUCKETARRAY x   The Bucket structures.
*               INTI        n   Number of elements in x.
*                                                                      
*   output                                                             
*                                                                      
*   returns     Valid_data if the content of Buckets is 
*               valid.
*                                                                      
*   diagnostics
*               Refer to BUCKET for a specification of valid data.
*              
*   see also    BUCKET
*                                                                      
***********************************************************************
,,EOH,,*/

VALIDATE Validate_BUCKETARRAY(BUCKETARRAY  x, INTI  n)
{
    VALIDATE v;
    INTI i;

    v = Valid_data;
    for (i = 0; i < n && v == Valid_data; i++)
      v = Validate_BUCKET(&x[i]);

    return v;
}

/*,,SOH,,
***********************************************************************
*                                                                      
*               Validate_STEPARRAY()
*                                                                      
*   interface   #include <validate.h>                                  
*               VALIDATE Validate_STEPARRAY(STEPARRAY x,
*                                           INTI      n);
*                                                                      
*   general     This function validates the content of the STEPARRAY
*               data structure                                         
*                                                                      
*   input       STEPARRAY x   The STEP_STR structures.
*               INTI      n   Number of elements in x.
*                                                                      
*   output                                                             
*                                                                      
*   returns     Valid_data if the content of STEP_STR is 
*               valid.
*                                                                      
*   diagnostics
*               Refer to STEP_STR for a specification of valid data.
*              
*   see also    STEP_STR
*                                                                      
***********************************************************************
,,EOH,,*/

VALIDATE Validate_STEPARRAY(STEPARRAY  x, INTI  n)
{
    VALIDATE v;
    INTI i;

    v = Valid_data;
    for (i = 0; i < n && v == Valid_data; i++)
      v = Validate_STEP_STR(&x[i]);

    return v;
}

/*,,SOH,,
***********************************************************************
*                                                                      
*               Validate_PERIODARRAY()
*                                                                      
*   interface   #include <validate.h>                                  
*               VALIDATE Validate_PERIODARRAY(PERIODARRAY x,
*                                           INTI      n);
*                                                                      
*   general     This function validates the content of the PERIODARRAY
*               data structure                                         
*                                                                      
*   input       PERIODARRAY x   The PERIOD structures.
*               INTI        n   Number of elements in x.
*                                                                      
*   output                                                             
*                                                                      
*   returns     Valid_data if the content of PERIODs is 
*               valid.
*                                                                      
*   diagnostics
*               Refer to PERIOD for a specification of valid data.
*              
*   see also    PERIOD
*                                                                      
***********************************************************************
,,EOH,,*/

VALIDATE Validate_PERIODARRAY(PERIODARRAY  x, INTI  n)
{
    BOOLE ok;
    INTI i;

    ok = True;
    for (i = 0; i < n && ok; i++)
      ok = Validate_PERIOD(&x[i]);

    if (ok)
        return Valid_data;
    else
        return Invalid_period;
}




/*,,SOH,,
************************************************************************
*                                                                       
*               Validate_ZRATEARRAY()                                
*                                                                       
*   interface   #include <validate.h>                                   
*               VALIDATE Validate_ZRATEARRAY(ZRATEARRAY  x,      
*                                             INTI n)                   
*                                                                       
*   general     This function validates the content of the 
*               ZRATEARRAY data structure
*                                                                       
*   input       ZRATEARRAY  x     The ZRATEARRAY data structure   
*               INTI        n      The size of the array                
*                                                                       
*   output                                                              
*                                                                       
*   returns     Valid_data if the content of ZRATE is valid,           
*                                                                       
*   diagnostics                                                         
*                                                                       
*   see also    ZRATEARRAY                                           
*                                                                       
************************************************************************
,,EOH,,*/


VALIDATE Validate_ZRATEARRAY(ZRATEARRAY x, INTI n)
{
    VALIDATE v = Valid_data ;
    INTI i ;

    for (i = 0; i < n && v == Valid_data; i++)
        v = Validate_ZRATE_STR(&x[i]) ;

    return v ;
}

/*,,SOH,,
************************************************************************
*                                                                       
*               Validate_DFSPREADARRAY()                                
*                                                                       
*   interface   #include <validate.h>                                   
*               VALIDATE Validate_DFSPREADARRAY(DFSPREADARRAY  cm,      
*                                             INTI n)                   
*                                                                       
*   general     This function validates the content of the 
*               DFSPREADARRAY data structure
*                                                                       
*   input       DFSPREADARRAY cm     The DFSPREADARRAY data structure   
*               INTI          n      The size of the array         
*                                                                       
*   output                                                              
*                                                                       
*   returns     Valid_data if the content of DFSPREAD is valid,       
*                                                                       
*   diagnostics                                                         
*                                                                       
*   see also    DFSPREADARRAY                                           
*                                                                       
************************************************************************
,,EOH,,*/


VALIDATE Validate_DFSPREADARRAY(DFSPREADARRAY cm, INTI n)
{
    VALIDATE v = Valid_data ;
    INTI i ;

    for (i = 0; i < n && v == Valid_data; i++)
        v = Validate_DFSPREAD(&cm[i]) ;

    return v ;
}


/*,,SOH,,
***********************************************************************
*                                                                      
*              Validate_FL64MATRIX()
*                                                                      
*   interface  #include <validate.h>                                   
*              VALIDATE Validate_FL64MATRIX(FL64MATRIX   pf,            
*                                           INTI         nr,            
*                                           INTI         nc,            
*                                           BOOLE        lbound,       
*                                           FL64         lb,           
*                                           BOOLE        ubound,       
*                                           FL64         ub) ;         
*                                                                      
*   general     This function validates the content of the FL64MATRIX
*                data structure                                        
*                                                                      
*   input       FL64MATRIX pf      The FL64MATRIX data structure       
*                                                                      
*               INTI       nr       Number of rows in pf
*                                                                      
*               INTI       nc       Number of columns in pf
*                                                                      
*               BOOLE      lbound  If lbound if True the entries in     
*                                  pf should be greater than lb         
*                                                                      
*               FL64       lb      Lower bound for entries in pf.       
*                                  Only used if lbound is True         
*                                                                      
*               BOOLE      ubound  If ubound if True the entries in     
*                                  pf should be smaller than ub         
*                                                                      
*               FL64       ub      Upper bound for entries in pf.       
*                                  Only used if ubound is True          
*   output                                                             
*                                                                      
*   returns     Valid_data if the content of  is valid,                
*               Out_of_range if lbound or ubound is true and some of 
*               the entries in pf are below resp. above lb resp. ub   
*   diagnostics                                                        
*                                                                      
*   see also                                                           
*                                                                      
***********************************************************************
,,EOH,,*/
VALIDATE Validate_FL64MATRIX(FL64MATRIX pf,
                            INTI nr,
                            INTI nc,
                            BOOLE lbound,
                            FL64 lb,
                            BOOLE ubound,
                            FL64 ub)
{
    VALIDATE v;
    INTI i ;

    v = Valid_data;
    for (i = 0; i < nr && v == Valid_data; i++)
        v = Validate_FL64ARRAY(pf[i], nc, lbound, lb, ubound, ub);

    return Valid_data ;
}



/*,,SOH,,
*************************************************************************
*
*               Validate_VOLBOX()
*
*   interface   #include <validate.h>
*               VALIDATE Validate_VOLBOX(VOLBOX *vol)
*
*   general     This function validates the content of the VOLBOX
*               data structure
*
*   input       VOLBOX   *vol  The VOLBOX data structure
*
*   output
*
*   returns     Valid_data if the content of vol is valid
*
*   diagnostics
*
*   see also    VOLBOX
*
*************************************************************************
,,EOH,,*/


VALIDATE Validate_VOLBOX(VOLBOX* vol)
{
    VALIDATE  v ;
    INTI k;

    if (!Validate_VOLCONV(vol->volconv))
        return Invalid_volconv ;

    if (!Validate_CALCONV(vol->cal))
        return Invalid_cal ;

    if (!Validate_INTPOLCONV(vol->ipol))
        return Invalid_intpolconv ;

    if (!Validate_EOMCONV(vol->eom))
        return Invalid_eomconv ;

    if (!Validate_BOOLE(vol->price_vol))
        return Invalid_boole ;

    v = Validate_DATEARRAY(vol->optmatur, vol->count_OM);
    if (v != Valid_data)
        return v;

    v = Validate_PERIODARRAY(vol->swapmatur, vol->count_SM);
    if (v != Valid_data)
        return v;

    /* Check that volatilities are non-negative: */
    for (k = 0; k < vol->count_OM && v == Valid_data; k++)
        v = Validate_FL64MATRIX(vol->vol[k], vol->count_S, 
            vol->count_SM, True, -valid_tol, False, 0.0);

    return Valid_data ;
}




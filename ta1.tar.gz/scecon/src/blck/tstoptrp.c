/* SCID @(#)tstoptrp.c	1.7 (SimCorp) 99/06/02 10:34:07 */

/************************************************************************
*
*   project     SCecon
*
************************************************************************/

/*** includes ***********************************************************/
#include <string.h>
#include <riskpos.h>
#include <bondio.h>
#include <ioconv.h>
#include <optrpos.h>
#include <optbond.h>
#include <capio.h>
#include <optio.h>
#include <futio.h>

INTI optrpostest(char* txa, FILE* in, FILE* out)
{
    char            txb[25], txpl[125] ;
    int             i1 ;
    FL64            price, notnal, tol, spot, beta, not, vol, 
                    spread ;
    HOLI_STR        holi ;
    BOOLE           zero, zeroeqv, zerodisc, zeroindex, zerocf, ok ;
    INTI            nbuck, diff, i, nbuckdisc, nbuckindex, nbuckcf, nstep ;
    YYYYMMDD        ymd ;
    DATESTR         analys, today, voldate ;
    DISCFAC         df, df_disc, df_index, df_cf, divdf ;
    FIXPAY          fixp ;
    BUCKETARRAY     bucket, bucket_disc, bucket_index, 
                    bucket_cf ;
    DFSPREAD        dfs ;
    DELTASET        ds, ds_disc, ds_index, ds_cf ;
    RISKPOSLIST     rpos, exprpos ;
    RISKTOKEN       token;
    OPTFUT          opt;
    VOL_STR         CMTvol, vols ;
    CMCONVADJ       cmadj ;
    DFWHICH         which, which_disc, which_index, which_cf ;
    CAP             cap ;
    B76SWTM         b76t ;
    SWAPTION        ncsw ;
    CONVTBL         cvt ;
    FXRISKSET       fxr;
    FUTBOND         futb ;

    diff = -1 ;
    if (!strcmp(txa, "OptBond_Black2RiskPos()") )
    {
        fscanf(in,"%lf %ld", &tol, &ymd) ;

        today = Cldr_YMD2Datestr(ymd) ;

        fprintf(out,"   Testing %s\n", txa) ;
        fprintf(out,"   Analysdate    %8ld\n", ymd) ;

        fixp = Read_FIXPAY(in, out, &today) ;
        opt  = Read_OPTFUT(in, out) ;

        fscanf(in,"%lf %lf %lf", &price, &not, &vol) ;
        
        fprintf(out,"   Spot price    %8.5lf\n", price) ;
        fprintf(out,"   Notional      %8.5lf\n", not) ;
        fprintf(out,"   Vol           %8.5lf\n", vol) ;
        
        df   = Read_DISCFAC(in, out) ;
        holi  = Set_HOLI_STR(NO_BUSADJUST, 0, NULL) ;
        bucket = Read_BUCKETARRAY(in, out, &nbuck) ;

        fscanf(in, "%s", txb) ;
        zeroeqv = Str2BOOLE(txb) ;
        fprintf(out,"   DECF        %8s\n", txb) ;

        fxr = Read_FXRISKSET(in, out) ;

        ds = Disc_DeltaPrep(&df, bucket, nbuck, &holi, False, df.irr,
                            df.freq, False, zeroeqv, DF_BOTH) ;

        
        rpos = OptBond_Black2RiskPos(&today, &opt, &fixp, price, not, 
                                     &today, vol, &df, NULL, &holi, 
                                     &ds, &fxr) ;

        exprpos.token = Alloc_RISKTOKENARRAY(rpos.npos) ;
        exprpos.pos   = Alloc_FL64ARRAY(rpos.npos) ;
        exprpos.npos  = rpos.npos ;

        for (i = 0; i < exprpos.npos; i++)
        {
            Read_RISKTOKEN(in, out, &exprpos.token[i]) ;
            fscanf(in, "%lf", &exprpos.pos[i]) ;
        }

        diff = Write_riskposdiff(exprpos, rpos, out, tol) ;

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_PLANARRAY(df.disc, 1) ;
        Free_DELTASET(&ds) ;
        Free_BUCKETARRAY(bucket) ;
        Free_FIXPAY(&fixp) ;

        Free_RISKPOSLIST(&rpos);
        Free_RISKPOSLIST(&exprpos);
        Free_OPTFUT(&opt) ;
    }

    if (!strcmp(txa, "OptFutBond_Black2RiskPos()"))
    {
        fscanf(in,"%lf %ld", &tol, &ymd) ;

        today = Cldr_YMD2Datestr(ymd) ;

        fprintf(out,"   Testing %s\n", txa) ;
        fprintf(out,"   Analysdate    %8ld\n", ymd) ;

        futb = Read_FUTBOND(in, out, &today) ;
        opt  = Read_OPTFUT(in, out) ;

        fscanf(in,"%lf %lf", &not, &vol) ;
        fprintf(out,"   Notional      %8.5lf\n", not) ;
        fprintf(out,"   Vol           %8.5lf\n", vol) ;
        
        df   = Read_DISCFAC(in, out) ;
        holi  = Set_HOLI_STR(NO_BUSADJUST, 0, NULL) ;
        bucket = Read_BUCKETARRAY(in, out, &nbuck) ;

        fscanf(in, "%s", txb) ;
        zeroeqv = Str2BOOLE(txb) ;
        fprintf(out,"   DECF        %8s\n", txb) ;

        fxr = Read_FXRISKSET(in, out) ;

        ds = Disc_DeltaPrep(&df, bucket, nbuck, &holi, False, df.irr,
                            df.freq, False, zeroeqv, DF_BOTH) ;

        rpos = OptFutBond_Black2RiskPos(&today, &opt, &futb, 
                                        not, &today, vol, &df, 0, 
                                        NULL, &holi, &ds, &fxr) ;

        exprpos.token = Alloc_RISKTOKENARRAY(rpos.npos) ;
        exprpos.pos   = Alloc_FL64ARRAY(rpos.npos) ;
        exprpos.npos  = rpos.npos ;

        for (i = 0; i < exprpos.npos; i++)
        {
            Read_RISKTOKEN(in, out, &exprpos.token[i]) ;
            fscanf(in, "%lf", &exprpos.pos[i]) ;
        }

        diff = Write_riskposdiff(exprpos, rpos, out, tol) ;

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_PLANARRAY(df.disc, 1) ;
        Free_DELTASET(&ds) ;
        Free_BUCKETARRAY(bucket) ;
        Free_FUTBOND(&futb) ;

        Free_RISKPOSLIST(&rpos);
        Free_RISKPOSLIST(&exprpos);
        Free_OPTFUT(&opt) ;
    }


    else if (!strcmp("Cap_Black2RiskPos()", txa))
    {
        /* Note that Caplets_Black2RiskPos is testes indirectly,
           since Cap_Black2RiskPos translate the cap to caplets
           and then call Caplets_Black2RiskPos */

        fprintf(out,"   Testing %s\n", txa) ;

        /* Read data */
        tol      = Read_FL64(in, out, "Tolerance   ") ;
        analys   = Read_DATESTR(in, out, "Analys date  ") ;
        voldate  = Read_DATESTR(in, out, "Vol date     ") ;
        cap      = Read_CAP(in, out) ;
        notnal   = Read_FL64(in, out, "Notional  ") ;
        df_index = Read_DISCFAC(in, out) ;
        df_disc  = Read_DISCFAC(in, out) ;
        vols     = Read_VOL_STR(in, out) ;
        CMTvol   = Read_VOL_STR(in, out) ;
        holi     = Read_HOLI_STR(in, out) ;

        bucket_index = Read_BUCKETARRAY(in, out, &nbuckindex) ;
        zeroindex    = Read_BOOLE(in, out, "DECF  ") ; 
        which_index  = Read_DFWHICH(in, out, "Which ") ;

        bucket_disc = Read_BUCKETARRAY(in, out, &nbuckdisc) ;
        zerodisc    = Read_BOOLE(in, out, "DECF  ") ;
        which_disc  = Read_DFWHICH(in, out, "Which ") ;

        fxr = Read_FXRISKSET(in, out) ;

        /* Initialise */
        ds_index = Disc_DeltaPrep(&df_index, bucket_index, nbuckindex, 
                                   &holi, True, df_index.irr, 
                                   df_index.freq, False, zeroindex, 
                                   which_index) ;
        ds_disc = Disc_DeltaPrep(&df_disc, bucket_disc, nbuckdisc, &holi,
                                  True, df_disc.irr, df_disc.freq, False,
                                  zerodisc, which_disc) ;

        cmadj = Set_CMCONVADJ(CMADJ_ORIG, &CMTvol, &vols, 0.0) ;

        /* Calculate */
        rpos = Cap_Black2RiskPos(&analys, &voldate, &cap, notnal, 
                                 &df_index, &df_disc, &vols, &cmadj, 
                                 &holi, &ds_index, &ds_disc, &fxr) ;

        /* Read expected results */
        fscanf(in, "%d", &i1) ;
        exprpos.npos = (INTI) i1 ;
        exprpos.token = Alloc_RISKTOKENARRAY(exprpos.npos) ;
        exprpos.pos   = Alloc_FL64ARRAY(exprpos.npos) ;

        for (i = 0; i < exprpos.npos; i++)
        {
            Read_RISKTOKEN(in, out, &exprpos.token[i]) ;
            fscanf(in, "%lf", &exprpos.pos[i]) ;
        }

        /* Compare */
        diff = Write_riskposdiff(exprpos, rpos, out, tol) ;
    
        /* Comments */
        IOUtil_ParseLine(in, out) ;

        /* Free */
        Free_CAP(&cap) ;
        Free_DATEARRAY(holi.holidays) ;
        Free_DELTASET(&ds_index) ;
        Free_DELTASET(&ds_disc) ;
        Free_PLANARRAY(df_index.disc, 1) ;
        Free_PLANARRAY(df_disc.disc, 1) ;
        Free_BUCKETARRAY(bucket_index) ;
        Free_BUCKETARRAY(bucket_disc) ;
        Free_PLANARRAY(CMTvol.vol, 1) ;
        Free_PLANARRAY(vols.vol, 1) ;
        Free_RISKPOSLIST(&rpos);
        Free_RISKPOSLIST(&exprpos);
    }

    else if (!strcmp("Swaption_Black2RiskPos()", txa))
    {
        fprintf(out,"   Testing %s\n", txa) ;

        /* Read data */
        tol       = Read_FL64(in, out, "Tolerance   ") ;
        analys    = Read_DATESTR(in, out, "Analys date  ") ;
        vol       = Read_FL64(in, out, "Volatilities ") ;
        ncsw      = Read_SWAPTION(in, out) ;
        notnal    = Read_FL64(in, out, "Notional  ") ;
        df        = Read_DISCFAC(in, out) ;
        df_cf     = Read_DISCFAC(in, out) ;
        CMTvol    = Read_VOL_STR(in, out) ;
        holi      = Read_HOLI_STR(in, out) ;
        b76t      = Read_B76SWTM(in, out) ;
        bucket    = Read_BUCKETARRAY(in, out, &nbuck) ;
        zero      = Read_BOOLE(in, out, "DECF  ") ;
        which     = Read_DFWHICH(in, out, "Which ") ;
        bucket_cf = Read_BUCKETARRAY(in, out, &nbuckcf) ;
        zerocf    = Read_BOOLE(in, out, "DECF  ") ;  
        which_cf  = Read_DFWHICH(in, out, "Which ") ;
        fxr       = Read_FXRISKSET(in, out) ;

        /* Initialise */
        ds    = Disc_DeltaPrep(&df, bucket, nbuck, &holi, True, df.irr, 
                                df.freq, False, zero, which) ;
        ds_cf = Disc_DeltaPrep(&df_cf, bucket_cf, nbuckcf, &holi, True, 
                                df_cf.irr, df_cf.freq, False, zerocf, 
                                which_cf) ;
        cmadj = Set_CMCONVADJ(CMADJ_ORIG, &CMTvol, NULL, 0.0) ;

        /* Calculate */
        rpos = Swaption_Black2RiskPos(&analys, &analys, vol, &ncsw, notnal,
                                      &df, &df_cf, &cmadj, &holi, &b76t, &ds,
                                      &ds_cf, &fxr, &ok) ;

        /* Read expected results */
        fscanf(in, "%d", &i1) ;
        exprpos.npos = (INTI) i1 ;
        exprpos.token = Alloc_RISKTOKENARRAY(exprpos.npos) ;
        exprpos.pos   = Alloc_FL64ARRAY(exprpos.npos) ;

        for (i = 0; i < exprpos.npos; i++)
        {
            Read_RISKTOKEN(in, out, &exprpos.token[i]) ;
            fscanf(in, "%lf", &exprpos.pos[i]) ;
        }

        /* Compare */
        diff = Write_riskposdiff(exprpos, rpos, out, tol) ;
    
        /* Comments */
        IOUtil_ParseLine(in, out) ;

        /* Free */
        Free_SWAPTION(&ncsw) ;
        Free_DATEARRAY(holi.holidays) ;
        Free_DELTASET(&ds) ;
        Free_DELTASET(&ds_cf) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_PLANARRAY(df_cf.disc, 1) ;
        Free_BUCKETARRAY(bucket) ;
        Free_BUCKETARRAY(bucket_cf) ;
        Free_PLANARRAY(CMTvol.vol, 1) ;
        Free_RISKPOSLIST(&rpos);
        Free_RISKPOSLIST(&exprpos);
    }


    else if (!strcmp("Convtbl_CRR2RiskPos()", txa))
    {
        fprintf(out,"   Testing %s\n", txa) ;

        /* Read data */
        tol    = Read_FL64(in, out, "Tolerance   ") ;
        analys = Read_DATESTR(in, out, "Analys date  ") ;
        spot   = Read_FL64(in, out, "Spot  ") ;
        vol    = Read_FL64(in, out, "Vol   ") ;
        nstep  = Read_INTI(in, out, "NStep ") ;
        cvt    = Read_CONVTBL(in, out, &analys) ;
        notnal = Read_FL64(in, out, "Notional  ") ;
        beta   = Read_FL64(in, out, "Beta      ") ;
        Read_RISKTOKEN(in, out, &token) ;
        df     = Read_DISCFAC(in, out) ;
        spread = Read_FL64(in, out, "   Spread   ") ;
        divdf  = Read_DISCFAC(in, out) ;
        bucket = Read_BUCKETARRAY(in, out, &nbuck) ;
        zero   = Read_BOOLE(in, out, "DECF  ") ;
        fxr    = Read_FXRISKSET(in, out) ;

        /* Initialise */
        holi = Set_HOLI_STR(NO_BUSADJUST, 0, NULL) ;
        dfs  = Set_DFSPREAD(spread, COMPOUND, ANNUALLY, NULL) ;
        ds   = Disc_DeltaPrep(&df, bucket, nbuck, &holi, False, df.irr, 
                               df.freq, True, zero, DF_BOTH) ;

        /* Calculate */
        rpos = Convtbl_CRR2RiskPos(&analys, spot, vol, nstep, &cvt, notnal,
                                   beta, &token, &df, &dfs, &divdf, &holi, 
                                   &ds, &fxr, &ok) ;

        /* Read expected results */
        fscanf(in, "%d", &i1) ;
        exprpos.npos = (INTI) i1 ;
        exprpos.token = Alloc_RISKTOKENARRAY(exprpos.npos) ;
        exprpos.pos   = Alloc_FL64ARRAY(exprpos.npos) ;

        for (i = 0; i < exprpos.npos; i++)
        {
            Read_RISKTOKEN(in, out, &exprpos.token[i]) ;
            fscanf(in, "%lf", &exprpos.pos[i]) ;
        }

        /* Compare */
        diff = Write_riskposdiff(exprpos, rpos, out, tol) ;
    
        /* Comments */
        IOUtil_ParseLine(in, out) ;

        /* Free */
        Free_PLANARRAY(divdf.disc, 1) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_DELTASET(&ds) ;
        Free_BUCKETARRAY(bucket) ;
        Free_CONVTBL(&cvt) ;
        Free_RISKPOSLIST(&rpos);
        Free_RISKPOSLIST(&exprpos);
    }



    return diff ;
}




/*
..
*/



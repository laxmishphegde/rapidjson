/* SCID @(#)capalloc.c	1.8 (SimCorp) 99/10/27 13:36:27 */

/************************************************************************
*
*   project     SCecon
*
*   file name   capalloc.c
*
*   general     This file contains allocating routines for cap/floors
*
************************************************************************/

#include <cap.h>


/*,,SOH,,
*************************************************************************
*
*               Alloc_IRGARRAY()
*
*    interface  #include <cap.h>
*               IRGARRAY Alloc_IRGARRAY(INTI n) ;
*
*    general    Alloc_IRGARRAY() allocates memory for an
*               [0...(n-1)] array of IRG_STR's.
*               Returns memory with zero'ed entries
*
*    input      INTI    n       The number of entries in IRG_STR list
*
*    output
*
*    returns    reference to the vector of type IRG_STR
*
*    diagnostics aborts calling SCecon_error()
*                with the message   "Memory allocation error"
*                         routine   "Alloc_IRGARRAY()"
*                         actioncode SCECONABORT
*                if allocation fails
*
*    see also   Free_IRGARRAY()
*
*************************************************************************
,,EOH,,*/


IRGARRAY Alloc_IRGARRAY(INTI n)
{
    IRGARRAY a;

    a = (IRGARRAY) SCecon_calloc (n, sizeof(IRG_STR), True, 
      "Alloc_IRGARRAY()") ;

    return a ;
}


/*,,SOH,,
*************************************************************************
*
*               Free_IRGARRAY()
*
*    interface  #include <cap.h>
*               void Free_IRGARRAY(IRGARRAY vector) ;
*
*    general    Free_IRGARRAY() frees memory for an array
*               of IRG_STR's allocated by Alloc_IRGARRAY()
*
*    input      IRGARRAY vector        Reference to the array
*
*    output
*
*    returns
*
*    diagnostics
*
*    see also   Alloc_IRGARRAY()
*
*************************************************************************
,,EOH,,*/


void Free_IRGARRAY(IRGARRAY vector)
{
    SCecon_free((VOIDPTR) vector) ;
}


/*,,SOH,,
*************************************************************************
*
*                Alloc_CAPLETSARRAY()
*
*    interface   #include <cap.h>
*                CAPLETSARRAY Alloc_CAPLETSARRAY(INTI  nstr,
*                                                INTI  np,
*                                                BOOLE sub) ;
*
*    general     Allocates memory for an array that can hold the
*                information about nstr cap structures.
*                Returns memory with zero'ed entries.
*
*    input       INTI  nstr   Number of structures.
*
*                INTI  np     Number of entries in each IRGARRAY.
*
*                BOOLE sub    Alloc IRGARRAY's ? True means YES and
*                             False NO.
*
*    output
*
*    returns     Reference to allocated CAPLETSARRAY
*
*    diagnostics aborts calling SCecon_error()
*                with the message   "Memory allocation error"
*                         routine   "Alloc_CAPLETSARRAY"
*                         actioncode SCECONABORT
*                if allocation fails
*
*    see also    Free_CAPLETSARRAY()
*
*************************************************************************
,,EOH,,*/

CAPLETSARRAY Alloc_CAPLETSARRAY(INTI nstr, INTI  np, BOOLE sub)
{
    CAPLETSARRAY a ;
    INTI         i ;

    a = (CAPLETSARRAY) SCecon_calloc(nstr, sizeof(CAPLETS), True,
      "Alloc_CAPLETSARRAY()") ;

    if (sub == True)
    {
        for (i = 0 ; i < nstr ; ++i)
            a[i].irg = Alloc_IRGARRAY(np) ;
    }

    return a ;
}


/*,,SOH,,
*************************************************************************
*
*                Free_CAPLETSARRAY()
*
*    interface   #include <cap.h>
*                void Free_CAPLETSARRAY(CAPLETSARRAY s,
*                                       INTI         nstr) ;
*
*    general     Frees memory for a nstr number of CAPLETSARRAY's
*                allocated by Alloc_CAPLETSARRAY()
*
*    input       CAPLETSARRAY s     Reference to the CAPLETSARRAY
*
*                INTI         nstr  Number of structs in s.
*
*    output
*
*    returns
*
*    diagnostics
*
*    see also    Alloc_CAPLETSARRAY()
*
*************************************************************************
,,EOH,,*/

void Free_CAPLETSARRAY(CAPLETSARRAY s, INTI  nstr)
{
    INTI    i ;

    nstr = GETMAX(1, nstr) ;

    for (i = 0 ; i < nstr ; i++)
        Free_IRGARRAY(s[i].irg) ;

    SCecon_free((VOIDPTR) s) ;
}


/*,,SOH,,
*************************************************************************
*
*               Alloc_SWAPTIONARRAY()
*
*    interface  #include <cap.h>
*               SWAPTIONARRAY Alloc_SWAPTIONARRAY(INTI n) ;
*
*    general    Alloc_SWAPTIONARRAY() allocates memory for an
*               [0...(n-1)] array of SWAPTION's.
*               Returns memory with zero'ed entries
*
*    input      INTI    n       The number of entries in SWAPTION list
*
*    output
*
*    returns    reference to the vector of type SWAPTION
*
*    diagnostics aborts calling SCecon_error()
*                with the message   "Memory allocation error"
*                         routine   "Alloc_SWAPTIONARRAY()"
*                         actioncode SCECONABORT
*                if allocation fails
*
*    see also   Free_SWAPTIONARRAY()
*
*************************************************************************
,,EOH,,*/


SWAPTIONARRAY Alloc_SWAPTIONARRAY(INTI n)
{
    SWAPTIONARRAY a;

    a = (SWAPTIONARRAY) SCecon_calloc (n, sizeof(SWAPTION), True, 
      "Alloc_SWAPTIONARRAY()") ;

    return a ;
}


/*,,SOH,,
*************************************************************************
*
*               Free_SWAPTIONARRAY()
*
*    interface  #include <cap.h>
*               void Free_SWAPTIONARRAY(SWAPTIONARRAY vector) ;
*
*    general    Free_SWAPTIONARRAY() frees memory for an array
*               of SWAPTION's allocated by Alloc_SWAPTIONARRAY()
*
*    input      SWAPTIONARRAY vector        Reference to the array
*
*    output
*
*    returns
*
*    diagnostics
*
*    see also   Alloc_SWAPTIONARRAY()
*
*************************************************************************
,,EOH,,*/


void Free_SWAPTIONARRAY(SWAPTIONARRAY vector)
{
    SCecon_free((VOIDPTR) vector) ;
}


/*,,SOH,,
*************************************************************************
*
*               Alloc_OPTFUTARRAY()
*
*    interface  #include <cap.h>
*               OPTFUTARRAY Alloc_OPTFUTARRAY(INTI n) ;
*
*    general    Alloc_OPTFUTARRAY() allocates memory for an
*               [0...(n-1)] array of OPTFUT's.
*               Returns memory with zero'ed entries
*
*    input      INTI    n       The number of entries in OPTFUT list
*
*    output
*
*    returns    reference to the vector of type OPTFUT
*
*    diagnostics aborts calling SCecon_error()
*                with the message   "Memory allocation error"
*                         routine   "Alloc_OPTFUTARRAY()"
*                         actioncode SCECONABORT
*                if allocation fails
*
*    see also   Free_OPTFUTARRAY()
*
*************************************************************************
,,EOH,,*/

OPTFUTARRAY Alloc_OPTFUTARRAY(INTI n)
{
    OPTFUTARRAY a;

    a = (OPTFUTARRAY) SCecon_calloc (n, sizeof(OPTFUT), True,
      "Alloc_OPTFUTARRAY()") ;

    return a ;
}


/*,,SOH,,
*************************************************************************
*
*               Free_OPTFUTARRAY()
*
*    interface  #include <cap.h>
*               void Free_OPTFUTARRAY(OPTFUTARRAY vector, INTI n) ;
*
*    general    Free_OPTFUTARRAY() frees memory for an array
*               of OPTFUT's allocated by Alloc_OPTFUTARRAY()
*
*    input      OPTFUTARRAY vector        Reference to the array
*                                         [n]    
*
*               INTI        n             Size of the array
*
*    output
*
*    returns
*
*    diagnostics
*
*    see also   Alloc_OPTFUTARRAY()
*
*************************************************************************
,,EOH,,*/

void Free_OPTFUTARRAY(OPTFUTARRAY vector,INTI n)
{
  INTI i;

  if (vector == NULL)
    return;
  
  for (i = 0; i < n; i++)
    Free_OPTFUT(&vector[i]);
  
  SCecon_free((VOIDPTR) vector) ;
}


/*,,SOH,,
*************************************************************************
*
*               Free_CAP()
*
*    interface  #include <cap.h>
*               void Free_CAP(CAP *s) ;
*
*    general    Free_CAP() frees memory for a CAP
*
*    input      CAP *s        Reference to the cap
*
*    output
*
*    returns
*
*    diagnostics
*
*    see also   
*
*************************************************************************
,,EOH,,*/

void Free_CAP(CAP* s)
{
    Free_DATEARRAY(s->fix_days.irreg_days);
    Free_PLANARRAY(s->step_str, 1) ;
    Free_PLANARRAY(s->step_not, 1) ;
}



/*,,SOH,,
*************************************************************************
*
*               Free_SWAPTION()
*
*    interface  #include <cap.h>
*               void Free_SWAPTION(SWAPTION *s) ;
*
*    general    Free_SWAPTION() frees memory for a SWAPTION
*
*    input      SWAPTION *s        Reference to the SWAPTION
*
*    output
*
*    returns
*
*    diagnostics
*
*    see also   
*
*************************************************************************
,,EOH,,*/

void Free_SWAPTION(SWAPTION* s)
{
    Free_PLANARRAY(s->fix.stepcoup, 1);
    Free_PLANARRAY(s->fix.irreg, 1);
    Free_PAYDAYDEF(&s->pfix);
    Free_PAYDAYDEF(&s->pfl);
    Free_PLANARRAY(s->amort, 1);
}


/*,,SOH,,
*************************************************************************
*
*                Alloc_CAPARRAY()
*
*    interface   #include <cap.h>
*                CAPARRAY Alloc_CAPARRAY(INTI  n) ;
*
*    general     Allocates memory for an array that can hold the
*                information about nstr cap structures.
*                Returns memory with zero'ed entries.
*
*    input       INTI  n      Number of structures.
*
*    output
*
*    returns     Reference to allocated CAPARRAY
*
*    diagnostics aborts calling SCecon_error()
*                with the message   "Memory allocation error"
*                         routine   "Alloc_CAPARRAY"
*                         actioncode SCECONABORT
*                if allocation fails
*
*    see also    Free_CAPARRAY()
*
*************************************************************************
,,EOH,,*/

CAPARRAY Alloc_CAPARRAY(INTI n)
{
    CAPARRAY a ;

    a = (CAPARRAY) SCecon_calloc(n, sizeof(CAP), True, 
      "Alloc_CAPARRAY()") ;

    return a ;
}


/*,,SOH,,
*************************************************************************
*
*                Free_CAPARRAY()
*
*    interface   #include <cap.h>
*                void Free_CAPARRAY(CAPARRAY s, INTI nstr, BOOLE sub) ;
*
*    general     Frees memory for a nstr number of CAPARRAY's
*                allocated by Alloc_CAPARRAY()
*
*    input       CAPARRAY s     Reference to the CAPARRAY
*
*                INTI     nstr  Number of structs in s.
*
*                BOOLE    sub   Free embedded pointers if True.
*
*    output
*
*    returns
*
*    diagnostics
*
*    see also    Alloc_CAPARRAY()
*
*************************************************************************
,,EOH,,*/

void Free_CAPARRAY(CAPARRAY s, INTI  nstr, BOOLE  sub)
{
    INTI i;

    if (sub)
    {
        for (i = 0; i < nstr; i++)
        {
            Free_CAP(&s[i]);
        }
    }

    SCecon_free((VOIDPTR) s) ;
}



/* SCID @(#)callswap.c	1.6 (SimCorp) 99/02/19 14:09:23 */

/************************************************************************
*
*   project     SCecon
*
*   file name   callswap.c
*
*   general     This file contains calculation routines for 
*               callable par swaps
*
************************************************************************/

#include <cap.h>

/*** defines  **********************************************************/
#define FIXRATE_FREQ      3
#define FIXRATE_DAMP      0.9
#define FIXRATE_ACC       0.00000001
#define FIXRATE_GUESS     10.0
#define FIXRATE_MIN       -1000.0
#define FIXRATE_MAX       1000.0
#define FIXRATE_EPS       0.01
#define FIXRATE_MAXIT     100


/*,,SOH,,
*************************************************************************
*
*               SwapCall_Simple2SWAPCALL()
*
*    interface  #include <cap.h>
*               SWAPCALL SwapCall_Simple2SWAPCALL(BOOLE pay_fix, 
*                                                 BOOLE    extend,
*                                                 BOOLE    berm,
*                                                 FL64     swap_rate,
*                                                 DATESTR* start,
*                                                 PERIOD*  first_call,
*                                                 PERIOD*  last_call,
*                                                 PERIOD*  matur,
*                                                 CALCONV  cal,
*                                                 EOMCONV  eom,
*                                                 PMTFREQ  freq)
*
*    general    The routine generates a SWAPCALL based on simple data.
*
*               Typically this can handle a callable par swap at issue as
*               10Y with a call in 5Y semiannually paying, strike 6.5)
*
*    input      BOOLE    pay_fix     Payer/Receiver Swap
*
*               BOOLE    extend      Extendible/Cancelable swap
*
*               BOOLE    berm        Bermudan/European.
*
*               FL64     swap_rate   The fixed side swap rate
*
*               DATESTR  *start      The swap start date
*
*               PERIOD   *first_call Time from start till first call date. Only
*                                    applicable for Bermudan style.
*
*               PERIOD   *last_call  Time from start till last call date. For
*                                    Bermudan style callable swaps this is the
*                                    call date.
*
*               PERIOD   *matur      Time from start till final maturity.
*
*               CALCONV  cal         The swap daycount method
*
*               EOMCONV  eom         Month end adjustment
*
*               PMTFREQ  freq        Fixed side roll (eg. semiann)
*
*
*    output
*
*    returns    The SWAPCALL data type
*
*    diagnostics
*
*    see also   SwapCall_Black2P()
*               SwapCall_HW2P()
*
*************************************************************************
,,EOH,,*/

SWAPCALL SwapCall_Simple2SWAPCALL(BOOLE  pay_fix, 
                                  BOOLE  extend,
                                  BOOLE  berm,
                                  FL64  swap_rate,
                                  DATESTR*  start,
                                  PERIOD*   first_call,
                                  PERIOD*   last_call,
                                  PERIOD*   matur,
                                  CALCONV  cal,
                                  EOMCONV  eom,
                                  PMTFREQ  freq)
{
  SWAPCALL  cswap;
  FIXRATE   fix;
  PAYDAYDEF pfix;
  DATESTR   first_call_date;
  DATESTR   last_call_date;
  DATESTR   maturity;
  HOLI_STR  holi;

  holi = Set_HOLI_STR(NO_BUSADJUST, 0, NULL);

  if (first_call)
    first_call_date = Cldr_AddPeriod(start, first_call, cal, eom, &holi);
  else
    first_call_date = Cldr_YMD2Datestr(0);
  last_call_date = Cldr_AddPeriod(start, last_call, cal, eom, &holi);
  maturity  = Cldr_AddPeriod(start, matur, cal, eom, &holi);

  fix = Set_FIXRATE(swap_rate, cal, start, NULL, 0.0, ODDCOUP, ODDCOUP, 
                          False, False, NULL, True, NULL, NODCOMP);


  pfix = Set_PAYDAYDEF(False, start, NULL, &maturity, False, NULL, 0, NULL);
  pfix.pseq.unit = MONTHS;
  pfix.pseq.term = Cflw_MonthsBetweenPayments(freq);
  pfix.pseq.eom = eom;

  cswap = Set_SWAPCALL(pay_fix, extend, berm, &first_call_date,
      &last_call_date, cal, &fix, &pfix);

  return cswap;
}


/*,,SOH,,
************************************************************************
*
*                Set_SWAPCALL()
*
*   interface    #include <cap.h>
*                SWAPCALL Set_SWAPCALL(BOOLE     pay_fix,
*                                      BOOLE     extend,
*                                      BOOLE     berm,
*                                      DATESTR   *first_call,
*                                      DATESTR   *last_call,
*                                      CALCONV   cal,
*                                      FIXRATE   *fix,
*                                      PAYDAYDEF *pfix)
*
*   general      This routine sets the members of the struct defined
*                in the function name. The pointer members are simply
*                assigned - without physical copying. The intention
*                of the Set_*() routines is that by using this
*                functionality, one avoids setting individual members
*                of structs in the application code.
*
*                When new members are inserted in structs the Set_*()
*                routine will be changed accordingly.
*
*                One exception to this principle applies. Whenever
*                OPTADD and vanilla members are used, only the
*                vanilla members are set in the Set_*() routines. The
*                non-vanilla and exotic members are set to defaults,
*                and must be set elsewhere - if needed.
*
*                For details on the interpretation of the individual
*                struct members please check the struct definition.
*
*   input        BOOLE      pay_fix     See general section.
*
*                BOOLE      extend      See general section.
*
*                BOOLE      berm        See general section.
*
*                DATESTR    *first_call See general section.
*
*                DATESTR    *last_call  See general section.
*
*                CALCONV    cal         See general section.
*
*                FIXRATE*   fix         See general section.
*
*                PAYDAYDEF* pfix        See general section.
*
*   output
*
*   returns      The filled out SWAPCALL struct
*
*   diagnostics
*
*   see also     SWAPCALL
*
************************************************************************
,,EOH,,*/

SWAPCALL Set_SWAPCALL(BOOLE      pay_fix,
                         BOOLE      extend,
                         BOOLE      berm,
                         DATESTR*   first_call,
                         DATESTR*   last_call,
                         CALCONV    cal,
                         FIXRATE*   fix,
                         PAYDAYDEF* pfix)
{
  SWAPCALL cswap;

  cswap.pay_fix = pay_fix;
  cswap.extend  = extend;
  cswap.berm    = berm;
  cswap.first_call = *first_call;
  cswap.last_call  = *last_call;
  cswap.cal        = cal;
  cswap.fix        = *fix;
  cswap.pfix       = *pfix;

  return cswap;
}


/*,,SOH,,
*************************************************************************
*
*               SwapCall_Black2P()
*
*    interface  #include <cap.h>
*               BOOLE SwapCall_Black2P(DATESTR*    analys,
*                                      DATESTR*    voldate,
*                                      FL64        vol,
*                                      SWAPCALL*   swap,
*                                      DISCFAC*    df,
*                                      HOLI_STR*   holi,
*                                      B76SWTM*    b76t,
*                                      FL64*       p)
*
*    general    The routine computes the theoretical price for a
*               callable swap by splitting this into a par swap
*               and a vanilla swaption. The swap is then priced
*               using the SwapFix_DF2NPV() function whilst the swaption 
*               part is priced using the Swaption_Black2P(). The result
*               is the combined price of the fixed leg of the swap and
*               the option.
*
*    input      DATESTR  *analys  Pointer to analysis date (NPV date)
*
*               DATESTR  *voldate Vol is calculated from this date
*
*               FL64     vol      The volatility of the forward starting
*                                 swap's swaprate in %.
*                                 See Swaption_VOLBOX2Vol()
*
*               SWAPCALL *swap    Pointer to swap data. Only European
*                                 callable swaps are allowed (berm = False).
*
*               DISCFAC  *df      Discount function setup for discounting
*                                 future payments.
*
*               HOLI_STR *holi    Holiday adjustment setup.
*
*               B76SWTM  *b76t    Black 76 model variation to be used
*                                 Enter NULL for default model
*
*    output     FL64     *p       Pointer to the premium in %
*
*    returns    True if all is OK, and False if not.
*
*    diagnostics
*
*    see also   SwapCall_Simple2SWAPCALL()
*               Swaption_Black2P()
*               SwapFix_DF2NPV()
*               SwapCall_Black2Impl()
*
*    wrapper    AP
*
*************************************************************************
,,EOH,,*/

BOOLE SwapCall_Black2P(DATESTR* analys,
                       DATESTR*    voldate,
                       FL64        vol,
                       SWAPCALL*   swap,
                       DISCFAC*    df,
                       HOLI_STR*   holi,
                       B76SWTM*    b76t,
                       FL64*       p)
{
  SWAPTION swpt;
  SWAPFIX  sfix;
  OPTTYPE  type;
  BOOLE    ok;
  DATESTR  swapmatur;
  FL64     swpt_p, swap_p, dp, ddp;

  if (swap->extend)
  {
    swapmatur = swap->last_call;
    if (swap->pay_fix)
      type = PUT;
    else
      type = CALL;
  }
  else 
  {
    swapmatur = swap->pfix.last;
    if (swap->pay_fix)
      type = CALL;
    else 
      type = PUT;
  }


  swpt = Set_SWAPTION(type, &swap->last_call, swap->cal, True,
                      &swap->fix, &swap->pfix);
  swpt.pfix.first = swap->last_call;
  swpt.pfix.is_first = False;
  swpt.fix.effective = swap->last_call;

  sfix = Set_SWAPFIX(NULL, NULL, &swap->fix, &swap->pfix, 0);
  sfix.pday.last = sfix.rday.last = swapmatur;

  ok = Swaption_Black2P(analys, voldate, vol, &swpt, df, df,
                       NULL, holi, b76t, NULL, &swpt_p, &dp, &ddp);

  swap_p = SwapFix_DF2NPV(analys, &sfix, holi, df, NULL, &dp, &ddp);

  if (swap->pay_fix)
    *p = swap_p - swpt_p;
  else 
    *p = swap_p + swpt_p;

  return ok;
}



/*,,SOH,,
*************************************************************************
*
*               SwapCall_Black2Impl()
*
*    interface  #include <cap.h>
*               BOOLE SwapCall_Black2Impl(DATESTR* analys,
*                                      DATESTR*    voldate,
*                                      FL64        vol,
*                                      FL64        npv,
*                                      SWAPCALL*   swap,
*                                      DISCFAC*    df,
*                                      HOLI_STR*   holi,
*                                      B76SWTM*    b76t,
*                                      FL64*       impl)
*
*
*    general    The routine computes the implied swaprate for a
*               callable swap by splitting this into a par swap
*               and a vanilla swaption as in SwapCall_Black2P().
*
*               df_cf and cmadj are only used if ncsw->vanilla is False
*
*    input      DATESTR   *analys Pointer to analysis date (NPV date)
*
*               DATESTR   *voldate Vol is calculated from this date
*
*               FL64      vol     The volatility of the forward 
*                                 starting swap's swaprate in %.
*
*               FL64      npv     The premium of the option on analys.
*
*               SWAPCALL *swap    Pointer to swap data. Only European
*                                 callable swaps are allowed (berm = False).
*
*               DISCFAC  *df      Discount function setup for 
*                                 discounting future payments.
*
*               HOLI_STR *holi    Holiday adjustment setup.
*
*               B76SWTM  *b76t    Black 76 model variation to be used
*                                 Enter NULL for default model
*
*    output     FL64      *impl   Pointer to the implied ratio.
*
*    returns    True if all is OK, and False if not.
*
*    diagnostics
*
*    see also   SwapCall_Black2P()
*               SwapFix_DF2CFrate()
*               SwapFix_DF2Rate()
*
*    wrapper    AP
*
*************************************************************************
,,EOH,,*/
BOOLE SwapCall_Black2Impl(DATESTR* analys,
                       DATESTR*    voldate,
                       FL64        vol,
                       FL64        npv,
                       SWAPCALL*   swap,
                       DISCFAC*    df,
                       HOLI_STR*   holi,
                       B76SWTM*    b76t,
                       FL64*       impl)
{
  SWAPCALLINT si;
  ITERCTRL    ictrl;
  NR_ERR err;
  FL64 oldr;
  BOOLE ok;

  si.analys = analys;
  si.voldate = voldate;
  si.vol = vol;
  si.swap = swap;
  si.df = df;
  si.holi = holi;
  si.b76t = b76t;
  si.p = npv;
  si.shock = 1e-4;

  oldr = swap->fix.fix_rate;

  Init_ITERCTRL(&ictrl);
  ictrl.maxiter = FIXRATE_MAXIT ;
  ictrl.init_guess = FIXRATE_GUESS ;
  ictrl.lower = FIXRATE_MIN ;
  ictrl.upper = FIXRATE_MAX ;
  ictrl.damp = FIXRATE_DAMP ;
  ictrl.acc = FIXRATE_ACC ;
  ictrl.what_acc = 1 ;
  ictrl.gfreq = FIXRATE_FREQ ;
  ictrl.bisec = 2 ;
  ictrl.shock = 0.0 ;

  err = Newton_Raphson(&SwapCall_NewtonRaphson, &si, &ictrl, 
	  impl, holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */
  ok = (err == NR_ROOT_FOUND ? True : False) ;

  swap->fix.fix_rate = oldr ;

  return ok ;
  
}


BOOLE SwapCall_NewtonRaphson(FL64  x, 
                               void*  y,
                               BOOLE  grad,
                               FL64*  fx, 
							   FL64*  dfx, 
							   void*  hol)
{
  SWAPCALLINT *si;
  DATESTR*   analys;
  DATESTR*   voldate;
  FL64       vol, npv, p, p1, shock;
  SWAPCALL*  swap;
  DISCFAC*   df;
  HOLI_STR*  holi = (HOLI_STR* )hol;   /* PMSTA-29444 - SRIDHARA - 050318 */
  B76SWTM*   b76t;
  BOOLE ok;

  si = (SWAPCALLINT*) y;

  analys = si->analys;
  voldate = si->voldate;
  vol = si->vol;
  swap = si->swap;
  df = si->df;
  holi = si->holi;
  b76t = si->b76t;
  npv = si->p;
  shock = si->shock;

  swap->fix.fix_rate = x;
  ok = SwapCall_Black2P(analys, voldate, vol, swap, df, holi, b76t, &p);
  shock = (shock <= 0.0 ? 1e-6 : shock) ;

  *fx = p - npv;

  /* Calculate gradient */
  if (grad == True && ok)
  {
    swap->fix.fix_rate += shock;
    ok = SwapCall_Black2P(analys, voldate, vol, swap, df, holi, b76t, &p1);
    swap->fix.fix_rate -= shock;

    *dfx = ((p1 - npv) - *fx) / shock;
  }
  else
    *dfx = 0.0;

  return ok;
}


/* SCID @(#)tstcap.c	1.15 (SimCorp) 99/02/19 14:10:07 */

/************************************************************************
*
*   project     SCecon
*
*   filename    captest.c
*
************************************************************************/

/*** includes ***********************************************************/
#include <string.h>
#include <stdlib.h>
#include <cap.h>
#include <str2conv.h>
#include <ioconv.h>
#include <capio.h>
#include <optio.h>
#include <futio.h>

/*** the main() routine *************************************************/

INTI captest(char* txa, FILE* in, FILE* out)
{
    char        txb[25], txc[25], txd[25], txe[25], txf[25], txpl[120];
    char        txg[25], txh[25], txi[25], txj[25], txk[25], txm[25] ;
    FL64        vola, swaprate, size, strike, acc, fres, fres1, fres2, 
                fexp, Lfix = 0, shock, fexp1, fexp2, price, dur, *dv, 
                *dvexp, atm_vol ;
    OPTTYPE     type ;
    INTI        ndvexp, nbuck, nh, i, diff, dif1, nd, no, nv, nirg ;
    BOOLE       zero, ok, okexp ;
    DISCIPOL    ipol ;
    YYYYMMDD    ymd5, ymd4, ymd1, ymd, ymd2, ymd3 ;
    PLANARRAY   disc, vol, volc ;
    DATEARRAY   holi ;
    IRGARRAY    expirg, irg ;
    CALCONV     cal, ical, volcal ;
    SEQCONV     per ;
    EOMCONV     eom ;
    QOTCONV     qot ;
    VOLCONV     vc ;
    BUSCONV     bus ;
    KEYCONV     what ;
    PMTFREQ     freq ;
    KEYCONV     key, wrt ;
    RISKCONV    risk ;
    FL64ARRAY   expprem, prem, forwfix, expforwfix;
    INTIARRAY   caplength, expcaplength;
    DATESTR     dzero, vold, eff, matur, analys, start, end, maturity ;
    INTPOLCONV  iconv ;
    int         i1, i2, i3, i4, i6, i7 ;
    HOLI_STR    holis ;
    PAYDAYDEF   pday ;
    PAYDAYSEQ   pseq ;
    CAPLETS     cap ;
    RATEINDEX   index ;
    DISCFAC     df, df1 ;
    RISKSET     orsk ;
    ITERCTRL    ictrl ;
    BUCKETARRAY bucket ;
    SWAPTION    ncsw ;
    FIXRATE     fix ;
    PLAN_STR    dummy ;
    VOL_STR     CMTv, vols ;
    SWPTVOL     swvol ;
    CAP         capx ;
    B76SWTM     b76t ;
    VOLBOX      *vb ;
    CMCONVADJ   cmadj ;
    DELTASET    ds ;
    RATECONV    rt ;

    /* warning avoidance */
    memset(&orsk, 0, sizeof(orsk));

    diff = -1 ;

    if (!strcmp("Caplets_Black2P()", txa))
    {
        fscanf(in, "%lf %lf %lf %ld %d %d %d %s %s %s %s %s",
            &fexp, &fexp1, &fexp2, &ymd, &i2, &i3, &i4, txg,
            txc, txe, txb, txh);
        fscanf(in, "%lf %lf %s %s %s %d %s %lf %s %lf %s %s",
            &acc, &dur, txd, txi, txj, &i6, txm, &Lfix, txf,
            &shock, txk, txpl) ;

        no   = (INTI) i2 ;
        nd   = (INTI) i3 ;
        nv   = (INTI) i4 ;
        analys = Cldr_YMD2Datestr(ymd) ;

        cal  = Str2CALCONV(txc) ;
        qot  = Str2QOTCONV(txe) ;
        ipol = Str2DISCIPOL(txb) ;
        iconv= Str2INTPOLCONV(txh) ;
        vc   = Str2VOLCONV(txg) ;
        freq = Str2PMTFREQ(txm) ;
        key  = Str2KEYCONV(txf) ;
        risk = Str2RISKCONV(txk) ;
        rt = (Str2PMTFREQ(txi) == NO_FREQUENCY ? MMRATE : PARYIELD) ;
        ical = (Str2PMTFREQ(txi) == NO_FREQUENCY ? cal : EU30E360) ;
        index = Set_RATEINDEX(rt, dur, Str2TERMUNIT(txd), 
                              Str2PMTFREQ(txi), ical, 0.0) ;

        holis.bus   = Str2BUSCONV(txj) ;
        holis.nholi = (INTI) i6 ;
        holis.holidays = Alloc_DATEARRAY(holis.nholi) ;

        fprintf(out,"   testing %s\n", txa) ;
        fprintf(out,"   analysis       %8ld\n", ymd) ;
        fprintf(out,"   volconv        %8s\n", txg) ;
        fprintf(out,"   calendar       %8s\n", txc) ;
        fprintf(out,"   quoting        %8s\n", txe) ;
        fprintf(out,"   ipol in disc.  %8s\n", txb) ;
        fprintf(out,"   intpol         %8s\n", txh) ;
        fprintf(out,"   LIBOR dur      %8lf\n", dur) ;
        fprintf(out,"   LIBOR unit     %8s\n", txd) ;
        fprintf(out,"   LIBOR freq     %8s\n", txi) ;
        fprintf(out,"   LIBOR fixing   %8lf\n", Lfix) ;
        fprintf(out,"   BusConv        %8s\n", txj) ;
        fprintf(out,"   Key            %8s\n", txf) ;
        fprintf(out,"   Risk           %8s\n", txk) ;
        fprintf(out,"   Shock          %8.5lf\n", shock) ;

        cap = Read_CAPLETS(in, out, cal, qot, freq, Lfix, &index) ;
        expprem = Read_FL64ARRAY(in, &nirg) ;
        disc = Alloc_PLANARRAY(2, GETMAX(no, nd)) ;

        fprintf(out,"   offer disc. fct. table is...\n") ;
        for (i = 0 ; i < no ; i++)
        {
            fscanf(in,"%ld %lf", &ymd, &disc[0].f64[i]) ;
            disc[0].day[i] = Cldr_YMD2Datestr(ymd) ;
            fprintf(out,"   date[%2d] %8ld  disc[%2d] %10.5lf\n",
                    i, ymd, i, disc[0].f64[i]) ;
        }

        disc[0].filled = disc[0].count = no;

        fprintf(out,"   disc disc. fct. table is...\n") ;
        for (i = 0 ; i < nd ; i++)
        {
            fscanf(in,"%ld %lf", &ymd, &disc[1].f64[i]) ;
            disc[1].day[i] = Cldr_YMD2Datestr(ymd) ;
            fprintf(out,"   date[%2d] %8ld  disc[%2d] %10.5lf\n",
                    i, ymd, i, disc[1].f64[i]) ;
        }
        disc[1].filled = disc[1].count = nd;

        vol  = Alloc_PLANARRAY(1, nv) ;
        volc = Alloc_PLANARRAY(1, nv) ;

        fprintf(out,"   vol. fct. table is...\n") ;
        for (i = 0 ; i < nv ; i++)
        {
            fscanf(in,"%ld %lf", &ymd, &vol[0].f64[i]) ;
            vol[0].day[i] = Cldr_YMD2Datestr(ymd) ;
            fprintf(out,"   date[%2d] %8ld  disc[%2d] %10.5lf\n",
                    i, ymd, i, vol[0].f64[i]) ;
            Cldr_InsertInPlan(&vol[0].day[i], vol[0].f64[i], volc, True) ;
        }

        vol[0].filled = vol[0].count = nv;

        fprintf(out,"   holidays...\n") ;
        for (i = 0 ; i < holis.nholi ; i++)
        {
            fscanf(in,"%ld", &ymd) ;
            holis.holidays[i] = Cldr_YMD2Datestr(ymd) ;
            fprintf(out,"   date[%2d] %8ld\n",
                    i, ymd) ;
        }

        df  = Set_DISCFAC(disc, ipol, iconv, cal, CONTINUOUS, ANNUALLY);
        df1 = Set_DISCFAC(&disc[1], ipol, iconv, cal, CONTINUOUS, ANNUALLY);

        orsk = Set_RISKSET(key, risk, shock, COMPOUND, ANNUALLY, NULL, True);

        vols = Set_VOL_STR(vol, cal, vc, LINEAR_EXTRAPOL);

/* Extra token, i7, read to tell whether test should include
   expected forwfixings and caplengths for test of
   Caplets_Black2P_Array 
   token is 1 if no extra input is added
            2 if expected data is entered
*/

        fscanf(in, "%d", &i7);
        expforwfix = NULL;
        expcaplength = NULL;

        if (i7 == 2)
        {
          expforwfix = Alloc_FL64ARRAY(nirg);
          expcaplength = Alloc_INTIARRAY(nirg);
          for (i = 0; i<nirg; i++)
          {
            fscanf(in,"%lf %ld",&expforwfix[i],&expcaplength[i]);
          }
        }

/*..careful about shocks !!!! */
        CMTv = Set_VOL_STR(vol, cal, vc, LINEAR_EXTRAPOL);

        cmadj = Set_CMCONVADJ(CMADJ_ORIG, &CMTv, NULL, 0.0) ;

        fres = Caplets_Black2P(&analys, &analys, &cap, &df, &df1, &vols,
                               &cmadj, &holis, &orsk, &fres1, &fres2) ;

        prem = Caplets_Black2P_Array(&analys, &analys, &cap, &df, &df1,
                                     &vols, &cmadj, &holis, &forwfix,
                                     &caplength) ;

        diff = Write_RiskDiff(True, True, fres, fres1, fres2, fexp, fexp1, 
                              fexp2, acc, out) ;

        for (i = 0; i < nirg; i++)
        {
            diff = (diff || (fabs(expprem[i] - prem[i]) > acc)) ;
            fprintf(out,
              "%d; premium[%d] is %9.5lf ; expected[%d] is %9.5lf\n",
                    (fabs(expprem[i] - prem[i]) > acc), i, prem[i], i,
                      expprem[i]) ;

        }

/*  output forward fixings and caplengths. If expected results were read
    compare
*/
        if (i7 == 1)
        {
          fprintf(out,"forward fixings and caplengths:\n");
          for (i = 0;i < nirg; i++)
          {
              fprintf(out, "caplet %d: %9.5lf   %9li\n",i,
                            forwfix[i], caplength[i]);
          }
        }
        else if (i7 == 2)
/*  errorhandler */
        {
          fprintf(out, "forward fixings vs. expected\n");
          for (i = 0;i < nirg; i++)
          {
               diff = (diff || (fabs(expforwfix[i] - forwfix[i]) > acc) );
               fprintf(out, "%d; ff[%d] is %9.5lf; expexted ff[%d] is %9.5lf\n",
                            (fabs(expforwfix[i] - forwfix[i]) > acc),
                            i, forwfix[i],   i, expforwfix[i]);
          }
          fprintf(out, "caplengths vs. expected\n");
          for (i = 0; i < nirg; i++)
          {
              diff = (diff || (caplength[i] != expcaplength[i]) );
              fprintf(out, "%d; cl[%d] is %8ld; expected cl[%d] is %8ld\n",
                          (caplength[i] != expcaplength[i]),
                          i, caplength[i], i, expcaplength[i]);
          }
        }
        else
        {
          diff = 1;
          fprintf(out,
            "%d; *.in has bad input for forwfix and caplengths",diff);
        }
        

        fprintf(out,"   %s\n\n", txpl) ;

        Free_PLANARRAY(disc, 2) ;
        Free_PLANARRAY(vol, 1) ;
        Free_PLANARRAY(volc, 1) ;
        Free_IRGARRAY(cap.irg) ;
        Free_FL64ARRAY(prem) ;
        Free_FL64ARRAY(expprem) ;
        Free_DATEARRAY(holis.holidays) ;
        Free_FL64ARRAY(forwfix);
        Free_INTIARRAY(caplength);
        if (expforwfix != NULL) Free_FL64ARRAY(expforwfix);
        if (expcaplength != NULL) Free_INTIARRAY(expcaplength);
    }

    else if (!strcmp("Cap_Black2P()", txa))
    {
        fscanf(in, 
          "%s %lf %lf %lf %lf %ld %ld",
          txpl, &acc, &fexp, &fexp1, &fexp2, &ymd, &ymd1) ;

        analys = Cldr_YMD2Datestr(ymd) ;
        vold   = Cldr_YMD2Datestr(ymd1) ;

        fprintf(out,"   testing %s\n", txa) ;
        fprintf(out,"   %s\n", txpl) ;
        fprintf(out,"   Analysis       %8ld\n", ymd) ;
        fprintf(out,"   VolDate        %8ld\n", ymd1) ;

        capx  = Read_CAP(in, out) ;
        df    = Read_DISCFAC(in, out) ;
        df1   = Read_DISCFAC(in, out) ;
        vols  = Read_VOL_STR(in, out) ;
        cmadj = Read_CMCONVADJ(in, out) ;
        holis = Read_HOLI_STR(in, out) ;
        orsk  = Read_RISKSET(in, out) ;

        fres = Cap_Black2P(&analys, &vold, &capx, &df, &df1, &vols, &cmadj,
                           &holis, &orsk, &fres1, &fres2) ;

        diff = Write_RiskDiff(True, True, fres, fres1, fres2, fexp, fexp1, 
                              fexp2, acc, out) ;

        /* NULL test */
        fres = Cap_Black2P(&analys, &vold, &capx, &df, &df1, &vols, NULL,
                           &holis, NULL, &fres1, &fres2) ;

        Free_PLANARRAY(df.disc, 1) ;
        Free_PLANARRAY(df1.disc, 1) ;
        Free_PLANARRAY(vols.vol, 1) ;
        Free_PLANARRAY(cmadj.volCM.vol, 1) ;
        Free_PLANARRAY(cmadj.volLIBOR.vol, 1) ;
        Free_DATEARRAY(holis.holidays) ;
        Free_CAP(&capx);
        Free_RISKSET(&orsk);
    }

    else if (!strcmp("Cap_Black2Delta()", txa))
    {
        fscanf(in, "%s %lf %ld %ld", txpl, &acc, &ymd, &ymd1) ;

        analys = Cldr_YMD2Datestr(ymd) ;
        vold   = Cldr_YMD2Datestr(ymd1) ;

        fprintf(out,"   testing %s\n", txa) ;
        fprintf(out,"   %s\n", txpl) ;
        fprintf(out,"   Analysis       %8ld\n", ymd) ;
        fprintf(out,"   VolDate        %8ld\n", ymd1) ;

        capx   = Read_CAP(in, out) ;
        df     = Read_DISCFAC(in, out) ;
        df1    = Read_DISCFAC(in, out) ;
        vols   = Read_VOL_STR(in, out) ;
        CMTv   = Read_VOL_STR(in, out) ;
        holis  = Read_HOLI_STR(in, out) ;
        bucket = Read_BUCKETARRAY(in, out, &nbuck) ;

        fscanf(in, "%s", txb) ;
        zero = Str2BOOLE(txb) ;
        fprintf(out,"   DECF        %8s\n", txb) ;

        ds = Disc_DeltaPrep(&df, bucket, nbuck, &holis, False,
                             df.irr, df.freq, False, zero, DF_BOTH) ;

        cmadj = Set_CMCONVADJ(CMADJ_ORIG, &CMTv, &vols, 0.0) ;

        dv = Cap_Black2Delta(&analys, &vold, &capx, &df, &df1, &vols,
                             &cmadj, &holis, &ds) ;
        dvexp = Read_FL64ARRAY(in, &ndvexp) ;
        diff = Write_DeltaDiff(True, True, dv, nbuck, dvexp, ndvexp, acc, 
                               out) ;
        fprintf(out, "\n") ;

        Free_PLANARRAY(df.disc, 1) ;
        Free_PLANARRAY(df1.disc, 1) ;
        Free_PLANARRAY(vols.vol, 1) ;
        Free_PLANARRAY(CMTv.vol, 1) ;
        Free_DATEARRAY(holis.holidays) ;
        Free_CAP(&capx);
        Free_DELTASET(&ds) ;
        Free_BUCKETARRAY(bucket) ;
        Free_FL64ARRAY(dv) ;
        Free_FL64ARRAY(dvexp) ;
    }

    else if (!strcmp("Cap_Black2Impl()", txa))
    {
        fscanf(in, "%s %lf %s %lf %ld %ld %lf",
               txpl, &acc, txb, &fexp, &ymd, &ymd1, &price) ;

        okexp = Str2BOOLE(txb) ;
        analys = Cldr_YMD2Datestr(ymd) ;
        vold   = Cldr_YMD2Datestr(ymd1) ;

        fprintf(out,"\n   testing %s\n", txa) ;
        fprintf(out,"   %s\n", txpl) ;
        fprintf(out,"   Analysis       %8ld\n", ymd) ;
        fprintf(out,"   VolDate        %8ld\n", ymd1) ;
        fprintf(out,"   Match:         %8lf\n", price) ;

        capx  = Read_CAP(in, out) ;
        df    = Read_DISCFAC(in, out) ;
        df1   = Read_DISCFAC(in, out) ;
        vols  = Read_VOL_STR(in, out) ;
        CMTv  = Read_VOL_STR(in, out) ;
        holis = Read_HOLI_STR(in, out) ;
        what  = Read_KEYCONV(in, out, "   What   ") ;
        Init_ITERCTRL(&ictrl) ;

        cmadj = Set_CMCONVADJ(CMADJ_ORIG, &CMTv, &vols, 0.0) ;
        fres = 0.0 ;
        ok = Cap_Black2Impl(&analys, &vold, price, &capx, &df, &df1,
                            &vols, &cmadj, &holis, what, &ictrl, &fres) ;
                              
        diff = Write_SingleDiff(ok, okexp, fres, fexp, acc, out) ;
        fprintf(out,"%d; total is %9.5lf ; expected is %9.5lf\n\n",
                diff, fres, fexp) ;

        /* NULL test */
        ok = Cap_Black2Impl(&analys, &vold, price, &capx, &df, &df1,
                            &vols, NULL, &holis, orsk.key, &ictrl, &fres) ;

        Free_PLANARRAY(df.disc, 1) ;
        Free_PLANARRAY(df1.disc, 1) ;
        Free_PLANARRAY(vols.vol, 1) ;
        Free_PLANARRAY(CMTv.vol, 1) ;
        Free_DATEARRAY(holis.holidays) ;
        Free_CAP(&capx);
    }
    else if (!strcmp("Cap_Black2ATMP()", txa))
    {
        fscanf(in, 
          "%s %lf %lf %lf %ld %ld",
          txpl, &acc, &fexp, &fexp1, &ymd, &ymd1) ;

        analys = Cldr_YMD2Datestr(ymd) ;
        vold   = Cldr_YMD2Datestr(ymd1) ;

        fprintf(out,"   testing %s\n", txa) ;
        fprintf(out,"   %s\n", txpl) ;
        fprintf(out,"   Analysis       %8ld\n", ymd) ;
        fprintf(out,"   VolDate        %8ld\n", ymd1) ;

        atm_vol = Read_FL64(in, out, " ATM vol");
        capx  = Read_CAP(in, out) ;
        df    = Read_DISCFAC(in, out) ;
        df1   = Read_DISCFAC(in, out) ;
        volcal = Read_CALCONV(in, out, " Vol day-count") ;
        holis = Read_HOLI_STR(in, out) ;

        ok = Cap_Black2ATMP(&analys, &vold, atm_vol, &capx, &df, &df1, volcal, 
                              &holis, &fres, &fres1) ;

        diff = Write_RiskDiff(ok, True, fres, fres1, 0.0, fexp, fexp1, 
                              0.0, acc, out) ;

        Free_PLANARRAY(df.disc, 1) ;
        Free_PLANARRAY(df1.disc, 1) ;
        Free_DATEARRAY(holis.holidays) ;
        Free_CAP(&capx);
    }

    else if (!strcmp("Caplets_Black2Delta()", txa))
    {
        fscanf(in, "%ld %d %d %d %s %s %s %s %s %lf %lf %s %s %s %d %s",
               &ymd, &i2, &i3, &i4, txg, txc, txe, txb, txh, &acc,
               &dur, txd, txi, txj, &i6, txm) ;

        no   = (INTI) i2 ;
        nd   = (INTI) i3 ;
        nv   = (INTI) i4 ;
        analys = Cldr_YMD2Datestr(ymd) ;

        cal  = Str2CALCONV(txc) ;
        qot  = Str2QOTCONV(txe) ;
        ipol = Str2DISCIPOL(txb) ;
        iconv= Str2INTPOLCONV(txh) ;
        vc   = Str2VOLCONV(txg) ;
        freq = Str2PMTFREQ(txm) ;

        rt = (Str2PMTFREQ(txi) == NO_FREQUENCY ? MMRATE : PARYIELD) ;
        ical = (Str2PMTFREQ(txi) == NO_FREQUENCY ? cal : EU30E360) ;
        index = Set_RATEINDEX(rt, dur, Str2TERMUNIT(txd), 
                              Str2PMTFREQ(txi), ical, 0.0) ;

        holis.bus   = Str2BUSCONV(txj) ;
        holis.nholi = (INTI) i6 ;
        holis.holidays = Alloc_DATEARRAY(holis.nholi) ;

        fprintf(out,"   testing %s\n", txa) ;
        fprintf(out,"   analysis       %8ld\n", ymd) ;
        fprintf(out,"   volconv        %8s\n", txg) ;
        fprintf(out,"   calendar       %8s\n", txc) ;
        fprintf(out,"   quoting        %8s\n", txe) ;
        fprintf(out,"   ipol in disc.  %8s\n", txb) ;
        fprintf(out,"   intpol         %8s\n", txh) ;
        fprintf(out,"   LIBOR dur      %8lf\n", dur) ;
        fprintf(out,"   LIBOR unit     %8s\n", txd) ;
        fprintf(out,"   LIBOR freq     %8s\n", txi) ;
        fprintf(out,"   BusConv        %8s\n", txj) ;

        cap = Read_CAPLETS(in, out, cal, qot, freq, Lfix, &index) ;

        disc = Alloc_PLANARRAY(2, GETMAX(no, nd)) ;

        fprintf(out,"   offer disc. fct. table is...\n") ;
        for (i = 0 ; i < no ; i++)
        {
            fscanf(in,"%ld %lf", &ymd, &disc[0].f64[i]) ;
            disc[0].day[i] = Cldr_YMD2Datestr(ymd) ;
            fprintf(out,"   date[%2d] %8ld  disc[%2d] %10.5lf\n",
                    i, ymd, i, disc[0].f64[i]) ;
        }
        disc[0].filled = disc[0].count = no;

        fprintf(out,"   disc disc. fct. table is...\n") ;
        for (i = 0 ; i < nd ; i++)
        {
            fscanf(in,"%ld %lf", &ymd, &disc[1].f64[i]) ;
            disc[1].day[i] = Cldr_YMD2Datestr(ymd) ;
            fprintf(out,"   date[%2d] %8ld  disc[%2d] %10.5lf\n",
                    i, ymd, i, disc[1].f64[i]) ;
        }
        disc[1].filled = disc[1].count = nd;

        vol = Alloc_PLANARRAY(1, nv) ;
        volc = Alloc_PLANARRAY(1, nv) ;

        fprintf(out,"   vol. fct. table is...\n") ;
        for (i = 0 ; i < nv ; i++)
        {
            fscanf(in,"%ld %lf", &ymd, &vol[0].f64[i]) ;
            vol[0].day[i] = Cldr_YMD2Datestr(ymd) ;
            fprintf(out,"   date[%2d] %8ld  disc[%2d] %10.5lf\n",
                    i, ymd, i, vol[0].f64[i]) ;
            Cldr_InsertInPlan(&vol[0].day[i], vol[0].f64[i], volc, True) ;
        }
        vol[0].filled = vol[0].count = nv;

        fprintf(out,"   holidays...\n") ;
        for (i = 0 ; i < holis.nholi ; i++)
        {
            fscanf(in,"%ld", &ymd) ;
            holis.holidays[i] = Cldr_YMD2Datestr(ymd) ;
            fprintf(out,"   date[%2d] %8ld\n",
                    i, ymd) ;
        }

        bucket = Read_BUCKETARRAY(in, out, &nbuck) ;

        df  = Set_DISCFAC(disc, ipol, iconv, cal, CONTINUOUS, ANNUALLY);
        df1 = Set_DISCFAC(&disc[1], ipol, iconv, cal, CONTINUOUS, ANNUALLY);

        vols = Set_VOL_STR(vol, cal, vc, LINEAR_EXTRAPOL);
        CMTv = Set_VOL_STR(vol, cal, vc, LINEAR_EXTRAPOL);

        ds = Disc_DeltaPrep(&df, bucket, nbuck, &holis, False,
                             df.irr, df.freq, False, False, DF_BOTH) ;

        cmadj = Set_CMCONVADJ(CMADJ_ORIG, &CMTv, NULL, 0.0) ;

        dv = Caplets_Black2Delta(&analys, &analys, &cap, &df1, &df, &vols,
                                 &cmadj, &holis, &ds) ;
        dvexp = Read_FL64ARRAY(in, &ndvexp) ;
        diff = Write_DeltaDiff(True, True, dv, nbuck, dvexp, ndvexp, acc, 
                               out) ;

        fscanf(in,"%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_PLANARRAY(disc, 2) ;
        Free_PLANARRAY(vol, 1) ;
        Free_PLANARRAY(volc, 1) ;
        Free_IRGARRAY(cap.irg) ;
        Free_DATEARRAY(holis.holidays) ;
        Free_DELTASET(&ds) ;
        Free_BUCKETARRAY(bucket) ;
        Free_FL64ARRAY(dv) ;
        Free_FL64ARRAY(dvexp) ;
    }

    else if (!strcmp("Caplets_Black2Impl()", txa))
    {
        fscanf(in, 
          "%lf %lf %d %d %d %s %s %s %s %s %s %lf %lf %s %s %s %d %s %s",
               &fexp, &price, &i2, &i3, &i4, txg, txc, txe,
               txb, txh, txf, &acc, &dur, txd, txi, txj, &i6, txm, txpl);
        no   = (INTI) i2 ;
        nd   = (INTI) i3 ;
        nv   = (INTI) i4 ;

        cal  = Str2CALCONV(txc) ;
        qot  = Str2QOTCONV(txe) ;
        ipol = Str2DISCIPOL(txb) ;
        iconv = Str2INTPOLCONV(txh) ; /*  missing *************/
        what = Str2KEYCONV(txf) ;
        vc   = Str2VOLCONV(txg) ;
        freq = Str2PMTFREQ(txm) ;

        rt = (Str2PMTFREQ(txi) == NO_FREQUENCY ? MMRATE : PARYIELD) ;
        ical = (Str2PMTFREQ(txi) == NO_FREQUENCY ? cal : EU30E360) ;
        index = Set_RATEINDEX(rt, dur, Str2TERMUNIT(txd), 
                              Str2PMTFREQ(txi), ical, 0.0) ;

        holis.bus   = Str2BUSCONV(txj) ;
        holis.nholi = (INTI) i6 ;
        holis.holidays = Alloc_DATEARRAY(holis.nholi) ;

        fprintf(out,"   testing %s\n", txa) ;
        fprintf(out,"   price          %8lf\n", price) ;
        fprintf(out,"   volconv        %8s\n", txg) ;
        fprintf(out,"   calendar       %8s\n", txc) ;
        fprintf(out,"   quoting        %8s\n", txe) ;
        fprintf(out,"   ipol in disc.  %8s\n", txb) ;
        fprintf(out,"   intpol         %8s\n", txh) ;
        fprintf(out,"   key            %8s\n", txf) ;
        fprintf(out,"   LIBOR dur      %8lf\n", dur) ;
        fprintf(out,"   LIBOR unit     %8s\n", txd) ;
        fprintf(out,"   LIBOR freq     %8s\n", txi) ;
        fprintf(out,"   BusConv        %8s\n", txj) ;

        cap = Read_CAPLETS(in, out, cal, qot, freq, Lfix, &index) ;

        disc = Alloc_PLANARRAY(2, GETMAX(no, nd)) ;

        fprintf(out,"   offer disc. fct. table is...\n") ;
        for (i = 0 ; i < no ; i++)
        {
            fscanf(in,"%ld %lf", &ymd, &disc[0].f64[i]) ;
            disc[0].day[i] = Cldr_YMD2Datestr(ymd) ;
            fprintf(out,"   date[%2d] %8ld  disc[%2d] %10.5lf\n",
                    i, ymd, i, disc[0].f64[i]) ;
        }
        disc[0].filled = disc[0].count = no;

        fprintf(out,"   disc disc. fct. table is...\n") ;
        for (i = 0 ; i < nd ; i++)
        {
            fscanf(in,"%ld %lf", &ymd, &disc[1].f64[i]) ;
            disc[1].day[i] = Cldr_YMD2Datestr(ymd) ;
            fprintf(out,"   date[%2d] %8ld  disc[%2d] %10.5lf\n",
                    i, ymd, i, disc[1].f64[i]) ;
        }
        disc[1].filled = disc[1].count = nd;

        vol = Alloc_PLANARRAY(1, nv) ;
        volc = Alloc_PLANARRAY(1, nv) ;

        fprintf(out,"   vol. fct. table is...\n") ;
        for (i = 0 ; i < nv ; i++)
        {
            fscanf(in,"%ld %lf", &ymd, &vol[0].f64[i]) ;
            vol[0].day[i] = Cldr_YMD2Datestr(ymd) ;
            fprintf(out,"   date[%2d] %8ld  disc[%2d] %10.5lf\n",
                    i, ymd, i, vol[0].f64[i]) ;
            Cldr_InsertInPlan(&vol[0].day[i], vol[0].f64[i], volc, True) ;
        }
        vol[0].filled = vol[0].count = nv;

        fprintf(out,"   holidays...\n") ;
        for (i = 0 ; i < holis.nholi ; i++)
        {
            fscanf(in,"%ld", &ymd) ;
            holis.holidays[i] = Cldr_YMD2Datestr(ymd) ;
            fprintf(out,"   date[%2d] %8ld\n",
                    i, ymd) ;
        }

        df  = Set_DISCFAC(disc, ipol, iconv, cal, CONTINUOUS, ANNUALLY);
        df1 = Set_DISCFAC(&disc[1], ipol, iconv, cal, CONTINUOUS, ANNUALLY);

        vols = Set_VOL_STR(vol, cal, vc, LINEAR_EXTRAPOL);
        CMTv = Set_VOL_STR(vol, cal, vc, LINEAR_EXTRAPOL);

        Init_ITERCTRL(&ictrl) ;
        fres = 0.0 ;
        analys = df1.disc->day[0] ;

        cmadj = Set_CMCONVADJ(CMADJ_ORIG, &CMTv, NULL, 0.0) ;
        fres = 0.0 ;
        ok = Caplets_Black2Impl(&analys, &analys, price, &cap, &df,
                                &df1, &vols, &cmadj,
                                &holis, what, &ictrl, &fres) ;

        diff = Write_SingleDiff(ok, True, fres, fexp, acc, out) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_PLANARRAY(disc, 2) ;
        Free_PLANARRAY(vol, 1) ;
        Free_PLANARRAY(volc, 1) ;
        Free_IRGARRAY(cap.irg) ;
        Free_DATEARRAY(holis.holidays) ;
    }

    else if (!strcmp("Caplets_Black2Intr()", txa))
    {
        fscanf(in, "%d %d %s %s %s %s %lf %lf %s %s %s %d %s %s",
               &i2, &i3, txc, txe, txb, txh, &acc,
               &dur, txd, txi, txj, &i6, txm, txpl);
        no   = (INTI) i2 ;
        nd   = (INTI) i3 ;

        cal  = Str2CALCONV(txc) ;
        qot  = Str2QOTCONV(txe) ;
        ipol = Str2DISCIPOL(txb) ;
        iconv= Str2INTPOLCONV(txh) ;
        freq = Str2PMTFREQ(txm) ;

        rt = (Str2PMTFREQ(txi) == NO_FREQUENCY ? MMRATE : PARYIELD) ;
        ical = (Str2PMTFREQ(txi) == NO_FREQUENCY ? cal : EU30E360) ;
        index = Set_RATEINDEX(rt, dur, Str2TERMUNIT(txd), 
                              Str2PMTFREQ(txi), ical, 0.0) ;

        holis.bus   = Str2BUSCONV(txj) ;
        holis.nholi = (INTI) i6 ;
        holis.holidays = Alloc_DATEARRAY(holis.nholi) ;

        fprintf(out,"   testing %s\n", txa) ;
        fprintf(out,"   calendar       %8s\n", txc) ;
        fprintf(out,"   quoting        %8s\n", txe) ;
        fprintf(out,"   ipol in disc.  %8s\n", txb) ;
        fprintf(out,"   intpol         %8s\n", txh) ;
        fprintf(out,"   LIBOR dur      %8lf\n", dur) ;
        fprintf(out,"   LIBOR unit     %8s\n", txd) ;
        fprintf(out,"   LIBOR freq     %8s\n", txi) ;
        fprintf(out,"   BusConv        %8s\n", txj) ;

        cap = Read_CAPLETS(in, out, cal, qot, freq, Lfix, &index) ;
        expprem = Read_FL64ARRAY(in, &nirg) ;

        disc = Alloc_PLANARRAY(2, GETMAX(no, nd)) ;

        fprintf(out,"   offer disc. fct. table is...\n") ;
        for (i = 0 ; i < no ; i++)
        {
            fscanf(in,"%ld %lf", &ymd, &disc[0].f64[i]) ;
            disc[0].day[i] = Cldr_YMD2Datestr(ymd) ;
            fprintf(out,"   date[%2d] %8ld  disc[%2d] %10.5lf\n",
                    i, ymd, i, disc[0].f64[i]) ;
        }
        disc[0].filled = disc[0].count = no;

        fprintf(out,"   disc disc. fct. table is...\n") ;
        for (i = 0 ; i < nd ; i++)
        {
            fscanf(in,"%ld %lf", &ymd, &disc[1].f64[i]) ;
            disc[1].day[i] = Cldr_YMD2Datestr(ymd) ;
            fprintf(out,"   date[%2d] %8ld  disc[%2d] %10.5lf\n",
                    i, ymd, i, disc[1].f64[i]) ;
        }
        disc[1].filled = disc[1].count = nd;

        fprintf(out,"   holidays...\n") ;
        for (i = 0 ; i < holis.nholi ; i++)
        {
            fscanf(in,"%ld", &ymd) ;
            holis.holidays[i] = Cldr_YMD2Datestr(ymd) ;
            fprintf(out,"   date[%2d] %8ld\n",
                    i, ymd) ;
        }

        df  = Set_DISCFAC(disc, ipol, iconv, cal, CONTINUOUS,
          ANNUALLY);
        df1 = Set_DISCFAC(&disc[1], ipol, iconv, cal, CONTINUOUS,
          ANNUALLY);

        prem = Caplets_Black2Intr(&df1.disc->day[0], &cap, &df, &df1,
          &holis) ;

        for (diff = i = 0; i < nirg; i++)
        {
            diff = (diff || (fabs(expprem[i] - prem[i]) > acc)) ;
            fprintf(out,
              "%d; premium[%d] is %9.5lf ; expected[%d] is %9.5lf\n",
              
                    (fabs(expprem[i] - prem[i]) > acc), i, prem[i], i,
                      expprem[i]) ;

        }
        fprintf(out,"   %s\n\n", txpl) ;

        Free_PLANARRAY(disc, 2) ;
        Free_IRGARRAY(cap.irg) ;
        Free_FL64ARRAY(prem) ;
        Free_FL64ARRAY(expprem) ;
        Free_DATEARRAY(holis.holidays) ;
    }

    else if (!strcmp("Caplets_GenrIRGARRAY()", txa))
    {
        fscanf(in, "%d %ld %ld %s %s %lf %lf %s %s %s %d %s",
               &i1, &ymd, &ymd2, txb, txe, &strike, &size, txd, txc,
               txf, &i2, txpl) ;
        nirg = (INTI) i1 ;
        nh   = (INTI) i2 ;

        start = Cldr_YMD2Datestr(ymd) ;
        end   = Cldr_YMD2Datestr(ymd2) ;

        freq = Str2PMTFREQ(txb) ;
        type = Str2OPTTYPE(txe) ;
        eom  = Str2EOMCONV(txd) ;
        bus  = Str2BUSCONV(txf) ;
        per  = Str2SEQCONV(txc) ;

        fprintf(out,"   testing %s\n", txa) ;
        fprintf(out,"   start          %8ld\n", ymd) ;
        fprintf(out,"   end            %8ld\n", ymd2) ;
        fprintf(out,"   pmtfreq        %8s\n", txb) ;
        fprintf(out,"   opttype        %8s\n", txe) ;
        fprintf(out,"   eom            %8s\n", txd) ;
        fprintf(out,"   perconv        %8s\n", txc) ;
        fprintf(out,"   busconv        %8s\n", txf) ;

        expirg = Alloc_IRGARRAY(nirg) ;
        holi   = Alloc_DATEARRAY(nh) ;

        for (i = 0 ; i < nirg ; i++)
        {
            fscanf(in,"%s %lf %ld %ld %lf",
                   txb, &expirg[i].strike,
                   &ymd, &ymd2, &expirg[i].size) ;
            expirg[i].type  = Str2OPTTYPE(txb) ;
            expirg[i].fix_start = Cldr_YMD2Datestr(ymd) ;
            expirg[i].fix_end   = Cldr_YMD2Datestr(ymd2) ;
        }

        fprintf(out,"   Holidays...\n") ;
        for (i = 0 ; i < nh ; i++)
        {
            fscanf(in, "%ld", &ymd) ;
            holi[i] = Cldr_YMD2Datestr(ymd) ;
            fprintf(out, "   %ld\n", ymd) ;
        }

        holis.nholi    = nh ;
        holis.holidays = holi ;
        holis.bus      = bus ;
        pseq = Set_PAYDAYSEQ(Cflw_MonthsBetweenPayments(freq), 
                                  MONTHS, NOODD, NOODD, per,
                                  eom) ;

        pday = Set_PAYDAYDEF(True, &start, &dzero, &end,
                                  False, &pseq, 0, NULL) ;

        nd = Cflw_PaydaysCount(&pday, &holis) ;

        if (nd - 1 != nirg)
        {
            diff = 1 ;
            fprintf(out, 
              "1; Wrong number of irg's you expected %d we found %d\n",
                    nirg, nd) ;
        }

        else
        {
            irg = Caplets_GenrIRGARRAY(&pday, type, strike,
                                       size, &holis, &nd) ;

            for (diff = i = 0; i < nirg; i++)
            {
                dif1 = Cldr_Datestr2YMD(&expirg[i].fix_start) !=
                  Cldr_Datestr2YMD(&irg[i].fix_start) ||
                       Cldr_Datestr2YMD(&expirg[i].fix_end) !=
                         Cldr_Datestr2YMD(&irg[i].fix_end) ;
                diff = diff || dif1 ;
                fprintf(out,
                  "%d; expstart %8ld start %8ld expend %8ld end %8ld\n",
                        dif1, Cldr_Datestr2YMD(&expirg[i].fix_start),
                              Cldr_Datestr2YMD(&irg[i].fix_start),
                              Cldr_Datestr2YMD(&expirg[i].fix_end),
                              Cldr_Datestr2YMD(&irg[i].fix_end)) ;
            }

            Free_IRGARRAY(irg) ;
        }
        fprintf(out,"   %s\n\n", txpl) ;

        Free_IRGARRAY(expirg) ;
        Free_DATEARRAY(holi) ;
    }

    else if (!strcmp("Swaption_Black2P()", txa))
    {
        fscanf(in, "%s %lf %lf %lf %ld %ld",
               txb, &fexp, &fexp1, &fexp2, &ymd2, &ymd5) ;

        fprintf(out,"   testing %s\n", txa) ;

        okexp = Str2BOOLE(txb) ;
        analys = Cldr_YMD2Datestr(ymd2) ;
        vold   = Cldr_YMD2Datestr(ymd5) ;
        fprintf(out,"   Analysdate     %8ld\n", ymd2) ;
        fprintf(out,"   Vol.Date       %8ld\n", ymd5) ;

        fscanf(in, "%lf", &vola) ;
        fprintf(out,"   vol            %8lf\n", vola) ;

        ncsw  = Read_SWAPTION(in, out) ;
        df    = Read_DISCFAC(in, out) ;
        df1   = Read_DISCFAC(in, out) ;
        CMTv  = Read_VOL_STR(in, out) ;
        holis = Read_HOLI_STR(in, out) ;
        b76t  = Read_B76SWTM(in, out) ;
        orsk  = Read_RISKSET(in, out) ;

        fscanf(in, "%lf", &acc) ;
        fprintf(out,"   ACC            %8lf\n", acc) ;
        fscanf(in, "%s", txpl) ;

        cmadj = Set_CMCONVADJ(CMADJ_ORIG, &CMTv, NULL, 0.0) ;

        ok = Swaption_Black2P(&analys, &vold, vola, &ncsw, &df, &df1, &cmadj, 
                              &holis, &b76t, &orsk, &fres, &fres1, &fres2) ;
        diff = Write_RiskDiff(ok, okexp, fres, fres1, fres2, fexp, fexp1, 
                              fexp2, acc, out) ;

        /* NULL test */
        ok = Swaption_Black2P(&analys, &vold, vola, &ncsw, &df, &df1, NULL, 
                              &holis, NULL, NULL, &fres, &fres1, &fres2) ;

        fprintf(out,"   %s\n\n", txpl) ;

        Free_PLANARRAY(df.disc, 1) ;
        Free_PLANARRAY(df1.disc, 1) ;
        Free_PLANARRAY(CMTv.vol, 1) ;
        Free_DATEARRAY(holis.holidays) ;
        Free_SWAPTION(&ncsw);
        Free_RISKSET(&orsk);
    }

    else if (!strcmp("Swaption_Black2Vol()", txa))
    {
        fscanf(in, "%lf %ld", &fexp, &ymd2) ;
        analys = Cldr_YMD2Datestr(ymd2) ;
        fprintf(out,"?; testing %s\n", txa) ;
        fprintf(out,"   Analysdate     %8ld\n", ymd2) ;

        ncsw = Read_SWAPTION(in, out) ;

        fscanf(in, "%s %s %s %lf", txf, txg, txh, &acc) ;
        fscanf(in, "%s", txpl) ;

        bus  = Str2BUSCONV(txf) ;
        ipol = Str2DISCIPOL(txg) ;
        iconv= Str2INTPOLCONV(txh) ;

        fprintf(out,"   Bus            %8s\n", txf) ;
        fprintf(out,"   Ipol in disc.  %8s\n", txg) ;
        fprintf(out,"   Intpol         %8s\n", txh) ;
        fprintf(out,"   Acc            %8lf\n", acc) ;

        swvol = Read_SWPTVOL(in) ;

        fprintf(out,"   DiscFct. Table is...\n") ;
        disc = Read_PLANARRAY(in) ;
        Write_PLANARRAY(out, disc) ;

        fscanf(in, "%d", &i2) ;
        nh   = (INTI) i2 ;
        holi = Alloc_DATEARRAY(nh) ;
        fprintf(out,"   holiday list...\n") ;
        for (i = 0 ; i < nh ; i++)
        {
            fscanf(in,"%ld", &ymd) ;
            holi[i] = Cldr_YMD2Datestr(ymd) ;
            fprintf(out,"   %8ld\n", ymd) ;
        }

        holis = Set_HOLI_STR(bus, nh, holi) ;
        df = Set_DISCFAC(disc, ipol, iconv, ncsw.cal, CONTINUOUS,
                              ANNUALLY);

        fres = Swaption_Black2Vol(&analys, &swvol, &ncsw, &df, &holis) ;

        diff = fabs(fres - fexp) > acc ;

        fprintf(out,"%d; Vol is %9.5lf ; expected is %9.5lf\n",
                fabs(fres - fexp) > acc, fres, fexp) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_PLANARRAY(disc, 1) ;
        Free_DATEARRAY(holi) ;
        Free_INTIARRAY(swvol.opt_mnth) ;
        Free_INTIARRAY(swvol.swp_mnth) ;
        Free_FL64MATRIX(swvol.vol) ;
        Free_SWAPTION(&ncsw);
    }

    else if (!strcmp("Swaption_Black2Delta()", txa))
    {
        fscanf(in, "%s %ld", txb, &ymd2) ;
        okexp = Str2BOOLE(txb) ;
        analys = Cldr_YMD2Datestr(ymd2) ;
        fprintf(out,"   testing %s\n", txa) ;
        fprintf(out,"   Analysdate     %8ld\n", ymd2) ;

        fscanf(in, "%lf", &vola) ;
        fprintf(out,"   vol            %8lf\n", vola) ;

        ncsw   = Read_SWAPTION(in, out) ;
        df     = Read_DISCFAC(in, out) ;
        df1    = Read_DISCFAC(in, out) ;
        CMTv   = Read_VOL_STR(in, out) ;
        holis  = Read_HOLI_STR(in, out) ;
        b76t   = Read_B76SWTM(in, out) ;
        bucket = Read_BUCKETARRAY(in, out, &nbuck) ;

        fscanf(in, "%s", txb) ;
        zero = Str2BOOLE(txb) ;
        fprintf(out,"   DECF        %8s\n", txb) ;

        fscanf(in, "%lf", &acc) ;
        fprintf(out,"   ACC            %8lf\n", acc) ;

        ds = Disc_DeltaPrep(&df, bucket, nbuck, &holis, False,
                             df.irr, df.freq, False, zero, DF_BOTH) ;
        cmadj = Set_CMCONVADJ(CMADJ_ORIG, &CMTv, NULL, 0.0) ;

        dv = Swaption_Black2Delta(&analys, &analys, vola, &ncsw, &df, &df1,
                                  &cmadj, &holis, &b76t, &ds, &ok) ;

        dvexp = Read_FL64ARRAY(in, &ndvexp) ;
        diff = Write_DeltaDiff(ok, okexp, dv, nbuck, dvexp, ndvexp, acc, 
                               out) ;

        fscanf(in,"%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_PLANARRAY(df.disc, 1) ;
        Free_PLANARRAY(df1.disc, 1) ;
        Free_PLANARRAY(CMTv.vol, 1) ;
        Free_DATEARRAY(holis.holidays) ;
        Free_DELTASET(&ds) ;
        Free_BUCKETARRAY(bucket) ;
        Free_FL64ARRAY(dv) ;
        Free_FL64ARRAY(dvexp) ;
        Free_SWAPTION(&ncsw);
    }

    else if (!strcmp("Swaption_Black2ATMP()", txa))
    {
        fprintf(out,"   testing %s\n", txa) ;
  
        acc = Read_FL64(in, out,"Tolerance");

        fexp = Read_FL64(in, out, "Exp. strike");
        fexp1 = Read_FL64(in, out, "Exp. price");

        analys = Read_DATESTR(in, out, "Analys");

        vold = Read_DATESTR(in, out, "Vol Date");
        
        atm_vol = Read_FL64(in, out, "ATM vol");

        ncsw = Read_SWAPTION(in, out);

        df = Read_DISCFAC(in, out);

        df1 = Read_DISCFAC(in, out);

        b76t = Read_B76SWTM(in, out);

        holis = Read_HOLI_STR(in, out);

        IOUtil_ParseLine(in, out);

        ok = Swaption_Black2ATMP(&analys, &vold, atm_vol, &ncsw,
                      &df, &df1, &b76t, &holis, &fres, &fres1);

        diff = Write_RiskDiff(ok, True, fres, fres1, 0.0, fexp, fexp1, 
                              0.0, acc, out) ;

        Free_PLANARRAY(df.disc, 1) ;
        Free_PLANARRAY(df1.disc, 1) ;
        Free_DATEARRAY(holis.holidays) ;
    }

    else if (!strcmp("Swaption_Black2Impl()", txa))
    {
        fscanf(in, "%s %lf %ld %ld %lf",
               txb, &fexp, &ymd2, &ymd5, &price) ;

        fprintf(out,"   testing %s\n", txa) ;
        okexp = Str2BOOLE(txb) ;
        analys = Cldr_YMD2Datestr(ymd2) ;
        vold   = Cldr_YMD2Datestr(ymd5) ;
        fprintf(out,"   Analysdate     %8ld\n", ymd2) ;
        fprintf(out,"   Vol.Date       %8ld\n", ymd5) ;
        fprintf(out,"   PV             %8lf\n", price) ;

        fscanf(in, "%lf", &vola) ;
        fprintf(out,"   vol            %8lf\n", vola) ;

        ncsw  = Read_SWAPTION(in, out) ;
        df    = Read_DISCFAC(in, out) ;
        df1   = Read_DISCFAC(in, out) ;
        CMTv  = Read_VOL_STR(in, out) ;
        holis = Read_HOLI_STR(in, out) ;
        b76t  = Read_B76SWTM(in, out) ;

        fscanf(in, " %s %lf", txc, &acc) ;
        wrt  = Str2KEYCONV(txc) ;
        fprintf(out,"   wrt            %8s\n", txc) ;
        fprintf(out,"   ACC            %8lf\n", acc) ;
        fscanf(in, "%s", txpl) ;

        cmadj = Set_CMCONVADJ(CMADJ_ORIG, &CMTv, NULL, 0.0) ;
        Init_ITERCTRL(&ictrl) ;
        fres = 0.0 ;
        ok = Swaption_Black2Impl(&analys, &vold, price, vola,
                                 &ncsw, &df, &df1, &cmadj, &holis, &b76t,
                                 wrt, &ictrl, &fres) ;
        diff = Write_SingleDiff(ok, okexp, fres, fexp, acc, out) ;
        fprintf(out,"   %s\n\n", txpl) ;

        /* NULL test */
        ok = Swaption_Black2Impl(&analys, &vold, price, vola,
                                 &ncsw, &df, &df1, NULL, &holis, NULL,
                                 wrt, &ictrl, &fres) ;

        Free_PLANARRAY(df.disc, 1) ;
        Free_PLANARRAY(df1.disc, 1) ;
        Free_DATEARRAY(holis.holidays) ;
        Free_PLANARRAY(CMTv.vol, 1) ;
        Free_SWAPTION(&ncsw);
    }

    else if (!strcmp("XtndSwap_Black2P()", txa))
    {
        fscanf(in, "%lf %ld %d %ld %ld %lf %ld %ld %s %s %ld %lf",
               &fexp, &ymd2, &i1, &ymd5, &ymd1, &swaprate, &ymd3, &ymd4,
               txk, txd, &ymd, &vola) ;

        fscanf(in, "%s %s %s %d %s %s %lf",
               txb, txe, txf, &i3, txg, txh, &acc) ;

        fscanf(in, "%s", txpl) ;

        analys = Cldr_YMD2Datestr(ymd2) ;
        start  = Cldr_YMD2Datestr(ymd1) ;
        end    = Cldr_YMD2Datestr(ymd3) ;
        matur  = Cldr_YMD2Datestr(ymd4) ;
        eff    = Cldr_YMD2Datestr(ymd5) ;

        nd    = (INTI) i1 ;
        nh    = (INTI) i3 ;
        freq = Str2PMTFREQ(txk) ;
        type = Str2OPTTYPE(txd) ;
        maturity = Cldr_YMD2Datestr((YYYYMMDD) ymd) ;
        cal  = Str2CALCONV(txb) ;
        eom  = Str2EOMCONV(txe) ;
        bus  = Str2BUSCONV(txf) ;
        ipol = Str2DISCIPOL(txg) ;
        iconv= Str2INTPOLCONV(txh) ;

        fprintf(out,"   testing %s\n", txa) ;
        fprintf(out,"   Analysdate     %8ld\n", ymd2) ;
        fprintf(out,"   swaprate       %8lf\n", swaprate) ;
        fprintf(out,"   Eff            %8ld\n", ymd5) ;
        fprintf(out,"   First          %8ld\n", ymd1) ;
        fprintf(out,"   Last           %8ld\n", ymd3) ;
        fprintf(out,"   freq           %8s\n", txk) ;
        fprintf(out,"   XtndMatur      %8ld\n", ymd4) ;
        fprintf(out,"   Type           %8s\n", txd) ;
        fprintf(out,"   maturity       %8ld\n", ymd) ;
        fprintf(out,"   vol            %8lf\n", vola) ;
        fprintf(out,"   calendar       %8s\n", txb) ;
        fprintf(out,"   eom            %8s\n", txe) ;
        fprintf(out,"   bus            %8s\n", txf) ;
        fprintf(out,"   ipol in disc.  %8s\n", txg) ;
        fprintf(out,"   intpol         %8s\n", txh) ;

        disc = Alloc_PLANARRAY(1, nd) ;
        holi = Alloc_DATEARRAY(nh) ;

        fprintf(out,"   disc. fct. table is...\n") ;
        for (i = 0 ; i < nd ; i++)
        {
            fscanf(in,"%ld %lf", &ymd, &disc[0].f64[i]) ;
            disc[0].day[i] = Cldr_YMD2Datestr(ymd) ;
            fprintf(out,"   date[%2d] %8ld  disc[%2d] %10.5lf\n",
                    i, ymd, i, disc[0].f64[i]) ;
        }
        disc[0].filled = disc[0].count = nd;

        fprintf(out,"   holiday list...\n") ;

        for (i = 0 ; i < nh ; i++)
        {
            fscanf(in,"%ld", &ymd) ;
            holi[i] = Cldr_YMD2Datestr(ymd) ;
            fprintf(out,"   %8ld\n", ymd) ;
        }

        holis = Set_HOLI_STR(bus, nh, holi) ;

        df  = Set_DISCFAC(disc, ipol, iconv, cal, CONTINUOUS,
                               ANNUALLY) ;
        df1 = Set_DISCFAC(&dummy, ipol, iconv, cal, CONTINUOUS,
                               ANNUALLY) ;

        pseq = Set_PAYDAYSEQ(Cflw_MonthsBetweenPayments(freq), 
                             MONTHS, NOODD, NOODD, ANCHOR, eom) ;

        pday = Set_PAYDAYDEF(True, &start, &dzero, &end,
                             False, &pseq, 0, NULL) ;

        fix = Set_FIXRATE(swaprate, cal, &eff, &dzero, 0.0,
                          ODDCOUP, ODDCOUP, False, False,
                          NULL, True, NULL, NODCOMP) ;

        ncsw.type     = type ;
        ncsw.maturity = maturity ;
        ncsw.cal      = cal ;
        ncsw.fix      = fix ;
        ncsw.pfix     = pday ;
        ncsw.vanilla  = True ;

        cmadj = Set_CMCONVADJ(CMADJ_ORIG, NULL, NULL, 0.0) ;
        ok = XtndSwap_Black2P(&analys, &analys, vola, &matur,
                              &ncsw, &df, &df1, &cmadj, &holis, &fres) ;
        if (ok == False)
        {
            diff = 1 ;
            fprintf(out,"1; Cannot find XtndSwap premium\n") ;
        }
        else
        {
            diff = fabs(fres - fexp) > acc ;
            fprintf(out,"%d; premium is %9.5lf ; expected is %9.5lf\n",
                    fabs(fres - fexp) > acc, fres, fexp) ;
        }

        fprintf(out,"   %s\n\n", txpl) ;

        Free_PLANARRAY(disc, 1) ;
        Free_DATEARRAY(holi) ;
    }

    else if (!strcmp("Swaption_VOLBOX2Vol()", txa))
    {
        fscanf(in, "%lf %lf %ld", &fexp, &acc, &ymd1) ;

        vold   = Cldr_YMD2Datestr(ymd1) ;

        fprintf(out,"   testing %s\n", txa) ;
        fprintf(out,"   Vol.Date       %8ld\n", ymd1) ;
        fprintf(out,"   Acc.           %8lf\n", acc) ;

        vb    = Read_VOLBOX(in, out) ;
        ncsw  = Read_SWAPTION(in, out) ;
        holis = Read_HOLI_STR(in, out) ;

        fres = Swaption_VOLBOX2Vol(&vold, vb, &ncsw, &holis) ;

        diff = fabs(fres - fexp) > acc ;
        fprintf(out,"%d; P is %9.5lf ; expected is %9.5lf\n",
                fabs(fres - fexp) > acc, fres, fexp) ;

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_SWAPTION(&ncsw);
        Free_VOLBOX(vb) ;
        Free_DATEARRAY(holis.holidays) ;
    }

    else if (!strcmp("Cap_VOLBOX2Vol()", txa))
    {
        fscanf(in, "%lf %ld", &acc, &ymd1) ;

        vold   = Cldr_YMD2Datestr(ymd1) ;

        fprintf(out,"   testing %s\n", txa) ;
        fprintf(out,"   Vol.Date       %8ld\n", ymd1) ;
        fprintf(out,"   Acc.           %8lf\n", acc) ;

        vb    = Read_VOLBOX(in, out) ;
        capx  = Read_CAP(in, out) ;
        holis = Read_HOLI_STR(in, out) ;
        fscanf(in, "%d", &i1) ;

        vols = Cap_VOLBOX2Vol(&vold, vb, &capx, &holis, False) ;
        diff = 0 ;
        if (i1 != vols.vol->filled)
            diff = 1 ;

        for (i = 0; i < (INTI) i1 ; i++)
        {
            fscanf(in, "%ld %lf", &ymd, &vola) ;
            if (i < vols.vol->filled)
            {
                dif1 = fabs(vola - vols.vol->f64[i]) > acc ||
                       ymd != Cldr_Datestr2YMD(&vols.vol->day[i]) ;
                diff = diff || dif1 ;
                fprintf(out,"%d; Exp: %8ld %9.5lf Res: %8ld %9.5lf\n",
                        dif1, ymd, vola, 
                        Cldr_Datestr2YMD(&vols.vol->day[i]),
                        vols.vol->f64[i]) ;
            }
        }

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_VOLBOX(vb) ;
        Free_DATEARRAY(holis.holidays) ;
        Free_CAP(&capx) ;
        Free_PLANARRAY(vols.vol, 1) ;
    }


    return diff ;
}


INTI optirftest(char* txa, FILE* in, FILE* out)
{
    DATESTR  today, vold;
    FRA_STR  irf;
    OPTFUT   opt;
    DISCFAC  df;
    FL64     vol, irfp;
    HOLI_STR holi;
    RISKSET  risk;
    FL64     fres, fres1, fres2, acc;
    INTI     diff;

    diff = -1;

    if (!strcmp(txa, "OptIRF_Black2DFp()"))
    {
        fprintf(out, "%s\n", txa);

        today = Read_DATESTR(in, out, "  Analys ");
        vold = Read_DATESTR(in, out, "  Vol date ");

        irf   = Read_FRA_STR(in, out) ;
        opt   = Read_OPTFUT(in, out) ;
        df    = Read_DISCFAC(in, out) ;
        vol = Read_FL64(in, out, "  Volatility ");
        holi  = Read_HOLI_STR(in, out) ;
        risk = Read_RISKSET(in, out) ;

        fres = OptIRF_Black2DFp(&today, &vold, &irf, &opt, &df,
                                vol, &holi, &risk, &fres1, &fres2);
  
        acc = Read_FL64(in, out, "");

        IOUtil_ParseLine(in, out) ;

        diff = Compare_Risk(in, out, True, fres, 
                   fres1, fres2, acc);

        Free_OPTFUT(&opt) ;
        Free_DISCFAC(&df) ;
        Free_HOLI_STR(&holi) ;
        Free_RISKSET(&risk) ;
    }

    if (!strcmp(txa, "OptIRF_Black2P()"))
    {
        fprintf(out, "%s\n", txa);

        today = Read_DATESTR(in, out, "  Analys ");
        vold = Read_DATESTR(in, out, "  Vol date ");

        irfp  = Read_FL64(in, out, "  Futures price ");
        irf   = Read_FRA_STR(in, out) ;
        opt   = Read_OPTFUT(in, out) ;
        df    = Read_DISCFAC(in, out) ;
        vol   = Read_FL64(in, out, "  Volatility ");
        holi  = Read_HOLI_STR(in, out) ;
        risk  = Read_RISKSET(in, out) ;

        fres = OptIRF_Black2P(&today, &vold, irfp, &irf, &opt, &df,
                                vol, &holi, &risk, &fres1, &fres2);
  
        acc = Read_FL64(in, out, "");

        IOUtil_ParseLine(in, out) ;

        diff = Compare_Risk(in, out, True, fres, 
                   fres1, fres2, acc);

        Free_OPTFUT(&opt) ;
        Free_DISCFAC(&df) ;
        Free_HOLI_STR(&holi) ;
        Free_RISKSET(&risk) ;
    }

    return diff;
}


INTI swapcalltest(char* txa, FILE*  in, FILE*  out)
{
  INTI      diff;
  DATESTR   analys;
  DATESTR   voldate;
  FL64      vol, p, exp, impl;
  SWAPCALL  swap;
  DISCFAC   df;
  HOLI_STR  holi;
  B76SWTM   b76t;
  BOOLE     ok;

  diff = -1;

  if (!strcmp(txa, "SwapCall_Black2P()"))
  {
    fprintf(out, "%s\n", txa) ;

    IOUtil_ParseLine(in, out);

    diff = 0;
    fscanf(in, "%lf", &exp);

    analys = Read_DATESTR(in, out, "Analysis");
    voldate = Read_DATESTR(in, out, "Vol date");
    vol = Read_FL64(in, out, "Vol");      
    swap = Read_SWAPCALL(in, out);
    df = Read_DISCFAC(in, out);
    holi = Read_HOLI_STR(in, out);
    b76t = Read_B76SWTM(in, out);

    ok = SwapCall_Black2P(&analys, &voldate, vol, &swap, &df, 
                          &holi, &b76t, &p);
    
    diff = Write_SingleDiff(ok, True, p, exp, 1e-5, out) ;

    Free_PLANARRAY(swap.fix.stepcoup, 1);
    Free_PLANARRAY(swap.fix.irreg, 1);
    Free_PAYDAYDEF(&swap.pfix);
    Free_DISCFAC(&df);
    Free_HOLI_STR(&holi);
  }

  else if (!strcmp(txa, "SwapCall_Black2Impl()"))
  {
    fprintf(out, "%s\n", txa) ;

    IOUtil_ParseLine(in, out);

    diff = 0;
    fscanf(in, "%lf", &exp);

    p = Read_FL64(in, out, "NPV");
    analys = Read_DATESTR(in, out, "Analysis");
    voldate = Read_DATESTR(in, out, "Vol date");
    vol = Read_FL64(in, out, "Vol");      
    swap = Read_SWAPCALL(in, out);
    df = Read_DISCFAC(in, out);
    holi = Read_HOLI_STR(in, out);
    b76t = Read_B76SWTM(in, out);

    ok = SwapCall_Black2Impl(&analys, &voldate, vol, p, &swap, &df, 
                      &holi, &b76t, &impl);
    
    diff = Write_SingleDiff(ok, True, impl, exp, 1e-5, out) ;

    Free_PLANARRAY(swap.fix.stepcoup, 1);
    Free_PLANARRAY(swap.fix.irreg, 1);
    Free_PAYDAYDEF(&swap.pfix);
    Free_DISCFAC(&df);
    Free_HOLI_STR(&holi);
  }

  return diff;
}


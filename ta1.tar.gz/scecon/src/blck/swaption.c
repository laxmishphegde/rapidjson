/* SCID @(#)swaption.c	1.17 (SimCorp) 99/02/19 14:10:04 */

/************************************************************************
*
*   project     SCecon
*
*   file name   swaption.c
*
*   general     This file contains calculation routines for EU swaptions*
*
************************************************************************/

#include <cap.h>

#define SHOCKSIZE 0.01
#define IRG_EPS   0.0001

/*
..Currently private
*************************************************************************
*
*               Swaption_Black2Vol()
*
*    interface  #include <cap.h>
*               BOOLE Swaption_Black2Vol(DATESTR     *analys,
*                                        SWPTVOL     *swvol,
*                                        SWAPTION    *ncsw,
*                                        DISCFAC     *df,
*                                        HOLI_STR    *holi) ;
*
*    general    The routine computes the volatility to be used in the
*               Black76-based swaption pricing routines.
*
*               The vol is interpolated of an at-the-money 2D surface.
*               The 'smile' is handled using a 'skew'-factor.
*
*               Currently only vanilla swaptions are supported.
*
*    input      DATESTR   *analys Pointer to analysis date (NPV date)
*
*               SWPTVOL   *swvol  The volatility surface.
*
*               SWAPTION  *ncsw   Pointer to swaption data
*
*               DISCFAC   *df     Discount function setup for
*                                 discounting future payments.
*
*               HOLI_STR  *holi   Container for data on business
*                                 day convention and non-week-end
*                                 holidays.
*
*    output
*
*    returns    The volatility (as a percentage).
*
*    diagnostics
*
*    see also   Swaption_Black2P()
*
*************************************************************************
*/


FL64 Swaption_Black2Vol(DATESTR* analys,
                        SWPTVOL*    swvol,
                        SWAPTION*   ncsw,
                        DISCFAC*    df,
                        HOLI_STR*   holi)
{
    FL64      fwd, tmp, x10, x20, vol, strike ;
    INTI      i ;
    DATESTR   date, date1 ;
    FL64ARRAY x1, x2 ;

    /* 1. (2D) Interpolate to get ATM vol - Prepare data */
    date  = Cldr_NextBusinessDate(&ncsw->maturity, holi) ;
	x10 = Cldr_TermBetweenDates(analys, &date, 12, swvol->cal, LAST, holi);  /* PMSTA-22396 - SRIDHARA � 160502 */
    date1 = Cldr_NextBusinessDate(&ncsw->pfix.last, holi) ;
	x20 = Cldr_TermBetweenDates(&date, &date1, 12, swvol->cal, LAST, holi);  /* PMSTA-22396 - SRIDHARA � 160502 */

    x1  = Alloc_FL64ARRAY(swvol->no) ;
    x2  = Alloc_FL64ARRAY(swvol->ns) ;

    for (i = 0; i < swvol->no; i++)
        x1[i] = (FL64) swvol->opt_mnth[i] ;

    for (i = 0; i < swvol->ns; i++)
        x2[i] = (FL64) swvol->swp_mnth[i] ;

    vol = Math_2Dinterpolation(x10, x20, x1, swvol->no, x2, swvol->ns,
                               swvol->vol, swvol->iconv) ;

    /* 2. Find ATM Strike Rate */
    date   = Cldr_NextBusinessDate(&ncsw->fix.effective, holi) ;
    strike = SwapFix_DF2CFrate(&date, 100.0, &ncsw->pfix, &date,
                               ncsw->fix.cal, df, holi) ;

    /* 3. Use SKEW formula to find the actual vol */
    fwd = ncsw->fix.fix_rate ;
    if (strike > 0.0)
        tmp = fwd / strike ;
    else
        tmp = 0.0 ;

    if (tmp > 0.0)
        tmp  = swvol->skew * log(tmp) ;
    else
        tmp = 0.0 ;

    vol *= 1.0 + SQR(tmp) ;

    /* 4. Clean Up */
    Free_FL64ARRAY(x1) ;
    Free_FL64ARRAY(x2) ;

    return vol ;
}


/*,,SOH,,
*************************************************************************
*
*               Swaption_Black2P()
*
*    interface  #include <cap.h>
*               BOOLE Swaption_Black2P(DATESTR     *analys,
*                                      DATESTR     *voldate,
*                                      FL64        vol,
*                                      SWAPTION    *ncsw,
*                                      DISCFAC     *df,
*                                      DISCFAC     *df_cf,
*                                      CMCONVADJ   *cmadj,
*                                      HOLI_STR    *holi,
*                                      B76SWTM     *b76t,
*                                      RISKSET     *risk,
*                                      FL64        *p,
*                                      FL64        *dp,
*                                      FL64        *ddp) ;
*
*    general    The routine computes the theoretical price for a
*               swaption using the Black 76 model for European-Style
*               swaptions
*               This model assumes that the option is of European type.
*               The option type is defined as:
*
*                    CALL - Receiver (Fix) Swaption
*                    PUT  - Payer (Fix) Swaption
*
*               In addition some of the risk measures can be computed.
*               The parameter risk->key describes what is to be
*               computed, the following value are possible
*
*                    risk->key            Meaning
*                    ------------         --------------------
*                    KEY_VOL              Vol Sensitivity (Vega)
*                    KEY_STRIKE           Swaprate Sensitivity
*                    KEY_DF               Zero Yield Sensitivity
*                    KEY_BPV              Basis point value (BPV)
*                    KEY_MATURITY         Maturity Sensitivity (Theta)
*                    KEY_MATURITY_BPV     Maturity Sensitivity (Theta)
*                    KEY_PROB             Moneyness - Delta / Gamma
*                    ------------         --------------------
*
*               The delta/gammas for KEY_DF corresponds to shocks in the*
*               entire Zero Yield Curve.
*
*               The KEY_PROB numbers are alternative definitions of
*               delta and gamma. And express the in-the-moneyness of a
*               option (delta), and the sensitivity of this (gamma) to
*               variations in the underlying variable.
*
*               df_cf and cmadj are only used if ncsw->vanilla is False
*
*    input      DATESTR   *analys Pointer to analysis date (NPV date)
*
*               DATESTR   *voldate Vol is calculated from this date
*
*               FL64      vol     The volatility of the forward starting*
*                                 swap's swaprate in %.
*                                 See Swaption_VOLBOX2Vol()
*
*               SWAPTION  *ncsw   Pointer to swaption data
*
*               DISCFAC   *df     Discount function setup for discounting*
*                                 future payments.
*
*               DISCFAC   *df_cf  Discount function for generating float*
*                                 payments (CMT).
*
*               CMCONVADJ *cmadj  Data for Convexity Adjustment
*                                 Use NULL if no adjustment
*
*               HOLI_STR  *holi   Holiday adjustment setup.
*
*               B76SWTM   *b76t   Black 76 model variation to be used
*                                 Enter NULL for default model
*
*               RISKSET   *risk   Risk convention, see above.
*                                 Use NULL for no Greeks.
*
*    output     FL64      *p      Pointer to the premium in %
*
*               FL64      *dp     Pointer to the first order derivative.*
*
*               FL64      *ddp    Pointer to the second order derivative*
*
*    returns    True if all is OK, and False if not.
*
*    diagnostics
*
*    see also   Swaption_Black2Impl()
*               Swaption_HWCF2P()
*               Swaption_VOLBOX2Vol()
*               Swaption_Simple2SWAPTION()
*
*    wrapper    AP
*
*************************************************************************
,,EOH,,*/

BOOLE Swaption_Black2P(DATESTR* analys,
                       DATESTR*    voldate,
                       FL64       vol,
                       SWAPTION*   ncsw,
                       DISCFAC*    df,
                       DISCFAC*    df_cf,
                       CMCONVADJ*  cmadj,
                       HOLI_STR*   holi,
                       B76SWTM*    b76t,
                       RISKSET*    risk,
                       FL64*       p,
                       FL64*       dp,
                       FL64*       ddp)
{
    FL64      dr = 0, ddr = 0, x1, plo = 0, phi = 0, shock ;
    BOOLE     ok ;
    DATESTR   anld, vold ;
    DISCFAC   sdf_cf, sdf ;
    CALCONV   cal ;
    KEYCONV   key ;
    B76SWTM   b76 ;

    /* Initialise */
    ok  = True ;
    *p  = *dp = *ddp = 0.0 ;
    cal = ncsw->cal ;
    key = (risk != NULL ? risk->key : KEY_PRICE) ;

    /* Avoid silly things 
       Barrier swaption check should be returned in a model status !! */
    if (GetPlanFill(df->disc) == 0 || ncsw->oadd == SWPTBARR)
        return False ;

    if (b76t == NULL)
    {
        b76.b76sm     = B76SM_RATE ;
        b76.use_fwd   = False ;
        ncsw->swapstl = True ;
    }
    else
        b76 = *b76t ;

    if (b76.b76sm == B76SM_RATE)
        ok = Swaption_Black2P_Rate(analys, voldate, vol, ncsw, df, df_cf,
                                   cmadj, holi, &b76, False, key, p, &dr,
                                   &ddr) ;
    else if (b76.b76sm == B76SM_RATEPA)
        ok = Swaption_Black2P_Rate(analys, voldate, vol, ncsw, df, df_cf,
                                   cmadj, holi, &b76, True, key, p, &dr,
                                   &ddr) ;
    else if (b76.b76sm == B76SM_SCORIG)
        ok = Swaption_Black2P_Scorig(analys, voldate, vol, ncsw, df, df_cf,
                                     cmadj, holi, key, p, &dr, &ddr) ;
    else if (b76.b76sm == B76SM_PRICE)
        ok = Swaption_Black2P_Price(analys, voldate, vol, ncsw, df, df_cf,
                                    cmadj, holi, key, p, &dr, &ddr) ;

    /* Compute risk ratios - if specified */
    if (ok == False || risk == NULL || risk->risk == ZERO_ORDER)
        return ok ;

    /* Calculate risk ratios */
    shock = Scutl_Default_Shock(risk->shock, risk->key) ;

    switch (risk->key)
    {
        case KEY_PROB :

            *dp  = dr ;
            *ddp = ddr ;
            break ;

        case KEY_STRIKE:   /* Swaprate sensitivity */

            ncsw->fix.fix_rate -= shock ;
            ok = Swaption_Black2P(analys, voldate, vol, ncsw, df, df_cf,
                                  cmadj, holi, b76t, NULL, &plo, &x1, &x1) ;

            ncsw->fix.fix_rate += 2.0 * shock ;
            ok = ok && Swaption_Black2P(analys, voldate, vol, ncsw, df, df_cf,
                                        cmadj, holi, b76t, NULL, &phi, &x1,
                                        &x1) ;
            ncsw->fix.fix_rate -= shock ;
            break ;

        case KEY_VOL:

            ok = Swaption_Black2P(analys, voldate, vol - shock, ncsw, df, df_cf,
                                  cmadj, holi, b76t, NULL, &plo, &x1, &x1) ;

            ok = ok && Swaption_Black2P(analys, voldate, vol + shock, ncsw, df,
                                        df_cf, cmadj, holi, b76t, NULL,
                                        &phi, &x1, &x1) ;
            break ;

        case KEY_DF:
        case KEY_BPV:

            /* $Duration / Convexity - Shock DF */
            sdf    = Disc_ShockRates(df, 1.0, risk, holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */
            sdf_cf = Disc_ShockRates(df_cf, 1.0, risk, holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */

            ok  = Swaption_Black2P(analys, voldate, vol, ncsw, &sdf, &sdf_cf,
                                   cmadj, holi, b76t, NULL, &phi, &x1, &x1) ;

            Free_PLANARRAY(sdf.disc, 1) ;
            Free_PLANARRAY(sdf_cf.disc, 1) ;

			sdf = Disc_ShockRates(df, -1.0, risk, holi);  /* PMSTA-22396 - SRIDHARA � 160502 */
			sdf_cf = Disc_ShockRates(df_cf, -1.0, risk, holi);  /* PMSTA-22396 - SRIDHARA � 160502 */
            ok = ok && Swaption_Black2P(analys, voldate, vol, ncsw, &sdf,
                                        &sdf_cf, cmadj, holi, b76t, NULL,
                                        &plo, &x1, &x1) ;

            Free_PLANARRAY(sdf.disc, 1) ;
            Free_PLANARRAY(sdf_cf.disc, 1) ;

            if (risk->key == KEY_BPV)
                shock = 1.0 ;

            break ;

        case KEY_MATURITY:
        case KEY_MATURITY_BPV:

            /* Let time decay -> and reflect this in the dates of the DF's.
               Ie. we move the entire Term Strcuture of interest rates. */
			/* PMSTA-22396 - SRIDHARA � 160502 */
            sdf    = Disc_Shock_Dates(df, (INTI) shock, holi) ;
            sdf_cf = Disc_Shock_Dates(df_cf, (INTI) shock, holi) ;
            anld   = Cldr_AddDays(analys, (INTL) shock, cal, holi) ;
            vold   = Cldr_AddDays(voldate, (INTL) shock, cal, holi) ;

            /* Note that we do not shift the vol, since we want to interpolate
               the same vols as before */
            ok = Swaption_Black2P(&anld, &vold, vol, ncsw, &sdf, &sdf_cf, cmadj,
                                  holi, b76t, NULL, &plo, &x1, &x1) ;

            /* Do not set ddp */
            *dp = (plo - *p) / shock ;

            if (risk->key == KEY_MATURITY)
				*dp *= Cldr_DaysPerYear(analys, analys, 0, cal, LAST, holi); /* PMSTA-22396 - SRIDHARA � 160502 */

            /* Clean up */
            Free_PLANARRAY(sdf.disc, 1) ;
            Free_PLANARRAY(sdf_cf.disc, 1) ;
            break ;

        default:
            ;
    }

    if (ok == True && risk->key != KEY_MATURITY &&
        risk->key != KEY_PROB && risk->key != KEY_MATURITY_BPV)
    {
        *dp = (phi - plo) / (2.0 * shock);

        if (risk->risk == SECOND_ORDER && risk->key != KEY_BPV)
            *ddp = (phi + plo - 2.0 * (*p)) / SQR(shock) ;
    }

    return ok ;
}


/*
..This is the 'market model'
*/

BOOLE Swaption_Black2P_Rate(DATESTR* analys,
                            DATESTR*    voldate,
                            FL64       vol,
                            SWAPTION*   ncsw,
                            DISCFAC*    df,
                            DISCFAC*    df_cf,
                            CMCONVADJ*  cmadj,
                            HOLI_STR*   holi,
                            B76SWTM*    b76t,
                            BOOLE      pa,
                            KEYCONV    key,
                            FL64*       p,
                            FL64*       dr,
                            FL64*       ddr)
{
    FL64      actrate, dum, fac, oldfix, dts, fwd, alphai, DFi, pfl, dsc ;
    INTI      i ;
    BOOLE     ok ;
    DATESTR   start, today, d1, d2 ;
    FIXRATE   fix ;
    PAYDAYDEF pday ;
    OPTINT    oint ;
    SWAPFIX   sfix ;
    FLOATRATE frate ;
    SWAPFLOAT sfl ;
    RISKCONV  risk ;
    REPAYMNT  repay ;
    CFLWARRAY cflw ;

    /* Initialise */
    ok     = True ;
    *p     = *dr = *ddr = 0.0 ;
    fix    = ncsw->fix ;
    pday   = ncsw->pfix ;
    oldfix = fix.fix_rate ;

    if (ncsw->vanilla == False && GetPlanFill(ncsw->amort) > 0)
        repay = Set_REPAYMNT(NONREGULAR, NULL, False, 0.0, NULL, ncsw->amort, 
                             NULL, 0.0, 0.0) ;
    else
        repay = Set_REPAYMNT(BULLET, NULL, False, 0.0, NULL, NULL, NULL,
                             0.0, 0.0) ;

    /* Find dates */
    today = df->disc->day[0] ;
    start = Cldr_NextBusinessDate(&fix.effective, holi) ;

    /* Calculate value of floating leg at option maturity */
    if (ncsw->vanilla == False)
    {
        /* Find floating PV */
        frate = Set_FLOATRATE(&ncsw->fbase, ncsw->factor, False, NULL, NONE,
                              ANNUALLY, &ncsw->index, NULL, NULL, NULL) ;
        sfl = Set_SWAPFLOAT(&repay, NULL, &frate, &ncsw->pfl, 0) ;
        pfl = SwapFl_DF2NPV(&start, &sfl, df_cf, df, cmadj, holi,
                            NULL, dr, ddr) ;
    }
    else
        pfl = 100.0 ;

    /* Find the current swaprate */
	dts = Disc_Interpolation(&start, df, holi); /* PMSTA-22396 - SRIDHARA � 160502 */
    sfix = Set_SWAPFIX(&repay, NULL, &fix, &pday, 0) ;
    ok   = SwapFix_DF2Rate(&today, pfl * dts, &sfix, df, holi, &actrate) ;

    /* Now do the pricing */
    if (ok == True)
    {
        /* Discount till 'today' */
		ok = Disc_forwval(df, analys, &dts, holi); /* PMSTA-22396 - SRIDHARA � 160502 */

        /* Find PV2Rate factor */
        fix.fix_rate  = 1.0 ;
        sfix          = Set_SWAPFIX(&repay, NULL, &fix, &pday, 0) ;
        sfix.repay.io = True ;

        if (ncsw->swapstl == True && pa == False)
            /* Swap Settlement - Calculate rate to PV translation factor */
            fac = SwapFix_DF2NPV(&start, &sfix, holi, df, NULL, &dum, &dum) ;
        else if (ncsw->swapstl == False && pa == False)
        {
            /* Cash Settlement */
            if (b76t->use_fwd == True)
                fwd = b76t->fwdswap / 100.0 ;
            else
                fwd = actrate / 100.0 ;

            /* Now generate the factor */
            cflw = SwapFix_GenrCflw(&sfix, holi) ;
            d2   = start ;
            for (fac = 0.0, DFi = 1.0, i = 0; i < cflw->filled; i++)
            {
                d1     = d2 ;
                d2     = cflw->days[i] ;
				alphai = Cldr_TermBetweenDates(&d1, &d2, 0, fix.cal, LAST, holi); /* PMSTA-22396 - SRIDHARA � 160502 */
                DFi   *= 1.0 / (1.0 + fwd * alphai) ;
                fac   += cflw->coupon[i] * DFi ;
            }

            Free_CFLWARRAY(cflw, 1) ;
        }
        else
            /* This is per annum */
            fac = 1.0 ;

        /* Formulated in rates so inverse */
        oint = swaption_set_OPTINT(analys, voldate, ncsw, oldfix, True,
                                   fac, holi) ;

        /* This is Per Annum Premium */
        risk = (key == KEY_PROB ? SECOND_ORDER : ZERO_ORDER) ;
        dsc  = (pa == True ? 1.0 : dts) ;
        *p   = Black_Premium(&oint, actrate, False, dsc, vol, dsc, dsc, key,
                             risk, 0.0, CONTINUOUS, 0, dr, ddr, holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */

        /* Calculate flat premium - if relevant */
        if (ncsw->oadd != BINARY || ncsw->bini.poff.poff != OP_BINARY)
            *p *= fac ;
    }

    sfix.fix.fix_rate = oldfix ;

    return ok ;
}


/*
..
*/

BOOLE Swaption_Black2P_Scorig(DATESTR* analys,
                       DATESTR*    voldate,
                       FL64       vol,
                       SWAPTION*   ncsw,
                       DISCFAC*    df,
                       DISCFAC*    df_cf,
                       CMCONVADJ*  cmadj,
                       HOLI_STR*   holi,
                       KEYCONV    key,
                       FL64*       p,
                       FL64*       dr,
                       FL64*       ddr)
{
    FL64        size, actrate = 0, dswap, e, f, dum, f0,
                oldfix, dts, dt, f1, vol_p ;
    BOOLE       ok ;
    DATESTR     start, matur, today ;
    CFLW_STR    *cflw ;
    FIXRATE     fix ;
    PAYDAYDEF   pday ;
    FLOATRATE   frate ;
    OPTINT      oint ;
    SWAPFLOAT   sfl ;
    SWAPFIX     sfix ;
    RISKCONV    risk ;
    REPAYMNT    repay ;

    /* warning avoidance */
    dswap = 0.0 ;

    /* Initialise */
    ok     = True ;
    size   = SHOCKSIZE ;
    *p     = *dr = *ddr = 0.0 ;
    fix    = ncsw->fix ;
    pday   = ncsw->pfix ;
    oldfix = fix.fix_rate ;

    if (ncsw->vanilla == False && GetPlanFill(ncsw->amort) > 0)
        repay = Set_REPAYMNT(NONREGULAR, NULL, False, 0.0, NULL, ncsw->amort, 
                             NULL, 0.0, 0.0) ;
    else
        repay = Set_REPAYMNT(BULLET, NULL, False, 0.0, NULL, NULL, NULL,
                             0.0, 0.0) ;

    /* Find dates */
    today = df->disc->day[0] ;
    matur = Cldr_NextBusinessDate(&ncsw->maturity, holi) ;
    start = Cldr_NextBusinessDate(&fix.effective, holi) ;

	/* PMSTA-22396 - SRIDHARA � 160502 */
    dt  = Disc_Interpolation(&matur, df, holi) ;
    dts = Disc_Interpolation(&start, df, holi) ;

    /* Calculate value of floating leg at maturity */
    if (ncsw->vanilla == True)
    {
        /* This is vanilla and simple forwards starting legs */
        e  = 100.0 * dts ;
		ok = Disc_forwval(df, &matur, &e, holi); /* PMSTA-22396 - SRIDHARA � 160502 */
    }
    else
    {
        /* This is for non-vanilla float legs - CMT's */
        frate = Set_FLOATRATE(&ncsw->fbase, ncsw->factor, False, NULL, NONE,
                              ANNUALLY, &ncsw->index, NULL, NULL, NULL) ;
        sfl = Set_SWAPFLOAT(&repay, NULL, &frate, &ncsw->pfl, 0) ;

        /* This is the option strike as floating PV */
        e = SwapFl_DF2NPV(&matur, &sfl, df_cf, df, cmadj, holi,
                          NULL, &dum, &dum) ;
    }

    /* Calculate the value of the fixed leg at maturity */
    sfix = Set_SWAPFIX(&repay, NULL, &fix, &pday, 0) ;
    cflw = SwapFix_GenrCflw(&sfix, holi) ;
	/* PMSTA-22396 - SRIDHARA � 160502 */
    f    = Swap_DF2NPV(&today, cflw, True, df, holi) ;
    ok   = ok && Disc_forwval(df, &matur, &f, holi) ;
    Free_CFLWARRAY(cflw, 1) ;

    /* Find the current swaprate */
    ok = ok && SwapFix_DF2Rate(&today, 100.0 * dts, &sfix, df, holi, &actrate) ;

    if (ok == True)
    {
        sfix.fix.fix_rate = actrate + size ;
        cflw = SwapFix_GenrCflw(&sfix, holi) ;

        /* f0 is the PV of a fixed leg entered into at current market rates */
        f0 = 100.0 * dts ;
        ok = Disc_forwval(df, &matur, &f0, holi) ;  /* PMSTA-22396 - SRIDHARA � 160502 */

        /* f0 is the PV of a fixed leg entered into at current market rates 
           plus a small perturbation */
		/* PMSTA-22396 - SRIDHARA � 160502 */
        f1   = Swap_DF2NPV(&today, cflw, True, df, holi) ;
        ok   = Disc_forwval(df, &matur, &f1, holi) ;
        Free_CFLWARRAY(cflw, 1) ;

        /* This is the sensitivity of a forward starting fixed leg to the
           current swaprate */
        dswap = SCecon_fabs( (f0 - f1) / size) ;
    }

    /* Now do the pricing */
    if (ok == True)
    {
        /* Transform the vol to the price vol of a forward starting bond */
        vol_p = dswap * vol * actrate / f ;

        /* Discount till 'today' */
		ok = Disc_forwval(df, analys, &dt, holi);  /* PMSTA-22396 - SRIDHARA � 160502 */

        /* Set base option */
        oint = swaption_set_OPTINT(analys, voldate, ncsw, e, False, 1.0, holi);

        risk = (key == KEY_PROB ? SECOND_ORDER : ZERO_ORDER) ;
        *p   = Black_Premium(&oint, f, False, 1.0, vol_p, dt,
                             dt, key, risk, 0.0, CONTINUOUS, 0, dr, ddr, holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */
    }

    sfix.fix.fix_rate = oldfix ;

    return ok ;
}


/*
..
*/

BOOLE Swaption_Black2P_Price(DATESTR* analys,
                       DATESTR*    voldate,
                       FL64       vol,
                       SWAPTION*   ncsw,
                       DISCFAC*    df,
                       DISCFAC*    df_cf,
                       CMCONVADJ*  cmadj,
                       HOLI_STR*   holi,
                       KEYCONV    key,
                       FL64*       p,
                       FL64*       dr,
                       FL64*       ddr)
{
    FL64        size, dswap, e, f, dum, f0, oldfix, dts, dt, f1, vol_p ;
    BOOLE       ok ;
    DATESTR     start, matur, today ;
    CFLW_STR    *cflw ;
    FIXRATE     fix ;
    PAYDAYDEF   pday ;
    FLOATRATE   frate ;
    OPTINT      oint ;
    SWAPFLOAT   sfl ;
    SWAPFIX     sfix ;
    RISKCONV    risk ;
    REPAYMNT    repay ;

    /* warning avoidance */
    dswap = 0.0 ;

    /* Initialise */
    ok     = True ;
    size   = SHOCKSIZE ;
    *p     = *dr = *ddr = 0.0 ;
    fix    = ncsw->fix ;
    pday   = ncsw->pfix ;
    oldfix = fix.fix_rate ;

    if (ncsw->vanilla == False && GetPlanFill(ncsw->amort) > 0)
        repay = Set_REPAYMNT(NONREGULAR, NULL, False, 0.0, NULL, ncsw->amort, 
                             NULL, 0.0, 0.0) ;
    else
        repay = Set_REPAYMNT(BULLET, NULL, False, 0.0, NULL, NULL, NULL,
                             0.0, 0.0) ;

    /* Find dates */
    today = df->disc->day[0] ;
    matur = Cldr_NextBusinessDate(&ncsw->maturity, holi) ;
    start = Cldr_NextBusinessDate(&fix.effective, holi) ;

	/* PMSTA-22396 - SRIDHARA � 160502 */
    dt  = Disc_Interpolation(&matur, df, holi) ;
    dts = Disc_Interpolation(&start, df, holi) ;

    /* Calculate value of floating leg at maturity */
    if (ncsw->vanilla == True)
    {
        /* This is vanilla and simple forwards starting legs */
        e  = 100.0 * dts ;
        ok = Disc_forwval(df, &matur, &e, holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */
    }
    else
    {
        /* This is for non-vanilla float legs - CMT's */
        frate = Set_FLOATRATE(&ncsw->fbase, ncsw->factor, False, NULL, NONE,
                              ANNUALLY, &ncsw->index, NULL, NULL, NULL) ;
        sfl = Set_SWAPFLOAT(&repay, NULL, &frate, &ncsw->pfl, 0) ;

        /* This is the option strike as floating PV */
        e   = SwapFl_DF2NPV(&matur, &sfl, df_cf, df, cmadj, holi,
                            NULL, &dum, &dum) ;
    }

    /* Calculate the value of the fixed leg at maturity */
    sfix = Set_SWAPFIX(&repay, NULL, &fix, &pday, 0) ;
    cflw = SwapFix_GenrCflw(&sfix, holi) ;
	/* PMSTA-22396 - SRIDHARA � 160502 */
    f    = Swap_DF2NPV(&today, cflw, True, df, holi) ;
    ok   = ok && Disc_forwval(df, &matur, &f, holi) ;
    Free_CFLWARRAY(cflw, 1) ;

    if (ok == True)
    {
        sfix.fix.fix_rate = oldfix + size ;
        cflw = SwapFix_GenrCflw(&sfix, holi) ;
		/* PMSTA-22396 - SRIDHARA � 160502 */
        f1   = Swap_DF2NPV(&today, cflw, True, df, holi) ;
        ok   = Disc_forwval(df, &matur, &f1, holi) ;
        Free_CFLWARRAY(cflw, 1) ;

        /* This is the sensitivity of a forward starting fixed leg to the
           current swaprate */
        f0    = f ;
        dswap = fabs( (f0 - f1) / size) ;
    }

    /* Now do the pricing */
    if (ok == True)
    {
        /* Transform the vol to the price vol of a forward starting bond */
        vol_p = dswap * vol * oldfix / f ;

        /* Set base option */
        oint = swaption_set_OPTINT(analys, voldate, ncsw, e, False, 1.0, holi);
        risk = (key == KEY_PROB ? SECOND_ORDER : ZERO_ORDER) ;
        *p   = Black_Premium(&oint, f, False, 1.0, vol_p, dt,
                             dt, key, risk, 0.0, CONTINUOUS, 0, dr, ddr, holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */
    }

    sfix.fix.fix_rate = oldfix ;

    return ok ;
}


/*,,SOH,,
*************************************************************************
*
*               Swaption_Black2Impl()
*
*    interface  #include <cap.h>
*               BOOLE Swaption_Black2Impl(DATESTR    *analys,
*                                         DATESTR    *voldate,
*                                         FL64       pv,
*                                         FL64       vol,
*                                         SWAPTION   *ncsw,
*                                         DISCFAC    *df,
*                                         DISCFAC    *df_cf,
*                                         CMCONVADJ  *cmadj,
*                                         HOLI_STR   *holi,
*                                         B76SWTM    *b76t,
*                                         KEYCONV    what,
*                                         ITERCTRL   *ictrl,
*                                         FL64       *res) ;
*
*    general    The routine computes the implied volatility
*               or implied swaprate for a swaption using the Black 76
*               model for European-Style Swaptions.
*
*               df_cf and cmadj are only used if ncsw->vanilla is False
*
*    input      DATESTR   *analys Pointer to analysis date (NPV date)
*
*               DATESTR   *voldate Vol is calculated from this date
*
*               FL64      pv      The premium of the option on analys.
*
*               FL64      vol     The volatility of the forward starting*
*                                 swap's swaprate in %.
*
*               SWAPTION  *ncsw   Pointer to swaption data
*
*               DISCFAC   *df     Discount factor setup for discounting
*                                 future payments.
*
*               DISCFAC   *df_cf  Discount function for generating float*
*                                 payments (CMT).
*
*               CMCONVADJ *cmadj  Data for Convexity Adjustment
*                                 Use NULL if no adjustment
*
*               HOLI_STR  *holi   Container for data on business
*                                 day convention and non-week-end
*                                 holidays.
*
*               B76SWTM   *b76t   Black 76 model variation to be used
*                                 Enter NULL for default model
*
*               KEYCONV   what    Key convention, KEY_STRIKE for implied*
*                                 swaprate and KEY_VOL for implied vol
*
*               ITERCTRL  *ictrl  Iteration control data. Use defaults
*                                 whenever possible.
*
*    output     FL64      *res    Pointer to the implied ratio.
*
*    returns    True if all is OK, and False if not.
*
*    diagnostics
*
*    see also   Swaption_Black2P()
*
*    wrapper    AP
*
*************************************************************************
,,EOH,,*/

BOOLE Swaption_Black2Impl(DATESTR* analys,
                          DATESTR*    voldate,
                          FL64        pv,
                          FL64        vol,
                          SWAPTION*   ncsw,
                          DISCFAC*    df,
                          DISCFAC*    df_cf,
                          CMCONVADJ*  cmadj,
                          HOLI_STR*   holi,
                          B76SWTM*    b76t,
                          KEYCONV     what,
                          ITERCTRL*   ictrl,
                          FL64*       res)
{
    BOOLE    ok ;
    FL64     oldsr, shock ;
    BLCKINT  blck_data ;
    ITERCTRL ctrl ;
    NR_ERR   err ;

    /* Save to restore. */
    oldsr = ncsw->fix.fix_rate ;

    /* Initialize for Newton_Raphson. */
    shock = (ictrl->shock <= 0.0 ?   IRG_EPS : ictrl->shock) ;
    blck_data = Blck_SetBLCKINT(analys, voldate, pv, NULL, ncsw, df,
      df_cf, vol, NULL, cmadj, holi, b76t, what, shock) ;
    Blck_SetITERCTRL(ictrl, what, &blck_data, &ctrl, holi) ;   /* PMSTA-29444 - SRIDHARA - 050318 */

    err = Newton_Raphson(&Blck_NewtonRaphson, &blck_data, &ctrl, 
		res, holi);   /* PMSTA-22396 - SRIDHARA � 160502 */
    ok = (err == NR_ROOT_FOUND ? True : False) ;

    ncsw->fix.fix_rate = oldsr ;

    return ok ;
}


/*,,SOH,,
*************************************************************************
*
*               Swaption_Black2Delta()
*
*    interface  #include <cap.h>
*               FL64ARRAY Swaption_Black2Delta(DATESTR     *analys,
*                                              DATESTR     *voldate,
*                                              FL64        vol,
*                                              SWAPTION    *ncsw,
*                                              DISCFAC     *df,
*                                              DISCFAC     *df_cf,
*                                              CMCONVADJ   *cmadj,
*                                              HOLI_STR    *holi,
*                                              B76SWTM     *b76t,
*                                              DELTASET    *ds,
*                                              BOOLE       *ok);
*
*    general    The routine computes the delta vector for a swaption
*               using the Black 76 model for European-Style swaptions.
*               This model assumes that the option is of European type.
*
*               The delta vector represents the price differences
*               invoked by the curve shocks.
*
*               df_cf, ds_cf and cmadj are only used if ncsw->vanilla
*               is False.
*
*    input      DATESTR   *analys Pointer to analysis date (NPV date)
*
*               DATESTR   *voldate Vol is calculated from this date
*
*               FL64      vol     The volatility of the forward starting*
*                                 swap's swaprate in %.
*
*               SWAPTION  *ncsw   Pointer to swaption data
*
*               DISCFAC   *df     Discount function setup
*
*               DISCFAC   *df_cf  Discount function for generating float*
*                                 payments (CMT).
*
*               CMCONVADJ *cmadj  Data for Convexity Adjustment
*                                 Use NULL if no adjustment
*
*               HOLI_STR  *holi   Container for data on business
*                                 day convention and non-week-end
*                                 holidays.
*
*               B76SWTM   *b76t   Black 76 model variation to be used
*                                 Enter NULL for default model
*
*               DELTASET  *ds     Data for delta calculation.
*
*    output     BOOLE     *ok     True if all OK, False if not.
*
*    returns    The delta vector allocated as:
*
*                         Alloc_FL64ARRAY(ds->nshock) ;
*    diagnostics
*
*    see also   Swaption_Black2P()
*
*    wrapper    AP
*
*************************************************************************
,,EOH,,*/

FL64ARRAY Swaption_Black2Delta(DATESTR* analys,
                       DATESTR*    voldate,
                       FL64       vol,
                       SWAPTION*   ncsw,
                       DISCFAC*    df,
                       DISCFAC*    df_cf,
                       CMCONVADJ*  cmadj,
                       HOLI_STR*   holi,
                       B76SWTM*    b76t,
                       DELTASET*   ds,
                       BOOLE*      ok)
{
    INTI      i ;
    FL64ARRAY dv ;
    FL64      p0, dum ;
    PLANARRAY old_cf, old_disc, old ;
    DATESTR   fsprev, matur ;

    /* Initialise */
    *ok       = True ;
    old_disc  = df->disc ;
    old_cf    = df_cf->disc ;
    dv = Alloc_FL64ARRAY(ds->nshock) ;

    /* The unshocked price */
    *ok = Swaption_Black2P(analys, voldate, vol, ncsw, df, df_cf, cmadj, holi,
                           b76t, NULL, &p0, &dum, &dum);

    /* Last relevant payday */
    matur = Cldr_NextBusinessDate(&ncsw->pfix.last, holi) ;
    if (ncsw->vanilla == False)
        matur = Cldr_TermUnit2Date(&matur, (INTI) (1.0 + ncsw->index.LIBORdur),
                                   ncsw->index.LIBORunit, ncsw->cal, LAST,
                                   holi);

    for (i = 0; *ok == True && i < ds->nshock; i++)
    {
        if (ds->dfwhich == DF_BOTH)
        {
            fsprev = Disc_get_chgdate(NULL, old_disc, &ds->shock[i]) ;
            fsprev = Disc_get_chgdate(&fsprev, old_cf, &ds->shock[i]) ;
        }
        else 
        {
            old = (ds->dfwhich == DF_CFLW ? old_cf : old_disc) ;
            fsprev = Disc_get_chgdate(NULL, old, &ds->shock[i]) ;
        }

        if (fsprev.y > 0 && Cldr_DateLT(&matur, &fsprev) == False)
        {
            /* Use shocks in ds->shoch for both curves */
            if (ds->dfwhich == DF_BOTH)
                df->disc = df_cf->disc = &ds->shock[i] ;  
            
            /* Use shocks in ds->shoch for cflw curve */
            else if (ds->dfwhich == DF_CFLW)
                df_cf->disc = &ds->shock[i] ;

            /* Use shocks in ds->shoch for disc curve */
            else if (ds->dfwhich == DF_DISC)
                df->disc = &ds->shock[i] ;

            *ok = Swaption_Black2P(analys, voldate, vol, ncsw, df, df_cf,
                                   cmadj, holi, b76t, NULL, &dv[i], &dum,
                                   &dum);
            dv[i] -= p0 ;

            if (ds->zero == True)
            {
				/* PMSTA-22396 - SRIDHARA � 160502 */
                /* Find shocked Zero PV */
                if (ds->dfwhich == DF_CFLW)
                    dv[i] /= Disc_DF2BPV(&ds->mid[i], df_cf, old_cf, holi) ;
                else
                    dv[i] /= Disc_DF2BPV(&ds->mid[i], df, old_disc, holi) ;
            }
        }
        else
            dv[i] = 0.0 ;
    }

    df->disc    = old_disc ;
    df_cf->disc = old_cf ;

    return dv ;
}


/*
*************************************************************************
*
*               XtndSwap_Black2P()
*
*    interface  #include <cap.h>
*               BOOLE XtndSwap_Black2P(DATESTR     *analys,
*                                      DATESTR     *voldate,
*                                      FL64        vol,
*                                      DATESTR     *matur,
*                                      SWAPTION    *ncsw,
*                                      DISCFAC     *df,
*                                      DISCFAC     *df_cf,
*                                      CMCONVADJ   *cmadj,
*                                      HOLI_STR    *holi,
*                                      FL64        *spr) ;
*
*    general    The routine computes the theoretical price for a
*               Swaption embedded in an Extendible swap. The option
*               is of European type.
*
*               The premium is amortized as an increase in the swaprate,*
*               so the premium calculated is the annual increase in
*               the swaprate.
*
*               The option type is defined as:
*
*                    CALL - Receiver (Fix) Swaption
*                    PUT  - Payer (Fix) Swaption
*
*               df_cf and cmadj are only used if ncsw->vanilla is False
*
*    input      DATESTR   *analys Pointer to analysis date (NPV date)
*
*               DATESTR   *voldate Vol is calculated from this date
*
*               FL64      vol     The volatility of the forward starting*
*                                 swap's swaprate in %.
*
*               DATESTR   *matur  The full maturity of the swap if the
*                                 swap is extended.
*
*               SWAPTION  *ncsw   Pointer to swaption data
*
*               DISCFAC   *df     Discount function setup
*
*               DISCFAC   *df_cf  Discount function for float leg cflw
*                                 generation.
*
*               CMCONVADJ *cmadj  Data for Convexity Adjustment
*                                 Use NULL if no adjustment
*
*               HOLI_STR  *holi   Holiday setup.
*
*    output     FL64      *spr    Pointer to increase in the swaprate
*
*    returns    True if all is OK, and False if not.
*
*    diagnostics
*
*    see also   Swaption_Black2P()
*
*************************************************************************
*/


BOOLE XtndSwap_Black2P(DATESTR* analys,
                       DATESTR*     voldate,
                       FL64        vol,
                       DATESTR*     matur,
                       SWAPTION*    ncsw,
                       DISCFAC*     df,
                       DISCFAC*     df_cf,
                       CMCONVADJ*   cmadj,
                       HOLI_STR*    holi,
                       FL64*        spr)
{
    FL64        pv, p, dum ;
    BOOLE       ok ;
    DATESTR     eff ;
    RISKSET     risk ;
    PAYDAYDEF   pday, Xpday ;
    B76SWTM     b76t ;

    /* Initialize */
    pday      = ncsw->pfix ;
    risk.risk = ZERO_ORDER ;
    *spr      = 0.0 ;
    eff       = ncsw->fix.effective ;

    /* First find the option premium */
    Xpday  = Set_PAYDAYDEF(True, &pday.last, NULL, matur, False, 
                           &pday.pseq, 0, NULL) ;

    ncsw->fix.effective = pday.last ;
    ncsw->pfix = Xpday ;

    b76t.b76sm = B76SM_SCORIG ;
    ok = Swaption_Black2P(analys, voldate, vol, ncsw, df, df_cf, cmadj, holi,
                          &b76t, &risk, &p, &dum, &dum) ;

	/* PMSTA-22396 - SRIDHARA � 160502 */
    /* Now amortize the premium as spread on the fixed leg */
    pv = 100.0 * Disc_Interpolation(&pday.last, df, holi) ;
    ok = ok && Disc_forwval(df, analys, &pv, holi) ;

    if (ok == True)
        *spr = SwapFix_DF2CFrate(analys, p + pv, &pday, &eff,
                                 ncsw->fix.cal, df, holi) ;

    ncsw->fix.effective = eff ;
    ncsw->pfix          = pday ;

    return ok ;
}


/*
..
*/


void Swaption_SetImpl(FL64 rts,
                      FL64*    vol,
                      FL64*    swaprate,
                      KEYCONV what)
{
    if (what == KEY_VOL)
        *vol = rts ;
    else if (what == KEY_STRIKE)
        *swaprate = rts ;
}


/*
..
*/

INTIARRAY Swaption_Genr_index(SWAPTIONARRAY swt, 
                                 INTI          nswt,
                                 BOOLE         use_optmatur)
{
    INTIARRAY index ;
    FL64ARRAY matur ;
    INTI      i ;

    matur = Alloc_FL64ARRAY(nswt) ;

    for (i = 0; i < nswt; i++)
        matur[i] = (FL64) Cldr_Datestr2YMD(
          (use_optmatur ? &swt[i].maturity : &swt[i].pfix.last)) ;

    index = Scutl_Indexx_FL64(nswt, matur, ASCENDING) ;

    Free_FL64ARRAY(matur) ;

    return index ;
}


/*,,SOH,,
*************************************************************************
*
*               Swaption_VOLBOX2Vol()
*
*    interface  #include <cap.h>
*               FL64 Swaption_VOLBOX2Vol(DATESTR  *voldate,
*                                        VOLBOX   *vb,
*                                        SWAPTION *swpt,
*                                        HOLI_STR *holi) ;
*
*    general    The routine computes the volatility to be used in the
*               Black76-based swaption pricing routines.
*
*    input      DATESTR  *voldate Vol is calculated off this date
*
*               VOLBOX   *vb      The volatility surface.
*                                 It is assumed that ALL entries in
*                                 vb->swapmatur have the same quoting
*                                 unit (we recommend MONTHS).
*
*               SWAPTION *swpt    Pointer to swaption data
*
*               HOLI_STR *holi    Businessday adjustment setup
*
*    output
*
*    returns    The volatility (as a percentage).
*
*    diagnostics
*
*    see also   Swaption_Black2P()
*
*************************************************************************
,,EOH,,*/

FL64 Swaption_VOLBOX2Vol(DATESTR* voldate,
                         VOLBOX*   vb,
                         SWAPTION* swpt,
                         HOLI_STR* holi)
{
    FL64    vol, s ;
    INTI    days1, days, num ;
    DATESTR dum, om, eday, sday, xday ;
    PERIOD  sm ;

    if (vb->filled_SM < 1)
        return 0.0 ;

    /* Find option maturity, strike and swap maturity */
    om = Cldr_NextBusinessDate(&swpt->maturity, holi) ;

    /* Strike is the rate on the fixed side */
    s = swpt->fix.fix_rate ;

    /* Swap maturity is the date of the last fixed side payment
       -find corresponding number of termunits from swap effective */

    sm   = Set_PERIOD(1, vb->swapmatur->unit) ;
    eday = Cldr_NextBusinessDate(&swpt->fix.effective, holi) ;
    sday = Cldr_NextBusinessDate(&swpt->pfix.last, holi) ;
    num  = Cldr_PeriodsBetweenDates(&eday, &sday, &sm, vb->cal, vb->eom, holi) ;

    if (num < 0)
        return 0.0 ;

    /* Be careful about period rounding */
    sm    = Set_PERIOD(num, vb->swapmatur->unit) ;
    xday  = Cldr_AddPeriod(&eday, &sm, vb->cal, vb->eom, holi) ;
	days = (INTI)Cldr_DaysBetweenDates(&sday, &xday, vb->cal, holi);  /* PMSTA-22396 - SRIDHARA � 160502 */
    dum   = Cldr_YMD2Datestr((YYYYMMDD) 0 ) ;
    sm    = Set_PERIOD(1, vb->swapmatur->unit) ;
    xday  = Cldr_AddPeriod(&dum, &sm, vb->cal, vb->eom, holi) ;
	days1 = (INTI)Cldr_DaysBetweenDates(&dum, &xday, vb->cal, holi);  /* PMSTA-22396 - SRIDHARA � 160502 */

    if (2 * days > days1)
        sm = Set_PERIOD(num - 1, vb->swapmatur->unit) ;
    else
        sm = Set_PERIOD(num, vb->swapmatur->unit) ;

    /* find swaption vol */
    vol = Vol_Linear_Lookup(vb, voldate, &om, s, &sm, holi) ;

    return vol ;
}


/*,,SOH,,
************************************************************************
*
*                Set_SWAPTION()
*
*   interface    #include <cap.h>
*                SWAPTION Set_SWAPTION(OPTTYPE    type,
*                                      DATESTR*   maturity,
*                                      CALCONV    cal,
*                                      BOOLE      swapstl,
*                                      FIXRATE*   fix,
*                                      PAYDAYDEF* pfix) ;
*
*   general      This routine sets the members of the struct defined
*                in the function name. The pointer members are simply
*                assigned - without physical copying. The intention
*                of the Set_*() routines is that by using this
*                functionality, one avoids setting individual members
*                of structs in the application code.
*
*                When new members are inserted in structs the Set_*()
*                routine will be changed accordingly.
*
*                One exception to this principle applies. Whenever
*                OPTADD and vanilla members are used, only the
*                vanilla members are set in the Set_*() routines. The
*                non-vanilla and exotic members are set to defaults,
*                and must be set elsewhere - if needed.
*
*                For details on the interpretation of the individual
*                struct members please check the struct definition.
*
*                The SWAPTION filled is a vanilla swaption. If more
*                general SWAPTION types are to be defined then the
*                individual non-vanilla members must be set
*                individually (remember to set .vanilla accordingly).
*
*   input        OPTTYPE    type     See general section.
*
*                DATESTR*   maturity See general section.
*
*                CALCONV    cal      See general section.
*
*                BOOLE      swapstl  See general section.
*
*                FIXRATE*   fix      See general section.
*
*                PAYDAYDEF* pfix     See general section.
*
*   output
*
*   returns      The filled out SWAPTION struct
*                .vanilla is True.
*
*   diagnostics
*
*   see also     SWAPTION
*
************************************************************************
,,EOH,,*/

SWAPTION Set_SWAPTION(OPTTYPE     type,
                DATESTR*    maturity,
                CALCONV     cal,
                BOOLE       swapstl,
                FIXRATE*    fix,
                PAYDAYDEF*  pfix)
{
    SWAPTION swt ;

    swt.type     = type ;
    swt.maturity = *maturity;
    swt.cal      = cal ;
    swt.swapstl  = swapstl ;
    swt.fix      = *fix ;
    swt.pfix     = *pfix ;

    swt.vanilla = True ;
    swt.fbase   = Set_FLOATBASE(10.0, cal, maturity, 0.0, False) ;
    swt.index   = Set_RATEINDEX(MMRATE, 3.0, MONTHS, NO_FREQUENCY, cal, 0.0) ;
    swt.factor  = 1.0 ;
    swt.pfl     = *pfix ;
    swt.amort   = NULL ;

    swt.oadd    = NO_OPTADD ;

    return swt ;
}


/*,,SOH,,
*************************************************************************
*
*               Swaption_Simple2SWAPTION()
*
*    interface  #include <cap.h>
*               SWAPTION Swaption_Simple2SWAPTION(DATESTR* today,
*                                                 OPTTYPE  type,
*                                                 PERIOD*  opt_matur,
*                                                 PERIOD*  swap_delay,
*                                                 PERIOD*  swap_matur,
*                                                 PMTFREQ  swap_freq,
*                                                 FL64     swap_rate,
*                                                 CALCONV  cal,
*                                                 EOMCONV  eom) ;
*
*    general    The routine generates a SWAPTION based on simple data.
*
*               Typically this can handle a swaption at issue as
*               quoted on broker pages (i.e. 12M into 48M semiannually,
*               strike 6.5)
*
*    input      DATESTR *today      The base date
*
*               OPTTYPE type        The option type
*
*               PERIOD  *opt_matur  The option length (e.g 12M)
*
*               PERIOD  *swap_delay The period from option expiry till
*                                   swap start. Use NULL for default.
*
*               PERIOD  *swap_matur The swap length (e.g 48M)
*
*               PMTFREQ swap_freq   Fixed side roll (eg. semiann)
*
*               FL64    swap_rate   The fixed side swap rate
*
*               CALCONV cal         The swap daycount method
*
*               EOMCONV eom         Month end adjustment
*
*    output
*
*    returns    The SWAPTION data type
*
*    diagnostics
*
*    see also   Swaption_Black2P()
*
*************************************************************************
,,EOH,,*/

SWAPTION Swaption_Simple2SWAPTION(DATESTR*   today,
                                     OPTTYPE    type,
                                     PERIOD*    opt_matur,
                                     PERIOD*    swap_delay,
                                     PERIOD*    swap_matur,
                                     PMTFREQ    swap_freq,
                                     FL64       swap_rate,
                                     CALCONV    cal,
                                     EOMCONV    eom)
{
    SWAPTION  s ;
    DATESTR   Omatur, Smatur, Seff ;
    FIXRATE   fix ;
    PAYDAYDEF pday ;
    PAYDAYSEQ pseq ;
    HOLI_STR  holi ;
    INTI      m ;

    holi = Set_HOLI_STR(NO_BUSADJUST, 0, NULL) ;
    m    = Cflw_MonthsBetweenPayments(swap_freq) ;

    Omatur = Cldr_AddPeriod(today, opt_matur, cal, eom, &holi) ;
    Seff   = Cldr_AddPeriod(&Omatur, swap_delay, cal, eom, &holi) ;
    Smatur = Cldr_AddPeriod(&Seff, swap_matur, cal, eom, &holi) ;
    fix    = Set_FIXRATE(swap_rate, cal, &Seff, NULL, 0.0, ODDCOUP, ODDCOUP,
                         False, False, NULL, True, NULL, NODCOMP) ;
    pseq   = Set_PAYDAYSEQ(m, MONTHS, NOODD, NOODD, ANCHOR, eom) ;
    pday   = Set_PAYDAYDEF(False, &Seff, NULL, &Smatur, False, &pseq, 
                           0, NULL) ;

    s = Set_SWAPTION(type, &Omatur, cal, True, &fix, &pday) ;

    return s ;
}


/*
..
*/

OPTINT swaption_set_OPTINT(DATESTR*  analys,
                              DATESTR*  voldate,
                              SWAPTION* ncsw,
                              FL64      strike,
                              BOOLE     in_rates,
                              FL64      PV2rate_fac,
                              HOLI_STR* holi)
{
    OPTINT  opt ;
    DATESTR matur ;
    FL64    cprem, cstr ;

    /* Set these dates */
    opt.analys  = *analys ;
    opt.voldate = *voldate ;

    /* Find the value on 'analys' date */
    matur    = Cldr_NextBusinessDate(&ncsw->maturity, holi) ;
	opt.tfix = Cldr_TermBetweenDates(analys, &matur, 0, ncsw->cal, LAST, holi);  /* PMSTA-22396 - SRIDHARA � 160502 */
    opt.t    = opt.tfix ;

    /* Volatility period */
	opt.tvol = Cldr_TermBetweenDates(voldate, &matur, 0, ncsw->cal, LAST, holi);  /* PMSTA-22396 - SRIDHARA � 160502 */

    /* Set remaining option members */
    opt.e     = strike ;
    opt.ptype = UP_FRONT ;
    opt.cal   = ncsw->cal ;

    /* Here the option payoff is formulated in rates */
    if (in_rates == True)
    {
        opt.type = STRADDLE ;
        if (ncsw->type == CALL)
           opt.type = PUT ;
        else if (ncsw->type == PUT)
           opt.type = CALL ;

        opt.oadd = ncsw->oadd ;
    }
    else
    {
        opt.type = ncsw->type ;
        opt.oadd = NO_OPTADD ;
    }

    /* Override exotics if vanilla is True */
    if (ncsw->vanilla)
      opt.oadd = NO_OPTADD;

    switch (opt.oadd)
    {
        case NO_OPTADD:
        default:
            break ;

        case BINARY:
            opt.bini = Set_BINARYINF(&ncsw->bini.poff,
                                     ncsw->bini.dcadj) ;
            break ;

        case CONTPREM:
            opt.oadd = BINARY ;
            cprem = SafeDivide(ncsw->ctp.prem, PV2rate_fac, 0.000001, 0.0) ;
            opt.bini.poff = Set_PAYOFFINF(OP_GAP, cprem, 1.0) ;
            opt.bini.dcadj = False ;
            break ;

        case COMPOPT:
            cstr = SafeDivide(ncsw->compo.strike, PV2rate_fac, 0.000001, 0.0);
            opt.compo = Set_COMPOPTINF(ncsw->compo.type, &ncsw->compo.matur,
                                       cstr) ;
            break ;

        case FWDSTART:
            /* Change some option settings accordingly */
            opt.tfix  = Cldr_TermBetweenDates(&ncsw->fwdst.dset, &matur, 
                                              0, ncsw->cal, LAST, holi);  /* PMSTA-22396 - SRIDHARA � 160502 */
            opt.t     = opt.tfix ;
            opt.tvol  = opt.tfix ;
            opt.e     = ncsw->fwdst.alpha * strike ;
            opt.oadd  = NO_OPTADD ;
            break ;

        case CHOOSER:
            opt.chos = Set_CHOOSERINF(&ncsw->chos.dchoose) ;
            break ;
    }

    return opt ;
}

/*,,SOH,,
*************************************************************************
*
*               Swaption_Black2ATMP()
*
*    interface  #include <cap.h>
*               BOOLE Swaption_Black2ATMP (DATESTR* analys,
*                                DATESTR*    voldate,
*                                FL64        atm_vol,
*                                SWAPTION*   ncsw,
*                                DISCFAC*    df_cf,
*                                DISCFAC*    df_disc,
*                                B76SWTM*    b76t,
*                                HOLI_STR*   holi,
*                                FL64*       strike,
*                                FL64*       p)
*
*    general    This function finds the at the money swaption rate and the 
*               at the money premium of a swaption.
*
*               Supports only Vanilla swaption (swaption->vanilla should 
*               be True)
*
*    input      DATESTR  *analys  Pointer to analysis date (NPV date)
*
*               DATESTR  *voldate Vol calculated from this date
*
*               FL64     atm_vol  At the money volatility of the swaption
*
*               SWAPTION *ncsw    Pointer to swaption data
*
*               DISCFAC  *df_cf   Discount function setup for
*                                 finding forward rates.
*
*               DISCFAC  *df_disc Discount function setup for discounting*
*                                 future payments.
*
*               B76SWTM  *b76t    Black 76 model variation to be used
*                                 Enter NULL for default model
*
*               HOLI_STR *holi    Holiday set-up.
*
*    output     FL64     *strike  The at the money strike.
*
*               FL64     *p       The at the money swaption premium.
*
*    returns    The total price of the swaption.
*
*    diagnostics
*
*    see also   Swaption_Black2Impl()
*               Swaption_Black2P()
*               SwapFix_DF2Rate()
*
*    wrapper    AP
*
*************************************************************************
,,EOH,,*/

BOOLE Swaption_Black2ATMP(DATESTR*  analys,
                      DATESTR*     voldate,
                      FL64         atm_vol,
                      SWAPTION*    ncsw,
                      DISCFAC*     df_cf,
                      DISCFAC*     df_disc,
                      B76SWTM*     b76t,
                      HOLI_STR*    holi,
                      FL64*        strike,
                      FL64*        p)
{
  SWAPFIX   sfix;
  FL64      dp, ddp;
  SWAPTION  swaption1;
  BOOLE     ok; 

  sfix = Set_SWAPFIX(NULL, NULL, &ncsw->fix, &ncsw->pfix, 0) ;

  ok = SwapFix_DF2Rate(&ncsw->fix.effective, 100.0, &sfix, df_disc,
                         holi, strike) ;
  if (ok == False)
  {
    *strike = 0.0;
    *p      = 0.0;
    return False;
  }

  /* Now compute premium given at the money strike */
  swaption1 = *ncsw;
  swaption1.vanilla = True;
  swaption1.fix.fix_rate = *strike;
  swaption1.fix.stepcoup = NULL;
  swaption1.fix.irreg = NULL;

  ok = Swaption_Black2P(analys, voldate, atm_vol, &swaption1, df_cf, df_disc, 
                        NULL, holi, b76t, NULL, p, &dp, &ddp) ;

  return ok; 
}

#undef SHOCKSIZE
#undef IRG_EPS

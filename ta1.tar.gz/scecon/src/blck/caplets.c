/* SCID @(#)caplets.c	1.29 (SimCorp) 99/11/12 10:46:41 */

/************************************************************************
*
*   project     SCecon
*
*   file name   caplets.c
*
*   general     This file contains calculation routines for cap/floors
*               and other IR options.
*
************************************************************************/


/** includes ***********************************************************/
#include <cap.h>

/** defines  ***********************************************************/
#define MIN_FORW_RATE  0.00001
#define IRG_MAXIT      100
#define IRG_GUESS      10.0
#define IRG_DAMP       1.0
#define IRG_ACC        0.000000001
#define IRG_EPS        0.0001
#define IRG_LOWER      0.0001
#define IRG_UPPER      1000.0  
#define IRG_UPPER_SIZE 1.0E10  
#define IRG_UPPER_VOL  100  



/*,,SOH,,
*************************************************************************
*
*               Caplets_Black2P()
*
*    interface  #include <cap.h>
*               FL64 Caplets_Black2P(DATESTR    *analys,
*                                    DATESTR    *voldate,
*                                    CAPLETS    *cap,
*                                    DISCFAC    *df_index,
*                                    DISCFAC    *df_disc,
*                                    VOL_STR    *vol,
*                                    CMCONVADJ  *cmadj,
*                                    HOLI_STR   *holi,
*                                    RISKSET    *risk,
*                                    FL64       *dp,
*                                    FL64       *ddp) ;
*
*    general    Caplets_Black2P() computes the theoretical price for a
*               cap, floor or IRG using the Black 76 model for interest
*               rate options.
*
*               A cap/floor is essentially a portfolio of caplets of
*               floorlets so the pricing function loops over the indi-
*               vidual *lets and finds the total price.
*
*               CMT/CMS Caps are handled by using a convexity adjust-
*               ment (as for CMT swaps).
*
*               All adjustments for businessdays in the caplets must be
*               performed prior to calling this function - eg. when
*               generating the IRG's with Caplets_GenrIRGARRAY().
*
*               Note that the volatility structure is a forward
*               volatility structure. The duration of the forward
*               volatilities should be the same as the duration of the
*               IRG's in the CAP for consistency.
*
*               Key ratios are calculated as follows:
*
*                   risk->key        dp          ddp
*                   ---------        ---         ----
*                   KEY_DF           $Dur        $Conv
*                   KEY_BPV          BPV
*                   KEY_PRICE        Delta       Gamma
*                   KEY_PROB         N(d1)       N/A
*                   KEY_MATURITY     Theta       N/A
*                   KEY_MATURITY_BPV Theta       N/A
*                   KEY_VOL          Vega        d(Vega)/d(Vol)
*                   KEY_STRIKE       d(P)/d(C)   d2(P)/d(C)2
*
*               where dp contains first order and ddp second order
*               ratios. C is the caprate (strike).
*
*               The delta/gammas for KEY_DF corresponds to shocks in the
*               entire Zero Yield Curve, whereas as the delta/gammas for
*               KEY_PRICE corresponds to shocks to the FRA rates only.
*
*               KEY_PROB returns an unadjusted N(d1) in a Black 76 sence.
*               Should not be confused with the option delta. This number
*               is only sensible for caplet. For caps the sum of caplet
*               N(d1) is returned. Notional amount is ignored.
*
*               When vega is calculated CM related vols are NOT shocked
*
*    input      DATESTR  *analys   Pointer to analysis date (NPV date)
*
*               DATESTR  *voldate  Vol calculated from this date
*
*               CAPLETS  *cap      The cap definition.
*
*               DISCFAC  *df_index Discount function setup for
*                                  finding forward rates.
*
*               DISCFAC  *df_disc  Discount function setup for discounting
*                                  future payments.
*
*               VOL_STR  *vol      Forward volatility structure.
*
*               CMCONVADJ *cmadj   Data for Convexity Adjustment
*                                  Use NULL if no adjustment
*
*               HOLI_STR *holi     Holiday set-up.
*
*               RISKSET  *risk     The risk ratio definitions
*                                  Use NULL for no Greeks
*
*    output     FL64     *dp       The first order ratio
*
*               FL64     *ddp      The second order ratio.
*
*    returns    The total price of the cap/floor.
*
*    diagnostics
*
*    see also   Caplets_Black2Impl()
*               Caplets_GenrIRGARRAY()
*               Caplets_HWCF2P()
*
*    wrapper    AP
*
*************************************************************************
,,EOH,,*/

FL64 Caplets_Black2P(DATESTR* analys,
                 DATESTR*   voldate,
                 CAPLETS*   cap,
                 DISCFAC*   df_index,
                 DISCFAC*   df_disc,
                 VOL_STR*   vol,
                 CMCONVADJ* cmadj,
                 HOLI_STR*  holi,
                 RISKSET*   risk,
                 FL64*      dp,
                 FL64*      ddp)
{
  FL64 total;

  total = Caplets_Black2P_int(analys, voldate, cap, df_index, df_disc,
                         vol, cmadj, holi, risk, dp, ddp, NULL, NULL);

  return total;
}

/*
*******************************************************************
*
*
*               FL64 Caplets_Black2P_int(DATESTR    *analys,
*                                    DATESTR    *voldate,
*                                    CAPLETS    *cap,
*                                    DISCFAC    *df_index,
*                                    DISCFAC    *df_disc,
*                                    VOL_STR    *vol,
*                                    CMCONVADJ  *cmadj,
*                                    HOLI_STR   *holi,
*                                    RISKSET    *risk,
*                                    FL64       *dp,
*                                    FL64       *ddp
*                                    FL64ARRAY  forwfix
*                                    INTIARRAY  caplength) ;
*
*
*     Like Caplets_Black2P, except that this returns forward fixings
*     and duration for each caplet, which is used in Caplets_Black2P_Array.   
* 
*     It is assumed that forwfix and caplength are either NULL or 
*     preallocated to have size cap.count, i.e. either called
*     as from Caplets_Black2P or as from Caplets_Black2P_Array.
*
*******************************************************************
*/


FL64 Caplets_Black2P_int(DATESTR* analys,
                             DATESTR*   voldate,
                             CAPLETS*   cap,
                             DISCFAC*   df_index,
                             DISCFAC*   df_disc,
                             VOL_STR*   vol,
                             CMCONVADJ* cmadj,
                             HOLI_STR*  holi,
                             RISKSET*   risk,
                             FL64*      dp,
                             FL64*      ddp,
                             FL64ARRAY  forwfix,
                             INTIARRAY  caplength)
{
  FL64      phi, plo, prem, ca, total, dsc_end, f_rate, volat,
            dr, ddr, dt, xdsc, shock, tot_dp, tot_ddp, sz, CMTv, adj, 
            tmp, volL, rstrike, dstrike, f_rate_prev ;
  INTI      nirg, i, ir, mcomp, mfreq ;
  DATESTR   day1, day0, rend, rstart, anld, vold, vdate, rdate, Dvol ;
  IRGARRAY  irg ;
  CALCONV   cal, vol_cal ;
  EOMCONV   eom ;
  QOTCONV   qot ;
  COMPMETHOD method;
  RISKCONV  rsk ;
  DISCFAC   sdf_disc, sdf_index ;
  BOOLE     ok, LIBORplain, Bend, cont_prem, f_rate_prev_set ;
  OPTINT    oint ;
  OPTADD    oadd ;
  RATEINDEX rindex ;

  /* Initialise */
  *ddp  = *dp = 0.0 ;
  irg   = cap->irg ;
  nirg  = cap->count ;
  cal   = cap->cal ;
  vol_cal = vol->cal ;
  eom   = cap->eom ;
  qot   = cap->qot ;
  oadd  = cap->oadd ;
  day0  = Cldr_YMD2Datestr((YYYYMMDD) 19900101) ;
  day1  = Cldr_YMD2Datestr((YYYYMMDD) 19910101) ;
  Dvol  = vdate = rdate = *voldate ;
  rstrike = (nirg > 0 ? irg[0].strike : 0.0) ;
  cont_prem = False ;
  f_rate_prev = 0.0 ;
  f_rate_prev_set = False ;

  /* 1.0 Set the compounding dates */
  method = cap->method ;
  mfreq = Cflw_MonthsBetweenPayments(cap->freq) ;
  mcomp = Cflw_MonthsBetweenPayments(cap->compfreq) ;

  /* This if-else statement was copied from SwapFl_GenrCoupons() */
  if (mcomp >= mfreq)
  {
      mcomp = mfreq ;
      if (method != DECOMPOUND)
          method = NONE ;
  }
  else
  {
      /* Avoid silly situations */
      if (method != FLAT && method != REGCOMPOUND && method != TAM)
          mcomp = mfreq ;
  }

  if (cap->oadd == CONTPREM)
  {
    cont_prem = True ;
    cap->oadd = BINARY ;
    cap->bini.poff.gap = cap->ctp.prem ;
    cap->bini.poff.poff  = OP_GAP ;
    cap->bini.poff.scale = 1.0 ;
    cap->bini.dcadj = False ;
  }

  else if (cap->oadd == SHARKFIN)
    return Caplets_Black2P_Barr(analys, voldate, cap, df_index, df_disc,
                                  vol, cmadj, holi, risk, dp, ddp) ;

  LIBORplain = cap_isLIBORplain(&cap->index, cal, eom, cap->freq) ;

  if (risk != NULL && (risk->key == KEY_PRICE || risk->key == KEY_PROB))
    rsk = risk->risk ;
  else
    rsk = ZERO_ORDER ;

  volat = CMTv = volL = 0.0 ;
  if (GetPlanFill(vol->vol) > 0 && vol->vc == FORWVOL)
	  volat = Vol_Interpolation(&irg[nirg - 1].fix_start, vol, holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */

  if (cmadj != NULL && cmadj->volCM.vc == FORWVOL && nirg > 0)
    Dvol = irg[nirg - 1].fix_start ;

  for (tot_dp = tot_ddp = total = 0.0, i = 0 ; i < nirg ; i++)
  {
    Bend = True ;

    /* Find discount factor from end till 'analys' */
	dsc_end = Disc_Interpolation(&irg[i].pay_day, df_disc, holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */
	ok = Disc_forwval(df_disc, analys, &dsc_end, holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */

    if (ok == False || Cldr_DateLE(&irg[i].pay_day, analys) == True)
      continue ;

    else if (Cldr_DateLT(&irg[i].fix_start, analys) == True &&
             Cldr_DateLT(analys, &irg[i].pay_day) == True &&
             cap->oadd != ASIAN)
    {
      total += dsc_end * Caplets_IRG_Payout(cap, i, holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */
      /* take care of seasoned reset caps */
      if (cap->oadd == RESET && (ir = i - cap->reset.nfirst) >= 0
          && ir % cap->reset.nfreq == 0)
      {
        rstrike = irg[i].LIBORfix + cap->reset.spread ;
      }
      f_rate_prev = irg[i].LIBORfix ;
      f_rate_prev_set = True ;
    }
    else if (Cldr_DateLT(&irg[i].fix_end, analys) == True &&
             Cldr_DateLT(analys, &irg[i].pay_day) == True &&
             cap->oadd == ASIAN)
      total += dsc_end * Caplets_IRG_Payout(cap, i, holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */
    else
    {
      xdsc = 1.0 ;

      /* Find the period for the forward rate */
      if (cap->oadd == ASIAN && cap->asian.avgrt == False)
      {
        rstart = irg[i].fix_end ;
        Bend   = False ;
		xdsc = Disc_Interpolation(&irg[i].pay_day, df_disc, holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */
		ok = Disc_forwval(df_disc, &rstart, &xdsc, holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */
      }
      else if (cap->oadd == ASIAN && cap->asian.avgrt == True)
      {
        /* Be Careful about Secondaries */
        if (Cldr_DateLT(&irg[i].fix_start, analys) == True &&
            Cldr_DateLT(analys, &irg[i].fix_end) == True)
        {
          rstart = *analys ;
          Bend   = False ;
        }
        else
          rstart = irg[i].fix_start ;
      }
      else
        rstart = irg[i].fix_start ;

      if (LIBORplain == False || Bend == False)
      {
        /* avoid fractional years (to suppress calendar dependence)*/
        rindex =  cap->index ;
        if (rindex.LIBORunit == YEARS) 
        {
          rindex.LIBORdur *= 12.0 ;
          rindex.LIBORunit = MONTHS ;
        }
        rend = Cldr_Term2Date(&rstart, rindex.LIBORdur,
                                rindex.LIBORunit, cal, eom) ;
        rend = Cldr_NextBusinessDate(&rend, holi) ;
      }
      else
        rend = irg[i].fix_end ;

      /* Find volatilities */
      if (GetPlanFill(vol->vol) > 0 && vol->vc == FORWFORW)
		  volat = Vol_Interpolation(&irg[i].fix_start, vol, holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */

      if (cmadj != NULL && cmadj->volCM.vc == FORWFORW)
        Dvol = irg[i].fix_start ;

      /* Find forward rate for IRG valuation - remember to
         convexity adjust the forward rate - if needed */
      f_rate = SwapFl_DF2ForwRate(&rstart, &rend, &irg[i].pay_day,
                                  &Dvol, &cap->index, False,
								  df_index, df_disc, cmadj, &ca, holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */
      f_rate = GETMAX(MIN_FORW_RATE, f_rate) ;

      /* Compounding/Decompounding */
      switch (method)
      {
      case DECOMPOUND:
          f_rate = Cflw_Decompound(f_rate, mcomp, True,
			  EPR_PER, NULL, NULL, cal, holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */
          /* Adjust for root convexity? 
             -> Look in SwapFl_GenrCoupons() !! */
          break;
      default:
          /* No compounding - do nothing */
          break;
      }

      /* output forward fixings and caplengths,
         if called by Caplets_Black2P_Array*/
      if (forwfix != NULL && caplength != NULL)
      {
        forwfix[i] = f_rate;
        caplength[i] = Cldr_DaysBetweenDates(&irg[i].fix_start,
                     &irg[i].fix_end, cal, holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */
      }

      /* reset caps get special treatment (see above for seasoned) */
      if (cap->oadd == RESET)
      {
        /* (re)set the caplet strike */
        irg[i].strike = rstrike ;
        vdate         = rdate ;

        /* New reset strike and vol date if this is a reset fixing */
        if ((ir = i - cap->reset.nfirst) >= 0 && ir % cap->reset.nfreq == 0)
        {
          /* a little inaccurate, but...  */
          if (cap->reset.delayfix == False || f_rate_prev_set == False)
            rstrike = f_rate + cap->reset.spread ;   
          else
            rstrike = GETMIN(GETMAX(f_rate_prev + cap->reset.spread_low,
                                    f_rate + cap->reset.spread),
                                    f_rate_prev + cap->reset.spread_up) ;

          rdate = irg[i].fix_start ;
        }
        f_rate_prev = f_rate ;
        f_rate_prev_set = True ;
      }

      /* Find relevant period scaling and discount factor */
      dt = MM_AnnForw2Qot(1.0, &irg[i].period_start,
                         &irg[i].period_end, cal, qot, 1.0, holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */
      dsc_end = MM_AnnForw2Qot(dsc_end, &day0, &day1, EU30E360,
                               qot, 1.0, holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */

      /* be careful about GAP's; for CONTPREM' these are absolute dollar
         pay-off amounts and should NOT be multiplied by day-count
         fractions. For 'BINARY.OP_BINARY' day-count adjustment
         is optional.         
         Here we scale the gap to compensate for later multiplication 
         with day-count fraction - to be reset later */
      if (dt > 0.0 
              && (cont_prem
                  || (cap->oadd == BINARY 
                      && cap->bini.poff.poff == OP_BINARY 
                      && !cap->bini.dcadj)))
          cap->bini.poff.gap /= dt ;

      /* Compounding/Decompounding of strike */
      switch (method)
      {
      case DECOMPOUND:
          dstrike = Cflw_Decompound(irg[i].strike, mfreq, True,
                                   EPR_PER, NULL, NULL, cal, holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */
          break;
      default:
          /* No compounding - do nothing */
          dstrike = irg[i].strike ;
          break;
      }

      /* Calculate price - and possibly risk ratios */
      oint = caplets_set_OPTINT(analys, &vdate, irg[i].type,
                                dstrike, UP_FRONT, cap, i, cal, vol_cal, holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */

      /* Calculate the correct short rate (r) / dividend (D) - such that
         r - D = 0, but r is sensible */
	  adj = Disc_Interpolation(&irg[i].fix_end, df_disc, holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */
	  ok = Disc_forwval(df_disc, analys, &adj, holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */

      /* Calculate Premium */
      if (risk != NULL)
        shock = Scutl_Default_Shock(risk->shock, risk->key) ;
      else
        shock = Scutl_Default_Shock(-1.0, KEY_PRICE) ;

      /* Remember the notional amount */
	  sz = Caplets_IRG_Notional(cap, i, holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */
      tmp      = sz * dt * xdsc ;
      /* This option was introduced to satisfy TMS2000 */
      if (risk != NULL && risk->key == KEY_PROB)
      {
        prem = Black_Premium(&oint, f_rate, False, adj, volat, adj,
                             dsc_end, KEY_PROB, rsk, shock,
							 CONTINUOUS, 0, &dr, &ddr, holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */
        tot_dp  += dr ;
        tot_ddp = 0.0 ;
      }
      else
      {
        prem = Black_Premium(&oint, f_rate, False, adj, volat, adj,
                           dsc_end, KEY_SPOT, rsk, shock,
						   CONTINUOUS, 0, &dr, &ddr, holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */
        tot_dp  += dr * tmp ;
        tot_ddp += ddr * tmp ;
      }
      total   += prem * tmp ;

      /* reset the gap */
      if (dt > 0.0
             && (cont_prem
                 || (cap->oadd == BINARY 
                     && cap->bini.poff.poff == OP_BINARY
                     && !cap->bini.dcadj)))
        cap->bini.poff.gap *= dt ;
    }
  }

  /* Clean up actions */
  if (oadd == CONTPREM)
    cap->oadd = CONTPREM ;

  if (risk == NULL || risk->risk == ZERO_ORDER)
    return total ;

  /* Shock input */
  shock = Scutl_Default_Shock(risk->shock, risk->key) ;

  switch (risk->key)
  {
    case KEY_PRICE:     /* FRA rate sensitivity - weird */
    case KEY_PROB:     
      *dp  = tot_dp ;
      *ddp = tot_ddp ;
      break ;

    case KEY_STRIKE:    /* Caprate sensitivity */

      for (i = 0 ; i < cap->count; i++)
        cap->irg[i].strike += shock ;

      phi = Caplets_Black2P(analys, voldate, cap, df_index, df_disc, vol,
                            cmadj, holi, NULL, &dr, &ddr) ;

      for (i = 0 ; i < cap->count; i++)
        cap->irg[i].strike -= 2.0 * shock ;

      plo = Caplets_Black2P(analys, voldate, cap, df_index, df_disc, vol,
                            cmadj, holi, NULL, &dr, &ddr) ;

      for (i = 0 ; i < cap->count; i++)
        cap->irg[i].strike += shock ;

      *dp = (phi - plo) / (2.0 * shock) ;
      if (risk->risk == SECOND_ORDER)
        *ddp = (phi + plo - 2.0 * total) / SQR(shock) ;

      break ;

    case KEY_VOL:       /* Vega */

      /* Be careful about CMT's - Currently NOT shocked */

      /* Shock the vol */
      for (i = 0; i < GetPlanFill(vol->vol); i++)
        vol->vol->f64[i] += shock ;

      phi = Caplets_Black2P(analys, voldate, cap, df_index, df_disc, vol,
                            cmadj, holi, NULL, &dr, &ddr) ;

      for (i = 0; i < GetPlanFill(vol->vol); i++)
        vol->vol->f64[i] -= 2.0 * shock ;

      plo = Caplets_Black2P(analys, voldate, cap, df_index, df_disc, vol,
                            cmadj, holi, NULL, &dr, &ddr) ;

      for (i = 0; i < GetPlanFill(vol->vol); i++)
        vol->vol->f64[i] += shock ;

      *dp = (phi - plo) / (2.0 * shock) ;
      if (risk->risk == SECOND_ORDER)
        *ddp = (phi + plo - 2.0 * total) / SQR(shock) ;

      break ;

    case KEY_DF:
    case KEY_BPV:

      /* $Duration / Convexity - Shock DF */

		/* PMSTA-22396 - SRIDHARA � 160502 */
      sdf_disc  = Disc_ShockRates(df_disc, 1.0, risk, holi) ;
      sdf_index = Disc_ShockRates(df_index, 1.0, risk, holi) ;

      phi = Caplets_Black2P(analys, voldate, cap, &sdf_index, &sdf_disc,
                            vol, cmadj, holi, NULL, &dr, &ddr) ;

      Free_PLANARRAY(sdf_disc.disc, 1) ;
      Free_PLANARRAY(sdf_index.disc, 1) ;

	  /* PMSTA-22396 - SRIDHARA � 160502 */
      sdf_disc  = Disc_ShockRates(df_disc, -1.0, risk, holi) ;
      sdf_index = Disc_ShockRates(df_index, -1.0, risk, holi) ;

      plo = Caplets_Black2P(analys, voldate, cap, &sdf_index, &sdf_disc,
                            vol, cmadj, holi, NULL, &dr, &ddr) ;

      Free_PLANARRAY(sdf_disc.disc, 1) ;
      Free_PLANARRAY(sdf_index.disc, 1) ;

      if (risk->key == KEY_BPV)
        shock = 1.0 ;

      *dp = (phi - plo) / (2.0 * shock) ;
      if (risk->risk == SECOND_ORDER && risk->key == KEY_DF)
        *ddp = (phi + plo - 2.0 * total) / SQR(shock) ;

      break ;

    case KEY_MATURITY:
    case KEY_MATURITY_BPV:

      /* Let time decay -> and reflect this in the dates of the DF's.
         Ie. we move the entire Term Structure of interest rates. */
		/* PMSTA-22396 - SRIDHARA � 160502 */
      sdf_disc  = Disc_Shock_Dates(df_disc, (INTI) shock, holi) ;
      sdf_index = Disc_Shock_Dates(df_index, (INTI) shock, holi) ;
      anld = Cldr_AddDays(analys, (INTL) shock, cal, holi) ;
      vold = Cldr_AddDays(voldate, (INTL) shock, vol_cal, holi) ;

      /* Note that we do not shift the vol, since we want to interpolate
         the same vols as before */

      plo = Caplets_Black2P(&anld, &vold, cap, &sdf_index, &sdf_disc, vol,
                            cmadj, holi, NULL, &dr, &ddr) ;

      /* Do not set ddp */
      *dp = (plo - total) / shock ;

      if (risk->key == KEY_MATURITY)
		  *dp *= Cldr_DaysPerYear(analys, analys, 0, cal, LAST, holi);  /* PMSTA-22396 - SRIDHARA � 160502 */

      /* Clean up */
      Free_PLANARRAY(sdf_disc.disc, 1) ;
      Free_PLANARRAY(sdf_index.disc, 1) ;
      break ;

    default:
      ;
  }

  return total ;
}


/*,,SOH,,
*************************************************************************
*
*               Caplets_Black2Delta()
*
*    interface  #include <cap.h>
*               FL64ARRAY Caplets_Black2Delta(DATESTR    *analys,
*                                             DATESTR    *voldate,
*                                             CAPLETS    *cap,
*                                             DISCFAC    *df_index,
*                                             DISCFAC    *df_disc,
*                                             VOL_STR    *vol,
*                                             CMCONVADJ  *cmadj,
*                                             HOLI_STR   *holi,
*                                             DELTASET   *ds) ;
*
*    general    The routine calculates the delta vector for a cap, floor*
*               or IRG using Black 76 pricing and a Zero Coupon Yield
*               Curve for bucketing.
*
*               The delta vector represents the price differences
*               invoked by the curve shocks.
*
*    input      DATESTR  *analys   Pointer to analysis date (NPV date)
*
*               DATESTR  *voldate  Vol calculated from this date
*
*               CAPLETS  *cap      The cap definition.
*
*               DISCFAC  *df_index Discount function setup for
*                                  finding forward rates.
*
*               DISCFAC  *df_disc  Discount function setup for discounting
*                                  future payments.
*
*               VOL_STR  *vol      Forward volatility structure.
*
*               CMCONVADJ *cmadj   Data for Convexity Adjustment
*                                  Use NULL if no adjustment
*
*               HOLI_STR *holi     Holiday set-up.
*
*               DELTASET *ds       Data for delta calculation.
*
*    output
*
*    returns    The deltavector allocated as:
*
*                         Alloc_FL64ARRAY(ds->nshock) ;
*
*    diagnostics
*
*    see also   Caplets_Black2Impl()
*               Caplets_GenrIRGARRAY()
*
*    wrapper    AP
*
*************************************************************************
,,EOH,,*/

FL64ARRAY Caplets_Black2Delta(DATESTR* analys,
                     DATESTR*    voldate,
                     CAPLETS*    cap,
                     DISCFAC*    df_index,
                     DISCFAC*    df_disc,
                     VOL_STR*    vol,
                     CMCONVADJ* cmadj,
                     HOLI_STR*   holi,
                     DELTASET*   ds)
{
    INTI      nirg, i ;
    FL64ARRAY dv ;
    FL64      p0, dum ;
    PLANARRAY old_index, old_disc, old ;
    DATESTR   fsprev, matur ;

    /* Initialise */
    old_index = df_index->disc ;
    old_disc  = df_disc->disc ;

    dv = Alloc_FL64ARRAY(ds->nshock) ;

    nirg = cap->count ;
    if (nirg <= 0)
        return dv ;

    /* The unshocked price */
    p0 = Caplets_Black2P(analys, voldate, cap, df_index, df_disc, vol, cmadj,
                         holi, NULL, &dum, &dum) ;

    /* Last relevant payday */
    matur = cap->irg[nirg - 1].fix_end ;
    if (Cldr_DateLT(&matur, &cap->irg[nirg - 1].pay_day) == True)
        matur = cap->irg[nirg - 1].pay_day ;

    matur = Cldr_TermUnit2Date(&matur, (INTI) (1.0 + cap->index.LIBORdur),
                               cap->index.LIBORunit, cap->cal, LAST, holi) ;

    for (i = 0; i < ds->nshock; i++)
    {
        if (ds->dfwhich == DF_BOTH)
        {
            fsprev = Disc_get_chgdate(NULL, old_index, &ds->shock[i]) ;
            fsprev = Disc_get_chgdate(&fsprev, old_disc, &ds->shock[i]) ;
        }
        else 
        {
            old = (ds->dfwhich == DF_CFLW ? old_index : old_disc) ;
            fsprev = Disc_get_chgdate(NULL, old, &ds->shock[i]) ;
        }

        if (fsprev.y > 0 && Cldr_DateLT(&matur, &fsprev) == False)
        {
            /* Use shocks in ds->shoch for both curves */
            if (ds->dfwhich == DF_BOTH)
                df_index->disc = df_disc->disc = &ds->shock[i] ;

            /* Use shocks in ds->shoch for cflw curve */
            else if (ds->dfwhich == DF_CFLW)
                df_index->disc = &ds->shock[i] ;

            /* Use shocks in ds->shoch for disc curve */
            else if (ds->dfwhich == DF_DISC)
                df_disc->disc = &ds->shock[i] ;
            
            dv[i] = Caplets_Black2P(analys, voldate, cap, df_index, df_disc,
                                    vol, cmadj, holi, NULL, &dum, &dum) ;
            dv[i] -= p0 ;

            if (ds->zero == True)
            {
                /* Find shocked Zero PV */
                if (ds->dfwhich == DF_CFLW)
					dv[i] /= Disc_DF2BPV(&ds->mid[i], df_index, old_index, holi);  /* PMSTA-22396 - SRIDHARA � 160502 */
                else
					dv[i] /= Disc_DF2BPV(&ds->mid[i], df_disc, old_disc, holi);  /* PMSTA-22396 - SRIDHARA � 160502 */
            }
        }
        else
            dv[i] = 0.0 ;
    }

    df_index->disc = old_index ;
    df_disc->disc  = old_disc ;

    return dv ;
}


/*,,SOH,,
*************************************************************************
*
*               Caplets_Black2P_Array()
*
*    interface  #include <cap.h>
*               FL64ARRAY Caplets_Black2P_Array(DATESTR    *analys,
*                                               DATESTR    *voldate,
*                                               CAPLETS    *cap,
*                                               DISCFAC    *df_index,
*                                               DISCFAC    *df_disc,
*                                               VOL_STR    *vol,
*                                               CMCONVADJ  *cmadj,
*                                               HOLI_STR   *holi,
*                                               FL64ARRAY  *forwfixp,
*                                               INTIARRAY  *caplngthp) ;
*
*    general    The routine computes the theoretical price for a
*               cap or floor using the Black 76 model for interest rate
*               options. In this routine the premiae of the individual
*               caplets are returned as an array.
*
*    input      DATESTR   *analys    Pointer to analysis date (NPV date)
*
*                                      df_disc->disc->day[0] <= analys
*
*               DATESTR   *voldate   Vol calculated from this date
*
*               CAPLETS   *cap       The cap definition.
*                                    cap->irg is the list of irg's.
*                                    The IRGARRAY can be generated
*                                    with Caplets_GenrIRGARRAY()
*
*               DISCFAC   *df_index  Discount function setup for
*                                    finding forward rates.
*
*               DISCFAC   *df_disc   Discount function setup for discounting
*                                    future payments.
*
*               VOL_STR   *vol       Forward rate vol.
*
*               CMCONVADJ *cmadj     Data for Convexity Adjustment
*                                    Use NULL if no adjustment
*
*               HOLI_STR  *holi      Holiday set-up.
*
*    output     FL64ARRAY *forwfixp  Forward fixings for each caplet
*
*               INTIARRAY *caplngthp Duration of each caplet
*
*    
*
*    returns    The individual prices of the caplet's as an array
*               allocated as Alloc_FL64ARRAY(cap->count) ;
*
*               
*    diagnostics
*
*    see also   Caplets_Black2Impl()
*               Caplets_GenrIRGARRAY()
*
*************************************************************************
,,EOH,,*/

FL64ARRAY Caplets_Black2P_Array(DATESTR* analys,
                     DATESTR*    voldate,
                     CAPLETS*    cap,
                     DISCFAC*    df_index,
                     DISCFAC*    df_disc,
                     VOL_STR*    vol,
                     CMCONVADJ*  cmadj,
                     HOLI_STR*   holi,
                     FL64ARRAY*  forwfixp,
                     INTIARRAY*  caplngthp)
{
    FL64ARRAY prem, dummyfl ;
    INTIARRAY dummyinti ;
    FL64      dum ;
    INTI      i ;
    CAPLETS   capl ;

    prem = Alloc_FL64ARRAY(cap->count) ;
    *forwfixp = Alloc_FL64ARRAY(cap->count) ;
    *caplngthp = Alloc_INTIARRAY(cap->count) ;
    dummyfl = Alloc_FL64ARRAY(1) ;
    dummyinti = Alloc_INTIARRAY(1) ;

    capl.count    = 1 ;
    capl.cal      = cap->cal ;
    capl.eom      = cap->eom ;
    capl.qot      = cap->qot ;
    capl.freq     = cap->freq ;
    capl.index    = cap->index ;
    capl.oadd     = cap->oadd ;
    capl.bini     = cap->bini ;
    capl.ctp      = cap->ctp ;
    capl.method   = cap->method ;
    capl.compfreq = cap->compfreq ;

    /* Caplets_Black2P_int is called with only one caplet whence dummyfl
       and dummyinti contains values for i'th caplet at position 0!*/

    for (i = 0; i < cap->count; i++)
    {
        capl.irg = &cap->irg[i] ;
        prem[i] = Caplets_Black2P_int(analys, voldate, &capl, df_index,
                                  df_disc, vol, cmadj, holi, NULL,
                                  &dum, &dum, dummyfl, dummyinti) ;
        (*forwfixp)[i] = dummyfl[0];
        (*caplngthp)[i] = dummyinti[0];
    }
    Free_FL64ARRAY(dummyfl);
    Free_INTIARRAY(dummyinti);

    return prem ;
}


/*,,SOH,,
*************************************************************************
*
*               Caplets_Black2Intr()
*
*    interface  #include <cap.h>
*               FL64ARRAY Caplets_Black2Intr(DATESTR    *analys,
*                                            CAPLETS    *cap,
*                                            DISCFAC    *df_index,
*                                            DISCFAC    *df_disc,
*                                            HOLI_STR   *holi) ;
*
*    general    Caplets_Black2Intr() computes the intrinsic values
*               of caps and/or floors.
*
*               All adjustments for businessdays must be performed prior
*               to calling this function - eg. when generating the IRG's
*               with Caplets_GenrIRGARRAY().
*
*               Note that negative intrinsic values may be returned
*               by the function.
*
*               For CMT/CMS caps no convexity adjustment is performed
*               in this routine.
*
*    input      DATESTR   *analys   Pointer to analysis date
*
*               CAPLETS   *cap      The cap definition.
*                                   cap->irg is the list of irg's.
*                                   The IRGARRAY can be generated
*                                   with Caplets_GenrIRGARRAY()
*
*               DISCFAC   *df_index Discount function setup for getting
*                                   forward rates.
*
*               DISCFAC   *df_disc  Discount function setup for discounting
*                                   future payments.
*
*               HOLI_STR  *holi     Holiday set-up.
*
*    output
*
*    returns    Pointer to a list of individual intrinsic values of the
*               IRG's. Allocated in this routine as:
*               Alloc_FL64ARRAY(cap->count)
*
*    diagnostics
*
*    see also   Caplets_Black2Impl()
*               Caplets_Black2P()
*               Caplets_GenrIRGARRAY()
*
*************************************************************************
,,EOH,,*/

FL64ARRAY Caplets_Black2Intr(DATESTR* analys,
                             CAPLETS*    cap,
                             DISCFAC*    df_index,
                             DISCFAC*    df_disc,
                             HOLI_STR*   holi)
{
    FL64      ca, q_dsc, f_rate ;
    FL64ARRAY intr ;
    INTI      nirg, i ;
    DATESTR   rend ;
    IRGARRAY  irg ;
    CALCONV   cal ;
    EOMCONV   eom ;
    QOTCONV   qot ;
    BOOLE     ok ;
    RATEINDEX rindex ;

    /* Initialise */
    irg   = cap->irg ;
    nirg  = cap->count ;
    cal   = cap->cal ;
    eom   = cap->eom ;
    qot   = cap->qot ;
    intr  = Alloc_FL64ARRAY(nirg) ;

    /* Compute dates - the start date of each irg - strikes, and f_rates */
    for (i = 0 ; i < nirg ; i++)
    {
        if (Cldr_DateLE(&irg[i].pay_day, analys) == True)
            intr[i] = 0.0 ;

        else if (Cldr_DateLT(&irg[i].fix_start, analys) == True &&
                 Cldr_DateLT(analys, &irg[i].pay_day) == True)
				 intr[i] = Caplets_IRG_Payout(cap, i, holi);  /* PMSTA-22396 - SRIDHARA � 160502 */
        else
        {
            /* Find the fictitious end of the forward rate (CMT) */
            if (cap_isLIBORplain(&cap->index, cal, eom, cap->freq) == False)
            {
                /* avoid fractional years (to suppress calendar dependence)*/
                rindex =  cap->index ;
                if (rindex.LIBORunit == YEARS) 
                {
                  rindex.LIBORdur *= 12.0 ;
                  rindex.LIBORunit = MONTHS ;
                }
                rend = Cldr_Term2Date(&irg[i].fix_start, rindex.LIBORdur,
                                      rindex.LIBORunit, cal, eom) ;
                rend = Cldr_NextBusinessDate(&rend, holi) ;
            }
            else
                rend = irg[i].fix_end ;

            /* Find forward rate for IRG valuation  */
            f_rate = SwapFl_DF2ForwRate(&irg[i].fix_start, &rend,
                                        &irg[i].pay_day, NULL, &cap->index,
                                        False, df_index, df_disc,
										NULL, &ca, holi);  /* PMSTA-22396 - SRIDHARA � 160502 */
            f_rate  -= irg[i].strike  ;
            intr[i]  = irg[i].size *
                       (irg[i].type == CALL ? f_rate : -f_rate) / 100.0 ;

            /* Correct for quoting convention */
			/* PMSTA-22396 - SRIDHARA � 160502 */
            q_dsc = Disc_Interpolation(&irg[i].pay_day, df_disc, holi) ;
            ok    = Disc_forwval(df_disc, analys, &q_dsc, holi) ;
            if (ok == False)
                continue ;

			/* PMSTA-22396 - SRIDHARA � 160502 */
            intr[i]  = MM_AnnForw2Qot(q_dsc, &irg[i].fix_start, &irg[i].fix_end,
                                      cal, qot, intr[i], holi) ;
        }
    }

    return intr ;
}


/*,,SOH,,
*************************************************************************
*
*               Caplets_GenrIRGARRAY()
*
*    interface  #include <cap.h>
*               IRGARRAY Caplets_GenrIRGARRAY(PAYDAYDEF  *pday,
*                                             OPTTYPE    type,
*                                             FL64       strike,
*                                             FL64       size,
*                                             HOLI_STR   *holi,
*                                             INTI       *nirg) ;
*
*    general    Caplets_GenrIRGARRAY() generates a list of IRG's or caplet*
*               floorlet's corresponding to the input spec.
*
*               The IRG's are set as back-to-back options. With
*               pay_day equal to fix_end.
*
*               When returning the IRGARRAY (irg) contains the details
*               needed for each IRG and all dates suitable corrected
*               for businessdays. This IRGARRAY can then be further
*               processed by Caplets_Black2P() etc.
*
*               The first (pday->first) date can be today or the first
*               IRG start date. The function simply delivers the IRG's
*               with starting date today or after today.
*
*               irg->LIBORfix is set to 0.0.
*
*    input      PAYDAYDEF *pday   The conventions for IRG-date
*                                 generation. pday->first is the first
*                                 fixing date and pday->last is the last
*                                 settlement date of the cap.
*                                 freq is the reset frequency of IRG's.
*                                 Eq. SEMIANNUALLY for 6 month IRG/FRA's
*
*               OPTTYPE   type    The type of IRG, CALL for a cap and
*                                 PUT for floor's.
*
*               FL64      strike  The strike rate (annual %).
*
*               FL64      size    The contract size
*
*               HOLI_STR  *holi   Container for data on business
*                                 day convention and non-week-end
*                                 holidays.
*
*    output     INTI      *nirg   Pointer to number of IRG's.
*
*    returns    Pointer to the list of back-to-back IRG's.
*               IRGARRAY is allocated as: Alloc_IRGARRAY(*nirg)
*
*    diagnostics
*
*    see also   Caplets_Black2Impl()
*               Caplets_Black2P()
*               Caplets_HWCF2P()
*
*    wrapper    AP
*
*************************************************************************
,,EOH,,*/


IRGARRAY Caplets_GenrIRGARRAY(PAYDAYDEF* pday,
                          OPTTYPE  type,
                          FL64     strike,
                          FL64     size,
                          HOLI_STR* holi,
                          INTI*     nirg)
{
    INTI      i ;
    DATEARRAY days ;
    IRGARRAY  irg ;

    /* First get the irg dates */
    days = Cflw_Paydays(pday, holi, nirg) ;
    irg  = Alloc_IRGARRAY(*nirg - 1);

    /* Note that the last day is the end date of the last irg */
    for (i = 0 ; i < *nirg - 1 ; i++)
      irg[i] = Set_IRG_STR(type, strike, &days[i], &days[i + 1],
        NULL, NULL, NULL, size, 0.0) ;

    --*nirg ;

    /* Clean up */
    Free_DATEARRAY(days) ;

    return irg ;
}


/*,,SOH,,
*************************************************************************
*
*               Caplets_Black2Impl()
*
*    interface  #include <cap.h>
*               BOOLE Caplets_Black2Impl(DATESTR    *analys,
*                                        DATESTR    *voldate,
*                                        FL64       price,
*                                        CAPLETS    *cap,
*                                        DISCFAC    *df_index,
*                                        DISCFAC    *df_disc,
*                                        VOL_STR    *vol1,
*                                        CMCONVADJ  *cmadj,
*                                        HOLI_STR   *holi,
*                                        KEYCONV    what,
*                                        ITERCTRL   *ictrl,
*                                        FL64       *res) ;
*
*    general    The function calculates the implied parameter specified
*               specified by what, using the Black formula for interest
*               rate options.
*
*               The following implied ratios can be found:
*
*                   what                 implied
*                   ----                 -------
*                   KEY_VOL              Forward Volatility (FORWVOL)
*                   KEY_STRIKE           Strike Rate
*                   KEY_SIZE             Contract Size
*                   KEY_GAP              Gap
*
*               Using KEY_GAP can be used to find the contingent premium*
*               for CONTINGENT PREMIUM options (Pay Later options), that*
*               are essentially Gap Options. Use pv = 0 for this
*               purpose.
*
*               The implied volatility is delivered as the forward vola-*
*               tility (and not forward-forward vol.).
*
*               All adjustments for businessdays must be performed prior*
*               to calling this function - eg. when generating the IRG's*
*               with Caplets_GenrIRGARRAY().
*
*               The function encounters cases where no solution can
*               be found. Info on this is returned as a False flag.
*
*    input      DATESTR   *analys   Pointer to analysis date (NPV date)
*
*                                      df_disc->disc->day[0] <= analys
*
*               DATESTR   *voldate  Vol calculated from this date
*
*               FL64      price     Market price to be matched
*
*               CAPLETS   *cap      The cap definition.
*
*               DISCFAC   *df_index Discount function setup for getting
*                                   forward rates.
*
*               DISCFAC   *df_disc  Discount function setup for
*                                   discounting future payments.
*
*               VOL_STR   *vol1     Forward volatility structure.
*                                   Only used if what is not KEY_VOL.
*
*               CMCONVADJ *cmadj    Data for Convexity Adjustment
*                                   Use NULL if no adjustment
*
*               HOLI_STR  *holi     Holiday set-up.
*
*               KEYCONV   what      What ratios ? KEY_VOL, KEY_SIZE or
*                                   KEY_STRIKE
*
*               ITERCTRL  *ictrl    Iteration control variable.
*                                   Use defaults whenever possible.
*
*    output     FL64      *res      The implied ratio
*                                   Only set if all is OK.
*
*    returns    True if all is OK, False if not.
*
*    diagnostics
*
*    see also   Caplets_Black2P()
*               Caplets_GenrIRGARRAY()
*
*    wrapper    AP
*
*************************************************************************
,,EOH,,*/

BOOLE Caplets_Black2Impl(DATESTR* analys,
                 DATESTR*   voldate,
                 FL64      price,
                 CAPLETS*   cap,
                 DISCFAC*   df_index,
                 DISCFAC*   df_disc,
                 VOL_STR*   vol1,
                 CMCONVADJ* cmadj,
                 HOLI_STR*  holi,
                 KEYCONV   what,
                 ITERCTRL*  ictrl,
                 FL64*      res)
{
    INTI      i ;
    FL64      shock, f, f1, rts, dum ;
    BOOLE     ok ;
    VOL_STR   vol ;
    PLANARRAY tmp_vol ;
    OPTADD    oadd ;
    RISKSET   risk ;
    BLCKINT   blck_data ;
    ITERCTRL  ctrl ;
    NR_ERR    err ;

    *res = 0.0 ;
    ok = True ;

    if (what == KEY_VOL)
    {
        tmp_vol = Alloc_PLANARRAY(1, 1) ;
        vol = Set_VOL_STR(tmp_vol, vol1->cal, FORWVOL, vol1->iconv);
    }
    else
    {
        tmp_vol = Alloc_PLANARRAY(1, GetPlanFill(vol1->vol)) ;

        for (i = 0 ; i < GetPlanFill(vol1->vol); i++)
            Cldr_InsertInPlan(&vol1->vol->day[i], vol1->vol->f64[i],
                                tmp_vol, True) ;
        vol = Set_VOL_STR(tmp_vol, vol1->cal, vol1->vc, vol1->iconv);
    }

    oadd = cap->oadd ;

    /* implied contingent premium can be done with closed form */
    if (cap->oadd == CONTPREM && what == KEY_GAP)
    {
        /* dummy RISKSET */
        risk = Set_RISKSET(KEY_DF, ZERO_ORDER, 0.0, COMPOUND, ANNUALLY,
                          NULL, True) ;

        /* get vanilla price */
        cap->oadd = NO_OPTADD ;
        f = Caplets_Black2P(analys, voldate, cap, df_index, df_disc, vol1, 
          cmadj, holi, &risk, &dum, &dum) ;

        /* get price of unit pay-off digital */
        cap->oadd = BINARY ;
        cap->bini.poff.poff  = OP_BINARY ;
        cap->bini.poff.gap   = 0.01 ;
        cap->bini.poff.scale = 0.0 ;
        cap->bini.dcadj      = False ;
        rts = cap->irg[0].size / 10000.0 ;
        for (i = 0; rts != 0.0 && i < cap->count; i++)
          cap->irg[i].size /= rts ;

        f1 = Caplets_Black2P(analys, voldate, cap, df_index, df_disc, vol1, 
          cmadj, holi, &risk, &dum, &dum) ;

        /* clean up */
        cap->oadd = CONTPREM ;
        for (i = 0; i < cap->count; i++)
          cap->irg[i].size *= rts ;

        /* free */
        Free_PLANARRAY(vol.vol, 1) ;
     
        /* compute contingent premium */
        if (f1 > 0.0)
        {
          *res = (f - price) / f1 ;
          return True ;
        }
        else
          return False ;
    }

    /* Initialize for Newton-Raphson. */
    shock = (ictrl->shock <= 0.0 ?   IRG_EPS : ictrl->shock) ;
    blck_data = Blck_SetBLCKINT(analys, voldate, price, cap, NULL, df_index,
      df_disc, 0.0, &vol, cmadj, holi, NULL, what, shock) ;
    Blck_SetITERCTRL(ictrl, what, &blck_data, &ctrl, holi) ;   /* PMSTA-29444 - SRIDHARA - 050318 */
    
    err = Newton_Raphson(&Blck_NewtonRaphson, &blck_data, &ctrl, 
		res, holi);   /* PMSTA-22396 - SRIDHARA � 160502 */
    ok = (err == NR_ROOT_FOUND ? True : False) ;

    if (oadd == CONTPREM)
        cap->oadd = CONTPREM ;

    Free_PLANARRAY(vol.vol, 1) ;

    return ok ;
}


/*
..
*/

void Caplets_SetImpl(FL64   rts,
                     IRGARRAY  irg,
                     BINARYINF* bini,
                     INTI      nirg,
                     VOL_STR*   vol,
                     KEYCONV   what)
{
    INTI    i ;

    if (what == KEY_VOL)
        Cldr_InsertInPlan(&irg[nirg - 1].fix_start, rts, vol->vol, True) ;

    else if (what == KEY_STRIKE)
    {
        for (i = 0 ; i < nirg ; i++)
            irg[i].strike = rts ;
    }

    else if (what == KEY_SIZE)
    {
        for (i = 0 ; i < nirg ; i++)
            irg[i].size = rts ;
    }

    else if (what == KEY_GAP)
    {
        for (i = 0 ; i < nirg ; i++)
            bini->poff.gap = rts ;
    }
}

/*
..
*/

BOOLE cap_isLIBORplain(RATEINDEX* index,
                       CALCONV   cal,
                       EOMCONV   eom,
                       PMTFREQ   cap_freq)
{
    BOOLE   plain ;
    INTI    mfreq ;
    DATESTR start, date, date1 ;
    RATEINDEX rindex ;

    start = Cldr_YMD2Datestr((YYYYMMDD) 19900101) ;
    mfreq = Cflw_MonthsBetweenPayments(cap_freq) ;  /* Cap reset frequency */

    /* avoid fractional years (to suppress calendar dependence)*/
    rindex =  *index ;
    if (rindex.LIBORunit == YEARS) 
    {
      rindex.LIBORdur *= 12.0 ;
      rindex.LIBORunit = MONTHS ;
    }

    date1 = Cldr_Term2Date(&start, rindex.LIBORdur, rindex.LIBORunit, cal, eom);
    date  = Cldr_AddMonths(&start, mfreq, eom) ;

    if (Cldr_DateEQ(&date1, &date) == True && 
        index->LIBORfreq == NO_FREQUENCY &&
        index->LIBORtype != PARYIELD)
        plain = True ;
    else
        plain = False ;

    return plain ;
}

/*
..
*/

void Blck_SetITERCTRL(ITERCTRL*  ictrl,
                         KEYCONV    what,
                         BLCKINT*   blck_data,
                         ITERCTRL*  ctrl,
						 HOLI_STR*  holi)
{
    BOOLE ok ;

    Init_ITERCTRL(ctrl) ; ;

    /* Set uninitialized initial guess. */
    if (ictrl->use_init_guess == False)
    {
      if ((ictrl->use_lower) && (ictrl->use_upper))
        ctrl->init_guess = 0.5 * (ictrl->upper + ictrl->lower) ;
      else 
        ctrl->init_guess = IRG_GUESS ;
      ctrl->use_init_guess = True ;
    }
    else
      ctrl->init_guess = ictrl->init_guess ;

    /* Set uninitialized boundaries for iteration. */
    if (ictrl->use_lower) 
      ctrl->lower = GETMIN(ictrl->lower, ctrl->init_guess) ;
    else
    {
      ctrl->lower = IRG_LOWER ;
      ctrl->lower = GETMIN(ctrl->lower, ctrl->init_guess / 1.1)  ;
      ctrl->use_lower = True ;
    }

    if (ictrl->use_upper)
      ctrl->upper = GETMAX(ictrl->upper, ctrl->init_guess) ;
    else
    {
      if (what == KEY_SIZE)
        ctrl->upper = IRG_UPPER_SIZE ;
      else if (what == KEY_VOL)
        ctrl->upper = IRG_UPPER_VOL ;
      else
        ctrl->upper = IRG_UPPER ;

      ctrl->upper = GETMAX(ctrl->upper, ctrl->init_guess * 1.1) ;
      ctrl->use_upper = True ;
    }

    if (ictrl->use_lower == False || ictrl->use_upper == False)
      ok = Math_PosRootBracket(&Blck_NewtonRaphson, blck_data, ctrl,
        &ctrl->lower, &ctrl->upper, holi) ;   /* PMSTA-29444 - SRIDHARA - 050318 */

    ctrl->maxiter    = (ictrl->maxiter < 0 ? IRG_MAXIT : ictrl->maxiter) ;
    ctrl->damp       = (ictrl->damp < 0.0  ?  IRG_DAMP : ictrl->damp) ;
    ctrl->acc        = (ictrl->acc < 0.0   ?   IRG_ACC : ictrl->acc) ;
    ctrl->what_acc   = (ictrl->what_acc < 0   ? 1 : ictrl->what_acc) ;
    ctrl->gfreq      = ictrl->gfreq ;
    ctrl->bisec      = (ictrl->bisec < 0 ? 1 : ictrl->bisec) ;
    ctrl->shock      = 0.0 ; /* no multiple roots checking */
}

/*
..
*/

BLCKINT Blck_SetBLCKINT(DATESTR*  analys,
                        DATESTR*     voldate,
                        FL64         price,
                        CAPLETS*     cap,
                        SWAPTION*    ncsw,
                        DISCFAC*     df_index,
                        DISCFAC*     df_disc,
                        FL64         vol,
                        VOL_STR*     volstr,
                        CMCONVADJ*   cmadj,
                        HOLI_STR*    holi,
                        B76SWTM*     b76t,
                        KEYCONV      what,
                        FL64         shock)
{
  BLCKINT blck_data ;

  blck_data.analys = analys ;
  blck_data.voldate = voldate ;
  blck_data.price = price ;
  blck_data.cap = cap ;
  blck_data.ncsw = ncsw ;
  blck_data.df_index = df_index ;
  blck_data.df_disc = df_disc ;
  blck_data.vol = vol ;
  blck_data.volstr = volstr ;
  blck_data.cmadj = cmadj ;
  blck_data.holi = holi ;
  blck_data.b76t = b76t ;  
  blck_data.what = what ;
  blck_data.shock = shock ;

  return blck_data ;
}

/*
..
*/

void Blck_GetBLCKINT(BLCKINT*     blck_data,
                        DATESTR**     analys,
                        DATESTR**     voldate,
                        FL64*         price,
                        CAPLETS**     cap,
                        SWAPTION**    ncsw,
                        DISCFAC**     df_index,
                        DISCFAC**     df_disc,
                        FL64*         vol,
                        VOL_STR**     volstr,
                        CMCONVADJ**   cmadj,
                        HOLI_STR**    holi,
                        B76SWTM**     b76t,
                        KEYCONV*      what,
                        FL64*         shock)     
{
  *analys  = blck_data->analys ;
  *voldate = blck_data->voldate ;
  *price = blck_data->price ;
  *cap = blck_data->cap ;
  *ncsw = blck_data->ncsw ;
  *df_index = blck_data->df_index ;
  *df_disc = blck_data->df_disc ;
  *vol = blck_data->vol ;
  *volstr = blck_data->volstr ;
  *cmadj = blck_data->cmadj ;
  *holi = blck_data->holi ;
  *b76t = blck_data->b76t ;  
  *what = blck_data->what ;
  *shock = blck_data->shock ;
}

/*
..
*/

BOOLE Blck_NewtonRaphson(FL64  x, 
                               void*  y,
                               BOOLE  grad,
                               FL64*  fx, 
                               FL64*  dfx,
							   void*  hol)
{
  DATESTR    *analys, *voldate ;
  CAPLETS    *cap ;
  SWAPTION   *ncsw ;
  DISCFAC    *df_index, *df_disc ;
  FL64       price, vol, shock, fx1, dum ;
  VOL_STR    *volstr ;
  CMCONVADJ  *cmadj ;
  HOLI_STR   *holi = (HOLI_STR *)hol;   /* PMSTA-29444 - SRIDHARA - 050318 */
  B76SWTM    *b76t ;
  KEYCONV    what ;
  BOOLE      ok ;

  /* Initialize */
  ok = True;

  /* Get data from y */
  Blck_GetBLCKINT((BLCKINT*)y, &analys, &voldate, &price, &cap, &ncsw,
    &df_index, &df_disc, &vol, &volstr, &cmadj, &holi, &b76t, &what, &shock);
  shock = (shock <= 0.0 ? IRG_EPS : shock) ;
  
  /* Compute fx */
  if (ncsw == NULL) 
  {
    Caplets_SetImpl(x, cap->irg, &cap->bini, cap->count, volstr, what) ;
    *fx  = Caplets_Black2P(analys, voldate, cap, df_index, df_disc, volstr,
      cmadj, holi, NULL, &dum, &dum) ;
  }
  else
  {
    Swaption_SetImpl(x, &vol, &ncsw->fix.fix_rate, what) ;
    ok = Swaption_Black2P(analys, voldate, vol, ncsw, df_index, df_disc, cmadj,
      holi, b76t, NULL, fx, &dum, &dum) ;
  }

  *fx -= price;

  /* Calculate gradient */
  if (grad == True)
  {
    if (ncsw == NULL)
    {
      Caplets_SetImpl(x + shock, cap->irg, &cap->bini, cap->count, volstr,
        what) ;
      fx1  = Caplets_Black2P(analys, voldate, cap, df_index, df_disc, volstr,
        cmadj, holi, NULL, &dum, &dum) ;
      Caplets_SetImpl(x, cap->irg, &cap->bini, cap->count, volstr, what) ;
    }
    else
    {
      Swaption_SetImpl(x + shock, &vol, &ncsw->fix.fix_rate, what) ;
      ok = Swaption_Black2P(analys, voldate, vol, ncsw, df_index, df_disc,
        cmadj, holi, b76t, NULL, &fx1, &dum, &dum) ;
      Swaption_SetImpl(x, &vol, &ncsw->fix.fix_rate, what) ;
    }

    fx1 -= price;
    *dfx = (fx1 - *fx) / shock;
  }

  return ok;
}

/*
..
*/

FL64 Caplets_IRG_Payout(CAPLETS* capl, INTI i, HOLI_STR *holi)  /* PMSTA-22396 - SRIDHARA � 160502 */
{
    FL64       size, gap, scale, strike, LIBOR, period, p ;
    OPTTYPE    type ;
    PAYOFF     poff ;
    OPTADD     oadd ;
    CALCONV    cal ;
    COMPMETHOD method ;
    INTI       mfreq, mcomp ;
    BOOLE      dcadj ; /* day count fraction adjustment for caplets */

    p = 0.0 ;

    /* 1.0 Set the compounding dates */
    cal = capl->cal;
    method = capl->method ;
    mfreq = Cflw_MonthsBetweenPayments(capl->freq) ;
    mcomp = Cflw_MonthsBetweenPayments(capl->compfreq) ;

    /* This if-else statement was copied from Caplets_Black2P() */
    if (mcomp >= mfreq)
    {
        mcomp = mfreq ;
        if (method != DECOMPOUND)
            method = NONE ;
    }
    else
    {
        /* Avoid silly situations */
        if (method != FLAT && method != REGCOMPOUND && method != TAM)
            mcomp = mfreq ;
    }

    /* Handle this in a simple way */
    oadd = capl->oadd ;
    if (capl->oadd == CONTPREM)
    {
        capl->oadd = BINARY ;
        capl->bini.poff.poff  = OP_GAP ;
        /* Do not day count period fraction adjust the gap. */
        capl->bini.dcadj = False;
        capl->bini.poff.gap   = capl->ctp.prem ;
        capl->bini.poff.scale = 1.0 ;
    }

    /* Compounding/Decompounding of strike */
    switch (method)
    {
    case DECOMPOUND:
		/* PMSTA-22396 - SRIDHARA � 160502 */
        LIBOR = Cflw_Decompound(capl->irg[i].LIBORfix, mcomp, 
                    True, EPR_PER, NULL, NULL, cal, holi);
        strike = Cflw_Decompound(capl->irg[i].strike, mfreq, 
                    True, EPR_PER, NULL, NULL, cal, holi);
        break;
    default:
        /* No compounding - do nothing */
        LIBOR  = capl->irg[i].LIBORfix ;
        strike = capl->irg[i].strike ;
        break;
    }

    size   = capl->irg[i].size ;
    type   = capl->irg[i].type ;

    scale  = capl->bini.poff.scale ;
    gap    = capl->bini.poff.gap ;
    poff   = capl->bini.poff.poff ;
    dcadj  = capl->bini.dcadj ;

    period = Cldr_TermBetweenDates(&capl->irg[i].period_start,
               &capl->irg[i].period_end, 0, capl->cal, LAST, holi);   /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */

    /* Adjust for Yield quote on Bill */
    size = Caplets_IRG_Notional(capl, i, holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */

    if (capl->oadd != BINARY || poff == OP_VANILLA)
    {
        if (capl->oadd == ASIAN && capl->asian.avgrt == False)
            strike = capl->asian.last_avg ;
        else if (capl->oadd == ASIAN && capl->asian.avgrt == True)
            LIBOR = capl->asian.last_avg ;

        if (type == CALL)
            p = GETMAX((LIBOR - strike), 0.0) * period * size ;
        else if (type == PUT)
            p = GETMAX((strike - LIBOR), 0.0) * period * size ;
        else if (type == STRADDLE)
            p = GETMAX((LIBOR - strike), 0.0) * period * size +
                GETMAX((strike - LIBOR), 0.0) * period * size ;
    }
    else if (capl->oadd == BINARY && poff == OP_BINARY)
    {
        if (type == CALL && LIBOR >= strike)
            p = gap * size ;
        else if (type == PUT && LIBOR <= strike)
            p = gap * size ;

        if (dcadj)
            p *= period ;
    }
    else if (capl->oadd == BINARY && poff == OP_ASSETON)
    {
        if (type == CALL && LIBOR >= strike)
            p = scale * LIBOR * period * size ;
        else if (type == PUT && LIBOR <= strike)
            p = scale * LIBOR * period * size ;
    }
    else if (capl->oadd == BINARY && poff == OP_GAP)
    {
        if (type == CALL && LIBOR >= strike)
            p = (LIBOR - strike - gap) * period * size ;
        else if (type == PUT && LIBOR <= strike)
            p = (strike - LIBOR - gap) * period * size ;
    }
/*
printf("Fix: %lf, X: %5lf, T: %lf ", LIBOR, strike, period);
*/
    /* Set values back */
    if (capl->oadd == CONTPREM)
        capl->oadd = oadd ;

    return p ;
}


/*
..
*/

OPTINT caplets_set_OPTINT(DATESTR* analys, 
                             DATESTR* vold, 
                             OPTTYPE type, 
                             FL64 x, 
                             PREMIUMTYPE ptype, 
                             CAPLETS* capl, 
                             INTI i, 
                             CALCONV cal,
							 CALCONV vol_cal, 
							 HOLI_STR* holi)  /* PMSTA-22396 - SRIDHARA � 160502 */
{
    OPTINT opt ;

    opt.analys  = *analys ;
    opt.voldate = *vold ;
    opt.type    = type ;
    opt.e       = x ;

	/* PMSTA-22396 - SRIDHARA � 160502 */
    opt.tvol = Cldr_TermBetweenDates(vold, &capl->irg[i].fix_start, 0,
                                     vol_cal, LAST, holi) ;
    opt.tfix = Cldr_TermBetweenDates(analys, &capl->irg[i].fix_start, 0,
                                     cal, LAST, holi) ;
    /* Not used */
    opt.t    = Cldr_TermBetweenDates(analys, &capl->irg[i].fix_start, 0,
                                     cal, LAST, holi) ;
    opt.ptype = ptype ;
    opt.cal   = cal ;

    switch (capl->oadd)
    {
        case NO_OPTADD:
        default:
            opt.oadd = NO_OPTADD ;
            break ;

        case BINARY:
            opt.oadd = BINARY ;
            opt.bini = Set_BINARYINF(&capl->bini.poff,
                                     capl->bini.dcadj) ;
            break ;

        case CONTPREM:
            opt.oadd = BINARY ;
            opt.bini.poff = Set_PAYOFFINF(OP_GAP, capl->ctp.prem, 1.0) ;
            opt.bini.dcadj = False;
            break ;

        case ASIAN:
            opt.oadd = ASIAN ;
			/* PMSTA-22396 - SRIDHARA � 160502 */
            opt.tvol = Cldr_TermBetweenDates(vold, &capl->irg[i].fix_end, 0,
                                             vol_cal, LAST, holi) ;
            opt.tfix = Cldr_TermBetweenDates(analys, &capl->irg[i].fix_end, 0,
                                             cal, LAST, holi) ;
            opt.asian = Set_ASIANINF(&capl->irg[i].fix_start, 
                                     &capl->irg[i].fix_end, 
                                     capl->asian.num_avg,
                                     capl->asian.curr_avg,
                                     capl->asian.avgrt, capl->asian.last_avg) ;
            break ;

        case RESET:
            opt.oadd  = RESET ;
            opt.reset = Set_RESETINF(capl->reset.spread, capl->reset.nfirst,
                                     capl->reset.nfreq,
                                     capl->reset.delayfix,
                                     capl->reset.spread_low,
                                     capl->reset.spread_up) ;
            break ;
    }

    return opt ;
}


/*
..
*/

INTIARRAY Caplets_Genr_Index(CAPLETSARRAY cap, INTI ncap)
{
    INTIARRAY index ;
    FL64ARRAY matur ;
    INTI      nirg, i ;

    matur = Alloc_FL64ARRAY(ncap) ;

    for (i = 0; i < ncap; i++)
    {
        nirg     = cap[i].count ;
        if (nirg > 0)
            matur[i] = (FL64) Cldr_Datestr2YMD(&cap[i].irg[nirg - 1].fix_end) ;
        else
            matur[i] = 0.0 ;
    }

    index = Scutl_Indexx_FL64(ncap, matur, ASCENDING) ;

    Free_FL64ARRAY(matur) ;

    return index ;
}


/*
..
*/

FL64 Caplets_Black2P_Barr(DATESTR* analys,
                 DATESTR*   voldate,
                 CAPLETS*   cap,
                 DISCFAC*   df_index,
                 DISCFAC*   df_disc,
                 VOL_STR*   vol,
                 CMCONVADJ* cmadj,
                 HOLI_STR*  holi,
                 RISKSET*   risk,
                 FL64*      dp,
                 FL64*      ddp)
{
    FL64    R, G, B, X, p, p1, dp1, ddp1, p2, dp2, ddp2, p3, dp3, ddp3,
            f1, f2 ;
    CAPLETS capl ;
    INTI    i ;
    IRG_STR irg ;
    OPTTYPE type, rtype = CALL;

    /* warning avoidance */
    f1 = f2 = 0.0 ;

    p = *dp = *ddp = 0.0 ;
    if (cap->oadd != SHARKFIN || cap->count < 1)
        return p ;

    /* Initialise */
    capl = Set_CAPLETS(1, cap->cal, cap->eom, cap->qot, cap->freq,
                       &irg, &cap->index, cap->method,
                       cap->compfreq) ;
    B    = cap->sfin.barrier ;
    R    = cap->sfin.rebate ;

    /* Decompose this security into its basic components */
    for (i = 0 ; i < cap->count; i++)
    {
        type = cap->irg[i].type ;
        X    = cap->irg[i].strike ;

        /* Handle straddles separately */
        if (type == STRADDLE)
        {
            capl.sfin = Set_SHARKFININF(cap->sfin.btype, cap->sfin.barrier,
                                        cap->sfin.rebate, &cap->sfin.poff) ;
            capl.oadd = SHARKFIN ;
            irg = Set_IRG_STR(CALL, cap->irg[i].strike, &cap->irg[i].fix_start,
                              &cap->irg[i].fix_end, &cap->irg[i].pay_day, 
                              &cap->irg[i].period_start, 
                              &cap->irg[i].period_end, cap->irg[i].size, 
                              cap->irg[i].LIBORfix) ;
            p1 = Caplets_Black2P_Barr(analys, voldate, &capl, df_index, df_disc,
                                      vol, cmadj, holi, risk, &dp1, &ddp1) ;
            irg.type = PUT ;
            p2 = Caplets_Black2P_Barr(analys, voldate, &capl, df_index, df_disc,
                                      vol, cmadj, holi, risk, &dp2, &ddp2) ;

            p    += p1 + p2 ;
            *dp  += dp1 + dp2 ;
            *ddp += ddp1 + ddp2 ;
            continue ;
        }

        /* Find combination factors */
        if (cap->sfin.btype == UP_OUT)
        {
            rtype = CALL ;
            if (type == CALL)
            {
                f1 = (B > X) ? 1.0 : 0.0 ;
                f2 = (B > X) ? -1.0 : 0.0 ;
            }

            else if (type == PUT)
            {
                f1 = (B > X) ? 1.0 : 0.0 ;
                f2 = (B > X) ? 0.0 : 1.0 ;
            }
        }

        else if (cap->sfin.btype == UP_IN)
        {
            rtype = PUT ;
            if (type == CALL)
            {
                f1 = (B > X) ? 0.0 : 1.0 ;
                f2 = (B > X) ? 1.0 : 0.0 ;
            }

            else if (type == PUT)
            {
                f1 = (B > X) ? 0.0 : 1.0 ;
                f2 = (B > X) ? 0.0 : -1.0 ;
            }
        }

        else if (cap->sfin.btype == DOWN_OUT)
        {
            rtype = PUT ;
            if (type == CALL)
            {
                f1 = (B > X) ? 0.0 : 1.0 ;
                f2 = (B > X) ? 1.0 : 0.0 ;
            }

            else if (type == PUT)
            {
                f1 = (B > X) ? 0.0 : 1.0 ;
                f2 = (B > X) ? 0.0 : -1.0 ;
            }
        }

        else if (cap->sfin.btype == DOWN_IN)
        {
            rtype = CALL ;
            if (type == CALL)
            {
                f1 = (B > X) ? 1.0 : 0.0 ;
                f2 = (B > X) ? -1.0 : 0.0 ;
            }

            else if (type == PUT)
            {
                f1 = (B > X) ? 1.0 : 0.0 ;
                f2 = (B > X) ? 0.0 : 1.0 ;
            }
        }

        /* First do the 'vanilla' part */
        irg = Set_IRG_STR(cap->irg[i].type, cap->irg[i].strike,
                          &cap->irg[i].fix_start, &cap->irg[i].fix_end,
                          &cap->irg[i].pay_day, &cap->irg[i].period_start, 
                          &cap->irg[i].period_end, cap->irg[i].size,
                          cap->irg[i].LIBORfix) ;

        capl.oadd = BINARY ;
        capl.bini.poff = Set_PAYOFFINF(cap->sfin.poff.poff,
                                       cap->sfin.poff.gap,
                                       cap->sfin.poff.scale) ;
        capl.bini.dcadj = False ;

        p1 = Caplets_Black2P(analys, voldate, &capl, df_index, df_disc,
                             vol, cmadj, holi, risk, &dp1, &ddp1) ;

        /* Now do the 'barrier' part - be careful about option type */
        irg.strike = B ;
        irg.type   = type ;
        G = (type == CALL) ? X - B : B - X ;

        if (cap->sfin.poff.poff == OP_VANILLA)
            capl.bini.poff = Set_PAYOFFINF(OP_GAP, G, 0.0) ;

        else if (cap->sfin.poff.poff == OP_BINARY)
            capl.bini.poff = Set_PAYOFFINF(OP_BINARY,
                                           cap->sfin.poff.gap, 0.0) ;

        else if (cap->sfin.poff.poff == OP_ASSETON)
            capl.bini.poff = Set_PAYOFFINF(OP_ASSETON, 0.0,
                                           cap->sfin.poff.scale) ;

        else if (cap->sfin.poff.poff == OP_GAP)
            capl.bini.poff = Set_PAYOFFINF(OP_GAP,
                                           cap->sfin.poff.gap + G, 0.0);

        p2 = Caplets_Black2P(analys, voldate, &capl, df_index, df_disc, vol,
                             cmadj, holi, risk, &dp2, &ddp2) ;
/*
printf("%lf %lf %lf %lf\n", f1, f2, p1, p2) ;
*/

        /* Any rebates - handle as a digital option */
        if (R > IRG_ACC)
        {
            irg.strike = B ;
            irg.type   = rtype ;
            capl.bini.poff = Set_PAYOFFINF(OP_BINARY, R, 0.0) ;
            p3 = Caplets_Black2P(analys, voldate, &capl, df_index, df_disc, vol,
                                 cmadj, holi, risk, &dp3, &ddp3) ;
        }
        else
            p3 = dp3 = ddp3 = 0.0 ;

        p    += f1 * p1 + f2 * p2 + p3 ;
        *dp  += f1 * dp1 + f2 * dp2 + dp3 ;
        *ddp += f1 * ddp1 + f2 * ddp2 + ddp3 ;
    }

    return p ;
}


/*,,SOH,,
***********************************************************************
*                                                                      
*                Set_CAPLETS()                                         
*                                                                      
*   interface    #include <cap.h>                                      
*                CAPLETS Set_CAPLETS(INTI       count,                 
*                                    CALCONV    cal,                   
*                                    EOMCONV    eom,                   
*                                    QOTCONV    qot,                   
*                                    PMTFREQ    freq,                  
*                                    IRGARRAY   irg,                   
*                                    RATEINDEX* index,
*                                    COMPMETHOD method,
*                                    PMTFREQ    compfreq) ;
*                                                                      
*   general      This routine sets the members of the struct defined   
*                in the function name. The pointer members are simply  
*                assigned - without physical copying. The intention    
*                of the Set_*() routines is that by using this         
*                functionality, one avoids setting individual members  
*                of structs in the application code.                   
*                                                                      
*                When new members are inserted in structs the Set_*()  
*                routine will be changed accordingly.                  
*                                                                      
*                One exception to this principle applies. Whenever     
*                OPTADD and vanilla members are used, only the         
*                vanilla members are set in the Set_*() routines. The  
*                non-vanilla and exotic members are set to defaults,   
*                and must be set elsewhere - if needed.                
*                                                                      
*                For details on the interpretation of the individual   
*                struct members please check the struct definition.    
*                                                                      
*   input        INTI       count    See general section.               
*                                                                      
*                CALCONV    cal      See general section.               
*                                                                      
*                EOMCONV    eom      See general section.               
*                                                                      
*                QOTCONV    qot      See general section.               
*                                                                      
*                PMTFREQ    freq     See general section.               
*                                                                      
*                IRGARRAY   irg      See general section.               
*                                                                      
*                RATEINDEX* index    See general section.               
*                                    Use NULL for default values        
*                
*                COMPMETHOD method   See general section.
*                
*                PMTFREQ    compfreq See general section.       
*                                                                      
*   output                                                             
*                                                                      
*   returns      The filled out CAPLETS struct                         
*                                                                      
*   diagnostics                                                        
*                                                                      
*   see also     CAPLETS                                               
*                                                                      
************************************************************************
,,EOH,,*/

CAPLETS Set_CAPLETS(INTI        count,
                       CALCONV     cal,
                       EOMCONV     eom,
                       QOTCONV     qot,
                       PMTFREQ     freq,
                       IRGARRAY    irg,
                       RATEINDEX*  index,
                       COMPMETHOD  method,
                       PMTFREQ     compfreq)
{
    CAPLETS capl ;
    FL64    m ;

    capl.count    = count ;
    capl.cal      = cal ;
    capl.eom      = eom ;
    capl.qot      = qot ;
    capl.freq     = freq ;
    capl.irg      = irg ;
    capl.method   = method ;
    capl.compfreq = compfreq ;

    if (index != NULL)
        capl.index = *index ;
    else
    {
        m          = (FL64) Cflw_MonthsBetweenPayments(freq) ;
        capl.index = Set_RATEINDEX(MMRATE, m, MONTHS, NO_FREQUENCY, cal, 0.0) ;
    }

    capl.oadd  = NO_OPTADD ;

    return capl ;
}


/*
..
*/

FL64 Caplets_IRG_Notional(CAPLETS* cap, INTI i, HOLI_STR* holi)   /* PMSTA-22396 - SRIDHARA � 160502 */
{
  FL64 sz, dtby ;

  /* Cap prices are quoted in basis points */
  sz = cap->irg[i].size / 100.0 ;
      
  if (cap->index.LIBORtype == BILLYIELD)
  {
      /* Here the payoff is translated from Bill Yield terms to
         rate terms */
      dtby = Cldr_TermBetweenDates(&cap->irg[i].fix_start, 
                                   &cap->irg[i].fix_end, 
                                   0, cap->cal, LAST, holi) ;   /* PMSTA-22396 - SRIDHARA � 160502 */
      sz  *= TVMunit_NPV(dtby, cap->irg[i].strike, SIMPLE_MM, 0) ;
  }

  return sz ;
}


/*,,SOH,,
************************************************************************
*
*                Set_IRG_STR()
*
*   interface    #include <cap.h>
*                IRG_STR Set_IRG_STR(OPTTYPE  type,
*                                    FL64     strike,
*                                    DATESTR* fix_start,
*                                    DATESTR* fix_end,
*                                    DATESTR* pay_day,
*                                    DATESTR* period_start,
*                                    DATESTR* period_end,
*                                    FL64     size,
*                                    FL64     LIBORfix) ;
*
*   general      This routine sets the members of the struct defined
*                in the function name. The pointer members are simply
*                assigned - without physical copying. The intention
*                of the Set_*() routines is that by using this
*                functionality, one avoids setting individual members
*                of structs in the application code.
*
*                When new members are inserted in structs the Set_*()
*                routine will be changed accordingly.
*
*                One exception to this principle applies. Whenever
*                OPTADD and vanilla members are used, only the
*                vanilla members are set in the Set_*() routines. The
*                non-vanilla and exotic members are set to defaults,
*                and must be set elsewhere - if needed.
*
*                For details on the interpretation of the individual
*                struct members please check the struct definition.
*
*   input        OPTTYPE  type          See general section.
*
*                FL64     strike        See general section.
*
*                DATESTR* fix_start     See general section.
*
*                DATESTR* fix_end       See general section.
*
*                DATESTR* pay_day       See general section.
*                                       Use NULL for default value
*
*                DATESTR* period_start  See general section.
*                                       Use NULL for default value
*
*                DATESTR* period_end    See general section.
*                                       Use NULL for default value
*
*                FL64     size          See general section.
*
*                FL64     LIBORfix      See general section.
*
*   output
*
*   returns      The filled out IRG_STR struct
*
*   diagnostics
*
*   see also     IRG_STR
*
************************************************************************
,,EOH,,*/

IRG_STR Set_IRG_STR(OPTTYPE  type,
                       FL64     strike,
                       DATESTR* fix_start,
                       DATESTR* fix_end,
                       DATESTR* pay_day,
                       DATESTR* period_start,
                       DATESTR* period_end,
                       FL64     size,
                       FL64     LIBORfix)
{
    IRG_STR irg ;

    irg.type      = type ;
    irg.strike    = strike ;
    irg.fix_start = *fix_start ;
    irg.fix_end   = *fix_end ;

    if (pay_day != NULL)
        irg.pay_day = *pay_day ;
    else
        irg.pay_day = *fix_end ;

    if (period_start != NULL)
        irg.period_start = *period_start ;
    else
        irg.period_start = *fix_start ;

    if (period_end != NULL)
        irg.period_end = *period_end ;
    else
        irg.period_end = *fix_end ;

    irg.size      = size ;
    irg.LIBORfix  = LIBORfix ;

    return irg ;
}


#undef MIN_FORW_RATE
#undef IRG_MAXIT
#undef IRG_GUESS
#undef IRG_DAMP
#undef IRG_ACC
#undef IRG_EPS
#undef IRG_LOWER
#undef IRG_UPPER
#undef IRG_UPPER_SIZE
#undef IRG_UPPER_VOL

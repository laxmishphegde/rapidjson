/* SCID @(#)tstvolbt.c	1.6 (SimCorp) 99/02/19 14:10:18 */

/************************************************************************
*
*   project     SCecon
*
*   filename    boottest.c
*
*   this program tests the routines in the boot module of SCecon
*
************************************************************************/

/*** includes ***********************************************************/
#include <string.h>
#include <scalloc.h>
#include <str2conv.h>
#include <volboot.h>
#include <ioconv.h>
#include <capio.h>
#include <optio.h>
#include <futio.h>
#include <bondio.h>

/*** the main() routine *************************************************/

INTI volboottest(char* txa, FILE* in, FILE* out)
{
    char       txb[40], txc[40], txe[40], txf[40], txpl[120];
    char       txg[40], txh[40] ;
    INTI       i, j ;
    BOOLE      err, okexp, ok ;
    INTI       nirg, ncap, nh, no, nv, diff, dif1, nd, n ;
    FL64       size, strike, acc, dacc, dum, fexp ;
    PLANARRAY  disc ;
    FL64ARRAY  prices, spread, madj ;
    PLANARRAY  vol1, vol, expplan ;
    DISCIPOL   ipol ;
    YYYYMMDD   ymd, ymd2 ;
    DATESTR    today, end, dzero ;
    DATEARRAY  holidays, settle ;
    VOLCONV    vc ;
    EOMCONV    eom ;
    BUSCONV    bus ;
    CAPLETSARRAY cap ;
    CAPARRAY   caps;
    OPTTYPE    type ;
    PMTFREQ    freq ;
    INTPOLCONV iconv ;
    int        i1, i2, i3, i4, i5 ;
    HOLI_STR   holi ;
    PAYDAYDEF  pday ;
    CALCONV    cal_ipol ;
    DISCFAC    df, df1, df_index, df_disc ;
    VOL_STR    vols, volf ;
    PAYDAYSEQ   pseq ;
    BSECARRAY  secs1 ;

    acc   = 0.00001 ;
    dacc  = 0.000001 ;
    dzero = Cldr_YMD2Datestr((YYYYMMDD) 0) ;

    diff = -1 ;


    if (!strcmp("Boot_PCPAR2MarginAdj()", txa))
    {
        fscanf(in, "%ld %d %s", &ymd, &i1, txpl) ;
        n = (INTI) i1 ;

        secs1  = Alloc_BSECARRAY(n) ;
        prices = Alloc_FL64ARRAY(n) ;
        spread = Alloc_FL64ARRAY(n) ;
        settle = Alloc_DATEARRAY(n) ;

        today = Cldr_YMD2Datestr(ymd) ;

        fprintf(out,"?; testing %s\n", txa) ;
        fprintf(out,"   today is           %8ld\n", ymd) ;

        for (i = 0 ; i < n ; i++)
        {
            fprintf(out, "SECURITY              %8d\n", (int) (i + 1)) ;
            secs1[i] = Read_BSEC(in, out, &prices[i], &spread[i],
                                 &dum, &settle[i]) ;
        }

        df   = Read_DISCFAC(in, out) ;
        volf = Read_VOL_STR(in, out) ;  /* #1 */
        holi = Set_HOLI_STR(NO_BUSADJUST, 0, NULL) ;

        madj = Boot_PCPAR2MarginAdj(&today, secs1, settle, prices, n,
                                    &df, &volf, &holi) ;

        diff = 0 ;
        fprintf(out, "\n    Exp.Adj    Calc.Adj\n") ;

        for (i = 0 ; i < n; i++)
        {
            fscanf(in, "%lf", &fexp) ;

            diff = diff || (fabs(fexp - madj[i]) > acc) ;
            fprintf(out,"%d; %lf %lf\n", fabs(fexp - madj[i]) > acc,
                    fexp, madj[i]) ;
        }
        
        fprintf(out,"   %s\n\n", txpl) ;

        Free_FL64ARRAY(madj) ;
        Free_FL64ARRAY(prices) ;
        Free_FL64ARRAY(spread) ;
        Free_DATEARRAY(holi.holidays) ;
        Free_DATEARRAY(settle) ;
        Free_BSECARRAY(secs1) ;
        Free_PLANARRAY(volf.vol, 1) ;
        Free_PLANARRAY(df.disc, 1) ;
    }

    else if (!strcmp("Boot_Caplets2B76Vol()", txa))
    {
        fscanf(in, "%d %d %d %d %d %s %s %s %s %s %s",
               &i1, &i2, &i3, &i4, &i5, txg, txb, txh, txc, txf, txpl);
        nh = (INTI) i1 ;
        ncap = (INTI) i2 ;
        no = (INTI) i3 ;
        nd = (INTI) i4 ;
        nv = (INTI) i5 ;

        ipol = Str2DISCIPOL(txb) ;
        iconv= Str2INTPOLCONV(txh) ;
        bus  = Str2BUSCONV(txf) ;
        vc   = Str2VOLCONV(txg) ;
        cal_ipol = Str2CALCONV(txc) ;

        fprintf(out,"   testing %s\n", txa) ;
        fprintf(out,"   volconv        %8s\n", txg) ;
        fprintf(out,"   ipol in        %8s\n", txb) ;
        fprintf(out,"   intpol         %8s\n", txh) ;
        fprintf(out,"   cal intpol     %8s\n", txc) ;
        fprintf(out,"   busconv        %8s\n", txf) ;

        holidays = Alloc_DATEARRAY(nh) ;

        fprintf(out,"   the holidays are...\n") ;
        fprintf(out,"   holiday\n") ;
        for (i = 0 ; i < nh ; i++)
        {
            fscanf(in, "%ld", &ymd) ;
            holidays[i] = Cldr_YMD2Datestr(ymd) ;
            fprintf(out,"   %8ld\n", ymd) ;
        }

        fprintf(out, "\n") ;

        cap    = Alloc_CAPLETSARRAY(ncap, 0, False) ;
        prices = Alloc_FL64ARRAY(ncap) ;

        fprintf(out,"   cap array is...\n") ;
        for (i = 0 ; i < ncap ; i++)
        {
            fscanf(in,"%d %lf %s %lf %ld %ld %s %lf %s %s %s",
                   &i1, &prices[i], txb, &strike,
                   &ymd, &ymd2, txc, &size, txe, txf, txg) ;
            type  = Str2OPTTYPE(txb) ;
            freq  = Str2PMTFREQ(txc) ;
            today = Cldr_YMD2Datestr(ymd) ;
            end   = Cldr_YMD2Datestr(ymd2) ;

            cap[i].cal   = Str2CALCONV(txe) ;
            cap[i].eom   = eom = Str2EOMCONV(txf) ;
            cap[i].qot   = Str2QOTCONV(txg) ;
            cap[i].freq  = freq ;

            cap[i].index = Set_RATEINDEX(MMRATE, 
              (FL64)Cflw_MonthsBetweenPayments(freq), MONTHS,
              NO_FREQUENCY, cap[i].cal, 0.0);

            holi.nholi    = nh ;
            holi.holidays = holidays ;
            holi.bus      = bus ;

            pseq = Set_PAYDAYSEQ(Cflw_MonthsBetweenPayments(freq),
                                      MONTHS, NOODD, NOODD, ANCHORBACK,
                                      eom) ;

            pday = Set_PAYDAYDEF(True, &today, &dzero, &end,
                                      False, &pseq, 0, NULL) ;

            cap[i].irg = Caplets_GenrIRGARRAY(&pday, type, strike,
                                              size, &holi, &nirg) ;
            cap[i].count = nirg ;

            fprintf(out,"    CAP %d\n", (int) i) ;
            fprintf(out,"    %lf %s %lf %8ld %8ld %s %lf %s %s %s\n",
                    prices[i], txb, strike, ymd, ymd2,
                    txc, size, txe, txf, txg);
            fprintf(out,"    IRGdates\n") ;

            for (j = 0 ; j < nirg; j++)
                fprintf(out, "    %d %ld %ld\n", (int) j,
                        Cldr_Datestr2YMD(&cap[i].irg[j].fix_start),
                        Cldr_Datestr2YMD(&cap[i].irg[j].fix_end) ) ;
        }

        disc = Alloc_PLANARRAY(2, GETMAX(no, nd)) ;

        fprintf(out,"   offer disc. fct. table is...\n") ;
        for (i = 0 ; i < no ; i++)
        {
            fscanf(in,"%ld %lf", &ymd, &disc[0].f64[i]) ;
            disc[0].day[i] = Cldr_YMD2Datestr(ymd) ;
            fprintf(out,"   date[%2d] %8ld  disc[%2d] %10.5lf\n",
                    (int) i, ymd, (int) i, disc[0].f64[i]) ;
            ++(disc->filled) ;
        }

        fprintf(out,"   disc disc. fct. table is...\n") ;
        for (i = 0 ; i < nd ; i++)
        {
            fscanf(in,"%ld %lf", &ymd, &disc[1].f64[i]) ;
            disc[1].day[i] = Cldr_YMD2Datestr(ymd) ;
            fprintf(out,"   date[%2d] %8ld  disc[%2d] %10.5lf\n",
                    (int) i, ymd, (int) i, disc[1].f64[i]) ;
            ++(disc[1].filled) ;
        }

        vol = Alloc_PLANARRAY(1, GETMAX(nv, ncap) ) ;

        for (i = 0 ; i < nv ; i++)
        {
            fscanf(in,"%ld %lf", &ymd, &vol[0].f64[i]) ;
            vol[0].day[i] = Cldr_YMD2Datestr(ymd) ;
            ++(vol->filled) ;
        }

        df  = Set_DISCFAC(disc, ipol, iconv, cal_ipol, CONTINUOUS,
                         ANNUALLY);
        df1 = Set_DISCFAC(&disc[1], ipol, iconv, cal_ipol, CONTINUOUS,
                          ANNUALLY);

        err = Boot_Caplets2B76Vol(cap, ncap, prices, &df, &df1, cal_ipol, 
                                  vc, &vols) ;
        vol1 = vols.vol ;

        if (err != True)
        {
            diff = 1 ;
            fprintf(out, "1; Cannot calibrate\n") ;
        }

        else if (GetPlanFill(vol1) != GetPlanFill(vol))
        {
            diff = 1 ;
            fprintf(out,
              "1; Wrong number of vol's you expected %d we found %d\n",
                    GetPlanFill(vol), GetPlanFill(vol1)) ;
        }
        else
        {
            for (diff = i = 0; i < GetPlanFill(vol1); i++)
            {
                dif1 = fabs(vol1->f64[i] - vol[0].f64[i]) > acc ||
                       Cldr_Datestr2YMD(&vol[0].day[i]) !=
                       Cldr_Datestr2YMD(&vol1->day[i]) ;
                diff = diff || dif1 ;
                fprintf(out,"%d; calc: day %8ld vol %9.5lf",
                        (int) dif1, Cldr_Datestr2YMD(&vol1->day[i]),
                        vol1->f64[i]) ;
                fprintf(out," exp: day %8ld vol %9.5lf\n",
                        Cldr_Datestr2YMD(&vol[0].day[i]), vol[0].f64[i]) ;
            }
        }
        fprintf(out,"   %s\n\n", txpl) ;

        Free_PLANARRAY(disc, 2) ;
        Free_PLANARRAY(vol, 1) ;
        Free_PLANARRAY(vols.vol, 1) ;
        Free_CAPLETSARRAY(cap, ncap) ;
        Free_FL64ARRAY(prices) ;
        Free_DATEARRAY(holidays) ;
    }

    else if (!strcmp("Boot_Cap2B76Vol()", txa))
    {
        okexp = Read_BOOLE(in, out, "  Exp. status      ");

        df_index = Read_DISCFAC(in, out);
        df_disc = Read_DISCFAC(in, out);
        holi = Read_HOLI_STR(in, out);

        caps = Read_CAPARRAY(in, out, &ncap);
        fprintf(out, "   Price quotes:  \n");
        prices = Read_FL64ARRAY(in, &n);
        Write_FL64ARRAY(out, prices, n);
        
        cal_ipol = Read_CALCONV(in, out, "  Vol daycounting  ");
        vc  = Read_VOLCONV(in, out, "  Vol conv         ");

        IOUtil_ParseLine(in, out);

        ok = Boot_Cap2B76Vol(caps, ncap, prices, &df_index,
            &df_disc, &holi, cal_ipol, vc, &vols);

        expplan = Read_PLANARRAY(in);

        if (ok == okexp && ok)
            diff = Write_PlanDiff(expplan, vols.vol, out);
        else if (ok != okexp)
        {
            fprintf(out, "1; Unexpected status: %d\n", ok);
            diff = 1;
        }
        else
        {
            fprintf(out, "0; Couldn't calibrate.\n");
            diff = 0;
        }

        Free_PLANARRAY(df_index.disc, 1);
        Free_PLANARRAY(df_disc.disc, 1);
        Free_DATEARRAY(holi.holidays);
        Free_CAPARRAY(caps, ncap, True);
        Free_PLANARRAY(vols.vol, 1);
        Free_PLANARRAY(expplan, 1);
        Free_FL64ARRAY(prices);
    }


    return diff ;
}

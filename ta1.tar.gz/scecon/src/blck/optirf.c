/* SCID @(#)optirf.c	1.4 (SimCorp) 99/02/19 14:09:52 */

/************************************************************************
*
*   project     SCecon
*
*   file name   optirf.c
*
*   general     This file contains calculation routines for IRF options.
*
************************************************************************/

#include <cap.h>


/*,,SOH,,
*************************************************************************
*
*               OptIRF_Black2DFp()
*
*    interface  #include <cap.h>
*               FL64 OptIRF_Black2DFp(DATESTR*  analys,   
*                                     DATESTR*  voldate,
*                                     FRA_STR*  irf,    
*                                     OPTFUT*   opt,    
*                                     DISCFAC*  df,     
*                                     FL64      vol,    
*                                     HOLI_STR* holi,   
*                                     RISKSET*  risk,   
*                                     FL64*     dp,     
*                                     FL64*     ddp)    
*
*    general    OptIRF_Black2DFp() computes the theoretical price for an
*               option on an IRF using the Black 76 model for interest
*               rate options under the assumption that the equivalent
*               FRA rate is log-normal. The current value of the 
*               underlying IRF (ie the current FRA rate) is extracted
*               from the provided discount function.
*
*               Key ratios are calculated as follows:
*
*                   risk->key      dp          ddp
*                   ---------      ---         ----
*                   KEY_DF         Delta       Gamma
*                   KEY_BPV        BPV
*                   KEY_PRICE      Delta       Gamma
*                   KEY_MATURITY   Theta
*                   KEY_VOL        Vega        d(Vega)/d(Vol)
*                   KEY_STRIKE     d(P)/d(C)   d2(P)/d(C)2
*
*               where dp contains first order and ddp second order
*               ratios. C is the strike.
*
*               The delta/gammas for KEY_DF corresponds to shocks in the*
*               entire Zero Yield Curve, whereas as the delta/gammas for*
*               KEY_PRICE corresponds to shocks to the FRA rates only.
*
*    input      DATESTR  *analys  Pointer to analysis date (NPV date)
*
*               DATESTR  *voldate Vol calculated from this date
*
*               FRA_STR  *irf     The IRF definition. irf->fra is 
*                                 assumed to be False.
*
*               OPTFUT   *opt     The option definition.
*
*               DISCFAC  *df      Discount function setup for 
*                                 discounting future payments.
*
*               FL64     vol      Volatility of the equivalent FRA rate.
*
*               HOLI_STR *holi    Holiday set-up.
*
*               RISKSET  *risk    The risk ratio definitions
*                                 Use NULL for no Greeks.
*
*    output     FL64     *dp      The first order ratio
*
*               FL64     *ddp     The second order ratio.
*
*    returns    The total price of the option quoted pr 1 notional
*               unit.
*
*    diagnostics
*
*    see also   OptIRF_Black2P()
*               Cap_Black2P()
*
*    wrapper    AP
*
*************************************************************************
,,EOH,,*/

FL64 OptIRF_Black2DFp(DATESTR* analys,
                          DATESTR*   voldate,
                          FRA_STR*   irf,
                          OPTFUT*    opt,
                          DISCFAC*   df,
                          FL64       vol,
                          HOLI_STR*  holi,
                          RISKSET*   risk,
                          FL64*      dp,
                          FL64*      ddp)
{
  FL64     dum, futp, frar, phi, plo, p, shock, vol_t, dt ;
  DATESTR  anld, vold, dsett, dmat ;
  DISCFAC  dfsh ;
  FRA_STR  irf_t ;
  OPTFUT   opt_t ;

  /* Initialize */
  *dp = *ddp = 0.0 ;
  irf_t = *irf;
  opt_t = *opt;
  vol_t = vol;

  /* Find DF based FRA rate */
  futp = IRF_DF2Price(&irf_t, df, holi) ;
  frar = 100.0 - futp;
  opt_t.strike = 100 - opt_t.strike;
  opt_t.type = (opt_t.type == CALL ? PUT : 
                   (opt_t.type == PUT ? CALL : opt_t.type));

  dsett = Cldr_NextBusinessDate(&irf->settl, holi) ;
  dmat  = Cldr_NextBusinessDate(&irf->matur, holi) ;
  if (irf->freq != NO_FREQUENCY)
      dt = ((FL64) Cflw_MonthsBetweenPayments(irf->freq)) / 12.0;
  else
	  dt = Cldr_TermBetweenDates(&dsett, &dmat, 0, irf->cal, LAST, holi);  /* PMSTA-22396 - SRIDHARA � 160502 */

  /* Find the option price according to this futures price */
  p = Option_Black2P(analys, voldate, frar, False, 1.0, vol_t, 
                     &opt_t, df, holi, NULL, &dum, &dum) ;
/*  p *= dt;*/

  if (risk == NULL || risk->risk == ZERO_ORDER)
      return p ;

  /* Shock input */
  shock = Scutl_Default_Shock(risk->shock, risk->key) ;

  switch (risk->key)
  {
    case KEY_PRICE:     /* FRA rate sensitivity - weird */
      frar -= shock ;
      phi = Option_Black2P(analys, voldate, frar, False, 1.0, vol_t, 
                     &opt_t, df, holi, NULL, &dum, &dum) ;
/*      phi *= dt;*/

      frar += 2.0 * shock ;
      plo = Option_Black2P(analys, voldate, frar, False, 1.0, vol_t, 
                     &opt_t, df, holi, NULL, &dum, &dum) ;
/*      plo *= dt;*/

      frar -= shock ;
      *dp = (phi - plo) / (2.0 * shock) ;
      if (risk->risk == SECOND_ORDER)
        *ddp = (phi + plo - 2.0 * p) / SQR(shock) ;

      break ;

    case KEY_STRIKE:    /* Strike sensitivity */

      opt->strike -= shock ;
      phi = OptIRF_Black2DFp(analys, voldate, irf, opt,
                           df, vol_t, holi, NULL, &dum, &dum) ;

      opt->strike += 2.0 * shock ;
      plo = OptIRF_Black2DFp(analys, voldate, irf, opt,
                           df, vol_t, holi, NULL, &dum, &dum) ;

      opt->strike -= shock ;
      *dp = (phi - plo) / (2.0 * shock) ;
      if (risk->risk == SECOND_ORDER)
        *ddp = (phi + plo - 2.0 * p) / SQR(shock) ;

      break ;

    case KEY_VOL:       /* Vega */

      /* Shock the vol */
      vol_t += shock ;
      phi = OptIRF_Black2DFp(analys, voldate, irf, opt,
                           df, vol_t, holi, NULL, &dum, &dum) ;

      vol_t -= 2.0 * shock ;
      plo = OptIRF_Black2DFp(analys, voldate, irf, opt,
                           df, vol_t, holi, NULL, &dum, &dum) ;

      vol_t += shock ;

      *dp = (phi - plo) / (2.0 * shock) ;
      if (risk->risk == SECOND_ORDER)
        *ddp = (phi + plo - 2.0 * p) / SQR(shock) ;

      break ;

    case KEY_DF:
    case KEY_BPV:

      /* $Duration / Convexity - Shock DF */

      shock = Scutl_Default_Shock(risk->shock, risk->key) ;

	  dfsh = Disc_ShockRates(df, 1.0, risk, holi);  /* PMSTA-22396 - SRIDHARA � 160502 */
      phi  = OptIRF_Black2DFp(analys, voldate, irf, opt,
                           &dfsh, vol_t, holi, NULL, &dum, &dum) ;
      Free_PLANARRAY(dfsh.disc, 1) ;

	  dfsh = Disc_ShockRates(df, -1.0, risk, holi);  /* PMSTA-22396 - SRIDHARA � 160502 */
      plo  = OptIRF_Black2DFp(analys, voldate, irf, opt,
                           &dfsh, vol_t, holi, NULL, &dum, &dum) ;
      Free_PLANARRAY(dfsh.disc, 1) ;

      if (risk->key == KEY_BPV)
          shock = 1.0 ;

      *dp = (phi - plo) / (2.0 * shock) ;
      if (risk->risk == SECOND_ORDER && risk->key == KEY_DF)
          *ddp = (phi + plo - 2.0 * p) / SQR(shock) ;

      break ;

    case KEY_MATURITY:
    case KEY_MATURITY_BPV:

      /* Let time decay -> and reflect this in the dates of the DF's.
         Ie. we move the entire Term Structure of interest rates. */
		/* PMSTA-22396 - SRIDHARA � 160502 */
		dfsh = Disc_Shock_Dates(df, (INTI)shock, holi);  
      anld = Cldr_AddDays(analys, (INTL) shock, opt->cal, holi) ;
      vold = Cldr_AddDays(voldate, (INTL) shock, opt->cal, holi) ;

      /* Note that we do not shift the vol, since we want to interpolate
         the same vols as before */

      plo  = OptIRF_Black2DFp(&anld, &vold, irf, opt,
                           &dfsh, vol_t, holi, NULL, &dum, &dum) ;

      /* Do not set ddp */
      *dp = (plo - p) / shock ;

      if (risk->key == KEY_MATURITY)
		  *dp *= Cldr_DaysPerYear(analys, analys, 0, opt->cal, LAST, holi);  /* PMSTA-22396 - SRIDHARA � 160502 */

      /* Clean up */
      Free_PLANARRAY(dfsh.disc, 1) ;
      break ;

    default:
      ;
  }

  return p ;
}


/*,,SOH,,
*************************************************************************
*
*               OptIRF_Black2P()
*
*    interface  #include <cap.h>
*               FL64 OptIRF_Black2P(DATESTR*  analys,   
*                                   DATESTR*  voldate,
*                                   FL64      irfp,
*                                   FRA_STR*  irf,
*                                   OPTFUT*   opt,    
*                                   DISCFAC*  df,     
*                                   FL64      vol,    
*                                   HOLI_STR* holi,   
*                                   RISKSET*  risk,   
*                                   FL64*     dp,     
*                                   FL64*     ddp)    

*    general    OptIRF_Black2P() computes the theoretical price for an
*               option on an IRF using the Black 76 model for interest
*               rate options under the assumption that the equivalent
*               FRA rate is log-normal.
*
*               Key ratios are calculated as follows:
*
*                   risk->key      dp          ddp
*                   ---------      ---         ----
*                   KEY_DF         Delta       Gamma
*                   KEY_BPV        BPV
*                   KEY_PRICE      Delta       Gamma
*                   KEY_MATURITY   Theta
*                   KEY_VOL        Vega        d(Vega)/d(Vol)
*                   KEY_STRIKE     d(P)/d(C)   d2(P)/d(C)2
*
*               where dp contains first order and ddp second order
*               ratios. C is the strike.
*
*               The delta/gammas for KEY_DF corresponds to shocks in the*
*               entire Zero Yield Curve, whereas as the delta/gammas for*
*               KEY_PRICE corresponds to shocks to the FRA rates only.
*
*    input      DATESTR  *analys  Pointer to analysis date (NPV date)
*
*               DATESTR  *voldate Vol calculated from this date
*
*               FL64     irfp     The current IRF price.
*
*               FRA_STR  *irf     The IRF definition. irf->fra is 
*                                 assumed to be False.
*
*               OPTFUT   *opt     The option definition.
*
*               DISCFAC  *df      Discount function setup for 
*                                 discounting future payments.
*
*               FL64     vol      Volatility of the equivalent FRA rate.
*
*               HOLI_STR *holi    Holiday set-up.
*
*               RISKSET  *risk    The risk ratio definitions
*                                 Use NULL for no Greeks.
*
*    output     FL64     *dp      The first order ratio
*
*               FL64     *ddp     The second order ratio.
*
*    returns    The total price of the option quoted pr 1 notional
*               unit.
*
*    diagnostics
*
*    see also   OptIRF_Black2DFp()
*               Cap_Black2P()
*
*    wrapper    AP
*
*************************************************************************
,,EOH,,*/

FL64 OptIRF_Black2P(DATESTR* analys,
                          DATESTR*   voldate,
                          FL64       irfp,
                          FRA_STR*   irf,
                          OPTFUT*    opt,
                          DISCFAC*   df,
                          FL64       vol,
                          HOLI_STR*  holi,
                          RISKSET*   risk,
                          FL64*      dp,
                          FL64*      ddp)
{
  FL64     dum, frar, phi, plo, p, shock, vol_t, dt ;
  DATESTR  anld, vold, dsett, dmat ;
  DISCFAC  dfsh ;
  OPTFUT   opt_t ;

  /* Initialize */
  *dp = *ddp = 0.0 ;
  opt_t = *opt;
  vol_t = vol;

  /* Find DF based FRA rate */
  frar = 100.0 - irfp;
  opt_t.strike = 100 - opt_t.strike;
  opt_t.type = (opt_t.type == CALL ? PUT : 
                   (opt_t.type == PUT ? CALL : opt_t.type));

  dsett = Cldr_NextBusinessDate(&irf->settl, holi) ;
  dmat  = Cldr_NextBusinessDate(&irf->matur, holi) ;
  if (irf->freq != NO_FREQUENCY)
      dt = ((FL64) Cflw_MonthsBetweenPayments(irf->freq)) / 12.0;
  else
	  dt = Cldr_TermBetweenDates(&dsett, &dmat, 0, irf->cal, LAST, holi);  /* PMSTA-22396 - SRIDHARA � 160502 */

  /* Find the option price according to this futures price */
  p = Option_Black2P(analys, voldate, frar, False, 1.0, vol_t, 
                     &opt_t, df, holi, NULL, &dum, &dum) ;
/*  p *= dt;*/

  if (risk == NULL || risk->risk == ZERO_ORDER)
      return p ;

  /* Shock input */
  shock = Scutl_Default_Shock(risk->shock, risk->key) ;

  switch (risk->key)
  {
    case KEY_PRICE:     /* FRA rate sensitivity - weird */
      irfp += shock ;
      phi = OptIRF_Black2P(analys, voldate, irfp, irf, opt,
                           df, vol_t, holi, NULL, &dum, &dum) ;

      irfp -= 2.0 * shock ;
      plo = OptIRF_Black2P(analys, voldate, irfp, irf, opt,
                           df, vol_t, holi, NULL, &dum, &dum) ;

      irfp += shock ;
      *dp = (phi - plo) / (2.0 * shock) ;
      if (risk->risk == SECOND_ORDER)
        *ddp = (phi + plo - 2.0 * p) / SQR(shock) ;

      break ;

    case KEY_STRIKE:    /* Strike sensitivity */

      opt->strike += shock ;
      phi = OptIRF_Black2P(analys, voldate, irfp, irf, opt,
                           df, vol_t, holi, NULL, &dum, &dum) ;

      opt->strike -= 2.0 * shock ;
      plo = OptIRF_Black2P(analys, voldate, irfp, irf, opt,
                           df, vol_t, holi, NULL, &dum, &dum) ;

      opt->strike += shock ;
      *dp = (phi - plo) / (2.0 * shock) ;
      if (risk->risk == SECOND_ORDER)
        *ddp = (phi + plo - 2.0 * p) / SQR(shock) ;

      break ;

    case KEY_VOL:       /* Vega */

      /* Shock the vol */
      vol_t += shock ;
      phi = OptIRF_Black2P(analys, voldate, irfp, irf, opt,
                           df, vol_t, holi, NULL, &dum, &dum) ;

      vol_t -= 2.0 * shock ;
      plo = OptIRF_Black2P(analys, voldate, irfp, irf, opt,
                           df, vol_t, holi, NULL, &dum, &dum) ;

      vol_t += shock ;

      *dp = (phi - plo) / (2.0 * shock) ;
      if (risk->risk == SECOND_ORDER)
        *ddp = (phi + plo - 2.0 * p) / SQR(shock) ;

      break ;

    case KEY_DF:
    case KEY_BPV:

      /* $Duration / Convexity - Shock DF */

      shock = Scutl_Default_Shock(risk->shock, risk->key) ;

	  dfsh = Disc_ShockRates(df, 1.0, risk, holi);  /* PMSTA-22396 - SRIDHARA � 160502 */
      phi  = OptIRF_Black2P(analys, voldate, irfp, irf, opt,
                           &dfsh, vol_t, holi, NULL, &dum, &dum) ;
      Free_PLANARRAY(dfsh.disc, 1) ;

	  dfsh = Disc_ShockRates(df, -1.0, risk, holi);  /* PMSTA-22396 - SRIDHARA � 160502 */
      plo  = OptIRF_Black2P(analys, voldate, irfp, irf, opt,
                           &dfsh, vol_t, holi, NULL, &dum, &dum) ;
      Free_PLANARRAY(dfsh.disc, 1) ;

      if (risk->key == KEY_BPV)
          shock = 1.0 ;

      *dp = (phi - plo) / (2.0 * shock) ;
      if (risk->risk == SECOND_ORDER && risk->key == KEY_DF)
          *ddp = (phi + plo - 2.0 * p) / SQR(shock) ;

      break ;

    case KEY_MATURITY:
    case KEY_MATURITY_BPV:

      /* Let time decay -> and reflect this in the dates of the DF's.
         Ie. we move the entire Term Structure of interest rates. */
		/* PMSTA-22396 - SRIDHARA � 160502 */
      dfsh  = Disc_Shock_Dates(df, (INTI) shock, holi) ;
      anld = Cldr_AddDays(analys, (INTL) shock, opt->cal, holi) ;
      vold = Cldr_AddDays(voldate, (INTL) shock, opt->cal, holi) ;

      /* Note that we do not shift the vol, since we want to interpolate
         the same vols as before */

      plo  = OptIRF_Black2P(&anld, &vold, irfp, irf, opt,
                           &dfsh, vol_t, holi, NULL, &dum, &dum) ;

      /* Do not set ddp */
      *dp = (plo - p) / shock ;

      if (risk->key == KEY_MATURITY)
        *dp *= Cldr_DaysPerYear(analys, analys, 0, opt->cal, LAST, holi) ;

      /* Clean up */
      Free_PLANARRAY(dfsh.disc, 1) ;
      break ;

    default:
      ;
  }

  return p ;
}

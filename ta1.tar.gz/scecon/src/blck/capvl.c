/* SCID @(#)capvl.c	1.12 (SimCorp) 99/08/30 13:38:06 */

/************************************************************************
*
*   project     SCecon
*
*   file name   validate.c
*
*   general     This file contains routines for validating the
*               content of the data structures of SCecon
*
************************************************************************/

/*** includes **********************************************************/
#include <capvl.h>
#include <optvalid.h>
#include <futvl.h>
#include <bondvl.h>

/*** defines ***********************************************************/
#define valid_tol 0.000001


/*,,SOH,,
*************************************************************************
*
*               Validate_B76SM()
*
*   interface   #include <capvl.h>
*               BOOLE     Validate_B76SM(B76SM b)
*
*   general     This function validates the content of the B76SM
*               data structure
*
*   input       B76SM  b  The B76SM data structure
*
*   output
*
*   returns     True if b is a valid B76SM, False if invalid
*
*   diagnostics
*
*   see also    B76SM
*
*************************************************************************
,,EOH,,*/


BOOLE Validate_B76SM(B76SM b)
{
    /* check that b is valid */
    switch (b)
    {
        case B76SM_RATE :
        case B76SM_RATEPA :
        case B76SM_PRICE :
        case B76SM_SCORIG :
              return True ;
        default :
            return False ;
    }
}


/*,,SOH,,
*************************************************************************
*
*               Validate_B76SWTM()
*
*   interface   #include <capvl.h>
*               VALIDATE Validate_B76SWTM(B76SWTM *b)
*
*   general     This function validates the content of the B76SWTM
*               data structure
*
*   input       B76SWTM   *b  The B76SWTM data structure
*
*   output
*
*   returns     Valid_data if the content of b is valid
*               Invalid_b76sm if b76sm is an invalid B76SM
*               Invalid_boole if use_fwd is not True or False
*
*
*   diagnostics
*
*   see also    B76SWTM
*
*************************************************************************
,,EOH,,*/

VALIDATE Validate_B76SWTM(B76SWTM* b)
{
    if (b == NULL)
        return Valid_data ;

    if (!Validate_B76SM(b->b76sm))
        return Invalid_b76sm ;

    if (!Validate_BOOLE(b->use_fwd))
        return Invalid_boole ;

    return Valid_data ;
}


/*,,SOH,,
*************************************************************************
*
*               Validate_CAPLETS()
*
*   interface   #include <capvl.h>
*               VALIDATE Validate_CAPLETS(CAPLETS *c)
*
*   general     This function validates the content of the CAPLETS data
*               structure
*
*   input       CAPLETS   *c      The CAPLETS data structure
*
*   output
*
*   returns     Valid_data if the content of c is valid
*               Invalid_filled is count is < 0
*               Invalid_cal if cal is an invalid calendar convention
*               Invalid_eomconv if eom is an invalid EOMCONV
*               Invalid_qot if qot is an invalid QOTCONV
*               Invalid_freq if freq is an invalid PMTFREQ
*               If the content of irg[i] is invalid an error message
*                    from Validate_IRG_STR() is returned
*               If the content of index is invalid an error message
*                    from Validate_RATEINDEX() is returned
*
*               Invalid_notional if notional is <= 0
*               Invalid_LIBORfix if LIBORfix is <= 0
*               Invalid_boole if vanilla is not TRUE or False
*
*               If oadd is True one the following error messages are
*                   also possible
*
*               If oadd is BARRIER and barr is invalid an error message
*                   from Validate_BARRIERINF() is returned
*               If oadd is ASIAN and asian is invalid an error message
*                   from Validate_ASIANINF() is returned
*               If oadd is BINARY and bini is invalid an error message
*                   from Validate_BINARYINF() is returned
*               If oadd is CONTPREM and ctp is invalid an error message
*                   from Validate_CONTPREMINF() is returned
*               If oadd is RESET and reset is invalid an error message
*                   from Validate_RESETINF() is returned
*
*   diagnostics
*
*   see also    CAPLETS
*
*************************************************************************
,,EOH,,*/


VALIDATE Validate_CAPLETS(CAPLETS* c)
{
    BOOLE       ok = True ;
    INTI        i ;
    VALIDATE    v = Valid_data;
    BARRIERINF  barr ;

    if (c->count < 0)
        return Invalid_filled ;

    if (!Validate_CALCONV(c->cal))
        return Invalid_cal ;

    if (!Validate_EOMCONV(c->eom))
        return Invalid_eomconv ;

    if (!Validate_QOTCONV(c->qot))
        return Invalid_qot ;

    if (!Validate_PMTFREQ(c->freq))
        return Invalid_freq ;

    for (i = 0; i < c->count && ok == True; i++)
    {
        v = Validate_IRG_STR(&c->irg[i]) ;
        if (v != Valid_data)
            ok = False ;
    }
    if (ok == False)
        return v ;

    v = Validate_RATEINDEX(&c->index) ;
    if (v != Valid_data)
        return v ;

    if (Validate_OPTADD(c->oadd) == True)
    {
        switch (c->oadd)
        {
            case NO_OPTADD:
                break ;

            case SHARKFIN:
                barr.monit.num = 0 ;
                barr = Set_BARRIERINF(c->sfin.btype, c->sfin.barrier,
                                      c->sfin.rebate, True, &c->sfin.poff,
                                      &barr.monit);

                v = Validate_BARRIERINF(&barr) ;
                if (v != Valid_data)
                    return v ;

                break ;

            case RESET:
                v = Validate_RESETINF(&c->reset) ;
                if (v != Valid_data)
                    return v ;

                break ;

            case ASIAN:
                /* we don't check that dagvN is before fixing so it doesn't */
                /* matter which date we give Validate_ASIANINF() as argument */
                v = Validate_ASIANINF(&c->asian, &c->irg[0].fix_end, False) ;
                if (v != Valid_data)
                    return v ;

                break ;

            case BINARY :
                v = Validate_BINARYINF(&c->bini) ;
                if (v != Valid_data)
                    return v ;

                break ;

            case CONTPREM:
                v = Validate_CONTPREMINF(&c->ctp) ;
                if (v != Valid_data)
                    return v ;

                break ;

            default:
                ;
        }
    }
    else
        return Invalid_optadd ;

    return Valid_data ;
}


/*,,SOH,,
*************************************************************************
*
*               Validate_CAP()
*
*   interface   #include <capvl.h>
*               VALIDATE Validate_CAP(CAP *c)
*
*   general     This function validates the content of the CAP data
*               structure
*
*   input       CAP     *c         The CAP data structure
*
*   output
*
*   returns     Valid_data if the content of c is valid
*               Invalid_opttype if type is an invalid OPTTYPE
*               Invalid_strike if strike is <= 0
*               Invalid_cal if cal is an invalid calendar convention
*               If the content of fix_days is invalid an error message
*                    from Validate_PAYDAYDEF() is returned
*               Invalid_LIBORfix if LIBORfix is <= 0
*               Invalid_boole if vanilla is not TRUE or False
*
*               If vanilla is False one the following error messages
*                   are also possible
*
*               Invalid_period if delay is an invalid PERIOD
*               Invalid_qot if qot is an invalid QOTCONV
*               If the content of index is invalid an error message
*                    from Validate_RATEINDEX() is returned
*               Invalid_boole if arrears is not TRUE or False
*               Invalid_boole if margin is not TRUE or False
*               Invalid_boole if qprice is not TRUE or False
*               If the content of step_str is invalid an error message
*                   from Validate_PLAN_STR() is returned
*               Wrong_sign_in_array if any of the entries in
*                   step_str.f64 are negative
*               If the content of step_not is invalid an error message
*                   from Validate_PLAN_STR() is returned
*               Wrong_sign_in_array if any of the entries in
*                   step_not.f64 are negative
*               Invalid_optadd if oadd is an invalid OPTADD
*
*               If oadd is True one the following error messages are
*                   also possible
*
*               If oadd is BARRIER and barr is invalid an error message
*                   from Validate_BARRIERINF() is returned
*               If oadd is ASIAN and asian is invalid an error message
*                   from Validate_ASIANINF() is returned
*               If oadd is BINARY and bini is invalid an error message
*                   from Validate_BINARYINF() is returned
*               If oadd is CONTPREM and ctp is invalid an error message
*                   from Validate_COoTPREMINF() is returned
*               If oadd is RESET and reset is invalid an error message
*                   from Validate_RESETINF() is returned
*               If oadd is FLEXICAP and flexicap is invalid an error message
*                   from Validate_FLEXICAPINF() is returned
*
*   diagnostics
*
*   see also    CAP
*
*************************************************************************
,,EOH,,*/

VALIDATE Validate_CAP(CAP* c)
{
    VALIDATE   v ;
    BARRIERINF barr ;

    if (!Validate_OPTTYPE(c->type))
        return Invalid_opttype ;

    if (!Validate_CALCONV(c->cal))
        return Invalid_cal ;

    v = Validate_PAYDAYDEF(&c->fix_days, False) ;
    if (v != Valid_data)
        return v ;

    if (!Validate_BOOLE(c->vanilla))
        return Invalid_boole ;

    if (c->vanilla == False)
    {
        /* No point in validating factor, routine survives anyway */

        if (!Validate_PERIOD(&c->delay))
            return Invalid_period ;

        if (!Validate_QOTCONV(c->qot))
            return Invalid_qot ;

        v = Validate_RATEINDEX(&c->index) ;
        if (v != Valid_data)
            return v ;

        if (!Validate_BOOLE(c->arrears))
            return Invalid_boole ;

        if (!Validate_BOOLE(c->margin))
            return Invalid_boole ;

        if (!Validate_BOOLE(c->qprice))
            return Invalid_boole ;

        v = Validate_PLAN_STR(c->step_str) ;
        if (v != Valid_data)
            return v ;
        else
        {
            v = Validate_PLAN_STR_SIGN(c->step_str, True) ;
            if (v != Valid_data)
                return v ;
        }

        v = Validate_PLAN_STR(c->step_not) ;
        if (v != Valid_data)
            return v ;
        else
        {
            v = Validate_PLAN_STR_SIGN(c->step_not, True) ;
            if (v != Valid_data)
                return v ;
        }

        if (Validate_OPTADD(c->oadd) == True)
        {
            switch (c->oadd)
            {
                case NO_OPTADD:
                    break ;

                case SHARKFIN:
                  barr.monit.num = 0 ;
                  barr = Set_BARRIERINF(c->sfin.btype, c->sfin.barrier,
                                      c->sfin.rebate, True, &c->sfin.poff,
                                      &barr.monit);

                    v = Validate_BARRIERINF(&barr) ;
                    if (v != Valid_data)
                        return v ;

                    break ;

                case RESET:
                    v = Validate_RESETINF(&c->reset) ;
                    if (v != Valid_data)
                        return v ;

                    break ;

                case ASIAN:
                    v = Validate_ASIANINF(&c->asian, &c->fix_days.last, False) ;
                    if (v != Valid_data)
                        return v ;

                    break ;

                case BINARY :
                    v = Validate_BINARYINF(&c->bini) ;
                    if (v != Valid_data)
                        return v ;

                    break ;

                case CONTPREM:
                    v = Validate_CONTPREMINF(&c->ctp) ;
                    if (v != Valid_data)
                        return v ;

                    break ;

                case FLEXICAP:
                    if (!Validate_BOOLE(c->flexicap.autoflex))
                        return Invalid_boole ;
                    break;

                default:
                    return Invalid_optadd ;
            }
        }
        else
            return Invalid_optadd ;
    }
    return Valid_data ;
}


/*,,SOH,,
*************************************************************************
*
*               Validate_SWAPTION()
*
*   interface   #include <capvl.h>
*               VALIDATE Validate_SWAPTION(SWAPTION *s)
*
*   general     This function validates the content of the SWAPTION
*               data structure
*
*   input       SWAPTION     *s         The SWAPTION data structure
*
*   output
*
*   returns     Valid_data if the content of s is valid
*
*   diagnostics
*
*   see also    SWAPTION
*
*************************************************************************
,,EOH,,*/

VALIDATE Validate_SWAPTION(SWAPTION* s)
{
    VALIDATE v ;

    if (!Validate_OPTTYPE(s->type))
        return Invalid_opttype ;

    if (Cldr_CheckDate(&s->maturity) == False)
        return Invalid_date ;

    if (!Validate_CALCONV(s->cal))
        return Invalid_cal ;

    if (!Validate_BOOLE(s->swapstl))
        return Invalid_boole ;

    v = Validate_FIXRATE(&s->fix) ;
    if (v != Valid_data)
        return v ;

    v = Validate_PAYDAYDEF(&s->pfix, False) ;
    if (v != Valid_data)
        return v ;

    if (!Validate_BOOLE(s->vanilla))
        return Invalid_boole ;

    if (s->vanilla == False)
    {
        v = Validate_FLOATBASE(&s->fbase) ;
        if (v != Valid_data)
            return v ;

        v = Validate_RATEINDEX(&s->index) ;
        if (v != Valid_data)
            return v ;

        v = Validate_PAYDAYDEF(&s->pfl, False) ;
        if (v != Valid_data)
            return v ;

        v = Validate_PLAN_STR(s->amort);
        if (v != Valid_data)
            return v ;
        else
        {
            v = Validate_PLAN_STR_SUM100(s->amort) ;
            if (v != Valid_data)
                return v ;
        }

        if (s->oadd != NO_OPTADD)
        {
            if (s->oadd == BINARY)
            {
                v = Validate_BINARYINF(&s->bini) ;
                if (v != Valid_data)
                    return v ;
            }
            else if (s->oadd == CONTPREM)
            {
                v = Validate_CONTPREMINF(&s->ctp) ;
                if (v != Valid_data)
                    return v ;
            }
            else if (s->oadd == COMPOPT)
            {
                v = Validate_COMPOPTINF(&s->compo) ;
                if (v != Valid_data)
                    return v ;
            }
            else if (s->oadd == FWDSTART)
            {
                v = Validate_FWDSTARTINF(&s->fwdst, &s->maturity, True) ;
                if (v != Valid_data)
                    return v ;
            }
            else if (s->oadd == CHOOSER)
            {
                v = Validate_CHOOSERINF(&s->chos, &s->maturity, True) ;
                if (v != Valid_data)
                    return v ;
            }
            else
                return Invalid_optadd ;
        }
    }

    return Valid_data ;
}




/*,,SOH,,
************************************************************************
*                                                                       
*               Validate_CAPARRAY()                                
*                                                                       
*   interface   #include <capvl.h>                                   
*               VALIDATE Validate_CAPARRAY(CAPARRAY  cm,      
*                                             INTI n)                   
*                                                                       
*   general     This function validates the content of the 
*               CAPARRAY data structure
*                                                                       
*   input       CAPARRAY cm     The CAPARRAY data structure   
*               INTI        n      The size of the array                
*                                                                       
*   output                                                              
*                                                                       
*   returns     Valid_data if the content of CAP is valid,           
*                                                                       
*   diagnostics                                                         
*                                                                       
*   see also    CAPARRAY                                           
*                                                                       
************************************************************************
,,EOH,,*/


VALIDATE Validate_CAPARRAY(CAPARRAY cm, INTI n)
{
    VALIDATE v = Valid_data ;
    INTI i ;

    for (i = 0; i < n && v == Valid_data; i++)
        v = Validate_CAP(&cm[i]) ;

    return v ;
}


/*,,SOH,,
************************************************************************
*                                                                       
*               Validate_SWAPTIONARRAY()                                
*                                                                       
*   interface   #include <capvl.h>                                   
*               VALIDATE Validate_SWAPTIONARRAY(SWAPTIONARRAY  cm,      
*                                             INTI n)                   
*                                                                       
*   general     This function validates the content of the 
*               SWAPTIONARRAY data structure
*                                                                       
*   input       SWAPTIONARRAY cm     The SWAPTIONARRAY data structure   
*               INTI          n      The size of the array          
*                                                                       
*   output                                                              
*                                                                       
*   returns     Valid_data if the content of SWAPTION is valid,      
*                                                                       
*   diagnostics                                                         
*                                                                       
*   see also    SWAPTIONARRAY                                           
*                                                                       
************************************************************************
,,EOH,,*/


VALIDATE Validate_SWAPTIONARRAY(SWAPTIONARRAY cm, INTI n)
{
    VALIDATE v = Valid_data ;
    INTI i ;

    for (i = 0; i < n && v == Valid_data; i++)
        v = Validate_SWAPTION(&cm[i]) ;

    return v ;
}


/*,,SOH,,
***********************************************************************
*                                                                      
*               Validate_IRG_STR()                                     
*                                                                      
*   interface   #include <capvl.h>                                  
*               VALIDATE Validate_IRG_STR(IRG_STR *i)                  
*                                                                      
*   general     This function validates the content of the IRG_STR data
*               structure                                              
*                                                                      
*   input       IRG_STR   *i      The IRG_STR data structure           
*                                                                      
*   output                                                             
*   returns     Valid_data if the content of c is valid                
*               Invalid_opttype if type is an invalid OPTTYPE          
*               Invalid_date if fix_start, fix_end, pay_end, period_start,
*                   or period_end is an invalid date.
*               Fix_start_after_fix_end if fix_start is later than     
*                   fix_end                                            
*               Fix_start_after_pay_day if fix_start
*                is later than pay_day
*               Period_start_after_period_end if period_start is later
*               than period_end.
*               Invalid_notional if notional is <= 0                   
*               Invalid_LIBORfix if LIBORfix is <= 0                   
*                                                                      
*   diagnostics                                                        
*                                                                      
*   see also    IRG_STR                                                
*                                                                      
***********************************************************************
,,EOH,,*/


VALIDATE Validate_IRG_STR(IRG_STR* i)
{
    BOOLE ok = False ;

    if (!Validate_OPTTYPE(i->type))
        return Invalid_opttype ;

    ok = Cldr_CheckDate(&i->fix_start) ;
    ok = ok && Cldr_CheckDate(&i->fix_end) ;
    ok = ok && Cldr_CheckDate(&i->pay_day) ;
    ok = ok && Cldr_CheckDate(&i->period_start) ;
    ok = ok && Cldr_CheckDate(&i->period_end) ;
    if (ok == False)
        return Invalid_date ;

    if (Cldr_DateLE(&i->fix_start, &i->fix_end) == False)
        return Fix_start_after_fix_end ;

    if (Cldr_DateLE(&i->fix_start, &i->pay_day) == False)
        return Fix_start_after_pay_day ;

    if (Cldr_DateLE(&i->period_start, &i->period_end) == False)
        return Period_start_after_period_end ;

    if (i->size <= -valid_tol)
        return Invalid_notional ;

    if (i->LIBORfix < -valid_tol)
        return Invalid_LIBORfix ;

    return Valid_data ;
}






/*,,SOH,,
***********************************************************************
*                                                                      
*               Validate_CAPTION()
*                                                                      
*   interface   #include <capvl.h>                                  
*               VALIDATE Validate_CAPTION(CAPTION *x)
*                                                                      
*   general     This function validates the content of the CAPTION
*               data structure                                         
*                                                                      
*   input       CAPTION *x   The Caption structure.
*                                                                      
*   output                                                             
*                                                                      
*   returns     Valid_data if the content of Caption is 
*               valid.
*                                                                      
*   diagnostics
*               Refer to CAPTION for a specification of valid data.
*              
*   see also    CAPTION
*                                                                      
***********************************************************************
,,EOH,,*/

VALIDATE Validate_CAPTION(CAPTION*  x)
{
    VALIDATE v;

    if (Validate_OPTTYPE(x->type) == False)
        return Invalid_opttype;

    if (Validate_BOOLE(x->berm) == False)
        return Invalid_boole;

    v = Validate_PAYDAYDEF(&x->dpay, False);
    if (v != Valid_data)
        return v;

    v = Validate_CAP(&x->cap);
    if (v != Valid_data)
        return v;

    return Valid_data;
}





/*,,SOH,,
************************************************************************
*                                                                       
*               Validate_IRGARRAY()                                
*                                                                       
*   interface   #include <capvl.h>                                   
*               VALIDATE Validate_IRGARRAY(IRGARRAY  cm,      
*                                             INTI n)                   
*                                                                       
*   general     This function validates the content of the 
*               IRGARRAY data structure
*                                                                       
*   input       IRGARRAY cm     The IRGARRAY data structure   
*               INTI        n      The size of the array                
*                                                                       
*   output                                                              
*                                                                       
*   returns     Valid_data if the content of IRG is valid,           
*                                                                       
*   diagnostics                                                         
*                                                                       
*   see also    IRGARRAY                                           
*                                                                       
************************************************************************
,,EOH,,*/


VALIDATE Validate_IRGARRAY(IRGARRAY cm, INTI n)
{
    VALIDATE v = Valid_data ;
    INTI i ;

    for (i = 0; i < n && v == Valid_data; i++)
        v = Validate_IRG_STR(&cm[i]) ;

    return v ;
}



/*,,SOH,,
***********************************************************************
*                                                                      
*               Validate_CONVTBL()
*                                                                      
*   interface   #include <capvl.h>                                  
*               VALIDATE Validate_CONVTBL(CONVTBL *x)
*                                                                      
*   general     This function validates the content of the CONVTBL
*               data structure                                         
*                                                                      
*   input       CONVTBL *x   The CONVTBL structure.
*                                                                      
*   output                                                             
*                                                                      
*   returns     Valid_data if the content of CONVTBL is 
*               valid.
*                                                                      
*   diagnostics
*               Refer to CONVTBL for a specification of valid data.
*              
*   see also    CONVTBL
*                                                                      
***********************************************************************
,,EOH,,*/
VALIDATE Validate_CONVTBL(CONVTBL*  x)
{
    VALIDATE v;

    if (Cldr_CheckDate(&x->first) == False)
        return Invalid_first;
    if (Cldr_CheckDate(&x->last) == False)
        return Invalid_last;
    if (Cldr_DateLE(&x->first, &x->last) == False)
        return First_after_last;

    if (Validate_BOOLE(x->accr_incl) == False)
        return Invalid_boole;

    if (Cldr_CheckDate(&x->hurdle_date) == False)
        return Invalid_first;
    if (Cldr_CheckDate(&x->call_date) == False)
        return Invalid_last;

/*..to be added later..    
    if (Validate_BOOLE(x->mat_conv) == False)
        return Invalid_boole;
*/

    v = Validate_FIXPAY(&x->fixp, True);
    if (v != Valid_data)
        return v;

    if (x->fixp.repay.type != BULLET)
        return Type_not_bullet;

    v = Validate_PLAN_STR(x->call_plan);
    if (v != Valid_data)
        return v ;

/*..to be added later..    
    v = Validate_PLAN_STR(x->put_plan);
    if (v != Valid_data)
        return v ;
*/

    v = Validate_PLAN_STR(x->div);
    if (v != Valid_data)
        return v ;

    if (Cldr_DateLE(&x->hurdle_date, &x->call_date) == False)
        return Call_before_hurdle;

    if (Cldr_DateLE(&x->call_date, &x->fixp.cday.last) == False)
        return Maturity_before_call;

    if (x->conv_price < -valid_tol)
        return Invalid_conversion_price;

    if (x->call_hurdle < -valid_tol)
        return Invalid_call_hurdle;

    if (x->call_price < -valid_tol)
        return Invalid_call_price;

    return Valid_data;
}


/* SCID @(#)optbond.c	1.8 (SimCorp) 99/09/29 14:19:07 */

/************************************************************************
*
*   project     SCecon
*
*   filename    optbond.c
*
*   contains    routines for bond and bond futures options
*
************************************************************************/

/***** includes ********************************************************/
#include <optbond.h>

/***** defines  ********************************************************/
#define PAYM_TOL  1.0E-10
#define SHOCKSIZE 0.01
#define MAXIT   100
#define ACC_PRICE 0.001
#define ACC_RATE  0.0001
#define MIN_VOL   0.00001
#define ACC_TERM  0.000001
#define LOW_BOUND 0.0001
#define MIN_GRAD  0.000001

/*,,SOH,,
*************************************************************************
*
*               OptFutBond_Black2P()
*
*    interface  #include <optbond.h>
*               FL64 OptFutBond_Black2P(DATESTR  *analys,
*                                       DATESTR  *voldate,
*                                       FL64     futp,
*                                       FL64     vol,
*                                       BOOLE    margin,
*                                       DATESTR  *delv,
*                                       OPTFUT   *opt,
*                                       DISCFAC  *df,
*                                       HOLI_STR *holi,
*                                       RISKSET  *risk,
*                                       FL64     *dp,
*                                       FL64     *ddp) ;
*
*    general    The routine calculates the premium for a standard
*               option on a future - using the Black76 formula
*               for a european option on a future. In addition some of
*               the Greek numbers can be computed.
*
*               Key ratios are calculated as follows:
*
*                   risk->key      dp          ddp
*                   ---------      ---         ----
*                   KEY_PRICE      Delta       Gamma
*                   KEY_PROB       Delta       Gamma
*                   KEY_MATURITY   Theta       N/A
*                   KEY_VOL        Vega        d(Vega)/d(Vol)
*                   KEY_STRIKE     d(P)/d(C)   d2(P)/d(C)2
*                   KEY_REPO       Rho         d(rho)/d(r)
*                   -----------------------------------------
*
*               The KEY_PROB numbers are alternative definitions of
*               delta and gamma. And express the in-the-moneyness of a
*               option (delta), and the sensitivity of this (gamma) to
*               variations in the underlying variable.
*
*    input      DATESTR  *analys  Pointer to analysis date (NPV date)
*
*               DATESTR  *voldate Vol calculated from this date.
*
*               FL64     futp     The futures price in percent.
*
*               FL64     vol      The annual volatility of the futures
*                                 price in percent.
*
*               BOOLE    margin   margin is True if margining is used, 
*                                 False if not (e.g. options on 
*                                 forward contracts).
*
*               DATESTR  *delv    The delivery date as output by
*                                 FutBond_DF2Price(). Only used if 
*                                 margin is False.
*
*               OPTFUT   *opt     The data defining the option.
*                                 ->oadd assumed as NO_OPTADD.
*
*               DISCFAC  *df      Discount function for discounting
*                                 the option payout.
*
*               HOLI_STR *holi    Holiday adjustment setup
*
*               RISKSET  *risk    The risk ratio definitions
*                                 Use NULL for no Greeks
*
*
*    output     FL64     *dp      Pointer to the first order derivative.*
*
*               FL64     *ddp     Pointer to the second order derivative*
*
*    returns    the option premium.
*
*    diagnostics
*
*    see also   Option_Black2P()                                    
*               OptFutBond_Black2DFp()
*               OptFutBond_Black2Impl()
*
*    wrapper    AP
*
*************************************************************************
,,EOH,,*/

FL64 OptFutBond_Black2P(DATESTR* analys,
                    DATESTR* voldate,
                    FL64    futp,
                    FL64    vol,
                    BOOLE    margin,
                    DATESTR  *delv,
                    OPTFUT*  opt,
                    DISCFAC* df,
                    HOLI_STR* holi,
                    RISKSET* risk,
                    FL64*    dp,
                    FL64*    ddp)
{
  OPTFUT option ;

  if (margin == True)
    option = *opt ;
  else
  {
    option = *opt ;
    option.dpay = *delv ;
  }

    /* Call the Standard Black Calculator */

  return Option_Black2P(analys, voldate, futp, False, 1.0, vol, &option, df,
                          holi, risk, dp, ddp) ;
}


/*,,SOH,,
*************************************************************************
*
*               OptFutBond_Black2DFp()
*
*    interface  #include <optbond.h>
*               FL64 OptFutBond_Black2DFp(DATESTR       *analys,
*                                         DATESTR       *voldate,
*                                         FL64          vol,
*                                         INTI          noas,
*                                         DFSPREADARRAY dfs,
*                                         FUTBOND       *futb,
*                                         OPTFUT        *opt,
*                                         DISCFAC       *df,
*                                         HOLI_STR      *holi,
*                                         RISKSET       *risk,
*                                         FL64          *dp,
*                                         FL64          *ddp) ;
*
*    general    The routine calculates the premium for a standard
*               option using Black 76 pricing. This routine differs
*               from OptFutBond_Black2P() in that here the futures price
*               is determined from the Zero Coupon Yield Curve.
*
*               Key ratios are calculated as follows:
*
*                   risk->key      dp          ddp
*                   ---------      ---         ----
*                   KEY_DF         $Duration   $Convexity
*                   KEY_BPV        BPV
*
*    input      DATESTR  *analys  Pointer to analysis date (NPV date)
*
*               DATESTR  *voldate Vol calculated from this date.
*
*               FL64     vol      The annual volatility of the futures
*                                 price in percent.
*
*               INTI     noas     No. of elements in dfs.
*                                 If noas > 0 and noas < futb->nbond, 
*                                 only the first noas bonds are 
*                                 considered.
*
*               DFSPREADARRAY dfs Spread of the bond against the zero
*                                 curve (df). Quoted in %.
*                                 Set to NULL if no spread
*                                 Dimension [noas]
*
*               FUTBOND  *futb    The bond data for the underlying bond.
*                                 futb->margin and futb->futp is not used
*                                 by this function.
*
*               OPTFUT   *opt     The data defining the option.
*                                 ->oadd assumed as NO_OPTADD.
*
*               DISCFAC  *df      Discount function for discounting
*                                 option payout, and for finding the
*                                 futures price using the entire bond
*                                 cashflow.
*
*               HOLI_STR *holi    Holiday adjustment setup
*
*               RISKSET  *risk    The risk ratio definitions.
*                                 Use NULL for no Greeks
*
*    output     FL64     *dp      Pointer to the first order derivative.*
*
*               FL64     *ddp     Pointer to the second order derivative*
*
*    returns    the option premium.
*
*    diagnostics
*
*    see also   Option_Black2P()                                    
*               OptFutBond_Black2P()
*               OptFutBond_Black2Impl()
*
*    wrapper    AP
*
*************************************************************************
,,EOH,,*/

FL64 OptFutBond_Black2DFp(DATESTR* analys,
                    DATESTR*  voldate,
                    FL64     vol,
                    INTI     noas,
                    DFSPREADARRAY dfs,
                    FUTBOND*  futb,
                    OPTFUT*   opt,
                    DISCFAC*  df,
                    HOLI_STR* holi,
                    RISKSET*  risk,
                    FL64*     dp,
                    FL64*     ddp)
{
    FL64     dum, futp, phi, plo, p, shock ;
    INTI     idum ;
    DATESTR  deliv ;
    DISCFAC  dfsh ;

    /* Initialize */
    *dp = *ddp = 0.0 ;

    /* Find DF based Futures price */
    futp = FutBond_DF2Price(analys, futb, noas, dfs, df, holi, NULL,
                            &dum, &dum, &idum, &deliv) ;

    /* Find the option price according to this futures price */
    p = OptFutBond_Black2P(analys, voldate, futp, vol, futb->margin, &deliv, 
      opt, df, holi, NULL, &dum, &dum) ;

    if (risk == NULL || risk->risk == ZERO_ORDER)
        return p ;

    /* Now find dollar duration / convexity */
    if (risk->key == KEY_DF || risk->key == KEY_BPV)
    {
        shock = Scutl_Default_Shock(risk->shock, risk->key) ;

		dfsh = Disc_ShockRates(df, 1.0, risk, holi);   /* PMSTA-22396 - SRIDHARA � 160502 */
        phi  = OptFutBond_Black2DFp(analys, voldate, vol, noas, dfs, futb, opt,
                                    &dfsh, holi, NULL, &dum, &dum) ;
        Free_PLANARRAY(dfsh.disc, 1) ;

		dfsh = Disc_ShockRates(df, -1.0, risk, holi);   /* PMSTA-22396 - SRIDHARA � 160502 */
        plo  = OptFutBond_Black2DFp(analys, voldate, vol, noas, dfs, futb, opt,
                                    &dfsh, holi, NULL, &dum, &dum) ;
        Free_PLANARRAY(dfsh.disc, 1) ;

        if (risk->key == KEY_BPV)
            shock = 1.0 ;

        *dp = (phi - plo) / (2.0 * shock) ;
        if (risk->risk == SECOND_ORDER && risk->key == KEY_DF)
            *ddp = (phi + plo - 2.0 * p) / SQR(shock) ;
    }

    return p ;
}


/*,,SOH,,
*************************************************************************
*
*               OptFutBond_Black2Delta()
*
*    interface  #include <optbond.h>
*               FL64ARRAY OptFutBond_Black2Delta(
*                                         DATESTR           *analys,
*                                         DATESTR           *voldate,
*                                         FL64              vol,
*                                         INTI              noas,
*                                         DFSPREADARRAY     dfs,
*                                         FUTBOND           *futb,
*                                         OPTFUT            *opt,
*                                         DISCFAC           *df,
*                                         HOLI_STR          *holi,
*                                         DELTASET          *ds) ;
*
*    general    The routine calculates the delta vector for a standard
*               option using Black 76 pricing and a Zero Coupon Yield
*               Curve for bucketing.
*
*               The delta vector represents the price differences
*               invoked by the curve shocks.
*
*    input      DATESTR   *analys Pointer to analysis date (NPV date)
*
*               DATESTR   *voldate Vol calculated from this date.
*
*               FL64      vol     The annual volatility of the futures
*                                 price in percent.
*
*               INTI      noas    No. of elements in dfs.
*                                 If noas > 0 and noas < futb->nbond, 
*                                 only the first noas bonds are 
*                                 considered.
*
*               DFSPREADARRAY dfs Spread of the bond against the zero
*                                 curve (df). Quoted in %.
*                                 Set to NULL if no spread
*                                 Dimension [noas]
*
*               FUTBOND   *futb   The bond data for the underlying bond.
*                                 futb->margin and futb->futp is not used
*                                 by this function.
*
*               OPTFUT    *opt    The data defining the option.
*                                 ->oadd assumed as NO_OPTADD.
*
*               DISCFAC   *df     Discount function for discounting
*                                 option payout, and for finding the
*                                 futures price using the entire bond
*                                 cashflow.
*
*               HOLI_STR  *holi   Holiday adjustment setup
*
*               DELTASET  *ds     The delta-defining data
*
*    output
*
*    returns    The delta vector allocated as:
*
*                         Alloc_FL64ARRAY(ds->nshock) ;
*    diagnostics
*
*    see also   OptFutBond_Black2P()
*               OptFutBond_Black2DFp()
*               OptFutBond_Black2Impl()
*
*    wrapper    AP
*
*************************************************************************
,,EOH,,*/

FL64ARRAY OptFutBond_Black2Delta(DATESTR* analys,
                    DATESTR*  voldate,
                    FL64     vol,
                    INTI     noas,
                    DFSPREADARRAY dfs,
                    FUTBOND* futb,
                    OPTFUT*   opt,
                    DISCFAC*  df,
                    HOLI_STR* holi,
                    DELTASET* ds)
{
    INTI      i ;
    FL64ARRAY dv ;
    FL64      p0, dum ;
    PLANARRAY old ;
    DATESTR   fsprev, matur ;

    /* Initialise */
    dv  = Alloc_FL64ARRAY(ds->nshock) ;
    old = df->disc ;

    /* The unshocked price */
    p0 = OptFutBond_Black2DFp(analys, voldate, vol, noas, dfs, futb, opt, df,
                              holi, NULL, &dum, &dum) ;

    /* Last relevant payday */
    matur = futb->fixp[0].rday.last ;
    for (i = 1; i < futb->nbond; i++)
      if (Cldr_DateLT(&matur, &futb->fixp[i].rday.last))
        matur = futb->fixp[i].rday.last ;

    for (i = 0; i < ds->nshock; i++)
    {
        fsprev = Disc_get_chgdate(NULL, old, &ds->shock[i]) ;

        if (fsprev.y > 0 && Cldr_DateLT(&matur, &fsprev) == False)
        {
            df->disc = &ds->shock[i] ;
            dv[i]  = OptFutBond_Black2DFp(analys, voldate, vol, noas, 
              dfs, futb, opt, df, holi, NULL, &dum, &dum) ;
            dv[i] -= p0 ;

            if (ds->zero == True)
                /* Find shocked Zero PV */
				dv[i] /= Disc_DF2BPV(&ds->mid[i], df, old, holi);   /* PMSTA-22396 - SRIDHARA � 160502 */
        }
        else
            dv[i] = 0.0 ;
    }

    df->disc = old ;

    return dv ;
}


/*,,SOH,,
*************************************************************************
*
*               OptFutBond_Black2YTMp()
*
*    interface  #include <optbond.h>
*               FL64 OptFutBond_Black2YTMp(DATESTR  *analys,
*                                          DATESTR  *voldate,
*                                          FL64     vol,
*                                          FUTBOND  *futb,
*                                          OPTFUT   *opt,
*                                          DISCFAC  *df,
*                                          FL64     ytm,
*                                          YTMCONV  *ytmc,
*                                          HOLI_STR *holi,
*                                          RISKSET  *risk,
*                                          FL64     *dp,
*                                          FL64     *ddp) ;
*
*    general    The routine calculates the premium for a standard
*               option using Black 76 pricing. This routine differs
*               from OptFutBond_Black2P() in that here the futures price*
*               is determined from a yield to maturity (ytm).
*
*               Only 1 bond is entered here. In case of CTD futures this*
*               should then be the current CTD bond.
*
*               Key ratios are calculated as follows:
*
*                   risk->key      dp          ddp
*                   ---------      ---         ----
*                   KEY_YTM        $Duration   $Convexity
*                   KEY_BPV        BPV(YTM)
*
*    input      DATESTR  *analys  Pointer to analysis date (NPV date)
*
*               DATESTR  *voldate Vol calculated from this date.
*
*               FL64     vol      The annual volatility of the futures
*                                 price in percent.
*
*               FUTBOND  *futb    The bond data for the underlying bond.
*                                 futb->margin and futb->futp is not used
*                                 by this function.
*
*               OPTFUT   *opt     The data defining the option.
*                                 ->oadd assumed as NO_OPTADD.
*
*               DISCFAC  *df      Discount function for discounting
*                                 option payout.
*
*               FL64     ytm      Yield to maturity (%) of future
*
*               YTMCONV  *ytmc    Yield to maturity conventions
*
*               HOLI_STR *holi    Holiday adjustment setup
*
*               RISKSET  *risk    The risk ratio definitions.
*                                 Use NULL for no Greeks
*
*    output     FL64     *dp      Pointer to the first order derivative.*
*
*               FL64     *ddp     Pointer to the second order derivative*
*
*    returns    the option premium.
*
*    diagnostics
*
*    see also   OptFutBond_Black2P()
*
*************************************************************************
,,EOH,,*/

FL64 OptFutBond_Black2YTMp(DATESTR* analys,
                    DATESTR*  voldate,
                    FL64     vol,
                    FUTBOND* futb,
                    OPTFUT*   opt,
                    DISCFAC*  df,
                    FL64     ytm,
                    YTMCONV*  ytmc,
                    HOLI_STR* holi,
                    RISKSET*  risk,
                    FL64*     dp,
                    FL64*     ddp)
{
    FL64     dum, futp, phi, plo, p, shock ;
    INTI     idum ;
    DATESTR  deliv ;
    DISCFAC  dfsh ;

    /* Initialize */
    *dp = *ddp = 0.0 ;

    /* Find YTM based Futures price */
    futp = FutBond_YTM2Price(analys, ytm, futb, ytmc, holi, ZERO_ORDER,
                             &dum, &dum, &idum, &deliv) ;

    /* Find the option price according to this futures price */
    p = OptFutBond_Black2P(analys, voldate, futp, vol, futb->margin, &deliv, 
      opt, df, holi, NULL, &dum, &dum) ;

    if (risk == NULL)
        return p ;

    /* Now find dollar duration / convexity */
    if (risk->risk != ZERO_ORDER)
    {

        /* Note the sloppyness wrt shocking rates with different conventions -
           basically this is due to the fact that this routine is somewhat
           out of limits */
        shock = Scutl_Default_Shock(risk->shock, risk->key) ;
		dfsh = Disc_ShockRates(df, 1.0, risk, holi);   /* PMSTA-22396 - SRIDHARA � 160502 */
        phi  = OptFutBond_Black2YTMp(analys, voldate, vol, futb, opt, &dfsh,
                                     ytm + shock, ytmc, holi, NULL, &dum, &dum);
        Free_PLANARRAY(dfsh.disc, 1) ;

		dfsh = Disc_ShockRates(df, -1.0, risk, holi);   /* PMSTA-22396 - SRIDHARA � 160502 */
        plo  = OptFutBond_Black2YTMp(analys, voldate, vol, futb, opt, &dfsh,
                                     ytm - shock, ytmc, holi, NULL, &dum, &dum);
        Free_PLANARRAY(dfsh.disc, 1) ;

        if (risk->key == KEY_BPV)
            shock = 1.0 ;

        *dp = (phi - plo) / (2.0 * shock) ;
        if (risk->risk == SECOND_ORDER && risk->key == KEY_YTM)
            *ddp = (phi + plo - 2.0 * p) / SQR(shock) ;
    }

    return p ;
}


/*,,SOH,,
*************************************************************************
*
*               OptFutBond_Black2Impl()
*
*    interface  #include <optbond.h>
*               BOOLE OptFutBond_Black2Impl(DATESTR     *analys,
*                                           DATESTR     *voldate,
*                                           FL64        prem,
*                                           BOOLE       is_p,
*                                           FL64        futp,
*                                           FL64        vol,
*                                           BOOLE       margin,
*                                           DATESTR     *delv,
*                                           OPTFUT      *opt,
*                                           DISCFAC     *df,
*                                           HOLI_STR    *holi,
*                                           KEYCONV     what,
*                                           ITERCTRL    *ctrl,
*                                           FL64        *impl) ;
*
*    general    The routine calculates the implied ratio for a standard
*               option on a future - using the Black76 formula
*               for a european option on a future.
*
*               The parameter what can be one of the following values
*
*                   what            impl
*                   ----------      ----
*                   KEY_PRICE       Implied futures price
*                   KEY_VOL         Implied volatility
*                   KEY_STRIKE      Implied strike
*
*               The argument prem can be either the option price or the
*               option delta, this is defined in is_p. Consequently
*               one can use the routine to find implied strike given
*               some delta value.
*
*    input      DATESTR  *analys  Pointer to analysis date (NPV date)
*
*               DATESTR  *voldate Vol calculated from this date.
*
*               FL64     prem     The option premium to match, quoted
*                                 on analys.
*
*               BOOLE    is_p     If True the prem is the price, if
*                                 False then prem is the option delta.
*
*               FL64     futp     The futures price in percent.
*
*               FL64     vol      The annual volatility of the futures
*                                 price in percent.
*
*               BOOLE    margin   margin is True if margining is used, 
*                                 False if not (e.g. options on 
*                                 forward contracts).
*
*               DATESTR  *delv    The delivery date as output by
*                                 FutBond_DF2Price(). Only used if 
*                                 margin is False.
*
*               OPTFUT   *opt     The data defining the option.
*                                 ->oadd assumed as NO_OPTADD.
*
*               DISCFAC  *df      Discount function for discounting
*                                 future payments.
*
*               HOLI_STR *holi    Holiday adjustment setup
*
*               KEYCONV  what     What implied ratio to find.
*
*               ITERCTRL *ctrl    Pointer to iteration control data.
*
*    output     FL64     *impl    The implied ratio.
*
*    returns    True if all is OK, and False if not.
*
*    diagnostics
*
*    see also   Option_Black2Impl()                                    
*               OptFutBond_Black2DFp()
*               OptFutBond_Black2P()
*
*    wrapper    AP
*
*************************************************************************
,,EOH,,*/


BOOLE OptFutBond_Black2Impl(DATESTR* analys,
                    DATESTR* voldate,
                    FL64    prem,
                    BOOLE   is_p,
                    FL64    futp,
                    FL64    vol,
                    BOOLE   margin,
                    DATESTR     *delv,
                    OPTFUT*  opt,
                    DISCFAC* df,
                    HOLI_STR* holi,
                    KEYCONV what,
                    ITERCTRL*  ctrl,
                    FL64*    impl)
{

  OPTFUT option ;

  if (margin == True)
    option = *opt ;
  else
  {
    option = *opt ;
    option.dpay = *delv ;
  }

  return Option_Black2Impl(analys, voldate, prem, is_p, futp, False, 1.0,
                           vol, &option, df, holi, what, ctrl, impl) ;
}


/*,,SOH,,
*************************************************************************
*
*               OptBond_Black2P()
*
*    interface  #include <optbond.h>
*               FL64 OptBond_Black2P(DATESTR  *analys,
*                                    DATESTR  *voldate,
*                                    FL64     vol,
*                                    FL64     spot,
*                                    DFSPREAD *dfs,
*                                    FIXPAY   *fixp,
*                                    OPTFUT   *opt,
*                                    DISCFAC  *df,
*                                    HOLI_STR *holi,
*                                    RISKSET  *risk,
*                                    FL64     *dp,
*                                    FL64     *ddp) ;
*
*    general    The routine calculates the premium for an (OTC)
*               option on a bond - using the Black76 formula.
*               In addition some of the Greek numbers can be computed.
*
*               Key ratios are calculated as follows:
*
*                   risk->key      dp          ddp
*                   ---------      ---         ----
*                   KEY_SPOT       Delta       Gamma
*                   KEY_PROB       Delta       Gamma
*                   KEY_MATURITY   Theta       N/A
*                   KEY_VOL        Vega        d(Vega)/d(Vol)
*                   KEY_STRIKE     d(P)/d(C)   d2(P)/d(C)2
*                   KEY_REPO       Rho         d(rho)/d(r)
*                   -----------------------------------------
*
*               The KEY_PROB numbers are alternative definitions of
*               delta and gamma. And express the in-the-moneyness of a
*               option (delta), and the sensitivity of this (gamma) to
*               variations in the underlying variable.
*
*    input      DATESTR  *analys  Pointer to analysis date (NPV date)
*
*               DATESTR  *voldate Vol calculated from this date.
*
*               FL64     vol      The annual volatility of the futures
*                                 price in percent.
*
*               FL64     spot     The spot price in percent.
*
*               DFSPREAD *dfs     Spread of the bond against the zero
*                                 curve (df). Quoted in %.
*                                 Set to NULL if no spread
*
*               FIXPAY   *fixp    The bond data
*
*               OPTFUT   *opt     The data defining the option.
*                                 ->oadd assumed as NO_OPTADD.
*
*               DISCFAC  *df      Discount function for discounting
*
*               HOLI_STR *holi    Holiday adjustment setup
*
*               RISKSET  *risk    The risk ratio definitions
*                                 Use NULL for no Greeks
*
*    output     FL64     *dp      Pointer to the first order derivative.*
*
*               FL64     *ddp     Pointer to the second order derivative*
*
*    returns    the option premium.
*
*    diagnostics
*
*    see also   Option_Black2P()                                    
*               OptBond_Black2DFp()
*               OptBond_Black2Impl()
*
*    wrapper    AP
*
*************************************************************************
,,EOH,,*/

FL64 OptBond_Black2P(DATESTR* analys,
                     DATESTR*  voldate,
                     FL64     vol,
                     FL64     spot,
                     DFSPREAD* dfs,
                     FIXPAY*   fixp,
                     OPTFUT*   opt,
                     DISCFAC*  df,
                     HOLI_STR* holi,
                     RISKSET*  risk,
                     FL64*     dp,
                     FL64*     ddp)
{
    FL64      shock, p, cf, f, adj, dt, phi, plo ;
    TRADEINFO stl ;
    INTI      ctd ;
    DATESTR   anld, vold, delv ;
    FUTBOND   futb ;
    DISCFAC   sdf ;

    cf   = 1.0 ;
    futb = Set_FUTBOND(1, &opt->dfix, 1, fixp, &cf, 0.0, True, False) ;

    adj = 1.0 ;
    if (fabs(spot) > 0.00001)
    {
        /* Find forward price on the fixing day */
        stl = bond_set_tradeinfo(analys) ;
        f   = FutBond_CC2Price(&stl, &futb, 1, &spot, 1, dfs, df, 
                              holi, &ctd, &delv) ;
		dt = Disc_Interpolation(&opt->dfix, df, holi);   /* PMSTA-22396 - SRIDHARA � 160502 */
		Disc_forwval(df, analys, &dt, holi);   /* PMSTA-22396 - SRIDHARA � 160502 */
        adj = f * dt / spot ;
    }

    /* Call the Standard Black Calculator */
    p = Option_Black2P(analys, voldate, spot, True, adj, vol, opt, df,
                       holi, risk, dp, ddp) ;

    if (risk == NULL)
        return p ;

    if (risk->key == KEY_SPOT && fabs(adj) > PAYM_TOL)
    {
        *dp  /= adj ;
        *ddp /= SQR(adj) ;
    }

    else if (risk->key == KEY_MATURITY && risk->risk != ZERO_ORDER)
    {
        /* Let time decay -> and reflect this in the dates of the DF's.
           Ie. we move the entire Term Strcuture of interest rates. */
        shock = Scutl_Default_Shock(risk->shock, risk->key) ;
		sdf = Disc_Shock_Dates(df, (INTI)shock, holi);   /* PMSTA-22396 - SRIDHARA � 160502 */
		anld = Cldr_AddDays(analys, (INTL)shock, opt->cal, holi);   /* PMSTA-22396 - SRIDHARA � 160502 */
		vold = Cldr_AddDays(voldate, (INTL)shock, opt->cal, holi);   /* PMSTA-22396 - SRIDHARA � 160502 */

        /* Calculate shocked value */
        plo = OptBond_Black2P(&anld, &vold, vol, spot, dfs, fixp, opt, &sdf,
                              holi, NULL, dp, ddp) ;

        /* Do not set ddp */
        *dp  = (plo - p) / shock ;
        *ddp = 0.0 ;

        /* Annualize */
		*dp *= (FL64)Cldr_DaysPerYear(analys, analys, 0, opt->cal, LAST, holi);   /* PMSTA-22396 - SRIDHARA � 160502 */

        /* Clean up */
        Free_PLANARRAY(sdf.disc, 1) ;
    }

    else if (risk->key == KEY_REPO && risk->risk != ZERO_ORDER)
    {
        shock = Scutl_Default_Shock(risk->shock, KEY_DF) ;
		sdf = Disc_ShockRates(df, 1.0, risk, holi);   /* PMSTA-22396 - SRIDHARA � 160502 */
        phi = OptBond_Black2P(analys, voldate, vol, spot, dfs, fixp, opt, &sdf,
                              holi, NULL, dp, ddp) ;
        Free_PLANARRAY(sdf.disc, 1) ;

		sdf = Disc_ShockRates(df, -1.0, risk, holi);   /* PMSTA-22396 - SRIDHARA � 160502 */
        plo = OptBond_Black2P(analys, voldate, vol, spot, dfs, fixp, opt, &sdf,
                              holi, NULL, dp, ddp) ;
        Free_PLANARRAY(sdf.disc, 1) ;

        *dp = (phi - plo) / (2.0 * shock);

        if (risk->risk == SECOND_ORDER)
            *ddp = (phi + plo - 2.0 * p) / SQR(shock) ;
    }

    return p ;
}


/*,,SOH,,
*************************************************************************
*
*               OptBond_Black2Impl()
*
*    interface  #include <optbond.h>
*               BOOLE OptBond_Black2Impl(DATESTR     *analys,
*                                        DATESTR     *voldate,
*                                        FL64        prem,
*                                        BOOLE       is_p,
*                                        FL64        vol,
*                                        FL64        spot,
*                                        DFSPREAD    *dfs,
*                                        FIXPAY      *fixp,
*                                        OPTFUT      *opt,
*                                        DISCFAC     *df,
*                                        HOLI_STR    *holi,
*                                        KEYCONV     what,
*                                        ITERCTRL    *ctrl, 
*                                        FL64        *impl) ;
*
*    general    The routine calculates the implied ratio for an (OTC)
*               option on a bond - using the Black76 formula.
*
*               The parameter what can be one of the following values
*
*                   what            impl
*                   ----------      ----
*                   KEY_SPOT        Implied spot price
*                   KEY_VOL         Implied volatility
*                   KEY_STRIKE      Implied strike
*
*               The argument prem can be either the option price or the
*               option delta, this is defined in is_p. Consequently
*               one can use the routine to find implied strike given
*               some delta value.
*
*    input      DATESTR  *analys  Pointer to analysis date (NPV date)
*
*               DATESTR  *voldate Vol calculated from this date.
*
*               FL64     prem     The option premium to match, quoted
*                                 on analys.
*
*               BOOLE    is_p     If True the prem is the price, if
*                                 False then prem is the option delta.
*
*               FL64     vol      The annual volatility of the futures
*                                 price in percent.
*
*               FL64     spot     The spot price in percent.
*
*               DFSPREAD *dfs     Spread of the bond against the zero
*                                 curve (df). Quoted in %.
*                                 Set to NULL if no spread
*
*               FIXPAY   *fixp    The bond data
*
*               OPTFUT   *opt     The data defining the option.
*                                 ->oadd assumed as NO_OPTADD.
*
*               DISCFAC  *df      Discount function for discounting
*                                 future payments.
*
*               HOLI_STR *holi    Holiday adjustment setup
*
*               KEYCONV  what     What implied ratio to find.
*
*               ITERCTRL *ctrl    Pointer to iteration control data.
*
*    output     FL64     *impl    The implied ratio.
*
*    returns    True if all is OK, and False if not.
*
*    diagnostics
*
*    see also   Option_Black2Impl()                                    
*               OptBond_Black2P()
*
*************************************************************************
,,EOH,,*/

BOOLE OptBond_Black2Impl(DATESTR* analys,
                    DATESTR* voldate,
                    FL64    prem,
                    BOOLE   is_p,
                    FL64    vol,
                    FL64     spot,
                    DFSPREAD* dfs,
                    FIXPAY*   fixp,
                    OPTFUT*  opt,
                    DISCFAC* df,
                    HOLI_STR* holi,
                    KEYCONV what,
                    ITERCTRL*  ctrl,
                    FL64*    impl)
{
    FL64      cf, f, adj, dt, dum ;
    TRADEINFO matur, stl ;
    INTI      ctd ;
    DATESTR   delv ;
    CFLWARRAY cflw, xcflw ;
    BOOLE     ok ;
    FUTBOND   futb ;
    EXINF     dummy ;

    *impl = 0.0 ;
    adj   = 1.0 ;
    stl   = bond_set_tradeinfo(analys) ;
    stl.nom = 100.0 ;
    matur = bond_set_tradeinfo(&opt->dfix) ;

    cf   = 1.0 ;
    futb = Set_FUTBOND(1, &opt->dfix, 1, fixp, &cf, 0.0, True, False) ;

    if (what != KEY_SPOT && fabs(spot) > 0.00001)
    {

        /* Find forward price on the fixing day */
        f   = FutBond_CC2Price(&stl, &futb, 1, &spot, 1, dfs, df, 
                            holi, &ctd, &delv) ;
		/* PMSTA-22396 - SRIDHARA � 160502 */
        dt  = Disc_Interpolation(&opt->dfix, df, holi) ;
        Disc_forwval(df, analys, &dt, holi) ;
        adj = f * dt / spot ;
        return Option_Black2Impl(analys, voldate, prem, is_p, spot, True, adj,
                                 vol, opt, df, holi, what, ctrl, impl) ;
    }

    else if (what == KEY_SPOT)
    {
        /* Find implied forward price */
        ok = Option_Black2Impl(analys, voldate, prem, is_p, spot, False, 1.0,
                               vol, opt, df, holi, KEY_PRICE, ctrl, impl) ;
        if (ok == False)
            return False ;

        /* Find corresponding spot price */
        matur.price = *impl ;
        cflw = Cflw_GenrCflw(&fixp->repay, &fixp->rday,
                              &fixp->fix, &fixp->cday, holi) ;
        xcflw = Cflw_ExtractPeriod(&stl, &matur, &fixp->fix, &fixp->cday.pseq,
                                    &fixp->accru, &fixp->exp, holi, True, cflw,
                                    &fixp->repay.pp, fixp->repay.aufab, &dummy);
        Bond_TaxAdjCflw(xcflw, &fixp->tax, &fixp->fix.effective,
                        &fixp->cday.last) ;
        *impl = Cflw_DF2Price(analys, df, xcflw, &fixp->repay.pp, holi, dfs,
                              NULL, &dum, &dum) ;

        Free_CFLWARRAY(xcflw, 1) ;
        Free_CFLWARRAY(cflw, 1) ;
    }

    return False ;
}


/*,,SOH,,
*************************************************************************
*
*               OptBond_Black2DFp()
*
*    interface  #include <optbond.h>
*               FL64 OptBond_Black2DFp(DATESTR  *analys,
*                                      DATESTR  *voldate,
*                                      FL64     vol,
*                                      DFSPREAD *dfs,
*                                      FIXPAY   *fixp,
*                                      OPTFUT   *opt,
*                                      DISCFAC  *df,
*                                      HOLI_STR *holi,
*                                      RISKSET  *risk,
*                                      FL64     *dp,
*                                      FL64     *ddp) ;
*
*    general    The routine calculates the premium for an (OTC) bond
*               option using Black 76 pricing. This routine differs
*               from OptBond_Black2P() in that here the bond price is
*               determined from the Zero Coupon Yield Curve.
*
*               Key ratios are calculated as follows:
*
*                   risk->key      dp          ddp
*                   ---------      ---         ----
*                   KEY_DF         $Duration   $Convexity
*                   KEY_BPV        BPV
*
*    input      DATESTR  *analys  Pointer to analysis date (NPV date)
*
*               DATESTR  *voldate Vol calculated from this date.
*
*               FL64     vol      The annual volatility of the futures
*                                 price in percent.
*
*               DFSPREAD *dfs     Spread of the bond against the zero
*                                 curve (df). Quoted in %.
*                                 Set to NULL if no spread
*
*               FIXPAY   *fixp    The bond data
*
*               OPTFUT   *opt     The data defining the option.
*                                 ->oadd assumed as NO_OPTADD.
*
*               DISCFAC  *df      Discount function for discounting
*                                 option payout, and for finding the
*                                 bond price using the entire bond
*                                 cashflow.
*
*               HOLI_STR *holi    Holiday adjustment setup
*
*               RISKSET  *risk    The risk ratio definitions.
*                                 Use NULL for no Greeks
*
*    output     FL64     *dp      Pointer to the first order derivative.*
*
*               FL64     *ddp     Pointer to the second order derivative*
*
*    returns    the option premium.
*
*    diagnostics
*
*    see also   OptBond_Black2P()
*               OptBond_Black2Impl()
*
*    wrapper    AP
*
*************************************************************************
,,EOH,,*/


FL64 OptBond_Black2DFp(DATESTR* analys,
                    DATESTR*  voldate,
                    FL64     vol,
                    DFSPREAD* dfs,
                    FIXPAY*   fixp,
                    OPTFUT*   opt,
                    DISCFAC*  df,
                    HOLI_STR* holi,
                    RISKSET*  risk,
                    FL64*     dp,
                    FL64*     ddp)
{
  FL64 cf = 1.0 ;
  FUTBOND futb ;

  futb = Set_FUTBOND(1, &opt->dfix, 1, fixp, &cf, 0.0, True, False) ;  
    
  return OptFutBond_Black2DFp(analys, voldate, vol, 1, dfs, &futb, opt,
                                df, holi, risk, dp, ddp) ;
}


/*,,SOH,,
*************************************************************************
*
*               OptBond_Black2Delta()
*
*    interface  #include <optbond.h>
*               FL64ARRAY OptBond_Black2Delta(DATESTR    *analys,
*                                             DATESTR    *voldate,
*                                             FL64       vol,
*                                             DFSPREAD   *dfs,
*                                             FIXPAY     *fixp,
*                                             OPTFUT     *opt,
*                                             DISCFAC    *df,
*                                             HOLI_STR   *holi,
*                                             DELTASET   *ds) ;
*
*    general    The routine calculates the delta vector for an (OTC)
*               option on a bond using Black 76 pricing and a Zero
*               Coupon Yield Curve for bucketing.
*
*               The delta vector represents the price differences
*               invoked by the curve shocks.
*
*    input      DATESTR   *analys Pointer to analysis date (NPV date)
*
*               DATESTR   *voldate Vol calculated from this date.
*
*               FL64      vol     The annual volatility of the futures
*                                 price in percent.
*
*               DFSPREAD  *dfs    Spread of the bond against the zero
*                                 curve (df). Quoted in %.
*                                 Set to NULL if no spread
*
*               FIXPAY    *fixp   The bond data
*
*               OPTFUT    *opt    The data defining the option.
*                                 ->oadd assumed as NO_OPTADD.
*
*               DISCFAC   *df     Discount function for discounting
*                                 option payout, and for finding the
*                                 futures price using the entire bond
*                                 cashflow.
*
*               HOLI_STR  *holi   Holiday adjustment setup
*
*               DELTASET  *ds     Delta-defining data
*
*    output
*
*    returns    The delta vector allocated as:
*
*                         Alloc_FL64ARRAY(ds->nshock) ;
*    diagnostics
*
*    see also   OptFutBond_Black2P()
*               OptFutBond_Black2DFp()
*               OptFutBond_Black2Impl()
*
*    wrapper    AP
*
*************************************************************************
,,EOH,,*/


FL64ARRAY OptBond_Black2Delta(DATESTR* analys,
                    DATESTR*  voldate,
                    FL64     vol,
                    DFSPREAD* dfs,
                    FIXPAY*   fixp,
                    OPTFUT*   opt,
                    DISCFAC*  df,
                    HOLI_STR* holi,
                    DELTASET* ds)
{

  FL64 cf = 1.0 ;
  FUTBOND futb ;

  futb = Set_FUTBOND(1, &opt->dfix, 1, fixp, &cf, 0.0, True, False) ; 


  return OptFutBond_Black2Delta(analys, voldate, vol, 1, dfs, &futb, opt,
                                df, holi, ds) ;
}


/*,,SOH,,
*************************************************************************
*
*               OptBond_Black2YTMp()
*
*    interface  #include <optbond.h>
*               FL64 OptBond_Black2YTMp(DATESTR  *analys,
*                                       DATESTR  *voldate,
*                                       FL64     vol,
*                                       FIXPAY   *fixp,
*                                       OPTFUT   *opt,
*                                       DISCFAC  *df,
*                                       FL64     ytm,
*                                       YTMCONV  *ytmc,
*                                       HOLI_STR *holi,
*                                       RISKSET  *risk,
*                                       FL64     *dp,
*                                       FL64     *ddp) ;
*
*    general    The routine calculates the premium for an (OTC) bond
*               option using Black 76 pricing. This routine differs
*               from OptBond_Black2P() in that here the bond price is
*               determined from the bond yield to maturity.
*
*               Key ratios are calculated as follows:
*
*                   risk->key      dp          ddp
*                   ---------      ---         ----
*                   KEY_YTM        $Duration   $Convexity
*                   KEY_BPV        BPV(YTM)
*
*    input      DATESTR  *analys  Pointer to analysis date (NPV date)
*
*               DATESTR  *voldate Vol calculated from this date.
*
*               FL64     vol      The annual volatility of the futures
*                                 price in percent.
*
*               FIXPAY   *fixp    The bond data
*
*               OPTFUT   *opt     The data defining the option.
*                                 ->oadd assumed as NO_OPTADD.
*
*               DISCFAC  *df      Discount function for discounting
*                                 option payout.
*
*               FL64     ytm      Yield to maturity (%) of bond
*                                 Quoted on analys.
*
*               YTMCONV  *ytmc    Yield to maturity conventions
*
*               HOLI_STR *holi    Holiday adjustment setup
*
*               RISKSET  *risk    The risk ratio definitions.
*                                 Use NULL for no Greeks
*
*    output     FL64     *dp      Pointer to the first order derivative.*
*
*               FL64     *ddp     Pointer to the second order derivative*
*
*    returns    the option premium.
*
*    diagnostics
*
*    see also   OptBond_Black2P()
*
*************************************************************************
,,EOH,,*/

FL64 OptBond_Black2YTMp(DATESTR* analys,
                    DATESTR*  voldate,
                    FL64     vol,
                    FIXPAY*   fixp,
                    OPTFUT*   opt,
                    DISCFAC*  df,
                    FL64     ytm,
                    YTMCONV*  ytmc,
                    HOLI_STR* holi,
                    RISKSET*  risk,
                    FL64*     dp,
                    FL64*     ddp)
{
    FL64      p, phi, plo, dum, shock, spot ;
    TRADEINFO trade ;
    DISCFAC   dfsh ;

    /* Find spot price */
    trade = bond_set_tradeinfo(analys) ;
    spot  = Bond_YTM2Price(ytm, &trade, fixp, ytmc, holi, ZERO_ORDER, False,
                           dp, ddp) ;

    /* Find option price */
    p = OptBond_Black2P(analys, voldate, vol, spot, NULL, fixp, opt, df,
                        holi, NULL, dp, ddp) ;

    if (risk == NULL)
        return p ;

    /* Find YTM base risk ratios */
    if (risk->risk != ZERO_ORDER)
    {
        /* Note the sloppyness wrt shocking rates with different conventions -
           basically this is due to the fact that this routine is somewhat
           out of limits */
        shock = Scutl_Default_Shock(risk->shock, risk->key) ;
		dfsh = Disc_ShockRates(df, 1.0, risk, holi);  /* PMSTA-22396 - SRIDHARA � 160502 */
        phi   = OptBond_Black2YTMp(analys, voldate, vol, fixp, opt, &dfsh,
                                   ytm + shock, ytmc, holi, NULL, &dum, &dum) ;
        Free_PLANARRAY(dfsh.disc, 1) ;

		dfsh = Disc_ShockRates(df, -1.0, risk, holi);  /* PMSTA-22396 - SRIDHARA � 160502 */
        plo  = OptBond_Black2YTMp(analys, voldate, vol, fixp, opt, &dfsh,
                                  ytm - shock, ytmc, holi, NULL, &dum, &dum) ;
        Free_PLANARRAY(dfsh.disc, 1) ;

        if (risk->key == KEY_BPV)
            shock = 1.0 ;

        *dp = (phi - plo) / (2.0 * shock) ;
        if (risk->risk == SECOND_ORDER && risk->key == KEY_YTM)
            *ddp = (phi + plo - 2.0 * p) / SQR(shock) ;
    }

    return p ;
}


/*,,SOH,,
*************************************************************************
*
*               OptBond_VOLBOX2Vol()
*
*    interface  #include <optbond.h>
*               FL64 OptBond_VOLBOX2Vol(DATESTR  *today,
*                                       VOLBOX   *vb,
*                                       OPTFUT   *opt,
*                                       FIXPAY   *fixp,
*                                       DISCFAC  *df,
*                                       HOLI_STR *holi) ;
*
*    general    The routine computes the volatility to be used in the
*               Black76-based bond option pricing routines.
*
*    input      DATESTR   *today  Pointer to analysis date (NPV date)
*
*               VOLBOX    *vb     The volatility surface.
*
*               OPTFUT    *opt    Pointer to option data
*
*               FIXPAY    *fixp   Pointer to bond data
*
*               DISCFAC   *df     Discount factor setup.
*
*               HOLI_STR  *holi   Businessday adjustment setup
*
*    output
*
*    returns    The volatility (as a percentage).
*
*    diagnostics
*
*    see also   OptBond_Black2P()
*
*************************************************************************
,,EOH,,*/

FL64 OptBond_VOLBOX2Vol(DATESTR* today,
                        VOLBOX*  vb,
                        OPTFUT*   opt,
                        FIXPAY*   fixp,
                        DISCFAC*  df,
                        HOLI_STR* holi)
{
    FL64    vol, s, tmp ;
    DATESTR om ;
    PERIOD  sm ;

    /* find option maturity and strike */
    om = opt->dfix ;
    s  = opt->strike ;

    /* bond maturity is the date of the last payment
        -find corresponding number of months from option expiry */
    sm.unit = MONTHS ;
    tmp     = Cldr_TermBetweenDates(&om, &fixp->cday.last, 12, vb->cal,
		vb->eom, holi);  /* PMSTA-22396 - SRIDHARA � 160502 */
    sm.num  = (INTI) (0.5 + tmp) ;

    if (sm.num <= 0)
        return 0.0 ;

    /* find corresponding vol */
    vol = Vol_Linear_Lookup(vb, today, &om, s, &sm, holi) ;

    if (vb->price_vol)
        return vol ;

    /* transform yield vol to bond price vol */
    vol = OptBond_YldVol2Pvol(vol, fixp, df, holi) ;

    return vol ;
}


/*
..Private
*/

FL64 OptBond_YldVol2Pvol(FL64 yvol, FIXPAY* fixp, DISCFAC* df, 
                            HOLI_STR* holi)
{
    FL64      shock, pvol, pu, pd, dp, ddp ;
    DISCFAC   df_s ;
    TRADEINFO trade ;
    RISKSET   risk ;

    trade = bond_set_tradeinfo(df->disc->day) ;
    risk  = Set_RISKSET(KEY_DF, ZERO_ORDER, Scutl_Default_Shock(-1.0, KEY_DF),
                        COMPOUND, ANNUALLY, NULL, True) ;
    shock = Scutl_Default_Shock(risk.shock, KEY_DF) ;

	df_s = Disc_Logshock_Rates(df, 1.0, &risk, holi);  /* PMSTA-22396 - SRIDHARA � 160502 */
    pu   = Bond_DF2Price(df->disc->day, &trade, fixp, &df_s, holi, NULL,
                         &risk, &dp, &ddp) ;
    Free_PLANARRAY(df_s.disc, 1) ;

	df_s = Disc_Logshock_Rates(df, -1.0, &risk, holi);  /* PMSTA-22396 - SRIDHARA � 160502 */
    pd   = Bond_DF2Price(df->disc->day, &trade, fixp, &df_s, holi, NULL,
                         &risk, &dp, &ddp) ;
    Free_PLANARRAY(df_s.disc, 1) ;

    pvol  = yvol ;
    pvol *= (pd - pu) / (2.0 * shock) ;
    pvol /= (pd + pu) ? (pd + pu) / 2.0 : 1.0 ;

    return pvol ;
}


/*,,SOH,,
*************************************************************************
*
*               OptFutBond_VOLBOX2Vol()
*
*    interface  #include <optbond.h>
*               FL64 OptFutBond_VOLBOX2Vol(DATESTR  *today,
*                                          VOLBOX   *vb,
*                                          OPTFUT   *opt,
*                                          FIXPAY   *fixp,
*                                          DISCFAC  *df,
*                                          HOLI_STR *holi) ;
*
*    general    The routine computes the volatility to be used in the
*               Black76-based bond futures option pricing routines.
*
*    input      DATESTR   *today  Pointer to analysis date (NPV date)
*
*               VOLBOX    *vb     The volatility surface.
*
*               OPTFUT    *opt    Pointer to option data
*
*               FIXPAY    *fixp   Pointer to bond data
*
*               DISCFAC   *df     Discount factor setup.
*
*               HOLI_STR  *holi   Businessday adjustment setup
*
*    output
*
*    returns    The volatility (as a percentage).
*
*    diagnostics
*
*    see also   OptFutBond_Black2P()
*
*************************************************************************
,,EOH,,*/

FL64 OptFutBond_VOLBOX2Vol(DATESTR* today,
                       VOLBOX*  vb,
                       OPTFUT*   opt,
                       FIXPAY*   fixp,
                       DISCFAC*  df,
                       HOLI_STR* holi)
{
    FL64    vol, s, tmp ;
    DATESTR    om ;
    PERIOD    sm ;

    /* find option maturity and strike */
    om = opt->dfix ;
    s  = opt->strike ;

    /* bond maturity is the date of the last payment
        -find corresponding number of months from option expiry */
    sm.unit = MONTHS ;
    tmp     = Cldr_TermBetweenDates(&om, &fixp->cday.last, 12, vb->cal,
                                    vb->eom, holi) ;  /* PMSTA-22396 - SRIDHARA � 160502 */
    sm.num  = (INTI) (tmp + 0.5) ;

    if (sm.num <= 0)
        return 0.0 ;

    /* find corresponding vol */
    vol = Vol_Linear_Lookup(vb, today, &om, s, &sm, holi) ;

    if (vb->price_vol)
        return vol ;

    /* transform yield vol to bond price vol */
    vol = OptFutBond_YldVol2FutPvol(vol, opt, fixp, df, holi) ;

    return vol ;
}


/*
..
*/

FL64 OptFutBond_YldVol2FutPvol(FL64 yvol, OPTFUT* opt, FIXPAY* fixp,
                                  DISCFAC* df, HOLI_STR* holi)
{
    FL64      shock, pvol, pu, pd, dp, ddp ;
    DISCFAC   df_s ;
    RISKSET   risk ;
    FL64      cf ;
    INTI      ctd ;
    DATESTR   delv ;
    FUTBOND   futb ;

    /* Initialise */
    cf   = 1.0 ;
    futb = Set_FUTBOND(1, &opt->dfix, 1, fixp, &cf, 0.0, True, False) ;
    risk = Set_RISKSET(KEY_DF, ZERO_ORDER, Scutl_Default_Shock(-1.0, KEY_DF),
                       COMPOUND, ANNUALLY, NULL, True) ;
    shock = Scutl_Default_Shock(risk.shock, KEY_DF) ;

	df_s = Disc_Logshock_Rates(df, 1.0, &risk, holi);  /* PMSTA-22396 - SRIDHARA � 160502 */
    pu   = FutBond_DF2Price(df->disc->day, &futb, 0, NULL, &df_s, holi,
                            &risk, &dp, &ddp, &ctd, &delv) ;
    Free_PLANARRAY(df_s.disc, 1) ;

	df_s = Disc_Logshock_Rates(df, -1.0, &risk, holi);  /* PMSTA-22396 - SRIDHARA � 160502 */
    pd   = FutBond_DF2Price(df->disc->day, &futb, 0, NULL, &df_s, holi,
                            &risk, &dp, &ddp, &ctd, &delv) ;
    Free_PLANARRAY(df_s.disc, 1) ;

    pvol  = yvol ;
    pvol *= (pd - pu) / (2.0 * shock) ;
    pvol /= (pd + pu) ? (pd + pu) / 2.0 : 1.0 ;

    return pvol ;
}


#undef MAXIT
#undef PAYM_TOL
#undef SHOCKSIZE
#undef ACC_PRICE
#undef ACC_RATE
#undef MIN_VOL
#undef ACC_TERM
#undef LOW_BOUND
#undef MIN_GRAD


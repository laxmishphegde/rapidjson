/* SCID @(#)volboot.c	1.12 (SimCorp) 99/08/16 16:01:30  */

/************************************************************************
*
*       project         SCecon Library
*
*       file name       volboot.c
*
*       contains        bootstrapping of volatility function
*
************************************************************************/

/*** includes **********************************************************/
#include <volboot.h>


/*** defines  **********************************************************/
#define IRG_EPS        0.0001

#define ZERO_TOL       0.000000001



/*,,SOH,,
*************************************************************************
*
*               Boot_PCPAR2MarginAdj()
*
*   interface   #include <volboot.h>
*               FL64ARRAY Boot_PCPAR2MarginAdj(DATESTR   *start,
*                                              BSECARRAY bsec,
*                                              DATEARRAY settle,
*                                              FL64ARRAY prices,
*                                              INTI      nsec,
*                                              DISCFAC   *df,
*                                              VOL_STR   *vol,
*                                              HOLI_STR  *holi)
*
*   general     The function computes the Margin Adjustment sometimes
*               needed for Interest Rate Futures when bootstrapping.
*
*               The method employed is to employ the Put-Call Parity
*               to back out the forward rate adjustment needed for
*               futures.
*
*               The benefits of this model is that the vols can be taken*
*               directly from market data (i.e. FORWFORW cap/floor vols)*
*               and no 'fudgeable' data need to be entered.
*
*   input       DATESTR   *start   The analysis date
*
*               BSECARRAY bsec     The list of securities to use for
*                                  bootstrapping (nsec securities).
*
*               DATEARRAY settle   List of contract settlement dates.
*                                  Array with nsec entries.
*                                  Any settle day must satisfy:
*
*                                       start <= settle[i]
*
*               FL64ARRAY prices   List of contract price quotes.
*                                  Array with nsec entries.
*
*               INTI      nsec     The number of securities in bsec
*
*               DISCFAC   *df      Discount factor curve.
*                                  E.g. the swap/deposit based curve
*
*               VOL_STR   *vol     Vols of forward rates.
*                                  Eg. Cap/Floor (average) FORWFORW vols*
*
*               HOLI_STR  *holi    Business day adjustment setup.
*
*   output
*
*   returns     List of Margin Adjustment's for all securities, 0 if
*               not an IRF. Set as a rate change in percent.
*               Allocated in the routine as Alloc_FL64ARRAY(nsec).
*
*   diagnostics
*
*   see also    Boot_BSEC2DF()
*
*************************************************************************
,,EOH,,*/

/*,,SIC,,
This approach computes the margin adjustment by
comparing the IRF price with the implied forward rate
for the contracted period. This relation can be
stated using put-call parity although the importance
of volatility will vanish !

The forward rate implied by the IRF contract is

   100 - Price - MarginAdj

Consider a caplet and a floorlet covering the contract
period with strike set to

   K := 100 - Price

Let C be the caplet preset value, F the floorlet present value, 
D the discounting to end of the contract period, and dy the 
contract period year fraction. Let L be the presently observed
forward LIBOR rate for the contract period 
The put-call parity states:

  C - F = d * dy * (L - K)

The implied margin adjustment (by a number of assumptions)
is then

 MarginAdj := (F - C) / (dy * D)

Since C - F is nothing but an affine transformation
of the forward LIBOR rate, the MarginAdj will be independent
of the volatility (which is then superfluous in the function).
,,EIC,,*/
FL64ARRAY Boot_PCPAR2MarginAdj(DATESTR* start,
                               BSECARRAY  bsec,
                               DATEARRAY  settle,
                               FL64ARRAY  prices,
                               INTI       nsec,
                               DISCFAC*    df,     /* For Cap/Floorlet pv */
                               VOL_STR*    vol,    /* FORWFORW vol */
                               HOLI_STR*   holi)
{
    INTI       mon, days, ix, i ;
    FL64       dT, alfa, dum, c, p ;
    FL64ARRAY  madj ;
    IRG_STR    irg ;
    CAPLETS    capl ;
    PMTFREQ    freq ;
    INTIARRAY  index ;

    /* Initialise */
    madj  = Alloc_FL64ARRAY(nsec) ;
    index = Boot_GenrIndex(bsec, settle, nsec, holi) ;
    mon   = 3 ;

    /* Loop over IRF's */
    for (ix = 0; ix < nsec; ix++)
    {
        i = index[ix] ;

        /* Only adjust futures */
        if (bsec[i].type != IRF || ix == 0)
            continue ;

        /* Generate fictitious caplet */
        irg  = Set_IRG_STR(CALL, 100.0 - prices[i],  &bsec[i].start,
                           &bsec[i].maturity, NULL, NULL, NULL, 100.0, 0.0) ;
        days = Cldr_DaysBetweenDates(&bsec[i].start, &bsec[i].maturity, 
                                     ACTACT, NULL) ;  /* PMSTA-22396 - SRIDHARA � 160502 */
        if (days > 0)
            mon  = (INTI) (0.5 + (FL64) (360 / days) ) ;

        freq = Cflw_Months2PmtFreq(mon) ;
        capl = Set_CAPLETS(1, bsec[i].cal, bsec[i].eom, Q_FLAT,
                           freq, &irg, NULL, NONE, NO_FREQUENCY) ;

        c = Caplets_Black2P(start, start, &capl, df, df, vol, NULL,
                            holi, NULL, &dum, &dum) ;

        /* Generate fictitious floorlet */
        irg.type = PUT ;
        p = Caplets_Black2P(start, start, &capl, df, df, vol, NULL,
                            holi, NULL, &dum, &dum) ;

		/* PMSTA-22396 - SRIDHARA � 160502 */
        /* Invoke put-call parity */
        alfa = Cldr_TermBetweenDates(&bsec[i].start, &bsec[i].maturity,
                                     0, bsec[i].cal, LAST, holi) ;
        dT   = Disc_Interpolation(&bsec[i].maturity, df, holi) ;

        if (fabs(alfa * dT) > ZERO_TOL)
            madj[i] = (p - c) / (alfa * dT) ;
        else
            madj[i] = 0.0 ;
    }
    
    /* Clean up */
    Free_INTIARRAY(index) ;

    return madj ;
}


/*,,SOH,,
*************************************************************************
*
*               Boot_Caplets2B76Vol()
*
*    interface  #include <volboot.h>
*               BOOLE Boot_Caplets2B76Vol(CAPLETSARRAY   cap,
*                                         INTI           ncap,
*                                         FL64ARRAY      prices,
*                                         DISCFAC        *df_index,
*                                         DISCFAC        *df_disc,
*                                         CALCONV        cal,
*                                         VOLCONV        vc,
*                                         VOL_STR        *vol) ;
*
*    general    The routine bootstrappes a forward volatility curve
*               from a list of quoted caps and floors using the Black 76*
*               model for the interest rate options.
*
*               Bootstrapping in this context means that the caps are
*               sorted according to maturities and then successively
*               are used to generate the forward volatilities implicit
*               in the prices.
*
*               The duration of the forward volatilities are the same as*
*               the duration of the individual IRG's in the caps.
*               So for consistency these individual duration must match,*
*               that is all IRG's are on say 3 month FRA's, and no mix
*               of FRA terms!
*
*               The function encounters 2 cases where no solution can
*               be found. Info on this is returned, the return code
*               False implies:
*
*                        No solution could be found for a given
*                        volatility, but all volatilities up to
*                        now are OK, i.e. up till nfilled - 1 in
*                        vol.
*
*               2 volatility conventions are handled - FORWFORW and
*               FORWVOL depending on user preferences and beliefs.
*
*    input      CAPLETSARRAY cap  The list of quoted cap/floor's
*                                 The index elements are NOT used, only
*                                 simple caps are supported
*
*               INTI      ncap    The number of cap's
*
*               FL64ARRAY prices  The prices of the individual caps
*
*               DISCFAC   *df_index Discount function setup for getting
*                                 forward rates. The first date is the
*                                 analysis date.
*
*               DISCFAC   *df_disc Discount function for discounting
*                                 future payments. The first date is
*                                 the analysis date.
*
*               CALCONV   cal     Calendar for interpolation in vol
*
*               VOLCONV   vc      Volatility convention
*
*    output     VOL_STR   *vol    vol->vol element is allocated as:
*
*                                     Alloc_PLANARRAY(1, ncap)
*
*                                 in this routine.
*                                 vol->cal and vol->vc are also set.
*
*    returns    True if all is OK, False if not.
*
*    diagnostics
*
*    see also   Caplets_Black2Impl()
*               Caplets_Black2P()
*               Caplets_GenrIRGARRAY()
*               Boot_BSEC2DF()
*
*************************************************************************
,,EOH,,*/

BOOLE Boot_Caplets2B76Vol(CAPLETSARRAY cap,
                    INTI      ncap,
                    FL64ARRAY prices,
                    DISCFAC*   df_index,
                    DISCFAC*   df_disc,
                    CALCONV   cal,
                    VOLCONV   vc,
                    VOL_STR*   vol)
{
    INTI      ixcap, i ;
    BOOLE     ok ;
    FL64      rts ;
    HOLI_STR  holi ;
    DATESTR   ddate ;
    ITERCTRL  ictrl, ctrl ;
    INTIARRAY ixc ;
    BLCKINT   blck_data ;
    NR_ERR    err ;

    /* Allocate */
    *vol = Set_VOL_STR(NULL, cal, vc, LINEAR_FLAT_END); 
      /* LINEAR_FLAT_END is hard-wired, should be passed by argument */
    vol->vol = Alloc_PLANARRAY(1, ncap) ;

    /* Initialize */
    if (GetPlanFill(df_disc->disc) > 0)
        ddate = df_disc->disc->day[0] ;
    else
        return False ;

    Init_ITERCTRL(&ictrl);

    /* Holi  not used in Caplets_Black2P() - therefore defaults */
    holi = Set_HOLI_STR(NO_BUSADJUST, 0, NULL) ;

    /* Generate sorting index */
    ixc = Caplets_Genr_Index(cap, ncap) ;

    /* Loop over caps */
    for (ok = True, i = 0 ; i < ncap && ok == True ; i++)
    {
        ixcap = ixc[i] ;

        if (prices[ixcap] <= IRG_EPS)
            continue ;

        if (vol->vc == FORWVOL)
        {
            ok = Caplets_Black2Impl(&ddate, &ddate, prices[ixcap], 
              &cap[ixcap], df_index, df_disc, vol, NULL, &holi, 
              KEY_VOL, &ictrl, &rts) ;
            Cldr_InsertInPlan(&cap[ixcap].irg[cap[ixcap].count - 1]
              .fix_start, rts, vol->vol, True);

            /* Do not do any iteration - we have the result now */
            continue ;
        }

        /* Initialize for Newton-Raphson */
        blck_data = Blck_SetBLCKINT(&ddate, &ddate, prices[ixcap], 
          &cap[ixcap], NULL, df_index, df_disc, 0.0, vol, NULL, &holi, 
          NULL, KEY_VOL, IRG_EPS) ;
        Blck_SetITERCTRL(&ictrl, KEY_VOL, &blck_data, &ctrl, &holi);  /* PMSTA-29444 - SRIDHARA - 050318 */

        /* Result is really returned via updated vol. */
        err = Newton_Raphson(&Blck_NewtonRaphson, &blck_data, &ctrl, 
			&rts, &holi);  /* PMSTA-22396 - SRIDHARA � 160502 */
        ok = (err == NR_ROOT_FOUND ? True : False) ;

        /* Cldr_InsertInPlan(&irg[nirg - 1].fix_start, rts, vol->vol, True) ; */
    }

    Free_INTIARRAY(ixc) ;

    return ok ;
}

/*,,SOH,,
*************************************************************************
*
*               Boot_Cap2B76Vol()
*
*    interface  #include <volboot.h>
*               BOOLE Boot_Cap2B76Vol(CAPARRAY           cap,
*                                         INTI           ncap,
*                                         FL64ARRAY      prices,
*                                         DISCFAC        *df_index,
*                                         DISCFAC        *df_disc,
*                                         HOLI_STR       *holi,
*                                         CALCONV        cal,
*                                         VOLCONV        vc,
*                                         VOL_STR        *vol) ;
*
*    general    The routine bootstrappes a forward volatility curve
*               from a list of quoted caps and floors using the Black 76*
*               model for the interest rate options.
*
*               Refer to Boot_Caplets2B76Vol() for a description of the
*               Bootstrapping algorithm.
*
*    input      CAPARRAY  cap     The list of quoted cap/floor's
*                                 The index elements are NOT used, only
*                                 simple caps are supported
*                                 Dimension [ncap]
*
*               INTI      ncap    The number of cap's
*
*               FL64ARRAY prices  The prices of the individual caps
*                                 Dimension [ncap]
*
*               DISCFAC   *df_index Discount function setup for getting
*                                 forward rates. The first date is the
*                                 analysis date.
*
*               DISCFAC   *df_disc Discount function for discounting
*                                 future payments. The first date is
*                                 the analysis date.
*
*               HOLI_STR  *holi   Business day adjustment setup
*                                 Used to generate caplets.
*
*               CALCONV   cal     Calendar for interpolation in vol
*
*               VOLCONV   vc      Volatility convention
*
*    output     VOL_STR   *vol    vol->vol element is allocated as:
*
*                                     Alloc_PLANARRAY(1, ncap)
*
*                                 in this routine.
*                                 vol->cal and vol->vc are also set.
*
*    returns    True if all is OK, False if not.
*
*    diagnostics
*
*    see also   Cap_Black2Impl()
*               Cap_Black2P()
*               Boot_Caplets2B76Vol()
*
*    wrapper    AP
*
*************************************************************************
,,EOH,,*/
BOOLE Boot_Cap2B76Vol(CAPARRAY cap,
                    INTI      ncap,
                    FL64ARRAY prices,
                    DISCFAC*   df_index,
                    DISCFAC*   df_disc,
                    HOLI_STR*  holi,
                    CALCONV   cal,
                    VOLCONV   vc,
                    VOL_STR*   vol)
{
    CAPLETSARRAY  caplets;
    BOOLE         ok;
    INTI          i;

    caplets = Alloc_CAPLETSARRAY(ncap, 0, False);

    for (i = 0; i < ncap; i++)
    {
        /* Translate */
        caplets[i] = Cap_CAP2CAPLETS(&cap[i], holi) ;
    }

    ok = Boot_Caplets2B76Vol(caplets, ncap, prices, df_index,
        df_disc, cal, vc, vol);

    Free_CAPLETSARRAY(caplets, ncap);

    return ok;
}


#undef IRG_EPS

#undef ZERO_TOL

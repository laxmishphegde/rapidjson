/* SCID @(#)optrpos.c	1.7 (SimCorp) 99/06/06 10:41:42  */

/************************************************************************
*
*       Project         SCecon
*
*       file name       riskpos.c
*
*       contains        risk position calculations
*
************************************************************************/

/*** includes **********************************************************/
#include <optrpos.h>
#include <optbond.h>

/*** defines  **********************************************************/
#define DISC_TOLR  (FL64)    0.00000001
#define DIV_TOL    (FL64)    0.00000001



/*,,SOH,,
*************************************************************************
*
*               OptFutBond_Black2RiskPos()
*
*   interface   #include <optrpos.h>
*               RISKPOSLIST OptFutBond_Black2RiskPos(DATESTR   *analys,
*                                                   OPTFUT    *opt,
*                                                   FUTBOND   *futb,
*                                                   FL64      Notnal,
*                                                   DATESTR   *voldate,
*                                                   FL64      vol,
*                                                   DISCFAC   *df,
*                                                   INTI      noas,
*                                                   DFSPREADARRAY  dfs,
*                                                   HOLI_STR  *holi,
*                                                   DELTASET  *ds,
*                                                   FXRISKSET *FXr) ;
*
*   general     The routine calculates the Risk Position for an
*               option on a bond future using a list of predefined
*               shocks to the zero curve.
*
*               The Risk Position is the core input for VAR calculation.*
*               The Risk Position calculated for this position must be
*               added to the total Risk Position. Once this total Risk
*               Position is available VAR can be calculated with the
*               routine VAR_MATRIX2VAR().
*
*               The decision whether to use price or yield vol is
*               signalled in ds->zero. Note that this must be the same
*               for all risk factors encountered in the total VAR
*               calculation.
*
*               The risk factors affecting a fixed cashflow are:
*
*                   Interest Rates (Government, Swap or Money Market)
*                   FX (if Instrument CCY differs from Home CCY)
*
*               These entries are found in the returned RISKPOSLIST
*
*   input       DATESTR   *analys       The analysis date.
*
*               OPTFUT    *opt          The data defining the option.
*                                       ->oadd assumed as NO_OPTADD.
*
*               FUTBOND   *futb         The bond data for the underlying 
*                                       bond. futb->margin and 
*                                       futb->futp is not used
*                                       by this function.
*
*               FL64      Notnal        The notional holding (position)
*                                       ie. number of options times
*                                       notional of underlying.
*
*               DATESTR   *voldate      Vol calculated from this date.
*
*               FL64      vol           The annual volatility of the
*                                       futures price in percent.
*
*               DISCFAC   *df           Discounting structure setup.
*                                       The initial (unshocked) curve
*                                       should be in df->disc.
*
*               INTI      noas          No. of elements in dfs.
*                                       If noas > 0 and noas < futb->nbond, 
*                                       only the first noas bonds are 
*                                       considered.
*
*               DFSPREADARRAY dfs       Spread of the bond against the zero
*                                       curve (df). Quoted in %.
*                                       Set to NULL if no spread
*                                       Dimension [noas]
*
*               HOLI_STR  *holi         Business day adjustment setup.
*
*               DELTASET  *ds           Delta vector defining data
*                                       Set with Disc_DeltaPrep()
*
*               FXRISKSET *FXr          Data for FX risk generation
*
*   output
*
*   returns     The Risk Position allocated as:
*
*                         Alloc_RISKTOKENARRAY(ds->nshock + 1) ;
*                         Alloc_FL64ARRAY(ds->nshock + 1) ;
*
*   diagnostics
*
*   see also    Disc_DeltaPrep()
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/


RISKPOSLIST OptFutBond_Black2RiskPos(DATESTR* analys,
                                     OPTFUT*    opt,
                                     FUTBOND*   futb,
                                     FL64      Notnal,
                                     DATESTR*   voldate,
                                     FL64      vol,
                                     DISCFAC*   df,
                                     INTI       noas,
                                     DFSPREADARRAY dfs,
                                     HOLI_STR*  holi,
                                     DELTASET*  ds,
                                     FXRISKSET* FXr)
{
    RISKPOSLIST rpos ;
    FL64ARRAY    dv ;
    FL64         FX, p, dum, fac, pct ;
    INTI         allocsize, i ;

    /* Initialise */
    FX = (!SCecon_strncmp(FXr->token.ccy, FXr->home, CCY_LENGTH) ? 
            1.0 : FXr->rate) ;

    /* Allocate output */
    allocsize  = rpos.npos = ds->nshock + 1 ;
    rpos.token = Alloc_RISKTOKENARRAY(allocsize) ;
    rpos.pos   = Alloc_FL64ARRAY(allocsize) ;

    /* Generate delta vector */
    dv = OptFutBond_Black2Delta(analys, voldate, vol, noas, dfs, 
      futb, opt, df, holi, ds) ;

    /* dv wrt zeros has already been pct adjusted */
    pct = 100.0 ;

    /* Translate to Risk Position */
    for (i = 0; i < ds->nshock; i++)
    {
        /* Find adjustment factor */
		fac = Disc_DF2RiskPosFac(analys, df, ds, i, holi);  /* PMSTA-22396 - SRIDHARA � 160502 */

        /* Do the calculation */
        rpos.pos[i]   = dv[i] * fac * FX * Notnal / pct ;
        rpos.token[i] = ds->token[i] ;
    }

    /* FX risk contribution - if required */
    rpos.token[ds->nshock] = FXr->token ;

    if (!SCecon_strncmp(FXr->token.ccy, FXr->home, CCY_LENGTH) == False)
    {
        /* PV in pct in Home CCY */
        p = OptFutBond_Black2DFp(analys, voldate, vol, noas, dfs, 
          futb, opt, df, holi, NULL, &dum, &dum) ;

        /* Remember FX contribution - PV in Home CCY */
        rpos.pos[ds->nshock] = p * FX * Notnal / pct ;
    }
    else
        rpos.pos[ds->nshock] = 0.0 ;

    /* Clean up */
    Free_FL64ARRAY(dv) ;

    return rpos ;
}


/*,,SOH,,
*************************************************************************
*
*               OptBond_Black2RiskPos()
*
*   interface   #include <optrpos.h>
*               RISKPOSLIST OptBond_Black2RiskPos(DATESTR   *analys,
*                                                 OPTFUT    *opt,
*                                                 FIXPAY    *fixp,
*                                                 FL64      spot,
*                                                 FL64      Notnal,
*                                                 DATESTR   *voldate,
*                                                 FL64      vol,
*                                                 DISCFAC   *df,
*                                                 DFSPREAD  *dfs,
*                                                 HOLI_STR  *holi,
*                                                 DELTASET  *ds,
*                                                 FXRISKSET *FXr) ;
*
*   general     The routine calculates the Risk Position for an (OTC)
*               option on a bond using a list of predefined shocks to
*               the zero curve.
*
*               The Risk Position is the core input for VAR calculation.*
*               The Risk Position calculated for this position must be
*               added to the total Risk Position. Once this total Risk
*               Position is available VAR can be calculated with the
*               routine VAR_MATRIX2VAR().
*
*               The decision whether to use price or yield vol is
*               signalled in ds->zero. Note that this must be the same
*               for all risk factors encountered in the total VAR
*               calculation.
*
*               The risk factors affecting a fixed cashflow are:
*
*                   Interest Rates (Government, Swap or Money Market)
*                   FX (if Instrument CCY differs from Home CCY)
*
*               These entries are found in the returned RISKPOSLIST
*
*   input       DATESTR   *analys       The analysis date.
*
*               OPTFUT    *opt          The data defining the option.
*                                       ->oadd assumed as NO_OPTADD.
*
*               FIXPAY    *fixp         The bond data.
*
*               FL64      spot          The bond spot price in percent.
*
*               FL64      Notnal        The notional holding (position)
*                                       ie. number of options times
*                                       notional of underlying.
*
*               DATESTR   *voldate      Vol calculated from this date.
*
*               FL64      vol           The annual volatility of the
*                                       futures price in percent.
*
*               DISCFAC   *df           Discounting structure setup.
*                                       The initial (unshocked) curve
*                                       should be in df->disc.
*
*               DFSPREAD  *dfs          Spread against the curve.
*
*               HOLI_STR  *holi         Business day adjustment setup.
*
*               DELTASET  *ds           Delta vector defining data
*                                       Set with Disc_DeltaPrep()
*
*               FXRISKSET *FXr          Data for FX risk generation
*
*   output
*
*   returns     The Risk Position allocated as:
*
*                         Alloc_RISKTOKENARRAY(ds->nshock + 1) ;
*                         Alloc_FL64ARRAY(ds->nshock + 1) ;
*
*   diagnostics
*
*   see also    Disc_DeltaPrep()
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/

RISKPOSLIST OptBond_Black2RiskPos(DATESTR* analys,
                                  OPTFUT*    opt,
                                  FIXPAY*    fixp,
                                  FL64      spot,
                                  FL64      Notnal,
                                  DATESTR*   voldate,
                                  FL64      vol,
                                  DISCFAC*   df,
                                  DFSPREAD*  dfs,
                                  HOLI_STR*  holi,
                                  DELTASET*  ds,
                                  FXRISKSET* FXr)
{
    RISKPOSLIST  rpos ;
    FL64ARRAY    dv ;
    FL64         FX, p, dum, fac, pct ;
    INTI         allocsize, i ;

    /* Initialise */
    FX = (!SCecon_strncmp(FXr->token.ccy, FXr->home, CCY_LENGTH) ? 
            1.0 : FXr->rate) ;

    /* Allocate output */
    allocsize  = rpos.npos = ds->nshock + 1 ;
    rpos.token = Alloc_RISKTOKENARRAY(allocsize) ;
    rpos.pos   = Alloc_FL64ARRAY(allocsize) ;

    /* Generate delta vector */
    dv = OptBond_Black2Delta(analys, voldate, vol, dfs, fixp, opt, df, 
                             holi, ds) ;

    /* dv wrt zeros has already been pct adjusted */
    pct = 100.0 ;

    /* Translate to Risk Position */
    for (i = 0; i < ds->nshock; i++)
    {
        /* Find adjustment factor */
		fac = Disc_DF2RiskPosFac(analys, df, ds, i, holi);  /* PMSTA-22396 - SRIDHARA � 160502 */

        /* Do the calculation */
        rpos.pos[i]   = dv[i] * fac * FX * Notnal / pct ;
        rpos.token[i] = ds->token[i] ;
    }

    /* FX risk contribution - if required */
    rpos.token[ds->nshock] = FXr->token ;

    if (!SCecon_strncmp(FXr->token.ccy, FXr->home, CCY_LENGTH) == False)
    {
        /* PV in pct in Home CCY */
        p = OptBond_Black2P(analys, voldate, vol, spot, dfs, fixp, opt, df,
                            holi, NULL, &dum, &dum) ;

        /* Remember FX contribution - PV in Home CCY */
        rpos.pos[ds->nshock] = p * FX * Notnal / pct ;
    }
    else
        rpos.pos[ds->nshock] = 0.0 ;

    /* Clean up */
    Free_FL64ARRAY(dv) ;

    return rpos ;
}


/*,,SOH,,
*************************************************************************
*
*               Caplets_Black2RiskPos()
*
*   interface   #include <optrpos.h>
*               RISKPOSLIST Caplets_Black2RiskPos(DATESTR    *analys,
*                                                 DATESTR    *voldate,
*                                                 CAPLETS    *cap,
*                                                 FL64       Notnal,
*                                                 DISCFAC    *df_index,
*                                                 DISCFAC    *df_disc,
*                                                 VOL_STR    *vol,
*                                                 CMCONVADJ  *cmadj,
*                                                 HOLI_STR   *holi,
*                                                 DELTASET   *ds_index,
*                                                 DELTASET   *ds_disc,
*                                                 FXRISKSET  *FXr) ;
*
*   general     The routine calculates the Risk Position for a cap,
*               floor or IRG using Black 76 pricing and a list of
*               predefined shocks to the zero curve.
*
*               The Risk Position is the core input for VAR calculation.*
*               The Risk Position calculated for this position must be
*               added to the total Risk Position. Once this total Risk
*               Position is available VAR can be calculated with the
*               routine VAR_MATRIX2VAR().
*
*               The decision whether to use price or yield vol is
*               signalled in ds_cflw->zero and ds_disc->zero.
*               Note that this must be the same for all risk factors
*               encountered in the total VAR calculation.
*
*               The risk factors affecting a cap are:
*
*                   Interest Rates (Government, Swap or Money Market)
*                   FX (if Instrument CCY differs from Home CCY)
*
*               These entries are found in the returned RISKPOSLIST
*
*   input       DATESTR     *analys     The analysis date.
*
*               DATESTR     *voldate    Vol calculated from this date.
*
*               CAPLETS     *cap        The cap definition.
*                                       cap->irg.->size MUST be constant*
*
*               FL64        Notnal      The notional holding (position)
*                                       Amount in Instrument CCY
*
*               DISCFAC     *df_index   Discount function setup for
*                                       finding forward rates.
*
*               DISCFAC     *df_disc    Discount function setup for
*                                       discounting future payments.
*
*               VOL_STR     *vol        Forward volatility structure.
*
*               CMCONVADJ  *cmadj       Data for Convexity Adjustment
*                                       Use NULL if no adjustment
*
*               HOLI_STR    *holi       Container for data on business
*                                       day convention and non-week-end
*                                       holidays.
*
*               DELTASET    *ds_index   Data for delta calculation
*                                       ds->dfwhich should be DF_CFLW or*
*                                       DF_BOTH.
*                                       Use DF_BOTH whenever the 2 DF's
*                                       are equal.
*
*               DELTASET    *ds_disc    Data for delta calculation
*                                       Not used if ds_cflw->dfwhich is
*                                       DF_BOTH.
*                                       ds->dfwhich should be DF_DISC.
*
*               FXRISKSET   *FXr        Data for FX risk generation
*
*   output
*
*   returns     The Risk Position allocated as:
*
*                   Alloc_RISKTOKENARRAY(ds_cflw->nshock +
*                                           ds_disc->nshock + 1) ;
*                   Alloc_FL64ARRAY(ds_cflw->nshock +
*                                           ds_disc->nshock + 1) ;
*
*   diagnostics
*
*   see also    Disc_DeltaPrep()
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/

RISKPOSLIST Caplets_Black2RiskPos(DATESTR*     analys,
                                      DATESTR*     voldate,
                                      CAPLETS*     cap,
                                      FL64         Notnal,
                                      DISCFAC*     df_index,
                                      DISCFAC*     df_disc,
                                      VOL_STR*     vol, 
                                      CMCONVADJ*   cmadj,
                                      HOLI_STR*    holi,
                                      DELTASET*    ds_index,
                                      DELTASET*    ds_disc,
                                      FXRISKSET*   FXr)
{
    RISKPOSLIST  rpos, rpostmp, rposlist ;
    FL64ARRAY    dv_index, dv_disc ;
    FL64         FX, pv, dum, fac, pct ;
    INTI         allocsize, i, nshock ;

    /* warning avoidance */
    dv_disc = NULL ;

    /* Initialise */
    FX = (!SCecon_strncmp(FXr->token.ccy, FXr->home, CCY_LENGTH) ? 
            1.0 : FXr->rate) ;

    rpostmp.npos  = 0 ;
    rpostmp.token = NULL ;
    rpostmp.pos   = NULL ;

    nshock     = ds_index->nshock + ds_disc->nshock ;
    allocsize  = nshock + 1 ;
    rpos.token = Alloc_RISKTOKENARRAY(allocsize) ;
    rpos.pos   = Alloc_FL64ARRAY(allocsize) ;
    rpos.npos  = 0 ; 
             
    /* Generate delta vector by shocking df_index */
    dv_index = Caplets_Black2Delta(analys, voldate, cap, df_index, df_disc,
                                   vol, cmadj, holi, ds_index) ;

    /* Generate delta vector by shocking df_disc */
    if (ds_index->dfwhich != DF_BOTH)
        dv_disc = Caplets_Black2Delta(analys, voldate, cap, df_index, df_disc, 
                                      vol, cmadj, holi, ds_disc) ;

    /* dv wrt zeros has already been pct adjusted */
    pct = cap->irg->size ;

    /* Translate to Risk Position (df_index) */
    for (i = 0; i < ds_index->nshock; i++)
    {
        /* Find adjustment factor */
		fac = Disc_DF2RiskPosFac(analys, df_index, ds_index, i, holi);  /* PMSTA-22396 - SRIDHARA � 160502 */

        /* Do the calculation */
        rpos.pos[i] = dv_index[i] * fac * FX * Notnal / pct ;
        VAR_RiskTokenCpy(&rpos.token[i], &ds_index->token[i]) ;
        rpos.npos += 1 ;
    }

    /* Translate to Risk Position (df_disc) */
    for (i = 0; ds_index->dfwhich != DF_BOTH && i < ds_disc->nshock ; i++)
    {
        /* Find adjustment factor */
		fac = Disc_DF2RiskPosFac(analys, df_disc, ds_disc, i, holi);  /* PMSTA-22396 - SRIDHARA � 160502 */

        /* Do the calculation */
        rpos.pos[i + ds_index->nshock] = dv_disc[i] * fac * FX * Notnal / pct ;
        VAR_RiskTokenCpy(&rpos.token[i + ds_index->nshock], &ds_disc->token[i]);
        rpos.npos += 1 ;
    }

    /* FX risk contribution - if required */
    VAR_RiskTokenCpy(&rpos.token[rpos.npos], &FXr->token) ;

    if (!SCecon_strncmp(FXr->token.ccy, FXr->home, CCY_LENGTH) == False)
    {
        /* PV in pct in Home CCY */
        pv = Caplets_Black2P(analys, voldate, cap, df_index, df_disc, vol,
                             cmadj, holi, NULL, &dum, &dum) ;

        /* Remember FX contribution - PV in Home CCY */
        rpos.pos[rpos.npos] = pv * Notnal * FX / pct ;
    }
    else
        rpos.pos[rpos.npos] = 0.0 ;

    rpos.npos += 1 ;
    rposlist = VAR_MergeRISKPOSLIST(&rpos, &rpostmp) ;

    /* Clean up */
    Free_RISKPOSLIST(&rpos) ;
    Free_RISKPOSLIST(&rpostmp) ;
    Free_FL64ARRAY(dv_index) ;
    if (ds_index->dfwhich != DF_BOTH)
        Free_FL64ARRAY(dv_disc) ;

    return rposlist ;
}


/*,,SOH,,
*************************************************************************
*
*               Cap_Black2RiskPos()
*
*   interface   #include <optrpos.h>
*               RISKPOSLIST Cap_Black2RiskPos(DATESTR     *analys,
*                                             DATESTR     *voldate,
*                                             CAP         *cap,
*                                             FL64        Notnal,
*                                             DISCFAC     *df_index,
*                                             DISCFAC     *df_disc,
*                                             VOL_STR     *vol,
*                                             CMCONVADJ   *cmadj,
*                                             HOLI_STR    *holi,
*                                             DELTASET    *ds_index,
*                                             DELTASET    *ds_disc,
*                                             FXRISKSET   *FXr) ;
*
*   general     The routine calculates the Risk Position for a cap,
*               floor or IRG using Black 76 pricing and a list of
*               predefined shocks to the zero curve.
*
*               The Risk Position is the core input for VAR calculation.*
*               The Risk Position calculated for this position must be
*               added to the total Risk Position. Once this total Risk
*               Position is available VAR can be calculated with the
*               routine VAR_MATRIX2VAR().
*
*               The decision whether to use price or yield vol is
*               signalled in ds_cflw->zero and ds_disc->zero.
*               Note that this must be the same for all risk factors
*               encountered in the total VAR calculation.
*
*               The risk factors affecting a cap are:
*
*                   Interest Rates (Government, Swap or Money Market)
*                   FX (if Instrument CCY differs from Home CCY)
*
*               These entries are found in the returned RISKPOSLIST
*
*   input       DATESTR     *analys     The analysis date.
*
*               DATESTR     *voldate    Vol calculated from this date.
*
*               CAP         *cap        The cap definition.
*                                       cap->irg.->size MUST be constant*
*
*               FL64        Notnal      The notional holding (position)
*                                       Amount in Instrument CCY
*
*               DISCFAC     *df_index   Discount function setup for
*                                       finding forward rates.
*
*               DISCFAC     *df_disc    Discount function setup for
*                                       discounting future payments.
*
*               VOL_STR     *vol        Forward volatility structure.
*
*               CMCONVADJ   *cmadj      Data for Convexity Adjustment
*                                       Use NULL if no adjustment
*
*               HOLI_STR    *holi       Container for data on business
*                                       day convention and non-week-end
*                                       holidays.
*
*               DELTASET    *ds_index   Data for delta calculation
*                                       ds->dfwhich should be DF_CFLW or*
*                                       DF_BOTH.
*                                       Use DF_BOTH whenever the 2 DF's
*                                       are equal.
*
*               DELTASET    *ds_disc    Data for delta calculation
*                                       Not used if ds_cflw->dfwhich is
*                                       DF_BOTH.
*                                       ds->dfwhich should be DF_DISC.
*
*               FXRISKSET   *FXr        Data for FX risk generation
*
*   output
*
*   returns     The Risk Position allocated as:
*
*                   Alloc_RISKTOKENARRAY(ds_cflw->nshock +
*                                           ds_disc->nshock + 1) ;
*                   Alloc_FL64ARRAY(ds_cflw->nshock +
*                                           ds_disc->nshock + 1) ;
*
*   diagnostics
*
*   see also    Disc_DeltaPrep()
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/

RISKPOSLIST Cap_Black2RiskPos(DATESTR*     analys,
                                  DATESTR*     voldate,
                                  CAP*         cap,
                                  FL64         Notnal,
                                  DISCFAC*     df_index,
                                  DISCFAC*     df_disc,
                                  VOL_STR*     vol, 
                                  CMCONVADJ*   cmadj,
                                  HOLI_STR*    holi,
                                  DELTASET*    ds_index,
                                  DELTASET*    ds_disc,
                                  FXRISKSET*   FXr)
{
    CAPLETS     capl ;
    RISKPOSLIST rpos ;

    /* Translate */
    capl = Cap_CAP2CAPLETS(cap, holi) ;

    /* Calculate */
    rpos = Caplets_Black2RiskPos(analys, voldate, &capl, Notnal, 
                                 df_index, df_disc, vol, cmadj, 
                                 holi, ds_index, ds_disc, FXr) ;

    /* Free */
    Free_IRGARRAY(capl.irg) ;

    return rpos ;
}




/*,,SOH,,
*************************************************************************
*
*               Swaption_Black2RiskPos()
*
*   interface   #include <optrpos.h>
*               RISKPOSLIST Swaption_Black2RiskPos(DATESTR    *analys,
*                                                  DATESTR    *voldate,
*                                                  FL64       vol,
*                                                  SWAPTION   *ncsw,
*                                                  FL64       Notnal,
*                                                  DISCFAC    *df,
*                                                  DISCFAC    *df_cf,
*                                                  CMCONVADJ  *cmadj,
*                                                  HOLI_STR   *holi,
*                                                  B76SWTM    *b76t,
*                                                  DELTASET   *ds,
*                                                  DELTASET   *ds_cf,
*                                                  FXRISKSET  *FXr,
*                                                  BOOLE      *ok) ;
*
*   general     The routine computes the risk position for a swaption
*               using the Black 76 model for European-Style swaptions
*               and a list of predefined shocks to the zero curve.
*               This model assumes that the option is of European type.
*
*
*               The Risk Position is the core input for VAR calculation.*
*               The Risk Position calculated for this position must be
*               added to the total Risk Position. Once this total Risk
*               Position is available VAR can be calculated with the
*               routine VAR_MATRIX2VAR().
*
*               The decision whether to use price or yield vol is
*               signalled in ds_cflw->zero and ds_disc->zero.
*               Note that this must be the same for all risk factors
*               encountered in the total VAR calculation.
*
*               The risk factors affecting a swaption are:
*
*                   Interest Rates (Government, Swap or Money Market)
*                   FX (if Instrument CCY differs from Home CCY)
*
*               These entries are found in the returned RISKPOSLIST
*
*               df_cf, ds_cf and cmadj are only used if ncsw->vanilla
*               is False.
*
*   input       DATESTR     *analys     The analysis date.
*
*               DATESTR     *voldate    Vol is calculated from this date*
*
*               FL64        vol         The volatility of the forward
*                                       starting swap's swaprate in %.
*
*               SWAPTION    *ncsw       Pointer to swaption data.
*
*               FL64        Notnal      The notional holding (position).*
*                                       Amount in Instrument CCY.
*
*               DISCFAC     *df         Discount function setup.
*
*               DISCFAC     *df_cf      Discount function for generating*
*                                       float payments (CMT).
*
*               CMCONVADJ   *cmadj      Data for Convexity Adjustment
*                                       Use NULL if no adjustment
*
*               HOLI_STR    *holi       Container for data on business
*                                       day convention and non-week-end
*                                       holidays.
*
*               B76SWTM     *b76t       Black 76 model variation to
*                                       be used.
*                                       Use NULL for default.
*
*               DELTASET    *ds         Data for delta calculation
*                                       ds->dfwhich should be DF_CFLW
*                                       or DF_BOTH.
*                                       Use DF_BOTH whenever the 2 DF's
*                                       are equal.
*
*               DELTASET    *ds_cf      Data for delta calculation
*                                       Not used if ds->dfwhich is
*                                       DF_BOTH.
*                                       ds->dfwhich should be DF_DISC.
*
*               FXRISKSET   *FXr        Data for FX risk generation
*
*   output      BOOLE       *ok         True if all OK, False if not.
*
*   returns     The Risk Position allocated as:
*
*                   Alloc_RISKTOKENARRAY(ds->nshock +
*                                           ds_cf->nshock + 1) ;
*                   Alloc_FL64ARRAY(ds->nshock + ds_cf->nshock + 1) ;
*
*   diagnostics
*
*   see also    Disc_DeltaPrep()
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/

RISKPOSLIST Swaption_Black2RiskPos(DATESTR*     analys,
                                       DATESTR*     voldate,
                                       FL64         vol, 
                                       SWAPTION*    ncsw,
                                       FL64         Notnal,
                                       DISCFAC*     df,
                                       DISCFAC*     df_cf,
                                       CMCONVADJ*   cmadj,
                                       HOLI_STR*    holi,
                                       B76SWTM*     b76t,
                                       DELTASET*    ds,
                                       DELTASET*    ds_cf,
                                       FXRISKSET*   FXr,
                                       BOOLE*       ok)
{
    RISKPOSLIST  rpos, rpostmp, rposlist ;
    FL64ARRAY    dv, dv_cf ;
    FL64         FX, pv, dum, fac, pct ;
    INTI         allocsize, i, nshock ;

    /* warning avoidance */
    dv_cf = NULL ;

    /* Initialise */
    *ok = True ;
    FX = (!SCecon_strncmp(FXr->token.ccy, FXr->home, CCY_LENGTH) ? 
            1.0 : FXr->rate) ;

    rpostmp.npos  = 0 ;
    rpostmp.token = NULL ;
    rpostmp.pos   = NULL ;

    nshock     = ds->nshock + ds_cf->nshock ;
    allocsize  = nshock + 1 ;
    rpos.token = Alloc_RISKTOKENARRAY(allocsize) ;
    rpos.pos   = Alloc_FL64ARRAY(allocsize) ;
    rpos.npos  = 0 ; 
             
    /* Generate delta vector by shocking df */
    dv = Swaption_Black2Delta(analys, voldate, vol, ncsw, df, df_cf, 
                              cmadj, holi, b76t, ds, ok) ;

    /* Generate delta vector by shocking df_cf */
    if (ds->dfwhich != DF_BOTH)
        dv_cf = Swaption_Black2Delta(analys, voldate, vol, ncsw, df, df_cf, 
                                     cmadj, holi, b76t, ds_cf, ok) ;

    /* dv wrt zeros has already been pct adjusted */
    pct = 100.0 ;

    /* Translate to Risk Position (df) */
    for (i = 0; i < ds->nshock; i++)
    {

        /* Find adjustment factor */
		fac = Disc_DF2RiskPosFac(analys, df, ds, i, holi);  /* PMSTA-22396 - SRIDHARA � 160502 */

        /* Do the calculation */
        rpos.pos[i] = dv[i] * fac * FX * Notnal / pct ;
        VAR_RiskTokenCpy(&rpos.token[i], &ds->token[i]) ;
        rpos.npos += 1 ;
    }

    /* Translate to Risk Position (df_cf) */
    for (i = 0; ds->dfwhich != DF_BOTH && i < ds_cf->nshock ; i++)
    {
        /* Find adjustment factor */
		fac = Disc_DF2RiskPosFac(analys, df_cf, ds_cf, i, holi);  /* PMSTA-22396 - SRIDHARA � 160502 */

        /* Do the calculation */
        rpos.pos[i + ds->nshock] = dv_cf[i] * fac * FX * Notnal / pct ;
        VAR_RiskTokenCpy(&rpos.token[i + ds->nshock], &ds_cf->token[i]);
        rpos.npos += 1 ;
    }

    /* FX risk contribution - if required */
    VAR_RiskTokenCpy(&rpos.token[rpos.npos], &FXr->token) ;

    if (!SCecon_strncmp(FXr->token.ccy, FXr->home, CCY_LENGTH) == False)
    {
        /* PV in pct in Home CCY */
        *ok = Swaption_Black2P(analys, voldate, vol, ncsw, df, df_cf, cmadj,
                               holi, b76t, NULL, &pv, &dum, &dum) ;

        /* Remember FX contribution - PV in Home CCY */
        rpos.pos[rpos.npos] = pv * Notnal * FX / pct ;
    }
    else
        rpos.pos[rpos.npos] = 0.0 ;

    rpos.npos += 1 ;
    rposlist = VAR_MergeRISKPOSLIST(&rpos, &rpostmp) ;

    /* Clean up */
    Free_RISKPOSLIST(&rpos) ;
    Free_RISKPOSLIST(&rpostmp) ;
    Free_FL64ARRAY(dv) ;
    if (ds->dfwhich != DF_BOTH)
        Free_FL64ARRAY(dv_cf) ;

    return rposlist ;
}

/*,,SOH,,
*************************************************************************
*
*               Convtbl_CRR2RiskPos()
*
*    interface  #include <optrpos.h>
*               RISKPOSLIST Convtbl_CRR2RiskPos(DATESTR    *analys,
*                                               FL64       spot,
*                                               FL64       vol,
*                                               INTI       nstep,
*                                               CONVTBL    *cvt,
*                                               FL64       Notnal,
*                                               FL64       beta,
*                                               RISKTOKEN *EqtyIxToken,
*                                               DISCFAC    *df,
*                                               DFSPREAD   *dfs,
*                                               DISCFAC    *divdf,
*                                               HOLI_STR   *holi,
*                                               DELTASET   *ds,
*                                               FXRISKSET  *FXr,
*                                               BOOLE      *ok) ;
*
*    general    The routine calculates the risk position for a
*               Convertible bond using the Binomial CRR method and a
*               list of predefined shocks to the zero coupon curve.
*
*               The Risk Position is the core input for VAR calculation.*
*               The Risk Position calculated for this position must be
*               added to the total Risk Position. Once this total Risk
*               Position is available VAR can be calculated with the
*               routine VAR_MATRIX2VAR().
*
*               The decision whether to use price or yield vol is
*               signalled in ds->zero. Note that this must be the same
*               for all risk factors encountered in the total VAR
*               calculation.
*
*               The risk factors affecting Convertible Bonds are:
*
*                   Interest Rates (Government, Swap or Money Market)
*                   FX (if Instrument CCY differs from Home CCY)
*
*               These entries are found in the returned RISKPOSLIST
*
*               If something goes wrong during the calculation then
*               False is returned.
*
*    input      DATESTR    *analys  Pointer to analysis date (NPV date)
*
*               FL64       spot     The unadjusted spot price
*
*               FL64       vol      The annual volatility of the Spot
*                                   price in percent.
*
*               INTI       nstep    Number of steps in the Binomial Tree*
*
*               CONVTBL    *cvt     The data defining the option.
*                                   opt->berm assumed as False.
*
*               FL64       Notnal   The notional holding (position).
*                                   Amount in Instrument CCY.
*
*               FL64       beta     Beta relative to Equity Index.
*
*               RISKTOKEN  *EqtyIxToken  Risk factor definition of
*                                        Equity Index.
*
*               DISCFAC    *df      Discount structure
*
*               DFSPREAD   *dfs     Corporate spread to 'df'
*
*               DISCFAC    *divdf   Dividend yield term structure
*                                   Alternative to using discrete-time
*                                   dividends in the argument div.
*                                   This is particularly useful when
*                                   valuing index options.
*
*               HOLI_STR   *holi    Holiday setup.
*
*               DELTASET   *ds      Data for delta calculation.
*
*               FXRISKSET  *FXr     Data for FX risk generation.
*
*    output     BOOLE      *ok      True if all ok, False if not.
*
*   returns     The Risk Position allocated as:
*
*                         Alloc_RISKTOKENARRAY(ds->nshock + 1) ;
*                         Alloc_FL64ARRAY(ds->nshock + 1) ;
*
*   diagnostics
*
*   see also    Disc_DeltaPrep()
*
*************************************************************************
,,EOH,,*/
RISKPOSLIST Convtbl_CRR2RiskPos(DATESTR*      analys,
                                    FL64          spot,
                                    FL64          vol,
                                    INTI          nstep,
                                    CONVTBL*      cvt,
                                    FL64          Notnal,
                                    FL64          beta,
                                    RISKTOKEN*    EqtyIxToken,
                                    DISCFAC*      df,
                                    DFSPREAD*     dfs,  
                                    DISCFAC*      divdf,
                                    HOLI_STR*     holi,
                                    DELTASET*     ds,
                                    FXRISKSET*    FXr,
                                    BOOLE*        ok)
{
    RISKPOSLIST  rpos ;
    FL64ARRAY    dv ;
    FL64         FX, pv, dum, fac, pct, delta ;
    INTI         allocsize, i ;
    RISKSET      risk ;

    /* Initialise */
    *ok = True ;
    FX = (!SCecon_strncmp(FXr->token.ccy, FXr->home, CCY_LENGTH) ? 
            1.0 : FXr->rate) ;

    /* Allocate output */
    allocsize  = rpos.npos = ds->nshock + 2 ;
    rpos.token = Alloc_RISKTOKENARRAY(allocsize) ;
    rpos.pos   = Alloc_FL64ARRAY(allocsize) ;

    /* Generate delta vector */
    dv = Convtbl_CRR2Delta(analys, spot, vol, nstep, cvt, df, dfs, divdf,
                           holi, ds, ok) ;

    if (*ok == False)
    {
        Free_FL64ARRAY(dv) ;
        return rpos ;
    }

    /* dv wrt zeros has already been pct adjusted */
    pct = 100.0 ;

    /* Translate to Risk Position */
    for (i = 0; i < ds->nshock; i++)
    {
        /* Find adjustment factor */
		fac = Disc_DF2RiskPosFac(analys, df, ds, i, holi);  /* PMSTA-22396 - SRIDHARA � 160502 */

        /* Do the calculation */
        rpos.pos[i]   = dv[i] * fac * FX * Notnal / pct ;
        VAR_RiskTokenCpy(&rpos.token[i], &ds->token[i]) ;
    }

    /* Eqty Index contribution */
    VAR_RiskTokenCpy(&rpos.token[ds->nshock], EqtyIxToken) ;
    risk = Set_RISKSET(KEY_PRICE, FIRST_ORDER, 0.01, ds->irr,
                       ds->freq, NULL, True) ;
   *ok  = Convtbl_CRR2Price(analys, spot, vol, nstep, cvt, df, dfs,
                             divdf, holi, &risk, &pv, &delta, &dum) ;
    rpos.pos[ds->nshock] = delta * spot * beta * FX * Notnal / pct ;

    /* FX risk contribution - if required */
    VAR_RiskTokenCpy(&rpos.token[ds->nshock + 1], &FXr->token) ;

    if (!SCecon_strncmp(FXr->token.ccy, FXr->home, CCY_LENGTH) == False)
        /* Remember FX contribution - PV in Home CCY */
        rpos.pos[ds->nshock + 1] = pv * Notnal * FX / pct ;
    else
        rpos.pos[ds->nshock + 1] = 0.0 ;

    /* Clean up */
    Free_FL64ARRAY(dv) ;

    return rpos ;
}


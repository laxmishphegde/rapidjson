/* SCID @(#)cap.c	1.20 (SimCorp) 99/08/16 15:56:50  */

/************************************************************************
*
*   project     SCecon
*
*   file name   cap.c
*
*   general     This file contains calculation routines for cap/floors
*               and other IR options.
*
************************************************************************/

#include <cap.h>


/*,,SOH,,
*************************************************************************
*
*               Cap_Simple2CAP()
*
*    interface  #include <cap.h>
*               CAP Cap_Simple2CAP(DATESTR*  today,
*                                  OPTTYPE   type,
*                                  PERIOD*   term,
*                                  PMTFREQ   freq,
*                                  FL64      strike,
*                                  CALCONV   cal,
*                                  EOMCONV   eom) ;
*
*    general    The routine generates a CAP based on simple input data.
*
*               Typically this can handle a cap / floor at issue as
*               quoted on broker pages (i.e. 5Y cap, semiannually,
*               strike 6.5)
*
*    input      DATESTR  *today   The base date
*
*               OPTTYPE  type     The option type
*
*               PERIOD   *term    The total cap term (i.e 5Y)
*
*               PMTFREQ  freq     The cap roll frequency (e.g. semiann)
*
*               FL64     strike   The cap strike rate (%)
*
*               CALCONV  cal      The payoff daycount method
*
*               EOMCONV  eom      Month end adjustment
*
*    output
*
*    returns    The CAP data type
*
*    diagnostics
*
*    see also   Cap_Black2P()
*
*************************************************************************
,,EOH,,*/

CAP Cap_Simple2CAP(DATESTR*   today,
                      OPTTYPE    type,
                      PERIOD*    term,
                      PMTFREQ    freq,
                      FL64       strike,
                      CALCONV    cal,
                      EOMCONV    eom)
{
    CAP       c ;
    PAYDAYDEF fd ;
    PAYDAYSEQ pseq ;
    INTI      m ;
    DATESTR   last ;
    HOLI_STR  holi ;

    holi = Set_HOLI_STR(NO_BUSADJUST, 0, NULL) ;
    m    = Cflw_MonthsBetweenPayments(freq) ;

    /* Last caplet period end */
    last = Cldr_AddPeriod(today, term, cal, eom, &holi) ;

    /* This is last FIXING date */
    last = Cldr_AddMonths(&last, -m, eom) ;
    pseq = Set_PAYDAYSEQ(m, MONTHS, NOODD, NOODD, ANCHOR, eom) ;
    fd   = Set_PAYDAYDEF(False, today, NULL, &last, False, &pseq, 0, NULL) ;

    c = Set_CAP(type, strike, cal, &fd, 100.0, 0.0) ;

    return c ;
}


/*,,SOH,,
*************************************************************************
*
*               Cap_CAP2CAPLETS()
*
*    interface  #include <cap.h>
*               CAPLETS Cap_CAP2CAPLETS(CAP      *cap,
*                                       HOLI_STR *holi) ;
*
*    general    The routine translates between the 2 different
*               cap / floor formats.
*
*    input      CAP      *cap     The cap definition.
*
*               HOLI_STR *holi    Holiday set-up.
*
*    output
*
*    returns    The CAPLETS data type. capl.irg is allocated as:
*               capl.irg = Alloc_IRGARRAY(capl.count) ;
*
*    diagnostics
*
*    see also   Cap_Black2P()
*
*    wrapper     AP
*
*************************************************************************
,,EOH,,*/

CAPLETS Cap_CAP2CAPLETS(CAP* cap, HOLI_STR* holi)
{
    CAPLETS   capl ;
    DATEARRAY fdays ;
    DATESTR   tmp ;
    PERIOD    per, arrears_per ;
    INTI      ns, nn, i, nfix, ix ;

    capl.oadd = NO_OPTADD ;
    capl.method   = NONE ;
    capl.compfreq = NO_FREQUENCY ;

    /* First set Fixing Days */
    fdays = Cflw_Paydays(&cap->fix_days, holi, &nfix) ;
    capl.count = nfix ;
    capl.irg   = Alloc_IRGARRAY(nfix) ;

    /* Various defaults */
    capl.cal  = cap->cal ;
    capl.eom  = cap->fix_days.pseq.eom ;
    capl.qot  = Q_FLAT ;
    if (cap->fix_days.pseq.unit == MONTHS)
        capl.freq = Cflw_Months2PmtFreq(cap->fix_days.pseq.term) ;
    else
        capl.freq = NO_FREQUENCY ;

    capl.index = Set_RATEINDEX(MMRATE, (FL64) cap->fix_days.pseq.term,
                       cap->fix_days.pseq.unit, NO_FREQUENCY, cap->cal, 0.0) ;

    per = Set_PERIOD(cap->fix_days.pseq.term, cap->fix_days.pseq.unit) ;

    capl.count = nfix ;

    /* Now set IRGARRAY */
    for (i = 0; i < nfix; i++)
    {
        capl.irg[i].type      = cap->type ;
        capl.irg[i].strike    = cap->strike ;
        capl.irg[i].size      = cap->notional ;
        capl.irg[i].LIBORfix  = cap->LIBORfix ;
        capl.irg[i].fix_start = fdays[i] ;
        capl.irg[i].period_start = capl.irg[i].fix_start ;

        if (i < nfix - 1)
            tmp = fdays[i + 1] ;
        else
        {
            if (cap->fix_days.nirreg != 0)
                /* What is the end of the last fixing period in case of 
                   irregular fixing days ? For now, just add one period 
                   to the last fixing day */
                tmp = Cldr_NextROLL(&fdays[i], ANCHOR, &per, cap->cal, 
                                    cap->fix_days.pseq.eom, holi) ;
            else
                tmp = Cldr_NextROLL(&cap->fix_days.last, 
                                    cap->fix_days.pseq.seq, &per, cap->cal, 
                                    cap->fix_days.pseq.eom, holi) ;
        }
        
        Cldr_Move2BusinessDays(&tmp, 1, holi) ;
        capl.irg[i].fix_end = tmp ;
        capl.irg[i].pay_day = tmp ;
        capl.irg[i].period_end = capl.irg[i].fix_end ;

        /* Be careful here about arrears caps */
        if (cap->vanilla == False && cap->arrears == True &&
            cap->oadd != ASIAN)
        {
            /* Pay-day is at beginning of fixing period. */
            capl.irg[i].pay_day = capl.irg[i].fix_start ;
            /* Period start is the start of the previous period. */
            if (i > 0)
              capl.irg[i].period_start = capl.irg[i-1].fix_start ;
            else
            {
              /* Period start for the first fixing. */
              arrears_per = Set_PERIOD(-cap->fix_days.pseq.term, 
                cap->fix_days.pseq.unit) ;
              tmp = (cap->fix_days.is_first ? cap->fix_days.first :
                fdays[0]) ;
              capl.irg[i].period_start = Cldr_NextROLL(&tmp, 
                cap->fix_days.pseq.seq, &arrears_per, cap->cal, 
                cap->fix_days.pseq.eom, holi) ;
              capl.irg[i].period_start = Cldr_NextBusinessDate(
                &capl.irg[i].period_start, holi) ;
            }
            /* Period end is at the beginnig of fixing period. */
            capl.irg[i].period_end = capl.irg[i].fix_start ;
        }
    }

    /* Check for Various Non-Vanilla Settings */
    if (cap->vanilla != True && nfix > 0)
    {
        nn = GetPlanFill(cap->step_not) ;
        ns = GetPlanFill(cap->step_str) ;
        capl.qot      = cap->qot ;
        capl.method   = cap->method ;
        capl.compfreq = cap->compfreq ;
        capl.index    = cap->index ;
        if (cap->margin == True)
            capl.qot = Q_FLATFORW ;

        if (ns > 0)
        {
            ix = 0;
            for (i = 0; i < nfix; i++)
            {
                capl.irg[i].strike = Cldr_PlanLookup(cap->strike, cap->step_str,
                  &fdays[i], &ix) ;
            }
        }

        if (nn > 0)
        {
            ix = 0;
            for (i = 0; i < nfix; i++)
            {
                capl.irg[i].size = Cldr_PlanLookup(cap->notional, cap->step_not,
                  &fdays[i], &ix) ;
            }
        }

        /* Set factor */
        if (SCecon_fabs(cap->factor - 1.0) > 0.0000001 &&
            cap->oadd == NO_OPTADD)
        {
            for (i = 0; i < nfix; i++)
            {
                capl.irg[i].strike = SafeDivide(capl.irg[i].strike, cap->factor,
                                                0.0000001, 0.0) ;
                capl.irg[i].size  *= cap->factor ;
            }
        }

        if (cap->delay.num != 0)
        {
            for (i = 0; i < nfix; i++)
                capl.irg[i].pay_day = Cldr_TermUnit2Date(&capl.irg[i].pay_day,
                                                         cap->delay.num,
                                                         cap->delay.unit,
                                                         cap->cal,
                                                         cap->fix_days.pseq.eom,
                                                         holi) ;
        }

        if (cap->qprice == True)
        {
            for (i = 0; i < nfix; i++)
                capl.irg[i].strike = 100.0 - capl.irg[i].strike ;
        }

        switch (cap->oadd)
        {
            /* Currently arrears not allowed for exotics */

            case NO_OPTADD:
                capl.oadd = NO_OPTADD ;
                break ;

            case BINARY:
                capl.oadd = BINARY ;
                capl.bini = Set_BINARYINF(&cap->bini.poff,
                                          cap->bini.dcadj) ;
                break ;

            case CONTPREM:
                /* Use simplest approach */
                capl.oadd = CONTPREM ;
                capl.ctp = Set_CONTPREMINF(cap->ctp.prem) ;
                break ;

            case ASIAN:
                /* Dates are not used */
                capl.oadd  = ASIAN ;
                capl.asian = Set_ASIANINF(NULL, NULL,
                                          cap->asian.num_avg,
                                          cap->asian.curr_avg,
                                          cap->asian.avgrt, 
                                          cap->asian.last_avg) ;
                break ;

            case SHARKFIN:

                /* SharkFinn barriers only */
                capl.oadd = SHARKFIN ;
                capl.sfin = Set_SHARKFININF(cap->sfin.btype, cap->sfin.barrier,
                                            cap->sfin.rebate , &cap->sfin.poff);
                break ;

            case RESET:
                capl.oadd  = RESET ;
                capl.reset = Set_RESETINF(cap->reset.spread, 
                                          cap->reset.nfirst,
                                          cap->reset.nfreq,
                                          cap->reset.delayfix,
                                          cap->reset.spread_low,
                                          cap->reset.spread_up) ;
                break ;

            default:
                capl.oadd = NO_OPTADD ;
                break ;
        }
    }

    /* Clean Up */
    Free_DATEARRAY(fdays) ;

    return capl ;
}


/*,,SOH,,
*************************************************************************
*
*               Cap_Black2P()
*
*    interface  #include <cap.h>
*               FL64 Cap_Black2P(DATESTR    *analys,
*                                DATESTR    *voldate,
*                                CAP        *cap,
*                                DISCFAC    *df_cf,
*                                DISCFAC    *df_disc,
*                                VOL_STR    *vol,
*                                CMCONVADJ  *cmadj,
*                                HOLI_STR   *holi,
*                                RISKSET    *risk,
*                                FL64       *dp,
*                                FL64       *ddp) ;
*
*    general    Cap_Black2P() computes the theoretical price for a
*               cap, floor or IRG using the Black 76 model for interest
*               rate options.
*
*               CMT/CMS Caps are handled by using a convexity adjust-
*               ment (as for CMT swaps).
*
*               Key ratios are calculated as follows:
*
*                   risk->key      dp          ddp
*                   ---------      ---         ----
*                   KEY_DF         Delta       Gamma
*                   KEY_BPV        BPV
*                   KEY_PRICE      Delta       Gamma
*                   KEY_MATURITY   Theta
*                   KEY_VOL        Vega        d(Vega)/d(Vol)
*                   KEY_STRIKE     d(P)/d(C)   d2(P)/d(C)2
*
*               where dp contains first order and ddp second order
*               ratios. C is the caprate (strike).
*
*               The delta/gammas for KEY_DF corresponds to shocks in the*
*               entire Zero Yield Curve, whereas as the delta/gammas for*
*               KEY_PRICE corresponds to shocks to the FRA rates only.
*
*               When vega is calculated CMTvol is NOT shocked.
*
*    input      DATESTR  *analys  Pointer to analysis date (NPV date)
*
*               DATESTR  *voldate Vol calculated from this date
*
*               CAP      *cap     The cap definition.
*
*               DISCFAC  *df_cf   Discount function setup for
*                                 finding forward rates.
*
*               DISCFAC  *df_disc Discount function setup for discounting*
*                                 future payments.
*
*               VOL_STR  *vol     Forward volatility structure.
*
*               CMCONVADJ *cmadj  Data for Convexity Adjustment
*                                 Use NULL if no adjustment
*
*               HOLI_STR *holi    Holiday set-up.
*
*               RISKSET  *risk    The risk ratio definitions
*                                 Use NULL for no Greeks.
*
*    output     FL64     *dp      The first order ratio
*
*               FL64     *ddp     The second order ratio.
*
*    returns    The total price of the cap/floor.
*
*    diagnostics
*
*    see also   Cap_Black2Impl()
*               Caplets_HWCF2P()
*
*    wrapper    AP
*
*************************************************************************
,,EOH,,*/

FL64 Cap_Black2P(DATESTR* analys,
                 DATESTR*   voldate,
                 CAP*       cap,
                 DISCFAC*   df_cf,
                 DISCFAC*   df_disc,
                 VOL_STR*   vol,
                 CMCONVADJ* cmadj,
                 HOLI_STR*  holi,
                 RISKSET*   risk,
                 FL64*      dp,
                 FL64*      ddp)
{
    CAPLETS     capl ;
    FL64        p ;

    /* Translate */
    capl = Cap_CAP2CAPLETS(cap, holi) ;

    /* Calculate */
    p = Caplets_Black2P(analys, voldate, &capl, df_cf, df_disc,
                        vol, cmadj, holi, risk, dp, ddp) ;

    Free_IRGARRAY(capl.irg) ;

    return p ;
}


/*,,SOH,,
*************************************************************************
*
*               Cap_Black2Delta()
*
*    interface  #include <cap.h>
*               FL64ARRAY Cap_Black2Delta(DATESTR    *analys,
*                                         DATESTR    *voldate,
*                                         CAP        *cap,
*                                         DISCFAC    *df_cf,
*                                         DISCFAC    *df_disc,
*                                         VOL_STR    *vol,
*                                         CMCONVADJ  *cmadj,
*                                         HOLI_STR   *holi,
*                                         DELTASET   *ds) ;
*
*    general    The routine calculates the delta vector for a cap, floor*
*               or IRG using Black 76 pricing and a Zero Coupon Yield
*               Curve for bucketing.
*
*               The delta vector represents the price differences
*               invoked by the curve shocks.
*
*    input      DATESTR  *analys  Pointer to analysis date (NPV date)
*
*               DATESTR  *voldate Vol calculated from this date
*
*               CAP      *cap     The cap definition.
*
*               DISCFAC  *df_cf   Discount function setup for
*                                 finding forward rates.
*
*               DISCFAC  *df_disc Discount function for discounting
*
*               VOL_STR  *vol     Forward volatility structure.
*
*               CMCONVADJ *cmadj  Data for Convexity Adjustment
*                                 Use NULL if no adjustment
*
*               HOLI_STR *holi    Holiday set-up.
*
*               DELTASET *ds      Data for delta calculation.
*
*    output
*
*    returns    The delta vector allocated as:
*
*                         Alloc_FL64ARRAY(ds->nshock) ;
*
*    diagnostics
*
*    see also   Cap_Black2Impl()
*
*    wrapper    AP
*
*************************************************************************
,,EOH,,*/

FL64ARRAY Cap_Black2Delta(DATESTR* analys,
                     DATESTR*    voldate,
                     CAP*        cap,
                     DISCFAC*    df_cf,
                     DISCFAC*    df_disc,
                     VOL_STR*    vol,
                     CMCONVADJ*  cmadj,
                     HOLI_STR*   holi,
                     DELTASET*   ds)
{
    CAPLETS   capl ;
    FL64ARRAY dv ;

    /* Translate */
    capl = Cap_CAP2CAPLETS(cap, holi) ;

    /* Calculate */
    dv = Caplets_Black2Delta(analys, voldate, &capl, df_cf, df_disc, vol,
                             cmadj, holi, ds) ;

    Free_IRGARRAY(capl.irg) ;

    return dv ;
}


/*,,SOH,,
*************************************************************************
*
*               Cap_Black2Impl()
*
*    interface  #include <cap.h>
*               BOOLE Cap_Black2Impl(DATESTR    *analys,
*                                    DATESTR    *voldate,
*                                    FL64       price,
*                                    CAP        *cap,
*                                    DISCFAC    *df_cf,
*                                    DISCFAC    *df_disc,
*                                    VOL_STR    *vol1,
*                                    CMCONVADJ  *cmadj,
*                                    HOLI_STR   *holi,
*                                    KEYCONV    what,
*                                    ITERCTRL   *ictrl,
*                                    FL64       *res) ;
*
*    general    The function calculates the implied parameter specified
*               specified by what, using the Black formula for interest
*               rate options.
*
*               The following implied ratios can be found:
*
*                   what                 implied
*                   ----                 -------
*                   KEY_VOL              Forward Volatility (FORWVOL)
*                   KEY_STRIKE           Strike Rate
*                   KEY_SIZE             Contract Size
*                   KEY_GAP              Gap
*
*               Using KEY_GAP can be used to find the contingent premium*
*               for CONTINGENT PREMIUM options (Pay Later options), that*
*               are essentially Gap Options. Use pv = 0 for this
*               purpose.
*
*               The function encounters cases where no solution can
*               be found. Info on this is returned as a False flag.
*
*    input      DATESTR   *analys Pointer to analysis date (NPV date)
*
*               DATESTR   *voldate Vol calculated from this date
*
*               FL64      price   Market price to be matched
*
*               CAP       *cap    The cap definition.
*
*               DISCFAC   *df_cf  Discount function setup for getting
*                                 forward rates.
*
*               DISCFAC   *df_disc Discount function setup for
*                                 discounting future payments.
*
*               VOL_STR   *vol1   Forward volatility structure.
*                                 Only used if what is not KEY_VOL.
*
*               CMCONVADJ *cmadj  Data for Convexity Adjustment
*                                 Use NULL if no adjustment
*
*               HOLI_STR  *holi   Holiday set-up.
*
*               KEYCONV   what    What ratios ? KEY_VOL, KEY_SIZE or
*                                 KEY_STRIKE
*
*               ITERCTRL  *ictrl  Iteration control variable.
*                                 Use defaults whenever possible.
*
*    output     FL64      *res    The implied ratio
*                                 Only set if all is OK.
*
*    returns    True if all is OK, False if not.
*
*    diagnostics
*
*    see also   Cap_Black2P()
*
*    wrapper    AP
*
*************************************************************************
,,EOH,,*/

BOOLE Cap_Black2Impl(DATESTR* analys,
                 DATESTR*   voldate,
                 FL64      price,
                 CAP*       cap,
                 DISCFAC*   df_cf,
                 DISCFAC*   df_disc,
                 VOL_STR*   vol1,
                 CMCONVADJ* cmadj,
                 HOLI_STR*  holi,
                 KEYCONV   what,
                 ITERCTRL*  ictrl,
                 FL64*      res)
{
    CAPLETS capl ;
    BOOLE   ok ;

    /* Translate */
    capl = Cap_CAP2CAPLETS(cap, holi) ;

    /* Calculate */
    ok = Caplets_Black2Impl(analys, voldate, price, &capl, df_cf, df_disc,
                            vol1, cmadj, holi, what, ictrl, res) ;

    Free_IRGARRAY(capl.irg) ;

    return ok ;
}


/*,,SOH,,
*************************************************************************
*
*               Cap_VOLBOX2Vol()
*
*    interface  #include <cap.h>
*               VOL_STR Cap_VOLBOX2Vol(DATESTR  *today,
*                                      VOLBOX    *vb,
*                                      CAP       *cap,
*                                      HOLI_STR  *holi,
*                                      BOOLE     cmt) ;
*
*    general    The routine computes the volatility to be used in the
*               Black76-based cap pricing routines.
*
*    input      DATESTR   *today  Pointer to analysis date (NPV date)
*
*               VOLBOX    *vb     The volatility surface.
*
*               CAP       *cap    Pointer to cap data
*
*               HOLI_STR  *holi   Businessday adjustment setup
*
*               BOOLE     cmt     True if interpolated vol is a CMT/CMS
*                                 surface, False if not.
*
*    output
*
*    returns    The volatility as a VOL_STR
*
*    diagnostics
*
*    see also   Cap_Black2P()
*
*************************************************************************
,,EOH,,*/

VOL_STR Cap_VOLBOX2Vol(DATESTR* today,
                       VOLBOX*   vb,
                       CAP*      cap,
                       HOLI_STR* holi,
                       BOOLE    cmt)
{
    PLANARRAY tmp;
    VOL_STR vol ;
    PERIOD  dur ;
    CAPLETS capl ;
    INTI    i ;
    FL64    v ;

    capl = Cap_CAP2CAPLETS(cap, holi) ;

    /* Set the "swap maturities" ie, the cap period */
    if (cap->vanilla || !cmt)
    {
        dur.num = cap->fix_days.pseq.term ;
        dur.unit = cap->fix_days.pseq.unit ;
    }
    else
    {
        dur.num = (INTI) (0.5 + cap->index.LIBORdur) ;
        dur.unit = cap->index.LIBORunit ;
        if (dur.unit == YEARS)
        {
            dur.num  = (INTI) (12.0 * cap->index.LIBORdur) ;
            dur.unit = MONTHS ;
        }
    }

    /* Allocate for output */
    tmp = Alloc_PLANARRAY(1, capl.count) ;

    /* Set output */
    vol = Set_VOL_STR(tmp, vb->cal, vb->volconv, vb->ipol);

    for (i = 0; i < capl.count ; i++)
    {
        v = Vol_Linear_Lookup(vb, today, &capl.irg[i].fix_start,
                              capl.irg[i].strike, &dur, holi) ;
        Cldr_InsertInPlan(&capl.irg[i].fix_start, v, vol.vol, True) ;
    }

    /* Free */
    Free_IRGARRAY(capl.irg) ;

    return vol ;
}


/*,,SOH,,
************************************************************************
*
*                Set_CAP()
*
*   interface    #include <cap.h>
*                CAP Set_CAP(OPTTYPE    type,
*                            FL64       strike,
*                            CALCONV    cal,
*                            PAYDAYDEF* fix_days,
*                            FL64       notional,
*                            FL64       LIBORfix) ;
*
*   general      This routine sets the members of the struct defined
*                in the function name. The pointer members are simply
*                assigned - without physical copying. The intention
*                of the Set_*() routines is that by using this
*                functionality, one avoids setting individual members
*                of structs in the application code.
*
*                When new members are inserted in structs the Set_*()
*                routine will be changed accordingly.
*
*                For details on the interpretation of the individual
*                struct members please check the struct definition.
*
*                The CAP filled is a vanilla cap. If more general
*                CAP types are to be defined then the individual
*                non-vanilla or exotic members must be set individually*
*                (remember to set .vanilla / .oadd accordingly).
*
*   input        OPTTYPE    type     See general section.
*
*                FL64       strike   See general section.
*
*                CALCONV    cal      See general section.
*
*                PAYDAYDEF* fix_days See general section.
*
*                FL64       notional See general section.
*
*                FL64       LIBORfix See general section.
*
*   output
*
*   returns      The filled out CAP struct
*                .vanilla is True and .oadd is NO_OPTADD.
*
*   diagnostics
*
*   see also     CAP
*
************************************************************************
,,EOH,,*/

CAP Set_CAP(OPTTYPE     type,
               FL64        strike,
               CALCONV     cal,
               PAYDAYDEF*  fix_days,
               FL64        notional,
               FL64        LIBORfix)
{
    CAP cap ;

    cap.type     = type ;
    cap.strike   = strike ;
    cap.cal      = cal ;
    cap.fix_days = *fix_days ;
    cap.notional = notional ;
    cap.LIBORfix = LIBORfix ;

    cap.vanilla  = True ;
    cap.factor   = 1.0 ;
    cap.delay    = Set_PERIOD(0, DAYS) ;        
    cap.qot      = Q_FLAT ;
    cap.index    = Set_RATEINDEX(MMRATE, (FL64) fix_days->pseq.term,
                            fix_days->pseq.unit, NO_FREQUENCY, cal, 0.0) ;
    cap.method   = NONE ;
    cap.compfreq = NO_FREQUENCY ;
    cap.arrears  = False ;
    cap.margin   = False ;
    cap.qprice   = False ;
    cap.step_str = NULL ;
    cap.step_not = NULL ;

    cap.oadd = NO_OPTADD ;

    return cap ;
}


/*,,SOH,,
*************************************************************************
*
*               Cap_Black2ATMP()
*
*    interface  #include <cap.h>
*               BOOLE Cap_Black2ATMP (DATESTR* analys,
*                                DATESTR*    voldate,
*                                FL64        atm_vol,
*                                CAP*        cap,
*                                DISCFAC*    df_cf,
*                                DISCFAC*    df_disc,
*                                CALCONV     volcal,
*                                HOLI_STR*   holi,
*                                FL64*       strike,
*                                FL64*       p)
*
*    general    This function finds the at the money cap rate and the at
*               the money premieum of a cap.
*
*               Supports only Vanilla caps (cap->vanilla should be True)
*
*    input      DATESTR  *analys  Pointer to analysis date (NPV date)
*
*               DATESTR  *voldate Vol calculated from this date
*
*               FL64     atm_vol  At the money volatility of the cap
*
*               CAP      *cap     The cap definition.
*
*               DISCFAC  *df_cf   Discount function setup for
*                                 finding forward rates.
*
*               DISCFAC  *df_disc Discount function setup for discounting*
*                                 future payments.
*
*               CALCONV  volcal   Day count convention for volatility 
*                                 computation.
*
*               HOLI_STR *holi    Holiday set-up.
*
*    output     FL64     *strike  The at the money strike.
*
*               FL64     *p       The at the money cap premium.
*
*    returns    The total price of the cap/floor.
*
*    diagnostics
*
*    see also   Cap_Black2Impl()
*               Cap_Black2P()
*               SwapFix_DF2Rate()
*
*    wrapper    AP
*
*************************************************************************
,,EOH,,*/


BOOLE Cap_Black2ATMP(DATESTR*  analys,
                      DATESTR*     voldate,
                      FL64         atm_vol,
                      CAP*         cap,
                      DISCFAC*     df_cf,
                      DISCFAC*     df_disc,
                      CALCONV      volcal,
                      HOLI_STR*    holi,
                      FL64*        strike,
                      FL64*        p)
{
  HOLI_STR  hol;
  FIXRATE   fix;
  PAYDAYDEF payday;
  SWAPFIX   sfix;
  FL64      dp, ddp;
/*  FL64      p1;*/
  CAP       cap1;
  DATESTR   first, last, first_fixing;
  PERIOD    pr;
  BOOLE     ok; 
  VOL_STR   vol;
  PLAN_STR  *vols;

  hol = *holi;
  hol.bus = NO_BUSADJUST;
  /* Dates on equivalent par swap must be found using no
     business day adjustment */
  
  pr = Set_PERIOD(cap->fix_days.pseq.term,
                  cap->fix_days.pseq.unit) ; 
  if (cap->fix_days.is_first)
    first_fixing = cap->fix_days.first;
  else
    first_fixing = Cldr_NextROLL(&cap->fix_days.first, 
                        cap->fix_days.pseq.seq,
                        &pr, cap->cal, cap->fix_days.pseq.eom, &hol) ;

  fix = Set_FIXRATE(0.0, cap->cal,
                    &first_fixing, NULL, 0.0, ODDCOUP, ODDCOUP, False,
                    False, NULL, True, NULL, NODCOMP) ;

  /* Move first and last fixing days one period ahead to get 
    first and last paydays. */

 
  first = Cldr_NextROLL(&first_fixing, cap->fix_days.pseq.seq,
                       &pr, cap->cal, cap->fix_days.pseq.eom, &hol) ;
  last = Cldr_NextROLL(&cap->fix_days.last, cap->fix_days.pseq.seq,
                       &pr, cap->cal, cap->fix_days.pseq.eom, &hol) ;
  payday = cap->fix_days;
  payday.first = first;
  payday.is_first = True;
  payday.last = last;


  sfix = Set_SWAPFIX(NULL, NULL, &fix, &payday, 0) ;

  ok = SwapFix_DF2Rate(&first_fixing, 100.0, &sfix, df_disc,
                         holi, strike) ;
  if (ok == False)
  {
    *strike = 0.0;
    *p      = 0.0;
    return False;
  }

  vols = Alloc_PLANARRAY(1,1);
  Cldr_InsertInPlan(&cap->fix_days.last, atm_vol, vols, True) ;
  vol = Set_VOL_STR (vols, volcal, FORWVOL, LINEAR_FLAT_END);

  /* Now compute premium given at the money strike */
  cap1 = *cap;
  cap1.vanilla = True;
  cap1.strike = *strike;

  *p = Cap_Black2P(analys, voldate, &cap1, df_cf, df_disc, &vol, NULL,
                   holi, NULL, &dp, &ddp) ;
/*  cap1.type = (cap1.type == CALL ? PUT : CALL);
  p1 = Cap_Black2P(analys, voldate, &cap1, df_cf, df_disc, &vol, NULL,
                   holi, NULL, &dp, &ddp) ;
*/
  Free_PLANARRAY(vols, 1);

  return True; 
}



/*,,SOH,,
************************************************************************
*
*                Set_FLEXICAPINF()
*
*   interface    #include <cap.h>
*                FLEXICAPINF Set_FLEXICAPINF(BOOLE  autoflex,
*                                    INTI n_caplets) ;
*
*   general      This routine sets the members of the struct defined
*                in the function name. The pointer members are simply
*                assigned - without physical copying. The intention
*                of the Set_*() routines is that by using this
*                functionality, one avoids setting individual members
*                of structs in the application code.
*
*                When new members are inserted in structs the Set_*()
*                routine will be changed accordingly.
*
*                For details on the interpretation of the individual
*                struct members please check the struct definition.
*
*   input        BOOLE  autoflex   See general section
*
*                INTI   n_caplets  See general section.
*
*   output
*
*   returns      The filled out FLEXICAPINF struct
*
*   diagnostics
*
*   see also     FLEXICAPINF
*
************************************************************************
,,EOH,,*/

FLEXICAPINF Set_FLEXICAPINF(BOOLE  autoflex,
                       INTI  n_caplets)
{
    FLEXICAPINF fcap ;

    fcap.autoflex = autoflex;
    fcap.n_caplets = n_caplets;

    return fcap;
}



/*
..
*/


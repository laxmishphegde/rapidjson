/* SCID @(#)convtibl.c	1.9 (SimCorp) 99/09/07 13:34:04 */

/************************************************************************
*
*   project     SCecon
*
*   filename    convtibl.c
*
*   contains    routines in the SCecon Library Options price
*               module to calculate convertible bond prices
*               based on the Cox/Ross/Rubinstein model.
*
************************************************************************/

/*** includes **********************************************************/
#include <optbond.h>


/*** defines  **********************************************************/
#define DAY_TOL   0.001
#define SHOCKSIZE 0.01
#define MAXIT   100
#define F64_TOL   0.00000001
#define ACC_PRICE 0.001
#define ACC_RATE  0.0001
#define ACC_TERM  0.000001
#define LOW_BOUND 0.0001


/*,,SOH,,
*************************************************************************
*
*               Convtbl_CRR2Price()
*
*    interface  #include <optbond.h>
*               BOOLE Convtbl_CRR2Price(DATESTR   *analys,
*                                       FL64      spot,
*                                       FL64      vol,
*                                       INTI      nstep,
*                                       CONVTBL   *cvt,
*                                       DISCFAC   *df,
*                                       DFSPREAD  *dfs,
*                                       DISCFAC   *divdf,
*                                       HOLI_STR  *holi,
*                                       RISKSET   *opt,
*                                       FL64      *p,
*                                       FL64      *dp,
*                                       FL64      *ddp) ;
*
*    general    The routine calculates the premium for a Convertible
*               bond. Using the Binomial CRR method.
*
*               Key ratios are calculated as follows:
*
*                   risk->key         dp          ddp
*                   ---------         ---         ----
*                   KEY_DF            $Duration   $Convexity
*                   KEY_BPV           BPV
*                   KEY_PRICE         Delta       Gamma
*                   KEY_MATURITY      Theta       N/A
*                   KEY_VOL           Vega        d(Vega)/d(Vol)
*                   -----------------------------------------
*
*               If something goes wrong during the calculation then
*               False is returned. Essentially this can only happen if
*               unrealistic probabilities occur.
*
*               2 ways of entering are supported: Dividend yields and
*               discrete-time dividends.
*
*    input      DATESTR  *analys  Pointer to analysis date (NPV date)
*
*               FL64     spot     The unadjusted spot price
*
*               FL64     vol      The annual volatility of the Spot
*                                 price in percent.
*
*               INTI     nstep    Number of steps in the Binomial Tree
*
*               CONVTBL  *cvt     The convertible data
*
*               DISCFAC  *df      Discount structure
*
*               DFSPREAD *dfs     Spread against df.
*
*               DISCFAC  *divdf   Dividend yield term structure
*                                 Alternative to using discrete-time
*                                 dividends in the argument div.
*                                 This is particularly useful when
*                                 valuing index options.
*
*               HOLI_STR *holi    Holiday setup
*
*               RISKSET  *opt     The risk ratio definitions
*                                 Use NULL for no Greeks
*
*    output     FL64     *p       Pointer to the Convertible Price
*
*               FL64     *dp      Pointer to the first order derivative
*
*               FL64     *ddp     Pointer to the second order derivative*
*
*    returns    True if all is OK, False if not.
*
*    diagnostics
*
*    see also   Convtbl_CRR2Impl()
*
*************************************************************************
,,EOH,,*/

BOOLE Convtbl_CRR2Price(DATESTR*    analys,
                            FL64        spot,
                            FL64        vol,
                            INTI        nstep,
                            CONVTBL*    cvt,
                            DISCFAC*    df,
                            DFSPREAD*   dfs,
                            DISCFAC*    divdf,
                            HOLI_STR*   holi,
                            RISKSET*    opt,
                            FL64*       p,
                            FL64*       dp,
                            FL64*       ddp)
{
    BOOLE      ok = True ;
    DISCFAC    sdf ;
    FL64       dpy, pu = 0, pd = 0, shock, d ;
    DATEARRAY  dd, oldd ;
    INTI       i ;
    DATESTR    anld ;

    *p = *dp = *ddp = 0.0 ;

    /* calculate convertible bond price */
    ok = crr_convtbl_premium(analys, spot, vol, nstep, cvt, df,
                             dfs, divdf, holi, p, &d, False) ;

    if (!ok || opt == NULL || opt->risk == ZERO_ORDER)
        return ok ;

    /* do risk ratios */
    shock = Scutl_Default_Shock(opt->shock, opt->key) ;

    switch (opt->key)
    {
        case KEY_DF :
        case KEY_BPV:

			sdf = Disc_ShockRates(df, 1.0, opt, holi);   /* PMSTA-22396 - SRIDHARA � 160502 */
            ok = crr_convtbl_premium(analys, spot, vol, nstep, cvt,
                                     &sdf, dfs, divdf, holi, &pu, &d,
                                     False) ;

            Free_PLANARRAY(sdf.disc, 1) ;

			sdf = Disc_ShockRates(df, -1.0, opt, holi);   /* PMSTA-22396 - SRIDHARA � 160502 */
            ok = ok && crr_convtbl_premium(analys, spot, vol, nstep, cvt,
                                           &sdf, dfs, divdf, holi, &pd,
                                           &d, False) ;

            Free_PLANARRAY(sdf.disc, 1) ;

            if (opt->key == KEY_BPV)
                shock = 1.0 ;

            break ;

        case KEY_PRICE :

            ok = crr_convtbl_premium(analys, spot + shock, vol, nstep,
                                     cvt, df, dfs, divdf, holi, &pu,
                                     &d, False) ;

            ok = ok && crr_convtbl_premium(analys, spot - shock, vol, nstep,
                                        cvt, df, dfs, divdf, holi, &pd,
                                        &d, False) ;

            break ;

        case KEY_VOL :
            ok = crr_convtbl_premium(analys, spot, vol + shock, nstep,
                                     cvt, df, dfs, divdf, holi, &pu,
                                     &d, False) ;

            ok = ok && crr_convtbl_premium(analys, spot, vol - shock, nstep,
                                     cvt, df, dfs, divdf, holi, &pd,
                                     &d, False) ;
            break ;

        case KEY_MATURITY :

            dd = Alloc_DATEARRAY(GetPlanFill(df->disc)) ;

            /* Let time decay -> and reflect this in the dates of the DF's.
               Ie. we move the entire Term Structure of interest rates. */

            for (i = 0 ; i < GetPlanFill(df->disc); i++)
				dd[i] = Cldr_AddDays(&df->disc->day[i], (INTL)shock, df->cal, holi);   /* PMSTA-22396 - SRIDHARA � 160502 */

            oldd = df->disc->day ;
            df->disc->day = dd ;

			anld = Cldr_AddDays(analys, (INTL)shock, df->cal, holi);   /* PMSTA-22396 - SRIDHARA � 160502 */

            /* Note that we do not shift the vol, since we want to interpolate
               the same vols as before */
            ok = crr_convtbl_premium(&anld, spot, vol, nstep,
                                     cvt, df, dfs, divdf, holi, &pd,
                                     &d, False) ;
            /* Do not set ddp */
			dpy = (FL64)Cldr_DaysPerYear(analys, analys, 0, df->cal, LAST, holi);   /* PMSTA-22396 - SRIDHARA � 160502 */
            *dp = dpy * (pd - *p) / shock ;

            /* Clean up */
            df->disc->day = oldd ;
            Free_DATEARRAY(dd) ;

            break ;

        default :
            ok = False ;
            return ok ;
    }

    if (ok == True && opt->key != KEY_MATURITY)
    {
        *dp = (pu - pd) / (2.0 * shock) ;
        if (opt->risk == SECOND_ORDER && opt->key != KEY_BPV)
            *ddp = (pu + pd - 2.0 * (*p)) / (shock * shock) ;
    }

    return ok ;
}


/*
..
*/

BOOLE crr_convtbl_premium(DATESTR*    analys,
                              FL64        spot,
                              FL64        vol,
                              INTI        nstep,
                              CONVTBL*    cvt,
                              DISCFAC*    df0,
                              DFSPREAD*   dfs,
                              DISCFAC*    divdf,
                              HOLI_STR*   holi,
                              FL64*       p,
                              FL64*       d,
                              BOOLE       do_d)
{
  FL64         factor, val, prob, wait, *price, rp ;
  FL64         dt, u, *time, *scale, ra, *price0, to, from, t1, *bond_npv ;
  FL64         *bond_price, node_price, hurdle_time, call_time, call_price ;
  INTI         up, i, j, n ;
  BOOLE        ok, before, div_used ;
  BINTREEARRAY crra ;
  TSARRAY      ts, fts ;
  PLANARRAY    dummy ;
  DISCFAC      df, div ;
  DATESTR      d1, tmp ;

  /* warning avoidance */
  node_price = 0.0 ;

  *p = *d = 0.0 ;

  if (GetPlanFill(df0->disc) < 1)
    return False ;

  /* If divdf->disc is NULL special treatment is needed. 
     Therefore make sure that a local DISCFAC div is used.
     If divdf->disc is different from NULL then divdf is 
     copied to div. Otherwise div is initialised with 
     trivial data */
  div_used = False ;
  div = Set_DISCFAC(NULL, divdf->what, divdf->iconv, divdf->cal, 
                    divdf->irr, divdf->freq) ;

  if (GetPlanFill(divdf->disc) < 2)
  {
    div.disc = Alloc_PLANARRAY(1, 2) ;
    div_used = True ;
    Cldr_InsertInPlan(&df0->disc->day[0], 1.0, div.disc, False) ;
    tmp = Cldr_AddMonths(&df0->disc->day[0], 120, SAME) ;
    Cldr_InsertInPlan(&tmp, 0.999999, div.disc, False) ;
  }
  else
    div.disc = divdf->disc ;



  /* find spread (corporate) DF */
  df = Disc_Spread2DF(df0, dfs, holi);   /* PMSTA-22396 - SRIDHARA � 160502 */

  /* do the tree calibration here */
  d1   = Cldr_NextBusinessDate(&cvt->last, holi) ;
  crra = Clb_CRR2Tree(nstep, vol, spot, analys, &d1, df0->cal, cvt->div, holi);   /* PMSTA-22396 - SRIDHARA � 160502 */

  /* Initialize */
  *p   = 0.0 ;
  ok   = True ;
  to = Cldr_TermBetweenDates(analys, &d1, 0, df0->cal, SAME, holi);   /* PMSTA-22396 - SRIDHARA � 160502 */
  d1   = Cldr_NextBusinessDate(&cvt->first, holi) ;
  from = Cldr_TermBetweenDates(analys, &d1, 0, df0->cal, SAME, holi);   /* PMSTA-22396 - SRIDHARA � 160502 */

  /* Find the period rate, and set up other variables */
  n      = crra->nlevel ;
  price0 = crra->f64 ;
  scale  = crra->scale ;
  time   = crra->time ;

  dt   = time[1] ;
  u    = crr_vol2factor(vol, dt) ;
  d1   = Cldr_NextBusinessDate(&cvt->hurdle_date, holi) ;
  hurdle_time = Cldr_TermBetweenDates(analys, &d1, 0, df0->cal, SAME, holi);   /* PMSTA-22396 - SRIDHARA � 160502 */
  d1   = Cldr_NextBusinessDate(&cvt->call_date, holi) ;
  call_time = Cldr_TermBetweenDates(analys, &d1, 0, df0->cal, SAME, holi);   /* PMSTA-22396 - SRIDHARA � 160502 */

  /* calculate the probability for an 'up' move */
  prob = 1.0 / (1 + u) ;

  /* find ts for risk-free discount function */
  dummy = Alloc_PLANARRAY(1, GetPlanFill(df0->disc));
  ts = Disc_DF2TS(df0->disc->day + 1, GetPlanFill(df0->disc) - 1, df0, dummy,
                  df0->irr, df0->freq, holi) ;   /* PMSTA-22396 - SRIDHARA � 160502 */
  fts = Disc_DF2TS(div.disc->day + 1, GetPlanFill(div.disc) - 1, &div,
                   dummy, divdf->irr, divdf->freq, holi) ;   /* PMSTA-22396 - SRIDHARA � 160502 */
/*  fts = Disc_DF2TS(divdf->disc->day + 1, GetPlanFill(divdf->disc) - 1, divdf,
                   dummy, divdf->irr, divdf->freq) ;*/

  /* adjust prices for discounting and continuous dividends */
  for (i = 1, factor = 1.0; i <= n; i++)
  {
    t1 = time[i] ;
    factor *= CRR_Rpcalc(t1, dt, fts, divdf->iconv, ts, df0->iconv, &rp) ;
    price0[i] *= factor ;
  }

  /* Memory for holding prices in the tree */
  price = Alloc_FL64ARRAY(n + 2) ;
  for (i = 0; i < n + 2; i++)
    price[i] = 0.0 ;

  /* find future bond npv and future bond prices using corporate df */
  bond_price = Alloc_FL64ARRAY(n + 1) ;
  bond_npv = Alloc_FL64ARRAY(n + 1) ;
  ok = ok && fixp_to_npvarray(n, analys, time, &df, &cvt->fixp,
                              bond_npv, bond_price, cvt->accr_incl, holi) ;

  /* Find the last active level in the tree */
  for (i = n ; ok && i >= 0 ; i--)
    if ((time[i] - DAY_TOL) < to)
      break ;

  up = i ;

  /* Now loop over all the levels and generate the option price tree */
  for (i = up ; ok == True && i >= 0 ; i--)
  {
    factor = 1.0 ;
    before = ((time[i] >= (from - DAY_TOL)) ? False : True);

    /* get the strike of the call option */
    call_price = find_call_price(analys, cvt, time[i], df0->cal, SAME) ;

    /* Get the discount factor (rp) for the time step */
    t1 = time[i] ;
    ra = CRR_Rpcalc(t1, dt, fts, divdf->iconv, ts, df0->iconv, &rp) ;
    ra *= 1.0 ;                                /* Warning avoidance */

    for (j = 0 ; ok == True && j <= i ; j++)
    {
      wait = (prob * price[j] + (1.0 - prob) * price[j + 1]) / rp ;

      /* Are we before first expiration ?? */
      if (ok == True && before == False)
      {
        /* We are still in the exercise period */
        node_price = price0[i] * factor ;
        factor *= scale[i] ;
        /* compute innner value (normalized to 100.0 nominal bond value) */
        if (cvt->accr_incl)
          val = node_price * 100.0 / cvt->conv_price - bond_price[i] ;
        else
          val = node_price * 100.0 / cvt->conv_price - bond_npv[i] ;
/* the above val calculation could be improved by valuing the put option...*/
      }
      else
        val = 0.0 ;

/*..to be added later..
      * deal with mandatory conversion at maturity *
      if (i == up && cvt->mat_conv)
        price[j] = val ;
      else
      {
        val     = GETMAX(val, 0.0) ;
        price[j] = GETMAX(val, wait) ;
      }
..but, for now, */

      val     = GETMAX(val, 0.0) ;
      price[j] = GETMAX(val, wait) ;

      /* deal with the early redemption (call) option */
      if (call_exercise(time[i], hurdle_time, call_time, cvt->call_hurdle,
                      node_price, price[j], bond_price[i], call_price))
        price[j] = call_price - bond_price[i] ;
    }
    if (ok && i == 1 && do_d)
    {
      *d = price0[1] * (1.0 - scale[1]) ;
      *d = (*d > F64_TOL) ? (price[1] - price[0]) / *d : 0.0 ;
    }
  }

  *p = price[0] + bond_price[0] ;

  /* Free */
  if (div_used == True)
    Free_PLANARRAY(div.disc, 1) ;
  Free_PLANARRAY(df.disc, 1) ;
  Free_FL64ARRAY(price) ;
  Free_FL64ARRAY(bond_npv) ;
  Free_FL64ARRAY(bond_price) ;
  Free_BINTREEARRAY(crra, 1) ;
  Free_TSARRAY(ts, 1) ;
  Free_TSARRAY(fts, 1) ;
  Free_PLANARRAY(dummy, 1) ;

  return ok ;
}


/*
..
*/

FL64 find_call_price(DATESTR* analys,
                     CONVTBL*   convtbl,
                     FL64      time,
                     CALCONV   cal,
                     EOMCONV   eom)
{
    DATESTR    node_date ;
    INTI    index ;

    if (GetPlanFill(convtbl->call_plan) < 1)
        return convtbl->call_price ;

    node_date = Cldr_Term2Date(analys, time, YEARS, cal, eom) ;

    if (Cldr_DateLT(&node_date, convtbl->call_plan->day))
        return convtbl->call_price ;

    index = Cldr_FindDateIndex(convtbl->call_plan->day,
                                convtbl->call_plan->filled,
                                &node_date, 0, SEARCH_FORWARDS, NEXTINDEX) ;

    return convtbl->call_plan->f64[index - 1] ;
}



BOOLE call_exercise(FL64 node_time,
                    FL64 hurdle_time,
                    FL64 call_time,
                    FL64 call_hurdle,
                    FL64 stock_price,
                    FL64 option_value,
                    FL64 bond_price,
                    FL64 call_price)
{
    BOOLE ok = False;

    /* the call may be exercised only if one of two conditions obtains */
    if (node_time >= hurdle_time && node_time < call_time)
        ok = (stock_price >= call_hurdle) ? True : False ;
    else if (node_time - call_time > 0.001)
        ok = True ;

    /* now find out whether the option is exercised */
    /* we assume exercise at first profitable instance */
    return (ok && option_value + bond_price >= call_price) ? True : False ;
}


/*
..
*/

BOOLE fixp_to_npvarray(INTI     nlevel,
                       DATESTR*     analys,
                       FL64*        time,
                       DISCFAC*     df,
                       FIXPAYARRAY bond,
                       FL64ARRAY   bond_npv,
                       FL64ARRAY   bond_price,
                       BOOLE       do_price_only,
                       HOLI_STR*   holi)   /* PMSTA-22396 - SRIDHARA � 160502 */
{
    FL64      *disc, *npvdecomp, dp, ddp ;
    CFLWARRAY cflw ;
    INTI      i, j ;
    BOOLE     ok = True ;
    DATEARRAY node_days ;
    TRADEINFO trade ;

    /* find temporal nodes as dates */
    node_days = Alloc_DATEARRAY(nlevel + 1) ;
    for (i = 0; i < nlevel + 1; i++)
        node_days[i] = Cldr_Term2Date(analys, time[i], YEARS, df->cal, SAME) ;

    /* find future bond prices */
    for (i = 0; i < nlevel + 1; i++)
    {
        trade         = bond_set_tradeinfo(&node_days[i]) ;
        bond_price[i] = Bond_DF2Price(&node_days[i], &trade, bond,
                                      df, holi, NULL, NULL, &dp, &ddp) ;
        /* make sure the bond values at par (and not ZERO!) at maturity  */
        if (Cldr_DateEQ(&node_days[i], &bond->cday.last))
            bond_price[i] = 100.0 ;
    }

    if (do_price_only == False)
    {
        /* find disc factors on temporal nodes */
		disc = Disc_IntpolArray(node_days, nlevel + 1, df, holi);   /* PMSTA-22396 - SRIDHARA � 160502 */

        /* do the bond cash flow */
        cflw = Cflw_GenrCflw(&bond->repay, &bond->rday, &bond->fix,
                              &bond->cday, holi) ;

        /* we must have at least one payment */
        if (cflw->filled <= 0)
            ok = False ;

        npvdecomp = Alloc_FL64ARRAY(GETMAX(1, cflw->filled)) ;

        /* find npv's on ANALYS date of each payment */
        if (ok == True)
            Disc_DF2NPV(analys, cflw->days, cflw->coupon, cflw->repay, 
                        cflw->filled, df, NULL, False, npvdecomp, holi) ;   /* PMSTA-22396 - SRIDHARA � 160502 */

        /* find the npv on ANALYS date of the cash flow after each node date */
        for (i = nlevel, j = cflw->filled - 1; ok && i >= 0; i--)
        {
            bond_npv[i] = (i >= nlevel) ? 0.0 : bond_npv[i+1] ;
            while (j >= 0 && Cldr_DateLE(&node_days[i],&cflw->days[j]))
            {
                bond_npv[i] += npvdecomp[j] ;
                j-- ;
            }
        }

        /* discount back out to each node date */
        for (i = 0; ok == True && i <= nlevel; i++)
        {
            if (disc[i] > 0.0 && disc[i] <= 1.0)
                bond_npv[i] /= disc[i] ;
            else
                ok = False ;
            /* make sure the bond npv is 100 (and not 0) at maturity  */
            if (Cldr_DateEQ(&node_days[i], &bond->cday.last))
                bond_npv[i] = 100.0 ;
        }

        /* free */
        Free_FL64ARRAY(npvdecomp) ;
        Free_FL64ARRAY(disc) ;
        Free_CFLWARRAY(cflw, 1) ;
    }

    Free_DATEARRAY(node_days) ;

    return ok ;
}


/*,,SOH,,
*************************************************************************
*
*               Convtbl_CRR2Impl()
*
*    interface  #include <optbond.h>
*               BOOLE Convtbl_CRR2Impl(DATESTR   *analys,
*                                      FL64      price,
*                                      FL64      spot,
*                                      FL64      vol,
*                                      INTI      nstep,
*                                      CONVTBL   *cvt,
*                                      DISCFAC   *df,
*                                      DFSPREAD  *dfs,
*                                      DISCFAC   *divdf,
*                                      HOLI_STR  *holi,
*                                      KEYCONV   key,
*                                      ITERCTRL  *ictrl,
*                                      FL64      *impl) ;
*
*    general    The routine calculates the premium for a Convertible
*               bond. Using the Binomial CRR method.
*
*               Implied ratis are calculated as follows:
*
*                              Implied measure
*                              ---------------
*                                KEY_VOL
*                                KEY_SPREAD
*                                KEY_DIVYLD
*
*               If something goes wrong during the calculation then
*               False is returned. Essentially this can only happen if
*               unrealistic probabilities occur.
*
*               2 ways of entering are supported: Dividend yields and
*               discrete-time dividends.
*
*               The parameters up/low are used to control the iteration
*               process, and must therefore be filled with useful data.
*
*               If up and low are not consistent the iteration process
*               stops. It is of great importance that these bounds are
*               reasonably tight, since this will give a considerably
*               speed-up of the computations.
*
*               If no solution can be found False is returned.
*
*    input      DATESTR  *analys  Pointer to analysis date (NPV date)
*
*               FL64     price    The price of convertible bond
*
*               FL64     spot     The unadjusted spot price of
*                                 underlying stock
*
*               FL64     vol      The annual volatility of the Spot
*                                 price in percent.
*
*               INTI     nstep    Number of steps in the Binomial Tree
*
*               CONVTBL  *cvt     The convertible data
*
*               DISCFAC  *df      Discount structure
*
*               DFSPREAD *dfs     Spread against df
*
*               DISCFAC  *divdf   Dividend yield term structure.
*                                 Alternative to using discrete-time
*                                 dividends in the argument div.
*                                 This is particularly useful when
*                                 valuing index options.
*
*               HOLI_STR *holi    Holiday setup
*
*               KEYCONV  key      What to solve for.
*
*               ITERCTRL *ictrl   Iteration control
*
*    output     FL64     *impl    The implied ratio.
*
*    returns    True if all is OK, False if not.
*
*    diagnostics
*
*    see also   Convtbl_CRR2Price()
*
*************************************************************************
,,EOH,,*/

BOOLE Convtbl_CRR2Impl(DATESTR*   analys,
                           FL64       price,
                           FL64       spot,
                           FL64       vol,
                           INTI       nstep,
                           CONVTBL*   cvt,
                           DISCFAC*   df,
                           DFSPREAD*  dfs,
                           DISCFAC*   divdf,
                           HOLI_STR*  holi,
                           KEYCONV    key,
                           ITERCTRL*   ictrl,
                           FL64*      impl)
{
  BOOLE ok ;
  CONVTBLNR y;
  NR_ERR err;

  *impl = 0.0;
  ok = True;

/*  if (df->disc == NULL || divdf->disc == NULL)
    return False;*/
  if (df->disc == NULL || 
      (divdf->disc == NULL && key != KEY_DIVYLD))
    return False;

  ictrl->maxiter = ((ictrl->maxiter < 0.0) ? MAXIT : ictrl->maxiter);
  ictrl->shock = ((ictrl->shock < 0.0) ? 1e-2 : ictrl->shock);
  ictrl->acc = ((ictrl->acc) ? ACC_RATE : ictrl->acc);
  ictrl->what_acc = ((ictrl->acc) ? 0 : ictrl->what_acc);
  ictrl->bisec = ((ictrl->bisec) ? 2 : ictrl->bisec);

  y = Convtbl_SetNR(analys, price, spot, vol, nstep, cvt, 
                    df, dfs, divdf, holi, key, ictrl->shock);

  if (ictrl->bisec == 2)
  {
    ictrl->lower = ((ictrl->use_lower) ? ictrl->lower : 1.0 );
    ictrl->upper = ((ictrl->use_upper) ? ictrl->upper : 2.0 );

    if (key == KEY_SPREAD)
      ok = Math_RootBracket(&Convtbl_NewtonRaphson, &y, ictrl, 
                           &ictrl->lower, &ictrl->upper, holi);  /* PMSTA-29444 - SRIDHARA - 050318 */
    else
      ok = Math_PosRootBracket(&Convtbl_NewtonRaphson, &y, ictrl, 
                           &ictrl->lower, &ictrl->upper, holi);  /* PMSTA-29444 - SRIDHARA - 050318 */
    if (ictrl->lower > ictrl->init_guess || 
        ictrl->init_guess > ictrl->upper)
      ictrl->init_guess = (ictrl->lower + ictrl->upper) / 2.0;
    ictrl->bisec = 1;
  }
  else
  {
    ictrl->lower = ((ictrl->use_lower) ? ictrl->lower : 1e-6 );
    ictrl->upper = ((ictrl->use_upper) ? ictrl->upper : 100.0 );
    ictrl->init_guess = ((ictrl->use_init_guess) ? ictrl->init_guess : 50.0);
  }

  if (!ok)
    err = NR_MAXITER_EXCEEDED;
  else
	  err = Newton_Raphson(&Convtbl_NewtonRaphson, &y, ictrl, impl, holi);   /* PMSTA-22396 - SRIDHARA � 160502 */

  ok = (err == NR_ROOT_FOUND ? True : False) ;

  return ok;
}


/*,,SOH,,
*************************************************************************
*
*               Convtbl_CRR2Delta()
*
*    interface  #include <optbond.h>
*               FL64ARRAY Convtbl_CRR2Delta(DATESTR      *analys,
*                                           FL64         spot,
*                                           FL64         vol,
*                                           INTI         nstep,
*                                           CONVTBL      *cvt,
*                                           DISCFAC      *df,
*                                           DFSPREAD     *dfs,
*                                           DISCFAC      *divdf,
*                                           HOLI_STR     *holi,
*                                           DELTASET     *ds,
*                                           BOOLE        *ok);
*
*    general    The routine calculates the delta vector for a
*               Convertible bond using the Binomial CRR method and a
*               list of predefined shocks to the zero coupon curve.
*
*               If something goes wrong during the calculation then
*               False is returned.
*
*    input      DATESTR  *analys  Pointer to analysis date (NPV date)
*
*               FL64     spot     The unadjusted spot price
*
*               FL64     vol      The annual volatility of the Spot
*                                 price in percent.
*
*               INTI     nstep    Number of steps in the Binomial Tree
*
*               CONVTBL  *cvt     The data defining the option.
*                                 opt->berm assumed as False.
*
*               DISCFAC  *df      Discount structure
*
*               DFSPREAD *dfs     Spread against df
*
*               DISCFAC  *divdf   Dividend yield term structure
*                                 Alternative to using discrete-time
*                                 dividends in the argument div.
*                                 This is particularly useful when
*                                 valuing index options.
*
*               HOLI_STR *holi    Holiday setup
*
*               DELTASET *ds      Data for delta calculation
*
*    output     BOOLE    *ok      True if all ok, False if not.
*
*    returns    The delta vector allocated as:
*
*                         Alloc_FL64ARRAY(ds->nshock) ;
*
*    diagnostics
*
*    see also   Convtbl_CRR2Price()
*               Convtbl_CRR2Impl()
*
*************************************************************************
,,EOH,,*/
FL64ARRAY Convtbl_CRR2Delta(DATESTR*   analys,
                                FL64       spot,
                                FL64       vol,
                                INTI       nstep,
                                CONVTBL*   cvt,
                                DISCFAC*   df,
                                DFSPREAD*  dfs,
                                DISCFAC*   divdf,
                                HOLI_STR*  holi,
                                DELTASET*  ds,
                                BOOLE*     ok)
{
    INTI      i ;
    FL64ARRAY dv ;
    FL64      p0, dum ;
    PLANARRAY old ;
    DATESTR   fsprev, matur ;

    /* Initialise */
    *ok = True ;
    old = df->disc ;

    /* Allocate */
    dv = Alloc_FL64ARRAY(ds->nshock) ;

    /* The unshocked price */
    *ok = Convtbl_CRR2Price(analys, spot, vol, nstep, cvt, df, dfs, 
                            divdf, holi, NULL, &p0, &dum, &dum) ;

    /* Find last relevant date */
    matur = Cldr_NextBusinessDate(&cvt->fixp.cday.last, holi) ;
                      
    for (i = 0; *ok == True && i < ds->nshock; i++)
    {
        fsprev = Disc_get_chgdate(NULL, old, &ds->shock[i]) ;

        if (fsprev.y > 0 && Cldr_DateLT(&matur, &fsprev) == False)
        {
            df->disc = &ds->shock[i] ;

            *ok = Convtbl_CRR2Price(analys, spot, vol, nstep, cvt, df, 
                                    dfs, divdf, holi, NULL, 
                                    &dv[i], &dum, &dum) ;
            dv[i] -= p0 ;

            if (ds->zero == True)
                /* Find shocked Zero PV */
				dv[i] /= Disc_DF2BPV(&ds->mid[i], df, old, holi);   /* PMSTA-22396 - SRIDHARA � 160502 */
        }
        else
            dv[i] = 0.0 ;
    }

    df->disc = old ;

    return dv ;
}



/*,,SOH,,
*************************************************************************
*
*               Free_CONVTBL()
*
*    interface  #include <optbond.h>
*               void Free_CONVTBL(CONVTBL *fixp) ;
*
*    general    Free_CONVTBL() frees memory for a CONVTBL. All the
*               memory is suballocated in the fixp structure.
*
*    input      CONVTBL     *fixp       The bond data container
*
*    output
*
*    returns
*
*    diagnostics
*
*    see also
*
*************************************************************************
,,EOH,,*/


void Free_CONVTBL(CONVTBL* fixp)
{
    /* Free all suballocated memory */
    Free_PLANARRAY(fixp->call_plan, 1) ;
    Free_FIXPAY(&fixp->fixp) ;
    Free_PLANARRAY(fixp->div, 1) ;
}



CONVTBLNR Convtbl_SetNR(DATESTR*  analys, 
                            FL64  price, 
                            FL64  spot,                         
                            FL64  vol, 
                            INTI  nstep, 
                            CONVTBL*  cvt,                         
                            DISCFAC*  df0, 
                            DFSPREAD*  dfs,                         
                            DISCFAC*  divdf, 
                            HOLI_STR*  holi,                         
                            KEYCONV  key, 
                            FL64  shock)
{
  CONVTBLNR c;

  c.analys = analys;
  c.price = price;
  c.spot = spot;
  c.vol = vol;
  c.nstep = nstep;
  c.cvt = cvt;
  c.df0 = df0;
  c.dfs = dfs;
  c.divdf = divdf;
  c.holi = holi;
  c.key = key;
  c.shock = shock;

  return c;
}

void Convtbl_GetNR(DATESTR**  analys, 
                              FL64*  price, 
                              FL64*  spot, 
                              FL64*  vol, 
                              INTI*  nstep, 
                              CONVTBL**  cvt,                         
                              DISCFAC**  df0, 
                              DFSPREAD**  dfs,                         
                              DISCFAC**  divdf, 
                              HOLI_STR**  holi,                         
                              KEYCONV*  key, 
                              FL64*  shock,
                              CONVTBLNR*  c)
{
  *analys = c->analys;
  *price = c->price;
  *spot = c->spot;
  *vol = c->vol;
  *nstep = c->nstep;
  *cvt = c->cvt;
  *df0 = c->df0;
  *dfs = c->dfs;
  *divdf = c->divdf;
  *holi = c->holi;
  *key = c->key;
  *shock = c->shock;
}


BOOLE Convtbl_NewtonRaphson(FL64  x, 
                    void*  y,
                    BOOLE  grad,
                    FL64*  fx, 
                    FL64*  dfx,
					void*  hol)
{
  DATESTR   *analys;
  FL64      price;
  FL64      spot, guess;
  FL64      vol, shock, dummy;
  INTI      nstep;
  CONVTBL   *cvt;
  DISCFAC   *df0;
  DFSPREAD  *dfs;
  DISCFAC   *divdf;
  HOLI_STR  *holi = (HOLI_STR *)hol; /* PMSTA-29444 - SRIDHARA - 050318 */
  KEYCONV   key;
  BOOLE   ok ;
  DISCFAC cc_df ;
  DFPARMS dfp ;
  FL64    fx1 = 0, dfx1;

  guess = x;
  Convtbl_GetNR(&analys, &price, &spot, &vol, &nstep, &cvt, 
                &df0, &dfs, &divdf, &holi, &key, &shock,
                (CONVTBLNR*) y);

  /* warning avoidance */
  ok = False;

  if (key == KEY_VOL)
    vol = guess ;
  else if (key == KEY_SPREAD)
    *dfs = Set_DFSPREAD(guess, COMPOUND, ANNUALLY, NULL) ;
  else if (key == KEY_DIVYLD)
  {
    /* Translate continuous dividend yield into cc_df */
    dfp = Set_DFPARMS(DI_SPOT, LINEAR_FLAT_END, df0->cal,
                      CONTINUOUS, ANNUALLY) ;
	cc_df = Disc_TS2DF(analys, &cvt->last, &guess, 1, &dfp, holi);   /* PMSTA-22396 - SRIDHARA � 160502 */
    ok = crr_convtbl_premium(analys, spot, vol, nstep, cvt,
                           df0, dfs, &cc_df, holi, fx, &dummy, False) ;
    Free_PLANARRAY(cc_df.disc, 1) ;
  }
  else
    return False ;

  if (key != KEY_DIVYLD)
    ok = crr_convtbl_premium(analys, spot, vol, nstep, cvt,
                           df0, dfs, divdf, holi, fx, &dummy, False) ;

  if (ok)
    *fx -= price ;

  /* Calculate gradient */
  if (grad == True)
  {
    ok = ok && Convtbl_NewtonRaphson(x + shock, y, False, &fx1, &dfx1, holi);

    *dfx = (fx1 - *fx) / shock;
  }

  return ok ;

}





#undef DAY_TOL
#undef SHOCKSIZE
#undef MAXIT
#undef F64_TOL
#undef ACC_PRICE
#undef ACC_RATE
#undef ACC_TERM
#undef LOW_BOUND

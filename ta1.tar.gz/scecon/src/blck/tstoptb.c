/* SCID @(#)tstoptb.c	1.11 (SimCorp) 99/09/29 14:19:08 */

/************************************************************************
*
*   project     SCecon
*
*   this program tests the routines in the option module of SCecon.
*
************************************************************************/

/*** includes ***********************************************************/
#include <string.h>
#include <str2conv.h>
#include <optbond.h>
#include <stdlib.h>
#include <stdio.h>
#include <ioconv.h>
#include <optio.h>
#include <bondio.h>
#include <capio.h>
#include <futio.h>

/*** prototyping  *******************************************************/


INTI optbondtest(char* txa, FILE* in, FILE* out)
{
    char        txb[25], txpl[120] ;
    FL64        ytm, spot, f, p, acc, fexp, fres, fres1, fexp1 ;
    FL64        s0, vol, fres2, fexp2, price, spread, *dv ;
    INTI        nbuck, nstep, i, diff ;
    KEYCONV     wrt, what ;
    YYYYMMDD    ymd ;
    DATESTR     vold, today, deliv ;
    BOOLE       okexp, is_p, ok, zero ;
    DISCFAC     df, cc_df, divdf ;
    OPTFUT      opt ;
    RISKSET     orisk ;
    FIXPAY      fixp ;
    BUCKETARRAY bucket ;
    HOLI_STR    holi ;
    CONVTBL     cvt ;
    YTMCONV     ytmc ;
    DELTASET    ds ;
    DFSPREAD    dfs ;
    ITERCTRL    ctrl ;
    FUTBOND     futb ;
 
    acc   = 0.0001 ;
    diff = -1 ;

    if (!strcmp(txa, "OptFutBond_Black2P()"))
    {
        fscanf(in,"%lf %lf %lf %ld %lf %lf",
               &fexp, &fexp1, &fexp2, &ymd, &f, &vol) ;

        today = Cldr_YMD2Datestr(ymd) ;

        fprintf(out,"   Testing %s\n", txa) ;
        fprintf(out,"   Analysdate    %8ld\n", ymd) ;
        fprintf(out,"   Future price  %8.5lf\n", f) ;
        fprintf(out,"   Vol           %8.5lf\n", vol) ;

        zero   = Read_BOOLE(in, out, "Margining  ") ;
        fscanf(in,"%ld ", &ymd) ;

        deliv = Cldr_YMD2Datestr(ymd) ;

        fprintf(out,"   Delivery      %8ld\n", ymd) ;

        opt   = Read_OPTFUT(in, out) ;
        orisk = Read_RISKSET(in, out) ;
        df    = Read_DISCFAC(in, out) ;
        holi  = Set_HOLI_STR(NO_BUSADJUST, 0, NULL) ;

        fres = OptFutBond_Black2P(&today, &today, f, vol, zero, &deliv, 
          &opt, &df, &holi, &orisk, &fres1, &fres2) ;
        diff = Write_RiskDiff(True, True, fres, fres1, fres2, fexp, fexp1, 
                              fexp2, acc, out) ;
        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_RISKSET(&orisk) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_OPTFUT(&opt) ;
    }

    else if (!strcmp(txa, "OptBond_Black2DFp()") )
    {
        fscanf(in,"%lf %lf %lf %ld %lf",
               &fexp, &fexp1, &fexp2, &ymd, &vol) ;

        today = Cldr_YMD2Datestr(ymd) ;

        fprintf(out,"   Testing %s\n", txa) ;
        fprintf(out,"   Analysdate    %8ld\n", ymd) ;
        fprintf(out,"   Vol           %8.5lf\n", vol) ;

        fixp  = Read_FIXPAY(in, out, &today) ;
        opt   = Read_OPTFUT(in, out) ;
        df    = Read_DISCFAC(in, out) ;
        holi  = Set_HOLI_STR(NO_BUSADJUST, 0, NULL) ;
        orisk = Read_RISKSET(in, out) ;

        
        fres = OptBond_Black2DFp(&today, &today, vol, NULL, &fixp,
                                 &opt, &df, &holi, &orisk, &fres1, 
                                 &fres2) ;
        diff = Write_RiskDiff(True, True, fres, fres1, fres2, fexp, fexp1, 
                              fexp2, acc, out) ;
        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_FIXPAY(&fixp) ;
        Free_RISKSET(&orisk) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_OPTFUT(&opt) ;
    }

    else if (!strcmp(txa, "OptFutBond_Black2DFp()"))
    {
        fscanf(in,"%lf %lf %lf %ld %lf",
               &fexp, &fexp1, &fexp2, &ymd, &vol) ;

        today = Cldr_YMD2Datestr(ymd) ;

        fprintf(out,"   Testing %s\n", txa) ;
        fprintf(out,"   Analysdate    %8ld\n", ymd) ;
        fprintf(out,"   Vol           %8.5lf\n", vol) ;

        futb  = Read_FUTBOND(in, out, &today) ;
        opt   = Read_OPTFUT(in, out) ;
        df    = Read_DISCFAC(in, out) ;
        holi  = Set_HOLI_STR(NO_BUSADJUST, 0, NULL) ;
        orisk = Read_RISKSET(in, out) ;
        
        fres = OptFutBond_Black2DFp(&today, &today, vol, 0, NULL,
                                    &futb, &opt, &df, &holi, &orisk, 
                                    &fres1, &fres2) ;
        
        diff = Write_RiskDiff(True, True, fres, fres1, fres2, fexp, fexp1, 
                              fexp2, acc, out) ;
        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_FUTBOND(&futb) ;
        Free_RISKSET(&orisk) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_OPTFUT(&opt) ;
    }

    else if (!strcmp(txa, "OptBond_Black2YTMp()") )
    {
        fscanf(in,"%lf %lf %lf %ld %lf",
               &fexp, &fexp1, &fexp2, &ymd, &vol) ;

        today = Cldr_YMD2Datestr(ymd) ;

        fprintf(out,"   Testing %s\n", txa) ;
        fprintf(out,"   Analysdate    %8ld\n", ymd) ;
        fprintf(out,"   Vol           %8.5lf\n", vol) ;

        fixp  = Read_FIXPAY(in, out, &today) ;
        opt   = Read_OPTFUT(in, out) ;
        df    = Read_DISCFAC(in, out) ;

        fscanf(in,"%lf", &ytm) ;
        fprintf(out,"   YTM           %8.5lf\n", ytm) ;

        ytmc  = Read_YTMCONV(in, out) ;
        holi  = Set_HOLI_STR(NO_BUSADJUST, 0, NULL) ;
        orisk = Read_RISKSET(in, out) ;

        fres = OptBond_Black2YTMp(&today, &today, vol, &fixp, &opt, &df,
                                  ytm, &ytmc, &holi, &orisk, &fres1,
                                  &fres2) ;
        diff = Write_RiskDiff(True, True, fres, fres1, fres2, fexp, fexp1, 
                              fexp2, acc, out) ;
        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_RISKSET(&orisk) ;
        Free_FIXPAY(&fixp) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_OPTFUT(&opt) ;
    }

    else if (!strcmp(txa, "OptFutBond_Black2YTMp()"))
    {
        fscanf(in,"%lf %lf %lf %ld %lf",
               &fexp, &fexp1, &fexp2, &ymd, &vol) ;

        today = Cldr_YMD2Datestr(ymd) ;

        fprintf(out,"   Testing %s\n", txa) ;
        fprintf(out,"   Analysdate    %8ld\n", ymd) ;
        fprintf(out,"   Vol           %8.5lf\n", vol) ;

        futb  = Read_FUTBOND(in, out, &today) ;
        opt   = Read_OPTFUT(in, out) ;
        df    = Read_DISCFAC(in, out) ;

        fscanf(in,"%lf", &ytm) ;
        fprintf(out,"   YTM           %8.5lf\n", ytm) ;

        ytmc  = Read_YTMCONV(in, out) ;
        holi  = Set_HOLI_STR(NO_BUSADJUST, 0, NULL) ;
        orisk = Read_RISKSET(in, out) ;

        fres = OptFutBond_Black2YTMp(&today, &today, vol, &futb,
                                     &opt, &df, ytm, &ytmc, &holi, 
                                     &orisk, &fres1, &fres2) ;

        diff = Write_RiskDiff(True, True, fres, fres1, fres2, fexp, fexp1, 
                              fexp2, acc, out) ;
        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_RISKSET(&orisk) ;
        Free_FUTBOND(&futb) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_OPTFUT(&opt) ;
    }



    else if (!strcmp(txa, "OptBond_Black2Delta()") )
    {
        fscanf(in,"%ld %lf", &ymd, &vol) ;

        today = Cldr_YMD2Datestr(ymd) ;

        fprintf(out,"   Testing %s\n", txa) ;
        fprintf(out,"   Analysdate    %8ld\n", ymd) ;
        fprintf(out,"   Vol           %8.5lf\n", vol) ;

        fixp = Read_FIXPAY(in, out, &today) ;
        opt  = Read_OPTFUT(in, out) ;
        df   = Read_DISCFAC(in, out) ;
        holi  = Set_HOLI_STR(NO_BUSADJUST, 0, NULL) ;
        bucket = Read_BUCKETARRAY(in, out, &nbuck) ;

        ds = Disc_DeltaPrep(&df, bucket, nbuck, &holi, False, df.irr,
                             df.freq, False, False, DF_BOTH) ;

        
        dv = OptBond_Black2Delta(&today, &today, vol, NULL,
                                 &fixp, &opt, &df, &holi, &ds) ;
        diff = 0 ;
        for (i = 0; i < nbuck; i++)
        {
            fscanf(in, "%lf", &fexp) ;
            diff = diff || fabs(fexp - dv[i]) > 0.00001 ;
            fprintf(out, "%d; %d exp %lf res %lf\n",
                    fabs(fexp - dv[i]) > 0.00001, i, fexp, dv[i]) ;
        }

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_FIXPAY(&fixp) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_DELTASET(&ds) ;
        Free_BUCKETARRAY(bucket) ;
        Free_FL64ARRAY(dv) ;
        Free_OPTFUT(&opt) ;
    }

    else if (!strcmp(txa, "OptFutBond_Black2Delta()"))
    {
        fscanf(in,"%ld %lf", &ymd, &vol) ;

        today = Cldr_YMD2Datestr(ymd) ;

        fprintf(out,"   Testing %s\n", txa) ;
        fprintf(out,"   Analysdate    %8ld\n", ymd) ;
        fprintf(out,"   Vol           %8.5lf\n", vol) ;

        futb = Read_FUTBOND(in, out, &today) ;
        opt  = Read_OPTFUT(in, out) ;
        df   = Read_DISCFAC(in, out) ;
        holi  = Set_HOLI_STR(NO_BUSADJUST, 0, NULL) ;
        bucket = Read_BUCKETARRAY(in, out, &nbuck) ;

        ds = Disc_DeltaPrep(&df, bucket, nbuck, &holi, False, df.irr,
                             df.freq, False, False, DF_BOTH) ;

        dv = OptFutBond_Black2Delta(&today, &today, vol, 0, NULL,
                                    &futb, &opt, &df, &holi, &ds) ; 

        diff = 0 ;
        for (i = 0; i < nbuck; i++)
        {
            fscanf(in, "%lf", &fexp) ;
            diff = diff || fabs(fexp - dv[i]) > 0.00001 ;
            fprintf(out, "%d; %d exp %lf res %lf\n",
                    fabs(fexp - dv[i]) > 0.00001, i, fexp, dv[i]) ;
        }

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_FUTBOND(&futb) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_DELTASET(&ds) ;
        Free_BUCKETARRAY(bucket) ;
        Free_FL64ARRAY(dv) ;
        Free_OPTFUT(&opt) ;
    }


    else if (!strcmp(txa, "OptFutBond_Black2Impl()"))
    {
        fscanf(in,"%lf %lf %s %ld %lf %lf",
               &fexp, &p, &txb, &ymd, &f, &vol) ;

        today = Cldr_YMD2Datestr(ymd) ;
        is_p = Str2BOOLE(txb) ;

        fprintf(out,"   Testing %s\n", txa) ;
        fprintf(out,"   Analysdate    %8ld\n", ymd) ;
        fprintf(out,"   Option Price  %8.5lf\n", p) ;
        fprintf(out,"   Is-P ?        %8s\n", txb) ;
        fprintf(out,"   Future price  %8.5lf\n", f) ;
        fprintf(out,"   Vol           %8.5lf\n", vol) ;

        zero   = Read_BOOLE(in, out, "Margining  ") ;
        fscanf(in,"%ld ", &ymd) ;

        deliv = Cldr_YMD2Datestr(ymd) ;

        fprintf(out,"   Delivery      %8ld\n", ymd) ;

        opt = Read_OPTFUT(in, out) ;

        fscanf(in, "%s", txb) ;
        fprintf(out,"   Solve for     %8s\n", txb) ;
        what = Str2KEYCONV(txb) ;

        df = Read_DISCFAC(in, out) ;
        holi  = Set_HOLI_STR(NO_BUSADJUST, 0, NULL) ;

        ctrl = Read_ITERCTRL(in, out);

        fres = 0.0 ;
        ok = OptFutBond_Black2Impl(&today, &today, p, is_p, f, vol, zero, 
          &deliv, &opt, &df, &holi, what, &ctrl, &fres) ;

        diff = Write_SingleDiff(ok, True, fres, fexp, acc, out) ;
        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_PLANARRAY(df.disc, 1) ;
        Free_OPTFUT(&opt) ;
    }



    else if (!strcmp(txa, "Convtbl_CRR2Price()"))
    {
        fprintf(out,"   testing %s\n", txa) ;        
        okexp = Read_BOOLE(in, out, "Exp OK              ") ;
        fexp = Read_FL64(in, out, "Exp 0.th derivative ");
        fexp1 = Read_FL64(in, out, "Exp 1.st derivative ");
        fexp2 = Read_FL64(in, out, "Exp 2.nd derivative ");

        acc = Read_FL64(in, out, "   Accept level    ");
        today = Read_DATESTR(in, out, "   Today           ");

        nstep = Read_INTI(in, out, "   CRR steps       ");
        s0 = Read_FL64(in, out, "   Spot price      ");
        vol = Read_FL64(in, out, "   Spot price vol  ");

        cvt = Read_CONVTBL(in, out, &today);

        spread = Read_FL64(in, out, "   Spread          ");

        cc_df = Read_DISCFAC(in, out);
        df = Read_DISCFAC(in, out);
        holi = Read_HOLI_STR(in, out);
        orisk = Read_RISKSET(in, out);
        dfs = Set_DFSPREAD(spread, COMPOUND, ANNUALLY, NULL) ;

        ok = Convtbl_CRR2Price(&today, s0, vol, nstep, &cvt, &df, 
                               &dfs, &cc_df, &holi, &orisk, 
                               &fres, &fres1, &fres2) ;

        IOUtil_ParseLine(in, out);

        diff = Write_RiskDiff(ok, okexp, fres, fres1, fres2, fexp, fexp1, 
                              fexp2, acc, out) ;

        Free_PLANARRAY(df.disc, 1) ;
        Free_PLANARRAY(cc_df.disc, 1) ;
        Free_CONVTBL(&cvt) ;
        Free_DATEARRAY(holi.holidays);
        Free_PLANARRAY(orisk.loads, 1);
    }

    else if (!strcmp(txa, "Convtbl_CRR2Impl()"))
    {
        fprintf(out,"   testing %s\n", txa) ;                
        okexp = Read_BOOLE(in, out, "Exp OK              ");
        fexp = Read_FL64(in, out, "Exp implied ratio   ");
        acc = Read_FL64(in, out, "   Accept level    ");
        today = Read_DATESTR(in, out, "   Today           ");

        nstep = Read_INTI(in, out, "   CRR steps       ");
        price = Read_FL64(in, out, "   Option Premium  ");
        s0 = Read_FL64(in, out, "   Spot price      ");
        vol = Read_FL64(in, out, "   Spot price vol  ");

        cvt = Read_CONVTBL(in, out, &today);

        spread = Read_FL64(in, out, "   Spread          ");

        cc_df = Read_DISCFAC(in, out);
        df = Read_DISCFAC(in, out);

        holi = Read_HOLI_STR(in, out);

        wrt = Read_KEYCONV(in, out, "   Impl. wrt         ");

        Init_ITERCTRL(&ctrl);
        dfs = Set_DFSPREAD(spread, COMPOUND, ANNUALLY, NULL) ;

        ok = Convtbl_CRR2Impl(&today, price, s0, vol, nstep, &cvt, &df,
                              &dfs, &cc_df, &holi, wrt, &ctrl, 
                              &fres) ;

        IOUtil_ParseLine(in, out);

        diff = Write_SingleDiff(ok, okexp, fres, fexp, acc, out) ;

        Free_PLANARRAY(df.disc, 1) ;
        Free_PLANARRAY(cc_df.disc, 1) ;
        Free_CONVTBL(&cvt) ;
        Free_DATEARRAY(holi.holidays);
    }


    else if (!strcmp(txa, "Convtbl_CRR2Delta()"))
    {
        fprintf(out,"   Testing %s\n", txa) ;

        /* Read data */
        today  = Read_DATESTR(in, out, "Analys date  ") ;
        spot   = Read_FL64(in, out, "Spot  ") ;
        vol    = Read_FL64(in, out, "Vol   ") ;
        nstep  = Read_INTI(in, out, "NStep ") ;
        cvt    = Read_CONVTBL(in, out, &today) ;
        df     = Read_DISCFAC(in, out) ;
        spread = Read_FL64(in, out, "Spread ") ;
        divdf  = Read_DISCFAC(in, out) ;
        
        bucket = Read_BUCKETARRAY(in, out, &nbuck) ;
        zero   = Read_BOOLE(in, out, "DECF  ") ;

        /* Initialise */
        holi = Set_HOLI_STR(NO_BUSADJUST, 0, NULL) ;
        ds   = Disc_DeltaPrep(&df, bucket, nbuck, &holi, True, df.irr,
                               df.freq, True, zero, DF_BOTH) ;

        /* Calculate */
        dfs = Set_DFSPREAD(spread, COMPOUND, ANNUALLY, NULL) ;
        dv = Convtbl_CRR2Delta(&today, spot, vol, nstep, &cvt, &df, &dfs,
                               &divdf, &holi, &ds, &ok) ;

        /* Read expected results and compare */
        diff = 0 ;
        for (i = 0; i < nbuck; i++)
        {
            fscanf(in, "%lf", &fexp) ;
            diff = diff || fabs(fexp - dv[i]) > 0.00001 ;
            fprintf(out, "%d; %d exp %lf res %lf\n",
                    fabs(fexp - dv[i]) > 0.00001, i, fexp, dv[i]) ;
        }

        /* Comments */
        IOUtil_ParseLine(in, out) ;

        /* Free */
        Free_PLANARRAY(df.disc, 1) ;
        Free_PLANARRAY(divdf.disc, 1) ;
        Free_DELTASET(&ds) ;
        Free_BUCKETARRAY(bucket) ;
        Free_CONVTBL(&cvt) ;
        Free_FL64ARRAY(dv) ;
    }

    else if (!strcmp(txa, "OptBond_Black2P()"))
    {
        fscanf(in,"%lf %lf %lf %ld %lf %lf",
               &fexp, &fexp1, &fexp2, &ymd, &vol, &spot) ;

        today = Cldr_YMD2Datestr(ymd) ;
        vold = today;

        fprintf(out,"   Testing %s\n", txa) ;
        fprintf(out,"   Analysdate    %8ld\n", ymd) ;
        fprintf(out,"   Vol           %8.5lf\n", vol) ;
        fprintf(out,"   Spot          %8.5lf\n", spot) ;

        orisk = Read_RISKSET(in, out) ;
        fixp  = Read_FIXPAY(in, out, &today) ;
        opt   = Read_OPTFUT(in, out) ;
        df    = Read_DISCFAC(in, out) ;
        holi  = Read_HOLI_STR(in, out) ;

        fres = OptBond_Black2P(&today, &vold, vol, spot, NULL, &fixp,
                               &opt, &df, &holi, &orisk, &fres1, &fres2) ;

        diff = (fabs(fres - fexp) > acc || fabs(fres1 - fexp1) > acc ||
                fabs(fres2 - fexp2) > acc);
        fprintf(out,"%d; option premium      %8.5lf expected = %8.5lf\n",
                (fabs(fres - fexp) > acc), fres, fexp);
        fprintf(out,"%d; 1. order derivative %8.5lf expected = %8.5lf\n",
                (fabs(fres1 - fexp1) > acc), fres1, fexp1);
        fprintf(out,"%d; 2. order derivative %8.5lf expected = %8.5lf\n",
                (fabs(fres2 - fexp2) > acc), fres2, fexp2);
        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_RISKSET(&orisk) ;
        Free_FIXPAY(&fixp) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_DATEARRAY(holi.holidays) ;
        Free_OPTFUT(&opt) ;
    }

    else if (!strcmp(txa, "OptBond_Black2Impl()"))
    {
        fscanf(in,"%lf %lf %ld %lf %lf %s",
               &fexp, &p, &ymd, &vol, &spot, txb) ;

        today = Cldr_YMD2Datestr(ymd) ;
        wrt   = Str2KEYCONV(txb) ;

        fprintf(out,"   Testing %s\n", txa) ;
        fprintf(out,"   Analysdate    %8ld\n", ymd) ;
        fprintf(out,"   Premium       %8.5lf\n", p) ;
        fprintf(out,"   Vol           %8.5lf\n", vol) ;
        fprintf(out,"   Spot          %8.5lf\n", spot) ;
        fprintf(out,"   Wrt           %8s\n", txb) ;

        fixp = Read_FIXPAY(in, out, &today) ;
        opt  = Read_OPTFUT(in, out) ;
        df   = Read_DISCFAC(in, out) ;
        holi = Set_HOLI_STR(NO_BUSADJUST, 0, NULL) ;

        ctrl = Read_ITERCTRL(in, out);

        ok = OptBond_Black2Impl(&today, &today, p, True, vol, spot,
                                NULL, &fixp, &opt, &df, &holi, wrt, 
                                &ctrl, &fres) ;

        diff = fabs(fres - fexp) > acc ;
        fprintf(out,"%d; Implied is  %8.5lf expected = %8.5lf\n",
                (fabs(fres - fexp) > acc), fres, fexp);
        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_FIXPAY(&fixp) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_OPTFUT(&opt) ;
    }


    return diff ;
}


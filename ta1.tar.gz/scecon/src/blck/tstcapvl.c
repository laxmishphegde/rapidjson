/* SCID @(#)tstcapvl.c	1.6 (SimCorp) 99/02/19 14:10:09 */

/************************************************************************
*
*   project     SCecon
*
************************************************************************/

/*** includes ***********************************************************/
#include <string.h>
#include <bond.h>
#include <str2conv.h>
#include <capio.h>
#include <capvl.h>
#include <futio.h>

INTI capvaltest(char* txa, FILE* in, FILE* out)
{
    char        txb[80], txc[80], txd[80], txe[80], txf[80], txg[80], txh[80],
      txpl[80] ;
    INTI        diff ;
    VALIDATE    val, exp_val ;
    DATESTR     date ;

    FL64        dur, Lfix ;
    SWAPTION    ncsw ;
    DATESTR     dummy_date ;
    CALCONV     cal, ical ;
    PMTFREQ     freq ;
    QOTCONV     qot ;
    RATEINDEX   index ;
    CAP         cap ;
    CAPLETS     caplets ;
    B76SWTM     b76t ;

    date  = dummy_date = Cldr_YMD2Datestr((YYYYMMDD) 0) ;
    diff = -1 ;

    if (!strcmp("Validate_SWAPTION()", txa))
    {
        fscanf(in, "%s %s", txe, txpl) ;

        exp_val = Str2VALIDATE(txe) ;

        fprintf(out, "   \n Testing %s\n", txa) ;
        fprintf(out, "   %s\n", txpl) ;

        ncsw = Read_SWAPTION(in, out) ;

        val = Validate_SWAPTION(&ncsw) ;
        VALIDATE2Str(val, txc) ;

        diff = (val == exp_val ? 0 : 1) ;
        fprintf(out,"%d;  Exp %s Res %s\n", diff, txe, txc) ;
    }

    else if (!strcmp("Validate_CAP()", txa))
    {
        fscanf(in, "%s %s", txe, txpl) ;

        exp_val = Str2VALIDATE(txe) ;

        fprintf(out, "   \n Testing %s\n", txa) ;
        fprintf(out, "   %s\n", txpl) ;

        cap = Read_CAP(in, out) ;

        val = Validate_CAP(&cap) ;
        VALIDATE2Str(val, txc) ;

        diff = (val == exp_val ? 0 : 1) ;
        fprintf(out,"%d;  Exp %s Res %s\n", diff, txe, txc) ;

        Free_DATEARRAY(cap.fix_days.irreg_days) ;
        Free_PLANARRAY(cap.step_str ,1) ;
        Free_PLANARRAY(cap.step_not ,1) ;
    }


    else if (!strcmp("Validate_CAPLETS()", txa))
    {
        fscanf(in, "%s %s", txe, txpl) ;

        exp_val = Str2VALIDATE(txe) ;

        fprintf(out, "   \n Testing %s\n", txa) ;
        fprintf(out, "   %s\n", txpl) ;

        fscanf(in, "%s %s %s %lf %s %s %lf",
                txb, txd, txf, &dur, txg, txh, &Lfix) ;

        cal  = Str2CALCONV(txb) ;
        qot  = Str2QOTCONV(txd) ;
        freq = Str2PMTFREQ(txf) ;

        ical = (Str2PMTFREQ(txh) == NO_FREQUENCY ? cal : EU30E360) ;
        index = Set_RATEINDEX(MMRATE, dur, Str2TERMUNIT(txg),
                                     Str2PMTFREQ(txh), ical, 0.0) ;

        fprintf(out,"   calendar       %8s\n", txb) ;
        fprintf(out,"   quoting        %8s\n", txd) ;
        fprintf(out,"   frequency      %8s\n", txf) ;
        fprintf(out,"   LIBOR dur      %8lf\n", dur) ;
        fprintf(out,"   LIBOR unit     %8s\n", txg) ;
        fprintf(out,"   LIBOR freq     %8s\n", txh) ;
        fprintf(out,"   LIBOR fixing   %8lf\n", Lfix) ;

        caplets = Read_CAPLETS(in, out, cal, qot, freq, Lfix, &index) ;

        val = Validate_CAPLETS(&caplets) ;
        VALIDATE2Str(val, txc) ;

        diff = (val == exp_val ? 0 : 1) ;
        fprintf(out,"%d;  Exp %s Res %s\n", diff, txe, txc) ;

        Free_IRGARRAY(caplets.irg) ;
    }

    else if (!strcmp("Validate_B76SWTM()", txa))
    {
        fscanf(in, "%s %s", txe, txpl) ;

        exp_val = Str2VALIDATE(txe) ;

        fprintf(out, "   \n Testing %s\n", txa) ;
        fprintf(out, "   %s\n", txpl) ;

        b76t = Read_B76SWTM(in, out) ;

        val = Validate_B76SWTM(&b76t) ;
        VALIDATE2Str(val, txc) ;

        diff = (val == exp_val ? 0 : 1) ;
        fprintf(out,"%d;  Exp %s Res %s\n", diff, txe, txc) ;

    }


    return diff ;
}

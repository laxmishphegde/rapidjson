/* @(#)optscen.c	1.8 (SimCorp) 99/06/06 10:41:43 */

/************************************************************************
*
*   project     SCecon
*
*   filename    scenario.c
*
*   contains    routines in the SCecon Library Scenario module
*
************************************************************************/


/***** includes ********************************************************/
#include <optscen.h>
#include <optbond.h>

/***** defines  ********************************************************/
#define DISC_TOLR  (FL64)    0.00000001
#define DAY_TOL    (FL64)    0.001
#define IRR_ACC    (FL64)    0.0000000001
#define IRR_MAXIT  (INTI)  150
#define IRR_FREQ   (INTI)    5
#define IRR_DAMP   (FL64)    0.9
#define REPAY_TOL  (FL64)   50.0
#define COUPON_TOL (FL64)   0.1





/*,,SOH,,
*************************************************************************
*
*               Caplets_Black2ScenBPV()
*
*   interface   #include <optscen.h>
*               FL64ARRAY Caplets_Black2ScenBPV(DATESTR  *analys,
*                                         DATESTR    *voldate,
*                                         DISCFAC    *df_cflw,
*                                         DISCFAC    *df_disc,
*                                         VOL_STR    *vol,
*                                         CMCONVADJ  *cmadj,
*                                         FL64       fx_spot,
*                                         CAPLETS    *cap,
*                                         HOLI_STR   *holi,
*                                         DELTASET   *ds_cflw,
*                                         DELTASET   *ds_disc,
*                                         FXSHOCKSET *fxs);
*
*   general     The routine calculates the vector of scenario BPV's for
*               a cap/floor using a list of predefined shocks to the
*               zero coupon curve and a list of predefined FX shocks.
*               Each zero coupon curve shock corresponds to a single
*               FX shock.
*
*               The scenario BPV represents the price differences
*               invoked by the curve shocks between the shocked PV's
*               and the initial PV.
*
*               It is required that the number of zero coupon curve
*               shocks match the number of FX shocks, ie.
*
*                fxs->nshock == ds_cflw->nshock == ds_disc->nshock
*
*               However, fxs may be set to NULL, in which case FX
*               shocking is ignored and the scenario BPV are calculated
*               in instrument ccys only. Otherwise BPV's are in
*               domestic (home ccy)
*
*               Scenarios may be used for evaluation of
*               - Randomly chosen curve/fx shocks,
*               - Historical scenarios/simulation,
*               - Expert scenarios,
*               - Worst case analysis, etc.
*
*               Refer to Caplets_Black2P() for pricing model
*               description.
*
*   input       DATESTR    *analys      The analysis date.
*
*               DATESTR    *voldate     Vol calculated from this date
*
*               DISCFAC    *df_cflw     Discounting structure setup.
*                                       Used to generate payments
*                                       The initial (unshocked) curve
*                                       should be in df->cflw.
*
*               DISCFAC    *df_disc     Discounting structure setup.
*                                       Used for discounting
*                                       The initial (unshocked) curve
*                                       should be in df->disc.
*
*               VOL_STR    *vol         Forward volatility structure.
*
*               CMCONVADJ  *cmadj       Data for Convexity Adjustment
*                                       Use NULL if no adjustment
*
*               FL64       fx_spot      FX spot rate.
*                                       The initial (unshocked) rate.
*
*               CAPLETS    *cap         The cap definition.
*
*               HOLI_STR   *holi        Business day adjustment setup.
*
*               DELTASET   *ds_cflw     Curve shock definitions for
*                                       the the curve in df_cflw.
*
*               DELTASET   *ds_disc     Curve shock definitions for
*                                       the the curve in df_disc.
*
*               FXSHOCKSET *fxs         FX shock definitions.
*
*   output
*
*   returns     The vector of scenario BPV as:
*
*                         Alloc_FL64ARRAY(ds->nshock) ;
*
*   diagnostics
*
*   see also    Disc_ScenarioPrep()
*               SwapFl_DF2ScenBPV()
*               RepoCflw_DF2ScenBPV()
*
*************************************************************************
,,EOH,,*/

FL64ARRAY Caplets_Black2ScenBPV(DATESTR* analys,
                        DATESTR*    voldate,
                        DISCFAC*    df_cflw,
                        DISCFAC*    df_disc,
                        VOL_STR*    vol,
                        CMCONVADJ*  cmadj,
                        FL64       fx_spot,
                        CAPLETS*    cap,
                        HOLI_STR*   holi,
                        DELTASET*   ds_cflw,
                        DELTASET*   ds_disc,
                        FXSHOCKSET* fxs)
{
    INTI      i, fx_size ;
    FL64ARRAY dv ;
    FL64      p0, dum, pShock, bpv ;
    PLANARRAY old_cflw, old_disc ;
    BOOLE noFx;

    dv = NULL;

    if (FXSHOCKSET_IsEmpty(fxs))
    {
      noFx = True;
      fx_size = 0;
    }
    else
    {
      fx_size = fxs->nshock;
      noFx = False;
    }

    if (ds_disc->nshock == ds_cflw->nshock && 
        (noFx || ds_cflw->nshock == fx_size))
    {
        /* Initialise */
        dv        = Alloc_FL64ARRAY(ds_cflw->nshock) ;
        old_cflw  = df_cflw->disc ;
        old_disc  = df_disc->disc ;

        /* The unshocked price */
        p0 = Caplets_Black2P(analys, voldate, cap, df_cflw, df_disc, 
                vol, cmadj, holi, NULL, &dum, &dum) ;

        for (i = 0; i < ds_cflw->nshock; i++)
        {
            df_cflw->disc = &ds_cflw->shock[i];
            df_disc->disc = &ds_disc->shock[i];

            pShock = Caplets_Black2P(analys, voldate, cap, df_cflw, 
                df_disc, vol, cmadj, holi, NULL, &dum, &dum) ;

            if (noFx)
              bpv = pShock - p0;
            else
              bpv = pShock * fxs->shocked[i] - p0 * fx_spot;

            dv[i] = bpv;
        }

        df_disc->disc = old_disc;
        df_cflw->disc = old_cflw;
    }

    return dv ;
}



/*,,SOH,,
*************************************************************************
*
*               Cap_Black2ScenBPV()
*
*   interface   #include <optscen.h>
*               FL64ARRAY Cap_Black2ScenBPV(DATESTR  *analys,
*                                         DATESTR    *voldate,
*                                         DISCFAC    *df_cflw,
*                                         DISCFAC    *df_disc,
*                                         VOL_STR    *vol,
*                                         CMCONVADJ  *cmadj,
*                                         FL64       fx_spot,
*                                         CAP        *cap,
*                                         HOLI_STR   *holi,
*                                         DELTASET   *ds_cflw,
*                                         DELTASET   *ds_disc,
*                                         FXSHOCKSET *fxs);
*
*   general     The routine calculates the vector of scenario BPV's for
*               a cap/floor using a list of predefined shocks to the
*               zero coupon curve and a list of predefined FX shocks.
*               Each zero coupon curve shock corresponds to a single
*               FX shock.
*
*               The scenario BPV represents the price differences
*               invoked by the curve shocks between the shocked PV's
*               and the initial PV.
*
*               It is required that the number of zero coupon curve
*               shocks match the number of FX shocks, ie.
*
*                fxs->nshock == ds_cflw->nshock == ds_disc->nshock
*
*               However, fxs may be set to NULL, in which case FX
*               shocking is ignored and the scenario BPV are calculated
*               in instrument ccys only. Otherwise BPV's are in
*               domestic (home ccy)
*
*               Scenarios may be used for evaluation of
*               - Randomly chosen curve/fx shocks,
*               - Historical scenarios/simulation,
*               - Expert scenarios,
*               - Worst case analysis, etc.
*
*               Refer to Cap_Black2P() for pricing model description.
*
*   input       DATESTR    *analys      The analysis date.
*
*               DATESTR    *voldate     Vol calculated from this date
*
*               DISCFAC    *df_cflw     Discounting structure setup.
*                                       Used to generate payments
*                                       The initial (unshocked) curve
*                                       should be in df->cflw.
*
*               DISCFAC    *df_disc     Discounting structure setup.
*                                       Used for discounting
*                                       The initial (unshocked) curve
*                                       should be in df->disc.
*
*               VOL_STR    *vol         Forward volatility structure.
*
*               CMCONVADJ  *cmadj       Data for Convexity Adjustment
*                                       Use NULL if no adjustment
*
*               FL64       fx_spot      FX spot rate.
*                                       The initial (unshocked) rate.
*
*               CAP        *cap         The cap definition.
*
*               HOLI_STR   *holi        Business day adjustment setup.
*
*               DELTASET   *ds_cflw     Curve shock definitions for
*                                       the the curve in df_cflw.
*
*               DELTASET   *ds_disc     Curve shock definitions for
*                                       the the curve in df_disc.
*
*               FXSHOCKSET *fxs         FX shock definitions.
*
*   output
*
*   returns     The vector of scenario BPV as:
*
*                         Alloc_FL64ARRAY(ds->nshock) ;
*
*   diagnostics
*
*   see also    Disc_ScenarioPrep()
*               SwapFl_DF2ScenBPV()
*               RepoCflw_DF2ScenBPV()
*
*************************************************************************
,,EOH,,*/

FL64ARRAY Cap_Black2ScenBPV(DATESTR* analys,
                        DATESTR*    voldate,
                        DISCFAC*    df_cflw,
                        DISCFAC*    df_disc,
                        VOL_STR*    vol,
                        CMCONVADJ*  cmadj,
                        FL64       fx_spot,
                        CAP*        cap,
                        HOLI_STR*   holi,
                        DELTASET*   ds_cflw,
                        DELTASET*   ds_disc,
                        FXSHOCKSET* fxs)
{
    CAPLETS   capl ;
    FL64ARRAY dv ;

    /* Translate */
    capl = Cap_CAP2CAPLETS(cap, holi) ;

    /* Calculate */
    dv = Caplets_Black2ScenBPV(analys, voldate, df_cflw, 
        df_disc, vol, cmadj, fx_spot, &capl, holi, ds_cflw, 
        ds_disc, fxs);

    Free_IRGARRAY(capl.irg) ;

    return dv ;
}



/*,,SOH,,
*************************************************************************
*
*               Swaption_Black2ScenBPV()
*
*   interface   #include <optscen.h>
*               FL64ARRAY Swaption_Black2ScenBPV(DATESTR  *analys,
*                                         DATESTR    *voldate,
*                                         DISCFAC    *df_cflw,
*                                         DISCFAC    *df_disc,
*                                         FL64       vol,
*                                         CMCONVADJ  *cmadj,
*                                         FL64       fx_spot,
*                                         SWAPTION   *ncsw,
*                                         HOLI_STR   *holi,
*                                         B76SWTM    *b76t,
*                                         DELTASET   *ds_cflw,
*                                         DELTASET   *ds_disc,
*                                         FXSHOCKSET *fxs,
*                                         BOOLE      *ok);
*
*   general     The routine calculates the vector of scenario BPV's for
*               a swaption using a list of predefined shocks to the
*               zero coupon curve and a list of predefined FX shocks.
*               Each zero coupon curve shock corresponds to a single
*               FX shock.
*
*               The scenario BPV represents the price differences
*               invoked by the curve shocks between the shocked PV's
*               and the initial PV.
*
*               It is required that the number of zero coupon curve
*               shocks match the number of FX shocks, ie.
*
*                fxs->nshock == ds_cflw->nshock == ds_disc->nshock
*
*               However, fxs may be set to NULL, in which case FX
*               shocking is ignored and the scenario BPV are calculated
*               in instrument ccys only. Otherwise BPV's are in
*               domestic (home ccy)
*
*               Scenarios may be used for evaluation of
*               - Randomly chosen curve/fx shocks,
*               - Historical scenarios/simulation,
*               - Expert scenarios,
*               - Worst case analysis, etc.
*
*               Refer to Swaption_Black2P() for pricing model
*               description.
*
*   input       DATESTR    *analys      The analysis date.
*
*               DATESTR    *voldate     Vol calculated from this date
*
*               DISCFAC    *df_cflw     Discounting structure setup.
*                                       Used to generate payments
*                                       The initial (unshocked) curve
*                                       should be in df->cflw.
*
*               DISCFAC    *df_disc     Discounting structure setup.
*                                       Used for discounting
*                                       The initial (unshocked) curve
*                                       should be in df->disc.
*
*               FL64       vol          Forward volatility.
*
*               CMCONVADJ  *cmadj       Data for Convexity Adjustment
*                                       Use NULL if no adjustment
*
*               FL64       fx_spot      FX spot rate.
*                                       The initial (unshocked) rate.
*
*               SWAPTION   *ncsw        The swaption definition.
*
*               HOLI_STR   *holi        Business day adjustment setup.
*
*               B76SWTM    *b76t        Black 76 model variation to be
*                                       used.
*                                       Use NULL for default
*
*               DELTASET   *ds_cflw     Curve shock definitions for
*                                       the the curve in df_cflw.
*
*               DELTASET   *ds_disc     Curve shock definitions for
*                                       the the curve in df_disc.
*
*               FXSHOCKSET *fxs         FX shock definitions.
*
*   output      BOOLE      *ok          True if all OK, False if not.
*
*   returns     The vector of scenario BPV as:
*
*                         Alloc_FL64ARRAY(ds->nshock) ;
*
*   diagnostics
*
*   see also    Disc_ScenarioPrep()
*               SwapFl_DF2ScenBPV()
*               Cap_Black2ScenBPV()
*
*************************************************************************
,,EOH,,*/

FL64ARRAY Swaption_Black2ScenBPV(DATESTR* analys,
                        DATESTR*    voldate,
                        DISCFAC*    df_cflw,
                        DISCFAC*    df_disc,
                        FL64       vol,
                        CMCONVADJ*  cmadj,
                        FL64       fx_spot,
                        SWAPTION*   ncsw,
                        HOLI_STR*   holi,
                        B76SWTM*    b76t,
                        DELTASET*   ds_cflw,
                        DELTASET*   ds_disc,
                        FXSHOCKSET* fxs,
                        BOOLE*      ok)
{
    INTI      i, fx_size ;
    FL64ARRAY dv ;
    FL64      p0, dum, pShock, bpv ;
    PLANARRAY old_cflw, old_disc ;
    BOOLE noFx;

    dv = NULL;

    if (FXSHOCKSET_IsEmpty(fxs))
    {
      noFx = True;
      fx_size = 0;
    }
    else
    {
      fx_size = fxs->nshock;
      noFx = False;
    }

    if (ds_disc->nshock == ds_cflw->nshock && 
        (noFx || ds_cflw->nshock == fx_size))
    {
        /* Initialise */
        dv        = Alloc_FL64ARRAY(ds_cflw->nshock) ;
        old_cflw  = df_cflw->disc ;
        old_disc  = df_disc->disc ;

        /* The unshocked price */
        *ok = Swaption_Black2P(analys, voldate, vol, ncsw, df_disc, 
            df_cflw, cmadj, holi, b76t, NULL, &p0, &dum, &dum);

        for (i = 0; i < ds_cflw->nshock && *ok; i++)
        {
            df_cflw->disc = &ds_cflw->shock[i];
            df_disc->disc = &ds_disc->shock[i];

            *ok = Swaption_Black2P(analys, voldate, vol, ncsw, 
                df_disc, df_cflw, cmadj, holi, b76t, NULL, &pShock, 
                &dum, &dum);

            if (noFx)
              bpv = pShock - p0;
            else
              bpv = pShock * fxs->shocked[i] - p0 * fx_spot;

            dv[i] = bpv;
        }

        df_disc->disc = old_disc;
        df_cflw->disc = old_cflw;
    }

    return dv ;
}


/*,,SOH,,
*************************************************************************
*
*               OptFutBond_Black2ScenBPV()
*
*   interface   #include <optscen.h>
*               FL64ARRAY OptFutBond_Black2ScenBPV(DATESTR  *analys,
*                                             DATESTR    *voldate,
*                                             FL64       vol,
*                                             FL64       fx_spot,
*                                             INTI       noas,
*                                             DFSPREADARRAY dfs,
*                                             FUTBOND    *futb,
*                                             OPTFUT     *opt,
*                                             DISCFAC    *df,
*                                             HOLI_STR   *holi,
*                                             DELTASET   *ds,
*                                             FXSHOCKSET *fxs);
*
*   general     The routine calculates the vector of scenario BPV's for
*               a bond future option using a list of predefined
*               shocks to the zero coupon curve and a list of
*               predefined FX shocks.
*               Each zero coupon curve shock corresponds to a single
*               FX shock.
*
*               The scenario BPV represents the price differences
*               invoked by the curve shocks between the shocked PV's
*               and the initial PV.
*
*               It is required that the number of zero coupon curve
*               shocks match the number of FX shocks, ie.
*
*                        fxs->nshock == ds->nshock
*
*               However, fxs may be set to NULL, in which case FX
*               shocking is ignored and the scenario BPV are calculated
*               in instrument ccys only. Otherwise BPV's are in
*               domestic (home ccy)
*
*               Scenarios may be used for evaluation of
*               - Randomly chosen curve/fx shocks,
*               - Historical scenarios/simulation,
*               - Expert scenarios,
*               - Worst case analysis, etc.
*
*               Refer to OptFutBond_Black2DFp() for pricing model
*               description.
*
*    input      DATESTR   *analys   Pointer to analysis date (NPV date)
*
*               DATESTR   *voldate  Vol calculated from this date.
*
*               FL64      vol       The annual volatility of the
*                                   futures price in percent.
*
*               FL64      fx_spot   Spot exchange rate. Price in
*                                   domestic currency of foreign
*                                   currency units.
*                                   The initial (unshocked) rate.
*
*               INTI      noas      No. of elements in dfs.
*                                   If noas > 0 and noas < futb->nbond, 
*                                   only the first noas bonds are 
*                                   considered.
*
*               DFSPREADARRAY dfs   Spread of the bond against the zero
*                                   curve (df). Quoted in %.
*                                   Set to NULL if no spread
*                                   Dimension [noas]
*
*               FUTBOND   *futb     The bond data for the underlying 
*                                   bond. futb->margin and futb->futp
*                                   is not used by this function.
*
*               OPTFUT    *opt      The data defining the option.
*                                   ->oadd assumed as NO_OPTADD.
*
*               DISCFAC   *df       Discount function for discounting
*                                   option payout, and for finding the
*                                   futures price using the entire bond
*                                   cashflow.
*
*               HOLI_STR  *holi     Holiday adjustment setup
*
*               DELTASET   *ds      Curve shock definitions.
*
*               FXSHOCKSET *fxs      FX shock definitions.
*
*   output
*
*   returns     The vector of scenario BPV as:
*
*                         Alloc_FL64ARRAY(ds->nshock) ;
*
*   diagnostics
*
*   see also    Disc_ScenarioPrep()
*               OptFutBond_Black2DFp()
*               OptFutBond_Black2Delta()
*               OptBond_Black2ScenBPV()
*
*************************************************************************
,,EOH,,*/

FL64ARRAY OptFutBond_Black2ScenBPV(DATESTR* analys,
                        DATESTR*  voldate,
                        FL64     vol,
                        FL64     fx_spot,
                        INTI     noas,
                        DFSPREADARRAY dfs,
                        FUTBOND*  futb,
                        OPTFUT*   opt,
                        DISCFAC*  df,
                        HOLI_STR* holi,
                        DELTASET*   ds,
                        FXSHOCKSET* fxs)
{
    FL64ARRAY dv;
    INTI      size, i;
    FL64      p0, pShock, bpv, dum;

    dv = NULL;

    if (FXSHOCKSET_IsEmpty(fxs))
    {
        dv = OptFutBond_Black2Delta(analys, voldate, vol, noas, dfs, 
            futb, opt, df, holi, ds);
    }
    else if (ds->nshock == fxs->nshock)
    {
        size = ds->nshock;

        /* The unshocked price */
        p0 = OptFutBond_Black2DFp(analys, voldate, vol, noas, dfs, 
                     futb, opt, df,holi, NULL, &dum, &dum) ; 
        dv = OptFutBond_Black2Delta(analys, voldate, vol, noas, dfs, 
            futb, opt, df, holi, ds);
        for(i = 0; i < size; i++)
        {
            pShock = dv[i] + p0;
            bpv = pShock * fxs->shocked[i] - p0 * fx_spot;
            dv[i] = bpv;
        }
    }

    return dv;
}




/*,,SOH,,
*************************************************************************
*
*               OptBond_Black2ScenBPV()
*
*   interface   #include <optscen.h>
*               FL64ARRAY OptBond_Black2ScenBPV(DATESTR  *analys,
*                                             DATESTR    *voldate,
*                                             FL64       vol,
*                                             FL64       fx_spot,
*                                             DFSPREAD   *dfs,
*                                             FIXPAY     *fixp,
*                                             OPTFUT     *opt,
*                                             DISCFAC    *df,
*                                             HOLI_STR   *holi,
*                                             DELTASET   *ds,
*                                             FXSHOCKSET *fxs);
*
*   general     The routine calculates the vector of scenario BPV's for
*               a bond future option using a list of predefined
*               shocks to the zero coupon curve and a list of
*               predefined FX shocks.
*               Each zero coupon curve shock corresponds to a single
*               FX shock.
*
*               The scenario BPV represents the price differences
*               invoked by the curve shocks between the shocked PV's
*               and the initial PV.
*
*               It is required that the number of zero coupon curve
*               shocks match the number of FX shocks, ie.
*
*                        fxs->nshock == ds->nshock
*
*               However, fxs may be set to NULL, in which case FX
*               shocking is ignored and the scenario BPV are calculated
*               in instrument ccys only. Otherwise BPV's are in
*               domestic (home ccy)
*
*               Scenarios may be used for evaluation of
*               - Randomly chosen curve/fx shocks,
*               - Historical scenarios/simulation,
*               - Expert scenarios,
*               - Worst case analysis, etc.
*
*               Refer to OptBond_Black2P() for pricing model
*               description.
*
*    input      DATESTR   *analys   Pointer to analysis date (NPV date)
*
*               DATESTR   *voldate  Vol calculated from this date.
*
*               FL64      vol       The annual volatility of the
*                                   futures price in percent.
*
*               FL64      fx_spot   Spot exchange rate. Price in
*                                   domestic currency of foreign
*                                   currency units.
*                                   The initial (unshocked) rate.
*
*               DFSPREAD  *dfs      Spread of the bond against the zero
*                                   curve (df). Quoted in %.
*
*               FIXPAY    *fixp     The bond data
*
*               OPTFUT    *opt      The data defining the option.
*                                   ->oadd assumed as NO_OPTADD.
*
*               DISCFAC   *df       Discount function for discounting
*                                   option payout, and for finding the
*                                   futures price using the entire bond
*                                   cashflow.
*
*               HOLI_STR  *holi     Holiday adjustment setup
*
*               DELTASET   *ds      Curve shock definitions.
*
*               FXSHOCKSET *fxs      FX shock definitions.
*
*   output
*
*   returns     The vector of scenario BPV as:
*
*                         Alloc_FL64ARRAY(ds->nshock) ;
*
*   diagnostics
*
*   see also    Disc_ScenarioPrep()
*               OptBond_Black2DFp()
*               OptFutBond_Black2ScenBPV()
*               OptFutBond_Black2ScenBPV()
*               Bond_DF2ScenBPV()
*
*************************************************************************
,,EOH,,*/

FL64ARRAY OptBond_Black2ScenBPV(DATESTR* analys,
                        DATESTR*  voldate,
                        FL64     vol,
                        FL64     fx_spot,
                        DFSPREAD* dfs,
                        FIXPAY*   fixp,
                        OPTFUT*   opt,
                        DISCFAC*  df,
                        HOLI_STR* holi,
                        DELTASET*   ds,
                        FXSHOCKSET* fxs)
{
  FL64 cf = 1.0 ;
  FUTBOND futb ;

  futb = Set_FUTBOND(1, &opt->dfix, 1, fixp, &cf, 0.0, True, False) ;

  return OptFutBond_Black2ScenBPV(analys, voldate, vol, fx_spot, 1, 
                        dfs, &futb, opt, df, holi, ds, fxs) ;
}






/*,,SOH,,
*************************************************************************
*
*               Convtbl_CRR2ScenBPV()
*
*   interface   #include <optscen.h>
*               FL64ARRAY Convtbl_CRR2ScenBPV(DATESTR      *analys,
*                                             FL64         spot,
*                                             FL64         vol,
*                                             FL64         fx_spot,
*                                             CONVTBL      *cvt,
*                                             INTI         nstep,
*                                             DISCFAC      *df,
*                                             DFSPREAD     *dfs,
*                                             DISCFAC      *divdf,
*                                             HOLI_STR     *holi,
*                                             DELTASET     *ds,
*                                             FXSHOCKSET   *fxs,
*                                             EQTYSHOCKSET *eqtys,
*                                             BOOLE        *ok) ;
*
*   general     The routine calculates the vector of scenario BPV's for
*               a convtible bond using a list of predefined shocks to
*               the zero coupon curve, a list of predefined FX shocks,
*               and a list of spot shocks.
*               Each zero coupon curve shock corresponds to a single
*               FX shock and a spot shock.
*
*               The scenario BPV represents the price differences
*               invoked by the curve shocks between the shocked PV's
*               and the initial PV.
*
*               It is required that the number of zero coupon curve
*               shocks match the number of FX shocks and the number of
*               equity shocks, ie.
*
*                     eqtys->nshock == fxs->nshock == ds->nshock
*
*               However, fxs and/or eqtys may be set to NULL, in which
*               case FX and/or equity shocking is ignored. If fxs is
*               NULL the scenario BPV are calculated  in instrument
*               ccys only. Otherwise BPV's are in domestic (home ccy).
*               If eqtys is NULL spot is used in all PV calculations.
*
*               Scenarios may be used for evaluation of
*               - Randomly chosen curve/fx shocks/equity shocks,
*               - Historical scenarios/simulation,
*               - Expert scenarios,
*               - Worst case analysis, etc.
*
*               Refer to Convtbl_CRR2P() for pricing model description.
*
*    input      DATESTR    *analys    Pointer to analysis date
*                                     (NPV date).
*
*               FL64       spot       The spot price.
*                                     Must not be preADJUSTED for
*                                     dividends at entry.
*
*               FL64       vol        The annual volatility of the Spot
*                                     price in percent.
*
*               FL64       fx_spot    Spot exchange rate. Price in
*                                     domestic currency of foreign
*                                     currency units.
*                                     The initial (unshocked) rate.
*
*               CONVTBL    *cvt       The convertible data
*
*               INTI       nstep      Number of steps in the Binomial
*                                     Tree.
*
*               DISCFAC    *df        Discount function for discounting
*                                     the option payout.
*
*               DFSPREAD   *dfs       Corporate spread to 'df'
*
*               DISCFAC    *divdf     Term structure of dividend yields
*
*               HOLI_STR   *holi      Holiday adjustment rules
*
*               DELTASET   *ds        Curve shock definitions.
*
*               FXSHOCKSET *fxs       FX shock definitions.
*
*               EQTYSHOCKSET *eqtys   Equity shock definitions.
*
*   output      BOOLE      *ok        True if all ok, False if not.
*
*   returns     The vector of scenario BPV as:
*
*                         Alloc_FL64ARRAY(ds->nshock) ;
*
*   diagnostics
*
*   see also    Disc_ScenarioPrep()
*               OptEqty_CRR2P()
*               OptEqty_CRR2Delta()
*               OptFX_CRR2ScenBPV()
*
*************************************************************************
,,EOH,,*/
FL64ARRAY Convtbl_CRR2ScenBPV(DATESTR*       analys,
                                  FL64           spot,      
                                  FL64           vol,       
                                  FL64           fx_spot,
                                  CONVTBL*       cvt,
                                  INTI           nstep,     
                                  DISCFAC*       df,       
                                  DFSPREAD*      dfs,
                                  DISCFAC*       divdf,
                                  HOLI_STR*      holi,     
                                  DELTASET*      ds,  
                                  FXSHOCKSET*    fxs,
                                  EQTYSHOCKSET*  eqtys,
                                  BOOLE*         ok)
{
    FL64ARRAY dv;
    INTI      size, i;
    FL64      p0, pShock, bpv, dum, spotshock;
    BOOLE     dsdomold, fx_IsEmpty, spot_IsEmpty;
    PLANARRAY old ;

    dv = NULL;
    dsdomold = ds->dom;

    ds->dom = True;

    fx_IsEmpty   = FXSHOCKSET_IsEmpty(fxs) ;
    spot_IsEmpty = EQTYSHOCKSET_IsEmpty(eqtys) ;

    /* No FX and EQTY shocks */
    if (fx_IsEmpty && spot_IsEmpty)
        dv = Convtbl_CRR2Delta(analys, spot, vol, nstep, cvt, df, dfs, 
                               divdf, holi, ds, ok) ;
    /* FX and/or EQTY shocks */
    else if ( (ds->nshock == fxs->nshock && ds->nshock == eqtys->nshock) ||
              (ds->nshock == fxs->nshock && spot_IsEmpty)  ||
              (ds->nshock == eqtys->nshock && fx_IsEmpty) )
    {
        size = ds->nshock;

        /* The unshocked price */
        *ok = Convtbl_CRR2Price(analys, spot, vol, nstep, cvt, df, dfs,
                                divdf, holi, NULL, &p0, &dum, &dum) ;

        old = df->disc ;
        dv = Alloc_FL64ARRAY(size) ;

        for(i = 0; i < size && *ok == True; i++)
        {
            /* Shocked spot price */
            spotshock = (spot_IsEmpty ? spot : eqtys->shocked[i]) ;
            
            df->disc = &ds->shock[i] ;

            /* Shocked price */
            *ok = Convtbl_CRR2Price(analys, spotshock, vol, nstep, cvt, 
                                    df, dfs, divdf, holi, NULL, 
                                    &pShock, &dum, &dum) ;

            if (fx_IsEmpty)
                bpv = pShock - p0;
            else
                bpv = pShock * fxs->shocked[i] - p0 * fx_spot;
            
            dv[i] = bpv;
        }

        df->disc = old ;

    }

    ds->dom = dsdomold;

    return dv;
}







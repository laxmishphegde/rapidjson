/* SCID @(#)capio.c	1.18 (SimCorp) 99/08/30 13:37:34 */

/************************************************************************
*
*   Project     SCecon
*
*   file name   ioutils.c
*
*   general     This file contains file io functions
*
************************************************************************/

/* includes    *********************************************************/
#include <capio.h>
#include <ioconv.h>
#include <capvl.h>
#include <optio.h>
#include <futio.h>
#include <bondio.h>

B76SM Str2B76SM(TEXT txt)
{
    B76SM iw = B76SM_RATE;

    if (!strcmp("B76SM_RATE", txt))            iw = B76SM_RATE ;
    else if (!strcmp("B76SM_RATEPA", txt))     iw = B76SM_RATEPA ;
    else if (!strcmp("B76SM_PRICE", txt))      iw = B76SM_PRICE ;
    else if (!strcmp("B76SM_SCORIG", txt))     iw = B76SM_SCORIG ;
    else
        SCecon_error("b76swtmdl unknown\n", "str2b76swtmdl()", 
            SCECONABORT) ;

    return iw ;
}

/*
..
*/


B76SM Read_B76SM(FILE* in, FILE* out, TEXT dscr)
{
    B76SM irr;
    CH txb[MAX_KEYWORD_LENGTH];

      /* Comments, if any: */
    if (!IOUtil_ReadComment(in, out))
        Write_Comment(out, dscr);

    Read_TEXT(in, MAX_KEYWORD_LENGTH, txb);
    irr = Str2B76SM(txb);

    fprintf(out, " %s\n", txb);

    return irr;
}

/*
..
*/


B76SWTM Read_B76SWTM(FILE* in, FILE* out)
{
    char    txb[25] ;
    B76SWTM b76t ;

    fscanf(in, "%s", txb) ;
    b76t.b76sm = Str2B76SM(txb) ;
    fprintf(out,"   SwaptionModel  %8s\n", txb) ;

    fscanf(in, "%s", txb) ;
    b76t.use_fwd = Str2BOOLE(txb) ;
    fprintf(out,"   Use Forward ?  %8s\n", txb) ;

    fscanf(in, "%lf", &b76t.fwdswap) ;
    fprintf(out,"   Fwd Swaprate   %8lf\n", b76t.fwdswap) ;

    Write_VALIDATEError(out, Validate_B76SWTM(&b76t));

    return b76t ;
}


/*
..
*/



SWAPTIONARRAY Read_SWAPTIONARRAY(FILE* in, FILE* out, INTI* n)
{
    SWAPTIONARRAY swoa ;
    INTI          i ;
    int           i1 ;
    long          ymd1, ymd3 ;
    FL64          swaprate ;
    char          txk[20], txb[20] ;
    DATESTR       start, end, dzero, maturity ;
    PMTFREQ       freq ;
    CALCONV       cal ;
    OPTTYPE       type ;

    dzero = Cldr_YMD2Datestr((YYYYMMDD) 0) ;

    fscanf(in, "%d", &i1) ;
    *n = (INTI) i1 ;

    swoa = Alloc_SWAPTIONARRAY(*n) ;
    fprintf(out,"   Swaption array is...\n") ;
    for (i = 0 ; i < *n ; i++)
    {
        swoa[i].vanilla = True ;
        fscanf(in, "%ld %lf %ld %s %s", &ymd1, &swaprate, &ymd3, txk, txb) ;
        start  = Cldr_YMD2Datestr(ymd1) ;
        end    = Cldr_YMD2Datestr(ymd3) ;
        freq   = Str2PMTFREQ(txk) ;
        cal    = Str2CALCONV(txb) ;
        fprintf(out, "   %8lf %8ld %8ld %8s %8s",
                swaprate, ymd1, ymd3, txk, txb) ;

        fscanf(in, "%s %ld", txk, &ymd1) ;
        type     = Str2OPTTYPE(txk) ;
        maturity = Cldr_YMD2Datestr((YYYYMMDD) ymd1) ;
        fprintf(out,"   %8s %8ld\n", txk, ymd1) ;

        swoa[i].pfix = cflw_set_payday(&start, &dzero, &end, False,
                                       Cflw_MonthsBetweenPayments(freq),
                                       MONTHS, NOODD, NOODD, ANCHOR, LAST) ;
        swoa[i].fix  = Set_FIXRATE(swaprate, cal, &start, &end, 0.0,
                                   ODDCOUP, ODDCOUP, False, False, NULL, 
                                   True, NULL, NODCOMP) ;

        swoa[i].type     = type ;
        swoa[i].maturity = maturity ;
        swoa[i].cal      = cal ;
        swoa[i].swapstl  = True ;
    }

    Write_VALIDATEError(out, Validate_SWAPTIONARRAY(swoa, *n));

    return swoa ;
}

/*
..
*/


CAPARRAY Read_CAPARRAY(FILE*  in, FILE*  out, INTI*  ncap)
{
    CAPARRAY  caps;
    COUNT     type;
    INTI      i;

    caps = NULL;

    fprintf(out,"   CAP:\n") ;
    type = Read_FormatId(in, out);

    switch (type)
    {
    case 1:
        *ncap = Read_INTI(in, out, "  No. of caps      ");

        caps = Alloc_CAPARRAY(*ncap);
        for (i = 0; i < *ncap; i++)
        {
            caps[i] = Read_CAP(in, out);
        }
    }

    Write_VALIDATEError(out, Validate_CAPARRAY(caps, *ncap));

    return caps;
}

/*
..
*/

CAP Read_CAP(FILE* in, FILE* out)
{
    COUNT     type ;
    CAP       c ;
    OPTTYPE   otype ;
    FL64      fix, strike ;
    PAYDAYDEF fix_days ;
    CALCONV   cal ;
    EOMCONV   eom ;
    DATESTR   today ;
    PERIOD    per ;
    PMTFREQ   freq ;

    fprintf(out,"*   CAP:\n") ;

    type = Read_FormatId(in, out);

    c.step_str = NULL;
    c.step_not = NULL;
    c.fix_days.irreg_days = NULL;
    c.fix_days.nirreg = 0;

    c.method = NONE;
    c.compfreq = NO_FREQUENCY;

    switch (type)
    {
        case 1:
            c.type = Read_OPTTYPE(in, out, "Type") ;
            c.strike = Read_FL64(in, out, "Strike") ;
            c.cal = Read_CALCONV(in, out, "Day count") ;
            c.fix_days = Read_PAYDAYDEF(in, out) ;

            c.notional = Read_FL64(in, out, "Notional") ;
            c.LIBORfix = Read_FL64(in, out, "LIBORfix") ;
            c.vanilla = Read_BOOLE(in, out, "Vanilla") ;
            c.factor = 1.0 ;

            c.delay.num  = Read_INTI(in, out, "Delay") ;
            c.delay.unit = Read_TERMUNIT(in, out, "Delay Unit") ;
            c.qot = Read_QOTCONV(in, out, "Quoting") ;
            c.index = Read_RATEINDEX(in, out) ;

            c.arrears = Read_BOOLE(in, out, "Arrears") ;
            c.margin = Read_BOOLE(in, out, "Margin") ;
            c.qprice = Read_BOOLE(in, out, "QuotePrice") ;

            c.method   = Read_COMPMETHOD(in, out, "  Compounding ") ;
            c.compfreq = Read_PMTFREQ(in, out, "  Comp Freq   ") ;

            fprintf(out,"* Stepped Strike:\n") ;
            c.step_str = Read_PLANARRAY(in) ;
            Write_PLANARRAY(out, c.step_str) ;

            fprintf(out,"* Stepped Amortisations:\n") ;
            c.step_not = Read_PLANARRAY(in) ;
            Write_PLANARRAY(out, c.step_not) ;

            break ;

        case 2:
            otype = Read_OPTTYPE(in, out, "Type") ;
            strike = Read_FL64(in, out, "Strike") ;
            cal = Read_CALCONV(in, out, "Day count") ;
            fix_days = Read_PAYDAYDEF(in, out) ;
            {
                const FL64 notional = Read_FL64(in, out, "Notional") ;
                fix = Read_FL64(in, out, "LIBORfix") ;

                c = Set_CAP(otype, strike, cal, &fix_days, notional, fix) ;
            }
            break ;

        case 3:
            c.type = Read_OPTTYPE(in, out, "Type") ;
            c.strike = Read_FL64(in, out, "Strike") ;
            c.cal = Read_CALCONV(in, out, "Day count") ;
            c.fix_days = Read_PAYDAYDEF(in, out) ;
            c.notional = Read_FL64(in, out, "Notional") ;
            c.LIBORfix = Read_FL64(in, out, "LIBORfix") ;
            c.factor = 1.0 ;
            c.delay = Set_PERIOD(0, DAYS) ;
            c.qot = Q_FLAT ;
            c.index = Read_RATEINDEX(in, out) ;

            c.arrears = False ;
            c.margin  = False ;
            c.qprice  = False ;
            c.step_not = NULL ;
            c.step_str = NULL ;
            c.vanilla = False ;
            c.oadd    = NO_OPTADD ;

            break ;

        case 4:
        case 7:
            
            today  = Read_DATESTR(in, out, "   Today      ") ;
            otype  = Read_OPTTYPE(in, out, "   Type       ") ;
            per    = Read_PERIOD(in) ;
            Write_PERIOD(out, "   Cap Term:   ", &per) ;

            freq   = Read_PMTFREQ(in, out, "   Frequency   ") ;
            strike = Read_FL64(in, out, "   Strike     ") ;   
            cal    = Read_CALCONV(in, out, "   Cal        ") ;            
            eom    = Read_EOMCONV(in, out, "   Eom        ") ;
            c = Cap_Simple2CAP(&today, otype, &per, freq, strike, cal, eom) ;

            c.vanilla = False;

            break ;

        case 5:
        case 6:
            
            today  = Read_DATESTR(in, out, "   Today      ") ;
            otype  = Read_OPTTYPE(in, out, "   Type       ") ;
            per    = Read_PERIOD(in) ;
            Write_PERIOD(out, "* Cap Term:   ", &per) ;

            freq   = Read_PMTFREQ(in, out, "   Frequency   ") ;
            strike = Read_FL64(in, out, "   Strike     ") ;   
            cal    = Read_CALCONV(in, out, "   Cal        ") ;            
            eom    = Read_EOMCONV(in, out, "   Eom        ") ;
            c = Cap_Simple2CAP(&today, otype, &per, freq, strike, cal, eom) ;

            c.vanilla = False ;
            c.factor  = Read_FL64(in, out, "   Factor     ") ;   
            c.index   = Read_RATEINDEX(in, out) ;

            c.method   = Read_COMPMETHOD(in, out, "  Compounding ") ;
            c.compfreq = Read_PMTFREQ(in, out, "  Comp Freq   ") ;

            if (type == 6)
                c.notional = Read_FL64(in, out, "   Notional   ") ;

            break ;

    }

    switch (type)
    {
    case 7:
        c.vanilla = False;

    case 1:
/*..Read_OPTADD() */
        c.oadd = Read_OPTADD(in, out, "OptAdd") ;

        switch (c.oadd)
        {
        case NO_OPTADD:
            break ;

        case SHARKFIN:
            c.sfin.btype = Read_KNOCKTYPE(in, out, "Type") ;
            c.sfin.barrier = Read_FL64(in, out, "Barrier") ;
            c.sfin.rebate = Read_FL64(in, out, "Rebate") ;

            c.sfin.poff.poff = Read_PAYOFF(in, out, "Payoff") ;
            c.sfin.poff.gap = Read_FL64(in, out, "Gap") ;
            c.sfin.poff.scale = Read_FL64(in, out, "Scale") ;
            break ;

        case ASIAN:
            c.asian.num_avg = Read_INTI(in, out, "Num. Avg.");
            c.asian.curr_avg = Read_FL64(in, out, "Curr. Avg.");
            c.asian.avgrt = Read_BOOLE(in, out, "Avg Rate");
            c.asian.last_avg = Read_FL64(in, out, "Last Avg.");
            break ;

        case BINARY :
            c.bini.poff.poff = Read_PAYOFF(in, out, "Payoff") ;
            c.bini.poff.gap = Read_FL64(in, out, "Gap") ;
            c.bini.poff.scale = Read_FL64(in, out, "Scale") ;
            c.bini.dcadj = Read_BOOLE(in, out, "Day-count period adjust") ;
            break ;

        case CONTPREM:
            c.ctp.prem = Read_FL64(in, out, "Cont. Prem.") ;
            break ;

        case RESET:
            c.reset.spread = Read_FL64(in, out, "Spread") ;
            c.reset.nfirst = Read_INTI(in, out, "First Reset") ;
            c.reset.nfreq = Read_INTI(in, out, "Reset Freq") ;
            c.reset.delayfix = Read_BOOLE(in, out, "Delay Fix ?") ;
            c.reset.spread_low = Read_FL64(in, out, "Spread low") ;
            c.reset.spread_up = Read_FL64(in, out, "Spread up" ) ;            
            break ;

        case FLEXICAP:
            c.flexicap = Read_FLEXICAPINF(in, out);
            break;

        default:
            ;
        }

    default:
        break;
    }
          


    Write_VALIDATEError(out, Validate_CAP(&c));

    return c ;
}


/*
..
*/

CAPLETS Read_CAPLETS(FILE* in, FILE* out, CALCONV cal, QOTCONV qot,
                     PMTFREQ freq, FL64 Lfix, RATEINDEX* index)
{
    CAPLETS  capl ;
    int      i1 ;
    INTI     i ;
    char     txb[20], txc[20] ;
    YYYYMMDD ymd, ymd1, ymd2, ymd3, ymd4 ;
    FL64     scale = 0, gap = 0 ;
    PAYOFF   poff = OP_VANILLA;
    COUNT    type;

    type = Read_FormatId(in, out);

    switch (type)
    {
        case 1:

            fscanf(in, "%d", &i1) ;
            capl.count = (INTI) i1 ;
            capl.irg = Alloc_IRGARRAY(i1) ;

            fprintf(out,"   IRG Array is...\n") ;
            for (i = 0 ; i < i1 ; i++)
            {
                fscanf(in,"%s %s %lf %ld %ld %ld %lf %lf %lf",
                       txb, txc, &capl.irg[i].strike, &ymd, &ymd2, &ymd1,
                       &capl.irg[i].size, &scale, &gap) ;
                capl.irg[i].type  = Str2OPTTYPE(txb) ;
                poff = Str2PAYOFF(txc) ;
                capl.irg[i].fix_start = Cldr_YMD2Datestr(ymd) ;
                capl.irg[i].fix_end   = Cldr_YMD2Datestr(ymd2) ;
                capl.irg[i].pay_day   = Cldr_YMD2Datestr(ymd1) ;
                capl.irg[i].period_start = Cldr_YMD2Datestr(ymd) ;
                capl.irg[i].period_end   = Cldr_YMD2Datestr(ymd2) ;
                capl.irg[i].LIBORfix  = Lfix ;

                fprintf(out,"    %s %s %lf %8ld %8ld %8ld %lf %lf %lf\n",
                       txb, txc, capl.irg[i].strike, ymd, ymd2, ymd1,
                         capl.irg[i].size,
                       scale, gap) ;
            }

            capl.cal   = cal ;
            capl.qot   = qot ;
            capl.eom   = SAME ;
            capl.freq  = freq ;
            capl.index = *index ;
            capl.oadd  = NO_OPTADD ;

            capl.method = NONE;
            capl.compfreq = NO_FREQUENCY;

            if (poff != OP_VANILLA)
            {
                capl.oadd = BINARY ;
                capl.bini.poff.poff  = poff ;
                capl.bini.poff.scale = scale ;
                capl.bini.poff.gap   = gap ;
                capl.bini.dcadj      = False;
            }

            break ;

        case 2:

            fscanf(in, "%d", &i1) ;
            capl.count = (INTI) i1 ;
            capl.irg = Alloc_IRGARRAY(i1) ;

            fprintf(out,"   IRG Array is...\n") ;
            for (i = 0 ; i < i1 ; i++)
            {
                fscanf(in,"%s %s %lf %ld %ld %ld %ld %ld %lf %lf %lf",
                       txb, txc, &capl.irg[i].strike, &ymd, &ymd2, &ymd1,
                       &ymd3, &ymd4,
                       &capl.irg[i].size, &scale, &gap) ;
                capl.irg[i].type  = Str2OPTTYPE(txb) ;
                poff = Str2PAYOFF(txc) ;
                capl.irg[i].fix_start = Cldr_YMD2Datestr(ymd) ;
                capl.irg[i].fix_end   = Cldr_YMD2Datestr(ymd2) ;
                capl.irg[i].pay_day   = Cldr_YMD2Datestr(ymd1) ;
                capl.irg[i].period_start = Cldr_YMD2Datestr(ymd3) ;
                capl.irg[i].period_end   = Cldr_YMD2Datestr(ymd4) ;
                capl.irg[i].LIBORfix  = Lfix ;

            fprintf(out,"    %s %s %lf %8ld %8ld %8ld %8ld %8ld %lf %lf %lf\n",
                       txb, txc, capl.irg[i].strike, ymd, ymd2, ymd1,
                       ymd3, ymd4, capl.irg[i].size, scale, gap) ;
            }

            capl.cal   = cal ;
            capl.qot   = qot ;
            capl.eom   = SAME ;
            capl.freq  = freq ;
            capl.index = *index ;
            capl.oadd  = NO_OPTADD ;

            capl.method = NONE;
            capl.compfreq = NO_FREQUENCY;

            if (poff != OP_VANILLA)
            {
                capl.oadd = BINARY ;
                capl.bini.poff.poff  = poff ;
                capl.bini.poff.scale = scale ;
                capl.bini.poff.gap   = gap ;
                capl.bini.dcadj      = False;
            }

            break ;
    }

    Write_VALIDATEError(out, Validate_CAPLETS(&capl));

    return capl ;
}


/*
..
*/

CAPTION Read_CAPTION(FILE*  in, FILE*  out)
{
    COUNT type;
    CAPTION capt;

    fprintf(out,"   CAPTION:\n") ;

    type = Read_FormatId(in, out);

    switch (type)
    {
    case 1:
        /* Read Caption Data */
        capt.type   = Read_OPTTYPE(in, out, "Option type  ");
        capt.berm = False;
        capt.dpay.first  = Read_DATESTR(in, out, "First strike ");
        capt.dpay.last   = Read_DATESTR(in, out, "Last strike  ");
        capt.dpay = Set_PAYDAYDEF(True, &capt.dpay.first, NULL, 
                                 &capt.dpay.last, False, NULL, 0, NULL) ;
        capt.strike = Read_FL64(in, out, "Option strike ");
        /* Read Cap Data */
        capt.step_strike = NULL;
        capt.cap = Read_CAP(in, out);

        break;

    case 2:
        capt.type   = Read_OPTTYPE(in, out, "Option type  ");
        capt.berm = Read_BOOLE(in, out, "Bermudan style ") ;
        capt.dpay = Read_PAYDAYDEF(in, out);
        capt.strike = Read_FL64(in, out, "Option strike ");
        capt.step_strike = Read_PLANARRAY(in);
        Write_PLANARRAY(out, capt.step_strike);
        capt.cap = Read_CAP(in, out);
        
        break;
    }

    Write_VALIDATEError(out, Validate_CAPTION(&capt));

    return capt;
}


/*
..
*/

SWAPTION Read_SWAPTION(FILE* in, FILE* out)
{
    SWAPTION ncsw ;
    YYYYMMDD ymd1, ymd3, ymd ;
    FL64     fac, swaprate, spr, dur ;
    BOOLE    swapstl, vanl ;
    TERMUNIT unit ;
    PMTFREQ  ifreq, freq, flfreq ;
    DATESTR  dzero, maturity, start, end, effective ;
    OPTTYPE  otype ;
    CALCONV  cal, LIBORcal ;
    EOMCONV  eom ;
    char     txk[20], txb[20], txc[20], txd[20], txe[20] ;
    RATECONV rt ;
    COUNT    type;
    FIXRATE  fix ;
    PAYDAYDEF pfix ;
    PERIOD    delay, Oterm, Sterm ;

    fprintf(out,"   SWAPTION:\n") ;
    dzero = Cldr_YMD2Datestr((YYYYMMDD) 0) ;
    type = Read_FormatId(in, out);
    ncsw.oadd = NO_OPTADD ;

    switch (type)
    {
        case 1:

            fscanf(in, "%ld %lf %ld %s", &ymd1, &swaprate, &ymd3, txk) ;

            start  = Cldr_YMD2Datestr(ymd1) ;
            end    = Cldr_YMD2Datestr(ymd3) ;
            freq   = Str2PMTFREQ(txk) ;
            fprintf(out,"   swaprate       %8lf\n", swaprate) ;
            fprintf(out,"   First          %8ld\n", ymd1) ;
            fprintf(out,"   Last           %8ld\n", ymd3) ;
            fprintf(out,"   freq           %8s\n", txk) ;

            fscanf(in, "%s %lf %s %lf %s %s %lf",
                   txe, &spr, txb, &dur, txc, txd, &fac) ;

            fprintf(out,"   Vanilla        %8s\n", txe) ;
            fprintf(out,"   Spread         %8lf\n", spr) ;
            fprintf(out,"   Fl.Freq        %8s\n", txb) ;
            fprintf(out,"   Index Dur      %8lf\n", dur) ;
            fprintf(out,"   Index Unit     %8s\n", txc) ;
            fprintf(out,"   Index Freq     %8s\n", txd) ;
            fprintf(out,"   Factor         %8lf\n", fac) ;

            vanl   = Str2BOOLE(txe) ;
            flfreq = Str2PMTFREQ(txb) ;
            unit   = Str2TERMUNIT(txc) ;
            ifreq  = Str2PMTFREQ(txd) ;

            fscanf(in, "%s %ld %s", txd, &ymd, txb) ;

            otype    = Str2OPTTYPE(txd) ;
            maturity = Cldr_YMD2Datestr((YYYYMMDD) ymd) ;
            swapstl  = Str2BOOLE(txb) ;

            fprintf(out,"   Type           %8s\n", txd) ;
            fprintf(out,"   maturity       %8ld\n", ymd) ;
            fprintf(out,"   SwapSettle     %8s\n", txb) ;

            fscanf(in, "%s %s", txb, txe) ;

            cal  = Str2CALCONV(txb) ;
            eom  = Str2EOMCONV(txe) ;

            fprintf(out,"   calendar       %8s\n", txb) ;
            fprintf(out,"   eom            %8s\n", txe) ;

            ncsw.pfix = cflw_set_payday(&start, &dzero, &end, False,
                                        Cflw_MonthsBetweenPayments(freq),
                                        MONTHS, NOODD, NOODD, ANCHOR, eom) ;
            ncsw.fix  = Set_FIXRATE(swaprate, cal, &start, &end, 0.0,
                                    ODDCOUP, ODDCOUP, False, False, 
                                    NULL, True, NULL, NODCOMP) ;
            ncsw.pfl  = cflw_set_payday(&start, &dzero, &end, False,
                                        Cflw_MonthsBetweenPayments(flfreq),
                                        MONTHS, NOODD, NOODD, ANCHOR, eom) ;
            ncsw.fbase.cal       = cal ;
            ncsw.fbase.effective = start ;
            ncsw.fbase.is_fix    = False ;
            ncsw.fbase.spread    = spr ;

            rt = (ifreq == NO_FREQUENCY ? MMRATE : PARYIELD) ;
            LIBORcal = (ifreq == NO_FREQUENCY ? cal : EU30E360) ;
            ncsw.index = Set_RATEINDEX(rt, dur, unit, ifreq, LIBORcal, 0.0) ;

            ncsw.vanilla  = vanl ;
            ncsw.type     = otype ;
            ncsw.maturity = maturity ;
            ncsw.cal      = cal ;
            ncsw.swapstl  = swapstl ;
            ncsw.factor   = fac ;
            ncsw.amort    = NULL ;

            break ;

        case 2:

            fscanf(in, "%ld %lf %ld %s", &ymd1, &swaprate, &ymd3, txk) ;

            start  = Cldr_YMD2Datestr(ymd1) ;
            end    = Cldr_YMD2Datestr(ymd3) ;
            freq   = Str2PMTFREQ(txk) ;
            fprintf(out,"   swaprate       %8lf\n", swaprate) ;
            fprintf(out,"   First          %8ld\n", ymd1) ;
            fprintf(out,"   Last           %8ld\n", ymd3) ;
            fprintf(out,"   freq           %8s\n", txk) ;

            fscanf(in, "%s %ld", txd, &ymd) ;

            otype    = Str2OPTTYPE(txd) ;
            maturity = Cldr_YMD2Datestr((YYYYMMDD) ymd) ;
            fprintf(out,"   Type           %8s\n", txd) ;
            fprintf(out,"   maturity       %8ld\n", ymd) ;

            fscanf(in, "%s %s", txb, txe) ;

            cal  = Str2CALCONV(txb) ;
            eom  = Str2EOMCONV(txe) ;

            fprintf(out,"   calendar       %8s\n", txb) ;
            fprintf(out,"   eom            %8s\n", txe) ;

            pfix = cflw_set_payday(&start, &dzero, &end, False,
                                   Cflw_MonthsBetweenPayments(freq),
                                   MONTHS, NOODD, NOODD, ANCHOR, eom) ;
            fix  = Set_FIXRATE(swaprate, cal, &start, NULL, 0.0,
                               ODDCOUP, ODDCOUP, False, False, 
                               NULL, True, NULL, NODCOMP) ;
            ncsw = Set_SWAPTION(otype, &maturity, cal, True, &fix, &pfix) ;

            break ;

        case 3:

            fscanf(in, "%ld %lf %ld %s %s", &ymd1, &swaprate, &ymd3, txk, txb);

            start  = Cldr_YMD2Datestr(ymd1) ;
            end    = Cldr_YMD2Datestr(ymd3) ;
            freq   = Str2PMTFREQ(txk) ;
            cal    = Str2CALCONV(txb) ;
            fprintf(out,"   swaprate       %8lf\n", swaprate) ;
            fprintf(out,"   First          %8ld\n", ymd1) ;
            fprintf(out,"   Last           %8ld\n", ymd3) ;
            fprintf(out,"   freq           %8s\n", txk) ;
            fprintf(out,"   calendar       %8s\n", txb) ;

            fscanf(in, "%s %ld", txd, &ymd) ;

            otype    = Str2OPTTYPE(txd) ;
            maturity = Cldr_YMD2Datestr((YYYYMMDD) ymd) ;
            fprintf(out,"   Type           %8s\n", txd) ;
            fprintf(out,"   maturity       %8ld\n", ymd) ;

            pfix = cflw_set_payday(&start, &dzero, &end, False,
                                   Cflw_MonthsBetweenPayments(freq),
                                   MONTHS, NOODD, NOODD, ANCHOR, LAST) ;
            fix  = Set_FIXRATE(swaprate, cal, &start, &end, 0.0,
                               ODDCOUP, ODDCOUP, False, False, 
                               NULL, True, NULL, NODCOMP) ;

            ncsw = Set_SWAPTION(otype, &maturity, cal, True, &fix, &pfix) ;

            break ;

        case 4:

            start  = Read_DATESTR(in, out, "   Today      ") ;
            otype  = Read_OPTTYPE(in, out, "   Type       ") ;
            Oterm  = Read_PERIOD(in) ;
            Write_PERIOD(out, "   Option:     ", &Oterm) ;
            Sterm  = Read_PERIOD(in) ;
            Write_PERIOD(out, "   Swap:       ", &Sterm) ;

            freq   = Read_PMTFREQ(in, out, "   Frequency   ") ;
            swaprate = Read_FL64(in, out, "   Rate       ") ;   
            cal    = Read_CALCONV(in, out, "   Cal        ") ;            
            eom    = Read_EOMCONV(in, out, "   Eom        ") ;
            ncsw   = Swaption_Simple2SWAPTION(&start, otype, &Oterm,NULL, 
                                              &Sterm, freq, swaprate, cal, eom);
            break ;

        case 5:

            start  = Read_DATESTR(in, out, "   Today      ") ;
            otype  = Read_OPTTYPE(in, out, "   Type       ") ;
            Oterm  = Read_PERIOD(in) ;
            Write_PERIOD(out, "   Option:     ", &Oterm) ;
            delay   = Read_PERIOD(in) ;
            Write_PERIOD(out, "   Delay:      ", &delay) ;
            Sterm  = Read_PERIOD(in) ;
            Write_PERIOD(out, "   Swap:       ", &Sterm) ;

            freq   = Read_PMTFREQ(in, out, "   Frequency   ") ;
            swaprate = Read_FL64(in, out, "   Rate       ") ;   
            cal    = Read_CALCONV(in, out, "   Cal        ") ;            
            eom    = Read_EOMCONV(in, out, "   Eom        ") ;
            ncsw   = Swaption_Simple2SWAPTION(&start, otype, &Oterm, &delay, 
                                              &Sterm, freq, swaprate, cal, eom);
            ncsw.vanilla = False ;
            ncsw.fbase = Read_FLOATBASE(in, out) ;
            ncsw.index = Read_RATEINDEX(in, out) ;
            ncsw.factor = Read_FL64(in, out, "   Factor     ") ;   
            ncsw.pfl = Read_PAYDAYDEF(in, out) ;
            ncsw.amort = Read_PLANARRAY(in) ;
            Write_PLANARRAY(out, ncsw.amort) ;

            break ;

        case 6:

            start  = Read_DATESTR(in, out, "   Today      ") ;
            otype  = Read_OPTTYPE(in, out, "   Type       ") ;
            Oterm  = Read_PERIOD(in) ;
            Write_PERIOD(out, "   Option:     ", &Oterm) ;
            delay   = Read_PERIOD(in) ;
            Write_PERIOD(out, "   Delay:      ", &delay) ;
            Sterm  = Read_PERIOD(in) ;
            Write_PERIOD(out, "   Swap:       ", &Sterm) ;

            freq   = Read_PMTFREQ(in, out, "   Frequency   ") ;
            swaprate = Read_FL64(in, out, "   Rate       ") ;   
            cal    = Read_CALCONV(in, out, "   Cal        ") ;            
            eom    = Read_EOMCONV(in, out, "   Eom        ") ;
            ncsw   = Swaption_Simple2SWAPTION(&start, otype, &Oterm, &delay, 
                                              &Sterm, freq, swaprate, cal, eom);
            ncsw.vanilla = False ;
            ncsw.fbase = Read_FLOATBASE(in, out) ;
            ncsw.index = Read_RATEINDEX(in, out) ;
            ncsw.factor = Read_FL64(in, out, "   Factor     ") ;   
            ncsw.pfl = Read_PAYDAYDEF(in, out) ;
            ncsw.amort = Read_PLANARRAY(in) ;
            Write_PLANARRAY(out, ncsw.amort) ;

            ncsw.oadd = Read_OPTADD(in, out, "   OptAdd     ") ;
            switch (ncsw.oadd)
            {
                case NO_OPTADD:
                    break ;

                case BINARY :
                    ncsw.bini.poff.poff = 
                        Read_PAYOFF(in, out, "   Factor     ");
                    ncsw.bini.poff.gap = 
                        Read_FL64(in, out, "   Gap        ") ;
                    ncsw.bini.poff.scale = 
                        Read_FL64(in, out, "   Scale      ") ;
                    /* Day-count period adjusting only makes sense for caps: */
                    ncsw.bini.dcadj = False ;
                    break ;

                case CONTPREM:
                    ncsw.ctp.prem = Read_FL64(in, out, "   ContPrem   ") ;
                    break ;

                case COMPOPT:
                    ncsw.compo.type = Read_OPTTYPE(in, out, "   OptType    ");
                    ncsw.compo.matur = Read_DATESTR(in, out, "   CompDate   ");
                    ncsw.compo.strike = Read_FL64(in, out, "   Strike     ");
                    break ;

                case FWDSTART:
                    ncsw.fwdst.dset = Read_DATESTR(in, out, "   FwdDate    ");
                    ncsw.fwdst.alpha = Read_FL64(in, out, "   Factor     ");
                    break ;

                case CHOOSER:
                    ncsw.chos.dchoose = Read_DATESTR(in, out, "   ChooseAt  ");
                    break ;

                default:
                    ;
            }

            break ;

        case 7:

            start  = Read_DATESTR(in, out, "   Today      ") ;
            otype  = Read_OPTTYPE(in, out, "   Type       ") ;
            Oterm  = Read_PERIOD(in) ;
            Write_PERIOD(out, "   Option:     ", &Oterm) ;
            Sterm  = Read_PERIOD(in) ;
            Write_PERIOD(out, "   Swap:       ", &Sterm) ;

            freq   = Read_PMTFREQ(in, out, "   Frequency   ") ;
            swaprate = Read_FL64(in, out, "   Rate       ") ;   
            cal    = Read_CALCONV(in, out, "   Cal        ") ;            
            eom    = Read_EOMCONV(in, out, "   Eom        ") ;
            ncsw   = Swaption_Simple2SWAPTION(&start, otype, &Oterm,NULL, 
                                              &Sterm, freq, swaprate, cal, eom);
            ncsw.vanilla = True ;
            ncsw.oadd = SWPTBARR ;
            ncsw.sbarr.tenor = Read_PERIOD(in) ;
            ncsw.sbarr.freq  = Read_PMTFREQ(in, out, "  Freq    ") ;
            ncsw.sbarr.cal   = Read_CALCONV(in, out, "   Calconv  ") ;
            ncsw.sbarr.rate  = Read_FL64(in, out, "  Rate    ") ;
            ncsw.sbarr.first = Read_DATESTR(in, out, "  FirstBarr  ") ;
            ncsw.sbarr.last  = Read_DATESTR(in, out, "  Last Barr  ") ;
            ncsw.sbarr.per_barr = Read_PERIOD(in) ;
            ncsw.sbarr.type     = Read_KNOCKTYPE(in, out, "  KnockType  ") ;
            break ;

        case 8:

            start = Read_DATESTR(in, out, "  First   ");
            swaprate = Read_FL64(in, out, "  Rate   ");
            end = Read_DATESTR(in, out, "  Last   ");
            effective = Read_DATESTR(in, out, "  Effective   ");
            freq = Read_PMTFREQ(in, out, "   Frequency   ");

            otype = Read_OPTTYPE(in, out, "   Option   ");
            maturity = Read_DATESTR(in, out, "  Exercise   ");

            cal = Read_CALCONV(in, out, "   Cal   ");
            eom = Read_EOMCONV(in, out, "   Eom   ");

            pfix = cflw_set_payday(&start, &dzero, &end, False,
                                   Cflw_MonthsBetweenPayments(freq),
                                   MONTHS, NOODD, NOODD, ANCHOR, eom) ;
            fix  = Set_FIXRATE(swaprate, cal, &effective, NULL, 0.0,
                               ODDCOUP, ODDCOUP, False, False, 
                               NULL, True, NULL, NODCOMP) ;
            ncsw = Set_SWAPTION(otype, &maturity, cal, True, &fix, &pfix) ;

            break ;
    }

    Write_VALIDATEError(out, Validate_SWAPTION(&ncsw));

    return ncsw ;
}


SWPTVOL Read_SWPTVOL(FILE* in)
{
    INTI    i, j ;
    int     i1, i2, i3 ;
    char    txb[20], txc[20] ;
    SWPTVOL swvol ;

    fscanf(in,"%d %d %lf %s %s", &i1, &i2, &swvol.skew, txb, txc) ;

    swvol.opt_mnth = Alloc_INTIARRAY((INTI) i1) ;
    swvol.swp_mnth = Alloc_INTIARRAY((INTI) i2) ;
    swvol.vol      = Alloc_FL64MATRIX((INTI) i1, (INTI) i2) ;
    swvol.no    = (INTI) i1 ;
    swvol.ns    = (INTI) i2 ;
    swvol.cal   = Str2CALCONV(txc) ;
    swvol.iconv = Str2INTPOLCONV(txb) ;

    for (i = 0 ; i < (INTI) i1 ; i++)
    {
        fscanf(in, "%d", &i3) ;
        swvol.opt_mnth[i] = (INTI) i3 ;
    }

    for (j = 0 ; j < (INTI) i2 ; j++)
    {
        fscanf(in, "%d", &i3) ;
        swvol.swp_mnth[j] = (INTI) i3 ;

        for (i = 0 ; i < (INTI) i1 ; i++)
            fscanf(in, "%lf", &swvol.vol[i][j]) ;
    }

    return swvol ;
}

/*
..
*/

CONVTBL Read_CONVTBL(FILE* in, FILE* out, DATESTR* settle)
{
  CONVTBL   xt ;
  COUNT     type;

  fprintf(out,"   CONVERTIBLE BOND:\n") ;

  type = Read_FormatId(in, out);

  switch (type)
  {
    case 1:

      xt.first       = Read_DATESTR(in, out, "First       ") ;
      xt.last        = Read_DATESTR(in, out, "Last        ") ;
      xt.conv_price  = Read_FL64(in, out, "Conv price  ") ;
      xt.accr_incl   = Read_BOOLE(in, out, "Accr incl   ") ;
      xt.call_hurdle = Read_FL64(in, out, "Call hurdle ") ;
      xt.hurdle_date = Read_DATESTR(in, out, "Hurdle date ") ;
      xt.call_date   = Read_DATESTR(in, out, "Call date   ") ;
      xt.call_price  = Read_FL64(in, out, "Call price  ") ;
      xt.call_plan   = Read_PLANARRAY(in) ;
      fprintf(out,"   Call plan:\n") ;
      Write_PLANARRAY(out, xt.call_plan) ;
      xt.fixp        = Read_FIXPAY(in, out, settle) ;
      xt.div         = Read_PLANARRAY(in) ;
/*..to be added later..
      xt.put_plan   = NULL ;
      xt.mat_conv    = False ;
*/
      fprintf(out,"   Div:\n") ;
      Write_PLANARRAY(out, xt.div) ;
      break ;

    case 2:

      xt.first       = Read_DATESTR(in, out, "First       ") ;
      xt.last        = Read_DATESTR(in, out, "Last        ") ;
      xt.conv_price  = Read_FL64(in, out, "Conv price  ") ;
      xt.accr_incl   = Read_BOOLE(in, out, "Accr incl   ") ;
      xt.call_hurdle = Read_FL64(in, out, "Call hurdle ") ;
      xt.hurdle_date = Read_DATESTR(in, out, "Hurdle date ") ;
      xt.call_date   = Read_DATESTR(in, out, "Call date   ") ;
      xt.call_price  = Read_FL64(in, out, "Call price  ") ;
      xt.call_plan   = Read_PLANARRAY(in) ;
      fprintf(out,"   Call plan:\n") ;
      Write_PLANARRAY(out, xt.call_plan) ;
      xt.fixp        = Read_FIXPAY(in, out, settle) ;
      xt.div         = Read_PLANARRAY(in) ;
      fprintf(out,"   Div:\n") ;
      Write_PLANARRAY(out, xt.div) ;
/*..to be added later..
      xt.put_plan   = Read_PLANARRAY(in) ;
      fprintf(out,"   Put price:\n") ;
      Write_PLANARRAY(out, xt.put_plan) ;
      xt.mat_conv    = Read_BOOLE(in, out, "Maturity conversion? ") ;
*/
      break ;
  }

  Write_VALIDATEError(out, Validate_CONVTBL(&xt));

  return xt ;
}

/*
..
*/



SWAPCALL Read_SWAPCALL(FILE*  in, FILE*  out)
{
  SWAPCALL cswap;
  FL64     swap_rate;
  DATESTR  start;
  PERIOD   first_call, last_call, matur;
  PMTFREQ  freq;
  BOOLE pay_fix; 
  BOOLE extend;
  BOOLE berm;
  CALCONV cal;
  EOMCONV eom;
  COUNT type;

  /* warning avoidance */
  memset(&cswap, 0, sizeof(cswap));

  fprintf(out,"   Callable swap:\n") ;

  type = Read_FormatId(in, out);

  switch (type)
  {
    case 1: /* European callable swap */
      pay_fix   = Read_BOOLE(in, out, "Pay Fixed  ");
      extend    = Read_BOOLE(in, out, "Extendible ");
      start     = Read_DATESTR(in, out, "Swap Start");
      last_call = Read_PERIOD(in);
      Write_PERIOD(out, "Call", &last_call);
      matur     = Read_PERIOD(in);
      Write_PERIOD(out, "Swap Maturity", &matur);
      swap_rate = Read_FL64(in, out, "Swap rate");
      freq      = Read_PMTFREQ(in, out, "Payment freq");
      cal       = Read_CALCONV(in, out, "Day-count");
      eom       = Read_EOMCONV(in, out, "End-of-month");

      cswap = SwapCall_Simple2SWAPCALL(pay_fix, extend, False, swap_rate, 
          &start, NULL, &last_call, &matur, cal, eom, freq);
      break;

    case 2: /* Bermudan callable swap */
      pay_fix   = Read_BOOLE(in, out, "Pay Fixed  ");
      extend    = Read_BOOLE(in, out, "Extendible ");
      berm      = Read_BOOLE(in, out, "Bermudan ");
      start     = Read_DATESTR(in, out, "Swap Start");
      first_call = Read_PERIOD(in);
      Write_PERIOD(out, "First Call", &first_call);
      last_call = Read_PERIOD(in);
      Write_PERIOD(out, "Last Call", &last_call);
      matur     = Read_PERIOD(in);
      Write_PERIOD(out, "Swap Maturity", &matur);
      swap_rate = Read_FL64(in, out, "Swap rate");
      freq      = Read_PMTFREQ(in, out, "Payment freq");
      cal       = Read_CALCONV(in, out, "Day-count");
      eom       = Read_EOMCONV(in, out, "End-of-month");

      cswap = SwapCall_Simple2SWAPCALL(pay_fix, extend, berm, swap_rate, 
          &start, &first_call, &last_call, &matur, cal, eom, freq);
      break;

    default:
      ;
  }
  return cswap;
}


FLEXICAPINF Read_FLEXICAPINF(FILE* in, FILE* out)
{
    FLEXICAPINF fcap;

    /* Read data */
    fprintf(out,"   FLEXICAPINF Data ...\n") ;

    fcap.autoflex = Read_BOOLE(in, out, "Auto-exercise");
    fcap.n_caplets = Read_INTI(in, out, "#caplets");

    return fcap;
}



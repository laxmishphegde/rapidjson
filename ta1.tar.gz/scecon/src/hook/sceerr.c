/* @(#)sceerr.c	1.12 (SimCorp) 99/10/28 11:43:29 */

/**********************************************************************
*                                                                      
*       Module          Hook                                           
*                                                                      
*       general         Standard hooks to error handling and reporting 
*                       for the SCecon Library.                        
*                                                                      
*                       This code is an example of user specifications 
*                       and is distributed in source.                  
*                                                                      
***********************************************************************
*/

#include <scechook.h>
#include <stdlib.h>
#include <stdio.h>
#include <float.h>

#include <stdarg.h>

/*,,SOH,,
***********************************************************************
*                                                                      
*               SCecon_error()                                         
*                                                                      
*    interface  #include <scechook.h>                                  
*               void SCecon_error(TEXT message,                        
*                                 TEXT routine,                        
*                                 INTI action) ;                       
*                                                                      
*    general    This function is the general error handler of the      
*               SCecon Library.                                        
*               If your application wants certain actions to be taken  
*               before returning from error situations you should      
*               modify this function according to your needs.          
*                                                                      
*    input      TEXT    message     Message to be written.             
*                                                                      
*               TEXT    routine     Name of calling routine.           
*                                                                      
*               INTI    action      Specification of how to react      
*                                   in an error situation.             
*                                   Eligible values  are               
*                                                                      
*                                       SCECONCONTINUE                 
*                                       SCECONABORT                    
*                                                                      
*    output                                                            
*                                                                      
*    returns                                                           
*                                                                      
*    diagnostics In the default set-up provided by SimCorp, if action  
*                is SCECONABORT, the routine calls SCecon_printf() with
*                a warning and exits.                                  
*                                                                      
*                If action is specified as SCECONCONTINUE the routine  
*                continues after the call to SCecon_printf().          
*                                                                      
*                If action is neither SCECONABORT or SCECONCONTINUE,   
*                the routine exits after calling SCecon_printf() with  
*                the message "Unknown action code...".                 
*                                                                      
*                However, you would probably like to change these      
*                settings.                                             
*                                                                      
*    see also                                                          
*                                                                      
***********************************************************************
,,EOH,,*/


void SCecon_error(TEXT message,
                  TEXT  routine,
                  INTI   action)
{

    /* Take appropriate action. If called with SCECONCONTINUE, it is */
    /* probably safe to simply return after issuing a warning.       */
    /* We use SCecon_printf() defined below as output routine.       */
    if (action == SCECONCONTINUE)
    {
        SCecon_printf(SCECONWARNING,
                     "%s\n occured in routine %s\n", message, routine);
        return ;
    }

    /* If called with SCECONABORT - or an unknown action code - we   */
    /* print out the message using SCecon_printf() and return.       */
    else
    {
        if (action == SCECONABORT)
        {
             SCecon_printf(SCECONERROR,
                     "%s\n occured in routine %s\n", message, routine);
             SCecon_printf(SCECONERROR, "Aborting\n") ;
             exit(1) ;
        }
        else
        {
             SCecon_printf(SCECONERROR,
                        "Unknown action code %d, aborting\n", action) ;
             exit(1) ;
        }
    }
}


/*,,SOH,,
***********************************************************************
*                                                                      
*               SCecon_printf()                                        
*                                                                      
*    interface  #include <scechook.h>
*               void SCecon_printf(INTI  code,                         
*                                  TEXT format,                        
*                                  ...) ;                              
*                                                                      
*    general    This function is the general error reporter of the     
*               SCecon Library.                                        
*               The routine simply prints out the message given in     
*               the ... input parameter.                               
*               This message is formatted according to format.         
*                                                                      
*               Check out the routine SCecon_error() above to see      
*               examples of calls to SCecon_printf().                  
*                                                                      
*               However, since the routine is distributed in source,   
*               you may change it according to your needs.             
*                                                                      
*    input      INTI  code        Message level. Eligible values are   
*                                                                      
*                                    SCECONERROR     Error message.    
*                                    SCECONWARNING   Warning.          
*                                                                      
*               TEXT  format      Format of message                    
*                                                                      
*               ...               Error message to be printed.         
*                                                                      
*    output                                                            
*                                                                      
*    returns                                                           
*                                                                      
*    diagnostics                                                       
*                                                                      
*    see also   SCecon_error()                                         
*                                                                      
***********************************************************************
,,EOH,,*/

void SCecon_printf(INTI  code,
                   TEXT format,
                   ...)
{
    va_list argptr ;

    /* This is an example of how you may set up a standard printf    */
    /* routine.                                                      */
    /* Anytime SCecon prints something, it is passed to this routine */
    /* Here, we simply emulate printf.                               */

    switch (code)
    {
        case SCECONERROR :
        case SCECONWARNING :
        case SCECONPROGRESS :
                va_start(argptr, format) ;
                vprintf(format, argptr) ;
                va_end(argptr) ;
            break ;
        default : break ;
    }
}



/*,,SOH,,
***********************************************************************
*                                                                      
*               SCecon_tryinterrupt()                                  
*                                                                      
*    interface  #include <scechook.h>
*               BOOLE SCecon_tryinterrupt(INTI  code,                   
*                                  TEXT routine,                      
*                                  TEXT format,                        
*                                  ...) ;                              
*                                                                      
*    general    This function is the general interrupt checker of the   
*               SCecon Library.                                        
*               The routine simply checks if an abort interrupt has 
*               been issued in which case the message given in     
*               the ... input parameter printed asking for a 
*               confirmation.
*               This message is formatted according to format.         
*                                                                      
*               Check out the routine SCecon_error() above to see      
*               examples of calls to SCecon_printf().                  
*                                                                      
*               However, since the routine is distributed in source,   
*               you may change it according to your needs.             
*                                                                      
*               The default implementation of this function just prints
*               the message and of course no interrupt is checked for.
*
*               No message is printed in the present implementation
*               used in the SCecon test suite if SCECONMESSAGE is used.
*                                                                      
*    input      INTI  code        Message level. Eligible values are   
*                                                                      
*                                    SCECONERROR     Error message.    
*                                    SCECONWARNING   Warning.          
*                                    SCECONPROGRESS  Progress info
*                                    SCECONMESSAGE   Simple message    
*                                                                      
*               TEXT  routine     Name of calling routine.           
*                                                                      
*               TEXT  format      Format of message                    
*                                                                      
*               ...               Error message to be printed.         
*                                                                      
*    output                                                            
*                                                                      
*    returns    If an abort interrupt was issued by the calling 
*               application then True is returned. Otherwise False.
*                                                                      
*    diagnostics                                                       
*                                                                      
*    see also   SCecon_error()                                         
*               SCecon_printf()                                         
*                                                                      
***********************************************************************
,,EOH,,*/

BOOLE SCecon_tryinterrupt(INTI  code,
                   TEXT routine,
                   TEXT format,
                   ...)
{
  va_list argptr ;
  BOOLE   abort;

  /* Warning avoidance */
  code = code;
  routine = routine;

  /* This is an example of how you may set up the routine.         */
  /* Anytime SCecon tries and interrupt something, this routine is */
  /* used.                                                         */

  abort = False;

  switch (code)
  {
  case SCECONERROR :
  case SCECONWARNING :
  case SCECONPROGRESS :
   /* Here, we simply emulate printf. */
    va_start(argptr, format) ;
    vprintf(format, argptr) ;
    va_end(argptr) ;
    break ;

  case SCECONMESSAGE:
  default: 
    /* Here we just forget the message */
    break ;
  }

  return abort;
}



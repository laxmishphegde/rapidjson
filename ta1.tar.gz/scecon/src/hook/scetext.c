/* @(#)scetext.c	1.2 (SimCorp) 99/02/19 16:49:59 */

/**********************************************************************
*                                                                      
*       Module          Hook                                           
*                                                                      
*       general         Standard hooks to string/memory handling 
*                       for the SCecon Library.                        
*                                                                      
*                       This code is an example of user specifications 
*                       and is distributed in source.                  
*                                                                      
***********************************************************************
*/

#include <scechook.h>
#include <stdlib.h>
#include <stdio.h>
#include <float.h>

/* 
************************************************************************
String utilities taken from cstring.hxx of Ascend 1.64 
************************************************************************
*/

SCCONST char *SCecon_nullcheck(SCCONST char * s)
{
  return (s) ? s : (SCCONST char *)"";
}


size_t SCecon_strlen(SCCONST char * s)
{ 
  return (s) ? strlen(s) : (size_t)0;
}


char *SCecon_strcpy(char* t, SCCONST char * s)
{ 
  if(s) strcpy(t, s); else *t=0;
  return t;
}


char *SCecon_strncpy(char * t, SCCONST char * s, size_t n)
{ 
    /* Remember that strncpy does *not* assure a  */
    /* terminating zero!                          */
  if(n>0) 
    strncpy(t, SCecon_nullcheck(s), n);
  return t;
}


char *SCecon_strncpyz(char * t, SCCONST char * s, size_t n)
{ 
    /* This is a version of strncpy that does assure zero */
    /* termination if n>0.                                */
  if(n>0)
  {
    strncpy(t, SCecon_nullcheck(s), n);
    t[n-1]=0;
  }
  return t;
}


char *SCecon_strcat(char * t, SCCONST char * s)
{ 
  if(s)
    strcat(t, s);
  return t;
}


char *SCecon_strncat(char * t, SCCONST char * s, size_t n)
{ 
  return strncat(t, SCecon_nullcheck(s), n);
}


const char *SCecon_strchr(SCCONST char * s, int c)
{ 
  if(s)
    return strchr(s, c);
  else
    return NULL;
}


const char *SCecon_strrchr(SCCONST char * s, int c)
{ 
  if(s) 
    return strrchr(s, c);
  else
    return NULL;
}


size_t SCecon_strspn(SCCONST char * s1, SCCONST char * s2)
{ 
  return strspn(SCecon_nullcheck(s1), SCecon_nullcheck(s2));
}


size_t SCecon_strcspn(SCCONST char * s1, SCCONST char * s2)
{ 
  return strcspn(SCecon_nullcheck(s1), SCecon_nullcheck(s2));
}


const char *SCecon_strpbrk(SCCONST char * s1, SCCONST char * s2)
{ 
  return strpbrk(SCecon_nullcheck(s1), SCecon_nullcheck(s2));
}


int SCecon_strcmp(SCCONST char * s1, SCCONST char * s2)
{ 
  return strcmp(SCecon_nullcheck(s1), SCecon_nullcheck(s2));
}


/* Not included in cstring.hxx */
int SCecon_strncmp(SCCONST char * s1, SCCONST char * s2, size_t l)
{ 
  return strncmp(SCecon_nullcheck(s1), SCecon_nullcheck(s2), l);
}


  /* mem-functions working on void *. The length is */
  /* always given explicitly. If the length is 0 no */
  /* action is performed.                           */

const void *SCecon_memchr(SCCONST void * s, int c, size_t l)
{ 
  if(l) 
    return memchr(s, c, l);
  else
    return NULL;
}


void *SCecon_memset(void * t, int c, size_t l)
{ 
  if(l) 
    memset(t, c, l);
  return t;
}


void *SCecon_memcpy(void * t, SCCONST void * s, size_t l)
{ 
  if(l) 
    memcpy(t, s, l);
  return t;
}


void *SCecon_memmove(void * t, SCCONST void * s, size_t l)
{ 
    /* memmove supports overlapping memory areas. If     */
    /* t==s there is no reason to move anything. I dont  */
    /* know if memmove itself checks for this condition. */
  if(l && t != s) 
    memmove(t, s, l);
  return t;
}


int SCecon_memcmp(SCCONST void * s1, SCCONST void * s2, size_t l)
{
  if(l) 
    return memcmp(s1, s2, l);
  else
    return 0;
}


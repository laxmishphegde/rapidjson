/* @(#)scefile.c	1.4 (SimCorp) 99/02/19 16:49:57 */

/**********************************************************************
*                                                                      
*       Module          Hook                                          
*                                                                      
*       general         Standard hooks to error file handling
*                       for the SCecon Library.                        
*                                                                      
*                       This code is an example of user specifications 
*                       and is distributed in source.                  
*                                                                      
***********************************************************************
*/

#include <scechook.h>
#include <stdlib.h>
#include <stdio.h>
#include <float.h>


/*    Utilities for file access     */

/*,,SOH,,
***********************************************************************
*                                                                      
*               SCecon_fopen()                                         
*                                                                      
*    interface  #include <scechook.h>                                  
*               FILE *  SCecon_fopen(FILENAME   name,                  
*                                    TEXT       mode,                  
*                                    BOOLE      doerr)                 
*                                                                      
*    general    This function is the SCEcon cover routine for file     
*               opening.                                               
*                                                                      
*    input      FILENAME    name    path and name of file to open      
*                                                                      
*               TEXT        mode    opening mode (identical to that of 
*                                   the C library function 'fopen()).  
*                                                                      
*               BOOLE       doerr   toggle determining error handling  
*                                   (see below)                        
*                                                                      
*    output                                                            
*                                                                      
*    returns    pointer to file 'name' if successfully opened.         
*               If an error occurred: if 'doerr' is 'True' the function
*               SCecon_error() will be invoked; if 'doerr' is 'False'  
*               a null pointer is returned.                            
*                                                                      
*    diagnostics                                                       
*                                                                      
*    see also   SCecon_fclose()                                        
*                                                                      
***********************************************************************
,,EOH,,*/


FILE *  SCecon_fopen(FILENAME name, TEXT mode, BOOLE doerr)
{
    FILE    *fptr ;

/*..#ifdef APL...
APL file handling? */

    fptr = fopen(name, mode) ;

    if (!fptr && doerr)
        SCecon_error("file open fail", "SCecon_fopen()", SCECONABORT) ;

    return fptr ;
}


/*,,SOH,,
***********************************************************************
*                                                                      
*               SCecon_fclose()                                        
*                                                                      
*    interface  #include <scechook.h>                                  
*               INTI    SCecon_fclose(FILE *fptr, BOOLE doerr)         
*                                                                      
*    general    This function is the SCEcon cover routine for file     
*               closing.                                               
*                                                                      
*    input      FILE        *fptr   pointer to file to close           
*                                                                      
*               BOOLE       doerr   toggle determining error handling  
*                                   (see below)                        
*                                                                      
*    output                                                            
*                                                                      
*    returns    zero if file successfully closed.                      
*               If an error occurred: if 'doerr' is 'True' the function
*               SCecon_error() will be invoked; if 'doerr' is 'False'  
*               EOF is returned.                                       
*                                                                      
*    diagnostics                                                       
*                                                                      
*    see also   SCecon_fopen()                                         
*                                                                      
***********************************************************************
,,EOH,,*/

INTI    SCecon_fclose(FILE* fptr, BOOLE doerr)
{
    INTI    out ;

/*..#ifdef APL...
APL file handling? */

    out = fclose(fptr) ;

    if (out == EOF && doerr)
        SCecon_error("file close fail", "SCecon_fclose()", SCECONABORT);

    return out ;
}


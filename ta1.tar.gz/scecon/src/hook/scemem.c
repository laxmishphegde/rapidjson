/* @(#)scemem.c	1.9 (SimCorp) 99/10/28 10:29:59 */

/*********************************************************************
*                                                                     
*       Module          Hook                                          
*                                                                     
*       general         Standard hooks to memory handling
*                       for the SCecon Library.                       
*                                                                     
*                       This code is an example of user specifications
*                       and is distributed in source.                 
*                                                                     
**********************************************************************
*/

#include <scechook.h>
#include <stdlib.h>
#include <stdio.h>
#include <float.h>


/*,,SOH,,
***********************************************************************
*                                                                      
*               SCecon_calloc()                                        
*                                                                      
*    interface  #include <scechook.h>
*               VOIDPTR SCecon_calloc(INTI      nh,                    
*                                    size_t     sizof,                 
*                                    BOOLE      doerr,
*                                    TEXT       fname)                 
*                                                                      
*    general    This function is the SCEcon cover routine for          
*               memory allocation.                                     
*                                                                      
*    input      INTI        nh      The number of memory blocks to     
*                                   be allocated. Each block has size  
*                                   sizof. Must be non-negative
*                                                                      
*               size_t      sizof   The size of each memory block.     
*                                                                      
*               BOOLE       doerr   toggle determining error handling  
*                                   (see below)
*
*               TEXT        fname   Name of the calling function. Only
*                                   used if doerr is True.   
*                                                                      
*    output                                                            
*                                                                      
*    returns    A pointer to the allocated memory blocks if successfully
*               allocated.
*               If an error occurred: if 'doerr' is 'True' the function
*               SCecon_error() will be invoked; if 'doerr' is 'False'  
*               a null pointer is returned.                            
*                                                                      
*    diagnostics                                               
*               Returns NULL if nh is zero or negative.
*                                                                      
*    see also   SCecon_free()                                          
*                                                                      
***********************************************************************
,,EOH,,*/

VOIDPTR SCecon_calloc(INTI nh, size_t sizof, BOOLE doerr, TEXT fname)
{
  VOIDPTR v ;

  if (nh < 1)
    v = NULL;
  else
  {
    v = calloc((unsigned) nh, sizof) ;
    if (!v && doerr == True)
      SCecon_error("Allocation failed", fname, 
                   SCECONABORT) ;
  }

  return v ;
}


/*,,SOH,,
***********************************************************************
*                                                                      
*               SCecon_free()                                          
*                                                                      
*    interface  #include <scechook.h>
*               void SCecon_free(VOIDPTR   v)                          
*                                                                      
*    general    This function is the SCEcon cover routine for          
*               memory de-allocation.                                  
*                                                                      
*    input      VOIDPTR     v       Pointer to the memory block        
*                                   to be deallocated. The memory      
*                                   must be allocated by SCecon_calloc 
*                                   prior to calling this function.    
*                                                                      
*    output                                                            
*                                                                      
*    returns                                                           
*                                                                      
*    diagnostics                                                       
*               The memory referenced by v is de-allocated,            
*               and v is afterwards undefined.                         
*                                                                      
*    see also   SCecon_calloc()                                        
*                                                                      
***********************************************************************
,,EOH,,*/

void SCecon_free(VOIDPTR v)

{
    if (v)
#ifdef APLII_386
        AplFree((char*) v) ;
#else
        free((char*) v) ;
#endif
}



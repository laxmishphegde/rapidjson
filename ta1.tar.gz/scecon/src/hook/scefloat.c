/* @(#)scefloat.c	1.4 (SimCorp) 99/02/19 16:49:57 */

/*********************************************************************
*                                                                     
*       Module          Hook                                          
*                                                                     
*       general         Standard hooks to special operations on floats
*                       for the SCecon Library.                       
*                                                                     
*                       This code is an example of user specifications
*                       and is distributed in source.                 
*                                                                     
**********************************************************************
*/

#include <scechook.h>
#include <stdlib.h>
#include <stdio.h>
#include <float.h>


/*,,SOH,,
***********************************************************************
*                                                                      
*               SCecon_fabs()                                          
*                                                                      
*    interface  #include <scechook.h>                                  
*               FL64 SCecon_fabs(FL64 x) ;                             
*                                                                      
*    general    This function is the SCEcon cover routine for the      
*               library routine fabs()                                 
*                                                                      
*    input      FL64        x       Floating number to be fabs'ed.     
*                                                                      
*    output                                                            
*                                                                      
*    returns    The fabs'ed number                                     
*                                                                      
*    diagnostics                                                       
*                                                                      
*    see also                                                          
*                                                                      
***********************************************************************
,,EOH,,*/

FL64 SCecon_fabs (FL64 x)

{
    return (x > 0.0 ? x : -x ) ;
}


/*,,SOH,,
***********************************************************************
*                                                                  
*               SCecon_floor()                                     
*                                                                  
*    interface  #include <scechook.h>                                
*               FL64 SCecon_floor(FL64 x) ;                        
*                                                                  
*    general    This function is the SCEcon cover routine for the      
*               library routine floor(). SCecon_floor() differs
*               slightly in that negative values are handled
*               differently; The returned value matches 
*                 (x > 0.0 ? floor(x) : -floor(-x) )
*               The numbers are floor'ed towards zero.
*                                                                  
*    input      FL64        x       Floating number to be floor'ed.
*                                                                  
*    output                                                        
*                                                                  
*    returns    The floor'ed number as an FL64
*                                                                  
*    diagnostics                                                   
*                                                                  
*    see also   SCecon_ceil()
*                                                                  
***********************************************************************
,,EOH,,*/

FL64 SCecon_floor (FL64 x)
{   
    return (x < 0.0 ? -floor(-x) : floor(x)) ;
}

/*,,SOH,,
***********************************************************************
*                                                                      
*               SCecon_floori()                                        
*                                                                      
*    interface  #include <scechook.h>                                  
*               INTI SCecon_floori(FL64 x) ;                           
*                                                                      
*    general    This function is equivalent to SCecon_floori()
*                                                                      
*    input      FL64        x       Floating number to be floor'ed.
*                                                                      
*    output                                                            
*                                                                      
*    returns    The floor'ed number as an INTI.
*                                                                      
*    diagnostics                                                       
*                                                                      
*    see also   SCecon_floor()
*                                                                      
***********************************************************************
,,EOH,,*/

INTI SCecon_floori (FL64 x)
{
    return (INTI) SCecon_floor(x);
}


/*,,SOH,,
***********************************************************************
*                                                                  
*               SCecon_ceil()                                     
*                                                                  
*    interface  #include <scechook.h>                                
*               FL64 SCecon_ceil(FL64 x) ;                        
*                                                                  
*    general    This function is the SCEcon cover routine for the      
*               library routine ceil(). SCecon_ceil() differs
*               slightly in that negative values are handled
*               differently; The returned value matches 
*                 (x > 0.0 ? ceil(x) : -ceil(-x) )
*               The numbers are ceil'ed away from zero.
*                                                                  
*    input      FL64        x       Floating number to be ceil'ed.
*                                                                  
*    output                                                        
*                                                                  
*    returns    The ceil'ed number as an FL64
*                                                                  
*    diagnostics                                                   
*                                                                  
*    see also   SCecon_ceili()
*                                                                  
***********************************************************************
,,EOH,,*/

FL64 SCecon_ceil (FL64 x)
{
    return (x < 0.0 ? -ceil(-x) : ceil(x));
}

/*,,SOH,,
***********************************************************************
*                                                                      
*               SCecon_ceili()                                        
*                                                                      
*    interface  #include <scechook.h>                                  
*               INTI SCecon_ceili(FL64 x) ;                            
*                                                                      
*    general    This function is equivalent to SCecon_ceil()
*                                                                      
*    input      FL64        x       Floating number to be ceil'ed.    
*                                                                      
*    output                                                            
*                                                                      
*    returns    The ceil'ed number as an INTI
*                                                                      
*    diagnostics                                                       
*                                                                      
*    see also   SCecon_ceil()
*                                                                      
***********************************************************************
,,EOH,,*/

INTI SCecon_ceili (FL64 x)
{
    return (INTI) SCecon_ceil(x);
}


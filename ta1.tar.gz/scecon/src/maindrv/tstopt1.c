/* SCID @(#)tstopt1.c	1.4 (SimCorp) 99/02/19 14:18:13 */

/************************************************************************
*
*   project     SCecon
*
*   this program tests the routines in the option module of SCecon.
*
************************************************************************/

/*** includes ***********************************************************/

#include <string.h>
#include <str2conv.h>
#include <option.h>
#include <stdlib.h>
#include <stdio.h>
#include <optio.h>

/*
..
*/


INTI opttest1(char* txa, FILE* in, FILE* out)
{
    char        txb[25], txpl[64] ;
    FL64        acc1, e, acc, fexp, fres ;
    FL64        delta, gamma, s, dp, ddp ;
    INTI        diff ;
    OPTTYPE     type ;

    acc  = 0.001 ;
    acc1 = 0.01 ;
    diff = -1 ;

    if (!strcmp(txa, "opt_intrinsic_value()"))
    {
        fscanf(in,"%lf %lf %lf %s %s", &fexp, &e, &s, txb, txpl);
        type = Str2OPTTYPE(txb) ;
        fres = opt_intrinsic_value(e, s, type) ;
        diff = (fabs(fres - fexp) > acc);

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   strike price %8.5lf\n", e) ;
        fprintf(out,"   market price %8.5lf\n", s) ;
        fprintf(out,"   option type %s\n", txb) ;
        fprintf(out,"   result is %8lf  expected is %8lf\n", fres, fexp) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }

    else if (!strcmp(txa, "opt_dollar_duration()"))
    {
        fscanf(in,"%lf %lf %lf %s", &fexp, &delta, &dp, txpl) ;
        fres = opt_dollar_duration(delta, dp) ;
        diff = (fabs(fres - fexp) > acc);

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   option delta            %8.5lf\n", delta) ;
        fprintf(out,"   dollar duration of bond %8.5lf\n", dp) ;
        fprintf(out,"   result is %8lf  expected is %8lf\n", fres, fexp) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }

    else if (!strcmp(txa, "opt_dollar_convexity()"))
    {
        fscanf(in,"%lf %lf %lf %lf %lf %s", &fexp, &delta, &dp, &gamma,
                                            &ddp, txpl) ;
        fres = opt_dollar_convexity(delta, dp, gamma, ddp) ;
        diff = (fabs(fres - fexp) > acc);

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   option delta             %8.5lf\n", delta) ;
        fprintf(out,"   option gamma             %8.5lf\n", gamma) ;
        fprintf(out,"   dollar duration  of bond %8.5lf\n", dp) ;
        fprintf(out,"   dollar convexity of bond %8.5lf\n", ddp) ;
        fprintf(out,"   result is %8lf  expected is %8lf\n", fres, fexp) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }

    return diff ;
}

/*
..
*/

/* PMSTA-22396 - SRIDHARA � 160502 */
int test_crr_premium(FILE* in, FILE* out,  HOLI_STR* hol)
{
    char        txc[25], txd[25], txe[25], txf[25], txg[25], txpl[64] ;
    FL64        e, acc, fexp, fres ;
    FL64        s0, fres1, fexp1, vol, fres2, fexp2 ;
    FL64        divyld ;
    INTI        nts, i, count, n, diff ;
    RISKCONV    risk ;
    KEYCONV     wrt ;
    OPTTYPE     type ;
    PLAN_STR    *div ;
    BINTREE     *crr ;
    YYYYMMDD    tt, ts, te ;
    CALCONV     cal ;
    DATESTR     today, start, end ;
    int         i1, i2, i3 ;
    BOOLE       ok ;
    TS_STR      *ts1, *cc_ts;
    PERIOD      pd ;

    fscanf(in,
      "%lf %lf %lf %d %lf %d %s %lf %ld %ld %ld %lf %lf %d %s %s %s %s %s",
      
           &fexp, &fexp1, &fexp2, &i1, &vol, &i3, txg, &s0, &tt, &ts, &te, &e,
           &divyld, &i2, txc, txd, txf, txe, txpl) ;

    acc    = 0.0001 ;
    pd.num = 0 ;
    pd.unit = DAYS ;
    n     = (INTI) i1 ;
    count = (INTI) i2 ;
    nts   = (INTI) i3 ;

    today = Cldr_YMD2Datestr(tt) ;
    start = Cldr_YMD2Datestr(ts) ;
    end   = Cldr_YMD2Datestr(te) ;
    cal   = Str2CALCONV(txe) ;

    /* translate continuous dividend yield into cc_ts */
    cc_ts = Alloc_TSARRAY(1, 1) ;
    cc_ts->count = 1 ;
    cc_ts->conv  = CONTINUOUS ;
    cc_ts->qbas  = 1 ;
    cc_ts->term[0] = Cldr_TermBetweenDates(&today, &end, 0, cal, SAME, hol) ;   	/* PMSTA-22396 - SRIDHARA � 160502 */
    cc_ts->rate[0] = divyld ;

    div = Alloc_PLANARRAY(1, count) ;
    div[0].filled = count ;

    for (i = 0 ; i < count ; i++)
    {
        fscanf(in, "%ld %lf", &tt, &div[0].f64[i]) ;
        div[0].day[i] = Cldr_YMD2Datestr(tt) ;
    }

    ts1 = Alloc_TSARRAY(1, nts) ;
    for (i = 0 ; i < nts ; i++)
        fscanf(in, "%lf %lf", &ts1[0].term[i], &ts1[0].rate[i]) ;

    ts1->count = nts ;
    ts1->conv  = Str2IRRCONV(txg) ;
    ts1->qbas  = 1 ;

    type  = Str2OPTTYPE(txc) ;
    wrt   = Str2KEYCONV(txd) ;
    risk  = Str2RISKCONV(txf) ;

    crr = Clb_CRR2Tree(n, vol, s0, &today, &end, cal, div, hol) ;   	/* PMSTA-22396 - SRIDHARA � 160502 */
    ok  = CRR_premium(crr, &today, &start, &end, pd, e, vol, ts1, CUBIC_SPLINE,
                      type,
                      cc_ts, CUBIC_SPLINE, div, wrt, risk, -1.0, cal, &fres,
                      &fres1, &fres2) ;

    diff = (fabs(fres - fexp) > acc || fabs(fres1 - fexp1) > acc ||
            fabs(fres2 - fexp2) > acc);

    fprintf(out,"   levels      %d\n", n) ;
    fprintf(out,"   option type %s\n", txc) ;
    fprintf(out,"   spot price    %8.5lf\n", s0) ;
    fprintf(out,"   strike price  %8.5lf\n", e) ;
    fprintf(out,"   today         %8ld\n", Cldr_Datestr2YMD(&today) ) ;
    fprintf(out,"   first expiry  %8ld\n", ts) ;
    fprintf(out,"   last expiry   %8ld\n", te) ;
    fprintf(out,"   irrconv       %8s\n", txg) ;
    fprintf(out,"   volatility    %8.5lf\n", vol) ;
    fprintf(out,"   div.yield     %8.5lf\n", divyld) ;
    fprintf(out,"   with respect to  %s\n", txd) ;
    fprintf(out,"   risk calculation %s\n", txf) ;
    fprintf(out,"   calendar         %s\n", txe) ;
    fprintf(out,"   assumed dividend payments...\n") ;
    for (i = 0 ; i < count ; i++)
        fprintf(out," date %8ld payment %8.5lf\n",
                Cldr_Datestr2YMD(&div[0].day[i]), div[0].f64[i]) ;

    fprintf(out,"   term structure...\n") ;
    for (i = 0 ; i < nts ; i++)
        fprintf(out,"   term %8.5lf rate %8.5lf\n",
                ts1[0].term[i], ts1[0].rate[i]) ;

    fprintf(out,"   Error code  %d\n", ok) ;

    diff = (fabs(fres - fexp) > acc || fabs(fres1 - fexp1) > acc ||
            fabs(fres2 - fexp2) > acc);
    fprintf(out,"%d; option premium      %8.5lf expected = %8.5lf\n",
            (fabs(fres - fexp) > acc), fres, fexp);
    fprintf(out,"%d; 1. order derivative %8.5lf expected = %8.5lf\n",
            (fabs(fres1 - fexp1) > acc), fres1, fexp1);
    fprintf(out,"%d; 2. order derivative %8.5lf expected = %8.5lf\n",
            (fabs(fres2 - fexp2) > acc), fres2, fexp2);

    fprintf(out,"   %s\n\n", txpl) ;

    Free_PLANARRAY(div, 1) ;
    Free_TSARRAY(ts1, 1) ;
    Free_TSARRAY(cc_ts, 1) ;
    Free_BINTREEARRAY(crr, 1) ;

    return diff ;
}

/*
..
*/

/* PMSTA-22396 - SRIDHARA � 160502 */
int test_crr_implied(FILE* in, FILE* out, HOLI_STR* hol)
{
    char        txc[25], txd[25], txe[25], txg[25], txpl[64] ;
    FL64        p, e, acc, fexp, fres, s0, vol ;
    FL64        divyld ;
    INTI        nts, i, count, n, diff ;
    KEYCONV     what ;
    OPTTYPE     type ;
    PLAN_STR    *div ;
    YYYYMMDD    tt, ts, te ;
    CALCONV     cal ;
    DATESTR     today, start, end ;
    int         i1, i2, i3 ;
    BOOLE       ok ;
    TS_STR      *ts1, *cc_ts;
    PERIOD      pd ;
    ITERCTRL    ctrl ;

    acc = 0.0001 ;

    ctrl = Read_ITERCTRL(in, out);

    fscanf(in,
      "%lf %lf %d %lf %d %s %lf %ld %ld %ld %lf %lf %d %s %s %s %s",
      
           &fexp, &p, &i1, &vol, &i3, txg, &s0, &tt, &ts, &te, &e, &divyld,
           &i2, txc, txd, txe, txpl) ;

    pd.num = 0 ;
    pd.unit = DAYS ;
    n     = (INTI) i1 ;
    count = (INTI) i2 ;
    nts   = (INTI) i3 ;

    today = Cldr_YMD2Datestr(tt) ;
    start = Cldr_YMD2Datestr(ts) ;
    end   = Cldr_YMD2Datestr(te) ;
    cal  = Str2CALCONV(txe) ;

    /* translate continuous dividend yield into cc_ts */
    cc_ts = Alloc_TSARRAY(1, 1) ;
    cc_ts->count = 1 ;
    cc_ts->conv  = CONTINUOUS ;
    cc_ts->qbas  = 1 ;
    cc_ts->term[0] = Cldr_TermBetweenDates(&today, &end, 0, cal, SAME, hol) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
    cc_ts->rate[0] = divyld ;

    div = Alloc_PLANARRAY(1, count) ;
    div[0].filled = count ;

    for (i = 0 ; i < count ; i++)
    {
        fscanf(in, "%ld %lf", &tt, &div[0].f64[i]) ;
        div[0].day[i] = Cldr_YMD2Datestr(tt) ;
    }

    ts1 = Alloc_TSARRAY(1, nts) ;
    for (i = 0 ; i < nts ; i++)
        fscanf(in, "%lf %lf", &ts1[0].term[i], &ts1[0].rate[i]) ;

    ts1->count = nts ;
    ts1->conv  = Str2IRRCONV(txg) ;
    ts1->qbas  = 1 ;

    type = Str2OPTTYPE(txc) ;
    what = Str2KEYCONV(txd) ;

    ok = CRR_Implied(p, &today, &start, &end, pd, n, s0, e, vol, ts1,
      CUBIC_SPLINE,
                     type, cc_ts, CUBIC_SPLINE, div, what, cal, &ctrl, &fres, hol)  	/* PMSTA-22396 - SRIDHARA � 160502 */
                       ;

    diff = (fabs(fres - fexp) > acc ) ;

    fprintf(out,"   levels      %d\n", n) ;
    fprintf(out,"   option type %s\n", txc) ;
    fprintf(out,"   premium       %8.5lf\n", p) ;
    fprintf(out,"   spot price    %8.5lf\n", s0) ;
    fprintf(out,"   strike price  %8.5lf\n", e) ;
    fprintf(out,"   today         %8ld\n", Cldr_Datestr2YMD(&today) ) ;
    fprintf(out,"   first expiry  %8ld\n", ts) ;
    fprintf(out,"   last expiry   %8ld\n", te) ;
    fprintf(out,"   irr           %8s\n", txg) ;
    fprintf(out,"   volatility    %8.5lf\n", vol) ;
    fprintf(out,"   div.yield     %8.5lf\n", divyld) ;
    fprintf(out,"   implied ratio %s\n", txd) ;
    fprintf(out,"   calendar         %s\n", txe) ;
    fprintf(out,"   assumed dividend payments...\n") ;
    for (i = 0 ; i < count ; i++)
        fprintf(out,"   date %8ld payment %8.5lf\n",
                Cldr_Datestr2YMD(&div[0].day[i]), div[0].f64[i]) ;

    fprintf(out,"   term structure...\n") ;
    for (i = 0 ; i < nts ; i++)
        fprintf(out,"   term %8.5lf rate %8.5lf\n",
                ts1[0].term[i], ts1[0].rate[i]) ;

    fprintf(out,"   Error code  %8d\n", ok) ;
    fprintf(out,"%d; result is %8lf  expected is %8lf\n", diff, fres, fexp) ;
    fprintf(out,"   %s\n\n", txpl) ;

    Free_PLANARRAY(div, 1) ;
    Free_TSARRAY(ts1, 1) ;
    Free_TSARRAY(cc_ts, 1) ;

    return diff ;
}

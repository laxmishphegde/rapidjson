/* SCID @(#)option.c	1.35 (SimCorp) 99/11/12 14:36:54 */

/************************************************************************
*
*   project     SCecon
*
*   filename    option.c
*
*   contains    routines in the SCecon options library.
*
************************************************************************/

/***** includes ********************************************************/
#include <option.h>

/***** defines  ********************************************************/
#define PAYM_TOL  1.0E-10
#define SHOCKSIZE 0.01
#define MAXIT     100
#define ACC_PRICE 0.000001
#define ACC_RATE  0.000001
#define MIN_VOL   0.00001
#define ACC_TERM  0.000000001
#define SHOCK_TOL 0.0000000001
#define LOW_BOUND 0.0001
#define MIN_GRAD  0.000001
#define MAX_MIRRORS 100
#define VOL_GUESS 15

/***** functions *******************************************************/


/*,,SOH,,
***********************************************************************
*                                                                      
*               Option_Black2P()                                       
*                                                                      
*    interface  #include <option.h>                                    
*               FL64 Option_Black2P(DATESTR  *analys,   
*                                    DATESTR  *voldate,  
*                                    FL64     futp,       
*                                    BOOLE    s_f,        
*                                    FL64     adj,      
*                                    FL64     vol,  
*                                    OPTFUT   *opt,      
*                                    DISCFAC  *df,       
*                                    HOLI_STR *holi,     
*                                    RISKSET  *risk,     
*                                    FL64     *dp,       
*                                    FL64     *ddp) ;    
*                                                                      
*    general    The routine calculates the premium for a general
*               option - using the Black76 formula.          
*               In addition some of the Greek numbers can be computed. 
*                                                                      
*               Key ratios are calculated as follows:                  
*                                                                      
*                   risk->key      dp          ddp                     
*                   ---------      ---         ----                    
*                   KEY_SPOT       Delta       Gamma                   
*                   KEY_PRICE      Delta       Gamma                   
*                   KEY_PROB       Delta       Gamma                   
*                   KEY_MATURITY   Theta       N/A                     
*                   KEY_VOL        Vega        d(Vega)/d(Vol)          
*                   KEY_STRIKE     d(P)/d(C)   d2(P)/d(C)2             
*                   KEY_REPO       Rho         d(rho)/d(r)             
*                   -----------------------------------------          
*                                                                      
*               The KEY_PROB numbers are alternative definitions of    
*               delta and gamma expressing the in-the-moneyness of a 
*               option (delta), and the sensitivity of this (gamma) to 
*               variations in the underlying variable.                 
*               The relation between KEY_SPOT and KEY_PRICE is that 
*               delta for KEY_PRICE is computed as delta for 
*               KEY_SPOT divided by adj. For gamma the difference
*               is adj^2 rather than just adj.
*               Please note that when shocking eg. interest rates 
*               (KEY_REPO) the forward value in reality also changes.
*               If you don't want the forward value to change you 
*               should use the Rho from this function, else use 
*               functions like OptBond_Black2P(). This also
*               goes for KEY_MATURITY.
*                                                                      
*               The argument futp can be either the spot price or the
*               forward price of the underlying, this is defined in 
*               s_f. Note that the spot is quoted on voldate and hence
*               the accompanying forward rate computed at fixing.
*               Thus the function can be used to compute the forward
*               value of an option even in this case, by choosing
*               voldate as the actual analysis date and analys
*               as the date for which you want the forward value.
*                 
*    input      DATESTR  *analys  Pointer to analysis date (NPV date)
*                                 Note that choosing a future date
*                                 means, effectively that the forward
*                                 value of the option on that date
*                                 is computed.
*                                                                      
*               DATESTR  *voldate Vol calculated from this date.       
*                                                                      
*               FL64     futp     If s_f is True, this is the spot 
*                                 price in percent. If s_f is False
*                                 this is the forward price.
*                                                                      
*               BOOLE    s_f      Toggle for spot price forward price.
*                                 True indicates that futp is actually the
*                                 spot price whereas false indicates that
*                                 futp is the forward price of the asset.
*                                                                      
*               FL64     adj      The adjustment factor for the spot 
*                                 price. If s_f is True it is used to 
*                                 compute the forward price as
*                                 futp * adj discounted from the fixing 
*                                 day to the analysis date.
*                                 If s_f is False enter 1.0.
*                                 This can be used for Burghardt/Hoskins
*                                 style margin adjustment for options on
*                                 futures.
*                                 If no adjustment is desired use 1.0
*                                                                      
*               FL64     vol      The annual volatility of the forward 
*                                 price in percent.                    
*                                                                      
*               OPTFUT   *opt     The data defining the option.        
*                                                                      
*               DISCFAC  *df      Discount function for discounting
*                                                                      
*               HOLI_STR *holi    Holiday adjustment setup
*                                                                      
*               RISKSET  *risk    The risk ratio definitions
*                                 Use NULL for no Greeks
*                                                                      
*    output     FL64     *dp      Pointer to the first order derivative
*                                                                      
*               FL64     *ddp     Pointer to the second order 
*                                 derivative.
*                                                                      
*    returns    the option premium.                                    
*                                                                      
*    diagnostics                                                       
*                                                                      
*    see also   OptBond_Black2P()                                    
*               Option_Black2Impl()                                   
*                                                                      
***********************************************************************
,,EOH,,*/

FL64 Option_Black2P(DATESTR* analys,
                    DATESTR* voldate,
                    FL64    futp,
                    BOOLE   s_f,
                    FL64    adj,
                    FL64    vol,
                    OPTFUT*  opt,
                    DISCFAC* df,
                    HOLI_STR* holi,
                    RISKSET* risk,
                    FL64*    dp,
                    FL64*    ddp)
{
    FL64     shock, dfix, disc, p ;
    INTI     qbas ;
    BOOLE    ok ;
    OPTINT   oint ;
    KEYCONV  key ;
    RISKCONV rsk ;
    IRRCONV  irr ;

    if (opt->oadd == CONTPREM)
    {
        opt->oadd = BINARY ;
        opt->bini.poff.poff  = OP_GAP ;
        opt->bini.poff.gap   = opt->ctp.prem ;
        opt->bini.poff.scale = 1.0 ;
    }

    *dp = *ddp = 0.0 ;

    /* Prepare for calling black_*() functions */
	/* PMSTA-22396 - SRIDHARA � 160502 */
    disc = Disc_Interpolation(&opt->dpay, df, holi) ;
    ok   = Disc_forwval(df, analys, &disc, holi) ;
    dfix = Disc_Interpolation(&opt->dfix, df, holi) ;
    /* CHANGE Next was analys, but voldate seems better
       see e.g. cld/blacksettle.tex */
    ok   = ok && Disc_forwval(df, voldate, &dfix, holi) ;

    oint = optfut_set_OPTINT(analys, voldate, opt, vol, holi) ;

    key   = (risk != NULL ? risk->key : KEY_PRICE) ;
    rsk   = (risk != NULL ? risk->risk : ZERO_ORDER) ;
    shock = (risk != NULL ? risk->shock : 0.0) ;
    irr   = (risk != NULL ? risk->irr : COMPOUND) ;
    qbas  = (risk != NULL ? disc_set_qbas(risk->freq) : ANNUALLY) ;
    
    p     = Black_Premium(&oint, futp, s_f, adj, vol, dfix, disc, key,
                          rsk, shock, irr, qbas, dp, ddp, holi) ; 	/* PMSTA-22396 - SRIDHARA � 160502 */

    return p ;
}


/*
..
*/
/*,,SOH,,
***********************************************************************
*                                                                      
*               Option_Black2Impl()                                    
*                                                                      
*    interface  #include <option.h>                                    
*               BOOLE Option_Black2Impl(DATESTR     *analys,           
*                                        DATESTR     *voldate,         
*                                        FL64        prem,             
*                                        BOOLE       is_p,             
*                                        FL64        futp,       
*                                        BOOLE       s_f,        
*                                        FL64        adj,      
*                                        FL64        vol,              
*                                        FL64        spot,             
*                                        OPTFUT      *opt,             
*                                        DISCFAC     *df,              
*                                        HOLI_STR    *holi,            
*                                        KEYCONV     what,             
*                                        ITERCTRL    *ctrl,  
*                                        FL64        *impl) ;          
*                                                                      
*    general    The routine calculates the implied ratio for a general
*               option - using the Black76 formula.          
*                                                                      
*               The parameter what can be one of the following values  
*                                                                      
*                   what            impl                               
*                   ----------      ----                               
*                   KEY_PRICE       Implied forward price    
*                   KEY_SPOT        Implied spot price                 
*                   KEY_VOL         Implied volatility                 
*                   KEY_STRIKE      Implied strike                     
*                                                                      
*               The argument prem can be either the option price or the
*               option delta, this is defined in is_p. Consequently    
*               one can use the routine to find implied strike given   
*               some delta value. 
*               Regarding the use of analys vs. voldate see the
*               documentation for Option_Black2P.
*               
*                                                                      
*    input      DATESTR  *analys  Pointer to analysis date (NPV date)  
*                                                                      
*               DATESTR  *voldate Vol calculated from this date.       
*                                                                      
*               FL64     prem     The option premium to match, quoted  
*                                 on analys.                           
*                                                                      
*               BOOLE    is_p     If True the prem is the price, if    
*                                 False then prem is the option delta. 
*                                                                      
*               FL64     futp     If s_f is True, this is the spot 
*                                 price in percent. If s_f is False
*                                 this is the forward price.
*                                                                      
*               BOOLE    s_f      Toggle for spot price forward price.
*                                                                      
*               FL64     adj      The adjustment factor for the spot 
*                                 price. If s_f is True it is used to 
*                                 compute the forward price as
*                                 futp * adj discounted from the fixing 
*                                 day to the analysis date.
*                                 If s_f is False enter 1.0.
*                                                                      
*               FL64     vol      The annual volatility of the futures 
*                                 price in percent.                    
*                                                                      
*               FL64     spot     The spot price in percent.           
*                                                                      
*               OPTFUT   *opt     The data defining the option.        
*                                 ->oadd assumed as NO_OPTADD.         
*                                                                      
*               DISCFAC  *df      Discount function for discounting    
*                                 future payments.                     
*                                                                      
*               HOLI_STR *holi    Holiday adjustment setup             
*                                                                      
*               KEYCONV  what     What implied ratio to find.          
*                                                                      
*               ITERCTRL *ctrl    Pointer to iteration control data.
*
*    output     FL64     *impl    The implied ratio.                   
*                                                                      
*    returns    True if all is OK, and False if not.                   
*                                                                      
*    diagnostics                                                       
*                                                                      
*    see also   Option_Black2P()                                       
*                                                                      
***********************************************************************
,,EOH,,*/

BOOLE Option_Black2Impl(DATESTR* analys,
                    DATESTR* voldate,
                    FL64    prem,
                    BOOLE   is_p,
                    FL64    futp,
                    BOOLE   s_f,
                    FL64    adj,
                    FL64    vol,
                    OPTFUT*  opt,
                    DISCFAC* df,
                    HOLI_STR* holi,
                    KEYCONV what,
                    ITERCTRL*  ctrl,
                    FL64*    impl)
{
    FL64    dfix, df2, dfu, dfl, pl, pu, disc, shock ;
    RISKSET risk ;
    BOOLE   ok ;
    OPTINT  oint ;
    BLACKINT y;
    ITERCTRL ictrl ;

    if (opt->oadd == CONTPREM)
    {
        opt->oadd = BINARY ;
        opt->bini.poff.poff  = OP_GAP ;
        opt->bini.poff.gap   = opt->ctp.prem ;
        opt->bini.poff.scale = 1.0 ;
    }

    /* Various initialization */
    ok = True ;
    risk.risk  = FIRST_ORDER ;
    risk.shock = -1.0 ;
    if (is_p == True)
        risk.key = what ;
    else
        risk.key = KEY_PRICE ;

    /* In this case we can solve without iterating */
    if (what == KEY_GAP)
    {
        if (opt->oadd == BINARY && opt->bini.poff.poff == OP_GAP)
        {
            opt->oadd = BINARY ;
            opt->bini.poff.gap  = 0.0 ;
            opt->bini.poff.poff = OP_GAP ;
            pu = Option_Black2P(analys, voldate, futp, s_f, adj, vol, opt, df,
                                holi, &risk, &dfu, &df2) ;
            opt->bini.poff.gap  = 1.0 ;
            opt->bini.poff.poff = OP_BINARY ;
            pl = Option_Black2P(analys, voldate, futp, s_f, adj, vol, opt, df,
                                holi, &risk, &dfl, &df2) ;

            if (is_p == True)
            {
                if (fabs(pl) > PAYM_TOL)
                    *impl = (pu - prem) / pl ;
                else
                    ok = False ;
            }
            else
                ok = False ;

            return ok ;
        }
        else
            return False ;
    }

    /* Prepare for call to implied calculator */
	/* PMSTA-22396 - SRIDHARA � 160502 */
    disc = Disc_Interpolation(&opt->dpay, df, holi) ;
    ok   = Disc_forwval(df, analys, &disc, holi) ;
    dfix = Disc_Interpolation(&opt->dfix, df, holi) ;
        /* CHANGE Next was analys, but voldate seems better
       see e.g. cld/blacksettle.tex */

    ok   = Disc_forwval(df, voldate, &dfix, holi) ;

    /* Fill intermediate data containers */
    oint = optfut_set_OPTINT(analys, voldate, opt, vol, holi) ;
    shock = ((ctrl->shock <= 0.0) ? Scutl_Default_Shock(-1.0, what) : 
    ctrl->shock);
    y = Black_SetBLACKINT(&oint, prem, is_p, futp, s_f, adj, vol, dfix,
      disc, what, shock);

    Init_ITERCTRL(&ictrl);
    
    /* Set uninitialized init_guess */
    if (ctrl->use_init_guess == False)
    {
      if ((ctrl->use_lower) && (ctrl->use_upper))
        ictrl.init_guess = 0.5*(ctrl->lower + ctrl->upper);
      else if (what == KEY_PRICE || what == KEY_SPOT)
        ictrl.init_guess = opt->strike;
      else if (what == KEY_STRIKE)
        ictrl.init_guess = futp;
      else  /* if (what == KEY_VOL) */
        ictrl.init_guess = VOL_GUESS;
    }
    else
      ictrl.init_guess = ctrl->init_guess;

    ictrl.init_guess = GETMAX(ictrl.init_guess, LOW_BOUND);
    ictrl.use_init_guess = ctrl->use_init_guess ;

    /* Set uninitialized boundaries for iteration */
    if (ctrl->use_lower == False)
    {  
      ictrl.lower = ictrl.init_guess / 1.1 ;      
      if (what == KEY_VOL)
        ictrl.lower = GETMIN(0.001, ictrl.lower);
    }
    else
      ictrl.lower = GETMIN(ctrl->lower, ictrl.init_guess);
      
    if (ctrl->use_upper == False)
    {
      ictrl.upper = ictrl.init_guess * 1.1 ;    
      if (what == KEY_VOL)
        ictrl.upper = GETMAX(100, ictrl.upper);
    }
    else
      ictrl.upper = GETMAX(ctrl->upper, ictrl.init_guess);

    if ((ctrl->use_lower == False) || (ctrl->use_upper == False))
      ok = Math_PosRootBracket(&Black_NewtonRaphson, &y, &ictrl,
        &ictrl.lower, &ictrl.upper, holi);  /* PMSTA-29444 - SRIDHARA - 050318 */

    ictrl.use_lower = ctrl->use_lower ;
    ictrl.use_upper = ctrl->use_upper ;

    ictrl.maxiter = ((ctrl->maxiter < 0) ? MAXIT : ctrl->maxiter);
    ictrl.damp = ((ctrl->damp < 0.0) ? 1.0 : ctrl->damp);
    ictrl.acc = ctrl->acc; /* Set in Black_Implied */
    ictrl.what_acc = ((ctrl->what_acc < 0) ? 0 : ctrl->what_acc);
    ictrl.gfreq = ((ctrl->gfreq < 0) ? 1 : ctrl->gfreq);
    ictrl.bisec = ((ctrl->bisec < 0) ? 1 : ctrl->bisec);
    ictrl.shock = ctrl->shock; /* Set in Black_Root */

    /* Now do the real call. Note that if ctrl->lower and ctrl->upper
       do not bracket the
       solution then ok will automatically be returned as False */

    ok   = Black_Implied(&oint, prem, is_p, futp, s_f, adj, vol, dfix, 
              disc, what, &ictrl, impl, holi) ;   	/* PMSTA-22396 - SRIDHARA � 160502 */
    return ok ;
}


/*
..
*/

FL64 Black_d1(FL64 f, FL64 e, FL64 vol, FL64 t, FL64 fac)
{
    FL64 tmp, d1 ;

    tmp = Vol_Ann2Per(vol / 100.0 , t) ;
    d1  = (fabs(e) > PAYM_TOL && f > PAYM_TOL ? log(f/e) + fac*SQR(tmp) : 0.0) ;

    if (fabs(tmp) > PAYM_TOL)
        d1 /= tmp ;
    else
        d1 = N01_EXTREME ;

    return d1 ;
}


/*
..tfix - time from analys to fixing     dfix - DF from analys till fixing
..t    - time from analys to payout     disc - DF from analys to payout
..tvol - time from voldate to fixing

..s_f == True -> f is Spot and adj is used to find adjusted spot

..IN THE FUTURE only dates inserted + DISCFAC curves -> needed for theta
  calculation of exotics (day shock) + more general calculation
  Also implied for forward starts is messy
  ->-> Need to reconsider the whole setup for generality

..optFX_black2DFp() more risk ratios !!
  optFX_black2DFimpl() to be made !!

*/

FL64 Black_Premium(OPTINT* opt, FL64 f, BOOLE s_f, FL64 adj, FL64 vol, 
                       FL64  dfix, FL64 disc, KEYCONV wrt, RISKCONV risk, 
					   FL64 shock, IRRCONV irr, INTI qbas, FL64* dp, FL64* ddp, HOLI_STR* holi)
{
    FL64    dpy, ff, repo, dfix1, disc1, d2, d1, x1, x2, size, plo, phi, p,
            N1, N1m, adj1, dp1, ddp1 ;
    DATESTR start ;

    /* warning avoidance */
    plo = phi = N1 = N1m = p = size = 0.0;

    Math_LaGuerre(opt->analys.y, opt->analys.m, opt->analys.d);

    if (opt->oadd == TOUCHDIG || opt->oadd == CHOOSER)
        opt->type = CALL ;        /* Avoid straddles */

    if (opt->type == STRADDLE)
    {
        opt->type = CALL ;
        p  = Black_Premium(opt, f, s_f, adj, vol, dfix, disc,
                           wrt, risk, shock, irr, qbas, &dp1, &ddp1, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
        *dp  = dp1 ;
        *ddp = ddp1 ;
        opt->type = PUT ;
        p += Black_Premium(opt, f, s_f, adj, vol, dfix, disc,
                           wrt, risk, shock, irr, qbas, &dp1, &ddp1, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
        *dp  += dp1 ;
        *ddp += ddp1 ;
        opt->type = STRADDLE ;

        return p ;
    }

    *dp = *ddp = 0.0 ;

    if (opt->tfix < -0.001 || opt->tvol < -0.001)
        return 0.0 ;

    /* Be careful JJ is out there */
    vol = GETMAX(vol, MIN_VOL) ;

    if (opt->e < MIN_VOL && opt->e >= 0.0)
        opt->e = MIN_VOL ;

    else if (opt->e > MIN_VOL && opt->e <= 0.0)
        opt->e = - MIN_VOL ;

    /* Find Forward Price */
    if (s_f == True && dfix > 0.000001)
        /* This requires that the adjusted spot is relative to fixing */
        ff = (f * adj) / dfix ;
    else
        ff = f ;
/*
printf("f %lf f %lf adj %lf dfix %lf\n", ff, f, adj, dfix) ;
*/
/*
printf("vol %lf e %lf f %lf tfix %lf\n", vol, e, ff, tfix) ;
*/

    d1 = Black_d1(ff, opt->e, vol, opt->tvol, 0.5) ;
    d2 = black_d2(d1, vol, opt->tvol) ;

    /* Find UNdiscounted payoff */
    if (opt->oadd == NO_OPTADD || opt->oadd == RESET)
    {
        /* Vanilla options */
        N1 = Stat_NormalizedNormal(d1) ;
        p  = ff * N1 ;
        p -= Stat_NormalizedNormal(d2) * opt->e ;
        if (opt->type == PUT)
        {
            p  = GETMAX(0.0, p) + (opt->e - ff) ;
            N1 = N1 - 1.0 ;
        }

        /* Ensure that non-negative results are delivered */
        p = GETMAX(0.0, p) ;
    }

    else if (opt->oadd == CHOOSER)
        p = Option_Chooser(opt, vol, ff, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */

    else if (opt->oadd == LOOKBACK)
        p = Option_Lookback(f, opt, adj, dfix, vol, ff) ;

    else if (opt->oadd == BARRIER)
    {
        if (opt->barr.poff.poff == OP_VANILLA)
            p = Option_Barrier(opt, f, s_f, adj, vol, ff, dfix, disc, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
        else
            p = Option_Barrier_dig(opt, f, s_f, adj, vol, ff, dfix, disc, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
    }

    else if (opt->oadd == LADDER)
        p = Option_Ladder(opt, f, s_f, adj, vol, ff, dfix, disc, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
    
    else if (opt->oadd == TSWITCH)
        p = Option_Tswitch(opt, f, adj, vol, dfix, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
    
    else if (opt->oadd == CORRIDOR)
        p = Option_Corridor(opt, f, adj, vol, dfix, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
    
    else if (opt->oadd == ASIAN)
        p = Option_Asian(opt, f, s_f, adj, vol, disc, dfix, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */

    else if (opt->oadd == BINARY)
    {
        if (opt->bini.poff.poff == OP_VANILLA)
        {
            opt->oadd = NO_OPTADD ;
            p = Black_Premium(opt, f, s_f, adj, vol, dfix, 1.0, wrt,
                              ZERO_ORDER, shock, irr, qbas, &x1, &x2, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
            opt->oadd = BINARY ;
        }

        if (opt->bini.poff.poff == OP_BINARY)
        {
            /* Binary /Digital options */
            if (opt->type == CALL)
                p = opt->bini.poff.gap * Stat_NormalizedNormal(d2) ;
            else
                p = opt->bini.poff.gap * Stat_NormalizedNormal(-d2) ;
        }
        else if (opt->bini.poff.poff == OP_ASSETON)
        {
            /* Asset-Or-Nothing options */
            if (opt->type == CALL)
                p = opt->bini.poff.scale * ff * Stat_NormalizedNormal(d1) ;
            else
                p = opt->bini.poff.scale * ff * Stat_NormalizedNormal(-d1) ;
        }
        else if (opt->bini.poff.poff == OP_GAP)
        {
            /* GAP options */
            if (opt->type == CALL)
            {
                p  = ff * Stat_NormalizedNormal(d1) ;
                p -= (opt->e + opt->bini.poff.gap) * Stat_NormalizedNormal(d2)
                  ;
            }
            else
            {
                p  = - ff * Stat_NormalizedNormal(-d1) ;

                /* Here is an error in Rubinstein's notes (sign on Gap) */
                p += (opt->e - opt->bini.poff.gap) *
                  Stat_NormalizedNormal(-d2) ;
            }
        }
    }

    else if (opt->oadd == CONTPREM)
    {
        opt->oadd = BINARY ;
        opt->bini.poff.poff  = OP_GAP ;
        opt->bini.poff.gap   = opt->ctp.prem ;
        opt->bini.poff.scale = 1.0 ;
        p = Black_Premium(opt, f, s_f, adj, vol, dfix, disc, wrt,
                          ZERO_ORDER, shock, irr, qbas, &x1, &x2, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
        opt->oadd = CONTPREM ;
    }

    else if (opt->oadd == TOUCHDIG)
    {
        /* Avoid dumb cases */
        if (opt->tdi.poff.poff == OP_VANILLA)
            opt->tdi.poff.poff = OP_BINARY ;

        if (opt->tdi.poff.gap < MIN_VOL)
            opt->tdi.poff.gap = 1.0 ;

        if (opt->tdi.poff.scale < MIN_VOL)
            opt->tdi.poff.scale = 1.0 ;

        p = Option_Barrier_touch(opt, f, adj, vol, ff, dfix, disc, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
    }

    else if (opt->oadd == COMPOPT)
        p = Option_Compound_option(opt, ff, f, vol, adj, dfix, disc) ;

    else if (opt->oadd == DOUBLKO)
        p = Option_Double_ko(opt, f, vol, adj, dfix, disc) ;

    if (opt->ptype == UP_FRONT)
        p *= disc ;
/*
printf("f % lf n1 %lf X %lf n2 %lf disc %lf p %lf\n",
ff, Stat_NormalizedNormal(d1), opt->e, Stat_NormalizedNormal(d1), disc, p) ;
*/
    /* Compute risk ratios - if specified. */
    if (risk == ZERO_ORDER)
        return p ;

    switch (wrt)
    {
        case KEY_PROB:

            size = Scutl_Default_Shock(-1.0, wrt) ;
            d1   = Black_d1(ff + size, opt->e, vol, opt->tvol, 0.5) ;
            N1m  = Stat_NormalizedNormal(d1) ;
            if (opt->type == PUT)
                N1m = N1m - 1.0 ;

            break ;

        case KEY_PRICE:
        case KEY_SPOT:

            size = Scutl_Default_Shock(shock, wrt) ;

            if (fabs(size) > f)
                size = f / 2.0 ;

            plo  = Black_Premium(opt, f - size, s_f, adj, vol, dfix, disc,
                                 KEY_PRICE,
                                 ZERO_ORDER, shock, irr, qbas, &x1, &x2, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
            phi  = Black_Premium(opt, f + size, s_f, adj, vol, dfix, disc,
                                 KEY_PRICE,
                                 ZERO_ORDER, shock, irr, qbas, &x1, &x2, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */

            /* Beware of adjusted spot shocking */
            if (wrt == KEY_PRICE)
                size *= adj ;
/*
printf("spot %lf forw %lf adj %lf dfix %lf\n", f, ff, adj, dfix) ;
*/

            break ;

        case KEY_REPO:

            size = Scutl_Default_Shock(shock, wrt) ;
            repo = TVMunit_Yield(disc, opt->t, irr, qbas) ;

            disc1 = TVMunit_NPV(opt->t, repo - size, irr, qbas) ;
            dfix1 = TVMunit_NPV(opt->tfix, repo - size, irr, qbas) ;
            plo   = Black_Premium(opt, f, s_f, adj, vol, dfix1, disc1, KEY_REPO,
                                  ZERO_ORDER, shock, irr, qbas, &x1, &x2, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */

            disc1 = TVMunit_NPV(opt->t, repo + size, irr, qbas) ;
            dfix1 = TVMunit_NPV(opt->tfix, repo + size, irr, qbas) ;
            phi   = Black_Premium(opt, f, s_f, adj, vol, dfix1, disc1, KEY_REPO,
                                  ZERO_ORDER, shock, irr, qbas, &x1, &x2, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
            break ;

        case KEY_VOL:

            size = Scutl_Default_Shock(shock, wrt) ;

            plo  = Black_Premium(opt, f, s_f, adj, vol-size, dfix, disc,
                                 KEY_VOL,
                                 ZERO_ORDER, shock, irr, qbas, &x1, &x2, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
            phi  = Black_Premium(opt, f, s_f, adj, vol+size, dfix, disc,
                                 KEY_VOL,
                                 ZERO_ORDER, shock, irr, qbas, &x1, &x2, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
            break ;

        case KEY_MATURITY:

            /* Use a dummy date */
            start = Cldr_YMD2Datestr((YYYYMMDD) 19900101) ;
            dpy   = (FL64) Cldr_DaysPerYear(&start, &start, 0, opt->cal,
              LAST, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
            size  = Scutl_Default_Shock(shock, wrt) / dpy ;

            repo  = TVMunit_Yield(disc, opt->t, CONTINUOUS, 0) ;
            disc1 = TVMunit_NPV(opt->t - size, repo, CONTINUOUS, 0) ;
            dfix1 = TVMunit_NPV(opt->tfix - size, repo, CONTINUOUS, 0) ;
            opt->tvol -= size ;
            opt->tfix -= size ;
            opt->t    -= size ;

            repo = TVMunit_Yield(adj, opt->tfix, CONTINUOUS, 0) ;
            adj1 = TVMunit_NPV(opt->tfix - size, repo, CONTINUOUS, 0) ;

            plo = Black_Premium(opt, f, s_f, adj1, vol, dfix1, disc1,
                                KEY_MATURITY,
                                ZERO_ORDER, shock, irr, qbas, &x1, &x2, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */

            repo  = TVMunit_Yield(disc, opt->t, CONTINUOUS, 0) ;
            disc1 = TVMunit_NPV(opt->t + 2.0 * size, repo, CONTINUOUS, 0) ;
            dfix1 = TVMunit_NPV(opt->tfix + 2.0 * size, repo, CONTINUOUS, 0) ;
            opt->tvol += 2.0 * size ;
            opt->tfix += 2.0 * size ;
            opt->t    += 2.0 * size ;

            repo = TVMunit_Yield(adj, opt->tfix, CONTINUOUS, 0) ;
            adj1 = TVMunit_NPV(opt->tfix - size, repo, CONTINUOUS, 0) ;

            phi = Black_Premium(opt, f, s_f, adj1, vol, dfix1, disc1,
                                KEY_MATURITY,
								ZERO_ORDER, shock, irr, qbas, &x1, &x2, holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */
            opt->tvol -= size ;
            opt->tfix -= size ;
            opt->t    -= size ;

            break ;

        case KEY_STRIKE:

            size = Scutl_Default_Shock(shock, wrt) ;

            opt->e -= size ;
            plo = Black_Premium(opt, f, s_f, adj, vol, dfix, disc, KEY_STRIKE,
				ZERO_ORDER, shock, irr, qbas, &x1, &x2, holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */
            opt->e += 2.0 * size ;
            phi = Black_Premium(opt, f, s_f, adj, vol, dfix, disc, KEY_STRIKE,
                                ZERO_ORDER, shock, irr, qbas, &x1, &x2, holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */

            opt->e -= size ;
            break ;

        default:
            ;
    }

    if (wrt == KEY_MATURITY && fabs(size) > SHOCK_TOL)
        *dp = (plo - p) / size ;
    else if (wrt == KEY_PROB)
        *dp = N1 ;
    else if (fabs(size) > SHOCK_TOL)
        *dp = (phi - plo) / (2.0 * size) ;

    if (risk == SECOND_ORDER && wrt != KEY_MATURITY)
    {
        if (wrt == KEY_PROB && fabs(size) > SHOCK_TOL)
            *ddp = (N1m - N1) / size ;
        else if (fabs(size) > SHOCK_TOL)
            *ddp = (phi + plo - 2.0 * p) / SQR(size) ;
    }

    return p ;
}


/*
..
*/

BOOLE Black_Implied(OPTINT* opt, FL64 p, BOOLE is_p, FL64 f, BOOLE s_f,
                    FL64 adj, FL64 vol, FL64 dfix, FL64 disc, KEYCONV what,
					ITERCTRL*  ctrl, FL64* res, HOLI_STR *holi)
{
    FL64 acc ;

    /* warning avoidance */
    acc = 0.0;

    /* Set up bounds for the unknown variable + the desired accuracy */
    if (what == KEY_PRICE || what == KEY_STRIKE)
    {
        acc = ACC_PRICE ;
        ctrl->lower = (ctrl->use_lower ? ctrl->lower :
            GETMAX(ctrl->lower, LOW_BOUND)) ;
    }

    else if (what == KEY_REPO || what == KEY_VOL)
        acc = ACC_RATE ;

    else if (what == KEY_MATURITY)
    {
        acc = ACC_TERM ;
        ctrl->lower = (ctrl->use_lower ? ctrl->lower :
            (opt->t - opt->tfix) + GETMAX(ctrl->lower, LOW_BOUND)) ;
    }

    /* Now find the implied ratio (root) */
    if (opt->ptype == BY_MARGIN && what == KEY_REPO)
    {
        *res = 0.0 ;
        return True ;
    }

    if (ctrl->acc <= 0.0) 
      ctrl->acc = acc;

    return Black_Root(opt, p, is_p, f, s_f, adj, vol, dfix, disc,
                      what, ctrl, res, holi) ;   	/* PMSTA-22396 - SRIDHARA � 160502 */
}


/*
..
*/

void Black_SetImpl(FL64 x, FL64* pu, FL64* dfix, FL64* disc, FL64* vol,
                   FL64* e, FL64* tvol, FL64* tfix, FL64* to, KEYCONV what)
{
    FL64 dif1, diff, repo ;

    if      (what == KEY_PRICE || what == KEY_SPOT)    *pu = x ;
    else if (what == KEY_REPO)
    {
        *disc = TVMunit_NPV(*to, x, CONTINUOUS, 0) ;
        *dfix = TVMunit_NPV(*tfix, x, CONTINUOUS, 0) ;
    }
    else if (what == KEY_VOL)      *vol = x ;
    else if (what == KEY_STRIKE)   *e = x ;
    else if (what == KEY_MATURITY)
    {
        diff  = *to - *tfix ;
        dif1  = *to - *tvol ;
        repo  = TVMunit_Yield(*disc, *to, CONTINUOUS, 0) ;
        *to   = x ;
        *tfix = *to - diff ;
        *tvol = *to - dif1 ;
        *disc = TVMunit_NPV(*to, repo, CONTINUOUS, 0) ;
        *dfix = TVMunit_NPV(*tfix, repo, CONTINUOUS, 0) ;
    }
}

/*
..
*/

BLACKINT Black_SetBLACKINT(OPTINT*  opt, FL64  prem, BOOLE  is_p, 
                              FL64  pu, 
                              BOOLE  s_f, FL64  adj, FL64  vol, 
                              FL64  dfix, FL64  disc, KEYCONV  what,
                              FL64  shock)
{
  BLACKINT blckint;

  blckint.opt = opt;
  blckint.prem = prem;
  blckint.is_p = is_p;
  blckint.pu = pu;
  blckint.s_f = s_f;
  blckint.adj = adj;
  blckint.vol = vol;
  blckint.dfix = dfix;
  blckint.disc = disc;
  blckint.what = what;
  blckint.shock = shock;

  return blckint;
}

/*
..
*/

void Black_GetBLACKINT(BLACKINT*  blckint, 
                          OPTINT**  opt, FL64*  prem, BOOLE*  is_p, 
                          FL64*  pu, 
                          BOOLE*  s_f, FL64*  adj, FL64*  vol, 
                          FL64*  dfix, FL64*  disc, KEYCONV*  what,
                          FL64*  shock) 
{
  *opt = blckint->opt;
  *prem = blckint->prem;
  *is_p = blckint->is_p;
  *pu = blckint->pu;
  *s_f = blckint->s_f;
  *adj = blckint->adj;
  *vol = blckint->vol;
  *dfix = blckint->dfix;
  *disc = blckint->disc;
  *what = blckint->what;
  *shock = blckint->shock;
}

/*
..
*/

BOOLE Black_NewtonRaphson(FL64  x, void*  y, BOOLE  grad, FL64*  fx,
                             FL64*  dfx, void* hol)
{
  OPTINT* opt; 
  BOOLE is_p, s_f; 
  FL64 prem, pu, adj, vol, dfix, disc, dum, shock, fx1;
  KEYCONV what;
  RISKCONV risk;

  /* PMSTA-22396 - SRIDHARA � 160502 */
  HOLI_STR holi = (*(HOLI_STR *)hol);   /* PMSTA-29444 - SRIDHARA - 050318 */
  holi = Set_HOLI_STR(NO_BUSADJUST, 0, NULL);
  
  /* Get data from y */
  Black_GetBLACKINT((BLACKINT*)y, &opt, &prem, &is_p, &pu, &s_f, &adj, 
    &vol, &dfix, &disc, &what, &shock);

  /* Set input for Black_Premium */
  Black_SetImpl(x, &pu, &dfix, &disc, &vol, &opt->e, &opt->tvol,
    &opt->tfix, &opt->t, what);
  
  if (is_p == True)
  {
    if (grad == True)
      risk = FIRST_ORDER;
    else
      risk = ZERO_ORDER;
    *fx = Black_Premium(opt, pu, s_f, adj, vol, dfix, disc,
            what, risk, -1.0, CONTINUOUS, 0, dfx, &dum, &holi) - prem;   /* PMSTA-22396 - SRIDHARA � 160502 */
  }
  else
  {
    /* Be careful when finding implied given delta */
    dum = Black_Premium(opt, pu, s_f, adj, vol, dfix, disc,
          KEY_PRICE, FIRST_ORDER, -1.0, CONTINUOUS, 0, fx, dfx, &holi);  /* PMSTA-22396 - SRIDHARA � 160502 */

    /* Now find delta sensitivity with respect to what */
    if (grad == True)
    {
      shock = ((shock <= 0.0) ? Scutl_Default_Shock(-1.0, what) : shock);
      Black_SetImpl(x + shock, &pu, &dfix, &disc, &vol, &opt->e,
        &opt->tvol, &opt->tfix, &opt->t, what) ;
      dum = Black_Premium(opt, pu, s_f, adj, vol, dfix, disc,
        KEY_PRICE, FIRST_ORDER, -1.0, CONTINUOUS, 0, &fx1,
        dfx, &holi);  /* PMSTA-22396 - SRIDHARA � 160502 */
      *dfx = (fx1 - *fx) / shock;
    }
    *fx -= prem;
  }

  return True;
}

/*
..
*/

BOOLE Black_Root(OPTINT*  opt, FL64  pr, BOOLE  is_p, FL64  pu,
                 BOOLE  s_f, FL64  adj, FL64  vol,
                 FL64  dfix, FL64  disc, KEYCONV  what,
				 ITERCTRL*  ctrl, FL64*  rts, HOLI_STR* holi)
{
  BLACKINT y;
  FL64     shock;
  NR_ERR   err;
  BOOLE    ok;

  shock = ((ctrl->shock <= 0.0) ? Scutl_Default_Shock(-1.0, what) : 
    ctrl->shock);
  ctrl->shock = -1.0; /* default */

  y = Black_SetBLACKINT(opt, pr, is_p, pu, s_f, adj, vol, dfix,
      disc, what, shock);

  err = Newton_Raphson(&Black_NewtonRaphson, &y, ctrl, rts, holi);                	/* PMSTA-22396 - SRIDHARA � 160502 */
  ok = (err == NR_ROOT_FOUND ? True : False);

  return ok;
}

/* Option on a Normally Distributed Factor:
     opt   - option definition
     f     - forward or spot value
     s_f   - True => f is spot and adj is used to calculate forward
     adj   - calculate forward as f * adj / discfac(analys, dfix)
     vol   - volatility
     dfix  - discfac(analys, dfix)
     disc  - discfac(analys, dpay)
     wrt   - risk convention
     shock - shock size
     irr   - interest rate convention
     qbas  - quoting basis
   See "Spread Options", MBP-99-01 for a detailed description.
*/


FL64 NormDist_Premium(OPTINT*   opt, 
                          FL64      f,
                          BOOLE     s_f,
                          FL64      adj,
                          FL64      vol, 
                          FL64      dfix,
                          FL64      disc,
                          KEYCONV   wrt,
                          RISKCONV  risk, 
                          FL64      shock,
                          IRRCONV   irr,
                          INTI      qbas,
                          FL64*     dp, 
                          FL64*     ddp)
{
    FL64    dpy, ff, repo, dfix1, disc1, x1, x2, size, plo, phi, p,
            N1, N1m, adj1, dp1, ddp1, sgn, tmp1, tmp2, tmp3,
            p_asset, p_bin;
    DATESTR start ;

	/* PMSTA-22396 - SRIDHARA � 160502 */
	HOLI_STR holi;
	holi = Set_HOLI_STR(NO_BUSADJUST, 0, NULL);

      /* warning avoidance */
    plo = phi = N1 = N1m = p = size = 0.0;

    if (opt->type == STRADDLE)
    {
        opt->type = CALL ;
        p  = NormDist_Premium(opt, f, s_f, adj, vol, dfix, disc,
                              wrt, risk, shock, irr, qbas, &dp1, &ddp1) ;
        *dp  = dp1 ;
        *ddp = ddp1 ;
        opt->type = PUT ;
        p += NormDist_Premium(opt, f, s_f, adj, vol, dfix, disc,
                              wrt, risk, shock, irr, qbas, &dp1, &ddp1) ;
        *dp  += dp1 ;
        *ddp += ddp1 ;
        opt->type = STRADDLE ;

        return p ;
    }

    *dp = *ddp = 0.0 ;

    if (opt->type == CALL) sgn = 1.0; else sgn = -1.0;

    if (opt->tfix < -0.001 || opt->tvol < -0.001)
        return 0.0 ;

      /* Extreme values ? */

    vol = GETMAX(vol, MIN_VOL) ;

    if (opt->e < MIN_VOL && opt->e >= 0.0)
        opt->e = MIN_VOL ;

    else if (opt->e > MIN_VOL && opt->e <= 0.0)
        opt->e = - MIN_VOL ;

      /* Find Forward Price */
    if (s_f == True && dfix > 0.000001)
        /* This requires that the adjusted spot is relative to fixing */
        ff = (f * adj) / dfix ;
    else
        ff = f ;

      /* Find UNdiscounted payoff */
    switch (opt->oadd)
    {
    case NO_OPTADD:
    case BINARY:
        vol = Vol_Ann2Per(vol / 100.0 , opt->tvol) ;

        sgn = (opt->type == CALL ? 1.0 : -1.0);

        tmp1 = (ff - opt->e) ;
        p_asset = sgn * vol / sqrt(2.0 * sc_PI);
        if (vol > PAYM_TOL)
        {
          tmp2 = - SQR(tmp1) / (2.0 * SQR(vol));
          p_asset *= exp(tmp2);
        }

        if (vol > PAYM_TOL)
          tmp3 = sgn * tmp1 / vol;
        else
          tmp3 = (sgn * tmp1 > PAYM_TOL ? N01_EXTREME : -N01_EXTREME);

        /* Primitive binary and asset-or-nothing: */
        p_bin = Stat_NormalizedNormal(tmp3);
        p_asset += ff * Stat_NormalizedNormal(tmp3);

        /* Vanilla: (must be non-negative) */
        p = GETMAX(0.0, sgn * (p_asset - opt->e * p_bin));

        if (opt->oadd == BINARY && opt->bini.poff.poff == OP_GAP)
          p = p - opt->bini.poff.gap * p_bin;
        else if (opt->oadd == BINARY && opt->bini.poff.poff == OP_ASSETON)
          p = opt->bini.poff.scale * p_asset;
        else if (opt->oadd == BINARY && opt->bini.poff.poff == OP_BINARY)
          p = opt->bini.poff.gap * p_bin;

        break;
    default:
      /* ERROR !!! */
      SCecon_error("Invalid option-additional", "NormDist_Premium()", 
                   SCECONWARNING);
      break;
    }

    if (opt->ptype == UP_FRONT)
        p *= disc ;

    /* Compute risk ratios - if specified. */
    if (risk == ZERO_ORDER)
        return p ;

    switch (wrt)
    {
        /*
        case KEY_PROB:

            size = Scutl_Default_Shock(-1.0, wrt) ;
            d1   = Black_d1(ff + size, opt->e, vol, opt->tvol, 0.5) ;
            N1m  = Stat_NormalizedNormal(d1) ;
            if (opt->type == PUT)
                N1m = N1m - 1.0 ;

            break ;
        */

        case KEY_PRICE:
        case KEY_SPOT:

            size = Scutl_Default_Shock(shock, wrt) ;

            if (fabs(size) > f)
                size = f / 2.0 ;

            plo  = NormDist_Premium(opt, f - size, s_f, adj, vol, dfix, disc,
                                    KEY_PRICE,
                                    ZERO_ORDER, shock, irr, qbas, &x1, &x2) ;
            phi  = NormDist_Premium(opt, f + size, s_f, adj, vol, dfix, disc,
                                    KEY_PRICE,
                                    ZERO_ORDER, shock, irr, qbas, &x1, &x2) ;

            /* Beware of adjusted spot shocking */
            if (wrt == KEY_PRICE)
                size *= adj ;

            break ;

        case KEY_REPO:

            size = Scutl_Default_Shock(shock, wrt) ;
            repo = TVMunit_Yield(disc, opt->t, irr, qbas) ;

            disc1 = TVMunit_NPV(opt->t, repo - size, irr, qbas) ;
            dfix1 = TVMunit_NPV(opt->tfix, repo - size, irr, qbas) ;
            plo   = NormDist_Premium(opt, f, s_f, adj, vol, dfix1, disc1, 
                      KEY_REPO, ZERO_ORDER, shock, irr, qbas, &x1, &x2) ;

            disc1 = TVMunit_NPV(opt->t, repo + size, irr, qbas) ;
            dfix1 = TVMunit_NPV(opt->tfix, repo + size, irr, qbas) ;
            phi   = NormDist_Premium(opt, f, s_f, adj, vol, dfix1, disc1, 
                      KEY_REPO, ZERO_ORDER, shock, irr, qbas, &x1, &x2) ;
            break ;

        case KEY_VOL:

            size = Scutl_Default_Shock(shock, wrt) ;

            plo  = NormDist_Premium(opt, f, s_f, adj, vol-size, dfix, disc,
                                    KEY_VOL,
                                    ZERO_ORDER, shock, irr, qbas, &x1, &x2) ;
            phi  = NormDist_Premium(opt, f, s_f, adj, vol+size, dfix, disc,
                                    KEY_VOL,
                                    ZERO_ORDER, shock, irr, qbas, &x1, &x2) ;
            break ;

        case KEY_MATURITY:

            /* Use a dummy date */
            start = Cldr_YMD2Datestr((YYYYMMDD) 19900101) ;
            dpy   = (FL64) Cldr_DaysPerYear(&start, &start, 0, opt->cal,
				LAST, &holi); 	/* PMSTA-22396 - SRIDHARA � 160502 */
            size  = Scutl_Default_Shock(shock, wrt) / dpy ;

            repo  = TVMunit_Yield(disc, opt->t, CONTINUOUS, 0) ;
            disc1 = TVMunit_NPV(opt->t - size, repo, CONTINUOUS, 0) ;
            dfix1 = TVMunit_NPV(opt->tfix - size, repo, CONTINUOUS, 0) ;
            opt->tvol -= size ;
            opt->tfix -= size ;
            opt->t    -= size ;

            repo = TVMunit_Yield(adj, opt->tfix, CONTINUOUS, 0) ;
            adj1 = TVMunit_NPV(opt->tfix - size, repo, CONTINUOUS, 0) ;

            plo = NormDist_Premium(opt, f, s_f, adj1, vol, dfix1, disc1,
                                   KEY_MATURITY,
                                   ZERO_ORDER, shock, irr, qbas, &x1, &x2) ;

            repo  = TVMunit_Yield(disc, opt->t, CONTINUOUS, 0) ;
            disc1 = TVMunit_NPV(opt->t + 2.0 * size, repo, CONTINUOUS, 0) ;
            dfix1 = TVMunit_NPV(opt->tfix + 2.0 * size, repo, CONTINUOUS, 0) ;
            opt->tvol += 2.0 * size ;
            opt->tfix += 2.0 * size ;
            opt->t    += 2.0 * size ;

            repo = TVMunit_Yield(adj, opt->tfix, CONTINUOUS, 0) ;
            adj1 = TVMunit_NPV(opt->tfix - size, repo, CONTINUOUS, 0) ;

            phi = NormDist_Premium(opt, f, s_f, adj1, vol, dfix1, disc1,
                                   KEY_MATURITY,
                                   ZERO_ORDER, shock, irr, qbas, &x1, &x2) ;
            opt->tvol -= size ;
            opt->tfix -= size ;
            opt->t    -= size ;

            break ;

        case KEY_STRIKE:

            size = Scutl_Default_Shock(shock, wrt) ;

            opt->e -= size ;
            plo = NormDist_Premium(opt, f, s_f, adj, vol, dfix, disc, 
                       KEY_STRIKE, ZERO_ORDER, shock, irr, qbas, &x1, &x2) ;
            opt->e += 2.0 * size ;
            phi = NormDist_Premium(opt, f, s_f, adj, vol, dfix, disc, 
                       KEY_STRIKE, ZERO_ORDER, shock, irr, qbas, &x1, &x2) ;

            opt->e -= size ;
            break ;

        default:
            ;
    }

    if (wrt == KEY_MATURITY && fabs(size) > SHOCK_TOL)
        *dp = (plo - p) / size ;
    else if (wrt == KEY_PROB)
        *dp = N1 ;
    else if (fabs(size) > SHOCK_TOL)
        *dp = (phi - plo) / (2.0 * size) ;

    if (risk == SECOND_ORDER && wrt != KEY_MATURITY)
    {
        if (wrt == KEY_PROB && fabs(size) > SHOCK_TOL)
            *ddp = (N1m - N1) / size ;
        else if (fabs(size) > SHOCK_TOL)
            *ddp = (phi + plo - 2.0 * p) / SQR(size) ;
    }

    return p ;
}


/*,,SOH,,
************************************************************************
*
*                Set_OPTFUT()
*
*   interface    #include <option.h>
*                OPTFUT Set_OPTFUT(OPTTYPE     type,
*                                  FL64        strike,
*                                  DATESTR*    dfix,
*                                  DATESTR*    dpay,
*                                  PREMIUMTYPE ptype,
*                                  CALCONV     cal) ;
*
*   general      This routine sets the members of the struct defined
*                in the function name. The pointer members are simply
*                assigned - without physical copying. The intention
*                of the Set_*() routines is that by using this
*                functionality, one avoids setting individual members
*                of structs in the application code.
*
*                When new members are inserted in structs the Set_*()
*                routine will be changed accordingly.
*
*                One exception to this principle applies. Whenever
*                OPTADD and vanilla members are used, only the
*                vanilla members are set in the Set_*() routines. The
*                non-vanilla and exotic members are set to defaults,
*                and must be set elsewhere - if needed.
*
*                For details on the interpretation of the individual
*                struct members please check the struct definition.
*
*   input        OPTTYPE     type   See general section.
*
*                FL64        strike See general section.
*
*                DATESTR*    dfix   See general section.
*
*                DATESTR*    dpay   See general section.
*
*                PREMIUMTYPE ptype  See general section.
*
*                CALCONV     cal    See general section.
*
*   output
*
*   returns      The filled out OPTFUT struct
*
*   diagnostics
*
*   see also     OPTFUT
*
************************************************************************
,,EOH,,*/

OPTFUT Set_OPTFUT(OPTTYPE type, FL64 strike, DATESTR* dfix,
                         DATESTR* dpay, PREMIUMTYPE ptype, CALCONV cal)
{
    OPTFUT opt ;

    opt.type   = type ;
    opt.strike = strike ;
    opt.dfix   = *dfix ;
    opt.dpay   = *dpay ;
    opt.ptype  = ptype ;
    opt.cal    = cal ;

    opt.oadd   = NO_OPTADD ;

    return opt ;
}


/*
..
*/

OPTINT optfut_set_OPTINT(DATESTR* analys, DATESTR* vold, OPTFUT* optf, 
                            FL64  vol, HOLI_STR *  holi)
{
  OPTINT  opt ;
  DATESTR df, dp ;
  FL64 bshift, sb, slb, sub  ;

  opt.analys  = *analys ;
  opt.voldate = *vold ;

  df = Cldr_NextBusinessDate(&optf->dfix, holi) ;
  dp = Cldr_NextBusinessDate(&optf->dpay, holi) ;

  opt.type  = optf->type ;
  opt.e     = optf->strike ;
  /* PMSTA-22396 - SRIDHARA � 160502 */
  opt.tvol  = Cldr_TermBetweenDates(vold, &df, 0, optf->cal, LAST, holi) ;
  opt.tfix  = Cldr_TermBetweenDates(analys, &df, 0, optf->cal, LAST, holi);
  opt.t     = Cldr_TermBetweenDates(analys, &dp, 0, optf->cal, LAST, holi);
  opt.ptype = optf->ptype ;
  opt.cal   = optf->cal ;

  opt.oadd  = optf->oadd ;

  switch (opt.oadd)
  {
      case NO_OPTADD:
          break ;

      case CHOOSER:
          dp = Cldr_NextBusinessDate(&optf->chos.dchoose, holi) ;
          opt.chos = Set_CHOOSERINF(&dp) ;
          break ;

      case LOOKBACK:
          opt.lbi = Set_LOOKBACKINF(optf->lbi.xtrem, optf->lbi.lbrate) ;
          break ;

      case BARRIER:
          /* deal with discretely monitored barriers */
          if (optf->barr.monit.num != 0)
          {
            /* shift factor for an UP barrier */
            bshift = optint_DiscBarrShiftFac(vold, &df, &optf->barr.monit,
                                 vol, opt.tfix, optf->cal, holi) ;
            if (optf->barr.btype == DOWN_IN || optf->barr.btype == DOWN_OUT)
              bshift = 1.0 / bshift ;
          }
          else
            bshift = 1.0 ;

          /* shift barrier */
          sb = optf->barr.barrier * bshift ;

          opt.barr = Set_BARRIERINF(optf->barr.btype, sb,
                                    optf->barr.rebate, optf->barr.phit,
                                    &optf->barr.poff, &optf->barr.monit) ;
          break ;

      case ASIAN:
          df = Cldr_NextBusinessDate(&optf->asian.davg1, holi) ;
          dp = Cldr_NextBusinessDate(&optf->asian.davgN, holi) ;
          opt.asian = Set_ASIANINF(&df, &dp, optf->asian.num_avg,
                                   optf->asian.curr_avg, optf->asian.avgrt,
                                   optf->asian.last_avg) ;
          break ;

      case TOUCHDIG:
          opt.tdi = Set_TOUCHDIGINF(optf->tdi.btype, optf->tdi.barrier,
                                    optf->tdi.phit, &optf->tdi.poff) ;
          break ;

      case BINARY:
          opt.bini = Set_BINARYINF(&optf->bini.poff,
                                   optf->bini.dcadj) ;
          break ;

      case CONTPREM:
          opt.ctp = Set_CONTPREMINF(optf->ctp.prem) ;
          break ;

      case COMPOPT:
          dp = Cldr_NextBusinessDate(&optf->compo.matur, holi) ;
          opt.compo = Set_COMPOPTINF(optf->compo.type, &dp,
                                     optf->compo.strike) ;
          break ;

      case DOUBLKO:
          /* deal with discretely monitored barriers */
          if (optf->dko.monit.num != 0)
            /* shift factor for an UP barrier */
            bshift = optint_DiscBarrShiftFac(vold, &df, &optf->dko.monit,
                                 vol, opt.tfix, optf->cal, holi) ;
          else
            bshift = 1.0 ;
          /* shift barriers */
          slb = optf->dko.b1 / bshift;
          sub = optf->dko.b2 * bshift;

          opt.dko = Set_DOUBLKOINF(slb, sub, &optf->dko.monit, &optf->dko.poff,
                  optf->dko.rebates, optf->dko.r1, optf->dko.phit1, 
                  optf->dko.r2, optf->dko.phit2) ;
          break ;
   
      case LADDER:
          opt.lad = optf->lad ;
          break ;

      case TSWITCH:
          df = Cldr_NextBusinessDate(&optf->tswi.dobs1, holi) ;
          dp = Cldr_NextBusinessDate(&optf->tswi.dobsN, holi) ;
          opt.tswi = Set_TSWITCHINF(&df, &dp, optf->tswi.num_obs,
                                   optf->tswi.level,
                                   optf->tswi.step_strike,
                                   optf->tswi.curr_pay) ;
          break ;

      case CORRIDOR:
          df = Cldr_NextBusinessDate(&optf->cor.dobs1, holi) ;
          dp = Cldr_NextBusinessDate(&optf->cor.dobsN, holi) ;
          opt.cor = Set_CORRIDORINF(&df, &dp, optf->cor.num_obs,
                               optf->cor.upper,optf->cor.lower, 
                               optf->cor.ustep_strike,
                               optf->cor.lstep_strike,
                               optf->cor.curr_pay) ;
          break ;          

      default:
          ;
  }

  return opt ;
}


/*,,SOH,,
************************************************************************
*
*                Set_PAYOFFINF()
*
*   interface    #include <option.h>
*                PAYOFFINF Set_PAYOFFINF(PAYOFF poff,
*                                        FL64   gap,
*                                        FL64   scale) ;
*
*   general      This routine sets the members of the struct defined
*                in the function name. The pointer members are simply
*                assigned - without physical copying. The intention
*                of the Set_*() routines is that by using this
*                functionality, one avoids setting individual members
*                of structs in the application code.
*
*                When new members are inserted in structs the Set_*()
*                routine will be changed accordingly.
*
*                One exception to this principle applies. Whenever
*                OPTADD and vanilla members are used, only the
*                vanilla members are set in the Set_*() routines. The
*                non-vanilla and exotic members are set to defaults,
*                and must be set elsewhere - if needed.
*
*                For details on the interpretation of the individual
*                struct members please check the struct definition.
*
*   input        PAYOFF poff  See general section.
*
*                FL64   gap   See general section.
*
*                FL64   scale See general section.
*
*   output
*
*   returns      The filled out PAYOFFINF struct
*
*   diagnostics
*
*   see also     PAYOFFINF
*
************************************************************************
,,EOH,,*/

PAYOFFINF Set_PAYOFFINF(PAYOFF poff, FL64 gap, FL64 scale)
{
    PAYOFFINF bini ;

    bini.poff  = poff ;
    bini.scale = scale ;
    bini.gap   = gap ;

    return bini ;
}


/*,,SOH,,
************************************************************************
*
*                Set_BARRIERINF()
*
*   interface    #include <option.h>
*                BARRIERINF Set_BARRIERINF(KNOCKTYPE  btype,
*                                          FL64       barrier,
*                                          FL64       rebate,
*                                          BOOLE      phit,
*                                          PAYOFFINF* poff,
*                                          PERIOD*    monit) ;
*
*   general      This routine sets the members of the struct defined
*                in the function name. The pointer members are simply
*                assigned - without physical copying. The intention
*                of the Set_*() routines is that by using this
*                functionality, one avoids setting individual members
*                of structs in the application code.
*
*                When new members are inserted in structs the Set_*()
*                routine will be changed accordingly.
*
*                One exception to this principle applies. Whenever
*                OPTADD and vanilla members are used, only the
*                vanilla members are set in the Set_*() routines. The
*                non-vanilla and exotic members are set to defaults,
*                and must be set elsewhere - if needed.
*
*                For details on the interpretation of the individual
*                struct members please check the struct definition.
*
*   input        KNOCKTYPE  btype   See general section.
*
*                FL64       barrier See general section.
*
*                FL64       rebate  See general section.
*
*                BOOLE      phit    See general section.
*
*                PAYOFFINF* poff    See general section.
*
*                PERIOD*    monit   See general section.
*
*   output
*
*   returns      The filled out BARRIERINF struct
*
*   diagnostics
*
*   see also     BARRIERINF
*
************************************************************************
,,EOH,,*/

BARRIERINF Set_BARRIERINF(KNOCKTYPE  btype,
                             FL64       barrier,
                             FL64       rebate,
                             BOOLE      phit,
                             PAYOFFINF*  poff,
                             PERIOD*    monit)
{                            
    BARRIERINF b ;

    b.btype = btype ;
    b.barrier = barrier ;
    b.rebate = rebate ;
    b.phit = phit ;
    b.poff = *poff ;
    b.monit = *monit ;

    return b ;
}   


/*,,SOH,,
************************************************************************
*
*                Set_ASIANINF()
*
*   interface    #include <option.h>
*                ASIANINF Set_ASIANINF(DATESTR* davg1,
*                                      DATESTR* davgN,
*                                      INTI     num_avg,
*                                      FL64     curr_avg,
*                                      BOOLE    avgrt,
*                                      FL64     last_avg) ;
*
*   general      This routine sets the members of the struct defined
*                in the function name. The pointer members are simply
*                assigned - without physical copying. The intention
*                of the Set_*() routines is that by using this
*                functionality, one avoids setting individual members
*                of structs in the application code.
*
*                When new members are inserted in structs the Set_*()
*                routine will be changed accordingly.
*
*                One exception to this principle applies. Whenever
*                OPTADD and vanilla members are used, only the
*                vanilla members are set in the Set_*() routines. The
*                non-vanilla and exotic members are set to defaults,
*                and must be set elsewhere - if needed.
*
*                For details on the interpretation of the individual
*                struct members please check the struct definition.
*
*   input        DATESTR* davg1    See general section.
*
*                DATESTR* davgN    See general section.
*
*                INTI     num_avg  See general section.
*
*                FL64     curr_avg See general section.
*
*                BOOLE    avgrt    See general section.
*
*                FL64     last_avg See general section.
*
*   output
*
*   returns      The filled out ASIANINF struct
*
*   diagnostics
*
*   see also     ASIANINF
*
************************************************************************
,,EOH,,*/

ASIANINF Set_ASIANINF(DATESTR*   davg1,
                         DATESTR*   davgN,
                         INTI       num_avg,
                         FL64       curr_avg,
                         BOOLE      avgrt,
                         FL64       last_avg)
{
    ASIANINF a ;

    if (davg1 != NULL)
        a.davg1 = *davg1 ;
    else
        a.davg1 = Cldr_YMD2Datestr((YYYYMMDD) 0) ;

    if (davgN != NULL)
        a.davgN = *davgN ;
    else
        a.davgN = Cldr_YMD2Datestr((YYYYMMDD) 0) ;
    
    a.num_avg = num_avg ;
    a.curr_avg = curr_avg ;
    a.avgrt = avgrt ;
    a.last_avg = last_avg ;

    return a ;
}   


/*,,SOH,,
************************************************************************
*
*                Set_FWDSTARTINF()
*
*   interface    #include <option.h>
*                FWDSTARTINF Set_FWDSTARTINF(DATESTR* dset,
*                                            FL64     alpha) ;
*
*   general      This routine sets the members of the struct defined
*                in the function name. The pointer members are simply
*                assigned - without physical copying. The intention
*                of the Set_*() routines is that by using this
*                functionality, one avoids setting individual members
*                of structs in the application code.
*
*                When new members are inserted in structs the Set_*()
*                routine will be changed accordingly.
*
*                One exception to this principle applies. Whenever
*                OPTADD and vanilla members are used, only the
*                vanilla members are set in the Set_*() routines. The
*                non-vanilla and exotic members are set to defaults,
*                and must be set elsewhere - if needed.
*
*                For details on the interpretation of the individual
*                struct members please check the struct definition.
*
*   input        DATESTR* dset  See general section.
*
*                FL64     alpha See general section.
*
*   output
*
*   returns      The filled out FWDSTARTINF struct
*
*   diagnostics
*
*   see also     FWDSTARTINF
*
************************************************************************
,,EOH,,*/

FWDSTARTINF Set_FWDSTARTINF(DATESTR*   dset,
                               FL64     alpha)
{
    FWDSTARTINF a ;

    a.dset  = *dset ;
    a.alpha = alpha ;

    return a ;
}   


/*,,SOH,,
************************************************************************
*
*                Set_CHOOSERINF()
*
*   interface    #include <option.h>
*                CHOOSERINF Set_CHOOSERINF(DATESTR* dchoose) ;
*
*   general      This routine sets the members of the struct defined
*                in the function name. The pointer members are simply
*                assigned - without physical copying. The intention
*                of the Set_*() routines is that by using this
*                functionality, one avoids setting individual members
*                of structs in the application code.
*
*                When new members are inserted in structs the Set_*()
*                routine will be changed accordingly.
*
*                One exception to this principle applies. Whenever
*                OPTADD and vanilla members are used, only the
*                vanilla members are set in the Set_*() routines. The
*                non-vanilla and exotic members are set to defaults,
*                and must be set elsewhere - if needed.
*
*                For details on the interpretation of the individual
*                struct members please check the struct definition.
*
*   input        DATESTR* dchoose See general section.
*
*   output
*
*   returns      The filled out CHOOSERINF struct
*
*   diagnostics
*
*   see also     CHOOSERINF
*
************************************************************************
,,EOH,,*/

CHOOSERINF Set_CHOOSERINF(DATESTR*  dchoose)
{
    CHOOSERINF a ;
    
    a.dchoose = *dchoose ;

    return a ;
}   


/*,,SOH,,
************************************************************************
*
*                Set_TOUCHDIGINF()
*
*   interface    #include <option.h>
*                TOUCHDIGINF Set_TOUCHDIGINF(KNOCKTYPE  btype,
*                                            FL64       barrier,
*                                            BOOLE      phit,
*                                            PAYOFFINF* poff) ;
*
*   general      This routine sets the members of the struct defined
*                in the function name. The pointer members are simply
*                assigned - without physical copying. The intention
*                of the Set_*() routines is that by using this
*                functionality, one avoids setting individual members
*                of structs in the application code.
*
*                When new members are inserted in structs the Set_*()
*                routine will be changed accordingly.
*
*                One exception to this principle applies. Whenever
*                OPTADD and vanilla members are used, only the
*                vanilla members are set in the Set_*() routines. The
*                non-vanilla and exotic members are set to defaults,
*                and must be set elsewhere - if needed.
*
*                For details on the interpretation of the individual
*                struct members please check the struct definition.
*
*   input        KNOCKTYPE  btype   See general section.
*
*                FL64       barrier See general section.
*
*                BOOLE      phit    See general section.
*
*                PAYOFFINF* poff    See general section.
*
*   output
*
*   returns      The filled out TOUCHDIGINF struct
*
*   diagnostics
*
*   see also     TOUCHDIGINF
*
************************************************************************
,,EOH,,*/

TOUCHDIGINF Set_TOUCHDIGINF(KNOCKTYPE   btype,
                               FL64        barrier,
                               BOOLE       phit,
                               PAYOFFINF*  poff)
{
    TOUCHDIGINF  a ;
        
    a.btype = btype ;
    a.barrier = barrier ;
    a.phit = phit ;
    a.poff = *poff ;

    return a ;
}   


/*,,SOH,,
************************************************************************
*
*                Set_LOOKBACKINF()
*
*   interface    #include <option.h>
*                LOOKBACKINF Set_LOOKBACKINF(FL64  xtrem,
*                                            BOOLE lbrate) ;
*
*   general      This routine sets the members of the struct defined
*                in the function name. The pointer members are simply
*                assigned - without physical copying. The intention
*                of the Set_*() routines is that by using this
*                functionality, one avoids setting individual members
*                of structs in the application code.
*
*                When new members are inserted in structs the Set_*()
*                routine will be changed accordingly.
*
*                One exception to this principle applies. Whenever
*                OPTADD and vanilla members are used, only the
*                vanilla members are set in the Set_*() routines. The
*                non-vanilla and exotic members are set to defaults,
*                and must be set elsewhere - if needed.
*
*                For details on the interpretation of the individual
*                struct members please check the struct definition.
*
*   input        FL64  xtrem  See general section.
*
*                BOOLE lbrate See general section.
*
*   output
*
*   returns      The filled out LOOKBACKINF struct
*
*   diagnostics
*
*   see also     LOOKBACKINF
*
************************************************************************
,,EOH,,*/

LOOKBACKINF Set_LOOKBACKINF(FL64   xtrem,
                               BOOLE  lbrate)
{
    LOOKBACKINF a ;

    a.xtrem  = xtrem ;
    a.lbrate = lbrate ;

    return a ;
} 


/*,,SOH,,
************************************************************************
*
*                Set_BINARYINF()
*
*   interface    #include <option.h>
*                BINARYINF Set_BINARYINF(PAYOFFINF* poff,
*                                        BOOLE      dcadj) ;
*
*   general      This routine sets the members of the struct defined
*                in the function name. The pointer members are simply
*                assigned - without physical copying. The intention
*                of the Set_*() routines is that by using this
*                functionality, one avoids setting individual members
*                of structs in the application code.
*
*                When new members are inserted in structs the Set_*()
*                routine will be changed accordingly.
*
*                One exception to this principle applies. Whenever
*                OPTADD and vanilla members are used, only the
*                vanilla members are set in the Set_*() routines. The
*                non-vanilla and exotic members are set to defaults,
*                and must be set elsewhere - if needed.
*
*                For details on the interpretation of the individual
*                struct members please check the struct definition.
*
*   input        PAYOFFINF* poff  See general section.
*
*                BOOLE      dcadj See general section.
*
*   output
*
*   returns      The filled out BINARYINF struct
*
*   diagnostics
*
*   see also     BINARYINF
*
************************************************************************
,,EOH,,*/

BINARYINF Set_BINARYINF(PAYOFFINF*  poff, BOOLE  dcadj)
{
    BINARYINF a ;

    a.poff = *poff ;
    a.dcadj = dcadj;

    return a ;
} 

  
/*,,SOH,,
************************************************************************
*
*                Set_CONTPREMINF()
*
*   interface    #include <option.h>
*                CONTPREMINF Set_CONTPREMINF(FL64 prem) ;
*
*   general      This routine sets the members of the struct defined
*                in the function name. The pointer members are simply
*                assigned - without physical copying. The intention
*                of the Set_*() routines is that by using this
*                functionality, one avoids setting individual members
*                of structs in the application code.
*
*                When new members are inserted in structs the Set_*()
*                routine will be changed accordingly.
*
*                One exception to this principle applies. Whenever
*                OPTADD and vanilla members are used, only the
*                vanilla members are set in the Set_*() routines. The
*                non-vanilla and exotic members are set to defaults,
*                and must be set elsewhere - if needed.
*
*                For details on the interpretation of the individual
*                struct members please check the struct definition.
*
*   input        FL64 prem See general section.
*
*   output
*
*   returns      The filled out CONTPREMINF struct
*
*   diagnostics
*
*   see also     CONTPREMINF
*
************************************************************************
,,EOH,,*/

CONTPREMINF Set_CONTPREMINF(FL64  prem)
{
    CONTPREMINF a ; 

    a.prem = prem ;

    return a ;
}   


/*,,SOH,,
************************************************************************
*
*                Set_COMPOPTINF()
*
*   interface    #include <option.h>
*                COMPOPTINF Set_COMPOPTINF(OPTTYPE  type,
*                                          DATESTR* matur,
*                                          FL64     strike) ;
*
*   general      This routine sets the members of the struct defined
*                in the function name. The pointer members are simply
*                assigned - without physical copying. The intention
*                of the Set_*() routines is that by using this
*                functionality, one avoids setting individual members
*                of structs in the application code.
*
*                When new members are inserted in structs the Set_*()
*                routine will be changed accordingly.
*
*                One exception to this principle applies. Whenever
*                OPTADD and vanilla members are used, only the
*                vanilla members are set in the Set_*() routines. The
*                non-vanilla and exotic members are set to defaults,
*                and must be set elsewhere - if needed.
*
*                For details on the interpretation of the individual
*                struct members please check the struct definition.
*
*   input        OPTTYPE  type   See general section.
*
*                DATESTR* matur  See general section.
*
*                FL64     strike See general section.
*
*   output
*
*   returns      The filled out COMPOPTINF struct
*
*   diagnostics
*
*   see also     COMPOPTINF
*
************************************************************************
,,EOH,,*/

COMPOPTINF Set_COMPOPTINF(OPTTYPE   type,
                             DATESTR*  matur,
                             FL64      strike)
{
    COMPOPTINF a ;

    a.type = type ;
    a.matur = *matur ;
    a.strike = strike ;

    return a ;
}   


/*,,SOH,,
************************************************************************
*
*                Set_DOUBLKOINF()
*
*   interface    #include <option.h>
*                DOUBLKOINF Set_DOUBLKOINF(FL64 b1,
*                                          FL64 b2,
*                                          PERIOD*,monit,
*                                          BOOLE,rebates,
*                                          FL64, r1,
*                                          BOOLE,phit1,
*                                          FL64, r2,
*                                          BOOLE,phit2)
*
*   general      This routine sets the members of the struct defined
*                in the function name. The pointer members are simply
*                assigned - without physical copying. The intention
*                of the Set_*() routines is that by using this
*                functionality, one avoids setting individual members
*                of structs in the application code.
*
*                If 'rebates' is 'False' the rebate info is
*                NOT set (and will NOT be accessed by the
*                supporting routines)
*
*                When new members are inserted in structs the Set_*()
*                routine will be changed accordingly.
*
*                One exception to this principle applies. Whenever
*                OPTADD and vanilla members are used, only the
*                vanilla members are set in the Set_*() routines. The
*                non-vanilla and exotic members are set to defaults,
*                and must be set elsewhere - if needed.
*
*                For details on the interpretation of the individual
*                struct members please check the struct definition.
*
*   input        FL64   b1      See general section.
*
*                FL64   b2      See general section.
*
*                PERIOD*monit   See general section.
*
*                BOOLE  rebates See general section.
*
*                FL64   r1      See general section.
*
*                BOOLE  phit1   See general section.
*
*                FL64   r2      See general section.
*
*                BOOLE  phit2   See general section.
*
*   output
*
*   returns      The filled out DOUBLKOINF struct
*
*   diagnostics
*
*   see also     DOUBLKOINF
*
************************************************************************
,,EOH,,*/

DOUBLKOINF Set_DOUBLKOINF(FL64  b1,
                             FL64  b2,
                             PERIOD* monit,
                             PAYOFFINF* poff,
                             BOOLE rebates,
                             FL64  r1,
                             BOOLE phit1,
                             FL64  r2,
                             BOOLE phit2)
{
    DOUBLKOINF a ;

    a.b1 = b1 ;
    a.b2 = b2 ;
    a.monit = *monit ;
    a.poff = *poff ;
    a.rebates = rebates ;
    if (rebates) 
    {
      a.r1      = r1      ;
      a.phit1   = phit1   ;
      a.r2      = r2      ;
      a.phit2   = phit2   ;
    }
    return a ;
}    


/*,,SOH,,
************************************************************************
*
*                Set_RESETINF()
*
*   interface    #include <option.h>
*                RESETINF Set_RESETINF(FL64   spread,
*                                      INTI   nfirst,
*                                      INTI   nfreq,
*                                      BOOLE  delayfix,
*                                      FL64   spread_low,
*                                      FL64   spread_up) ;
*
*   general      This routine sets the members of the struct defined
*                in the function name. The pointer members are simply
*                assigned - without physical copying. The intention
*                of the Set_*() routines is that by using this
*                functionality, one avoids setting individual members
*                of structs in the application code.
*
*                When new members are inserted in structs the Set_*()
*                routine will be changed accordingly.
*
*                One exception to this principle applies. Whenever
*                OPTADD and vanilla members are used, only the
*                vanilla members are set in the Set_*() routines. The
*                non-vanilla and exotic members are set to defaults,
*                and must be set elsewhere - if needed.
*
*                For details on the interpretation of the individual
*                struct members please check the struct definition.
*
*   input        FL64  spread      See general section.
*
*                INTI  nfirst      See general section.
*
*                INTI  nfreq       See general section.
*
*                BOOLE delayfix    See general section.
*
*                FL64  spread_low  See general section.
*
*                FL64  spread_up   See general section.
*
*   output
*
*   returns      The filled out RESETINF struct
*
*   diagnostics
*
*   see also     RESETINF
*
************************************************************************
,,EOH,,*/

RESETINF Set_RESETINF(FL64     spread,
                         INTI     nfirst,
                         INTI     nfreq,
                         BOOLE    delayfix,
                         FL64     spread_low,
                         FL64     spread_up)
{
    RESETINF a;
    
    a.spread     = spread ;
    a.nfirst     = nfirst ;
    a.nfreq      = nfreq ;
    a.delayfix   = delayfix ;
    a.spread_low = spread_low ;
    a.spread_up  = spread_up ;

    return a ;
}   


/*,,SOH,,
************************************************************************
*
*                Set_SHARKFININF()
*
*   interface    #include <option.h>
*                SHARKFININF Set_SHARKFININF(KNOCKTYPE  btype,
*                                            FL64       barrier,
*                                            FL64       rebate,
*                                            PAYOFFINF* poff) ;
*
*   general      This routine sets the members of the struct defined
*                in the function name. The pointer members are simply
*                assigned - without physical copying. The intention
*                of the Set_*() routines is that by using this
*                functionality, one avoids setting individual members
*                of structs in the application code.
*
*                When new members are inserted in structs the Set_*()
*                routine will be changed accordingly.
*
*                For details on the interpretation of the individual
*                struct members please check the struct definition.
*
*   input        KNOCKTYPE  btype   See general section.
*
*                FL64       barrier See general section.
*
*                FL64       rebate  See general section.
*
*                PAYOFFINF* poff    See general section.
*
*   output
*
*   returns      The filled out SHARKFININF struct
*
*   diagnostics
*
*   see also     SHARKFININF
*
************************************************************************
,,EOH,,*/

SHARKFININF Set_SHARKFININF(KNOCKTYPE  btype,
                                FL64       barrier,
                                FL64       rebate,
                                PAYOFFINF*  poff)
{
    SHARKFININF b ;

    b.btype = btype ;
    b.barrier = barrier ;
    b.rebate = rebate ;
    b.poff = *poff ;

    return b ;
}   


/*,,SOH,,
************************************************************************
*
*                Set_LADDERINF()
*
*   interface    #include <option.h>
*                LADDERINF Set_LADDERINF( FL64ARRAY levels ,
*                                         INTI      nlevels ) ;
*
*   general      This routine sets the members of the struct defined
*                in the function name. The pointer members are simply
*                assigned - without physical copying. The intention
*                of the Set_*() routines is that by using this
*                functionality, one avoids setting individual members
*                of structs in the application code.
*
*                When new members are inserted in structs the Set_*()
*                routine will be changed accordingly.
*
*                For details on the interpretation of the individual
*                struct members please check the struct definition.
*
*   input        FL64ARRAY  levels  See general section.
*
*                INTI       nlevels See general section.
*
*   output
*
*   returns      The filled out LADDERINF struct
*
*   diagnostics
*
*   see also     LADDERINF
*
************************************************************************
,,EOH,,*/

LADDERINF Set_LADDERINF(FL64ARRAY  levels,
                            INTI  nlevels) 
{
    LADDERINF b ;

    b.levels = levels ;
    b.nlevels = nlevels ;

    return b ;
}   

/*,,SOH,,
************************************************************************
*
*                Set_TSWITCHINF()
*
*   interface    #include <option.h>
*                TSWITCHINF Set_TSWITCHINF (DATESTR*  dobs1 ,
*                                           DATESTR*  dobsN ,
*                                           INTI      num_obs ,
*                                           FL64      level ,
*                                           PLAN_STR* step_strike ,
*                                           FL64      curr_pay) ;
*
*   general      This routine sets the members of the struct defined
*                in the function name. The pointer members are simply
*                assigned - without physical copying. The intention
*                of the Set_*() routines is that by using this
*                functionality, one avoids setting individual members
*                of structs in the application code.
*
*                When new members are inserted in structs the Set_*()
*                routine will be changed accordingly.
*
*                For details on the interpretation of the individual
*                struct members please check the struct definition.
*
*   input        DATESTR      dobs1 See general section.
*
*                DATESTR      dobsN See general section.
*
*                INTI         num_obs See general section.
*
*                FL64         level See general section.
*
*                PLAN_STR     step_strike See general section.
*
*                FL64         curr_pay See general section.
*
*   output
*
*   returns      The filled out TSWITCHINF struct
*
*   diagnostics
*
*   see also     TSWITCHINF
*
************************************************************************
,,EOH,,*/

TSWITCHINF Set_TSWITCHINF(DATESTR*  dobs1 ,
                             DATESTR*  dobsN ,
                             INTI  num_obs ,
                             FL64  level ,
                             PLAN_STR*  step_strike ,
                             FL64  curr_pay) 
{
    TSWITCHINF b ;

    b.dobs1 = *dobs1 ;
    b.dobsN = *dobsN ;
    b.num_obs = num_obs;
    b.level = level ;
    b.step_strike = step_strike ;
    b.curr_pay = curr_pay; 

    return b ;
}   

/*,,SOH,,
************************************************************************
*
*                Set_CORRIDORINF()
*
*   interface    #include <option.h>
*                CORRIDORINF Set_CORRIDORINF (DATESTR*  dobs1 ,
*                                             DATESTR*  dobsN ,
*                                             INTI      num_obs ,
*                                             FL64      upper ,
*                                             FL64      lower , 
*                                             PLAN_STR* ustep_strike ,
*                                             PLAN_STR* lstep_strike ,
*                                             FL64      curr_pay) ;
*
*   general      This routine sets the members of the struct defined
*                in the function name. The pointer members are simply
*                assigned - without physical copying. The intention
*                of the Set_*() routines is that by using this
*                functionality, one avoids setting individual members
*                of structs in the application code.
*
*                When new members are inserted in structs the Set_*()
*                routine will be changed accordingly.
*
*                For details on the interpretation of the individual
*                struct members please check the struct definition.
*
*   input        DATESTR      dobs1. See general section.
*
*                DATESTR      dobsN. See general section.
*
*                INTI         num_obs. See general section.
*
*                FL64         upper. See general section.
*
*                FL64         lower. See general section.
*
*                PLAN_STR     ustep_strike. See general section. 
*
*                PLAN_STR     lstep_strike. See general section.
*
*                FL64         curr_pay. See general section.
*
*   output
*
*   returns      The filled out CORRIDORINF struct
*
*   diagnostics
*
*   see also     CORRIDORINF
*
************************************************************************
,,EOH,,*/

CORRIDORINF Set_CORRIDORINF(DATESTR*  dobs1 ,
                                DATESTR*  dobsN ,
                                INTI  num_obs ,
                                FL64  upper ,
                                FL64  lower ,                                
                                PLAN_STR*  ustep_strike ,
                                PLAN_STR*  lstep_strike ,
                                FL64  curr_pay) 
{
    CORRIDORINF b ;

    b.dobs1 = *dobs1 ;
    b.dobsN = *dobsN ;
    b.num_obs = num_obs;
    b.upper = upper ;
    b.lower = lower ;    
    b.ustep_strike = ustep_strike ;
    b.lstep_strike = lstep_strike ;
    b.curr_pay = curr_pay; 

    return b ;
}   


/*,,SOH,,
*************************************************************************
*
*               Free_OPTFUT()
*
*    interface  #include <option.h>
*               void Free_OPTFUT(OPTFUT *s) ;
*
*    general    Free_OPTFUT() frees memory for a OPTFUT
*
*    input      OPTFUT *s        Reference to the option
*
*    output
*
*    returns
*
*    diagnostics
*
*    see also   
*
*************************************************************************
,,EOH,,*/

void Free_OPTFUT(OPTFUT* s)
{
    switch (s->oadd)
    {
    case NO_OPTADD:
    case CHOOSER:
    case LOOKBACK:
    case ASIAN:
    case BARRIER:
    case FWDSTART:
    case TOUCHDIG:
    case BINARY:
    case CONTPREM:
    case COMPOPT:
    case DOUBLKO:
    case RESET:
    case SWPTBARR:
    case SHARKFIN:
    case FLEXICAP:
      break ;
    case LADDER:
      Free_FL64ARRAY(s->lad.levels);
      break ;
    case TSWITCH:
      Free_PLANARRAY(s->tswi.step_strike, 1) ;
      break ;
    case CORRIDOR:
      Free_PLANARRAY(s->cor.ustep_strike, 1) ;
      Free_PLANARRAY(s->cor.lstep_strike, 1) ;
      break ;
    }
}

#undef PAYM_TOL
#undef MAXIT
#undef SHOCKSIZE
#undef ACC_PRICE
#undef ACC_RATE
#undef MIN_VOL
#undef ACC_TERM
#undef SHOCK_TOL
#undef LOW_BOUND
#undef MIN_GRAD
#undef MAX_MIRRORS
#undef VOL_GUESS

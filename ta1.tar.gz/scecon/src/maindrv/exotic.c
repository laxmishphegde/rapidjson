/* SCID @(#)exotic.c	1.24 (SimCorp) 99/11/12 14:36:53 */

/************************************************************************
*
*   project     SCecon
*
*   filename    exotic.c
*
*   contains    routines in the SCecon options library.
*
************************************************************************/

/***** includes ********************************************************/
#include <option.h>


/***** defines  ********************************************************/
#define PAYM_TOL    1.0E-10
#define MIN_VOL     0.00001
#define MIN_DRIFT   0.000001
#define MIN_EXERCISE 1.0E-13
#define MAX_MIRRORS 1000
#define SQRT_TWO 1.414213562373095049


/*
..f  is spot
..ff is forward
..no discounting till today
*/


FL64 Option_Lookback(FL64 f, OPTINT* opt, FL64 adj, FL64 dfix, FL64 vol,
                     FL64 ff)
{
    BOOLE ok, div0 ;
    FL64  kb, E, k, tau, p, M, b, d, r, v, mu, lbd, d1, d2, d3, tmp ;

    /* warning avoidance */
    p = tmp = lbd = b = 0.0 ;

    ok = True ;
    v  = vol / 100.0 ;
    if (fabs(opt->tvol) < 0.001 || vol < MIN_VOL || f < PAYM_TOL)
        return 0.0 ;

    if (opt->lbi.lbrate == False)
    {
        /* Price Strike Lookback Options using Rubinstein */
        if (opt->type == CALL)
        {
            if (opt->lbi.xtrem > 0.0001)
                M = GETMIN(opt->lbi.xtrem, f) ;     /* f is UNadj. spot */
            else
                M = f ;
        }
        else
            M = GETMAX(opt->lbi.xtrem, f) ;

        if (fabs(M) > 0.00001 && f / M > 0.00001)
            b = log(f / M) ;
        else
            ok = False ;

        d = TVMunit_Yield(adj, opt->tfix, COMPOUND, 1) / 100.0 ;
        r = TVMunit_Yield(dfix, opt->tvol, COMPOUND, 1) / 100.0 ;

        mu = log ((1.0 + r) / (1.0 + d)) - 0.5 * SQR(v) ;
        div0 = False ;
        if (fabs(r - d) > PAYM_TOL)
            lbd = 0.5 * SQR(v) / log ((1.0 + r) / (1.0 + d)) ;
        else
            div0 = True ;

        d1 = (b + mu * opt->tvol) / (v * sqrt(opt->tvol)) ;
        d2 = (- b + mu * opt->tvol) / (v * sqrt(opt->tvol)) ;
        d3 = (- b - (mu + SQR(v)) * opt->tvol) / (v * sqrt(opt->tvol)) ;

        if (div0 == False)
            tmp = GETMIN(b * (1.0 - 1.0 / lbd), log(DBL_MAX) - 1.0) ;

        /* UNDiscounted Price */
        if (opt->type == CALL && ok == True)
        {
            p = ff - M * Stat_NormalizedNormal(d1) ;
            if (div0 == False)
            {
                p += M * lbd * exp (tmp) * Stat_NormalizedNormal(d2) ;
                p -= ff * (1.0 + lbd) * Stat_NormalizedNormal(d3) ;
            }
        }
        else if (opt->type == PUT && ok == True)
        {
            p = - ff + M * Stat_NormalizedNormal(-d1) ;
            if (div0 == False)
            {
                p -= M * lbd * exp (tmp) * Stat_NormalizedNormal(-d2) ;
                p += ff * (1.0 + lbd) * Stat_NormalizedNormal(-d3) ;
            }
        }
        else
            p = 0.0 ;
    }
    else
    {
        if (opt->e < PAYM_TOL)
            return 0.0 ;

        /* Price Strike Lookback Options - using JAS */
        if (opt->type == PUT)
        {
            if (opt->lbi.xtrem > 0.0001)
                M = GETMIN(opt->lbi.xtrem, f) ;     /* f is UNadj. spot */
            else
                M = f ;
        }
        else
            M = GETMAX(opt->lbi.xtrem, f) ;

        E   = opt->e ;
        d   = TVMunit_Yield(adj, opt->tfix, CONTINUOUS, 1) / 100.0 ;
        r   = TVMunit_Yield(dfix, opt->tvol, CONTINUOUS, 1) / 100.0 ;
        mu  = r - d - 0.5 * SQR(v) ;
        k   = 2.0 * mu / SQR(v) ;
        tau = 0.5 * SQR(v) * opt->tvol ;

        if (fabs(k + 1.0) < MIN_VOL)
            k += MIN_VOL ;

        if (opt->type == CALL && E >= M - PAYM_TOL)
        {
            b  = log(f / E) ;
            d1 = (b + (k + 2.0) * tau) / sqrt(2.0 * tau) ;
            d2 = (b + k * tau) / sqrt(2.0 * tau) ;
            d3 = (b - k * tau) / sqrt(2.0 * tau);
            kb = - k * b ;
            kb = GETMIN(25.0, kb) ;

            /* UNDiscounted Price */
            p   = - E * Stat_NormalizedNormal(d2) ;
            tmp = exp(tau * (k + 1.0)) / (k + 1.0) * (k + 2.0) * f ;
            /* 990531/PAG: This reshuffle is tried to minimize the
             * difference between optimize and without. This is
             * hopefully only a temporary pseudo-solution. The original
             * version was:
             * tmp = (k + 2.0) / (k + 1.0) * f * exp(tau * (k + 1.0)) ;
             */
            /* In a test example tmp yields different results
            when compiled in debug and optimized mode. There
            seems to be no easy work around??? MGH 27-05-99 
            printf("exp %20.18lf    f %20.18lf    kbrok %20.18lf 
            j %20.18lf ide %20.18lf", exp(tau * (k + 1.0)), f, 
            (k + 2.0) / (k + 1.0), (k + 2.0) / (k + 1.0) * f,
            (k + 2.0) * (f * exp(tau * (k + 1.0))/ (k + 1.0))) ; */
            p  += tmp * Stat_NormalizedNormal(d1) ;
            tmp = E * exp(kb) / (k + 1.0) ;
            p  -= tmp * Stat_NormalizedNormal(d3) ;
        }

        else if (opt->type == PUT && E < M - PAYM_TOL)
        {
            b  = log(f / E) ;
            d1 = (b + (k + 2.0) * tau) / sqrt(2.0 * tau) ;
            d2 = (b + k * tau) / sqrt(2.0 * tau) ;
            d3 = (b - k * tau) / sqrt(2.0 * tau);
            kb = - k * b ;
            kb = GETMIN(25.0, kb) ;

            /* UNDiscounted Price */
            p   = - E * Stat_NormalizedNormal(-d2) ;
            tmp = (k + 2.0) / (k + 1.0) * f * exp(tau * (k + 1.0)) ;
            p  += tmp * Stat_NormalizedNormal(-d1) ;
            tmp = E * exp(kb) / (k + 1.0) ;
            p  -= tmp * Stat_NormalizedNormal(-d3) ;

            p  *= -1.0 ;
        }

        else if (opt->type == CALL && E < M - PAYM_TOL)
        {
            b  = log(f / M) ;
            d1 = (-b - k * tau) / sqrt(2.0 * tau) ;
            d2 = (b - k * tau) / sqrt(2.0 * tau) ;
            d3 = (b + (k + 2.0) * tau) / sqrt(2.0 * tau) ;
            kb = - k * b ;
            kb = GETMIN(25.0, kb) ;

            /* UNDiscounted Price */
            p   = M * Stat_NormalizedNormal(d1) - E ;
            tmp = M * exp(kb) / (k + 1.0) ;
            p  -= tmp * Stat_NormalizedNormal(d2) ;
            tmp = (k + 2.0) / (k + 1.0) * f * exp(tau * (k + 1.0)) ;
            p  += tmp * Stat_NormalizedNormal(d3) ;
        }

        else if (opt->type == PUT && E >= M - PAYM_TOL)
        {
            b  = log(f / M) ;
            d1 = (-b - k * tau) / sqrt(2.0 * tau) ;
            d2 = (b - k * tau) / sqrt(2.0 * tau) ;
            d3 = (b + (k + 2.0) * tau) / sqrt(2.0 * tau) ;
            kb = - k * b ;
            kb = GETMIN(25.0, kb) ;

            /* UNDiscounted Price */
            p   = M * Stat_NormalizedNormal(-d1) - E ;
            tmp = M * exp(kb) / (k + 1.0) ;
            p  -= tmp * Stat_NormalizedNormal(-d2) ;
            tmp = (k + 2.0) / (k + 1.0) * f * exp(tau * (k + 1.0)) ;
            p  += tmp * Stat_NormalizedNormal(-d3) ;

            p *= -1.0 ;
        }
    }

    return p ;
}


/*
..
*/

FL64 Option_Chooser(OPTINT* opt, 
                       FL64    vol, 
                       FL64    ff,
					   HOLI_STR* holi)
{
    FL64 tch, tmp, p, dp1 ;

    opt->oadd = NO_OPTADD ;

    /* Premium is the sum of a call and a put with diff. maturities */
    opt->type = CALL ;
    p = Black_Premium(opt, ff, False, 1.0, vol, 1.0, 1.0, KEY_PRICE, ZERO_ORDER,
                      0.0, COMPOUND, 1, &dp1, &dp1, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */

    opt->type = PUT ;
    tmp       = opt->tvol ;
    tch       = Cldr_TermBetweenDates(&opt->voldate, &opt->chos.dchoose,
                                      0, opt->cal, LAST, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
    opt->tvol = tch ;

    if (tch > -0.001)
        p += Black_Premium(opt, ff, False, 1.0, vol, 1.0, 1.0, KEY_PRICE,
                           ZERO_ORDER, 0.0, COMPOUND, 1, &dp1, &dp1, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
    else
        p = 0.0 ;

    /* Set values back */
    opt->tvol = tmp ;
    opt->oadd = CHOOSER ;

    return p ;
}

/*
Consider a call ladder with 1 rung. This option can be
replicated by one regular call option and two up
knock-in put options both with the barrier level set equal
to the rung level. The first knock-in option should have
a strike level equal to the strike level of the regular
call option whereas the second should have a strike level
equal to the run level. The strike of the regular option
is the strike of the ladder option. See the documentation
working paper for further details.

The function can handle put and call ladder options with
an arbitrary number of rungs.
*/


FL64 Option_Ladder(OPTINT* opt, FL64 f, BOOLE s_f, FL64 adj, FL64 vol, 
                       FL64 forw, FL64  dfix, FL64 disc, HOLI_STR* holi)
                     
{
  OPTINT regular, putcall_a, putcall_b;
  PAYOFFINF poff;
  PERIOD   monit;
  FL64  dp1, ddp1, p;
  INTI  i;

  poff = Set_PAYOFFINF(OP_VANILLA, 0.0, 0.0);
  monit = Set_PERIOD(0, DAYS);

  regular = putcall_a = putcall_b = *opt;
  /* For the regular option */
  regular.oadd = NO_OPTADD;
  p  = Black_Premium(&regular, f, s_f, adj, vol, dfix, disc,
                     KEY_PRICE, ZERO_ORDER, 0.0, SIMPLE_MM, 1, &dp1, &ddp1, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
  /* The function is supposed to return a premium as if the option was paid
     by margin - not up front.
  */
  if (opt->ptype != BY_MARGIN)
      p /= disc ;
  /* What does "paying by margin" on ladder really mean???? */
  putcall_a.oadd = putcall_b.oadd = BARRIER;
  putcall_a.e = opt->e;

  if (opt->type == PUT)
  {
    putcall_a.type = putcall_b.type  = CALL;
    putcall_a.barr = putcall_b.barr = Set_BARRIERINF(DOWN_IN, 
                     opt->lad.levels[0], 0.0, False, &poff, &monit) ;
  }
  else
  {
    putcall_a.type = putcall_b.type = PUT;
    putcall_a.barr = putcall_b.barr = Set_BARRIERINF(UP_IN, 
                     opt->lad.levels[0], 0.0, False, &poff, &monit) ;
  }

  /* For the knock-ins */
  for (i = 0; i < opt->lad.nlevels; i++)
  {
    putcall_b.e = putcall_a.e ;
    putcall_a.e = opt->lad.levels[i];
    putcall_a.barr.barrier = putcall_b.barr.barrier = opt->lad.levels[i];

	/* PMSTA-22396 - SRIDHARA � 160502 */
    p += Option_Barrier(&putcall_a, f, s_f, adj, vol, forw, dfix, disc, holi) ;
    p -= Option_Barrier(&putcall_b, f, s_f, adj, vol, forw, dfix, disc, holi) ;
  } 

  return p ;
}



/*
Returns the premium of a time switch option per one unit notional. 
Automatic calculation of pay-off earned when priced after effective 
date could be considered in the future. Should probably be extended 
with a volatility structure. See also MGH-98-10 Exotic Options.
*/

FL64 Option_Tswitch(OPTINT* opt, FL64 f, FL64 adj, 
                       FL64 vol, FL64 dfix, HOLI_STR* holi)
{
    FL64  p, N, d, r, sigm, mu, lf, dt, t1, ti, d1, strike ;
    INTI  n, i, ix, m;
    DATESTR date;

    m = 0;
    p = 0.0 ;                 
    n = opt->tswi.num_obs ;  
    N = (FL64) n ;

    d = TVMunit_Yield(adj, opt->tfix, CONTINUOUS, 1) / 100.0 ;
    r = TVMunit_Yield(dfix, opt->tvol, CONTINUOUS, 1) / 100.0 ;

    /* Safety first */
    if (d < 0.0 || r <= 0.0001 || n <= 0 || f <= 0.0001)
      return 0.0 ;
    
    sigm = GETMAX(vol/100.0, MIN_VOL) ;
    mu = r - d - 0.5 * sigm * sigm ;
    lf = log(f);

    /* dt: period between observations
       t1: period between first obs. and vol date */

    if (n > 1)
      dt = GETMAX(Cldr_TermBetweenDates(&opt->tswi.dobs1, 
                  &opt->tswi.dobsN, 0, opt->cal, LAST, holi) /    /* PMSTA-22396 - SRIDHARA � 160502 */
                  (N - 1.0), 0.0) ;
    else
      dt = 1.0 ;

    t1 = opt->tvol - (N - 1.0) * dt ; 

    /* Has the option started to accumulate pay-off yet? 
       m: # of past obs. 
       n: # of remain. obs. 
       ti: time till next obs. rel. to vol date */

    if (t1 < -0.001)
    {
      m = ((INTI) (- t1 / dt) ) + 1 ;
      n = n - m ;
      p = opt->tswi.curr_pay ;
      t1 = GETMAX(dt * (FL64)(m) + t1, 0.0) ;
    }
    else
      t1 = GETMAX(t1, 0.0);

    for (i = 0; i < n; i++)
    {
      ti = t1 + i * dt ;  
      date = Cldr_Term2Date(&opt->tswi.dobs1, (i + m) * dt, YEARS, 
                            opt->cal, LAST) ;
      ix = 0;
      strike = Cldr_PlanLookup(opt->e, opt->tswi.step_strike,
                               &date, &ix);
      d1 = (lf - log(strike) + mu*ti)/(sigm*sqrt(ti));
      p += Stat_NormalizedNormal(d1) ;
    }
    /* Discounting back to analysis date - again playing safe */
    p = GETMAX(0.0, p * dt) ;
    return p ;
}


/*
Returns the premium of a corridor option per one unit notional. Automatic 
calculation of pay-off earned when priced after effective date could be 
considered in the future. See also MGH-98-10 Exotic Options.
*/

FL64 Option_Corridor(OPTINT* opt, FL64 f, FL64 adj, FL64 vol, 
                        FL64 dfix, HOLI_STR* holi)
{
    TSWITCHINF tswi_upper, tswi_lower ;
    OPTINT opt_lower, opt_upper ;
    FL64 p ;

    p = 0.0 ;
    opt_lower = opt_upper = *opt ;

    /* Safety first */
    if (opt->cor.upper < opt->cor.lower || 
        opt->cor.lower < 0.001 || f <= 0.0001)
    return 0.0 ;

    tswi_upper = Set_TSWITCHINF(&opt->cor.dobs1, &opt->cor.dobsN,
                opt->cor.num_obs, opt->cor.upper, 
                opt->cor.ustep_strike, opt->cor.curr_pay) ;
    tswi_lower = Set_TSWITCHINF(&opt->cor.dobs1, &opt->cor.dobsN,
                opt->cor.num_obs, opt->cor.lower,
                opt->cor.lstep_strike, opt->cor.curr_pay) ;
    opt_lower.tswi = tswi_lower ;
    opt_upper.tswi = tswi_upper ;
    opt_lower.oadd = opt_upper.oadd = TSWITCH ;

	/* PMSTA-22396 - SRIDHARA � 160502 */
    p = Option_Tswitch(&opt_lower, f, adj, vol, dfix, holi) -
        Option_Tswitch(&opt_upper, f, adj, vol, dfix, holi) ;
    return p ;
}


/*
..spot is UNadjusted
*/
/* Call this function ONLY when opt->barr.poff.poff is OP_VANILLA!
For OP_GAP, OP_BINARY, and OP_ASSETON use Option_Barrier_dig() */

FL64 Option_Barrier(OPTINT* opt, FL64 spot, BOOLE s_f, FL64 adj, FL64 vol,
                    FL64 forw, FL64 dfix, FL64 disc, HOLI_STR* holi)
{
  FL64    y1, y, mu, lambda, phi, nabla, r, d, x, x1, p,
          r1, r2, r3, r4, r5, r6, S, H, K, R, a, b, z, tmp, v ;
  OPTTYPE type ;

  p    = 0.0 ;
  S    = spot ;
  R    = opt->barr.rebate ;
  K    = opt->e ;
  H    = opt->barr.barrier ;
  type = opt->type ;
  v    = vol / 100.0 ;

  /* Initialisation */
  d = 1.0 + TVMunit_Yield(adj, opt->tfix, COMPOUND, 1) / 100.0 ;
  r = 1.0 + TVMunit_Yield(dfix, opt->tvol, COMPOUND, 1) / 100.0 ;

  /* Safety first */
  if (S <= 0.0001 || d <= 0.0001 || r <= 0.0001)
      return 0.0 ;

  phi    = (type == CALL ? 1.0 : -1.0) ;
  nabla  = (S >= H ? 1.0 : -1.0) ;
  mu     = log (r / d) - 0.5 * SQR(v) ;
  lambda = 1.0 + mu / SQR(v) ;

  /* Calculate the 6 terms of the Rubinstein formulae */

  /* r1 */
  x   = Black_d1(S, K, vol, opt->tvol, lambda) ;
  r1  = forw * Stat_NormalizedNormal(phi * x) ;
  x   = black_d2(x, vol, opt->tvol) ;
  r1 -= K * Stat_NormalizedNormal(phi * x) ;
  r1 *= phi ;

  /* r2 */
  x1  = Black_d1(S, H, vol, opt->tvol, lambda) ;
  r2  = forw * Stat_NormalizedNormal(phi * x1) ;
  x1  = black_d2(x1, vol, opt->tvol) ;
  r2 -= K * Stat_NormalizedNormal(phi * x1) ;
  r2 *= phi ;

  /* r3 */
  y   = Black_d1(H * H, S * K, vol, opt->tvol, lambda) ;
  r3  = forw * pow(H / S, 2.0 * lambda) * Stat_NormalizedNormal(nabla * y) ;
  y   = black_d2(y, vol, opt->tvol) ;
  r3 -= K * pow(H / S, 2.0 * lambda - 2.0) * Stat_NormalizedNormal(nabla * y) ;
  r3 *= phi ;

  /* r4 */
  y1  = Black_d1(H, S, vol, opt->tvol, lambda) ;
  r4  = forw * pow(H / S, 2.0 * lambda) * Stat_NormalizedNormal(nabla * y1) ;
  y1  = black_d2(y1, vol, opt->tvol) ;
  r4 -= K * pow(H / S, 2.0 * lambda - 2.0) * Stat_NormalizedNormal(nabla * y1) ;
  r4 *= phi ;

  /* r5 - IN Rebate */
  r5  = Stat_NormalizedNormal(nabla * x1) ;
  r5 -= pow(H / S, 2.0 * lambda - 2.0) * Stat_NormalizedNormal(nabla * y1) ;
  r5 *= R ;

  /* r6 - OUT Rebate if paid at hit */
  a   = mu / SQR(v) ;
  b   = sqrt(SQR(mu) + 2.0 * log(r) * SQR(v)) / SQR(v) ;
  z   = Black_d1(H, S, vol, opt->tvol, b) ;
  r6  = pow(H / S, a + b) * Stat_NormalizedNormal(nabla * z) ;
  z  -= 2.0 * b * v * sqrt(opt->tvol) ;
  r6 += pow(H / S, a - b) * Stat_NormalizedNormal(nabla * z) ;
  r6 *= R / disc ;

  /* OUT rebate if paid at expiry */
  if (opt->barr.phit == False)
    r6 = R - r5 ;

  if (opt->barr.btype == UP_IN)
  {
    if (S < H)  /* Up and in */
    {
      if (K > H)
        p = r5 + (type == CALL ? r1 : r1 - r2 + r4) ;
      else
        p = r5 + (type == CALL ? r2 - r3 + r4 : r3) ;
    }
    else
    {
      /* This is a vanilla option - since barrier breached */
      opt->oadd = NO_OPTADD ;
      p = Black_Premium(opt, spot, s_f, adj, vol, dfix, 1.0, KEY_PRICE,
                        ZERO_ORDER, 0.0, COMPOUND, 1, &tmp, &tmp, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
      opt->oadd = BARRIER ;
    }
  }

  else if (opt->barr.btype == UP_OUT)
  {
    if (S < H)  /* Up and out */
    {
      if (K > H)
        p = r6 + (type == CALL ? 0.0 : r2 - r4) ;
      else
        p = r6 + (type == CALL ? r1 - r2 + r3 - r4 : r1 - r3) ;
    }
    else if (opt->barr.phit == False)
      p = R ;    /* rebate is due at expiry */
    else
      p = 0.0 ;  /* rebate has been received */
  }
  else if (opt->barr.btype == DOWN_IN)
  {
    if (S > H)
    {
      if (K > H)
        p = r5 + (type == CALL ? r3 : r2 - r3 + r4) ;
      else
        p = r5 + (type == CALL ? r1 - r2 + r4 : r1) ;
    }
    else
    {
      /* This is a vanilla option - since barrier breached */
      opt->oadd = NO_OPTADD ;
      p = Black_Premium(opt, spot, s_f, adj, vol, dfix, 1.0, KEY_PRICE,
                        ZERO_ORDER, 0.0, COMPOUND, 1, &tmp, &tmp, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
      opt->oadd = BARRIER ;
    }
  }
  else if (opt->barr.btype == DOWN_OUT)
  {
    if (S > H)
    {
      if (K > H)
        p = r6 + (type == CALL ? r1 - r3 : r1 - r2 + r3 - r4) ;
      else
        p = r6 + (type == CALL ? r2 - r4 : 0.0) ;
    }
    else if (opt->barr.phit == False)
      p = R ;    /* rebate is due at expiry */
    else
      p = 0.0 ;  /* rebate has been received */
  }

  return p ;
}


/*
..spot is UNadjusted
*/
/* Call this function ONLY when opt->barr.poff.poff is OP_GAP, OP_BINARY, 
or OP_ASSETON! For OP_VANILLA use Option_Barrier_dig() */

FL64 Option_Barrier_dig(OPTINT* opt, FL64 spot, BOOLE s_f, FL64 adj, 
                           FL64 vol, FL64 forw, FL64 dfix, FL64 disc, HOLI_STR* holi)
{
  FL64    y1, y, mu, lambda, phi, nabla, r, d, x, x1, barr, p,
          r1A, r1C, r2A, r2C, r3A, r3C, r4A, r4C, r6, S, H, K, R, a, b,
          scale, z, tmp, v, X, r1, r2, r3, r4, r5 ;
  OPTTYPE type ;

  /* warning avoidance */
  r1 = r2 = r3 = r4 = 0.0 ;

  if (opt->barr.poff.poff == OP_GAP)
  {
    opt->barr.poff.poff = OP_BINARY ;
    p  = Option_Barrier_dig(opt, spot, s_f, adj, vol, forw, dfix, disc, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */

    opt->barr.poff.poff  = OP_ASSETON ;
    p += Option_Barrier_dig(opt, spot, s_f, adj, vol, forw, dfix, disc, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */

    opt->barr.poff.poff = OP_GAP ;
    return p ;
  }

  p      = 0.0 ;
  S      = spot ;
  R      = opt->barr.rebate ;
  X      = opt->barr.poff.gap ;
  scale  = opt->barr.poff.scale ;
  K      = opt->e ;
  barr   = H = opt->barr.barrier ;
  type   = opt->type ;
  v      = vol / 100.0 ;

  /* Initialisation */
  d = 1.0 + TVMunit_Yield(adj, opt->tfix, COMPOUND, 1) / 100.0 ;
  r = 1.0 + TVMunit_Yield(dfix, opt->tvol, COMPOUND, 1) / 100.0 ;

  /* Safety first */
  if (S <= 0.0001 || d <= 0.0001 || r <= 0.0001)
      return 0.0 ;

  phi    = (type == CALL ? 1.0 : -1.0) ;
  nabla  = (spot >= barr ? 1.0 : -1.0) ;
  mu     = log (r / d) - 0.5 * SQR(v) ;
  lambda = 1.0 + mu / SQR(v) ;

  /* Calculate the 9 terms of the Rubinstein formulae */

  /* r1 */
  x   = Black_d1(S, K, vol, opt->tvol, lambda) ;
  r1A = scale * forw * Stat_NormalizedNormal(phi * x) ;
  x   = black_d2(x, vol, opt->tvol) ;
  r1C = X * Stat_NormalizedNormal(phi * x) ;

  /* r2 */
  x1  = Black_d1(S, H, vol, opt->tvol, lambda) ;
  r2A = scale * forw * Stat_NormalizedNormal(phi * x1) ;
  x1  = black_d2(x1, vol, opt->tvol) ;
  r2C = X * Stat_NormalizedNormal(phi * x1) ;

  /* r3 */
  y   = Black_d1(H * H, S * K, vol, opt->tvol, lambda) ;
  r3A = scale * forw * pow(H / S, 2.0 * lambda) *
        Stat_NormalizedNormal(nabla * y) ;
  y   = black_d2(y, vol, opt->tvol) ;
  r3C = X * pow(H / S, 2.0 * lambda - 2.0) * Stat_NormalizedNormal(nabla * y) ;

  /* r4 */
  y1  = Black_d1(H, S, vol, opt->tvol, lambda) ;
  r4A = scale * forw * pow(H / S, 2.0 * lambda) *
        Stat_NormalizedNormal(nabla * y1) ;
  y1  = black_d2(y1, vol, opt->tvol) ;
  r4C = X * pow(H / S, 2.0 * lambda - 2.0) * Stat_NormalizedNormal(nabla * y1) ;

  /* r5 - IN Rebate, Not in Rubinstein */
  r5  = Stat_NormalizedNormal(nabla * x1) ;
  r5 -= pow(H / S, 2.0 * lambda - 2.0) * Stat_NormalizedNormal(nabla * y1) ;
  r5 *= R ;

  /* r6 - OUT Rebate if paid at hit; extension of Rubinstein */
  a   = mu / SQR(v) ;
  b   = sqrt(SQR(mu) + 2.0 * log(r) * SQR(v)) / SQR(v) ;
  z   = Black_d1(H, S, vol, opt->tvol, b) ;
  r6  = pow(H / S, a + b) * Stat_NormalizedNormal(nabla * z) ;
  z  -= 2.0 * b * v * sqrt(opt->tvol) ;
  r6 += pow(H / S, a - b) * Stat_NormalizedNormal(nabla * z) ;
  r6 *= R / disc ;

  /* OUT rebate if paid at expiry */
  if (opt->barr.phit == False)
    r6 = R - r5 ;

  if (opt->barr.poff.poff == OP_BINARY)
  {
    r1 = r1C ;
    r2 = r2C ;
    r3 = r3C ;
    r4 = r4C ;
  }

  else if (opt->barr.poff.poff == OP_ASSETON)
  {
    r1 = r1A ;
    r2 = r2A ;
    r3 = r3A ;
    r4 = r4A ;
  }
/*
printf("%lf %lf %lf %lf %lf\n", r1, r2, r3, r4, r6) ;
*/
  if (opt->barr.btype == UP_IN)
  {
    if (S < H)  /* Up and in */
    {
      if (K > H)
        p = r5 + (type == CALL ? r1 : r1 - r2 + r4) ;
      else
        p = r5 + (type == CALL ? r2 - r3 + r4 : r3) ;
    }
    else
    {
      /* This is a non-barrier option - since already knocked in.
        Deal with pay-off characteristics */
      opt->oadd = BINARY ;
      opt->bini.poff = opt->barr.poff ;
      p = Black_Premium(opt, spot, s_f, adj, vol, dfix, 1.0, KEY_PRICE,
                        ZERO_ORDER, 0.0, COMPOUND, 1, &tmp, &tmp, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
      opt->oadd = BARRIER ;
    }
  }

  else if (opt->barr.btype == UP_OUT)
  {
    if (S < H)  /* Up and out */
    {
      if (K > H)
        p = r6 + (type == CALL ? 0.0 : r2 - r4) ;
      else
        p = r6 + (type == CALL ? r1 - r2 + r3 - r4 : r1 - r3) ;
    }
    else if (opt->barr.phit == False)
      p = R ;    /* rebate is due at expiry */
    else
      p = 0.0 ;  /* rebate has been received */
  }
  else if (opt->barr.btype == DOWN_IN)
  {
    if (S > H)
    {
      if (K > H)
        p = r5 + (type == CALL ? r3 : r2 - r3 + r4) ;
      else
        p = r5 + (type == CALL ? r1 - r2 + r4 : r1) ;
    }
    else
    {
      /* This is a non-barrier option - since already knocked in.
        Deal with pay-off characteristics */
      opt->oadd = BINARY ;
      opt->bini.poff = opt->barr.poff ;
      p = Black_Premium(opt, spot, s_f, adj, vol, dfix, 1.0, KEY_PRICE,
                        ZERO_ORDER, 0.0, COMPOUND, 1, &tmp, &tmp, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
      opt->oadd = BARRIER ;
    }
  }
  else if (opt->barr.btype == DOWN_OUT)
  {
    if (S > H)
    {
      if (K > H)
        p = r6 + (type == CALL ? r1 - r3 : r1 - r2 + r3 - r4) ;
      else
        p = r6 + (type == CALL ? r2 - r4 : 0.0) ;
    }
    else if (opt->barr.phit == False)
      p = R ;    /* rebate is due at expiry */
    else
      p = 0.0 ;  /* rebate has been received */
  }

  return p ;
}


/*
..spot is UNadjusted
*/


FL64 Option_Barrier_touch(OPTINT* opt, FL64 spot, FL64 adj, FL64 vol,
                          FL64 forw, FL64 dfix, FL64 disc, HOLI_STR* holi)
{
  FL64 y1, mu, lambda, phi, nabla, r, d, x1, p, r2A, r2C, r4A,
       r4C, r6, S, H, a, b, scale, z, v, X, r2, r4 ;

  /* warning avoidance */
  r2 = r4 = phi = 0.0 ;

  if (opt->tdi.poff.poff == OP_GAP)
  {
    opt->tdi.poff.poff = OP_BINARY ;
    p  = Option_Barrier_dig(opt, spot, True, adj, vol, forw, dfix, disc, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */

    opt->tdi.poff.poff = OP_ASSETON ;
    p += Option_Barrier_dig(opt, spot, True, adj, vol, forw, dfix, disc, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */

    opt->tdi.poff.poff = OP_GAP ;
    return p ;
  }

  p     = 0.0 ;
  S     = spot ;
  X     = opt->tdi.poff.gap ;
  scale = opt->tdi.poff.scale ;
  H     = opt->tdi.barrier ;
  v     = vol / 100.0 ;

  /* Initialisation */
  d = 1.0 + TVMunit_Yield(adj, opt->tfix, COMPOUND, 1) / 100.0 ;
  r = 1.0 + TVMunit_Yield(dfix, opt->tvol, COMPOUND, 1) / 100.0 ;

  /* Safety first */
  if (S <= 0.0001 || d <= 0.0001 || r <= 0.0001)
    return 0.0 ;

  nabla  = (S >= H ? 1.0 : -1.0) ;
  if (opt->tdi.btype == UP_IN || opt->tdi.btype == DOWN_OUT)
    phi = 1.0 ;
  else if (opt->tdi.btype == DOWN_IN || opt->tdi.btype == UP_OUT)
    phi = - 1.0 ;

  mu     = log (r / d) - 0.5 * SQR(v) ;
  lambda = 1.0 + mu / SQR(v) ;

  /* Calculate the 5 terms of the Rubinstein formulae */

  /* r2 */
  x1  = Black_d1(S, H, vol, opt->tvol, lambda) ;
  r2A = scale * forw * Stat_NormalizedNormal(phi * x1) ;
  x1  = black_d2(x1, vol, opt->tvol) ;
  r2C = X * Stat_NormalizedNormal(phi * x1) ;

  /* r4 */
  y1  = Black_d1(H, S, vol, opt->tvol, lambda) ;
  r4A = scale * forw * pow(H / S, 2.0 * lambda) *
        Stat_NormalizedNormal(nabla * y1) ;
  y1  = black_d2(y1, vol, opt->tvol) ;
  r4C = X * pow(H / S, 2.0 * lambda - 2.0) * Stat_NormalizedNormal(nabla * y1) ;

  /* r6 */
  a   = mu / SQR(v) ;
  b   = sqrt(SQR(mu) + 2.0 * log(r) * SQR(v)) / SQR(v) ;
  z   = Black_d1(H, S, vol, opt->tvol, b) ;
  r6  = pow(H / S, a + b) * Stat_NormalizedNormal(nabla * z) ;
  z  -= 2.0 * b * v * sqrt(opt->tvol) ;
  r6 += pow(H / S, a - b) * Stat_NormalizedNormal(nabla * z) ;

  if (opt->tdi.poff.poff == OP_BINARY)
  {
    r2  = r2C ;
    r4  = r4C ;
    r6 *= X / disc ;
  }

  else if (opt->tdi.poff.poff == OP_ASSETON)
  {
    r2  = r2A ;
    r4  = r4A ;
    r6 *= H / disc ;
  }
/*
printf("%lf %lf %lf\n", r2, r4, r6) ;
*/
  if (opt->tdi.btype == UP_IN)
  {
    if (S < H)
    {
      if (opt->tdi.phit == True && opt->tdi.poff.poff == OP_BINARY)
        p = r6 ;
      else if (opt->tdi.phit == True && opt->tdi.poff.poff == OP_ASSETON)
        p = r6 ;
      else if (opt->tdi.phit == False && opt->tdi.poff.poff == OP_BINARY)
        p = r2 + r4 ;
      else if (opt->tdi.phit == False && opt->tdi.poff.poff == OP_ASSETON)
        p = r2 + r4 ;
    }
    else
      /* Already expired - payout elsewhere */
      p = 0.0 ;
  }

  else if (opt->tdi.btype == UP_OUT)
  {
    if (S < H)
    {
      if (opt->tdi.phit == True && opt->tdi.poff.poff == OP_BINARY)
        p = 0.0 ;
      else if (opt->tdi.phit == True && opt->tdi.poff.poff == OP_ASSETON)
        p = 0.0 ;
      else if (opt->tdi.phit == False && opt->tdi.poff.poff == OP_BINARY)
        p = r2 - r4 ;
      else if (opt->tdi.phit == False && opt->tdi.poff.poff == OP_ASSETON)
        p = r2 - r4 ;
    }
    else
      /* This is expired - since barrier breached */
      p = 0.0 ;
  }
  else if (opt->tdi.btype == DOWN_IN)
  {
    if (S > H)
    {
      if (opt->tdi.phit == True && opt->tdi.poff.poff == OP_BINARY)
        p = r6 ;
      else if (opt->tdi.phit == True && opt->tdi.poff.poff == OP_ASSETON)
        p = r6 ;
      else if (opt->tdi.phit == False && opt->tdi.poff.poff == OP_BINARY)
        p = r2 + r4 ;
      else if (opt->tdi.phit == False && opt->tdi.poff.poff == OP_ASSETON)
        p = r2 + r4 ;
    }
    else
      /* Already expired - payout elsewhere */
      p = 0.0 ;
  }
  else if (opt->tdi.btype == DOWN_OUT)
  {
    if (S > H)
    {
      if (opt->tdi.phit == True && opt->tdi.poff.poff == OP_BINARY)
        p = 0.0 ;
      else if (opt->tdi.phit == True && opt->tdi.poff.poff == OP_ASSETON)
        p = 0.0 ;
      else if (opt->tdi.phit == False && opt->tdi.poff.poff == OP_BINARY)
        p = r2 - r4 ;
      else if (opt->tdi.phit == False && opt->tdi.poff.poff == OP_ASSETON)
        p = r2 - r4 ;
    }
    else
      /* This is expired - since barrier breached */
      p = 0.0 ;
  }

  return p ;
}


/*,,SIC,,
************************************************************************
*
*                Option_Asian()
*
*    interface   #include <option.h>
*                FL64 Option_Asian(OPTINT  *opt,
*                                  FL64    f,
*                                  BOOLE   s_f,
*                                  FL64    adj,
*                                  FL64    vol,
*                                  FL64    disc,
*                                  FL64    dfix) ;
*
*    general     The function calculates the premium of an Asian option.
*        
*                Average-rate options have payoffs as:
* 
*                CALL: max[ Avg(Si) - X, 0 ]
*                PUT:  max[ X - Avg(Si), 0 ]
*
*                Average-strike options have payoffs as:
*
*                CALL: max[ S(T) - Avg(Si), 0 ]
*                PUT:  max[ Avg(Si) - S(T) , 0 ]
*
*                where Si is the underlying variable, X is the strike and S(T) 
*                is the price at maturity.
*
*                In a 'Black-model' type of environment we use Michael 
*                Curran's approach for average-rate options (Curran: 
*                'Beyond Average Intelligence', Risk, Vol 5, No. 10, Nov 1992) 
*                and Bouaziz et.al. for average-strike options 
*                (Bouaziz, Briys, and Crouhy: 'The pricing of forward starting
*                asian options', Journal of Banking and Finance, 18, 1994). 
*                The latter approach assumes continuous averaging, whereas 
*                the former allow discrete time sampling.
*                For the put-call parity for average-rate options, we use the
*                parity from (Levy and Turnbull: 'Average Intelligence', Risk,
*                Vol 5, No. 2, Feb 1992).
*
*    input       OPTINT          *opt       The option definition.
*
*                FL64            f          The value of the underlying.
*
*                BOOLE           s_f        True if f is a spot value,
*                                           False if f is a forward value. 
*
*                FL64            adj        This is used to find the 
*                                           dividend yield.
*
*                FL64            vol        The volatility of the option.
*
*                FL64            disc       DF from analys to payout.
*
*                FL64            dfix       DF from analys till fixing.
*                                      
*    output
*
*    returns     The price of the Asian option at maturity. Discounting
*                to the valuation date must take place after calling
*                this function.
*
*    diagnostics
*
*    see also    
*
************************************************************************
,,EIC,,*/


FL64 Option_Asian(OPTINT* opt, FL64 f, BOOLE s_f, FL64 adj, FL64 vol, 
                     FL64 disc, FL64 dfix, HOLI_STR* holi)
{
    FL64  trm1, ci, sigmx2, mui, sigmi, Ehat, ti, mu, mux, A1m, S0, E, p,
          d, r, t1, d1i, lEhat, sigm, dt, I, N, lS, tmp, lE, sigmx, zeta, t2,
          mt, V, M, d1, rhat, A ;
    INTI  n1, i, n, m ;
    BOOLE seas ;

    /* warning avoidance */
    A1m = 0.0 ;

    if (opt->asian.avgrt == True)
    {
        /* Average Rate options - following Curran */
        if (f < 0.00001 || opt->e < 0.00001)
            return 0.0 ;

        if (opt->asian.num_avg <= 1)
        {
            opt->oadd = NO_OPTADD ;
            p = Black_Premium(opt, f, s_f, adj, vol, dfix, 1.0, KEY_PRICE,
                              ZERO_ORDER, 0.0, COMPOUND, 1, &tmp, &tmp, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
            opt->oadd = ASIAN ;
            return p ;
        }

        S0   = f ;                /* Spot or Forward Price */
        lS   = log(S0) ;
        E    = opt->e ;
        lE   = log(E) ;
        d    = TVMunit_Yield(adj, opt->tfix, CONTINUOUS, 1) / 100.0 ;
        r    = TVMunit_Yield(dfix, opt->tvol, CONTINUOUS, 1) / 100.0 ;
        n    = n1 = opt->asian.num_avg ;
        N    = (FL64) n ;
        sigm = vol / 100.0 ;
        dt   = Cldr_TermBetweenDates(&opt->asian.davg1, &opt->asian.davgN, 0,
                                     opt->cal, LAST, holi) / (N - 1.0) ;      /* PMSTA-22396 - SRIDHARA � 160502 */ 
        t1   = opt->tvol - (N - 1.0) * dt ;
        zeta = 0.0 ;

        seas = (t1 < -0.001 ? True : False) ;

        if (seas == True)
        {
            m    = ((INTI) (- t1 / dt) ) + 1 ;
            A1m  = opt->asian.curr_avg ;
            E    = E * ((FL64) n) / ((FL64) n - m) ;
            E    = E - ((FL64) m) / ((FL64) (n - m) ) * A1m ;

              /* Avoid taking the log of a negative number */
            if (E < MIN_EXERCISE)
              E = MIN_EXERCISE ;
            lE   = log(E) ;
            n    = n1 - m ;
            N    = (FL64) n ;
            zeta = - t1 - dt * (FL64) (m - 1) ;
        }
        else
            m = 0 ;

        mu = r - d - 0.5 * sigm * sigm ;

        if (seas == True)
        {
            mux    = lS + mu * (dt - zeta + dt * (N - 1.0) / 2.0) ;
            sigmx2 = dt - zeta + dt * (N - 1.0) * (2.0 * N - 1.0) / (6.0 * N) ;
        }
        else
        {
            mux    = lS + mu * (t1 + dt * (N - 1.0) / 2.0) ;
            sigmx2 = t1 + dt * (N - 1.0) * (2.0 * N - 1.0) / (6.0 * N) ;
        }

        sigmx2 *= SQR(sigm) ;
        if (fabs(sigmx2) < PAYM_TOL)
            return 0.0 ;

        sigmx   = sqrt(sigmx2) ;

        for (Ehat = 2.0 * E, i = 1; i <= n; i++)
        {
            I      = (FL64) i ;
            if (seas == True)
                ti = dt - zeta + (I - 1.0) * dt ;
            else
                ti = t1 + (I - 1.0) * dt ;

            ti    = GETMAX(0.0, ti) ;
            mui   = lS + mu * ti ;
            sigmi = sigm * sqrt(ti) ;

            if (seas == True)
                ci = dt - zeta + dt * (I - 1.0) * (1.0 - I / (2.0 * N)) ;
            else
                ci = t1 + dt * (I - 1.0) * (1.0 - I / (2.0 * N)) ;

            ci   *= SQR(sigm) ;
            tmp   = mui + ci * (lE - mux) / sigmx2 + 0.5 * sigmi * sigmi ;
            tmp  -= ci * ci / (2.0 * sigmx2) ;
            Ehat -= exp(tmp) / N ;
        }

        if (Ehat < PAYM_TOL)
            return 0.0 ;

        lEhat = log(Ehat) ;

        for (trm1 = 0.0, i = 1; i <= n; i++)
        {
            I = (FL64) i ;
            if (seas == True)
                ti = dt - zeta + (I - 1.0) * dt ;
            else
                ti = t1 + (I - 1.0) * dt ;

            if (seas == True)
                ci = dt - zeta + dt * (I - 1.0) * (1.0 - I / (2.0 * N)) ;
            else
                ci = t1 + dt * (I - 1.0) * (1.0 - I / (2.0 * N)) ;

            ci   *= SQR(sigm) ;
            d1i   = (mux - lEhat + ci) / sigmx ;
            trm1 += exp((r - d) * ti) * Stat_NormalizedNormal(d1i) ;
        }

        p = (S0 / N) * trm1 - E * Stat_NormalizedNormal((mux - lEhat) / sigmx)
          ;

        if (seas == True)
            p *= ((FL64) (n1 - m)) / ((FL64) n1) ;

        if (opt->type == PUT)
        {
            /* Use Average-Rate Put-Call Parity - see Levy & Turnbull
               n1 = N + 1, m = m + 1, dt = h, r - d = g in article.
               Notice that we have already checked for n1 > 1.
               Furthermore A1m = 0.0 and m = 0 if seas == False*/
          
          t2 = dt * ((FL64) (n1 - m)) ;
          if (fabs(r-d) > MIN_DRIFT)
          {
            trm1  = (S0 / ((FL64) n1)) * (1.0 - exp((r - d) * t2)) ;
            if (seas == True)
              trm1 *= exp((r - d) * (dt - zeta)) ;
            else
              trm1 *= exp((r - d) * t1) ;
            trm1 /= (1.0 - exp((r - d) * dt)) ;
          }
          else
            trm1 = S0 * ((FL64) (n1 - m)) / ((FL64) n1) ; 

          trm1 += A1m * ((FL64) m) / ((FL64) n1) ;
          trm1 -= opt->e ;
          p -= trm1 ;
        }
    }
    else
    {
        /* Average strike options - following Bouaziz et.al */
        A = Cldr_TermBetweenDates(&opt->asian.davg1, &opt->asian.davgN, 0,
                                  opt->cal, LAST, holi) ;   /* PMSTA-22396 - SRIDHARA � 160502 */
        if (A < 0.001)
            return 0.0 ;

        vol  = GETMAX(vol, MIN_VOL) ;
        d    = TVMunit_Yield(adj, opt->tfix, CONTINUOUS, 1) / 100.0 ;
        r    = TVMunit_Yield(dfix, opt->tvol, CONTINUOUS, 1) / 100.0 ;
        sigm = vol / 100.0 ;
        rhat = r - d - 0.5 * SQR(sigm) ;
        seas = ( (opt->tvol - A) < -0.001 ? True : False) ;

        /* First consider non-seasoned avg's */
        if (seas == False)
        {
            /* Price a CALL */
            d1   = sqrt(3.0) * rhat * sqrt(A) / (2.0 * sigm) ;
            p    = (rhat * A / 2.0) * Stat_NormalizedNormal(d1) ;
            tmp  = sqrt(sigm * sigm * A / (6.0 * sc_PI)) ;
            tmp *= exp(-3.0 * rhat * rhat * A / (8.0 * sigm * sigm) ) ;
            p   += tmp ;

            /* Discount till Today */
            p   *= f * exp(- r * A) ;

            /* Price a PUT */
            if (opt->type == PUT)
            {
              /* If r-d is zero, the call value equals the put value,
                 see Bouaziz et. al. eqn. 20 */
                if (fabs(r * A) > PAYM_TOL && fabs(r-d) > MIN_DRIFT)
                    p += f * ((1.0 - exp(-(r - d) * A)) / 
                    ((r - d) * A) - 1.0) ;
            }
        }
        else
        {
            t1 = opt->tvol ;        /* Remaining time */
            mt = (A - t1) * opt->asian.curr_avg / (f * A) ;
            M  = 1.0 - t1 / A + rhat * t1 - rhat * t1 * t1 / (2.0 * A) - mt ;
            V  = (t1 + t1 * t1 * t1 / (3.0 * A * A) - t1 * t1 / A) * SQR(sigm) ;
            V  = GETMAX(V, MIN_VOL) ;

            /* Price a CALL */
            p  = M * Stat_NormalizedNormal(M / sqrt(V)) ;
            p += sqrt(V / (2.0 * sc_PI)) * exp(- M * M / (2.0 * V)) ;

            /* Discount till today */
            p *= f * exp(-r * t1) ;

            /* Price a PUT */
            if (opt->type == PUT)
            {
              if (fabs(r * A) > PAYM_TOL)
              {
                if (fabs(r - d) > MIN_DRIFT)
                  p += f * ((1.0 - exp(-(r - d) * t1)) / 
                    ((r - d) * A) - 1.0) ;
                else
                  p += f * ((t1 / A) - 1.0) ;

                p += f * mt * exp(-r * t1) ;
              }
            }
        }

           /* Return UNdiscounted payoff */
        if (disc > PAYM_TOL)
          p /= disc ;
    }
       

    return p ;
}


/*
..returns payoff UNdiscounted
..later need to return an OK
*/

FL64 Option_Compound_option(OPTINT* opt, 
                               FL64 forw,     /* Forw at maturity */
                               FL64 spot,     /* Spot price */
                               FL64 vol,
                               FL64 adj,      /* Adj factor to maturity */
                               FL64 dfix,     /* DF from fixing 2 maturity */
                               FL64 disc)     /* DF from fixing 2 payday */
{
    FL64     sigma, k, K, Ft, FT, t1, t2, t3, X, x, y, S, ro, t, T, phi, nabla,
             p, b, a, r, d ;
    OPTINT   xopt ;
    OPTFUT   optf ;
    BOOLE    ok ;
    HOLI_STR holi ;
    ITERCTRL ctrl ;

    Init_ITERCTRL(&ctrl);

    holi = Set_HOLI_STR(NO_BUSADJUST, 0, NULL) ;

    K     = opt->compo.strike ;
    k     = opt->e ;
    sigma = vol / 100.0 ;
    nabla = (opt->type == CALL ? 1.0 : -1.0) ;
    phi   = (opt->compo.type == CALL ? 1.0 : -1.0) ;
    T     = opt->tvol ;
    t     = Cldr_TermBetweenDates(&opt->voldate, &opt->compo.matur,
                                  0, opt->cal, LAST, &holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */

    if (T <= t || t <= 0.001)
        return 0.0 ;

    d  = 1.0 + TVMunit_Yield(adj, opt->tfix, COMPOUND, 1) / 100.0 ;
    r  = 1.0 + TVMunit_Yield(dfix, opt->tvol, COMPOUND, 1) / 100.0 ;
    ro = sqrt(t / T) ;

    /* When calculating FT we really need the DF until time T - need not
       be flat. Also DF(div's) needed out there */
    S  = spot ;
    FT = forw ;                            /* Forward price at T */
    Ft = S * pow(r, t) / pow(d, t) ;       /* Forward price at t */

    /* Solve for X - use dummy dates, overwritten  */
    optf = Set_OPTFUT(opt->type, k, &opt->analys,
                      &opt->analys, UP_FRONT, opt->cal) ;
    xopt = optfut_set_OPTINT(&opt->analys, &opt->voldate, &optf, vol, &holi) ;

    /* Be careful about the term settings */
    xopt.t    = T - t ;
    xopt.tvol = T - t ;
    xopt.tfix = T - t ;

    ctrl.init_guess = S;
    ctrl.use_init_guess = True ;
    ctrl.lower = S / 5.0;
    ctrl.use_lower = True ;
    ctrl.upper = S * 5.0;
    ctrl.use_upper = True ;

    ctrl.maxiter = 100;
    ctrl.damp = 1.0;
    ctrl.what_acc = 0;
    ctrl.gfreq = 1;
    ctrl.bisec = 1;

    /* Here X is solved for as forward price */
    ok = Black_Implied(&xopt, K, True, S, False, pow(d, t - T), vol,
                       pow(r, t - T), pow(r, t - T), KEY_PRICE,
                       &ctrl, &X, &holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */

    if (ok == False)
        return 0.0 ;

    /* Transform X into Spot Terms */
    X *= pow(d, T - t) / pow(r, T - t) ;

    x = Black_d1(Ft, X, vol, t, 0.5) ;
    y = Black_d1(FT, k, vol, T, 0.5) ;

    /* Find the 3 terms in Rubinstein's formulae */
    t1  = phi * nabla * S * Stat_BivariateNormal(phi * nabla * x,
                                                 nabla * y, phi * ro, 
                                                 True, 0.0) ;
    t1 *= pow(d, -T) ;

    a   = phi * nabla * (x - sigma * sqrt(t)) ;
    b   = nabla * (y - sigma * sqrt(T)) ;
    t2  = phi * nabla * k * Stat_BivariateNormal(a, b, phi * ro, 
                                                 True, 0.0) ;
    t2 *= pow(r, -T) ;

    t3  = phi * K * Stat_NormalizedNormal(a) ;
    t3 *= pow(r, -t) ;

    p = t1 - t2 - t3 ;

    return p / disc ;
}


/*
..returns payoff UNdiscounted
..later need to return an OK
*/
FL64 Option_Double_ko(OPTINT* opt, FL64 spot, FL64 volin,
                         FL64 adj, FL64 dfix, FL64 disc)
{
  FL64 yld, r, p, x1, x2, x0, p1, p2, volt, vol2, mu, vol, tol ;

  /* check for triviality */
  if (opt->tfix <= 0.001 || spot < 0.001 || opt->e < 0.001
    || opt->dko.b2 <= opt->dko.b1 || opt->dko.b2 <= spot || spot <= opt->dko.b1
    || (opt->type == CALL && opt->dko.b2 <= opt->e)
    || (opt->type == PUT && opt->e <= opt->dko.b1))
    return 0.0 ;

  /* find solution parameters */
  tol = 1.0e-6 ;  /* arbitrarily set relative tolerance */
  yld  = TVMunit_Yield(adj, opt->tfix, CONTINUOUS, 1) / 100.0 ;
  r    = TVMunit_Yield(dfix, opt->tvol, CONTINUOUS, 1) / 100.0 ;
  vol  = GETMAX(volin, 0.001) ;
  vol /= 100.0 ;
  volt = vol * sqrt(opt->tfix) ;
  vol2 = SQR(vol) ;
  mu   = r - yld - 0.5 * vol2 ;
  x1 = log(opt->dko.b1) ;
  x2 = log(opt->dko.b2) ;
  x0 = log(spot) ;

  /* deal with pay-offs */
  if (opt->dko.poff.poff == OP_VANILLA)
    p   = Dko_bs2P_basic(x1, x2, opt->e, opt->type, opt->tfix,
                        x0, vol2, mu, volt, tol, False) ;
  else if (opt->dko.poff.poff == OP_BINARY)
  {
    p   = Dko_bs2P_basic(x1, x2, opt->e, opt->type, opt->tfix,
                        x0, vol2, mu, volt, tol, True) ;
    p *= opt->dko.poff.gap ;
  }
  else if (opt->dko.poff.poff == OP_ASSETON)
  {
    p1  = Dko_bs2P_basic(x1, x2, opt->e, opt->type, opt->tfix,
                        x0, vol2, mu, volt, tol, False) ;
    p1 *= opt->dko.poff.scale ;
    p2   = Dko_bs2P_basic(x1, x2, opt->e, opt->type, opt->tfix,
                        x0, vol2, mu, volt, tol, True) ;
    p2 *= opt->e ;
    p = p1 + p2 ;
  }
  else if (opt->dko.poff.poff == OP_GAP)
  {
    p1  = Dko_bs2P_basic(x1, x2, opt->e, opt->type, opt->tfix,
                        x0, vol2, mu, volt, tol, False) ;
    p2   = Dko_bs2P_basic(x1, x2, opt->e, opt->type, opt->tfix,
                        x0, vol2, mu, volt, tol, True) ;
    p2 *= opt->dko.poff.gap ;
    p = p1 - p2 ;
  }
  else
    return 0.0 ;

  if (opt->dko.rebates == True)
    p += Dko_rebate(opt, spot, vol, yld, r, disc, tol) / disc ;

  return p ;
}


FL64 Dko_bs2P_basic(FL64  x1, FL64  x2, FL64  e, OPTTYPE  type, 
                        FL64  tfix, FL64  x0, FL64  vol2, FL64  mu, 
                        FL64  volt, FL64  tol, BOOLE  binary) 
{
  FL64 p, dp, c1, c2, kpm, x ;
  INTI i ;

  if (type == CALL)
  {
    x = x2 ;
    kpm = GETMAX(log(e), x1) ;
  }
  else 
  {
    x = x1 ;
    kpm = GETMIN(log(e), x2) ;
  }

  p = Dko_W(x0, x0, mu, vol2, tfix, kpm, x, e, volt, binary, 1) ;

  c1 = c2 = x0 ;

  for (i = 1; i < MAX_MIRRORS; i++)
  {
    c1 = 2.0 * x1 - c1 ;
    c2 = 2.0 * x2 - c2 ;
    
    dp =  Dko_W(c1, x0, mu, vol2, tfix, kpm, x, e, volt, binary, 1) ;
    dp += Dko_W(c2, x0, mu, vol2, tfix, kpm, x, e, volt, binary, -1) ;

    c1 = 2.0 * x2 - c1 ;
    c2 = 2.0 * x1 - c2 ;

    dp -= Dko_W(c1, x0, mu, vol2, tfix, kpm, x, e, volt, binary, -1) ;
    dp -= Dko_W(c2, x0, mu, vol2, tfix, kpm, x, e, volt, binary, 1) ;

    p -= dp ;

    if (fabs(SafeDivide(dp, fabs(p), tol / 10.0, tol / 2.0)) < tol)
      break ;
  }
/*printf("%d", i) ;*/
  return p ;
}

FL64 Stat_ComplErrFct(FL64 x) ;
FL64 Bis_NormalizedNormal(FL64 x) ;

FL64 Dko_W(FL64  c, 
           FL64  x0, 
           FL64  mu, 
           FL64  vol2, 
           FL64  tfix, 
           FL64  kpm, 
           FL64  x, 
           FL64  e,
           FL64  volt,
           BOOLE  binary,
           INTI  sgn)
{
  FL64  w1, w, c1, c2, l ;

  c1 = sgn * (c + mu * tfix - kpm) / volt ;
  c2 = sgn * (c + mu * tfix - x) / volt ; 

  w =  Bis_NormalizedNormal(c2) ;
  w -=  Bis_NormalizedNormal(c1) ;

  w *= (binary) ? -1.0 : e ;

  c1 += sgn * volt ;
  c2 += sgn * volt ;

  if (!binary)
  {
    w1 = Bis_NormalizedNormal(c1) ;
    w1 -= Bis_NormalizedNormal(c2) ;
    w1 *= exp(c + (mu + 0.5 * vol2) * tfix) ;
    w += w1 ;
  }

  l = GETMIN(mu / vol2 * (c - x0), log(DBL_MAX) - 1.0) ;
  w *= exp(l) ;

  return sgn * w ;
}






/*
  This function computes the (discounted) present value of rebates 
  on a double knock-out option
*/

FL64  Dko_rebate(OPTINT*  opt, 
                    FL64  spot, 
                    FL64  voll, 
                    FL64  yld, 
                    FL64  r, 
                    FL64  disc, 
                    FL64  tol) 
{
  FL64 reb, u1, u2 ;
  FL64 b1, b2, s, vol, mu, km, m, k, x, x0, x1, x2, t, vt ;

  /* Set solution variables */
  s = GETMAX(spot, 0.000001) ;
  b1  = GETMAX(opt->dko.b1, 0.000001) ;
  b2  = GETMAX(opt->dko.b2, 0.000001) ;
  vol = GETMAX(voll, 0.01) ;
  t = GETMAX(opt->tfix, 0.000001) ;

  mu = r - yld - 0.5 * SQR(vol) ;
  k = mu / SQR(vol) ;
  m = sqrt(2.0 * r * SQR(vol) + SQR(mu)) ;
  km = m / SQR(vol) ;
  vt = vol * sqrt(t) ;

  x   = x0 = log(s) ;
  x1  = log(b1) ;
  x2  = log(b2) ;

  if (x >= x2 || x <= x1)
      return 0.0 ;

  /* split into elementary rebates and value these */
  /* lower barrier */
  if (fabs(opt->dko.r1) < 0.000001)
    u1 = 0.0 ;
  else if (opt->dko.phit1 == True)
  /* at-hit payment */
    u1 = dko_upper_rebate(x1 + x2 - x0, x1, x2, -k, -km, vt, (-m) * t, tol) ;
  else
  {/* at-expiry payment */
    u1 = dko_upper_rebate(x1 + x2 - x0, x1, x2, -k, -k, vt, (-mu) * t, tol) ;
    u1 *= disc ;
  }

  /* upper barrier */
  if (fabs(opt->dko.r2) < 0.000001)
    u2 = 0.0 ;
  else if (opt->dko.phit2 == True)
  /* at-hit payment */
    u2 = dko_upper_rebate(x0, x1, x2, k, km, vt, m * t, tol) ;
  else
  {/* at-expiry payment */
    u2 = dko_upper_rebate(x0, x1, x2, k, k, vt, mu * t, tol) ;
    u2 *= disc ;
  }

  /* multiply by cash rebates and sum */
  reb = u1 * opt->dko.r1 + u2 * opt->dko.r2 ;

  /* return */
  return reb ;
}

/* 
  unit pay-off! 
*/
FL64  dko_upper_rebate(FL64 x0, 
                          FL64 x1, 
                          FL64 x2, 
                          FL64 k, 
                          FL64 km, 
                          FL64 vt,
                          FL64 mt,
                          FL64 tol)
{
  FL64 u, du, yi, zi, dyz, yd1, yd2, zd1, zd2 ;
  INTI i ;

  yi = x0 + x2 - 2.0 * x1 ;
  zi = x2 - x0 ;
  dyz = 2.0 * (x1 - x2) ;

  for (i = 1, u = 0.0; i < MAX_MIRRORS; i++)
  {
    yi += dyz ;
    yd1 = (yi + mt) / vt ;
    yd2 = (yi - mt) / vt ;
    zi += dyz ;
    zd1 = (zi - mt) / vt ;
    zd2 = (zi + mt) / vt ;
    
    du = exp(km * yi) * Stat_NormalizedNormal(yd1) 
      + exp(-km * yi) * Stat_NormalizedNormal(yd2) ;

    du -= exp(-km * zi) * Stat_NormalizedNormal(zd1) 
      + exp(km * zi) * Stat_NormalizedNormal(zd2) ;

    u += du ;
    
    if (fabs(SafeDivide(du, u, tol / 10.0, tol / 2.0)) < tol)
      break ;
  }
/*
  printf("%d", i) ;
*/
  u *= exp(k * (x2 - x0)) ;

  return u ;
}



/* find barrier shift factor following Broadie, Glasserman & Kou */
FL64  optint_DiscBarrShiftFac(DATESTR* vold, 
                                 DATESTR* dfix, 
                                 PERIOD* monit,
                                 FL64 vol, 
                                 FL64 tfix, 
                                 CALCONV cal,
                                 HOLI_STR* holi)
{
  FL64    s ;
  INTI    m ;

  /* find # observations */
  m = Cldr_PeriodsBetweenDates(vold, dfix, monit, cal, LAST, holi) ;

  /* no nastiness */
  m = GETMAX(m, 1) ;

  /* compute shift factor */
  s = 0.5826 * (vol / 100.0) * sqrt(tfix / m) ;
  s = exp(s) ;

  /* return */
  return s ;
}


/* function computing the complementary error function
  (cf Numerical Recipes in C) */
FL64 Stat_ComplErrFct(FL64  x)
{
  FL64 t, z, ans, s ;

  z = fabs(x) ;
  t = 1.0 / (1.0 + 0.5 * z) ;
  s = t * (1.00002368 
         + t * (0.37409196 
              + t * (0.09678418 
                   + t * (-0.18628806 
                        + t * (0.27886807 
                             + t * (-1.13520398 
                                  + t * (1.48851587      
                                       + t * (-0.82215223 
                                            + t * 0.17087277)))))))) ;
  ans = t * exp(-SQR(z) - 1.26551223 + s) ;

  return x >= 0.0 ? ans : 2.0 - ans ;
}

FL64 Bis_NormalizedNormal(FL64  x)
{
  return 1.0 - Stat_ComplErrFct(x / SQRT_TWO) / 2.0 ;
}

#undef PAYM_TOL    
#undef MIN_VOL     
#undef MIN_DRIFT
#undef MIN_EXERCISE
#undef MAX_MIRRORS 
#undef SQRT_TWO 

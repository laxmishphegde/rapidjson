#include <sccsid.h>
SCCSID(optio_c,
  "@(#)optio.c	1.12 (SimCorp) 99/02/19 14:17:56")

/************************************************************************
*
*   Project     SCecon
*
*   file name   ioutils.c
*
*   general     This file contains file io functions
*
************************************************************************/

/* includes    *********************************************************/
#include <optio.h>
#include <ioconv.h>
#include <optvalid.h>


PREMIUMTYPE Str2PREMIUMTYPE(TEXT txt)
{
    PREMIUMTYPE r = PREMIUMTYPE_INIT ;

    Str_Uppercase(txt) ;

    if      (!strcmp(txt, "UP_FRONT"))      r = UP_FRONT ;
    else if (!strcmp(txt, "UP FRONT"))      r = UP_FRONT ;
    else if (!strcmp(txt, "FRONT"))         r = UP_FRONT ;
    else if (!strcmp(txt, "F"))             r = UP_FRONT ;

    else if (!strcmp(txt, "BY_MARGIN"))     r = BY_MARGIN ;
    else if (!strcmp(txt, "BY MARGIN"))     r = BY_MARGIN ;
    else if (!strcmp(txt, "MARGIN"))        r = BY_MARGIN ;
    else if (!strcmp(txt, "M"))             r = BY_MARGIN ;
    else
        SCecon_error("Unknown premium type convention\n", 
          "Str2PREMIUMTYPE()", SCECONABORT) ;

    return r ;
}


/*
..
*/


OPTTYPE Str2OPTTYPE(TEXT txt)
{
    OPTTYPE r = OPTTYPE_INIT ;

    Str_Uppercase(txt) ;

    if      (!strcmp(txt, "CALL"))      r = CALL ;
    else if (!strcmp(txt, "CAP"))       r = CALL ;
    else if (!strcmp(txt, "C"))         r = CALL ;
    else if (!strcmp(txt, "RECEIVER"))  r = CALL ;
    else if (!strcmp(txt, "RECEIVE"))   r = CALL ;
    else if (!strcmp(txt, "RCV"))       r = CALL ;
    else if (!strcmp(txt, "R"))         r = CALL ;

    else if (!strcmp(txt, "PUT"))       r = PUT ;
    else if (!strcmp(txt, "PAYER"))     r = PUT ;
    else if (!strcmp(txt, "PAY"))       r = PUT ;
    else if (!strcmp(txt, "FLOOR"))     r = PUT ;
    else if (!strcmp(txt, "P"))         r = PUT ;
    else if (!strcmp(txt, "F"))         r = PUT ;

    else if (!strcmp(txt, "STRADDLE"))  r = STRADDLE ;
    else if (!strcmp(txt, "S"))         r = STRADDLE ;
    else
        SCecon_error("Unknown option type\n", "Str2OPTTYPE()", 
          SCECONABORT) ;

    return r ;
}


/*
..
*/


PAYOFF Str2PAYOFF(TEXT txt)
{
    PAYOFF eom = PAYOFF_INIT ;

    Str_Uppercase(txt) ;

    if      (!strcmp(txt, "OP_BINARY"))   eom = OP_BINARY ;
    else if (!strcmp(txt, "BINARY"))      eom = OP_BINARY ;
    else if (!strcmp(txt, "B"))           eom = OP_BINARY ;
    else if (!strcmp(txt, "DIGITAL"))     eom = OP_BINARY ;
    else if (!strcmp(txt, "D"))           eom = OP_BINARY ;

    else if (!strcmp(txt, "OP_VANILLA"))  eom = OP_VANILLA ;
    else if (!strcmp(txt, "VANILLA"))     eom = OP_VANILLA ;
    else if (!strcmp(txt, "V"))           eom = OP_VANILLA ;

    else if (!strcmp(txt, "OP_ASSETON"))  eom = OP_ASSETON ;
    else if (!strcmp(txt, "ASSETON"))     eom = OP_ASSETON ;
    else if (!strcmp(txt, "AON"))         eom = OP_ASSETON ;

    else if (!strcmp(txt, "OP_GAP"))      eom = OP_GAP ;
    else if (!strcmp(txt, "GAP"))         eom = OP_GAP ;
    else
        SCecon_error("Unknown Payoff type\n", "Str2PAYOFF()", 
            SCECONABORT) ;

    return eom ;
}


/*
..
*/


OPTADD Str2OPTADD(TEXT txt)
{
    OPTADD optadd = OPTADD_INIT ;

    Str_Uppercase(txt) ;

    if      (!strcmp(txt, "NO_OPTADD"))       optadd = NO_OPTADD ;
    else if (!strcmp(txt, "CHOOSER"))         optadd = CHOOSER ;
    else if (!strcmp(txt, "LOOKBACK"))        optadd = LOOKBACK ;
    else if (!strcmp(txt, "BARRIER"))         optadd = BARRIER ;
    else if (!strcmp(txt, "ASIAN"))           optadd = ASIAN ;
    else if (!strcmp(txt, "FWDSTART"))        optadd = FWDSTART ;
    else if (!strcmp(txt, "TOUCHDIG"))        optadd = TOUCHDIG ;
    else if (!strcmp(txt, "BINARY"))          optadd = BINARY ;
    else if (!strcmp(txt, "CONTPREM"))        optadd = CONTPREM ;
    else if (!strcmp(txt, "COMPOPT"))         optadd = COMPOPT ;
    else if (!strcmp(txt, "DOUBLKO"))         optadd = DOUBLKO ;
    else if (!strcmp(txt, "RESET"))           optadd = RESET ;
    else if (!strcmp(txt, "SWPTBARR"))        optadd = SWPTBARR ;
    else if (!strcmp(txt, "SHARKFIN"))        optadd = SHARKFIN ;
    else if (!strcmp(txt, "LADDER"))          optadd = LADDER;
    else if (!strcmp(txt, "TSWITCH"))         optadd = TSWITCH;
    else if (!strcmp(txt, "CORRIDOR"))        optadd = CORRIDOR;
    else if (!strcmp(txt, "FLEXICAP"))        optadd = FLEXICAP;
    else
        SCecon_error("Unknown Exotic type\n", "Str2OPTADD()", 
            SCECONABORT) ;

    return optadd ;
}

/*
..
*/


KNOCKTYPE Str2KNOCKTYPE(TEXT txt)
{
    KNOCKTYPE knocktype = KNOCKTYPE_INIT ;

    Str_Uppercase(txt) ;

    if      (!strcmp(txt, "UP_IN"))       knocktype = UP_IN ;
    else if (!strcmp(txt, "UPIN"))        knocktype = UP_IN ;
    else if (!strcmp(txt, "UP_OUT"))      knocktype = UP_OUT ;
    else if (!strcmp(txt, "UPOUT"))       knocktype = UP_OUT ;
    else if (!strcmp(txt, "DOWN_OUT"))    knocktype = DOWN_OUT ;
    else if (!strcmp(txt, "DOWNOUT"))     knocktype = DOWN_OUT ;
    else if (!strcmp(txt, "DOWN_IN"))     knocktype = DOWN_IN ;
    else if (!strcmp(txt, "DOWNIN"))      knocktype = DOWN_IN ;
    else
        SCecon_error("Unknown Knock type\n", "Str2KNOCKTYPE()", 
            SCECONABORT) ;

    return knocktype ;
}

/*
..
*/


CTTYPE Str2CTTYPE(TEXT txt)
{
    CTTYPE iw = FESDC;

    if      (!strcmp("FESDC", txt))       iw = FESDC ;
    else if (!strcmp("QUANTOPT", txt))    iw = QUANTOPT ;
    else if (!strcmp("ELFX", txt))        iw = ELFX ;
    else
        SCecon_error("cttype unknown\n", "Str2CTTYPE()", SCECONABORT) ;

    return iw ;
}




/*
..
*/


PREMIUMTYPE Read_PREMIUMTYPE(FILE* in, FILE* out, TEXT dscr)
{
    PREMIUMTYPE irr;
    CH txb[MAX_KEYWORD_LENGTH];

      /* Comments, if any: */
    if (!IOUtil_ReadComment(in, out))
        Write_Comment(out, dscr);

    Read_TEXT(in, MAX_KEYWORD_LENGTH, txb);
    irr = Str2PREMIUMTYPE(txb);

    fprintf(out, " %s\n", txb);

    return irr;
}

/*
..
*/


OPTTYPE Read_OPTTYPE(FILE* in, FILE* out, TEXT dscr)
{
    OPTTYPE irr;
    CH txb[MAX_KEYWORD_LENGTH];

      /* Comments, if any: */
    if (!IOUtil_ReadComment(in, out))
        Write_Comment(out, dscr);

    Read_TEXT(in, MAX_KEYWORD_LENGTH, txb);
    irr = Str2OPTTYPE(txb);

    fprintf(out, " %s\n", txb);

    return irr;
}

/*
..
*/


PAYOFF Read_PAYOFF(FILE* in, FILE* out, TEXT dscr)
{
    PAYOFF irr;
    CH txb[MAX_KEYWORD_LENGTH];

      /* Comments, if any: */
    if (!IOUtil_ReadComment(in, out))
        Write_Comment(out, dscr);

    Read_TEXT(in, MAX_KEYWORD_LENGTH, txb);
    irr = Str2PAYOFF(txb);

    fprintf(out, " %s\n", txb);

    return irr;
}

/*
..
*/


OPTADD Read_OPTADD(FILE* in, FILE* out, TEXT dscr)
{
    OPTADD irr;
    CH txb[MAX_KEYWORD_LENGTH];

      /* Comments, if any: */
    if (!IOUtil_ReadComment(in, out))
        Write_Comment(out, dscr);

    Read_TEXT(in, MAX_KEYWORD_LENGTH, txb);
    irr = Str2OPTADD(txb);

    fprintf(out, " %s\n", txb);

    return irr;
}

/*
..
*/


KNOCKTYPE Read_KNOCKTYPE(FILE* in, FILE* out, TEXT dscr)
{
    KNOCKTYPE irr;
    CH txb[MAX_KEYWORD_LENGTH];

      /* Comments, if any: */
    if (!IOUtil_ReadComment(in, out))
        Write_Comment(out, dscr);

    Read_TEXT(in, MAX_KEYWORD_LENGTH, txb);
    irr = Str2KNOCKTYPE(txb);

    fprintf(out, " %s\n", txb);

    return irr;
}

/*
..
*/


CTTYPE Read_CTTYPE(FILE* in, FILE* out, TEXT dscr)
{
    CTTYPE irr;
    CH txb[MAX_KEYWORD_LENGTH];

      /* Comments, if any: */
    if (!IOUtil_ReadComment(in, out))
        Write_Comment(out, dscr);

    Read_TEXT(in, MAX_KEYWORD_LENGTH, txb);
    irr = Str2CTTYPE(txb);

    fprintf(out, " %s\n", txb);

    return irr;
}

/*
..
*/




OPTFUT Read_OPTFUT(FILE* in, FILE* out)
{

    OPTFUT   opt ;

    opt.type = Read_OPTTYPE(in, out, "Type");
    opt.strike = Read_FL64(in, out, "Strike");
    opt.dfix = Read_DATESTR(in, out, "Fixing Date");
    opt.dpay = Read_DATESTR(in, out, "Payment Date");
    opt.ptype = Read_PREMIUMTYPE(in, out, "Premium Type");
    opt.cal = Read_CALCONV(in, out, "Calendar");
    opt.oadd = Read_OPTADD(in, out, "Additionals");

    switch (opt.oadd)
    {
        case NO_OPTADD:
            break ;

        case CHOOSER:

            opt.chos.dchoose = Read_DATESTR(in, out, "ChooseDate");
            break ;

        case LOOKBACK:

            opt.lbi.xtrem = Read_FL64(in, out, "Hist. Extreme");
            opt.lbi.lbrate = Read_BOOLE(in, out, "LB Rate");
            break ;

        case BARRIER:

            opt.barr.btype = Read_KNOCKTYPE(in, out, "Type");
            opt.barr.barrier = Read_FL64(in, out, "Barrier");
            opt.barr.rebate = Read_FL64(in, out, "Rebate");
            opt.barr.phit = Read_BOOLE(in, out, "At Hit");

            opt.barr.poff.poff = Read_PAYOFF(in, out, "Payoff");
            opt.barr.poff.gap = Read_FL64(in, out, "Gap");
            opt.barr.poff.scale = Read_FL64(in, out, "Scale");

            opt.barr.monit = Read_PERIOD(in) ;
            Write_PERIOD(out, "Look period:", &opt.barr.monit) ;
            break ;

        case ASIAN:


            opt.asian.davg1 = Read_DATESTR(in, out, "Avg Date 1");
            opt.asian.davgN = Read_DATESTR(in, out, "Avg Date N");
            opt.asian.num_avg = Read_INTI(in, out, "Num Avg");
            opt.asian.curr_avg = Read_FL64(in, out, "Curr Avg");
            opt.asian.avgrt = Read_BOOLE(in, out, "AvgRate");
            opt.asian.last_avg = 0.0;
            break ;

        case FWDSTART:

            opt.fwdst.dset = Read_DATESTR(in, out, "SetDate");
            opt.fwdst.alpha = Read_FL64(in, out, "Alpha");

            break ;

        case TOUCHDIG:

            opt.tdi.btype = Read_KNOCKTYPE(in, out, "Type");
            opt.tdi.barrier = Read_FL64(in, out, "Barrier");
            opt.tdi.phit = Read_BOOLE(in, out, "At Hit");

            opt.tdi.poff.poff = Read_PAYOFF(in, out, "Payoff");
            opt.tdi.poff.gap = Read_FL64(in, out, "Gap");
            opt.tdi.poff.scale = Read_FL64(in, out, "Scale");
            break ;

        case BINARY :

            opt.bini.poff.poff = Read_PAYOFF(in, out, "Payoff");
            opt.bini.poff.gap = Read_FL64(in, out, "Gap");
            opt.bini.poff.scale = Read_FL64(in, out, "Scale");
            /* Day-count period adjustment is only applicable for caps: */
            opt.bini.dcadj = False;
            break ;

        case CONTPREM:

            opt.ctp.prem = Read_FL64(in, out, "Cont Prem");
            break ;

        case COMPOPT:

            opt.compo.type = Read_OPTTYPE(in, out, "Type") ;
            opt.compo.matur = Read_DATESTR(in, out, "Maturity") ;
            opt.compo.strike = Read_FL64(in, out, "Strike") ;
            break ;

        case DOUBLKO:
            opt.dko.b1 = Read_FL64(in, out, "Lower Barrier") ;
            opt.dko.b2 = Read_FL64(in, out, "Upper Barrier") ;
            opt.dko.monit = Read_PERIOD(in) ;
            Write_PERIOD(out, "Look period:", &opt.dko.monit) ;

            opt.dko.poff.poff = Read_PAYOFF(in, out, "Payoff");
            opt.dko.poff.gap = Read_FL64(in, out, "Gap");
            opt.dko.poff.scale = Read_FL64(in, out, "Scale");

            opt.dko.rebates = Read_BOOLE(in, out, "Rebates?") ;
            if (opt.dko.rebates)
            {
              opt.dko.r1 = Read_FL64(in, out, "Lower Rebate") ;
              opt.dko.phit1 = Read_BOOLE(in, out, "Pay at hit?") ;
              opt.dko.r2 = Read_FL64(in, out, "Upper Rebate") ;
              opt.dko.phit2 = Read_BOOLE(in, out, "Pay at hit?") ;
            }
            else
            {
              opt.dko.r1 = opt.dko.r2 = 0.0;
              opt.dko.phit1 = opt.dko.phit2 = False;
            }
            break ;

        case LADDER:
            opt.lad.levels = Read_FL64ARRAY (in, &opt.lad.nlevels);
            Write_FL64ARRAY(out, opt.lad.levels, opt.lad.nlevels) ;
            break ;

        case TSWITCH:
            opt.tswi.dobs1 = Read_DATESTR(in, out, "Obs Date 1") ;
            opt.tswi.dobsN = Read_DATESTR(in, out, "Obs Date N") ;
            opt.tswi.num_obs = Read_INTI(in, out, "Num Obs");
            opt.tswi.level = Read_FL64(in, out, "Switch Level");
            opt.tswi.step_strike = Read_PLANARRAY(in) ;
            Write_PLANARRAY(out, opt.tswi.step_strike) ;
            opt.tswi.curr_pay = Read_FL64(in, out, "Curr Accum");
            break ;

        case CORRIDOR:
            opt.cor.dobs1 = Read_DATESTR(in, out, "Obs Date 1") ;
            opt.cor.dobsN = Read_DATESTR(in, out, "Obs Date N") ;
            opt.cor.num_obs = Read_INTI(in, out, "Num Obs");
            opt.cor.upper = Read_FL64(in, out, "Upper Level");
            opt.cor.lower = Read_FL64(in, out, "Lower Level");
            opt.cor.ustep_strike = Read_PLANARRAY(in) ;
            Write_PLANARRAY(out, opt.cor.ustep_strike) ;
            opt.cor.lstep_strike = Read_PLANARRAY(in) ;
            Write_PLANARRAY(out, opt.cor.lstep_strike) ;
            opt.cor.curr_pay = Read_FL64(in, out, "Curr Accum");
            break ;    

        default:
            ;
}

    Write_VALIDATEError(out, Validate_OPTFUT(&opt));

    return opt ;
}



/*
..
*/


OPTCT Read_OPTCT(FILE* in, FILE* out)
{
    OPTCT    opt ;
    YYYYMMDD ymd, ymd1 ;
    char     txb[20], txd[20], txe[20] ;

    fscanf(in,"%s %lf %ld %ld %s %s",
           txb, &opt.strike, &ymd, &ymd1, txd, txe) ;

    opt.type  = Str2OPTTYPE(txb) ;
    opt.dfix  = Cldr_YMD2Datestr(ymd) ;
    opt.dpay  = Cldr_YMD2Datestr(ymd1) ;
    opt.ptype = Str2PREMIUMTYPE(txd) ;
    opt.cal   = Str2CALCONV(txe) ;

    fprintf(out,"   Type          %8s\n", txb) ;
    fprintf(out,"   Strike        %8.5lf\n", opt.strike) ;
    fprintf(out,"   Fixing date   %8ld\n", ymd) ;
    fprintf(out,"   Pay Date      %8ld\n", ymd1) ;
    fprintf(out,"   PremiumType   %8s\n", txd) ;
    fprintf(out,"   Cal           %8s\n", txe) ;

    fscanf(in,"%s", txb) ;
    fprintf(out,"   Additionals:  %8s\n", txb) ;

    opt.cttype = Str2CTTYPE(txb) ;

    switch (opt.cttype)
    {
        case QUANTOPT:

            fscanf(in, "%lf", &opt.quanto.FX0) ;
            fprintf(out,"   FX0           %8lf\n", opt.quanto.FX0) ;
            break ;

        default:
            ;
    }

    Write_VALIDATEError(out, Validate_OPTCT(&opt));

    return opt ;
}

/*
..
*/


#include <sccsid.h>
SCCSID(optvalid_c,
  "@(#)optvalid.c	1.12 (SimCorp) 99/02/19 14:18:06")


/************************************************************************
*
*   project     SCecon
*
*   file name   validate.c
*
*   general     This file contains routines for validating the
*               content of the data structures of SCecon
*
************************************************************************/

/*** includes **********************************************************/
#include <optvalid.h>

/*** defines ***********************************************************/
#define valid_tol 0.000001


/*,,SOH,,
*************************************************************************
*
*               Validate_PREMIUMTYPE()
*
*   interface   #include <optvalid.h>
*               BOOLE Validate_PREMIUMTYPE(PREMIUMTYPE p)
*
*   general     This function validates the content of the PREMIUMTYPE
*               data structure
*
*   input       PREMIUMTYPE  p    The PREMIUMTYPE data structure
*
*   output
*
*   returns     True if p is a valid PREMIUMTYPE, otherwise False
*
*   diagnostics
*
*   see also    PREMIUMTYPE
*
*************************************************************************
,,EOH,,*/


BOOLE Validate_PREMIUMTYPE(PREMIUMTYPE p)
{
    switch (p)
    {
        case UP_FRONT:
        case BY_MARGIN:
            return True ;
        default:
            return False ;
    }
}


/*,,SOH,,
***********************************************************************
*                                                                      
*               Validate_CTTYPE()
*                                                                      
*   interface   #include <optvalid.h>                                  
*               BOOLE     Validate_CTTYPE(CTTYPE r)              
*                                                                      
*   general     This function validates the content of the CTTYPE
*               data structure                                         
*                                                                      
*   input       CTTYPE  r  The CTTYPE data structure
*                                                                      
*   output                                                             
*                                                                      
*   returns     True if r is a valid CTTYPE, False if invalid       
*                                                                      
*   diagnostics                                                        
*                                                                      
*   see also    CTTYPE
*                                                                      
***********************************************************************
,,EOH,,*/
BOOLE Validate_CTTYPE(CTTYPE  r)
{
    /* check that r is valid */
    switch (r)
    {
    case FESDC:
    case QUANTOPT:      
    case ELFX:      
        return True ;
    default:    
        return False ;    
    }
}


/*,,SOH,,
*************************************************************************
*
*               Validate_CONTPREMINF()
*
*   interface   #include <optvalid.h>
*               VALIDATE Validate_CONTPREMINF(CONTPREMINF *c)
*
*   general     This function validates the content of the CONTPREMINF
*               data structure
*
*   input       CONTPREMINF *c       The CONTPREMINF data structure
*
*   output
*
*   returns     Valid_data if the content of CONTPREMINF is valid,
*
*               Invalid_prem if prem is less than 0
*
*   diagnostics
*
*   see also    CONTPREMINF
*
*************************************************************************
,,EOH,,*/


VALIDATE Validate_CONTPREMINF(CONTPREMINF* c)
{
    if (c->prem < -valid_tol)
        return Invalid_prem ;

    return Valid_data ;
}



/*,,SOH,,
*************************************************************************
*
*               Validate_LOOKBACKINF()
*
*   interface   #include <optvalid.h>
*               VALIDATE Validate_LOOKBACKINF(LOOKBACKINF *l)
*
*   general     This function validates the content of the LOOKBACKTINF
*               data structure
*
*   input       LOOKBACKINF  *l   The LOOKBACKINF data structure
*
*   output
*
*   returns     Valid_data if the content of LOOKBACKINF is valid,
*               Invalid_xtrem if type is less than 0
*               Invalid_boole if lbrate is not True or False
*
*   diagnostics
*
*   see also    LOOKBACKINF
*
*************************************************************************
,,EOH,,*/


VALIDATE Validate_LOOKBACKINF(LOOKBACKINF* l)
{
    if (l->xtrem < -valid_tol)
        return Invalid_xtrem ;

    if (!Validate_BOOLE(l->lbrate))
        return Invalid_boole ;

    return Valid_data ;
}



/*,,SOH,,
*************************************************************************
*
*               Validate_COMPOPTINF()
*
*   interface   #include <optvalid.h>
*               VALIDATE Validate_COMPOPTINF(COMPOPTINF *c) ;
*
*   general     This function validates the content of the COMPOPTINF
*               data structure
*
*   input       COMPOPTINF  *c          The COMPOPTINF data structure
*
*   output
*
*   returns     Valid_data if the content of COMPOPTINF is valid,
*               Invalid_opttype if type is an invalid OPTTYPE
*               Invalid_date if matur is an invalid date
*               Invalid_strike if strike is less than 0
*
*   diagnostics
*
*   see also    COMPOPTINF
*
*************************************************************************
,,EOH,,*/

VALIDATE Validate_COMPOPTINF(COMPOPTINF* c)
{
    BOOLE ok = False ;

    if (!Validate_OPTTYPE(c->type))
        return Invalid_opttype ;

    ok = Cldr_CheckDate(&c->matur) ;
    if (ok == False)
        return Invalid_date ;

    if (c->strike < -valid_tol)
        return Invalid_strike ;

    return Valid_data ;
}



/*,,SOH,,
*************************************************************************
*
*               Validate_PAYOFFINF()
*
*   interface   #include <optvalid.h>
*               VALIDATE Validate_PAYOFFINF(PAYOFFINF *p)
*
*   general     This function validates the content of the PAYOFFINF
*               data structure
*
*   input       PAYOFFINF   *p    The PAYOFFINF data structure
*
*   output
*
*   returns     Valid_data if the content of PAYOFFINF is valid,
*               Invalid_payoff if poff is an invalid PAYOFF
*
*   diagnostics
*
*   see also    PAYOFFINF
*
*************************************************************************
,,EOH,,*/


VALIDATE Validate_PAYOFFINF(PAYOFFINF* p)
{
    if (!Validate_PAYOFF(p->poff))
        return Invalid_payoff ;

    return Valid_data ;
}


/*,,SOH,,
*************************************************************************
*
*               Validate_DOUBLKOINF()
*
*   interface   #include <optvalid.h>
*               VALIDATE Validate_DOUBLKOINF(DOUBLKOINF *d)
*
*   general     This function validates the content of the DOUBLKOINF
*               data structure
*
*   input       DOUBLKOINF   *d   The DOUBLKOINF data structure
*
*   output
*
*   returns     Valid_data if the content of DOUBLKOINF is valid,
*
*   diagnostics
*
*   see also    DOUBLKOINF
*
*************************************************************************
,,EOH,,*/


VALIDATE Validate_DOUBLKOINF(DOUBLKOINF* d)
{
    if (d->b1 < -valid_tol || d->b2 < -valid_tol)
        return Invalid_barrier;

    if (d->monit.num < 0)
      return Invalid_period ;

    return Valid_data ;
}

/*,,SOH,,
*************************************************************************
*
*               Validate_LADDERINF()
*
*   interface   #include <optvalid.h>
*               VALIDATE Validate_LADDERINF(LADDERINF *d)
*
*   general     This function validates the content of the LADDERINF
*               data structure
*
*   input       LADDERINF   *d   The LADDERINF data structure
*
*   output
*
*   returns     Valid_data if the content of LADDERINF is valid,
*
*   diagnostics
*
*   see also    LADDERINF
*
*************************************************************************
,,EOH,,*/


VALIDATE Validate_LADDERINF(LADDERINF* d)
{
    if (d->nlevels < 0)
      return Invalid_filled ;

    return Valid_data ;
}


/*,,SOH,,
*************************************************************************
*
*               Validate_TSWITCHINF()
*
*   interface   #include <optvalid.h>
*               VALIDATE Validate_TSWITCHINF(TSWITCHINF  *d);
*
*   general     This function validates the content of the TSWITCHINF
*               data structure
*
*   input       TSWITCHINF  *d          The TSWITCHINF data structure
*
*   output
*
*   returns     Valid_data if the content of TSWITCHINF is valid,
*
*   diagnostics
*
*   see also    TSWITCHINF
*
*************************************************************************
,,EOH,,*/


VALIDATE Validate_TSWITCHINF(TSWITCHINF* d)
{
    BOOLE ok = False ;
    VALIDATE v ;
   
    ok = Cldr_CheckDate(&d->dobs1) ;
    ok = ok && Cldr_CheckDate(&d->dobsN) ;

    if (ok == False)
       return Invalid_date ;

    v = Validate_PLAN_STR_SIGN(d->step_strike, True) ;
    if (v != Valid_data)
      return v;

    if (Cldr_DateLE(&d->dobs1, &d->dobsN) == False)
       return Dobs1_after_dobsN ;

    if (d->num_obs < 0)
      return Invalid_filled ;

    return Valid_data ;
}

/*,,SOH,,
*************************************************************************
*
*               Validate_CORRIDORINF()
*
*   interface   #include <optvalid.h>
*               VALIDATE Validate_CORRIDORINF(CORRIDORINF *d) ;
*
*   general     This function validates the content of the CORRIDORINF
*               data structure
*
*   input       CORRIDORINF  *d         The CORRIDORINF data structure
*
*   output
*
*   returns     Valid_data if the content of CORRIDORINF is valid,
*
*   diagnostics
*
*   see also    CORRIDORINF
*
*************************************************************************
,,EOH,,*/


VALIDATE Validate_CORRIDORINF(CORRIDORINF* d)
{
    BOOLE ok = False ;
    VALIDATE v ;

    ok = Cldr_CheckDate(&d->dobs1) ;
    ok = ok && Cldr_CheckDate(&d->dobsN) ;
    if (ok == False)
       return Invalid_date ;

    v = Validate_PLAN_STR_SIGN(d->ustep_strike, True) ;
    if (v != Valid_data)
      return v;

    v = Validate_PLAN_STR_SIGN(d->lstep_strike, True) ;
    if (v != Valid_data)
      return v;

    if (Cldr_DateLE(&d->dobs1, &d->dobsN) == False)
       return Dobs1_after_dobsN ;

    if (d->num_obs < 0)
       return Invalid_filled ;

    if (d->upper < d->lower)
       return Invalid_filled ;

    if (d->curr_pay < 0)
       return Invalid_filled ;

    return Valid_data ;
}


/*,,SOH,,
*************************************************************************
*
*               Validate_BARRIERINF()
*
*   interface   #include <optvalid.h>
*                VALIDATE Validate_BARRIERINF(BARRIERINF *b)
*
*   general     This function validates the content of the BARRIERINF
*               data structure
*
*   input       BARRIERINF  *b    The BARRIERINF data structure
*
*   output
*
*   returns     Valid_data if the content of BARRIERINF is valid,
*               Invalid_knocktype if btype is an invalid KNOCKTYPE
*               Invalid_barrier if barrier <= 0
*               Invalid_boole if phit is not True or False
*               Invalid_rebate if rebate <= 0
*               If the content of poff is invalid an error message
*                    from Validate_PAYOFFINF() is returned
*
*   diagnostics
*
*   see also    BARRIERINF
*
*************************************************************************
,,EOH,,*/


VALIDATE Validate_BARRIERINF(BARRIERINF* b)
{
    VALIDATE v ;

    if (!Validate_KNOCKTYPE(b->btype))
        return Invalid_knocktype ;

    if (b->barrier <= -valid_tol)
        return Invalid_barrier ;

    if (!Validate_BOOLE(b->phit))
        return Invalid_boole ;

    if (b->rebate < -valid_tol)
        return Invalid_rebate ;

    v = Validate_PAYOFFINF(&b->poff) ;
    if (v != Valid_data)
        return v ;

    if (b->monit.num < 0)
      return Invalid_period ;

    return Valid_data ;
}


/*,,SOH,,
*************************************************************************
*
*               Validate_BINARYINF()
*
*   interface   #include <optvalid.h>
*               VALIDATE Validate_BINARYINF(BINARYINF *b)
*
*   general     This function validates the content of the BINARYINF
*               data structure
*
*   input       BINARYINF     *b    The BINARYINF data structure
*
*   output
*
*   returns     Valid_data if the content of BINARYINF is valid,
*               If the content of poff is invalid an error message
*                   from Validate_PAYOFFINF() is returned
*
*   diagnostics
*
*   see also    BINARYINF
*
*************************************************************************
,,EOH,,*/


VALIDATE Validate_BINARYINF(BINARYINF* b)
{
    VALIDATE v ;

    v = Validate_PAYOFFINF(&b->poff) ;
    if (v != Valid_data)
        return v ;

    if (!Validate_BOOLE(b->dcadj))
        return Invalid_boole ;

    return Valid_data ;
}


/*,,SOH,,
*************************************************************************
*
*               Validate_RESETINF()
*
*   interface   #include <optvalid.h>
*                VALIDATE Validate_RESETINF(RESETINF *r)
*
*   general     This function validates the content of the RESETINF
*               data structure
*
*   input       RESETINF  *r    The RESETINF data structure
*
*   output
*
*   returns     Valid_data if the content of RESETINF is valid,
*               Invalid_reset_nfirst if nfirst < 0
*               Invalid_reset_nfreq if nfreq <= 0
*               Invalid_boole if r->delayfix is not a BOOLE.
*
*   diagnostics
*
*   see also    RESETINF
*
*************************************************************************
,,EOH,,*/


VALIDATE Validate_RESETINF(RESETINF* r)
{

    if (r->nfirst < 0)
        return Invalid_reset_nfirst ;

    if (r->nfreq <= 0)
        return Invalid_reset_nfreq ;

    if (!Validate_BOOLE(r->delayfix))
        return Invalid_boole ;


    return Valid_data ;
}


/*,,SOH,,
*************************************************************************
*
*               Validate_TOUCHDIGINF()
*
*   interface   #include <optvalid.h>
*               VALIDATE Validate_TOUCHDIGINF(TOUCHDIGINF *t)
*
*   general     This function validates the content of the TOUCHDIGINF
*               data structure
*
*   input       TOUCHDIGINF   *t  The TOUCHDIGINF data structure
*
*   output
*
*   returns     Valid_data if the content of TOUCHDIGINF is valid,
*               Invalid_knocktype if btype is an invalid KNOCKTYPE
*               Invalid_barrier if barrier < 0
*               Invalid_boole if phit is not True or False
*               Invalid_knocktype if phit is True and btype is not
*                   either UP_IN or DOWN_IN
*               If the content of poff is invalid an error message
*                   from Validate_PAYOFFINF() is returned
*
*   diagnostics
*
*   see also    TOUCHDIGINF
*
*************************************************************************
,,EOH,,*/


VALIDATE Validate_TOUCHDIGINF(TOUCHDIGINF* t)
{
    VALIDATE v ;

    if (!Validate_KNOCKTYPE(t->btype))
        return Invalid_knocktype ;

    if (t->barrier < -valid_tol)
        return Invalid_barrier ;

    if (!Validate_BOOLE(t->phit))
        return Invalid_boole ;

    if (t->phit == True && (t->btype != UP_IN && t->btype != DOWN_IN))
        return Invalid_knocktype ;

    v = Validate_PAYOFFINF(&t->poff) ;
    if (v != Valid_data)
        return v ;

    return Valid_data ;
}


/*,,SOH,,
*************************************************************************
*
*               Validate_FWDSTARTINF()
*
*   interface   #include <optvalid.h>
*               VALIDATE Validate_FWDSTARTINF(FWDSTARTINF *f,
*                                             DATESTR     *fix,
*                                             BOOLE       val_dates) ;
*
*   general     This function validates the content of the FWDSTARTINF
*               data structure
*
*   input       FWDSTARTINF *f          The FWDSTARTINF data structure
*               DATESTR     *fix        The fixing date of the option
*               BOOLE       val_dates   If val_dates is True dset must
*                                       be earlier than or equal to fix
*                                       If val_dates is False fix is
*                                       used
*
*   output
*
*   returns     Valid_data if the content of FWDSTARTINF is valid,
*               Invalid_date if dset is an invalid date
*               Dset_after_dfix if val_dates is True and dset is later
*                   than fix
*               Invalid_alpha if alpha is <= 0
*
*   diagnostics
*
*   see also    FWDSTARTINF
*
*************************************************************************
,,EOH,,*/

VALIDATE Validate_FWDSTARTINF(FWDSTARTINF* f, DATESTR* fix, BOOLE val_dates)
{
    BOOLE ok = False ;

    ok = Cldr_CheckDate(&f->dset) ;
    if (ok == False)
        return Invalid_date ;

    if (val_dates == True && Cldr_DateLE(&f->dset, fix) == False)
        return Dset_after_dfix ;

    if (f->alpha <= -valid_tol)
        return Invalid_alpha ;

    return Valid_data ;
}



/*,,SOH,,
*************************************************************************
*
*               Validate_ASIANINF()
*
*   interface   #include <optvalid.h>
*                VALIDATE Validate_ASIANINF(ASIANINF *a,
*                                           DATESTR  *fix,
*                                           BOOLE    val_dates)
*
*   general     This function validates the content of the ASIANINF
*               data structure
*
*   input       ASIANINF *a        The ASIANINF data structure
*               DATESTR  *fix      The fixing date of the option
*               BOOLE    val_dates If val_dates is True davg1 and davgN
*                                  are validated, otherwise not
*
*   output
*
*   returns     Valid_data if the content of ASIANINF is valid,
*               Invalid_date if davg1 or davgN are invalid dates
*               Davg1_after_davgN if davg1 is later than davgN
*               DavgN_after_dfix if davgN is later than fix
*               invalid_boole if avrt is not True or False
*               Invalid_num_avg if avgrt is True and num_avg <= 0
*
*   diagnostics
*
*   see also    ASIANINF
*
*************************************************************************
,,EOH,,*/


VALIDATE Validate_ASIANINF(ASIANINF* a, DATESTR* fix, BOOLE val_dates)
{
    BOOLE ok = False ;

    if (val_dates == True)
    {
        ok = Cldr_CheckDate(&a->davg1) ;
        ok = ok && Cldr_CheckDate(&a->davgN) ;
        if (ok == False)
            return Invalid_date ;

        if (Cldr_DateLE(&a->davg1, &a->davgN) == False)
            return Davg1_after_davgN ;

        if (Cldr_DateLE(&a->davgN, fix) == False)
            return DavgN_after_dfix ;
    }

    if (!Validate_BOOLE(a->avgrt))
        return Invalid_boole ;

    if (a->avgrt == True && a->num_avg <= -valid_tol)
        return Invalid_num_avg ;

    return Valid_data ;
}



/*,,SOH,,
*************************************************************************
*
*               Validate_CHOOSERINF()
*
*   interface   #include <optvalid.h>
*               VALIDATE Validate_CHOOSERINF(CHOOSERINF *c,
*                                            DATESTR    *fix,
*                                            BOOLE      val_dates) ;
*
*   general     This function validates the content of the CHOOSERINF
*               data structure
*
*   input       CHOOSERINF  *c          The CHOOSERINF data structure
*               DATESTR     *fix        The fixing date of the option
*               BOOLE       val_dates   If val_dates is True dchoose must*
*                                       be earlier than or equal to fix
*                                       If val_dates is False fix is
*                                       used
*
*   output
*
*   returns     Valid_data if the content of CHOOSERINF is valid,
*               Invalid_date if dchoose is an invalid date
*               Dchoose_after_dfix if val_dates is True and davgN is
*                   later than fix
*
*   diagnostics
*
*   see also    CHOOSERINF
*
*************************************************************************
,,EOH,,*/


VALIDATE Validate_CHOOSERINF(CHOOSERINF* c, DATESTR* fix, BOOLE val_dates)
{
    BOOLE ok = False ;

    ok = Cldr_CheckDate(&c->dchoose) ;

    if (ok == False)
        return Invalid_date ;

    if (val_dates == True && Cldr_DateLE(&c->dchoose, fix) == False)
        return Dchoose_after_dfix ;

    return Valid_data ;
}


/*,,SOH,,
*************************************************************************
*
*               Validate_OPTADD()
*
*   interface   #include <optvalid.h>
*               BOOLE Validate_OPTADD(OPTADD o)
*
*   general     This function validates the content of the OPTADD
*               data structure
*
*   input       OPTADD    o       The OPTADD data structure
*
*   output
*
*   returns     True if o is a valid OPTADD, False if invalid
*
*   diagnostics
*
*   see also    OPTADD
*
*************************************************************************
,,EOH,,*/

BOOLE Validate_OPTADD(OPTADD o)
{
    /* check that o is valid */
    switch (o)
    {
        case NO_OPTADD :
        case CHOOSER :
        case LOOKBACK :
        case ASIAN :
        case BARRIER :
        case FWDSTART :
        case TOUCHDIG :
        case BINARY :
        case CONTPREM :
        case COMPOPT :
        case DOUBLKO :
        case RESET :
        case SWPTBARR :
        case SHARKFIN :
        case LADDER :
        case TSWITCH :
        case CORRIDOR :
        case FLEXICAP :
            return True ;
        default :
            return False ;
    }
}


/*,,SOH,,
*************************************************************************
*
*               Validate_KNOCKTYPE()
*
*   interface   #include <optvalid.h>
*               BOOLE Validate_KNOCKTYPE(KNOCKTYPE k)
*
*   general     This function validates the content of the KNOCKTYPE
*               data structure
*
*   input       KNOCKTYPE    k    The KNOCKTYPE data structure
*
*   output
*
*   returns     True if k is a valid KNOCKTYPE, False if invalid
*
*   diagnostics
*
*   see also    KNOCKTYPE
*
*************************************************************************
,,EOH,,*/


BOOLE Validate_KNOCKTYPE(KNOCKTYPE k)
{
    /* check that k is valid */
    switch (k)
    {
        case UP_IN :
        case UP_OUT :
        case DOWN_IN :
        case DOWN_OUT :
            return True ;
        default :
            return False ;
    }
}


/*,,SOH,,
*************************************************************************
*
*               Validate_PAYOFF()
*
*   interface   #include <optvalid.h>
*               BOOLE Validate_PAYOFF(PAYOFF p)
*
*   general     This function validates the content of the PAYOFF
*               data structure
*
*   input       PAYOFF    p       The PAYOFF data structure
*
*   output
*
*   returns     True if p is a valid PAYOFF, False if invalid
*
*   diagnostics
*
*   see also    PAYOFF
*
*************************************************************************
,,EOH,,*/


BOOLE Validate_PAYOFF(PAYOFF p)
{
    /* check that k is valid */
    switch (p)
    {
        case OP_VANILLA :
        case OP_BINARY :
        case OP_ASSETON :
        case OP_GAP    :
            return True ;
        default :
            return False ;
    }
}


/*,,SOH,,
*************************************************************************
*
*               Validate_OPTFUT()
*
*   interface   #include <optvalid.h>
*               VALIDATE Validate_OPTFUT(OPTFUT *o)
*
*   general     This function validates the content of the OPTFUT
*               data structure.
*
*   input       OPTFUT *o         The OPTFUT data structure
*
*   output
*
*   returns     Valid_data if the content of OPTFUT is valid,
*               Invalid_opttype if type is an invalid OPTTYPE
*               Invalid_fixing if dfix is an invalid DATESTR
*               Invalid_paying if dpay is an invalid DATESTR
*               Dpay_before_dfix if dpay is earlier than dfix
*               Invalid_premiumtype if ptype is an invalid PREMIUMTYPE
*               Invalid_optadd if oadd is an invalid OPTADD
*               If the content of chos is invalid an error message
*                   from Validate_CHOOSERINF() is returned
*               If the content of lbi is invalid an error message
*                   from Validate_LOOKBACKINF() is returned
*               If the content of barr is invalid an error message
*                   from Validate_BARRIERINF() is returned
*               If the content of asian is invalid an error message
*                   from Validate_ASIANINF() is returned
*               If the content of fwdst is invalid an error message
*                   from Validate_FWDSTARTINF() is returned
*               If the content of tdi is invalid an error message
*                   from Validate_TOUCHDIGINF() is returned
*               If the content of bini is invalid an error message
*                   from Validate_BINARYINF() is returned
*               If the content of ctp is invalid an error message
*                   from Validate_CONTPREMINF() is returned
*               If the content of compo is invalid an error message
*                   from Validate_COMPOPTINF() is returned
*               If the content of dko is invalid an error message
*                   from Validate_DOUBLKOINF() is returned
*               If the content of lad is invalid an error message
*                   from Validate_LADDERINF() is returned
*               If the content of lad is invalid an error message
*                   from Validate_TSWITCHINF() is returned
*               If the content of lad is invalid an error message
*                   from Validate_CORRIDORINF() is returned
*
*   diagnostics
*
*   see also    OPTFUT
*
*************************************************************************
,,EOH,,*/

VALIDATE Validate_OPTFUT(OPTFUT* o)
{
    VALIDATE v ;

    if (!Validate_OPTTYPE(o->type))
        return Invalid_opttype ;
    if (!Cldr_CheckDate(&o->dfix))
        return Invalid_fixing ;
    if (!Cldr_CheckDate(&o->dpay))
        return Invalid_paying ;
    if (Cldr_DateLE(&o->dfix, &o->dpay) == False)
        return Dpay_before_dfix ;
    if (!Validate_PREMIUMTYPE(o->ptype))
        return Invalid_premiumtype ;
    if (Validate_OPTADD(o->oadd) == True)
    {
        switch (o->oadd)
        {
            case NO_OPTADD:
                break ;

            case CHOOSER:
                v = Validate_CHOOSERINF(&o->chos, &o->dfix, True) ;
                if (v != Valid_data)
                    return v ;

                break ;

            case LOOKBACK:
                v = Validate_LOOKBACKINF(&o->lbi) ;
                if (v != Valid_data)
                    return v ;
                break ;

            case BARRIER:
                v = Validate_BARRIERINF(&o->barr) ;
                if (v != Valid_data)
                    return v ;

                break ;

            case ASIAN:
                v = Validate_ASIANINF(&o->asian, &o->dfix, True) ;
                if (v != Valid_data)
                    return v ;

                break ;

            case FWDSTART:
                v = Validate_FWDSTARTINF(&o->fwdst, &o->dfix, True) ;
                if (v != Valid_data)
                    return v ;

                break ;

            case TOUCHDIG:
                v = Validate_TOUCHDIGINF(&o->tdi) ;
                if (v != Valid_data)
                    return v ;

                break ;

            case BINARY :
                v = Validate_BINARYINF(&o->bini) ;
                if (v != Valid_data)
                    return v ;

                break ;

            case CONTPREM:
                v = Validate_CONTPREMINF(&o->ctp) ;
                if (v != Valid_data)
                    return v ;

                break ;

            case COMPOPT:
                v = Validate_COMPOPTINF(&o->compo) ;
                if (v != Valid_data)
                    return v ;

                break ;

            case DOUBLKO:
                v = Validate_DOUBLKOINF(&o->dko) ;
                if (v != Valid_data)
                    return v ;

                break ;

            case LADDER:
                v = Validate_LADDERINF(&o->lad) ;
                if (v != Valid_data)
                    return v ;

                break ;

            case TSWITCH:
                v = Validate_TSWITCHINF(&o->tswi) ; 
                if (v != Valid_data)
                    return v ;

                break ;


            case CORRIDOR:
                v = Validate_CORRIDORINF(&o->cor) ;
                if (v != Valid_data)
                    return v ;

                break ;

            default:
                ;
        }
    }
    else
        return Invalid_optadd ;

    return Valid_data ;
}


/*,,SOH,,
***********************************************************************
*                                                                      
*               Validate_OPTCT()
*                                                                      
*   interface   #include <optvalid.h>                                  
*               VALIDATE Validate_OPTCT(OPTCT *x)
*                                                                      
*   general     This function validates the content of the OPTCT
*               data structure                                         
*                                                                      
*   input       OPTCT *x   The OPTCT structure.
*                                                                      
*   output                                                             
*                                                                      
*   returns     Valid_data if the content of OPTCT is 
*               valid.
*                                                                      
*   diagnostics
*               Refer to OPTCT for a specification of valid data.
*              
*   see also    OPTCT
*                                                                      
***********************************************************************
,,EOH,,*/
VALIDATE Validate_OPTCT(OPTCT*  x)
{
    VALIDATE v;

    if (Validate_OPTTYPE(x->type) == False)
        return Invalid_opttype;

    if (Cldr_CheckDate(&x->dfix) == False)
        return Invalid_date ;

    if (Cldr_CheckDate(&x->dpay) == False)
        return Invalid_date ;

    if (Validate_PREMIUMTYPE(x->ptype) == False)
        return Invalid_premiumtype;

    if (Validate_CALCONV(x->cal) == False)
        return Invalid_cal;

    if (Validate_CTTYPE(x->cttype) == False)
        return Invalid_cttype;

    v = Validate_QUANTOINF(&x->quanto);
    if (v != Valid_data)
        return v;

    return Valid_data;
}


/*,,SOH,,
************************************************************************
*                                                                       
*               Validate_OPTFUTARRAY()                                
*                                                                       
*   interface   #include <optvalid.h>                                   
*               VALIDATE Validate_OPTFUTARRAY(OPTFUTARRAY  cm,      
*                                             INTI n)                   
*                                                                       
*   general     This function validates the content of the 
*               OPTFUTARRAY data structure
*                                                                       
*   input       OPTFUTARRAY cm     The OPTFUTARRAY data structure   
*               INTI        n      The size of the array                
*                                                                       
*   output                                                              
*                                                                       
*   returns     Valid_data if the content of OPTFUT is valid,           
*                                                                       
*   diagnostics                                                         
*                                                                       
*   see also    OPTFUTARRAY                                           
*                                                                       
************************************************************************
,,EOH,,*/


VALIDATE Validate_OPTFUTARRAY(OPTFUTARRAY cm, INTI n)
{
    VALIDATE v = Valid_data ;
    INTI i ;

    for (i = 0; i < n && v == Valid_data; i++)
        v = Validate_OPTFUT(&cm[i]) ;

    return v ;
}



/*,,SOH,,
*************************************************************************
*
*               Validate_OPTTYPE()
*
*   interface   #include <optvalid.h>
*               BOOLE Validate_OPTTYPE(OPTTYPE o)
*
*   general     This function validates the content of the OPTTYPE
*               data structure
*
*   input       OPTTYPE    o      The OPTTYPE data structure
*
*   output
*
*   returns     True if o is a valid OPTTYPE, otherwise False
*
*   diagnostics
*
*   see also    OPTTYPE
*
*************************************************************************
,,EOH,,*/


BOOLE Validate_OPTTYPE(OPTTYPE o)
{
    switch (o)
    {
        case CALL:
        case PUT:
        case STRADDLE:
            return True ;
        default:
            return False ;
    }
}



/*,,SOH,,
***********************************************************************
*                                                                      
*               Validate_QUANTOINF()
*                                                                      
*   interface   #include <optvalid.h>                                  
*               VALIDATE Validate_QUANTOINF(QUANTOINF *x)
*                                                                      
*   general     This function validates the content of the QUANTOINF
*               data structure                                         
*                                                                      
*   input       QUANTOINF *x   The QUANTOINF structure.
*                                                                      
*   output                                                             
*                                                                      
*   returns     Valid_data if the content of QUANTOINF is 
*               valid.
*                                                                      
*   diagnostics
*               Refer to QUANTOINF for a specification of valid data.
*              
*   see also    QUANTOINF
*                                                                      
***********************************************************************
,,EOH,,*/
VALIDATE Validate_QUANTOINF(QUANTOINF*  x)
{
    /* warning avoidance */
    x = NULL ;

    return Valid_data;
}




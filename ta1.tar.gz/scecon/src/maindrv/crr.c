/* SCID @(#)crr.c	1.15 (SimCorp) 99/10/27 14:29:48 */

/************************************************************************
*
*   project     SCecon
*
*   filename    crr.c
*
*   contains    routines in the SCecon Library Options price
*               module to calculate options prices and risk ratios
*               based on the Cox/Ross/Rubinstein model.
*
************************************************************************/

/*** includes **********************************************************/
#include <option.h>


/*** defines  **********************************************************/
#define DAY_TOL   0.001
#define SHOCKSIZE 0.01
#define F64_TOL   0.00000001
#define ACC_PRICE 0.000001
#define ACC_RATE  0.0000001
#define ACC_TERM  0.000000001
#define LOW_BOUND 0.0001
#define VOL_GUESS 15
#define MAXIT     100


/*,,SOH,,
*************************************************************************
*
*               Clb_CRR2Tree()
*
*    interface  #include <option.h>
*               BINTREEARRAY Clb_CRR2Tree(INTI     n,
*                                          FL64     sigma,
*                                          FL64     s0,
*                                          DATESTR  *today,
*                                          DATESTR  *expiry,
*                                          CALCONV  cal,
*                                          PLAN_STR *div) ;
*
*    general    Clb_CRR2Tree() calibrates a binomial tree using the
*               Cox, Ross & Rubinstein model.
*
*               The tree is in the spot price of the stock, index,
*               commodity or ....
*
*    input      INTI     n      Number of steps in the lattice.
*                               The tree is generated with steps
*                               0, 1, ...., n
*
*               FL64     sigma  The volatility of the price of the
*                               spot instrument in annual percent.
*
*               FL64     s0     The initial spot price
*
*               DATESTR  *today The valuation date.
*
*               DATESTR  *expiry The last date in the tree.
*                               This should be choosen as the expiry of
*                               the option, when used for option
*                               valuation.
*
*               CALCONV  cal    Calendar convention.
*
*               PLAN_STR *div   Reference to payment struct containing
*                               dividend payments from the underlying
*                               stock, quoted in percent.
*                               These dividend quotes are equivalent
*                               to discrete-time dividends.
*                               There can only be 1 dividend payment
*                               per period in the tree.
*
*	       	  HOLI_STR  *holi   Container for list of holidays.
*
*    output
*
*    returns    Pointer to allocated binomial tree. Allocated as:
*               Alloc_BINTREARRAY(1, n + 1)
*
*    diagnostics
*
*    see also    OptFX_CRR2P()
*                OptEqty_CRR2P()
*                OptCmdty_CRR2P()
*
*************************************************************************
,,EOH,,*/

BINTREEARRAY Clb_CRR2Tree(INTI  n,
                           FL64     sigma,
                           FL64     s0,
                           DATESTR*  today,
                           DATESTR*  expiry,
                           CALCONV  cal,
                           PLAN_STR* div,
						   HOLI_STR* holi)
{
    INTI         fill, j, i ;
    FL64         up, down, term, *pmt, *time, *price0, *scale, scale1, t1, dt,
                 termb ;
    DATESTR      *divday ;
    BINTREEARRAY crr ;

    Math_LaGuerre(today->y, today->m, today->d);

    /* 1. Find the time spacing in the model and the period rate */
    t1 = Cldr_TermBetweenDates(today, expiry, 0, cal, SAME, holi) ; 	/* PMSTA-22396 - SRIDHARA � 160502 */
    dt = t1 / (FL64) n ;

    /* 2. Set up the up/down factors */
    up   = crr_vol2factor(sigma, dt) ;
    down = 1.0 / up ;

    /* 3. Now do the calibration one step at a time, first put data in the
          first level */
    crr    = Alloc_BINTREEARRAY(1, n + 1) ;
    time   = crr->time ;
    price0 = crr->f64 ;
    scale  = crr->scale ;
    crr->nlevel = n ;

    divday = GetPlanDay(div) ;
    pmt    = GetPlanF64(div) ;
    fill   = GetPlanFill(div) ;

    time[0]   = 0.0 ;
    price0[0] = s0 ;
    scale[0]  = 1.0 ,
    j         = Cldr_FindDateIndex(divday, fill, today, 0, SEARCH_FORWARDS,
                                    NEXTINDEX) ;
    termb = term = 0.0 ;
    if (fill > 0 && j < fill)
        termb = term = Cldr_TermBetweenDates(today, &divday[j], 0, cal, SAME, holi) ; 	/* PMSTA-22396 - SRIDHARA � 160502 */
    if (j > 0 && fill > 0)
        termb = Cldr_TermBetweenDates(today, &divday[j - 1], 0, cal, SAME, holi) ; 	/* PMSTA-22396 - SRIDHARA � 160502 */

    for (i = 1 ; i <= n ; i++)
    {
        t1     = dt * (FL64) i ;
        scale1 = up ;

        /* Are there any dividend payments in the period ?? */
        if (j < fill && term <= t1 + DAY_TOL &&
           ((j > 0 && t1 >= termb + DAY_TOL) || j == 0))
        {
            scale1 *= 1.0 - pmt[j]/100.0 ;
            if (++j < fill)
                term = Cldr_TermBetweenDates(today, &divday[j], 
                                              0, cal, SAME, holi) ; 	/* PMSTA-22396 - SRIDHARA � 160502 */
            if (j > 0)
                termb = Cldr_TermBetweenDates(today, &divday[j - 1],
                                              0, cal, SAME, holi) ; 	/* PMSTA-22396 - SRIDHARA � 160502 */
        }

        time[i]   = t1 ;
        price0[i] = price0[i - 1] * scale1 ;
        scale[i]  = SQR(down) ;
    }

    return crr ;
}


/*,,SOH,,
*************************************************************************
*
*               Alloc_BINTREEARRAY()
*
*    interface  #include <option.h>
*               BINTREEARRAY Alloc_BINTREEARRAY(INTI ntree,
*                                               INTI nlevel) ;
*
*    general    Alloc_BINTREEARRAY() allocates ntree BINTREE's
*
*    input      INTI    ntree  The number of trees.
*
*               INTI    nlevel The number of levels.
*
*    output
*
*    returns    reference to the allocated tree.
*
*    diagnostics call to SCecon_error() with the arguments
*                     Message        "Allocation failed"
*                     Function       "Alloc_BINTREEARRAY()"
*                     Action         SCECONABORT
*
*                if allocation fails.
*
*    see also    Free_BINTREEARRAY()
*
*************************************************************************
,,EOH,,*/


BINTREEARRAY Alloc_BINTREEARRAY(INTI ntree, INTI nlevel)
{
    BINTREEARRAY a ;
    INTI     i ;

    a = (BINTREEARRAY) SCecon_calloc(ntree, sizeof(BINTREE), True,
      "Alloc_BINTREEARRAY()") ;

    for (i = 0 ; i < ntree ; i++)
    {
        a[i].time  = Alloc_FL64ARRAY(nlevel + 1) ;
        a[i].f64   = Alloc_FL64ARRAY(nlevel + 1) ;
        a[i].scale = Alloc_FL64ARRAY(nlevel + 1) ;
    }

    return a ;
}

/*,,SOH,,
*************************************************************************
*
*               Free_BINTREEARRAY()
*
*    interface  #include <option.h>
*               void Free_BINTREEARRAY(BINTREEARRAY s,
*                                      INTI         ntree) ;
*
*    general    Free_BINTREEARRAY() frees a BINTREEARRAY allocated with
*               Alloc_BINTREEARRAY().
*
*    input      BINTREEARRAY  s     Reference to the tree allocated by
*                                   Alloc_BINTREEARRAY().
*
*               INTI          ntree The number of trees allocated.
*    output
*
*    returns
*
*    diagnostics
*
*    see also   Alloc_BINTREEARRAY()
*
*************************************************************************
,,EOH,,*/


void Free_BINTREEARRAY(BINTREEARRAY s, INTI ntree)
{
    INTI     i ;
    BINTREE *t ;

    t = s ;

    ntree  = GETMAX(1, ntree) ;

    for (i = 0 ; i < ntree ; i++)
    {
        Free_FL64ARRAY(t[i].time) ;
        Free_FL64ARRAY(t[i].f64) ;
        Free_FL64ARRAY(t[i].scale) ;
    }

    SCecon_free((VOIDPTR) s) ;
}


/*
..
CRR_premium() computes the options price using the
Cox, Ross & Rubinstein model.
In addition some risk measures are computed for the
option.
The parameters wrt and risk describes what is to be
computed, the following value are possible:

     wrt                  risk

                          FIRST_ORDER   SECOND_ORDER
     -----------------    -----------   ------------
     KEY_PRICE               delta       gamma
     KEY_REPO                rho         d(rho)/d(r)
     KEY_VOL                 eta         d(eta)/d(v)
     KEY_MATURITY            theta       d(theta)/d(t)
     KEY_FIRSTDELIVERY       zeta        d(zeta)/d(t)
     KEY_STRIKE              alfa          %
     KEY_BPV                 BPV           %
     KEY_DF                  $Duration   $Convexity
     -----------------    -----------   ------------

If something goes wrong during the calculation then
False is returned. Essentially this can only happen if
unrealistic probabilities occur.
*/

/* WARNING: TOO MANY ARGS (>15) BELOW */
BOOLE CRR_premium(BINTREE *crra, DATESTR *today, DATESTR *dfrom, DATESTR *dto,
                  PERIOD pd, FL64 e, FL64 vol, TS_STR *ts, INTPOLCONV its,
                  OPTTYPE type, TS_STR *fts, INTPOLCONV ifts,
                  PLAN_STR *div, KEYCONV wrt, RISKCONV risk, FL64 size, CALCONV
                    cal,
                  FL64 *p, FL64 *dp, FL64 *ddp)
{
    FL64         factor, val, prob, wait, *price, rp, plo = 0, phi = 0, dpy ;
    FL64         dt, s0, u, d, delta, gamma, x1, x2, *time, *scale,
                 ra, *price0, to, from, t1, delay, rd ;
    INTI         up, i, j, n ;
    BOOLE        ok, before ;
    BINTREEARRAY crr1a ;
    DATESTR      dto1, dfrom1, pday ;
    HOLI_STR     holi ;

    /* Initialize */
    delta = gamma = *p = *dp = *ddp = 0.0 ;
    ok    = True ;
		    
    holi.nholi = 0 ;
    holi.bus = NO_BUSADJUST ;

	/* PMSTA-22396 - SRIDHARA � 160502 */
	to = Cldr_TermBetweenDates(today, dto, 0, cal, SAME, &holi);
	from = Cldr_TermBetweenDates(today, dfrom, 0, cal, SAME, &holi);

    /* Find the period rate, and set up other variables */
    n      = crra->nlevel ;
    price0 = crra->f64 ;
    scale  = crra->scale ;
    time   = crra->time ;

    dt   = time[1] ;
    u    = crr_vol2factor(vol, dt) ;
    d    = 1.0 / u ;
    s0   = price0[0] ;

/*..perhaps this should be moved to the calibration routine... */
    /* adjust prices for discounting and foreign term structure */
/*..put back later
    for (i = 1, factor = 1.0; i <= n; i++)
    {
        t1 = time[i] ;
        factor *= CRR_Rpcalc(t1, dt, fts, ts, &rp) ;
        price0[i] *= factor ;
    }
*/
    /* Memory for holding prices in the tree */
    price = Alloc_FL64ARRAY(n + 2) ;

    /* Find the last active level in the tree */
    for (i = n ; i >= 0 ; i--)
    {
        if ((time[i] - DAY_TOL) < to)
            break ;
    }

    up = i ;

    /* calculate the probability for an 'up' move */
/*
    prob = 1.0 / (1 + u) ;
*/
    /* Now loop over all the levels and generate the price tree */
    for (i = up ; ok == True && i >= 0 ; i--)
    {
       factor = 1.0 ;
       before = ((time[i] >= (from - DAY_TOL)) ? False : True);

       /* Get the discount factor 'rp' for the i'th step */
       t1 = time[i] ;
       ra = CRR_Rpcalc(t1, dt, fts, ifts, ts, its, &rp) ;

       prob = ((u - d) ? (ra - d) / (u - d) : 0.5) ;
       if (prob > 1.0 || prob < 0.0)
           ok = False ;

       /* find the payment date if exercised at time[i] */
       pday = Cldr_Term2Date(today, t1, YEARS, cal, SAME) ;
       pday = Cldr_TermUnit2Date(&pday, pd.num, pd.unit, cal, SAME, &holi) ;
       delay = Cldr_TermBetweenDates(today, &pday, 0, cal, SAME, &holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
       delay -= t1 ;
       ra = CRR_Rpcalc(t1, delay, fts, its, ts, ifts, &rd) ;

       for (j = 0 ; ok == True && j <= i ; j++)
       {
           wait = (prob * price[j] + (1.0 - prob) * price[j + 1]) / rp ;

           /* Are we before first expiration ?? */
           if (ok == True && before == False)
           {
               /* We are still in the exercise period */
               val     = price0[i] * factor - e ;
               val       /= rd ;
               factor *= scale[i] ;
               val    *= (type == PUT ? -1.0 : 1.0) ;
               val     = GETMAX(val, 0.0) ;
           }
           else
               val = 0.0 ;

           price[j] = GETMAX(val, wait) ;
       }

       if (ok == True && i == 1 && risk != ZERO_ORDER && wrt == KEY_PRICE)
       {
           delta = price0[1] * (1.0 - scale[1]) ;
           delta = (delta > F64_TOL ? (price[0] - price[1]) / delta : 0.0) ;
       }
    }

    /* Clean up */
    *p = price[0] ;
    Free_FL64ARRAY(price) ;

    /* Now find the risk ratios - if desired */
    if (ok == False || risk == ZERO_ORDER)
        return ok ;

    switch (wrt)
    {
        case KEY_PRICE:

            size = Scutl_Default_Shock(size, wrt) ;

            /* This derivative is different because the price is piecewise
               linear in the price of the underlying. */
            if (risk == SECOND_ORDER)
            {
                crr1a = Clb_CRR2Tree(n, vol, s0 + size, today, dto, cal, div, &holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
                ok    = CRR_premium(crr1a, today, dfrom, dto, pd, e, vol, ts,
                                    its, type, fts, ifts, div, KEY_PRICE, 
                                    FIRST_ORDER, size, cal, &plo, &x1, &x2) ;
                gamma = (x1 - delta)/size ;
                Free_BINTREEARRAY(crr1a, 1) ;
            }
            break ;

        case KEY_REPO:
        case KEY_BPV:
        case KEY_DF:

            size = Scutl_Default_Shock(size, wrt) ;

            crr1a = Clb_CRR2Tree(n, vol, s0, today, dto, cal,  div, &holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
            Yld_Shock_Rates(ts, PARALLEL, - size) ;
            ok = CRR_premium(crr1a, today, dfrom, dto, pd, e, vol, ts, its,
                             type, fts, ifts, div, KEY_REPO, ZERO_ORDER, 
                             size, cal, &plo, &x1, &x2) ;
            Yld_Shock_Rates(ts, PARALLEL, 2.0 * size) ;
            ok = CRR_premium(crr1a, today, dfrom, dto, pd, e, vol, ts, its,
                             type, fts, ifts, div, KEY_REPO, ZERO_ORDER, size, 
                             cal, &phi, &x1, &x2) ;
            Yld_Shock_Rates(ts, PARALLEL, -size) ;
            Free_BINTREEARRAY(crr1a, 1) ;
            break ;

        case KEY_VOL:

            size = Scutl_Default_Shock(size, wrt) ;

            crr1a = Clb_CRR2Tree(n, vol - size, s0, today, dto, cal,  div, &holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
            ok = CRR_premium(crr1a, today, dfrom, dto, pd, e, vol-size, ts,
                             its, type, fts, ifts, div, KEY_VOL, ZERO_ORDER, 
                             size, cal, &plo, &x1, &x2) ;
            Free_BINTREEARRAY(crr1a, 1) ;
            crr1a = Clb_CRR2Tree(n, vol + size, s0, today, dto, cal, div, &holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
            ok = CRR_premium(crr1a, today, dfrom, dto, pd, e, vol+size, ts,
                             its, type, fts, ifts, div, KEY_VOL, ZERO_ORDER, 
                             size, cal, &phi, &x1, &x2) ;
            Free_BINTREEARRAY(crr1a, 1) ;
            break ;

        case KEY_FIRSTDELIVERY:

            size = Scutl_Default_Shock(size, wrt) ;

            if (Cldr_DateEQ(dfrom, dto) == True)
            {
                dfrom1 = dto1 = Cldr_AddDays(dfrom, (INTL) -size, cal, &holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
                crr1a  = Clb_CRR2Tree(n, vol, s0, today, &dto1, cal, div, &holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
                ok     = CRR_premium(crr1a, today, &dfrom1, &dto1, pd, e, vol,
                                     ts, its, type, fts, ifts, div, 
                                     KEY_FIRSTDELIVERY, ZERO_ORDER,
                                     size, cal, &plo, &x1, &x2) ;
                Free_BINTREEARRAY(crr1a, 1) ;

                dfrom1 = dto1 = Cldr_AddDays(dfrom, (INTL) size, cal, &holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
                crr1a  = Clb_CRR2Tree(n, vol, s0, today, &dto1, cal, div, &holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
                ok     = CRR_premium(crr1a, today, &dfrom1, &dto1, pd, e, vol,
                                     ts, its, type, fts, ifts, div, 
                                     KEY_FIRSTDELIVERY, ZERO_ORDER,
                                     size, cal, &phi, &x1, &x2) ;
                Free_BINTREEARRAY(crr1a, 1) ;
            }
            else
            {
                dfrom1 = Cldr_AddDays(dfrom, (INTL) -size, cal, &holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
                crr1a  = Clb_CRR2Tree(n, vol, s0, today, dto, cal, div, &holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
                ok     = CRR_premium(crr1a, today, &dfrom1, dto, pd, e, vol,
                                     ts, its, type, fts, ifts, div, 
                                     KEY_FIRSTDELIVERY, ZERO_ORDER,
                                     size, cal, &plo, &x1, &x2) ;
                Free_BINTREEARRAY(crr1a, 1) ;

                dfrom1 = Cldr_AddDays(dfrom, (INTL) size, cal, &holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
                crr1a  = Clb_CRR2Tree(n, vol, s0, today, dto, cal, div, &holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
                ok     = CRR_premium(crr1a, today, &dfrom1, dto, pd, e, vol,
                                     ts, its, type, fts, ifts, div, 
                                     KEY_FIRSTDELIVERY, ZERO_ORDER,
                                     size, cal, &phi, &x1, &x2) ;
                Free_BINTREEARRAY(crr1a, 1) ;
            }

            dpy   = (FL64) Cldr_DaysPerYear(today, today, 0, cal, LAST, &holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
            size /= dpy ;

            break ;

        case KEY_MATURITY:

            size = Scutl_Default_Shock(size, wrt) ;

            if (Cldr_DateEQ(dfrom, dto) == True)
            {
				/* PMSTA-22396 - SRIDHARA � 160502 */
                dfrom1 = dto1 = Cldr_AddDays(dfrom, (INTL) -size, cal, &holi) ;
                crr1a  = Clb_CRR2Tree(n, vol, s0, today, &dto1, cal, div, &holi) ;
                ok     = CRR_premium(crr1a, today, &dfrom1, &dto1, pd, e, vol,
                                     ts, its, type, fts, ifts, div, 
                                     KEY_MATURITY, ZERO_ORDER,
                                     size, cal, &plo, &x1, &x2) ;
                Free_BINTREEARRAY(crr1a, 1) ;

				/* PMSTA-22396 - SRIDHARA � 160502 */
                dfrom1 = dto1 = Cldr_AddDays(dfrom, (INTL) size, cal, &holi) ;
                crr1a  = Clb_CRR2Tree(n, vol, s0, today, &dto1, cal, div, &holi) ;
                ok     = CRR_premium(crr1a, today, &dfrom1, &dto1, pd, e, vol,
                                     ts, its, type, fts, ifts, div, 
                                     KEY_MATURITY, ZERO_ORDER,
                                     size, cal, &phi, &x1, &x2) ;
                Free_BINTREEARRAY(crr1a, 1) ;
            }
            else
            {
				/* PMSTA-22396 - SRIDHARA � 160502 */
                dto1   = Cldr_AddDays(dto, (INTL) -size, cal, &holi) ;
                crr1a  = Clb_CRR2Tree(n, vol, s0, today, &dto1, cal, div, &holi) ;
                ok     = CRR_premium(crr1a, today, dfrom, &dto1, pd, e, vol,
                                     ts, its, type, fts, ifts,div, 
                                     KEY_MATURITY, ZERO_ORDER,
                                     size, cal, &plo, &x1, &x2) ;
                Free_BINTREEARRAY(crr1a, 1) ;

				/* PMSTA-22396 - SRIDHARA � 160502 */
                dto1   = Cldr_AddDays(dto, (INTL) size, cal, &holi) ;
                crr1a  = Clb_CRR2Tree(n, vol, s0, today, &dto1, cal, div, &holi) ;
                ok     = CRR_premium(crr1a, today, dfrom, &dto1, pd, e, vol,
                                     ts, its, type, fts, ifts,div, 
                                     KEY_MATURITY, ZERO_ORDER,
                                     size, cal, &phi, &x1, &x2) ;
                Free_BINTREEARRAY(crr1a, 1) ;
            }

            dpy   = (FL64) Cldr_DaysPerYear(today, today, 0, cal, LAST, &holi) ;  /* PMSTA-22396 - SRIDHARA � 160502 */
            size /= dpy ;

            break ;

        case KEY_STRIKE:

            size = Scutl_Default_Shock(size, wrt) ;

            ok = CRR_premium(crra, today, dfrom, dto, pd, e - size, vol, ts,
                             its, type, fts, ifts,div, KEY_STRIKE, ZERO_ORDER,
                             size, cal, &plo, &x1, &x2) ;
            ok = CRR_premium(crra, today, dfrom, dto, pd, e + size, vol, ts,
                             its, type, fts, ifts, div, KEY_STRIKE, ZERO_ORDER,
                             size, cal, &phi, &x1, &x2) ;
            break ;

        default:
            ;
    }

    if (wrt == KEY_BPV)
        *dp = (phi - plo) / 2.0 ;

    else if (wrt != KEY_PRICE && ok == True)
    {
        *dp = (phi - plo)/ (2.0 * size) ;

        /* The price is piecewise linear in the strike price !!! */
        if (wrt != KEY_STRIKE || wrt != KEY_BPV)
            *ddp = (phi + plo - (2.0 * (*p)))/SQR(size) ;
        else
            *ddp = 0.0 ;
    }

    else if (ok == True)
    {
        *dp = delta ;
        if (risk == SECOND_ORDER)
            *ddp = gamma ;
    }

    return ok ;
}


/*
..
Implied measure
---------------
KEY_PRICE
KEY_VOL
KEY_STRIKE
KEY_REPO

*/

/* WARNING: TOO MANY ARGS (>15) BELOW */
BOOLE CRR_Implied(FL64 p, DATESTR *today, DATESTR *dfrom, DATESTR *dto, 
                  PERIOD pd, INTI n, FL64 s0, FL64 e, FL64 vol, TS_STR *ts,
                  INTPOLCONV its, OPTTYPE type, TS_STR *fts, INTPOLCONV ifts,
                  PLAN_STR *div, KEYCONV what, CALCONV cal,
				  ITERCTRL *ctrl, FL64 *impl, HOLI_STR *holi)
{
    FL64    stmp, lra, ra, per, time, tmp, acc ;
    INTI    i ;
    BOOLE   ok ;
    CRRINT  y ;
    ITERCTRL ictrl ;

    /* warning avoidance */
    acc = 0.0 ;

	time = Cldr_TermBetweenDates(today, dto, 0, cal, SAME, holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */

    Init_ITERCTRL(&ictrl);

    /* Set uninitialized init_guess */
    if (ctrl->use_init_guess == False)
    {
      if ((ctrl->use_lower) && (ctrl->use_upper))
        ictrl.init_guess = 0.5*(ctrl->lower + ctrl->upper);
      else if (what == KEY_PRICE)
        ictrl.init_guess = e;
      else if (what == KEY_STRIKE)
        ictrl.init_guess = s0;
      else if (what == KEY_REPO)
        ictrl.init_guess = ts->rate[0];
      else if (what == KEY_VOL)
        ictrl.init_guess = VOL_GUESS;
    }
    else
      ictrl.init_guess = ctrl->init_guess;

    ictrl.init_guess = GETMAX(ictrl.init_guess, LOW_BOUND);
    ictrl.use_init_guess = ctrl->use_init_guess ;

    /* Set uninitialized boundaries for iteration */
    if (ctrl->use_lower == False)
    {  
      ictrl.lower = ictrl.init_guess / 1.1 ;      
      if (what == KEY_VOL)
        ictrl.lower = GETMIN(0.001, ictrl.lower);
    }
    else
      ictrl.lower = GETMIN(ctrl->lower, ictrl.init_guess);
      
    if (ctrl->use_upper == False)
    {
      ictrl.upper = ictrl.init_guess * 1.1 ;    
      if (what == KEY_VOL)
        ictrl.upper = GETMAX(100, ictrl.upper);
    }
    else
      ictrl.upper = GETMAX(ctrl->upper, ictrl.init_guess);

    if ((ctrl->use_lower == False) || (ctrl->use_upper == False))
    {
      /* Fill intermediate data container */
      y = CRR_SetCRRINT(p, s0, e, vol, ts, its, type, today,
              dfrom, dto, pd, fts, ifts, div, n, what, cal, 
              FIRST_ORDER) ;

      ok = Math_PosRootBracket(CRR_NewtonRaphson, &y, &ictrl,
        &ictrl.lower, &ictrl.upper, holi) ;  /* PMSTA-29444 - SRIDHARA - 050318 */
    }

    ictrl.use_lower = ctrl->use_lower ;
    ictrl.use_upper = ctrl->use_upper ;

    /* Set up bounds for the unknown variable + the desired accuracy */
    if (what == KEY_PRICE || what == KEY_STRIKE)
        acc = ACC_PRICE ;

    else if (what == KEY_VOL)
    {
        acc = ACC_RATE ;
        tmp = time / (FL64) n ;

        /* Here we must loop over all possible probabilities to ensure that
           non-negative probabilities never occur */
        stmp = sqrt(tmp) ;
        for (i = 0; i <= n ; i++)
        {
            ra  = CRR_Rpcalc(tmp * (FL64) i, tmp, fts, ifts, ts, its, &per) ;
            lra = 100.0 * log(ra) / stmp ;
            ictrl.lower = GETMAX(ictrl.lower, -lra) ;
            ictrl.lower = GETMAX(ictrl.lower,  lra) ;
        }

        ictrl.lower += 0.001 ;
        ictrl.init_guess = GETMAX(ictrl.lower, ictrl.init_guess);
        ictrl.upper = GETMAX(ictrl.init_guess, ictrl.upper) ;
    }
    else if (what == KEY_REPO)
    {
        acc = ACC_RATE ;
        per = time / (FL64) n ;
        tmp = GETMIN(ictrl.upper, -0.002 +
                          100.0 * (crr_vol2factor(vol, per) - 1.0)) ;
        tmp = Yld_Per2Ann(tmp, per, 1, COMPOUND) ;

        ictrl.upper  = GETMIN(ictrl.upper, tmp) ;
        ictrl.init_guess = GETMIN(ictrl.upper, ictrl.init_guess);
        ictrl.lower = GETMIN(ictrl.lower, ictrl.init_guess) ;
    }

    /* Set uninitialized ctrl->acc */
    ictrl.acc = ((ctrl->acc <= 0.0) ? acc : ctrl->acc);

    ictrl.maxiter = ((ctrl->maxiter < 0) ? MAXIT : ctrl->maxiter);
    ictrl.damp = ((ctrl->damp < 0.0) ? 1.0 : ctrl->damp);
    ictrl.what_acc = ((ctrl->what_acc < 0) ? 0 : ctrl->what_acc);
    ictrl.gfreq = ((ctrl->gfreq < 0) ? 1 : ctrl->gfreq);
    ictrl.bisec = ((ctrl->bisec < 0) ? 1 : ctrl->bisec);
    ictrl.shock = ((ctrl->shock < 0.0) ? 0.0 : ctrl->shock); 

    /* Now find the implied ratio (root) */
    ok = CRR_Root(p, s0, e, vol, ts, its, type, today, dfrom, dto, pd, fts,
                  ifts, div, n, what, cal, &ictrl, impl, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */

    return ok ;
}

/*
..
*/

/* WARNING: TOO MANY ARGS (>15) BELOW */

CRRINT CRR_SetCRRINT(FL64 pr, FL64 pu, FL64 e, FL64 vol, 
                      TS_STR *ts, INTPOLCONV its, OPTTYPE type,
                      DATESTR *today, DATESTR *dfrom, DATESTR *dto, 
                      PERIOD pd, TS_STR *fts, INTPOLCONV ifts, 
                      PLAN_STR *div, INTI n, KEYCONV what, 
                      CALCONV cal, RISKCONV risk) 
{
  CRRINT crrdata;

  crrdata.pr = pr;
  crrdata.pu = pu;
  crrdata.e = e;
  crrdata.vol = vol;
  crrdata.ts = ts;
  crrdata.its = its;
  crrdata.type = type;  
  crrdata.today = today;
  crrdata.dfrom = dfrom;
  crrdata.dto = dto;
  crrdata.pd = pd;
  crrdata.fts = fts; 
  crrdata.ifts = ifts;  
  crrdata.div = div;
  crrdata.n = n; 
  crrdata.what = what; 
  crrdata.cal = cal; 
  crrdata.risk = risk;

  return crrdata;
}

/*
..
*/

/* WARNING: TOO MANY ARGS (>15) BELOW */

void CRR_GetCRRINT(CRRINT *crrdata, 
                      FL64 *pr, FL64 *pu, FL64 *e, FL64 *vol, 
                      TS_STR **ts, INTPOLCONV *its, OPTTYPE *type,
                      DATESTR **today, DATESTR **dfrom, DATESTR **dto, 
                      PERIOD *pd, TS_STR **fts, INTPOLCONV *ifts, 
                      PLAN_STR **div, INTI *n, KEYCONV *what, 
                      CALCONV *cal, RISKCONV *risk) 
{
  *pr = crrdata->pr ;
  *pu = crrdata->pu ;
  *e = crrdata->e ;
  *vol = crrdata->vol ;
  *ts = crrdata->ts ;
  *its = crrdata->its ;
  *type = crrdata->type ;  
  *today = crrdata->today ;
  *dfrom = crrdata->dfrom ;
  *dto = crrdata->dto ;
  *pd = crrdata->pd ;
  *fts = crrdata->fts ; 
  *ifts = crrdata->ifts ;  
  *div = crrdata->div ;
  *n = crrdata->n ; 
  *what = crrdata->what ; 
  *cal = crrdata->cal ; 
  *risk = crrdata->risk ;
}

/*
..
*/
BOOLE CRR_NewtonRaphson(FL64  x, VOIDPTR  y, BOOLE  grad, FL64*  fx,
                           FL64*  dfx, VOIDPTR holi)
{
  FL64        pr, pu, e, vol; 
  TS_STR      *ts; 
  INTPOLCONV  its; 
  OPTTYPE     type;
  DATESTR     *today, *dfrom, *dto; 
  PERIOD      pd; 
  TS_STR      *fts; 
  INTPOLCONV  ifts; 
  PLAN_STR    *div; 
  INTI        n; 
  KEYCONV     what;
  CALCONV     cal; 
  RISKCONV    risk;

  CRR_GetCRRINT( (CRRINT*)y, &pr, &pu, &e, &vol, &ts, &its, &type,
                      &today, &dfrom, &dto, &pd, &fts, &ifts, &div, 
                      &n, &what, &cal, &risk) ;
  if (grad == True) 
    risk = FIRST_ORDER;
  else
    risk = ZERO_ORDER;

  return CRR_Impl_Deviation(x, pr, pu, e, vol, ts, its, type,
                      today, dfrom, dto, pd, fts, ifts, div, 
                      n, what, cal, fx, dfx, risk, (HOLI_STR*)(holi));   	/* PMSTA-22396 - SRIDHARA � 160502 */
}

/*
..
*/

/* WARNING: TOO MANY ARGS (>15) BELOW */
BOOLE CRR_Root(FL64 pr, FL64 pu, FL64 e, FL64 vol, TS_STR *ts, INTPOLCONV its,
               OPTTYPE type, DATESTR *today, DATESTR *dfrom, DATESTR *dto,
               PERIOD pd, TS_STR *fts, INTPOLCONV ifts, PLAN_STR *div, INTI n, 
			   KEYCONV what, CALCONV cal, ITERCTRL *ctrl, FL64 *rts,  HOLI_STR* holi)
{
    CRRINT y;
    NR_ERR err;
    BOOLE  ok;

    y = CRR_SetCRRINT(pr, pu, e, vol, ts, its, type, today,
              dfrom, dto, pd, fts, ifts, div, n, what, cal, 
              FIRST_ORDER) ;

    err = Newton_Raphson(&CRR_NewtonRaphson, &y, ctrl, rts, holi) ;   	/* PMSTA-22396 - SRIDHARA � 160502 */
    ok = (err == NR_ROOT_FOUND ? True : False) ;

    return ok ;
}

/*
..
*/

/* WARNING: TOO MANY ARGS (>15) BELOW */
BOOLE CRR_Impl_Deviation(FL64 x, FL64 pr, FL64 pu, FL64 e, FL64 vol, 
                         TS_STR *ts, INTPOLCONV its, OPTTYPE type,
                         DATESTR *today, DATESTR *dfrom, DATESTR *dto, 
                         PERIOD pd, TS_STR *fts, INTPOLCONV ifts, 
                         PLAN_STR *div, INTI n, KEYCONV what, CALCONV cal,
						 FL64 *y, FL64 *dy, RISKCONV risk, HOLI_STR* holi)
{
    FL64         ddy ;
    BINTREEARRAY crr1 ;
    BOOLE        ok ;
    TSARRAY      ts1 ;

    ts1 = Alloc_TSARRAY(1, 1) ;

    if      (what == KEY_PRICE)         pu   = x ;
    else if (what == KEY_VOL)           vol  = x ;
    else if (what == KEY_STRIKE)        e    = x ;
    else if (what == KEY_REPO)
    {
        ts1->conv = ts->conv ;
        ts1->qbas = ts->qbas ;
        ts1->term[0] = 1.0 ;
        ts1->rate[0] = x ;
        ts1->count   = 1 ;
    }

    crr1 = Clb_CRR2Tree(n, vol, pu, today, dto, cal, div, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */

    if (what != KEY_REPO)
        ok = CRR_premium(crr1, today, dfrom, dto, pd, e, vol, ts, its, type,
                         fts, ifts, div, what, risk, -1.0, cal, y, dy, &ddy) ;
    else
        ok = CRR_premium(crr1, today, dfrom, dto, pd, e, vol, ts1, its, type,
                         fts, ifts, div, what, risk, -1.0, cal, y, dy, &ddy) ;

    Free_BINTREEARRAY(crr1, 1) ;
    Free_TSARRAY(ts1, 1) ;

    *y = *y - pr ;
    return ok ;
}

/*
..ra - 1.0 + proces drift (r - d) * dt
..rp - 1.0 + the discounting rate
*/

FL64 CRR_Rpcalc(FL64 t1, FL64 dt, TS_STR* fts, INTPOLCONV ifts, TS_STR* ts,
                   INTPOLCONV its, FL64* rp)
{
   FL64 ra, f, fr, r1, r2, t2, fr1, fr2 ;

   r1  = Yld_Get_TsRate(ts, t1, its) ;
   fr1 = Yld_Get_TsRate(fts, t1, ifts) ;
   t2  = t1 + dt ;
   r2  = Yld_Get_TsRate(ts, t2, its) ;
   fr2 = Yld_Get_TsRate(fts, t2, ifts) ;
   f   = Yld_Spot2Forw_Rate(r1, t1, r2, t2, ts->qbas, ts->conv) ;
   fr  = Yld_Spot2Forw_Rate(fr1, t1, fr2, t2, fts->qbas, fts->conv) ;
   *rp = 1.0 / TVMunit_NPV(dt, f, ts->conv, ts->qbas) ;
   ra  = *rp * TVMunit_NPV(dt, fr, fts->conv, ts->qbas) ;

   return ra ;
}

#undef DAY_TOL
#undef SHOCKSIZE
#undef F64_TOL
#undef ACC_PRICE
#undef ACC_RATE
#undef ACC_TERM
#undef LOW_BOUND
#undef VOL_GUESS
#undef MAXIT

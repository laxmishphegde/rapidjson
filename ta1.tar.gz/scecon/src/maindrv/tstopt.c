/* SCID @(#)tstopt.c	1.8 (SimCorp) 99/09/08 17:33:58 */

/************************************************************************
*
*   project     SCecon
*
*   this program tests the routines in the option module of SCecon.
*
************************************************************************/

/*** includes ***********************************************************/
#include <string.h>
#include <str2conv.h>
#include <option.h>
#include <stdlib.h>
#include <stdio.h>
#include <ioconv.h>
#include <optio.h>

/*** prototyping  *******************************************************/
/* PMSTA-22396 - SRIDHARA � 160502 */
int  test_crr_premium(FILE *in, FILE *out, HOLI_STR* hol) ;
int  test_crr_implied(FILE *in, FILE *out, HOLI_STR* hol) ;


INTI opttest(char* txa, FILE* in, FILE* out)
{
    FL64        spot, p, acc, fres, adj, fres1, vol, fres2 ;
    INTI        diff ;
    KEYCONV     what ;
    DATESTR     vold, today ;
    BOOLE       is_p, ok, s_f ;
    DISCFAC     df ;
    OPTFUT      opt ;
    RISKSET     orisk ;
    HOLI_STR    holi ;
    ITERCTRL    ctrl ;

    acc   = 0.0001 ;
    diff = -1 ;

    if (!strcmp(txa, "CRR_premium()"))
    {
        fprintf(out,"?; testing %s\n", txa) ;
		/* PMSTA-22396 - SRIDHARA � 160502 */
		holi = Read_HOLI_STR(in, out);
		diff = test_crr_premium(in, out, &holi);
		Free_HOLI_STR(&holi);
    }


    else if (!strcmp(txa, "CRR_Implied()"))
    {
        fprintf(out,"?; testing %s\n", txa) ;
		/* PMSTA-22396 - SRIDHARA � 160502 */
		holi = Read_HOLI_STR(in, out);
		diff = test_crr_implied(in, out, &holi);
		Free_HOLI_STR(&holi);
    }

    else if (!strcmp(txa, "Option_Black2P()"))
    {
        fprintf(out, "%s\n", txa);

        today = Read_DATESTR(in, out, "  Analys ");
        vold = Read_DATESTR(in, out, "  Vol date ");

        spot = Read_FL64(in, out, "  Spot/Fut Price ");
        s_f = Read_BOOLE(in, out, "  Spot toggle ");
        adj = Read_FL64(in, out, "  Adjustment factor ");
        vol = Read_FL64(in, out, "  Volatility ");

        opt   = Read_OPTFUT(in, out) ;
        df    = Read_DISCFAC(in, out) ;
        holi  = Read_HOLI_STR(in, out) ;
        orisk = Read_RISKSET(in, out) ;

        fres = Option_Black2P(&today, &vold, spot, s_f, adj, vol,
                &opt, &df, &holi, &orisk, &fres1, &fres2);
  
        acc = Read_FL64(in, out, "");

        IOUtil_ParseLine(in, out) ;

        diff = Compare_Risk(in, out, True, fres, 
                   fres1, fres2, acc);

        Free_OPTFUT(&opt) ;
        Free_DISCFAC(&df) ;
        Free_HOLI_STR(&holi) ;
        Free_RISKSET(&orisk) ;
    }

    else if (!strcmp(txa, "Option_Black2Impl()"))
    {
        fprintf(out, "%s\n", txa);

        Init_ITERCTRL(&ctrl) ;

        today = Read_DATESTR(in, out, "  Analys ");
        vold = Read_DATESTR(in, out, "  Vol date ");

        p = Read_FL64(in, out, "  Premium ");
        is_p = Read_BOOLE(in, out, "  Premium/Delta toggle ");
        spot = Read_FL64(in, out, "  Spot/Fut Price ");
        s_f = Read_BOOLE(in, out, "  Spot toggle ");
        adj = Read_FL64(in, out, "  Adjustment factor ");
        vol = Read_FL64(in, out, "  Volatility ");

        opt   = Read_OPTFUT(in, out) ;
        df    = Read_DISCFAC(in, out) ;
        holi  = Read_HOLI_STR(in, out) ;
        what = Read_KEYCONV(in, out, "  Implied What? ") ;
        ctrl.init_guess = Read_FL64(in, out, "  Initial guess ");
        ctrl.use_init_guess = Read_BOOLE(in, out, "  Use initial guess? ") ;

        ok = Option_Black2Impl(&today, &vold, p, is_p, spot, 
                s_f, adj, vol, &opt, &df, &holi, what, &ctrl, &fres);
  
        acc = Read_FL64(in, out, "");

        IOUtil_ParseLine(in, out) ;

        diff = Compare_Single(in, out, ok, fres, acc);
        
        Free_OPTFUT(&opt) ;
        Free_DISCFAC(&df) ;
        Free_HOLI_STR(&holi) ;
    }

    return diff ;
}


/* SCID @(#)tstoptvl.c	1.5 (SimCorp) 99/02/19 14:18:15 */

/************************************************************************
*
*   project     SCecon
*
************************************************************************/

/*** includes ***********************************************************/
#include <string.h>
#include <str2conv.h>
#include <optio.h>
#include <optvalid.h>

INTI optvaltest(char* txa, FILE* in, FILE* out)
{
    char        txc[80], txe[80], txpl[80] ;
    INTI        diff ;
    VALIDATE    val, exp_val ;
    DATESTR     date ;
    OPTFUT      optfut ;
    DATESTR     dummy_date ;

    date  = dummy_date = Cldr_YMD2Datestr((YYYYMMDD) 0) ;
    diff = -1 ;

    if (!strcmp("Validate_OPTFUT()", txa))
    {
        fscanf(in, "%s %s", txe, txpl) ;

        exp_val = Str2VALIDATE(txe) ;

        fprintf(out, "   \n Testing %s\n", txa) ;
        fprintf(out, "   %s\n", txpl) ;

        optfut = Read_OPTFUT(in, out) ;
        val    = Validate_OPTFUT(&optfut) ;
        VALIDATE2Str(val, txc) ;

        diff = (val == exp_val ? 0 : 1) ;
        fprintf(out,"%d;  Exp %s Res %s\n", diff, txe, txc) ;
        Free_OPTFUT(&optfut) ;
    }


    return diff ;
}

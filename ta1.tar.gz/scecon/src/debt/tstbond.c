/* SCID @(#)tstbond.c	1.8 (SimCorp) 99/02/19 14:12:34 */

/************************************************************************
*
*   project     SCecon
*
*   filename    bondtest.c
*
************************************************************************/

/*** includes ***********************************************************/
#include <string.h>
#include <bond.h>
#include <str2conv.h>
#include <ioconv.h>
#include <bootsec.h>
#include <bondio.h>

/*** prototypes *********************************************************/
extern INTI bondtest_diff(FL64 fres, FL64 fres1, FL64 fres2,
                          FL64 fexp, FL64 fexp1, FL64 fexp2, FL64 acc, 
                          FILE *out) ;

INTI bondtest(char* txa, FILE* in, FILE* out)
{
    char        txb[25], txc[25], txpl[125] ;
    FL64        price, fexp, fres = 0, ytm, fexp1, fexp2, fres1, fres2,
                acc, iacc, shift, coup, *dv ;
    PAYDAYDEF   pday ;
    HOLI_STR    holi ;
    CFLWARRAY   cflw, xcflw, mcflw ;
    YTMCONV     ytmcr, ytmc ;
    BOOLE       okexp, zero, p_y, modf, mean, ok ;
    INTI        nbuck, diff, i, nfixp, ntrar, ntrah, ndfs, dif1, n1, n2, n;
    YYYYMMDD    ymd = 0 ;
    int         i1, i2 ;
    DATESTR     matur, analys ;
    DISCFAC     df, dfre ;
    PP_STR      pp ;
    RISKSET     risk ;
    FIXPAY      fixp ;
    BUCKETARRAY bucket ;
    DFSPREAD    dfs ;
    TRADEINFO   hrz, trade, tr1, tr2 ;
    BOOLEARRAY  what ;
    ITERCTRL    ictrl ;
    DEPOSIT     depo ;
    AIRESULT    aiexp, aires ;
    TRADEINFOARRAY trah, trar ;
    FIXPAYARRAY    fixpar ;
    DFSPREADARRAY  dfsa ;
    DELTASET     ds ;
    BONDBM       bond ;
    YTMSEG       yseg ;
    HZYCONV      hzyc ;
    PLANARRAY    xredemp, amort, exp_amort, prepay ;
    PREPAYCONV   prepayc ;
    PMTFREQ      pfreq ;
    FL64MATRIX   quotes;
    FL64ARRAY    w_quotes, e_quotes;

    diff = -1 ;

    if (!strcmp("Cflw_YTM2Yield()", txa))
    {
        fscanf(in, "%lf %lf %lf", &fexp, &price, &iacc) ;
        fprintf(out,"   Testing %s\n", txa) ;
        fprintf(out,"   price       %lf\n", price) ;

        xcflw = Read_CFLWARRAY(in, out) ;
        ytmc  = Read_YTMCONV(in, out) ;
        pday  = Read_PAYDAYDEF(in, out) ;
        coup  = Read_FL64(in, out, "   Coupon: ") ;
        holi  = Read_HOLI_STR(in, out) ;
        pp    = Read_PP_STR(in, out) ;

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n", txpl) ;

        Init_ITERCTRL(&ictrl) ;
        ictrl.acc = iacc ;
        ok = Cflw_YTM2Yield(price, xcflw, &ytmc, &pday, coup, &pp, &holi,
                            &ictrl, &fres) ;
        if (ok == False)
        {
            fprintf(out, "1; Cannot find YTM\n\n") ;
            diff = 1 ;
        }
        else
        {
            diff = fabs(fres - fexp) > 0.00001 ;
            fprintf(out,
              "%d; Expected %lf Result %lf\n\n",
              diff, fexp, fres) ;
        }

        Free_DATEARRAY(holi.holidays) ;
        Free_CFLWARRAY(xcflw, 1) ;
        Free_PLANARRAY(pp.ppmts, 1) ;
        Free_PAYDAYDEF(&pday);
    }

    else if (!strcmp("RepoCflw_YTM2Yield()", txa))
    {
        fscanf(in, "%lf %lf %lf", &fexp, &price, &iacc) ;
        fprintf(out,"   Testing %s\n", txa) ;
        fprintf(out,"   price       %lf\n", price) ;

        xcflw = Read_CFLWARRAY(in, out) ;
        fscanf(in, "%ld", &ymd) ;
        matur = Cldr_YMD2Datestr(ymd) ;
        fprintf(out,"   Maturity    %ldn", ymd) ;
        ytmc  = Read_YTMCONV(in, out) ;
        pday  = Read_PAYDAYDEF(in, out) ;
        coup  = Read_FL64(in, out, "   Coupon: ") ;
        holi  = Read_HOLI_STR(in, out) ;
        pp    = Read_PP_STR(in, out) ;

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n", txpl) ;

        Init_ITERCTRL(&ictrl) ;
        ictrl.acc = iacc ;
        ok = RepoCflw_YTM2Yield(price, xcflw, &matur, &ytmc, &pday, coup, 
                                &pp, &holi, &ictrl, &fres) ;
        if (ok == False)
        {
            fprintf(out, "1; Cannot find YTM\n\n") ;
            diff = 1 ;
        }
        else
        {
            diff = fabs(fres - fexp) > 0.0001 ;
            fprintf(out,
              "%d; Expected %lf Result %lf\n\n",
              diff, fexp, fres) ;
        }

        Free_DATEARRAY(holi.holidays) ;
        Free_CFLWARRAY(xcflw, 1) ;
        Free_PLANARRAY(pp.ppmts, 1) ;
        Free_PAYDAYDEF(&pday);
    }

    else if (!strcmp("RepoCflw_YTM2Price()", txa))
    {
        fscanf(in, "%lf %lf %lf %lf", &fexp, &fexp1, &fexp2, &ytm) ;
        fprintf(out,"   Testing %s\n", txa) ;
        fprintf(out,"   YTM       %lf\n", ytm) ;

        xcflw = Read_CFLWARRAY(in, out) ;
        fscanf(in, "%ld", &ymd) ;
        matur = Cldr_YMD2Datestr(ymd) ;
        fprintf(out,"   Maturity    %ldn", ymd) ;
        ytmc  = Read_YTMCONV(in, out) ;
        pday  = Read_PAYDAYDEF(in, out) ;
        coup  = Read_FL64(in, out, "   Coupon: ") ;
        holi  = Read_HOLI_STR(in, out) ;
        pp    = Read_PP_STR(in, out) ;

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n", txpl) ;

        fres = RepoCflw_YTM2Price(ytm, xcflw, &matur, &ytmc, &pday,
                                  coup, &pp, &holi, SECOND_ORDER, 
                                  False, &fres1, &fres2) ;

        diff = bondtest_diff(fres, fres1, fres2, fexp, fexp1, fexp2,
                             0.00001, out) ;

        Free_DATEARRAY(holi.holidays) ;
        Free_CFLWARRAY(xcflw, 1) ;
        Free_PLANARRAY(pp.ppmts, 1) ;
        Free_PAYDAYDEF(&pday);
    }

    else if (!strcmp("Bond_GenrTerms()", txa))
    {
        fscanf(in, "%ld", &ymd) ;
        analys = Cldr_YMD2Datestr(ymd) ;
        fprintf(out,"   Testing %s\n", txa) ;
        fprintf(out,"   Analysis    %ld\n", ymd) ;

        xcflw = Read_CFLWARRAY(in, out) ;
        ytmc  = Read_YTMCONV(in, out) ;
        pday  = Read_PAYDAYDEF(in, out) ;
        holi  = Read_HOLI_STR(in, out) ;

        dv = Bond_GenrTerms(&analys, xcflw, &ytmc, &pday, &holi) ;
        diff = 0 ;
        for (i = 0; i < xcflw->filled; i++)
        {
            fscanf(in, "%lf", &fexp) ;
            diff = diff || fabs(dv[i] - fexp) > 0.00001 ;
            fprintf(out,"%d; Exp %lf Res %lf\n",
                    fabs(dv[i] - fexp) > 0.00001, fexp, dv[i]) ;
        }

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_DATEARRAY(holi.holidays) ;
        Free_FL64ARRAY(dv) ;
        Free_CFLWARRAY(xcflw, 1) ;
        Free_PAYDAYDEF(&pday);
    }

    else if (!strcmp("Cflw_WAL()", txa))
    {
        fscanf(in, "%lf", &fexp) ;
        analys = Cldr_YMD2Datestr(ymd) ;
        fprintf(out,"   Testing %s\n", txa) ;
        fprintf(out,"   Analysis    %ld\n", ymd) ;

        xcflw = Read_CFLWARRAY(in, out) ;
        ytmc  = Read_YTMCONV(in, out) ;
        pday  = Read_PAYDAYDEF(in, out) ;
        holi  = Read_HOLI_STR(in, out) ;

        fres = Cflw_WAL(xcflw, &ytmc, &pday, &holi) ;
        diff = fabs(fres - fexp) > 0.00001 ;
        fprintf(out, "%d; Expected %lf Result %lf\n\n",
                diff, fexp, fres) ;

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_DATEARRAY(holi.holidays) ;
        Free_CFLWARRAY(xcflw, 1) ;
        Free_PAYDAYDEF(&pday);
    }

    else if (!strcmp("Cflw_LIFE()", txa))
    {
        fscanf(in, "%lf", &fexp) ;
        analys = Cldr_YMD2Datestr(ymd) ;
        fprintf(out,"   Testing %s\n", txa) ;
        fprintf(out,"   Analysis    %ld\n", ymd) ;

        xcflw = Read_CFLWARRAY(in, out) ;
        ytmc  = Read_YTMCONV(in, out) ;
        pday  = Read_PAYDAYDEF(in, out) ;
        holi  = Read_HOLI_STR(in, out) ;

        fres = Cflw_LIFE(xcflw, &ytmc, &pday, &holi) ;
        diff = fabs(fres - fexp) > 0.00001 ;
        fprintf(out, "%d; Expected %lf Result %lf\n\n",
                diff, fexp, fres) ;

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_DATEARRAY(holi.holidays) ;
        Free_CFLWARRAY(xcflw, 1) ;
        Free_PAYDAYDEF(&pday);
    }

    else if (!strcmp("Bond_YTM2Yield()", txa))
    {
        fscanf(in, "%lf", &fexp) ;

        fprintf(out,"   Testing %s\n", txa) ;

        trade = Read_TRADEINFO(in, out) ;
        fixp  = Read_FIXPAY(in, out, &trade.settle) ;
        ytmc  = Read_YTMCONV(in, out) ;
        holi  = Read_HOLI_STR(in, out) ;

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Init_ITERCTRL(&ictrl) ;
        ok = Bond_YTM2Yield(&trade, &fixp, &ytmc, &holi, &ictrl, &fres) ;
        if (ok == False)
        {
            fprintf(out, "1; Cannot find YTM\n\n") ;
            diff = 1 ;
        }
        else
        {
            diff = fabs(fres - fexp) > 0.00001 ;
            fprintf(out, "%d; Expected %lf Result %lf\n\n",
                    diff, fexp, fres) ;
        }

        Free_DATEARRAY(holi.holidays) ;
        Free_FIXPAY(&fixp) ;
    }

    else if (!strcmp("Bond_YTM2Price()", txa))
    {
        fscanf(in, "%lf %lf %lf %lf", &fexp, &fexp1, &fexp2, &ytm) ;

        fprintf(out,"   Testing %s\n", txa) ;
        fprintf(out,"   YTM         %lf\n", ytm) ;

        trade = Read_TRADEINFO(in, out) ;
        fixp  = Read_FIXPAY(in, out, &trade.settle) ;
        ytmc  = Read_YTMCONV(in, out) ;
        holi  = Read_HOLI_STR(in, out) ;

        fscanf(in, "%s %s", txb, txpl) ;
        modf = Str2BOOLE(txb) ;
        fprintf(out,"   Modified ?     %s\n", txb) ;
        fprintf(out,"   %s\n\n", txpl) ;

        fres = Bond_YTM2Price(ytm, &trade, &fixp, &ytmc, &holi,
                              SECOND_ORDER, modf, &fres1, &fres2) ;

        diff = bondtest_diff(fres, fres1, fres2, fexp, fexp1, fexp2,
                             0.00001, out) ;

        Free_DATEARRAY(holi.holidays) ;
        Free_FIXPAY(&fixp) ;
    }

    else if (!strcmp("Bond_YTM2PV01()", txa))
    {
        fscanf(in, "%lf %lf", &fexp, &ytm) ;

        fprintf(out,"   Testing %s\n", txa) ;
        fprintf(out,"   YTM         %lf\n", ytm) ;

        trade = Read_TRADEINFO(in, out) ;
        fixp  = Read_FIXPAY(in, out, &trade.settle) ;
        ytmc  = Read_YTMCONV(in, out) ;
        holi  = Read_HOLI_STR(in, out) ;

        fscanf(in, "%lf %s %s", &shift, txb, txpl) ;
        mean = Str2BOOLE(txb) ;
        fprintf(out,"   Shift          %lf\n", shift) ;
        fprintf(out,"   Mean ?         %s\n", txb) ;
        fprintf(out,"   %s\n\n", txpl) ;

        fres = Bond_YTM2PV01(ytm, &trade, &fixp, &ytmc, &holi, shift, mean)
          ;

        diff = fabs(fres - fexp) > 0.00001 ;
        fprintf(out,"%d; Expected %lf Result %lf\n\n", diff, fexp, fres) ;

        Free_DATEARRAY(holi.holidays) ;
        Free_FIXPAY(&fixp) ;
    }

    else if (!strcmp("Bond_YTM2YV01()", txa))
    {
        fscanf(in, "%lf", &fexp) ;

        fprintf(out,"   Testing %s\n", txa) ;

        trade = Read_TRADEINFO(in, out) ;
        fixp  = Read_FIXPAY(in, out, &trade.settle) ;
        ytmc  = Read_YTMCONV(in, out) ;
        holi  = Read_HOLI_STR(in, out) ;

        fscanf(in, "%lf %s %s", &shift, txb, txpl) ;
        mean = Str2BOOLE(txb) ;
        fprintf(out,"   Shift          %lf\n", shift) ;
        fprintf(out,"   Mean ?         %s\n", txb) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Init_ITERCTRL(&ictrl) ;
        ok = Bond_YTM2YV01(&trade, &fixp, &ytmc, &holi, &ictrl,
                           shift, mean, &fres) ;
        if (ok == False)
        {
            diff = 1 ;
            fprintf(out,"1; Cannot solve\n") ;
        }
        else
        {
            diff = fabs(fres - fexp) > 0.00001 ;
            fprintf(out,
              "%d; Expected %lf Result %lf\n\n",
              diff, fexp, fres) ;
        }

        Free_DATEARRAY(holi.holidays) ;
        Free_FIXPAY(&fixp) ;
    }

    else if (!strcmp("Bond_YTM2Duration()", txa))
    {
        fscanf(in, "%lf %lf", &fexp, &ytm) ;

        fprintf(out,"   Testing %s\n", txa) ;
        fprintf(out,"   YTM         %lf\n", ytm) ;

        trade = Read_TRADEINFO(in, out) ;
        fixp  = Read_FIXPAY(in, out, &trade.settle) ;
        ytmc  = Read_YTMCONV(in, out) ;
        holi  = Read_HOLI_STR(in, out) ;

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        fres = Bond_YTM2Duration(ytm, &trade, &fixp, &ytmc, &holi) ;
        diff = fabs(fres - fexp) > 0.00001 ;
        fprintf(out,"%d; Expected %lf Result %lf\n\n", diff, fexp, fres) ;

        Free_DATEARRAY(holi.holidays) ;
        Free_FIXPAY(&fixp) ;
    }

    else if (!strcmp("Bond_DF2Hzy()", txa))
    {
        fscanf(in, "%lf %s", &fexp, txb) ;
        fprintf(out,"   Testing %s\n", txa) ;
        okexp = Str2BOOLE(txb) ;

        trade = Read_TRADEINFO(in, out) ;
        hrz   = Read_TRADEINFO(in, out) ;
        fixp  = Read_FIXPAY(in, out, &trade.settle) ;

        hzyc  = Read_HZYCONV(in, out) ;
        dfre  = Read_DISCFAC(in, out) ;
        df    = Read_DISCFAC(in, out) ;
        holi  = Read_HOLI_STR(in, out) ;
        dfs   = Read_DFSPREAD(in, out) ;
        ictrl = Read_ITERCTRL(in, out) ;

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;
        ok = Bond_DF2Hzy(&trade, &hrz, &fixp, &hzyc, &dfre, &df,
                         &holi, &dfs, &ictrl, &fres) ;
        diff = fabs(fres - fexp) > 0.00001 || ok != okexp ;
        fprintf(out,"%d; Expected %d %lf Result %d %lf\n\n", 
                diff, okexp, fexp, ok, fres) ;

        Free_DATEARRAY(holi.holidays) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_PLANARRAY(dfre.disc, 1) ;
        Free_FIXPAY(&fixp) ;
        Free_DFSPREAD(&dfs) ;
    }

    else if (!strcmp("Cflw_YTM2Price()", txa))
    {
        fscanf(in, "%lf %lf %lf %lf", &fexp, &fexp1, &fexp2, &ytm) ;
        fprintf(out,"   Testing %s\n", txa) ;
        fprintf(out,"   ytm         %lf\n", ytm) ;

        xcflw = Read_CFLWARRAY(in, out) ;
        ytmc  = Read_YTMCONV(in, out) ;
        pday  = Read_PAYDAYDEF(in, out) ;
        coup  = Read_FL64(in, out, "   Coupon: ") ;
        holi  = Read_HOLI_STR(in, out) ;
        pp    = Read_PP_STR(in, out) ;

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        fres = Cflw_YTM2Price(ytm, xcflw, &ytmc, &pday, coup, &pp, &holi,
                              SECOND_ORDER, False, &fres1, &fres2) ;

        diff = bondtest_diff(fres, fres1, fres2, fexp, fexp1, fexp2,
                             0.00001, out) ;

        Free_DATEARRAY(holi.holidays) ;
        Free_CFLWARRAY(xcflw, 1) ;
        Free_PLANARRAY(pp.ppmts, 1) ;
        Free_PAYDAYDEF(&pday);
    }

    else if (!strcmp("Cflw_YTM2Duration()", txa))
    {
        fscanf(in, "%lf %lf", &fexp, &ytm) ;
        fprintf(out,"   Testing %s\n", txa) ;
        fprintf(out,"   ytm         %lf\n", ytm) ;

        xcflw = Read_CFLWARRAY(in, out) ;
        ytmc  = Read_YTMCONV(in, out) ;
        pday  = Read_PAYDAYDEF(in, out) ;
        holi  = Read_HOLI_STR(in, out) ;

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        fres = Cflw_YTM2Duration(ytm, xcflw, &ytmc, &pday, &holi) ;
        diff = fabs(fres  - fexp) > 0.00001 ;
        fprintf(out,"%d; Expected %lf Result %lf\n\n",
                fabs(fres - fexp) > 0.00001, fexp, fres) ;

        Free_DATEARRAY(holi.holidays) ;
        Free_CFLWARRAY(xcflw, 1) ;
        Free_PAYDAYDEF(&pday);
    }

    else if (!strcmp("Cflw_DF2Price()", txa))
    {
        fscanf(in, "%lf %lf %lf %ld", &fexp, &fexp1, &fexp2, &ymd) ;

        analys = Cldr_YMD2Datestr(ymd) ;

        fprintf(out,"   Testing %s\n", txa) ;
        fprintf(out,"   analys      %ld\n", ymd) ;

        df    = Read_DISCFAC(in, out) ;
        xcflw = Read_CFLWARRAY(in, out) ;
        pp    = Read_PP_STR(in, out) ;
        holi  = Read_HOLI_STR(in, out) ;
        dfs   = Read_DFSPREAD(in, out) ;
        risk  = Read_RISKSET(in, out) ;
        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        fres = Cflw_DF2Price(&analys, &df, xcflw, &pp, &holi, &dfs,
                             &risk, &fres1, &fres2) ;

        diff = bondtest_diff(fres, fres1, fres2, fexp, fexp1, fexp2,
                             0.00001, out) ;

        Free_DATEARRAY(holi.holidays) ;
        Free_CFLWARRAY(xcflw, 1) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_PLANARRAY(pp.ppmts, 1) ;
        Free_PLANARRAY(risk.loads, 1) ;
        Free_DFSPREAD(&dfs) ;
    }

    else if (!strcmp("RepoCflw_DF2Price()", txa))
    {
        fscanf(in, "%lf %lf %lf %ld", &fexp, &fexp1, &fexp2, &ymd) ;

        analys = Cldr_YMD2Datestr(ymd) ;

        fprintf(out,"   Testing %s\n", txa) ;
        fprintf(out,"   analys      %ld\n", ymd) ;

        df    = Read_DISCFAC(in, out) ;
        xcflw = Read_CFLWARRAY(in, out) ;
        fscanf(in, "%ld", &ymd) ;
        matur = Cldr_YMD2Datestr(ymd) ;
        fprintf(out,"   Maturity    %ldn", ymd) ;
        pp    = Read_PP_STR(in, out) ;
        holi  = Read_HOLI_STR(in, out) ;
        dfs   = Read_DFSPREAD(in, out) ;
        risk  = Read_RISKSET(in, out) ;
        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        fres = RepoCflw_DF2Price(&analys, &df, xcflw, &matur, &pp, 
                                 &holi, &dfs, &risk, &fres1, &fres2) ;

        diff = bondtest_diff(fres, fres1, fres2, fexp, fexp1, fexp2,
                             0.00001, out) ;

        Free_DATEARRAY(holi.holidays) ;
        Free_CFLWARRAY(xcflw, 1) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_PLANARRAY(pp.ppmts, 1) ;
        Free_PLANARRAY(risk.loads, 1) ;
        Free_DFSPREAD(&dfs) ;
    }

    else if (!strcmp("Cflw_DF2Spread()", txa))
    {
        fscanf(in, "%lf %s %lf", &fexp, txb, &price) ;
        okexp = Str2BOOLE(txb) ;

        fprintf(out,"   Testing %s\n", txa) ;
        fprintf(out,"   price       %8lf\n", price) ;

        df    = Read_DISCFAC(in, out) ;
        xcflw = Read_CFLWARRAY(in, out) ;
        pp    = Read_PP_STR(in, out) ;
        holi  = Read_HOLI_STR(in, out) ;
        dfs   = Read_DFSPREAD(in, out) ;

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Init_ITERCTRL(&ictrl) ;
        ok = Cflw_DF2Spread(price, &df, xcflw, &pp, &holi, &dfs,
                            &ictrl, &fres) ;
        diff = fabs(fres  - fexp) > 0.00001 || ok != okexp ;
        fprintf(out,"%d; Expected %d %lf Result %d %lf\n",
                fabs(fres - fexp) > 0.00001, okexp, fexp, ok, fres) ;

        Free_DATEARRAY(holi.holidays) ;
        Free_CFLWARRAY(xcflw, 1) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_PLANARRAY(pp.ppmts, 1) ;
        Free_DFSPREAD(&dfs) ;
    }

    else if (!strcmp("Bond_DF2Delta()", txa))
    {
        fscanf(in, "%ld", &ymd) ;
        analys = Cldr_YMD2Datestr(ymd) ;

        fprintf(out,"   Testing %s\n", txa) ;
        fprintf(out,"   analys      %ld\n", ymd) ;

        trade = Read_TRADEINFO(in, out) ;
        fixp  = Read_FIXPAY(in, out, &trade.settle) ;
        df    = Read_DISCFAC(in, out) ;
        holi  = Read_HOLI_STR(in, out) ;
        dfs   = Read_DFSPREAD(in, out) ;
        bucket = Read_BUCKETARRAY(in, out, &nbuck) ;

        fscanf(in, "%s", txb) ;
        zero = Str2BOOLE(txb) ;
        fprintf(out,"   DECF        %8s\n", txb) ;

        ds = Disc_DeltaPrep(&df, bucket, nbuck, &holi, False, df.irr,
                             df.freq, False, zero, DF_BOTH) ;
        dv = Bond_DF2Delta(&analys, &trade, &fixp, &df, &holi, &dfs, &ds) ;

        diff = 0 ;
        for (i = 0; i < nbuck; i++)
        {
            fscanf(in, "%lf", &fexp) ;
            diff = diff || fabs(fexp - dv[i]) > 0.00001 ;
            fprintf(out, "%d; %d exp %lf res %lf\n",
                    fabs(fexp - dv[i]) > 0.00001, i, fexp, dv[i]) ;
        }

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_DATEARRAY(holi.holidays) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_DELTASET(&ds) ;
        Free_BUCKETARRAY(bucket) ;
        Free_FL64ARRAY(dv) ;
        Free_FIXPAY(&fixp);
        Free_DFSPREAD(&dfs) ;
    }

    else if (!strcmp("Cflw_DF2Delta()", txa))
    {
        fscanf(in, "%ld", &ymd) ;

        analys = Cldr_YMD2Datestr(ymd) ;

        fprintf(out,"   Testing %s\n", txa) ;
        fprintf(out,"   analys      %ld\n", ymd) ;

        df     = Read_DISCFAC(in, out) ;
        xcflw  = Read_CFLWARRAY(in, out) ;
        pp     = Read_PP_STR(in, out) ;
        holi   = Read_HOLI_STR(in, out) ;
        dfs    = Read_DFSPREAD(in, out) ;
        bucket = Read_BUCKETARRAY(in, out, &nbuck) ;

        fscanf(in, "%s", txb) ;
        zero = Str2BOOLE(txb) ;
        fprintf(out,"   DECF        %8s\n", txb) ;

        ds = Disc_DeltaPrep(&df, bucket, nbuck, &holi, False, df.irr,
                             df.freq, False, zero, DF_BOTH) ;
        dv = Cflw_DF2Delta(&analys, &df, xcflw, &pp, &holi, &dfs, &ds) ;

        diff = 0 ;
        for (i = 0; i < nbuck; i++)
        {
            fscanf(in, "%lf", &fexp) ;
            diff = diff || fabs(fexp - dv[i]) > 0.00001 ;
            fprintf(out, "%d; %d exp %lf res %lf\n",
                    fabs(fexp - dv[i]) > 0.00001, i, fexp, dv[i]) ;
        }

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_DATEARRAY(holi.holidays) ;
        Free_CFLWARRAY(xcflw, 1) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_DELTASET(&ds) ;
        Free_BUCKETARRAY(bucket) ;
        Free_FL64ARRAY(dv) ;
        Free_DFSPREAD(&dfs) ;
    }

    else if (!strcmp("RepoCflw_DF2Delta()", txa))
    {
        fscanf(in, "%ld", &ymd) ;

        analys = Cldr_YMD2Datestr(ymd) ;

        fprintf(out,"   Testing %s\n", txa) ;
        fprintf(out,"   analys      %ld\n", ymd) ;

        df     = Read_DISCFAC(in, out) ;
        xcflw  = Read_CFLWARRAY(in, out) ;
        fscanf(in, "%ld", &ymd) ;
        matur = Cldr_YMD2Datestr(ymd) ;
        fprintf(out,"   Maturity    %ldn", ymd) ;
        pp     = Read_PP_STR(in, out) ;
        holi   = Read_HOLI_STR(in, out) ;
        dfs    = Read_DFSPREAD(in, out) ;
        bucket = Read_BUCKETARRAY(in, out, &nbuck) ;

        fscanf(in, "%s", txb) ;
        zero = Str2BOOLE(txb) ;
        fprintf(out,"   DECF        %8s\n", txb) ;

        ds = Disc_DeltaPrep(&df, bucket, nbuck, &holi, False, df.irr,
                             df.freq, False, zero, DF_BOTH) ;
        dv = RepoCflw_DF2Delta(&analys, &df, xcflw, &matur, &pp, 
                               &holi, &dfs, &ds) ;

        diff = 0 ;
        for (i = 0; i < nbuck; i++)
        {
            fscanf(in, "%lf", &fexp) ;
            diff = diff || fabs(fexp - dv[i]) > 0.00001 ;
            fprintf(out, "%d; %d exp %lf res %lf\n",
                    fabs(fexp - dv[i]) > 0.00001, i, fexp, dv[i]) ;
        }

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_DATEARRAY(holi.holidays) ;
        Free_CFLWARRAY(xcflw, 1) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_DELTASET(&ds) ;
        Free_BUCKETARRAY(bucket) ;
        Free_FL64ARRAY(dv) ;
        Free_DFSPREAD(&dfs) ;
    }

    else if (!strcmp("Bond_DF2Price()", txa))
    {
        fscanf(in, "%lf %lf %lf %ld", &fexp, &fexp1, &fexp2, &ymd) ;
        analys = Cldr_YMD2Datestr(ymd) ;
        fprintf(out,"   Testing %s\n", txa) ;
        fprintf(out,"   analys      %ld\n", ymd) ;

        trade = Read_TRADEINFO(in, out) ;
        fixp  = Read_FIXPAY(in, out, &trade.settle) ;
        df    = Read_DISCFAC(in, out) ;
        holi  = Read_HOLI_STR(in, out) ;
        dfs   = Read_DFSPREAD(in, out) ;
        risk  = Read_RISKSET(in, out) ;

        fres = Bond_DF2Price(&analys, &trade, &fixp, &df, &holi,
                             &dfs, &risk, &fres1, &fres2) ;

        diff = bondtest_diff(fres, fres1, fres2, fexp, fexp1, fexp2,
                             0.00001, out) ;

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_DATEARRAY(holi.holidays) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_FIXPAY(&fixp);
        Free_DFSPREAD(&dfs) ;
        Free_PLANARRAY(risk.loads, 1) ;
    }

    else if (!strcmp("Bond_DF2Duration()", txa))
    {
        fprintf(out,"   Testing %s\n", txa) ;

        fexp  = Read_FL64(in, out, "   Expected   ") ;
        analys= Read_DATESTR(in, out, "   Analysis   ") ;
        trade = Read_TRADEINFO(in, out) ;
        fixp  = Read_FIXPAY(in, out, &trade.settle) ;
        df    = Read_DISCFAC(in, out) ;
        holi  = Read_HOLI_STR(in, out) ;
        dfs   = Read_DFSPREAD(in, out) ;

        fres = Bond_DF2Duration(&analys, &trade, &fixp, &df, &holi, &dfs) ;
        diff = Write_SingleDiff(True, True, fres, fexp, 0.00001, out) ;

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_DATEARRAY(holi.holidays) ;
        Free_DISCFAC(&df) ;
        Free_FIXPAY(&fixp);
        Free_DFSPREAD(&dfs) ;
    }

    else if (!strcmp("Bond_DF2Spread()", txa))
    {
        fprintf(out,"   Testing %s\n", txa) ;
        fscanf(in, "%lf %s", &fexp, txb) ;
        okexp = Str2BOOLE(txb) ;

        trade = Read_TRADEINFO(in, out) ;
        fixp  = Read_FIXPAY(in, out, &trade.settle) ;
        df    = Read_DISCFAC(in, out) ;
        holi  = Read_HOLI_STR(in, out) ;
        dfs   = Read_DFSPREAD(in, out) ;

        Init_ITERCTRL(&ictrl) ;
        ok = Bond_DF2Spread(&trade, &fixp, &df, &holi, &dfs, 
                            &ictrl, &fres) ;

        diff = fabs(fres  - fexp) > 0.00001 || ok != okexp ;
        fprintf(out,"%d; Expected %d %lf Result %d %lf\n",
                fabs(fres - fexp) > 0.00001, okexp, fexp, ok, fres) ;

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n", txpl) ;

        Free_DATEARRAY(holi.holidays) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_FIXPAY(&fixp);
        Free_DFSPREAD(&dfs) ;
    }

    else if (!strcmp("Cflw_YTM2Risk()", txa))
    {
        fscanf(in, "%lf %s %lf", &price, txb, &coup) ;
        p_y = Str2BOOLE(txb) ;
        fprintf(out,"\n   Testing %s\n", txa) ;
        fprintf(out,"   PRY         %lf\n", price) ;
        fprintf(out,"   p_y         %s\n", txb) ;
        fprintf(out,"   Coupon      %lf\n", coup) ;

        xcflw = Read_CFLWARRAY(in, out) ;
        ytmcr = ytmc = Read_YTMCONV(in, out) ;
        pday  = Read_PAYDAYDEF(in, out) ;
        holi  = Read_HOLI_STR(in, out) ;
        pp    = Read_PP_STR(in, out) ;

        fscanf(in, "%s %s", txb, txc) ;
        ytmcr.irr    = Str2IRRCONV(txb) ;
        ytmcr.qb_ytm = Str2PMTFREQ(txc) ;
        fprintf(out,"   Risk IRR       %s\n", txb) ;
        fprintf(out,"   Risk Freq      %s\n", txc) ;

        fscanf(in, "%d %s", &i1, txpl) ;
        what = Alloc_BOOLEARRAY(i1) ;
        for (i = 0; i < i1; i++)
        {
            fscanf(in, "%d", &i2) ;
            what[i] = i2 ;
        }

        Init_ITERCTRL(&ictrl) ;
        dv = Cflw_YTM2Risk(what, (INTI) i1, price, p_y, coup, xcflw, &ytmc,
                           &pday, &pp, &holi, &ytmcr, &ictrl, ACT360, &ok) ;
        if (ok == False)
        {
            fprintf(out, "1; Cannot find RISK\n\n") ;
            diff = 1 ;
        }
        else
        {
            for (diff = i = 0; i < i1; i++)
            {
                fscanf(in, "%lf", &fexp) ;
                diff = diff || fabs(dv[i] - fexp) > 0.00001 ;
                fprintf(out,"%d; Expected %lf Result %lf\n",
                        fabs(dv[i] - fexp) > 0.00001, fexp, dv[i]) ;
            }
        }

        fprintf(out,"   %s\n\n", txpl) ;

        Free_DATEARRAY(holi.holidays) ;
        Free_FL64ARRAY(dv) ;
        Free_BOOLEARRAY(what) ;
        Free_CFLWARRAY(xcflw, 1) ;
        Free_PLANARRAY(pp.ppmts, 1) ;
        Free_PAYDAYDEF(&pday);
    }

    else if (!strcmp("Deposit_DF2Price()", txa))
    {
        fscanf(in, "%lf %lf %lf %ld", &fexp, &fexp1, &fexp2, &ymd) ;

        analys = Cldr_YMD2Datestr(ymd) ;
        fprintf(out,"   Testing %s\n", txa) ;
        fprintf(out,"   analys      %ld\n", ymd) ;

        depo = Read_DEPOSIT(in, out) ;
        df   = Read_DISCFAC(in, out) ;
        holi = Read_HOLI_STR(in, out) ;
        dfs  = Read_DFSPREAD(in, out) ;
        risk = Read_RISKSET(in, out) ;

        fres = Deposit_DF2Price(&analys, &depo, &df, &holi, &dfs,
                                &risk, &fres1, &fres2) ;

        diff = bondtest_diff(fres, fres1, fres2, fexp, fexp1, fexp2,
                             0.00001, out) ;

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_DATEARRAY(holi.holidays) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_RISKSET(&risk);
        Free_DFSPREAD(&dfs) ;
    }

    else if (!strcmp("Deposit_DF2Delta()", txa))
    {
        fscanf(in, "%ld", &ymd) ;

        analys = Cldr_YMD2Datestr(ymd) ;
        fprintf(out,"   Testing %s\n", txa) ;
        fprintf(out,"   analys      %ld\n", ymd) ;

        depo   = Read_DEPOSIT(in, out) ;
        df     = Read_DISCFAC(in, out) ;
        holi   = Read_HOLI_STR(in, out) ;
        dfs    = Read_DFSPREAD(in, out) ;
        bucket = Read_BUCKETARRAY(in, out, &nbuck) ;

        ds = Disc_DeltaPrep(&df, bucket, nbuck, &holi, False,
                             df.irr, df.freq, False, False, DF_BOTH) ;
        dv = Deposit_DF2Delta(&analys, &depo, &df, &holi, &dfs, &ds) ;

        diff = 0 ;
        for (i = 0; i < nbuck; i++)
        {
            fscanf(in, "%lf", &fexp) ;
            diff = diff || fabs(fexp - dv[i]) > 0.00001 ;
            fprintf(out, "%d; %d exp %lf res %lf\n",
                    fabs(fexp - dv[i]) > 0.00001, i, fexp, dv[i]) ;
        }

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_DATEARRAY(holi.holidays) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_DELTASET(&ds) ;
        Free_BUCKETARRAY(bucket) ;
        Free_FL64ARRAY(dv) ;
        Free_DFSPREAD(&dfs) ;
    }

    else if (!strcmp("Deposit_Accruint()", txa))
    {
        fscanf(in, "%lf %ld", &fexp, &ymd) ;

        analys = Cldr_YMD2Datestr(ymd) ;
        fprintf(out,"   Testing %s\n", txa) ;
        fprintf(out,"   analys      %ld\n", ymd) ;

        depo = Read_DEPOSIT(in, out) ;
        holi = Read_HOLI_STR(in, out) ;

        aires = Deposit_Accruint(&analys, &depo, &holi) ;
        fres  = aires.AI ;

        diff = fabs(fres  - fexp) > 0.00001 ;
        fprintf(out,"%d; Expected %lf Result %lf\n",
                fabs(fres - fexp) > 0.00001, fexp, fres) ;

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_DATEARRAY(holi.holidays) ;
    }

    else if (!strcmp("Bond_GenrCflw()", txa))
    {
        fprintf(out,"\n   Testing %s\n", txa) ;

        tr1   = Read_TRADEINFO(in, out) ;
        fixp  = Read_FIXPAY(in, out, &tr1.settle) ;
        holi  = Read_HOLI_STR(in, out) ;
        xcflw = Read_CFLWARRAY(in, out) ;
        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n", txpl) ;

        cflw = Bond_GenrCflw(&tr1, &fixp, &holi) ;
        diff = Write_CflwDiff(xcflw, cflw, out) ;

        Free_FIXPAY(&fixp) ;
        Free_DATEARRAY(holi.holidays) ;
        Free_CFLWARRAY(cflw, 1) ;
        Free_CFLWARRAY(xcflw, 1) ;
    }

    else if (!strcmp("Bond_GenrPeriod()", txa))
    {
        fprintf(out,"\n   Testing %s\n", txa) ;

        tr1   = Read_TRADEINFO(in, out) ;
        tr2   = Read_TRADEINFO(in, out) ;
        fixp  = Read_FIXPAY(in, out, &tr1.settle) ;
        holi  = Read_HOLI_STR(in, out) ;
        xcflw = Read_CFLWARRAY(in, out) ;
        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n", txpl) ;

        cflw = Bond_GenrPeriod(&tr1, &tr2, &fixp, &holi) ;
        diff = Write_CflwDiff(xcflw, cflw, out) ;

        Free_FIXPAY(&fixp) ;
        Free_DATEARRAY(holi.holidays) ;
        Free_CFLWARRAY(cflw, 1) ;
        Free_CFLWARRAY(xcflw, 1) ;
    }

    else if (!strcmp("Bond_Accruint()", txa))
    {
        fprintf(out,"\n   Testing %s\n", txa) ;

        aiexp = Read_AIRESULT(in) ;
        tr1   = Read_TRADEINFO(in, out) ;
        fixp  = Read_FIXPAY(in, out, &tr1.settle) ;
        holi  = Read_HOLI_STR(in, out) ;
        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n", txpl) ;

        aires = Bond_Accruint(&tr1, &fixp, &holi) ;

        diff = 0 ;
        if (fabs(aires.AI - aiexp.AI) > 0.00001 || 
            aiexp.AIdays != aires.AIdays ||
            fabs(aires.AI_per_day - aiexp.AI_per_day) > 0.00001 ||
            aires.exc != aiexp.exc ||
            Cldr_Datestr2YMD(&aires.next) != Cldr_Datestr2YMD(&aiexp.next))
            diff = 1 ;

        fprintf(out, "%d; exp %lf res %lf\n",
                fabs(aires.AI - aiexp.AI) > 0.00001, aiexp.AI, aires.AI) ;
        fprintf(out, "%d; exp %d res %d\n",
                aires.AIdays != aiexp.AIdays, aiexp.AIdays, aires.AIdays) ;
        fprintf(out, "%d; exp %lf res %lf\n",
                fabs(aires.AI_per_day - aiexp.AI_per_day) > 0.00001,
                aiexp.AI_per_day, aires.AI_per_day) ;
        fprintf(out, "%d; exp %d res %d\n",
                aires.exc != aiexp.exc, aiexp.exc, aires.exc) ;
        fprintf(out, "%d; exp %d res %d\n",
                Cldr_Datestr2YMD(&aires.next) != 
                Cldr_Datestr2YMD(&aiexp.next),
                Cldr_Datestr2YMD(&aiexp.next), 
                Cldr_Datestr2YMD(&aires.next) ) ;
        fprintf(out, "\n\n") ;

        Free_FIXPAY(&fixp) ;
        Free_DATEARRAY(holi.holidays) ;
    }

    else if (!strcmp("BondPF_YTM2Yield()", txa))
    {
        fscanf(in, "%lf", &fexp) ;

        fprintf(out,"   Testing %s\n", txa) ;

        fscanf(in, "%d", &i1) ;
        ntrar = (INTI) i1 ;
        trar  = Alloc_TRADEINFOARRAY(i1) ;
        for (i = 0; i < ntrar; i++)
            trar[i] = Read_TRADEINFO(in, out) ;

        fscanf(in, "%d", &i1) ;
        nfixp  = (INTI) i1 ;
        fixpar = Alloc_FIXPAYARRAY(i1) ;
        for (i = 0; i < nfixp; i++)
            fixpar[i] = Read_FIXPAY(in, out, &trar[i].settle) ;

        ytmc   = Read_YTMCONV(in, out) ;
        holi   = Read_HOLI_STR(in, out) ;

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Init_ITERCTRL(&ictrl) ;

        if (nfixp != ntrar)
        {
            fprintf(out, "Data counts do not match\n") ;
            ok = False ;
        }

        else
            ok = BondPF_YTM2Yield(trar, fixpar, nfixp, &ytmc,
                                  &holi, &ictrl, &fres) ;

        if (ok == False)
        {
            fprintf(out, "1; Cannot find YTM\n\n") ;
            diff = 1 ;
        }
        else
        {
            diff = fabs(fres - fexp) > 0.00001 ;
            fprintf(out,
              "%d; Expected %lf Result %lf\n\n",
              diff, fexp, fres) ;
        }

        Free_DATEARRAY(holi.holidays) ;
        Free_TRADEINFOARRAY(trar) ;
        for (i = 0; i < nfixp; i++)
          Free_FIXPAY(&fixpar[i]);
        Free_FIXPAYARRAY(fixpar) ;
    }

    else if (!strcmp("BondPF_YTM2Duration()", txa))
    {
        fscanf(in, "%lf %lf", &fexp, &ytm) ;

        fprintf(out,"   Testing %s\n", txa) ;
        fprintf(out,"   YTM     %8.5lf\n", ytm) ;

        fscanf(in, "%d", &i1) ;
        ntrar = (INTI) i1 ;
        trar  = Alloc_TRADEINFOARRAY(i1) ;
        for (i = 0; i < ntrar; i++)
            trar[i] = Read_TRADEINFO(in, out) ;

        fscanf(in, "%d", &i1) ;
        nfixp  = (INTI) i1 ;
        fixpar = Alloc_FIXPAYARRAY(i1) ;
        for (i = 0; i < nfixp; i++)
            fixpar[i] = Read_FIXPAY(in, out, &trar[i].settle) ;

        ytmc   = Read_YTMCONV(in, out) ;
        holi   = Read_HOLI_STR(in, out) ;

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        if (nfixp != ntrar)
        {
            fprintf(out, "Data counts do not match\n") ;
            diff = 1 ;
        }

        else
            fres = BondPF_YTM2Duration(ytm, trar, fixpar, nfixp, &ytmc,
                                       &holi) ;

        diff = fabs(fres - fexp) > 0.00001 ;
        fprintf(out,"%d; Expected %lf Result %lf\n\n", diff, fexp, fres) ;

        Free_DATEARRAY(holi.holidays) ;
        Free_TRADEINFOARRAY(trar) ;
        for (i = 0; i < nfixp; i++)
          Free_FIXPAY(&fixpar[i]);
        Free_FIXPAYARRAY(fixpar) ;
    }


    else if (!strcmp("BondPF_DF2Hzy()", txa))
    {
        fscanf(in, "%lf", &fexp) ;

        fprintf(out,"   Testing %s\n", txa) ;

        fscanf(in, "%d", &i1) ;
        ntrar = (INTI) i1 ;
        trar  = Alloc_TRADEINFOARRAY(i1) ;
        for (i = 0; i < ntrar; i++)
            trar[i] = Read_TRADEINFO(in, out) ;

        fscanf(in, "%d", &i1) ;
        ntrah = (INTI) i1 ;
        trah  = Alloc_TRADEINFOARRAY(i1) ;
        for (i = 0; i < ntrah; i++)
            trah[i] = Read_TRADEINFO(in, out) ;

        fscanf(in, "%d", &i1) ;
        nfixp  = (INTI) i1 ;
        fixpar = Alloc_FIXPAYARRAY(i1) ;
        for (i = 0; i < nfixp; i++)
            fixpar[i] = Read_FIXPAY(in, out, &trar[i].settle) ;

        hzyc = Read_HZYCONV(in, out) ;
        dfre = Read_DISCFAC(in, out) ;
        df   = Read_DISCFAC(in, out) ;
        holi = Read_HOLI_STR(in, out) ;

        fscanf(in, "%d", &i1) ;
        ndfs = (INTI) i1 ;
        dfsa = Alloc_DFSPREADARRAY(i1) ;
        for (i = 0; i < ndfs; i++)
            dfsa[i] = Read_DFSPREAD(in, out) ;

        ictrl = Read_ITERCTRL(in, out) ;

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        if (nfixp != ntrar || ntrar != ntrah || ndfs != ntrah)
        {
            fprintf(out, "Data counts do not match\n") ;
            ok = False ;
        }

        else
            ok = BondPF_DF2Hzy(trar, trah, fixpar, nfixp, &hzyc,
                               &dfre, &df, &holi, dfsa, &ictrl, &fres) ;

        if (ok == False)
        {
            fprintf(out, "1; Cannot find HZY\n\n") ;
            diff = 1 ;
        }
        else
        {
            diff = fabs(fres - fexp) > 0.00001 ;
            fprintf(out,
              "%d; Expected %lf Result %lf\n\n",
              diff, fexp, fres) ;
        }

        Free_DATEARRAY(holi.holidays) ;
        Free_TRADEINFOARRAY(trar) ;
        Free_TRADEINFOARRAY(trah) ;
        for (i = 0; i < nfixp; i++)
          Free_FIXPAY(&fixpar[i]);
        Free_FIXPAYARRAY(fixpar) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_PLANARRAY(dfre.disc, 1) ;

        for (i = 0; i < ndfs; i++)
            Free_DFSPREAD(&dfsa[i]) ;
        Free_DFSPREADARRAY(dfsa) ;
    }

    else if (!strcmp("Bond_MergeCFLWARRAY()", txa))
    {
        fprintf(out,"\n   Testing %s\n", txa) ;

        fscanf(in, "%d", &i1) ;
        ntrar = (INTI) i1 ;
        trar  = Alloc_TRADEINFOARRAY(i1) ;
        for (i = 0; i < ntrar; i++)
            trar[i] = Read_TRADEINFO(in, out) ;

        fscanf(in, "%d", &i1) ;
        nfixp  = (INTI) i1 ;
        fixpar = Alloc_FIXPAYARRAY(i1) ;
        for (i = 0; i < nfixp; i++)
            fixpar[i] = Read_FIXPAY(in, out, &trar[i].settle) ;

        holi  = Read_HOLI_STR(in, out) ;
        cflw = Read_CFLWARRAY(in, out) ;
        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n", txpl) ;

        mcflw = Bond_MergeCFLWARRAY(trar, fixpar, nfixp, &holi) ;
        diff  = Write_CflwDiff(cflw, mcflw, out) ;

        for (i = 0; i < nfixp; i++)
          Free_FIXPAY(&fixpar[i]);
        Free_FIXPAYARRAY(fixpar) ;
        Free_DATEARRAY(holi.holidays) ;
        Free_CFLWARRAY(cflw, 1) ;
        Free_CFLWARRAY(mcflw, 1) ;
        Free_TRADEINFOARRAY(trar) ;
    }

    else if (!strcmp("Bond_GenrXtraOrdAmort()", txa))
    {
        fprintf(out,"\n   Testing %s\n", txa) ;

        /* Read data */
        trade = Read_TRADEINFO(in, out) ;
        fixp = Read_FIXPAY(in, out, &trade.settle) ;
        xredemp = Read_PLANARRAY(in) ;
        fprintf(out, "    Extraordinary redemptions:\n");
        Write_PLANARRAY(out, xredemp) ;
         
        /* Exp amort */
        exp_amort = Read_PLANARRAY(in) ;

        /* Merge */
        amort = Bond_GenrXtraOrdAmort(&trade, &fixp, xredemp) ;

        /* Compare */
        diff  = Write_PlanDiff(exp_amort, amort, out) ;

        /* Comments */
        IOUtil_ParseLine(in, out) ;

        Free_FIXPAY(&fixp);
        Free_PLANARRAY(xredemp, 1) ;
        Free_PLANARRAY(amort, 1) ;
        Free_PLANARRAY(exp_amort, 1) ;
    }

    else if (!strcmp("Cflw_Amort2Prepay()", txa))
    {
        fprintf(out,"\n   Testing %s\n", txa) ;

        /* Read data */
        amort = Read_PLANARRAY(in) ;
        fprintf(out, "Ordinary amortisations:\n");
        Write_PLANARRAY(out, amort) ;
        exp_amort = Read_PLANARRAY(in) ;
        fprintf(out, "Post-prepayment amortisations:\n");
        Write_PLANARRAY(out, exp_amort) ;
        prepayc = Read_PREPAYCONV(in, out, 
                     "Prepayment convention ") ;
        pfreq = Read_PMTFREQ(in, out,
                     "Payment frequency     ") ;

         
        /* Exp prepayments */
        xredemp = Read_PLANARRAY(in) ;

        /* Compute */
        prepay = Cflw_Amort2Prepay(amort, exp_amort, prepayc, pfreq);

        /* Compare */
        diff  = Write_PlanDiff(xredemp, prepay, out) ;

        /* Comments */
        IOUtil_ParseLine(in, out) ;

        Free_PLANARRAY(xredemp, 1) ;
        Free_PLANARRAY(amort, 1) ;
        Free_PLANARRAY(exp_amort, 1) ;
        Free_PLANARRAY(prepay, 1) ;
    }

    else if (!strcmp("Cflw_CheckAmortsInNewAmorts()", txa))
    {
        fprintf(out,"\n   Testing %s\n", txa) ;

        /* Read data */
        amort = Read_PLANARRAY(in) ;
        fprintf(out, "Ordinary amortisations:\n");
        Write_PLANARRAY(out, amort) ;
        exp_amort = Read_PLANARRAY(in) ;
        fprintf(out, "Post-prepayment amortisations:\n");
        Write_PLANARRAY(out, exp_amort) ;
         
        okexp = Read_BOOLE(in, out, "") ;

        /* Compute */
        ok = Cflw_CheckAmortsInNewAmorts(amort, exp_amort);

        /* Comments */
        IOUtil_ParseLine(in, out) ;

        /* Compare */
        if (ok == okexp)
        {
          fprintf(out, "0; Exp and got %d\n", ok);
          diff = 0;
        }
        else
        {
          fprintf(out, "1; Exp %d and got %d\n", okexp, ok);
          diff = 1;
        }

        Free_PLANARRAY(amort, 1) ;
        Free_PLANARRAY(exp_amort, 1) ;
    }

    else if (!strcmp("BondBM_YTM2Yield()", txa))
    {
        fscanf(in, "%lf %lf %lf %ld", &fexp, &acc, &price, &ymd) ;
        analys = Cldr_YMD2Datestr(ymd) ;

        fprintf(out,"\n   Testing %s\n", txa) ;
        fprintf(out,"   ACC         %lf\n", acc) ;
        fprintf(out,"   price       %lf\n", price) ;
        fprintf(out,"   Analysis    %ld\n", ymd) ;

        bond = Read_BONDBM(in, out) ;
        fscanf(in, "%s", txc) ;
        fprintf(out,"   YTM as      %s\n", txc) ;
        yseg = Str2YTMSEG(txc) ;
        holi = Read_HOLI_STR(in, out) ;

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        ok = BondBM_YTM2Yield(price, &analys, &bond, yseg, &holi, &fres) ;

        if (ok == False)
        {
            fprintf(out, "1; Cannot find YTM\n\n") ;
            diff = 1 ;
        }
        else
        {
            diff = fabs(fres - fexp) > acc ;
            fprintf(out, "%d; Expected %lf Result %lf\n\n",
                    diff, fexp, fres) ;
        }

        Free_DATEARRAY(holi.holidays) ;
    }

    else if (!strcmp("BondBM_YTM2Duration()", txa))
    {
        fscanf(in, "%lf %lf %ld", &fexp, &ytm, &ymd) ;
        analys = Cldr_YMD2Datestr(ymd) ;

        fprintf(out,"\n   Testing %s\n", txa) ;
        fprintf(out,"   YTM         %lf\n", ytm) ;
        fprintf(out,"   Analysis    %ld\n", ymd) ;

        bond = Read_BONDBM(in, out) ;
        fscanf(in, "%s", txc) ;
        fprintf(out,"   YTM as      %s\n", txc) ;
        yseg = Str2YTMSEG(txc) ;
        holi = Read_HOLI_STR(in, out) ;

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        fres = BondBM_YTM2Duration(ytm, &analys, &bond, yseg, &holi) ;
        diff = fabs(fres - fexp) > 0.0005 ;
        fprintf(out, "%d; Expected %lf Result %lf\n\n",
                diff, fexp, fres) ;

        Free_DATEARRAY(holi.holidays) ;
    }

    else if (!strcmp("BondBM_YTM2Price()", txa))
    {
        fscanf(in, "%lf %lf %ld", &fexp, &ytm, &ymd) ;
        analys = Cldr_YMD2Datestr(ymd) ;

        fprintf(out,"\n   Testing %s\n", txa) ;
        fprintf(out,"   YTM         %lf\n", ytm) ;
        fprintf(out,"   Analysis    %ld\n", ymd) ;

        bond = Read_BONDBM(in, out) ;
        fscanf(in, "%s", txc) ;
        fprintf(out,"   YTM as      %s\n", txc) ;
        yseg = Str2YTMSEG(txc) ;
        holi = Read_HOLI_STR(in, out) ;

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        fres = BondBM_YTM2Price(ytm, &analys, &bond, yseg, &holi,
                                ZERO_ORDER, False, &fres1, &fres2) ;
        diff = fabs(fres - fexp) > 0.0005 ;
        fprintf(out, "%d; Expected %lf Result %lf\n\n",
                diff, fexp, fres) ;

        Free_DATEARRAY(holi.holidays) ;
    }

    else if (!strcmp("BondBM_Accruint()", txa))
    {
        fscanf(in, "%lf %ld", &fexp, &ymd) ;
        analys = Cldr_YMD2Datestr(ymd) ;

        fprintf(out,"\n   Testing %s\n", txa) ;
        fprintf(out,"   Analysis    %ld\n", ymd) ;

        bond = Read_BONDBM(in, out) ;
        holi = Read_HOLI_STR(in, out) ;

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        fres = BondBM_Accruint(&analys, &bond, &holi) ;
        diff = fabs(fres - fexp) > 0.0005 ;
        fprintf(out, "%d; Expected %lf Result %lf\n\n",
                diff, fexp, fres) ;

        Free_DATEARRAY(holi.holidays) ;
    }

    else if (!strcmp("Cflw_YTM2YV01()", txa))
    {
        fscanf(in, "%lf", &fexp) ;

        fprintf(out,"   Testing %s\n", txa) ;

        okexp = Read_BOOLE(in, out, "  Exp. ok  ");
        fres  = Read_FL64(in, out, "  Exp. res  ");
        price = Read_FL64(in, out, "  Cash flow price  ");
        xcflw = Read_CFLWARRAY(in, out) ;
        ytmc  = Read_YTMCONV(in, out) ;
        pday  = Read_PAYDAYDEF(in, out) ;
        coup  = Read_FL64(in, out, "   Coupon: ") ;
        holi  = Read_HOLI_STR(in, out) ;
        pp    = Read_PP_STR(in, out) ;

        shift = Read_FL64(in, out, "  Price shift ");
        mean = Read_BOOLE(in, out, "  Mean ");

        IOUtil_ParseLine(in, out);

        Init_ITERCTRL(&ictrl) ;
        ok = Cflw_YTM2YV01(price, xcflw, &ytmc, &pday, coup, 
                           &pp, &holi, &ictrl, shift, mean, &fres);
        if (ok == False)
        {
            diff = (ok != okexp) ;
            fprintf(out,"%d; Cannot solve\n", diff) ;
        }
        else
        {
            diff = fabs(fres - fexp) > 0.00001 ;
            fprintf(out,
              "%d; Expected %lf Result %lf\n\n",
              diff, fexp, fres) ;
        }

        Free_DATEARRAY(holi.holidays) ;
        Free_PAYDAYDEF(&pday) ;
        Free_PLANARRAY(pp.ppmts, 1);
        Free_CFLWARRAY(xcflw, 1);
    }

    else if (!strcmp("Bond_RexIndexPrices()", txa))
    {
        fprintf(out,"   Testing %s\n", txa) ;

        quotes = Read_FL64MATRIX(in, out, &n1, &n2);

        n = Read_INTI(in, out, "Sub index");

        w_quotes = Bond_RexIndexPrices(quotes, n, &fres);

        IOUtil_ParseLine(in, out);

        e_quotes = Read_FL64ARRAY(in, &n1);
        fscanf(in, "%lf", &fexp);

        diff = Write_SingleDiff(True, True, fres, fexp, 1.0e-6, out) ;
        dif1 = WriteFL64ARRAYDiff(True, e_quotes, n1, True, w_quotes, n1,
                                  out, 1e-6);

        diff = diff || dif1;

        Free_FL64ARRAY(e_quotes);
        Free_FL64ARRAY(w_quotes);
        Free_FL64MATRIX(quotes);
    }


    return diff ;
}


/*
..
*/

INTI bondtest_diff(FL64 fres, FL64 fres1, FL64 fres2,
                   FL64 fexp, FL64 fexp1, FL64 fexp2, FL64 acc, FILE* out)
{
    INTI diff ;

    diff = (fabs(fres - fexp) > acc || fabs(fres1 - fexp1) > acc ||
            fabs(fres2 - fexp2) > acc);
    fprintf(out,"%d; 0. order derivative %8.5lf expected = %8.5lf\n",
            (fabs(fres - fexp) > acc), fres, fexp);
    fprintf(out,"%d; 1. order derivative %8.5lf expected = %8.5lf\n",
            (fabs(fres1 - fexp1) > acc), fres1, fexp1);
    fprintf(out,"%d; 2. order derivative %8.5lf expected = %8.5lf\n",
            (fabs(fres2 - fexp2) > acc), fres2, fexp2);

    return diff ;
}


/*
..
*/


INTI bootsectest(char* txa, FILE* in, FILE* out)
{
    char       txpl[120];
    INTI       i, ix ;
    INTI       diff, nholi, n ;
    FL64       acc, dacc ;
    FL64ARRAY  spread, prices, madj ;
    INTIARRAY  index ;
    YYYYMMDD   ymd ;
    DATESTR    today, dzero ;
    DATEARRAY  settle, holidays;
    BSECARRAY  secs1 ;
    int        i1, i2 ;
    HOLI_STR   holi ;

    acc   = 0.00001 ;
    dacc  = 0.000001 ;
    dzero = Cldr_YMD2Datestr((YYYYMMDD) 0) ;

    diff = -1 ;

    if (!strcmp("Boot_GenrIndex()", txa))
    {
        fscanf(in, "%ld %d %d %s", &ymd, &i2, &i1, txpl) ;
        nholi = (INTI) i2 ;
        n = (INTI) i1 ;

        secs1 = Alloc_BSECARRAY(n) ;
        prices  = Alloc_FL64ARRAY(n) ;
        spread  = Alloc_FL64ARRAY(n) ;
        madj    = Alloc_FL64ARRAY(n) ;
        settle  = Alloc_DATEARRAY(n) ;

        today = Cldr_YMD2Datestr(ymd) ;

        fprintf(out,"?; testing %s\n", txa) ;
        fprintf(out,"   today is           %8ld\n", ymd) ;

        holidays = Alloc_DATEARRAY(nholi) ;

        fprintf(out,"   the holidays are...\n") ;
        fprintf(out,"   holiday\n") ;
        for (i = 0 ; i < nholi ; i++)
        {
            fscanf(in, "%ld", &ymd) ;
            holidays[i] = Cldr_YMD2Datestr(ymd) ;
            fprintf(out,"   %8ld\n", ymd) ;
        }
        fprintf(out, "\n") ;

        for (i = 0 ; i < n ; i++)
        {
            fprintf(out, "SECURITY              %8d\n", (int) (i + 1)) ;
            secs1[i] = Read_BSEC(in, out, &prices[i], &spread[i],
                                 &madj[i], &settle[i]) ;
        }

        holi.nholi    = nholi ;
        holi.holidays = holidays ;

        index = Boot_GenrIndex(secs1, settle, n, &holi) ;

        diff = 0 ;
        fprintf(out, "\n    Exp.Index  Calc.Index\n") ;

        for (i = 0 ; i < n; i++)
        {
            fscanf(in,"%d", &i1) ;
            ix = (INTI) i1 ;

            diff = diff || (ix != index[i]) ;
            fprintf(out,"%d; %10d %10d\n", (int) (ix != index[i]),
                    (int) ix, (int) index[i]) ;

        }

        fprintf(out,"   %s\n\n", txpl) ;

        Free_FL64ARRAY(madj) ;
        Free_FL64ARRAY(prices) ;
        Free_FL64ARRAY(spread) ;
        Free_DATEARRAY(holidays) ;
        Free_DATEARRAY(settle) ;
        Free_BSECARRAY(secs1) ;
        Free_INTIARRAY(index) ;
    }


    return diff ;
}

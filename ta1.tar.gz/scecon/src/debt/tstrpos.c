/* @(#)tstrpos.c	1.5 (SimCorp) 99/02/19 14:12:46 */

/************************************************************************
*
*   project     SCecon
*
************************************************************************/

/*** includes ***********************************************************/
#include <string.h>
#include <riskpos.h>
#include <ioconv.h>
#include <idxbond.h>
#include <bondio.h>

INTI rpostest(char* txa, FILE* in, FILE* out)
{
    char            txb[25], txpl[125] ;
    int             i1 ;
    FL64            notnal, tol ;
    HOLI_STR        holi ;
    CFLWARRAY       xcflw ;
    BOOLE           zero, idxadj ;
    INTI            nbuck, diff, i ;
    YYYYMMDD        ymd ;
    DATESTR         matur, analys ;
    DISCFAC         df ;
    PP_STR          pp ;
    FIXPAY          fixp ;
    BUCKETARRAY     bucket ;
    DFSPREAD        dfs ;
    TRADEINFO       trade;
    DEPOSIT         depo ;
    DELTASET        ds ;
    RISKPOSLIST     rpos, exprpos ;
    INDEXFAC        fac, debfac, crefac ;
    INDEXBOND       idxbond ;
    INDEXLOAN       idxloan ;
    FXRISKSET       fxr;

    diff = -1 ;

    if (!strcmp("Cflw_DF2RiskPos()", txa))
    {
        fscanf(in, "%lf %ld", &tol, &ymd) ;

        analys = Cldr_YMD2Datestr(ymd) ;

        fprintf(out,"   Testing %s\n", txa) ;
        fprintf(out,"   analys      %ld\n", ymd) ;

        xcflw  = Read_CFLWARRAY(in, out) ;
        pp     = Read_PP_STR(in, out) ;
        fscanf(in, "%lf", &notnal) ;
        fprintf(out,"   Notional    %lf\n", notnal) ;
        df     = Read_DISCFAC(in, out) ;
        dfs    = Read_DFSPREAD(in, out) ;
        holi   = Read_HOLI_STR(in, out) ;
        bucket = Read_BUCKETARRAY(in, out, &nbuck) ;

        fscanf(in, "%s", txb) ;
        zero = Str2BOOLE(txb) ;
        fprintf(out,"   DECF        %8s\n", txb) ;

        fxr = Read_FXRISKSET(in, out) ;

        ds = Disc_DeltaPrep(&df, bucket, nbuck, &holi, True, df.irr,
                             df.freq, False, zero, DF_BOTH) ;

        rpos = Cflw_DF2RiskPos(&analys, xcflw, &pp, notnal, &df,
                               &dfs, &holi, &ds, &fxr) ;

        exprpos.token = Alloc_RISKTOKENARRAY(rpos.npos) ;
        exprpos.pos   = Alloc_FL64ARRAY(rpos.npos) ;
        exprpos.npos  = rpos.npos ;

        for (i = 0; i < exprpos.npos; i++)
        {
            Read_RISKTOKEN(in, out, &exprpos.token[i]) ;
            fscanf(in, "%lf", &exprpos.pos[i]) ;
        }

        diff = Write_riskposdiff(exprpos, rpos, out, tol) ;

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_CFLWARRAY(xcflw, 1) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_DATEARRAY(holi.holidays) ;
        Free_BUCKETARRAY(bucket) ;
        Free_DELTASET(&ds) ;
        Free_RISKPOSLIST(&rpos);
        Free_RISKPOSLIST(&exprpos);
        Free_DFSPREAD(&dfs) ;
    }

    else if (!strcmp("RepoCflw_DF2RiskPos()", txa))
    {
        fscanf(in, "%lf %ld", &tol, &ymd) ;

        analys = Cldr_YMD2Datestr(ymd) ;

        fprintf(out,"   Testing %s\n", txa) ;
        fprintf(out,"   analys      %ld\n", ymd) ;

        xcflw  = Read_CFLWARRAY(in, out) ;

        fscanf(in, "%ld", &ymd) ;
        matur = Cldr_YMD2Datestr(ymd) ;
        fprintf(out,"   matur       %ld\n", ymd) ;

        pp     = Read_PP_STR(in, out) ;
        fscanf(in, "%lf", &notnal) ;
        fprintf(out,"   Notional    %lf\n", notnal) ;
        df     = Read_DISCFAC(in, out) ;
        dfs    = Read_DFSPREAD(in, out) ;
        holi   = Read_HOLI_STR(in, out) ;
        bucket = Read_BUCKETARRAY(in, out, &nbuck) ;

        fscanf(in, "%s", txb) ;
        zero = Str2BOOLE(txb) ;
        fprintf(out,"   DECF        %8s\n", txb) ;

        fxr = Read_FXRISKSET(in, out) ;

        ds = Disc_DeltaPrep(&df, bucket, nbuck, &holi, True, df.irr,
                             df.freq, False, zero, DF_BOTH) ;

        rpos = RepoCflw_DF2RiskPos(&analys, xcflw, &matur, &pp, notnal, 
                                   &df, &dfs, &holi, &ds, &fxr) ;

        exprpos.token = Alloc_RISKTOKENARRAY(rpos.npos) ;
        exprpos.pos   = Alloc_FL64ARRAY(rpos.npos) ;
        exprpos.npos  = rpos.npos ;

        for (i = 0; i < exprpos.npos; i++)
        {
            Read_RISKTOKEN(in, out, &exprpos.token[i]) ;
            fscanf(in, "%lf", &exprpos.pos[i]) ;
        }

        diff = Write_riskposdiff(exprpos, rpos, out, tol) ;

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_CFLWARRAY(xcflw, 1) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_DATEARRAY(holi.holidays) ;
        Free_BUCKETARRAY(bucket) ;
        Free_DELTASET(&ds) ;
        Free_RISKPOSLIST(&rpos);
        Free_RISKPOSLIST(&exprpos);
        Free_DFSPREAD(&dfs) ;
    }

    else if (!strcmp("Bond_DF2RiskPos()", txa))
    {
        fscanf(in, "%lf %ld", &tol, &ymd) ;

        analys = Cldr_YMD2Datestr(ymd) ;

        fprintf(out,"   Testing %s\n", txa) ;
        fprintf(out,"   analys      %ld\n", ymd) ;

        trade  = Read_TRADEINFO(in, out) ;
        fixp   = Read_FIXPAY(in, out, &trade.settle) ;
        fscanf(in, "%lf", &notnal) ;
        fprintf(out,"   Notional    %lf\n", notnal) ;
        df     = Read_DISCFAC(in, out) ;
        dfs    = Read_DFSPREAD(in, out) ;
        holi   = Read_HOLI_STR(in, out) ;
        bucket = Read_BUCKETARRAY(in, out, &nbuck) ;

        fscanf(in, "%s", txb) ;
        zero = Str2BOOLE(txb) ;
        fprintf(out,"   DECF        %8s\n", txb) ;

        fxr = Read_FXRISKSET(in, out) ;

        ds = Disc_DeltaPrep(&df, bucket, nbuck, &holi, True, df.irr,
                             df.freq, False, zero, DF_BOTH) ;

        rpos = Bond_DF2RiskPos(&analys, &trade, &fixp, notnal, 
                               &df, &dfs, &holi, &ds, &fxr) ;

        exprpos.token = Alloc_RISKTOKENARRAY(rpos.npos) ;
        exprpos.pos   = Alloc_FL64ARRAY(rpos.npos) ;
        exprpos.npos  = rpos.npos ;

        for (i = 0; i < exprpos.npos; i++)
        {
            Read_RISKTOKEN(in, out, &exprpos.token[i]) ;
            fscanf(in, "%lf", &exprpos.pos[i]) ;
        }

        diff = Write_riskposdiff(exprpos, rpos, out, tol) ;

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_FIXPAY(&fixp) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_DATEARRAY(holi.holidays) ;
        Free_BUCKETARRAY(bucket) ;
        Free_DELTASET(&ds) ;
        Free_RISKPOSLIST(&rpos);
        Free_RISKPOSLIST(&exprpos);
        Free_DFSPREAD(&dfs) ;
    }


    else if (!strcmp("Deposit_DF2RiskPos()", txa))
    {
        fscanf(in, "%lf %ld", &tol, &ymd) ;

        analys = Cldr_YMD2Datestr(ymd) ;

        fprintf(out,"   Testing %s\n", txa) ;
        fprintf(out,"   analys      %ld\n", ymd) ;

        depo   = Read_DEPOSIT(in, out) ;
        fscanf(in, "%lf", &notnal) ;
        fprintf(out,"   Notional    %lf\n", notnal) ;
        df     = Read_DISCFAC(in, out) ;
        dfs    = Read_DFSPREAD(in, out) ;
        holi   = Read_HOLI_STR(in, out) ;
        bucket = Read_BUCKETARRAY(in, out, &nbuck) ;

        fscanf(in, "%s", txb) ;
        zero = Str2BOOLE(txb) ;
        fprintf(out,"   DECF        %8s\n", txb) ;

        fxr = Read_FXRISKSET(in, out) ;

        ds = Disc_DeltaPrep(&df, bucket, nbuck, &holi, True, df.irr,
                             df.freq, False, zero, DF_BOTH) ;

        rpos = Deposit_DF2RiskPos(&analys, &depo, notnal, &df, &dfs, 
                                  &holi, &ds, &fxr) ;

        exprpos.token = Alloc_RISKTOKENARRAY(rpos.npos) ;
        exprpos.pos   = Alloc_FL64ARRAY(rpos.npos) ;
        exprpos.npos  = rpos.npos ;

        for (i = 0; i < exprpos.npos; i++)
        {
            Read_RISKTOKEN(in, out, &exprpos.token[i]) ;
            fscanf(in, "%lf", &exprpos.pos[i]) ;
        }

        diff = Write_riskposdiff(exprpos, rpos, out, tol) ;

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_DATEARRAY(holi.holidays) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_DELTASET(&ds) ;
        Free_BUCKETARRAY(bucket) ;
        Free_RISKPOSLIST(&rpos);
        Free_RISKPOSLIST(&exprpos);
        Free_DFSPREAD(&dfs) ;
    }


    else if (!strcmp("IndexBond_DF2RiskPos()", txa))
    {
        fprintf(out,"   Testing %s\n", txa) ;

        /* Read data */
        tol     = Read_FL64(in, out, "Tolerance   ") ;
        analys  = Read_DATESTR(in, out, "Analys date  ") ;
        trade   = Read_TRADEINFO(in, out) ;
        idxbond = Read_INDEXBOND(in, out, &trade.settle) ;
        notnal  = Read_FL64(in, out, "Notional  ") ;
        fac     = Read_INDEXFAC(in, out) ;
        df      = Read_DISCFAC(in, out) ;
        dfs     = Read_DFSPREAD(in, out) ;
        holi    = Read_HOLI_STR(in, out) ;
        idxadj  = Read_BOOLE(in, out, "Index adjusted price  ") ;
        bucket  = Read_BUCKETARRAY(in, out, &nbuck) ;
        zero    = Read_BOOLE(in, out, "DECF  ") ;
        fxr     = Read_FXRISKSET(in, out) ;

        /* Initialise */
        ds = Disc_DeltaPrep(&df, bucket, nbuck, &holi, True, df.irr,
                             df.freq, False, zero, DF_BOTH) ;

        /* Calculate */
        rpos = IndexBond_DF2RiskPos(&analys, &trade, &idxbond, notnal, 
                                    &fac, &df, &dfs, &holi, idxadj,
                                    &ds, &fxr) ;

        /* Read expected results */
        fscanf(in, "%d", &i1) ;
        exprpos.npos  = (INTI) i1 ;
        exprpos.token = Alloc_RISKTOKENARRAY(exprpos.npos) ;
        exprpos.pos   = Alloc_FL64ARRAY(exprpos.npos) ;

        for (i = 0; i < exprpos.npos; i++)
        {
            Read_RISKTOKEN(in, out, &exprpos.token[i]) ;
            fscanf(in, "%lf", &exprpos.pos[i]) ;
        }

        /* Compare */
        diff = Write_riskposdiff(exprpos, rpos, out, tol) ;
    
        /* Comments */
        IOUtil_ParseLine(in, out) ;

        Free_FIXPAY(&idxbond.fixp) ;
        Free_PLANARRAY(fac.idxfac, 1) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_DATEARRAY(holi.holidays) ;
        Free_BUCKETARRAY(bucket) ;
        Free_DELTASET(&ds) ;
        Free_RISKPOSLIST(&rpos);
        Free_RISKPOSLIST(&exprpos);
        Free_DFSPREAD(&dfs) ;
    }

    else if (!strcmp("IndexLoan_DF2RiskPos()", txa))
    {
        fprintf(out,"   Testing %s\n", txa) ;

        /* Read data */
        tol     = Read_FL64(in, out, "Tolerance   ") ;
        analys  = Read_DATESTR(in, out, "Analys date  ") ;
        idxloan = Read_INDEXLOAN(in, out) ;
        notnal  = Read_FL64(in, out, "Notional  ") ;
        debfac  = Read_INDEXFAC(in, out) ;
        crefac  = Read_INDEXFAC(in, out) ;
        df      = Read_DISCFAC(in, out) ;
        dfs     = Read_DFSPREAD(in, out) ;
        holi    = Read_HOLI_STR(in, out) ;
        idxadj  = Read_BOOLE(in, out, "Index adjusted price  ") ;
        bucket  = Read_BUCKETARRAY(in, out, &nbuck) ;
        zero    = Read_BOOLE(in, out, "DECF  ") ;
        fxr     = Read_FXRISKSET(in, out) ;

        /* Initialise */
        ds = Disc_DeltaPrep(&df, bucket, nbuck, &holi, True, df.irr,
                             df.freq, False, zero, DF_BOTH) ;

        /* Calculate */
        rpos = IndexLoan_DF2RiskPos(&analys, &idxloan, notnal, &debfac, 
                                    &crefac, &df, &dfs, &holi, idxadj,
                                    &ds, &fxr) ;

        /* Read expected results */
        fscanf(in, "%d", &i1) ;
        exprpos.npos  = (INTI) i1 ;
        exprpos.token = Alloc_RISKTOKENARRAY(exprpos.npos) ;
        exprpos.pos   = Alloc_FL64ARRAY(exprpos.npos) ;

        for (i = 0; i < exprpos.npos; i++)
        {
            Read_RISKTOKEN(in, out, &exprpos.token[i]) ;
            fscanf(in, "%lf", &exprpos.pos[i]) ;
        }

        /* Compare */
        diff = Write_riskposdiff(exprpos, rpos, out, tol) ;
    
        /* Comments */
        IOUtil_ParseLine(in, out) ;

        Free_PLANARRAY(debfac.idxfac, 1) ;
        Free_PLANARRAY(crefac.idxfac, 1) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_DATEARRAY(holi.holidays) ;
        Free_BUCKETARRAY(bucket) ;
        Free_DELTASET(&ds) ;
        Free_RISKPOSLIST(&rpos);
        Free_RISKPOSLIST(&exprpos);
        Free_DFSPREAD(&dfs) ;
    }


    return diff ;
}




/*
..
*/



/* SCID @(#)exdays.c	1.3 (SimCorp) 99/02/19 14:12:05 */

/************************************************************************
*
*   project     SCecon
*
*   filename    exdays.c
*
*   general     This file contains standard cash flow routines of
*               SCecon Library
*
************************************************************************/

/* includes ************************************************************/
#include <cflw.h>

/*
*************************************************************************
*
*               Cflw_Is_Excoupon()
*
*    interface  #include <cflw.h>
*               BOOLE Cflw_Is_Excoupon(DATESTR *dsettle,
*                                      DATESTR *dcoupon,
*                                      INTI    ds) ;
*
*    general    Cflw_Is_Excoupon() checks if a bond is ex coupon at
*               date dsettle.
*
*               For german bonds special rules applies, why you should
*               use cldr_is_excouponBRD()
*
*    input      DATESTR * dsettle    Pointer to value date of the bond.
*
*               DATESTR * dcoupon    Pointer to the next coupon date.
*
*               INTI      ds         Number of days in the ex-coupon
*                                    period.
*
*    output
*
*    returns    True if the bond is ex coupon, False if not.
*
*    diagnostics
*
*    see also   Cflw_Is_ExcouponBRD()
*               Cflw_Is_Date_Ex()
*
*************************************************************************
*/


BOOLE Cflw_Is_Excoupon(DATESTR* dsettle,
                       DATESTR*  dcoupon,
                       INTI      ds)
{
    DATESTR dex ;

    dex = Cldr_AddDays(dcoupon, - (INTL) ds, ACTACT, NULL) ;    /* PMSTA-22396 - SRIDHARA � 160502 */
    return Cflw_Is_Exprincipal(dsettle, &dex) ;
}


/*
*************************************************************************
*
*               Cflw_Is_ExcouponBRD()
*
*   interface   #include <cflw.h>
*               BOOLE Cflw_Is_ExcouponBRD(DATESTR *dsettle,
*                                         DATESTR *dcoupon) ;
*
*   general     Cflw_Is_ExcouponBRD() checks if a bond following the
*               special German rules is ex coupon.
*               According to these rules a bond is ex-coupon if the
*               settlement date is at the 15th of a month, or later
*               and coupons are paid at any date between the 18th of
*               the same month and the 3rd of the following month.
*               Otherwise the bond is ex coupon if the settlement is
*               at the 1st of a month, or later, and coupons are paid
*               between the 4th and the 17th of this month.
*
*   input       DATESTR  *dsettle    Pointer to the valuedate.
*
*               DATESTR  *dcoupon    Pointer to the next coupon date.
*
*   output
*
*   returns     True if the bond is ex coupon, False if not.
*
*   diagnostics
*
*   see also    Cflw_Is_Excoupon()
*               Cflw_Is_Date_Ex()
*
*************************************************************************
*/


BOOLE Cflw_Is_ExcouponBRD(DATESTR* dsettle,
                          DATESTR*  dcoupon)
{
    DATESTR dprev;

    dprev = Cldr_AddMonths(dcoupon, -1, SAME);
    if (dsettle->d >= 15)
    {
        if ((dcoupon->d >= 18 && dcoupon->m == dsettle->m) ||
             (dcoupon->d <= 3 && dsettle->m == dprev.m))
            return ((Cldr_DateLE(dcoupon, dsettle) == True) ? False : True);
    }
    else if (dsettle->d >= 1)
    {
        if (dcoupon->d >= 4 && dcoupon->m == dsettle->m && dcoupon->d <= 17)
            return ((Cldr_DateLE(dcoupon, dsettle) == True) ? False : True);
    }
    return False;
}


/*
*************************************************************************
*
*               Cflw_Is_Exprincipal()
*
*   interface   #include <cflw.h>
*               BOOLE Cflw_Is_Exprincipal(DATESTR *dsettle,
*                                         DATESTR *dpublic) ;
*
*   general     Checks if a bond that goes ex principal on the date
*               dpublic is ex principal on the date dsettle.
*
*   input       DATESTR  *dsettle    Pointer to the value date.
*
*               DATESTR  *dpublic    Pointer to the ex-principal
*                                    date.
*
*   output
*
*   returns     True if the bond is ex principal on dsettle, False
*               if not.
*
*   diagnostics
*
*   see also    Cflw_Is_Date_Ex()
*
*************************************************************************
*/


BOOLE Cflw_Is_Exprincipal(DATESTR* dsettle,
                          DATESTR*  dpublic)
{
    if (Cldr_DateLE(dpublic, dsettle) == True)
        return True ;
    else
        return False ;
}


/*
*************************************************************************
*
*               Cflw_Is_Date_Ex()
*
*   interface   #include <cflw.h>
*               BOOLE Cflw_Is_Date_Ex(DATESTR   *dsettle,
*                                     DATEARRAY days,
*                                     FL64ARRAY pmts,
*                                     DATEARRAY xdays,
*                                     INTI      ncflw,
*                                     INTI      excdays,
*                                     BOOLE     xdays_ok,
*                                     BOOLE     BRDrule) ;
*
*   general     Checks if a bond is ex on a given date, using either
*               information on the number of ex coupon days, excdays,
*               or a set of predefined exdays, xdays.
*               The switching is controlled by xdays_ok.
*
*               If BRDrule is True the ex calculation is performed
*               using the German Kassenverein set of rules.
*
*   input       DATESTR   *dsettle   Pointer to the value date.
*
*               DATEARRAY days       Array of payment dates.
*                                    An array with ncflw elements.
*
*               FL64ARRAY  pmts      The payments corresponding to
*                                    days.
*                                    An array with ncflw elements.
*                                    Could be either coupons or
*                                    repayments.
*
*               DATEARRAY xdays      Array of excoupon dates.
*                                    An array with ncflw elements.
*
*               INTI      ncflw      Number of elements in days, pmts
*                                    and xdays.
*
*               INTI      excdays    Number of excoupon days, ie. the
*                                    number of calendar days before a
*                                    coupon day, where the bond goes
*                                    ex.
*
*               BOOLE     xdays_ok   If True then the dates in xdays
*                                    are used in the evaluation.
*                                    If False excdays are used.
*
*               BOOLE     BRDrule    True if the Kassenverein rules are
*                                    to be used.
*
*   output
*
*   returns     True if the bond is ex on dsettle, False if not.
*
*   diagnostics
*
*   see also    Cflw_Is_Excoupon()
*               Cflw_Is_Exprincipal()
*
*************************************************************************
*/


BOOLE Cflw_Is_Date_Ex(DATESTR* dsettle, DATEARRAY days,
                      FL64ARRAY pmts, DATEARRAY xdays,
                      INTI  ncflw, INTI  excdays,
                      BOOLE xdays_ok, BOOLE BRDrule)
{
    BOOLE   exc ;
    INTI    ix ;

    /* First find next payday */
    ix = Cldr_FindDateIndex(days, ncflw, dsettle, 1,
                             SEARCH_BISECTION, NEXTINDEX) ;
    ix = Cflw_FindNextPmt(pmts, ncflw, ix - 1) ;
    if (ix >= ncflw)
        return False ;

    if (BRDrule == True)
        exc = Cflw_Is_ExcouponBRD(dsettle, &days[ix]) ;

    else if (xdays_ok == True)
        exc = Cflw_Is_Exprincipal(dsettle, &xdays[ix]) ;
    else
        exc = Cflw_Is_Excoupon(dsettle, &days[ix], excdays) ;

    return exc ;
}

/*,,SOH,,
*************************************************************************
*
*               Cflw_XdayCalc()
*
*   interface   #include <cflw.h>
*               BOOLE Cflw_XdayCalc(DATESTR   *dsettle,
*                                   DATESTR   *prev,
*                                   DATESTR   *next,
*                                   DATESTR   *last,
*                                   EXRULE    *exr,
*                                   EXTRADE   *extr,
*                                   HOLI_STR  *holi)
*
*   general     Checks if a bond is ex on a given date. Can be used
*               for ex-coupon or ex-principal calculation.
*
*   input       DATESTR   *dsettle   Pointer to the value date.
*
*               DATESTR   *prev      The last previous payday (or issue)*
*                                    Only used if exr->xconv is EX_DATE
*
*               DATESTR   *next      The first coming payday
*
*               DATESTR   *last      The last payday
*
*               EXRULE    *exr       Rules for ex-calculation
*
*               EXTRADE   *extr      Special agreements
*                                    Overrules exr if entered.
*
*               HOLI_STR  *holi      Businessday setup. holi->bus is
*                                    not used.
*
*   output
*
*   returns     True if the bond is ex on dsettle, False if not.
*
*   diagnostics
*
*   see also
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/


BOOLE Cflw_XdayCalc(DATESTR* dsettle,
                    DATESTR*   prev,
                    DATESTR*   next,
                    DATESTR*   last,
                    EXRULE*    exr,
                    EXTRADE*   extr,
                    HOLI_STR*  holi)
{
    BOOLE     exc1 ;
    DATESTR   jan1_96, pr, dex ;
    INTI      ix, i ;
    EXRULE    extmp ;

/*
printf("prev %ld settle %ld next %ld\n",
Cldr_Datestr2YMD(prev), Cldr_Datestr2YMD(dsettle), Cldr_Datestr2YMD(next)) ;
*/

    exc1 = False ;

    /* This is special */
    if (extr->spec == True)
        exc1 = extr->ex_fix ;

    /* Now handle the regular case */
    else if (Cldr_DateEQ(next, last) == True && exr->xlast == False)
        exc1 = False ;
    else if (extr->spec == False && exr->xconv == EX_DAYS)
    {
        if (exr->caldays == True)
        {
			dex = Cldr_AddDays(next, -(INTL)exr->exdays, exr->cal, holi); 	/* PMSTA-22396 - SRIDHARA � 160502 */
            if (Cldr_DateLE(&dex, dsettle) == True)
                 exc1 = True ;
        }
        else
        {
            dex = Cldr_AddBusinessdays(next, - (INTL) exr->exdays,
                                       holi->nholi, holi->holidays) ;
            if (Cldr_DateLE(&dex, dsettle) == True)
                 exc1 = True ;
        }
    }

    else if (extr->spec == False && exr->xconv == EX_DATE)
    {
        if (Cldr_DateLE(&exr->dex, dsettle) == True &&
            Cldr_DateLE(prev, &exr->dex) == True)
            exc1 = True ;
    }

    else if (extr->spec == False && exr->xconv == EX_DATEARRAY)
    {
        /* First find the dateindex */
        ix = Cldr_FindDateIndex(exr->pday, exr->npday, dsettle, 0,
                                 SEARCH_BISECTION, NEXTINDEX) ;
        if (ix >= exr->npday)
            exc1 = False ;
        else
        {
            dex = exr->xpday[ix] ;
            if (ix > 0)
                pr = exr->pday[ix - 1] ;
            else
                pr = Cldr_YMD2Datestr((YYYYMMDD) 0) ;

            if (Cldr_DateLE(&dex, dsettle) == True &&
                Cldr_DateLE(&pr, &dex) == True)
                exc1 = True ;
        }
    }

    else if (extr->spec == False && exr->xconv == EX_AUT)
    {
        dex = *next ;
        if (next->d >= 10 && next->d <= 24)
        {
            dex.d = 1 ;

            /* Find first monday */
            for (i = 0; i < 8; i++)
            {
                if (Cldr_Weekday(&dex) == 1)
                    break ;
                dex.d += 1 ;
            }
        }
        else
        {
            if (next->d < 10)
                dex = Cldr_AddMonths(&dex, -1, SAME) ;
            dex.d = 14 ;

            /* Find first monday after the 14'th */
            for (i = 0; i < 8; i++)
            {
                if (Cldr_Weekday(&dex) == 1)
                    break ;

                dex.d += 1 ;
            }
        }

        if (Cldr_DateLE(&dex, dsettle) == True)
             exc1 = True ;
    }

    else if (extr->spec == False && exr->xconv == EX_OLDBRD)
    {
        dex = *next ;
        if (next->d >= 3 && next->d <= 16)
            dex.d = 1 ;
        else
        {
            dex.d = 16 ;
            if (next->d < 3)
                dex = Cldr_AddMonths(&dex, -1, SAME) ;
        }
        if (Cldr_DateLE(&dex, dsettle) == True)
             exc1 = True ;
    }

    else if (extr->spec == False && exr->xconv == EX_UKGILT)
    {
        jan1_96 = Cldr_YMD2Datestr((YYYYMMDD) 19960101) ;
        
        if (Cldr_DateLT(dsettle, &jan1_96) == True)
        {
            i = next->m ;
            if ((i == 1 || i == 4 || i == 7 || i == 10) &&
                next->d >= 5 && next->d <= 8)
            {
                dex = Cldr_AddMonths(next, -1, SAME) ;
                dex.d = 1 ;

                if (Cldr_DateLE(&dex, dsettle) == True)
                    exc1 = True ;
            }
            else
            {
                extmp = Set_EXRULE(EX_DAYS, 37, True, ACTACT, next,
                                        0, NULL, NULL, exr->xlast) ;
                exc1 = Cflw_XdayCalc(dsettle, prev, next, last, &extmp, 
                                     extr, holi) ;
            }
        }
        else
        {
            extmp = Set_EXRULE(EX_DAYS, 7, False, ACTACT, next,
                                    0, NULL, NULL, exr->xlast) ;
            exc1  = Cflw_XdayCalc(dsettle, prev, next, last, &extmp, 
                                  extr, holi) ;
        }
    }

    else if (extr->spec == False && exr->xconv == EX_IRLGILT)
    {
		dex = Cldr_AddDays(next, (INTL)-21, ACTACT, NULL); 	/* PMSTA-22396 - SRIDHARA � 160502 */
        i   = Cldr_Weekday(&dex) ;
        if (i == 7)
            i = 0 ;

        /* Nearest wednesday is: */
		dex = Cldr_AddDays(&dex, 3 - i, ACTACT, NULL); 	/* PMSTA-22396 - SRIDHARA � 160502 */

        if (Cldr_DateLE(&dex, dsettle) == True)
             exc1 = True ;
    }

    return exc1 ;
}


/*
..
*/


DATESTR Cflw_Exday(DATESTR* dsettle,
                   DATESTR*   next,
                   EXRULE*    exr,
                   HOLI_STR*  holi)
{
    DATESTR   jan1_96, dex ;
    INTI      ix, i ;

    dex = *next ;

    /* Now handle the regular case */
    if (exr->xconv == EX_DAYS)
    {
        if (exr->caldays == True)
			dex = Cldr_AddDays(next, -(INTL)exr->exdays, exr->cal, holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */
        else
            dex = Cldr_AddBusinessdays(next, - (INTL) exr->exdays,
                                       holi->nholi, holi->holidays) ;
    }

    else if (exr->xconv == EX_DATE)
        dex = exr->dex ;

    else if (exr->xconv == EX_DATEARRAY)
    {
        /* First find the dateindex */
        ix = Cldr_FindDateIndex(exr->pday, exr->npday, dsettle, 0,
                                 SEARCH_BISECTION, NEXTINDEX) ;
        if (ix >= exr->npday)
            dex = *next ;
        else
            dex = exr->xpday[ix] ;
    }

    else if (exr->xconv == EX_AUT)
    {
        dex = *next ;
        if (next->d >= 10 && next->d <= 24)
        {
            dex.d = 1 ;

            /* Find first monday */
            for (i = 0; i < 8; i++)
            {
                if (Cldr_Weekday(&dex) == 1)
                    break ;
                dex.d += 1 ;
            }
        }
        else
        {
            if (next->d < 10)
                dex = Cldr_AddMonths(&dex, -1, SAME) ;
            dex.d = 14 ;

            /* Find first monday after the 14'th */
            for (i = 0; i < 8; i++)
            {
                if (Cldr_Weekday(&dex) == 1)
                    break ;

                dex.d += 1 ;
            }
        }
    }

    else if (exr->xconv == EX_OLDBRD)
    {
        dex = *next ;
        if (next->d >= 3 && next->d <= 16)
            dex.d = 1 ;
        else
        {
            dex.d = 16 ;
            if (next->d < 3)
                dex = Cldr_AddMonths(&dex, -1, SAME) ;
        }
    }

    else if (exr->xconv == EX_UKGILT)
    {
        jan1_96 = Cldr_YMD2Datestr((YYYYMMDD) 19960101) ;
        
        if (Cldr_DateLT(dsettle, &jan1_96) == True)
        {
            i = next->m ;
            if ((i == 1 || i == 4 || i == 7 || i == 10) &&
                next->d >= 5 && next->d <= 8)
            {
                dex = Cldr_AddMonths(next, -1, SAME) ;
                dex.d = 1 ;
            }
            else
				dex = Cldr_AddDays(next, -(INTL)37, ACTACT, NULL);  	/* PMSTA-22396 - SRIDHARA � 160502 */
        }
        else
            dex = Cldr_AddBusinessdays(next, - (INTL) 7,
                                       holi->nholi, holi->holidays) ;
    }

    else if (exr->xconv == EX_IRLGILT)
    {
		dex = Cldr_AddDays(next, (INTL)-21, ACTACT, NULL);  	/* PMSTA-22396 - SRIDHARA � 160502 */
        i   = Cldr_Weekday(&dex) ;
        if (i == 7)
            i = 0 ;

        /* Nearest wednesday is: */
		dex = Cldr_AddDays(&dex, 3 - i, ACTACT, NULL);  	/* PMSTA-22396 - SRIDHARA � 160502 */
    }

    return dex ;
}

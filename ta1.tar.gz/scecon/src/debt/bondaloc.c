/* SCID @(#)bondaloc.c	1.4 (SimCorp) 99/10/27 13:58:33 */

/************************************************************************
*
*   project     SCecon
*
*   file name   bondaloc.c
*
*   general     This file contains allocating routines for FIXPAY's
*
************************************************************************/

#include <bond.h>


/*,,SOH,,
*************************************************************************
*
*               Alloc_FIXPAYARRAY()
*
*    interface  #include <bond.h>
*               FIXPAYARRAY Alloc_FIXPAYARRAY(INTI n);
*
*    general    Alloc_FIXPAYARRAY() allocates memory for an
*               [0...(n-1)] array of FIXPAY's.
*               Returns memory with zero'ed entries
*
*    input      INTI    n       The number of entries in FIXPAY list
*
*    output
*
*    returns    reference to the vector of type FIXPAY
*
*    diagnostics aborts calling SCecon_error()
*                with the message   "Memory allocation error"
*                         routine   "Alloc_FIXPAYARRAY()"
*                         actioncode SCECONABORT
*                if allocation fails
*
*    see also   Free_FIXPAYARRAY()
*
*************************************************************************
,,EOH,,*/


FIXPAYARRAY Alloc_FIXPAYARRAY(INTI n)
{
    FIXPAYARRAY a;

    a = (FIXPAYARRAY) SCecon_calloc(n, sizeof(FIXPAY), True, 
      "Alloc_FIXPAYARRAY()") ;

    return a ;
}


/*,,SOH,,
*************************************************************************
*
*               Free_FIXPAYARRAY()
*
*    interface  #include <bond.h>
*               void Free_FIXPAYARRAY(FIXPAYARRAY date) ;
*
*    general    Free_FIXPAYARRAY() frees memory for an array
*               of FIXPAY's allocated by Alloc_FIXPAYARRAY()
*
*    input      FIXPAYARRAY date          Reference to the array
*
*    output
*
*    returns
*
*    diagnostics
*
*    see also   Alloc_FIXPAYARRAY()
*
*************************************************************************
,,EOH,,*/


void Free_FIXPAYARRAY(FIXPAYARRAY date)
{
    SCecon_free((VOIDPTR) date) ;
}


/*,,SOH,,
*************************************************************************
*
*               Alloc_BONDBMARRAY()
*
*    interface  #include <bond.h>
*               BONDBMARRAY Alloc_BONDBMARRAY(INTI n);
*
*    general    Alloc_BONDBMARRAY() allocates memory for an
*               [0...(n-1)] array of BONDBM's.
*               Returns memory with zero'ed entries
*
*    input      INTI    n       The number of entries in BONDBM list
*
*    output
*
*    returns    reference to the vector of type BONDBM
*
*    diagnostics aborts calling SCecon_error()
*                if allocation fails
*
*    see also   Free_BONDBMARRAY()
*
*************************************************************************
,,EOH,,*/


BONDBMARRAY Alloc_BONDBMARRAY(INTI n)
{
    BONDBMARRAY a;

    a = (BONDBMARRAY) SCecon_calloc(n, sizeof(BONDBM), True,
      "Alloc_BONDBMARRAY()") ;

    return a ;
}


/*,,SOH,,
*************************************************************************
*
*               Free_BONDBMARRAY()
*
*    interface  #include <bond.h>
*               void Free_BONDBMARRAY(BONDBMARRAY a) ;
*
*    general    Free_BONDBMARRAY() frees memory for an array
*               of BONDBM's allocated by Alloc_BONDBMARRAY()
*
*    input      BONDBMARRAY a             Reference to the array
*
*    output
*
*    returns
*
*    diagnostics
*
*    see also   Alloc_BONDBMARRAY()
*
*************************************************************************
,,EOH,,*/


void Free_BONDBMARRAY(BONDBMARRAY a)
{
    SCecon_free((VOIDPTR) a) ;
}


/*,,SOH,,
*************************************************************************
*
*               Free_FIXPAY()
*
*    interface  #include <bond.h>
*               void Free_FIXPAY(FIXPAY *fixp) ;
*
*    general    Free_FIXPAY() frees memory for a FIXPAY. All the memory
*               is suballocated in the fixp structure.
*
*    input      FIXPAY     *fixp       The bond data container
*
*    output
*
*    returns
*
*    diagnostics
*
*    see also
*
*************************************************************************
,,EOH,,*/


void Free_FIXPAY(FIXPAY* fixp)
{
    /* Free all suballocated memory */
    Free_DATEARRAY(fixp->cday.irreg_days) ;
    Free_PLANARRAY(fixp->fix.stepcoup, 1) ;
    Free_PLANARRAY(fixp->fix.irreg, 1) ;
    Free_DATEARRAY(fixp->rday.irreg_days) ;
    Free_PLANARRAY(fixp->repay.aufab, 1) ;
    Free_PLANARRAY(fixp->repay.irreg, 1) ;
    Free_PLANARRAY(fixp->repay.pp.ppmts, 1) ;
    Free_DATEARRAY(fixp->accru.exr.pday) ;
    Free_DATEARRAY(fixp->accru.exr.xpday) ;
    Free_DATEARRAY(fixp->exp.pday) ;
    Free_DATEARRAY(fixp->exp.xpday) ;
}

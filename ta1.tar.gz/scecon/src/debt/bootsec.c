/* SCID @(#)bootsec.c	1.8 (SimCorp) 99/10/27 13:58:35 */

/************************************************************************
*
*   project     SCecon
*
*   file name   bootsec.c
*
*   general     This file contains allocating routines for bootstrp
*               calculations
*
************************************************************************/

#include <bootsec.h>


/*,,SOH,,
*************************************************************************
*
*               Boot_GenrIndex()
*
*   interface   #include <bootsec.h>
*               INTIARRAY Boot_GenrIndex(BSECARRAY secs,
*                                        DATEARRAY settle,
*                                        INTI      nsec,
*                                        HOLI_STR  *holi) ;
*
*   general     The function returns the indexation order for use in
*               generating a discount function using bootstrapping.
*
*               The sort index is generated as follows:
*
*               All securities are sorted according to maturities
*               within each maturity class the securities are sorted
*               in the following sequence:
*
*               MM, SWAP/SWAPGENR, BOND, BONDSIMPL, FRA, IMMFRA,
*               IRF, AVGIRG, BONDREPO
*
*               Note that an FRA (IMMFRA) or IRF cannot be the first 
*               security in a list. This is NOT checked.
*
*   input       BSECARRAY secs     The list of securities to use for
*                                  bootstrapping (nsec securities).
*
*               DATEARRAY settle   List of individual settle days.
*
*               INTI      nsec     The number of securities in prices
*                                  and secs.
*
*               HOLI_STR  *holi    Holiday adjustment setup
*
*   output
*
*   returns     Pointer to the list of sort indices.
*               Allocated in this function with nsec entries.
*               Contains 0 through nsec-1 - each only once.
*
*   diagnostics
*
*   see also    Boot_BSEC2DF()
*
*************************************************************************
,,EOH,,*/


INTIARRAY Boot_GenrIndex(BSECARRAY secs,
                         DATEARRAY settle,
                         INTI      nsec,
                         HOLI_STR*  holi)
{
    FL64ARRAY maturs ;
    INTIARRAY index, types, tmpix, tmpix1 ;
    INTI      ix, i ;
    DATESTR   tmp ;

    /* Allocate */
    index  = Alloc_INTIARRAY(nsec) ;
    types  = Alloc_INTIARRAY(nsec) ;
    maturs = Alloc_FL64ARRAY(nsec) ;

    /* First sort with maturities then within sec.classes */
    for (i = 0; i < nsec ; i++)
    {
        if (secs[i].type == MM)
            types[i] = 1 ;
        else if (secs[i].type == SWAP || secs[i].type == SWAPGENR)
            types[i] = 2 ;
        else if (secs[i].type == BOND || secs[i].type == BONDSMPL)
            types[i] = 3 ;
        else if (secs[i].type == FRA || secs[i].type == IMMFRA)
            types[i] = 4 ;
        else if (secs[i].type == SWAPFUT)
            types[i] = 5 ;
        else if (secs[i].type == IRF)
            types[i] = 6 ;
        else if (secs[i].type == AVGIRF)
            types[i] = 7 ;
        else if (secs[i].type == BONDREPO)
            types[i] = 8 ;
    }

    tmpix = Scutl_Indexx_INTI(nsec, types, ASCENDING) ;

    for (i = 0 ; i < nsec ; i++)
    {
        ix  = tmpix[i] ;
        tmp = Boot_Genrmaturity(&settle[ix], &secs[ix], holi) ;
        maturs[i] = (FL64) Cldr_Datestr2YMD(&tmp) ;
    }

    tmpix1 = Scutl_Indexx_FL64(nsec, maturs, ASCENDING) ;

    for (i = 0 ; i < nsec ; i++)
        index[i] = tmpix[tmpix1[i]] ;

    Free_INTIARRAY(types) ;
    Free_INTIARRAY(tmpix) ;
    Free_INTIARRAY(tmpix1) ;
    Free_FL64ARRAY(maturs) ;

    return index ;
}


/************************************************************************
*
*               Boot_Genrmaturity()
*
*   interface   #include <bootsec.h>
*               DATESTR Boot_Genrmaturity(DATESTR   *today,
*                                         BSECARRAY secs,
*                                         HOLI_STR  *holi) ;
*
*   general     The function generates the maturity of a money market
*               security used for bootstrapping.
*
*   input       DATESTR   *today   The start date for the security
*
*               BSECARRAY secs     The list of securities to use for
*                                  bootstrapping (nsec securities).
*
*               HOLI_STR  *holi    Container for data on business
*                                  day convention and non-week-end
*                                  holidays.
*                                  The bus entry is not used.
*
*   output
*
*   returns     The maturity as DATESTR
*
*   diagnostics
*
*   see also    Boot_GenrIndex()
*
************************************************************************/


DATESTR Boot_Genrmaturity(DATESTR* today,
                          BSECARRAY secs,
                          HOLI_STR*  holi)
{
    DATESTR  start, day1, matur ;
    BUSCONV  bus ;
    PERIOD   per ;

    bus = holi->bus ;
    holi->bus = secs->bus ;
    day1 = Cldr_NextBusinessDate(today, holi) ;

    if (secs->type == MM || secs->type == SWAP)
        matur = Cldr_TermUnit2Date(&day1, secs->term1, secs->unit,
                                   secs->cal, secs->eom, holi) ;

    else if (secs->type == IRF || secs->type == AVGIRF ||
             secs->type == BONDREPO)
        matur = secs->maturity ;

    else if (secs->type == SWAPGENR)
        matur = secs->sfix.pday.last ;

    else if (secs->type == BOND)
        matur = secs->fixp.cday.last ;

    else if (secs->type == BONDSMPL)
        matur = secs->maturity ;

    else if (secs->type == FRA)
    {
        if (secs->nest == True)
        {
            start = Cldr_TermUnit2Date(&day1, secs->term1, secs->unit,
                                       secs->cal, secs->eom, holi) ;
            start = Cldr_NextBusinessDate(&start, holi) ;
            matur = Cldr_TermUnit2Date(&start,
                                       secs->term2 - secs->term1,
                                       secs->unit, secs->cal,
                                       secs->eom, holi) ;
        }
        else
            matur = Cldr_TermUnit2Date(&day1, secs->term2, secs->unit,
                                       secs->cal, secs->eom, holi) ;
    }
    else if (secs->type == IMMFRA)
    {                       
        start = Cldr_IMMInMonth(&secs->start) ;
 
        per   = Set_PERIOD(secs->term1, secs->unit) ;
        matur = Cldr_NextROLL(&start, IMM, &per, secs->cal, secs->eom, holi) ;
    }
    else if (secs->type == SWAPFUT)
        matur = Cldr_TermUnit2Date(&secs->maturity, secs->term1, secs->unit,
                                   secs->cal, secs->eom, holi) ;

    matur = Cldr_NextBusinessDate(&matur, holi) ;
    holi->bus = bus ;

    return matur ;
}




/*
..
*/

/*,,SOH,,
************************************************************************
*
*                Set_BSEC_MM()
*
*   interface    #include <bootsec.h>
*                BSEC Set_BSEC_MM(IRRCONV  irr,
*                                 CALCONV  cal,
*                                 CALCONV  cal_ipol,
*                                 EOMCONV  eom,
*                                 BUSCONV  bus,
*                                 INTI     term1,
*                                 TERMUNIT unit) ;
*
*   general      This routine sets the members of the struct defined
*                in the function name. The pointer members are simply
*                assigned - without physical copying. The intention
*                of the Set_*() routines is that by using this
*                functionality, one avoids setting individual members
*                of structs in the application code.
*
*                When new members are inserted in structs the Set_*()
*                routine will be changed accordingly.
*
*                One exception to this principle applies. Whenever
*                OPTADD and vanilla members are used, only the
*                vanilla members are set in the Set_*() routines. The
*                non-vanilla and exotic members are set to defaults,
*                and must be set elsewhere - if needed.
*
*                For details on the interpretation of the individual
*                struct members please check the struct definition.
*
*   input        IRRCONV  irr      See general section.
*
*                CALCONV  cal      See general section.
*
*                CALCONV  cal_ipol See general section.
*
*                EOMCONV  eom      See general section.
*
*                BUSCONV  bus      See general section.
*
*                INTI     term1    See general section.
*
*                TERMUNIT unit     See general section.
*
*   output
*
*   returns      The filled out BSEC struct
*
*   diagnostics
*
*   see also     BSEC
*
************************************************************************
,,EOH,,*/

BSEC Set_BSEC_MM(IRRCONV    irr,
                    CALCONV    cal,
                    CALCONV    cal_ipol,
                    EOMCONV    eom,
                    BUSCONV    bus,
                    INTI       term1,
                    TERMUNIT   unit)
{
    BSEC b ;

    b.type = MM ;
    b.vanilla = True ;
    b.irr  = irr ;
    b.cal  = cal ;
    b.cal_ipol = cal_ipol ;
    b.eom  = eom ;
    b.bus  = bus ;
    b.term1 = term1 ;
    b.unit = unit ;
    return b ;
}


/*
..
*/

/*,,SOH,,
************************************************************************
*
*                Set_BSEC_FRA()
*
*   interface    #include <bootsec.h>
*                BSEC Set_BSEC_FRA(CALCONV  cal,
*                                  CALCONV  cal_ipol,
*                                  EOMCONV  eom,
*                                  BUSCONV  bus,
*                                  INTI     term1,
*                                  INTI     term2,
*                                  TERMUNIT unit,
*                                  BOOLE    nest) ;
*
*   general      This routine sets the members of the struct defined
*                in the function name. The pointer members are simply
*                assigned - without physical copying. The intention
*                of the Set_*() routines is that by using this
*                functionality, one avoids setting individual members
*                of structs in the application code.
*
*                When new members are inserted in structs the Set_*()
*                routine will be changed accordingly.
*
*                One exception to this principle applies. Whenever
*                OPTADD and vanilla members are used, only the
*                vanilla members are set in the Set_*() routines. The
*                non-vanilla and exotic members are set to defaults,
*                and must be set elsewhere - if needed.
*
*                For details on the interpretation of the individual
*                struct members please check the struct definition.
*
*   input        CALCONV  cal      See general section.
*
*                CALCONV  cal_ipol See general section.
*
*                EOMCONV  eom      See general section.
*
*                BUSCONV  bus      See general section.
*
*                INTI     term1    See general section.
*
*                INTI     term2    See general section.
*
*                TERMUNIT unit     See general section.
*
*                BOOLE    nest     See general section.
*
*   output
*
*   returns      The filled out BSEC struct
*
*   diagnostics
*
*   see also     BSEC
*
************************************************************************
,,EOH,,*/

BSEC Set_BSEC_FRA(CALCONV    cal,
                     CALCONV    cal_ipol,
                     EOMCONV    eom,
                     BUSCONV    bus,
                     INTI       term1,
                     INTI       term2,
                     TERMUNIT   unit,
                     BOOLE      nest)
{
    BSEC b ;

    b.type = FRA ;
    b.vanilla = True ;
    b.cal  = cal ;
    b.cal_ipol = cal_ipol ;
    b.eom  = eom ;
    b.bus  = bus ;
    b.term1 = term1 ;
    b.term2 = term2 ;
    b.unit = unit ;
    b.nest = nest ;

    return b ;
}


/*
..
*/

/*,,SOH,,
************************************************************************
*
*                Set_BSEC_IMMFRA()
*
*   interface    #include <bootsec.h>
*                BSEC Set_BSEC_IMMFRA(CALCONV  cal,
*                                  CALCONV  cal_ipol,
*                                  EOMCONV  eom,
*                                  BUSCONV  bus,
*                                  DATESTR* start,
*                                  INTI     term1,
*                                  TERMUNIT unit) ;
*
*   general      This routine sets the members of the struct defined
*                in the function name. The pointer members are simply
*                assigned - without physical copying. The intention
*                of the Set_*() routines is that by using this
*                functionality, one avoids setting individual members
*                of structs in the application code.
*
*                When new members are inserted in structs the Set_*()
*                routine will be changed accordingly.
*
*                One exception to this principle applies. Whenever
*                OPTADD and vanilla members are used, only the
*                vanilla members are set in the Set_*() routines. The
*                non-vanilla and exotic members are set to defaults,
*                and must be set elsewhere - if needed.
*
*                For details on the interpretation of the individual
*                struct members please check the struct definition.
*
*   input        CALCONV  cal      See general section.
*
*                CALCONV  cal_ipol See general section.
*
*                EOMCONV  eom      See general section.
*
*                BUSCONV  bus      See general section.
*
*                DATESTR* start    See general section.
*
*                INTI     term1    See general section.
*
*                TERMUNIT unit     See general section.
*
*   output
*
*   returns      The filled out BSEC struct
*
*   diagnostics
*
*   see also     BSEC
*
************************************************************************
,,EOH,,*/

BSEC Set_BSEC_IMMFRA(CALCONV    cal,
                     CALCONV    cal_ipol,
                     EOMCONV    eom,
                     BUSCONV    bus,
                     DATESTR*   start,
                     INTI       term1,
                     TERMUNIT   unit)
{
    BSEC b ;

    b.type = IMMFRA ;
    b.vanilla = True ;
    b.cal  = cal ;
    b.cal_ipol = cal_ipol ;
    b.eom  = eom ;
    b.bus  = bus ;
    b.start = *start ;
    b.term1 = term1 ;
    b.unit = unit ;

    return b ;
}


/*
..
*/

/*,,SOH,,
************************************************************************
*
*                Set_BSEC_IRF()
*
*   interface    #include <bootsec.h>
*                BSEC Set_BSEC_IRF(CALCONV  cal,
*                                  CALCONV  cal_ipol,
*                                  EOMCONV  eom,
*                                  BUSCONV  bus,
*                                  DATESTR* start,
*                                  DATESTR* maturity) ;
*
*   general      This routine sets the members of the struct defined
*                in the function name. The pointer members are simply
*                assigned - without physical copying. The intention
*                of the Set_*() routines is that by using this
*                functionality, one avoids setting individual members
*                of structs in the application code.
*
*                When new members are inserted in structs the Set_*()
*                routine will be changed accordingly.
*
*                One exception to this principle applies. Whenever
*                OPTADD and vanilla members are used, only the
*                vanilla members are set in the Set_*() routines. The
*                non-vanilla and exotic members are set to defaults,
*                and must be set elsewhere - if needed.
*
*                For details on the interpretation of the individual
*                struct members please check the struct definition.
*
*   input        CALCONV  cal      See general section.
*
*                CALCONV  cal_ipol See general section.
*
*                EOMCONV  eom      See general section.
*
*                BUSCONV  bus      See general section.
*
*                DATESTR* start    See general section.
*
*                DATESTR* maturity See general section.
*
*   output
*
*   returns      The filled out BSEC struct
*
*   diagnostics
*
*   see also     BSEC
*
************************************************************************
,,EOH,,*/

BSEC Set_BSEC_IRF(CALCONV    cal,
                     CALCONV    cal_ipol,
                     EOMCONV    eom,
                     BUSCONV    bus,
                     DATESTR*   start,
                     DATESTR*   maturity)
{
    BSEC b ;

    b.type = IRF ;
    b.vanilla = True ;    
    b.cal  = cal ;
    b.cal_ipol = cal_ipol ;
    b.eom  = eom ;
    b.bus  = bus ;
    b.start = *start ;
    b.maturity = *maturity ;

    return b ;
}


/*
..
*/

/*,,SOH,,
************************************************************************
*
*                Set_BSEC_SWAP()
*
*   interface    #include <bootsec.h>
*                BSEC Set_BSEC_SWAP(CALCONV  cal,
*                                   CALCONV  cal_ipol,
*                                   EOMCONV  eom,
*                                   BUSCONV  bus,
*                                   INTI     term1,
*                                   TERMUNIT unit,
*                                   PMTFREQ  freq) ;
*
*   general      This routine sets the members of the struct defined
*                in the function name. The pointer members are simply
*                assigned - without physical copying. The intention
*                of the Set_*() routines is that by using this
*                functionality, one avoids setting individual members
*                of structs in the application code.
*
*                When new members are inserted in structs the Set_*()
*                routine will be changed accordingly.
*
*                One exception to this principle applies. Whenever
*                OPTADD and vanilla members are used, only the
*                vanilla members are set in the Set_*() routines. The
*                non-vanilla and exotic members are set to defaults,
*                and must be set elsewhere - if needed.
*
*                For details on the interpretation of the individual
*                struct members please check the struct definition.
*
*   input        CALCONV  cal      See general section.
*
*                CALCONV  cal_ipol See general section.
*
*                EOMCONV  eom      See general section.
*
*                BUSCONV  bus      See general section.
*
*                INTI     term1    See general section.
*
*                TERMUNIT unit     See general section.
*
*                PMTFREQ  freq     See general section.
*
*   output
*
*   returns      The filled out BSEC struct
*
*   diagnostics
*
*   see also     BSEC
*
************************************************************************
,,EOH,,*/

BSEC Set_BSEC_SWAP(CALCONV    cal,
                      CALCONV    cal_ipol,
                      EOMCONV    eom,
                      BUSCONV    bus,
                      INTI       term1,
                      TERMUNIT   unit,
                      PMTFREQ    freq)
{
    BSEC b ;

    b.type = SWAP ;
    b.vanilla = True ;
    b.cal  = cal ;
    b.cal_ipol = cal_ipol ;
    b.eom  = eom ;
    b.bus  = bus ;
    b.term1 = term1 ;
    b.unit = unit ;
    b.freq = freq ;

    return b ;
}


/*
..
*/

/*,,SOH,,
************************************************************************
*
*                Set_BSEC_AVGIRF()
*
*   interface    #include <bootsec.h>
*                BSEC Set_BSEC_AVGIRF(CALCONV  cal,
*                                     CALCONV  cal_ipol,
*                                     EOMCONV  eom,
*                                     BUSCONV  bus,
*                                     INTI     term1,
*                                     TERMUNIT unit,
*                                     DATESTR* start,
*                                     DATESTR* maturity,
*                                     FL64     curr_avg) ;
*
*   general      This routine sets the members of the struct defined
*                in the function name. The pointer members are simply
*                assigned - without physical copying. The intention
*                of the Set_*() routines is that by using this
*                functionality, one avoids setting individual members
*                of structs in the application code.
*
*                When new members are inserted in structs the Set_*()
*                routine will be changed accordingly.
*
*                One exception to this principle applies. Whenever
*                OPTADD and vanilla members are used, only the
*                vanilla members are set in the Set_*() routines. The
*                non-vanilla and exotic members are set to defaults,
*                and must be set elsewhere - if needed.
*
*                For details on the interpretation of the individual
*                struct members please check the struct definition.
*
*   input        CALCONV  cal      See general section.
*
*                CALCONV  cal_ipol See general section.
*
*                EOMCONV  eom      See general section.
*
*                BUSCONV  bus      See general section.
*
*                INTI     term1    See general section.
*
*                TERMUNIT unit     See general section.
*
*                DATESTR* start    See general section.
*
*                DATESTR* maturity See general section.
*
*                FL64     curr_avg See general section.
*
*   output
*
*   returns      The filled out BSEC struct
*
*   diagnostics
*
*   see also     BSEC
*
************************************************************************
,,EOH,,*/

BSEC Set_BSEC_AVGIRF(CALCONV    cal,
                     CALCONV    cal_ipol,
                     EOMCONV    eom,
                     BUSCONV    bus,
                     INTI       term1,
                     TERMUNIT   unit,
                     DATESTR*   start,
                     DATESTR*   maturity,
                     FL64        curr_avg)
{
    BSEC b ;

    b.type = AVGIRF ;
    b.vanilla = True ;
    b.cal  = cal ;
    b.cal_ipol = cal_ipol ;
    b.eom  = eom ;
    b.bus  = bus ;
    b.term1 = term1 ;
    b.unit  = unit ;
    b.start = *start ;
    b.maturity = *maturity ;
    b.curr_avg = curr_avg ;

    return b ;
}


/*
..
*/

/*,,SOH,,
************************************************************************
*
*                Set_BSEC_BOND()
*
*   interface    #include <bootsec.h>
*                BSEC Set_BSEC_BOND(CALCONV cal_ipol,
*                                   BUSCONV bus,
*                                   FIXPAY* fixp) ;
*
*   general      This routine sets the members of the struct defined
*                in the function name. The pointer members are simply
*                assigned - without physical copying. The intention
*                of the Set_*() routines is that by using this
*                functionality, one avoids setting individual members
*                of structs in the application code.
*
*                When new members are inserted in structs the Set_*()
*                routine will be changed accordingly.
*
*                One exception to this principle applies. Whenever
*                OPTADD and vanilla members are used, only the
*                vanilla members are set in the Set_*() routines. The
*                non-vanilla and exotic members are set to defaults,
*                and must be set elsewhere - if needed.
*
*                For details on the interpretation of the individual
*                struct members please check the struct definition.
*
*   input        CALCONV cal_ipol See general section.
*
*                BUSCONV bus      See general section.
*
*                FIXPAY* fixp     See general section.
*
*   output
*
*   returns      The filled out BSEC struct
*
*   diagnostics
*
*   see also     BSEC
*
************************************************************************
,,EOH,,*/

BSEC Set_BSEC_BOND(CALCONV    cal_ipol,
                      BUSCONV    bus,
                      FIXPAY*    fixp)
{
    BSEC b ;

    b.type = BOND ;
    b.cal_ipol = cal_ipol ;
    b.bus  = bus ;
    b.vanilla = False ;
    b.fixp = *fixp ;

    return b ;
}


/*
..
*/

/*,,SOH,,
************************************************************************
*
*                Set_BSEC_BONDSMPL()
*
*   interface    #include <bootsec.h>
*                BSEC Set_BSEC_BONDSMPL(CALCONV  cal,
*                                       CALCONV  cal_ipol,
*                                       EOMCONV  eom,
*                                       BUSCONV  bus,
*                                       PMTFREQ  freq,
*                                       DATESTR* start,
*                                       DATESTR* maturity,
*                                       FL64     coupon,
*                                       INTI     excdays) ;
*
*   general      This routine sets the members of the struct defined
*                in the function name. The pointer members are simply
*                assigned - without physical copying. The intention
*                of the Set_*() routines is that by using this
*                functionality, one avoids setting individual members
*                of structs in the application code.
*
*                When new members are inserted in structs the Set_*()
*                routine will be changed accordingly.
*
*                One exception to this principle applies. Whenever
*                OPTADD and vanilla members are used, only the
*                vanilla members are set in the Set_*() routines. The
*                non-vanilla and exotic members are set to defaults,
*                and must be set elsewhere - if needed.
*
*                For details on the interpretation of the individual
*                struct members please check the struct definition.
*
*   input        CALCONV  cal      See general section.
*
*                CALCONV  cal_ipol See general section.
*
*                EOMCONV  eom      See general section.
*
*                BUSCONV  bus      See general section.
*
*                PMTFREQ  freq     See general section.
*
*                DATESTR* start    See general section.
*
*                DATESTR* maturity See general section.
*
*                FL64     coupon   See general section.
*
*                INTI     excdays  See general section.
*
*   output
*
*   returns      The filled out BSEC struct
*
*   diagnostics
*
*   see also     BSEC
*
************************************************************************
,,EOH,,*/

BSEC Set_BSEC_BONDSMPL(CALCONV    cal,
                     CALCONV    cal_ipol,
                     EOMCONV    eom,
                     BUSCONV    bus,
                     PMTFREQ       freq,
                     DATESTR*   start,
                     DATESTR*   maturity,
                     FL64        coupon,
                     INTI        excdays)
{
    BSEC b ;

    b.type = BONDSMPL ;
    b.vanilla = True ;
    b.cal  = cal ;
    b.cal_ipol = cal_ipol ;
    b.eom  = eom ;
    b.bus  = bus ;
    b.freq = freq ;
    b.start = *start ;
    b.maturity = *maturity ;
    b.coupon   = coupon ;
    b.excdays  = excdays ;

    return b ;
}


/*
..
*/

/*,,SOH,,
************************************************************************
*
*                Set_BSEC_BONDREPO()
*
*   interface    #include <bootsec.h>
*                BSEC Set_BSEC_BONDREPO(CALCONV  cal_ipol,
*                                       BUSCONV  bus,
*                                       EOMCONV  eom,
*                                       DATESTR* maturity,
*                                       FIXPAY*  fixp) ;
*
*   general      This routine sets the members of the struct defined
*                in the function name. The pointer members are simply
*                assigned - without physical copying. The intention
*                of the Set_*() routines is that by using this
*                functionality, one avoids setting individual members
*                of structs in the application code.
*
*                When new members are inserted in structs the Set_*()
*                routine will be changed accordingly.
*
*                One exception to this principle applies. Whenever
*                OPTADD and vanilla members are used, only the
*                vanilla members are set in the Set_*() routines. The
*                non-vanilla and exotic members are set to defaults,
*                and must be set elsewhere - if needed.
*
*                For details on the interpretation of the individual
*                struct members please check the struct definition.
*
*   input        CALCONV  cal_ipol See general section.
*
*                BUSCONV  bus      See general section.
*
*                EOMCONV  eom      See general section.
*
*                DATESTR* maturity See general section.
*
*                FIXPAY*  fixp     See general section.
*
*   output
*
*   returns      The filled out BSEC struct
*
*   diagnostics
*
*   see also     BSEC
*
************************************************************************
,,EOH,,*/

BSEC Set_BSEC_BONDREPO(CALCONV    cal_ipol,
                          BUSCONV    bus,
                          EOMCONV    eom,
                          DATESTR*   maturity,
                          FIXPAY*     fixp)
{
    BSEC b ;

    b.type = BONDREPO ;
    b.vanilla = False ;
    b.cal_ipol = cal_ipol ;
    b.bus  = bus ;
    b.eom = eom ;
    b.maturity = *maturity ;
    b.fixp = *fixp ;

    return b ;
}


/*
..
*/

/*,,SOH,,
************************************************************************
*
*                Set_BSEC_SWAPGENR()
*
*   interface    #include <bootsec.h>
*                BSEC Set_BSEC_SWAPGENR(CALCONV  cal_ipol,
*                                       BUSCONV  bus,
*                                       SWAPFIX* sfix) ;
*
*   general      This routine sets the members of the struct defined
*                in the function name. The pointer members are simply
*                assigned - without physical copying. The intention
*                of the Set_*() routines is that by using this
*                functionality, one avoids setting individual members
*                of structs in the application code.
*
*                When new members are inserted in structs the Set_*()
*                routine will be changed accordingly.
*
*                One exception to this principle applies. Whenever
*                OPTADD and vanilla members are used, only the
*                vanilla members are set in the Set_*() routines. The
*                non-vanilla and exotic members are set to defaults,
*                and must be set elsewhere - if needed.
*
*                For details on the interpretation of the individual
*                struct members please check the struct definition.
*
*   input        CALCONV  cal_ipol See general section.
*
*                BUSCONV  bus      See general section.
*
*                SWAPFIX* sfix     See general section.
*
*   output
*
*   returns      The filled out BSEC struct
*
*   diagnostics
*
*   see also     BSEC
*
************************************************************************
,,EOH,,*/

BSEC Set_BSEC_SWAPGENR(CALCONV    cal_ipol,
                          BUSCONV    bus,
                          SWAPFIX*   sfix)
{
    BSEC b ;

    b.type = SWAPGENR ;
    b.vanilla = False ;
    b.cal_ipol = cal_ipol ;
    b.bus  = bus ;
    b.sfix = *sfix ;

    return b ;
}

/*,,SOH,,
************************************************************************
*
*                Set_BSEC_SWAPFUT()
*
*   interface    #include <bootsec.h>
*                BSEC Set_BSEC_SWAPFUT(CALCONV   cal,
*                                      CALCONV   cal_ipol,
*                                      EOMCONV   eom,
*                                      BUSCONV   bus,
*                                      INTI      term1,
*                                      TERMUNIT  unit,
*                                      PMTFREQ   freq,
*                                      DATESTR*  maturity,
*                                      FL64      coupon);
*
*   general      This routine sets the members of the struct defined
*                in the function name. The pointer members are simply
*                assigned - without physical copying. The intention
*                of the Set_*() routines is that by using this
*                functionality, one avoids setting individual members
*                of structs in the application code.
*
*                When new members are inserted in structs the Set_*()
*                routine will be changed accordingly.
*
*                One exception to this principle applies. Whenever
*                OPTADD and vanilla members are used, only the
*                vanilla members are set in the Set_*() routines. The
*                non-vanilla and exotic members are set to defaults,
*                and must be set elsewhere - if needed.
*
*                For details on the interpretation of the individual
*                struct members please check the struct definition.
*
*   input        CALCONV  cal      See general section.
*
*                CALCONV  cal_ipol See general section.
*
*                EOMCONV  eom      See general section.
*
*                BUSCONV  bus      See general section.
*
*                INTI     term1    See general section.
*
*                TERMUNIT unit     See general section.
*
*                PMTFREQ  freq     See general section.
*
*                DATESTR* maturity See general section.
*
*                FL64     coupon   See general section.
*
*   output
*
*   returns      The filled out BSEC struct
*
*   diagnostics
*
*   see also     BSEC
*
************************************************************************
,,EOH,,*/

BSEC Set_BSEC_SWAPFUT (CALCONV   cal,
                       CALCONV   cal_ipol,
                       EOMCONV   eom,
                       BUSCONV   bus,
                       INTI      term1,
                       TERMUNIT  unit,
                       PMTFREQ   freq,
                       DATESTR*  maturity,
                       FL64      coupon)
{
    BSEC b;

    b.type = SWAPFUT;
    b.vanilla = True ;
    b.cal  = cal;
    b.cal_ipol = cal_ipol;
    b.eom  = eom;
    b.bus  = bus;
    b.term1 = term1;
    b.unit = unit;
    b.freq = freq;
    b.maturity = *maturity;
    b.coupon = coupon;

    return b;
}


/*,,SOH,,
*************************************************************************
*
*               Alloc_BSECARRAY()
*
*    interface  #include <bootsec.h>
*               BSECARRAY Alloc_BSECARRAY(INTI n);
*
*    general    Alloc_BSECARRAY() allocates memory for an
*               [0...(n-1)] array of BSEC_STR's.
*               Returns memory with zero'ed entries
*
*    input      INTI    n       The number of entries in BSEC_STR list
*
*    output
*
*    returns    reference to the vector of type BSEC_STR
*
*    diagnostics aborts calling SCecon_error()
*                with the message   "Memory allocation error"
*                         routine   "Alloc_BSECARRAY()"
*                         actioncode SCECONABORT
*                if allocation fails
*
*    see also   Free_BSECARRAY()
*
*************************************************************************
,,EOH,,*/


BSECARRAY Alloc_BSECARRAY(INTI n)
{
    BSECARRAY a;

    a = (BSECARRAY) SCecon_calloc(n, sizeof(BSEC), True,
      "Alloc_BSECARRAY()") ;

    return a ;
}


/*,,SOH,,
*************************************************************************
*
*               Free_BSECARRAY()
*
*    interface  #include <bootsec.h>
*               void Free_BSECARRAY(BSECARRAY date) ;
*
*    general    Free_BSECARRAY() frees memory for an array
*               of BSEC_STR's allocated by Alloc_BSECARRAY()
*
*    input      BSECARRAY date          Reference to the array
*
*    output
*
*    returns
*
*    diagnostics
*
*    see also   Alloc_BSECARRAY()
*
*************************************************************************
,,EOH,,*/


void Free_BSECARRAY(BSECARRAY date)
{
    SCecon_free((VOIDPTR) date) ;
}



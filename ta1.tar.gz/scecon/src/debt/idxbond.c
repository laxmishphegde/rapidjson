/* @(#)idxbond.c	1.12 (SimCorp) 99/11/02 14:53:09 */

/************************************************************************
*
*       Project         SCecon
*
*       file name       dvlp.c
*
************************************************************************/

#include <idxbond.h>

/*** defines  **********************************************************/
#define IDXTOL     (FL64)   0.0000000000001


/*,,SOH,,
************************************************************************
*
*              IndexLoan_GenrCflw()
*
*  interface   #include <idxbond.h>
*              CFLWARRAY IndexLoan_GenrCflw(DATESTR *analys,
*                                        INDEXLOAN *idxloan,
*                                        INDEXFAC *debfac,
*                                        INDEXFAC *crefac,
*                                        HOLI_STR *holi) ;
*
*  general     This function generates cash flow for index loans from
*              analys date till idxloan->last.
*              Covered bond types are various danish indexed loans of
*              type AI, I, SI and IS.
*              The cashflows are for idealised bonds
*              financing one indexed loan. Since indexed bonds are tap
*              issued actual cashflows will differ
*              from these idealised cashflows. To work with actual
*              cashflows use IndexBond_GenrCflw.
*              with an irregular amortisation corresponding to the
*              cashflow published by the bond issuer.
*
*
*  input       DATESTR   *analys  The analysis date
*
*              INDEXLOAN *idxloan The indexloan definition
*
*              INDEXFAC  *debfac  Debtor index factors
*                                 Use NULL for 0% inflation
*
*              INDEXFAC  *crefac  Creditor index factors
*                                 Use NULL for 0% inflation
*
*              HOLI_STR  *holi    Container for data on business
*                                 day convention and non-week-end
*                                 holidays
*
*  output
*
*  returns     Pointer to cashflow generated. Allocated in this routine*
*              as Alloc_CFLWARRAY(1, x), where x is calculated.
*              Note that the cashflow is not scaled to 100 notional as is
*              customary in other parts of the library.
*
*  diagnostics
*
*  see also
*
*  wrapper     AP
*
************************************************************************
,,EOH,,*/


CFLWARRAY IndexLoan_GenrCflw(DATESTR*    analys,
                                INDEXLOAN*  idxloan,
                                INDEXFAC*   debfac,
                                INDEXFAC*   crefac,
                                HOLI_STR*   holi)
{
    INDEXBOND idxbond ;
    CFLWARRAY cflw ;
    TRADEINFO basis ;



    *debfac = Index_PrepIndex(debfac) ;
    *crefac = Index_PrepIndex(crefac) ;

    /* For SI bonds we use a special SI cflw generator
       For other types of bonds we use the fact that, unindexed
       the cashflows are just very simple bullet/serial or Annuity bonds
       So we generate an INDEXBOND and use this cashflow generator
       This would also work for SI_CREDITOR INDEXLOANTYPE, but for
       backwards compatibility we let the SI generator do the generation*/

    if (idxloan->iltype == IS_CREDITOR)
        return ISLoan_GenrCflw(analys, idxloan, debfac, crefac, holi, True ) ;
    if (idxloan->iltype == IS_DEBITOR)
        return ISLoan_GenrCflw(analys, idxloan, debfac, crefac, holi, False ) ;

    IndexLoan_GenrIndexBond(idxloan, analys, &idxbond, &basis) ;

    /* Generate the cashflow */
    cflw = IndexBond_GenrCflw(&basis, &idxbond, crefac, holi) ;

    /* Free */

    Free_INDEXBOND( &idxbond) ;

    return cflw ;
}


/*,,SIC,,
*************************************************************************
*
*               ISLoan_GenrCflw()
*
*   interface   #include <idxbond.h>
*               CFLWARRAY ISLoan_GenrCflw(DATESTR   *analys,
*                                             INDEXLOAN *idxloan,
*                                             INDEXFAC  *debfac,
*                                             INDEXFAC  *crefac,
*                                             HOLI_STR  *holi,
*                                             BOOLE     usecred) ;
*
*   general     This function generates cash flow for index loans from
*               analys date till idxloan->last.
*
*   input       DATESTR   *analys       The analysis date
*
*               INDEXLOAN *idxloan      The indexloan definition
*
*               INDEXFAC  *debfac       Debtor index factors
*                                       Use NULL for 0% inflation
*
*               INDEXFAC  *crefac       Creditor index factors
*                                       Use NULL for 0% inflation
*
*               HOLI_STR  *holi         Container for data on business
*                                       day convention and non-week-end
*                                       holidays
*
*               BOOLE     usecred       If true creditor cashflow is generated
*                                       If false debitor cashflow
*
*
*   output
*
*   returns     Pointer to cashflow generated. Allocated in this routine*
*               as Alloc_CFLWARRAY(1, x), where x is calculated.
*
*   diagnostics
*
*   see also
*
*   wrapper     AP
*
*************************************************************************
,,EIC,,*/

CFLWARRAY ISLoan_GenrCflw(DATESTR*    analys,
                                INDEXLOAN*  idxloan,
                                INDEXFAC*   debfac,
                                INDEXFAC*   crefac,
                                HOLI_STR*   holi,
                                BOOLE       usecred)
{
    AIRESULT    ai ;
    CFLWARRAY   ccflw, dcflw ;
    DATEARRAY   days, paydays ;
    FL64 rpct, coupon, dprinc_debidx, coutstand, doutstand, kurs,
     idxfac, idxfac1, idxfac2, deb_idx1, deb_idx2, deb_idx, cre_idx1,
     cre_idx2, cre_idx , redem, normalterm, thisterm ;

    FL64ARRAY   ccoupon, dcoupon, crepay, drepay;
    INTI        i, j, npay, nday ;
    PAYDAYDEF   pday ;
    DATESTR     prev, next, first_amort, last, dummy ;
    INTI        ms, qbas ;
    BOOLE       fshort ;
    PERIOD delay, per ;


    /* Initialise */
    dummy = Cldr_YMD2Datestr(0) ;

    *debfac = Index_PrepIndex(debfac) ;
    *crefac = Index_PrepIndex(crefac) ;


    /* Generate paydays */
    pday    = INDEXLOAN_Set_PAYDAYDEF(idxloan) ;
    paydays = Cflw_Paydays(&pday, holi, &npay) ;
                    
    j       = Cldr_FindDateIndex(paydays, npay, analys, 0, 
                                  SEARCH_BISECTION, NEXTINDEX) ;
                                                    
    nday = npay - j + 1 ;
    days = Alloc_DATEARRAY(nday) ;
    for (i = 1 ; i < nday; i++)
        days[i] = paydays[i + j - 1];
    days[0] = *analys ; 

    /* Allocate memory */
    nday  = GETMAX(1, nday) ;
    dcflw = Alloc_CFLWARRAY(1, nday) ;
    ccflw = Alloc_CFLWARRAY(1, nday) ;
                                         
    drepay  = dcflw->repay ;
    dcoupon = dcflw->coupon ;
    crepay  = ccflw->repay ;
    ccoupon = ccflw->coupon ;
       
    /* First coupon short ? */
    ms = Cflw_MonthsBetweenPayments(idxloan->freq) ;
    prev = Cldr_AddMonths(&idxloan->first_coupon, -ms, SAME) ;
    fshort = Cldr_DateLT(&prev, &idxloan->effective) ;

    
    if (Cldr_DateLT(&idxloan->effective, analys))
        prev = (j > 0 ? paydays[j - 1] : dummy) ;
    else
        prev =  idxloan->effective ;

      /* Initialise */

    dcoupon[0] = drepay[0] = ccoupon[0] = crepay[0] = 0.0 ;
    i = 1 ;
    rpct = idxloan->rpct ;
    qbas = disc_set_qbas(idxloan->freq) ; 
    coupon = idxloan->coupon ; 
    first_amort = idxloan->first_amort ;
    last = idxloan->last ;
    delay = Set_PERIOD(idxloan->delay.num, idxloan->delay.unit) ;

    /* Initial creditor and debtor principal - must be 
       index-factor adjusted */
    dprinc_debidx = idxloan->dprinc ;

    if (idxloan->round) dprinc_debidx = Math_Round(dprinc_debidx, 2) ;

    /* Initial creditor and debtor principal/outstanding - must be 
       index-factor adjusted */
    coutstand = idxloan->coutstand ;
    doutstand = idxloan->doutstand ;

    if (idxloan->round) coutstand = Math_Round(coutstand, 2) ;
    if (idxloan->round) doutstand = Math_Round(doutstand, 2) ;

    kurs = SafeDivide(doutstand, coutstand, IDXTOL, 1.0) ;
    /* NOTE kurs is always positive */
    if (idxloan->round) kurs = Math_Round(kurs, 4) ;

    next = prev ;

    /* Generate repayments and coupons */
    while (coutstand > 0.0 && i < nday)
    {
        prev = next ;
        next = days[i] ;
      
        /* Creditor coupon */
      
        /* Cope with coupon in first short period */
        if (fshort == True && i == 1)
        {

            per = Set_PERIOD(0, DAYS) ;
            thisterm = Cldr_TermBetweenDates(&prev, &next, 0,
                                         idxloan->cal, SAME, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
            dummy = Cldr_AddMonths(&prev, ms, SAME) ;
            normalterm = Cldr_TermBetweenDates(&prev, &dummy, 0,
                                           idxloan->cal, SAME, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */


            idxfac1 = Index_Interpolation(&idxloan->effective, &per, crefac) ;
            idxfac2 = Index_Interpolation(&idxloan->first_coupon, &delay, 
                                          crefac) ;
            idxfac = idxfac1 / idxfac2 ;

            ccoupon[i]  = coutstand ; 
            ccoupon[i] -= coutstand * idxfac * 
                         (normalterm - thisterm) / (normalterm);
            ccoupon[i] *= (coupon) / (100.0 * (FL64) qbas);
        }
        else /*even coupons*/
            ccoupon[i] = coutstand * coupon  / (100.0 * (FL64) qbas) ;


        /* Creditor and debtor repayment */
        /* used to be && nday>0 but i=1 at entry so this logic is not
           necessary*/
        if (Cldr_DateLT(&next, &first_amort) == True)
        {
            /* Postponed Amort */
            crepay[i] = 0.0 ;
            drepay[i] = 0.0 ;
        }
        else if (Cldr_DateEQ(&next, &last) == True)
        {
            /* payday is later than maturity, ie repayment must
               equal outstanding */
            crepay[i] = coutstand ;
            if (idxloan->round) crepay[i] = Math_Round(crepay[i], 2) ;
            drepay[i] = doutstand ;
            if (idxloan->round) drepay[i] = Math_Round(drepay[i], 2) ;
        }
        else if (idxloan->amort > 0.0 &&  
                    Cldr_DateEQ(&next, &first_amort) == True)
        {
            /* An initial amortisation */
            drepay[i] = idxloan->amort ;
            if (idxloan->round) drepay[i] = Math_Round(drepay[i], 2) ;
            crepay[i] = drepay[i] / kurs ; 
            if (idxloan->round) crepay[i] = Math_Round(crepay[i], 2) ;
        }
        else 
        {
            /* 'Normal situation' */
            drepay[i] = rpct / 100.0 * dprinc_debidx ;
            if (idxloan->round) drepay[i] = Math_Round(drepay[i], 2) ;
            crepay[i] = drepay[i] / kurs ; 
            if (idxloan->round) crepay[i] = Math_Round(crepay[i], 2) ;
        }

        /* Repayments cannot be larger than outstanding */
        crepay[i] = GETMIN(crepay[i], coutstand) ;
        drepay[i] = GETMIN(drepay[i], doutstand) ;
      
        if (idxloan->round) ccoupon[i] = Math_Round(ccoupon[i], 2) ;

        /* Total Payment */
        redem = crepay[i] + ccoupon[i] ;

        /* debtor coupon is determined residually */
        dcoupon[i] = redem - drepay[i] ;

        if (idxloan->round) dcoupon[i] = Math_Round(dcoupon[i], 2) ;
  
        /* Look up index factors */
        if (i + 1 < nday)
        {
            deb_idx1 = Index_Interpolation(&days[i + 1], &delay, debfac) ;
            deb_idx2 = Index_Interpolation(&days[i], &delay, debfac) ;
            deb_idx = deb_idx1 / deb_idx2 ;

            cre_idx1 = Index_Interpolation(&days[i + 1], &delay, crefac) ;
            cre_idx2 = Index_Interpolation(&days[i], &delay, crefac) ;
            cre_idx = cre_idx1 / cre_idx2 ;
        }
        else
            deb_idx = cre_idx = 1.0 ;

        /* Update creditor outstanding */
        coutstand -= crepay[i] ;
        coutstand *= cre_idx ;
        if (idxloan->round) coutstand = Math_Round(coutstand, 2) ;

        /* Update debtor principal and outstanding */
        dprinc_debidx = dprinc_debidx * deb_idx ;
        if (idxloan->round) dprinc_debidx = Math_Round(dprinc_debidx, 2) ;

        doutstand -= drepay[i] ;
        doutstand *= cre_idx ;
        if (idxloan->round) doutstand = Math_Round(doutstand, 2) ;
      
        i += 1 ;
    }

    nday = i ;



    /* Accrued interest calculation */
    if (Cldr_DateLE(analys, &idxloan->effective) == False)
    {
        ai = ISLoan_Accruint(analys, idxloan, crefac, True, holi,usecred) ;
        if (usecred == False)
            dcoupon[0] = ai.AI ;
        else
            ccoupon[0] = ai.AI ;

        /* If we are ex coupon the next coupon is not present !*/
        if (ai.exc && nday >1 )
        {
            if (usecred == False)
                dcoupon[1] = 0 ;
            else
                ccoupon[1] = 0 ;
        }
    }

    Free_DATEARRAY(paydays) ;

    /* Return the proper cashflow and free the other one: */
    if (Cldr_DateLT(&idxloan->last, analys) == True)
    {
        dcflw->filled = 0 ;
        Free_DATEARRAY(days) ;        
        Free_CFLWARRAY(ccflw, 1) ;
        
        return dcflw ;
    }
    else
    {    
        if (usecred == False)
        {
            dcflw->filled = nday ;
            /* Return debtor cflw - replace dcflw->day by days */
            Free_DATEARRAY(dcflw->days) ;
            dcflw->days = days ;
            /* .. And free creditor cflw */
            Free_CFLWARRAY(ccflw, 1) ;

            return dcflw ;
        }                            
        else
        {
            ccflw->filled = nday ;
            /* Return creditor cflw - replace ccflw->day by days */
            Free_DATEARRAY(ccflw->days) ;
            ccflw->days = days ;
            /* .. And free debtor cflw. */
            Free_CFLWARRAY(dcflw, 1) ;

            return ccflw ;
        }
    }
}


/*,,SOH,,
*************************************************************************
*
*               IndexLoan_Accruint()
*
*   interface   #include <idxbond.h>
*               AIRESULT IndexLoan_Accruint(DATESTR   *analys,
*                                           INDEXLOAN *idxloan,
*                                           INDEXFAC  *crefac,
*                                           BOOLE     indexadj,
*                                           HOLI_STR  *holi) ;
*
*   general     This function calculates accrued interest for an index
*               loan.
*
*               In order to get meaningful results, an index factor
*               corresponding to a date later than analys must be
*               specified.
*
*   input       DATESTR   *analys       The analysis date
*
*               INDEXLOAN *idxloan      The indexloan definition
*
*               INDEXFAC  *crefac       Creditor index factors
*                                       Use NULL for 0% inflation
*
*               BOOLE     indexadj      False means that the actual
*                                       accrued interest is returned
*                                       True means that accrued interest*
*                                       times the relevant index factor
*                                       is returned
*
*               HOLI_STR  *holi         Container for data on business
*                                       day convention and non-week-end
*                                       holidays
*                
*
*   returns     The accrued interest for a holding of coutstand/doutstand.
*               Choice of which according to usecred.
*               The output is contained in the SCecon standard accrued
*               information in an AIRESULT struct.
*
*   diagnostics
*
*   see also
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/


AIRESULT IndexLoan_Accruint(DATESTR   *analys,
                                      INDEXLOAN *idxloan,
                                      INDEXFAC  *crefac,
                                      BOOLE     indexadj,
                                      HOLI_STR  *holi)
{
    INDEXBOND idxbond ;
    TRADEINFO basis ;
    AIRESULT ai ;


    *crefac = Index_PrepIndex(crefac) ;


    if (idxloan->iltype == IS_CREDITOR)
      return ISLoan_Accruint(analys, idxloan, crefac, indexadj, holi,True) ;
    if (idxloan->iltype == IS_DEBITOR)
      return ISLoan_Accruint(analys, idxloan, crefac, indexadj, holi,False) ;

    IndexLoan_GenrIndexBond(idxloan, analys, &idxbond, &basis) ;

    ai = IndexBond_Accruint(&basis, &idxbond, crefac, indexadj, holi) ;

    /* Free*/

    Free_INDEXBOND(&idxbond) ;

    return ai ;

}



/*,,SIC,,
*************************************************************************
*
*               ISLoan_Accruint()
*
* interface   #include <idxbond.h>
*               AIRESULT ISLoan_Accruint(DATESTR    *analys,
*                                       INDEXLOAN   *idxloan,
*                                       INDEXFAC    *crefac,
*                                       BOOLE       indexadj,
*                                       HOLI_STR    *holi,
*                                       BOOLE       usecred) ;
*
* general     This function calculates accrued interest for an index
*               loan.
*
*               In order to get meaningful results, an index factor
*               corresponding to a date later than analys must be
*               specified.
*
* input       DATESTR   *analys       The analysis date
*
*               INDEXLOAN *idxloan      The indexloan definition
*
*               INDEXFAC  *crefac       Creditor index factors
*                                       crefac->baseidx must be 1.0
*
*               BOOLE     indexadj      False means that the actual
*                                       accrued interest is returned.
*                                       True means that accrued interest*
*                                       times the relevant index factor
*                                       is returned
*
*               HOLI_STR  *holi         Container for data on business
*                                       day convention and non-week-end
*                                       holidays
*                
*               BOOLE      usecred      Specifies whether to compute
*                                       in terms of creditor or debitor
*                                       outstanding
*                                       True means accrued interest on
*                                       creditor side
*
* output      
*
* returns     Various data on the calculation as an AIRESULT struct.
*
* diagnostics
*
* see also
*
* wrapper     AP
*
*************************************************************************
,,EIC,,*/


AIRESULT ISLoan_Accruint(DATESTR    *analys,
                         INDEXLOAN   *idxloan,
                         INDEXFAC    *crefac,
                         BOOLE       indexadj,
                         HOLI_STR    *holi,
                         BOOLE       usecred)
{
    AIRESULT    air ;
    INTI        months, day, j, npay;
    FL64        idxfac, ai, fullterm, termbefore, termafter ;
    DATESTR     prev,next,last ;
    PAYDAYDEF   pday ;
    DATEARRAY   paydays ;
    EXTRADE     ext ;
    BOOLE       isexc ;


    *crefac = Index_PrepIndex(crefac) ;

    /* Analys is later than maturity */
    if (Cldr_DateLT(&idxloan->last, analys) == True)
    {
        air.AI         = 0.0 ;
        air.AIdays     = 0 ;
        air.next       = Cldr_YMD2Datestr(0) ;
        air.exc        = True ;
        air.AI_per_day = 0.0 ;
        
        return air ;
    }

    /* Generate paydays */
    months  = Cflw_MonthsBetweenPayments(idxloan->freq) ;
    pday    = INDEXLOAN_Set_PAYDAYDEF(idxloan) ;
    paydays = Cflw_Paydays(&pday, holi, &npay) ;
    
    /* Find next payday */
    j       = Cldr_FindDateIndex(paydays, npay, analys, 0, 
                                  SEARCH_BISECTION, NEXTINDEX) ;
    next = paydays[j] ;

    /* Calculate */
    prev   = Cldr_AddMonths(&next, -months, SAME) ;
    last = paydays[npay-1] ;
    termbefore    = Cldr_TermBetweenDates(&prev, analys, 0,
                                          idxloan->accru_cal, SAME, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
    termafter = Cldr_TermBetweenDates(analys, &next, 0,
                                      idxloan->accru_cal, SAME, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
    fullterm    = Cldr_TermBetweenDates(&prev, &next, 0,
                                        idxloan->accru_cal, SAME, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
    idxfac = Index_Interpolation(analys, &idxloan->delay, crefac) /
             Index_Interpolation(&prev, &idxloan->delay, crefac) ;

    /*Dont use EXTRADE*/
    ext.spec = ext.ex_fix = False ;

    /* Compute coupon using evencoup-style convention*/
    if (Cldr_DateLT(&prev,analys) && Cldr_DateLT(analys,&next))
    {
        isexc = Cflw_XdayCalc(analys,&prev,&next,&last,
                              &idxloan->exc,&ext,holi) ;
        if (isexc)
        {
            day = Cldr_DaysBetweenDates(analys, &next, idxloan->accru_cal, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
            ai = (idxloan->coupon / 100.0) * (termafter / fullterm)
                 *((FL64) months / (FL64) 12);
        }
        else
        {
            day = Cldr_DaysBetweenDates(&prev, analys, idxloan->accru_cal, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
            ai = - (idxloan->coupon / 100.0) * (termbefore / fullterm)
                 *((FL64) months / (FL64) 12);
        }
    }
    else
    {
        day = 0 ;
        isexc = 0 ;
        ai = 0.0 ;
    }

    /* Adjust for index factors */
    if (indexadj == True)
        ai *= idxfac ;

    air.AI = ai ;
    air.AI *= (usecred == False ? idxloan->doutstand : idxloan->coutstand) ;
    
    air.AIdays     = day ;
    air.next       = paydays[j] ;
    air.exc        = isexc ;
    air.AI_per_day = (air.AIdays != 0 ? air.AI / air.AIdays : 0.0) ;
         
    /* Free paydays */
    Free_DATEARRAY(paydays) ;

    return air ;
}



/*,,SOH,,
*************************************************************************
*
*               IndexLoan_YTM2Price()
*
*   interface   #include <idxbond.h>
*               FL64 IndexLoan_YTM2Price(FL64       ytm,
*                                        DATESTR    *analys,
*                                        INDEXLOAN  *idxloan,
*                                        INDEXFAC   *debfac,
*                                        INDEXFAC   *crefac,
*                                        YTMCONV    *ytmc,
*                                        HOLI_STR   *holi,
*                                        RISKCONV   risk,
*                                        BOOLE      modf,
*                                        BOOLE      indexadj,
*                                        FL64       *dp,
*                                        FL64       *ddp) ;
*
*   general     The function calculates the clean price given YTM for a
*               index loan with respect to the conventions defined.
*
*               Note that whether or not the clean price is adjusted
*               for index factors depends on indexadj.
*               Also the dollar duration and dollar convexity can be
*               calculated.
*
*               Note that the cashflow of the loan is always indexed.
*               To compute price wrt. real YTM, use a 0% inflation
*               (i.e. flat) index. The YTM published by the
*               Copenhagen Stock Exchange is such a real YTM.
*
*               The conventions defined should be sufficiently general
*               to handle most YTM setup's.
*
*   input       FL64      ytm           The Yield to Maturity of index
*                                       loan
*
*               DATESTR   *analys       The analys date
*
*               INDEXLOAN *idxloan      The index loan definition
*
*               INDEXFAC  *debfac       Debtor index factors
*                                       Use NULL for 0% inflation
*
*               INDEXFAC  *crefac       Creditor index factors
*                                       Use NULL for 0% inflation
*
*               YTMCONV   *ytmc         The conventions defined for
*                                       calculating the YTM
*
*               HOLI_STR  *holi         Container for data on business
*                                       day convention and non-week-end
*                                       holidays
*
*               RISKCONV  risk          The risk setup
*
*               BOOLE     modf          True means that ratios are modified
*                                       (i.e. scaled with the dirty
*                                       price), False means direct
*                                       derivatives
*
*               BOOLE     indexadj      False means that the clean
*                                       price is returned. True means
*                                       that clean price times the
*                                       relevant index factor is
*                                       returned
*
*   output      FL64      *dp           The dollar duration
*
*               FL64      *ddp          The dollar convexity
*
*   returns     The clean price of the index loan on the analys date.
*
*
*   diagnostics
*
*   see also
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/


FL64 IndexLoan_YTM2Price(FL64        ytm,
                             DATESTR*    analys,
                             INDEXLOAN*  idxloan,
                             INDEXFAC*   debfac,
                             INDEXFAC*   crefac,
                             YTMCONV*    ytmc,
                             HOLI_STR*   holi,
                             RISKCONV    risk,
                             BOOLE       modf,
                             BOOLE       indexadj,
                             FL64*       dp,
                             FL64*       ddp)
{
    CFLWARRAY   xcflw ;
    FL64        p, idxfac ;
    PAYDAYDEF   pday ;

    *debfac = Index_PrepIndex(debfac) ;
    *crefac = Index_PrepIndex(crefac) ;

    /* Initialise */
    *ddp = *dp = 0.0 ;
    
    /* Generate paydays */
    pday = INDEXLOAN_Set_PAYDAYDEF(idxloan) ;
    
    /* Generate cashflow */
    xcflw = IndexLoan_GenrCflw(analys, idxloan, debfac, crefac, holi) ;
                                                  
    /* Calculate */
    p = Cflw_YTM2Price(ytm, xcflw, ytmc, &pday, idxloan->coupon, NULL, 
                       holi, risk, modf, dp, ddp) ;


    /* Index adjusted price? */
    if (indexadj == False)
    {
        idxfac = Index_Interpolation(analys, &idxloan->delay, crefac) ;

        /* idxfac is always positive !! */
        p /= idxfac ;

        if (modf == False)
        {
            *dp  /= idxfac ;
            *ddp /= idxfac ;
        }
    }

    /* Free */
    Free_CFLWARRAY(xcflw, 1) ;

    return p ;
}



/*,,SOH,,
*************************************************************************
*
*               IndexLoan_YTM2Yield()
*
*   interface   #include <idxbond.h>
*               BOOLE IndexLoan_YTM2Yield(DATESTR    *analys,
*                                         FL64       price,
*                                         INDEXLOAN  *idxloan,
*                                         INDEXFAC   *debfac,
*                                         INDEXFAC   *crefac,
*                                         YTMCONV    *ytmc,
*                                         BOOLE      indexadj,
*                                         HOLI_STR   *holi,
*                                         ITERCTRL   *ictrl,
*                                         FL64       *ytm) ;
*
*   general     The function calculates the Yield to maturity for a
*               index loan with respect to the conventions defined.
*
*               The conventions defined should be sufficiently general
*               to handle most YTM setup's.
*
*               Note that the cashflow of the loan is always indexed.
*               To compute real YTM, use a 0% inflation (i.e. flat)
*               index. The YTM published by the Copenhagen Stock Exchange
*               is such a real YTM.
*
*
*   input       DATESTR   *analys       The analys date
*
*               FL64      price         The clean price
*
*               INDEXLOAN *idxloan      The indexloan definition
*
*               INDEXFAC  *debfac       Debtor index factors
*                                       Use NULL for 0% inflation
*
*               INDEXFAC  *crefac       Creditor index factors
*                                       Use NULL for 0% inflation
*
*               YTMCONV   *ytmc         The conventions defined for
*                                       calculating the YTM
*
*               BOOLE     indexadj      False means that the clean
*                                       price is input. True means that
*                                       clean price times the relevant
*                                       index factor is input
*
*               HOLI_STR  *holi         Container for data on business
*                                       day convention and non-week-end
*                                       holidays
*
*               ITERCTRL  *ictrl        Iteration control
*
*   output      FL64      *ytm          The YTM calculated in %
*
*   returns     True if all is OK, False if not.
*
*   diagnostics
*
*   see also
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/

BOOLE IndexLoan_YTM2Yield(DATESTR*       analys,
                              FL64           price,
                              INDEXLOAN*     idxloan,
                              INDEXFAC*      debfac,
                              INDEXFAC*      crefac,
                              YTMCONV*       ytmc,
                              BOOLE          indexadj,
                              HOLI_STR*      holi,
                              ITERCTRL*      ictrl,
                              FL64*          ytm)
{
    BOOLE       ok ;
    CFLWARRAY   xcflw ;
    FL64        idxfac ;
    PAYDAYDEF   pday ;

    *debfac = Index_PrepIndex(debfac) ;
    *crefac = Index_PrepIndex(crefac) ;

    /* Generate paydays */
    pday = INDEXLOAN_Set_PAYDAYDEF(idxloan) ;

    /* Generate cashflow */
    xcflw = IndexLoan_GenrCflw(analys, idxloan, debfac, crefac, holi) ;

    /* Adjust Price */
    idxfac = Index_Interpolation(analys, &idxloan->delay, crefac) ;
    price *= (indexadj == False ? idxfac : 1.0) ;

    /* Calculate yield */
    ok = Cflw_YTM2Yield(price, xcflw, ytmc, &pday, idxloan->coupon, 
                        NULL, holi, ictrl, ytm) ;

    Free_CFLWARRAY(xcflw, 1) ;

    return ok ;
}


/*,,SOH,,
*************************************************************************
*
*               IndexLoan_YTM2Duration()
*
*   interface   #include <idxbond.h>
*               FL64 IndexLoan_YTM2Duration(FL64       ytm,
*                                           DATESTR    *analys,
*                                           INDEXLOAN  *idxloan,
*                                           INDEXFAC   *debfac,
*                                           INDEXFAC   *crefac,
*                                           YTMCONV    *ytmc,
*                                           HOLI_STR   *holi) ;
*
*   general     The function calculates the duration given YTM for a
*               index loan with respect to the conventions defined.
*
*               The duration returned here is in YEARS and not in
*               periods. Multiply by number of annual periods to get
*               duration in periods.
*
*               Note that the cashflow of the loan is always indexed.
*               To compute duration wrt. real YTM, use a 0% inflation
*               (i.e. flat) index. The YTM published by the
*               Copenhagen Stock Exchange is such a real YTM.
*
*               The conventions defined should be sufficiently general
*               to handle most YTM setup's.
*
*   input       FL64      ytm           The Yield to Maturity of index
*                                       loan
*
*               DATESTR   *analys       The analys date
*
*               INDEXLOAN *idxloan      The indexloan definition
*                                       Use NULL for 0% inflation
*
*               INDEXFAC  *debfac       Debtor index factors
*                                       Use NULL for 0% inflation
*
*               INDEXFAC  *crefac       Creditor index factors
*
*               YTMCONV   *ytmc         The conventions defined for
*                                       calculating the YTM
*
*               HOLI_STR  *holi         Container for data on business
*                                       day convention and non-week-end
*                                       holidays
*
*   output
*
*   returns     The duration of the index loan on the analys date.
*
*
*   diagnostics
*
*   see also
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/


FL64 IndexLoan_YTM2Duration(FL64        ytm,
                               DATESTR*    analys,
                               INDEXLOAN*  idxloan,
                               INDEXFAC*   debfac,
                               INDEXFAC*   crefac,
                               YTMCONV*    ytmc,
                               HOLI_STR*   holi)
{
    CFLWARRAY   xcflw ;
    FL64        dur ;
    PAYDAYDEF   pday ;

    *debfac = Index_PrepIndex(debfac) ;
    *crefac = Index_PrepIndex(crefac) ;

    /* Generate paydays */
    pday = INDEXLOAN_Set_PAYDAYDEF(idxloan) ;
    
    /* Generate cashflow */
    xcflw = IndexLoan_GenrCflw(analys, idxloan, debfac, crefac, holi) ;
                                                  
    /* Calculate */
    dur = Cflw_YTM2Duration(ytm, xcflw, ytmc, &pday, holi) ;

    /* Free */
    Free_CFLWARRAY(xcflw, 1) ;

    return dur ;
}


/*,,SOH,,
*************************************************************************
*
*               IndexLoan_DF2Price()
*
*   interface   #include <idxbond.h>
*               FL64 IndexLoan_DF2Price(DATESTR    *analys,
*                                       INDEXLOAN  *idxloan,
*                                       INDEXFAC   *debfac,
*                                       INDEXFAC   *crefac,
*                                       DISCFAC    *df,
*                                       HOLI_STR   *holi,
*                                       DFSPREAD   *dfs,
*                                       RISKSET    *risk,
*                                       BOOLE      indexadj,
*                                       FL64       *dp,
*                                       FL64       *ddp) ;
*
*   general     The function calculates the clean price for a index
*               loan given a zero-coupon discount factor curve.
*
*               Note that whether or not the clean price is adjusted
*               for index factors depends on indexadj.
*               Also the dollar duration and dollar convexity can be
*               calculated.
*
*               Risk ratios are calculated as follows:
*
*                   risk->key      dp          ddp
*                   ---------      ---         ----
*                   KEY_DF         $Duration   $Convexity
*                   KEY_BPV        BPV
*                   KEY_INDEX      1st order   0
*                                  inflation   
*                                  sensitivity 
*
*   input       DATESTR   *analys       The analys date
*
*               INDEXLOAN *idxloan      The indexloan definition
*
*               INDEXFAC  *debfac       Debtor index factors
*                                       Use NULL for 0% inflation
*
*               INDEXFAC  *crefac       Creditor index factors
*                                       Use NULL for 0% inflation
*
*               DISCFAC   *df           Discounting structure setup
*
*               HOLI_STR  *holi         Container for data on business
*                                       day convention and non-week-end
*                                       holidays
*
*               DFSPREAD  *dfs          Spread against the curve
*
*               RISKSET   *risk         The risk setup.
*                                       Use NULL for no risk ratios
*
*               BOOLE     indexadj      False means that the clean
*                                       price is returned. True means
*                                       that clean price times the
*                                       relevant index factor is
*                                       returned.
*
*   output      FL64      *dp           The dollar duration
*
*               FL64      *ddp          The dollar convexity
*
*   returns     The clean price of the index loan on the analys date.
*
*
*   diagnostics
*
*   see also
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/


FL64 IndexLoan_DF2Price(DATESTR*    analys,
                            INDEXLOAN*  idxloan,
                            INDEXFAC*   debfac,
                            INDEXFAC*   crefac,
                            DISCFAC*    df,
                            HOLI_STR*   holi,
                            DFSPREAD*   dfs,
                            RISKSET*    risk,
                            BOOLE       indexadj,
                            FL64*       dp,
                            FL64*       ddp)
{
    CFLWARRAY   xcflw ;
    FL64        p, pup, pdown, idxfac ;
    INDEXFAC    creshock, debshock ; 
    
    *debfac = Index_PrepIndex(debfac) ;
    *crefac = Index_PrepIndex(crefac) ;
    
    /* Initialise */
    *ddp = *dp = 0.0 ;
    
    /* Generate cashflow */
    xcflw = IndexLoan_GenrCflw(analys, idxloan, debfac, crefac, holi) ;
                                                  
    /* Calculate */
    p = Cflw_DF2Price(analys, df, xcflw, NULL, holi, dfs, risk, dp, ddp) ;

    if (risk->key == KEY_INDEX)
    {
		/* PMSTA-22396 - SRIDHARA � 160502 */
        /* Parallel inflation shock to both indices*/
        creshock = Index_ShockIndex(crefac, risk->shock, holi) ;
        debshock = Index_ShockIndex(debfac, risk->shock, holi) ;
        
        Free_CFLWARRAY(xcflw, 1) ;
        xcflw = IndexLoan_GenrCflw(analys, idxloan,
                                   &debshock, &creshock, holi) ;
        pup = Cflw_DF2Price(analys, df, xcflw, NULL, holi,
                            dfs, risk, dp, ddp) ;

        Free_INDEXFAC(&creshock) ;
        Free_INDEXFAC(&debshock) ;

		/* PMSTA-22396 - SRIDHARA � 160502 */
        creshock = Index_ShockIndex(crefac, -risk->shock, holi) ;
        debshock = Index_ShockIndex(debfac, -risk->shock, holi) ;
        Free_CFLWARRAY(xcflw, 1) ;
        xcflw = IndexLoan_GenrCflw(analys, idxloan,
                                   &debshock, &creshock, holi) ;
        pdown = Cflw_DF2Price(analys, df, xcflw, NULL, holi,
                            dfs, risk, dp, ddp) ;


        *dp = SafeDivide((pup - pdown) , 2*SCecon_fabs(risk->shock),
                         FL64TOL, 0) ;
        *ddp = 0 ;

        Free_INDEXFAC(&creshock) ;
        Free_INDEXFAC(&debshock) ;

    }

    /* Index adjusted price? */
    if (indexadj == False)
    {
        idxfac = Index_Interpolation(analys, &idxloan->delay, crefac) ;

        /* idxfac is always positive !! */
        p    /= idxfac ;
        *dp  /= idxfac ;
        *ddp /= idxfac ;
    }

    /* Free */
    Free_CFLWARRAY(xcflw, 1) ;

    return p ;
}


/*,,SOH,,
*************************************************************************
*
*               IndexLoan_DF2Delta()
*
*    interface  #include <idxbond.h>
*               FL64ARRAY IndexLoan_DF2Delta(DATESTR    *analys,
*                                            INDEXLOAN  *idxloan,
*                                            INDEXFAC   *debfac,
*                                            INDEXFAC   *crefac,
*                                            DISCFAC    *df,
*                                            HOLI_STR   *holi,
*                                            DFSPREAD   *dfs,
*                                            BOOLE      indexadj,
*                                            DELTASET   *ds);
*
*   general     IndexLoan_DF2Delta() calculates the delta vector for
*               a index loan using a list of predefined shocks to the
*               zero coupon curve.
*
*               The delta vector represents the price differences
*               invoked by the curve shocks.
*
*               Note that whether or not the price differences are
*               adjusted for index factors depends on indexadj.
*
*    input      DATESTR   *analys       Pointer to analysis date
*
*               INDEXLOAN *idxloan      The indexloan definition
*
*               INDEXFAC  *debfac       Debtor index factors
*                                       Use NULL for 0% inflation
*
*               INDEXFAC  *crefac       Creditor index factors
*                                       Use NULL for 0% inflation
*
*               DISCFAC   *df           Discounting structure setup.
*
*               HOLI_STR  *holi         Container for data on business
*                                       day convention and non-week-end
*                                       holidays.
*
*               DFSPREAD  *dfs          Spread against the curve.
*
*               BOOLE     indexadj      False means that the price
*                                       differences are returned. True
*                                       means that price differences
*                                       times the relevant index factor
*                                       is returned.
*
*               DELTASET  *ds           Data for delta calculation
*
*    output
*
*    returns    The delta vector allocated as:
*
*                         Alloc_FL64ARRAY(ds->nshock) ;
*
*    diagnostics
*
*    see also   IndexLoan_DF2Price()
*
*    wrapper    AP
*
*************************************************************************
,,EOH,,*/


FL64ARRAY IndexLoan_DF2Delta(DATESTR*    analys,
                                INDEXLOAN*  idxloan,
                                INDEXFAC*   debfac,
                                INDEXFAC*   crefac,
                                DISCFAC*    df,
                                HOLI_STR*   holi,
                                DFSPREAD*   dfs,
                                BOOLE       indexadj,
                                DELTASET*   ds)
{
    INTI      i ;
    FL64ARRAY dv ;
    FL64      fac ;
    CFLWARRAY xcflw ;


    *debfac = Index_PrepIndex(debfac) ;
    *crefac = Index_PrepIndex(crefac) ;

    /* Generate cashflow */
    xcflw = IndexLoan_GenrCflw(analys, idxloan, debfac, crefac, holi) ;

    /* Calculate */
    dv = Cflw_DF2Delta(analys, df, xcflw, NULL, holi, dfs, ds) ;

    /* Index adjusted price? */
    if (indexadj == False)
    {
        fac = Index_Interpolation(analys, &idxloan->delay, crefac) ;

        /* idxfac is always positive !! */
        for (i = 0; i < ds->nshock; i++)
             dv[i] /= fac ;
    }

    /* Free */
    Free_CFLWARRAY(xcflw, 1) ;

    return dv ;
}


/*,,SOH,,
************************************************************************
*
*              IndexLoan_DF2ImpliedInflation()
*
*  interface   #include <idxbond.h>
*              BOOLE IndexLoan_DF2ImpliedInflation(DATESTR* analys,
*                                                  FL64 p,
*                                                  INDEXLOAN* idxloan,
*                                                  DISCFAC* df,
*                                                  HOLI_STR* holi,
*                                                  DFSPREAD* dfs,
*                                                  CALCONV indexcal,
*                                                  FL64 pwfac,
*                                                  BOOLE indexadj,
*                                                  ITERCTRL *ictrl,
*                                                  FL64 *inflation) ;
*
*
*  general     Computes the flat inflation structure giving idxloan the
*              price p given the discount structure df.
*              NOTE : Due to the very high price sensitivity against
*              inflation is is a difficult to obtain more than 4-5
*              digit precision on the price* as a function of inflation
*              using this routine.
*
*              The returned inflation is annually compounded inflation.
*              Annualised inflation is bound to be between 0% and 100%
*              if other bounds are not explicitly set using ictrl.
*
*              The function should be seen as an approximate inverse
*              to IndexLoan_DF2Price when the indexstructures input to
*              this are flat, with annualised growth of size inflation
*              for creditor factors and size pwfac * inflation for
*              debitor factors.
*              Use Index_FlatIndex to generate the index structures
*              necessary in IndexLoan_DF2Price to recapture the price
*              given the implied inflation.
*
*  input       DATESTR    *analys    The analysis date for which the
*                                    price is assumed to hold
*
*              FL64       p          The qutoed price. Indexadjustment,
*                                    and spreads etc. are observed
*
*              INDEXLOAN  *idxloan   The bond being priced. Note that
*                                    if idxloan.round = True, the price
*                                    of the bond is not a continuous
*                                    function of the inflation
*                                    so the solution price will not be
*                                    precise to more than 4-5 digits.
*
*              DISCFAC    *df        The discount structure
*
*              HOLI_STR   *holi      Business day adjustment data
*
*              DFSPREAD   *dfs       A spread definition. Use NULL for
*                                    0 spread
*
*              CALCONV    indexcal   The calendar used for
*                                    interpolationg index factors
*
*              FL64       pwfac      The ratio of growth in debitor
*                                    (wage) factors relative to
*                                    creditor (price) factors. For IS
*                                    loans the recommended setting is
*                                    either 0.75 or the observed ratio of
*                                    debitor factors to creditor
*                                    factors. Use 1.0 to leave out this
*                                    slow redemption effect. For non IS
*                                    loans this input is not used
*
*              BOOLE      indexadj   Toggle determing if the quoted
*                                    prie is assumed index adjusted
*
*              ITERCTRL   *ictrl     The setup for the rootfinder used to solve
*                                    for price given inflation
*
*  output      FL64       *inflation The resulting inflation. This is
*                                    set even if no inflations could be
*                                    found obtaining the given price.
*
*  returns     True if an inflationlevel could be found. False if not
*
*  diagnostics
*
*  see also    IndexLoan_DF2Price
*
*
************************************************************************
,,EOH,,*/


BOOLE IndexLoan_DF2ImpliedInflation(DATESTR*    analys,
                            FL64        p,
                            INDEXLOAN*  idxloan,
                            DISCFAC*    df,
                            HOLI_STR*   holi,
                            DFSPREAD*   dfs,
                            CALCONV     indexcal,
                            FL64        pwfac,
                            BOOLE       indexadj,
                            ITERCTRL    *ictrl,
                            FL64 *inflation)
{
   INDEXFAC idxfac ;
   INDEXLOANINT idxdata ;
   PAYDAYDEF ilpddef ;
   DATEARRAY  ilpaydays ;
   ITERCTRL thisctrl ;
   NR_ERR   nres ;
   BOOLE ok ;
   INTI i, ndays ;

   idxfac.cal = indexcal ;
   idxfac.baseidx = 100 ;
   idxfac.round = False ;
   idxfac.roundOff = 0 ;

   /* Set a plan str in the indexfac with volinterpolation dates*/

   ilpddef = INDEXLOAN_Set_PAYDAYDEF(idxloan) ;
   ilpaydays = Cflw_Paydays(&ilpddef, holi, &ndays) ;
   idxfac.idxfac = Alloc_PLANARRAY(1,ndays) ;
   for (i = 0; i<ndays; i++) idxfac.idxfac->day[i]= ilpaydays[i] ;
   idxfac.idxfac->filled = ndays ;

   Free_DATEARRAY(ilpaydays) ;

   /* Transfer data to NR data container*/
   Index_SetINDEXLOANINT(analys, idxloan, &idxfac, df, holi,
                     dfs, 0.01, pwfac, indexadj, p ,&idxdata) ;


   thisctrl = *ictrl ;
   if (!ictrl->use_init_guess) thisctrl.init_guess = 50 ;
   /* We force positive inflation*/
   if (!ictrl->use_lower) thisctrl.lower = 0.0 ; 
   /* And disallow absurd scenarios */
   if (!ictrl->use_upper) thisctrl.upper = 100.0 ;
   if (ictrl->damp<=0) thisctrl.damp = 0.95 ;

   nres = Newton_Raphson(&IndexLoan_NewtonRaphson, &idxdata,
                         &thisctrl, inflation, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */

   ok = (nres == NR_ROOT_FOUND ? True : False) ;

   Free_INDEXFAC(&idxfac) ;

   return ok ;

}


/*,,SOH,,
*************************************************************************
*
*              IndexBond_GenrCflw()
*
*    interface #include <idxbond.h>
*              CFLWARRAY IndexBond_GenrCflw(TRADEINFO *start,
*                                           INDEXBOND *idxbond,
*                                           INDEXFAC  *idxfac,
*                                           HOLI_STR  *holi) ;
*
*    general   This function generates cash flow for index bonds from
*              start date till maturity. This function can generate
*              cashflows for general bonds where all amounts
*              - outstanding, repayment, coupons, etc. are
*              indexed by the same inflation-index on a given date.
*              When idxbond->indexednotional is True, the notional is assumed
*              to be indexed to effective date or if irregular payments
*              are specified they are assumed to be indexed to first
*              repayment date.
*              When idxbond->indexednotional = False, notional and
*              irregular payments are assumed to be unindexed.
*              
*
*    input     TRADEINFO  *start     The first trade date
*
*              INDEXBOND  *idxbond   The index bond definition
*                                    Irregular repayments are
*                                    assumed to be indexed to first
*                                    repayment date.
*
*              INDEXFAC   *idxfac    Index factors
*                                    Use NULL for 0% inflation
*
*              HOLI_STR   *holi      Business day adjustment data
*
*    returns   Pointer to cashflow generated. Allocated in this routine
*              as Alloc_CFLWARRAY(1, x), where x is calculated.
*              Note that when fixpay.repay.irreg is set
*              the cashflow is not scaled to 100 notional as is
*              customary in other parts of the library, instead returned
*              redemptions are the entries in fixpay.repay.irreg indexed
*              by the index factor on that date.
*            
*              
*
*    diagnostics
*
*    see also  IndexBond_GenrPeriod()
*
*    wrapper   AP
*
*************************************************************************
,,EOH,,*/


CFLWARRAY IndexBond_GenrCflw(TRADEINFO*     start,
                                 INDEXBOND*     idxbond,
                                 INDEXFAC*      idxfac,
                                 HOLI_STR*      holi)
{
    CFLWARRAY cflw ;
    INTI      i, filled ;
    FL64      startfac, fac, sum, scale, rn ;
    FL64ARRAY irreg_old, irreg ;

    /* warning avoidance */
    scale = 0.0 ;
    irreg = irreg_old = NULL ;
    *idxfac = Index_PrepIndex(idxfac) ;

    /* Norm irregular amort */    
    filled = GetPlanFill(idxbond->fixp.repay.irreg) ;
    if (idxbond->fixp.repay.type == NONREGULAR && filled > 0)
    {
        /* Make copy of irreg amort */
        irreg_old = idxbond->fixp.repay.irreg->f64 ;

        /* Allocate and initialise local copy of irreg amort */
        irreg  = Alloc_FL64ARRAY(filled) ;
        for (i = 0; i < filled; i++)
            irreg[i] = irreg_old[i] ;

        /* Scale cflw only counting days after trade->settle*/
        sum = 0.0 ;
        for (i = 0 ; i < filled ; i++)
            sum +=  irreg[i] ;

        scale = (fabs(sum) > IDXTOL ? (100.0/sum) : 1.0) ;

        for (i = 0; i < filled; i++)
            irreg[i] *= scale ;

        idxbond->fixp.repay.irreg->f64 = irreg ;
    }
    else
        scale = SafeDivide(100.0, start->nom, FL64TOL, 1.0 ); 

    
    rn = IndexBond_RemainingNotional(&start->settle, idxbond, holi) ;
    scale *= SafeDivide(100, rn, FL64TOL, 1.0) ;


    /* Generate cflw */
    cflw = Bond_GenrCflw(start, &idxbond->fixp, holi) ;

    /* Re-scale cflw */

    scale = (fabs(scale) > IDXTOL ? scale : 1.0) ;
    for (i = 0; i < cflw->filled; i++)
    {
        cflw->coupon[i] /= scale ;
        cflw->repay[i]  /= scale ;
    }

    if (idxbond->fixp.repay.type == NONREGULAR && filled > 0)
    {
        
        idxbond->fixp.repay.irreg->f64 = irreg_old ;
        
        /* Free */
        Free_FL64ARRAY(irreg) ;
    }

    /* Adjust for index factors */

    startfac = IndexBond_StartIndex(idxbond, idxfac) ;

    if (cflw->filled > 0)
    {
        for (i = 0; i < cflw->filled ; i++)
        {
            /* Find index factor */
            fac = Index_Interpolation(&cflw->days[i], 
                                      &idxbond->cflw_delay, idxfac)
                  /startfac ;

            /* Multiply by index factors */
            cflw->repay[i]  *= fac ;
            cflw->coupon[i] *= fac ;
        }
    }

    return cflw ;
}


/*,,SOH,,
*************************************************************************
*
*              IndexBond_GenrPeriod()
*
*    interface #include <idxbond.h>
*              CFLWARRAY IndexBond_GenrPeriod(TRADEINFO *start,
*                                              TRADEINFO *end,
*                                              INDEXBOND *idxbond,
*                                              INDEXFAC  *idxfac,
*                                              HOLI_STR  *holi) ;
*
*    general   This function generates cash flow for index bonds from
*              start date til end date.  
*              Note that the cashflow generated is
*              a period cashflow, i.e. the cashflow from holding the
*              bond from start to end and the reselling at end date.
*
*              To generate the pure bond cash flow, not including
*              reselling, use IndexBond_GenrCflw to generate the full cflw.
*              and Cflw_ExtractCflw to truncate at end date.
*
*    input     TRADEINFO  *start     The period start date
*
*              TRADEINFO  *end       The period end date
*
*              INDEXBOND  *idxbond   The index bond definition
*
*              INDEXFAC   *idxfac    Index factors
*                                    Use NULL for 0% inflation
*
*              HOLI_STR   *holi      Business day adjustment data
*
*    returns   Pointer to cashflow generated. Allocated in this routine
*              as Alloc_CFLWARRAY(1, x), where x is calculated.
*
*    diagnostics
*
*    see also  IndexBond_GenrCflw()
*              Cflw_ExtractCflw()
*
*************************************************************************
,,EOH,,*/


CFLWARRAY IndexBond_GenrPeriod(TRADEINFO*     start,
                                   TRADEINFO*     end,
                                   INDEXBOND*     idxbond,
                                   INDEXFAC*      idxfac,
                                   HOLI_STR*      holi)
{
    CFLWARRAY cflw ;
    INTI      i, filled ;
    FL64      startfac, fac, sum, scale, rn ;
    FL64ARRAY irreg_old, irreg ;

    /* warning avoidance */
    scale = 0.0 ;
    irreg_old = irreg = NULL ;
    *idxfac = Index_PrepIndex(idxfac) ;

    /* Norm irregular amort */    
    filled = GetPlanFill(idxbond->fixp.repay.irreg) ;
    if (idxbond->fixp.repay.type == NONREGULAR && filled > 0)
    {
        /* Make copy of irreg amort */
        irreg_old = idxbond->fixp.repay.irreg->f64 ;

        /* Allocate and initialise local copy of irreg amort */
        irreg  = Alloc_FL64ARRAY(filled) ;
        for (i = 0; i < filled; i++)
            irreg[i] = irreg_old[i] ;

        /* Scale cflw */
        sum = 0.0 ;
        for (i = 0 ; i < filled ; i++)
            sum += irreg[i] ;

        scale = (fabs(sum) > IDXTOL ? (100.0/sum) : 1.0) ;

        for (i = 0; i < filled; i++)
            irreg[i] *= scale ;

        idxbond->fixp.repay.irreg->f64 = irreg ;
    }
    else
        scale = SafeDivide(100.0, start->nom, FL64TOL, 1.0 ); 

    
    rn = IndexBond_RemainingNotional(&start->settle, idxbond, holi) 
         - IndexBond_RemainingNotional(&end->settle, idxbond, holi) ;
    scale *= SafeDivide(100, rn, FL64TOL, 1.0) ;

    
    /* Generate cflw */
    cflw = Bond_GenrPeriod(start, end, &idxbond->fixp, holi) ;
    
    /* Re-scale cflw */
    if (idxbond->fixp.repay.type == NONREGULAR && filled > 0)
    {
        scale = (fabs(scale) > IDXTOL ? scale : 1.0) ;
        for (i = 0; i < cflw->filled; i++)
        {
            cflw->coupon[i] /= scale ;
            cflw->repay[i]  /= scale ;
        }
        
        idxbond->fixp.repay.irreg->f64 = irreg_old ;
        
        /* Free */
        Free_FL64ARRAY(irreg) ;
    }

    /* Adjust for index factors */
    startfac = IndexBond_StartIndex(idxbond, idxfac) ;

    if (cflw->filled > 0)
    {
        for (i = 0; i < cflw->filled ; i++)
        {
            /* Find index factor */
            fac  = Index_Interpolation(&cflw->days[i], 
                                       &idxbond->cflw_delay, idxfac)
                   / startfac ;


            /* Multiply by index factors */
            cflw->repay[i]  *= fac ;
            cflw->coupon[i] *= fac ;
        }
    }

    return cflw ;
}


/*,,SOH,,
*************************************************************************
*
*              IndexBond_Accruint()
*
*    interface #include <idxbond.h>
*              AIRESULT IndexBond_Accruint(TRADEINFO   *basis,
*                                          INDEXBOND   *idxbond,
*                                          INDEXFAC    *idxfac,
*                                          BOOLE       indexadj,
*                                          HOLI_STR    *holi) ;
*
*    general   This function calculates the accrued interest for a
*              index bond at any time during the life of the index bond.
*
*    input     TRADEINFO   *basis    The settle date info. AI is
*                                    calculated on settle->aisettle
*                                    If settle->brd is False then
*                                    only settle->aisttl is used
*
*              INDEXBOND   *idxbond  The index bond definition
*
*              INDEXFAC    *idxfac   Index factors
*                                    Use NULL for 0% inflation
*
*              BOOLE       indexadj  False means that the actual
*                                    accrued interest is returned.
*                                    True means that accrued interest
*                                    times the relevant index factor is
*                                    returned.
*
*              HOLI_STR    *holi     Business day adjustment data
*
*    output
*
*    returns   Various data on the calculation as an AIRESULT struct.
*
*    diagnostics
*
*    see also
*
*    wrapper   AP
*
*************************************************************************
,,EOH,,*/


AIRESULT IndexBond_Accruint(TRADEINFO*   basis,
                               INDEXBOND*   idxbond,
                               INDEXFAC*    idxfac,
                               BOOLE        indexadj,
                               HOLI_STR*    holi)
{
    AIRESULT    ai ;
    FL64        startfac, fac, scale, sum , rn;
    FL64ARRAY   irreg, irreg_old ;
    INTI        i, filled ;

    /* warning avoidance */
    scale = 0.0 ;
    irreg_old = irreg = NULL ;
    *idxfac = Index_PrepIndex(idxfac) ;


    /* Norm irregular amort */    
    filled = GetPlanFill(idxbond->fixp.repay.irreg) ;
    if (idxbond->fixp.repay.type == NONREGULAR && filled > 0)
    {
        /* Make copy of irreg amort */
        irreg_old = idxbond->fixp.repay.irreg->f64 ;

        /* Allocate and initialise local copy of irreg amort */
        irreg  = Alloc_FL64ARRAY(filled) ;
        for (i = 0; i < filled; i++)
            irreg[i] = irreg_old[i] ;

        /* Scale cflw */
        sum = 0.0 ;
        for (i = 0 ; i < filled ; i++)
            sum += irreg[i] ;

        scale = (fabs(sum) > IDXTOL ? (100.0 / sum) : 1.0) ;

        for (i = 0; i < filled; i++)
            irreg[i] *= scale ;

        idxbond->fixp.repay.irreg->f64 = irreg ;
    }
    else
        scale = SafeDivide(100.0, basis->nom, FL64TOL, 1.0 ); 

    
    rn = IndexBond_RemainingNotional(&basis->settle, idxbond, holi) ;
    scale *= SafeDivide(100, rn, FL64TOL, 1.0) ;

    /* Calculate */
    ai = Bond_Accruint(basis, &idxbond->fixp, holi) ;

    /* Re-scale Accrued int */
    if (idxbond->fixp.repay.type == NONREGULAR && filled > 0)
    {
        /* scale must be positive */
        scale = (fabs(scale) > IDXTOL ? scale : 1.0) ;
    
        /* Re-scale */
        ai.AI /= scale ;        
        ai.AI_per_day = (ai.AIdays != 0 ? ai.AI / ai.AIdays : 0.0) ;
        
        idxbond->fixp.repay.irreg->f64 = irreg_old ;
        
        /* Free */
        Free_FL64ARRAY(irreg) ;
    }

    startfac = IndexBond_StartIndex(idxbond, idxfac) ;
    if (indexadj == True)
    {
        fac = Index_Interpolation(&basis->settle,
                                  &idxbond->pv_delay, idxfac)
              / startfac ;


        /* Adjust for index factors */
        ai.AI *= fac ;
        ai.AI_per_day = (ai.AIdays != 0 ? ai.AI / ai.AIdays : 0.0) ;
    }

    return ai ;
}


/*,,SOH,,
*************************************************************************
*
*               IndexBond_YTM2Price()
*
*   interface   #include <idxbond.h>
*               FL64 IndexBond_YTM2Price(FL64       ytm,
*                                        TRADEINFO  *trade,
*                                        INDEXBOND  *idxbond,
*                                        INDEXFAC   *idxfac,
*                                        YTMCONV    *ytmc,
*                                        HOLI_STR   *holi,
*                                        RISKCONV   risk,
*                                        BOOLE      modf,
*                                        BOOLE      indexadj,
*                                        FL64       *dp,
*                                        FL64       *ddp) ;
*
*   general     The function calculates the clean price given YTM for a
*               index bond with respect to the conventions defined.
*               Note that whether or not the clean price is adjusted
*               for index factors depends on indexadj.
*               Also the dollar duration and dollar convexity can be
*               calculated.
*
*               The conventions defined should be sufficiently general
*               to handle most YTM setup's.
*
*   input       FL64      ytm           The Yield to Maturity of index
*                                       loan
*
*               TRADEINFO *trade        The trade data
*
*               INDEXBOND *idxbond      The index bond definition
*
*               INDEXFAC  *idxfac       Index factors
*                                       Use NULL for 0% inflation
*
*               YTMCONV   *ytmc         The conventions defined for
*                                       calculating the YTM
*
*               HOLI_STR  *holi         Container for data on business
*                                       day convention and non-week-end
*                                       holidays
*
*               RISKCONV  risk          The risk setup
*
*               BOOLE     modf          True means that ratios are modi-*
*                                       (i.e. scaled with the dirty
*                                       price), False means direct
*                                       derivatives
*
*               BOOLE     indexadj      False means that the clean
*                                       price is returned. True means
*                                       that clean price times the
*                                       relevant index factor is
*                                       returned
*
*   output      FL64      *dp           The dollar duration
*
*               FL64      *ddp          The dollar convexity
*
*   returns     The clean price of the bond on the settlement date.
*
*   diagnostics
*
*   see also
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/
FL64 IndexBond_YTM2Price(FL64        ytm,
                             TRADEINFO*  trade,
                             INDEXBOND*  idxbond,
                             INDEXFAC*   idxfac,
                             YTMCONV*    ytmc,
                             HOLI_STR*   holi,
                             RISKCONV    risk,
                             BOOLE       modf,
                             BOOLE       indexadj,
                             FL64*       dp,
                             FL64*       ddp)
{
    CFLWARRAY xcflw ;
    FL64      p, fac;

    /* Initialise */
    *ddp = *dp = 0.0 ;
    *idxfac = Index_PrepIndex(idxfac) ;


    /* Generate cashflow */
    xcflw = IndexBond_GenrCflw(trade, idxbond, idxfac, holi) ;
                
    /* Calculate */
    p = Cflw_YTM2Price(ytm, xcflw, ytmc, &idxbond->fixp.cday, 
                       idxbond->fixp.fix.fix_rate,
                       &idxbond->fixp.repay.pp, holi, 
                       risk, modf, dp, ddp) ;

    /* Index adjusted price? */
    if (indexadj == False)
    {
        fac = Index_Interpolation(&trade->settle,
                                  &idxbond->pv_delay, idxfac)
              /IndexBond_StartIndex(idxbond, idxfac);

        /* idxfac is always positive !! */
        p /= fac ;

        if (modf == False)
        {
            *dp  /= fac ;
            *ddp /= fac ;
        }
    }

    /* Free */
    Free_CFLWARRAY(xcflw, 1) ;

    return p ;
}


/*,,SOH,,
*************************************************************************
*
*               IndexBond_YTM2Yield()
*
*   interface   #include <idxbond.h>
*               BOOLE IndexBond_YTM2Yield(TRADEINFO  *trade,
*                                         INDEXBOND  *idxbond,
*                                         INDEXFAC   *idxfac,
*                                         YTMCONV    *ytmc,
*                                         BOOLE      indexadj,
*                                         HOLI_STR   *holi,
*                                         ITERCTRL   *ictrl,
*                                         FL64       *ytm) ;
*
*   general     The function calculates the Yield to maturity for a
*               index bond with respect to the conventions defined.
*
*               The conventions defined should be sufficiently general
*               to handle most YTM setup's.
*
*   input       TRADEINFO *trade        The trade data
*
*               INDEXBOND *idxbond      The index bond definition
*
*               INDEXFAC  *idxfac       Index factors
*                                       Use NULL for 0% inflation
*
*               YTMCONV   *ytmc         The conventions defined for
*                                       calculating the YTM
*
*               BOOLE     indexadj      False means that the clean
*                                       price is input. True means that
*                                       clean price times the relevant
*                                       index factor is input
*
*               HOLI_STR  *holi         Container for data on business
*                                       day convention and non-week-end
*                                       holidays
*
*               ITERCTRL  *ictrl        Iteration control
*
*   output      FL64      *ytm          The YTM calculated in %
*
*   returns     True if all is OK, False if not.
*
*   diagnostics
*
*   see also
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/
BOOLE IndexBond_YTM2Yield(TRADEINFO*     trade,
                             INDEXBOND*     idxbond,
                             INDEXFAC*      idxfac,
                             YTMCONV*       ytmc,
                             BOOLE          indexadj,
                             HOLI_STR*      holi,
                             ITERCTRL*      ictrl,
                             FL64*          ytm)
{
    BOOLE       ok ;
    CFLWARRAY   xcflw ;
    FL64        fac, price;
    
    /* Initialise */
    price = trade->price ;
    *idxfac = Index_PrepIndex(idxfac) ;
    
    /* Generate cashflow */
    xcflw = IndexBond_GenrCflw(trade, idxbond, idxfac, holi) ;

    /* Adjust Price */
    fac = Index_Interpolation(&trade->settle, &idxbond->pv_delay, idxfac)
          /IndexBond_StartIndex(idxbond, idxfac);
    price *= (indexadj == False ? fac : 1.0) ;

    /* Calculate yield */
    ok = Cflw_YTM2Yield(price, xcflw, ytmc, &idxbond->fixp.cday, 
                        idxbond->fixp.fix.fix_rate,
                        &idxbond->fixp.repay.pp, 
                        holi, ictrl, ytm) ;

    Free_CFLWARRAY(xcflw, 1) ;

    return ok ;
}


/*,,SOH,,
*************************************************************************
*
*               IndexBond_YTM2Duration()
*
*   interface   #include <idxbond.h>
*               FL64 IndexBond_YTM2Duration(FL64       ytm,
*                                           TRADEINFO  *trade,
*                                           INDEXBOND  *idxbond,
*                                           INDEXFAC   *idxfac,
*                                           YTMCONV    *ytmc,
*                                           HOLI_STR   *holi) ;
*
*   general     The function calculates the duration given YTM for a
*               index bond with respect to the conventions defined.
*
*               The duration returned here is in YEARS and not in
*               periods. Multiply by number of annual periods to get
*               duration in periods.
*
*               The conventions defined should be sufficiently general
*               to handle most YTM setup's.
*
*   input       FL64      ytm           The Yield to Maturity of index
*                                       bond
*
*               TRADEINFO *trade        The trade data
*
*               INDEXBOND *idxbond      The index bond definition
*
*               INDEXFAC  *idxfac       Index factors
*                                       Use NULL for 0% inflation
*
*               YTMCONV   *ytmc         The conventions defined for
*                                       calculating the YTM
*
*               HOLI_STR  *holi         Container for data on business
*                                       day convention and non-week-end
*                                       holidays
*
*   output
*
*   returns     The duration of the index bond on the analys date.
*
*
*   diagnostics
*
*   see also
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/
FL64 IndexBond_YTM2Duration(FL64        ytm,
                               TRADEINFO*  trade,
                               INDEXBOND*  idxbond,
                               INDEXFAC*   idxfac,
                               YTMCONV*    ytmc,
                               HOLI_STR*   holi)
{
    CFLWARRAY   xcflw ;
    FL64        dur ;

    *idxfac = Index_PrepIndex(idxfac) ;
    
    /* Generate cashflow */
    xcflw = IndexBond_GenrCflw(trade, idxbond, idxfac, holi) ;
                                                  
    /* Calculate */
    dur = Cflw_YTM2Duration(ytm, xcflw, ytmc, &idxbond->fixp.cday, holi) ;

    /* Free */
    Free_CFLWARRAY(xcflw, 1) ;

    return dur ;
}


/*,,SOH,,
*************************************************************************
*
*               IndexBond_DF2Price()
*
*   interface   #include <idxbond.h>
*               FL64 IndexBond_DF2Price(TRADEINFO  *trade,
*                                       INDEXBOND  *idxbond,
*                                       INDEXFAC   *idxfac,
*                                       DISCFAC    *df,
*                                       HOLI_STR   *holi,
*                                       DFSPREAD   *dfs,
*                                       RISKSET    *risk,
*                                       BOOLE      indexadj,
*                                       FL64       *dp,
*                                       FL64       *ddp) ;
*
*   general     The function calculates the clean price for a index
*               bond given a zero-coupon discount factor curve.
*
*               Note that whether or not the clean price is adjusted
*               for index factors depends on indexadj.
*               Also the dollar duration and dollar convexity can be
*               calculated.
*
*               Risk ratios are calculated as follows:
*
*                   risk->key      dp          ddp
*                   ---------      ---         ----
*                   KEY_DF         $Duration   $Convexity
*                   KEY_BPV        BPV
*                   KEY_INDEX      1st order   0
*                                  inflation   
*                                  sensitivity 
*
*   input       TRADEINFO *trade        The trade data
*
*               INDEXBOND *idxbond      The index bond definition
*
*               INDEXFAC  *idxfac       Index factors
*                                       Use NULL for 0% inflation
*
*               DISCFAC   *df           Discounting structure setup
*
*               HOLI_STR  *holi         Container for data on business
*                                       day convention and non-week-end
*                                       holidays
*
*               DFSPREAD  *dfs          Spread against the curve
*
*               RISKSET   *risk         The risk setup.
*                                       Use NULL for no risk ratios
*
*               BOOLE     indexadj      False means that the clean
*                                       price is returned. True means
*                                       that clean price times the
*                                       relevant index factor is
*                                       returned
*
*   output      FL64      *dp           The dollar duration
*
*               FL64      *ddp          The dollar convexity
*
*   returns     The clean price of the index loan on the analys date.
*
*
*   diagnostics
*
*   see also
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/

FL64 IndexBond_DF2Price(TRADEINFO*  trade,
                            INDEXBOND*  idxbond,
                            INDEXFAC*   idxfac,
                            DISCFAC*    df,
                            HOLI_STR*   holi,
                            DFSPREAD*   dfs,
                            RISKSET*    risk,
                            BOOLE       indexadj,
                            FL64*       dp,
                            FL64*       ddp)
{
    CFLWARRAY   xcflw ;
    FL64        p, pup, pdown, fac;
    INDEXFAC    idxshock ;
    
    /* Initialise */
    *ddp = *dp = 0.0 ;
    *idxfac = Index_PrepIndex(idxfac) ;
    
    /* Generate cashflow */
    xcflw = IndexBond_GenrCflw(trade, idxbond, idxfac, holi) ;
                                                  
    /* Calculate */
    p = Cflw_DF2Price(&trade->settle, df, xcflw, &idxbond->fixp.repay.pp, 
                      holi, dfs, risk, dp, ddp) ;

    if (risk->key == KEY_INDEX)
    {
        /* Parallel inflation shock to both indices*/
		idxshock = Index_ShockIndex(idxfac, risk->shock, holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */

        
        Free_CFLWARRAY(xcflw, 1) ;
        xcflw = IndexBond_GenrCflw(trade, idxbond, &idxshock, holi) ;
        pup = Cflw_DF2Price(&trade->settle, df, xcflw, 
                    &idxbond->fixp.repay.pp, holi, dfs, risk, dp, ddp) ;

        Free_INDEXFAC(&idxshock) ;

        idxshock = Index_ShockIndex(idxfac, -risk->shock, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */

        Free_CFLWARRAY(xcflw, 1) ;
        xcflw = IndexBond_GenrCflw(trade, idxbond, &idxshock, holi) ;
        pdown = Cflw_DF2Price(&trade->settle, df, xcflw, 
                    &idxbond->fixp.repay.pp, holi, dfs, risk, dp, ddp) ;


        *dp = SafeDivide((pup - pdown) , 2*SCecon_fabs(risk->shock),
                         FL64TOL, 0) ;
        *ddp = 0 ;

        Free_INDEXFAC(&idxshock) ;

    }

    /* Index adjusted price? */
    if (indexadj == False)
    {
        fac = Index_Interpolation(&trade->settle, &idxbond->pv_delay, idxfac)
              /IndexBond_StartIndex(idxbond, idxfac);

        /* idxfac is always positive !! */
        p    /= fac ;
        *dp  /= fac ;
        *ddp /= fac ;
    }

    /* Free */
    Free_CFLWARRAY(xcflw, 1) ;

    return p ;
}


/*,,SOH,,
*************************************************************************
*
*               IndexBond_DF2Delta()
*
*    interface  #include <idxbond.h>
*               FL64ARRAY IndexBond_DF2Delta(TRADEINFO  *trade,
*                                            INDEXBOND  *idxbond,
*                                            INDEXFAC   *idxfac,
*                                            DISCFAC    *df,
*                                            HOLI_STR   *holi,
*                                            DFSPREAD   *dfs,
*                                            BOOLE      indexadj,
*                                            DELTASET   *ds);
*
*   general     IndexBond_DF2Delta() calculates the delta vector for
*               a index bond using a list of predefined shocks to the
*               zero coupon curve.
*
*               The delta vector represents the price differences
*               invoked by the curve shocks.
*
*               Note that whether or not the price differences are
*               adjusted for index factors depends on indexadj.
*
*    input      TRADEINFO *trade        The trade data
*
*               INDEXBOND *idxbond      The index bond definition
*
*               INDEXFAC  *idxfac       Index factors
*                                       Use NULL for 0% inflation
*
*               DISCFAC   *df           Discounting structure setup
*
*               HOLI_STR  *holi         Container for data on business
*                                       day convention and non-week-end
*                                       holidays
*
*               DFSPREAD  *dfs          Spread against the curve
*
*               BOOLE     indexadj      False means that the price
*                                       differences are returned. True
*                                       means that price differences
*                                       times the relevant index factor
*                                       is returned
*
*               DELTASET  *ds           Data for delta calculation
*
*    output
*
*    returns    The delta vector allocated as:
*
*                         Alloc_FL64ARRAY(ds->nshock) ;
*
*    diagnostics
*
*    see also   IndexBond_DF2Price()
*
*    wrapper    AP
*
*************************************************************************
,,EOH,,*/

FL64ARRAY IndexBond_DF2Delta(TRADEINFO*  trade,
                                INDEXBOND*  idxbond,
                                INDEXFAC*   idxfac,
                                DISCFAC*    df,
                                HOLI_STR*   holi,
                                DFSPREAD*   dfs,
                                BOOLE       indexadj,
                                DELTASET*   ds)
{
    INTI      i ;
    FL64ARRAY dv ;
    FL64      fac ;
    CFLWARRAY xcflw ;

    *idxfac = Index_PrepIndex(idxfac) ;
    
    /* Generate cashflow */
    xcflw = IndexBond_GenrCflw(trade, idxbond, idxfac, holi) ;
                                                  
    dv = Cflw_DF2Delta(&trade->settle, df, xcflw, NULL, holi, dfs, ds) ;

    /* Index adjusted price? */
    if (indexadj == False)
    {
        fac = Index_Interpolation(&trade->settle, &idxbond->pv_delay, idxfac)
              /IndexBond_StartIndex(idxbond, idxfac);

        /* idxfac is always positive !! */
        for (i = 0; i < ds->nshock; i++)
             dv[i] /= fac ;
    }

    /* Free */
    Free_CFLWARRAY(xcflw, 1) ;

    return dv ;
}



/*,,SOH,,
************************************************************************
*
*              IndexBond_DF2ImpliedInflation()
*
*  interface   #include <idxbond.h>
*              BOOLE IndexBond_DF2ImpliedInflation(TRADEINFO* trade,
*                                                  INDEXBOND* idxbond,
*                                                  DISCFAC* df,
*                                                  HOLI_STR* holi,
*                                                  DFSPREAD* dfs,
*                                                  CALCONV indexcal,
*                                                  BOOLE indexadj,
*                                                  ITERCTRL *ictrl,
*                                                  FL64 *inflation) ;
*
*
*  general     Computes the flat inflation structure giving idxbond the
*              price trade.price and the discount structure df.
*              NOTE : Due to the very high price sensitivity against
*              inflation is is a difficult to obtain more than 4-5
*              digit precision on the price* as a function of inflation
*              using this routine.
*
*              Returned inflation is annually compounded inflation.
*              Annualised inflation is bound to be between 0% and 100%
*              if other bounds are not explicitly set using ictrl.
*
*              The function should be seen as an approximate inverse
*              to IndexBond_DF2Price when the indexstructures input to
*              this are flat, with annualised growth of size inflation
*              for creditor factors and size pwfac * inflation for
*              debitor factors.
*              Use Index_FlatIndex to generate the index structures
*              necessary in IndexBond_DF2Price to recapture the price
*              given the implied inflation.
*
*  input       TRADEINFO* trade      Tradeinformation. The price assumed
*                                    for the implied calc. is trade.price
*
*              INDEXBOND* idxbond    The bond being priced.
*
*              DISCFAC*   df         The discount structure
*
*              HOLI_STR*  holi       Business day adjustment data
*
*              DFSPREAD*  dfs        A spread definition. Use NULL for
*                                    0 spread
*
*              CALCONV    indexcal   The calendar used for
*                                    interpolationg index factors
*
*              BOOLE      indexadj   Toggle determing if the quoted
*                                    prie is assumed index adjusted
*
*              ITERCTRL   *ictrl     The setup for the rootfinder used to solve
*                                    for price given inflation
*
*  output      FL64       *inflation The resulting inflation. This is
*                                    set even if no inflations could be
*                                    found obtaining the given price.
*
*  returns     True if an inflationlevel could be found. False if not
*
*  diagnostics
*
*  see also    IndexBond_DF2Price
*
*
************************************************************************
,,EOH,,*/


BOOLE IndexBond_DF2ImpliedInflation(TRADEINFO*   trade, 
                            INDEXBOND*  idxbond,
                            DISCFAC*    df,
                            HOLI_STR*   holi,
                            DFSPREAD*   dfs,
                            CALCONV     indexcal,
                            BOOLE       indexadj,
                            ITERCTRL    *ictrl,
                            FL64 *inflation)
{
   INDEXFAC idxfac ;
   INDEXBONDINT idxdata ;
   PAYDAYSEQ  pseq ;
   PAYDAYDEF ilpddef ;
   DATEARRAY  ilpaydays ;
   NR_ERR   nres ;
   BOOLE ok ;
   INTI i, ndays ;
   ITERCTRL thisctrl ;

   idxfac.cal = indexcal ;
   idxfac.baseidx = 100 ;
   idxfac.round = False ;
   idxfac.roundOff = 0 ;

   /* Set a plan str in the indexfac with volinterpolation dates */
   
   /* make sure the structure has dates from settle to expiry */

   pseq = Set_PAYDAYSEQ(3, MONTHS, NOODD, NOODD, ANCHOR, SAME) ;
   ilpddef = Set_PAYDAYDEF(True, &trade->settle, NULL,
                             &idxbond->fixp.rday.last,
                             False, &pseq, 0 , NULL) ;
   ilpaydays = Cflw_Paydays(&ilpddef, holi, &ndays) ;

   idxfac.idxfac = Alloc_PLANARRAY(1,ndays) ;
   for (i = 0; i<ndays; i++) idxfac.idxfac->day[i]= ilpaydays[i] ;
   idxfac.idxfac->filled = ndays ;
   idxfac.cal = indexcal ;
   idxfac.baseidx = 1.0 ;

   Free_DATEARRAY(ilpaydays) ;

   /* Transfer data to NR data container*/
   Index_SetINDEXBONDINT(idxbond, trade, &idxfac, df, holi,
                     dfs, 0.01, indexadj ,&idxdata) ;


   thisctrl = *ictrl ;
   if (!ictrl->use_init_guess) thisctrl.init_guess = 50 ;
   /* We force positive inflation*/
   if (!ictrl->use_lower) thisctrl.lower = 0.0 ; 
   /* And disallow absurd scenarios */
   if (!ictrl->use_upper) thisctrl.upper = 100.0 ;
   if (ictrl->damp<=0) thisctrl.damp = 0.95 ;

   nres = Newton_Raphson(&IndexBond_NewtonRaphson,
                         &idxdata, &thisctrl, inflation, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */

   ok = (nres == NR_ROOT_FOUND ? True : False) ;

   Free_INDEXFAC(&idxfac) ;

   return ok ;

}



/*,,SOH,,
*************************************************************************
*
*               Index_Interpolation()
*
*    interface  #include <idxbond.h>
*               FL64 Index_Interpolation(DATESTR    *date,
*                                        PERIOD     *delay,
*                                        INDEXFAC   *fac) ;
*
*    general    The function performs interpolation in a list of index
*               factors according to various conventions.
*
*               Any adjustment for businessdays must be performed
*               prior to calling this function.
*
*               If the actual date is prior to the first date in the
*               index factor list, then the first index factor is
*               returned.
*
*               If the actual date is later than the last date in the
*               index factor list, then the last index factor is
*               returned.
*
*               Often index factor are published with a certain delay,
*               ie. the latest known index factors often correspond to
*               a period in the past. If this is so the argument delay
*               can be used to specify the delay.
*
*    input      DATESTR   *date   The date for which a index factor
*                                 is sought
*
*               PERIOD    *delay  The delay period
*
*               INDEXFAC  *fac    List of index factors
*
*    output
*
*    returns    The interpolated index factor relative to baseidx.
*               I.e. if index factor is 120 and baseidx is 100, 1.2
*               is returned
*               If date is before the
*               first index factor date, the first index factor is
*               returned. If date is later than the last index factor
*               date, the last index factor is returned.
*
*    diagnostics
*
*    see also
*
*    wrapper    AP
*
*************************************************************************
,,EOH,,*/

FL64 Index_Interpolation(DATESTR*  date, PERIOD*  delay, INDEXFAC*  fac)
{
    DATESTR     delaydate ;
    FL64        idx, base ;
    HOLI_STR    holi ;
    PERIOD      delayper ;
    BOOLE       rounding ;

    base = (fac->baseidx < IDXTOL ? 1.0 : fac->baseidx) ; 
    /* If there are no index factors, then 1 is returned */
    if (GetPlanFill(fac->idxfac) == 0)
        return 1.0 ;
    
    /* Initialise */
    holi = Set_HOLI_STR(NO_BUSADJUST, 0, NULL) ;
    rounding = fac->round ;

    /* Change sign */
    delayper  = Set_PERIOD(-delay->num, delay->unit) ;
    delaydate = Cldr_AddPeriod(date, &delayper, fac->cal, SAME, &holi) ;

    /* Look up */
	idx = Cldr_Plan_Intpol(&delaydate, fac->idxfac, fac->cal, LINEAR_FLAT_END, &holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */

    if (rounding == True)
        idx = Math_Round(idx, fac->roundOff) ;
    
    idx /= base ;

    if (idx < IDXTOL)
        idx = fac->baseidx ;


    return idx ;
}


/*,,SOH,,
*************************************************************************
*
*               Free_INDEXBOND()
*
*    interface  #include <idxbond.h>
*               void Free_INDEXBOND(INDEXBOND *idxbond) ;
*
*    general    Free_INDEXBOND() frees memory for a INDEXBOND. All the memory
*               is suballocated in the idxbond structure.
*
*    input      INDEXBOND     *idxbond       The bond data container
*
*    output
*
*    returns
*
*    diagnostics
*
*    see also
*
*************************************************************************
,,EOH,,*/

void Free_INDEXBOND(INDEXBOND *idxbond)
{
  Free_FIXPAY(&idxbond->fixp) ;
}


/*,,SOH,,
*************************************************************************
*
*               Free_INDEXLOAN()
*
*    interface  #include <idxbond.h>
*               void Free_INDEXLOAN(INDEXLOAN *idxloan) ;
*
*    general    Free_INDEXLOAN() frees memory for a INDEXLOAN. All the memory
*               is suballocated in the idxloan structure.
*
*    input      INDEXLOAN     *idxloan       The bond data container
*
*    output
*
*    returns
*
*    diagnostics
*
*    see also
*
*************************************************************************
,,EOH,,*/

void Free_INDEXLOAN(INDEXLOAN *idxloan)
{
  Free_EXRULE(&idxloan->exc) ;
}

/*,,SOH,,
*************************************************************************
*
*               Free_INDEXFAC()
*
*    interface  #include <idxbond.h>
*               void Free_INDEXFAC(INDEXFAC *idxfac) ;
*
*    general    Free_INDEXFAC() frees memory for a INDEXFAC. All the memory
*               is suballocated in the idxfac structure.
*
*    input      INDEXFAC     *idxfac       The index container
*
*    output
*
*    returns
*
*    diagnostics
*
*    see also
*
*************************************************************************
,,EOH,,*/

void Free_INDEXFAC(INDEXFAC *idxfac)
{
  Free_PLANARRAY(idxfac->idxfac ,1) ;
}


/*,,SOH,,
************************************************************************
*
*            Index_FlatIndex()
*
*  interface #include <idxbond.h>
*            void Index_FlatIndex(FL64 inflation,
*                                 INDEXFAC *idxfac) ;
*
*  general   Generate an INDEXFAC describing a flat inflation annually
*            compounded with entries on the dates in the input
*            idxfac->idxfac.
*
*  input     FL64     inflation The annually compounded inflation as a
*                               percentage (i.e. 4.0 for 4%)
*
*	       	  HOLI_STR    *hol	  Container for list of holidays.
*
*  inout     INDEXFAC *idxfac   Should contain non-plan members when
*                               calling this function. Calendar and
*                               baseidx are observed. Note that the dates
*                               in idxfac->idxfac are used as the dates
*                               the index are quoted on, so these must
*                               be allocated
*
*  returns
*
************************************************************************
,,EOH,,*/


void Index_FlatIndex(FL64 inflation,
                     INDEXFAC *idxfac,
					 HOLI_STR *holi)
{
  PLANARRAY theidx ;
  INTI i;
  FL64 term ;

  /* use local reference for readability*/
  theidx = idxfac->idxfac ;

  if (theidx->filled > 0)
  {
      theidx->f64[0] = idxfac->baseidx ;
      for (i=1; i<theidx->filled; i++)
      {
          term = Cldr_TermBetweenDates(&theidx->day[i-1], &theidx->day[i],
                                       0,idxfac->cal,SAME, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
          theidx->f64[i] = theidx->f64[i-1]*pow(1+inflation/100.0,term) ;
      }
  }

}


/*
Private functions
*/


PAYDAYDEF INDEXLOAN_Set_PAYDAYDEF(INDEXLOAN*  idxloan)
{
    INTI        months ;  
    PAYDAYDEF   pday ;
    PAYDAYSEQ   pseq ;
    
    /* Generate paydays */
    months = Cflw_MonthsBetweenPayments(idxloan->freq) ;
    pseq   = Set_PAYDAYSEQ(months, MONTHS, NOODD, NOODD, ANCHOR, SAME) ;
    pday   = Set_PAYDAYDEF(True, &idxloan->first_coupon, NULL, &idxloan->last,
                           False, &pseq, 0, NULL) ;

    return pday ;
}


/*
************************************************************************
*
*            IndexBond_StartIndex()
*
*  interface #include <idxbond.h>
*            FL64 IndexBond_StartIndex(INDEXBOND *idxbond,
*                                      INDEXFAC *idxfac) ;
*
*  general   The function finds the index factor relative to which
*            notional is scaled. When idxbond->indextobase is True
*            this is 1.0, when idxbond->indextobase = False this is
*            either the index on effective date of the bond or
*            - if irregular payments are specified - the index on
*            the first irregular paydate.
*
*  input     INDEXBOND *idxbond    The bond in question
*
*            INDEXFAC  *idxfac     The index to interpolate in
*            
*  output    
*
*  
*  returns   The indexfactor on the paydate preceding analys. If
*            analys is before first paydate, the
*            index on effective is returned.
*
*  diagnostics
*
*  see also
*
*
************************************************************************
*/


FL64 IndexBond_StartIndex(INDEXBOND *idxbond,
                          INDEXFAC *idxfac)
{

    DATESTR startdate ;
    FL64 startindex ;

    if (!idxbond->indexednotional) return 1.0 ;

    if (idxbond->fixp.repay.type == NONREGULAR &&
        GetPlanFill(idxbond->fixp.repay.irreg) > 0)
        startdate = idxbond->fixp.repay.irreg->day[0] ;
    else
        startdate = idxbond->fixp.fix.effective ;

    startindex = Index_Interpolation(&startdate,
                                     &idxbond->cflw_delay, idxfac) ;

    return startindex ;
    
}


/*
************************************************************************
*
*            IndexBond_RemainingNotional()
*
*  interface #include <idxbond.h>
*            FL64 IndexBond_RemainingNotional(DATESTR *analys,
*                                             INDEXBOND *idxbond,
*                                             HOLI_STR *holi) ;
*
*  general   computes the notional remaining on analys
*
*  input     DATESTR   *analys  The date after which notional is sought
*
*            INDEXBOND *idxbond The bond analysed
*
*            HOLI_STR  *holi    Businessday setup
*
*  output
*
*  returns   notional at analys as described
*
*  see also
*
*
************************************************************************
*/

FL64 IndexBond_RemainingNotional(DATESTR *analys,
                            INDEXBOND *idxbond,
                            HOLI_STR *holi)
{
    CFLWARRAY cflw ;
    INTI i, n ;
    FL64 notional ;

    cflw = Cflw_GenrCflw(&idxbond->fixp.repay, &idxbond->fixp.rday,
                  &idxbond->fixp.fix, &idxbond->fixp.cday, holi) ;


    n = Cldr_FindDateIndex(cflw->days, cflw->filled, analys,
                       0,SEARCH_BISECTION, NEXTINDEX) ;

    notional = 100.0 ;
    for (i = 0; i<n && i<cflw->filled; i++)
      notional -= cflw->repay[i] ;

   Free_CFLWARRAY(cflw, 1) ;

   return notional ;

}

/*
************************************************************************
*
*            Index_ShockIndex()
*
*  interface #include <idxbond.h>
*            INDEXFAC Index_ShockIndex(INDEXFAC *idxfac,
*                                      FL64 shock) ;
*
*  general   Computes a new indexstructure
*            where a parallel shock to annual inflation has been
*            applied
*
*  input     INDEXFAC idxfac The index to be shocked
*
*            FL64     shock  The inflation shock (annually compounded
*                            inflation) shock may be positive or negative.
*                            If shock = 0 a default positive shock
*                            of 1 basis point is used
*
*	       	 HOLI_STR    *hol	  Container for list of holidays.
*
*  returns   The functions returns a shocked INDEXFAC with the same
*            number
*            of index dates as the input.
*
*
*
************************************************************************
*/


INDEXFAC Index_ShockIndex(INDEXFAC *idxfac,
                          FL64 shock, HOLI_STR* holi)
{
    PLANARRAY idisc ;
    DISCFAC e,se ; /*equivalent discounting structure before/after shock*/
    INDEXFAC si ; /*shocked index*/
    RISKSET risk ;
    INTI i ;
    FL64 fac ;

    /*
    From the index structure (i.e. growthfactors)
    we generate a discount struture so we can use existing
    disc shocking code
    */

    idisc = Alloc_PLANARRAY(1,idxfac->idxfac->filled) ;
    idisc->filled = idisc->count ;
    for (i = 0; i<idisc->count; i++)
    {
        idisc->day[i] = idxfac->idxfac->day[i] ;
        idisc->f64[i] = SafeDivide(idxfac->idxfac->f64[0],
                                      idxfac->idxfac->f64[i],
                                      IDXTOL,
                                      1) ;
    }

    /* Set other disc members and use a std risk setting*/
    /*  HFI-PMSTA-36650-190729  This call looks like a big BUG : two parameters have teh wrong datatype.    */
    /*  We choose not to correct the root cause as we do not know the aim of such a code                    */
    e = Set_DISCFAC(idisc, DISCIPOL_WRONG_VALUE_7 /*KEY_DF*/, LINEAR_FLAT_END,
                    ACTACT, (IRRCONV) idxfac->cal, ANNUALLY) ;

    risk = Set_RISKSET(KEY_DF, FIRST_ORDER, SCecon_fabs(shock),
                       COMPOUND, ANNUALLY, NULL, True) ;

    /* Shock using proper sign of shock*/

    fac = SafeDivide(shock, SCecon_fabs(shock), FL64TOL, 1) ;
    se = Disc_ShockRates(&e,fac,&risk, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */

    /* reconvert to growth factors
       for simplicity we reuse the allocated idisc 
       as the container for the output index structure
    */
    for (i= 0; i<idisc->count; i++)
    {
        idisc->f64[i] = idxfac->idxfac->f64[0] /
                        se.disc->f64[i] ;
    }
    si.idxfac = idisc ;
    si.cal = idxfac->cal ;
    si.baseidx = idxfac->baseidx ;
    si.round = idxfac->round ;
    si.roundOff = idxfac->roundOff ;

    /* Free */

    Free_DISCFAC(&se) ;

    return si ;

}


/*
************************************************************************
*
*            Index_PrepIndex()
*
*  interface #include <idxbond.h>
*            INDEXFAC Index_PrepIndex(INDEXFAC *idxfac) ;
*
*  general   Implements NULL safety for indexing structures if idxfac
*            points to something this is returned. If idxfac is NULL *
*            an empty INDEXFAC is returned, which in turn is
*            interpreted in Index_Interpolation as a flat index
*            structure, i.e. no inflation.
*
*  input     INDEXFAC *idxfac      A pointer to the possibly
*                                  nonexistent index (NULL)
*
*  returns   A zero inflation index structure
*
************************************************************************
*/


INDEXFAC Index_PrepIndex(INDEXFAC *idxfac)
{
    INDEXFAC newidxfac ;

    /* Null forces a no-inflation return from Index_Interpolation*/
    newidxfac.idxfac = NULL ;
    newidxfac.baseidx = 100 ;
    
    /* if idxfac points to something maintain integrity
      by setting output to point to the same thing*/
    if (idxfac != NULL)
    {
        newidxfac = *idxfac ;
    }

    return newidxfac ;
}



/* std. Newton Raphson data setup as documented
   in main/newton.c and main/scmath.h*/

void Index_SetINDEXLOANINT(DATESTR      *analys,
                        INDEXLOAN    *idxloan,
                        INDEXFAC     *idxfac,
                        DISCFAC      *df,
                        HOLI_STR     *holi,
                        DFSPREAD     *dfs,
                        FL64         shock,
                        FL64         pwfac,
                        BOOLE        indexadj,
                        FL64         p,
                        INDEXLOANINT     *ii)
{
    ii->analys = analys ;
    ii->idxloan = idxloan ;
    ii->idxfac = idxfac ;
    ii->df = df ;
    ii->holi = holi ;
    ii->dfs = dfs ;
    ii->shock = shock ;
    ii->pwfac = pwfac ;
    ii->indexadj = indexadj ;
    ii->p = p ;
}


void Index_GetINDEXLOANINT(DATESTR      **analys,
                        INDEXLOAN    **idxloan,
                        INDEXFAC     **idxfac,
                        DISCFAC      **df,
                        HOLI_STR     **holi,
                        DFSPREAD     **dfs,
                        FL64         *shock,
                        FL64         *pwfac,
                        BOOLE        *indexadj,
                        FL64         *p,
                        INDEXLOANINT     *ii)
{
    *analys = ii->analys ;
    *idxloan = ii->idxloan ;
    *idxfac = ii->idxfac ;
    *df = ii->df ;
    *holi = ii->holi ;
    *dfs = ii->dfs ;
    *shock = ii->shock ;
    *pwfac = ii->pwfac ;
    *indexadj = ii->indexadj ;
    *p = ii->p ;
}

void Index_SetINDEXBONDINT(INDEXBOND    *idxbond,
                        TRADEINFO    *trade,
                        INDEXFAC     *idxfac,
                        DISCFAC      *df,
                        HOLI_STR     *holi,
                        DFSPREAD     *dfs,
                        FL64         shock,
                        BOOLE        indexadj,
                        INDEXBONDINT     *ii)
{
    ii->idxbond = idxbond ;
    ii->trade = trade ;
    ii->idxfac = idxfac ;
    ii->df = df ;
    ii->holi = holi ;
    ii->dfs = dfs ;
    ii->shock = shock ;
    ii->indexadj = indexadj ;
}


void Index_GetINDEXBONDINT(INDEXBOND    **idxbond,
                        TRADEINFO    **trade ,
                        INDEXFAC     **idxfac,
                        DISCFAC      **df,
                        HOLI_STR     **holi,
                        DFSPREAD     **dfs,
                        FL64         *shock,
                        BOOLE        *indexadj,
                        INDEXBONDINT     *ii)
{
    *idxbond = ii->idxbond ;
    *trade =  ii->trade ;
    *idxfac = ii->idxfac ;
    *df = ii->df ;
    *holi = ii->holi ;
    *dfs = ii->dfs ;
    *shock = ii->shock ;
    *indexadj = ii->indexadj ;
}

/*
   This is a std Newton_Raphson evaluator
   for IndexLoan_DF2Price
   used in IndexLoan_DF2ImpliedInflation

   Not strictly in accordance with spec - we always compute gradient

   For a description of the Newton-Raphson setup 
   see SWI : The SCecon implementation of Newton-Raphson

*/

BOOLE IndexLoan_NewtonRaphson(FL64    x, 
                            void*   y,
                            BOOLE   grad,
                            FL64*   fx, 
                            FL64*   dfx,
							void*   hol)
{
    DATESTR       *analys ;
    INDEXLOAN     *idxloan ;
    INDEXFAC      debidxfac, *idxfac  ;
    DISCFAC       *df ;
	HOLI_STR      *holi = (HOLI_STR *)hol;
    DFSPREAD      *dfs ;
    RISKSET       risk ;
    BOOLE         indexadj ;
    FL64          p, dummy, shock, pwfac ;
    INTI          i ;


    /* Warning avoidance */
    grad = grad ;

    /* Get the data from INDEXBONDINT*/

    Index_GetINDEXLOANINT(&analys,&idxloan,&idxfac,&df,
                      &holi,&dfs,&shock, &pwfac, &indexadj,
                      &p, (INDEXLOANINT*) y) ;

    /* compute f(x) and f'(x) in one go */

    debidxfac = *idxfac ;
    debidxfac.idxfac = Alloc_PLANARRAY(1,idxfac->idxfac->filled) ;
    for (i= 0; i<idxfac->idxfac->filled; i++)
      debidxfac.idxfac->day[i] = idxfac->idxfac->day[i] ;
    debidxfac.idxfac->filled = idxfac->idxfac->filled ;

	/* PMSTA-22396 - SRIDHARA � 160502 */
    Index_FlatIndex(x, idxfac, holi) ;
    Index_FlatIndex(x * pwfac, &debidxfac, holi) ;

    
    /* Shock  must be a basis point or more and positive */ 

    shock = (shock<0.01 ? 0.01 : shock) ;
    risk = Set_RISKSET(KEY_INDEX, FIRST_ORDER, shock,
                       COMPOUND, ANNUALLY, NULL, True) ;

    *fx = IndexLoan_DF2Price(analys, idxloan, &debidxfac, idxfac,
                            df, holi, dfs, &risk, indexadj, dfx, &dummy) - p ;

    Free_INDEXFAC(&debidxfac) ;

    return True ;

}


BOOLE IndexBond_NewtonRaphson(FL64    x, 
                            void*   y,
                            BOOLE   grad,
                            FL64*   fx, 
                            FL64*   dfx,
							void*   hol)
{

    INDEXBOND     *idxbond ;
    TRADEINFO     *trade ;
    INDEXFAC      *idxfac  ;
    DISCFAC       *df ;
	HOLI_STR      *holi = (HOLI_STR  *)hol;
    DFSPREAD      *dfs ;
    RISKSET       risk ;
    BOOLE         indexadj ;
    FL64          dummy, shock ;


    /* Warning avoidance */
    grad = grad ;

    /* Get the data from INDEXBONDINT*/

    Index_GetINDEXBONDINT(&idxbond,&trade, &idxfac,&df,
                      &holi,&dfs,&shock, &indexadj, (INDEXBONDINT*) y) ;

    /* Shock  must be a basis point or more and positive */ 

    shock = (shock<0.01 ? 0.01 : shock) ;

    /* compute f(x) and f'(x) in one go */

    Index_FlatIndex(x, idxfac, holi) ;   	/* PMSTA-22396 - SRIDHARA � 160502 */


    risk = Set_RISKSET(KEY_INDEX, FIRST_ORDER, shock,
                       COMPOUND, ANNUALLY, NULL, True) ;

    *fx = IndexBond_DF2Price(trade, idxbond, idxfac,
                             df, holi, dfs, &risk, indexadj,
                             dfx, &dummy) - trade->price ;


    return True ;

}



/*
************************************************************************
*
*            IndexLoan_GenrIndexBond()
*
*  interface #include <idxbond.h>
*            void IndexLoan_GenrIndexBond(INDEXLOAN *idxloan,
*                                         DATESTR *analys,
*                                         INDEXBOND *idxbond,
*                                         TRADEINFO *basis) ;
*
*  general   Generates an INDEXBOND descrbing an AI, I or SI loan from
*            an INDEXLOAN structure as required by IndexLoan_GenrCflw()
*            since notional is important for these functions we also
*            set a TRADEINFO struct.
*            We define SI and I loans as simple indexed SERIAL_PCT
*            bonds The user should have set the delay in repayment
*            characterising SI bonds.
*
*  input     INDEXLOAN *idxloan The loan to be defined as bond
*
*            DATESTR   *analys  Valuation day
*
*  output    INDEXBOND *idxbond The bond definition
*
*            TRADEINFO *basis   And trading information - including
*                               valuation day.
*
*  returns
*
*
************************************************************************
*/

void IndexLoan_GenrIndexBond(INDEXLOAN *idxloan,
               DATESTR   *analys,
               INDEXBOND *idxbond,
               TRADEINFO *basis)
{
  EXTRADE ext ;
  HOLI_STR holi ;
  INTI nredemptions, qbas, nextdate ;
  DATEARRAY rdays ;




  /*Initialise*/

  holi = Set_HOLI_STR(NO_BUSADJUST, 0 , NULL) ;
  
  /* INDEXLOANS are simple with the exception of the repayment */

    idxbond->fixp = Bond_Simple2FIXPAY(&idxloan->effective,
                                       NULL, &idxloan->last,
                                       idxloan->coupon, idxloan->freq,
                                       BULLET, &idxloan->exc, NULL,
                                       idxloan->cal, SAME) ;

  /* Now fix the repayment schedule */
  
  /* fix delayed amortisation*/

  /* First original bond definition*/
  idxbond->fixp.rday.first = idxloan->first_amort ;
  
  rdays = Cflw_Paydays(&idxbond->fixp.rday, &holi, &nredemptions) ;

  nextdate = Cldr_FindDateIndex(rdays, nredemptions, 
                         analys, 0, SEARCH_BISECTION, NEXTINDEX) ;
  
  if (nextdate == nredemptions)
      idxbond->fixp.rday.first = idxloan->last ;
  else
      idxbond->fixp.rday.first  = rdays[nextdate] ;
  
  Free_DATEARRAY(rdays) ;

  /* Compute the number of paydays*/

  nredemptions = Cflw_PaydaysCount(&idxbond->fixp.rday,&holi) ;

  qbas = disc_set_qbas(idxloan->freq) ;

  if (idxloan->iltype == SI || idxloan->iltype == I)
  {
    idxbond->fixp.repay.type = SERIAL_PCT ;
    idxbond->fixp.repay.rpct_first = 0.0 ;
    idxbond->fixp.repay.rpct = 100.0/ (FL64) nredemptions ;
  }
  else /* AI loans - Even coupons*/
  {
    idxbond->fixp.repay.type = ANNUITY_PCT ;
    idxbond->fixp.repay.rpct_first = 0.0 ;
    idxbond->fixp.repay.rpct = Cflw_Annuity((idxloan->coupon / (FL64) qbas),
                                            nredemptions, False ) ;
  }

  /* Done setting fixp - now set TRADEINFO*/

  /* Dont use EXTRADE in TRADEINFO*/
  
  ext.spec = ext.ex_fix = False ;

  /* We're doing creditor cashflows so notional is coutstand */

  *basis = Set_TRADEINFO(analys,analys,analys,False,
                         idxloan->coutstand,idxloan->coutstand,&ext,&ext) ;

}

/* SCID @(#)swap.c	1.5 (SimCorp) 99/02/19 14:12:29 */

/************************************************************************
*
*       project         SCecon Library
*
*       file name       swap.c
*
*       contains        fixed leg functions for swap calculations
*
************************************************************************/

/*** includes **********************************************************/
#include <swap.h>


/*** defines  **********************************************************/
#define FIXRATE_ACC       0.00000001


/*,,SOH,,
*************************************************************************
*
*              SwapFix_GenrCflw()
*
*    interface #include <swap.h>
*              CFLWARRAY SwapFix_GenrCflw(SWAPFIX     *sfix,
*                                          HOLI_STR    *holi) ;
*
*    general   This function generates cash flow for the fixed leg of
*              an interest swap according to a number of conventions
*              specified.
*
*    input     SWAPFIX    *sfix     The fixed leg definition
*
*              HOLI_STR   *holi     Business day adjustment setup
*
*    output
*
*    returns   Pointer to the cashflow allocated as:
*              Alloc_CFLWARRAY(1, x), where x is sufficiently large
*
*    diagnostics
*
*    see also  SwapFix_GenrCoupons()
*              SwapFl_GenrCflw()
*              SwapFix_DF2Rate()
*
*    wrapper   AP
*
*************************************************************************
,,EOH,,*/


CFLWARRAY SwapFix_GenrCflw(SWAPFIX*  sfix,
                            HOLI_STR*    holi)
{
    INTI       na, i, i0 ;
    CFLWARRAY  cflw ;
    PLAN_STR   *old, *plana ;

    na = GetPlanFill(sfix->repay.irreg) ;

    /* Generate the appropriate cashflow */
    if (sfix->repay.type == NONREGULAR && na == 0 && sfix->repay.io == False)
    {
        /* Simulate a bullet structure */
        plana           = Alloc_PLANARRAY(1, 1) ;
        plana[0].filled = 1 ;
        plana[0].f64[0] = 100.0 ;
        plana[0].day[0] = sfix->pday.last ;

        old = sfix->repay.irreg ;
        sfix->repay.irreg = plana ;

        cflw = Cflw_GenrCflw(&sfix->repay, &sfix->rday, &sfix->fix,
                              &sfix->pday, holi) ;

        Free_PLANARRAY(plana, 1) ;
        sfix->repay.irreg = old ;
    }
    else
        cflw = Cflw_GenrCflw(&sfix->repay, &sfix->rday, &sfix->fix,
                              &sfix->pday, holi) ;

    /* Adjust for specialities.
       Note that initial exchange is NOT delayed */
    if (sfix->delay)
    {
        i0 = 0 ;
        if (fabs(sfix->repay.init_exch) > FIXRATE_ACC)
            i0 = 1 ;

        if (holi->bus != NO_BUSADJUST)
        {
            for (i = i0 ; i < cflw->filled ; i++)
                cflw->days[i] = Cldr_AddBusinessdays(&cflw->days[i],
                                                     (INTL) sfix->delay,
                                                     holi->nholi,
                                                     holi->holidays);
        }
        else
        {
            for (i = i0 ; i < cflw->filled ; i++)
                cflw->days[i] = Cldr_AddDays(&cflw->days[i], (INTL) sfix->delay,
                                             sfix->fix.cal, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
        }
    }

    return cflw ;
}


/*,,SOH,,
*************************************************************************
*
*              SwapFix_GenrCoupons()
*
*    interface #include <swap.h>
*              FL64ARRAY SwapFix_GenrCoupons(FIXRATE     *fix,
*                                             PLAN_STR    *amort,
*                                             DATEARRAY   cdays,
*                                             INTI        nc,
*                                             PAYDAYSEQ   *pseq) ;
*
*    general   This function generates coupons for the fixed leg of
*              an interest swap according to a number of conventions
*              specified.
*
*              The routine is equivalent to Cflw_GenrCoupons()
*
*              In this function the coupon dates are assumed provided
*              from somewhere else, and the associated coupons are
*              calculated. This allows for non regularly paying swaps,
*              as opposed to SwapFix_GenrCflw() where a regular
*              pay schedule is assumed.
*
*              Also it is here assumed that adjustment for businessdays
*              has already been performed.
*
*    input     FIXRATE     *fix     The data needed for coupon calcula-
*                                   tion.
*
*              PLAN_STR    *amort   Array of prescheduled amortizations.*
*                                   Note, that days does not contain
*                                   the date for any initial exchange.
*                                   If this is required, it must be
*                                   handled elsewhere.
*                                   The amortizations must sum to 100.
*
*              DATEARRAY   cdays    Array of coupon paydays.
*
*              INTI        nc       No. of elements in cdays.
*
*              PAYDAYSEQ   *pseq    The payday sequencing.
*
*	       	   HOLI_STR    *hol	    Container for list of holidays.
*
*    output
*
*    returns   The coupon stream allocated in this routine as:
*
*                          Alloc_FL64ARRAY(nc) ;
*
*    diagnostics
*
*    see also  SwapFix_GenrCflw()
*              SwapFl_GenrCflw()
*              SwapFix_DF2Rate()
*
*************************************************************************
,,EOH,,*/


FL64ARRAY SwapFix_GenrCoupons(FIXRATE* fix,
                       PLAN_STR*  amort,
                       DATEARRAY cdays,
                       INTI      nc,
                       PAYDAYSEQ* pseq,
					   HOLI_STR* holi)
{
    return Cflw_GenrCoupons(fix, amort, cdays, nc, NULL, pseq, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
}




/*,,SOH,,
*************************************************************************
*
*               Free_SWAPFIX()
*
*    interface  #include <swap.h>
*               void Free_SWAPFIX(SWAPFIX *x) ;
*
*    general    Free_SWAPFIX() frees memory for a SWAPFIX. All the
*               memory is suballocated in the x structure.
*
*    input      SWAPFIX     *x       The fixed leg data container
*
*    output
*
*    returns
*
*    diagnostics
*
*    see also
*
*************************************************************************
,,EOH,,*/


void Free_SWAPFIX(SWAPFIX* x)
{
    /* Free all suballocated memory */
    Free_PAYDAYDEF(&x->rday);
    Free_PAYDAYDEF(&x->pday);
    Free_PLANARRAY(x->fix.stepcoup, 1) ;
    Free_PLANARRAY(x->fix.irreg, 1) ;
    Free_PLANARRAY(x->repay.aufab, 1) ;
    Free_PLANARRAY(x->repay.irreg, 1) ;
    Free_PLANARRAY(x->repay.pp.ppmts, 1) ;
}

/*
..
*/

/*,,SOH,,
************************************************************************
*
*                Set_SWAPFIX()
*
*   interface    #include <swap.h>
*                SWAPFIX Set_SWAPFIX(REPAYMNT*  repay,
*                                    PAYDAYDEF* rday,
*                                    FIXRATE*   fix,
*                                    PAYDAYDEF* pday,
*                                    INTI       delay) ;
*
*   general      This routine sets the members of the struct defined
*                in the function name. The pointer members are simply
*                assigned - without physical copying. The intention
*                of the Set_*() routines is that by using this
*                functionality, one avoids setting individual members
*                of structs in the application code.
*
*                When new members are inserted in structs the Set_*()
*                routine will be changed accordingly.
*
*                One exception to this principle applies. Whenever
*                OPTADD and vanilla members are used, only the
*                vanilla members are set in the Set_*() routines. The
*                non-vanilla and exotic members are set to defaults,
*                and must be set elsewhere - if needed.
*
*                For details on the interpretation of the individual
*                struct members please check the struct definition.
*
*   input        REPAYMNT*  repay See general section.
*                                 Use NULL for defaults
*
*                PAYDAYDEF* rday  See general section.
*                                 Use NULL for defaults
*
*                FIXRATE*   fix   See general section.
*
*                PAYDAYDEF* pday  See general section.
*
*                INTI       delay See general section.
*
*   output
*
*   returns      The filled out SWAPFIX struct
*
*   diagnostics
*
*   see also     SWAPFIX
*
************************************************************************
,,EOH,,*/

SWAPFIX Set_SWAPFIX(REPAYMNT* repay, PAYDAYDEF* rday,
                       FIXRATE* fix, PAYDAYDEF* pday, INTI delay)
{
    SWAPFIX sfix ;

    if (repay != NULL)
        sfix.repay = *repay ;
    else
        sfix.repay = Set_REPAYMNT(BULLET, NULL, False, 0.0, NULL,
                                  NULL, NULL, 0.0, 0.0) ;

    if (rday != NULL)
        sfix.rday  = *rday ;
    else
        sfix.rday = *pday ;

    sfix.fix   = *fix ;
    sfix.pday  = *pday ;
    sfix.delay = delay ;

    return sfix ;
}


/*,,SOH,,
*************************************************************************
*
*               SwapFix_Simple2SWAPFIX()
*
*    interface  #include <swap.h>
*               SWAPFIX SwapFix_Simple2SWAPFIX(DATESTR* effect,
*                                              PERIOD*  tenor,
*                                              PMTFREQ  freq,
*                                              FL64     rate,
*                                              CALCONV  cal,
*                                              EOMCONV  eom) ;
*
*    general    The routine generates a SWAPFIX based on simple data.
*
*    input      DATESTR  *effect  The accrual start date
*
*               PERIOD   *tenor   The total swap term (i.e 5Y)
*
*               PMTFREQ  freq     The fixed roll (e.g. semiann)
*
*               FL64     rate     The swaprate
*
*               CALCONV  cal      The daycount method
*
*               EOMCONV  eom      Month end adjustment
*
*    output
*
*    returns    The SWAPFIX data type
*
*    diagnostics
*
*    see also
*
*************************************************************************
,,EOH,,*/

SWAPFIX SwapFix_Simple2SWAPFIX(DATESTR* effect,
                                  PERIOD*  tenor,
                                  PMTFREQ  freq,
                                  FL64     rate,
                                  CALCONV  cal,
                                  EOMCONV  eom)
{
    SWAPFIX   sfix ;
    PAYDAYDEF pday ;
    PAYDAYSEQ pseq ;
    INTI      mon ;
    HOLI_STR  holi ;
    FIXRATE   fix ;
    DATESTR   matur ;

    holi  = Set_HOLI_STR(NO_BUSADJUST, 0, NULL) ;
    mon   = Cflw_MonthsBetweenPayments(freq) ;
    matur = Cldr_AddPeriod(effect, tenor, cal, eom, &holi) ;
    pseq  = Set_PAYDAYSEQ(mon, MONTHS, NOODD,  NOODD, ANCHOR, eom) ;
    pday  = Set_PAYDAYDEF(False, effect, NULL, &matur, False, &pseq,
                          0, NULL) ;
    fix   = Set_FIXRATE(rate, cal, effect, NULL, 0.0, ODDCOUP, ODDCOUP,
                        False, False, NULL, True, NULL, NODCOMP) ;
    sfix  = Set_SWAPFIX(NULL, NULL, &fix, &pday, 0) ;

    return sfix ;
}


/*
*************************************************************************
*
*              Swap_DF2NPV()
*
*    interface #include <swap.h>
*              FL64 Swap_DF2NPV(DATESTR    *analys,
*                               CFLW_STR   *cflw,
*                               BOOLE      ignore,
*                               DISCFAC    *df) ;
*
*    general   This function generates the NPV of a swap leg according
*              to the discount function and the cashflow - fixed or
*              floating.
*
*              The NPV is computed on the analysis date.
*
*              All payments between analys and the first date in df are
*              IGNORED.
*
*    input     DATESTR    *analys   Pointer to analysis date.
*
*              CFLW_STR   *cflw     The cashflow with cflw->filled
*                                   payments.
*
*              BOOLE      ignore    True if payments on analys are
*                                   ignored, False otherwise.
*
*              DISCFAC    *df       The discount function setup.
*	       	   HOLI_STR   *holi	    Container for list of holidays.
*
*    output
*
*    returns   NPV of the leg.
*
*    diagnostics
*
*    see also  SwapFix_GenrCflw()
*              SwapFl_GenrCflw()
*
*************************************************************************
*/

FL64 Swap_DF2NPV(DATESTR* analys, CFLW_STR* cflw, 
                    BOOLE  ignore, DISCFAC* df, HOLI_STR* holi)
{
    FL64 npv ;

    npv = Disc_DF2NPV(analys, cflw->days, cflw->coupon, cflw->repay,
                      cflw->filled, df, NULL, ignore, NULL,  holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */

    return npv ;
}



#undef FIXRATE_ACC

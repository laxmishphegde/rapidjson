/* SCID @(#)cf_gener.c	1.16 (SimCorp) 99/11/08 13:41:47 */

/************************************************************************
*
*       Project         SCecon
*
*       file name       cf_gener.c
*
*       contains        the standard SimCorp cash flow generator,
*
************************************************************************/

/*** includes **********************************************************/
#include <cflw.h>

/*** defines ***********************************************************/
#define PRICE_TOL   0.000001


/*,,SOH,,
*************************************************************************
*
*              Cflw_GenrCflw()
*
*    interface #include <cflw.h>
*              CFLWARRAY Cflw_GenrCflw(REPAYMNT    *redemp,
*                                       PAYDAYDEF   *rday,
*                                       FIXRATE     *fix,
*                                       PAYDAYDEF   *cday,
*                                       HOLI_STR    *holi) ;
*
*    general   This function generates cash flow for bonds from issue
*              to maturity.
*
*              The bonds can have a number of features :
*
*                 - Odd first and/or last coupon periods.
*                 - Odd first and/or last repay periods.
*                 - Chained, anchored or IMM payday schemes
*                 - Irregular repayment schedules.
*                 - Partly paid issue.
*                 - The coupon days and the repay days need
*                   not coincide.
*                 - Interest rate adjustments at any time
*                   between interest rate start and maturity,
*                   and not necessarily known for the whole
*                   life.
*                   This includes annuities with rate adjustments
*                   as known in Scandinavia.
*                 - Theoretical maturity later than the actual
*                   maturity, ie. balloons.
*                 - Interest accrual start differing from issue
*                   date.
*                 - Dates are moved according to business conventions
*                   to business days before interest calculation.
*                   This allows for the implementation of fixed-leg
*                   swap calculations.
*                 - The amortisation or coupon days can be complete
*                   irregular
*                 - Zeros
*                 - Interest only
*                 - Initial exchange
*
*                 ....etc
*
*    input     REPAYMNT   *redemp    The data describing the repayments
*
*              PAYDAYDEF  *rday      The conventions for generating the
*                                    amortisation dates.
*
*              FIXRATE     *fix      The data needed for coupon calcula-*
*                                    tion.
*
*              PAYDAYDEF  *cday      The conventions for generating the
*                                    coupon dates.
*
*              HOLI_STR  *holi       Container for data on business
*                                    day convention and non-week-end
*                                    holidays.
*
*    returns   Pointer to cashflow generated. Allocated in this routine
*              as Alloc_CFLWARRAY(1, x), where x is calculated.
*
*    diagnostics
*
*    see also  Cflw_ExtractCflw()
*              Cflw_ExtractPeriod()
*
*    wrapper   AP
*
*************************************************************************
,,EOH,,*/


CFLWARRAY Cflw_GenrCflw(REPAYMNT* redemp,
                         PAYDAYDEF*   rday,
                         FIXRATE*     fix,
                         PAYDAYDEF*   cday,
                         HOLI_STR*    holi,
						 FL64ARRAY	  intrRate,
						 FLAG_T		  mktConvMethodEnblFlg)    /* PMSTA-42879 - SRIDHARA - 18032021 */
{
    INTI      npp, na, nc, nad, nirreg, ix, i, j ;
    INTI      ntmp, ixc, ixa, ixt, months ;
    FL64      pct, coupon, rg, tmprg, *adj ;
    FL64      storedrate ;
    FL64ARRAY repay, coupons, tmprepay, couponx ;
    DATEARRAY ppdays, tmpdays ;
    DATESTR   secl, dteomatur, *adjdays, hmatur, effold, lastold, 
              tmpday ;
    BOOLE     zero, harm ;
    BONDTYPE  repaytype ;
    PLAN_STR  plana, planc ;
    CFLWARRAY cflw ;
    HOLI_STR  xhol ;
    PAYDAYDEF xday ;
    PAYDAYSEQ xseq ;
    ODDCONV   oddN = NOODD;
    FIXRATE   tmpfix ;

    Math_LaGuerre(fix->effective.y, fix->effective.m, 
      fix->effective.d);

    /* 0.0 This case can be handled like this */
    if (fix->holpre == False)
    {
        fix->holpre = True ;

		/* PMSTA-36049 - Silpakal - 191029 */
        cflw = Cflw_GenrCflw(redemp, rday, fix, cday, holi, intrRate, mktConvMethodEnblFlg); /* PMSTA-42879 - SRIDHARA - 18032021 */

        Cldr_Move2BusinessDays(cflw->days, cflw->filled, holi) ;

        fix->holpre = False ;
        return cflw ;
    }

    /* 0.1 Initialise */
    repaytype = (fix->jgb == True ? BULLET : redemp->type) ;
    effold  = fix->effective ;
    lastold = fix->lastaccr ;

    if (Cldr_DateLT(&redemp->teomatur, &fix->effective) == True)
        dteomatur = rday->last ;
    else
        dteomatur = redemp->teomatur ;

    if (cday->pseq.seq == TAM_T4M)
    {
        fix->effective = Cflw_Snap2(&fix->effective, TAM_T4M, 
                                    cday->snap2, holi) ;
        fix->lastaccr  = Cflw_Snap2(&fix->lastaccr, TAM_T4M, 
                                    cday->snap2, holi);
        dteomatur = Cflw_Snap2(&dteomatur, TAM_T4M, cday->snap2, holi) ;
    }
 
    /* 0.2 Be careful about decompounding */
    coupon = fix->fix_rate ;
    harm   = Cflw_Is_Harmonic(cday->pseq.term, cday->pseq.unit, &months) ;
    coupon = Cflw_Decompound(coupon, months, harm, fix->decomp, 
                             NULL, NULL, fix->cal, holi) ;  /* PMSTA-22396 - SRIDHARA � 160502 */

    adj     = GetPlanF64(fix->stepcoup) ;
    adjdays = GetPlanDay(fix->stepcoup) ;
    nad     = GetPlanFill(fix->stepcoup) ;
    nirreg  = GetPlanFill(fix->irreg) ;

    ppdays = GetPlanDay(redemp->pp.ppmts) ;
    npp    = GetPlanFill(redemp->pp.ppmts) ;

    /* 0.3 Business day adjustment */
    if (holi->bus != NO_BUSADJUST)
    {
        Cldr_Move2BusinessDays(adjdays, nad, holi) ;
        Cldr_Move2BusinessDays(ppdays, npp, holi) ;
    }

    /* 0.3 Is this a zero bond. */
    zero = ((fabs(coupon) < PRICE_TOL && nad == 0 && nirreg == 0) ? 
        True : False) ;

    /* 1.0 + 2.0 First find the amortization days and the associated
                 repay schedule. */

    /* 1.0 Find the amortisation days. */

    tmpday     = rday->last ;
    rday->last = dteomatur ;
    plana.day  = Cflw_Paydays(rday, holi, &na) ;
    plana.filled = na ;
    rday->last = tmpday ;
    
    /* Be careful about last period for JGB's */
    if (fix->jgb == True && na > 0 &&
        Cldr_IsBusinessDate(&plana.day[na - 1], 0, NULL) == False)
    {
        xhol = Set_HOLI_STR(NEXT, 0, NULL) ;
        plana.day[na - 1] = Cldr_NextBusinessDate(&plana.day[na - 1], 
                                                  &xhol) ;
    }

    /* 2.0 Find the repayment schedule. */

    plana.f64  = Alloc_FL64ARRAY(na) ;
    repay = plana.f64 ;
    coupons = Alloc_FL64ARRAY(na) ;
    
    switch (repaytype)
    {
        case BULLET:
        case SERIAL:

            Cflw_Bondtype2Payments(0.0, NULL, na, repaytype,
                    False, repay, coupons) ;
            
            break ;

        case SERIAL_PCT:

            /* These are serials with fixed amortisation percentage */

            /* Only if repayment % is nonzero, otherwise use a regular bullet*/
            if (redemp->rpct > PRICE_TOL)
            {
                /* Generate Flow with constant repayment (Afdrags %) */
                for (rg = 100.0, i = 0; i < na; i++)
                {
                    pct      = (i == 0 &&
                                redemp->rpct_first > PRICE_TOL ?
                                redemp->rpct_first : redemp->rpct) ;
                    repay[i] = pct ;
                    rg      -= repay[i] ;
                    if (rg <= PRICE_TOL)
                    {
                        repay[i] = rg + pct ;
                        break ;
                    }
                }

                if (rg > PRICE_TOL && na > 0)
                   repay[na - 1] += rg ;
            }
            else
              Cflw_Bondtype2Payments(0.0, NULL, na, BULLET,
                      False, repay, coupons) ;

            break ;

        case ANNUITY:
        case ANNUITY_PREP:

            /* First case is annuities with stepped coupons - 
               as defined in Scandinavia.
               NOTE: These loans are NOT real annuities; they are annuities
               in the periods between the rate adjustments.
               Real annuities with stepped coupons are covered by the
               standard case below; if they are needed a new type
               ANNUITY_STEP should be defined to cover the Scandinavian 
               type. */
            if (nad > 0 && (repaytype == ANNUITY ||
                repaytype == ANNUITY_PREP) && na > 1)
            {
                tmpfix = *fix ;
                tmpfix.prepaid = False ;
                tmpfix.stepcoup = NULL ;

                /* Find latest rate adjust before first repay date */
                i = Cldr_FindDateIndex(adjdays, nad, &rday->first,
                                        0, SEARCH_FORWARDS, PREVINDEX) ;
                
                /* Coupon rate from first repay date. */
                tmpfix.fix_rate = (i < 0 ? coupon : 
                    Cflw_Decompound(adj[i], months, harm, fix->decomp,
                                    NULL, NULL, fix->cal, holi) );   /* PMSTA-22396 - SRIDHARA � 160502 */

                /* Generate annuity. */
                couponx = Cflw_GenrCouponRates(&tmpfix, plana.day, na, 
                    &rday->pseq, holi) ;  /* PMSTA-22396 - SRIDHARA � 160502 */
                Cflw_Bondtype2Payments(0.0, couponx, na, repaytype,
                    (BOOLE) repaytype == ANNUITY_PREP, repay, coupons) ;
                Free_FL64ARRAY(couponx) ;

                tmprepay  = Alloc_FL64ARRAY(na) ;

                /* Loop over rate adjustments. */
                for (i++ ; i < nad ; i++)
                {
                    /* Find repay day and coupon for next rate adjustment. */
                    ix = Cldr_FindDateIndex(plana.day, na, &adjdays[i],
                                            0, SEARCH_FORWARDS, SAMEINDEX) ;
                    tmpfix.fix_rate = Cflw_Decompound(adj[i], months, harm, 
                        fix->decomp, NULL, NULL, fix->cal, holi) ;  /* PMSTA-22396 - SRIDHARA � 160502 */

                    /* Number of repayments left. */
                    ntmp = na - ix - 1 ;
                    if (ntmp > 0 && tmpfix.fix_rate > 0.0)
                    {
                        /* Generate annuity. */
                        couponx = Cflw_GenrCouponRates(&tmpfix, plana.day, na, 
                          &rday->pseq, holi) ;  /* PMSTA-22396 - SRIDHARA � 160502 */
                        Cflw_Bondtype2Payments(0.0, couponx, na, repaytype,
                            (BOOLE) repaytype == ANNUITY_PREP, tmprepay,
                            coupons) ;
                        Free_FL64ARRAY(couponx) ;

                        /* Find ratio between outstanding of the old and new
                           annuity. */
                        for (rg = 100.0, tmprg = 100.0, j = 0 ; j <= ix ; j++)
                        {
                            rg -= repay[j] ;
                            tmprg -= tmprepay[j] ;
                        }
                        tmprg = rg / tmprg ;
                        for (j = ix + 1 ; j < na ; j++)
                            repay[j] = tmprg * tmprepay[j] ;
                    }
                    else
                      break ;
                }

                Free_FL64ARRAY(tmprepay) ;
            }
            else
            {
                /* This is the regular case */

                tmpfix = *fix;
                tmpfix.prepaid = False;

                couponx = Cflw_GenrCouponRates(&tmpfix, plana.day, na, 
                      &rday->pseq, holi) ;  /* PMSTA-22396 - SRIDHARA � 160502 */               
                Cflw_Bondtype2Payments(0.0, couponx, na, repaytype,
                    repaytype == ANNUITY_PREP, repay, coupons) ;
                Free_FL64ARRAY(couponx) ;
            
            }

            break ;

        case ANNUITY_PCT:

            /* These are annuities with fixed total payment percentage */

            /* Only if payment % is nonzero, if zero it's a zero coupon bond*/
            if (redemp->rpct > PRICE_TOL)
            {
                /* Find adjusted rates */
                tmpfix = *fix;
                couponx = Cflw_GenrCouponRates(&tmpfix, plana.day, na, 
                      &rday->pseq, holi) ;  /* PMSTA-22396 - SRIDHARA � 160502 */

                /* Generate Flow with constant TOTAL payment (Ydelses %)*/
                for (rg = 100.0, i = 0; i < na; i++)
                {
                    pct      = (i == 0 && 
                                redemp->rpct_first > PRICE_TOL ?
                                redemp->rpct_first : redemp->rpct);
                    repay[i] = pct - rg * couponx[i] / 100.0 ;
                    rg      -= repay[i] ;
                    if (rg <= PRICE_TOL)
                    {
                        repay[i] = rg + repay[i] ;
                        break ;
                    }
                }

                if (rg > PRICE_TOL && na > 0)
                   repay[na - 1] += rg ;

                Free_FL64ARRAY(couponx) ;
            }
            else
                Cflw_Bondtype2Payments(0, NULL, na, BULLET,
                    False, repay, coupons) ;

            break ;        

        case NONREGULAR:

            /* Here we already know the amortizations, but need to move
               the days to businessdays */
            Free_DATEARRAY(plana.day) ;
            Free_FL64ARRAY(plana.f64) ;

            na        = GetPlanFill(redemp->irreg) ;
            plana.day = Alloc_DATEARRAY(na) ;
            plana.f64 = Alloc_FL64ARRAY(na) ;
            plana.filled = na ;

            for (i = 0 ; i < na ; i++)
            {
                plana.f64[i] = redemp->irreg->f64[i] ;
                plana.day[i] = redemp->irreg->day[i] ;
            }

            Cldr_Move2BusinessDays(plana.day, na, holi) ;

            break ;

        default:
            ;
    }

    Free_FL64ARRAY(coupons) ;

    /* 3. Find the coupon days */
    if (zero == True)
    {
        nc = 0 ;
        planc.day = Alloc_DATEARRAY(nc) ;
        planc.filled = nc ;
    }
    else if (nirreg == 0)
    {
        /* Be careful about how JGB bond data are set */
        if (fix->jgb == True && cday->is_first == True && 
            cday->pseq.unit == MONTHS && cday->nirreg == 0)
        {
            /* Assume that last and first are set - and unit is MONTHS */
            xhol   = Set_HOLI_STR(NEXT, 0, NULL) ;
            secl   = cday->last ;
            secl.d = cday->first.d ;
            secl   = Cldr_AddMonths(&secl, -cday->pseq.term, cday->pseq.eom) ;
            hmatur = Cldr_NextBusinessDate(&cday->last, &xhol) ;
            if (hmatur.d != cday->first.d)
                oddN = LONGODD ;

            xseq = Set_PAYDAYSEQ(cday->pseq.term, cday->pseq.unit,
                                      NOODD, oddN, ANCHORBACK,
                                      cday->pseq.eom) ;
            xday = Set_PAYDAYDEF(True, &cday->first, &secl, &hmatur,
                                      False, &xseq, 0, NULL) ;

            /* Now generate days */
            planc.day    = Cflw_Paydays(&xday, holi, &nc) ;
            planc.filled = nc ;
        }
        else
        {
            /* The standard case */
            planc.day    = Cflw_Paydays(cday, holi, &nc) ;
            planc.filled = nc ;
        }
    }
    else
    {
        /* Completely irregular flow */
        planc.filled = nc = nirreg ;
        planc.day    = Alloc_DATEARRAY(nc) ;
        for (i = 0 ; i < nc ; i++)
            planc.day[i] = fix->irreg->day[i] ;
    }


    /* 5. Check for balloons (at maturity), and adjust the number of
          coupondays.
          Note that rday->last must always be entered even for irregular's */
    if (fix->jgb == False || na == 0)
    {
        hmatur = Cflw_Snap2(&rday->last, rday->pseq.seq, rday->snap2, holi) ;
        hmatur = Cldr_NextBusinessDate(&hmatur, holi) ;
    }
    else
        hmatur = plana.day[na - 1] ;

    na = Cflw_Balloon(plana.day, na, &hmatur, plana.f64) ;
    ix = Cldr_FindDateIndex(planc.day, nc, &hmatur, 0,
                             SEARCH_BISECTION, NEXTINDEX) ;

    nc = GETMAX(0, ix) ;
    plana.filled = na ;
    planc.filled = nc ;

    /* Adjust here */
    fix->lastaccr = Cldr_NextBusinessDate(&fix->lastaccr, holi) ;
    
    /* 6. Now generate the coupons */

    /* If it's an annnuity pct with zero rpct we rig
       fix->fix_rate to produce a zero coupon bond*/

    storedrate = fix->fix_rate ;
    if (repaytype==ANNUITY_PCT && redemp->rpct<=PRICE_TOL)
      fix->fix_rate = 0.0 ;

    coupons = Cflw_GenrCoupons(fix, &plana, planc.day, nc,
                                redemp->pp.ppmts, &cday->pseq, holi, intrRate, mktConvMethodEnblFlg);  /* PMSTA-22396 - SRIDHARA � 160502 */ /* PMSTA-42879 - SRIDHARA - 18032021 */

    fix->fix_rate = storedrate ;

    /* Now allocate memory for the merged cashflow */
    cflw = Alloc_CFLWARRAY(1, na + nc + 1) ;
    cflw->count = na + nc + 1 ;

    /* Merge dates and payments */
    if (redemp->io == False)
        tmpdays = Cldr_MergeDates(plana.day, na, planc.day, nc, &ntmp) ;
    else
        tmpdays = Cldr_MergeDates(plana.day, 0, planc.day, nc, &ntmp) ;

    /* Remember initial exchange */
    tmpday       = Cldr_NextBusinessDate(&fix->effective, holi) ;
    cflw->filled = ntmp ;
    ixt          = 0 ;

    if (ntmp > 0 && Cldr_DateEQ(&tmpday, &tmpdays[0]) == False &&
        fabs(redemp->init_exch) > PRICE_TOL)
        cflw->filled += 1 ;

    if (ntmp > 0 && Cldr_DateEQ(&tmpday, &tmpdays[0]) == True &&
        fabs(redemp->init_exch) > PRICE_TOL)
        ixt = 1 ;

    for (ixc = ixa = i = 0 ; i < cflw->filled ; i++)
    {
        /* Set date */
        if (i == 0 && fabs(redemp->init_exch) > PRICE_TOL)
        {
            cflw->days[0]  = tmpday ;
            cflw->repay[0] = - redemp->init_exch ;
        }
        else
            cflw->days[i] = tmpdays[ixt++] ;

        /* Set payments */
        while (ixc < nc && Cldr_DateEQ(&cflw->days[i], 
          &planc.day[ixc]) == True)
          cflw->coupon[i] += coupons[ixc++] ;

        while (ixa < na && Cldr_DateEQ(&cflw->days[i], 
          &plana.day[ixa]) == True && redemp->io == False)
            cflw->repay[i]  += plana.f64[ixa++] ;

		/* Set rate */ /* PMSTA10118 - DDV - 100628 - set the rate into cflw */
		 /* PMSTA-42879 - SRIDHARA - 18032021 */
		if (intrRate != NULL && i < nc)
			cflw->ratesTab[i] = intrRate[i];
		else
			cflw->ratesTab[i] = fix->fix_rate;
    }

    /* Clean up */
    fix->effective = effold ;
    fix->lastaccr = lastold ;

    Free_DATEARRAY(tmpdays) ;
    Free_DATEARRAY(planc.day) ;
    Free_FL64ARRAY(coupons) ;
    Free_DATEARRAY(plana.day) ;
    Free_FL64ARRAY(plana.f64) ;

    return cflw ;
}


/*
..
*/


FL64 Cflw_TermUnit2DayFrac(DATESTR* date, PAYDAYSEQ* pseq, CALCONV cal,
                           HOLI_STR* hol, DATEARRAY days, INTI na)
{
    DATESTR day ;
    BOOLE   harm ;
    FL64    frac, dpy ;
    INTI    months ;
    PERIOD  per ;

    frac = 0.0 ;
    harm = Cflw_Is_Harmonic(pseq->term, pseq->unit, &months) ;

    if (harm == True)
        frac = ((FL64) months) / 12.0 ;
    else
    {
        if (pseq->term != 0)
        {
            day  = Cldr_TermUnit2Date(date, pseq->term, pseq->unit, cal,
                                      pseq->eom, hol) ;

			/* PMSTA-22396 - SRIDHARA � 160502 */
            frac = (FL64) Cldr_DaysBetweenDates(date, &day, cal, hol) ;
            dpy  = Cldr_DaysPerYear(date, &day, 0, cal, LAST, hol) ;
            frac = frac / dpy ;
        }
        else
        {
            if (na > 1)
            {
                per  = Set_PERIOD(1, MONTHS) ;
                frac = (FL64) Cldr_PeriodsBetweenDates(&days[0], &days[1],
                                                       &per, cal,
                                                       pseq->eom, hol) ;
                frac = frac / 12.0 ;
            }
        }
    }

    return frac ;
}

#undef PRICE_TOL

/* @(#)tstscen.c	1.5 (SimCorp) 99/02/19 14:12:48 */

/************************************************************************
*
*   Project     SCecon
*
*   this program tests the routines in the scen.fcts module of SCecon
*
************************************************************************/


/*** includes ***********************************************************/
#include <string.h>
#include <stdlib.h>
#include <scalloc.h>
#include <scenario.h>
#include <str2conv.h>
#include <ioconv.h>
#include <bondio.h>

INTI scentest(char* txa, FILE* in, FILE* out)
{
    FL64       acc ;
    INTI       dexp, dif1, i, diff ;

    PMTFREQ      freq ;
    HOLI_STR     holi ;
    IRRCONV      irr ;
    DELTASET     ds ;
    PLANARRAY    plan;
    SCENARIOLIST scen ;
    DISCFAC      df ;
    FL64         fx_spot ;
    FL64ARRAY    shocks, dv, dvexp ;
    INTI         nshock, nshockexp ;
    FXSHOCKSET   fxs, expfxs ;
    DATESTR      analys, matur ;
    CFLWARRAY    xcflw;
    PP_STR       pp;
    DFSPREAD     dfs;
    BOOLE        dom, ok, okexp, adj ;
    TRADEINFO    trade;
    FIXPAY       fixp;
    DEPOSIT      depo;
    CCYCODE      ccy;
    INDEXBOND    idxbond ;
    INDEXLOAN    idxloan ;
    INDEXFAC     fac, debfac, crefac ;

    acc = 0.00001 ;
    diff = -1 ;

    if (!strcmp("Disc_ScenarioPrep()", txa))
    {
        fprintf(out,"   testing %s\n", txa) ;

        df   = Read_DISCFAC(in, out) ;
        scen = Read_SCENARIOLIST(in, out) ;
        holi = Read_HOLI_STR(in, out) ;
        irr = Read_IRRCONV(in, out, "  Shock IRR   ");
        freq = Read_PMTFREQ(in, out, "  Shock Freq  ");

        ds = Disc_ScenarioPrep(&df, &scen, &holi, irr, freq, True) ;

        diff = 0 ;

        dexp = Read_INTI(in, out, "  Exp result size ");
        if (dexp != ds.nshock)
        {
            diff = 1 ;
            for (i = 0; i < dexp; i++)
            {
                plan = Read_PLANARRAY(in) ;
                Free_PLANARRAY(plan, 1) ;
            }
        }
        else
        {
            for (i = 0; i < dexp; i++)
            {
                plan = Read_PLANARRAY(in) ;
                dif1 = Write_PlanDiff(plan, &ds.shock[i], out) ;
                diff = diff || dif1 ;
                Free_PLANARRAY(plan, 1) ;
            }
        }

        if (diff == 0)
            fprintf(out, "0; All OK\n") ;

        IOUtil_ParseLine(in, out);

        Free_PLANARRAY(df.disc, 1) ;
        Free_DELTASET(&ds) ;
        Free_DATEARRAY(holi.holidays) ;
        Free_SCENARIOLIST(&scen) ;
    }


    else if (!strcmp("FX_ShockPrep()", txa))
    {
        fprintf(out,"   testing %s\n", txa) ;

        IOUtil_ParseLine(in, out);

        Read_CCYCODE(in, out, &ccy);

        fx_spot = Read_FL64(in, out, "Fx Spot   "); 

        shocks = Read_FL64ARRAY(in, &nshock);
        Write_FL64ARRAY(out, shocks, nshock);

        expfxs = Read_FXSHOCKSET(in, out);

        fxs = FX_ShockPrep(fx_spot, shocks, nshock, &ccy) ;

        acc = Read_FL64(in, out, "Tolerance ");
        diff = Write_FXSHOCKSETDiff(&expfxs, &fxs, out, acc);

        Free_FXSHOCKSET(&expfxs);
        Free_FXSHOCKSET(&fxs);
        Free_FL64ARRAY(shocks);
    }

    else if (!strcmp("Cflw_DF2ScenBPV()", txa))
    {
        fprintf(out,"   Testing %s\n", txa) ;

        strncpy(ccy, "USD", CCY_LENGTH);
        analys = Read_DATESTR(in, out, "   analys    ");
        fx_spot = Read_FL64(in, out, "Fx Spot   "); 

        df     = Read_DISCFAC(in, out) ;
        xcflw  = Read_CFLWARRAY(in, out) ;
        pp     = Read_PP_STR(in, out) ;
        holi   = Read_HOLI_STR(in, out) ;
        dfs    = Read_DFSPREAD(in, out) ;
        scen = Read_SCENARIOLIST(in, out) ;

        shocks = Read_FL64ARRAY(in, &nshock);
        Write_FL64ARRAY(out, shocks, nshock);

        irr = Read_IRRCONV(in, out, "  Shock IRR   ");
        freq = Read_PMTFREQ(in, out, "  Shock Freq  ");
        dom = Read_BOOLE(in, out, "   Domestic  ");

        ds = Disc_ScenarioPrep(&df, &scen, &holi, irr, freq, dom) ;

        fxs = FX_ShockPrep(fx_spot, shocks, nshock, &ccy) ;

        dv = Cflw_DF2ScenBPV(&analys, &df, fx_spot, xcflw, &pp, 
          &holi, &dfs, &ds, &fxs) ;

        ok = True;
        okexp = Read_BOOLE(in, out, "  Exp status ");
        dvexp = Read_FL64ARRAY(in, &nshockexp);
        acc = Read_FL64(in, out, "Tolerance ");

        diff = WriteFL64ARRAYDiff(okexp, dvexp, nshockexp, 
            ok, dv, nshock, out, acc);

        IOUtil_ParseLine(in, out);

        Free_DATEARRAY(holi.holidays) ;
        Free_CFLWARRAY(xcflw, 1) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_DELTASET(&ds) ;
        Free_SCENARIOLIST(&scen) ;
        Free_FL64ARRAY(dv) ;
        Free_FXSHOCKSET(&fxs);
        Free_FL64ARRAY(shocks);
        Free_FL64ARRAY(dvexp);
        Free_DFSPREAD(&dfs) ;
    }

    else if (!strcmp("RepoCflw_DF2ScenBPV()", txa))
    {
        fprintf(out,"   Testing %s\n", txa) ;

        strncpy(ccy, "USD", CCY_LENGTH);
        analys = Read_DATESTR(in, out, "   analys    ");
        fx_spot = Read_FL64(in, out, "Fx Spot   "); 

        df     = Read_DISCFAC(in, out) ;

        xcflw  = Read_CFLWARRAY(in, out) ;
        matur = Read_DATESTR(in, out, "   Maturity  ");
        pp     = Read_PP_STR(in, out) ;

        holi   = Read_HOLI_STR(in, out) ;
        dfs    = Read_DFSPREAD(in, out) ;
        scen = Read_SCENARIOLIST(in, out) ;

        shocks = Read_FL64ARRAY(in, &nshock);
        Write_FL64ARRAY(out, shocks, nshock);

        irr = Read_IRRCONV(in, out, "  Shock IRR   ");
        freq = Read_PMTFREQ(in, out, "  Shock Freq  ");
        dom = Read_BOOLE(in, out, "   Domestic  ");

        ds = Disc_ScenarioPrep(&df, &scen, &holi, irr, freq, dom) ;

        fxs = FX_ShockPrep(fx_spot, shocks, nshock, &ccy) ;

          /* Try with NULL if fxs->nshock == 0 */
        if (fxs.nshock == 0)
          dv = RepoCflw_DF2ScenBPV(&analys, &df, fx_spot, xcflw, 
            &matur, &pp, &holi, &dfs, &ds, NULL) ;
        else
          dv = RepoCflw_DF2ScenBPV(&analys, &df, fx_spot, xcflw, 
            &matur, &pp, &holi, &dfs, &ds, &fxs) ;

        ok = True;
        nshock = ds.nshock;
        okexp = Read_BOOLE(in, out, "  Exp status ");
        dvexp = Read_FL64ARRAY(in, &nshockexp);
        acc = Read_FL64(in, out, "Tolerance ");

        diff = WriteFL64ARRAYDiff(okexp, dvexp, nshockexp, 
            ok, dv, nshock, out, acc);

        IOUtil_ParseLine(in, out);

        Free_DATEARRAY(holi.holidays) ;
        Free_CFLWARRAY(xcflw, 1) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_DELTASET(&ds) ;
        Free_SCENARIOLIST(&scen) ;
        Free_FL64ARRAY(dv) ;
        Free_FXSHOCKSET(&fxs);
        Free_FL64ARRAY(shocks);
        Free_FL64ARRAY(dvexp);
        Free_DFSPREAD(&dfs) ;
    }

    else if (!strcmp("Bond_DF2ScenBPV()", txa))
    {
        fprintf(out,"   Testing %s\n", txa) ;

        strncpy(ccy, "USD", CCY_LENGTH);
        analys = Read_DATESTR(in, out, "   analys    ");
        fx_spot = Read_FL64(in, out, "Fx Spot   "); 

        df     = Read_DISCFAC(in, out) ;
        trade = Read_TRADEINFO(in, out) ;
        fixp  = Read_FIXPAY(in, out, &trade.settle) ;
        holi   = Read_HOLI_STR(in, out) ;
        dfs    = Read_DFSPREAD(in, out) ;
        scen = Read_SCENARIOLIST(in, out) ;

        shocks = Read_FL64ARRAY(in, &nshock);
        Write_FL64ARRAY(out, shocks, nshock);

        irr = Read_IRRCONV(in, out, "  Shock IRR   ");
        freq = Read_PMTFREQ(in, out, "  Shock Freq  ");
        dom = Read_BOOLE(in, out, "   Domestic  ");

        ds = Disc_ScenarioPrep(&df, &scen, &holi, irr, freq, dom) ;

        fxs = FX_ShockPrep(fx_spot, shocks, nshock, &ccy) ;

        dv = Bond_DF2ScenBPV(&analys, &df, fx_spot, &trade, &fixp, 
          &holi, &dfs, &ds, &fxs) ;

        ok = True;
        okexp = Read_BOOLE(in, out, "  Exp status ");
        dvexp = Read_FL64ARRAY(in, &nshockexp);
        acc = Read_FL64(in, out, "Tolerance ");

        diff = WriteFL64ARRAYDiff(okexp, dvexp, nshockexp, 
            ok, dv, nshock, out, acc);

        IOUtil_ParseLine(in, out);

        Free_DATEARRAY(holi.holidays) ;
        Free_FIXPAY(&fixp) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_DELTASET(&ds) ;
        Free_SCENARIOLIST(&scen) ;
        Free_FL64ARRAY(dv) ;
        Free_FXSHOCKSET(&fxs);
        Free_FL64ARRAY(shocks);
        Free_FL64ARRAY(dvexp);
        Free_DFSPREAD(&dfs) ;
    }

    else if (!strcmp("IndexBond_DF2ScenBPV()", txa))
    {
        fprintf(out,"   Testing %s\n", txa) ;

        /* Read data */
        strncpy(ccy, "USD", CCY_LENGTH);
        analys  = Read_DATESTR(in, out, "   analys    ");
        fx_spot = Read_FL64(in, out, "Fx Spot   "); 
        df      = Read_DISCFAC(in, out) ;
        trade   = Read_TRADEINFO(in, out) ;
        idxbond = Read_INDEXBOND(in, out, &trade.settle) ;
        fac     = Read_INDEXFAC(in, out) ;
        holi    = Read_HOLI_STR(in, out) ;
        dfs     = Read_DFSPREAD(in, out) ;
        adj     = Read_BOOLE(in, out, "   Index adj?   ");
        scen    = Read_SCENARIOLIST(in, out) ;

        shocks  = Read_FL64ARRAY(in, &nshock);
        Write_FL64ARRAY(out, shocks, nshock);

        irr     = Read_IRRCONV(in, out, "  Shock IRR   ");
        freq    = Read_PMTFREQ(in, out, "  Shock Freq  ");
        dom     = Read_BOOLE(in, out, "   Domestic  ");

        /* Initialise */
        ds  = Disc_ScenarioPrep(&df, &scen, &holi, irr, freq, dom) ;
        fxs = FX_ShockPrep(fx_spot, shocks, nshock, &ccy) ;

        /* Calculate */
        dv = IndexBond_DF2ScenBPV(&analys, &df, fx_spot, &trade, &idxbond,
                                  &fac, &holi, &dfs, adj, &ds, &fxs) ;

        /* Read exp. res. */
        ok    = True;
        okexp = Read_BOOLE(in, out, "  Exp status ");
        dvexp = Read_FL64ARRAY(in, &nshockexp);
        acc   = Read_FL64(in, out, "Tolerance ");

        /* Compare */
        diff = WriteFL64ARRAYDiff(okexp, dvexp, nshockexp, ok, dv, nshock, 
                                  out, acc);

        /* Comments */
        IOUtil_ParseLine(in, out);

        Free_DATEARRAY(holi.holidays) ;
        Free_FIXPAY(&idxbond.fixp) ;
        Free_PLANARRAY(fac.idxfac, 1) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_DELTASET(&ds) ;
        Free_SCENARIOLIST(&scen) ;
        Free_FL64ARRAY(dv) ;
        Free_FXSHOCKSET(&fxs);
        Free_FL64ARRAY(shocks);
        Free_FL64ARRAY(dvexp);
        Free_DFSPREAD(&dfs) ;
    }
    
    else if (!strcmp("IndexLoan_DF2ScenBPV()", txa))
    {
        fprintf(out,"   Testing %s\n", txa) ;

        /* Read data */
        strncpy(ccy, "USD", CCY_LENGTH);
        analys  = Read_DATESTR(in, out, "   analys    ");
        fx_spot = Read_FL64(in, out, "Fx Spot   "); 
        df      = Read_DISCFAC(in, out) ;
        idxloan = Read_INDEXLOAN(in, out) ;
        debfac  = Read_INDEXFAC(in, out) ;
        crefac  = Read_INDEXFAC(in, out) ;
        holi    = Read_HOLI_STR(in, out) ;
        dfs     = Read_DFSPREAD(in, out) ;
        adj     = Read_BOOLE(in, out, "   Index adj?   ");
        scen    = Read_SCENARIOLIST(in, out) ;

        shocks  = Read_FL64ARRAY(in, &nshock);
        Write_FL64ARRAY(out, shocks, nshock);

        irr     = Read_IRRCONV(in, out, "  Shock IRR   ");
        freq    = Read_PMTFREQ(in, out, "  Shock Freq  ");
        dom     = Read_BOOLE(in, out, "   Domestic  ");

        /* Initialise */
        ds  = Disc_ScenarioPrep(&df, &scen, &holi, irr, freq, dom) ;
        fxs = FX_ShockPrep(fx_spot, shocks, nshock, &ccy) ;

        /* Calculate */
        dv = IndexLoan_DF2ScenBPV(&analys, &df, fx_spot, &idxloan, &debfac,
                                  &crefac, &holi, &dfs, adj, &ds, &fxs) ;

        /* Read exp. res. */
        ok    = True;
        okexp = Read_BOOLE(in, out, "  Exp status ");
        dvexp = Read_FL64ARRAY(in, &nshockexp);
        acc   = Read_FL64(in, out, "Tolerance ");

        /* Compare */
        diff = WriteFL64ARRAYDiff(okexp, dvexp, nshockexp, ok, dv, nshock, 
                                  out, acc);

        /* Comments */
        IOUtil_ParseLine(in, out);

        Free_DATEARRAY(holi.holidays) ;
        Free_PLANARRAY(debfac.idxfac, 1) ;
        Free_PLANARRAY(crefac.idxfac, 1) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_DELTASET(&ds) ;
        Free_SCENARIOLIST(&scen) ;
        Free_FL64ARRAY(dv) ;
        Free_FXSHOCKSET(&fxs);
        Free_FL64ARRAY(shocks);
        Free_FL64ARRAY(dvexp);
        Free_DFSPREAD(&dfs) ;
    }

    else if (!strcmp("Deposit_DF2ScenBPV()", txa))
    {
        fprintf(out,"   Testing %s\n", txa) ;

        strncpy(ccy, "USD", CCY_LENGTH);
        analys = Read_DATESTR(in, out, "   analys    ");
        fx_spot = Read_FL64(in, out, "Fx Spot   "); 

        df     = Read_DISCFAC(in, out) ;
        depo   = Read_DEPOSIT(in, out) ;
        holi   = Read_HOLI_STR(in, out) ;
        dfs    = Read_DFSPREAD(in, out) ;
        scen = Read_SCENARIOLIST(in, out) ;

        shocks = Read_FL64ARRAY(in, &nshock);
        Write_FL64ARRAY(out, shocks, nshock);

        irr = Read_IRRCONV(in, out, "  Shock IRR   ");
        freq = Read_PMTFREQ(in, out, "  Shock Freq  ");
        dom = Read_BOOLE(in, out, "   Domestic  ");

        ds = Disc_ScenarioPrep(&df, &scen, &holi, irr, freq, dom) ;

        fxs = FX_ShockPrep(fx_spot, shocks, nshock, &ccy) ;

        dv = Deposit_DF2ScenBPV(&analys, &df, fx_spot, &depo, 
          &holi, &dfs, &ds, &fxs) ;

        ok = True;
        okexp = Read_BOOLE(in, out, "  Exp status ");
        dvexp = Read_FL64ARRAY(in, &nshockexp);
        acc = Read_FL64(in, out, "Tolerance ");

        diff = WriteFL64ARRAYDiff(okexp, dvexp, nshockexp, 
            ok, dv, nshock, out, acc);

        IOUtil_ParseLine(in, out);

        Free_DATEARRAY(holi.holidays) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_DELTASET(&ds) ;
        Free_SCENARIOLIST(&scen) ;
        Free_FL64ARRAY(dv) ;
        Free_FXSHOCKSET(&fxs);
        Free_FL64ARRAY(shocks);
        Free_FL64ARRAY(dvexp);
        Free_DFSPREAD(&dfs) ;
    }



    return diff ;
}



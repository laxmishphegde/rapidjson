/* @(#)tstcflw2.c	1.4 (SimCorp) 99/02/19 14:12:41 */

/************************************************************************
*
*       This section contains the C enviroment test utility for the
*       cashflow C code.
*
************************************************************************/

/*** includes ***********************************************************/
#include <string.h>
#include <scalloc.h>
#include <str2conv.h>
#include <cflw.h>
#include <bondio.h>

#define ACC 0.00001    /* used for floating point comparison */

int cftest_test_generate(FILE* in, FILE*  out)
{
    INTI        tmp ;
    char        secid[120], txa[15], txb[15], txc[15], txd[15], txe[15],
                txf[15], txg[15] ;
    INTI        pnr, rdnr, cnr, nic ;
    INTL        clast, slast, teomatur, matur, repay1, coupon1, cstart, rday,
      aday ;
    DATESTR     dteomatur, dmatur, *ppdays, *xpamortdays, *holidays ;
    DATESTR     dlast, dcstart, *redempdays, *adjustdays, *icdays ;
    FL64        rpct, coupon, *ppamt, *redemp, *adjust, init_exch, *xpamort,
                *xpcoupons, rpct1 ;
    BONDTYPE    bondcat ;
    CALCONV     cal ;
    EOMCONV     eom ;
    BUSCONV     bus ;
    INTI        i, xpna, nholi, anerr, theerr = 0, allerr = 0 ;
    COUPONBASE  cbas1, cbas ;
    BOOLE       jgb, io, holpre, prepaid ;
    int         i1 ;
    HOLI_STR    holi ;
    PAYDAYDEF   rdday, cday ;
    FIXRATE     fix ;
    PLAN_STR    planpp, plana, planx, *plani ;
    REPAYMNT    xrepay ;
    CFLW_STR    *cflw ;
    PP_STR      pps ;

    tmp = fscanf(in, "%s", secid) ;
    if (tmp == EOF)
        return 0 ;

    fprintf(out, "%s\n", secid) ;

    fscanf(in, "%ld %ld %lf %s", &teomatur, &matur, &coupon, txa) ;

    bondcat   = Str2BONDTYPE(txa) ;
    dteomatur = Cldr_YMD2Datestr(teomatur) ;
    dmatur    = Cldr_YMD2Datestr(matur) ;

    fscanf(in, "%s %lf %lf %lf", txc, &init_exch, &rpct, &rpct1) ;
    io = Str2BOOLE(txc) ;

    fprintf(out, "Theo Maturity %8ld ; Maturity %8ld \n",
            teomatur, matur) ;

    fprintf(out, 
      "Coupon %9.4lf ; Bond Type %8s IO %s Init_exch %lf RPct %lf %lf\n",
      
            coupon, txa, txc, init_exch, rpct, rpct1) ;

    fscanf(in, "%ld %ld %s %s %s %d %s %s",
           &repay1, &slast, txa, txb, txc, &i1, txd, txe) ;
    rdday.pseq.odd1 = Str2ODDCONV(txa) ;
    rdday.pseq.oddn = Str2ODDCONV(txb) ;
    rdday.pseq.seq  = Str2SEQCONV(txc) ;
    rdday.pseq.term = (INTI) i1 ;
    rdday.pseq.unit = Str2TERMUNIT(txd) ;
    rdday.is_first  = True ;
    rdday.first   = Cldr_YMD2Datestr(repay1) ;
    rdday.seclast = Cldr_YMD2Datestr(slast) ;
    rdday.last  = dmatur ;
    rdday.snap2 = Str2BOOLE(txe) ;

    fprintf(out, "Repay: %8ld %8ld %10s %10s %10s %3d %10s %5s\n",
            repay1, slast, txa, txb, txc, i1, txd, txe) ;

    fscanf(in, "%ld %ld %s %s %s %d %s %s",
           &coupon1, &slast, txa, txb, txc, &i1, txd, txe) ;

    cday.pseq.odd1 = Str2ODDCONV(txa) ;
    cday.pseq.oddn = Str2ODDCONV(txb) ;
    cday.pseq.seq  = Str2SEQCONV(txc) ;
    cday.pseq.term = (INTI) i1 ;
    cday.pseq.unit = Str2TERMUNIT(txd) ;
    cday.is_first  = True ;
    cday.first   = Cldr_YMD2Datestr(coupon1) ;
    cday.seclast = Cldr_YMD2Datestr(slast) ;
    cday.last  = dmatur ;
    cday.snap2 = Str2BOOLE(txe) ;

    fprintf(out, "Coupon: %8ld %8ld %10s %10s %10s %3d %10s %5s\n",
            coupon1, slast, txa, txb, txc, i1, txd, txe) ;

    fscanf(in, "%ld %ld %lf %s %s %s %s %s %s",
           &cstart, &clast, &fix.accrfac, txb, txc, txd, txe, txf, txg) ;
    cbas1 = Str2COUPONBASE(txb) ;
    cbas = Str2COUPONBASE(txc) ;
    prepaid = Str2BOOLE(txd) ;
    jgb     = Str2BOOLE(txe) ;
    dcstart  = Cldr_YMD2Datestr(cstart) ;
    dlast    = Cldr_YMD2Datestr(clast) ;
    holpre   = Str2BOOLE(txf) ;
    fix.decomp = Str2FIXDCOMP(txg) ;

    fprintf(out, "Start %8ld Last %ld AccrFac %lf CB(odd) %s\n",
            cstart, clast, fix.accrfac, txb);
    fprintf(out, "CB %s Prepaid? %s JGB? %s HolPre %s DeCompound %s\n",
            txc, txd, txe, txf, txg) ;

    fscanf(in, "%s %s %s", txa, txb, txc) ;
    cal = Str2CALCONV(txa) ;
    eom = Str2EOMCONV(txb) ;
    bus = Str2BUSCONV(txc) ;
    fprintf(out, 
"Calendar Convention %8s ; End of Month Convention %8s\nBusinessdayConv %s\n",
            txa, txb, txc) ;

    fscanf(in, "%d", &i1) ;
    nholi = (INTI) i1 ;
    holidays = Alloc_DATEARRAY(nholi) ;
    for (i = 0 ; i < nholi ; i++)
    {
       if (i == 0)
           fprintf(out, "Non-Weekend Holidays:\n") ;
       fscanf(in, "%ld", &rday) ;
       holidays[i] = Cldr_YMD2Datestr(rday) ;
       fprintf(out, "%ld\n", rday) ;
    }

    holi.nholi    = nholi ;
    holi.holidays = holidays ;
    holi.bus      = bus ;

    fscanf(in, "%d", &i1) ;
    rdnr = (INTI) i1 ;
    redemp     = Alloc_FL64ARRAY(rdnr) ;
    redempdays = Alloc_DATEARRAY(rdnr) ;

    for (i = 0 ; i < rdnr ; i++)
    {
       fscanf(in, "%ld %lf", &rday, &redemp[i]) ;
       redempdays[i] = Cldr_YMD2Datestr(rday) ;
       fprintf(out, "%ld Repayment %11.4lf\n", rday, redemp[i]) ;
    }

    fscanf(in, "%d", &i1) ;
    nic = (INTI) i1 ;

    icdays = Alloc_DATEARRAY(nic) ;

    for (i = 0 ; i < nic ; i++)
    {
       if (i == 0)
           fprintf(out, "Coupondays:\n") ;
       fscanf(in, "%ld", &rday) ;
       icdays[i] = Cldr_YMD2Datestr(rday) ;
       fprintf(out, "%ld\n", rday) ;
    }

    fscanf(in, "%d", &i1) ;
    cnr = (INTI) i1 ;

    adjust     = Alloc_FL64ARRAY(cnr) ;
    adjustdays = Alloc_DATEARRAY(cnr) ;

    for (i = 0 ; i < cnr ; i++)
    {
       fscanf(in,"%ld %lf", &aday, &adjust[i]) ;
       adjustdays[i] = Cldr_YMD2Datestr(aday) ;
       fprintf(out, "%ld Interest Rate Adjustment %8.4lf\n",
               aday, adjust[i]) ;
    }

    fscanf(in, "%d", &i1) ;
    pnr = (INTI) i1;

    ppamt  = Alloc_FL64ARRAY(pnr) ;
    ppdays = Alloc_DATEARRAY(pnr) ;

    for (i = 0 ; i < pnr ; i++)
    {
       fscanf(in,"%ld %lf", &aday, &ppamt[i]) ;
       ppdays[i] = Cldr_YMD2Datestr(aday) ;
       fprintf(out, "%ld Partly Payment %8.4lf\n",
               aday, ppamt[i]) ;
    }

    /* Read irregular coupons */
    plani = Read_PLANARRAY(in) ;
    fprintf(out, "   Irregular Coupons\n") ;
    Write_PLANARRAY(out, plani) ;

    /* reading expected cash flows */
    fscanf(in, "%d", &i1) ;
    xpna = (INTI) i1 ;
    xpamortdays = Alloc_DATEARRAY(xpna) ;
    xpamort     = Alloc_FL64ARRAY(xpna) ;
    xpcoupons    = Alloc_FL64ARRAY(xpna) ;

    for (i = 0 ; i < xpna ; i++)
    {
        fscanf(in, "%ld %lf %lf", &aday, &xpamort[i], &xpcoupons[i]) ;
        xpamortdays[i] = Cldr_YMD2Datestr(aday) ;
    }

    /* Set calendar conventions */
    rdday.pseq.eom = eom ;
    cday.pseq.eom  = eom ;

    planx.filled = cnr ;
    planx.count  = cnr ;
    planx.day    = adjustdays ;
    planx.f64    = adjust ;

    planpp.filled = pnr ;
    planpp.count  = pnr ;
    planpp.day    = ppdays ;
    planpp.f64    = ppamt ;
    pps.ppmts     = &planpp ;

    cday.nirreg = nic ;
    cday.irreg_days = icdays ;

    rdday.nirreg = rdnr ;
    rdday.irreg_days = redempdays ;

    plana.filled = rdnr ;
    plana.f64    = redemp ;
    plana.day    = redempdays ;

    xrepay = Set_REPAYMNT(bondcat, &dteomatur, io, init_exch, &pps,
                          &plana, &plana, rpct, rpct1) ;

    fix = Set_FIXRATE(coupon, cal, &dcstart, &dlast, fix.accrfac, cbas,
                      cbas1, prepaid, jgb, &planx, holpre, plani, fix.decomp);

    cflw = Cflw_GenrCflw(&xrepay, &rdday, &fix, &cday, &holi) ;

    /* printing out results */
    fprintf(out, "\nThe Output Cash Flow is\n") ;

    fprintf(out,"OK   Expected                    Calculated\n") ;
    fprintf(out,
      "     Date     Repayment  Coupon  Date     Repayment  Coupon\n") ;

    if (xpna == cflw->filled)
    {
        for (i = 0 ; i < xpna ; i++)
        {
            rday = Cldr_Datestr2YMD(&cflw->days[i]) ;
            aday = Cldr_Datestr2YMD(&xpamortdays[i]) ;
            anerr = rday != aday ||
                    fabs(xpamort[i] - cflw->repay[i]) >= ACC ||
                    fabs(xpcoupons[i] - cflw->coupon[i]) >= ACC ;
            fprintf(out, "%d;  %8ld %9.5lf %9.6lf %8ld %9.5lf %9.6lf\n",
                    anerr, aday, xpamort[i], xpcoupons[i],
                           rday, cflw->repay[i], cflw->coupon[i]) ;
            theerr = theerr || anerr ;
        }
    }
    else
    {
        fprintf(out, 
"1; MISMATCH in expected and actual number of payments. Exp %d found %d\n",
          
                xpna, cflw->filled) ;
        fprintf(out,"        calculated\n") ;
        fprintf(out,"        date repayment coupon\n") ;
        theerr = 1 ;
        for (i = 0 ; i < cflw->filled ; i++)
        {
            rday = Cldr_Datestr2YMD(&cflw->days[i]) ;
            fprintf(out, "     %8ld %9.3lf %9.6lf\n",
                    rday, cflw->repay[i], cflw->coupon[i]) ;
        }
    }

    /* picking up errors */
    allerr += theerr ;
    theerr = 0 ;

    fprintf(out, "\n\n") ;

    /* Cleaning up memory */
    Free_DATEARRAY(holidays) ;

    Free_FL64ARRAY(xpamort) ;
    Free_FL64ARRAY(xpcoupons) ;
    Free_DATEARRAY(xpamortdays) ;

    Free_FL64ARRAY(redemp) ;
    Free_DATEARRAY(redempdays) ;
    Free_DATEARRAY(icdays) ;
    Free_FL64ARRAY(adjust) ;
    Free_DATEARRAY(adjustdays) ;
    Free_FL64ARRAY(ppamt) ;
    Free_DATEARRAY(ppdays) ;
    Free_CFLWARRAY(cflw, 1) ;

    Free_PLANARRAY(plani, 1) ;

    return allerr ;
}

/*
..
*/

int cftest_test_extract( FILE*  in, FILE*  out)
{
    char        secid[120], txa[15], txb[15], txc[15], txd[15], txe[25] ;
    INTI        qbas, tmp, ncflw, i , np, nad, nxp, npmts ;
    COUPONBASE  cbase, cbase1 ;
    INTL        rtend, trade, zins, geld, end, rtstart, aday ;
    DATESTR     dlast, dend, drtstart ;
    FL64        pp_price, price, coupon, nom ;
    FL64        *cflwamort, *cflwcoupon, *adjust ;
    DATESTR     *cflwdays, *adjustdays, *ppdays, *dates ;
    INTL        *xpdates ;
    FL64        *ppamt, *amort, *coupons, *xpamort, *xpcoupons ;
    CALCONV     calacc ;
    EOMCONV     eom ;
    INTI        nauf, anerr, theerr = 0, allerr = 0 ;
    BOOLE       b1, b2, b3, b4, b5, b6, b7, b8, cgb184, jgb,
                prepaid, fill, schuldsch, incl, pre, BRDfeb ;
    IRRCONV     irr ;
    long        l1, l2 ;
    int         i1 ;
    FIXRATE     fix ;
    PLAN_STR    *aufab, *plani, planpp, planx ;
    CFLW_STR    cflw, *xcflw ;
    ACCRUINT    accru ;
    PAYDAYSEQ   pseq ;
    HOLI_STR    holi ;
    PP_STR      pps, *ppp ;
    EXRULE      xprule ;
    TRADEINFO   tr1, tr2 ;
    EXDAYCONV   xdc1, xdc2 ;
    EXINF       dummy ;

    tmp = fscanf(in, "%s", secid) ;
    if (tmp == EOF)
        return 0 ;

    fprintf(out, "%s\n", secid) ;

    fscanf(in, "%ld %ld %ld %s", &trade, &zins, &geld, txd) ;
    tr1.brd = Str2BOOLE(txd) ;
    tr1.settle = Cldr_YMD2Datestr(geld) ;
    tr1.aisttl = Cldr_YMD2Datestr(zins) ;
    tr1.trade  = Cldr_YMD2Datestr(trade) ;

    fprintf(out,"START: %ld %ld %ld %s\n", trade, zins, geld, txd) ;

    fscanf(in, "%ld %lf %lf %s %s %s", &end, &price, &coupon, txb, txa, txc) ;
    cbase1 = Str2COUPONBASE(txb) ;
    cbase = Str2COUPONBASE(txa) ;
    jgb   = Str2BOOLE(txc) ;

    fprintf(out,
"End %8ld Price %6.3lf\nCoupon %6.3lf C.Base(odd) %s C.Base %s JGB? %s\n",
      
            end, price, coupon, txb, txa, txc) ;

    fscanf(in, "%s %s %d %s", txa, txb, &i1, txc) ;
    pseq.odd1 = Str2ODDCONV(txa) ;
    pseq.oddn = Str2ODDCONV(txb) ;
    pseq.term = (INTI) i1 ;
    pseq.unit = Str2TERMUNIT(txc) ;
    fprintf(out, "OddConv %s %s ; PmtFreq %d %s\n", txa, txb, i1, txc) ;

    fscanf(in, "%s %ld %s %s %s %s", txe, &l1, txa, txb, txc, txd) ;
    xdc1 = Str2EXDAYCONV(txe) ;
    b1 = Str2BOOLE(txa) ;
    b2 = Str2BOOLE(txb) ;
    b3 = Str2BOOLE(txc) ;
    b4 = Str2BOOLE(txd) ;
    fprintf(out, "Exc: %s %ld Is_Set1 %s Ex_Fix1 %s Is_Set2 %s Ex_Fix2 %s\n",
            txe, l1, txa, txb, txc, txd) ;

    fscanf(in, "%s %ld %s %s %s %s", txe, &l2, txa, txb, txc, txd) ;
    xdc2 = Str2EXDAYCONV(txe) ;
    b5 = Str2BOOLE(txa) ;
    b6 = Str2BOOLE(txb) ;
    b7 = Str2BOOLE(txc) ;
    b8 = Str2BOOLE(txd) ;
    fprintf(out, "Exp: %s %ld Is_Set1 %s Ex_Fix1 %s Is_Set2 %s Ex_Fix2 %s\n",
            txe, l2, txa, txb, txc, txd) ;

    fscanf(in, "%s %ld %ld %lf %s", txa, &rtstart, &rtend, &fix.accrfac, txb) ;
    calacc = Str2CALCONV(txa) ;
    prepaid = Str2BOOLE(txb) ;
    fprintf(out,"CalAccr %8s Start %8ld End %ld AccrFac %lf Prepaid? %8s\n",
            txa, rtstart, rtend, fix.accrfac, txb) ;

    fscanf(in, "%s %s", txc, txd) ;
    eom  = Str2EOMCONV(txc) ;
    schuldsch = Str2BOOLE(txd) ;
    fprintf(out, "Eom                             %s\n", txc) ;
    fprintf(out, "Schuldschein ?                ? %s\n", txd) ;

    fscanf(in, "%s %s %s %s", txb, txa, txe, txc) ;
    incl = Str2BOOLE(txb) ;
    pre  = Str2BOOLE(txa) ;
    cgb184 = Str2BOOLE(txe) ;
    BRDfeb = Str2BOOLE(txc) ;
    fprintf(out, "One day xtra accrued          ? %s\n", txb) ;
    fprintf(out, "Accrued before interest start ? %s\n", txa) ;
    fprintf(out, "CGB Special Rule              ? %s\n", txe) ;
    fprintf(out, "BRD Special Rule              ? %s\n", txc) ;

    fscanf(in, "%s %d", txa, &i1) ;
    qbas = (INTI) i1 ;
    irr = Str2IRRCONV(txa) ;
    fprintf(out, "Accrual Convention %s Basis %d\n", txa, i1) ;
    qbas = (INTI) i1 ;

    fscanf(in, "%lf %s", &nom, txa) ;
    fill = Str2BOOLE(txa) ;
    fprintf(out, "Nominal amount is    %7.3lf fill empty ? %s\n",
            nom, txa) ;

    /* reading, allocating and writing bond cash flow */
    fscanf(in, "%d", &i1) ;
    ncflw = (INTI) i1 ;

    cflwdays   = Alloc_DATEARRAY(ncflw) ;
    cflwamort  = Alloc_FL64ARRAY(ncflw) ;
    cflwcoupon = Alloc_FL64ARRAY(ncflw) ;

    fprintf(out, "Input cash flow is\n") ;
    fprintf(out, "    date   repayment     coupon\n") ;

    for (i = 0 ; i < ncflw ; i++)
    {
        fscanf(in, "%ld %lf %lf", &aday, &cflwamort[i], &cflwcoupon[i]) ;
        cflwdays[i] = Cldr_YMD2Datestr(aday) ;
        fprintf(out,"%8ld %10.3lf %10.3lf\n",
                aday, cflwamort[i], cflwcoupon[i]) ;
    }

    /* Reading, allocating and writing interest rate adjustments */
    fscanf(in, "%d", &i1) ;
    nad = (INTI) i1 ;

    adjust     = Alloc_FL64ARRAY(nad) ;
    adjustdays = Alloc_DATEARRAY(nad) ;

    for (i = 0 ; i < nad ; i++)
    {
       fscanf(in,"%ld %lf", &aday, &adjust[i]) ;
       adjustdays[i] = Cldr_YMD2Datestr(aday) ;
       fprintf(out, "%ld Interest Rate Adjustment %8.4lf\n",
               aday, adjust[i]) ;
    }

    /* Partly payments */
    fscanf(in, "%d %lf", &i1, &pp_price) ;
    np = (INTI) i1 ;

    ppamt  = Alloc_FL64ARRAY(np) ;
    ppdays = Alloc_DATEARRAY(np) ;

    for (i = 0 ; i < np ; i++)
    {
       fscanf(in,"%ld %lf", &aday, &ppamt[i]) ;
       ppdays[i] = Cldr_YMD2Datestr(aday) ;
       fprintf(out, "%ld Partly Payments %8.4lf\n", aday, ppamt[i]) ;
    }

    /* Auf/Ab */
    fscanf(in, "%d", &i1) ;
    nauf = (INTI) i1 ;
    aufab = Alloc_PLANARRAY(1, nauf) ;
    aufab->filled = nauf ;
    for (i = 0 ; i < nauf ; i++)
    {
       fscanf(in,"%ld %lf", &aday, &aufab->f64[i]) ;
       aufab->day[i] = Cldr_YMD2Datestr(aday) ;
       fprintf(out, "%ld Auf/Ab %8.4lf\n", aday, aufab->f64[i]) ;
    }

    /* Read irregular coupons */
    plani = Read_PLANARRAY(in) ;
    fprintf(out, "   Irregular Coupons\n") ;
    Write_PLANARRAY(out, plani) ;

    /* Reading and allocating expected cash flows */
    fscanf(in, "%d", &i1) ;
    nxp = (INTI) i1 ;

    xpdates   = Alloc_YMDARRAY(nxp) ;
    xpamort   = Alloc_FL64ARRAY(nxp) ;
    xpcoupons = Alloc_FL64ARRAY(nxp) ;

    for (i = 0 ; i < nxp ; i++)
    {
        fscanf(in, "%ld %lf %lf",
               &xpdates[i], &xpamort[i], &xpcoupons[i]) ;
    }

    dend     = Cldr_YMD2Datestr(end) ;
    drtstart = Cldr_YMD2Datestr(rtstart) ;
    dlast    = Cldr_YMD2Datestr(rtend) ;

    planx.filled = nad ;
    planx.count  = nad ;
    planx.day = adjustdays ;
    planx.f64 = adjust ;

    planpp.filled = np ;
    planpp.count  = np ;
    planpp.day    = ppdays ;
    planpp.f64    = ppamt ;

    pps.ppmts = &planpp ;
    pps.pp_price = pp_price ;

    cflw.filled = ncflw ;
    cflw.days   = cflwdays ;
    cflw.coupon = cflwcoupon ;
    cflw.repay  = cflwamort ;

    accru.pre  = pre ;
    accru.incl = incl ;
    accru.cal  = calacc ;
    accru.cbodd_accru = cbase1 ;
    accru.cb_accru    = cbase ;
    accru.irr = irr ;
    accru.qbas = qbas ;
    accru.schuldsch = schuldsch ;
    accru.CGB184    = cgb184 ;
    accru.BRDfeb    = BRDfeb ;

    holi.nholi = 0 ;
    holi.bus   = NO_BUSADJUST ;

    accru.exr.xconv   = xdc1 ;
    accru.exr.dex     = Cldr_YMD2Datestr((YYYYMMDD) l1) ;
    accru.exr.exdays  = (INTI) l1 ;
    accru.exr.caldays = False ;
    accru.exr.cal     = calacc ;
    accru.exr.xlast   = True ;

    xprule.xconv   = xdc2 ;
    xprule.dex     = Cldr_YMD2Datestr((YYYYMMDD) l2) ;
    xprule.exdays  = (INTI) l2 ;
    xprule.caldays = False ;
    xprule.cal     = calacc ;
    xprule.xlast   = True ;

    tr1.nom    = nom ;
    tr1.xctrade.spec   = b1 ;
    tr1.xctrade.ex_fix = b2 ;
    tr1.xptrade.spec   = b5 ;
    tr1.xptrade.ex_fix = b6 ;

    tr2.settle = dend ;
    tr2.aisttl = dend ;
    tr2.trade  = dend ;
    tr2.brd    = False ;
    tr2.price  = price ;
    tr2.xctrade.spec   = b3 ;
    tr2.xctrade.ex_fix = b4 ;
    tr2.xptrade.spec   = b7 ;
    tr2.xptrade.ex_fix = b8 ;

    pseq.eom = eom ;
    pseq.seq = ANCHOR ;

    fix = Set_FIXRATE(coupon, calacc, &drtstart, &dlast, fix.accrfac,
                      cbase, cbase1, prepaid, jgb, &planx, False, 
                      plani, NODCOMP) ;

    /* Test this */
    ppp = (np == 0 ? NULL : &pps) ;

    xcflw = Cflw_ExtractPeriod(&tr1, &tr2, &fix, &pseq, &accru, &xprule, &holi,
                                fill, &cflw, ppp, aufab, &dummy) ;

    npmts   = xcflw->filled ;
    dates   = xcflw->days ;
    amort   = xcflw->repay ;
    coupons = xcflw->coupon ;

    fprintf(out, "\nYou expected %d payments - we found %d payments\n\n",
            nxp, npmts) ;

    theerr = nxp != npmts ;

    fprintf(out, "\nThe Output Extracted Cash Flow is\n") ;

    fprintf(out,"OK expected                              calculated\n") ;
    fprintf(out,
      "       date   repayment    coupon       date   repayment    coupon\n")
      ;

    for (i = 0 ; i < GETMAX(nxp, npmts) ; i++)
    {
        aday = (i < npmts ? Cldr_Datestr2YMD(&dates[i]) : (INTL) 0);
        if (i < nxp && i < npmts)
            anerr = xpdates[i] != aday ||
                    fabs(xpamort[i] - amort[i]) >= ACC ||
                    fabs(xpcoupons[i] - coupons[i]) >= ACC ;
        else
            anerr = 1 ;

        fprintf(out, "%d;", anerr) ;
        if (i < nxp)
            fprintf(out, " %8ld %10.5lf %9.6lf",
                    xpdates[i], xpamort[i], xpcoupons[i]) ;
        else
            fprintf(out, "                                      ") ;

        if (i < npmts)
            fprintf(out, "   %8ld %10.5lf %9.6lf\n",
                    aday, amort[i], coupons[i]) ;
        else
            fprintf(out, "\n") ;

        theerr = theerr || anerr ;
    }

    /* picking up errors */
    allerr += theerr ;
    theerr = 0 ;

    fprintf(out, "\n\n") ;

    /* cleaning up memory */
    Free_DATEARRAY(cflwdays) ;
    Free_FL64ARRAY(cflwamort) ;
    Free_FL64ARRAY(cflwcoupon) ;

    Free_FL64ARRAY(adjust) ;
    Free_DATEARRAY(adjustdays) ;
    Free_FL64ARRAY(ppamt) ;
    Free_DATEARRAY(ppdays) ;

    Free_YMDARRAY(xpdates) ;
    Free_FL64ARRAY(xpamort) ;
    Free_FL64ARRAY(xpcoupons) ;

    Free_CFLWARRAY(xcflw, 1) ;

    Free_PLANARRAY(aufab, 1) ;
    Free_PLANARRAY(plani, 1) ;

    return allerr ;
}

/*
..
*/

int cftest_test_accruint( FILE*  in, FILE*  out)
{
    char        secid[120], txa[15], txb[15], txc[15], txd[15], txe[15] ;
    INTI        allerr, qbas, tmp, excdays, ncflw, i, np, nad;
    COUPONBASE  cbase, cbase1 ;
    INTL        rtend, trade, zins, geld, rtstart, aday ;
    DATESTR     dlast, drtstart ;
    FL64        coupon, *cflwamort, *cflwcoupon, *adjust, *ppamt ;
    DATESTR     *cflwdays, *adjustdays, *ppdays ;
    CALCONV     calacc ;
    EOMCONV     eom ;
    BOOLE       b1, b2, b5, b6, cgb184, jgb,
                prepaid, schuldsch, incl, pre, BRDfeb ;
    IRRCONV     irr ;
    int         i1 ;
    FIXRATE     fix ;
    PLAN_STR    planpp, planx ;
    CFLW_STR    cflw ;
    ACCRUINT    accru ;
    PAYDAYSEQ   pseq ;
    HOLI_STR    holi ;
    TRADEINFO   tr1 ;
    AIRESULT    aires, aiexp ;

    allerr = 0 ;

    tmp = fscanf(in, "%s", secid) ;
    if (tmp == EOF)
        return 0 ;

    fprintf(out, "%s\n", secid) ;

    fscanf(in, 
      "%lf %d %lf %ld %s",
      &aiexp.AI, &i1, &aiexp.AI_per_day, &aday, txc) ;
    aiexp.AIdays     = (INTI) i1 ;
    aiexp.exc        = Str2BOOLE(txc) ;
    aiexp.next       = Cldr_YMD2Datestr(aday) ;

    fscanf(in, "%ld %ld %ld %s", &trade, &zins, &geld, txd) ;
    tr1.brd = Str2BOOLE(txd) ;
    tr1.settle = Cldr_YMD2Datestr(geld) ;
    tr1.aisttl = Cldr_YMD2Datestr(zins) ;
    tr1.trade  = Cldr_YMD2Datestr(trade) ;

    fprintf(out,"START: %ld %ld %ld %s\n", trade, zins, geld, txd) ;

    fscanf(in, "%lf %s %s %s %s", &coupon, txb, txa, txc, txd) ;
    cbase1 = Str2COUPONBASE(txb) ;
    cbase = Str2COUPONBASE(txa) ;
    jgb   = Str2BOOLE(txc) ;
    fix.decomp = Str2FIXDCOMP(txd) ;

    fprintf(out,"Coupon %6.3lf C.Base(odd) %s C.Base %s JGB? %s DeComp? %s\n",
            coupon, txb, txa, txc, txd) ;

    fscanf(in, "%s %s %d %s", txa, txb, &i1, txc) ;
    pseq.odd1 = Str2ODDCONV(txa) ;
    pseq.oddn = Str2ODDCONV(txb) ;
    pseq.term = (INTI) i1 ;
    pseq.unit = Str2TERMUNIT(txc) ;
    fprintf(out, "OddConv %s %s ; PmtFreq %d %s\n", txa, txb, i1, txc) ;

    fscanf(in, "%d %s %s %s %s", &i1, txa, txb, txc, txd) ;
    excdays = (INTI) i1 ;
    b1 = Str2BOOLE(txa) ;
    b2 = Str2BOOLE(txb) ;
    b5 = Str2BOOLE(txc) ;
    b6 = Str2BOOLE(txd) ;
    fprintf(out, 
            "Exc: Days %2d XC: Is_Set %s Ex_Fix %s XP: Is_Set %s Ex_Fix %s\n",
            i1, txa, txb, txc, txd) ;

    fscanf(in, "%s %ld %ld %lf %s", txa, &rtstart, &rtend, &fix.accrfac, txb) ;
    calacc = Str2CALCONV(txa) ;
    prepaid = Str2BOOLE(txb) ;
    fprintf(out,"CalAccr %8s Start %8ld End %ld AccrFac %lf Prepaid? %8s\n",
            txa, rtstart, rtend, fix.accrfac, txb) ;

    fscanf(in, "%s %s", txc, txd) ;
    eom  = Str2EOMCONV(txc) ;
    schuldsch = Str2BOOLE(txd) ;
    fprintf(out, "Eom                             %s\n", txc) ;
    fprintf(out, "Schuldschein ?                ? %s\n", txd) ;

    fscanf(in, "%s %s %s %s", txb, txa, txe, txc) ;
    incl = Str2BOOLE(txb) ;
    pre  = Str2BOOLE(txa) ;
    cgb184 = Str2BOOLE(txe) ;
    BRDfeb = Str2BOOLE(txc) ;
    fprintf(out, "One day xtra accrued          ? %s\n", txb) ;
    fprintf(out, "Accrued before interest start ? %s\n", txa) ;
    fprintf(out, "CGB Special Rule              ? %s\n", txe) ;
    fprintf(out, "BRD Special Rule              ? %s\n", txc) ;

    fscanf(in, "%s %d", txa, &i1) ;
    qbas = (INTI) i1 ;
    irr = Str2IRRCONV(txa) ;
    fprintf(out, "Accrual Convention %s Basis %d\n", txa, i1) ;
    qbas = (INTI) i1 ;

    /* reading, allocating and writing bond cash flow */
    fscanf(in, "%d", &i1) ;
    ncflw = (INTI) i1 ;

    cflwdays   = Alloc_DATEARRAY(ncflw) ;
    cflwamort  = Alloc_FL64ARRAY(ncflw) ;
    cflwcoupon = Alloc_FL64ARRAY(ncflw) ;

    fprintf(out, "Input cash flow is\n") ;
    fprintf(out, "    date   repayment     coupon\n") ;

    for (i = 0 ; i < ncflw ; i++)
    {
        fscanf(in, "%ld %lf %lf", &aday, &cflwamort[i], &cflwcoupon[i]) ;
        cflwdays[i] = Cldr_YMD2Datestr(aday) ;
        fprintf(out,"%8ld %10.3lf %10.3lf\n",
                aday, cflwamort[i], cflwcoupon[i]) ;
    }

    /* Reading, allocating and writing interest rate adjustments */
    fscanf(in, "%d", &i1) ;
    nad = (INTI) i1 ;

    adjust     = Alloc_FL64ARRAY(nad) ;
    adjustdays = Alloc_DATEARRAY(nad) ;

    for (i = 0 ; i < nad ; i++)
    {
       fscanf(in,"%ld %lf", &aday, &adjust[i]) ;
       adjustdays[i] = Cldr_YMD2Datestr(aday) ;
       fprintf(out, "%ld Interest Rate Adjustment %8.4lf\n",
               aday, adjust[i]) ;
    }

    /* Partly payments */
    fscanf(in, "%d", &i1) ;
    np = (INTI) i1 ;

    ppamt  = Alloc_FL64ARRAY(np) ;
    ppdays = Alloc_DATEARRAY(np) ;

    for (i = 0 ; i < np ; i++)
    {
       fscanf(in,"%ld %lf", &aday, &ppamt[i]) ;
       ppdays[i] = Cldr_YMD2Datestr(aday) ;
       fprintf(out, "%ld Partly Payments %8.4lf\n", aday, ppamt[i]) ;
    }

    drtstart = Cldr_YMD2Datestr(rtstart) ;
    dlast    = Cldr_YMD2Datestr(rtend) ;

    planx.filled = nad ;
    planx.count  = nad ;
    planx.day    = adjustdays ;
    planx.f64    = adjust ;

    planpp.filled = np ;
    planpp.count  = np ;
    planpp.day    = ppdays ;
    planpp.f64    = ppamt ;

    cflw.filled = ncflw ;
    cflw.days   = cflwdays ;
    cflw.coupon = cflwcoupon ;
    cflw.repay  = cflwamort ;

    accru.pre  = pre ;
    accru.incl = incl ;
    accru.cal  = calacc ;
    accru.cbodd_accru = cbase1 ;
    accru.cb_accru    = cbase ;
    accru.irr = irr ;
    accru.qbas = qbas ;
    accru.schuldsch = schuldsch ;
    accru.CGB184    = cgb184 ;
    accru.BRDfeb    = BRDfeb ;

    holi.nholi = 0 ;
    holi.bus   = NO_BUSADJUST ;

    accru.exr.xconv   = EX_DAYS ;
    accru.exr.exdays  = excdays ;
    accru.exr.caldays = False ;
    accru.exr.cal     = calacc ;
    accru.exr.xlast   = True ;

    tr1.nom = 100.0 ;
    tr1.xctrade.spec   = b1 ;
    tr1.xctrade.ex_fix = b2 ;
    tr1.xptrade.spec   = b5 ;
    tr1.xptrade.ex_fix = b6 ;

    pseq.eom = eom ;
    pseq.seq = ANCHOR ;

    fix = Set_FIXRATE(coupon, calacc, &drtstart, &dlast, fix.accrfac,
                      cbase, cbase1, prepaid, jgb, &planx, False, 
                      NULL, fix.decomp) ;

    aires = Cflw_Accruint(&tr1, &cflw, &fix, &pseq, &accru, &holi, &planpp, NEXTINDEX) ;    /*  FPL-PMSTA00211-100826 add NEXTINDEX */

    /* Pick up errors */
    if (fabs(aires.AI - aiexp.AI) > 0.00001 || aiexp.AIdays != aires.AIdays)
        allerr = 1 ;
    if (fabs(aires.AI_per_day - aiexp.AI_per_day) > 0.00001)
        allerr = 1 ;
    if (aires.exc != aiexp.exc)
        allerr = 1 ;
    if (Cldr_Datestr2YMD(&aires.next) != Cldr_Datestr2YMD(&aiexp.next) )
        allerr = 1 ;

    fprintf(out, "%d; exp %lf res %lf\n",
            fabs(aires.AI - aiexp.AI) > 0.00001, aiexp.AI, aires.AI) ;
    fprintf(out, "%d; exp %d res %d\n",
            aires.AIdays != aiexp.AIdays, aiexp.AIdays, aires.AIdays) ;
    fprintf(out, "%d; exp %lf res %lf\n",
            fabs(aires.AI_per_day - aiexp.AI_per_day) > 0.00001,
            aiexp.AI_per_day, aires.AI_per_day) ;
    fprintf(out, "%d; exp %d res %d\n",
            aires.exc != aiexp.exc, aiexp.exc, aires.exc) ;
    fprintf(out, "%d; exp %d res %d\n",
            Cldr_Datestr2YMD(&aires.next) != Cldr_Datestr2YMD(&aiexp.next),
            Cldr_Datestr2YMD(&aiexp.next), Cldr_Datestr2YMD(&aires.next) ) ;
    fprintf(out, "\n\n") ;

    /* Clean up memory */
    Free_DATEARRAY(cflwdays) ;
    Free_FL64ARRAY(cflwamort) ;
    Free_FL64ARRAY(cflwcoupon) ;

    Free_FL64ARRAY(adjust) ;
    Free_DATEARRAY(adjustdays) ;

    Free_FL64ARRAY(ppamt) ;
    Free_DATEARRAY(ppdays) ;

    return allerr ;
}

#undef ACC

/* SCID @(#)riskpos.c	1.4 (SimCorp) 99/09/21 11:05:19  */

/************************************************************************
*
*       Project         SCecon
*
*       file name       riskpos.c
*
*       contains        risk position calculations
*
************************************************************************/

/*** includes **********************************************************/
#include <riskpos.h>


/*** defines  **********************************************************/
#define DISC_TOLR  (FL64)    0.00000001
#define DIV_TOL    (FL64)    0.00000001


/*,,SOH,,
*************************************************************************
*
*               Cflw_DF2RiskPos()
*
*   interface   #include <riskpos.h>
*               RISKPOSLIST Cflw_DF2RiskPos(DATESTR   *analys,
*                                           CFLW_STR  *xcflw,
*                                           PP_STR    *pp,
*                                           FL64      Notnal,
*                                           DISCFAC   *df,
*                                           DFSPREAD  *dfs,
*                                           HOLI_STR  *holi,
*                                           DELTASET  *ds,
*                                           FXRISKSET *FXr) ;
*
*   general     The routine calculates the Risk Position for
*               an arbitrary cashflow using a list of predefined shocks
*               to the zero curve.
*
*               The Risk Position is the core input for VAR calculation.*
*               The Risk Position calculated for this position must be
*               added to the total Risk Position. Once this total Risk
*               Position is available VAR can be calculated with the
*               routine VAR_MATRIX2VAR().
*
*               The decision whether to use price or yield vol is
*               signalled in ds->zero. Note that this must be the same
*               for all risk factors encountered in the total VAR
*               calculation.
*
*               The risk factors affecting a fixed cashflow are:
*
*                   Interest Rates (Government, Swap or Money Market)
*                   FX (if Instrument CCY differs from Home CCY)
*
*               These entries are found in the returned RISKPOSLIST
*
*   input       DATESTR   *analys       The analysis date.
*
*               CFLW_STR  *xcflw        The extracted cashflow from
*                                       the relevant period.
*                                       Must have the format defined
*                                       by bond_extract_period().
*                                       Cashflow is NOT adjusted for
*                                       businessdays.
*                                       The outstanding debt on the
*                                       bond must be 100.
*
*               PP_STR    *pp           Partly Paid setup. pp->pp_price
*                                       is not used.
*
*               FL64      Notnal        The notional holding (position)
*                                       Amount in Instrument CCY
*
*               DISCFAC   *df           Discounting structure setup.
*                                       The initial (unshocked) curve
*                                       should be in df->disc.
*
*               DFSPREAD  *dfs          Spread against the curve.
*
*               HOLI_STR  *holi         Business adjustment setup
*
*               DELTASET  *ds           Delta vector defining data
*                                       Set with Disc_DeltaPrep()
*
*               FXRISKSET *FXr          Data for FX risk generation
*
*   output
*
*   returns     The Risk Position allocated as:
*
*                         Alloc_RISKTOKENARRAY(ds->nshock + 1) ;
*                         Alloc_FL64ARRAY(ds->nshock + 1) ;
*
*   diagnostics
*
*   see also    Disc_DeltaPrep()
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/


RISKPOSLIST Cflw_DF2RiskPos(DATESTR* analys,
                            CFLW_STR*  xcflw,
                            PP_STR*    pp,
                            FL64      Notnal,
                            DISCFAC*   df,
                            DFSPREAD*  dfs,
                            HOLI_STR*  holi,
                            DELTASET*  ds,
                            FXRISKSET* FXr)
{
    return RepoCflw_DF2RiskPos(analys, xcflw, NULL, pp, Notnal, 
                               df, dfs, holi, ds, FXr) ;
}


/*,,SOH,,
*************************************************************************
*
*               RepoCflw_DF2RiskPos()
*
*   interface   #include <riskpos.h>
*               RISKPOSLIST RepoCflw_DF2RiskPos(DATESTR   *analys,
*                                               CFLW_STR  *xcflw,
*                                               DATESTR   *matur,
*                                               PP_STR    *pp,
*                                               FL64      Notnal,
*                                               DISCFAC   *df,
*                                               DFSPREAD  *dfs,
*                                               HOLI_STR  *holi,
*                                               DELTASET  *ds,
*                                               FXRISKSET *FXr) ;
*
*   general     The routine calculates the Risk Position for an
*               arbitrary repo cashflow using a list of predefined
*               shocks to the zero curve.
*
*               The Risk Position is the core input for VAR calculation.*
*               The Risk Position calculated for this position must be
*               added to the total Risk Position. Once this total Risk
*               Position is available VAR can be calculated with the
*               routine VAR_MATRIX2VAR().
*
*               The decision whether to use price or yield vol is
*               signalled in ds->zero. Note that this must be the same
*               for all risk factors encountered in the total VAR
*               calculation.
*
*               The risk factors affecting a fixed cashflow are:
*
*                   Interest Rates (Government, Swap or Money Market)
*                   FX (if Instrument CCY differs from Home CCY)
*
*               These entries are found in the returned RISKPOSLIST
*
*   input       DATESTR   *analys       The analysis date.
*
*               CFLW_STR  *xcflw        The extracted cashflow from
*                                       the relevant period.
*                                       Must have the format defined
*                                       by bond_extract_period().
*                                       Cashflow is NOT adjusted for
*                                       businessdays.
*                                       The outstanding debt on the
*                                       bond must be 100.
*
*               DATESTR   *matur        The maturity date
*
*               PP_STR    *pp           Partly Paid setup. pp->pp_price
*                                       is not used.
*
*               FL64      Notnal        The notional holding (position)
*                                       Amount in Instrument CCY
*
*               DISCFAC   *df           Discounting structure setup.
*                                       The initial (unshocked) curve
*                                       should be in df->disc.
*
*               DFSPREAD  *dfs          Spread against the curve.
*
*               HOLI_STR  *holi         Business adjustment setup
*
*               DELTASET  *ds           Delta vector defining data
*                                       Set with Disc_DeltaPrep()
*
*               FXRISKSET *FXr          Data for FX risk generation
*
*   output
*
*   returns     The Risk Position allocated as:
*
*                         Alloc_RISKTOKENARRAY(ds->nshock + 1) ;
*                         Alloc_FL64ARRAY(ds->nshock + 1) ;
*
*   diagnostics
*
*   see also    Disc_DeltaPrep()
*
*************************************************************************
,,EOH,,*/

RISKPOSLIST RepoCflw_DF2RiskPos(DATESTR* analys,
                                CFLW_STR*  xcflw,
                                DATESTR*   matur,
                                PP_STR*    pp,
                                FL64      Notnal,
                                DISCFAC*   df,
                                DFSPREAD*  dfs,
                                HOLI_STR*  holi,
                                DELTASET*  ds,
                                FXRISKSET* FXr) 
{
    RISKPOSLIST  rpos ;
    FL64ARRAY    dv ;
    FL64         FX, pv, dum, fac, pct ;
    INTI         allocsize, i ;

    /* Initialise */

    FX = (!SCecon_strncmp(FXr->token.ccy, FXr->home, CCY_LENGTH) ? 
            1.0 : FXr->rate) ;

    /* Allocate output */
    allocsize  = rpos.npos = ds->nshock + 1 ;
    rpos.token = Alloc_RISKTOKENARRAY(allocsize) ;
    rpos.pos   = Alloc_FL64ARRAY(allocsize) ;

    /* Generate delta vector */
    dv = RepoCflw_DF2Delta(analys, df, xcflw, matur, pp, holi, dfs, ds) ;

    /* Translate to Risk Position */
    for (i = 0; i < ds->nshock; i++)
    {
        /* dv wrt zeros has already been pct adjusted */
        pct = 100.0 ;

        /* Find adjustment factor */
		fac = Disc_DF2RiskPosFac(analys, df, ds, i, holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */

        /* Do the calculation */
        rpos.pos[i]   = dv[i] * fac * FX * Notnal / pct ;
        VAR_RiskTokenCpy(&rpos.token[i], &ds->token[i]) ;
    }

    /* FX risk contribution - if required */
    VAR_RiskTokenCpy(&rpos.token[ds->nshock], &FXr->token) ;

    if (!SCecon_strncmp(FXr->token.ccy, FXr->home, CCY_LENGTH) == False)
    {
        /* PV in pct in Home CCY */
        pv = RepoCflw_DF2Price(analys, df, xcflw, matur, pp, holi, dfs,
                               NULL, &dum, &dum) ;

        /* Remember FX contribution - PV in Home CCY */
        rpos.pos[ds->nshock] = pv * Notnal * FX / 100.0 ;
    }
    else
        rpos.pos[ds->nshock] = 0.0 ;

    /* Clean up */
    Free_FL64ARRAY(dv) ;

    return rpos ;
}


/*,,SOH,,
*************************************************************************
*
*               Bond_DF2RiskPos()
*
*   interface   #include <riskpos.h>
*               RISKPOSLIST Bond_DF2RiskPos(DATESTR   *analys,
*                                           TRADEINFO *trade,
*                                           FIXPAY    *fixp,
*                                           FL64      Notnal,
*                                           DISCFAC   *df,
*                                           DFSPREAD  *dfs,
*                                           HOLI_STR  *holi,
*                                           DELTASET  *ds,
*                                           FXRISKSET *FXr) ;
*
*   general     The routine calculates the Risk Position for an bond
*               using a list of predefined shocks to the zero curve.
*
*               The Risk Position is the core input for VAR calculation.*
*               The Risk Position calculated for this position must be
*               added to the total Risk Position. Once this total Risk
*               Position is available VAR can be calculated with the
*               routine VAR_MATRIX2VAR().
*
*               The decision whether to use price or yield vol is
*               signalled in ds->zero. Note that this must be the same
*               for all risk factors encountered in the total VAR
*               calculation.
*
*               The risk factors affecting a fixed cashflow are:
*
*                   Interest Rates (Government, Swap or Money Market)
*                   FX (if Instrument CCY differs from Home CCY)
*
*               These entries are found in the returned RISKPOSLIST
*
*   input       DATESTR   *analys       The analysis date.
*
*               TRADEINFO *trade        The position data
*                                       trade->nom is not used
*
*               FIXPAY    *fixp         The bond definition
*
*               FL64      Notnal        The notional holding (position)
*                                       Amount in Instrument CCY
*
*               DISCFAC   *df           Discounting structure setup.
*                                       The initial (unshocked) curve
*                                       should be in df->disc.
*
*               DFSPREAD  *dfs          Spread against the curve.
*
*               HOLI_STR  *holi         Business adjustment setup
*
*               DELTASET  *ds           Delta vector defining data
*                                       Set with Disc_DeltaPrep()
*
*               FXRISKSET *FXr          Data for FX risk generation
*
*   output
*
*   returns     The Risk Position allocated as:
*
*                         Alloc_RISKTOKENARRAY(ds->nshock + 1) ;
*                         Alloc_FL64ARRAY(ds->nshock + 1) ;
*
*   diagnostics
*
*   see also    Disc_DeltaPrep()
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/


RISKPOSLIST Bond_DF2RiskPos(DATESTR* analys,
                            TRADEINFO*  trade,
                            FIXPAY*     fixp,
                            FL64       Notnal,
                            DISCFAC*    df,
                            DFSPREAD*   dfs,
                            HOLI_STR*   holi,
                            DELTASET*   ds,
                            FXRISKSET*  FXr)
{
    CFLWARRAY    xcflw ;
    HOLI_STR     hol ;
    RISKPOSLIST  rpos ;
    FL64         tmp ;
    INTI         idx ;


    /* Initialise */
    tmp = trade->nom ;
    trade->nom = 100.0 ;
    
    /* Extract cflw */
    hol   = bond_set_holi(holi, &fixp->fix) ;
    xcflw = Bond_GenrCflw(trade, fixp, &hol) ;

    /* We are interested in the MV of the bond 
       so AI is removed from the cflw */
    if (xcflw->filled > 0)
    {
        idx = Cldr_FindDateIndex(xcflw->days, xcflw->filled, &trade->settle, 
                                  0, SEARCH_FORWARDS, SAMEINDEX) ;
        if (idx >= 0 && idx < xcflw->filled)
            xcflw->coupon[idx] = 0.0 ;
    }

    /* Calculate RiskPos */
    rpos  = Cflw_DF2RiskPos(analys, xcflw, &fixp->repay.pp, Notnal, df, dfs,
                            holi, ds, FXr) ;
    /* Clean up */
    trade->nom = tmp ;

    /* Free cflw */
    Free_CFLWARRAY(xcflw, 1) ;

    return rpos ;
}


/*,,SOH,,
*************************************************************************
*
*               Deposit_DF2RiskPos()
*
*   interface   #include <riskpos.h>
*               RISKPOSLIST Deposit_DF2RiskPos(DATESTR   *analys,
*                                              DEPOSIT   *depo,
*                                              FL64      Notnal,
*                                              DISCFAC   *df,
*                                              DFSPREAD  *dfs,
*                                              HOLI_STR  *holi,
*                                              DELTASET  *ds,
*                                              FXRISKSET *FXr) ;
*
*   general     The routine calculates the Risk Position for a deposit
*               using a list of predefined shocks to the zero curve.
*
*               The Risk Position is the core input for VAR calculation.*
*               The Risk Position calculated for this position must be
*               added to the total Risk Position. Once this total Risk
*               Position is available VAR can be calculated with the
*               routine VAR_MATRIX2VAR().
*
*               The decision whether to use price or yield vol is
*               signalled in ds->zero. Note that this must be the same
*               for all risk factors encountered in the total VAR
*               calculation.
*
*               The risk factors affecting a fixed cashflow are:
*
*                   Interest Rates (Government, Swap or Money Market)
*                   FX (if Instrument CCY differs from Home CCY)
*
*               These entries are found in the returned RISKPOSLIST
*
*   input       DATESTR   *analys       The analysis date.
*
*               DEPOSIT   *depo         The deposit data
*
*               FL64      Notnal        The notional holding (position)
*                                       Amount in Instrument CCY
*
*               DISCFAC   *df           Discounting structure setup.
*                                       The initial (unshocked) curve
*                                       should be in df->disc.
*
*               DFSPREAD  *dfs          Spread against the curve.
*
*               HOLI_STR  *holi         Business adjustment setup
*
*               DELTASET  *ds           Delta vector defining data
*                                       Set with Disc_DeltaPrep()
*
*               FXRISKSET *FXr          Data for FX risk generation
*
*   output
*
*   returns     The Risk Position allocated as:
*
*                         Alloc_RISKTOKENARRAY(ds->nshock + 1) ;
*                         Alloc_FL64ARRAY(ds->nshock + 1) ;
*
*   diagnostics
*
*   see also    Disc_DeltaPrep()
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/


RISKPOSLIST Deposit_DF2RiskPos(DATESTR* analys,
                               DEPOSIT*    depo,
                               FL64       Notnal,
                               DISCFAC*    df,
                               DFSPREAD*   dfs,
                               HOLI_STR*   holi,
                               DELTASET*   ds,
                               FXRISKSET*  FXr)
{
    CFLWARRAY   cflw ;
    RISKPOSLIST rpos ;
    FIXPAY      fixp ;

    /* Translate deposit into fixpay */
    fixp = Deposit_DEPOSIT2FIXPAY(depo, holi) ;

    /* Extract cash flow */
    cflw = Cflw_GenrCflw(&fixp.repay, &fixp.rday, 
                          &fixp.fix, &fixp.cday, holi) ;
    
    /* Calculate risk positions */
    rpos = Cflw_DF2RiskPos(analys, cflw, &fixp.repay.pp, Notnal, df, 
      dfs, holi, ds, FXr) ;

    /* Free cflw */
    Free_CFLWARRAY(cflw, 1) ;

    return rpos ;
}




/*,,SOH,,
*************************************************************************
*
*               IndexBond_DF2RiskPos()
*
*   interface   #include <riskpos.h>
*               RISKPOSLIST IndexBond_DF2RiskPos(DATESTR     *analys,
*                                                TRADEINFO   *trade,
*                                                INDEXBOND   *idxbond,
*                                                FL64        Notnal,
*                                                INDEXFAC    *idxfac,
*                                                DISCFAC     *df,
*                                                DFSPREAD    *dfs,
*                                                HOLI_STR    *holi,
*                                                BOOLE       indexadj,
*                                                DELTASET    *ds,
*                                                FXRISKSET   *FXr) ;
*
*   general     The routine calculates the Risk Position for an index
*               bond using a list of predefined shocks to the zero
*               curve.
*
*               The Risk Position is the core input for VAR calculation.*
*               The Risk Position calculated for this position must be
*               added to the total Risk Position. Once this total Risk
*               Position is available VAR can be calculated with the
*               routine VAR_MATRIX2VAR().
*
*               The decision whether to use price or yield vol is
*               signalled in ds->zero. Note that this must be the same
*               for all risk factors encountered in the total VAR
*               calculation.
*
*               The risk factors affecting a index bond are:
*
*                   Interest Rates (Government, Swap or Money Market)
*                   FX (if Instrument CCY differs from Home CCY)
*
*               These entries are found in the returned RISKPOSLIST
*
*   input       DATESTR   *analys       The analysis date.
*
*               TRADEINFO *trade        The position data
*                                       trade->nom is not used
*
*               INDEXBOND *idxbond      The index bond definition
*
*               FL64      Notnal        The notional holding (position)
*                                       Amount in Instrument CCY
*
*               INDEXFAC  *idxfac       Index factors
*
*               DISCFAC   *df           Discounting structure setup.
*                                       The initial (unshocked) curve
*                                       should be in df->disc.
*
*               DFSPREAD  *dfs          Spread against the curve.
*
*               HOLI_STR  *holi         Business adjustment setup
*
*               BOOLE     indexadj      False means that the risk
*                                       positions are not adjusted for
*                                       index factors. True means that
*                                       risk positions times the
*                                       relevant index factor is
*                                       returned.
*
*               DELTASET  *ds           Delta vector defining data
*                                       Set with Disc_DeltaPrep()
*
*               FXRISKSET *FXr          Data for FX risk generation
*
*   output
*
*   returns     The Risk Position allocated as:
*
*                         Alloc_RISKTOKENARRAY(ds->nshock + 1) ;
*                         Alloc_FL64ARRAY(ds->nshock + 1) ;
*
*   diagnostics
*
*   see also    Disc_DeltaPrep()
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/

RISKPOSLIST IndexBond_DF2RiskPos(DATESTR*    analys,
                                     TRADEINFO*  trade,
                                     INDEXBOND*  idxbond,
                                     FL64        Notnal,
                                     INDEXFAC*   idxfac,
                                     DISCFAC*    df,
                                     DFSPREAD*   dfs,
                                     HOLI_STR*   holi,
                                     BOOLE       indexadj,
                                     DELTASET*   ds,
                                     FXRISKSET*  FXr)
{
    RISKPOSLIST  rpos ;
    FL64         fac ;
    INTI         i, idx ;
    CFLWARRAY    xcflw ;
    

    /* Generate cashflow */
    xcflw = IndexBond_GenrCflw(trade, idxbond, idxfac, holi) ;

    /* We are interested in the MV of the index bond 
       so AI is removed from the cflw */
    if (xcflw->filled > 0)
    {
        idx = Cldr_FindDateIndex(xcflw->days, xcflw->filled, &trade->settle, 
                                  0, SEARCH_FORWARDS, SAMEINDEX) ;
        if (idx >= 0 && idx < xcflw->filled)
            xcflw->coupon[idx] = 0.0 ;
    }
    
    /* Calculate */
    rpos = Cflw_DF2RiskPos(analys, xcflw, NULL, Notnal, df, dfs, holi, 
                           ds, FXr) ;

    /* Index adjusted price? */
    if (indexadj == False)
    {
        fac = Index_Interpolation(analys, &idxbond->pv_delay, idxfac);

        /* idxfac is always positive !! */
        for (i = 0; i < rpos.npos; i++)
             rpos.pos[i] /= fac ;
    }

    /* Free */
    Free_CFLWARRAY(xcflw, 1) ;

    return rpos ;
}




/*,,SOH,,
*************************************************************************
*
*               IndexLoan_DF2RiskPos()
*
*   interface   #include <riskpos.h>
*               RISKPOSLIST IndexLoan_DF2RiskPos(DATESTR     *analys,
*                                                INDEXLOAN   *idxloan,
*                                                FL64        Notnal,
*                                                INDEXFAC    *debfac,
*                                                INDEXFAC    *crefac,
*                                                DISCFAC     *df,
*                                                DFSPREAD    *dfs,
*                                                HOLI_STR    *holi,
*                                                BOOLE       indexadj,
*                                                DELTASET    *ds,
*                                                FXRISKSET   *FXr) ;
*
*   general     The routine calculates the Risk Position for an index
*               loan using a list of predefined shocks to the zero
*               curve.
*
*               The Risk Position is the core input for VAR calculation.*
*               The Risk Position calculated for this position must be
*               added to the total Risk Position. Once this total Risk
*               Position is available VAR can be calculated with the
*               routine VAR_MATRIX2VAR().
*
*               The decision whether to use price or yield vol is
*               signalled in ds->zero. Note that this must be the same
*               for all risk factors encountered in the total VAR
*               calculation.
*
*               The risk factors affecting a index loan are:
*
*                   Interest Rates (Government, Swap or Money Market)
*                   FX (if Instrument CCY differs from Home CCY)
*
*               These entries are found in the returned RISKPOSLIST
*
*   input       DATESTR   *analys       The analysis date.
*
*               INDEXLOAN *idxloan      The index loan definition
*
*               FL64      Notnal        The notional holding (position)
*                                       Amount in Instrument CCY
*
*               INDEXFAC  *debfac       Debtor index factors
*
*               INDEXFAC  *crefac       Creditor index factors
*
*               DISCFAC   *df           Discounting structure setup.
*                                       The initial (unshocked) curve
*                                       should be in df->disc.
*
*               DFSPREAD  *dfs          Spread against the curve.
*
*               HOLI_STR  *holi         Business adjustment setup
*
*               BOOLE     indexadj      False means that the risk
*                                       positions are not adjusted for
*                                       index factors. True means that
*                                       risk positions times the
*                                       relevant index factor is
*                                       returned.
*
*               DELTASET  *ds           Delta vector defining data
*                                       Set with Disc_DeltaPrep()
*
*               FXRISKSET *FXr          Data for FX risk generation
*
*   output
*
*   returns     The Risk Position allocated as:
*
*                         Alloc_RISKTOKENARRAY(ds->nshock + 1) ;
*                         Alloc_FL64ARRAY(ds->nshock + 1) ;
*
*   diagnostics
*
*   see also    Disc_DeltaPrep()
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/

RISKPOSLIST IndexLoan_DF2RiskPos(DATESTR*    analys,
                                     INDEXLOAN*  idxloan,
                                     FL64        Notnal,
                                     INDEXFAC*   debfac,
                                     INDEXFAC*   crefac,
                                     DISCFAC*    df,
                                     DFSPREAD*   dfs,
                                     HOLI_STR*   holi,
                                     BOOLE       indexadj,
                                     DELTASET*   ds,
                                     FXRISKSET*  FXr)
{
    RISKPOSLIST  rpos ;
    FL64         fac ;
    INTI         i, idx ;
    CFLWARRAY    xcflw ;
    
    /* Generate cashflow */
    xcflw = IndexLoan_GenrCflw(analys, idxloan, debfac, crefac, holi) ;
    
    /* We are interested in the MV of the index loan 
       so AI is removed from the cflw */
    if (xcflw->filled > 0)
    {
        idx = Cldr_FindDateIndex(xcflw->days, xcflw->filled, analys, 
                                  0, SEARCH_FORWARDS, SAMEINDEX) ;
        if (idx >= 0 && idx < xcflw->filled)
            xcflw->coupon[idx] = 0.0 ;
    }

    /* Calculate */
    rpos = Cflw_DF2RiskPos(analys, xcflw, NULL, Notnal, df, dfs, holi, 
                           ds, FXr) ;

    /* Index adjusted price? */
    if (indexadj == False)
    {
        fac = Index_Interpolation(analys, &idxloan->delay, crefac) ;

        /* idxfac is always positive !! */
        for (i = 0; i < rpos.npos; i++)
             rpos.pos[i] /= fac ;
    }

    /* Free */
    Free_CFLWARRAY(xcflw, 1) ;

    return rpos ;
}




/*
Private Functions
*/


FL64 Disc_DF2RiskPosFac(DATESTR* analys,
                        DISCFAC*   df,
                        DELTASET*  ds,
                        INTI      i,
						HOLI_STR* holi)
{
    FL64 shock, trm, fac, disc ;
    INTI qb ;

    /* Initialise */
    qb = disc_set_qbas(ds->freq) ;

    /* This requires mid to be set always */
	disc = Disc_Interpolation(&ds->mid[i], df, holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */

    if (ds->zero == True)
    {
        /* Multiply with the discount factor - also to toggle sign */
        fac   = disc ;
        shock = 1.0 ;
    }
    else
    {
        /* Multiply with the yield - in fractions */
        trm = Cldr_TermBetweenDates(analys, &ds->mid[i], 0, 
                                    df->cal, LAST, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
        fac = TVMunit_Yield(disc, trm, ds->irr, qb) / 100.0 ;
        shock = 0.01 * GetArrayEl(ds->size, i, ds->nshock, 0.01) ;
    }

    if (fabs(shock) > DISC_TOLR)
        return fac / shock ;
    else
        return 0.0 ;
}



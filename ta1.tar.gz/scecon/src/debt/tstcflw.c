/* SCID @(#)tstcflw.c	1.9 (SimCorp) 99/02/19 14:12:36 */

/************************************************************************
*
*   project     SCecon
*
*   filename    cflwtest.c
*
*   this program tests the routines in the cash flow module of SCecon
*
************************************************************************/

/*** includes ***********************************************************/
#include <string.h>
#include <scalloc.h>
#include <str2conv.h>
#include <cflw.h>
#include <bondio.h>
#include <ioconv.h>

/*** prototyping  *******************************************************/


INTI cflwtst1(char *txa, FILE *in, FILE *out) ;
extern int cftest_test_generate(FILE * in, FILE * out) ;
extern int cftest_test_extract(FILE * in, FILE * out) ;
extern int cftest_test_accruint(FILE * in, FILE * out) ;


INTI cflw2test(char* txa, FILE* in, FILE* out)
{
    char      txb[25], txc[25], txd[25], txe[25], txf[25], txpl[64];
    INTI      tot, dexp, dres, dres1, n , ds, i, count, nc, m, term ;
    INTI      j, diff, dif1, exc1, exc2, exp1, exp2, *index ;
    INTL      ymd ;
    FL64      fexp, fres, *repay, *coupon, *erepay, *ecoupon;
    FL64      r1, r2, acc, *eweight, *weight, rate ;
    CALCONV   cal ;
    ODDCONV   odd ;
    YYYYMMDD  dslast, dprev, dsettle, dcoupon, dissue, dmatur;
    DATESTR   daysettle, dayissue, daymatur, daycoupon, dayprev, rd1, rd2,
              daylast ;
    DATESTR   *daytheo, *edaytheo ;
    PMT_STR   *pmtstr, *res, *res1 ;
    PLANARRAY plan, rplan, rplan1, plan2 ;
    BOOLE     ok, brd, okexp ;
    MMDDARRAY mmdd ;
    int       i1, i2, i3 ;
    HOLI_STR  holi ;
    PAYDAYDEF pday ;
    CFLW_STR  cflw, *xcflw ;
    EXRULE    xrule ;
    EXTRADE   xtrade ;
    FIXRATE   fix ;
    PAYDAYSEQ pseq ;
    DATEARRAY couponday ;
    TERMUNIT  unit;

    acc = 0.00001 ;

    diff = -1 ;

    if (!strcmp(txa, "Cflw_Is_Harmonic()"))
    {
        fprintf(out,"?; testing %s\n", txa) ;

        term = Read_INTI(in, out, "");
        unit = Read_TERMUNIT(in, out, "");

        IOUtil_ParseLine(in, out);

        dexp = Read_INTI(in, out, "");
        okexp = Read_BOOLE(in, out, "");

        ok = Cflw_Is_Harmonic(term, unit, &m);

        diff = Write_SingleDiff(ok, okexp, (FL64) m, (FL64) dexp, 
                                acc, out) ;

    }

    else if (!strcmp(txa, "Cflw_Is_Excoupon()"))
    {
        fscanf(in, 
          "%d %ld %ld %d %s",
          &dexp, &dsettle, &dcoupon, &i2, txpl);
        ds = (INTI) i2 ;
        daysettle = Cldr_YMD2Datestr(dsettle);
        daycoupon = Cldr_YMD2Datestr(dcoupon);
        dres = Cflw_Is_Excoupon(&daysettle, &daycoupon, ds);
        diff = (dres != dexp);

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   settlement date  %8ld\n", dsettle) ;
        fprintf(out,"   next coupon date %8ld\n", dcoupon) ;
        fprintf(out,"   ex coupon days   %8d\n", ds) ;
        fprintf(out,"   result is %2d ; expected is %2d\n", dres, dexp) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }

    else if (!strcmp(txa, "Cflw_Is_ExcouponBRD()"))
    {
        fscanf(in, "%d %ld %ld %s", &i1, &dsettle, &dcoupon, txpl);
        dexp = (INTI) i1 ;
        daysettle = Cldr_YMD2Datestr(dsettle);
        daycoupon = Cldr_YMD2Datestr(dcoupon);
        dres = Cflw_Is_ExcouponBRD(&daysettle, &daycoupon);
        diff = (dres != dexp);

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   settlement date  %8ld\n", dsettle) ;
        fprintf(out,"   next coupon date %8ld\n", dcoupon) ;
        fprintf(out,"   result is %2d ; expected is %2d\n", dres, dexp) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }

    else if (!strcmp(txa, "Cflw_Is_Exprincipal()"))
    {
        fscanf(in, "%d %ld %ld %s", &i1, &dsettle, &dcoupon, txpl);
        dexp = (INTI) i1 ;
        daysettle = Cldr_YMD2Datestr(dsettle);
        daycoupon = Cldr_YMD2Datestr(dcoupon);
        dres = Cflw_Is_Exprincipal(&daysettle, &daycoupon);
        diff = (dres != dexp);

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   settlement date     %8ld\n", dsettle) ;
        fprintf(out,"   next principal date %8ld\n", dcoupon) ;
        fprintf(out,"   result is %2d ; expected is %2d\n", dres, dexp) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }

    else if (!strcmp(txa, "Cflw_Is_Date_Ex()"))
    {
        fscanf(in, "%d %ld %d %d %s %s %s",
               &i3, &dsettle, &i1, &i2, txb, txc, txpl);

        dexp = (INTI) i3 ;
        n = (INTI) i1 ;
        ds = (INTI) i2 ;

        fprintf(out,"   testing %s\n", txa) ;
        fprintf(out,"   settlement date    %8ld\n", dsettle) ;
        fprintf(out,"   ex coupon days     %8d\n", ds) ;
        fprintf(out,"   use predef. exdays %8s\n", txb) ;
        fprintf(out,"   BRD rules ?        %8s\n", txc) ;

        ok  = Str2BOOLE(txb) ;
        brd = Str2BOOLE(txc) ;
        daysettle = Cldr_YMD2Datestr(dsettle);

        daytheo  = Alloc_DATEARRAY(n) ;
        edaytheo = Alloc_DATEARRAY(n) ;
        repay    = Alloc_FL64ARRAY(n) ;

        fprintf(out,"   Array data\n") ;
        fprintf(out,"   Paydate   Payment    Exday\n") ;

        for (i = 0 ; i < n ; i++)
        {
            fscanf(in, "%ld %lf", &dcoupon, &repay[i]) ;
            daytheo[i] = Cldr_YMD2Datestr(dcoupon) ;
            fprintf(out,"   %8ld  %5.3lf", dcoupon, repay[i]) ;
            fscanf(in, "%ld", &dcoupon) ;
            edaytheo[i] = Cldr_YMD2Datestr(dcoupon) ;
            fprintf(out,"   %8ld\n", dcoupon) ;
        }

        dres = Cflw_Is_Date_Ex(&daysettle, daytheo, repay, edaytheo, n, ds,
                               ok, brd) ;
        diff = (dres != dexp);

        fprintf(out,"%d;  result is %2d ; expected is %2d\n",
                diff, dres, dexp) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_DATEARRAY(daytheo) ;
        Free_DATEARRAY(edaytheo) ;
        Free_FL64ARRAY(repay) ;
    }

    else if (!strcmp(txa, "Cflw_XdayCalc()"))
    {
        fscanf(in, "%d %ld %ld %ld %ld %s %s %d %s %s %s %d %ld %d %s",
               &dexp, &dsettle, &dprev, &dcoupon, &dslast, txe, txf, &i2,
               txb, txc, txd, &i3, &dmatur, &i1, txpl);

        xrule.cal     = Str2CALCONV(txf) ;
        xrule.exdays  = (INTI) i2 ;
        xrule.caldays = Str2BOOLE(txb) ;
        xrule.xconv   = Str2EXDAYCONV(txc) ;
        xrule.dex     = Cldr_YMD2Datestr(dmatur) ;
        xrule.npday   = (INTI) i1 ;
        xrule.xlast   = Str2BOOLE(txe) ;

        xtrade.spec = False ;
        if (xrule.xconv == EX_FIX)
            xtrade.spec = True ;

        xtrade.ex_fix  = Str2BOOLE(txd) ;

        holi.nholi = (INTI) i3 ;
        holi.bus   = NO_BUSADJUST ;
        holi.holidays = Alloc_DATEARRAY(holi.nholi) ;

        daysettle  = Cldr_YMD2Datestr(dsettle);
        daycoupon  = Cldr_YMD2Datestr(dcoupon);
        dayprev    = Cldr_YMD2Datestr(dprev);
        daylast    = Cldr_YMD2Datestr(dslast) ;

        fprintf(out,"   testing %s\n", txa) ;
        fprintf(out,"   settlement date  %8ld\n", dsettle) ;
        fprintf(out,"   prev coupon date %8ld\n", dprev) ;
        fprintf(out,"   next coupon date %8ld\n", dcoupon) ;
        fprintf(out,"   maturity         %8ld\n", dslast) ;
        fprintf(out,"   calendar         %8s\n", txf) ;
        fprintf(out,"   ex coupon days   %8d\n", i2) ;
        fprintf(out,"   calendardays ?   %8s\n", txb) ;
        fprintf(out,"   xconv            %8s\n", txc) ;
        fprintf(out,"   X is             %8s\n", txd) ;
        fprintf(out,"   Xlast            %8s\n", txe) ;
        fprintf(out,"   dex              %8ld\n", dmatur) ;

        fprintf(out,"   Holidays:\n") ;
        for (i = 0 ; i < holi.nholi ; i++)
        {
            fscanf(in, "%ld", &dcoupon) ;
            holi.holidays[i] = Cldr_YMD2Datestr(dcoupon) ;
            fprintf(out,"   %8ld\n", dcoupon) ;
        }

        xrule.pday  = Alloc_DATEARRAY(i1) ;
        xrule.xpday = Alloc_DATEARRAY(i1) ;

        fprintf(out,"   Ex/Paydays:\n") ;
        for (i = 0 ; i < i1 ; i++)
        {
            fscanf(in, "%ld %ld", &dcoupon, &dmatur) ;
            xrule.pday[i]  = Cldr_YMD2Datestr(dcoupon) ;
            xrule.xpday[i] = Cldr_YMD2Datestr(dmatur) ;
            fprintf(out,"   %8ld %8ld\n", dcoupon, dmatur) ;
        }

        dres = Cflw_XdayCalc(&daysettle, &dayprev, &daycoupon, &daylast,
          &xrule,
                             &xtrade, &holi) ;

        diff = (dres != dexp);

        fprintf(out,"%d; result is %2d ; expected is %2d\n",
                diff, dres, dexp) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_DATEARRAY(holi.holidays) ;
        Free_DATEARRAY(xrule.pday) ;
        Free_DATEARRAY(xrule.xpday) ;
    }

    else if (!strcmp(txa, "Cflw_mmdd2Paydays_count()"))
    {
        fscanf(in, "%d %ld %ld %d %s %s", &i1, &dissue,
               &dmatur, &i2, txb, txpl) ;
        dexp = (INTI) i1 ;
        n = (INTI) i2 ;
        odd  = Str2ODDCONV(txb) ;
        dayissue = Cldr_YMD2Datestr(dissue);
        daymatur = Cldr_YMD2Datestr(dmatur);
        mmdd = Alloc_INTIARRAY(n) ;

        for (i = 0 ; i < n ; i++)
        {
            fscanf(in, "%d", &i1) ;
            mmdd[i] = (INTI) i1 ;
        }
        dres = Cflw_mmdd2Paydays_count(&dayissue, &daymatur, mmdd, n, odd) ;

        diff = (dres != dexp);

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   issue date        %8ld\n", dissue) ;
        fprintf(out,"   maturity date     %8ld\n", dmatur) ;
        fprintf(out,"   odd convention    %s\n", txb) ;
        fprintf(out,"   mmdd's:\n") ;
        for (i = 0 ; i < n ; i++)
            fprintf(out, "   mmdd - %d\n", mmdd[i]) ;

        fprintf(out,"   result is %2d ; expected is %2d\n", dres, dexp) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_INTIARRAY(mmdd) ;
    }

    else if (!strcmp(txa, "Cflw_mmdd2Paydays()"))
    {
        fscanf(in, "%d %ld %ld %d %s %s", &i1, &dissue,
               &dmatur, &i2, txb, txpl);

        dexp = (INTI) i1 ;
        n = (INTI) i2 ;
        odd  = Str2ODDCONV(txb) ;
        mmdd = Alloc_INTIARRAY(n) ;
        for (i = 0 ; i < n ; i++)
        {
            fscanf(in, "%d", &i1) ;
            mmdd[i] = (INTI) i1 ;
        }

        edaytheo = Alloc_DATEARRAY(dexp) ;
        for (i = 0 ; i < dexp ; i++)
        {
           fscanf(in, "%ld", &dcoupon);
           edaytheo[i] = Cldr_YMD2Datestr(dcoupon);
        }

        dayissue = Cldr_YMD2Datestr(dissue);
        daymatur = Cldr_YMD2Datestr(dmatur);
        daytheo  = Cflw_mmdd2Paydays(&dayissue, &daymatur, mmdd, n,
                                     odd, &dres1) ;

        diff = (dexp != dres1) ;

        fprintf(out,"?; testing %s\n", txa) ;
        fprintf(out,"   issue date        %8ld\n", dissue) ;
        fprintf(out,"   maturity date     %8ld\n", dmatur) ;
        fprintf(out,"   odd convention    %s\n", txb) ;
        fprintf(out,"   mmdd's:\n") ;
        for (i = 0 ; i < n ; i++)
            fprintf(out, "   mmdd - %d\n", mmdd[i]) ;

        if (diff)
        {
           fprintf(out, "   you expexted %3d dates:\n", dexp);
           for (i = 0 ; i < dexp ; i++)
               fprintf(out, "   %3d. %8ld\n",
                       i, Cldr_Datestr2YMD(&edaytheo[i]));

           fprintf(out, "   but CFLWTEST found %3d dates:\n", dres1);
           for(i = 0 ; i < dres1 ; i++)
               fprintf(out, "   %3d. %8ld\n",
                       i, Cldr_Datestr2YMD(&daytheo[i]));
        }
        else
        {
            for (i = 0 ; i < dres1 ; i++)
            {
                diff = (Cldr_DateEQ(&daytheo[i], &edaytheo[i]) == False) ;
                fprintf(out,
                  "%d; resulting date[%3d] is %8ld, expected is %8ld\n",
                  
                        diff, i, Cldr_Datestr2YMD(&daytheo[i]),
                        Cldr_Datestr2YMD(&edaytheo[i]));
            }
        }
        fprintf(out,"   %s\n\n", txpl) ;

        Free_DATEARRAY(daytheo);
        Free_DATEARRAY(edaytheo);
        Free_INTIARRAY(mmdd) ;
    }

    else if (!strcmp(txa, "Cflw_PaydaysCount()"))
    {
        fprintf(out,"?; testing %s\n", txa) ;            
        fscanf(in, "%d", &i1) ;

        dexp = (INTI) i1 ;
        pday = Read_PAYDAYDEF(in, out) ;
        holi = Read_HOLI_STR(in, out) ;
        fscanf(in, "%s", txpl) ;
        dres = Cflw_PaydaysCount(&pday, &holi) ;
        diff = (dres != dexp);

        fprintf(out,
          "%d; result is %2d ; expected is %2d\n",
          diff, dres, dexp) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_DATEARRAY(holi.holidays) ;
        Free_PAYDAYDEF(&pday);
    }

    else if (!strcmp(txa, "Cflw_Paydays()"))
    {
        fprintf(out,"?; testing %s\n", txa) ;
        fscanf(in, "%d", &i1) ;

        dexp = (INTI) i1 ;
        pday = Read_PAYDAYDEF(in, out) ;
        holi = Read_HOLI_STR(in, out) ;
        fscanf(in, "%s", txpl) ;
        daytheo = Cflw_Paydays(&pday, &holi, &dres1) ;
        diff = (dres1 != dexp);

        diff = (dexp != dres1) ;

        if (diff)
        {
            fprintf(out, "   you expexted %3d dates:\n", dexp);
            for (i = 0 ; i < dexp ; i++)
            {
                fscanf(in, "%ld", &dissue) ;
                fprintf(out, "   %3d. %8ld\n", i, dissue) ;
            }

            fprintf(out, "1; but CFLWTEST found %3d dates:\n", dres1);
            for(i = 0 ; i < dres1 ; i++)
                fprintf(out, 
                  "   %3d. %8ld\n",
                  i, Cldr_Datestr2YMD(&daytheo[i])) ;
        }
        else
        {
            for (i = 0 ; i < dres1 ; i++)
            {
                fscanf(in, "%ld", &dissue) ;
                rd1 = Cldr_YMD2Datestr(dissue) ;
                dif1 = (Cldr_DateEQ(&daytheo[i], &rd1) == False) ;
                diff = diff || dif1 ;
                fprintf(out,
                  "%d; resulting date[%3d] is %8ld, expected is %8ld\n",
                  
                        dif1, i, Cldr_Datestr2YMD(&daytheo[i]), dissue) ;
            }
        }

        fprintf(out,"   %s\n\n", txpl) ;
        Free_DATEARRAY(daytheo);
        Free_DATEARRAY(holi.holidays) ;
        Free_PAYDAYDEF(&pday);
    }

    else if (!strcmp("Cflw_FractionDebt()", txa))
    {
        fscanf(in, "%d %s", &i1, txpl);
        n = (INTI) i1 ;

        repay  = Alloc_FL64ARRAY(n);
        eweight = Alloc_FL64ARRAY(n);
        for (i = 0 ; i < n ; i++)
            fscanf(in,"%lf %lf", &eweight[i], &repay[i]);

        weight = Cflw_FractionDebt(repay, n) ;

        fprintf(out,"?; testing %s\n", txa) ;
        fprintf(out,"   number of payments %8d\n", n) ;
        fprintf(out,"   the repayment schedule is...\n") ;
        for (i = 0 ; i < n ; i++)
            fprintf(out,"   repayment[%2d] %10.5lf\n", i, repay[i]) ;

        diff = 0 ;
        for (i = 0 ; i < n ; i++)
        {
            dif1 = (fabs(weight[i] - eweight[i]) > acc) ;
            diff = (dif1 ? 1 : diff) ;
            fprintf(out,"%d; result[%2d] %8.5lf ; expected[%2d] %8.5lf\n",
                        diff, i, weight[i], i, eweight[i]);
        }
        fprintf(out,"   %s\n\n", txpl) ;

        Free_FL64ARRAY(eweight);
        Free_FL64ARRAY(weight);
        Free_FL64ARRAY(repay);
    }



    else if (!strcmp("Cflw_ExtractCflw()", txa))
    {
        fscanf(in, "%ld %ld %d %d %s %s %s %s %s", &dprev, &dmatur, &i1,
                               &i2, txb, txc, txd, txe, txpl) ;
        n = (INTI) i1 ;
        count = (INTI) i2 ;
        exc1 = Str2BOOLE(txb) ;
        exp1 = Str2BOOLE(txc) ;
        exc2 = Str2BOOLE(txd) ;
        exp2 = Str2BOOLE(txe) ;

        dayprev  = Cldr_YMD2Datestr(dprev) ;
        daymatur = Cldr_YMD2Datestr(dmatur) ;

        repay    = Alloc_FL64ARRAY(n) ;
        coupon   = Alloc_FL64ARRAY(n) ;
        daytheo  = Alloc_DATEARRAY(n) ;

        fprintf(out,"?; testing %s\n", txa) ;
        fprintf(out,"   previous pay day   %8ld\n", dprev) ;
        fprintf(out,"   maturity           %8ld\n", dmatur) ;
        fprintf(out,"   ex coupon start    %8s\n", txb) ;
        fprintf(out,"   ex principal start %8s\n", txc) ;
        fprintf(out,"   ex coupon end      %8s\n", txd) ;
        fprintf(out,"   ex principal end   %8s\n", txe) ;

        fprintf(out,"   the initial cash flow is...\n") ;
        fprintf(out,"       date  repayment   coupon\n") ;
        for (i = 0 ; i < n ; i++)
        {
            fscanf(in, "%ld %lf %lf", &dsettle, &repay[i], &coupon[i]) ;
            daytheo[i] = Cldr_YMD2Datestr(dsettle) ;
            fprintf(out,"   %8ld %9.5lf %9.5lf\n",
                                         dsettle, repay[i], coupon[i]) ;
        }
        cflw.filled = n ;
        cflw.days   = daytheo ;
        cflw.repay  = repay ;
        cflw.coupon = coupon ;

        HOLI_STR* sceholi = NULL;
        xcflw = Cflw_ExtractCflw(&dayprev, &daymatur, &cflw,
            0, exc1, exp1, exc2, exp2, sceholi);
        /*PMSTA-40263-ARUN-29102020*/

        tot = xcflw->filled ;
        edaytheo = xcflw->days ;
        ecoupon  = xcflw->coupon ;
        erepay   = xcflw->repay ;

        if (tot == count)
        {
            diff = 0 ;

            fprintf(out,"   expected                       computed\n") ;
            fprintf(out,
"       date repayment    coupon       date repayment    coupon \n")
              ;
            for (i = 0 ; i < count ; i++)
            {
                fscanf(in, "%ld %lf %lf", &dsettle, &r1, &r2) ;
                daysettle = Cldr_YMD2Datestr(dsettle) ;
                dif1 = ((Cldr_DateEQ(&daysettle, &edaytheo[i]) == False) ||
                        (fabs(erepay[i] - r1) > acc) ||
                        (fabs(ecoupon[i] - r2) > acc));
                fprintf(out, 
                  "%d; %8ld %9.5lf %9.5lf ; %8ld %9.5lf %9.5lf\n",
                  
                        dif1, dsettle, r1, r2, 
                        Cldr_Datestr2YMD(&edaytheo[i]),
                        erepay[i], ecoupon[i]) ;
                diff = dif1 || diff ;
            }
        }
        else
        {
            diff = 1 ;
            fprintf(out, "%d; Cflw_ExtractCflw(", diff);
            fprintf(out, "%ld, %ld, %2d, %2d, %2d, %2d",
                    dprev, dmatur, exc1, exp1, exc2, exp2);
            fprintf(out, ") = %d payments  expected = %d %s\n",
                    tot, count, txpl) ;

            fprintf(out, 
              "   you expected this cash flow containing %d payments\n",
              count) ;
            fprintf(out, "        day    repay    coupon\n") ;
            for (i = 0 ; i < count ; i++)
            {
                fscanf(in, "%ld %lf %lf", &dsettle, &r1, &r2) ;
                fprintf(out,"   %8ld %9.5lf %9.5lf\n", dsettle, r1, r2) ;
            }

            fprintf(out, 
"   but SCecon computed this cash flow containing %d payments\n",
              tot) ;
            fprintf(out, "        day    repay    coupon\n") ;
            for (i = 0 ; i < tot ; i++)
                fprintf(out, "%d; %8ld %9.5lf %9.5lf\n", 1,
                        Cldr_Datestr2YMD(&edaytheo[i]), erepay[i],   
                        ecoupon[i])
                          ;
        }
        fprintf(out,"   %s\n\n", txpl) ;

        Free_FL64ARRAY(repay) ;
        Free_FL64ARRAY(coupon) ;
        Free_DATEARRAY(daytheo) ;
        Free_CFLWARRAY(xcflw, 1) ;
    }
    else if (!strcmp("Cflw_DebtPerDate()", txa))
    {
        fscanf(in, "%lf %ld %d %s %s", &fexp, &dsettle, &i1, txb, txpl) ;
        n = (INTI) i1 ;
        daysettle = Cldr_YMD2Datestr(dsettle) ;
        exp1 = Str2BOOLE(txb) ;
        daytheo = Alloc_DATEARRAY(n) ;
        repay   = Alloc_FL64ARRAY(n) ;

        for (i = 0 ; i < n ; i++)
        {
            fscanf(in, "%ld %lf", &dprev, &repay[i]) ;
            daytheo[i] = Cldr_YMD2Datestr(dprev) ;
        }
        fres = Cflw_DebtPerDate(&daysettle, n, daytheo, repay, exp1, 0) ;

        diff = (fabs(fres - fexp) > acc) ;

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   settlement date    %8ld\n", dsettle) ;
        fprintf(out,"   number of payments %8d\n", n) ;
        fprintf(out,"   ex principal       %8s\n", txb) ;
        fprintf(out,"   input repayment schedule is...\n") ;
        fprintf(out,"       date repayment\n") ;
        for (i = 0 ; i < n ; i++)
            fprintf(out,"   %8ld %9.5lf\n",
                                   Cldr_Datestr2YMD(&daytheo[i]), repay[i]);
        fprintf(out,
          "   result is %9.5lf ; expected is %9.5lf\n",
          fres, fexp) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_FL64ARRAY(repay) ;
        Free_DATEARRAY(daytheo) ;
    }

    else if (!strcmp("Cflw_NormCashflow()", txa))
    {
        fscanf(in, "%d %s", &i1, txpl) ;
        n = (INTI) i1 ;
        coupon  = Alloc_FL64ARRAY(n) ;
        repay   = Alloc_FL64ARRAY(n) ;
        ecoupon = Alloc_FL64ARRAY(n) ;
        erepay  = Alloc_FL64ARRAY(n) ;

        for (i = 0 ; i < n ; i++)
            fscanf(in, "%lf %lf %lf %lf", &coupon[i],  &repay[i],
                                          &ecoupon[i], &erepay[i]) ;

        fprintf(out,"?; testing %s\n", txa) ;
        fprintf(out,"   number of payments %8d\n", n) ;
        fprintf(out,"   initial payments are...\n") ;
        fprintf(out,"      coupon repayment\n") ;
        for (i = 0 ; i < n ; i++)
            fprintf(out,"   %9.5lf %9.5lf\n", coupon[i], repay[i]) ;

        Cflw_NormCashflow(n, coupon, repay) ;

        fprintf(out,"   expected             computed\n") ;
        fprintf(out,"   repayment   coupon ; repayment   coupon\n") ;
        diff = 0 ;

        for (i = 0 ; i < n ; i++)
        {
            dif1 = ((fabs(repay[i] - erepay[i]) > acc) ||
                    (fabs(coupon[i] - ecoupon[i]) > acc)) ;
            fprintf(out,"%d; %9.5lf %8.5lf ; %9.5lf %8.5lf\n",
                    dif1, erepay[i], ecoupon[i], repay[i], coupon[i]) ;
            diff = (diff || dif1) ;
        }
        fprintf(out,"   %s\n\n", txpl) ;

        Free_FL64ARRAY(repay) ;
        Free_FL64ARRAY(coupon) ;
        Free_FL64ARRAY(erepay) ;
        Free_FL64ARRAY(ecoupon) ;
    }

    else if (!strcmp("Cflw_MergePMTARRAY()", txa))
    {
        fscanf(in, "%d %d %s", &i1, &i2, txpl);
        count = (INTI) i1 ;
        n     = (INTI) i2 ;

        pmtstr = Alloc_PMTARRAY(n, 50) ;
        res    = Alloc_PMTARRAY(1, 100) ;
        index  = Alloc_INTIARRAY(count) ;
        weight = Alloc_FL64ARRAY(count) ;

        for (i = 0 ; i < count ; i++)
        {
            fscanf(in, "%d %lf", &i1, &weight[i]) ;
            index[i] = (INTI) i1 ;
        }
        fprintf(out,"?; testing %s\n", txa) ;
        fprintf(out,"   number of cash flows %4d\n", n) ;
        fprintf(out,"   input cashflows...\n") ;

        for (i = 0 ; i < n ; i++)
        {
            fscanf(in, "%d", &i1) ;
            pmtstr[i].count =(INTI) i1 ;

            fprintf(out,"       term   payment\n") ;

            for (j = 0 ; j < pmtstr[i].count ; j++)
            {
                fscanf(in, "%lf %lf",
                           &pmtstr[i].term[j], &pmtstr[i].payment[j]) ;
                fprintf(out,"   %8.5lf %10.5lf\n",
                           pmtstr[i].term[j], pmtstr[i].payment[j]) ;
            }
        }
        fscanf(in, "%d", &i1) ;
        res[0].count = (INTI) i1 ;
        for (j = 0 ; j < res[0].count ; j++)
            fscanf(in, "%lf %lf", &res[0].term[j], &res[0].payment[j]) ;

        res1 = Cflw_MergePMTARRAY(pmtstr, index, weight, count) ;

        if (res[0].count == res1->count)
        {
            dif1 = diff = 0 ;
            fprintf(out, "   expected             computed\n") ;
            fprintf(out, "       term   payment       term   payment\n") ;
            for (i = 0 ; i < res[0].count ; i++)
            {
                r1 = res[0].term[i] ;
                r2 = res1->term[i] ;
                dif1 = (fabs(r1 - r2) > acc) ;
                r1 = res[0].payment[i] ;
                r2 = res1->payment[i] ;
                dif1 = dif1 || (fabs(r1 - r2) > acc);
                fprintf(out, "%d; %8.5lf %9.5lf ; %8.5lf %9.5lf\n",
                        dif1, res[0].term[i], res[0].payment[i],
                        res1->term[i], res1->payment[i]) ;
                diff = dif1 || diff ;
            }
        }
        else
        {
            diff = 1 ;
            fprintf(out, "   you expected these %d payments\n",
                                                      res[0].count) ;
            fprintf(out, "    term     payment\n") ;
            for (i = 0 ; i < res[0].count ; i++)
                fprintf(out, "   %lf %lf\n",
                              res[0].term[i], res[0].payment[i]) ;
            fprintf(out, "   but SCecon computed these %d payments\n",
                                                      res1->count) ;
            fprintf(out, "    term     payment\n") ;
            for (i = 0 ; i < res1->count ; i++)
                fprintf(out, "%d; %lf %lf\n",
                        diff, res1->term[i], res1->payment[i]) ;

        }
        fprintf(out,"   %s\n\n", txpl) ;

        Free_PMTARRAY(pmtstr, n) ;
        Free_PMTARRAY(res, 1) ;
        Free_PMTARRAY(res1, 1) ;
        Free_INTIARRAY(index) ;
        Free_FL64ARRAY(weight) ;
    }

    else if (!strcmp("Cflw_MergePLANARRAY()", txa))
    {
        fscanf(in, "%d %d %s", &i1, &i2, txpl);
        count = (INTI) i1 ;
        n     = (INTI) i2 ;

        plan   = Alloc_PLANARRAY(n, 50) ;
        rplan  = Alloc_PLANARRAY(1, 100) ;
        index  = Alloc_INTIARRAY(count) ;
        weight = Alloc_FL64ARRAY(count) ;
        rplan[0].count = 100 ;

        for (i = 0 ; i < count ; i++)
        {
            fscanf(in, "%d %lf", &i1, &weight[i]) ;
            index[i] = (INTI) i1 ;
        }
        fprintf(out,"?; testing %s\n", txa) ;
        fprintf(out,"   number of cash flows %4d\n", n) ;
        fprintf(out,"   input cashflows...\n") ;

        for (i = 0 ; i < n ; i++)
        {
            fscanf(in, "%d", &i1) ;
            plan[i].count = plan[i].filled = (INTI) i1 ;

            fprintf(out,"       term   payment\n") ;
            for (j = 0 ; j < plan[i].count ; j++)
            {
                fscanf(in, "%ld %lf", &dprev, &plan[i].f64[j]) ;
                plan[i].day[j] = Cldr_YMD2Datestr((YYYYMMDD) dprev) ;

                fprintf(out,"   %8ld %10.5lf\n", dprev, plan[i].f64[j]) ;
            }
        }

        fscanf(in, "%d", &i1) ;
        rplan[0].filled = (INTI) i1 ;
        for (j = 0 ; j < rplan[0].count ; j++)
        {
            fscanf(in, "%ld %lf", &dprev, &rplan[0].f64[j]) ;
            rplan[0].day[j] = Cldr_YMD2Datestr((YYYYMMDD) dprev) ;
        }

        rplan1 = Cflw_MergePLANARRAY(plan, index, weight, count) ;

        if (rplan[0].filled == rplan1->filled)
        {
            dif1 = diff = 0 ;
            fprintf(out, "   expected             computed\n") ;
            fprintf(out, "       day    payment       day    payment\n") ;
            for (i = 0 ; i < rplan[0].filled ; i++)
            {
                rd1 = rplan[0].day[i] ;
                rd2 = rplan1->day[i] ;
                dif1 = Cldr_DateEQ(&rd1, &rd2) == False ; ;
                r1 = rplan[0].f64[i] ;
                r2 = rplan1->f64[i] ;
                dif1 = dif1 || (fabs(r1 - r2) > acc);
                fprintf(out, "%d; %8ld %9.5lf ; %8ld %9.5lf\n",
                        dif1, Cldr_Datestr2YMD(&rd1), rplan[0].f64[i],
                              Cldr_Datestr2YMD(&rd2), rplan1->f64[i]) ;
                diff = dif1 || diff ;
            }
        }
        else
        {
            diff = 1 ;
            fprintf(out, "   you expected these %d payments\n",
                                                      rplan[0].filled) ;
            fprintf(out, "    term     payment\n") ;
            for (i = 0 ; i < rplan[0].filled ; i++)
                fprintf(out, "   %ld %lf\n",
                        Cldr_Datestr2YMD(&rplan[0].day[i]),rplan[0].f64[i]);
            fprintf(out, "   but SCecon computed these %d payments\n",
                                                      rplan1->filled) ;
            fprintf(out, "    term     payment\n") ;
            for (i = 0 ; i < rplan1->filled ; i++)
                fprintf(out, "%d; %ld %lf\n",
                        diff, Cldr_Datestr2YMD(&rplan1->day[i]),
                          rplan1->f64[i]) ;

        }
        fprintf(out,"   %s\n\n", txpl) ;

        Free_PLANARRAY(plan, n) ;
        Free_PLANARRAY(rplan, 1) ;
        Free_PLANARRAY(rplan1, 1) ;
        Free_INTIARRAY(index) ;
        Free_FL64ARRAY(weight) ;
    }

    else if (!strcmp("Cflw_ProjectPLANARRAY()", txa))
    {
        fscanf(in, "%d %d %lf %s %s", &i1, &i2, &rate, txc, txpl);

        cal = Str2CALCONV(txc) ;
        count = (INTI) i1 ;
        n     = (INTI) i2 ;

        fprintf(out,"?; testing %s\n", txa) ;
        fprintf(out,"   calendar             %s\n", txc) ;
        fprintf(out,"   rate                 %8lf\n", rate) ;
        fprintf(out,"   Input flow\n") ;

        plan    = Alloc_PLANARRAY(2, 100) ;
        daytheo = Alloc_DATEARRAY(n) ;
        plan[1].count = plan[0].count = 100 ;

        for (i = 0 ; i < count ; i++)
        {
            fscanf(in, "%ld %lf", &dprev, &plan[0].f64[i]) ;
            plan[0].day[i] = Cldr_YMD2Datestr((YYYYMMDD) dprev) ;
            fprintf(out, "%ld %lf\n", dprev, plan[0].f64[i]) ;
        }
        plan[0].filled = count ;

        for (i = 0 ; i < n ; i++)
        {
            fscanf(in, "%ld %lf", &dprev, &plan[1].f64[i]) ;
            plan[1].day[i] = Cldr_YMD2Datestr((YYYYMMDD) dprev) ;
            daytheo[i] = plan[1].day[i] ;
        }
        plan[1].filled =  n ;
		holi = Read_HOLI_STR(in, out);  	/* PMSTA-22396 - SRIDHARA � 160502 */
		plan2 = Cflw_ProjectPLANARRAY(&plan[0], daytheo, n, cal, rate, &holi);

        if (plan[1].filled == plan2->filled)
        {
            dif1 = diff = 0 ;
            fprintf(out, "   expected             computed\n") ;
            fprintf(out, "       day    payment       day    payment\n") ;
            for (i = 0 ; i < plan2->filled ; i++)
            {
                rd1  = plan[1].day[i] ;
                rd2  = plan2->day[i] ;
                dif1 = Cldr_DateEQ(&rd1, &rd2) == False ; ;
                r1   = plan[1].f64[i] ;
                r2   = plan2->f64[i] ;
                dif1 = dif1 || (fabs(r1 - r2) > acc);
                fprintf(out, "%d; %8ld %9.5lf ; %8ld %9.5lf\n",
                        dif1, Cldr_Datestr2YMD(&rd1), plan[1].f64[i],
                              Cldr_Datestr2YMD(&rd2), plan2->f64[i]) ;
                diff = dif1 || diff ;
            }
        }
        else
        {
            diff = 1 ;
            fprintf(out, "   you expected these %d payments\n",
                                                      plan[1].filled) ;
            fprintf(out, "    term     payment\n") ;
            for (i = 0 ; i < plan[1].filled ; i++)
                fprintf(out, "   %ld %lf\n",
                        Cldr_Datestr2YMD(&plan[1].day[i]), plan[1].f64[i]);
            fprintf(out, "   but SCecon computed these %d payments\n",
                                                      plan2->filled) ;
            fprintf(out, "    term     payment\n") ;
            for (i = 0 ; i < plan2->filled ; i++)
                fprintf(out, "%d; %ld %lf\n",
                        diff, Cldr_Datestr2YMD(&plan2->day[i]), 
                        plan2->f64[i]);
        }
        fprintf(out,"   %s\n\n", txpl) ;

        Free_DATEARRAY(daytheo) ;
        Free_PLANARRAY(plan, 2) ;
        Free_PLANARRAY(plan2, 1) ;
		Free_DATEARRAY(holi.holidays);   	/* PMSTA-22396 - SRIDHARA � 160502 */
    }

    else if (!strcmp("Cflw_FindNextPmt()", txa))
    {
        fscanf(in, "%d %d %d %s", &i1, &i2, &i3, txpl);
        dexp = (INTI) i1 ;
        n = (INTI) i2 ;
        count = (INTI) i3 ;

        repay = Alloc_FL64ARRAY(n) ;
        for (i = 0 ; i < n ; i++)
            fscanf(in, "%lf", &repay[i]) ;

        dres = Cflw_FindNextPmt(repay, n, count) ;
        diff = (dres != dexp) ;

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   number of payments %8d\n", n) ;
        fprintf(out,"   start index        %8d\n", count) ;
        fprintf(out,"   input payment schedule is...\n") ;
        fprintf(out,"   date repayment\n") ;
        for (i = 0 ; i < n ; i++)
            fprintf(out,"   %4d %9.5lf\n", i, repay[i]) ;
        fprintf(out,"   result is %2d ; expected is %2d\n", dres, dexp) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_FL64ARRAY(repay) ;
    }

    else if (!strcmp("Cflw_FindPrevPmt()", txa))
    {
        fscanf(in, "%d %d %d %s", &i1, &i2, &i3, txpl);
        dexp = (INTI) i1 ;
        n = (INTI) i2 ;
        count = (INTI) i3 ;

        repay = Alloc_FL64ARRAY(n) ;
        for (i = 0 ; i < n ; i++)
            fscanf(in, "%lf", &repay[i]) ;

        dres = Cflw_FindPrevPmt(repay, n, count) ;
        diff = (dres != dexp) ;

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   number of payments %8d\n", n) ;
        fprintf(out,"   start index        %8d\n", count) ;
        fprintf(out,"   input payment schedule is...\n") ;
        fprintf(out,"   date repayment\n") ;
        for (i = 0 ; i < n ; i++)
            fprintf(out,"   %4d %9.5lf\n", i, repay[i]) ;
        fprintf(out,"   result is %2d ; expected is %2d\n", dres, dexp) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_FL64ARRAY(repay) ;
    }

    else if (!strcmp("Cflw_GenrCflw()", txa))
    {
        fprintf(out,"?; testing %s\n", txa) ;
        diff = cftest_test_generate(in, out) ;
    }

    else if (!strcmp("Cflw_ExtractPeriod()", txa))
    {
        fprintf(out,"?; testing %s\n", txa) ;
        diff = cftest_test_extract(in, out) ;
    }

    else if (!strcmp("Cflw_Accruint()", txa))
    {
        fprintf(out,"?; testing %s\n", txa) ;
        diff = cftest_test_accruint(in, out) ;
    }

    else if (!strcmp("Cflw_GenrCouponRates()", txa))
    {
        fix = Read_FIXRATE(in, out);

        pseq = Read_PAYDAYSEQ(in, out) ;

        IOUtil_ParseLine(in, out);

        fscanf(in, "%d", &nc);
        ecoupon = Alloc_FL64ARRAY(nc);
        couponday = Alloc_DATEARRAY(nc);
        for (i = 0 ; i < nc ; i++)
        {
            fscanf(in, "%ld %lf", &ymd, &ecoupon[i]) ;
            couponday[i] = Cldr_YMD2Datestr(ymd) ;
        }

		/* PMSTA-22396 - SRIDHARA � 160502 */
		holi = Read_HOLI_STR(in, out);
		coupon = Cflw_GenrCouponRates(&fix, couponday, nc, &pseq, &holi);

        diff = 0 ;
        for (i = 0 ; i < nc ; i++)
            diff = (diff || (fabs(coupon[i] - ecoupon[i]) > acc)) ;

        fprintf(out,"   the %d coupon payments are\n", nc) ;
        fprintf(out,"       date computed  expected\n") ;

        for (i = 0 ; i < nc ; i++)
            fprintf(out,"%d; %8ld %8.5lf ; %8.5lf\n",
                    fabs(coupon[i] - ecoupon[i]) > acc,
                    Cldr_Datestr2YMD(&couponday[i]), coupon[i], ecoupon[i]) ;

        Free_FL64ARRAY(ecoupon) ;
        Free_FL64ARRAY(coupon) ;
        Free_DATEARRAY(couponday) ;
        Free_PLANARRAY(fix.irreg, 1);
        Free_PLANARRAY(fix.stepcoup, 1);
		Free_DATEARRAY(holi.holidays);   	/* PMSTA-22396 - SRIDHARA � 160502 */
    }

    /* Look in cflwtst1 for other functions */
    if (diff == -1)
        diff = cflwtst1(txa, in, out) ;

    return diff ;
}

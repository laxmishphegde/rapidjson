/* SCCS @(#)cflw.c	1.9 (SimCorp) 99/11/08 12:03:12 */

/************************************************************************
*
*   project     SCecon
*
*   filename    cflw.c
*
*   general     This file contains standard cash flow routines
*
************************************************************************/

/* includes ************************************************************/
#include <cflw.h>


/*,,SOH,,
*************************************************************************
*
*                Cflw_Insert_In_Cflw()
*
*    interface   #include <cflw.h>
*                INTI Cflw_Insert_In_Cflw(DATESTR   *date,
*                                         FL64      amort,
*                                         FL64      coupon,
*                                         CFLW_STR  *cflw) ;
*
*    general     The function inserts a payment in a CFLW_STR.
*
*                If no space is available (filled == count in plan)
*                then nothing is done unless the date is already in
*                the flow.
*
*                If date is already in flow then an addition is
*                performed.
*
*    input       DATESTR   *date     Pointer to input date.
*
*                FL64      amort     The amortisation
*
*                FL64      coupon    The coupon
*
*                CFLW_STR  *cflw     Cashflow
*                                    NULL or ->filled = 0 for empty
*
*    output
*
*    returns     Number of filled data in the plan.
*
*    diagnostics
*
*    see also
*
*************************************************************************
,,EOH,,*/

INTI Cflw_Insert_In_Cflw(DATESTR*   date,
                             FL64       amort, 
                             FL64       coupon,
                             CFLW_STR*  cflw)
{
    DATESTR  *pdays ;
    FL64     *pamort, *pcoupon ;
    INTI     i, ix, nfill, ncount ;
    BOOLE    space ;

    space = True ;

    pdays   = GetCflwDays(cflw) ;
    pamort  = GetCflwRepay(cflw) ;
    pcoupon = GetCflwCoupon(cflw) ;
    nfill   = GetCflwFill(cflw) ;
    ncount  = GetCflwCount(cflw) ;

    /* check sizes first */
    if (nfill >= ncount)
        space = False ;
    if (ncount <= 0)
        space = False ;

    if (space == True)
    {
        /* Find index of next element */
        ix = Cldr_FindDateIndex(pdays, nfill, date, 0,
                                 SEARCH_BISECTION, SAMEINDEX) ;

        /* After the last ?? */
        if (ix >= nfill)
        {
            if (nfill < ncount)
            {
                pamort[nfill]  = amort ;
                pcoupon[nfill] = coupon ;

                if (date != NULL)
                    pdays[nfill] = *date ;
                else
                    pdays[nfill] = Cldr_YMD2Datestr((YYYYMMDD) 0) ;

                cflw->filled++, nfill++ ;
            }
        }

        /* Equal to an element */
        else if (Cldr_DateEQ(date, &pdays[ix]) == True)
        {
            /* Add */
            pamort[ix]  += amort ;
            pcoupon[ix] += coupon ;
        }

        /* Just insert and move upwards */
        else
        {
            if (nfill < ncount)
            {
                for (i = nfill - 1 ; i >= ix ; i--)
                {
                    pamort[i + 1]  = pamort[i] ;
                    pcoupon[i + 1] = pcoupon[i] ;
                    pdays[i + 1]   = pdays[i] ;
                }

                pamort[ix]  = amort ;
                pcoupon[ix] = coupon ;

                if (date != NULL)
                    pdays[ix] = *date ;
                else
                    pdays[nfill] = Cldr_YMD2Datestr((YYYYMMDD) 0) ;

                cflw->filled++, nfill++ ;
            }
        }
    }

    return nfill ;
}


/*,,SOH,,
*************************************************************************
*
*               Cflw_ExtractCflw()
*
*   interface   #include <cflw.h>
*               CFLWARRAY Cflw_ExtractCflw(DATESTR   *date1,
*                                           DATESTR   *date2,
*                                           CFLW_STR  *cflw,
*                                           INTI      start,
*                                           BOOLE     exc1,
*                                           BOOLE     exp1,
*                                           BOOLE     exc2,
*                                           BOOLE     exp2) ;
*
*   general     The function extracts the cashflow in the period from
*               date1 to date2. The input cashflow is in cflw.
*
*               The function considers the problems of ex-coupon
*               and ex-principal in both ends.
*
*               The input cashflow must be normalized to an initial
*               outstanding debt of 100.
*
*               The coupons are in percent per initial outstanding.
*
*               The output extracted cashflow is renormalized to 100
*               per date1.
*
*               The function does not calculate accrued interest, for a
*               function that combines extracting and accrued calcula-
*               tion see Cflw_ExtractPeriod().
*
*   input       DATESTR    *date1 Pointer to the first date.
*
*               DATESTR    *date2 Pointer to the last date.
*
*               CFLW_STR   *cflw  The input cashflow.
*
*               INTI       start  The index for the first payment after
*                                 date1. This must be the firstcoming
*                                 even if the bond is ex-coupon or
*                                 ex-principal per date1.
*                                 If this index is not known just use
*                                 start = 0 as input.
*
*               BOOLE      exc1   True if the bond is ex-coupon per
*                                 date1, otherwise False.
*
*               BOOLE      exp1   True if the bond is ex-principal per
*                                 date1, otherwise False.
*
*               BOOLE      exc2   True if the bond is ex-coupon per
*                                 date2, otherwise False.
*
*               BOOLE      exp2   True if the bond is ex-principal per
*                                 date2, otherwise False.
*
*   output
*
*   returns     The extracted cashflow allocated in this routine as:
*               Alloc_CFLWARRAY(1, cflw->filled + 2)
*
*   diagnostics
*
*   see also    Cflw_ExtractPeriod()
*               Cflw_GenrCflw()
*               Cflw_XdayCalc()
*
*************************************************************************
,,EOH,,*/


CFLWARRAY Cflw_ExtractCflw(DATESTR* date1,
    DATESTR*    date2,
    CFLW_STR*   cflw,
    INTI       start,
    BOOLE      exc1,
    BOOLE      exp1,
    BOOLE      exc2,
    BOOLE      exp2,
    HOLI_STR*    holi)
{
    INTI      next, next_coupon, next_amort, j, idx, i, uploop;
    INTI      n, idx0, set, k, prev_amort, prev_coupon;
    BOOLE     exc1o, exp1o;
    FL64      tol, scale1, scale, scale0, sum, sum1;
    DATESTR   *pdays, *edays;
    FL64      *rates, *amort, *coupon, *erates, *eamort, *ecoupon;
    CFLWARRAY xcflw;

    /* warning avoidance */
    next = 0;

    /* Pick pointers and allocate sufficient memory */
    pdays = cflw->days;
    coupon = cflw->coupon;   /* PMSTA10118 - DDV - 100628 - change rates and erates with coupon and ecoupon */
    rates = cflw->ratesTab; /* PMSTA10118 - DDV - 100628 - set the rate into cflw */
    amort = cflw->repay;
    n = cflw->filled;

    xcflw = Alloc_CFLWARRAY(1, n + 2);

    edays = xcflw->days;
    eamort = xcflw->repay;
    ecoupon = xcflw->coupon; /* PMSTA10118 - DDV - 100628 - change rates and erates with coupon and ecoupon */
    erates = xcflw->ratesTab;/* PMSTA10118 - DDV - 100628 - set the rate into cflw */
    xcflw->count = n + 2;

    /* Initialize */
    exc1o = exc1;
    exp1o = exp1;
    sum1 = sum = 0.0;
    tol = PMT_TOL;

    /* First find the index for the first payment after date1 that are relevant
       and remember the sum that is needed to renorm the cashflow. */

    idx = Cldr_FindDateIndex(pdays, n, date1, start,
        SEARCH_FORWARDS, NEXTINDEX);
    idx0 = idx;

    uploop = idx - 1;
    for (i = 0; i <= uploop; i++)
        sum += amort[i];
    sum1 = sum;

    /* Find index for next amortization and next coupon payment - for
       regular cashflows these indices are always equal to idx */

    next_coupon = Cflw_FindNextPmt(coupon, n, idx - 1); /* PMSTA10118 - DDV - 100628 - change rates and erates with coupon and ecoupon */
    next_amort = Cflw_FindNextPmt(amort, n, idx - 1);

    if (next_amort < n && exp1 == True)
        sum += amort[next_amort];

    /* Now loop over all payments that are prior to the ultimo date.
       remember to renorm the cashflow. Also handle the ex-coupon/ex-principal
       in connection with the first payment. Scale is the factor that assures
       that the cashflow is normed correctly. */

    j = -1;
    scale = (fabs(sum - 100.0) > tol ? 100.0 / (100.0 - sum) : 0.0);
    scale0 = (fabs(sum1 - 100.0) > tol ? 100.0 / (100.0 - sum1) : 0.0);

    /*PMSTA-40263-ARUN-15102020*/
    /*Do not apply scale factor for NPV/ChileanBonds rule. holi->busi_const_fact will be (BUSCONSTFACTOR)ScaleFctNotRequired for NPV/Chielan rule*/
    if (holi != NULL && (holi)->busi_const_fact == (BUSCONSTFACTOR)ScaleFctNotRequired)
    {
        scale = 1; scale0 = 1;
    }

    uploop = Cldr_FindDateIndex(pdays, n, date2, idx - 1,
                                 SEARCH_BISECTION, NEXTINDEX) - 1 ;

    /* next tells which payment is the critical in case the cashflow is
       ex-coupon or ex-principal. */

    if (exc1 == True && exp1 == True)
        next = GETMIN(n - 1, GETMAX(next_coupon, next_amort)) ;

    else if (exc1 == True && exp1 == False)
        next = GETMIN(n - 1, next_coupon) ;

    else if (exc1 == False && exp1 == True)
        next = GETMIN(n - 1, next_amort) ;

    else if (exc1 == False && exp1 == False)
        next = 0 ;

    for (i = idx ; i <= uploop ; i++)
    {
        /* First consider the first payment after date1 - and handle the
           various ex-coupon/-principal situations carefully. */

        if (i <= next)
        {
            if (exp1 == False || exc1 == False)
                j++ ;
            else
            {
                if      (next_coupon < next_amort)
                    exc1 = False ;
                else if (next_coupon > next_amort)
                    exp1 = False ;

                continue ;
            }

            edays[j] = pdays[i] ;
            erates[j] = rates[i] ; /* PMSTA10118 - DDV - 100628 - set the rate into cflw */

            if (exc1 == False && exp1 == False)
            {
                ecoupon[j] = scale * coupon[i] ; /* PMSTA10118 - DDV - 100628 - change rates and erates with coupon and ecoupon */
                eamort[j] = scale * amort[i] ;
/*
printf("%d %ld %lf %lf\n", j, Cldr_Datestr2YMD(&edays[j]),ecoupon[j],eamort[j]); PMSTA10118 - DDV - 100628 - change rates and erates with coupon and ecoupon 
*/
            }
            else if (exc1 == True && exp1 == False)
            {
                if (fabs(amort[i]) > PMT_TOL)
                {
                    eamort[j] = scale * amort[i] ;
                    ecoupon[j] = 0.0 ; /* PMSTA10118 - DDV - 100628 - change rates and erates with coupon and ecoupon */
/*
printf("%d %ld %lf %lf\n", j, Cldr_Datestr2YMD(&edays[j]),ecoupon[j],eamort[j]);  PMSTA10118 - DDV - 100628 - change rates and erates with coupon and ecoupon 
*/
                }
                else
                    j-- ;
            }
            else if (exc1 == False && exp1 == True)
            {
                eamort[j] = 0.0 ;
                scale1 = (fabs(sum1 - 100.0) > tol  ?
                                               100.0/(100.0 - sum1) : 0.0) ;
                ecoupon[j] = scale*(1.0 - amort[next]*scale1/100.0)*coupon[i] ; /* PMSTA10118 - DDV - 100628 - change rates and erates with coupon and ecoupon */
                if (fabs(ecoupon[j]) < PMT_TOL) /* PMSTA10118 - DDV - 100628 - change rates and erates with coupon and ecoupon */
                    j-- ;
                else
                {
                    /* This line was added to prevent the VisAge compiler
                       from core-dumping */
                    ;
/*
printf("%d %ld %lf %lf\n", j, Cldr_Datestr2YMD(&edays[j]),ecoupon[j],eamort[j]); PMSTA10118 - DDV - 100628 - change rates and erates with coupon and ecoupon 
*/
                }
            }
        }

        /* Here we handle the trivial payments in the period */
        else
        {
            j++ ;
            edays[j]  = pdays[i] ;
            ecoupon[j] = scale * coupon[i] ; /* PMSTA10118 - DDV - 100628 - change rates and erates with coupon and ecoupon */
            eamort[j] = scale * amort[i] ;
            erates[j] = rates[i] ; /* PMSTA10118 - DDV - 100628 - set the rate into cflw */
/*
printf("%d %ld %lf %lf\n", j, Cldr_Datestr2YMD(&edays[j]),ecoupon[j],eamort[j]); PMSTA10118 - DDV - 100628 - change rates and erates with coupon and ecoupon 
*/
        }
    }

    idx = i ;
    exc1 = exc1o ;
    exp1 = exp1o ;

    /* Finally take care of any ex-principal/ex-coupon at ultimo, and in
       particular handle the situation where there the bond is ex-princ. but
       not ex-coupon. Also take care that the primo/ultimo dates are not in
       the same ex-coupon/ex-principal periods. The code is somewhat messed
       up by handling the generel irregular cashflows - but in the regular
       case the k-loop involves only 1 loop and next_coupon/next_amort are
       equal to idx (the index for the next payment).
       prev_amort/_coupon are used to check that date1/date2 are not in the
       same ex-principal/-coupon period. */

    if (idx < n && (exc2 == True || exp2 == True))
    {
/*
        prev_coupon = next_coupon - idx0 ;
        prev_amort  = next_amort - idx0 ;
*/
        prev_coupon = Cflw_FindNextPmt(coupon, n, idx0 - 1) ; /* PMSTA10118 - DDV - 100628 - change rates and erates with coupon and ecoupon */
        prev_amort  = Cflw_FindNextPmt(amort, n, idx0 - 1) ;
        next_coupon = Cflw_FindNextPmt(coupon, n, idx - 1) ; /* PMSTA10118 - DDV - 100628 - change rates and erates with coupon and ecoupon */
        next_amort  = Cflw_FindNextPmt(amort, n, idx - 1) ;
        uploop = GETMIN(n - 1, GETMAX(next_coupon, next_amort)) ;
        for (k = idx ; k <= uploop ; k++)
        {
            j++ ;
            edays[j] = pdays[k] ;
            set = 0 ;

            /* Now handle the 3 possible cases separately
                   1. exc2
                   2. exc2 && exp2
                   2. exp2
            */

            /* Case 1 */
            if (exc2 == True && exp2 == False)
            {
                /* Are we looking at the next coupon ?? */
                if (k == next_coupon)
                {
                    /* Are we in the same ex-coupon period as at date1 ?? */
/*
                    if (exc1 == False || j > prev_coupon)
*/
                    if (exc1 == False ||
                        Cldr_DateLT(&pdays[prev_coupon], &edays[j]) == True)
                    {
                        set = 1 ;
                        ecoupon[j] = scale * coupon[k] ; /* PMSTA10118 - DDV - 100628 - change rates and erates with coupon and ecoupon */
                    }
                }
            }

            /* Case 2 */
            else if (exc2 == True && exp2 == True)
            {
                /* First look at the amortization */
/*
                if (exp1 == False || j > prev_amort)
*/
                if (exp1 == False ||
                    Cldr_DateLT(&pdays[prev_amort], &edays[j]) == True)
                {
                    if (k == next_amort)
                    {
                        set = 1 ;
                        eamort[j] = scale * amort[k] ;
                    }
                }

                /* Next look at the coupon */
/*
                if (exc1 == False || j > prev_coupon)
*/
                if (exc1 == False ||
                    Cldr_DateLT(&pdays[prev_coupon], &edays[j]) == True)
                {
                    if (k == next_coupon)
                    {
                        set = 1 ;
                        /* Are we in the same ex-princ period as at date1 ?? */
/*
                        if (exp1 == True && j == prev_amort)
*/
                        if (exp1 == True &&
                            Cldr_DateEQ(&pdays[prev_amort], &edays[j]) == True)
                            ecoupon[j] = scale0 * coupon[k] ; /* PMSTA10118 - DDV - 100628 - change rates and erates with coupon and ecoupon */
                        else
                            ecoupon[j] = scale * coupon[k] ; /* PMSTA10118 - DDV - 100628 - change rates and erates with coupon and ecoupon */
                    }

                    /* Remember the bite of coupon for the exp-holder */
                    if (k > next_coupon)
                    {
                        set = 1 ;
                        if (k < n)
                        {
                            sum1 = 0.0 ;
                            for (i = 0 ; i <= j - 1 ; i++)
                                sum1 += eamort[i] ;
                            scale1 = (fabs(sum1 - 100.0) > tol ?
                                                  100.0 / (100.0 - sum1) : 0.0)
                                                    ;
                            ecoupon[j] = SQR(scale) * coupon[k] * 0.01 * scale1 * /* PMSTA10118 - DDV - 100628 - change rates and erates with coupon and ecoupon */
                                        amort[next_amort] ;
                        }
                        else
                            ecoupon[j] = scale * coupon[k] ; /* PMSTA10118 - DDV - 100628 - change rates and erates with coupon and ecoupon */
                    }
                }
            }
            /* Case 3 */
            else if (exc2 == False && exp2 == True)
            {
/*
                if ((exc1 == False || j > prev_coupon) &&
                    (exp1 == False || j > prev_amort))
*/
                if ((exc1 == False ||
                    Cldr_DateLT(&pdays[prev_coupon], &edays[j]) == True) &&
                    (exp1 == False ||
                    Cldr_DateLT(&pdays[prev_amort], &edays[j]) == True))
                {
                    set = 1 ;
                    if (k < n)
                    {
                        sum1 = 0.0 ;
                        for (i = 0 ; i <= j - 1 ; i++)
                            sum1 += eamort[i] ;
                        scale1 = (fabs(sum1 - 100.0) > tol  ?
                                                   100.0/(100.0 - sum1) : 0.0) ;
                        ecoupon[j] = SQR(scale) * coupon[k] * 0.01 * scale1 * /* PMSTA10118 - DDV - 100628 - change rates and erates with coupon and ecoupon */
                                    amort[next_amort] ;
                    }
                    else
                        ecoupon[j] = scale * coupon[k] ; /* PMSTA10118 - DDV - 100628 - change rates and erates with coupon and ecoupon */
                }
/*
                if (k == next_amort && (exp1 == False || j > prev_amort))
*/
                if (k == next_amort && (exp1 == False ||
                    Cldr_DateLT(&pdays[prev_amort], &edays[j]) == True))
                {
                    eamort[j] = scale * amort[k] ;
                    set = 1 ;
                }
            }

            if (set == 0)
                j-- ;
/*
else
printf("%d %ld %lf %lf\n", j, Cldr_Datestr2YMD(&edays[j]),ecoupon[j],eamort[j]); PMSTA10118 - DDV - 100628 - change rates and erates with coupon and ecoupon 
*/
        }
    }

    xcflw->filled = j + 1 ;
/*
printf("filled %d\n", j + 1) ;
*/
    return xcflw ;
}


/*,,SOH,,
*************************************************************************
*
*               Cflw_DebtPerDate()
*
*   interface   #include <cflw.h>
*               FL64 Cflw_DebtPerDate(DATESTR   *date1,
*                                       INTI      count,
*                                       DATEARRAY pdays1,
*                                       FL64ARRAY amort1,
*                                       BOOLE     exp1,
*                                       INTI      start) ;
*
*   general     The function finds the outstanding debt at some
*               date, date1, respecting any information concerning
*               the ex-principal status at that date.
*
*   input       DATESTR  *date1     Pointer to the date at which the
*                                   debt is sought.
*
*               INTI     count      The number of elements in pdays
*                                   and amort.
*
*               DATEARRAY pdays1    The datearray in which we look
*                                   for an index.
*
*               FL64ARRAY  amort1   The principal payment at pdays.
*                                   The sum of the amortizations must
*                                   be 100.0.
*
*               BOOLE    exp1       True if the bond is ex-principal
*                                   per date1, otherwise False.
*
*               INTI     start      The search for the index starts
*                                   in this value. Default is 0, which
*                                   should be used if nothing else is
*                                   known.
*
*   output
*
*   returns     the debt per date1 in percent.
*
*   diagnostics
*
*   see also    Cflw_OutstandingDebt()
*
*************************************************************************
,,EOH,,*/


FL64    Cflw_DebtPerDate(DATESTR* date1,
                           INTI    count,
                           DATEARRAY pdays1,
                           FL64ARRAY amort1,
                           BOOLE   exp1,
                           INTI    start)
{
    INTI    i, idx ;
    FL64    debt ;

    idx = Cldr_FindDateIndex(pdays1, count, date1, start,
                              SEARCH_BISECTION, NEXTINDEX) ;
    if (exp1 == True)
        idx++ ;

    if (idx < count)
    {
        debt = ((idx < count/2) ? 100.0 : 0.0) ;

        if (idx < count/2)
        {
            for (i = 0 ; i < idx ; i++)
                debt -= amort1[i] ;
        }
        else
        {
            for (i = count - 1 ; i >= idx ; i--)
                debt += amort1[i] ;
        }
    }
    else
        debt = 0.0 ;

    return debt ;
}


/*,,SOH,,
*************************************************************************
*
*               Cflw_NormCashflow()
*
*   interface   #include <cflw.h>
*               void Cflw_NormCashflow(INTI      count,
*                                       FL64ARRAY rates1,
*                                       FL64ARRAY amort1) ;
*
*   general     The function norms the cash flow of rates and amort
*               such that the amortizations sums to 100.
*
*               The coupon payments in rates are updated with the
*               same scale factor.
*
*   input       INTI      count     The number of elements in pdays
*                                   and amort.
*
*               FL64ARRAY rates1    The coupon payments.
*                                   Dimension [count]
*
*               FL64ARRAY amort1    The principal payments.
*                                   Dimension [count]
*
*   output
*
*   returns
*
*   diagnostics
*
*   see also
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/


void Cflw_NormCashflow(INTI  count,
                        FL64ARRAY rates1,
                        FL64ARRAY amort1)
{
    INTI    i ;
    FL64    sum, scale ;

    sum = 0.0 ;
    for (i = 0 ; i < count ; i++)
        sum += amort1[i] ;

    scale = (fabs(sum) > PMT_TOL ? (100.0/sum) : 0.0) ;

    for (i = 0 ; i < count ; i++)
    {
        amort1[i] *= scale ;
        rates1[i] *= scale ;
    }
}


/*
*************************************************************************
*
*               Cflw_FindNextPmt()
*
*   interface   #include <cflw.h>
*               INTI Cflw_FindNextPmt(FL64ARRAY pmt1,
*                                     INTI      n,
*                                     INTI      start) ;
*
*   general     The function finds the index for the first coming
*               nonzero payment in the array pmt - after the index
*               start.
*               In finding this a tolerance of 1.0E-10 is used to
*               test whether a payment is zero or not.
*               If there is no payments after start, n is returned.
*
*   input       FL64ARRAY  pmt1     The array of payments.
*
*               INTI       n        The number of elements in pmt.
*
*               INTI       start    The starting index for the search,
*                                   default is zero.
*
*   output
*
*   returns     The index for the first coming non-zero payment after
*               start, or n if no future payments.
*
*   diagnostics
*
*   see also    Cflw_FindPrevPmt()
*
*************************************************************************
*/


INTI  Cflw_FindNextPmt(FL64ARRAY pmt1, INTI  n, INTI  start)
{
    INTI    i ;

    for (i = GETMAX(0, start + 1) ; i < n ; i++)
        if (fabs(pmt1[i]) > PMT_TOL)
            break ;

    return GETMIN(i, n) ;
}


/*
*************************************************************************
*
*               Cflw_FindPrevPmt()
*
*   interface   #include <cflw.h>
*               INTI Cflw_FindPrevPmt(FL64ARRAY pmt1,
*                                     INTI      n,
*                                     INTI      start) ;
*
*   general     The function finds the index for the previous
*               nonzero payment in the array pmt - prior to the index
*               start.
*               In finding this a tolerance of 1.0E-10 is used to
*               test whether a payment is zero or not.
*               If there is no payments before start, -1 is returned.
*
*   input       FL64ARRAY  pmt1     The array of payments.
*
*               INTI       n        The number of elements in pmt.
*
*               INTI       start    The starting index for the search,
*                                   default is n - 1.
*
*   output
*
*   returns     The index for the first non-zero payment prior to
*               start, or -1 if no payments prior to start.
*
*   diagnostics
*
*   see also    Cflw_FindNextPmt()
*
*************************************************************************
*/


INTI  Cflw_FindPrevPmt(FL64ARRAY pmt1, INTI  n, INTI  start)
{
    INTI    i ;

    for (i = GETMIN(n - 1, start - 1) ; i >= 0 ; i--)
        if (fabs(pmt1[i]) > PMT_TOL)
            break ;

    return GETMAX(i, -1) ;
}


/*,,SOH,,
*************************************************************************
*
*               Cflw_GenrCoupons()
*
*   interface   #include <cflw.h>
*               FL64ARRAY Cflw_GenrCoupons(FIXRATE   *fix,
*                                           PLAN_STR  *amort,
*                                           DATEARRAY cdays,
*                                           INTI      nc,
*                                           PLAN_STR  *pp,
*                                           PAYDAYSEQ *pseq) ;
*
*   general     The function generates a sequence of coupon payments
*
*               This setup should allow for a wide variety of coupon
*               evaluation schedules:
*
*                    - Standard calculation (with periodic fixed
*                      coupons).
*                    - Standard calculation (with periodic fixed
*                      coupons), but with odd first and/or last
*                      coupon periods.
*                      Also BIANNUALLY paying coupons etc. are possible.*
*                    - First coupons which are only accrued over a
*                      reduced period, ie. when effective is later
*                      than issuedate.
*                    - Stepped coupons, a fixed rate adjustment over
*                      the entire life of the bond.
*                    - Rate adjustments, where the rates are fixed for
*                      a given period, but not known over the entire
*                      life of the bond. This includes cases where
*                      the rates are adjusted in the middle of a
*                      coupon period.
*                    - Long/short first/last coupon periods
*                    - Coupons evaluated by calculating day fractions,
*                      for instance for completely irregular bonds,
*                      with only aperiodic paydays.
*                    - All sorts of repayment and partly paid schedules.*
*                    - Zeros.
*                    - Fixed leg coupons for swaps.
*                    - Partly payments
*                    - Completely irregular paydays
*                    - Daycount protocols
*                    - Coupons paid in advance of the calculation period*
*
*                    ....etc
*
*               Note that the use of this function requires that the
*               paydays have been computed already. This allows for
*               incorporation of various security specific behaviour.
*
*               The algorithm consists basically of two steps. In the
*               first all eventdays are found and following this we
*               loop over all days and keeps track of the repay saldo
*               and the coupon saldo. In particular we allow for the
*               case in which rate adjustments occur at any time during
*               the life of the bond.
*
*   input       FIXRATE     *fix      Struct that informs on how to
*                                     calculate coupons.
*
*               PLAN_STR    *amort    Array of repayments.
*                                     Repayments must sum to 100.
*
*               DATEARRAY   cdays     Array of coupon paydays.
*                                     Dimension [nc].
*                                     NB: The coupon days are moved to 
*                                     match the payments for prepaid bonds.
*
*               INTI        nc        No. of elements in cdays.
*
*               PLAN_STR    *pp       Array of partly payments.
*                                     To disable enter pp->filled = 0
*                                     Partly payments must sum to 100.
*
*               PAYDAYSEQ   *pseq     The payday sequencing.
*               HOLI_STR    *hol	  Container for list of holidays.
*
*   output
*
*   returns     The coupon stream allocated in this routine as:
*
*                          Alloc_FL64ARRAY(nc) ;
*
*   diagnostics
*
*   see also    Cflw_GenrCflw()
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/


FL64ARRAY Cflw_GenrCoupons(FIXRATE* fix,
                       PLAN_STR*  amort,
                       DATEARRAY cdays,
                       INTI      nc,
                       PLAN_STR*  pp,
                       PAYDAYSEQ* pseq,
					   HOLI_STR* hol,
					   FL64ARRAY  intrRate,
					FLAG_T mktConvMethodEnblFlg)   /* PMSTA-42879 - SRIDHARA - 18032021 */
{
    INTI       months, term, i, nf, ne, ixp, ixf, ixc, ixr, ixa, nr, ne1, npp,
               na ;
    FL64       acrl, p, dpy, act_coupon, saldo, csaldo, coupon ;
    DATEARRAY  stday, amday, ppdays, buffer1, eventdays1, fict_coupon1 ;
    FL64ARRAY  stf64, amf64, ppamt, coupons ;
    DATESTR    last, date_from, day, from, prev, next, nextx, *eventdays ;
    BOOLE      accrual, harm, pday, aday, rday, cday, fday ;
    CALCONV    cal ;
    EOMCONV    eom ;
    COUPONBASE cbaseodd, cbase ;
    HOLI_STR   holi ;
    ODDCONV    odd1, oddn ;
    TERMUNIT   unit ;

	holi = *hol;   	/* PMSTA-22396 - SRIDHARA � 160502 */

    /* warning avoidance */
    acrl = 0.0 ;

    /* Allocate output */
    coupons = Alloc_FL64ARRAY(nc) ;

    if (nc == 0)
        return coupons ;

    /* Handle completely irregular flows differently */
    if (GetPlanFill(fix->irreg) > 0)
    {
        for (i = 0; i < nc; i++)
            coupons[i] = fix->irreg->f64[i] ;

        return coupons ;
    }

    /* Get arrays */
    stday = GetPlanDay(fix->stepcoup) ;
    stf64 = GetPlanF64(fix->stepcoup) ;
    nr    = GetPlanFill(fix->stepcoup) ;

    amday = GetPlanDay(amort) ;
    amf64 = GetPlanF64(amort) ;
    na    = GetPlanFill(amort) ;

    ppdays = GetPlanDay(pp) ;
    ppamt  = GetPlanF64(pp) ;
    npp    = GetPlanFill(pp) ;

	/* Set fix info */
	/* PMSTA-42879 - SRIDHARA - 18032021 */
	if (intrRate != NULL) 
		coupon = intrRate[0];
	else
		coupon = fix->fix_rate;

    cbase     = fix->cbase ;
    cbaseodd  = fix->cbodd ;
    from      = fix->effective ;
    date_from = fix->effective ;
    cal       = fix->cal ;
    last      = fix->lastaccr ;
    if (nc && Cldr_DateLT(&last, &date_from) == True)
        last = cdays[nc - 1] ;

    accrual = False ;
    if (fix->accrfac > 0.00001 && fix->accrfac < 1.00001)
    {
        accrual = True ;
        acrl    = 0.0 ;
        fix->prepaid = False ;
    }

    /* Set payday info */
    term = GETMAX(0, pseq->term) ;
    unit = pseq->unit ;
    odd1 = pseq->odd1 ;
    oddn = pseq->oddn ;
    eom  = pseq->eom ;

    harm = Cflw_Is_Harmonic(term, unit, &months) ;

    /* Adjust for Japanese Govnmts */
    if (fix->jgb == True && nc > 0)
    {
        /* First adjust for 1 xtra day of accued interest */
        date_from = Cldr_AddDays(&date_from, (INTL) -1, ACTACT, NULL) ;   /* PMSTA-22396 - SRIDHARA � 160502 */
        cbaseodd  = EVENODD ;
        cbase     = EVENCOUP ;
        if (odd1 == NOODD)
            pseq->odd1 = odd1 = LONGODD ;

        /* Now adjust for the final period */
		/* PMSTA-22396 - SRIDHARA � 160502 */
		if (cal != BUS252)
		{
			holi = Set_HOLI_STR(NEXT, 0, NULL);
		}
        if (Cldr_IsBusinessDate(&cdays[nc - 1], 0, &day) == False)
        {
            cdays[nc - 1] = Cldr_NextBusinessDate(&cdays[nc - 1], &holi) ;
            last = cdays[nc - 1];

            if (oddn == NOODD)
                pseq->oddn = oddn = LONGODD ;

            if (na > 0)
                amday[na - 1] = cdays[nc - 1] ;
        }
        else if (nc > 1 && cdays[nc - 1].d != cdays[nc - 2].d)
            pseq->oddn = oddn = LONGODD ;
    }

    /* Are the first/last coupons long - insert fictitious coupon days */
    fict_coupon1 = Cflw_Fictcoup(&from, cdays, nc, cbaseodd, pseq, &nf) ;

    if (nc > 0 && harm == True && odd1 == LONGODD)
    {
        if (cbaseodd == EVENCOUP || cbaseodd == EVENODD)
            from = Cldr_AddMonths(&fict_coupon1[0], -months, pseq->eom) ;
    }

    if (nc > 0 && cbaseodd == EVENCOUP && harm == True && odd1 == SHORTODD)
        from = Cldr_AddMonths(&cdays[0], -months, pseq->eom) ;

    /* In the next steps we merge all dates into an array of eventdays. */
    buffer1    = Cldr_MergeDates(amday, na, cdays, nc, &ne1) ;
    eventdays1 = Cldr_MergeDates(buffer1, ne1, fict_coupon1, nf, &ne) ;
    Free_DATEARRAY(buffer1) ;
    buffer1 = Cldr_MergeDates(eventdays1, ne, stday, nr, &ne1) ;
    Free_DATEARRAY(eventdays1) ;
    eventdays1 = Cldr_MergeDates(buffer1, ne1, ppdays, npp, &ne) ;
    eventdays  = eventdays1 ;

    /* Compute days per year for first period. 
       Used in the day count fraction. */

    /* Odd first period. */
    if (odd1 != NOODD)
    {
        /* ISMA convention. */
        if (cbaseodd == EVENCOUP && harm == True)
        {
            /* Long first: First period until first fictitious coupon. */
            if (odd1 == LONGODD)
                dpy = Cldr_DaysPerYear(&from, &fict_coupon1[0], months, 
                    cal, eom, &holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */
            /* Short first: First period from fictitious effective date. */
			else
				dpy = Cldr_DaysPerYear(&from, &cdays[0], months, cal, eom, &holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */
                
        }
        /* Equal size coupons. */
        else if (cbaseodd == EQUALCOUP && harm == True)

            dpy = Cldr_DaysPerYear(&from, &cdays[0], months, cal, eom, &holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */

        /* Odd coupons: ODDCOUP and EVENODD. */ 
        else

			dpy = Cldr_DaysPerYear(&from, &cdays[0], 0, cal, eom, &holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */
        
    }
    /* Regular first period. */
    else
    {
        /* ISMA convention. */
        if (cbase != ODDCOUP && harm == True)

			dpy = Cldr_DaysPerYear(&from, &cdays[0], months, cal, eom, &holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */

        /* Odd coupons: ODDCOUP. */
        else

			dpy = Cldr_DaysPerYear(&from, &cdays[0], 0, cal, eom, &holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */
    }

	/* PMSTA-45846 - SENTHILKUMAR - 25082021 */
	/* PMSTA-37299 - JPR - 190924 - The days per year has to be 360 for all 360 day count conventions*/
		/* PMSTA-37299 - JPR - 190924 - The days per year has to be 360 for all 360 day count conventions*/
	if (cal == EU30360 || cal == EU30E360 || cal == EU30EP360 ||
		cal == US30360 || cal == US30E360 || cal == ACT360)
		dpy = 360;

	if (mktConvMethodEnblFlg ==TRUE && (cal == ACT360 || cal == ACT365 || cal == ACTACT))
		dpy = Cldr_DaysPerYear(&from, &cdays[0], 0, cal, eom, &holi);

    /* Handle decompounding carefully */
    act_coupon = Cflw_Decompound(coupon, months, harm, fix->decomp,
                                 &from, &cdays[0], cal, &holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */

    /* Now loop over all eventdays and keep track of all saldoes etc.
       saldo is the outstanding amount, csaldo is the coupon saldo,
       act_coupon is the 'current' coupon, next is the next event date. */
    saldo      = (npp == 0 ? 1.0 : 0.0) ;
    csaldo     = 0.0 ;

    next       = date_from ;
    ixp = ixf = ixc = ixa = ixr = 0 ;

    for (i = 0 ; i < ne && ixc < nc ; i++)
    {
        /* Pick the next date */
        prev = next ;
        if (Cldr_DateLT(&prev, &date_from) == True)
            prev = date_from ;

        nextx = next = eventdays[i] ;

        /* Not after last accrual date */
        if (Cldr_DateLE(&last, &next) == True)
            nextx = last ;
        if (Cldr_DateLT(&nextx, &prev) == True)
            nextx = prev ;

        cday = (Cldr_DateEQ(&next, &cdays[ixc]) == True ? True : False) ;
        rday = (ixr < nr && Cldr_DateEQ(&next, &stday[ixr]) == True  ?
                                                               True : False) ;
        aday = (ixa < na && Cldr_DateEQ(&next, &amday[ixa]) == True ?
                                                               True : False) ;
        fday = (ixf < nf && Cldr_DateEQ(&next, &fict_coupon1[ixf]) == True ?
                                                               True : False) ;
        pday = (ixp < npp && Cldr_DateEQ(&next, &ppdays[ixp]) == True ?
                                                               True : False) ;

        /* What happens here ? -

              0) Accumulate the coupon saldo
              1) Is it a fictitious coupon day ?
              2) Is next a coupon day.
                 If yes then set the new number
                 of days per year (denominator in day fraction).
              3) Next look for a rateadjustment
              4) Finally look for a repayment
              5) Finally look partly payment dates */

        /* Now accumulate the coupon saldo over the period p */
        if (fabs(dpy) > 0.000001)
			p = ((FL64)Cldr_DaysBetweenDates(&prev, &nextx, cal, &holi)) / dpy; 	/* PMSTA-22396 - SRIDHARA � 160502 */
        else
            p = 0.0 ;

        if (Cldr_DateLT(&date_from, &next) == True)
            csaldo += saldo * yld_simple_ann2per(act_coupon, p) ;

        /* A coupon day ?? */
        if (cday == True)
        {
            if (accrual == False)
            {
                coupons[ixc++] = csaldo ;
                csaldo         = 0.0 ;
            }
            else
            {
                coupons[ixc++] = csaldo * (1.0 - fix->accrfac) ;
                acrl          += csaldo * fix->accrfac ;
                saldo         += 0.01 * csaldo * fix->accrfac ;
                csaldo         = 0.0 ;
            }

			/* PMSTA-42879 - SRIDHARA - 18032021 */
			if (intrRate != NULL && ixc < nc)
                coupon = intrRate[i + 1];

            /* Be careful about decompounding */
            if (nr == 0 && ixc < nc)
                act_coupon = Cflw_Decompound(coupon, months, harm, 
                                             fix->decomp, &cdays[ixc - 1],
                                             &cdays[ixc], cal, &holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */
        }

        /* Update the coupon denominator */
		if ((cday == True || fday == True) && ixc < nc)
        {
            /* Is in first odd period */
            if (harm == True && odd1 != NOODD && nc &&
                Cldr_DateLT(&nextx, &cdays[0]) == True)
            {
                /* ISMA convention. */
                if (cbaseodd == EVENCOUP || cbaseodd == EVENODD)
                {
                    /* Simulate next fictituous coupon day. */
                    day  = Cldr_AddMonths(&next, months, eom) ;
					dpy = Cldr_DaysPerYear(&nextx, &day, months, cal, eom, &holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */
					
                }
                /* Equal size coupons. */
                else if (cbaseodd == EQUALCOUP)
                
                    dpy = Cldr_DaysPerYear(&nextx, &cdays[ixc], months, cal, 
					eom, &holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */

                /* Odd coupons: ODDCOUP. */
                else

					dpy = Cldr_DaysPerYear(&nextx, &cdays[ixc], 0, cal, eom, &holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */
            }
            /* Is in final odd period */
            else if (harm == True && oddn != NOODD && nc > 1 &&
                Cldr_DateLE(&cdays[nc - 2], &nextx) == True)
            {
                if (cbaseodd == EVENODD)
                {
                    /* Short and on coupon payday */
                    if (oddn == SHORTODD && nc > 1 &&
                        Cldr_DateEQ(&nextx, &cdays[nc - 2]) == True)
                        dpy = Cldr_DaysPerYear(&nextx, &cdays[ixc], 0, cal,
                                                 eom, &holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */

                    /* Long and on final fictitious coupon day */
                    else if (oddn == LONGODD && nf > 0 &&
                             Cldr_DateEQ(&nextx, &fict_coupon1[nf - 1]) == True)
                        dpy = Cldr_DaysPerYear(&nextx, &cdays[ixc], 0, cal,
                                                 eom, &holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */

                    else
                    {
                        /* Next fictitious coupon day. */
                        day = Cldr_AddMonths(&nextx, months, eom) ;
                        dpy = Cldr_DaysPerYear(&nextx, &day, months, cal, 
                              eom, &holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */
                    }
                }

                else if (cbaseodd == EVENCOUP)
                {
                    /* Short and on coupon payday - ODD */
                    if (oddn == SHORTODD && nc > 1 &&
                        Cldr_DateEQ(&nextx, &cdays[nc - 2]) == True)
                    {
                        day = Cldr_AddMonths(&nextx, months, eom) ;
                        dpy = Cldr_DaysPerYear(&nextx, &day, months, cal, 
                              eom, &holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */
                    }

                    /* Long and on coupon payday */
                    else if (oddn == LONGODD && nc > 1 && nf > 0 &&
                             Cldr_DateEQ(&nextx, &cdays[nc - 2]) == True)

                        dpy = Cldr_DaysPerYear(&nextx, &fict_coupon1[ixf], 
                              months, cal, eom, &holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */

                    /* Long and on fictitious coupon day */
                    else if (oddn == LONGODD && nf > 0 &&
                             Cldr_DateEQ(&nextx, &fict_coupon1[ixf]) == True)
                    {
                        day = Cldr_AddMonths(&nextx, months, eom) ;
                        dpy = Cldr_DaysPerYear(&nextx, &day, months, cal, 
                              eom, &holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */
                    }
                }

                else if (cbaseodd == EQUALCOUP)

                    dpy = Cldr_DaysPerYear(&nextx, &cdays[ixc], months, cal, 
                              eom, &holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */
                
                else

                    dpy = Cldr_DaysPerYear(&nextx, &cdays[ixc], 0, cal, eom, &holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */
            }

            /* If NOT in odd period */
            else
            {
                if (harm == True && cbase != ODDCOUP)

                    dpy = Cldr_DaysPerYear(&nextx, &cdays[ixc], months, cal, 
                              eom, &holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */
                
                else

                    dpy = Cldr_DaysPerYear(&nextx, &cdays[ixc], 0, cal, eom, &holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */
            }
        }

		/* PMSTA-45846 - SENTHILKUMAR - 25082021 */
		if (mktConvMethodEnblFlg == TRUE && (cal == ACT360 || cal == ACT365 || cal == ACTACT))
			dpy = Cldr_DaysPerYear(&nextx, &cdays[ixc], 0, cal, eom, &holi);

        /* Now look for amortizations, rateadjustments and partly paydays. */
        if (rday == True)
        {
            act_coupon = stf64[ixr++] ;
            if (ixc > 0 && ixc < nc)
                act_coupon = Cflw_Decompound(act_coupon, months, harm, 
                                             fix->decomp, &cdays[ixc - 1], 
                                             &cdays[ixc], cal, &holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */
            else if (ixc <= 0 && ixc < nc)
              /* cdays[ixc - 1] is undefined - do something sensible 
                 fix->effective was choosen for no particular reason */
                act_coupon = Cflw_Decompound(act_coupon, months, harm, 
                                             fix->decomp, &fix->effective, 
                                             &cdays[ixc], cal, &holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */
        }

        if (aday == True)
            saldo -= 0.01 * amf64[ixa++] ;

        if (pday == True)
            saldo += 0.01 * ppamt[ixp++] ;

        /* A fictitious coupon day ? */
        if (fday == True)
            ixf++ ;
    }

    /* Set in the final payment for accruals */
    if (nc && accrual == True)
        coupons[nc - 1] += acrl ;

    /* Now adjust for coupons paid in advance */
    if (fix->prepaid == True)
    {
        /* Here we shift the paydays 1 period - the coupons are unchanged */
        for (i = nc - 1; i >= 0 ; i--)
        {
            if (i == 0)
                cdays[0] = date_from ;
            else
                cdays[i] = cdays[i - 1] ;
        }
    }

    /* Finish off things */
    Free_DATEARRAY(buffer1) ;
    Free_DATEARRAY(eventdays1) ;
    Free_DATEARRAY(fict_coupon1) ;

    return coupons ;
}


/*,,SOH,,
***********************************************************************
*                                 
*               Cflw_GenrCouponRates()
*                                 
*   interface   #include <cflw.h> 
*               FL64ARRAY Cflw_GenrCouponRates(FIXRATE   *fix,    
*                                           DATEARRAY cdays,  
*                                           INTI      nc,     
*                                           PAYDAYSEQ *pseq) ;
*                                                             
*   general     The function generates a sequence of coupon rates
*               This function is equivalent to Cflw_GenrCoupons()
*               except that amortisations and partly payments are
*               not handled.
*                  
*               Ignoring amortisations and partly payments, this
*               function computes the coupon rates to be used
*               when calculating the actual coupon payments.
*                                                  
*   input       FIXRATE     *fix      Struct that informs on how to
*                                     calculate coupons.       
*                                                              
*               DATEARRAY   cdays     Array of coupon paydays. 
*                                                              
*               INTI        nc        No. of elements in cdays.
*                                                              
*               PAYDAYSEQ   *pseq     The payday sequencing. 
*	       	    HOLI_STR    *hol	  Container for list of holidays.
*                                                              
*   output                                                     
*                                                              
*   returns     The coupon stream allocated in this routine as:
*                                                              
*                          Alloc_FL64ARRAY(nc) ;               
*                                                              
*   diagnostics                                                
*                                                              
*   see also    Cflw_GenrCoupons()                                
*                                                              
***********************************************************************
,,EOH,,*/

FL64ARRAY Cflw_GenrCouponRates(FIXRATE* fix,
                       DATEARRAY cdays,
                       INTI      nc,
                       PAYDAYSEQ* pseq,
					   HOLI_STR* holi)
{
	return Cflw_GenrCoupons(fix, NULL, cdays, nc, NULL, pseq, holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */
}


/*,,SOH,,
*************************************************************************
*
*               Cflw_Balloon()
*
*   interface   #include <cflw.h>
*               INTI Cflw_Balloon(DATEARRAY amortdays1,
*                                 INTI      na,
*                                 DATESTR   *matur,
*                                 FL64ARRAY amort1) ;
*
*   general     The function checks if there is a balloon, that is
*               an extraordinary amortization in the final cash flow
*               redemption schedule. This can happen if the cash flow
*               has been derived for a theoretical maturity date that
*               is larger than the actual maturity date, matur.
*
*               If there is a balloon in the cashflow the amort is
*               reorganized such that all extraordinary amortizations
*               are paid at the input maturity, matur, and the cash
*               flow is shortened such that the last payment is on
*               the input maturity date, matur.
*
*               If matur is larger than the last amortday then nothing
*               is changed.
*
*   input       DATEARRAY amortdays1 The array of amortization days.
*                                    The entries has been filled prior
*                                    prior to calling this function.
*                                    If matur is not in amortdays and a
*                                    balloon is found then matur is
*                                    inserted in amortdays at the
*                                    appropriate location.
*
*               INTI    na           # of elements in amort/amortdays.
*
*               DATESTR *matur       The maturity of the bond.
*
*   output      FL64ARRAY amort1     The theoretical amortization scheme*
*                                    already derived.
*                                    In case a balloon is found then
*                                    amort is updated.
*
*   returns     The new number of significant entries in amortdays and
*               amort. The return value is less than or equal to na.
*
*   diagnostics
*
*   see also    Cflw_GenrCflw()
*
*************************************************************************
,,EOH,,*/

INTI  Cflw_Balloon(DATEARRAY amortdays1, INTI  na, DATESTR* matur,
                   FL64ARRAY amort1)
{
    INTI    i ;
    FL64    debt ;

    if (na == 0 || Cldr_DateLE(&amortdays1[na - 1], matur) == True)
        return na ;

    debt = 100.0 ;

    for (i = 0 ; i < na ; i++)
    {
        if (Cldr_DateLT(&amortdays1[i], matur) == True)
            debt -= amort1[i] ;
        else
        {
            amortdays1[i] = *matur ;
            amort1[i] = debt ;
            break ;
        }
    }

    return i + 1 ;
}


/*
*************************************************************************
*
*               Cflw_Redemption_Price()
*
*   interface   #include <cflw.h>
*               void Cflw_Redemption_Price(DATEARRAY adays1,
*                                          FL64ARRAY amt1,
*                                          INTI      na,
*                                          DATEARRAY rpdays1,
*                                          FL64ARRAY rprice1,
*                                          INTI      nrp) ;
*
*   general     The function calculates the actual redemptions given
*               the nominal redemption schedule and the - possibly
*               varying - redemption prices.
*
*               The function simply finds the amortization amount
*               corresponding to a given redemption price - and then
*               performs the multiplication. The actual amortization
*               payments are then returned in amt.
*
*               The redemption price days must be contained in the
*               amortization days, but can be a subset of the set of
*               amortdays. An important special case in when rpdays
*               only contains maturity date.
*               Amortizations that have no matching redemption price
*               repays by default at 100 in this function.
*               In the general case the function also handles the
*               German Auf/Abgeld problem.
*
*               If the redemption prices are empty (nrp = 0) then
*               nothing is performed. This is useful if all redemptions
*               are at price 100.
*
*               Also notice that the situation handled here also covers
*               partly paid issues - here amt[i] is the amount issued at
*               time adays[i] and rprice is the minimum tender price.
*
*   input       DATEARRAY adays1  The array of amortization days.
*                                 The entries has been filled prior
*                                 to calling this function.
*                                 Dates must be distinct and sorted
*                                 ascendingly.
*
*               FL64ARRAY amt1    The theoretical payment scheme
*                                 already derived. Must sum to 100.
*
*               INTI      na      The number of elements in amt/adays
*
*               DATEARRAY rpdays1 The array of days with redemption
*                                 price.
*                                 The entries has been filled prior
*                                 to calling this function.
*                                 Dates must be distinct and sorted
*                                 ascendingly.
*
*               FL64ARRAY rprice1 The redemption prices already derived.*
*                                 rprice is quoted in percent.
*
*               INTI      nrp     The number of elements in
*                                 rprice/rpdays
*
*   output      FL64ARRAY amt1    The actual payment schedule.
*
*   returns
*
*   diagnostics
*
*   see also    Cflw_Bondtype2Payments()
*               Cflw_GenrCflw()
*
*************************************************************************
*/

void Cflw_Redemption_Price(DATEARRAY adays1, FL64ARRAY amt1, INTI  na,
                           DATEARRAY rpdays1, FL64ARRAY rprice1, INTI  nrp)
{
    INTI       ix, i ;
    SEARCHCONV conv ;

    if (nrp == 1)
        conv = SEARCH_BACKWARDS ;
    else if (nrp == na)
        conv = SEARCH_FORWARDS ;
    else
        conv = SEARCH_BISECTION ;

    ix = 0 ;
    for (i = 0 ; i < nrp ; i++)
    {
        ix = Cldr_FindDateIndex(adays1, na, &rpdays1[i], ix - 1,
                                 conv, SAMEINDEX) ;
        if (ix < na && Cldr_DateEQ(&adays1[ix], &rpdays1[i]) == True)
            amt1[ix] *= 0.01 * rprice1[i] ;
    }
}


/*,,SOH,,
*************************************************************************
*
*               Free_PAYDAYDEF()
*
*    interface  #include <cflw.h>
*               void Free_PAYDAYDEF(PAYDAYDEF *ds) ;
*
*    general    Free_PAYDAYDEF() frees memory for a PAYDAYDEF struct
*
*    input      PAYDAYDEF   *ds    Reference to the PAYDAYDEF type
*
*    output
*
*    returns
*
*    diagnostics
*
*    see also
*
*************************************************************************
,,EOH,,*/


void Free_PAYDAYDEF(PAYDAYDEF* ds)
{
    Free_DATEARRAY(ds->irreg_days) ;
}

/*,,SIC,,
************************************************************************
*
*            Cflw_Is_Harmonic()
*
*  interface #include <cflw.h>
*            BOOLE Cflw_Is_Harmonic(INTI term,
*                                   TERMUNIT unit,
*                                   INTI* m)
*
*  general   Determines whether a given period is either 1/12, 1/6,
*            1/4, 1/2 or a multiple of a year.
*
*  input     INTI     term The length of the term in ...
*            TERMUNIT unit ... units of this
*  output    INTI*    m    The number of months in the period.
*
*  returns                 True if the period is congruent with a year,
*                          False if not.
*
*
************************************************************************
,,EIC,,*/

BOOLE Cflw_Is_Harmonic(INTI term, TERMUNIT unit, INTI* m)
{
    BOOLE h ;

    *m = 1 ;
    h  = False ;

    if(term != 0 && unit==MONTHS && (!(12%term) || !(term%12)))
    {
        *m=term;
        return True;
    }
    else if(term != 0 && unit==YEARS)
    {
        *m=12*term;
        return True;
    }
    else
    {
        *m=1;
        return False;
    }

}


/*,,SIC,,
************************************************************************
*
*
*            Cflw_Fictcoup()
*
*  interface #include <cflw.h>
*            DATEARRAY Cflw_Fictcoup(DATESTR* issue,
*                                    DATEARRAY cdays,
*                                    INTI nc,
*                                    COUPONBASE cbodd,
*                                    PAYDAYSEQ* pseq,
*                                    INTI* nf)
*
*  general   The function finds the number of fictitious
*            coupon days to be inserted in long first and
*            last coupon periods given the couponbase
*            conventions and odd-period conventions.
*            Fictitious coupon days are laid out annually
*            between issue and first coupon date,
*            chained back from first coupon data
*            and between secondlast and last coupon date
*            chained from secondlast
*
*
*
*  input     DATESTR*   issue The issue date of the bond.
*                             Odd first periods run from
*                             issue to cdays[0].
*            DATEARRAY  cdays The (real) coupon days of the cflw.
*            INTI       nc    The number of elements in cdays
*            COUPONBASE cbodd The couponbase convention according
*                             to which fictitious coupon days are
*                             to be computed. If this is not
*                             equal to EVENCOUP or EVENODD,
*                             no fictitious coupon dates are to
*                             be generated.
*            PAYDAYSEQ  pseq  Sequencing data for coupon days.
*                             If none of these is LONGODD no
*                             fictitious coupons are to be generated.
*                             If the cashflow is inharmonic
*                             no fictitious coupons are generated.
*
*  output    INTI*      nf    The number of fictitious coupon days in
*                             the returned array.
*
*  returns                    An allocated array of fictitious coupon
*                             days, sorted ascendingly.
*
*
*  see also  COUPONBASE
*
************************************************************************
,,EIC,,*/


DATEARRAY Cflw_Fictcoup(DATESTR* issue, DATEARRAY cdays, INTI nc,
                        COUPONBASE cbodd, PAYDAYSEQ* pseq, INTI* nf)
{
    DATEARRAY fict ;
    DATESTR   tmp ;
    BOOLE     harm ;
    INTI      n1, n2, m ;

    *nf = 0 ;
    harm = Cflw_Is_Harmonic(pseq->term, pseq->unit, &m) ;

    if (nc < 1 || harm == False || (cbodd != EVENCOUP && cbodd != EVENODD) )
        return Alloc_DATEARRAY(*nf) ;

    if (pseq->odd1 != LONGODD && pseq->oddn != LONGODD)
        return Alloc_DATEARRAY(*nf) ;

    /* First count fict days */
    n1 = 0 ;
    if (pseq->odd1 == LONGODD)
    {
        tmp = Cldr_AddMonths(&cdays[0], -m, pseq->eom) ;
        ++n1 ;
        tmp = Cldr_AddMonths(&tmp, -m, pseq->eom) ;
        while (Cldr_DateLT(issue, &tmp) == True)
        {
            ++n1 ;
            tmp = Cldr_AddMonths(&tmp, -m, pseq->eom) ;
        }
    }

    n2 = 0 ;
    /* We need at least two coupdays for long odd last period :*/
    if (pseq->oddn == LONGODD && nc>1) 
    {
        tmp = Cldr_AddMonths(&cdays[nc - 2], m, pseq->eom) ;
        ++n2 ;
        tmp = Cldr_AddMonths(&tmp, m, pseq->eom) ;
        while (Cldr_DateLT(&tmp, &cdays[nc - 1]) == True)
        {
            ++n2 ;
            tmp = Cldr_AddMonths(&tmp, m, pseq->eom) ;
        }
    }

    *nf  = 0  ;
    fict = Alloc_DATEARRAY(n1 + n2) ;

    /* Now lay them out */
    if (pseq->odd1 == LONGODD)
    {
    /*
     *  tmp = fict[*nf] = Cldr_AddMonths(&cdays[0], -m, pseq->eom) ;
     */
        fict[*nf] = Cldr_AddMonths(&cdays[0], -m, pseq->eom) ;
        tmp = fict[*nf];
        *nf = 1 ;
        tmp = Cldr_AddMonths(&tmp, -m, pseq->eom) ;

        while (Cldr_DateLT(issue, &tmp) == True)
        {
            fict[*nf] = tmp ;
            ++*nf ;
            tmp = Cldr_AddMonths(&tmp, -m, pseq->eom) ;
        }
    }

    /* Only if there are two coup days ...*/
    if (pseq->oddn == LONGODD && nc>1 )
    {
    /*
     *  tmp = fict[*nf] = Cldr_AddMonths(&cdays[nc - 2], m, pseq->eom) ;
     */
        fict[*nf] = Cldr_AddMonths(&cdays[nc - 2], m, pseq->eom) ;
        tmp = fict[*nf] ;
        ++*nf ;
        tmp = Cldr_AddMonths(&tmp, m, pseq->eom) ;

        while (Cldr_DateLT(&tmp, &cdays[nc - 1]) == True)
        {
            fict[*nf] = tmp ;
            ++*nf ;
            tmp = Cldr_AddMonths(&tmp, m, pseq->eom) ;
        }
    }

    Cldr_DateSort(*nf, fict, ASCENDING) ;

    return fict ;
}


/*
..
*/

FL64 Cflw_Decompound(FL64      act_coupon,
                        INTI      months,
                        BOOLE     harm,
                        FIXDCOMP  decomp,
                        DATESTR*  start,
                        DATESTR*  end,
                        CALCONV   cal,
						HOLI_STR* holi)
{
    FL64 c, dpy, d ;
    
    c = act_coupon ;
    
    if (decomp == EPR_PER && harm == True && months > 0)
    {
        c  = Yld_Ann2Per(act_coupon, ((FL64) months) / 12.0, 1, COMPOUND) ;
        c *= 12.0 / (FL64) months ;
    }
    else if (decomp == EPR_DF && start != NULL && end != NULL)
    {
		/* PMSTA-22396 - SRIDHARA � 160502 */
        /* This is the TAM/TAG method */
        d   = (FL64) Cldr_DaysBetweenDates(start, end, cal, holi) ;  
        dpy = Cldr_DaysPerYear(start, end, 0, cal, LAST, holi) ;

        if (dpy > 0.1 && d > 0.1)
        {
            c  = pow(1.0 + act_coupon / 100.0, d / dpy) - 1.0 ;
            c *= 100.0 * dpy / d ;
        }
        else
            c = act_coupon ;
    }
    else if (decomp == EDDR && start != NULL && end != NULL)
    {
		/* PMSTA-22396 - SRIDHARA � 160502 */
        /* This is the T4M method */
        d   = (FL64) Cldr_DaysBetweenDates(start, end, cal, holi) ;
        dpy = Cldr_DaysPerYear(start, end, 0, cal, LAST, holi) ;

        if (dpy > 0.1 && d > 0.1)
        {
            c  = pow(1.0 + d * act_coupon / (100.0 * dpy), 1.0 / d) - 1.0 ;
            c *= 100.0 * dpy ;
        }
        else
            c = act_coupon ;
    }

    return c ;
}


/*
..
*/

INTI GetPPFill(PP_STR*  pp)
{
    if (pp == NULL)
        return 0 ;

    if (pp->ppmts == NULL)
        return 0 ;
    
    return pp->ppmts->filled ;
}


/*
..
*/

PLAN_STR * GetPPPlan(PP_STR*  pp)
{
    if (pp == NULL)
        return NULL ;

    return pp->ppmts ;
}


/*,,SOH,,
************************************************************************
*
*                Set_FIXRATE()
*
*   interface    #include <cflw.h>
*                FIXRATE Set_FIXRATE(FL64       fix_rate,
*                                    CALCONV    cal,
*                                    DATESTR*   effective,
*                                    DATESTR*   lastaccr,
*                                    FL64       accrfac,
*                                    COUPONBASE cbase,
*                                    COUPONBASE cbodd,
*                                    BOOLE      prepaid,
*                                    BOOLE      jgb,
*                                    PLAN_STR*  stepcoup,
*                                    BOOLE      holpre,
*                                    PLAN_STR*  irreg,
*                                    FIXDCOMP   decomp) ;
*
*   general      This routine sets the members of the struct defined
*                in the function name. The pointer members are simply
*                assigned - without physical copying. The intention
*                of the Set_*() routines is that by using this
*                functionality, one avoids setting individual members
*                of structs in the application code.
*
*                When new members are inserted in structs the Set_*()
*                routine will be changed accordingly.
*
*                One exception to this principle applies. Whenever
*                OPTADD and vanilla members are used, only the
*                vanilla members are set in the Set_*() routines. The
*                non-vanilla and exotic members are set to defaults,
*                and must be set elsewhere - if needed.
*
*                For details on the interpretation of the individual
*                struct members please check the struct definition.
*
*   input        FL64       fix_rate  See general section.
*
*                CALCONV    cal       See general section.
*
*                DATESTR*   effective See general section.
*
*                DATESTR*   lastaccr  See general section.
*                                     Enter NULL for default
*
*                FL64       accrfac   See general section.
*
*                COUPONBASE cbase     See general section.
*
*                COUPONBASE cbodd     See general section.
*
*                BOOLE      prepaid   See general section.
*
*                BOOLE      jgb       See general section.
*
*                PLAN_STR*  stepcoup  See general section.
*
*                BOOLE      holpre    See general section.
*
*                PLAN_STR*  irreg     See general section.
*
*                FIXDCOMP   decomp    See general section.
*
*   output
*
*   returns      The filled out FIXRATE struct
*
*   diagnostics
*
*   see also     FIXRATE
*
************************************************************************
,,EOH,,*/

FIXRATE Set_FIXRATE(FL64   fix_rate,
                         CALCONV    cal,
                         DATESTR*    effective,
                         DATESTR*    lastaccr,
                         FL64       accrfac,
                         COUPONBASE cbase,
                         COUPONBASE cbodd,
                         BOOLE      prepaid,
                         BOOLE      jgb,
                         PLAN_STR*   stepcoup,
                         BOOLE      holpre,
                         PLAN_STR*   irreg,
                         FIXDCOMP    decomp)
{
    FIXRATE fix ;

    fix.fix_rate  = fix_rate ;
    fix.cal       = cal;
    fix.effective = *effective ;
    
    if (lastaccr != NULL)
        fix.lastaccr = *lastaccr ;
    else
        fix.lastaccr = Cldr_YMD2Datestr((YYYYMMDD) 0) ;

    fix.accrfac   = accrfac ;
    fix.cbase     = cbase ;
    fix.cbodd     = cbodd ;
    fix.prepaid   = prepaid ;
    fix.jgb       = jgb ;
    fix.stepcoup  = stepcoup ;
    fix.holpre    = holpre ;
    fix.irreg     = irreg ;
    fix.decomp    = decomp ;

    return fix ;
}


/*,,SOH,,
************************************************************************
*
*                Set_REPAYMNT()
*
*   interface    #include <cflw.h>
*                REPAYMNT Set_REPAYMNT(BONDTYPE  type,
*                                      DATESTR*  teomatur,
*                                      BOOLE     io,
*                                      FL64      init_exch,
*                                      PP_STR*   pp,
*                                      PLAN_STR* irreg,
*                                      PLAN_STR* aufab,
*                                      FL64      rpct,
*                                      FL64      rpct_first) ;
*
*   general      This routine sets the members of the struct defined
*                in the function name. The pointer members are simply
*                assigned - without physical copying. The intention
*                of the Set_*() routines is that by using this
*                functionality, one avoids setting individual members
*                of structs in the application code.
*
*                When new members are inserted in structs the Set_*()
*                routine will be changed accordingly.
*
*                One exception to this principle applies. Whenever
*                OPTADD and vanilla members are used, only the
*                vanilla members are set in the Set_*() routines. The
*                non-vanilla and exotic members are set to defaults,
*                and must be set elsewhere - if needed.
*
*                For details on the interpretation of the individual
*                struct members please check the struct definition.
*
*   input        BONDTYPE  type       See general section.
*
*                DATESTR*  teomatur   See general section.
*                                     Enter NULL for default
*
*                BOOLE     io         See general section.
*
*                FL64      init_exch  See general section.
*
*                PP_STR*   pp         See general section.
*                                     Enter NULL for default
*
*                PLAN_STR* irreg      See general section.
*                                     Enter NULL for default
*
*                PLAN_STR* aufab      See general section.
*                                     Enter NULL for default
*
*                FL64      rpct       See general section.
*
*                FL64      rpct_first See general section.
*
*   output
*
*   returns      The filled out REPAYMNT struct
*
*   diagnostics
*
*   see also     REPAYMNT
*
************************************************************************
,,EOH,,*/

REPAYMNT Set_REPAYMNT(BONDTYPE type,
                           DATESTR*   teomatur,
                           BOOLE     io,
                           FL64      init_exch,
                           PP_STR*    pp,
                           PLAN_STR*  irreg,
                           PLAN_STR*  aufab,
                           FL64      rpct,
                           FL64      rpct_first)
{
    REPAYMNT repay ;

    repay.type = type ;

    if (teomatur != NULL)
        repay.teomatur = *teomatur ;
    else
        repay.teomatur = Cldr_YMD2Datestr((YYYYMMDD) 0) ;

    repay.io        = io ;
    repay.init_exch = init_exch ;

    if(pp != NULL)
      repay.pp       = *pp ;
    else
    {
      repay.pp.pp_price = 0.0 ;
      repay.pp.ppmts = NULL ;
    }

    repay.irreg      = irreg ;
    repay.aufab      = aufab ;
    repay.rpct       = rpct ;
    repay.rpct_first = rpct_first ;

    return repay ;
}


/*,,SOH,,
************************************************************************
*
*                Set_ACCRUINT()
*
*   interface    #include <cflw.h>
*                ACCRUINT Set_ACCRUINT(CALCONV    cal,
*                                      COUPONBASE cb_accru,
*                                      COUPONBASE cbodd_accru,
*                                      BOOLE      incl,
*                                      BOOLE      pre,
*                                      IRRCONV    irr,
*                                      INTI       qbas,
*                                      BOOLE      schuldsch,
*                                      BOOLE      CGB184,
*                                      BOOLE      BRDfeb,
*                                      EXRULE*    exr) ;
*
*   general      This routine sets the members of the struct defined
*                in the function name. The pointer members are simply
*                assigned - without physical copying. The intention
*                of the Set_*() routines is that by using this
*                functionality, one avoids setting individual members
*                of structs in the application code.
*
*                When new members are inserted in structs the Set_*()
*                routine will be changed accordingly.
*
*                One exception to this principle applies. Whenever
*                OPTADD and vanilla members are used, only the
*                vanilla members are set in the Set_*() routines. The
*                non-vanilla and exotic members are set to defaults,
*                and must be set elsewhere - if needed.
*
*                For details on the interpretation of the individual
*                struct members please check the struct definition.
*
*   input        CALCONV    cal         See general section.
*
*                COUPONBASE cb_accru    See general section.
*
*                COUPONBASE cbodd_accru See general section.
*
*                BOOLE      incl        See general section.
*
*                BOOLE      pre         See general section.
*
*                IRRCONV    irr         See general section.
*
*                INTI       qbas        See general section.
*
*                BOOLE      schuldsch   See general section.
*
*                BOOLE      CGB184      See general section.
*
*                BOOLE      BRDfeb      See general section.
*
*                EXRULE*    exr         See general section.
*                                       Enter NULL for default
*
*   output
*
*   returns      The filled out ACCRUINT struct
*
*   diagnostics
*
*   see also     ACCRUINT
*
************************************************************************
,,EOH,,*/

ACCRUINT  Set_ACCRUINT(CALCONV cal,
                             COUPONBASE cb_accru,
                             COUPONBASE cbodd_accru,
                             BOOLE      incl,
                             BOOLE      pre,
                             IRRCONV    irr,
                             INTI       qbas,
                             BOOLE      schuldsch,
                             BOOLE      CGB184,
                             BOOLE      BRDfeb,
                             EXRULE*     exr)
{
    ACCRUINT accru ;

    accru.cal         = cal ;
    accru.cb_accru    = cb_accru ;
    accru.cbodd_accru = cbodd_accru ;
    accru.incl        = incl ;
    accru.pre         = pre ;
    accru.irr         = irr ;
    accru.qbas        = qbas ;
    accru.schuldsch   = schuldsch ;
    accru.CGB184      = CGB184 ;
    accru.BRDfeb      = BRDfeb ;

    if (exr != NULL)
        accru.exr = *exr ;
    else
        accru.exr = Set_EXRULE(EX_DAYS, 0, True, EU30E360, NULL,
                               0, NULL, NULL, True) ;
    return accru ;
}


/*
..
*/

/*,,SOH,,
************************************************************************
*
*                Set_EXRULE()
*
*   interface    #include <cflw.h>
*                EXRULE Set_EXRULE(EXDAYCONV xconv,
*                                  INTI      exdays,
*                                  BOOLE     caldays,
*                                  CALCONV   cal,
*                                  DATESTR*  dex,
*                                  INTI      npday,
*                                  DATEARRAY pday,
*                                  DATEARRAY xpday,
*                                  BOOLE     xlast) ;
*
*   general      This routine sets the members of the struct defined
*                in the function name. The pointer members are simply
*                assigned - without physical copying. The intention
*                of the Set_*() routines is that by using this
*                functionality, one avoids setting individual members
*                of structs in the application code.
*
*                When new members are inserted in structs the Set_*()
*                routine will be changed accordingly.
*
*                One exception to this principle applies. Whenever
*                OPTADD and vanilla members are used, only the
*                vanilla members are set in the Set_*() routines. The
*                non-vanilla and exotic members are set to defaults,
*                and must be set elsewhere - if needed.
*
*                For details on the interpretation of the individual
*                struct members please check the struct definition.
*
*   input        EXDAYCONV xconv   See general section.
*
*                INTI      exdays  See general section.
*
*                BOOLE     caldays See general section.
*
*                CALCONV   cal     See general section.
*
*                DATESTR*  dex     See general section.
*                                  Enter NULL for default
*
*                INTI      npday   See general section.
*
*                DATEARRAY pday    See general section.
*
*                DATEARRAY xpday   See general section.
*
*                BOOLE     xlast   See general section.
*
*   output
*
*   returns      The filled out EXRULE struct
*
*   diagnostics
*
*   see also     EXRULE
*
************************************************************************
,,EOH,,*/

EXRULE Set_EXRULE(EXDAYCONV xconv,
                     INTI      exdays,
                     BOOLE     caldays,
                     CALCONV   cal,
                     DATESTR*   dex,
                     INTI      npday,
                     DATEARRAY pday,
                     DATEARRAY xpday,
                     BOOLE     xlast)
{
    EXRULE exr ;

    exr.xconv   = xconv ;
    exr.exdays  = exdays ;
    exr.caldays = caldays ;
    exr.cal     = cal ;

    if (dex != NULL)
        exr.dex = *dex ;
    else
        exr.dex = Cldr_YMD2Datestr((YYYYMMDD) 0) ;

    exr.npday   = npday ;
    exr.pday    = pday ;
    exr.xpday   = xpday ;
    exr.xlast   = xlast ;

    return exr ;
}

/*,,SOH,,
************************************************************************
*
*                Set_PP_STR()
*
*   interface    #include <cflw.h>
*                PP_STR Set_PP_STR(FL64      p,
*                                  PLAN_STR* pp) ;
*
*   general      This routine sets the members of the struct defined
*                in the function name. The pointer members are simply
*                assigned - without physical copying. The intention
*                of the Set_*() routines is that by using this
*                functionality, one avoids setting individual members
*                of structs in the application code.
*
*                When new members are inserted in structs the Set_*()
*                routine will be changed accordingly.
*
*                One exception to this principle applies. Whenever
*                OPTADD and vanilla members are used, only the
*                vanilla members are set in the Set_*() routines. The
*                non-vanilla and exotic members are set to defaults,
*                and must be set elsewhere - if needed.
*
*                For details on the interpretation of the individual
*                struct members please check the struct definition.
*
*   input        FL64      p  See general section.
*
*                PLAN_STR* pp See general section.
*
*   output
*
*   returns      The filled out PP_STR struct
*
*   diagnostics
*
*   see also     PP_STR
*
************************************************************************
,,EOH,,*/

PP_STR Set_PP_STR(FL64 p, PLAN_STR* pp)
{
    PP_STR pps ;

    pps.ppmts    = pp ;
    pps.pp_price = p ;

    return pps ;
}


/*,,SOH,,
************************************************************************
*
*                Set_TRADEINFO()
*
*   interface    #include <cflw.h>
*                TRADEINFO Set_TRADEINFO(DATESTR* trade,
*                                        DATESTR* aisttl,
*                                        DATESTR* settle,
*                                        BOOLE    brd,
*                                        FL64     price,
*                                        FL64     nom,
*                                        EXTRADE* xctrade,
*                                        EXTRADE* xptrade) ;
*
*   general      This routine sets the members of the struct defined
*                in the function name. The pointer members are simply
*                assigned - without physical copying. The intention
*                of the Set_*() routines is that by using this
*                functionality, one avoids setting individual members
*                of structs in the application code.
*
*                When new members are inserted in structs the Set_*()
*                routine will be changed accordingly.
*
*                One exception to this principle applies. Whenever
*                OPTADD and vanilla members are used, only the
*                vanilla members are set in the Set_*() routines. The
*                non-vanilla and exotic members are set to defaults,
*                and must be set elsewhere - if needed.
*
*                For details on the interpretation of the individual
*                struct members please check the struct definition.
*
*   input        DATESTR* trade   See general section.
*
*                DATESTR* aisttl  See general section.
*                                 Enter NULL for default
*
*                DATESTR* settle  See general section.
*                                 Enter NULL for default
*
*                BOOLE    brd     See general section.
*
*                FL64     price   See general section.
*
*                FL64     nom     See general section.
*
*                EXTRADE* xctrade See general section.
*                                 Enter NULL for default
*
*                EXTRADE* xptrade See general section.
*                                 Enter NULL for default
*
*   output
*
*   returns      The filled out TRADEINFO struct
*
*   diagnostics
*
*   see also     TRADEINFO
*
************************************************************************
,,EOH,,*/

TRADEINFO Set_TRADEINFO(DATESTR* trade, DATESTR* aisttl, DATESTR* settle,
                             BOOLE brd, FL64 price, FL64 nom, EXTRADE* xctrade,
                             EXTRADE* xptrade)
{
    TRADEINFO   trd ;

    trd.trade   = *trade ;

    if (aisttl != NULL)
        trd.aisttl  = *aisttl ;
    else
        trd.aisttl  = *trade ;

    if (settle != NULL)
        trd.settle  = *settle ;
    else
        trd.settle  = *trade ;

    trd.brd     = brd ;
    trd.price   = price ;
    trd.nom     = nom ;

    if (xctrade != NULL)
        trd.xctrade = *xctrade;
    else
        trd.xctrade = Set_EXTRADE(False, False) ;

    if (xptrade != NULL)
        trd.xptrade = *xptrade;
    else
        trd.xptrade = Set_EXTRADE(False, False) ;

    return trd ;
}


/*
..
*/

/*,,SOH,,
************************************************************************
*
*                Set_EXTRADE()
*
*   interface    #include <cflw.h>
*                EXTRADE Set_EXTRADE(BOOLE spec,
*                                    BOOLE ex_fix) ;
*
*   general      This routine sets the members of the struct defined
*                in the function name. The pointer members are simply
*                assigned - without physical copying. The intention
*                of the Set_*() routines is that by using this
*                functionality, one avoids setting individual members
*                of structs in the application code.
*
*                When new members are inserted in structs the Set_*()
*                routine will be changed accordingly.
*
*                One exception to this principle applies. Whenever
*                OPTADD and vanilla members are used, only the
*                vanilla members are set in the Set_*() routines. The
*                non-vanilla and exotic members are set to defaults,
*                and must be set elsewhere - if needed.
*
*                For details on the interpretation of the individual
*                struct members please check the struct definition.
*
*   input        BOOLE spec   See general section.
*
*                BOOLE ex_fix See general section.
*
*   output
*
*   returns      The filled out EXTRADE struct
*
*   diagnostics
*
*   see also     EXTRADE
*
************************************************************************
,,EOH,,*/

EXTRADE Set_EXTRADE(BOOLE spec, BOOLE ex_fix)
{
    EXTRADE   xtrd ;

    xtrd.spec   = spec ;
    xtrd.ex_fix = ex_fix ;

    return xtrd ;
}

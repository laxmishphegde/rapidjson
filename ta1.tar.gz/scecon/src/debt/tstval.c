/* SCID @(#)tstval.c	1.4 (SimCorp) 99/02/19 14:12:52 */

/************************************************************************
*
*   project     SCecon
*
************************************************************************/

/*** includes ***********************************************************/
#include <string.h>
#include <bondio.h>
#include <str2conv.h>
#include <bondvl.h>

INTI debtvaltest(char* txa, FILE* in, FILE* out)
{
    char        txc[80], txe[80], txpl[80] ;
    INTI        diff ;
    VALIDATE    val, exp_val ;
    DATESTR     date ;
    FIXPAY      fixp ;
    TRADEINFO   tr ;
    DEPOSIT     dep ;
    REPAYMNT    repay ;
    DATESTR     dummy_date ;
    CFLWARRAY   cflw ;
    PP_STR      pp ;

    date  = dummy_date = Cldr_YMD2Datestr((YYYYMMDD) 0) ;
    diff = -1 ;

    if (!strcmp("Validate_FIXPAY()", txa))
    {
        fscanf(in, "%s %s", txe, txpl) ;

        exp_val = Str2VALIDATE(txe) ;

        fprintf(out, "   \n Testing %s\n", txa) ;
        fprintf(out, "   %s\n", txpl) ;

        fixp = Read_FIXPAY(in, out, &date) ;
        val  = Validate_FIXPAY(&fixp, True) ;
        VALIDATE2Str(val, txc) ;

        diff = (val == exp_val ? 0 : 1) ;
        fprintf(out,"%d;  Exp %s Res %s\n", diff, txe, txc) ;

        Free_FIXPAY(&fixp) ;
    }

    else if (!strcmp("Validate_TRADEINFO()", txa))
    {
        fscanf(in, "%s %s", txe, txpl) ;

        exp_val = Str2VALIDATE(txe) ;

        fprintf(out, "   \n Testing %s\n", txa) ;
        fprintf(out, "   %s\n", txpl) ;

        tr  = Read_TRADEINFO(in, out) ;
        val = Validate_TRADEINFO(&tr) ;
        VALIDATE2Str(val, txc) ;

        diff = (val == exp_val ? 0 : 1) ;
        fprintf(out,"%d;  Exp %s Res %s\n", diff, txe, txc) ;
    }


    else if (!strcmp("Validate_DEPOSIT()", txa))
    {
        fscanf(in, "%s %s", txe, txpl) ;

        exp_val = Str2VALIDATE(txe) ;

        fprintf(out, "   \n Testing %s\n", txa) ;
        fprintf(out, "   %s\n", txpl) ;

        dep = Read_DEPOSIT(in, out) ;

        val = Validate_DEPOSIT(&dep) ;
        VALIDATE2Str(val, txc) ;

        diff = (val == exp_val ? 0 : 1) ;
        fprintf(out,"%d;  Exp %s Res %s\n", diff, txe, txc) ;
    }

    /* used to test that rpct and rpct_first are valid */
    /* so it is safe to call validate_REPAYMNT with a dummy date */
    else if (!strcmp("Validate_REPAYMNT()", txa))
    {
        fscanf(in, "%s %s", txe, txpl) ;

        exp_val = Str2VALIDATE(txe) ;

        fprintf(out, "   \n Testing %s\n", txa) ;
        fprintf(out, "   %s\n", txpl) ;

        repay = Read_REPAYMNT(in, out) ;

        val = Validate_REPAYMNT(&repay, &dummy_date, False, True) ;
        VALIDATE2Str(val, txc) ;

        diff = (val == exp_val ? 0 : 1) ;
        fprintf(out,"%d;  Exp %s Res %s\n", diff, txe, txc) ;

        Free_PLANARRAY(repay.pp.ppmts ,1) ;
        Free_PLANARRAY(repay.irreg ,1) ;
        Free_PLANARRAY(repay.aufab ,1) ;
    }


    else if (!strcmp("Validate_CFLW_STR()", txa))
    {
        fscanf(in, "%s %s", txe, txpl) ;

        exp_val = Str2VALIDATE(txe) ;

        fprintf(out, "   \n Testing %s\n", txa) ;
        fprintf(out, "   %s\n", txpl) ;

        cflw = Read_CFLWARRAY(in, out) ;

        val = Validate_CFLW_STR(cflw) ;
        VALIDATE2Str(val, txc) ;

        diff = (val == exp_val ? 0 : 1) ;
        fprintf(out,"%d;  Exp %s Res %s\n", diff, txe, txc) ;

        Free_CFLWARRAY(cflw, 1) ;
    }

    else if (!strcmp("Validate_PP_STR()", txa))
    {
        fscanf(in, "%s %s", txe, txpl) ;

        exp_val = Str2VALIDATE(txe) ;

        fprintf(out, "   \n Testing %s\n", txa) ;
        fprintf(out, "   %s\n", txpl) ;

        pp = Read_PP_STR(in, out) ;

        val = Validate_PP_STR(&pp) ;
        VALIDATE2Str(val, txc) ;

        diff = (val == exp_val ? 0 : 1) ;
        fprintf(out,"%d;  Exp %s Res %s\n", diff, txe, txc) ;

        Free_PLANARRAY(pp.ppmts, 1) ;
    }


    return diff ;
}

/* @(#)tstindx.c	1.10 (SimCorp) 99/10/15 11:41:56 */

/************************************************************************
*
*   project     SCecon
*
************************************************************************/

/*** includes ***********************************************************/
#include <string.h>
#include <idxbond.h>
#include <str2conv.h>
#include <ioconv.h>
#include <bondio.h>


#define RelDiff(EXPECTED,ACTUAL) (SCecon_fabs(EXPECTED) > 0.0 ?              \
                                    SCecon_fabs((ACTUAL)/(EXPECTED) - 1.0) : \
                                    SCecon_fabs((ACTUAL)-(EXPECTED)))

/*** prototypes *********************************************************/

INTI idxbntest(char* txa, FILE* in, FILE* out)
{
    INTI        diff, nbuck, i = 0 ;
    INDEXLOAN   idxloan ;
    INDEXFAC    debfac, crefac, fac ;
    HOLI_STR    holi ;
    CFLWARRAY   cflw, expcflw ;
    FL64        fres, fres1, fres2, fexp, fexp1, fexp2, tol, 
                price, ytm, infl, pwfac ;
    DATESTR     analys, lookup ;
    PERIOD      delay ;
    AIRESULT    aires, aiexp ;
    BOOLE       ok, modf, idxadj, zero ;
    YTMCONV     ytmc ;
    ITERCTRL    ictrl ;
    RISKCONV    risk ;
    RISKSET     riskset ;
    DFSPREAD    dfs ;
    DISCFAC     df ;
    TRADEINFO   start, end ;
    INDEXBOND   idxbond ; 
    DELTASET    ds ;
    BUCKETARRAY bucket ;
    FL64ARRAY   dv ;
    CALCONV     indexcal ;
    NR_ERR       nres ;

    diff = -1 ;

    if (!strcmp("IndexLoan_GenrCflw()", txa))
    {
        fprintf(out,"\n\n Testing %s\n", txa) ;

        /* Read data */
        analys  = Read_DATESTR(in, out, "Analysis date  ") ;
        idxloan = Read_INDEXLOAN(in, out) ;
        debfac  = Read_INDEXFAC(in, out) ;
        crefac  = Read_INDEXFAC(in, out) ;
        holi    = Read_HOLI_STR(in, out) ;

        /* Generate CFLW */
        cflw = IndexLoan_GenrCflw(&analys, &idxloan, &debfac, 
                                   &crefac, &holi) ;

        /* Read expected CFLW */
        expcflw = Read_CFLWARRAY(in, out) ;

        IOUtil_ParseLine(in, out) ;

        /* Compare */
        diff = Write_CflwDiff(expcflw, cflw, out) ;

        /* Free */
        Free_INDEXLOAN(&idxloan) ;
        Free_CFLWARRAY(cflw, 1) ;
        Free_CFLWARRAY(expcflw, 1) ;
        Free_PLANARRAY(debfac.idxfac, 1) ;
        Free_PLANARRAY(crefac.idxfac, 1) ;
        Free_DATEARRAY(holi.holidays) ;
    }

    else if (!strcmp("IndexLoan_Accruint()", txa))
    {
        fprintf(out,"\n\n Testing %s\n", txa) ;

        /* Expected result */
        aiexp   = Read_AIRESULT(in) ;

        /* Read data */
        analys  = Read_DATESTR(in, out, "Analysis date  ") ;
        idxloan = Read_INDEXLOAN(in, out) ;
        fac     = Read_INDEXFAC(in, out) ;
        idxadj  = Read_BOOLE(in, out, "Index adjusted price  ") ;
        holi    = Read_HOLI_STR(in, out) ;
        
        /* Calculate */
        aires = IndexLoan_Accruint(&analys, &idxloan, &fac, idxadj, &holi) ;

        IOUtil_ParseLine(in, out) ;

        /* Compare */
        diff = 0 ;
        if (RelDiff(aiexp.AI,aires.AI) > 0.00001 || 
            aiexp.AIdays != aires.AIdays ||
            fabs(aires.AI_per_day - aiexp.AI_per_day) > 0.0001 ||
            aires.exc != aiexp.exc ||
            !Cldr_DateEQ(&aires.next, &aiexp.next))
            diff = 1 ;

        fprintf(out, "%d; exp %lf res %lf\n",
                RelDiff(aiexp.AI, aires.AI) > 0.00001, aiexp.AI, aires.AI) ;
        fprintf(out, "%d; exp %d res %d\n",
                aires.AIdays != aiexp.AIdays, aiexp.AIdays, aires.AIdays) ;
        fprintf(out, "%d; exp %lf res %lf\n",
                RelDiff(aiexp.AI_per_day, aires.AI_per_day) > 0.0001,
                aiexp.AI_per_day, aires.AI_per_day) ;
        fprintf(out, "%d; exp %d res %d\n",
                aires.exc != aiexp.exc, aiexp.exc, aires.exc) ;
        fprintf(out, "; exp %d res %d\n",
                !Cldr_DateEQ(&aires.next, &aiexp.next),
                !Cldr_DateEQ(&aiexp.next, &aires.next) ) ;
        fprintf(out, "\n\n") ;

        Free_INDEXLOAN(&idxloan) ;
        Free_PLANARRAY(fac.idxfac, 1) ;
        Free_DATEARRAY(holi.holidays) ;
    }

    else if (!strcmp("IndexLoan_YTM2Price()", txa))
    {
        fprintf(out,"\n\n Testing %s\n", txa) ;

        /* Expected results */
        fexp    = Read_FL64(in, out, "Exp price ") ;
        fexp1   = Read_FL64(in, out, "Exp dollar dur ") ;
        fexp2   = Read_FL64(in, out, "Exp dollar conv ") ;

        /* Read data */
        ytm     = Read_FL64(in, out, "YTM  ") ;
        analys  = Read_DATESTR(in, out, "Analysis date  ") ;
        idxloan = Read_INDEXLOAN(in, out) ;
        debfac  = Read_INDEXFAC(in, out) ;
        crefac  = Read_INDEXFAC(in, out) ;
        ytmc    = Read_YTMCONV(in, out) ;
        holi    = Read_HOLI_STR(in, out) ;
        risk    = Read_RISKCONV(in, out, "Risk Conv  ") ;
        modf    = Read_BOOLE(in, out, "Modf  ") ;
        idxadj  = Read_BOOLE(in, out, "Index adjusted price  ") ;

        /* Calculate */
        fres = IndexLoan_YTM2Price(ytm, &analys, &idxloan, &debfac,
                                   &crefac, &ytmc, &holi, risk, modf,
                                   idxadj, &fres1, &fres2) ;

        IOUtil_ParseLine(in, out) ;

        /* Compare */
        diff = (RelDiff(fexp,fres) > 0.00001 || RelDiff(fexp1,fres1) > 0.0001 ||
                RelDiff(fexp2,fres2) > 0.003);
        fprintf(out,"%d; 0. order derivative %10.7lf expected = %10.7lf\n",
                (RelDiff(fexp,fres) > 0.00001), fres, fexp);
        fprintf(out,"%d; 1. order derivative %9.6lf expected = %9.6lf\n",
                (RelDiff(fexp1, fres1) > 0.0001), fres1, fexp1);
        fprintf(out,"%d; 2. order derivative %9.6lf expected = %9.6lf\n",
                (RelDiff(fexp2,fres2) > 0.003), fres2, fexp2);

        /* Free */
        Free_INDEXLOAN(&idxloan) ;
        Free_PLANARRAY(debfac.idxfac, 1) ;
        Free_PLANARRAY(crefac.idxfac, 1) ;
        Free_DATEARRAY(holi.holidays) ;
    }
    
    else if (!strcmp("IndexLoan_YTM2Yield()", txa))
    {
        fprintf(out,"\n\n Testing %s\n", txa) ;

        /* Expected results */
        fexp    = Read_FL64(in, out, "Exp YTM ") ;

        /* Read data */
        analys  = Read_DATESTR(in, out, "Analysis date  ") ;
        price   = Read_FL64(in, out, "Price  ") ;
        idxloan = Read_INDEXLOAN(in, out) ;
        debfac  = Read_INDEXFAC(in, out) ;
        crefac  = Read_INDEXFAC(in, out) ;
        ytmc    = Read_YTMCONV(in, out) ;
        idxadj  = Read_BOOLE(in, out, "Index adjusted price  ") ;
        holi    = Read_HOLI_STR(in, out) ;

        Init_ITERCTRL(&ictrl) ;

        /* Calculate */
        ok = IndexLoan_YTM2Yield(&analys, price, &idxloan, &debfac,
                                 &crefac, &ytmc, idxadj, &holi, &ictrl, 
                                 &fres) ;

        IOUtil_ParseLine(in, out) ;

        /* Compare */
        diff = Write_SingleDiff(ok, True, fres, fexp, 0.00001, out) ;

        /* Free */
        Free_INDEXLOAN(&idxloan) ;
        Free_PLANARRAY(debfac.idxfac, 1) ;
        Free_PLANARRAY(crefac.idxfac, 1) ;
        Free_DATEARRAY(holi.holidays) ;
    }
    
    else if (!strcmp("IndexLoan_YTM2Duration()", txa))
    {
        fprintf(out,"\n\n Testing %s\n", txa) ;

        /* Expected results */
        fexp    = Read_FL64(in, out, "Exp duration ") ;

        /* Read data */
        ytm     = Read_FL64(in, out, "YTM  ") ;
        analys  = Read_DATESTR(in, out, "Analysis date  ") ;
        idxloan = Read_INDEXLOAN(in, out) ;
        debfac  = Read_INDEXFAC(in, out) ;
        crefac  = Read_INDEXFAC(in, out) ;
        ytmc    = Read_YTMCONV(in, out) ;
        holi    = Read_HOLI_STR(in, out) ;

        /* Calculate */
        fres = IndexLoan_YTM2Duration(ytm, &analys, &idxloan, &debfac,
                                      &crefac, &ytmc, &holi) ;

        IOUtil_ParseLine(in, out) ;

        /* Compare */
        diff = Write_SingleDiff(True, True, fres, fexp, 0.00001, out) ;

        /* Free */
        Free_INDEXLOAN(&idxloan) ;
        Free_PLANARRAY(debfac.idxfac, 1) ;
        Free_PLANARRAY(crefac.idxfac, 1) ;
        Free_DATEARRAY(holi.holidays) ;
    }

    else if (!strcmp("IndexLoan_DF2Price()", txa))
    {
        fprintf(out,"\n\n Testing %s\n", txa) ;

        /* Expected results */
        fexp    = Read_FL64(in, out, "Exp price ") ;
        fexp1   = Read_FL64(in, out, "Exp dollar dur ") ;
        fexp2   = Read_FL64(in, out, "Exp dollar conv ") ;

        /* Read data */
        analys  = Read_DATESTR(in, out, "Analysis date  ") ;
        idxloan = Read_INDEXLOAN(in, out) ;
        debfac  = Read_INDEXFAC(in, out) ;
        crefac  = Read_INDEXFAC(in, out) ;
        df      = Read_DISCFAC(in ,out) ;
        holi    = Read_HOLI_STR(in, out) ;
        dfs     = Read_DFSPREAD(in, out) ;
        riskset = Read_RISKSET(in ,out) ;
        idxadj  = Read_BOOLE(in, out, "Index adjusted price  ") ;

        /* Calculate */
        fres = IndexLoan_DF2Price(&analys, &idxloan, &debfac, &crefac, 
                                  &df, &holi, &dfs, &riskset, idxadj, 
                                  &fres1, &fres2) ;

        IOUtil_ParseLine(in, out) ;

        /* Compare */
        diff = (RelDiff(fres,fexp) > 0.00001 || RelDiff(fres1,fexp1) > 0.0001 ||
                RelDiff(fres2,fexp2) > 0.001);
        fprintf(out,"%d; 0. order derivative %8.5lf expected = %8.5lf\n",
                (RelDiff(fres,fexp) > 0.00001), fres, fexp);
        fprintf(out,"%d; 1. order derivative %8.5lf expected = %8.5lf\n",
                (RelDiff(fres1,fexp1) > 0.0001), fres1, fexp1);
        fprintf(out,"%d; 2. order derivative %8.5lf expected = %8.5lf\n",
                (RelDiff(fres2,fexp2) > 0.001), fres2, fexp2);

        /* Free */
        Free_INDEXLOAN(&idxloan) ;
        Free_PLANARRAY(debfac.idxfac, 1) ;
        Free_PLANARRAY(crefac.idxfac, 1) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_DATEARRAY(holi.holidays) ;
        Free_PLANARRAY(riskset.loads, 1) ;
        Free_DFSPREAD(&dfs) ;
    }

    else if (!strcmp("IndexLoan_DF2Delta()", txa))
    {
        fprintf(out,"\n\n Testing %s\n", txa) ;

        /* Read data */
        analys  = Read_DATESTR(in, out, "Analysis date  ") ;
        idxloan = Read_INDEXLOAN(in, out) ;
        debfac  = Read_INDEXFAC(in, out) ;
        crefac  = Read_INDEXFAC(in, out) ;
        df      = Read_DISCFAC(in ,out) ;
        holi    = Read_HOLI_STR(in, out) ;
        dfs     = Read_DFSPREAD(in, out) ;
        idxadj  = Read_BOOLE(in, out, "Index adjusted price  ") ;
        bucket  = Read_BUCKETARRAY(in, out, &nbuck) ;
        zero    = Read_BOOLE(in, out, "DECF ") ;

        /* Initialise */
        ds = Disc_DeltaPrep(&df, bucket, nbuck, &holi, False, df.irr,
                             df.freq, False, zero, DF_BOTH) ;
        
        /* Calculate */
        dv = IndexLoan_DF2Delta(&analys, &idxloan, &debfac, &crefac, 
                                &df, &holi, &dfs, idxadj, &ds) ;

        diff = 0 ;
        for (i = 0; i < nbuck; i++)
        {
            fscanf(in, "%lf", &fexp) ;
            diff = diff || RelDiff(fexp,dv[i]) > 0.001 ;
            fprintf(out, "%d; %d exp %lf res %lf\n",
                    RelDiff(fexp,dv[i]) > 0.001, i, fexp, dv[i]) ;
        }



        IOUtil_ParseLine(in, out) ;

        /* Free */
        Free_INDEXLOAN(&idxloan) ;
        Free_DELTASET(&ds) ;
        Free_BUCKETARRAY(bucket) ;
        Free_FL64ARRAY(dv) ;
        Free_PLANARRAY(debfac.idxfac, 1) ;
        Free_PLANARRAY(crefac.idxfac, 1) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_DATEARRAY(holi.holidays) ;
        Free_DFSPREAD(&dfs) ;
    }

    else if (!strcmp("IndexLoan_DF2ImpliedInflation()", txa))
    {
        fprintf(out,"\n\n Testing %s\n", txa) ;

        /* Read data */
        price = Read_FL64(in, out, "Input price  ") ;
        analys  = Read_DATESTR(in, out, "Analysis date  ") ;
        idxloan = Read_INDEXLOAN(in, out) ;
        df      = Read_DISCFAC(in ,out) ;
        holi    = Read_HOLI_STR(in, out) ;
        dfs     = Read_DFSPREAD(in, out) ;
        indexcal = Read_CALCONV(in, out, "Index interpolation calendar ") ;
        pwfac  = Read_FL64(in, out, "Wage/Price factor ") ;
        idxadj  = Read_BOOLE(in, out, "Index adjusted price  ") ;

        Init_ITERCTRL(&ictrl) ;

        /* Calculate */
        nres =  (NR_ERR) IndexLoan_DF2ImpliedInflation(&analys, price, &idxloan, 
                                        &df, &holi, &dfs, indexcal, pwfac,
                                        idxadj, &ictrl, &infl) ;

        diff = 0 ;

        fscanf(in, "%lf", &fexp) ;
        diff = diff || (RelDiff(fexp, infl) > 0.0001
                    || !(nres == NR_ROOT_FOUND || nres == NR_CONSTANT_ZERO));
        fprintf(out, "%d; %d exp %lf res %lf\n",
                    ((RelDiff(fexp, infl) > 0.00001) || 
                    !(nres == NR_ROOT_FOUND || nres == NR_CONSTANT_ZERO) ),
                    i, fexp, infl) ;


        IOUtil_ParseLine(in, out) ;

        /* Free */
        Free_INDEXLOAN(&idxloan) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_DATEARRAY(holi.holidays) ;
        Free_DFSPREAD(&dfs) ;

    }

    else if (!strcmp("IndexBond_DF2ImpliedInflation()", txa))
    {
        fprintf(out,"\n\n Testing %s\n", txa) ;

        /* Read data */

        start   = Read_TRADEINFO(in,out) ;
        idxbond = Read_INDEXBOND(in, out, &start.settle) ;
        df      = Read_DISCFAC(in ,out) ;
        holi    = Read_HOLI_STR(in, out) ;
        dfs     = Read_DFSPREAD(in, out) ;
        indexcal = Read_CALCONV(in, out, "Index interpolation calendar ") ;
        idxadj  = Read_BOOLE(in, out, "Index adjusted price  ") ;

        Init_ITERCTRL(&ictrl) ;

        /* Calculate */
        nres =  (NR_ERR) IndexBond_DF2ImpliedInflation(&start, &idxbond, 
                                       &df, &holi, &dfs, indexcal,
                                       idxadj, &ictrl, &infl) ;

        diff = 0 ;

        fscanf(in, "%lf", &fexp) ;
        diff = diff || (RelDiff(fexp, infl) > 0.0001
                    || !(nres == NR_ROOT_FOUND || nres == NR_CONSTANT_ZERO));
        fprintf(out, "%d; %d exp %lf res %lf\n",
                    ((RelDiff(fexp, infl) > 0.00001) || 
                    !(nres == NR_ROOT_FOUND || nres == NR_CONSTANT_ZERO) ),
                    i, fexp, infl) ;


        IOUtil_ParseLine(in, out) ;

        /* Free */
        Free_INDEXBOND(&idxbond) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_DATEARRAY(holi.holidays) ;
        Free_DFSPREAD(&dfs) ;

    }


    else if (!strcmp("IndexBond_GenrCflw()", txa))
    {
        fprintf(out,"\n\n Testing %s\n", txa) ;

        /* Read data */
        start   = Read_TRADEINFO(in, out) ;
        idxbond = Read_INDEXBOND(in, out, &start.settle) ;
        fac     = Read_INDEXFAC(in, out) ;
        holi    = Read_HOLI_STR(in, out) ;

        /* Generate CFLW */
        cflw = IndexBond_GenrCflw(&start, &idxbond, &fac, &holi) ;

        /* Read expected CFLW */
        expcflw = Read_CFLWARRAY(in, out) ;

        IOUtil_ParseLine(in, out) ;

        /* Compare */
        diff = Write_CflwDiff(expcflw, cflw, out) ;

        /* Free */
        Free_INDEXBOND(&idxbond) ;
        Free_CFLWARRAY(cflw, 1) ;
        Free_CFLWARRAY(expcflw, 1) ;
        Free_PLANARRAY(fac.idxfac, 1) ;
        Free_DATEARRAY(holi.holidays) ;
    }

    else if (!strcmp("IndexBond_GenrPeriod()", txa))
    {
        fprintf(out,"\n\n Testing %s\n", txa) ;

        /* Read data */
        start   = Read_TRADEINFO(in, out) ;
        end     = Read_TRADEINFO(in, out) ;
        idxbond = Read_INDEXBOND(in, out, &start.settle) ;
        fac     = Read_INDEXFAC(in, out) ;
        holi    = Read_HOLI_STR(in, out) ;

        /* Generate CFLW */
        cflw = IndexBond_GenrPeriod(&start, &end, &idxbond, &fac, &holi) ;

        /* Read expected CFLW */
        expcflw = Read_CFLWARRAY(in, out) ;

        IOUtil_ParseLine(in, out) ;

        /* Compare */
        diff = Write_CflwDiff(expcflw, cflw, out) ;

        /* Free */
        Free_INDEXBOND(&idxbond) ;
        Free_CFLWARRAY(cflw, 1) ;
        Free_CFLWARRAY(expcflw, 1) ;
        Free_PLANARRAY(fac.idxfac, 1) ;
        Free_DATEARRAY(holi.holidays) ;
    }

    else if (!strcmp("IndexBond_Accruint()", txa))
    {
        fprintf(out,"\n\n Testing %s\n", txa) ;

        /* Expected result */
        aiexp   = Read_AIRESULT(in) ;

        /* Read data */
        start   = Read_TRADEINFO(in, out) ;
        idxbond = Read_INDEXBOND(in, out, &start.settle) ;
        fac     = Read_INDEXFAC(in, out) ;
        idxadj  = Read_BOOLE(in, out, "Index adjusted price  ") ;
        holi    = Read_HOLI_STR(in, out) ;
        
        /* Calculate */
        aires = IndexBond_Accruint(&start, &idxbond, &fac, idxadj, &holi) ;

        IOUtil_ParseLine(in, out) ;

        /* Compare */
        diff = 0 ;
        if (RelDiff(aires.AI, aiexp.AI) > 0.00001 || 
            aiexp.AIdays != aires.AIdays ||
            RelDiff(aires.AI_per_day, aiexp.AI_per_day) > 0.0001 ||
            aires.exc != aiexp.exc ||
            !Cldr_DateEQ(&aires.next, &aiexp.next) )
            diff = 1 ;

        fprintf(out, "%d; exp %lf res %lf\n",
                fabs(aires.AI - aiexp.AI) > 0.00001, aiexp.AI, aires.AI) ;
        fprintf(out, "%d; exp %d res %d\n",
                aires.AIdays != aiexp.AIdays, aiexp.AIdays, aires.AIdays) ;
        fprintf(out, "%d; exp %lf res %lf\n",
                fabs(aires.AI_per_day - aiexp.AI_per_day) > 0.0001,
                aiexp.AI_per_day, aires.AI_per_day) ;
        fprintf(out, "%d; exp %d res %d\n",
                aires.exc != aiexp.exc, aiexp.exc, aires.exc) ;
        fprintf(out, "; exp %d res %d\n",
                !Cldr_DateEQ(&aires.next, &aiexp.next),
                !Cldr_DateEQ(&aiexp.next, &aires.next) ) ;
        fprintf(out, "\n\n") ;

        Free_INDEXBOND(&idxbond) ;
        Free_PLANARRAY(fac.idxfac, 1) ;
        Free_DATEARRAY(holi.holidays) ;
    }

    else if (!strcmp("IndexBond_YTM2Price()", txa))
    {
        fprintf(out,"\n\n Testing %s\n", txa) ;

        /* Expected results */
        fexp    = Read_FL64(in, out, "Exp price ") ;
        fexp1   = Read_FL64(in, out, "Exp dollar dur ") ;
        fexp2   = Read_FL64(in, out, "Exp dollar conv ") ;

        /* Read data */
        ytm     = Read_FL64(in, out, "YTM  ") ;
        start   = Read_TRADEINFO(in, out) ;
        idxbond = Read_INDEXBOND(in, out, &start.settle) ;
        fac     = Read_INDEXFAC(in, out) ;
        ytmc    = Read_YTMCONV(in, out) ;
        holi    = Read_HOLI_STR(in, out) ;
        risk    = Read_RISKCONV(in, out, "Risk Conv  ") ;
        modf    = Read_BOOLE(in, out, "Modf  ") ;
        idxadj  = Read_BOOLE(in, out, "Index adjusted price  ") ;

        /* Calculate */
        fres = IndexBond_YTM2Price(ytm, &start, &idxbond, &fac, &ytmc, 
                                   &holi, risk, modf, idxadj, &fres1, 
                                   &fres2) ;

        IOUtil_ParseLine(in, out) ;

        /* Compare */
        diff = (RelDiff(fres, fexp) > 0.00001 ||
                RelDiff(fres1, fexp1) > 0.0001 ||
                RelDiff(fres2, fexp2) > 0.001);
        fprintf(out,"%d; 0. order derivative %8.5lf expected = %8.5lf\n",
                (RelDiff(fres, fexp) > 0.00001), fres, fexp);
        fprintf(out,"%d; 1. order derivative %8.5lf expected = %8.5lf\n",
                (RelDiff(fres1, fexp1) > 0.0001), fres1, fexp1);
        fprintf(out,"%d; 2. order derivative %8.5lf expected = %8.5lf\n",
                (RelDiff(fres2, fexp2) > 0.002), fres2, fexp2);

        /* Free */
        Free_INDEXBOND(&idxbond) ;
        Free_PLANARRAY(fac.idxfac, 1) ;
        Free_DATEARRAY(holi.holidays) ;
    }

    else if (!strcmp("IndexBond_YTM2Yield()", txa))
    {
        fprintf(out,"\n\n Testing %s\n", txa) ;

        /* Expected results */
        fexp    = Read_FL64(in, out, "Exp YTM ") ;

        /* Read data */
        start   = Read_TRADEINFO(in, out) ;
        idxbond = Read_INDEXBOND(in, out, &start.settle) ;
        fac     = Read_INDEXFAC(in, out) ;
        ytmc    = Read_YTMCONV(in, out) ;
        idxadj  = Read_BOOLE(in, out, "Index adjusted price  ") ;
        holi    = Read_HOLI_STR(in, out) ;

        Init_ITERCTRL(&ictrl) ;

        /* Calculate */
        ok = IndexBond_YTM2Yield(&start, &idxbond, &fac, &ytmc, 
                                 idxadj, &holi, &ictrl, &fres) ;

        IOUtil_ParseLine(in, out) ;

        /* Compare */
        diff = Write_SingleDiff(ok, True, fres, fexp, 0.00001, out) ;

        /* Free */
        Free_INDEXBOND(&idxbond) ;
        Free_PLANARRAY(fac.idxfac, 1) ;
        Free_DATEARRAY(holi.holidays) ;
    }
    
    else if (!strcmp("IndexBond_YTM2Duration()", txa))
    {
        fprintf(out,"\n\n Testing %s\n", txa) ;

        /* Expected results */
        fexp    = Read_FL64(in, out, "Exp duration ") ;

        /* Read data */
        ytm     = Read_FL64(in, out, "YTM  ") ;
        start   = Read_TRADEINFO(in, out) ;
        idxbond = Read_INDEXBOND(in, out, &start.settle) ;
        fac     = Read_INDEXFAC(in, out) ;
        ytmc    = Read_YTMCONV(in, out) ;
        holi    = Read_HOLI_STR(in, out) ;

        /* Calculate */
        fres = IndexBond_YTM2Duration(ytm, &start, &idxbond, &fac,
                                      &ytmc, &holi) ;

        IOUtil_ParseLine(in, out) ;

        /* Compare */
        diff = Write_SingleDiff(True, True, fres, fexp, 0.00001, out) ;

        /* Free */
        Free_INDEXBOND(&idxbond) ;
        Free_PLANARRAY(fac.idxfac, 1) ;
        Free_DATEARRAY(holi.holidays) ;
    }

    else if (!strcmp("IndexBond_DF2Price()", txa))
    {
        fprintf(out,"\n\n Testing %s\n", txa) ;

        /* Expected results */
        fexp    = Read_FL64(in, out, "Exp price ") ;
        fexp1   = Read_FL64(in, out, "Exp dollar dur ") ;
        fexp2   = Read_FL64(in, out, "Exp dollar conv ") ;

        /* Read data */

        start   = Read_TRADEINFO(in, out) ;
        idxbond = Read_INDEXBOND(in, out, &start.settle) ;
        fac     = Read_INDEXFAC(in, out) ;
        df      = Read_DISCFAC(in ,out) ;
        holi    = Read_HOLI_STR(in, out) ;
        dfs     = Read_DFSPREAD(in, out) ;
        riskset = Read_RISKSET(in ,out) ;
        idxadj  = Read_BOOLE(in, out, "Index adjusted price  ") ;

        /* Calculate */
        fres = IndexBond_DF2Price(&start, &idxbond, &fac,  
                                  &df, &holi, &dfs, &riskset, idxadj, 
                                  &fres1, &fres2) ;

        IOUtil_ParseLine(in, out) ;

        /* Compare */
        diff = (RelDiff(fres, fexp) > 0.00001 ||
                RelDiff(fres1, fexp1) > 0.0001 ||
                RelDiff(fres2, fexp2) > 0.001);
        fprintf(out,"%d; 0. order derivative %8.5lf expected = %8.5lf\n",
                (RelDiff(fres, fexp) > 0.00001), fres, fexp);
        fprintf(out,"%d; 1. order derivative %8.5lf expected = %8.5lf\n",
                (RelDiff(fres1, fexp1) > 0.0001), fres1, fexp1);
        fprintf(out,"%d; 2. order derivative %8.5lf expected = %8.5lf\n",
                (RelDiff(fres2, fexp2) > 0.001), fres2, fexp2);

        /* Free */
        Free_INDEXBOND(&idxbond) ;
        Free_PLANARRAY(fac.idxfac, 1) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_DATEARRAY(holi.holidays) ;
        Free_PLANARRAY(riskset.loads, 1) ;
        Free_DFSPREAD(&dfs) ;
    }

    else if (!strcmp("IndexBond_DF2Delta()", txa))
    {
        fprintf(out,"\n\n Testing %s\n", txa) ;

        /* Read data */
        start   = Read_TRADEINFO(in, out) ;
        idxbond = Read_INDEXBOND(in, out, &start.settle) ;
        fac     = Read_INDEXFAC(in, out) ;
        df      = Read_DISCFAC(in ,out) ;
        holi    = Read_HOLI_STR(in, out) ;
        dfs     = Read_DFSPREAD(in, out) ;
        idxadj  = Read_BOOLE(in, out, "Index adjusted price  ") ;
        bucket  = Read_BUCKETARRAY(in, out, &nbuck) ;
        zero    = Read_BOOLE(in, out, "DECF ") ;

        /* Initialise */
        ds = Disc_DeltaPrep(&df, bucket, nbuck, &holi, False, df.irr,
                             df.freq, False, zero, DF_BOTH) ;
        
        /* Calculate */
        dv = IndexBond_DF2Delta(&start, &idxbond, &fac,  
                                &df, &holi, &dfs, idxadj, &ds) ;

        diff = 0 ;
        for (i = 0; i < nbuck; i++)
        {
            fscanf(in, "%lf", &fexp) ;
            diff = diff || RelDiff(fexp, dv[i]) > 0.001 ;
            fprintf(out, "%d; %d exp %lf res %lf\n",
                    RelDiff(fexp, dv[i]) > 0.001, i, fexp, dv[i]) ;
        }

        IOUtil_ParseLine(in, out) ;

        /* Free */
        Free_DELTASET(&ds) ;
        Free_BUCKETARRAY(bucket) ;
        Free_FL64ARRAY(dv) ;
        Free_INDEXBOND(&idxbond) ;
        Free_PLANARRAY(fac.idxfac, 1) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_DATEARRAY(holi.holidays) ;
        Free_DFSPREAD(&dfs) ;
    }

    else if (!strcmp("Index_Interpolation()", txa))
    {
        fprintf(out,"\n\n Testing %s\n", txa) ;

        /* Read data */
        fexp   = Read_FL64(in, out, "Expected index factor ") ;
        tol    = Read_FL64(in, out, "Tolerance ") ;
        lookup = Read_DATESTR(in, out, "Loop up date ") ;
        delay  = Read_PERIOD(in) ;
        Write_PERIOD(out, "Delay period: ", &delay) ;
        fac    = Read_INDEXFAC(in, out) ;

        /* Calculate */
        fres = Index_Interpolation(&lookup, &delay, &fac) ;

        IOUtil_ParseLine(in, out) ;

        /* Compare */
        diff = Write_SingleDiff(True, True, fres, fexp, tol, out) ;

        /* Free */
        Free_PLANARRAY(fac.idxfac, 1) ;
    }

    return diff ;
}




/* SCID @(#)depo.c	1.3 (SimCorp) 99/02/19 14:12:03 */

/************************************************************************
*
*       Project         SCecon
*
*       file name       depo.c
*
*       contains        routines for deposits
*
************************************************************************/

/*** includes **********************************************************/
#include <bond.h>


/*,,SOH,,
*************************************************************************
*
*               Deposit_DEPOSIT2FIXPAY()
*
*   interface   #include <bond.h>
*               FIXPAY Deposit_DEPOSIT2FIXPAY(DEPOSIT  *depo,
*                                             HOLI_STR *holi) ;
*
*   general     The function translates a DEPOSIT data type into
*               a FIXPAY
*
*   input       DEPOSIT   *depo         The deposit definition
*
*               HOLI_STR  *holi         Holiday setup
*
*   output
*
*   returns     FIXPAY holding deposit information
*
*
*   diagnostics
*
*   see also
*
*************************************************************************
,,EOH,,*/


FIXPAY Deposit_DEPOSIT2FIXPAY(DEPOSIT* depo, HOLI_STR* holi)
{
    FIXPAY    fixp ;
    DATESTR   effective, maturity ;
    INTI      months ;
    PAYDAYSEQ pseq ;
    PAYDAYDEF pday ;
    FIXRATE   fix ;
    REPAYMNT  repay ;

    effective = Cldr_NextBusinessDate(&depo->effective, holi) ;
    maturity  = Cldr_NextBusinessDate(&depo->maturity, holi) ;

    /* Set paydaydef */
    months = Cflw_MonthsBetweenPayments(depo->freq) ;
    pseq   = Set_PAYDAYSEQ(months, MONTHS, NOODD, NOODD, 
                           ANCHORBACK, depo->eom) ;
    pday   = Set_PAYDAYDEF(False, &effective, NULL, 
                           &maturity, False, &pseq, 0, NULL) ;

    /* Set fixrate */
    fix = Set_FIXRATE(depo->coupon, depo->cal, &effective, 
                      &maturity, 0.0, ODDCOUP, ODDCOUP, False,
                      False, NULL, True, NULL, NODCOMP) ;

    /* Set repaymnt */
    repay = Set_REPAYMNT(BULLET, NULL, False, 
                         depo->issue_price, NULL, NULL, NULL, 0.0, 0.0) ;

    /* Set taxation */
    fixp = Set_FIXPAY(&pday, &fix, NULL, &repay, NULL, NULL, NULL) ;

    return fixp ;
}


/*,,SOH,,
*************************************************************************
*
*               Deposit_DF2Price()
*
*   interface   #include <bond.h>
*               FL64 Deposit_DF2Price(DATESTR    *analys,
*                                     DEPOSIT    *depo,
*                                     DISCFAC    *df,
*                                     HOLI_STR   *holi,
*                                     DFSPREAD   *dfs,
*                                     RISKSET    *risk,
*                                     FL64       *dp,
*                                     FL64       *ddp) ;
*
*   general     Deposit_DF2Price() calculates the price given a zero-
*               coupon discount factor curve.
*
*               Risk ratios are calculated as follows:
*
*                   risk->key      dp          ddp
*                   ---------      ---         ----
*                   KEY_DF         $Duration   $Convexity
*                   KEY_BPV        BPV
*
*   input       DATESTR   *analys       The analysis date.
*
*               DEPOSIT   *depo         The deposit definition
*
*               DISCFAC   *df           Discounting structure setup.
*
*               HOLI_STR  *holi         Bus.day adjustment setup
*
*               DFSPREAD  *dfs          Spread against the curve.
*                                       Enter NULL if no spread.
*
*               RISKSET   *risk         The risk calculation setup.
*                                       Use NULL for no risk ratios
*
*   output      FL64      *dp           The dollar duration
*
*               FL64      *ddp          The dollar convexity
*
*   returns     The clean price of the deposit on the analysis date.
*
*   diagnostics
*
*   see also    Cflw_DF2Price()
*               Bond_DF2Price()
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/

FL64 Deposit_DF2Price(DATESTR* analys,
                      DEPOSIT*    depo,
                      DISCFAC*    df,
                      HOLI_STR*   holi,
                      DFSPREAD*   dfs,
                      RISKSET*    risk,
                      FL64*       dp,
                      FL64*       ddp)
{
    CFLWARRAY cflw ;
    FL64      p ;
    TRADEINFO end ;
    FIXPAY    fixp ;
    AIRESULT  air ;

    /* Translate deposit into fixpay */
    fixp = Deposit_DEPOSIT2FIXPAY(depo, holi) ;

    /* Compute cash flow */
    cflw = Cflw_GenrCflw(&fixp.repay, &fixp.rday, &fixp.fix, 
                          &fixp.cday, holi) ;
    p    = Cflw_DF2Price(analys, df, cflw, &fixp.repay.pp, holi,
                         dfs, risk, dp, ddp) ;

    /* Adjust for accrued interest */
    if (Cldr_DateLE(analys, &depo->effective) == True)
        air.AI = 0.0 ;
    else
    {
        end = bond_set_tradeinfo(analys) ;
        air = Cflw_Accruint(&end, cflw, &fixp.fix, &fixp.cday.pseq, &fixp.accru,
                            holi, fixp.repay.pp.ppmts, NEXTINDEX) ;             /*  FPL-PMSTA00211-100826   */
    }

    /* Free */
    Free_CFLWARRAY(cflw, 1) ;

    return p - air.AI ;
}



/*,,SOH,,
*************************************************************************
*
*               Deposit_DF2Delta()
*
*   interface   #include <bond.h>
*               FL64ARRAY Deposit_DF2Delta(DATESTR    *analys,
*                                          DEPOSIT    *depo,
*                                          DISCFAC    *df,
*                                          HOLI_STR   *holi,
*                                          DFSPREAD   *dfs,
*                                          DELTASET   *ds) ;
*
*   general     The routine calculates the delta vector for
*               a deposit using a list of predefined shocks to the zero
*               coupon curve.
*
*               The delta vector represents the price differences
*               invoked by the curve shocks.
*
*   input       DATESTR   *analys       The analysis date.
*
*               DEPOSIT   *depo         The deposit definition
*
*               DISCFAC   *df           Discounting structure setup.
*                                       The initial (unshocked) curve
*                                       should be in df->disc.
*
*               HOLI_STR  *holi         Container for data on business
*                                       day convention and non-week-end
*                                       holidays.
*
*               DFSPREAD  *dfs          Spread against the curve.
*                                       Enter NULL if no spread.
*
*               DELTASET  *ds           Data for delta calculation
*
*   output
*
*   returns     The delta vector allocated as:
*
*                         Alloc_FL64ARRAY(ds->nshock) ;
*
*   diagnostics
*
*   see also    Bond_DF2Price()
*               Bond_DF2Delta()
*               Disc_DeltaPrep()
*               Boot_DeltaPrep()
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/

FL64ARRAY Deposit_DF2Delta(DATESTR* analys,
                           DEPOSIT*    depo,
                           DISCFAC*    df,
                           HOLI_STR*   holi,
                           DFSPREAD*   dfs,
                           DELTASET*   ds)
{
    CFLWARRAY cflw ;
    FL64ARRAY dv ;
    FIXPAY    fixp ;

    /* Translate deposit into fixpay */
    fixp = Deposit_DEPOSIT2FIXPAY(depo, holi) ;

    /* Compute cash flow + Delta Vector */
    cflw = Cflw_GenrCflw(&fixp.repay, &fixp.rday, 
                          &fixp.fix, &fixp.cday, holi) ;
    dv   = Cflw_DF2Delta(analys, df, cflw, &fixp.repay.pp, holi, dfs, ds) ;

    /* Free */
    Free_CFLWARRAY(cflw, 1) ;

    return dv ;
}


/*,,SOH,,
*************************************************************************
*
*             Deposit_Accruint()
*
*   interface #include <bond.h>
*             AIRESULT Deposit_Accruint(DATESTR     *analys,
*                                       DEPOSIT     *depo,
*                                       HOLI_STR    *holi) ;
*
*   general   This function calculates the accrued interest for a depo-
*             sit at any time during the life of the deposit.
*
*   input     DATESTR    *analys    The settle date
*
*             DEPOSIT    *depo      The deposit data
*
*             HOLI_STR   *holi      Businessday adjustments.
*
*   output
*
*   returns   An AIRESULT containing the accrual calculations.
*
*   diagnostics
*
*   see also  Bond_Accruint()
*
*   wrapper   AP
*
*************************************************************************
,,EOH,,*/

AIRESULT Deposit_Accruint(DATESTR* analys,
                          DEPOSIT*  depo,
                          HOLI_STR* holi)
{
    FIXPAY    fixp ;
    CFLWARRAY cflw ;
    TRADEINFO end ;
    AIRESULT  air ;

    if (Cldr_DateLE(analys, &depo->effective) == True)
    {
        air.AI         = 0.0 ;
        air.AIdays     = 0 ;
        air.next       = depo->maturity ;
        air.exc        = False ;
        air.AI_per_day = 0.0 ;
        return air ;
    }

    /* Translate deposit into fixpay */
    fixp = Deposit_DEPOSIT2FIXPAY(depo, holi) ;

    /* Compute cash flow */
    cflw = Cflw_GenrCflw(&fixp.repay, &fixp.rday, &fixp.fix, 
                          &fixp.cday, holi) ;
    end  = bond_set_tradeinfo(analys) ;
    air  = Cflw_Accruint(&end, cflw, &fixp.fix, &fixp.cday.pseq, &fixp.accru,
                         holi, fixp.repay.pp.ppmts, NEXTINDEX) ;        /*  FPL-PMSTA00211-100826   */

    /* Free */
    Free_CFLWARRAY(cflw, 1) ;

    return air ;
}



/* SCID @(#)paydays.c	1.8 (SimCorp) 99/09/22 12:15:30 */

/************************************************************************
*
*   project     SCecon
*
*   filename    paydays.c
*
*   general     This file contains standard cash flow routines of
*               SCecon Library
*
************************************************************************/

/* includes ************************************************************/
#include <cflw.h>


/*,,SOH,,
*************************************************************************
*
*               Cflw_PaydaysCount()
*
*   interface   #include <cflw.h>
*               INTI Cflw_PaydaysCount(PAYDAYDEF  *pday,
*                                       HOLI_STR   *holi) ;
*
*   general     Cflw_PaydaysCount() calculates the number of payment
*               dates from the bond with respect to the odd coupon
*               code, end of month convention and period convention.
*
*               Upon calling this function Cflw_Paydays() can be invoked*
*               to find the payment dates.
*
*               Note that on some occasions the number generated here
*               may be 1 too large, since in (weird) cases the last
*               2 paydays are coinciding. This problem is handled
*               directly in Cflw_Paydays() by removing non-unique days
*               from the list.
*
*   input       PAYDAYDEF *pday         Pointer to the data describing
*                                       the payday sequence.
*
*               HOLI_STR  *holi         Container for data on business
*                                       day convention and non-week-end
*                                       holidays.
*
*   output
*
*   returns     the number of payment days as INTI.
*
*   diagnostics
*
*   see also    Cflw_Paydays()
*
*************************************************************************
,,EOH,,*/

INTI Cflw_PaydaysCount(PAYDAYDEF* pday,
                        HOLI_STR* holi)
{
    INTI     j, i, total ;
    DATESTR  anchor, old, dslast, stop, datec, dmatur, dstart ;
    BOOLE    slm, sl, hit ;
    EOMCONV  eom ;
    PERIOD   per ;
    SEQCONV  roll ;

    if (pday->nirreg > 0)
        return pday->nirreg ;

    total  = 1 ;
    dmatur = pday->last ;
    dslast = pday->seclast ;
    dstart = pday->first ;

    if (Cldr_DateLT(&dmatur, &dstart) == True)
        dstart = dmatur ;

    /* Be careful about second last payday */
    slm = sl = False ;
    if (pday->pseq.oddn == LONGODD && Cldr_DateLE(&dstart, &dslast) == True &&
        Cldr_DateLT(&dslast, &dmatur) == True)
        sl = True ;

    if (pday->pseq.oddn == LONGODD && (Cldr_DateLT(&dslast, &dstart) == True ||
        Cldr_DateLT(&dmatur, &dslast) == True))
        slm = True ;

    /* A simple consistency check */
    eom = pday->pseq.eom ;
    if (dmatur.d == 31 || dstart.d == 31 || dslast.d == 31)
        eom = LAST ;

    /* Handle 'snapping' */
    pday->first = Cflw_Snap2(&dstart, pday->pseq.seq, pday->snap2, holi) ;
    dstart      = pday->first ;
    pday->last  = Cflw_Snap2(&dmatur, pday->pseq.seq, pday->snap2, holi) ;
    dmatur      = pday->last ;

    if (sl == True)
    {
        pday->seclast = Cflw_Snap2(&dslast, pday->pseq.seq, pday->snap2, holi);
        dslast        = pday->seclast ;
    }

    /* First handle the case with NO frequency */
    if (pday->pseq.term == 0)
    {
        if (Cldr_DateEQ(&dmatur, &dstart) == True || pday->is_first == False)
            return 1 ;
        else
            return 2 ;
    }

    /* Now be careful about first being issue and the first period is broken */
    if (pday->is_first == False && pday->pseq.odd1 != NOODD &&
        Cflw_Is_Anchored(pday->pseq.seq) == True)
        roll = ANCHORBACK ;
    else
        roll = pday->pseq.seq ;

    /* Count the following payment days */
    switch (roll)
    {
        case ANCHOR:
        case ANCHORSHIFT:
        case TAM_T4M:

            if (pday->pseq.seq == ANCHORSHIFT)
            {
                dstart.d = 1 ;
                dmatur.d = 1 ;
            }

            total = (pday->is_first == True ? 1 : 0) ;
            datec = dstart ;

            if (sl == True)
                stop = dslast ;
            else
                stop = dmatur ;

            i = 1 ;
            while (Cldr_DateLT(&datec, &stop) == True)
            {
                old   = datec ;
                per   = Set_PERIOD(i * pday->pseq.term, pday->pseq.unit);
                datec = Cldr_NextROLL(&dstart, pday->pseq.seq, &per, 
                                      ACTACT, eom, holi) ;
                if (old.y != datec.y && pday->pseq.seq == ANCHORSHIFT)
					datec = Cldr_AddDays(&datec, 1, ACTACT, NULL);  	/* PMSTA-22396 - SRIDHARA � 160502 */
                
                total++ ;
                i++ ;
            }

            if (sl == True)
                total++ ;

            if (slm == True)
                total-- ;

            break ;

        case ANCHORBACK:

            if (sl == True)
            {
                datec = dslast ;
                total = 1 ;
            }
            else
            {
                datec = dmatur ;
                total = 0 ;
            }

            hit    = False ;
            anchor = datec ;
            j      = 0 ;

            while (Cldr_DateLE(&dstart, &datec) == True)
            {
                j++ ;
                per   = Set_PERIOD(-j * pday->pseq.term, pday->pseq.unit);
                datec = Cldr_NextROLL(&anchor, ANCHORBACK, &per,
                                      ACTACT, eom, holi) ;
                total++ ;
                if (Cldr_DateEQ(&dstart, &datec) == True)
                    hit = True ;
            }

            if (pday->is_first == False)
            {
                if (hit == True || pday->pseq.odd1 == LONGODD)
                    total-- ;
            }

            if (pday->is_first == True && hit == False)
                total++ ;

            break ;

        case IMM:
        case IMM_ZAR:
        case CAD_BA:
        case LASTBUS:
        case CHAIN:

            per   = Set_PERIOD(pday->pseq.term, pday->pseq.unit);
            total = (pday->is_first == True ? 1 : 0) ;

            if (pday->pseq.seq == CHAIN)
                datec = Cldr_NextBusinessDate(&dstart, holi) ;
            else
                datec = dstart ;

            if (sl == True)
                stop = dslast ;
            else
                stop = dmatur ;

            while (Cldr_DateLT(&datec, &stop) == True)
            {
                datec = Cldr_NextROLL(&datec, pday->pseq.seq, &per, 
                                      ACTACT, eom, holi) ;
                total++ ;
            }

            if (sl == True)
                total++ ;

            if (slm == True)
                total-- ;

            break ;
    }

    return total ;
}


/*,,SOH,,
*************************************************************************
*
*               Cflw_Paydays()
*
*   interface   #include <cflw.h>
*               DATEARRAY Cflw_Paydays(PAYDAYDEF  *pday,
*                                      HOLI_STR   *holi,
*                                      INTI       *count) ;
*
*   general     Cflw_Paydays() calculates the paydays for the cashflow
*               with respect to the various conventions.
*
*               Upon exit all paydays has been moved to business days
*               according to the businessday convention used.
*
*               The days generated in this routine are unique. If coin-
*               ciding dates occur the redundant days are removed. This
*               may happen in very rare cases in the last period.
*               In this case - of course - the count is returned as the
*               correct value.
*
*               Note that irregular paydays can be accommodated by
*               setting pday data suitably.
*
*   input       PAYDAYDEF *pday         Pointer to the description of
*                                       the payday sequence.
*
*               HOLI_STR  *holi         Container for data on business
*                                       day convention and non-week-end
*                                       holidays.
*
*   output      INTI      *count        The number of paydays.
*
*   returns     Pointer to the list of paydays. Allocated in this
*               routine with as Alloc_DATEARRAY(*count)
*
*   diagnostics
*
*   see also    
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/

DATEARRAY Cflw_Paydays(PAYDAYDEF* pday,
                       HOLI_STR*   holi,
                       INTI*       count)
{
    INTI      ix, count1, m, i, j ;
    DATEARRAY paydays, paydays1 ;
    DATESTR   anchor, dslast, dmatur, dstart ;
    BOOLE     sl ;
    EOMCONV   eom ;
    PERIOD    per ;
    SEQCONV   roll ;

    count1   = Cflw_PaydaysCount(pday, holi) ;
    paydays1 = Alloc_DATEARRAY(count1) ;

    if (pday->nirreg > 0)
    {
        for (i = 0; i < pday->nirreg; i++)
            paydays1[i] = pday->irreg_days[i] ;

        paydays = Cldr_UniqueDates(count1, paydays1, count) ;
        Cldr_Move2BusinessDays(paydays, *count, holi) ;
        Free_DATEARRAY(paydays1) ;

        return paydays ;
    }

    dmatur = pday->last ;
    dslast = pday->seclast ;
    dstart = pday->first ;

    if (Cldr_DateLT(&dmatur, &dstart) == True)
        dstart = dmatur ;

    /* Be careful about second last payday */
    sl = False ;
    if (pday->pseq.oddn == LONGODD && Cldr_DateLT(&dstart, &dslast) == True &&
        Cldr_DateLT(&dslast, &dmatur) == True)
        sl = True ;

    /* A simple consistency check */
    eom = pday->pseq.eom ;
    if (dmatur.d == 31 || dstart.d == 31 || dslast.d == 31)
        eom = LAST ;

    if (pday->pseq.term == 0)
    {
        if (count1 == 1)
          paydays1[0] = dmatur ;
        else if (count1 == 2)
        {
          paydays1[0] = dstart ;
          paydays1[1] = dmatur ;
        }

        if (pday->pseq.seq == CHAIN)
        {
            paydays1[0] = Cldr_NextBusinessDate(&paydays1[0], holi) ;
            if (count1 == 2)
                paydays1[1] = Cldr_NextBusinessDate(&paydays1[1], holi) ;
        }
        else
            Cldr_Move2BusinessDays(paydays1, count1, holi) ;

        paydays = Cldr_UniqueDates(count1, paydays1, count) ;
        Free_DATEARRAY(paydays1) ;

        return paydays ;
    }

    /* Now be careful about first being issue and the first period is broken */
    if (pday->is_first == False && pday->pseq.odd1 != NOODD &&
        Cflw_Is_Anchored(pday->pseq.seq) == True)
        roll = ANCHORBACK ;
    else
        roll = pday->pseq.seq ;

    /* Find the event days */
    switch (roll)
    {
        case ANCHOR:
        case ANCHORSHIFT:
        case TAM_T4M:

            if (pday->pseq.seq == ANCHORSHIFT)
            {
                dstart.d = 1 ;
                dmatur.d = 1 ;
            }

            ix = (pday->is_first == True ? 0 : 1) ;

            for (i = 0 ; i < count1 ; i++)
            {
                per = Set_PERIOD((i + ix) * pday->pseq.term, pday->pseq.unit);
                paydays1[i] = Cldr_NextROLL(&dstart, pday->pseq.seq, &per,
                                            ACTACT, eom, holi) ;
            }

            if (count1 > 1)
                paydays1[count1 - 1] = dmatur ;

            if (count1 > 2 && sl == True)
                paydays1[count1 - 2] = dslast ;

            /* Find first payday in any year -- ANCHORSHIFT */
            if (pday->pseq.seq == ANCHORSHIFT)
            {
                for (j = 1; j < count1; j++)
                {
                    if (paydays1[j].y > paydays1[j - 1].y)
                        break ;
                }

                m = paydays1[j].m ;

                for (i = 0; i < count1 ; i++)
                {
                    if (paydays1[i].m == m &&
                        Cldr_DateEQ(&paydays1[i], &dslast) == False)
						paydays1[i] = Cldr_AddDays(&paydays1[i], 1, ACTACT, NULL);  	/* PMSTA-22396 - SRIDHARA � 160502 */
                }
            }

            Cldr_Move2BusinessDays(paydays1, count1, holi) ;

            break ;

        case ANCHORBACK:
            if (count1 < 1) break;      /* PMSTA15291-JPP-130207 - Crash prevention */
            paydays1[count1 - 1] = dmatur ;
            i = count1 - 2 ;
            anchor = dmatur ;
            if (sl == True && count1 > 1)
            {
                paydays1[count1 - 2] = dslast ;
                i = count1 - 3 ;
                anchor = dslast ;
            }

            for (; i >= 0 ; i--)
            {
                j = (count1 - 1) - i ;
                if (sl == True && count1 > 1)
                    j-- ;

                per = Set_PERIOD(- j * pday->pseq.term, pday->pseq.unit);
                paydays1[i] = Cldr_NextROLL(&anchor, ANCHORBACK, &per,
                                            ACTACT, eom, holi) ;
            }

            if (pday->is_first == True && count1 > 0)
                paydays1[0] = dstart ;

            Cldr_Move2BusinessDays(paydays1, count1, holi) ;

            break ;

        case CHAIN:
        case LASTBUS:

            per = Set_PERIOD(pday->pseq.term, pday->pseq.unit);

            if (pday->is_first == True)
                paydays1[0] = Cldr_NextBusinessDate(&dstart, holi) ;
            else
                paydays1[0]= Cldr_NextROLL(&dstart, pday->pseq.seq, &per, 
                                           ACTACT, eom, holi) ;

            for (i = 1 ; i < count1 ; i++)
                paydays1[i]= Cldr_NextROLL(&paydays1[i - 1], pday->pseq.seq, 
                                           &per, ACTACT, eom, holi) ;

            if (count1 > 1)
                paydays1[count1 - 1] = Cldr_NextBusinessDate(&dmatur, holi) ;

            if (count1 > 2 && sl == True)
                paydays1[count1 - 2] = Cldr_NextBusinessDate(&dslast, holi) ;

            break ;

        case IMM:
        case IMM_ZAR:
        case CAD_BA:
        
            per = Set_PERIOD(pday->pseq.term, pday->pseq.unit);
        
            if (pday->is_first == True)
                paydays1[0] = dstart ;
            else
                paydays1[0]= Cldr_NextROLL(&dstart, pday->pseq.seq, &per, 
                                           ACTACT, eom, holi) ;

            for (i = 1 ; i < count1 ; i++)
                paydays1[i] = Cldr_NextROLL(&paydays1[i - 1], pday->pseq.seq, 
                                            &per, ACTACT, eom, holi) ;

            if (count1 > 1)
                paydays1[count1 - 1] = dmatur ;

            if (count1 > 2 && sl == True)
                paydays1[count1 - 2] = dslast ;

            Cldr_Move2BusinessDays(paydays1, count1, holi) ;

            break ;
    }

    /* Chk for uniqueness */
    paydays = Cldr_UniqueDates(count1, paydays1, count) ;
    Free_DATEARRAY(paydays1) ;

    return paydays ;
}

/*,,SOH,,
*************************************************************************
*
*               Cflw_ExtractPaydays()
*
*   interface   #include <cflw.h>
*               PAYDAYDEF Cflw_ExtractPaydays(DATESTR   *first,
*                                             DATESTR   *last,
*                                             PAYDAYDEF *pday,
*                                             HOLI_STR  *holi) ;
*
*   general     Cflw_ExtractPaydays() calculates the paydays specified by
*               a payday-definition and stores the subset of these paydays
*               between two dates in a new payday-definition.
*
*               The paydays are holiday adjusted before the extract is made.
*               The dates first and last are not holiday adjusted.
*               Dates equal to first or last are included.
*
*               The days generated in this routine are unique. If coin-
*               ciding dates occur the redundant days are removed.
*
*   input       DATESTR   *first        Pointer to the earliest payday
*                                       to be included.
*
*               DATESTR   *last         Pointer to the latest payday
*                                       to be included.
*
*               PAYDAYDEF *pday         Pointer to the description of
*                                       the payday sequence.
*
*               HOLI_STR  *holi         Container for data on business
*                                       day convention and non-week-end
*                                       holidays.
*
*   output
*
*   returns     A payday definition of holiday adjusted paydays between
*               the specified dates. An array of irregular paydays
*               irreg_days is allocated in this routine using
*               Alloc_DATEARRAY().
*
*   diagnostics
*
*   see also    Cflw_Paydays()
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/

PAYDAYDEF Cflw_ExtractPaydays(DATESTR*  first,
                                        DATESTR*  last,
                                        PAYDAYDEF*  pday,
                                        HOLI_STR*  holi)
{
  PAYDAYDEF res;
  DATEARRAY pd;
  INTI pdcount;
  INTI i;
  INTI firstidx, lastidx;
  DATEARRAY irreg;
  INTI cnt;

  pd = Cflw_Paydays(pday, holi, &pdcount);
  
  /* Find index of first payday */
  firstidx = 0;
  while (firstidx < pdcount && Cldr_DateLT(&pd[firstidx],first))
    firstidx++;

  /* Find index of last payday */
  lastidx = pdcount - 1;
  while (lastidx > -1 && Cldr_DateLT(last,&pd[lastidx]))
    lastidx--;

  if (firstidx > lastidx)
    res = Set_PAYDAYDEF(True, NULL, NULL, NULL, False, NULL, 0, NULL);
  else
  {
    cnt = lastidx - firstidx + 1;
    irreg = Alloc_DATEARRAY(cnt);
    for (i = 0; i < cnt; i++)
      irreg[i] = pd[firstidx + i];
    res = Set_PAYDAYDEF(True, &pd[firstidx], NULL, &pd[lastidx], pday->snap2,
        &pday->pseq, cnt, irreg);
  }
  Free_DATEARRAY(pd);

  return res;
}

/*
*************************************************************************
*
*               Cflw_mmdd2Paydays_count()
*
*   interface   #include <cflw.h>
*               INTI Cflw_mmdd2Paydays_count(DATESTR   *dstart,
*                                            DATESTR   *dmatur,
*                                            MMDDARRAY mmdd,
*                                            INTI      n,
*                                            ODDCONV   odd) ;
*
*   general     Cflw_mmdd2Paydays_count() calculates the number of pay-
*               dates from the bond with respect to the odd coupon
*               code and MMDD specification.
*
*               Notice that the long periods cannot exceed 2 ordinary
*               coupon periods.
*
*               Upon calling this function Cflw_mmdd2Paydays() can be
*               invoked to find the payment dates.
*
*   input       DATESTR  *dstart        Pointer to the first payday.
*
*               DATESTR  *dmatur        Pointer to the maturity date.
*
*               MMDDARRAY mmdd          Array of payterms.
*
*               INTI      n             Number of entries in mmdd. If
*                                       zero then the only paydays are
*                                       dstart and dmatur.
*
*               ODDCONV   odd           Odd coupon period mark.
*
*   output
*
*   returns     the number of payment days as INTI.
*
*   diagnostics
*
*   see also    Cflw_Paydays()
*               Cflw_mmdd2Paydays()
*
*************************************************************************
*/

INTI Cflw_mmdd2Paydays_count(DATESTR* dstart,
                              DATESTR*  dmatur,
                              MMDDARRAY mmdd,
                              INTI      n,
                              ODDCONV   odd)
{
    INTI    imd, total ;
    DATESTR date ;
    MMDD    *pmmdd ;
    BOOLE   found ;

    total = 1 ;

    if (n == 0)
    {
        if (Cldr_DateEQ(dmatur, dstart) == True)
            return 1 ;
        else
            return 2 ;
    }
    /* Count the following payment days */

    pmmdd  = mmdd ;

    total  = 1 ;
    date.y = dstart->y ;
    found  = False ;

    while (found == False)
    {
        for (imd = 0 ; imd < n ; imd++)
        {
            date.m = pmmdd[imd]/100 ;
            date.d = pmmdd[imd] - 100 * (pmmdd[imd]/100) ;
            if (Cldr_DateLE(&date, dmatur) == False)
            {
                if (odd == SHORTODD)
                    total++ ;

                found = True ;
                break ;
            }
            if (Cldr_DateLT(dstart, &date) == True)
                total++ ;
        }
        date.y++ ;
    }

    if (total > 2 && odd == LONGODD)
        total-- ;

    return total ;
}


/*
*************************************************************************
*
*               Cflw_mmdd2Paydays()
*
*   interface   #include <cflw.h>
*               DATEARRAY Cflw_mmdd2Paydays(DATESTR   *dstart,
*                                           DATESTR   *dmatur,
*                                           MMDDARRAY mmdd,
*                                           INTI      n,
*                                           ODDCONV   odd,
*                                           INTI      *count) ;
*
*   general     Cflw_mmdd2Paydays() calculates the paydays
*               from the bond with respect to the MMDD spec.
*
*               Notice that the long periods cannot exceed 2 ordinary
*               coupon periods.
*
*               Notice that the odd convention for the first period is
*               not used.
*
*   input       DATESTR  *dstart        Pointer to the first payday.
*
*               DATESTR  *dmatur        Pointer to the maturity date.
*
*               MMDDARRAY mmdd          Array of payterms.
*
*               INTI      n             Number of entries in mmdd. If
*                                       zero then the only paydays are
*                                       dstart and dmatur.
*
*               ODDCONV   odd           Oddities convention
*
*   output      INTI      *count        Number of payments calculated
*
*   returns     Pointer to the list of paydays. Allocated in this
*               routine as Alloc_DATEARRAY(*count)
*
*   diagnostics
*
*   see also    Cflw_Paydays()
*               Cflw_mmdd2Paydays_count()
*
*************************************************************************
*/

DATEARRAY Cflw_mmdd2Paydays(DATESTR* dstart,
                            DATESTR*  dmatur,
                            MMDDARRAY mmdd,
                            INTI      n,
                            ODDCONV   odd,
                            INTI*      count)
{
    INTI      imd, i ;
    DATESTR   date ;
    MMDD      *pmmdd ;
    BOOLE     found ;
    DATEARRAY paydays ;

    *count  = Cflw_mmdd2Paydays_count(dstart, dmatur, mmdd, n, odd) ;
    paydays = Alloc_DATEARRAY(*count) ;

    if (n == 0)
    {
        if (Cldr_DateEQ(dmatur, dstart) == True)
            paydays[0] = *dstart ;
        else
        {
            paydays[0] = *dstart ;
            paydays[1] = *dmatur ;
        }

        return paydays ;
    }

    /* Count the following payment days */

    pmmdd   = mmdd ;

    date.y  = dstart->y ;
    found   = False ;
    paydays[0] = *dstart ;
    i       = 1 ;

    while (found == False)
    {
        for (imd = 0 ; imd < n ; imd++)
        {
            date.m = pmmdd[imd]/100 ;
            date.d = pmmdd[imd] - 100 * (pmmdd[imd]/100) ;
            if (Cldr_DateLT(dstart, &date) == True)
                paydays[i++] = date ;

            if (i >= *count)
            {
                found = True ;
                break ;
            }
        }

        date.y++ ;
    }

    if (*count > 1)
        paydays[*count - 1] = *dmatur ;

    return paydays ;
}


/*
..
*/

PAYDAYDEF cflw_set_payday(DATESTR* first, DATESTR* seclast, DATESTR* last,
                          BOOLE snap2, INTI term, TERMUNIT unit,
                          ODDCONV odd1, ODDCONV oddn, SEQCONV per, EOMCONV eom)
{
    PAYDAYDEF pday ;
    
    pday.is_first = True ;
    pday.first  = *first ;
    pday.seclast= *seclast ;
    pday.last   = *last ;
    pday.snap2  = snap2 ;
    pday.pseq.term = term ;
    pday.pseq.unit = unit ;
    pday.pseq.odd1 = odd1 ;
    pday.pseq.oddn = oddn ;
    pday.pseq.seq  = per ;
    pday.pseq.eom  = eom ;

    pday.nirreg     = 0 ;
    pday.irreg_days = NULL ;

    return pday ;
}

/*
..
*/

DATESTR Cflw_Snap2(DATESTR* in, SEQCONV seq, BOOLE snap2, HOLI_STR* holi)
{
    DATESTR out ;

    if (snap2 == True)
        out = Cldr_NextROLL(in, seq, NULL, ACTACT, LAST, holi) ;
    else
        out = *in ;

    return out ;
}


/*
..
*/

BOOLE Cflw_Is_Anchored(SEQCONV  roll)
{
    if (roll == ANCHOR || roll == TAM_T4M || roll == ANCHORSHIFT)
        return True ;
    else
        return False ;
}

/*
..
*/

/*,,SOH,,
************************************************************************
*
*                Set_PAYDAYDEF()
*
*   interface    #include <cflw.h>
*                PAYDAYDEF Set_PAYDAYDEF(BOOLE      is_first,
*                                        DATESTR*   first,
*                                        DATESTR*   seclast,
*                                        DATESTR*   last,
*                                        BOOLE      snap2,
*                                        PAYDAYSEQ* pseq,
*                                        INTI       nirreg,
*                                        DATEARRAY  irreg_days) ;
*
*   general      This routine sets the members of the struct defined
*                in the function name. The pointer members are simply
*                assigned - without physical copying. The intention
*                of the Set_*() routines is that by using this
*                functionality, one avoids setting individual members
*                of structs in the application code.
*
*                When new members are inserted in structs the Set_*()
*                routine will be changed accordingly.
*
*                One exception to this principle applies. Whenever
*                OPTADD and vanilla members are used, only the
*                vanilla members are set in the Set_*() routines. The
*                non-vanilla and exotic members are set to defaults,
*                and must be set elsewhere - if needed.
*
*                For details on the interpretation of the individual
*                struct members please check the struct definition.
*
*   input        BOOLE      is_first   See general section.
*
*                DATESTR*   first      See general section.
*
*                DATESTR*   seclast    See general section.
*                                      Enter NULL for default
*
*                DATESTR*   last       See general section.
*
*                BOOLE      snap2      See general section.
*
*                PAYDAYSEQ* pseq       See general section.
*                                      Enter NULL for dummies
*
*                INTI       nirreg     See general section.
*
*                DATEARRAY  irreg_days See general section.
*
*   output
*
*   returns      The filled out PAYDAYDEF struct
*
*   diagnostics
*
*   see also     PAYDAYDEF
*
************************************************************************
,,EOH,,*/

PAYDAYDEF Set_PAYDAYDEF(BOOLE is_first, 
                           DATESTR* first, 
                           DATESTR* seclast, 
                           DATESTR* last,
                           BOOLE snap2, 
                           PAYDAYSEQ* pseq, 
                           INTI nirreg,
                           DATEARRAY irreg_days)
{
    PAYDAYDEF pday ;

    pday.is_first = is_first ;
    pday.first  = *first ;
    if (seclast == NULL)
        pday.seclast= Cldr_YMD2Datestr(0) ;
    else    
        pday.seclast= *seclast ;
    pday.last   = *last ;
    pday.snap2  = snap2 ;

    if (pseq != NULL)
        pday.pseq = *pseq ;
    else
        pday.pseq = Set_PAYDAYSEQ(0, YEARS, NOODD, NOODD, ANCHOR, LAST) ;

    pday.nirreg     = nirreg ;
    pday.irreg_days = irreg_days ;

    return pday ;
}

/*
..
*/

/*,,SOH,,
************************************************************************
*
*                Set_PAYDAYSEQ()
*
*   interface    #include <cflw.h>
*                PAYDAYSEQ Set_PAYDAYSEQ(INTI     term,
*                                        TERMUNIT unit,
*                                        ODDCONV  odd1,
*                                        ODDCONV  oddn,
*                                        SEQCONV  per,
*                                        EOMCONV  eom) ;
*
*   general      This routine sets the members of the struct defined
*                in the function name. The pointer members are simply
*                assigned - without physical copying. The intention
*                of the Set_*() routines is that by using this
*                functionality, one avoids setting individual members
*                of structs in the application code.
*
*                When new members are inserted in structs the Set_*()
*                routine will be changed accordingly.
*
*                One exception to this principle applies. Whenever
*                OPTADD and vanilla members are used, only the
*                vanilla members are set in the Set_*() routines. The
*                non-vanilla and exotic members are set to defaults,
*                and must be set elsewhere - if needed.
*
*                For details on the interpretation of the individual
*                struct members please check the struct definition.
*
*   input        INTI     term See general section.
*
*                TERMUNIT unit See general section.
*
*                ODDCONV  odd1 See general section.
*
*                ODDCONV  oddn See general section.
*
*                SEQCONV  per  See general section.
*
*                EOMCONV  eom  See general section.
*
*   output
*
*   returns      The filled out PAYDAYSEQ struct
*
*   diagnostics
*
*   see also     PAYDAYSEQ
*
************************************************************************
,,EOH,,*/

PAYDAYSEQ Set_PAYDAYSEQ(INTI term, TERMUNIT unit, ODDCONV odd1, 
                           ODDCONV oddn, SEQCONV per, EOMCONV eom)
{
    PAYDAYSEQ pseq ;

    pseq.term = term ;
    pseq.unit = unit ;
    pseq.odd1 = odd1 ;
    pseq.oddn = oddn ;
    pseq.seq  = per ;
    pseq.eom  = eom ;

    return pseq ;
}

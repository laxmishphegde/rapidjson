/* @(#)scenario.c	1.6 (SimCorp) 99/10/27 13:58:36 */

/************************************************************************
*
*   project     SCecon
*
*   filename    scenario.c
*
*   contains    routines in the SCecon Library Scenario module
*
************************************************************************/
/***** list of to do's **************************************************
  TODO: ScenBPV for Fut instruments.
************************************************************************/


/***** includes ********************************************************/
#include <scenario.h>

/***** defines  ********************************************************/
#define DISC_TOLR  (FL64)    0.00000001
#define DAY_TOL    (FL64)    0.001
#define IRR_ACC    (FL64)    0.0000000001
#define IRR_MAXIT  (INTI)  150
#define IRR_FREQ   (INTI)    5
#define IRR_DAMP   (FL64)    0.9
#define REPAY_TOL  (FL64)   50.0
#define COUPON_TOL (FL64)   0.1



/*,,SOH,,
*************************************************************************
*
*               Disc_ScenarioPrep()
*
*    interface  #include <scenario.h>
*               DELTASET Disc_ScenarioPrep(DISCFAC      *df,
*                                           SCENARIOLIST *scen,
*                                           HOLI_STR     *holi,
*                                           IRRCONV      irr,
*                                           PMTFREQ      freq,
*                                           BOOLE        dom) ;
*
*    general    The function shocks a discount structure using a list
*               of scenarios.
*
*               This functionality is a preprocessor for a scenario
*               calculation.
*
*               The actual scenario PV's can be calculated using the:
*
*                        Sec_Model2ScenBPV()
*
*               routines.
*
*               Linear interpolation is used to find shocks in between
*               grid points.
*
*               For another type of shock see Disc_DeltaPrep()
*
*    input      DISCFAC      *df   The discount function setup.
*
*               SCENARIOLIST *scen The scenario definitions
*
*               HOLI_STR     *holi Holiday setup
*
*               IRRCONV      irr   Convention for the type of spot rates*
*                                  that are shocked.
*
*               PMTFREQ      freq  The quoting of irr.
*
*               BOOLE        dom   Domestic (True) or foreign (False)
*
*    output
*
*    returns    A DELTASET ds holding:
*               ds.shock: Shocked discount function setup allocated as:
*
*                    Alloc_PLANARRAY(scen->nscen, x) ;
*
*               holding all the shocked discount factor curves.
*               ds.nshock  = nscen
*               ds.dom     = dom
*               ds.dfwhich = DF_BOTH
*               ds.zero    = False
*               ds.mid     = NULL
*               ds.token   = NULL
*               ds.size    = NULL
*
*    diagnostics
*
*    see also   Boot_DeltaPrep()
*
*************************************************************************
,,EOH,,*/


DELTASET Disc_ScenarioPrep(DISCFAC*   df,
                            SCENARIOLIST* scen,
                            HOLI_STR*     holi,
                            IRRCONV      irr,
                            PMTFREQ      freq,
                            BOOLE        dom)
{
    INTI        qb, maxbuck, i, j ;
    DELTASET    ds ;
    PLANARRAY   dfs, pts ;
    DISCFAC     dfn ;
    DATESTR     date, today ;
    FL64        disc, shock ;
    BUCKETARRAY ba ;

    ds = Set_DELTASET(NULL, 0, dom, DF_BOTH, False, NULL, NULL, 
                           irr, freq, NULL) ;

    for (maxbuck = i = 0; i < scen->nscen; i++)
        maxbuck = GETMAX(scen->scens[i].nbuck, maxbuck) ;

    if (maxbuck <= 0)
        return ds ;

    if (GetPlanFill(df->disc) < 1)
        return ds ;

    /* Allocate */
    ds.shock = dfs = Alloc_PLANARRAY(scen->nscen, 
                                     GetPlanFill(df->disc) + maxbuck) ;
    pts = Alloc_PLANARRAY(1, GetPlanFill(df->disc) + maxbuck) ;

    today = df->disc->day[0] ;
    qb    = disc_set_qbas(freq) ;

    for (i = 0; i < scen->nscen; i++)
    {
        /* Find actual scenario dates */
        for (pts->filled = j = 0; j < scen->scens[i].nbuck; j++)
        {
            ba = scen->scens[i].scen ;
            date = Cldr_TermUnit2Date(&today, ba[j].term,
                                      ba[j].unit, ACTACT, LAST, holi);
            date = Cldr_NextBusinessDate(&date, holi) ;
            Cldr_InsertInPlan(&date, ba[j].shock, pts, True) ;
        }

        dfn = Disc_insert_buckdates(df, scen->scens[i].scen, 
          scen->scens[i].nbuck, holi) ;
    
        /* Loop to generate scenarios */
        for (j = 0; j < dfn.disc->filled; j++)
        {
            shock = Cldr_Plan_Intpol(&dfn.disc->day[j], pts, dfn.cal, 
                                     LINEAR_FLAT_END, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
            disc  = Disc_Shock_Single(&today, &dfn.disc->day[j], 
                                      dfn.disc->f64[j], shock, dfn.cal,
									  irr, qb, holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */
            Cldr_InsertInPlan(&dfn.disc->day[j], disc, &dfs[i], True) ;
        }

        Free_PLANARRAY(dfn.disc, 1) ;
    }

    /* Clean up */
    Free_PLANARRAY(pts, 1) ;

    /* return */
    ds.nshock = scen->nscen ;

    return ds ;
}


/*,,SOH,,
*************************************************************************
*
*               Set_SCENARIOLIST()
*
*    interface  #include <scenario.h>
*               SCENARIOLIST Set_SCENARIOLIST(SCENARIOARRAY a,
*                              INTI n) ;
*
*    general    The routine sets a SCENARIOLIST struct.
*
*    input      SCENARIOARRAY  a  The scenarios.
*               INTI           n  The number of scenarios.
*
*    output
*
*    returns    SCENARIOLIST ds    Initialised SCENARIOLIST.
*
*    diagnostics
*
*    see also   Alloc_SCENARIOARRAY()
*               Free_SCENARIOARRAY()
*
*************************************************************************
,,EOH,,*/

SCENARIOLIST Set_SCENARIOLIST(SCENARIOARRAY a, INTI n) 
{
    SCENARIOLIST ds;

    ds.nscen = n;
    ds.scens = a;

    return ds;
}



/*,,SOH,,
*************************************************************************
*
*               FX_ShockPrep()
*
*    interface  #include <scenario.h>
*               FXSHOCKSET FX_ShockPrep(FL64 fx_spot,
*                                     FL64ARRAY shocks,
*                                     INTI      nshock,
*                                     CCYCODE   *ccy)
*
*    general    The function shocks a FX spot rate using various
*               shocks.
*
*               This functionality is a preprocessor for a scenario
*               calculation.
*
*               The shocks used here are on the spot rate.
*               For each shock a shocked fx-spot will be produced.
*               The shocks are absolute shocks quoted as fx_spot.
*               A RISKTOKEN is stored for the *_*2RiskPos functions
*               - used for VAR calculations.
*
*    input      FL64        fx_spot  The FX spot rate.
*
*               FL64ARRAY   shocks   The array of shocks in the spot
*                                    rate.
*
*               INTI        nshock   No. of shocks in shocks.
*
*               CCYCODE     *ccy     The currency of the FX spot rate.
*
*    output
*
*    returns    A FXSHOCKSET holding:
*               ds.shocked: Fx rates allocated as:
*
*                    Alloc_FL64ARRAY(nshock) ;
*
*               holding all the shocked FX spot rates.
*               ds.nshock = nshock
*               ds.token.ccy = *ccy
*               ds.token.rclass = XS_NAME
*
*    diagnostics
*
*    see also
*
*************************************************************************
,,EOH,,*/


FXSHOCKSET FX_ShockPrep(FL64 fx_spot,
    FL64ARRAY shocks,
    INTI nshock,
    CCYCODE* ccy)
                     
{
    INTI       i ;
    FXSHOCKSET fxs;

    fxs.shocked = Alloc_FL64ARRAY(nshock) ;
    fxs.nshock = nshock ;

    if (ccy != NULL)
    {
      strncpy(fxs.token.ccy, *ccy, CCY_LENGTH);
    }
    strncpy(fxs.token.rclass, XS_NAME, CLASS_LENGTH);

    if (nshock <= 0)
        return fxs ;

    for (i = 0; i < nshock; i++)
    {
        fxs.shocked[i] = fx_spot + shocks[i];
    }

    return fxs ;
}



/*,,SOH,,
*************************************************************************
*
*               EQTY_Shock_Prep()
*
*    interface  #include <scenario.h>
*               EQTYSHOCKSET EQTY_Shock_Prep(FL64       spot,
*                                            FL64ARRAY  shocks,
*                                            INTI       nshock) ;
*
*    general    The function shocks a Equity spot price using various
*               shocks.
*
*               This functionality is a preprocessor for a scenario
*               calculation.
*
*               The shocks used here are on the spot rate.
*               For each shock a shocked equity-spot will be produced.
*               The shocks are absolute shocks quoted as spot.
*
*    input      FL64        spot     The Equity spot price.
*
*               FL64ARRAY   shocks   The array of shocks in the spot
*                                    prices.
*
*               INTI        nshock   No. of shocks in shocks.
*
*    output
*
*    returns    A EQTYSHOCKSET holding:
*               ds.shocked: equity prices allocated as:
*
*                    Alloc_FL64ARRAY(nshock) ;
*
*               holding all the shocked equity spot prices.
*               ds.nshock = nshock
*
*    diagnostics
*
*    see also
*
*************************************************************************
,,EOH,,*/


EQTYSHOCKSET EQTY_Shock_Prep(FL64 spot,
    FL64ARRAY shocks,
    INTI nshock)
                     
{
    INTI         i ;
    EQTYSHOCKSET eqtys;

    eqtys.shocked = Alloc_FL64ARRAY(nshock) ;
    eqtys.nshock  = nshock ;

    if (nshock <= 0)
        return eqtys ;

    for (i = 0; i < nshock; i++)
        eqtys.shocked[i] = spot + shocks[i];

    return eqtys ;
}




/*,,SOH,,
*************************************************************************
*
*               Free_FXSHOCKSET()
*
*    interface  #include <scenario.h>
*               void Free_FXSHOCKSET(FXSHOCKSET *fxs) ;
*
*    general    Free_FXSHOCKSET() frees memory for a FXSHOCKSET struct
*
*    input      FXSHOCKSET *fxs   Reference to the FXSHOCKSET type
*
*    output
*
*    returns
*
*    diagnostics
*
*    see also
*
*************************************************************************
,,EOH,,*/


void Free_FXSHOCKSET(FXSHOCKSET* fxs)
{
    Free_FL64ARRAY(fxs->shocked) ;
}


/*,,SOH,,
*************************************************************************
*
*               Free_EQTYSHOCKSET()
*
*    interface  #include <scenario.h>
*               void Free_EQTYSHOCKSET(EQTYSHOCKSET *eqtys) ;
*
*    general    Free_EQTYSHOCKSET() frees memory for a EQTYSHOCKSET
*               struct
*
*    input      EQTYSHOCKSET *eqtys  Reference to the EQTYSHOCKSET type
*
*    output
*
*    returns
*
*    diagnostics
*
*    see also
*
*************************************************************************
,,EOH,,*/


void Free_EQTYSHOCKSET(EQTYSHOCKSET* eqtys)
{
    Free_FL64ARRAY(eqtys->shocked) ;
}





/*,,SOH,,
*************************************************************************
*
*               Free_SCENARIOLIST()
*
*    interface  #include <scenario.h>
*               void Free_SCENARIOLIST(SCENARIOLIST *ds) ;
*
*    general    The routine frees memory for a SCENARIOLIST struct
*               using Free_SCENARIOARRAY and Free_SCENARIO.
*
*    input      SCENARIOLIST   *ds    Reference to the data type
*
*    output
*
*    returns
*
*    diagnostics
*
*    see also   Free_SCENARIO()
*               Free_SCENARIOARRAY()
*
*************************************************************************
,,EOH,,*/


void Free_SCENARIOLIST(SCENARIOLIST* ds)
{
    INTI i;

    for (i = 0; i < ds->nscen; i++)
        Free_SCENARIO(&ds->scens[i]);

    Free_SCENARIOARRAY(ds->scens);
}


/*,,SOH,,
*************************************************************************
*
*               Alloc_SCENARIO()
*
*    interface  #include <scenario.h>
*               SCENARIO Alloc_SCENARIO(INTI nbuck) ;
*
*    general    The routine allocates memory for a SCENARIO struct
*
*    input      INTI       nbuck  The number of grid points in the
*                                 scenario.
*
*    output
*
*    returns    SCENARIO          Allocated SCENARIO.
*
*    diagnostics
*
*    see also   Alloc_SCENARIOARRAY()
*
*************************************************************************
,,EOH,,*/

SCENARIO Alloc_SCENARIO(INTI nbuck) 
{
    SCENARIO ds;

    nbuck = GETMAX(0, nbuck);

    ds.nbuck = nbuck;
    ds.scen = Alloc_BUCKETARRAY(nbuck);

    return ds;
}


/*,,SOH,,
*************************************************************************
*
*               Free_SCENARIO()
*
*    interface  #include <scenario.h>
*               void Free_SCENARIO(SCENARIO *ds) ;
*
*    general    The routine frees memory for a SCENARIO struct
*
*    input      SCENARIO   *ds    Reference to the data type
*
*    output
*
*    returns
*
*    diagnostics
*
*    see also   Free_SCENARIOLIST()
*               Free_SCENARIOARRAY()
*
*************************************************************************
,,EOH,,*/

void Free_SCENARIO(SCENARIO* ds) 
{
    Free_BUCKETARRAY(ds->scen);
}


/*,,SOH,,
*************************************************************************
*
*               Alloc_SCENARIOARRAY()
*
*    interface  #include <scenario.h>
*               SCENARIOARRAY Alloc_SCENARIOARRAY(INTI nscen) ;
*
*    general    The routine allocates memory for a SCENARIOLIST struct.
*               Doesn't allocate the individual SCENARIO's. Use
*               Alloc_SCENARIO for this.
*
*    input      INTI       nscen  The number of scenarios.
*
*    output
*
*    returns    SCENARIOARRAY     An allocated SCENARIOARRAY
*
*    diagnostics  aborts calling SCecon_error()
*               with the message   "Allocation failure"
*                        routine   "Alloc_SCENARIOARRAY"
*                        actioncode SCECONABORT
*               if allocation fails.
*
*    see also   Alloc_SCENARIO()
*
*************************************************************************
,,EOH,,*/

SCENARIOARRAY Alloc_SCENARIOARRAY(INTI nscen) 
{
    SCENARIOARRAY ds;
    INTI i;

    nscen = GETMAX(0, nscen);

    ds = (SCENARIOARRAY) SCecon_calloc(nscen, sizeof(SCENARIO), True,
      "Alloc_SCENARIOARRAY()") ;

    for (i = 0; i < nscen; i++)
    {
      ds[i].nbuck = 0;
      ds[i].scen = NULL;
    }

    return ds;
}


/*,,SOH,,
*************************************************************************
*
*               Free_SCENARIOARRAY()
*
*    interface  #include <scenario.h>
*               void Free_SCENARIOARRAY(SCENARIOARRAY ds) ;
*
*    general    The routine frees memory for a SCENARIOARRAY
*               Doesn't allocate pointers in SCENARIO - use
*               Free_SCENARIO.
*
*    input      SCENARIOARRAY   ds    Scenario array.
*
*    output
*
*    returns
*
*    diagnostics
*
*    see also   Free_SCENARIO()
*               Free_SCENARIOLIST()
*
*************************************************************************
,,EOH,,*/

void Free_SCENARIOARRAY(SCENARIOARRAY ds)
{
    SCecon_free(ds) ;
}



/* 
..
*/



/*,,SOH,,
************************************************************************
*
*                Set_FXSHOCKSET()
*
*   interface    #include <scenario.h>
*                FXSHOCKSET Set_FXSHOCKSET(FL64ARRAY shocked,
*                                          INTI      nshock,
*                                          RISKTOKEN token) ;
*
*   general      This routine sets the members of the struct defined
*                in the function name. The pointer members are simply
*                assigned - without physical copying. The intention
*                of the Set_*() routines is that by using this
*                functionality, one avoids setting individual members
*                of structs in the application code.
*
*                When new members are inserted in structs the Set_*()
*                routine will be changed accordingly.
*
*                One exception to this principle applies. Whenever
*                OPTADD and vanilla members are used, only the
*                vanilla members are set in the Set_*() routines. The
*                non-vanilla and exotic members are set to defaults,
*                and must be set elsewhere - if needed.
*
*                For details on the interpretation of the individual
*                struct members please check the struct definition.
*
*   input        FL64ARRAY shocked See general section.
*
*                INTI      nshock  See general section.
*
*                RISKTOKEN token   See general section.
*
*   output
*
*   returns      The filled out FXSHOCKSET struct
*
*   diagnostics
*
*   see also     FXSHOCKSET
*
************************************************************************
,,EOH,,*/

FXSHOCKSET Set_FXSHOCKSET(FL64ARRAY shocked,
    INTI nshock,
    RISKTOKEN token)
{
    FXSHOCKSET fxs;

    fxs.shocked = shocked;
    fxs.nshock = nshock;
    Free_FL64ARRAY(fxs.shocked) ;
    VAR_RiskTokenCpy(&fxs.token, &token) ;

    return fxs;
}


/*,,SOH,,
************************************************************************
*
*                Set_EQTYSHOCKSET()
*
*   interface    #include <scenario.h>
*                EQTYSHOCKSET Set_EQTYSHOCKSET(FL64ARRAY shocked,
*                                              INTI      nshock) ;
*
*   general      This routine sets the members of the struct defined
*                in the function name. The pointer members are simply
*                assigned - without physical copying. The intention
*                of the Set_*() routines is that by using this
*                functionality, one avoids setting individual members
*                of structs in the application code.
*
*                When new members are inserted in structs the Set_*()
*                routine will be changed accordingly.
*
*                One exception to this principle applies. Whenever
*                OPTADD and vanilla members are used, only the
*                vanilla members are set in the Set_*() routines. The
*                non-vanilla and exotic members are set to defaults,
*                and must be set elsewhere - if needed.
*
*                For details on the interpretation of the individual
*                struct members please check the struct definition.
*
*   input        FL64ARRAY shocked See general section.
*
*                INTI      nshock  See general section.
*
*   output
*
*   returns      The filled out EQTYSHOCKSET struct
*
*   diagnostics
*
*   see also     EQTYSHOCKSET
*
************************************************************************
,,EOH,,*/

EQTYSHOCKSET Set_EQTYSHOCKSET(FL64ARRAY shocked,
    INTI nshock)
{
    EQTYSHOCKSET eqtys;

    eqtys.shocked = shocked;
    eqtys.nshock  = nshock;
    Free_FL64ARRAY(eqtys.shocked) ;

    return eqtys;
}



/* *********************************************************** */
/*   CALCULATIONS                                              */
/* *********************************************************** */

/*,,SOH,,
*************************************************************************
*
*               RepoCflw_DF2ScenBPV()
*
*   interface   #include <scenario.h>
*               FL64ARRAY RepoCflw_DF2ScenBPV(DATESTR  *analys,
*                                             DISCFAC    *df,
*                                             FL64       fx_spot,
*                                             CFLW_STR   *xcflw,
*                                             DATESTR    *matur,
*                                             PP_STR     *pp,
*                                             HOLI_STR   *holi,
*                                             DFSPREAD   *dfs,
*                                             DELTASET   *ds,
*                                             FXSHOCKSET *fxs);
*
*   general     The routine calculates the vector of scenario BPV's for
*               a cashflow using a list of predefined shocks to the
*               zero coupon curve and a list of predefined FX shocks.
*               Each zero coupon curve shock corresponds to a single
*               FX shock.
*
*               The scenario BPV represents the price differences
*               invoked by the curve shocks between the shocked PV's
*               and the initial PV.
*
*               It is required that the number of zero coupon curve
*               shocks match the number of FX shocks, ie.
*
*                        fxs->nshock == ds->nshock
*
*               However, fxs may be set to NULL, in which case FX
*               shocking is ignored and the scenario BPV are calculated
*               in instrument ccys only. Otherwise BPV's are in
*               domestic (home ccy)
*
*               Scenarios may be used for evaluation of
*               - Randomly chosen curve/fx shocks,
*               - Historical scenarios/simulation,
*               - Expert scenarios,
*               - Worst case analysis, etc.
*
*   input       DATESTR    *analys      The analysis date.
*
*               DISCFAC    *df          Discounting structure setup.
*                                       The initial (unshocked) curve
*                                       should be in df->disc.
*
*               FL64       fx_spot      FX spot rate.
*                                       The initial (unshocked) rate.
*
*               CFLW_STR  *xcflw        The extracted cashflow from
*                                       the relevant period.
*                                       Must have the format defined
*                                       by bond_extract_period().
*                                       Cashflow is NOT adjusted for
*                                       businessdays.
*                                       The outstanding debt on the
*                                       bond must be 100.
*                                       The first date in the flow is
*                                       the settlement date.
*
*               DATESTR   *matur        The maturity date
*
*               PP_STR    *pp           Partly Paid setup. pp->pp_price
*                                       is not used.
*
*               HOLI_STR   *holi        Business day adjustment setup.
*
*               DFSPREAD   *dfs         Spread against the curve.
*
*               DELTASET   *ds          Curve shock definitions.
*
*               FXSHOCKSET *fxs         FX shock definitions.
*
*   output
*
*   returns     The vector of scenario BPV as:
*
*                         Alloc_FL64ARRAY(ds->nshock) ;
*
*   diagnostics
*
*   see also    Disc_ScenarioPrep()
*               RepoCflw_DF2Price()
*               Cflw_DF2ScenBPV()
*               Bond_DF2ScenBPV()
*
*************************************************************************
,,EOH,,*/

FL64ARRAY RepoCflw_DF2ScenBPV(DATESTR* analys,
                        DISCFAC*    df,
                        FL64       fx_spot,
                        CFLW_STR*   xcflw,
                        DATESTR*    matur,
                        PP_STR*     pp,
                        HOLI_STR*   holi,
                        DFSPREAD*   dfs,
                        DELTASET*   ds,
                        FXSHOCKSET* fxs)
{
    FL64ARRAY dv;
    INTI      size, i;
    FL64      p0, pShock, bpv, dum;

    dv = NULL;

    if (FXSHOCKSET_IsEmpty(fxs))
    {
        dv = RepoCflw_DF2Delta(analys, df, xcflw, matur, pp, holi, 
                               dfs, ds);
    }
    else if (ds->nshock == fxs->nshock)
    {
        size = ds->nshock;

        /* The unshocked price */
        p0 = RepoCflw_DF2Price(analys, df, xcflw, matur, pp, holi, 
                               dfs, NULL, &dum, &dum) ;
        dv = RepoCflw_DF2Delta(analys, df, xcflw, matur, pp, holi, 
                               dfs, ds);
        for(i = 0; i < size; i++)
        {
            pShock = dv[i] + p0;
            bpv = pShock * fxs->shocked[i] - p0 * fx_spot;
            dv[i] = bpv;
        }
    }

    return dv;
}



/*,,SOH,,
*************************************************************************
*
*               Cflw_DF2ScenBPV()
*
*   interface   #include <scenario.h>
*               FL64ARRAY Cflw_DF2ScenBPV(DATESTR  *analys,
*                                         DISCFAC    *df,
*                                         FL64       fx_spot,
*                                         CFLW_STR   *xcflw,
*                                         PP_STR     *pp,
*                                         HOLI_STR   *holi,
*                                         DFSPREAD   *dfs,
*                                         DELTASET   *ds,
*                                         FXSHOCKSET *fxs);
*
*   general     The routine calculates the vector of scenario BPV's for
*               a cashflow using a list of predefined shocks to the
*               zero coupon curve and a list of predefined FX shocks.
*               Each zero coupon curve shock corresponds to a single
*               FX shock.
*
*               The scenario BPV represents the price differences
*               invoked by the curve shocks between the shocked PV's
*               and the initial PV.
*
*               It is required that the number of zero coupon curve
*               shocks match the number of FX shocks, ie.
*
*                        fxs->nshock == ds->nshock
*
*               However, fxs may be set to NULL, in which case FX
*               shocking is ignored and the scenario BPV are calculated
*               in instrument ccys only. Otherwise BPV's are in
*               domestic (home ccy)
*
*               Scenarios may be used for evaluation of
*               - Randomly chosen curve/fx shocks,
*               - Historical scenarios/simulation,
*               - Expert scenarios,
*               - Worst case analysis, etc.
*
*   input       DATESTR    *analys      The analysis date.
*
*               DISCFAC    *df          Discounting structure setup.
*                                       The initial (unshocked) curve
*                                       should be in df->disc.
*
*               FL64       fx_spot      FX spot rate.
*                                       The initial (unshocked) rate.
*
*               CFLW_STR  *xcflw        The extracted cashflow from
*                                       the relevant period.
*                                       Must have the format defined
*                                       by bond_extract_period().
*                                       Cashflow is NOT adjusted for
*                                       businessdays.
*                                       The outstanding debt on the
*                                       bond must be 100.
*
*               PP_STR    *pp           Partly Paid setup. pp->pp_price
*                                       is not used.
*
*               HOLI_STR   *holi        Business day adjustment setup.
*
*               DFSPREAD   *dfs         Spread against the curve.
*
*               DELTASET   *ds          Curve shock definitions.
*
*               FXSHOCKSET *fxs         FX shock definitions.
*
*   output
*
*   returns     The vector of scenario BPV as:
*
*                         Alloc_FL64ARRAY(ds->nshock) ;
*
*   diagnostics
*
*   see also    Disc_ScenarioPrep()
*               RepoCflw_DF2ScenBPV()
*               Bond_DF2ScenBPV()
*
*************************************************************************
,,EOH,,*/

FL64ARRAY Cflw_DF2ScenBPV(DATESTR* analys,
                        DISCFAC*    df,
                        FL64       fx_spot,
                        CFLW_STR*   xcflw,
                        PP_STR*     pp,
                        HOLI_STR*   holi,
                        DFSPREAD*   dfs,
                        DELTASET*   ds,
                        FXSHOCKSET* fxs)
{
    return RepoCflw_DF2ScenBPV(analys, df, fx_spot, xcflw, NULL, pp, 
      holi, dfs, ds, fxs);
}



/*,,SOH,,
*************************************************************************
*
*               Bond_DF2ScenBPV()
*
*   interface   #include <scenario.h>
*               FL64ARRAY Bond_DF2ScenBPV(DATESTR  *analys,
*                                         DISCFAC    *df,
*                                         FL64       fx_spot,
*                                         TRADEINFO  *trade,
*                                         FIXPAY     *fixp,
*                                         HOLI_STR   *holi,
*                                         DFSPREAD   *dfs,
*                                         DELTASET   *ds,
*                                         FXSHOCKSET *fxs);
*
*   general     The routine calculates the vector of scenario BPV's for
*               a bond using a list of predefined shocks to the
*               zero coupon curve and a list of predefined FX shocks.
*               Each zero coupon curve shock corresponds to a single
*               FX shock.
*
*               The scenario BPV represents the price differences
*               invoked by the curve shocks between the shocked PV's
*               and the initial PV.
*
*               It is required that the number of zero coupon curve
*               shocks match the number of FX shocks, ie.
*
*                        fxs->nshock == ds->nshock
*
*               However, fxs may be set to NULL, in which case FX
*               shocking is ignored and the scenario BPV are calculated
*               in instrument ccys only. Otherwise BPV's are in
*               domestic (home ccy)
*
*               Scenarios may be used for evaluation of
*               - Randomly chosen curve/fx shocks,
*               - Historical scenarios/simulation,
*               - Expert scenarios,
*               - Worst case analysis, etc.
*
*   input       DATESTR    *analys      The analysis date.
*
*               DISCFAC    *df          Discounting structure setup.
*                                       The initial (unshocked) curve
*                                       should be in df->disc.
*
*               FL64       fx_spot      FX spot rate.
*                                       The initial (unshocked) rate.
*
*               TRADEINFO *trade        The trade data
*
*               FIXPAY    *fixp         The bond definition
*
*               HOLI_STR   *holi        Business day adjustment setup.
*
*               DFSPREAD   *dfs         Spread against the curve.
*
*               DELTASET   *ds          Curve shock definitions.
*
*               FXSHOCKSET *fxs         FX shock definitions.
*
*   output
*
*   returns     The vector of scenario BPV as:
*
*                         Alloc_FL64ARRAY(ds->nshock) ;
*
*   diagnostics
*
*   see also    Disc_ScenarioPrep()
*               Cflw_DF2ScenBPV()
*               RepoCflw_DF2ScenBPV()
*
*************************************************************************
,,EOH,,*/

FL64ARRAY Bond_DF2ScenBPV(DATESTR* analys,
                        DISCFAC*    df,
                        FL64       fx_spot,
                        TRADEINFO*  trade,
                        FIXPAY*     fixp,
                        HOLI_STR*   holi,
                        DFSPREAD*   dfs,
                        DELTASET*   ds,
                        FXSHOCKSET* fxs)
{
    CFLWARRAY xcflw ;
    HOLI_STR  hol ;
    FL64ARRAY dv ;

    hol   = bond_set_holi(holi, &fixp->fix) ;
    xcflw = Bond_GenrCflw(trade, fixp, &hol) ;

    dv = Cflw_DF2ScenBPV(analys, df, fx_spot, xcflw, &fixp->repay.pp, 
      holi, dfs, ds, fxs);
    Free_CFLWARRAY(xcflw, 1) ;

    return dv ;
}


/*,,SOH,,
*************************************************************************
*
*               Deposit_DF2ScenBPV()
*
*   interface   #include <scenario.h>
*               FL64ARRAY Deposit_DF2ScenBPV(DATESTR  *analys,
*                                         DISCFAC    *df,
*                                         FL64       fx_spot,
*                                         DEPOSIT    *depo,
*                                         HOLI_STR   *holi,
*                                         DFSPREAD   *dfs,
*                                         DELTASET   *ds,
*                                         FXSHOCKSET *fxs);
*
*
*   general     The routine calculates the vector of scenario BPV's for
*               a deposit using a list of predefined shocks to the
*               zero coupon curve and a list of predefined FX shocks.
*               Each zero coupon curve shock corresponds to a single
*               FX shock.
*
*               The scenario BPV represents the price differences
*               invoked by the curve shocks between the shocked PV's
*               and the initial PV.
*
*               It is required that the number of zero coupon curve
*               shocks match the number of FX shocks, ie.
*
*                        fxs->nshock == ds->nshock
*
*               However, fxs may be set to NULL, in which case FX
*               shocking is ignored and the scenario BPV are calculated
*               in instrument ccys only. Otherwise BPV's are in
*               domestic (home ccy)
*
*               Scenarios may be used for evaluation of
*               - Randomly chosen curve/fx shocks,
*               - Historical scenarios/simulation,
*               - Expert scenarios,
*               - Worst case analysis, etc.
*
*   input       DATESTR    *analys      The analysis date.
*
*               DISCFAC    *df          Discounting structure setup.
*                                       The initial (unshocked) curve
*                                       should be in df->disc.
*
*               FL64       fx_spot      FX spot rate.
*                                       The initial (unshocked) rate.
*
*               DEPOSIT   *depo         The deposit definition
*
*               HOLI_STR   *holi        Business day adjustment setup.
*
*               DFSPREAD   *dfs         Spread against the curve.
*
*               DELTASET   *ds          Curve shock definitions.
*
*               FXSHOCKSET *fxs         FX shock definitions.
*
*   output
*
*   returns     The vector of scenario BPV as:
*
*                         Alloc_FL64ARRAY(ds->nshock) ;
*
*   diagnostics
*
*   see also    Disc_ScenarioPrep()
*               Cflw_DF2ScenBPV()
*               Bond_DF2ScenBPV()
*
*************************************************************************
,,EOH,,*/


FL64ARRAY Deposit_DF2ScenBPV(DATESTR* analys,
                        DISCFAC*    df,
                        FL64       fx_spot,
                        DEPOSIT*    depo,
                        HOLI_STR*   holi,
                        DFSPREAD*   dfs,
                        DELTASET*   ds,
                        FXSHOCKSET* fxs)
{
    CFLWARRAY cflw ;
    FL64ARRAY dv ;
    FIXPAY    fixp ;

    /* Translate deposit into fixpay */
    fixp = Deposit_DEPOSIT2FIXPAY(depo, holi) ;

    /* Compute cash flow + Delta Vector */
    cflw = Cflw_GenrCflw(&fixp.repay, &fixp.rday, 
                          &fixp.fix, &fixp.cday, holi) ;
    dv   = Cflw_DF2ScenBPV(analys, df, fx_spot, cflw, &fixp.repay.pp, 
      holi, dfs, ds, fxs) ;

    /* Free */
    Free_CFLWARRAY(cflw, 1) ;

    return dv ;
}






/*,,SOH,,
*************************************************************************
*
*               IndexLoan_DF2ScenBPV()
*
*   interface   #include <scenario.h>
*               FL64ARRAY IndexLoan_DF2ScenBPV(DATESTR    *analys,
*                                              DISCFAC    *df,
*                                              FL64       fx_spot,
*                                              INDEXLOAN  *idxloan,
*                                              INDEXFAC   *debfac,
*                                              INDEXFAC   *crefac,
*                                              HOLI_STR   *holi,
*                                              DFSPREAD   *dfs,
*                                              BOOLE      indexadj,
*                                              DELTASET   *ds,
*                                              FXSHOCKSET *fxs);
*
*   general     The routine calculates the vector of scenario BPV's for
*               a index loan using a list of predefined shocks to the
*               zero coupon curve and a list of predefined FX shocks.
*               Each zero coupon curve shock corresponds to a single
*               FX shock.
*
*               The scenario BPV represents the price differences
*               invoked by the curve shocks between the shocked PV's
*               and the initial PV.
*
*               It is required that the number of zero coupon curve
*               shocks match the number of FX shocks, ie.
*
*                        fxs->nshock == ds->nshock
*
*               However, fxs may be set to NULL, in which case FX
*               shocking is ignored and fx_spot is used for all PV
*               calculations.
*
*               Scenarios may be used for evaluation of
*               - Randomly chosen curve/fx shocks,
*               - Historical scenarios/simulation,
*               - Expert scenarios,
*               - Worst case analysis, etc.
*
*   input       DATESTR    *analys      The analysis date.
*
*               DISCFAC    *df          Discounting structure setup.
*                                       The initial (unshocked) curve
*                                       should be in df->disc.
*
*               FL64       fx_spot      FX spot rate.
*                                       The initial (unshocked) rate.
*
*               INDEXLOAN  *idxloan     The index loan definition
*
*               INDEXFAC   *debfac      Debtor index factors
*
*               INDEXFAC   *crefac      Creditor index factors
*
*               HOLI_STR   *holi        Business day adjustment setup.
*
*               DFSPREAD   *dfs         Spread against the curve.
*
*               BOOLE     indexadj      False means that the scenario
*                                       BPV's are not adjusted for
*                                       index factors. True means that
*                                       scenario BPV's times the
*                                       relevant index factor is
*                                       returned.
*
*               DELTASET   *ds          Curve shock definitions.
*
*               FXSHOCKSET *fxs         FX shock definitions.
*
*   output
*
*   returns     The vector of scenario BPV as:
*
*                         Alloc_FL64ARRAY(ds->nshock) ;
*
*   diagnostics
*
*   see also    Disc_ScenarioPrep()
*
*************************************************************************
,,EOH,,*/

FL64ARRAY IndexLoan_DF2ScenBPV(DATESTR*     analys,
                                   DISCFAC*     df,
                                   FL64         fx_spot,
                                   INDEXLOAN*   idxloan, 
                                   INDEXFAC*    debfac,
                                   INDEXFAC*    crefac,
                                   HOLI_STR*    holi,
                                   DFSPREAD*    dfs,
                                   BOOLE        indexadj,
                                   DELTASET*    ds,
                                   FXSHOCKSET*  fxs)
{
    CFLWARRAY xcflw ;
    FL64ARRAY dv ;
    FL64      fac ;
    INTI      i ;

    /* Generate CFLW */
    xcflw = IndexLoan_GenrCflw(analys, idxloan, debfac, crefac, holi) ;

    /* Calculate */
    dv = Cflw_DF2ScenBPV(analys, df, fx_spot, xcflw, NULL, holi, dfs, 
                         ds, fxs) ;

    /* Index adjusted price? */
    if (indexadj == False)
    {
        fac = Index_Interpolation(analys, &idxloan->delay, crefac) ;

        /* idxfac is always positive !! */
        for (i = 0; i < ds->nshock; i++)
             dv[i] /= fac ;
    }

    /* Free */
    Free_CFLWARRAY(xcflw, 1) ;

    return dv ;
}



/*,,SOH,,
*************************************************************************
*
*               IndexBond_DF2ScenBPV()
*
*   interface   #include <scenario.h>
*               FL64ARRAY IndexBond_DF2ScenBPV(DATESTR    *analys,
*                                              DISCFAC    *df,
*                                              FL64       fx_spot,
*                                              TRADEINFO  *trade,
*                                              INDEXBOND  *idxbond,
*                                              INDEXFAC   *idxfac,
*                                              HOLI_STR   *holi,
*                                              DFSPREAD   *dfs,
*                                              BOOLE      indexadj,
*                                              DELTASET   *ds,
*                                              FXSHOCKSET *fxs);
*
*   general     The routine calculates the vector of scenario BPV's for
*               a index bond using a list of predefined shocks to the
*               zero coupon curve and a list of predefined FX shocks.
*               Each zero coupon curve shock corresponds to a single
*               FX shock.
*
*               The scenario BPV represents the price differences
*               invoked by the curve shocks between the shocked PV's
*               and the initial PV.
*
*               It is required that the number of zero coupon curve
*               shocks match the number of FX shocks, ie.
*
*                        fxs->nshock == ds->nshock
*
*               However, fxs may be set to NULL, in which case FX
*               shocking is ignored and fx_spot is used for all PV
*               calculations.
*
*               Scenarios may be used for evaluation of
*               - Randomly chosen curve/fx shocks,
*               - Historical scenarios/simulation,
*               - Expert scenarios,
*               - Worst case analysis, etc.
*
*   input       DATESTR    *analys      The analysis date.
*
*               DISCFAC    *df          Discounting structure setup.
*                                       The initial (unshocked) curve
*                                       should be in df->disc.
*
*               FL64       fx_spot      FX spot rate.
*                                       The initial (unshocked) rate.
*
*               TRADEINFO  *trade       The trade data
*
*               INDEXBOND  *idxbond     The index bond definition
*
*               INDEXFAC   *idxfac      Index factors
*
*               HOLI_STR   *holi        Business day adjustment setup.
*
*               DFSPREAD   *dfs         Spread against the curve.
*
*               BOOLE     indexadj      False means that the scenario
*                                       BPV's are not adjusted for
*                                       index factors. True means that
*                                       scenario BPV's times the
*                                       relevant index factor is
*                                       returned.
*
*               DELTASET   *ds          Curve shock definitions.
*
*               FXSHOCKSET *fxs         FX shock definitions.
*
*   output
*
*   returns     The vector of scenario BPV as:
*
*                         Alloc_FL64ARRAY(ds->nshock) ;
*
*   diagnostics
*
*   see also    Disc_ScenarioPrep()
*
*************************************************************************
,,EOH,,*/

FL64ARRAY IndexBond_DF2ScenBPV(DATESTR*     analys,
                                   DISCFAC*     df,
                                   FL64         fx_spot,
                                   TRADEINFO*   trade,
                                   INDEXBOND*   idxbond, 
                                   INDEXFAC*    idxfac,
                                   HOLI_STR*    holi,
                                   DFSPREAD*    dfs,
                                   BOOLE        indexadj,
                                   DELTASET*    ds,
                                   FXSHOCKSET*  fxs)
{
    CFLWARRAY xcflw ;
    FL64ARRAY dv ;
    FL64      fac;
    INTI      i ;


    /* Generate cashflow */
    xcflw = IndexBond_GenrCflw(trade, idxbond, idxfac, holi) ;
    
    /* Calculate */
    dv = Cflw_DF2ScenBPV(analys, df, fx_spot, xcflw, NULL, holi, dfs, 
                         ds, fxs) ;

    /* Index adjusted price? */
    if (indexadj == False)
    {
        fac = Index_Interpolation(analys, &idxbond->pv_delay, idxfac) ;

        /* idxfac is always positive !! */
        for (i = 0; i < ds->nshock; i++)
             dv[i] /= fac ;
    }

    /* Free */
    Free_CFLWARRAY(xcflw, 1) ;

    return dv ;
}





/*
..
*/


BOOLE FXSHOCKSET_IsEmpty(FXSHOCKSET*  fxs)
{
    if (fxs == NULL)
        return True;
    else if (fxs->shocked == NULL || fxs->nshock == 0)
        return True;
    else
        return False;
}

/*
..
*/

BOOLE EQTYSHOCKSET_IsEmpty(EQTYSHOCKSET*  eqtys)
{
    if (eqtys == NULL)
        return True;
    else if (eqtys->shocked == NULL || eqtys->nshock == 0)
        return True;
    else
        return False;
}



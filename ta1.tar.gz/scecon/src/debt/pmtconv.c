/* SCID @(#)pmtconv.c	1.3 (SimCorp) 99/02/19 14:12:15 */

/************************************************************************
*
*   project     SCecon
*
*   filename    pmtconv.c
*
*   general     This file contains standard cash flow routines of
*               SCecon Library
*
************************************************************************/

/* includes ************************************************************/
#include <cflw.h>

/* defines  ************************************************************/
#define DAY_TOL    0.001
#define SCHUGE_VAL 100000.0


/*
*************************************************************************
*
*               Cflw_FL64ARRAY2PMTARRAY()
*
*   interface   #include <cflw.h>
*               void Cflw_FL64ARRAY2PMTARRAY(INTI      count,
*                                            FL64ARRAY rates,
*                                            FL64ARRAY amort,
*                                            FL64ARRAY terms,
*                                            PMTARRAY  pmtstr) ;
*
*   general     The function takes the terms, coupons and amortizations
*               and fills them in the PMTARRAY.
*
*   input       INTI     count      The number of elements in pdays
*                                   and amort.
*
*               FL64ARRAY  rates    The coupon payments, allocated
*                                   with count entries by the routine
*                                   Alloc_FL64ARRAY().
*
*               FL64ARRAY  amort    The principal payments, allocated
*                                   with count entries by the routine
*                                   Alloc_FL64ARRAY().
*
*               FL64ARRAY  terms    The terms for the payments in rates
*                                   and amort, allocated with count
*                                   entries using the routine
*                                   Alloc_FL64ARRAY().
*
*   output      PMTARRAY  pmtstr    The struct in which the above
*                                   arguments are to be put. Allocated
*                                   with sufficient memory assigned,
*                                   using Alloc_PMTARRAY().
*
*   returns
*
*   diagnostics
*
*   see also    Cflw_PMTARRAY2FL64ARRAY()
*
*************************************************************************
*/

void Cflw_FL64ARRAY2PMTARRAY(INTI  count,
                        FL64ARRAY rates1,
                        FL64ARRAY amort1,
                        FL64ARRAY terms1,
                        PMTARRAY pmtstr)
{
    INTI    i ;
    FL64    *terms, *rates, *amort, *t1, *p1 ;
    PMT_STR *pmt ;

    pmt   = pmtstr ;
    pmt->count = count ;
    t1    = pmt->term ;
    p1    = pmt->payment ;

    terms = terms1 ;
    rates = rates1 ;
    amort = amort1 ;

    for (i = 0 ; i < count ; i++)
    {
        t1[i] = terms[i] ;
        p1[i] = rates[i] + amort[i] ;
    }
}


/*,,SOH,,
*************************************************************************
*
*               Cflw_Cflw2Pmt()
*
*   interface   #include <cflw.h>
*               PMTARRAY Cflw_Cflw2Pmt(DATESTR  *start,
*                                      CFLW_STR *cflw,
*                                      CALCONV  cal) ;
*
*   general     The function takes the terms, coupons and amortizations
*               and fills them in the PMTARRAY.
*
*               The terms in the PMTARRAY are calculated using cal, and
*               the payment entries are the sum of coupons and repay-
*               ments in cflw.
*
*   input       DATESTR    *start   The valuation day
*
*               CFLW_STR   *cflw    The cashflow to be transformed into
*                                   a PMTARRAY
*
*               CALCONV    cal      Calendar convention
*
*   output
*
*   returns     Pointer to the PMTARRAY allocated in this routine as:
*               Alloc_PMTARRAY(1, cflw->filled)
*
*   diagnostics
*
*   see also    Cflw_ExtractPeriod()
*               TVM_Zero2Price()
*               TVM_Yield2Price()
*               TVM_Price2Yield()
*
*************************************************************************
,,EOH,,*/

PMTARRAY Cflw_Cflw2Pmt(DATESTR* start,
                       CFLW_STR* cflw,
                       CALCONV  cal)
{
	/* PMSTA-22396 - SRIDHARA � 160502 */
	HOLI_STR holi;
	holi = Set_HOLI_STR(NO_BUSADJUST, 0, NULL);

    INTI      i ;
    PMTARRAY  pmt ;

    pmt = Alloc_PMTARRAY(1, cflw->filled) ;
    pmt->count = cflw->filled ;

    for (i = 0; i < cflw->filled ; i++)
    {
        pmt->term[i]    = Cldr_TermBetweenDates(start, &cflw->days[i],
                                                0, cal, LAST, &holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
        pmt->payment[i] = cflw->coupon[i] + cflw->repay[i] ;
    }

    return pmt ;
}


/*
*************************************************************************
*
*               Cflw_Cflw2Pmt_Scan()
*
*   interface   #include <cflw.h>
*               PMTARRAY Cflw_Cflw2Pmt_Scan(DATESTR   *start,
*                                           CFLW_STR  *cflw,
*                                           CALCONV   cal_per1,
*                                           CALCONV   cal_per2,
*                                           INTI      norig,
*                                           DATEARRAY origdays) ;
*
*   general     The function takes the terms, coupons and amortizations
*               and fills them in the PMTARRAY.
*
*               The terms in the PMTARRAY are calculated using cal_per1
*               and cal_per2 (as described in Cldr_ComputeTerms(), and
*               the payment entries are the sum of coupons and repay-
*               ments in cflw.
*
*   input       DATESTR    *start   The valuation day
*
*               CFLW_STR   *cflw    The cashflow to be transformed into
*                                   a PMTARRAY
*
*               CALCONV    cal_per1 Calendar convention first period
*
*               CALCONV    cal_per2 Calendar convention whole periods
*
*               INTI       norig    Number of elements in origdays.
*
*               DATEARRAY  origdays Array of payment days with norig
*                                   entries.
*
*   output
*
*   returns     Pointer to the PMTARRAY allocated in this routine as:
*               Alloc_PMTARRAY(1, cflw->filled)
*
*   diagnostics
*
*   see also
*
*************************************************************************
*/

PMTARRAY Cflw_Cflw2Pmt_Scan(DATESTR* start,
                            CFLW_STR*  cflw,
                            CALCONV   cal_per1,
                            CALCONV   cal_per2,
                            INTI      norig,
                            DATEARRAY origdays)
{
	/* PMSTA-22396 - SRIDHARA � 160502 */
	HOLI_STR holi;
	holi = Set_HOLI_STR(NO_BUSADJUST, 0, NULL);

    INTI      i ;
    PMTARRAY  pmt ;
    FL64ARRAY terms ;

    pmt = Alloc_PMTARRAY(1, cflw->filled) ;
    pmt->count = cflw->filled ;

    terms = Cldr_ComputeTerms(start, cflw->filled, cflw->days,
                               norig, origdays, 0, cal_per1, cal_per2, LAST, &holi) ; 	/* PMSTA-22396 - SRIDHARA � 160502 */

    for (i = 0; i < cflw->filled ; i++)
    {
        pmt->term[i]    = terms[i] ;
        pmt->payment[i] = cflw->coupon[i] + cflw->repay[i] ;
    }

    Free_FL64ARRAY(terms) ;

    return pmt ;
}


/*
*************************************************************************
*
*               Cflw_PMTARRAY2FL64ARRAY()
*
*   interface   #include <cflw.h>
*               INTI Cflw_PMTARRAY2FL64ARRAY(FL64ARRAY pmt,
*                                            FL64ARRAY terms,
*                                            PMTARRAY  pmtstr) ;
*
*   general     The function fills the pmt/terms arrays with data from
*               the PMTARRAY pmtstr.
*
*   input       PMTARRAY  pmtstr    The struct from which the data
*                                   are to be taken, and put into
*                                   pmt and terms. Allocated with
*                                   sufficient memory assigned
*                                   by Alloc_PMTARRAY().
*
*   output      FL64ARRAY  pmt      The total payments. Allocated as
*                                   an array so that enough memory is
*                                   available by Alloc_FL64ARRAY().
*
*               FL64ARRAY  terms    The terms for the payments in pmt.
*                                   Allocated as an array such that
*                                   enough memory is available with
*                                   Alloc_FL64ARRAY().
*
*   returns     the number of elements that are filled in pmt/terms.
*
*   diagnostics
*
*   see also    Cflw_FL64ARRAY2PMTARRAY()
*
*************************************************************************
*/


INTI  Cflw_PMTARRAY2FL64ARRAY(FL64ARRAY pmt1,
                         FL64ARRAY terms1,
                         PMTARRAY pmtstr)
{
    INTI    count, i ;
    FL64    *terms, *pmt, *t1, *p1 ;
    PMT_STR *p ;

    p     = pmtstr ;
    count = p->count ;
    t1    = p->term ;
    p1    = p->payment ;

    terms = terms1 ;
    pmt   = pmt1 ;

    for (i = 0 ; i < count ; i++)
    {
        terms[i] = t1[i] ;
        pmt[i]   = p1[i] ;
    }

    return count ;
}


/*,,SOH,,
*************************************************************************
*
*               Cflw_MergePMTARRAY()
*
*   interface   #include <cflw.h>
*               PMTARRAY Cflw_MergePMTARRAY(PMTARRAY  pmts1,
*                                            INTIARRAY indices1,
*                                            FL64ARRAY weight1,
*                                            INTI      n) ;
*
*   general     The function merges n PMT_STR's into one aggregate
*               PMTARRAY.
*               The struct that holds the basic cashflows is pmts.
*
*               The n basic cashflows to be merged are identified
*               by the index array, indices. This array holds the
*               indices in pmts for the n basic cashflows. The array
*               weights holds the factors that are used to weight
*               the individual cashflows.
*
*               A PMT_STR does not contain information about nominal
*               outstanding - therefore the merged cashflow is NOT
*               scaled. Instead the choice of weights reflects
*               the character of the aggregate cashflow.
*
*   input       PMTARRAY  pmts1   The basis cashflows - with at least
*                                 n individual cashflows. This can
*                                 be performed with the routine
*                                 Alloc_PMTARRAY(n, maxpmt) where
*                                 maxpmt is userdefined.
*                                 The basic cashflows must be sorted
*                                 in ascending order.
*
*               INTIARRAY indices1 Indices in pmts for the individual
*                                 cash flows to be merged.
*
*               FL64ARRAY weight1 The individual weights on the basic
*                                 cashflows.
*
*               INTI      n       The number of basic cashflows to
*                                 be merged.
*
*   output
*
*   returns     Pointer to the PMT_STR holding the merged flow.
*               Allocated in this routine as: Alloc_PMTARRAY(1, count)
*               where count is total numbner of payments.
*
*   diagnostics
*
*   see also
*
*************************************************************************
,,EOH,,*/


PMTARRAY Cflw_MergePMTARRAY(PMTARRAY pmts1, INTIARRAY indices1,
  FL64ARRAY weight1, INTI n)
{
    INTIARRAY cflcount1, finished1 ;
    INTI      count, i, j, *cflcount, *finished, nfinish, active, itmp ;
    FL64      pmt, time, day_tol_cash ;
    INTI      *indices ;
    FL64      *tpmts, *ppmts, *tres, *pres, *weight ;
    PMT_STR   *pmts ;
    PMTARRAY  res ;

    /* Allocate working memory */
    cflcount1 = Alloc_INTIARRAY(n) ;
    finished1 = Alloc_INTIARRAY(n) ;

    cflcount = cflcount1 ;
    finished = finished1 ;
    indices  = indices1 ;
    weight   = weight1 ;
    pmts     = pmts1 ;

    for (count = i = 0; i < n ; i++)
        count += pmts[indices[i]].count ;

    res  = Alloc_PMTARRAY(1, count) ;
    tres = res->term ;
    pres = res->payment ;

    day_tol_cash = DAY_TOL/4.0 ;
    nfinish      = 0 ;
    time         = (FL64) SCHUGE_VAL ;

    for (i = 0 ; i < n ; i++)
    {
        cflcount[i] = 0 ;

        /* Check if there is any payments in the i'th cashflow */
        if (!pmts[indices[i]].count)
        {
            finished[i] = 1 ;
            nfinish++ ;
        }
    }

    /* Start looping around cashflows to merge into aggregate cashflow */
    i = 0 ;
    while (nfinish < n)
    {
        pmt = 0.0 ;
        time = (FL64) SCHUGE_VAL ;

        /* Find shortest time in cashflows */
        for (j = 0 ; j < n ; j++)
        {
            if (finished[j])
                continue ;
            tpmts = pmts[indices[j]].term ;
            time  = GETMIN(time, tpmts[cflcount[j]]) ;
        }

        /* Find securities with payments at that term */
        for (j = 0 ; j < n ; j++)
        {
            if (finished[j])
                continue ;

            active = cflcount[j] ;
            itmp   = indices[j] ;

            tpmts = pmts[itmp].term ;
            ppmts = pmts[itmp].payment ;

            if (fabs(time - tpmts[active]) <= day_tol_cash)
            {
                pmt += ppmts[active] * weight[j] ;
                cflcount[j]++ ;

                /* keep track of finished securities */
                if (cflcount[j] >= pmts[itmp].count)
                {
                    finished[j] = 1 ;
                    nfinish++ ;
                }
            }
        }

        /* update PMT_STR */
        if (fabs(pmt) > PMT_TOL)
        {
            tres[i] = time ;
            pres[i] = pmt ;
            i++ ;
        }
    }
    /* Done, now set number of payments */
    res->count = i ;

    Free_INTIARRAY(cflcount1) ;
    Free_INTIARRAY(finished1) ;

    return res ;
}


/*,,SOH,,
*************************************************************************
*
*               Cflw_MergePLANARRAY()
*
*   interface   #include <cflw.h>
*               PLANARRAY Cflw_MergePLANARRAY(PLANARRAY pmts1,
*                                              INTIARRAY indices1,
*                                              FL64ARRAY weight1,
*                                              INTI      n) ;
*
*   general     The function merges n PLAN_STR's into one aggregate
*               PLANARRAY.
*               The struct that holds the basic cashflows is pmts.
*
*               The n basic cashflows to be merged are identified
*               by the index array, indices. This array holds the
*               indices in pmts for the n basic cashflows. The array
*               weights holds the factors that are used to weight
*               the individual cashflows.
*
*               A PLAN_STR does not contain information about nominal
*               outstanding - therefore the merged cashflow is NOT
*               scaled. Instead the choice of weights reflects
*               the character of the aggregate cashflow.
*
*   input       PLANARRAY  pmts1  The basis cashflows - with at least
*                                 n individual cashflows. This can
*                                 be performed with the routine
*                                 Alloc_PLANARRAY(n, maxpmt) where
*                                 maxpmt is userdefined.
*                                 The basic cashflows must be sorted
*                                 in ascending order.
*                                 pmts[i].count and filled must have
*                                 been assigned before calling.
*
*               INTIARRAY indices1 Indices in pmts for the individual
*                                 cash flows to be merged.
*
*               FL64ARRAY weight1 The individual weights on the basic
*                                 cashflows.
*
*               INTI      n       The number of basic cashflows to
*                                 be merged.
*
*   output
*
*   returns     Pointer to the PLANARRAY holding the merged flow.
*               Allocated in this routine as: Alloc_PLANARRAY(1, count)
*               where count is total number of payments.
*
*   diagnostics
*
*   see also
*
*************************************************************************
,,EOH,,*/


PLANARRAY Cflw_MergePLANARRAY(PLANARRAY pmts1, INTIARRAY indices1,
  FL64ARRAY weight1, INTI n)
{
    INTIARRAY cflcount1, finished1 ;
    INTI      count, i, j, *cflcount, *finished, nfinish, active, itmp ;
    FL64      pmt ;
    INTI      *indices ;
    FL64      *ppmts, *pres, *weight ;
    DATESTR   *dres, *dpmts, time ;
    PLAN_STR  *pmts, *look ;
    PLANARRAY res ;

    /* Allocate working memory */
    cflcount1 = Alloc_INTIARRAY(n) ;
    finished1 = Alloc_INTIARRAY(n) ;

    cflcount = cflcount1 ;
    finished = finished1 ;
    indices  = indices1 ;
    weight   = weight1 ;
    pmts     = pmts1 ;

    for (count = i = 0; i < n; i++)
    {
        look   = &pmts[indices[i]] ;
        count += GetPlanFill(look) ;
    }

    res  = Alloc_PLANARRAY(1, count)  ;
    dres = res->day ;
    pres = res->f64 ;

    nfinish = 0 ;
    time    = Cldr_YMD2Datestr((YYYYMMDD) 99999999) ;

    for (i = 0 ; i < n ; i++)
    {
        cflcount[i] = 0 ;

        /* Check if there is any payments in the i'th cashflow */
        look = &pmts[indices[i]] ;
        if (GetPlanFill(look) == 0)
        {
            finished[i] = 1 ;
            nfinish++ ;
        }
    }

    /* Start looping around cashflows to merge into aggregate cashflow */
    i = 0 ;
    while (nfinish < n)
    {
        pmt  = 0.0 ;
        time = Cldr_YMD2Datestr((YYYYMMDD) 99999999) ;

        /* Find shortest time in cashflows */
        for (j = 0 ; j < n ; j++)
        {
            if (finished[j])
                continue ;

            dpmts = pmts[indices[j]].day ;
            if (Cldr_DateLT(&dpmts[cflcount[j]], &time) == True)
                time = dpmts[cflcount[j]] ;
        }

        /* Find securities with payments at that day */
        for (j = 0 ; j < n ; j++)
        {
            if (finished[j])
                continue ;

            active = cflcount[j] ;
            itmp   = indices[j] ;

            dpmts = pmts[itmp].day ;
            ppmts = pmts[itmp].f64 ;

            if (Cldr_DateEQ(&time, &dpmts[active]) == True)
            {
                pmt += ppmts[active] * weight[j] ;
                cflcount[j]++ ;

                /* keep track of finished securities */
                if (cflcount[j] >= pmts[itmp].filled)
                {
                    finished[j] = 1 ;
                    nfinish++ ;
                }
            }
        }

        /* update PLAN_STR */
        if (fabs(pmt) > PMT_TOL)
        {
            dres[i] = time ;
            pres[i] = pmt ;
            i++ ;
        }
    }
    /* Done, now set number of payments */
    res->filled = i ;

    Free_INTIARRAY(cflcount1) ;
    Free_INTIARRAY(finished1) ;

    return res ;
}


/*,,SOH,,
*************************************************************************
*
*               Cflw_ProjectPLANARRAY()
*
*   interface   #include <cflw.h>
*               PLANARRAY Cflw_ProjectPLANARRAY(PLAN_STR  *in,
*                                                DATEARRAY dates,
*                                                INTI      n,
*                                                CALCONV   cal,
*                                                FL64      rate) ;
*
*   general     The function projects a PLAN_STR onto a specified set of*
*               dates.
*
*               In doing so the payments are discounted forward till
*               grid date using the discounting rate.
*
*               NB:
*               All paydates after the last grid date will be ignored.
*
*   input       PLAN_STR  *in     The basis cashflow.
*                                 in->count and filled must have
*                                 been assigned before calling.
*
*               DATEARRAY dates   The grid dates
*
*               INTI      n       The number elements in dates
*
*               CALCONV   cal     Calendar convention
*
*               FL64      rate    The discounting rate. Annually compo-
*                                 unded rate in %.
*
*	       	    HOLI_STR   *hol	  Container for list of holidays.
*
*   output
*
*   returns     Pointer to the PLAN_STR holding the projected flow.
*               Allocated in this routine as: Alloc_PLANARRAY(1, n)
*
*
*   diagnostics
*
*   see also
*
*************************************************************************
,,EOH,,*/

PLANARRAY Cflw_ProjectPLANARRAY(PLAN_STR* in,
                                 DATEARRAY dates,
                                 INTI      n,
                                 CALCONV   cal,
                                 FL64      rate,
								 HOLI_STR* holi)
{
    INTI      j, i ;
    DATESTR   date, *pinday , *poutday ;
    FL64      *pinf64, *poutf64, term ;
    PLANARRAY out ;

    out = Alloc_PLANARRAY(1, n) ;

    pinf64  = in->f64 ;
    poutf64 = out->f64 ;
    pinday  = in->day ;
    poutday = out->day ;

    out->filled = 0 ;

    /* Loop around grid dates */
    for (j = i = 0 ; i < n; i++)
    {
        date       = dates[i] ;
        poutday[i] = date ;
        poutf64[i] = 0.0 ;
        out->filled++ ;

        while (j < in->filled && Cldr_DateLE(&pinday[j], &date) == True)
        {
			term = Cldr_TermBetweenDates(&pinday[j], &date, 0, cal, LAST, holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */
            poutf64[i] += pinf64[j] / TVMunit_NPV(term, rate, COMPOUND, 1) ;
            j++ ;
        }
    }

    return out ;
}


#undef DAY_TOL
#undef SCHUGE_VAL

/* SCID @(#)bondseg.c	1.5 (SimCorp) 99/09/14 18:14:00 */

/************************************************************************
*
*       Project         SCecon
*
*       file name       bondseg.c
*
*       contains        Government Benchmark Bond Calculations
*
************************************************************************/


/*** includes **********************************************************/
#include <bond.h>


/*,,SOH,,
*************************************************************************
*
*               BondBM_YTMSEG2YTMCONV()
*
*   interface   #include <bond.h>
*               YTMCONV BondBM_YTMSEG2YTMCONV(YTMSEG yseg) ;
*
*   general     The function translates a yield segment into the
*               standard YTMCONV format - i.e by defaulting the various
*               elements of the YTMCONV.
*
*               Note that we do not assume any responsibility for chan-
*               ges in the settings of the various yield conventions.
*               We refer to "Government Bond Outlines", 11th edition,
*               July 1998, J.P.Morgan and information gathered from Reuters
*               as of Summer 1999.
*
*               For our current understanding of the various conventions
*               check out the documentation of YTMSEG.
*
*   input       YTMSEG    yseg          The YTM segment
*
*   output
*
*   returns     The YTMCONV appropriately set
*
*   diagnostics
*
*   see also
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/

YTMCONV BondBM_YTMSEG2YTMCONV(YTMSEG yseg)
{
    YTMCONV ytmc ;

    /* warning avoidance */
    memset(&ytmc, 0, sizeof(ytmc));

    switch (yseg)
    {
        /* 30/360 related */
        case ISMA360ANN:
            ytmc = Set_YTMCONV(COMPOUND, ANNUALLY, 
                               True, True, True,
                               EU30E360, EU30E360, EU30E360, False, False) ;
            break ;

        case ISMA360SEMI:
            ytmc = Set_YTMCONV(COMPOUND, SEMIANNUALLY, 
                               True, True, True,
                               EU30E360, EU30E360, EU30E360, False, False) ;
            break ;

        /* ACTACT related */
        case USDGOVEQV:
        case AUDGOVEQV:
        case DEMGOVEQV:
        case NZDGOVEQV:
            ytmc = Set_YTMCONV(COMPOUND, SEMIANNUALLY, 
                               False, False, False,
                               ACTACT, ACTACT, ACTACT, False, False) ;
            break ;

        case FRFGOVEQV:
            ytmc = Set_YTMCONV(COMPOUND, ANNUALLY, 
                               True, False, True,
                               ACTACT, ACTACT, ACTACT, False, False) ;
            break ;

        case USTEQV:
            ytmc = Set_YTMCONV(US_TREASURY, SEMIANNUALLY, 
                               False, False, False,
                               ACTACT, ACTACT, ACTACT, False, False) ;
            break ;

        case IEPGOVEQV:
        case UKCONSORTIUM:
        case ITLGOVEQV:    
          ytmc = Set_YTMCONV(COMPOUND, SEMIANNUALLY, 
                               True, False, True,
                               ACTACT, ACTACT, ACTACT, False, False) ;
            break ;

        case ESPGOVEQV:
            ytmc = Set_YTMCONV(COMPOUND, ANNUALLY, 
                               True, True, True,
                               ACTACT, ACTACT, ACTACT, False, False) ;
            break ;

        case ITLGOVEQVTRUE:  
            ytmc = Set_YTMCONV(COMPOUND, ANNUALLY, 
                               True, True, True,
                               ACTACT, ACTACT, ACTACT, True, False) ;
            break ;

        case UKBUMPDATES:
            /* Also GRY + Consortium Yield */
            ytmc = Set_YTMCONV(COMPOUND, SEMIANNUALLY, 
                               True, True, True,
                               ACTACT, ACTACT, ACTACT, True, False) ;
            break ;


        /* ACT365 related */
        case NOKGOVEQV:
            ytmc = Set_YTMCONV(COMPOUND, ANNUALLY, 
                               True, False, True,
                               ACT365, ACT365, ACT365, False, False) ;
            break ;

        case BANKOFCANADA:
            ytmc = Set_YTMCONV(COMPOUND, SEMIANNUALLY, 
                               False, False, False,
                               ACT365, ACT365, ACT365, False, False) ;
            break ;


        case OLDITLGOVEQV:    
          ytmc = Set_YTMCONV(COMPOUND, ANNUALLY, 
                               True, False, True,
                               ACT365, ACT365, ACT365, False, False) ;
            break ;

        case OLDITLGOVEQVTRUE:  
            ytmc = Set_YTMCONV(COMPOUND, ANNUALLY, 
                               True, True, True,
                               ACT365, ACT365, ACT365, True, False) ;
            break ;

        case OLDESPGOVEQV:
            ytmc = Set_YTMCONV(COMPOUND, ANNUALLY, 
                               True, True, True,
                               ACT365, ACT365, ACT365, False, False) ;
            break ;

        case OLDUKBUMPDATES:
            /* Also GRY + Consortium Yield */
            ytmc = Set_YTMCONV(COMPOUND, SEMIANNUALLY, 
                               True, True, True,
                               ACT365, ACT365, ACT365, True, False) ;
            break ;

        case OLDUKCONSORTIUM:
            ytmc = Set_YTMCONV(COMPOUND, SEMIANNUALLY, 
                               True, False, True,
                               ACT365, ACT365, ACT365, False, False) ;
            break ;
            
        /* ACTNL365 related */
        case JPYGOVEQV:
            ytmc = Set_YTMCONV(JGBYTM, ANNUALLY, 
                               False, False, False,
                               ACTNL365, ACTNL365, ACTNL365, True, False) ;
            break ;

        /* Money Market related */
        case MM360:
            ytmc = Set_YTMCONV(SIMPLE_MM, ANNUALLY, 
                               True, True, True,
                               ACT360, ACT360, ACT360, True, False) ;
            break ;

        case MM365:
            ytmc = Set_YTMCONV(SIMPLE_MM, ANNUALLY, 
                               True, True, True,
                               ACT365, ACT365, ACT365, True, False) ;
            break ;

        case REPO360:
            ytmc = Set_YTMCONV(SIMPLE_REPO, ANNUALLY, 
                               True, True, True,
                               ACT360, ACT360, ACT360, True, False) ;
            break ;

        case REPO365:
            ytmc = Set_YTMCONV(SIMPLE_REPO, ANNUALLY, 
                               True, True, True,
                               ACT365, ACT365, ACT365, True, False) ;
            break ;
    }

    return ytmc ;
}



/*,,SOH,,
*************************************************************************
*
*               BondBM_BONDBM2FIXPAY()
*
*   interface   #include <bond.h>
*               FIXPAY BondBM_BONDBM2FIXPAY(DATESTR *settle,
*                                           BONDBM  *bond,
*                                           YTMSEG  yseg) ;
*
*   general     The function translates a bond segment into the
*               standard FIXPAY format - i.e by defaulting the various
*               elements of the FIXPAY.
*
*               The YTMSEG input is used because sometimes the bond
*               data depends on the yield definition (Bank of Canada).
*
*               Note that we do not assume any responsibility for chan-
*               ges in the settings of the various segment conventions.
*               We refer to "Government Bond Outlines", 11th edition,
*               July 1998, J.P.Morgan and information gathered from Reuters
*               as of Summer 1999.
*
*               For our current understanding of the various conventions*
*               check out the documentation of YTMSEG and BONDBM.
*
*   input       DATESTR   *settle       The settle date for the bond
*
*               BONDBM    *bond         The standard bond data
*
*               YTMSEG    yseg          The YTM segment
*
*   output
*
*   returns     The FIXPAY appropriately set
*
*   diagnostics
*
*   see also
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/

FIXPAY BondBM_BONDBM2FIXPAY(DATESTR* settle, 
                               BONDBM*  bond, 
                               YTMSEG  yseg)
{
    FIXPAY     fixp ;
    EXRULE     exc ;
    ACCRUINT   accru ;
    PAYDAYSEQ  pseq ;
    FIXRATE    fix ;
    PAYDAYDEF  pday ;
    DATEARRAY  days ;
    HOLI_STR   holi ;
    INTI       xc, ndays, mon ;
    COUPONBASE cbaio, cbn, cbodd, cbai ;
    CALCONV    cal ;
    EOMCONV    eom ;
    EXDAYCONV  xconv ;
    BOOLE      calds, incl, pre, jgb, cgb ;
    DATESTR    tmp, matur, nom, effect, first, secl ;
    ODDCONV    odd1, oddN ;

    /* warning avoidance */
    memset(&first, 0, sizeof(first));

    /* Set sensible defaults */
    cal   = EU30E360 ;
    eom   = SAME ;
    mon   = 12 ;
    cbn   = EVENCOUP ;
    cbai  = EVENCOUP ;
    cbodd = EVENCOUP ;
    cbaio = EVENCOUP ;
    xconv = EX_DAYS ;
    xc    = 0 ;
    calds = True ;
    incl  = False ;
    pre   = True ;
    jgb   = False ;
    cgb   = False ;
    matur = bond->matur ;
    odd1  = bond->stub_front ;
    oddN  = NOODD ;
    secl  = Cldr_YMD2Datestr((YYYYMMDD) 0) ;
    nom   = secl ;
    holi  = Set_HOLI_STR(NO_BUSADJUST, 0, NULL) ;

    switch (bond->seg)
    {
        case USDGOV:   /* Bonds + Notes */
            cal   = ACTACT ;
            eom   = LAST ;
            mon   = 6 ;
            break ;

        case GBPGOV:   /* Gilts */
            cal   = ACTACT ;
            eom   = SAME ;
            mon   = 6 ;
            cbai  = ODDCOUP ;
            cbodd = ODDCOUP ;
            cbaio = ODDCOUP ;
            xconv = EX_UKGILT ;
            break ;

        case OLDGBPGOV:   /* Gilts */
            cal   = ACT365 ;
            eom   = SAME ;
            mon   = 6 ;
            cbai  = ODDCOUP ;
            cbodd = ODDCOUP ;
            cbaio = ODDCOUP ;
            xconv = EX_UKGILT ;
            break ;

        case NLGGOV:
        case BEFGOV:   /* OLO */
            break ;

        case DEMGOV:
            cal = ACTACT ;
            break ;

        case ITLGOV:   /* BTP + CTO */
            incl = True ;
            cal  = ACTACT ;

            /* Make sure that issue date is used in this case */
            if (bond->tax.pro_rata == True && bond->tax.tax_cg > 0.00001)
                odd1 = SHORTODD ;

            break ;

        case OLDITLGOV:   /* BTP + CTO */
            mon  = 6 ;
            incl = True ;

            /* Make sure that issue date is used in this case */
            if (bond->tax.pro_rata == True && bond->tax.tax_cg > 0.00001)
                odd1 = SHORTODD ;

            break ;

        case ESPGOV:   /* BONOS */
            cal = ACTACT ;
            pre = False ;

            /* Be careful about nominated date */
            if (Cldr_DateLE(settle, &bond->issue_nom) == True &&
                Cldr_DateLT(&bond->issue_nom, &bond->matur) == True)
                nom = bond->issue_nom ;
            break ;

        case JPYGOV:   
            /* Be very careful about JGB's - due to specialties in first
               and last coupon period */
            cal   = ACT365 ;
            mon   = 6 ;
            cbai  = ODDCOUP ;
            cbaio = ODDCOUP ;
            cbodd = EVENODD ;
            jgb   = True ;

            if (matur.d != first.d)
                oddN = LONGODD ;

            secl   = matur ;
            secl.d = bond->first.d ;
            secl   = Cldr_AddMonths(&secl, -mon, eom) ;

            tmp = Cldr_AddMonths(&bond->first, -mon, eom) ;

            if (Cldr_DateLE(&bond->issue_nom, &tmp) == True)
                odd1 = LONGODD ;
            else
                odd1 = SHORTODD ;

            break ;

        case FRFGOV:   /* OAT + BTAN */ 
            cal = ACTACT ;
            break ;

        case DKKGOV:
            xc = 30 ;
            break ;

        case SEKGOV:
            /* 5 Businessdays before a coupon day -> Record Date */
            xc    = 5 ;      
            calds = False ;
            break ;

        case NOKGOV:
            cal   = ACT365 ;
            cbai  = ODDCOUP ;
            cbodd = ODDCOUP ;
            cbaio = ODDCOUP ;
            xc    = 14 ;
            break ;

        case FIMGOV:
            cal   = ACTACT ;
            break ;

        case OLDFIMGOV:
            cal   = EU30360 ;
            break ;

        case CADGOV:
            cal   = ACT365 ;
            mon   = 6 ;
            cbn   = EVENCOUP ;
            cbai  = ODDCOUP ;
            cbodd = ODDCOUP ;
            cbaio = ODDCOUP ;
            cgb   = True ;

            if (yseg == BANKOFCANADA)
            {
                odd1  = NOODD ;
                cgb   = False ;
                cbai  = EVENCOUP ;
                cbodd = EVENCOUP ;
            }
            break ;

        case NZDGOV:
            cal   = ACTACT ; 
            mon   = 6 ;
            xc    = 10 ;
            break ;

        case AUDGOV:
            cal   = ACTACT ;
            mon   = 6 ;
            xc    = 7 ;
            break ;

        case ATSGOV:
            xconv = EX_AUT ;
            break ;

        case CHFGOV:
            cal = EU30EP360 ;
            break ;

        case IEPGOV:   
            cal   = ACTACT ;
            cbai  = ODDCOUP ;
            cbodd = ODDCOUP ;
            cbaio = ODDCOUP ;
            xconv = EX_IRLGILT ;
            break ;
    }

    /* Handle front stub carefully */
    pseq = Set_PAYDAYSEQ(mon, MONTHS, odd1, oddN, ANCHORBACK, eom) ;

    if (odd1 != NOODD)
        pday = Set_PAYDAYDEF(False, &bond->issue_nom, &secl, &matur, 
                             False, &pseq, 0, NULL) ;
    else
        pday = Set_PAYDAYDEF(False, settle, &secl, &matur, 
                             False, &pseq, 0, NULL) ;
    
    /* Find first payday */
    days = Cflw_Paydays(&pday, &holi, &ndays) ;
    if (ndays > 0)
        first = days[0] ;
    else
        /* Do something to survive - should not happen */
        first = *settle ;

    /* Set effective */
    if (odd1 != NOODD)
        effect = bond->issue_nom ;
    else 
        effect = Cldr_AddMonths(&first, -mon, eom) ;

    if (Cldr_DateLE(settle, &nom) == True)
        effect = nom ;

    /* Now set the fixpay */
    pday  = Set_PAYDAYDEF(True, &first, &secl, &matur,
                          False, &pseq, 0, NULL) ;
    fix   = Set_FIXRATE(bond->coupon, cal, &effect, NULL, 0.0, 
                        cbn, cbodd, False, jgb, NULL, False, NULL, NODCOMP) ;
    exc   = Set_EXRULE(xconv, xc, calds, cal, &first,
                       0, NULL, NULL, False) ; 
    accru = Set_ACCRUINT(cal, cbai, cbaio, incl, pre, SIMPLE_MM, 1,
                         False, cgb, False, &exc) ;
    fixp  = Set_FIXPAY(&pday, &fix, NULL, NULL, &accru, NULL, &bond->tax) ;
    
    Free_DATEARRAY(days) ;

    return fixp ;
}


/*,,SOH,,
*************************************************************************
*
*               BondBM_YTM2Price()
*
*   interface   #include <bond.h>
*               FL64 BondBM_YTM2Price(FL64     ytm,
*                                     DATESTR  *settle,
*                                     BONDBM   *bond,
*                                     YTMSEG   yseg,
*                                     HOLI_STR *holi,
*                                     RISKCONV risk,
*                                     BOOLE    modf,
*                                     FL64     *dp,
*                                     FL64     *ddp) ;
*
*   general     The function calculates the price given YTM
*               for the bond with respect to the conventions defined.
*
*               Note that we do not assume any responsibility for chan-
*               ges in the settings of the various segment conventions.
*
*               For our current understanding of the various conventions*
*               check out the documentation of YTMSEG and BONDBM.
*
*   input       FL64      ytm           The bond yield
*
*               DATESTR   *settle       The settle date
*
*               BONDBM    *bond         The bond definition
*
*               YTMSEG    yseg          The conventions defined for
*                                       calculating the YTM.
*
*               HOLI_STR  *holi         Business day adjustment setup
*
*               RISKCONV  risk          The risk setup.
*
*               BOOLE     modf          True means that ratios are modi-*
*                                       (i.e. scaled with the dirty
*                                       price), False means direct
*                                       derivatives.
*
*   output      FL64      *dp           The dollar duration
*
*               FL64      *ddp          The dollar convexity
*
*   returns     The clean price of the bond on the settlement date.
*
*   diagnostics
*
*   see also
*
*************************************************************************
,,EOH,,*/

FL64 BondBM_YTM2Price(FL64  ytm,
                      DATESTR*  settle, 
                      BONDBM*   bond, 
                      YTMSEG   yseg,
                      HOLI_STR* holi,
                      RISKCONV risk,
                      BOOLE    modf,
                      FL64*     dp,
                      FL64*     ddp)
{
    FL64      p ;
    TRADEINFO trade ;
    FIXPAY    fixp ;
    YTMCONV   ytmc ;

    trade = bond_set_tradeinfo(settle) ;
    fixp  = BondBM_BONDBM2FIXPAY(settle, bond, yseg) ;
    ytmc  = BondBM_YTMSEG2YTMCONV(yseg) ;

    p = Bond_YTM2Price(ytm, &trade, &fixp, &ytmc, holi, risk, 
                       modf, dp, ddp) ;

    return p ;
}


/*,,SOH,,
*************************************************************************
*
*               BondBM_YTM2Yield()
*
*   interface   #include <bond.h>
*               BOOLE BondBM_YTM2Yield(FL64     price,
*                                      DATESTR  *settle,
*                                      BONDBM   *bond,
*                                      YTMSEG   yseg,
*                                      HOLI_STR *holi,
*                                      FL64     *ytm)
*
*   general     The function calculates the Yield to maturity
*               for the bond with respect to the conventions defined.
*
*               Note that we do not assume any responsibility for chan-
*               ges in the settings of the various segment conventions.
*
*               For our current understanding of the various conventions*
*               check out the documentation of YTMSEG and BONDBM.
*
*   input       FL64      price         The bond price (clean)
*
*               DATESTR   *settle       The settle date
*
*               BONDBM    *bond         The bond definition
*
*               YTMSEG    yseg          The conventions defined for
*                                       calculating the YTM.
*
*               HOLI_STR  *holi         Business day adjustment setup
*
*   output      FL64      *ytm          The YTM calculated in %
*
*   returns     True if all is OK, False if not.
*
*   diagnostics
*
*   see also
*
*************************************************************************
,,EOH,,*/


BOOLE BondBM_YTM2Yield(FL64  price,
                       DATESTR*  settle, 
                       BONDBM*   bond, 
                       YTMSEG   yseg,
                       HOLI_STR* holi,
                       FL64*     ytm)
{
    TRADEINFO trade ;
    BOOLE     ok ;
    ITERCTRL  ictrl ;
    FIXPAY    fixp ;
    YTMCONV   ytmc ;

    trade = bond_set_tradeinfo(settle) ;
    trade.price = price ;
    fixp  = BondBM_BONDBM2FIXPAY(settle, bond, yseg) ;
    ytmc  = BondBM_YTMSEG2YTMCONV(yseg) ;

    /* JJ asked for this accuracy */
    Init_ITERCTRL(&ictrl) ;
    ictrl.acc = 1.0E-10 ;

    ok = Bond_YTM2Yield(&trade, &fixp, &ytmc, holi, &ictrl, ytm) ;

    return ok ;
}


/*,,SOH,,
*************************************************************************
*
*               BondBM_YTM2Duration()
*
*   interface   #include <bond.h>
*               FL64 BondBM_YTM2Duration(FL64     ytm,
*                                        DATESTR  *settle,
*                                        BONDBM   *bond,
*                                        YTMSEG   yseg,
*                                        HOLI_STR *holi) ;
*
*   general     The function calculates the duration given YTM
*               for the bond with respect to the conventions defined.
*
*               Note that we do not assume any responsibility for chan-
*               ges in the settings of the various segment conventions.
*
*               For our current understanding of the various conventions*
*               check out the documentation of YTMSEG and BONDBM.
*
*   input       FL64      ytm           The bond yield
*
*               DATESTR   *settle       The settle date
*
*               BONDBM    *bond         The bond definition
*
*               YTMSEG    yseg          The conventions defined for
*                                       calculating the YTM.
*
*               HOLI_STR  *holi         Business day adjustment setup
*
*   output
*
*   returns     The bond duration
*
*   diagnostics
*
*   see also
*
*************************************************************************
,,EOH,,*/

FL64 BondBM_YTM2Duration(FL64  ytm,
                         DATESTR*  settle, 
                         BONDBM*   bond, 
                         YTMSEG   yseg,
                         HOLI_STR* holi)
{
    FL64      dur ;
    TRADEINFO trade ;
    FIXPAY    fixp ;
    YTMCONV   ytmc ;

    trade = bond_set_tradeinfo(settle) ;
    fixp  = BondBM_BONDBM2FIXPAY(settle, bond, yseg) ;
    ytmc  = BondBM_YTMSEG2YTMCONV(yseg) ;

    dur = Bond_YTM2Duration(ytm, &trade, &fixp, &ytmc, holi) ;
                          
    return dur ;
}


/*,,SOH,,
*************************************************************************
*
*               BondBM_Accruint()
*
*   interface   #include <bond.h>
*               FL64 BondBM_Accruint(DATESTR  *settle,
*                                    BONDBM   *bond,
*                                    HOLI_STR *holi) ;
*
*   general     The function calculates the accrued interest
*               for the bond with respect to the conventions defined.
*
*               Note that we do not assume any responsibility for chan-
*               ges in the settings of the various segment conventions.
*
*               For our current understanding of the various conventions*
*               check out the documentation of YTMSEG and BONDBM.
*
*   input       DATESTR   *settle       The settle date
*
*               BONDBM    *bond         The bond definition
*
*               HOLI_STR  *holi         Business day adjustment setup
*
*   output
*
*   returns     The bond accrued interest
*
*   diagnostics
*
*   see also
*
*************************************************************************
,,EOH,,*/

FL64 BondBM_Accruint(DATESTR* settle, 
                     BONDBM*   bond, 
                     HOLI_STR* holi)
{
    TRADEINFO trade ;
    FIXPAY    fixp ;
    AIRESULT  aires ;

    trade = bond_set_tradeinfo(settle) ;
    fixp  = BondBM_BONDBM2FIXPAY(settle, bond, ISMA360ANN) ;
    aires = Bond_Accruint(&trade, &fixp, holi) ;

    return aires.AI ;
}


/*,,SOH,,
************************************************************************
*
*                Set_BONDBM()
*
*   interface    #include <bond.h>
*                BONDBM Set_BONDBM(BONDSEG    seg,
*                                  DATESTR*   matur,
*                                  FL64       coupon,
*                                  ODDCONV    stub_front,
*                                  DATESTR*   issue_nom,
*                                  DATESTR*   first,
*                                  TAXINFO*   tax) ;
*
*   general      This routine sets the members of the struct defined
*                in the function name. The pointer members are simply
*                assigned - without physical copying. The intention
*                of the Set_*() routines is that by using this
*                functionality, one avoids setting individual members
*                of structs in the application code.
*
*                When new members are inserted in structs the Set_*()
*                routine will be changed accordingly.
*
*                For details on the interpretation of the individual
*                struct members please check the struct definition.
*
*   input        BONDSEG    seg        See general section.
*
*                DATESTR*   matur      See general section.
*
*                FL64       coupon     See general section.
*
*                ODDCONV    stub_front See general section.
*
*                DATESTR*   issue_nom  See general section.
*                                      Use NULL for defaults
*
*                DATESTR*   first      See general section.
*                                      Use NULL for defaults
*
*                TAXINFO    *tax       See general section.
*                                      Use NULL for defaults
*
*   output
*
*   returns      The filled out BONDBM struct
*
*   diagnostics
*
*   see also     BONDBM
*
************************************************************************
,,EOH,,*/

BONDBM Set_BONDBM(BONDSEG     seg,
                     DATESTR*    matur,
                     FL64        coupon,
                     ODDCONV     stub_front,
                     DATESTR*    issue_nom,   
                     DATESTR*    first,
                     TAXINFO*    tax)
{
    BONDBM bm ;

    bm.seg   = seg ;
    bm.matur = *matur;
    bm.coupon = coupon;
    bm.stub_front = stub_front ;  
    if (issue_nom != NULL)
        bm.issue_nom = *issue_nom ;
    else
        bm.issue_nom = Cldr_YMD2Datestr((YYYYMMDD) 0)  ;

    if (first != NULL)
        bm.first = *first ;
    else
        bm.first = Cldr_YMD2Datestr((YYYYMMDD) 0)  ;

    if (tax != NULL)
        bm.tax = *tax ;
    else
        bm.tax = Set_TAXINFO(0.0, 0.0, 0.0, False) ;

    return bm ;
}

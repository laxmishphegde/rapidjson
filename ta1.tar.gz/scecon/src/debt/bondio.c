#include <sccsid.h>
SCCSID(bondio_c,
  "@(#)bondio.c	1.18 (SimCorp) 99/11/15 14:04:42")


/************************************************************************
*
*   project     SCecon
*
*   file name   validate.c
*
*   general     This file contains routines for validating the
*               content of the data structures of SCecon
*
************************************************************************/

/*** includes **********************************************************/
#include <ioconv.h>
#include <bondio.h>
#include <bondvl.h>


ODDCONV Str2ODDCONV(TEXT txt)
{
    ODDCONV odd = NOODD;

    Str_Uppercase(txt) ;

    if      (!strcmp(txt, "NOODD"))        odd = NOODD ;
    else if (!strcmp(txt, "NONE"))         odd = NOODD ;
    else if (!strcmp(txt, "NO"))           odd = NOODD ;

    else if (!strcmp(txt, "SHORT"))        odd = SHORTODD ;
    else if (!strcmp(txt, "SHORTODD"))     odd = SHORTODD ;

    else if (!strcmp(txt, "LONG"))         odd = LONGODD ;
    else if (!strcmp(txt, "LONGODD"))      odd = LONGODD ;
    else
        SCecon_error("oddconv unknown\n", "Str2ODDCONV()", 
            SCECONABORT) ;

    return odd ;
}


/*
..
*/


COUPONBASE Str2COUPONBASE(TEXT txt)
{
    COUPONBASE r = COUPONBASE_INIT ;

    Str_Uppercase(txt) ;

    if      (!strcmp(txt, "EVENCOUP"))      r = EVENCOUP ;
    else if (!strcmp(txt, "SAME"))          r = EVENCOUP ;
    else if (!strcmp(txt, "PERIOD"))        r = EVENCOUP ;
    else if (!strcmp(txt, "EVEN"))          r = EVENCOUP ;
    else if (!strcmp(txt, "E"))             r = EVENCOUP ;

    else if (!strcmp(txt, "EQUALCOUP"))     r = EQUALCOUP ;
    else if (!strcmp(txt, "EQUAL"))         r = EQUALCOUP ;

    else if (!strcmp(txt, "ODDCOUP"))       r = ODDCOUP ;
    else if (!strcmp(txt, "ODD"))           r = ODDCOUP ;
    else if (!strcmp(txt, "O"))             r = ODDCOUP ;
    else if (!strcmp(txt, "DAYCOUNT"))      r = ODDCOUP ;
    else if (!strcmp(txt, "DAYS"))          r = ODDCOUP ;

    else if (!strcmp(txt, "EVENODD"))       r = EVENODD ;
    else
        SCecon_error("Unknown coupon base\n", "Str2COUPONBASE()", 
          SCECONABORT) ;

    return r ;
}


/*
..
*/


EXDAYCONV Str2EXDAYCONV(TEXT txt)
{
    EXDAYCONV eom = EXDAYCONV_INIT;

    Str_Uppercase(txt) ;

    if      (!strcmp(txt, "EX_DAYS"))     eom = EX_DAYS ;

    else if (!strcmp(txt, "EX_DATE"))     eom = EX_DATE ;

    else if (!strcmp(txt, "EX_FIX"))      eom = EX_FIX ;

    else if (!strcmp(txt, "EX_AUT"))      eom = EX_AUT ;
    else if (!strcmp(txt, "AUT"))         eom = EX_AUT ;

    else if (!strcmp(txt, "EX_OLDBRD"))   eom = EX_OLDBRD ;
    else if (!strcmp(txt, "OLDBRD"))      eom = EX_OLDBRD ;

    else if (!strcmp(txt, "EX_UKGILT"))   eom = EX_UKGILT ;
    else if (!strcmp(txt, "UKGILT"))      eom = EX_UKGILT ;

    else if (!strcmp(txt, "EX_IRLGILT"))  eom = EX_IRLGILT ;
    else if (!strcmp(txt, "IRLGILT"))     eom = EX_IRLGILT ;

    else if (!strcmp(txt, "EX_DATEARRAY")) eom = EX_DATEARRAY ;
    else
        SCecon_error("Unknown ex-coupon day convention\n", 
            "Str2EXDAYCONV()", SCECONABORT) ;

    return eom ;
}


/*
..
*/


BONDSEG Str2BONDSEG(TEXT txt)
{
    BONDSEG eom = USDGOV;

    Str_Uppercase(txt) ;

    if      (!strcmp(txt, "USDGOV"))         eom = USDGOV ;
    else if (!strcmp(txt, "USD"))            eom = USDGOV ;
    else if (!strcmp(txt, "UST"))            eom = USDGOV ;

    else if (!strcmp(txt, "GBPGOV"))         eom = GBPGOV ;
    else if (!strcmp(txt, "OLDGBPGOV"))      eom = OLDGBPGOV ;
    else if (!strcmp(txt, "GBP"))            eom = GBPGOV ;
    else if (!strcmp(txt, "UKGILT"))         eom = GBPGOV ;
    else if (!strcmp(txt, "GILT"))           eom = GBPGOV ;

    else if (!strcmp(txt, "DEMGOV"))         eom = DEMGOV ;
    else if (!strcmp(txt, "DEM"))            eom = DEMGOV ;
    else if (!strcmp(txt, "BUND"))           eom = DEMGOV ;
    else if (!strcmp(txt, "BOBL"))           eom = DEMGOV ;
    else if (!strcmp(txt, "SCHAETZE"))       eom = DEMGOV ;

    else if (!strcmp(txt, "NLGGOV"))         eom = NLGGOV ;
    else if (!strcmp(txt, "NLG"))            eom = NLGGOV ;

    else if (!strcmp(txt, "BEFGOV"))         eom = BEFGOV ;
    else if (!strcmp(txt, "BEF"))            eom = BEFGOV ;
    else if (!strcmp(txt, "OLO"))            eom = BEFGOV ;

    else if (!strcmp(txt, "ITLGOV"))         eom = ITLGOV ;
    else if (!strcmp(txt, "ITL"))            eom = ITLGOV ;
    else if (!strcmp(txt, "OLDITLGOV"))      eom = OLDITLGOV ;
    else if (!strcmp(txt, "BTP"))            eom = ITLGOV ;
    else if (!strcmp(txt, "CTO"))            eom = ITLGOV ;

    else if (!strcmp(txt, "ESPGOV"))         eom = ESPGOV ;
    else if (!strcmp(txt, "ESP"))            eom = ESPGOV ;
    else if (!strcmp(txt, "BONOS"))          eom = ESPGOV ;

    else if (!strcmp(txt, "JPYGOV"))         eom = JPYGOV ;
    else if (!strcmp(txt, "JPY"))            eom = JPYGOV ;
    else if (!strcmp(txt, "JGB"))            eom = JPYGOV ;

    else if (!strcmp(txt, "FRFGOV"))         eom = FRFGOV ;
    else if (!strcmp(txt, "FRF"))            eom = FRFGOV ;
    else if (!strcmp(txt, "OAT"))            eom = FRFGOV ;
    else if (!strcmp(txt, "BTAN"))           eom = FRFGOV ;

    else if (!strcmp(txt, "DKKGOV"))         eom = DKKGOV ;
    else if (!strcmp(txt, "DKK"))            eom = DKKGOV ;

    else if (!strcmp(txt, "SEKGOV"))         eom = SEKGOV ;
    else if (!strcmp(txt, "SEK"))            eom = SEKGOV ;

    else if (!strcmp(txt, "NOKGOV"))         eom = NOKGOV ;
    else if (!strcmp(txt, "NOK"))            eom = NOKGOV ;

    else if (!strcmp(txt, "FIMGOV"))         eom = FIMGOV ;
    else if (!strcmp(txt, "OLDFIMGOV"))      eom = OLDFIMGOV ;
    else if (!strcmp(txt, "FIM"))            eom = FIMGOV ;

    else if (!strcmp(txt, "CADGOV"))         eom = CADGOV ;
    else if (!strcmp(txt, "CAD"))            eom = CADGOV ;
    else if (!strcmp(txt, "CGB"))            eom = CADGOV ;

    else if (!strcmp(txt, "NZDGOV"))         eom = NZDGOV ;
    else if (!strcmp(txt, "NZD"))            eom = NZDGOV ;

    else if (!strcmp(txt, "AUDGOV"))         eom = AUDGOV ;
    else if (!strcmp(txt, "AUD"))            eom = AUDGOV ;

    else if (!strcmp(txt, "ATSGOV"))         eom = ATSGOV ;
    else if (!strcmp(txt, "ATS"))            eom = ATSGOV ;
    else if (!strcmp(txt, "AUT"))            eom = ATSGOV ;

    else if (!strcmp(txt, "CHFGOV"))         eom = CHFGOV ;
    else if (!strcmp(txt, "CHF"))            eom = CHFGOV ;

    else if (!strcmp(txt, "IEPGOV"))         eom = IEPGOV ;
    else if (!strcmp(txt, "IRLGILT"))        eom = IEPGOV ;
    else if (!strcmp(txt, "IEP"))            eom = IEPGOV ;
    else if (!strcmp(txt, "IRA"))            eom = IEPGOV ;
    else
        SCecon_error("BONDSEG unknown\n", "Str2BONDSEG()", 
            SCECONABORT) ;

    return eom ;
}


/*
..
*/


YTMSEG Str2YTMSEG(TEXT txt)
{
    YTMSEG eom = ISMA360ANN;

    Str_Uppercase(txt) ;

    if      (!strcmp(txt, "ISMA360ANN"))        eom = ISMA360ANN ;
    else if (!strcmp(txt, "ISMA360A"))          eom = ISMA360ANN ;
    else if (!strcmp(txt, "ISMA360SEMI"))       eom = ISMA360SEMI ;
    else if (!strcmp(txt, "ISMA360S"))          eom = ISMA360SEMI ;

    else if (!strcmp(txt, "NZDGOVEQV"))         eom = NZDGOVEQV ;
    else if (!strcmp(txt, "NZDGOV"))            eom = NZDGOVEQV ;
    else if (!strcmp(txt, "NZD"))               eom = NZDGOVEQV ;

    else if (!strcmp(txt, "USDGOVEQV"))         eom = USDGOVEQV ;
    else if (!strcmp(txt, "USDEQV"))            eom = USDGOVEQV ;
    else if (!strcmp(txt, "STREET"))            eom = USDGOVEQV ;

    else if (!strcmp(txt, "USTEQV"))            eom = USTEQV ;
    else if (!strcmp(txt, "UST"))               eom = USTEQV ;

    else if (!strcmp(txt, "AUDGOVEQV"))         eom = AUDGOVEQV ;
    else if (!strcmp(txt, "AUDGOV"))            eom = AUDGOVEQV ;
    else if (!strcmp(txt, "AUD"))               eom = AUDGOVEQV ;

    else if (!strcmp(txt, "FRFGOVEQV"))         eom = FRFGOVEQV ;
    else if (!strcmp(txt, "FRFGOV"))            eom = FRFGOVEQV ;
    else if (!strcmp(txt, "FRF"))               eom = FRFGOVEQV ;
    else if (!strcmp(txt, "OAT"))               eom = FRFGOVEQV ;
    else if (!strcmp(txt, "BTAN"))              eom = FRFGOVEQV ;

    else if (!strcmp(txt, "ITLGOVEQV"))         eom = ITLGOVEQV ;
    else if (!strcmp(txt, "OLDITLGOVEQV"))      eom = OLDITLGOVEQV ;
    else if (!strcmp(txt, "ITLGOV"))            eom = ITLGOVEQV ;
    else if (!strcmp(txt, "ITL"))               eom = ITLGOVEQV ;
    else if (!strcmp(txt, "ITLGOVEQVTRUE"))     eom = ITLGOVEQVTRUE ;
    else if (!strcmp(txt, "OLDITLGOVEQVTRUE"))  eom = OLDITLGOVEQVTRUE ;
    else if (!strcmp(txt, "ITLGOVTRUE"))        eom = ITLGOVEQVTRUE ;
    else if (!strcmp(txt, "ITLTRUE"))           eom = ITLGOVEQVTRUE ;

    else if (!strcmp(txt, "ESPGOVEQV"))         eom = ESPGOVEQV ;
    else if (!strcmp(txt, "OLDESPGOVEQV"))      eom = OLDESPGOVEQV ;
    else if (!strcmp(txt, "ESPGOV"))            eom = ESPGOVEQV ;
    else if (!strcmp(txt, "ESP"))               eom = ESPGOVEQV ;
    else if (!strcmp(txt, "BONOS"))             eom = ESPGOVEQV ;

    else if (!strcmp(txt, "IEPGOVEQV"))         eom = IEPGOVEQV ;
    else if (!strcmp(txt, "IEPGOV"))            eom = IEPGOVEQV ;
    else if (!strcmp(txt, "IEP"))               eom = IEPGOVEQV ;
    else if (!strcmp(txt, "IRLGILT"))           eom = IEPGOVEQV ;
    else if (!strcmp(txt, "IRA"))               eom = IEPGOVEQV ;

    else if (!strcmp(txt, "NOKGOVEQV"))         eom = NOKGOVEQV ;
    else if (!strcmp(txt, "NOKGOV"))            eom = NOKGOVEQV ;
    else if (!strcmp(txt, "NOK"))               eom = NOKGOVEQV ;

    else if (!strcmp(txt, "BANKOFCANADA"))      eom = BANKOFCANADA ;

    else if (!strcmp(txt, "UKBUMPDATES"))       eom = UKBUMPDATES ;
    else if (!strcmp(txt, "OLDUKBUMPDATES"))    eom = OLDUKBUMPDATES ;
    else if (!strcmp(txt, "UKB"))               eom = UKBUMPDATES ;

    else if (!strcmp(txt, "UKCONSORTIUM"))      eom = UKCONSORTIUM ;
    else if (!strcmp(txt, "OLDUKCONSORTIUM"))   eom = OLDUKCONSORTIUM ;
    else if (!strcmp(txt, "UKC"))               eom = UKCONSORTIUM ;

    else if (!strcmp(txt, "JPYGOVEQV"))         eom = JPYGOVEQV ;
    else if (!strcmp(txt, "JPYGOV"))            eom = JPYGOVEQV ;
    else if (!strcmp(txt, "JPY"))               eom = JPYGOVEQV ;
    else if (!strcmp(txt, "JGB"))               eom = JPYGOVEQV ;

    else if (!strcmp(txt, "MM360"))             eom = MM360 ;    

    else if (!strcmp(txt, "MM365"))             eom = MM365 ;        

    else if (!strcmp(txt, "REPO360"))           eom = REPO360 ;    

    else if (!strcmp(txt, "REPO365"))           eom = REPO365 ;        

    else
        SCecon_error("YTMSEG unknown\n", "Str2YTMSEG()", SCECONABORT) ;

    return eom ;
}


/*
..
*/

FIXDCOMP Str2FIXDCOMP(TEXT txt)
{
    FIXDCOMP ft = FIXDCOMP_INIT;

    Str_Uppercase(txt) ;

    if      (!strcmp(txt, "NODCOMP"))    ft = NODCOMP ;
    else if (!strcmp(txt, "NONE"))       ft = NODCOMP ;
    else if (!strcmp(txt, "FALSE"))      ft = NODCOMP ;

    else if (!strcmp(txt, "EPR_PER"))    ft = EPR_PER ;
    else if (!strcmp(txt, "PERIODIC"))   ft = EPR_PER ;
    else if (!strcmp(txt, "TRUE"))       ft = EPR_PER ;

    else if (!strcmp(txt, "EPR_DF"))     ft = EPR_DF ;
    else if (!strcmp(txt, "TAM"))        ft = EPR_DF ;

    else if (!strcmp(txt, "EDDR"))       ft = EDDR ;
    else if (!strcmp(txt, "T4M"))        ft = EDDR ;
    else
        SCecon_error("Unknown FIXDCOMP\n", "str2FIXDCOMP()",
                     SCECONABORT) ;

    return ft ;
}


/*
..
*/

RATECONV Str2RATECONV(TEXT txt)
{
    RATECONV ft = RATECONV_INIT;

    Str_Uppercase(txt) ;

    if      (!strcmp(txt, "FRABBA"))    ft = MMRATE ;
    else if (!strcmp(txt, "MMRATE"))    ft = MMRATE ;
    else if (!strcmp(txt, "BILLDISC"))  ft = BILLDISC ;
    else if (!strcmp(txt, "BILLYIELD")) ft = BILLYIELD ;
    else if (!strcmp(txt, "PARYIELD"))  ft = PARYIELD ;
    else if (!strcmp(txt, "REX"))       ft = REX;
    else
        SCecon_error("Unknown RATECONV\n", "Str2RATECONV()",
                     SCECONABORT) ;

    return ft ;
}


/*
..
*/

PREPAYCONV Str2PREPAYCONV(TEXT txt)
{
    PREPAYCONV ft = PREPAYCONV_INIT;

    Str_Uppercase(txt) ;

    if      (!strcmp(txt, "PREPAY_ABS"))  ft = PREPAY_ABS ;
    else if (!strcmp(txt, "ABS"))         ft = PREPAY_ABS ;
    else if (!strcmp(txt, "ABSOLUTE"))    ft = PREPAY_ABS ;
    else if (!strcmp(txt, "AMOUNTS"))     ft = PREPAY_ABS ;

    else if (!strcmp(txt, "PREPAY_CPR"))  ft = PREPAY_CPR ;
    else if (!strcmp(txt, "CPR"))         ft = PREPAY_CPR ;
    else if (!strcmp(txt, "CONDITIONAL")) ft = PREPAY_CPR ;

    else if (!strcmp(txt, "PREPAY_APD"))  ft = PREPAY_APD ;
    else if (!strcmp(txt, "APD"))         ft = PREPAY_APD ;
    else if (!strcmp(txt, "PCT. DIFF."))  ft = PREPAY_APD ;
    else if (!strcmp(txt, "PCT DIFF"))    ft = PREPAY_APD ;
    else if (!strcmp(txt, "PCT_DIFF"))    ft = PREPAY_APD ;

    else
        SCecon_error("Unknown PREPAYCONV\n", "Str2RATECONV()",
                     SCECONABORT) ;

    return ft ;
}

/*
..
*/


INDEXLOANTYPE Str2INDEXLOANTYPE(TEXT txt)
{
    INDEXLOANTYPE unit = INDEXLOANTYPE_INIT;

    Str_Uppercase(txt) ;

    if (!strcmp(txt, "IS_DEBITOR"))       unit = IS_DEBITOR ;
    else if (!strcmp(txt, "IS_CREDITOR")) unit = IS_CREDITOR ;
    else if (!strcmp(txt, "AI"))          unit = AI ;
    else if (!strcmp(txt, "SI"))          unit = SI ;
    else if (!strcmp(txt, "I"))           unit = I ;
    else
        SCecon_error("Unknown index loan type\n",
                     "Str2INDEXLOANTYPE()", SCECONABORT) ;

    return unit ;
}

/*..*/



ODDCONV Read_ODDCONV(FILE* in, FILE* out, TEXT dscr)
{
    ODDCONV irr;
    CH txb[MAX_KEYWORD_LENGTH];

      /* Comments, if any: */
    if (!IOUtil_ReadComment(in, out))
        Write_Comment(out, dscr);

    Read_TEXT(in, MAX_KEYWORD_LENGTH, txb);
    irr = Str2ODDCONV(txb);

    fprintf(out, " %s\n", txb);

    return irr;
}

/*
..
*/


COUPONBASE Read_COUPONBASE(FILE* in, FILE* out, TEXT dscr)
{
    COUPONBASE irr;
    CH txb[MAX_KEYWORD_LENGTH];

      /* Comments, if any: */
    if (!IOUtil_ReadComment(in, out))
        Write_Comment(out, dscr);

    Read_TEXT(in, MAX_KEYWORD_LENGTH, txb);
    irr = Str2COUPONBASE(txb);

    fprintf(out, " %s\n", txb);

    return irr;
}

/*
..
*/


EXDAYCONV Read_EXDAYCONV(FILE* in, FILE* out, TEXT dscr)
{
    EXDAYCONV irr;
    CH txb[MAX_KEYWORD_LENGTH];

      /* Comments, if any: */
    if (!IOUtil_ReadComment(in, out))
        Write_Comment(out, dscr);

    Read_TEXT(in, MAX_KEYWORD_LENGTH, txb);
    irr = Str2EXDAYCONV(txb);

    fprintf(out, " %s\n", txb);

    return irr;
}

/*
..
*/


YTMSEG Read_YTMSEG(FILE* in, FILE* out, TEXT dscr)
{
    YTMSEG irr;
    CH txb[MAX_KEYWORD_LENGTH];

      /* Comments, if any: */
    if (!IOUtil_ReadComment(in, out))
        Write_Comment(out, dscr);

    Read_TEXT(in, MAX_KEYWORD_LENGTH, txb);
    irr = Str2YTMSEG(txb);

    fprintf(out, " %s\n", txb);

    return irr;
}

/*
..
*/


BONDSEG Read_BONDSEG(FILE* in, FILE* out, TEXT dscr)
{
    BONDSEG irr;
    CH txb[MAX_KEYWORD_LENGTH];

      /* Comments, if any: */
    if (!IOUtil_ReadComment(in, out))
        Write_Comment(out, dscr);

    Read_TEXT(in, MAX_KEYWORD_LENGTH, txb);
    irr = Str2BONDSEG(txb);

    fprintf(out, " %s\n", txb);

    return irr;
}

/*
..
*/


RATECONV Read_RATECONV(FILE* in, FILE* out, TEXT dscr)
{
    RATECONV irr;
    CH txb[MAX_KEYWORD_LENGTH];

      /* Comments, if any: */
    if (!IOUtil_ReadComment(in, out))
        Write_Comment(out, dscr);

    Read_TEXT(in, MAX_KEYWORD_LENGTH, txb);
    irr = Str2RATECONV(txb);

    fprintf(out, " %s\n", txb);

    return irr;
}

/*
..
*/


FIXDCOMP Read_FIXDCOMP(FILE* in, FILE* out, TEXT dscr)
{
    FIXDCOMP dfw ;
    CH txb[MAX_KEYWORD_LENGTH];

      /* Comments, if any: */
    if (!IOUtil_ReadComment(in, out))
        Write_Comment(out, dscr);

    Read_TEXT(in, MAX_KEYWORD_LENGTH, txb);
    dfw = Str2FIXDCOMP(txb);

    fprintf(out, " %s\n", txb);

    return dfw;
}












BSECTYPE Str2BSECTYPE(TEXT txt)
{
    BSECTYPE unit = BSECTYPE_INIT;

    Str_Uppercase(txt) ;

    if      (!strcmp(txt, "MM"))             unit = MM ;
    else if (!strcmp(txt, "IRF"))            unit = IRF ;
    else if (!strcmp(txt, "SWAP"))           unit = SWAP ;
    else if (!strcmp(txt, "SWAPGENR"))       unit = SWAPGENR ;
    else if (!strcmp(txt, "FRA"))            unit = FRA ;
    else if (!strcmp(txt, "IMMFRA"))         unit = IMMFRA ;
    else if (!strcmp(txt, "BOND"))           unit = BOND ;
    else if (!strcmp(txt, "BONDSMPL"))       unit = BONDSMPL ;
    else if (!strcmp(txt, "AVGIRF"))         unit = AVGIRF ;
    else if (!strcmp(txt, "BONDREPO"))       unit = BONDREPO ;
    else if (!strcmp(txt, "SWAPFUT"))        unit = SWAPFUT;
    else
        SCecon_error("Unknown zero coupon boot strap security type\n",
                     "Str2BSECTYPE()", SCECONABORT) ;

    return unit ;
}


/*
..
*/



BSECTYPE Read_BSECTYPE(FILE* in, FILE* out, TEXT dscr)
{
    BSECTYPE irr;
    CH txb[MAX_KEYWORD_LENGTH];

      /* Comments, if any: */
    if (!IOUtil_ReadComment(in, out))
        Write_Comment(out, dscr);

    Read_TEXT(in, MAX_KEYWORD_LENGTH, txb);
    irr = Str2BSECTYPE(txb);

    fprintf(out, " %s\n", txb);

    return irr;
}



/*
..
*/

INDEXLOANTYPE Read_INDEXLOANTYPE(FILE* in, FILE* out, TEXT dscr)
{
    INDEXLOANTYPE iltype;
    CH txb[MAX_KEYWORD_LENGTH];

      /* Comments, if any: */
    if (!IOUtil_ReadComment(in, out))
        Write_Comment(out, dscr);

    Read_TEXT(in, MAX_KEYWORD_LENGTH, txb);
    iltype = Str2INDEXLOANTYPE(txb);

    fprintf(out, " %s\n", txb);

    return iltype;
}

/*..*/

BSEC Read_BSEC(FILE* in,
                 FILE*    out,
                 FL64*    price,
                 FL64*    spr,
                 FL64*    madj,
                 DATESTR* settle)
{
    BSEC     bsec ;

    bsec.vanilla  = True ;
    bsec.type = Read_BSECTYPE(in, out, "Type") ;
    *settle = Read_DATESTR(in, out, "Settlement") ;

    /* Pick the security */
    if (bsec.type == MM)
        Read_Boot_MM(in, out, &bsec, price, spr) ;
    else if (bsec.type == FRA)
        Read_Boot_FRA(in, out, &bsec, price, spr) ;
    else if (bsec.type == IMMFRA)
        Read_Boot_IMMFRA(in, out, &bsec, price, spr) ;
    else if (bsec.type == IRF)
        Read_Boot_IRF(in, out, &bsec, price, spr, madj) ;
    else if (bsec.type == AVGIRF)
        Read_Boot_AVGIRF(in, out, &bsec, price, spr) ;
    else if (bsec.type == SWAP)
        Read_Boot_SWAP(in, out, &bsec, price, spr) ;
    else if (bsec.type == SWAPGENR)
        Read_Boot_SWAPGENR(in, out, &bsec, price, spr) ;
    else if (bsec.type == SWAPFUT)
        Read_Boot_SWAPFUT(in, out, &bsec, price, spr) ;
    else if (bsec.type == BOND)
        Read_Boot_BOND(in, out, &bsec, price, spr, settle) ;
    else if (bsec.type == BONDSMPL)
        Read_Boot_BONDSMPL(in, out, &bsec, price, spr,settle) ;
    else if (bsec.type == BONDREPO)
        Read_Boot_BONDREPO(in, out, &bsec, price, spr, settle) ;

    Write_VALIDATEError(out, Validate_BSEC(&bsec));

    return bsec ;
}


/*
..
*/

void Read_Boot_MM(FILE* in, FILE* out, BSEC* bsec,
                  FL64* price, FL64* spr)
{
    IRRCONV   irr;
    INTI      terms;
    TERMUNIT  unit;
    CALCONV   cal;
    EOMCONV   eom;
    BUSCONV   bus;

    irr = Read_IRRCONV(in, out, "IRR") ;
    terms = Read_INTI(in, out, "Terms") ;
    unit = Read_TERMUNIT(in, out, "Unit") ;
    *price = Read_FL64(in, out, "Par Rate") ;
    *spr = Read_FL64(in, out, "Spread") ;
    cal = Read_CALCONV(in, out, "Day count") ;
    eom = Read_EOMCONV(in, out, "End of Month") ;
    bus = Read_BUSCONV(in, out, "Business Conv.") ;

    *bsec = Set_BSEC_MM(irr, cal, cal, eom, bus, terms, unit) ;
}

/*
..
*/

void Read_Boot_IRF(FILE* in, FILE* out, BSEC* bsec,
                   FL64* price, FL64* spr, FL64* madj)
{
    DATESTR  dstart, dmatur ;
    CALCONV   cal;
    EOMCONV   eom;
    BUSCONV   bus;

    dstart = Read_DATESTR(in, out, "Start date") ;
    dmatur = Read_DATESTR(in, out, "Maturity") ;
    *price = Read_FL64(in, out, "Par Rate") ;
    *spr = Read_FL64(in, out, "Spread") ;
    *madj = Read_FL64(in, out, "Margin Adj") ;
    cal = Read_CALCONV(in, out, "Day count") ;
    eom = Read_EOMCONV(in, out, "End of Month") ;
    bus = Read_BUSCONV(in, out, "Business Conv.") ;

    *bsec = Set_BSEC_IRF(cal, cal, eom, bus, &dstart, &dmatur) ;
}


/*
..
*/

void Read_Boot_AVGIRF(FILE* in, FILE* out, BSEC* bsec,
                      FL64* price, FL64* spr)
{
    DATESTR  dstart, dmatur ;
    INTI     terms ;
    TERMUNIT unit ;
    FL64     ca ;
    CALCONV   cal;
    EOMCONV   eom;
    BUSCONV   bus;

    dstart = Read_DATESTR(in, out, "Start date") ;
    dmatur = Read_DATESTR(in, out, "Maturity") ;
    *price = Read_FL64(in, out, "Par Rate") ;
    *spr = Read_FL64(in, out, "Spread") ;
    ca = Read_FL64(in, out, "Current Avg") ;
    terms = Read_INTI(in, out, "Terms") ;
    unit = Read_TERMUNIT(in, out, "Unit") ;
    cal = Read_CALCONV(in, out, "Day count") ;
    eom = Read_EOMCONV(in, out, "End of Month") ;
    bus = Read_BUSCONV(in, out, "Business Conv.") ;

    *bsec = Set_BSEC_AVGIRF(cal, cal, eom, bus, terms, unit,
                            &dstart, &dmatur, ca) ;
}


/*
..
*/

void Read_Boot_FRA(FILE* in, FILE* out, BSEC* bsec,
                   FL64* price, FL64* spr)
{
    INTI     i1, i2 ;
    TERMUNIT unit ;
    CALCONV   cal;
    EOMCONV   eom;
    BUSCONV   bus;
    BOOLE     nest ;

    i1 = Read_INTI(in, out, "Units to start");
    i2 = Read_INTI(in, out, "Units to matur");
    unit = Read_TERMUNIT(in, out, "Unit") ;
    *price = Read_FL64(in, out, "Par Rate") ;
    *spr = Read_FL64(in, out, "Spread") ;
    nest = Read_BOOLE(in, out, "FRA nest") ;
    cal = Read_CALCONV(in, out, "Day count") ;
    eom = Read_EOMCONV(in, out, "End of Month") ;
    bus = Read_BUSCONV(in, out, "Business Conv.") ;

    *bsec = Set_BSEC_FRA(cal, cal, eom, bus, i1, i2, unit, nest) ;
}

/*
..
*/

void Read_Boot_IMMFRA(FILE* in, FILE* out, BSEC* bsec,
                         FL64* price, FL64* spr)
{
    DATESTR   start;
    INTI      i1 ;
    TERMUNIT  unit ;
    CALCONV   cal;
    EOMCONV   eom;
    BUSCONV   bus;

    start = Read_DATESTR(in, out, "Start month") ;
    i1 = Read_INTI(in, out, "Units to start to matur");
    unit = Read_TERMUNIT(in, out, "Unit") ;
    *price = Read_FL64(in, out, "Par Rate") ;
    *spr = Read_FL64(in, out, "Spread") ;
    cal = Read_CALCONV(in, out, "Day count") ;
    eom = Read_EOMCONV(in, out, "End of Month") ;
    bus = Read_BUSCONV(in, out, "Business Conv.") ;

    *bsec = Set_BSEC_IMMFRA(cal, cal, eom, bus, &start, i1, unit) ;
}

/*
..
*/

void Read_Boot_SWAP(FILE* in, FILE* out, BSEC* bsec,
                    FL64* price, FL64* spr)
{
    INTI     i2 ;
    TERMUNIT unit ;
    CALCONV  cal ;
    EOMCONV  eom ;
    BUSCONV  bus ;
    PMTFREQ  freq ;

    i2 = Read_INTI(in, out, "Units to matur");
    unit = Read_TERMUNIT(in, out, "Unit") ;
    *price = Read_FL64(in, out, "Par Rate") ;
    *spr = Read_FL64(in, out, "Spread") ;
    freq = Read_PMTFREQ(in, out, "Frequency");
    cal = Read_CALCONV(in, out, "Day count") ;
    eom = Read_EOMCONV(in, out, "End of Month") ;
    bus = Read_BUSCONV(in, out, "Business Conv.") ;

    *bsec = Set_BSEC_SWAP(cal, cal, eom, bus, i2, unit, freq) ;
}


/*
..
*/

void Read_Boot_SWAPGENR(FILE* in, FILE* out, BSEC* bsec,
                        FL64* price, FL64* spr)
{
    CALCONV  cal ;
    EOMCONV  eom ;
    BUSCONV  bus ;
    INTI      i2 ;
    FIXRATE   fix ;
    PAYDAYDEF rday, cday ;
    PAYDAYSEQ pseq ;
    DATESTR   matur, effect ;
    SWAPFIX   sfix ;

    effect = Read_DATESTR(in, out, "Effective") ;
    matur = Read_DATESTR(in, out, "Maturity") ;
    i2 = Read_INTI(in, out, "Roll Period") ;
    *price = Read_FL64(in, out, "Par Rate") ;
    *spr = Read_FL64(in, out, "Spread") ;
    cal = Read_CALCONV(in, out, "Day count") ;
    eom = Read_EOMCONV(in, out, "End of Month") ;
    bus = Read_BUSCONV(in, out, "Business Conv.") ;

    pseq = Set_PAYDAYSEQ(i2, MONTHS, NOODD, NOODD, ANCHORBACK,
                         eom) ;
    cday = Set_PAYDAYDEF(False, &effect, NULL, &matur, False,
                         &pseq, 0, NULL) ;
    rday = Set_PAYDAYDEF(True, &matur, NULL, &matur, False,
                         &pseq, 0, NULL) ;
    fix = Set_FIXRATE(*price, cal, &effect, &matur, 0.0,
                      ODDCOUP, ODDCOUP, False, False, NULL, True,
                      NULL, NODCOMP) ;
    sfix = Set_SWAPFIX(NULL, &rday, &fix, &cday, 0) ;

    *bsec = Set_BSEC_SWAPGENR(cal, bus, &sfix) ; 
}


/*
..
*/

void Read_Boot_BONDSMPL(FILE* in, FILE* out, BSEC* bsec,
                        FL64* price, FL64* spr, DATESTR* settle)
{
    INTI     i1 ;
    DATESTR  end ;
    FL64     coupon ;
    CALCONV  cal ;
    EOMCONV  eom ;
    BUSCONV  bus ;
    PMTFREQ  freq ;

    *price = Read_FL64(in, out, "Par Rate") ;
    *spr = Read_FL64(in, out, "Spread") ;
    coupon = Read_FL64(in, out, "Coupon") ;
    end = Read_DATESTR(in, out, "Maturity") ;
    i1 = Read_INTI(in, out, "Excdays") ;
    freq = Read_PMTFREQ(in, out, "Frequency");
    cal = Read_CALCONV(in, out, "Day count") ;
    eom = Read_EOMCONV(in, out, "End of Month") ;
    bus = Read_BUSCONV(in, out, "Business Conv.") ;

    *bsec = Set_BSEC_BONDSMPL(cal, cal, eom, bus, freq,
                              settle, &end, coupon, i1) ;
}


/*
..
*/

void Read_Boot_BOND(FILE* in, FILE* out, BSEC* bsec,
                       FL64* price, FL64* spr, DATESTR* settle)
{
    int      i1 ;
    PMTFREQ  freq ;
    CALCONV  cal ;
    EOMCONV  eom ;
    BUSCONV  bus ;
    DATESTR  end ;
    FL64     coupon ;
    EXRULE   xc, xp ;
    FIXPAY   fixp ;

    *price = Read_FL64(in, out, "Par Rate") ;
    *spr = Read_FL64(in, out, "Spread") ;
    coupon = Read_FL64(in, out, "Coupon") ;
    end = Read_DATESTR(in, out, "Maturity") ;
    i1 = Read_INTI(in, out, "Excdays") ;
    freq = Read_PMTFREQ(in, out, "Frequency");
    cal = Read_CALCONV(in, out, "Day count") ;
    eom = Read_EOMCONV(in, out, "End of Month") ;
    bus = Read_BUSCONV(in, out, "Business Conv.") ;
   
    xc = Set_EXRULE(EX_DAYS, i1, True, cal, settle,
                    0, NULL, NULL, False) ;
    xp = Set_EXRULE(EX_DAYS, 0, True, cal, settle,
                    0, NULL, NULL, False) ;

    bsec->fixp = Bond_Simple2FIXPAY(settle, settle, &end, coupon,
                                    freq, BULLET, &xc, &xp,
                                    cal, eom) ;
    fixp = Bond_Simple2FIXPAY(settle, settle, &end, coupon,
                              freq, BULLET, &xc, &xp, cal, eom) ;

    *bsec = Set_BSEC_BOND(cal, bus, &fixp) ;
}


/*
..
*/

void Read_Boot_BONDREPO(FILE* in, FILE* out, BSEC* bsec,
                        FL64* price, FL64* spr, DATESTR* settle)
{
    int      i1 ;
    DATESTR  end, dmatur ;
    FL64     coupon ;
    EXRULE   xc, xp ;
    FIXPAY   fixp ;
    CALCONV  cal, rcal ;
    EOMCONV  eom ;
    PMTFREQ  freq ;
    BUSCONV  bus ;

    dmatur = Read_DATESTR(in, out, "Repo Matur") ;
    rcal = Read_CALCONV(in, out, "Repo Calendar") ;
    *price = Read_FL64(in, out, "Price") ;
    *spr = Read_FL64(in, out, "Spread") ;
    coupon = Read_FL64(in, out, "Coupon") ;
    end = Read_DATESTR(in, out, "Bond Matur") ;
    i1 = Read_INTI(in, out, "Excdays") ;
    freq = Read_PMTFREQ(in, out, "Frequency");
    cal = Read_CALCONV(in, out, "Day count") ;
    eom = Read_EOMCONV(in, out, "End of Month") ;
    bus = Read_BUSCONV(in, out, "Business Conv.") ;

    xc = Set_EXRULE(EX_DAYS, i1, True, cal, settle,
                    0, NULL, NULL, False) ;
    xp = Set_EXRULE(EX_DAYS, 0, True, cal, settle,
                    0, NULL, NULL, False) ;
    fixp = Bond_Simple2FIXPAY(settle, settle, &end, coupon,
                              freq, BULLET, &xc, &xp, cal, eom) ;
    *bsec = Set_BSEC_BONDREPO(cal, bus, eom, &dmatur, &fixp) ;
}

/*
..
*/

void Read_Boot_SWAPFUT(FILE* in, FILE* out, BSEC* bsec,
                       FL64* price, FL64* spr)
{
    INTI     term;
    TERMUNIT unit;
    CALCONV  cal;
    EOMCONV  eom;
    BUSCONV  bus;
    PMTFREQ  freq;
    DATESTR  delivery;
    FL64     coupon;

    delivery = Read_DATESTR(in, out, "Delivery date") ;
    term = Read_INTI(in, out, "Term");
    unit = Read_TERMUNIT(in, out, "Unit");
    *price = Read_FL64(in, out, "Futures price");
    *spr = Read_FL64(in, out, "Spread");
    freq = Read_PMTFREQ(in, out, "Frequency");
    cal = Read_CALCONV(in, out, "Day count");
    eom = Read_EOMCONV(in, out, "End of Month");
    bus = Read_BUSCONV(in, out, "Business Conv.");
    coupon = Read_FL64(in, out, "Coupon");
    

    *bsec = Set_BSEC_SWAPFUT(cal, cal, eom, bus, term, unit, freq, &delivery,
        coupon);
}

/*
..
*/



PAYDAYDEF Read_PAYDAYDEF(FILE* in, FILE* out)
{
    PAYDAYDEF pday ;
    PMTFREQ   freq ;
    COUNT     type ;

    pday.irreg_days = NULL ;
    pday.nirreg = 0 ;

    type = Read_FormatId(in, out) ;

    switch (type)
    {
        case 1:

            pday.first = Read_DATESTR(in, out, "First");
            pday.seclast = Read_DATESTR(in, out, "Seclast");
            pday.last = Read_DATESTR(in, out, "Last");
            pday.is_first = True ;
            pday.snap2   = False ;
            pday.pseq = Read_PAYDAYSEQ(in, out) ;
            break ;

        case 2:

            pday.first = Read_DATESTR(in, out, "First");
            pday.seclast = Read_DATESTR(in, out, "Seclast");
            pday.last = Read_DATESTR(in, out, "Last");
            pday.snap2 = Read_BOOLE(in, out, "Snap2");
            pday.is_first = True ;

            pday.pseq = Read_PAYDAYSEQ(in, out) ;

            fprintf(out, "*Irreg Days:\n") ;
            pday.irreg_days = Read_DATEARRAY(in, out, &pday.nirreg) ;

            break ;

        case 3:

            pday.first = Read_DATESTR(in, out, "First");
            pday.last = Read_DATESTR(in, out, "Last");
            pday.is_first = True ;
            pday.seclast = Cldr_YMD2Datestr((YYYYMMDD) 0) ;
            pday.snap2 = False ;

            freq = Read_PMTFREQ(in, out, "Frequency");
            pday.pseq.term = Cflw_MonthsBetweenPayments(freq) ;
            pday.pseq.unit = MONTHS ;
            pday.pseq.odd1 = Read_ODDCONV(in, out, "Odd First");
            pday.pseq.oddn = Read_ODDCONV(in, out, "Odd Last");
            pday.pseq.eom = Read_EOMCONV(in, out, "End Of Month");
            pday.pseq.seq = Read_SEQCONV(in, out, "Roll");
            break ;

        case 4:

            pday.is_first = Read_BOOLE(in, out, "Is First");
            pday.first = Read_DATESTR(in, out, "First");
            pday.seclast = Read_DATESTR(in, out, "Seclast");
            pday.last = Read_DATESTR(in, out, "Last");
            pday.snap2 = Read_BOOLE(in, out, "Snap2");

            pday.pseq.term = Read_INTI(in, out, "Term");
            pday.pseq.unit = Read_TERMUNIT(in, out, "Unit");
            pday.pseq.odd1 = Read_ODDCONV(in, out, "Odd First");
            pday.pseq.oddn = Read_ODDCONV(in, out, "Odd Last");
            pday.pseq.eom = Read_EOMCONV(in, out, "End Of Month");
            pday.pseq.seq = Read_SEQCONV(in, out, "Roll");

            break ;

        case 5:
            
            /* This case is used for Opt*_CRR2P functions. 
               Only first and last is used. */               
            pday.first = Read_DATESTR(in, out, "   First   ") ;
            pday.last = Read_DATESTR(in, out, "   Last   ") ;
            pday = Set_PAYDAYDEF(True, &pday.first, NULL, 
                                 &pday.last, False, NULL, 0, NULL) ;

            break ;
    }

    Write_VALIDATEError(out, Validate_PAYDAYDEF(&pday, True));

    return pday ;
}


/*
..
*/


DEPOSIT Read_DEPOSIT(FILE* in, FILE* out)
{
    char     txb[25], txc[25], txd[25] ;

    YYYYMMDD ymd, ymd1 ;
    DEPOSIT  depo ;
    COUNT    type ;

    type = Read_FormatId(in, out) ;

    switch (type)
    {
        case 1 :

            fscanf(in, "%ld %ld %lf %lf %s",
                   &ymd, &ymd1, &depo.coupon, &depo.issue_price, txb) ;

            depo.effective = Cldr_YMD2Datestr((YYYYMMDD) ymd) ;
            depo.maturity  = Cldr_YMD2Datestr((YYYYMMDD) ymd1) ;
            depo.cal       = Str2CALCONV(txb) ;

            fprintf(out,"   Deposit:\n") ;
            fprintf(out,"   Effective      %8ld\n", ymd) ;
            fprintf(out,"   Maturity       %8ld\n", ymd1) ;
            fprintf(out,"   Coupon         %8lf\n", depo.coupon) ;
            fprintf(out,"   Issue P.       %8lf\n", depo.issue_price) ;
            fprintf(out,"   Cal            %8s\n", txb) ;

            /* Default */
            depo.freq = NO_FREQUENCY ;
            depo.eom  = SAME ;

            break ;

        case 2:

            fscanf(in, "%ld %ld %s %lf %lf %s %s",
                   &ymd, &ymd1, txb, &depo.coupon,
                   &depo.issue_price, txc, txd) ;

            depo.effective = Cldr_YMD2Datestr((YYYYMMDD) ymd) ;
            depo.maturity  = Cldr_YMD2Datestr((YYYYMMDD) ymd1) ;
            depo.freq      = Str2PMTFREQ(txb) ;
            depo.cal       = Str2CALCONV(txc) ;
            depo.eom       = Str2EOMCONV(txd) ;

            fprintf(out,"   Deposit:\n") ;
            fprintf(out,"   Effective      %8ld\n", ymd) ;
            fprintf(out,"   Maturity       %8ld\n", ymd1) ;
            fprintf(out,"   Frequency      %8s\n", txb) ;
            fprintf(out,"   Coupon         %8lf\n", depo.coupon) ;
            fprintf(out,"   Issue P.       %8lf\n", depo.issue_price) ;
            fprintf(out,"   Cal            %8s\n", txc) ;
            fprintf(out,"   Eom            %8s\n", txd) ;

            break ;
    }
    Write_VALIDATEError(out, Validate_DEPOSIT(&depo));

    return depo ;
}

/*
..
*/


CFLWARRAY Read_CFLWARRAY(FILE* in, FILE* out)
{
    CFLWARRAY cflw ;
    INTI      n, i ;
    int       i1 ;
    INTL      ymd ;
    COUNT     type ;

    type = Read_FormatId(in, out) ;

    fscanf(in, "%d", &i1) ;
    n = (INTI) i1 ;

    /* Allocate */
    cflw = Alloc_CFLWARRAY(1, n) ;
    cflw->filled = n ;
    cflw->count = n ;

    /* Read data */
    fprintf(out,"   CFLW is...\n") ;

    if (type == 1)
    {
        fprintf(out,"   Date       Repay    Coupon\n") ;
        for (i = 0 ; i < n ; i++)
        {
            fscanf(in,"%ld %lf %lf",
                   &ymd, &cflw->repay[i], &cflw->coupon[i]) ;
            cflw->days[i] = Cldr_YMD2Datestr(ymd) ;
            fprintf(out,"   %8ld %10.5lf %10.5lf\n",
                    ymd, cflw->repay[i], cflw->coupon[i]) ;
        }
    }
    else if (type == 2)
    {
        fprintf(out,"   Date       Coupon     Repay\n") ;
        for (i = 0 ; i < n ; i++)
        {
            fscanf(in,"%ld %lf %lf",
                   &ymd, &cflw->coupon[i], &cflw->repay[i]) ;
            cflw->days[i] = Cldr_YMD2Datestr(ymd) ;
            fprintf(out,"   %8ld %10.5lf %10.5lf\n",
                    ymd, cflw->coupon[i], cflw->repay[i]) ;
        }
    }

    return cflw ;
}


/*
..
*/

FIXPAY Read_FIXPAY(FILE* in, FILE* out, DATESTR* settle)
{
    DATESTR  end, first, eff ;
    FL64     coupon ;
    FIXPAY   fixp ;
    EOMCONV  eom ;
    CALCONV  cal;
    BONDTYPE btype;
    PMTFREQ  freq;
    COUNT    type ;
    BONDBM   bondbm;
    YTMSEG   yseg;
   
    EXRULE   xc, xp ;

    fprintf(out,"   Bond Data:\n") ;
    type = Read_FormatId(in, out) ;

    xp = Set_EXRULE(EX_DAYS, 0, True, EU30E360, NULL, 0, NULL, NULL, True) ;
    xc = Set_EXRULE(EX_DAYS, 0, True, EU30E360, NULL, 0, NULL, NULL, True) ;

    switch (type)
    {
        case 1:

            coupon = Read_FL64(in, out, "    Coupon    ");
            end = Read_DATESTR(in, out, "    Maturity  ");
            freq = Read_PMTFREQ(in, out, "    Frequency ");
            cal = Read_CALCONV(in, out, "    Daycount  ");

            fixp = Bond_Simple2FIXPAY(settle, settle, &end, coupon,
                                      freq, BULLET, NULL, NULL, cal, LAST) ;
            break ;

        case 2:

            end = Read_DATESTR(in, out, "    Maturity  ");
            coupon = Read_FL64(in, out, "    Coupon    ");
            freq = Read_PMTFREQ(in, out, "    Frequency ");
            btype = Read_BONDTYPE(in, out, "    Bondtype  ");
            cal = Read_CALCONV(in, out, "    Daycount  ");

            fixp = Bond_Simple2FIXPAY(settle, settle, &end, coupon,
                                      freq, btype, NULL, NULL, cal, LAST) ;
            break ;

        case 3:

            end = Read_DATESTR(in, out, "    Maturity  ");
            coupon = Read_FL64(in, out, "    Coupon    ");
            freq = Read_PMTFREQ(in, out, "    Frequency ");

            fixp = Bond_Simple2FIXPAY(settle, settle, &end, coupon,
                                      freq, BULLET, NULL, NULL, EU30E360, LAST);
            break ;

        case 4:

            fixp.cday  = Read_PAYDAYDEF(in, out) ;
            fixp.fix   = Read_FIXRATE(in, out) ;
            fixp.rday  = Read_PAYDAYDEF(in, out) ;
            fixp.repay = Read_REPAYMNT(in, out) ;
            fixp.accru = Read_ACCRUINT(in, out) ;
            fixp.exp   = Read_EXRULE(in, out) ;
            fixp.tax   = Read_TAXINFO(in, out) ;

            break ;

        case 5:

            end = Read_DATESTR(in, out, "    Maturity  ");
            coupon = Read_FL64(in, out, "    Coupon    ");
            freq = Read_PMTFREQ(in, out, "    Frequency ");
            btype = Read_BONDTYPE(in, out, "    Bondtype  ");
            xc.exdays = Read_INTI(in, out, "    ExCoup    ");
            xp.exdays = Read_INTI(in, out, "    ExPrinc   ");
            xc.cal = cal = Read_CALCONV(in, out, "    Daycount  ");

            fixp = Bond_Simple2FIXPAY(settle, settle, &end, coupon,
                                      freq, btype, &xc, &xp, cal, LAST) ;

            break ;

        case 6:
        case 7:

            end = Read_DATESTR(in, out, "    Maturity  ");
            coupon = Read_FL64(in, out, "    Coupon    ");
            freq = Read_PMTFREQ(in, out, "    Frequency ");
            btype = Read_BONDTYPE(in, out, "    Bondtype  ");
            cal   = Read_CALCONV(in, out, "    Daycount  ");

            if (type == 6)
                eom = LAST ;
            else
                eom = Read_EOMCONV(in, out, "   EOM         ");

            fixp = Bond_Simple2FIXPAY(settle, settle, &end, coupon,
                                  freq, btype, NULL, NULL, cal, eom) ;

            fixp.accru.cb_accru = Read_COUPONBASE(in, out, "   Odd AI      ");
            fixp.accru.incl = Read_BOOLE(in, out, "   Incl        ");
            fixp.tax = Read_TAXINFO(in, out) ;
            break ;

        case 8:

            end = Read_DATESTR(in, out, "    Maturity  ");
            coupon = Read_FL64(in, out, "    Coupon    ");
            freq = Read_PMTFREQ(in, out, "    Frequency ");
            btype = Read_BONDTYPE(in, out, "    Bondtype  ");
            xc.exdays = Read_INTI(in, out, "    ExCoup    ");
            xp.exdays = Read_INTI(in, out, "    ExPrinc   ");
            xc.cal = xp.cal = cal = Read_CALCONV(in, out, "   Daycount  ") ;
            fixp = Bond_Simple2FIXPAY(settle, settle, &end, coupon,
                                 freq, btype, &xc, &xp, cal, LAST) ;

            first = Read_DATESTR(in, out, "  First Coupon/Redem  ");
            eff = Read_DATESTR(in, out, "  Effective           ");
            fixp.cday.first = fixp.rday.first = first ;
            fixp.fix.effective = eff ;

            break ;

        case 9:

            end = Read_DATESTR(in, out, "    Maturity  ");
            coupon = Read_FL64(in, out, "    Coupon    ");
            freq = Read_PMTFREQ(in, out, "    Frequency ");
            btype = Read_BONDTYPE(in, out, "    Bondtype  ");
            cal = Read_CALCONV(in, out, "    Daycount  ");

            fixp = Bond_Simple2FIXPAY(settle, settle, &end, coupon,
                                      freq, btype, NULL, NULL, cal, LAST) ;

            fixp.repay.irreg = Read_PLANARRAY(in) ;
            Write_PLANARRAY(out, fixp.repay.irreg) ;

            break ;

        case 10:

            end = Read_DATESTR(in, out, "    Maturity  ");
            coupon = Read_FL64(in, out, "    Coupon    ");
            freq = Read_PMTFREQ(in, out, "    Frequency ");

            fixp = Bond_Simple2FIXPAY(settle, settle, &end, coupon, freq, 
                                      BULLET, NULL, NULL, EU30E360, LAST) ;

            /* Read coupon plan  */
            fprintf(out, "    Stepped coupons:\n");
            fixp.fix.stepcoup = Read_PLANARRAY(in);
            Write_PLANARRAY(out, fixp.fix.stepcoup);

            break ;

        case 11:

            end    = Read_DATESTR(in, out, "    Maturity  ");
            coupon = Read_FL64(in, out, "    Coupon    ");
            freq   = Read_PMTFREQ(in, out, "    Frequency ");
            btype  = Read_BONDTYPE(in, out, "    Bondtype  ");
            cal    = Read_CALCONV(in, out, "    Daycount  ");
            eom    = Read_EOMCONV(in, out, "   EOM         ");
            fixp = Bond_Simple2FIXPAY(settle, settle, &end, coupon,
                                      freq, btype, NULL, NULL, cal, eom) ;

            fixp.accru.cb_accru = Read_COUPONBASE(in, out, "   Odd AI      ");
            fixp.accru.incl = Read_BOOLE(in, out, "   Incl        ");
            eff = Read_DATESTR(in, out, "  Effective           ");
            fixp.cday.first    = eff ;
            fixp.rday.first    = eff ;
            fixp.fix.effective = eff ;
            fixp.tax = Read_TAXINFO(in, out) ;
            
            break ;

        case 12:

            /* This case is almost identical with case 5 */  
            end = Read_DATESTR(in, out, "    Maturity  ");
            coupon = Read_FL64(in, out, "    Coupon    ");
            freq = Read_PMTFREQ(in, out, "    Frequency ");
            btype = Read_BONDTYPE(in, out, "    Bondtype  ");
            xc.exdays = Read_INTI(in, out, "    ExCoup    ");
            xp.exdays = Read_INTI(in, out, "    ExPrinc   ");
            xc.cal = cal = Read_CALCONV(in, out, "    Daycount  ");

            fixp = Bond_Simple2FIXPAY(settle, settle, &end, coupon,
                                      freq, btype, &xc, &xp, cal, LAST) ;

            /* Irregular amortisations */
            fixp.repay.irreg = Read_PLANARRAY(in) ;
            Write_PLANARRAY(out, fixp.repay.irreg) ;

            break ;
        case 13:
            bondbm = Read_BONDBM(in, out);
            yseg = Read_YTMSEG(in, out, "BondBM yield seg  ");
            fixp = BondBM_BONDBM2FIXPAY(settle, &bondbm, yseg);
            break;
    }

    Write_VALIDATEError(out, Validate_FIXPAY(&fixp, False));
  
    return fixp ;
}


/*
..
*/

REPAYMNT Read_REPAYMNT(FILE* in, FILE* out)
{
    REPAYMNT repay ;
    COUNT     type ;

    fprintf(out, "   REPAYMNT:\n") ;

    type = Read_FormatId(in, out) ;

    switch (type)
    {
        case 1:
        case 2:

            repay.type = Read_BONDTYPE(in, out, "Type");
            repay.teomatur = Read_DATESTR(in, out, "TeoMatur");

            repay.io = Read_BOOLE(in, out, "IO");
            repay.init_exch = Read_FL64(in, out, "InitExch");

            repay.pp.pp_price = Read_FL64(in, out, "PP Price");

            repay.pp.ppmts = Read_PLANARRAY(in) ;
            fprintf(out,"   PP's:\n") ;
            Write_PLANARRAY(out, repay.pp.ppmts) ;

            repay.irreg = Read_PLANARRAY(in) ;
            fprintf(out,"   Irreg's:\n") ;
            Write_PLANARRAY(out, repay.irreg) ;

            repay.aufab = Read_PLANARRAY(in) ;
            fprintf(out,"   AufAb's:\n") ;
            Write_PLANARRAY(out, repay.aufab) ;

            if (type == 2)
            {
                repay.rpct = Read_FL64(in, out, "RPct");
                repay.rpct_first = Read_FL64(in, out, "RPct First");
            }
            else
                repay.rpct = repay.rpct_first = 0.0 ;

            break ;

        case 3:

            repay.type = Read_BONDTYPE(in, out, "Type");
            repay.teomatur = Read_DATESTR(in, out, "TeoMatur");

            repay.io = False ;
            repay.init_exch = 0.0 ;
            repay.pp.pp_price = 100.0 ;
            repay.pp.ppmts = repay.irreg = repay.aufab = NULL ;
            repay.rpct = repay.rpct_first = 0.0 ;

            break ;
    }

    Write_VALIDATEError(out, 
        Validate_REPAYMNT(&repay, &repay.teomatur, False, False));

    return repay ;
}

/*
..
*/

PAYDAYSEQ Read_PAYDAYSEQ(FILE* in, FILE* out)
{
    PAYDAYSEQ pseq ;
    int       i1 ;
    char      txb[20], txc[20], txd[20] ;

    fscanf(in, "%s %s %s", txb, txc, txd) ;
    pseq.odd1 = Str2ODDCONV(txb) ;
    pseq.oddn = Str2ODDCONV(txc) ;
    pseq.seq  = Str2SEQCONV(txd) ;

    fprintf(out, "   Odd1           %s\n", txb) ;
    fprintf(out, "   OddN           %s\n", txc) ;
    fprintf(out, "   Seq.           %s\n", txd) ;

    fscanf(in, "%d %s %s", &i1, txb, txc) ;

    pseq.term = (INTI) i1 ;
    pseq.unit = Str2TERMUNIT(txb) ;
    pseq.eom  = Str2EOMCONV(txc) ;

    fprintf(out, "   Term           %d\n", i1) ;
    fprintf(out, "   Unit           %s\n", txb) ;
    fprintf(out, "   Eom            %s\n", txc) ;

    Write_VALIDATEError(out, Validate_PAYDAYSEQ(&pseq));


    return pseq ;
}

/*
..
*/


FIXRATE Read_FIXRATE(FILE* in, FILE* out)
{
    FIXRATE  fix ;
    COUNT type;

    fprintf(out, "   FIXRATE:\n") ;
    type = Read_FormatId(in, out) ;

    switch (type)
    {
        case 1:
            fix.fix_rate = Read_FL64(in, out, "Fixrate");
            fix.cal = Read_CALCONV(in, out, "Day count");
            fix.effective = Read_DATESTR(in, out, "Effective");

            fix.lastaccr = Read_DATESTR(in, out, "LastAccrDate");
            fix.accrfac = Read_FL64(in, out, "AccrFactor");
            fix.cbase = Read_COUPONBASE(in, out, "CouponBase");

            fix.cbodd = Read_COUPONBASE(in, out, "CouponBase ODD");

            fix.prepaid = Read_BOOLE(in, out, "Prepaid ? ");

            fix.jgb = Read_BOOLE(in, out, "JGB ? ");

            fix.stepcoup = Read_PLANARRAY(in) ;
            fprintf(out, "* Stepped Coupon:\n") ;
            Write_PLANARRAY(out, fix.stepcoup) ;

            fix.holpre = Read_BOOLE(in, out, "Hol. Pre ? ");

            fix.irreg = NULL ;
            fix.decomp = NODCOMP ;
    
            break ;

        case 2:
            fix.fix_rate = Read_FL64(in, out, "Fixrate");
            fix.cal = Read_CALCONV(in, out, "Day count");
            fix.effective = Read_DATESTR(in, out, "Effective");

            fix.lastaccr = Read_DATESTR(in, out, "LastAccrDate");
            fix.accrfac = Read_FL64(in, out, "AccrFactor");
            fix.cbase = Read_COUPONBASE(in, out, "CouponBase");

            fix.cbodd = Read_COUPONBASE(in, out, "CouponBase ODD");

            fix.prepaid = Read_BOOLE(in, out, "Prepaid ? ");

            fix.jgb = Read_BOOLE(in, out, "JGB ? ");

            fix.stepcoup = Read_PLANARRAY(in) ;
            fprintf(out,"* Stepped Coupon:\n") ;
            Write_PLANARRAY(out, fix.stepcoup) ;

            fix.holpre = Read_BOOLE(in, out, "Hol. Pre ? ");

            fix.irreg = Read_PLANARRAY(in) ;
            fprintf(out,"* Irregular Coupon:\n") ;
            Write_PLANARRAY(out, fix.irreg) ;

            fix.decomp = NODCOMP ;
    
            break ;

        case 3:
            fix.fix_rate = Read_FL64(in, out, "Fixrate");
            fix.cal = Read_CALCONV(in, out, "Day count");
            fix.effective = Read_DATESTR(in, out, "Effective");

            fix.cbase = fix.cbodd = 
                Read_COUPONBASE(in, out, "CouponBase");

            fix.lastaccr = Cldr_YMD2Datestr((YYYYMMDD) 0) ;
            fix.accrfac  = 0.0 ;
            fix.prepaid  = False ;
            fix.jgb      = False ;
            fix.stepcoup = NULL ;
            fix.holpre   = False ;
            fix.irreg    = NULL ;

            fix.decomp = Read_FIXDCOMP(in, out, "Decomp");
            break ;
    }

    Write_VALIDATEError(out, Validate_FIXRATE(&fix));

    return fix ;
}

/*
..
*/


ACCRUINT Read_ACCRUINT(FILE* in, FILE* out)
{
    ACCRUINT accru ;
    char      txb[20] ;
    int       i1 ;

    fprintf(out, "   ACCRUINT:\n") ;

    fscanf(in, "%s", txb) ;
    accru.cal = Str2CALCONV(txb) ;
    fprintf(out, "   Accru Calendar %8s\n", txb) ;

    fscanf(in, "%s", txb) ;
    accru.cb_accru = Str2COUPONBASE(txb) ;
    fprintf(out, "   CBASE Accru.   %8s\n", txb) ;

    fscanf(in, "%s", txb) ;
    accru.cbodd_accru = Str2COUPONBASE(txb) ;
    fprintf(out, "   Cb Odd Accru.  %8s\n", txb) ;

    fscanf(in, "%s", txb) ;
    accru.incl = Str2BOOLE(txb) ;
    fprintf(out, "   INCL.          %8s\n", txb) ;

    fscanf(in, "%s", txb) ;
    accru.pre = Str2BOOLE(txb) ;
    fprintf(out, "   PRE.           %8s\n", txb) ;

    fscanf(in, "%s", txb) ;
    accru.irr = Str2IRRCONV(txb) ;
    fprintf(out, "   IrrConv        %8s\n", txb) ;

    fscanf(in, "%d", &i1) ;
    accru.qbas = (INTI) i1 ;
    fprintf(out, "   Qbas           %8d\n", i1) ;

    fscanf(in, "%s", txb) ;
    accru.schuldsch = Str2BOOLE(txb) ;
    fprintf(out, "   SchuldSch.     %8s\n", txb) ;

    fscanf(in, "%s", txb) ;
    accru.CGB184 = Str2BOOLE(txb) ;
    fprintf(out, "   CGB184         %8s\n", txb) ;

    fscanf(in, "%s", txb) ;
    accru.BRDfeb = Str2BOOLE(txb) ;
    fprintf(out, "   BRDfeb         %8s\n", txb) ;

    accru.exr = Read_EXRULE(in, out) ;

    Write_VALIDATEError(out, Validate_ACCRUINT(&accru));


    return accru ;
}

/*
..
*/


EXRULE Read_EXRULE(FILE* in, FILE* out)
{
    EXRULE   exr ;
    YYYYMMDD ymd ;
    char     txb[20] ;
    int      i1 ;
    INTI     dum ;
    COUNT type;

    fprintf(out, "   EXRULE:\n") ;

    type = Read_FormatId(in, out) ;

    fscanf(in, "%s", txb) ;
    exr.xconv = Str2EXDAYCONV(txb) ;
    fprintf(out, "   ExDayConv      %8s\n", txb) ;

    fscanf(in, "%d", &i1) ;
    exr.exdays = (INTI) i1 ;
    fprintf(out, "   Exdays         %8d\n", i1) ;

    fscanf(in, "%s", txb) ;
    exr.caldays = Str2BOOLE(txb) ;
    fprintf(out, "   CalDays ?      %8s\n", txb) ;

    fscanf(in, "%s", txb) ;
    exr.cal = Str2CALCONV(txb) ;
    fprintf(out, "   X Calendar     %8s\n", txb) ;

    fscanf(in, "%ld", &ymd) ;
    exr.dex = Cldr_YMD2Datestr((YYYYMMDD) ymd) ;
    fprintf(out, "   DateEx         %8ld\n", ymd) ;

    exr.pday  = Read_DATEARRAY(in, out, &exr.npday) ;
    exr.xpday = Read_DATEARRAY(in, out, &dum) ;

    if (type == 1)
        exr.xlast = False ;
    else if (type == 2)
    {
        fscanf(in, "%s", txb) ;
        exr.xlast = Str2BOOLE(txb) ;
        fprintf(out, "   Xlast ?        %8s\n", txb) ;
    }

    Write_VALIDATEError(out, Validate_EXRULE(&exr));

    return exr ;
}


/*
..
*/

TAXINFO Read_TAXINFO(FILE* in, FILE* out)
{
    TAXINFO tax ;
    COUNT type;

    fprintf(out, "   FIXRATE:\n") ;
    type = Read_FormatId(in, out) ;
    
    switch (type)
    {
        case 1:
            tax.tax_c  = Read_FL64(in, out, "   Tax_c       ");
            tax.tax_cg = Read_FL64(in, out, "   Tax_cg      ");
            tax.bp_tax = Read_FL64(in, out, "   BP Tax      ");
            tax.pro_rata = False ;
            break ;

        case 2 :
            tax.bp_tax = Read_FL64(in, out, "   BP Tax      ");
            tax.tax_c  = Read_FL64(in, out, "   Tax_c       ");
            tax.tax_cg = Read_FL64(in, out, "   Tax_cg      ");
            tax.pro_rata = False ;
            break ;

        case 3 :
            tax.bp_tax = Read_FL64(in, out, "   BP Tax      ");
            tax.tax_c  = Read_FL64(in, out, "   Tax_c       ");
            tax.tax_cg = Read_FL64(in, out, "   Tax_cg      ");
            tax.pro_rata = Read_BOOLE(in, out, "   Pro Rata ?  ");
            break ;
    }

    Write_VALIDATEError(out, Validate_TAXINFO(&tax));

    return tax ;
}


/*
..
*/

TRADEINFO Read_TRADEINFO(FILE* in, FILE* out)
{
    TRADEINFO tr ;
    YYYYMMDD  ymd ;
    char      txb[15] ;
    COUNT    type;

    fprintf(out,"   TRADEINFO:\n") ;

    type = Read_FormatId(in, out);

    switch (type)
    {
        case 1:

            fscanf(in, "%ld", &ymd) ;
            tr.trade = Cldr_YMD2Datestr((YYYYMMDD) ymd) ;
            fprintf(out,"   Trade       %8ld\n", ymd) ;

            fscanf(in, "%ld", &ymd) ;
            tr.aisttl = Cldr_YMD2Datestr((YYYYMMDD) ymd) ;
            fprintf(out,"   AISettle    %8ld\n", ymd) ;

            fscanf(in, "%ld", &ymd) ;
            tr.settle = Cldr_YMD2Datestr((YYYYMMDD) ymd) ;
            fprintf(out,"   Settle      %8ld\n", ymd) ;

            fscanf(in, "%s", txb) ;
            tr.brd = Str2BOOLE(txb) ;
            fprintf(out,"   BRD?        %8s\n", txb) ;

            fscanf(in, "%lf", &tr.price) ;
            fprintf(out,"   Price       %8lf\n", tr.price) ;

            fscanf(in, "%lf", &tr.nom) ;
            fprintf(out,"   Nominal     %8lf\n", tr.nom) ;

            tr.xctrade = Read_EXTRADE(in, out) ;
            tr.xptrade = Read_EXTRADE(in, out) ;

            break ;

        case 2:

            fscanf(in, "%ld", &ymd) ;
            tr.settle = Cldr_YMD2Datestr((YYYYMMDD) ymd) ;
            fprintf(out,"   Settle      %8ld\n", ymd) ;

            tr.brd   = False ;
            tr.price = 0.0 ;
            tr.nom   = 100.0 ;

            tr.xctrade = Read_EXTRADE(in, out) ;
            tr.xptrade = Read_EXTRADE(in, out) ;

            break ;

        case 3:

            fscanf(in, "%lf %ld", &tr.price, &ymd) ;
            tr.settle = Cldr_YMD2Datestr((YYYYMMDD) ymd) ;
            fprintf(out,"   Price       %8lf\n", tr.price) ;
            fprintf(out,"   Settle      %8ld\n", ymd) ;

            tr.brd   = False ;
            tr.nom   = 100.0 ;

            tr.xctrade = Read_EXTRADE(in, out) ;
            tr.xptrade = Read_EXTRADE(in, out) ;

            break ;

        case 4:

            fscanf(in, "%ld", &ymd) ;
            tr.trade = tr.settle = tr.aisttl = Cldr_YMD2Datestr((YYYYMMDD) ymd);
            fprintf(out,"   Trade       %8ld\n", ymd) ;

            tr.brd = False ;

            fscanf(in, "%lf", &tr.price) ;
            fprintf(out,"   Price       %8lf\n", tr.price) ;

            fscanf(in, "%lf", &tr.nom) ;
            fprintf(out,"   Nominal     %8lf\n", tr.nom) ;

            tr.xctrade = Read_EXTRADE(in, out) ;
            tr.xptrade = Read_EXTRADE(in, out) ;

            break ;
    }

    Write_VALIDATEError(out, Validate_TRADEINFO(&tr));

    return tr ;
}


/*
..
*/

EXTRADE Read_EXTRADE(FILE* in, FILE* out)
{
    EXTRADE xt ;
    char    txb[15] ;
    COUNT type;

    /* warning avoidance */
    memset(&xt, 0, sizeof(xt));

    fprintf(out,"   EXTRADE:\n") ;
    type = Read_FormatId(in, out);

    switch (type)
    {
        case 1:

            fscanf(in, "%s", txb) ;
            xt.spec = Str2BOOLE(txb) ;
            fprintf(out,"   Spec?       %8s\n", txb) ;

            fscanf(in, "%s", txb) ;
            xt.ex_fix = Str2BOOLE(txb) ;
            fprintf(out,"   Ex Fix ?    %8s\n", txb) ;
            break ;

        case 2:

            xt.spec = True ;

            fscanf(in, "%s", txb) ;
            xt.ex_fix = Str2BOOLE(txb) ;
            fprintf(out,"   Ex Fix ?    %8s\n", txb) ;
            break ;

        case 3:

            xt.spec   = False ;
            xt.ex_fix = False ;

            break ;


    }

    return xt ;
}


/*
..
*/

SWAPFIX Read_SWAPFIX(FILE* in, FILE* out)
{
    SWAPFIX     sfix ;
    int         i1, i2, i6 ;
    char        txb[25], txc[25], txd[25], txe[25], txm[25], txi[25], 
                txf[25], txq[25] ;
    INTI        i, na, ns, delay ;
    FL64        ie, fix_rate ;
    PLANARRAY   stepcoup, irreg ;
    EOMCONV     eom ;
    CALCONV     cal ;
    SEQCONV     per ;
    PMTFREQ     freq ;
    BOOLE       io, init_exch ;
    YYYYMMDD    ymd, effect, first, matur ;
    DATESTR     deffect, dfirst, dmatur ;
    COUPONBASE  cbase ;
    PAYDAYDEF   pday ;
    FIXRATE     fixr ;
    REPAYMNT    redemp ;
    PAYDAYSEQ   pseq ;
    FIXRATE     fix ;
    COUNT       type ;

    type = Read_FormatId(in, out);

    switch (type)
    {
        case 1:

            sfix.repay = Read_REPAYMNT(in, out) ;
            sfix.rday  = Read_PAYDAYDEF(in, out) ;
            sfix.fix   = Read_FIXRATE(in, out) ;
            sfix.pday  = Read_PAYDAYDEF(in, out) ;

            sfix.delay = Read_INTI(in, out, "Delay") ;
            break ;
        case 2:
            fscanf(in, "%ld %ld %ld %s %s %s %s %s %lf %d %s %s",
                   &effect, &first, &matur, txb, txc, txd, txm,
                   txi, &fix_rate, &i1, txe, txf) ;

            delay = (INTI) i1 ;

            freq = Str2PMTFREQ(txb) ;
            eom  = Str2EOMCONV(txc) ;
            cal  = Str2CALCONV(txd) ;
            per  = Str2SEQCONV(txm) ;
            cbase = Str2COUPONBASE(txi) ;
            init_exch = Str2BOOLE(txe) ;
            io = Str2BOOLE(txf) ;
            deffect = Cldr_YMD2Datestr(effect) ;
            dfirst = Cldr_YMD2Datestr(first) ;
            dmatur = Cldr_YMD2Datestr(matur) ;

            fprintf(out,"   effective day      %8ld\n", effect) ;
            fprintf(out,"   first payday       %8ld\n", first) ;
            fprintf(out,"   maturity           %8ld\n", matur) ;
            fprintf(out,"   pay frequency      %8s\n", txb) ;
            fprintf(out,"   eomconv            %8s\n", txc) ;
            fprintf(out,"   calendar           %8s\n", txd) ;
            fprintf(out,"   per.conv           %8s\n", txm) ;
            fprintf(out,"   coupon basis       %8s\n", txi) ;
            fprintf(out,"   fix rate           %3.4lf\n", fix_rate) ;
            fprintf(out,"   delay              %8d\n", delay) ;
            fprintf(out,"   initial exchange ? %8s\n", txe) ;
            fprintf(out,"   interest only ??   %8s\n", txf) ;

            stepcoup = Read_PLANARRAY(in) ;
            fprintf(out,"   Stepped Coupon:\n") ;
            Write_PLANARRAY(out, stepcoup) ;

            irreg = Read_PLANARRAY(in) ;
            fprintf(out,"   Irreg's:\n") ;
            Write_PLANARRAY(out, irreg) ;

            pseq.term = Cflw_MonthsBetweenPayments(freq) ;
            pseq.unit = MONTHS ;
            pseq.odd1 = NOODD ;
            pseq.oddn = NOODD ;
            pseq.eom  = eom ;
            pseq.seq  = per ;

            pday = Set_PAYDAYDEF(True, &dfirst, NULL, &dmatur,
                                 False, &pseq, 0, NULL) ;
            fixr = Set_FIXRATE(fix_rate, cal, &deffect, NULL, 0.0,
                               cbase, cbase, False, False, stepcoup, True,
                               NULL, NODCOMP) ;

            ie     = (init_exch == True ? 100.0 : 0.0) ;
            redemp = Set_REPAYMNT(NONREGULAR, NULL, io, ie, NULL,
                                  irreg, NULL, 0.0, 0.0) ;
            sfix   = Set_SWAPFIX(&redemp, &pday, &fixr, &pday, delay) ;

            break ;

        case 3:

            fscanf(in, "%ld %ld %ld %s %s %s %s %s %lf %d %s %s %s %d %d",
                   &effect, &first, &matur, txb, txc, txd, txm, txi, &fix_rate,
                   &i1, txe, txf, txq, &i2, &i6) ;
            delay = (INTI) i1 ;
            na    = (INTI) i2 ;
            ns    = (INTI) i6 ;

            freq = Str2PMTFREQ(txb) ;
            eom  = Str2EOMCONV(txc) ;
            cal  = Str2CALCONV(txd) ;
            per  = Str2SEQCONV(txm) ;
            cbase = Str2COUPONBASE(txi) ;
            init_exch = Str2BOOLE(txe) ;
            io = Str2BOOLE(txf) ;

            deffect = Cldr_YMD2Datestr(effect) ;
            dfirst  = Cldr_YMD2Datestr(first) ;
            dmatur  = Cldr_YMD2Datestr(matur) ;

            pseq = Set_PAYDAYSEQ(Cflw_MonthsBetweenPayments(freq), 
                                 MONTHS, NOODD, NOODD, per, eom) ;
            pday = Set_PAYDAYDEF(True, &dfirst, NULL, &dmatur,
                                 False, &pseq, 0, NULL) ;

            fprintf(out,"   effective day      %8ld\n", effect) ;
            fprintf(out,"   first payday       %8ld\n", first) ;
            fprintf(out,"   maturity           %8ld\n", matur) ;
            fprintf(out,"   pay frequency      %8s\n", txb) ;
            fprintf(out,"   eomconv            %8s\n", txc) ;
            fprintf(out,"   calendar           %8s\n", txd) ;
            fprintf(out,"   per.conv           %8s\n", txm) ;
            fprintf(out,"   coupon basis       %8s\n", txi) ;
            fprintf(out,"   fix rate           %3.4lf\n", fix_rate) ;
            fprintf(out,"   delay              %8d\n", delay) ;
            fprintf(out,"   initial exchange ? %8s\n", txe) ;
            fprintf(out,"   interest only ??   %8s\n", txf) ;

            irreg = Alloc_PLANARRAY(1, na) ;
            irreg->filled = na ;
            fprintf(out,"   the amort schedule is...\n") ;
            fprintf(out,"       date  repayment\n") ;

            for (i = 0 ; i < na ; i++)
            {
                fscanf(in, "%ld %lf", &ymd, &irreg->f64[i]) ;
                irreg->day[i] = Cldr_YMD2Datestr(ymd) ;
                fprintf(out,"   %8ld %9.5lf\n", ymd, irreg->f64[i]) ;
            }

            stepcoup = Alloc_PLANARRAY(1, ns) ;
            stepcoup->filled = ns ;
            fprintf(out,"   the stepped coupon schedule is...\n") ;
            fprintf(out,"       date  coupon\n") ;

            for (i = 0 ; i < ns ; i++)
            {
                fscanf(in, "%ld %lf", &ymd, &stepcoup->f64[i]) ;
                stepcoup->day[i] = Cldr_YMD2Datestr(ymd) ;
                fprintf(out,"   %8ld %9.5lf\n", ymd, stepcoup->f64[i]) ;
            }

            fix    = Set_FIXRATE(fix_rate, cal, &deffect, NULL, 0.0, cbase,
                                 cbase, False, False, stepcoup, True, NULL,
                                 Str2FIXDCOMP(txq)) ;

            ie     = (init_exch == True ? 100.0 : 0.0) ;
            redemp = Set_REPAYMNT(NONREGULAR, NULL, io, ie, NULL,
                                  irreg, NULL, 0.0, 0.0) ;
            sfix   = Set_SWAPFIX(&redemp, &pday, &fix, &pday, delay) ;

            break ;
    }

    Write_VALIDATEError(out, Validate_SWAPFIX(&sfix));

    return sfix ;
}

/*
..
*/

HZYCONV Read_HZYCONV(FILE* in, FILE* out)
{
    HZYCONV hzyc ;
    INTI    type ;

    fprintf(out, "   HZYCONV:\n") ;
    type = Read_FormatId(in, out);

    switch (type)
    {
        case 1:

            hzyc.reinv = Read_BOOLE(in, out, "   ReInvest ?     ") ;
            hzyc.hzp   = Read_BOOLE(in, out, "   HorizonPrice ? ") ;
            hzyc.ytmc  = Read_YTMCONV(in, out) ;
            break ;
    }

    Write_VALIDATEError(out, Validate_HZYCONV(&hzyc));

    return hzyc ;
}

/*
..
*/


PREPAYCONV Read_PREPAYCONV(FILE* in, FILE* out, TEXT dscr)
{
    PREPAYCONV prepayc;
    CH txb[MAX_KEYWORD_LENGTH];

      /* Comments, if any: */
    if (!IOUtil_ReadComment(in, out))
        Write_Comment(out, dscr);

    Read_TEXT(in, MAX_KEYWORD_LENGTH, txb);
    prepayc = Str2PREPAYCONV(txb);

    fprintf(out, " %s\n", txb);

    return prepayc;
}

/*
..
*/

YTMCONV Read_YTMCONV(FILE* in, FILE* out)
{
    YTMCONV ytmc ;
    INTI    type ;

    fprintf(out, "   YTMCONV:\n") ;
    type = Read_FormatId(in, out);

    switch (type)
    {
        case 1:
            ytmc.irr    = Read_IRRCONV(in, out, "   IRR        ") ;
            ytmc.qb_ytm = Read_PMTFREQ(in, out, "   qbas       ") ;
            ytmc.dayfrac_first  = Read_BOOLE(in, out, "   df first   ") ;
            ytmc.dayfrac_normal = Read_BOOLE(in, out, "   df normal  ") ;
            ytmc.dayfrac_last   = Read_BOOLE(in, out, "   df last    ") ;
            ytmc.cal_first      = Read_CALCONV(in, out, "   cal first  ") ;
            ytmc.cal_normal     = Read_CALCONV(in, out, "   cal normal ") ;
            ytmc.cal_last       = Read_CALCONV(in, out, "   cal last   ") ;
            ytmc.trueYTM        = False ;
            ytmc.as_bullet        = False ;
            break ;

        case 2:
            ytmc.irr    = Read_IRRCONV(in, out, "   IRR        ") ;
            ytmc.qb_ytm = Read_PMTFREQ(in, out, "   qbas       ") ;
            ytmc.dayfrac_first  = Read_BOOLE(in, out, "   df first   ") ;
            ytmc.dayfrac_normal = Read_BOOLE(in, out, "   df normal  ") ;
            ytmc.dayfrac_last   = Read_BOOLE(in, out, "   df last    ") ;
            ytmc.cal_first      = Read_CALCONV(in, out, "   cal first  ") ;
            ytmc.cal_normal     = Read_CALCONV(in, out, "   cal normal ") ;
            ytmc.cal_last       = Read_CALCONV(in, out, "   cal last   ") ;
            ytmc.trueYTM        = Read_BOOLE(in, out, "   True YTM   ") ; ;
            ytmc.as_bullet        = False ;
            break ;

        case 3:
            ytmc.irr    = Read_IRRCONV(in, out, "   IRR        ") ;
            ytmc.qb_ytm = Read_PMTFREQ(in, out, "   qbas       ") ;
            ytmc.dayfrac_first  = Read_BOOLE(in, out, "   df first   ") ;
            ytmc.dayfrac_normal = Read_BOOLE(in, out, "   df normal  ") ;
            ytmc.dayfrac_last   = Read_BOOLE(in, out, "   df last    ") ;
            ytmc.cal_first      = Read_CALCONV(in, out, "   cal first  ") ;
            ytmc.cal_normal     = Read_CALCONV(in, out, "   cal normal ") ;
            ytmc.cal_last       = Read_CALCONV(in, out, "   cal last   ") ;
            ytmc.trueYTM        = Read_BOOLE(in, out, "   True YTM   ") ; ;
            ytmc.as_bullet      = Read_BOOLE(in, out, "   as_bullet ") ; ;
            break ;
    }

    Write_VALIDATEError(out, Validate_YTMCONV(&ytmc));

    return ytmc ;
}


/*
..
*/

PP_STR Read_PP_STR(FILE* in, FILE* out)
{
    PP_STR pp ;
    COUNT type;

    fprintf(out, "   PP_STR\n") ;

    type = Read_FormatId(in, out);

    switch (type)
    {
        case 1:

            fscanf(in, "%lf", &pp.pp_price) ;
            fprintf(out,"   pp price:      %8lf\n", pp.pp_price) ;
            fprintf(out,"   PP's are:\n") ;
            pp.ppmts = Read_PLANARRAY(in) ;
            Write_PLANARRAY(out, pp.ppmts) ;

            break ;

        case 2:

            pp.pp_price = 100.0 ;
            pp.ppmts    = NULL ;

            break ;

    }

    Write_VALIDATEError(out, Validate_PP_STR(&pp));

    return pp ;
}


/*
..
*/


INTI Write_CflwDiff(CFLWARRAY exp, CFLWARRAY res, FILE* out)
{
    INTI     i, diff, dif1 ;
    YYYYMMDD ymd, ymd1 ;

    diff = 1 ;

    fprintf(out, "\nThe Output Cash Flow is\n") ;

    fprintf(out,"OK   Expected                    Calculated\n") ;
    fprintf(out,
      "     Date     Repayment  Coupon  Date     Repayment  Coupon\n")
      ;

    if (res->filled == exp->filled)
    {
        for (diff = i = 0 ; i < res->filled ; i++)
        {
            ymd  = Cldr_Datestr2YMD(&res->days[i]) ;
            ymd1 = Cldr_Datestr2YMD(&exp->days[i]) ;
            dif1 = ymd != ymd1 ||
                    fabs(res->repay[i] - exp->repay[i]) >= 0.00001 ||
                    fabs(res->coupon[i] - exp->coupon[i]) >= 0.00001 ;
            diff = diff || dif1 ;
            fprintf(out, "%d;  %8ld %9.5lf %9.6lf %8ld %9.5lf %9.6lf\n",
                        dif1, ymd1, exp->repay[i], exp->coupon[i],
                        ymd, res->repay[i], res->coupon[i]) ;
        }
    }

    else
    {
        fprintf(out, "1; Fill mismatch %d %d\n\n", res->filled, exp->filled) ;
        for (i = 0 ; i < res->filled ; i++)
        {
            ymd  = Cldr_Datestr2YMD(&res->days[i]) ;
            fprintf(out, "     Res: %8ld %9.5lf %9.6lf\n",
                    ymd, res->repay[i], res->coupon[i]) ;
        }

        for (i = 0 ; i < exp->filled ; i++)
        {
            ymd1 = Cldr_Datestr2YMD(&exp->days[i]) ;
            fprintf(out, "     Exp: %8ld %9.5lf %9.6lf\n",
                    ymd1, exp->repay[i], exp->coupon[i]) ;
        }
    }

    return diff ;
}


/*
..
*/

BONDBM Read_BONDBM(FILE* in, FILE* out)
{
    BONDBM   bond ;
    char     txa[30] ;
    YYYYMMDD ymd ;
    COUNT type;

    fprintf(out,"   Bond BM:\n") ;
    type = Read_FormatId(in, out);

    switch (type)
    {
        case 1:

            fscanf(in, "%s", txa) ;
            fprintf(out,"   Bond BM:    %8s\n", txa) ;
            bond.seg = Str2BONDSEG(txa) ;

            fscanf(in, "%ld", &ymd) ;
            bond.matur = Cldr_YMD2Datestr(ymd) ;
            fprintf(out,"   Maturity    %8ld\n", ymd) ;

            fscanf(in, "%lf", &bond.coupon) ;
            fprintf(out,"   Coupon      %8lf\n", bond.coupon) ;

            fscanf(in, "%s", txa) ;
            fprintf(out,"   Stub Front  %8s\n", txa) ;
            bond.stub_front = Str2ODDCONV(txa) ;

            fscanf(in, "%ld", &ymd) ;
            bond.issue_nom = Cldr_YMD2Datestr(ymd) ;
            fprintf(out,"   Issue/Nom   %8ld\n", ymd) ;

            fscanf(in, "%ld", &ymd) ;
            bond.first = Cldr_YMD2Datestr(ymd) ;
            fprintf(out,"   First       %8ld\n", ymd) ;

            bond.tax = Set_TAXINFO(0.0, 0.0, 0.0, False) ;
            break ;

        case 2:
            fscanf(in, "%s", txa) ;
            fprintf(out,"   Bond BM:    %8s\n", txa) ;
            bond.seg = Str2BONDSEG(txa) ;

            fscanf(in, "%ld", &ymd) ;
            bond.matur = Cldr_YMD2Datestr(ymd) ;
            fprintf(out,"   Maturity    %8ld\n", ymd) ;

            fscanf(in, "%lf", &bond.coupon) ;
            fprintf(out,"   Coupon      %8lf\n", bond.coupon) ;

            fscanf(in, "%s", txa) ;
            fprintf(out,"   Stub Front  %8s\n", txa) ;
            bond.stub_front = Str2ODDCONV(txa) ;

            fscanf(in, "%ld", &ymd) ;
            bond.issue_nom = Cldr_YMD2Datestr(ymd) ;
            fprintf(out,"   Issue/Nom   %8ld\n", ymd) ;

            fscanf(in, "%ld", &ymd) ;
            bond.first = Cldr_YMD2Datestr(ymd) ;
            fprintf(out,"   First       %8ld\n", ymd) ;

            bond.tax = Read_TAXINFO(in, out) ;
    }

    Write_VALIDATEError(out, Validate_BONDBM(&bond));

    return bond ;
}


/*
..
*/


AIRESULT Read_AIRESULT(FILE* in)
{
    AIRESULT aiexp ;
    int      i1 ;
    YYYYMMDD aday ;
    char     txc[25] ;

    fscanf(in, 
      "%lf %d %lf %ld %s",
      &aiexp.AI, &i1, &aiexp.AI_per_day, &aday, txc) ;
    aiexp.AIdays     = (INTI) i1 ;
    aiexp.exc        = Str2BOOLE(txc) ;
    aiexp.next       = Cldr_YMD2Datestr(aday) ;

    Write_ValidateStatus(Validate_AIRESULT(&aiexp));

    return aiexp ;
}



/* 
..
*/

INDEXBOND Read_INDEXBOND(FILE* in, FILE* out, DATESTR* settle)
{
    INDEXBOND   xt ;
    COUNT       type;

    fprintf(out,"   INDEXBOND:\n") ;

    type = Read_FormatId(in, out);

    switch (type)
    {
        case 1:

            xt.fixp  = Read_FIXPAY(in, out, settle) ;
            xt.pv_delay = Read_PERIOD(in) ;
            Write_PERIOD(out, "PV Delay: ", &xt.pv_delay) ;
            xt.cflw_delay = Read_PERIOD(in) ;
            Write_PERIOD(out, "CFLW Delay: ", &xt.cflw_delay) ;
            xt.indexednotional = Read_BOOLE(in, out, "Indexed Notional  ") ;
            break ;
    }

    Write_VALIDATEError(out, Validate_INDEXBOND(&xt));

    return xt ;
}

/*
..
*/

INDEXLOAN Read_INDEXLOAN(FILE* in, FILE* out)
{
    INDEXLOAN   xt ;
    COUNT       type;
    BOOLE       deb ;

    /* warning avoidance */
    memset(&xt, 0, sizeof(xt));

    fprintf(out,"   INDEXLOAN:\n") ;

    type = Read_FormatId(in, out);

    switch (type)
    {
        case 1:

            xt.coupon    = Read_FL64(in, out, "Coupon            ") ;
            xt.rpct      = Read_FL64(in, out, "rpct              ") ;
            xt.round     = True ;
            xt.freq      = Read_PMTFREQ(in, out, "Frequency          ") ;
            xt.dprinc    = Read_FL64(in, out, "Debtor princ      ") ;
            xt.doutstand = Read_FL64(in, out, "Debtor outstand   ") ;
            xt.coutstand = Read_FL64(in, out, "Creditor outstand ") ;
            xt.effective = Read_DATESTR(in, out, "Effective          ") ;
            xt.first_coupon = Read_DATESTR(in, out, "First coupon day   ") ;
            xt.first_amort  = Read_DATESTR(in, out, "First amort. day   ") ;
            xt.last      = Read_DATESTR(in, out, "Last               ") ;
            xt.delay     = Read_PERIOD(in) ;
            Write_PERIOD(out, "Delay: ", &xt.delay) ;
            deb       = Read_BOOLE(in, out, 
                                   "Assuming IS bond. Debitor CFLW? ") ;
            if (deb)
              xt.iltype = IS_DEBITOR ;
            else
              xt.iltype = IS_CREDITOR ;
            xt.amort = 0.0 ;

            xt.cal = EU30360 ;
            xt.accru_cal = xt.cal ;
            xt.exc = Set_EXRULE(EX_DAYS, 0, True, ACTACT,
                                NULL, 0, NULL, NULL, True) ;


            break ;

        case 2:

            xt.coupon    = Read_FL64(in, out, "Coupon            ") ;
            xt.rpct      = Read_FL64(in, out, "rpct              ") ;
            xt.round     = Read_BOOLE(in, out, "Round payments ?  ") ;
            xt.freq      = Read_PMTFREQ(in, out, "Frequency          ") ;
            xt.dprinc    = Read_FL64(in, out, "Debtor princ      ") ;
            xt.doutstand = Read_FL64(in, out, "Debtor outstand   ") ;
            xt.coutstand = Read_FL64(in, out, "Creditor outstand ") ;
            xt.effective = Read_DATESTR(in, out, "Effective          ") ;
            xt.first_coupon = Read_DATESTR(in, out, "First coupon day   ") ;
            xt.first_amort  = Read_DATESTR(in, out, "First amort. day   ") ;
            xt.last      = Read_DATESTR(in, out, "Last               ") ;
            xt.cal = Read_CALCONV(in, out, "Odd first calendar ") ;
            xt.delay     = Read_PERIOD(in) ;
            Write_PERIOD(out, "Delay: ", &xt.delay) ;
            xt.iltype       = Read_INDEXLOANTYPE(in, out, "Type of Loan ") ;   
            xt.amort = Read_FL64(in, out, "Amort     ") ;
            xt.exc = Read_EXRULE(in, out) ;
            xt.accru_cal = Read_CALCONV(in, out, "Accrued calendar") ;

            break ;
    }

    return xt ;
}


/*
..
*/

INDEXFAC Read_INDEXFAC(FILE* in, FILE* out)
{
    INDEXFAC    xt ;
    COUNT       type;

    fprintf(out,"   INDEX FACTORS:\n") ;

    type = Read_FormatId(in, out);

    xt.round = False ;
    xt.roundOff = 0 ;

    switch (type)
    {
        case 1:
        case 2:

            xt.baseidx = Read_FL64(in, out, "Base index ") ;
            xt.idxfac  = Read_PLANARRAY(in) ;
            Write_PLANARRAY(out, xt.idxfac) ;
            xt.cal         = Read_CALCONV(in, out, "Calendar ") ;

            if (type == 2)
            {
              xt.round = True ;
              xt.roundOff = Read_INTI(in, out, "No. of decimals ") ;
            }

            break ;
        case 3: /* Set to zero inflation*/
        default:
            xt.baseidx = 100 ;
            xt.idxfac = NULL ;
            xt.cal = ACTACT ;
            break ;
    }

    Write_VALIDATEError(out, Validate_INDEXFAC(&xt));

    return xt ;
}


/*
..
*/


/*
  ***** STUFF RELATED TO VAR.H ***************************
*/


FXRISKSET Read_FXRISKSET(FILE* in, FILE* out)
{
    FXRISKSET fxr ;
    INTI      type ;

    /* warning avoidance */
    memset(&fxr, 0, sizeof(fxr));

    type = Read_FormatId(in, out) ;

    fprintf(out,"   FXRISKSET:\n") ;

    switch (type)
    {
        case 1:
        case 2:

            fxr.rate = Read_FL64(in, out, "   FXrate   ") ;
            Read_RISKTOKEN(in, out, &fxr.token) ;
            Read_CCYCODE(in, out, &fxr.home) ;
            if (type == 1)
                fxr.shock = 0.0 ;
            else if (type == 2)
                fxr.shock = Read_FL64(in, out, "   FXshock   ") ;
            
            break;

        default:
            fprintf(out, "1; Unknown format.\n");
            break;
    }

    return fxr ;
}


/*
..
*/


SCENARIOLIST Read_SCENARIOLIST(FILE* in, FILE* out)
{
    INTI         i ;
    int          i1 ;
    SCENARIOLIST scen ;
    COUNT type;

    type = Read_FormatId(in, out) ;

    fscanf(in, "%d", &i1) ;
    scen.nscen = (INTI) i1 ;
    fprintf(out, "   # of Scenarios %d\n", i1) ;

    /* Allocate */
    scen = Set_SCENARIOLIST(Alloc_SCENARIOARRAY(scen.nscen),
      scen.nscen);

    /* Read data */
    if (type == 1)
    {
        for (i = 0; i < scen.nscen; i++)
            scen.scens[i].scen = Read_BUCKETARRAY(in, out, 
                &scen.scens[i].nbuck) ;
    }

    Write_VALIDATEError(out, Validate_SCENARIOLIST(&scen));

    return scen ;
}


/*
..
*/


void Read_RISKTOKEN(FILE* in, FILE* out, RISKTOKEN* rt)
{
    char        txb[10] ;
    
    fscanf(in, "%s", txb) ;
    Str2CCYCODE(txb, &rt->ccy) ;

    fscanf(in, "%s", txb) ;
    Str2RISKCLASS(txb, sizeof(txb), &rt->rclass) ;

    Write_RISKTOKEN(out, rt) ;
}

/*
..
*/


void Write_RISKTOKEN(FILE* out, RISKTOKEN* r)
{
    char    tmp[256] ;

    fprintf(out,"   RISKTOKEN: ") ;

    /* CCYCODE */
    CCYCODE2Str(r->ccy, tmp) ;
    fprintf(out, "   CCY:   %s , ", tmp) ;

    /* RISKCLASS */
    RISKCLASS2Str(r->rclass, tmp) ;
    fprintf(out, "Class:  %s \n", tmp) ;
}

/*
..
*/


INTI Write_riskposdiff(RISKPOSLIST exp, RISKPOSLIST res, FILE* out, FL64 tol)
{
    int     i, diff, diff1 ;
    BOOLE   tokenEQ ;

    diff = 0 ;

    if (exp.npos != res.npos)
    {
        fprintf(out, "1; Array sizes mismatch. ");
        fprintf(out, "Expected: %d, Actual %d\n", 
          exp.npos, res.npos);

        diff = 1 ;
        return diff ;
    }

    for (i = 0; i < res.npos; i++)
    {
        fprintf(out, "\n       Exp. ") ;
        Write_RISKTOKEN(out, &exp.token[i]) ;
        fprintf(out, "       Res. ") ;
        Write_RISKTOKEN(out, &res.token[i]) ;

        diff1 =  fabs(exp.pos[i] - res.pos[i]) > tol ;
        tokenEQ = VAR_RiskTokenEQ(&exp.token[i], &res.token[i]) ;
        diff1 = diff1 || (tokenEQ ? 0 : 1) ;

        diff = diff || diff1;

        fprintf(out, "%d; %3d exp %lf res %lf\n", diff1, i,
                    exp.pos[i], res.pos[i]) ;
    }

    return diff ;
}



RISKPOSLIST Read_RISKPOSLIST(FILE* in, FILE* out)
{
    INTI        i ;
    RISKPOSLIST rp ;

    fscanf(in, "%d", &rp.npos) ;

    rp.token = Alloc_RISKTOKENARRAY(rp.npos) ;
    rp.pos = Alloc_FL64ARRAY(rp.npos) ;

    fprintf(out, "\nRisk positions:\n") ;
    for (i = 0; i < rp.npos; i++)
    {
        fscanf(in, "%s %s %lf", rp.token[i].ccy, rp.token[i].rclass, 
            &rp.pos[i]) ;
        fprintf(out, "%s\t%s\t%lf\n", rp.token[i].ccy, rp.token[i].rclass, 
            rp.pos[i]) ;
    }

    return rp ;
}




RISKTOKENARRAY Read_RISKTOKENARRAY(FILE* in, FILE* out, INTI* nrf)
{
    INTI        i ;
    RISKTOKENARRAY rf ;

    fscanf(in, "%d", nrf);
    fprintf(out, "   # risk factors:   %d\n", *nrf);
    rf = Alloc_RISKTOKENARRAY(*nrf);
    for (i = 0; i < *nrf; i++)
      Read_RISKTOKEN(in, out, &rf[i]);

    return rf ;
}



void Read_CCYCODE(FILE* in, FILE* out, CCYCODE* ccy)
{
  CH txb[50];

  fscanf(in, "%s", txb);
  Str2CCYCODE(txb, ccy);
  fprintf(out, "CCYCODE: %s\n", txb);
}



CCYCODEARRAY Read_CCYCODEARRAY(FILE* in, FILE* out, INTI* nrf)
{
  INTI        i ;
  CCYCODEARRAY rf ;

  fscanf(in, "%i", nrf);
  fprintf(out, "%i\n", *nrf);
  rf = Alloc_CCYCODEARRAY(*nrf);
  for (i = 0; i < *nrf; i++)
    Read_CCYCODE(in, out, &rf[i]);

  return rf ;
}





/*
Note txt must be a least CLASS_LENGTH characters long 
*/


void Str2CCYCODE(TEXT txt, CCYCODE* ccy)
{
    Str_Uppercase(txt) ;
    
    strncpy(*ccy, txt, CCY_LENGTH) ;
}


/*
Note txt must be a least CLASS_LENGTH characters long 
*/


void CCYCODE2Str(CCYCODE ccy, TEXT txt)
{
    strncpy(txt, ccy, CCY_LENGTH) ;
}


/*
Note txt must be a least CLASS_LENGTH characters long 
*/


void Str2RISKCLASS(TEXT txt, size_t size, RISKCLASS* rclass)  
{
    Str_Uppercase(txt) ;

//    nstrcpy(*rclass, size, txt) ;     /*  HFI-PMSTA-36650-190724  nstrcpy is part of syslib.h ... not a good idea to include syslib.h in scecon project   */
    strncpy(*rclass, txt, --size);
    (*rclass)[size] = 0;
}


/*
Note txt must be a least CLASS_LENGTH characters long 
*/


void RISKCLASS2Str(RISKCLASS rclass, TEXT txt)
{
    strcpy(txt, rclass) ;
}




INTI Write_FXSHOCKSETDiff(FXSHOCKSET* exp, FXSHOCKSET* res, 
        FILE* out, FL64 tol) 
{
    INTI diff, i, diff1;

    diff = diff1 = 0;
    if (exp->nshock == res->nshock)
    {
        for (i = 0; i < exp->nshock; i++)
        {
            if (fabs(exp->shocked[i] - res->shocked[i]) < tol)
              diff1 = 0;
            else
              diff1 = 1;

            fprintf(out, "%d; %3d  Exp: %8.5lf  Act: %8.5lf\n", diff1,
              i, exp->shocked[i], res->shocked[i]);
            diff = diff || diff1;
        }
    }
    else
    {
        fprintf(out, "1; Arraysizes mismatch. ");
        fprintf(out, "Expected %d, Actual %d\n", exp->nshock, 
          res->nshock);
        diff = 1;  
    }

    if (VAR_RiskTokenEQ(&exp->token, &res->token) == True)
        diff1 = 0;
    else
        diff1 = 1;

    fprintf(out, "%d;", diff1);
    Write_RISKTOKEN(out, &exp->token);
    fprintf(out, "  ");
    Write_RISKTOKEN(out, &res->token);

    diff = diff || diff1;

    return diff;
}



FXSHOCKSET Read_FXSHOCKSET(FILE* in, FILE* out)
{
    FXSHOCKSET fxs ;
    INTI      type;

    /* warning avoidance */
    memset(&fxs, 0, sizeof(fxs));

    fprintf(out, "   FXSHOCKSET\n") ;

    type = Read_FormatId(in, out);

    switch (type)
    {
    case 1:
        fprintf(out, "Shocked Fx rates:\n");
        fxs.shocked = Read_FL64ARRAY(in, &fxs.nshock);
        Write_FL64ARRAY(out, fxs.shocked, fxs.nshock);

        fprintf(out, "Fx rate Risk Token:\n");

        Read_RISKTOKEN(in, out, &fxs.token);
        break;
    default:
        fprintf(out, "1; Unknown format.\n");
        break;
    }

    return fxs ;
}


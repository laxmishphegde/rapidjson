/* SCID @(#)bondpf.c	1.9 (SimCorp) 99/10/27 13:58:34 */

/************************************************************************
*
*   project     SCecon
*
*   filename    bondpf.c
*
*   general     This file contains Bond Portfolio Routines
*
************************************************************************/

/* includes ************************************************************/
#include <bond.h>

/*** defines  **********************************************************/

/*,,SOH,,
*************************************************************************
*
*               Cflw_MergeCFLWARRAY()
*
*   interface   #include <bond.h>
*               CFLWARRAY Cflw_MergeCFLWARRAY(CFLWARRAY cflw,
*                                             FL64ARRAY notnal,
*                                             INTI      n) ;
*
*   general     The function merges n CFLW_STR's into one aggregate
*               CFLWARRAY.
*
*               The array notnals holds the notional amounts for each
*               position in the individual cashflow.
*
*   input       CFLWARRAY cflw    The basis cashflows
*                                 Dimension [n]
*
*               FL64ARRAY notnal  The individual notnals on the basic
*                                 cashflows.
*                                 Dimension [n]
*
*               INTI      n       The number of entries in cflw, notnal
*
*   output
*
*   returns     Pointer to the CFLWARRAY holding the merged flow.
*               Allocated in this routine as: Alloc_CFLWARRAY(1, count)
*               where count is total number of payments.
*
*   diagnostics
*
*   see also
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/

CFLWARRAY Cflw_MergeCFLWARRAY(CFLWARRAY cflw, FL64ARRAY notnal, INTI n)
{
    INTI      count, i, j, *cflcount, *finished, nfinish, active ;
    FL64      coup, repay ;
    DATESTR   *dcflw, time ;
    CFLWARRAY res ;

    /* Allocate working memory */
    cflcount = Alloc_INTIARRAY(n) ;
    finished = Alloc_INTIARRAY(n) ;

    for (count = i = 0; i < n; i++)
        count += cflw[i].filled ;

    res     = Alloc_CFLWARRAY(1, count)  ;
    nfinish = 0 ;
    time    = Cldr_YMD2Datestr((YYYYMMDD) 99999999) ;

    for (i = 0 ; i < n ; i++)
    {
        cflcount[i] = 0 ;

        /* Check if there is any payments in the i'th cashflow */
        if (cflw[i].filled == 0)
        {
            finished[i] = 1 ;
            nfinish++ ;
        }
    }

    /* Start looping around cashflows to merge into aggregate cashflow */
    i = 0 ;
    while (nfinish < n)
    {
        coup = repay = 0.0 ;
        time = Cldr_YMD2Datestr((YYYYMMDD) 99999999) ;

        /* Find shortest time in cashflows */
        for (j = 0 ; j < n ; j++)
        {
            if (finished[j])
                continue ;

            dcflw = cflw[j].days ;
            if (Cldr_DateLT(&dcflw[cflcount[j]], &time) == True)
                time = dcflw[cflcount[j]] ;
        }

        /* Find securities with payments at that day */
        for (j = 0 ; j < n ; j++)
        {
            if (finished[j])
                continue ;

            active = cflcount[j] ;

            if (Cldr_DateEQ(&time, &cflw[j].days[active]) == True)
            {
                coup  += cflw[j].coupon[active] * notnal[j] / 100.0;
                repay += cflw[j].repay[active] * notnal[j] / 100.0;
                cflcount[j]++ ;

                /* keep track of finished securities */
                if (cflcount[j] >= cflw[j].filled)
                {
                    finished[j] = 1 ;
                    nfinish++ ;
                }
            }
        }

        /* Update resulting cashflow */ 
        Cflw_Insert_In_Cflw(&time, repay, coup, res) ;
    }

    /* Clean up */
    Free_INTIARRAY(cflcount) ;
    Free_INTIARRAY(finished) ;

    return res ;
}


/*,,SOH,,
*************************************************************************
*
*               Bond_MergeCFLWARRAY()
*
*   interface   #include <bond.h>
*               CFLWARRAY Bond_MergeCFLWARRAY(TRADEINFOARRAY  trade,
*                                              FIXPAYARRAY     fixp,
*                                              INTI            nfixp,
*                                              HOLI_STR        *holi) ;
*
*   general     The function merges the cashflows of n bonds into one
*               aggregate CFLWARRAY.
*
*   input       TRADEINFOARRAY trade    The trade data (nfixp entries)
*
*               FIXPAYARRAY    fixp     The bond list (nfixp bonds)
*
*               INTI           nfixp    Number of fixp + trade
*
*               HOLI_STR       *holi    Business day adjustment setup
*
*   output
*
*   returns     Pointer to the CFLWARRAY holding the merged flow.
*               Allocated in this routine as: Alloc_CFLWARRAY(1, count)
*               where count is total number of payments.
*
*   diagnostics
*
*   see also
*
*************************************************************************
,,EOH,,*/


CFLWARRAY Bond_MergeCFLWARRAY(TRADEINFOARRAY trade,
                               FIXPAYARRAY      fixp,
                               INTI             nfixp,
                               HOLI_STR*         holi)
{
    INTI      i ;
    HOLI_STR  hol ;
    FL64ARRAY notnal ;
    CFLWARRAY xcflw, cflw, mcflw ;

    /* Allocate */
    cflw   = Alloc_CFLW(nfixp) ;
    notnal = Alloc_FL64ARRAY(nfixp) ;

    for (i = 0; i < nfixp; i++)
    {
        notnal[i] = trade[i].nom ;
        hol       = bond_set_holi(holi, &fixp[i].fix) ;
        xcflw     = Bond_GenrCflw(&trade[i], &fixp[i], &hol) ;

        cflw[i].filled = xcflw->filled ;
        cflw[i].days   = xcflw->days ;
        cflw[i].repay  = xcflw->repay ;
        cflw[i].coupon = xcflw->coupon ;

        Free_CFLW(xcflw) ;
    }

    /* Merge into PF cashflow */
    mcflw = Cflw_MergeCFLWARRAY(cflw, notnal, nfixp) ;

    Free_CFLWARRAY(cflw, nfixp) ;
    Free_FL64ARRAY(notnal) ;

    return mcflw ;
}


/*,,SOH,,
*************************************************************************
*
*               BondPF_YTM2Yield()
*
*   interface   #include <bond.h>
*               BOOLE BondPF_YTM2Yield(TRADEINFOARRAY trade,
*                                      FIXPAYARRAY    fixp,
*                                      INTI           nfixp,
*                                      YTMCONV        *ytmc,
*                                      HOLI_STR       *holi,
*                                      ITERCTRL       *ictrl,
*                                      FL64           *ytm) ;
*
*   general     The function calculates the Yield to maturity
*               for a bond portfolio.
*
*               The total bond position is found by weighting the
*               individual cashflows with trade[i].nom as the individual*
*               holding.
*
*   input       TRADEINFOARRAY trade    The trade data (nfixp entries)
*
*               FIXPAYARRAY    fixp     The bond list (nfixp bonds)
*
*               INTI           nfixp    Number of fixp + trade
*
*               YTMCONV        *ytmc    The conventions defined for
*                                       calculating the YTM.
*                                       ytmc->irr cannot be MAIR.
*
*               HOLI_STR       *holi    Business day adjustment setup
*
*               ITERCTRL       *ictrl   Iteration control
*
*   output      FL64           *ytm     The YTM calculated in %
*
*   returns     True if all is OK, False if not.
*
*   diagnostics
*
*   see also
*
*************************************************************************
,,EOH,,*/


BOOLE BondPF_YTM2Yield(TRADEINFOARRAY trade,
                       FIXPAYARRAY    fixp,
                       INTI           nfixp,
                       YTMCONV*        ytmc,
                       HOLI_STR*       holi,
                       ITERCTRL*       ictrl,
                       FL64*           ytm)
{
    CFLWARRAY mcflw ;
    PAYDAYDEF cday ;
    PAYDAYSEQ pseq ;
    INTI      i ;
    DATESTR   ddum ;
    FL64      price ;
    BOOLE     ok ;

    /* Merge into PF cashflow */
    mcflw = Bond_MergeCFLWARRAY(trade, fixp, nfixp, holi) ;

    pseq = Set_PAYDAYSEQ(0, MONTHS, NOODD, NOODD, ANCHOR, LAST) ;
    cday = Set_PAYDAYDEF(False, &ddum, &ddum, &ddum,
                              False, &pseq, mcflw->filled, mcflw->days) ;
    for (price = 0.0, i = 0; i < nfixp; i++)
        price += trade[i].price * trade[i].nom / 100.0 ;

    /* Calculate yield */
    ok = Cflw_YTM2Yield(price, mcflw, ytmc, &cday, 0.0, 
                        NULL, holi, ictrl, ytm) ;

    Free_CFLWARRAY(mcflw, 1) ;

    return ok ;
}


/*,,SOH,,
*************************************************************************
*
*               BondPF_YTM2Duration()
*
*   interface   #include <bond.h>
*               FL64 BondPF_YTM2Duration(FL64           ytm,
*                                        TRADEINFOARRAY trade,
*                                        FIXPAYARRAY    fixp,
*                                        INTI           nfixp,
*                                        YTMCONV        *ytmc,
*                                        HOLI_STR       *holi)
*
*   general     The function calculates the duration (Macauley)
*               for a bond portfolio.
*
*               The total bond position is found by weighting the
*               individual cashflows with trade[i].nom as the individual*
*               holding.
*
*   input       FL64           ytm      Yield (%)
*
*               TRADEINFOARRAY trade    The trade data (nfixp entries)
*
*               FIXPAYARRAY    fixp     The bond list (nfixp bonds)
*
*               INTI           nfixp    Number of fixp + trade
*
*               YTMCONV        *ytmc    The conventions defined for
*                                       calculating the YTM.
*                                       ytmc->irr cannot be MAIR.
*
*               HOLI_STR       *holi    Business day adjustment setup
*
*   output
*
*   returns     The duration
*
*   diagnostics
*
*   see also
*
*************************************************************************
,,EOH,,*/


FL64 BondPF_YTM2Duration(FL64        ytm,
                         TRADEINFOARRAY trade,
                         FIXPAYARRAY    fixp,
                         INTI           nfixp,
                         YTMCONV*        ytmc,
                         HOLI_STR*       holi)
{
    CFLWARRAY mcflw ;
    PAYDAYDEF cday ;
    PAYDAYSEQ pseq ;
    INTI      i ;
    DATESTR   ddum ;
    FL64      dur, price ;

    /* Merge into PF cashflow */
    mcflw = Bond_MergeCFLWARRAY(trade, fixp, nfixp, holi) ;

    pseq = Set_PAYDAYSEQ(0, MONTHS, NOODD, NOODD, ANCHOR, LAST) ;
    cday = Set_PAYDAYDEF(False, &ddum, &ddum, &ddum,
                              False, &pseq, mcflw->filled, mcflw->days) ;
    for (price = 0.0, i = 0; i < nfixp; i++)
        price += trade[i].price * trade[i].nom / 100.0 ;

    /* Calculate duration */
    dur = Cflw_YTM2Duration(ytm, mcflw, ytmc, &cday, holi) ;

    Free_CFLWARRAY(mcflw, 1) ;

    return dur ;
}


/*,,SOH,,
*************************************************************************
*
*               BondPF_DF2Hzy()
*
*   interface   #include <bond.h>
*               BOOLE BondPF_DF2Hzy(TRADEINFOARRAY trade,
*                                   TRADEINFOARRAY horiz,
*                                   FIXPAYARRAY    fixp,
*                                   INTI           nfixp,
*                                   HZYCONV        *hzyc,
*                                   DISCFAC        *dfre,
*                                   DISCFAC        *dfhz,
*                                   HOLI_STR       *holi,
*                                   DFSPREADARRAY  dfs,
*                                   ITERCTRL       *ictrl,
*                                   FL64           *hzy) ;
*
*   general     The function calculates the Horizon Yield
*               for a bond portfolio.
*
*               The total bond position is found by weighting the
*               individual cashflows with trade[i].nom as the individual*
*               holding.
*
*   input       TRADEINFOARRAY trade    The trade data (nfixp entries)
*                                       Contains current market prices
*
*               TRADEINFOARRAY horiz    The horizon data (nfixp entries)*
*                                       all settle dates assumed equal.
*                                       Contains all horizon prices if
*                                       needed.
*
*               FIXPAYARRAY    fixp     The bond list (nfixp bonds)
*
*               INTI           nfixp    Number of fixp, trade, horiz
*
*               HZYCONV        *hzyc    Conventions for calculation
*
*               DISCFAC        *dfre    Discount factor setup for
*                                       reinvesting till horiz.
*                                       (E.g. zero curve on settle)
*                                       Only used if interim proceeds
*                                       are reinvested.
*
*               DISCFAC        *dfhz    Discount factor setup for
*                                       finding the value on horiz of
*                                       the payments after horiz.
*                                       (E.g forward curve on horiz).
*                                       If dfhz is equal to dfre then
*                                       essentially forward rates are
*                                       used to find the terminal value.*
*                                       Only used if horizon value is
*                                       not entered separately.
*
*               HOLI_STR       *holi    Business day adjustment setup
*
*               DFSPREADARRAY  dfs      List of individual bond spreads
*                                       (nfixp entries).
*
*               ITERCTRL       *ictrl   Iteration control
*
*   output      FL64           *hzy     The YTM calculated in %
*
*   returns     True if all is OK, False if not.
*
*   diagnostics
*
*   see also
*
*************************************************************************
,,EOH,,*/

BOOLE BondPF_DF2Hzy(TRADEINFOARRAY trade,
                        TRADEINFOARRAY horiz,
                        FIXPAYARRAY    fixp,
                        INTI           nfixp,
                        HZYCONV*       hzyc,
                        DISCFAC*       dfre,
                        DISCFAC*       dfhz,
                        HOLI_STR*      holi,
                        DFSPREADARRAY  dfs,
                        ITERCTRL*      ictrl,
                        FL64*          hzy)
{
    HOLI_STR  hol ;
    CFLWARRAY cflw, xcflw1, xcflw2, mcflw ;
    PAYDAYDEF cday ;
    PAYDAYSEQ pseq ;
    INTI      i, j, ix ;
    DATESTR   ddum, dhoriz ;
    FL64      rg, pmt, dH, dum, HVi, HV, price, coup ;
    BOOLE     ok ;
    FL64ARRAY notnal ;
    TRADEINFO hzt, end ;

    if (nfixp > 0)
        dhoriz = horiz[0].settle ;

    cflw   = Alloc_CFLW(nfixp) ;
    notnal = Alloc_FL64ARRAY(nfixp) ;

    /* Loop to find all flows and horizon value */
    for (HV = price = 0.0, i = 0; i < nfixp; i++)
    {
        notnal[i] = trade[i].nom ;

        end = bond_set_tradeinfo(&fixp[i].cday.last) ;
        hol = bond_set_holi(holi, &fixp[i].fix) ;
        hzt = Set_TRADEINFO(&horiz->trade, &horiz->aisttl, &horiz->settle,
                            horiz->brd, 0.0, 100.0, &horiz[i].xctrade,
                            &horiz[i].xptrade) ;
        trade[i].nom = 100.0 ;

        if (hzyc->hzp == False)
        {
            xcflw2 = Bond_GenrPeriod(&hzt, &end, &fixp[i], &hol) ;
            HVi = Cflw_DF2Price(&dhoriz, dfhz, xcflw2, &fixp[i].repay.pp, holi,
                                &dfs[i], NULL, &dum, &dum) ;
            Free_CFLWARRAY(xcflw2, 1) ;
        }
       else
            HVi = horiz[i].price ;

        xcflw1 = Bond_GenrPeriod(&trade[i], &hzt, &fixp[i], &hol) ;

        for (rg = 0.0, j = 1; j < xcflw1->filled; j++)
            rg += xcflw1->repay[j] ;

        HV    += (1.0 - rg / 100.0) * HVi * notnal[i] / 100.0 ;
        price += trade[i].price * notnal[i] / 100.0 ;

        cflw[i].filled = xcflw1->filled ;
        cflw[i].days   = xcflw1->days ;
        cflw[i].repay  = xcflw1->repay ;
        cflw[i].coupon = xcflw1->coupon ;

        trade[i].nom = notnal[i] ;

        Free_CFLW(xcflw1) ;
    }

    /* Merge into PF cashflow */
    mcflw = Cflw_MergeCFLWARRAY(cflw, notnal, nfixp) ;

    /* Handle reinvestment properly */
    if (hzyc->reinv == True)
    {
        /* Horizon value - reinvested payments */
		dH = Disc_Interpolation(&dhoriz, dfre, holi);  /* PMSTA-22396 - SRIDHARA � 160502 */

        for (i = 1; i < mcflw->filled; i++)
        {
            if (fabs(dH) > 0.0000001)
            {
                pmt  = mcflw->coupon[i] + mcflw->repay[i] ;
                pmt *= Disc_Interpolation(&mcflw->days[i], dfre, holi) / dH ;    /* PMSTA-22396 - SRIDHARA � 160502 */
                HV  += pmt ;
            }
        }

        /* Reshuffle the cashflow */
        if (mcflw->count > 1)
        {
            mcflw->filled    = 2 ;
            mcflw->days[1]   = dhoriz ;
            mcflw->coupon[1] = 0.0 ;
            mcflw->repay[1]  = HV ;
        }
    }
    else
    {
        /* Set horizon value */
        ix = Cldr_FindDateIndex(mcflw->days, mcflw->filled, &dhoriz, 0,
                                 SEARCH_BISECTION, SAMEINDEX) ;
        if (ix < mcflw->filled)
            mcflw->repay[ix] += HV ;
        else
        {
            /* Occasionally end date is not in xcflw1 ! */
            if (mcflw->count > mcflw->filled)
            {
                ix = mcflw->filled ;
                mcflw->days[ix]   = dhoriz ;
                mcflw->repay[ix]  = HV ;
                mcflw->coupon[ix] = 0.0 ;
                mcflw->filled    += 1 ;
            }
            else
            {
                ix = GETMIN(ix, mcflw->filled - 1) ;
                mcflw->repay[ix] += HV ;
            }
        }
    }

    /* Calculate horizon yield */
    pseq = Set_PAYDAYSEQ(0, MONTHS, NOODD, NOODD, ANCHOR, LAST) ;
    cday = Set_PAYDAYDEF(False, &ddum, &ddum, &ddum,
                         False, &pseq, mcflw->filled, mcflw->days) ;

    if (mcflw->filled > 2)
        coup = Cflw_Extract_Coupon(mcflw) ;
    else 
        coup = 0.0 ;

    ok   = RepoCflw_YTM2Yield(price, mcflw, &horiz->settle, &hzyc->ytmc,
                              &cday, coup, NULL, holi, ictrl, hzy) ;

    /* Clean up */
    Free_CFLWARRAY(mcflw, 1) ;
    Free_CFLWARRAY(cflw, nfixp) ;
    Free_FL64ARRAY(notnal) ;

    return ok ;
}


/*
..
*/


CFLWARRAY Alloc_CFLW(INTI ns)
{
    CFLWARRAY a ;

    a = (CFLWARRAY) SCecon_calloc(ns, sizeof(CFLW_STR), True,
      "Alloc_CFLW()") ;

    return a ;
}

/*
..
*/


void Free_CFLW(CFLWARRAY cflw)
{
    SCecon_free((VOIDPTR) cflw) ;
}


/*,,SOH,,
*************************************************************************
*
*               Alloc_TRADEINFOARRAY()
*
*    interface  #include <bond.h>
*               TRADEINFOARRAY Alloc_TRADEINFOARRAY(INTI ns);
*
*    general    Alloc_TRADEINFOARRAY() allocates memory for an
*               [0...(n-1)] array of BUCKET_STR's.
*               Returns memory with zero'ed entries
*
*    input      INTI    ns   The number of entries in TRADEINFO list
*
*    output
*
*    returns    reference to the vector of type TRADEINFO
*
*    diagnostics aborts calling SCecon_error()
*                with the message   "Memory allocation error"
*                         routine   "Alloc_TRADEINFOARRAY()"
*                         actioncode SCECONABORT
*                if allocation fails
*
*    see also   Free_TRADEINFOARRAY()
*
*************************************************************************
,,EOH,,*/


TRADEINFOARRAY Alloc_TRADEINFOARRAY(INTI ns)
{
    TRADEINFOARRAY a ;

    a = (TRADEINFOARRAY) SCecon_calloc(ns, sizeof(TRADEINFO), True,
      "Alloc_TRADEINFOARRAY()") ;

    return a ;
}



/*,,SOH,,
*************************************************************************
*
*               Free_TRADEINFOARRAY()
*
*    interface  #include <bond.h>
*               void Free_TRADEINFOARRAY(TRADEINFOARRAY t) ;
*
*    general    Free_TRADEINFOARRAY() frees memory for an array
*               of TRADEINFO's allocated by Alloc_TRADEINFOARRAY()
*
*    input      TRADEINFOARRAY t             Reference to the array
*
*    output
*
*    returns
*
*    diagnostics
*
*    see also   Alloc_TRADEINFOARRAY()
*
*************************************************************************
,,EOH,,*/


void Free_TRADEINFOARRAY(TRADEINFOARRAY t)
{
    SCecon_free((VOIDPTR) t) ;
}

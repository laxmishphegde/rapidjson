/* SCID @(#)cf_accru.c	1.11 (SimCorp) 99/11/11 10:35:00 */

/************************************************************************
*
*       project         SCecon
*
*       file name       cf_accru.c
*
*       contains        the standard SimCorp accrued calculator
*
************************************************************************/

/*** includes **********************************************************/
#include <cflw.h>


/*** defines ***********************************************************/
#define PRICE_TOL   0.000001


/*,,SOH,,
*************************************************************************
*
*              Cflw_Accruint()
*
*    interface #include <cflw.h>
*              AIRESULT Cflw_Accruint(TRADEINFO   *settle,
*                                     CFLW_STR    *cflw,
*                                     FIXRATE     *fix,
*                                     PAYDAYSEQ   *pseq,
*                                     ACCRUINT    *accru,
*                                     HOLI_STR    *holi,
*                                     PLAN_STR    *pp) ;
*
*    general   This function calculates the accrued interest for a bond
*              at any time during the life of the bond.
*              The value returned is per 100 outstanding at time basis
*              - after possible payments on the valuation day.
*
*              The function considers the following special effects.
*
*                  - ex-coupon days. If the bond is ex-coupon the
*                    accrued interest is negative.
*                  - calender convention for calculating accrued
*                  - end of month convention.
*                  - KNOWN rate adjustments over the entire life of
*                    the bond.
*                  - amortizations at any time during the life of the
*                    bond, including irregular schemes paying on days
*                    differing from the coupon days and with more than
*                    one amortization during a coupon period.
*                  - partly payments in the period before the first
*                    repayment.
*                  - coupon accrual start differing from issue date.
*                  - coupon base differing from the base used to
*                    compute the coupons, ie. when accrued interest
*                    not equals the coupon.
*                  - odd first/last coupon periods
*                  - accrued interest before emission or rather before
*                    the interest start date. In this case the
*                    accrued interest can be negative.
*                  - compounding convention and basis.
*                    Usually simple interest is used, but for some
*                    markets periodically compounding is used.
*                  - interest accrues in both first and final day of
*                    the holding period - except of course if the
*                    final day in the holding period is a coupon day.
*                  - prepaid coupons
*
*                  ..etc
*
*              Note that in case prepaid coupons is set, the ex-coupon
*              definition is ignored.
*
*              NB:
*              The original cashflow of the bond is used here. This is
*              done for generality. In many situations simplified data
*              can be used. For 'simple' loans just put in:
*
*                  - cflw->filled   = 1
*                  - cflw->days     = next coupon date
*                  - cflw->repay    = 100 on next coupon date
*                  - cflw->coupon   = the periodic coupon
*                  - fix->effective = the previous coupon date
*
*              However, if you are not sure whether a loan is 'simple'
*              do the calculation the general way.
*
*    input     TRADEINFO   *settle   The settle date info. AI is
*                                    calculated on settle->aisettle
*                                    If settle->brd is False then
*                                    only settle->aisttl is used
*
*              CFLW_STR    *cflw     Cashflow as generated from
*                                    Cflw_GenrCflw()
*                                    Do NOT compress any all zero
*                                    paydays out (used for accruals).
*
*              FIXRATE     *fix      Coupon calc. conventions.
*
*              PAYDAYSEQ   *pseq     Conventions for payday sequencing.
*                                    For bonds with irregular coupon
*                                    days - just use pseq.term = 0
*
*              ACCRUINT    *accru    Conventions for accrued calculation*
*
*              HOLI_STR    *holi     Businessday adjustments.
*
*              PLAN_STR    *pp       Partly payments.
*                                    An array with pp->filled elements.
*                                    All payments must fall before the
*                                    first repayment.
*                                    Must sum to 100 if npp > 0.
*
*    output
*
*    returns   Various data on the calculation as an AIRESULT struct.
*
*    diagnostics
*
*    see also  Cflw_ExtractPeriod()
*
*    wrapper   AP
*
*************************************************************************
,,EOH,,*/


AIRESULT Cflw_Accruint(TRADEINFO* settle,
                       CFLW_STR*    cflw,
                       FIXRATE*     fix,
                       PAYDAYSEQ*   pseq,
                       ACCRUINT*    accru,
                       HOLI_STR*    holi,
                       PLAN_STR*    pp,
                       INDEXCONV    iConv,
	                   FLAG_T mktConvMethodEnblFlg)      /*  FPL-PMSTA00211-100826 for full coupon flag  */
{
    FL64       acr, term, dai, saldo, scale, debt, act_coupon, ai,
               brdacc, dpy, dd ;
    INTI       cix1, cix2, ixf, nf, months, ne, ixr, ixa, ixp, next, prev,
               dnext, qbas, ix, i, dum, dum1, nad, npp, n, ne1, ixx,
               ixt, trmu, AId, nirreg ;
    TERMUNIT   unit ;
    DATEARRAY  fict_coupon1, buffer1, buffer2, event ;
    DATESTR    last, xlast, dcalc, compfrom, prevdate, date, from, to, yfrom,
               yto, dcprev, dcnext, basis, day, datex, AI1, AI2, dummy ;
    DATESTR    *dates1, *adjustdays, *ppdays ;
    FL64       *coups, *coupons1, coupon, *amort1, *adjust, *ppamt ;
    BOOLE      add2, accrual, harm, exc, pre, incl, oddcase, rl, CGB183_184 ;
    CALCONV    cal ;
    BUSCONV    bus ;
    COUPONBASE cb, cbodd ;
    IRRCONV    irr ;
    ODDCONV    odd1, oddn ;
    EOMCONV    eom ;
    PLAN_STR   plana ;
    AIRESULT   aires ;

    /* warning avoidance */
    acr = dpy = 0.0 ;

    /* Pick various data */
    basis = settle->aisttl ;

    odd1 = pseq->odd1 ;
    oddn = pseq->oddn ;
    eom  = pseq->eom ;
    trmu = pseq->term ;
    unit = pseq->unit ;
    harm = Cflw_Is_Harmonic(trmu, unit, &months) ;

    dcalc   = fix->effective ;
    coupon  = fix->fix_rate ;
    nad     = GetPlanFill(fix->stepcoup) ;

    last    = fix->lastaccr ;
    if (cflw->filled && Cldr_DateLT(&last, &dcalc) == True)
        last = cflw->days[cflw->filled - 1] ;

    cal   = accru->cal ;
    incl  = accru->incl ;
    pre   = accru->pre ;
    irr   = accru->irr ;
    qbas  = accru->qbas ;
    cb    = accru->cb_accru ;
    cbodd = accru->cbodd_accru ;

    /* Pick more information */
    nirreg     = GetPlanFill(fix->irreg) ;

    nad        = GetPlanFill(fix->stepcoup) ;
    adjustdays = GetPlanDay(fix->stepcoup) ;
    adjust     = GetPlanF64(fix->stepcoup) ;

    ppdays     = GetPlanDay(pp) ;
    ppamt      = GetPlanF64(pp) ;
    npp        = GetPlanFill(pp) ;

    amort1   = cflw->repay ;
    coupons1 = cflw->coupon ;
    n        = cflw->filled ;
    dates1   = cflw->days ;

    if (n > 0)
        xlast = dates1[n - 1] ;
    else
        xlast = Cldr_YMD2Datestr((YYYYMMDD) 0) ;

    if (GetPlanFill(fix->irreg) > 0 || harm == False)
    {
        cb   = cbodd = ODDCOUP ;
        irr  = SIMPLE_MM ;
        nad  = 0 ;
        odd1 = oddn = NOODD ;
        harm = False ;
        trmu = 0 ;
    }

    /* Set switch for adding up AI - BRD specialty */
    add2 = False ;
    if (settle->brd == True)
    {
        ixx  = Cldr_FindDateIndex(dates1, n, &settle->aisttl, 0,
                                   SEARCH_BISECTION, NEXTINDEX) ;
        ixx  = Cflw_FindNextPmt(coupons1, n, ixx - 1) ;
        ixt  = Cldr_FindDateIndex(dates1, n, &settle->trade, 0,
                                   SEARCH_BISECTION, NEXTINDEX) ;
        ixt  = Cflw_FindNextPmt(coupons1, n, ixt - 1) ;

        /* This is when trade is before payday and Zinsvaluta is after */
        if (ixt < ixx && ixt < n &&
            Cldr_DateEQ(&settle->aisttl, &dates1[ixt]) == False)
            add2 = True ;

        if (accru->BRDfeb == True && settle->aisttl.m == 2 && 
            settle->settle.m == 3 &&
            Cldr_DaysBetweenDates(&settle->aisttl,
                                  &settle->settle, ACTACT, NULL) == (INTL) 1)   /* PMSTA-22396 - SRIDHARA � 160502 */
        {
            incl  = False ;
            basis = settle->settle ;
        }
    }

    accrual = False ;
    if (fix->accrfac > 0.00001 && fix->accrfac < 1.00001 &&
        GetPlanFill(fix->irreg) == 0)
    {
        accrual = True ;
        add2    = False ;
    }

    /* Adjust for Japanese Govnmts */
    if (fix->jgb == True && n > 0 && GetPlanFill(fix->irreg) == 0)
    {
        /* First adjust for 1 xtra day of accued interest */
        dcalc = Cldr_AddDays(&dcalc, (INTL) -1, ACTACT, NULL) ;    /* PMSTA-22396 - SRIDHARA � 160502 */
        cbodd = ODDCOUP ;
        cb    = ODDCOUP ;
        if (odd1 == NOODD)
            pseq->odd1 = LONGODD ;

        /* Now adjust for the final period */
        bus = holi->bus ;
        holi->bus = NEXT ;
        rl = False ;

        if (Cldr_DateEQ(&basis, &dates1[n - 1]) == True)
            rl = True ;

        if (Cldr_IsBusinessDate(&dates1[n - 1], holi->nholi,
                               holi->holidays) == False)
        {
            dates1[n - 1] = Cldr_NextBusinessDate(&dates1[n - 1], holi) ;
            last = dates1[n-1];
            if (oddn == NOODD)
                pseq->oddn = LONGODD ;
        }

        if (rl == True)
            basis = dates1[n - 1] ;

        holi->bus = bus ;
    }

    /* First check that there are coupons after the current date - next
       is the index for this coupon in the datearray. Watch out for
       prepaid coupons though. */
    next = ix = Cldr_FindDateIndex(dates1, n, &basis, 0,
                                    SEARCH_BISECTION, iConv) ;  /*  FPL-PMSTA00211-100826 replace NEXTINDEX by iConv for full coupon flag   */
    if (accrual == False)
        next = Cflw_FindNextPmt(coupons1, n, ix - 1) ;
    if (fix->prepaid == True && next >= n)
        next-- ;

    dnext = next ;

    /* No accrued interest if no future coupons or if basis is before
       interest start and this is not 'allowed' */
    if ((fabs(coupon) < PMT_TOL && nad == 0 && nirreg == 0) || next >= n ||
        (Cldr_DateLT(&basis, &dcalc) == True && pre == False))
    {
        aires.AI         = 0.0 ;
        aires.AIdays     = 0 ;
        aires.AI_per_day = 0 ;
		aires.AI_denom   = 0.0 ; /* PMSTA-20235 - CHU - 150528 : do not leave this uninitialized */
        aires.next       = Cldr_YMD2Datestr((YYYYMMDD) 0) ;
        if (dnext < n)
            aires.next = dates1[dnext] ;
        aires.exc = False ;

        return aires ;
    }

    /* Calculate X-status */
    if (fix->prepaid == False)
    {
        prev = Cflw_FindPrevPmt(coupons1, n, ix) ;
        if (prev >= 0)
            exc = Cflw_XdayCalc(&basis, &dates1[prev], &dates1[next],
                                &xlast, &accru->exr, &settle->xctrade, holi) ;
        else
            exc = Cflw_XdayCalc(&basis, &dcalc, &dates1[next],
                                &xlast, &accru->exr, &settle->xctrade, holi) ;

        if ((accrual == True) ||
            (iConv == SAMEINDEX))   /*  FPL-PMSTA00211-100826 for the full coupon flag  */
            exc = False ;
    }
    else
        exc = True ;

    /* Find index for first coupon payday */
    cix1 = 0 ;
    if (accrual == False)
        cix1 = Cflw_FindNextPmt(coupons1, n, -1) ;

    /* Find index for the second last coupon payday */
    cix2 = n - 2 ;
    if (accrual == False)
    {
        cix2 = Cflw_FindPrevPmt(coupons1, n, n) ;
        cix2 = Cflw_FindPrevPmt(coupons1, n, cix2) ;
    }

    /* If needed generate fictitious coupon days */
    fict_coupon1 = Cflw_Fictcoup(&dcalc, dates1, n, cbodd, pseq, &nf) ;

    /* Generate an array of eventdates - containing rate adjustment
       days, partly pay days, fict. days and paydays. */
    buffer2 = Cldr_MergeDates(adjustdays, nad, dates1, n, &ne) ;
    buffer1 = Cldr_MergeDates(buffer2, ne, fict_coupon1, nf, &ne1) ;
    Free_DATEARRAY(buffer2) ;
    buffer2 = Cldr_MergeDates(buffer1, ne1, ppdays, npp, &ne) ;

    event = Alloc_DATEARRAY(ne + 2) ;
    for (i = 0; i < ne ; i++)
        event[i] = buffer2[i] ;

    /* Find the index (in dates) for the last previous coupon payment.
       If next is the first coupon payment then prev will be -1 */
    prev = ix - 1 ;
    if (accrual == False)
        prev = Cflw_FindPrevPmt(coupons1, n, ix) ;

    brdacc = 0.0 ;
    if (add2 == True && prev >= 0)
        brdacc = coupons1[prev] ;

    /* Set date interval we wish to scan for 'events', ie. amortizations
       and rate adjustments. Also insert the start/end dates in the interval
       in the event array. */
    if (exc == True)
    {
        /* The bond is excoupon */
        from = basis ;
        to   = dates1[next] ;
        ne   = Cldr_InsertDate(event, ne, &from, &dum) ;
    }
    else
    {
        if (prev == -1)
        {
            if (Cldr_DateLT(&basis, &dcalc) == True)
            {
                /* We are before interest start */
                from = basis ;
                to   = dcalc ;
            }
            else
            {
                /* We are after interest start */
                from = dcalc ;
                to   = basis ;
            }

            ne   = Cldr_InsertDate(event, ne, &from, &dum) ;
            ne   = Cldr_InsertDate(event, ne, &to, &dum) ;
        }
        else
        {
            /* This is the standard case */
            from = dates1[prev] ;
            to   = basis ;
            ne   = Cldr_InsertDate(event, ne, &to, &dum) ;
        }
    }

    /* AIdays */
    if (add2 == True)
    {
        if (prev - 1 >= 0)
            AI1 = dates1[prev - 1] ;
        else
            AI1 = dcalc ;
    }
    else
        AI1 = from ;

    AI2 = to ;

    /* Set the anchor date for nonlinear compounding */
    if (irr != SIMPLE_MM)
    {
        if (prev == -1)
            compfrom = dcalc ;
        else
            compfrom = dates1[prev] ;

        /* Watch out here - this is delicate */
        if (incl == True)
			compfrom = Cldr_AddDays(&compfrom, (INTL)-1, cal, holi);  /* PMSTA-22396 - SRIDHARA � 160502 */
    }

    /* Set the coupon level.
       Are there any rate adjustments, if so then find the index
       in adjustdays/adjust - ixr. Remember decompounding.
       Irregular coupons are set below. */
    ixr = Cldr_FindDateIndex(adjustdays, nad, &from, 0,
                              SEARCH_BISECTION, NEXTINDEX) ;
	if (mktConvMethodEnblFlg == TRUE)
		coupon = cflw->ratesTab[n - 1];
    act_coupon = (ixr > 0 ? adjust[ixr - 1] : coupon) ;
    if (prev == -1)
        dcprev = dcalc ;
    else
        dcprev = dates1[prev] ;

    dcnext = dates1[next] ;
    act_coupon = Cflw_Decompound(act_coupon, months, harm, fix->decomp,
                                 &dcprev, &dcnext, cal, holi);  /* PMSTA-22396 - SRIDHARA � 160502 */

    /* Are there any partly payments, if so then find the index for next event
       in ppdays/ppamt - ixp. */
    ixp = (npp == 0 ? 0 : Cldr_FindDateIndex(ppdays, npp, &from, 0,
                                              SEARCH_BISECTION, NEXTINDEX)) ;

    /* Are there any fict. coupons, if so then find the index for next event
       in fict_coupon - ixf. */
    ixf = (nf == 0 ? 0 : Cldr_FindDateIndex(fict_coupon1, nf, &from, 0,
                                             SEARCH_BISECTION, NEXTINDEX)) ;

    /* Set the scaling factor for outstanding nominal - because the input
       cashflow is from emission. */
    debt  = Cflw_DebtPerDate(&from, n, dates1, amort1, False, 0) ;
    scale = (fabs(debt) > PRICE_TOL ? 100.0 / debt : 0.0) ;

    /* Set irregular coupon.
       The coupon is multiplied by scale to neutralize the the division
       by scale later in this function. The irregular coupon is already
       adjusted for amortisations.                                      */
    if (GetPlanFill(fix->irreg) > 0)
        act_coupon = coupons1[dnext] * scale ;

    /* Calculate the length of a year from this date (yfrom) and (possibly)
       to yto */
    if (prev >= 0)
    {
        if (exc == True && cix2 > -1 && cbodd == EVENCOUP && harm == True &&
            Cldr_DateLT(&dates1[cix2], &basis) == True && oddn == LONGODD)
            yfrom = fict_coupon1[nf - 1] ;
        else if (exc == True && cix2 > -1 && cbodd == EVENODD && harm == True &&
            Cldr_DateLT(&dates1[cix2], &basis) == True && oddn == LONGODD)
            yfrom = fict_coupon1[nf - 1] ;
        else
            yfrom = dates1[prev] ;
    }
    else
    {
        if (Cldr_DateLT(&basis, &dates1[cix1]) == True && cbodd == EVENCOUP &&
            harm == True && odd1 == SHORTODD)
            yfrom = Cldr_AddMonths(&dates1[cix1], -months, eom) ;

        else if (Cldr_DateLT(&basis, &dates1[cix1]) == True &&
                 harm == True && cbodd == EVENCOUP && odd1 == LONGODD)
        {
            if (exc == True)
                yfrom = fict_coupon1[0] ;
            else
                yfrom = Cldr_AddMonths(&fict_coupon1[0], -months, eom) ;
        }
        else
            yfrom = dcalc ;
    }

    /* Adjust dpy in a number of special cases */
    oddcase = False ;

	/* Before first coupon in short period */
	if (n && cbodd == EVENCOUP && harm == True &&
		Cldr_DateLT(&basis, &dates1[cix1]) == True && odd1 == SHORTODD)
	{
		yto = dates1[cix1];
		/* PMSTA-24182 - SRIDHARA � 160802 */
        if (cal != ACTACT) /*PMSTA-56548 accrued Interest is incorrect for ACTACT*/
        {
            oddcase = True;
        }
	}

    /* Before first coupon in long period */
    else if (n && cbodd == EVENCOUP && harm == True &&
             Cldr_DateLT(&basis, &dates1[cix1]) == True && odd1 == LONGODD)
    {
        if (exc == True)
            yto = dates1[cix1] ;
        else
            yto = fict_coupon1[0] ;
    }

    else if (n && cbodd == EVENODD && harm == True &&
             Cldr_DateLT(&basis, &dates1[cix1]) == True && odd1 == LONGODD)
    {
        if (exc == True)
            yto = dates1[cix1] ;
        else
            oddcase = True ;
    }

    /* In last long coupon period before fict. day */
    else if (n && cbodd == EVENCOUP && harm == True &&
             cix2 > -1 && Cldr_DateEQ(&yfrom, &dates1[cix2]) == True &&
             oddn == LONGODD)
        yto = Cldr_AddMonths(&yfrom, months, eom) ;

    else if (n && cbodd == EVENODD && harm == True &&
             cix2 > -1 && Cldr_DateEQ(&yfrom, &dates1[cix2]) == True &&
             oddn == LONGODD)
        yto = Cldr_AddMonths(&yfrom, months, eom) ;

    /* In last long coupon period after fict. day */
    else if (n && cbodd == EVENCOUP && harm == True &&
             cix2 > -1 && oddn == LONGODD &&
             Cldr_DateEQ(&yfrom, &fict_coupon1[nf - 1]) == True)
        yto = Cldr_AddMonths(&yfrom, months, eom) ;

    else if (n && cbodd == EVENODD && harm == True &&
             cix2 > -1 && oddn == LONGODD &&
             Cldr_DateEQ(&yfrom, &fict_coupon1[nf - 1]) == True)
        oddcase = True ;

    /* In last short period */
    else if (n && cbodd == EVENCOUP && harm == True &&
             cix2 > -1 && Cldr_DateEQ(&yfrom, &dates1[cix2]) == True &&
             oddn == SHORTODD)
        yto = Cldr_AddMonths(&yfrom, months, eom) ;

    /* Odd issue after first odd coupon */
    else if (n && cb == EVENCOUP && harm == True && odd1 != NOODD &&
             Cldr_DateLT(&basis, &dates1[cix1]) == False)
        yto = dates1[next] ;

    else if (n && cb == EVENODD && harm == True && odd1 != NOODD &&
             Cldr_DateLT(&basis, &dates1[cix1]) == False)
        yto = dates1[next] ;

    /* Odd issue before second last coupon */
    else if (n && cb == EVENCOUP && harm == True &&
             cix2 > -1 && oddn != NOODD &&
             Cldr_DateLT(&yfrom, &dates1[cix2]) == True)
        yto = dates1[next] ;

    else if (n && cb == EVENODD && harm == True &&
             cix2 > -1 && oddn != NOODD &&
             Cldr_DateLT(&yfrom, &dates1[cix2]) == True)
        yto = dates1[next] ;

    /* Noodd issue in any period */
    else if (n && cb == EVENCOUP && harm == True && odd1 == NOODD &&
             oddn == NOODD)
        yto = dates1[next] ;

    else if (n && cb == EVENODD && harm == True && odd1 == NOODD &&
             oddn == NOODD)
        yto = dates1[next] ;

    else if (harm == True && cb == EQUALCOUP)
        yto = dates1[next] ;
    else
        oddcase = True ;

    /* Compute days per year. */
    if (oddcase == False)
	{
		/* PMSTA-22396 - SRIDHARA � 160602 */
		/* PMSTA-45702 - SENTHILKUMAR - 31082021*/
		if (cal == BUS252 || (mktConvMethodEnblFlg == TRUE && (cal == ACTACT || cal == ACT360 || cal == ACT365)))/*PMSTA-45702 - Kramadevi - 26082021*/
		{
			dpy = Cldr_DaysPerYear(&yfrom, &yto, 0, cal, LAST, holi);  /* PMSTA-22396 - SRIDHARA � 160502 */
		}
		else if (cal == ACT360)  /*PMSTA-55909 The accrued interest calculation in TAP and T24 are different.*/
		{
			dpy = Cldr_DaysPerYear(&yfrom, &yto, 0, cal, eom, holi);
		}
		else
		{
			dpy = Cldr_DaysPerYear(&yfrom, &yto, months, cal, LAST, holi);  /* PMSTA-22396 - SRIDHARA � 160502 */
		}
	}
    else
    {
        if (GetPlanFill(fix->irreg) > 0)
            dpy = (FL64) Cldr_DaysBetweenDates(&yfrom, &dates1[next], cal, holi) ;   /* PMSTA-22396 - SRIDHARA � 160502 */
        else
            /* ODDCOUP day fractions */
            dpy = Cldr_DaysPerYear(&yfrom, &dates1[next], 0, cal, eom, holi) ;   /* PMSTA-22396 - SRIDHARA � 160502 */
    }

    /* Index (in dates) for next potential amortization. */
    ixa = prev + 1 ;

    /* Find the indices in events for the first/last 'event' */
    prev = Cldr_FindDateIndex(event, ne, &from, 0,
                               SEARCH_BISECTION, SAMEINDEX) ;

    next = Cldr_FindDateIndex(event, ne, &to, prev,
                               SEARCH_BISECTION, SAMEINDEX) ;

    /* Update index for the next potential amortisation to be after 
       first 'event' */
    while (ixa < n && Cldr_DateLT(&dates1[ixa], &event[prev+1]))
        ixa++;

    /* Find the nominal saldo at starting time - note that we assume that all
       partly payments are being paid before the first amortization.
       Beware of accruals. */

    if (accrual == True)
    {
        i = Cldr_FindDateIndex(dates1, n, &basis, 0,
                                SEARCH_BISECTION, NEXTINDEX) - 1 ;
        if (i >= 0)
        {
            fix->cbase = cb ;
            fix->cbodd = cbodd ;
            fix->lastaccr = dates1[i] ;

            plana.day = dates1 ;
            plana.f64 = amort1 ;
            plana.filled = i + 1 ;

			coups = Cflw_GenrCoupons(fix, &plana, dates1, i + 1, pp, pseq, holi);   /* PMSTA-22396 - SRIDHARA � 160502 */
            acr   = coups[i] - coupons1[i] ;
            saldo = 1.0 + acr / 100.0 ;

/*
printf("saldo %lf acr %lf\n", saldo, acr) ;
*/

            Free_FL64ARRAY(coups) ;
            fix->lastaccr = last ;

            AI1 = dcalc ;
        }
        else
        {
            saldo = 1.0 ;
            acr   = 0.0 ;
        }
    }
    else
    {
        for (saldo = 1.0, i = npp - 1 ; i >= ixp ; i--)
            saldo -= 0.01 * ppamt[i] ;
    }

    /* Loop over the eventdates and accumulate (accrue) the interest until
       we find the basis date. Note that if the bond is ex-coupon, we accrue
       from basis till next coupon.
       Remember to initialize for the case when both days in the period are
       inclusive. */
    ai = 0.0 ;
    if (incl == True && irr == SIMPLE_MM)
    {
        ai = saldo * Yld_Ann2Per(act_coupon, 1.0 / dpy, qbas, irr) ;
        if (exc == True || Cldr_DateLT(&basis, &dcalc) == True)
            ai *= -1.0 ;
    }

    /* Now detect if this is a Canadian Government Bond in a period with
       184 days and the valuation date is the 183'rd date in the period !! */
    CGB183_184 = False ;
    if (accru->CGB184 == True)
    {
		/* PMSTA-22396 - SRIDHARA � 160502 */
        dum  = (INTI) Cldr_DaysBetweenDates(&event[prev], &dates1[dnext], cal, holi) ;
        dum1 = (INTI) Cldr_DaysBetweenDates(&event[prev], &basis, cal, holi) ;
        if (dum == 184 && dum1 == 183)
            CGB183_184 = True ;
    }

    for (prevdate = from, i = prev + 1 ; i <= next ; i++)
    {
        datex = date = event[i];

        /*PMSTA-25965 - 060217 - Sridhara*/
        if (cal == EU30360 || cal == US30360)
        {
            if ((odd1 == LONGODD) && (prevdate.d < 30)) //Instrument begin date should be less than 30th 
            {
                if ((datex.d > 30) && (basis.d < 31))   //Instrument frequency "semester", Valuation domain date < 31st 
                {
                	datex.d = 30;
                }
                if ((datex.d == 30) && (basis.d == 31) && (months == 1))   // Instrument frequency "month", Valuation domain date = 31st  
                {
                	datex.d = 29;
                }
            }
        }
/*
printf("%ld %ld %lf\n",
Cldr_DaysBetweenDates(&prevdate, &date, cal), Cldr_Datestr2YMD(&date), dpy) ;
*/
        if (Cldr_DateLT(&last, &date) == True)
            AI2 = datex = last ;

        /* Accumulate the saldo */
        if (irr == SIMPLE_MM)
        {
            if (CGB183_184 == False)
                /* This is the standard case - just accumulate the saldo */
                ai += saldo * act_coupon / dpy *
                      (FL64) Cldr_DaysBetweenDates(&prevdate, &datex, cal, holi) ; /* PMSTA-22396 - SRIDHARA � 160502 */
            else
                /* This is CGB on day 183 in a period of 184 days */
                ai += saldo * act_coupon / dpy * 181.5 ;
        }
        else
        {
            /* The following code handles a number of REALLY unusual cases.
               Normally only one loop is performed and the accrued interest
               is accumulated exponentially. In the case with irregular
               amortizations and rateadjustments in between coupons some
               systematic handling of compounded interest is needed. This is
               our proposition ! */

            dai  = 0.0 ;
            if (incl == True && i == prev + 1 && exc == False &&
                Cldr_DateLE(&dcalc, &basis) == True)
                term = 0.0 ;
            else
                term = ((FL64) Cldr_DaysBetweenDates(&compfrom,
                                                     &prevdate, cal, holi)) / dpy ;  /* PMSTA-22396 - SRIDHARA � 160502 */
            dai -= Yld_Ann2Per(act_coupon, term, qbas, irr) ;

            if (incl == True && i == next && (exc == True ||
                Cldr_DateEQ(&dcalc, &datex) == True))
            {
				/* PMSTA-22396 - SRIDHARA � 160502 */
                day  = Cldr_AddDays(&datex, (INTL) -1, cal, holi) ;
                term = ((FL64) Cldr_DaysBetweenDates(&compfrom, &day, cal, holi))/dpy;   
            }
            else
            {
                dd   = (FL64) Cldr_DaysBetweenDates(&compfrom, &datex, cal, holi) ;  /* PMSTA-22396 - SRIDHARA � 160502 */
                term = dd / dpy ;
            }

            dai += Yld_Ann2Per(act_coupon, term, qbas, irr) ;
            ai  += saldo * dai ;
        }

        /* Fict. coupon day. - change days_per_year */
        if (ixf < nf && Cldr_DateEQ(&date, &fict_coupon1[ixf]) == True)
        {
            if (cbodd == EVENCOUP && harm == True)
            {
				/* REF9954 - TEB - 041220 - Purify detected that cix2 can be -1 => possibility of crash
				                            then and else clause are identic !! */
/*
                if (nf && Cldr_DateLT(&dates1[cix2], &date) == True &&
                    oddn == LONGODD)
                {
 */
                    /* This handles last period */
/*
                    day = Cldr_AddMonths(&date, months, eom) ;
                    dpy = Cldr_DaysPerYear(&date, &day, months, cal, eom) ;
                }
                else
                {
 */
                    /* This handles the first period */
                    day = Cldr_AddMonths(&date, months, eom) ;
					if (cal == BUS252)    /* PMSTA-27061 - 100517 - Sridhara */
					{
						dpy = Cldr_DaysPerYear(&date, &day, 0, cal, eom, holi);  /* PMSTA-22396 - SRIDHARA � 160502 */
					}
					else if (cal == ACT360)  /*PMSTA-55909 The accrued interest calculation in TAP and T24 are different.*/
					{
						dpy = Cldr_DaysPerYear(&yfrom, &yto, 0, cal, eom, holi);
					}

					else
					{
						dpy = Cldr_DaysPerYear(&date, &day, months, cal, eom, holi);  /* PMSTA-22396 - SRIDHARA � 160502 */
					}
                  /* 
                }
 */
            }

            else if (cbodd == EVENODD)
            {
                /* After last fict day in final long */
                if (nf && Cldr_DateEQ(&fict_coupon1[nf - 1], &date) == True &&
                    oddn == LONGODD)
                {
                    if (next > cflw->filled)
                    {
                      /* dates1[next] is undefined do something sensible ! 
                         Adding 1 months was chosen at random ! */
                      dummy  = Cldr_AddMonths(&date, 1, eom) ;
                      dpy = Cldr_DaysPerYear(&fict_coupon1[nf - 1],
                                             &dummy, 0, cal, eom, holi) ;  /* PMSTA-22396 - SRIDHARA � 160502 */
                    }
                    else
                      dpy = Cldr_DaysPerYear(&fict_coupon1[nf - 1],
                                             &dates1[next], 0, cal, eom, holi) ;   /* PMSTA-22396 - SRIDHARA � 160502 */
                }

                /* Otherwise */
                else
                {
                    day  = Cldr_AddMonths(&date, months, eom) ;
                    dpy = Cldr_DaysPerYear(&date, &day, months, cal, eom, holi) ;   /* PMSTA-22396 - SRIDHARA � 160502 */
                }
            }

            ixf++ ;
        }

        /* Rate adjust day. */
        if (ixr < nad && Cldr_DateEQ(&date, &adjustdays[ixr]) == True)
        {
            act_coupon = adjust[ixr++] ;
            act_coupon = Cflw_Decompound(act_coupon, months, harm, fix->decomp,
                                         &dcprev, &dcnext, cal, holi) ;   /* PMSTA-22396 - SRIDHARA � 160502 */
        }

        /* Amortization day. */
        if (ixa < n && Cldr_DateEQ(&date, &dates1[ixa]) == True && i != next)
            saldo -= 0.01 * amort1[ixa++] * scale ;

        /* Partly payment day. */
        if (ixp < npp && Cldr_DateEQ(&date, &ppdays[ixp]) == True)
            saldo += 0.01 * ppamt[ixp++] ;

        prevdate = datex ;
    }
/*
printf("ai %lf\n", ai) ;
*/
    if (accrual == True)
        ai += acr ;

    if (add2 == True)
        ai += brdacc ;

    /* Now check the outstanding amount at the evaluation day in order to
       rescale the accrued such that it corresponds to 100 outstanding at
       evaluation day. */
    debt = Cflw_DebtPerDate(&basis, n, dates1, amort1, False, 0) ;

    /* SWI 9811: Outstanding at evaluation day, post amortisations!
    if (ixa < n && Cldr_DateEQ(&basis, &dates1[ixa]) == True)
        debt += amort1[ixa] ; */

    if (fabs(scale * debt) > PRICE_TOL)
        ai /= scale * 0.01 * debt ;

    AId = (INTI) Cldr_DaysBetweenDates(&AI1, &AI2, cal, holi) ;
    if (incl == True)
        ++AId ;

    /* Change the sign if ex-coupon or prior to interest start */
    if (exc == True || Cldr_DateLT(&basis, &dcalc) == True)
    {
        ai  *= - 1.0 ;
        AId *= - 1 ;
    }

    /* Set output */
    aires.AI   = ai ;
    aires.exc  = exc ;
    aires.next = Cldr_YMD2Datestr((YYYYMMDD) 0) ;
    if (dnext < n)
        aires.next = dates1[dnext] ;
    if (settle->brd == True)
        aires.AIdays = GETMAX(0, AId) ;
    else
        aires.AIdays = AId ;
    if (AId != 0)
        aires.AI_per_day = ai / (FL64) AId ;
    else
        aires.AI_per_day = 0.0 ;

	aires.AI_denom = dpy;	/* PMSTA-10628 - RAK - 110110 */

    /* Clean up and return. */
    Free_DATEARRAY(fict_coupon1) ;
    Free_DATEARRAY(event) ;
    Free_DATEARRAY(buffer1) ;
    Free_DATEARRAY(buffer2) ;
/*
printf("ai %lf\n", ai) ;
*/
    return aires ;
}

/*** undefines *********************************************************/

#undef PRICE_TOL

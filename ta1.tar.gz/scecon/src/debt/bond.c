/* SCID @(#)bond.c	1.25 (SimCorp) 99/11/02 14:53:07 */

/************************************************************************
*
*       Project         SCecon
*
*       file name       bond.c
*
*       contains        bond calculations
*
************************************************************************/

/*** includes **********************************************************/
#include <bond.h>


/*** defines  **********************************************************/
#define TERM_MIN  (FL64)     0.0000001

#define YTM_ACC   (FL64)     0.0000000001
#define YTM_MIN   (FL64)   -99.9999
#define YTM_MAX   (FL64)   100.0
#define YTM_MAXIT (INTI)   150
#define YTM_FREQ  (INTI)     5
#define YTM_DAMP  (FL64)     1.0
#define YTM_GUESS (FL64)    10.0
#define YTM_TOL   (FL64)     0.00001

#define OAS_MAXIT   (INTI) 100
#define OAS_EPS     (FL64)   0.0001
#define OAS_TOL     (FL64)   0.000001
#define OAS_MIN     (FL64) -99.9999
#define OAS_MAX     (FL64) 100.0
#define OAS_FREQ    (INTI)   3
#define P_TOL       (FL64)   0.0001

/*,,SOH,,
*************************************************************************
*
*               Bond_YTM2Yield()
*
*   interface   #include <bond.h>
*               BOOLE Bond_YTM2Yield(TRADEINFO  *trade,
*                                    FIXPAY     *fixp,
*                                    YTMCONV    *ytmc,
*                                    HOLI_STR   *holi,
*                                    ITERCTRL   *ictrl,
*                                    FL64       *ytm) ;
*
*   general     The function calculates the Yield to maturity
*               for the bond with respect to the conventions defined.
*
*               The conventions defined should be sufficiently general
*               to handle most YTM setup's.
*
*   input       TRADEINFO *trade        The trade data
*
*               FIXPAY    *fixp         The bond definition
*
*               YTMCONV   *ytmc         The conventions defined for
*                                       calculating the YTM.
*
*               HOLI_STR  *holi         Container for data on business
*                                       day convention and non-week-end
*                                       holidays.
*                                       Used to calculate businessday
*                                       adjusted yield.
*
*               ITERCTRL  *ictrl        Iteration control
*
*   output      FL64      *ytm          The YTM calculated in %
*
*   returns     True if all is OK, False if not.
*
*   diagnostics
*
*   see also
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/

BOOLE Bond_YTM2Yield(TRADEINFO* trade,
                        FIXPAY*    fixp,
                        YTMCONV*   ytmc,
                        HOLI_STR*  holi,
                        ITERCTRL*  ictrl,
                        FL64*      ytm)
{
    CFLWARRAY xcflw ;
    BOOLE     ok ;
    HOLI_STR  hol ;
    FL64      price ;
    FIXPAY    fxp ;

    price = trade->price ;

    Math_LaGuerre(trade->settle.y, trade->settle.m, 
      trade->settle.d);

    /* Generate cashflow */
    fxp   = Bond_YTM_Prep(trade, fixp, ytmc) ;
	/* PMSTA-22396 - SRIDHARA � 160502 */
	if (fixp->accru.cal == BUS252)
	{
		xcflw = Bond_GenrCflw(trade, &fxp, holi);
	}
	else
	{
		hol = bond_set_holi(holi, &fxp.fix);
		xcflw = Bond_GenrCflw(trade, &fxp, &hol);
	}

    /* Calculate yield */
    ok = Cflw_YTM2Yield(price, xcflw, ytmc, &fxp.cday, fxp.fix.fix_rate, 
                        &fxp.repay.pp, holi, ictrl, ytm) ;

    Free_CFLWARRAY(xcflw, 1) ;

    return ok ;
}


/*,,SOH,,
*************************************************************************
*
*               Cflw_YTM2Yield()
*
*   interface   #include <bond.h>
*               BOOLE Cflw_YTM2Yield(FL64       price,
*                                    CFLW_STR   *xcflw,
*                                    YTMCONV    *ytmc,
*                                    PAYDAYDEF  *pday,
*                                    FL64       coupon,
*                                    PP_STR     *pp,
*                                    HOLI_STR   *holi,
*                                    ITERCTRL   *ictrl,
*                                    FL64       *ytm) ;
*
*   general     The function calculates the Yield to maturity
*               for the bond with respect to the conventions defined.
*
*               The conventions defined should be sufficiently general
*               to handle most YTM setup's.
*
*               The cashflow on which to calculate yield should NOT
*               have been adjusted for non-businessdays prior to calling*
*               this routine. This is performed in this routine.
*
*               A special case occur when the coming payment is ex.
*               If the first fractional period is till the 'empty'
*               payment, the 'empty' payment must be visible in the in
*               xcflw (use fill = True in Bond_GenrPeriod().
*               If this payment is ignored, when calculating YTM, then
*               use fill = False in Bond_GenrPeriod(). In this case
*               the first fractional period is longer than a normal
*               coupon period.
*
*   input       FL64      price         The clean price of the bond
*
*               CFLW_STR  *xcflw        The extracted cashflow from
*                                       the relevant period.
*                                       Must have the format defined
*                                       by Bond_GenrPeriod().
*                                       Cashflow is NOT adjusted for
*                                       businessdays.
*                                       The outstanding debt on the
*                                       bond must be 100.
*
*               YTMCONV   *ytmc         The conventions defined for
*                                       calculating the YTM.
*
*               PAYDAYDEF *pday         Pointer to the description of
*                                       the payday sequence.
*
*               FL64      coupon        The annually coupon (%).
*                                       Only used if ytmc->irr = JGBYTM
*
*               PP_STR    *pp           Partly Paid setup. pp->pp_price
*                                       is not used.
*                                       Enter NULL if not needed.
*
*               HOLI_STR  *holi         Container for data on business
*                                       day convention and non-week-end
*                                       holidays.
*                                       Used to calculate businessday
*                                       adjusted yield.
*
*               ITERCTRL  *ictrl        Iteration control
*
*   output      FL64      *ytm          The YTM calculated in %
*
*   returns     True if all is OK, False if not.
*
*   diagnostics
*
*   see also
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/

BOOLE Cflw_YTM2Yield(FL64        price,
                        CFLW_STR*   xcflw,
                        YTMCONV*    ytmc,
                        PAYDAYDEF*  pday,
                        FL64        coupon,
                        PP_STR*     pp,
                        HOLI_STR*   holi,
                        ITERCTRL*   ictrl,
                        FL64*       ytm)
{
    return RepoCflw_YTM2Yield(price, xcflw, NULL, ytmc, pday, coupon, 
                              pp, holi, ictrl, ytm) ;
}


/*,,SOH,,
*************************************************************************
*
*               RepoCflw_YTM2Yield()
*
*   interface   #include <bond.h>
*               BOOLE RepoCflw_YTM2Yield(FL64       price,
*                                        CFLW_STR   *xcflw,
*                                        DATESTR    *matur,
*                                        YTMCONV    *ytmc,
*                                        PAYDAYDEF  *pday,
*                                        FL64       coupon,
*                                        PP_STR     *pp,
*                                        HOLI_STR   *holi,
*                                        ITERCTRL   *ictrl,
*                                        FL64       *ytm) ;
*
*   general     The function calculates the Yield to maturity
*               for the bond with respect to the conventions defined.
*
*               The cashflow used can be a period cashflow, where the
*               end date (matur) is befre the real maturity.
*
*               The conventions defined should be sufficiently general
*               to handle most YTM setup's.
*
*               The cashflow on which to calculate yield should NOT
*               have been adjusted for non-businessdays prior to calling*
*               this routine. This is performed in this routine.
*
*   input       FL64      price         The clean price of the bond
*
*               CFLW_STR  *xcflw        The extracted cashflow from
*                                       the relevant period.
*                                       Must have the format defined
*                                       by Bond_GenrPeriod().
*                                       Cashflow is NOT adjusted for
*                                       businessdays.
*                                       The outstanding debt on the
*                                       bond must be 100.
*
*               DATESTR   *matur        The maturity date for the flow.
*
*               YTMCONV   *ytmc         The conventions defined for
*                                       calculating the YTM.
*
*               PAYDAYDEF *pday         Pointer to the description of
*                                       the payday sequence.
*
*               FL64      coupon        The annually coupon (%).
*                                       Only used if ytmc->irr = JGBYTM
*
*               PP_STR    *pp           Partly Paid setup. pp->pp_price
*                                       is not used.
*                                       Enter NULL if not needed.
*
*               HOLI_STR  *holi         Container for data on business
*                                       day convention and non-week-end
*                                       holidays.
*                                       Used to calculate businessday
*                                       adjusted yield.
*
*               ITERCTRL  *ictrl        Iteration control
*
*   output      FL64      *ytm          The YTM calculated in %
*
*   returns     True if all is OK, False if not.
*
*   diagnostics
*
*   see also
*
*************************************************************************
,,EOH,,*/

BOOLE RepoCflw_YTM2Yield(FL64        price,
                         CFLW_STR*   xcflw,
                         DATESTR*    matur,
                         YTMCONV*    ytmc,
                         PAYDAYDEF*  pday,
                         FL64        coupon,
                         PP_STR*     pp,
                         HOLI_STR*   holi,
                         ITERCTRL*   ictrl,
                         FL64*       ytm)
{
    INTI      i, npp, ix, basis ;
    IRRCONV   irr ;
    PMTARRAY  pmt ;
    BOOLE     ok ;
    FL64      m, debt, dum, life ;
    ITERCTRL  ctrl ;

    ctrl = *ictrl ;

    if (ytmc->irr == JGBYTM || ctrl.use_init_guess == False)
    {
        life = Cldr_TermBetweenDates(&xcflw->days[0], &pday->last,
                                     0, ytmc->cal_first, SAME, holi) ;   /* PMSTA-22396 - SRIDHARA � 160502 */
        *ytm = TVMunit_JGBYTM2rate(price / 100.0, life, coupon) ;

        if (ytmc->irr == JGBYTM)
            return True ;
        else if (xcflw->filled > 2 && *ytm > 1.0)
        {
            /* Here we initialise for YTM Calculation */
          ctrl.init_guess = (ictrl->use_init_guess ? ctrl.init_guess : *ytm) ;
          ctrl.use_init_guess = True ;
        }
    }

    ok = False ;
    if (xcflw->filled > 0)
    {
        /* Find terms */
        pmt   = Bond_Cflw2Pmt(&xcflw->days[0], xcflw, ytmc, pday, holi) ;
        basis = disc_set_qbas(ytmc->qb_ytm) ;
        irr   = Bond_Set_IRRCONV(xcflw, ytmc->irr, pday->pseq.eom) ;

        m = 0.0 ;
        if (ytmc->irr == SIMPLE_REPO && matur != NULL)
        {
            m = Cldr_TermBetweenDates(&xcflw->days[0], matur, 0,
                                      ytmc->cal_first, LAST, holi) ;   /* PMSTA-22396 - SRIDHARA � 160502 */
            
            for (dum = 0.0, i = 0; i < xcflw->filled; i++)
                dum += pmt->payment[i] ;

            if (pmt->count > 0)
            {
                /* Do a qualified guess */
                ctrl.init_guess = (ictrl->use_init_guess ? ctrl.init_guess :
                    (dum / (price - xcflw->coupon[0]) - 1.0) /
                          pmt->term[pmt->count - 1] * 100.0 ) ;
                ctrl.use_init_guess = True ;
            }
        }

        /* Find purchased amount (in %) for partly paid bonds */
        npp = GetPPFill(pp) ;
        if (npp > 0)
        {
            ix = Cldr_FindDateIndex(pp->ppmts->day, npp, &xcflw->days[0], 0,
                                     SEARCH_BISECTION, NEXTINDEX) ;
            debt = pp->ppmts->f64[0] / 100.0 ;
            for (i = 1; i < ix; i++)
                 debt += pp->ppmts->f64[i] / 100.0 ;
        }
        else
            debt = 1.0 ;

        price *= debt ;
        price -= xcflw->coupon[0] ;

        ok = bond_price2yield(price, basis, irr, &dum, 100.0, pmt,
                              m, &ctrl, ytm, holi) ;   /* PMSTA-22396 - SRIDHARA � 160502 */

        Free_PMTARRAY(pmt, 1) ;
    }

    return ok ;
}


/*,,SOH,,
*************************************************************************
*
*               Bond_Cflw2Pmt()
*
*   interface   #include <bond.h>
*               PMTARRAY Bond_Cflw2Pmt(DATESTR    *analys,
*                                      CFLW_STR   *xcflw,
*                                      YTMCONV    *ytmc,
*                                      PAYDAYDEF  *pday,
*                                      HOLI_STR   *holi) ;
*
*   general     Bond_Cflw2Pmt() transforms a CFLW_STR to a PMTARRAY
*               with respect to the conventions defined.
*
*               The conventions defined should be sufficiently general
*               to handle most YTM setup's.
*
*               The cashflow on which to calculate yield should NOT
*               have been adjusted for non-businessdays prior to calling*
*               this routine. This is performed in this routine.
*
*               A special case occur when the coming payment is ex.
*               If the first fractional period is till the 'empty'
*               payment, the 'empty' payment must be visible in the in
*               xcflw (use fill = True in Bond_GenrPeriod().
*               If this payment is ignored, when calculating YTM, then
*               use fill = False in Bond_GenrPeriod(). In this case
*               the first fractional period is longer than a normal
*               coupon period.
*
*               The first payment in the output is returned as empty
*               at term x, where x is the 'term' bewteen analys and
*               xcflw->days[0], which is usually 0.
*
*   input       DATESTR   *analys       The date of analysis, may be
*                                       equal to or less than
*                                       xcflw->days[0].
*
*               CFLW_STR  *xcflw        The extracted cashflow from
*                                       the relevant period.
*                                       Must have the format defined
*                                       by Bond_GenrPeriod().
*                                       Cashflow is NOT adjusted for
*                                       businessdays.
*                                       The outstanding debt on the
*                                       bond must be 100.
*
*               YTMCONV   *ytmc         The conventions defined for
*                                       calculating the YTM.
*
*               PAYDAYDEF *pday         Pointer to the description of
*                                       the payday sequence.
*
*               HOLI_STR  *holi         Container for data on business
*                                       day convention and non-week-end
*                                       holidays.
*                                       Used to calculate businessday
*                                       adjusted yield.
*
*   output
*
*   returns     Pointer to the PMTARRAY that holds the pmt_list. Alloca-*
*               ted as Alloc_PMTARRAY(1, xcflw->filled) ;
*
*   diagnostics
*
*   see also
*
*************************************************************************
,,EOH,,*/

PMTARRAY Bond_Cflw2Pmt(DATESTR* analys,
                       CFLW_STR*   xcflw,
                       YTMCONV*    ytmc,
                       PAYDAYDEF*  pday,
                       HOLI_STR*   holi)
{
    INTI      i ;
    PMTARRAY  pmt ;
    FL64ARRAY terms ;

    pmt   = Alloc_PMTARRAY(1, xcflw->filled) ;
    terms = Bond_GenrTerms(analys, xcflw, ytmc, pday, holi) ;

    for (i = 0; i < xcflw->filled; i++)
    {
        if (i > 0)
            pmt[0].payment[i] = xcflw->coupon[i] + xcflw->repay[i] ;

        pmt[0].term[i] = terms[i] ;
    }

    pmt[0].count = xcflw->filled ;

    Free_FL64ARRAY(terms) ;

    return pmt ;
}


/*,,SOH,,
*************************************************************************
*
*               Cflw_YTM2Price()
*
*   interface   #include <bond.h>
*               FL64 Cflw_YTM2Price(FL64       ytm,
*                                   CFLW_STR   *xcflw,
*                                   YTMCONV    *ytmc,
*                                   PAYDAYDEF  *pday,
*                                   FL64       coupon,
*                                   PP_STR     *pp,
*                                   HOLI_STR   *holi,
*                                   RISKCONV   risk,
*                                   BOOLE      modf,
*                                   FL64       *dp,
*                                   FL64       *ddp) ;
*
*   general     The function calculates the price given YTM for
*               a bond with respect to the conventions defined. Also the*
*               dollar duration and dollar convexity can be calculated.
*
*               The conventions defined should be sufficiently general
*               to handle most YTM setup's.
*
*               The cashflow on which to calculate yield should NOT
*               have been adjusted for non-businessdays prior to calling*
*               this routine. This is performed in this routine.
*
*               A special case occur when the coming payment is ex.
*               If the first fractional period is till the 'empty'
*               payment, the 'empty' payment must be visible in the in
*               xcflw (use fill = True in Bond_GenrPeriod().
*               If this payment is ignored, when calculating YTM, then
*               use fill = False in Bond_GenrPeriod(). In this case
*               the first fractional period is longer than a normal
*               coupon period.
*
*   input       FL64      ytm           The Yield to Maturity of bond
*
*               CFLW_STR  *xcflw        The extracted cashflow from
*                                       the relevant period.
*                                       Must have the format defined
*                                       by Bond_GenrPeriod().
*                                       Cashflow is NOT adjusted for
*                                       businessdays.
*                                       The outstanding debt on the
*                                       bond must be 100.
*
*               YTMCONV   *ytmc         The conventions defined for
*                                       calculating the YTM.
*
*               PAYDAYDEF *pday         Pointer to the description of
*                                       the payday sequence.
*
*               FL64      coupon        The annually coupon (%).
*                                       Only used if ytmc->irr = JGBYTM
*
*               PP_STR    *pp           Partly Paid setup. pp->pp_price
*                                       is not used.
*                                       Enter NULL if not needed.
*
*               HOLI_STR  *holi         Container for data on business
*                                       day convention and non-week-end
*                                       holidays.
*                                       Used to calculate businessday
*                                       adjusted yield.
*
*               RISKCONV  risk          The risk setup.
*
*               BOOLE     modf          True means that ratios are modi-*
*                                       (i.e. scaled with the dirty
*                                       price), False means direct
*                                       derivatives.
*
*   output      FL64      *dp           The dollar duration
*
*               FL64      *ddp          The dollar convexity
*
*   returns     The clean price of the bond on the settlement date.
*
*   diagnostics
*
*   see also    Bond_YTM2Price()
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/

FL64 Cflw_YTM2Price(FL64        ytm,
                        CFLW_STR*   xcflw,
                        YTMCONV*    ytmc,
                        PAYDAYDEF*  pday,
                        FL64        coupon,
                        PP_STR*     pp,
                        HOLI_STR*   holi,
                        RISKCONV    risk,
                        BOOLE        modf,
                        FL64*       dp,
                        FL64*       ddp)
{
    return RepoCflw_YTM2Price(ytm, xcflw, NULL, ytmc, pday, coupon, 
                              pp, holi, risk, modf, dp, ddp) ;
}


/*,,SOH,,
*************************************************************************
*
*               RepoCflw_YTM2Price()
*
*   interface   #include <bond.h>
*               FL64 RepoCflw_YTM2Price(FL64   ytm,
*                                   CFLW_STR   *xcflw,
*                                   DATESTR    *matur,
*                                   YTMCONV    *ytmc,
*                                   PAYDAYDEF  *pday,
*                                   FL64       coupon,
*                                   PP_STR     *pp,
*                                   HOLI_STR   *holi,
*                                   RISKCONV   risk,
*                                   BOOLE      modf,
*                                   FL64       *dp,
*                                   FL64       *ddp) ;
*
*   general     The function calculates the price given YTM for
*               a repo cashflow with respect to the conventions defined.*
*               Also the dollar duration and dollar convexity can be
*               calculated.
*
*               The conventions defined should be sufficiently general
*               to handle most YTM setup's.
*
*               The cashflow on which to calculate yield should NOT
*               have been adjusted for non-businessdays prior to calling*
*               this routine. This is performed in this routine.
*
*               A special case occur when the coming payment is ex.
*               If the first fractional period is till the 'empty'
*               payment, the 'empty' payment must be visible in the in
*               xcflw (use fill = True in Bond_GenrPeriod().
*               If this payment is ignored, when calculating YTM, then
*               use fill = False in Bond_GenrPeriod(). In this case
*               the first fractional period is longer than a normal
*               coupon period.
*
*   input       FL64      ytm           The Yield to Maturity of bond
*
*               CFLW_STR  *xcflw        The extracted cashflow from
*                                       the relevant period.
*                                       Must have the format defined
*                                       by Bond_GenrPeriod().
*                                       Cashflow is NOT adjusted for
*                                       businessdays.
*                                       The outstanding debt on the
*                                       bond must be 100.
*
*               DATESTR   *matur        The maturity date for the flow.
*
*               YTMCONV   *ytmc         The conventions defined for
*                                       calculating the YTM.
*
*               PAYDAYDEF *pday         Pointer to the description of
*                                       the payday sequence.
*
*               FL64      coupon        The annually coupon (%).
*                                       Only used if ytmc->irr = JGBYTM
*
*               PP_STR    *pp           Partly Paid setup. pp->pp_price
*                                       is not used.
*                                       Enter NULL if not needed.
*
*               HOLI_STR  *holi         Container for data on business
*                                       day convention and non-week-end
*                                       holidays.
*                                       Used to calculate businessday
*                                       adjusted yield.
*
*               RISKCONV  risk          The risk setup.
*
*               BOOLE     modf          True means that ratios are modi-*
*                                       (i.e. scaled with the dirty
*                                       price), False means direct
*                                       derivatives.
*
*   output      FL64      *dp           The dollar duration
*
*               FL64      *ddp          The dollar convexity
*
*   returns     The clean price of the repo on the settlement date.
*
*   diagnostics
*
*   see also    Bond_YTM2Price()
*               Cflw_YTM2Price()
*
*************************************************************************
,,EOH,,*/

FL64 RepoCflw_YTM2Price(FL64        ytm,
                            CFLW_STR*   xcflw,
                            DATESTR*    matur,
                            YTMCONV*    ytmc,
                            PAYDAYDEF*  pday,
                            FL64        coupon,
                            PP_STR*     pp,
                            HOLI_STR*   holi,
                            RISKCONV    risk,
                            BOOLE       modf,
                            FL64*       dp,
                            FL64*       ddp)
{
    INTI      npp, i, ix, basis ;
    IRRCONV   irr ;
    PMTARRAY  pmt ;
    FL64      ss, life, pu, pd, dirty, debt, price, dum ;

    if (ytmc->irr == JGBYTM)
    {
        price = *dp = *ddp = 0.0 ;

        *ddp = *dp = 0.0 ;
        life = Cldr_TermBetweenDates(&xcflw->days[0], &pday->last,
                                     0, ytmc->cal_first, SAME, holi) ;   /* PMSTA-22396 - SRIDHARA � 160502 */

        price = TVMunit_JGBYTM(ytm, life, coupon) ;
        if (risk != ZERO_ORDER)
        {
            ss = Scutl_Default_Shock(-1.0, KEY_DF) ;
            pu = TVMunit_JGBYTM(ytm + ss, life, coupon) ;
            pd = TVMunit_JGBYTM(ytm - ss, life, coupon) ;

            *dp = (pu - pd) / (2.0 * ss) ;
            if (risk == SECOND_ORDER)
                *ddp = (pu + pd - 2.0 * price) / (SQR(ss)) ;

            dirty = price - xcflw->coupon[0] ;
            if (modf == True && fabs(dirty) > P_TOL)
            {
                *dp   /= dirty ;
                *dp   *= -1.0 ;
                *ddp  /= dirty ;
            }
        }

        return price ;
    }

    if (xcflw->filled > 0)
    {
        /* Set terms */
        pmt   = Bond_Cflw2Pmt(&xcflw->days[0], xcflw, ytmc, pday, holi) ;
        basis = disc_set_qbas(ytmc->qb_ytm) ;
        irr   = Bond_Set_IRRCONV(xcflw, ytmc->irr, pday->pseq.eom) ;

        /* Find purchased amount (in %) for partly paid bonds */
        npp = GetPPFill(pp) ;
        if (npp > 0)
        {
            ix = Cldr_FindDateIndex(pp->ppmts->day, npp, &xcflw->days[0], 0,
                                     SEARCH_BISECTION, NEXTINDEX) ;
            debt = pp->ppmts->f64[0] / 100.0 ;
            for (i = 1; i < ix; i++)
                 debt += pp->ppmts->f64[i] / 100.0 ;
        }
        else
            debt = 1.0 ;

        if (irr != SIMPLE_REPO || matur == NULL)
            dirty = TVM_Yield2Price(ytm, risk, basis, 100.0, irr,
                                    &dum, pmt, dp, ddp) ;
        else
        {
            life  = Cldr_TermBetweenDates(&xcflw->days[0], matur,
                                          0, ytmc->cal_first, SAME, holi) ;   /* PMSTA-22396 - SRIDHARA � 160502 */
            dirty = TVM_Simplerepo2Price(ytm, dp, ddp, risk, 100.0,
                                         pmt, life) ;
        }

        price  = dirty + xcflw->coupon[0] ;
        if (fabs(debt) > P_TOL)
        {
            price /= debt ;
            *dp   /= debt ;
            *ddp  /= debt ;
        }

        dirty /= 100.0 ;

        if (modf == True && fabs(dirty) > P_TOL)
        {
            *dp   /= dirty ;
            *dp   *= -1.0 ;
            *ddp  /= dirty ;
        }

        Free_PMTARRAY(pmt, 1) ;
    }
    else
        price = 0.0 ;

    return price ;
}


/*,,SOH,,
*************************************************************************
*
*               Bond_YTM2Price()
*
*   interface   #include <bond.h>
*               FL64 Bond_YTM2Price(FL64       ytm,
*                                   TRADEINFO  *trade,
*                                   FIXPAY     *fixp,
*                                   YTMCONV    *ytmc,
*                                   HOLI_STR   *holi,
*                                   RISKCONV   risk,
*                                   BOOLE      modf,
*                                   FL64       *dp,
*                                   FL64       *ddp) ;
*
*   general     The function calculates the price given YTM for a
*               bond with respect to the conventions defined. Also the
*               dollar duration and dollar convexity can be calculated.
*
*               The conventions defined should be sufficiently general
*               to handle most YTM setup's.
*
*   input       FL64      ytm           The Yield to Maturity of the bond*
*
*               TRADEINFO *trade        The trade data
*
*               FIXPAY    *fixp         The bond definition
*
*               YTMCONV   *ytmc         The conventions defined for
*                                       calculating the YTM.
*
*               HOLI_STR  *holi         Container for data on business
*                                       day convention and non-week-end
*                                       holidays.
*
*               RISKCONV  risk          The risk setup.
*
*               BOOLE     modf          True means that ratios are modi-*
*                                       (i.e. scaled with the dirty
*                                       price), False means direct
*                                       derivatives.
*
*   output      FL64      *dp           The dollar duration
*
*               FL64      *ddp          The dollar convexity
*
*   returns     The clean price of the bond on the settlement date.
*
*   diagnostics
*
*   see also    Cflw_YTM2Price()
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/


FL64 Bond_YTM2Price(FL64    ytm,
                    TRADEINFO*  trade,
                    FIXPAY*     fixp,
                    YTMCONV*    ytmc,
                    HOLI_STR*   holi,
                    RISKCONV   risk,
                    BOOLE      modf,
                    FL64*       dp,
                    FL64*       ddp)
{
    CFLWARRAY xcflw ;
    FL64      dirty, ss, life, p, pu, pd ;
    HOLI_STR  hol ;
    FIXPAY    fxp ;

    /* warning avoidance */
    p = 0.0 ;

    if (ytmc->irr == JGBYTM)
    {
        *ddp = *dp = 0.0 ;
        life = Cldr_TermBetweenDates(&trade->settle, &fixp->cday.last,
                                     0, ytmc->cal_first, SAME, holi) ;   /* PMSTA-22396 - SRIDHARA � 160502 */
        p = TVMunit_JGBYTM(ytm, life, fixp->fix.fix_rate) ;
        if (risk != ZERO_ORDER)
        {
            ss = Scutl_Default_Shock(-1.0, KEY_DF) ;
            pu = TVMunit_JGBYTM(ytm + ss, life, fixp->fix.fix_rate) ;
            pd = TVMunit_JGBYTM(ytm - ss, life, fixp->fix.fix_rate) ;

            *dp = (pu - pd) / (2.0 * ss) ;
            if (risk == SECOND_ORDER)
                *ddp = (pu + pd - 2.0 * p) / (SQR(ss)) ;
        }
    }

    if (ytmc->irr != JGBYTM || modf == True)
    {
        fxp   = Bond_YTM_Prep(trade, fixp, ytmc) ;

		/* PMSTA-22396 - SRIDHARA � 160502 */
		if (fixp->accru.cal == BUS252)
		{
			xcflw = Bond_GenrCflw(trade, &fxp, holi);
		}
		else
		{
			hol = bond_set_holi(holi, &fxp.fix);
			xcflw = Bond_GenrCflw(trade, &fxp, &hol);
		}

        if (ytmc->irr != JGBYTM)
            p = Cflw_YTM2Price(ytm, xcflw, ytmc, &fxp.cday, fxp.fix.fix_rate,
                               &fxp.repay.pp, holi, risk, modf, dp, ddp) ;

        if (ytmc->irr == JGBYTM && modf == True && risk != ZERO_ORDER)
        {
            dirty = (p - xcflw->coupon[0]) / 100.0 ;
            if (fabs(dirty) > P_TOL)
            {
                *dp   /= dirty ;
                *dp   *= -1.0 ;
                *ddp  /= dirty ;
            }
        }

        Free_CFLWARRAY(xcflw, 1) ;
    }

    return p ;
}


/*,,SOH,,
*************************************************************************
*
*               Bond_YTM2PV01()
*
*   interface   #include <bond.h>
*               FL64 Bond_YTM2PV01(FL64       ytm,
*                                  TRADEINFO  *trade,
*                                  FIXPAY     *fixp,
*                                  YTMCONV    *ytmc,
*                                  HOLI_STR   *holi,
*                                  FL64       yshift,
*                                  BOOLE      mean) ;
*
*   general     The function calculates the price value of a given
*               yield shift for a bond.
*
*   input       FL64      ytm           Yield to Maturity of the bond
*
*               TRADEINFO *trade        The trade data
*
*               FIXPAY    *fixp         The bond definition
*
*               YTMCONV   *ytmc         The conventions defined for
*                                       calculating the YTM.
*
*               HOLI_STR  *holi         Container for data on business
*                                       day convention and non-week-end
*                                       holidays.
*
*               FL64      yshift        The shift in the ytm, percentage*
*                                       input.
*
*               BOOLE     mean          False means that a directional
*                                       shift is used. True means that
*                                       an average value from an up and
*                                       down shift is returned.
*
*   output
*
*   returns     The Price Value of a Yield shift
*
*   diagnostics
*
*   see also    Bond_YTM2Price()
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/

FL64 Bond_YTM2PV01(FL64    ytm,
                     TRADEINFO*  trade,
                     FIXPAY*     fixp,
                     YTMCONV*    ytmc,
                     HOLI_STR*   holi,
                     FL64       yshift,
                     BOOLE      mean)
{
    CFLWARRAY xcflw ;
    FL64      life, p, pu, pd ;
    HOLI_STR  hol ;
    FIXPAY    fxp ;

    if (ytmc->irr == JGBYTM)
    {
        life = Cldr_TermBetweenDates(&trade->settle, &fixp->cday.last,
                                     0, ytmc->cal_first, SAME, holi) ; /* PMSTA-22396 - SRIDHARA � 160502 */
        p  = TVMunit_JGBYTM(ytm, life, fixp->fix.fix_rate) ;
        pu = TVMunit_JGBYTM(ytm + yshift, life, fixp->fix.fix_rate) ;
        pd = TVMunit_JGBYTM(ytm - yshift, life, fixp->fix.fix_rate) ;

        if (mean == False)
            p = p - pu ;
        else
            p = (pd - pu) / 2.0 ;

        return p ;
    }

    fxp   = Bond_YTM_Prep(trade, fixp, ytmc) ;
    hol   = bond_set_holi(holi, &fxp.fix) ;
    xcflw = Bond_GenrCflw(trade, &fxp, &hol) ;

    p = Cflw_YTM2PV01(ytm, xcflw, ytmc, &fxp.cday, fxp.fix.fix_rate,
                      &fxp.repay.pp, holi, yshift, mean) ;

    Free_CFLWARRAY(xcflw, 1) ;

    return p ;
}



/*,,SOH,,
*************************************************************************
*
*               Cflw_YTM2PV01()
*
*   interface   #include <bond.h>
*               FL64 Cflw_YTM2PV01(FL64       ytm,
*                                  CFLW_STR   *xcflw,
*                                  YTMCONV    *ytmc,
*                                  PAYDAYDEF  *pday,
*                                  FL64       coupon,
*                                  PP_STR     *pp,
*                                  HOLI_STR   *holi,
*                                  FL64       yshift,
*                                  BOOLE      mean) ;
*
*   general     The function calculates the price value of a given
*               yield shift for a bond.
*
*   input       FL64      ytm           Yield to Maturity of the bond
*
*               CFLW_STR  *xcflw        The extracted cashflow.
*
*               YTMCONV   *ytmc         The conventions defined for
*                                       calculating the YTM.
*
*               PAYDAYDEF *pday         Pointer to the description of
*                                       the payday sequence.
*
*               FL64      coupon        The annually coupon (%).
*                                       Only used if ytmc->irr = JGBYTM
*
*               PP_STR    *pp           Partly Paid setup. pp->pp_price
*                                       is not used.
*                                       Enter NULL if not needed.
*
*               HOLI_STR  *holi         Container for data on business
*                                       day convention and non-week-end
*                                       holidays.
*
*               FL64      yshift        The shift in the ytm, percentage*
*                                       input.
*
*               BOOLE     mean          False means that a directional
*                                       shift is used. True means that
*                                       an average value from an up and
*                                       down shift is returned.
*
*   output
*
*   returns     The Price Value of a Yield shift
*
*   diagnostics
*
*   see also    Cflw_YTM2Price()
*               Cflw_YTM2YV01()
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/

FL64 Cflw_YTM2PV01(FL64     ytm,
                   CFLW_STR*   xcflw,
                   YTMCONV*    ytmc,
                   PAYDAYDEF*  pday,
                   FL64        coupon,
                   PP_STR*     pp,
                   HOLI_STR*   holi,
                   FL64        yshift,
                   BOOLE       mean)
{
    FL64     dp, p, pu, pd ;
    RISKCONV risk ;

    risk = ZERO_ORDER ;
    p  = Cflw_YTM2Price(ytm, xcflw, ytmc, pday, coupon, pp,
                        holi, risk, False, &dp, &dp) ;

    pu = Cflw_YTM2Price(ytm + yshift, xcflw, ytmc, pday, coupon,
                        pp, holi, risk, False, &dp, &dp) ;

    if (mean == False)
        p = p - pu ;
    else
    {
        pd = Cflw_YTM2Price(ytm - yshift, xcflw, ytmc, pday, coupon, 
                            pp, holi, risk, False, &dp, &dp) ;
        p = (pd - pu) / 2.0 ;
    }

    return p ;
}


/*,,SOH,,
*************************************************************************
*
*               Bond_YTM2YV01()
*
*   interface   #include <bond.h>
*               BOOLE Bond_YTM2YV01(TRADEINFO  *trade,
*                                   FIXPAY     *fixp,
*                                   YTMCONV    *ytmc,
*                                   HOLI_STR   *holi,
*                                   ITERCTRL   *ictrl,
*                                   FL64       pshift,
*                                   BOOLE      mean,
*                                   FL64       *yvb) ;
*
*   general     The function calculates the yield value of a given
*               price shift for a bond.
*
*   input       TRADEINFO *trade        The trade data
*
*               FIXPAY    *fixp         The bond definition
*
*               YTMCONV   *ytmc         The conventions defined for
*                                       calculating the YTM.
*
*               HOLI_STR  *holi         Container for data on business
*                                       day convention and non-week-end
*                                       holidays.
*
*               ITERCTRL  *ictrl        Iteration control
*
*               FL64      pshift        The shift in the price, percen-
*                                       tage input.
*
*               BOOLE     mean          False means that a directional
*                                       shift is used. True means that
*                                       an average value from an up and
*                                       down shift is returned.
*
*   output      FL64      *yvb          The Yield value of a price shift*
*
*   returns     True if all OK, False if not.
*
*   diagnostics
*
*   see also    Bond_YTM2Yield()
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/

BOOLE Bond_YTM2YV01(TRADEINFO* trade,
                    FIXPAY*     fixp,
                    YTMCONV*    ytmc,
                    HOLI_STR*   holi,
                    ITERCTRL*   ictrl,
                    FL64       pshift,
                    BOOLE      mean,
                    FL64*       yvb)
{
    CFLWARRAY xcflw ;
    BOOLE     ok ;
    HOLI_STR  hol ;
    FL64      price, y, yu, yd, life ;
    FIXPAY    fxp ;

    price = trade->price ;

    Math_LaGuerre(trade->settle.y, trade->settle.m, 
      trade->settle.d);

    if (ytmc->irr == JGBYTM)
    {
        life = Cldr_TermBetweenDates(&trade->settle, &fixp->cday.last,
                                     0, ytmc->cal_first, SAME, holi) ; /* PMSTA-22396 - SRIDHARA � 160502 */
        if (life > P_TOL && price > fabs(pshift))
        {
            y  = TVMunit_JGBYTM2rate(price / 100.0, life, fixp->fix.fix_rate) ;
            yu = TVMunit_JGBYTM2rate((price + pshift) / 100.0, life, 
                                     fixp->fix.fix_rate) ;
            yd = TVMunit_JGBYTM2rate((price - pshift) / 100.0, life, 
                                     fixp->fix.fix_rate) ;
            if (mean == False)
                *yvb = yd - y ;
            else
                *yvb = (yd - yu) / 2.0 ;
        }
        else
            *yvb = 0.0 ;

        return True ;
    }

    fxp   = Bond_YTM_Prep(trade, fixp, ytmc) ;
    hol   = bond_set_holi(holi, &fxp.fix) ;
    xcflw = Bond_GenrCflw(trade, fixp, &hol) ;

    ok = Cflw_YTM2YV01(price, xcflw, ytmc, &fxp.cday, fxp.fix.fix_rate,
                       &fxp.repay.pp, holi, ictrl, pshift, mean, yvb) ;

    Free_CFLWARRAY(xcflw, 1) ;

    return ok ;
}


/*,,SOH,,
*************************************************************************
*
*               Cflw_YTM2YV01()
*
*   interface   #include <bond.h>
*               BOOLE Cflw_YTM2YV01(FL64      price,
*                                  CFLW_STR   *xcflw,
*                                  YTMCONV    *ytmc,
*                                  PAYDAYDEF  *pday,
*                                  FL64       coupon,
*                                  PP_STR     *pp,
*                                  HOLI_STR   *holi,
*                                  ITERCTRL   *ictrl,
*                                  FL64       pshift,
*                                  BOOLE      mean,
*                                  FL64       *yvb) ;
*
*   general     The function calculates the price value of a given
*               yield shift for a bond.
*
*   input       FL64      price         The price of the cashflow.
*
*               CFLW_STR  *xcflw        The extracted cashflow.
*
*               YTMCONV   *ytmc         The conventions defined for
*                                       calculating the YTM.
*
*               PAYDAYDEF *pday         Pointer to the description of
*                                       the payday sequence.
*
*               FL64      coupon        The annually coupon (%).
*                                       Only used if ytmc->irr = JGBYTM
*
*               PP_STR    *pp           Partly Paid setup. pp->pp_price
*                                       is not used.
*                                       Enter NULL if not needed.
*
*               HOLI_STR  *holi         Container for data on business
*                                       day convention and non-week-end
*                                       holidays.
*
*               ITERCTRL  *ictrl        Iteration control
*
*               FL64      pshift        The shift in the price, percen-
*                                       tage input.
*
*               BOOLE     mean          False means that a directional
*                                       shift is used. True means that
*                                       an average value from an up and
*                                       down shift is returned.
*
*   output      FL64      *yvb          The Yield value of a price shift*
*
*   returns     True if all OK, False if not.
*
*   diagnostics
*
*   see also    Cflw_YTM2Price()
*               Cflw_YTM2PV01()
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/

BOOLE Cflw_YTM2YV01(FL64    price,
                    CFLW_STR*   xcflw,
                    YTMCONV*    ytmc,
                    PAYDAYDEF*  pday,
                    FL64        coupon,
                    PP_STR*     pp,
                    HOLI_STR*   holi,
                    ITERCTRL*   ictrl,
                    FL64        pshift,
                    BOOLE       mean,
                    FL64*       yvb)
{
    BOOLE ok ;
    FL64  y, yu, yd ;

    *yvb=y=yu=yd=0.0;

    ok = Cflw_YTM2Yield(price, xcflw, ytmc, pday, coupon, pp, holi, 
                        ictrl, &y) ;

    ok = ok && Cflw_YTM2Yield(price - pshift, xcflw, ytmc, pday, coupon,
                              pp, holi, ictrl, &yd) ;

    if (mean == False)
        *yvb = yd - y ;
    else
    {
        ok = ok && Cflw_YTM2Yield(price + pshift, xcflw, ytmc, pday, coupon, 
                                  pp, holi, ictrl, &yu) ;
        *yvb = (yd - yu) / 2.0 ;
    }

    return ok ;
}


/*,,SOH,,
*************************************************************************
*
*               Cflw_YTM2Duration()
*
*   interface   #include <bond.h>
*               FL64 Cflw_YTM2Duration(FL64       ytm,
*                                      CFLW_STR   *xcflw,
*                                      YTMCONV    *ytmc,
*                                      PAYDAYDEF  *pday,
*                                      HOLI_STR   *holi) ;
*
*   general     The function calculates the price given YTM
*               for a bond with respect to the conventions defined.
*
*               The duration returned here is in YEARS and not in
*               periods. Multiply by number of annual periods to get
*               duration in periods.
*
*               The conventions defined should be sufficiently general
*               to handle most YTM setup's.
*
*               The cashflow on which to calculate yield should NOT
*               have been adjusted for non-businessdays prior to calling*
*               this routine. This is performed in this routine.
*
*               A special case occur when the coming payment is ex.
*               If the first fractional period is till the 'empty'
*               payment, the 'empty' payment must be visible in the in
*               xcflw (use fill = True in Bond_GenrPeriod().
*               If this payment is ignored, when calculating YTM, then
*               use fill = False in Bond_GenrPeriod(). In this case
*               the first fractional period is longer than a normal
*               coupon period.
*
*   input       FL64      ytm           The Yield to Maturity of the bond*
*
*               CFLW_STR  *xcflw        The extracted cashflow from
*                                       the relevant period.
*                                       Must have the format defined
*                                       by Bond_GenrPeriod().
*                                       Cashflow is NOT adjusted for
*                                       businessdays.
*                                       The outstanding debt on the
*                                       bond must be 100.
*
*               YTMCONV   *ytmc         The conventions defined for
*                                       calculating the YTM.
*
*               PAYDAYDEF *pday         Pointer to the description of
*                                       the payday sequence.
*
*               HOLI_STR  *holi         Container for data on business
*                                       day convention and non-week-end
*                                       holidays.
*
*   output
*
*   returns     The duration of the bond
*
*   diagnostics
*
*   see also    Bond_YTM2Duration()
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/

FL64 Cflw_YTM2Duration(FL64        ytm,
                          CFLW_STR*   xcflw,
                          YTMCONV*    ytmc,
                          PAYDAYDEF*  pday,
                          HOLI_STR*   holi)
{
    INTI      basis ;
    IRRCONV   irr ;
    PMTARRAY  pmt ;
    FL64      ai, dum, dur ;

    if (xcflw->filled > 0)
    {
        pmt   = Bond_Cflw2Pmt(&xcflw->days[0], xcflw, ytmc, pday, holi) ;
        basis = disc_set_qbas(ytmc->qb_ytm) ;
        irr   = Bond_Set_IRRCONV(xcflw, ytmc->irr, pday->pseq.eom) ;

        ai = xcflw->coupon[0] ;
        xcflw->coupon[0] = 0.0 ;

        dur = TVM_Yield2Duration(ytm, basis, irr, &dum, pmt) ;
        xcflw->coupon[0] = ai ;

        Free_PMTARRAY(pmt, 1) ;
    }
    else
        dur = 0.0 ;

    return dur ;
}


/*,,SOH,,
*************************************************************************
*
*               Bond_YTM2Duration()
*
*   interface   #include <bond.h>
*               FL64 Bond_YTM2Duration(FL64       ytm,
*                                      TRADEINFO  *trade,
*                                      FIXPAY     *fixp,
*                                      YTMCONV    *ytmc,
*                                      HOLI_STR   *holi) ;
*
*   general     The function calculates the price given YTM
*               for a bond with respect to the conventions defined.
*
*               The duration returned here is in YEARS and not in
*               periods. Multiply by number of annual periods to get
*               duration in periods.
*
*               The conventions defined should be sufficiently general
*               to handle most YTM setup's.
*
*   input       FL64      ytm           Yield to Maturity of the bond
*
*               TRADEINFO *trade        The trade data
*
*               FIXPAY    *fixp         The bond definition
*
*               YTMCONV   *ytmc         The conventions defined for
*                                       calculating the YTM.
*
*               HOLI_STR  *holi         Container for data on business
*                                       day convention and non-week-end
*                                       holidays.
*
*   output
*
*   returns     The duration of the bond
*
*   diagnostics
*
*   see also    Cflw_YTM2Duration()
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/


FL64 Bond_YTM2Duration(FL64    ytm,
                         TRADEINFO*  trade,
                         FIXPAY*     fixp,
                         YTMCONV*    ytmc,
                         HOLI_STR*   holi)
{
    CFLWARRAY xcflw ;
    FL64      dur ;
    HOLI_STR  hol ;
    FIXPAY    fxp ;

    fxp   = Bond_YTM_Prep(trade, fixp, ytmc) ;
    	/* PMSTA-22396 - SRIDHARA � 160502 */
	if (fixp->accru.cal == BUS252)
	{
		xcflw = Bond_GenrCflw(trade, &fxp, holi);
	}

	else
	{
		hol = bond_set_holi(holi, &fxp.fix);
		xcflw = Bond_GenrCflw(trade, &fxp, &hol);
	}

    dur = Cflw_YTM2Duration(ytm, xcflw, ytmc, &fxp.cday, holi) ;

    Free_CFLWARRAY(xcflw, 1) ;

    return dur ;
}


/*,,SOH,,
*************************************************************************
*
*               Bond_GenrTerms()
*
*   interface   #include <bond.h>
*               FL64ARRAY Bond_GenrTerms(DATESTR    *analys,
*                                         CFLW_STR   *xcflw,
*                                         YTMCONV    *ytmc,
*                                         PAYDAYDEF  *pday,
*                                         HOLI_STR   *holi) ;
*
*   general     Bond_GenrTerms() calculates the 'terms' between paydays*
*               needed for discounting payments.
*
*               The conventions defined should be sufficiently general
*               to handle most YTM setup's.
*
*               The cashflow on which to calculate yield should NOT
*               have been adjusted for non-businessdays prior to calling*
*               this routine. This is performed in this routine.
*
*               A special case occur when the coming payment is ex.
*               If the first fractional period is till the 'empty'
*               payment, the 'empty' payment must be visible in the in
*               xcflw (use fill = True in Bond_GenrPeriod().
*               If this payment is ignored, when calculating YTM, then
*               use fill = False in Bond_GenrPeriod(). In this case
*               the first fractional period is longer than a normal
*               coupon period.
*
*               The first 'term' is returned as the 'term' between
*               analys and xcflw->days[0] - which is usually 0.0.
*
*   input       DATESTR   *analys       The date of analysis, may be
*                                       equal to or less than
*                                       xcflw->days[0].
*
*               CFLW_STR  *xcflw        The extracted cashflow from
*                                       the relevant period.
*                                       Must have the format defined
*                                       by Bond_GenrPeriod().
*                                       Cashflow is NOT adjusted for
*                                       businessdays.
*
*               YTMCONV   *ytmc         The conventions defined for
*                                       calculating the YTM.
*
*               PAYDAYDEF *pday         Pointer to the description of
*                                       the payday sequence.
*
*               HOLI_STR  *holi         Container for data on business
*                                       day convention and non-week-end
*                                       holidays.
*                                       Used to calculate businessday
*                                       adjusted yield.
*
*   output
*
*   returns     Pointer to list of 'terms'. Allocated in this routine
*               as Alloc_FL64ARRAY(xcflw->filled) ;
*               The list contains xcflw->filled 'terms'
*
*   diagnostics
*
*   see also    Cflw_YTM2Yield()
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/

FL64ARRAY Bond_GenrTerms(DATESTR*    analys,
                             CFLW_STR*   xcflw,
                             YTMCONV*    ytmc,
                             PAYDAYDEF*  pday,
                             HOLI_STR*   holi)
{
    INTI       ix, months, i, ndates ;
    BOOLE      trueYTM, simpl, short1, shortn, finalodd;
    DATESTR    first, pnext, ps0, ps, settle, prev, next, seclast,
               oneyear ;
    DATEARRAY  dates ;
    FL64       frac, add, prevterm, term ;
    FL64ARRAY  terms ;
    ODDCONV    odd1, oddn ;
    EOMCONV    eom ;
    HOLI_STR   hol ;
    CALCONV    cal_first, cal_normal, cal_last ;

    /* warning avoidance */
    term = frac = 0.0 ;

    /* Allocate output */
    terms = Alloc_FL64ARRAY(GetCflwFill(xcflw)) ;

    /* Avoid silly cases */
    if (GetCflwFill(xcflw) <= 0)
        return terms ;

    /* Find various settings */
    cal_first = ytmc->cal_first ;
    cal_normal = ytmc->cal_normal ;
    cal_last = ytmc->cal_last ;
   
    odd1   = pday->pseq.odd1 ;
    oddn   = pday->pseq.oddn ;
    finalodd = short1 = shortn = False ;
    if (oddn != NOODD)
        finalodd = True ;
    if (odd1 == SHORTODD)
        short1 = True ;
    if (oddn == SHORTODD)
        shortn = True ;

    eom    = pday->pseq.eom ;
    settle = next = xcflw->days[0] ;

    simpl = Cflw_Is_Harmonic(pday->pseq.term, pday->pseq.unit, &months) ;
    if (pday->nirreg != 0 || simpl == False)
        simpl = False ;
    else
    {
        term = ((FL64) months) / 12.0 ;
        frac = 1.0 / term ;
    }

    /* Generate UNadjusted paydays */
    hol   = Set_HOLI_STR(NO_BUSADJUST, 0, NULL) ;
    dates = Cflw_Paydays(pday, &hol, &ndates) ;

    if (ndates > 1)
        seclast = dates[ndates - 2] ;
    if (ndates > 0)
        first = dates[0] ;

    /* True Yield or 'Normal' Yield */
    trueYTM = ((holi->bus != NO_BUSADJUST && 
               ytmc->trueYTM == True) ? True : False) ;

    /* Set the term from analysis to settlement */
    if (Cldr_DateEQ(analys, &settle) == False)
    {
        /* This is not strictly OK, but ... */
        if (ytmc->dayfrac_first == True || simpl == False)
            add = Cldr_TermBetweenDates(analys, &settle, 0,
                                        cal_first, eom, holi) ;  /* PMSTA-22396 - SRIDHARA � 160502 */
        else
        {
            ix   = Cldr_FindDateIndex(dates, ndates, &next, 0,
                                       SEARCH_BISECTION, SAMEINDEX) ;
            next = dates[ix] ;
            ps   = Cldr_AddMonths(&next, - months, eom) ;
            add  = Bond_Period_Term(analys, &settle, &ps, &next,
                                    cal_first, frac, holi) ;  /* PMSTA-22396 - SRIDHARA � 160502 */
        }

        prevterm = terms[0] = add ;
    }
    else
        prevterm = 0.0 ;

    /* For ytmc->irr == COMPOUNDSIMPLE_ODD (Swedish bond market)
       the last calendar convention is used for cashflows of one
       year and shorter.                                          */
    if (ytmc->irr == COMPOUNDSIMPLE_ODD && xcflw->filled > 0)
    {
        oneyear = Cldr_AddMonths(&xcflw->days[0], 12, eom) ;
        if (Cldr_DateLE(&xcflw->days[xcflw->filled - 1], &oneyear)
            == True)
        {
            cal_first = cal_last ;
            cal_normal = cal_last ;        
        }
    }

    /* Now loop over all periods to find discounting terms */
    for (ix = 0, i = 1; i < xcflw->filled; i++)
    {
        prev = next ;
        next = xcflw->days[i] ;

        ix = Cldr_FindDateIndex(dates, ndates, &next, ix - 1,
                                 SEARCH_BISECTION, SAMEINDEX) ;

        /* This should always be OK, but wrong data... */
        if (ix < ndates)
            pnext = dates[ix] ;

        if (trueYTM == True)
            next = Cldr_NextBusinessDate(&next, holi) ;
        else
            next = Cldr_NextBusinessDate(&next, &hol) ;

        /* Now set the period till payments */

        /* 1. Buy. This is the initial fractional period. This period is NOT
              in the last payperiod of the bond. */

        if (i == 1 && ndates > 1 && Cldr_DateLT(&settle, &seclast) == True)
        {
            /* 1.1 First take care of settlement in first odd period */
            if (simpl == True && odd1 != NOODD && ytmc->dayfrac_first == False
                && Cldr_DateLT(&settle, &first) == True)
            {
                ps = Cldr_AddMonths(&first, - months, eom) ;
                if (short1 == True)
                    add = Bond_Period_Term(&prev, &next, &ps, &first,
                                           cal_first, frac, holi) ;  /* PMSTA-22396 - SRIDHARA � 160502 */
                else /* This must be long */
                {
                    ps0 = Cldr_AddMonths(&ps, - months, eom) ;
                    if (Cldr_DateLT(&settle, &ps) == True)
                    {
                        add  = term ;
                        add += Bond_Period_Term(&prev, &ps, &ps0, &ps,
                                                cal_first, frac, holi) ;  /* PMSTA-22396 - SRIDHARA � 160502 */
                    }
                    else
                        add = Bond_Period_Term(&prev, &next, &ps, &first,
                                                cal_first, frac, holi) ;  /* PMSTA-22396 - SRIDHARA � 160502 */
                }
            }

            /* 1.2 This handles settlement in a 'normal' period */
            else
            {
                ps = Cldr_AddMonths(&pnext, - months, eom) ;
                if (ytmc->dayfrac_first == False && simpl == True)
                    add = Bond_Period_Term(&prev, &next, &ps, &pnext,
                                           cal_first, frac, holi) ;  /* PMSTA-22396 - SRIDHARA � 160502 */
                else
                {
                    /* Beware if settlement is on a payday, then use
                       'normal' discounting */
                    if (simpl == True && Cldr_DateEQ(&ps, &settle) == True)
                    {
                        if (ytmc->dayfrac_normal == True)
                            add = Cldr_TermBetweenDates(&prev, &next, 0,
                                                        cal_normal, eom, holi) ;  /* PMSTA-22396 - SRIDHARA � 160502 */
                        else
                        {
                            if (trueYTM == True)
                                add = Bond_Period_Term(&prev, &next, &ps,&pnext,
                                                       cal_normal, frac, holi) ;  /* PMSTA-22396 - SRIDHARA � 160502 */
                            else
                            {
                                if (Cldr_DateEQ(&next, &pnext) == True &&
                                    Cldr_DateEQ(&prev, &ps) == True)
                                    add = term ;
                                else
                                    add = Bond_Period_Term(&prev, &next, &ps, 
                                                           &pnext,
                                                           cal_normal, 
														   frac, holi);  /* PMSTA-22396 - SRIDHARA � 160502 */
                            }
                        }
                    }
                    else
                        add = Cldr_TermBetweenDates(&prev, &next, 0,
                                                    cal_first, eom, holi) ;  /* PMSTA-22396 - SRIDHARA � 160502 */
                }
            }
        }

        /* 2. This is the initial fractional period. This period IS
              in the last payperiod of the bond. */

        else if (i == 1 && ndates > 1 && Cldr_DateLE(&seclast, &settle) == True)
        {
            /* 2.1 This is settlement in a final odd period */
            if (simpl == True && oddn != NOODD && ytmc->dayfrac_last == False)
            {
                ps = Cldr_AddMonths(&seclast, months, eom) ;
                if (shortn == True)
                    add = Bond_Period_Term(&prev, &next, &seclast, &ps,
                                           cal_last, frac, holi) ;  /* PMSTA-22396 - SRIDHARA � 160502 */
                else
                {
                    ps0 = Cldr_AddMonths(&ps, months, eom) ;
                    if (Cldr_DateLT(&next, &ps) == True)
                    {
                        add  = term ;
                        add += Bond_Period_Term(&prev, &ps, &seclast, &ps,
                                                cal_last, frac, holi) ;  /* PMSTA-22396 - SRIDHARA � 160502 */
                    }
                    else
                        add = Bond_Period_Term(&prev, &next, &ps, &ps0,
                                               cal_last, frac, holi) ;  /* PMSTA-22396 - SRIDHARA � 160502 */
                }
            }

            /* 2.2 This is settlement in a final 'normal' period */
            else
            {
                ps = Cldr_AddMonths(&seclast, months, eom) ;
                if (ytmc->dayfrac_last == False && simpl == True)
                    add = Bond_Period_Term(&prev, &next, &seclast, &ps,
                                           cal_last, frac, holi) ;  /* PMSTA-22396 - SRIDHARA � 160502 */
                else
                    add = Cldr_TermBetweenDates(&prev, &next, 0,
                                                cal_last, eom, holi) ;  /* PMSTA-22396 - SRIDHARA � 160502 */
            }
        }

        /* 3.0 Buy in last period of bond with a single coupon */
        else if (i == 1 && ndates == 1)
        {
            ps = Cldr_AddMonths(&dates[0], - months, eom) ;
            if (ytmc->dayfrac_last == False && simpl == True)
                add = Bond_Period_Term(&prev, &next, &ps, &dates[0],
                                       cal_last, frac, holi) ;  /* PMSTA-22396 - SRIDHARA � 160502 */
            else
                add = Cldr_TermBetweenDates(&prev, &next, 0,
                                            cal_last, eom, holi) ;  /* PMSTA-22396 - SRIDHARA � 160502 */
        }

        /* 4. These are 'normal' periods, or the last period */
        else
        {
            /* 4.1 Remember to handle final odd periods specially - if needed */
            if (i == xcflw->filled - 1 && finalodd == True && simpl == True &&
                ytmc->dayfrac_normal == False)
            {
                /* The maturity date is in a final odd period */
                ps = Cldr_AddMonths(&seclast, months, eom) ;
                if (shortn == True)
                    add = Bond_Period_Term(&prev, &next, &seclast, &ps,
                                           cal_normal, frac, holi) ;  /* PMSTA-22396 - SRIDHARA � 160502 */
                else
                {
                    ps0  = Cldr_AddMonths(&ps, months, eom) ;
                    add  = term ;
                    add += Bond_Period_Term(&ps, &next, &ps, &ps0,
                                            cal_normal, frac, holi) ;  /* PMSTA-22396 - SRIDHARA � 160502 */
                }
            }

            /* 4.2 This is a normal period or final period with no oddities */
            else
            {
                ps = Cldr_AddMonths(&pnext, - months, eom) ;
                if (i == xcflw->filled - 1)
                {
                    if (ytmc->dayfrac_normal == True || simpl == False)
                        add = Cldr_TermBetweenDates(&prev, &next, 0,
                                                    cal_normal, eom, holi) ;  /* PMSTA-22396 - SRIDHARA � 160502 */
                    else
                    {
                        if (trueYTM == True)
                            add = Bond_Period_Term(&prev, &next, &ps, &pnext,
                                                   cal_normal, frac, holi) ;  /* PMSTA-22396 - SRIDHARA � 160502 */
                        else
                        {
                            if (Cldr_DateEQ(&next, &pnext) == True &&
                                Cldr_DateEQ(&prev, &ps) == True)
                                add = term ;
                            else
                                add = Bond_Period_Term(&prev, &next, &ps,&pnext,
                                                       cal_normal, frac, holi) ;  /* PMSTA-22396 - SRIDHARA � 160502 */
                        }
                    }
                }

                else
                {
                    if (ytmc->dayfrac_normal == True || simpl == False)
                        add = Cldr_TermBetweenDates(&prev, &next, 0,
                                                    cal_normal, eom, holi) ;  /* PMSTA-22396 - SRIDHARA � 160502 */
                    else
                    {
                        if (trueYTM == True)
                            add = Bond_Period_Term(&prev, &next, &ps, &pnext,
                                                   cal_normal, frac, holi) ;  /* PMSTA-22396 - SRIDHARA � 160502 */
                        else
                        {
                            if (Cldr_DateEQ(&next, &pnext) == True &&
                                Cldr_DateEQ(&prev, &ps) == True)
                                add = term ;
                            else
                                add = Bond_Period_Term(&prev, &next, &ps,&pnext,
                                                       cal_normal, frac, holi) ;  /* PMSTA-22396 - SRIDHARA � 160502 */
                        }
                    }
                }
            }
        }

        terms[i] = prevterm + add ;
        prevterm = terms[i] ;
    }

    Free_DATEARRAY(dates) ;

    return terms ;
}


/*
..
*/

FL64 Bond_Period_Term(DATESTR*  prev_num,
                         DATESTR*  next_num,
                         DATESTR*  prev_denom,
                         DATESTR*  next_denom,
                         CALCONV   cal,
                         FL64      qb,
						 HOLI_STR* holi)     /* PMSTA-22396 - SRIDHARA � 160502 */
{
    FL64 add, num, denom ;

	/* PMSTA-22396 - SRIDHARA � 160502 */
    num   = (FL64) Cldr_DaysBetweenDates(prev_num, next_num, cal, holi) ;  
    denom = (FL64) Cldr_DaysBetweenDates(prev_denom, next_denom, cal, holi) ;
    add   = num / (qb * denom) ;

    return add ;
}

/*,,SOH,,
*************************************************************************
*
*               Cflw_DF2Price()
*
*   interface   #include <bond.h>
*               FL64 Cflw_DF2Price(DATESTR    *analys,
*                                  DISCFAC    *df,
*                                  CFLW_STR   *xcflw,
*                                  PP_STR     *pp,
*                                  HOLI_STR   *holi,
*                                  DFSPREAD   *dfs,
*                                  RISKSET    *risk,
*                                  FL64       *dp,
*                                  FL64       *ddp) ;
*
*   general     Cflw_DF2Price() calculates the price given a zero-
*               coupon discount factor curve.
*
*               The cashflow on which to calculate yield should NOT
*               have been adjusted for non-businessdays prior to calling*
*               this routine. This is performed in this routine.
*
*               Risk ratios are calculated as follows:
*
*                   risk->key      dp          ddp
*                   ---------      ---         ----
*                   KEY_DF         $Duration   $Convexity
*                   KEY_BPV        BPV
*
*               All payments between analys and the first date in df are*
*               IGNORED.
*
*   input       DATESTR   *analys       The analysis date.
*
*               DISCFAC   *df           Discounting structure setup.
*
*               CFLW_STR  *xcflw        The extracted cashflow from
*                                       the relevant period.
*                                       Must have the format defined
*                                       by Bond_GenrPeriod().
*                                       Cashflow is NOT adjusted for
*                                       businessdays.
*                                       The outstanding debt on the
*                                       bond must be 100.
*                                       The first date in the flow is
*                                       the settlement date.
*
*               PP_STR    *pp           Partly Paid setup. pp->pp_price
*                                       is not used.
*                                       Enter NULL if not needed.
*
*               HOLI_STR  *holi         Container for data on business
*                                       day convention and non-week-end
*                                       holidays.
*
*               DFSPREAD  *dfs          Spread against the curve.
*                                       Enter NULL if no spread.
*
*               RISKSET   *risk         The risk calculation setup.
*                                       Use NULL for nul risk numbers
*
*   output      FL64      *dp           The dollar duration
*
*               FL64      *ddp          The dollar convexity
*
*   returns     The clean price of the bond on the analysis date.
*
*   diagnostics
*
*   see also    Bond_DF2Price()
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/


FL64 Cflw_DF2Price(DATESTR* analys,
                   DISCFAC*    df,
                   CFLW_STR*   xcflw,
                   PP_STR*     pp,
                   HOLI_STR*   holi,
                   DFSPREAD*   dfs,
                   RISKSET*    risk,
                   FL64*       dp,
                   FL64*       ddp)
{
    return RepoCflw_DF2Price(analys, df, xcflw, NULL, pp, holi, dfs,
                             risk, dp, ddp) ;
}


/*,,SOH,,
*************************************************************************
*
*               RepoCflw_DF2Price()
*
*   interface   #include <bond.h>
*               FL64 RepoCflw_DF2Price(DATESTR    *analys,
*                                      DISCFAC    *df,
*                                      CFLW_STR   *xcflw,
*                                      DATESTR    *matur,
*                                      PP_STR     *pp,
*                                      HOLI_STR   *holi,
*                                      DFSPREAD   *dfs,
*                                      RISKSET    *risk,
*                                      FL64       *dp,
*                                      FL64       *ddp) ;
*
*   general     Cflw_DF2Price() calculates the price given a zero-
*               coupon discount factor curve.
*
*               The cashflow used can be a period cashflow, where the
*               end date (matur) is befre the real maturity.
*
*               The cashflow on which to calculate yield should NOT
*               have been adjusted for non-businessdays prior to calling*
*               this routine. This is performed in this routine.
*
*               Risk ratios are calculated as follows:
*
*                   risk->key      dp          ddp
*                   ---------      ---         ----
*                   KEY_DF         $Duration   $Convexity
*                   KEY_BPV        BPV
*
*               All payments between analys and the first date in df are*
*               IGNORED.
*
*   input       DATESTR   *analys       The analysis date.
*
*               DISCFAC   *df           Discounting structure setup.
*
*               CFLW_STR  *xcflw        The extracted cashflow from
*                                       the relevant period.
*                                       Must have the format defined
*                                       by Bond_GenrPeriod().
*                                       Cashflow is NOT adjusted for
*                                       businessdays.
*                                       The outstanding debt on the
*                                       bond must be 100.
*                                       The first date in the flow is
*                                       the settlement date.
*
*               DATESTR   *matur        The flow maturity date.
*
*               PP_STR    *pp           Partly Paid setup. pp->pp_price
*                                       is not used.
*                                       Enter NULL if not needed.
*
*               HOLI_STR  *holi         Container for data on business
*                                       day convention and non-week-end
*                                       holidays.
*
*               DFSPREAD  *dfs          Spread against the curve.
*                                       Enter NULL if no spread.
*
*               RISKSET   *risk         The risk calculation setup.
*                                       Use NULL for nul risk numbers
*
*   output      FL64      *dp           The dollar duration
*
*               FL64      *ddp          The dollar convexity
*
*   returns     The clean price of the bond on the analysis date.
*
*   diagnostics
*
*   see also    Bond_DF2Price()
*
*************************************************************************
,,EOH,,*/

FL64 RepoCflw_DF2Price(DATESTR* analys,
                   DISCFAC*    df,
                   CFLW_STR*   xcflw,
                   DATESTR*    matur,
                   PP_STR*     pp,
                   HOLI_STR*   holi,
                   DFSPREAD*   dfs,
                   RISKSET*    risk,
                   FL64*       dp,
                   FL64*       ddp)
{
    INTI    i, ix, npp ;
    FL64    debt, dum, shock, p, pu, pd ;
    DISCFAC ds, ds1 ;
    BOOLE   alc ;

    p = *dp = *ddp = 0.0 ;
    Cldr_Move2BusinessDays(xcflw->days, xcflw->filled, holi) ;

    if (xcflw->filled > 0)
    {
        alc = False ;

        if (dfs != NULL && (fabs(dfs->spread) > 0.000000001 || 
            GetPlanFill(dfs->spr_list) > 0))
        {
            alc = True ;
            ds  = Disc_Spread2DF(df, dfs, holi) ;  /* PMSTA-22396 - SRIDHARA � 160502 */
        }
        else
            ds = *df ;

        /* Find purchased amount (in %) for partly paid bonds */
        npp = GetPPFill(pp) ;
        if (npp > 0)
        {
            ix = Cldr_FindDateIndex(pp->ppmts->day, npp, &xcflw->days[0], 0,
                                    SEARCH_BISECTION, NEXTINDEX) ;
            debt = pp->ppmts->f64[0] / 100.0 ;
            for (i = 1; i < ix; i++)
                 debt += pp->ppmts->f64[i] / 100.0 ;
        }
        else
            debt = 1.0 ;

        p = Disc_DF2NPV(analys, xcflw->days, xcflw->coupon, xcflw->repay,
                        xcflw->filled, &ds, matur, False, NULL, holi) ;  /* PMSTA-22396 - SRIDHARA � 160502 */
        if (fabs(debt) > 0.00001)
            p /= debt ;

        if (risk != NULL && (risk->key == KEY_DF || risk->key == KEY_BPV) &&
            risk->risk != ZERO_ORDER)
        {
            shock = Scutl_Default_Shock(risk->shock, risk->key) ;

            ds1 = Disc_ShockRates(&ds, 1.0, risk, holi) ;  /* PMSTA-22396 - SRIDHARA � 160502 */
            pu  = RepoCflw_DF2Price(analys, &ds1, xcflw, matur, pp, holi, NULL,   /* PMSTA-24127 - SRIDHARA � 160721 */
                                    NULL, &dum, &dum) ;
            Free_PLANARRAY(ds1.disc, 1) ;

			ds1 = Disc_ShockRates(&ds, -1.0, risk, holi);  /* PMSTA-22396 - SRIDHARA � 160502 */
            pd  = RepoCflw_DF2Price(analys, &ds1, xcflw, matur, pp, holi, NULL,       /* PMSTA-24127 - SRIDHARA � 160721 */
                                    NULL, &dum, &dum) ;
            Free_PLANARRAY(ds1.disc, 1) ;

            if (risk->key == KEY_BPV)
                shock = 1.0 ;

            *dp = TVMunit_Calc_Deriv(0.0, pd, p, pu, 0.0, shock, 1) ;

            if (risk->risk == SECOND_ORDER && risk->key == KEY_DF)
                *ddp = TVMunit_Calc_Deriv(0.0, pd, p, pu, 0.0, shock, 2) ;
        }

        if (alc == True)
            Free_PLANARRAY(ds.disc, 1) ;
    }

    return p ;
}


/*,,SOH,,
*************************************************************************
*
*               Bond_DF2Price()
*
*   interface   #include <bond.h>
*               FL64 Bond_DF2Price(DATESTR    *analys,
*                                  TRADEINFO  *trade,
*                                  FIXPAY     *fixp,
*                                  DISCFAC    *df,
*                                  HOLI_STR   *holi,
*                                  DFSPREAD   *dfs,
*                                  RISKSET    *risk,
*                                  FL64       *dp,
*                                  FL64       *ddp) ;
*
*   general     Bond_DF2Price() calculates the price given a zero-
*               coupon discount factor curve.
*
*               Risk ratios are calculated as follows:
*
*                   risk->key      dp          ddp
*                   ---------      ---         ----
*                   KEY_DF         $Duration   $Convexity
*                   KEY_BPV        BPV
*
*               All payments between analys and the first date in df are*
*               IGNORED.
*
*   input       DATESTR   *analys       The analysis date.
*
*               TRADEINFO *trade        The trade data
*
*               FIXPAY    *fixp         The bond definition
*
*               DISCFAC   *df           Discounting structure setup.
*
*               HOLI_STR  *holi         Container for data on business
*                                       day convention and non-week-end
*                                       holidays.
*
*               DFSPREAD  *dfs          Spread against the curve.
*                                       Enter NULL if no spread.
*
*               RISKSET   *risk         The risk calculation setup.
*                                       Use NULL for nul risk numbers
*
*   output      FL64      *dp           The dollar duration
*
*               FL64      *ddp          The dollar convexity
*
*   returns     The clean price of the bond on the analysis date.
*
*   diagnostics
*
*   see also    Cflw_DF2Price()
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/

FL64 Bond_DF2Price(DATESTR* analys,
                     TRADEINFO*  trade,
                     FIXPAY*     fixp,
                     DISCFAC*    df,
                     HOLI_STR*   holi,
                     DFSPREAD*   dfs,
                     RISKSET*    risk,
                     FL64*       dp,
                     FL64*       ddp)
{
    CFLWARRAY xcflw ;
    FL64      p ;
    HOLI_STR  hol ;

	/* PMSTA-22396 - SRIDHARA � 160502 */
	if (fixp->accru.cal == BUS252)
	{
		xcflw = Bond_GenrCflw(trade, fixp, holi);
	}

	else
	{
		hol = bond_set_holi(holi, &fixp->fix);
		xcflw = Bond_GenrCflw(trade, fixp, &hol);
	}

    p = Cflw_DF2Price(analys, df, xcflw, &fixp->repay.pp, holi,
                      dfs, risk, dp, ddp) ;

    Free_CFLWARRAY(xcflw, 1) ;

    return p ;
}


/*,,SOH,,
*************************************************************************
*
*               Bond_DF2Duration()
*
*   interface   #include <bond.h>
*               FL64 Bond_DF2Duration(DATESTR    *analys,
*                                     TRADEINFO  *trade,
*                                     FIXPAY     *fixp,
*                                     DISCFAC    *df,
*                                     HOLI_STR   *holi,
*                                     DFSPREAD   *dfs) ;
*
*   general     The routine calculates the duration given a zero-
*               coupon discount factor curve.
*
*               All payments between analys and the first date in df are*
*               IGNORED.
*
*   input       DATESTR   *analys       The analysis date.
*
*               TRADEINFO *trade        The trade data
*
*               FIXPAY    *fixp         The bond definition
*
*               DISCFAC   *df           Discounting structure setup.
*
*               HOLI_STR  *holi         Container for data on business
*                                       day convention and non-week-end
*                                       holidays.
*
*               DFSPREAD  *dfs          Spread against the curve.
*                                       Enter NULL if no spread.
*
*   output
*
*   returns     The (Fisher-Weill) duration on the analysis date.
*
*   diagnostics
*
*   see also    Bond_DF2Price()
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/

FL64 Bond_DF2Duration(DATESTR*    analys,
                         TRADEINFO*  trade,
                         FIXPAY*     fixp,
                         DISCFAC*    df,
                         HOLI_STR*   holi,
                         DFSPREAD*   dfs)
{
    HOLI_STR  hol ;
    CFLWARRAY xcflw ;
    FL64      t, den, num, dur, dum ;
    INTI      i ;

    hol   = bond_set_holi(holi, &fixp->fix) ;
    xcflw = Bond_GenrCflw(trade, fixp, &hol) ;

    if (xcflw->filled > 0)
        xcflw->coupon[0] = 0.0 ;

    /* Base price */
    den = Cflw_DF2Price(analys, df, xcflw, &fixp->repay.pp, holi,
                        dfs, NULL, &dum, &dum) ;

    /* Adjust for Duration calculation */
    for (i = 0; i < xcflw->filled; i++)
    {
		t = Cldr_TermBetweenDates(analys, &xcflw->days[i], 0, df->cal, LAST, holi);  /* PMSTA-22396 - SRIDHARA � 160502 */
        xcflw->repay[i]  *= t ;
        xcflw->coupon[i] *= t ;
    }

    num = Cflw_DF2Price(analys, df, xcflw, &fixp->repay.pp, holi,
                        dfs, NULL, &dum, &dum) ;
    dur = SafeDivide(num, den, YTM_ACC, 0.0) ;

    /* Clean up */    
    Free_CFLWARRAY(xcflw, 1) ;

    return dur ;
}


/*,,SOH,,
*************************************************************************
*
*               Bond_DF2Hzy()
*
*   interface   #include <bond.h>
*               BOOLE Bond_DF2Hzy(TRADEINFO  *settle,
*                                 TRADEINFO  *horiz,
*                                 FIXPAY     *fixp,
*                                 HZYCONV    *hzyc,
*                                 DISCFAC    *dfre,
*                                 DISCFAC    *dfhz,
*                                 HOLI_STR   *holi,
*                                 DFSPREAD   *dfs,
*                                 ITERCTRL   *ictrl,
*                                 FL64       *hzy) ;
*
*   general     This routine calculates the horizon yield given disco-
*               unt factor curves for the horizon value and for the
*               reinvested payments.
*
*   input       TRADEINFO *settle       The initial trade
*                                       Contains initial price.
*
*               TRADEINFO *horiz        The horizon trade. Contains
*                                       horizon price (if needed).
*
*               FIXPAY    *fixp         The bond data.
*
*               HZYCONV   *hzyc         Conventions for calculation
*
*               DISCFAC   *dfre         Discount factor setup for
*                                       reinvesting till horiz.
*                                       (E.g. zero curve on settle)
*                                       Only used if interim proceeds
*                                       are reinvested.
*
*               DISCFAC   *dfhz         Discount factor setup for
*                                       finding the value on horiz of
*                                       the payments after horiz.
*                                       (E.g forward curve on horiz).
*                                       If dfhz is equal to dfre then
*                                       essentially forward rates are
*                                       used to find the terminal value.*
*                                       Only used if horizon value is
*                                       not entered separately.
*
*               HOLI_STR  *holi         Holiday adjustment setup
*
*               DFSPREAD  *dfs          Spread against the curve.
*                                       Enter NULL if no spread.
*
*               ITERCTRL  *ictrl        Iteration control
*
*   output      FL64      *hzy          The horizon yield in percent.
*
*   returns     True if all OK , False if not
*
*   diagnostics
*
*   see also
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/

BOOLE Bond_DF2Hzy(TRADEINFO* settle,
                      TRADEINFO*  horiz,
                      FIXPAY*     fixp,
                      HZYCONV*    hzyc,
                      DISCFAC*    dfre,
                      DISCFAC*    dfhz,
                      HOLI_STR*   holi,
                      DFSPREAD*   dfs,
                      ITERCTRL*   ictrl,
                      FL64*       hzy)
{
    CFLWARRAY cflw, xcflw1, xcflw2 ;
    FL64      rg, dum, HV, dH, pmt ;
    INTI      ix, i ;
    BOOLE     ok ;
    HOLI_STR  hol ;
    TRADEINFO end ;
    EXINF     dummy ;

    hol = bond_set_holi(holi, &fixp->fix) ;

    /* Initial flow */
    cflw = Cflw_GenrCflw(&fixp->repay, &fixp->rday, &fixp->fix,
                          &fixp->cday, &hol) ;

    /* Cashflow from horizon to maturity */
    if (hzyc->hzp == False)
    {
        end    = bond_set_tradeinfo(&fixp->cday.last) ;
        horiz->nom = 100.0 ;
        xcflw2 = Cflw_ExtractPeriod(horiz, &end, &fixp->fix, &fixp->cday.pseq,
                                    &fixp->accru, &fixp->exp, &hol, True, cflw,
                                    &fixp->repay.pp, fixp->repay.aufab, &dummy);

        Bond_TaxAdjCflw(xcflw2, &fixp->tax, &fixp->fix.effective,
                        &fixp->cday.last) ;

        /* Horizon value - future payments */
        HV = Cflw_DF2Price(&horiz->settle, dfhz, xcflw2, &fixp->repay.pp, holi,
                           dfs, NULL, &dum, &dum) ;
        Free_CFLWARRAY(xcflw2, 1) ;
    }
    else
        HV = horiz->price ;

    /* Cashflow from settle to horizon */
    horiz->price = 0.0 ;
    settle->nom  = 100.0 ;
    xcflw1 = Cflw_ExtractPeriod(settle, horiz, &fixp->fix, &fixp->cday.pseq,
                                 &fixp->accru, &fixp->exp, &hol, True, cflw,
                                 &fixp->repay.pp, fixp->repay.aufab, &dummy) ;

    /* Adjust for redemptions in the period */
    for (rg = 0.0, i = 1; i < xcflw1->filled; i++)
        rg += xcflw1->repay[i] ;

    HV *= 1.0 - rg / 100.0 ;

    Bond_TaxAdjCflw(xcflw1, &fixp->tax, &fixp->fix.effective,
                    &fixp->cday.last) ;

    if (hzyc->reinv == True)
    {
        /* Horizon value - reinvested payments */
		dH = Disc_Interpolation(&horiz->settle, dfre, holi);  /* PMSTA-22396 - SRIDHARA � 160502 */

        for (i = 1; i < xcflw1->filled; i++)
        {
            if (fabs(dH) > 0.0000001)
            {
                pmt  = xcflw1->coupon[i] + xcflw1->repay[i] ;
                pmt *= Disc_Interpolation(&xcflw1->days[i], dfre, holi) / dH ;  /* PMSTA-22396 - SRIDHARA � 160502 */
                HV  += pmt ;
            }
        }

        /* Reshuffle the cashflow */
        xcflw1->filled    = 2 ;
        xcflw1->days[1]   = horiz->settle ;
        xcflw1->coupon[1] = 0.0 ;
        xcflw1->repay[1]  = HV ;
    }
    else
    {
        /* Set horizon value */
        ix = Cldr_FindDateIndex(xcflw1->days, xcflw1->filled, &horiz->settle,
                                 0, SEARCH_BISECTION, SAMEINDEX) ;
        if (ix < xcflw1->filled)
            xcflw1->repay[ix] += HV ;
        else
        {
            /* Occasionally end date is not in xcflw1 ! */
            if (xcflw1->count > xcflw1->filled)
            {
                ix = xcflw1->filled ;
                xcflw1->days[ix]   = horiz->settle ;
                xcflw1->repay[ix]  = HV ;
                xcflw1->coupon[ix] = 0.0 ;
                xcflw1->filled    += 1 ;
            }
            else
            {
                ix = GETMIN(ix, xcflw1->filled - 1) ;
                xcflw1->repay[ix] += HV ;
            }
        }
    }

    /* Horizon return */
    ok = RepoCflw_YTM2Yield(settle->price, xcflw1, &horiz->settle, &hzyc->ytmc,
                            &fixp->cday, fixp->fix.fix_rate, &fixp->repay.pp, 
                            holi, ictrl, hzy) ;

    Free_CFLWARRAY(cflw, 1) ;
    Free_CFLWARRAY(xcflw1, 1) ;

    return ok ;
}


/*,,SOH,,
*************************************************************************
*
*               Cflw_DF2Spread()
*
*   interface   #include <bond.h>
*               BOOLE Cflw_DF2Spread(FL64       price,
*                                    DISCFAC    *df,
*                                    CFLW_STR   *xcflw,
*                                    PP_STR     *pp,
*                                    HOLI_STR   *holi,
*                                    DFSPREAD   *dfs,
*                                    ITERCTRL   *ictrl,
*                                    FL64       *oas) ;
*
*   general     Cflw_DF2Spread() calculates the implied spread given
*               a price of a bond and a discount factor curve.
*
*               The price to be matched is the clean price on the
*               settlement day (xcflw->days[0]).
*
*               The cashflow on which to calculate yield should NOT
*               have been adjusted for non-businessdays prior to calling*
*               this routine. This is performed in this routine.
*
*   input       FL64      price         The clean price on settlement
*
*               DISCFAC   *df           Discounting structure setup.
*
*               CFLW_STR  *xcflw        The extracted cashflow from
*                                       the relevant period.
*                                       Must have the format defined
*                                       by Bond_GenrPeriod().
*                                       Cashflow is NOT adjusted for
*                                       businessdays.
*                                       The outstanding debt on the
*                                       bond must be 100.
*                                       The first date in the flow is
*                                       the settlement date.
*
*               PP_STR    *pp           Partly Paid setup. pp->pp_price
*                                       is not used.
*                                       Enter NULL if not needed.
*
*               HOLI_STR  *holi         Container for data on business
*                                       day convention and non-week-end
*                                       holidays.
*
*               DFSPREAD  *dfs          Quoting of the spread.
*
*               ITERCTRL  *ictrl        Iteration control
*
*   output      FL64      *oas          The calibrated spread.
*
*   returns     The clean price of the bond on the analysis date.
*
*   diagnostics
*
*   see also    Bond_DF2Spread()
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/

BOOLE Cflw_DF2Spread(FL64    price,
                     DISCFAC*    df,
                     CFLW_STR*   xcflw,
                     PP_STR*     pp,
                     HOLI_STR*   holi,
                     DFSPREAD*   dfs,
                     ITERCTRL*   ictrl,
                     FL64*       oas)
{
    BOOLE    ok ;
    FL64     shock ;
    DATESTR  analys ;
    DFSPREAD dfs_tmp ;
    SPREADINT   spr_data ;
    ITERCTRL ctrl ;
    NR_ERR   err ;

    /* Initialise */
    bond_set_itervars(ictrl, &ctrl, &shock, False) ;

    Cldr_Move2BusinessDays(xcflw->days, xcflw->filled, holi) ;
    analys = xcflw->days[0] ;

    /* Initial guess */
    dfs_tmp = *dfs ;
    dfs_tmp.spr_list = NULL ;

    spr_data = Cflw_SetSPREADINT(price, df, xcflw, pp, &analys, 
      &dfs_tmp, shock) ;

	err = Newton_Raphson(&Cflw_NewtonRaphson, &spr_data, &ctrl, oas, holi);  /* PMSTA-22396 - SRIDHARA � 160502 */
    ok = (err == NR_ROOT_FOUND ? True : False) ;

    return ok ;
}


/*,,SOH,,
*************************************************************************
*
*               Bond_DF2Spread()
*
*   interface   #include <bond.h>
*               BOOLE Bond_DF2Spread(TRADEINFO  *trade,
*                                    FIXPAY     *fixp,
*                                    DISCFAC    *df,
*                                    HOLI_STR   *holi,
*                                    DFSPREAD   *dfs,
*                                    ITERCTRL   *ictrl,
*                                    FL64       *oas) ;
*
*   general     Bond_DF2Spread() calculates the implied spread given
*               a price of a bond and a discount factor curve.
*
*               The price to be matched is the clean price on the
*               settlement day.
*
*   input       TRADEINFO *trade        The trade data
*
*               FIXPAY    *fixp         The bond definition
*
*               DISCFAC   *df           Discounting structure setup.
*
*               HOLI_STR  *holi         Container for data on business
*                                       day convention and non-week-end
*                                       holidays.
*
*               DFSPREAD  *dfs          Quoting of the spread.
*
*               ITERCTRL  *ictrl        Iteration control
*
*   output      FL64      *oas          The calibrated spread.
*
*   returns     True if all OK, False if not.
*
*   diagnostics
*
*   see also    Cflw_DF2Spread()
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/

BOOLE Bond_DF2Spread(TRADEINFO* trade,
                     FIXPAY*     fixp,
                     DISCFAC*    df,
                     HOLI_STR*   holi,
                     DFSPREAD*   dfs,
                     ITERCTRL*   ictrl,
                     FL64*       oas)
{
    CFLWARRAY xcflw ;
    BOOLE     ok ;
    HOLI_STR  hol ;

    hol   = bond_set_holi(holi, &fixp->fix) ;
    xcflw = Bond_GenrCflw(trade, fixp, &hol) ;

    ok = Cflw_DF2Spread(trade->price, df, xcflw, &fixp->repay.pp, holi, dfs,
                        ictrl, oas) ;

    Free_CFLWARRAY(xcflw, 1) ;

    return ok ;
}


/*,,SOH,,
*************************************************************************
*
*              Bond_GenrCflw()
*
*    interface #include <bond.h>
*              CFLWARRAY Bond_GenrCflw(TRADEINFO *start,
*                                       FIXPAY    *fixp,
*                                       HOLI_STR  *holi) ;
*
*    general   This function generates cash flow for bonds from start
*              date till maturity.
*              Note that holiday adjustment is deliberatly delayed
*              till after the coupon generation as this never occurs
*              in the bond markets.
*              Thus, the holpre switch is never used here.
*
*    input     TRADEINFO  *start     The first trade date
*
*              FIXPAY     *fixp      The bond data
*
*              HOLI_STR   *holi      Business day adjustment data
*
*    returns   Pointer to cashflow generated. Allocated in this routine
*              as Alloc_CFLWARRAY(1, x), where x is calculated.
*
*    diagnostics
*
*    see also
*
*    wrapper   AP
*
*************************************************************************
,,EOH,,*/

CFLWARRAY Bond_GenrCflw(TRADEINFO* start,
                         FIXPAY*    fixp,
                         HOLI_STR*  holi,
						 FL64ARRAY  intrRate,
						 FLAG_T mktConvMethodEnblFlg)    /* PMSTA-42879 - SRIDHARA - 18032021 */
{
    CFLWARRAY cflw, xcflw ;
    FL64      onom ;
    TRADEINFO end ;
    EXINF     dummy ;
  
    Math_LaGuerre(fixp->fix.effective.y, fixp->fix.effective.m, 
      fixp->fix.effective.d);

    /* Initialise */
    onom = start->nom ;
    start->nom = 100.0 ;
    end = bond_set_tradeinfo(&fixp->cday.last) ;

	/* PMSTA-36049 - Silpakal - 191029 */
    cflw = Cflw_GenrCflw(&fixp->repay, &fixp->rday, &fixp->fix,
                         &fixp->cday, holi, intrRate, mktConvMethodEnblFlg);   /* PMSTA-42879 - SRIDHARA - 18032021 */

    /* Extract period */
    xcflw = Cflw_ExtractPeriod(start, &end, &fixp->fix, &fixp->cday.pseq,
                               &fixp->accru, &fixp->exp, holi, True, cflw,
                               &fixp->repay.pp, fixp->repay.aufab, &dummy, mktConvMethodEnblFlg) ;

    Bond_TaxAdjCflw(xcflw, &fixp->tax, &fixp->fix.effective,
                    &fixp->cday.last) ;

    /* Now it is time to adjust */
    Cldr_Move2BusinessDays(xcflw->days, xcflw->filled, holi) ;

    /* Clean up */
    Free_CFLWARRAY(cflw, 1) ;
    start->nom = onom ;

    return xcflw ;
}


/*,,SOH,,
*************************************************************************
*
*              Bond_GenrPeriod()
*
*    interface #include <bond.h>
*              CFLWARRAY Bond_GenrPeriod(TRADEINFO *start,
*                                         TRADEINFO *end,
*                                         FIXPAY    *fixp,
*                                         HOLI_STR  *holi) ;
*
*    general   This function generates cash flow for bonds from start
*              date til end date. Note that the cashflow generated is
*              a period cashflow, i.e. the cashflow from holding the
*              bond from start to end and the reselling at end date.
*
*              To generate the pure bond cash flow, not including
*              reselling, use Bond_GenrCflw to generate the full cflw.
*              and Cflw_ExtractCflw to truncate at end date.
*
*    input     TRADEINFO  *start     The period startdate
*
*              TRADEINFO  *end       The period end date
*
*              FIXPAY     *fixp      The bond data
*
*              HOLI_STR   *holi      Business day adjustment data
*
*    returns   Pointer to cashflow generated. Allocated in this routine
*              as Alloc_CFLWARRAY(1, x), where x is calculated.
*
*    diagnostics
*
*    see also  Bond_GenrCflw()
*              Cflw_ExtractCflw()
*              Cflw_ExtractPeriod()
*
*    wrapper   AP
*
*************************************************************************
,,EOH,,*/

CFLWARRAY Bond_GenrPeriod(TRADEINFO* start,
                             TRADEINFO* end,
                             FIXPAY*    fixp,
                             HOLI_STR*  holi)
{
    CFLWARRAY cflw, xcflw ;
    FL64      onom ;
    EXINF     dummy ;
    HOLI_STR  hol ;

    /* Initialise */
    onom = start->nom ;
    start->nom = 100.0 ;

    /* Avoid business day adjustment here */    
    hol  = Set_HOLI_STR(NO_BUSADJUST, 0, NULL) ;
    cflw = Cflw_GenrCflw(&fixp->repay, &fixp->rday, &fixp->fix,
                         &fixp->cday, &hol) ;

    /* Extract period */
    xcflw = Cflw_ExtractPeriod(start, end, &fixp->fix, &fixp->cday.pseq,
                               &fixp->accru, &fixp->exp, holi, True, cflw,
                               &fixp->repay.pp, fixp->repay.aufab, &dummy) ;

    Bond_TaxAdjCflw(xcflw, &fixp->tax, &fixp->fix.effective,
                    &fixp->cday.last) ;

    /* Now it is time to adjust */
    Cldr_Move2BusinessDays(xcflw->days, xcflw->filled, holi) ;

    /* Clean up */
    Free_CFLWARRAY(cflw, 1) ;
    start->nom = onom ;

    return xcflw ;
}


/*,,SOH,,
*************************************************************************
*
*              Bond_Accruint()
*
*    interface #include <bond.h>
*              AIRESULT Bond_Accruint(TRADEINFO   *basis,
*                                     FIXPAY      *fixp,
*                                     HOLI_STR    *holi) ;
*
*    general   This function calculates the accrued interest for a bond
*              at any time during the life of the bond.
*              The value returned is per 100 outstanding at time basis.
*
*    input     TRADEINFO   *basis    The settle date info. AI is
*                                    calculated on basis->aisettle
*                                    If basis->brd is False 
*                                    only basis->aisttl is used
*
*              FIXPAY     *fixp      The bond data
*
*              HOLI_STR   *holi      Business day adjustment data
*
*    output
*
*    returns   Various data on the calculation as an AIRESULT struct.
*
*    diagnostics
*
*    see also
*
*    wrapper   AP
*
*************************************************************************
,,EOH,,*/


AIRESULT Bond_Accruint(TRADEINFO* basis,
                       FIXPAY*      fixp,
                       HOLI_STR*    holi,
					   FLAG_T       mktConvMethodEnblFlg)
{
    CFLWARRAY cflw ;
    AIRESULT  aires ;
       
    /* PMSTA-36049 - Silpakal - 191029 */
    cflw = Cflw_GenrCflw(&fixp->repay, &fixp->rday, &fixp->fix,
                         &fixp->cday, holi,NULL,mktConvMethodEnblFlg);

    /* Do the calculation */
    aires = Cflw_Accruint(basis, cflw, &fixp->fix, &fixp->cday.pseq,
                          &fixp->accru, holi, fixp->repay.pp.ppmts, NEXTINDEX, mktConvMethodEnblFlg) ;    /*  FPL-PMSTA00211-100826 add NEXTINDEX */

    /* Clean up */
    Free_CFLWARRAY(cflw, 1) ;

    return aires ;
}


/*,,SOH,,
*************************************************************************
*
*              Bond_TaxAdjCflw()
*
*    interface #include <bond.h>
*              void Bond_TaxAdjCflw(CFLW_STR    *xcflw,
*                                   TAXINFO     *tax,
*                                   DATESTR     *eff,
*                                   DATESTR     *matur) ;
*
*    general   This function adjusts a cashflow for tax. Coupon tax on
*              coupons and accrued interest is handled, as well as
*              capital gains tax. However the adjustment is rather crude*
*              and does not handle all sorts of country specific rules.
*
*              The adjustment simply multiplies the payments with the
*              appropriate factors.
*
*    input     CFLW_STR   *xcflw     Cashflow as generated from
*                                    Bond_GenrPeriod()
*
*              TAXINFO    *tax       Taxation scheme
*
*              DATESTR    *eff       Effective date. Used to calculate
*                                    pro rata capital gain tax.
*                                    Enter NULL if not used
*
*              DATESTR    *matur     Maturity of bond. Used to calculate*
*                                    pro rata capital gain tax.
*                                    Enter NULL if not used
*
*    output
*
*    returns
*
*    diagnostics
*
*    see also  Bond_GenrPeriod()
*
*************************************************************************
,,EOH,,*/

void Bond_TaxAdjCflw(CFLW_STR* xcflw,
                        TAXINFO*  tax,
                        DATESTR* eff,
                        DATESTR* matur)
{
    INTI i ;
    FL64 rata, cg_tax, tax_cg, tax_c, bp_tax, d1, d2 ;

    tax_c  = tax->tax_c  / 100.0 ;
    tax_cg = tax->tax_cg / 100.0 ;
    bp_tax = tax->bp_tax / 100.0 ;

    for (i = 0; i < xcflw->filled; i++)
    {
        /* Coupon tax */
        xcflw->coupon[i] *= 1.0 - tax_c ;

        /* Capital Gains Tax. Realisation-based */
        if (xcflw->repay[i] > P_TOL && bp_tax > P_TOL)
        {
            if (tax->pro_rata == True)
            {
				/* PMSTA-22396 - SRIDHARA � 160502 */
                d1 = (FL64) Cldr_DaysBetweenDates(eff, &xcflw->days[0], ACTACT, NULL);
                d2 = (FL64) Cldr_DaysBetweenDates(eff, matur, ACTACT, NULL);
                rata = SafeDivide(d1, d2, P_TOL, 1.0) ;
            }
            else
                rata = 1.0 ;

            cg_tax = xcflw->repay[i] * (1.0 - bp_tax) * tax_cg ;
            xcflw->repay[i] -= cg_tax * rata ;
        }
    }
}


/*,,SOH,,
*************************************************************************
*
*               Bond_Zero2FIXPAY()
*
*   interface   #include <bond.h>
*               FIXPAY Bond_Zero2FIXPAY(DATESTR *matur) ;
*
*   general     The function translates a zerocoupon bond into a FIXPAY
*
*   input       DATESTR     *matur      The maturity date
*
*   output
*
*   returns     FIXPAY holding zerocoupon bond
*
*   diagnostics
*
*   see also
*
*************************************************************************
,,EOH,,*/

FIXPAY Bond_Zero2FIXPAY(DATESTR* matur)
{
    FIXPAY  fixp ;
    DATESTR start ;

    start = Cldr_AddDays(matur, (INTL) -1, ACTACT, NULL) ;  /* PMSTA-22396 - SRIDHARA � 160502 */
    fixp  = Bond_Simple2FIXPAY(&start, NULL, matur, 0.0, NO_FREQUENCY,
                               BULLET, NULL, NULL, EU30E360, LAST);
    return fixp ;
}


/*,,SOH,,
*************************************************************************
*
*               Bond_Simple2FIXPAY()
*
*   interface   #include <bond.h>
*               FIXPAY Bond_Simple2FIXPAY(DATESTR   *settle,
*                                         DATESTR   *issue,
*                                         DATESTR   *matur,
*                                         FL64      coupon,
*                                         PMTFREQ   freq,
*                                         BONDTYPE  type,
*                                         EXRULE    *exc,
*                                         EXRULE    *exp,
*                                         CALCONV   cal,
*                                         EOMCONV   eom) ;
*
*   general     Bond_Simple2FIXPAY() is used to translate simple bond
*               data into the more general FIXPAY container.
*
*   input       DATESTR   *settle       The settlement date
*
*               DATESTR   *issue        The issue date. If this is not
*                                       available use settle here.
*                                       NULL for default values
*
*               DATESTR   *matur        The maturity date.
*
*               FL64      coupon        Coupon rate (%)
*
*               PMTFREQ   freq          Pay frequency
*
*               BONDTYPE  type          The repaytype
*
*               EXRULE    *exc          Ex-coupon setup
*                                       NULL for default values
*
*               EXRULE    *exp          Ex-princ. setup
*                                       NULL for default values
*
*               CALCONV   cal           Calendar
*
*               EOMCONV   eom           End of month convention
*
*   output
*
*   returns     The FIXPAY container set in this routine.
*               All pointer values are set to NULL
*
*   diagnostics
*
*   see also
*
*************************************************************************
,,EOH,,*/

FIXPAY Bond_Simple2FIXPAY(DATESTR* settle,
                          DATESTR*   issue,
                          DATESTR*   matur,
                          FL64      coupon,
                          PMTFREQ   freq,
                          BONDTYPE  type,
                          EXRULE*    exc,
                          EXRULE*    exp,
                          CALCONV   cal,
                          EOMCONV   eom)
{
    FIXPAY    fixp ;
    INTI      months ;
    DATESTR   dissue, first, prev ;
    PAYDAYSEQ pseq ;

    if (issue == NULL)
        dissue = *settle ;
    else
        dissue = *issue ;

    months = Cflw_MonthsBetweenPayments(freq) ;
    if (months == 0)
        months = 12 ;

    prev  = Cldr_FindPrevTerm(settle, matur, months, eom) ;
    first = Cldr_FindNextTerm(settle, &prev, months, eom) ;

    /* Beware of forward starting bonds */
    if (Cldr_DateLT(settle, &dissue) == True)
    {
        prev  = dissue ;
        first = Cldr_FindNextTerm(&prev, &prev, months, eom) ;
    }

    /* Be careful in last coupon period */
    if (Cldr_DateLT(matur, &first) == True)
        first = *matur ;

    /* Set fixrate */
    fixp.fix = Set_FIXRATE(coupon, cal, &prev, NULL, 0.0, EVENCOUP,
                           EVENCOUP, False, False, NULL, False, NULL,
                           NODCOMP) ;

    /* Set payday_str */
    pseq = Set_PAYDAYSEQ(months, MONTHS, NOODD, NOODD, ANCHOR, eom) ;
    fixp.cday = Set_PAYDAYDEF(True, &first, NULL, matur, False,
                              &pseq, 0, NULL) ;

    /* Set repaymnt */
    fixp.repay = Set_REPAYMNT(type, NULL, False, 0.0, NULL,
                              NULL, NULL, 0.0, 0.0) ;

    /* Set payday_str */
    fixp.rday = Set_PAYDAYDEF(True, &first, NULL, matur, False,
                              &pseq, 0, NULL) ;

    /* Set exp */
    if (exp != NULL)
        fixp.exp = *exp ;
    else
        fixp.exp = Set_EXRULE(EX_DAYS, 0, True, EU30E360, NULL,
                              0, NULL, NULL, True) ;

    /* Set accru */
    fixp.accru = Set_ACCRUINT(cal, EVENCOUP, EVENCOUP, False, False,
                              SIMPLE_MM, 1, False, False, False, exc) ;

    /* Set taxation */
    fixp.tax = Set_TAXINFO(0.0, 0.0, 0.0, False) ;

    return fixp ;
}


/*,,SOH,,
*************************************************************************
*
*               Cflw_DF2Delta()
*
*   interface   #include <bond.h>
*               FL64ARRAY Cflw_DF2Delta(DATESTR    *analys,
*                                       DISCFAC    *df,
*                                       CFLW_STR   *xcflw,
*                                       PP_STR     *pp,
*                                       HOLI_STR   *holi,
*                                       DFSPREAD   *dfs,
*                                       DELTASET   *ds) ;
*
*   general     The routine calculates the delta vector for a
*               cashflow using a list of predefined shocks to the zero
*               coupon curve.
*
*               The delta vector represents the price differences
*               invoked by the curve shocks.
*
*   input       DATESTR   *analys       The analysis date.
*
*               DISCFAC   *df           Discounting structure setup.
*                                       The initial (unshocked) curve
*                                       should be in df->disc.
*
*               CFLW_STR  *xcflw        The extracted cashflow from
*                                       the relevant period.
*                                       Must have the format defined
*                                       by Bond_GenrPeriod().
*                                       Cashflow is NOT adjusted for
*                                       businessdays.
*                                       The outstanding debt on the
*                                       bond must be 100.
*
*               PP_STR    *pp           Partly Paid setup. pp->pp_price
*                                       is not used.
*                                       Enter NULL if not needed.
*
*               HOLI_STR  *holi         Container for data on business
*                                       day convention and non-week-end
*                                       holidays.
*
*               DFSPREAD  *dfs          Spread against the curve.
*                                       Enter NULL if no spread.
*
*               DELTASET  *ds           Delta vector defining data
*
*   output
*
*   returns     The delta vector allocated as:
*
*                         Alloc_FL64ARRAY(ds->nshock) ;
*
*   diagnostics
*
*   see also    Bond_DF2Price()
*               Disc_DeltaPrep()
*               Boot_DeltaPrep()
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/


FL64ARRAY Cflw_DF2Delta(DATESTR* analys,
                        DISCFAC*    df,
                        CFLW_STR*   xcflw,
                        PP_STR*     pp,
                        HOLI_STR*   holi,
                        DFSPREAD*   dfs,
                        DELTASET*   ds)
{
    return RepoCflw_DF2Delta(analys, df, xcflw, NULL, pp, holi, dfs, ds) ;
}



/*,,SOH,,
*************************************************************************
*
*               RepoCflw_DF2Delta()
*
*   interface   #include <bond.h>
*               FL64ARRAY RepoCflw_DF2Delta(DATESTR    *analys,
*                                           DISCFAC    *df,
*                                           CFLW_STR   *xcflw,
*                                           DATESTR    *matur,
*                                           PP_STR     *pp,
*                                           HOLI_STR   *holi,
*                                           DFSPREAD   *dfs,
*                                           DELTASET   *ds) ;
*
*   general     The routine calculates the delta vector for
*               a repo cflw using a list of predefined shocks to the
*               zero coupon curve.
*
*               The delta vector represents the price differences
*               invoked by the curve shocks.
*
*   input       DATESTR   *analys       The analysis date.
*
*               DISCFAC   *df           Discounting structure setup.
*                                       The initial (unshocked) curve
*                                       should be in df->disc.
*
*               CFLW_STR  *xcflw        The extracted cashflow from
*                                       the relevant period.
*                                       Must have the format defined
*                                       by Bond_GenrPeriod().
*                                       Cashflow is NOT adjusted for
*                                       businessdays.
*                                       The outstanding debt on the
*                                       bond must be 100.
*                                       The first date in the flow is
*                                       the settlement date.
*
*               DATESTR   *matur        The maturity date
*
*               PP_STR    *pp           Partly Paid setup. pp->pp_price
*                                       is not used.
*                                       Enter NULL if not needed.
*
*               HOLI_STR  *holi         Container for data on business
*                                       day convention and non-week-end
*                                       holidays.
*
*               DFSPREAD  *dfs          Spread against the curve.
*                                       Enter NULL if no spread.
*
*               DELTASET  *ds           Delta vector defining data
*
*   output
*
*   returns     The delta vector allocated as:
*
*                         Alloc_FL64ARRAY(ds->nshock) ;
*
*   diagnostics
*
*   see also    Bond_DF2Price()
*               Disc_DeltaPrep()
*               Boot_DeltaPrep()
*
*************************************************************************
,,EOH,,*/

FL64ARRAY RepoCflw_DF2Delta(DATESTR* analys,
                        DISCFAC*    df,
                        CFLW_STR*   xcflw,
                        DATESTR*    matur,
                        PP_STR*     pp,
                        HOLI_STR*   holi,
                        DFSPREAD*   dfs,
                        DELTASET*   ds)
{
    INTI      i ;
    FL64ARRAY dv ;
    FL64      p0, dum ;
    RISKSET   risk ;
    PLANARRAY old ;
    HOLI_STR  hol ;
    DATESTR   fsprev, last ;

    /* Initialise */
    dv        = Alloc_FL64ARRAY(ds->nshock) ;
    risk.risk = ZERO_ORDER ;
    old       = df->disc ;
    hol       = Set_HOLI_STR(NO_BUSADJUST, 0, NULL) ;

    /* Do this only once */
    Cldr_Move2BusinessDays(xcflw->days, xcflw->filled, holi) ;

    /* The unshocked price */
    p0 = RepoCflw_DF2Price(analys, df, xcflw, matur, pp, holi, dfs,
                           &risk, &dum, &dum) ;

    if (xcflw->filled > 0)
        last = xcflw->days[xcflw->filled - 1] ;
    else
        last = Cldr_YMD2Datestr((INTL) 0) ;

    for (i = 0; i < ds->nshock; i++)
    {
        fsprev = Disc_get_chgdate(NULL, old, &ds->shock[i]) ;

        if (fsprev.y > 0 && Cldr_DateLT(&last, &fsprev) == False)
        {
            df->disc = &ds->shock[i] ;
            dv[i]  = RepoCflw_DF2Price(analys, df, xcflw, matur, pp,
                                       &hol, dfs, &risk, &dum, &dum) ;
            dv[i] -= p0 ;
            if (ds->zero == True)
                /* Find shocked Zero PV */
				dv[i] /= Disc_DF2BPV(&ds->mid[i], df, old, holi);  /* PMSTA-22396 - SRIDHARA � 160502 */
        }
        else
            dv[i] = 0.0 ;
    }

    df->disc = old ;

    return dv ;
}


/*,,SOH,,
*************************************************************************
*
*               Bond_DF2Delta()
*
*   interface   #include <bond.h>
*               FL64ARRAY Bond_DF2Delta(DATESTR    *analys,
*                                       TRADEINFO  *trade,
*                                       FIXPAY     *fixp,
*                                       DISCFAC    *df,
*                                       HOLI_STR   *holi,
*                                       DFSPREAD   *dfs,
*                                       DELTASET   *ds) ;
*
*   general     Bond_DF2Delta() calculates the delta vector for
*               a bond using a list of predefined shocks to the zero
*               coupon curve.
*
*               The delta vector represents the price differences
*               invoked by the curve shocks.
*
*   input       DATESTR   *analys       The analysis date.
*
*                                          df->disc->day[0] <= analys
*
*               TRADEINFO *trade        The trade data
*
*               FIXPAY    *fixp         The bond definition
*
*               DISCFAC   *df           Discounting structure setup.
*                                       The initial (unshocked) curve
*                                       should be in df->disc.
*
*               HOLI_STR  *holi         Container for data on business
*                                       day convention and non-week-end
*                                       holidays.
*
*               DFSPREAD  *dfs          Spread against the curve.
*                                       Enter NULL if no spread.
*
*               DELTASET  *ds           Delta vector defining data
*
*   output
*
*   returns     The delta vector allocated as:
*
*                         Alloc_FL64ARRAY(ds->nshock) ;
*
*   diagnostics
*
*   see also    Bond_DF2Price()
*               Disc_DeltaPrep()
*               Boot_DeltaPrep()
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/


FL64ARRAY Bond_DF2Delta(DATESTR* analys,
                          TRADEINFO*  trade,
                          FIXPAY*     fixp,
                          DISCFAC*    df,
                          HOLI_STR*   holi,
                          DFSPREAD*   dfs,
                          DELTASET*   ds)
{
    CFLWARRAY xcflw ;
    HOLI_STR  hol ;
    FL64ARRAY dv ;

    hol   = bond_set_holi(holi, &fixp->fix) ;
    xcflw = Bond_GenrCflw(trade, fixp, &hol) ;
    dv = Cflw_DF2Delta(analys, df, xcflw, &fixp->repay.pp, holi, dfs, ds) ;
    Free_CFLWARRAY(xcflw, 1) ;

    return dv ;
}


/*
..
*/

TRADEINFO bond_set_tradeinfo(DATESTR* matur)
{
    TRADEINFO trade ;

/*
    trade.brd    = False ;
    trade.aisttl = *matur ;
    trade.settle = *matur ;
    trade.trade  = *matur ;
    trade.nom    = 100.0 ;
    trade.price  = 100.0 ;
    trade.xctrade.spec = False ;
    trade.xptrade.spec = False ;
*/
    trade = Set_TRADEINFO(matur, NULL, NULL, False, 100.0, 100.0, NULL, NULL) ;

    return trade ;
}


/*,,SOH,,
*************************************************************************
*
*               Cflw_YTM2Risk()
*
*   interface   #include <bond.h>
*               FL64ARRAY Cflw_YTM2Risk(BOOLEARRAY what,
*                                       INTI       nw,
*                                       FL64       pry,
*                                       BOOLE      p_y,
*                                       FL64       coupon,
*                                       CFLW_STR   *xcflw,
*                                       YTMCONV    *ytmc,
*                                       PAYDAYDEF  *pday,
*                                       PP_STR     *pp,
*                                       HOLI_STR   *holi,
*                                       YTMCONV    *ytmcr,
*                                       ITERCTRL   *ictrl,
*                                       CALCONV    cal_mm,
*                                       BOOLE      *ok)
*
*   general     The function calculates a number of Risk Ratios relating*
*               to YTM for bonds.
*
*               The cashflow on which to calculate yield should NOT
*               have been adjusted for non-businessdays prior to calling*
*               this routine. This is performed in this routine.
*
*               A special case occur when the coming payment is ex.
*               If the first fractional period is till the 'empty'
*               payment, the 'empty' payment must be visible in the in
*               xcflw (use fill = True in Bond_GenrPeriod().
*               If this payment is ignored, when calculating YTM, then
*               use fill = False in Bond_GenrPeriod(). In this case
*               the first fractional period is longer than a normal
*               coupon period.
*
*               The array returned contains:
*
*                   result[0]      YTM (ytmc)
*                   result[1]      YTM (SIMPLE_MM)
*                   result[2]      YTM (AIBD)
*                   result[3]      Clean Price
*                   result[4]      Dirty Price
*                   result[5]      Accrued Interest
*                   result[6]      Remaining Life (in Years)
*                   result[7]      Average Remaining Life (in Years)
*                   result[8]      $ Duration
*                   result[9]      $ Convexity
*                   result[10]     Current Yield
*                   result[11]     Modified Duration
*                   result[12]     Modified Convexity
*                   result[13]     Duration
*                   result[14]     YTM (ytmcr)
*
*               If the corresponding element of what is True, if that
*               element of what is False, then the corresponding result
*               data is not set.
*
*               If nw is smaller than 15 then result is allocated
*               with nw elements, and only those elements indicated are
*               calculated.
*
*   input       BOOLEARRAY what         Array with boolean elements. If
*                                       what[ix] is True then the cor-
*                                       responding result array element
*                                       is set.
*                                       Dimension [nw]
*
*               INTI       nw           Number of elements in what
*                                       should be at least 4.
*
*               FL64       pry          Price or Yield
*
*               BOOLE      p_y          True if pry is price, False if
*                                       pry is Yield.
*
*               FL64       coupon       The bond's coupon. Only needed
*                                       for current yield calculation.
*
*               CFLW_STR   *xcflw       The extracted cashflow from
*                                       the relevant period.
*                                       Must have the format defined
*                                       by Bond_GenrPeriod().
*                                       Cashflow is NOT adjusted for
*                                       businessdays.
*                                       The outstanding debt on the
*                                       bond must be 100.
*
*               YTMCONV    *ytmc        The conventions defined for
*                                       calculating the YTM.
*
*               PAYDAYDEF  *pday        Pointer to the description of
*                                       the payday sequence.
*
*               PP_STR     *pp          Partly Paid setup. pp->pp_price
*                                       is not used.
*                                       Enter NULL if not needed.
*
*               HOLI_STR   *holi        Container for data on business
*                                       day convention and non-week-end
*                                       holidays.
*                                       Used to calculate businessday
*                                       adjusted yield.
*
*               YTMCONV    *ytmcr       Conventions used for:
*                                       $Dur/$Conv/ModDur/ModConv/
*                                       Duration Calculations.
*
*               ITERCTRL   *ictrl       Iteration control
*
*               CALCONV    cal_mm       Calendar convention for calcu-
*                                       lating result[1].
*
*   output      BOOLE      *ok          True if all OK, False if not.
*
*   returns     Array with nw elements. Allocated as:
*
*                          Alloc_FL64ARRAY(nw)
*
*               Elements 0, 3, 4, 5 are always filled.
*
*   diagnostics
*
*   see also
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/

FL64ARRAY Cflw_YTM2Risk(BOOLEARRAY what,
                        INTI       nw,
                        FL64       pry,
                        BOOLE      p_y,
                        FL64       coupon,
                        CFLW_STR*   xcflw,
                        YTMCONV*    ytmc,
                        PAYDAYDEF*  pday,
                        PP_STR*     pp,
                        HOLI_STR*   holi,
                        YTMCONV*    ytmcr,
                        ITERCTRL*   ictrl,
                        CALCONV    cal_mm,
                        BOOLE*      ok)
{
    FL64ARRAY  res ;
    RISKCONV   risk = ZERO_ORDER;
    FL64       y_r = 0, dp, ddp, coup ;
    YTMCONV    yc ;
    FL64ARRAY  terms ;

/*
..paydaydef needed ???????
*/

    if (xcflw->filled > 2)
        coup = Cflw_Extract_Coupon(xcflw) ;
    else
        coup = 0.0 ;

    *ok = True ;
    res = Alloc_FL64ARRAY(nw) ;
    if (nw < 4)
        return res ;

    if (nw >= 12 && what[11])
        what[8] = True ;

    if (nw >= 13 && what[12])
        what[9] = True ;

    /* Price based */
    if (nw >= 4 && p_y == True)
    {
        res[3] = pry ;
        *ok    = Cflw_YTM2Yield(pry, xcflw, ytmc, pday, coup, pp, 
                                holi, ictrl, &res[0]) ;
        risk   = ZERO_ORDER ;
        y_r    = res[0] ;

        if (bond_comp_ytmc(ytmc, ytmcr) == False && nw >= 14 &&
           (what[8] || what[9] || what[13]))
            *ok = Cflw_YTM2Yield(pry, xcflw, ytmcr, pday, coup, pp, 
                                 holi, ictrl, &y_r) ;
    }

    /* Yield based */
    else if (nw >= 4)
    {
        if (bond_comp_ytmc(ytmc, ytmcr) == True && nw >= 10 && (what[8] ||
          what[9]) )
            risk = SECOND_ORDER ;
        else
            risk = ZERO_ORDER ;

        y_r    = res[0] = pry ;
        res[3] = Cflw_YTM2Price(pry, xcflw, ytmc, pday, coup, pp, holi, 
                                risk, False, &dp, &ddp) ;

        if (nw >= 10 && risk == SECOND_ORDER)
        {
            if (what[8] == False)
                res[8] = 0.0 ;
            else
                res[8] = dp ;

            if (what[9] == False)
                res[9] = 0.0 ;
            else
                res[9] = ddp ;
        }

        if (bond_comp_ytmc(ytmc, ytmcr) == False && nw >= 14 &&
           (what[8] || what[9] || what[13]))
            *ok = Cflw_YTM2Yield(res[3], xcflw, ytmcr, pday, coup, pp, holi, 
                                 ictrl, &y_r) ;
    }

    /* NB: By now res[0] & res[3] have been set */
    if (*ok == False)
        return res ;

    /* Accrued Interest - res[5] */
    if (nw >= 6)
        res[5] = -xcflw->coupon[0] ;

    /* Dirty Price - res[4] */
        if (nw >= 6)
    res[4] = res[3] + res[5] ;

    /* DolDur + DolConv - res[8, 9] */
    if (risk == ZERO_ORDER && nw >= 10 && (what[8] || what[9]))
    {
        dp = Cflw_YTM2Price(y_r, xcflw, ytmcr, pday, coup, pp, holi, 
                            SECOND_ORDER, False, &res[8], &res[9]) ;
        if (what[8] == False)
            res[8] = 0.0 ;

        if (what[9] == False)
            res[9] = 0.0 ;
    }

    /* Rem. Life (SAL) - res[6] */
    if (nw >= 7 && what[6] && xcflw->filled >= 2)
    {
/*
        res[6] = Cldr_TermBetweenDates(&xcflw->days[0],
                                       &xcflw->days[xcflw->filled - 1],
                                       0, ytmc->cal_first, LAST) ;
*/
        terms = Bond_GenrTerms(&xcflw->days[0], xcflw, ytmcr, pday, holi) ;
        res[6] = terms[xcflw->filled -1 ];
        Free_FL64ARRAY(terms) ;
    }

    /* WAL - res[7] */
    if (nw >= 8 && what[7])
        res[7] = Cflw_WAL(xcflw, ytmcr, pday, holi) ;

    /* IRR - MM - res[1] */
    if (nw >= 4 && what[1])
    {
        yc.irr        = SIMPLE_MM ;
        yc.qb_ytm     = ANNUALLY ;
        yc.cal_first  = cal_mm ;
        yc.cal_normal = cal_mm ;
        yc.cal_last   = cal_mm ;
        yc.dayfrac_first  = True ;
        yc.dayfrac_normal = True ;
        yc.dayfrac_last   = True ;
        yc.trueYTM        = True ;

        *ok = Cflw_YTM2Yield(res[3], xcflw, &yc, pday, coup, pp, holi, 
                             ictrl, &res[1]) ;

        if (*ok == False)
            return res ;
    }

    /* IRR - AIBD - res[2] */
    if (nw >= 4 && what[2])
    {
        yc.irr        = COMPOUND ;
        yc.qb_ytm     = ANNUALLY ;
        yc.cal_first  = EU30E360 ;
        yc.cal_normal = EU30E360 ;
        yc.cal_last   = EU30E360 ;
        yc.dayfrac_first  = False ;
        yc.dayfrac_normal = False ;
        yc.dayfrac_last   = False ;
        yc.trueYTM        = False ;

        *ok = Cflw_YTM2Yield(res[3], xcflw, &yc, pday, coup, pp, holi, 
                             ictrl, &res[2]) ;

        if (*ok == False)
            return res ;
    }

    /* Current Yield - res[10] */
    if (nw >= 11 && what[10] && fabs(res[3]) > P_TOL)
        res[10] = 100.0 * coupon / res[3] ;

    /* Modified Duration - res[11] */
    if (nw >= 12 && what[11] && fabs(res[4]) > P_TOL)
        res[11] = - 100.0 * res[8] / res[4] ;

    /* Modified Duration - res[12] */
    if (nw >= 13 && what[12] && fabs(res[4]) > P_TOL)
        res[12] = 100.0 * res[9] / res[4] ;

    /* Duration - res[13] */
    if (nw >= 14 && what[13])
        res[13] = Cflw_YTM2Duration(y_r, xcflw, ytmcr, pday, holi) ;

    /* YTM - res[14] */
    if (nw >= 15 && what[14])
        *ok = Cflw_YTM2Yield(res[3], xcflw, ytmcr, pday, coup, pp, 
                             holi, ictrl, &res[14]) ;

    return res ;
}


/*,,SOH,,
*************************************************************************
*
*               Cflw_WAL()
*
*   interface   #include <bond.h>
*               FL64 Cflw_WAL(CFLW_STR   *xcflw,
*                             YTMCONV    *ytmc,
*                             PAYDAYDEF  *pday,
*                             HOLI_STR   *holi) ;
*
*   general     The routine calculates the Weighted Average Life (WAL)
*               for a cashflow.
*
*   input       CFLW_STR  *xcflw        The extracted cashflow from
*                                       the relevant period.
*                                       Must have the format defined
*                                       by Bond_GenrPeriod().
*                                       Cashflow is NOT adjusted for
*                                       businessdays.
*                                       The outstanding debt on the
*                                       bond must be 100.
*
*               YTMCONV   *ytmc         The conventions defined for
*                                       calculating the YTM.
*
*               PAYDAYDEF *pday         Pointer to the description of
*                                       the payday sequence.
*
*               HOLI_STR  *holi         Business day adjustment setup.
*
*   output
*
*   returns     The WAL as FL64
*
*   diagnostics
*
*   see also    Cflw_YTM2Yield()
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/


FL64 Cflw_WAL(CFLW_STR* xcflw,
              YTMCONV*    ytmc,
              PAYDAYDEF*  pday,
              HOLI_STR*   holi)
{
    FL64ARRAY terms ;
    FL64      res ;

    if (xcflw->filled < 2)
        return 0.0 ;

    terms = Bond_GenrTerms(&xcflw->days[0], xcflw, ytmc, pday, holi) ;
    res   = Math_WeightedAvg(xcflw->filled - 1, terms + 1, xcflw->repay + 1) ;

    Free_FL64ARRAY(terms) ;

    return res ;
}


/*,,SOH,,
*************************************************************************
*
*               Cflw_LIFE()
*
*   interface   #include <bond.h>
*               FL64 Cflw_LIFE(CFLW_STR   *xcflw,
*                              YTMCONV    *ytmc,
*                              PAYDAYDEF  *pday,
*                              HOLI_STR   *holi) ;
*
*   general     The routine calculates the Simple Life (SAL)
*               for a cashflow.
*
*   input       CFLW_STR  *xcflw        The extracted cashflow from
*                                       the relevant period.
*                                       Must have the format defined
*                                       by Bond_GenrPeriod().
*                                       Cashflow is NOT adjusted for
*                                       businessdays.
*                                       The outstanding debt on the
*                                       bond must be 100.
*
*               YTMCONV   *ytmc         The conventions defined for
*                                       calculating the YTM.
*
*               PAYDAYDEF *pday         Pointer to the description of
*                                       the payday sequence.
*
*               HOLI_STR  *holi         Business day adjustment setup.
*
*   output
*
*   returns     The LIFE as FL64
*
*   diagnostics
*
*   see also    Cflw_YTM2Yield()
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/

FL64 Cflw_LIFE(CFLW_STR* xcflw,
               YTMCONV*    ytmc,
               PAYDAYDEF*  pday,
               HOLI_STR*   holi)
{
    FL64ARRAY terms ;
    FL64      res ;

    if (xcflw->filled < 2)
        return 0.0 ;

    terms = Bond_GenrTerms(&xcflw->days[0], xcflw, ytmc, pday, holi) ;
    res   = terms[xcflw->filled -1 ];

    Free_FL64ARRAY(terms) ;

    return res ;
}


/*
..
*/

FL64 Cflw_Extract_Coupon(CFLW_STR* xcflw)
{
    FL64 debt, coupon ;
    INTI ix ;
    INTL days ;

    if (xcflw->filled < 2)
        return 0.0 ;
    else if (xcflw->filled == 2)
        /* Last period - this is not possible with these data */
        return xcflw->coupon[xcflw->filled - 1] ;
    else
    {
        /* This only works for 'standard' bonds */
        ix = (xcflw->filled - 1) / 2 ;
        ix = GETMAX(ix, 2) ;
        coupon = xcflw->coupon[ix] ;
        if (fabs(coupon) < P_TOL)
        {
            ix++ ;
            if (ix < xcflw->filled)
                coupon = xcflw->coupon[ix] ;
        }

        if (ix < xcflw->filled)
        {
            days = Cldr_DaysBetweenDates(&xcflw->days[ix - 1],
                                         &xcflw->days[ix], EU30E360, NULL) ;  /* PMSTA-22396 - SRIDHARA � 160502 */
            days = GETMAX(1, days);
            coupon *= 360.0 / (FL64) days ;
        }

        /* Divide by outstanding debt - if possible */
        debt = Cflw_DebtPerDate(&xcflw->days[ix - 1], xcflw->filled,
                                  xcflw->days, xcflw->repay, False, 0) ;
        if (fabs(debt) > P_TOL)
            coupon *= 100.0 / debt ;
    }

    return coupon ;
}


/*
..
*/

BOOLE bond_comp_ytmc(YTMCONV* y1, YTMCONV* y2)
{
    if (y1->irr == y2->irr &&
        y1->qb_ytm == y2->qb_ytm &&
        y1->cal_first == y2->cal_first &&
        y1->cal_normal == y2->cal_normal &&
        y1->cal_last == y2->cal_last &&
        y1->dayfrac_first == y2->dayfrac_first &&
        y1->dayfrac_normal == y2->dayfrac_normal &&
        y1->dayfrac_last == y2->dayfrac_last &&
        y1->trueYTM == y2->trueYTM)
        return True ;
    else
        return False ;
}


/*
..
*/

BOOLE bond_price2yield(FL64   price,
                       INTI      basis,
                       IRRCONV   irr,
                       FL64ARRAY rerates,
                       FL64      debt,
                       PMT_STR*   paym,
                       FL64      matur,
                       ITERCTRL*  ictrl,
					   FL64*      ytm,
					   HOLI_STR*  holi)      /* PMSTA-22396 - SRIDHARA � 160502 */
{
    FL64    *term, min ;

    min = (irr != SIMPLE_REPO ? YTM_MIN : YTM_MIN * 100.0) ;

    if (irr == SIMPLE_MM)
    {
        term = paym->term ;

        if (paym->count == 0 && term[paym->count - 1] > TERM_MIN)
            min = GETMAX(YTM_MIN, -100.0 / term[paym->count - 1]) ;
        else 
            min = YTM_MIN;
    }

    ictrl->lower = ((ictrl->use_lower) ? ictrl->lower : min ) ;
    ictrl->upper = ((ictrl->use_upper) ? ictrl->upper : YTM_MAX ) ;

    return bond_root(price, basis, irr, rerates, debt, paym,
                     matur, ictrl, ytm, holi) ;  /* PMSTA-22396 - SRIDHARA � 160502 */
}


/*
..
*/

BOOLE bond_root(FL64 price, INTI  qb, IRRCONV irr, 
                   FL64ARRAY rerate,  FL64 debt, PMT_STR* pmt,
                   FL64 matur, ITERCTRL* ictrl, FL64* ytm, HOLI_STR *holi)   /* PMSTA-22396 - SRIDHARA � 160502 */
{
    FL64      dum ;
    BOOLE     ok ;
    YTMINT    ytm_data ;
    ITERCTRL  ctrl ;
    NR_ERR    err ;

    bond_set_itervars(ictrl, &ctrl, &dum, True) ;

    ytm_data = Bond_SetYTMINT(price, qb, irr, rerate, debt, 
      pmt, matur) ;

	err = Newton_Raphson(&Bond_NewtonRaphson, &ytm_data, &ctrl, ytm, holi);  /* PMSTA-22396 - SRIDHARA � 160502 */
    ok = (err == NR_ROOT_FOUND ? True : False) ;

    return ok ;
    
}


/*
..Changes   FIXPAY->cday && FIXPAY->rday (if zero coupon)
            FIXPAY->repay.type (if YTMCONV->as_bullet is True)
*/

FIXPAY Bond_YTM_Prep(TRADEINFO* trade, FIXPAY* fixp, YTMCONV* ytmc)
{
    INTI    months ;
    DATESTR first, matur, prev ;
    EOMCONV eom ;
    FIXPAY  out ;

    out = Set_FIXPAY(&fixp->cday, &fixp->fix, &fixp->rday, &fixp->repay,
                     &fixp->accru, &fixp->exp, &fixp->tax) ;

    /* Be careful about zero coupons calculated using SIA */
    if (SCecon_fabs(out.fix.fix_rate) < 0.000001 &&
        GetPlanFill(out.fix.stepcoup) == 0)
    {
        months = Cflw_MonthsBetweenPayments(ytmc->qb_ytm) ;
        if (months == 0)
            months = 12 ;

        eom   = out.cday.pseq.eom ;
        matur = out.cday.last ;
        prev  = Cldr_FindPrevTerm(&trade->settle, &matur, months, eom) ;
        first = Cldr_FindNextTerm(&trade->settle, &prev, months, eom) ;

        /* Beware of forward starting bonds */
        if (Cldr_DateLT(&trade->settle, &out.fix.effective) == True)
        {
            prev  = out.fix.effective ; 
            first = Cldr_FindNextTerm(&prev, &prev, months, eom) ;
        }

        /* Be careful in last coupon period */
        if (Cldr_DateLT(&matur, &first) == True)
            first = matur ;

        out.cday.pseq.term = months ;
        out.cday.pseq.unit = MONTHS ;
        out.cday.first     = first ;

        if (out.repay.type == BULLET)
        {
            out.rday.pseq.term = months ;
            out.rday.pseq.unit = MONTHS ;
            out.rday.first     = first ;
        }
    }

    if (ytmc->as_bullet == True)
        out.repay.type = BULLET ;

    return out ;
}


/*
..
*/

IRRCONV Bond_Set_IRRCONV(CFLW_STR* cflw,
                            IRRCONV  irr,
                            EOMCONV  eom)
{
    DATESTR date ;

    if (cflw->filled == 2 && irr == COMPOUNDSIMPLE)
    {
        date = Cldr_AddMonths(&cflw->days[0], 12, eom) ;
        if (Cldr_DateLE(&cflw->days[1], &date) == True)
            irr = SIMPLE_MM ;
    }

    if (irr == COMPOUNDSIMPLE_ODD && cflw->filled > 0)
    {
        date = Cldr_AddMonths(&cflw->days[0], 12, eom) ;
        if (Cldr_DateLE(&cflw->days[cflw->filled - 1], &date) == True)
            irr = SIMPLE_MM ;
    }

    return irr ;
}


/*
..
*/

void bond_set_itervars(ITERCTRL*  ictrl,
                          ITERCTRL*  ctrl ,
                          FL64* shock,
                          BOOLE ytm)
{
    Init_ITERCTRL(ctrl) ;  

    if (ytm == True)
    {
      ctrl->maxiter = (ictrl->maxiter < 0 ? YTM_MAXIT : ictrl->maxiter) ;
      ctrl->lower = ictrl->lower ;
      ctrl->upper = GETMAX(ictrl->upper, ctrl->lower) ;
      ctrl->init_guess = ((ictrl->use_init_guess == False) || 
        (ictrl->init_guess > ctrl->upper) ||
        (ictrl->init_guess < ctrl->lower) ?
        GETMIN( GETMAX(YTM_GUESS, ctrl->lower), ctrl->upper) : 
        ictrl->init_guess) ;
      ctrl->damp = (ictrl->damp < 0.0 ?  YTM_DAMP : ictrl->damp) ;
      ctrl->acc = (ictrl->acc < 0.0 ? YTM_TOL : ictrl->acc) ;
      ctrl->what_acc = 1 ;
      ctrl->gfreq = (ictrl->gfreq < 0 ? YTM_FREQ : ictrl->gfreq) ; ;
      ctrl->bisec = (ictrl->bisec < 0 ? 1 : ictrl->bisec) ;
      ctrl->shock = 0.0 ;
      *shock = 1.0 ; /* not used */
    }
    else
    {
      ctrl->maxiter = (ictrl->maxiter < 0 ? OAS_MAXIT : ictrl->maxiter) ;
      ctrl->init_guess = (ictrl->use_init_guess == False ? 0.0 : 
        ictrl->init_guess) ;
        ctrl->lower = GETMIN((ictrl->use_lower ? ictrl->lower : OAS_MIN), 
        ctrl->init_guess) ;
        ctrl->upper = GETMAX((ictrl->use_upper ? ictrl->upper : OAS_MAX), 
        ctrl->init_guess) ;
      ctrl->damp = (ictrl->damp < 0.0 ?  YTM_DAMP : ictrl->damp) ;
      ctrl->acc = (ictrl->acc < 0.0 ? OAS_TOL : ictrl->acc) ;
      ctrl->what_acc = 1 ;
      ctrl->gfreq = (ictrl->gfreq < 0 ? OAS_FREQ : ictrl->gfreq) ; ;
      ctrl->bisec = (ictrl->bisec < 0 ? 1 : ictrl->bisec) ;
      ctrl->shock = 0.0 ;
      *shock = (ictrl->shock < 0.0 ? OAS_EPS : ictrl->shock) ;
    }
}

/*
..
*/

YTMINT Bond_SetYTMINT(FL64       price,
                         INTI       qb,
                         IRRCONV    irr,
                         FL64ARRAY  rerate,
                         FL64       debt,
                         PMT_STR*   pmt,
                         FL64       matur)
{
  YTMINT  ytm_data ;

  ytm_data.price = price ;
  ytm_data.qb = qb ;
  ytm_data.irr = irr ;
  ytm_data.rerate = rerate ;
  ytm_data.debt = debt ;
  ytm_data.pmt = pmt ;
  ytm_data.matur = matur ;

  return ytm_data ;
}

/*
..
*/

void Bond_GetYTMINT(YTMINT*    ytm_data,
                       FL64*       price,
                       INTI*       qb,
                       IRRCONV*    irr,
                       FL64ARRAY*  rerate,
                       FL64*       debt,
                       PMT_STR**   pmt,
                       FL64*       matur)
{
  *price = ytm_data->price ;
  *qb = ytm_data->qb ;
  *irr = ytm_data->irr ;
  *rerate = ytm_data->rerate ;
  *debt = ytm_data->debt ;
  *pmt = ytm_data->pmt ;
  *matur = ytm_data->matur ;
}

/*
..
*/

BOOLE Bond_NewtonRaphson(FL64    x, 
                            void*   y,
                            BOOLE   grad,
                            FL64*   fx, 
                            FL64*   dfx,
							void*   hol) 
{
	/* PMSTA-29444 - SRIDHARA - 050318 */
  HOLI_STR    holi = (*(HOLI_STR *)hol);  
  holi = Set_HOLI_STR(NO_BUSADJUST, 0, NULL);

  FL64      price, debt, matur, dum ;
  INTI      qb ;
  IRRCONV   irr ;
  FL64ARRAY rerate ;
  PMT_STR   *pmt ;
  RISKCONV  risk ;

  /* Get data from y */
  Bond_GetYTMINT((YTMINT*)y, &price, &qb , &irr, &rerate,
    &debt, &pmt, &matur) ;

  if (grad == True)
    risk = FIRST_ORDER ;
  else
    risk = ZERO_ORDER ;

  /* Compute fx */
  if (irr != SIMPLE_REPO)
    *fx = TVM_Yield2Price(x, risk, qb, debt,
      irr, rerate, pmt, dfx, &dum) - price ;
  else
    *fx = TVM_Simplerepo2Price(x, dfx, &dum, risk,
      debt, pmt,matur) - price ;

  return True ;
}

/*
..
*/

SPREADINT Cflw_SetSPREADINT(FL64       price,
                         DISCFAC*   df,
                         CFLW_STR*  xcflw,
                         PP_STR*    pp,
                         DATESTR*   analys,
                         DFSPREAD*  dfs_tmp,
                         FL64       shock)
{
  SPREADINT  spr_data ;

  spr_data.price = price ;
  spr_data.df = df ;
  spr_data.xcflw = xcflw ;
  spr_data.pp = pp ;
  spr_data.analys = analys ;
  spr_data.dfs_tmp = dfs_tmp ;
  spr_data.shock = shock ;

  return spr_data ;
}

/*
..
*/

void Cflw_GetSPREADINT(SPREADINT*     spr_data,
                       FL64*       price,
                       DISCFAC**   df,
                       CFLW_STR**  xcflw,
                       PP_STR**    pp,
                       DATESTR**   analys,
                       DFSPREAD**  dfs_tmp,
                       FL64*       shock)
{
  *price = spr_data->price ;
  *df = spr_data->df ;
  *xcflw = spr_data->xcflw ;
  *pp = spr_data->pp ;
  *analys = spr_data->analys ;
  *dfs_tmp = spr_data->dfs_tmp ;
  *shock = spr_data->shock ;
}

/*
..
*/

BOOLE Cflw_NewtonRaphson(FL64    x, 
                            void*   y,
                            BOOLE   grad,
                            FL64*   fx, 
                            FL64*   dfx,
							void*   hol) 
{
  /* PMSTA-29444 - SRIDHARA - 050318 */
  HOLI_STR    holi = (*(HOLI_STR *)hol);
  holi = Set_HOLI_STR(NO_BUSADJUST, 0, NULL);

  FL64      price, shock, dum, fx1 ;
  DISCFAC   *df ;
  CFLW_STR  *xcflw ;
  PP_STR    *pp ;
  DATESTR   *analys ;
  DFSPREAD  *dfs_tmp ;

  /* Get data from y */
  Cflw_GetSPREADINT((SPREADINT*)y, &price, &df, &xcflw, &pp, 
    &analys, &dfs_tmp, &shock) ;
  shock = ((shock <= 0.0) ? OAS_EPS : shock) ;

  /* Compute fx */
  dfs_tmp->spread = x ;
  *fx = Cflw_DF2Price(analys, df, xcflw, pp, NULL, dfs_tmp,
     NULL, &dum, &dum) - price ;

  /* Compute gradient */
  if (grad == True)
  {
    dfs_tmp->spread = x + shock ;
    fx1 = Cflw_DF2Price(analys, df, xcflw, pp, NULL, dfs_tmp,
     NULL, &dum, &dum) - price ;
    dfs_tmp->spread = x ;
    
    *dfx = (fx1 - *fx) / shock ;
  }

  return True ;
}

/*
..
*/

HOLI_STR bond_set_holi(HOLI_STR* holi, FIXRATE* fix)
{
    HOLI_STR hol ;

    hol = Set_HOLI_STR(NO_BUSADJUST, 0, NULL) ;

    if (fix->holpre == True)
        hol = Set_HOLI_STR(holi->bus, holi->nholi, holi->holidays) ;

    return hol ;
}


/*
  Compute REX bond yield implied from the term structure
*/

BOOLE Bond_DF2RexYield(DATESTR*  Lstart,
                            INTI      dur,
                            TERMUNIT  unit,
                            PMTFREQ   freq,
                            FL64      coupon,
                            CALCONV   cal,
                            DISCFAC*  df_cflw,
                            FL64*     ytm)
{
  TRADEINFO trade;
  DATESTR   matur;
  FIXPAY    fixp;
  HOLI_STR  holi;
  YTMCONV   ytmc;
  ITERCTRL  ictrl;
  BOOLE     ok;
  FL64      dp, ddp;

  dp = ddp = 0.0;

  holi  = Set_HOLI_STR(NO_BUSADJUST, 0, NULL);
  matur = Cldr_TermUnit2Date(Lstart, dur, unit, cal, SAME, &holi);

  trade = bond_set_tradeinfo(Lstart);
  fixp  = Bond_Simple2FIXPAY(Lstart, NULL, &matur, coupon, freq, BULLET,
                             NULL, NULL, cal, SAME);

  trade.price = Bond_DF2Price(Lstart, &trade, &fixp, df_cflw, &holi, NULL, 
                        NULL, &dp, &ddp);

  ytmc = BondBM_YTMSEG2YTMCONV(ISMA360ANN) ;
  Init_ITERCTRL(&ictrl);
  ok = Bond_YTM2Yield(&trade, &fixp, &ytmc, &holi, &ictrl, ytm) ;
  
  return ok;
}


/*,,SOH,,
*************************************************************************
*
*              Bond_RexIndexPrices()
*
*    interface #include <bond.h>
*              FL64ARRAY Bond_RexIndexPrices(FL64MATRIX quotes,   
*                                            INTI       sub_indx,
*                                            FL64       *indx_coup)
*
*    general   This function computes the weighted prices of the
*              one to ten year synthetic REX bonds using the
*              weights of a particular REX sub index.
*              Computes the coupon of the synthetic bond corresponding
*              to the chosen sub index.
*
*              This should be used when computing the bond prices of
*              the one to ten year REX bonds used to construct the
*              curve for a particular REX sub index, eg the REX-10.
*
*              The weights are fixed by the Deutsche Boerse, but
*              hasen't been changed since the introduction of the REX
*              indices in 1967.
*              The following weights are used in this function:
*
*                        6.0%   7.5%   9.0%   (Coupon)
*              Tenor
*              1Y        3.10   1.73   2.56
*              2Y        3.50   2.43   2.87
*              3Y        4.06   3.03   3.16
*              4Y        4.88   3.37   3.70
*              5Y        4.87   3.15   4.02
*              6Y        4.09   2.84   4.32
*              7Y        3.82   3.02   4.79
*              8Y        3.38   3.14   4.06
*              9Y        3.65   2.62   3.38
*              10Y       3.15   1.47   1.84
*              
*              With the weighted prices computed by this function and some 
*              additional long benchmark bonds, a REX sub index curve 
*              (eg the REX-10 curve) can be constructed using Fit_BSEC2DF().
*              This curve is then relevant for pricing REX floaters
*              using SwapFl_DF2NPV().
*              
*    input     FL64MATRIX quotes     Prices of the 30 synthetic REX
*                                    bonds with maturity in 1 to 10 years
*                                    and coupon 6%, 7.5%, or 9%
*                                    Row index follows increasing maturity
*                                    while column index follows increasing
*                                    coupon.
*                                    [10,3]
*
*              INTI       sub_indx   The sub index. 
*                                    Must be either of 1, 2, ..., 10.
*
*    output    FL64       *indx_coup The sub index coupon.
*
*    returns   An array of weighted index bond prices.
*              Allocated as
*
*                  Alloc_FL64ARRAY(10);
*
*    diagnostics
*
*    see also  SwapFl_DF2NPV()
*              SwapFl_DF2Spread()
*              Fit_BSEC2DF()
*
*    wrapper   AP
*
*************************************************************************
,,EOH,,*/
FL64ARRAY Bond_RexIndexPrices(FL64MATRIX  quotes,   
                              INTI        sub_indx,
                              FL64*       indx_coup)
{
  FL64MATRIX weights;
  FL64ARRAY  w_quotes;
  FL64       coupons[3], sum;
  INTI       i, j;

  w_quotes = Alloc_FL64ARRAY(10);
  *indx_coup = 0.0;

  if (1 > sub_indx || sub_indx > 10)
    return w_quotes;

  sub_indx--;

  weights = Alloc_FL64MATRIX(10, 3);

  weights[0][0] = 3.1;    weights[0][1] = 1.73;   weights[0][2] = 2.56;
  weights[1][0] = 3.5;    weights[1][1] = 2.43;   weights[1][2] = 2.87;
  weights[2][0] = 4.06;   weights[2][1] = 3.03;   weights[2][2] = 3.16;
  weights[3][0] = 4.88;   weights[3][1] = 3.37;   weights[3][2] = 3.7;
  weights[4][0] = 4.87;   weights[4][1] = 3.15;   weights[4][2] = 4.02;
  weights[5][0] = 4.09;   weights[5][1] = 2.84;   weights[5][2] = 4.32;
  weights[6][0] = 3.82;   weights[6][1] = 3.02;   weights[6][2] = 4.79;
  weights[7][0] = 3.38;   weights[7][1] = 3.14;   weights[7][2] = 4.06;
  weights[8][0] = 3.65;   weights[8][1] = 2.62;   weights[8][2] = 3.38;
  weights[9][0] = 3.15;   weights[9][1] = 1.47;   weights[9][2] = 1.84;
  coupons[0] = 6.0;       coupons[1] = 7.5;       coupons[2] = 9.0;

  *indx_coup = sum = 0.0;
  for (i = 0; i < 3; i++)
  {
    sum += weights[sub_indx][i];
    *indx_coup += weights[sub_indx][i] * coupons[i];
  }
  *indx_coup /= sum;

  for (j = 0; j < 10; j++)
  {
    for (i = 0; i < 3; i++)
      w_quotes[j] += quotes[j][i] * weights[sub_indx][i];
    w_quotes[j] /= sum;
  }

  Free_FL64MATRIX(weights);

  return w_quotes;
}


/*,,SOH,,
************************************************************************
*
*                Set_TAXINFO()
*
*   interface    #include <bond.h>
*                TAXINFO Set_TAXINFO(FL64  c,
*                                    FL64  cg,
*                                    FL64  bp,
*                                    BOOLE pro_rata) ;
*
*   general      This routine sets the members of the struct defined
*                in the function name. The pointer members are simply
*                assigned - without physical copying. The intention
*                of the Set_*() routines is that by using this
*                functionality, one avoids setting individual members
*                of structs in the application code.
*
*                When new members are inserted in structs the Set_*()
*                routine will be changed accordingly.
*
*                For details on the interpretation of the individual
*                struct members please check the struct definition.
*
*   input        FL64  c        See general section.
*
*                FL64  cg       See general section.
*
*                FL64  bp       See general section.
*
*                BOOLE pro_rata See general section.
*
*   output
*
*   returns      The filled out TAXINFO struct
*
*   diagnostics
*
*   see also     TAXINFO
*
************************************************************************
,,EOH,,*/

TAXINFO Set_TAXINFO(FL64 c, 
                       FL64 cg, 
                       FL64 bp,
                       BOOLE pro_rata)
{
    TAXINFO tax ;

    tax.tax_c  = c ;
    tax.tax_cg = cg ;
    tax.bp_tax = bp ;
    tax.pro_rata = pro_rata ;

    return tax ;
}


/*,,SOH,,
************************************************************************
*
*                Set_FIXPAY()
*
*   interface    #include <bond.h>
*                FIXPAY Set_FIXPAY(PAYDAYDEF* cday,
*                                  FIXRATE*   fix,
*                                  PAYDAYDEF* rday,
*                                  REPAYMNT*  repay,
*                                  ACCRUINT*  accru,
*                                  EXRULE*    exp,
*                                  TAXINFO*   tax) ;
*
*   general      This routine sets the members of the struct defined
*                in the function name. The pointer members are simply
*                assigned - without physical copying. The intention
*                of the Set_*() routines is that by using this
*                functionality, one avoids setting individual members
*                of structs in the application code.
*
*                When new members are inserted in structs the Set_*()
*                routine will be changed accordingly.
*
*                One exception to this principle applies. Whenever
*                OPTADD and vanilla members are used, only the
*                vanilla members are set in the Set_*() routines. The
*                non-vanilla and exotic members are set to defaults,
*                and must be set elsewhere - if needed.
*
*                For details on the interpretation of the individual
*                struct members please check the struct definition.
*
*   input        PAYDAYDEF* cday  See general section.
*
*                FIXRATE*   fix   See general section.
*
*                PAYDAYDEF* rday  See general section.
*                                 Use NULL for defaults
*
*                REPAYMNT*  repay See general section.
*                                 Use NULL for defaults
*
*                ACCRUINT*  accru See general section.
*                                 Use NULL for defaults
*
*                EXRULE*    exp   See general section.
*                                 Use NULL for defaults
*
*                TAXINFO*   tax   See general section.
*                                 Use NULL for defaults
*
*   output
*
*   returns      The filled out FIXPAY struct
*
*   diagnostics
*
*   see also     FIXPAY
*
************************************************************************
,,EOH,,*/

FIXPAY Set_FIXPAY(PAYDAYDEF* cday,
                       FIXRATE*     fix,
                       PAYDAYDEF*   rday,
                       REPAYMNT*    repay,
                       ACCRUINT*    accru,
                       EXRULE*      exp,
                       TAXINFO*     tax)
{
    FIXPAY fixp ;

    fixp.cday  = *cday ;
    fixp.fix   = *fix  ;

    if (rday != NULL)
        fixp.rday  = *rday ;
    else
        fixp.rday = *cday ;
    
    if (repay != NULL)
        fixp.repay = *repay ;
    else
        fixp.repay = Set_REPAYMNT(BULLET, NULL, False, 0.0, NULL, NULL, NULL,
                                  0.0, 0.0) ;

    if (accru != NULL)
        fixp.accru = *accru ;
    else
        fixp.accru = Set_ACCRUINT(fix->cal, fix->cbase, fix->cbodd, False, 
                                  False, SIMPLE_MM, 1, False, False, False, 
                                  NULL) ;

    if (exp != NULL)
        fixp.exp = *exp ;
    else
        fixp.exp = Set_EXRULE(EX_DAYS, 0, True, EU30E360, NULL,
                              0, NULL, NULL, True) ;

    if (tax != NULL)
        fixp.tax = *tax  ;
    else
        fixp.tax = Set_TAXINFO(0.0, 0.0, 0.0, False) ;

    return fixp ;
}


/*,,SOH,,
************************************************************************
*
*                Set_YTMCONV()
*
*   interface    #include <bond.h>
*                YTMCONV Set_YTMCONV(IRRCONV irr,
*                                    PMTFREQ qb_ytm,
*                                    BOOLE   dayfrac_first,
*                                    BOOLE   dayfrac_normal,
*                                    BOOLE   dayfrac_last,
*                                    CALCONV cal_first,
*                                    CALCONV cal_normal,
*                                    CALCONV cal_last,
*                                    BOOLE   trueYTM,
*                                    BOOLE   as_bullet) ;
*
*   general      This routine sets the members of the struct defined
*                in the function name. The pointer members are simply
*                assigned - without physical copying. The intention
*                of the Set_*() routines is that by using this
*                functionality, one avoids setting individual members
*                of structs in the application code.
*
*                When new members are inserted in structs the Set_*()
*                routine will be changed accordingly.
*
*                For details on the interpretation of the individual
*                struct members please check the struct definition.
*
*   input        IRRCONV irr            See general section.
*
*                PMTFREQ qb_ytm         See general section.
*
*                BOOLE   dayfrac_first  See general section.
*
*                BOOLE   dayfrac_normal See general section.
*
*                BOOLE   dayfrac_last   See general section.
*
*                CALCONV cal_first      See general section.
*
*                CALCONV cal_normal     See general section.
*
*                CALCONV cal_last       See general section.
*
*                BOOLE   trueYTM        See general section.
*
*                BOOLE   as_bullet        See general section.
*
*   output
*
*   returns      The filled out YTMCONV struct
*
*   diagnostics
*
*   see also     YTMCONV
*
************************************************************************
,,EOH,,*/

YTMCONV Set_YTMCONV(IRRCONV irr,
                       PMTFREQ qb_ytm,
                       BOOLE   dayfrac_first,
                       BOOLE   dayfrac_normal,
                       BOOLE   dayfrac_last,
                       CALCONV cal_first,
                       CALCONV cal_normal,
                       CALCONV cal_last,
                       BOOLE   trueYTM,
                       BOOLE   as_bullet)
{
    YTMCONV ytmc ;

    ytmc.irr            = irr ;
    ytmc.qb_ytm         = qb_ytm ;
    ytmc.dayfrac_first  = dayfrac_first ;
    ytmc.dayfrac_normal = dayfrac_normal ;
    ytmc.dayfrac_last   = dayfrac_last;
    ytmc.cal_first      = cal_first ;
    ytmc.cal_normal     = cal_normal ;
    ytmc.cal_last       = cal_last ;
    ytmc.trueYTM        = trueYTM ;
    ytmc.as_bullet        = as_bullet ;

    return ytmc ;
}


/*,,SOH,,
************************************************************************
*
*                Set_HZYCONV()
*
*   interface    #include <bond.h>
*                HZYCONV Set_HZYCONV(BOOLE   reinv,
*                                    BOOLE   hzp,
*                                    YTMCONV *ytmc) ;
*
*   general      This routine sets the members of the struct defined
*                in the function name. The pointer members are simply
*                assigned - without physical copying. The intention
*                of the Set_*() routines is that by using this
*                functionality, one avoids setting individual members
*                of structs in the application code.
*
*                When new members are inserted in structs the Set_*()
*                routine will be changed accordingly.
*
*                One exception to this principle applies. Whenever
*                OPTADD and vanilla members are used, only the
*                vanilla members are set in the Set_*() routines. The
*                non-vanilla and exotic members are set to defaults,
*                and must be set elsewhere - if needed.
*
*                For details on the interpretation of the individual
*                struct members please check the struct definition.
*
*   input        BOOLE   reinv          See general section.
*
*                BOOLE   hzp            See general section.
*
*                YTMCONV *ytmc          See general section.
*                                       Enter NULL for default
*
*   output
*
*   returns      The filled out HZYCONV struct
*
*   diagnostics
*
*   see also     HZYCONV
*
************************************************************************
,,EOH,,*/

HZYCONV Set_HZYCONV(BOOLE    reinv,
                       BOOLE    hzp,
                       YTMCONV* ytmc)
{
    HZYCONV hzyc ;

    hzyc.reinv = reinv ;
    hzyc.hzp   = hzp ;

    if (ytmc != NULL)
        hzyc.ytmc = *ytmc ;
    else
        hzyc.ytmc = Set_YTMCONV(COMPOUND, ANNUALLY, False, False, False,
                                EU30E360, EU30E360, EU30E360, False, False) ;
    return hzyc ;
}


#undef YTM_ACC
#undef YTM_MIN
#undef YTM_MAX
#undef YTM_MAXIT
#undef YTM_FREQ
#undef YTM_DAMP
#undef YTM_GUESS
#undef YTM_TOL

#undef OAS_MAXIT
#undef OAS_EPS
#undef OAS_TOL
#undef OAS_MIN
#undef OAS_MAX
#undef OAS_FREQ
#undef P_TOL

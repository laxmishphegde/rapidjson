#include <sccsid.h>
SCCSID(bondvl_c,
  "@(#)bondvl.c	1.10 (SimCorp) 99/09/14 18:14:01")


/************************************************************************
*
*   project     SCecon
*
*   file name   validate.c
*
*   general     This file contains routines for validating the
*               content of the data structures of SCecon
*
************************************************************************/

/*** includes **********************************************************/
#include <bondvl.h>

/*** defines ***********************************************************/
#define valid_tol 0.000001



/*,,SOH,,
***********************************************************************
*                                                                      
*               Validate_BONDSEG()                                     
*                                                                      
*   interface   #include <bondvl.h>                                  
*               BOOLE     Validate_BONDSEG(BONDSEG r)                 
*                                                                      
*   general     This function validates the content of the BONDSEG     
*               data structure                                         
*                                                                      
*   input       BONDSEG  r  The BONDSEG data structure                
*                                                                      
*   output                                                             
*                                                                      
*   returns     True if r is a valid BONDSEG, False if invalid         
*                                                                      
*   diagnostics                                                        
*                                                                      
*   see also    BONDSEG                                                
*                                                                      
***********************************************************************
,,EOH,,*/


BOOLE Validate_BONDSEG(BONDSEG r)
{
    /* check that r is valid */
    switch (r)
    {
    case USDGOV:
    case GBPGOV:
    case OLDGBPGOV:
    case DEMGOV:
    case NLGGOV:
    case BEFGOV:
    case ITLGOV:
    case OLDITLGOV:
    case ESPGOV:
    case JPYGOV:
    case FRFGOV:
    case DKKGOV:
    case SEKGOV:
    case NOKGOV:
    case FIMGOV:
    case OLDFIMGOV:
    case CADGOV:
    case NZDGOV:
    case AUDGOV:
    case ATSGOV:
    case CHFGOV:
    case IEPGOV:
        return True ;
    default :
        return False ;
    }
}

/*,,SOH,,
*************************************************************************
*
*               Validate_FIXDCOMP()
*
*   interface   #include <bondvl.h>
*               BOOLE     Validate_FIXDCOMP(FIXDCOMP r) ;
*
*   general     This function validates the content of the enum
*               data structure
*
*   input       FIXDCOMP  r  The FIXDCOMP data structure
*
*   output
*
*   returns     True if r is a valid FIXDCOMP, False if invalid
*
*   diagnostics
*
*   see also    FIXDCOMP
*
*************************************************************************
,,EOH,,*/

BOOLE Validate_FIXDCOMP(FIXDCOMP r)
{
    /* check that r is valid */
    switch (r)
    {
        case NODCOMP :
        case EPR_PER :
        case EPR_DF :
        case EDDR :
            return True ;
        default :
            return False ;
    }
}


/*,,SOH,,
***********************************************************************
*                                                                      
*               Validate_INDEXFAC()                                    
*                                                                      
*   interface   #include <bondvl.h>                                  
*               VALIDATE Validate_INDEXFAC(INDEXFAC *x)                
*                                                                      
*   general     This function validates the content of the INDEXFAC    
*               data structure                                         
*                                                                      
*   input       INDEXFAC   *x  The INDEXFAC data structure             
*                                                                      
*   output                                                             
*                                                                      
*   returns     Valid_data if the content of vol is valid              
*                                                                      
*   diagnostics                                                        
*                                                                      
*   see also    INDEXFAC                                               
*                                                                      
***********************************************************************
,,EOH,,*/


VALIDATE Validate_INDEXFAC(INDEXFAC* x)
{
    VALIDATE  v ;

    v = Validate_PLAN_STR(x->idxfac);
    if (v != Valid_data)
        return v ;

    if (!Validate_CALCONV(x->cal))
        return Invalid_cal ;

    return Valid_data ;
}



/*,,SOH,,
*************************************************************************
*
*               Validate_PP_STR()
*
*   interface   #include <bondvl.h>
*               VALIDATE Validate_PP_STR(PP_STR *p)
*
*   general     This function validates the content of the PP_STR
*               data structure
*
*   input       PP_STR   *p       The PP_STR data structure
*
*   output
*
*   returns     Valid_data if the content of p is valid
*               Invalid_pp_price if pp_price < 0
*               If the content of ppmts is invalid an error message
*                    from Validate_PLAN_STR() is returned
*               If the content of ppmts is invalid an error message
*                    from Validate_PLAN_STR_SUM100() is returned
*
*   diagnostics
*
*   see also
*
*************************************************************************
,,EOH,,*/



VALIDATE Validate_PP_STR(PP_STR* p)
{
    VALIDATE  v ;

    /* check that pp_price >= 0 */
    if (p->pp_price < -valid_tol)
        return Invalid_pp_price ;

    /* check that ppmts is a valid PLAN_STR */
    v = Validate_PLAN_STR(p->ppmts);
    if (v != Valid_data)
        return v ;
    else
    {
        v = Validate_PLAN_STR_SUM100(p->ppmts) ;
        if (v != Valid_data)
            return v ;
    }

    return Valid_data ;
}


/*,,SOH,,
*************************************************************************
*
*               Validate_CFLW_STR()
*
*   interface   #include <bondvl.h>
*               VALIDATE Validate_CFLW_STR(CFLW_STR *cflw)
*
*   general     This function validates the content of the CFLW_STR
*               data structure
*
*   input       CFLW_STR   *cflw      The CFLW_STR data structure
*
*   output
*
*   returns     Valid_data if the content of cflw is valid or if cflw
*                   is NULL
*               Invalid_filled if filled < 0
*               Invalid_date if any of the dates in days are invalid
*
*   diagnostics
*
*   see also    CFLW_STR
*
*************************************************************************
,,EOH,,*/


VALIDATE Validate_CFLW_STR(CFLW_STR* cflw)
{
    INTI    i ;

    if (cflw == NULL)
        return Invalid_filled ;

    if (cflw->filled < 0)
        return Invalid_filled ;

    for (i = 0 ; i < cflw->filled ; i++)
    {
        if (!Cldr_CheckDate(&cflw->days[i]))
            return Invalid_date ;
    }

    return Valid_data ;
}


/*,,SOH,,
*************************************************************************
*
*               Validate_DEPOSIT()
*
*   interface   #include <bondvl.h>
*               VALIDATE Validate_DEPOSIT(DEPOSIT *d)
*
*   general     This function validates the content of the DEPOSIT
*               data structure
*
*   input       DEPOSIT        *d       The DEPOSIT data structure
*
*   output
*
*   returns     Valid_data if the content of d is valid
*               Invalid_date if either effective or maturity is an
*                    invalid date
*               Invalid_coupon if coupon is less than 0
*               Invalid_cal if cal is an invalid calendar convention
*
*   diagnostics
*
*   see also    DEPOSIT
*
*************************************************************************
,,EOH,,*/


VALIDATE Validate_DEPOSIT(DEPOSIT* d)
{
    BOOLE ok = False ;

    ok = Cldr_CheckDate(&d->effective) ;
    ok = ok && Cldr_CheckDate(&d->maturity) ;
    if (ok == False)
        return Invalid_date ;

    if (!Validate_PMTFREQ(d->freq))
        return Invalid_freq ;

    if (d->coupon < -valid_tol)
        return Invalid_coupon ;

    if (!Validate_CALCONV(d->cal))
        return Invalid_cal ;

    if (!Validate_EOMCONV(d->eom))
        return Invalid_eomconv ;

    return Valid_data ;
}


/*,,SOH,,
***********************************************************************
*                                                                      
*               Validate_FIXPAY()                                      
*                                                                      
*   interface   #include <bondvl.h>                                  
*               VALIDATE Validate_FIXPAY(FIXPAY *fixpay,
*                                        BOOLE  sum100)                
*                                                                      
*   general     This function validates the content of the FIXPAY      
*               data structure                                         
*                                                                      
*   input       FIXPAY  *fixpay   The FIXPAY data structure            
*                                                                      
*               BOOLE   sum100    If True, amortisations must sum to 
*                                 100.0
*                                                                      
*   output                                                             
*                                                                      
*   returns     Valid_data if the content of fixpay is valid,          
*               If the content of any of the data structures PAYDAYDEF,
*                   FIXRATE, REPAYMNT, ACCRUINT, EXRULE, or TAXINFO   
*                   is invalid an error message from one of the        
*                   corresponding validation routines is returned      
*               Last_date_in_pday_later_than_cday_last if last date in 
*                   pday in accru.exr is later than last in cday       
*                                                                      
*               Last_date_in_pday_later_than_cday_last if last date in 
*                   pday in exp is later than last in cday             
*                                                                      
*                                                                      
*   diagnostics                                                        
*                                                                      
*   see also    FIXPAY, FIXRATE, REPAYMNT, ACCRUINT, EXRULE, and      
*               TAXINFO                                                
*                                                                      
*   wrapper     AP
*                                                                      
***********************************************************************
,,EOH,,*/


VALIDATE Validate_FIXPAY(FIXPAY* fixpay, BOOLE  sum100)
{
    VALIDATE v ;
    BOOLE    is_bull ;

    is_bull = ((fixpay->repay.type == BULLET ||
                fabs(fixpay->fix.fix_rate) < valid_tol) ? True : False) ;

    /* check that cday is a valid PAYDAYDEF data structure */
    v = Validate_PAYDAYDEF(&fixpay->cday, is_bull) ;
    if (v != Valid_data)
        return v ;

    /* check that fix is a valid FIXRATE data structure */
    v = Validate_FIXRATE(&fixpay->fix) ;
    if (v != Valid_data)
        return v ;

    /* check that rday is a valid PAYDAYDEF data structure */
    if (fixpay->repay.type != NONREGULAR)
    {
        v = Validate_PAYDAYDEF(&fixpay->rday, True) ;
        if (v != Valid_data)
            return v ;
    }

    /* check that repay is a valid REPAYMNT data structure */
    v = Validate_REPAYMNT(&fixpay->repay, &fixpay->cday.last, True,
      sum100) ;
    if (v != Valid_data)
        return v ;

    /* check that accru is a valid ACCRUINT data structure */
    v = Validate_ACCRUINT(&fixpay->accru) ;
    if (v != Valid_data)
        return v ;

    /* check that the last date in pday in accru.exr is earlier than or equal to
       last in cday    */
    if (fixpay->accru.exr.xconv == EX_DATEARRAY &&
          fixpay->accru.exr.npday > 0
          && Cldr_DateLE(&fixpay->accru.exr.pday[fixpay->accru.exr.npday -1],
                &fixpay->cday.last) == False)
        return Last_date_in_pday_later_than_cday_last ;

    /* check that exp is a valid EXRULE data structure */
    v = Validate_EXRULE(&fixpay->exp) ;
    if (v != Valid_data)
        return v ;

    /* check that the last date in pday in exp is earlier than or equal to
       last in cday    */
    if (fixpay->exp.xconv == EX_DATEARRAY && fixpay->exp.npday > 0 &&
            Cldr_DateLE(&fixpay->exp.pday[fixpay->exp.npday -1],
              &fixpay->cday.last) == False)
        return Last_date_in_pday_later_than_cday_last ;

    /* check that tax is a valid TAXINFO data structure */
    v = Validate_TAXINFO(&fixpay->tax) ;
    if (v != Valid_data)
        return v ;

    return Valid_data ;
}


/*,,SOH,,
*************************************************************************
*
*               Validate_ACCRUINT()
*
*   interface   #include <bondvl.h>
*               VALIDATE Validate_ACCRUINT(ACCRUINT  *accru_str)
*
*   general     This function validates the content of the ACCRUINT
*               data structure
*
*   input       ACCRUINT  *accru_str  The ACCRUINT data structure
*
*   output
*
*   returns     Valid_data if the content of accr_str is valid,
*               Invalid_cal if cal is an invalid CALCONV,
*               Invalid_cb_accru if cb_accru is an invalid COUPONBASE,
*               Invalid_cbodd_accru if cbodd_accru is an invalid
*                   COUPONBASE,
*               Invalid_incl if incl is not True or False,
*               Invalid_pre if pre is not True or False,
*               Invalid_irr if irr is not SIMPLE_MM or COMPOUND,
*               Invalid_qbas if irr is COMPOUND and qbas is different
*                   from 1,2,3,4,6,12,
*               Invalid_schuldsch if schuldsch is not True or False,
*               Invalid_CGB184 if CGB184 is not True or False,
*               Invalid_BRDfeb if BRDfeb is not True or False,
*               If the content of exr is invalid an error message
*                   from Validate_EXRULE() is returned
*
*   diagnostics
*
*   see also    ACCRUINT
*
*************************************************************************
,,EOH,,*/


VALIDATE Validate_ACCRUINT(ACCRUINT* accru_str)
{
    VALIDATE v;

    /* check that cal is a valid CALCONV */
    if (Validate_CALCONV(accru_str->cal) == False)
        return Invalid_cal ;

    /* check that cb_accru is a valid COUPONBASE */
    if (Validate_COUPONBASE(accru_str->cb_accru) == False)
        return Invalid_cb_accru ;

    /* check that cbodd_accru is a valid COUPONBASE */
    if (Validate_COUPONBASE(accru_str->cbodd_accru) == False)
        return Invalid_cbodd_accru ;

    /* check that incl is True or False */
    if (accru_str->incl != True && accru_str->incl != False)
        return Invalid_incl ;

    /* check that pre is True or False */
    if (accru_str->pre != True && accru_str->pre != False)
        return Invalid_pre ;

    /* check that irr is SIMPLE_MM or COMPOUND */
    if (accru_str->irr != SIMPLE_MM && accru_str->irr != COMPOUND)
        return Invalid_irr ;

    /* check that qbas is 1,2,3,4,6,12 */
    if (accru_str->irr == COMPOUND && (accru_str->qbas == 0 || 12 %
      accru_str->qbas != 0))
        return Invalid_qbas ;

    /* check that schuldsch is True or False */
    if (accru_str->schuldsch != True && accru_str->schuldsch != False)
        return Invalid_schuldsch ;

    /* check that CGB184 is True or False */
    if (accru_str->CGB184 != True && accru_str->CGB184 != False)
        return Invalid_CGB184 ;

    /* check that BRDfeb is True or False */
    if (accru_str->BRDfeb != True && accru_str->BRDfeb != False)
        return Invalid_BRDfeb ;

    /* check that exr is a valid EXRULE */
    v = Validate_EXRULE(&accru_str->exr) ;
    if (v != Valid_data)
        return v ;

     return Valid_data ;
}


/*,,SOH,,
*************************************************************************
*
*               Validate_COUPONBASE()
*
*   interface   #include <bondvl.h>
*               BOOLE Validate_COUPONBASE(COUPONBASE couponbase)
*
*   general     This function validates the content of the COUPONBASE
*               data structure
*
*   input       COUPONBASE couponbase  The COUPONBASE data structure
*
*   output
*
*   returns     True if couponbase is a valid COUPONBASE,
*               False if invalid
*
*   diagnostics
*
*   see also    COUPONBASE
*
*************************************************************************
,,EOH,,*/


BOOLE Validate_COUPONBASE(COUPONBASE couponbase)
{
    /* check that couponbase is valid */
    switch (couponbase)
    {
        case ODDCOUP :
        case EVENCOUP :
        case EQUALCOUP :
        case EVENODD :
            return True ;
        default :
            return False ;
    }
}


/*,,SOH,,
*************************************************************************
*
*               Validate_RATECONV()
*
*   interface   #include <bondvl.h>
*               BOOLE Validate_RATECONV(RATECONV type) ;
*
*   general     This function validates the content of the RATECONV
*               data structure
*
*   input       RATECONV  type    The RATECONV data structure
*
*   output
*
*   returns     True if type is a valid RATECONV, False if invalid
*
*   diagnostics
*
*   see also    RATECONV
*
*************************************************************************
,,EOH,,*/


BOOLE Validate_RATECONV(RATECONV type)
{
    /* check that type is valid */
    switch (type)
    {
        case MMRATE :
        case BILLDISC:
        case BILLYIELD:
        case PARYIELD:
        case REX:
            return True ;
        default :
            return False ;
    }
}


/*,,SOH,,
*************************************************************************
*
*               Validate_EXDAYCONV()
*
*   interface   #include <bondvl.h>
*               BOOLE Validate_EXDAYCONV(EXDAYCONV exdayconv)
*
*   general     This function validates the content of the EXDAYCONV
*               data structure
*
*   input       EXDAYCONV    exdayconv    The EXDAYCONV data structure
*
*   output
*
*   returns     True if exdayconv is a valid EXDAYCONV,
*               False if invalid
*
*   diagnostics
*
*   see also    EXDAYCONV
*
*************************************************************************
,,EOH,,*/


BOOLE Validate_EXDAYCONV(EXDAYCONV exdayconv)
{
    /* check that exdayconv is valid */
    switch (exdayconv)
    {
        case EX_DAYS :
        case EX_DATE :
        case EX_DATEARRAY :
        case EX_FIX :
        case EX_AUT :
        case EX_OLDBRD :
        case EX_UKGILT :
        case EX_IRLGILT :
            return True ;
        default :
            return False ;
    }
}


/*,,SOH,,
*************************************************************************
*
*               Validate_EXRULE()
*
*   interface   #include <bondvl.h>
*               VALIDATE Validate_EXRULE(EXRULE *exrule)
*
*   general     This function validates the content of the EXRULE
*               data structure
*
*   input       EXRULE   *exrule  The EXRULE data structure
*
*   output
*
*   returns     Valid_data if the content of exrule is valid,
*               Invalid_xconv if xconv is an invalid EXDAYCONV,
*               Invalid_exdays if exdays is < 0,
*               Invalid_caldays if caldays is not True or False,
*               Invalid_cal if cal is an invalid CALCONV,
*               Invalid_dex if dex is an invalid date,
*               Invalid_npday if npday is < 0,
*               Invalid_pday if pday is an invalid DATEARRAY,
*               Invalid_xpday if xpday is an invalid DATEARRAY,
*               Xpday_after_pday if a date in xpday is later than the
*                   corresponding date in pday
*
*   diagnostics
*
*   see also    EXRULE
*
*************************************************************************
,,EOH,,*/


VALIDATE Validate_EXRULE(EXRULE* exrule)
{
    INTI i;

    /* check that xconv is valid */
    if (Validate_EXDAYCONV(exrule->xconv) == False)
        return Invalid_xconv ;

    /* check that the number of exdays is greater than or equal to 0 if xconv
      is EX_DAYS */
    if (exrule->xconv == EX_DAYS && exrule->exdays < 0)
        return Invalid_exdays ;

    /* check that caldays is True or False if xconv is EX_DAYS */
    if (exrule->xconv == EX_DAYS && exrule->caldays != True && exrule->caldays
      != False)
        return Invalid_caldays ;

    /* check that cal is valid if xconv is EX_DAYS and caldays is True */
    if (exrule->xconv == EX_DAYS && exrule->caldays == True &&
      Validate_CALCONV(exrule->cal) == False)
        return Invalid_cal ;

    /* check that dex is a valid date if xconv is EX_DATE */
     if (exrule->xconv == EX_DATE && Cldr_CheckDate(&exrule->dex) == False)
         return Invalid_dex ;

     /* check that number of npday is greater than or equal to 0 if xconv is
       EX_DATEARRAY */
    if (exrule->xconv == EX_DATEARRAY && exrule->npday < 0)
        return Invalid_npday ;

    /* check that pday is a valid datearray if xconv is EX_DATEARARY */
    if (exrule->xconv == EX_DATEARRAY && exrule->npday > 0
            && Validate_DATEARRAY(exrule->pday, exrule->npday) != Valid_data)
        return Invalid_pday ;

    /* check that xpday is a valid datearray if xconv is EX_DATEARARY */
    if (exrule->xconv == EX_DATEARRAY && exrule->npday > 0
            && Validate_DATEARRAY(exrule->xpday, exrule->npday) != Valid_data)
        return Invalid_xpday ;

    /* check that the dates in xpday are earlier than or equal to the
      corresponding dates in pday */
    if (exrule->xconv == EX_DATEARRAY)
    {
        for (i=0; i <= exrule->npday -1; i++)
            if (Cldr_DateLE(&exrule->xpday[i], &exrule->pday[i]) == False)
                return Xpday_after_pday ;
    }

    /* check that caldays is True or False if xconv is EX_DAYS */
    if (exrule->xlast != True && exrule->xlast != False)
        return Invalid_boole ;

    return Valid_data ;
}


/*,,SOH,,
*************************************************************************
*
*               Validate_FIXRATE()
*
*   interface   #include <bondvl.h>
*               VALIDATE Validate_FIXRATE(FIXRATE *fixrate) ;
*
*   general     This function validates the content of the FIXRATE
*               data structure
*
*   input       FIXRATE *fixrate    The FIXRATE data structure
*
*   output
*
*   returns     Valid_data if the content of fixrate is valid,
*               Invalid_cal if cal is an invalid CALCONV,
*               Invalid_lastaccr if lastaccr is an invalid date,
*               Lastaccr_after_effective if lastaccr is a valid date
*                   and lastaccr is later than effective,
*               Invalid_accrfac if accrfac is < 0 or > 1,
*               Invalid_cbase if cbase is an invalid COUPONBASE,
*               Invalid_cbodd if cbodd is an invalid COUPONBASE,
*               Invalid_prepaid if prepaid is not True or False,
*               Invalid_accrfac_prepaid if prepaid is not True when
*                   accrfac > 0
*               Invalid_jgb if jgb is not True or False,
*               Invalid_holpre if holpre is not True or False
*               Invalid_filled if filled is < 0,
*               If stepcoup->day is an invalid DATEARRAY an
*                   error message from Validate_DATEARRAY()is returned
*               If irreg->day is an invalid DATEARRAY an
*                   error message from Validate_DATEARRAY()is returned
*
*   diagnostics
*
*   see also    FIXRATE
*
*************************************************************************
,,EOH,,*/


VALIDATE Validate_FIXRATE(FIXRATE* fixrate)
{
    VALIDATE tmp ;

    /* check that cal is valid CALCONV */
    if (Validate_CALCONV(fixrate->cal) == False)
        return Invalid_cal ;

    /* check that lastaccr is a valid date */
    if (Cldr_CheckDate(&fixrate->lastaccr) == False &&
            Cldr_IsNullDate(&fixrate->lastaccr) == False)
        return Invalid_lastaccr ;

    /* check that effective is earlier than or equal to lastaccr if lastaccr is
      a valid date */
    if (Cldr_CheckDate(&fixrate->lastaccr) == True
            && Cldr_DateLE(&fixrate->effective, &fixrate->lastaccr) == False)
        return Effective_after_lastaccr ;

    /* check that accrfac lies between 0.0 and 1.0 */
    if (fixrate->accrfac < -valid_tol || fixrate->accrfac > 1.0 + valid_tol)
        return Invalid_accrfac ;

    /* check that cbase is a valid COUPONBASE */
    if (Validate_COUPONBASE(fixrate->cbase) == False)
        return Invalid_cbase ;

    /* check that cbodd is a valid COUPONBASE */
    if (Validate_COUPONBASE(fixrate->cbodd) == False)
        return Invalid_cbodd ;

    /* check that prepaid is True or False */
    if (fixrate->prepaid != True && fixrate->prepaid != False)
        return Invalid_prepaid ;

    /* check that decompound is OK */
    if (Validate_FIXDCOMP(fixrate->decomp) == False)
        return Invalid_decomp ;

    /* check prepaid is False if accrfac > 0.0 */
    if (fixrate->accrfac > valid_tol && fixrate->prepaid != False)
        return Invalid_accrfac_prepaid ;

    /* check that jgb is True or False */
    if (fixrate->jgb != True && fixrate->jgb != False)
        return Invalid_jgb ;

    /* check that holpre is True or False */
    if (fixrate->holpre != True && fixrate->holpre != False)
        return Invalid_holpre ;

    if (fixrate->stepcoup != NULL)
    {
        /* check that filled >= 0 */
        if (GetPlanFill(fixrate->stepcoup) < 0)
            return Invalid_filled ;

        if (GetPlanFill(fixrate->stepcoup) > 0)
        {
            /* check that day is a valid datearray */
            tmp = Validate_DATEARRAY(fixrate->stepcoup->day,
              GetPlanFill(fixrate->stepcoup)) ;
            if (tmp != Valid_data)
                return tmp ;
        }
    }

    if (fixrate->irreg != NULL)
    {
        /* check that filled >= 0 */
        if (GetPlanFill(fixrate->irreg) < 0)
            return Invalid_filled ;

        if (GetPlanFill(fixrate->irreg) > 0)
        {
            /* check that irreg->day is a valid datearray */
            tmp = Validate_DATEARRAY(fixrate->irreg->day,
              GetPlanFill(fixrate->irreg)) ;
            if (tmp != Valid_data)
                return tmp ;
        }
    }

    return Valid_data;
}


/*,,SOH,,
*************************************************************************
*
*               Validate_ODDCONV()
*
*   interface   #include <bondvl.h>
*               BOOLE     Validate_ODDCONV(ODDCONV oddconv)
*
*   general     This function validates the content of the ODDCONV
*               data structure
*
*   input       ODDCONV  oddconv  The ODDCONV data structure
*
*   output
*
*   returns     True if oddconv is a valid ODDCONV, False if invalid
*
*   diagnostics
*
*   see also    ODDCONV
*
*************************************************************************
,,EOH,,*/


BOOLE Validate_ODDCONV(ODDCONV oddconv)
{
    /* check that oddconv is valid */
    switch (oddconv)
    {
        case NOODD :
        case SHORTODD :
        case LONGODD:
              return True ;
        default :
            return False ;
    }
}


/*,,SOH,,
*************************************************************************
*
*               Validate_PAYDAYDEF()
*
*   interface   #include <bondvl.h>
*               VALIDATE Validate_PAYDAYDEF(PAYDAYDEF *paydaydef,
*                                           BOOLE     is_bull) ;
*
*   general     This function validates the content of the PAYDAYDEF
*               data structure
*
*   input       PAYDAYDEF   *paydaydef   The PAYDAYDEF data structure
*               BOOLE       is_bull      IF is_bull is False
*                                        paydaydef->first must be filled*
*                                        Otherwise paydaydef->first is
*                                        not used
*   output
*
*   returns     Valid_data if the content of paydaydef is valid,
*               Invalid_first if is_bull is False and first is an
*                   invalid date,
*               Invalid_last if last is an invalid date,
*               First_after_last if is_bull is False and first is later
*                   than last,
*               If paydayseq is an invalid PAYDAYSEQ data structure an
*                   error code from PAYDAYSEQ is returned,
*                   see PAYDAYSEQ
*               Invalid_seclast if seclast is an invalid date,
*               Invalid_snap2 if snap2 is not True or False,
*               Invalid_nirreg if nirreg is < 0,
*               Invalid_datearray if datearray is invalid,
*               First_after_first_irreg_day if first is later than the
*                   first date in irreg_day,
*               Last_after_last_irreg_day if the last date in irreg_day
*                   is later than last
*
*   diagnostics
*
*   see also    PAYDAYDEF
*
*************************************************************************
,,EOH,,*/


VALIDATE Validate_PAYDAYDEF(PAYDAYDEF* paydaydef, BOOLE is_bull)
{
    VALIDATE v, tmp ;

    /* check that last is a valid date -- last must always be entered */
    if (Cldr_CheckDate(&paydaydef->last) == False)
        return Invalid_last ;

    if (paydaydef->nirreg == 0)
    {
        /* check that first is a valid date */
        if (is_bull == False && Cldr_CheckDate(&paydaydef->first) == False)
            return Invalid_first ;

        /* check that first is earlier than or equal to last*/
        if (is_bull == False && Cldr_DateLT(&paydaydef->last,
          &paydaydef->first) == True)
            return First_after_last ;

        /* check that pseq is a valid PAYDAYSEQ */
        v = Validate_PAYDAYSEQ(&paydaydef->pseq) ;
        if (v != Valid_data)
            return v ;

        /* check that seclast is a valid date */
        if (paydaydef->pseq.oddn == LONGODD) 
        {
            if (Cldr_CheckDate(&paydaydef->seclast) == False) 
            {
                if (Cldr_Datestr2YMD(&paydaydef->seclast) != (YYYYMMDD) 0)
                    return Invalid_seclast ;
            }
            else 
            {
                if (Cldr_DateEQ(&paydaydef->first, &paydaydef->last) == True) 
                {
                    if (Cldr_DateEQ(&paydaydef->first, &paydaydef->seclast) ==
                      False)
                        return Invalid_seclast ;
                }
                else
                {
                    if (Cldr_DateLE(&paydaydef->first, &paydaydef->seclast) ==
                      False ||
                            Cldr_DateLT(&paydaydef->seclast , &paydaydef->last)
                              == False)
                        return Invalid_seclast ;
                }
            }
        }

        /* check that snap is True or False when pseq.seg is IMM, CAD_BA or
          LASTBUS */
        if ((paydaydef->pseq.seq == IMM || 
             paydaydef->pseq.seq == CAD_BA ||
             paydaydef->pseq.seq == LASTBUS || 
             paydaydef->pseq.seq == IMM_ZAR ||
             paydaydef->pseq.seq == TAM_T4M) &&
             paydaydef->snap2 != True && paydaydef->snap2 != False)
            return Invalid_snap2 ;
    }

    /* check that nirreg >= 0 */
    if (paydaydef->nirreg < 0)
        return Invalid_nirreg ;

    /* check that irreg_days is valid datearray */
    tmp = Validate_DATEARRAY(paydaydef->irreg_days, paydaydef->nirreg) ;
    if (paydaydef->nirreg > 0 &&  tmp != Valid_data)
        return tmp ;

    return Valid_data ;
}


/*,,SOH,,
*************************************************************************
*
*               Validate_PAYDAYSEQ()
*
*   interface   #include <bondvl.h>
*               VALIDATE Validate_PAYDAYSEQ(PAYDAYSEQ *paydayseq)
*
*   general     This function validates the content of the PAYDAYSEQ
*               data structure
*
*   input       PAYDAYSEQ  *paydayseq    The PAYDAYSEQ data structure
*
*   output
*
*   returns     Valid_data if the content of paydayseq is valid,
*               Invalid_oddconv if oddconv is an invalid ODDCONV,
*               Invalid_seqconv if seqconv is an invalid SEQCONV,
*               Invalid_term if term is < 0,
*               Invalid_termunit if termunit is an invalid TERMUNIT,
*               Invalid_eomconv if eomconv is an invalid EOMCONV
*
*   diagnostics
*
*   see also    PAYDAYSEQ
*
*************************************************************************
,,EOH,,*/


VALIDATE Validate_PAYDAYSEQ(PAYDAYSEQ* paydayseq)
{
    /* check that odd1 is a valid ODDCONV */
    if (Validate_ODDCONV(paydayseq->odd1) == False)
        return Invalid_oddconv ;

    /* check that oddn is a valid ODDCONV */
    if (Validate_ODDCONV(paydayseq->oddn) == False)
        return Invalid_oddconv ;

    /* check that seq is a valid SEQCONV */
    if (Validate_SEQCONV(paydayseq->seq) == False)
        return Invalid_seqconv ;

    /* check that term >= 0 */
    if (paydayseq->term < 0)
        return Invalid_term ;

    /* check that unit is a valid TERMUNIT */
    if (Validate_TERMUNIT(paydayseq->unit) == False)
        return Invalid_termunit ;

    /* check that eom is a valid EOMCONV */
    if (Validate_EOMCONV(paydayseq->eom) == False)
        return Invalid_eomconv ;

    return Valid_data ;
}


/*,,SOH,,
**********************************************************************
*                                                                     
*               Validate_REPAYMNT()                                   
*                                                                     
*   interface   #include <bondvl.h>                                 
*               VALIDATE Validate_REPAYMNT(REPAYMNT *repay_str,       
*                                          DATESTR  *last,            
*                                          BOOLE    val_dates,
*                                          BOOLE    sum100) ;      
*                                                                     
*   general     This function validates the content of the REPAYMNT   
*               data structure                                        
*                                                                     
*   input       REPAYMNT    *repay_str  The REPAYMNT data structure   
*               DATESTR     *last       The last coupon day. Primarily
*                                       used in cross checking data in
*                                       FIXPAY data structure         
*               BOOLE       val_dates   If val_dates is True last is  
*                                       used in cross checking. If    
*                                       val_dates is False last is not
*                                       used                          
*               BOOLE       sum100      If sum100 is True amortisations
*                                       must sum to 100.0 
*                                                                     
*   output                                                            
*                                                                     
*   returns     Valid_data if the content of repay_str is valid,      
*               Invalid_bondtype if bondtype is an invalid BONDTYPE,  
*               Invalid_teomatur if teomatur is an invalid date,      
*               Invalid_io if io is not True or False,                
*               Invalid_pp_price if pp_price is < 0,                  
*               If pp.ppmts, irreg, or aufab is an invalid PLAN_STR   
*                 data structure an error message from              
*                 Validate_PLAN_STR() is returned                   
*               Invalid_irreg if filled in repay_str.irreg is less 
*                 than 0.
*               Last_date_in_day_later_than_cday_last if the last date
*                 in pp.ppmts.day in repay is earlier than or equal to
*                 last in cday                                        
*               repay_str->irreg->f64 must sum to 100.0 is sum100 is 
*                 True.
*                                                                     
*   diagnostics                                                       
*                                                                     
*   see also    REPAYMNT                                              
*                                                                     
**********************************************************************
,,EOH,,*/


VALIDATE Validate_REPAYMNT(REPAYMNT* repay_str, DATESTR* last, 
                              BOOLE val_dates, BOOLE  sum100)
{
    VALIDATE v ;

    /* check that type is a valid BONDTYPE */
    if (Validate_BONDTYPE(repay_str->type) == False)
        return Invalid_bondtype ;

    /* check that teomatur is a valid date */
    if (Cldr_CheckDate(&repay_str->teomatur) == False &&
        repay_str->type != NONREGULAR &&
        Cldr_IsNullDate(&repay_str->teomatur) == False)
        return Invalid_teomatur ;

    /* check that io is True or False */
    if (repay_str->io != True && repay_str->io != False)
        return Invalid_io ;

    /* check that pp is a valid PP_STR */
    v = Validate_PP_STR(&repay_str->pp);
    if (v != Valid_data)
        return v ;

    /* */
    if (repay_str->type == NONREGULAR && GetPlanFill(repay_str->irreg) < 0)
        return Invalid_irreg;

    /* check that irreg is a valid PLAN_STR */
    if (repay_str->type == NONREGULAR)
    {
        v = Validate_PLAN_STR(repay_str->irreg);
        if (v != Valid_data)
            return v ;
        else if (sum100 == True)
        {
            v = Validate_PLAN_STR_SUM100(repay_str->irreg) ;
            if (v != Valid_data)
                return v ;
        }
    }

    /* check that aufab is a valid PLAN_STR */
    v = Validate_PLAN_STR(repay_str->aufab);
    if (v != Valid_data)
        return v ;

    /* check that the last date in pp.ppmts.day in repay is earlier than or
       equal to last in cday */
       if (val_dates == True && GetPlanFill(repay_str->pp.ppmts) > 0 &&

         Cldr_DateLE(&repay_str->pp.ppmts->day[repay_str->pp.ppmts->filled -1],
                     last) == False
       )
           return Last_date_in_day_later_than_cday_last ;

    return Valid_data ;
}


/*,,SOH,,
*************************************************************************
*
*               Validate_TAXINFO()
*
*   interface   #include <bondvl.h>
*               VALIDATE Validate_TAXINFO(TAXINFO *taxinfo)
*
*   general     This function validates the content of the TAXINFO
*               data structure
*
*   input       TAXINFO *taxinfo  The TAXINFO data structure
*
*   output
*
*   returns     Valid_data if the content of TAXINFO is valid,
*               Invalid_tax_c if tax_c is < 0 or > 100,
*               Invalid_tax_cg if tax_cg is < 0 or > 100,
*               Invalid_bp_tax if bp_tax is < 0
*
*   diagnostics
*
*   see also    TAXINFO
*
*************************************************************************
,,EOH,,*/

VALIDATE Validate_TAXINFO(TAXINFO* taxinfo)
{
    /* check that tax_c lies between 0 and 100 */
    if (taxinfo->tax_c < -valid_tol || taxinfo->tax_c > 100.0 +valid_tol)
        return Invalid_tax_c ;

    /* check that tax_cg lies between 0 and 100 */
    if (taxinfo->tax_cg < -valid_tol || taxinfo->tax_cg > 100.0 +valid_tol)
        return Invalid_tax_cg ;

    /* check that bp_tax is greater than or equal to 0 */
    if (taxinfo->bp_tax < -valid_tol)
        return Invalid_bp_tax ;

    if (Validate_BOOLE(taxinfo->pro_rata) == False)
        return Invalid_boole ;

     return Valid_data ;
}


/*,,SOH,,
*************************************************************************
*
*               Validate_TRADEINFO()
*
*   interface   #include <bondvl.h>
*               VALIDATE Validate_TRADEINFO(TRADEINFO *t)
*
*   general     This function validates the content of the TRADEINFO
*               data structure
*
*   input       TRADEINFO  *t     The TRADEINFO data structure
*
*   output
*
*   returns     Valid_data if the content of t is valid,
*               Invalid_date if trade
*
*               Invalid_extrade if xctrade is an invalid EXTRADE
*               Invalid_extrade if xptrade is an invalid EXTRADE
*
*
*   diagnostics
*
*   see also    TRADEINFO
*
*************************************************************************
,,EOH,,*/


VALIDATE Validate_TRADEINFO(TRADEINFO* t)
{
    BOOLE   ok = True ;

    if (t->brd == True)
    {
        ok = Cldr_CheckDate(&t->trade) ;
        ok = ok && Cldr_CheckDate(&t->aisttl) ;
    }

       ok = ok && Cldr_CheckDate(&t->settle) ;

    if (ok == False)
        return Invalid_date ;

    if (t->brd == True && Cldr_DateLE(&t->trade, &t->settle) == False)
        return Trade_after_settle ;

    if (Validate_EXTRADE(&t->xctrade) == False)
        return Invalid_extrade ;

    if (Validate_EXTRADE(&t->xptrade) == False)
        return Invalid_extrade ;

    return Valid_data ;
}


/*,,SOH,,
*************************************************************************
*
*               Validate_EXTRADE()
*
*   interface   #include <bondvl.h>
*               BOOLE Validate_EXTRADE(EXTRADE *ext)
*
*   general     This function validates the content of the EXTRADE
*               data structure
*
*   input       EXTRADE   *ext    The EXTRADE data structure
*
*   output
*
*   returns     True if the content of ext if valid, otherwise False
*
*   diagnostics
*
*   see also    EXTRADE
*
*************************************************************************
,,EOH,,*/


BOOLE Validate_EXTRADE(EXTRADE* ext)
{
    BOOLE    ok ;

    ok = Validate_BOOLE(ext->spec) ;
    ok = ok && Validate_BOOLE(ext->ex_fix) ;

    if (ok == False)
        return False ;

    return True ;
}



/*,,SOH,,
*************************************************************************
*
*               Validate_INDEXBOND()
*
*   interface   #include <bondvl.h>
*               VALIDATE Validate_INDEXBOND(INDEXBOND *r)
*
*   general     This function validates the content of the INDEXBOND
*               data structure
*
*   input       INDEXBOND  *r      The INDEXBOND data structure
*
*   output
*
*   returns     Valid_data if the content of r is valid,
*               Invalid_boole if reverse is not True or False
*               Invalid_sell_date if sell_date is an invalid DATESTR
*               Invalid_buy_date if buy_date is an invalid DATESTR
*               Invalid_cal if cal is an invalid calendar convention
*               Invalid_INDEX_period if sell date is later then buy_date
*               If bond is an invalid fixpay an error message from
*                   Validate_FIXPAY() is returned
*
*   diagnostics
*
*   see also    INDEXBOND
*
*************************************************************************
,,EOH,,*/


VALIDATE Validate_INDEXBOND(INDEXBOND* r)
{
    VALIDATE tmp ;

    if (Validate_PERIOD(&r->pv_delay) == False)
        return Invalid_period ;

    if (Validate_PERIOD(&r->cflw_delay) == False)
        return Invalid_period ;

    tmp = Validate_FIXPAY(&r->fixp, False) ;
    if (tmp != Valid_data)
        return tmp ;

    return Valid_data ;
}

/*,,SOH,,
*************************************************************************
*
*               Validate_SWAPFIX()
*
*   interface   #include <bondvl.h>
*               VALIDATE Validate_SWAPFIX(SWAPFIX *fixpay)
*
*   general     This function validates the content of the SWAPFIX
*               data structure
*
*   input       SWAPFIX *fixpay   The SWAPFIX data structure
*
*   output
*
*   returns     Valid_data if the content of fixpay is valid,
*               If the content of any of the data structures PAYDAYDEF,
*                   FIXRATE, or REPAYMNT is invalid an error message
*                   from one of the corresponding validation routines
*                   is returned
*
*   diagnostics
*
*   see also    SWAPFIX
*
*************************************************************************
,,EOH,,*/


VALIDATE Validate_SWAPFIX(SWAPFIX* fixpay)
{
    VALIDATE v ;
    BOOLE    is_bull ;

    is_bull = ((fixpay->repay.type == BULLET ||
                fabs(fixpay->fix.fix_rate) < valid_tol)  ? True : False) ;
    v = Validate_PAYDAYDEF(&fixpay->pday, is_bull) ;
    if (v != Valid_data)
        return v ;

    v = Validate_FIXRATE(&fixpay->fix) ;
    if (v != Valid_data)
        return v ;
    if (fixpay->repay.type != NONREGULAR)
    {
        v = Validate_PAYDAYDEF(&fixpay->rday, True) ;
        if (v != Valid_data)
            return v ;
    }

    v = Validate_REPAYMNT(&fixpay->repay, &fixpay->pday.last, True, 
        True);
    if (v != Valid_data)
        return v ;

    return Valid_data ;
}


/*,,SOH,,
*************************************************************************
*
*               Validate_AIRESULT()
*
*   interface   #include <bondvl.h>
*               VALIDATE Validate_AIRESULT(AIRESULT *cm)
*
*   general     This function validates the content of the AIRESULT
*               data structure
*
*   input       AIRESULT *cm     The AIRESULT data structure
*
*   output
*
*   returns     Valid_data if the content of fixpay is valid,
*
*   diagnostics
*
*   see also    AIRESULT
*
*************************************************************************
,,EOH,,*/


VALIDATE Validate_AIRESULT(AIRESULT* cm)
{
    if (Cldr_CheckDate(&cm->next) == False && 
            Cldr_IsNullDate(&cm->next) == False)
        return Invalid_date ;

    if (Validate_BOOLE(cm->exc) == False)
        return Invalid_boole ;

    return Valid_data ;
}

/*,,SOH,,
*************************************************************************
*
*               Validate_YTMCONV()
*
*   interface   #include <bondvl.h>
*               VALIDATE Validate_YTMCONV(YTMCONV *cm)
*
*   general     This function validates the content of the YTMCONV
*               data structure
*
*   input       YTMCONV *cm     The YTMCONV data structure
*
*   output
*
*   returns     Valid_data if the content of fixpay is valid,
*
*   diagnostics
*
*   see also    YTMCONV
*
*************************************************************************
,,EOH,,*/


VALIDATE Validate_YTMCONV(YTMCONV* cm)
{
    if (Validate_IRRCONV(cm->irr) == False || cm->irr == MAIR)
        return Invalid_irrconv ;

    if (Validate_PMTFREQ(cm->qb_ytm) == False)
        return Invalid_freq ;

    if (Validate_BOOLE(cm->dayfrac_first) == False)
        return Invalid_boole ;

    if (Validate_BOOLE(cm->dayfrac_normal) == False)
        return Invalid_boole ;

    if (Validate_BOOLE(cm->dayfrac_last) == False)
        return Invalid_boole ;

    if (Validate_CALCONV(cm->cal_first) == False)
        return Invalid_cal ;

    if (Validate_CALCONV(cm->cal_normal) == False)
        return Invalid_cal ;

    if (Validate_CALCONV(cm->cal_last) == False)
        return Invalid_cal ;

    if (Validate_BOOLE(cm->trueYTM) == False)
        return Invalid_boole ;

    if (Validate_BOOLE(cm->as_bullet) == False)
        return Invalid_boole ;

    return Valid_data ;
}



/*,,SOH,,
***********************************************************************
*                                                                      
*               Validate_BONDBM()
*                                                                      
*   interface   #include <bondvl.h>                                  
*               VALIDATE Validate_BONDBM(BONDBM *x)
*                                                                      
*   general     This function validates the content of the BONDBM
*               data structure                                         
*                                                                      
*   input       BONDBM *x   The Benchmark Bond structure.
*                                                                      
*   output                                                             
*                                                                      
*   returns     Valid_data if the content of Benchmark Bond is valid.
*                                                                      
*   diagnostics
*               Refer to BONDBM for a specification of valid data.
*              
*   see also    BONDBM
*                                                                      
***********************************************************************
,,EOH,,*/

VALIDATE Validate_BONDBM(BONDBM*  x)
{
    VALIDATE v;

    if (Validate_BONDSEG(x->seg) == False)
      return Invalid_bondseg;

    if (Cldr_CheckDate(&x->matur) == False)
      return Invalid_matur;

    if (Validate_ODDCONV(x->stub_front) == False)
      return Invalid_oddconv;

      /* Validate issue_nom: */
    if (x->stub_front != NOODD || x->seg == JPYGOV)
    {
      if (Cldr_CheckDate(&x->issue_nom) == False)
        return Invalid_issue;
    }
    else if (x->seg == ESPGOV)
    {
      if (Cldr_IsNullDate(&x->issue_nom) == False &&
          Cldr_CheckDate(&x->issue_nom) == False)
        return Invalid_issue;
    }
    else if (x->seg == ITLGOV)
    {
      if (x->tax.tax_cg > valid_tol &&
          Cldr_CheckDate(&x->issue_nom) == False)
        return Invalid_issue;
    }
    else if (x->seg == OLDITLGOV)
    {
      if (x->tax.tax_cg > valid_tol &&
          Cldr_CheckDate(&x->issue_nom) == False)
        return Invalid_issue;
    }

      /* Validate first: */
    if (x->seg == JPYGOV)
    {
      if (Cldr_CheckDate(&x->first) == False)
        return Invalid_first;
    }

    v = Validate_TAXINFO(&x->tax);
    if (v != Valid_data)
      return v;

    return Valid_data;
}


/*,,SOH,,
************************************************************************
*                                                                       
*               Validate_FIXPAYARRAY()                                
*                                                                       
*   interface   #include <bondvl.h>                                   
*               VALIDATE Validate_FIXPAYARRAY(FIXPAYARRAY  cm,      
*                                             INTI n)                   
*                                                                       
*   general     This function validates the content of the 
*               FIXPAYARRAY data structure
*                                                                       
*   input       FIXPAYARRAY cm     The FIXPAYARRAY data structure   
*               INTI        n      The size of the array                
*                                                                       
*   output                                                              
*                                                                       
*   returns     Valid_data if the content of fixpay is valid,           
*                                                                       
*   diagnostics                                                         
*                                                                       
*   see also    FIXPAYARRAY                                           
*                                                                       
************************************************************************
,,EOH,,*/


VALIDATE Validate_FIXPAYARRAY(FIXPAYARRAY cm, INTI n)
{
    VALIDATE v = Valid_data ;
    INTI i ;

    for (i = 0; i < n && v == Valid_data; i++)
        v = Validate_FIXPAY(&cm[i], True) ;

    return v ;
}



/*,,SOH,,
************************************************************************
*                                                                       
*               Validate_BONDBMARRAY()                                
*                                                                       
*   interface   #include <bondvl.h>                                   
*               VALIDATE Validate_BONDBMARRAY(BONDBMARRAY  x,      
*                                             INTI n)                   
*                                                                       
*   general     This function validates the content of the 
*               BONDBMARRAY data structure
*                                                                       
*   input       BONDBMARRAY  x     The BONDBMARRAY data structure   
*               INTI        n      The size of the array                
*                                                                       
*   output                                                              
*                                                                       
*   returns     Valid_data if the content of BONDBM is valid,           
*                                                                       
*   diagnostics                                                         
*                                                                       
*   see also    BONDBMARRAY                                           
*                                                                       
************************************************************************
,,EOH,,*/


VALIDATE Validate_BONDBMARRAY(BONDBMARRAY x, INTI n)
{
    VALIDATE v = Valid_data ;
    INTI i ;

    for (i = 0; i < n && v == Valid_data; i++)
        v = Validate_BONDBM(&x[i]) ;

    return v ;
}


/*,,SOH,,
************************************************************************
*                                                                       
*               Validate_TRADEINFOARRAY()                               
*                                                                       
*   interface   #include <bondvl.h>                                   
*               VALIDATE Validate_TRADEINFOARRAY(TRADEINFOARRAY  cm,    
*                                             INTI n)                   
*                                                                       
*   general     This function validates the content of the 
*               TRADEINFOARRAY data structure
*                                                                       
*   input       TRADEINFOARRAY cm     The TRADEINFOARRAY data structure 
*               INTI           n      The size of the array         
*                                                                       
*   output                                                              
*                                                                       
*   returns     Valid_data if the content of TRADEINFO is valid,        
*                                                                       
*   diagnostics                                                         
*                                                                       
*   see also    TRADEINFOARRAY                                          
*                                                                       
************************************************************************
,,EOH,,*/


VALIDATE Validate_TRADEINFOARRAY(TRADEINFOARRAY cm, INTI n)
{
    VALIDATE v = Valid_data ;
    INTI i ;

    for (i = 0; i < n && v == Valid_data; i++)
        v = Validate_TRADEINFO(&cm[i]) ;

    return v ;
}


/*,,SOH,,
***********************************************************************
*                                                                      
*               Validate_HZYCONV()
*                                                                      
*   interface   #include <bondvl.h>                                  
*               VALIDATE Validate_HZYCONV(HZYCONV *x)
*                                                                      
*   general     This function validates the content of the HZYCONV
*               data structure                                         
*                                                                      
*   input       HZYCONV *x   The HZYCONV structure.
*                                                                      
*   output                                                             
*                                                                      
*   returns     Valid_data if the content of HZYCONV is 
*               valid.
*                                                                      
*   diagnostics
*               Refer to HZYCONV for a specification of valid data.
*              
*   see also    HZYCONV
*                                                                      
***********************************************************************
,,EOH,,*/
VALIDATE Validate_HZYCONV(HZYCONV*  x)
{
    VALIDATE v;

    if (Validate_BOOLE(x->reinv) == False)
        return Invalid_boole;

    if (Validate_BOOLE(x->hzp) == False)
        return Invalid_boole;

    v = Validate_YTMCONV(&x->ytmc);
    if (v != Valid_data)
        return Valid_data;

    return Valid_data;
}



/*,,SOH,,
***********************************************************************
*                                                                      
*              Validate_SCENARIO()
*                                                                      
*   interface  #include <bondvl.h>                                   
*              VALIDATE Validate_SCENARIO(SCENARIO   *pf) ;         
*                                                                      
*   general     This function validates the content of the SCENARIO
*                data structure                                        
*                                                                      
*   input       SCENARIO    *pf      The SCENARIO data structure 
*                                   
*   output                                                             
*                                                                      
*   returns     Valid_data if the content of  is valid,                
*                                                                      
*   diagnostics                                                        
*                                                                      
*   see also                                                           
*                                                                      
***********************************************************************
,,EOH,,*/
VALIDATE Validate_SCENARIO(SCENARIO*  pf)
{
    VALIDATE v;
    INTI i ;

    v = Valid_data;
    for (i = 0; i < pf->nbuck && v == Valid_data; i++)
        v = Validate_BUCKETARRAY(pf->scen, pf->nbuck);

    return Valid_data ;
}

/*,,SOH,,
************************************************************************
*                                                                       
*               Validate_SCENARIOARRAY()                               
*                                                                       
*   interface   #include <bondvl.h>                                   
*               VALIDATE Validate_SCENARIOARRAY(SCENARIOARRAY  cm,    
*                                             INTI n)                   
*                                                                       
*   general     This function validates the content of the 
*               SCENARIOARRAY data structure
*                                                                       
*   input       SCENARIOARRAY cm     The SCENARIOARRAY data structure 
*               INTI          n      The size of the array             
*                                                                       
*   output                                                              
*                                                                       
*   returns     Valid_data if the content of SCENARIO is valid,        
*                                                                       
*   diagnostics                                                         
*                                                                       
*   see also    SCENARIOARRAY                                          
*                                                                       
************************************************************************
,,EOH,,*/


VALIDATE Validate_SCENARIOARRAY(SCENARIOARRAY cm, INTI n)
{
    VALIDATE v = Valid_data ;
    INTI i ;

    for (i = 0; i < n && v == Valid_data; i++)
        v = Validate_SCENARIO(&cm[i]) ;

    return v ;
}


/*,,SOH,,
***********************************************************************
*                                                                      
*              Validate_SCENARIOLIST()
*                                                                      
*   interface  #include <bondvl.h>                                   
*              VALIDATE Validate_SCENARIOLIST(SCENARIOLIST   *pf) ;    
*                                                                      
*   general     This function validates the content of the SCENARIOLIST
*                data structure                                        
*                                                                      
*   input       SCENARIOLIST *pf      The SCENARIOLIST data structure   
*                                   
*   output                                                             
*                                                                      
*   returns     Valid_data if the content of  is valid,                
*                                                                      
*   diagnostics                                                        
*                                                                      
*   see also                                                           
*                                                                      
***********************************************************************
,,EOH,,*/
VALIDATE Validate_SCENARIOLIST(SCENARIOLIST*  pf)
{
    VALIDATE v;
    INTI i ;

    v = Valid_data;
    for (i = 0; i < pf->nscen && v == Valid_data; i++)
        v = Validate_SCENARIOARRAY(pf->scens, pf->nscen);

    return Valid_data ;
}


/*,,SOH,,
***********************************************************************
*                                                                      
*               Validate_BSECTYPE()                                     
*                                                                      
*   interface   #include <bondvl.h>                                  
*               BOOLE     Validate_BSECTYPE(BSECTYPE r)                 
*                                                                      
*   general     This function validates the content of the BSECTYPE     
*               data structure                                         
*                                                                      
*   input       BSECTYPE  r  The BSECTYPE data structure                
*                                                                      
*   output                                                             
*                                                                      
*   returns     True if r is a valid BSECTYPE, False if invalid         
*                                                                      
*   diagnostics                                                        
*                                                                      
*   see also    BSECTYPE                                                
*                                                                      
***********************************************************************
,,EOH,,*/


BOOLE Validate_BSECTYPE(BSECTYPE  r)
{
    /* check that r is valid */
    switch (r)
    {
    case MM:
    case FRA:
    case IMMFRA:
    case SWAP:
    case IRF:
    case BOND:
    case AVGIRF:
    case BONDREPO:
    case BONDSMPL:
    case SWAPGENR:
    case SWAPFUT:
        return True ;
    default :
        return False ;
    }
}



/*,,SOH,,
***********************************************************************
*                                                                      
*               Validate_BSEC()
*                                                                      
*   interface   #include <bondvl.h>                                  
*               VALIDATE Validate_BSEC(BSEC *x)
*                                                                      
*   general     This function validates the content of the BSEC
*               data structure                                         
*                                                                      
*   input       BSEC *x   The Bootstrap security structure.
*                                                                      
*   output                                                             
*                                                                      
*   returns     Valid_data if the content of Bootstrap security is 
*               valid.
*                                                                      
*   diagnostics
*               Refer to BSEC for a specification of valid data.
*              
*   see also    BSEC
*                                                                      
***********************************************************************
,,EOH,,*/

VALIDATE Validate_BSEC(BSEC*  x)
{
    VALIDATE v;

    if (Validate_BSECTYPE(x->type) == False)
      return Invalid_bsectype;

    if (x->type == MM)
        if (Validate_IRRCONV(x->irr) == False)
          return Invalid_irrconv;

    if (x->type == MM || x->type == FRA || x->type == IRF || 
        x->type == IMMFRA || x->type == SWAP || x->type == AVGIRF || 
        x->type == BONDSMPL || x->type == SWAPFUT)
        if (Validate_CALCONV(x->cal) == False)
          return Invalid_cal;

    if (x->type == MM || x->type == FRA || x->type == IRF || 
        x->type == IMMFRA || x->type == SWAP || x->type == AVGIRF || 
        x->type == BONDSMPL || x->type == BONDREPO ||
        x->type == SWAPGENR || x->type == SWAPFUT)
        if (Validate_CALCONV(x->cal_ipol) == False)
          return Invalid_cal;

    if (x->type == MM || x->type == FRA || x->type == IRF || 
        x->type == IMMFRA || x->type == SWAP || x->type == AVGIRF || 
        x->type == BONDSMPL || x->type == BONDREPO || x->type == SWAPFUT)
        if (Validate_EOMCONV(x->eom) == False)
          return Invalid_eomconv;

    if (x->type == MM || x->type == FRA || x->type == IRF || 
        x->type == IMMFRA || x->type == SWAP || x->type == AVGIRF || 
        x->type == BOND || x->type == BONDSMPL || 
        x->type == BONDREPO || x->type == SWAPGENR || x->type == SWAPFUT)
        if (Validate_BUSCONV(x->bus) == False)
            return Invalid_busconv;

    if (x->type == SWAP || x->type == AVGIRF || x->type == SWAPFUT)
    {
        if (x->term1 < 1)
            return Invalid_term;
    }
    else if (x->type == FRA || x->type == IMMFRA || x->type == MM)
    {
        if (x->term1 < 0)
            return Invalid_term;
    }

    if (x->type == FRA)
        if (x->term2 < 1)
            return Invalid_term;

    if (x->type == MM || x->type == FRA || x->type == IMMFRA || 
            x->type == SWAP || x->type == AVGIRF || x->type == SWAPFUT)
        if (Validate_TERMUNIT(x->unit) == False)
            return Invalid_termunit;

    if (x->type == FRA)
    {
        if (Validate_BOOLE(x->nest) == False)
            return Invalid_seqconv;

        if (x->term2 <= x->term1)
            return First_after_last;
    }

    if (x->type == IRF || x->type == AVGIRF || x->type == BONDSMPL)
    {
        if (Cldr_CheckDate(&x->start) == False)
            return Invalid_first;
    }

    if (x->type == IRF || x->type == AVGIRF || 
        x->type == BONDSMPL || x->type == BONDREPO || x->type == SWAPFUT)
    {
        if (Cldr_CheckDate(&x->maturity) == False)
            return Invalid_matur;
    }

    if (x->type == IRF || x->type == AVGIRF)
    {
        if (Cldr_DateLT(&x->start, &x->maturity) == False)
            return First_after_last;
    }

    if (x->type == SWAP || x->type == SWAPFUT || x->type == BONDSMPL)
        if (Validate_PMTFREQ(x->freq) == False)
            return Invalid_freq;

    if (x->type == BOND || x->type == BONDREPO)
    {
        v = Validate_FIXPAY(&x->fixp, True);
        if (v != Valid_data)
            return v;
    }

    if (x->type == BONDSMPL)
    {
      if (x->excdays < 0)
          return Invalid_exdays;
    }

    if (x->type == SWAPGENR)
    {
        v = Validate_SWAPFIX(&x->sfix);
        if (v != Valid_data)
            return v;
    }

    return Valid_data;
}



/*,,SOH,,
***********************************************************************
*                                                                      
*               Validate_BSECARRAY()
*                                                                      
*   interface   #include <bondvl.h>                                  
*               VALIDATE Validate_BSECARRAY(BSECARRAY x,
*                                           INTI      n);
*                                                                      
*   general     This function validates the content of the BSECARRAY
*               data structure                                         
*                                                                      
*   input       BSECARRAY x   The Bootstrap security structures.
*               INTI      n   Number of elements in x.
*                                                                      
*   output                                                             
*                                                                      
*   returns     Valid_data if the content of Bootstrap security is 
*               valid.
*                                                                      
*   diagnostics
*               Refer to BSEC for a specification of valid data.
*              
*   see also    BSEC
*                                                                      
***********************************************************************
,,EOH,,*/

VALIDATE Validate_BSECARRAY(BSECARRAY  x, INTI  n)
{
    VALIDATE v;
    INTI i;

    v = Valid_data;
    for (i = 0; i < n && v == Valid_data; i++)
      v = Validate_BSEC(&x[i]);

    return v;
}



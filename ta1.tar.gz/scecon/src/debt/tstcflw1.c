/* SCID @(#)tstcflw1.c	1.3 (SimCorp) 99/02/19 14:12:39 */

/************************************************************************
*
*   project     SCecon
*
*   filename    cflwtst1.c
*
*   this program tests the routines in the cash flow module of SCecon
*
************************************************************************/

/*** includes ***********************************************************/
#include <string.h>
#include <str2conv.h>
#include <scalloc.h>
#include <cflw.h>
#include <bondio.h>

/*** routine ************************************************************/


INTI cflwtst1(char* txa, FILE* in, FILE* out)
{
    char        txg[25], txb[25], txc[25], txd[25], txe[25], txf[25], txh[25],
                txj[25], txpl[64] ;
    INTI        dif1, n1, n2, n3, i, diff, na, nr, nc, np ;
    FL64        *rprice, *pp, *repay, *coupon, *ecoupon, coup, *rate, acc,
                *eamort, *amort, *tmpamort;
    YYYYMMDD    dlast, dissue, ymd, matur ;
    DATESTR     *ppday, *amortday, *rateday, *couponday, *tmpday, dmatur,
                iss, last ;
    int         i1, i2, i3, i4, i5 ;
    FIXRATE     fix ;
    PLAN_STR    plana, planpp, planx ;
    PAYDAYSEQ   pseq ;

	HOLI_STR    holi;  	/* PMSTA-22396 - SRIDHARA � 160502 */

    acc = 0.00001 ;
    diff = -1 ;

    if (!strcmp("Cflw_GenrCoupons()", txa))
    {
        fscanf(in, "%s %s %ld %ld %lf %lf %d %s %s %s %s %s %s %d %d %d %d %s",
               txg, txf, &dissue, &dlast, &fix.accrfac, &coup, &i5, txe, txb,
               txj, txc, txd, txh, &i1, &i2, &i3, &i4, txpl) ;

        na = (INTI) i1 ;
        nr = (INTI) i2 ;
        np = (INTI) i3 ;
        nc = (INTI) i4 ;

        iss  = Cldr_YMD2Datestr(dissue) ;
        last = Cldr_YMD2Datestr(dlast) ;

        pseq.term = (INTI) i5 ;
        pseq.unit = Str2TERMUNIT(txe) ;
        pseq.odd1 = Str2ODDCONV(txb) ;
        pseq.oddn = Str2ODDCONV(txj) ;
        pseq.eom  = Str2EOMCONV(txc) ;

        fprintf(out,"?; testing %s\n", txa) ;
        fprintf(out,"   date from          %8ld\n", dissue) ;
        fprintf(out,"   date last          %8ld\n", dlast) ;
        fprintf(out,"   AccrFac            %8.5lf\n", fix.accrfac) ;
        fprintf(out,"   coupon             %8.5lf\n", coup) ;
        fprintf(out,"   term              %d\n", i5) ;
        fprintf(out,"   unit              %s\n", txe) ;
        fprintf(out,"   coupon base (odd) %s\n", txg) ;
        fprintf(out,"   coupon base       %s\n", txf) ;
        fprintf(out,"   odd1              %s\n", txb) ;
        fprintf(out,"   oddN              %s\n", txj) ;
        fprintf(out,"   eom convention    %s\n", txc) ;
        fprintf(out,"   cal convention    %s\n", txd) ;
        fprintf(out,"   prepaid ?         %s\n", txh) ;

        repay     = Alloc_FL64ARRAY(na) ;
        amortday  = Alloc_DATEARRAY(na) ;

        pp        = Alloc_FL64ARRAY(np) ;
        ppday     = Alloc_DATEARRAY(np) ;

        ecoupon   = Alloc_FL64ARRAY(nc) ;
        couponday = Alloc_DATEARRAY(nc) ;

        rate      = Alloc_FL64ARRAY(nr) ;
        rateday   = Alloc_DATEARRAY(nr) ;

        fprintf(out,"   number of principal payments %d\n", na) ;
        for (i = 0 ; i < na ; i++)
        {
            fscanf(in, "%ld %lf", &ymd, &repay[i]) ;
            amortday[i] = Cldr_YMD2Datestr(ymd) ;
            fprintf(out,"   %8ld %9.5lf\n", ymd, repay[i]) ;
        }

        fprintf(out,"   number of coupon adjustments %d\n", nr) ;
        for (i = 0 ; i < nr ; i++)
        {
            fscanf(in, "%ld %lf", &ymd, &rate[i]) ;
            rateday[i] = Cldr_YMD2Datestr(ymd) ;
            fprintf(out,"   %8ld %9.5lf\n", ymd, rate[i]) ;
        }

        fprintf(out,"   number of partly paids       %d\n", np) ;
        for (i = 0 ; i < np ; i++)
        {
            fscanf(in, "%ld %lf", &ymd, &pp[i]) ;
            ppday[i] = Cldr_YMD2Datestr(ymd) ;
            fprintf(out,"   %8ld %9.5lf\n", ymd, pp[i]) ;
        }

        for (i = 0 ; i < nc ; i++)
        {
            fscanf(in, "%ld %lf", &ymd, &ecoupon[i]) ;
            couponday[i] = Cldr_YMD2Datestr(ymd) ;
        }

        planx.filled = nr ;
        planx.day = rateday ;
        planx.f64 = rate ;

        planpp.filled = np ;
        planpp.day    = ppday ;
        planpp.f64    = pp ;

        plana.filled = na ;
        plana.day    = amortday ;
        plana.f64    = repay ;

        fix = Set_FIXRATE(coup, Str2CALCONV(txd), &iss, &last, fix.accrfac,
                          Str2COUPONBASE(txf), Str2COUPONBASE(txg),
                          Str2BOOLE(txh), False, &planx, False,
                          NULL, NODCOMP) ;


		/* PMSTA-22396 - SRIDHARA � 160502 */
		holi = Read_HOLI_STR(in, out);
		coupon = Cflw_GenrCoupons(&fix, &plana, couponday, nc, &planpp, &pseq, &holi)
			;
        diff = 0 ;
        for (i = 0 ; i < nc ; i++)
            diff = (diff || (fabs(coupon[i] - ecoupon[i]) > acc)) ;

        fprintf(out,"   the %d coupon payments are\n", nc) ;
        fprintf(out,"       date computed  expected\n") ;

        for (i = 0 ; i < nc ; i++)
            fprintf(out,"%d; %8ld %8.5lf ; %8.5lf\n",
                    fabs(coupon[i] - ecoupon[i]) > acc,
                    Cldr_Datestr2YMD(&couponday[i]), coupon[i], ecoupon[i]) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_FL64ARRAY(pp) ;
        Free_DATEARRAY(ppday) ;
        Free_FL64ARRAY(repay) ;
        Free_DATEARRAY(amortday) ;
        Free_FL64ARRAY(ecoupon) ;
        Free_FL64ARRAY(coupon) ;
        Free_DATEARRAY(couponday) ;
        Free_FL64ARRAY(rate) ;
        Free_DATEARRAY(rateday) ;
		Free_DATEARRAY(holi.holidays);  	/* PMSTA-22396 - SRIDHARA � 160502 */
    }

    else if (!strcmp("Cflw_Balloon()", txa))
    {
        fscanf(in, "%d %d %ld %s", &i1, &i2, &matur, txpl) ;
        n1 = (INTI) i1 ;
        n2 = (INTI) i2 ;

        dmatur = Cldr_YMD2Datestr(matur) ;

        repay    = Alloc_FL64ARRAY(n1) ;
        tmpamort = Alloc_FL64ARRAY(n2) ;
        amortday = Alloc_DATEARRAY(n1) ;
        tmpday   = Alloc_DATEARRAY(n2) ;

        for (i = 0 ; i < n1 ; i++)
        {
            fscanf(in, "%ld %lf", &ymd, &repay[i]) ;
            amortday[i] = Cldr_YMD2Datestr(ymd) ;
        }

        for (i = 0 ; i < n2 ; i++)
        {
            fscanf(in, "%ld %lf", &ymd, &tmpamort[i]) ;
            tmpday[i] = Cldr_YMD2Datestr(ymd) ;
        }

        n3 = Cflw_Balloon(amortday, n1, &dmatur, repay) ;

        diff = (n3 != n2) ;

        if (diff == 0)
        {
            for (i = 0 ; i < n2 ; i++)
                diff = diff || (fabs(repay[i] - tmpamort[i]) > acc) ||
                       (Cldr_DateEQ(&amortday[i], &tmpday[i]) == False) ;
        }

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   number of theoretical payments %8d\n", n1) ;

        fprintf(out,"   theoretical payments...\n") ;
        fprintf(out,"       date   payment\n") ;
        for (i = 0 ; i < n1 ; i++)
            fprintf(out,"   %8ld %9.5lf\n",
                                     Cldr_Datestr2YMD(&amortday[i]), repay[i]) ;

        fprintf(out,"   maturity of balloon            %8ld\n", matur) ;

        if (n3 == n2)
        {
            fprintf(out,"   computed             expected\n") ;
            fprintf(out,"       date repayment       date repayment\n") ;

            for (i = 0 ; i < n2 ; i++)
            {
                dif1 = (fabs(repay[i] - tmpamort[i]) > acc) ||
                       (Cldr_DateEQ(&amortday[i], &tmpday[i]) == False) ;
                fprintf(out, "%d; %8ld %9.5lf ; %8ld %9.5lf\n",
                        dif1, Cldr_Datestr2YMD(&tmpday[i]), tmpamort[i],
                        Cldr_Datestr2YMD(&amortday[i]), repay[i]) ;
            }
        }

        else
        fprintf(out, "   you expected %d amort's, but we found %d\n", n2, n3) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_FL64ARRAY(repay) ;
        Free_FL64ARRAY(tmpamort) ;
        Free_DATEARRAY(amortday) ;
        Free_DATEARRAY(tmpday) ;
    }

    else if (!strcmp("Cflw_Redemption_Price()", txa))
    {
        fscanf(in, "%d %d %s", &i1, &i2, txpl) ;
        n1 = (INTI) i1 ;
        n2 = (INTI) i2 ;

        repay    = Alloc_FL64ARRAY(n1) ;
        amortday = Alloc_DATEARRAY(n1) ;
        eamort   = Alloc_FL64ARRAY(n1) ;
        amort    = Alloc_FL64ARRAY(n1) ;
        tmpamort = Alloc_FL64ARRAY(n1) ;
        tmpday   = Alloc_DATEARRAY(n2) ;
        rprice   = Alloc_FL64ARRAY(n2) ;

        for (i = 0 ; i < n1 ; i++)
        {
            fscanf(in, "%ld %lf %lf", &ymd, &repay[i], &eamort[i]) ;
            amort[i] = repay[i] ;
            amortday[i] = Cldr_YMD2Datestr(ymd) ;
        }

        for (i = 0 ; i < n2 ; i++)
        {
            fscanf(in, "%ld %lf", &ymd, &rprice[i]) ;
            tmpday[i] = Cldr_YMD2Datestr(ymd) ;
        }

        Cflw_Redemption_Price(amortday, repay, n1, tmpday, rprice, n2) ;

        diff = 0 ;

        fprintf(out,"?; testing %s\n", txa) ;
        fprintf(out,"   number of payments          %8d\n", n1) ;
        fprintf(out,"   number of redemption prices %8d\n", n2) ;
        for (i = 0 ; i < n2 ; i++)
            fprintf(out, "   date[%2d] %8ld, redemption price[%2d] %9.5lf\n",
                    i, Cldr_Datestr2YMD(&tmpday[i]), i, rprice[i]) ;

        fprintf(out,"   results are...\n") ;
        fprintf(out,"       date principal  computed  expected\n") ;

        for (i = 0 ; i < n1 ; i++)
        {
            dif1 = (fabs(eamort[i] - repay[i]) > acc) ;
            fprintf(out, "%d; %8ld %9.5lf %9.5lf %9.5lf\n",
                    dif1, Cldr_Datestr2YMD(&amortday[i]), amort[i],
                    repay[i], eamort[i]) ;
            diff = diff || dif1 ;
        }

        fprintf(out,"   %s\n\n", txpl) ;

        Free_FL64ARRAY(repay) ;
        Free_FL64ARRAY(tmpamort) ;
        Free_FL64ARRAY(eamort) ;
        Free_FL64ARRAY(amort) ;
        Free_FL64ARRAY(rprice) ;
        Free_DATEARRAY(amortday) ;
        Free_DATEARRAY(tmpday) ;
    }

    return diff ;
}

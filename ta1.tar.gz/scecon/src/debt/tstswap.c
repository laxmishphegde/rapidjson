/* @(#)tstswap.c	1.5 (SimCorp) 99/02/19 14:12:50 */

/************************************************************************
*
*   Project     SCecon
*
*   this program tests the routines in the swap module of SCecon
*
************************************************************************/

/*** includes ***********************************************************/
#include <string.h>
#include <str2conv.h>
#include <swap.h>
#include <ioconv.h>
#include <bondio.h>
                    
/*** Prototypes *********************************************************/

INTI swapfixtest(char* txa, FILE* in, FILE* out)
{
    char        txb[25], txc[25], txd[25], txpl[140],
                txf[25], txg[25] ;
    INTI        dexp, i, ns, diff, dif1, na, nd ;
    FL64        fix_rate, *amort, *fixcoupon, *fixamort, *expcoup,
                acc, fexp, fres, *aspr ;
    PLANARRAY   disc ;
    EOMCONV     eom ;
    CALCONV     cal ;
    DISCIPOL    ipol ;
    YYYYMMDD    effect, ymd ;
    DATESTR     analys, deffect ;
    DATESTR     *fixdays, *amortdays, *sprdays ;
    PMTFREQ     freq ;
    COUPONBASE  cbase ;
    INTPOLCONV  iconv ;
    int         i1, i2, i7 ;
    HOLI_STR    holi ;
    FIXRATE     fix ;
    PLAN_STR    planx, plana ;
    CFLW_STR    xcflw, *cflw, *xpcflw ;
    DISCFAC     df ;
    PAYDAYSEQ   pseq ;
    SWAPFIX     sfix ;

    acc   = 0.00001 ;
    diff = -1 ;

    if (!strcmp("SwapFix_GenrCflw()", txa))
    {
        fprintf(out,"?; testing %s\n", txa) ;
        sfix = Read_SWAPFIX(in, out) ;
        holi = Read_HOLI_STR(in, out) ;

        cflw = SwapFix_GenrCflw(&sfix, &holi) ;

        xpcflw = Read_CFLWARRAY(in, out) ;
        diff   = Write_CflwDiff(cflw, xpcflw, out) ;

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_CFLWARRAY(cflw, 1) ;
        Free_CFLWARRAY(xpcflw, 1) ;
        Free_DATEARRAY(holi.holidays) ;
        Free_SWAPFIX(&sfix) ;
    }

    else if (!strcmp("SwapFix_GenrCoupons()", txa))
    {
        fscanf(in, "%ld %s %s %lf %s %s %d %d %d %s",
               &effect, txc, txd, &fix_rate, txf, txg, &i1, &i7, &i2, txpl)
                 ;
        na = (INTI) i1 ;
        ns = (INTI) i7 ;
        dexp = (INTI) i2 ;

        eom  = Str2EOMCONV(txc) ;
        cal  = Str2CALCONV(txd) ;
        freq = Str2PMTFREQ(txf) ;
        cbase = Str2COUPONBASE(txg) ;
        deffect = Cldr_YMD2Datestr(effect) ;

        amortdays = Alloc_DATEARRAY(GETMAX(1, na)) ;
        amort     = Alloc_FL64ARRAY(GETMAX(1, na)) ;
        fixdays   = Alloc_DATEARRAY(dexp) ;
        expcoup   = Alloc_FL64ARRAY(dexp) ;
        sprdays   = Alloc_DATEARRAY(ns) ;
        aspr      = Alloc_FL64ARRAY(ns) ;

        fprintf(out,"?; testing %s\n", txa) ;
        fprintf(out,"   effective day      %8ld\n", effect) ;
        fprintf(out,"   eomconv            %8s\n", txc) ;
        fprintf(out,"   calendar           %8s\n", txd) ;
        fprintf(out,"   pmt.freq.          %8s\n", txf) ;
        fprintf(out,"   couponbase         %8s\n", txg) ;
        fprintf(out,"   fix rate           %3.4lf\n", fix_rate) ;

        fprintf(out,"   the amort schedule is...\n") ;
        fprintf(out,"       date  repayment\n") ;

        for (i = 0 ; i < na ; i++)
        {
            fscanf(in, "%ld %lf", &ymd, &amort[i]) ;
            amortdays[i] = Cldr_YMD2Datestr(ymd) ;
            fprintf(out,"   %8ld %9.5lf\n", ymd, amort[i]) ;
        }

        fprintf(out,"   the stepped coupon schedule is...\n") ;
        fprintf(out,"       date  coupon\n") ;

        for (i = 0 ; i < ns ; i++)
        {
            fscanf(in, "%ld %lf", &ymd, &aspr[i]) ;
            sprdays[i] = Cldr_YMD2Datestr(ymd) ;
            fprintf(out,"   %8ld %9.5lf\n", ymd, aspr[i]) ;
        }

        for (i = 0 ; i < dexp ; i++)
        {
            fscanf(in, "%ld %lf", &ymd, &expcoup[i]) ;
            fixdays[i] = Cldr_YMD2Datestr(ymd) ;
        }

        planx.filled  = ns ;
        planx.day     = sprdays ;
        planx.f64     = aspr ;
        fix = Set_FIXRATE(fix_rate, cal, &deffect, NULL, 0.0, 
                          cbase, cbase, False, False, &planx,
                          True, NULL, NODCOMP) ;

        plana.filled = na ;
        plana.f64    = amort ;
        plana.day    = amortdays ;

        pseq      = Set_PAYDAYSEQ(Cflw_MonthsBetweenPayments(freq),
                       MONTHS, NOODD, NOODD, ANCHOR, eom);
        fixcoupon = SwapFix_GenrCoupons(&fix, &plana, fixdays, dexp,
                                         &pseq, &holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
        diff = 0 ;
        fprintf(out,"       date exp.coupon comp.coupon\n") ;
        for (i = 0 ; i < dexp ; i++)
        {
            dif1 = (fabs(fixcoupon[i] - expcoup[i]) > acc);
            fprintf(out, "%d; %8ld %9.5lf %9.5lf\n",
                    dif1, Cldr_Datestr2YMD(&fixdays[i]),
                    expcoup[i], fixcoupon[i]) ;
            diff = dif1 || diff ;
        }

        fprintf(out,"   %s\n\n", txpl) ;

        Free_FL64ARRAY(amort) ;
        Free_DATEARRAY(amortdays) ;
        Free_FL64ARRAY(aspr) ;
        Free_DATEARRAY(sprdays) ;
        Free_DATEARRAY(fixdays) ;
        Free_FL64ARRAY(fixcoupon) ;
        Free_FL64ARRAY(expcoup) ;
    }


    else if (!strcmp("Swap_DF2NPV()", txa))
    {
        fscanf(in, 
          "%lf %d %d %s %s %s %s",
          &fexp, &i1, &i2, txb, txd, txc, txpl) ;
        na = (INTI) i1 ;
        nd = (INTI) i2 ;

        ipol = Str2DISCIPOL(txb) ;
        iconv = Str2INTPOLCONV(txd) ;
        cal  = Str2CALCONV(txc) ;

        fixdays   = Alloc_DATEARRAY(na) ;
        fixcoupon = Alloc_FL64ARRAY(na) ;
        fixamort  = Alloc_FL64ARRAY(na) ;
        disc      = Alloc_PLANARRAY(1, nd) ;

        fprintf(out,"?; testing %s\n", txa) ;
        fprintf(out,"   ipol in disc. ??   %8s\n", txb) ;
        fprintf(out,"   intpol             %8s\n", txd) ;
        fprintf(out,"   calendar           %8s\n", txc) ;

        fprintf(out,"   the pay schedule is...\n") ;
        fprintf(out,"       date  coupon   repayment\n") ;

        for (i = 0 ; i < na ; i++)
        {
            fscanf(in, "%ld %lf %lf", &ymd, &fixcoupon[i], &fixamort[i]) ;
            fixdays[i] = Cldr_YMD2Datestr(ymd) ;
            fprintf(out,"   %8ld %9.5lf %9.5lf\n",
                    ymd, fixcoupon[i], fixamort[i]) ;
        }
        fprintf(out,"   the discount function is...\n") ;
        fprintf(out,"       date  discount factor\n") ;

        for (i = 0 ; i < nd ; i++)
        {
            fscanf(in, "%ld %lf", &ymd, &disc[0].f64[i]) ;
            disc[0].day[i] = Cldr_YMD2Datestr(ymd) ;
            fprintf(out,"   %8ld %9.5lf\n", ymd, disc[0].f64[i]) ;
        }

        disc[0].count = disc[0].filled = nd ;

        xcflw.days   = fixdays ;
        xcflw.coupon = fixcoupon ;
        xcflw.repay  = fixamort ;
        xcflw.filled = na ;

        df = Set_DISCFAC(disc, ipol, iconv, cal, CONTINUOUS, ANNUALLY)
          ;

        if (GetPlanFill(df.disc) > 0)
            analys = df.disc->day[0] ;
        else
            analys = Cldr_YMD2Datestr((YYYYMMDD) 19900101) ;

		fres = Swap_DF2NPV(&analys, &xcflw, True, &df, &holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */
        diff = (fabs(fexp - fres) > acc) ;

        fprintf(out, "%d;  expected NPV is %9.5lf  result is %9.5lf\n",
                diff, fexp, fres) ;

        fprintf(out,"   %s\n\n", txpl) ;

        Free_DATEARRAY(fixdays) ;
        Free_FL64ARRAY(fixcoupon) ;
        Free_FL64ARRAY(fixamort) ;
        Free_PLANARRAY(disc, 1) ;
    }


    return diff ;
}


/*
..
*/



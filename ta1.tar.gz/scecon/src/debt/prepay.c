/* SCID @(#)prepay.c	1.6 (SimCorp) 99/10/01 14:47:08 */

/************************************************************************
*
*   project     SCecon
*
*   filename    prepay.c
*
*   general     This file contains routines for merging
*               prepayments and ordinary amortisations.
*
************************************************************************/

/* includes ************************************************************/
#include <bond.h>

/*** defines  **********************************************************/
#define ZERO_TOL  0.0001


/*,,SOH,,
*************************************************************************
*
*               Cflw_MergeXtraOrdCflw()
*
*    interface  #include <bond.h>
*               CFLWARRAY Cflw_MergeXtraOrdCflw(DATESTR*   today,
*                                               CFLW_STR*  cflw,
*                                               PLAN_STR*  prep,
*                                               PREPAYCONV prepayc,
*                                               FL64       anncoup,
*                                               PMTFREQ    pfreq,
*                                               EXRULE*    excp,
*                                               EXRULE*    expr,
*                                               EXRULE*    expr_d,
*                                               BOOLE*     exc,
*                                               BOOLE*     exp,
*                                               BOOLE*     expd) ;
*
*    general    The routine performs prepayment adjustment of the 
*               scheduled cash flow of a bond. In particular, it can 
*               be used to merge an ordinary with an extraordinary cash
*               flow or to perform Conditional Prepayment Rate (CPR)
*               adjustments.
*
*    input      DATESTR  *today     Analysis date.
*
*               CFLW_STR *cflw      The ordinary cashflow.
*                                   The payment frequency should match
*                                   'pfreq' for a sensible result.
*                                   The coupon payments are not used.
*                                   The new coupons are generated using
*                                   'pfreq' and 'anncoup'.
*
*               PLAN_STR *prep      The dates and corresponding
*                                   prepayments.
*
*               PREPAYCONV prepayc  Convention for quoting prepayments.
*
*               FL64     anncoup    The annually coupon (in %)
*
*               PMTFREQ  pfreq      Payment frequency
*
*               EXRULE   *excp      Definition of ex-coupon rules
*
*               EXRULE   *expr      Definition of ex-principal rules
*
*               EXRULE   *expr_d    The period before a payday after
*                                   which the debtor cannot call his
*                                   loan (typically a day)
*
*    output     BOOLE    *exc       Ex-Coupon status on 'today'
*
*               BOOLE    *exp       Ex-Principal status on 'today'
*
*               BOOLE    *expd      Ex-Principal (debtor) status on
*                                   'today'
*
*    returns    Resulting normalised cashflow extracted from 'today'. 
*               Allocated as Alloc_CFLWARRAY(1, cflw->filled);
*               Taking into account the ex-status for 'today'.
*
*    diagnostics
*
*    see also   Bond_GenrXtraOrdAmort()
*               DKmbs_Genr_Cflw()
*               Cflw_Amort2Prepay()
*
*************************************************************************
,,EOH,,*/

CFLWARRAY Cflw_MergeXtraOrdCflw(DATESTR*    today,
                                    CFLW_STR*   cflw,
                                    PLAN_STR*   prep,
                                    PREPAYCONV  prepayc,
                                    FL64        anncoup,
                                    PMTFREQ     pfreq,
                                    EXRULE*     excp,
                                    EXRULE*     expr,
                                    EXRULE*     expr_d,
                                    BOOLE*      exc,
                                    BOOLE*      exp,
                                    BOOLE*      expd)
{
    HOLI_STR  holi ;
    FL64      spm, rep, fac, rg_orig, rg_new, period, total_orig, xtra ;
    INTI      months, ix, i, prep_no ;
    CFLWARRAY xcflw, cflwm ;
    DATESTR   last, prev, end ;
    EXTRADE   extr ;


    /* No holiday adjustment */
    holi = Set_HOLI_STR(NO_BUSADJUST, 0, NULL) ;
    extr.spec = False ;

    /* Sum of original redemptions */
    for (total_orig = 0.0, i = 0; i < cflw->filled ; i++)
        total_orig += cflw->repay[i] ;

    months = Cflw_MonthsBetweenPayments(pfreq) ;
    period = ((FL64) months) / 12.0 ;
    cflwm  = Alloc_CFLWARRAY(1, cflw->filled) ;

    /* Initialise remaining principal */
    rg_new  = rg_orig = total_orig ;

    /* No. of prepayments */
    prep_no = GetPlanFill(prep) ;

    i = 0;
    ix = 0;

    while ((i < cflw->filled) && (SCecon_fabs(rg_new) > ZERO_TOL))
    {
      /* Copy cash flow date */
      cflwm->days[i] = cflw->days[i] ; 

      /* Move to the first prepayment date after current date */
      while ((ix < prep_no) && 
        (Cldr_DateLT(&prep->day[ix], &cflw->days[i]) == True))
          ix++;

      /* Find prepayment */
      if (ix < prep_no)
      {
        if (Cldr_DateEQ(&prep->day[ix], &cflw->days[i]) == True)
        /* Next prepayment on current date */
        {
          rep = prep->f64[ix] ;
          ix++ ;
        }
        else 
        /* Next prepayment after current date */
        {
          if (ix == 0 || prepayc == PREPAY_ABS) 
            /* Prior to first prepayment date  or absolute prepayments */
            rep = 0 ;
          else
            /* Step function for CPR and APD method */
            rep = prep->f64[ix - 1] ;
        }
      }
      else 
      /* No prepayments after current date */
      {
        if (prep_no == 0 || prepayc == PREPAY_ABS) 
        /* No prepayments or absolute prepayments */
          rep = 0 ;
        else
        /* Step function for CPR and APD method */
          rep = prep->f64[prep_no - 1] ;
      }

      /* Compute extraordinary payment and factor */
      switch (prepayc)
      {
        case PREPAY_ABS: /* Absolute prepayments */
          xtra = rep ;
          fac =  SafeDivide(rg_new - xtra, rg_orig, ZERO_TOL, 0.0) ;
          break ;

        case PREPAY_CPR: /* CPR method */
          spm = 1.0 - pow(1.0 - rep / 100.0, period) ;
          xtra = rg_new * spm ;
          fac =  SafeDivide(rg_new - xtra, rg_orig, ZERO_TOL, 0.0) ;
          break ;

        case PREPAY_APD: /* Amortising difference method */
          xtra = rg_new * rep / 100 ;
          fac =  SafeDivide(rg_new, rg_orig, ZERO_TOL, 0.0) ;
          break ;

        default:
          /* Should never get here.
             Added to avoid warnings.*/
          xtra = 0.0;
          fac = 1.0;
          break;
      }
          
      /* Calculate new amortisation */
      cflwm->repay[i] = GETMIN(xtra + cflw->repay[i] * fac, rg_new) ;

      /* Calculate new coupon */
      cflwm->coupon[i] = period * anncoup * rg_new / 100.0 ;
      ++cflwm->filled ;

      /* Adjust new and old remaining principal */
      rg_new -= cflwm->repay[i] ;
      rg_orig -= cflw->repay[i] ;
            
      i++ ;
    }
    
    /* Renorm flow */
    Cflw_NormCashflow(cflwm->filled, cflwm->coupon, cflwm->repay) ;
    ix = Cldr_FindDateIndex(cflwm->days, cflwm->filled, today, 0,
                             SEARCH_BISECTION, NEXTINDEX) ;
    *exc = *exp = *expd = False ;

    /* Find X-status */
    if (ix < cflwm->filled)
    {
        if (ix > 0)
            prev = cflwm->days[ix - 1] ;
        else
            prev = Cldr_AddMonths(&cflwm->days[0], -months, SAME) ;

        if (cflwm->filled > 0)
            last = cflwm->days[cflwm->filled - 1] ;
        else
            last = Cldr_YMD2Datestr((YYYYMMDD) 0) ;

        *exc = Cflw_XdayCalc(today, &prev, &cflwm->days[ix], &last, excp,
                             &extr, &holi) ;

        /* 'Kreditor publisering' */
        if (SCecon_fabs(cflwm->repay[ix]) > ZERO_TOL)
            *exp = Cflw_XdayCalc(today, &prev, &cflwm->days[ix], &last, expr,
                                 &extr, &holi) ;
        else
            *exp = False ;

        /* 'Debtor publisering' */
        if (SCecon_fabs(cflwm->repay[ix]) > ZERO_TOL)
            *expd = Cflw_XdayCalc(today, &prev, &cflwm->days[ix], &last,
                                  expr_d, &extr, &holi) ;
        else
            *expd = False ;

        /* Handle silly cases appropriately */
        if (*exc == True && SCecon_fabs(cflwm->repay[ix]) > ZERO_TOL)
            *exp = *expd = True ;
    }

    if (cflwm->filled > 0)
        end = cflwm->days[cflwm->filled - 1] ;
    else
        end = *today ;

    xcflw = Cflw_ExtractCflw(today, &end, cflwm, 0, *exc, *exp, False, False,&holi) ;
    /*PMSTA-40263-ARUN-29102020*/

    Free_CFLWARRAY(cflwm, 1) ;

    return xcflw ;
}


/*,,SOH,,
*************************************************************************
*
*               Bond_GenrXtraOrdAmort()
*
*    interface  #include <bond.h>
*               PLANARRAY Bond_GenrXtraOrdAmort(TRADEINFO*  trd,
*                                               FIXPAY*     fixp,
*                                               PLAN_STR    *xredemp) ;
*
*    general    The routine merges a ordinary with an extraordinary
*               cashflow of a bond.
*
*    input      TRADEINFO*   trd         The trade data.
*
*               FIXPAY*      fixp        The bond data.
*                                        NOTE: irregular amortiosations
*                                        in fixp->repay.irreg MUST sum
*                                        to 100.0
*                                        NOTE: payment frequency in
*                                        fixp->cday.pseq.unit MUST be
*                                        MONTHS or YEARS.
*
*               PLAN_STR     *xredemp    The extraordinary cashflow .
*
*    output
*
*    returns    Resulting cashflow. Allocated as
*               Alloc_CFLWARRAY(1, cflw->filled) ;
*
*    diagnostics
*
*    see also   Cflw_MergeXtraOrdCflw()
*               DKmbs_Genr_Cflw()
*               Cflw_Amort2Prepay()
*
*************************************************************************
,,EOH,,*/
PLANARRAY Bond_GenrXtraOrdAmort(TRADEINFO*  trd,
                                   FIXPAY*     fixp,
                                   PLAN_STR*   xredemp)
{
    BOOLE     tmp ;
    HOLI_STR  holi ;
    PMTFREQ   freq ;
    CFLWARRAY cflw, xcflw ;
    PLANARRAY amort ;
    DATEARRAY tdays ;
    FL64ARRAY tf64s ;

    /* Initialise */
    holi = Set_HOLI_STR(NO_BUSADJUST, 0, NULL) ;

    if (fixp->cday.pseq.term == 1 && fixp->cday.pseq.unit == YEARS) 
        freq = ANNUALLY ;
    else 
        freq = Cflw_Months2PmtFreq(fixp->cday.pseq.term) ;

    /* Cenerate bond cflw */
    cflw = Bond_GenrCflw(trd, fixp, &holi) ;

    /* Merge ordinary + extraordinary cflw's */
    xcflw = Cflw_MergeXtraOrdCflw(&trd->settle, cflw, xredemp,
                                  PREPAY_ABS,
                                  fixp->fix.fix_rate, freq,
                                  &fixp->accru.exr, &fixp->exp, 
                                  &fixp->exp, &tmp, &tmp, &tmp) ;

    /* Allocate memory */
    amort = Alloc_PLANARRAY(1, GetCflwFill(xcflw)) ;

    /* Swap the arrays: */
    tdays = GetCflwDays(xcflw);
    tf64s = GetCflwRepay(xcflw);
    xcflw->days = amort->day;
    xcflw->repay = amort->f64;
    amort->filled = GetCflwFill(xcflw) ;
    amort->day = tdays;
    amort->f64 = tf64s;
    
    /* Free... */
    Free_CFLWARRAY(xcflw, 1);
    Free_CFLWARRAY(cflw, 1) ;
    
    return amort;
}

/*,,SOH,,
*************************************************************************
*
*               Cflw_Amort2Prepay()
*
*   interface   #include <bond.h>
*               PLANARRAY Cflw_Amort2Prepay(PLAN_STR*   amort,
*                                           PLAN_STR*   xamort,
*                                           PREPAYCONV  prepayc,
*                                           PMTFREQ     pfreq);
*
*   general     The function finds the implicit extraordinary
*               prepayments given the scheduled and the post-prepayment 
*               amortisation plans.
*
*               The validity of the amortisation plans may be verified by
*               Cflw_CheckAmortsInNewAmorts().
*
*   input       PLAN_STR    *amort    The scheduled amortisation plan.
*                                     
*               PLAN_STR    *xamort   The post-prepayment amortisation
*                                     plan. All dates of xamort have to
*                                     be dates in amort. Dates of
*                                     amort not occuring in xamort
*                                     will be interpreted as the
*                                     zero amortisation in xamort.
*
*               PREPAYCONV  prepayc   Convention for quoting the
*                                     prepayments.
*
*               PMTFREQ     pfreq     The payment frequency in the
*                                     amortisation plans. Only used
*                                     if prepayc = PREPAY_CPR.
*
*   output
*
*   returns     Resulting dates and prepayments corresponding to the
*               normalised amortisations.
*               Last prepayment will always be 0.0.
*               Allocated as Alloc_PLANARRAY(1, GetPlanFill(amort)).
*
*   diagnostics
*
*   See also    Cflw_MergeXtraOrdCflw()
*               Bond_GenrXtraOrdAmort()
*               DKmbs_Genr_Cflw()
*
*************************************************************************
,,EOT,,*/

PLANARRAY Cflw_Amort2Prepay(PLAN_STR*    amort,
                               PLAN_STR*    xamort,
                               PREPAYCONV   prepayc,
                               PMTFREQ      pfreq)
{
  INTI        i, ix, amort_no, xamort_no, months;
  FL64        amort_total, xamort_total, payment, period, xpayment, 
              principal, xprincipal;
  PLANARRAY   prep;

  /* Warning avoidance */
  period = 0.0;

  /* Compute total */
  amort_no = GetPlanFill(amort);
  for (amort_total = 0.0, i = 0; i < amort_no; i++)
    amort_total += amort->f64[i];
  amort_total = (SCecon_fabs(amort_total) < ZERO_TOL ? 100.0 : 
    amort_total);

  /* Compute post-prepayment total */
  xamort_no = GetPlanFill(xamort);
  for (xamort_total = 0.0, ix = 0; ix < xamort_no; ix++)
    xamort_total += xamort->f64[ix];
  xamort_total = (SCecon_fabs(xamort_total) < ZERO_TOL ? 100.0 : 
    xamort_total);

  /* Compute period length */
  if (prepayc == PREPAY_CPR)
  {
    months = Cflw_MonthsBetweenPayments(pfreq);
    months = (months < 1 ? 12 : months);
    period = 12.0 / ((FL64) months); 
  }

  /* Initialize principal */
  principal = xprincipal = 100.0;
  
  prep = Alloc_PLANARRAY(1, amort_no);

  for (i = 0, ix = 0; i < amort_no; i++)
  {
    /* Copy amortisation date */
    prep->day[i] = amort->day[i];

    /* Scheduled payment */
    payment = amort->f64[i] / amort_total * 100.0; 

    /* Ignore post-prepayment dates before current date */
    while ((ix < xamort_no) &&
      Cldr_DateLT(&xamort->day[ix], &amort->day[i]) == True)
      ix++;

    /* Find post-prepayment payment */
    if ((ix < xamort_no) &&
      (Cldr_DateEQ(&xamort->day[ix], &amort->day[i]) == True))
    /* Next payment on current date */
    {
      xpayment = xamort->f64[ix] / xamort_total * 100.0;
      ix++;
    }
    else 
    /* Next payment after current date or no payments left */
      xpayment = 0.0;

    /* Compute prepayment */
    switch (prepayc)
    {
      case PREPAY_ABS: /* Absolute prepayments */
        prep->f64[i] =  xpayment - payment * 
          SafeDivide(xprincipal - xpayment, principal - payment, 
          ZERO_TOL, 0.0) ;
        break ;

      case PREPAY_CPR: /* CPR method */
        prep->f64[i] =  SafeDivide(principal * (xprincipal - 
          xpayment), xprincipal * (principal - payment), 
          ZERO_TOL, 1.0);
        prep->f64[i] =   100.0 * (1.0 - pow(prep->f64[i], period)) ;
        break ;

      case PREPAY_APD: /* Amortising difference method */
        prep->f64[i] =  100.0 * (SafeDivide(xpayment, xprincipal, 
          ZERO_TOL, 0.0) - SafeDivide(payment, principal, 
          ZERO_TOL, 0.0));
        break ;
    }

    /* Last payment */
    if (i == (amort_no - 1))  
      prep->f64[i] = 0.0;
          
    ++prep->filled;

   /* Adjust new and old remaining principal */
    principal -= payment;
    xprincipal -= xpayment;
  }
    
  return prep;
}



/*,,SOH,,
*************************************************************************
*
*               Cflw_CheckAmortsInNewAmorts()
*
*   interface   #include <bond.h>
*               BOOLE Cflw_CheckAmortsInNewAmorts(PLAN_STR*   amort,
*                                           PLAN_STR*   newamort);
*
*   general     The function checks that one amortisation schedule
*               arises from another by allowing only positive
*               prepayments on the ordinary amortisation dates.
*               This function is relavent when using Cflw_Amort2Prepay()
*
*   input       PLAN_STR  *amort      The scheduled amortisation plan.
*                                     NULL is allowed as input.
*                                     
*               PLAN_STR  *newamort   The post-prepayment amortisation.
*                                     NULL is allowed as input.
*
*   output
*
*   returns     True if it is possible to arrive at 'newamort' 
*               from 'amort' with positive prepayments on the
*               dates in 'amort'. Returns False if this is not the
*               case or if either schedule is empty or NULL.
*
*   diagnostics
*
*   See also    Cflw_Amort2Prepay()
*
*************************************************************************
,,EOT,,*/

BOOLE Cflw_CheckAmortsInNewAmorts(PLAN_STR*  amort,
                                    PLAN_STR*  newamort)
{
  BOOLE stop = False;
  COUNT i_a, i_p;
  COUNT n_a, n_p;
  FL64 sum_a, sum_p;
  INTI ix;

  n_a = GetPlanFill(newamort);
  n_p = GetPlanFill(amort);
  if (n_a * n_p == 0 || n_a > n_p)
    stop = True;

  i_a = i_p = 0;
  sum_a = sum_p = 0.0;
  while (!stop && i_a < n_a && i_p < n_p)
  {
    if (Cldr_DateEQ(&newamort->day[i_a], &amort->day[i_p]))
      ix = 0;
    else if  (Cldr_DateLT(&newamort->day[i_a], &amort->day[i_p]))
      ix = 1;
    else
      ix = -1;

    if (ix == 1)
      stop = True;

    if (ix != -1)
      sum_a += newamort->f64[i_a++];
    if (ix != 1)
      sum_p += amort->f64[i_p++];

    if (sum_p - sum_a > 1e-6)
      stop = True;
  }


  if (stop || (i_a < n_a && i_p == n_p))
    return False;
  else
    return True;
}


/* SCID @(#)cflwaloc.c	1.6 (SimCorp) 99/10/27 13:58:36 */

/************************************************************************
*
*    project    SCecon
*
*    filename   pmtalloc.c
*
*    general    allocating routines for the cflw module of SCecon
*
************************************************************************/

#include <stdlib.h>
#include <cflw.h>


/*,,SOH,,
***************************************************************************
*
*                Alloc_CFLWARRAY()
*
*    interface   #include <cflw.h>
*                CFLWARRAY Alloc_CFLWARRAY(INTI ns,
*                                          INTI np) ;
*
*    general     Allocates memory for an array that can hold information
*                about ns cashflow structures.
*                Returns memory with zero'ed entries.
*
*    input       INTI  ns     Number of structures.
*
*                INTI  np     Number of days, repay and coupons
*                             per CFLW_STR.
*
*    output
*
*    returns     reference to allocated CFLW_STR array.
*
*    diagnostics aborts calling SCecon_error()
*                with the message   "Allocation failure"
*                         routine   "Alloc_CFLWARRAY"
*                         actioncode SCECONABORT
*                if allocation fails.
*
*    see also    Free_CFLWARRAY()
*
***************************************************************************
,,EOH,,*/


CFLWARRAY Alloc_CFLWARRAY(INTI ns, INTI  np)
{
    CFLWARRAY a ;
    INTI      i ;

    a = (CFLWARRAY) SCecon_calloc(ns, sizeof(CFLW_STR), True, 
      "Alloc_CFLWARRAY()") ;

    for (i = 0 ; i < ns ; i++)
    {
        a[i].count  = np ;
        a[i].days   = Alloc_DATEARRAY(np) ;
        a[i].repay  = Alloc_FL64ARRAY(np) ;
        a[i].coupon = Alloc_FL64ARRAY(np) ;
        a[i].ratesTab = Alloc_FL64ARRAY(np) ; /* PMSTA10118 - DDV - 100623 */

    }

    return a ;
}


/*,,SOH,,
***************************************************************************
*
*                Free_CFLWARRAY()
*
*    interface   #include <cflw.h>
*                void Free_CFLWARRAY(CFLWARRAY s,
*                                    INTI      ns) ;
*
*    general     Frees memory for a given number of CFLWARRAYS's allocated*
*                by Alloc_CFLWARRAY().
*
*    input       CFLWARRAY s  The structs already allocated.
*
*                INTI      ns Number of structs in s.
*
*    output
*
*    returns
*
*    diagnostics
*
*    see also    Alloc_CFLWARRAY()
*
***************************************************************************
,,EOH,,*/


void Free_CFLWARRAY(CFLWARRAY s, INTI ns)
{
    INTI  i ;

    if (!s)
        return ;

    ns  = GETMAX(1, ns) ;

    for (i = 0 ; i < ns ; i++)
    {
        Free_DATEARRAY(s[i].days) ;
        Free_FL64ARRAY(s[i].repay) ;
        Free_FL64ARRAY(s[i].coupon) ;
        Free_FL64ARRAY(s[i].ratesTab) ;  /* PMSTA10118 - DDV - 100623 */
    }
 
    SCecon_free((VOIDPTR) s) ;
}


/*,,SOH,,
*************************************************************************
*
*               Free_EXRULE()
*
*    interface  #include <cflw.h>
*               void Free_EXRULE(EXRULE *ex) ;
*
*    general    Free_EXRULE() frees memory for a EXRULE. All the memory
*               is suballocated in the ex structure.
*
*    input      EXRULE     *ex       The ex coup container
*
*    output
*
*    returns
*
*    diagnostics
*
*    see also
*
*************************************************************************
,,EOH,,*/

void Free_EXRULE(EXRULE *ex)
{
  Free_DATEARRAY(ex->pday) ;
  Free_DATEARRAY(ex->xpday) ;
}

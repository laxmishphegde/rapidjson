/* SCID @(#)rposeqty.c	1.5 (SimCorp) 99/02/19 14:14:48  */

/************************************************************************
*
*       Project         SCecon
*
*       file name       rposeqty.c
*
*       contains        risk position calculations
*
************************************************************************/

/*** includes **********************************************************/
#include <opteqty.h>
#include <futeqty.h>
#include <riskpos.h>


/*** defines  **********************************************************/
#define DISC_TOLR  (FL64)    0.00000001
#define DIV_TOL    (FL64)    0.00000001


/*,,SOH,,
*************************************************************************
*
*               FutEqty_CC2RiskPos()
*
*   interface   #include <opteqty.h>
*               RISKPOSLIST FutEqty_CC2RiskPos(DATESTR   *analys,
*                                               FUTEQTY   *fute,
*                                               DATESTR   *spotdate,
*                                               FL64      spot,
*                                               FL64      num,
*                                               FL64      beta,
*                                               FL64      divyld,
*                                               RISKTOKEN *EqtyIxToken,
*                                               DISCFAC   *df,
*                                               HOLI_STR  *holi,
*                                               DELTASET  *ds,
*                                               FXRISKSET *FXr) ;
*
*   general     The routine calculates the Risk Position for
*               an future equity using a list of predefined shocks
*               to the zero curve.
*
*               The Risk Position is the core input for VAR calculation.*
*               The Risk Position calculated for this position must be
*               added to the total Risk Position. Once this total Risk
*               Position is available VAR can be calculated with the
*               routine VAR_MATRIX2VAR().
*
*               The decision whether to use price or yield vol is
*               signalled in ds->zero. Note that this must be the same
*               for all risk factors encountered in the total VAR
*               calculation.
*
*               The risk factors affecting a future equity are:
*
*                   Equity indicies
*                   Interest Rates (Government and Money Market)
*                   FX (if Instrument CCY differs from Home CCY)
*
*               These entries are found in the returned RISKPOSLIST
*
*   input       DATESTR   *analys       The analysis date.
*
*               FUTEQTY   *fute         The equity future data.
*
*               DATESTR   *spotdate     The date for the market value
*                                       of the future.
*
*               FL64      spot          The equity spot price per unit
*
*               FL64      num           Number of units
*
*               FL64      beta          Beta relative to Equity Index.
*
*               FL64      divyld        The dividend yield as a
*                                       CONTINUOUS rate (%).
*
*               RISKTOKEN *EqtyIxToken  Risk factor definition of
*                                       Equity Index
*
*               DISCFAC   *df           Discounting structure setup.
*                                       The initial (unshocked) curve
*                                       should be in df->disc.
*
*               HOLI_STR  *holi         Business adjustment setup
*
*               DELTASET  *ds           Delta vector defining data
*                                       Set with Disc_DeltaPrep()
*
*               FXRISKSET *FXr          Data for FX risk generation
*
*   output
*
*   returns     The Risk Position allocated as:
*
*                         Alloc_RISKTOKENARRAY(ds->nshock + 2) ;
*                         Alloc_FL64ARRAY(ds->nshock + 2) ;
*
*   diagnostics
*
*   see also    Disc_DeltaPrep()
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/

RISKPOSLIST FutEqty_CC2RiskPos(DATESTR* analys,
                                FUTEQTY*   fute,
                                DATESTR*   spotdate,
                                FL64      spot,
                                FL64      num,
                                FL64      beta,
                                FL64      divyld,    
                                RISKTOKEN* EqtyIxToken,
                                DISCFAC*   df,
                                HOLI_STR*  holi,
                                DELTASET*  ds,
                                FXRISKSET* FXr)
{
    RISKPOSLIST  rpos ;
    FL64ARRAY    dv ;
    FL64         FX, pv, dum, fac, pct, fwd, dsc ;
    INTI         allocsize, i ;
    DATESTR      matur ;

    /* Initialise */
    FX = (!SCecon_strncmp(FXr->token.ccy, FXr->home, CCY_LENGTH) ? 
            1.0 : FXr->rate) ;

    /* Allocate output */
    allocsize  = rpos.npos = ds->nshock + 2 ;
    rpos.token = Alloc_RISKTOKENARRAY(allocsize) ;
    rpos.pos   = Alloc_FL64ARRAY(allocsize) ;

    /* Generate delta vector */
    dv = FutEqty_CC2Delta(analys, spotdate, spot, fute, divyld, df, holi, ds) ;

    /* dv wrt zeros has already been pct adjusted */
    pct = 1.0 ;

    /* Translate to Risk Position */
    for (i = 0; i < ds->nshock; i++)
    {
        /* Find adjustment factor */
        fac = Disc_DF2RiskPosFac(analys, df, ds, i, holi) ;   /* PMSTA-22396 - SRIDHARA � 160502 */

        /* Do the calculation */
        rpos.pos[i]   = dv[i] * fac * FX * num / pct ;
        VAR_RiskTokenCpy(&rpos.token[i], &ds->token[i]) ;
    }

    /* Eqty Index contribution */
    VAR_RiskTokenCpy(&rpos.token[ds->nshock], EqtyIxToken) ;
    fwd = FutEqty_CC2Price(spotdate, spot, fute, divyld, df, holi) ;
    /* Deal with margining  */ 
    if (fute->margin == False)
    {
        matur = Cldr_NextBusinessDate(&fute->matur, holi) ;
		/* PMSTA-22396 - SRIDHARA � 160502 */
        dsc = Disc_Interpolation(&matur, df, holi) ;
        Disc_forwval(df, analys, &dsc, holi) ;
    }
    else
        dsc = 1.0 ;

    rpos.pos[ds->nshock] = fwd * FX * dsc * beta * num / pct ;

    /* FX risk contribution - if required */
    VAR_RiskTokenCpy(&rpos.token[ds->nshock + 1], &FXr->token) ;

    if (!SCecon_strncmp(FXr->token.ccy, FXr->home, CCY_LENGTH) == False)
    {
        /* PV in pct in Home CCY */
        pv   = FutEqty_CC2NPV(analys, spotdate, spot, fute, divyld, df, holi, 
                              NULL, &dum, &dum) ;

        /* Remember FX contribution - PV in Home CCY */
        rpos.pos[ds->nshock + 1] = pv * FX * num / pct ;
    }
    else
        rpos.pos[ds->nshock + 1] = 0.0 ;

    /* Clean up */
    Free_FL64ARRAY(dv) ;

    return rpos ;
}


/*,,SOH,,
*************************************************************************
*
*               Eqty_VAR2RiskPos()
*
*   interface   #include <opteqty.h>
*               RISKPOSLIST Eqty_VAR2RiskPos(FL64       spot,
*                                            FL64       num,
*                                            FL64       beta,
*                                            RISKTOKEN  *EqtyIxToken,
*                                            FXRISKSET  *FXr) ;
*
*   general     The routine calculates the Risk Position for an equity.
*
*               The Risk Position is the core input for VAR calculation.*
*               The Risk Position calculated for this position must be
*               added to the total Risk Position. Once this total Risk
*               Position is available VAR can be calculated with the
*               routine VAR_MATRIX2VAR().
*
*               The risk factors affecting a equity are:
*
*                   Equity indicies and
*                   FX (if Instrument CCY differs from Home CCY)
*
*               These entries are found in the returned RISKPOSLIST
*
*   input       FL64      spot          The equity spot price per unit
*
*               FL64      num           Number of units
*
*               FL64      beta          Beta relative to Equity Index
*
*               RISKTOKEN *EqtyIxToken  Risk factor definition of
*                                       Equity Index
*
*               FXRISKSET *FXr          Data for FX risk generation
*
*   output
*
*   returns     The Risk Position allocated as:
*
*                         Alloc_RISKTOKENARRAY(2) ;
*                         Alloc_FL64ARRAY(2) ;
*
*   diagnostics
*
*   see also
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/


RISKPOSLIST Eqty_VAR2RiskPos(FL64   spot,       
                             FL64      num,     
                             FL64      beta,     
                             RISKTOKEN* EqtyIxToken,
                             FXRISKSET* FXr)
{
    FL64         FX ;
    RISKPOSLIST  rpos ;

    /* Initialise */
    FX = (!SCecon_strncmp(FXr->token.ccy, FXr->home, CCY_LENGTH) ? 
            1.0 : FXr->rate) ;

    /* Allocate output */
    rpos.npos  = 2 ;
    rpos.token = Alloc_RISKTOKENARRAY(rpos.npos) ;
    rpos.pos   = Alloc_FL64ARRAY(rpos.npos) ;

    /* Translate to Risk Position */
    rpos.pos[0]   = spot * num * beta * FX ;
    VAR_RiskTokenCpy(&rpos.token[0], EqtyIxToken) ;

    /* FX risk contribution - if required */
    VAR_RiskTokenCpy(&rpos.token[1], &FXr->token) ;

    if (!SCecon_strncmp(FXr->token.ccy, FXr->home, CCY_LENGTH) == False)
        /* Remember FX contribution - MV in Home CCY */
        rpos.pos[1] = spot * num * FX ;
    else
        rpos.pos[1] = 0.0 ;

    return rpos ;
}



/*,,SOH,,
*************************************************************************
*
*               OptEqty_Black2RiskPos()
*
*   interface   #include <opteqty.h>
*               RISKPOSLIST OptEqty_Black2RiskPos(DATESTR *analys,
*                                               OPTFUT    *opt,
*                                               FUTEQTY   *fute,
*                                               FL64      spot,
*                                               FL64      Notnal,
*                                               FL64      beta,
*                                               DATESTR   *voldate,
*                                               FL64      vol,
*                                               FL64      divyld,
*                                               RISKTOKEN *EqtyIxToken,
*                                               DISCFAC   *df,
*                                               HOLI_STR  *holi,
*                                               DELTASET  *ds,
*                                               FXRISKSET *FXr) ;
*
*   general     The routine calculates the Risk Position for an (OTC)
*               option on a equity using a list of predefined shocks to
*               the zero curve.
*
*               The Risk Position is the core input for VAR calculation.*
*               The Risk Position calculated for this position must be
*               added to the total Risk Position. Once this total Risk
*               Position is available VAR can be calculated with the
*               routine VAR_MATRIX2VAR().
*
*               The decision whether to use price or yield vol is
*               signalled in ds->zero. Note that this must be the same
*               for all risk factors encountered in the total VAR
*               calculation.
*
*               The risk factors affecting a fixed cashflow are:
*
*                   Equity indicies
*                   Interest Rates (Government, Swap or Money Market)
*                   FX (if Instrument CCY differs from Home CCY)
*
*               These entries are found in the returned RISKPOSLIST
*
*   input       DATESTR   *analys       The analysis date.
*
*               OPTFUT    *opt          The data defining the option.
*                                       ->oadd assumed as NO_OPTADD.
*
*               FUTEQTY  *fute          Equity data.
*
*               FL64      spot          The eqty spot price.
*                                       Must not be preADJUSTED for
*                                       dividends at entry.
*
*               FL64      Notnal        The notional holding (position)
*                                       Amount in Instrument CCY.
*
*               FL64      beta          Beta relative to Equity Index.
*
*               DATESTR   *voldate      Vol calculated from this date.
*
*               FL64      vol           The annual volatility of the
*                                       spot price in percent.
*
*               FL64      divyld        Dividend yield.
*                                       (continuous rate in %).
*
*               RISKTOKEN *EqtyIxToken  Risk factor definition of
*                                       Equity Index.
*
*               DISCFAC   *df           Discounting structure setup.
*                                       The initial (unshocked) curve
*                                       should be in df->disc.
*
*               HOLI_STR  *holi         Business day adjustment setup.
*
*               DELTASET  *ds           Delta vector defining data
*                                       Set with Disc_DeltaPrep().
*
*               FXRISKSET *FXr          Data for FX risk generation.
*
*   output
*
*   returns     The Risk Position allocated as:
*
*                         Alloc_RISKTOKENARRAY(ds->nshock + 2) ;
*                         Alloc_FL64ARRAY(ds->nshock + 2) ;
*
*   diagnostics
*
*   see also    Disc_DeltaPrep()
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/


RISKPOSLIST OptEqty_Black2RiskPos(DATESTR* analys,
                                  OPTFUT*    opt,
                                  FUTEQTY*   fute,
                                  FL64      spot,
                                  FL64      Notnal,
                                  FL64      beta,
                                  DATESTR*   voldate,
                                  FL64      vol,
                                  FL64      divyld,    
                                  RISKTOKEN* EqtyIxToken,
                                  DISCFAC*   df,
                                  HOLI_STR*  holi,
                                  DELTASET*  ds,
                                  FXRISKSET* FXr)
{
    RISKPOSLIST  rpos ;
    FL64ARRAY    dv ;
    FL64         FX, p, dum, fac, pct, delta ;
    INTI         allocsize, i ;
    RISKSET      risk ;

    /* Initialise */
    FX = (!SCecon_strncmp(FXr->token.ccy, FXr->home, CCY_LENGTH) ? 
            1.0 : FXr->rate) ;

    /* Allocate output */
    allocsize  = rpos.npos = ds->nshock + 2 ;
    rpos.token = Alloc_RISKTOKENARRAY(allocsize) ;
    rpos.pos   = Alloc_FL64ARRAY(allocsize) ;

    /* Generate delta vector */
    dv = OptEqty_Black2Delta(analys, voldate, spot, vol, divyld, fute, opt, df,
                             holi, ds) ;

    /* dv wrt zeros has already been pct adjusted */
    pct = 1.0 ;

    /* Translate to Risk Position */
    for (i = 0; i < ds->nshock; i++)
    {
        /* Find adjustment factor */
        fac = Disc_DF2RiskPosFac(analys, df, ds, i, holi) ;   /* PMSTA-22396 - SRIDHARA � 160502 */

        /* Do the calculation */
        rpos.pos[i]   = dv[i] * fac * FX * Notnal / pct ;
        VAR_RiskTokenCpy(&rpos.token[i], &ds->token[i]) ;
    }

    /* Eqty Index contribution */
    VAR_RiskTokenCpy(&rpos.token[ds->nshock], EqtyIxToken) ;
    risk = Set_RISKSET(KEY_SPOT, FIRST_ORDER, 0.01, ds->irr,
                       ds->freq, NULL, True) ;
    p    = OptEqty_Black2P(analys, voldate, spot, vol, divyld, fute, 
                           opt, df, holi, &risk, &delta, &dum) ;
    rpos.pos[ds->nshock] = delta * spot * beta * FX * Notnal / pct ;
                                         
    /* FX risk contribution - if required */
    VAR_RiskTokenCpy(&rpos.token[ds->nshock + 1], &FXr->token) ;

    if (!SCecon_strncmp(FXr->token.ccy, FXr->home, CCY_LENGTH) == False)
        /* Remember FX contribution - PV in Home CCY */
        rpos.pos[ds->nshock + 1] = p * FX * Notnal / pct ;
    else
        rpos.pos[ds->nshock + 1] = 0.0 ;

    /* Clean up */
    Free_FL64ARRAY(dv) ;

    return rpos ;
}


/*,,SOH,,
*************************************************************************
*
*               OptFutEqty_Black2RiskPos()
*
*   interface   #include <opteqty.h>
*               RISKPOSLIST OptFutEqty_Black2RiskPos(DATESTR   *analys,
*                                               OPTFUT    *opt,
*                                               FUTEQTY   *fute,
*                                               FL64      futp,
*                                               FL64      Notnal,
*                                               FL64      beta,
*                                               DATESTR   *voldate,
*                                               FL64      vol,
*                                               FL64      divyld,
*                                               RISKTOKEN *EqtyIxToken,
*                                               DISCFAC   *df,
*                                               HOLI_STR  *holi,
*                                               DELTASET  *ds,
*                                               FXRISKSET *FXr) ;
*
*   general     The routine calculates the Risk Position for an (OTC)
*               option on a equity future using a list of predefined
*               shocks to the zero curve.
*
*               The Risk Position is the core input for VAR calculation.*
*               The Risk Position calculated for this position must be
*               added to the total Risk Position. Once this total Risk
*               Position is available VAR can be calculated with the
*               routine VAR_MATRIX2VAR().
*
*               The decision whether to use price or yield vol is
*               signalled in ds->zero. Note that this must be the same
*               for all risk factors encountered in the total VAR
*               calculation.
*
*               The risk factors affecting a fixed cashflow are:
*
*                   Equity indicies
*                   Interest Rates (Government, Swap or Money Market)
*                   FX (if Instrument CCY differs from Home CCY)
*
*               These entries are found in the returned RISKPOSLIST
*
*   input       DATESTR   *analys       The analysis date.
*
*               OPTFUT    *opt          The data defining the option.
*                                       ->oadd assumed as NO_OPTADD.
*
*               FUTEQTY  *fute          Equity data.
*
*               FL64      futp          The future price in percent.
*
*               FL64      Notnal        The notional holding (position)
*                                       Amount in Instrument CCY.
*
*               FL64      beta          Beta relative to Equity Index.
*
*               DATESTR   *voldate      Vol calculated from this date.
*
*               FL64      vol           The annual volatility of the
*                                       spot price in percent.
*
*               FL64      divyld        Dividend yield.
*                                       (continuous rate in %).
*
*               RISKTOKEN *EqtyIxToken  Risk factor definition of
*                                       Equity Index.
*
*               DISCFAC   *df           Discounting structure setup.
*                                       The initial (unshocked) curve
*                                       should be in df->disc.
*
*               HOLI_STR  *holi         Business day adjustment setup.
*
*               DELTASET  *ds           Delta vector defining data
*                                       Set with Disc_DeltaPrep().
*
*               FXRISKSET *FXr          Data for FX risk generation.
*
*   output
*
*   returns     The Risk Position allocated as:
*
*                         Alloc_RISKTOKENARRAY(ds->nshock + 2) ;
*                         Alloc_FL64ARRAY(ds->nshock + 2) ;
*
*   diagnostics
*
*   see also    Disc_DeltaPrep()
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/


RISKPOSLIST OptFutEqty_Black2RiskPos(DATESTR* analys,
                                     OPTFUT*    opt,
                                     FUTEQTY*   fute,
                                     FL64      futp,
                                     FL64      Notnal,
                                     FL64      beta,
                                     DATESTR*   voldate,
                                     FL64      vol,
                                     FL64      divyld,
                                     RISKTOKEN* EqtyIxToken,
                                     DISCFAC*   df,
                                     HOLI_STR*  holi,
                                     DELTASET*  ds,
                                     FXRISKSET* FXr)
{
    FL64        spot ;
    BOOLE       ok ;
    ITERCTRL    ictrl ;
    RISKPOSLIST rpos ;

    /* Calculate implicit spot */
    Init_ITERCTRL(&ictrl) ;
    ok   = FutEqty_CC2Impl(analys, 0.0, futp, fute, divyld, df, holi, 
                           KEY_SPOT, &ictrl, &spot) ;

    /* NOTE: Calculations of implicit spot can never result in ok == False */

    /* Calculate risk position */
    rpos = OptEqty_Black2RiskPos(analys, opt, fute, spot, Notnal, beta,
                                 voldate, vol, divyld, EqtyIxToken,
                                 df, holi, ds, FXr) ;
    return rpos ;
}


/*,,SOH,,
*************************************************************************
*
*               OptEqty_CRR2RiskPos()
*
*    interface  #include <opteqty.h>
*               RISKPOSLIST OptEqty_CRR2RiskPos(DATESTR    *analys,
*                                               FL64       spot,
*                                               FL64       vol,
*                                               INTI       nstep,
*                                               DISCFAC    *divdf,
*                                               FUTEQTY    *fute,
*                                               TREEOPT    *opt,
*                                               FL64       Notnal,
*                                               FL64       beta,
*                                               RISKTOKEN *EqtyIxToken,
*                                               DISCFAC    *df,
*                                               HOLI_STR   *holi,
*                                               DELTASET   *ds,
*                                               FXRISKSET  *FXr,
*                                               BOOLE      *ok) ;
*
*    general    The routine calculates the risk position for an
*               EU/US-Style option on Equity (stock or stock index)
*               using the Cox-Ross-Rubinstein binomial approach and a
*               list of predefined shocks to the zero curve.
*
*               Dividends may be entered in two ways:
*
*                i)  as a PLAN_STR of discrete amounts
*                ii) as a DISCFAC
*
*               The Risk Position is the core input for VAR calculation.*
*               The Risk Position calculated for this position must be
*               added to the total Risk Position. Once this total Risk
*               Position is available VAR can be calculated with the
*               routine VAR_MATRIX2VAR().
*
*               The decision whether to use price or yield vol is
*               signalled in ds->zero. Note that this must be the same
*               for all risk factors encountered in the total VAR
*               calculation.
*
*               The risk factors affecting Equity Options are:
*
*                   Interest Rates (Government, Swap or Money Market)
*                   FX (if Instrument CCY differs from Home CCY)
*
*               These entries are found in the returned RISKPOSLIST
*
*               If something goes wrong during the calculation then
*               False is returned.
*
*    input      DATESTR    *analys  Pointer to analysis date (NPV date)
*
*               FL64       spot     The unadjusted spot price
*
*               FL64       vol      The annual volatility of the Spot
*                                   price in percent.
*
*               INTI       nstep    Number of steps in the Binomial Tree*
*
*               DISCFAC    *divdf   Term structure of dividend yields
*
*               FUTEQTY    *fute    Equity data
*
*               TREEOPT    *opt     The data defining the option.
*                                   opt->berm assumed as False.
*
*               FL64       Notnal   The notional holding (position).
*                                   Amount in Instrument CCY.
*
*               FL64       beta     Beta relative to Equity Index.
*
*               RISKTOKEN *EqtyIxToken  Risk factor definition of
*                                       Equity Index.
*
*               DISCFAC   *df        Discount function for discounting
*                                    the option payout.
*
*               HOLI_STR  *holi      Holiday setup.
*
*               DELTASET  *ds        Data for delta calculation.
*
*               FXRISKSET *FXr       Data for FX risk generation.
*
*    output     BOOLE     *ok        True if all ok, False if not.
*
*   returns     The Risk Position allocated as:
*
*                         Alloc_RISKTOKENARRAY(ds->nshock + 1) ;
*                         Alloc_FL64ARRAY(ds->nshock + 1) ;
*
*   diagnostics
*
*   see also    Disc_DeltaPrep()
*
*************************************************************************
,,EOH,,*/

RISKPOSLIST OptEqty_CRR2RiskPos(DATESTR*      analys,
                                    FL64          spot,
                                    FL64          vol,
                                    INTI          nstep,
                                    DISCFAC*      divdf,
                                    FUTEQTY*      fute,
                                    TREEOPT*      opt,
                                    FL64          Notnal,
                                    FL64          beta,
                                    RISKTOKEN*    EqtyIxToken,
                                    DISCFAC*      df,
                                    HOLI_STR*     holi,
                                    DELTASET*     ds,
                                    FXRISKSET*    FXr,
                                    BOOLE*        ok)
{ 
    RISKPOSLIST  rpos ;
    FL64ARRAY    dv ;
    FL64         FX, pv, dum, fac, pct, delta ;
    INTI         allocsize, i ;
    RISKSET      risk ;

    /* Initialise */
    *ok = True ;
    FX = (!SCecon_strncmp(FXr->token.ccy, FXr->home, CCY_LENGTH) ? 
            1.0 : FXr->rate) ;

    /* Allocate output */
    allocsize  = rpos.npos = ds->nshock + 2 ;
    rpos.token = Alloc_RISKTOKENARRAY(allocsize) ;
    rpos.pos   = Alloc_FL64ARRAY(allocsize) ;

    /* Generate delta vector */
    dv = OptEqty_CRR2Delta(analys, spot, vol, nstep, divdf, fute, opt, df, 
                           holi, ds, ok) ;

    /* dv wrt zeros has already been pct adjusted */
    pct = 1.0 ;

    /* Translate to Risk Position */
    for (i = 0; i < ds->nshock; i++)
    {
        /* Find adjustment factor */
        fac = Disc_DF2RiskPosFac(analys, df, ds, i, holi) ;    /* PMSTA-22396 - SRIDHARA � 160502 */

        /* Do the calculation */
        rpos.pos[i]   = dv[i] * fac * FX * Notnal / pct ;
        VAR_RiskTokenCpy(&rpos.token[i], &ds->token[i]) ;
    }

    /* Eqty Index contribution */
    VAR_RiskTokenCpy(&rpos.token[ds->nshock], EqtyIxToken) ;
    risk = Set_RISKSET(KEY_PRICE, FIRST_ORDER, 0.01, ds->irr,
                       ds->freq, NULL, True) ;
    *ok  = OptEqty_CRR2P(analys, spot, vol, nstep, divdf, fute, opt, df,
                         holi, &risk, &pv, &delta, &dum) ;
    rpos.pos[ds->nshock] = delta * spot * beta * FX * Notnal / pct ;

    /* FX risk contribution - if required */
    VAR_RiskTokenCpy(&rpos.token[ds->nshock + 1], &FXr->token) ;

    if (!SCecon_strncmp(FXr->token.ccy, FXr->home, CCY_LENGTH) == False)
        /* Remember FX contribution - PV in Home CCY */
        rpos.pos[ds->nshock + 1] = pv * Notnal * FX / pct ;
    else
        rpos.pos[ds->nshock + 1] = 0.0 ;

    /* Clean up */
    Free_FL64ARRAY(dv) ;

    return rpos ;
}



/*,,SOH,,
*************************************************************************
*
*               FutFX_DF2RiskPos()
*
*    interface  #include <opteqty.h>
*               RISKPOSLIST FutFX_DF2RiskPos(DATESTR       *analys,
*                                            FXFORW        *fxfw,
*                                            FL64          Notnal,
*                                            DISCFAC       *df_p,
*                                            DISCFAC       *df_r,
*                                            HOLI_STR      *holi,
*                                            DELTASET      *ds_p,
*                                            DELTASET      *ds_r,
*                                            FXRISKSET     *FX_p,
*                                            FXRISKSET     *FX_r) ;
*
*    general    This routine calculates the risk position of a FX
*               forward contract using a list of predefined shocks to
*               the zero coupon curves.
*
*               The Risk Position is the core input for VAR calculation.*
*               The Risk Position calculated for this position must be
*               added to the total Risk Position. Once this total Risk
*               Position is available VAR can be calculated with the
*               routine VAR_MATRIX2VAR().
*
*               The decision whether to use price or yield vol is
*               signalled in ds_p->zero and ds_r->zero. Note that this
*               must be the same for all risk factors encountered in
*               the total VAR calculation.
*
*               The risk factors affecting an FX forward contract are:
*
*                   Interest Rates (Government, Swap or Money Market)
*                   FX (if paid CCY and/or received CCY differs from
*                       Home CCY)
*
*               These entries are found in the returned RISKPOSLIST
*
*    input      DATESTR  *analys  Pointer to analysis date (NPV date)
*
*               FXFORW   *fxfw    FX Forward data.
*
*               FL64     Notnal   The notional holding (position).
*                                 Amount in received CCY.
*
*               DISCFAC  *df_p    Discount function for paid currency
*
*               DISCFAC  *df_r    Discount function for received
*                                 currency
*
*               HOLI_STR *holi    Holiday setup.
*
*               DELTASET *ds_p    Data for delta calculation in paid
*                                 currency.
*
*               DELTASET  *ds_r   Data for delta calculation in
*                                 received currency.
*
*               FXRISKSET *FX_p   Data for FX risk generation.
*                                 FX_p->rate is the spot FX rate
*                                 in Home CCY units per paid CCY unit
*                                 in base 1.
*
*               FXRISKSET *FX_r   Data for FX risk generation.
*                                 FX_r->rate is the spot FX rate
*                                 in Home CCY units per received CCY
*                                 unit in base 1.
*
*   output
*
*   returns     The Risk Position allocated as:
*
*                   Alloc_FL64ARRAY(ds_p->nshock + ds_r->nshock) ;
*                   Alloc_RISKTOKENARRAY(ds_p->nshock + ds_r->nshock) ;
*
*   diagnostics
*
*   see also    Disc_DeltaPrep()
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/

RISKPOSLIST FutFX_DF2RiskPos(DATESTR*      analys,
                                 FXFORW*       fxfw,
                                 FL64          Notnal,
                                 DISCFAC*      df_p,
                                 DISCFAC*      df_r,
                                 HOLI_STR*     holi,
                                 DELTASET*     ds_p,
                                 DELTASET*     ds_r,
                                 FXRISKSET*    FX_p,
                                 FXRISKSET*    FX_r)
{
    TRADEINFO    trd ;
    FIXPAY       pay, rcv ;
    FL64         not_p, not_r, fx_forw ;
    RISKPOSLIST  rpos_p, rpos_r, rpos ;

    /* Initialise */
    trd = bond_set_tradeinfo(analys) ;
        
    /* Initialise two zero bonds */
    pay = Bond_Zero2FIXPAY(&fxfw->matur) ;
    rcv = Bond_Zero2FIXPAY(&fxfw->matur) ;

    /* Adjust for base */
    fx_forw = SafeDivide(fxfw->fwd, fxfw->base, 0.0000001, 1.0) ;

    /* Inverse quoted ? */
    if (fxfw->inv == True)
        fx_forw = SafeDivide(1.0, fx_forw, 0.0000001, 1.0) ;

    not_p = -1.0 * fx_forw * Notnal ;
    not_r = Notnal ;
    
    /* Risk Postions for paid leg */
    /* .margin -> matur -> analys ???? */
    rpos_p = Bond_DF2RiskPos(analys, &trd, &pay, not_p, 
                             df_p, NULL, holi, ds_p, FX_p) ;

    /* Risk Postions for received leg */
    rpos_r = Bond_DF2RiskPos(analys, &trd, &rcv, not_r,
                             df_r, NULL, holi, ds_r, FX_r) ;

    /* Merge Risk Positions */
    rpos = VAR_MergeRISKPOSLIST(&rpos_p, &rpos_r) ;

    /* Clean up */
    Free_FIXPAY(&pay) ;
    Free_FIXPAY(&rcv) ;
    Free_RISKPOSLIST(&rpos_p) ;
    Free_RISKPOSLIST(&rpos_r) ;

    return rpos ;
}



/*,,SOH,,
*************************************************************************
*
*               OptFX_CRR2RiskPos()
*
*    interface  #include <opteqty.h>
*               RISKPOSLIST OptFX_CRR2RiskPos(DATESTR    *analys,
*                                             FL64       fx_spot,
*                                             FL64       vol,
*                                             INTI       nstep,
*                                             TREEOPT    *opt,
*                                             FL64       Notnal,
*                                             DISCFAC    *df_p,
*                                             DISCFAC    *df_r,
*                                             HOLI_STR   *holi,
*                                             DELTASET   *ds_p,
*                                             DELTASET   *ds_r,
*                                             FXRISKSET  *FX_p,
*                                             FXRISKSET  *FX_r,
*                                             BOOLE      *ok) ;
*
*    general    The routine calculates the risk position for a FX
*               option using the Binomial CRR method and a list of
*               predefined shocks to the zero coupon curve.
*
*               The Risk Position is the core input for VAR calculation.*
*               The Risk Position calculated for this position must be
*               added to the total Risk Position. Once this total Risk
*               Position is available VAR can be calculated with the
*               routine VAR_MATRIX2VAR().
*
*               The decision whether to use price or yield vol is
*               signalled in ds->zero. Note that this must be the same
*               for all risk factors encountered in the total VAR
*               calculation.
*
*               The risk factors affecting FX option are:
*
*                   Interest Rates (Government, Swap or Money Market)
*                   FX (if Instrument CCY differs from Home CCY)
*
*               These entries are found in the returned RISKPOSLIST
*
*               If something goes wrong during the calculation then
*               False is returned.
*
*    input      DATESTR    *analys  Pointer to analysis date (NPV date)
*
*               FL64       fx_spot  The FX spot price
*
*               FL64       vol      The annual volatility of the Spot
*                                   price in percent.
*
*               INTI       nstep    Number of steps in the Binomial Tree*
*
*               TREEOPT    *opt     The data defining the option.
*                                   opt->berm assumed as False.
*
*               FL64       Notnal   The notional holding (position).
*                                   Amount in Instrument CCY.
*
*               DISCFAC   *df_p     Discount function for paid currency
*
*               DISCFAC   *df_r     Discount function for received
*                                   currency
*
*               HOLI_STR  *holi     Holiday setup.
*
*               DELTASET  *ds_p     Data for delta calculation in paid
*                                   currency.
*
*               DELTASET  *ds_r     Data for delta calculation in
*                                   received currency.
*
*               FXRISKSET *FX_p     Data for FX risk generation.
*                                   FX_p->rate is the spot FX rate
*                                   in Home CCY units per paid CCY unit
*                                   in base 1.
*
*               FXRISKSET *FX_r     Data for FX risk generation.
*                                   FX_r->rate is the spot FX rate
*                                   in Home CCY units per received CCY
*                                   unit in base 1.
*
*
*    output     BOOLE      *ok      True if all ok, False if not.
*
*    returns     The Risk Position allocated as:
*
*                   Alloc_FL64ARRAY(ds_p->nshock + ds_r->nshock) ;
*                   Alloc_RISKTOKENARRAY(ds_p->nshock + ds_r->nshock) ;
*
*    diagnostics
*
*    see also    Disc_DeltaPrep()
*
*************************************************************************
,,EOH,,*/
RISKPOSLIST OptFX_CRR2RiskPos(DATESTR*      analys,
                                  FL64          fx_spot,
                                  FL64          vol,
                                  INTI          nstep,
                                  TREEOPT*      opt,
                                  FL64          Notnal,
                                  DISCFAC*      df_p,
                                  DISCFAC*      df_r,
                                  HOLI_STR*     holi,
                                  DELTASET*     ds_p,
                                  DELTASET*     ds_r,
                                  FXRISKSET*    FX_p, 
                                  FXRISKSET*    FX_r, 
                                  BOOLE*        ok)
{
    RISKPOSLIST  rpos, rpostmp, riskpos ;
    FL64ARRAY    dv_p, dv_r ;
    FL64         p, dum, fac, pct, pShock, fx_shock, shock, FXp, FXr, 
                 shockp, shockr ;
    INTI         allocsize, i ;
    BOOLE        ok_p, ok_r, ok_pv ;

    /* Initialise */
    *ok = True ;
    p = dum = 0.0;
    
    FXp = (!SCecon_strncmp(FX_p->token.ccy, FX_p->home, CCY_LENGTH) ? 
            1.0 : FX_p->rate) ;
    FXr = (!SCecon_strncmp(FX_r->token.ccy, FX_r->home, CCY_LENGTH) ? 
            1.0 : FX_r->rate) ;

    shockp = FX_p->shock ;
    shockr = FX_r->shock ;

    rpostmp.token = NULL ;
    rpostmp.pos   = NULL ;
    rpostmp.npos  = 0 ;

    /* Allocate tmp rpos */
    allocsize  = ds_p->nshock + ds_r->nshock + 2 ;
    rpos.token = Alloc_RISKTOKENARRAY(allocsize) ;
    rpos.pos   = Alloc_FL64ARRAY(allocsize) ;
    rpos.npos  = 0 ;

    /* dv wrt zeros has already been pct adjusted */
    pct = 1.0 ;
    ok_pv = OptFX_CRR2P(analys, fx_spot, vol, nstep, opt, df_p, df_r, holi, 
                        NULL, &p, &dum, &dum) ;

    /* Generate delta vector */
    dv_p = OptFX_CRR2Delta(analys, fx_spot, vol, nstep, opt, df_p, df_r, holi,
                           ds_p, &ok_p) ;

    dv_r = OptFX_CRR2Delta(analys, fx_spot, vol, nstep, opt, df_p, df_r, holi, 
                           ds_r, &ok_r) ;
    
    if (ds_p->dom == False || ds_r->dom == True || !ok_pv || !ok_p || !ok_r)
    {
        Free_RISKPOSLIST(&rpos) ;
        Free_FL64ARRAY(dv_p) ;
        Free_FL64ARRAY(dv_r) ;
        return rpostmp ;
    }

    /* Translate to Risk Position, domestic curve */
    for (i = 0; i < ds_p->nshock; i++)
    {
        /* Find adjustment factor */
        fac = Disc_DF2RiskPosFac(analys, df_p, ds_p, i, holi) ;   /* PMSTA-22396 - SRIDHARA � 160502 */

        /* Do the calculation */
        rpos.pos[i] = dv_p[i] * fac * FXp * Notnal / pct ;
        VAR_RiskTokenCpy(&rpos.token[i], &ds_p->token[i]) ;
        rpos.npos += 1 ;
    }

    /* FX risk contribution, pay - if required */
    VAR_RiskTokenCpy(&rpos.token[ds_p->nshock], &FX_p->token) ;
    rpos.npos += 1 ;
    
    if (!SCecon_strncmp(FX_p->token.ccy, FX_p->home, CCY_LENGTH) == False)
    {
        shock = FXp * (1.0 + shockp / 100.0) ;
        fx_shock = SafeDivide(FXr, shock, DIV_TOL, 1.0) ;
        ok_pv = OptFX_CRR2P(analys, fx_shock, vol, nstep, opt, df_p, df_r, holi,
                            NULL, &pShock, &dum, &dum) ;
        fac = SafeDivide(100.0, shockp, DIV_TOL, 1.0) ;
        rpos.pos[ds_p->nshock] = (pShock * shock - p * FXp) * Notnal 
                                    * fac / pct ;
    }
    else
        rpos.pos[ds_p->nshock] = 0.0 ; 

    /* Translate to Risk Position, rcv curve */
    for (i = 0; i < ds_r->nshock; i++)
    {
        /* Find adjustment factor */
        fac = Disc_DF2RiskPosFac(analys, df_r, ds_r, i, holi) ;   /* PMSTA-22396 - SRIDHARA � 160502 */

        /* Do the calculation */
        rpos.pos[i + ds_p->nshock + 1] = dv_r[i] * fac * FXp * Notnal / pct ;
        VAR_RiskTokenCpy(&rpos.token[i + ds_p->nshock + 1], &ds_r->token[i]) ;
        rpos.npos += 1 ;
    }

    /* FX risk contribution, rcv - if required */
    VAR_RiskTokenCpy(&rpos.token[ds_p->nshock + ds_r->nshock + 1], 
                     &FX_r->token) ;
    rpos.npos += 1 ;

    if (!SCecon_strncmp(FX_r->token.ccy, FX_r->home, CCY_LENGTH) == False)
    {
        shock = FXr * (1.0 + shockr / 100.0) ;
        fx_shock = SafeDivide(shock, FXp, DIV_TOL, 1.0) ;
        ok_pv = OptFX_CRR2P(analys, fx_shock, vol, nstep, opt, df_p, df_r,
                            holi, NULL, &pShock, &dum, &dum) ;
        fac = SafeDivide(100.0, shockr, DIV_TOL, 1.0) ;
        rpos.pos[ds_p->nshock + ds_r->nshock + 1] = (pShock - p) * FXp * Notnal
                                                        * fac / pct ;
    }
    else
        rpos.pos[ds_p->nshock + ds_r->nshock + 1] = 0.0 ; 

    /* Merge */
    riskpos = VAR_MergeRISKPOSLIST(&rpos, &rpostmp) ;

    /* Clean up */
    Free_FL64ARRAY(dv_p) ;
    Free_FL64ARRAY(dv_r) ;
    Free_RISKPOSLIST(&rpos) ;
    Free_RISKPOSLIST(&rpostmp) ;

    return riskpos ;
}



/*,,SOH,,
*************************************************************************
*
*               OptFX_Black2RiskPos()
*
*    references HET-97-12, "FX-options -- Calculation of Risk Positons"
*
*    interface  #include <opteqty.h>
*               RISKPOSLIST OptFX_Black2RiskPos(DATESTR    *analys,
*                                               DATESTR    *voldate,
*                                               FL64       vol,
*                                               FL64       fx_spot,
*                                               DATESTR    *spot,
*                                               OPTFUT     *opt,
*                                               FL64       Notnal,
*                                               DISCFAC    *df_p,
*                                               DISCFAC    *df_r,
*                                               HOLI_STR   *holi,
*                                               DELTASET   *ds_p,
*                                               DELTASET   *ds_r,
*                                               FXRISKSET  *FX_p,
*                                               FXRISKSET  *FX_r) ;
*
*   general     The routine calculates the Risk Position for an FX
*               option using a list of predefined shocks to the zero
*               curves.
*
*               The Risk Position is the core input for VAR calculation.*
*               The Risk Position calculated for this position must be
*               added to the total Risk Position. Once this total Risk
*               Position is available VAR can be calculated with the
*               routine VAR_MATRIX2VAR().
*
*               The decision whether to use price or yield vol is
*               signalled in ds->zero. Note that this must be the same
*               for all risk factors encountered in the total VAR
*               calculation.
*
*               The risk factors affecting a FX option are:
*
*                   Interest Rates (Government, Swap or Money Market)
*                   FX (if Instrument CCY differs from Home CCY)
*
*               These entries are found in the returned RISKPOSLIST
*
*    input      DATESTR  *analys  Pointer to analysis date (NPV date)
*
*               DATESTR  *voldate Vol calculated from this date
*
*               FL64      vol     The annual volatility of the FX
*                                 spot price in percent.
*
*               FL64      fx_spot Spot exchange rate. Price in domes-
*                                 tic currency of foreign currency units*
*
*               DATESTR   *spot   The date for fx_spot
*
*               OPTFUT    *opt    The data defining the option.
*
*               FL64      Notnal  The notional holding (position).
*                                 Amount in received CCY.
*
*               DISCFAC   *df_p   Discount function for paid currency
*
*               DISCFAC   *df_r   Discount function for received
*                                 currency
*
*               HOLI_STR  *holi   Holiday setup.
*
*               DELTASET  *ds_p   Data for delta calculation in paid
*                                 currency.
*
*               DELTASET  *ds_r   Data for delta calculation in
*                                 received currency.
*
*               FXRISKSET *FX_p   Data for FX risk generation.
*                                 FX_p->rate is the spot FX rate
*                                 in Home CCY units per paid CCY unit
*                                 in base 1.
*
*               FXRISKSET *FX_r   Data for FX risk generation.
*                                 FX_r->rate is the spot FX rate
*                                 in Home CCY units per received CCY
*                                 unit in base 1.
*
*
*   returns     The Risk Position allocated as:
*
*                   Alloc_FL64ARRAY(ds_p->nshock + ds_r->nshock) ;
*                   Alloc_RISKTOKENARRAY(ds_p->nshock + ds_r->nshock) ;
*
*    diagnostics
*
*    see also
*
*    wrapper    AP
*
*************************************************************************
,,EOH,,*/
RISKPOSLIST OptFX_Black2RiskPos(DATESTR*      analys,
                                    DATESTR*      voldate,
                                    FL64          vol,
                                    FL64          fx_spot,
                                    DATESTR*      spot,
                                    OPTFUT*       opt,
                                    FL64          Notnal,
                                    DISCFAC*      df_p,
                                    DISCFAC*      df_r,
                                    HOLI_STR*     holi,
                                    DELTASET*     ds_p,
                                    DELTASET*     ds_r,
                                    FXRISKSET*    FX_p,
                                    FXRISKSET*    FX_r)
{
    FL64        dum, p, fac, delta, FXp, FXr ;
    FL64ARRAY   dv_p, dv_r ;
    INTI        i, allocsize ;
    RISKPOSLIST rpos, rpostmp, riskpos ;
    RISKSET     risk ;

      /* 1a. Initialise */        
    FXp = (!SCecon_strncmp(FX_p->token.ccy, FX_p->home, CCY_LENGTH) ? 
            1.0 : FX_p->rate) ;
    FXr = (!SCecon_strncmp(FX_r->token.ccy, FX_r->home, CCY_LENGTH) ? 
            1.0 : FX_r->rate) ;

    rpostmp.token = NULL ;
    rpostmp.pos   = NULL ;
    rpostmp.npos  = 0 ;

      /* 1b. Input validation */
    if (ds_p->dom == False || ds_r->dom == True)
        return rpostmp ;

      /* 2a. Calculate premium and delta */
    risk = Set_RISKSET(KEY_SPOT, FIRST_ORDER, FX_p->shock,
                       CONTINUOUS, NO_FREQUENCY, NULL, True) ;

    p = OptFX_Black2P(analys, voldate, vol, fx_spot, spot, opt,
                      df_p, df_r, holi, &risk, &delta, &dum) ;

      /* 2b. Allocate memory for the list of risk positions */
    allocsize  = ds_p->nshock + ds_r->nshock + 2 ;

    rpos.token = Alloc_RISKTOKENARRAY(allocsize) ;
    rpos.pos   = Alloc_FL64ARRAY(allocsize) ;
    rpos.npos  = 0 ;

      /* 2c. Calculate delta vectors */
    dv_p = OptFX_Black2Delta(analys, voldate, vol, fx_spot, spot, opt,
                             df_p, df_r, holi, ds_p) ;

    dv_r = OptFX_Black2Delta(analys, voldate, vol, fx_spot, spot, opt,
                             df_p, df_r, holi, ds_r) ;

      /* 3a. Risk positions wrt paid curve */
    for (i = 0; i < ds_p->nshock; i++)
    {
        fac = Disc_DF2RiskPosFac(analys, df_p, ds_p, i, holi) ;   /* PMSTA-22396 - SRIDHARA � 160502 */
        rpos.pos[i] = dv_p[i] * fac * FXp * Notnal ;

        VAR_RiskTokenCpy(&rpos.token[i], &ds_p->token[i]) ;

        rpos.npos += 1 ;
    }

      /* 3b. Risk position wrt paid currency (domestic) */
    VAR_RiskTokenCpy(&rpos.token[ds_p->nshock], &FX_p->token) ;

    rpos.npos += 1 ;

    if (!SCecon_strncmp(FX_p->token.ccy, FX_p->home, CCY_LENGTH) == False)
        rpos.pos[ds_p->nshock] = Notnal * (FXp * p - FXr * delta) ;
    else
        rpos.pos[ds_p->nshock] = 0.0 ; 

      /* 3c. Risk positions wrt received curve */
    for (i = 0; i < ds_r->nshock; i++)
    {
        fac = Disc_DF2RiskPosFac(analys, df_r, ds_r, i, holi) ;   /* PMSTA-22396 - SRIDHARA � 160502 */
        rpos.pos[i + ds_p->nshock + 1] = dv_r[i] * fac * FXp * Notnal ;

        VAR_RiskTokenCpy(&rpos.token[i + ds_p->nshock + 1], &ds_r->token[i]) ;

        rpos.npos += 1 ;
    }

      /* 3d. Risk position wrt received currency (foreign) */
    VAR_RiskTokenCpy(&rpos.token[ds_p->nshock + ds_r->nshock + 1], 
                        &FX_r->token) ;
    rpos.npos += 1 ;

    if (!SCecon_strncmp(FX_r->token.ccy, FX_r->home, CCY_LENGTH) == False)
        rpos.pos[ds_p->nshock + ds_r->nshock + 1] =
            Notnal * (FXr * delta - FXp * p) ;
    else
        rpos.pos[ds_p->nshock + ds_r->nshock + 1] = 0.0 ; 

      /* 4. Merge lists */
    riskpos = VAR_MergeRISKPOSLIST(&rpos, &rpostmp) ;

      /* 5. Free */
    Free_FL64ARRAY(dv_p) ;
    Free_FL64ARRAY(dv_r) ;
    Free_RISKPOSLIST(&rpos) ;
    Free_RISKPOSLIST(&rpostmp) ;

    return riskpos ;
}


/*,,SOH,,
*************************************************************************
*
*               OptFutFX_Black2RiskPos()
*
*    interface  #include <opteqty.h>
*               RISKPOSLIST OptFutFX_Black2RiskPos(DATESTR    *analys,
*                                                  DATESTR    *voldate,
*                                                  FL64       vol,
*                                                  FL64       fx_spot,
*                                                  DATESTR    *spot,
*                                                  OPTFUT     *opt,
*                                                  FL64       Notnal,
*                                                  DISCFAC    *df_p,
*                                                  DISCFAC    *df_r,
*                                                  HOLI_STR   *holi,
*                                                  DELTASET   *ds_p,
*                                                  DELTASET   *ds_r,
*                                                  FXRISKSET  *FX_p,
*                                                  FXRISKSET  *FX_r) ;
*
*   general     The routine calculates the Risk Position for an option
*               on a FX forward using a list of predefined shocks to
*               the zero curves.
*
*               The Risk Position is the core input for VAR calculation.*
*               The Risk Position calculated for this position must be
*               added to the total Risk Position. Once this total Risk
*               Position is available VAR can be calculated with the
*               routine VAR_MATRIX2VAR().
*
*               The decision whether to use price or yield vol is
*               signalled in ds->zero. Note that this must be the same
*               for all risk factors encountered in the total VAR
*               calculation.
*
*               The risk factors affecting an option on a FX
*               forward are:
*
*                   Interest Rates (Government, Swap or Money Market)
*                   FX (if Instrument CCY differs from Home CCY)
*
*               These entries are found in the returned RISKPOSLIST
*
*    input      DATESTR  *analys  Pointer to analysis date (NPV date)
*
*               DATESTR  *voldate Vol calculated from this date
*
*               FL64      vol     The annual volatility of the FX
*                                 spot price in percent.
*
*               FL64      fx_spot Spot exchange rate. Price in domes-
*                                 tic currency of foreign currency units*
*
*               DATESTR   *spot   The date for fx_spot
*
*               OPTFUT    *opt    The data defining the option.
*
*               FL64      Notnal  The notional holding (position).
*                                 Amount in received CCY.
*
*               DISCFAC   *df_p   Discount function for paid currency
*
*               DISCFAC   *df_r   Discount function for received
*                                 currency
*
*               HOLI_STR  *holi   Holiday setup.
*
*               DELTASET  *ds_p   Data for delta calculation in paid
*                                 currency.
*
*               DELTASET  *ds_r   Data for delta calculation in
*                                 received currency.
*
*               FXRISKSET *FX_p   Data for FX risk generation.
*                                 FX_p->rate is the spot FX rate
*                                 in Home CCY units per paid CCY unit
*                                 in base 1.
*
*               FXRISKSET *FX_r   Data for FX risk generation.
*                                 FX_r->rate is the spot FX rate
*                                 in Home CCY units per received CCY
*                                 unit in base 1.
*
*
*   returns     The Risk Position allocated as:
*
*                   Alloc_FL64ARRAY(ds_p->nshock + ds_r->nshock) ;
*                   Alloc_RISKTOKENARRAY(ds_p->nshock + ds_r->nshock) ;
*
*    diagnostics
*
*    see also
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/
RISKPOSLIST OptFutFX_Black2RiskPos(DATESTR*      analys,
                                       DATESTR*      voldate,
                                       FL64          vol,
                                       FL64          fx_spot,
                                       DATESTR*      spot,
                                       OPTFUT*       opt,
                                       FL64          Notnal,
                                       DISCFAC*      df_p,
                                       DISCFAC*      df_r,
                                       HOLI_STR*     holi,
                                       DELTASET*     ds_p,
                                       DELTASET*     ds_r,
                                       FXRISKSET*    FX_p,
                                       FXRISKSET*    FX_r)
{
    return OptFX_Black2RiskPos(analys, voldate, vol, fx_spot, spot, 
                               opt, Notnal, df_p, df_r, holi, ds_p, 
                               ds_r, FX_p, FX_r) ;
} 




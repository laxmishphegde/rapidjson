/* SCID @(#)crreqty.c	1.17 (SimCorp) 99/10/14 15:06:26 */

/************************************************************************
*
*   project     SCecon
*
*   filename    crreqty.c
*
*   contains    routines in the SCecon Library Options price
*               module to calculate options prices and risk ratios
*               based on the Cox/Ross/Rubinstein model.
*
************************************************************************/

/*** includes **********************************************************/
#include <opteqty.h>
#include <option.h>



/*,,SOH,,
*************************************************************************
*
*               OptFX_CRR2P()
*
*    interface  #include <opteqty.h>
*               BOOLE OptFX_CRR2P(DATESTR  *analys,
*                                 FL64     spot,
*                                 FL64     vol,
*                                 INTI     nstep,
*                                 TREEOPT  *opt,
*                                 DISCFAC  *df_d,
*                                 DISCFAC  *df_f,
*                                 HOLI_STR *holi,
*                                 RISKSET  *risk,
*                                 FL64     *p,
*                                 FL64     *dp,
*                                 FL64     *ddp) ;
*
*    general    The routine calculates the premium for an EU/US-Style
*               option on Currency using the
*               Cox-Ross-Rubinstein binomial approach.
*               In addition, some of the 'Greeks' can be computed.
*
*               Key ratios are calculated as follows:
*
*                   risk->key         dp          ddp
*                   ---------         ---         ----
*                   KEY_PRICE         Delta       Gamma
*                   KEY_MATURITY      Theta       N/A
*                   KEY_FIRSTDELIVERY Zeta        N/A
*                   KEY_VOL           Vega        d(Vega)/d(Vol)
*                   KEY_STRIKE        d(P)/d(C)   N/A
*                   KEY_REPO          Rho         d(rho)/d(r)
*                   KEY_BPV           BPV         N/A
*                   KEY_DF            $Duration   $Convexity
*                   -----------------------------------------
*
*               Rho is wrt the domestic rates.
*
*    input      DATESTR  *analys  Pointer to analysis date (NPV date)
*
*               FL64     spot     The unadjusted spot price
*
*               FL64     vol      The annual volatility of the Spot
*                                 price in percent.
*
*               INTI     nstep    Number of steps in the Binomial Tree
*
*               TREEOPT  *opt     The data defining the option.
*                                 opt->berm assumed as False.
*
*               DISCFAC  *df_d    Discount function in domestic currency*
*                                 For CALL - PUT CCY Curve
*                                 For PUT  - CALL CCY Curve
*
*               DISCFAC  *df_f    Discount function in foreign currency
*                                 For CALL - CALL CCY Curve
*                                 For PUT  - PUT CCY Curve
*
*               HOLI_STR *holi    Holiday setup
*
*               RISKSET  *risk    The risk ratio definitions
*                                 Use NULL for no Greeks
*
*    output     FL64     *p       Pointer to the Option Premium
*                                 For CALL - PUT CCY units
*                                 For PUT  - CALL CCY units
*
*               FL64     *dp      Pointer to the first order derivative
*
*               FL64     *ddp     Pointer to the second order derivative*
*
*    returns    True if all is OK, False if not.
*
*    diagnostics
*
*    see also   OptFX_CRR2Impl()
*               OptEqty_CRR2P()
*               OptCmdty_CRR2P()
*
*************************************************************************
,,EOH,,*/

BOOLE OptFX_CRR2P(DATESTR* analys,
                     FL64     spot,
                     FL64     vol,
                     INTI     nstep,
                     TREEOPT*  opt,
                     DISCFAC*  df_d,
                     DISCFAC*  df_f,
                     HOLI_STR* holi,
                     RISKSET*  risk,
                     FL64*     p,
                     FL64*     dp,
                     FL64*     ddp)
{
    BOOLE    ok ;
    FUTEQTY  fute ;

    fute = Set_FUTEQTY(analys, NULL, opt->cal, 0.0, False) ;
    ok   = OptEqty_CRR2P(analys, spot, vol, nstep, df_f, &fute, opt, df_d,
                         holi, risk, p, dp, ddp) ;
    return ok ;
}



/*,,SOH,,
*************************************************************************
*
*               OptFX_CRR2Delta()
*
*    interface  #include <opteqty.h>
*               FL64ARRAY OptFX_CRR2Delta(DATESTR  *analys,
*                                         FL64     spot,
*                                         FL64     vol,
*                                         INTI     nstep,
*                                         TREEOPT  *opt,
*                                         DISCFAC  *df_d,
*                                         DISCFAC  *df_f,
*                                         HOLI_STR *holi,
*                                         DELTASET *ds,
*                                         BOOLE    *ok);
*
*    general    The routine calculates the delta vector for an US-Style
*               option on Currency using the
*               Cox-Ross-Rubinstein binomial approach.
*
*    input      DATESTR  *analys  Pointer to analysis date (NPV date)
*
*               FL64     spot     The unadjusted spot price
*
*               FL64     vol      The annual volatility of the Spot
*                                 price in percent.
*
*               INTI     nstep    Number of steps in the Binomial Tree
*
*               TREEOPT  *opt     The data defining the option.
*                                 opt->berm assumed as False.
*
*               DISCFAC  *df_d    Discount function in domestic currency*
*                                 For CALL - PUT CCY Curve
*                                 For PUT  - CALL CCY Curve
*
*               DISCFAC  *df_f    Discount function in foreign currency
*                                 For CALL - CALL CCY Curve
*                                 For PUT  - PUT CCY Curve
*
*               HOLI_STR *holi    Holiday setup
*
*               DELTASET *ds      Data for delta calculation
*
*    output     BOOLE    *ok      True if all ok , False if not.
*
*    returns    The delta vector allocated as:
*
*                         Alloc_FL64ARRAY(ds->nshock) ;
*
*               For CALL - PUT CCY units
*               For PUT  - CALL CCY units
*
*    diagnostics
*
*    see also   OptFX_CRR2Impl()
*               OptEqty_CRR2P()
*               OptCmdty_CRR2P()
*
*************************************************************************
,,EOH,,*/


FL64ARRAY OptFX_CRR2Delta(DATESTR* analys,
                          FL64     spot,
                          FL64     vol,
                          INTI     nstep,
                          TREEOPT*  opt,
                          DISCFAC*  df_d,
                          DISCFAC*  df_f,
                          HOLI_STR* holi,
                          DELTASET*  ds,
                          BOOLE*     ok)
{
    FUTEQTY   fute ;
    FL64ARRAY dv ;

    fute = Set_FUTEQTY(analys, NULL, opt->cal, 0.0, False) ;
    dv   = OptEqty_CRR2Delta(analys, spot, vol, nstep, df_f, &fute, 
                             opt, df_d, holi, ds, ok) ;
    return dv ;
}


/*,,SOH,,
*************************************************************************
*
*               OptCmdty_CRR2P()
*
*    interface  #include <opteqty.h>
*               BOOLE OptCmdty_CRR2P(DATESTR  *analys,
*                                    FL64     spot,
*                                    FL64     vol,
*                                    INTI     nstep,
*                                    TREEOPT  *opt,
*                                    DISCFAC  *conv_df,
*                                    DISCFAC  *stor_df,
*                                    FUTCMDTY *futc,
*                                    DISCFAC  *df,
*                                    HOLI_STR *holi,
*                                    RISKSET  *risk,
*                                    FL64     *p,
*                                    FL64     *dp,
*                                    FL64     *ddp) ;
*
*    general    The routine calculates the premium for an EU/US-Style
*               option on Commodity using the
*               Cox-Ross-Rubinstein binomial approach.
*               In addition, some of the 'Greeks' can be computed.
*
*               Key ratios are calculated as follows:
*
*                   risk->key         dp          ddp
*                   ---------         ---         ----
*                   KEY_PRICE         Delta       Gamma
*                   KEY_MATURITY      Theta       N/A
*                   KEY_FIRSTDELIVERY Zeta        N/A
*                   KEY_VOL           Vega        d(Vega)/d(Vol)
*                   KEY_STRIKE        d(P)/d(C)   N/A
*                   KEY_REPO          Rho         d(rho)/d(r)
*                   KEY_BPV           BPV         N/A
*                   KEY_DF            $Duration   $Convexity
*                   -----------------------------------------
*
*               If something goes wrong during the calculation then
*               False is returned.
*
*               Convenience Yields and Storage Costs may be entered in
*               two ways:
*
*                i)  as a discount function
*                ii) as discrete amounts (% of underlying price)
*
*    input      DATESTR  *analys  Pointer to analysis date (NPV date)
*
*               FL64     spot     The unadjusted spot price
*
*               FL64     vol      The annual volatility of the Spot
*                                 price in percent.
*
*               INTI     nstep    Number of steps in the Binomial Tree
*
*               TREEOPT  *opt     The data defining the option.
*                                 opt->berm assumed as False.
*
*               DISCFAC  *conv_df Discount function of convenience
*                                 yields
*
*               DISCFAC  *stor_df Discount function of storage costs
*
*               FUTCMDTY *futc    Commodity data
*
*               DISCFAC  *df      Discount function for discounting
*                                 the option payout.
*
*               HOLI_STR *holi    Holiday setup
*
*               RISKSET  *risk    The risk ratio definitions
*                                 Use NULL for no Greeks
*
*    output     FL64     *p       Pointer to the Option Premium
*
*               FL64     *dp      Pointer to the first order derivative
*
*               FL64     *ddp     Pointer to the second order derivative*
*
*    returns    True if all is OK, False if not.
*
*    diagnostics
*
*    see also   OptCmdty_CRR2Impl()
*               OptEqty_CRR2P()
*               OptFX_CRR2P()
*
*************************************************************************
,,EOH,,*/

BOOLE OptCmdty_CRR2P(DATESTR* analys,
                     FL64     spot,
                     FL64     vol,
                     INTI     nstep,
                     TREEOPT*  opt,
                     DISCFAC*  conv_df,
                     DISCFAC*  stor_df,
                     FUTCMDTY* futc,
                     DISCFAC*  df,
                     HOLI_STR* holi,
                     RISKSET*  risk,
                     FL64*     p,
                     FL64*     dp,
                     FL64*     ddp)
{
    PLANARRAY cc ;
    DISCFAC   cc_df ;
    BOOLE     ok ;
    PLAN_STR  ps[2] ;
    INTI      ind[2] ;
    FL64      wgt[2] ;
    FUTEQTY   fute ;

    /* Merge the PLAN_STR's 'conv' and 'stor' */
    if (futc->cy != NULL)
        ps[0] = *(futc->cy) ;
    else
        ps[0].filled = 0 ;

    if (futc->stc != NULL)
        ps[1] = *(futc->stc) ;
    else
        ps[1].filled = 0 ;

    ind[0] = 0 ;
    ind[1] = 1 ;
    wgt[0] = 1.0 ;           /* Add Convenience Yield */
    wgt[1] = -1.0 ;          /* Subtract Storage Costs */
    cc = Cflw_MergePLANARRAY(ps, ind, wgt, 2) ;

    /* Combine the DISCFAC's 'conv_df' and 'stor_df' */
	cc_df = Disc_MergeDF(conv_df, stor_df, holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */

    /* Finally we can do the calculation */
    fute = Set_FUTEQTY(&futc->matur, cc, futc->cal, 0.0, False) ;
    ok   = OptEqty_CRR2P(analys, spot, vol, nstep, &cc_df, &fute, opt, df,
                         holi, risk, p, dp, ddp) ;

    /* Free */
    Free_PLANARRAY(cc, 1) ;
    Free_PLANARRAY(cc_df.disc, 1) ;

    return ok ;
}


/*,,SOH,,
*************************************************************************
*
*               OptEqty_CRR2P()
*
*    interface  #include <opteqty.h>
*               BOOLE OptEqty_CRR2P(DATESTR  *analys,
*                                   FL64     spot,
*                                   FL64     vol,
*                                   INTI     nstep,
*                                   DISCFAC  *divdf,
*                                   FUTEQTY  *fute,
*                                   TREEOPT  *opt,
*                                   DISCFAC  *df,
*                                   HOLI_STR *holi,
*                                   RISKSET  *risk,
*                                   FL64     *p,
*                                   FL64     *dp,
*                                   FL64     *ddp) ;
*
*    general    The routine calculates the premium for an EU/US-Style
*               option on Equity (stock or stock index) using the
*               Cox-Ross-Rubinstein binomial approach.
*               In addition, some of the 'Greeks' can be computed.
*
*               Key ratios are calculated as follows:
*
*                   risk->key         dp          ddp
*                   ---------         ---         ----
*                   KEY_PRICE         Delta       Gamma
*                   KEY_MATURITY      Theta       N/A
*                   KEY_FIRSTDELIVERY Zeta        N/A
*                   KEY_VOL           Vega        d(Vega)/d(Vol)
*                   KEY_STRIKE        d(P)/d(C)   N/A
*                   KEY_REPO          Rho         d(rho)/d(r)
*                   KEY_BPV           BPV         N/A
*                   KEY_DF            $Duration   $Convexity
*                   -----------------------------------------
*
*               If something goes wrong during the calculation then
*               False is returned.
*
*               Dividends may be entered in two ways:
*
*                i)  as a PLAN_STR of discrete amounts
*                ii) as a DISCFAC
*
*    input      DATESTR  *analys  Pointer to analysis date (NPV date)
*
*               FL64     spot     The unadjusted spot price
*
*               FL64     vol      The annual volatility of the Spot
*                                 price in percent.
*
*               INTI     nstep    Number of steps in the Binomial Tree
*
*               DISCFAC  *divdf   Term structure of dividend yields
*
*               FUTEQTY  *fute    Equity data
*
*               TREEOPT  *opt     The data defining the option.
*                                 opt->berm assumed as False.
*
*               DISCFAC  *df      Discount function for discounting
*                                 the option payout.
*
*               HOLI_STR *holi    Holiday setup
*
*               RISKSET  *risk    The risk ratio definitions
*                                 Use NULL for no Greeks
*
*    output     FL64     *p       Pointer to the Option Premium
*
*               FL64     *dp      Pointer to the first order derivative
*
*               FL64     *ddp     Pointer to the second order derivative*
*
*    returns    True if all is OK, False if not.
*
*    diagnostics
*
*    see also   OptEqty_CRR2Impl()
*
*    wrapper    AP
*
*************************************************************************
,,EOH,,*/

BOOLE OptEqty_CRR2P(DATESTR* analys,
                     FL64     spot,
                     FL64     vol,
                     INTI     nstep,
                     DISCFAC*  divdf,
                     FUTEQTY*  fute,
                     TREEOPT*  opt,
                     DISCFAC*  df,
                     HOLI_STR* holi,
                     RISKSET*  risk,
                     FL64*     p,
                     FL64*     dp,
                     FL64*     ddp)
{
    BINTREEARRAY crr ;
    TSARRAY      ts, fts ;
    DATESTR      expiry, d1, d2 ;
    BOOLE        ok ;
    KEYCONV      key ;
    RISKCONV     rsk ;
    FL64         shock ;

    *p = *ddp = *ddp = 0.0 ;

    /* Watch your steps ... */
    if (GetPlanFill(df->disc) <= 0)
        return False;

    /* Initialize */
    expiry = Cldr_NextBusinessDate(&opt->dpay.last, holi) ;
    crr    = Clb_CRR2Tree(nstep, vol, spot, analys, &expiry, opt->cal,
                          fute->div, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */

    ts = Disc_DF2TS(df->disc->day + 1, GetPlanFill(df->disc) - 1, df, NULL,
                    df->irr, df->freq, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
    
    if (GetPlanFill(divdf->disc) > 0)
        fts = Disc_DF2TS(divdf->disc->day + 1, GetPlanFill(divdf->disc) - 1, 
                         divdf, NULL, divdf->irr, divdf->freq, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
    else
        fts = Alloc_TSARRAY(1, 1) ;

    d1 = Cldr_NextBusinessDate(&opt->dpay.first, holi) ;
    d2 = Cldr_NextBusinessDate(&opt->dpay.last, holi) ;

    key   = (risk != NULL ? risk->key : KEY_PRICE) ;
    rsk   = (risk != NULL ? risk->risk : ZERO_ORDER) ;
    shock = (risk != NULL ? risk->shock : 0.0) ;

    ok = CRR_premium(crr, analys, &d1, &d2, opt->pay_delay, opt->strike, vol, 
                     ts, df->iconv, opt->type, fts, divdf->iconv, fute->div, 
                     key, rsk, shock, opt->cal, p, dp, ddp) ;

    Free_BINTREEARRAY(crr, 1) ;
    Free_TSARRAY(ts, 1) ;
    Free_TSARRAY(fts, 1) ;

    if (risk == NULL)
        return ok ;

    if (risk->key == KEY_MATURITY && risk->risk != ZERO_ORDER)
    {
        *ddp = 0.0 ;
        *dp *= -1.0 ;
    }

    if (risk->key == KEY_FIRSTDELIVERY && risk->risk != ZERO_ORDER)
    {
        *ddp = 0.0 ;
        *dp *= -1.0 ;
    }

    return ok ;
}


/*,,SOH,,
*************************************************************************
*
*               OptExch_CRR2P()
*
*    references JAS-97-07, "Exchange Options"
*               HET-97-12, "Exchange Options -- American Style"
*               Rubinstein & Reiner, 1992, "Exotic Options"
*
*    interface  #include <opteqty.h>
*               BOOLE OptExch_CRR2P(DATESTR  *analys,
*                                   FL64     spot1,
*                                   FL64     spot2,
*                                   FL64     vol1,
*                                   FL64     vol2,
*                                   FL64     corr,
*                                   DISCFAC  *divyld1,
*                                   DISCFAC  *divyld2,
*                                   PLAN_STR *plan1,
*                                   PLAN_STR *plan2,
*                                   INTI     nstep,
*                                   TREEOPT  *opt,
*                                   HOLI_STR *holi,
*                                   RISKSET  *risk,
*                                   FL64     *p,
*                                   FL64     *dp,
*                                   FL64     *ddp) ;
*               
*    general     The routine calculates the premium of European or
*                American style exchange options using the Cox-Ross-
*                Rubinstein binomial method.
*
*                The terminal payoff from an exchange option is given
*                by
*
*                    max(spot1 - spot2 ; 0)
*
*                The implementation is suggested by Rubinstein.
*
*                Some of the 'Greeks' can be computed.
*
*                Key ratios are calculated as follows:
*
*                    risk->key     risk->dom  *dp     *ddp
*                    ---------     ---------  ---     ----
*                    KEY_SPOT      False      Delta1  Gamma1
*                    KEY_SPOT      True       Delta2  Gamma2
*                    KEY_GAMMAX               N/A     Mixed-Gamma
*                    KEY_MATURITY             Theta   N/A
*                    KEY_VOL                  Vega    N/A
* 
*                Note that it is possible to enter both continuous and
*                and discrete dividends for each asset.
* 
*    input       DATESTR  *analys  Analysis date (NPV date)
* 
*                FL64     spot1    Price of asset 1
*
*                FL64     spot2    Price of asset 2
*
*                FL64     vol1     Annual volatility of asset 1 (pct)
*
*                FL64     vol2     Annual volatility of asset 2 (pct)
*
*                FL64     corr     Correlation between asset 1 and 2
*
*                DISCFAC  *divyld1 Dividend yield of asset 1 -- enter
*                                  as discount factors
*
*                DISCFAC  *divyld2 Dividend yield of asset 2 -- enter
*                                  as discount factors
*
*                PLAN_STR *plan1   Plan of discrete dividend payments
*                                  for asset 1
* 
*                PLAN_STR *plan2   Plan of discrete dividend payments
*                                  for asset 2
*
*                INTI     nstep    Number of steps in the binomial tree
*
*                TREEOPT  *opt     Definition of the option
*                                  Note that strike is irrelevant
*
*                HOLI_STR *holi    Holiday setup
*
*                RISKSET  *risk    Risk ratio definition

*
*    output      FL64     *p       Pointer to the option premium
*
*                FL64     *dp      Pointer to the first order derivative
*
*                FL64     *ddp     Pointer to the second order derivative
*
*    returns     BOOLE    *ok      True if all ok , False if not
*
*    diagnostics
*
*    see also    OptExch_Black2P()
*                OptEqty_CRR2P()
*                OptCmdty_CRR2P()
*
*************************************************************************
,,EOH,,*/

BOOLE OptExch_CRR2P(DATESTR  *analys,
                    FL64     spot1,
                    FL64     spot2,
                    FL64     vol1,
                    FL64     vol2,
                    FL64     corr,
                    DISCFAC  *divyld1,
                    DISCFAC  *divyld2,
                    PLAN_STR *plan1,
                    PLAN_STR *plan2,
                    INTI     nstep,
                    TREEOPT  *opt,
                    HOLI_STR *holi,
                    RISKSET  *risk,
                    FL64     *p,
                    FL64     *dp,
                    FL64     *ddp)

{
    BINTREEARRAY crr ;
    BOOLE        ok ;
    DATESTR      expiry, d1, d2, anld ;
    INTI         ind[2] ;
    FL64         wgt[2] ;
    FL64         spot, vol, shock, phi, plo ;
    PLANARRAY    div ;
    PLAN_STR     ps[2] ;
    TSARRAY      ts, fts ;
    RISKSET      risk2 ;

      /* Warning avoidance */
    *p = *dp = *ddp = 0.0 ;
    ok = True ;

      /* Merge dividend plans (plan1 - plan2) */
    if (plan1 != NULL)
        ps[0] = *plan1 ;
    else
        ps[0].filled = 0 ;

    if (plan2 != NULL)
        ps[1] = *plan2 ;
    else
        ps[1].filled = 0 ;

    ind[0] = 0 ;
    ind[1] = 1 ;
    wgt[0] = 1.0 ;
    wgt[1] = -1.0 ;

    div    = Cflw_MergePLANARRAY(ps, ind, wgt, 2) ;

      /* Spot and vol of the martingale process -- spot1 as numeraire */
    spot = spot2 / spot1 ;
    vol  = Vol_Bivariate2Vol(vol1, vol2, corr);
    
      /* Initialize tree */
    expiry = Cldr_NextBusinessDate(&opt->dpay.last, holi) ;
    crr    = Clb_CRR2Tree(nstep, vol, spot, analys, &expiry, opt->cal, div, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */

      /* Dividend yield 1 must be interpretted as interest rate */
    if (GetPlanFill(divyld1->disc) > 0)
      ts = Disc_DF2TS(divyld1->disc->day + 1,
                      GetPlanFill(divyld1->disc) - 1,
                      divyld1, NULL, divyld1->irr, divyld1->freq, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
    else
      ts = Alloc_TSARRAY(1, 1) ;

      /* Dividend yield 2 must be interpretted as the payout
           rate of the underlying */
    if (GetPlanFill(divyld2->disc) > 0)
      fts = Disc_DF2TS(divyld2->disc->day + 1,
                       GetPlanFill(divyld2->disc) - 1,
                       divyld2, NULL, divyld2->irr, divyld2->freq, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
    else
      fts = Alloc_TSARRAY(1, 1) ;

      /* Calculate premium */
    d1 = Cldr_NextBusinessDate(&opt->dpay.first, holi) ;
    d2 = Cldr_NextBusinessDate(&opt->dpay.last, holi) ;

      /* Note that the strike==1.0 is fixed
           -- max(S2-S1,0) is changed to max(S2/S1-1,0) */
    ok = CRR_premium(crr, analys, &d1, &d2, opt->pay_delay, 1.0, vol,
                     ts, divyld1->iconv, opt->type, fts, divyld2->iconv,
                     div, KEY_PRICE, risk->risk, 0.0, opt->cal, p, dp, ddp) ;

      /* Clean up */
    Free_BINTREEARRAY(crr, 1) ;
    Free_PLANARRAY(div, 1) ;
    Free_TSARRAY(ts, 1) ;
    Free_TSARRAY(fts, 1) ;

      /* We chose spot1 as numeraire -- now multiply by spot1 */
    *p *= spot1 ;

    if (risk == NULL)
        return ok ;

      /* Risk ratios -- note that
         1. risk->dom has the same interpretation as in OptExch_Black2P
         2. we reuse dp and ddp from the general CRR_premium function */
    if (risk->risk != ZERO_ORDER)
    {
      risk2 = Set_RISKSET(KEY_SPOT, ZERO_ORDER, 0.0, COMPOUND, ANNUALLY,
                          NULL, False) ;

      shock = Scutl_Default_Shock(risk->shock, risk->key);

      if (risk->key == KEY_SPOT || risk->key == KEY_PRICE)
      {
        if (risk->dom == False)
          *dp = ((*p) - spot2 * (*dp)) / spot1 ;
        if (risk->risk == SECOND_ORDER)
        {
          if (risk->dom == False)
            *ddp = (*ddp) * SQR(spot2) / (SQR(spot1) * spot1) ;
          else
            *ddp /= spot1 ;
        }
      }

      else if (risk->key == KEY_GAMMAX)
      {
        *dp = 0.0 ;
        *ddp *= -spot2 / SQR(spot1) ;
      }

      else if (risk->key == KEY_VOL)
      {
        if (risk->dom == True)
        {
          ok = OptExch_CRR2P(analys, spot1, spot2, vol1, vol2 + shock,
                             corr, divyld1, divyld2, plan1, plan2,
                             nstep, opt, holi, &risk2, &phi, dp, ddp) ;
          ok = OptExch_CRR2P(analys, spot1, spot2, vol1, vol2 - shock,
                             corr, divyld1, divyld2, plan1, plan2,
                             nstep, opt, holi, &risk2, &plo, dp, ddp) ;
        }
        else
        {
          ok = OptExch_CRR2P(analys, spot1, spot2, vol1 + shock, vol2,
                             corr, divyld1, divyld2, plan1, plan2,
                             nstep, opt, holi, &risk2, &phi, dp, ddp) ;
          ok = OptExch_CRR2P(analys, spot1, spot2, vol1 - shock, vol2,
                             corr, divyld1, divyld2, plan1, plan2,
                             nstep, opt, holi, &risk2, &plo, dp, ddp) ;
        }
        *dp = (phi - plo) / (2.0 * shock) ;
      }

      else if (risk->key == KEY_MATURITY)
      {
        anld  = Cldr_AddDays(analys, (INTL) shock, opt->cal, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
        ok = OptExch_CRR2P(&anld, spot1, spot2, vol1, vol2,
                           corr, divyld1, divyld2, plan1, plan2,
                           nstep, opt, holi, &risk2, &plo, dp, ddp) ;
        *dp = (plo - (*p)) / shock ;
        *dp *= Cldr_DaysPerYear(analys, analys, 0, opt->cal, LAST, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
      }

    }

    return ok ;
}



/*,,SOH,,
*************************************************************************
*
*               OptEqty_CRR2Delta()
*
*    interface  #include <opteqty.h>
*               FL64ARRAY OptEqty_CRR2Delta(DATESTR    *analys,
*                                           FL64       spot,
*                                           FL64       vol,
*                                           INTI       nstep,
*                                           DISCFAC    *divdf,
*                                           FUTEQTY    *fute,
*                                           TREEOPT    *opt,
*                                           DISCFAC    *df,
*                                           HOLI_STR   *holi,
*                                           DELTASET   *ds,
*                                           BOOLE      *ok) ;
*
*    general    The routine calculates the delta vector for an
*               EU/US-Style option on Equity (stock or stock index)
*               using the Cox-Ross-Rubinstein binomial approach.
*
*               If something goes wrong during the calculation then
*               False is returned.
*
*               Dividends may be entered in two ways:
*
*                i)  as a PLAN_STR of discrete amounts
*                ii) as a DISCFAC
*
*    input      DATESTR  *analys  Pointer to analysis date (NPV date)
*
*               FL64     spot     The unadjusted spot price
*
*               FL64     vol      The annual volatility of the Spot
*                                 price in percent.
*
*               INTI     nstep    Number of steps in the Binomial Tree
*
*               DISCFAC  *divdf   Term structure of dividend yields
*
*               FUTEQTY  *fute    Equity data
*
*               TREEOPT  *opt     The data defining the option.
*                                 opt->berm assumed as False.
*
*               DISCFAC  *df      Discount function for discounting
*                                 the option payout.
*
*               HOLI_STR *holi    Holiday setup
*
*               DELTASET *ds      Data for delta calculation. Note that
*                                 the dom argument must be True.
*
*    output     BOOLE    *ok      True if all ok , False if not.
*
*    returns    The delta vector allocated as:
*
*                         Alloc_FL64ARRAY(ds->nshock) ;
*
*    diagnostics
*
*    see also   OptEqty_CRR2P()
*               OptEqty_CRR2Impl()
*
*************************************************************************
,,EOH,,*/

/*,,SIC,,

..divdf -> foreign
..df    -> domestic

,,EIC,,*/

FL64ARRAY OptEqty_CRR2Delta(DATESTR* analys,
                        FL64      spot,
                        FL64      vol,
                        INTI      nstep,
                        DISCFAC*   divdf,
                        FUTEQTY*   fute,
                        TREEOPT*   opt,
                        DISCFAC*   df,
                        HOLI_STR*  holi,
                        DELTASET*  ds,
                        BOOLE*     ok)
{
    INTI      i ;
    FL64ARRAY dv ;
    FL64      p0, dum ;
    PLANARRAY old ;
    DATESTR   fsprev, matur ;

    /* Initialise */
    *ok = True ;

    dv = Alloc_FL64ARRAY(ds->nshock) ;
    if (ds->dom == True)
        old = df->disc ;
    else
        old = divdf->disc ;

    /* The unshocked price */
    *ok = OptEqty_CRR2P(analys, spot, vol, nstep, divdf, fute, opt, df,
                        holi, NULL, &p0, &dum, &dum) ;

    /* Find last relevant date */
    matur = opt->dpay.last ;

    for (i = 0; *ok == True && i < ds->nshock; i++)
    {
        fsprev = Disc_get_chgdate(NULL, old, &ds->shock[i]) ;

        if (fsprev.y > 0 && Cldr_DateLT(&matur, &fsprev) == False)
        {
            if (ds->dom == True)
                df->disc = &ds->shock[i] ;
            else
                divdf->disc = &ds->shock[i] ;

            *ok = OptEqty_CRR2P(analys, spot, vol, nstep, divdf, fute, opt, df,
                                holi, NULL, &dv[i], &dum, &dum) ;
            dv[i] -= p0 ;

            if (ds->zero == True && ds->dom == True)
                /* Find shocked Zero PV */
                dv[i] /= Disc_DF2BPV(&ds->mid[i], df, old, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */

            else if (ds->zero == True && ds->dom == False)
                /* Find shocked Zero PV */
                dv[i] /= Disc_DF2BPV(&ds->mid[i], divdf, old, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */

        }
        else
            dv[i] = 0.0 ;
    }

    if (ds->dom == True)
        df->disc = old ;
    else
        divdf->disc = old ;

    return dv ;
}


/*,,SOH,,
*************************************************************************
*
*               OptFX_CRR2Impl()
*
*    interface  #include <opteqty.h>
*               BOOLE OptFX_CRR2Impl(DATESTR  *analys,
*                                    FL64     prem,
*                                    FL64     spot,
*                                    FL64     vol,
*                                    INTI     nstep,
*                                    TREEOPT  *opt,
*                                    DISCFAC  *df_d,
*                                    DISCFAC  *df_f,
*                                    HOLI_STR *holi,
*                                    KEYCONV  key,
*                                    ITERCTRL *ctrl,
*                                    FL64     *impl) ;
*
*    general    The routine calculates various implied quantitites for
*               an option on Currency using the Cox-Ross-Rubinstein
*               binomial method
*
*               Implied ratios are calculated as follows:
*
*                              Implied measure
*                              ---------------
*                                KEY_PRICE
*                                KEY_VOL
*                                KEY_STRIKE
*                                KEY_REPO
*
*               The ctrl parameter is used to control the iteration
*               process. It can defaulted but it is recommended to set
*               the upper and lower bounds or give an initial guess.
*               Tight bounds or a reasonable initial guess will speed up
*               the computations considerably.
*
*               If no solution can be found False is returned.
*
*    input      DATESTR  *analys  Pointer to analysis date (NPV date)
*
*               FL64     prem     Option premium to match
*
*               FL64     spot     The unadjusted spot price
*
*               FL64     vol      The annual volatility of the Spot
*                                 price in percent.
*
*               INTI     nstep    Number of steps in the Binomial Tree
*
*               TREEOPT  *opt     The data defining the option.
*                                 opt->berm assumed as False.
*
*               DISCFAC  *df_d    Discount function in domestic currency*
*
*               DISCFAC  *df_f    Discount function in foreign currency
*
*               HOLI_STR *holi    Holiday setup
*
*               KEYCONV  key      The implied ratio to find
*
*               ITERCTRL *ctrl    Pointer to iteration control data
*
*    output     FL64     *impl    The implied ratio
*
*    returns    True if all is OK, False if not.
*
*    diagnostics
*
*    see also   OptFX_CRR2P()
*
*************************************************************************
,,EOH,,*/

BOOLE OptFX_CRR2Impl(DATESTR* analys,
                     FL64     prem,
                     FL64     spot,
                     FL64     vol,
                     INTI     nstep,
                     TREEOPT*  opt,
                     DISCFAC*  df_d,
                     DISCFAC*  df_f,
                     HOLI_STR* holi,
                     KEYCONV  key,
                     ITERCTRL*  ctrl,
                     FL64*     impl)
{

    BOOLE    ok ;
    FUTEQTY  fute ;

    fute = Set_FUTEQTY(analys, NULL, opt->cal, 0.0, False) ;
    ok   = OptEqty_CRR2Impl(analys, prem, spot, vol, nstep, df_f, &fute, opt,
                            df_d, holi, key, ctrl, impl) ;
    return ok ;
}


/*,,SOH,,
*************************************************************************
*
*               OptCmdty_CRR2Impl()
*
*    interface  #include <opteqty.h>
*               BOOLE OptCmdty_CRR2Impl(DATESTR  *analys,
*                                       FL64     prem,
*                                       FL64     spot,
*                                       FL64     vol,
*                                       INTI     nstep,
*                                       TREEOPT  *opt,
*                                       DISCFAC  *conv_df,
*                                       DISCFAC  *stor_df,
*                                       FUTCMDTY *futc,
*                                       DISCFAC  *df,
*                                       HOLI_STR *holi,
*                                       KEYCONV  key,
*                                       ITERCTRL *ctrl,
*                                       FL64     *impl) ;
*
*    general    The routine calculates various implied quantitites for
*               an option on Commodity using the Cox-Ross-Rubinstein
*               binomial
*
*               Implied ratios are calculated as follows:
*
*                              Implied measure
*                              ---------------
*                                KEY_PRICE
*                                KEY_VOL
*                                KEY_STRIKE
*                                KEY_REPO
*
*               Convenience Yields and Storage Costs may be entered in
*               two ways:
*
*                i) as a discount function
*                ii) as discrete amounts (% of underlying price)
*
*               The ctrl parameter is used to control the iteration
*               process. It can defaulted but it is recommended to set
*               the upper and lower bounds or give an initial guess.
*               Tight bounds or a reasonable initial guess will speed up
*               the computations considerably.
*
*               If no solution can be found False is returned.
*
*    input      DATESTR  *analys  Pointer to analysis date (NPV date)
*
*               FL64     prem     Option premium to match
*
*               FL64     spot     The unadjusted spot price
*
*               FL64     vol      The annual volatility of the Spot
*                                 price in percent.
*
*               INTI     nstep    Number of steps in the Binomial Tree
*
*               TREEOPT  *opt     The data defining the option.
*                                 opt->berm assumed as False.
*
*               DISCFAC  *conv_df Discount function of convenience
*                                 yields
*
*               DISCFAC  *stor_df Discount function of storage costs
*
*               FUTCMDTY *futc    Commodity data
*
*               DISCFAC  *df      Discount function setup.
*
*               HOLI_STR *holi    Holiday setup
*
*               KEYCONV  key      The implied ratio to find
*
*               ITERCTRL *ctrl    Pointer to iteration control data.
*
*    output     FL64     *impl    The implied ratio
*
*    returns    True if all is OK, False if not.
*
*    diagnostics
*
*    see also   OptCmdty_CRR2P()
*
*************************************************************************
,,EOH,,*/

BOOLE OptCmdty_CRR2Impl(DATESTR* analys,
                     FL64     prem,
                     FL64     spot,
                     FL64     vol,
                     INTI     nstep,
                     TREEOPT*  opt,
                     DISCFAC*  conv_df,
                     DISCFAC*  stor_df,
                     FUTCMDTY* futc,
                     DISCFAC*  df,
                     HOLI_STR* holi,
                     KEYCONV  key,
                     ITERCTRL*  ctrl,
                     FL64*     impl)
{
    PLANARRAY cc ;
    DISCFAC   cc_df ;
    BOOLE     ok ;
    PLAN_STR  ps[2] ;
    INTI      ind[2] ;
    FL64      wgt[2] ;
    FUTEQTY   fute ;

    /* Merge the PLAN_STR's 'conv' and 'stor' */
    if (futc->cy != NULL)
        ps[0] = *(futc->cy) ;
    else
        ps[0].filled = 0 ;

    if (futc->stc != NULL)
        ps[1] = *(futc->stc) ;
    else
        ps[1].filled = 0 ;

    ind[0] = 0 ;
    ind[1] = 1 ;
    wgt[0] = 1.0 ;           /* Add Convenience Yield */
    wgt[1] = -1.0 ;          /* Subtract Storage Costs */
    cc = Cflw_MergePLANARRAY(ps, ind, wgt, 2) ;

    /* Combine the DISCFAC's 'conv_df' and 'stor_df' */
    cc_df = Disc_MergeDF(conv_df, stor_df, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */

    /* Finally we can do the calculation */
    fute = Set_FUTEQTY(&futc->matur, cc, futc->cal, 0.0, False) ;
    ok   = OptEqty_CRR2Impl(analys, prem, spot, vol, nstep, &cc_df, &fute,
                            opt, df, holi, key, ctrl, impl) ;

    /* Free */
    Free_PLANARRAY(cc, 1) ;
    Free_PLANARRAY(cc_df.disc, 1) ;

    return ok ;
}


/*,,SOH,,
*************************************************************************
*
*               OptEqty_CRR2Impl()
*
*    interface  #include <opteqty.h>
*               BOOLE OptEqty_CRR2Impl(DATESTR  *analys,
*                                      FL64     prem,
*                                      FL64     spot,
*                                      FL64     vol,
*                                      INTI     nstep,
*                                      DISCFAC  *divdf,
*                                      FUTEQTY  *fute,
*                                      TREEOPT  *opt,
*                                      DISCFAC  *df,
*                                      HOLI_STR *holi,
*                                      KEYCONV  key,
*                                      ITERCTRL *ctrl,
*                                      FL64     *impl) ;
*
*    general    The routine calculates various implied quantitites for
*               an option on Equity (stock or stock index) using the
*               Cox-Ross-Rubinstein method
*
*               Implied ratios are calculated as follows:
*
*                              Implied measure
*                              ---------------
*                                KEY_PRICE
*                                KEY_VOL
*                                KEY_STRIKE
*                                KEY_REPO
*
*               Dividends may be entered in two ways:
*                i) as a PLAN_STR of discrete amounts
*                ii) as a DISCFAC
*
*               The ctrl parameter is used to control the iteration
*               process. It can defaulted but it is recommended to set
*               the upper and lower bounds or give an initial guess.
*               Tight bounds or a reasonable initial guess will speed up
*               the computations considerably.
*
*               If no solution can be found False is returned.
*
*    input      DATESTR  *analys  Pointer to analysis date (NPV date)
*
*               FL64     prem     Option premium to match
*
*               FL64     spot     The unadjusted spot price
*
*               FL64     vol      The annual volatility of the Spot
*                                 price in percent.
*
*               INTI     nstep    Number of steps in the Binomial Tree
*
*               DISCFAC  *divdf   the term structure of dividend yields
*
*               FUTEQTY  *fute    Equity data
*
*               TREEOPT  *opt     The data defining the option.
*                                 opt->berm assumed as False.
*
*               DISCFAC  *df      Discount function setup.
*
*               HOLI_STR *holi    Holiday setup
*
*               KEYCONV  key      The implied ratio to find
*
*               ITERCTRL *ctrl    Pointer to iteration control data.
*
*    output     FL64     *impl    The implied ratio
*
*    returns    True if all is OK, False if not.
*
*    diagnostics
*
*    see also   OptEqty_CRR2P()
*
*    wrapper    AP
*
*************************************************************************
,,EOH,,*/


BOOLE OptEqty_CRR2Impl(DATESTR* analys,
                     FL64     prem,
                     FL64     spot,
                     FL64     vol,
                     INTI     nstep,
                     DISCFAC*  divdf,
                     FUTEQTY*  fute,
                     TREEOPT*  opt,
                     DISCFAC*  df,
                     HOLI_STR* holi,
                     KEYCONV  key,
                     ITERCTRL*  ctrl,
                     FL64*     impl)
{
    BOOLE    ok ;
    TSARRAY  ts, fts ;
    DATESTR  d1, d2 ;

    *impl = 0.0 ;

    if (GetPlanFill(df->disc) <= 0)
        return False ;

    ts  = Disc_DF2TS(df->disc->day + 1, GetPlanFill(df->disc) - 1, df, NULL,
                     df->irr, df->freq, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */

    if (GetPlanFill(divdf->disc) > 0)
        fts = Disc_DF2TS(divdf->disc->day + 1, GetPlanFill(divdf->disc) - 1, 
                         divdf, NULL, divdf->irr, divdf->freq, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
    else
        /* fts mustn't be NULL, hence we allocate an empty struct. */
        fts = Alloc_TSARRAY(1, 0) ;

    d1 = Cldr_NextBusinessDate(&opt->dpay.first, holi) ;
    d2 = Cldr_NextBusinessDate(&opt->dpay.last, holi) ;

    ok = CRR_Implied(prem, analys, &d1, &d2, opt->pay_delay, nstep, spot, 
                     opt->strike, vol, ts, df->iconv, opt->type, fts, 
                     divdf->iconv, fute->div, key, opt->cal, ctrl, impl, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */

    Free_TSARRAY(ts, 1) ;
    Free_TSARRAY(fts, 1) ;

    return ok ;
}



/*,,SOH,,
*************************************************************************
*
*               OptExch_CRR2Impl()
*
*    interface  #include <opteqty.h>
*               BOOLE OptExch_CRR2Impl(DATESTR  *analys,
*                                      FL64     prem,
*                                      FL64     spot1,
*                                      FL64     spot2,
*                                      FL64     vol1,
*                                      FL64     vol2,
*                                      FL64     corr,
*                                      DISCFAC  *divyld1,
*                                      DISCFAC  *divyld2,
*                                      PLAN_STR *plan1,
*                                      PLAN_STR *plan2,
*                                      INTI     nstep,
*                                      TREEOPT  *opt,
*                                      HOLI_STR *holi,
*                                      KEYCONV  key,
*                                      ITERCTRL *ctrl,
*                                      FL64     *impl) ;
*               
*    general     The routine calculates implied ratios for American
*                style exchange options using the Cox-Ross-Rubinstein
*                binomial method.
*
*                The following implied ratios can be calculated
*
*                    key         implied
*                    ------      ---------
*                    KEY_VOL     correlation
* 
*                Note that it is possible to enter both continuous and
*                and discrete dividends for each asset.
*
*                The ctrl parameter is used to control the iteration
*                process. It can defaulted but it is recommended to set
*                the upper and lower bounds or give an initial guess.
*                Tight bounds or a reasonable initial guess will speed up
*                the computations considerably.
* 
*    input       DATESTR  *analys  Analysis date (NPV date)
*
*                FL64     prem     Premium of option
* 
*                FL64     spot1    Price of asset 1
*
*                FL64     spot2    Price of asset 2
*
*                FL64     vol1     Annual volatility of asset 1 (pct)
*
*                FL64     vol2     Annual volatility of asset 2 (pct)
*
*                FL64     corr     Correlation between asset 1 and 2
*
*                DISCFAC  *divyld1 Dividend yield of asset 1 -- enter
*                                  as discount factors
*
*                DISCFAC  *divyld2 Dividend yield of asset 2 -- enter
*                                  as discount factors
*
*                PLAN_STR *plan1   Plan of discrete dividend payments
*                                  for asset 1
* 
*                PLAN_STR *plan2   Plan of discrete dividend payments
*                                  for asset 2
*
*                INTI     nstep    Number of steps in the binomial tree
*
*                TREEOPT  *opt     Definition of the option
*                                  Note that strike is irrelevant
*
*                HOLI_STR *holi    Holiday setup
*
*                KEYCONV  key      The implied ratio to find
*
*                ITERCTRL *ctrl    Pointer to iteration control data.
*
*    output      FL64     *impl    Implied ratio
*
*    returns     BOOLE    *ok      True if all ok , False if not
*
*    diagnostics
*
*    see also    OptExch_CRR2P()
*
*************************************************************************
,,EOH,,*/

BOOLE OptExch_CRR2Impl(DATESTR  *analys,
                       FL64     prem,
                       FL64     spot1,
                       FL64     spot2,
                       FL64     vol1,
                       FL64     vol2,
                       FL64     corr,
                       DISCFAC  *divyld1,
                       DISCFAC  *divyld2,
                       PLAN_STR *plan1,
                       PLAN_STR *plan2,
                       INTI     nstep,
                       TREEOPT  *opt,
                       HOLI_STR *holi,
                       KEYCONV  key,
                       ITERCTRL *ctrl,
                       FL64     *impl)

{
    BOOLE        ok ;
    DATESTR      d1, d2 ;
    INTI         ind[2] ;
    FL64         wgt[2] ;
    FL64         spot, vol, pr ;
    PLANARRAY    div ;
    PLAN_STR     ps[2] ;
    TSARRAY      ts, fts ;
    FL64         temp ;

      /* Warning avoidance */
    *impl = 0.0 ;
    ok = True ;

      /* Merge dividend plans (plan1 - plan2) */
    if (plan1 != NULL)
        ps[0] = *plan1 ;
    else
        ps[0].filled = 0 ;

    if (plan2 != NULL)
        ps[1] = *plan2 ;
    else
        ps[1].filled = 0 ;

    ind[0] = 0 ;
    ind[1] = 1 ;
    wgt[0] = 1.0 ;
    wgt[1] = -1.0 ;

    div    = Cflw_MergePLANARRAY(ps, ind, wgt, 2) ;

      /* Spot and vol of the martingale process -- spot1 as numeraire */
    spot = spot2 / spot1 ;
    vol  = Vol_Bivariate2Vol(vol1, vol2, corr);
    
      /* Dividend yield 1 must be interpretted as interest rate */
    if (GetPlanFill(divyld1->disc) > 0)
      ts = Disc_DF2TS(divyld1->disc->day + 1,
                      GetPlanFill(divyld1->disc) - 1,
					  divyld1, NULL, divyld1->irr, divyld1->freq, holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */
    else
      ts = Alloc_TSARRAY(1, 1) ;

      /* Dividend yield 2 must be interpretted as the payout
           rate of the underlying */
    if (GetPlanFill(divyld2->disc) > 0)
      fts = Disc_DF2TS(divyld2->disc->day + 1,
                       GetPlanFill(divyld2->disc) - 1,
                       divyld2, NULL, divyld2->irr, divyld2->freq, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
    else
      fts = Alloc_TSARRAY(1, 1) ;

    d1 = Cldr_NextBusinessDate(&opt->dpay.first, holi) ;
    d2 = Cldr_NextBusinessDate(&opt->dpay.last, holi) ;

      /* We have changed numaraire now */
    pr = prem / spot1 ;

    ok = CRR_Implied(pr, analys, &d1, &d2, opt->pay_delay, nstep, spot, 
                     1.0, vol, ts, divyld1->iconv, opt->type, fts, 
                     divyld2->iconv, div, key, opt->cal, ctrl, impl, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */

    if (key == KEY_VOL)
    {
      temp = 2 * vol1 * vol2 ;
      if (fabs(temp) > 1e-4)
        *impl =  (SQR(vol1) + SQR(vol2) - SQR(*impl)) / temp ;
      else
        ok = False ;
    }

      /* Clean up */
    Free_PLANARRAY(div, 1) ;
    Free_TSARRAY(ts, 1) ;
    Free_TSARRAY(fts, 1) ;

    return ok ;
}



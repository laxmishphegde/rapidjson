/* SCID @(#)optfx.c	1.7 (SimCorp) 99/10/12 15:42:56 */

/************************************************************************
*
*   project     SCecon
*
*   filename    optfx.c
*
*   contains    routines to be included in the SCecon Library for
*               evaluating options on FX forward contracts
*
************************************************************************/

/***** includes ********************************************************/
#include <option.h>
#include <opteqty.h>

/***** defines  ********************************************************/
#define PAYM_TOL  1.0E-10
#define SHOCKSIZE 0.01
#define MAXIT   100
#define ACC_PRICE 0.001
#define ACC_RATE  0.0001
#define ACC_TERM  0.000001
#define LOW_BOUND 0.0001

/***** functions *******************************************************/


/*,,SOH,,
*************************************************************************
*
*               OptFutFX_Black2P()
*
*    interface  #include <opteqty.h>
*               FL64 OptFutFX_Black2P(DATESTR  *analys,
*                                     DATESTR  *voldate,
*                                     FL64     futp,
*                                     FL64     vol,
*                                     OPTFUT   *opt,
*                                     DISCFAC  *df,
*                                     HOLI_STR *holi,
*                                     RISKSET  *risk,
*                                     FL64     *dp,
*                                     FL64     *ddp) ;
*
*    general    The routine computes the premium for an option on
*               a currency forward - using the Garman/Kohlhagen
*               formula for a European option. In addition some of
*               the Greek numbers can be computed.
*
*               Key ratios are calculated as follows:
*
*                   risk->key      dp          ddp
*                   ---------      ---         ----
*                   KEY_PRICE      Delta       Gamma
*                   KEY_PROB       Delta       Gamma
*                   KEY_MATURITY   Theta       N/A
*                   KEY_VOL        Vega        d(Vega)/d(Vol)
*                   KEY_STRIKE     d(P)/d(C)   d2(P)/d(C)2
*                   KEY_REPO       Rho         d(rho)/d(r)
*                   -----------------------------------------
*
*               The KEY_PROB numbers are alternative definitions of
*               delta and gamma. And express the in-the-moneyness of a
*               option (delta), and the sensitivity of this (gamma) to
*               variations in the underlying variable.
*
*               Rho is wrt to the domestic interest rate.
*
*    input      DATESTR  *analys  Pointer to analysis date (NPV date)
*
*               DATESTR  *voldate Vol calculated from this date
*
*               FL64     futp     The FX forward Exchange Rate.
*                                 Quoted on analys.
*                                 Quoted directly in base 1 in domestic
*                                 currency per foreing currency units.
*
*               FL64     vol      The annual volatility of the futures
*                                 price in percent.
*
*               OPTFUT   *opt     The data defining the option.
*                                 ->oadd must be NO_OPTADD
*
*               DISCFAC  *df      Domestic discount function
*                                 For CALL - PUT CCY Curve
*                                 For PUT  - CALL CCY Curve
*
*               HOLI_STR *holi    Holiday setup
*
*               RISKSET  *risk    The risk ratio definitions
*                                 Use NULL for no Greeks
*
*    output     FL64     *dp      Pointer to the first order derivative.*
*
*               FL64     *ddp     Pointer to the second order derivative*
*
*    returns    The option premium.
*               For CALL - PUT CCY units
*               For PUT  - CALL CCY units
*
*    diagnostics
*
*    see also   Option_Black2P()                                 
*               OptFX_Black2P()
*               OptFutFX_Black2Impl()
*
*    wrapper    AP
*
*************************************************************************
,,EOH,,*/

FL64 OptFutFX_Black2P(DATESTR* analys,
                    DATESTR* voldate,
                    FL64    futp,
                    FL64    vol,
                    OPTFUT*  opt,
                    DISCFAC* df,
                    HOLI_STR* holi,
                    RISKSET* risk,
                    FL64*    dp,
                    FL64*    ddp)
{
    FL64 p ;

    /* Call the Standard Black Calculator */
    p = Option_Black2P(analys, voldate, futp, False, 1.0, vol, opt, df,
                       holi, risk, dp, ddp) ;
    return p ;
}


/*,,SOH,,
*************************************************************************
*
*               OptFutFX_Black2DFp()
*
*    interface  #include <opteqty.h>
*               FL64 OptFutFX_Black2DFp(DATESTR  *analys,
*                                       DATESTR  *voldate,
*                                       FL64     vol,
*                                       FL64     fx_spot,
*                                       DATESTR  *spot,
*                                       OPTFUT   *opt,
*                                       DISCFAC  *df_d,
*                                       DISCFAC  *df_f,
*                                       HOLI_STR *holi,
*                                       RISKSET  *risk,
*                                       FL64     *dp,
*                                       FL64     *ddp) ;
*
*    general    The routine computes the premium for an option on
*               a currency forward - using the Garman/Kohlhagen
*               formula for a European option.
*
*               Key ratios are calculated as follows:
*
*                   risk->key      dp          ddp
*                   ---------      ---         ----
*                   KEY_DF         $Duration   $Convexity
*                   KEY_BPV        BPV
*
*               If risk->dom is True then these ratios are wrt domestic
*               Zero Curve, and if risk->dom is False then the ratios
*               are wrt the foreign Zero Curve.
*
*    input      DATESTR  *analys  Pointer to analysis date (NPV date)
*
*               DATESTR  *voldate Vol calculated from this date
*
*               FL64     vol      The annual volatility of the FX
*                                 spot price in percent.
*
*               FL64     fx_spot  Spot exchange rate. Price in domes-
*                                 tic currency of foreign currency units*
*
*               DATESTR  *spot    The date for fx_spot
*
*               OPTFUT   *opt     The data defining the option.
*
*               DISCFAC  *df_d    Domestic discount function
*                                 For CALL - PUT CCY Curve
*                                 For PUT  - CALL CCY Curve
*
*               DISCFAC  *df_f    Foreign discount function
*                                 For CALL - CALL CCY Curve
*                                 For PUT  - PUT CCY Curve
*
*               HOLI_STR *holi    Holiday setup
*
*               RISKSET  *risk    The risk ratio definitions.
*                                 Use NULL for no Greeks
*
*    output     FL64     *dp      Pointer to the first order derivative.*
*
*               FL64     *ddp     Pointer to the second order derivative*
*
*    returns    The option premium.
*               For CALL - PUT CCY units
*               For PUT  - CALL CCY units
*
*    diagnostics
*
*    see also   OptFutFX_Black2P()
*               OptFutFX_Black2Impl()
*
*    wrapper    AP
*
*************************************************************************
,,EOH,,*/

FL64 OptFutFX_Black2DFp(DATESTR* analys,
                      DATESTR*  voldate,
                      FL64     vol,
                      FL64     fx_spot,
                      DATESTR*  spot,
                      OPTFUT*   opt,
                      DISCFAC*  df_d,
                      DISCFAC*  df_f,
                      HOLI_STR* holi,
                      RISKSET*  risk,
                      FL64*     dp,
                      FL64*     ddp)
{
    return OptFX_Black2P(analys, voldate, vol, fx_spot, spot, opt, df_d, df_f,
                         holi, risk, dp, ddp) ;
}


/*,,SOH,,
*************************************************************************
*
*               OptFX_Black2P()
*
*    interface  #include <opteqty.h>
*               FL64 OptFX_Black2P(DATESTR  *analys,
*                                  DATESTR  *voldate,
*                                  FL64     vol,
*                                  FL64     fx_spot,
*                                  DATESTR  *spot,
*                                  OPTFUT   *opt,
*                                  DISCFAC  *df_d,
*                                  DISCFAC  *df_f,
*                                  HOLI_STR *holi,
*                                  RISKSET  *risk,
*                                  FL64     *dp,
*                                  FL64     *ddp) ;
*
*    general    The routine computes the premium for an option on
*               a currency - using the Garman/Kohlhagen
*               formula for a European option.
*
*               Key ratios are calculated as follows:
*
*                   risk->key      dp          ddp
*                   ---------      ---         ----
*                   KEY_DF         $Duration   $Convexity
*                   KEY_BPV        BPV
*                   KEY_REPO       Rho         d(Rho)/d(Repo)
*                   KEY_SPOT       Delta       Gamma
*                   KEY_PROB       Delta       Gamma
*                   KEY_VOL        Vega        d(Vega)/d(Vol)
*                   KEY_MATURITY   Theta       N/A
*
*               If risk->dom is True then these ratios are wrt domestic
*               Zero Curve, and if risk->dom is False then the ratios
*               are wrt the foreign Zero Curve.
*
*               The Delta/Gamma's are wrt the Spot FX rate. KEY_SPOT
*               uses a central difference approximation approach and
*               KEY_PROB returns the classic Black Scholes delta N(d1).
*               For the general case KEY_SPOT is the recommended setting. 
*
*    input      DATESTR  *analys  Pointer to analysis date (NPV date)
*
*               DATESTR  *voldate Vol calculated from this date
*
*               FL64     vol      The annual volatility of the FX
*                                 spot price in percent.
*
*               FL64     fx_spot  Spot exchange rate. Price in domes-
*                                 tic currency of foreign currency units*
*
*               DATESTR  *spot    The date for fx_spot
*
*               OPTFUT   *opt     The data defining the option.
*
*               DISCFAC  *df_d    Domestic discount function
*                                 For CALL - PUT CCY Curve
*                                 i.e. the currency paid
*                                 For PUT  - CALL CCY Curve
*                                 i.e. the currency received
*
*               DISCFAC  *df_f    Foreign discount function
*                                 For CALL - CALL CCY Curve
*                                 i.e. the currency received
*                                 For PUT  - PUT CCY Curve
*                                 i.e. the currency paid
*
*               HOLI_STR *holi    Holiday setup
*
*               RISKSET  *risk    The risk ratio definitions.
*                                 Use NULL for no Greeks
*
*    output     FL64     *dp      Pointer to the first order derivative.*
*
*               FL64     *ddp     Pointer to the second order derivative*
*
*    returns    The option premium.
*               The premium is returned pr notional 
*               quoted in domestic currency units
*               (NB: notional is quoted in foreign currency units)
*
*               In CALL CCY/PUT CCY terms this means:
*               For CALL - PUT CCY units
*               For PUT  - CALL CCY units
*
*    diagnostics
*
*    see also   Option_Black2P()                                 
*               OptFutFX_Black2P()
*               OptFutFX_Black2Impl()
*
*    wrapper    AP
*
*************************************************************************
,,EOH,,*/

FL64 OptFX_Black2P(DATESTR* analys,
                     DATESTR*  voldate,
                     FL64     vol,
                     FL64     fx_spot,
                     DATESTR*  spot,
                     OPTFUT*   opt,
                     DISCFAC*  df_d,
                     DISCFAC*  df_f,
                     HOLI_STR* holi,
                     RISKSET*  risk,
                     FL64*     dp,
                     FL64*     ddp)
{
    FL64     f1, f2, dsc, adj, shock, p, phi, plo, dum, size, fx_tmp ;
    DISCFAC  sdf, sdf_d, sdf_f ;
    BOOLE    ok ;
    OPTFUT   ofut ;
    FXFORW   fxfw ;
    DATESTR  anld, vold, spotd ;

    /* warning avoidance */
    phi = plo = 0.0;

    p = *dp = *ddp = 0.0 ;

    /* First find fx_spot/fx_tmp on 'analys' */
    fxfw   = Set_FXFORW(analys, False, 1.0, 1.0, False, ACT360) ;
    fx_tmp = FutFX_DF2FXrate(spot, fx_spot, &fxfw, True, holi, df_d, df_f) ;

	/* PMSTA-22396 - SRIDHARA � 160502 */
    adj = Disc_Interpolation(&opt->dfix, df_f, holi) ;
    ok  = Disc_forwval(df_f, analys, &adj, holi) ;

    /* The option premium is: */
    if (opt->oadd != FWDSTART)
    {
        if (risk != NULL && (risk->key == KEY_SPOT || risk->key == KEY_VOL ||
          risk->key == KEY_PROB))
            p = Option_Black2P(analys, voldate, fx_tmp, True, adj, vol, opt,
                               df_d, holi, risk, dp, ddp) ;
        else
            p = Option_Black2P(analys, voldate, fx_tmp, True, adj, vol, opt,
                               df_d, holi, NULL, &dum, &dum) ;
    }
    else
    {
        /* Rule out dumb cases */
        if (Cldr_DateLE(&opt->fwdst.dset, analys) == True)
            return 0.0 ;

        /* Find the forward price on setting date */
        fxfw = Set_FXFORW(&opt->fwdst.dset, False, 1.0, 1.0, False, ACT360);
        f1   = FutFX_DF2FXrate(analys, fx_spot, &fxfw, True, holi, df_d, df_f) ;

        /* Find the forward price on expiry date */
        fxfw = Set_FXFORW(&opt->dfix, False, 1.0, 1.0, False, ACT360) ;
        f2   = FutFX_DF2FXrate(analys, fx_spot, &fxfw, True, holi, df_d, df_f) ;

        ofut = Set_OPTFUT(opt->type, opt->fwdst.alpha * f1,
                          &opt->dfix, &opt->dpay, UP_FRONT, opt->cal) ;

        /* Call the Standard Black Calculator - for this case */
        if (risk != NULL && risk->key == KEY_PROB)
          p = Option_Black2P(&opt->fwdst.dset, &opt->fwdst.dset, f2, False, 
                             1.0, vol, &ofut, df_d, holi, risk, dp, ddp) ;
        else
          p = Option_Black2P(&opt->fwdst.dset, &opt->fwdst.dset, f2, False, 
                             1.0, vol, &ofut, df_d, holi, NULL, dp, ddp) ;

        /* Discount from forward starting date */
		/* PMSTA-22396 - SRIDHARA � 160502 */
        dsc = Disc_Interpolation(&opt->fwdst.dset, df_d, holi) ;
        Disc_forwval(df_d, analys, &dsc, holi) ;
        p *= dsc ;

        if (risk == NULL)
            return p ;

        /* Be careful about risk ratios for fwd starts - do it specially */
        if (risk->risk != ZERO_ORDER && (risk->key == KEY_SPOT || 
            risk->key == KEY_VOL))
        {
            size = Scutl_Default_Shock(risk->shock, risk->key) ;

            if (risk->key == KEY_SPOT)
            {
                phi = OptFX_Black2P(analys, voldate, vol, size + fx_spot, spot,
                                    opt, df_d, df_f, holi, NULL, &dum, &dum) ;
                plo = OptFX_Black2P(analys, voldate, vol, -size + fx_spot, spot,
                                    opt, df_d, df_f, holi, NULL, &dum, &dum) ;
            }

            else if (risk->key == KEY_VOL)
            {
                phi = OptFX_Black2P(analys, voldate, vol + size , fx_spot, spot,
                                    opt, df_d, df_f, holi, NULL, &dum, &dum) ;

                plo = OptFX_Black2P(analys, voldate, vol - size, fx_spot, spot,
                                    opt, df_d, df_f, holi, NULL, &dum, &dum) ;
            }

            *dp = (phi - plo) / (2.0 * size) ;
            if (risk->risk == SECOND_ORDER)
                *ddp = (phi + plo - 2.0 * p) / SQR(size) ;
        }
    }

    if (risk == NULL)
        return p ;

    /* Risk ratios */
    if (ok == True && risk->risk != ZERO_ORDER &&
        risk->key != KEY_SPOT && risk->key != KEY_VOL && 
        risk->key != KEY_PROB)
    {
        shock = Scutl_Default_Shock(risk->shock, risk->key) ;

        if (risk->key == KEY_BPV || risk->key == KEY_DF || 
            risk->key == KEY_REPO)
        {
            /* Note that for FX Options Rho and $Duration is the same thing */
            if (risk->dom == True)
            {
				/* PMSTA-22396 - SRIDHARA � 160502 */
                sdf = Disc_ShockRates(df_d, 1.0, risk, holi) ;
                phi = OptFX_Black2P(analys, voldate, vol, fx_spot, spot, opt,
                                    &sdf, df_f, holi, NULL, &dum, &dum) ;
            }
            else
            {
				/* PMSTA-22396 - SRIDHARA � 160502 */
                sdf = Disc_ShockRates(df_f, 1.0, risk, holi) ;
                phi = OptFX_Black2P(analys, voldate, vol, fx_spot, spot, opt,
                                    df_d, &sdf, holi, NULL, &dum, &dum) ;
            }

            Free_PLANARRAY(sdf.disc, 1) ;

            if (risk->dom == True)
            {
				/* PMSTA-22396 - SRIDHARA � 160502 */
                sdf = Disc_ShockRates(df_d, -1.0, risk, holi) ;
                plo = OptFX_Black2P(analys, voldate, vol, fx_spot, spot, opt,
                                    &sdf, df_f, holi, NULL, &dum, &dum) ;
            }
            else
            {
				/* PMSTA-22396 - SRIDHARA � 160502 */
                sdf = Disc_ShockRates(df_f, -1.0, risk, holi) ;
                plo = OptFX_Black2P(analys, voldate, vol, fx_spot, spot, opt,
                                    df_d, &sdf, holi, NULL, &dum, &dum) ;
            }

            Free_PLANARRAY(sdf.disc, 1) ;

            if (risk->key == KEY_BPV)
                shock = 1.0 ;

            *dp = - (plo - phi) / (2.0 * shock) ;
            if (risk->risk == SECOND_ORDER && 
              (risk->key == KEY_DF || risk->key == KEY_REPO))
                *ddp = (phi + plo - 2.0 * p) / SQR(shock) ;

        }

        else if (risk->key == KEY_MATURITY)
        {
            /* Let time decay -> and reflect this in the dates of the DF's.
               Ie. we move the entire Term Structure of interest rates. */
			/* PMSTA-22396 - SRIDHARA � 160502 */
            sdf_d = Disc_Shock_Dates(df_d, (INTI) shock, holi) ;
            sdf_f = Disc_Shock_Dates(df_f, (INTI) shock, holi) ;

            anld  = Cldr_AddDays(analys, (INTL) shock, opt->cal, holi) ;
            vold  = Cldr_AddDays(voldate, (INTL) shock, opt->cal, holi) ;
            spotd = Cldr_AddDays(spot, (INTL) shock, opt->cal, holi) ;

            plo = OptFX_Black2P(&anld, &vold, vol, fx_spot, &spotd, opt,
                                &sdf_d, &sdf_f, holi, NULL, &dum, &dum) ;

            /* Do not set ddp */
            *dp = (plo - p) / shock ;

            if (risk->key == KEY_MATURITY)
                *dp *= Cldr_DaysPerYear(analys, analys, 0, opt->cal, LAST, holi) ;   /* PMSTA-22396 - SRIDHARA � 160502 */

            Free_PLANARRAY(sdf_d.disc, 1) ;
            Free_PLANARRAY(sdf_f.disc, 1) ;
        }
    }

    return p ;
}


/*,,SOH,,
*************************************************************************
*
*               OptFutFX_Black2Delta()
*
*    interface  #include <opteqty.h>
*               FL64ARRAY OptFutFX_Black2Delta(DATESTR    *analys,
*                                              DATESTR    *voldate,
*                                              FL64       vol,
*                                              FL64       fx_spot,
*                                              DATESTR    *spot,
*                                              OPTFUT     *opt,
*                                              DISCFAC    *df_d,
*                                              DISCFAC    *df_f,
*                                              HOLI_STR   *holi,
*                                              DELTASET   *ds) ;
*
*    general    The routine computes the delta vector for an option on
*               a currency forward - using the Garman/Kohlhagen
*               formula for a European option and a list of predefined
*               shocks to the Zero Curves.
*
*               The delta vector represents the price differences
*               invoked by the curve shocks.
*
*    input      DATESTR   *analys  Pointer to analysis date (NPV date)
*
*               DATESTR   *voldate Vol calculated from this date
*
*               FL64      vol      The annual volatility of the FX
*                                  forward price in percent.
*
*               FL64      fx_spot  Spot exchange rate. Price in domes-
*                                  tic currency of foreign currency units
*
*               DATESTR   *spot    The date for fx_spot
*
*               OPTFUT    *opt     The data defining the option.
*
*               DISCFAC   *df_d    Domestic discount function
*                                  For CALL - PUT CCY Curve
*                                  For PUT  - CALL CCY Curve
*
*               DISCFAC   *df_f    Foreign discount function
*                                  For CALL - CALL CCY Curve
*                                  For PUT  - PUT CCY Curve
*
*               HOLI_STR  *holi    Holiday setup
*
*               DELTASET  *ds      Delta-vector defining data
*                                  Relates to df_d or df_f depending
*                                  on ds->dom.
*
*    output
*
*    returns    The delta vector allocated as:
*
*                         Alloc_FL64ARRAY(ds->nshock) ;
*
*               For CALL - PUT CCY units
*               For PUT  - CALL CCY units
*
*    diagnostics
*
*    see also   OptFutFX_Black2P()
*
*    wrapper    AP
*
*************************************************************************
,,EOH,,*/


FL64ARRAY OptFutFX_Black2Delta(DATESTR* analys,
                    DATESTR*  voldate,
                    FL64     vol,
                    FL64     fx_spot,
                    DATESTR*  spot,
                    OPTFUT*   opt,
                    DISCFAC*  df_d,
                    DISCFAC*  df_f,
                    HOLI_STR* holi,
                    DELTASET* ds)
{
    return OptFX_Black2Delta(analys, voldate, vol, fx_spot, spot, opt, df_d,
                             df_f, holi, ds) ;
}


/*,,SOH,,
*************************************************************************
*
*               OptFX_Black2Delta()
*
*    interface  #include <opteqty.h>
*               FL64ARRAY OptFX_Black2Delta(DATESTR    *analys,
*                                           DATESTR    *voldate,
*                                           FL64       vol,
*                                           FL64       fx_spot,
*                                           DATESTR    *spot,
*                                           OPTFUT     *opt,
*                                           DISCFAC    *df_d,
*                                           DISCFAC    *df_f,
*                                           HOLI_STR   *holi,
*                                           DELTASET   *ds) ;
*
*    general    The routine computes the delta vector for an option on
*               a currency - using the Garman/Kohlhagen
*               formula for a European option and a list of predefined
*               shocks to the Zero Curves.
*
*               The delta vector represents the price differences
*               invoked by the curve shocks.
*
*    input      DATESTR   *analys Pointer to analysis date (NPV date)
*
*               DATESTR  *voldate Vol calculated from this date
*
*               FL64      vol     The annual volatility of the FX
*                                 forward price in percent.
*
*               FL64      fx_spot Spot exchange rate. Price in domes-
*                                 tic currency of foreign currency units*
*
*               DATESTR   *spot   The date for fx_spot
*
*               OPTFUT    *opt    The data defining the option.
*
*               DISCFAC   *df_d   Domestic discount function
*                                 For CALL - PUT CCY Curve
*                                 For PUT  - CALL CCY Curve
*
*               DISCFAC   *df_f   Foreign discount function
*                                 For CALL - CALL CCY Curve
*                                 For PUT  - PUT CCY Curve
*
*               HOLI_STR  *holi   Holiday setup
*
*               DELTASET  *ds     Delta-vector defining data
*                                 Relates to df_d or df_f depending
*                                 on ds->dom.
*
*    output
*
*    returns    The delta vector allocated as:
*
*                         Alloc_FL64ARRAY(ds->nshock) ;
*
*               For CALL - PUT CCY units
*               For PUT  - CALL CCY units
*
*    diagnostics
*
*    see also   OptFX_Black2P()
*
*    wrapper    AP
*
*************************************************************************
,,EOH,,*/

FL64ARRAY OptFX_Black2Delta(DATESTR* analys,
                    DATESTR*  voldate,
                    FL64     vol,
                    FL64     fx_spot,
                    DATESTR*  spot,
                    OPTFUT*   opt,
                    DISCFAC*  df_d,
                    DISCFAC*  df_f,
                    HOLI_STR* holi,
                    DELTASET* ds)
{
    INTI      i ;
    FL64ARRAY dv ;
    FL64      p0, dum ;
    PLANARRAY old ;
    DATESTR   fsprev, matur ;

    /* Initialise */
    dv = Alloc_FL64ARRAY(ds->nshock) ;
    if (ds->dom == True)
        old = df_d->disc ;
    else
        old = df_f->disc ;

    /* The unshocked price */
    p0 = OptFX_Black2P(analys, voldate, vol, fx_spot, spot, opt, df_d, df_f,
                       holi, NULL, &dum, &dum) ;

    /* Find last relevant date */
    matur = opt->dpay ;
    if (Cldr_DateLT(&matur, &opt->dfix) == True)
        matur = opt->dfix ;

    for (i = 0; i < ds->nshock; i++)
    {
        fsprev = Disc_get_chgdate(NULL, old, &ds->shock[i]) ;

        if (fsprev.y > 0 && Cldr_DateLT(&matur, &fsprev) == False)
        {
            if (ds->dom == True)
                df_d->disc = &ds->shock[i] ;
            else
                df_f->disc = &ds->shock[i] ;

            dv[i]  = OptFX_Black2P(analys, voldate, vol, fx_spot, spot, opt,
                                   df_d, df_f, holi, NULL, &dum, &dum) ;
            dv[i] -= p0 ;

            if (ds->zero == True && ds->dom == True)
                /* Find shocked Zero PV */
                dv[i] /= Disc_DF2BPV(&ds->mid[i], df_d, old, holi) ;    /* PMSTA-22396 - SRIDHARA � 160502 */

            else if (ds->zero == True && ds->dom == False)
                /* Find shocked Zero PV */
                dv[i] /= Disc_DF2BPV(&ds->mid[i], df_f, old, holi) ;           /* PMSTA-22396 - SRIDHARA � 160502 */
        }
        else
            dv[i] = 0.0 ;
    }

    if (ds->dom == True)
        df_d->disc = old ;
    else
        df_f->disc = old ;

    return dv ;
}


/*,,SOH,,
*************************************************************************
*
*               OptFutFX_Black2Impl()
*
*    interface  #include <opteqty.h>
*               BOOLE OptFutFX_Black2Impl(DATESTR     *analys,
*                                         DATESTR     *voldate,
*                                         FL64        prem,
*                                         BOOLE       is_p,
*                                         FL64        futp,
*                                         FL64        vol,
*                                         OPTFUT      *opt,
*                                         DISCFAC     *df,
*                                         HOLI_STR    *holi,
*                                         KEYCONV     what,
*                                         ITERCTRL    *ctrl,
*                                         FL64        *impl) ;
*
*    general    The routine calculates the implied ratio for a European
*               option on a currency - using the Black76 formula
*               for a European option on a future.
*
*               The parameter what can be one of the following values
*
*                   what            impl
*                   ----------      ----
*                   KEY_PRICE       Implied FX Forward price
*                   KEY_VOL         Implied volatility
*                   KEY_STRIKE      Implied strike
*
*               The argument prem can be either the option price or the
*               option delta, this is defined in is_p. Consequently
*               one can use the routine to find implied strike given
*               some delta value.
*
*               If Implied Spot FX is required - first find the
*               Implied FX forward, and used the interest rate parity
*               to back out the FX spot herefrom.
*
*               Use FutFX_DF2FXrate() to this purpose.
*
*    input      DATESTR  *analys  Pointer to analysis date (NPV date)
*
*               DATESTR  *voldate Vol calculated from this date
*
*               FL64     prem     The option premium to match, quoted
*                                 on analys.
*
*               BOOLE    is_p     If True the prem is the price, if
*                                 False then prem is the option delta.
*
*               FL64     futp     The FX Forward Exchange Rate.
*                                 Quoted directly in base 1 in domestic
*                                 currency per foreing currency units.
*
*               FL64     vol      The annual volatility of the futures
*                                 price in percent.
*
*               OPTFUT   *opt     The data defining the option.
*                                 ->oadd must be NO_OPTADD.
*
*               DISCFAC  *df      Domestic discount function
*                                 For CALL - PUT CCY Curve
*                                 For PUT  - CALL CCY Curve
*
*               HOLI_STR *holi    Holiday setup
*
*               KEYCONV  what     What implied ratio to find.
*
*               ITERCTRL *ctrl    Pointer to iteration control data.
*
*    output     FL64     *impl    The implied ratio.
*
*    returns    True if all is OK, and False if not.
*
*    diagnostics
*
*    see also   Option_Black2Impl()                                 
*               OptFX_Black2P()
*               OptFutFX_Black2P()
*               FutFX_DF2FXrate()
*
*    wrapper    AP
*
*************************************************************************
,,EOH,,*/


BOOLE OptFutFX_Black2Impl(DATESTR* analys,
                    DATESTR* voldate,
                    FL64    prem,
                    BOOLE   is_p,
                    FL64    futp,
                    FL64    vol,
                    OPTFUT*  opt,
                    DISCFAC* df,
                    HOLI_STR* holi,
                    KEYCONV what,
                    ITERCTRL*  ctrl,
                    FL64*    impl)
{
    BOOLE ok ;

    *impl = 0.0 ;
    if (opt->oadd == FWDSTART)
        ok = False ;
    else
        ok = Option_Black2Impl(analys, voldate, prem, is_p, futp, False, 1.0,
                               vol, opt, df, holi, what, ctrl, impl) ;
    return ok ;
}


/*,,SOH,,
*************************************************************************
*
*               OptFX_Black2Impl()
*
*    interface  #include <opteqty.h>
*               BOOLE OptFX_Black2Impl(DATESTR     *analys,
*                                      DATESTR     *voldate,
*                                      FL64        prem,
*                                      BOOLE       is_p,
*                                      FL64        vol,
*                                      FL64        fx_spot,
*                                      DATESTR     *spot,
*                                      OPTFUT      *opt,
*                                      DISCFAC     *df_d,
*                                      DISCFAC     *df_f,
*                                      HOLI_STR    *holi,
*                                      KEYCONV     what,
*                                      ITERCTRL    *ctrl,
*                                      FL64        *impl) ;
*
*    general    The routine calculates the implied ratio for a European
*               option on a currency forward - using the Black76 formula*
*               for a European option on a future.
*
*               The parameter what can be one of the following values
*
*                   what            impl
*                   ----------      ----
*                   KEY_SPOT        Implied FX Spot
*                   KEY_VOL         Implied volatility
*                   KEY_STRIKE      Implied strike
*
*               The argument prem can be either the option price or the
*               option delta, this is defined in is_p. Consequently
*               one can use the routine to find implied strike given
*               some delta value.
*
*    input      DATESTR  *analys  Pointer to analysis date (NPV date)
*
*               DATESTR  *voldate Vol calculated from this date
*
*               FL64     prem     The option premium to match, quoted
*                                 on analys.
*
*               BOOLE    is_p     If True the prem is the price, if
*                                 False then prem is the option delta.
*
*               FL64     vol      The annual volatility of the FX
*                                 spot price in percent.
*
*               FL64     fx_spot  Spot exchange rate. Price in domes-
*                                 tic currency of foreign currency units*
*
*               DATESTR  *spot    The date for fx_spot
*
*               OPTFUT   *opt     The data defining the option.
*
*               DISCFAC  *df_d    Domestic discount function
*                                 For CALL - PUT CCY Curve
*                                 For PUT  - CALL CCY Curve
*
*               DISCFAC  *df_f    Foreign discount function
*                                 For CALL - CALL CCY Curve
*                                 For PUT  - PUT CCY Curve
*
*               HOLI_STR *holi    Holiday setup
*
*               KEYCONV  what     What implied ratio to find.
*
*               ITERCTRL *ctrl    Pointer to iteration control data.
*
*    output     FL64     *impl    The implied ratio.
*
*    returns    True if all is OK, and False if not.
*
*    diagnostics
*
*    see also   OptFX_Black2P()
*               OptFutFX_Black2P()
*               FutFX_DF2FXrate()
*
*************************************************************************
,,EOH,,*/


BOOLE OptFX_Black2Impl(DATESTR* analys,
                      DATESTR*  voldate,
                      FL64     prem,
                      BOOLE    is_p,
                      FL64     vol,
                      FL64     fx_spot,
                      DATESTR*  spot,
                      OPTFUT*   opt,
                      DISCFAC*  df_d,
                      DISCFAC*  df_f,
                      HOLI_STR* holi,
                      KEYCONV  what,
                      ITERCTRL*  ctrl,
                      FL64*     impl)
{
    BOOLE    ok ;
    FL64     futp ;
    KEYCONV  what1 ;
    FXFORW   fxfw ;

    what1 = (what == KEY_SPOT ? KEY_PRICE : what) ;
    fxfw  = Set_FXFORW(&opt->dfix, False, 1.0, 1.0, False, ACT360) ;
    futp  = FutFX_DF2FXrate(spot, fx_spot, &fxfw, True, holi, df_d, df_f) ;

    ok = OptFutFX_Black2Impl(analys, voldate, prem, is_p, futp, vol,
                             opt, df_d, holi, what1, ctrl, impl) ;

    if (ok == True && what == KEY_SPOT)
    {
        fxfw  = Set_FXFORW(&opt->dfix, False, 1.0, 1.0, False, ACT360) ;
        *impl = FutFX_DF2FXrate(spot, *impl, &fxfw, False, holi, df_d, df_f) ;
    }

    return ok ;
}


/*,,SOH,,
*************************************************************************
*
*               OptFX_VOLBOX2Vol()
*
*    interface  #include <opteqty.h>
*               FL64 OptFX_VOLBOX2Vol(DATESTR  *today,
*                                     VOLBOX   *vb,
*                                     OPTFUT   *opt,
*                                     HOLI_STR *holi) ;
*
*    general    The routine computes the volatility to be used in the
*               Black76-based FX option pricing routines.
*
*    input      DATESTR   *today  Pointer to analysis date (NPV date)
*
*               VOLBOX    *vb     The volatility surface.
*
*               OPTFUT    *opt    Pointer to option data
*
*               HOLI_STR  *holi   Businessday adjustment setup
*
*    output
*
*    returns    The volatility (as a percentage).
*
*    diagnostics
*
*    see also   OptFX_Black2P()
*
*************************************************************************
,,EOH,,*/


FL64 OptFX_VOLBOX2Vol(DATESTR* today,
                      VOLBOX*   vb,
                      OPTFUT*   opt,
                      HOLI_STR* holi)
{
    FL64    vol, s ;
    DATESTR om ;
    PERIOD  sm ;

    sm.num = 1 ;
    sm.unit = DAYS ;

    /* Find option maturity, strike and bond maturity */
    om = Cldr_NextBusinessDate(&opt->dfix, holi) ;
    s  = opt->strike ;

    /* Find corresponding vol - Assume PRICE vol ONLY */
    vol = Vol_Linear_Lookup(vb, today, &om, s, &sm, holi) ;

    return vol ;
}


/*,,SOH,,
*************************************************************************
*
*               OptFX_Cross2Vol()
*
*    interface  #include <opteqty.h>
*               FL64 OptFX_Cross2Vol(FL64   vol1,
*                                    FL64   vol2,
*                                    FL64   corr) ;
*
*    general    The routine computes the volatility between currency1
*               and currency3 given
*                   1) the volatility between currency1 and currency2
*                   2) the volatility between currency2 and currency3
*                   3) the correlation between the above mentioned
*                      volatilities
*
*    input      FL64      vol1   vol between currency1 and currency2
*
*               FL64      vol2   vol between currency2 and currency3
*
*               FL64      corr   corr. between vol1 and vol2
*
*    output
*
*    returns    The volatility (as a percentage).
*
*    diagnostics
*
*    see also   OptFutFX_Cross2Vol()
*
*************************************************************************
,,EOH,,*/

FL64 OptFX_Cross2Vol(FL64 vol1,
                        FL64 vol2,
                        FL64 corr)
{
    FL64 vol ;

    vol = SQR(vol1) + SQR(vol2) - 2.0 * corr * vol1 * vol2 ;
    if (vol < ACC_TERM)
        vol = 0.0 ;
    else
        vol = sqrt(vol) ;

    return vol ;
}

/*,,SOH,,
*************************************************************************
*
*               OptFutFX_Cross2Vol()
*
*    interface  #include <opteqty.h>
*               FL64 OptFutFX_Cross2Vol(FL64   vol1,
*                                       FL64   vol2,
*                                       FL64   corr) ;
*
*    general    The routine computes the volatility between currency1
*               and currency3 given
*                   1) the volatility between currency1 and currency2
*                   2) the volatility between currency2 and currency3
*                   3) the correlation between the above mentioned
*                      volatilities
*
*    input      FL64      vol1   vol between currency1 and currency2
*
*               FL64      vol2   vol between currency2 and currency3
*
*               FL64      corr   corr. between vol1 and vol2
*
*    output
*
*    returns    The volatility (as a percentage).
*
*    diagnostics
*
*    see also   OptFX_Cross2Vol()
*
*************************************************************************
,,EOH,,*/


FL64 OptFutFX_Cross2Vol(FL64 vol1,
                        FL64 vol2,
                        FL64 corr)
{
    return OptFX_Cross2Vol(vol1, vol2, corr) ;
}

/*
..Not used anymore
*/


FL64 black_d1_fxforw(FL64 f, FL64 e, FL64 vol, FL64 t)
{
    FL64 tmp, d1 ;

    tmp = Vol_Ann2Per(vol/100.0, t) ;
    d1 = (fabs(e) > PAYM_TOL && f > PAYM_TOL ? log(f/e) + 0.5*SQR(tmp) : 0.0) ;
    return (fabs(tmp) > PAYM_TOL ? d1/tmp : 0.0) ;
}

/*
..Not used anymore - except JL
*/

FL64 black_premium_fxforw(FL64 f,
                          FL64 e,
                          FL64 vol,
                          FL64 tfix,
                          FL64 t,
                          FL64 disc,
                          OPTTYPE type,
                          PREMIUMTYPE ptype,
                          KEYCONV wrt,
                          RISKCONV risk,
                          FL64* dp,
                          FL64* ddp)
{
    FL64 repo, disc1, d2, d1, x1, x2, size, plo, phi, p ;

    /* warning avoidance */
    phi = plo = 0.0;

    *dp = *ddp = 0.0 ;

    d1 = black_d1_fxforw(f, e, vol, tfix) ;
    d2 = black_d2(d1, vol, tfix) ;

    if (type == CALL)
        p  = f * Stat_NormalizedNormal(d1) - e * Stat_NormalizedNormal(d2) ;

    else
        p  = e * Stat_NormalizedNormal(-d2) - f * Stat_NormalizedNormal(-d1) ;

    if (ptype == UP_FRONT)
        p *= disc ;

    /* Compute risk ratios - if specified. */
    if (risk == ZERO_ORDER)
        return p ;

    size = SHOCKSIZE ;

    switch (wrt)
    {
        case KEY_PRICE:

            size = size  / 100.0 ;
            if (fabs(size) > f)
                size = f / 2.0 ;

            plo  = black_premium_fxforw(f-size, e, vol, tfix, t, disc, type,
                                        ptype, KEY_PRICE, ZERO_ORDER, 
                                        &x1, &x2) ;
            phi  = black_premium_fxforw(f+size, e, vol, tfix, t, disc, type,
                                        ptype, KEY_PRICE, ZERO_ORDER, 
                                        &x1, &x2);
/*
printf("%15.13lf %15.13lf %15.13lf %15.13lf %15.13lf\n",
plo, p, phi, phi + plo - 2.0 *p, (phi + plo - 2.0 *p) / SQR(size)) ;
*/
            break ;

        case KEY_REPO:

            repo  = TVMunit_Yield(disc, t, CONTINUOUS, 0) ;

            disc1 = TVMunit_NPV(t, repo-size, CONTINUOUS, 0) ;
            plo   = black_premium_fxforw(f, e, vol, tfix, t, disc1, type, ptype,
                                         KEY_REPO, ZERO_ORDER, &x1, &x2);

            disc1 = TVMunit_NPV(t, repo+size, CONTINUOUS, 0) ;
            phi   = black_premium_fxforw(f, e, vol, tfix, t, disc1, type, ptype,
                                         KEY_REPO, ZERO_ORDER, &x1, &x2);
            break ;

        case KEY_VOL:

            plo  = black_premium_fxforw(f, e, vol-size, tfix, t, disc, type,
                                        ptype,
                                        KEY_VOL, ZERO_ORDER, &x1, &x2) ;
            phi  = black_premium_fxforw(f, e, vol+size, tfix, t, disc, type,
                                        ptype,
                                        KEY_VOL, ZERO_ORDER, &x1, &x2) ;
            break ;

        case KEY_MATURITY:

            size  = 0.0001 ;
            repo  = TVMunit_Yield(disc, t, CONTINUOUS, 0) ;

            disc1 = TVMunit_NPV(t-size, repo, CONTINUOUS, 0) ;
            plo   = black_premium_fxforw(f, e, vol, tfix-size, t-size, disc1,
                                         type, ptype,
                                         KEY_MATURITY, ZERO_ORDER, &x1, &x2) ;

            disc1 = TVMunit_NPV(t+size, repo, CONTINUOUS, 0) ;
            phi   = black_premium_fxforw(f, e, vol, tfix+size, t+size, disc1,
                                         type, ptype,
                                         KEY_MATURITY, ZERO_ORDER, &x1, &x2) ;
            break ;

        case KEY_STRIKE:

            plo  = black_premium_fxforw(f, e-size, vol, tfix, t, disc, type,
                                        ptype, KEY_STRIKE, ZERO_ORDER, 
                                        &x1, &x2) ;
            phi  = black_premium_fxforw(f, e+size, vol, tfix, t, disc, type,
                                        ptype, KEY_STRIKE, ZERO_ORDER, 
                                        &x1, &x2) ;
            break ;

        default:
            ;
    }

    *dp  = (phi - plo) / (2.0 * size) ;

    if (risk == SECOND_ORDER)
        *ddp = (phi + plo - (2.0 * p)) / SQR(size) ;

    return p ;
}

/*
..Not used anymore - except JL
*/


BOOLE black_implied_fxforw(FL64 p, BOOLE is_p, FL64 f, FL64 e, FL64 vol,
                           FL64 tfix, FL64 t, FL64 disc, OPTTYPE type,
                           PREMIUMTYPE ptype, KEYCONV what, FL64 low,
                           FL64 up, FL64* res)
{
    FL64 acc ;

    /* warning avoidance */
    acc = 0.0;

    /* Set up bounds for the unknown variable + the desired accuracy */
    if (what == KEY_PRICE || what == KEY_STRIKE)
    {
        acc = ACC_PRICE ;
        low = GETMAX(low, LOW_BOUND) ;
    }

    else if (what == KEY_REPO || what == KEY_VOL)
        acc = ACC_RATE ;

    else if (what == KEY_MATURITY)
    {
        acc = ACC_TERM ;
        low = (t - tfix) + GETMAX(low, LOW_BOUND) ;
    }

    /* Now find the implied ratio (root) */
    return black_root_fxforw(p, is_p, f, e, vol, disc, type, ptype, tfix, t,
                             what, low, up, acc, res) ;
}

/*
..Not used anymore - except JL
*/


BOOLE black_root_fxforw(FL64 pr, BOOLE is_p, FL64 pu, FL64 e, FL64 vol,
                        FL64 disc, OPTTYPE type, PREMIUMTYPE ptype,
                        FL64 tfix, FL64 to, KEYCONV what,
                        FL64 low, FL64 up, FL64 xacc, FL64* rts)
{
    INTI     j ;
    FL64     df1, df, dx, ddf, dxold, f, fh, fl, swap, temp, xh, xl ;
    RISKCONV risk ;

    risk = (is_p == True ? ZERO_ORDER : FIRST_ORDER) ;

    black_setimpl_fxforw(low, &pu, &disc, &vol, &e, &tfix, &to, what) ;
    fl = black_premium_fxforw(pu, e, vol, tfix, to, disc, type, ptype,
      KEY_PRICE,
                              risk, &df, &ddf) - pr ;
    if (is_p == False)
        fl = df - pr ;

    black_setimpl_fxforw(up, &pu, &disc, &vol, &e, &tfix, &to, what) ;
    fh = black_premium_fxforw(pu, e, vol, tfix, to, disc, type, ptype,
      KEY_PRICE,
                              risk, &df, &ddf) - pr ;
    if (is_p == False)
        fh = df - pr ;

    if (fl * fh >= 0.0)
        return False ;

    if (fl < 0.0)
    {
        xl = low ;
        xh = up ;
    }
    else
    {
        xh = low ;
        xl = up ;
        swap = fl ;
        fl = fh ;
        fh = swap ;
    }

    risk = FIRST_ORDER ;
    *rts = 0.5 * (up + low) ;
    dx   = dxold = fabs(up - low) ;
    black_setimpl_fxforw(*rts, &pu, &disc, &vol, &e, &tfix, &to, what) ;

    if (is_p == True)
        f = black_premium_fxforw(pu, e, vol, tfix, to, disc, type, ptype, what,
                                 risk, &df, &ddf) - pr ;
    else
    {
        /* Be careful when finding implied given delta */
        f = black_premium_fxforw(pu, e, vol, tfix, to, disc, type, ptype,
                                 KEY_PRICE, risk, &df1, &ddf) ;
        f = df1 - pr ;

        /* Now find delta sensitivity with respect to what */
        black_setimpl_fxforw(*rts + xacc, &pu, &disc, &vol, &e, &tfix, &to,
          what);
        temp = black_premium_fxforw(pu, e, vol, tfix, to, disc, type, ptype,
                                    KEY_PRICE, risk, &df, &ddf) ;

        df = (df - df1) / xacc ;

        black_setimpl_fxforw(*rts, &pu, &disc, &vol, &e, &tfix, &to, what) ;
/*
printf("dev %lf rts %lf delta %lf df %lf\n", f, *rts, df1, df) ;
*/
    }

    for (j = 1 ; j <= MAXIT ; j++)
    {
        if ((((*rts - xh) * df - f) * ((*rts - xl) * df - f) >= 0.0)
            || (fabs(2.0 * f) > fabs(dxold * df)))
        {
            /* Here we use bisection - whenever the Newton-Raphson step is
               out of range */
            dxold = dx;
            dx    = 0.5 * (xh - xl);
            *rts  = xl + dx;
            if (xl == *rts)
                return True ;
        }
        else
        {
            /* Use Newton-Raphson whenever the new guess is within bounds */
            dxold  = dx;
            dx     = f / df ;
            temp   = *rts;
            *rts  -= dx;
            if (temp == *rts)
                return True ;
        }

        if (fabs(dx) < xacc)
            return True ;

        black_setimpl_fxforw(*rts, &pu, &disc, &vol, &e, &tfix, &to, what) ;
        if (is_p == True)
            f = black_premium_fxforw(pu, e, vol, tfix, to, disc, type, ptype,
                                     what, risk, &df, &ddf) - pr ;
        else
        {
            /* Be careful when finding implied given delta */
            f = black_premium_fxforw(pu, e, vol, tfix, to, disc, type, ptype,
                                     KEY_PRICE, risk, &df1, &ddf) ;
            f = df1 - pr ;

            /* Now find delta sensitivity with respect to what */
            black_setimpl_fxforw(*rts + xacc, &pu, &disc, &vol, &e, &tfix, &to,
              what);
            temp = black_premium_fxforw(pu, e, vol, tfix, to, disc, type, ptype,
                                        KEY_PRICE, risk, &df, &ddf) ;

            df = (df - df1) / xacc ;

            black_setimpl_fxforw(*rts, &pu, &disc, &vol, &e, &tfix, &to, what) ;
/*
printf("dev %lf rts %lf delta %lf df %lf\n", f, *rts, df1, df) ;
*/
        }

        if (f < 0.0)
        {
            xl = *rts;
            fl = f;
        }
        else
        {
            xh = *rts;
            fh = f;
        }
    }

    return False ;
}

/*
..Not used anymore - except JL
*/


void black_setimpl_fxforw(FL64 x, FL64* pu, FL64* disc, FL64* vol,
                          FL64* e, FL64* tfix, FL64* to, KEYCONV what)
{
    FL64 diff, repo ;

    if      (what == KEY_PRICE)    *pu   = x ;
    else if (what == KEY_REPO)     *disc = TVMunit_NPV(*to, x, CONTINUOUS, 0) ;
    else if (what == KEY_VOL)      *vol  = x ;
    else if (what == KEY_STRIKE)   *e    = x ;
    else if (what == KEY_MATURITY)
    {
        diff  = *to - *tfix ;
        repo  = TVMunit_Yield(*disc, *to, CONTINUOUS, 0) ;
        *to   = x ;
        *tfix = *to - diff ;
        *disc = TVMunit_NPV(x, repo, CONTINUOUS, 0) ;
    }
}


#undef MAXIT
#undef PAYM_TOL
#undef SHOCKSIZE
#undef ACC_PRICE
#undef ACC_RATE
#undef ACC_TERM

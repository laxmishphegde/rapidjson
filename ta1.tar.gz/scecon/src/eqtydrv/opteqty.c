/* SCID @(#)opteqty.c	1.10 (SimCorp) 99/10/20 15:02:03 */

/************************************************************************
*
*   project     SCecon
*
*   filename    opteqty.c
*
*   contains    routines in the SCecon options library.
*
************************************************************************/

/***** includes ********************************************************/
#include <opteqty.h>

/***** defines  ********************************************************/
#define PAYM_TOL  1.0E-10
#define SHOCKSIZE 0.01
#define MAXIT   100
#define ACC_PRICE 0.001
#define ACC_RATE  0.0001
#define ACC_TERM  0.000001
#define LOW_BOUND 0.0001

/***** functions *******************************************************/


/*,,SOH,,
*************************************************************************
*
*               OptEqty_Black2P()
*
*    interface  #include <opteqty.h>
*               FL64 OptEqty_Black2P(DATESTR  *analys,
*                                    DATESTR  *voldate,
*                                    FL64     spot,
*                                    FL64     vol,
*                                    FL64     divyld,
*                                    FUTEQTY  *fute,
*                                    OPTFUT   *opt,
*                                    DISCFAC  *df,
*                                    HOLI_STR *holi,
*                                    RISKSET  *risk,
*                                    FL64     *dp,
*                                    FL64     *ddp) ;
*
*    general    The routine calculates the premium for a European
*               option on a Stock or a Warrant - using the Black76
*               formula for a european option on a Stock. In addition
*               some of the Greek numbers can be computed.
*
*               Key ratios are calculated as follows:
*
*                   risk->key      dp          ddp
*                   ---------      ---         ----
*                   KEY_SPOT       Delta       Gamma
*                   KEY_PROB       Delta       Gamma
*                   KEY_MATURITY   Theta       N/A
*                   KEY_VOL        Vega        d(Vega)/d(Vol)
*                   KEY_STRIKE     d(P)/d(C)   d2(P)/d(C)2
*                   KEY_REPO       Rho         d(rho)/d(r)
*                   KEY_DF         $Duration   $Convexity
*                   KEY_BPV        BPV
*                   -----------------------------------------
*
*               The delta/gamma wrt KEY_SPOT is wrt the SPOT price.
*               This of course requires that adj is False.
*
*               The KEY_PROB numbers are alternative definitions of
*               delta and gamma. And express the in-the-moneyness of a
*               option (delta), and the sensitivity of this (gamma) to
*               variations in the underlying variable.
*
*               2 ways of entering dividend are supported: Dividend
*               yields and discrete-time dividends.
*
*               NOTE that not all risk ratios are calculated for any
*               option structure (in which case 0 is returned).
*
*
*    input      DATESTR  *analys  Pointer to analysis date (NPV date)
*
*               DATESTR  *voldate Vol calculated from this date.
*
*               FL64     spot     The spot price.
*                                 Must not be preADJUSTED for dividends
*                                 at entry.
*
*               FL64     vol      The annual volatility of the Spot
*                                 price in percent.
*
*               FL64     divyld   Dividend yield (continuous rate in %).*
*
*               FUTEQTY  *fute    Equity data
*
*               OPTFUT   *opt     The data defining the option.
*
*               DISCFAC  *df      Discount function for discounting
*                                 the option payout.
*
*               HOLI_STR *holi    Holiday adjustment rules
*
*               RISKSET  *risk    The risk ratio definitions
*                                 Use NULL for no Greeks
*
*    output     FL64     *dp      Pointer to the first order derivative.*
*
*               FL64     *ddp     Pointer to the second order derivative*
*
*    returns    the option premium.
*
*    diagnostics
*
*    see also   Option_Black2P()                                    
*               OptEqty_Black2Impl()
*               OptEqty_VOLBOX2Vol()
*
*    wrapper    AP
*
*************************************************************************
,,EOH,,*/

FL64 OptEqty_Black2P(DATESTR* analys,
                    DATESTR* voldate,
                    FL64    spot,
                    FL64    vol,
                    FL64    divyld,
                    FUTEQTY* fute,
                    OPTFUT*  opt,
                    DISCFAC* df,
                    HOLI_STR* holi,
                    RISKSET* risk,
                    FL64*    dp,
                    FL64*    ddp)
{
    FL64    dum, size, phi, plo, p, dsc1, f1, f2, sk2, shock ;
    OPTFUT  ofut ;
    FUTEQTY fnew ;
    DISCFAC sdf ;
    DATESTR anld, vold ;

    p = *dp = *ddp = 0.0 ;

    sk2 = 1.0 ;
    if (fabs(spot) > 0.00001)
        sk2 = FutEqty_CC2AdjSpot(analys, &opt->dfix, spot, fute->cal,
                                 divyld, fute->div, holi) / spot ;       /* PMSTA-22396 - SRIDHARA � 160502 */

    if (opt->oadd != FWDSTART)
        /* Call the Standard Black Calculator */
        p = Option_Black2P(analys, voldate, spot, True, sk2, vol, opt, df,
                           holi, risk, dp, ddp) ;
    else
    {
        /* Rule out dumb cases */
        if (Cldr_DateLT(&opt->fwdst.dset, analys) == True)
            return 0.0 ;

        /* Find the forward price on setting date */
        fnew = Set_FUTEQTY(&opt->fwdst.dset, fute->div, fute->cal, 0.0,
                           False) ;
        f1   = FutEqty_CC2Price(analys, spot, &fnew, divyld, df, holi) ;

        /* Find the forward price on expiry date */
        fnew = Set_FUTEQTY(&opt->dfix, fute->div, fute->cal, 0.0, False) ;
        f2   = FutEqty_CC2Price(analys, spot, &fnew, divyld, df, holi) ;

        ofut = Set_OPTFUT(opt->type, opt->fwdst.alpha * f1,
                          &opt->dfix, &opt->dpay, UP_FRONT, opt->cal) ;

        /* Call the Standard Black Calculator - for this case */
        p = Option_Black2P(&opt->fwdst.dset, &opt->fwdst.dset, f2, False, 1.0,
                           vol, &ofut, df, holi, risk, dp, ddp) ;

        /* Discount from forward starting date */
		/* PMSTA-22396 - SRIDHARA � 160502 */
        dsc1 = Disc_Interpolation(&opt->fwdst.dset, df, holi) ;
        Disc_forwval(df, analys, &dsc1, holi) ;
        p *= dsc1 ;

        if (risk == NULL)
            return p ;

        /* Be careful about most risk ratios for fwd starts - do it specially */
        size = Scutl_Default_Shock(risk->shock, risk->key) ;
            
        if (risk->risk != ZERO_ORDER && risk->key == KEY_SPOT)
        {
            phi = OptEqty_Black2P(analys, voldate, size + spot, vol,
                                  divyld, fute, opt, df, holi, NULL, dp, ddp) ;
            plo = OptEqty_Black2P(analys, voldate, - size + spot, vol,
                                  divyld, fute, opt, df, holi, NULL, dp, ddp) ;
        }
        else if (risk->risk != ZERO_ORDER && risk->key == KEY_VOL)
        {
            phi = OptEqty_Black2P(analys, voldate, spot, vol + size,
                                  divyld, fute, opt, df, holi, NULL, dp, ddp) ;
            plo = OptEqty_Black2P(analys, voldate, spot, vol - size,
                                  divyld, fute, opt, df, holi, NULL, dp, ddp) ;
        }
        else
            phi = plo = p ;

        if (risk->risk != ZERO_ORDER)
            *dp = (phi - plo) / (2.0 * size) ;
        if (risk->risk == SECOND_ORDER)
            *ddp = (phi + plo - 2.0 * p) / SQR(size) ;
    }

    if (risk == NULL)
        return p ;

    if (risk->risk != ZERO_ORDER && (risk->key == KEY_DF || 
        risk->key == KEY_BPV || risk->key == KEY_REPO))
    {
        shock = Scutl_Default_Shock(risk->shock, risk->key) ;

        /* $Duration / Convexity - Shock DF */
		/* PMSTA-22396 - SRIDHARA � 160502 */
        sdf = Disc_ShockRates(df, 1.0, risk, holi) ;
        phi = OptEqty_Black2P(analys, voldate, spot, vol, divyld, fute, opt,
                              &sdf, holi, NULL, dp, ddp) ;
        Free_PLANARRAY(sdf.disc, 1) ;

		/* PMSTA-22396 - SRIDHARA � 160502 */
        sdf = Disc_ShockRates(df, -1.0, risk, holi) ;
        plo = OptEqty_Black2P(analys, voldate, spot, vol, divyld, fute, opt,
                              &sdf, holi, NULL, dp, ddp) ;
        Free_PLANARRAY(sdf.disc, 1) ;

        if (risk->key == KEY_BPV)
            shock = 1.0 ;

        *dp = (phi - plo) / (2.0 * shock) ;
        if (risk->risk == SECOND_ORDER &&
          (risk->key == KEY_DF || risk->key == KEY_REPO))
            *ddp = (phi + plo - 2.0 * p) / SQR(shock) ;
    }

    else if (risk->risk != ZERO_ORDER && risk->key == KEY_MATURITY)
    {
        /* Let time decay -> and reflect this in the dates of the DF's.
           Ie. we move the entire Term Structure of interest rates. */
		/* PMSTA-22396 - SRIDHARA � 160502 */
        shock = Scutl_Default_Shock(risk->shock, risk->key) ;
        sdf   = Disc_Shock_Dates(df, (INTI) shock, holi) ;
        anld  = Cldr_AddDays(analys, (INTL) shock, opt->cal, holi) ;
        vold  = Cldr_AddDays(voldate, (INTL) shock, opt->cal, holi) ;

        /* Recalculate */
        plo = OptEqty_Black2P(&anld, &vold, spot, vol, divyld, fute, opt,
                              &sdf, holi, NULL, &dum, &dum) ;

        /* Do not set ddp */
        *dp = (plo - p) / shock ;

        if (risk->key == KEY_MATURITY)
            *dp *= Cldr_DaysPerYear(analys, analys, 0, opt->cal, LAST, holi) ;     /* PMSTA-22396 - SRIDHARA � 160502 */

        Free_PLANARRAY(sdf.disc, 1) ;
    }

    return p ;
}


/*,,SOH,,
*************************************************************************
*
*               OptEqty_Black2Delta()
*
*    interface  #include <opteqty.h>
*               FL64ARRAY OptEqty_Black2Delta(DATESTR  *analys,
*                                             DATESTR  *voldate,
*                                             FL64     spot,
*                                             FL64     vol,
*                                             FL64     divyld,
*                                             FUTEQTY  *fute,
*                                             OPTFUT   *opt,
*                                             DISCFAC  *df,
*                                             HOLI_STR *holi,
*                                             DELTASET *ds) ;
*
*    general    The routine calculates the delta vector for an (OTC)
*               option on a Equity using Black 76 pricing and a Zero
*               Coupon Yield Curve for bucketing.
*
*               The delta vector represents the price differences
*               invoked by the curve shocks.
*
*
*    input      DATESTR  *analys  Pointer to analysis date (NPV date)
*
*               DATESTR  *voldate Vol calculated from this date.
*
*               FL64     spot     The spot price.
*                                 Must not be preADJUSTED for dividends
*                                 at entry.
*
*               FL64     vol      The annual volatility of the Spot
*                                 price in percent.
*
*               FL64     divyld   Dividend yield (continuous rate in %).*
*
*               FUTEQTY  *fute    Equity data
*
*               OPTFUT   *opt     The data defining the option.
*
*               DISCFAC  *df      Discount function for discounting
*                                 the option payout.
*
*               HOLI_STR *holi    Holiday adjustment rules
*
*               DELTASET *ds      Delta-defining data
*
*    output
*
*    returns    The deltavector allocated as:
*
*                         Alloc_FL64ARRAY(ds->nshock) ;
*
*    diagnostics
*
*    see also   OptEqty_Black2P()
*
*    wrapper    AP
*
*************************************************************************
,,EOH,,*/

FL64ARRAY OptEqty_Black2Delta(DATESTR* analys,
                              DATESTR*  voldate,
                              FL64     spot,
                              FL64     vol,
                              FL64     divyld,
                              FUTEQTY*  fute,
                              OPTFUT*   opt,
                              DISCFAC*  df,
                              HOLI_STR* holi,
                              DELTASET* ds)
{
    INTI      i ;
    FL64ARRAY dv ;
    FL64      p0, dum ;
    PLANARRAY old ;
    DATESTR   matur, fsprev ;

    /* Initialise */
    dv  = Alloc_FL64ARRAY(ds->nshock) ;
    old = df->disc ;

    /* The unshocked price */
    p0 = OptEqty_Black2P(analys, voldate, spot, vol, divyld, fute, opt, df,
                         holi, NULL, &dum, &dum) ;
    matur = Cldr_NextBusinessDate(&opt->dpay, holi) ;

    for (i = 0; i < ds->nshock; i++)
    {
        fsprev = Disc_get_chgdate(NULL, old, &ds->shock[i]) ;

        if (fsprev.y > 0 && Cldr_DateLT(&matur, &fsprev) == False)
        {
            df->disc = &ds->shock[i] ;
            dv[i]    = OptEqty_Black2P(analys, voldate, spot, vol, divyld,
                                       fute, opt, df,
                                       holi, NULL, &dum, &dum) - p0 ;
            if (ds->zero == True)
                /* Find shocked Zero PV */
                dv[i] /= Disc_DF2BPV(&ds->mid[i], df, old,holi) ;    /* PMSTA-22396 - SRIDHARA � 160502 */
        }
        else
            dv[i] = 0.0 ;
    }

    df->disc = old ;

    return dv ;
}


/*,,SOH,,
*************************************************************************
*
*               OptEqty_Black2Impl()
*
*    interface  #include <opteqty.h>
*               BOOLE OptEqty_Black2Impl(DATESTR     *analys,
*                                        DATESTR     *voldate,
*                                        FL64        prem,
*                                        BOOLE       is_p,
*                                        FL64        spot,
*                                        FL64        vol,
*                                        FL64        divyld,
*                                        FUTEQTY     *fute,
*                                        OPTFUT      *opt,
*                                        DISCFAC     *df,
*                                        HOLI_STR    *holi,
*                                        KEYCONV     what,
*                                        ITERCTRL    *ctrl,
*                                        FL64        *impl) ;
*
*    general    The routine calculates the implied ratio for a standard
*               option on a Stock or a Warrant - using the Black76
*               formula for a European option on a Stock.
*
*               The parameter what can be one of the following values
*
*                   what          impl
*                   ----------    ----
*                   KEY_PRICE     Implied Adjusted Spot price
*                   KEY_SPOT      Implied UNAdjusted Spot price
*                   KEY_VOL       Implied volatility
*                   KEY_STRIKE    Implied strike
*                   KEY_GAP       Implied Gap or
*                                 Contingent Premium
*
*               The argument prem can be either the option price or the
*               option delta, this is defined in is_p. Consequently
*               one can use the routine to find implied strike given
*               some delta value.
*
*               Using KEY_GAP can be used to find the contingent premium*
*               for CONTINGENT PREMIUM options (Pay Later options), that*
*               are essentially Gap Options. Use prem = 0 for this
*               purpose. KEY_GAP can only be used with is_p = True.
*
*               NOTE that not all risk ratios are calculated for any
*               option structure (in which case False is returned).
*
*    input      DATESTR  *analys  Pointer to analysis date (NPV date)
*
*               DATESTR  *voldate Vol calculated from this date.
*
*               FL64     prem     The option premium to match, quoted
*                                 on analys.
*
*               BOOLE    is_p     If True the prem is the price, if
*                                 False then prem is the option delta.
*
*               FL64     spot     The spot price.
*                                 Must not be preADJUSTED for dividends
*                                 at entry.
*
*               FL64     vol      The annual volatility of the Spot
*                                 price in percent.
*
*               FL64     divyld   Dividend yield (continuous rate in %).*
*
*               FUTEQTY  *fute    Equity data
*
*               OPTFUT   *opt     The data defining the option.
*
*               DISCFAC  *df      Discount function for discounting
*                                 future payments.
*
*               HOLI_STR *holi    Holiday adjustment rules
*
*               KEYCONV  what     What implied ratio to find.
*
*               ITERCTRL *ctrl    Pointer to iteration control data.
*
*    output     FL64     *impl    The implied ratio.
*
*    returns    True if all is OK, and False if not.
*
*    diagnostics
*
*    see also   Option_Black2Impl()                                 
*               OptEqty_Black2P()
*
*    wrapper    AP
*
*************************************************************************
,,EOH,,*/

BOOLE OptEqty_Black2Impl(DATESTR* analys,
                    DATESTR* voldate,
                    FL64    prem,
                    BOOLE   is_p,
                    FL64    spot,
                    FL64    vol,
                    FL64    divyld,
                    FUTEQTY* fute,
                    OPTFUT*  opt,
                    DISCFAC* df,
                    HOLI_STR* holi,
                    KEYCONV what,
                    ITERCTRL*  ctrl,
                    FL64*    impl)
{
    BOOLE   ok ;
    FL64    dsc1, f1, f2, sk ;
    OPTFUT  ofut ;
    FUTEQTY fnew ;

    *impl = 0.0 ;
    if (opt->oadd == FWDSTART && what != KEY_VOL && is_p == True)
        return False ;

    if (what == KEY_SPOT)
        what = KEY_PRICE ;

	/* PMSTA-22396 - SRIDHARA � 160502 */
    sk = FutEqty_CC2AdjSpot(analys, &opt->dfix, 100.0, fute->cal,
                                divyld, fute->div, holi) / 100.0 ;

    if (opt->oadd != FWDSTART)
        ok = Option_Black2Impl(analys, voldate, prem, is_p, spot, True, sk, vol,
                               opt, df, holi, what, ctrl, impl) ;
    else
    {
        /* Rule out dumb cases */
        if (Cldr_DateLE(&opt->fwdst.dset, analys) == True)
            return False ;

        /* Discount till forward starting date */
		/* PMSTA-22396 - SRIDHARA � 160502 */
        dsc1 = Disc_Interpolation(&opt->fwdst.dset, df, holi) ;
        Disc_forwval(df, analys, &dsc1, holi) ;
        if (fabs(dsc1) > 0.00001)
            prem /= dsc1 ;

        /* Find the forward price on setting date */
        fnew = Set_FUTEQTY(&opt->fwdst.dset, fute->div, fute->cal, 0.0,
                           False) ;
        f1   = FutEqty_CC2Price(analys, spot, &fnew, divyld, df, holi) ;

        /* Find the forward price on expiry date */
        fnew = Set_FUTEQTY(&opt->dfix, fute->div, fute->cal, 0.0, False) ;
        f2   = FutEqty_CC2Price(analys, spot, &fnew, divyld, df, holi) ;

        ofut = Set_OPTFUT(opt->type, opt->fwdst.alpha * f1,
                          &opt->dfix, &opt->dpay, UP_FRONT, opt->cal) ;

        ok = Option_Black2Impl(&opt->fwdst.dset, &opt->fwdst.dset, prem, is_p,
                               f2, False, 1.0, vol, &ofut, df, holi, what,
                               ctrl, impl) ;
    }

    return ok ;
}


/*,,SOH,,
*************************************************************************
*
*               OptFutEqty_Black2P()
*
*    interface  #include <opteqty.h>
*               FL64 OptFutEqty_Black2P(DATESTR  *analys,
*                                       DATESTR  *voldate,
*                                       FL64     fwd,
*                                       FL64     vol,
*                                       BOOLE    margin,
*                                       DATESTR  *delv, 
*                                       OPTFUT   *opt,
*                                       DISCFAC  *df,
*                                       HOLI_STR *holi,
*                                       RISKSET  *risk,
*                                       FL64     *dp,
*                                       FL64     *ddp) ;
*
*    general    The routine calculates the premium for a European
*               option on an Equity Future - using the Black76
*               formula for a european option on a Forward. In addition
*               some of the Greek numbers can be computed.
*
*               Key ratios are calculated as follows:
*
*                   risk->key      dp          ddp
*                   ---------      ---         ----
*                   KEY_PRICE      Delta       Gamma
*                   KEY_PROB       Delta       Gamma
*                   KEY_MATURITY   Theta       N/A
*                   KEY_VOL        Vega        d(Vega)/d(Vol)
*                   KEY_STRIKE     d(P)/d(C)   d2(P)/d(C)2
*                   KEY_REPO       Rho         d(rho)/d(r)
*                   -----------------------------------------
*
*               The delta/gamma wrt KEY_PRICE is wrt the FORWARD price.
*
*               The KEY_PROB numbers are alternative definitions of
*               delta and gamma. And express the in-the-moneyness of a
*               option (delta), and the sensitivity of this (gamma) to
*               variations in the underlying variable.
*
*               NOTE that not all risk ratios are calculated for any
*               option structure (in which case 0 is returned).
*
*    input      DATESTR  *analys  Pointer to analysis date (NPV date)
*
*               DATESTR  *voldate Vol calculated from this date.
*
*               FL64     fwd      The forward price
*
*               FL64     vol      The annual volatility of the Forward
*                                 price in percent.
*
*               BOOLE    margin   margin is True if margining is used, 
*                                 False if not (e.g. options on 
*                                 forward contracts).
*
*               DATESTR  *delv    The delivery date. Only used if 
*                                 margin is False.
*
*               OPTFUT   *opt     The data defining the option.
*                                 ->oadd must be NO_OPTADD
*
*               DISCFAC  *df      Discount function for discounting
*                                 the option payout.
*
*               HOLI_STR *holi    Holiday adjustment rules
*
*               RISKSET  *risk    The risk ratio definitions
*                                 Use NULL for no Greeks
*
*    output     FL64     *dp      Pointer to the first order derivative.*
*
*               FL64     *ddp     Pointer to the second order derivative*
*
*    returns    the option premium.
*
*    diagnostics
*
*    see also   Option_Black2P()                                    
*               OptEqty_Black2P()                                 
*               OptEqty_VOLBOX2Vol()
*
*    wrapper    AP
*
*************************************************************************
,,EOH,,*/

FL64 OptFutEqty_Black2P(DATESTR  *analys,
                        DATESTR  *voldate,
                        FL64     fwd,
                        FL64     vol,
                        BOOLE    margin,
                        DATESTR  *delv,
                        OPTFUT   *opt,
                        DISCFAC  *df,
                        HOLI_STR *holi,
                        RISKSET  *risk,
                        FL64     *dp,
                        FL64     *ddp)
{

  OPTFUT option ;
  
  *dp = *ddp = 0.0 ;

  if (margin == True)
    option = *opt ;
  else
  {
    option = *opt ;
    option.dpay = *delv ;
  }

  return Option_Black2P(analys, voldate, fwd, False, 1.0, vol, 
    &option, df, holi, risk, dp, ddp) ;
}


/*,,SOH,,
*************************************************************************
*
*               OptFutEqty_Black2Impl()
*
*    interface  #include <opteqty.h>
*               BOOLE OptFutEqty_Black2Impl(DATESTR     *analys,
*                                           DATESTR     *voldate,
*                                           FL64        prem,
*                                           BOOLE       is_p,
*                                           FL64        fwd,
*                                           FL64        vol,
*                                           BOOLE       margin,
*                                           DATESTR     *delv,
*                                           OPTFUT      *opt,
*                                           DISCFAC     *df,
*                                           HOLI_STR    *holi,
*                                           KEYCONV     what,
*                                           ITERCTRL    *ctrl,
*                                           FL64        *impl) ;
*
*    general    The routine calculates the implied ratio for a standard
*               option on a Equity Future - using the Black76
*               formula for a European option on a Stock.
*
*               The parameter what can be one of the following values
*
*                   what          impl
*                   ----------    ----
*                   KEY_VOL       Implied volatility
*
*               The argument prem can be either the option price or the
*               option delta, this is defined in is_p. Consequently
*               one can use the routine to find implied strike given
*               some delta value.
*
*               NOTE that not all risk ratios are calculated for any
*               option structure (in which case False is returned).
*
*    input      DATESTR  *analys  Pointer to analysis date (NPV date)
*
*               DATESTR  *voldate Vol calculated from this date.
*
*               FL64     prem     The option premium to match, quoted
*                                 on analys.
*
*               BOOLE    is_p     If True the prem is the price, if
*                                 False then prem is the option delta.
*
*               FL64     fwd      The spot price.
*                                 Must not be preADJUSTED for dividends
*                                 at entry.
*
*               FL64     vol      The annual volatility of the Spot
*                                 price in percent.
*
*               BOOLE    margin   margin is True if margining is used, 
*                                 False if not (e.g. options on 
*                                 forward contracts).
*
*               DATESTR  *delv    The delivery date. Only used if 
*                                 margin is False.
*
*               OPTFUT   *opt     The data defining the option.
*
*               DISCFAC  *df      Discount function for discounting
*                                 future payments.
*
*               HOLI_STR *holi    Holiday adjustment rules
*
*               KEYCONV  what     What implied ratio to find.
*
*               ITERCTRL *ctrl    Pointer to iteration control data.
*
*    output     FL64     *impl    The implied ratio.
*
*    returns    True if all is OK, and False if not.
*
*    diagnostics
*
*    see also   Option_Black2Impl()
*               OptFutEqty_Black2P()
*
*************************************************************************
,,EOH,,*/

BOOLE OptFutEqty_Black2Impl(DATESTR  *analys,
                            DATESTR  *voldate,
                            FL64     prem,
                            BOOLE    is_p,
                            FL64     fwd,
                            FL64     vol,
                            BOOLE    margin,
                            DATESTR  *delv,
                            OPTFUT   *opt,
                            DISCFAC  *df,
                            HOLI_STR *holi,
                            KEYCONV  what,
                            ITERCTRL *ctrl,
                            FL64     *impl)
{
  BOOLE   ok ;
  OPTFUT option ;

  *impl = 0.0 ;
  if (what != KEY_VOL)
    return False ;

  if (margin == True)
    option = *opt ;
  else
  {
    option = *opt ;
    option.dpay = *delv ;
  }

  ok = Option_Black2Impl(analys, voldate, prem, is_p, fwd, False, 1.0, vol,
                         &option, df, holi, what, ctrl, impl) ;

  return ok ;
}


/*,,SOH,,
*************************************************************************
*
*               OptFutEqty_Black2DFp()
*
*    interface  #include <opteqty.h>
*               FL64 OptFutEqty_Black2DFp(DATESTR  *analys,
*                                       DATESTR  *voldate,
*                                       DATESTR  *spotdate,
*                                       FL64     spot,
*                                       FL64     vol,
*                                       OPTFUT   *opt,
*                                       FUTEQTY  *fute,
*                                       FL64     divyld,
*                                       DISCFAC  *df,
*                                       HOLI_STR *holi,
*                                       RISKSET  *risk,
*                                       FL64     *dp,
*                                       FL64     *ddp) ;
*
*    general    The routine calculates the premium for a standard
*               option on a Equity Future using Black 76 pricing.
*               This routine differs from OptFutEqty_Black2P() in that
*               here the futures price is determined from the Zero
*               Coupon Yield Curve.
*
*               Key ratios are calculated as follows:
*
*                   risk->key      dp          ddp
*                   ---------      ---         ----
*                   KEY_DF         $Duration   $Convexity
*                   KEY_BPV        BPV
*
*    input      DATESTR  *analys   Pointer to analysis date (NPV date)
*
*               DATESTR  *voldate  Vol calculated from this date.
*
*               DATESTR  *spotdate The date on which spot is quoted
*
*               FL64     spot      The spot price.
*                                  Must not be preADJUSTED for dividends
*                                  at entry.
*
*               FL64     vol       The annual volatility of the Forward
*                                  price in percent.
*
*               OPTFUT   *opt      The data defining the option.
*                                  ->oadd must be NO_OPTADD
*
*               FUTEQTY  *fute     Equity data
*
*               FL64     divyld    Dividend yield (continuous rate in %).
*
*               DISCFAC  *df       Discount function for discounting
*                                  the option payout.
*
*               HOLI_STR *holi     Holiday adjustment rules
*
*               RISKSET  *risk     The risk ratio definitions
*                                  Use NULL for no Greeks
*
*    output     FL64     *dp       Pointer to the first order derivative.
*
*               FL64     *ddp      Pointer to the second order derivative
*
*    returns    the option premium.
*
*    diagnostics
*
*    see also   OptFutEqty_Black2P()
*
*    wrapper    AP
*
*************************************************************************
,,EOH,,*/

FL64 OptFutEqty_Black2DFp(DATESTR* analys,
                        DATESTR* voldate,
                        DATESTR* spotdate,
                        FL64    spot,
                        FL64    vol,
                        OPTFUT*  opt,
                        FUTEQTY* fute,
                        FL64    divyld,
                        DISCFAC* df,
                        HOLI_STR* holi,
                        RISKSET* risk,
                        FL64*    dp,
                        FL64*    ddp)
{
    FL64    shock, phi, plo, p, fwd ;
    DISCFAC dfs ;

    p = *dp = *ddp = 0.0 ;

    fwd = FutEqty_CC2Price(spotdate, spot, fute, divyld, df, holi) ;
    p   = OptFutEqty_Black2P(analys, voldate, fwd, vol, fute->margin, 
      &fute->matur, opt, df, holi, NULL, dp, ddp) ;

    if (risk == NULL)
        return p ;

    if ((risk->key == KEY_DF || risk->key == KEY_BPV) && 
        risk->risk != ZERO_ORDER)
    {
        shock = Scutl_Default_Shock(risk->shock, risk->key) ;

		/* PMSTA-22396 - SRIDHARA � 160502 */
        dfs = Disc_ShockRates(df, 1.0, risk, holi) ;
        phi = OptFutEqty_Black2DFp(analys, voldate, spotdate, spot, vol, opt,
                                   fute, divyld, &dfs, holi, NULL, dp, ddp) ;
        Free_PLANARRAY(dfs.disc, 1) ;

		/* PMSTA-22396 - SRIDHARA � 160502 */
        dfs = Disc_ShockRates(df, -1.0, risk, holi) ;
        plo = OptFutEqty_Black2DFp(analys, voldate, spotdate, spot, vol, opt,
                                   fute, divyld, &dfs, holi, NULL, dp, ddp) ;
        Free_PLANARRAY(dfs.disc, 1) ;

        if (risk->key == KEY_BPV)
            shock = 1.0 ;

        *dp = (phi - plo) / (2.0 * shock) ;
        if (risk->risk == SECOND_ORDER && risk->key == KEY_DF)
            *ddp = (phi + plo - 2.0 * p) / SQR(shock) ;
    }

    return p ;
}


/*,,SOH,,
*************************************************************************
*
*               OptFutEqty_Black2Delta()
*
*    interface  #include <opteqty.h>
*               FL64ARRAY OptFutEqty_Black2Delta(DATESTR  *analys,
*                                                DATESTR  *voldate,
*                                                DATESTR  *spotdate,
*                                                FL64     spot,
*                                                FL64     vol,
*                                                FL64     divyld,
*                                                FUTEQTY  *fute,
*                                                OPTFUT   *opt,
*                                                DISCFAC  *df,
*                                                HOLI_STR *holi,
*                                                DELTASET *ds) ;
*
*    general    The routine calculates the delta vector for an (OTC)
*               option on a Equity Future using Black 76 pricing and
*               a Zero Coupon Yield Curve for bucketing.
*
*               The delta vector represents the price differences
*               invoked by the curve shocks.
*
*
*    input      DATESTR  *analys   Pointer to analysis date (NPV date)
*
*               DATESTR  *voldate  Vol calculated from this date.
*
*               DATESTR  *spotdate The date on which spot is quoted
*
*               FL64     spot      The spot price.
*                                  Must not be preADJUSTED for dividends
*                                  at entry.
*
*               FL64     vol       The annual volatility of the Spot
*                                  price in percent.
*
*               FL64     divyld    Dividend yield (continuous rate in %).
*
*               FUTEQTY  *fute     Equity data
*
*               OPTFUT   *opt      The data defining the option.
*
*               DISCFAC  *df       Discount function for discounting
*                                  the option payout.
*
*               HOLI_STR *holi     Holiday adjustment rules
*
*               DELTASET *ds       Delta-defining data
*
*    output
*
*    returns    The deltavector allocated as:
*
*                         Alloc_FL64ARRAY(ds->nshock) ;
*
*    diagnostics
*
*    see also   OptFutEqty_Black2P()
*
*************************************************************************
,,EOH,,*/

FL64ARRAY OptFutEqty_Black2Delta(DATESTR* analys,
                                 DATESTR*  voldate,
                                 DATESTR*  spotdate,
                                 FL64     spot,
                                 FL64     vol,
                                 FL64     divyld,
                                 FUTEQTY*  fute,
                                 OPTFUT*   opt,
                                 DISCFAC*  df,
                                 HOLI_STR* holi,
                                 DELTASET* ds)
{
    INTI      i ;
    FL64ARRAY dv ;
    FL64      p0, dum;
    PLANARRAY old ;
    DATESTR   matur, fsprev ;

    /* Initialise */
    dv  = Alloc_FL64ARRAY(ds->nshock) ;
    old = df->disc ;

    /* The unshocked price */
    p0 = OptFutEqty_Black2DFp(analys, voldate, spotdate, spot, vol, 
                              opt, fute, divyld, df, holi, NULL, &dum, &dum);

    if (Cldr_DateLE(&opt->dpay, &fute->matur) == True)
        matur = Cldr_NextBusinessDate(&fute->matur, holi) ;
    else
        matur = Cldr_NextBusinessDate(&opt->dpay, holi) ;

    for (i = 0; i < ds->nshock; i++)
    {
        fsprev = Disc_get_chgdate(NULL, old, &ds->shock[i]) ;

        if (fsprev.y > 0 && Cldr_DateLT(&matur, &fsprev) == False)
        {
            df->disc = &ds->shock[i] ;
            dv[i] = OptFutEqty_Black2DFp(analys, voldate, spotdate, 
                                         spot, vol, opt, fute, divyld, df, 
                                         holi, NULL, &dum, &dum) - p0 ;
            if (ds->zero == True)
                /* Find shocked Zero PV */
                dv[i] /= Disc_DF2BPV(&ds->mid[i], df, old, holi) ;      /* PMSTA-22396 - SRIDHARA � 160502 */
        }
        else
            dv[i] = 0.0 ;
    }

    df->disc = old ;

    return dv ;
}


/*,,SOH,,
*************************************************************************
*
*               OptEqty_VOLBOX2Vol()
*
*    interface  #include <opteqty.h>
*               FL64 OptEqty_VOLBOX2Vol(DATESTR  *today,
*                                       VOLBOX   *vb,
*                                       OPTFUT   *opt,
*                                       HOLI_STR *holi) ;
*
*    general    The routine computes the volatility to be used in the
*               Black76-based Equity option pricing routines.
*
*    input      DATESTR   *today  Pointer to analysis date (NPV date)
*
*               VOLBOX    *vb     The volatility surface.
*
*               OPTFUT    *opt    Pointer to option data
*
*               HOLI_STR  *holi   Businessday adjustment setup
*
*    output
*
*    returns    The volatility (as a percentage).
*
*    diagnostics
*
*    see also   OptEqty_Black2P()
*               OptFutEqty_Black2P()
*
*************************************************************************
,,EOH,,*/

FL64 OptEqty_VOLBOX2Vol(DATESTR* today,
                        VOLBOX*   vb,
                        OPTFUT*   opt,
                        HOLI_STR* holi)
{
    FL64    vol, s ;
    DATESTR om ;
    PERIOD  sm ;

    sm.num = 1 ;
    sm.unit = DAYS ;

    /* Find option maturity, strike and bond maturity */
    om = Cldr_NextBusinessDate(&opt->dfix, holi) ;
    s  = opt->strike ;

    /* Find corresponding vol - Assume PRICE vol ONLY */
    vol = Vol_Linear_Lookup(vb, today, &om, s, &sm, holi) ;

    return vol ;
}


/*,,SOH,,
*************************************************************************
*
*               OptCmdty_Black2P()
*
*    interface  #include <opteqty.h>
*               FL64 OptCmdty_Black2P(DATESTR  *analys,
*                                     DATESTR  *voldate,
*                                     FL64     spot,
*                                     FL64     vol,
*                                     FL64     convyld,
*                                     FL64     stcost,
*                                     FUTCMDTY *futc,
*                                     OPTFUT   *opt,
*                                     DISCFAC  *df,
*                                     HOLI_STR *holi,
*                                     RISKSET  *risk,
*                                     FL64     *dp,
*                                     FL64     *ddp) ;
*
*    general    The routine calculates the premium for a European
*               option on a Commodity - using the Black76
*               formula for a european option. In addition
*               some of the Greek numbers can be computed.
*
*               Key ratios are calculated as follows:
*
*                   risk->key      dp          ddp
*                   ---------      ---         ----
*                   KEY_SPOT       Delta       Gamma
*                   KEY_PROB       Delta       Gamma
*                   KEY_MATURITY   Theta       N/A
*                   KEY_VOL        Vega        d(Vega)/d(Vol)
*                   KEY_STRIKE     d(P)/d(C)   d2(P)/d(C)2
*                   KEY_REPO       Rho         d(rho)/d(r)
*                   KEY_DF         $Duration   $Convexity
*                   KEY_BPV        BPV
*                   -----------------------------------------
*
*               The KEY_PROB numbers are alternative definitions of
*               delta and gamma. And express the in-the-moneyness of a
*               option (delta), and the sensitivity of this (gamma) to
*               variations in the underlying variable.
*
*               NOTE that not all risk ratios are calculated for any
*               option structure (in which case 0 is returned).
*
*    input      DATESTR  *analys  Pointer to analysis date (NPV date)
*
*               DATESTR  *voldate Vol calculated from this date.
*
*               FL64     spot     The spot price
*
*               FL64     vol      The annual volatility of the Spot
*                                 price in percent.
*
*               FL64     convyld  Convenience yield
*                                 CONTINUOUS rate (%)
*
*               FL64     stcost   Storage cost
*                                 CONTINUOUS rate (%)
*
*               FUTCMDTY *futc    Commodity data
*
*               OPTFUT   *opt     The data defining the option.
*
*               DISCFAC  *df      Discount function for discounting
*                                 the option payout.
*
*               HOLI_STR *holi    Holiday adjustment rules
*
*               RISKSET  *risk    The risk ratio definitions
*                                 Use NULL for no Greeks
*
*    output     FL64     *dp      Pointer to the first order derivative.*
*
*               FL64     *ddp     Pointer to the second order derivative*
*
*    returns    the option premium.
*
*    diagnostics
*
*    see also   Option_Black2P()                                    
*               OptCmdty_Black2Impl()
*               OptCmdty_VOLBOX2Vol()
*
*************************************************************************
,,EOH,,*/

FL64 OptCmdty_Black2P(DATESTR* analys,
                    DATESTR*  voldate,
                    FL64     spot,
                    FL64     vol,
                    FL64     convyld,
                    FL64     stcost,
                    FUTCMDTY* futc,
                    OPTFUT*   opt,
                    DISCFAC*  df,
                    HOLI_STR* holi,
                    RISKSET*  risk,
                    FL64*     dp,
                    FL64*     ddp)
{
    FL64     dum, size, phi, plo, p, dsc1, f1, f2, sk2 ;
    OPTFUT   ofut ;
    FUTCMDTY fnew ;
    DISCFAC  sdf ;
    DATESTR  anld, vold ;

    p = *dp = *ddp = 0.0 ;

    sk2 = 1.0 ;
    if (fabs(spot) > 0.00001)
    {
        fnew = Set_FUTCMDTY(&opt->dfix, futc->cy, futc->stc, futc->cal) ;
		/* PMSTA-22396 - SRIDHARA � 160502 */
        sk2  = FutCmdty_CC2Price(analys, spot, &fnew, convyld,
                                 stcost, df, holi) / spot;
        dsc1 = Disc_Interpolation(&opt->dfix, df, holi) ;
        Disc_forwval(df, analys, &dsc1, holi) ;
        sk2 *= dsc1 ;
    }

    if (opt->oadd != FWDSTART)
        /* Call the Standard Black Calculator */
        p = Option_Black2P(analys, voldate, spot, True, sk2, vol, opt, df,
                           holi, risk, dp, ddp) ;
    else
    {
        /* Rule out dumb cases */
        if (Cldr_DateLE(&opt->fwdst.dset, analys) == True)
            return 0.0 ;

        /* Find the forward price on setting date */
        fnew = Set_FUTCMDTY(&opt->fwdst.dset, futc->cy, futc->stc, futc->cal);
        f1   = FutCmdty_CC2Price(analys, spot, &fnew, convyld, stcost, df, holi) ;   /* PMSTA-22396 - SRIDHARA � 160502 */

        /* Find the forward price on expiry date */
        fnew = Set_FUTCMDTY(&opt->dfix, futc->cy, futc->stc, futc->cal) ;
        f2   = FutCmdty_CC2Price(analys, spot, &fnew, convyld, stcost, df, holi) ;   /* PMSTA-22396 - SRIDHARA � 160502 */
        ofut = Set_OPTFUT(opt->type, opt->fwdst.alpha * f1,
                          &opt->dfix, &opt->dpay, UP_FRONT, opt->cal) ;

        /* Call the Standard Black Calculator - for this case */
        p = Option_Black2P(&opt->fwdst.dset, &opt->fwdst.dset, f2, False, 1.0,
                           vol, &ofut, df, holi, risk, dp, ddp) ;

        /* Discount from forward starting date */
		/* PMSTA-22396 - SRIDHARA � 160502 */
        dsc1 = Disc_Interpolation(&opt->fwdst.dset, df, holi) ;
        Disc_forwval(df, analys, &dsc1, holi) ;
        p *= dsc1 ;

        if (risk == NULL)
            return p ;

        /* Be careful about most risk ratios for fwd starts - do it specially */
        size = Scutl_Default_Shock(risk->shock, risk->key) ;

        if (risk->risk != ZERO_ORDER && risk->key == KEY_SPOT)
        {
            phi = OptCmdty_Black2P(analys, voldate, size + spot, vol, convyld,
                                   stcost, futc, opt, df, holi, NULL, dp, ddp) ;
            plo = OptCmdty_Black2P(analys, voldate, - size + spot, vol, convyld,
                                   stcost, futc, opt, df, holi, NULL, dp, ddp) ;
        }

        else if (risk->risk != ZERO_ORDER && risk->key == KEY_VOL)
        {
            phi = OptCmdty_Black2P(analys, voldate, spot, vol + size, convyld,
                                   stcost, futc, opt, df, holi, NULL, dp, ddp) ;
            plo = OptCmdty_Black2P(analys, voldate, spot, vol - size, convyld,
                                   stcost, futc, opt, df, holi, NULL, dp, ddp) ;
        }
        else
            phi = plo = p ;

        if (risk->risk != ZERO_ORDER)
            *dp = (phi - plo) / (2.0 * size) ;
        if (risk->risk == SECOND_ORDER)
            *ddp = (phi + plo - 2.0 * p) / SQR(size) ;

    }

    if (risk == NULL)
        return p ;

    if (risk->risk != ZERO_ORDER && (risk->key == KEY_DF || 
        risk->key == KEY_BPV || risk->key == KEY_REPO))
    {
        size = Scutl_Default_Shock(risk->shock, risk->key) ;

        /* $Duration / Convexity - Shock DF */
		/* PMSTA-22396 - SRIDHARA � 160502 */
        sdf = Disc_ShockRates(df, 1.0, risk, holi) ;    /* PMSTA-22396 - SRIDHARA � 160502 */
        phi = OptCmdty_Black2P(analys, voldate, spot, vol, convyld,
                               stcost, futc, opt, &sdf, holi, NULL, dp, ddp) ;
        Free_PLANARRAY(sdf.disc, 1) ;

        sdf = Disc_ShockRates(df, -1.0, risk, holi) ;   /* PMSTA-22396 - SRIDHARA � 160502 */
        plo = OptCmdty_Black2P(analys, voldate, spot, vol, convyld,
                               stcost, futc, opt, &sdf, holi, NULL, dp, ddp) ;
        Free_PLANARRAY(sdf.disc, 1) ;

        if (risk->key == KEY_BPV)
            size = 1.0 ;

        *dp = (phi - plo) / (2.0 * size) ;
        if (risk->risk == SECOND_ORDER &&
          (risk->key == KEY_DF || risk->key == KEY_REPO))
            *ddp = (phi + plo - 2.0 * p) / SQR(size) ;
    }

    else if (risk->risk != ZERO_ORDER && risk->key == KEY_MATURITY)
    {
        /* Let time decay -> and reflect this in the dates of the DF's.
           Ie. we move the entire Term Structure of interest rates. */
		/* PMSTA-22396 - SRIDHARA � 160502 */
        size = Scutl_Default_Shock(risk->shock, risk->key) ;
        sdf  = Disc_Shock_Dates(df, (INTI) size, holi) ;
        anld = Cldr_AddDays(analys, (INTL) size, opt->cal, holi) ;
        vold = Cldr_AddDays(voldate, (INTL) size, opt->cal, holi) ;

        /* Recalculate */
        plo = OptCmdty_Black2P(&anld, &vold, spot, vol, convyld, stcost,
                               futc, opt, &sdf, holi, NULL, &dum, &dum) ;

        /* Do not set ddp */
        *dp = (plo - p) / size ;

        if (risk->key == KEY_MATURITY)
            *dp *= Cldr_DaysPerYear(analys, analys, 0, opt->cal, LAST, holi) ;   /* PMSTA-22396 - SRIDHARA � 160502 */

        Free_PLANARRAY(sdf.disc, 1) ;
    }

    return p ;
}


/*,,SOH,,
*************************************************************************
*
*               OptCmdty_Black2Impl()
*
*    interface  #include <opteqty.h>
*               BOOLE OptCmdty_Black2Impl(DATESTR     *analys,
*                                         DATESTR     *voldate,
*                                         FL64        prem,
*                                         BOOLE       is_p,
*                                         FL64        spot,
*                                         FL64        vol,
*                                         FL64        convyld,
*                                         FL64        stcost,
*                                         FUTCMDTY    *futc,
*                                         OPTFUT      *opt,
*                                         DISCFAC     *df,
*                                         HOLI_STR    *holi,
*                                         KEYCONV     what,
*                                         ITERCTRL    *ctrl,
*                                         FL64        *impl) ;
*
*    general    The routine calculates the implied ratio for a standard
*               option on a Commodity - using the Black76
*               formula for a European option.
*
*               The parameter what can be one of the following values
*
*                   what          impl
*                   ----------    ----
*                   KEY_SPOT      Implied Spot price
*                   KEY_VOL       Implied volatility
*                   KEY_STRIKE    Implied strike
*                   KEY_GAP       Implied Gap or
*                                 Contingent Premium
*
*               The argument prem can be either the option price or the
*               option delta, this is defined in is_p. Consequently
*               one can use the routine to find implied strike given
*               some delta value.
*
*               Using KEY_GAP can be used to find the contingent premium*
*               for CONTINGENT PREMIUM options (Pay Later options), that*
*               are essentially Gap Options. Use prem = 0 for this
*               purpose. KEY_GAP can only be used with is_p = True.
*
*               NOTE that not all risk ratios are calculated for any
*               option structure (in which case False is returned).
*
*    input      DATESTR  *analys  Pointer to analysis date (NPV date)
*
*               DATESTR  *voldate Vol calculated from this date.
*
*               FL64     prem     The option premium to match, quoted
*                                 on analys.
*
*               BOOLE    is_p     If True the prem is the price, if
*                                 False then prem is the option delta.
*
*               FL64     spot     The spot price.
*
*               FL64     vol      The annual volatility of the Spot
*                                 price in percent.
*
*               FL64     convyld  Convenience yield
*                                 CONTINUOUS rate (%)
*
*               FL64     stcost   Storage cost
*                                 CONTINUOUS rate (%)
*
*               FUTCMDTY *futc    Commodity data
*
*               OPTFUT   *opt     The data defining the option.
*
*               DISCFAC  *df      Discount function for discounting
*                                 future payments.
*
*               HOLI_STR *holi    Holiday adjustment rules
*
*               KEYCONV  what     What implied ratio to find.
*
*               ITERCTRL *ctrl    Pointer to iteration control data.
*
*    output     FL64     *impl    The implied ratio.
*
*    returns    True if all is OK, and False if not.
*
*    diagnostics
*
*    see also   Option_Black2Impl()                                 
*               OptCmdty_Black2P()
*
*************************************************************************
,,EOH,,*/

BOOLE OptCmdty_Black2Impl(DATESTR* analys,
                    DATESTR* voldate,
                    FL64    prem,
                    BOOLE   is_p,
                    FL64    spot,
                    FL64    vol,
                    FL64     convyld,
                    FL64     stcost,
                    FUTCMDTY* futc,
                    OPTFUT*  opt,
                    DISCFAC* df,
                    HOLI_STR* holi,
                    KEYCONV what,
                    ITERCTRL*  ctrl,
                    FL64*    impl)
{
    BOOLE    ok ;
    FL64     dsc1, f1, f2, sk ;
    OPTFUT   ofut ;
    FUTCMDTY fnew ;

    *impl = 0.0 ;
    if (opt->oadd == FWDSTART && what != KEY_VOL && is_p == True)
        return False ;

    sk = 1.0 ;
    if (fabs(spot) > 0.00001)
    {
        fnew = Set_FUTCMDTY(&opt->dfix, futc->cy, futc->stc, futc->cal) ;
		/* PMSTA-22396 - SRIDHARA � 160502 */
        sk   = FutCmdty_CC2Price(analys, spot, &fnew, convyld, stcost, df, holi) /
                                 spot ;
        dsc1 = Disc_Interpolation(&opt->dfix, df, holi) ;
        Disc_forwval(df, analys, &dsc1, holi) ;
        sk *= dsc1 ;
    }

    if (opt->oadd != FWDSTART)
        ok = Option_Black2Impl(analys, voldate, prem, is_p, spot, True, sk, vol,
                               opt, df, holi, what, ctrl, impl) ;
    else
    {
        /* Rule out dumb cases */
        if (Cldr_DateLE(&opt->fwdst.dset, analys) == True)
            return False ;

        /* Discount till forward starting date */
		/* PMSTA-22396 - SRIDHARA � 160502 */
        dsc1 = Disc_Interpolation(&opt->fwdst.dset, df, holi) ;
        Disc_forwval(df, analys, &dsc1, holi) ;
        if (fabs(dsc1) > 0.00001)
            prem /= dsc1 ;

        /* Find the forward price on setting date */
        fnew = Set_FUTCMDTY(&opt->fwdst.dset, futc->cy, futc->stc,
                            futc->cal) ;
        f1   = FutCmdty_CC2Price(analys, spot, &fnew, convyld, stcost, df, holi) ;     /* PMSTA-22396 - SRIDHARA � 160502 */

        /* Find the forward price on expiry date */
        fnew = Set_FUTCMDTY(&opt->dfix, futc->cy, futc->stc, futc->cal) ;
        f2   = FutCmdty_CC2Price(analys, spot, &fnew, convyld, stcost, df, holi) ;    /* PMSTA-22396 - SRIDHARA � 160502 */
		 
        ofut = Set_OPTFUT(opt->type, opt->fwdst.alpha * f1,
                          &opt->dfix, &opt->dpay, UP_FRONT, opt->cal) ;

        ok = Option_Black2Impl(&opt->fwdst.dset, &opt->fwdst.dset, prem, is_p,
                               f2, False, 1.0, vol, &ofut, df, holi, what,
                               ctrl, impl) ;
    }

    return ok ;
}


/*,,SOH,,
*************************************************************************
*
*               OptFutCmdty_Black2P()
*
*    interface  #include <opteqty.h>
*               FL64 OptFutCmdty_Black2P(DATESTR  *analys,
*                                        DATESTR  *voldate,
*                                        FL64     fwd,
*                                        FL64     vol,
*                                        OPTFUT   *opt,
*                                        DISCFAC  *df,
*                                        HOLI_STR *holi,
*                                        RISKSET  *risk,
*                                        FL64     *dp,
*                                        FL64     *ddp) ;
*
*    general    The routine calculates the premium for a European
*               option on a Commodity Forward using Black76.
*               In addition some of the Greek numbers can be computed.
*
*               Key ratios are calculated as follows:
*
*                   risk->key      dp          ddp
*                   ---------      ---         ----
*                   KEY_PRICE      Delta       Gamma
*                   KEY_PROB       Delta       Gamma
*                   KEY_MATURITY   Theta       N/A
*                   KEY_VOL        Vega        d(Vega)/d(Vol)
*                   KEY_STRIKE     d(P)/d(C)   d2(P)/d(C)2
*                   KEY_REPO       Rho         d(rho)/d(r)
*                   -----------------------------------------
*
*               The KEY_PROB numbers are alternative definitions of
*               delta and gamma. And express the in-the-moneyness of a
*               option (delta), and the sensitivity of this (gamma) to
*               variations in the underlying variable.
*
*               NOTE that not all risk ratios are calculated for any
*               option structure (in which case 0 is returned).
*
*    input      DATESTR  *analys  Pointer to analysis date (NPV date)
*
*               DATESTR  *voldate Vol calculated from this date.
*
*               FL64     fwd      The forward price
*
*               FL64     vol      The annual volatility of the forward
*                                 price in percent.
*
*               OPTFUT   *opt     The data defining the option.
*                                 ->oadd must be NO_OPTADD
*
*               DISCFAC  *df      Discount function for discounting
*                                 the option payout.
*
*               HOLI_STR *holi    Holiday adjustment rules
*
*               RISKSET  *risk    The risk ratio definitions
*                                 Use NULL for no Greeks
*
*    output     FL64     *dp      Pointer to the first order derivative.*
*
*               FL64     *ddp     Pointer to the second order derivative*
*
*    returns    the option premium.
*
*    diagnostics
*
*    see also   Option_Black2P()                                    
*               OptCmdty_VOLBOX2Vol()
*
*************************************************************************
,,EOH,,*/

FL64 OptFutCmdty_Black2P(DATESTR* analys,
                         DATESTR* voldate,
                         FL64    fwd,
                         FL64    vol,
                         OPTFUT*  opt,
                         DISCFAC* df,
                         HOLI_STR* holi,
                         RISKSET* risk,
                         FL64*    dp,
                         FL64*    ddp)
{
    FL64 adj ;

    *dp = *ddp = 0.0 ;

    /* Call the Standard Black Calculator */
	/* PMSTA-22396 - SRIDHARA � 160502 */
    adj = Disc_Interpolation(&opt->dfix, df, holi) ;
    Disc_forwval(df, analys, &adj, holi) ;

    /* Make sure r = D */
    return Option_Black2P(analys, voldate, fwd, True, adj, vol, opt, df,
                          holi, risk, dp, ddp) ;
}


/*,,SOH,,
*************************************************************************
*
*               OptCmdty_VOLBOX2Vol()
*
*    interface  #include <opteqty.h>
*               FL64 OptCmdty_VOLBOX2Vol(DATESTR  *today,
*                                        VOLBOX   *vb,
*                                        OPTFUT   *opt,
*                                        HOLI_STR *holi) ;
*
*    general    The routine computes the volatility to be used in the
*               Black76-based Commodity option pricing routines.
*
*    input      DATESTR   *today  Pointer to analysis date (NPV date)
*
*               VOLBOX    *vb     The volatility surface.
*
*               OPTFUT    *opt    Pointer to option data
*
*               HOLI_STR  *holi   Businessday adjustment setup
*
*    output
*
*    returns    The volatility (as a percentage).
*
*    diagnostics
*
*    see also   OptCmdty_Black2P()
*               OptFutCmdty_Black2P()
*               Vol_Interpolation()          
*
*************************************************************************
,,EOH,,*/

FL64 OptCmdty_VOLBOX2Vol(DATESTR* today,
                         VOLBOX*   vb,
                         OPTFUT*   opt,
                         HOLI_STR* holi)
{
    FL64    vol, s ;
    DATESTR om ;
    PERIOD  sm ;

    sm.num = 1 ;
    sm.unit = DAYS ;

    /* Find option maturity, strike and bond maturity */
    om = Cldr_NextBusinessDate(&opt->dfix, holi) ;
    s  = opt->strike ;

    /* Find corresponding vol - Assume PRICE vol ONLY */
    vol = Vol_Linear_Lookup(vb, today, &om, s, &sm, holi) ;

    return vol ;
}


/*,,SOH,,
************************************************************************
*
*                Set_TREEOPT()
*
*   interface    #include <opteqty.h>
*                TREEOPT Set_TREEOPT(OPTTYPE   type,
*                                    FL64      strike,
*                                    DATESTR   *first,
*                                    DATESTR   *last,
*                                    DATESTR   *dpay,
*                                    CALCONV   cal);
*
*   general      This routine sets the members of the struct defined
*                in the function name. The pointer members are simply
*                assigned - without physical copying. The intention
*                of the Set_*() routines is that by using this
*                functionality, one avoids setting individual members
*                of structs in the application code.
*
*                When new members are inserted in structs the Set_*()
*                routine will be changed accordingly.
*
*                For details on the interpretation of the individual
*                struct members please check the struct definition.
*
*   input        OPTTYPE   type        See general section.
*
*                FL64      strike      See general section.
*
*                DATESTR   *first      First possible strike date.
*
*                DATESTR   *last       Last possible strike date.
*
*                DATESTR   *dpay       The date on which possible payment
*                                      occur. dpay >= last.
*
*                CALCONV   cal         See general section.
*
*   output
*
*   returns      The filled out TREEOPT struct
*
*   diagnostics
*
*   see also     TREEOPT
*
************************************************************************
,,EOH,,*/

TREEOPT Set_TREEOPT(OPTTYPE   type,
                    FL64      strike,
                    DATESTR*  first,
                    DATESTR*  last,
                    DATESTR*  dpay,
                    CALCONV   cal)
{
    TREEOPT b ;

	/* PMSTA-22396 - SRIDHARA � 160502 */
	HOLI_STR holi;
	holi = Set_HOLI_STR(NO_BUSADJUST, 0, NULL);

    b.type      = type ;
    b.strike    = strike ;
    b.berm      = False ;
    b.dpay.first = *first ;
    b.dpay.last = *last ;
    b.pay_delay = Set_PERIOD(Cldr_DaysBetweenDates(last, dpay, cal, &holi), DAYS);    /* PMSTA-22396 - SRIDHARA � 160502 */
    b.cal       = cal;

    return b;
}


#undef MAXIT
#undef PAYM_TOL
#undef SHOCKSIZE
#undef ACC_PRICE
#undef ACC_RATE
#undef ACC_TERM
#undef LOW_BOUND

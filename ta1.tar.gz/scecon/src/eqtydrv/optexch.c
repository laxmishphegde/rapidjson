/* SCID @(#)optexch.c	1.13 (SimCorp) 99/02/19 14:14:43 */

/************************************************************************
*
*   project     SCecon
*
*   filename    optexch.c
*
*   contains    routines in the SCecon options library.
*
************************************************************************/

/***** includes ********************************************************/
#include <opteqty.h>
#include <vol.h>


/*,,SOH,,
*************************************************************************
*
*               OptExch_Black2P()
*
*    references JAS-97-07, "Exchange Options"
*               HET-97-12, "Exchange Options -- American Style"
*
*    interface  #include <opteqty.h>
*               FL64 OptExch_Black2P(DATESTR  *analys,
*                                    DATESTR  *voldate,
*                                    FL64     spot1,
*                                    FL64     spot2,
*                                    FL64     vol1,
*                                    FL64     vol2,
*                                    FL64     corr,
*                                    FL64     divyld1,
*                                    FL64     divyld2,
*                                    FUTEQTY  *fute1,
*                                    FUTEQTY  *fute2,
*                                    OPTFUT   *opt,
*                                    HOLI_STR *holi,
*                                    RISKSET  *risk,
*                                    FL64     *dp,
*                                    FL64     *ddp) ;
*
*    general    The routine calculates the premium for a Exchange
*               option using Margrabe's closed-form solution.
*
*               Key ratios are calculated as follows:
*
*                   risk->key     risk->dom  *dp     *ddp
*                   ---------     ---------  ---     ----
*                   KEY_SPOT      False      Delta1  Gamma1
*                   KEY_SPOT      True       Delta2  Gamma2
*                   KEY_GAMMAX               N/A     Mixed-Gamma
*                   KEY_MATURITY             Theta   N/A
*                   KEY_VOL                  Vega    d(Vega)/d(Vol)
*
*               The delta/gamma wrt KEY_SPOT is wrt the SPOT price.
*               This of course requires that adj is False.
*
*               2 ways of entering dividend are supported: Dividend
*               yields and discrete-time dividends.
*
*    input      DATESTR  *analys  Pointer to analysis date (NPV date)
*
*               DATESTR  *voldate Vol calculated from this date.
*
*               FL64     spot1    The spot price of underlying asset 1.
*
*               FL64     spot2    The spot price of underlying asset 2.
*
*               FL64     vol1     The annual volatility of the Spot
*                                 price 1 in percent.
*
*               FL64     vol2     The annual volatility of the Spot
*                                 price 2 in percent.
*
*               FL64     corr     The correlation between returns in
*                                 the two spot prices.
*
*               FL64     divyld1  Dividend yield of underlying asset 1
*                                 (continuous rate in %).
*
*               FL64     divyld2  Dividend yield of underlying asset 2
*                                 (continuous rate in %).
*
*               FUTEQTY  *fute1   Equity data, asset 1.
*
*               FUTEQTY  *fute2   Equity data, asset 2.
*
*               OPTFUT   *opt     The data defining the option.
*
*               HOLI_STR *holi    Holiday setup
*
*               RISKSET  *risk    The risk ratio definitions
*                                 Use NULL for no Greeks
*                                 If risk->dom is FALSE the greeks are
*                                 wrt asset 1. For greeks related to
*                                 asset 2, risk->dom must be TRUE.
*
*    output     FL64     *dp      Pointer to the first order derivative.*
*
*               FL64     *ddp     Pointer to the second order derivative*
*
*    returns    the option premium.
*
*    diagnostics
*
*    see also   OptExch_CRR2P
*
*************************************************************************
,,EOH,,*/

FL64 OptExch_Black2P(DATESTR  *analys,
                     DATESTR  *voldate,
                     FL64     spot1,
                     FL64     spot2,
                     FL64     vol1,
                     FL64     vol2,
                     FL64     corr,
                     FL64     divyld1,
                     FL64     divyld2,
                     FUTEQTY  *fute1,
                     FUTEQTY  *fute2,
                     OPTFUT   *opt,
                     HOLI_STR *holi,
                     RISKSET  *risk,
                     FL64     *dp,
                     FL64     *ddp)
{
  FL64      p, phi, plo, pmix, sk1, sk2, 
            shock, shck, vol, dum, vol_shck;
  DATESTR   anld,vold;
  OPTINT    opti;
  RISKCONV  rsk;
  KEYCONV   key;
  IRRCONV   irr;
  INTI      qbas;

  /* warning avoidance */
  phi = plo = pmix = dum = 0.0;
  p = *dp = *ddp = 0.0 ;
  
  /* Adjust spot prices for dividends */
  /* PMSTA-22396 - SRIDHARA � 160502 */
  sk1 = FutEqty_CC2AdjSpot(analys, &opt->dfix, spot1, fute1->cal, 
                           divyld1, fute1->div, holi);
  sk2 = FutEqty_CC2AdjSpot(analys, &opt->dfix, spot2, fute1->cal,
                           divyld2, fute2->div, holi);

  /* Calculate variance */
  vol = Vol_Bivariate2Vol(vol1, vol2, corr);

  /* We consider the exchange option as a call on asset 2 with strike 
     price equal to the future value of asset 1 */
  opti = optexch_set_OPTINT(analys, voldate, opt, sk1, holi) ;

  /* Keyratio setup */
  key = KEY_PRICE;
  rsk = ZERO_ORDER;
  shck = 0.0;
  irr = COMPOUND;
  qbas = ANNUALLY;

  /* Calculate premium */
  p = Black_Premium(&opti, sk2, False, 1.0, vol, 1.0, 1.0, key, rsk, 
                    shck, irr, qbas, &dum, &dum, holi);

  if (risk == NULL)
    return p ;

  /* Risk ratios */
  if (risk->risk != ZERO_ORDER)
  {
    shock = Scutl_Default_Shock(risk->shock, risk->key);

    if (risk->key == KEY_SPOT)
    {
      if (risk->dom == True)
      {
		  /* PMSTA-22396 - SRIDHARA � 160502 */
        phi = Black_Premium(&opti, sk2 + shock, False, 1.0, vol, 1.0, 1.0, 
                            key, rsk, shck, irr, qbas, &dum, &dum, holi);
        plo = Black_Premium(&opti, sk2 - shock, False, 1.0, vol, 1.0, 1.0, 
                            key, rsk, shck, irr, qbas, &dum, &dum, holi);
      }
      else
      {
		  /* PMSTA-22396 - SRIDHARA � 160502 */
        opti = optexch_set_OPTINT(analys, voldate, opt, sk1 + shock, holi) ;
        phi = Black_Premium(&opti, sk2, False, 1.0, vol, 1.0, 1.0, 
                            key, rsk, shck, irr, qbas, &dum, &dum, holi);
        
        opti = optexch_set_OPTINT(analys, voldate, opt, sk1 - shock, holi) ;
        plo = Black_Premium(&opti, sk2, False, 1.0, vol, 1.0, 1.0, 
                            key, rsk, shck, irr, qbas, &dum, &dum, holi);
      }

      *dp = (phi - plo) / (2.0 * shock) ;
      if (risk->risk == SECOND_ORDER)
        *ddp = (phi + plo - 2.0 * p) / SQR(shock) ;
    }

      /* Note that Numerical Recipes uses a wrong approximation on p. 187 */
    else if (risk->key == KEY_GAMMAX)
    {
      opti = optexch_set_OPTINT(analys, voldate, opt, sk1, holi) ;
	  /* PMSTA-22396 - SRIDHARA � 160502 */
      phi = Black_Premium(&opti, sk2 + shock, False, 1.0, vol, 1.0, 1.0, 
                          key, rsk, shck, irr, qbas, &dum, &dum, holi);
      opti = optexch_set_OPTINT(analys, voldate, opt, sk1 + shock, holi) ;
      plo = Black_Premium(&opti, sk2, False, 1.0, vol, 1.0, 1.0, 
                          key, rsk, shck, irr, qbas, &dum, &dum, holi);
      pmix = Black_Premium(&opti, sk2 + shock, False, 1.0, vol, 1.0, 1.0, 
                          key, rsk, shck, irr, qbas, &dum, &dum, holi);
      *ddp = (pmix - plo - phi + p) / SQR(shock) ;
    }

    else if (risk->key == KEY_VOL)
    {
      if (risk->dom == True)
      {
        vol_shck = vol2 + shock ;
        vol = Vol_Bivariate2Vol(vol1, vol_shck, corr);
		/* PMSTA-22396 - SRIDHARA � 160502 */
        phi = Black_Premium(&opti, sk2, False, 1.0, vol, 1.0, 1.0, 
                            key, rsk, shck, irr, qbas, &dum, &dum, holi);

        vol_shck = vol2 - shock ;
        vol = Vol_Bivariate2Vol(vol1, vol_shck, corr);
		/* PMSTA-22396 - SRIDHARA � 160502 */
        plo = Black_Premium(&opti, sk2, False, 1.0, vol, 1.0, 1.0, 
                            key, rsk, shck, irr, qbas, &dum, &dum, holi);
      }
      else
      {
        vol_shck = vol1 + shock ;
        vol = Vol_Bivariate2Vol(vol_shck, vol2, corr);
        phi = Black_Premium(&opti, sk2, False, 1.0, vol, 1.0, 1.0, 
                            key, rsk, shck, irr, qbas, &dum, &dum, holi);  /* PMSTA-22396 - SRIDHARA � 160502 */

        vol_shck = vol1 - shock ;
        vol = Vol_Bivariate2Vol(vol_shck, vol2, corr);
        plo = Black_Premium(&opti, sk2, False, 1.0, vol, 1.0, 1.0,
                            key, rsk, shck, irr, qbas, &dum, &dum, holi);    /* PMSTA-22396 - SRIDHARA � 160502 */
      }
      *dp = (phi - plo) / (2.0 * shock) ;
      if (risk->risk == SECOND_ORDER)
        *ddp = (phi + plo - 2.0 * p) / SQR(shock) ;
    }      

    else if (risk->key == KEY_MATURITY)
    {
      /* Let time decay */
		/* PMSTA-22396 - SRIDHARA � 160502 */
      anld  = Cldr_AddDays(analys, (INTL) shock, opt->cal, holi) ;
      vold  = Cldr_AddDays(voldate, (INTL) shock, opt->cal, holi) ;

      opti = optexch_set_OPTINT(&anld, &vold, opt, sk1, holi) ;

      plo = Black_Premium(&opti, sk2, False, 1.0, vol, 1.0, 1.0,
                          key, rsk, shck, irr, qbas, &dum, &dum, holi);   /* PMSTA-22396 - SRIDHARA � 160502 */

      /* Do not set ddp */
      *dp = (plo - p) / shock ;

      /* Scaling */
      *dp *= Cldr_DaysPerYear(analys, analys, 0, opt->cal, LAST, holi) ;    /* PMSTA-22396 - SRIDHARA � 160502 */
    }
  }

  return p;
}


/*,,SOH,,
*************************************************************************
*
*               OptExch_Black2Impl()
*
*    interface  #include <opteqty.h>
*               BOOLE OptExch_Black2Impl(DATESTR  *analys,
*                                    DATESTR  *voldate,
*                                    FL64     prem,
*                                    FL64     spot1,
*                                    FL64     spot2,
*                                    FL64     vol1,
*                                    FL64     vol2,
*                                    FL64     corr,
*                                    FL64     divyld1,
*                                    FL64     divyld2,
*                                    FUTEQTY  *fute1,
*                                    FUTEQTY  *fute2,
*                                    OPTFUT   *opt,
*                                    HOLI_STR *holi,
*                                    KEYCONV  key,
*                                    ITERCTRL *ictrl,
*                                    FL64     *impl) ;
*
*    general    The routine calculates implied ratios for European
*               exchange options.
*
*                The following implied ratios can be calculated
*
*                    key         implied
*                    ------      ---------
*                    KEY_STRIKE  spot1
*                    KEY_SPOT    spot2
*                    KEY_VOL     corr
*
*    input      DATESTR  *analys  Pointer to analysis date (NPV date)
*
*               DATESTR  *voldate Vol calculated from this date.
*
*               FL64     prem     The option premium
*
*               FL64     spot1    The spot price of underlying asset 1.
*
*               FL64     spot2    The spot price of underlying asset 2.
*
*               FL64     vol1     The annual volatility of the Spot
*                                 price 1 in percent.
*
*               FL64     vol2     The annual volatility of the Spot
*                                 price 2 in percent.
*
*               FL64     corr     The correlation between returns in
*                                 the two spot prices.
*
*               FL64     divyld1  Dividend yield of underlying asset 1
*                                 (continuous rate in %).
*
*               FL64     divyld2  Dividend yield of underlying asset 2
*                                 (continuous rate in %).
*
*               FUTEQTY  *fute1   Equity data, asset 1.
*
*               FUTEQTY  *fute2   Equity data, asset 2.
*
*               OPTFUT   *opt     The data defining the option.
*
*               HOLI_STR *holi    Holiday setup
*
*               KEYCONV  key      The implied ratio to find
*
*               ITERCTRL *ictrl   Iteration control
*
*
*    output     FL64     *impl    Implied ratio
*
*    returns                      True if all ok , False if not
*
*    diagnostics
*
*    see also   OptExch_Black2P
*
*************************************************************************
,,EOH,,*/

BOOLE OptExch_Black2Impl(DATESTR  *analys,
                       DATESTR  *voldate,
                       FL64     prem,
                       FL64     spot1,
                       FL64     spot2,
                       FL64     vol1,
                       FL64     vol2,
                       FL64     corr,
                       FL64     divyld1,
                       FL64     divyld2,
                       FUTEQTY  *fute1,
                       FUTEQTY  *fute2,
                       OPTFUT   *opt,
                       HOLI_STR *holi,
                       KEYCONV  key,
                       ITERCTRL *ictrl,
                       FL64     *impl)
{
  FL64      sk1, sk2, vol, temp ;
  OPTFUT    optf ;
  BOOLE     ok ;
  DISCFAC   df ;
  PLANARRAY plan ;

    /* warning avoidance */
  *impl = 0.0 ;
  sk1 = sk2 = vol = 0.0 ;
  
    /* Calculate adjusted spot1, spot2, or vol -- if needed */
  if (key != KEY_STRIKE)
    sk1 = FutEqty_CC2AdjSpot(analys, &opt->dfix, spot1, fute1->cal, 
                             divyld1, fute1->div, holi);     /* PMSTA-22396 - SRIDHARA � 160502 */

  if (key != KEY_SPOT)
    sk2 = FutEqty_CC2AdjSpot(analys, &opt->dfix, spot2, fute1->cal,
                             divyld2, fute2->div, holi);  /* PMSTA-22396 - SRIDHARA � 160502 */

  if (key != KEY_VOL)
    vol = Vol_Bivariate2Vol(vol1, vol2, corr);

    /* We consider the exchange option as a call on asset 2 with strike 
       price equal to the future value of asset 1 */
  optf = Set_OPTFUT(CALL, sk1, &opt->dfix, &opt->dpay, opt->ptype, opt->cal) ;

    /* Remember that the spot2/spot1 process has no drift */
  plan = Alloc_PLANARRAY(1,2) ;
  plan->day[0] = plan->day[1] = *analys ;
  plan->f64[0] = plan->f64[1] = 1.0 ;
  plan->day[1].y++;
  plan->filled=2;

  df = Set_DISCFAC(plan, DI_SPOT, LINEAR_FLAT_END, ACTACT, COMPOUND, ANNUALLY) ;

    /* Find implied ratio */
  ok = Option_Black2Impl(analys, voldate, prem, True, sk2, False,
                         1.0, vol, &optf, &df, holi, key, ictrl, impl) ;

    /* Back-out correlation */
  if (key == KEY_VOL)
  {
    temp = 2 * vol1 * vol2 ;
    if (fabs(temp) > 1e-4)
      *impl =  (SQR(vol1) + SQR(vol2) - SQR(*impl)) / temp ;
    else
      ok = False ;
  }

    /* Clean up */
  Free_PLANARRAY(plan, 1) ;

  return ok;
}





















/*
..
*/


OPTINT optexch_set_OPTINT(DATESTR*   analys, 
                             DATESTR*   vold, 
                             OPTFUT*    optf, 
                             FL64       strike,
                             HOLI_STR*  holi)
{
  OPTINT  opt;
  DATESTR dp, df;

  opt.analys  = *analys;
  opt.voldate = *vold;

  df = Cldr_NextBusinessDate(&optf->dfix, holi);
  dp = Cldr_NextBusinessDate(&optf->dpay, holi);

  /* We consider the exchange option as a call on asset 2 with strike 
     price equal to the future value of asset 1 */
  opt.type  = CALL;
  opt.e     = strike;
  /* PMSTA-22396 - SRIDHARA � 160502 */
  opt.tvol  = Cldr_TermBetweenDates(vold, &df, 0, optf->cal, LAST, holi);
  opt.tfix  = Cldr_TermBetweenDates(analys, &df, 0, optf->cal, LAST, holi);
  opt.t     = Cldr_TermBetweenDates(analys, &dp, 0, optf->cal, LAST, holi);
  opt.ptype = optf->ptype;
  opt.cal   = optf->cal;

  opt.oadd  = NO_OPTADD;

  return opt;
}


/* SCID @(#)futcmdty.c	1.4 (SimCorp) 99/02/19 14:14:26 */

/************************************************************************
*
*       project         SCecon
*
*       file name       futdisc.c
*
*       contains        Bond and Commodity futures calculations
*
************************************************************************/


/*** includes **********************************************************/
#include <futeqty.h>




/*,,SOH,,
*************************************************************************
*
*               FutCmdty_CC2Price()
*
*   interface   #include <futeqty.h>
*               FL64 FutCmdty_CC2Price(DATESTR  *analys,
*                                      FL64     spot,
*                                      FUTCMDTY *futc,
*                                      FL64     convyld,
*                                      FL64     stcost,
*                                      DISCFAC  *df) ;
*
*   general     This function calculates the Forward Commodity price
*               using the cost of carry model (CC).
*
*   input       DATESTR     *analys      The analys date
*
*               FL64        spot         The current spot price
*
*               FUTCMDTY    *futc        The commidity forward data
*
*               FL64        convyld      Convenience yield
*                                        CONTINUOUS rate (%)
*
*               FL64        stcost       Storage cost
*                                        CONTINUOUS rate (%)
*
*               DISCFAC     *df          Discount function
*
*	       	    HOLI_STR    *hol	     Container for list of holidays.
*
*   output
*
*   returns     The forward price
*
*   diagnostics
*
*   see also    FutCmdty_CC2NPV()
*               FutCmdty_CC2Delta
*
*************************************************************************
,,EOH,,*/

FL64 FutCmdty_CC2Price(DATESTR* analys,
                       FL64     spot,
                       FUTCMDTY* futc,
                       FL64     convyld,
                       FL64     stcost,
                       DISCFAC*  df,
					   HOLI_STR* holi)
{
    FL64 f, adj, pvd, disc, term ;
    INTI i ;

    adj = 0.0 ;

    /* Handle Convenience Yield - Eqv. to Equity Dividends */
    if (GetPlanFill(futc->cy) > 0)
    {
        for (pvd = 0.0, i = 0; i < futc->cy->filled; i++)
        {
            if (Cldr_DateLE(&futc->cy->day[i], &futc->matur) == True &&
                Cldr_DateLT(analys, &futc->matur) == True)
            {
				disc = Disc_Interpolation(&futc->cy->day[i], df, holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */
                pvd += disc * spot / 100.0 * futc->cy->f64[i] ;
            }

            adj -= pvd ;
        }
    }

    /* Handle Storage Costs - Eqv. to Interest Rates */
    if (GetPlanFill(futc->stc) > 0)
    {
        for (pvd = 0.0, i = 0; i < futc->stc->filled; i++)
        {
            if (Cldr_DateLE(&futc->stc->day[i], &futc->matur) == True &&
                Cldr_DateLT(analys, &futc->matur) == True)
            {
				disc = Disc_Interpolation(&futc->stc->day[i], df, holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */
                pvd += disc * spot / 100.0 * futc->stc->f64[i] ;
            }

            adj += pvd ;
        }
    }

    /* Handle Convenience Yield - Eqv. to Equity Dividends */
    if (GetPlanFill(futc->cy) == 0)
    {
        term  = Cldr_TermBetweenDates(analys, &futc->matur, 0, 
                                      futc->cal, SAME, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
        spot *= TVMunit_NPV(term, convyld, CONTINUOUS, 0) ;
    }

    /* Handle Storage Costs - Eqv. to Interest Rates */
    if (GetPlanFill(futc->stc) == 0)
    {
        term  = Cldr_TermBetweenDates(analys, &futc->matur, 0, 
                                      futc->cal, SAME, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
        spot /= TVMunit_NPV(term, stcost, CONTINUOUS, 0) ;
    }

    adj += spot ;

    /* Discount till forward date */
	/* PMSTA-22396 - SRIDHARA � 160502 */
    disc = Disc_Interpolation(&futc->matur, df, holi) ;  	
	Disc_forwval(df, analys, &disc, holi);  	
    if (fabs(disc) > 0.00000001)
        f = adj / disc ;
    else
        f = adj ;

    return f ;
}


/*,,SOH,,
*************************************************************************
*
*               FutCmdty_CC2NPV()
*
*   interface   #include <futeqty.h>
*               FL64 FutCmdty_CC2NPV(DATESTR  *analys,
*                                   DATESTR  *spotdate,
*                                   FL64     spot,
*                                   FL64     futp,
*                                   FUTCMDTY *futc,
*                                   FL64     convyld,
*                                   FL64     stcost,
*                                   DISCFAC  *df,
*                                   RISKSET  *risk,
*                                   FL64     *dp,
*                                   FL64     *ddp) ;
*
*   general     This function calculates the PV of a commodity futures
*               contract using the cost of carry model (CC).
*
*               Key ratios are calculated as follows:
*
*                   risk->key        dp          ddp
*                   ---------        ---         ----
*                   KEY_DF           $Dur        $Conv
*                   KEY_BPV          BPV
*
*   input       DATESTR     *analys      The PV date
*
*               DATESTR     *spotdate    The date for the spot price
*
*               FL64        spot         The current spot price
*
*               FL64        futp         The forward commodity price
*
*               FUTCMDTY    *futc        The commodity forward data
*
*               FL64        convyld      The convenience yield as a
*                                        CONTINUOUS rate (%)
*
*               FL64        stcost       Storage cost
*                                        CONTINUOUS rate (%)
*
*               DISCFAC     *df          Discount function
*
*               RISKSET     *risk        The risk ratio definitions
*                                        Use NULL for no risk ratios
*
*   output      FL64        *dp          The first order ratio
*
*               FL64        *ddp         The second order ratio.
*
*	       	    HOLI_STR    *hol	  Container for list of holidays.
*
*
*   returns     The contract PV
*
*   diagnostics
*
*   see also    FutCmdty_CC2Price()
*               FutCmdty_CC2Delta
*               
*
*************************************************************************
,,EOH,,*/


FL64 FutCmdty_CC2NPV(DATESTR  *analys,
                     DATESTR  *spotdate,
                     FL64     spot,
                     FL64     futp,
                     FUTCMDTY *futc,
                     FL64     convyld,    
                     FL64     stcost,
                     DISCFAC  *df,
                     RISKSET  *risk,
                     FL64     *dp,
                     FL64     *ddp,
					 HOLI_STR *holi)
{
    FL64    pvu, pvd, shock, f, pv ;
    DISCFAC sdf ;

    *dp = *ddp = 0.0 ;

    f  = FutCmdty_CC2Price(spotdate, spot, futc, convyld, stcost, df, holi) ;   /* PMSTA-22396 - SRIDHARA � 160502 */
    pv = f - futp ;
      /* No margin adjustment for commodity futures */
    pv = Disc_MarginAdjust(False, pv, analys, &futc->matur, df, holi) ;   /* PMSTA-22396 - SRIDHARA � 160502 */

    if (risk != NULL && (risk->key == KEY_DF || risk->key == KEY_BPV) &&
        risk->risk != ZERO_ORDER)
    {
        shock   = Scutl_Default_Shock(risk->shock, risk->key) ;

        sdf = Disc_ShockRates(df, 1.0, risk, holi) ;   /* PMSTA-22396 - SRIDHARA � 160502 */
        pvu = FutCmdty_CC2NPV(analys, spotdate, spot, futp, futc, 
                              convyld, stcost, &sdf, NULL, dp, ddp, holi) ;   /* PMSTA-22396 - SRIDHARA � 160502 */
        Free_PLANARRAY(sdf.disc, 1) ;

        sdf = Disc_ShockRates(df, - 1.0, risk, holi) ;   /* PMSTA-22396 - SRIDHARA � 160502 */
        pvd = FutCmdty_CC2NPV(analys, spotdate, spot, futp, futc, 
                              convyld, stcost, &sdf, NULL, dp, ddp, holi) ;   /* PMSTA-22396 - SRIDHARA � 160502 */
        Free_PLANARRAY(sdf.disc, 1) ;

        if (risk->key == KEY_BPV)
            shock = 1.0 ;

        *dp = (pvu - pvd) / (2.0 * shock) ;
        if (risk->risk == SECOND_ORDER && risk->key == KEY_DF)
            *ddp = (pvu + pvd - 2.0 * pv) / SQR(shock) ;
    }

    return pv ;
}

/*,,SOH,,
*************************************************************************
*
*               FutCmdty_CC2Delta()
*
*   interface   #include <futeqty.h>
*               FL64ARRAY FutCmdty_CC2Delta(DATESTR  *analys,
*                                           DATESTR  *spotdate,
*                                           FL64     spot,
*                                           FL64     futp,
*                                           FUTCMDTY *futc,
*                                           FL64     convyld,
*                                           FL64     stcost,
*                                           DISCFAC  *df,
*                                           DELTASET *ds) ;
*
*   general     This function calculates the delta vector for a
*               commodity futures contract using the cost of carry 
*               model (CC).
*
*   input       DATESTR     *analys      The PV date
*
*               DATESTR     *spotdate    The date for the spot price
*
*               FL64        spot         The current spot price
*
*               FL64        futp         The forward commodity price
*
*               FUTCMDTY    *futc        The commodity forward data
*
*               FL64        convyld      The convenience yield as a
*                                        CONTINUOUS rate (%)
*
*               FL64        stcost       Storage cost
*                                        CONTINUOUS rate (%)
*
*               DISCFAC     *df          Discount function
*
*               DELTASET    *ds          Delta vector definition
*
*	       	    HOLI_STR    *hol	  Container for list of holidays.
*
*   output      
*
*   returns     The delta vector allocated as 
*               Alloc_FL64ARRAY(ds->nshock) ;
*
*   diagnostics
*
*   see also    FutCmdty_CC2Price()
*               FutCmdty_CC2NPV()
*
*************************************************************************
,,EOH,,*/


FL64ARRAY FutCmdty_CC2Delta(DATESTR  *analys,
                            DATESTR  *spotdate,
                            FL64     spot,
                            FL64     futp,
                            FUTCMDTY *futc,
                            FL64     convyld,    
                            FL64     stcost,
                            DISCFAC  *df,
                            DELTASET *ds,
							HOLI_STR *holi)
{
  INTI      i ;
  FL64ARRAY dv ;
  FL64      p0, dum ;
  PLANARRAY old ;
  DATESTR   fsprev ;

    /* Initialise */
  dv        = Alloc_FL64ARRAY(ds->nshock) ;
  old       = df->disc ;

    /* The unshocked price */
  p0    = FutCmdty_CC2NPV(analys, spotdate, spot, futp, futc, 
                          convyld, stcost, df, NULL, &dum, &dum, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */

  for (i = 0; i < ds->nshock; i++)
  {
    fsprev = Disc_get_chgdate(NULL, old, &ds->shock[i]) ;

    if (fsprev.y > 0 && Cldr_DateLT(&futc->matur, &fsprev) == False)
    {
      df->disc = &ds->shock[i] ;
      dv[i]    = FutCmdty_CC2NPV(analys, spotdate, spot, futp, futc, 
                          convyld, stcost, df, NULL, &dum, &dum, holi) - p0 ; /* PMSTA-22396 - SRIDHARA � 160502 */

      if (ds->zero == True)
        /* Find shocked Zero PV */
      dv[i] /= Disc_DF2BPV(&ds->mid[i], df, old, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
    }
    else
      dv[i] = 0.0 ;
  }

    /* Clean up */
  df->disc = old ;

  return dv ;
}

/*,,SOH,,
*************************************************************************
*
*               FutCmdty_CC2Implyld()
*
*   interface   #include <futeqty.h>
*               FL64 FutCmdty_CC2Implyld(DATESTR  *analys,
*                                        FL64     spot,
*                                        FL64     futp,
*                                        FUTCMDTY *futc,
*                                        DISCFAC  *df) ;
*
*   general     This function calculates the Implied
*               Convenience/Storage Cost Yield
*               given the forward commodity price using the cost of
*               carry model (CC).
*
*   input       DATESTR     *analys      The analys date
*
*               FL64        spot         The current spot price
*
*               FL64        futp         The forward commodity price
*
*               FUTCMDTY    *futc        The commodity forward data
*
*               DISCFAC     *df          Discount function
*
*	       	    HOLI_STR    *hol	  Container for list of holidays.
*
*   output
*
*   returns     The implied yield as a continuously compunded rate
*
*   diagnostics
*
*   see also
*
*************************************************************************
,,EOH,,*/

FL64 FutCmdty_CC2Implyld(DATESTR* analys,
                         FL64     spot,
                         FL64     futp,
                         FUTCMDTY* futc,
                         DISCFAC*  df,
						 HOLI_STR* holi)
{
    FL64 yld, npv, tmp, t ;

    /* First find net present value of discrete dividend payments */
    npv = 0.0 ;
    if (GetPlanFill(futc->cy) > 0)
    {
        tmp = FutEqty_CC2AdjSpot(analys, &futc->matur, spot, futc->cal, 0.0,
                                 futc->cy, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
        npv = spot - tmp ;
    }

    if (GetPlanFill(futc->stc) > 0)
    {
        tmp = FutEqty_CC2AdjSpot(analys, &futc->matur, spot, futc->cal, 0.0,
                                 futc->stc, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
        npv = npv - (spot - tmp) ;
    }

    /* Do calculation */
    t   = Cldr_TermBetweenDates(analys, &futc->matur, 0, futc->cal, SAME, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
    tmp = npv + Disc_Interpolation(&futc->matur, df, holi) * futp ;
    tmp  = (fabs(spot) > 0.000001 ? tmp / spot : 0.0) ;

    Disc_forwval(df, analys, &tmp, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
    yld = TVMunit_Yield(tmp, t, CONTINUOUS, 0) ;

    /* return */
    return yld ;
}



/*,,SOH,,
************************************************************************
*
*                Set_FUTCMDTY()
*
*   interface    #include <futeqty.h>
*                FUTCMDTY Set_FUTCMDTY(DATESTR*  matur,
*                                      PLAN_STR* cy,
*                                      PLAN_STR* stc,
*                                      CALCONV   cal) ;
*
*   general      This routine sets the members of the struct defined
*                in the function name. The pointer members are simply
*                assigned - without physical copying. The intention
*                of the Set_*() routines is that by using this
*                functionality, one avoids setting individual members
*                of structs in the application code.
*
*                When new members are inserted in structs the Set_*()
*                routine will be changed accordingly.
*
*                One exception to this principle applies. Whenever
*                OPTADD and vanilla members are used, only the
*                vanilla members are set in the Set_*() routines. The
*                non-vanilla and exotic members are set to defaults,
*                and must be set elsewhere - if needed.
*
*                For details on the interpretation of the individual
*                struct members please check the struct definition.
*
*   input        DATESTR*  matur See general section.
*
*                PLAN_STR* cy    See general section.
*
*                PLAN_STR* stc   See general section.
*
*                CALCONV   cal   See general section.
*
*   output
*
*   returns      The filled out FUTCMDTY struct
*
*   diagnostics
*
*   see also     FUTCMDTY
*
************************************************************************
,,EOH,,*/

FUTCMDTY Set_FUTCMDTY(DATESTR* matur,
                             PLAN_STR* cy,
                             PLAN_STR* stc,
                             CALCONV  cal)
{
    FUTCMDTY fute ;

    fute.matur = *matur ;
    fute.cy    = cy ;
    fute.stc   = stc ;
    fute.cal   = cal ;

    return fute ;
}


/*,,SOH,,
*************************************************************************
*
*               Free_FUTCMDTY()
*
*    interface  #include <futeqty.h>
*               void Free_FUTCMDTY(FUTCMDTY *fixp) ;
*
*    general    Free_FUTCMDTY() frees memory for a FUTCMDTY. All the
*               memory is suballocated in the fixp structure.
*
*    input      FUTCMDTY     *fixp   The comodity future data container
*
*    output
*
*    returns
*
*    diagnostics
*
*    see also
*
*************************************************************************
,,EOH,,*/


void Free_FUTCMDTY(FUTCMDTY* fixp)
{
    /* Free all suballocated memory */
    Free_PLANARRAY(fixp->cy, 1);
    Free_PLANARRAY(fixp->stc, 1);
}


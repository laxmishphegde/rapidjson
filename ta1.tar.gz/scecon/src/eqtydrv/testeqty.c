/* SCCS: @(#)testeqty.c	1.19 (SimCorp) 99/09/30 11:09:59 */

/************************************************************************
*
*   project     SCecon
*
*   this program tests the routines in the option module of SCecon.
*
************************************************************************/

/*** includes ***********************************************************/
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#include <str2conv.h>
#include <bondio.h>
#include <ioconv.h>
#include <eqtyio.h>
#include <opteqty.h>
#include <futeqty.h>
#include <scenario.h>
#include <riskpos.h>
#include <eqtyval.h>
#include <optio.h>


/*** prototyping  *******************************************************/


INTI eqtytest(char* txa, FILE* in, FILE* out)
{
    char        txb[25], txc[25], txd[25], txe[25], txf[25],
                txg[25], txpl[120] ;
    FL64        spot, f, p, acc, fexp, fres, fx_spot_opt, fx_spot_home ;
    FL64        s0, low, up, fres1, fexp1, vol, vol_fx, corr, fres2, fexp2 ;
    FL64        fx, divyld, *dv, vol1, vol2, fwd, stcost, volrate, disc ;
    FL64        fx_spot, tol, notnal, beta, price, sk, e, tfix, to;
    FL64        acc1;
    FL64        s1, s2, divyld1, divyld2;
    INTI        nbuck, nstep, i, n, diff, nbucket, nshock_opt ;
    INTI        nshock_home, nshockexp, nshock, neqtyshock;
    INTI        nbuckp, nbuckr;
    RISKCONV    risk ;
    KEYCONV     wrt, what ;
    YYYYMMDD    tt, ts, te, ymd, ymd1, ymd2 ;
    CALCONV     cal ;
    DATESTR     vold, today, start, end ;
    int         i1 ;
    BOOLE       dom, is_p, ok, zero, okexp, zeroeqv, test ;
    DISCFAC     df, df1, df2, cc_df, divdf, df_f, df_d, df_p, df_r ;
    OPTFUT      opt ;
    OPTTYPE     type;
    PREMIUMTYPE ptype;
    OPTCT       ctopt ;
    TREEOPT     topt ;
    PERIOD      pd ;
    RISKSET     orisk, rs ;
    BUCKETARRAY bucket, bucket_p, bucket_r ;
    PLANARRAY   pl1, pl2, dsc, dsc1, dsc2, div, plan ;
    HOLI_STR    holi ;
    FUTCMDTY    futc ;
    FUTEQTY     fute ;
    DELTASET    ds, ds_d, ds_f;
    DATESTR     dstart, dend, analys, matur, spotd, voldate, spotdate;
    ITERCTRL    ictrl;
    FXFORW      fxfw;
    VALIDATE    val, exp_val ;
    FUTEQTY     futeqty;
    FUTEQTY     fute1, fute2;
    CCYCODE     ccy;
    FXSHOCKSET  fxs, fxs_opt, fxs_home;
    FL64ARRAY    shocks_opt, shocks_home, dvexp, shocks;
    FL64ARRAY    eqtyshocks;
    SCENARIOLIST scen;
    IRRCONV      irr;
    PMTFREQ      freq;
    EQTYSHOCKSET eqtys;
    TREEOPT      crropt;
    RISKTOKEN    token;
    FXRISKSET    fxr, fx_r, fx_p;
    RISKPOSLIST  rpos, exprpos;
    DELTASET     ds_r, ds_p;
    PLAN_STR     *plan1, *plan2 ;
    ITERCTRL     ctrl;


    acc   = 0.0001 ;
    diff = -1 ;

    if (!strcmp(txa, "OptExch_Black2P()"))
    {
        fprintf(out,"   Testing %s\n", txa) ;

        /* Read expected */
        acc = Read_FL64(in, out, "  Tolerance: ");
        fexp = Read_FL64(in, out, "  exp res: ");
        fexp1 = Read_FL64(in, out, "  exp 1st order dev: ");
        fexp2 = Read_FL64(in, out, "  exp 2nd order dev: ");

        /* Read data */
        analys = Read_DATESTR(in, out, "  Analysis: ");
        voldate = Read_DATESTR(in, out, "  Vol date: ");
        s1 = Read_FL64(in, out, "  Spot price asset 1: ");
        s2 = Read_FL64(in, out, "  Spot price asset 2: ");
        vol1 = Read_FL64(in, out, "  Vol (asset 1): ");
        vol2 = Read_FL64(in, out, "  Vol (asset 2): ");
        corr = Read_FL64(in, out, "  Correlation: ");
        divyld1 = Read_FL64(in, out, "  Cont dividend yield (asset 1): ");
        divyld2 = Read_FL64(in, out, "  Cont dividend yield (asset 2): ");
        fute1 = Read_FUTEQTY(in, out);
        fute2 = Read_FUTEQTY(in, out);
        opt = Read_OPTFUT(in, out);
        holi = Read_HOLI_STR(in, out);
        rs =  Read_RISKSET(in, out);

        /* Calculate */
        fres = OptExch_Black2P(&analys, &voldate, s1, s2, vol1, vol2, corr,
                               divyld1, divyld2, &fute1, &fute2, &opt, &holi,
                               &rs, &fres1, &fres2);
        /* Compare */
        diff = Write_RiskDiff(True, True, fres, fres1, fres2,
                              fexp, fexp1, fexp2, acc, out);

        /* Comments */
        IOUtil_ParseLine(in, out) ;

        /* Free.. */
        Free_FUTEQTY(&fute1) ;
        Free_FUTEQTY(&fute2) ;
        Free_HOLI_STR(&holi) ;
        Free_RISKSET(&rs) ;
        Free_OPTFUT(&opt) ;
    }

    if (!strcmp(txa, "OptExch_Black2Impl()"))
    {
        fprintf(out,"   Testing %s\n", txa) ;

        /* Read expected */
        acc = Read_FL64(in, out, "  Tolerance: ");
        fexp = Read_FL64(in, out, "  exp res: ");

        /* Read data */
        analys = Read_DATESTR(in, out, "  Analysis: ");
        voldate = Read_DATESTR(in, out, "  Vol date: ");
        price = Read_FL64(in, out, " Option premium     : ");
        s1 = Read_FL64(in, out, "  Spot price asset 1: ");
        s2 = Read_FL64(in, out, "  Spot price asset 2: ");
        vol1 = Read_FL64(in, out, "  Vol (asset 1): ");
        vol2 = Read_FL64(in, out, "  Vol (asset 2): ");
        corr = Read_FL64(in, out, "  Correlation: ");
        divyld1 = Read_FL64(in, out, "  Cont dividend yield (asset 1): ");
        divyld2 = Read_FL64(in, out, "  Cont dividend yield (asset 2): ");
        fute1 = Read_FUTEQTY(in, out);
        fute2 = Read_FUTEQTY(in, out);
        opt = Read_OPTFUT(in, out);
        holi = Read_HOLI_STR(in, out);
        what = Read_KEYCONV(in, out, "  Key convention :  ") ;
        Init_ITERCTRL(&ictrl) ;

        /* Calculate */
        ok = OptExch_Black2Impl(&analys, &voldate, price, s1, s2, vol1,
                                vol2, corr, divyld1, divyld2, &fute1,
                                &fute2, &opt, &holi, what, &ictrl, &fres);
        /* Compare */
        diff = Write_SingleDiff(ok, True, fres, fexp, acc, out) ;

        /* Comments */
        IOUtil_ParseLine(in, out) ;

        /* Free.. */
        Free_FUTEQTY(&fute1) ;
        Free_FUTEQTY(&fute2) ;
        Free_HOLI_STR(&holi) ;
        Free_OPTFUT(&opt) ;
    }


    if (!strcmp(txa, "black_premium_fxforw()"))
    {
        fscanf(in,"%lf %lf %lf %lf %lf %lf %lf %lf %lf %s %s %s %s %s",
               &fexp, &fexp1, &fexp2, &sk, &e, &vol, &tfix, &to, &disc,
               txc, txe, txd, txf, txpl);
        type = Str2OPTTYPE(txc) ;
        wrt  = Str2KEYCONV(txd) ;
        risk = Str2RISKCONV(txf) ;
        ptype = Str2PREMIUMTYPE(txe) ;
        fres = black_premium_fxforw(sk, e, vol, tfix, to, disc, type, ptype,
          wrt,
                                    risk, &fres1, &fres2) ;
        diff = (fabs(fres - fexp) > acc || fabs(fres1 - fexp1) > acc ||
                fabs(fres2 - fexp2) > acc);

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   option type %s\n", txc) ;
        fprintf(out,"   premiumtype %s\n", txe) ;
        fprintf(out,"   FX Forward    %8.5lf\n", sk) ;
        fprintf(out,"   strike price  %8.5lf\n", e) ;
        fprintf(out,"   fixing        %8.5lf\n", tfix) ;
        fprintf(out,"   expiry        %8.5lf\n", to) ;
        fprintf(out,"   volatility    %8.5lf\n", vol) ;
        fprintf(out,"   discount fct. %8.5lf\n", disc) ;
        fprintf(out,"   with respect to %s\n", txd) ;
        fprintf(out,"   risk calculation %s\n", txf) ;
        fprintf(out,"%d; option premium      %8.5lf expected = %8.5lf\n",
                (fabs(fres - fexp) > acc), fres, fexp);
        fprintf(out,"%d; 1. order derivative %8.5lf expected = %8.5lf\n",
                (fabs(fres1 - fexp1) > acc), fres1, fexp1);
        fprintf(out,"%d; 2. order derivative %8.5lf expected = %8.5lf\n",
                (fabs(fres2 - fexp2) > acc), fres2, fexp2);
        fprintf(out,"   %s\n\n", txpl) ;
    }

    else if (!strcmp(txa, "black_implied_fxforw()"))
    {
        fscanf(in,"%lf %lf %s %lf %lf %lf %lf %lf %lf %s %s %s %lf %lf %s",
               &fexp, &p, txb, &sk, &e, &vol, &tfix, &to, &disc, txc, txe, txd,
               &low, &up, txpl);

        acc1 = 1e-4;
        is_p  = Str2BOOLE(txb) ;
        type  = Str2OPTTYPE(txc) ;
        what  = Str2KEYCONV(txd) ;
        ptype = Str2PREMIUMTYPE(txe) ;
        ok    = black_implied_fxforw(p, is_p, sk, e, vol, tfix, to, disc,
                                     type, ptype, what, low, up, &fres) ;

        if (ok == True)
            diff = (fabs(fres - fexp) > acc1 ) ;
        else
            diff = 1 ;

        fprintf(out,"%d; testing %s\n", diff, txa) ;
        fprintf(out,"   option type   %s\n", txc) ;
        fprintf(out,"   opt.price     %8.5lf\n", p) ;
        fprintf(out,"   is_p ?        %s\n", txb) ;
        fprintf(out,"   premiumtype   %s\n", txe) ;
        fprintf(out,"   FX Forward    %8.5lf\n", sk) ;
        fprintf(out,"   strike price  %8.5lf\n", e) ;
        fprintf(out,"   volatility    %8.5lf\n", vol) ;
        fprintf(out,"   fixing        %8.5lf\n", tfix) ;
        fprintf(out,"   expiry        %8.5lf\n", to) ;
        fprintf(out,"   discount fct. %8.5lf\n", disc) ;
        fprintf(out,"   implied ratio %s\n", txd) ;
        fprintf(out,"   lower bound %8.5lf\n", low) ;
        fprintf(out,"   upper bound %8.5lf\n", up) ;
        fprintf(out,"   error code  %8d\n", ok) ;
        fprintf(out,"   result is %8lf  expected is %8lf\n", fres, fexp) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }

    else if (!strcmp(txa, "OptEqty_Black2P()"))
    {
        fscanf(in,"%lf %lf %lf %ld %lf %lf %lf",
               &fexp, &fexp1, &fexp2, &ymd, &f, &vol, &divyld) ;

        today = Cldr_YMD2Datestr(ymd) ;

        fprintf(out,"   Testing %s\n", txa) ;
        fprintf(out,"   Analysdate    %8ld\n", ymd) ;
        fprintf(out,"   Spot          %8.5lf\n", f) ;
        fprintf(out,"   Vol           %8.5lf\n", vol) ;
        fprintf(out,"   DivYld        %8.5lf\n", divyld) ;

        fute  = Read_FUTEQTY(in, out) ;
        opt   = Read_OPTFUT(in, out) ;
        orisk = Read_RISKSET(in, out) ;
        df    = Read_DISCFAC(in, out) ;
        holi  = Set_HOLI_STR(NO_BUSADJUST, 0, NULL) ;

        fres = OptEqty_Black2P(&today, &today, f, vol, divyld, &fute,
                               &opt, &df, &holi, &orisk, &fres1, &fres2) ;
        diff = Write_RiskDiff(True, True, fres, fres1, fres2, fexp, fexp1,
                              fexp2, acc, out) ;
        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_RISKSET(&orisk) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_FUTEQTY(&fute) ;
        Free_OPTFUT(&opt) ;
    }

    else if (!strcmp(txa, "OptFutEqty_Black2P()"))
    {
        fscanf(in,"%lf %lf %lf %ld %lf %lf",
               &fexp, &fexp1, &fexp2, &ymd, &f, &vol) ;

        today = Cldr_YMD2Datestr(ymd) ;

        fprintf(out,"   Testing %s\n", txa) ;
        fprintf(out,"   Analysdate    %8ld\n", ymd) ;
        fprintf(out,"   Future        %8.5lf\n", f) ;
        fprintf(out,"   Vol           %8.5lf\n", vol) ;

        zero = Read_BOOLE(in, out, "Margining  ") ;
        fscanf(in,"%ld ", &ymd) ;

        end = Cldr_YMD2Datestr(ymd) ;

        fprintf(out,"   Delivery      %8ld\n", ymd) ;

        opt   = Read_OPTFUT(in, out) ;
        orisk = Read_RISKSET(in, out) ;
        df    = Read_DISCFAC(in, out) ;
        holi  = Set_HOLI_STR(NO_BUSADJUST, 0, NULL) ;

        fres = OptFutEqty_Black2P(&today, &today, f, vol, zero, &end,
          &opt, &df, &holi, &orisk, &fres1, &fres2) ;

        diff = Write_RiskDiff(True, True, fres, fres1, fres2, fexp, fexp1,
                              fexp2, acc, out) ;
        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_RISKSET(&orisk) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_OPTFUT(&opt) ;
    }

    else if (!strcmp(txa, "OptEqtyCT_Black2P()"))
    {
        fscanf(in,"%lf %lf %lf %ld %lf %lf %lf %lf %lf %lf",
               &fexp, &fexp1, &fexp2, &ymd, &f, &fx, &vol,
               &vol_fx, &corr, &divyld) ;

        today = Cldr_YMD2Datestr(ymd) ;

        fprintf(out,"   Testing %s\n", txa) ;
        fprintf(out,"   Analysdate    %8ld\n", ymd) ;
        fprintf(out,"   Spot          %8.5lf\n", f) ;
        fprintf(out,"   FX            %8.5lf\n", fx) ;
        fprintf(out,"   Vol Spot      %8.5lf\n", vol) ;
        fprintf(out,"   Vol FX        %8.5lf\n", vol_fx) ;
        fprintf(out,"   Corr          %8.5lf\n", corr) ;
        fprintf(out,"   DivYld        %8.5lf\n", divyld) ;

        fute  = Read_FUTEQTY(in, out) ;
        ctopt = Read_OPTCT(in, out) ;
        orisk = Read_RISKSET(in, out) ;
        df1   = Read_DISCFAC(in, out) ;
        df2   = Read_DISCFAC(in, out) ;
        holi  = Set_HOLI_STR(NO_BUSADJUST, 0, NULL) ;

        fres = OptEqtyCT_Black2P(&today, &today, f, fx, vol, vol_fx, corr,
                                 divyld, &fute, &ctopt, &df1, &df2,
                                 &holi, &orisk, &fres1, &fres2) ;

        diff = Write_RiskDiff(True, True, fres, fres1, fres2, fexp, fexp1,
                              fexp2, acc, out) ;
        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_RISKSET(&orisk) ;
        Free_PLANARRAY(df1.disc, 1) ;
        Free_PLANARRAY(df2.disc, 1) ;
        Free_FUTEQTY(&fute) ;
    }

    else if (!strcmp(txa, "OptCmdty_Black2P()"))
    {
        fscanf(in,"%lf %lf %lf %ld %lf %lf %lf",
               &fexp, &fexp1, &fexp2, &ymd, &f, &vol, &divyld) ;

        today = Cldr_YMD2Datestr(ymd) ;

        fprintf(out,"   Testing %s\n", txa) ;
        fprintf(out,"   Analysdate    %8ld\n", ymd) ;
        fprintf(out,"   Spot          %8.5lf\n", f) ;
        fprintf(out,"   Vol           %8.5lf\n", vol) ;
        fprintf(out,"   ConvYld.      %8.5lf\n", divyld) ;

        futc  = Read_FUTCMDTY(in, out) ;
        opt   = Read_OPTFUT(in, out) ;
        orisk = Read_RISKSET(in, out) ;
        df    = Read_DISCFAC(in, out) ;
        holi  = Set_HOLI_STR(NO_BUSADJUST, 0, NULL) ;

        fres = OptCmdty_Black2P(&today, &today, f, vol, divyld, 0.0,
                                &futc, &opt, &df, &holi, &orisk, &fres1,
                                &fres2) ;
        diff = Write_RiskDiff(True, True, fres, fres1, fres2, fexp, fexp1,
                              fexp2, acc, out) ;
        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_RISKSET(&orisk) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_FUTCMDTY(&futc) ;
        Free_OPTFUT(&opt) ;
    }

    else if (!strcmp(txa, "OptFutFX_Black2P()"))
    {
        fscanf(in,"%lf %lf %lf %ld %ld %lf %lf",
               &fexp, &fexp1, &fexp2, &ymd, &ymd1, &f, &vol) ;

        today = Cldr_YMD2Datestr(ymd) ;
        vold  = Cldr_YMD2Datestr(ymd1) ;

        fprintf(out,"   Testing %s\n", txa) ;
        fprintf(out,"   Analysdate    %8ld\n", ymd) ;
        fprintf(out,"   Vol.Date      %8ld\n", ymd1) ;
        fprintf(out,"   Future price  %8.5lf\n", f) ;
        fprintf(out,"   Vol           %8.5lf\n", vol) ;

        opt   = Read_OPTFUT(in, out) ;
        orisk = Read_RISKSET(in, out) ;
        df    = Read_DISCFAC(in, out) ;
        holi  = Set_HOLI_STR(NO_BUSADJUST, 0, NULL) ;

        fres = OptFutFX_Black2P(&today, &vold, f, vol, &opt, &df, &holi,
                                &orisk, &fres1, &fres2) ;
        diff = Write_RiskDiff(True, True, fres, fres1, fres2, fexp, fexp1,
                              fexp2, acc, out) ;
        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_RISKSET(&orisk) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_OPTFUT(&opt) ;
    }


    else if (!strcmp(txa, "OptFX_Black2P()") ||
             !strcmp(txa, "OptFutFX_Black2DFp()") )
    {
        fscanf(in, "%lf %lf %lf %ld %ld %lf",
               &fexp, &fexp1, &fexp2, &ymd, &ymd1, &vol) ;

        today = Cldr_YMD2Datestr(ymd) ;
        vold  = Cldr_YMD2Datestr(ymd1) ;

        fprintf(out,"   Testing %s\n", txa) ;
        fprintf(out,"   Analysdate    %8ld\n", ymd) ;
        fprintf(out,"   Vol.Date      %8ld\n", ymd1) ;
        fprintf(out,"   Vol           %8.5lf\n", vol) ;

        fscanf(in, "%lf %ld\n", &fx, &ymd) ;
        end = Cldr_YMD2Datestr(ymd) ;

        fprintf(out,"   FX_spot       %8.5lf\n", fx) ;
        fprintf(out,"   SpotDate      %8ld\n", ymd) ;

        opt   = Read_OPTFUT(in, out) ;
        df    = Read_DISCFAC(in, out) ;
        df1   = Read_DISCFAC(in, out) ;
        holi  = Set_HOLI_STR(NO_BUSADJUST, 0, NULL) ;
        orisk = Read_RISKSET(in, out) ;

        if (!strcmp(txa, "OptFX_Black2P()"))
            fres = OptFX_Black2P(&today, &vold, vol, fx, &end, &opt, &df,
                                 &df1, &holi, &orisk, &fres1, &fres2) ;
        else
            fres = OptFutFX_Black2DFp(&today, &vold, vol, fx, &end, &opt,
                                      &df, &df1, &holi, &orisk, &fres1,
                                      &fres2) ;

        diff = Write_RiskDiff(True, True, fres, fres1, fres2, fexp, fexp1,
                              fexp2, acc, out) ;
        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_RISKSET(&orisk) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_PLANARRAY(df1.disc, 1) ;
        Free_OPTFUT(&opt) ;
    }

    else if (!strcmp(txa, "OptFX_Black2Impl()"))
    {
        fscanf(in, "%lf %ld %ld %lf %s %lf",
               &fexp, &ymd, &ymd1, &p, txb, &vol) ;

        today = Cldr_YMD2Datestr(ymd) ;
        vold  = Cldr_YMD2Datestr(ymd1) ;
        is_p  = Str2BOOLE(txb) ;

        fprintf(out,"   Testing %s\n", txa) ;
        fprintf(out,"   Analysdate    %8ld\n", ymd) ;
        fprintf(out,"   VolDate       %8ld\n", ymd1) ;
        fprintf(out,"   Option Price  %8.5lf\n", p) ;
        fprintf(out,"   Is-P ?        %8s\n", txb) ;
        fprintf(out,"   Vol           %8.5lf\n", vol) ;

        fscanf(in, "%lf %ld\n", &fx, &ymd) ;
        end = Cldr_YMD2Datestr(ymd) ;

        fprintf(out,"   FX_spot       %8.5lf\n", fx) ;
        fprintf(out,"   SpotDate      %8ld\n", ymd) ;

        opt = Read_OPTFUT(in, out) ;
        df  = Read_DISCFAC(in, out) ;
        df1 = Read_DISCFAC(in, out) ;
        holi  = Set_HOLI_STR(NO_BUSADJUST, 0, NULL) ;

        fscanf(in, "%s", txd) ;
        fprintf(out,"   Key           %8s\n", txd) ;
        what = Str2KEYCONV(txd) ,

        ctrl = Read_ITERCTRL(in, out);

        ok = OptFX_Black2Impl(&today, &vold, p, is_p, vol, fx, &end,
                              &opt, &df, &df1, &holi, what, &ctrl, &fres) ;
        diff = Write_SingleDiff(ok, True, fres, fexp, acc, out) ;
        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_PLANARRAY(df.disc, 1) ;
        Free_PLANARRAY(df1.disc, 1) ;
        Free_OPTFUT(&opt) ;
    }

    else if (!strcmp(txa, "OptFX_Black2Delta()"))
    {
        fscanf(in, "%ld %lf", &ymd, &vol) ;

        today = Cldr_YMD2Datestr(ymd) ;

        fprintf(out,"   Testing %s\n", txa) ;
        fprintf(out,"   Analysdate    %8ld\n", ymd) ;
        fprintf(out,"   Vol           %8.5lf\n", vol) ;

        fscanf(in, "%lf %ld\n", &fx, &ymd) ;
        end = Cldr_YMD2Datestr(ymd) ;

        fprintf(out,"   FX_spot       %8.5lf\n", fx) ;
        fprintf(out,"   SpotDate      %8ld\n", ymd) ;

        opt = Read_OPTFUT(in, out) ;
        df  = Read_DISCFAC(in, out) ;
        df1 = Read_DISCFAC(in, out) ;
        holi  = Set_HOLI_STR(NO_BUSADJUST, 0, NULL) ;

        bucket = Read_BUCKETARRAY(in, out, &nbuck) ;

        fscanf(in, " %s %s", txc, txb) ;
        dom = Str2BOOLE(txc) ;
        zero = Str2BOOLE(txb) ;
        fprintf(out,"   Domestic      %8s\n", txc) ;
        fprintf(out,"   DECF          %8s\n", txb) ;

        if (dom == True)
            ds = Disc_DeltaPrep(&df, bucket, nbuck, &holi, False,
                                 df.irr, df.freq, dom, zero, DF_BOTH) ;
        else
            ds = Disc_DeltaPrep(&df1, bucket, nbuck, &holi, False,
                                 df1.irr, df1.freq, dom, zero, DF_BOTH) ;

        dv = OptFX_Black2Delta(&today, &today, vol, fx, &end, &opt, &df,
                               &df1, &holi, &ds) ;
        diff = 0 ;
        for (i = 0; i < nbuck; i++)
        {
            fscanf(in, "%lf", &fexp) ;
            diff = diff || fabs(fexp - dv[i]) > 0.00001 ;
            fprintf(out, "%d; %d exp %lf res %lf\n",
                    fabs(fexp - dv[i]) > 0.00001, i, fexp, dv[i]) ;
        }

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_PLANARRAY(df.disc, 1) ;
        Free_PLANARRAY(df1.disc, 1) ;
        Free_DELTASET(&ds) ;
        Free_BUCKETARRAY(bucket) ;
        Free_FL64ARRAY(dv) ;
        Free_OPTFUT(&opt) ;
    }

    else if (!strcmp(txa, "OptFX_CRR2Delta()"))
    {
        fprintf(out,"   Testing %s\n", txa) ;

        today = Read_DATESTR(in, out, "   Analysis   ") ;
        fx = Read_FL64(in, out, "   FX_spot   ") ;
        vol = Read_FL64(in, out, "   vol   ") ;
        nstep = Read_INTI(in, out, "   NStep   ") ;
        topt = Read_TREEOPT(in, out) ;
        df  = Read_DISCFAC(in, out) ;
        df1 = Read_DISCFAC(in, out) ;
        holi  = Set_HOLI_STR(NO_BUSADJUST, 0, NULL) ;
        dom = Read_BOOLE(in, out, "   Domestic shocks   ") ;
        bucket = Read_BUCKETARRAY(in, out, &nbuck) ;

        if (dom == True)
            ds = Disc_DeltaPrep(&df, bucket, nbuck, &holi, False,
                                 df.irr, df.freq, dom, False, DF_BOTH) ;
        else
            ds = Disc_DeltaPrep(&df1, bucket, nbuck, &holi, False,
                                 df1.irr, df1.freq, dom, False, DF_BOTH) ;

        dv = OptFX_CRR2Delta(&today, fx, vol, nstep, &topt, &df, &df1,
                             &holi, &ds, &ok) ;

        diff = 0 ;
        if (ok == False)
        {
            diff = 1 ;
            fprintf(out, "1; Cannot find Delta Vec\n") ;
        }
        else
        {
            for (i = 0; i < nbuck; i++)
            {
                fscanf(in, "%lf", &fexp) ;
                diff = diff || fabs(fexp - dv[i]) > 0.00001 ;
                fprintf(out, "%d; %d exp %lf res %lf\n",
                        fabs(fexp - dv[i]) > 0.00001, i, fexp, dv[i]) ;
            }
        }

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_DISCFAC(&df) ;
        Free_DISCFAC(&df1) ;
        Free_DELTASET(&ds) ;
        Free_BUCKETARRAY(bucket) ;
        Free_FL64ARRAY(dv) ;
        Free_DATEARRAY(topt.dpay.irreg_days) ;
    }


    else if (!strcmp(txa, "OptEqty_Black2Impl()"))
    {
        fscanf(in,"%lf %lf %s %ld %lf %lf %lf",
               &fexp, &p, &txb, &ymd, &f, &vol, &divyld) ;

        today = Cldr_YMD2Datestr(ymd) ;
        is_p = Str2BOOLE(txb) ;

        fprintf(out,"   Testing %s\n", txa) ;
        fprintf(out,"   Analysdate    %8ld\n", ymd) ;
        fprintf(out,"   Option Price  %8.5lf\n", p) ;
        fprintf(out,"   Is-P ?        %8s\n", txb) ;
        fprintf(out,"   Spot          %8.5lf\n", f) ;
        fprintf(out,"   Vol           %8.5lf\n", vol) ;
        fprintf(out,"   DivYld        %8.5lf\n", divyld) ;

        fute = Read_FUTEQTY(in, out) ;
        opt  = Read_OPTFUT(in, out) ;
        holi  = Set_HOLI_STR(NO_BUSADJUST, 0, NULL) ;

        fscanf(in, "%s", txb) ;
        fprintf(out,"   Solve for     %8s\n", txb) ;
        what = Str2KEYCONV(txb) ;

        df = Read_DISCFAC(in, out) ;

        ctrl = Read_ITERCTRL(in, out);

        fres = 0.0 ;
        ok = OptEqty_Black2Impl(&today, &today, p, is_p, f, vol, divyld,
                                &fute, &opt, &df, &holi, what, &ctrl,
                                &fres) ;

        diff = Write_SingleDiff(ok, True, fres, fexp, acc, out) ;
        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_PLANARRAY(df.disc, 1) ;
        Free_PLANARRAY(fute.div, 1) ;
        Free_OPTFUT(&opt) ;
    }

    else if (!strcmp(txa, "OptCmdty_Black2Impl()"))
    {
        fscanf(in,"%lf %lf %s %ld %lf %lf %lf",
               &fexp, &p, &txb, &ymd, &f, &vol, &divyld) ;

        today = Cldr_YMD2Datestr(ymd) ;
        is_p = Str2BOOLE(txb) ;

        fprintf(out,"   Testing %s\n", txa) ;
        fprintf(out,"   Analysdate    %8ld\n", ymd) ;
        fprintf(out,"   Option Price  %8.5lf\n", p) ;
        fprintf(out,"   Is-P ?        %8s\n", txb) ;
        fprintf(out,"   Spot          %8.5lf\n", f) ;
        fprintf(out,"   Vol           %8.5lf\n", vol) ;
        fprintf(out,"   ConvYld       %8.5lf\n", divyld) ;

        futc = Read_FUTCMDTY(in, out) ;
        opt = Read_OPTFUT(in, out) ;

        fscanf(in, "%s", txb) ;
        fprintf(out,"   Solve for     %8s\n", txb) ;
        what = Str2KEYCONV(txb) ;

        df = Read_DISCFAC(in, out) ;
        holi  = Set_HOLI_STR(NO_BUSADJUST, 0, NULL) ;

        ctrl = Read_ITERCTRL(in, out);

        fres = 0.0 ;
        ok = OptCmdty_Black2Impl(&today, &today, p, is_p, f, vol, divyld,
                                 0.0, &futc, &opt, &df, &holi, what, &ctrl,
                                 &fres)
                                   ;
        diff = Write_SingleDiff(ok, True, fres, fexp, acc, out) ;
        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_PLANARRAY(df.disc, 1) ;
        Free_PLANARRAY(futc.cy, 1) ;
        Free_PLANARRAY(futc.stc, 1) ;
        Free_OPTFUT(&opt) ;
    }

    else if (!strcmp(txa, "OptFutFX_Black2Impl()"))
    {
        fscanf(in,"%lf %lf %s %ld %ld %lf %lf",
               &fexp, &p, &txb, &ymd, &ymd1, &f, &vol) ;

        today = Cldr_YMD2Datestr(ymd) ;
        vold  = Cldr_YMD2Datestr(ymd1) ;
        is_p = Str2BOOLE(txb) ;

        fprintf(out,"   Testing %s\n", txa) ;
        fprintf(out,"   Analysdate    %8ld\n", ymd) ;
        fprintf(out,"   Vol.Date      %8ld\n", ymd1) ;
        fprintf(out,"   Option Price  %8.5lf\n", p) ;
        fprintf(out,"   Is-P ?        %8s\n", txb) ;
        fprintf(out,"   Future price  %8.5lf\n", f) ;
        fprintf(out,"   Vol           %8.5lf\n", vol) ;

        opt = Read_OPTFUT(in, out) ;

        fscanf(in, "%s", txb) ;
        fprintf(out,"   Solve for     %8s\n", txb) ;
        what = Str2KEYCONV(txb) ;

        df = Read_DISCFAC(in, out) ;
        holi  = Set_HOLI_STR(NO_BUSADJUST, 0, NULL) ;

        ctrl = Read_ITERCTRL(in, out);

        fres = 0.0 ;
        ok = OptFutFX_Black2Impl(&today, &vold, p, is_p, f, vol, &opt,
                                 &df, &holi, what, &ctrl, &fres) ;
        diff = Write_SingleDiff(ok, True, fres, fexp, acc, out) ;

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_PLANARRAY(df.disc, 1) ;
        Free_OPTFUT(&opt) ;
    }


    else if (!strcmp(txa, "OptEqty_CRR2P()"))
    {
        fprintf(out,"   Testing %s\n", txa) ;

        /* Exp result */
        fexp = Read_FL64(in, out, "   Exp Prem   ") ;
        fexp1 = Read_FL64(in, out, "   Exp 1st order Derivative   ") ;
        fexp2 = Read_FL64(in, out, "   Exp 2nd order Derivative   ") ;

        /* Read data */
        today = Read_DATESTR(in, out, "   Analysis   ") ;
        vol = Read_FL64(in, out, "   Vol   ") ;
        s0 = Read_FL64(in, out, "   Spot   ") ;
        n = Read_INTI(in, out, "   NStep   ") ;
        topt = Read_TREEOPT(in, out) ;
        fute = Read_FUTEQTY(in, out) ;
        cc_df = Read_DISCFAC(in, out) ;
        df = Read_DISCFAC(in, out) ;
        holi = Read_HOLI_STR(in, out) ;
        orisk = Read_RISKSET(in, out) ;

        /* Calculate */
        ok = OptEqty_CRR2P(&today, s0, vol, n, &cc_df, &fute, &topt, &df,
                            &holi, &orisk, &fres, &fres1, &fres2) ;

        /* Compare */
        diff = Write_RiskDiff(ok, True, fres, fres1, fres2,
                              fexp, fexp1, fexp2, acc, out) ;

        /* Comments */
        IOUtil_ParseLine(in, out) ;

        /* Free.. */
        Free_FUTEQTY(&fute) ;
        Free_DISCFAC(&df) ;
        Free_DISCFAC(&cc_df) ;
        Free_HOLI_STR(&holi) ;
        Free_RISKSET(&orisk) ;
        Free_PAYDAYDEF(&topt.dpay) ;
    }

    else if (!strcmp(txa, "OptFX_CRR2P()"))
    {
        fprintf(out,"\n   testing %s\n", txa) ;

        /* Exp result */
        fexp = Read_FL64(in, out, "   Exp Prem   ") ;
        fexp1 = Read_FL64(in, out, "   Exp 1st order Derivative   ") ;
        fexp2 = Read_FL64(in, out, "   Exp 2nd order Derivative   ") ;

        /* Read data */
        today = Read_DATESTR(in, out, "   Analysis   ") ;
        vol = Read_FL64(in, out, "   Vol   ") ;
        s0 = Read_FL64(in, out, "   Spot   ") ;
        n = Read_INTI(in, out, "   NStep   ") ;
        topt = Read_TREEOPT(in, out) ;
        df = Read_DISCFAC(in, out) ;
        df1 = Read_DISCFAC(in, out) ;
        holi  = Set_HOLI_STR(NO_BUSADJUST, 0, NULL) ;
        orisk = Read_RISKSET(in, out) ;

        /* Calculate */
        ok = OptFX_CRR2P(&today, s0, vol, n, &topt, &df, &df1, &holi,
                         &orisk, &fres, &fres1, &fres2) ;

        /* Compare */
        diff = Write_RiskDiff(ok, True, fres, fres1, fres2,
                              fexp, fexp1, fexp2, acc, out) ;

        /* Comments */
        IOUtil_ParseLine(in, out) ;

        /* Free.. */
        Free_PAYDAYDEF(&topt.dpay) ;
        Free_DISCFAC(&df) ;
        Free_DISCFAC(&df1) ;
        Free_RISKSET(&orisk) ;
        Free_HOLI_STR(&holi) ;
    }

    else if (!strcmp(txa, "OptCmdty_CRR2P()"))
    {
        fscanf(in,"%lf %lf %lf %d %lf %s %lf %ld %ld %ld %lf %s %s %s %s",
               &fexp, &fexp1, &fexp2, &i1, &vol, txg, &s0, &tt, &ts, &te,
               &topt.strike, txc, txd, txf, txe) ;

        pd.num = 0 ;
        pd.unit = DAYS ;
        n     = (INTI) i1 ;
        today = Cldr_YMD2Datestr(tt) ;
        topt.dpay.first = start = Cldr_YMD2Datestr(ts) ;
        topt.dpay.last  = end   = Cldr_YMD2Datestr(te) ;
        topt.berm = False ;
        topt.pay_delay = pd ;
        topt.type = Str2OPTTYPE(txc) ;
        wrt   = Str2KEYCONV(txd) ;
        risk  = Str2RISKCONV(txf) ;
        cal   = topt.cal = Str2CALCONV(txe) ;

        fprintf(out,"\n   testing %s\n", txa) ;
        fprintf(out,"   levels      %d\n", n) ;
        fprintf(out,"   option type %s\n", txc) ;
        fprintf(out,"   spot price    %8.5lf\n", s0) ;
        fprintf(out,"   strike price  %8.5lf\n", topt.strike) ;
        fprintf(out,"   today         %8ld\n", tt) ;
        fprintf(out,"   first strike  %8ld\n", ts) ;
        fprintf(out,"   last strike   %8ld\n", te) ;
        fprintf(out,"   pay delay     %d %s\n", pd.num, "DAYS") ;
        fprintf(out,"   irrconv       %8s\n", txg) ;
        fprintf(out,"   volatility    %8.5lf\n", vol) ;
        fprintf(out,"   with respect to  %s\n", txd) ;
        fprintf(out,"   risk calculation %s\n", txf) ;
        fprintf(out,"   calendar         %s\n", txe) ;

        /* Read Convenience Yield DF + Plan */
        dsc = Read_PLANARRAY(in) ;
        fprintf(out,"   Conv.Yield DF is:\n") ;
        Write_PLANARRAY(out, dsc) ;
        df = Set_DISCFAC(dsc, DI_SPOT, LINEAR_EXTRAPOL, cal,
                              Str2IRRCONV(txg), ANNUALLY) ;

        pl1 = Read_PLANARRAY(in) ;
        fprintf(out,"   Discr. Conv.Yield is:\n") ;
        Write_PLANARRAY(out, pl1) ;

        /* Read Storage DF */
        dsc1 = Read_PLANARRAY(in) ;
        fprintf(out,"   Storage Cost DF is:\n") ;
        Write_PLANARRAY(out, dsc1) ;
        df1 = Set_DISCFAC(dsc1, DI_SPOT, LINEAR_EXTRAPOL, cal,
                               Str2IRRCONV(txg), ANNUALLY) ;
        pl2 = Read_PLANARRAY(in) ;
        fprintf(out,"   Discr. Storage Costs:\n") ;
        Write_PLANARRAY(out, pl2) ;

        futc = Set_FUTCMDTY(&today, pl1, pl2, cal) ;

        /* Read DF */
        dsc2 = Read_PLANARRAY(in) ;
        fprintf(out,"   DF is:\n") ;
        Write_PLANARRAY(out, dsc2) ;
        df2 = Set_DISCFAC(dsc2, DI_SPOT, LINEAR_EXTRAPOL, cal,
                               Str2IRRCONV(txg), ANNUALLY) ;

        holi  = Set_HOLI_STR(NO_BUSADJUST, 0, NULL) ;
        orisk = Set_RISKSET(wrt, risk, -1.0,
                                 Str2IRRCONV(txg), ANNUALLY, NULL, True) ;

        ok = OptCmdty_CRR2P(&today, s0, vol, n, &topt, &df,
                            &df1, &futc, &df2, &holi, &orisk, &fres,
                              &fres1, &fres2) ;

        diff = (fabs(fres - fexp) > acc || fabs(fres1 - fexp1) > acc ||
                fabs(fres2 - fexp2) > acc);

        fprintf(out,"   Error code  %d\n", ok) ;
        fprintf(out,"%d; option premium      %8.5lf expected = %8.5lf\n",
                (fabs(fres - fexp) > acc), fres, fexp);
        fprintf(out,"%d; 1. order derivative %8.5lf expected = %8.5lf\n",
                (fabs(fres1 - fexp1) > acc), fres1, fexp1);
        fprintf(out,"%d; 2. order derivative %8.5lf expected = %8.5lf\n",
                (fabs(fres2 - fexp2) > acc), fres2, fexp2);

        fscanf(in,"%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_PLANARRAY(dsc, 1) ;
        Free_PLANARRAY(dsc1, 1) ;
        Free_PLANARRAY(dsc2, 1) ;
        Free_PLANARRAY(pl1, 1) ;
        Free_PLANARRAY(pl2, 1) ;
    }

    else if (!strcmp(txa, "OptExch_CRR2P()"))
    {
        fprintf(out,"   Testing %s\n", txa) ;

        acc     = Read_FL64(in, out, "  Tolerance:         ");
        fexp    = Read_FL64(in, out, "  exp res:           ");
        fexp1   = Read_FL64(in, out, "  exp 1st order dev: ");
        fexp2   = Read_FL64(in, out, "  exp 2nd order dev: ");

        today   = Read_DATESTR(in, out, "   Analys   ") ;
        s1      = Read_FL64(in, out, "   Spot 1    ") ;
        s2      = Read_FL64(in, out, "   Spot 2    ") ;
        vol1    = Read_FL64(in, out, "   Vol 1     ") ;
        vol2    = Read_FL64(in, out, "   Vol 2     ") ;
        corr    = Read_FL64(in, out, "   Corr      ") ;
        df1     = Read_DISCFAC(in, out) ;
        df2     = Read_DISCFAC(in, out) ;
        plan1   = Read_PLANARRAY(in) ;
        plan2   = Read_PLANARRAY(in) ;
        nstep   = Read_INTI(in, out, "   Steps    ") ;
        topt    = Read_TREEOPT(in, out) ;
        holi    = Read_HOLI_STR(in, out) ;
        rs      = Read_RISKSET(in, out) ;

        IOUtil_ParseLine(in, out) ;

        ok = OptExch_CRR2P(&today, s1, s2, vol1, vol2, corr,
                           &df1, &df2, plan1, plan2,
                           nstep, &topt, &holi, &rs,
                           &fres, &fres1, &fres2) ;

        diff = Write_RiskDiff(True, True, fres, fres1, fres2,
                              fexp, fexp1, fexp2, acc, out);

        Free_DISCFAC(&df1) ;
        Free_DISCFAC(&df2) ;
        Free_PLANARRAY(plan1, 1) ;
        Free_PLANARRAY(plan2, 1) ;
        Free_HOLI_STR(&holi) ;
        Free_PAYDAYDEF(&topt.dpay) ;
    }

    else if (!strcmp(txa, "OptExch_CRR2Impl()"))
    {
        fprintf(out,"   Testing %s\n", txa) ;

        acc     = Read_FL64(in, out, "  Tolerance:         ");
        fexp    = Read_FL64(in, out, "  exp res:           ");

        today   = Read_DATESTR(in, out, "   Analys   ") ;
        price   = Read_FL64(in, out, "   Premium   ") ;
        s1      = Read_FL64(in, out, "   Spot 1    ") ;
        s2      = Read_FL64(in, out, "   Spot 2    ") ;
        vol1    = Read_FL64(in, out, "   Vol 1     ") ;
        vol2    = Read_FL64(in, out, "   Vol 2     ") ;
        corr    = Read_FL64(in, out, "   Corr      ") ;
        df1     = Read_DISCFAC(in, out) ;
        df2     = Read_DISCFAC(in, out) ;
        plan1   = Read_PLANARRAY(in) ;
        plan2   = Read_PLANARRAY(in) ;
        nstep   = Read_INTI(in, out, "   Steps    ") ;
        topt    = Read_TREEOPT(in, out) ;
        holi    = Read_HOLI_STR(in, out) ;
        what    = Read_KEYCONV(in, out, "   Key      ") ;
        ctrl    = Read_ITERCTRL(in, out) ;

        ok = OptExch_CRR2Impl(&today, price, s1, s2, vol1, vol2,
                              corr, &df1, &df2, plan1, plan2,
                              nstep, &topt, &holi, what,
                              &ctrl, &fres) ;

        diff = Write_SingleDiff(ok, True, fres, fexp, acc, out) ;

        IOUtil_ParseLine(in, out) ;

        Free_DISCFAC(&df1) ;
        Free_DISCFAC(&df2) ;
        Free_PLANARRAY(plan1, 1) ;
        Free_PLANARRAY(plan2, 1) ;
        Free_HOLI_STR(&holi) ;
        Free_PAYDAYDEF(&topt.dpay) ;
    }

    else if (!strcmp(txa, "OptFX_CRR2Impl()"))
    {
        fprintf(out,"?; testing %s\n", txa) ;

        /* Exp result */
        fexp = Read_FL64(in, out, "   Exp implied result   ") ;

        /* Read data */
        today = Read_DATESTR(in, out, "   Analysis   ") ;
        p = Read_FL64(in, out, "   Premium   ") ;
        vol = Read_FL64(in, out, "   Vol   ") ;
        s0 = Read_FL64(in, out, "   Spot   ") ;
        n = Read_INTI(in, out, "   NStep   ") ;
        topt = Read_TREEOPT(in, out) ;
        df = Read_DISCFAC(in, out) ;
        df1 = Read_DISCFAC(in, out) ;
        holi = Set_HOLI_STR(NO_BUSADJUST, 0, NULL) ;
        what = Read_KEYCONV(in, out, "   What?   ") ;
        ctrl = Read_ITERCTRL(in, out) ;

        /* Calculate */
        fres = 0.0 ;
        ok = OptFX_CRR2Impl(&today, p, s0, vol, n, &topt, &df, &df1, &holi,
                            what, &ctrl, &fres) ;

        /* Comments */
        IOUtil_ParseLine(in, out);

        diff = Write_SingleDiff(ok, True, fres, fexp, acc, out) ;

        /* Free.. */
        Free_PAYDAYDEF(&topt.dpay) ;
        Free_DISCFAC(&df) ;
        Free_DISCFAC(&df1) ;
    }

    else if (!strcmp(txa, "OptCmdty_CRR2Impl()"))
    {
        fscanf(in,"%lf %lf %d %lf %s %lf %ld %ld %ld %lf %s %s %s",
               &fexp, &p, &i1, &vol, txg, &s0, &tt, &ts, &te,
               &topt.strike, txc, txd, txe) ;

        pd.num = 0 ;
        pd.unit = DAYS ;
        n     = (INTI) i1 ;
        today = Cldr_YMD2Datestr(tt) ;
        topt.dpay.first = start = Cldr_YMD2Datestr(ts) ;
        topt.dpay.last  = end   = Cldr_YMD2Datestr(te) ;
        topt.berm = False ;
        topt.pay_delay = pd ;
        topt.type = Str2OPTTYPE(txc) ;
        wrt = Str2KEYCONV(txd) ;
        cal = topt.cal = Str2CALCONV(txe) ;

        fprintf(out,"\n   testing %s\n", txa) ;
        fprintf(out,"   levels      %d\n", n) ;
        fprintf(out,"   option type %s\n", txc) ;
        fprintf(out,"   spot price    %8.5lf\n", s0) ;
        fprintf(out,"   strike price  %8.5lf\n", topt.strike) ;
        fprintf(out,"   today         %8ld\n", tt) ;
        fprintf(out,"   first strike  %8ld\n", ts) ;
        fprintf(out,"   last strike   %8ld\n", te) ;
        fprintf(out,"   pay delay     %d %s\n", pd.num, "DAYS") ;
        fprintf(out,"   irrconv       %8s\n", txg) ;
        fprintf(out,"   volatility    %8.5lf\n", vol) ;
        fprintf(out,"   with respect to  %s\n", txd) ;
        fprintf(out,"   calendar         %s\n", txe) ;
        ctrl = Read_ITERCTRL(in, out) ;

        /* Read Convenience Yield DF + Plan */
        dsc = Read_PLANARRAY(in) ;
        fprintf(out,"   Conv.Yield DF is:\n") ;
        Write_PLANARRAY(out, dsc) ;
        df = Set_DISCFAC(dsc, DI_SPOT, LINEAR_EXTRAPOL, cal,
                              Str2IRRCONV(txg), ANNUALLY) ;

        pl1 = Read_PLANARRAY(in) ;
        fprintf(out,"   Discr. Conv.Yield is:\n") ;
        Write_PLANARRAY(out, pl1) ;

        /* Read Storage DF */
        dsc1 = Read_PLANARRAY(in) ;
        fprintf(out,"   Storage Cost DF is:\n") ;
        Write_PLANARRAY(out, dsc1) ;
        df1 = Set_DISCFAC(dsc1, DI_SPOT, LINEAR_EXTRAPOL, cal,
                               Str2IRRCONV(txg), ANNUALLY) ;
        pl2 = Read_PLANARRAY(in) ;
        fprintf(out,"   Discr. Storage Costs:\n") ;
        Write_PLANARRAY(out, pl2) ;

        futc = Set_FUTCMDTY(&today, pl1, pl2, cal) ;

        /* Read DF */
        dsc2 = Read_PLANARRAY(in) ;
        fprintf(out,"   DF is:\n") ;
        Write_PLANARRAY(out, dsc2) ;
        df2 = Set_DISCFAC(dsc2, DI_SPOT, LINEAR_EXTRAPOL, cal,
                               Str2IRRCONV(txg), ANNUALLY) ;
        holi  = Set_HOLI_STR(NO_BUSADJUST, 0, NULL) ;

        ok = OptCmdty_CRR2Impl(&today, p, s0, vol, n, &topt, &df,
                               &df1, &futc, &df2, &holi, wrt, &ctrl,
                                 &fres) ;

        diff = fabs(fres - fexp) > acc ;

        fprintf(out,"   Error code  %d\n", ok) ;
        fprintf(out,"%d; option impl      %8.5lf expected = %8.5lf\n",
                (fabs(fres - fexp) > acc), fres, fexp);

        fscanf(in,"%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_PLANARRAY(dsc, 1) ;
        Free_PLANARRAY(dsc1, 1) ;
        Free_PLANARRAY(dsc2, 1) ;
        Free_PLANARRAY(pl1, 1) ;
        Free_PLANARRAY(pl2, 1) ;
    }


    else if (!strcmp(txa, "OptEqty_CRR2Impl()"))
    {
        fprintf(out,"?; testing %s\n", txa) ;

        /* Exp result */
        fexp = Read_FL64(in, out, "   Exp implied result   ") ;

        /* Read data */
        today = Read_DATESTR(in, out, "   Analysis   ") ;
        p = Read_FL64(in, out, "   Premium   ") ;
        vol = Read_FL64(in, out, "   Vol   ") ;
        s0 = Read_FL64(in, out, "   Spot   ") ;
        n = Read_INTI(in, out, "   NStep   ") ;
        topt = Read_TREEOPT(in, out) ;
        fute = Read_FUTEQTY(in, out) ;
        cc_df = Read_DISCFAC(in, out) ;
        df = Read_DISCFAC(in, out) ;
        holi = Set_HOLI_STR(NO_BUSADJUST, 0, NULL) ;
        what = Read_KEYCONV(in, out, "   What?   ") ;
        ctrl = Read_ITERCTRL(in, out) ;

        /* Calculate */
        fres = 0.0 ;
        ok = OptEqty_CRR2Impl(&today, p, s0, vol, n, &cc_df, &fute,
                              &topt, &df, &holi, what, &ctrl, &fres) ;

        /* Comments */
        IOUtil_ParseLine(in, out);

        diff = Write_SingleDiff(ok, True, fres, fexp, acc, out) ;

        /* Free.. */
        Free_PAYDAYDEF(&topt.dpay) ;
        Free_FUTEQTY(&fute) ;
        Free_DISCFAC(&df) ;
        Free_DISCFAC(&cc_df) ;
    }


    else if (!strcmp(txa, "OptEqty_Black2Delta()"))
    {
        fscanf(in,"%ld %lf %lf %lf", &ymd, &f, &vol, &divyld) ;

        today = Cldr_YMD2Datestr(ymd) ;

        fprintf(out,"   Testing %s\n", txa) ;
        fprintf(out,"   Analysdate    %8ld\n", ymd) ;
        fprintf(out,"   Spot          %8.5lf\n", f) ;
        fprintf(out,"   Vol           %8.5lf\n", vol) ;
        fprintf(out,"   DivYld        %8.5lf\n", divyld) ;

        fute   = Read_FUTEQTY(in, out) ;
        opt    = Read_OPTFUT(in, out) ;
        df     = Read_DISCFAC(in, out) ;
        holi   = Set_HOLI_STR(NO_BUSADJUST, 0, NULL) ;
        bucket = Read_BUCKETARRAY(in, out, &nbuck) ;

        fscanf(in, " %s", txb) ;
        zero = Str2BOOLE(txb) ;
        fprintf(out,"   DECF          %8s\n", txb) ;

        ds = Disc_DeltaPrep(&df, bucket, nbuck, &holi, False,
                             df.irr, df.freq, False, zero, DF_BOTH) ;
        dv = OptEqty_Black2Delta(&today, &today, f, vol, divyld,
                                   &fute, &opt, &df, &holi, &ds) ;

        diff = 0 ;
        for (i = 0; i < nbuck; i++)
        {
            fscanf(in, "%lf", &fexp) ;
            diff = diff || fabs(fexp - dv[i]) > 0.00001 ;
            fprintf(out, "%d; %d exp %lf res %lf\n",
                    fabs(fexp - dv[i]) > 0.00001, i, fexp, dv[i]) ;
        }

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_PLANARRAY(df.disc, 1) ;
        Free_PLANARRAY(fute.div, 1) ;
        Free_DELTASET(&ds) ;
        Free_BUCKETARRAY(bucket) ;
        Free_FL64ARRAY(dv) ;
        Free_OPTFUT(&opt) ;
    }

    else if (!strcmp(txa, "OptFutEqty_Black2Delta()"))
    {
        fprintf(out,"   Testing %s\n", txa) ;

        fscanf(in,"%ld", &ymd) ;
        today = Cldr_YMD2Datestr(ymd) ;
        fprintf(out,"   Analysdate    %8ld\n", ymd) ;

        fscanf(in,"%ld %lf", &ymd, &vol) ;
        vold = Cldr_YMD2Datestr(ymd) ;
        fprintf(out,"   VOL date      %8ld\n", ymd) ;
        fprintf(out,"   Vol           %8.5lf\n", vol) ;

        fscanf(in,"%ld %lf %lf", &ymd, &f, &divyld) ;
        start = Cldr_YMD2Datestr(ymd) ;
        fprintf(out,"   spotdate      %8ld\n", ymd) ;
        fprintf(out,"   Spot          %8.5lf\n", f) ;

        fprintf(out,"   DivYld        %8.5lf\n", divyld) ;

        fute   = Read_FUTEQTY(in, out) ;
        opt    = Read_OPTFUT(in, out) ;
        df     = Read_DISCFAC(in, out) ;
        holi   = Set_HOLI_STR(NO_BUSADJUST, 0, NULL) ;
        bucket = Read_BUCKETARRAY(in, out, &nbuck) ;

        fscanf(in, " %s", txb) ;
        zero = Str2BOOLE(txb) ;
        fprintf(out,"   DECF          %8s\n", txb) ;

        ds = Disc_DeltaPrep(&df, bucket, nbuck, &holi, False,
                             df.irr, df.freq, False, zero, DF_BOTH) ;
        dv = OptFutEqty_Black2Delta(&today, &vold, &start, f, vol, divyld,
                                   &fute, &opt, &df, &holi, &ds) ;

        diff = 0 ;
        for (i = 0; i < nbuck; i++)
        {
            fscanf(in, "%lf", &fexp) ;
            diff = diff || fabs(fexp - dv[i]) > 0.00001 ;
            fprintf(out, "%d; %d exp %lf res %lf\n",
                    fabs(fexp - dv[i]) > 0.00001, i, fexp, dv[i]) ;
        }

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_PLANARRAY(df.disc, 1) ;
        Free_PLANARRAY(fute.div, 1) ;
        Free_DELTASET(&ds) ;
        Free_BUCKETARRAY(bucket) ;
        Free_FL64ARRAY(dv) ;
        Free_OPTFUT(&opt) ;
    }

    else if (!strcmp(txa, "OptFutEqty_Black2DFp()"))
    {
        fscanf(in,"%lf %lf %lf %ld %ld %ld %lf %lf %lf",
               &fexp, &fexp1, &fexp2, &ymd, &ymd1, &ymd2, &f, &vol,
                 &divyld) ;

        today = Cldr_YMD2Datestr(ymd) ;
        start = Cldr_YMD2Datestr(ymd1) ;
        vold  = Cldr_YMD2Datestr(ymd2) ;

        fprintf(out,"   Testing %s\n", txa) ;
        fprintf(out,"   Analysdate    %8ld\n", ymd) ;
        fprintf(out,"   Spot date     %8ld\n", ymd1) ;
        fprintf(out,"   Spot          %8.5lf\n", f) ;
        fprintf(out,"   Vol date      %8ld\n", ymd2) ;
        fprintf(out,"   Vol           %8.5lf\n", vol) ;
        fprintf(out,"   Divyld        %8.5lf\n", divyld) ;

        fute  = Read_FUTEQTY(in, out) ;
        opt   = Read_OPTFUT(in, out) ;
        orisk = Read_RISKSET(in, out) ;
        df    = Read_DISCFAC(in, out) ;
        holi  = Set_HOLI_STR(NO_BUSADJUST, 0, NULL) ;

        fres = OptFutEqty_Black2DFp(&today, &vold, &start, f, vol, &opt,
                                    &fute, divyld, &df, &holi, &orisk,
                                    &fres1, &fres2) ;

        diff = Write_RiskDiff(True, True, fres, fres1, fres2, fexp, fexp1,
                              fexp2, acc, out) ;
        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_RISKSET(&orisk) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_PLANARRAY(fute.div, 1) ;
        Free_OPTFUT(&opt) ;
    }

    else if (!strcmp(txa, "OptFutEqty_Black2Impl()"))
    {
        fscanf(in,"%lf %lf %s %ld %lf %ld %lf",
               &fexp, &p, &txb, &ymd, &f, &ymd1, &vol) ;

        today = Cldr_YMD2Datestr(ymd) ;
        vold  = Cldr_YMD2Datestr(ymd1) ;
        is_p  = Str2BOOLE(txb) ;

        fprintf(out,"   Testing %s\n", txa) ;
        fprintf(out,"   Analysdate    %8ld\n", ymd) ;
        fprintf(out,"   Option Price  %8.5lf\n", p) ;
        fprintf(out,"   Is-P ?        %8s\n", txb) ;
        fprintf(out,"   Fwd           %8.5lf\n", f) ;
        fprintf(out,"   Vol           %8.5lf\n", vol) ;

        zero = Read_BOOLE(in, out, "Margining  ") ;
        fscanf(in,"%ld ", &ymd) ;

        end = Cldr_YMD2Datestr(ymd) ;

        fprintf(out,"   Delivery      %8ld\n", ymd) ;

        opt  = Read_OPTFUT(in, out) ;
        holi  = Set_HOLI_STR(NO_BUSADJUST, 0, NULL) ;

        fscanf(in, "%s", txb) ;
        fprintf(out,"   Solve for     %8s\n", txb) ;
        what = Str2KEYCONV(txb) ;

        df = Read_DISCFAC(in, out) ;

        ctrl = Read_ITERCTRL(in, out);

        fres = 0.0 ;
        ok = OptFutEqty_Black2Impl(&today, &vold, p, is_p, f, vol, zero, &end,
                                   &opt, &df, &holi, what, &ctrl, &fres) ;

        diff = Write_SingleDiff(ok, True, fres, fexp, 0.001, out) ;
        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_PLANARRAY(df.disc, 1) ;
        Free_OPTFUT(&opt) ;
    }

    else if (!strcmp(txa, "OptFX_Cross2Vol()") ||
             !strcmp(txa, "OptFutFX_Cross2Vol()") )
    {
        fscanf(in,"%lf %lf %lf %lf", &fexp, &vol1, &vol2, &corr) ;

        fprintf(out,"   Testing %s\n", txa) ;
        fprintf(out,"   Vol1          %8.5lf\n", vol1) ;
        fprintf(out,"   Vol2          %8.5lf\n", vol2) ;
        fprintf(out,"   Corr          %8.5lf\n", corr) ;

        if (!strcmp(txa, "OptFX_Cross2Vol()"))
            fres = OptFX_Cross2Vol(vol1, vol2, corr) ;
        else
            fres = OptFutFX_Cross2Vol(vol1, vol2, corr) ;

        diff = Write_SingleDiff(True, True, fres, fexp, acc, out) ;

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;
    }

    else if (!strcmp(txa, "OptEqty_CRR2Delta()"))
    {
        fprintf(out,"   Testing %s\n", txa) ;

        /* Read data */
        today  = Read_DATESTR(in, out, "Analysis  ") ;
        spot   = Read_FL64(in, out, "Spot  ") ;
        vol    = Read_FL64(in, out, "Vol   ") ;
        nstep  = Read_INTI(in, out, "NStep ") ;
        divdf  = Read_DISCFAC(in, out) ;
        fute   = Read_FUTEQTY(in, out) ;
        topt   = Read_TREEOPT(in, out) ;
        df     = Read_DISCFAC(in, out) ;
        bucket = Read_BUCKETARRAY(in, out, &nbuck) ;
        zero   = Read_BOOLE(in, out, "DECF  ") ;

        /* Initialise */
        holi = Set_HOLI_STR(NO_BUSADJUST, 0, NULL) ;
        ds   = Disc_DeltaPrep(&df, bucket, nbuck, &holi, False, df.irr,
                               df.freq, True, zero, DF_BOTH) ;

        /* Calculate */
        dv = OptEqty_CRR2Delta(&today, spot, vol, nstep, &divdf, &fute, &topt,
                               &df, &holi, &ds, &ok) ;

        /* Compare */
        diff = 0 ;
        if (ok == False)
        {
            diff = 1 ;
            fprintf(out, "1; Cannot find Delta Vec\n") ;
        }
        else
        {
            for (i = 0; i < nbuck; i++)
            {
                fscanf(in, "%lf", &fexp) ;
                diff = diff || fabs(fexp - dv[i]) > 0.00001 ;
                fprintf(out, "%d; %d exp %lf res %lf\n",
                        fabs(fexp - dv[i]) > 0.00001, i, fexp, dv[i]) ;
            }
        }

        /* Comments */
        IOUtil_ParseLine(in, out) ;

        /* Free */
        Free_PLANARRAY(divdf.disc, 1) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_DELTASET(&ds) ;
        Free_BUCKETARRAY(bucket) ;
        Free_FL64ARRAY(dv) ;
        Free_DATEARRAY(topt.dpay.irreg_days) ;
        Free_FUTEQTY(&fute) ;
    }

    else if (!strcmp(txa, "FutEqty_CC2Price()"))
    {
        fscanf(in, "%lf %ld %lf %lf", &fexp, &ymd, &spot, &divyld) ;

        dstart = Cldr_YMD2Datestr(ymd) ;

        fprintf(out,"?; testing %s\n", txa) ;
        fprintf(out,"   Analys             %8ld\n", ymd) ;
        fprintf(out,"   Spot               %8lf\n", spot) ;
        fprintf(out,"   DivYld             %8lf\n", divyld) ;

        fute = Read_FUTEQTY(in, out) ;
        df   = Read_DISCFAC(in, out) ;
        holi = Set_HOLI_STR(NO_BUSADJUST, 0, NULL) ;

        fres = FutEqty_CC2Price(&dstart, spot, &fute, divyld, &df, &holi) ;

        diff = fabs(fexp - fres) > acc ;
        fprintf(out,"   Result...\n") ;
        fprintf(out,"%d; Exp. %10.7lf Calc. %10.7lf\n",
                diff, fexp, fres) ;

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_FUTEQTY(&fute) ;
        Free_PLANARRAY(df.disc, 1) ;
    }

    else if (!strcmp(txa, "FutEqty_CC2NPV()"))
    {
        fscanf(in, "%lf %lf %lf %ld %ld %lf %lf",
               &fexp, &fexp1, &fexp2, &ymd, &ymd1, &spot, &divyld) ;

        dstart = Cldr_YMD2Datestr(ymd) ;
        dend   = Cldr_YMD2Datestr(ymd1) ;

        fprintf(out,"?; testing %s\n", txa) ;
        fprintf(out,"   Analys             %8ld\n", ymd) ;
        fprintf(out,"   Spotdate           %8ld\n", ymd1) ;
        fprintf(out,"   Spot               %8lf\n", spot) ;
        fprintf(out,"   DivYld             %8lf\n", divyld) ;

        fute = Read_FUTEQTY(in, out) ;
        df   = Read_DISCFAC(in, out) ;
        rs   = Read_RISKSET(in, out) ;
        holi = Set_HOLI_STR(NO_BUSADJUST, 0, NULL) ;

        fres = FutEqty_CC2NPV(&dstart, &dend, spot, &fute, divyld, &df,
                              &holi, &rs, &fres1, &fres2) ;

        diff = fabs(fres - fexp) > 0.00001 ||
               fabs(fres1 - fexp1) > 0.00001 ||
               fabs(fres2 - fexp2) > 0.00001 ;

        fprintf(out,"   Result...\n") ;
        fprintf(out,"%d; PV: Expected %lf Result %lf\n",
                fabs(fres - fexp) > 0.00001, fexp, fres) ;
        fprintf(out,"%d; DP:   Expected %lf Result %lf\n",
                fabs(fres1 - fexp1) > 0.00001, fexp1, fres1) ;
        fprintf(out,"%d; DDP:  Expected %lf Result %lf\n",
                fabs(fres2 - fexp2) > 0.00001, fexp2, fres2) ;

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_FUTEQTY(&fute) ;
        Free_RISKSET(&rs);
        Free_PLANARRAY(df.disc, 1) ;
    }

    else if (!strcmp(txa, "FutEqty_CC2Delta()"))
    {
        fscanf(in, "%ld %ld %lf %lf", &ymd, &ymd1, &spot, &divyld) ;

        dstart = Cldr_YMD2Datestr(ymd) ;
        dend   = Cldr_YMD2Datestr(ymd1) ;

        fprintf(out,"?; testing %s\n", txa) ;
        fprintf(out,"   Analys             %8ld\n", ymd) ;
        fprintf(out,"   Spotdate           %8ld\n", ymd1) ;
        fprintf(out,"   Spot               %8lf\n", spot) ;
        fprintf(out,"   DivYld             %8lf\n", divyld) ;

        fute = Read_FUTEQTY(in, out) ;
        df   = Read_DISCFAC(in, out) ;
        bucket = Read_BUCKETARRAY(in, out, &nbucket) ;

        fscanf(in, "%s", txb) ;
        zero = Str2BOOLE(txb) ;
        fprintf(out,"   DECF        %8s\n", txb) ;

        holi = Set_HOLI_STR(NO_BUSADJUST, 0, NULL) ;
        ds = Disc_DeltaPrep(&df, bucket, nbucket, &holi, True, df.irr,
                             df.freq, False, zero, DF_BOTH) ;
        dv = FutEqty_CC2Delta(&dstart, &dend, spot, &fute, divyld, &df,
                              &holi, &ds) ;

        diff = 0 ;
        for (i = 0; i < nbucket; i++)
        {
            fscanf(in, "%lf", &fexp) ;
            diff = diff || fabs(fexp - dv[i]) > 0.00001 ;
            fprintf(out, "%d; %d exp %lf res %lf\n",
                    fabs(fexp - dv[i]) > 0.00001, i, fexp, dv[i]) ;
        }

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_FUTEQTY(&fute) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_BUCKETARRAY(bucket) ;
        Free_FL64ARRAY(dv) ;
        Free_DELTASET(&ds) ;
    }

    else if (!strcmp(txa, "FutEqty_CC2Impl()"))
    {
        fscanf(in, "%lf %ld %lf %lf %lf",
                    &fexp, &ymd, &spot, &fwd, &divyld) ;

        dstart = Cldr_YMD2Datestr(ymd) ;

        fprintf(out,"?; testing %s\n", txa) ;
        fprintf(out,"   Analys             %8ld\n", ymd) ;
        fprintf(out,"   Spot               %8lf\n", spot) ;
        fprintf(out,"   Forward            %8lf\n", fwd) ;
        fprintf(out,"   DivYield           %8lf\n", divyld) ;

        fute = Read_FUTEQTY(in, out) ;
        df   = Read_DISCFAC(in, out) ;
        holi = Set_HOLI_STR(NO_BUSADJUST, 0, NULL) ;
        Init_ITERCTRL(&ictrl) ;

        fscanf(in, "%s", txc) ;
        fprintf(out,"   KeyConv           %s\n", txc) ;
        what = Str2KEYCONV(txc) ;

        ok = FutEqty_CC2Impl(&dstart, spot, fwd, &fute, divyld, &df,
                             &holi, what, &ictrl, &fres) ;

        diff = fabs(fexp - fres) > acc && ok == True;
        fprintf(out,"   Result...\n") ;
        fprintf(out,"%d; Exp. %10.7lf Calc. %10.7lf\n",
                diff, fexp, fres) ;

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_FUTEQTY(&fute) ;
        Free_PLANARRAY(df.disc, 1) ;
    }


    else if (!strcmp(txa, "FutEqty_CC2AdjSpot()") )
    {
        fprintf(out,"?; testing %s\n", txa) ;

        /* Read data */
        fexp = Read_FL64(in, out, "   Exp              ") ;
        analys = Read_DATESTR(in, out, "   Analysis         ") ;
        matur = Read_DATESTR(in, out, "   Maturity         ") ;
        spot = Read_FL64(in, out, "   Spot             ") ;
        cal = Read_CALCONV(in, out, "   Calendar         ") ;
        divyld = Read_FL64(in, out, "   Dividend yield   ") ;
        div = Read_PLANARRAY(in) ;
        fprintf(out,"   Term structure of dividends:\n") ;
        Write_PLANARRAY(out, div) ;

        /* Calculate */
        fres = FutEqty_CC2AdjSpot(&analys, &matur, spot, cal, divyld, div, &holi) ;   /* PMSTA-22396 - SRIDHARA � 160502 */

        /* Compare */
        diff = Write_SingleDiff(True, True, fres, fexp, acc, out) ;

        /* Comments */
        IOUtil_ParseLine(in, out) ;

        /* Free */
        Free_PLANARRAY(div, 1) ;
    }


    else if (!strcmp(txa, "FutCmdty_CC2Price()"))
    {
        fscanf(in,
          "%lf %ld %lf %lf %lf",
          &fexp, &ymd, &spot, &divyld, &stcost) ;

        dstart = Cldr_YMD2Datestr(ymd) ;

        fprintf(out,"?; testing %s\n", txa) ;
        fprintf(out,"   Analys             %8ld\n", ymd) ;
        fprintf(out,"   Spot               %8lf\n", spot) ;
        fprintf(out,"   Conv.Yld           %8lf\n", divyld) ;
        fprintf(out,"   Storage Cost       %8lf\n", stcost) ;

        futc = Read_FUTCMDTY(in, out) ;
        df   = Read_DISCFAC(in, out) ;

        fres = FutCmdty_CC2Price(&dstart, spot, &futc, divyld,
                                 stcost, &df, &holi) ;   /* PMSTA-22396 - SRIDHARA � 160502 */

        diff = fabs(fexp - fres) > acc ;
        fprintf(out,"   Result...\n") ;
        fprintf(out,"%d; Exp. %10.7lf Calc. %10.7lf\n",
                diff, fexp, fres) ;

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_FUTCMDTY(&futc) ;
        Free_PLANARRAY(df.disc, 1) ;
    }

    else if (!strcmp(txa, "FutCmdty_CC2NPV()"))
    {
        fscanf(in,
          "%lf %lf %lf %ld %ld %lf %lf %lf %lf",
          &fexp, &fexp1, &fexp2, &ymd, &ymd1, &spot, &fwd, &divyld, &stcost) ;

        dstart = Cldr_YMD2Datestr(ymd) ;
        spotd = Cldr_YMD2Datestr(ymd1) ;

        fprintf(out,"?; testing %s\n", txa) ;
        fprintf(out,"   Analys             %8ld\n", ymd) ;
        fprintf(out,"   Spotdate           %8ld\n", ymd1) ;
        fprintf(out,"   Spot               %8lf\n", spot) ;
        fprintf(out,"   Futures price      %8lf\n", fwd) ;
        fprintf(out,"   Conv.Yld           %8lf\n", divyld) ;
        fprintf(out,"   Storage Cost       %8lf\n", stcost) ;

        futc = Read_FUTCMDTY(in, out) ;
        df   = Read_DISCFAC(in, out) ;
        rs   = Read_RISKSET(in, out) ;


        fres = FutCmdty_CC2NPV(&dstart, &spotd, spot, fwd, &futc, divyld,
                               stcost, &df, &rs, &fres1, &fres2, &holi) ;   /* PMSTA-22396 - SRIDHARA � 160502 */

        diff = (fabs(fres - fexp) > acc)   ||
               (fabs(fres1 - fexp1) > acc) ||
               (fabs(fres2 - fexp2) > acc) ;

        fprintf(out,"%d; result is %8lf ; expected is %8lf\n",
                (fabs(fres - fexp) > acc), fres, fexp) ;
        fprintf(out,"%d; result is %8lf ; expected is %8lf\n",
                (fabs(fres1 - fexp1) > acc), fres1, fexp1) ;
        fprintf(out,"%d; result is %8lf ; expected is %8lf\n",
                (fabs(fres2 - fexp2) > acc), fres2, fexp2) ;

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_RISKSET(&rs) ;
        Free_FUTCMDTY(&futc) ;
        Free_PLANARRAY(df.disc, 1) ;
    }

    else if (!strcmp(txa, "FutCmdty_CC2Delta()"))
    {

        fscanf(in,
          "%ld %ld %lf %lf %lf %lf",
          &ymd, &ymd1, &spot, &fwd, &divyld, &stcost) ;

        dstart = Cldr_YMD2Datestr(ymd) ;
        spotd = Cldr_YMD2Datestr(ymd1) ;

        fprintf(out,"?; testing %s\n", txa) ;
        fprintf(out,"   Analys             %8ld\n", ymd) ;
        fprintf(out,"   Spotdate           %8ld\n", ymd1) ;
        fprintf(out,"   Spot               %8lf\n", spot) ;
        fprintf(out,"   Futures price      %8lf\n", fwd) ;
        fprintf(out,"   Conv.Yld           %8lf\n", divyld) ;
        fprintf(out,"   Storage Cost       %8lf\n", stcost) ;

        futc = Read_FUTCMDTY(in, out) ;
        df   = Read_DISCFAC(in, out) ;
        zero = False ;

        bucket = Read_BUCKETARRAY(in, out, &nbucket) ;
        holi = Set_HOLI_STR(NO_BUSADJUST, 0, NULL) ;
        ds = Disc_DeltaPrep(&df, bucket, nbucket, &holi, True, df.irr,
                             df.freq, False, zero, DF_BOTH) ;

		/* PMSTA-22396 - SRIDHARA � 160502 */
		holi = Read_HOLI_STR(in, out);
		dv = FutCmdty_CC2Delta(&dstart, &spotd, spot, fwd, &futc, divyld,
                               stcost, &df, &ds, &holi) ;   /* PMSTA-22396 - SRIDHARA � 160502 */

        diff = 0 ;
        for (i = 0; i < nbucket; i++)
        {
            fscanf(in, "%lf", &fexp) ;
            diff = diff || fabs(fexp - dv[i]) > 0.00001 ;
            fprintf(out, "%d; %d exp %lf res %lf\n",
                    fabs(fexp - dv[i]) > 0.00001, i, fexp, dv[i]) ;
        }

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;


        Free_FL64ARRAY(dv) ;
        Free_DELTASET(&ds) ;
        Free_BUCKETARRAY(bucket) ;
        Free_FUTCMDTY(&futc) ;
        Free_PLANARRAY(df.disc, 1) ;
		Free_DATEARRAY(holi.holidays);  	/* PMSTA-22396 - SRIDHARA � 160502 */
    }

    else if (!strcmp(txa, "FutCmdty_CC2Implyld()"))
    {
        fscanf(in, "%lf %ld %lf %lf", &fexp, &ymd, &spot, &fwd) ;

        dstart = Cldr_YMD2Datestr(ymd) ;

        fprintf(out,"?; testing %s\n", txa) ;
        fprintf(out,"   Analys             %8ld\n", ymd) ;
        fprintf(out,"   Spot               %8lf\n", spot) ;
        fprintf(out,"   Forward            %8lf\n", fwd) ;

        futc = Read_FUTCMDTY(in, out) ;
        df   = Read_DISCFAC(in, out) ;

        fres = FutCmdty_CC2Implyld(&dstart, spot, fwd, &futc, &df, &holi) ;   /* PMSTA-22396 - SRIDHARA � 160502 */

        diff = fabs(fexp - fres) > acc ;
        fprintf(out,"   Result...\n") ;
        fprintf(out,"%d; Exp. %10.7lf Calc. %10.7lf\n",
                diff, fexp, fres) ;

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_FUTCMDTY(&futc) ;
        Free_PLANARRAY(df.disc, 1) ;
    }

    else if (!strcmp("FutFX_DF2FXrate()", txa))
    {
        fscanf(in, "%lf %ld %lf", &fexp, &ymd, &fx);

        fprintf(out,"   testing %s\n", txa) ;
        fprintf(out,"   Spot       %8ld\n", ymd) ;
        fprintf(out,"   fx_spot    %8lf\n", fx) ;

        analys = Cldr_YMD2Datestr((YYYYMMDD) ymd) ;

        fxfw = Read_FXFORW(in, out) ;

        fscanf(in, "%s", txe) ;
        fprintf(out,"   Spot ?     %8s\n",  txe) ;
        is_p = Str2BOOLE(txe) ;

        holi = Read_HOLI_STR(in, out) ;
        df_d = Read_DISCFAC(in, out) ;
        df_f = Read_DISCFAC(in, out) ;

        fres = FutFX_DF2FXrate(&analys, fx, &fxfw, is_p, &holi, &df_d,
                               &df_f) ;

        diff = (fabs(fres - fexp) > acc);
        fprintf(out, "%d; result is %8lf ; expected is %8lf\n",
                diff, fres, fexp) ;
        fscanf(in,"%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_PLANARRAY(df_d.disc, 1) ;
        Free_PLANARRAY(df_f.disc, 1) ;
        Free_DATEARRAY(holi.holidays) ;
    }

    else if (!strcmp("FutFX_PL2NPV()", txa))
    {
        fscanf(in, "%lf", &fexp);

        fprintf(out,"   testing %s\n", txa) ;
        fxfw = Read_FXFORW(in, out) ;
        plan = Read_PLANARRAY(in) ;
        fprintf(out,"   Outrights (Fwd)\n") ;
        Write_PLANARRAY(out, plan) ;
        holi = Read_HOLI_STR(in, out) ;

        fres = FutFX_PL2NPV(&fxfw, plan, &holi) ;

        diff = (fabs(fres - fexp) > acc);
        fprintf(out, "%d; result is %8lf ; expected is %8lf\n",
                diff, fres, fexp) ;
        fscanf(in,"%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_PLANARRAY(plan, 1) ;
        Free_DATEARRAY(holi.holidays) ;
    }

    else if (!strcmp("FutFX_DF2NPV()", txa))
    {
        fscanf(in, "%lf %lf %lf", &fexp, &fexp1, &fexp2);
        fscanf(in, "%ld %ld %lf", &ymd, &ymd1, &fx);

        fprintf(out,"   testing %s\n", txa) ;
        fprintf(out,"   Analys     %8ld\n", ymd) ;
        fprintf(out,"   Spot       %8ld\n", ymd1) ;
        fprintf(out,"   fx_spot    %8lf\n", fx) ;
        analys = Cldr_YMD2Datestr((YYYYMMDD) ymd) ;
        spotd  = Cldr_YMD2Datestr((YYYYMMDD) ymd1) ;

        fxfw = Read_FXFORW(in, out) ;
        holi = Read_HOLI_STR(in, out) ;
        df_d = Read_DISCFAC(in, out) ;
        df_f = Read_DISCFAC(in, out) ;
        rs   = Read_RISKSET(in, out) ;

        fres = FutFX_DF2NPV(&analys, &spotd, fx, &fxfw, &holi,
                            &df_d, &df_f, &rs, &fres1, &fres2) ;

        diff = (fabs(fres - fexp) > acc)   ||
               (fabs(fres1 - fexp1) > acc) ||
               (fabs(fres2 - fexp2) > acc) ;

        fprintf(out,"%d; result is %8lf ; expected is %8lf\n",
                (fabs(fres - fexp) > acc), fres, fexp) ;
        fprintf(out,"%d; result is %8lf ; expected is %8lf\n",
                (fabs(fres1 - fexp1) > acc), fres1, fexp1) ;
        fprintf(out,"%d; result is %8lf ; expected is %8lf\n",
                (fabs(fres2 - fexp2) > acc), fres2, fexp2) ;

        fscanf(in,"%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_RISKSET(&rs) ;
        Free_PLANARRAY(df_d.disc, 1) ;
        Free_PLANARRAY(df_f.disc, 1) ;
        Free_DATEARRAY(holi.holidays) ;
    }

    else if (!strcmp("FutFX_DF2Delta()", txa))
    {
        fscanf(in, "%ld %ld %lf", &ymd, &ymd1, &fx);

        fprintf(out,"   testing %s\n", txa) ;
        fprintf(out,"   Analys     %8ld\n", ymd) ;
        fprintf(out,"   Spot       %8ld\n", ymd1) ;
        fprintf(out,"   fx_spot    %8lf\n", fx) ;
        analys = Cldr_YMD2Datestr((YYYYMMDD) ymd) ;
        spotd  = Cldr_YMD2Datestr((YYYYMMDD) ymd1) ;

        fxfw = Read_FXFORW(in, out) ;
        holi = Read_HOLI_STR(in, out) ;
        df_d = Read_DISCFAC(in, out) ;
        df_f = Read_DISCFAC(in, out) ;

        fscanf(in, "%s", txe) ;
        fprintf(out,"   Dom ?      %8s\n",  txe) ;
        dom = Str2BOOLE(txe) ;

        bucket = Read_BUCKETARRAY(in, out, &nbuck) ;

        if (dom == True)
            ds = Disc_DeltaPrep(&df_d, bucket, nbuck, &holi, False,
                                 df_d.irr, df_d.freq, dom,
                                 False, DF_BOTH) ;
        else
            ds = Disc_DeltaPrep(&df_f, bucket, nbuck, &holi, False,
                                 df_f.irr, df_f.freq, dom,
                                 False, DF_BOTH) ;

        dv = FutFX_DF2Delta(&analys, &spotd, fx,
                            &fxfw, &holi, &df_d, &df_f, &ds) ;

        diff = 0 ;
        for (i = 0; i < nbuck; i++)
        {
            fscanf(in, "%lf", &fexp) ;
            diff = diff || (fabs(fexp - dv[i]) > 0.00001) ;
            fprintf(out, "%d; %d exp %lf res %lf\n",
                    (fabs(fexp - dv[i]) > 0.00001), i, fexp, dv[i]) ;
        }

        fscanf(in,"%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_PLANARRAY(df_d.disc, 1) ;
        Free_PLANARRAY(df_f.disc, 1) ;
        Free_FL64ARRAY(dv) ;
        Free_DELTASET(&ds) ;
        Free_BUCKETARRAY(bucket) ;
        Free_DATEARRAY(holi.holidays) ;
    }

    else if (!strcmp("OptFX_Black2ScenBPV()", txa) ||
            !strcmp("OptFutFX_Black2ScenBPV()", txa))
    {
        fprintf(out,"   Testing %s\n", txa) ;

        strncpy(ccy, "USD", CCY_LENGTH);
        analys = Read_DATESTR(in, out, "   analys    ");
        voldate = Read_DATESTR(in, out, "   voldate    ");

        fx_spot_opt = Read_FL64(in, out, "Fx Spot Option");
        fx_spot_home = Read_FL64(in, out, "Fx Spot Home  ");
        spotdate = Read_DATESTR(in, out, "   Spotdate   ");

        opt = Read_OPTFUT(in, out) ;

        volrate = Read_FL64(in, out, "   Forw. vol ");

        holi    = Read_HOLI_STR(in, out) ;
        df_d = Read_DISCFAC(in, out) ;
        df_f = Read_DISCFAC(in, out) ;
        scen    = Read_SCENARIOLIST(in, out);

        shocks_opt = Read_FL64ARRAY(in, &nshock_opt);
        Write_FL64ARRAY(out, shocks_opt, nshock_opt);

        shocks_home = Read_FL64ARRAY(in, &nshock_home);
        Write_FL64ARRAY(out, shocks_home, nshock_home);

        irr = Read_IRRCONV(in, out, "  Shock IRR   ");
        freq = Read_PMTFREQ(in, out, "  Shock Freq  ");
        dom = Read_BOOLE(in, out, "   Domestic  ");

        ds_d = Disc_ScenarioPrep(&df_d, &scen, &holi,
            irr, freq, dom) ;

        ds_f = Disc_ScenarioPrep(&df_f, &scen, &holi,
            irr, freq, dom) ;

        fxs_opt = FX_ShockPrep(fx_spot_opt, shocks_opt,
          nshock_opt, &ccy) ;
        fxs_home = FX_ShockPrep(fx_spot_home, shocks_home,
          nshock_home, &ccy) ;

        ok = True;

        if (!strcmp("OptFutFX_Black2ScenBPV()", txa))
        {
              /* Try with NULL if fxs->nshock == 0 */
            if (fxs_opt.nshock == 0 && fxs_home.nshock == 0)
              dv = OptFutFX_Black2ScenBPV(&analys, &voldate,
                  volrate, fx_spot_opt, fx_spot_home, &spotdate,
                  &opt, &df_d, &df_f, &holi, &ds_d, &ds_f,
                  NULL, NULL);
            else if (fxs_opt.nshock == 0)
              dv = OptFutFX_Black2ScenBPV(&analys, &voldate,
                  volrate, fx_spot_opt, fx_spot_home, &spotdate,
                  &opt, &df_d, &df_f, &holi, &ds_d, &ds_f,
                  NULL, &fxs_home);
            else if (fxs_home.nshock == 0)
              dv = OptFutFX_Black2ScenBPV(&analys, &voldate,
                  volrate, fx_spot_opt, fx_spot_home, &spotdate,
                  &opt, &df_d, &df_f, &holi, &ds_d, &ds_f,
                  &fxs_opt, NULL);
            else
              dv = OptFutFX_Black2ScenBPV(&analys, &voldate,
                  volrate, fx_spot_opt, fx_spot_home, &spotdate,
                  &opt, &df_d, &df_f, &holi, &ds_d, &ds_f,
                  &fxs_opt, &fxs_home);
        }
        else
        {
              /* Try with NULL if fxs->nshock == 0 */
            if (fxs_opt.nshock == 0 && fxs_home.nshock == 0)
              dv = OptFX_Black2ScenBPV(&analys, &voldate,
                  volrate, fx_spot_opt, fx_spot_home, &spotdate,
                  &opt, &df_d, &df_f, &holi, &ds_d, &ds_f,
                  NULL, NULL);
            else if (fxs_opt.nshock == 0)
              dv = OptFX_Black2ScenBPV(&analys, &voldate,
                  volrate, fx_spot_opt, fx_spot_home, &spotdate,
                  &opt, &df_d, &df_f, &holi, &ds_d, &ds_f,
                  NULL, &fxs_home);
            else if (fxs_home.nshock == 0)
              dv = OptFX_Black2ScenBPV(&analys, &voldate,
                  volrate, fx_spot_opt, fx_spot_home, &spotdate,
                  &opt, &df_d, &df_f, &holi, &ds_d, &ds_f,
                  &fxs_opt, NULL);
            else
              dv = OptFX_Black2ScenBPV(&analys, &voldate,
                  volrate, fx_spot_opt, fx_spot_home, &spotdate,
                  &opt, &df_d, &df_f, &holi, &ds_d, &ds_f,
                  &fxs_opt, &fxs_home);
        }

        okexp = Read_BOOLE(in, out, "  Exp status ");
        dvexp = Read_FL64ARRAY(in, &nshockexp);
        acc = Read_FL64(in, out, "Tolerance ");

        nshock = ds_f.nshock;
        diff = WriteFL64ARRAYDiff(okexp, dvexp, nshockexp,
            ok, dv, nshock, out, acc);

        IOUtil_ParseLine(in, out);

        Free_DATEARRAY(holi.holidays) ;
        Free_PLANARRAY(df_d.disc, 1) ;
        Free_PLANARRAY(df_f.disc, 1) ;
        Free_DELTASET(&ds_d) ;
        Free_DELTASET(&ds_f) ;
        Free_SCENARIOLIST(&scen) ;
        Free_FL64ARRAY(dv) ;
        Free_FXSHOCKSET(&fxs_opt);
        Free_FXSHOCKSET(&fxs_home);
        Free_FL64ARRAY(shocks_opt);
        Free_FL64ARRAY(shocks_home);
        Free_FL64ARRAY(dvexp);
        Free_OPTFUT(&opt) ;
    }

    else if (!strcmp("OptEqty_Black2ScenBPV()", txa))
    {
        fprintf(out,"   Testing %s\n", txa) ;

        strncpy(ccy, "USD", CCY_LENGTH);
        analys = Read_DATESTR(in, out, "   analys    ");
        voldate = Read_DATESTR(in, out, "   voldate    ");

        spot = Read_FL64(in, out, "Spot      ");
        fx_spot = Read_FL64(in, out, "Fx Spot   ");
        volrate = Read_FL64(in, out, "   Forw. vol ");
        divyld = Read_FL64(in, out, "   Div. Yld  ");

        fute   = Read_FUTEQTY(in, out) ;
        opt = Read_OPTFUT(in, out) ;

        df = Read_DISCFAC(in, out) ;
        holi    = Read_HOLI_STR(in, out) ;
        scen    = Read_SCENARIOLIST(in, out);

        shocks = Read_FL64ARRAY(in, &nshock);
        Write_FL64ARRAY(out, shocks, nshock);

        eqtyshocks = Read_FL64ARRAY(in, &neqtyshock);
        Write_FL64ARRAY(out, eqtyshocks, neqtyshock);

        irr = Read_IRRCONV(in, out, "  Shock IRR   ");
        freq = Read_PMTFREQ(in, out, "  Shock Freq  ");
        dom = Read_BOOLE(in, out, "   Domestic  ");

        ds = Disc_ScenarioPrep(&df, &scen, &holi,
            irr, freq, dom) ;

        fxs   = FX_ShockPrep(fx_spot, shocks, nshock, &ccy) ;
        eqtys = EQTY_Shock_Prep(spot, eqtyshocks, neqtyshock) ;
        ok    = True;

          /* Try with NULL if fxs->nshock == 0 && eqtys->nshock == 0 */
        if (fxs.nshock == 0 && eqtys.nshock == 0)
            dv = OptEqty_Black2ScenBPV(&analys, &voldate, spot,
                volrate, fx_spot, divyld, &fute, &opt, &df, &holi,
                &ds, NULL, NULL);
        else
            dv = OptEqty_Black2ScenBPV(&analys, &voldate, spot,
                volrate, fx_spot, divyld, &fute, &opt, &df, &holi,
                &ds, &fxs, &eqtys);

        okexp = Read_BOOLE(in, out, "  Exp status ");
        dvexp = Read_FL64ARRAY(in, &nshockexp);
        acc = Read_FL64(in, out, "Tolerance ");

        nshock = ds.nshock;
        diff = WriteFL64ARRAYDiff(okexp, dvexp, nshockexp,
            ok, dv, nshock, out, acc);

        IOUtil_ParseLine(in, out);

        Free_FUTEQTY(&fute) ;
        Free_DATEARRAY(holi.holidays) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_DELTASET(&ds) ;
        Free_SCENARIOLIST(&scen) ;
        Free_FL64ARRAY(dv) ;
        Free_FXSHOCKSET(&fxs);
        Free_EQTYSHOCKSET(&eqtys);
        Free_FL64ARRAY(shocks);
        Free_FL64ARRAY(eqtyshocks);
        Free_FL64ARRAY(dvexp);
        Free_OPTFUT(&opt) ;
    }

    else if (!strcmp("OptFutEqty_Black2ScenBPV()", txa))
    {
        fprintf(out,"   Testing %s\n", txa) ;

        strncpy(ccy, "USD", CCY_LENGTH);
        analys = Read_DATESTR(in, out, "   analys    ");
        voldate = Read_DATESTR(in, out, "   voldate    ");
        spotdate = Read_DATESTR(in, out, "   spotdate   ");

        spot = Read_FL64(in, out, "Spot      ");
        fx_spot = Read_FL64(in, out, "Fx Spot   ");
        volrate = Read_FL64(in, out, "   Forw. vol ");
        divyld = Read_FL64(in, out, "   Div. Yld  ");

        fute   = Read_FUTEQTY(in, out) ;
        opt = Read_OPTFUT(in, out) ;

        df = Read_DISCFAC(in, out) ;
        holi    = Read_HOLI_STR(in, out) ;
        scen    = Read_SCENARIOLIST(in, out);

        shocks = Read_FL64ARRAY(in, &nshock);
        Write_FL64ARRAY(out, shocks, nshock);

        eqtyshocks = Read_FL64ARRAY(in, &neqtyshock);
        Write_FL64ARRAY(out, eqtyshocks, neqtyshock);

        irr = Read_IRRCONV(in, out, "  Shock IRR   ");
        freq = Read_PMTFREQ(in, out, "  Shock Freq  ");
        dom = Read_BOOLE(in, out, "   Domestic  ");

        ds = Disc_ScenarioPrep(&df, &scen, &holi,
            irr, freq, dom) ;

        fxs   = FX_ShockPrep(fx_spot, shocks, nshock, &ccy) ;
        eqtys = EQTY_Shock_Prep(spot, eqtyshocks, neqtyshock) ;

        ok = True;

          /* Try with NULL if fxs->nshock == 0 */
        if (fxs.nshock == 0 && eqtys.nshock == 0)
            dv = OptFutEqty_Black2ScenBPV(&analys, &voldate,
                &spotdate, spot, volrate, fx_spot, divyld, &fute,
                &opt, &df, &holi, &ds, NULL, NULL);
        else
            dv = OptFutEqty_Black2ScenBPV(&analys, &voldate,
                &spotdate, spot, volrate, fx_spot, divyld, &fute,
                &opt, &df, &holi, &ds, &fxs, &eqtys);

        okexp = Read_BOOLE(in, out, "  Exp status ");
        dvexp = Read_FL64ARRAY(in, &nshockexp);
        acc = Read_FL64(in, out, "Tolerance ");

        nshock = ds.nshock;
        diff = WriteFL64ARRAYDiff(okexp, dvexp, nshockexp,
            ok, dv, nshock, out, acc);

        IOUtil_ParseLine(in, out);

        Free_FUTEQTY(&fute) ;
        Free_DATEARRAY(holi.holidays) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_DELTASET(&ds) ;
        Free_SCENARIOLIST(&scen) ;
        Free_FL64ARRAY(dv) ;
        Free_FXSHOCKSET(&fxs);
        Free_FL64ARRAY(shocks);
        Free_EQTYSHOCKSET(&eqtys);
        Free_FL64ARRAY(eqtyshocks);
        Free_FL64ARRAY(dvexp);
        Free_OPTFUT(&opt) ;
    }

    else if (!strcmp("OptFX_CRR2ScenBPV()", txa))
    {
        fprintf(out,"   Testing %s\n", txa) ;

        strncpy(ccy, "USD", CCY_LENGTH);
        analys = Read_DATESTR(in, out, "   analys    ");

        fx_spot_opt = Read_FL64(in, out, "Fx Spot Option");
        fx_spot_home = Read_FL64(in, out, "Fx Spot Home  ");

        crropt = Read_TREEOPT(in, out) ;
        nstep  = Read_INTI(in, out, "No. of steps ");

        volrate = Read_FL64(in, out, "   Forw. vol ");

        holi    = Read_HOLI_STR(in, out) ;
        df_d = Read_DISCFAC(in, out) ;
        df_f = Read_DISCFAC(in, out) ;
        scen    = Read_SCENARIOLIST(in, out);

        shocks_opt = Read_FL64ARRAY(in, &nshock_opt);
        Write_FL64ARRAY(out, shocks_opt, nshock_opt);

        shocks_home = Read_FL64ARRAY(in, &nshock_home);
        Write_FL64ARRAY(out, shocks_home, nshock_home);

        irr = Read_IRRCONV(in, out, "  Shock IRR   ");
        freq = Read_PMTFREQ(in, out, "  Shock Freq  ");
        dom = Read_BOOLE(in, out, "   Domestic  ");

        ds_d = Disc_ScenarioPrep(&df_d, &scen, &holi,
            irr, freq, dom) ;

        ds_f = Disc_ScenarioPrep(&df_f, &scen, &holi,
            irr, freq, dom) ;

        fxs_opt = FX_ShockPrep(fx_spot_opt, shocks_opt,
          nshock_opt, &ccy) ;
        fxs_home = FX_ShockPrep(fx_spot_home, shocks_home,
          nshock_home, &ccy) ;

        ok = True;

          /* Try with NULL if fxs->nshock == 0 */
        if (fxs_opt.nshock == 0 && fxs_home.nshock == 0)
          dv = OptFX_CRR2ScenBPV(&analys, volrate, fx_spot_opt,
              fx_spot_home, nstep, &crropt, &df_d, &df_f, &holi,
              &ds_d, &ds_f, NULL, NULL, &ok);
        else if (fxs_opt.nshock == 0)
          dv = OptFX_CRR2ScenBPV(&analys, volrate, fx_spot_opt,
              fx_spot_home, nstep, &crropt, &df_d, &df_f, &holi,
              &ds_d, &ds_f, NULL, &fxs_home, &ok);
        else if (fxs_home.nshock == 0)
          dv = OptFX_CRR2ScenBPV(&analys, volrate, fx_spot_opt,
              fx_spot_home, nstep, &crropt, &df_d, &df_f, &holi,
              &ds_d, &ds_f, &fxs_opt, NULL, &ok);
        else
          dv = OptFX_CRR2ScenBPV(&analys, volrate, fx_spot_opt,
              fx_spot_home, nstep, &crropt, &df_d, &df_f, &holi,
              &ds_d, &ds_f, &fxs_opt, &fxs_home, &ok);

        okexp = Read_BOOLE(in, out, "  Exp status ");
        dvexp = Read_FL64ARRAY(in, &nshockexp);
        acc = Read_FL64(in, out, "Tolerance ");

        nshock = ds_f.nshock;
        diff = WriteFL64ARRAYDiff(okexp, dvexp, nshockexp,
            ok, dv, nshock, out, acc);

        IOUtil_ParseLine(in, out);

        Free_PAYDAYDEF(&crropt.dpay);
        Free_DATEARRAY(holi.holidays) ;
        Free_PLANARRAY(df_d.disc, 1) ;
        Free_PLANARRAY(df_f.disc, 1) ;
        Free_DELTASET(&ds_d) ;
        Free_DELTASET(&ds_f) ;
        Free_SCENARIOLIST(&scen) ;
        Free_FL64ARRAY(dv) ;
        Free_FXSHOCKSET(&fxs_opt);
        Free_FXSHOCKSET(&fxs_home);
        Free_FL64ARRAY(shocks_opt);
        Free_FL64ARRAY(shocks_home);
        Free_FL64ARRAY(dvexp);
    }

    else if (!strcmp("OptEqty_CRR2ScenBPV()", txa))
    {
        fprintf(out,"   Testing %s\n", txa) ;

        strncpy(ccy, "USD", CCY_LENGTH);
        analys = Read_DATESTR(in, out, "   analys    ");

        spot = Read_FL64(in, out, "Spot      ");
        fx_spot = Read_FL64(in, out, "Fx Spot   ");
        volrate = Read_FL64(in, out, "   Forw. vol ");

        fute   = Read_FUTEQTY(in, out) ;
        crropt = Read_TREEOPT(in, out) ;
        nstep  = Read_INTI(in, out, "No. of steps ");
        divdf = Read_DISCFAC(in, out) ;

        df = Read_DISCFAC(in, out) ;
        holi    = Read_HOLI_STR(in, out) ;
        scen    = Read_SCENARIOLIST(in, out);

        shocks = Read_FL64ARRAY(in, &nshock);
        Write_FL64ARRAY(out, shocks, nshock);

        eqtyshocks = Read_FL64ARRAY(in, &neqtyshock);
        Write_FL64ARRAY(out, eqtyshocks, neqtyshock);

        irr = Read_IRRCONV(in, out, "  Shock IRR   ");
        freq = Read_PMTFREQ(in, out, "  Shock Freq  ");
        dom = Read_BOOLE(in, out, "   Domestic  ");

        ds = Disc_ScenarioPrep(&df, &scen, &holi,
            irr, freq, dom) ;

        fxs   = FX_ShockPrep(fx_spot, shocks, nshock, &ccy) ;
        eqtys = EQTY_Shock_Prep(spot, eqtyshocks, neqtyshock) ;

        ok = True;

          /* Try with NULL if fxs->nshock == 0 */
        if (fxs.nshock == 0 && eqtys.nshock ==0)
            dv = OptEqty_CRR2ScenBPV(&analys, spot, volrate,
                fx_spot,&fute, nstep, &crropt, &df, &divdf,
                &holi, &ds, NULL, NULL, &ok);
        else
            dv = OptEqty_CRR2ScenBPV(&analys, spot, volrate,
                fx_spot,&fute, nstep, &crropt, &df, &divdf,
                &holi, &ds, &fxs, &eqtys, &ok);

        okexp = Read_BOOLE(in, out, "  Exp status ");
        dvexp = Read_FL64ARRAY(in, &nshockexp);
        acc = Read_FL64(in, out, "Tolerance ");

        nshock = ds.nshock;
        diff = WriteFL64ARRAYDiff(okexp, dvexp, nshockexp,
            ok, dv, nshock, out, acc);

        IOUtil_ParseLine(in, out);

        Free_PAYDAYDEF(&crropt.dpay);
        Free_FUTEQTY(&fute) ;
        Free_DATEARRAY(holi.holidays) ;
        Free_PLANARRAY(divdf.disc, 1) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_DELTASET(&ds) ;
        Free_SCENARIOLIST(&scen) ;
        Free_FL64ARRAY(dv) ;
        Free_FXSHOCKSET(&fxs);
        Free_EQTYSHOCKSET(&eqtys);
        Free_FL64ARRAY(shocks);
        Free_FL64ARRAY(eqtyshocks);
        Free_FL64ARRAY(dvexp);
    }


    else if (!strcmp("FutEqty_CC2ScenBPV()", txa))
    {
        fprintf(out,"   Testing %s\n", txa) ;

        /* Read data */
        analys  = Read_DATESTR(in, out, "   analys    ") ;
        spot    = Read_FL64(in, out, "   Spot      ") ;
        fx_spot = Read_FL64(in, out, "   Fx Spot   ") ;
        divyld  = Read_FL64(in, out, "   Divyld    ") ;
        fute    = Read_FUTEQTY(in, out) ;
        df      = Read_DISCFAC(in, out) ;
        holi    = Read_HOLI_STR(in, out) ;

        /* Curve shocks */
        scen    = Read_SCENARIOLIST(in, out) ;

        /* FX shocks */
        shocks = Read_FL64ARRAY(in, &nshock) ;
        Write_FL64ARRAY(out, shocks, nshock) ;

        /* Equity shocks */
        eqtyshocks = Read_FL64ARRAY(in, &neqtyshock) ;
        Write_FL64ARRAY(out, eqtyshocks, neqtyshock) ;

        irr  = Read_IRRCONV(in, out, "  Shock IRR    ") ;
        freq = Read_PMTFREQ(in, out, "  Shock Freq   ") ;
        dom  = Read_BOOLE(in, out, "  Domestic     ") ;

        /* Initialise */
        ds    = Disc_ScenarioPrep(&df, &scen, &holi, irr, freq, dom) ;
        strncpy(ccy, "USD", CCY_LENGTH);
        fxs   = FX_ShockPrep(fx_spot, shocks, nshock, &ccy) ;
        eqtys = EQTY_Shock_Prep(spot, eqtyshocks, neqtyshock) ;

        ok = True ;

        /* Try with NULL if fxs->nshock == 0 and eqtys->nshock == 0 */
        if (fxs.nshock == 0 && eqtys.nshock ==0)
            dv = FutEqty_CC2ScenBPV(&analys, &analys, spot, fx_spot, divyld,
                                    &fute, &df, &holi, &ds, NULL, NULL) ;
        else
            dv = FutEqty_CC2ScenBPV(&analys, &analys, spot, fx_spot, divyld,
                                    &fute, &df, &holi, &ds, &fxs, &eqtys) ;


        okexp = Read_BOOLE(in, out, "  Exp status ") ;
        dvexp = Read_FL64ARRAY(in, &nshockexp) ;
        acc = Read_FL64(in, out, "Tolerance ") ;

        nshock = ds.nshock;
        diff = WriteFL64ARRAYDiff(okexp, dvexp, nshockexp, ok, dv, nshock, out,
                                  acc) ;

        IOUtil_ParseLine(in, out) ;

        Free_FUTEQTY(&fute) ;
        Free_DATEARRAY(holi.holidays) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_DELTASET(&ds) ;
        Free_SCENARIOLIST(&scen) ;
        Free_FL64ARRAY(dv) ;
        Free_FXSHOCKSET(&fxs) ;
        Free_EQTYSHOCKSET(&eqtys) ;
        Free_FL64ARRAY(shocks) ;
        Free_FL64ARRAY(eqtyshocks) ;
        Free_FL64ARRAY(dvexp) ;
    }

    else if (!strcmp("FutEqty_CC2RiskPos()", txa))
    {
        fscanf(in,"%lf %ld", &tol, &ymd) ;

        analys = Cldr_YMD2Datestr(ymd) ;

        fprintf(out,"?; testing %s\n", txa) ;
        fprintf(out,"   Analysis    %8ld\n", ymd) ;

        fute = Read_FUTEQTY(in, out) ;

        fscanf(in,"%ld %lf %lf %lf %lf", &ymd, &spot, &notnal,
                    &beta, &divyld) ;
        spotdate = Cldr_YMD2Datestr(ymd) ;
        fprintf(out,"   Spot date            %8ld\n", ymd) ;
        fprintf(out,"   Spot price per unit  %8lf\n", spot) ;
        fprintf(out,"   Number of units      %8lf\n", notnal) ;
        fprintf(out,"   Beta                 %8lf\n", beta) ;
        fprintf(out,"   Dividend yield       %8lf\n", divyld) ;

        Read_RISKTOKEN(in, out, &token) ;

        df     = Read_DISCFAC(in, out) ;
        holi   = Read_HOLI_STR(in, out) ;
        bucket = Read_BUCKETARRAY(in, out, &nbucket) ;

        fscanf(in, "%s", txb) ;
        zero = Str2BOOLE(txb) ;
        fprintf(out,"   DECF        %8s\n", txb) ;

        fxr = Read_FXRISKSET(in, out) ;

        ds = Disc_DeltaPrep(&df, bucket, nbucket, &holi, True, df.irr,
                             df.freq, False, zero, DF_BOTH) ;

        rpos = FutEqty_CC2RiskPos(&analys, &fute, &spotdate, spot,
                                   notnal, beta, divyld, &token,
                                   &df, &holi, &ds, &fxr) ;

        exprpos.token = Alloc_RISKTOKENARRAY(rpos.npos) ;
        exprpos.pos   = Alloc_FL64ARRAY(rpos.npos) ;
        exprpos.npos  = rpos.npos ;

        for (i = 0; i < exprpos.npos; i++)
        {
            Read_RISKTOKEN(in, out, &exprpos.token[i]) ;
            fscanf(in, "%lf", &exprpos.pos[i]) ;
        }

        diff = Write_riskposdiff(exprpos, rpos, out, tol) ;

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_PLANARRAY(fute.div, 1) ;

        Free_FUTEQTY(&fute) ;
        Free_DATEARRAY(holi.holidays) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_DELTASET(&ds) ;
        Free_BUCKETARRAY(bucket) ;
        Free_RISKPOSLIST(&rpos);
        Free_RISKPOSLIST(&exprpos);
    }

    else if (!strcmp(txa, "Eqty_VAR2RiskPos()"))
    {
        fscanf(in, "%lf %lf %lf %lf", &tol, &spot, &notnal, &beta) ;

        fprintf(out,"?; testing %s\n", txa) ;
        fprintf(out,"   Spot price per unit %8lf\n", spot) ;
        fprintf(out,"   Number of units     %8lf\n", notnal) ;
        fprintf(out,"   Beta                %8lf\n", beta) ;

        Read_RISKTOKEN(in, out, &token) ;
        fxr   = Read_FXRISKSET(in, out) ;

        rpos = Eqty_VAR2RiskPos(spot, notnal, beta, &token, &fxr) ;

        exprpos.token = Alloc_RISKTOKENARRAY(rpos.npos) ;
        exprpos.pos   = Alloc_FL64ARRAY(rpos.npos) ;
        exprpos.npos  = rpos.npos ;

        for (i = 0; i < exprpos.npos; i++)
        {
            Read_RISKTOKEN(in, out, &exprpos.token[i]) ;
            fscanf(in, "%lf", &exprpos.pos[i]) ;
        }

        diff = Write_riskposdiff(exprpos, rpos, out, tol) ;

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_RISKPOSLIST(&rpos);
        Free_RISKPOSLIST(&exprpos);
    }

    else if (!strcmp(txa, "OptFutEqty_Black2RiskPos()") ||
             !strcmp(txa, "OptEqty_Black2RiskPos()") )
    {
        fscanf(in,"%lf %ld", &tol, &ymd) ;

        today = Cldr_YMD2Datestr(ymd) ;

        fprintf(out,"   Testing %s\n", txa) ;
        fprintf(out,"   Analysdate    %8ld\n", ymd) ;

        opt  = Read_OPTFUT(in, out) ;
        fute = Read_FUTEQTY(in, out) ;

        FL64 notional;

        fscanf(in,"%lf %lf %lf %lf %lf", &price, &notional, &beta,
                    &vol, &divyld) ;
        if (!strcmp(txa, "OptFutEqty_Black2RiskPos()"))
            fprintf(out,"   Future price  %8.5lf\n", price) ;
        else
            fprintf(out,"   Spot price    %8.5lf\n", price) ;
        fprintf(out,"   Notional      %8.5lf\n", notional) ;
        fprintf(out,"   Beta          %8.5lf\n", beta) ;
        fprintf(out,"   Vol           %8.5lf\n", vol) ;

        Read_RISKTOKEN(in, out, &token) ;
        df     = Read_DISCFAC(in, out) ;
        holi   = Set_HOLI_STR(NO_BUSADJUST, 0, NULL) ;
        bucket = Read_BUCKETARRAY(in, out, &nbuck) ;

        fscanf(in, "%s", txb) ;
        zeroeqv = Str2BOOLE(txb) ;
        fprintf(out,"   DECF        %8s\n", txb) ;

        fxr = Read_FXRISKSET(in, out) ;

        ds = Disc_DeltaPrep(&df, bucket, nbuck, &holi, False, df.irr,
                             df.freq, False, zeroeqv, DF_BOTH) ;

        if (!strcmp(txa, "OptFutEqty_Black2RiskPos()"))
            rpos = OptFutEqty_Black2RiskPos(&today, &opt, &fute, price,
                                            notional, beta, &today, vol,
                                            divyld, &token, &df,
                                            &holi, &ds, &fxr) ;
        else
            rpos = OptEqty_Black2RiskPos(&today, &opt, &fute, price,
                                         notional, beta, &today, vol,
                                         divyld, &token, &df,
                                         &holi, &ds, &fxr) ;

        exprpos.token = Alloc_RISKTOKENARRAY(rpos.npos) ;
        exprpos.pos   = Alloc_FL64ARRAY(rpos.npos) ;
        exprpos.npos  = rpos.npos ;

        for (i = 0; i < exprpos.npos; i++)
        {
            Read_RISKTOKEN(in, out, &exprpos.token[i]) ;
            fscanf(in, "%lf", &exprpos.pos[i]) ;
        }

        diff = Write_riskposdiff(exprpos, rpos, out, tol) ;

        fscanf(in, "%s", txpl) ;
        fprintf(out,"   %s\n\n", txpl) ;

        Free_PLANARRAY(df.disc, 1) ;
        Free_DELTASET(&ds) ;
        Free_BUCKETARRAY(bucket) ;
        Free_PLANARRAY(fute.div, 1) ;

        Free_RISKPOSLIST(&rpos);
        Free_RISKPOSLIST(&exprpos);
        Free_OPTFUT(&opt) ;
    }

    else if (!strcmp("OptEqty_CRR2RiskPos()", txa))
    {
        fprintf(out,"   Testing %s\n", txa) ;

        /* Read data */
        tol    = Read_FL64(in, out, "Tolerance   ") ;
        analys = Read_DATESTR(in, out, "Analys date  ") ;
        spot   = Read_FL64(in, out, "Spot  ") ;
        vol    = Read_FL64(in, out, "Vol   ") ;
        nstep  = Read_INTI(in, out, "NStep ") ;
        divdf  = Read_DISCFAC(in, out) ;
        fute   = Read_FUTEQTY(in, out) ;
        topt   = Read_TREEOPT(in, out) ;
        notnal = Read_FL64(in, out, "Notional  ") ;
        beta   = Read_FL64(in, out, "Beta      ") ;
        Read_RISKTOKEN(in, out, &token) ;
        df     = Read_DISCFAC(in, out) ;
        bucket = Read_BUCKETARRAY(in, out, &nbuck) ;
        zero   = Read_BOOLE(in, out, "DECF  ") ;
        fxr    = Read_FXRISKSET(in, out) ;

        /* Initialise */
        holi = Set_HOLI_STR(NO_BUSADJUST, 0, NULL) ;
        ds   = Disc_DeltaPrep(&df, bucket, nbuck, &holi, False, df.irr,
                               df.freq, True, zero, DF_BOTH) ;

        /* Calculate */
        rpos = OptEqty_CRR2RiskPos(&analys, spot, vol, nstep, &divdf, &fute,
                                   &topt, notnal, beta, &token, &df, &holi,
                                   &ds, &fxr, &ok) ;

        /* Read expected results */
        fscanf(in, "%d", &i1) ;
        exprpos.npos = (INTI) i1 ;
        exprpos.token = Alloc_RISKTOKENARRAY(exprpos.npos) ;
        exprpos.pos   = Alloc_FL64ARRAY(exprpos.npos) ;

        for (i = 0; i < exprpos.npos; i++)
        {
            Read_RISKTOKEN(in, out, &exprpos.token[i]) ;
            fscanf(in, "%lf", &exprpos.pos[i]) ;
        }

        /* Compare */
        diff = Write_riskposdiff(exprpos, rpos, out, tol) ;

        /* Comments */
        IOUtil_ParseLine(in, out) ;

        /* Free */
        Free_PLANARRAY(divdf.disc, 1) ;
        Free_PLANARRAY(df.disc, 1) ;
        Free_DELTASET(&ds) ;
        Free_BUCKETARRAY(bucket) ;
        Free_DATEARRAY(topt.dpay.irreg_days) ;
        Free_FUTEQTY(&fute) ;
        Free_RISKPOSLIST(&rpos);
        Free_RISKPOSLIST(&exprpos);
    }

    else if (!strcmp("OptFX_CRR2RiskPos()", txa))
    {
        fprintf(out,"   Testing %s\n", txa) ;

        tol      = Read_FL64(in, out, "Tolerance   ") ;
        analys   = Read_DATESTR(in, out, "Analys date  ") ;
        spot     = Read_FL64(in, out, "Spot  ") ;
        vol      = Read_FL64(in, out, "Vol   ") ;
        nstep    = Read_INTI(in, out, "NStep ") ;
        topt     = Read_TREEOPT(in, out) ;
        notnal   = Read_FL64(in, out, "Notional  ") ;
        df_p     = Read_DISCFAC(in, out) ;
        df_r     = Read_DISCFAC(in, out) ;
        bucket_p = Read_BUCKETARRAY(in, out, &nbuckp) ;
        bucket_r = Read_BUCKETARRAY(in, out, &nbuckr) ;
        zero     = Read_BOOLE(in, out, "DECF  ") ;
        fx_p     = Read_FXRISKSET(in, out) ;
        fx_r     = Read_FXRISKSET(in, out) ;

        holi = Set_HOLI_STR(NO_BUSADJUST, 0, NULL) ;
        ds_p = Disc_DeltaPrep(&df_p, bucket_p, nbuckp, &holi, True, df_p.irr,
                               df_p.freq, True, zero, DF_BOTH) ;
        ds_r = Disc_DeltaPrep(&df_r, bucket_r, nbuckr, &holi, True, df_r.irr,
                               df_r.freq, False, zero, DF_BOTH) ;

        rpos = OptFX_CRR2RiskPos(&analys, spot, vol, nstep, &topt, notnal,
                                 &df_p, &df_r, &holi, &ds_p, &ds_r, &fx_p,
                                 &fx_r, &ok) ;

        fscanf(in, "%d", &i1) ;
        exprpos.npos = (INTI) i1 ;
        exprpos.token = Alloc_RISKTOKENARRAY(exprpos.npos) ;
        exprpos.pos   = Alloc_FL64ARRAY(exprpos.npos) ;

        for (i = 0; i < exprpos.npos; i++)
        {
            Read_RISKTOKEN(in, out, &exprpos.token[i]) ;
            fscanf(in, "%lf", &exprpos.pos[i]) ;
        }

        diff = Write_riskposdiff(exprpos, rpos, out, tol) ;

        IOUtil_ParseLine(in, out) ;

        Free_PLANARRAY(df_p.disc, 1) ;
        Free_PLANARRAY(df_r.disc, 1) ;
        Free_DELTASET(&ds_p) ;
        Free_DELTASET(&ds_r) ;
        Free_BUCKETARRAY(bucket_p) ;
        Free_BUCKETARRAY(bucket_r) ;
        Free_DATEARRAY(topt.dpay.irreg_days) ;
        Free_RISKPOSLIST(&rpos);
        Free_RISKPOSLIST(&exprpos);
    }

    else if (!strcmp(txa, "OptFX_Black2RiskPos()") ||
             !strcmp(txa, "OptFutFX_Black2RiskPos()") )
    {
        fprintf(out,"   Testing %s\n", txa) ;

        /* Read data */
        tol      = Read_FL64(in, out, "Tolerance   ") ;
        analys   = Read_DATESTR(in, out, "Analys date  ") ;
        vol      = Read_FL64(in, out, "Vol   ") ;
        spot     = Read_FL64(in, out, "Spot  ") ;
        spotdate = Read_DATESTR(in, out, "Spot date  ") ;
        opt      = Read_OPTFUT(in, out) ;
        notnal   = Read_FL64(in, out, "Notional  ") ;
        df_p     = Read_DISCFAC(in, out) ;
        df_r     = Read_DISCFAC(in, out) ;
        bucket_p = Read_BUCKETARRAY(in, out, &nbuckp) ;
        bucket_r = Read_BUCKETARRAY(in, out, &nbuckr) ;
        zero     = Read_BOOLE(in, out, "DECF  ") ;
        fx_p     = Read_FXRISKSET(in, out) ;
        fx_r     = Read_FXRISKSET(in, out) ;
        test     = Read_BOOLE(in, out, "Serious test example ") ;

        /* Initialise */
        holi = Set_HOLI_STR(NO_BUSADJUST, 0, NULL) ;
        ds_p = Disc_DeltaPrep(&df_p, bucket_p, nbuckp, &holi, True, df_p.irr,
                               df_p.freq, True, zero, DF_BOTH) ;
        ds_r = Disc_DeltaPrep(&df_r, bucket_r, nbuckr, &holi, True, df_r.irr,
                               df_r.freq, False, zero, DF_BOTH) ;

        /* Calculate */
        if (!strcmp(txa, "OptFX_Black2RiskPos()"))
            rpos = OptFX_Black2RiskPos(&analys, &analys, vol, spot, &spotdate,
                                       &opt, notnal, &df_p, &df_r, &holi, &ds_p,
                                       &ds_r, &fx_p, &fx_r) ;
        else
            rpos = OptFutFX_Black2RiskPos(&analys, &analys, vol, spot,
                                          &spotdate, &opt, notnal, &df_p, &df_r,
                                          &holi, &ds_p, &ds_r, &fx_p, &fx_r) ;

        /* Read exp res */
        fscanf(in, "%d", &i1) ;
        exprpos.npos = (INTI) i1 ;
        exprpos.token = Alloc_RISKTOKENARRAY(exprpos.npos) ;
        exprpos.pos   = Alloc_FL64ARRAY(exprpos.npos) ;

        for (i = 0; i < exprpos.npos; i++)
        {
            Read_RISKTOKEN(in, out, &exprpos.token[i]) ;
            fscanf(in, "%lf", &exprpos.pos[i]) ;
        }

        /* Compare */
        if (test == True)
            diff = Write_riskposdiff(exprpos, rpos, out, tol) ;
        else
        {
            diff = 0 ;
            fprintf(out, "%d; Expected Result \n\n", diff) ;
        }


        /* Comments */
        IOUtil_ParseLine(in, out) ;

        /* Free */
        Free_PLANARRAY(df_p.disc, 1) ;
        Free_PLANARRAY(df_r.disc, 1) ;
        Free_DELTASET(&ds_p) ;
        Free_DELTASET(&ds_r) ;
        Free_BUCKETARRAY(bucket_p) ;
        Free_BUCKETARRAY(bucket_r) ;
        Free_RISKPOSLIST(&rpos);
        Free_RISKPOSLIST(&exprpos);
        Free_OPTFUT(&opt) ;
    }

    else if (!strcmp(txa, "FutFX_DF2RiskPos()"))
    {
        fprintf(out,"   Testing %s\n", txa) ;

        /* Read data */
        tol      = Read_FL64(in, out, "Tolerance   ") ;
        analys   = Read_DATESTR(in, out, "Analys date  ") ;
        fxfw     = Read_FXFORW(in, out) ;
        notnal   = Read_FL64(in, out, "Notional  ") ;
        df_p     = Read_DISCFAC(in, out) ;
        df_r     = Read_DISCFAC(in, out) ;
        bucket_p = Read_BUCKETARRAY(in, out, &nbuckp) ;
        bucket_r = Read_BUCKETARRAY(in, out, &nbuckr) ;
        zero     = Read_BOOLE(in, out, "DECF  ") ;
        fx_p     = Read_FXRISKSET(in, out) ;
        fx_r     = Read_FXRISKSET(in, out) ;

        /* Initialise */
        holi = Set_HOLI_STR(NO_BUSADJUST, 0, NULL) ;
        ds_p = Disc_DeltaPrep(&df_p, bucket_p, nbuckp, &holi, True, df_p.irr,
                               df_p.freq, True, zero, DF_BOTH) ;
        ds_r = Disc_DeltaPrep(&df_r, bucket_r, nbuckr, &holi, True, df_r.irr,
                               df_r.freq, True, zero, DF_BOTH) ;

        /* Calculate */
        rpos = FutFX_DF2RiskPos(&analys, &fxfw, notnal, &df_p, &df_r,
                                &holi, &ds_p, &ds_r, &fx_p, &fx_r) ;

        /* Read expected results */
        fscanf(in, "%d", &i1) ;
        exprpos.npos = (INTI) i1 ;
        exprpos.token = Alloc_RISKTOKENARRAY(exprpos.npos) ;
        exprpos.pos   = Alloc_FL64ARRAY(exprpos.npos) ;

        for (i = 0; i < exprpos.npos; i++)
        {
            Read_RISKTOKEN(in, out, &exprpos.token[i]) ;
            fscanf(in, "%lf", &exprpos.pos[i]) ;
        }

        diff = Write_riskposdiff(exprpos, rpos, out, tol) ;

        /* Comments */
        IOUtil_ParseLine(in, out) ;

        /* Free */
        Free_PLANARRAY(df_p.disc, 1) ;
        Free_PLANARRAY(df_r.disc, 1) ;
        Free_DELTASET(&ds_p) ;
        Free_DELTASET(&ds_r) ;
        Free_BUCKETARRAY(bucket_p) ;
        Free_BUCKETARRAY(bucket_r) ;
        Free_RISKPOSLIST(&rpos);
        Free_RISKPOSLIST(&exprpos);
    }

    else if (!strcmp("Validate_FXFORW()", txa))
    {
        fscanf(in, "%s %s", txe, txpl) ;

        exp_val = Str2VALIDATE(txe) ;

        fprintf(out, "   \n Testing %s\n", txa) ;
        fprintf(out, "   %s\n", txpl) ;

        fxfw = Read_FXFORW(in, out) ;

        val = Validate_FXFORW(&fxfw) ;
        VALIDATE2Str(val, txc) ;

        diff = (val == exp_val ? 0 : 1) ;
        fprintf(out,"%d;  Exp %s Res %s\n", diff, txe, txc) ;

    }

    else if (!strcmp("Validate_FUTEQTY()", txa))
    {
        fscanf(in, "%s %s", txe, txpl) ;

        exp_val = Str2VALIDATE(txe) ;

        fprintf(out, "   \n Testing %s\n", txa) ;
        fprintf(out, "   %s\n", txpl) ;

        futeqty = Read_FUTEQTY(in, out) ;

        val = Validate_FUTEQTY(&futeqty) ;
        VALIDATE2Str(val, txc) ;

        diff = (val == exp_val ? 0 : 1) ;
        fprintf(out,"%d;  Exp %s Res %s\n", diff, txe, txc) ;

        Free_PLANARRAY(futeqty.div, 1) ;
    }

    return diff ;
}


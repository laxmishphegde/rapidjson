/* SCID @(#)fxforw.c	1.5 (SimCorp) 99/02/19 14:14:33 */

/************************************************************************
*
*   project     SCecon
*
*   file name   fxforw.c
*
*   general     This file contains routines for FX Forward calculations
*
************************************************************************/

/* includes ************************************************************/
#include <futeqty.h>

/***** defines  ********************************************************/
#define DISC_TOLR 0.00000001


/*,,SOH,,
*************************************************************************
*
*               FutFX_DF2FXrate()
*
*    interface  #include <futeqty.h>
*               FL64 FutFX_DF2FXrate(DATESTR    *spot,
*                                    FL64       fx,
*                                    FXFORW     *fxfw,
*                                    BOOLE      fxspot,
*                                    HOLI_STR   *holi,
*                                    DISCFAC    *df_d,
*                                    DISCFAC    *df_f) ;
*
*    general    This routine calculates the implied forward or spot FX
*               rate using the interest rate parity, and zero coupon
*               discount factors in both currencies.
*
*               The result is in the same base as the input FX Rate.
*
*               In the following domestic / foreign refer to:
*
*                   Domestic - CCY paid
*                   Foreign  - CCY received
*
*    input      DATESTR    *spot     The date for fx_spot
*
*               FL64       fx        Spot or forward FX rate.
*                                    Quoted as fxfw->base / ->inv
*
*               FXFORW     *fxfw     FX Forward data
*
*               BOOLE      fxspot    True if fx is spot and False
*                                    if fx is forward.
*
*               HOLI_STR   *holi     Holiday adjustment setup
*
*               DISCFAC    *df_d     Domestic discount factor setup
*
*               DISCFAC    *df_f     Foreign discount factor setup
*    output
*
*    returns    If fxspot is True the FX Forward Exchange rate, and if
*               fxspot is False the FX Spot Exchange Rate.
*
*    diagnostics
*
*    see also   FutFX_DF2NPV()
*
*    wrapper    AP
*
*************************************************************************
,,EOH,,*/


FL64 FutFX_DF2FXrate(DATESTR* spot,
                     FL64    fx,
                     FXFORW*  fxfw,
                     BOOLE   fxspot,
                     HOLI_STR* holi,
                     DISCFAC* df_d,
                     DISCFAC* df_f)
{
    FL64    fxx, d_d, d_f ;
    BOOLE   ok ;
    DATESTR madj ;

    d_d = d_f = 0.0 ;

    /* Use the Interest Rate Parity */
    madj = Cldr_NextBusinessDate(&fxfw->matur, holi) ;
	/* PMSTA-22396 - SRIDHARA � 160502 */
    ok = Disc_ForwDisc(df_d, spot, &madj, &d_d, holi) ;
    ok = ok && Disc_ForwDisc(df_f, spot, &madj, &d_f, holi) ;

    if (fxspot == True)
    {
        if (fxfw->inv == False && fabs(d_d) > DISC_TOLR)
            fxx = d_f * fx / d_d ;
        else if (fxfw->inv == True && fabs(d_f) > DISC_TOLR)
            fxx = d_d * fx / d_f ;
        else
            fxx = 0.0 ;
    }
    else
    {
        if (fxfw->inv == False && fabs(d_f) > DISC_TOLR)
            fxx = d_d * fx / d_f ;
        else if (fxfw->inv == True && fabs(d_d) > DISC_TOLR)
            fxx = d_f * fx / d_d ;
        else
            fxx = 0.0 ;
    }

    return fxx ;
}


/*,,SOH,,
*************************************************************************
*
*               FutFX_DF2NPV()
*
*    interface  #include <futeqty.h>
*               FL64 FutFX_DF2NPV(DATESTR    *analys,
*                                 DATESTR    *spot,
*                                 FL64       fx_spot,
*                                 FXFORW     *fxfw,
*                                 HOLI_STR   *holi,
*                                 DISCFAC    *df_d,
*                                 DISCFAC    *df_f,
*                                 RISKSET    *risk,
*                                 FL64       *dp,
*                                 FL64       *ddp) ;
*
*    general    This routine calculates the NPV of a FX forward.
*               Depending on the setting of risk dollar durations and
*               convexities are also calculated, with respect to either
*               the domestic or foreign Zero Curve.
*
*               Risk ratios are calculated as follows:
*
*                   risk->key      dp          ddp
*                   ---------      ---         ----
*                   KEY_DF         $Duration   $Convexity
*                   KEY_BPV        BPV
*
*               In the following domestic / foreign refer to:
*
*                   Domestic - CCY paid
*                   Foreign  - CCY received
*
*    input      DATESTR    *analys   Pointer to analysis date.
*
*               DATESTR    *spot     The date for fx_spot
*
*               FL64       fx_spot   Spot exchange rate.
*                                    Quoted as fxfw->base / ->inv
*
*               FXFORW     *fxfw     FX Forward data
*
*               HOLI_STR   *holi     Holiday adjustment setup
*
*               DISCFAC    *df_d     Domestic discount factor setup
*
*               DISCFAC    *df_f     Foreign discount factor setup
*
*               RISKSET    *risk     Data for risk calculations
*                                    Use NULL for no risk ratios
*
*    output     FL64       *dp       Dollar duration
*
*               FL64       *ddp      Dollar convexity
*
*    returns    The PV in domestic CCY per foreign CCY unit
*               Find full PV by multiplying by foreign CCY amount
*
*    diagnostics
*
*    see also   FutFX_DF2FXrate()
*
*    wrapper    AP
*
*************************************************************************
,,EOH,,*/

FL64 FutFX_DF2NPV(DATESTR* analys,
                  DATESTR*    spot,
                  FL64       fx_spot,
                  FXFORW*     fxfw,
                  HOLI_STR*   holi,
                  DISCFAC*    df_d,
                  DISCFAC*    df_f,
                  RISKSET*    risk,
                  FL64*       dp,
                  FL64*       ddp)
{
    FL64    dum, shock, pv, d_d, d_f, pvu, pvd, fx_forw, disc ;
    BOOLE   ok ;
    DISCFAC sdf ;
    DATESTR madj ;

    /* warning avoidance */
    fx_forw = 0.0 ;

    *dp = *ddp = 0.0 ;

    /* Use the Interest Rate Parity */
    madj = Cldr_NextBusinessDate(&fxfw->matur, holi) ;

    d_d = d_f = 0.0 ;
	/* PMSTA-22396 - SRIDHARA � 160502 */
    ok = Disc_ForwDisc(df_d, spot, &madj, &d_d, holi) ;
    ok = ok && Disc_ForwDisc(df_f, spot, &madj, &d_f, holi) ;
    if (ok == False)
    {
        /* Fatal error in discount function. */
        return 0.0 ;
    }

    /* Adjust for base */
    if (fabs(fxfw->base) > 0.0000001)
    {
        fx_spot /= fxfw->base ;
        fx_forw  = fxfw->fwd / fxfw->base ;
    }

    /* PV on spot date */
    if (fxfw->inv == False)
    {
        if (fxfw->margin == False)
            pv = fx_spot * d_f - fx_forw * d_d ;
        else
            pv = d_f * fx_spot / d_d - fx_forw ;
    }
    else
    {
        if (fxfw->margin == False)
            pv = 1.0 / fx_spot * d_f - 1.0 / fx_forw * d_d ;
        else
            pv = d_f / fx_spot / d_d - 1.0 / fx_forw ;
    }

    /* Move PV from spot date to analysis date */
	/* PMSTA-22396 - SRIDHARA � 160502 */
    ok = Disc_ForwDisc(df_d, analys, spot, &disc, holi) ;
    if (disc != 1.0)
        pv *= disc ;

    if (risk != NULL && (risk->key == KEY_DF || risk->key == KEY_BPV) &&
        risk->risk != ZERO_ORDER)
    {
        shock    = Scutl_Default_Shock(risk->shock, risk->key) ;
        fx_spot *= fxfw->base ;

        if (risk->dom == True)
        {
			/* PMSTA-22396 - SRIDHARA � 160502 */
            sdf = Disc_ShockRates(df_d, 1.0, risk, holi) ;
            pvu = FutFX_DF2NPV(analys, spot, fx_spot, fxfw, holi,
                               &sdf, df_f, NULL, &dum, &dum) ;
        }
        else
        {
            sdf = Disc_ShockRates(df_f, 1.0, risk, holi) ;  /* PMSTA-22396 - SRIDHARA � 160502 */
            pvu = FutFX_DF2NPV(analys, spot, fx_spot, fxfw, holi,
                               df_d, &sdf, NULL, &dum, &dum) ;
        }

        Free_PLANARRAY(sdf.disc, 1) ;

        if (risk->dom == True)
        {
            sdf = Disc_ShockRates(df_d, -1.0, risk, holi) ;  /* PMSTA-22396 - SRIDHARA � 160502 */
            pvd = FutFX_DF2NPV(analys, spot, fx_spot, fxfw, holi,
                               &sdf, df_f, NULL, &dum, &dum) ;
        }
        else
        {
            sdf = Disc_ShockRates(df_f, -1.0, risk, holi) ;  /* PMSTA-22396 - SRIDHARA � 160502 */
            pvd = FutFX_DF2NPV(analys, spot, fx_spot, fxfw, holi,
                               df_d, &sdf, NULL, &dum, &dum) ;
        }

        Free_PLANARRAY(sdf.disc, 1) ;

        if (risk->key == KEY_BPV)
            shock = 1.0 ;

        *dp = - (pvd - pvu) / (2.0 * shock) ;
        if (risk->risk == SECOND_ORDER && risk->key == KEY_DF)
            *ddp = (pvu + pvd - 2.0 * pv) / SQR(shock) ;
    }

    return pv ;
}


/*,,SOH,,
*************************************************************************
*
*               FutFX_PL2NPV()
*
*    interface  #include <futeqty.h>
*               FL64 FutFX_PL2NPV(FXFORW     *fxfw,
*                                 PLAN_STR   *fw_out,
*                                 HOLI_STR   *holi) ;
*
*    general    This routine calculates the P/L of a FX forward using
*               the FX forward curve (calculated from forward points).
*               This corresponds to an FX mark to market calculation.
*
*               In the following domestic / foreign refer to:
*
*                   Domestic - CCY paid
*                   Foreign  - CCY received
*
*    input      FXFORW     *fxfw     FX Forward data
*
*               PLAN_STR   *fw_out   The FX forward curve. Quoted as
*                                    fxfw->inv / ->base.
*                                    This curve represents FX outrights
*                                    that are forward point adjusted.
*
*               HOLI_STR   *holi     Holiday adjustment setup
*
*    output
*
*    returns    The P/L in domestic CCY per foreign CCY unit
*               Find full P/L by multiplying by foreign CCY amount
*
*    diagnostics
*
*    see also   FutFX_DF2FXrate()
*
*************************************************************************
,,EOH,,*/


FL64 FutFX_PL2NPV(FXFORW*  fxfw,
                  PLAN_STR*   fw_out,
                  HOLI_STR*   holi)
{
    FL64    pnl, fwd ;
    DATESTR madj ;

    /* Business day adjust */
    madj = Cldr_NextBusinessDate(&fxfw->matur, holi) ;

    /* Interpolate fwd rate */
    fwd = Cldr_Plan_Intpol(&madj, fw_out, fxfw->cal, LINEAR_FLAT_END, holi) ;  /* PMSTA-22396 - SRIDHARA � 160502 */

    /* P/L is */
    if (fxfw->inv == False)
        pnl = fwd - fxfw->fwd ;
    else
        pnl = 1.0 / fwd - 1.0 / fxfw->fwd ;

    /* Adjust for base */
    if (fabs(fxfw->base) > 0.0000001)
        pnl /= fxfw->base ;

    return pnl ;
}


/*,,SOH,,
*************************************************************************
*
*               FutFX_DF2Delta()
*
*    interface  #include <futeqty.h>
*               FL64ARRAY FutFX_DF2Delta(DATESTR    *analys,
*                                        DATESTR    *spot,
*                                        FL64       fx_spot,
*                                        FXFORW     *fxfw,
*                                        HOLI_STR   *holi,
*                                        DISCFAC    *df_d,
*                                        DISCFAC    *df_f,
*                                        DELTASET   *ds) ;
*
*    general    This routine calculates the delta vector of a FX forward*
*               contract using a list of predefined shocks to the zero
*               coupon curve.
*
*               The delta vector represents the price differences
*               invoked by the curve shocks.
*
*               In the following domestic / foreign refer to:
*
*                   Domestic - CCY paid
*                   Foreign  - CCY received
*
*    input      DATESTR    *analys   Pointer to analysis date.
*
*               DATESTR    *spot     The date for fx_spot
*
*               FL64       fx_spot   Spot exchange rate.
*                                    Quoted as fxfw->base / ->inv
*
*               FXFORW     *fxfw     FX Forward data
*
*               HOLI_STR   *holi     Holiday adjustment setup
*
*               DISCFAC    *df_d     Domestic discount factor setup
*
*               DISCFAC    *df_f     Foreign discount factor setup
*
*               DELTASET   *ds       Delta defining data
*                                    Relates to df_d or df_f depending
*                                    on ds->dom.
*
*    output
*
*    returns    The delta vector allocated as:
*
*                         Alloc_FL64ARRAY(ds->nshock) ;
*
*               The delta PV in domestic CCY per foreign CCY unit
*               Find full PV by multiplying by foreign CCY amount
*
*    diagnostics
*
*    see also   FutFX_DF2NPV()
*
*    wrapper    AP
*
*************************************************************************
,,EOH,,*/


FL64ARRAY FutFX_DF2Delta(DATESTR* analys,
                         DATESTR*    spot,
                         FL64       fx_spot,
                         FXFORW*     fxfw,
                         HOLI_STR*   holi,
                         DISCFAC*    df_d,
                         DISCFAC*    df_f,
                         DELTASET*   ds)
{
    INTI      i ;
    FL64ARRAY dv ;
    FL64      p0, dum ;
    PLANARRAY old ;
    DATESTR   fsprev ;

    dv  = Alloc_FL64ARRAY(ds->nshock) ;
    if (ds->dom == True)
        old = df_d->disc ;
    else
        old = df_f->disc ;

    /* The unshocked price */
    p0 = FutFX_DF2NPV(analys, spot, fx_spot, fxfw, holi, df_d,
                      df_f, NULL, &dum, &dum) ;

    for (i = 0; i < ds->nshock; i++)
    {
        fsprev = Disc_get_chgdate(NULL, old, &ds->shock[i]) ;

        if (fsprev.y > 0 && Cldr_DateLT(&fxfw->matur, &fsprev) == False)
        {
            if (ds->dom == True)
                df_d->disc = &ds->shock[i] ;
            else
                df_f->disc = &ds->shock[i] ;

            dv[i]  = FutFX_DF2NPV(analys, spot, fx_spot, fxfw,
                                  holi, df_d, df_f, NULL, &dum, &dum) ;
            dv[i] -= p0 ;

            if (ds->zero == True && ds->dom == True)
                /* Find shocked Zero PV */
                dv[i] /= Disc_DF2BPV(&ds->mid[i], df_d, old, holi) ;  /* PMSTA-22396 - SRIDHARA � 160502 */

            else if (ds->zero == True && ds->dom == False)
                /* Find shocked Zero PV */
                dv[i] /= Disc_DF2BPV(&ds->mid[i], df_f, old, holi) ;  /* PMSTA-22396 - SRIDHARA � 160502 */
        }
        else
            dv[i] = 0.0 ;
    }

    if (ds->dom == True)
        df_d->disc = old ;
    else
        df_f->disc = old ;

    return dv ;
}



/*
..
*/


/*,,SOH,,
************************************************************************
*
*                Set_FXFORW()
*
*   interface    #include <futeqty.h>
*                FXFORW Set_FXFORW(DATESTR* matur,
*                                  BOOLE    inv,
*                                  FL64     base,
*                                  FL64     fwd,
*                                  BOOLE    margin,
*                                  CALCONV  cal) ;
*
*   general      This routine sets the members of the struct defined
*                in the function name. The pointer members are simply
*                assigned - without physical copying. The intention
*                of the Set_*() routines is that by using this
*                functionality, one avoids setting individual members
*                of structs in the application code.
*
*                When new members are inserted in structs the Set_*()
*                routine will be changed accordingly.
*
*                One exception to this principle applies. Whenever
*                OPTADD and vanilla members are used, only the
*                vanilla members are set in the Set_*() routines. The
*                non-vanilla and exotic members are set to defaults,
*                and must be set elsewhere - if needed.
*
*                For details on the interpretation of the individual
*                struct members please check the struct definition.
*
*   input        DATESTR* matur  See general section.
*
*                BOOLE    inv    See general section.
*
*                FL64     base   See general section.
*
*                FL64     fwd    See general section.
*
*                BOOLE    margin See general section.
*
*                CALCONV  cal    See general section.
*
*   output
*
*   returns      The filled out FXFORW struct
*
*   diagnostics
*
*   see also     FXFORW
*
************************************************************************
,,EOH,,*/

FXFORW Set_FXFORW(DATESTR* matur,
                     BOOLE   inv,
                     FL64    base,
                     FL64    fwd,
                     BOOLE   margin,
                     CALCONV cal)
{
    FXFORW fxfw ;

    fxfw.matur  = *matur ;
    fxfw.inv    = inv ;
    fxfw.base   = base ;
    fxfw.fwd    = fwd ;
    fxfw.margin = margin ;
    fxfw.cal    = cal ;

    return fxfw ;
}

#undef DISC_TOLR

/* SCID @(#)eqtyval.c	1.4 (SimCorp) 99/02/19 14:14:21 */

/************************************************************************
*
*   project     SCecon
*
*   file name   eqtyval.c
*
*   general     This file contains routines for validating the
*               content of the data structures of SCecon
*
************************************************************************/

/*** includes **********************************************************/
#include <eqtyval.h>
#include <optvalid.h>
#include <bondvl.h>

/*** defines ***********************************************************/
#define valid_tol 0.000001


/*,,SOH,,
*************************************************************************
*
*               Validate_FUTEQTY()
*
*   interface   #include <eqtyval.h>
*               VALIDATE Validate_FUTEQTY(FUTEQTY *f)
*
*   general     This function validates the content of the FUTEQTY
*               data structure
*
*   input       FUTEQTY   *f  The FUTEQTY data structure
*
*   output
*
*   returns     Valid_data if the content of f is valid
*               Invalid_matur if matur is an invalid date
*               If the content of div is invalid an error message
*                    from Validate_PLAN_STR() is returned
*               Invalid_cal if cal is an invalid calendar convention
*
*
*   diagnostics
*
*   see also    FUTEQTY
*
*************************************************************************
,,EOH,,*/


VALIDATE Validate_FUTEQTY(FUTEQTY* f)
{
    VALIDATE v ;

    if (Cldr_CheckDate(&f->matur) == False && 
        Cldr_IsNullDate(&f->matur) == False)
        return Invalid_matur ;

    v = Validate_PLAN_STR(f->div) ;
    if (v != Valid_data)
        return v ;

    if (!Validate_CALCONV(f->cal))
        return Invalid_cal ;

    return Valid_data ;
}

/*,,SOH,,
*************************************************************************
*
*               Validate_FUTCMDTY()
*
*   interface   #include <eqtyval.h>
*               VALIDATE Validate_FUTCMDTY(FUTCMDTY *f)
*
*   general     This function validates the content of the FUTCMDTY
*               data structure
*
*   input       FUTCMDTY   *f  The FUTCMDTY data structure
*
*   output
*
*   returns     Valid_data if the content of f is valid
*
*
*   diagnostics
*
*   see also    FUTCMDTY
*
*************************************************************************
,,EOH,,*/


VALIDATE Validate_FUTCMDTY(FUTCMDTY* f)
{
    VALIDATE v ;

    if (Cldr_CheckDate(&f->matur) == False && 
        Cldr_IsNullDate(&f->matur) == False)
        return Invalid_matur ;

    v = Validate_PLAN_STR(f->stc) ;
    if (v != Valid_data)
        return v ;

    v = Validate_PLAN_STR(f->cy) ;
    if (v != Valid_data)
        return v ;

    if (!Validate_CALCONV(f->cal))
        return Invalid_cal ;

    return Valid_data ;
}


/*,,SOH,,
*************************************************************************
*
*               Validate_FXFORW()
*
*   interface   #include <eqtyval.h>
*               VALIDATE Validate_FXFORW(FXFORW *f)
*
*   general     This function validates the content of the FXFORW
*               data structure
*
*   input       FXFORW   *f       The FXFORW data structure
*
*   output
*
*   returns     Valid_data if the content of f is valid
*               Invalid_date if matur is an invalid date
*               Invalid_boole if inv is not True or False
*               Invalid_base if base <= 0
*
*   diagnostics
*
*   see also    FXFORW
*
*************************************************************************
,,EOH,,*/

VALIDATE Validate_FXFORW(FXFORW* f)
{
    BOOLE ok ;

    ok = Cldr_CheckDate(&f->matur) ;
    if (ok == False)
        return Invalid_date ;

    if (!Validate_BOOLE(f->inv))
        return Invalid_boole ;

    if (f->base <= 0)
        return Invalid_base ;

    if (!Validate_BOOLE(f->margin))
        return Invalid_boole ;
    
    if (!Validate_CALCONV(f->cal))
        return Invalid_cal ;

    return Valid_data ;
}


/*,,SOH,,
***********************************************************************
*                                                                      
*               Validate_TREEOPT()
*                                                                      
*   interface   #include <eqtyval.h>                                  
*               VALIDATE Validate_TREEOPT(TREEOPT *x)
*                                                                      
*   general     This function validates the content of the TREEOPT
*               data structure                                         
*                                                                      
*   input       TREEOPT *x   The TREEOPT structure.
*                                                                      
*   output                                                             
*                                                                      
*   returns     Valid_data if the content of TREEOPT is 
*               valid.
*                                                                      
*   diagnostics
*               Refer to TREEOPT for a specification of valid data.
*              
*   see also    TREEOPT
*                                                                      
***********************************************************************
,,EOH,,*/
VALIDATE Validate_TREEOPT(TREEOPT*  x)
{
    VALIDATE v;

    if (Validate_OPTTYPE(x->type) == False)
        return Invalid_opttype;

    if (Validate_BOOLE(x->berm) == False)
        return Invalid_boole;

    v = Validate_PAYDAYDEF(&x->dpay, False);
    if (v != Valid_data)
        return v;

    if (Validate_PERIOD(&x->pay_delay) == False)
        return Invalid_period;

    if (Validate_CALCONV(x->cal) == False)
        return Invalid_cal;

    return Valid_data;
}



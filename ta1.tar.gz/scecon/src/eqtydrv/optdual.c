/* SCID @(#)optdual.c	1.4 (SimCorp) 99/02/19 14:14:35 */

/************************************************************************
*
*   project     SCecon
*
*   filename    optdual.c
*
*   contains    routines in the SCecon options library.
*
************************************************************************/

/***** includes ********************************************************/
#include <opteqty.h>


/***** defines  ********************************************************/
#define SHOCKSIZE 0.01


/*,,SOH,,
*************************************************************************
*
*               OptEqtyCT_Black2P()
*
*    interface  #include <opteqty.h>
*               FL64 OptEqtyCT_Black2P(DATESTR  *analys,
*                                      DATESTR  *voldate,
*                                      FL64     spot,
*                                      FL64     FX,
*                                      FL64     vol_s,
*                                      FL64     vol_FX,
*                                      FL64     corr,
*                                      FL64     divyld,
*                                      FUTEQTY  *fute,
*                                      OPTCT    *opt,
*                                      DISCFAC  *df_d,
*                                      DISCFAC  *df_f,
*                                      HOLI_STR *holi,
*                                      RISKSET  *risk,
*                                      FL64     *dp,
*                                      FL64     *ddp) ;
*
*    general    The routine calculates the premium for a Currency
*               Translated (CT) European option using Rubinstein's
*               closed-form solutions.
*
*               Key ratios are calculated as follows:
*
*                   risk->key      dp          ddp
*                   ---------      ---         ----
*                   KEY_SPOT       Delta       Gamma
*
*    input      DATESTR  *analys  Pointer to analysis date (NPV date)
*
*               DATESTR  *voldate Vol calculated from this date.
*
*               FL64     spot     The spot price
*
*               FL64     FX       The FX rate (straight quoting).
*
*               FL64     vol_s    The annual volatility of the Spot
*                                 price in percent.
*
*               FL64     vol_FX   The annual volatility of the FX rate
*                                 in percent.
*
*               FL64     corr     The correlation between returns in
*                                 the spot and the FX rate.
*
*               FL64     divyld   Dividend yield (continuous rate in %).*
*
*               FUTEQTY  *fute    Equity data
*
*               OPTCT    *opt     The data defining the option.
*
*               DISCFAC  *df_d    Domestic Discount Function
*
*               DISCFAC  *df_f    Foreign Discount Function
*
*               HOLI_STR *holi    Holiday setup
*
*               RISKSET  *risk    The risk ratio definitions
*                                 Use NULL for no Greeks
*
*    output     FL64     *dp      Pointer to the first order derivative.*
*
*               FL64     *ddp     Pointer to the second order derivative*
*
*    returns    the option premium.
*
*    diagnostics
*
*    see also   OptEqty_Black2P()
*               OptEqty_VOLBOX2Vol()
*
*************************************************************************
,,EOH,,*/

/* WARNING: TOO MANY ARGS (>15) BELOW */
FL64 OptEqtyCT_Black2P(DATESTR  *analys,
                       DATESTR  *voldate,
                       FL64     spot,
                       FL64     FX,
                       FL64     vol_s,
                       FL64     vol_FX,
                       FL64     corr,
                       FL64     divyld,
                       FUTEQTY  *fute,
                       OPTCT    *opt,
                       DISCFAC  *df_d,
                       DISCFAC  *df_f,
                       HOLI_STR *holi,
                       RISKSET  *risk,
                       FL64     *dp,
                       FL64     *ddp)
{
    FL64     size, phi, plo, dp1, ddp1, adj, vol, p, s0, dfix, disc ;
    OPTINT   oint ;
    BOOLE    ok ;

    /* warning avoidance */
    p = size = 0.0 ;

    *dp = *ddp = 0.0 ;

    if (opt->type == STRADDLE)
    {
        opt->type = CALL ;
        p = OptEqtyCT_Black2P(analys, voldate, spot, FX, vol_s, vol_FX, corr,
                              divyld, fute, opt, df_d, df_f, holi, risk, dp,
                              ddp) ;
        opt->type = PUT ;
        p += OptEqtyCT_Black2P(analys, voldate, spot, FX, vol_s, vol_FX, corr,
                               divyld, fute, opt, df_d, df_f, holi, risk, &dp1,
                               &ddp1) ;
        opt->type = STRADDLE ;
        *dp  += dp1 ;
        *ddp += ddp1 ;

        return p ;
    }

    vol_s    /= 100.0 ;
    vol_FX   /= 100.0 ;

    oint = optCT_set_OPTINT(analys, voldate, opt, holi) ;

    switch (opt->cttype)
    {
/*
..case vanilla ???
*/
        case FESDC:

            /* Use simple equivalence */
            vol = vol_s * vol_s + vol_FX * vol_FX ;
            vol = sqrt(vol + 2.0 * corr * vol_s * vol_FX) ;
            s0  = spot * FX ;
            adj = 1.0 ;
            if (fabs(spot) > 0.00001)
                /* Adjust dividends with foreign DF */
                adj = FutEqty_CC2AdjSpot(analys, &opt->dfix, spot, fute->cal,
                                         divyld, fute->div, holi) / spot ;   /* PMSTA-22396 - SRIDHARA � 160502 */

			/* PMSTA-22396 - SRIDHARA � 160502 */
            /* Find discount factors */
            disc = Disc_Interpolation(&opt->dpay, df_d, holi) ;
            ok   = Disc_forwval(df_d, analys, &disc, holi) ;
            dfix = Disc_Interpolation(&opt->dfix, df_d, holi) ;
            ok   = ok && Disc_forwval(df_d, analys, &dfix, holi) ;

            p = Black_Premium(&oint, s0, True, adj, 100.0 * vol, dfix, disc,
                              KEY_SPOT, ZERO_ORDER, 0.01, COMPOUND, 1,
                              dp, ddp, holi) ;   /* PMSTA-22396 - SRIDHARA � 160502 */
            break ;

        case QUANTOPT:

            /* Use simple equivalence */
            vol = vol_s ;
            s0  = spot * opt->quanto.FX0 ;

            oint.e *= opt->quanto.FX0 ;

            /* Adjust dividends with foreign DF */
            adj = 1.0 ;
            if (fabs(spot) > 0.00001)
                /* Adjust dividends with foreign DF */
                adj = FutEqty_CC2AdjSpot(analys, &opt->dfix, spot, fute->cal,
                                         divyld, fute->div, holi) / spot ;   /* PMSTA-22396 - SRIDHARA � 160502 */
            adj *= exp(- corr * vol_s * vol_FX * oint.tfix) ;

            /* Find discount factors */
			/* PMSTA-22396 - SRIDHARA � 160502 */
            disc = Disc_Interpolation(&opt->dpay, df_d, holi) ;
            ok   = Disc_forwval(df_d, analys, &disc, holi) ;
            dfix = Disc_Interpolation(&opt->dfix, df_f, holi) ;
            ok   = ok && Disc_forwval(df_f, analys, &dfix, holi) ;

            p = Black_Premium(&oint, s0, True, adj, 100.0 * vol, dfix, disc,
                              KEY_SPOT, ZERO_ORDER, 0.01, COMPOUND, 1,
                              dp, ddp, holi) ;   /* PMSTA-22396 - SRIDHARA � 160502 */
            break ;

        case ELFX:

            /* Use simple equivalence */
            vol = vol_FX ;
            s0  = spot * FX ;
            oint.e *= spot ;

            /* Adjust dividends with foreign DF */
            adj = 1.0 ;
            if (fabs(spot) > 0.00001)
                /* Adjust dividends with foreign DF */
                adj = FutEqty_CC2AdjSpot(analys, &opt->dfix, spot, fute->cal,
                                         divyld, fute->div, holi) / spot ;   /* PMSTA-22396 - SRIDHARA � 160502 */

            /* Find discount factors */
			/* PMSTA-22396 - SRIDHARA � 160502 */
            disc  = Disc_Interpolation(&opt->dpay, df_d, holi) ;
            ok    = Disc_forwval(df_d, analys, &disc, holi) ;

            dfix  = Disc_Interpolation(&opt->dpay, df_f, holi) ;
            ok    = Disc_forwval(df_f, analys, &dfix, holi) ;

            if (fabs(dfix) > 0.00001)
                dfix = 1.0 / dfix ;
            dfix *= disc * adj ;
            dfix *= exp(- corr * vol_s * vol_FX * oint.tfix) ;
            disc  = dfix ;

            p = Black_Premium(&oint, s0, True, adj, 100.0 * vol, dfix, disc,
                              KEY_SPOT, ZERO_ORDER, 0.01, COMPOUND, 1,
                              dp, ddp, holi) ;   /* PMSTA-22396 - SRIDHARA � 160502 */
            break ;
    }

    /* Compute risk ratios - if specified. */
    if (risk == NULL || risk->risk == ZERO_ORDER)
        return p ;

    vol_s    *= 100.0 ;
    vol_FX   *= 100.0 ;

    switch (risk->key)
    {
        case KEY_SPOT:

            size = Scutl_Default_Shock(risk->shock, risk->key) ;
            if (fabs(size) > spot)
                size = spot / 2.0 ;

            plo = OptEqtyCT_Black2P(analys, voldate, spot-size, FX, vol_s,
                                    vol_FX, corr, divyld, fute, opt, df_d, df_f,
                                    holi, NULL, dp, ddp) ;
            phi = OptEqtyCT_Black2P(analys, voldate, spot+size, FX, vol_s,
                                    vol_FX, corr, divyld, fute, opt, df_d, df_f,
                                    holi, NULL, dp, ddp) ;
            break ;

        default:

            phi = plo = p ;
            break ;
    }

    if (fabs(size) > 0.000000001)
        *dp = (phi - plo) / (2.0 * size) ;
    if (risk->risk == SECOND_ORDER && fabs(size) > 0.000000001)
        *ddp = (phi + plo - 2.0 * p) / SQR(size) ;

    return p ;
}


/*
..
*/


OPTINT optCT_set_OPTINT(DATESTR* analys, 
                           DATESTR* vold, 
                           OPTCT* optd, 
                           HOLI_STR*  holi)
{
    OPTINT  opt ;
    DATESTR dp, df ;

    opt.analys  = *analys ;
    opt.voldate = *vold ;

    df = Cldr_NextBusinessDate(&optd->dfix, holi) ;
    dp = Cldr_NextBusinessDate(&optd->dpay, holi) ;

    opt.type  = optd->type ;
    opt.e     = optd->strike ;
	/* PMSTA-22396 - SRIDHARA � 160502 */
    opt.tvol  = Cldr_TermBetweenDates(vold, &df, 0, optd->cal, LAST, holi) ;
    opt.tfix  = Cldr_TermBetweenDates(analys, &df, 0, optd->cal, LAST, holi);
    opt.t     = Cldr_TermBetweenDates(analys, &dp, 0, optd->cal, LAST, holi);
    opt.ptype = optd->ptype ;
    opt.cal   = optd->cal ;

    opt.oadd  = NO_OPTADD ;

    return opt ;
}


#undef SHOCKSIZE

/* SCID @(#)futeqty.c	1.13 (SimCorp) 99/09/07 13:39:37 */

/************************************************************************
*
*       project         SCecon
*
*       file name       futeqty.c
*
*       contains        Equity futures calculations
*
************************************************************************/

/*** includes **********************************************************/
#include <futeqty.h>

/*,,SOH,,
*************************************************************************
*
*               FutEqty_CC2Price()
*
*   interface   #include <futeqty.h>
*               FL64 FutEqty_CC2Price(DATESTR  *spotdate,
*                                     FL64     spot,
*                                     FUTEQTY  *fute,
*                                     FL64     divyld,
*                                     DISCFAC  *df,
*                                     HOLI_STR *holi) ;
*
*   general     This function calculates the Forward Equity price using
*               the cost of carry model (CC).
*
*   input       DATESTR     *spotdate    The date for the spot price
*
*               FL64        spot         The current spot price
*
*               FUTEQTY     *fute        The equity forward data
*
*               FL64        divyld       The dividend yield as a
*                                        CONTINUOUS rate (%)
*
*               DISCFAC     *df          Discount function
*
*               HOLI_STR    *holi        Holiday adjustment setup
*
*   output
*
*   returns     The forward price
*
*   diagnostics
*
*   see also    FutEqty_CC2AdjSpot()
*               FutEqty_CC2Impl()
*               FutEqty_CC2NPV()
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/


FL64 FutEqty_CC2Price(DATESTR* spotdate,
                       FL64     spot,
                       FUTEQTY*  fute,
                       FL64     divyld,    /* CONTINUOUS only */
                       DISCFAC*  df,
                       HOLI_STR* holi)
{
    FL64    sk, dsc, f ;
    DATESTR matur ;

    matur = Cldr_NextBusinessDate(&fute->matur, holi) ;
	/* PMSTA-22396 - SRIDHARA � 160502 */
    sk  = FutEqty_CC2AdjSpot(spotdate, &matur, spot, fute->cal, divyld,
                             fute->div, holi) ;
    dsc = Disc_Interpolation(&matur, df, holi) ;
    Disc_forwval(df, spotdate, &dsc, holi) ;
    if (fabs(dsc) > 0.00000001)
        f = sk / dsc ;
    else
        f = sk ;

    return f ;
}



/*,,SOH,,
*************************************************************************
*
*               FutEqty_CC2NPV()
*
*   interface   #include <futeqty.h>
*               FL64 FutEqty_CC2NPV(DATESTR  *analys,
*                                   DATESTR  *spotdate,
*                                   FL64     spot,
*                                   FUTEQTY  *fute,
*                                   FL64     divyld,
*                                   DISCFAC  *df,
*                                   HOLI_STR *holi,
*                                   RISKSET  *risk,
*                                   FL64     *dp,
*                                   FL64     *ddp) ;
*
*   general     This function calculates the PV of an equity futures
*               contract using the cost of carry model (CC).
*
*               Key ratios are calculated as follows:
*
*                   risk->key        dp          ddp
*                   ---------        ---         ----
*                   KEY_DF           $Dur        $Conv
*                   KEY_BPV          BPV
*
*   input       DATESTR     *analys      The PV date
*
*               DATESTR     *spotdate    The date for the spot price
*
*               FL64        spot         The current spot price
*
*               FUTEQTY     *fute        The equity forward data
*
*               FL64        divyld       The dividend yield as a
*                                        CONTINUOUS rate (%)
*
*               DISCFAC     *df          Discount function
*
*               HOLI_STR    *holi        Holiday adjustment setup
*
*               RISKSET     *risk        The risk ratio definitions
*                                        Use NULL for no risk ratios
*
*   output      FL64        *dp          The first order ratio
*
*               FL64        *ddp         The second order ratio.
*
*   returns     The contract PV
*
*   diagnostics
*
*   see also    FutEqty_CC2AdjSpot()
*               FutEqty_CC2Impl()
*               FutEqty_CC2Price()
*               FutEqty_CC2Delta()
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/


FL64 FutEqty_CC2NPV(DATESTR* analys,
                    DATESTR*  spotdate,
                    FL64     spot,
                    FUTEQTY*  fute,
                    FL64     divyld,    /* CONTINUOUS only */
                    DISCFAC*  df,
                    HOLI_STR* holi,
                    RISKSET*  risk,
                    FL64*     dp,
                    FL64*     ddp)
{
    FL64    pvu, pvd, shock, f, pv ;
    DISCFAC sdf ;
    DATESTR matur ;

    *dp = *ddp = 0.0 ;

    matur = Cldr_NextBusinessDate(&fute->matur, holi) ;
    f  = FutEqty_CC2Price(spotdate, spot, fute, divyld, df, holi) ;
    pv = f - fute->futp ;
	pv = Disc_MarginAdjust(fute->margin, pv, analys, &matur, df, holi);  	/* PMSTA-22396 - SRIDHARA � 160502 */

    if (risk != NULL && (risk->key == KEY_DF || risk->key == KEY_BPV) &&
        risk->risk != ZERO_ORDER)
    {
        shock   = Scutl_Default_Shock(risk->shock, risk->key) ;

        sdf = Disc_ShockRates(df, 1.0, risk, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
        pvu = FutEqty_CC2NPV(analys, spotdate, spot, fute, divyld, &sdf, holi,
                             NULL, dp, ddp) ;
        Free_PLANARRAY(sdf.disc, 1) ;

        sdf = Disc_ShockRates(df, - 1.0, risk, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
        pvd = FutEqty_CC2NPV(analys, spotdate, spot, fute, divyld, &sdf, holi,
                             NULL, dp, ddp) ;
        Free_PLANARRAY(sdf.disc, 1) ;

        if (risk->key == KEY_BPV)
            shock = 1.0 ;

        *dp = (pvu - pvd) / (2.0 * shock) ;
        if (risk->risk == SECOND_ORDER && risk->key == KEY_DF)
            *ddp = (pvu + pvd - 2.0 * pv) / SQR(shock) ;
    }

    return pv ;
}


/*,,SOH,,
*************************************************************************
*
*               FutEqty_CC2Delta()
*
*   interface   #include <futeqty.h>
*               FL64ARRAY FutEqty_CC2Delta(DATESTR  *analys,
*                                          DATESTR  *spotdate,
*                                          FL64     spot,
*                                          FUTEQTY  *fute,
*                                          FL64     divyld,
*                                          DISCFAC  *df,
*                                          HOLI_STR *holi,
*                                          DELTASET *ds) ;
*
*   general     This function calculates the delta vector for an equity
*               futures contract using the cost of carry model (CC).
*
*   input       DATESTR     *analys      The PV date
*
*               DATESTR     *spotdate    The date for the spot price
*
*               FL64        spot         The current spot price
*
*               FUTEQTY     *fute        The equity forward data
*
*               FL64        divyld       The dividend yield as a
*                                        CONTINUOUS rate (%)
*
*               DISCFAC     *df          Discount function
*
*               HOLI_STR    *holi        Holiday adjustment setup
*
*               DELTASET    *ds          Delta vector defining data
*
*   output
*
*   returns     The delta vector allocated as:
*
*                         Alloc_FL64ARRAY(ds->nshock) ;
*   diagnostics
*
*   see also    FutEqty_CC2NPV()
*               FutEqty_CC2Price()
*
*   wrapper     AP
*
*************************************************************************
,,EOH,,*/


FL64ARRAY FutEqty_CC2Delta(DATESTR* analys,
                           DATESTR*  spotdate,
                           FL64     spot,
                           FUTEQTY*  fute,
                           FL64     divyld,    /* CONTINUOUS only */
                           DISCFAC*  df,
                           HOLI_STR* holi,
                           DELTASET* ds)
{
    INTI      i ;
    FL64ARRAY dv ;
    FL64      p0, dum ;
    PLANARRAY old ;
    DATESTR   matur, fsprev ;

    /* Initialise */
    dv        = Alloc_FL64ARRAY(ds->nshock) ;
    old       = df->disc ;

    /* The unshocked price */
    p0    = FutEqty_CC2NPV(analys, spotdate, spot, fute, divyld, df, holi,
                           NULL, &dum, &dum) ;
    matur = Cldr_NextBusinessDate(&fute->matur, holi) ;

    for (i = 0; i < ds->nshock; i++)
    {
        fsprev = Disc_get_chgdate(NULL, old, &ds->shock[i]) ;

        if (fsprev.y > 0 && Cldr_DateLT(&matur, &fsprev) == False)
        {
            df->disc = &ds->shock[i] ;
            dv[i]    = FutEqty_CC2NPV(analys, spotdate, spot, fute, divyld, df,
                                      holi, NULL, &dum, &dum) - p0 ;

            if (ds->zero == True)
                /* Find shocked Zero PV */
                dv[i] /= Disc_DF2BPV(&ds->mid[i], df, old, holi) ;  	/* PMSTA-22396 - SRIDHARA � 160502 */
        }
        else
            dv[i] = 0.0 ;
    }

    /* Clean up */
    df->disc = old ;

    return dv ;
}




/*,,SOH,,
*************************************************************************
*
*               FutEqty_CC2AdjSpot()
*
*   interface   #include <futeqty.h>
*               FL64 FutEqty_CC2AdjSpot(DATESTR  *today,
*                                       DATESTR  *matur,
*                                       FL64     spot,
*                                       CALCONV  cal,
*                                       FL64     div_yld,
*                                       PLAN_STR *div) ;
*
*   general     This function return the spot price adjusted for future
*               dividends or dividend yield.
*
*   input       DATESTR     *today    The date for the spot price
*
*               DATESTR     *matur    The maturity date
*
*               FL64        spot      The current spot market price
*
*               CALCONV     cal       Calendar convention
*
*               FL64        div_yld   The dividend yield as a
*                                     CONTINUOUS rate (%)
*
*               PLAN_STR    *div      Structure of known proportional 
*                                     dividends in percent (%). 
*
*	       	    HOLI_STR    *holi	  Container for list of holidays.
*                                     
*
*   output
*
*   returns     The adjusted spot price
*
*   diagnostics
*
*   see also    FutEqty_CC2NPV()
*               FutEqty_CC2Price()
*               FutEqty_CC2Impl()
*
*************************************************************************
,,EOH,,*/
FL64 FutEqty_CC2AdjSpot(DATESTR* today,
                        DATESTR*  matur,
                        FL64     spot,
                        CALCONV  cal,
                        FL64     div_yld,
                        PLAN_STR* div,
						HOLI_STR* holi)
{
  FL64      adj, pvd, term;
  INTI      i;

  /* warning avoidance */
  adj = 0.0;

  if (GetPlanFill(div) == 0)  /* continuous dividends */
  {
	  term = Cldr_TermBetweenDates(today, matur, 0, cal, SAME, holi); 	/* PMSTA-22396 - SRIDHARA � 160502 */
    adj  = spot * TVMunit_NPV(term, div_yld, CONTINUOUS, 0);
  }
  else  /* discrete dividends */
  {
    for (pvd = 0.0, i = 0; i < div->filled; i++)
    {
      if (Cldr_DateLE(&div->day[i], matur) == True &&
          Cldr_DateLT(today, &div->day[i]) == True)
        /* make adjustment for proportional dividends */
        pvd += spot / 100.0 * div->f64[i];

      /* consider possibility of adding support for dollar dividends 
         as follows
      {
        disc = Disc_Interpolation(&div->day[i], df) ;
        pvd += disc * spot / 100.0 * div->f64[i] ;
      } 
       where df is declared as a DISCFAC */
    }
    adj = spot - pvd;
  }

  return adj;
}


/*,,SOH,,
*************************************************************************
*
*               FutEqty_CC2Impl()
*
*   interface   #include <futeqty.h>
*               BOOLE FutEqty_CC2Impl(DATESTR  *spotdate,
*                                     FL64     spot,
*                                     FL64     futp,
*                                     FUTEQTY  *fute,
*                                     FL64     divyld,
*                                     DISCFAC  *df,
*                                     HOLI_STR *holi,
*                                     KEYCONV  what,
*                                     ITERCTRL *ictrl,
*                                     FL64     *impl) ;
*
*   general     This function calculates an implied ratio
*               given the forward equity price using the cost of carry
*               model (CC).
*
*               Ratios calculated are:
*
*                  what          ratio
*                  ------------------------------------
*                  KEY_SPOT      implied spot
*                  KEY_REPO      implied repo (CONTINUOUS)
*                  KEY_DIVYLD    implied dividend yield (CONTINUOUS)
*
*   input       DATESTR     *spotdate The date for the spot price
*
*               FL64        spot      The current spot market price
*
*               FL64        futp      The forward equity market price
*
*               FUTEQTY     *fute     The equity forward data
*
*               FL64        divyld    The dividend yield as a
*                                     CONTINUOUS rate (%)
*
*               DISCFAC     *df       Discount function
*
*               HOLI_STR    *holi     Holiday adjustment setup
*
*               KEYCONV     what      What implied ratio to calculate
*
*               ITERCTRL    *ictrl    Iteration control
*
*   output      FL64        *impl     The implied ratio
*
*   returns     True if OK, False if not
*
*   diagnostics
*
*   see also    FutEqty_CC2NPV()
*               FutEqty_CC2Price()
*
*************************************************************************
,,EOH,,*/


BOOLE FutEqty_CC2Impl(DATESTR* spotdate,
                        FL64     spot,
                        FL64     futp,
                        FUTEQTY*  fute,
                        FL64     divyld,
                        DISCFAC*  df,
                        HOLI_STR* holi,
                        KEYCONV  what,
                        ITERCTRL* ictrl,
                        FL64*     impl)
{
    FL64         shock, adj, npv, tmp, t ;
    DATESTR      matur ;
    BOOLE        ok ;
    DISCFAC      dfrepo ;
    DFPARMS      dfp ;
    FUTEQTYINT   fut_data ;
    ITERCTRL     ctrl ;
    NR_ERR       err ;

    ok    = True ;
    *impl = npv = 0.0 ;

    /* Term till maturity */
    matur = Cldr_NextBusinessDate(&fute->matur, holi) ;
    t = Cldr_TermBetweenDates(spotdate, &matur, 0, fute->cal, SAME, holi); 	/* PMSTA-22396 - SRIDHARA � 160502 */

    if (what == KEY_DIVYLD)
    {
        /* First find net present value of discrete payments */
        if (GetPlanFill(fute->div) > 0)
        {
            npv = FutEqty_CC2AdjSpot(spotdate, &matur, spot, fute->cal, 0.0,
                                     fute->div, holi); 	/* PMSTA-22396 - SRIDHARA � 160502 */
            npv = spot - npv ;
        }

        /* Do calculation */
        tmp = npv + Disc_Interpolation(&matur, df, holi) * futp ;   /* PMSTA-22396 - SRIDHARA � 160502 */
        tmp = (fabs(spot) > 0.000001 ? tmp / spot : 0.0) ;

        Disc_forwval(df, spotdate, &tmp, holi); 	/* PMSTA-22396 - SRIDHARA � 160502 */
        *impl = TVMunit_Yield(tmp, t, CONTINUOUS, 0) ;
    }

    else if (what == KEY_REPO)
    {
        if (GetPlanFill(fute->div) == 0)
        {
            tmp   = FutEqty_CC2AdjSpot(spotdate, &matur, spot, fute->cal,
                                       divyld, NULL, holi); 	/* PMSTA-22396 - SRIDHARA � 160502 */
            tmp   = (fabs(futp) > 0.000001 ? tmp / futp : 0.0) ;
            *impl = TVMunit_Yield(tmp, t, CONTINUOUS, 0) ;
        }

        /* Unfortunately we will have to iterate here */
        else
        {
            futEqty_set_itervars(ictrl, &ctrl, &shock) ;

            dfp = Set_DFPARMS(DI_SPOT, LINEAR_FLAT_END, fute->cal,
                                   CONTINUOUS, ANNUALLY) ;

            fut_data = FutEqty_SetFUTEQTYINT(spotdate, &matur,
              spot, futp, &dfp, fute, &dfrepo, holi, shock) ;

            err = Newton_Raphson(&FutEqty_NewtonRaphson, &fut_data, 
              &ctrl, impl, holi); 	/* PMSTA-22396 - SRIDHARA � 160502 */
            ok = (err == NR_ROOT_FOUND ? True : False) ;
        }
    }

    else if (what == KEY_SPOT)
    {
        adj = FutEqty_CC2AdjSpot(spotdate, &matur, 1.0, fute->cal,
                                 divyld, fute->div, holi); 	/* PMSTA-22396 - SRIDHARA � 160502 */
        tmp   = (fabs(adj) > 0.000001 ? futp / adj : 0.0) ;
        *impl  = tmp * Disc_Interpolation(&matur, df, holi); 	/* PMSTA-22396 - SRIDHARA � 160502 */
        Disc_forwval(df, spotdate, impl, holi); 	/* PMSTA-22396 - SRIDHARA � 160502 */
    }

    /* Return */
    return ok ;
}

/*
..
*/


/*,,SOH,,
************************************************************************
*
*                Set_FUTEQTY()
*
*   interface    #include <futeqty.h>
*                FUTEQTY Set_FUTEQTY(DATESTR*  matur,
*                                    PLAN_STR* div,
*                                    CALCONV   cal,
*                                    FL64      futp,
*                                    BOOLE     margin) ;
*
*   general      This routine sets the members of the struct defined
*                in the function name. The pointer members are simply
*                assigned - without physical copying. The intention
*                of the Set_*() routines is that by using this
*                functionality, one avoids setting individual members
*                of structs in the application code.
*
*                When new members are inserted in structs the Set_*()
*                routine will be changed accordingly.
*
*                One exception to this principle applies. Whenever
*                OPTADD and vanilla members are used, only the
*                vanilla members are set in the Set_*() routines. The
*                non-vanilla and exotic members are set to defaults,
*                and must be set elsewhere - if needed.
*
*                For details on the interpretation of the individual
*                struct members please check the struct definition.
*
*   input        DATESTR*  matur  See general section.
*
*                PLAN_STR* div    See general section.
*
*                CALCONV   cal    See general section.
*
*                FL64      futp   See general section.
*
*                BOOLE     margin See general section.
*
*   output
*
*   returns      The filled out FUTEQTY struct
*
*   diagnostics
*
*   see also     FUTEQTY
*                Free_FUTEQTY()
*
************************************************************************
,,EOH,,*/

FUTEQTY Set_FUTEQTY(DATESTR* matur,
                           PLAN_STR* div,
                           CALCONV  cal,
                           FL64     futp,
                           BOOLE    margin)
{
    FUTEQTY fute ;

    fute.matur  = *matur ;
    fute.div    = div ;
    fute.cal    = cal ;
    fute.futp   = futp ;
    fute.margin = margin ;

    return fute ;
}


/*
..
*/


void futEqty_set_itervars(ITERCTRL*  ictrl,
                             ITERCTRL*  ctrl, 
                             FL64*      shock)
{
    Init_ITERCTRL(ctrl) ;
  
    *shock = (ictrl->shock <= 0.0 ? 0.01 : ictrl->shock) ;

    ctrl->maxiter    = (ictrl->maxiter < 0 ? 100 : ictrl->maxiter) ;
    ctrl->damp       = (ictrl->damp < 0.0  ?  0.9 : ictrl->damp) ;
    ctrl->acc        = (ictrl->acc < 0.0   ?   
      0.000000001 : ictrl->acc) ;
    ctrl->what_acc   = (ictrl->what_acc < 0   ? 1 : ictrl->what_acc) ;
    ctrl->shock      = 0.0 /* no multiple roots check */ ;
    ctrl->gfreq      = (ictrl->gfreq < 0 ? 5 : ictrl->gfreq) ;
    ctrl->bisec      = (ictrl->bisec < 0 ? 1 : ictrl->bisec) ;

    /* Set uninitialized initial guess. */
    if (ictrl->use_init_guess == False)
    {
      if ((ictrl->use_lower) && (ictrl->use_upper))
        ctrl->init_guess = 0.5 * (ictrl->upper + ictrl->lower) ;
      else 
        ctrl->init_guess = 0.0 ;
    }
    else
      ctrl->init_guess = ictrl->init_guess ;

    /* Set uninitialized boundaries for iteration. */
    if (ictrl->use_lower)
      ctrl->lower = GETMIN(ictrl->lower, ctrl->init_guess) ;
    else
      ctrl->lower = GETMIN(0.0, ctrl->init_guess)  ;

    if (ictrl->use_upper)
      ctrl->upper = GETMAX(ictrl->upper, ctrl->init_guess) ;
    else
      ctrl->upper = GETMAX(100.0, ctrl->init_guess) ;

}

/*
..
*/

FUTEQTYINT FutEqty_SetFUTEQTYINT(DATESTR*   spotdate,
                                    DATESTR*   matur,
                                    FL64       spot,
                                    FL64       futp,
                                    DFPARMS*   dfp,
                                    FUTEQTY*   fute,
                                    DISCFAC*   dfrepo,
                                    HOLI_STR*  holi,
                                    FL64       shock) 
{
  FUTEQTYINT fut_data ;

  fut_data.spotdate = spotdate;
  fut_data.matur = matur;
  fut_data.spot = spot;
  fut_data.futp = futp;
  fut_data.dfp = dfp;
  fut_data.fute = fute;
  fut_data.dfrepo = dfrepo;
  fut_data.holi = holi;
  fut_data.shock = shock;

  return fut_data ;
}

/*
..
*/

void FutEqty_GetFUTEQTYINT(FUTEQTYINT*   fut_data,
                              DATESTR**      spotdate,
                              DATESTR**      matur,
                              FL64*          spot,
                              FL64*          futp,
                              DFPARMS**      dfp,
                              FUTEQTY**      fute,
                              DISCFAC**      dfrepo,
                              HOLI_STR**     holi,
                              FL64*          shock) 
{
  *spotdate = fut_data->spotdate ;
  *matur = fut_data->matur ;
  *spot = fut_data->spot ;
  *futp = fut_data->futp ;
  *dfp = fut_data->dfp ;
  *fute = fut_data->fute ;
  *dfrepo = fut_data->dfrepo ;
  *holi = fut_data->holi ;
  *shock = fut_data->shock ;
}

/*
..
*/

BOOLE FutEqty_NewtonRaphson(FL64    x, 
                               void*   y,
                               BOOLE   grad,
                               FL64*   fx, 
                               FL64*   dfx,
							   void*   hol) 
{
  DATESTR  *spotdate, *matur ;
  FL64     spot, futp, shock, fx1, x1 ;
  DFPARMS  *dfp ;
  FUTEQTY  *fute ;
  DISCFAC  *dfrepo ;
  HOLI_STR *holi = (HOLI_STR *)hol;   /* PMSTA-29444 - SRIDHARA - 050318 */

  /* Get data from y */
  FutEqty_GetFUTEQTYINT((FUTEQTYINT*)y, &spotdate, &matur, 
    &spot, &futp, &dfp, &fute, &dfrepo, &holi, &shock);
  shock = (shock <= 0.0 ? 0.01 : shock) ;

  /* Compute fx */
  *dfrepo = Disc_TS2DF(spotdate, matur, &x, 1, dfp, holi); 	/* PMSTA-22396 - SRIDHARA � 160502 */
  *fx  = FutEqty_CC2Price(spotdate, spot, fute, 0.0,
    dfrepo, holi) - futp ;
  Free_PLANARRAY(dfrepo->disc, 1) ;

  /* Compute gradient */
  if (grad == True)
  {
    x1 = x + shock ;
	*dfrepo = Disc_TS2DF(spotdate, matur, &x1, 1, dfp, holi); 	/* PMSTA-22396 - SRIDHARA � 160502 */
    fx1  = FutEqty_CC2Price(spotdate, spot, fute, 0.0,
      dfrepo, holi) - futp ;
    Free_PLANARRAY(dfrepo->disc, 1) ;

    *dfx = (fx1 - *fx) / shock ;
  }

  return True ;
}

/*,,SOH,,
*************************************************************************
*
*               Free_FUTEQTY()
*
*    interface  #include <futeqty.h>
*               void Free_FUTEQTY(FUTEQTY *fixp) ;
*
*    general    Free_FUTEQTY() frees memory for a FUTEQTY. All the
*               memory is suballocated in the fixp structure.
*
*    input      FUTEQTY     *fixp       The equity future data container
*
*    output
*
*    returns
*
*    diagnostics
*
*    see also
*
*************************************************************************
,,EOH,,*/


void Free_FUTEQTY(FUTEQTY* fixp)
{
    /* Free all suballocated memory */
    Free_PLANARRAY(fixp->div, 1);
}


/* @(#)sceneqty.c	1.5 (SimCorp) 99/02/19 14:14:50 */

/************************************************************************
*
*   project     SCecon
*
*   filename    sceneqty.c
*
*   contains    routines in the SCecon Library Scenario module
*
************************************************************************/
/***** list of to do's **************************************************
  TODO: ScenBPV for Fut instruments.
************************************************************************/


/***** includes ********************************************************/
#include <futeqty.h>
#include <opteqty.h>
#include <scenario.h>

/*,,SOH,,
*************************************************************************
*
*               OptFX_Black2ScenBPV()
*
*   interface   #include <opteqty.h>
*               FL64ARRAY OptFX_Black2ScenBPV(DATESTR  *analys,
*                                         DATESTR    *voldate,
*                                         FL64       vol,
*                                         FL64       fx_spot_opt,
*                                         FL64       fx_spot_home,
*                                         DATESTR    *spotdate,
*                                         OPTFUT     *opt,
*                                         DISCFAC    *df_d,
*                                         DISCFAC    *df_f,
*                                         HOLI_STR   *holi,
*                                         DELTASET   *ds_d,
*                                         DELTASET   *ds_f,
*                                         FXSHOCKSET *fxs_opt,
*                                         FXSHOCKSET *fxs_home);
*
*   general     The routine calculates the vector of scenario BPV's for
*               an FX option using a list of predefined shocks to the
*               zero coupon curve and a list of predefined FX shocks.
*               Each zero coupon curve shock corresponds to a single
*               FX shock.
*
*               The scenario BPV represents the price differences
*               invoked by the curve shocks between the shocked PV's
*               and the initial PV.
*
*               It is required that the number of zero coupon curve
*               shocks match the number of FX shocks, ie.
*
*                fxs->nshock == ds_cflw->nshock == ds_disc->nshock
*
*               However, fxs may be set to NULL, in which case FX
*               shocking is ignored and fx_spot is used for all PV
*               calculations.
*
*               Scenarios may be used for evaluation of
*               - Randomly chosen curve/fx shocks,
*               - Historical scenarios/simulation,
*               - Expert scenarios,
*               - Worst case analysis, etc.
*
*               Refer to OptFX_Black2P() for pricing model description.
*
*   input       DATESTR    *analys      The analysis date.
*
*               DATESTR    *voldate     Vol calculated from this date
*
*               FL64      vol           The annual volatility of the FX
*                                       forward price in percent.
*
*               FL64      fx_spot_opt   Spot exchange rate for the
*                                       option premium currency. Price
*                                       in domestic currency of foreign
*                                       currency units.
*                                       The initial (unshocked) rate
*
*               FL64      fx_spot_home  Spot exchange rate for the
*                                       home/report currency. Price
*                                       in home currency of domestic
*                                       currency units.
*                                       The initial (unshocked) rate
*
*               DATESTR   *spotdate     The date for fx_spot
*
*               OPTFUT    *opt          The data defining the option.
*
*               DISCFAC   *df_d         Domestic discount function
*                                       For CALL - PUT CCY Curve
*                                       For PUT  - CALL CCY Curve
*
*               DISCFAC   *df_f         Foreign discount function
*                                       For CALL - CALL CCY Curve
*                                       For PUT  - PUT CCY Curve
*
*               HOLI_STR   *holi        Business day adjustment setup.
*
*               DELTASET   *ds_d        Curve shock definitions for
*                                       the the curve in df_d.
*
*               DELTASET   *ds_f        Curve shock definitions for
*                                       the the curve in df_f.
*
*               FXSHOCKSET *fxs_opt     FX shock definitions for the
*                                       'fx_spot_opt' rate.
*
*               FXSHOCKSET *fxs_home    FX shock definitions for the
*                                       'fx_spot_home' rate.
*
*   output
*
*   returns     The vector of scenario BPV as:
*
*                         Alloc_FL64ARRAY(ds->nshock) ;
*
*   diagnostics
*
*   see also    Disc_ScenarioPrep()
*               SwapFl_DF2ScenBPV()
*               Cap_Black2ScenBPV()
*
*************************************************************************
,,EOH,,*/

FL64ARRAY OptFX_Black2ScenBPV(DATESTR* analys,
                          DATESTR*    voldate, 
                          FL64       vol,      
                          FL64       fx_spot_opt,
                          FL64       fx_spot_home,
                          DATESTR*    spotdate,
                          OPTFUT*     opt,     
                          DISCFAC*    df_d,    
                          DISCFAC*    df_f,    
                          HOLI_STR*   holi,    
                          DELTASET*   ds_d,    
                          DELTASET*   ds_f,    
                          FXSHOCKSET* fxs_opt,
                          FXSHOCKSET* fxs_home)
{
    INTI      i, fx_opt_size, fx_home_size ;
    FL64ARRAY dv ;
    FL64      p0, dum, pShock, bpv ;
    PLANARRAY old_f, old_d ;
    BOOLE noFx_opt, noFx_home;

    dv = NULL;

    if (FXSHOCKSET_IsEmpty(fxs_opt))
    {
      noFx_opt = True;
      fx_opt_size = 0;
    }
    else
    {
      fx_opt_size = fxs_opt->nshock;
      noFx_opt = False;
    }

    if (FXSHOCKSET_IsEmpty(fxs_home))
    {
      noFx_home = True;
      fx_home_size = 0;
    }
    else
    {
      fx_home_size = fxs_home->nshock;
      noFx_home = False;
    }

    if (ds_d->nshock == ds_f->nshock && 
        (noFx_opt || ds_f->nshock == fx_opt_size) &&
        (noFx_home || ds_f->nshock == fx_home_size) &&
        (noFx_opt || noFx_home || fx_opt_size == fx_home_size))
    {
        /* Initialise */
        dv        = Alloc_FL64ARRAY(ds_f->nshock) ;
        old_f  = df_f->disc ;
        old_d  = df_d->disc ;

        /* The unshocked price */
        p0 = OptFX_Black2P(analys, voldate, vol, fx_spot_opt, spotdate, 
                opt, df_d, df_f, holi, NULL, &dum, &dum) ;

        for (i = 0; i < ds_f->nshock; i++)
        {
            df_f->disc = &ds_f->shock[i];
            df_d->disc = &ds_d->shock[i];

            if (noFx_opt)
                pShock = OptFX_Black2P(analys, voldate, vol, 
                    fx_spot_opt, spotdate, opt, df_d, df_f, holi, 
                    NULL, &dum, &dum) ;
            else
                pShock = OptFX_Black2P(analys, voldate, vol, 
                    fxs_opt->shocked[i], spotdate, opt, df_d, df_f, 
                    holi, NULL, &dum, &dum) ;

            if (noFx_home)
              bpv = pShock - p0;
            else
              bpv = pShock * fxs_home->shocked[i] - p0 * fx_spot_home;

            dv[i] = bpv;
        }

        df_d->disc = old_d;
        df_f->disc = old_f;
    }

    return dv ;
}



/*,,SOH,,
*************************************************************************
*
*               OptFutFX_Black2ScenBPV()
*
*   interface   #include <opteqty.h>
*               FL64ARRAY OptFutFX_Black2ScenBPV(DATESTR  *analys,
*                                         DATESTR    *voldate,
*                                         FL64       vol,
*                                         FL64       fx_spot_opt,
*                                         FL64       fx_spot_home,
*                                         DATESTR    *spotdate,
*                                         OPTFUT     *opt,
*                                         DISCFAC    *df_d,
*                                         DISCFAC    *df_f,
*                                         HOLI_STR   *holi,
*                                         DELTASET   *ds_d,
*                                         DELTASET   *ds_f,
*                                         FXSHOCKSET *fxs_opt,
*                                         FXSHOCKSET *fxs_home);
*
*   general     The routine calculates the vector of scenario BPV's for
*               an FX option using a list of predefined shocks to the
*               zero coupon curve and a list of predefined FX shocks.
*               Each zero coupon curve shock corresponds to a single
*               FX shock.
*
*               The scenario BPV represents the price differences
*               invoked by the curve shocks between the shocked PV's
*               and the initial PV.
*
*               It is required that the number of zero coupon curve
*               shocks match the number of FX shocks, ie.
*
*                fxs->nshock == ds_cflw->nshock == ds_disc->nshock
*
*               However, fxs may be set to NULL, in which case FX
*               shocking is ignored and fx_spot is used for all PV
*               calculations.
*
*               Scenarios may be used for evaluation of
*               - Randomly chosen curve/fx shocks,
*               - Historical scenarios/simulation,
*               - Expert scenarios,
*               - Worst case analysis, etc.
*
*               Refer to OptFX_Black2P() for pricing model
*               description.
*
*   input       DATESTR    *analys      The analysis date.
*
*               DATESTR    *voldate     Vol calculated from this date
*
*               FL64      vol           The annual volatility of the FX
*                                       forward price in percent.
*
*               FL64      fx_spot_opt   Spot exchange rate for the
*                                       option premium currency. Price
*                                       in domestic currency of foreign
*                                       currency units.
*                                       The initial (unshocked) rate
*
*               FL64      fx_spot_home  Spot exchange rate for the
*                                       home/report currency. Price
*                                       in home currency of domestic
*                                       currency units.
*                                       The initial (unshocked) rate
*
*               DATESTR   *spotdate     The date for fx_spot
*
*               OPTFUT    *opt          The data defining the option.
*
*               DISCFAC   *df_d         Domestic discount function
*                                       For CALL - PUT CCY Curve
*                                       For PUT  - CALL CCY Curve
*
*               DISCFAC   *df_f         Foreign discount function
*                                       For CALL - CALL CCY Curve
*                                       For PUT  - PUT CCY Curve
*
*               HOLI_STR   *holi        Business day adjustment setup.
*
*               DELTASET   *ds_d        Curve shock definitions for
*                                       the the curve in df_d.
*
*               DELTASET   *ds_f        Curve shock definitions for
*                                       the the curve in df_f.
*
*               FXSHOCKSET *fxs_opt     FX shock definitions for the
*                                       'fx_spot_opt' rate.
*
*               FXSHOCKSET *fxs_home    FX shock definitions for the
*                                       'fx_spot_home' rate.
*
*   output
*
*   returns     The vector of scenario BPV as:
*
*                         Alloc_FL64ARRAY(ds->nshock) ;
*
*   diagnostics
*
*   see also    Disc_ScenarioPrep()
*               OptFX_Black2ScenBPV()
*
*************************************************************************
,,EOH,,*/

FL64ARRAY OptFutFX_Black2ScenBPV(DATESTR* analys,
                          DATESTR*    voldate, 
                          FL64       vol,      
                          FL64       fx_spot_opt,
                          FL64       fx_spot_home,
                          DATESTR*    spotdate,
                          OPTFUT*     opt,     
                          DISCFAC*    df_d,    
                          DISCFAC*    df_f,    
                          HOLI_STR*   holi,    
                          DELTASET*   ds_d,    
                          DELTASET*   ds_f,    
                          FXSHOCKSET* fxs_opt,
                          FXSHOCKSET* fxs_home)
{
    return OptFX_Black2ScenBPV(analys, voldate, vol, fx_spot_opt,
        fx_spot_home, spotdate, opt, df_d, df_f, holi, ds_d, ds_f, 
        fxs_opt, fxs_home);

}


/*,,SOH,,
*************************************************************************
*
*               OptFutEqty_Black2ScenBPV()
*
*   interface   #include <opteqty.h>
*               FL64ARRAY OptFutEqty_Black2ScenBPV(DATESTR   *analys,
*                                                  DATESTR   *voldate,
*                                                  DATESTR   *spotdate,
*                                                  FL64      spot,
*                                                  FL64      vol,
*                                                  FL64      fx_spot,
*                                                  FL64      divyld,
*                                                  FUTEQTY   *fute,
*                                                  OPTFUT    *opt,
*                                                  DISCFAC   *df,
*                                                  HOLI_STR  *holi,
*                                                  DELTASET  *ds,
*                                                 FXSHOCKSET *fxs,
*                                                 EQTYSHOCKSET *eqtys);
*
*   general     The routine calculates the vector of scenario BPV's for
*               a equity future option using a list of predefined
*               shocks to the zero coupon curve and a list of
*               predefined FX shocks.
*               Each zero coupon curve shock corresponds to a single
*               FX shock.
*
*               The scenario BPV represents the price differences
*               invoked by the curve shocks between the shocked PV's
*               and the initial PV.
*
*               It is required that the number of zero coupon curve
*               shocks match the number of FX shocks and the number of
*               equity shocks, ie.
*
*                     eqtys->nshock == fxs->nshock == ds->nshock
*
*               However, fxs and/or eqtys may be set to NULL, in which
*               case FX and/or equity shocking is ignored. If fxs is
*               NULL the scenario BPV are calculated  in instrument
*               ccys only. Otherwise BPV's are in domestic (home ccy).
*               If eqtys is NULL spot is used in all PV calculations.
*
*               Scenarios may be used for evaluation of
*               - Randomly chosen curve/fx shocks/equity shocks,
*               - Historical scenarios/simulation,
*               - Expert scenarios,
*               - Worst case analysis, etc.
*
*               Refer to OptFutEqty_Black2DFp() for pricing model
*               description.
*
*    input      DATESTR    *analys    Pointer to analysis date
*                                     (NPV date).
*
*               DATESTR    *voldate   Vol calculated from this date.
*
*               DATESTR    *spotdate  The date on which spot is quoted
*
*               FL64       spot       The spot price.
*                                     Must not be preADJUSTED for
*                                     dividends at entry.
*
*               FL64       vol        The annual volatility of the Spot
*                                     price in percent.
*
*               FL64       fx_spot    Spot exchange rate. Price in
*                                     domestic currency of foreign
*                                     currency units.
*                                     The initial (unshocked) rate.
*
*               FL64       divyld     Dividend yield (continuous rate
*                                     in %).
*
*               FUTEQTY    *fute      Equity data
*
*               OPTFUT     *opt       The data defining the option.
*
*               DISCFAC    *df        Discount function for discounting
*                                     the option payout.
*
*               HOLI_STR   *holi      Holiday adjustment rules
*
*               DELTASET   *ds        Curve shock definitions.
*
*               FXSHOCKSET *fxs       FX shock definitions.
*
*               EQTYSHOCKSET *eqtys   Equity shock definitions.
*
*   output
*
*   returns     The vector of scenario BPV as:
*
*                         Alloc_FL64ARRAY(ds->nshock) ;
*
*   diagnostics
*
*   see also    Disc_ScenarioPrep()
*               OptFutEqty_Black2DFp()
*               OptFutEqty_Black2Delta()
*               OptEqty_Black2ScenBPV()
*
*************************************************************************
,,EOH,,*/

FL64ARRAY OptFutEqty_Black2ScenBPV(DATESTR* analys,
                              DATESTR*  voldate, 
                              DATESTR*  spotdate,
                              FL64     spot,     
                              FL64     vol,      
                              FL64     fx_spot,
                              FL64     divyld,   
                              FUTEQTY*  fute,    
                              OPTFUT*   opt,     
                              DISCFAC*  df,      
                              HOLI_STR* holi,    
                              DELTASET*   ds,    
                              FXSHOCKSET* fxs,
                              EQTYSHOCKSET* eqtys)
{
    FL64ARRAY dv;
    INTI      size, i;
    FL64      p0, pShock, bpv, dum, spotshock;
    BOOLE     fx_IsEmpty, spot_IsEmpty ;
    PLANARRAY old ;

    dv = NULL;

    fx_IsEmpty   = FXSHOCKSET_IsEmpty(fxs) ;
    spot_IsEmpty = EQTYSHOCKSET_IsEmpty(eqtys) ;

    /* No FX and EQTY shocks */
    if (fx_IsEmpty && spot_IsEmpty)
        dv = OptFutEqty_Black2Delta(analys, voldate, spotdate, spot, vol, 
                                    divyld, fute, opt, df, holi, ds);

    /* FX and/or EQTY shocks */
    else if ( (ds->nshock == fxs->nshock && ds->nshock == eqtys->nshock) ||
              (ds->nshock == fxs->nshock && spot_IsEmpty)  ||
              (ds->nshock == eqtys->nshock && fx_IsEmpty) )
    {
        size = ds->nshock;

        p0 = OptFutEqty_Black2DFp(analys, voldate, spotdate, spot, vol, opt,
                                  fute, divyld, df, holi, NULL, &dum, &dum) ;

        old = df->disc ;
        dv = Alloc_FL64ARRAY(size) ;
        
        for(i = 0; i < size; i++)
        {
            /* Shocked spot price */
            spotshock = (spot_IsEmpty ? spot : eqtys->shocked[i]) ;
            
            df->disc = &ds->shock[i] ;
            
            /* Shocked price */
            pShock = OptFutEqty_Black2DFp(analys, voldate, spotdate, spotshock,
                                          vol, opt, fute, divyld, df, holi,
                                          NULL, &dum, &dum) ;
            
            if (fx_IsEmpty)
                bpv = pShock - p0;
            else
                bpv = pShock * fxs->shocked[i] - p0 * fx_spot;
            
            dv[i] = bpv;
        }

        df->disc = old ;
    
    }

    return dv; 
}




/*,,SOH,,
*************************************************************************
*
*               OptEqty_Black2ScenBPV()
*
*   interface   #include <opteqty.h>
*               FL64ARRAY OptEqty_Black2ScenBPV(DATESTR      *analys,
*                                               DATESTR      *voldate,
*                                               FL64         spot,
*                                               FL64         vol,
*                                               FL64         fx_spot,
*                                               FL64         divyld,
*                                               FUTEQTY      *fute,
*                                               OPTFUT       *opt,
*                                               DISCFAC      *df,
*                                               HOLI_STR     *holi,
*                                               DELTASET     *ds,
*                                               FXSHOCKSET   *fxs,
*                                               EQTYSHOCKSET *eqtys);
*
*   general     The routine calculates the vector of scenario BPV's for
*               a equity ure option using a list of predefined
*               shocks to the zero coupon curve, a list of predefined
*               FX shocks, and a list of predefined equity shocks.
*               Each zero coupon curve shock corresponds to a single
*               FX shock and equity shock.
*
*               The scenario BPV represents the price differences
*               invoked by the curve shocks between the shocked PV's
*               and the initial PV.
*
*               It is required that the number of zero coupon curve
*               shocks match the number of FX shocks and the number of
*               equity shocks, ie.
*
*                     eqtys->nshock == fxs->nshock == ds->nshock
*
*               However, fxs and/or eqtys may be set to NULL, in which
*               case FX and/or equity shocking is ignored. If fxs is
*               NULL the scenario BPV are calculated  in instrument
*               ccys only. Otherwise BPV's are in domestic (home ccy).
*               If eqtys is NULL spot is used in all PV calculations.
*
*               Scenarios may be used for evaluation of
*               - Randomly chosen curve/fx shocks/equity shocks,
*               - Historical scenarios/simulation,
*               - Expert scenarios,
*               - Worst case analysis, etc.
*
*               Refer to OptEqty_Black2P() for pricing model
*               description.
*
*    input      DATESTR    *analys    Pointer to analysis date
*                                     (NPV date).
*
*               DATESTR    *voldate   Vol calculated from this date.
*
*               FL64       spot       The spot price.
*                                     Must not be preADJUSTED for
*                                     dividends at entry.
*
*               FL64       vol        The annual volatility of the Spot
*                                     price in percent.
*
*               FL64       fx_spot    Spot exchange rate. Price in
*                                     domestic currency of foreign
*                                     currency units.
*                                     The initial (unshocked) rate.
*
*               FL64       divyld     Dividend yield (continuous rate
*                                     in %).
*
*               FUTEQTY    *fute      Equity data
*
*               OPTFUT     *opt       The data defining the option.
*
*               DISCFAC    *df        Discount function for discounting
*                                     the option payout.
*
*               HOLI_STR   *holi      Holiday adjustment rules
*
*               DELTASET   *ds        Curve shock definitions.
*
*               FXSHOCKSET *fxs       FX shock definitions.
*
*               EQTYSHOCKSET *eqtys   Equity shock definitions.
*
*   output
*
*   returns     The vector of scenario BPV as:
*
*                         Alloc_FL64ARRAY(ds->nshock) ;
*
*   diagnostics
*
*   see also    Disc_ScenarioPrep()
*               OptEqty_Black2Delta()
*               OptFutEqty_Black2ScenBPV()
*
*************************************************************************
,,EOH,,*/

FL64ARRAY OptEqty_Black2ScenBPV(DATESTR*       analys,
                                    DATESTR*       voldate, 
                                    FL64           spot,     
                                    FL64           vol,      
                                    FL64           fx_spot,
                                    FL64           divyld,   
                                    FUTEQTY*       fute,    
                                    OPTFUT*        opt,     
                                    DISCFAC*       df,      
                                    HOLI_STR*      holi,    
                                    DELTASET*      ds,    
                                    FXSHOCKSET*    fxs,
                                    EQTYSHOCKSET*  eqtys)
{
    FL64ARRAY dv;
    INTI      size, i;
    FL64      p0, pShock, bpv, dum, spotshock ;
    PLANARRAY old ;
    BOOLE     fx_IsEmpty, spot_IsEmpty ;

    dv = NULL;

    fx_IsEmpty   = FXSHOCKSET_IsEmpty(fxs) ;
    spot_IsEmpty = EQTYSHOCKSET_IsEmpty(eqtys) ;

    /* No FX and EQTY shocks */
    if (fx_IsEmpty && spot_IsEmpty)
        dv = OptEqty_Black2Delta(analys, voldate, spot, vol, divyld, fute, 
                                 opt, df, holi, ds);
    /* FX and/or EQTY shocks */
    else if ( (ds->nshock == fxs->nshock && ds->nshock == eqtys->nshock) ||
              (ds->nshock == fxs->nshock && spot_IsEmpty)  ||
              (ds->nshock == eqtys->nshock && fx_IsEmpty) )
    {
        size = ds->nshock;

        /* The unshocked price */
        p0 = OptEqty_Black2P(analys, voldate, spot, vol, divyld, fute, opt, 
                             df, holi, NULL, &dum, &dum) ;
        
        old = df->disc ;
        dv = Alloc_FL64ARRAY(size) ;

        for(i = 0; i < size; i++)
        {
            /* Shocked spot price */
            spotshock = (spot_IsEmpty ? spot : eqtys->shocked[i]) ;
            
            df->disc = &ds->shock[i] ;
            
            /* Shocked price */
            pShock = OptEqty_Black2P(analys, voldate, spotshock, vol, divyld,
                                     fute, opt, df, holi, NULL, &dum, &dum) ;

            if (fx_IsEmpty)
                bpv = pShock - p0;
            else
                bpv = pShock * fxs->shocked[i] - p0 * fx_spot;

            dv[i] = bpv;
        }

        df->disc = old ;
    
    }

    return dv;
}






/*,,SOH,,
*************************************************************************
*
*               OptFX_CRR2ScenBPV()
*
*   interface   #include <opteqty.h>
*               FL64ARRAY OptFX_CRR2ScenBPV(DATESTR  *analys,
*                                         FL64       vol,
*                                         FL64       fx_spot_opt,
*                                         FL64       fx_spot_home,
*                                         INTI       nstep,
*                                         TREEOPT    *opt,
*                                         DISCFAC    *df_d,
*                                         DISCFAC    *df_f,
*                                         HOLI_STR   *holi,
*                                         DELTASET   *ds_d,
*                                         DELTASET   *ds_f,
*                                         FXSHOCKSET *fxs_opt,
*                                         FXSHOCKSET *fxs_home,
*                                         BOOLE      *ok);
*
*   general     The routine calculates the vector of scenario BPV's for
*               an FX option using a list of predefined shocks to the
*               zero coupon curve and a list of predefined FX shocks.
*               Each zero coupon curve shock corresponds to a single
*               FX shock.
*
*               The scenario BPV represents the price differences
*               invoked by the curve shocks between the shocked PV's
*               and the initial PV.
*
*               It is required that the number of zero coupon curve
*               shocks match the number of FX shocks, ie.
*
*                fxs->nshock == ds_cflw->nshock == ds_disc->nshock
*
*               However, fxs may be set to NULL, in which case FX
*               shocking is ignored and fx_spot is used for all PV
*               calculations.
*
*               Scenarios may be used for evaluation of
*               - Randomly chosen curve/fx shocks,
*               - Historical scenarios/simulation,
*               - Expert scenarios,
*               - Worst case analysis, etc.
*
*               Refer to OptFX_CRR2P() for pricing model description.
*
*   input       DATESTR    *analys      The analysis date.
*
*               FL64      vol           The annual volatility of the FX
*                                       forward price in percent.
*
*               FL64      fx_spot_opt   Spot exchange rate for the
*                                       option premium currency. Price
*                                       in domestic currency of foreign
*                                       currency units.
*                                       The initial (unshocked) rate
*
*               FL64      fx_spot_home  Spot exchange rate for the
*                                       home/report currency. Price
*                                       in home currency of domestic
*                                       currency units.
*                                       The initial (unshocked) rate
*
*               INTI      nstep         Number of steps in the Binomial
*                                       Tree.
*
*               TREEOPT   *opt          The data defining the option.
*                                       opt->berm assumed as False.
*
*               DISCFAC   *df_d         Domestic discount function
*                                       For CALL - PUT CCY Curve
*                                       For PUT  - CALL CCY Curve
*
*               DISCFAC   *df_f         Foreign discount function
*                                       For CALL - CALL CCY Curve
*                                       For PUT  - PUT CCY Curve
*
*               HOLI_STR   *holi        Business day adjustment setup.
*
*               DELTASET   *ds_d        Curve shock definitions for
*                                       the the curve in df_d.
*
*               DELTASET   *ds_f        Curve shock definitions for
*                                       the the curve in df_f.
*
*               FXSHOCKSET *fxs_opt     FX shock definitions for the
*                                       'fx_spot_opt' rate.
*
*               FXSHOCKSET *fxs_home    FX shock definitions for the
*                                       'fx_spot_home' rate.
*
*   output      BOOLE      *ok          True if all ok , False if not.
*
*   returns     The vector of scenario BPV as:
*
*                         Alloc_FL64ARRAY(ds->nshock) ;
*
*   diagnostics
*
*   see also    Disc_ScenarioPrep()
*               OptFX_Black2ScenBPV()
*               OptEqty_CRR2ScenBPV()
*
*************************************************************************
,,EOH,,*/

FL64ARRAY OptFX_CRR2ScenBPV(DATESTR* analys,
                          FL64       vol,    
                          FL64       fx_spot_opt,
                          FL64       fx_spot_home,
                          INTI       nstep,  
                          TREEOPT*    opt,   
                          DISCFAC*    df_d,    
                          DISCFAC*    df_f,    
                          HOLI_STR*   holi,    
                          DELTASET*   ds_d,    
                          DELTASET*   ds_f,    
                          FXSHOCKSET* fxs_opt,
                          FXSHOCKSET* fxs_home,
                          BOOLE*      ok)
{
    INTI      i, fx_opt_size, fx_home_size ;
    FL64ARRAY dv ;
    FL64      p0, dum, pShock, bpv ;
    PLANARRAY old_f, old_d ;
    BOOLE noFx_opt, noFx_home;

    dv = NULL;

    if (FXSHOCKSET_IsEmpty(fxs_opt))
    {
      noFx_opt = True;
      fx_opt_size = 0;
    }
    else
    {
      fx_opt_size = fxs_opt->nshock;
      noFx_opt = False;
    }

    if (FXSHOCKSET_IsEmpty(fxs_home))
    {
      noFx_home = True;
      fx_home_size = 0;
    }
    else
    {
      fx_home_size = fxs_home->nshock;
      noFx_home = False;
    }

    if (ds_d->nshock == ds_f->nshock && 
        (noFx_opt || ds_f->nshock == fx_opt_size) &&
        (noFx_home || ds_f->nshock == fx_home_size) &&
        (noFx_opt || noFx_home || fx_opt_size == fx_home_size))
    {
        /* Initialise */
        dv        = Alloc_FL64ARRAY(ds_f->nshock) ;
        old_f  = df_f->disc ;
        old_d  = df_d->disc ;

        /* The unshocked price */
        *ok = OptFX_CRR2P(analys, fx_spot_opt, vol, nstep, opt, df_d, 
                df_f, holi, NULL, &p0, &dum, &dum);

        for (i = 0; i < ds_f->nshock && *ok; i++)
        {
            df_f->disc = &ds_f->shock[i];
            df_d->disc = &ds_d->shock[i];

            if (noFx_opt)
                *ok = OptFX_CRR2P(analys, fx_spot_opt, vol, nstep, opt, 
                    df_d, df_f, holi, NULL, &pShock, &dum, &dum);
            else
                *ok = OptFX_CRR2P(analys, fxs_opt->shocked[i], vol, 
                    nstep, opt, df_d, df_f, holi, NULL, &pShock, 
                    &dum, &dum);

            if (noFx_home)
              bpv = pShock - p0;
            else
              bpv = pShock * fxs_home->shocked[i] - p0 * fx_spot_home;

            dv[i] = bpv;
        }

        df_d->disc = old_d;
        df_f->disc = old_f;
    }

    return dv ;
}



/*,,SOH,,
*************************************************************************
*
*               OptEqty_CRR2ScenBPV()
*
*   interface   #include <opteqty.h>
*               FL64ARRAY OptEqty_CRR2ScenBPV(DATESTR      *analys,
*                                             FL64         spot,
*                                             FL64         vol,
*                                             FL64         fx_spot,
*                                             FUTEQTY      *fute,
*                                             INTI         nstep,
*                                             TREEOPT      *opt,
*                                             DISCFAC      *df,
*                                             DISCFAC      *divdf,
*                                             HOLI_STR     *holi,
*                                             DELTASET     *ds,
*                                             FXSHOCKSET   *fxs,
*                                             EQTYSHOCKSET *eqtys,
*                                             BOOLE        *ok) ;
*
*   general     The routine calculates the vector of scenario BPV's for
*               a equity ure option using a list of predefined shocks
*               to the zero coupon curve, a list of predefined FX
*               shocks, and a list of predifined spot shocks.
*               Each zero coupon curve shock corresponds to a single
*               FX shock and a spot shock.
*
*               The scenario BPV represents the price differences
*               invoked by the curve shocks between the shocked PV's
*               and the initial PV.
*
*               It is required that the number of zero coupon curve
*               shocks match the number of FX shocks and the number of
*               equity shocks, ie.
*
*                     eqtys->nshock == fxs->nshock == ds->nshock
*
*               However, fxs and/or eqtys may be set to NULL, in which
*               case FX and/or equity shocking is ignored. If fxs is
*               NULL the scenario BPV are calculated  in instrument
*               ccys only. Otherwise BPV's are in domestic (home ccy).
*               If eqtys is NULL spot is used in all PV calculations.
*
*               Scenarios may be used for evaluation of
*               - Randomly chosen curve/fx shocks/equity shocks,
*               - Historical scenarios/simulation,
*               - Expert scenarios,
*               - Worst case analysis, etc.
*
*               Refer to OptEqty_CRR2P() for pricing model
*               description.
*
*    input      DATESTR    *analys    Pointer to analysis date
*                                     (NPV date).
*
*               FL64       spot       The spot price.
*                                     Must not be preADJUSTED for
*                                     dividends at entry.
*
*               FL64       vol        The annual volatility of the Spot
*                                     price in percent.
*
*               FL64       fx_spot    Spot exchange rate. Price in
*                                     domestic currency of foreign
*                                     currency units.
*                                     The initial (unshocked) rate.
*
*               FUTEQTY    *fute      Equity data
*
*               INTI       nstep      Number of steps in the Binomial
*                                     Tree.
*
*               TREEOPT    *opt       The data defining the option.
*                                     opt->berm assumed as False.
*
*               DISCFAC    *df        Discount function for discounting
*                                     the option payout.
*
*               DISCFAC    *divdf     Term structure of dividend yields
*
*               HOLI_STR   *holi      Holiday adjustment rules
*
*               DELTASET   *ds        Curve shock definitions.
*
*               FXSHOCKSET *fxs       FX shock definitions.
*
*               EQTYSHOCKSET *eqtys   Equity shock definitions.
*
*   output      BOOLE      *ok        True if all ok, False if not.
*
*   returns     The vector of scenario BPV as:
*
*                         Alloc_FL64ARRAY(ds->nshock) ;
*
*   diagnostics
*
*   see also    Disc_ScenarioPrep()
*               OptEqty_CRR2P()
*               OptEqty_CRR2Delta()
*               OptFX_CRR2ScenBPV()
*
*************************************************************************
,,EOH,,*/

FL64ARRAY OptEqty_CRR2ScenBPV(DATESTR*       analys,
                                  FL64           spot,      
                                  FL64           vol,       
                                  FL64           fx_spot,
                                  FUTEQTY*       fute,  
                                  INTI           nstep,     
                                  TREEOPT*       opt,      
                                  DISCFAC*       df,       
                                  DISCFAC*       divdf,
                                  HOLI_STR*      holi,     
                                  DELTASET*      ds,  
                                  FXSHOCKSET*    fxs,
                                  EQTYSHOCKSET*  eqtys,
                                  BOOLE*         ok)
{
    FL64ARRAY dv;
    INTI      size, i;
    FL64      p0, pShock, bpv, dum, spotshock;
    BOOLE     dsdomold, fx_IsEmpty, spot_IsEmpty;
    PLANARRAY old ;

    dv = NULL;
    dsdomold = ds->dom;

    ds->dom = True;

    fx_IsEmpty   = FXSHOCKSET_IsEmpty(fxs) ;
    spot_IsEmpty = EQTYSHOCKSET_IsEmpty(eqtys) ;

    /* No FX and EQTY shocks */
    if (fx_IsEmpty && spot_IsEmpty)
        dv = OptEqty_CRR2Delta(analys, spot, vol, nstep, divdf, fute, opt, df,
                               holi, ds, ok);
    /* FX and/or EQTY shocks */
    else if ( (ds->nshock == fxs->nshock && ds->nshock == eqtys->nshock) ||
              (ds->nshock == fxs->nshock && spot_IsEmpty)  ||
              (ds->nshock == eqtys->nshock && fx_IsEmpty) )
    {
        size = ds->nshock;

        /* The unshocked price */
        *ok = OptEqty_CRR2P(analys, spot, vol, nstep, divdf, fute, opt, df, 
                            holi, NULL, &p0, &dum, &dum) ;

        old = df->disc ;
        dv = Alloc_FL64ARRAY(size) ;

        for(i = 0; i < size && *ok == True; i++)
        {
            /* Shocked spot price */
            spotshock = (spot_IsEmpty ? spot : eqtys->shocked[i]) ;
            
            df->disc = &ds->shock[i] ;

            /* Shocked price */
            *ok = OptEqty_CRR2P(analys, spotshock, vol, nstep, divdf, fute, 
                                opt, df, holi, NULL, &pShock, &dum, &dum) ;

            if (fx_IsEmpty)
                bpv = pShock - p0;
            else
                bpv = pShock * fxs->shocked[i] - p0 * fx_spot;
            
            dv[i] = bpv;
        }

        df->disc = old ;

    }
    ds->dom = dsdomold;

    return dv;
}



/*,,SOH,,
*************************************************************************
*
*               FutEqty_CC2ScenBPV()
*
*   interface   #include <opteqty.h>
*               FL64ARRAY FutEqty_CC2ScenBPV(DATESTR      *analys,
*                                            DATESTR      *spotdate,
*                                            FL64         spot,
*                                            FL64         fx_spot,
*                                            FL64         divyld,
*                                            FUTEQTY      *fute,
*                                            DISCFAC      *df,
*                                            HOLI_STR     *holi,
*                                            DELTASET     *ds,
*                                            FXSHOCKSET   *fxs,
*                                            EQTYSHOCKSET *eqtys);
*
*   general     The routine calculates the vector of scenario BPV's for
*               a equity future using a list of predefined
*               shocks to the zero coupon curve and a list of
*               predefined FX shocks.
*               Each zero coupon curve shock corresponds to a single
*               FX shock.
*
*               The scenario BPV represents the price differences
*               invoked by the curve shocks between the shocked PV's
*               and the initial PV.
*
*               It is required that the number of zero coupon curve
*               shocks match the number of FX shocks and the number of
*               equity shocks, ie.
*
*                     eqtys->nshock == fxs->nshock == ds->nshock
*
*               However, fxs and/or eqtys may be set to NULL, in which
*               case FX and/or equity shocking is ignored. If fxs is
*               NULL the scenario BPV are calculated  in instrument
*               ccys only. Otherwise BPV's are in domestic (home ccy).
*               If eqtys is NULL spot is used in all PV calculations.
*
*               Scenarios may be used for evaluation of
*               - Randomly chosen curve/fx shocks/equity shocks,
*               - Historical scenarios/simulation,
*               - Expert scenarios,
*               - Worst case analysis, etc.
*
*    input      DATESTR    *analys    Pointer to analysis date
*                                     (NPV date).
*
*               DATESTR    *spotdate  The date on which spot is quoted
*
*               FL64       spot       The spot price.
*                                     Must not be preADJUSTED for
*                                     dividends at entry.
*
*               FL64       fx_spot    Spot exchange rate. Price in
*                                     domestic currency of foreign
*                                     currency units.
*                                     The initial (unshocked) rate.
*
*               FL64       divyld     Dividend yield (continuous rate
*                                     in %).
*
*               FUTEQTY    *fute      Equity data
*
*               DISCFAC    *df        Discount factors.
*
*               HOLI_STR   *holi      Holiday adjustment rules
*
*               DELTASET   *ds        Curve shock definitions.
*
*               FXSHOCKSET *fxs       FX shock definitions.
*
*               EQTYSHOCKSET *eqtys   Equity shock definitions.
*
*   output
*
*   returns     The vector of scenario BPV as:
*
*                         Alloc_FL64ARRAY(ds->nshock) ;
*
*   diagnostics
*
*   see also    Disc_ScenarioPrep()
*               FutEqty_CC2Delta()
*
*************************************************************************
,,EOH,,*/

FL64ARRAY FutEqty_CC2ScenBPV(DATESTR*       analys,
                                 DATESTR*       spotdate,
                                 FL64           spot,
                                 FL64           fx_spot,
                                 FL64           divyld,   
                                 FUTEQTY*       fute,    
                                 DISCFAC*       df,      
                                 HOLI_STR*      holi,    
                                 DELTASET*      ds,    
                                 FXSHOCKSET*    fxs,
                                 EQTYSHOCKSET*  eqtys) 
{
    FL64ARRAY dv ;
    INTI      size, i ;
    FL64      bpv, spotshock, pShock, dum, p0 ;
    BOOLE     fx_IsEmpty, spot_IsEmpty ;
    PLANARRAY old ;

    dv = NULL;

    fx_IsEmpty   = FXSHOCKSET_IsEmpty(fxs) ;
    spot_IsEmpty = EQTYSHOCKSET_IsEmpty(eqtys) ;

    /* No FX and EQTY shocks */
    if (fx_IsEmpty && spot_IsEmpty)
        dv = FutEqty_CC2Delta(analys, spotdate, spot, fute, divyld, df, 
                              holi, ds) ;

    /* FX and/or EQTY shocks */
    else if ( (ds->nshock == fxs->nshock && ds->nshock == eqtys->nshock) ||
              (ds->nshock == fxs->nshock && spot_IsEmpty)  ||
              (ds->nshock == eqtys->nshock && fx_IsEmpty) )
    {
        size = ds->nshock;

        old = df->disc ;
        dv = Alloc_FL64ARRAY(size) ;

        /* The unshocked price */
        p0 = FutEqty_CC2NPV(analys, spotdate, spot, fute, divyld, df, holi,
                            NULL, &dum, &dum) ;

        for(i = 0; i < size; i++)
        {
            /* Shocked spot price */
            spotshock = (spot_IsEmpty ? spot : eqtys->shocked[i]) ;
            
            df->disc = &ds->shock[i] ;
            
            /* Shocked price */
            pShock = FutEqty_CC2NPV(analys, spotdate, spotshock, fute, divyld, 
                                    df, holi, NULL, &dum, &dum) ;

            if (fx_IsEmpty)
                bpv = pShock - p0;
            else
                bpv = pShock * fxs->shocked[i] - p0 * fx_spot ;
           
            dv[i] = bpv ;
        }

        df->disc = old ;
    
    } 

    return dv ;
}



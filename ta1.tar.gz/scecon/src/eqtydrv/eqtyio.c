/* SCID @(#)eqtyio.c	1.4 (SimCorp) 99/02/19 14:14:17 */

/************************************************************************
*
*   Project     SCecon
*
*   file name   eqtyio.c
*
*   general     This file contains file io functions
*
************************************************************************/

/* includes    *********************************************************/
#include <eqtyio.h>
#include <ioconv.h>
#include <eqtyval.h>
#include <bondio.h>
#include <optio.h>

/*
..
*/


FXFORW Read_FXFORW(FILE* in, FILE* out)
{
    FXFORW   fxfw ;
    YYYYMMDD ymd ;
    char     txb[25] ;
    COUNT    type ;

    fprintf(out, "   FXForw\n") ;

    type = Read_FormatId(in, out);

    switch (type)
    {
        case 1:

            fscanf(in, "%lf %s", &fxfw.fwd, txb) ;
            fxfw.inv = Str2BOOLE(txb) ;
            fprintf(out, "   Forward FX       %8lf\n", fxfw.fwd) ;
            fprintf(out, "   Inverse:         %8s\n", txb) ;

            fscanf(in, "%ld", &ymd) ;
            fxfw.matur = Cldr_YMD2Datestr((YYYYMMDD) ymd) ;
            fprintf(out, "   Maturity:        %8ld\n", ymd) ;

            fxfw.base   = 1.0 ;
            fxfw.margin = False ;
            fxfw.cal    = ACT360 ;

            break ;

        case 2:

            fscanf(in, "%lf %s", &fxfw.fwd, txb) ;
            fxfw.inv = Str2BOOLE(txb) ;
            fprintf(out, "   Forward FX       %8lf\n", fxfw.fwd) ;
            fprintf(out, "   Inverse:         %8s\n", txb) ;

            fscanf(in, "%lf", &fxfw.base) ;
            fprintf(out, "   Base:            %8lf\n", fxfw.base) ;

            fscanf(in, "%ld", &ymd) ;
            fxfw.matur = Cldr_YMD2Datestr((YYYYMMDD) ymd) ;
            fprintf(out, "   Maturity:        %8ld\n", ymd) ;

            fxfw.margin = False ;
            fxfw.cal    = ACT360 ;

            break ;

    }

    Write_VALIDATEError(out, Validate_FXFORW(&fxfw));

    return fxfw ;
}

/*
..
*/


FUTEQTY Read_FUTEQTY(FILE* in, FILE* out)
{
    FUTEQTY  fute ;
    YYYYMMDD ymd ;
    char     txb[25] ;
    COUNT type;

    fprintf(out, "   FutEqty\n") ;

    type = Read_FormatId(in, out);

    fute.futp   = 0.0 ;
    fute.margin = True ;

    switch (type)
    {
        case 1:
        case 2:

            fscanf(in, "%ld", &ymd) ;
            fute.matur = Cldr_YMD2Datestr((YYYYMMDD) ymd) ;
            fprintf(out, "   Maturity:        %8ld\n", ymd) ;

            fute.div = Read_PLANARRAY(in) ;
            fprintf(out, "   Dividends:\n") ;
            Write_PLANARRAY(out, fute.div) ;

            if (type == 2)
            {
                fscanf(in, "%s", txb) ;
                fute.cal = Str2CALCONV(txb) ;
                fprintf(out, "   Calendar:        %8s\n", txb) ;
            }
            else
                fute.cal= EU30E360 ;
            break ;

        case 3:

            fute.matur = Cldr_YMD2Datestr((YYYYMMDD) 0) ;

            fute.div = Read_PLANARRAY(in) ;
            fprintf(out, "   Dividends:\n") ;
            Write_PLANARRAY(out, fute.div) ;

            fute.cal= EU30E360 ;

            break ;

        case 4:

            fscanf(in, "%ld", &ymd) ;
            fute.matur = Cldr_YMD2Datestr((YYYYMMDD) ymd) ;
            fprintf(out, "   Maturity:        %8ld\n", ymd) ;

            fute.div = Read_PLANARRAY(in) ;
            fprintf(out, "   Dividends:\n") ;
            Write_PLANARRAY(out, fute.div) ;

            fscanf(in, "%s", txb) ;
            fute.cal = Str2CALCONV(txb) ;
            fprintf(out, "   Calendar:        %8s\n", txb) ;

            fscanf(in, "%lf", &fute.futp) ;
            fprintf(out, "   Futures Price:   %8lf\n", fute.futp) ;

            fscanf(in, "%s", txb) ;
            fute.margin = Str2BOOLE(txb) ;
            fprintf(out, "   Margining:       %8s\n", txb) ;

            break ;
    }

    Write_VALIDATEError(out, Validate_FUTEQTY(&fute));

    return fute ;
}


/*
..
*/


FUTCMDTY Read_FUTCMDTY(FILE* in, FILE* out)
{
    FUTCMDTY fute ;
    YYYYMMDD ymd ;
    char     txb[25] ;
    COUNT type;

    fprintf(out, "   FutCmdty\n") ;

    type = Read_FormatId(in, out);

    switch (type)
    {
        case 1:
        case 2:

            fscanf(in, "%ld", &ymd) ;
            fute.matur = Cldr_YMD2Datestr((YYYYMMDD) ymd) ;
            fprintf(out, "   Maturity:        %8ld\n", ymd) ;

            fute.cy = Read_PLANARRAY(in) ;
            fprintf(out, "   Convenience Yield:\n") ;
            Write_PLANARRAY(out, fute.cy) ;

            fute.stc = Read_PLANARRAY(in) ;
            fprintf(out, "   Storate Cost:\n") ;
            Write_PLANARRAY(out, fute.stc) ;

            if (type == 2)
            {
                fscanf(in, "%s", txb) ;
                fute.cal = Str2CALCONV(txb) ;
                fprintf(out, "   Calendar:        %8s\n", txb) ;
            }
            else
                fute.cal= EU30E360 ;

            break ;

        case 3:

            fute.matur = Cldr_YMD2Datestr((YYYYMMDD) 0) ;

            fute.cy = Read_PLANARRAY(in) ;
            fprintf(out, "   Convenience Yield:\n") ;
            Write_PLANARRAY(out, fute.cy) ;

            fute.stc = Read_PLANARRAY(in) ;
            fprintf(out, "   Storate Cost:\n") ;
            Write_PLANARRAY(out, fute.stc) ;

            fute.cal= EU30E360 ;


        break ;
    }

    Write_VALIDATEError(out, Validate_FUTCMDTY(&fute));

    return fute ;
}


/*
..
*/


TREEOPT Read_TREEOPT(FILE* in, FILE* out)
{
    TREEOPT  o ;

    fprintf(out,"   Option:\n") ;

    o.type      = Read_OPTTYPE(in, out, "   Type   ") ;
    o.strike    = Read_FL64(in, out, "   Strike   ") ;
    o.berm      = Read_BOOLE(in, out, "   Bermudan style?   ") ;
    o.dpay      = Read_PAYDAYDEF(in, out) ;
    o.pay_delay = Read_PERIOD(in) ;
    o.cal       = Read_CALCONV(in, out, "   Calendar   ") ;

    Write_VALIDATEError(out, Validate_TREEOPT(&o));
  
    return o ;
}



/* SCID @(#)disc.h	1.87 (SimCorp) 99/09/15 17:24:46 */

#ifndef DISC_H_INCLUDED

#define DISC_H_INCLUDED

/************************************************************************
*                                                                       *
*    project    SCecon                                                  *
*                                                                       *
*    filename   disc.h                                                  *
*                                                                       *
*    this file contains definitions and function prototyping for the    *
*    routines in the SCecon discount function module.                   *
*                                                                       *
************************************************************************/

/***** includes  *******************************************************/
#include <cldr.h>
#include <yld.h>


/***** C++ Convenience *************************************************/
#ifdef __cplusplus
extern "C" {
#endif


/*,,SOT,,

DISCIPOL : data type for setting discount factor interpolation variable
-----------------------------------------------------------------------

This type is used when interpolating in discount factors. It sets the
variable in which to interpolate.

In SCecon, the data type is defined as

        typedef enum discipol_tag
        {
            DI_SPOT,
            DI_DISC,
            DI_GROWTH,
            DI_FORW
        }   DISCIPOL ;

in disc.h of the SCecon.

DI_DISC indicates that interpolation is to be performed in the discount
factors.

DI_SPOT indicates that the spot (continuous) rates are to be used.

DI_GROWTH indicates that the inverse discount factors should be the variable
in which to interpolate.

DI_FORW is used when interpolation is performed in the forward rates.
Currently it is assumed that forward rates are CONSTANT between grid points.

Note that the enum sequence has been choosen so that False corresponds to
DI_SPOT and True to DI_DISC (this is not to say that we recommend coding
using this condition).

,,EOT,,*/

typedef enum discipol_tag
{
    DISCIPOL_INIT = -1,
    DI_SPOT,
    DI_DISC,
    DI_GROWTH,
    DI_FORW,
    DISCIPOL_WRONG_VALUE_7 = 7
}   DISCIPOL ;


/*,,SOT,,

DISCFAC and DISCFACARRAY : info on zero coupon discount factors
--------------------------------------------------------------------

This type is defined as:

        typedef struct
        {
            PLAN_STR   *disc ;
            DISCIPOL   what ;
            INTPOLCONV iconv ;
            CALCONV    cal ;
            IRRCONV    irr ;
            PMTFREQ    freq ;
        }   DISCFAC ;

The data have the following interpretation:

        disc is a pointer to the list of discount factors. disc->f64[0]
        always contains a 1.0. In this way the discount factors are anchored
        to a certain date. All discount factors in disc->f64 must be positive,
        and disc->filled >= 2, for proper use.
        This representation is currently the standard for holding zero-coupon
        term structures of interest rates.

        what informs on how interpolation is performed.

        iconv is the interpolation convention. 
        Can be LINEAR_EXTRAPOL, LINEAR_FLAT_END or CUBIC_SPLINE.
        Currently it is assumed that when interpolating in forward rates
        (DI_FORW) then the forward rates (of the specified duration) are
        CONSTANT between grid points.

        cal is the calendar convention used for interpolating in the dates.

        if what is DI_SPOT or DI_FORW then the type of spotrate in which to
        interpolate is determined by irr. Choose any of:

            COMPOUND
            SIMPLE_MM
            DISCOUNT
            US_TREASURY
            CONTINUOUS
            MOOSMULLER
            BRAESSFANGMEYER
            SIMPLE_REPO

        if irr is COMPOUND, MOOSMULLER or US_TREASURY then freq must also be
        supplied as a frequency representing the periodicity of the
        interest rate. Choose any of:

            ANNUALLY
            SEMIANNUALLY
            QUARTERLY
            FOURTHMONTHLY
            BIMONTHLY
            MONTHLY

NOTES:

        - If you want to implement a flat yield curve using a DISCFAC, then
          use Disc_TS2DF() to generate the DISCFAC, using a single interest
          rate point.

        - If you use DISCFAC's for true Zero Curves then use one of

            Boot_BSEC2DF()
            Fit_BSEC2DF()

          to generate the Zero Curve / DISCFAC.

        - When using SIMPLE_REPO use Disc_TS2DF() to generate to DF curve.
          Only use this convention when calculating bond futures/forwards 
          or repos (FutBond_CC2*() or RepoBond_*2*()).

        - If interpolating linearly in spot rates on a very sparse 
          discount function, eg. with more than 50 years between the grid 
          points, problems with negative forward rates may occur. Choosing
          DI_FORW instead will stabilise the discount factor interpolation.
        - Note that a calendar like EU30E360 will induce discontinuities,
          because the 30th and 31st of a month will get the same discount
          factor. To avoid this, use an ACT* calendar, eg. ACTACT.

see also Set_DISCFAC

,,EOT,,*/

typedef struct
{
    PLAN_STR   *disc ;
    DISCIPOL   what ;
    INTPOLCONV iconv ;
    CALCONV    cal ;
    IRRCONV    irr ;
    PMTFREQ    freq ;
}   DISCFAC ;
typedef DISCFAC * DISCFACARRAY ;


/*,,SOT,,

DFPARMS: Parameters for Discount Factor interpolation
-----------------------------------------------------

This type is defined as:

        typedef struct dfparms_tag
        {
            DISCIPOL   what ;
            INTPOLCONV iconv ;
            CALCONV    cal ;
            IRRCONV    irr ;
            PMTFREQ    freq ;
        }   DFPARMS ;

in disc.h

For detailed info on the data - see the type DISCFAC.

see also Set_DFPARMS

,,EOT,,*/

typedef struct dfparms_tag
{
    DISCIPOL   what ;
    INTPOLCONV iconv ;
    CALCONV    cal ;
    IRRCONV    irr ;
    PMTFREQ    freq ;
}   DFPARMS ;


/*,,SOT,,

RISKSET : data type for holding info on risk ratio calculation
--------------------------------------------------------------

This type is defined in as:

        typedef struct riskset_tag
        {
            KEYCONV  key ;
            RISKCONV risk ;
            FL64     shock ;
            IRRCONV  irr ;
            PMTFREQ  freq ;
            PLAN_STR *loads ;
            BOOLE    dom ;
        }   RISKSET ;

The type is used for defining risk ratios. The individual data
are to be interpreted as follws:

    key indicates which risk ratios to calculate. Currently the
        following choices are valid:

            KEY_DF for calculating delta and gammas with respect to changes
            in the Zero Yields. Consequently these ratios are equivalent to
            the dollar durations and dollar convexities

            KEY_BPV for defining price value of a basis point shift
            (average of up and down).

            KEY_REPO for defining sensitivities wrt the repo rate

            KEY_PRICE for calculating delta and gamma with respect to the
            underlying variable of the option - when this is a forward
            price. E.g. for caps this is the list of FRA (forward) rates.

            KEY_SPOT for calculating delta and gamma with respect to the
            underlying variable of the option - when this is a spot price.

            KEY_MATURITY for calculating theta of the option.

            KEY_STRIKE for calculating the sensitivities with respect to the
            strike rate(s).

            KEY_VOL for calculating vega of the option.

            KEY_A for calculating vega1 of the option.

            KEY_SIGMA for calculating vega2 of the option.

            KEY_PROB for calculating moneyness

            KEY_YTM for calculating ytm base $duration / convexity

    risk  indicates the risk ratio level.

    shock is the shock size defined as follows

            KEY_DF       - Percentage
            KEY_BPV      - Percentage
            KEY_REPO     - Percentage
            KEY_PRICE    - Percentage
            KEY_SPOT     - Percentage
            KEY_VOL      - Percentage
            KEY_STRIKE   - Percentage
            KEY_MATURITY - Days (entered as FL64)
            KEY_A        - Number
            KEY_SIGMA    - Number
            KEY_PROB     - Not used
            KEY_YTM      - Percentage

        if a shock of 0 or less is entered, then default values are invoked,
        these are

            KEY_DF       - 0.01
            KEY_BPV      - 0.01
            KEY_REPO     - 0.01
            KEY_PRICE    - 0.0001
            KEY_SPOT     - 0.0001
            KEY_VOL      - 1.0
            KEY_STRIKE   - 0.01
            KEY_MATURITY - 1 Day
            KEY_A        - 0.01
            KEY_SIGMA    - 0.0001
            KEY_PROB     - 0.0001
            KEY_YTM      - 0.01

    irr   is used with KEY_DF, KEY_BPV and KEY_REPO.
          irr indicates the IRRCONV used when shocking the rates implied by
          the discount factor curve. Cannot be MAIR or JGBYTM.

    freq  when irr is COMPOUND, COMPOUNDSIMPLE, COMPOUNDSIMPLE_ODD,
          US_TREASURY or MOOSMULLER then a quoting base is also needed.

    loads|NULL is used with KEY_DF and KEY_BPV and defines the shock
          (structure) to be enforced. All elements in loads->f64 are in bps.
          If loads->filled is 0 or loads is NULL then the standard parallel
          shift risk ratios are found (shocksize is shock).
          Using loads allows for factor sensitivities / BPV's.

    dom   defines whether interest rate risk numbers are in domestic
          or foreign currency. Usually this is irrelevant, but for FX
          forwards and currency options this is relevant, since 2 interest
          rates enter into the calculation. Here True means domestic and
          False foreign currency based interest rate risk numbers.

see also Set_RISKSET

,,EOT,,*/

typedef struct riskset_tag
{
    KEYCONV  key ;
    RISKCONV risk ;
    FL64     shock ;
    IRRCONV  irr ;
    PMTFREQ  freq ;
    PLAN_STR *loads ;
    BOOLE    dom ;
}   RISKSET ;


/*,,SOT,,

BUCKET, BUCKETARRAY : data type for holding info on zero curve bucketing
------------------------------------------------------------------------

This type is defined in disc.h as:

        typedef struct bucket_tag
        {
            INTI      term ;
            TERMUNIT  unit ;
            FL64      shock ;
            RISKTOKEN token ;
        }   BUCKET ;

The type is used for defining how zero curves are shocked when calcu-
lating delta vectors.

The data have the following interpretation:

        term is the maturity quote for the bucket (in units of unit)
        term represents the middle of the bucket periods !

        unit is the unit of term

        shock is the shock for the bucket (in %)

        token defines the risk factor the bucket refers to.
        This piece of data is used in the *_*2RiskPos() routines used
        for Risk Position calculation which is the base for VAR 
        calculation.
        When calculating delta vectors token is NOT used.
        
Lists of BUCKET's can be handled via BUCKETARRAY's:

        typedef BUCKET * BUCKETARRAY ;

,,EOT,,*/

typedef struct bucket_tag
{
    INTI      term ;
    TERMUNIT  unit ;
    FL64      shock ;
    RISKTOKEN token ;
}   BUCKET ;

typedef BUCKET * BUCKETARRAY ;


/*,,SOT,,

DFSPREAD and DFSPREADARRAY: data type for holding info on spreads
-----------------------------------------------------------------

This type is defined as:

        typedef struct dfspread_tag
        {
            FL64     spread ;
            IRRCONV  irr ;
            PMTFREQ  freq ;
            PLAN_STR *spr_list ;
        }   DFSPREAD ;

For defining zero curve spreads.

The elements have the following interpretations:

    spread is the spread above the (DF) Curve

    irr and freq is the quoting of the spread. irr is the interest
        rate convention. MAIR and JGBYTM cannot be used.
        When irr is COMPOUND, COMPOUNDSIMPLE, COMPOUNDSIMPLE_ODD,
        US_TREASURY or MOOSMULLER then a quoting base (freq) is also
        needed.

    spr_list|NULL is a list of time dependent spreads, to be used when
        a single number is not sufficient.
        Use NULL for no spreads.

Lists of DFSPREAD's can be defined as

        typedef DFSPREAD * DFSPREADARRAY ;

see also Set_DFSPREAD

,,EOT,,*/

typedef struct dfspread_tag
{
    FL64     spread ;
    IRRCONV  irr ;
    PMTFREQ  freq ;
    PLAN_STR *spr_list ;
}   DFSPREAD ;

typedef DFSPREAD * DFSPREADARRAY ;



/*,,SOT,,

DFWHICH : data type for specifying which discount factor curve to shock 
-----------------------------------------------------------------------

This type is used when calculating delta vectors for instruments using
2 discount factor curves, typically the first curve is used for 
generating payments and the second is used for discounting payments. 

In SCecon, the data type is defined as

        typedef enum dfwhich_tag
        {
            DF_BOTH,
            DF_CFLW,
            DF_DISC
        }   DFWHICH ;

The individual data are to be interpreted as follows:

            DF_BOTH specified that the shocks in a DELTASET will be 
            used to shock both discount factor curves.
            DF_BOTH should only be used when the 2 discount factor 
            curves are identical (e.g. as in vanilla swaps, caps and 
            swaptions)

            DF_CFLW specified that the shocks in a DELTASET will be 
            used  to shock the discount factor curve used for 
            generating payments. For diff swaps this means the
            foreign currency discount factor curve.

            DF_DISC specified that the shocks in a DELTASET will be 
            used to shock the discount factor curve Used for 
            discounting. For diff swaps this means the domestic
            currency discount factor curve.

,,EOT,,*/

typedef enum dfwhich_tag
{
    DFWHICH_INIT = -1,
    DF_BOTH,
    DF_CFLW,
    DF_DISC
}   DFWHICH ;


/*,,SOT,,

DELTASET: struct for defining data for delta vector calculations
----------------------------------------------------------------

This type is defined as:

        typedef struct deltaset_tag
        {
            PLANARRAY      shock ;
            INTI           nshock ;
            BOOLE          dom ;
            DFWHICH        dfwhich ;
            BOOLE          zero ;
            DATEARRAY      mid ;
            RISKTOKENARRAY token ;
            IRRCONV        irr ;
            PMTFREQ        freq ;
            FL64ARRAY      size ;
        }   DELTASET ;

The data elements have the following interpretation:

    shock[nshock] is a list of (nshock) shocked discount factor
        curves. These curves SHOULD be generated using Disc_DeltaPrep(),
        Boot_DeltaPrep() or Disc_ScenarioPrep().

    nshock is the number of curves in shock.
        In some pricing routines 2 discount factor curves are used
        (e.g Caplets_Black2Delta()). In these cases the number of
        shocked curves for each discount factor MUST be the same.

    dom is True if curves are interpreted as domestic and False
        if interpreted as foreign curves.

    dfwhich is used to signal which discount factor curve(s) the 
        shocks in shock correspond to. 
        This is only used for deltavector and riskposition functions
        where two discount factor curves are needed.
        If these two discount factor curves are identically dfwhich 
        could be DF_BOTH. This means that the shocks are used to shock 
        both curves. If the curves differs dfwhich should be DF_CFLw or
        DF_DISC. If dfwhich is DF_CFLW the curve used for generating
        cash flow is shocked. If dfwhich is DF_DISC the curve used for
        discounting is shocked.
    
    zero is False if the delta vectors are calculated as shock
        values per interest rate shock,
        If it is True if the delta vectors are calculated as shock
        values per price change in a zero coupon security with
        maturity similar to the shocked rate. This method results
        in a delta vector that represent a delta equivalent cash flow
        (DECF) for the security.
        This facility is only relevant if Disc_DeltaPrep() is used.

    mid[nshock]|NULL is a list of dates - representing the mid dates
        on which the curve is shocked. Only used if shocks are generated
        from a list of buckets (BUCKETARRAY) as in Disc_DeltaPrep() The
        list contains nshock dates. If Boot_DeltaPrep() is used then mid
        is NULL, and can consequently not be used for Risk Position
        calculation (*_*2RiskPos()).

    token[nshock]|NULL is a list of nshock risk factors tokens. Used to
        identify the risk factor a given shock refers to. Used for Risk
        Position calculations in the routines *_*2RiskPos() - used for
        VAR calculations. Not used in *_*2delta() routines for delta
        vector calculations. If not used in the actual calculation enter
        a NULL.

    irr documents the rates that are being shocked

    freq is the quoting of irr

    size[nshock]|NULL is a list with nshock elements indicating the
        shocksize (in %) that was used to shock the curve. NULL
        indicates that default value (0.01 %) was used.

Free using Free_DELTASET().  

DELTASET is returned by Disc_DeltaPrep(), Boot_DeltaPrep() or 
Disc_ScenarioPrep().

The first 2 routines are used to initialise calculation of delta vectors, 
whereas the latter is used to initialise calculations of scenario PV's.
Both types of calculations (delta vector, scenario PV's) can be done with 
the SCecon routines: security_model2delta(). The only difference lies on 
the interpretation of the outcoming numbers as delta vectors or scenario
PV differences.

Note that when using shocked discount factor curves, the anchor date
(i.e. the date with discount factor 1)
for the set of shocked curves must be the analysis date. If a date
later than the anchor date of the discount function is used as analysis
date, the pricing routines will have to discount the PV forward from
anchor date to analysis date. Thus the shock to the first bucket will
be used for pricing even for cashflows that only have much later payments,
introducing an erroneous nonzero 1st delta-vector element.

see also Set_DELTASET

,,EOT,,*/

typedef struct deltaset_tag
{
    PLANARRAY      shock ;
    INTI           nshock ;
    BOOLE          dom ;
    DFWHICH        dfwhich ;
    BOOLE          zero ;
    DATEARRAY      mid ;     /* nshock dates */
    RISKTOKENARRAY token ;
    IRRCONV        irr ;
    PMTFREQ        freq ;
    FL64ARRAY      size ;
}   DELTASET ;


/*,,SOT,,

ZRATE_STR and ZRATEARRAY : types for holding zero coupon rate info
-------------------------------------------------------------------

ZRATE_STR is a type for holding the informations needed on zero 
coupon rates when bootstrapping the discount function.
The ZRATE_STR type is defined as:

    typedef struct zrate_str_tag
    {
        PERIOD  period ;
        FL64    rate ;
        IRRCONV irr ;
        PMTFREQ freq ;
        CALCONV cal ;
        BUSCONV bus ;
        EOMCONV eom ;
    }   ZRATE_STR ;

The data should be interpreted as:

        period is the period for which the zero coupon rate is
        quoted.

        rate is the zero coupon rate.
    
        irr is a specification of the interest rate convention
        used for rate.

        freq is the frequency of the rate.

        cal is the day count convention to be used.

        bus is the business day convention to be used.

        eom is the end of month convention to be used.

ZRATEARRAY is needed for lists of ZRATE_STR's
The definition of the ZRATEARRAY type is:

        typedef ZRATE_STR * ZRATEARRAY ;

see also Set_ZRATE_STR

,,EOT,,*/

typedef struct zrate_str_tag
{
    PERIOD  period ;
    FL64    rate ;
    IRRCONV irr ;
    PMTFREQ freq ;
    CALCONV cal ;
    BUSCONV bus ;
    EOMCONV eom ;
}   ZRATE_STR ;

typedef  ZRATE_STR * ZRATEARRAY ;

/*,,SOH,,
***********************************************************************
*                                                                      
*              Disc_CheckDfSpreadEmpty()              
*                                                                      
*    library   disc                                                    
*                                                                      
*    interface #include <disc.h>                                       
*              DISCFAC Disc_CheckDfSpreadEmpty(DFSPREAD *dfs) ;
*                                                                      
*   general    CheckDfSpreadEmpty() is a macro for testing whether 
*              there are any spreads or not                         
*                                                                      
*    input     DFSPREAD   *dfs      Spread setup to test. May be NULL.
*                                                                      
*    output                                                            
*                                                                      
*    returns   True if dfs indicates no spreads
*              False if there is either a general spread or a list
*                of time varying spreads.
*                                                                      
*    diagnostics                                                       
*                                                                      
*    see also                                                          
*                                                                      
***********************************************************************
,,EOH,,*/
#define Disc_CheckDfSpreadEmpty(dfs)   \
   ((dfs == NULL) || \
   (dfs->spread > -DISC_TOLR && dfs->spread < DISC_TOLR &&  \
  GetPlanFill(dfs->spr_list) < 1) ? True : False)            \



/*** prototypes  (disc.c)  **********************************************/


/* Public functions */

extern FL64 Disc_Interpolation(DATESTR    *date,
                               DISCFAC    *df,
							   HOLI_STR   *holi) ;  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */

extern FL64ARRAY Disc_IntpolArray(DATEARRAY dates,
                                   INTI n,
								   DISCFAC   *df, 
								   HOLI_STR  *holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */

extern TSARRAY Disc_DF2TS(DATEARRAY dates,
                            INTI n,
                            DISCFAC  *df,
                            PLAN_STR *loads,
                            IRRCONV irr,
                            PMTFREQ freq,
							HOLI_STR   *holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */

extern DISCFAC Disc_TS2DF(DATESTR   *today,
                          DATEARRAY dates,
                          FL64ARRAY rates,
                          INTI      n,
                          DFPARMS   *dfp,
						  HOLI_STR  *holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */

extern DISCFAC Disc_ShockRates(DISCFAC  *df,
                                FL64     fac,
                                RISKSET  *risk,
								HOLI_STR *holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */

extern FL64 Disc_DF2ForwRate(DATESTR   *start,
                             DATESTR   *end,
                             CALCONV   cal,
                             DISCFAC   *df,
                             IRRCONV   irr,
                             PMTFREQ   freq,
							 HOLI_STR  *holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */

extern FL64 Disc_DF2NPV(DATESTR   *analys,
	DATEARRAY dates,
	FL64ARRAY coupons,
	FL64ARRAY amorts,
	INTI      npmt,
	DISCFAC   *df,
	DATESTR   *matur,
	BOOLE     ignore,
	FL64ARRAY nvpdecomp,
	HOLI_STR  *holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */

extern FL64 Disc_DF2NPV2(DATESTR* analys,
	DATEARRAY dates,
	FL64ARRAY coupons,
	FL64ARRAY amorts,
	INTI npmt,
	DISCFAC* df,
	BOOLE     ignore);	/* PMSTA-31276 - RAK - 180621 */

extern DISCFAC Disc_Spread2DF(DISCFAC  *df,
                                 DFSPREAD *dfs,
								 HOLI_STR *holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */

extern DELTASET Disc_DeltaPrep(DISCFAC     *df,
                          BUCKETARRAY bucket,
                          INTI        nbuck,
                          HOLI_STR    *holi,
                          BOOLE       ins,
                          IRRCONV     irr,
                          PMTFREQ     freq,
                          BOOLE       dom,
                          BOOLE       zero,
                          DFWHICH     dfwhich) ;

extern DFSPREAD Set_DFSPREAD(FL64 spread, IRRCONV irr, PMTFREQ freq,
                                PLAN_STR *spr_list) ;

extern DELTASET Set_DELTASET(PLANARRAY shock,
                           INTI      nshock,
                           BOOLE     dom,
                           DFWHICH   dfwhich,
                           BOOLE     zero,
                           DATEARRAY mid,
                           RISKTOKENARRAY token,
                           IRRCONV   irr,
                           PMTFREQ   freq,
                           FL64ARRAY size) ;

extern DFPARMS Set_DFPARMS(DISCIPOL what, INTPOLCONV iconv,
                                 CALCONV cal, IRRCONV irr, PMTFREQ freq) ;

extern RISKSET Set_RISKSET(KEYCONV  key,
                         RISKCONV risk,
                         FL64     shock,
                         IRRCONV  irr,
                         PMTFREQ  freq,
                         PLAN_STR *loads,
                         BOOLE    dom) ;

extern DISCFAC Set_DISCFAC(PLAN_STR *disc, DISCIPOL ipol, INTPOLCONV iconv,
                                CALCONV cal, IRRCONV irr, PMTFREQ freq) ;

extern DISCFAC Disc_Zeros2DF(DATESTR       *start,
                              ZRATEARRAY    zrates,     
                              INTI          nrates,
                              HOLI_STR      *holi,
                              DFPARMS       *dfp) ;

extern ZRATE_STR Set_ZRATE_STR(PERIOD     *period, 
                             FL64       rate, 
                             IRRCONV    irr, 
                             PMTFREQ    freq,
                             CALCONV    cal,
                             BUSCONV    bus,
                             EOMCONV    eom) ;

/* Private functions */

extern TSARRAY Disc_DF2TSfwd(DATESTR   *analys,
                      DATEARRAY dates,
                      INTI      n,
                      DISCFAC   *df,
                      PLAN_STR  *loads,
                      IRRCONV   irrc,
                      PMTFREQ   freq) ;

extern DISCFAC Disc_Shock_Dates(DISCFAC   *df,
                                INTI      days,
								HOLI_STR  *holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */

extern FL64 Disc_Shock_Single(DATESTR *today, DATESTR *date, FL64 disc, 
                              FL64 shock,
                              CALCONV cal, IRRCONV irr, INTI qbas,
							  HOLI_STR   *holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */

extern INTI disc_set_qbas(PMTFREQ freq) ;

extern DISCFAC Disc_insert_buckdates(DISCFAC *df, BUCKETARRAY bucket,
                                     INTI nbucket, HOLI_STR *holi) ;
extern BOOLE Disc_forwval(DISCFAC *df, DATESTR *analys, FL64 *pv, 
						  HOLI_STR   *holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */

extern BOOLE Disc_ForwDisc(DISCFAC* df, DATESTR* start, 
						   DATESTR* end, FL64* disc, 
						   HOLI_STR   *holi) ;  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */

extern FL64 Disc_MarginAdjust(BOOLE   margin,
                                  FL64    futp,
                                  DATESTR *analys,
                                  DATESTR *deliv,
                                  DISCFAC *df,
								  HOLI_STR*holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */

extern FL64 Disc_DF2fwd(DISCFAC *df, DATESTR *date,
                        IRRCONV irr, PMTFREQ freq, INTI term, TERMUNIT unit,
                        FL64 *dsc) ;

extern FL64 Disc_fwdYield(FL64 npv, FL64ARRAY t, INTI n, 
                             IRRCONV irr, INTI qb, 
							 HOLI_STR   *holi) ;  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */

extern FL64 Disc_Logshock_Single(DATESTR *today, DATESTR *date, FL64 disc, 
                                 FL64 shock,
                                 CALCONV cal, IRRCONV irr, INTI qbas,
								 HOLI_STR   *holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */

extern DISCFAC Disc_Logshock_Rates(DISCFAC   *df,
                                   FL64      fac,
                                   RISKSET   *risk,
								   HOLI_STR  *holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */

extern FL64 Disc_DF2BPV(DATESTR *date, DISCFAC *shocked, PLAN_STR *orig,
					    HOLI_STR   *holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */

extern DATESTR Disc_get_chgdate(DATESTR *prev, PLAN_STR *old, 
                                   PLAN_STR *shock) ;

extern DISCFAC Disc_MergeDF(DISCFAC* df_conv,
                               DISCFAC* df_stor,
							   HOLI_STR *holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */



/*** prototypes  (discaloc.c)  ******************************************/

/* Public functions */

extern void Free_BUCKETARRAY(BUCKETARRAY buck) ;
extern BUCKETARRAY Alloc_BUCKETARRAY(INTI n) ;
extern DFSPREADARRAY Alloc_DFSPREADARRAY(INTI n) ;
extern ZRATEARRAY Alloc_ZRATEARRAY(INTI n) ;
extern DISCFACARRAY Alloc_DISCFACARRAY(INTI n) ;

extern void Free_DFSPREADARRAY(DFSPREADARRAY date) ;
extern void Free_DELTASET(DELTASET *ds) ;
extern void Free_RISKSET(RISKSET *ds);
extern void Free_ZRATEARRAY(ZRATEARRAY zrate) ;
extern void Free_DFSPREAD(DFSPREAD *d) ;

extern void Free_DISCFAC(DISCFAC *d) ;
extern void Free_DISCFACARRAY(DISCFACARRAY vector, INTI n) ; 

#ifdef __cplusplus
}
#endif

#endif

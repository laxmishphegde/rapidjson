/* SCID @(#)fitzero.h	1.21 (SimCorp) 99/09/07 16:22:19 */

#ifndef FITZERO_H_INCLUDED

#define FITZERO_H_INCLUDED

/************************************************************************
*                                                                       *
*    project    SCecon                                                  *
*                                                                       *
*    filename   fitzero.h                                               *
*                                                                       *
*    general    this file contains declarations, initializations,       *
*               type definitions and function prototyping for the       *
*               fitzero module of the standard library SCecon           *
*                                                                       *
************************************************************************/

/**** includes *********************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <ctype.h>

#include <time.h>
#include <bond.h>
#include <bootstrp.h>
#include <scutl.h>

#ifdef __cplusplus
extern "C" {
#endif

/*** typedefines ******************************************************/

/*,,SOT,,

ZEROMODEL : Term Structure models
---------------------------------

This is an enumerated type for holding information on Term Structure models.

The type is defined as:

        typedef enum zeromodel_tag
        {
            CIR,
            CIRNOM,
            CCW,
            DPOLY,
            IYEXT,
            SPLINEDISC,
            SPLINEEXPO,
            SPLINEYIELD,
            VASICEK,
            LONGSCH,
            BOOTSTRAP,
            SPLINEX,
            SPLINEF,
            BSPLYLD,
            BRNSTYLD,
            EXTNS,
            SPLINETRANS
  }   ZEROMODEL ;

in fitzero.h in SCecon.

The entries represents various Term theoretical Term Structure models.
These models are all theoretically well-defined models taken from the
literature.
Some of these models are, however, numerically sensitive. In order to
deal efficiently with these numerical issues we have - at the bottom
level in the code - implemented various 'safety valves'.

From the users point of view this can be regarded as implementation
specific issues. However, one thing must be borne in mind. Once the
coefficients of a given model have been estimated you should only use
the SCecon functions to generate term structures or bond prices using
the estimated coefficients. This is important, since the estimated
coefficients might not always be equal to the corresponding coefficients
from the litterature, due to scaling etc.
Also externally given values may not necessarily give you the expected
price etc.

In the following the models are briefly described:


                   Cox Ingersoll Ross (CIR) model
                   ------------------------------

The CIR model from the article of Cox, Ingersoll and Ross, "A Theory of
the Term Structure of Interest Rates", Econometrica, 1985, is really a
one factor equilibrium model of interest rates.
It is derived from a stochastic process of short rates, where the short
rate of interest is mean reverting and its volatility is proportional to
its square root.

Mean reversion means, that if rates are high relative to some target or
steady state level, they will tend to drift downwards, and if they are
low, they tend to come up. Interestingly enough, this process itself is
endogenously derived from the uncertainty about future technology and
economic agents preferences.

Based on this, CIR derive an equation describing the term structure as a
function of five parameters:

        Kappa   The rate of mean reversal or how fast does the
                market adjust.
                This should be between 0 and 1.

        Lambda  The market price of risk, or the risk premium.
                This should be negative in the CIR formulation
                since risk corrected returns are lowered by
                increased risk aversion.

        Sigma   The instantaneous volatility of short rates, which
                must - of course - be positive.

        Theta   The steady state level of interest rates.

        R       The current short rate.

As long as people are allowed to hold cash - which fortunately seems to
be the case in most situations - Theta and R are non-negative.

According to the CIR article, Kappa, Lambda and Theta are not independent
so in our implementation we use only 4 parameters

        Alpha   Kappa * Theta,
        Beta    Kappa + Lambda,
        Sigma and
        R.

In the original CIR model, all of these parameters are fixed, except the
current short rate, r, which is variable. This is the single factor in
the model. Under that - strict - interpretation of the model, the long
term yields are given whereas short term yields may move.

However, in SCecon, we allow you to use the CIR model in a slightly
different manner:

Instead of postulating all parameters except R, and letting the fitter
determine R, you can let the fitter determine all parameters of the model.
This is not completely in theoretical line with the original paper, but it
allows you to fit very nice looking term structures.
This version of the CIR model simply utilizes the mathematical properties
of the closed form solution found by CIR, without attaching any deeper
meaning to it.

Standard guesses and bounds for the parameters could be:

            Coefficient  Guess    Lower Bound     Upper Bound
            -------------------------------------------------
            Alpha        0.0159     0.001           0.25
            Beta         0.1668     0.01            0.9
            Sigma        0.00035    0.0001          0.3
            R            0.0953     0.01            0.3
            -------------------------------------------------

These coefficients approximates a flat term structure at 10.00% annually
compounded rates.



              Cox Ingersoll Ross with inflation (CIRNOM) model
              ------------------------------------------------

The CIRNOM model is equivalent to the CIR model described above except for
a 5'th parameter - the expected inflation. The model is referred to a the
nominal model with lognormal inflation.
The original reference to this model is the same paper in Econometrica,
1985. The model is the first example of a 2 factor model with a closed
form solution.
In SCecon this model variation is handled as the CIR model - except of
course for the 5'th parameter.

A standard guess and bounds for the parameters could be:

            Coefficient  Guess    Lower Bound     Upper Bound
            -------------------------------------------------
            Alpha        0.0044     0.00100         0.25000
            Beta         0.0239     0.01000         0.90000
            Sigma        0.0001     0.00010         0.30000
            R            0.1857     0.01000         0.30000
            EI          -0.0904    -0.50000         0.50000
            -------------------------------------------------

These coefficients approximates a flat term structure at 10.00% annually
compounded rates.


                 Chambers Carleton Waldman (CCW) Model
                 -------------------------------------

The CCW model introduced in the article "A New Approach to Estimation of
the Term Structure of Interest Rates", from the distinguised Journal of
Financial and Quantitative Analysis, September 1984, uses a polynomial as
a description of the term structure.

                                2
        yield(t) = a + b t + c t  + ...

A standard guess and bounds for the parameters could be

            Coefficient  Guess    Lower Bound     Upper Bound
            -------------------------------------------------
            a             0.0953     -1.0             1.0
            b             0.0        -1.0             1.0
            .              .           .               .
            .              .           .               .
            -------------------------------------------------

These coefficients approximates a flat term structure at 10.00% annually
compounded rates.

This is a third order approximation. Values for polynomias of a higher
order approximation can be found by adding more coefficients using the
same bounds and guesses of 0.0.



                  Modified Nelson Siegel Model (IYEXT)
                  ------------------------------------

The modified Nelson and Siegel model (IYEXT) uses Laguerre polynomials,
or decay functions, to fit the term structure. The advantage is that
short term and long term yields are then both bounded.

A curve fitted by the IYEXT model consists of a superimposition of three
functions. One determines the decay of short term impacts, one determines
the medium term decay, and one determines the long term decay.
The point where we distinguish between short term and medium term is
given by the time scaling parameter.

The model has five parameters. The first parameter is the long term yield,
quoted as continuously compounded rates. The rest are coefficients that
determine the decay behaviour in the three segments of the curve.

A standard guess and bounds for the parameters could be:

            Coefficient  Guess    Lower Bound     Upper Bound
            -------------------------------------------------
            Yield        0.0953       0.01          0.30
            Decay1       0.0         -5.0           5.0
            Decay2       0.0         -5.0           5.0
            Decay3       0.0         -5.0           5.0
            Scale        5.0          0.001         5.0
            -------------------------------------------------

These coefficients approximates a flat term structure at 10.00% annually
compounded rates.


                  Extended Nelson Siegel Model (EXTNS)
                  ------------------------------------

The extended Nelson and Siegel model (EXTNS) uses Laguerre polynomials,
or decay functions, to fit the term structure. The advantage is that
short term and long term yields are then both bounded.

A curve fitted by the EXTNS model consists of a superimposition of three
functions. One determines the decay of short term impacts, one determines
the medium term decay, and one determines the long term decay.
The point where we distinguish between short term and medium term is
given by the time scaling parameter.

The model has six parameters. The first parameter is the long term yield,
quoted as continuously compounded rates. The rest are coefficients that
determine the decay behaviour in the three segments of the curve.
This specification has several alternative parsimonious models as nested
cases. By restricting the 4th parameter to zero the original Nelson and
Siegel model arise. Similar by setting the 3rd parameter to zero Bliss's 
extended Nelson/Siegel model arise.

A standard guess and bounds for the parameters could be:

            Coefficient  Guess    Lower Bound     Upper Bound
            -------------------------------------------------
            Yield        0.0953       0.01          0.30
            Decay1       0.0         -5.0           5.0
            Decay2       0.0         -5.0           5.0
            Decay3       0.0         -5.0           5.0
            Scale1       5.0          0.001         5.0
            Scale2       5.0          0.001         5.0
            -------------------------------------------------

These coefficients approximates a flat term structure at 10.00% annually
compounded rates.


                 Polynomial Fit to Discount Function (DPOLY)
                 -------------------------------------------

DPOLY assumes that the discount function can be described as a polynomial of
some user specified degree

    disc(t) = 1 + a t + b t^2 + c t^3 + ...

where disc(t) is the discount factor for maturity t.

A standard guess and bounds for the parameters could be

            Coefficient  Guess    Lower Bound     Upper Bound
            -------------------------------------------------
            a           -0.953       -1.0            1.0
            b            0.449       -1.0            1.0
            c           -0.12        -1.0            1.0
            .             .            .              .
            .             .            .              .
            -------------------------------------------------

These coefficients approximates a flat term structure at 10.00% annually
compounded rates.

This is a third order approximation. Values for polynomias of a higher
order approximation can be found by adding more coefficients using the
same bounds and guesses of 0.0.


                  Cubic Spline on Yields (SPLINEYIELD)
                  ------------------------------------

In the SPLINEYIELD model, we fit a chain of third degree polynomials to
the term structure.

The polynomials are chained in the knot points as input by the user as
terms, and the coefficients of the polynomials are chosen such that the
first and second order derivatives of the interpolating function are
continuous in the knot points.
Outside the range given in the input knot points, the term structure will
be flat at the level in the first or last knot point.

A standard guess and bounds for the parameters could - with n spline
points - be

        Coefficient  Guess    Lower Bound     Upper Bound   Splinedate
        --------------------------------------------------------------
        Yspl(1)      0.0953      0.0             0.3           1.0
          .             .         .               .             .
          .             .         .               .             .
        Yspl(n)      0.0953      0.0             0.3           any
        --------------------------------------------------------------

The spline terms must be unique and sorted ascendingly.

These coefficients approximates a flat term structure at 10.00% annually
compounded rates.

With more involved term structures the splinedates must be selected very
carefully depending on the maturity spectre etc.

The method has been implemented such that approximately a flat yield curve
will prevail above the highest spline point and below the first one.

                  Cubic Spline on Yields (SPLINEX)
                  ------------------------------------

This is equivalent to SPLINEYIELD except that extrapolation is performed
beyond the outer spline points (i.e. linear extrapolation).


                  Cubic Spline on Yields (SPLINEF)
                  ------------------------------------

This is equivalent to SPLINEYIELD except that the first order derivatives
are 0 at the outer spline points.


             Cubic Spline on the Discount Function (SPLINEDISC)
             --------------------------------------------------

In the SPLINEDISC model, we fit a chain of third degree polynomials to
the discount function - the mirror image of the term structure.

The polynomials are chained in the knot points specified by the user as
terms, and the coefficients of the polynomials are chosen such that the
first and second order derivatives of the interpolating function are
continuous in the knot points.
Outside the range given in the input knot points, the term structure will
be flat at the level in the first or last knot point.

A standard guess and bounds for the parameters could - with n spline
points - be

        Coefficient  Guess    Lower Bound     Upper Bound    Splinedate
        ---------------------------------------------------------------
        Dspl(1)      0.9091      0.5             0.99           1.0
        Dspl(2)      0.8264      0.5             0.99           2.0
          .             .         .               .              .
          .             .         .               .              .
        Dspl(n)      0.3855      0.2             0.5           10.0
        ---------------------------------------------------------------

The spline terms must be unique and sorted ascendingly.

These coefficients approximates a flat term structure at 10.00% annually
compounded rates.

With more involved term structures the splinedates must be selected very
carefully depending on the maturity spectre etc.


                       Exponential Spline (SPLINEEXPO)
                       -------------------------------

In the SPLINEEXPO model, we fit a chain of third degree polynomials to
the term e = t*y(t) of the pricing equation P = exp(-e). Hence the name
exponential spline.

The polynomials are chained in the knot points specified by the user as
terms, and the coefficients of the polynomials are chosen such that the
first and second order derivatives of the interpolating function are
continuous in the knot points.
Outside the range given in the input knot points, the term structure will
be flat at the level in the first or last knot point.

A standard guess and bounds for the parameters could - with n spline
points - be

        Coefficient  Guess    Lower Bound     Upper Bound    Splinedate
        ---------------------------------------------------------------
        Espl(1)      0.0953     -1.0             1.0            1.0
        Espl(2)      0.1906     -1.0             1.0            2.0
          .             .         .               .              .
          .             .         .               .              .
        Espl(n)      t*0.0953   -1.0             1.0             t
        ---------------------------------------------------------------

The spline terms must be unique and sorted ascendingly.

These coefficients approximates a flat term structure at 10.00% annually
compounded rates.

With more involved term structures the splinedates must be selected very
carefully depending on the maturity spectre etc.


                       Transformed Yield Spline (SPLINETRANS)
                       --------------------------------------

In the SPLINETRANS model, we fit a chain of third degree polynomials to
a simple transformation of the yield curve, u(t), such that y(t) = 
u(t)/(1+t) which leads to the pricing equation P = exp(-t/(1+t)u(t)). 
Hence the name transformed yield spline.

The polynomials are chained in the knot points specified by the user as
terms, and the coefficients of the polynomials are chosen such that the
first and second order derivatives of the interpolating function are
continuous in the knot points.

A standard guess and bounds for the parameters could - with n spline
points - be

        Coefficient  Guess    Lower Bound     Upper Bound    Splinedate
        ---------------------------------------------------------------
        Espl(1)      0.0953     -1.0             1.0            1.0
        Espl(2)      0.1906     -1.0             1.0            2.0
          .             .         .               .              .
          .             .         .               .              .
        Espl(n)      t*0.0953   -1.0             1.0             t
        ---------------------------------------------------------------

The spline terms must be unique and sorted ascendingly.

With more involved term structures the splinedates must be selected very
carefully depending on the maturity spectre etc.


                           Vasicek (VASICEK)
                           -----------------

The Vasicek is an equilibrium model of the interest rates based on the
assumption that the short rate is determined by a one-factor stochastic
proces. This proces assumes that the short rate is normally distributed.

The parameters of the proces are:

        Kappa : The rate of mean reversal (how fast does the
                market adjust) - This should be between 0 and 1
        Lambda: The market price of risk, or the risk premium -
        Sigma : The instantaneous volatility of short rates -
                this should be positive
        Theta : The steady state level of interest rates -
                of course positive
        R     : The current short rate.

Lambda/Theta are not independent so in our implementation we use 4 parameters:

        Phi   : Theta - Lambda * Sigma
        Kappa :
        Sigma :
        R     :

This corresponds to the formulation by Hull & White (Review of Financial
Studies, 3, 1990, o 573 - 592).

In the original Vasicek model, all these parameters are fixed, except the
current short rate, r, which is variable. This is the single factor in the
model. Under that - strict - interpretation of the model, the long term yields
are given whereas short term yields may move. However, we allow you to use the
Vasicek model in a slightly different manner: Instead of postulating all
parameters except R, and letting the fitter determine R, you can let the
fitter determine all parameters of the model. This is not completely in
theoretical line with the original paper, but it allows you to fit very nice
looking term structures. This version of the Vasicek model simply utilizes
the mathematical properties of the closed form solution found by Vasicek,
without attaching any deeper meaning to it.

Standard guesses and bounds for the parameters could be:

            Coefficient  Guess    Lower Bound     Upper Bound
            -------------------------------------------------
            Phi          0.0154448    0.001           0.25
            Kappa        0.1620476    0.001           0.99
            Sigma        0.0001       0.0001          0.3
            R            0.0953102    0.01            0.3
            -------------------------------------------------

These coefficients approximates a flat term structure at 10.00% annually
compounded rates.


                   Longstaff Schwartz model (LONGSCH)
                   ----------------------------------

This model is the most recent development in the field of term structure
modelling - to be published in 1992. It is essentially a 2 factor model
with the 2 factors as the short rate and the volatility of the short rate.

From our point of view we use the model in a similar way as we use the
CIR model, which means that we estimate the 8 parameters of the model
without attaching any deeper meaning to the parameters.

The parameters of the stochastic differential equation to be solved in
the original formulation are

        a, b, c, d, e, f, mu, theta, sigma and lambda.

The parameters are (following the authors) in our formulation transformed
to the following 8 parameters:

                      2
        Alpha   mu * c ,

                              2     2
        Beta    (theta - sigma ) * f ,

                     2
        Gamma   a / c ,

        Delta   b,

                     2
        Eta     d / f ,

        Nu      e + lambda,

        R       the current short rate and

        V       the current short rate volatility.

Standard guesses and bounds for the parameters could be:

            Coefficient  Guess    Lower Bound     Upper Bound
            -------------------------------------------------
            Alpha      0.0240248    0.000010        1.000000
            Beta       0.0000079   -1.000000        1.000000
            Gamma      0.0069303    0.000010        1.000000
            Delta      0.4305436    0.000010        1.000000
            Eta        0.9418237    0.000010        1.000000
            Nu         0.0000186    0.000010        1.000000
            R          0.0953078    0.010000        0.250000
            V          0.0000100    0.000010        0.750000
            -------------------------------------------------

These coefficients approximates a flat term structure at 10.00% annually
compounded rates.


                        Bootstrapping (BOOTSTRAP)
                        -------------------------

This model differs somewhat from the other methods. Here an exact fit to the
market prices are provided by simply sorting securities according to
maturities and hereafter finding the relevant discount factors for the
various maturities. See boot_genrdisc() for details.

                      Basis Spline on Yields (BSPLYLD)
                      --------------------------------

In this model the term structure is fitted using basis splines.

The spline used is a 3'rd order. Therefore the estimation requires 3 + n
3'rd order basis splines.

A standard guess and bounds for the parameters could - with n spline
points - be

        Coefficient  Guess    Lower Bound     Upper Bound   Splinedate
        --------------------------------------------------------------
        P1           1.0      -100.0            100.0         -3.0
        P2           1.0      -100.0            100.0         -2.0
        P3           1.0      -100.0            100.0         -1.0
        Y1           1.0      -100.0            100.0          1.0
         .                                                      .
         .                                                      .
        Yn           1.0      -100.0            100.0          any
        --------------------------------------------------------------

The spline terms must be unique and sorted ascendingly.

In the list the first 3 spline points must be found. The last n are
user selected.


                  Bernstein Polynomial on Yields (BRNSTYLD)
                  -----------------------------------------

In this model the term structure is fitted using a Bernstein polynomial.

  A standard guess and bounds for the parameters could be:

        Coefficient  Guess    Lower Bound     Upper Bound   Splinedate
        --------------------------------------------------------------
        C1           0.0953    0.01            0.5             0.0
         .                                                      .
         .                                                      .
        Cn           0.0953    0.01            0.5             LAST
        --------------------------------------------------------------

All spline dates are 0 -e xcept the last date which reflects the last relevant
maturity date for the term structure (e.g 10Y or 30Y).

The order (n) of the polynomial approximation is user defined.


,,EOT,,*/

typedef enum zeromodel_tag
{
    ZEROMODEL_INIT = -1,
    CIR,
    CIRNOM,
    CCW,
    DPOLY,
    IYEXT,
    SPLINEDISC,
    SPLINEEXPO,
    SPLINEYIELD,
    VASICEK,
    LONGSCH,
    BOOTSTRAP,
    SPLINEX,
    SPLINEF,
    BSPLYLD,
    BRNSTYLD,
    EXTNS,
    SPLINETRANS
}   ZEROMODEL ;


/*,,SOT,,

SMOOTHCRIT : Smoothness Criterion
---------------------------------

This is an enumerated type for holding information on the smoothness
criterion which is optional in models using spline fitting.  

This type is defined in fitzero.h as:

        typedef enum smoothcrit_tag
        {
          SECONDDIFF,
          FIRSTDIFF,
          NO_SMOOTH  
        } SMOOTHCRIT;

The interpretation of the data is:

        SECONDDIFF - The integral of squared second order derivatives 
        of the function in question. A standard smoothness criteria.

        FIRSTDIFF - The integral of squared first order derivatives 
        of the function in question. A standard smoothness criteria.

        NO_SMOOTH - No smoothing is performed. 

,,EOT,,*/

typedef enum smoothcrit_tag
{
    SMOOTHCRIT_INIT = -1,
    SECONDDIFF,
    FIRSTDIFF,
    NO_SMOOTH  
} SMOOTHCRIT;



/*,,SOT,,

SMOOTHPARMS : Parameters specifying the smoothness term
-------------------------------------------------------

This type is defined in fitzero.h as:

        typedef struct smoothparms_tag
        {
          SMOOTHCRIT  smcrit ;
          FL64        lambda ;
          PLAN_STR*   tlambda ;
        } SMOOTHPARMS ;

The interpretation of the data is:

        smcrit specifies which smoothness criterion to use.
        Presently model must be either SPLINEDISC, SPLINEEXPO, 
        SPLINEYIELD, SPLINEX, SPLINEF, or SPLINETRANS if smcrit 
        is different from NO_SMOOTH. . 
  
        lambda specifies the trade off between smoothness
        and goodness-of-fit. Low values correspons to a high
        degree of goodness-of-fit whereas high values means
        that the smoothness of the yield curve is emphasised. 
        Only used if smcrit differs from NO_SMOOTH and tlambda
        is NULL.

        tlambda is used the same way as lambda only this
        argument allow a time varying lambda as suggested
        in Waggoner "Spline Methods for Extracting Interest 
        Rate Curves from Coupon Bond Prices", Federal Reserve
        Bank of Atlanta Working Paper, 1997. If not used
        this argument must be set to NULL.

,,EOT,,*/

typedef struct smoothparms_tag
{
  SMOOTHCRIT  smcrit ;
  FL64        lambda ;
  PLAN_STR*   tlambda ;
} SMOOTHPARMS ;


/*,,SOT,,

CRITERIONFUNC : Parameters for specifying the criterion function
----------------------------------------------------------------

This type is defined in fitzero.h as:
  
              typedef struct criterionfunc_tag
              {
                  INTI         norm ;
                  BOOLE        doMacaulay ;
                  INTI         noweights ;
                  FL64ARRAY    weights ;
                  BOOLE        docold ;
                  BOOLE        bidask ;
                  SMOOTHPARMS  smparms ;
              }   CRITERIONFUNC ;

This struct is used to describe the criterion function used when 
fitting the parameters in a ZEROMODEL. Hence a complete description 
of the problem is obtained when combining the ZEROPARMS and the 
CRITERION struct. The arguments in this structure is only used 
if model in ZEROPARMS is not BOOTSTRAP.

The interpretation of the data is:
        
        norm specifies which norm to use in the optimization. For 
        practical purposes the choice should be restricted to 1 or 
        2 for numerical stability. 2 seems to be the value recommended
        by most textbooks. Must be a positive integer.

        If doMacaulay is True then the specified norm of residuals 
        are weighted by the Macaulay duration of each bond. If False 
        an optional weighting scheme is available using weights.
        Duration weighting in the fitting procedure might be a good 
        idea if the number of long bonds is small.

        noweights specifies the number of elements in weights. Only 
        used if doMacaulay is False. By setting noweights to 0 the 
        optimizer will not use weights.

        weights[noweights]|NULL is an array of user specified weights. Only
        used if doMacaulay is False. This argument allows the user to
        specify individual weights to each residual. For instance the
        variance of the bond prices might be a sensible weight or 
        maybe relative trade volume. The optimizer will minimize the
        norm of the residuals divided by the the numbers in the weights
        argument. Set to NULL if no weights. The number of elements is
        noweights must correspond to the number of bonds in the estimation.

        docold is True if randomized optimisation (10 estimations), False
        if not (the standard case).

        bidask True specifies that residuals are calculated such 
        that only model prices outside the bid-ask spread are punished 
        when calculating the criterion function. If False the average
        of the bid and ask price is used. 

        smparms specifies the parameters in the smoothness term. This
        argument is optional and only considered if model is either 
        SPLINEDISC, SPLINEEXPO, SPLINEYIELD, SPLINEX, SPLINEF, or 
        SPLINETRANS.

,,EOT,,*/


typedef struct criterionfunc_tag
{
    INTI         norm ;
    BOOLE        doMacaulay ;
    INTI         noweights ;
    FL64ARRAY    weights ;
    BOOLE        docold ;
    BOOLE        bidask ;
    SMOOTHPARMS  smparms ;
}   CRITERIONFUNC ;



/*,,SOT,,

ZEROPARMS : Parameters for estimation of zero-coupon term structures
--------------------------------------------------------------------

This type is defined in fitzero.h as:

        typedef struct zeroparms_tag
        {
            ZEROMODEL     model ;
            INTI          ncoef ;
            FL64ARRAY     parms ;
            FL64MATRIX    bounds ;
            FL64ARRAY     spld ;
            BOOLE         use_prep ;
        }   ZEROPARMS ;

The interpretation of the data is:

        model is the model being used for estimation.

        ncoef is the number of coefficients in the model.
        Only used if model is not BOOTSTRAP

        parms[ncoef] are the coefficients of the model, altogether ncoef.
        Only used if model is not BOOTSTRAP

        bounds[ncoef,2] are the lower and upper bounds given on parms.
        Column 1 holds the lower bounds and column 2 the upper.
        Only used if model is not BOOTSTRAP

        spld[ncoef] are the spline terms. Contains ncoef terms (in
        fractional years). Sorted ascendingly and unique.
        Only used if model is SPLINEYIELD, SPLINEDISC, SPLINEEXPO,
        SPLINEX, SPLINEF, SPLINETRANS, BSPLYLD or BRNSTYLD. If model is 
        BRNSTYLD then only spld[ncoef - 1] is used - and this should 
        represent the maximum maturity of interest. 

        Setting use_prep to True might stabilize the two ends of the
        spline but the recommended setting is False. Only used if model 
        is SPLINEYIELD, SPLINEDISC, SPLINEEXPO, SPLINEX, SPLINEF, or 
        SPLINETRANS.  


,,EOT,,*/

typedef struct zeroparms_tag
{
    ZEROMODEL     model ;
    INTI          ncoef ;
    FL64ARRAY     parms ;
    FL64MATRIX    bounds ;
    FL64ARRAY     spld ;
    BOOLE         use_prep ;
}   ZEROPARMS ;



/*
..Private
*/

typedef struct zerofitdata_tag
{
    PMTARRAY        sPMTS       ; /* Array of security cashflows */
    FL64ARRAY       sFULLPRICE  ; /* Array of prices */
    FL64ARRAY       sNORMALOAS  ; /* Array of OAS's */
    FL64ARRAY       sTSDUR      ; /* Array of TS durations */
    FL64ARRAY       sBIDASK     ; /* Array of Bid-Ask spreads */
    CRITERIONFUNC*  sCFUNC      ; /* Criterion function */
    ZEROPARMS*      sPARMS      ; /* Model parameters */
    INTI            sNSEC       ; /* Number of securities */
    TSOVARRAY       sStepLambda ; /* Stepped lambdas for smoothing */
} ZEROFITDATA;


/*,,SOT,,

FITPARMS: Parameters for estimation of zero-coupon term structures
--------------------------------------------------------------------

This type is defined in fitzero.h as:

        typedef struct fitparms_tag
        {
            INTI          nparms ;
            FL64ARRAY     parms ;
            FL64          obj ;
        }   FITPARMS ;

The interpretation of the data is:

        nparms is the number of coefficients in the parms struct.
        Only used if model is not BOOTSTRAP

        parms[nparms] are the fitted parameter values, altogether ncoef.
        Only used if model is not BOOTSTRAP

        obj is the value of the criterion function in optimum.

,,EOT,,*/

typedef struct fitparms_tag
{
    INTI          nparms ;
    FL64ARRAY     parms ;
    FL64          obj ;
}   FITPARMS ;


/*** prototypes  (zeromodl.c) *****************************************/


/* public functions */

extern TSARRAY Zero_GenrTS(FL64ARRAY coefs,
                            FL64ARRAY spld,
                            INTI      ncoef,
                            ZEROMODEL model,
                            FL64ARRAY term,
                            INTI      nterm,
                            IRRCONV   irr,
                            INTI      qbas,
                            BOOLE     use_prep) ;

extern PLANARRAY Zero_GenrDF(FL64ARRAY  coefs,
                              FL64ARRAY spld,
                              INTI      ncoef,
                              ZEROMODEL model,
                              CALCONV   cal,
                              DATESTR   *today,
                              DATEARRAY days,
                              INTI      ndays,
                              BOOLE     use_prep,
							  HOLI_STR  *holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */

extern FL64 Zero_Model2Price(FL64ARRAY coefs,
                             FL64ARRAY spld,
                             BOOLE     use_prep,
                             INTI      ncoef,
                             ZEROMODEL model,
                             PMT_STR   *pmt,
                             FL64      spread,
                             RISKCONV  risk,
                             FL64      *dp,
                             FL64      *ddp) ;

/* private functions */

extern FL64 Zero_ccw(FL64ARRAY coefs, INTI ncoef, FL64 term, FL64 spread) ;

extern FL64 Zero_vasicek(FL64ARRAY coefs, FL64 term, FL64 spread) ;

extern FL64 Zero_cir(FL64ARRAY coefs, FL64 term, FL64 spread) ;

extern FL64 Zero_cirnom(FL64ARRAY coefs, FL64 term, FL64 spread) ;

extern FL64 Zero_longsch(FL64ARRAY coefs, FL64 term, FL64 spread) ;

extern FL64 Zero_dpoly(FL64ARRAY coefs, INTI ncoef, FL64 term, FL64 spread);

extern FL64 Zero_iyext(FL64ARRAY coefs, FL64 term, FL64 spread) ;

extern FL64 Zero_extns(FL64ARRAY coefs, FL64 term, FL64 spread) ;

extern INTI Zero_prep_splines(FL64ARRAY coefs,
                              FL64ARRAY spld,
                              INTI      ncoef,
                              FL64ARRAY newcoefs,
                              FL64ARRAY newspld,
                              ZEROMODEL model) ;

extern FL64 Zero_splines(FL64ARRAY coefs,
                         FL64ARRAY spld,
                         FL64ARRAY y2,
                         INTI      ncoef,
                         ZEROMODEL model,
                         FL64      term,
                         FL64      spread) ;

extern FL64 Zero_BSPLYLD(FL64ARRAY coefs,
                  FL64ARRAY knots,
                  INTI      nknots,
                  FL64      term,
                  FL64      spread) ;

extern FL64ARRAY Zero_prep_BSPLYLD(FL64ARRAY spld,
                                   INTI      nspld) ;

extern FL64 Zero_BRNSTYLD(FL64ARRAY coefs,
                   INTI      ncoefs,
                   FL64      tmax,
                   FL64      term,
                   FL64      spread) ;



/*** prototypes  (fitzero.c) *****************************************/


/* public functions */

extern FITPARMS Fit_Cflw2TS(ZEROPARMS      *zerop,
                            CRITERIONFUNC  *cfunc,
                            INTI           nsec,
                            PMTARRAY       pmt,
                            FL64ARRAY      prices,
                            FL64ARRAY      spread,
                            FL64ARRAY      bidask,
                            TSOVARRAY      tlambda,
                            ITERCTRL       *ictrl) ;

extern BOOLE Fit_BSEC2DF(DATESTR        *today,
                         ZEROPARMS      *zerop,
                         CRITERIONFUNC  *cfunc,
                         INTI           nsec,
                         BSECARRAY      secs,
                         BOOLE          use_ba,
                         FL64ARRAY      aprices,
                         FL64ARRAY      bprices,
                         FL64ARRAY      spread,
                         FL64ARRAY      madj,
                         FL64ARRAY      pvFL,
                         DATEARRAY      settle,
                         HOLI_STR       *holi,
                         DATEARRAY      gridpts,
                         INTI           ngridpts,
                         ITERCTRL       *ictrl,
                         DFPARMS        *dfp,
                         DISCFAC        *df,
                         FITPARMS       *tsfit) ;

extern void Free_ZEROPARMS(ZEROPARMS* x);

extern void Free_CRITERIONFUNC(CRITERIONFUNC* x) ;


/* private functions */

extern PMTARRAY Alloc_PMT(INTI ns) ;
extern void Free_PMT(PMTARRAY pmt) ;

/* Watch out for compatibility with Harwell in 32 bit address mode */

extern int Zero_abs_Prices(int *ncoef,
                           int *nsec,
                           double *coefs,
                           void *data,
                           double *f) ;

extern PMTARRAY Payment_Setup(PMTARRAY  pmt,
                              INTI      nterms,
                              FL64ARRAY terms,
                              INTI      nsec) ;
 
extern FL64 Calculate_smoothness(ZEROMODEL   model,
                                 FL64        lambda,
                                 TSOVARRAY   tlambda,
                                 SMOOTHCRIT  smcrit,
                                 INTI        ncoef,
                                 FL64ARRAY   coef,
                                 FL64ARRAY   spld) ;

extern ZEROPARMS SetUp_Tanggaard(ZEROMODEL   model,
                                 INTI        nsec,
                                 PMTARRAY    pmt,
                                 FL64ARRAY   prices,
                                 FL64ARRAY   spread,
                                 FL64ARRAY   bidask,
                                 CALCONV     cal,
                                 DATEARRAY   discdates,
                                 INTI        k,
                                 FL64ARRAY   terms,
                                 ITERCTRL*   ictrl,
								 HOLI_STR  *holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */

void  SetUp_NelsonSiegel(ZEROPARMS*      zero, 
                         CRITERIONFUNC*  cfun) ; 


extern SMOOTHPARMS Set_SMOOTHPARMS(SMOOTHCRIT  smcrit,
                            FL64        lambda,
                            PLAN_STR*   tlambda);

/*** prototypes  (factor.c) *****************************************/


/* public functions */

extern BOOLE Zero_Model2Factors(ZEROMODEL   model, 
                                DATEARRAY   dates, 
                                FL64MATRIX  parms,
                                INTI        ndate, 
                                INTI        ncoef, 
                                FL64ARRAY   spld, 
                                FL64ARRAY   tstimes,
                                INTI        nts, 
                                FL64        tol,
                                BOOLE       use_prep,
                                FL64MATRIX  loads, 
                                FL64MATRIX  correl, 
                                INTI        *nfact) ;

/* private functions */

extern INTI Zero_Genr_returns(FL64MATRIX returns, ZEROMODEL model, 
                      DATEARRAY dates, FL64MATRIX parms, INTI ndate, 
                      INTI ncoef, FL64ARRAY spld,
                      FL64ARRAY tstimes, INTI nts, BOOLE use_prep) ;

extern void Zero_scale_factors(FL64MATRIX u, INTI m, INTI n, FL64ARRAY w,
                       FL64MATRIX v, INTI nfact, FL64ARRAY contr) ;

extern void Zero_Genr_correl(FL64MATRIX actualreturns, INTI ndates, 
                                INTI nterms, FL64MATRIX u, INTI nfactor, 
                                FL64MATRIX v, FL64MATRIX correl) ;

extern FL64 Zero_correl_matrix(FL64MATRIX x, FL64MATRIX y, INTI m, INTI n) ;



#ifdef __cplusplus
}
#endif

#endif

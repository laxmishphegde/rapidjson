/* SCID @(#)cap.h	1.27 (SimCorp) 99/10/08 13:39:58 */

#ifndef CAP_H
#define CAP_H

/************************************************************************
*                                                                       *
*    project    SCecon                                                  *
*                                                                       *
*    filename   cap.h                                                   *
*                                                                       *
*    this file contains definitions and function prototyping for the    *
*    routines in the SCecon cap/floor pricing module.                   *
*                                                                       *
************************************************************************/

/*** includes **********************************************************/
#include <option.h>
#include <swapval.h>

#ifdef __cplusplus
extern "C" {
#endif

/*** typedefs **********************************************************/

/*,,SOT,,

IRG_STR and IRGARRAY : types for holding caplet/floorlet info
-------------------------------------------------------------

IRG_STR is a type for holding the information needed on IRG's
(caplet/floorlet), caps or floors.
The IRG_STR type is defined as:

        typedef struct irg_str_tag
        {
            OPTTYPE type ;
            FL64    strike ;
            DATESTR fix_start ;
            DATESTR fix_end ;
            DATESTR pay_day ;
            DATESTR period_start ;
            DATESTR period_end ;
            FL64    size ;
            FL64    LIBORfix ;
        }   IRG_STR ;

The elements of IRG_STR have the following interpretations

        type is the option type, that is CALL, PUT or STRADDLE,

        strike is the strike rate - annualised in percent.

        fix_start is the fixing date

        fix_end is end date of the fixing period

        pay_day is the payday of the IRG. Usually this is equal to fix_end
        but some payment delay may be imposed. Also for arrears caps it 
        should be equal to fix_start.

        period_start is the start of the period for which the fixed rate
        accrues. Usually this is equal to fix_start but for arrears caps
        it should be equal to the start of previous period.

        period_end is the end of the period for which the fixed rate
        accrues. Usually this is equal to fix_end but for arrears caps
        it should be equal to fix_start.

        size is the notional amount - multiplied on the payoff.

        LIBORfix is used for IRG's where the fixing date has been passed.
        In the period between fixing and payout the cap value should
        include the PV of the payout (if any) from the next IRG.
        For any IRG that has not passed fixing this info is not used.


IRGARRAY is the type needed for handling lists of IRG's or caps/floors.
The definition of the IRGARRAY type is:

    typedef IRG_STR  * IRGARRAY ;

see also Set_IRG_STR

,,EOT,,*/


typedef struct irg_str_tag
{
    OPTTYPE type ;
    FL64    strike ;
    DATESTR fix_start ;
    DATESTR fix_end ;
    DATESTR pay_day ;
    DATESTR period_start ;
    DATESTR period_end ;
    FL64    size ;
    FL64    LIBORfix ;
}   IRG_STR ;

typedef IRG_STR  * IRGARRAY ;


/*,,SOT,,

CAPLETS and CAPLETSARRAY: types for holding lists of caps
---------------------------------------------------------

This data type can hold information about a cap - i.e. a portfolio of
caplets or floorlets.

The type is defined as:

        typedef struct caplets_tag
        {
            INTI        count ;
            CALCONV     cal ;
            EOMCONV     eom ;
            QOTCONV     qot ;
            PMTFREQ     freq ;
            IRGARRAY    irg ;
            RATEINDEX   index ;
            COMPMETHOD  method ;
            PMTFREQ     compfreq ;

            OPTADD      oadd ;
            ASIANINF    asian ;
            BINARYINF   bini ;
            CONTPREMINF ctp ;
            SHARKFININF sfin ;
            RESETINF    reset ;
        }   CAPLETS ;

The data should be interpreted as:

        count    The element informs about the number of caplets in the 
                 cap, i.e irg's in irg.

        cal, 
        eom,
        qot      Conventions defined for all caplet's

        freq     The reset frequency of the cap.

        irg[count] List of individual caplets holding information 
                 specific to each caplet. Note that using size 
                 amortising caps can be defined, and using individual 
                 paydays irregular caps can be defined. Also strike 
                 can vary over the life of the cap/floor. Finally note 
                 that collars, piras etc can be defined in a single 
                 CAPLETS, since the same period can be multiply defined
                 in a CAPLETS. By letting equal periods represent put 
                 and calls option strategies can easily be defined.
                 Generate this list using Caplets_GenrIRGARRAY().

        index    index->LIBORtype defines the type of index:
            
                 MMRATE    -> Standard *IBOR index (e.g. 6 MONTHS USD 
                              LIBOR). Only LIBORterm, LIBORunit used.
                 BILLDISC  -> For South African Caps quoted as a 
                              DISCOUNT rate. Only LIBORterm, LIBORunit 
                              used.
                 BILLYIELD -> For Australian Caps (bank bill yield 
                              caps). Only LIBORterm, LIBORunit used
                 PARYIELD  -> Constant Maturity Caps. index->LIBORfreq
                              defines the frequency of the undelying 
                              index. I.e SEMIANNUALLY for (USD) CMT, 
                              and ANNUALLY for the (FRF) TEC index.
                              LIBORterm, LIBORunit and LIBORfreq used.

                for vanilla caps use 
                      {MMRATE, 3 or 6, MONTHS, NO_FREQUENCY}, 
                where  LIBOR duration is equal to the fixing period.

        method  The compounding method (according to ISDA conventions).
                   Currently only NONE and DECOMPOUND are supported.

        compfreq  Compounding frequency. When method is not NONE it 
                should be 'less' than the payment frequency. 
                E.g semiannual payments and quarterly compounding 
                (means 2 compounding periods). Use NO_FREQUENCY if 
                no compounding.

        oadd    Indicates whether additional features are used. 
                Default is NO_OPTADD. If oadd is not NO_OPTADD some 
                'exotic' option features can be defined as follows:

        oadd = ASIAN:
        asian defines the data needed for asian (average-rate) options.
        asian.davg1 and asian.davgN are NOT used, since the averaging
        periods follow the fixing periods of the individual caplets.
        asian.curr_avg describes the current average in the current period
        for secondary caps. Once the FINAL fixing is known, it should be
        set in asian.last_avg.
        If asian.avgrt is False then the current and FINAL average are in
        asian.curr_avg,
        asian.last_avg and the current LIBOR fixing is in LIBORfix.
        If the cap is seasoned and valued before settlement, ie after
        the fixing period but before the pay-off payment, then 
        asian.last_avg must set. Otherwise it is not used.

        oadd = BINARY:
        bini defines a binary option

        oadd = CONTPREM:
        ctp defines a contingent premium option which is the same
        for all caplets. This makes a contingent premium cap different
        from a portfolio of contigent premium caplets having individual
        contingent premiums.

        oadd = SHARKFIN:
        sfin defines data for a barrier cap.
        Barrier caps are defined so that the barrier is only active on
        the fixing date (this is almost always the case).
        All payoff's are supported.

        oadd = RESET:
        reset containes data for 'reset' or 'periodic' caps
        for which the strike of a caplet is given by a fixing of the
        index rate + a spread.
        resets occur every n'th fixing day, n=1,2...,
        until first reset given strikes are used.
        When pricing reset caps one should be careful about choosing
        volatility curves. Reset caps are forward starting instrument
        and the vol should reflect. On eway of calculating vol for
        reset caps is to take a FORWFORW vol curve and use Vol_Spot2Forw()
        to generate a forward starting vol curve. The dates for which
        to calculate the forward starting vol are the reset days 
        respectively the fixing days. These forward starting vols are then
        entered in a VOL_STR on the fixing dates.


To handle arrays or portfolios of caps another datatype has been defined,
namely a CAPLETSARRAY.
This is defined as

    typedef CAPLETS * CAPLETSARRAY ;

The CAPLETSARRAY can hold information about a list of caps. This is 
relevant when bootstrapping a forward volatility curve from a list of 
quoted caps. Consult the routine Boot_Caplets2B76ol() for a routine, 
that bootstraps a volatility curve.

see also Set_CAPLETS

,,EOT,,*/

typedef struct caplets_tag
{
    INTI        count ;
    CALCONV     cal ;
    EOMCONV     eom ;
    QOTCONV     qot ;
    PMTFREQ     freq ;
    IRGARRAY    irg ;
    RATEINDEX   index ;
    COMPMETHOD  method ;
    PMTFREQ     compfreq;

    OPTADD      oadd ;
    ASIANINF    asian ;
    BINARYINF   bini ;
    CONTPREMINF ctp ;
    SHARKFININF sfin ;
    RESETINF    reset ;
}   CAPLETS ;

typedef CAPLETS  * CAPLETSARRAY ;



/*,,SOT,,

B76SM: Black76 swaption model types.
------------------------------------

This type is defined as:

        typedef enum b76sm_tag
        {
            B76SM_RATE,
            B76SM_RATEPA,
            B76SM_PRICE,
            B76SM_SCORIG
        }   B76SM ;

where the various Black76 type of swaption models are formulated as:

        B76SM_RATE defines the model formulated in the forward SWAPRATE.
        This seems to be the market standard, and used as default
        if nothing else is chosen in Swaption_Black2P().
        This model does handle some exotic variations for swaptions using
        variations of the Black76 model.

        B76SM_RATEPA defines the model formulated in the SWAPRATE, but the
        price quoted as a per annum forward quote.
        This model does not handle exotic variations for swaptions.

        B76SM_PRICE defines the model formulated in the forward PRICE
        of the underlying swap. Where the vol is for the actual swaprate.
        Assumes that the option is swap settled.
        This model does not handle exotic variations for swaptions.

        B76SM_SCORIG defines the model formulated in the forward PRICE
        of the underlying swap. Here the vol is defined for an at-the-money
        swap. This is the original SCecon model.
        Assumes that the option is swap settled.
        This model does not handle exotic variations for swaptions.

The reason why these different formulation have been chosen is that
basically the Black 76 model for swaptions is an approximation, and there
exist various approaches for doing this approximation. 

Note that the Black (76) model for swaptions works well for vanilla swaptions
with fairly general fixed legs (incl. amortisations) and with vanilla
floating legs (incl. a spread and amortisations). Extensions with libor
factors and indices differing from the roll frequency are essentially just
quick and dirty approximations. In these case with more elaborate floating
legs one needs a Term Structure Model (as implemented in Swaption_HW2P() ).

,,EOT,,*/

typedef enum b76sm_tag
{
    B76SM_RATE,
    B76SM_RATEPA,
    B76SM_PRICE,
    B76SM_SCORIG
}   B76SM ;


/*,,SOT,,

B76SWTM: Type for holding Black76 Swaption Model Data
-----------------------------------------------------

This type is defined as:

        typedef struct b76swtm_tag
        {
            B76SM b76sm ;
            BOOLE use_fwd ;
            FL64  fwdswap ;
        }   B76SWTM ;

where

        b76sm defines the model variation.

        use_fwd is True is fwdswap are to be used for valuation, and False
        if not (only relevant if b76sm is B76SM_RATE and cash settlement).

        fwdswap defines the forward swap rate to be used for cash settled
        options in the valuation (only if b76sm is B76SM_RATE).

In the Swaption_Black2*() routines use NULL for the default model.

,,EOT,,*/

typedef struct b76swtm_tag
{
    B76SM b76sm ;
    BOOLE use_fwd ;
    FL64  fwdswap ;
}   B76SWTM ;


/*,,SOT,,

FLEXICAPINF: Definition of data for flexi-caps
----------------------------------------------

This data container is defined as

        typedef struct flexicapinf_tag
        {
            BOOLE  autoflex ;
            INTI   n_caplets;
        } FLEXICAPINF;

for holding info on flexi-caps.

The data are interpreted as
        
  autoflex  defines the type of exercise strategy that can be
            considered. The interpretation is as follows

            False - You-choose
                  means that a caplet is exercised if the strike value
                  of one caplet and the hold value of a flexible cap
                  with one caplet less exceeds the hold value of
                  flexible cap with all caplets remaining.

            True  - Auto
                  means that a caplet is exercised if the strike value
                  of one caplet is positive.

  n_caplets Defines the maximum number of caplets/floorlets to be
            exercised on the cap/floor. If this number is equal to the
            number of caplets/floorlets on the cap/floor, then the
            price of the flexi-cap will be identical to that of the
            cap.

Note that neither of the flexi-caps definable here can be priced
properly using the Black-76 framework. Auto-exercise flexi-caps can
be priced using either lattice (Cap_HW2P()) or Monte-Carlo Simulation
(MC_BGM2PV()). You-choose flexi-caps involve a bermudan decision
problem and can only be priced using a lattice.

See also Set_FLEXICAPINF()

,,EOT,,*/

typedef struct flexicapinf_tag
{
    BOOLE  autoflex ;
    INTI   n_caplets;
} FLEXICAPINF;


/*,,SOT,,

SWPTBARRINF: Definition of data for barrier swaption
----------------------------------------------------

This data container is defined as

        typedef struct swptbarrinf_tag
        {
            PERIOD    tenor ;
            PMTFREQ   freq ;
            CALCONV   cal ;
            FL64      rate ;
            DATESTR   first ;
            DATESTR   last ;
            PERIOD    per_barr ;
            KNOCKTYPE type ;
        }   SWPTBARRINF ;

for holding info on barrier swaptions

The data are interpreted as
        
            tenor is the length of the barrier rate (i.e. the rate based on
            which the option knock in or out). This can be equal to the tenor
            of the swap underlying the option or it can differ. I.e one can
            define an option on a 5Y swap that knocks out if the 

                a) the 5Y swap rate exceeds a barrier
                b) the 10Y swap rate exceeds a barrier
                c) 6M LIBOR exceeds a barrier

            freq is the roll frequency of the rate that defines the barrier.
            E.g. SEMIANNUALLY for a swaprate or NO_FREQUENCY for LIBOR.

            cal is the calendar for the barrier rate

            rate is the actual barrier level (e.g 6.55)

            first is the first date on which the barrier is active

            last is the last active barrier date

            per_barr is the barrier sampling frequency.
            If the length of the period is positive then the barrier is 
            discretely sampled, and if it is 0 then it is continuously
            sampled.

            type is the barrier type

,,EOT,,*/

typedef struct swptbarrinf_tag
{
    PERIOD    tenor ;
    PMTFREQ   freq ;
    CALCONV   cal ;
    FL64      rate ;
    DATESTR   first ;
    DATESTR   last ;
    PERIOD    per_barr ;
    KNOCKTYPE type ;
}   SWPTBARRINF ;


/*,,SOT,,

SWAPTION and SWAPTIONARRAY: European Style Swap Options type.
-------------------------------------------------------------

This type is defined as:

        typedef struct swaption_tag
        {
            OPTTYPE     type ;
            DATESTR     maturity ;
            CALCONV     cal ;
            BOOLE       swapstl ;
            FIXRATE     fix ;
            PAYDAYDEF   pfix ;

            BOOLE       vanilla ;
            FLOATBASE   fbase ;
            RATEINDEX   index ;
            FL64        factor ;
            PAYDAYDEF   pfl ;
            PLAN_STR    *amort ;

            OPTADD      oadd ;
            BINARYINF   bini ;
            CONTPREMINF ctp ;
            COMPOPTINF  compo ;
            FWDSTARTINF fwdst ;
            CHOOSERINF  chos ;
            SWPTBARRINF sbarr ;
        }   SWAPTION ;

The swaptions defined here are options into fixed vs floating swaps.
The data elements have the following interpretation:

    type    defines the option type. The definitions imply that:

            CALL - Receiver Swaption - i.e. option on swap receiving fixed
            PUT  - Payer Swaption    - i.e. option on swap paying fixed
            STRADDLE - Buy CALL and PUT with same strike

    maturity  is the maturity date of the option.

    cal     is the calendar convention for finding the term till
            option maturity

    swapstl is True if the option is swap settled, and False if it is
            cash settled.

    fix     is the definition of the fixed side of the swap.
            In particular the option strike is the fixed rate (fix.fix_rate),
            the swap start is fix.effective and the daycount is fix.cal.
            fix.stepcoup is NOT used.

    pfix    is the definition of the paydays of the fixed leg of the swap.


    vanilla defines whether the floating side is vanilla or not.
            If True none of the remaing fields are used and the float leg
            values at 100 when the float side is issued (this is the NORMAL
            case).
            If False then the float side possibly does NOT value to 100, 
            and all remaining fields are taken into account to find the 
            float value (as for options on CMT swaps etc).

    fbase   defines the float leg payment calculations.

    index   defines the underlying index of the floating side of the swap.
            Use this to define CM swaptions.

    factor  is a factor on the floating leg - used to describe options
            on leveraged / deleveraged swaps (e.g fix - 2 * LIBOR).
            Default is 1.0.

    pfl     is the definition of the paydays of the float leg of the swap.

    amort|NULL is a definition of an amortisation schedule, for amortising
            swaptions.
            Use NULL to define no amortisations.
            Amortisations can be on any date, but would typically be on 
            swap paydays. Must sum to 100. The amortisations are the same
            for the fixed and floating legs.

    oadd    defines any exotic behaviour. Ignored if vanilla is True. 
            Defualt is NO_OPTADD

            oadd = NO_OPTADD
            No exotic behaviour (default situation).

    bini    (oadd = BINARY)
            defines a binary option payoff for the swap option.

    ctp     (oadd = CONTPREM)
            defines a contingent premium swaption. The contingent premium
            is in price terms.

    compo   (oadd = COMPOPT)
            defines a compound option on the swaption.

    fwdst   (oadd = FWDSTART)
            defines a forward starting option, i.e a swaption where
            the strike is fixed at a future date.

    chos    (oadd = CHOOSER)
            defines a (simple) chooser swaption

    sbarr   (oadd = SWPTBARR)
            defines a barrier swaption, the sbarr data defines
            the barrier, that can be in a different index and partial
            (i.e. only effective for part of the period).

European-Style Swap options are swaptions where the terms (dates) of the
swap are known from the start of the option.

List's of swaption can be held using the type SWAPTIONARRAY defined as:

        typedef SWAPTION * SWAPTIONARRAY ;

see also Set_SWAPTION(), or Swaption_Simple2SWAPTION() for routines that
can set the SWAPTION type using simple data.

,,EOT,,*/

typedef struct swaption_tag
{
    OPTTYPE   type ;
    DATESTR   maturity ;
    CALCONV   cal ;
    BOOLE     swapstl ;
    FIXRATE   fix ;
    PAYDAYDEF pfix ;

    BOOLE     vanilla ;
    FLOATBASE fbase ;
    RATEINDEX index ;
    FL64      factor ;
    PAYDAYDEF pfl ;
    PLAN_STR  *amort ;

    OPTADD      oadd ;
    BINARYINF   bini ;
    CONTPREMINF ctp ;
    COMPOPTINF  compo ;
    FWDSTARTINF fwdst   ;
    CHOOSERINF  chos ;
    SWPTBARRINF sbarr ;
}   SWAPTION ;

typedef SWAPTION * SWAPTIONARRAY ;

/*
..currently private
SWPTVOL: A type for holding info on Swaption Volatilities
---------------------------------------------------------

This type is defined as:

        typedef struct swptvol_tag
        {
            INTIARRAY  opt_mnth ;
            INTI       no ;
            INTIARRAY  swp_mnth ;
            INTI       ns ;
            FL64MATRIX vol ;
            CALCONV    cal ;
            INTPOLCONV iconv ;
            FL64       skew ;
        }   SWPTVOL ;

It is used for storing at-the-money swaption volatilities.

The data elements have the following interpretation:

        opt_mnth is a list of the option maturities - quoted in months

        no is the number of elements in opt_mnth

        swp_mnth is a list of the swap maturities - quoted in months

        ns is the number of elements in swp_mnth

        vol is the volatility matrix (percentage entries). vol is indexed
        as vol[0...(no-1)][0...(ns-1)]. These vols have been calibrated
        using a matrix of ATM options.

        cal is the calendar for interpolating

        iconv is the interpolation convention (use LINEAR_EXTRAPOL or
        CUBIC_SPLINE)

        skew is a skew factor for handling out-of-the-moneyness sometimes
        referred to as 'the smile'. A volatility interpolated in the 2D
        surface are translated 'out-of-the-money' using skew as:

                vol = volATM * (1 + (skew * log (fwd / strike))^2)

        where volATM is the at-the-money volatility level.

*/

typedef struct swptvol_tag
{
    INTIARRAY  opt_mnth ;
    INTI       no ;
    INTIARRAY  swp_mnth ;
    INTI       ns ;
    FL64MATRIX vol ;
    CALCONV    cal ;
    INTPOLCONV iconv ;
    FL64       skew ;
}   SWPTVOL ;


/*,,SOT,,

CAP and CAPARRAY: Data structure for holding Cap's, Floor's or IRG's.
---------------------------------------------------------------------

This type is defined as:

        typedef struct cap_tag
        {
            OPTTYPE     type ;
            FL64        strike ;
            CALCONV     cal ;
            PAYDAYDEF   fix_days ;
            FL64        notional ;
            FL64        LIBORfix ;

            BOOLE       vanilla ;
            FL64        factor ;       
            PERIOD      delay ;
            QOTCONV     qot ;
            RATEINDEX   index ;
            COMPMETHOD  method ;
            PMTFREQ     compfreq ;
            BOOLE       arrears ;
            BOOLE       margin ;
            BOOLE       qprice ;
            PLAN_STR    *step_str ;
            PLAN_STR    *step_not ;

            OPTADD      oadd ;
            ASIANINF    asian ;
            BINARYINF   bini ;
            CONTPREMINF ctp ;
            SHARKFININF sfin ;
            RESETINF    reset ;
            FLEXICAPINF flexicap;
        }   CAP ;

For defining interest rate options (cap, floor, collar on various rates).
  
The data should be interpreted as:

    type    is the option type - CALL (Cap), PUT (Floor) or STRADDLE

    strike  is the strike rate (e.g. 6.0 for 6%)
            for secondary RESET caps this is the strike for the 
            fixed caplet

    cal     is the calendar for calculating the forward rates

    fix_days defines the fixing (reset) days of the cap.
            fix_days.last is the first day in the last notional FRA period.

    notional amount of the cap (typically 100.0 or 10000.0)

    LIBORfix is the current fixing value of the underlying index
            used for secondary caps.

    vanilla  Defines whether the remaining values are used.
             If True all remaining are ignored.

    factor   is used for vanilla option payoffs. Here the payoff is 
             defined as (for a CALL):

                Notional * Max(factor * F - X, 0) 

             where X is the strike and F the relevant forward rate.
             Default is of course 1.0. For exotic payoffs factor is 
             not used.

    delay    is the payment delay. Payment typically occur after the
             fixing period - except for arrears cap where it is a 
             period of delay after the fixing dates.

    qot      is the quoting - typically Q_FLAT.

    index    Defines the capped (or floored) index.
             index->LIBORtype defines the type of index:
        
              MMRATE    -> Standard *IBOR index (e.g. 6 MONTHS USD LIBOR)
                           Only LIBORterm, LIBORunit used
              BILLDISC  -> For South African Caps quoted as a DISCOUNT rate
                           Only LIBORterm, LIBORunit used
              BILLYIELD -> For Australian Caps (bank bill yield caps)
                           Only LIBORterm, LIBORunit used
              PARYIELD  -> Constant Maturity Caps. index->LIBORfreq
                           defines the frequency of the underlying index. I.e
                           SEMIANNUALLY for (USD) CMT, and ANNUALLY for
                           the (FRF) TEC index.
                           LIBORterm, LIBORunit and LIBORfreq used
              REX       -> REX cap. All values in index are used.

             for vanilla caps use {MMRATE, 3 or 6, MONTHS, NO_FREQUENCY}, 
             where LIBOR duration is equal to the fixing period.

    method   The compounding method (according to ISDA conventions).
             Currently only NONE and DECOMPOUND are supported.

    compfreq Compounding frequency. When method is not NONE it 
             should be 'less' than the payment frequency. 
             E.g semiannual payments and quarterly compounding 
             (means 2 compounding periods). Use NO_FREQUENCY if 
             no compounding.

    arrears  is False for standard caps and True for arrears caps. An 
             arrears cap is like a standard cap except that the rate
             used to compute the payoff is the fixing rate of the next 
             period. A pay delay is often a part of the contract as 
             fixing day and payment day will collide otherwise.
               Note that period for which the rate accrues, i.e. the
             period which is multiplied the payoff, is the period
             prior to the payment day and not the period of the 
             (forward) fixing period.

    margin   is normally False. True for exchange traded options with
             margining.

    qprice   is normally False. False means that the strike is quoted as a
             rate (e.g 6.0%). True means that the strike is quoted as a price
             (e.g 94.0), this is typically used for exchange traded options.
             Note that a CALL (price) = PUT(rate) and vice versa. We use the
             rate convention here.

    step_str|NULL is a list of stepped strikes.
             A NULL value indicates an empty array.

    step_not|NULL is a list of stepped notional amounts (for defining
             amortising / accreting caps).
             A NULL value indicates an empty array.

    oadd     indicates whether additional features are used. Default is
             NO_OPTADD. If oadd is not NO_OPTADD some 'exotic' option 
             features can be defined as follows:

    asian    (oadd = ASIAN)
             Defines the data needed for asian (average-rate) options.
             asian.davg1 and asian.davgN are NOT used, since the averaging
             periods follow the fixing periods of the individual caplets.
             asian.curr_avg describes the current average in the current 
             period for secondary caps. Once the FINAL fixing is known, it 
             should be set in asian.last_avg.
             If asian.avgrt is False then the current and FINAL average are in
             asian.curr_avg,
             asian.last_avg and the current LIBOR fixing is in LIBORfix.
             If the cap is seasoned and valued before settlement, ie after
             the fixing period but before the pay-off payment, then 
             asian.last_avg must set. Otherwise it is not used.

    binary   (oadd = BINARY)
             Defines a binary option

    ctp      (oadd = CONTPREM)
             Defines a contingent premium option which is the same
             for all caplets. This makes a contingent premium cap different
             from a portfolio of contigent premium caplets having individual
             contingent premiums.

    sbar     (oadd = SHARKFIN)
             Defines data for a barrier cap.
             Barrier caps are defined so that the barrier is only active on
             the fixing date (this is almost always the case).
             All payoff's are supported.

    reset    (oadd = RESET)
             reset containes data for 'reset' or 'periodic' caps
             for which the strike of a caplet is given by a fixing of the
             index rate + a spread.
             resets occur every n'th fixing day, n=1,2...,
             until first reset given strikes are used.
             When pricing reset caps one should be careful about choosing
             volatility curves. Reset caps are forward starting instrument
             and the vol should reflect this. One way of calculating vol for
             reset caps is to take a FORWFORW vol curve and use 
             Vol_Spot2Forw() to generate a forward starting vol curve. The 
             dates for which to calculate the forward starting vol are the 
             reset days respectively the fixing days. These forward 
             starting vols are then entered in a VOL_STR on the fixing dates.

    flexicap (oadd = FLEXICAP)
             Defines additional data for a flexi-cap/floor on which
             only a limited number of options can be exercised while
             remaining options are forfeited.


see also Set_CAP, or Cap_Simple2CAP() for routines that set a CAP based
on simple input data.

To handle arrays or portfolios of caps another datatype has been defined,
namely a CAPARRAY.
This is defined as

    typedef CAP * CAPARRAY ;

The CAPARRAY can hold information about a list of caps. This is 
relevant when bootstrapping a forward volatility curve from a list of 
quoted caps. Consult the routine Boot_Cap2B76Vol() for a routine, 
that bootstraps a volatility curve.

,,EOT,,*/

typedef struct cap_tag
{
    OPTTYPE    type ;
    FL64       strike ;
    CALCONV    cal ;
    PAYDAYDEF  fix_days ;
    FL64       notional ;
    FL64       LIBORfix ;

    BOOLE      vanilla ;
    FL64       factor ;       /* Vanilla only */
    PERIOD     delay ;        /* After fix_end, for NON-Arrears
                                 After fix_start for Arrears */
    QOTCONV    qot ;
    RATEINDEX  index ;
    COMPMETHOD method ;
    PMTFREQ    compfreq ;
    BOOLE      arrears ;
    BOOLE      margin ;
    BOOLE      qprice ;
    PLAN_STR   *step_str ;
    PLAN_STR   *step_not ;
/*
..spread (remove from RESETINF) 
*/

    OPTADD      oadd ;
    ASIANINF    asian ;
    BINARYINF   bini ;
    CONTPREMINF ctp ;
    SHARKFININF sfin ;
    RESETINF    reset ;
    FLEXICAPINF flexicap;
}   CAP ;

typedef CAP * CAPARRAY;


/*,,SOT,,

CAPTION: Type for holding info on Options on Caps / Floors / IRG's
------------------------------------------------------------------

The type is defined as:

        typedef struct caption_tag
        {
            OPTTYPE   type ;
            BOOLE     berm ;
            PAYDAYDEF dpay ;
            FL64      strike ;
            PLAN_STR  *step_strike;
            CAP       cap ;
        }   CAPTION ;

The data have the following interpretation:

        type defines the option type.

        berm defines the exercise days of the option. Use True for
        Bermudan style exercise with discretely spaced exercise days
        (including European style exercise). Use False for American
        style exercise with exercise on all days.

        dpay describes the exercise days. For American exercise (berm = False)
        only .first and .last are used as the first and last exercise
        days.
        
        strike is the strike price for the cap at exercise. 

        step_strike is a list of stepped strikes. Use NULL as default,
        in which case strike is used all the time. If step_strike is filled
        then strike is only used before the first date in step_strike.

        cap defines the underlying cap.
        Quoting convention (cap->qot) is assumed as Q_FLAT. Option pay-off 
        (cap->oadd) can be BINARY, CONTPREM or NO_OPTADD. Compounding 
        (cap->method, cap->compfreq) is not supported.

,,EOT,,*/

typedef struct caption_tag
{
    OPTTYPE   type ;
    BOOLE     berm ;
    PAYDAYDEF dpay ;
    FL64      strike ;
    PLAN_STR  *step_strike;
    CAP       cap ;
}   CAPTION ;


/*,,SOT,,

SWAPCALL: Callable Par Swaps
----------------------------

This type is defined as:

        typedef struct swapcall_tag 
        {
          BOOLE     pay_fix ;
          BOOLE     extend ;
          BOOLE     berm ;
          DATESTR   first_call ;
          DATESTR   last_call ;
          CALCONV   cal ;
          FIXRATE   fix ;
          PAYDAYDEF pfix ;
        } SWAPCALL;

The callable par swaps defined here are par swaps that can be
either extended or cancelled on a prespecified date or on a range of
payment days.
The data elements have the following interpretation:

  pay_fix    Determines whether the par swap pays fixed (choose: True)
             or receives fixed (choose: False).

  extend     Determines whether the par swap is extendible (choose: True)
             or cancellable (choose: False).

  berm       Bermudan callable. If True, the swap is cancelable on all
             payment days (pfix) between the dates first_call and
             last_call. If False, then the swap may only be cancelled or
             extended on the date specified by last_call.
             Extendible swaps cannot be bermudan, so berm must be False
             when extend is set to True.

  first_call The start of the call period. first_call is only used for
             Bermudan callable swaps (berm = True).

  last_call  The end of the call period for Bermudan callable swaps
             (berm = True). The call date for European callable swaps
             (berm = False).

  cal        The calendar convention for finding the term till the call
             date.

  fix        Defines the coupons or the fixed side of the par swap

  pfix       Defines the coupon payment dates of the par swap.
             'pfix.pseq.last' must be the final payment date of
             the swap (as if it was extended or not cancelled),
             ie 'pfix.pseq.last' must be later than 'last_call'.
             pfix.irreg_days is NOT supported.


see also Set_SWAPCALL, or SwapCall_Simple2SWAPCALL() for routines that
can set the SWAPCALL type using simple data.

,,EOT,,*/


typedef struct swapcall_tag 
{
  BOOLE     pay_fix ;
  BOOLE     extend ;
  BOOLE     berm ;
  DATESTR   first_call ;
  DATESTR   last_call ;
  CALCONV   cal ;
  FIXRATE   fix ;
  PAYDAYDEF pfix ;
} SWAPCALL;



typedef struct swapcallint_tag
{
  DATESTR*   analys;
  DATESTR*   voldate;
  FL64       vol;
  SWAPCALL*  swap;
  DISCFAC*   df;
  HOLI_STR*  holi;
  B76SWTM*   b76t;
  FL64       p, shock;
} SWAPCALLINT;



typedef struct 
{
    DATESTR    *analys;
    DATESTR    *voldate;
    FL64       price;
    CAPLETS    *cap;
    SWAPTION   *ncsw;
    DISCFAC    *df_index;
    DISCFAC    *df_disc;
    FL64       vol;
    VOL_STR    *volstr;
    CMCONVADJ  *cmadj;
    HOLI_STR   *holi;
    B76SWTM    *b76t;
    RISKSET    *risk;
    KEYCONV    what;
    FL64       shock;
}   BLCKINT ;


/*** Prototyping   *****************************************************/

/*** routines in capalloc.c ********************************************/


/* Public functions */
extern IRGARRAY Alloc_IRGARRAY(INTI n) ;

extern void Free_IRGARRAY(IRGARRAY date) ;

extern CAPLETSARRAY Alloc_CAPLETSARRAY(INTI nstr, INTI np, BOOLE sub) ;

extern void Free_CAPLETSARRAY(CAPLETSARRAY s, INTI  nstr) ;

extern SWAPTIONARRAY Alloc_SWAPTIONARRAY(INTI n) ;

extern void Free_SWAPTIONARRAY(SWAPTIONARRAY vector) ;

extern OPTFUTARRAY Alloc_OPTFUTARRAY(INTI n) ;

extern void Free_OPTFUTARRAY(OPTFUTARRAY vector,INTI n) ;

extern void Free_CAP(CAP *s) ;

extern void Free_SWAPTION(SWAPTION *s) ;

extern CAPARRAY Alloc_CAPARRAY(INTI n) ;

extern void Free_CAPARRAY(CAPARRAY s, INTI nstr, BOOLE sub) ;


/*** routines in caplets.c *************************************************/


/* Public functions */
extern FL64 Caplets_Black2P(DATESTR   *analys,
                     DATESTR   *voldate,
                     CAPLETS   *cap,
                     DISCFAC   *df_offer,
                     DISCFAC   *df_disc,
                     VOL_STR   *vol,
                     CMCONVADJ *cmadj,
                     HOLI_STR  *holi,
                     RISKSET   *risk,
                     FL64      *dp,
                     FL64      *ddp) ;

extern FL64ARRAY Caplets_Black2P_Array(DATESTR   *analys,
                     DATESTR   *voldate,
                     CAPLETS   *cap,
                     DISCFAC   *df_offer,
                     DISCFAC   *df_disc,
                     VOL_STR   *vol,
                     CMCONVADJ *cmadj,
                     HOLI_STR  *holi,
                     FL64ARRAY *forwfixp,
                     INTIARRAY *caplngthp) ;

extern FL64ARRAY Caplets_Black2Delta(DATESTR   *analys,
                     DATESTR   *voldate,
                     CAPLETS   *cap,
                     DISCFAC   *df_index,
                     DISCFAC   *df_disc,
                     VOL_STR   *vol,
                     CMCONVADJ *cmadj,
                     HOLI_STR  *holi,
                     DELTASET  *ds) ;

extern BOOLE Caplets_Black2Impl(DATESTR *analys,
                 DATESTR   *voldate,
                 FL64      price,
                 CAPLETS   *cap,
                 DISCFAC   *offer,
                 DISCFAC   *disc,
                 VOL_STR   *vol1,
                 CMCONVADJ *cmadj,
                 HOLI_STR  *holi,
                 KEYCONV   what,
                 ITERCTRL  *ictrl,
                 FL64      *res) ;

extern IRGARRAY Caplets_GenrIRGARRAY(PAYDAYDEF  *pday,
                      OPTTYPE type,
                      FL64    strike,
                      FL64    size,
                      HOLI_STR *holi,
                      INTI     *nirg) ;

extern IRG_STR Set_IRG_STR(OPTTYPE type,
                            FL64    strike,
                            DATESTR *fix_start,
                            DATESTR *fix_end,
                            DATESTR *pay_day,
                            DATESTR *period_start,
                            DATESTR *period_end,
                            FL64    size,
                            FL64    LIBORfix) ;

extern CAPLETS Set_CAPLETS(INTI        count,
                CALCONV     cal,
                EOMCONV     eom,
                QOTCONV     qot,
                PMTFREQ     freq,
                IRGARRAY    irg,
                RATEINDEX   *index,
                COMPMETHOD  method,
                PMTFREQ     compfreq) ;

extern FL64ARRAY Caplets_Black2Intr(DATESTR  *analys,
                                    CAPLETS  *cap,
                                    DISCFAC  *offer,
                                    DISCFAC  *disc,
                                    HOLI_STR *holi) ;

/* Private functions */
extern void Caplets_SetImpl(FL64      rts,
                            IRGARRAY  irg,
                            BINARYINF *bini,
                            INTI      nirg,
                            VOL_STR   *vol,
                            KEYCONV   what) ;

extern BOOLE cap_isLIBORplain(RATEINDEX *index, CALCONV cal, EOMCONV eom,
                              PMTFREQ freq) ;

extern void Blck_SetITERCTRL(ITERCTRL *ictrl,
                         KEYCONV         what,
                         BLCKINT         *blck_data,
                         ITERCTRL        *ctrl,
						 HOLI_STR        *holi) ;   /* PMSTA-29444 - SRIDHARA - 050318 */

extern BLCKINT Blck_SetBLCKINT(DATESTR  *analys,
                        DATESTR      *voldate,
                        FL64         price,
                        CAPLETS      *cap,
                        SWAPTION     *ncsw,
                        DISCFAC      *df_index,
                        DISCFAC      *df_disc,
                        FL64         vol,
                        VOL_STR      *volstr,
                        CMCONVADJ    *cmadj,
                        HOLI_STR     *holi,
                        B76SWTM      *b76t,
                        KEYCONV      what,
                        FL64         shock) ;

extern void Blck_GetBLCKINT(BLCKINT    *blck_data,
                        DATESTR       **analys,
                        DATESTR       **voldate,
                        FL64          *price,
                        CAPLETS       **cap,
                        SWAPTION      **ncsw,
                        DISCFAC       **df_index,
                        DISCFAC       **df_disc,
                        FL64          *vol,
                        VOL_STR       **volstr,
                        CMCONVADJ     **cmadj,
                        HOLI_STR      **holi,
                        B76SWTM       **b76t,
                        KEYCONV       *what,
                        FL64          *shock) ;   

extern BOOLE Blck_NewtonRaphson(FL64  x, 
                                void   *y,
                                BOOLE  grad,
                                FL64   *fx, 
                                FL64   *dfx,
								void   *hol) ;  /* PMSTA-29444 - SRIDHARA - 050318 */

extern FL64 Caplets_IRG_Payout(CAPLETS *cal, INTI i, HOLI_STR *holi);   	/* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */


extern OPTINT caplets_set_OPTINT(DATESTR *analys, DATESTR *vold, 
                                    OPTTYPE type, FL64 x, PREMIUMTYPE ptype, 
                                    CAPLETS *capl, INTI i, CALCONV cal, 
									CALCONV vol_cal,
									HOLI_STR *holi); 	/* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */

extern INTIARRAY Caplets_Genr_Index(CAPLETSARRAY cap, INTI ncap) ;

extern FL64 Caplets_Black2P_Barr(DATESTR   *analys,
                 DATESTR   *voldate,
                 CAPLETS   *cap,
                 DISCFAC   *df_index,
                 DISCFAC   *df_disc,
                 VOL_STR   *vol,
                 CMCONVADJ *cmadj,
                 HOLI_STR  *holi,
                 RISKSET   *risk,
                 FL64      *dp,
                 FL64      *ddp) ;

extern FL64 Caplets_Black2P_int(DATESTR   *analys,
                     DATESTR   *voldate,
                     CAPLETS   *cap,
                     DISCFAC   *df_offer,
                     DISCFAC   *df_disc,
                     VOL_STR   *vol,
                     CMCONVADJ *cmadj,
                     HOLI_STR  *holi,
                     RISKSET   *risk,
                     FL64      *dp,
                     FL64      *ddp,
                     FL64ARRAY forwfix,
                     INTIARRAY caplength) ;

extern FL64 Caplets_IRG_Notional(CAPLETS *cap, INTI i, HOLI_STR  *holi);  	/* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */

/*** routines in swaption.c ********************************************/


/* Public functions */
extern BOOLE Swaption_Black2P(DATESTR *analys,
                          DATESTR *voldate,
                          FL64    vol,
                          SWAPTION  *ncsw,
                          DISCFAC   *df,
                          DISCFAC   *df_cf,
                          CMCONVADJ *cmadj,
                          HOLI_STR  *holi,
                          B76SWTM   *b76t,
                          RISKSET   *risk,
                          FL64      *p,
                          FL64      *dp,
                          FL64      *ddp) ;

extern BOOLE Swaption_Black2Impl(DATESTR *analys,
                          DATESTR *voldate,
                          FL64      pv,
                          FL64      vol,
                          SWAPTION  *ncsw,
                          DISCFAC   *disc,
                          DISCFAC   *df_cf,
                          CMCONVADJ *cmadj,
                          HOLI_STR  *holi,
                          B76SWTM   *b76t,
                          KEYCONV   what,
                          ITERCTRL  *ictrl,
                          FL64      *res) ;


extern BOOLE Swaption_Black2ATMP(DATESTR* analys,
                      DATESTR*    voldate,
                      FL64        atm_vol,
                      SWAPTION*   ncsw,
                      DISCFAC*    df_cf,
                      DISCFAC*    df_disc,
                      B76SWTM*    b76t,
                      HOLI_STR*   holi,
                      FL64*       strike,
                      FL64*       p);

extern FL64ARRAY Swaption_Black2Delta(DATESTR    *analys,
                       DATESTR      *voldate,
                       FL64         vol,
                       SWAPTION     *ncsw,
                       DISCFAC      *df,
                       DISCFAC      *df_cf,
                       CMCONVADJ    *cmadj,
                       HOLI_STR     *holi,
                       B76SWTM      *b76t,
                       DELTASET     *ds,
                       BOOLE        *ok) ;

extern FL64 Swaption_VOLBOX2Vol(DATESTR  *today,
                                VOLBOX   *vb,
                                SWAPTION *swpt,
                                HOLI_STR *holi) ;

extern SWAPTION Set_SWAPTION(OPTTYPE    type,
                       DATESTR*   maturity,
                       CALCONV    cal,
                       BOOLE      swapstl,
                       FIXRATE*   fix,
                       PAYDAYDEF* pfix) ;

extern SWAPTION Swaption_Simple2SWAPTION(DATESTR*  today,
                                     OPTTYPE   type,
                                     PERIOD*   opt_matur,
                                     PERIOD*   swap_delay,
                                     PERIOD*   swap_matur,
                                     PMTFREQ   swap_freq,
                                     FL64      swap_rate,
                                     CALCONV   cal,
                                     EOMCONV   eom) ;

/* Private functions */
extern FL64 Swaption_Black2Vol(DATESTR    *analys,
                            SWPTVOL    *swvol,
                            SWAPTION   *ncsw,
                            DISCFAC    *df,
                            HOLI_STR   *holi) ;

extern BOOLE Swaption_Black2P_Rate(DATESTR    *analys,
                            DATESTR    *voldate,
                            FL64       vol,
                            SWAPTION   *ncsw,
                            DISCFAC    *df,
                            DISCFAC    *df_cf,
                            CMCONVADJ *cmadj,
                            HOLI_STR   *holi,
                            B76SWTM    *b76t,
                            BOOLE      pa,
                            KEYCONV    key,
                            FL64       *p,
                            FL64       *dr,
                            FL64       *ddr) ;

extern BOOLE Swaption_Black2P_Scorig(DATESTR    *analys,
                       DATESTR    *voldate,
                       FL64       vol,
                       SWAPTION   *ncsw,
                       DISCFAC    *df,
                       DISCFAC    *df_cf,
                       CMCONVADJ *cmadj,
                       HOLI_STR   *holi,
                       KEYCONV    key,
                       FL64       *p,
                       FL64       *dr,
                       FL64       *ddr) ;

extern BOOLE Swaption_Black2P_Price(DATESTR    *analys,
                       DATESTR    *voldate,
                       FL64       vol,
                       SWAPTION   *ncsw,
                       DISCFAC    *df,
                       DISCFAC    *df_cf,
                       CMCONVADJ *cmadj,
                       HOLI_STR   *holi,
                       KEYCONV    key,
                       FL64       *p,
                       FL64       *dr,
                       FL64       *ddr) ;

extern void Swaption_SetImpl(FL64      rts,
                 FL64 *vol,
                 FL64 *swaprate,
                 KEYCONV   what) ;

extern INTIARRAY Swaption_Genr_index(SWAPTIONARRAY swt, 
                                        INTI nswt,
                                        BOOLE use_optmatur) ;

extern BOOLE XtndSwap_Black2P(DATESTR     *analys,
                       DATESTR *voldate,
                       FL64        vol,
                       DATESTR     *matur,
                       SWAPTION    *ncsw,
                       DISCFAC     *df,
                       DISCFAC     *df_cf,
                       CMCONVADJ *cmadj,
                       HOLI_STR    *holi,
                       FL64        *spr) ; 

extern OPTINT swaption_set_OPTINT(DATESTR*  analys,
                                     DATESTR*  voldate,
                                     SWAPTION* ncsw,
                                     FL64      strike,
                                     BOOLE     in_rates,
                                     FL64      PV2rate_fac,
                                     HOLI_STR* holi) ;


/*** routines in cap.c **********************************************/


/* Public functions */
extern CAP Cap_Simple2CAP(DATESTR*  today,
                             OPTTYPE   type,
                             PERIOD*   term,
                             PMTFREQ   freq,
                             FL64      strike,
                             CALCONV   cal,
                             EOMCONV   eom) ;

extern CAPLETS Cap_CAP2CAPLETS(CAP *cap, HOLI_STR *holi) ;

extern FL64 Cap_Black2P(DATESTR   *analys,
                     DATESTR   *voldate,
                     CAP       *cap,
                     DISCFAC   *df_offer,
                     DISCFAC   *df_disc,
                     VOL_STR   *vol,
                     CMCONVADJ *cmadj,
                     HOLI_STR  *holi,
                     RISKSET   *risk,
                     FL64      *dp,
                     FL64      *ddp) ;

extern FL64ARRAY Cap_Black2Delta(DATESTR   *analys,
                     DATESTR    *voldate,
                     CAP        *cap,
                     DISCFAC    *df_cf,
                     DISCFAC    *df_disc,
                     VOL_STR    *vol,
                     CMCONVADJ *cmadj,
                     HOLI_STR   *holi,
                     DELTASET  *ds) ;

extern BOOLE Cap_Black2Impl(DATESTR *analys,
                 DATESTR   *voldate,
                 FL64      price,
                 CAP       *cap,
                 DISCFAC   *df_cf,
                 DISCFAC   *df_disc,
                 VOL_STR   *vol1,
                 CMCONVADJ *cmadj,
                 HOLI_STR  *holi,
                 KEYCONV   what,
                 ITERCTRL  *ictrl,
                 FL64      *res) ;

extern BOOLE Cap_Black2ATMP(DATESTR* analys,
                      DATESTR*    voldate,
                      FL64        atm_vol,
                      CAP*        cap,
                      DISCFAC*    df_cf,
                      DISCFAC*    df_disc,
                      CALCONV     volcal,
                      HOLI_STR*   holi,
                      FL64*       strike,
                      FL64*       p) ;
                      
extern VOL_STR Cap_VOLBOX2Vol(DATESTR  *today,
                              VOLBOX   *vb,
                              CAP      *cap,
                              HOLI_STR *holi,
                              BOOLE    cmt) ;

extern CAP Set_CAP(OPTTYPE    type,
                      FL64       strike,
                      CALCONV    cal,
                      PAYDAYDEF* fix_days,
                      FL64       notional,
                      FL64       LIBORfix) ;

extern FLEXICAPINF Set_FLEXICAPINF(BOOLE autoflex,
                       INTI n_caplets);

/* Private functions */


/*** routines in optirf.c *******************************************/


/* Public functions */

extern FL64 OptIRF_Black2DFp(DATESTR*  analys,
                          DATESTR*  voldate,
                          FRA_STR*  irf,
                          OPTFUT*   opt,
                          DISCFAC*  df,
                          FL64      vol,
                          HOLI_STR* holi,
                          RISKSET*  risk,
                          FL64*     dp,
                          FL64*     ddp) ;

extern FL64 OptIRF_Black2P(DATESTR* analys,
                          DATESTR*  voldate,
                          FL64      irfp,
                          FRA_STR*  irf,
                          OPTFUT*   opt,
                          DISCFAC*  df,
                          FL64      vol,
                          HOLI_STR* holi,
                          RISKSET*  risk,
                          FL64*     dp,
                          FL64*     ddp);

/* Private functions */


/*** routines in callswap.c *****************************************/


/* Public functions */

extern SWAPCALL SwapCall_Simple2SWAPCALL(BOOLE pay_fix, 
                                  BOOLE    extend,
                                  BOOLE    berm,
                                  FL64     swap_rate,
                                  DATESTR* start,
                                  PERIOD*  first_call,
                                  PERIOD*  last_call,
                                  PERIOD*  matur,
                                  CALCONV  cal,
                                  EOMCONV  eom,
                                  PMTFREQ  freq);


extern SWAPCALL Set_SWAPCALL(BOOLE     pay_fix,
                                BOOLE     extend,
                                BOOLE     berm,
                                DATESTR   *first_call,
                                DATESTR   *last_call,
                                CALCONV   cal,
                                FIXRATE   *fix,
                                PAYDAYDEF *pfix);

extern BOOLE SwapCall_Black2P(DATESTR* analys,
                       DATESTR*    voldate,
                       FL64        vol,
                       SWAPCALL*   swap,
                       DISCFAC*    df,
                       HOLI_STR*   holi,
                       B76SWTM*    b76t,
                       FL64*       p);

extern BOOLE SwapCall_Black2Impl(DATESTR* analys,
                       DATESTR*    voldate,
                       FL64        vol,
                       FL64        npv,
                       SWAPCALL*   swap,
                       DISCFAC*    df,
                       HOLI_STR*   holi,
                       B76SWTM*    b76t,
                       FL64*       impl);

/* Private functions */

extern BOOLE SwapCall_NewtonRaphson(FL64 x, 
                               void* y,
                               BOOLE grad,
                               FL64* fx, 
							   FL64* dfx,
							   void* hol);   /* PMSTA-29444 - SRIDHARA - 050318 */

#ifdef __cplusplus
}
#endif

#endif

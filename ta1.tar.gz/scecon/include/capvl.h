/* SCID @(#)capvl.h	1.3 (SimCorp) 99/02/19 14:09:43 */

#ifndef CAPVL_H
#define CAPVL_H

/************************************************************************
*                                                                       *
*    project     SCecon                                                 *
*                                                                       *
*    filename    validate.h                                             *
*                                                                       *
*    general     this file contains declarations, initializations,      *
*                type definitions and function prototyping for the      *
*                validation module of the standard library SCecon       *
*                                                                       *
************************************************************************/

/**** includes *********************************************************/
#include <cap.h>
#include <optbond.h>
#include <validate.h>

#ifdef __cplusplus
extern "C" {
#endif

/*** typedefines *******************************************************/


/*** function prototyping (capvl.c) ************************************/

extern BOOLE Validate_B76SM(B76SM b) ;

extern VALIDATE Validate_B76SWTM(B76SWTM *b) ;

extern VALIDATE Validate_CAP(CAP *c) ;
extern VALIDATE Validate_CAPARRAY(CAPARRAY cm, INTI n);
extern VALIDATE Validate_CAPLETS(CAPLETS *c) ;
extern VALIDATE Validate_CAPTION(CAPTION *x) ;

extern VALIDATE Validate_IRG_STR(IRG_STR *i) ;
extern VALIDATE Validate_IRGARRAY(IRGARRAY cm, INTI n);

extern VALIDATE Validate_SWAPTION(SWAPTION *s) ;
extern VALIDATE Validate_SWAPTIONARRAY(SWAPTIONARRAY cm, INTI n);

extern VALIDATE Validate_CONVTBL(CONVTBL *x);

#ifdef __cplusplus
}
#endif

#endif

/* @(#)swapval.h	1.10 (SimCorp) 99/09/06 11:32:46 */

#ifndef SWAPVAL_H
#define SWAPVAL_H

/************************************************************************
*                                                                       *
*    project     SCecon                                                 *
*                                                                       *
*    filename    swap.h                                                 *
*                                                                       *
*    general     this file contains declarations, initializations,      *
*                type definitions and function prototyping for the      *
*                swap module of the standard library SCecon             *
*                                                                       *
************************************************************************/

/**** includes *********************************************************/
#include <stdlib.h>
#include <future.h>
#include <swap.h>
#include <mm.h>
#include <vol.h>

/**** C++ convenience **************************************************/
#ifdef __cplusplus
extern "C" {
#endif


/*** typedefines ******************************************************/

/*,,SOT,,

COMPMETHOD: Method of compounding for float leg generation
----------------------------------------------------------

This enumerated type holds info on how to compound when generating
floating leg cashflows.

The COMPMETHOD data type is defined as

        typedef enum compmethod_tag
        {
            NONE,
            REGCOMPOUND,
            FLAT,
            TAM,
            DECOMPOUND
        }   COMPMETHOD ;


NONE indicates that no compounding apply.
  
FLAT and REGCOMPOUND are in accordance with ISDA convention for 
flat or regular compounding.
The interest paid use these to schema effectively contains
interest on interest. The REGCOMPOUND also includes interest on spread.

TAM represents the French TAM/TAG conventions, where averaged
O/N rates are compounded into annual rates.

DECOMPOUND indicates that the annual rates are decompounded to find the
periodical payment - using the period as decompounding term. This can be 
used to find the French TEC FRN cashflow, based on Government Bond Yields.

,,EOT,,*/

typedef enum compmethod_tag
{
    COMPMETHOD_INIT = -1,
    NONE,
    REGCOMPOUND,
    FLAT,
    TAM,
    DECOMPOUND
}   COMPMETHOD ;


/*,,SOT,,

LEGTYPE: Type of swap leg
-------------------------

Type for handling the 2 generic types of swap payments, nemely fixed and
floating. The LEGTYPE data type is defined as

         typedef enum legtype_tag
         {
             FIXEDLEG,
             FLOATLEG
         }   LEGTYPE ;

,,EOT,,*/

typedef enum legtype_tag
{
    FIXEDLEG,
    FLOATLEG
}   LEGTYPE ;


/*,,SOT,,

RATEINDEX: Type for holding info on floating rate indices
---------------------------------------------------------

This type is defined as:

        typedef struct rateindex_tag
        {
            RATECONV   LIBORtype ;
            FL64       LIBORdur ;
            TERMUNIT   LIBORunit ;
            PMTFREQ    LIBORfreq ;
            CALCONV    LIBORcal ;
            FL64       coupon;
        }   RATEINDEX ;

For holding data for floating rate indices.

The data have the following interpretations:

        LIBORtype  Usually indices are based on vanilla *IBOR, i.e SIMPLE_MM.
                   However, sometimes other indices are used (DISCOUNT).
                   The entries maps into:

                          MMRATE    -> SIMPLE_MM rate  (default)
                          BILLDISC  -> DISCOUNT rate
                          BILLYIELD -> SIMPLE_MM rate
                          PARYIELD  -> Constant Maturity Index, defined by
                                       LIBORfreq. Here the underlying index
                                       refers to the par yield of some 
                                       security (bond, swap, ..).
                                       Used in CMT/CMS swaps and in the 
                                       French TEC FRN Government Bond.
                          REX       -> Yield derived from REX price index.
                                       Here the underlying index refers 
                                       to the yield of a synthetic REX bond.
                                       Used in REX linked derivatives.

        LIBORdur   Duration of LIBOR (or the index). E.g 6 for 6 LIBORunit's.
                   Can be any number, eg. 5.25.
                   Default simple LIBOR, this can be accomplished by setting
                   the LIBORdur period equal to the pay frequency.

        LIBORunit  Unit of LIBORdur, e.g

                          MONTHS as in 6 MONTHS
                          YEARS  as in 5.25 YEARS
                          DAYS   as in 1 DAYS

        LIBORfreq  Usually the floating rate index in a floating leg is plain
                   LIBOR with some duration. In this case LIBORfreq is
                   NO_FREQUENCY. However, for Constant Maturity (CMT/CMS) 
                   swaps the underlying index is the rate of a security 
                   with pay-off's (e.g 5Y Treasury as in 5 Year CMT). 
                   In this case the payment frequency of the underlying 
                   index is reflected in LIBORfreq (e.g. SEMIANNUALLY 
                   for US Treasuries).
                   LIBORfreq is only used if LIBORtype is PARYIELD.

        LIBORcal   This is the day-count convention used in the coupon
                   calculation of the LIBOR index. For vanilla *IBOR this
                   will be identical to the day-count convention used
                   for the coupon calculation on the swap itself.
                   For TAM swaps this should be ACT360.
                   For Constant Maturity (CMS/CMT) swap the underlying index
                   is likely to have a different day-count convention, 
                   eg. EU30E360. The day-count should be the same as the one
                   used for the Par Swaps when the discount function was
                   bootstrapped. This will ensure consistency.


        coupon     This is the coupon of the index security. Only used
                   if LIBORtype is REX. For the 10 year REX index, the
                   underlying bonds have 10 years maturity paying a
                   coupon of 7.1958 annually on a EU30E360 basis.
                   The coupons of synthetic REX bonds have sofar remained
                   constant over time. It should therefore be safe to
                   assume a fixed known coupon for all future bonds.

With CM like indices, sometimes special steps must be taken 
in order to correctly construct the discount structure from which
the forward fixings are to derived.

      LIBORtype = REX:
      At the time of implementation (July/August 1998), it appears to be
      market practive that the discount function from which the forward 
      REX10 yields are derived is constructed as the LIBOR Swap Curve 
      with a spread of 32bp added to all bootstrap securities. This is, 
      of course, only an approximation to the true REX curve, but it seems 
      reasonable, as the 10 year spread between the government and swap 
      curves has been in the area of 32bp.
      The REX10 coupon is more accurately computed as the weighted average

        REX10 coupon = (3.15 * 6 + 1.47 * 7.5 + 1.84 * 9) / 6.46 = 7.1958

      A more correct REX curve can be constructed using Bond_RexIndexPrices()
      and Fit_BSEC2DF().

see also Set_RATEINDEX

,,EOT,,*/

typedef struct rateindex_tag
{
    RATECONV   LIBORtype ;
    FL64       LIBORdur ;
    TERMUNIT   LIBORunit ;
    PMTFREQ    LIBORfreq ;
    CALCONV    LIBORcal ;
    FL64       coupon ;
}   RATEINDEX ;


/*,,SOT,,

FLOATBASE: Type for holding basis info on floating coupon generation
--------------------------------------------------------------------

This type is defined as:

        typedef struct floatbase_tag
        {
            FL64    coupon1 ;
            CALCONV cal ;
            DATESTR effective ;
            FL64    spread ;
            BOOLE   is_fix ;
        }   FLOATBASE ;

The data has the following interpretations:

        coupon1    is index (LIBOR, ...) fixing for next coupon (annual rate
                   in %). The value is assumed to be the plain index (LIBOR)
                   UNadjusted for any spread.
                   See SwapFl_GenrLIBORsaldo() for how to calculate it
                   with more involved leg definitions.

        cal        is the calendar convention for coupon calculation

        effective  the date from which interest accrues
                   If SEQCONV for floating rate paydays is defined as TAM_T4M 
                   and the corresponding snap2 is True then effective is 
                   adjusted to closest first in month. Thereby one can just 
                   insert the  transaction date as effective, 
                   and the routines will automatically adjust it.
                   (in SwapFl_GenrCflw() ).

        spread     spread on LIBOR (annual rate in %)

        is_fix     if True then coupon1 is always used - also for forward
                   starting legs. If False then coupon1 is not used.
                   Usually is_fix is True, except for most forward starting
                   legs, where is_fix is usually False.
                   For seasoned (not backset legs) is_fix should be True.,
                   otherwise the next coupon is not defined.

These data are considered to core data needed for doing floating rate 
calculations. For more involved definitions see FLOATRATE.

see also Set_FLOATBASE

,,EOT,,*/

typedef struct floatbase_tag
{
    FL64    coupon1 ;
    CALCONV cal ;
    DATESTR effective ;
    FL64    spread ;
    BOOLE   is_fix ;
}   FLOATBASE ;


/*,,SOT,,

AVGFLOAT: Definition of floating rate averaging methods.
--------------------------------------------------------

This type is defined as:

        typedef struct avgfloat_tag
        {
            FL64     avgdur ;
            TERMUNIT avgunit ;
            BOOLE    avgmeth ;
        }   AVGFLOAT ;

where the individual elements have the following interpretation:

        avgdur     Duration of the averaging period. E.g. 1 for 1 avgunit's.
                   Default is no averaging, this can be accomplished by
                   setting the averaging period equal to the pay frequency,
                   or by setting avgdur <= 0.0.
                   avgdur is a floating number, because some indices are
                   simulated as say 1.25 Years (e.g. 'Stat, Fiskeri and
                   Faeroerne' in DK).
                   It is assumed that if avgunit is not years, then avgdur
                   is an integer (e.g 4.0) .

        avgunit    Unit of avgdur.

        avgmeth    This switch controls the simulation of future averages
                   when using the SwapFl_*() routines, where discount
                   factor curves are used.

                   If this is False then the averaging is performed by
                   looking up the individual floating rates for any
                   averaging period (this is the backwards compatibility
                   setting). Note that this method can involve huge amounts
                   of interpolation when avgdur is short relative to the
                   number of grid points in the discount factor curve.

                   If it is True then the averaging is performed by
                   assuming that the average interest rate in the period
                   is constant - which is of course much simpler and faster.
                   The latter method requires that the underlying index is
                   equal to the averaging periods.

see also Set_AVGFLOAT

,,EOT,,*/

typedef struct avgfloat_tag
{
    FL64     avgdur ;
    TERMUNIT avgunit ;
    BOOLE    avgmeth ;
}   AVGFLOAT ;


/*,,SOT,,

FLOATRATE: Type for holding info on floating coupon generation
--------------------------------------------------------------

This type is defined as:

        typedef struct floatrate_tag
        {
            FLOATBASE  fbase ;
            FL64       factor ;
            BOOLE      backset ;
            PERIOD     delay ;
            COMPMETHOD method ;
            PMTFREQ    compfreq ;
            RATEINDEX  index ;
            AVGFLOAT   avgfl ;
            PLAN_STR   *stepspr ;
            PLAN_STR   *stepfac ;
        }   FLOATRATE ;

Use this type to define the floating rate calculations on all sorts of 
FRN's and swap floating legs.

The data has the following interpretations:

        fbase      the basic info needed for coupon generation

        factor     factor on LIBOR (or the index) - typically 1.0

        backset    False means that LIBOR is set in advance and paid in
                   arrears, True means that LIBOR is set and paid in
                   arrears. False is the normal value.

        delay      is used if backset is True. It signals the fixing delay
                   for arrears setting swaps - typically 2 - 15 days.
                   For backset legs in the 'delay' period - fbase.coupon1
                   is known / used.

        method     The compounding method (according to ISDA conventions).

        compfreq   Compounding frequency. When method is not NONE it should
                   be 'less' than the payment frequency. E.g semiannual
                   payments and quarterly compounding (means 2 compounding
                   periods). Use NO_FREQUENCY if no compounding.

        index      Container for index (LIBOR or the like) information.
                   Used to define standard indices (e.g 6M LIBOR) or more
                   involved indices like constant maturities indices
                   (e.g. CMT, CMS swaps and TEC FRN's).

        avgfl      The definition of the averaging procedure.

        stepspr|NULL  Stepped up/down spread over the life of the leg. List 
                   with stepspr->filled entries. Default is 0, in which case
                   spread is used. If the first day in stepspr->day is after
                   effective, then spread is used till the first change.
                   If irregularly spaced the days are move to next payday or
                   compounding day.
                   If stepspr is NULL then it is assumed to be empty.

        stepfac|NULL  Stepped up/down factor over the life of the leg. List 
                   with stepfac->filled entries. Default is 0, in which case
                   factor is used. If the first day in stepfac->day is after
                   effective, then factor is used till the first change.
                   If irregularly spaced the days are move to next payday or
                   compounding day.
                   If stepfac is NULL then it is assumed to be empty.

The possibility of defining time-varying spreads/factors can be creatively
used to define all sorts of floating structures, including inverse floaters,
super floaters, and structures that are inverse for a period and then changed
to be straight floaters in another period etc.

The interpretation of fbase.coupon1 is somewhat subtle,
the following rules apply:

        In a plain vanilla floating leg coupon1 is LIBOR (excl. a spread).
        This also applies if the leg is seasoned.

        If the leg is backset then coupon1 is not used, since LIBOR is set in
        arrears (except for the delay period).

        If averaging applies, then coupon1 is current LIBOR until after the
        first averaging date, in which case coupon1 is the average so far.

        If method is TAM, then coupon1 is the current LIBOR, if the valuation
        day is after effective, then coupon1 is TAG(m), where m is the number
        of months passed. Note that we here use a PROXY for the accumulated
        saldo so far, since the real saldo is TAG(m) + the current average of
        the current month. If this is to be handled entirely correct, then 
        the user needs to calculate coupon1 accordingly.

        If method is FLAT or REGCOMPOUND then coupon1 is current LIBOR until
        after the first compounding day in which case coupon1 is the current
        compounding saldo according to the conventions.

        If method is DECOMPOUND then coupon1 is the annual rate 
        set for the actual period. If averaging apply then it is the current
        average.

        If backsetting is used with compounding, then at issue coupon1 is
        not used. After first compounding day coupon1 is the saldo according
        to conventions respecting backsetting.

        Averaging and compounding can be used at issue of the leg, but not
        after first compounding - since here 2 saldo's are needed (compounding
        saldo and current average). Except for TAM's where the TAG(m) is
        used and for DECOMPOUNDING.

        Backsetting and averaging cannot be combined.

        See SwapFl_GenrLIBORsaldo() for how to calculate coupon1 with more
        involved leg definitions.


When defining various FRF indices a few clarifying comments may be of 
some use:

        Index = T4M (TMM):
        Is the monthly average of the TMP rate (O/N) with no compounding.
        Floating leg pay frequency is MONTHLY
        Total swap Duration is max 11 (whole) months
        Calendar is ACT360.
        Fixed side is always decompounded (see FIXRATE).
        Effective date is always the 1st of a month. If transaction date is
        between the 1st and 14th (incl) effective is the 1st of the current 
        month. Otherwise it is the first of the next month. 
        In the first case  the swap is already a number of days old when 
        entered into, so coupon1 must be set accordingly - using the current 
        average of the month (quoted as TMP by various sources).
        Similarly TMP can be used as coupon1 when revaluing secondary T4M's.
        
        Index = TMP (Averaged):
        In this floating leg the average of the O/N rate with no compounding 
        is paid.
        Floating leg pay frequency is MONTHLY or with a single payment at the
        end of the swap.
        Calendar is ACT360
        Effective date is always the day following the transaction date,
        so at entry no interest has accrued.
        When revaluing secondary TMP swaps the running average must be 
        calculated / known.

        Index = TMP (Compounded):
        In this floating leg the daily compounded TMP (O/N) rate is paid.
        This is a variation of Over Night Indexed Swaps (OIS).
        Floating leg pay frequency is MONTHLY or with a single payment at the
        end of the swap.
        Calendar is ACT360
        Effective date is always the day following the transaction date,
        so at entry no interest has accrued.
        When revaluing secondary TMP swaps the running average must be 
        calculated / known.

        Index = TAM:
        Is the monthly average of the O/N rate (JJ) compounded monthly to an
        annual rate (COMPMETHOD = TAM).
        Floating leg pay frequency is ANNUALLY
        Total swap Duration is a whole number of months.
        Calendar for payment calculation is ACTACT, whereas the index calendar
        (TMP) is ACT360.
        Fixed side is decompounded in broken periods (see FIXRATE).
        Effective date is always the 1st of a month. If transaction date is
        between the 1st and 14th (incl) effective is the 1st of the current 
        month. Otherwise it is the first of the next month. 
        In the first case the swap is already a number of days old when 
        entered into, so coupon1 must be set accordingly - using the current 
        average of the month (quoted as TMP by various sources).
        When revaluing secondary TAM swaps a PROXY for the current compounding 
        saldo is known as TAG(m), where m is the number of whole months passed 
        in the current period. TAG(m) is a annualised rolling capitalisation 
        of monthly TMP averages for the periods m = 1, 2, ..., 12. If the exact 
        saldo is to be known it must be calculated directly.
        TAM swaps can be issued with broken periods. In this case the broken
        period is either at then start or the end of the swap and is a whole
        number of months.
        
        In broken periods the index paid is either:

            TAG(m), where m is the number of months in the broken period
                    paid once, or
            T4M     paid monthly m times

        The first variation is handled by SwapFl_GenrCflw() by using a broken
        period. The latter variation must be handled by decomposing the deal
        into 2 deals - a T4M swap + a 'pure' TAM swap.

        Index = TAG:
        Is the monthly average of the O/N rate (JJ) compounded monthly to an
        annual rate (COMPMETHOD = TAM).
        Floating leg pay frequency is ANNUALLY
        Total swap Duration is a whole number of months.
        Calendar for payment calculation is ACTACT, whereas the index calendar
        (TMP) is ACT360.
        Fixed side is decompounded in broken periods (see FIXRATE).
        Effective date is always the day following the transaction date,
        so at entry no interest has accrued.
        When revaluing secondary TAG swaps a PROXY for the current compounding 
        saldo is known as TAG(m), where m is the number of whole months passed 
        in the current period. TAG(m) is a annualised rolling capitalisation 
        of monthly TMP averages for the periods m = 1, 2, ..., 12. If the exact 
        saldo is to be known it must be calculated directly.
        TAG swaps can be issued with broken periods. In this case the broken
        period is either at then start or the end of the swap and is a whole
        number of months.

        In broken periods the index paid is either:

            TAG(m), where m is the number of months in the broken period
                    paid once, or
            T4M     paid monthly m times

        The first variation is handled by SwapFl_GenrCflw() by using a broken
        period. The latter variation must be handled by decomposing the deal
        into 2 deals - a T4M swap + a 'pure' TAG swap.

        Sometimes TAG swaps only have a single short period.

see also Set_FLOATRATE

,,EOT,,*/

typedef struct floatrate_tag
{
    FLOATBASE  fbase ;
    FL64       factor ;
    BOOLE      backset ;
    PERIOD     delay ;
    COMPMETHOD method ;
    PMTFREQ    compfreq ;
    RATEINDEX  index ;
    AVGFLOAT   avgfl ;
    PLAN_STR   *stepspr ;
    PLAN_STR   *stepfac ;
}   FLOATRATE ;


/*,,SOT,,

SWAPFLOAT: type for holding info on swap floating legs or FRN's
---------------------------------------------------------------

This type is defined as

        typedef struct swapfloat_tag
        {
            REPAYMNT  repay ;
            PAYDAYDEF rday ;
            FLOATRATE float1 ;
            PAYDAYDEF pday ;
            INTI      delay ;
        }   SWAPFLOAT ;

Use this type to define many sorts of floating swap legs.

The data has the following interpretations:

        repay is the definition of repayments.
        repay.pp and repay.aufab are NOT used.
        Annuities are NOT supported.
        Use repay to define Amortising (incl. Accreting and 
        Rollercoaster) floating swap legs.

        rday is the definition of the repay paydays

        float1 is the definition of floating payment calculation.
        Use this to define Averaging, Compounding, LIBOR Factors,
        Stepped Spreads or Stepped Factors and the index definition.
        Using Stepped Spreads and Factors one can creatively define various
        kinds of Inverse Floating (factor < 0), super floating (factor > 1)
        structures. This includes time-varying structures like vanilla
        for 3 years, then inverse floating for 2 years etc.
        Also use float1 to define various indices where the index duration
        differs from the pay frequency - like in CMS/CMT swaps.

        pday is the definition of the floating coupon paydays.

        delay is as delay being superimposed on the paydays after calcu-
        lating the amounts.

See SwapFl_GenrCflw() for cashflow calculation.

see also Set_SWAPFLOAT and SwapFloat_Simple2SWAPFLOAT()

,,EOT,,*/

typedef struct swapfloat_tag
{
    REPAYMNT  repay ;
    PAYDAYDEF rday ;
    FLOATRATE float1 ;
    PAYDAYDEF pday ;
    INTI      delay ;
}   SWAPFLOAT ;


/*,,SOT,,

DIFFSWAP: type for holding info on diff swaps
---------------------------------------------

This type is defined as

       typedef struct diffswap_tag
       {
           FLOATBASE fbase ;
           PAYDAYDEF pday ;
           BOOLE     io ;
           RATEINDEX index ;
           BOOLE     arrears ;
       }   DIFFSWAP ;

where
    
    fbase is the definition of the differential floating payments

    pday is the definition of the floating coupon paydays

    io is True if the leg is interest only, False if not (BULLET).

    index is the rate defining the cash flow
    
    arrears is True for a fixing-in-arrears swap, false otherwise.

,,EOT,,*/

typedef struct diffswap_tag
{
    FLOATBASE fbase ;
    PAYDAYDEF pday ;
    BOOLE     io ;
    RATEINDEX index ;
    BOOLE     arrears ;
}   DIFFSWAP ;



/*,,SOT,,

CMADJTYPE: Enum for defining CM derivatives convexity adjustment type
---------------------------------------------------------------------

This type is defined as:

        typedef enum cmadjtype_tag
        {
            NO_CMADJ,
            CMADJ_ORIG,
            CMADJ_PRATE,
            CMADJ_4TH,
            CMADJ_4THCORR
        }   CMADJTYPE ;

Where the individual entries are defined as:

        NO_CMADJ means no convexity adjustment

        CMADJ_ORIG is the original SimCorp derived adjustment (2'nd order in
        the annual yields

        CMADJ_PRATE is similar to CMADJ_ORIG except that adjustment is in
        the annual CM rate and not the equivalent yield.

        CMADJ_4TH is a higher order approximation (from tests it gives the
        same results as the 'correct' number calculated using numerical
        integration.

        CMADJ_4THCORR is similar to CMADJ_4TH except that the correlation and
        between CM rates and the short period discounting rates (LIBOR) are
        handled.
        This variation can only be used when fixing is 1 period in advance
        of payment.

For speed choose CMADJ_ORIG or CMADJ_PRATE, for enhanced precision choose
CMADJ_4TH or CMADJ_4THCORR (if data is available).

,,EOT,,*/

typedef enum cmadjtype_tag
{
    NO_CMADJ,
    CMADJ_ORIG,
    CMADJ_PRATE,
    CMADJ_4TH,
    CMADJ_4THCORR
}   CMADJTYPE ;


/*,,SOT,,

CMCONVADJ: struct for holding info on convexity adjustment
----------------------------------------------------------

This type is defined as:

        typedef struct cmconvadj_tag
        {
            CMADJTYPE order ;
            VOL_STR   volCM ;
            VOL_STR   volLIBOR ;
            FL64      corr ;
        }   CMCONVADJ ;

This struct is used to define data for calculating convexity adjusted
cashflows for Constant Maturity (CM) swaps. In order to avoid using this
let order be NO_CMADJ.

        order defines how adjustment is performed

        volCM is a term structure of volatility for the CM rate.
        Enter volCM->filled == 0 for empty data.
        Only needed if order is not NO_CMADJ.

        volLIBOR is a term stucture of volatility for the period
        discounting rate (e.g vol of 3M LIBOR).
        Enter volLIBOR->filled == 0 for empty data.
        Only needed if order is CMADJ_4THCORR. For cap valuation this
        may be equal to the forward rate volatility passed to the
        valuation routine elsewhere.

        corr is the correlation vbetween the CM rates and the short
        discounting rates (assumed constant). 0 is default.
        Only needed if order is CMADJ_4THCORR.
        This is only relevant when handling CM swaps and swaptions,
        and not caps / floors.

see also Set_CMCONVADJ

,,EOT,,*/

typedef struct cmconvadj_tag
{
    CMADJTYPE order ;
    VOL_STR   volCM ;
    VOL_STR   volLIBOR ;
    FL64      corr ;
}   CMCONVADJ ;

/* Newton-Raphson struct */

typedef struct
{
  DATESTR     *analys ;
  FL64        npv ;
  SWAPFIX     *sfix ;
  SWAPFLOAT   *sfl ;
  DISCFAC     *df_disc ;
  DISCFAC     *df_cflw ;
  CMCONVADJ   *cmadj ;
  HOLI_STR    *holi ;
  CFLW_STR    *cflw ;
  FL64        shock ;
} SWAPINT ;

/*** function prototyping (fixleg.c) ***************************************/


/* Public functions */
extern BOOLE SwapFix_DF2Rate(DATESTR     *analys,
                             FL64        npv,
                             SWAPFIX     *sfix,
                             DISCFAC     *df,
                             HOLI_STR    *holi,
                             FL64        *rate) ;

extern FL64 SwapFix_DF2CFrate(DATESTR    *analys,
                                   FL64       npv,
                                   PAYDAYDEF   *pday,
                                   DATESTR    *effective,
                                   CALCONV    cal,
                                   DISCFAC    *df,
                                   HOLI_STR   *holi) ;

extern BOOLE SwapFix_BONDSWAPSPR2CFrate(DATESTR   *analys,
                                 FIXPAY    *fixp,
                                 PAYDAYDEF *swapday,
                                 CALCONV   swapcal,
                                 FL64      bondprc,
                                 BOOLE     is_price,
                                 YTMCONV   *ytmc,
                                 FL64      swapspr,
                                 HOLI_STR  *holi,
                                 FL64      *ytm,
                                 FL64      *swaprate) ;

extern BOOLE SwapFix_FUTSWAPSPR2CFrate(DATESTR   *analys,
                                DATESTR   *deliv,
                                FIXPAY    *fixp,
                                FL64      cf,
                                PAYDAYDEF *swapday,
                                CALCONV   swapcal,
                                FL64      futp,
                                FL64      repo,
                                YTMCONV   *ytmc_repo,
                                YTMCONV   *ytmc,
                                FL64      swapspr,
                                HOLI_STR  *holi,
                                FL64      *ytm,
                                FL64      *swaprate) ;

extern FL64ARRAY SwapFix_DF2SwapCurve(DISCFAC   *df,
                         DATESTR   *forw,
                         INTIARRAY months,
                         INTI      nt,
                         CALCONV   cal,
                         PAYDAYSEQ *pseq,
                         HOLI_STR  *holi) ;

/* Private functions */

extern SWAPINT Swap_SetSWAPINT(DATESTR     *analys,
                                   FL64        npv,
                                   SWAPFIX     *sfix,
                                   SWAPFLOAT   *sfl,
                                   DISCFAC     *df_disc,
                                   DISCFAC     *df_cflw,
                                   CMCONVADJ   *cmadj,
                                   HOLI_STR    *holi,
                                   CFLW_STR    *cflw,
                                   FL64        shock) ;

extern void Swap_GetSWAPINT(SWAPINT     *swap_data,
                                DATESTR     **analys,
                                FL64        *npv,
                                SWAPFIX     **sfix,
                                SWAPFLOAT   **sfl,
                                DISCFAC     **df_disc,
                                DISCFAC     **df_cflw,
                                CMCONVADJ   **cmadj,
                                HOLI_STR    **holi,
                                CFLW_STR    **cflw,
                                FL64        *shock) ;

extern BOOLE Swap_NewtonRaphson(FL64   x, 
                                   void   *y,
                                   BOOLE  grad,
                                   FL64   *fx, 
                                   FL64   *dfx,
								   void   *hol) ;   /* PMSTA-29444 - SRIDHARA - 050318 */

/*** function prototyping (floatleg.c) *************************************/


/* Public functions */
extern FL64ARRAY SwapFl_GenrCoupons(DATESTR       *analys,
                                         FLOATRATE     *float1,
                                     PAYDAYSEQ     *pseq,
                                     PLAN_STR      *amort,
                                     DISCFAC       *df,
                                     DISCFAC       *df_dsc,
                                     CMCONVADJ     *cmadj,
                                     HOLI_STR      *holi,
                                     DATEARRAY     cdays,
                                     INTI          nc,
                                     FL64ARRAY     *ratesTabPtr) ; /*PMSTA10118 - DDV - 100623 */

extern CFLWARRAY SwapFl_GenrCflw(DATESTR       *analys,
                                     SWAPFLOAT     *sfl,
                                  DISCFAC       *df,
                                  DISCFAC       *df_dsc,
                                  CMCONVADJ     *cmadj,
                                  HOLI_STR      *holi) ;

extern BOOLE SwapFl_DF2Spread(DATESTR    *analys,
                              FL64       npv,
                              SWAPFLOAT  *sfl,
                              DISCFAC    *df_disc,
                              DISCFAC    *df_cflw,
                              CMCONVADJ  *cmadj,
                              HOLI_STR   *holi,
                              FL64       *spr) ;

extern FL64 SwapFl_DF2CFSpread(DATESTR    *analys,
                               FL64       npvLEG1,
                               FL64       npvLEG2,
                               PAYDAYDEF  *pdayLEG1,
                               DATESTR    *effLEG1,
                               CALCONV    calLEG1,
                               DISCFAC    *dfLEG2,
                               HOLI_STR   *holi) ;

extern FL64 SwapFl_GenrLIBORsaldo(DATESTR   *analys,
                            FLOATRATE *frate,
                            PAYDAYDEF *pday,
                            PLAN_STR  *amort,
                            HOLI_STR  *holi,
                            PLAN_STR  *index) ;

extern DATEARRAY SwapFl_GenrLIBORdays(DATESTR   *analys,
                           FLOATRATE *frate,
                           PAYDAYDEF *pday,
                           HOLI_STR  *holi,
                           INTI      *ndays,
                           INDEXCONV iConv) ;   /*  FPL-PMSTA00211-100825   */

extern VOL_STR SwapFl_VOLBOX2Vol(DATESTR *today, VOLBOX *vb, SWAPFLOAT *fl,
                                 DISCFAC *df, HOLI_STR *holi) ;

extern void Free_SWAPFLOAT(SWAPFLOAT *x);

extern CMCONVADJ Set_CMCONVADJ(CMADJTYPE order,
                               VOL_STR   *volCM,
                               VOL_STR   *volLIBOR,
                               FL64      corr) ;

extern FLOATBASE Set_FLOATBASE(FL64    coupon1,
                               CALCONV cal,
                               DATESTR *effective,
                               FL64    spread,
                               BOOLE   is_fix) ;

extern AVGFLOAT Set_AVGFLOAT(FL64     avgdur,
                                    TERMUNIT avgunit,
                                    BOOLE    avgmethod) ;

extern RATEINDEX Set_RATEINDEX(RATECONV LIBORtype,
                                      FL64     LIBORdur,
                                      TERMUNIT LIBORunit,
                                      PMTFREQ  LIBORfreq,
                                      CALCONV  LIBORcal,
                                      FL64     coupon) ;

extern FLOATRATE Set_FLOATRATE(FLOATBASE  *fbase,
                               FL64       factor,
                               BOOLE      backset,
                               PERIOD     *delay,
                               COMPMETHOD method,
                               PMTFREQ    compfreq,
                               RATEINDEX  *index,
                               AVGFLOAT   *avgfl,
                               PLAN_STR   *stepspr,
                               PLAN_STR   *stepfac) ;

extern SWAPFLOAT Set_SWAPFLOAT(REPAYMNT *repay, PAYDAYDEF *rday,
                                      FLOATRATE *fl, PAYDAYDEF *pday,
                                      INTI delay) ;

extern SWAPFLOAT SwapFl_Simple2SWAPFLOAT(DATESTR* effect,
                                     PERIOD* tenor,
                                     PMTFREQ freq,
                                     FL64    coupon1,
                                     FL64    spread,
                                     BOOLE   is_fix,
                                     CALCONV cal,
                                     EOMCONV eom) ;

/* Private functions */
extern FL64 SwapFl_DF2ForwRate(DATESTR*  Lstart,
                            DATESTR*  Lend,
                            DATESTR*  Lpay,  
                            DATESTR*  Dvol,
                            RATEINDEX* index,
                            BOOLE     backset,
                            DISCFAC*  df_cflw, 
                            DISCFAC*  df_disc, 
                            CMCONVADJ* cmadj,
                            FL64*     ConvAdj,
							HOLI_STR  *holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */

extern FL64 SwapFl_Genr_AVG(DATESTR* analys, 
                         DATESTR* Lstart, 
                         DATESTR* Lend, 
                         DATESTR* end, 
                         DATESTR* Dvol, 
                         FLOATRATE* frate, 
                         DISCFAC* df, 
                         CMCONVADJ* cmadj, 
                         EOMCONV eom, 
                         HOLI_STR* holi, 
                         BOOLE use1) ;

extern BOOLE SwapFl_Is_AVG(FLOATRATE *frate, 
                              PAYDAYSEQ *pseq,
                              HOLI_STR *holi) ;

extern BOOLE SwapFl_Is_Plain(FLOATRATE* frate,
                                PAYDAYSEQ* pseq,
                                HOLI_STR*  holi) ;

extern BOOLE SwapFl_Is_Vanilla(FLOATRATE* frate,
                                  PAYDAYSEQ* pseq,
                                  REPAYMNT*  repay,
                                  HOLI_STR*  holi) ;

extern DATEARRAY SwapFl_Genr_Compdays(FLOATRATE *frate, PAYDAYSEQ *pseq,
                                      BOOLE eff, HOLI_STR *holi, 
                                      DATEARRAY pfdays, INTI nfloat, INTI *n);

extern FL64 SwapFl_Genr_Regcompound(FL64 rsaldo, FL64 csaldo, FL64 period,
                                    FL64 coupon, FL64 spread) ;

extern FL64 SwapFl_Genr_Flat(FL64 rsaldo, FL64 csaldo, FL64 period,
                             FL64 coupon, FL64 spread) ;

extern FL64 SwapFl_CorrAdj_ForwRate(DATESTR *start,
                            DATESTR  *end,
                            DISCFAC  *dfLIBOR,
                            FL64     T,
                            FL64     volCM,
                            FL64     volLIBOR,
                            FL64     corr,
							HOLI_STR *holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */

extern FL64 SwapFl_CM2Price(DATESTR *start,
                     DATESTR *end,
                     PMTFREQ freq,
                     FL64    coupA,
                     FL64    ytmA,
                     FL64    *dp,
                     FL64    *ddp,
                     FL64    *dddp,
                     FL64    *ddddp) ;



/*** function prototyping (swapval.c) *************************************/


/* Public functions */
extern FL64 SwapFl_DF2NPV(DATESTR       *analys,
                          SWAPFLOAT     *sfl,
                          DISCFAC       *df_cflw,
                          DISCFAC       *df_disc,
                          CMCONVADJ     *cmadj,
                          HOLI_STR      *holi,
                          RISKSET       *risk,
                          FL64          *dp,
                          FL64          *ddp) ;

extern FL64 SwapFix_DF2NPV(DATESTR       *analys,
                           SWAPFIX       *sfix,
                           HOLI_STR      *holi,
                           DISCFAC       *df,
                           RISKSET       *risk,
                           FL64          *dp,
                           FL64          *ddp) ;

extern FL64ARRAY SwapFix_DF2Delta(DATESTR       *analys,
                                  SWAPFIX       *sfix,
                                  HOLI_STR      *holi,
                                  DISCFAC       *df,
                                  DELTASET      *ds) ;

extern FL64ARRAY SwapFl_DF2Delta(DATESTR       *analys,
                                 SWAPFLOAT     *sfl,
                                 DISCFAC       *df_cflw,
                                 DISCFAC       *df_disc,
                                 CMCONVADJ     *cmadj,
                                 HOLI_STR      *holi,
                                 DELTASET      *ds) ;

extern BOOLE AssetSwap_DF2Spread(DATESTR       *analys,
                                 FL64          asset_p,
                                 SWAPFIX       *sfix,
                                 SWAPFLOAT     *sfl,
                                 DISCFAC       *df_cflw,
                                 DISCFAC       *df_disc,
                                 CMCONVADJ     *cmadj,
                                 HOLI_STR      *holi,
                                 FL64          *spread) ;

extern FL64 AssetSwap_DF2PV(DATESTR       *analys,
                            FL64          asset_p,
                            SWAPFIX       *sfix,
                            SWAPFLOAT     *sfl,
                            DISCFAC       *df_cflw,
                            DISCFAC       *df_disc,
                            CMCONVADJ     *cmadj,
                            HOLI_STR      *holi) ;

/*** function prototyping (swapeqty.c) *************************************/


/* Public functions */
extern FL64 SwapEqty_DF2NPV(DATESTR   *analys,
                     SWAPFLOAT *eqsw,
                     DISCFAC   *df_div,
                     DISCFAC   *df_disc,
                     HOLI_STR  *holi) ;

extern FL64 SwapCmdty_DF2NPV(DATESTR   *analys,
                      SWAPFLOAT *cmsw,
                      DISCFAC   *df_conv,
                      DISCFAC   *df_stor,
                      DISCFAC   *df_disc,
                      HOLI_STR  *holi) ;

/* Private functions */


#ifdef __cplusplus
}
#endif

#endif

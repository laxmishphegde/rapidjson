#ifndef TSCALVL_H
#define TSCALVL_H

#include <sccsid.h>
SCCSID(tscalvl_h,
  "@(#)tscalvl.h	1.5 (SimCorp) 99/06/08 14:23:21")

/************************************************************************
*                                                                       *
*    project     SCecon                                                 *
*                                                                       *
*    filename    validate.h                                             *
*                                                                       *
*    general     this file contains declarations, initializations,      *
*                type definitions and function prototyping for the      *
*                validation module of the standard library SCecon       *
*                                                                       *
************************************************************************/

/**** includes *********************************************************/
#include <bootstrp.h>
#include <fitzero.h>
#include <validate.h>

#ifdef __cplusplus
extern "C" {
#endif

/*** typedefines *******************************************************/


/*** function prototyping (tscalvl.c) *********************************/



extern BOOLE Validate_ZEROMODEL(ZEROMODEL r);

extern VALIDATE Validate_SMOOTHPARMS(SMOOTHPARMS *x) ;

extern VALIDATE Validate_ZEROPARMS(ZEROPARMS *x);

extern VALIDATE Validate_CRITERIONFUNC(CRITERIONFUNC *x) ;



#ifdef __cplusplus
}
#endif

#endif


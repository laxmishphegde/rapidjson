#ifndef BONDVL_H
#define BONDVL_H

#include <sccsid.h>
SCCSID(bondvl_h,
  "@(#)bondvl.h	1.3 (SimCorp) 99/02/19 14:11:41")

/************************************************************************
*                                                                       *
*   project     SCecon                                                  *
*                                                                       *
*   file name   str2conv.h                                              *
*                                                                       *
*   general     This file contains the header file for the example code *
*               in str2conv.c                                           *
*                                                                       *
************************************************************************/

/*** includes **********************************************************/
#include <stdio.h>
#include <string.h>
#include <bond.h>
#include <swap.h>
#include <bootsec.h>
#include <idxbond.h>
#include <scenario.h>
#include <validate.h>

#ifdef __cplusplus
extern "C" {
#endif

extern BOOLE Validate_EXTRADE(EXTRADE *ext) ;
extern BOOLE Validate_BONDSEG(BONDSEG r);
extern BOOLE Validate_COUPONBASE(COUPONBASE couponbase) ;
extern BOOLE Validate_EXDAYCONV(EXDAYCONV exdayconv) ;
extern BOOLE Validate_FIXDCOMP(FIXDCOMP r) ;
extern BOOLE Validate_ODDCONV(ODDCONV oddconv) ;
extern BOOLE Validate_RATECONV(RATECONV type) ;
extern VALIDATE Validate_ACCRUINT(ACCRUINT *accru_str) ;
extern VALIDATE Validate_AIRESULT(AIRESULT *cm) ;
extern VALIDATE Validate_BONDBM(BONDBM* x);
extern VALIDATE Validate_BONDBMARRAY(BONDBMARRAY x, INTI n);
extern VALIDATE Validate_CFLW_STR(CFLW_STR *cflw) ;
extern VALIDATE Validate_DEPOSIT(DEPOSIT *d) ;
extern VALIDATE Validate_EXRULE(EXRULE *exrule) ;
extern VALIDATE Validate_FIXPAY(FIXPAY *fixpay, BOOLE sum100) ;
extern VALIDATE Validate_FIXPAYARRAY(FIXPAYARRAY cm, INTI n);
extern VALIDATE Validate_FIXRATE(FIXRATE *fixrate) ;
extern VALIDATE Validate_INDEXBOND(INDEXBOND *r);
extern VALIDATE Validate_INDEXFAC(INDEXFAC *x);
extern VALIDATE Validate_PAYDAYDEF(PAYDAYDEF *paydaydef, BOOLE is_bull) ;
extern VALIDATE Validate_PAYDAYSEQ(PAYDAYSEQ *paydayseq) ;
extern VALIDATE Validate_PP_STR(PP_STR *p) ;
extern VALIDATE Validate_REPAYMNT(REPAYMNT* repay_str, DATESTR* last,
                                  BOOLE val_dates, BOOLE sum100) ;
extern VALIDATE Validate_TAXINFO(TAXINFO *taxinfo) ;
extern VALIDATE Validate_TRADEINFO(TRADEINFO *t) ;
extern VALIDATE Validate_SCENARIO(SCENARIO *pf);
extern VALIDATE Validate_SCENARIOARRAY(SCENARIOARRAY cm, INTI n);
extern VALIDATE Validate_SCENARIOLIST(SCENARIOLIST *pf);
extern VALIDATE Validate_SWAPFIX(SWAPFIX *fixpay) ;
extern VALIDATE Validate_TRADEINFOARRAY(TRADEINFOARRAY cm, INTI n);
extern VALIDATE Validate_HZYCONV(HZYCONV *x);
extern VALIDATE Validate_YTMCONV(YTMCONV *cm) ;

extern BOOLE Validate_BSECTYPE(BSECTYPE r);

extern VALIDATE Validate_BSEC(BSEC* x);
extern VALIDATE Validate_BSECARRAY(BSECARRAY x, INTI n);



#ifdef __cplusplus
}
#endif


#endif


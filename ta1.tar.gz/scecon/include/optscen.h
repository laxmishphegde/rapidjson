/* SCID @(#)optscen.h	1.5 (SimCorp) 99/06/04 16:35:35 */

#ifndef OPTSCEN_H
#define OPTSCEN_H

/************************************************************************
*                                                                       *
*    project    SCecon                                                  *
*                                                                       *
*    filename   scenario.h                                              *
*                                                                       *
*    this file contains definitions and function prototyping for the    *
*    routines in the SCecon Scenario function module.                   *
*                                                                       *
************************************************************************/

/***** includes  *******************************************************/
#include <scenario.h>
#include <cap.h>
#include <optbond.h>

/***** C++ Convenience *************************************************/
#ifdef __cplusplus
extern "C" {
#endif



/*** prototypes  (optscen.c) *****************************************/


/* Public functions */


extern FL64ARRAY Caplets_Black2ScenBPV(DATESTR  *analys,
                        DATESTR    *voldate,
                        DISCFAC    *df_cflw,
                        DISCFAC    *df_disc,
                        VOL_STR   *vol,
                        CMCONVADJ  *cmadj,
                        FL64       fx_spot,
                        CAPLETS  *cap,
                        HOLI_STR   *holi,
                        DELTASET   *ds_cflw,
                        DELTASET   *ds_disc,
                        FXSHOCKSET *fxs);
extern FL64ARRAY Cap_Black2ScenBPV(DATESTR  *analys,
                        DATESTR    *voldate,
                        DISCFAC    *df_cflw,
                        DISCFAC    *df_disc,
                        VOL_STR    *vol,
                        CMCONVADJ  *cmadj,
                        FL64       fx_spot,
                        CAP        *cap,
                        HOLI_STR   *holi,
                        DELTASET   *ds_cflw,
                        DELTASET   *ds_disc,
                        FXSHOCKSET *fxs);
extern FL64ARRAY Swaption_Black2ScenBPV(DATESTR  *analys,
                        DATESTR    *voldate,
                        DISCFAC    *df_cflw,
                        DISCFAC    *df_disc,
                        FL64       vol,
                        CMCONVADJ  *cmadj,
                        FL64       fx_spot,
                        SWAPTION   *ncsw,
                        HOLI_STR   *holi,
                        B76SWTM    *b76t,
                        DELTASET   *ds_cflw,
                        DELTASET   *ds_disc,
                        FXSHOCKSET *fxs,
                        BOOLE      *ok);
extern FL64ARRAY OptFutBond_Black2ScenBPV(DATESTR  *analys,
                        DATESTR  *voldate,
                        FL64     vol,
                        FL64     fx_spot,  
                        INTI     noas,
                        DFSPREADARRAY dfs,
                        FUTBOND  *futb,
                        OPTFUT   *opt,
                        DISCFAC  *df,
                        HOLI_STR *holi,
                        DELTASET   *ds,
                        FXSHOCKSET *fxs);

extern FL64ARRAY OptBond_Black2ScenBPV(DATESTR  *analys,
                        DATESTR  *voldate,
                        FL64     vol,
                        FL64     fx_spot,  
                        DFSPREAD *dfs,
                        FIXPAY   *fixp,
                        OPTFUT   *opt,
                        DISCFAC  *df,
                        HOLI_STR *holi,
                        DELTASET   *ds,
                        FXSHOCKSET *fxs);

extern FL64ARRAY Convtbl_CRR2ScenBPV(DATESTR*      analys,
                                         FL64          spot,      
                                         FL64          vol,       
                                         FL64          fx_spot,
                                         CONVTBL*      cvt,
                                         INTI          nstep,     
                                         DISCFAC*      df,       
                                         DFSPREAD*     dfs,
                                         DISCFAC*      divdf,
                                         HOLI_STR*     holi,     
                                         DELTASET*     ds,  
                                         FXSHOCKSET*   fxs,
                                         EQTYSHOCKSET* eqtys,
                                         BOOLE*        ok) ;

/* Private functions */



#ifdef __cplusplus
}
#endif

#endif

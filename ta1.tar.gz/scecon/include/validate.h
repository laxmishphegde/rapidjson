/* SCID @(#)validate.h	1.43 (SimCorp) 99/08/17 10:03:32 */

#ifndef VALIDATE_H
#define VALIDATE_H

/************************************************************************
*                                                                       *
*    project     SCecon                                                 *
*                                                                       *
*    filename    validate.h                                             *
*                                                                       *
*    general     this file contains declarations, initializations,      *
*                type definitions and function prototyping for the      *
*                validation module of the standard library SCecon       *
*                                                                       *
************************************************************************/

/**** includes *********************************************************/
#include <cldr.h>
#include <pmt.h>
#include <disc.h>
#include <vol.h>

#ifdef __cplusplus
extern "C" {
#endif

/*** typedefines *******************************************************/

/*,,SOT,,

VALIDATE: Definition of return types for validation routines
------------------------------------------------------------

This enumeration is defined as:

    typedef enum validate_tag
    {
        INVALID_VALIDATE = -1,
        Valid_data = 0,
        Invalid_accrfac,
        Invalid_accrfac_prepaid,
        Invalid_averaging,
        Invalid_bondtype,
        Invalid_boole,
        Invalid_bp_tax,
        Invalid_buy_date,
        Invalid_cal,
        Invalid_caldays,
        Invalid_cb_accru,
        Invalid_cbase,
        Invalid_cbodd,
        Invalid_cbodd_accru,
        Invalid_compounding,
        Invalid_conversion_factor,
        Invalid_date,
        Invalid_datearray,
        Invalid_deliv,
        Invalid_dex,
        Invalid_effective,
        Invalid_eomconv,
        Invalid_exdays,
        Invalid_filled,
        Invalid_first,
        Invalid_fixing,
        Invalid_fra,
        Invalid_freq,
        Invalid_holpre,
        Invalid_incl,
        Invalid_io,
        Invalid_irr,
        Invalid_irreg,
        Invalid_jgb,
        Invalid_last,
        Invalid_lastaccr,
        Invalid_matur,
        Invalid_nirreg,
        Invalid_npday,
        Invalid_oddconv,
        Invalid_optadd,
        Invalid_opttype,
        Invalid_paydayseq,
        Invalid_paying,
        Invalid_period,
        Invalid_pday,
        Invalid_pp_price,
        Invalid_pre,
        Invalid_premiumtype,
        Invalid_prepaid,
        Invalid_price_fra,
        Invalid_price_irf,
        Invalid_qbas,
        Invalid_qot,
        Invalid_repo_period,
        Invalid_schuldsch,
        Invalid_seclast,
        Invalid_sell_date,
        Invalid_seqconv,
        Invalid_settl,
        Invalid_snap2,
        Invalid_tax_c,
        Invalid_sum,
        Invalid_tax_cg,
        Invalid_teomatur,
        Invalid_term,
        Invalid_termunit,
        Invalid_xconv,
        Invalid_xpday,
        Invalid_BRDfeb,
        Invalid_CGB184,
        Invalid_LIBOR_frequency,
        Invalid_LIBOR_period,
        Array_not_sorted,
        Array_empty,
        Cday_last_not_equal_rday_last,
        Days_not_sorted,
        Days_not_unique,
        Dex_after_cday_last,
        Effective_after_first,
        Effective_after_lastaccr,
        Effective_later_than_stepcoup,
        First_after_first_irreg_day,
        First_after_last,
        First_disc_not_unity,
        Last_after_last_irreg_day,
        Last_date_in_day_later_than_cday_last,
        Last_date_in_pday_later_than_cday_last,
        Last_date_in_xpday_later_than_cday_last,
        Last_later_than_stepcoup,
        Lastaccr_after_last,
        Out_of_range,
        Settl_after_matur,
        Teomatur_after_last,
        Xpday_after_pday,
        Dpay_before_dfix,
        Trade_after_settle,
        Invalid_extrade,
        Invalid_discipol,
        Invalid_intpolconv,
        Invalid_irrconv,
        Invalid_num_avg,
        Davg1_after_davgN,
        Dobs1_after_dobsN,
        Invalid_alpha,
        Invalid_barrier,
        Invalid_gap,
        Invalid_scale,
        Invalid_knocktype,
        Invalid_payoff,
        Invalid_rebate,
        Invalid_strike,
        Invalid_xtrem,
        Invalid_prem,
        Dchoose_after_dfix,
        DavgN_after_dfix,
        DobsN_after_dfix,
        Dset_after_dfix,
        Matur_after_dfix,
        Wrong_sign_in_array,
        Invalid_coupon,
        Invalid_issue_price,
        Invalid_notional,
        Invalid_LIBORfix,
        Invalid_rpct_first,
        Invalid_busconv,
        Fix_start_after_fix_end,
        Fix_start_after_pay_day,
        Invalid_price,
        Invalid_base,
        Invalid_volconv,
        Invalid_b76sm,
        Invalid_keyconv,
        Invalid_riskconv,
        NULL_pointer,
        Invalid_decomp,
        Invalid_reset_nfirst,
        Invalid_reset_nfreq,
        Invalid_AIdays,
        Invalid_CMAdjOrder,
        Invalid_Correlation,
        Invalid_Debtor_rate,
        Invalid_lattice_size,
        NEGATIVE_VOL,
        NONPOSDEF_CORR,
        Invalid_rateconv,
        Invalid_payday,
        Settl_after_payday,
        Invalid_nextfix,
        Nextfix_before_effective,
        Invalid_bondseg,
        Invalid_issue,
        Invalid_bsectype,
        Type_not_bullet,
        Call_before_hurdle,
        Maturity_before_call,
        Invalid_call_price,
        Invalid_call_hurdle,
        Invalid_conversion_price,
        Invalid_kfdebtor_rate,
        Invalid_step,
        Invalid_sigma,
        Invalid_process_type,
        Invalid_chg_time,
        Invalid_cttype,
        Invalid_cfconv,
        Period_start_after_period_end
    }   VALIDATE ;

This type is the return type for all Validate_*() functions

,,EOT,,*/


typedef enum validate_tag
{
/**** Invalid VALIDATE ****/
    INVALID_VALIDATE = -1,
/**** No Error: ****/
    Valid_data = 0,
/**** Invalid Enum/Simple Type: ****/
    Invalid_accrfac,
    Invalid_accrfac_prepaid,
    Invalid_averaging,
    Invalid_bondtype,
    Invalid_boole,
    Invalid_bp_tax,
    Invalid_buy_date,
    Invalid_cal,
    Invalid_caldays,
    Invalid_cb_accru,
    Invalid_cbase,
    Invalid_cbodd,
    Invalid_cbodd_accru,
    Invalid_compounding,
    Invalid_conversion_factor,
    Invalid_date,
    Invalid_datearray,
    Invalid_deliv,
    Invalid_dex,
    Invalid_effective,
    Invalid_eomconv,
    Invalid_exdays,
    Invalid_filled,
    Invalid_first,
    Invalid_fixing,
    Invalid_fra,  /* FRA_STR */
    Invalid_freq,
    Invalid_holpre,
    Invalid_incl,
    Invalid_io,
    Invalid_irr,
    Invalid_irreg,
    Invalid_jgb,
    Invalid_last,
    Invalid_lastaccr,
    Invalid_matur,    /* FRA_STR */
    Invalid_nirreg,
    Invalid_npday,
    Invalid_oddconv,
    Invalid_optadd,
    Invalid_opttype,
    Invalid_paydayseq,  /* obsolete */
    Invalid_paying,
    Invalid_period,
    Invalid_pday,  /* obsolete */
    Invalid_pp_price,
    Invalid_pre,
    Invalid_premiumtype,
    Invalid_prepaid,
    Invalid_price_fra,    /* FRA_STR */
    Invalid_price_irf,  /* FRA_STR */
    Invalid_qbas,
    Invalid_qot,  /* FRA_STR */
    Invalid_repo_period,
    Invalid_schuldsch,
    Invalid_seclast,
    Invalid_sell_date,
    Invalid_seqconv,
    Invalid_settl,    /* FRA_STR */
    Invalid_snap2,
    Invalid_tax_c,
    Invalid_sum,
    Invalid_tax_cg,
    Invalid_teomatur,
    Invalid_term,
    Invalid_termunit,
    Invalid_xconv,
    Invalid_xpday,  /* obsolete */
    Invalid_BRDfeb,
    Invalid_CGB184,
    Invalid_LIBOR_frequency,
    Invalid_LIBOR_period,
    Array_not_sorted,
    Array_empty,
    Cday_last_not_equal_rday_last,  /* obsolete */
    Days_not_sorted,
    Days_not_unique,
    Dex_after_cday_last,  /* obsolete */
    Effective_after_first,
    Effective_after_lastaccr,
    Effective_later_than_stepcoup,
    First_after_first_irreg_day,  /* obsolete */
    First_after_last,
    First_disc_not_unity,
    Last_after_last_irreg_day,  /* obsolete */
    Last_date_in_day_later_than_cday_last,
    Last_date_in_pday_later_than_cday_last,
    Last_date_in_xpday_later_than_cday_last,  /* obsolete */
    Last_later_than_stepcoup,
    Lastaccr_after_last,
    Out_of_range,
    Settl_after_matur,    /* FRA_STR */
    Teomatur_after_last,  /* obsolete */
    Xpday_after_pday,
    Dpay_before_dfix,
    Trade_after_settle,
    Invalid_extrade,
    Invalid_discipol,
    Invalid_intpolconv,
    Invalid_irrconv,
    Invalid_num_avg,
    Davg1_after_davgN,
    Dobs1_after_dobsN,
    Invalid_alpha,
    Invalid_barrier,
    Invalid_gap,
    Invalid_scale,
    Invalid_knocktype,
    Invalid_payoff,
    Invalid_rebate,
    Invalid_strike,
    Invalid_xtrem,
    Invalid_prem,
    Dchoose_after_dfix,
    DavgN_after_dfix,
    DobsN_after_dfix,
    Dset_after_dfix,
    Matur_after_dfix,
    Wrong_sign_in_array,
    Invalid_coupon,
    Invalid_issue_price,
    Invalid_notional,
    Invalid_LIBORfix,
    Invalid_rpct_first,
    Invalid_busconv,
    Fix_start_after_fix_end,
    Fix_start_after_pay_day,
    Invalid_price,
    Invalid_base,
    Invalid_volconv,
    Invalid_b76sm,
    Invalid_keyconv,
    Invalid_riskconv,
    NULL_pointer,
    Invalid_decomp,
    Invalid_reset_nfirst,
    Invalid_reset_nfreq,
    Invalid_AIdays,
    Invalid_CMAdjOrder,
    Invalid_Correlation,
    Invalid_Debtor_rate,
    Invalid_lattice_size,
    NEGATIVE_VOL,
    NONPOSDEF_CORR,
    Invalid_rateconv,
    Invalid_payday,
    Settl_after_payday,
    Invalid_nextfix,
    Nextfix_before_effective,
    Invalid_bondseg,
    Invalid_issue,
    Invalid_bsectype,
    Type_not_bullet,
    Call_before_hurdle,
    Maturity_before_call,
    Invalid_call_price,
    Invalid_call_hurdle,
    Invalid_conversion_price,
    Invalid_kfdebtor_rate,
    Invalid_step,
    Invalid_sigma,
    Invalid_process_type,
    Invalid_chg_time,
    Invalid_cttype,
    Invalid_cfconv,
    Period_start_after_period_end
}   VALIDATE ;


/*  hfi-*/
typedef struct
{
    VALIDATE        enVal;
    char*           pszText;
} VALIDATE_ST, *VALIDATE_STP;

extern const VALIDATE_ST EV_ValidateTab[];

/*** function prototyping (validate.c) *************************************/

extern BOOLE Validate_BOOLE(BOOLE b) ;
extern BOOLE Validate_BONDTYPE(BONDTYPE bondtype) ;
extern BOOLE Validate_BUSCONV(BUSCONV busconv) ;
extern BOOLE Validate_CALCONV(CALCONV calconv) ;
extern BOOLE Validate_DISCIPOL(DISCIPOL d);
extern BOOLE Validate_EOMCONV(EOMCONV eomconv) ;
extern BOOLE Validate_INTPOLCONV(INTPOLCONV intpol) ;
extern BOOLE Validate_IRRCONV(IRRCONV irrconv) ;
extern BOOLE Validate_KEYCONV(KEYCONV k) ;
extern BOOLE Validate_PERIOD(PERIOD *p) ;
extern BOOLE Validate_PMTFREQ(PMTFREQ pmtfreq) ;
extern BOOLE Validate_RISKCONV(RISKCONV r) ;
extern BOOLE Validate_SEQCONV(SEQCONV seqconv) ;
extern BOOLE Validate_TERMUNIT(TERMUNIT termunit) ;
extern BOOLE Validate_VOLCONV(VOLCONV volconv) ;
extern VALIDATE Validate_BOOLEARRAY(BOOLEARRAY pf, INTI c);
extern VALIDATE Validate_BUCKET(BUCKET* x);
extern VALIDATE Validate_BUCKETARRAY(BUCKETARRAY x, INTI n);
extern VALIDATE Validate_DATEARRAY(DATEARRAY datearray, INTI nday) ;
extern VALIDATE Validate_DISCFAC(DISCFAC *d) ;
extern VALIDATE Validate_DFPARMS(DFPARMS *d);
extern VALIDATE Validate_DFSPREAD(DFSPREAD *dfs) ;
extern VALIDATE Validate_DFSPREADARRAY(DFSPREADARRAY cm, INTI n);
extern VALIDATE Validate_FL64ARRAY(FL64ARRAY pf, INTI c, 
                       BOOLE lbound, FL64 lb, BOOLE ubound, FL64 ub);
extern VALIDATE Validate_FL64MATRIX(FL64MATRIX pf, INTI nr, INTI nc,
                       BOOLE lbound, FL64 lb, BOOLE ubound, FL64 ub);
extern VALIDATE Validate_HOLI_STR(HOLI_STR *h) ;
extern VALIDATE Validate_ITERCTRL(ITERCTRL *f);
extern VALIDATE Validate_PERIODARRAY(PERIODARRAY x, INTI n);
extern VALIDATE Validate_PLAN_STR(PLAN_STR *plan) ;
extern VALIDATE Validate_PLAN_STR_SIGN(PLAN_STR *plan,    BOOLE sign) ;
extern VALIDATE Validate_PLAN_STR_SORTED(PLAN_STR *plan, SORTCONV sc) ;
extern VALIDATE Validate_PLAN_STR_SUM100(PLAN_STR *plan) ;
extern VALIDATE Validate_RISKSET(RISKSET *r) ;
extern VALIDATE Validate_STEP_STR(STEP_STR *x);
extern VALIDATE Validate_STEPARRAY(STEPARRAY x, INTI n);
extern VALIDATE Validate_VOL_STR(VOL_STR *vol) ;
extern VALIDATE Validate_VOLBOX(VOLBOX *vol);
extern VALIDATE Validate_ZRATE_STR(ZRATE_STR *f);
extern VALIDATE Validate_ZRATEARRAY(ZRATEARRAY x, INTI n);


#ifdef __cplusplus
}
#endif

#endif

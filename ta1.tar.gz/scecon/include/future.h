/* SCID @(#)future.h	1.13 (SimCorp) 99/10/19 16:25:56 */

#ifndef FUT_H_INCLUDED

#define FUT_H_INCLUDED

/************************************************************************
*                                                                       *
*    project    SCecon                                                  *
*                                                                       *
*    filename   future.h                                                *
*                                                                       *
*    this file contains definitions and function prototyping for the    *
*    routines in the SCecon Future pricing module.                      *
*                                                                       *
************************************************************************/

/*** includes **********************************************************/
#include <bond.h>

#ifdef __cplusplus
extern "C" {
#endif


/*** defines ***********************************************************/
#define SCFUTHUGE_VAL 9999.99


/*** typedefs **********************************************************/

/*,,SOT,,

CTDCONV : data type for cheapest to deliver
-------------------------------------------

The data type for handling cheapest to deliver, CTDCONV, is defined as

        typedef enum ctd_tag
        {
            CTD_PROFIT,
            CTD_REPO,
            CTD_CONRATIO
        }   CTDCONV ;

in future.h of the SCecon Library.

This convention is used to define the ranking criteria for selection of
the cheapest to deliver bond in a CTD future.

If the ranking criteria is CTD_PROFIT, the maximum delivery profit bond
is selected.

If the ranking criteria is CTD_REPO, the bond with the highest implied
repo rate is selected.

If the ranking criteria is CDT_CONRATIO, the minimum convertion ratio
bond is selected as cheapest to deliver.

It makes no difference whether you use CTD_PROFIT, CTD_CONRATIO or
CTD_REPO to find the cheapest to deliver bond.

The bond with the lowest convertion ratio will allways be the same as
the bond with the highest implied repo rate, ie. the bond with the higest
delivery profit.

The different criterias are included for your convenience, to give you
the maximum flexibility when designing your application.

,,EOT,,*/

typedef enum ctd_tag
{
    CTDCONV_INIT = -1,
    CTD_PROFIT,
    CTD_REPO,
    CTD_CONRATIO
}   CTDCONV ;


/*,,SOT,,

CFCONV: Convention for Conversion Factor Algorithms
---------------------------------------------------

The type is defined as:

        typedef enum CFCONV_tag
        {
            NO_CFCONV,
            CBOT_T_BOND,
            CBOT_T_NOTE,
            CBOT_CGB,
            LIFFE_GILT,
            LIFFE_BUND,
            LIFFE_JGB,
            LIFFE_BTP,
            EUREX_BUND,
            EUREX_SGB,
            MATIF_NOT,
            MIF_BTP,
            OM_STAT,
            MEFF_BONOS,
            ME_CGB,
            TSE_T_BOND,
            TSE_JGB,
            SIMEX_JGB
        }   CFCONV ;

The individual elements descrive the algorithms used at various exchanges
for calculating Conversion Factors for deliverable bonds in futures
contracts:

            NO_CFCONV     - Default if no conversion factor (as in 
                            NOK, DKK, SEK, AUD, ..).
            CBOT_T_BOND   - US Treasury Bond (30Y) futures and 10-Year
                            Treasury Note futures traded at CBOT.
            CBOT_T_NOTE   - 2 and 5 - Year US Treasury Note futures
                            traded at CBOT.
            CBOT_CGB      - Canadian Gov. futures traded at CBOT.
            LIFFE_GILT    - 5 year and long UK Gilt futures traded at LIFFE.    
            LIFFE_BUND    - German Bund futures traded at LIFFE. 
            LIFFE_JGB     - Japanese Gov. Bond futures traded at LIFFE.
            LIFFE_BTP     - Italian Gov. Bond futures traded at LIFFE. 
            EUREX_BUND    - German Schatz, Bobl, Bund, and Buxl futures
                            traded at EUREX.
            EUREX_SGB     - Swiss Gov. Bond futures traded at EUREX.
            MATIF_NOT     - French and EMU Gov. Bond futures traded at MATIF.
            MIF_BTP       - 10 and 30 year Italian Gov. Bond futures traded
                            at MIF. 
            OM_STAT       - 2 and 10 year Swedish Gov. Bond futures traded
                            at OM.
            MEFF_BONOS    - Spanish Gov. Bond futures traded at MEFF.
            ME_CGB        - Canadian Gov. Bond futures traded at ME.
            TSE_T_BOND    - US Treasury Bond (30Y) futures traded at TSE.
            TSE_JGB       - JGB futures traded at TSE.
            SIMEX_JGB     - JGB futures traded at SIMEX.

,,EOT,,*/

typedef enum CFCONV_tag
{
    CFCONV_INIT = -1,
    NO_CFCONV,
    CBOT_T_BOND,
    CBOT_T_NOTE,
    CBOT_CGB,
    LIFFE_GILT,
    LIFFE_BUND,
    LIFFE_JGB,
    LIFFE_BTP,
    EUREX_BUND,
    EUREX_SGB,
    MATIF_NOT,
    MIF_BTP,
    OM_STAT,
    MEFF_BONOS,
    ME_CGB,
    TSE_T_BOND,
    TSE_JGB,
    SIMEX_JGB
}   CFCONV ;


/*,,SOT,,

REPOBOND : data type for Bond Repo's
------------------------------------

The data type for Bond Repo term sheet data is defined as

        typedef struct repobond_tag
        {
            DATESTR sell_date ;
            DATESTR buy_date ;
            FL64    sell_price ;
            FL64    rate ;
            IRRCONV irr ;
            CALCONV cal ;
            BOOLE   reverse ;
            FIXPAY  bond ;
        }   REPOBOND ;

the data must be interpreted as:

        sell_date is the date of the first transfer (sale) of the bond

        buy_date is the date of the second transfer (buy-back) of the bond

        sell_price is the price at which the bond is traded on sell_date.
        After entering into the repo this piece of data is fixed and used
        to calcaulate the buyback price. Before entering into the repo it
        should be considered as market data.

        rate is the repo rate (simple interest rate as a percentage)
        After entering into the repo this piece of data is fixed and used
        to calcaulate the buyback price. Before entering into the repo it
        should be considered as market data.

        irr is the specification of the interest rate convention used for 
        repo rate. For repos this is normally SIMPLE_MM or SIMPLE_REPO.
          
        cal is the repo calendar

        bond is the specification of the underlying bond

        reverse is a switch for reverse repo - False means 'normal' repo
        (bond is sold first and repurchased later), True means the
        reverse contract

,,EOT,,*/

typedef struct repobond_tag
{
    DATESTR sell_date ;
    DATESTR buy_date ;
    FL64    sell_price ;
    FL64    rate ;
    IRRCONV irr ;
    CALCONV cal ;
    BOOLE   reverse ;
    FIXPAY  bond ;
}   REPOBOND ;


/*,,SOT,,

FUTBOND: Bond futures data type
-------------------------------

This type is defined as:

        typedef struct futbond_tag
        {
            INTI        ndays ;
            DATEARRAY   ddays ;
            INTI        nbond ;
            FIXPAYARRAY fixp ;
            FL64ARRAY   cf ;
            FL64        futp ;
            BOOLE       margin ;
            BOOLE       xdiv3w ;
        }   FUTBOND ;

where

        ndays is the number of delivery days (in ddays).
        When calculating on CTD futures with a delivery date option a loop
        is performed over all delivery dates. Avoid making ndays to large
        since this can be costly, rather reduce ndays to a small number.
        Normally it is sufficient to use first or last delivery date in
        calculations.

        ddays[ndays] the actual delivery days (for most contracts only
        1).
        The delivery days may be generated using Cldr_FindDelvDays().

        nbond is the number of deliverable bonds

        fixp[nbond] is a list of bonds being deliverable
        (nbond entries)

        cf[nbond] is a list of conversion factors (nbond entries)

        futp is the contract price (agreed price)

        margin is True of margining is used, False if not (e.g.
        for forward contracts).

        xdiv3w True indicates that the Gilt Futures 3 week special
        ex-dividend period is invoked. Default should be False for any
        other futures contract.

see also Set_FUTBOND

,,EOT,,*/

typedef struct futbond_tag
{
    INTI        ndays ;
    DATEARRAY   ddays ;
    INTI        nbond ;
    FIXPAYARRAY fixp ;
    FL64ARRAY   cf ;
    FL64        futp ;
    BOOLE       margin ;
    BOOLE       xdiv3w ;
}   FUTBOND ;





/*,,SOT,,

FUTBONDBM: Container for Government Bond Futures Contracts.
-----------------------------------------------------------
  
Defined as

        typedef struct futbondbm_tag
        {
            CFCONV      cntr ;    
            DATESTR     first ;   
            DATESTR     last ;
            INTI        nbond ;
            BONDBMARRAY bonds ;
            BOOLE       do_cf ;
            FL64        cf_yield ;
            FL64ARRAY   cf ;      
        }   FUTBONDBM ;

The data type is used to defined standardised futures contracts based
on standardised bonds (BONDBM).

The data are interpreted as

    cntr    is the contract type (exchange and futures contract).

    first   is the first possible delivery date
            (no need to business day adjust)

    last    is the last possible delivery date (usually equal to first)
            (except for US Treasury futures, Gilt Futures and Canadian Gov. 
            Futures). (no need to business day adjust)

    nbond   is the number of deliverable bonds.

    bonds[nbond] is the list of standardised bonds.

    do_cf   Indicates whether conversion factors should be computed
            (enter True), of if these are specified in cf.

    cf_yield is the conversion factor yield. Only used if do_cf is
            True. 

    cf[nbond]|NULL Holds nbond entries of conversion factors.
            May be NULL only if do_cf = True.


Free with Free_FUTBONDBM().

,,EOT,,*/

typedef struct futbondbm_tag
{
    CFCONV      cntr ;    /* Used for cf calc */
    DATESTR     first ;   /* US, UK, CGB whole month ?? */
    DATESTR     last ;
    INTI        nbond ;
    BONDBMARRAY bonds ;
    BOOLE       do_cf ; 
    FL64        cf_yield ;
    FL64ARRAY   cf ;      
}   FUTBONDBM ;


/*,,SOT,,

CTDRES: Container for results for Bond Futures Calculations
-----------------------------------------------------------

Defined as

        typedef struct ctdres_tag
        {
            BOOLE     ok ;
            INTI      ndeliv ;
            FL64ARRAY fwd_rpo ; 
            INTIARRAY CTDix ;
            DATEARRAY deliv ;
        }   CTDRES ;

where

        ok is True if the calculation went ok, otherwise False

        ndeliv is the number of bonds deliverable

        fwd_rpo[ndeliv] is either the implied repo or imflied forward
        price per bond. ndeliv entries.

        CTDix[ndeliv] is a sorting index for the order of deliverability 
        of the individual bonds. 0 indicates the CTD etc. ndeliv entries.

        deliv[ndeliv] is the implied delivery date per bond. Relevant for 
        US Treasury futures, Gilt Futures and Canadian Gov. Futures where
        delivery can be during an entire month. ndeliv entries.

If ok is False then the 3 arrays are set to NULL.

Free with Free_CTDRES().

,,EOT,,*/

typedef struct ctdres_tag
{
    BOOLE     ok ;
    INTI      ndeliv ;
    FL64ARRAY fwd_rpo ;   /* ..NULL if ok = False */
    INTIARRAY CTDix ;
    DATEARRAY deliv ;
}   CTDRES ;




/*** macros  ***********************************************************/

/*
..
*/

#define fut_conversion_ratio(forw_p, cf) \
((cf) ? (forw_p)/(cf) : 0.0)

/*
..
*/

#define fut_invoice_ctd(fut_p, cf, acc, size) \
(((fut_p)*(cf) + (acc))*(size)/100.0)

/*
..
*/

#define fut_market_value(actual_price, prev_price) \
((actual_price) - (prev_price))

/*
..
*/

#define fut_basis(fut_p, spot_p) \
((fut_p) - (spot_p))


/*
..
*/

#define fut_profit_ctd(fut_price, forward, cf) \
((fut_price)*(cf) - (forward))


/*** prototypes  (future.c)  *******************************************/


/* Private functions */

extern FL64 Fut_Price_performanceindex(FL64    value0,
                                       FL64    t,
                                       FL64    rate,
                                       IRRCONV irr,
                                       INTI    qbas) ;

extern INTIARRAY Fut_select_ctd(FL64ARRAY f64,
                                INTI      n,
                                CTDCONV   code,
                                INTI      *index) ;

extern INTIARRAY Fut_select_wildcard(FL64ARRAY f64,
                                     INTI      n,
                                     CTDCONV   code,
                                     INTI      *index) ;


/*** prototypes  (futbseg.c)  *******************************************/


/* Public functions */
extern FL64ARRAY FutBondBM_ConFac(FUTBONDBM *fut,
                                  HOLI_STR  *holi);

extern CTDRES FutBondBM_CCREPO2Price(DATESTR   *settle, 
                                     FUTBONDBM *fut,
                                     FL64ARRAY spot,
                                     INTI      nspot,
                                     FL64      repo,     
                                     YTMSEG    repocnv,
                                     HOLI_STR  *holi) ;

extern CTDRES FutBondBM_CCREPO2Impl(DATESTR   *settle, 
                                    FL64      fwd,
                                    FUTBONDBM *fut,
                                    FL64ARRAY spot,
                                    INTI      nspot,
                                    YTMSEG    repocnv,
                                    HOLI_STR  *holi) ;

extern FUTBOND FutBondBM_FUTBONDBM2FUTBOND(DATESTR   *settle,
                                           FUTBONDBM *fut,
                                           HOLI_STR  *holi) ;

extern void Free_FUTBOND(FUTBOND *fut) ;

extern void Free_FUTBONDBM(FUTBONDBM *fut) ;

extern void Free_CTDRES(CTDRES *res) ;

/* Private functions */




/*** prototypes  (futdisc.c)  *****************************************/


/* Public functions */
extern FL64 FutBond_CC2Price(TRADEINFO *settle,
                      FUTBOND   *futb,
                      INTI      nspot,
                      FL64ARRAY spot,
                      INTI      noas,
                      DFSPREADARRAY dfs,
                      DISCFAC   *df,
                      HOLI_STR  *holi,
                      INTI      *ctd,
                      DATESTR   *delv) ;

extern FL64 FutBond_DF2Price(DATESTR     *analys,
                      FUTBOND     *futb,
                      INTI        noas,
                      DFSPREADARRAY dfs,
                      DISCFAC     *df,
                      HOLI_STR    *holi,
                      RISKSET     *risk,
                      FL64        *dp,
                      FL64        *ddp,
                      INTI        *ctd,
                      DATESTR     *delv) ;

extern FL64 FutBond_YTM2Price(DATESTR *analys,
                              FL64      ytm,
                              FUTBOND   *futb,
                              YTMCONV   *ytmc,
                              HOLI_STR  *holi,
                              RISKCONV  risk,
                              FL64      *dp,
                              FL64      *ddp,
                              INTI      *ctd,
                              DATESTR   *delv) ;

extern BOOLE FutBond_YTM2Yield(DATESTR   *deliv,
                        FL64      futp,
                        FL64      cf,
                        FIXPAY    *fixp,
                        YTMCONV   *ytmc,
                        HOLI_STR  *holi,
                        ITERCTRL  *ictrl,
                        FL64      *ytm) ;

extern BOOLE FutBond_CC2Impl(TRADEINFO *settle,
                      DATESTR   *deliv,
                      FL64      futp,
                      FL64      cf,
                      FIXPAY    *fixp,
                      HOLI_STR  *holi,
                      DFSPREAD  *dfs,
                      DISCFAC   *df,
                      YTMCONV   *ytmc,
                      ITERCTRL  *ictrl,
                      KEYCONV   what,
                      FL64      *impl) ;

extern FL64ARRAY FutBond_DF2Delta(DATESTR     *analys,
                           FUTBOND     *futb,
                           INTI        noas,
                           DFSPREADARRAY dfs,
                           DISCFAC     *df,
                           HOLI_STR    *holi,
                           DELTASET    *ds,
                           INTI        *ctd,
                           DATESTR     *delv) ;

extern FL64 FutBond_ConFac(FL64      coupon,
                PMTFREQ   freq,
                EXRULE    *exc,
                CALCONV   cal,
                EOMCONV   eom,
                ODDCONV   stub_front,
                DATESTR   *first_redemption,
                DATESTR   *last_redemption,
                DATESTR   *effec,
                DATESTR   *deliv,
                CFCONV    system,
                FL64      yield,
                HOLI_STR  *holi) ;

extern FL64 FutBond_PL2NPV(DATESTR     *analys,
                           DATESTR     *deliv,
                            FL64        futp,
                            FL64        agreed_futp,
                            BOOLE       margin,
                            DISCFAC     *df,
							HOLI_STR    *holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */


extern FUTBOND Set_FUTBOND(INTI        ndeliv,
                           DATEARRAY   deliv,
                           INTI        nbond,
                           FIXPAYARRAY fixp,
                           FL64ARRAY   cf,
                           FL64        futp,
                           BOOLE       margin,
                           BOOLE       xdiv3w) ;

/* Private functions */
extern DATEARRAY FutBond_Xdiv_Adjust(DATESTR   *settle,
                                     DATEARRAY days, 
                                     INTI      ndays,
                                     FIXPAY    *fixp,
                                     BOOLE     xdiv3w,
                                     HOLI_STR  *holi,
                                     INTI      *andays) ;




/*** prototypes  (repo.c)      ****************************************/


/* Public functions */
extern FL64 RepoBond_BuyBack(REPOBOND    *repo,
                             HOLI_STR    *holi) ;

extern FL64 RepoBond_CC2NPV(DATESTR     *analys,
                     FL64        spot,
                     REPOBOND    *repo,
                     HOLI_STR    *holi,
                     DISCFAC     *df,
                     DFSPREAD    *dfs) ;

extern FL64 RepoBond_DF2NPV(DATESTR     *analys,
                     REPOBOND    *repo,
                     HOLI_STR    *holi,
                     DISCFAC     *df,
                     DFSPREAD    *dfs,
                     RISKSET     *risk,
                     FL64        *dp,
                     FL64        *ddp) ;

extern BOOLE RepoBond_DF2Impl(REPOBOND  *repo,
                       FL64      bbp,
                       HOLI_STR  *holi,
                       DFSPREAD  *dfs,
                       DISCFAC   *df,
                       YTMCONV   *ytmc,
                       ITERCTRL  *ictrl,
                       KEYCONV   what,
                       FL64      *impl) ;

extern CFLWARRAY RepoBond_GenrCflw(REPOBOND      *repo,
                             HOLI_STR      *holi) ;

extern FL64 RepoBond_YTM2Price(FL64      ytm,
                        REPOBOND  *repo,
                        YTMCONV   *ytmc,
                        HOLI_STR  *holi,
                        RISKCONV  risk,
                        BOOLE     modf,
                        FL64      *dp,
                        FL64      *ddp) ;

extern FL64ARRAY RepoBond_DF2Delta(DATESTR  *analys,
                            REPOBOND *repo,
                            DISCFAC  *df,
                            DFSPREAD *dfs,
                            HOLI_STR *holi,
                            DELTASET *ds) ;


extern void Free_REPOBOND(REPOBOND *fixp);

/* Private functions */


#ifdef __cplusplus
}
#endif

#endif

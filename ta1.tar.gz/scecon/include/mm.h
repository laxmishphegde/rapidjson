/* SCID @(#)mm.h	1.2 (SimCorp) 99/02/19 14:13:40 */

#ifndef MM_H_INCLUDED

#define MM_H_INCLUDED

/************************************************************************
*                                                                       *
*    Project     SCecon                                                 *
*                                                                       *
*    filename    mm.h                                                   *
*                                                                       *
*    general     this file contains declarations, initializations,      *
*                typedefinitions and function prototyping for the       *
*                money market module of the standard library SCecon     *
*                                                                       *
************************************************************************/


/**** includes *********************************************************/
#include <stdlib.h>
#include <disc.h>
#include <swap.h>

#ifdef __cplusplus
extern "C" {
#endif

/*** typedefines ******************************************************/

/*,,SOT,,

QOTCONV : data type for quoting conventions used for interest rate quotes
-------------------------------------------------------------------------

In SCecon, the quoting conventions for caps and floors and other interest
rate options or FRA's are handled using the data type QOTCONV, defined as
in mm.h

        typedef enum qotconv_tag
        {
            Q_FLAT,
            Q_FLATFORW,
            Q_PERANNUM,
            Q_PERANNUMFORW
        } QOTCONV ;

Let us illustrate these different quoting methods using the Black 76
formula for an interest rate option.
Assuming a strike rate, X, and a FRA-rate of F, the Black 76 formula for
a call option becomes

        (F * N(d1) - X * N(d2))

according to the Q_PERANNUMFORW convention,

        (F * N(d1) - X * N(d2)) * disc

according to the Q_PERANNUM convention,

        (F * N(d1) - X * N(d2)) * (d_fra/d_year)

according to the Q_FLATFORW convention and

        (F * N(d1) - X * N(d2)) * (d_fra/d_year) * disc

according to the Q_FLAT convention.

In the formulas above, the following notations

        disc    the discount factor corresponding to the last
                day of the FRA period in question,

        d_fra   number of days in the FRA period in question
                with respect to calendar convention and

        d_year  number of days per year according to calendar
                convention

are used.

,,EOT,,*/

typedef enum qotconv_tag
{
    QOTCONV_INIT = -1,
    Q_FLAT,
    Q_FLATFORW,
    Q_PERANNUM,
    Q_PERANNUMFORW
}   QOTCONV ;


/*,,SOT,,

FRA_STR : data type for holding info on FRA's and IRF's
-------------------------------------------------------

This type for defining FRA/IRF's is defined as:

        typedef struct fra_str_tag
        {
            DATESTR  settl ;
            DATESTR  matur ;
            CALCONV  cal ;
            FL64     price ;
            BOOLE    fra ;
            QOTCONV  qot ;
            PMTFREQ  freq ;
            RATECONV type ;
            DATESTR  pay ;
        }   FRA_STR ;

for holding info on FRA's and Interest Rate Futures (IRF's).

This entries have the following meaning:

        settl is the settlement date for the contract (FRA start)

        matur is the maturity date for the contract (FRA period end date)

        cal is the calendar convention for calculating pay-off amount.

        price is the rate (%) for FRA's and the price (100 - rate) for
        IRF's.

        fra is True for FRA's and False for IRF's.
        It is assumed that IRF's are priced with margining and that
        the price is quoted as (100 - rate).

        qot is for quoting - typically Q_FLAT for FRA's.
        Not used for IRF's. Only relevant if type is MMRATE.

        freq indicates how the invoice amount is calculated for IRF's.
        If freq is NO_FREQUENCY then then invoice amount is calculated
        as Nominal * (SettleRate - ContractRate) * DayFrac. If instead
        freq is QUARTERLY then the invoice amount is calculated as;
        Nominal * (SettleRate - ContractRate) / 4,  etc.
        Only used if fra is False.

        type is the FRA/IRF type. Cannot be PARYIELD.
        See comments below.

        pay is the actual paydate (the default choice is settl).
        Only used for FRA's.

Here the dates are entered directly. This allows for broken date FRA's
as well as standardised FRA's. For entering IMM, CAD_BA, IMM_ZAR contracts
use the Cldr_NextROLL() routine for date generation.


The meaning of type is briefly elaborated below:

MMRATE means that the buyer of the FRA/IRF enter into a transaction where
a deposit is purchased at settle (at par) and paid back at maturity with 
interest. The interest is measured as a money market rate times FRA term. 
The price of the FRA is quoted as a SIMPLE_MM rate.
E.g. if the FRA is quoted at 15% for a 90 day period (365 days a year) it
means that that the FRA transactions are:

        1) receive 15% loan at FaceValue at settlement
        2) pay back FaceValue * (1 + 0.15 * 90 / 365) at maturity

This is the standard FRA in the Western countries.

BILLDISC means that the buyer of the FRA/IRF enter into a transaction where
a bill is purchased at settle at a discount and paid back at par at 
maturity of the FRA. 
The price of the FRA is quoted as a DISCOUNT rate.
E.g. if the FRA is quoted at 15% for a 90 day period (365 days a year) it
means that that the FRA transactions are:

        1) receive bill at FaceValue (1 - 0.15 * 90 / 365) at settlement
        2) pay back at par (FaceValue) at maturity

This is used in South Africa (Discounted Bank Bill).

BILLYIELD means that the buyer of the FRA/IRF enter into a transaction where
a bill is purchased at settle at a discount and paid back at par at 
maturity of the FRA. In contrast to BILLDISC the price of the FRA is quoted 
as a money market (SIMPLE_MM) rate. 
E.g. if the FRA is quoted at 15% for a 90 day period (365 days a year) it
means that that the FRA transactions are:

        1) receive bill at FaceValue / (1 + 0.15 * 90 / 365) at settlement
        2) pay back at par (FaceValue) at maturity

This principle is used for 90-day bank bill futures traded at Sidney Futures
Exchange.
see also Set_FRA_STR

,,EOT,,*/


typedef struct fra_str_tag
{
    DATESTR  settl ;
    DATESTR  matur ;
    CALCONV  cal ;
    FL64     price ;   /* Rate for FRA's and price for IRF's */
    BOOLE    fra ;
    QOTCONV  qot ;
    PMTFREQ  freq ;
    RATECONV type ;
    DATESTR  pay ;
}   FRA_STR ;





/*** function prototyping (fra.c) *************************************/


/* Public functions */
extern FL64 FRA_FRABBA2NPV(DATESTR   *analysis,
                           FRA_STR   *fra,
                           FL64      srate,
                           DISCFAC   *df,
                           HOLI_STR  *holi) ;

extern FL64 FRA_DF2NPV(DATESTR  *analysis,
                       FRA_STR  *fra,
                       DISCFAC  *df,
                       HOLI_STR *holi,
                       RISKSET  *risk,
                       FL64     *dp,
                       FL64     *ddp) ;

extern FL64 FRA_DF2Rate(FRA_STR  *fra,
                        DISCFAC  *df,
                        HOLI_STR *holi) ;

extern BOOLE FRA_DF2Impl(DATESTR    *analys,
                         FRA_STR    *fra,
                         DISCFAC    *df,
                         HOLI_STR   *holi,
                         KEYCONV    what,
                         FL64       *impl) ;

extern FL64ARRAY FRA_DF2Delta(DATESTR   *analys,
                  FRA_STR   *fra,
                  DISCFAC   *df,
                  HOLI_STR  *holi,
                  DELTASET  *ds) ;

extern FRA_STR Set_FRA_STR(DATESTR  *settl,
                       DATESTR  *matur,
                       CALCONV  cal,
                       FL64     price,
                       BOOLE    fra,
                       QOTCONV  qot,
                       PMTFREQ  freq,
                       RATECONV type,
                       DATESTR  *pay) ;

/* Private functions */
extern FL64 FRA_Payoff(FRA_STR  *fra,
                       FL64     srate,
                       HOLI_STR *holi) ;

extern IRRCONV FRA_RATECONV2IRRCONV(RATECONV fra) ;

/*** function prototyping (irf.c) *************************************/


/* Public functions */
extern FL64 IRF_FRABBA2NPV(DATESTR  *analys,
                           FRA_STR  *irf,
                           FL64     sprice,
                           HOLI_STR *holi) ;

extern FL64 IRF_DF2NPV(DATESTR    *analysis,
                       FRA_STR    *irf,
                       DISCFAC    *df,
                       HOLI_STR   *holi,
                       RISKSET    *risk,
                       FL64       *dp,
                       FL64       *ddp) ;

extern FL64 IRF_DF2Price(FRA_STR    *irf,
                           DISCFAC    *df,
                           HOLI_STR   *holi) ;

extern FL64ARRAY IRF_DF2Delta(DATESTR   *analys,
                  FRA_STR   *irf,
                  DISCFAC   *df,
                  HOLI_STR  *holi,
                  DELTASET  *ds) ;

/* Private function */
extern FL64 IRF_Payoff(FRA_STR  *irf,
                       FL64     sprice,
                       HOLI_STR *holi) ;

/*** function prototyping (mm.c) *********************************/


/* Private functions */
extern FL64 MM_AnnForw2Qot(FL64      disc,
                      DATESTR   *start,
                      DATESTR   *matur,
                      CALCONV   cal,
                      QOTCONV   qot,
                      FL64      price,
					  HOLI_STR  *holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */

extern FL64 MM_Ticksize_Adjust(FL64 rate,
                               FL64 ticksize) ;



/* Private functions */
#ifdef __cplusplus
}
#endif

#endif

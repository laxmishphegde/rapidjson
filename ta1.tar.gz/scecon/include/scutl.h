/* SCID @(#)scutl.h	1.71 (SimCorp) 99/10/11 17:02:36 */

#ifndef SCUTL_H
#define SCUTL_H

/************************************************************************
*                                                                       *
*    project    SCecon                                                  *
*                                                                       *
*    file name  scutl.h                                                 *
*                                                                       *
*    this file contains definitions and function prototyping for the    *
*    routines in the SCecon Utilities module.                           *
*                                                                       *
************************************************************************/

/***** includes  *******************************************************/
#include <scecon.h>
#include <scalloc.h>
#include <scmath.h>

#ifdef __cplusplus
extern "C" {
#endif

/***** defines   *******************************************************/
/* This value is the maximum value x that N01(x) can handle to avoid
   overflow (Mainframe, OS/2) ... */
#define XS_NAME "XS"        
  /* spot exchange rate asset class name. */
#define FX_CHAR 'X' 
  /* first character in exchange rate class name. */
#define COM_CHAR 'C'        
  /* first character in commodity class name. */
#define WILDCARD_FOR_CHAR '?' 
  /* wild card character for risk token characters. */
#define WILDCARD_FOR_STRING '*' 
  /* wild card character for risk token strings. */

/***** typedefs  *******************************************************/



/*,,SOT,,

SEARCHCONV : data type for search conventions
---------------------------------------------

Finding an element in a very large array may take some time. However,
knowledge of the elements approximate location in the large array can be
utilized to get faster results.

Given this knowledge, the SCecon gives you the flexibility to searh in
the array in an intelligent way using the SEARCHCONV data type defined
as

        typedef enum search_tag
        {
            SEARCH_FORWARDS,
            SEARCH_BACKWARDS,
            SEARCH_BISECTION
        }   SEARCHCONV ;

in scutl.h of the SCecon Library.

Using SEARCH_FORWARDS convention, to start looking at the beginning of
the arrray working your way forwards, while the SEARCH_BACKWARDS method
lets you start looking at the end of the array working your way
backwards.

If you have an array strictly sorted in an ascending or descending
order, you can succesfully use the SEARCH_BISECTION, that will divide
the array into halfs until the wanted element is found.

,,EOT,,*/

typedef enum search_tag
{
    SEARCHCONV_INIT = -1,
    SEARCH_FORWARDS,
    SEARCH_BACKWARDS,
    SEARCH_BISECTION
}   SEARCHCONV ;


/*,,SOT,,

INDEXCONV : data type for indexing method
-----------------------------------------

As mentioned under SEARCHCONV, you can searh for an element according to
various search conventions.

Now, what did you want this element for ?

Did you in fact want the element just after the element you found, e.g.
when finding the next coupon day ?
Or did you want the element just before, e.g. when finding the
outstanding debt on a given day ?
Or did you simply need the element, that you found ?

The INDEXCONV data type defined as

        typedef enum index_tag
        {
            NEXTINDEX,
            PREVINDEX,
            SAMEINDEX
        }   INDEXCONV ;

in scutl.h of the SCecon Library.

To be exact, using NEXTINDEX, you find the next index after your search
index, using PREVINDEX you find the last index prior to the search index
and using SAMEINDEX, you find the next index after your seach index
except if the corresponding element is the same as the one you sought
for.

,,EOT,,*/

typedef enum index_tag
{
    INDEXCONV_INIT = -1,
    NEXTINDEX,             /* Find next index after basis */
    PREVINDEX,             /* Find last index prior to basis */
    SAMEINDEX              /* As NEXTINDEX, but take the index if element
                              is equal to basis. */
}   INDEXCONV ;


/*,,SOT,,

ALIGNCONV : data type for alignment of arrays
---------------------------------------------

When generating arrays of data (say dates) in an interval one needs to
specify what to do if the data cannot be filled exactly in the period.
Would you like to align the data leftwards, rightwards or maybe to center
the data? This convention can be used to define the preference.

Suppose you want to insert 2 dates between January 1, 1992 and January 20,
1992 you cannot choose these new dates such that the 'distance' between
dates is constant. You can do 1 of three things:

        1) Choose the new dates as January 8 and January 15 1992
           according to ALIGNCONV being LEFT,

        2) Choose the new dates as January 6 and January 13 1992
           according to ALIGNCONV being RIGHT or

        3) Choose the new dates as January 7 and January 14 1992
           according to ALIGNCONV being CENTER.

The ALIGNCONV data type is defined as:

        typedef enum align_tag
        {
            LEFT,
            RIGHT,
            CENTER
        }   ALIGNCONV ;

in scutl.h of the SCecon Library.

,,EOT,,*/

typedef enum align_tag
{
    ALIGNCONV_INIT = -1,
    LEFT,                  /* Align leftwards */
    RIGHT,                 /* Align rightwards */
    CENTER                 /* Center ... */
}   ALIGNCONV ;


/*,,SOT,,

SORTCONV : data type for sorting arrays
---------------------------------------

This datatype is used to specify how to sort an array. The SORTCONV data
type is defined as:

        typedef enum sort_tag
        {
            ASCENDING,
            DESCENDING
        }   SORTCONV ;

in scutl.h of the SCecon Library.

,,EOT,,*/


typedef enum sort_tag
{
    SORTCONV_INIT = -1,
    ASCENDING,
    DESCENDING
}   SORTCONV ;


/*,,SOT,,

KEYCONV : data type for risk ratio / implied calculation
--------------------------------------------------------

When calculating risk ratios or implied ratios you specify the derivatives
with respect to price determining parameters and implied ratios by the
data type KEYCONV defined as

        typedef enum key_tag
        {
            KEY_PRICE,
            KEY_VOL,
            KEY_MATURITY,
            KEY_FIRSTDELIVERY,
            KEY_REPO,
            KEY_STRIKE,
            KEY_SIZE,
            KEY_DF,
            KEY_GAP,
            KEY_A,
            KEY_SIGMA,
            KEY_SPREAD,
            KEY_DIVYLD,
            KEY_SPOT,
            KEY_PROB,
            KEY_BPV,
            KEY_YTM,
            KEY_MATURITY_BPV,
            KEY_FRA,
            KEY_SHORT,
            KEY_LONG,
            KEY_GAMMAX,
            KEY_INDEX,
        }   KEYCONV ;

KEY_PRICE corresponds to the price of the underlying security or variable.
Use this to calculate delta and gamma wrt the underlying variable (i.e.
futures price or adjusted spot).

KEY_VOL corresponds to the volatility of the underlying security. Use
this to calculate vega and the second order derivative with respect to
volatility. In case of routines to calculate implied ratios, KEY_VOL
will calculate implied volatility.

KEY_MATURITY corresponds to term to option expiry. Use this convention
to calculate theta or implied term to volatility.

KEY_MATURITY_BPV is also used to calculate theta, but this theta is not
annualized - i.e. it is a simple shock difference.

KEY_FIRSTDELIVERY is relevant for american type options, and corresponds
to first eligible strike day. This convention is used only in the
routines related the the Cox, Ross and Rubinstein model for options on
stocks.

KEY_REPO and KEY_STRIKE correspond to the discount rate and agreed
strike price respectively.

The KEY_SIZE convention is relevant when finding contract sizes.

KEY_DF is used to calculate risk ratios for shocks to the term structure of
interest rates (or Discount Factors (DF)). Essentially this corresponds to
dollar duration and dollar convexity.

KEY_GAP is used for calculating the implied gap for options. This can be
used to find the premium for a CONTINGENT PREMIUM OPTION or PAY LATER
options.

KEY_A is used for calculating sensitivities wrt the a parameter in
the HWCF model (Hull & White refers to this as Vega2)

KEY_SIGMA is used for calculating sensitivities wrt the sigma parameter in
the HWCF model (Hull & White refers to this as Vega1)

KEY_SPREAD is used for calculating implied spreads-.

KEY_DIVYLD is used for calculating implied dividend yields.

KEY_SPOT corresponds to the spot price of the underlying security or
variable. Use this to calculate delta and gamma wrt the SPOT price of
the underlying variable.

KEY_PROB is used to specify calculation of the probability of being in the
money for options. This an alternative definition for delta / gamma that are
sometimes used for swaptions. Essentially in this setup:

        delta = N(d1)
        gamma = d(delta) / dF

here F is the underlying variable. This formulation is only valid for
vanilla options.

KEY_BPV defines basispoint values with respect to zero curves (DF) or the
underlying rate (YTM, repo).

KEY_YTM defines sensitivities with respect to yield to maturity

KEY_FRA   The FRA rate, ie. from start of the FRA period 
          untill end of FRA period.
KEY_SHORT The short rate, ie. from analysis date till start of FRA period.
KEY_LONG  The long rate, ie. from analysis date till end of FRA period.

KEY_GAMMAX The second order derivative wrt two different variables.

KEY_INDEX The sensitivity wrt to tthe change in an index used when pricing
indexed bonds.          

,,EOT,,*/


typedef enum key_tag
{
    KEYCONV_INIT = -1,
    KEY_PRICE,
    KEY_VOL,
    KEY_MATURITY,
    KEY_FIRSTDELIVERY,
    KEY_REPO,
    KEY_STRIKE,
    KEY_SIZE,
    KEY_DF,
    KEY_GAP,
    KEY_A,
    KEY_SIGMA,
    KEY_SPREAD,
    KEY_DIVYLD,
    KEY_SPOT,
    KEY_PROB,
    KEY_BPV,
    KEY_YTM,
    KEY_MATURITY_BPV,
    KEY_FRA,
    KEY_SHORT,
    KEY_LONG,
    KEY_GAMMAX,
    KEY_INDEX
}   KEYCONV ;


/***** defines   *******************************************************/

#define SPLINE_MAX 0.99E30      /* Used for cubic spline interpolation */

/***** function prototypes (scutl.c) ***********************************/


/* Public functions */

extern INTIARRAY Scutl_Indexx_FL64(INTI      n,
                                   FL64ARRAY arr,
                                   SORTCONV  sort) ;

extern INTIARRAY Scutl_Indexx_INTI(INTI      n,
                                   INTIARRAY arr,
                                   SORTCONV  sort) ;

extern void Scutl_Permute_FL64(INTI     n,
                               INTIARRAY index,
                               FL64ARRAY arr) ;

extern void Scutl_Permute_INTI(INTI     n,
                               INTIARRAY index,
                               INTIARRAY arr) ;

extern INTI Scutl_Find_Termindex(FL64ARRAY  terms,
                          INTI       count,
                          FL64       basisterm,
                          INTI       start,
                          SEARCHCONV conv,
                          INDEXCONV  iconv) ;

/* Private functions */
extern FL64 Scutl_Default_Shock(FL64 shock, KEYCONV key) ;

extern FL64ARRAY   Scutl_SubdivideFL64ARRAY(FL64ARRAY   in,
                            INTI        nin,
                            INTI        ratio,
                            FL64        last,
                            INTI        *nout) ;


/***** function prototypes (scutltkn.c) ********************************/


/* Public functions */
extern BOOLE VAR_RiskTokenLT(RISKTOKEN *rf1, RISKTOKEN *rf2) ;

extern BOOLE VAR_RiskTokenEQ(RISKTOKEN *rf1, RISKTOKEN *rf2) ;

extern BOOLE VAR_RiskTokenLE(RISKTOKEN *rf1, RISKTOKEN *rf2) ;

extern INTI VAR_RiskTokenCmp(RISKTOKEN  *rf1, RISKTOKEN *rf2, 
                             BOOLE wc) ;

extern void VAR_RiskTokenCpy(RISKTOKEN *rt1, RISKTOKEN *rt2) ;

extern RISKPOSLIST VAR_MergeRISKPOSLIST(
    RISKPOSLIST* rp1,
    RISKPOSLIST* rp2);

extern RISKTOKENARRAY VAR_UniqueRISKTOKENARRAY(
    RISKTOKENARRAY rt1, INTI nrt1,
    RISKTOKENARRAY rt2, INTI nrt2,
    INTI *nrt);

extern INTIARRAY VAR_SortRISKPOSLIST(RISKPOSLIST *pos) ;

extern INTIARRAY VAR_SortRISKTOKENARRAY(RISKTOKENARRAY   rp,
                                   INTI             nrp) ;


extern void Free_RISKPOSLIST(RISKPOSLIST* rp);

/* Private functions */

extern BOOLE VAR_RiskToken_Unique_cpy(
    RISKTOKEN *oldToken,
    RISKTOKEN *newToken);
extern void permute_FL64ARRAY(FL64ARRAY a,  INTI n, INTIARRAY  idx) ;
extern INTI wc_strncmp(char *s1, char *s2, INTI len) ;
extern INTI wc_strcmp(char *s1, char *s2) ;


#ifdef __cplusplus
}
#endif

#endif

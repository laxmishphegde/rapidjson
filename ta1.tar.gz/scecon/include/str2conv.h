/* SCID @(#)str2conv.h	1.143 (SimCorp) 99/10/26 09:11:32 */

#ifndef STR2CONV_H_INCLUDED

#define STR2CONV_H_INCLUDED

/************************************************************************
*                                                                       *
*   project     SCecon                                                  *
*                                                                       *
*   file name   str2conv.h                                              *
*                                                                       *
*   general     This file contains the header file for the example code *
*               in str2conv.c                                           *
*                                                                       *
************************************************************************/

/*** includes **********************************************************/
#include <ctype.h>
#include <stdio.h>
#include <string.h>
#include <validate.h>

#ifdef __cplusplus
extern "C" {
#endif

/*** prototypes  *******************************************************/

/* Only use unsigned format IDs !! */
extern COUNT Read_FormatId(FILE *in, FILE *out);
extern int IOUtil_SkipSpace(FILE *in);
extern void IOUtil_SkipLine(FILE *in);
extern void IOUtil_ParseLine(FILE *in, FILE *out);
extern void IOUtil_ParseComment(FILE* in, FILE* out);
extern BOOLE IOUtil_ReadComment(FILE *in, FILE *out);
extern BOOLE IOUtil_IsComment(int ch);
extern INTI Compare_Single(FILE* in, FILE* out, BOOLE okres, 
                              FL64 res, FL64 acc) ;
extern INTI Compare_Risk(FILE* in, FILE* out, BOOLE okres, 
                            FL64 res, FL64 res1, FL64 res2,  
                            FL64 acc);
 
extern void Str_Uppercase(TEXT s) ;
void Filename_In2Out(char *inname, char *outname);

extern EOMCONV     Str2EOMCONV(TEXT txt) ;
extern CALCONV     Str2CALCONV(TEXT txt) ;
extern BUSCONV     Str2BUSCONV(TEXT txt) ;
extern SEQCONV     Str2SEQCONV(TEXT txt) ;
extern PMTFREQ     Str2PMTFREQ(TEXT txt) ;
extern IRRCONV     Str2IRRCONV(TEXT txt) ;
extern BONDTYPE    Str2BONDTYPE(TEXT txt) ;
extern SEARCHCONV  Str2SEARCHCONV(TEXT txt) ;
extern INDEXCONV   Str2INDEXCONV(TEXT txt) ;
extern KEYCONV     Str2KEYCONV(TEXT txt) ;
extern INTPOLCONV  Str2INTPOLCONV(TEXT txt) ;
extern RISKCONV    Str2RISKCONV(TEXT txt) ;
extern SHOCKCONV   Str2SHOCKCONV(TEXT txt) ;
extern BOOLE       Str2BOOLE(TEXT txt) ;
extern ALIGNCONV   Str2ALIGNCONV(TEXT txt) ;
extern SORTCONV    Str2SORTCONV(TEXT txt) ;
extern TERMUNIT    Str2TERMUNIT(TEXT txt) ;
extern VOLCONV     Str2VOLCONV(TEXT txt) ;
extern DISCIPOL    Str2DISCIPOL(TEXT txt) ;
extern INWHATVOL   Str2INWHATVOL(TEXT txt) ;
extern VALIDATE    Str2VALIDATE(TEXT txt) ;
extern DFWHICH     Str2DFWHICH(TEXT txt) ;
extern WEEKDAY     Str2WEEKDAY(TEXT txt);
extern ANCHORDAY  Str2ANCHORDAY(TEXT txt);


extern PLANARRAY Read_PLANARRAY(FILE *in) ;

extern FL64ARRAY Read_FL64ARRAY(FILE *in, INTI *n) ;
extern INTIARRAY Read_INTIARRAY(FILE *in, INTI *n) ;
extern HOLI_STR  Read_HOLI_STR(FILE *in, FILE *out) ;
extern STEPARRAY Read_STEPARRAY(FILE *in, FILE *out, INTI *nstep) ;
extern BUCKETARRAY Read_BUCKETARRAY(FILE *in, FILE *out, INTI *nb) ;
extern DATEARRAY Read_DATEARRAY(FILE *in, FILE *out, INTI *n) ;
extern DISCFAC   Read_DISCFAC(FILE *in, FILE *out) ;
extern VOL_STR   Read_VOL_STR(FILE *in, FILE *out) ;
extern RISKSET   Read_RISKSET(FILE *in, FILE *out) ;
extern PERIOD    Read_PERIOD(FILE *in) ;
extern VOLBOX*   Read_VOLBOX(FILE *in, FILE *out) ;
extern DFSPREAD  Read_DFSPREAD(FILE *in, FILE *out) ;
extern DFSPREADARRAY Read_DFSPREADARRAY(FILE *in, FILE *out, INTI *ns) ;
extern ITERCTRL   Read_ITERCTRL(FILE *in, FILE *out) ;
extern DFPARMS    Read_DFPARMS(FILE *in, FILE *out) ;
extern FL64MATRIX Read_FL64MATRIX(FILE *in, FILE *out, INTI *i1, INTI *i2);
extern IRRATE     Read_IRRATE(FILE *in, FILE *out) ;
extern ZRATE_STR  Read_ZRATE_STR(FILE *in, FILE *out) ;
extern HOLIRULEARRAY Read_HOLIRULEARRAY(FILE* in,  FILE* out,
                                    INTI* nrules);

extern void Write_PLANARRAY(FILE *out, PLANARRAY plan) ;
extern void Write_FL64ARRAY(FILE *out, FL64ARRAY f64, INTI n) ;
extern void Write_INTIARRAY(FILE *out, INTIARRAY inti, INTI n) ;
extern void Write_PERIOD(FILE *out, char *txt, PERIOD *p) ;
extern void Write_ValidateStatus(VALIDATE val) ;

extern INTI Write_RiskDiff(BOOLE okres, BOOLE okexp, FL64 fres, FL64 fres1, 
                FL64 fres2, FL64 fexp, FL64 fexp1, FL64 fexp2, 
                FL64 acc, FILE *out) ;
extern INTI Write_SingleDiff(BOOLE ok, BOOLE okexp, FL64 fres, FL64 fexp, 
                                FL64 acc, FILE *out) ;
extern INTI Write_DeltaDiff(BOOLE ok, BOOLE okexp, FL64ARRAY dvres, INTI ndv,
                               FL64ARRAY dvexp, INTI ndvexp,
                               FL64 acc, FILE *out) ;
extern INTI Write_PlanDiff(PLANARRAY exp, PLANARRAY res, FILE *out) ;
extern INTI WriteFL64ARRAYDiff(BOOLE okexp, FL64ARRAY dvexp, 
                INTI nshockexp, BOOLE ok, FL64ARRAY dv, INTI nshock, 
                FILE *out, FL64 tol);
extern INTI WriteFL64ARRAYRelDiff(BOOLE okexp, FL64ARRAY dvexp, INTI nshockexp, 
                        BOOLE ok, FL64ARRAY dv, INTI nshock, 
                        FILE* out, FL64 tol);
extern void Write_FL64MATRIX(FL64MATRIX m, 
                      INTI       n1, 
                      INTI       n2, 
                      INTI       decimal_places,
                      FILE*      out);
extern INTI Write_FL64MATRIXdiff(FILE*  in, FILE*  out, BOOLE  ok, 
        FL64MATRIX act, INTI actrows, INTI actcols, 
        BOOLE okexp, FL64 tol);

extern INTI Write_FL64ARRAYdiff(FILE*  in, FILE*  out, BOOLE  ok, 
       FL64ARRAY  act, INTI  actrows,  
       BOOLE  okexp, FL64  tol) ;
extern INTI Write_TSDiff(FILE* in, FILE* out, TS_STR* ts, FL64 acc);
extern INTI Write_PlansDiff(FILE* in, FILE* out, PLANARRAY res, 
    INTI nres);

extern void Write_VALIDATEError(FILE* out, VALIDATE val);

extern void TERMUNIT2Str(TERMUNIT u, char *s) ;
extern void VALIDATE2Str(VALIDATE val, TEXT txt) ;
extern void BOOLE2Str(BOOLE x, TEXT txt) ;



#ifdef __cplusplus
}

#endif

#endif





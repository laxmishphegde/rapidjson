/* SCCS: @(#)strntio.h	1.2 (SimCorp) 99/02/19 14:10:35 */

#ifndef STRNTIO_H
#define STRNTIO_H

/************************************************************************
*                                                                       *
*   project     SCecon                                                  *
*                                                                       *
*   general     This file contains the header file for the example code *
*               in str2conv.c                                           *
*                                                                       *
************************************************************************/

/*** includes **********************************************************/
#include <str2conv.h>
#include <strnote.h>

#ifdef __cplusplus
extern "C" {
#endif

/*** prototypes  *******************************************************/

extern BLACKDIFF Read_BLACKDIFF(FILE *in, FILE *out) ;

extern ACCRNOTE  Read_ACCRNOTE(FILE *in, FILE *out) ;
extern RANGENOTE Read_RANGENOTE(FILE *in, FILE *out) ;
extern RESETACCRNOTE Read_RESETACCRNOTE(FILE* in, FILE* out) ;

extern OPTSPREAD Read_OPTSPREAD(FILE* in, FILE* out) ;


#ifdef __cplusplus
}
#endif

#endif

/* SCID @(#)vol.h	1.29 (SimCorp) 99/02/19 14:17:42 */

#ifndef VOL_H_INCLUDED

#define VOL_H_INCLUDED

/************************************************************************
*                                                                       *
*    project    SCecon                                                  *
*                                                                       *
*    filename   vol.h                                                   *
*                                                                       *
*    this file contains definitions and function prototyping for the    *
*    routines in the SCecon volatility conventions module.              *
*                                                                       *
************************************************************************/

/***** includes  *******************************************************/
#include <cldr.h>

#ifdef __cplusplus
extern "C" {
#endif

/***** typedefs  *******************************************************/

/*,,SOT,,

TSOV_STR and TSOVARRAY : data types for term structure of volatility
-------------------------------------------------------------------

In SCecon term structure of volatilities are represented in the data type
TSOV_STR, defined as

        typedef struct
        {
            INTI      count ;
            FL64ARRAY term ;
            FL64ARRAY vol ;
        }   TSOV_STR ;

in vol.h of the SCecon Library.

The entities in this data type are

        count   number of elements in term and vol,

        term    term[count] are the terms for the vols in
                fractional years,

        vol     vol[count] are the vols in percent

List's of TSOV_STR's can be hanled via:

        typedef TSOV_STR * TSOVARRAY ;

in vol.h of the SCecon Library.

,,EOT,,*/

typedef struct
{
    INTI       count;
    FL64ARRAY  term ;
    FL64ARRAY  vol ;
}   TSOV_STR ;


/*,,SOT,,

TSOVARRAY : a data type for term structure of volatility arrays
---------------------------------------------------------------

The TSOVARRAY data type is intended for keeping information on several
term structure of volatilities at the same time.

For further information on the TSOVARRAY data type, consult the section
"TSOV_STR and TSOVARRAY : data types for term structure of volatilities"
in this chapter.

,,EOT,,*/

typedef TSOV_STR * TSOVARRAY ;


/*,,SOT,,

VOLCONV : convention for forward volatility quotes
--------------------------------------------------

In SCecon, forward volatility conventions must be specified as the data
type VOLCONV, defined as

    typedef enum vol_tag
    {
        FORWFORW,
        FORWVOL
    }   VOLCONV ;

in vol.h of the SCecon Library.

These 2 types have the following meanings

FORWFORW means forward-forward volatility which implies that a cap - a
series of caplets or differential caps - must be valued with different
forward volatilities for each maturity.

In contrast the forward volatility, FORWVOL, implies that all caplets of
the cap must be valued with the same forward volatility.

The volatility structures found for each of these types are different.
In general the FORWVOL curve will look like a 'running average' of the
FORWFORW curve.

,,EOT,,*/

typedef enum vol_tag
{
    VOLCONV_INIT = -1,
    FORWFORW,
    FORWVOL
}   VOLCONV ;


/*,,SOT,,

VOL_STR: Type for holding info on volatility structures
-------------------------------------------------------

This type is defined in vol.h as:

        typedef struct volstr_tag
        {
            PLAN_STR   *vol ;
            VOLCONV    vc ;
            CALCONV    cal ;
            INTPOLCONV iconv ;
        }   VOL_STR ;

The data should be interpreted as:

        vol is the term structure of volatilities

        vc is the volatility type

        cal is the calendar used for interpolating in vol.

        iconv is the interpolation convention. Must be either
        LINEAR_EXTRAPOL or LINEAR_FLAT_END.

see also Set_VOL_STR

,,EOT,,*/

typedef struct volstr_tag
{
    PLAN_STR   *vol ;
    VOLCONV    vc ;
    CALCONV    cal ;
    INTPOLCONV iconv ;
}   VOL_STR ;


/*,,SOT,,

INWHATVOL: information on the quantities in which to interpolate volatilities
-----------------------------------------------------------------------------

This type is defined as

        typedef enum inwhatvol_tag
        {
            STDEV,
            VAR,
            VOL
        }   INWHATVOL ;

to indicate the underlying variable in which interpolation is performed.

,,EOT,,*/

typedef enum inwhatvol_tag
{
    STDEV,
    VAR,
    VOL
}   INWHATVOL ;


/*,,SOT,,

VOLBOX: type for holding a 3D volatility matrix
---------------------------------------------------

This type is defined as

        typedef struct volbox_tag
        {
            INTI         count_OM ;
            INTI         count_S ;
            INTI         count_SM ;
            INTI         filled_OM;
            INTI         filled_S ;
            INTI         filled_SM ;
            DATEARRAY    optmatur ;
            FL64ARRAY    strike ;
            PERIODARRAY  swapmatur ;
            FL64         ***vol ;
            VOLCONV      volconv ;
            INTPOLCONV   ipol ;
            INWHATVOL    in_what ;
            CALCONV      cal ;
            EOMCONV      eom ;
            BOOLE        price_vol ;
        }   VOLBOX ;

The data should be interpreted as

        count_OM    allocated range sizes for Option Maturity,
        count_S     Strike and
        count_SM    Swap Maturity, resp.

        filled_OM   filled range sizes for Option Maturity,
        filled_S    Strike and
        filled_SM   Swap Maturity, resp.

        optmatur    optmatur[filled_OM] is an array of dates giving the range
                    of Option Maturities
        swapmatur   swapmatur[filled_SM] is an array of periods giving the
                    range of Swap or Bond Maturities - i.e. the maturity of
                    the underlying security.
                    For practical purposes it is advisable to let all unit's in
                    swapmatur[filled_SM].unit be the same.

        strike      strike[filled_S] is an array of strikes in Strike range

        vol         triple pointer to 3D vol matrix (OM x S x SM)

        volconv     volatility quoting convention

        ipol        interpolation convention
                    NOT USED:   sofar only LINEAR INTERPOLATION
                                with FLAT EXTRAPOLATION supported

        in_what     in which quantity to interpolate

        cal         day count fraction to use in interpolation

        eom         end-of-month convention

        price_vol   'True' if price vol's, 'False' if yield vol's

,,EOT,,*/

typedef struct volbox_tag
{
    INTI        count_OM;
    INTI        count_S;
    INTI        count_SM ;
    INTI        filled_OM ;
    INTI        filled_S ;
    INTI        filled_SM ;
    DATEARRAY   optmatur ;
    FL64ARRAY   strike ;
    PERIODARRAY swapmatur ;
    FL64        ***vol ;
    VOLCONV     volconv ;
    INTPOLCONV  ipol ;
    INWHATVOL   in_what ;
    CALCONV     cal ;
    EOMCONV     eom ;
    BOOLE       price_vol ;
}   VOLBOX ;


/*** prototypes (volalloc.c)  ******************************************/


/* Public functions */

extern TSOVARRAY Alloc_TSOVARRAY(INTI nstr, INTI np);
extern void      Free_TSOVARRAY(TSOVARRAY s, INTI nstr);
extern VOLBOX    *Alloc_VOLBOX(INTI count_OM, INTI count_S, INTI count_SM) ;
extern void      Free_VOLBOX(VOLBOX *tsov) ;
extern void      Free_VOL_STR(VOL_STR *v) ;

/* Private functions */

/*** prototypes (vol.c)  ******************************************/


/* Public functions */

extern FL64 Vol_Ann2Per(FL64 vol, FL64 t) ;

extern FL64 Vol_Per2Ann(FL64 vol, FL64 t) ;

extern FL64 Vol_Interpolation(DATESTR  *date,
                              VOL_STR  *v,
							  HOLI_STR *holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */

extern FL64 Vol_Spot2Forw(DATESTR        *today,
                         VOL_STR        *ts,
                         DATESTR        *date1,
                         DATESTR        *date2,
						 HOLI_STR       *holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */

extern VOL_STR Set_VOL_STR(PLAN_STR *vol, CALCONV cal, VOLCONV vc,
                              INTPOLCONV iconv) ;

/* Private functions */
extern VOL_STR Vol_Shock_Vol(VOL_STR *vol, FL64 shock, BOOLE ds) ;

extern TSOVARRAY Vol_Get_Vol(TSOV_STR  *tsin,
                            FL64ARRAY  terms,
                            INTI       n,
                            INTPOLCONV intpol) ;

extern FL64 Vol_Get_TSOVqot(TSOV_STR    *tsin,
                     FL64       term,
                     INTPOLCONV intpol) ;

extern FL64 Vol_Linear_Lookup(    VOLBOX     *tsov,
                            DATESTR        *today,
                            DATESTR        *optmatur,
                            FL64        strike,
                            PERIOD        *swapmatur,
                            HOLI_STR      *holi) ;   /* PMSTA-22396  - SRIDHARA - 160503*/

extern VOLBOX *Vol_Extrapol(VOLBOX      *ts,
                        DATESTR     *optmatur,
                        FL64        strike,
                        PERIOD         *swapmatur,
                        HOLI_STR   *holi,
                        BOOLE         *new1) ;

extern FL64 Vol_Bivariate2Vol(FL64 vol1, FL64 vol2, FL64 corr);


#ifdef __cplusplus
}
#endif

#endif

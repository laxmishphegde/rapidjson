/* SCID @(#)futsc.h	1.2 (SimCorp) 99/02/19 14:13:24 */

#ifndef FUTSC_H
#define FUTSC_H

/************************************************************************
*                                                                       *
*    project    SCecon                                                  *
*                                                                       *
*    filename   scenario.h                                              *
*                                                                       *
*    this file contains definitions and function prototyping for the    *
*    routines in the SCecon Scenario function module.                   *
*                                                                       *
************************************************************************/

/***** includes  *******************************************************/
#include <mm.h>
#include <swapval.h>
#include <scenario.h>

/***** C++ Convenience *************************************************/
#ifdef __cplusplus
extern "C" {
#endif


/*** prototypes  (futsc.c) *****************************************/


/* Public functions */

extern FL64ARRAY  SwapFix_DF2ScenBPV(DATESTR  *analys,
                        DISCFAC    *df,
                        FL64       fx_spot,
                        SWAPFIX    *sfx,
                        HOLI_STR   *holi,
                        DELTASET   *ds,
                        FXSHOCKSET *fxs);
extern FL64ARRAY  FRA_DF2ScenBPV(DATESTR  *analys,
                        DISCFAC    *df,
                        FL64       fx_spot,
                        FRA_STR   *fra,
                        HOLI_STR   *holi,
                        DELTASET   *ds,
                        FXSHOCKSET *fxs);
extern FL64ARRAY  IRF_DF2ScenBPV(DATESTR  *analys,
                        DISCFAC    *df,
                        FL64       fx_spot,
                        FRA_STR   *fra,
                        HOLI_STR   *holi,
                        DELTASET   *ds,
                        FXSHOCKSET *fxs);
extern FL64ARRAY  RepoBond_DF2ScenBPV(DATESTR  *analys,
                        DISCFAC    *df,
                        FL64       fx_spot,
                        REPOBOND *repo,
                        HOLI_STR   *holi,
                        DFSPREAD   *dfs,
                        DELTASET   *ds,
                        FXSHOCKSET *fxs);
extern FL64ARRAY  SwapFl_DF2ScenBPV(DATESTR  *analys,
                        DISCFAC    *df_cflw,
                        DISCFAC    *df_disc,
                        CMCONVADJ  *cmadj,
                        FL64       fx_spot,
                        SWAPFLOAT  *sfl,
                        HOLI_STR   *holi,
                        DELTASET   *ds_cflw,
                        DELTASET   *ds_disc,
                        FXSHOCKSET *fxs);
extern FL64ARRAY  FRN_DF2ScenBPV(DATESTR  *analys,
                        DISCFAC    *df_cflw,
                        DISCFAC    *df_disc,
                        CMCONVADJ  *cmadj,
                        FL64       fx_spot,
                        SWAPFLOAT  *frn,
                        HOLI_STR   *holi,
                        DELTASET   *ds_cflw,
                        DELTASET   *ds_disc,
                        FXSHOCKSET *fxs);
extern FL64ARRAY FutBond_DF2ScenBPV(DATESTR       *analys,
                                       FL64          fx_spot,
                                       FUTBOND       *futb,      
                                       INTI          noas,       
                                       DFSPREADARRAY dfsarr,   
                                       DISCFAC       *df,        
                                       HOLI_STR      *holi,      
                                       DELTASET      *ds,
                                       FXSHOCKSET    *fxs);

#ifdef __cplusplus
}
#endif

#endif

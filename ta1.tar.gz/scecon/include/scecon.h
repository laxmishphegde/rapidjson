#ifndef SCECON_H
#define SCECON_H

#include <sccsid.h>
SCCSID(scecon_h,
  "@(#)scecon.h	1.62 (SimCorp) 99/09/13 13:01:38")

/************************************************************************
*                                                                       *
*    project    SCecon                                                  *
*                                                                       *
*    filename   scecon.h                                                *
*                                                                       *
*    general    This file contains declarations, initializations,       *
*               type definitions and function prototyping for the       *
*               SCecon library                                          *
*                                                                       *
************************************************************************/

/*** includes *********************************************************/
#include <scechook.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>   /* For APL II - 386 */

/***** C++ Convenience *************************************************/
#ifdef __cplusplus
extern "C" {
#endif

/*** General SCecon documentation        ******************************/

/*,,SINTRO,,

SCecon - A Primer
-----------------

SCecon is a library of financial calculation routines. These routines span 
the range from simple calendar and discounting routines to complex term 
structure models.

To use SCecon it is crucial to understand that SCecon contains calculations 
only. No database or other file access is used in the routines of the library.
Similarly data are not expected to come from a GUI interface. Instead all data
must be entered in C structs, and the desired routine called directly. Upon this
action the result is returned. Therefore SCecon is a tool that can assist 
developers in building financial calculations - where any external data sources 
must be built elsewhere.

At the core of SCecon are data descriptions (containers) and calculation 
routines.

SCecon essentially consists of the following types of data containers:

    Convention enumerations
    Instrument containers
    Utility data containers

and these types of calculation routines:

    Instrument Pricers
    Model Calibrators
    Utilities


Convention enumerations
-----------------------

In SCecon the various market conventions have been parameterised as various
conventions - like

    CALCONV         describing daycount conventions
    RATECONV        describing floating index conventions
    OPTTYPE         option types
    KEYCONV         definition of what variable to shock (when doing greeks)
                    or what implied ratio to find.    

whenever new conventions are encountered the description in SCecon will be
in the form of an enumeration.

These conventions are then inputs to the routines that do the various 
calculations - like day count calculators and index rate calculations.


Instrument containers
---------------------

Financial instruments are described using containers (C structs) that hold
the data needed to define the various instruments. Examples include:

    CAP             describing interest rate options like caps, floors and
                    IRG's.
    BONDBM          describing standardised Benchmark Bonds.
    
Some instrument data are described in sub-containers like:

    FIXRATE         definition of how to calculate fixed rate payments
    PAYOFFINF       definition of payoff for digital options

these containers appear as components in the security containers.

In all instrument calculators these containers are used to describe the
particular instrument being priced.


Utility data containers
-----------------------

Various other types of data containers not included in the first 2 categories
include

    DATESTR         holds a single date
    PERIOD          holds the definition of a relative period
    FL64            is just an 8 byte floating number
    PLAN_STR        list of combined {date, floating number} as used
                    in discount factors, irregular redemptions, volatility
                    structures.

Similarly other 'utility' like data containers are defined.


Instrument Pricers
------------------

Instrument pricers are routines that takes an instrument definition and a 
financial model and calculates a key ratio. All instrument pricers have a 
standardised name - according to the following convention:

    <Security>_<Model>2<KeyRatio>()

examples are:

    Bond_YTM2Price()    Calculate Price for a Bond using Yield To Maturity
    Cap_Black2P()       Calculate Premium for Cap using Black 76


The following models are currently available in SCecon:

    YTM     Yield to maturity (or internal rate of return - IRR)
    
    DM      Discounted Margin for FRN's

    SM      Simple margin for FRN's
    
    DF      Zero Rate Discount Factors (for virtually all instruments) or
            Interest Rate Parity (for FX Forwards).
            Used for discounting and floating payment cashflow generation.
            Includes convexity adjustment for CM floaters.
    
    CC,
    CCREPO  Cost of Carry for forwards / futures
    
    BLACK   Variations of Black-Scholes, Black76 and Rubinstein exotic
            options models.
            Includes convexity adjustment for CM floaters.
    
    CRR     Cox, Ross & Rubinstein binomial trees for equity, commodity and
            FX options

    HW,
    HWTREE,
    BDT     General 1-factor term structure models for option valuation.
            Incl. Black & Karasinski, Extended Vasicek, Extended CIR, 
            BDT, Ho/Lee, Hull & White etc.
    
    HWCF    Hull & White model with closed form solutions for European style
            options.
            This includes closed-form quanto-adjustment for quanto swap
            adjustment.
            
    BGM     Brace-Gatarek-Musiela multi-factor termstructure model for
            option valuation.
  
    VAR     Value-at-Risk calculation for portfolios (using the standardised
            matrix VAR approach - a la RiskMetrics).

Of course some models are only relevant for certain instruments (like CC not
being relevant for swaptions, and BLACK being relevant). This is reflected in
the pricing routines being available (i.e. {model, security} pairs).

For a list of instruments please browse in the function list.

Key ratios can be grouped into various categories:

    Price Related (for the model specified)
    ---------------------------------------
    PV
    Price 
    Clean Price
    Accrued Interest
    Dirty Price
    Option Premium 

    Yield Related
    -------------
    Simple margin
    Discounted Margin
    YTM - Yield to maturities
    Horizon Yields

    Greeks (for the model specified)
    --------------------------------
    $Duration (YTM)
    $Convexity (YTM)
    Modified $Duration (YTM)
    Modified $Convexity (YTM)
    Duration 
    PV01 
    YV01 
    $Duration (DF)
    $Convexity (DF)
    Modified $Duration (DF)
    Modified $Convexity (DF)
    BPV
    Delta Vector
    Risk Positions (for VAR calculations)
    Scenario BPV's
    Delta
    Gamma
    Theta
    Vega
    Rho
    Vega2 (as defined by Hull & White)
    Vega1 (as defined by Hull & White)
  
    Implied (for the model specified)
    ---------------------------------
    Repo Rate
    Spot 
    Swaprate 
    FRA rate
    Floating Spread
    Vol
    Strike (e.g. Caprate)
    Dividend Yield
    Gap (for contingent premium options)


Model Calibrators
-----------------

By model calibrators we understand routines that take a list of instruments
and their market prices and calculate (calibrate) the model data to this 
info.

Examples include 

    Boot_Caplets2HWCF()     Calibrate Hull & White model parameters from 
                            a list of Caplets
    Fit_BSEC2DF()           Calibrate a DF (Discount Factor) curve from
                            a list of BSEC's (i.e. a list of par instruments,
                            bonds etc)

Basically we apply two methods for finding model parameters - fitting and boot-
strapping. 

By fitting we mean finding parameters such that the model based prices are 
as close as possible to market prices.

By bootstrapping we mean that the model prices will per definition be exactly
equal to the market prices.

So the naming convention for these types of routines is:

    <Fit/Boot>_<Securities>2<Model>()

  
A special category of model calibration is margin adjustment for interest
rate futures. We have implemented variations of this adjustment - these 
routines are defined as:

    Boot_<AdjustmentMethod>2MargAdj()


When pricing using trees the underlying stochastic process must be mapped into
a lattice structure. SCecon supports general 1-factor models of the term 
structure of interest rates and the standard geometric brownian motion based 
models for equities, commodities and FX. The lattice generating routines are:


    Clb_<Model>2Tree()

where model is HW, BDT or CRR.


Utility Routines
----------------

Another category of SCecon routines is utility routines. The following 
financial type utility routines are included:
  
    Calendar routines           found as Cldr_*()
    Discount Factor routines    found as Disc_*()
    Validation routines         found as Validate_*()

Some more technical utility routines are:

    Dynamic memory allocation   found as Alloc_*()
    Dynamic memory deallocation found as Free_*()
    Struct member setting       found as Set_*()
    Hook routines               found as SCecon_*()

    
Test Standards
--------------

SCecon routines are continuously being tested using regression tests. Whenever
new routines are developed a suite of test examples are compiled and
each routine tested against this suite. In order to check the calculations
the expected results are also found and stored. 

Whenever possible the expected results are compiled from published references. 
Otherwise the benchmark examples are generated through careful model valuation.

Upon completion of developing a new routine the test examples are stored in the
total test repository, and will in all future be available for testing - in 
particular to evaluate whether new developments have impacted previous 
functional capabilities. Currently this total test repository amounts to 
several MBytes.


Consistency Checks
------------------

Whenever new versions are released a number of standard consistency checks are
performed:

    1. Checks for memeory leaks (using test suite runs)
    2. DOC consistency - i.e interface definition control
    3. All versions are stored in a repository
    4. Plus some less significant checks (like max line size).


Portability
-----------
SCecon can run on several platforms. Routinely SCecon has been ported to NT, 
DOS, Windows 3.1x, OS/2 and a wide range of Unix/Ultrix boxes - and many more.
Furthermore, SCEcon is also available for APL, Microsoft Visual Basic and
Microsoft Visual Basic for Applications.

Recommended Readings
--------------------

For general introductions to the financial theory underlying the calculations
in SCecon we recommend to:

J. Hull
Options, Futures, and other Derivative Securities
Prentice-Hall, 1997

R. Jarrow & S. Turnbull
Derivative Securities
South Western Publishing Co, 1996

D. Duffie
Dynamic Asset Pricing Theory
Princeton University Press, 1996

For more elaborate discussions of the details of exotic options, tree building,
volatility estimation, optimisation, discounting methods etc we refer to
the special literature. A couple of relevant examples are:

M. Rubinstein
Breaking down the barriers
Risk Magazine, Sep. 1991

J. Hull & A. White
One-factor interest rate models and the valuation of interest-rate derivative 
securities
J. of Financial and Quantitative Analysis, Vol. 28, June 1993, pp. 235-254

,,EINTRO,,*/


/*,,SABBR,,

YTM: Yield to Maturity
----------------------

The classical approach to (fixed) cashflow valuation is the so-called 
internal rate of return (IRR) more often referred to as Yield to Maturity
(YTM). 

The idea in YTM valuation is quite simple. All future cashflows are 
discounted till the valuation date by simply using the SAME discounting
yield for all payments. Therefore the present value (PV)  of these future 
payments  is:

        PV = Sum( C(i) * d(i), i)

        C(i) are the payments

        d(i) = 1 / (1 + y)^( t(i) )

        y is the IRR / YTM

        t(i) is the time till the i'th payment

This is illustrated in the following valuation of a cashflow (bullet bond)

        i   t(i)    C(i)    y       d(i)    pv(i)
        ------------------------------------------
        1   0.5     5.0    7.0   0.9667365   4.834
        2   1.0     5.0    7.0   0.9345794   4.673
        3   1.5   105.0    7.0   0.903492   94.867
        ------------------------------------------
                                           104.374

When invoking this simple formula a few details must be remembered

        In various markets various methods for calculating the time till
        the payments t(i) are used. In particular various day fraction
        conventions are used. In SCecon the datatype CALCONV is used
        to describe these conventions.

        Also various methods are used for transforming a yield y into
        a discounting factor d(i). Annually compounded or semiannually
        compounded yields or money market yields are used. In SCecon
        the type IRRCONV is used to parameterise these conventions.

        Finally note that different conventions may be used for 
        discounting in first / middle and last periods (as seen from 
        today). This is parameterised in the datatype YTMCONV. For details
        on specific market see the SCecon type YTMSEG.

        The cashflow C(i) must be known. In SCecon a number of routines 
        are available to generate a relevant cashflow for various fixed
        cashflow type of instruments (e.g. bonds, deposits, fixed swap 
        legs - see the routines *_GenrCflw() ).
  
For a given YTM it is fairly straightforward to calculate the PV. Often
however, it is more interesting to calculate the yield given a price for
a cashflow (e.g as arising from a bond investment). This implied yield
can be found by iterating on the basic equation for sequential guesses
on the yield y. In SCecon a Newton-Raphson iteration method is used.

Another relevant task is to calculate sensitivities of the PV to changes
in the yield. In SCecon the following sensitivities (Risk Ratios) are
available:

        $Duration            First order sensitivity of PV wrt the YTM.
                             This expresses the effect a change in YTM 
                             has on the PV
        Modified $Duration   $Duration divided by the PV
        $Convexity           Second order sensitivity of PV wrt YTM.
                             This expresses the inaccuracy of the $Duration
                             when  measuring th effect of a chnage in the YTM
        Modified $Convexity  $Convexity divided by the PV
        Duration             The PV weighted time till maturity (i.e. the
                             standard Macauley Duration)
        PV01                 Average change in the PV when the yield changes
                             a basis point
        YV01                 Average change in the yield when the PV changes
                             a basis point.
        WAL                  Weighted average life
        LIFE                 Simple life (term till maturity)

These risk numbers can be found by invoking the security pricing routines with
a risk toggle set (see the SCecon data type RISKSET). The YTM based security 
pricing routines are named

        <sec>_YTM2<key>()

Note that the first and second order derivatives are calculated as a spin-off
from the PV calculation (for speed purposes).

The (SCecon) securities for which a YTM based approach to valuation is 
implemented are:

        Bond                         Function Bond_YTM2Yield()
        Bond (Benchmark)             Function BondBM_YTM2Yield()
        Bond (Portfolio)             Function BondPF_YTM2Yield()
        Cashflows                    Function Cflw_YTM2Yield()
        Repo on Bond                 Function RepoBond_YTM2Price()
        Repo on Cashflow             Function RepoCflw_YTM2Price()
        Future/Forward on Bond       Function FutBond_YTM2Yield()
        Index-linked Bond            Function IndexBond_YTM2Yield()
        Index-linked Loan            Function IndexLoan_YTM2Yield()

Sometimes 'yield curves' are used for valuation purposes. This is a list of 
yields per duration or time to maturity. With such a list one can find the yield
to use for a cashflow (bond) by interpolating in the list (yield curve) with the
duration or time to maturity of the cashflow. When using such a yield one should
remember that the yield curve was probably generated from liquid bonds, whereas 
the bond being valued may be less liquid - and therefore should be valued using
a higher yield than the more liquid bonds. It is therefore advisable to add some
(subjectively adjusted) spread to such a yield to adjust for liquidity and 
credit effects.


DF: Zero Rate Discount Factors
------------------------------

The general approach to valuation of fixed and floating coupon
cashflows and cashflow based derivatives such as Repos and Swaps is 
the so-called Discount Factor (DF) method.
For FX Forwards the method is identical to the Interest Rate Parity.

The idea in DF valuation is quite simple. All future cashflows are 
discounted till the valuation date by using DIFFERENT (as opposed to 
the fixed yield used in the YTM method) discounting yield for all payments. 
To each discount factor corresponds a zero-coupon yield - the yield of
a zero-coupon bond maturing on the date of the discount factor.
For floating rate instruments, the future payments are unknown. To value
such instruments, this method replaces the unknown future payments by
the forward values, which may be derived from a term structure of zero rates.

The present value (PV) of the known future payments using this approach 
is then:

        PV = Sum( C(i) * d(i), i)

        C(i) are the payments

        d(i) = 1 / (1 + y(i) )^( t(i) )

        y(i) is the zero coupon rate for the i'th payment date.

        t(i) is the time till the i'th payment

This is illustrated in the following valuation of a cashflow (bullet bond)

        i   t(i)    C(i)   y(i)     d(i)    pv(i)
        ------------------------------------------
        1   0.5     5.0    6.8   0.967641   4.8382
        2   1.0     5.0    7.0   0.934579   4.6729
        3   1.5   105.0    7.15  0.901596  94.6675
        ------------------------------------------
                                          104.1786

The present value (PV) of the unknown future payments using this approach 
is then:

        PV = Sum( C(i) * d(i), i)

        C(i) are the payments which split into coupon and redemption:
             C(i) = c(i) + r(i)

        r(i) is the repayment on the i'th payment date

        c(i) is the interest payment on the i'th payment date.
             For simple floaters this is computed as:
             c(i) = d(i - 1) / d(i) - 1

        d(i) = 1 / (1 + y(i) )^( t(i) )

        y(i) is the zero coupon rate for the i'th payment date.

        t(i) is the time till the i'th payment

This is illustrated in the following valuation of a vanilla floating swap-leg

        i   t(i)    C(i)   y(i)     d(i)    pv(i)
        ------------------------------------------
        1   0.5     3.34   6.8   0.967641   3.2359
        2   1.0     3.54   7.0   0.934579   3.3062
        3   1.5   103.66   7.15  0.901596  93.4579
        ------------------------------------------
                                           100.000

The computation of the c(i)'s may be more or less complicated. In this
example the c(i) were defined by the 6 months deposit rate, which caused
the instrument to have unit value, and the values for c(i) are computed by 
Disc_DF2ForwRate(). In other cases such as CMS/CMT structures the c(i) 
is computed as the Par-Swap rate (CMS) or Par-Bond yield (CMT) requiring 
computations like SwapFix_DF2CFRate(). These structures also require
a convexity adjustment, since the forward value and the expected value
no longer coincide. This convexity adjustment is controlled by the 
CMCONVADJ type.

The zero-coupon rates are not directly observable, but can be
calibrated to given market prices of bonds or money/swap market instruments.
This can be done using the SCEcon functions Fit_BSEC2DF() and Boot_BSEC2DF().

When calculating PV by the simple formula above, a few details must be 
remembered

        In various markets various methods for calculating the time till
        the payments t(i) are used. In particular various day fraction
        conventions are used. In SCEcon the datatype CALCONV is used
        to describe these conventions.

        Discount factors (and hence zero rates) may not be available for
        exactly the terms t(i). To obtain discount factors (or zero rates)
        some interpolation scheme is necessary. Discount factors are
        represented using the DISCFAC types which is also used for the
        definition of interpolation schemes. 
        Also various methods are used for transforming a yield y into
        a discounting factor d(i). Annually compounded or semiannually
        compounded yields or money market yields are used. In SCEcon
        the type IRRCONV is used to parameterise these conventions.

        The floating rate cashflows can be defined in various ways:
         - Fixing according to a Money-Market Deposit
         - Fixing according to a Par-Swap
         - Fixing according to a Bond Par-Yield
         - Fixing according to an Equity Index
         - Fixing according to a Commodity Index
  
For a given set of discount factors it is fairly straightforward to 
calculate the PV. 
Another relevant task is to calculate sensitivities of the PV to changes
in the yield. In SCEcon the following sensitivities (Risk Ratios) are
available:

        $Duration            First order sensitivity of PV wrt the zero-coupon
                             rates. This expresses the effect a parallel shift
                             of the zero rates has on the PV.
        $Convexity           Second order sensitivity of PV wrt the zero rates.
                             This expresses the inaccuracy of the $Duration
                             when measuring the effect of a parallel shift of
                             the zero rates.
        BPV                  The Basis Point Value of a parallel shift of the
                             zero rates.
        Risk Positions       Risk positions to be used in the computation of
                             matrix-VaR.
        Delta Vector         First order sensitivity of PV wrt the zero-coupon
                             rates. This expresses the effect a local shift of a
                             particular zero rate has on the PV. 
        Duration             Fisher-Weil duration.
                             (available only for bonds).
        Zero-Curve Spread    The spread against a given set of zero-coupon 
                             rates. This expresses the cheapness/expensiveness
                             compared to a set of zero-coupon rates. 
                             (Available for cashflows and bonds only).
        Horizon Yield (HZY)  The net yield of a temporal bond or cashflow 
                             position. This expresses the 'yield-to-horizon'
                             obtained by buying a bond today and re-selling 
                             it on a certain future date.
                             (Available for cashflows and bonds only).

These risk numbers can be found by invoking the security pricing routines with
a risk toggle set (see the SCEcon data type RISKSET). The DF based security 
pricing routines are named

        <sec>_DF2<key>()

Note that the first and second order derivatives are calculated as a spin-off
from the PV calculation (for speed purposes).

The (SCEcon) securities for which a DF based approach to valuation is 
implemented are:

        Bond                         Function Bond_DF2Price()
        Bond (Portfolio)             Function BondPF_DF2Hzy()
        Cashflows                    Function Cflw_DF2Price()
        Deposits                     Function Deposit_DF2Price()
        Forward Rate Agreement (FRA) Function FRA_DF2NPV()
        Interest Rate Future (IRF)   Function IRF_DF2NPV()
        Repo on Bond                 Function RepoBond_DF2Price()
        Repo on Cashflow             Function RepoCflw_DF2Price()
        Future/Forward on Bond       Function FutBond_DF2Price()
        Floating Rate Note           Function FRN_DF2Price()
        Forward Foreign Exchange     Function FutFX_DF2NPV()
        Foreign Exchange Future      Function FutFX_DF2NPV()
        Index-Linked Bond            Function IndexBond_DF2Price()
        Index-Linked Loan            Function IndexLoan_DF2Price()
        Commodity-linked Floater     Function SwapCmdty_DF2NPV()
        Equity-linked Floater        Function SwapEqty_DF2NPV()
        Fixed Swap-leg               Function SwapFix_DF2NPV()
        Floating Swap-leg            Function SwapFl_DF2NPV()

Whenever the DF based approach is used, a zero-coupon term structure (ie,
a set of discount factors) is required. This term structure is normally derived
from very liquid instruments, whereas the instrument being valued may be 
less liquid - and therefore should be valued using higher zero rates than 
the more liquid instruments. It is therefore advisable to add some
(subjectively adjusted) spread to such a yield to adjust for liquidity and 
credit effects.



DM: Discounted Margin
---------------------

A simplified approach to valuation of floating rate notes (FRN).

The idea in DM valuation is a simplification of the more general
DF approach. The floating rate note is valued using an assumed
(constant) Libor rate. For the first payment the Libor rate
may be known, in which case this known value is used in the
valuation. The interest payments of the note are constructed
using the known and assumed Libor rates as well as a spread
added to these. The payments are discounted using simple
discounting in each period and using the known/assumed Libor
rates to which a specified 'discounted margin' is added.
The approach follows the recommended formula in "Floating
Rate Notes - Methods of Analysis" by Richard Williams, CSFB.
This approach is valid only for vanilla FRN's.

The present value (PV) of the known future payments using this approach 
is then:

        PV = Sum( C(i) * d(i), i)

        C(i) are the payments

        d(i) = 1 / (1 + y(i) )^( t(i) )

        Libor(i) is the assumed/known Libor rate.

        y(i) is the zero coupon rate for the i'th payment date.

        t(i) is the time till the i'th payment

Valuation Example:


        i   t(i)    C(i)  Libor(i)    y(i)       d(i)    pv(i)
        ------------------------------------------------------
        1   0.5     4.90     8.80     9.51   0.955933   4.6841
        2   1.0     5.86    10.72    10.52   0.904814   5.3022
        3   1.5   105.86    10.72    10.86   0.856718  90.6922
        ------------------------------------------------------
                                                      100.6785

In this example the first Libor rate is known to be 8.80 and the 
assumed Libor rates are 10.72. The payments C(i) are generated 
from the Libor rates by adding a spread of 1.0. The 'discounted
margin' is in this example set to 0.5. Since the 'discounted  
margin' is lower than the spread used for generating the payments,
the present value is over par. 

When invoking this simple method a few details must be remembered

        In various markets various methods for calculating the time till
        the payments t(i) are used. In particular various day fraction
        conventions are used. In SCEcon the datatype CALCONV is used
        to describe these conventions.

For a given discounted margin it is fairly straightforward to 
calculate the Price. Another relevant task is to calculate 
the implied discounted margin for a specified Price
DM is a specialised approach for vanilla FRN's and is accordingly only
implemented for this security. The available functions are:

       FRN_DM2Price()
       FRN_DM2DiscMrgn()



SM: Simple Margin
-----------------

Simple Margin is also a quite simple approach to valuation of 
floating rate notes (even compared to DM) in that it provides
a simple pricing formula.

The approach follows the recommended formula in "Floating
Rate Notes - Methods of Analysis" by Richard Williams, CSFB.
This approach is valid only for vanilla FRN's.


    P = 100 + (Lnext + spr) * t1 - (L1 + spr) * t0 - (sm - spr) * tN


    L1     is the current Libor rate (prevailing for the next 
           interest payment).

    Lnext  is the assumed Libor rate (prevailing for payments
           after the next interest payment).

    spr    is the quoted margin (or spread over Libor)

    sm     is a specified 'simple margin'

    t0     is the time between the previous and the next interest payment.

    t1     is the time from today till the next interest payment.

    tN     is the time from today till the final interest payment.


Valuation Example:

    L1     =  8.80

    Lnext  = 10.72
 
    spr    =  1.00

    sm     =  0.50

    t0     =  0.50

    t1     =  0.50

    tN     =  1.50

This yields a price, P, of 101.71.


When invoking this simple formula a few details must be remembered

        In various markets various methods for calculating the time till
        the payments t(i) are used. In particular various day fraction
        conventions are used. In SCEcon the datatype CALCONV is used
        to describe these conventions.

For a given simple margin it is fairly straightforward to 
calculate the Price. Another relevant task is to calculate 
the implied simple margin for a specified Price
DM is a specialised approach for vanilla FRN's and is accordingly only
implemented for this security. The available functions are:

       FRN_SM2Price()
       FRN_SM2SmplMrgn()



CC, CCREPO:  Cost of Carry
--------------------------

The general approach to valuation of futures on known cashflows 

The idea in CC/CCREPO valuation is quite simple. The futures price
is computed from the spot price of the instrument underlying the future
and from the cashflow obtained by carrying the underlying from today
till futures delivery. This intermediate cashflow is discounted
using zero-coupon rates (as in th DF method), the price of which is
subtracted from the spot price which in turn discounted inversely
to yield the futures price.

The price of a future using this approach is then:

        Price = (Spot - Carry) / d(n)
        
        Spot is the price of the underlying if traded spot today.

        Carry = Sum( C(i) * d(i), i)

        C(i) are the payments occuring between today and futures delivery
             possibly including amortisations and accrued interest on
             both today's date and of the futures delivery date.

        d(i) = 1 / (1 + y(i) )^( t(i) )

        d(n) = 1 / (1 + y(n) )^( t(n) )

        y(i) is the zero coupon rate for the i'th payment date.

        y(n) is the zero coupon rate for the futures delivery date.

        t(i) is the time till the i'th payment

        t(n) is the time till the futures delivery payment

This is illustrated in the following valuation of a future
on a bullet bond. The bond matures in 3.5 years and has annual payments.
The future delivers in one year.

        Bond spot price 96.01

        i   t(i)    C(i)  y(i)       d(i)    pv(i)
        ------------------------------------------
        0   0.0    -2.5    0.0   1.000000  -2.5000
        1   0.5     5.0    6.8   0.967641   4.8382
        2   1.0     2.5    7.0   0.934579   2.3364
        ------------------------------------------
                                            7.1747

        Futures price: 95.05

The zero-coupon rates are not directly observables, but can be
calibrated to given market prices of bonds or money/swap market instruments.
This can be done using the SCEcon functions Fit_BSEC2DF() and Boot_BSEC2DF().

When invoking this simple formula a few details must be remembered

        In various markets various methods for calculating the time till
        the payments t(i) are used. In particular various day fraction
        conventions are used. In SCEcon the datatype CALCONV is used
        to describe these conventions.

        Discount factors (and hence zero rates) may not be available for
        exactly the terms t(i). To obtain discount factors (or zero rates)
        some interpolation scheme is necessary. Discount factors are
        represented using the DISCFAC types which is also used for 
        definition interpolation schemes. 
        Also various methods are used for transforming a yield y into
        a discounting factor d(i). Annually compounded or semiannually
        compounded yields or money market yields are used. In SCEcon
        the type IRRCONV is used to parameterise these conventions.

For a given set of discount factors it is fairly straightforward to 
calculate the PV. 
Another relevant task is to calculate sensitivities of the PV to changes
in the yield. In SCEcon the following sensitivities (Risk Ratios) are
available:

        $Duration            First order sensitivity of PV wrt the zero-coupon
                             rates. This expresses the effect a parallel shift
                             of the zero rates has on the PV.
        $Convexity           Second order sensitivity of PV wrt the zero rates.
                             This expresses the inaccuracy of the $Duration
                             when measuring the effect of a parallel shift of
                             the zero rates.
        BPV                  The Basis Point Value of a parallel shift of the
                             zero rates.
        Risk Positions       Risk positions to be used in the computation of
                             matrix-VaR.
        Delta Vector         First order sensitivity of PV wrt the zero-coupon
                             rates. This expresses the effect a local shift of
                             particular zero rate has on the PV. 

These risk numbers can be found by invoking the security pricing routines with
a risk toggle set (see the SCEcon data type RISKSET). The DF based security 
pricing routines are named

        <sec>_CC2<key>() or <sec>_CCREPO2<key>()

Note that the first and second order derivatives are calculated as a spin-off
from the PV calculation (for speed purposes).

The (SCEcon) securities for which a DF based approach to valuation is 
implemented are:

        Repo on Bond                       Function RepoBond_CC2NPV()
        Future/Forward on Bond             Function FutBond_CC2Price()
        Future/Forward on Bond (Benchmark) Function FutBondBM_CCREPO2Price()
        Future/Forward on Equity           Function FutEqty_CC2Price()
        Future/Forward on Commodity        Function FutCmdty_CC2Price()

Whenever the CC/CCREPO based approach is used, a zero-coupon term structure (ie,
a set of discount factors) (or just a single repo rate in CCREPO case)
is required. This term structure is normally derived
from very liquid instruments, whereas the instrument being valued may be 
less liquid - and therefore should be valued using higher zero rates than 
the more liquid instruments. It is therefore advisable to add some
(subjectively adjusted) spread to such a yield to adjust for liquidity and 
credit effects.



BLACK: Black-Scholes, Black76, Garman-Kohlhagen and extensions
--------------------------------------------------------------

A generalised framework for valuation of options on interest rate,
equity, commodity and foreign exchange is provided by the 
Black-Scholes model.
Stated in terms of an equity, the model reads:

  dS = r * S * dt  +  v * S * dZ

  r  is the (constant) 'risk-free' rate of interest

  S  is the current equity price
  
  v  is the (constant) volatility of the equity price

  dt is an infinitesimal time increment

  dZ is a normally distributed shock

Within this framework european options are priced using a simple
pricing formula: An european call option with strike in time t at a 
rate of X has by Black-Scholes the value given by the formula:

  C  =  S * N( d1 )  -  X * exp(-r * t) * N( d2)

  d1 = (ln( S / X ) + r * t + v * v / 2 ) / ( v * sqrt( t ) )

  d2 = d1 - v * sqrt( t )

Valuation Example:

    r      =  0.10

    S      = 96.00
 
    X      = 95.00

    v      =  0.20

    t      =  1.00


This yields d1 = 0.652356, d2 = 0.452356 and C = 13.34059.

Extensions to the Black-Scholes and Black-76 formulae exist for
a range of exotic options (defined in OPTFUT, CAP, and SWAPTION)

When invoking this simple Black-Scholes formula a few details must be 
remembered

        In various markets various methods for calculating the time till
        option strike t are used. In particular various day fraction
        conventions are used. In SCecon the datatype CALCONV is used
        to describe these conventions.

        Also various methods are used for constructing the risk-free
        rate r from zero-coupon rates or discount factors. The risk-free 
        rate is often a money market yield. In SCecon the type IRRCONV 
        is used to parameterise these conventions.

For a given option it is straightforward to calculate the Premium. Often
however, it is more interesting to calculate the volatility given an
option premium. This implied volatility can be found by iterating on 
the basic equtaion for sequential guesses on the volatility v. In SCecon 
a Newton-Raphson iteration method is used.

Another relevant task is to calculate sensitivities (greeks) of the Premium 
to changes in the parameters. In SCecon the following Greeks are
available:

        $Duration            First order sensitivity of Premium wrt the 
                             term structure of interest rates or just r.
                             This expresses the effect a change in interest  
                             rates has on the Premium
        $Convexity           Second order sensitivity of Premium wrt the 
                             term structure of interest rates or just r
                             This expresses the inaccuracy of the $Duration
                             when  measuring the effect of a change in the 
                             interest rates
        BPV                  The Basis Point Value of a parallel shift of the
                             zero rates.
        Risk Positions       Risk positions to be used in the computation of
                             matrix-VaR.
        Delta Vector         First order sensitivity of Premium wrt the 
                             zero-coupon rates. This expresses the effect a 
                             local shift of particular zero rate has on the 
                             Premium. 
        Delta                First order sensitivity of Premium wrt the
                             underlying variable, eg. S. This expresses the
                             effect a change in S has on the Premium
        Gamma                Second order sensitivity of Premium wrt the
                             underlying variable, eg. S. This expresses the
                             inaccuracy of the Delta when measuring the 
                             effect of a change in S.
        Vega                 First order sensitivity of Premium wrt the
                             volatility. This expresses the effect a change 
                             in the volatility has on the Premium.
        Theta                First order sensitivity of Premium wrt the
                             time till option strike. This expresses the 
                             change in option premium as time passes.
        Rho                  First order sensitivity of Premium wrt the 
                             risk-free rate (not the entire term structure).
                             This expresses the effect a change in the 
                             risk-free rate has on the Premium

In addition the sensitivity of the Premium wrt the strike rate can also
be computed. Furthermore, second order sensitivities are available wrt the 
volatility and wrt the risk-free rate.

These risk numbers can be found by invoking the security pricing routines with
a risk toggle set (see the SCecon data type RISKSET). The BLACK based security 
pricing routines are named

        <sec>_Black2<key>()

Note that the first and second order derivatives are calculated as a spin-off
from the Premium calculation (for speed purposes).

The (SCecon) securities for which a BLACK based approach to valuation is 
implemented are:

        Bond Options                 Function OptBond_Black2P()
        Commodity Options            Function OptCmdty_Black2P()
        Equity Options               Function OptEqty_Black2P()
        Equity Options (with Quanto) Function OptEqtyCT_Black2P()
        Bond Futures Options         Function OptFutBond_Black2P()
        Commodity Futures Options    Function OptFutCmdty_Black2P()
        Equity Futures Options       Function OptFutEqty_Black2P()
        Foreign Exc. Futures Options Function OptFutFX_Black2P()
        Foreign Exchange Options     Function OptFX_Black2P()
        Caps/Floors                  Function Cap_Black2P()
        Swaptions                    Function Swaption_Black2P()



CRR: Cox, Ross & Rubinstein Binomial Model
------------------------------------------

Options with american exercise feature cannot be priced using the
pricing formula for european options. Cox, Ross & Rubinstein
provided a general discrete binomial model that allows easy 
valution of american options. Using the same basic model
as in BLACK, a discrete version of the model is used for
valuation.

             { u * S(i-1)   with probability  p
     S(i)  = {
             { d * S(i-1)   with probability  1 - p


     S(i)  is the equity price at the i'th time step.

     u     is the scale determining the upwards move

     d     is the scale determining the downwards move

     p     is the risk neutral probability of an upwards move.

     r     is the risk-free rate of interest

     v     is the volatility of S

     dt(i) is the time between the i'th time step and the (i-1)'th 
           time step.
     
     u, d, and p are determined so that the drift of S(i) becomes
     r and the volatility of S(i) becomes v. They can be determined
     uniquely by the following set of equations:

     (u + d) * p + d = r

     (u * u + d * d ) * p + d * d = v * v + r * r

     u * d = 1


     An american call-option on S with strike X is valued using the 
     following recursive equation:


     W(i) = V(i+1) * exp(-r * dt(i))

     V(i) = max ( S(i) - X, W(i) )

A valuation example can be found in "Options, Futures, and Other 
Derivatives" 3rd. ed. by Hull, J.C., pp. 350-351.

When invoking this simple Cox-Ross-Rubinstein method a few details must be 
remembered

        In various markets various methods for calculating the time till
        option strike t are used. In particular various day fraction
        conventions are used. In SCecon the datatype CALCONV is used
        to describe these conventions.

        Also various methods are used for constructing the risk-free
        rate r from zero-coupon rates or discount factors. The risk-free 
        rate is often a money market yield. In SCecon the type IRRCONV 
        is used to parameterise these conventions.

For a given option it is straightforward to calculate the Premium. Often
however, it is more interesting to calculate the volatility given an
option premium. This implied volatility can be found by iterating on 
the basic equtaion for sequential guesses on the volatility v. In SCecon 
a Newton-Raphson iteration method is used.

Another relevant task is to calculate sensitivities (greeks) of the Premium 
to changes in the parameters. In SCecon the following Greeks are
available:

        $Duration            First order sensitivity of Premium wrt the 
                             term structure of interest rates or just r.
                             This expresses the effect a change in interest  
                             rates has on the Premium
        $Convexity           Second order sensitivity of Premium wrt the 
                             term structure of interest rates or just r
                             This expresses the inaccuracy of the $Duration
                             when  measuring the effect of a change in the 
                             interest rates
        BPV                  The Basis Point Value of a parallel shift of the
                             zero rates.
        Risk Positions       Risk positions to be used in the computation of
                             matrix-VaR.
        Delta Vector         First order sensitivity of Premium wrt the 
                             zero-coupon rates. This expresses the effect a 
                             local shift of particular zero rate has on the 
                             Premium. 
        Delta                First order sensitivity of Premium wrt the
                             underlying variable, eg. S. This expresses the
                             effect a change in S has on the Premium
        Gamma                Second order sensitivity of Premium wrt the
                             underlying variable, eg. S. This expresses the
                             inaccuracy of the Dekta when measuring the 
                             effect of a change in S.
        Vega                 First order sensitivity of Premium wrt the
                             volatility. This expresses the effect a change 
                             in the volatility has on the Premium
        Theta                First order sensitivity of Premium wrt the
                             time till option strike. This expresses the 
                             change in option premium as time pass.
        Rho                  First order sensitivity of Premium wrt the 
                             risk-free rate (not the entire term structure).
                             This expresses the effect a change in the 
                             risk-free rate has on the Premium
        Zeta                 First order sensitivity of Premium wrt the
                             size of the exercise period. This expresses the
                             change in option premium as the first-strike 
                             date changes.

In addition the sensitivity of the Premium wrt the strike rate can also
be computed. Furthermore, second order sensitivities are available wrt the 
volatility and wrt the risk-free rate.

These risk numbers can be found by invoking the security pricing routines with
a risk toggle set (see the SCecon data type RISKSET). The CRR based security 
pricing routines are named

        <sec>_CRR2<key>()

Note that the first and second order derivatives are calculated as a spin-off
from the Premium calculation (for speed purposes).

The (SCecon) securities for which a CRR based approach to valuation is 
implemented are:

        Commodity Options            Function OptCmdty_CRR2P()
        Equity Options               Function OptEqty_CRR2P()
        Foreign Exchange Options     Function OptFX_CRR2P()
        Convertible Bond             Function Convtbl_CRR2Price()


HW, HWTREE, BDT: General 1-factor Term Structure Models for Option Valuation
----------------------------------------------------------------------------

Term structure derivatives, such as bermudan swaptions, may not depend
on a single rate, eg. the 5 year par swap rate. An approach is to model
the 'short-rate' (the instantaneous continuously compounded rate) and
derive the term structure from the dynamics of the short-rate.
The HW framework supports a long list of models on the short-rate, eg:
Black-Derman-Toy, Hull-White, and Black-Karasinski.

In general the short-rate proces can be defined as:

        d(f(r))  = drift(r) + vol(r)

        drift(r) = ( theta + phi * g(r) ) * dt

        vol(r)   = sigma * r ^ beta * dZ

        r          is the short-rate
        
        theta      is a steady-state level
        
        phi        is a mean-reversion factor

        g(r), f(r) are functions of the short-rate, defining the type 
                   of process.

        beta       is the elasticity of the volatility wrt the short-rate

        dt         is a infinitesimal time-increment

        dZ         is a normally distributed shock

        sigma      is the volatility level of the short-rate


The SCEcon datatype HWPARMS contains these model parameters.

For pricing purposes a HW model is discretised by a trinomial lattice
(binomial for the Black-Derman-Toy model). A description of how to 
build the lattice can be found in "Options, Futures, and Other Derivatives",
by Hull pp. 438ff.
The pricing of instruments using this lattice is a matter of 
finding the state-contingent cashflows and discounting backwards 
through the tree.

theta is determined from the zero coupon rates while the corresponding 
volatilities are used for determining phi (in case phi is not simply a  
given constant). The volatility level, sigma, can be specified independently 
(e.g. as the current short rate volatility). When using the BDT model, however, 
sigma is determined uniquely by theta and phi.

The zero-coupon rates are not directly observables, but can be
calibrated to given market prices of bonds or money/swap market instruments.
This can be done using the SCEcon functions Fit_BSEC2DF() and Boot_BSEC2DF().

The zero-rate volatilities are also not directly observables, but can be
calibrated to given market prices of vanilla caps/floors or vanilla swaptions.
This can be done using the SCEcon functions Fit_Cap2HWVol() and 
Fit_Swaption2HWVol().

When invoking this HW method a few details must be remembered

        In various markets various methods for calculating the time till
        option strike t are used. In particular various day fraction
        conventions are used. In SCecon the datatype CALCONV is used
        to describe these conventions.

        Also various methods are used for constructing the risk-free
        rate r from zero-coupon rates or discount factors. The risk-free 
        rate is often a money market yield. In SCecon the type IRRCONV 
        is used to parameterise these conventions.

For a given option it is straightforward to calculate the Premium. Often
however, it is more interesting to calculate the volatility given an
option premium. This implied volatility can be found by iterating on 
the basic equtaion for sequential guesses on the volatility v. In SCecon 
a Newton-Raphson iteration method is used.

Another relevant task is to calculate sensitivities (greeks) of the Premium 
to changes in the parameters. In SCecon the following Greeks are
available:

        $Duration            First order sensitivity of Premium wrt the 
                             term structure of interest rates or just r.
                             This expresses the effect a change in interest  
                             rates has on the Premium
        BPV                  The Basis Point Value of a parallel shift of the
                             zero rates.
        Vega                 First order sensitivity of Premium wrt the
                             zero-rate volatilities. This expresses the 
                             effect a change in the zero-rate volatilities 
                             has on the Premium.
        Vega1                First order sensitivity of Premium wrt the
                             short-rate volatility. 
                             This expresses the effect a change 
                             in the short-rate volatility has on the Premium
        Vega2                First order sensitivity of Premium wrt the
                             mean-reversion level. This expresses the effect
                             a change in the mean-reversion level has on the 
                             Premium
        Theta                First order sensitivity of Premium wrt the
                             time till option strike. This expresses the 
                             change in option premium as time passe.


These risk numbers can be found by invoking the security pricing routines with
a risk toggle set (see the SCecon data type RISKSET). The HW based security 
pricing routines are named

        <sec>_HW2<key>() or <sec>_BDT2<key>()

Note that the first order derivatives are calculated as a spin-off
from the Premium calculation (for speed purposes).

The (SCecon) securities for which a HW based approach to valuation is 
implemented are:

        Bond                          Function Bond_HW2Price()
        Cap/Floor                     Function Cap_HW2P()
        Danish Mortgage Backed Bonds  Function DKmbs_BDT2Price()
        Flexible Cap                  Function FlexCap_HW2P()
        Bond Options (American)       Function OptBondUS_HW2P()
        Floating Swap-leg             Function SwapFl_HW2NPV()
        Swaption (european)           Function Swaption_HW2P()
        Swaption (bermudan)           Function SwaptionNC_HW2P()
        Swaption (declining bermudan) Function SwaptionCC_HW2P()
        Caption/Floortion (bermudan)  Function Caption_HW2P()


HWCF: Hull & White Model with Closed Forms for European Style Options
---------------------------------------------------------------------

A special case of the general HW model framework has normally distributed
short-rate. In this setting closed form pricing formulae exist for a range of
term structure derivatives. These are covered by special
types and functions in SCEcon.

The short-rate proces is in this case defined as:

        d(r)     = drift(r) + vol

        drift(r) = ( theta + a * r ) * dt

        vol(r)   = sigma * dZ

        r          is the short-rate
        
        theta      is the steady-state level
        
        a          is the mean-reversion factor. The order of magnitude
                   is typically 0.01

        dt         is a infinitesimal time-increment

        dZ         is a normally distributed shock

        sigma      is the standard deviation of the short-rate. 
                   The order of magnitude is typically 0.01

The SCEcon datatype HWCFPARMS contains the model parameters a and sigma.

Given the model parameters a and sigma, theta can be found from
the zero coupon rates. 

The zero-coupon rates are not directly observables, but can be
calibrated to given market prices of bonds or money/swap market 
instruments. This can be done using the SCEcon functions 
Fit_BSEC2DF() and Boot_BSEC2DF().

The model parameters (a and sigma) are also not directly observables, 
but can be calibrated to given market prices of vanilla caps/floors 
or vanilla swaptions. This can be done using the SCEcon functions 
Fit_Cap2HWCF() and Fit_Swaption2HWCF().

When invoking this HWCF method a few details must be remembered

        In various markets various methods for calculating the time till
        option strike t are used. In particular various day fraction
        conventions are used. In SCecon the datatype CALCONV is used
        to describe these conventions.

        Also various methods are used for constructing the risk-free
        rate r from zero-coupon rates or discount factors. The risk-free 
        rate is often a money market yield. In SCecon the type IRRCONV 
        is used to parameterise these conventions.

For a given option it is straightforward to calculate the Premium. Often
however, it is more interesting to calculate the volatility given an
option premium. This implied volatility can be found by iterating on 
the basic equtaion for sequential guesses on the volatility v. In SCecon 
a Newton-Raphson iteration method is used.

Another relevant task is to calculate sensitivities (greeks) of the Premium 
to changes in the parameters. In SCecon the following Greeks are
available:

        $Duration            First order sensitivity of Premium wrt the 
                             term structure of interest rates or just r.
                             This expresses the effect a change in interest  
                             rates has on the Premium
        BPV                  The Basis Point Value of a parallel shift of the
                             zero rates.
        Vega1                First order sensitivity of Premium wrt the
                             short-rate volatility. 
                             This expresses the effect a change 
                             in the short-rate volatility has on the Premium
        Vega2                First order sensitivity of Premium wrt the
                             mean-reversion level. This expresses the effect
                             a change in the mean-reversion level has on the 
                             Premium
        Theta                First order sensitivity of Premium wrt the
                             time till option strike. This expresses the 
                             change in option premium as time passe.


These risk numbers can be found by invoking the security pricing routines with
a risk toggle set (see the SCecon data type RISKSET). The HWCF based security 
pricing routines are named

        <sec>_HWCF2<key>() or <sec>_HW2<key>()

Note that the first order derivatives are calculated as a spin-off
from the Premium calculation (for speed purposes).

The (SCecon) securities for which a HWCF based approach to valuation is 
implemented are (all are restricted to european exercise feature):

        Cap/Floor                     Function Cap_HWCF2P()
        Bond Options                  Function OptBond_HWCF2P()
        Swaption                      Function Swaption_HWCF2P()
        Quanto Swap (Floating leg)    Function SwapDiff_HWCF2P()
        Option on Bond Future         Function OptFutBond_HWCF2P()
        Caption/Floortion (bermudan)  Function Caption_HWCF2P()



VAR: Delta-Normal Value-at-Risk - a la RiskMetrics
--------------------------------------------------

An important portfolio figure is the VaR (Value-at-Risk) measure 
as introduced by JP Morgan in the RiskMetrics framework. The idea 
is to compute the overall portfolio sensitivity to market movements 
taking a long list of risk factors into account. Computing this 
sensitivity is a quite difficult task. To simplify matters the 
RiskMetrics framework suggests a simple first order approximation 
in addition to assuming the portfolio value to be normal. In the 
general case this is insufficient and may lead to large deviations 
on the VaR measure. For so-called linear instruments: Bonds, Swaps,
Futures, and Forwards this assumption and the first order approximation
suffices.

By the first-order approximation the calculation of the VaR measure
is broken into two parts:

        Calculation of position sensitivities

        Consolidation into the VaR measure

Each of the position sensitivities can be computed using the
generalised functions:

        <security>_<model>2RiskPos()

which return the sensitivities in form of a RISKPOSLIST and
require risk factors to be identified by a RISKTOKENARRAY
insides the DELTASET. The DELTASET contains a set of shocked
zero-rate curves, and should be computed only once for each
relevant curve in each currency using the Boot_DeltaPrep() or 
Disc_DeltaPrep().

The VaR consolidation requires the presence of a variance-covariance
matrix of the chosen risk factors. The function SCRM_ReadCovMatrix()
provides the facility of reading a subset variance-covariance matrix
from the RiskMetrics datasets into the VARCOVMATRIX type.
Once the variance-covariance matrix is ready the VaR may be computed
using the function:

        VAR_MATRIX2VAR()


,,EABBR,,*/





/*,,SOT,,

FL64SMATRIX
-----------

This data type is defined as
  
        typedef FL64MATRIX  FL64SMATRIX ;

in the scecon.h file. This type is intended for holding the LOWER half (incl
diagonal) of a symmetric matrix.
  
,,EOT,,*/

typedef FL64MATRIX  FL64SMATRIX ;


/*,,SOT,,

FL64LIST: Sized arrays of FL64's
--------------------------------

FL64LIST is defined as:

        typedef struct fl64list_tag
        {
            FL64ARRAY array ;
            INTI size ;
        } FL64LIST ;

in the scecon.h file. 
The data members are interpreted as:

        array   array[size] is an array of numbers.

        size    The number of elements in the array.

,,EOT,,*/

typedef struct fl64list_tag 
{
    FL64ARRAY array ;
    INTI size ;
} FL64LIST ;



  

/*,,SOT,,

CCYCODE and CCYCODEARRAY: Currency and Commodity Class Codes
-------------------------------------------

This type is defined as:

        #define CCY_LENGTH 4 
        typedef char CCYCODE[CCY_LENGTH] ;

Allowed values for CCYCODE are any Swift code for currencies:
e.g CAD, USD, NOK, DKK, SEK, DEM, ....

Or any standard commodity class indicator, e.g. ALU, COP,
GAS, ... (as defined in the Riskmetrics dataset from J.P. Morgan).

Please note that all instances of CCYCODE's are assumed to 
be zero-terminated.

,,EOT,,*/

#define CCY_LENGTH 4 
typedef char CCYCODE[CCY_LENGTH] ;
typedef CCYCODE * CCYCODEARRAY ;



/*,,SOT,,

RISKCLASS, RISKTOKEN, RISKTOKENARRAY: Risk factor definition data types
-----------------------------------------------------------------------

These data types are defined as:

        #define CLASS_LENGTH 5
        typedef char RISKCLASS[CLASS_LENGTH] ;

        typedef struct risktoken_tag
        {
            CCYCODE   ccy ;
            RISKCLASS rclass ;   
        }   RISKTOKEN ;

The data type is used to define a risk factor for VAR (Value-at-Risk) 
calculations.

The data members are interpreted as:

        ccy is the currency / commodity class indicator.
        Allowed values for for CCYCODE are described elsewhere.

        rclass is the risk class. An example of the definition of
        risk classes are the Riskmetrics dataset -- here allowed
        values for class are:

            XS      Exchange rate (RiskMetrics wrt USD)
            R***    Money market rate, e.g. R030, ..., R360
            Z**     Government zero rate, e.g. Z02, Z03, .. Z30
            S**     Swap zero rate, e.g. S02, S03, .. S10
            SE      Equity index
            C**     Commodity price (RiskMetrics wrt USD)

Please note that all instances of RISKCLASS's are assumed to 
be zero-terminated.

By using this terminology one define risk factors as:

        DEM.XS      DEM FX rate (relative to homeCCY)
        USD.R030    US 1M money market rate
        DKK.Z10     10Y Danish Government Zero rate
        SEK.S07     7Y Swedish swap zero rate
        FRF.SE      The French CAC40 Equity index
        GAS.C03     3 month Natural Gas Future

etc.

Note that not all combinations of code / token are allowed (as indicated by
the examples above).

RISKTOKEN's are used to map sensitivities correctly to risk positions.

Lists of RISKTOKEN's are defined as:

        typedef RISKTOKEN * RISKTOKENARRAY ;

,,EOT,,*/

#define CLASS_LENGTH 5
typedef char RISKCLASS[CLASS_LENGTH] ;

typedef struct risktoken_tag
{
    CCYCODE   ccy ;
    RISKCLASS rclass ;   
}   RISKTOKEN ;

typedef RISKTOKEN * RISKTOKENARRAY ;


/*,,SOT,,

RISKPOSLIST: Data type for holding list of risk positions
------------------------------------------------------------

RISKPOSLIST is defined as:

        typedef struct riskposlist_tag
        {
            INTI           npos ;
            RISKTOKENARRAY token ;
            FL64ARRAY      pos ;
        }   RISKPOSLIST ;
  
Where the data are interpreted as:    

        npos          number of entries in arrays.
        
        token[npos]   array of risk tokens for the risk factors.

        pos[npos]     array of risk positions for the risk factors.
        
,,EOT,,*/

typedef struct riskposlist_tag
{
    INTI           npos ;
    RISKTOKENARRAY token ;
    FL64ARRAY      pos ;
}   RISKPOSLIST ;


/*,,SOT,,

FXRISKSET: Data type for holding info on FX Risk
------------------------------------------------

Defined as:

        typedef struct fxriskset_tag
        {
            FL64      rate ;
            RISKTOKEN token ;
            FL64      shock ;
            CCYCODE   home ;  
        }   FXRISKSET ;

Used for Risk Position Calculations, where the FX risk is accounted for.

        rate is the actual FX rate in Home CCY units per Instrument CCY
        unit in base 1.

        token is the risk factor identification (CCY.XS in Riskmetrics
        terminology).

        shock is the shock size used for shocking the FX spot rate. The
        shock must be quoted in pct., eg. enter 0.01 for a one basis 
        point shock. shock is needed when calculation risk positions for
        instruments where a FX spot rate is used to calculate PV, eg. 
        FX options and options on FX forwards.

        home is the CCYCODE for the Home currency.

,,EOT,,*/

typedef struct fxriskset_tag
{
    FL64      rate ;
    RISKTOKEN token ;
    FL64      shock ;
    CCYCODE   home ;
}   FXRISKSET ;


/*,,SOT,,

MODELSTAT: Model status
-----------------------

This enumeration is used to inform on the capability of a model to handle
a given instrument.

It is defined as:

        typedef enum modelstat_tag
        {
            Model_OK,
            Exotic_Feature_Not_Handled,
            Amortisations_Not_Handled,
            Backset_Not_Handled,
            Factor_Not_Handled,
            Compounding_Not_Handled,
            Averaging_Not_Handled,
            Stepping_Not_Handled,
            Non_Vanilla_Not_Handled
        }   MODELSTAT ;   

The various entries are used to signal the exact reason why a given model 
does not handle a particular instrument. Model_OK indicates that everything
is ok.

If a pricing routine does not return a MODELSTAT information, one should be
able to price all variations of instrument data using the model.
  
,,EOT,,*/

typedef enum modelstat_tag
{
    Model_OK,
    Exotic_Feature_Not_Handled,
    Amortisations_Not_Handled,
    Backset_Not_Handled,
    Factor_Not_Handled,
    Compounding_Not_Handled,
    Averaging_Not_Handled,
    Stepping_Not_Handled,
    Non_Vanilla_Not_Handled
}   MODELSTAT ;   


/*
..controlled indexation
*/

#define GetArrayEl(p, i, n, def) ((p != NULL && i < n && i >= 0) ? p[i] : def)

/*** declarations used by the errorhandler routines *******************/


#ifdef __cplusplus
}
#endif

#endif

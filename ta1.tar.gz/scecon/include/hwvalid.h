/* SCCS: @(#)hwvalid.h	1.4 (SimCorp) 99/02/19 14:21:41 */

#ifndef HWVALID_H
#define HWVALID_H

/************************************************************************
*                                                                       *
*    project     SCecon                                                 *
*                                                                       *
*    filename    validate.h                                             *
*                                                                       *
*    general     this file contains declarations, initializations,      *
*                type definitions and function prototyping for the      *
*                validation module of the standard library SCecon       *
*                                                                       *
************************************************************************/

/**** includes *********************************************************/
#include <hw.h>
#include <validate.h>

#ifdef __cplusplus
extern "C" {
#endif

/*** typedefines *******************************************************/


/*** function prototyping (hwvalid.c) *************************************/

extern BOOLE Validate_HWFIXPARM(HWFIXPARM r);
extern BOOLE Validate_HWFUNC(HWFUNC r);

extern VALIDATE Validate_CCSWAPTION(CCSWAPTION *x);
extern VALIDATE Validate_CHVPARMS(CHVPARMS *x);
extern VALIDATE Validate_DEBTOR(DEBTOR *cm) ;
extern VALIDATE Validate_DEBTORARRAY(DEBTORARRAY cm, INTI n) ;
extern VALIDATE Validate_DKMBS(DKMBS *cm) ;
extern VALIDATE Validate_DKMBSMODEL(DKMBSMODEL *cm) ;
extern VALIDATE Validate_HWBOOTRES(HWBOOTRES *x);
extern VALIDATE Validate_HWCFDIFF(HWCFDIFF *x);
extern VALIDATE Validate_HWCFPARMS(HWCFPARMS *x);
extern VALIDATE Validate_HWCMTMODL(HWCMTMODL *x);
extern VALIDATE Validate_HWPARMS(HWPARMS *x);
extern VALIDATE Validate_KFDEBTOR(KFDEBTOR *cm);
extern VALIDATE Validate_KFDEBTORARRAY(KFDEBTORARRAY cm, INTI n);
extern VALIDATE Validate_NCSWAPTION(NCSWAPTION *x);
extern VALIDATE Validate_USBONDOPT(USBONDOPT *x);


#ifdef __cplusplus
}
#endif

#endif

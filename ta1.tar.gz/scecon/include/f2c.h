/* SCID @(#)f2c.h	1.8 (SimCorp) 98/06/16 13:18:07 */

/* f2c.h  --  Standard Fortran to C header file */
/* integer & logical now int instead of long .. PHF/910227 */

#ifndef F2C_INCLUDE
#define F2C_INCLUDE

#ifdef __cplusplus
extern "C" {
#endif

typedef int integer;
typedef char *address;
typedef short int shortint;
typedef float real;
typedef double doublereal;
typedef struct { real r, i; } complex;
typedef struct { doublereal r, i; } doublecomplex;
typedef int logical;
typedef short int shortlogical;

#define TRUE_ (1)
#define FALSE_ (0)

/* Extern is for use with -E */
#ifndef Extern
#define Extern extern
#endif

/* I/O stuff */

#ifdef f2c_i2
/* for -i2 */
typedef short flag;
typedef short ftnlen;
typedef short ftnint;
#else
typedef long flag;
typedef long ftnlen;
typedef long ftnint;
#endif

/*external read, write*/
typedef struct
{        flag cierr;
        ftnint ciunit;
        flag ciend;
        char *cifmt;
        ftnint cirec;
} cilist;

/*internal read, write*/
typedef struct
{        flag icierr;
        char *iciunit;
        flag iciend;
        char *icifmt;
        ftnint icirlen;
        ftnint icirnum;
} icilist;

/*open*/
typedef struct
{        flag oerr;
        ftnint ounit;
        char *ofnm;
        ftnlen ofnmlen;
        char *osta;
        char *oacc;
        char *ofm;
        ftnint orl;
        char *oblnk;
} olist;

/*close*/
typedef struct
{        flag cerr;
        ftnint cunit;
        char *csta;
} cllist;

/*rewind, backspace, endfile*/
typedef struct
{        flag aerr;
        ftnint aunit;
} alist;

/* inquire */
typedef struct
{        flag inerr;
        ftnint inunit;
        char *infile;
        ftnlen infilen;
        ftnint        *inex;        /*parameters in standard's order*/
        ftnint        *inopen;
        ftnint        *innum;
        ftnint        *innamed;
        char        *inname;
        ftnlen        innamlen;
        char        *inacc;
        ftnlen        inacclen;
        char        *inseq;
        ftnlen        inseqlen;
        char         *indir;
        ftnlen        indirlen;
        char        *infmt;
        ftnlen        infmtlen;
        char        *inform;
        ftnint        informlen;
        char        *inunf;
        ftnlen        inunflen;
        ftnint        *inrecl;
        ftnint        *innrec;
        char        *inblank;
        ftnlen        inblanklen;
} inlist;

/* #define SC_VOID void */
#ifndef SC_VOID
#define SC_VOID int
#endif

union Multitype {        /* for multiple entry points */
        shortint h;
        integer i;
        real r;
        doublereal d;
        complex c;
        doublecomplex z;
        };

typedef union Multitype Multitype;

typedef long Long;

struct Vardesc {        /* for Namelist */
        char *name;
        char *addr;
        Long *dims;
        int  type;
        };
typedef struct Vardesc Vardesc;

struct Namelist {
        char *name;
        Vardesc **vars;
        int nvars;
        };
typedef struct Namelist Namelist;

#undef abs
#define abs(x) ((x) >= 0 ? (x) : -(x))
#define dabs(x) (doublereal)abs(x)
#undef FORTRAN_MIN
#define FORTRAN_MIN(a,b) ((a) <= (b) ? (a) : (b))
#undef FORTRAN_MAX
#define FORTRAN_MAX(a,b) ((a) >= (b) ? (a) : (b))
#define dmin(a,b) (doublereal)FORTRAN_MIN(a,b)
#define dmax(a,b) (doublereal)FORTRAN_MAX(a,b)

/* procedure parameter types for -A and -C++ */

#define F2C_proc_par_types 1
#ifdef __cplusplus
typedef int /* Unknown procedure type */ (*U_fp)(...);
typedef shortint (*J_fp)(...);
typedef integer (*I_fp)(...);
typedef real (*R_fp)(...);
typedef doublereal (*D_fp)(...), (*E_fp)(...);
typedef /* Complex */ SC_VOID (*C_fp)(...);
typedef /* Double Complex */ SC_VOID (*Z_fp)(...);
typedef logical (*L_fp)(...);
typedef shortlogical (*K_fp)(...);
typedef /* Character */ SC_VOID (*H_fp)(...);
typedef /* Subroutine */ int (*S_fp)(...);
#else
typedef int /* Unknown procedure type */ (*U_fp)();
typedef shortint (*J_fp)();
typedef integer (*I_fp)();
typedef real (*R_fp)();
typedef doublereal (*D_fp)(), (*E_fp)();
typedef /* Complex */ SC_VOID (*C_fp)();
typedef /* Double Complex */ SC_VOID (*Z_fp)();
typedef logical (*L_fp)();
typedef shortlogical (*K_fp)();
typedef /* Character */ SC_VOID (*H_fp)();
typedef /* Subroutine */ int (*S_fp)();
#endif
/* E_fp is for real functions when -R is not specified */
typedef SC_VOID C_f;        /* complex function */
typedef SC_VOID H_f;        /* character function */
typedef SC_VOID Z_f;        /* double complex function */
typedef doublereal E_f;        /* real function with -R not specified */

/* undef any lower-case symbols that your C compiler predefines, e.g.: */

#ifndef Skip_f2c_Undefs
#undef cray
#undef gcos
#undef mc68010
#undef mc68020
#undef mips
#undef pdp11
#undef sgi
#undef sparc
#undef sun
#undef sun2
#undef sun3
#undef sun4
#undef u370
#undef u3b
#undef u3b2
#undef u3b5
#undef unix
#undef vax
#endif

#ifdef __cplusplus
}
#endif

#endif



#ifndef OAMSIRR_H
#define OAMSIRR_H

/************************************************************************
*                                                                       *
*    project     SCecon                                                 *
*                                                                       *
*    filename    oamsirr.h                                              *
*                                                                       *
*    general															*
*                                                                       *
************************************************************************/
#include <scecon.h>
#include <tvmunit.h>
#include <disc.h>
#ifdef __cplusplus
extern "C" {
#endif


typedef struct {
        FL64ARRAY	period;
        FL64ARRAY	flow;
        INTI		nbFlow;
        FL64		initMV;
} IRR_ST, *IRR_STP;


extern BOOLE Irr_OamsCompute(IRRCONV, FL64, FL64ARRAY, FL64ARRAY, INTI, ITERCTRL*, FL64*);

extern BOOLE IRRCompound_NewtonRaphson(FL64, void*, BOOLE, FL64*, FL64*, void*);   /* PMSTA-29444 - SRIDHARA - 050318 */

extern BOOLE IRRCompoundSimple_NewtonRaphson(FL64, void*, BOOLE, FL64*, FL64*, void*); /* PMSTA-29444 - SRIDHARA - 050318 */

#ifdef __cplusplus
}
#endif
#endif


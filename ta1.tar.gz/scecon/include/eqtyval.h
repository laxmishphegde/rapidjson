/* SCID @(#)eqtyval.h	1.3 (SimCorp) 99/02/19 14:14:24 */

#ifndef EQTYVAL_H
#define EQTYVAL_H

/************************************************************************
*                                                                       *
*    project     SCecon                                                 *
*                                                                       *
*    filename    eqtyval.h                                              *
*                                                                       *
*    general     this file contains declarations, initializations,      *
*                type definitions and function prototyping for the      *
*                validation module of the standard library SCecon       *
*                                                                       *
************************************************************************/

/**** includes *********************************************************/
#include <opteqty.h>
#include <futeqty.h>
#include <validate.h>

#ifdef __cplusplus
extern "C" {
#endif

/*** typedefines *******************************************************/

/*** function prototyping (eqtyval.c) **********************************/

extern VALIDATE Validate_FUTEQTY(FUTEQTY *f) ;
extern VALIDATE Validate_FUTCMDTY(FUTCMDTY *f);
extern VALIDATE Validate_FXFORW(FXFORW *f) ;

extern VALIDATE Validate_TREEOPT(TREEOPT *x);


#ifdef __cplusplus
}

#endif

#endif





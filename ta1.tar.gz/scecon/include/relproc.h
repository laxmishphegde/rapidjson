/* SCCS: @(#)relproc.h	1.4 (SimCorp) 97/06/25 10:13:46 */

/*,,SRELPROC,,
1 Purpose
---------
The purpose of this procedure is to ensure the quality and 
consistency of SCEcon releases.

2 The release plan
------------------
The release plan describes the extensions/modifications 
planned for future releases. It is updated regularly (and 
at least once for each release) based on two sorts of inputs
  - feed-back from existing customers  and from sales 
    concerning desired functionality extensions and/or 
    modifications
  - initiatives for new/modified functionality taken by the 
    development team (FRD) based on experince with existing 
    releases and on trends in the market
  SCEcon is under full version control (using SCCS) and the 
  release procedure observes the guidelines in 
  "SimCorp System Group Release Procedures".

3 Implementation of new release
-------------------------------
The starting point for the implementation of a new release is 
the (revised) release plan. The implementation is performed by 
the development team on an existing release. A well-defined 
version of a specific product is obtained using SCCS.
  During the implementation of extended/modified functionality 
relevant test examples are added to the (cumulative) test data 
base. As a rule these test examples are co-written with 
colleagues who are not involved in the corresponding 
implementation. The updated test data base is part of the release.
Furthermore, the documentation of the modified function(s)
is changed so that the changes in functionality is documented
as well as the existing functionality.
  SCCS has facilities for keeping track of changes to files. 
In particular, whenever a file has been changed the developer in 
charge inserts in SCCS a log file with a brief description of 
the changes.

4 Product release
-----------------
Whenever the implementation of a modification/addition has been 
completed (inclusive of testing) a new release is defined for all 
affected products. Release notes are written on the basis of the 
relevant log files.

5 Release completion 
--------------------
The new release is complete when
  - all products have been successfully updated to the new release
  - the comprehensive (full data base) test has been passed
  - memory leak test has been passed
Once the relase is complete a new SCEcon version is defined in 
SCCS and release notes are compiled from product level release notes.

,,ERELPROC,,*/


/* SCID @(#)scalloc.h	1.25 (SimCorp) 99/10/27 14:26:43 */

#ifndef SCALLOC_H
#define SCALLOC_H

/************************************************************************
*                                                                       *
*       Project         SCecon                                          *
*                                                                       *
*       file name       scalloc.h                                       *
*                                                                       *
*       contains        prototypes for SimCorp allocation routines      *
*                                                                       *
************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <scecon.h>
#include <scechook.h>

/***** C++ Convenience **************************************************/
#ifdef __cplusplus
extern "C" {
#endif

/***** scalloc.c ********************************************************/

/* Public functions */
extern FL32ARRAY  Alloc_FL32ARRAY(INTI nh) ;
extern FL64ARRAY  Alloc_FL64ARRAY(INTI nh) ;
extern INTIARRAY  Alloc_INTIARRAY(INTI nh) ;
extern INTLARRAY  Alloc_INTLARRAY(INTI nh) ;
extern BOOLEARRAY Alloc_BOOLEARRAY(INTI nh) ;
extern CCYCODEARRAY Alloc_CCYCODEARRAY(INTI n) ;
extern RISKTOKENARRAY Alloc_RISKTOKENARRAY(INTI n) ;
extern FL64MATRIX Alloc_FL64MATRIX(INTI nrh,
                                         INTI nch);
extern INTIMATRIX Alloc_INTIMATRIX(INTI nrh,
                                         INTI nch) ;
extern BOOLEMATRIX Alloc_BOOLEMATRIX(INTI nrh,
                                         INTI nch) ;
extern UN32ARRAY   Alloc_UN32ARRAY(UN32    n) ;
extern UN32MATRIX  Alloc_UN32MATRIX(INTI nr, UN32 nc) ;
extern FL64SMATRIX Alloc_FL64SMATRIX(INTI n) ;
extern FL64BOX Alloc_FL64BOX(INTI n1, INTI n2, INTI n3) ;
extern FL64DIM4 Alloc_FL64DIM4(INTI n1, INTI n2, INTI n3, INTI n4) ;

extern INTIBOX   Alloc_INTIBOX(INTI n1, INTI n2, INTI n3) ;
                                            
extern void Free_FL32ARRAY(FL32ARRAY v) ;
extern void Free_FL64ARRAY(FL64ARRAY v) ;
extern void Free_INTIARRAY(INTIARRAY v) ;
extern void Free_INTLARRAY(INTLARRAY v) ;
extern void Free_BOOLEARRAY(BOOLEARRAY v) ;
extern void Free_CCYCODEARRAY(CCYCODEARRAY vector) ;
extern void Free_RISKTOKENARRAY(RISKTOKENARRAY v) ;
extern void Free_FL64MATRIX(FL64MATRIX m) ;
extern void Free_INTIMATRIX(INTIMATRIX m) ;
extern void Free_BOOLEMATRIX(BOOLEMATRIX m) ;
extern void Free_FL64SMATRIX(FL64SMATRIX s) ;

extern void Free_UN32ARRAY(UN32ARRAY   ua) ;
extern void Free_UN32MATRIX(UN32MATRIX  um) ;
extern void Free_FL64BOX(FL64BOX b) ;
extern void Free_FL64DIM4(FL64DIM4  b) ;
extern void Free_INTIBOX(INTIBOX ib) ;

extern FL64LIST Set_FL64LIST(FL64ARRAY array, INTI size) ;

#ifdef __cplusplus
}
#endif

#endif

#ifndef OPTIO_H
#define OPTIO_H

#include <sccsid.h>
SCCSID(optio_h,
  "@(#)optio.h	1.4 (SimCorp) 99/02/19 14:17:59")

/************************************************************************
*                                                                       *
*   project     SCecon                                                  *
*                                                                       *
*   file name   str2conv.h                                              *
*                                                                       *
*   general     This file contains the header file for the example code *
*               in str2conv.c                                           *
*                                                                       *
************************************************************************/

/*** includes **********************************************************/
#include <stdio.h>
#include <string.h>
#include <option.h>
#include <validate.h>

#ifdef __cplusplus
extern "C" {
#endif


extern PREMIUMTYPE Str2PREMIUMTYPE(TEXT txt) ;
extern OPTTYPE     Str2OPTTYPE(TEXT txt) ;
extern PAYOFF      Str2PAYOFF(TEXT txt) ;
extern OPTADD      Str2OPTADD(TEXT txt) ;
extern KNOCKTYPE   Str2KNOCKTYPE(TEXT txt) ;
extern CTTYPE      Str2CTTYPE(TEXT txt) ;

extern PREMIUMTYPE Read_PREMIUMTYPE(FILE *in, FILE *out, TEXT dscr);
extern OPTTYPE Read_OPTTYPE(FILE *in, FILE *out, TEXT dscr);
extern PAYOFF Read_PAYOFF(FILE *in, FILE *out, TEXT dscr);     
extern OPTADD Read_OPTADD(FILE *in, FILE *out, TEXT dscr);     
extern KNOCKTYPE Read_KNOCKTYPE(FILE *in, FILE *out, TEXT dscr);  
extern CTTYPE Read_CTTYPE(FILE *in, FILE *out, TEXT dscr);     

extern OPTFUT    Read_OPTFUT(FILE *in, FILE *out) ;
extern OPTCT     Read_OPTCT(FILE *in, FILE *out) ;



#ifdef __cplusplus
}
#endif


#endif



/* SCID @(#)bond.h	1.18 (SimCorp) 99/10/01 15:04:43 */

#ifndef BOND_H
#define BOND_H

/************************************************************************
*                                                                       *
*    project    SCecon                                                  *
*                                                                       *
*    filename   bond.h                                                  *
*                                                                       *
*    this file contains definitions and function prototyping for the    *
*    routines in the SCecon Bond module                                 *
*                                                                       *
************************************************************************/

/***** includes ********************************************************/
#include <tvm.h>
#include <disc.h>
#include <cflw.h>

/***** C++ Convenience *************************************************/
#ifdef __cplusplus
extern "C" {
#endif


/*,,SOT,,

YTMCONV: Type for defining Yield to Maturity calculation:
---------------------------------------------------------

The data type for holding informations on YTM calculations, YTMCONV is
defined as

        typedef struct
        {
            IRRCONV irr ;
            PMTFREQ qb_ytm ;
            BOOLE   dayfrac_first ;
            BOOLE   dayfrac_normal ;
            BOOLE   dayfrac_last ;
            CALCONV cal_first ;
            CALCONV cal_normal ;
            CALCONV cal_last ;
            BOOLE   trueYTM ;
            BOOLE   as_bullet ;
        }   YTMCONV ;

When irr is NOT JGBYTM, then the YTM is found by matching the dirty
price with the PV of the cashflow of the bond:

        Price + Accrued = Sum( Payment(i) * df(YTM, i) )
                           i

where df() indicates a discount factor. These discount factors are deter-
mined by the interest rate convention (irr), the quoting basis (qb_ytm)
and the 'term generation' principle. I.e. for irr = SIMPLE_MM df() is:

        df(YTM, i) = 1 / (1 + YTM * dayfraction, i)

where the dayfraction is determined by the calendar principle in combina-
tion with the denominator, since the dayfraction is:

        dayfraction = days_in_period / denominator

The calculation of denominators has many facets to it. It may be the number
of days per year inherent in a calendar, or it may be number of annual
payments times the number of days in a specific period.

It is the aim of YTMCONV to handle the various conventions known in the
various marketplaces, for dealing with interest rate conventions, quotings
hereof, day fractions and denominators.

However, when irr is JGBYTM a somewhat different approach is used, since
with this Japanese convention, a closed form solution to the YTM given a
price is found. Note that JBGYTM makes no sense for floaters, ie. floating
swap legs and FRN's.

The pieces of data in YTMCONV have the following interpretations:

        irr is the convention for quoting the yield. Cannot be MAIR.

        qb_ytm tells how the periodicity of the yield, annual/semiannual
        or other periodicities. Should NOT be NO_FREQUENCY.
        Only relevant for irr being COMPOUND, MOOSMULLER, US_TREASURY,
        COMPOUNDSIMPLE or COMPOUNDSIMPLE_ODD.

        if dayfrac_first is True then the dayfraction till the first
        payment is the number of days divided with the number of days per
        year inherent in cal_first. If it is False then the period is the
        number of days divided by the number of days in the current payment
        period times the number of payments per year.
        In this sense dayfrac_first controls the denominator for the first
        fractional period of the cashflow.

        dayfrac_normal informs on day fraction calculations in the 'normal'
        periods. True means day fractions using cal_normal, whereas False
        means 'periodic' day fractions (i.e. half a year is 0.5
        independently of cal_normal etc).
        In this sense dayfrac_normal controls the denominator for the normal
        (periodic) periods of the cashflow.

        dayfrac_last is only used when settlement is in the last coupon
        period. And has otherwise the same interpretation as dayfrac_first.
        Here cal_last is used.
        In this sense dayfrac_last controls the denominator for the last
        fractional period of the cashflow, if the cashflow has a single
        future payment.

        cal_first is the calendar used for calculating day fractions before
        the first payday.

        cal_normal is the calendar used for calculating day fractions in
        'normal' periods (after first payday). If irr is COMPOUNDSIMPLE_ODD
        then cal_normal is used for cashflows longer than one year.

        cal_last is used to calculate day fractions in the last period, when
        settlement is in this period. If irr is COMPOUNDSIMPLE_ODD then
        cal_last is used for cashflows of one year and shorter.

        trueYTM is used to signal whether holiday adjusted yield is to be
        calculated. If True and a business day adjustment method is entered
        in the yield calculator (Bond_YTM2Yield()) then business days adjusted
        yield is calculated.

        as_bullet is used to indicate that a yield is to be calculated for any 
        loan type as if it was a BULLET loan. This is known to be relevant 
        in Sweden for serials and annuities with repayments by drawings 
        (set to True). (Default should be False).

Note that if the calendar is 30/360 - based the setting of dayfrac_* is
usually not important, since all periods have the same number of days. There
are, however, exceptions (e.g. when using ANCHORSHIFT or LAST360 on
Norwegian bonds), but these - to say the least - are pretty weird.

Examples of settings are:

        US Treasuries (SIA, True/Street Yield)
        --------------------------------------
        irr            - COMPOUNDSIMPLE
        qb_ytm         - SEMIANNUALLY
        dayfrac_first  - False
        dayfrac_normal - False
        dayfrac_last   - False
        cal_first      - ACTACT
        cal_normal     - ACTACT
        cal_last       - ACTACT

        Norwegian Government Bonds
        --------------------------
        irr            - COMPOUND
        qb_ytm         - ANNUALLY
        dayfrac_first  - True
        dayfrac_normal - True
        dayfrac_last   - True
        cal_first      - ACT365
        cal_normal     - EU30E360
        cal_last       - ACT365

Similarly the conventions for other markets can be specified. See under
YTMSEG for more details.
                        
see also Set_YTMCONV

,,EOT,,*/

typedef struct
{
    IRRCONV irr ;
    PMTFREQ qb_ytm ;
    BOOLE   dayfrac_first ;
    BOOLE   dayfrac_normal ;
    BOOLE   dayfrac_last ;
    CALCONV cal_first ;
    CALCONV cal_normal ;
    CALCONV cal_last ;
    BOOLE   trueYTM ;
    BOOLE   as_bullet ;
}   YTMCONV ;


/*,,SOT,,

TAXINFO: struct for holding bond tax data
-----------------------------------------

This type is defined as

        typedef struct taxinfo_tag
        {
            FL64  tax_c ;
            FL64  tax_cg ;
            FL64  bp_tax ;
            BOOLE pro_rata ;
        }   TAXINFO ;

tax_c and tax_cg that contain percentage tax rates for coupon and capital
gain taxation respectively. Use 0.0 for no tax adjustment.

Coupon taxation is fairly straightforward, whereas capital gain
taxation is performed on an realisation basis using bp_tax as base price for
taxation. Default symmetric capital gain taxation is used, so if
non-symmetric taxation is required (as in Italy) then a min(100, bp_tax)
must be invoked elsewhere.

pro_rata indicates whether capital gain tax is calculated as capital gain
times tax rate (pro_rata is False) or as capital gain for the actual holding
period (as effective for ITL Gov. Yields per 25-Nov-1996)

see also Set_TAXINFO

,,EOT,,*/

typedef struct taxinfo_tag
{
    FL64  tax_c ;
    FL64  tax_cg ;
    FL64  bp_tax ;
    BOOLE pro_rata ;
}   TAXINFO ;


/*,,SOT,,

FIXPAY and FIXPAYARRAY: Type for holding bond data
--------------------------------------------------

This type is defined as

        typedef struct fixpay_tag
        {
            PAYDAYDEF   cday ;
            FIXRATE     fix  ;
            PAYDAYDEF   rday ;
            REPAYMNT    repay ;
            ACCRUINT    accru ;
            EXRULE      exp ;
            TAXINFO     tax ;
        }   FIXPAY ;

The type can hold information for fairly general types of fixed rate bonds,
deposits, fixed legs of swaps etc.

The various entries are defined as:

        use cday this to define coupon payday definition

        use fix for definition of coupon payment calculation.
        The definition allows for daycount selection, various 'coupon bases',
        stepped coupon. JGB specialties, prepaid coupons, decompounding, 
        accruals etc.

        use rday this to define repayment date definition. 

        repay - repayment definition
        This allows for partly payments, interest only, initial exchange,
        balloons, irregular and regular repayment schedules, redemption
        prices differing from 100 (Auf/Abgeld).

        use accru to define accrued interest calculation. 
        This allows for various features like schuldscheine, Italian 
        add-day, accrued before issue, ex-coupon calculation, 'coupon
        basis' for accrued.

        exp - definition of ex-principal calculation. Relevant for amortising
        structures.

        tax - definition of taxation principles. Use this to generate 
        post-tax cashflows.

This setup allows for fairly general types of bonds. This includes 20+
government bond segments, pfandbriefe, mortgage bonds, schuldscheine,
corporate bonds etc. FIXPAY does not allow for embedded options so consult
CONVTBL, OPTFUT, USBONDOPT etc for definition of the option components.

When filling out a FIXPAY consider using the routines:

        Bond_Simple2FIXPAY()
        BondBM_BONDBM2FIXPAY()
        Deposit_DEPOSIT2FIXPAY()
        Bond_Zero2FIXPAY()
  
for quick setting of the parameters to some standard values:

Also see under BONDSEG for ideas about simple standard settings.

FIXPAYARRAY is needed for lists of FIXPAY's
The definition of the FIXPAYARRAY type is:

    typedef FIXPAY * FIXPAYARRAY ;

If pointers members that are not allocated in a FIXPAY are initialised 
to NULL, then Free_FIXPAY() can be used to free all dynamically 
allocated underlying pointer members in a single FIXPAY struct.

see also Set_FIXPAY

,,EOT,,*/

typedef struct fixpay_tag
{
    PAYDAYDEF   cday ;
    FIXRATE     fix  ;
    PAYDAYDEF   rday ;
    REPAYMNT    repay ;
    ACCRUINT    accru ;
    EXRULE      exp ;
    TAXINFO     tax ;
}   FIXPAY ;

typedef FIXPAY * FIXPAYARRAY ;


/*,,SOT,,

DEPOSIT: a data type for holding info on deposits
-------------------------------------------------

This type is defined as:

        typedef struct deposit_tag
        {
            DATESTR  effective ;
            DATESTR  maturity ;
            PMTFREQ  freq ;
            FL64     coupon ;
            FL64     issue_price ;
            CALCONV  cal ;
            EOMCONV  eom ;
        }   DEPOSIT ;

For holding information about deposit type of instruments (CD, T-Bill, 
Deposit, Discount Note, Bill of Exchange etc).

The data should be interpreted as:

        effective is the effective - or start or issue- date of the deposit
        for forward-forward deposits this is a future date

        maturity is the maturity date of the deposit

        freq is the payment frequency of the coupons

        coupon is the annual coupon paid on the deposit

        issue_price is the amount (per 100.0 deposited) paid at issue
        (i.e. on effective), only relevant for forward-forward deposits

        cal is the day count convention to be used

        eom is the end of month convention to be used

,,EOT,,*/

typedef struct deposit_tag
{
    DATESTR  effective ;
    DATESTR  maturity ;
    PMTFREQ  freq ;
    FL64     coupon ;
    FL64     issue_price ;
    CALCONV  cal ;
    EOMCONV  eom ;
}   DEPOSIT    ;




/*,,SOT,,

BONDSEG: enumeration for characteristic (generic) bonds
-------------------------------------------------------

This enumerations is defined as:

        typedef enum bondseg_tag
        {
            USDGOV,
            GBPGOV,
            DEMGOV,
            NLGGOV,
            BEFGOV,
            ITLGOV,
            ESPGOV,
            JPYGOV,
            FRFGOV,
            DKKGOV,
            SEKGOV,
            NOKGOV,
            FIMGOV,
            CADGOV,
            NZDGOV,
            AUDGOV,
            ATSGOV,
            CHFGOV,
            IEPGOV,
            OLDGBPGOV,
            OLDITLGOV,
            OLDFIMGOV
        }   BONDSEG ;

The bond segments are all BULLET bonds and in any way standardised within
the various segments. The data refered to below refer to members in
the FIXPAY data structure. For some countries it is possible to choose both 
the setting before EMU (refered to as OLD*) and the present setting. We refer 
to "Government Bond Outlines", 11th edition,July 1998, J.P.Morgan and 
information gathered from Reuters as of Summer 1999. SimCorp can neither
guarantee that the settings are up-to-date nor conform with market
practice.

The enumerations indicate:

        USDGOV:
        Type                    US Treasury Bonds and Notes
        Calendar                ACTACT
        Frequency               Semiannual
        EndOfMonth              LAST
        CouponBase (all)        EVENCOUP
        ExCoupon                0 DAYS

        GBPGOV   
        Type                    Gilts
        Calendar                ACTACT
        Frequency               Semiannual
        EndOfMonth              SAME
        CouponBase (Normal)     EVENCOUP
        CouponBase (all other)  ODDCOUP
        ExCoupon                EX_UKGILT

        OLDGBPGOV   
        Type                    Gilts
        Calendar                ACT365
        Frequency               Semiannual
        EndOfMonth              SAME
        CouponBase (Normal)     EVENCOUP
        CouponBase (all other)  ODDCOUP
        ExCoupon                EX_UKGILT

        DEMGOV   
        Type                    Bund, Bobl, Schaetze
        Calendar                ACTACT
        Frequency               Annual
        EndOfMonth              SAME
        CouponBase (all)        EVENCOUP
        ExCoupon                0 DAYS

        NLGGOV
        Type                    Dutch State Loans (DSL)
        Calendar                EU30E360
        Frequency               Annual
        EndOfMonth              SAME
        CouponBase (all)        EVENCOUP
        ExCoupon                0 DAYS

        BEFGOV   
        Type                    OLO
        Calendar                EU30E360
        Frequency               Annual
        EndOfMonth              SAME
        CouponBase (all)        EVENCOUP
        ExCoupon                0 DAYS

        ITLGOV   
        Type                    BTP, CTO
        Calendar                ACTACT
        Frequency               Annual
        EndOfMonth              SAME
        CouponBase (all)        EVENCOUP
        ExCoupon                0 DAYS
        Both Days Inclusive     True

        OLDITLGOV
        Type                    BTP, CTO
        Calendar                EU30E360
        Frequency               Semiannual
        EndOfMonth              SAME
        CouponBase (all)        EVENCOUP
        ExCoupon                0 DAYS
        Both Days Inclusive     True
  
        ESPGOV   
        Type                    BONOS
        Calendar                ACTACT
        Frequency               Annual
        EndOfMonth              SAME
        CouponBase (all)        EVENCOUP
        ExCoupon                0 DAYS
        Accrued before Effect   False
        (all issues with nominated date = effective date for accrual)

        JPYGOV   
        Type                    Japanese Government Bonds
        Calendar (Accrued)      ACT365
        Frequency               Semiannual
        EndOfMonth              SAME
        CouponBase (normal)     EVENCOUP
        CouponBase (accrued)    ODDCOUP
        CouponBase (odd)        EVENODD
        ExCoupon                0 DAYS
        Japanese Gov. Switch    True

        FRFGOV   
        Type                    OAT, BTAN
        Calendar                ACTACT
        Frequency               Annual
        EndOfMonth              SAME
        CouponBase (all)        EVENCOUP
        ExCoupon                0 DAYS

        DKKGOV
        Type                    Danish Government Bonds and Notes (DGB)
        Calendar                EU30E360
        Frequency               Annual
        EndOfMonth              SAME
        CouponBase (all)        EVENCOUP
        ExCoupon                30 Days

        SEKGOV
        Type                    Swedish Government Bonds
        Calendar                EU30E360
        Frequency               Annual
        EndOfMonth              SAME
        CouponBase (all)        EVENCOUP
        ExCoupon                5 Business Days

        NOKGOV
        Type                    Norwegian Government Bonds
        Calendar                ACT365
        Frequency               Annual
        EndOfMonth              SAME
        CouponBase (normal)     EVENCOUP
        CouponBase (all other)  ODDCOUP
        ExCoupon                14 Days

        FIMGOV
        Type                    Markkas
        Calendar                ACTACT
        Frequency               Annual
        EndOfMonth              SAME
        CouponBase (all)        EVENCOUP
        ExCoupon                0 Days

        OLDFIMGOV
        Type                    Markkas
        Calendar                EU30360
        Frequency               Annual
        EndOfMonth              SAME
        CouponBase (all)        EVENCOUP
        ExCoupon                0 Days

        CADGOV
        Type                    Canadian Government Bonds
        Calendar                ACT365
        Frequency               Semiannual
        EndOfMonth              SAME
        CouponBase (normal)     EVENCOUP
        CouponBase (all other)  ODDCOUP
        ExCoupon                0 Days
        184 day period rule     True
        
        if (yield convention is Bank of Canada) then
        CouponBase (all)        EVENCOUP
        184 day period rule     False

        NZDGOV
        Type                    New Zealand Government Stock
        Calendar                ACTACT
        Frequency               Semiannual
        EndOfMonth              SAME
        CouponBase (all)        EVENCOUP
        ExCoupon                10 DAYS

        AUDGOV
        Type                    Australian Commonwealth Government Bonds
        Calendar                ACTACT
        Frequency               Semiannual
        EndOfMonth              SAME
        CouponBase (all)        EVENCOUP
        ExCoupon                7 DAYS

        ATSGOV
        Type                    Austrian Bund
        Calendar                EU30E360
        Frequency               Annual
        EndOfMonth              SAME
        CouponBase (all)        EVENCOUP
        ExCoupon                EX_AUT

        CHFGOV
        Type                    Swiss Government Bonds and Notes
        Calendar                EU30EP360
        Frequency               Annual
        EndOfMonth              SAME
        CouponBase (all)        EVENCOUP
        ExCoupon                0 Days

        IEPGOV    
        Type                    Irish Government Bonds (Gilts)
        Calendar                ACTACT
        Frequency               Annual 
        EndOfMonth              SAME
        CouponBase (normal)     EVENCOUP
        CouponBase (all other)  ODDCOUP
        ExCoupon                EX_IRLGILT

Note that we do not guarantee the settings. In particular conventions
are occasionally changed.

,,EOT,,*/

typedef enum bondseg_tag
{
    USDGOV,   /* Note + Bond */
    GBPGOV,   /* UK Gilt */
    DEMGOV,   /* Bund + BOBL + Schaetze */
    NLGGOV,
    BEFGOV,   /* OLO */
    ITLGOV,   /* BTP + CTO */
    ESPGOV,   /* BONOS */
    JPYGOV,   
    FRFGOV,   /* OAT + BTAN */ 
    DKKGOV,
    SEKGOV,
    NOKGOV,
    FIMGOV,
    CADGOV,
    NZDGOV,
    AUDGOV,
    ATSGOV,
    CHFGOV,
    IEPGOV,    /* IRL Gilt */
    OLDGBPGOV,
    OLDITLGOV,
    OLDFIMGOV
}   BONDSEG ;


/*,,SOT,,

YTMSEG: enumeration of standard yield calculation methods
---------------------------------------------------------

This type is defined as:

        typedef enum ytmseg_tag
        {
            ISMA360ANN,
            ISMA360SEMI,
            USDGOVEQV,
            USTEQV,
            AUDGOVEQV,
            NZDGOVEQV,
            FRFGOVEQV,
            ITLGOVEQV,
            ITLGOVEQVTRUE,
            ESPGOVEQV,
            IEPGOVEQV,
            NOKGOVEQV,
            BANKOFCANADA,
            UKBUMPDATES,            
            UKCONSORTIUM,
            JPYGOVEQV,
            MM360,
            MM365,
            REPO360,
            REPO365,
            OLDUKCONSORTIUM,
            OLDUKBUMPDATES,            
            OLDITLGOVEQV,
            OLDITLGOVEQVTRUE,
            OLDESPGOVEQV,
            DEMGOVEQV
        }   YTMSEG ;

The enum is used to define various standard conventions for yield 
calculation. For some countries it is possible to choose both the setting
before EMU (refered to as OLD*) and the present setting. We refer to 
"Government Bond Outlines", 11th edition,July 1998, J.P.Morgan and 
information gathered from Reuters as of Summer 1999. SimCorp can neither
guarantee that the settings are up-to-date nor confirm with market
practice.

The various conventions are interpreted as follows, where
the describing data refers to YTMCONV members:

30/360 related conventions:

        ISMA360ANN
        Used in:

        IRR             Compound
        CompFreq        Annually
        CalConv         EU30E360
        DayFrac         True

        Used in: DKK, SEK, CHF, ATS, NLG, BEF, ISK, LUF

        ISMA360SEMI
        Defined as:

        IRR             Compound
        CompFreq        Semiannually
        CalConv         EU30E360
        DayFrac         True

        Used as alternative (2Yr Equivalent) quote.

ACTACT related conventions:

        USDGOVEQV
        The US Street Convention defined as:

        IRR             Compound
        CompFreq        Semiannually
        CalConv         ACTACT
        DayFrac         False

        USTEQV
        The official US Treasury Convention defined as:

        IRR             US_TREASURY
        CompFreq        Semiannually
        CalConv         ACTACT
        DayFrac         False

        AUDGOVEQV
        The Australian Government Bond Convention defined as:

        IRR             Compound
        CompFreq        Semiannually
        CalConv         ACTACT
        DayFrac         False

        NZDGOVEQV
        New Zealand Government Bond convention defined as:

        IRR             Compound
        CompFreq        Semiannually
        CalConv         ACTACT
        DayFrac         False

        DEMGOVEQV
        German Government Bond convention defined as:

        IRR             Compound
        CompFreq        Annually
        CalConv         ACTACT
        DayFrac         False
      
        FRFGOVEQV
        The French Government Bond Convention (OAT + BTAN) defined as:

        IRR             Compound
        CompFreq        Annually
        CalConv         ACTACT
        DayFracFirst    True
        DayFracNormal   False

        ITLGOVEQV
        Italian Gov. Eqv. Convention (BTP, CTO)

        If tax adjusted yield is to be used then use the tax settings
        elsewhere (i.e. the bond definition).
        The old net yield requires coupon taxation and capital gain
        taxation (based on the issue price).
        The new gross yield requires no coupon taxation but capital gain
        taxation (based on the issue price on a pro rata basis).

        IRR             Compound
        CompFreq        Annually
        CalConv         ACTACT
        DayFracFirst    True
        DayFracNormal   False

        ITLGOVEQVTRUE
        Italian Gov. Eqv. Convention as True yield (BTP, CTO)

        If tax adjusted yield is to be used then use the tax settings
        elsewhere (i.e. the bond definition).
        The old true net yield requires coupon taxation and capital gain
        taxation (based on the issue price).
        The new true gross yield requires no coupon taxation but capital gain
        taxation (based on the issue price on a pro rata basis).

        IRR             Compound
        CompFreq        Annually
        CalConv         ACTACT
        DayFracFirst    True
        DayFracNormal   True
        Business Day Adjusted Cashflow 

        ESPGOVEQV
        Spanish Gov. Eqv. Convention (BONOS)

        IRR             Compound
        CompFreq        Annually
        CalConv         ACTACT
        DayFracFirst    True
        DayFracNormal   True

        IEPGOVEQV
        Irish Gov. Eqv. Convention

        IRR             Compound
        CompFreq        Annually
        CalConv         ACTACT
        DayFracFirst    True
        DayFracNormal   False

        UKBUMPDATES           
        UK Gilt Convention as True yield

        IRR             Compound
        CompFreq        Semiannually
        CalConv         ACTACT
        DayFracFirst    True
        DayFracNormal   True
        Business Day Adjusted Cashflow 

        Also refered to as Gross Redemption yield

        UKCONSORTIUM
        UK Gilt Convention (Consortium Yield)

        IRR             Compound
        CompFreq        Semiannually
        CalConv         ACTACT
        DayFracFirst    True
        DayFracNormal   False

  ACT365 related conventions:

        NOKGOVEQV
        Norwegian Gov. Eqv. Convention

        IRR             Compound
        CompFreq        Annually
        CalConv         ACT365
        DayFracFirst    True
        DayFracNormal   False

        BANKOFCANADA
        Bank of Canada convention

        IRR             Compound
        CompFreq        Semiannually
        CalConv         ACT365
        DayFrac         False

        Special convention where accrued interest is calculated as US
        Treasuries (in conflict with the official accrued interest
        calculation method...). Also stub periods are ignored.

        OLDUKCONSORTIUM
        UK Gilt Convention (Consortium Yield)

        IRR             Compound
        CompFreq        Semiannually
        CalConv         ACT365
        DayFracFirst    True
        DayFracNormal   False

        OLDUKBUMPDATES
        UK Gilt Convention as True yield

        IRR             Compound
        CompFreq        Semiannually
        CalConv         ACT365
        DayFracFirst    True
        DayFracNormal   True
        Business Day Adjusted Cashflow


        Also refered to as Gross Redemption yield

        OLDITLGOVEQV
        Italian Gov. Eqv. Convention (BTP, CTO)

        If tax adjusted yield is to be used then use the tax settings
        elsewhere (i.e. the bond definition).
        The old net yield requires coupon taxation and capital gain
        taxation (based on the issue price).
        The new gross yield requires no coupon taxation but capital gain
        taxation (based on the issue price on a pro rata basis).

        IRR             Compound
        CompFreq        Annually
        CalConv         ACT365
        DayFracFirst    True
        DayFracNormal   False

        OLDITLGOVEQVTRUE
        Italian Gov. Eqv. Convention as True yield (BTP, CTO)

        If tax adjusted yield is to be used then use the tax settings
        elsewhere (i.e. the bond definition).
        The old true net yield requires coupon taxation and capital gain
        taxation (based on the issue price).
        The new true gross yield requires no coupon taxation but capital gain
        taxation (based on the issue price on a pro rata basis).

        IRR             Compound
        CompFreq        Annually
        CalConv         ACT365
        DayFracFirst    True
        DayFracNormal   True
        Business Day Adjusted Cashflow 

  
        No-Leap date related conventions:

        JPYGOVEQV
        Special Japanese Yield Convention

        IRR             JGBYTM
        CompFreq        Annually (not used)
        CalConv         ACTNL365
        DayFrac         False

Moneymarket conventions:

        MM360
        IRR             SIMPLE_MM
        CompFreq        Annually (not used)
        CalConv         ACT360
        DayFrac         True

        MM365
        IRR             SIMPLE_MM
        CompFreq        Annually (not used)
        CalConv         ACT365
        DayFrac         True

        REPO360
        IRR             SIMPLE_REPO
        CompFreq        Annually (not used)
        CalConv         ACT360
        DayFrac         True

        REPO365
        IRR             SIMPLE_REPO
        CompFreq        Annually (not used)
        CalConv         ACT365
        DayFrac         True

NOTES:

True yield indicates a business days adjusted yield

The conventions caters for standard government bonds. There are no
T-Bill, Mortgage Bond etc specialties handled, unless these map into 
the current framework.

These conventions do not handle any last period specialties
(like MM yields, different Calendar etc). 

If Net/gross yields are to be obtained this must be handled by generating
the bond cashflows appropriately.

When calculating or using yields we do not perform any rounding or 
truncation - this must be handled elsewhere.

When calculating True yields NEXT is used as adjustment convention unless
the BUSCONV is set to something sensible.

We do not guarantee the settings. In particular conventions
are occasionally changed.

,,EOT,,*/

typedef enum ytmseg_tag
{
    ISMA360ANN,
    ISMA360SEMI,
    USDGOVEQV,
    USTEQV,
    AUDGOVEQV,
    NZDGOVEQV,
    FRFGOVEQV,
    ITLGOVEQV,
    ITLGOVEQVTRUE,
    ESPGOVEQV,
    IEPGOVEQV,
    NOKGOVEQV,
    BANKOFCANADA,
    UKBUMPDATES,            /* Also GRY + Consortium Yield */
    UKCONSORTIUM,
    JPYGOVEQV,
    MM360,
    MM365,
    REPO360,
    REPO365,
    OLDUKCONSORTIUM,
    OLDUKBUMPDATES,            /* Also GRY + Consortium Yield */
    OLDITLGOVEQV,
    OLDITLGOVEQVTRUE,
    OLDESPGOVEQV,
    DEMGOVEQV
}   YTMSEG ;


/*,,SOT,,

BONDBM, BONDBMARRAY: Data type for defining standard bonds
----------------------------------------------------------

This type is defined as:

        typedef struct bondbm_tag
        {
            BONDSEG   seg ;
            DATESTR   matur ;
            FL64      coupon ;
            ODDCONV   stub_front ;  
            DATESTR   issue_nom ;   
            DATESTR   first ;       
            TAXINFO   tax ;
        }   BONDBM ;

The data structure is used to define STANDARDISED (Government) bonds.
Typically these are in most currencies defined by a few data - primarily
maturity and coupon. All other data are then default for the segment.

The data are interpreted as:

        seg defines the bond segment. See BONDSEG for the default
        conventions that are invoked. Must be set.

        matur defines the maturity date. Must be set.
        
        coupon is the coupon rate (%). Must be set.

        stub_front. In some Government segments odd first periods are
        used (US, UK, CAD, JGB). This is indicated in this piece of data.
        Standard value is NOODD. Must be set. 
        In countries where the first period is short, but the issue carries 
        a full first coupon (as in AUD, NZD and some European countries)
        stub_front should NOT be used, since the bond at issue will trade
        with accrued interest (adjusted to the previous fictitious coupon
        date).

        issue_nom is the issue date. ONLY USED if:
        1) stub_front is not NOODD, or
        2) seg is JPYGOV, or
        3) seg is ESPGOV - in this case issue_nom is the socalled 
           nominated date (effective for accrual) which is always 
           after issue. Can be set as 0 if settle date is after
           nominated date.
        4) seg is ITLGOV and a positive capital tax rate is entered.

        first is the first payday. ONLY USED if seg is JPYGOV, and must
        be set in this case.

        tax is the tax settings (common to coupon and capital gains taxation).

Note that we do not guarantee the settings. In particular conventions
are occasionally changed.

Set using Set_BONDBM().

List of BONDBM's are defined as:

typedef BONDBM * BONDBMARRAY ;

Allocate / free using Alloc_BONDBMARRAY() / Free_BONDBMARRAY()

,,EOT,,*/

typedef struct bondbm_tag
{
    /* Basic data */
    BONDSEG   seg ;
    DATESTR   matur ;
    FL64      coupon ;
    ODDCONV   stub_front ;  /* Stub between issue and first payday */
    DATESTR   issue_nom ;   /* JGB, ESP or stub_front != NOODD */
    DATESTR   first ;       /* JGB - always */
    TAXINFO   tax ;
}   BONDBM ;

typedef BONDBM * BONDBMARRAY ;


/*,,SOT,,

HZYCONV: Conventions for horizon yield calculations
---------------------------------------------------

This type is defined as:  

        typedef struct hzyconv_tag
        {
            BOOLE   reinv ;
            BOOLE   hzp ;
            YTMCONV ytmc ;
        }   HZYCONV ;

Where

        reinv is True if interim payments are reinvested using a zero curve,
        and False means that the internal rate of return are calculated for    
        the period cashflow.            

        hzp is True if the horizon PRICE is entered in the yield calcualtion.
        If False the horizon price is calculated from the horizon cashflow.

        ytmc are the conventions used when finding the horizon yield.

See Bond_DF2Hzy(), BondPF_DF2HZY() for applications.

,,EOT,,*/

typedef struct hzyconv_tag
{
    BOOLE   reinv ;
    BOOLE   hzp ;
    YTMCONV ytmc ;
}   HZYCONV ;

/*,,SOT,,

PREPAYCONV: Convention for prepayment rates.
--------------------------------------------

This enumeration type is defined as:

        typedef enum prepayconv_tag
        {
          PREPAY_ABS,
          PREPAY_CPR,
          PREPAY_APD
        } PREPAYCONV;

This type is used for specifying the interpretation of a list
of prepayment rates in connection with prepayment adjustment
of the cash flow of a bond. 

Let  a  be an amortisation in the scheduled cash flow of the bond
at a time where the remaining principal prior to the payment is  p . 
Let  a'  and  p'  be the corresponding values in the prepayment 
adjusted cash flow and the  e  be the prepayment quoted according 
to the prepayment convention PREPAYCONV. The interpretation of its 
values are then given as follows:

        PREPAY_ABS  Absolute prepayment method:
                    The prepayment is specified as an absolute
                    amount with the old amortisation rescaled
                    accordingly:

                    a' = e + a * (p' - e) / p.

                    Prepayments without a corresponding cash flow date
                    will be ignored. Cash flow dates without 
                    prepayment will be interpreted to mean the zero
                    prepayment.

        PREPAY_CPR  Conditional Prepayment Rate (CPR) method:
                    The prepayment is specified as an annual rate
                    in percent according to the CPR convention 
                    as defined by PSA:

                    a' = e' * p' + a * (p' - e' * p') / p.

                    where  e'  is the period adjusted rate, i.e.,

                    1 - e = (1 - e')^t,

                    where  t  is the number of payments per year.
                    e'  is also denoted the Single Period Mortality
                    (SPM) or Single Monthly Mortality (SMM) for 
                    bonds with monthly payments.

                    The prepayments function is interpreted as a step 
                    function. The rate hold from and including the 
                    given date to but not including the next date. 
                    Equals 0 prior to the first date.             

        PREPAY_APD  Amortising Percentage Difference method:
                    The prepayment is specified as a period
                    rate in percent being the difference between
                    the new and the old amortising proportion:

                    a' = e * p' + a * p' / p. 

                    The prepayment function is interpreted as a
                    step function similar to PREPAY_CPR.

,,EOT,,*/

typedef enum prepayconv_tag
{
  PREPAYCONV_INIT = -1,
  PREPAY_ABS,
  PREPAY_CPR,
  PREPAY_APD
} PREPAYCONV;

/* Newton-Raphson struct */

typedef struct
{
  FL64      price ;
  INTI      qb ;
  IRRCONV   irr ;
  FL64ARRAY rerate ;
  FL64      debt ;
  PMT_STR   *pmt ;
  FL64      matur ;
} YTMINT ;

typedef struct
{
  FL64      price ;
  DISCFAC   *df ;
  CFLW_STR  *xcflw ;
  PP_STR    *pp ;
  DATESTR   *analys ;
  DFSPREAD  *dfs_tmp ;
  FL64      shock ;
} SPREADINT ;

/*** routines in bondaloc.c ********************************************/


/* Public functions */
extern FIXPAYARRAY Alloc_FIXPAYARRAY(INTI n) ;
extern void        Free_FIXPAYARRAY(FIXPAYARRAY fixp) ;
extern void        Free_FIXPAY(FIXPAY *fixp) ;
extern BONDBMARRAY Alloc_BONDBMARRAY(INTI n) ;
extern void        Free_BONDBMARRAY(BONDBMARRAY a) ;

/* Private functions */


/*** routines in bond.c ************************************************/


/* Public functions */
extern BOOLE Bond_YTM2Yield(TRADEINFO *trade,
                       FIXPAY     *fixp,
                       YTMCONV    *ytmc,
                       HOLI_STR   *holi,
                       ITERCTRL   *ictrl,
                       FL64       *ytm) ;

extern BOOLE Cflw_YTM2Yield(FL64       price,
                              CFLWARRAY  xcflw,
                              YTMCONV    *ytmc,
                              PAYDAYDEF  *pday,
                              FL64       coupon,
                              PP_STR     *pp,
                              HOLI_STR   *holi,
                              ITERCTRL   *ictrl,
                              FL64       *ytm) ;

extern FL64ARRAY Bond_GenrTerms(DATESTR    *analys,
                                 CFLWARRAY  xcflw,
                                 YTMCONV    *ytmc,
                                 PAYDAYDEF  *pday,
                                 HOLI_STR   *holi) ;

extern PMTARRAY Bond_Cflw2Pmt(DATESTR    *analys,
                              CFLWARRAY  xcflw,
                              YTMCONV    *ytmc,
                              PAYDAYDEF  *pday,
                              HOLI_STR   *holi) ;

extern FL64 Cflw_YTM2Price(FL64       ytm,
                      CFLWARRAY  xcflw,
                      YTMCONV    *ytmc,
                      PAYDAYDEF  *pday,
                      FL64       coupon,
                      PP_STR     *pp,
                      HOLI_STR   *holi,
                      RISKCONV   risk,
                      BOOLE      modf,
                      FL64       *dp,
                      FL64       *ddp) ;

extern FL64 Bond_YTM2Price(FL64       ytm,
                      TRADEINFO  *trade,
                      FIXPAY     *fixp,
                      YTMCONV    *ytmc,
                      HOLI_STR   *holi,
                      RISKCONV   risk,
                      BOOLE      modf,
                      FL64       *dp,
                      FL64       *ddp) ;

extern FL64 Bond_YTM2PV01(FL64       ytm,
                     TRADEINFO  *trade,
                     FIXPAY     *fixp,
                     YTMCONV    *ytmc,
                     HOLI_STR   *holi,
                     FL64       yshift,
                     BOOLE      mean) ;

extern FL64 Cflw_YTM2PV01(FL64       ytm,
                   CFLWARRAY  xcflw,
                   YTMCONV    *ytmc,
                   PAYDAYDEF  *pday,
                   FL64       coupon,
                   PP_STR     *pp,
                   HOLI_STR   *holi,
                   FL64       yshift,
                   BOOLE      mean) ;

extern BOOLE Bond_YTM2YV01(TRADEINFO  *trade,
                     FIXPAY     *fixp,
                     YTMCONV    *ytmc,
                     HOLI_STR   *holi,
                     ITERCTRL   *ictrl,
                     FL64       pshift,
                     BOOLE      mean,
                     FL64       *yvb) ;

extern BOOLE Cflw_YTM2YV01(FL64       price,
                    CFLW_STR   *xcflw,
                    YTMCONV    *ytmc,
                    PAYDAYDEF  *pday,
                    FL64       coupon,
                    PP_STR     *pp,
                    HOLI_STR   *holi,
                    ITERCTRL   *ictrl,
                    FL64       pshift,
                    BOOLE      mean,
                    FL64       *yvb) ;

extern FL64 Cflw_YTM2Duration(FL64       ytm,
                                CFLWARRAY  xcflw,
                                YTMCONV    *ytmc,
                                PAYDAYDEF  *pday,
                                HOLI_STR   *holi) ;

extern FL64 Bond_YTM2Duration(FL64       ytm,
                         TRADEINFO  *trade,
                         FIXPAY     *fixp,
                         YTMCONV    *ytmc,
                         HOLI_STR   *holi) ;

extern BOOLE Bond_DF2Hzy(TRADEINFO  *settle,
                   TRADEINFO  *horiz,
                   FIXPAY     *fixp,
                   HZYCONV    *hzyc,
                   DISCFAC    *dfre,
                   DISCFAC    *dfhz,
                   HOLI_STR   *holi,
                   DFSPREAD   *dfs,
                   ITERCTRL   *ictrl,
                   FL64       *hzy) ;

extern FL64 Cflw_DF2Price(DATESTR    *analys,
                     DISCFAC    *df,
                     CFLWARRAY  xcflw,
                     PP_STR     *pp,
                     HOLI_STR   *holi,
                     DFSPREAD   *dfs,
                     RISKSET    *risk,
                     FL64       *dp,
                     FL64       *ddp) ;

extern FL64 Bond_DF2Price(DATESTR    *analys,
                     TRADEINFO  *settle,
                     FIXPAY     *fixp,
                     DISCFAC    *df,
                     HOLI_STR   *holi,
                     DFSPREAD   *dfs,
                     RISKSET    *risk,
                     FL64       *dp,
                     FL64       *ddp) ;

extern FL64 Bond_DF2Duration(DATESTR*   analys,
                         TRADEINFO* trade,
                         FIXPAY*    fixp,
                         DISCFAC*   df,
                         HOLI_STR*  holi,
                         DFSPREAD*  dfs) ;

extern BOOLE Cflw_DF2Spread(FL64       price,
                       DISCFAC    *df,
                       CFLWARRAY  xcflw,
                       PP_STR     *pp,
                       HOLI_STR   *holi,
                       DFSPREAD   *dfs,
                       ITERCTRL   *ictrl,
                       FL64       *oas) ;

extern BOOLE Bond_DF2Spread(TRADEINFO *trade,
                       FIXPAY     *fixp,
                       DISCFAC    *df,
                       HOLI_STR   *holi,
                       DFSPREAD   *dfs,
                       ITERCTRL   *ictrl,
                       FL64       *oas) ;

extern CFLWARRAY Bond_GenrCflw(TRADEINFO *start,
                         FIXPAY    *fixp,
                         HOLI_STR  *holi,
						 FL64ARRAY  fixRate = NULL,
	                     FLAG_T = FALSE);   /* PMSTA-42879 - SRIDHARA - 18032021 */

extern CFLWARRAY Bond_GenrPeriod(TRADEINFO *start,
                           TRADEINFO *end,
                           FIXPAY    *fixp,
                           HOLI_STR  *holi) ;

extern AIRESULT Bond_Accruint(TRADEINFO   *basis,
                       FIXPAY      *fixp,
                       HOLI_STR    *holi,
					   FLAG_T = FALSE) ;

extern void Bond_TaxAdjCflw(CFLW_STR* xcflw,
                               TAXINFO*  tax,
                               DATESTR*  eff,
                               DATESTR*  matur) ;

extern FL64 Cflw_WAL(CFLW_STR   *xcflw,
                     YTMCONV    *ytmc,
                     PAYDAYDEF  *pday,
                     HOLI_STR   *holi) ;

extern FL64 Cflw_LIFE(CFLW_STR   *xcflw,
                      YTMCONV    *ytmc,
                      PAYDAYDEF  *pday,
                      HOLI_STR   *holi) ;

extern FIXPAY Bond_Zero2FIXPAY(DATESTR *matur) ;

extern FIXPAY Bond_Simple2FIXPAY(DATESTR   *settle,
                          DATESTR   *issue,
                          DATESTR   *matur,
                          FL64      coupon,
                          PMTFREQ   freq,
                          BONDTYPE  type,
                          EXRULE    *exc,
                          EXRULE    *exp,
                          CALCONV   cal,
                          EOMCONV   eom) ;

extern FL64ARRAY Cflw_DF2Delta(DATESTR    *analys,
                          DISCFAC    *df,
                          CFLW_STR   *xcflw,
                          PP_STR     *pp,
                          HOLI_STR   *holi,
                          DFSPREAD   *dfs,
                          DELTASET  *ds) ;

extern FL64ARRAY RepoCflw_DF2Delta(DATESTR    *analys,
                        DISCFAC    *df,
                        CFLW_STR   *xcflw,
                        DATESTR    *matur,
                        PP_STR     *pp,
                        HOLI_STR   *holi,
                        DFSPREAD   *dfs,
                        DELTASET   *ds) ;

extern FL64 RepoCflw_DF2Price(DATESTR    *analys,
                   DISCFAC    *df,
                   CFLW_STR   *xcflw,
                   DATESTR    *matur,
                   PP_STR     *pp,
                   HOLI_STR   *holi,
                   DFSPREAD   *dfs,
                   RISKSET    *risk,
                   FL64       *dp,
                   FL64       *ddp) ;

extern BOOLE RepoCflw_YTM2Yield(FL64       price,
                         CFLW_STR   *xcflw,
                         DATESTR    *matur,
                         YTMCONV    *ytmc,
                         PAYDAYDEF  *pday,
                         FL64       coupon,
                         PP_STR     *pp,
                         HOLI_STR   *holi,
                         ITERCTRL   *ictrl,
                         FL64       *ytm) ;

extern FL64 RepoCflw_YTM2Price(FL64       ytm,
                    CFLW_STR   *xcflw,
                    DATESTR    *matur,
                    YTMCONV    *ytmc,
                    PAYDAYDEF  *pday,
                    FL64       coupon,
                    PP_STR     *pp,
                    HOLI_STR   *holi,
                    RISKCONV   risk,
                    BOOLE      modf,
                    FL64       *dp,
                    FL64       *ddp) ;

extern FL64ARRAY Bond_DF2Delta(DATESTR    *analys,
                          TRADEINFO  *trade,
                          FIXPAY     *fixp,
                          DISCFAC    *df,
                          HOLI_STR   *holi,
                          DFSPREAD   *dfs,
                          DELTASET  *ds) ;

extern FL64ARRAY Cflw_YTM2Risk(BOOLEARRAY what,
                        INTI       nw,
                        FL64       pry,
                        BOOLE      p_y,
                        FL64       coupon,
                        CFLW_STR   *xcflw,
                        YTMCONV    *ytmc,
                        PAYDAYDEF  *pday,
                        PP_STR     *pp,
                        HOLI_STR   *holi,
                        YTMCONV    *ytmcr,
                        ITERCTRL   *ictrl,
                        CALCONV    cal_mm,
                        BOOLE      *ok) ;

extern YTMCONV Set_YTMCONV(IRRCONV irr,
                         PMTFREQ qb_ytm,
                         BOOLE   dayfrac_first,
                         BOOLE   dayfrac_normal,
                         BOOLE   dayfrac_last,
                         CALCONV cal_first,
                         CALCONV cal_normal,
                         CALCONV cal_last,
                         BOOLE   trueYTM,
                         BOOLE   as_bullet) ;

extern FIXPAY Set_FIXPAY(PAYDAYDEF   *cday,
                       FIXRATE     *fix,
                       PAYDAYDEF   *rday,
                       REPAYMNT    *repay,
                       ACCRUINT    *accru,
                       EXRULE      *exp,
                       TAXINFO     *tax) ;

extern TAXINFO Set_TAXINFO(FL64 c, FL64 cg, FL64 tax, BOOLE pro_rata) ;

extern HZYCONV Set_HZYCONV(BOOLE    reinv,
                              BOOLE    hzp,
                              YTMCONV* ytmc) ;

extern FL64ARRAY Bond_RexIndexPrices(FL64MATRIX quotes,   
                              INTI       sub_indx,
                              FL64*      indx_coup);

/* Private functions */
extern FL64 Bond_Period_Term(DATESTR* prev_num,
                         DATESTR* next_num,
                         DATESTR* prev_denom,
                         DATESTR* next_denom,
                         CALCONV  cal,
                         FL64     qb,
						 HOLI_STR   *holi);  	/* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */
extern TRADEINFO bond_set_tradeinfo(DATESTR *matur) ;
extern FL64 Cflw_Extract_Coupon(CFLW_STR *xcflw) ;
extern BOOLE bond_comp_ytmc(YTMCONV *y1, YTMCONV *y2) ;
extern BOOLE bond_price2yield(FL64      price,
                       INTI      basis,
                       IRRCONV   irr,
                       FL64ARRAY rerates,
                       FL64      debt,
                       PMT_STR   *paym,
                       FL64      matur,
                       ITERCTRL  *ictrl,
                       FL64      *ytm,
					   HOLI_STR  *holi); 	/* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */
extern BOOLE bond_root(FL64 price, INTI  qb, IRRCONV irr, FL64ARRAY rerate,
                       FL64 debt, PMT_STR *pmt, FL64 matur,
					   ITERCTRL *ictrl, FL64 *ytm, HOLI_STR	*holi); 	/* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */
extern FIXPAY Bond_YTM_Prep(TRADEINFO *trade, FIXPAY *fixp, YTMCONV *ytmc) ;
extern IRRCONV Bond_Set_IRRCONV(CFLW_STR *cflw, IRRCONV irr, EOMCONV eom) ;
extern void bond_set_itervars(ITERCTRL *ictrl,
                                 ITERCTRL *ctrl,
                                 FL64     *shock,
                                 BOOLE    ytm) ;

extern YTMINT Bond_SetYTMINT(FL64      price,
                                INTI      qb,
                                IRRCONV   irr,
                                FL64ARRAY rerate,
                                FL64      debt,
                                PMT_STR   *pmt,
                                FL64      matur) ;

extern void Bond_GetYTMINT(YTMINT    *ytm_data,
                              FL64      *price,
                              INTI      *qb,
                              IRRCONV   *irr,
                              FL64ARRAY *rerate,
                              FL64      *debt,
                              PMT_STR   **pmt,
                              FL64      *matur) ;

extern BOOLE Bond_NewtonRaphson(FL64   x, 
                                   void   *y,
                                   BOOLE  grad,
                                   FL64   *fx, 
                                   FL64   *dfx,
								   void   *hol) ;   /* PMSTA-29444 - SRIDHARA - 050318 */

extern SPREADINT Cflw_SetSPREADINT(FL64      price,
                                DISCFAC   *df,
                                CFLW_STR  *xcflw,
                                PP_STR    *pp,
                                DATESTR   *analys,
                                DFSPREAD  *dfs_tmp,
                                FL64      shock) ;

extern void Cflw_GetSPREADINT(SPREADINT    *spr_data,
                              FL64      *price,
                              DISCFAC   **df,
                              CFLW_STR  **xcflw,
                              PP_STR    **pp,
                              DATESTR   **analys,
                              DFSPREAD  **dfs_tmp,
                              FL64      *shock) ;

extern BOOLE Cflw_NewtonRaphson(FL64   x, 
                                   void   *y,
                                   BOOLE  grad,
                                   FL64   *fx, 
                                   FL64   *dfx,
								   void   *hol) ;  /* PMSTA-29444 - SRIDHARA - 050318 */

extern HOLI_STR bond_set_holi(HOLI_STR *holi, FIXRATE *fix) ;

extern BOOLE Bond_DF2RexYield(DATESTR* Lstart,
                            INTI     dur,
                            TERMUNIT unit,
                            PMTFREQ  freq,
                            FL64     coupon,
                            CALCONV  cal,
                            DISCFAC* df_cflw,
                            FL64*    ytm) ;


/*** routines in depo.c ************************************************/


/* Public functions */

extern FIXPAY Deposit_DEPOSIT2FIXPAY(DEPOSIT *depo,
                                     HOLI_STR *holi) ;

extern FL64 Deposit_DF2Price(DATESTR    *analys,
                      DEPOSIT    *depo,
                      DISCFAC    *df,
                      HOLI_STR   *holi,
                      DFSPREAD   *dfs,
                      RISKSET    *risk,
                      FL64       *dp,
                      FL64       *ddp) ;

extern FL64ARRAY Deposit_DF2Delta(DATESTR    *analys,
                           DEPOSIT    *depo,
                           DISCFAC    *df,
                           HOLI_STR   *holi,
                           DFSPREAD   *dfs,
                           DELTASET  *ds) ;

extern AIRESULT Deposit_Accruint(DATESTR *analys,
                          DEPOSIT    *depo,
                          HOLI_STR   *holi) ;



/*** routines in bondpf.c **********************************************/


/* Public functions */
extern CFLWARRAY Cflw_MergeCFLWARRAY(CFLWARRAY cflw, 
                                      FL64ARRAY notnal, 
                                      INTI n) ;

extern CFLWARRAY Bond_MergeCFLWARRAY(TRADEINFOARRAY trade,
                                      FIXPAYARRAY    fixp,
                                      INTI           nfixp,
                                      HOLI_STR       *holi) ;

extern BOOLE BondPF_YTM2Yield(TRADEINFOARRAY trade,
                              FIXPAYARRAY    fixp,
                       INTI           nfixp,
                       YTMCONV        *ytmc,
                       HOLI_STR       *holi,
                       ITERCTRL       *ictrl,
                       FL64           *ytm) ;

extern FL64 BondPF_YTM2Duration(FL64           ytm,
                         TRADEINFOARRAY trade,
                         FIXPAYARRAY    fixp,
                         INTI           nfixp,
                         YTMCONV        *ytmc,
                         HOLI_STR       *holi) ;

extern BOOLE BondPF_DF2Hzy(TRADEINFOARRAY trade,
                     TRADEINFOARRAY horiz,
                     FIXPAYARRAY    fixp,
                     INTI           nfixp,
                     HZYCONV        *hzyc,
                     DISCFAC        *dfre,
                     DISCFAC        *dfhz,
                     HOLI_STR       *holi,
                     DFSPREADARRAY  dfs,
                     ITERCTRL       *ictrl,
                     FL64           *hzy) ;

extern TRADEINFOARRAY Alloc_TRADEINFOARRAY(INTI ns) ;

extern void Free_TRADEINFOARRAY(TRADEINFOARRAY t) ;

/* Private functions */
extern CFLWARRAY Alloc_CFLW(INTI ns) ;

extern void Free_CFLW(CFLWARRAY cflw) ;



/*** routines in bondseg.c *********************************************/


/* Public functions */
extern YTMCONV BondBM_YTMSEG2YTMCONV(YTMSEG yseg) ;

extern FIXPAY BondBM_BONDBM2FIXPAY(DATESTR *settle, 
                                   BONDBM  *bond, 
                                   YTMSEG  yseg) ;

extern FL64 BondBM_YTM2Price(FL64     ytm,
                      DATESTR  *settle, 
                      BONDBM   *bond, 
                      YTMSEG   yseg,
                      HOLI_STR *holi,
                      RISKCONV risk,
                      BOOLE    modf,
                      FL64     *dp,
                      FL64     *ddp) ;

extern BOOLE BondBM_YTM2Yield(FL64     price,
                       DATESTR  *settle, 
                       BONDBM   *bond, 
                       YTMSEG   yseg,
                       HOLI_STR *holi,
                       FL64     *ytm) ;

extern FL64 BondBM_YTM2Duration(FL64     ytm,
                         DATESTR  *settle, 
                         BONDBM   *bond, 
                         YTMSEG   yseg,
                         HOLI_STR *holi) ;

extern FL64 BondBM_Accruint(DATESTR  *settle, 
                            BONDBM   *bond, 
                            HOLI_STR *holi) ;

extern BONDBM Set_BONDBM(BONDSEG    seg,
                     DATESTR*   matur,
                     FL64       coupon,
                     ODDCONV    stub_front,
                     DATESTR*   issue_nom,   
                     DATESTR*   first,
                     TAXINFO*   tax) ;

/* Private functions */


/*** routines in bondpf.c **********************************************/


/* Public functions */

extern CFLWARRAY Cflw_MergeXtraOrdCflw(DATESTR    *today,
                                           CFLW_STR   *cflw,
                                           PLAN_STR   *prep,
                                           PREPAYCONV prepayc,
                                           FL64       anncoup,
                                           PMTFREQ    pfreq,
                                           EXRULE     *excp,
                                           EXRULE     *expr,
                                           EXRULE     *expr_d,
                                           BOOLE      *exc,
                                           BOOLE      *exp,
                                           BOOLE      *expd);

extern PLANARRAY Bond_GenrXtraOrdAmort(TRADEINFO  *trd,
                                          FIXPAY     *fixp,
                                          PLAN_STR   *xredemp) ;

extern PLANARRAY Cflw_Amort2Prepay(PLAN_STR    *amort,
                                      PLAN_STR    *xamort,
                                      PREPAYCONV  prepayc,
                                      PMTFREQ     pfreq);

extern BOOLE Cflw_CheckAmortsInNewAmorts(PLAN_STR* amort,
                                    PLAN_STR* newamort);

/* Private functions */


#ifdef __cplusplus
}
#endif

#endif

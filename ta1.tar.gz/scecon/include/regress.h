#ifndef REGRESS_H
#define REGRESS_H

#include <sccsid.h>
SCCSID(regress_h,
  "@(#)regress.h	1.5 (SimCorp) 99/08/12 13:40:50")

/***** includes  *****************************************************/
#include <scecon.h>
#include <scutl.h>
#include <math.h>

/***** C++ Convenience ***********************************************/
#ifdef __cplusplus
extern "C" {
#endif

/*** General least squares regression using classes of functions *****/
/*

FUNCBASE : class of functions
-----------------------------

Class of base functions to be used in regression:

        typedef enum funcclass_tag
        {
          POWER,
          MULTIPOWER
        } FUNCBASE;

POWER: Powers of x.
y = a0 + a1 * x + a2 * x^2 + a3 * x^3 + ...

MULTIPOWER: Powers of x1, x2, ..., xk.
y = a0 + a1 * x1 + a2 * x2 + ... + ak * xk + ak+1 * x1^2 + ak+2 * x1 * x2 + ...

POWER is a special case (one dimensional) of MULTIPOWER. The one-dimensional
implementation is however faster than the general implementation.
*/
typedef enum funcclass_tag
{
  POWER,
  MULTIPOWER
} FUNCBASE;

/*** prototypes  (regress.c)  ****************************************/
/* Public functions */

extern void Stat_LeastSquaresRegress(FL64MATRIX  x, /* nobs x nfacs */
                              FL64ARRAY   y,
                              BOOLEARRAY  exclude,
                              INTI        nobs,
                              INTI        nfac,
                              FUNCBASE    fbase,
                              INTI        pow,
                              INTI        ncoef,
                              FL64ARRAY   coefs,
                              FL64        chisqacc,
                              INTI        maxiter,
                              FL64*       chisq,
                              INTI*       iter);

extern FL64 Stat_FuncVal(FL64ARRAY   x, /* nfac */
                  INTI        nfac,
                  FUNCBASE    fbase,
                  INTI        pow,
                  INTI        ncoef,
                  FL64ARRAY   coefs);

extern INTI Stat_CoefNo(FUNCBASE  fbase,
                        INTI      nfac,
                        INTI      pow);

/* Private functions */
extern void mrqmin(FL64MATRIX x, FL64ARRAY y, BOOLEARRAY  exclude, 
    INTI nobs, INTI nfac, INTI pow, FL64ARRAY a, 
    INTI ma, FL64 **covar, FL64 **alpha, FL64 *chisq,
    void (*funcs)(FL64ARRAY, INTI, INTI, FL64ARRAY, FL64 *, FL64ARRAY, INTI),
    FL64 *alamda);
extern void gaussj(FL64 **a, INTI n, FL64 **b, INTI m);
extern void mrqcof(FL64MATRIX x, FL64ARRAY y, BOOLEARRAY  exclude,
    INTI nobs, INTI nfac, INTI pow, FL64ARRAY a, 
    INTI ma, FL64 **alpha, FL64ARRAY beta, FL64 *chisq,
    void (*funcs)(FL64ARRAY, INTI, INTI, FL64ARRAY, FL64 *, FL64ARRAY, INTI));

INTI PascalsTriangle(INTI r, INTI c);

extern void basefunc_power(FL64ARRAY x, INTI nfac, INTI pow, FL64ARRAY a,
    FL64 *y, FL64ARRAY dyda, INTI na);
extern void basefunc_secondpower(FL64ARRAY x, INTI nfac, INTI pow, FL64ARRAY a,
    FL64 *y, FL64ARRAY dyda, INTI na);
extern void basefunc_multipower(FL64ARRAY x, INTI nfac, INTI pow, FL64ARRAY a,
    FL64 *y, FL64ARRAY dyda, INTI na);

/***** C++ Convenience ***********************************************/
#ifdef __cplusplus
}
#endif

#endif /* REGRESS_H */

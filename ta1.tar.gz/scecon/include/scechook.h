/* SCCS: @(#)scechook.h	1.13 (SimCorp) 99/10/28 11:43:28 */

#ifndef SCECHOOK_H_INCLUDED

#define SCECHOOK_H_INCLUDED

/**********************************************************************
*                                                                     *
*    Module          Hook                                             *
*                                                                     *
*    general    This file contains declarations, initializations,     *
*               type definitions and function prototyping for the     *
*               SCecon library                                        *
*                                                                     *
***********************************************************************
*/

/*** includes *********************************************************/
#include <builtin.h>
#include <stdio.h>

/***** C++ Convenience ************************************************/
#ifdef __cplusplus
extern "C" {
#endif

/*** SCecon documentation from ccover.h ******************************/

/*,,SOT,,

COUNT
-----

This basic SimCorp data type is defined as

        typedef int COUNT;

in the ccover.h file.
Note that a variable having type COUNT is understoud to be a counter 
and should therefore be non-negative.

,,EOT,,*/

/*,,SOT,,

INTI, INTIARRAY, INTIMATRIX, and INTIBOX
----------------------------------------

This basic SimCorp data type is defined as

        typedef int INTI ;

in the ccover.h file.

INTIARRAY is defined as:

        typedef INTI * INTIARRAY ;

in scechook.h.

INTIARRAY is used to handle list's of INTI's.

INTIMATRIX is defined as:

        typedef INTIARRAY * INTIMATRIX ;

in scechook.h

INTIBOX is defined as:

        typedef INTIMATRIX * INTIBOX ;

in scechook.h


,,EOT,,*/

/*,,SOT,,

INTL, INTLARRAY:
----------------

This basic SimCorp data type is defined as

        typedef long INTL ;
or
        typedef int INTL;

in the ccover.h file.

INTLARRAY is defined as:

        typedef INTL * INTLARRAY ;

in scechook.h.

INTLARRAY is used to handle list's of INTL's.

The actual setting depends on the environment (compiler and operating system).

,,EOT,,*/


/*,,SOT,,

TEXT, CH:
---------

This basic SimCorp data type is defined as

        typedef char CH ;
        typedef CH*  TEXT ;

in the ccover.h file.

,,EOT,,*/


/*,,SOT,,

BOOLE, BOOLEARRAY and BOOLEMATRIX
---------------------------------

Theis basic SimCorp data type is defined as

        typedef int BOOLE;

        enum { False=0, True=1 };

in the ccover.h file. A BOOLE can take on the value of False or True.

BOOLEARRAY is defined as:

        typedef BOOLE * BOOLEARRAY ;

in scechook.h.

BOOLEARRAY is used to handle list's of BOOLE's.

BOOLEMATRIX is defined as:

        typedef BOOLEARRAY * BOOLEMATRIX ;

in scechook.h.

,,EOT,,*/


/*,,SOT,,

FL64, FL64ARRAY, FL64MATRIX, and FL64BOX
----------------------------------------

This basic SimCorp data type is defined as

        typedef double FL64 ;

in the ccover.h file.

FL64ARRAY is defined as:

        typedef FL64 * FL64ARRAY ;

in scechook.h.

FL64ARRAY is used to handle list's of FL64's.


FL64MATRIX is defined as:

        typedef FL64ARRAY * FL64MATRIX ;

in scechook.h.

FL64BOX is defined as:

        typedef FL64MATRIX * FL64BOX ;

in scechook.h

FL64DIM4 is defined as:

        typedef FL64BOX * FL64DIM4 ;

in scechook.h


,,EOT,,*/
/*,,SOT,,

UN32, UN32ARRAY, UN32MATRIX:
----------------------------

This basic SimCorp data type is defined as

        typedef unsigned long UN32 ;
or
        typedef unsigned int UN32;

in the ccover.h file.
The actual setting depends on the environment (compiler and operating system).

UN32ARRAY is defined as:

        typedef UN32 * UN32ARRAY ;

in scechook.h.

UN32ARRAY is used to handle list's of UN32's.

UN32MATRIX is defined as:

        typedef UN32ARRAY * UN32MATRIX ;

in scechook.h.


,,EOT,,*/

typedef float     FL32 ;
typedef FL32      * FL32ARRAY ;
typedef FL64      * FL64ARRAY ;
typedef INTI      * INTIARRAY ;
typedef INTL      * INTLARRAY ;
typedef BOOLE     * BOOLEARRAY ;
typedef BOOLEARRAY * BOOLEMATRIX ;
typedef FL64ARRAY * FL64MATRIX ;
typedef INTIARRAY * INTIMATRIX ;
typedef UN32      * UN32ARRAY ;
typedef UN32ARRAY * UN32MATRIX ;
typedef INTIMATRIX  * INTIBOX ;
typedef FL64MATRIX * FL64BOX ;
typedef FL64BOX * FL64DIM4 ;



/*,,SOT,,

FILENAME
--------

This data type is defined as

     typedef TEXT    FILENAME ;

in the scechook.h file. This type is used for holding file names
(including paths).

,,EOT,,*/

typedef TEXT    FILENAME ;


/*** declarations used by the errorhandler routines *******************/

/* Used by SCecon_error() */
#define SCECONCONTINUE 0
#define SCECONABORT    1

/* Used by SCecon_printf() */
#define SCECONERROR    1
#define SCECONWARNING  2
#define SCECONPROGRESS  3

/* Used by SCecon_tryinterrupt() in
   addition to those of SCecon_printf() */
#define SCECONMESSAGE 4



/* sceerr.c */

/* Public functions */

/*** prototyping of the standard errorhandling routines ***************/

extern void SCecon_error(TEXT message,
                         TEXT routine,
                         INTI  action);
extern void SCecon_printf(INTI code,
                          TEXT format,
                          ...);
extern BOOLE SCecon_tryinterrupt(INTI  code,
                                 TEXT routine,
                                 TEXT format,
                                 ...);

/* scemem.c */

/* Public functions */

/*** prototyping of the standard memory handling routines *************/

extern VOIDPTR SCecon_calloc(INTI nh, size_t sizof, BOOLE doerr, TEXT fname) ;
extern void    SCecon_free(VOIDPTR v) ;


/* scefile.c */

/* Public functions */

/*** prototyping of the standard file handling routines ***************/

extern FILE* SCecon_fopen(FILENAME name, TEXT mode, BOOLE doerr) ;
extern INTI  SCecon_fclose(FILE *fptr, BOOLE doerr) ;

/*** prototyping of the standard string lib overriders ****************/


/* scemath.c */

/* Public functions */

/*** prototyping of the standard math lib overriders ******************/

extern FL64 SCecon_fabs(FL64 x) ;
extern FL64 SCecon_floor(FL64 x) ;
extern INTI SCecon_floori(FL64 x) ;
extern FL64 SCecon_ceil(FL64 x) ;
extern INTI SCecon_ceili(FL64 x) ;


/* Private functions */

/* scetext.c */

/* Public functions */

/*** prototyping of the standard string lib overriders ****************/

SCCONST char *SCecon_nullcheck(SCCONST char * s);
size_t SCecon_strlen(SCCONST char * s);
char *SCecon_strcpy(char* t, SCCONST char * s);
char *SCecon_strncpy(char * t, SCCONST char * s, size_t n);
char *SCecon_strncpyz(char * t, SCCONST char * s, size_t n);
char *SCecon_strcat(char * t, SCCONST char * s);
char *SCecon_strncat(char * t, SCCONST char * s, size_t n);
const char *SCecon_strchr(SCCONST char * s, int c);
const char *SCecon_strrchr(SCCONST char * s, int c);
size_t SCecon_strspn(SCCONST char * s1, SCCONST char * s2);
size_t SCecon_strcspn(SCCONST char * s1, SCCONST char * s2);
const char *SCecon_strpbrk(SCCONST char * s1, SCCONST char * s2);
int SCecon_strcmp(SCCONST char * s1, SCCONST char * s2);
int SCecon_strncmp(SCCONST char * s1, SCCONST char * s2, size_t l);
const void *SCecon_memchr(SCCONST void * s, int c, size_t l);
void *SCecon_memset(void * t, int c, size_t l);
void *SCecon_memcpy(void * t, SCCONST void * s, size_t l);
void *SCecon_memmove(void * t, SCCONST void * s, size_t l);
int SCecon_memcmp(SCCONST void * s1, SCCONST void * s2, size_t l);

/*** prototyping of APL II 386 memory necessities *********************/

#ifdef APLII_386

/* To avoid including aplext.h */
extern char * AplAlloc(size_t aplarg) ;
extern void   AplFree(void * aplarg) ;

#endif

#ifdef __cplusplus
}
#endif

#endif

#ifndef GENMACRO_H
#define GENMACRO_H
#include <sccsid.h>

/*
SCCSID(genmacro_h,
  "@(#)genmacro.h	1.1 (SimCorp) 97/06/25 15:57:20")
*/

/* ********************************************************************
 Macros to paste tokens together to form new NAMEs.
 The various compilers do not agree too much on this file
 so we do our own (SimCorp)

 ANSI C preprocessors will not expand the arguments to a macro;
 so we need to add a level of indirection to allow macro expansion of
 arguments.

 for the same reasons we need a stringize macro.
 it will enclose the value of X in "".
 ******************************************************************* */

#if !defined(NON_ANSI_PREPROC)
#  define NAME2(a,b)        X_NAME2(a,b)
#  define X_NAME2(a,b)      a ## b
#  define NAME3(a,b,c)      X_NAME3(a,b,c)
#  define X_NAME3(a,b,c)    a ## b ## c
#  define NAME4(a,b,c,d)    X_NAME4(a,b,c,d)
#  define X_NAME4(a,b,c,d)  a ## b ## c ## d
#  define STRINGIZE(X) X_STRINGIZE(X)
#  define X_STRINGIZE(X) # X
#else
#  define NAME2(a,b)    a/**/b
#  define NAME3(a,b,c)  a/**/b/**/c
#  define NAME4(a,b,c,d)    a/**/b/**/c/**/d
#  define STRINGIZE(X) "X"
#endif

#define DECLARE(a,t) NAME2(a,DECLARE)(t)
#define IMPLEMENT(a,t) NAME2(a,IMPLEMENT)(t)
#define DECLARE2(a,t1,t2) NAME2(a,DECLARE2)(t1,t2)
#define IMPLEMENT2(a,t1,t2) NAME2(a,IMPLEMENT2)(t1,t2)


#endif


/* SCCS: @(#)hwio.h	1.5 (SimCorp) 99/02/19 14:21:28 */

#ifndef HWIO_H
#define HWIO_H

/************************************************************************
*                                                                       *
*   project     SCecon                                                  *
*                                                                       *
*   file name   str2conv.h                                              *
*                                                                       *
*   general     This file contains the header file for the example code *
*               in str2conv.c                                           *
*                                                                       *
************************************************************************/

/*** includes **********************************************************/
#include <str2conv.h>
#include <hw.h>

#ifdef __cplusplus
extern "C" {
#endif

/*** prototypes  *******************************************************/

extern HWFIXPARM   Str2HWFIXPARM(TEXT txt) ;
extern HWFUNC      Str2HWFUNC(TEXT txt) ;

extern HWFIXPARM Read_HWFIXPARM(FILE *in, FILE *out, TEXT dscr);  
extern HWFUNC Read_HWFUNC(FILE *in, FILE *out, TEXT dscr);     

extern HWPARMS   Read_HWPARMS(FILE *in, FILE *out) ;
extern HWCFDIFF  Read_HWCFDIFF(FILE *in, FILE *out) ;
extern DKMBSMODEL Read_DKMBSMODEL(FILE *in, FILE *out) ;
extern KFDEBTORARRAY Read_KFDEBTORARRAY(FILE* in, FILE* out, INTI *nkf) ;
extern DKMBS      Read_DKMBS(FILE *in, FILE *out) ;
extern NCSWAPTION Read_NCSWAPTION(FILE* in, FILE* out) ;
extern CCSWAPTION Read_CCSWAPTION(FILE* in, FILE* out) ;
extern USBONDOPT  Read_USBONDOPT(FILE* in, FILE* out) ;
extern HWCMTMODL  Read_HWCMTMODL(FILE* in, FILE* out);
extern CHVPARMS   Read_CHVPARMS(FILE* in, FILE* out) ;
extern HWFITVOLCTRL Read_HWFITVOLCTRL(FILE* in, FILE* out);

extern INTI Write_HWBOOTRESdiff(FILE* out, HWBOOTRES* hbr, 
         INTI nsec, BOOLE okexp, PLAN_STR* vol, FL64 acc1);
extern Write_HWCFdiff(FILE* out, BOOLE ok, HWCFPARMS* hwc, 
    FL64 obj, BOOLE okexp, FL64 fexp, FL64 fexp1, FL64 acc);



#ifdef __cplusplus
}

#endif

#endif





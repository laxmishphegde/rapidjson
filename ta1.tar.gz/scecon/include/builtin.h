#ifndef BUILTIN_H
#define BUILTIN_H

#include <sccsid.h>

/*
SCCSID(builtin_h,
  "@(#)builtin.h	1.1 (SimCorp) 97/06/25 15:57:12")
*/

#include <scansi.h>
#include <ccover.h>

#endif

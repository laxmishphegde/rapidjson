/* SCID @(#)option.h	1.29 (SimCorp) 99/07/21 17:20:39 */

#ifndef OPTION_H
#define OPTION_H

/************************************************************************
*                                                                       *
*    project    SCecon                                                  *
*                                                                       *
*    filename   option.h                                                *
*                                                                       *
*    this file contains definitions and function prototyping for the    *
*    routines in the SCecon option pricing module.                      *
*                                                                       *
************************************************************************/

/*** includes **********************************************************/
#include <vol.h>
#include <disc.h>
#include <float.h>

/***** C++ Convenience *************************************************/
#ifdef __cplusplus
extern "C" {
#endif

/*** typedefs **********************************************************/

/*,,SOT,,

OPTTYPE : data type for option type
-----------------------------------

The distinction between option types in the SCecon Library is
made using the data type OPTTYPE defined as

        typedef enum opttype_tag
        {
            CALL,
            PUT,
            STRADDLE
        }   OPTTYPE ;

Call options give you the right to buy an asset at some time (interval)
in the future at conditions agreed of today, while put options give you
the right to sell the asset.

A straddle is a portfolio where a call and a put option are purchased at
the same strike levels and maturity dates.

,,EOT,,*/

typedef enum opttype_tag
{
    OPTTYPE_INIT = -1,
    CALL,
    PUT,
    STRADDLE
}   OPTTYPE ;


/*,,SOT,,

PAYOFF : data type for pay-off function for options
---------------------------------------------------

This data type is defined as:

        typedef enum payoff_tag
        {
            OP_VANILLA,
            OP_BINARY,
            OP_ASSETON,
            OP_GAP
        }   PAYOFF ;

OP_VANILLA indicates a standard option with the usual pay-off pattern, i.e.

        0 if F < X    and    F - X  if F >= X      (CALL)
        0 if F > X    and    X - F  if F <= X      (PUT)

for a vanilla option with strike X and F the value of the underlying
asset.

OP_BINARY indicates a binary or digital payoff pattern,

        0 if F < X    and    B  if F >= X          (CALL)
        0 if F > X    and    B  if F <= X          (PUT)

for a binary option, where B is the amount payed out upon exercise of
the option.

OP_ASSETON indicates an Asset-Or-Nothing option, with payoff defined as:

        0 if F < X    and    S * F  if F >= X      (CALL)
        0 if F > X    and    S * F  if F <= X      (PUT)

Where S is a scale factor.

OP_GAP is a Gap option with payoff defined as:

        0 if F < X    and    F - X - Gap  if F >= X    (CALL)
        0 if F > X    and    X - F - Gap  if F <= X    (PUT)

Where Gap can be positive or negative. Clearly if the Gap is 0 then the
option is a vanilla option. If Gap is -X then it is equal to an
Asset-Or-Nothing option. If Gap is positive then a Gap Option can be used
to describe a CONTINGENT PREMIUM option, where the Gap is the contingent
premium.

,,EOT,,*/

typedef enum payoff_tag
{
    PAYOFF_INIT = -1,
    OP_VANILLA,
    OP_BINARY,
    OP_ASSETON,
    OP_GAP
}   PAYOFF ;


/*,,SOT,,

PREMIUMTYPE : data type for premium payment arrangements
--------------------------------------------------------

The premium types for options are defined in the SCecon Library as

        typedef enum premium_tag
        {
            UP_FRONT,
            BY_MARGIN
        }   PREMIUMTYPE ;

If the premium type is UP_FRONT, the premium is paid up front, i.e. when
the options are bought, while the premium is paid at expiry for options
with premium type BY_MARGIN.

The information about premium type has impact on the way the future
expected pay off from the option at expiry is discounted when computing
the theoretical prices - and risk ratios - for options.

,,EOT,,*/

typedef enum premium_tag
{
    PREMIUMTYPE_INIT = -1,
    UP_FRONT,
    BY_MARGIN
}   PREMIUMTYPE ;


/*,,SOT,,

BINTREE, BINTREEARRAY : data types concerning the binomial lattices
-------------------------------------------------------------------

This data type is used for handling binomial trees in general. These trees
include the CRR (Cox, Ross and Rubinstein) model or the BDT (Black, Derman and
Toy) interest rate model.

In the SCecon Library, this binomial lattice is represented by the data
type BIN_TREE, defined as

        typedef struct
        {
            INTI      nlevel ;
            FL64ARRAY time ;
            FL64ARRAY f64 ;
            FL64ARRAY scale ;
        }   BINTREE ;

The informations in the BINTREE data type are

        nlevel  number of levels in the tree. Ie. the levels are -
                0, 1, ..., nlevel.

        time    time[nlevel+1] is the time in fractional years

        f64     f64[nlevel+1] is the rate or price in state 0

        scale   scale[nlevel+1] is the scale factor - for scaling
                f64[nlevel+1] on a given level (time).

For lists of BINTREE's a type has been defined as:

        typedef BINTREE * BINTREEARRAY ;

For more information on the use of the BINTREE data type, consult the
chapter Functions Reference below.

,,EOT,,*/


typedef struct
{
    INTI      nlevel ;
    FL64ARRAY time ;
    FL64ARRAY f64 ;
    FL64ARRAY scale ;
} BINTREE ;

typedef BINTREE * BINTREEARRAY ;


/*,,SOT,,

OPTADD : Type for defining additional option data
-------------------------------------------------

This enumeration is defined in as:

        typedef enum optadd_tag
        {
            NO_OPTADD,
            CHOOSER,
            LOOKBACK,
            ASIAN,
            BARRIER,
            FWDSTART,
            TOUCHDIG,
            BINARY,
            CONTPREM,
            COMPOPT,
            DOUBLKO,
            RESET,
            SWPTBARR,
            SHARKFIN,
            LADDER,
            TSWITCH,
            CORRIDOR,
            FLEXICAP
        }   OPTADD ;

The enumerations stand for:

NO_OPTADD indicates that the terms of the options do not include any of
the following additional attributes.

CHOOSER indicates a simple chooser option.

LOOKBACK signals a lookback style exercise.

ASIAN defines an average-rate option (otherwise called Asian Option).

BARRIER indicates a single barrier knock-out / knock-in option.

FWDSTART is a forward starting option - where the strike level is fixed
at some future date.

TOUCHDIG stands for a One-Touch Digital options where the payout is a
fixed amount provided the underlying variable hits a certain level in a
given period, or if it does not hit the given level.

BINARY indicates a binary option - i.e an option having payoff as
OP_BINARY, OP_ASSETON or OP_GAP.

CONTPREM is a contingent premium option, where the premium is only paid if
the option expires in the money.

COMPOPT defines a compound option, i.e. an option on an option.

DOUBLKO defines a double barrier knock out option.

RESET can only be used with caps; it defines reset or periodic caps.

SWPTBARR defines a barrier swaption.

SHARKFIN defines a barrier option where the barrier is only active on 
the actual expiry date of the option (as for certain barrier caps, referred
to as sharkfin caps).

LADDER defines a ladder option.

TSWITCH defines a time switch option with discrete observation of the 
underlying.

CORRIDOR defines a corridor with discrete observation of the underlying.

FLEXICAP defines a cap/floor on which only a subset of options can be
exercised.

These additional terms for options are all independent, i.e. no barriers
on average rate options.

OPTADD is used to define various 'Exotic' features for options. Currently
this works for options on Equities, Currencies and Commodities - formulated
in the spot price.

,,EOT,,*/

typedef enum optadd_tag
{
    OPTADD_INIT = -1,
    NO_OPTADD,
    CHOOSER,
    LOOKBACK,
    ASIAN,
    BARRIER,
    FWDSTART,
    TOUCHDIG,
    BINARY,
    CONTPREM,
    COMPOPT,
    DOUBLKO,
    RESET,
    SWPTBARR,
    SHARKFIN,
    LADDER,
    TSWITCH,
    CORRIDOR,
    FLEXICAP
}   OPTADD ;


/*,,SOT,,

KNOCKTYPE : Type for defining barrier option type
-------------------------------------------------

This type is defined as:

        typedef enum knocktype_tag
        {
            UP_IN,
            UP_OUT,
            DOWN_IN,
            DOWN_OUT
        }   KNOCKTYPE ;

UP_IN signals an up and in (knock-in) barrier option

UP_OUT signals an up and out (knock-out) barrier option

DOWN_IN signals a down and in (knock-in) barrier option

DOWN_OUT signals a down and out (knock-out) barrier option

,,EOT,,*/

typedef enum knocktype_tag
{
    KNOCKTYPE_INIT = -1,
    UP_IN,
    UP_OUT,
    DOWN_IN,
    DOWN_OUT
}   KNOCKTYPE ;


/*,,SOT,,

PAYOFFINF : Data type for holding info on payoff profiles
---------------------------------------------------------

This type is defined as:

        typedef struct payoffinf_tag
        {
            PAYOFF poff ;
            FL64   gap ;
            FL64   scale ;
        }   PAYOFFINF ;

where:

        poff is the payoff function:

        poff         gap          scale           Call Payoff
        ----         ---          -----           -----------
        OP_BINARY    Digital Pay  Not Used        Gap         F >= X
        OP_VANILLA   Not Used     Not Used        F - X       F >= X
        OP_ASSETON   Not Used     Scale factor    Scale * F   F >= X
        OP_GAP       Gap size     Not Used        F - X - Gap F >= X

        gap and scale defines elements of the payoff profile - as shown
        above

        For caps 'gap' for 'OP_BINARY' means the DOLLAR PAY-OFF for each
        caplet - given as a percentage of cap notional. This pay-off is 
        NOT scaled with the cap period day-count fraction (for binary
        caps day-count scaling is possible, see BINARYINF).
        In contrast, 'gap' for 'OP_GAP' is the number of percentage points 
        to subtract from the vanilla pay-off. In this case the gap IS scaled
        with the day-count fraction.
        (For 'OP_GAP' with the gap given as a dollar amount use 'CONTPREM'.)

see also Set_PAYOFFINF

,,EOT,,*/

typedef struct payoffinf_tag
{
    PAYOFF poff ;
    FL64   gap ;
    FL64   scale ;
}   PAYOFFINF ;


/*,,SOT,,

BARRIERINF : Type for defining barrier option data
--------------------------------------------------

This type is defined as:

        typedef struct barrierinf_tag
        {
            KNOCKTYPE btype ;
            FL64      barrier ;
            FL64      rebate ;
            BOOLE     phit ;
            PAYOFFINF poff ;
            PERIOD    monit ;
        }   BARRIERINF ;

The data interpretation is:

        knock_in, defines the knock in/out type

        barrier defines the barrier level

        rebate defines the rebate being paid if knock-out's are knocked
        out or the rebate being paid for knock-in's that expire without
        breaching the barrier.
        For IN options the rebate is paid at expiry, for OUT options the
        rebate is paid when the barrier is breached (at hit) or at expiry
        depending on phit.

        phit is True if the rebate is received when the barrier is hit, and
        False if the rebate is received at expiry.
        For IN options the rebate is paid at expiry, for OUT options the
        rebate can be paid at hit or at expiry.

        poff defines the payoff structure.

        monit for a DISCRETELY MONITORED barrier enter monit should be
        the period between looks. For a CONTINUOUSLY MONITORED barrier
        monit.num should be set to zero. Discretely monitored barriers
        are analysed as in Broadie, Glasserman and Kou (1995)

Using these data the barrier is monitored continuously.

see also Set_BARRIERINF

,,EOT,,*/

typedef struct barrierinf_tag
{
    KNOCKTYPE btype ;
    FL64      barrier ;
    FL64      rebate ;
    BOOLE     phit ;
    PAYOFFINF poff ;
    PERIOD    monit ;
}   BARRIERINF ;

/*,,SOT,,

LADDERINF : Type for defining ladder option data
------------------------------------------------

This type is defined as:

        typedef struct ladderinf_tag
        {
            FL64ARRAY levels ;
            INTI      nlevels ;
        }   LADDERINF ;

The data interpretation is:

        levels[nlevels] defines the rungs in a ladder option

        nlevels defines the number of rungs

Using these data the ladder is monitored continuously.
A call ladder has a pay-off of the form:

  Max(Max(S_T, L1,..., Ln) - K, 0)

where S_T defines the price of the underlying at maturity,
L1,...,Ln defines the n rungs and K denotes the strike.
A put ladder has a pay-off of the form:

  Max(K - min(S_T, L1,..., Ln), 0)

see also Set_LADDERINF

,,EOT,,*/

typedef struct ladderinf_tag
{
    FL64ARRAY levels ;
    INTI      nlevels ;
}   LADDERINF ;


/*,,SOT,,

TSWITCHINF : Type for defining time-switch option data
------------------------------------------------------

This type is defined as:

        typedef struct tswitch_tag
        {
            DATESTR   dobs1 ;
            DATESTR   dobsN ;
            INTI      num_obs ;
            FL64      level ;
            PLAN_STR  *step_strike ;
            FL64      curr_pay ;
        }   TSWITCHINF ;

The data interpretation is:

        dobs1 is the first observation date

        dobsN is the last observation date

        num_obs is the number of observations. Only discrete
        time monitoring of the underlying is allowed. This 
        variable should contain the number of times the 
        underlying is observed in the interval from dobs1 to 
        dobsN (including both observations). This number 
        should in principle be larger than 1 but in the case
        n = 1 \Delta t is set to 1 (a digital option with
        unit pay-off).

        level defines the strike/switch level. 

        step_strike defines a structure of date and strike/switch 
        level pairs.

        curr_pay is the unit notional pay-off gained up to the next
        observation date. Hence if the option is valued before dobs1
        this variable should contain 0.0 and otherwise the accumulated
        value up to the next observation date relative to the 
        valuation date.

With discrete time observations a time switch option has a 
pay-off of the form:

  A sum_{i=0}^{num_obs-1} I_[S_{t_i} > K_{t_i}] \Delta t

where A defines the contract size, K_{t_i} is the strike level
at time t_i, S_{t_i} is the price of the underlying at time t_i 
and I_[.] is an indicator function taking the value 1 if the
condition is fullfilled and 0 otherwise.

Similar with continuous time observations the pay-off is

  A int_{t_0}^{t_n} I_[S_{u} > K_{u}] du

Note that care should be taken if the price is determined after
t_0 since the pay-off then is depended upon previous observations.

See also:

Andreas Pechtl. "Classified Information", Risk Magazine vol. 8 
no. 6, 1995.

Exotic Options, SimCorp Working Paper, MGH-98-10.

see also Set_TSWITCHINF

,,EOT,,*/

typedef struct tswitch_tag
{
      DATESTR   dobs1 ;
      DATESTR   dobsN ;
      INTI      num_obs ;
      FL64      level ;
      PLAN_STR  *step_strike ;
      FL64      curr_pay ;
}   TSWITCHINF ;


/*,,SOT,,

CORRIDORINF : Type for defining corridor option data
----------------------------------------------------

This type is defined as:

        typedef struct corridor_tag
        {
            DATESTR   dobs1 ;
            DATESTR   dobsN ;
            INTI      num_obs ;
            FL64      upper ;
            FL64      lower ;
            PLAN_STR  *ustep_strike ;
            PLAN_STR  *lstep_strike ;
            FL64      curr_pay ;
        }   CORRIDORINF ;

The data interpretation is:

        dobs1 is the first observation date

        dobsN is the last observation date

        num_obs is the number of observations. Only discrete
        time monitoring of the underlying is allowed. This 
        variable should contain the number of times the underlying 
        is observed in the interval from dobs1 to dobsN (including
        both observations). This number should in principle be 
        larger than 1 but in the case n = 1 \Delta t is set to 1 
        (a digital option with unit pay-off).

        upper defines the upper strike/switch level of the range. 

        lower defines the lower strike/switch level of the range. 

        ustep_strike defines a structure of date and strike/switch 
        level pairs refering to the upper level of the range.

        lstep_strike defines a structure of date and strike/switch 
        level pairs refering to the lower level of the range.

        curr_pay is the unit notional pay-off gained up to the next
        observation date. Hence if the option is valued before dobs1
        this variable should contain 0.0 and otherwise the accumulated
        value up to the next observation date relative to the 
        valuation date.

With discrete time observations a corridor option has a 
pay-off of the form:

  A sum_{i=0}^{num_obs - 1} I_[K1_{t_i} < S_{t_i} < K2_{t_i}] \Delta t

where A defines the contract size, K1_{t_i} and K2_{t_i} is 
respectively the lower and upper corridor bound, S_{t_i} is 
the price of the underlying at time t_i and I_[.] is an indicator 
function taking the value 1 if the condition is fullfilled and 
0 otherwise. Note that the pay-off can be replicated using time-switch
options, namely

  A sum_{i=0}^{num_obs - 1} I_[S_{t_i} > K1_{t_i}] \Delta t -
  A sum_{i=0}^{num_obs - 1} I_[S_{t_i} > K2_{t_1}] \Delta t

Similar with continuous time observations the pay-off is

  A int_{t_0}^{t_n} I_[K1_{t_i} < S_{t_i} < K2_{t_i}] dt =
  A int_{t_0}^{t_n} I_[S_{t_i} > K1_{t_i}] dt -
  A int_{t_0}^{t_n} I_[S_{t_i} > K2_{t_1}] dt 

Again the pay-off can be replicated using time-switch options.
Note that care should be taken if the price is determined after
t_0 since the pay-off then is depended upon previous observations.

see also Set_CORRIDORINF

,,EOT,,*/

typedef struct corridor_tag
{
      DATESTR   dobs1 ;
      DATESTR   dobsN ;
      INTI      num_obs ;
      FL64      upper ;
      FL64      lower ;
      PLAN_STR  *ustep_strike ;
      PLAN_STR  *lstep_strike ;
      FL64      curr_pay ;
}   CORRIDORINF ;


/*,,SOT,,

SHARKFININF : Type for defining ('sharkfin' or 'European')  option data
--------------------------------------------------------------

This type is defined as:

        typedef struct sharkfininf_tag
        {
            KNOCKTYPE btype ;
            FL64      barrier ;
            FL64      rebate ;
            PAYOFFINF poff ;
        }   SHARKFININF ;

The data interpretation is:

        knock_in, defines the knock in/out type

        barrier defines the barrier level

        rebate defines the rebate being paid for EACH caplet if 
        knock-out's are knocked out or the rebate being paid for 
        knock-in's that expire without breaching the barrier.
        The rebate is paid at expiry.
        The rebate is quoted as a percentage of notional.

        poff defines the payoff structure.

Using these data the barrier is monitored only at option expiry.
Since the barrier can only be breached when expiring, it makes no
difference whether the rebate is paid at expiry or when the barrier
is breached. This is different from barrier options defined by
BARRIERINF.

see also Set_SHARKFININF

,,EOT,,*/

typedef struct sharkfininf_tag
{
    KNOCKTYPE btype ;
    FL64      barrier ;
    FL64      rebate ;
    PAYOFFINF poff ;
}   SHARKFININF ;


/*,,SOT,,

ASIANINF : Type for defining Asian option data
----------------------------------------------

This type is defined as:

        typedef struct asianinfo_tag
        {
            DATESTR  davg1 ;
            DATESTR  davgN ;
            INTI     num_avg ;
            FL64     curr_avg ;
            BOOLE    avgrt ;
            FL64     last_avg ;
        }   ASIANINF ;

The data interpretation is:

        davg1 is the first averaging date

        davgN is the last averaging date

        num_avg is the number of averaging days. Consequently discrete
        time monitoring of the average is allowed. Only used for
        average-rate options.

        curr_avg is the current average amount. Before and on davg1
        it is 0.0, and in the period it is the current average.

        avgrt is True is the option is an average-rate option, False
        imply an average-strike option.

        last_avg is the previous average found. Only used for 
        seasoned Caps.

Average-rate options have payoffs as:

        CALL: max[ Avg(Si) - X, 0 ]
        PUT:  max[ X - Avg(Si), 0 ]

Average-strike options have payoffs as:

        CALL: max[ S(T) - Avg(Si), 0 ]
        PUT:  max[ Avg(Si) - S(T) , 0 ]

where Si is the underlying variable, X is the strike and S(T) is the
price at maturity.

In a 'Black-model' type of environment we used Michael Curran's approach
for average-rate options (Curran: 'Beyond Average Intelligence', Risk, 
Vol 5, No. 10, Nov 1992) and Bouaziz et.al. for average-strike options 
(Bouaziz, Briys, and Crouhy: 'The pricing of forward starting asian options', 
Journal of Banking and Finance, 18, 1994). The latter approach assumes 
continuous averaging, whereas the former allow discrete time sampling.

see also Set_ASIANINF

,,EOT,,*/

typedef struct asianinfo_tag
{
    DATESTR  davg1 ;
    DATESTR  davgN ;
    INTI     num_avg ;
    FL64     curr_avg ;
    BOOLE    avgrt ;
    FL64     last_avg ;
}   ASIANINF ;


/*,,SOT,,

FWDSTARTINF : Type for defining Forward Start Option data
---------------------------------------------------------

This type is defined as:

        typedef struct
        {
            DATESTR dset ;
            FL64    alpha ;
        }   FWDSTARTINF ;

where

        dset is the data where the strike level is set

        alpha is the factor on the spot rate at the strike fixing date

Forward start options have vanilla payoff functions.

NOTE that forward starting options (in SCecon) currently only handles
the case when the underlying variable is the spot price (FX, bond or
equity related prices).

see also Set_FWDSTARTINF

,,EOT,,*/

typedef struct
{
    DATESTR dset ;
    FL64    alpha ;
}   FWDSTARTINF ;


/*,,SOT,,

CHOOSERINF : Type for defining Chooser Option data
--------------------------------------------------

This type is defined as:

        typedef struct
        {
            DATESTR dchoose ;
        }   CHOOSERINF ;

where

        dchoose is the data where the decision must be made whether the
        option is a call or a put.

Chooser options have vanilla payoff functions.

see also Set_CHOOSERINF

,,EOT,,*/

typedef struct
{
    DATESTR dchoose ;
}   CHOOSERINF ;


/*,,SOT,,

TOUCHDIGINF : Type for defining One-Touch Digital Option data
-------------------------------------------------------------

This type is defined as:

        typedef struct touchdiginf_tag
        {
            KNOCKTYPE btype ;
            FL64      barrier ;
            BOOLE     phit ;
            PAYOFFINF poff ;
        }   TOUCHDIGINF ;

where:

        btype is the definition of how the payout will occur

              UP_IN    - Payout if underlying crosses 'barrier'
                         Payment either at hit or at expiry
              DOWN_IN  - Payout if underlying crosses 'barrier'
                         Payment either at hit or at expiry
              UP_OUT   - Payout (at expiry) if 'barrier' never breached
              DOWN_OUT - Payout (at expiry) if 'barrier' never breached

        barrier is the critical level that defines whether payout will
        occur

        phit is True if the payout is received when the barrier is hit, and
        False if the payout is received at expiry. If phit is True then
        btype must an 'IN'-type.

        poff defines the payoff function.

see also Set_TOUCHDIGINF

,,EOT,,*/

typedef struct touchdiginf_tag
{
    KNOCKTYPE btype ;
    FL64      barrier ;
    BOOLE     phit ;
    PAYOFFINF poff ;
}   TOUCHDIGINF ;


/*,,SOT,,

LOOKBACKINF: type for defining data for lookback options
--------------------------------------------------------

This type is defined as:

        typedef struct lookbackinf_tag
        {
            FL64  xtrem ;
            BOOLE lbrate ;
        }   LOOKBACKINF ;

where the data should be interpreted as:

        xtrem is the current extreme during the previous life of the
        option. Just enter 0 before or at option start.

        if lbrate is True then the option is an lookback rate option, if
        False it is a lookback strike option.

Payoffs are:

        Type              Option type    Payoff
        ----              -----------    ------
        Strike Lookback   CALL           Max[S(T) - Min{S(t)}, 0]
        Strike Lookback   PUT            Max[Max{S(t)} - S(T), 0]
        Rate Lookback     CALL           Max[Max{S(t)} - X, 0]
        Rate Lookback     PUT            Max[X - Min{S(t)}, 0]

where X is the strike.

see also Set_LOOKBACKINF

,,EOT,,*/

typedef struct lookbackinf_tag
{
    FL64  xtrem ;
    BOOLE lbrate ;
}   LOOKBACKINF ;


/*,,SOT,,

BINARYINF: type for defining data for binary / digital options
--------------------------------------------------------------

This type is defined as:

        typedef struct binaryinf_tag
        {
            PAYOFFINF poff ;
            BOOLE     dcadj;
        }   BINARYINF ;

where

        poff is the payoff structure.

        dcadj marks whether the pay-off should be day-count
        fraction adjusted.
        This field only applies for caplets (floorlets).
        If true, a quarterly binary caplet will pay-off
        approximately one quarter (depending on the day count
        convention) of the pay-off given in poff.

see also Set_BINARYINF

,,EOT,,*/

typedef struct binaryinf_tag
{
    PAYOFFINF poff ;
    BOOLE     dcadj;
}   BINARYINF ;


/*,,SOT,,

CONTPREMINF: type for defining data contingent premium options
--------------------------------------------------------------

This type is defined as:

        typedef struct contpreminf_tag
        {
            FL64 prem ;
        }   CONTPREMINF ;

where

        prem is the premium that are paid (contingent upon) the option
        expiring in the money

when solving for the contingent premium - use the relevant implied routine
and solve for KEY_GAP, with 0.0 (up front) premium as target. 

Note that for a contingent premium CAP the contingent premium is the DOLLAR 
amount (given as a percentage of cap notional) to paid for EACH caplet which 
expires in the money. This amount will NOT be scaled with the cap period
day-count fraction. (For the contingent premium given as a number of 
percentage points to subtract from the vanilla pay-off and scaled by the
day-count fraction use a 'BINARY' with 'OP_GAP' pay-off.)

see also Set_CONTPREMINF

,,EOT,,*/

typedef struct contpreminf_tag
{
    FL64 prem ;
}   CONTPREMINF ;


/*,,SOT,,

COMPOPTINF: type for defining compound options
----------------------------------------------

This type is defined as:

        typedef struct compoptinf_tag
        {
            OPTTYPE type ;
            DATESTR matur ;
            FL64    strike ;
        }   COMPOPTINF ;

where the data have the following interpretation:

        type is the option type of the compound option (PUT or CALL)

        matur is the maturity date of the compound option

        strike is the strike price of the compound option

these data defines the terms for the option on the option, ie not the 
underlying option. Therefore, strike is in terms of 'vanilla option 
premium' and matur must be before the exercise date of the underlying
option as is defined directly on OPTFUT or SWAPTION.

see also Set_COMPOPTINF

,,EOT,,*/

typedef struct compoptinf_tag
{
    OPTTYPE type ;
    DATESTR matur ;
    FL64    strike ;
}   COMPOPTINF ;


/*,,SOT,,

DOUBLKOINF: Data for defining double knock-out options.
------------------------------------------------------

This type is defined as:

        typedef struct doublko_tag
        {
            FL64      b1 ;
            FL64      b2 ;
            PERIOD    monit ;
            PAYOFFINF poff ;
            BOOLE     rebates ;
            FL64      r1 ;
            BOOLE     phit1 ;
            FL64      r2 ;
            BOOLE     phit2 ;
        }   DOUBLKOINF ;

where

        b1: the lower barrier,

        b2: the upper barrier (b1 < b2, otherwise 0.0 is returned)

        monit: for a DISCRETELY MONITORED barrier enter monit should be
          the period between looks. For a CONTINUOUSLY MONITORED barrier
          monit.num should be set to zero. Discretely monitored barriers
          are analysed as in Broadie, Glasserman and Kou (1995)

        poff: defines the payoff function.

        rebates: 'True' means option has rebates - 'False' means no rebates
          If 'False' rebate info (below) will NOT be accessed

        r1: the rebate for the lower barrier

        phit1: 'True' means r1 is paid at at the time of penetration
          'False' means r1 is paid out at option expiry (if barrier 
                  was penetrated)
          
        r2: is the rebate for the upper barrier

        phit2: 'True' means r2 is paid at at the time of penetration
          'False' means r2 is paid out at option expiry (if barrier 
                  was penetrated)

The option knocks out if one of the barriers are hit, during option life.
If the option is knocked out by the upper (lower) barrier a cash 
  rebate of r2 (r1) is paid out immediately/at option expiry iff 
  phit2 (phit1) is true/false.

see also Set_DOUBLKOINF

,,EOT,,*/

typedef struct doublko_tag
{
  FL64      b1 ;
  FL64      b2 ;
  PERIOD    monit ;
  PAYOFFINF poff ;
  BOOLE     rebates ;
  FL64      r1 ;
  BOOLE     phit1 ;
  FL64      r2 ;
  BOOLE     phit2 ;
} DOUBLKOINF ;


/*,,SOT,,

RESETINF: Type for holding reset info on reset (periodic) caps
------------------------------------------------------------------

The type is defined as:

        typedef struct resetinf_tag
        {
            FL64    spread ;
            INTI    nfirst ;
            INTI    nfreq ;
            BOOLE   delayfix ;
            FL64    spread_low ;
            FL64    spread_up ;
        }   RESETINF ;

The data have the following interpretation:

        spread is added to the fixing to obtain the strike.
        Range: floating point number

        the first reset occurs on the nfirst fixing day
        - this resets the strike for the nfirst + 1 fixing
        nfirst has zero offset so first fixing is number 0
        Range: non-negative integer

        subsequent resets occur on every nfreq'th fixing day
        Range: positive integer
    
        delayfix controls how the strike is reset. If delayfix is False,
        the option is an ordinary reset cap where the next strike is 
        calculated as 

                  'current fixing' + spread

        If delayfix is True, the next strike is calculated as  

          MIN(MAX('previous fixing' + spread_low, 'current fixing' + spread),
                  'previous fixing' + spread_up)

        If delayfix is True, spread_low denotes the spread added to the 
        previous fixing to obtain minimum strike. If delayfix is False, 
        spread_low is not used.

        If delayfix is True spread_up denotes the spread added to the 
        previous fixing to obtain maximum strike. If delayfix is False,
        spread_up is not used.

see also Set_RESETINF

,,EOT,,*/

typedef struct resetinf_tag
{
    FL64    spread ;
    INTI    nfirst ;
    INTI    nfreq ;
    BOOLE   delayfix ;
    FL64    spread_low ;
    FL64    spread_up ;
}   RESETINF ;


/*,,SOT,,

OPTFUT, OPTFUTARRAY : Type for defining data for options
--------------------------------------------------------

This type is defined in as:

        typedef struct optfut_tag
        {
            OPTTYPE     type ;
            FL64        strike ;
            DATESTR     dfix ;
            DATESTR     dpay ;
            PREMIUMTYPE ptype ;
            CALCONV     cal ;

            OPTADD      oadd ;
            CHOOSERINF  chos ;
            LOOKBACKINF lbi ;
            BARRIERINF  barr ;
            ASIANINF    asian ;
            FWDSTARTINF fwdst ;
            TOUCHDIGINF tdi ;
            BINARYINF   bini ;
            CONTPREMINF ctp ;
            COMPOPTINF  compo ;
            DOUBLKOINF  dko ;
            LADDERINF   lad ;
            TSWITCHINF  tswi ;
            CORRIDORINF cor;
        }   OPTFUT  ;

The data is used for describing European style options, and have the
following interpretations:

These first data are basic data for the option:

        type is the option type CALL, PUT or STRADDLE.

        strike is the option strike price.
        For Bond options quoted in % of underlying bond.
        For Stock Options and Warrant's the strike is quoted
        in Currency Units.
        For FX options: CALL -- PUT CCY  / CALL CCY
                        PUT  -- CALL CCY / PUT  CCY
        (eqv to: Domestic Currency per Foreign Currency Unit).

        dfix is the fixing data for the option (last trading day).

        dpay is day on which any payout occur (dfix <= dpay). I.e. the
        future is delivered or cash is settled.

        ptype is the premiumtype

        cal is the calendar used to find the term till fixing and payment.

In addition to these basic features some ADDITIONAL terms and conditions
can be invoked: (not implemented as union due to APL-Interface).

        oadd indicates whether additional features are used. Default is
        NO_OPTADD. If oadd is not NO_OPTADD some 'exotic' option features
        can be defined as follows:

        oadd = CHOOSER:
        chos is invoked if oadd is CHOOSER. type is not used.

        oadd = LOOKBACK:
        lbi defines the data.
        Continuous monitoring is assumed.

        oadd = BARRIER:
        barr defines for Barrier options the data needed.

        oadd = ASIAN:
        asian defines the data needed for asian (average-rate) options.
        It is assumed that dfix = asian.davgN

        oadd = FWDSTART:
        fwdst defines the data needed for forward start options.
        strike is not used. ptype is UP_FRONT.

        oadd = TOUCHDIG:
        tdi defines one-touch digital options.
        ptype is UP_FRONT. type and strike are not used.

        oadd = BINARY:
        bini defines a binary option

        oadd = CONTPREM:
        ctp defines a contingent premium option

        oadd = COMPOPT:
        compo defines a compound option. Here the data in compo defines
        the data of the option that strikes first of the 2 options.
        I.e. the compound option.

        oadd = DOUBLKO:
        dko defines the 2 (K/O) barriers for the option.

        oadd = LADDER:  
        lad defines a ladder option.

        oadd = TSWITCH:
        tswi defines a time switch option

        oadd = CORRIDOR:
        cor defines a corridor option

Whenever oadd is not NO_OPTADD then the Black-model used must be based on
spot prices (and not forward prices of the underlying).

This type is used to describe options on

        Bonds                 -   optBond_black2*()
        Bond Futures          -   optFutBond_black2*()
        Bond Futures          -   optFutBond_HWCF2*()
        FX Spot               -   optFX_black2*()
        FX Forwards           -   optFutFX_black2*()
        Commodities           -   optCmdty_black2*()
        Commodities Forwards  -   optFutCmdty_black2*()
        Equities              -   optEqty_black2*()
        Equity Forwards       -   optFutEqty_black2*()
        Stock Indices         -   optEqty_black2*()
        Stock Indices Futures -   optFutEqty_black2*()
        Warrants              -   optEqty_black2*()

List's of OPTFUT's can be described using the type:

        typedef OPTFUT * OPTFUTARRAY ;

see also Set_OPTFUT

,,EOT,,*/

typedef struct optfut_tag
{
    /* Base data */
    OPTTYPE     type ;
    FL64        strike ;
    DATESTR     dfix ;
    DATESTR     dpay ;
    PREMIUMTYPE ptype ;
    CALCONV     cal ;

    /* Additional Option Terms */
    OPTADD      oadd ;
    CHOOSERINF  chos ;              /* Chooser only */
    LOOKBACKINF lbi ;               /* Lookback only */
    BARRIERINF  barr ;              /* Barrier only */
    ASIANINF    asian ;             /* Asians only */
    FWDSTARTINF fwdst ;             /* Forward start only */
    TOUCHDIGINF tdi ;               /* One-Touch Digitals */
    BINARYINF   bini ;              /* Binary only */
    CONTPREMINF ctp ;               /* Contingent premium */
    COMPOPTINF  compo ;             /* Compound option */
    DOUBLKOINF  dko ;               /* Double KO option */
    LADDERINF   lad;                /* Ladder only */
    TSWITCHINF  tswi;               /* Time switch only */
    CORRIDORINF cor;                /* Corridor only */
}   OPTFUT ;

typedef OPTFUT * OPTFUTARRAY ;




/*,,SOT,,

CTTYPE: Enumeration of Currency Translated Option Types.
--------------------------------------------------------

This enumeration is defined as:

        typedef enum cttype_tag
        {
            FESDC,
            QUANTOPT,
            ELFX
        }   CTTYPE ;

where:

        FESDC is a Foreign Equity option Struck in Domestic Currency

        QUANTOPT is Foreign Equity option where the FX rate is Fixed

        ELFX is an Equity Linked FX option

in this way Mark Rubinsteins Currency Translated options can be described.

,,EOT,,*/

typedef enum cttype_tag
{
    FESDC,
    QUANTOPT,
    ELFX
}   CTTYPE ;


/*,,SOT,,

QUANTOINF: Container for holding info on Quanto Options:
--------------------------------------------------------

This type is defined as

        typedef struct quanto_tag
        {
            FL64 FX0 ;
        }   QUANTOINF ;

where
        FX0 is the fixed FX rate agreed upon in the option terms and
        conditions.

,,EOT,,*/

typedef struct quanto_tag
{
    FL64 FX0 ;
}   QUANTOINF ;


/*,,SOT,,

OPTCT: Currency Translated Option Definition
--------------------------------------------

This type is defined as:

        typedef struct optct_tag
        {
            OPTTYPE     type ;
            FL64        strike ;
            DATESTR     dfix ;
            DATESTR     dpay ;
            PREMIUMTYPE ptype ;
            CALCONV     cal ;
            CTTYPE      cttype ;
            QUANTOINF   quanto ;
        }   OPTCT ;

These first data are basic data for the option:

        type is the option type CALL, PUT or STRADDLE.

        strike is the strike price - in currency units.

        dfix is the fixing data for the option (last trading day).

        dpay is day on which any payout occur (dfix <= dpay). I.e. the
        future is delivered or cash is settled.

        ptype is the premiumtype

        cal is the calendar used to find the term till fixing and payment.

        cttype defines the Currency Translation

        quanto is only used when cttype is QUANTOOPT.

This struct is only used for Currency Translation of Equity and Commodity
Options. Use the routines -

        optEqtyCT_black2*()
        optCmdtyCT_black2*()

,,EOT,,*/

typedef struct optct_tag
{
    OPTTYPE     type ;
    FL64        strike ;
    DATESTR     dfix ;
    DATESTR     dpay ;
    PREMIUMTYPE ptype ;
    CALCONV     cal ;
    CTTYPE      cttype ;
    QUANTOINF   quanto ;
}   OPTCT ;


/*
..Private
*/

typedef struct
{
    DATESTR     analys ;
    DATESTR     voldate ;

    OPTTYPE     type ;
    FL64        e ;       /* Strike */
    FL64        tvol ;    /* Term for vol */
    FL64        tfix ;    /* Term till fixing */
    FL64        t ;       /* Term till payout */
    PREMIUMTYPE ptype ;
    CALCONV     cal ;

    OPTADD      oadd ;
    CHOOSERINF  chos ;    /* Choosers only */
    LOOKBACKINF lbi ;     /* Lookback extreme */
    BARRIERINF  barr ;    /* Barrier only */
    ASIANINF    asian ;   /* Asians only */
    FWDSTARTINF fwdst ;   /* Forward start only */
    TOUCHDIGINF tdi ;     /* One-Touch Digital */
    BINARYINF   bini ;
    CONTPREMINF ctp ;
    COMPOPTINF  compo ;   /* Compound option */
    DOUBLKOINF  dko ;     /* Double K/O */
    RESETINF    reset ;   /* Reset Cap (caps only) */
    LADDERINF   lad ;     /* Ladder */
    TSWITCHINF  tswi ;    /* Time switch */
    CORRIDORINF cor ;     /* Corridor */
}   OPTINT ;

typedef struct
{
  OPTINT*   opt;
  FL64      prem;
  BOOLE     is_p;
  FL64      pu;
  BOOLE     s_f;
  FL64      adj;
  FL64      vol;
  FL64      dfix;
  FL64      disc;
  KEYCONV   what;
  FL64      shock;
}   BLACKINT ;

typedef struct
{
  FL64       pr;
  FL64       pu; 
  FL64       e; 
  FL64       vol; 
  TS_STR*    ts; 
  INTPOLCONV its; 
  OPTTYPE    type;
  DATESTR*   today; 
  DATESTR*   dfrom; 
  DATESTR*   dto; 
  PERIOD     pd; 
  TS_STR*    fts; 
  INTPOLCONV ifts; 
  PLAN_STR*  div; 
  INTI       n;
  KEYCONV    what; 
  CALCONV    cal;
  RISKCONV   risk;
}   CRRINT ;
 
/*** macros ************************************************************/

/*
..
*/

#define opt_intrinsic_value(e, s, type) \
((type) == CALL ? GETMAX(0.0, (s) - (e)) : GETMAX(0.0, (e) - (s)))

/*
..
*/

#define opt_dollar_duration(delta, dp) \
(delta)*(dp)

/*
..
*/

#define opt_dollar_convexity(delta, dp, gamma, ddp) \
(gamma)*(SQR((dp)))+(delta)*(ddp)

/*
..
*/

#define black_d2(d1, vol, t) \
(d1) - 0.01*Vol_Ann2Per((vol), (t)) ;

/*
..
*/

#define crr_vol2factor(vol, t) \
exp(0.01*Vol_Ann2Per((vol), (t)))


/*** Prototyping   *****************************************************/


/*** routines in option.c  *********************************************/

extern FL64 Option_Black2P(DATESTR *analys,
                    DATESTR *voldate,
                    FL64    futp,
                    BOOLE   s_f,
                    FL64    adj,
                    FL64    vol,
                    OPTFUT  *opt,
                    DISCFAC *df,
                    HOLI_STR *holi,
                    RISKSET *risk,
                    FL64    *dp,
                    FL64    *ddp) ;

extern BOOLE Option_Black2Impl(DATESTR *analys,
                    DATESTR *voldate,
                    FL64    prem,
                    BOOLE   is_p,
                    FL64    futp,
                    BOOLE   s_f,
                    FL64    adj,
                    FL64    vol,
                    OPTFUT  *opt,
                    DISCFAC *df,
                    HOLI_STR *holi,
                    KEYCONV what,
                    ITERCTRL *ctrl,
                    FL64    *impl) ;

extern RESETINF Set_RESETINF(FL64    spread,
                         INTI    nfirst,
                         INTI    nfreq,
                         BOOLE    delayfix,
                         FL64     spread_low,
                         FL64     spread_up) ;

extern LADDERINF Set_LADDERINF(FL64ARRAY levels,
                                  INTI      nlevels) ;

extern TSWITCHINF Set_TSWITCHINF(DATESTR  *dobs1 ,
                                    DATESTR  *dobsN ,
                                    INTI     num_obs ,
                                    FL64     level ,
                                    PLAN_STR *step_strike ,
                                    FL64     curr_pay) ;

extern CORRIDORINF Set_CORRIDORINF(DATESTR  *dobs1 ,
                                      DATESTR  *dobsN ,
                                      INTI     num_obs ,
                                      FL64     upper ,
                                      FL64     lower ,
                                      PLAN_STR *ustep_strike ,
                                      PLAN_STR *lstep_strike ,
                                      FL64     curr_pay) ;

extern DOUBLKOINF Set_DOUBLKOINF(FL64 b1,
                             FL64 b2,
                             PERIOD *monit,
                             PAYOFFINF *poff,
                             BOOLE rebates,
                             FL64 r1,
                             BOOLE phit1,
                             FL64 r2,
                             BOOLE phit2) ;

extern COMPOPTINF Set_COMPOPTINF(OPTTYPE  type,
                             DATESTR* matur,
                             FL64     strike) ;

extern CONTPREMINF Set_CONTPREMINF(FL64 prem) ;

extern BINARYINF Set_BINARYINF(PAYOFFINF* poff,
                                  BOOLE      dcadj) ;

extern LOOKBACKINF Set_LOOKBACKINF(FL64  xtrem,
                               BOOLE lbrate) ;

extern TOUCHDIGINF Set_TOUCHDIGINF(KNOCKTYPE btype,
                               FL64     barrier,
                               BOOLE    phit,
                               PAYOFFINF* poff) ;

extern CHOOSERINF Set_CHOOSERINF(DATESTR* dchoose) ;

extern FWDSTARTINF Set_FWDSTARTINF(DATESTR*  dset,
                               FL64    alpha) ;

extern ASIANINF Set_ASIANINF(DATESTR*  davg1,
                         DATESTR*  davgN,
                         INTI      num_avg,
                         FL64      curr_avg,
                         BOOLE     avgrt,
                         FL64      last_avg) ;

extern BARRIERINF Set_BARRIERINF(KNOCKTYPE btype,
                             FL64      barrier,
                             FL64      rebate,
                             BOOLE     phit,
                             PAYOFFINF* poff,
                             PERIOD   *monit) ;

extern SHARKFININF Set_SHARKFININF(KNOCKTYPE btype,
                             FL64      barrier,
                             FL64      rebate,
                             PAYOFFINF* poff) ;

extern PAYOFFINF Set_PAYOFFINF(PAYOFF poff, FL64 gap, FL64 scale) ;

extern OPTFUT Set_OPTFUT(OPTTYPE type, FL64 strike, DATESTR *dfix,
                                DATESTR *dpay, PREMIUMTYPE ptype, CALCONV cal) ;

extern void Free_OPTFUT(OPTFUT* s) ;

/* Private functions */

extern FL64 Black_d1(FL64 f, FL64 e, FL64 vol, FL64 t, FL64 fac) ;

extern FL64 Black_Premium(OPTINT *opt, FL64 f, BOOLE s_f, FL64 adj, 
                              FL64 vol, FL64 dfix, FL64 disc, KEYCONV wrt, 
                              RISKCONV risk, FL64 shock, IRRCONV irr, 
							  INTI qbas, FL64 *dp, FL64 *ddp, HOLI_STR *holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */

extern BOOLE Black_Implied(OPTINT *opt, FL64 p, BOOLE is_p, FL64 f, 
                               BOOLE s_f, FL64 adj, FL64 vol, FL64 dfix, 
                               FL64 disc, KEYCONV what, 
							   ITERCTRL* ctrl, FL64 *res, HOLI_STR *holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */

extern void Black_SetImpl(FL64 x, FL64 *pu, FL64 *dfix, FL64 *disc, 
                              FL64 *vol, FL64 *e, FL64 *tvol, FL64 *tfix, 
                              FL64 *to, KEYCONV what) ;

extern FL64 NormDist_Premium(OPTINT* opt, FL64 f, BOOLE s_f,
                                 FL64 adj, FL64 vol, FL64 dfix,
                                 FL64 disc, KEYCONV wrt, RISKCONV risk,
                                 FL64 shock, IRRCONV irr, INTI qbas,
                                 FL64* dp, FL64* ddp) ;

extern OPTINT optfut_set_OPTINT(DATESTR *analys, DATESTR *vold,
                                OPTFUT *optf, FL64 vol, HOLI_STR *holi) ;

extern BLACKINT Black_SetBLACKINT(OPTINT* opt, FL64 prem, 
                                      BOOLE is_p, FL64 pu, BOOLE s_f, 
                                      FL64 adj, FL64 vol, FL64 dfix, 
                                      FL64 disc, KEYCONV what,
                                      FL64 shock);

extern void Black_GetBLACKINT(BLACKINT* blckint, OPTINT** opt, 
                                  FL64* prem, BOOLE* is_p, FL64* pu,
                                  BOOLE* s_f, FL64* adj, FL64* vol,
                                  FL64* dfix, FL64* disc, KEYCONV* what,
                                  FL64* shock);

extern BOOLE Black_NewtonRaphson(FL64 x, void* y, BOOLE grad, FL64* fx, 
                                    FL64* dfx, void* hol);  /* PMSTA-29444 - SRIDHARA - 050318 */
 
extern BOOLE Black_Root(OPTINT* opt, FL64 pr, BOOLE is_p, 
                                FL64 pu, BOOLE s_f, FL64 adj, 
                                FL64 vol, FL64 dfix, FL64 disc, 
                                KEYCONV what, 
                                ITERCTRL* y, FL64* rts,
								HOLI_STR  *holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */


/*** routines in exotic.c  *********************************************/


/* Private functions */
extern FL64 Option_Lookback(FL64 f, OPTINT *opt, FL64 adj, FL64 dfix,
                            FL64 vol, FL64 ff) ;

extern FL64 Option_Chooser(OPTINT *opt, FL64 vol, FL64 ff, HOLI_STR  *holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */

extern FL64 Option_Barrier(OPTINT *opt, FL64 spot, BOOLE s_f, 
      FL64 adj, FL64 vol,
	  FL64 forw, FL64 dfix, FL64 disc, HOLI_STR  *holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */

extern FL64 Option_Barrier_dig(OPTINT *opt, FL64 spot, BOOLE s_f, 
	FL64 adj, FL64 vol, FL64 forw, FL64 dfix, FL64 disc, HOLI_STR  *holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */

extern FL64 Option_Barrier_touch(OPTINT *opt, FL64 spot, FL64 adj,
	FL64 vol, FL64 forw, FL64 dfix, FL64 disc, HOLI_STR  *holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */

extern FL64 Option_Ladder(OPTINT* opt, FL64 f, BOOLE s_f, FL64 adj, 
	FL64 vol, FL64 forw, FL64  dfix, FL64 disc, HOLI_STR  *holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */

extern FL64 Option_Tswitch(OPTINT* opt, FL64 f, FL64 adj, FL64 vol, FL64 dfix, HOLI_STR  *holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */

extern FL64 Option_Corridor(OPTINT* opt, FL64 f, 
	FL64 adj, FL64 vol, FL64 dfix, HOLI_STR  *holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */

extern FL64 Option_Asian(OPTINT *opt, FL64 f, BOOLE s_f, FL64 adj, 
	FL64 vol, FL64 disc, FL64 dfix, HOLI_STR  *holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */

extern FL64 Option_Compound_option(OPTINT *opt, FL64 forw, 
                    FL64 spot, FL64 vol, FL64 adj, 
                    FL64 dfix, FL64 disc) ;

extern FL64 Option_Double_ko(OPTINT *opt, FL64 spot, FL64 vol,
                             FL64 adj, FL64 dfix, FL64 disc) ;

extern FL64 Dko_bs2P_basic(FL64 x1, FL64 x2, FL64 e, OPTTYPE type, 
                               FL64 tfix, FL64 x0, FL64 vol2, FL64 mu, 
                               FL64 volt, FL64 tol, BOOLE binary) ;

extern FL64 Dko_W(FL64 c, 
           FL64 x0, 
           FL64 mu, 
           FL64 vol2, 
           FL64 tfix, 
           FL64 kpm, 
           FL64 x, 
           FL64 e,
           FL64 volt,
           BOOLE binary,
           INTI sgn) ;

extern FL64  Dko_rebate(OPTINT *opt, 
                    FL64 spot, 
                    FL64 voll, 
                    FL64 yld, 
                    FL64 r, 
                    FL64 disc, 
                    FL64 tol) ;

extern FL64  dko_upper_rebate(FL64 x0, 
                          FL64 x1, 
                          FL64 x2, 
                          FL64 k, 
                          FL64 km, 
                          FL64 vt,
                          FL64 mt,
                          FL64 tol) ;

extern FL64  optint_DiscBarrShiftFac(DATESTR *vold, 
                                 DATESTR *dfix, 
                                 PERIOD *monit,
                                 FL64 vol, 
                                 FL64 tfix, 
                                 CALCONV cal,
                                 HOLI_STR *holi) ;


/*** routines in crr.c  *************************************************/

/* Public functions */


extern BINTREEARRAY Alloc_BINTREEARRAY(INTI ntree,
                                          INTI nlevel) ;

extern void Free_BINTREEARRAY(BINTREEARRAY s,
                                 INTI         ntree) ;

extern BINTREEARRAY Clb_CRR2Tree(INTI     n,
                    FL64     sigma,
                    FL64     s0,
                    DATESTR  *today,
                    DATESTR  *expiry,
                    CALCONV  cal,
                    PLAN_STR *div,
					HOLI_STR  *holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */

/* Private functions */

/* WARNING: TOO MANY ARGS (>15) BELOW */
extern BOOLE CRR_premium(BINTREE *crra, DATESTR *today, DATESTR *dfrom, 
                         DATESTR *dto, PERIOD pd, FL64 e, FL64 vol, TS_STR *ts, 
                         INTPOLCONV its, OPTTYPE type, TS_STR *fts, 
                         INTPOLCONV ifts, PLAN_STR *div, KEYCONV wrt, 
                         RISKCONV risk, FL64 size, CALCONV cal,
                         FL64 *p, FL64 *dp, FL64 *ddp) ;
/* WARNING: TOO MANY ARGS (>15) BELOW */
extern BOOLE CRR_Implied(FL64 p, DATESTR *today, DATESTR *dfrom,
                  DATESTR *dto, PERIOD pd, INTI n, FL64 s0, FL64 e, FL64 vol,
                  TS_STR *ts, INTPOLCONV its, OPTTYPE type, TS_STR *fts,
                  INTPOLCONV ifts,PLAN_STR *div, KEYCONV what, CALCONV cal,
				  ITERCTRL *ctrl, FL64 *impl, HOLI_STR  *holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */
/* WARNING: TOO MANY ARGS (>15) BELOW */
extern BOOLE CRR_Root(FL64 pr, FL64 pu, FL64 e, FL64 vol, TS_STR *ts,
                      INTPOLCONV its,
                      OPTTYPE type, DATESTR *today, DATESTR *dfrom, 
                      DATESTR *dto, PERIOD pd,
                      TS_STR *fts, INTPOLCONV ifts, PLAN_STR *div, INTI n, 
                      KEYCONV what, CALCONV cal,
					  ITERCTRL *ctrl, FL64 *rts, HOLI_STR  *holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */
/* WARNING: TOO MANY ARGS (>15) BELOW */
extern BOOLE CRR_Impl_Deviation(FL64 x, FL64 pr, FL64 pu, FL64 e,
                         FL64 vol, TS_STR *ts, INTPOLCONV its, OPTTYPE type,
                         DATESTR *today,
                         DATESTR *dfrom, DATESTR *dto, PERIOD pd,
                         TS_STR *fts, INTPOLCONV ifts, PLAN_STR *div,
                         INTI n, KEYCONV what, CALCONV cal,
						 FL64 *y, FL64 *dy, RISKCONV risk, HOLI_STR  *holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */
/* WARNING: TOO MANY ARGS (>15) BELOW */
extern CRRINT CRR_SetCRRINT(FL64 pr, FL64 pu, FL64 e, FL64 vol, 
                      TS_STR* ts, INTPOLCONV its, OPTTYPE type,
                      DATESTR* today, DATESTR* dfrom, DATESTR* dto, 
                      PERIOD pd, TS_STR* fts, INTPOLCONV ifts, 
                      PLAN_STR* div, INTI n, KEYCONV what, 
                      CALCONV cal, RISKCONV risk) ;
/* WARNING: TOO MANY ARGS (>15) BELOW */
extern void CRR_GetCRRINT(CRRINT* crrdata, 
                      FL64* pr, FL64* pu, FL64* e, FL64* vol, 
                      TS_STR** ts, INTPOLCONV* its, OPTTYPE* type,
                      DATESTR** today, DATESTR** dfrom, DATESTR** dto, 
                      PERIOD* pd, TS_STR** fts, INTPOLCONV* ifts, 
                      PLAN_STR** div, INTI* n, KEYCONV* what, 
                      CALCONV* cal, RISKCONV* risk) ;


extern FL64 CRR_Rpcalc(FL64 t1, FL64 dt, TS_STR *fts, INTPOLCONV ifts, 
                          TS_STR *ts, INTPOLCONV its, FL64 *rp) ;


extern BOOLE CRR_NewtonRaphson(FL64 x, VOIDPTR y, BOOLE grad, FL64* fx,
                               FL64* dfx, VOIDPTR holi) ;  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */


#ifdef __cplusplus
}
#endif

#endif

/* SCID @(#)riskpos.h	1.2 (SimCorp) 99/02/19 14:12:22 */

#ifndef RISKPOS_H_INCLUDED

#define RISKPOS_H_INCLUDED

/************************************************************************
*                                                                       *
*    project    SCecon                                                  *
*                                                                       *
*    filename   riskpos.h                                               *
*                                                                       *
*    this file contains definitions and function prototyping for the    *
*    routines in the SCecon RiskPos module                              *
*                                                                       *
************************************************************************/

/***** includes ********************************************************/
#include <bond.h>
#include <idxbond.h>
#include <scenario.h> 


/***** C++ Convenience *************************************************/
#ifdef __cplusplus
extern "C" {
#endif



extern RISKPOSLIST Cflw_DF2RiskPos(DATESTR   *analys,
                             CFLW_STR  *xcflw,
                             PP_STR    *pp,
                             FL64      Notnal,  
                             DISCFAC   *df,
                             DFSPREAD  *dfs,
                             HOLI_STR  *holi,
                             DELTASET  *ds,
                             FXRISKSET *FXr) ;

extern RISKPOSLIST RepoCflw_DF2RiskPos(DATESTR   *analys,
                                CFLW_STR  *xcflw,
                                DATESTR   *matur,
                                PP_STR    *pp,
                                FL64      Notnal,
                                DISCFAC   *df,
                                DFSPREAD  *dfs,
                                HOLI_STR  *holi,
                                DELTASET  *ds,
                                FXRISKSET *FXr) ;


extern RISKPOSLIST Bond_DF2RiskPos(DATESTR    *analys,
                                   TRADEINFO  *trade,
                                   FIXPAY     *fixp,
                                   FL64       Notnal,  
                                   DISCFAC    *df,
                                   DFSPREAD   *dfs,
                                   HOLI_STR   *holi,
                                   DELTASET   *ds,
                                   FXRISKSET  *FXr) ;

extern RISKPOSLIST Deposit_DF2RiskPos(DATESTR    *analys,
                                       DEPOSIT    *depo,
                                       FL64       Notnal,
                                       DISCFAC    *df,
                                       DFSPREAD   *dfs,
                                       HOLI_STR   *holi,
                                       DELTASET   *ds,
                                       FXRISKSET  *FXr) ;

extern RISKPOSLIST IndexBond_DF2RiskPos(DATESTR     *analys,
                                            TRADEINFO   *trade,
                                            INDEXBOND   *idxbond,
                                            FL64        Notnal,
                                            INDEXFAC    *idxfac,
                                            DISCFAC     *df,
                                            DFSPREAD    *dfs,
                                            HOLI_STR    *holi,
                                            BOOLE       indexadj,
                                            DELTASET    *ds,
                                            FXRISKSET   *FXr) ;

extern RISKPOSLIST IndexLoan_DF2RiskPos(DATESTR     *analys,
                                            INDEXLOAN   *idxloan,
                                            FL64        Notnal,
                                            INDEXFAC    *debfac,
                                            INDEXFAC    *crefac,
                                            DISCFAC     *df,
                                            DFSPREAD    *dfs,
                                            HOLI_STR    *holi,
                                            BOOLE       indexadj,
                                            DELTASET    *ds,
                                            FXRISKSET   *FXr) ;

/* Private functions */
extern FL64 Disc_DF2RiskPosFac(DATESTR   *analys,
                                  DISCFAC   *df,
                                  DELTASET  *ds,
                                  INTI      i,
								  HOLI_STR  *holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */


#ifdef __cplusplus
}
#endif

#endif

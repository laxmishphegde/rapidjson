/* SCID @(#)f2proto.h	1.10 (SimCorp) 99/02/19 14:15:33 */

#ifndef F2PROTO_H_INCLUDED

#define F2PROTO_H_INCLUDED

#include <math.h>
#include <f2c.h>

#ifdef __cplusplus
extern "C" {
#endif

/* F2CONST may be set to const when compiling as C++ */
#define F2CONST

extern int calc(
         int (*fdf)(integer *, integer *, double *, void *, double *),
         F2CONST  integer *n,
         F2CONST  integer *m,
         F2CONST  double x[],
         void   *data,
         double df[],
         double f[]) ;
extern int mi0cl1(
         int (*fdf)(integer *, integer *, double *, void *, double *),
         integer N,
         integer M,
         integer L,
         integer LEQ,
         F2CONST double c[],
         F2CONST double dc[],
         double x[],
         double *dx,
         double *eps,
         integer *maxfun,
         double *w,
         integer IW,
         integer *icontr,
         void* data) ;
extern double d_sign(double *a,double *b) ;
#ifndef NO_FPTR2FPTR
extern int mincl1_(int (*calc)(int (*fdf)(integer *, integer *, 
                   double *, void *, double *),
                integer *, integer *, double *, void *, double *, double *),
            int (*fdf) (integer *, integer *, double *, void *, double *),
            integer    *n,
            integer    *m,
            integer    *l,
            integer    *leq,
            doublereal *c,
            doublereal *dc,
            doublereal *x,
            doublereal *dx,
            doublereal *eps,
            integer    *maxfun,
            doublereal *w,
            integer    *iw,
            integer    *icontr,
            void       *data) ;

#ifndef NO_FPTR2FPTR
extern int checkd_(int (*calc)(int (*fdf)(integer *, integer *, double *,
  void *, double *),
                   integer *, integer *, double *, void *, double *, double *),
            int (*fdf) (integer *, integer *, double *, void *, double *),
#else
extern int checkd_(int (*calc)(),
            int (*fdf) (integer *, integer *, double *, void *, double *),
#endif
            integer    *n,
            integer    *m,
            doublereal *x,
            doublereal *stepl,
            doublereal *diff,
            integer    *indx,
            doublereal *a,
            doublereal *a1,
            doublereal *f,
            doublereal *f1,
            doublereal *f2, 
            void       *data) ;

extern int diferr_(doublereal *ym,
            doublereal *yf,
            doublereal *yb,
            doublereal *diff,
            doublereal *stepl,
            doublereal *erm,
            doublereal *erf,
            doublereal *erb,
            logical    *chm,
            logical    *chf,
            logical    *chb) ;

#ifndef NO_FPTR2FPTR
extern int l1nls_(
   int (*calc)(int (*fdf)(integer *, integer *, double *, void *, 
                          double *),
               integer *, integer *, double *, void *, double *, double *),
   int (*fdf) (integer *, integer *, double *, void *, double *),
#else
extern int l1nls_(int (*calc)(),
           int (*fdf) (integer *, integer *, double *, void *, double *),
#endif
           integer *n,
           integer *m,
           integer *l,
           integer *leq,
           doublereal *c,
           doublereal *dc,
           doublereal *x,
           doublereal *dx,
           doublereal *eps,
           integer *maxfun,
           integer *keqs,
           integer *nn,
           doublereal *f,
           doublereal *f1,
           doublereal *df,
           doublereal *df1,
           doublereal *x1,
           doublereal *b,
           doublereal *u,
           doublereal *r,
           doublereal *a,
           doublereal *cloc,
           doublereal *wl,
           doublereal *wl1,
           doublereal *xx,
           doublereal *w,
           doublereal *w1,
           doublereal *w2,
           doublereal *w3,
           doublereal *wm,
           doublereal *wm1,
           doublereal *aset,
           integer *kset,
           integer *kset0,
           integer *kstatc,
           integer *kstatf,
           integer *kstatl,
           integer *icontr,
           void    *data) ;

#ifndef NO_FPTR2FPTR
extern int l1sta2_(
            int (*calc)(int (*fdf)(integer *, integer *, double *,
                                   void *, double *),
                        integer *, integer *, double *, void *, 
                        double *, double *),
            int (*fdf) (integer *, integer *, double *, void *, double *),
#else
extern int l1sta2_(int (*calc)(),
            int (*fdf) (integer *, integer *, double *, void *, double *),
#endif
            integer    *n,
            integer    *m,
            integer    *l,
            integer    *leq,
            doublereal *c,
            doublereal *cloc,
            doublereal *dc,
            doublereal *x,
            doublereal *xxnmax,
            doublereal *b,
            integer    *nact,
            integer    *kset,
            doublereal *aset,
            integer    *kstatf,
            integer    *kstatc,
            doublereal *dz,
            doublereal *zz,
            integer    *nn,
            doublereal *f,
            doublereal *df,
            doublereal *x1,
            doublereal *f1,
            doublereal *df1,
            doublereal *w,
            doublereal *w1,
            doublereal *aset1,
            doublereal *wl,
            doublereal *wm,
            doublereal *eps,
            integer    *maxfun,
            integer    *ncall,
            doublereal *xxn,
            integer    *nstep,
            doublereal *seps,
            integer    *icontr,
            void       *data) ;

extern int l1lp_(doublereal *f,
          doublereal *df,
          doublereal *c,
          doublereal *dc,
          integer    *m,
          integer    *n,
          integer    *ic,
          integer    *le,
          integer    *li,
          doublereal *xnmax,
          doublereal *xn,
          doublereal *x,
          integer    *nact,
          integer    *kset,
          doublereal *aset,
          doublereal *u,
          doublereal *r,
          doublereal *dl,
          doublereal *h,
          doublereal *fup,
          doublereal *dldf,
          doublereal *cup,
          doublereal *dldc,
          integer    *kstatf,
          integer    *kstatc,
          integer    *kstatl,
          doublereal *stepf,
          doublereal *w,
          doublereal *seps,
          logical    *accum,
          doublereal *fl1,
          integer    *icontr) ;

extern int feasi_(doublereal *c,
           doublereal *dc,
           integer    *ic,
           integer    *le,
           integer    *li,
           integer    *n,
           doublereal *x,
           integer    *nact,
           integer    *kset,
           doublereal *aset,
           doublereal *u,
           doublereal *r,
           doublereal *dl,
           doublereal *right,
           doublereal *cup,
           doublereal *dldc,
           doublereal *w,
           integer    *kstat,
           integer    *icontr,
           logical    *accum,
           doublereal *seps) ;

extern int linsys_(doublereal *a,
            doublereal *b,
            integer    *idim,
            integer    *n,
            integer    *nr,
            doublereal *seps) ;

extern int bfgs_(doublereal *b,
          integer    *n,
          doublereal *y,
          doublereal *xx,
          doublereal *w,
          doublereal *seps) ;

extern int addcol_(doublereal *u,
            doublereal *r,
            integer    *n,
            integer    *kcol,
            integer    *knew,
            doublereal *right,
            doublereal *w,
            logical    *accum,
            logical    *lright,
            doublereal *eps) ;

extern int delcol_(integer    *k,
            doublereal *u,
            doublereal *r,
            integer    *n,
            integer    *kcol,
            doublereal *right,
            logical    *lright) ;

extern int uttrns_(doublereal *u,
            integer    *n,
            integer    *kcol,
            logical    *accum,
            doublereal *r,
            doublereal *w) ;

extern int utrns_(doublereal *u,
           integer    *n,
           integer    *kcol,
           logical    *accum,
           doublereal *r,
           doublereal *w) ;

extern int rsolv_(doublereal *r,
           integer    *n,
           integer    *kcol,
           doublereal *right,
           doublereal *x) ;

extern int rtsolv_(doublereal *r,
            integer    *n,
            integer    *kcol,
            doublereal *right,
            doublereal *x) ;

extern int haccum_(doublereal *u,
            integer    *n,
            integer    *kcol,
            doublereal *w) ;

extern int limit_(doublereal *xnmax2,
           doublereal *x,
           doublereal *xn2,
           doublereal *p,
           doublereal *pn2,
           doublereal *alfa,
           integer    *n) ;

extern int matvec_(doublereal *a,
            doublereal *x,
            integer    *ia,
            integer    *m,
            integer    *n,
            doublereal *y) ;

#else

extern int calc() ;
extern int mi0cl1() ;
extern double d_sign() ;
extern int mincl1_() ;
extern int checkd_() ;
extern int diferr_() ;
extern int l1nls_() ;
extern int l1sta2_() ;
extern int l1lp_() ;
extern int feasi_() ;
extern int linsys_() ;
extern int bfgs_() ;
extern int addcol_() ;
extern int delcol_() ;
extern int uttrns_() ;
extern int utrns_() ;
extern int rsolv_() ;
extern int rtsolv_() ;
extern int haccum_() ;
extern int limit_() ;
extern int matvec_() ;

#endif

#ifdef __cplusplus
}
#endif

#endif

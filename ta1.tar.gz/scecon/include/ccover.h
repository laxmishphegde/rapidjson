#ifndef CCOVER_H
#define CCOVER_H

#include <sccsid.h>

/*
SCCSID(ccover_h,
  "@(#)ccover.h	1.2 (SimCorp) 98/04/20 16:24:50")
*/

/* INCLUDE FILE FOR ALL SIMCORP C/C++ SOFTWARE
 *
 * Defines standard types to use instead of built in types for
 * portability and readability reasons.
 *
 * Define SCCONST according to compilation level. ANSI understands
 * const unless SCNOCONST macro is defined
 */

#if defined(SCANSI) && !defined(SCNOCONST)
#  define SCCONST const
#else
#  define SCCONST
#endif


/**********************************************************************
depending on operating system this will be defined:

  SIMCORP_OS_DOS
  SIMCORP_OS_OS2
    SIMCORP_OS_OS2_DLL
  SIMCORP_OS_WINDOWS
    SIMCORP_OS_WINDOWS_DLL
    SIMCORP_OS_WINDOWS_EXE
  SIMCORP_OS_UNIX
    SIMCORP_OS_UNIX_AIX
    SIMCORP_OS_UNIX_ULTRIX
    SIMCORP_OS_UNIX_SUNOS
    SIMCORP_OS_UNIX_AXP
    SIMCORP_OS_UNIX_ICL
    SIMCORP_OS_UNIX_CDC
    SIMCORP_OS_UNIX_XENIX
    SIMCORP_OS_UNIX_DYNIX

**********************************************************************/

/* ------ Zortech 3.04 on DOS (Must be extended for OS/2) ------ */
#ifdef __ZTC__

#  ifdef _WINDOWS
#    define EXPORTABLE pascal
#    define SIMCORP_OS_WINDOWS
#    ifdef _DLL
#      define SIMCORP_OS_WINDOWS_DLL
#    else
#      define SIMCORP_OS_WINDOWS_EXE
#    endif
#  else
#    define SIMCORP_OS_DOS
#  endif
#endif

/* ----------------- IBM CSet++/2 ----------------------------------- */
#if (defined(__IBMCPP__) || defined(__IBMC__)) && defined(__OS2__)

#  define SIMCORP_OS_OS2
#  if defined(__DLL__)
#    define SIMCORP_OS_OS2_DLL
#  endif
#endif

/* ----------------- Borland C++ 3.1 on DOS ----------------------- */
#ifdef __BORLANDC__

#  ifdef _Windows
#    define EXPORTABLE pascal
#    define SIMCORP_OS_WINDOWS
#    ifdef __DLL__
#      define SIMCORP_OS_WINDOWS_DLL
#    else
#      define SIMCORP_OS_WINDOWS_EXE
#    endif
#  else
#    define SIMCORP_OS_DOS
#  endif
#endif

/* --------------- Green Hills C++ on DEC  --------------- */
#ifdef __ghs
/* A few important defines */
#  define __mips
#  define __LANGUAGE_C
#  define SIMCORP_OS_UNIX
#  define SIMCORP_OS_UNIX_ULTRIX
#endif

/* --------------- DEC C(++)  1.00  ---------------*/
#if defined(ultrix)
#  define SIMCORP_OS_UNIX
#  define SIMCORP_OS_UNIX_ULTRIX
#endif

/* --------------- IBM xlC --------------- */
#if defined(__xlC__) || defined(_AIX)
/* only _AIX is defined when xlC redirects C sources to cc */
#  define SIMCORP_OS_UNIX
#  define SIMCORP_OS_UNIX_AIX
#endif

/* --------------- sun icl --------------- */
/* This triggers for both gcc (__GNUG__) on the sun and the sun
   AT&T cfront which apparently has got no special defines. It also
   copes with the ICL DRS/6000 which defines only sparc */
#if defined(sparc) || defined(sun)
#  define SIMCORP_OS_UNIX
#  if defined(sun)
#    define SIMCORP_OS_UNIX_SUNOS
#  else
#    define SIMCORP_OS_UNIX_ICL
#  endif
#endif

/* --------------- CDC (suspect!) --------------- */
#if defined(mips)
#  if !defined(ultrix)
#    define SIMCORP_OS_UNIX
#    define SIMCORP_OS_UNIX_CDC
#  endif
#endif

/* --------------- DEC Alpha --------------- */
#if defined(__alpha)
#  define SIMCORP_OS_UNIX
#  define SIMCORP_OS_UNIX_AXP
#endif

/* --------------- XENIX ------------------- */
#if defined(M_XENIX)
#  define SIMCORP_OS_UNIX
#  define SIMCORP_OS_UNIX_XENIX
#endif

/* --------------- DYNIX (suspect!) ------------------- */
#if defined(_SEQUENT_)
#  define SIMCORP_OS_UNIX
#  define SIMCORP_OS_UNIX_DYNIX
#endif

/* --------------- High C 32 bit compiler --------------- */
#ifdef __HIGHC__
#  define SIMCORP_OS_DOS
#endif

/* --------------- Watcom C 32 bit compiler --------------- */
#ifdef __WATCOMC__
#  if (defined __WINDOWS__) || (defined __WINDOWS_386__)
#    define EXPORTABLE pascal __export
#    define SIMCORP_OS_WINDOWS
#    ifdef __SW_BD
#      define SIMCORP_OS_WINDOWS_DLL
#    else
#      define SIMCORP_OS_WINDOWS_EXE
#    endif
#  else
#    define SIMCORP_OS_DOS
#  endif
#endif

/* --------------- Microsoft C/C++ --------------- */
#ifdef _MSC_VER
#  ifdef _WINDOWS
#    define EXPORTABLE __pascal __export
#    define SIMCORP_OS_WINDOWS
#    ifdef _WINDLL
#      define SIMCORP_OS_WINDOWS_DLL
#    else
#      define SIMCORP_OS_WINDOWS_EXE
#    endif
#  else
#    define SIMCORP_OS_DOS
#  endif
#endif

/* to prevent the 'keyword' EXPORTABLE causing trouble... */
#ifndef EXPORTABLE
#  define EXPORTABLE
#endif

#define DLLEXPORTABLE EXPORTABLE

/* To include "other" UNIX compilers (flavour unknown) */
#ifdef unix
#  ifndef SIMCORP_OS_UNIX
#    define SIMCORP_OS_UNIX
#  endif
#endif
/* --------------- End of Compilers --------------- */

#include <stddef.h>
#include <string.h>
#include <math.h>
#include <limits.h>
#include <genmacro.h>

/* decide IN32 */
#if 0x7FFFFFFFL == INT_MAX
  /* 32 bit int's */
#  define OS_32BIT
  typedef int IN32;
  typedef unsigned UN32;
#  define IN32_MAX INT_MAX
#  define IN32_MIN INT_MIN
#  define UN32_MAX UINT_MAX
#else
#  if 0x7FFFFFFFL == LONG_MAX
    /* 32 bit long's */
    typedef long IN32;
    typedef unsigned long UN32;
#  define IN32_MAX LONG_MAX
#  define IN32_MIN LONG_MIN
#  define UN32_MAX ULONG_MAX
#  endif
#endif

/* decide IN16 */
#if 0x7FFF == INT_MAX
  /* 16 bit int's  */
#  define OS_16BIT
  typedef int IN16;
  typedef unsigned UN16;
#  define IN16_MAX INT_MAX
#  define IN16_MIN INT_MIN
#  define UN16_MAX UINT_MAX
#else
#  if 0x7FFF == SHRT_MAX
    /* 16 bit short's */
    typedef short IN16;
    typedef unsigned short UN16;
#  define IN16_MAX SHRT_MAX
#  define IN16_MIN SHRT_MIN
#  define UN16_MAX USHRT_MAX
#  endif
#endif

#if !defined(SIMCSIGN)
/* The macro CHAR_MIN defined in limits.h is used for deciding whether
   chars are signed or not.

   On some compilers CHAR_MIN does not reflect if the signed/unsigned
   state of chars have been changed with a pragma. In those cases
   the settings can be overridden with a define on the command line.
   -DSIMCSIGN=1 states that chars should be regarded as signed,
   -DSIMCSIGN=0 that they should be treated as unsigned. This setting
   does in no way change the compilers way of treating the chars, it
   only assures that the SimCorp types will be defined accordingly.
 */
#  if CHAR_MIN == 0
#    define SIMCSIGN 0
#  else
#    define SIMCSIGN 1
#  endif
#endif

#if SIMCSIGN
   /* signed char's */
   typedef char IN8;
   typedef unsigned char UN8;
#  define SIMCHAR_MIN SCHAR_MIN
#  define SIMCHAR_MAX SCHAR_MAX
#else
   /* unsigned char's */
   typedef char UN8;
   typedef signed char IN8;
#  define SIMCHAR_MIN 0
#  define SIMCHAR_MAX UCHAR_MAX
#endif

#  define IN8_MAX SCHAR_MAX
#  define IN8_MIN SCHAR_MIN
#  define UN8_MAX UCHAR_MAX


/*  end of OS_ dependencies */

/* ---------- Definitions independent of platform ---------------- */

/* doubles are so far expected always to be 8 byte */
typedef double FL64;

typedef int INTI;
typedef long INTL;
typedef int COUNT;

#ifdef SCMSBOOL
  #define BOOLE bool
  #define True true
  #define False false
#else
  typedef int BOOLE;

  enum
  {
    False=0, True=1
  };
#endif

typedef char CH;
typedef CH *TEXT;
typedef SCCONST CH *CTEXT;
typedef void * VOIDPTR;

#endif


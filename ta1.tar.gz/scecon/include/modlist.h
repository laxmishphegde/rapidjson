/* SCCS @(#)modlist.h	1.9 (SimCorp) 99/05/21 13:53:43 */

/*******************************************/
/*                                         */
/*  SCEcon Modular Structure               */
/*                                         */
/*******************************************/

/*,,SMODULELIST,,

No. Contents                                          Directory  Requires
===============================================================================
 0  Memory/Error Manager                               hook                    
-------------------------------------------------------------------------------
 1  Basic - Debt Instruments                           main                   
 2  Basic - Derivatives                                maindrv                 
-------------------------------------------------------------------------------
 3  Fixed Income - Debt Instruments                    debt                    
 4  Fixed Income - Term Structure Calibration          tscalib   3             
-------------------------------------------------------------------------------
 5  Fixed Income Derivatives - Swaps and Forwards      debtdrv   3             
 6  Fixed Income Derivatives - Black Based - Basic     blck      2,3,5         
 7  Fixed Income Derivatives - Black Based - Advanced  blckava   2,3,5         
 8  Fixed Income Derivatives - One-Factor Models       tsm       2,3,5,6       
 9  Fixed Income Derivatives - Multi-Factor Models     mftsm     2,3,5,6       
10  Fixed Income Derivatives - Danish MBS              dkmbs     2,3,5,6,8
-------------------------------------------------------------------------------
11  Equity/FX/Commodity Derivatives - Black Based      eqtydrv   2,3           
-------------------------------------------------------------------------------
12  Portfolio - VaR and Performance                    prtfl     3      
13  RiskMetrics Interface                              scrm      3,12
14  TMS Interface                                      calcbase  2-6,11


Requirement Notes:
------------------
Modules 1 - 14 requires the presence of module 0 and 1


Current Status:
---------------
Some of the modules listed above are not yet present - these
modules are presently contained in other module:

Module 8 presently includes module 10 as well.

 
 

,,EMODULELIST,, */


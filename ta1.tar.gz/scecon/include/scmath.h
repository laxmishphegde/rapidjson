/* SCID @(#)scmath.h	1.4 (SimCorp) 99/09/07 13:25:01 */

#ifndef SCMATH_H
#define SCMATH_H

/************************************************************************
*                                                                       *
*    project    SCecon                                                  *
*                                                                       *
*    file name  scutl.h                                                 *
*                                                                       *
*    this file contains definitions and function prototyping for the    *
*    routines in the SCecon Utilities module.                           *
*                                                                       *
************************************************************************/

/***** includes  *******************************************************/
#include <math.h>
#include <scecon.h>
#include <scalloc.h>

#ifdef __cplusplus
extern "C" {
#endif

/***** defines   *******************************************************/
/* This value is the maximum value x that N01(x) can handle to avoid
   overflow (Mainframe, OS/2) ... */
#define N01_EXTREME  6.0  

#define sc_PI 3.1415926535897932384626
  /* PI, src: Numerical Recipes */


/*** General SCecon documentation        ******************************/

/*,,SIC,,

Numerical Routines in SCecon
----------------------------

Beneath the financial calculation routines in SCecon is a collection
of pure numerical routines. These are used to solve various kinds of
optimisation problems. All routines are implemented independent of
the financial context of SCecon and can be deployed for any other
problem. The interface between the problems and the routines is
based on problem specific data containers cast into VOIDPTR
and general function types, eg BRENT_FCT.


Interpolation:

  Math_IntpolArray()          Uni-variate interpolation
  Math_2Dinterpolation()      Bi-variate interpolation


Matrix Decompostion:

  Math_SVD()                  Singular Value Decompostion
  Math_LUdecomp()             LU Decompostion
  Math_SYM2OrthoDecomp()      Orthogonal Decompostion of a Symmetric Matrix
                              aka Eigenvector decomposition
                              aka Principal Components Analysis
  Math_CholeskyDecomp()       Cholesky Decomposition


Function Minimisation:

  Powell()                    Multi-variate un-constrained function 
                              minimisation using no explicit gradient 
                              information.
  Brent()                     Uni-variate un-constrained function minimisation
                              using no explicit gradient information.
  mi0cl1()                    Multi-variate constrained function minimisation
                              using explicit gradient information.
                              This is the Harwell optimiser.

  Stat_LeastSquaresRegress()  Generalised Non-Linear Least Squares Regression

  mrqmin()                    Multi-variate un-constrained function 
                              minimisation using explicit gradient 
                              information. This is the Leuvenberg-Marquardt 
                              method.

Root Search:

  Newton_Raphson()          Newton-Raphson root search.




,,EIC,,*/


/***** typedefs  *******************************************************/

/*,,SOT,,

INTPOLCONV : data type for interpolation method
-----------------------------------------------

Interpolation is used in several situations when you want to compute
corresponding (x,y) values, e.g. when you want to get a term structure
rate for a specific term not explicitly represented in the term
structure.

In SCecon, interpolation methods are defined in the data type INTPOLCONV
as

        typedef enum intpol_tag
        {
            LINEAR_EXTRAPOL,
            LINEAR_FLAT_END,
            EXCL_INCL,
            INCL_EXCL,
            CUBIC_SPLINE
        }   INTPOLCONV ;

in scutl.h of the SCecon Library.

Linear interpolation can be carried out in two ways, LINAER_EXTRAPOL and
LINEAR_FLAT_END. These methods differ in the way out of sample values
are treated.

According to the LINEAR_EXTRAPOL method, out of sample values of y are
computed as

                         y(last) - y(second last)
        y(x) = y(last) + ------------------------ * (x - x(last) ).
                         x(last) - x(second last)

According to the LINEAR_FLATEND method, out of sample values of y are
computed as

        y(x) = y(last).

Stair case interpolation of corresponding (y,x) values are calculated
using either EXCL_INCL or INCL_EXCL.

According to EXCL_INCL,

        y(x) = y(xhigh) if xlow < x <= xhigh,

while y(x) is computed as

        y(x) = y(xlow) if xlow <= x < xhigh

using the INCL_EXCL interpolation method.

Finally, using CUBIC_SPLINE, corresponding values of (y,x) are computed
according to a third degree polynomia, that fits the observed pairs of
(x,y) values best.

,,EOT,,*/

typedef enum intpol_tag
{
    INTPOLCONV_INIT = -1,
    LINEAR_EXTRAPOL,
    LINEAR_FLAT_END,
    EXCL_INCL,
    INCL_EXCL,
    CUBIC_SPLINE
}   INTPOLCONV ;





/*,,SOT,,

ITERCTRL: Data container for control of iterating procedures
------------------------------------------------------------

This type is defined as:

        typedef struct iterctrl_tag
        {
            INTI      maxiter ;
            FL64      init_guess ;
            BOOLE     use_init_guess ;
            FL64      lower ;
            BOOLE     use_lower ;
            FL64      upper ;
            BOOLE     use_upper ;
            FL64      damp ;
            FL64      acc ;
            INTI      what_acc ;
            INTI      gfreq ;
            INTI      bisec ;
            FL64      shock ;
        }   ITERCTRL ;

in scutl.h

The struct is used for controlling iterations in certain procedures where
iterations are needed for finding the result. The data have the following
interpretations:

        maxiter is the maximal number of iterations performed.

        init_guess is the initial guess on the variable to be found.
          Only used use_init_guess is True. If use_init_guess is False
        a default will be applied.
          It is recommended to supply an initial guess.
          The initial guess should always be between the lower and upper
        bounds in case these are supplied.

        lower is the lower bound on the variable to be found.
          Only used use_lower is True. If use_lower is False a default will 
        be applied.
          It is recommended to supply a lower bound.

        upper is the upper bound on the variable to be found.
          Only used use_upper is True. If use_upper is False a default will 
        be applied.
          It is recommended to supply an upper bound.

        damp is a damping parameter for reducing Newton-Raphson guess's
        when this algorithm becomes unstable. 
          Should be a number between 0.0 and 1.0 where 1.0 means no damping.
        Recommended selection is 1.0.

        acc is the absolute accuracy on the unknown.

        what_acc determines what the accuracy acc is applied to:
        0 means the accuracy of the variable to be found,
        1 means the accuracy of function value to be matched.
          Recommended selection is 1 but the difference between the two
        methods can be eliminated by adjusting the accuracy.

        gfreq is the frequency with which gradients are updated (1 means
        in every loop, 2, every second etc).
          Recommended selection is 1.

        bisec determines which Newton-Raphson algorithm to use:
        0 means standard Newton-Raphson.
        1 means Newton-Raphson with bisection.
        2 means Newton-Raphson with bisection and root bracketing
        prior to the root finding.
          Bisection is used as a means of recovery in the case where the
        Newton-Raphson algorithm is unable to proceed.
          Root bracketing is uses the initial guess to find a lower and
        upper bound.
          Recommended selection is 1.

        shock is the absolute shock size used when calculating gradients. 


In all routines where ITERCTRL is used, default values can be used instead
of setting these separately. IF YOU HAVE NO SPECIFIC IDEAS ABOUT THE VALUES
OF THESE VARIABLE - USE THE DEFAULTS. The default values are used by setting
use_init_guess, use_lower, use_upper to False and the remaining ITERCTRL 
values to a value strictly less than 0. Default values can be set 
individually.

Use Init_ITERCTRL() to set ALL default values.

,,EOT,,*/

typedef struct iterctrl_tag
{
    INTI      maxiter ;
    FL64      init_guess ;
    BOOLE     use_init_guess ;
    FL64      lower ;
    BOOLE     use_lower ;
    FL64      upper ;
    BOOLE     use_upper ;
    FL64      damp ;
    FL64      acc ;
    INTI      what_acc ;
    INTI      gfreq ;
    INTI      bisec ;
    FL64      shock ;
}   ITERCTRL ;


/*

NR_ERR: Newton-Raphson error container
--------------------------------------

This type is defined as:

    typedef enum nr_err_tag
    {
        NR_ROOT_FOUND,
        NR_CONSTANT_ZERO,
        NR_WRONG_BRACKET,
        NR_FUNCTION_COMPUTATION_ERR,
        NR_LOCAL_EXTR,
        NR_GUESS_OUTSIDE_BRACKET,
        NR_MAXITER_EXCEEDED,
        NR_ROOT_BRACKET_ERR,
        NR_CONT
    }   NR_ERR ;

When calling Newton_Raphson() a return code of type NR_ERR indicates 
how the root finding algorithm terminated:

NR_ROOT_FOUND means that the algorithm terminated successfully and 
that a root was found.

NR_CONSTANT_ZERO means that the algorithm terminated successfully
but a constant zero section was found.

NR_WRONG_BRACKET means that the algorithm failed because
init_guess is not between lower and upper.

NR_FUNCTION_COMPUTATION_ERR means that the algorithm failed because
the calculation of a function value returned False.

NR_LOCAL_EXTR means that the algorithm failed because a local
extremum was found. In this case try to use Newton-Raphson with
bisection.

NR_GUESS_OUTSIDE_BRACKET means that the algorithm failed because
the Newton-Raphson guess was outside the bracket. In this case
try change lower and upper or to use Newton-Raphson with bisection. 

NR_MAXITER_EXCEEDED means that the algorithm failed because
maxiter was exceeded before a root was found. In this case try to
increase maxiter or lower acc.

NR_CONT is only for internal use.

*/

typedef enum nr_err_tag
{
    NR_ROOT_FOUND,
    NR_CONSTANT_ZERO,
    NR_WRONG_BRACKET,
    NR_FUNCTION_COMPUTATION_ERR,
    NR_LOCAL_EXTR,
    NR_GUESS_OUTSIDE_BRACKET,
    NR_MAXITER_EXCEEDED,
    NR_CONT
}   NR_ERR ;




typedef struct ortodecomp_tag
{
  FL64MATRIX  v; /* Eigen-vectors. Size [n,nfac] */
  FL64ARRAY   l; /* Eigen-values. Size [nfac] */
  INTI        nfac; /* Number of components */
  INTI        n; /* Size of eigen vectors */
} ORTODECOMP;


/* 
  NEWTONRAPHSON_FCT
  *****************

  Function on which a root is sought using a uni-variate Newton-Raphson
  search routine.

  Prototype:

    typedef BOOLE (*NEWTONRAPHSON_FCT)(FL64, VOIDPTR, BOOLE, FL64*, FL64*);

  Input:
          FL64    x     The search parameter

          VOIDPTR pdata Problem specific data container

          BOOLE   deriv Compute gradient toggle

          INTI    *f    Computed function value at x

          INTI    *df   Computed gradient value at x 
                        Only computed when deriv == True.

  Returns:
          True if calculation succeeded or False upon any kind of failure

  Examples:

*/
typedef BOOLE(*NEWTONRAPHSON_FCT)(FL64, VOIDPTR, BOOLE, FL64*, FL64*, VOIDPTR);   /* PMSTA-29444 - SRIDHARA - 050318 */




/* 
  BRENT_FCT
  *********

  This type is used for the Brent optimiser seeking a optimal descent
  in a multi-variate setting.

  The type defines a function that computes a function value in multi-
  dimensional space.

  Prototype:

    FL64 (*BRENT_FCT)(FL64, VOIDPTR, FL64ARRAY, FL64ARRAY, BOOLE*);

  Input:
          FL64      x      The search parameter

          VOIDPTR   pdata  Problem specific data container

          FL64ARRAY point  The origin of the search

          FL64ARRAY direct The search-direction from 'point'.

  Inout:
          BOOLE     *ok    Everything ok watch.

  Returns:
          The function value computed at the point

                  (point)  +  x * (direct)

  Examples:

*/
typedef FL64 (*BRENT_FCT)(FL64, VOIDPTR, FL64ARRAY, FL64ARRAY, BOOLE*);


/* 
  POWELL_FCT
  **********

  This type is used for the Powell optimiser seeking an optimal
  (maximum or minimum) in a multi-variate setting.

  The type defines a function that computes a function value in multi-
  dimensional space.


  Prototype:

    FL64 (*POWELL_FCT)(FL64ARRAY, VOIDPTR, BOOLE*);

  Input:
          FL64ARRAY x     The origin of the search

          VOIDPTR   pdata Problem specific data container

  Inout:
          BOOLE     *ok   Everything ok watch.

  Returns:
          The function value computed at the point x

  Examples:

*/
typedef FL64 (*POWELL_FCT)(FL64ARRAY, VOIDPTR, BOOLE*);


/* 
  POWELLPROGRESS_FCT
  ******************

  This type is used for the Powell optimiser seeking an optimal
  (maximum or minimum) in a multi-variate setting.

  The type defines a function that is used for progress reporting.


  Prototype:

    BOOLE (*POWELLPROGRESS_FCT)(VOIDPTR, INTI, FL64);

  Input:
          VOIDPTR   pdata Problem specific data container

          INTI      iter  The iteration count in the Powell search.

          FL64      fpot  The current value of the potential function.

  Returns:
          A boolean indicating whether premature termination has been
          signalled. The function returns True when premature termination
          has been requested, and False if not.

  Examples:

*/
typedef BOOLE (*POWELLPROGRESS_FCT)(VOIDPTR, INTI, FL64);




/***** defines   *******************************************************/

#define SPLINE_MAX 0.99E30      /* Used for cubic spline interpolation */

/*** macros  **********************************************************/

#ifdef GETMAX
#undef GETMAX
#endif
#define GETMAX(a, b)   ((a) > (b) ? (a) : (b))

#ifdef GETMIN
#undef GETMIN
#endif
#define GETMIN(A, B)   ((A) < (B) ? (A) : (B))

#ifdef SQR
#undef SQR
#endif
#define SQR(x)         ((x)*(x))

#ifdef  SafeDivide
#undef  SafeDivide
#endif
#define SafeDivide(num, den, tol, def) \
  ( -(tol) < (den) && (den) < (tol) ? (def) : (num)/(den) )

/***** function prototypes (scstat.c) **********************************/


/* Public functions */

extern FL64 Stat_Mean(INTI n, FL64ARRAY x) ;

extern FL64 Stat_Stdev(INTI n, FL64ARRAY x) ;

extern FL64 Stat_Correl(INTI n, FL64ARRAY x, FL64ARRAY y) ;

extern FL64 Stat_NormalizedNormal(FL64 x) ;

extern FL64 Stat_CumulativeNormal(FL64 x, FL64 mean, FL64 std) ;

extern FL64  Stat_InvNormalizedNormal(FL64 p) ;

extern FL64  Stat_BIS_InvNormalizedNormal(FL64 p) ;


extern BOOLE Stat_ConfidenceNormal(FL64 conf,
                                   FL64 mean,
                                   FL64 std,
								   FL64 *limit, 
								   void *holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */

extern FL64 Stat_CumulativeLognormal(FL64 x, FL64 mean, FL64 std) ;

extern BOOLE Stat_Binomial(INTI n, INTI p, FL64 prob, FL64 *res) ;

extern FL64 Stat_BivariateNormal(FL64 x, FL64 y, FL64 corr, 
                                 BOOLE fixacc, FL64 acc) ;

extern FL64 Stat_BivariateNormal_Vasicek(FL64 x, FL64 y, 
                                         FL64 corr, FL64 acc) ;

extern FL64 Stat_BivariateNormal_Drezner(FL64 a, FL64 b, FL64 c) ;

/* Private functions */

extern BOOLE Beta_Incompl(FL64 a, FL64 b, FL64 x, FL64 *res) ;
extern BOOLE Beta_Contfrac(FL64 a, FL64 b, FL64 x, FL64 *res) ;
extern FL64  Log_Gamma(FL64 xx) ;
extern FL64  Cum_Biv_Norm_Neg(FL64 a, FL64 b, FL64 c) ;
extern FL64  f_anc(FL64 x, FL64 y, FL64 a, FL64 b, FL64 c) ;


/***** function prototypes (scmath.c) **********************************/


/* Public functions */
extern FL64ARRAY Math_IntpolArray(FL64ARRAY  x0,
                                   INTI       m,
                                   INTI       n,
                                   FL64ARRAY  x,
                                   FL64ARRAY  y,
                                   INTPOLCONV intpol) ;

extern FL64 Math_Interpolation(FL64       ax0,
                               INTI       n,
                               FL64ARRAY  ax,
                               FL64ARRAY  ay,
                               INTPOLCONV conv) ;

extern FL64 Math_2Dinterpolation(FL64       x10,
                          FL64       y20,
                          FL64ARRAY  x1,
                          INTI       nx1,
                          FL64ARRAY  x2,
                          INTI       nx2,
                          FL64MATRIX y,
                          INTPOLCONV conv) ;

extern FL64 Math_WeightedAvg(INTI      n,
                              FL64ARRAY value,
                              FL64ARRAY weight) ;

extern BOOLE Math_SVD(FL64MATRIX a1, 
                         INTI m, 
                         INTI n, 
                         INTI maxit,
                         FL64ARRAY w1,
                         FL64MATRIX v1) ;

extern void Init_ITERCTRL(ITERCTRL *ictrl) ;

/* Private functions */
extern FL64 Math_linintpol(FL64  xlow,
                           FL64  xup,
                           FL64  ylow,
                           FL64  yup,
                           FL64  x0,
                           BOOLE extrapol) ;

extern void Math_Cspl_Prep(FL64ARRAY x,
                        FL64ARRAY y,
                        INTI      n,
                        FL64      yp1,
                        FL64      ypn,
                        FL64ARRAY y2) ;

extern void Math_Cspl_Intpol(FL64ARRAY xa,
                        FL64ARRAY ya,
                        FL64ARRAY y2a,
                        INTI      n,
                        FL64      x,
                        FL64      *y) ;

extern BOOLE Math_LUdecomp(FL64MATRIX a,
                           INTI       n,
                           INTIARRAY  perm,
                           FL64       *parity) ;

extern void Math_LUsolv(FL64MATRIX a,
                        INTI       n,
                        INTIARRAY  perm,
                        FL64ARRAY  b) ;

extern FL64 Math_Intpol_Bspline(FL64      t,
                         INTI      p,
                         INTI      k,
                         INTI      n,
                         INTI      dim,
                         FL64ARRAY knots) ;

extern FL64 Math_Round(FL64  x, 
                          INTI  roundOff);

extern FL64 Math_Floor(FL64 x, FL64 limit);

extern INTI Math_LaGuerre(INTI x1, INTI x2, INTI x3);

extern FL64 Math_Ran1(FL64      *idum,
                 UN32      *ix1,
                 UN32      *ix2,
                 UN32      *ix3,
                 FL32ARRAY r,
                 BOOLE     init,
                 INTI      count) ;

extern FL64 Math_Determinant(FL64MATRIX m,
                                INTI       n);

extern void Math_Mult(FL64MATRIX a, 
                        FL64MATRIX b,
                        INTI       dim1,
                        INTI       dim2,
                        INTI       dim3,
                        FL64MATRIX c) ;

extern FL64MATRIX Math_Transpose(FL64MATRIX a,  
                                 INTI n,
                                 INTI m) ;


extern FL64MATRIX Math_Inverse (FL64MATRIX a,  
                                INTI n) ;

extern FL64 Math_exp_cutoff(FL64 x);

extern FL64 Math_sqrt_cutoff(FL64 x);

/***** function prototypes (ortho.c) ********************************/

/* Private functions */

extern void Math_MatrixVectorMult(INTI       dim,
                                 FL64MATRIX inv,
                                 FL64ARRAY  icov,
                                 FL64ARRAY  out);

extern void Free_ORTODECOMP(ORTODECOMP* x);

extern ORTODECOMP Math_SYM2OrthoDecomp(FL64MATRIX smtrx, 
                                   INTI       dim, 
                                   INTI       nfac,
                                   INTI       maxit,
                                   BOOLE*     ok);

extern BOOLE Math_SYM2ODS(INTI dim, FL64MATRIX smtrx, INTI maxit) ;

extern BOOLE Math_SYM2OD(INTI dim, 
                              FL64MATRIX s, 
                              FL64ARRAY ev, 
                              INTI maxit) ;
extern void Math_SYM2TD(FL64MATRIX mtrx, 
                           INTI dim, 
                           FL64ARRAY diag, 
                           FL64ARRAY off) ;
extern BOOLE Math_TD2OD(FL64ARRAY diag, 
                           FL64ARRAY off, 
                           INTI dim, 
                           FL64MATRIX mtrx, 
                           INTI maxit) ;

extern BOOLE Math_CholeskyDecomp(INTI dim, 
                                    FL64MATRIX d,  
                                    FL64MATRIX a,  
                                    INTI*      fail) ; 

extern BOOLE Math_InvertSmtrx(INTI    dim,
                     FL64MATRIX in,
                     FL64MATRIX out,
                     FL64*      determ) ;

extern BOOLE Math_SYM2Det(INTI nfac, 
                      INTI dim, 
                      FL64MATRIX matrix, 
                      INTI  maxit,
                      FL64* determ);

/***** function prototypes (newton.c) **********************************/

/* Private functions */
extern NR_ERR Newton_Raphson(NEWTONRAPHSON_FCT fctn,  
	VOIDPTR pdata, ITERCTRL* ctrl, FL64* x, void  *holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */
extern BOOLE Math_RootBracket(NEWTONRAPHSON_FCT fctn,  
                              VOIDPTR pdata, ITERCTRL *ctrl,
							  FL64* x1, FL64* x2, VOIDPTR holi);  /* PMSTA-29444 - SRIDHARA - 050318 */
extern BOOLE Math_PosRootBracket(NEWTONRAPHSON_FCT fctn,  
                              VOIDPTR pdata, ITERCTRL *ctrl,
							  FL64* x1, FL64* x2, VOIDPTR holi); /* PMSTA-29444 - SRIDHARA - 050318 */


/***** function prototypes (newton.c) **********************************/

/* Private functions */

extern BOOLE Powell(FL64ARRAY          x, 
                    VOIDPTR            pdata, 
                    FL64MATRIX         xi,   
                    INTI               n,
                    FL64               ftol, 
                    FL64               fmin,                     
                    POWELLPROGRESS_FCT f_prg, 
                    BRENT_FCT          f_1dim,
                    POWELL_FCT         f_ndim,
                    INTI               *iter, 
                    FL64               *fret, 
                    BOOLE              *ok);

extern void DirectionMin_NoGrad(FL64ARRAY   x,
                                VOIDPTR     pdata,
                                FL64ARRAY   xi,
                                INTI        n,
                                BRENT_FCT   f_1dim,
                                FL64        *fret,
                                BOOLE       *ok);

extern void BracketMin_NoGrad(FL64        *ax,
                              FL64        *bx,
                              FL64        *cx,
                              FL64        *fa,
                              FL64        *fb,
                              FL64        *fc,
                              VOIDPTR     pdata,
                              BRENT_FCT   f_1dim,
                              FL64ARRAY   point,
                              FL64ARRAY   direction,
                              BOOLE       *ok);

extern FL64 Brent(FL64        ax,
            FL64        bx,
            FL64        cx,
            BRENT_FCT   f_1dim,
            VOIDPTR     pdata,
            FL64ARRAY   point,
            FL64ARRAY   direction,
            FL64        tol,
            FL64        *xmin,
            BOOLE       *ok);

#ifdef __cplusplus
}
#endif

#endif

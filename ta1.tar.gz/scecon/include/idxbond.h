/* @(#)idxbond.h	1.9 (SimCorp) 99/10/02 16:11:08 */

#ifndef IDXBOND_H_INCLUDED

#define IDXBOND_H_INCLUDED

/************************************************************************
*                                                                       *
*    project    SCecon                                                  *
*                                                                       *
*    filename   bond.h                                                  *
*                                                                       *
*    this file contains definitions and function prototyping for the    *
*    routines in the SCecon Bond module                                 *
*                                                                       *
************************************************************************/

/***** includes ********************************************************/
#include <bond.h>


/***** C++ Convenience *************************************************/
#ifdef __cplusplus
extern "C" {
#endif



/*,,SOT,,

INDEXFAC: Type for holding index factor data
--------------------------------------------

This type is defined as

        typedef struct indexfac_tag
        {
            FL64        baseidx ;
            PLAN_STR    *idxfac ;
            CALCONV     cal ;
            BOOLE       round ;
            INTI        roundOff ;
        }   INDEXFAC ;

The type can hold information about index factor used for index loan and 
index bond calculation.

The various entries are defined as:

            baseidx is the base index factor. This is relevant for eg. 
            Swedish index bond. Factors in idxfac are intepreted
            relative to this.
            To use factors in idxfac as published by the Copenhagen
            Stock Exchange for danish indexed mortgage bonds, use
            baseidx = 100.

            idxfac holds the index factor and the corresponding dates.
            Idxfac should contain factors beyond any date of interest.
            Interpolation in this structure assumes idxfac is constant
            beyond last date, meaning NO inflation beyond the idxfac
            structure.

            cal is the calendar convention. This is used in connection with
            linear interpolation in the index factors.
            For danish indexed mortgage bonds this should be EU30E360.

            If round is False NO rounding off is performed (in connection 
            interpolation in the index factors). If round is True then the
            interpolated index factors are rounded off to roundOff decimals.

Note that the Danish IS index loans the debtor index factors are given as

            0.75 * MIN(NPI(t), TLI(t)),  if NPI(t) >= 0 and TLI(t) >= 0,
                                   0.0,  if NPI(t) <= 0 and TLI(t) > 0,  
                                TLI(t),  if TLI(t) < 0.               
                                                      
Here NPI(t) denotes the Net Price Index ('nettoprisindekset') at time t and
TLI(t) denotes Industrial Wage Index (the 'timeloensindeks for industriens
arbejdere') at time t. It is assumed NPI and TLI are scaled according to
baseidx.

Note that NPI and TLI are used with a delay when pricing bonds. See the
INDEXLOAN documentation for additional information on this.

The current value of the indices used for danish index bonds are published
by the Copenhagen Stock Exchange. The NPI and TLI are epublished by
Statistics Denmark.

,,EOT,,*/

typedef struct indexfac_tag
{
    FL64        baseidx ;
    PLAN_STR    *idxfac ;
    CALCONV     cal ;
    BOOLE       round ;
    INTI        roundOff ;
}   INDEXFAC ;

/*,,SOT,,

INDEXLOANTYPE: Contract information for index loans
---------------------------------------------------

  This type is defined as

  typedef enum indexloantype_tag
  {
      IS_DEBITOR,
      IS_CREDITOR,
      AI,
      SI,
      I
  } INDEXLOANTYPE ;


  The loan types defined here are all Danish indexed loan types
  The INDEXLOANTYPE of an INDEXLOAN struct describe the
  characteristics of the cash flows various loans. All loans
  are with semiannual payments

  IS_DEBITOR indicates the debitor side of an IS loan. IS loans
  are issed for housing as cash loans. Redemptions are indexed
  by a composite index known as the debitor indeks, based on the
  net price index (NPI) and industrial wage index (TLI).
  Remaining notional is indexed by NPI. This generates
  rather complicated looking cashflows under inflationary
  circumstances. The basic loan type is a serial  loan, but this can be
  very much obscured by the indexation.

  IS_CREDITOR indicates the creditor side of an IS loan. Since the loans
  are issued as cash loans the only link between creditor and debitor side
  is the equality of net payemnt, whereas the distribution into interest
  and repayment can vary a great deal.

  Since notional is indexed by NPI and repayment by the composite
  debtor index there may be remaining notional that needs
  to be refinanced at expiry.

  AI loans are loans for "green" energy (i.e. wind and solar energy plants).
  They are issued as annuities indexed by NPI with an initial interest only
  term. They are symmetrical on creditor and debtor sides.

  SI loans are loans for shipbuilding. SCecon considers only the creditor
  side of such loans. They are serial loans with 9 (4 1/2 years) interest
  only terms and repayment over 10 years. They are indexed by NPI.

  I loans are serial loans indexed by NPI with an initial interest only term.

,,EOT,,*/

typedef enum indexloantype_tag
{
  INDEXLOANTYPE_INIT = -1,
  IS_DEBITOR,
  IS_CREDITOR,
  AI,
  SI,
  I
} INDEXLOANTYPE ;

/*,,SOT,,

INDEXLOAN: Type for holding index loan data
-------------------------------------------

This type is defined as

        typedef struct indexloan_tag
        {
            FL64          coupon ;
            FL64          rpct ;
            BOOLE         round ;
            PMTFREQ       freq ;
            FL64          dprinc ;
            FL64          doutstand ;
            FL64          coutstand ;
            DATESTR       effective ;
            DATESTR       first_coupon ;
            DATESTR       first_amort ;
            DATESTR       last ;
            CALCONV       cal ;
            PERIOD        delay ;
            INDEXLOANTYPE iltype ;
            FL64          amort ;
            EXRULE        exc ;
            CALCONV       accru_cal ;
        }   INDEXLOAN ;

The type can hold information for index loans. Danish IS, AI, SI and I loans
are supported. Note that in general INDEXLOAN computations are not
"pr. 100 notional" but in actual amounts as defined by the *outstand
elements below.

The various entries are defined as:

            coupon is the annually nominel coupon in percent

            rpct is the repayment percentage.
            Note that rpct is repayment pr payment date, NOT annualised
            repayment percentage. Used for IS loans only.
            For other loantypes this quantity is computed.

            round toggles round to two decimals (i.e. "oere" amounts).
            True means rounding is applied. This was the standard
            before introduction of this switch

            freq is the payment frequency.

            dprinc is the present debtor principal ('debitor hovedstol'). 
            MUST be index factor adjusted. 
            For cashflow generation from emission to maturity dprinc must 
            be the proceeds of the loan ('laaneprovenuet') multiplied the
            debtor index factor on the next payment date and divided by the
            debtor index factor on effective date.

            doutstand is the present debtor outstanding ('debitor restgaeld').
            MUST be index factor adjusted. 
            For cashflow generation from emission to maturity doutstand must 
            be  the proceeds of the loan ('laaneprovenuet') multiplied the
            creditor index factor on the next payment date and divided by the
            creditor index factor on effective date.

            coutstand is the present creditor outstanding 
            ('kreditor restgaeld'). MUST be index factor adjusted. 
            For cashflow generation from emission to maturity coutstand must
            be 'the proceeeds of the loan ('laaneprovenuet')
            divided by the price at issue ('kursen paa koebstidspunktet')
            multiplied the creditor index factor on the next payment date and 
            divided by the creditor index factor on effective date.

            effective is the date from which coupons are accrued.

            first_coupon is the first coupon date. The fields effective and
            first_coupon must be coherently set up: i.e. Effective must be the
            start date for interest accruel for the coupon paying at effective.

            first_amort is the first amortisation date. Please note that 
            first_amort must be later than or equal to first_coupon. If 
            first_coupon and first_amort differs then first_amort must be
            a number of freq's later than first_coupon.

            last is the latest maturity date.

            cal is the calendar used when computing the cashflow.
            It is assumed that all regular coupons are of even size (COUPONBASE
            EVENCOUP) but an odd first coupon must be corrected and
            cal is used for this.

            delay is the delay used when looking up index factors.
            When looking up index factor
            on effective (needed if the first period is short) a delay of
            0 days is used. Be aware that the indices published by the
            Copenhagen Stock Exchange incorporate the relevant delay in
            observing all used inflation indices, so when using these
            indices a delay of 0 days should be used.
            When using Net Price Indices and
            Industrial Wage averages as published by Statistics Denmark, the
            delay should be set as specified for the bondtype in question.
            See : "Lovbekendtgoerelse nr. 572 af 15/9-89 om indeksregulerede
            realkreditlaan".

            iltype signals what loan cashflow to generate.

            amort is an initial agreed amortisation of doutstand paid on 
            first_amort. ONLY used if amort > 0.0 . amort should be quoted 
            as an amount in danish 'kroner'. SI loans only.

            exc is the ex-coupon rules to be used

            accru_cal is the calendar used when computing
            accrued interest on non-coupon days
            
,,EOT,,*/


typedef struct indexloan_tag
{
    FL64          coupon ;
    FL64          rpct ;
    BOOLE         round ;
    PMTFREQ       freq ;
    FL64          dprinc ;
    FL64          doutstand ;
    FL64          coutstand ;
    DATESTR       effective ;
    DATESTR       first_coupon ;
    DATESTR       first_amort ;
    DATESTR       last ;
    CALCONV       cal ;
    PERIOD        delay ;
    INDEXLOANTYPE iltype ;
    FL64          amort ;
    EXRULE        exc ;
    CALCONV       accru_cal ;
}   INDEXLOAN ;


/*,,SOT,,

INDEXBOND: Type for holding index bond data
-------------------------------------------

This type is defined as

        typedef struct indexbond_tag
        {
            FIXPAY      fixp ;
            PERIOD      pv_delay ;
            PERIOD      cflw_delay ;
            BOOLE       indexednotional ;
        }   INDEXBOND ;

The type can hold information for index bonds. Currently Danish and Swedish
index bonds are supported.

The various entries are defined as:

            fixp is the index bond definition. For Danish index bonds the
            cashflow that defines the index bond ('ydelsesraekke') should be
            inserted in fixp.repay.irreg. When indexednotional is True
            irregular repayments are assumed to be entered as indexed to
            first repayment date. Regular paying cashflows are assumed to be
            indexed to effective date (fixp.fix.effective).
            With indexednotional is False, all quantities are assumed to be
            in unindexed.
            Note that in contrast to the use of the FIXPAY structure elsewhere
            in the library, it is here not used to represent payments
            "pr. 100 notional" but rather indexbonds are in absolute terms
            when considering irregular amortisations.
            
            

            pv_delay is the delay used when looking up index factors 
            which are used for present value calculations.
        
            cflw_delay is the delay used when looking up index factors
            which are used for cashflow generation.

            indexednotional indicates whether notional is assumed indexed
            or not. 
            For swedish indexed bonds issued by the Swedish National Debt
            Office, False is the correct setting whereas True should be
            the setting for danish index bonds, when using irregular
            payments defining an indexed bond.

,,EOT,,*/


typedef struct indexbond_tag
{
    FIXPAY      fixp ;
    PERIOD      pv_delay ;
    PERIOD      cflw_delay ;
    BOOLE       indexednotional ;
}   INDEXBOND ;


/* std. Newton Raphson data setup as documented
   in main/newton.c and main/scmath.h*/


typedef struct indexloanint_tag
{
    DATESTR      *analys ;
    INDEXLOAN    *idxloan ;
    INDEXFAC     *idxfac ;
    DISCFAC      *df ;
    HOLI_STR     *holi ;
    DFSPREAD     *dfs ;
    FL64         pwfac ;
    FL64         shock ;
    FL64         p ;
    BOOLE        indexadj ;
} INDEXLOANINT ;


typedef struct indexbondint_tag
{
    INDEXBOND    *idxbond ;
    TRADEINFO    *trade ;
    INDEXFAC     *idxfac ;
    DISCFAC      *df ;
    HOLI_STR     *holi ;
    DFSPREAD     *dfs ;
    FL64         shock ;
    BOOLE        indexadj ;
} INDEXBONDINT ;


extern CFLWARRAY IndexLoan_GenrCflw(DATESTR   *analys,
                                        INDEXLOAN *idxloan,
                                        INDEXFAC  *debfac,
                                        INDEXFAC  *crefac,
                                        HOLI_STR  *holi) ;


extern AIRESULT IndexLoan_Accruint(DATESTR   *analys,
                                      INDEXLOAN *idxloan,
                                      INDEXFAC  *crefac,
                                      BOOLE     indexadj,
                                      HOLI_STR  *holi) ;


extern FL64 IndexLoan_YTM2Price(FL64        ytm,
                                    DATESTR     *analys,
                                    INDEXLOAN   *idxloan,
                                    INDEXFAC    *debfac,
                                    INDEXFAC    *crefac,
                                    YTMCONV     *ytmc,
                                    HOLI_STR    *holi,
                                    RISKCONV    risk,
                                    BOOLE       modf,
                                    BOOLE       indexadj,
                                    FL64        *dp,
                                    FL64        *ddp) ;

extern BOOLE IndexLoan_YTM2Yield(DATESTR     *analys,
                                     FL64        price,
                                     INDEXLOAN   *idxloan,
                                     INDEXFAC    *debfac,
                                     INDEXFAC    *crefac,
                                     YTMCONV     *ytmc,
                                     BOOLE       indexadj,
                                     HOLI_STR    *holi,
                                     ITERCTRL    *ictrl,
                                     FL64        *ytm) ;

extern FL64 IndexLoan_YTM2Duration(FL64        ytm,
                                      DATESTR     *analys,
                                      INDEXLOAN   *idxloan,
                                      INDEXFAC    *debfac,
                                      INDEXFAC    *crefac,
                                      YTMCONV     *ytmc,
                                      HOLI_STR    *holi) ;

extern FL64 IndexLoan_DF2Price(DATESTR      *analys,
                                   INDEXLOAN    *idxloan,
                                   INDEXFAC     *debfac,
                                   INDEXFAC     *crefac,
                                   DISCFAC      *df,
                                   HOLI_STR     *holi,
                                   DFSPREAD     *dfs,
                                   RISKSET      *risk,
                                   BOOLE        indexadj,
                                   FL64         *dp,
                                   FL64         *ddp) ;

extern CFLWARRAY ISLoan_GenrCflw(DATESTR   *analys,
                                        INDEXLOAN *idxloan,
                                        INDEXFAC  *debfac,
                                        INDEXFAC  *crefac,
                                        HOLI_STR  *holi,
                                        BOOLE     usecred) ;

extern FL64 ISLoan_YTM2Price(FL64        ytm,
                             DATESTR*    analys,
                             INDEXLOAN*  idxloan,
                             INDEXFAC*   debfac,
                             INDEXFAC*   crefac,
                             YTMCONV*    ytmc,
                             HOLI_STR*   holi,
                             RISKCONV    risk,
                             BOOLE       modf,
                             BOOLE       indexadj,
                             FL64*       dp,
                             FL64*       ddp);


extern BOOLE IndexLoan_DF2ImpliedInflation(DATESTR*    analys,
                            FL64        p,
                            INDEXLOAN*  idxloan,
                            DISCFAC*    df,
                            HOLI_STR*   holi,
                            DFSPREAD*   dfs,
                            CALCONV     indexcal,
                            FL64        pwfac,
                            BOOLE       indexadj,
                            ITERCTRL    *ictrl,
                            FL64 *inflation) ;

extern CFLWARRAY IndexBond_GenrCflw(TRADEINFO   *start,
                                        INDEXBOND   *idxbond,
                                        INDEXFAC    *idxfac,
                                        HOLI_STR    *holi) ;

extern CFLWARRAY IndexBond_GenrPeriod(TRADEINFO *start,
                                          TRADEINFO *end,
                                          INDEXBOND *idxbond,
                                          INDEXFAC  *idxfac,
                                          HOLI_STR  *holi) ;

extern AIRESULT IndexBond_Accruint(TRADEINFO *basis,
                                      INDEXBOND *idxbond,
                                      INDEXFAC  *idxfac,
                                      BOOLE     indexadj,
                                      HOLI_STR  *holi) ;

extern FL64 IndexBond_YTM2Price(FL64        ytm,
                                    TRADEINFO   *trade,
                                    INDEXBOND   *idxbond,
                                    INDEXFAC    *idxfac,
                                    YTMCONV     *ytmc,
                                    HOLI_STR    *holi,
                                    RISKCONV    risk,
                                    BOOLE       modf,
                                    BOOLE       indexadj,
                                    FL64        *dp,
                                    FL64        *ddp) ;

extern BOOLE IndexBond_YTM2Yield(TRADEINFO   *trade,
                                    INDEXBOND   *idxbond,
                                    INDEXFAC    *idxfac,
                                    YTMCONV     *ytmc,
                                    BOOLE       indexadj,
                                    HOLI_STR    *holi,
                                    ITERCTRL    *ictrl,
                                    FL64        *ytm) ;

extern FL64 IndexBond_YTM2Duration(FL64      ytm,
                                      TRADEINFO *trade,
                                      INDEXBOND *idxbond,
                                      INDEXFAC  *idxfac,
                                      YTMCONV   *ytmc,
                                      HOLI_STR  *holi) ;

extern FL64 IndexBond_DF2Price(TRADEINFO    *trade,
                                   INDEXBOND    *idxbond,
                                   INDEXFAC     *idxfac,
                                   DISCFAC      *df,
                                   HOLI_STR     *holi,
                                   DFSPREAD     *dfs,
                                   RISKSET      *risk,
                                   BOOLE        indexadj,
                                   FL64         *dp,
                                   FL64         *ddp) ;

extern FL64ARRAY IndexBond_DF2Delta(TRADEINFO    *trade,
                                       INDEXBOND    *idxbond,
                                       INDEXFAC     *idxfac,
                                       DISCFAC      *df,
                                       HOLI_STR     *holi,
                                       DFSPREAD     *dfs,
                                       BOOLE        indexadj,
                                       DELTASET     *ds) ;

extern BOOLE IndexBond_DF2ImpliedInflation(TRADEINFO*   trade,
                            INDEXBOND*  idxbond,
                            DISCFAC*    df,
                            HOLI_STR*   holi,
                            DFSPREAD*   dfs,
                            CALCONV     indexcal,
                            BOOLE       indexadj,
                            ITERCTRL    *ictrl,
                            FL64 *inflation) ;

extern FL64ARRAY IndexLoan_DF2Delta(DATESTR      *analys,
                                       INDEXLOAN    *idxloan,
                                       INDEXFAC     *debfac,
                                       INDEXFAC     *crefac,
                                       DISCFAC      *df,
                                       HOLI_STR     *holi,
                                       DFSPREAD     *dfs,
                                       BOOLE        indexadj,
                                       DELTASET     *ds) ;

extern FL64 Index_Interpolation(DATESTR *date, 
                                   PERIOD *delay, 
                                   INDEXFAC *fac) ;

extern void Free_INDEXBOND(INDEXBOND *idxbond) ;

extern void Free_INDEXLOAN(INDEXLOAN *idxloan) ;


extern void Free_INDEXFAC(INDEXFAC *idxfac) ;

extern void Index_FlatIndex(FL64 inflation, INDEXFAC *idxfac, HOLI_STR  *holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */

/*
Private functions
*/

extern AIRESULT ISLoan_Accruint(DATESTR    *analys,
                                INDEXLOAN   *idxloan,
                                INDEXFAC    *crefac,
                                BOOLE       indexadj,
                                HOLI_STR    *holi,
                                BOOLE       usecred) ;

                                           
extern PAYDAYDEF INDEXLOAN_Set_PAYDAYDEF(INDEXLOAN *idxloan) ;

extern FL64 IndexBond_StartIndex(INDEXBOND *idxbond,
                          INDEXFAC *idxfac) ;

extern FL64 IndexBond_RemainingNotional(DATESTR *analys,
                            INDEXBOND *idxbond,
                            HOLI_STR *holi) ;

extern INDEXFAC Index_ShockIndex(INDEXFAC *idxfac,
                                 FL64 shock, HOLI_STR  *holi) ;  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */

extern INDEXFAC Index_PrepIndex(INDEXFAC *idxfac) ;

extern void Index_SetINDEXLOANINT(DATESTR      *analys,
                        INDEXLOAN    *idxloan,
                        INDEXFAC     *idxfac,
                        DISCFAC      *df,
                        HOLI_STR     *holi,
                        DFSPREAD     *dfs,
                        FL64         shock,
                        FL64         pwfac,
                        BOOLE        indexadj,
                        FL64         p,
                        INDEXLOANINT *ii) ;

extern void Index_GetINDEXLOANINT(DATESTR      **analys,
                        INDEXLOAN    **idxloan,
                        INDEXFAC     **idxfac,
                        DISCFAC      **df,
                        HOLI_STR     **holi,
                        DFSPREAD     **dfs,
                        FL64         *shock,
                        FL64         *pwfac,
                        BOOLE        *indexadj,
                        FL64         *p,
                        INDEXLOANINT *ii) ;

extern void Index_SetINDEXBONDINT(INDEXBOND    *idxbond,
                        TRADEINFO    *trade,
                        INDEXFAC     *idxfac,
                        DISCFAC      *df,
                        HOLI_STR     *holi,
                        DFSPREAD     *dfs,
                        FL64         shock,
                        BOOLE        indexadj,
                        INDEXBONDINT *ii) ;

extern void Index_GetINDEXBONDINT(INDEXBOND    **idxbond,
                        TRADEINFO    **trade,
                        INDEXFAC     **idxfac,
                        DISCFAC      **df,
                        HOLI_STR     **holi,
                        DFSPREAD     **dfs,
                        FL64         *shock,
                        BOOLE        *indexadj,
                        INDEXBONDINT *ii) ;

extern BOOLE IndexLoan_NewtonRaphson(FL64    x, 
                            void*   y,
                            BOOLE   grad,
                            FL64*   fx, 
                            FL64*   dfx,
							void*   hol) ;   /* PMSTA-29444 - SRIDHARA - 050318 */

extern BOOLE IndexBond_NewtonRaphson(FL64    x, 
                            void*   y,
                            BOOLE   grad,
                            FL64*   fx, 
                            FL64*   dfx,
							void*   hol);   /* PMSTA-29444 - SRIDHARA - 050318 */

extern void IndexLoan_GenrIndexBond(INDEXLOAN *idxloan,
               DATESTR   *analys,
               INDEXBOND *idxbond,
               TRADEINFO *basis) ;



#ifdef __cplusplus
}
#endif

#endif

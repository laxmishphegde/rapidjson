/* SCID @(#)scenario.h	1.4 (SimCorp) 99/02/19 14:12:27 */

#ifndef SCENARIO_H_INCLUDED

#define SCENARIO_H_INCLUDED

/************************************************************************
*                                                                       *
*    project    SCecon                                                  *
*                                                                       *
*    filename   scenario.h                                              *
*                                                                       *
*    this file contains definitions and function prototyping for the    *
*    routines in the SCecon Scenario function module.                   *
*                                                                       *
************************************************************************/

/***** includes  *******************************************************/
#include <scecon.h>
#include <disc.h>
#include <bond.h>
#include <swap.h>
#include <idxbond.h>

/***** C++ Convenience *************************************************/
#ifdef __cplusplus
extern "C" {
#endif


/*,,SOT,,

SCENARIO, SCENARIOARRAY, SCENARIOLIST: Definition of a scenarios
----------------------------------------------------------------

Definition:

        typedef struct scenario_tag
        {
            INTI        nbuck ;      
            BUCKETARRAY scen ;     
        }   SCENARIO ;

The data are interpreted as:

        nbuck is a list of bucket/grid points in the scenario.

        scen[nbuck] is the list of how the various grid points on the
        zero curve are shocked in the scenario 
        (Defined as a BUCKETARRAY).

Lists of SCENARIO's can be handled via SCENARIOARRAY's:


        typedef SCENARIO * SCENARIOARRAY ;

Free using Free_SCENARIO() and Free_SCENARIOARRAY()

SCENARIOARRAYS are handled in a SCENARIOLIST:

        typedef struct scenariolist_tag
        {
            INTI        nscen ;
            SCENARIOARRAY scens ;     
        }   SCENARIOLIST ;

The data are interpreted as:

        nscen is the number of scenarios

        scens[nscen] is the list of scenarios (each showing the various 
        grid points on the zero curve are shocked in each).
        List of nscen scenarios 
        (each defined as a SCENARIO).

This struct is utilised by Disc_ScenarioPrep() to generate a DELTASET
struct. Using a DELTASET the SCecon routines security_model2delta() can 
be used to calculate all the scenario PV differences.

Free using Free_SCENARIOLIST().  

see also Set_SCENARIOLIST

,,EOT,,*/

typedef struct scenario_tag
{
    INTI        nbuck ;        
    BUCKETARRAY scen ;       /* nbuck elements */
}   SCENARIO ;

typedef SCENARIO * SCENARIOARRAY ;

typedef struct scenariolist_tag
{
    INTI        nscen ;
    SCENARIOARRAY scens ;    /* nscen BUCKETARRAY's */
}   SCENARIOLIST ;


/*,,SOT,,

FXSHOCKSET: struct for defining FX data for scenario calculations
-----------------------------------------------------------------

This type is defined as:

        typedef struct fxshockset_tag
        {
            FL64ARRAY      shocked ;
            INTI           nshock ;
            RISKTOKEN      token ;
        }   FXSHOCKSET ;

The data elements have the following interpretation:

    shocked[nshock] is a list of (nshock) shocked FX rates.
        These rates SHOULD be generated using FX_ShockPrep().

    nshock is the number of rates in shocked.
        Usually a FXSHOCKSET, a EQTYSHOCKSET, and a DELTASET is 
        used simultaneously (eg. OptEqty_Black2ScenBPV()). 
        In theses cases the nshock, the nshock of the EQTYSHOCKSET,
        and the nshock field of the DELTASET MUST identical.

    token|NULL is a risk factor token. Used to identify the FX rate
        risk factor to which the shocks refers.
        Used for Risk Position calculations in the routines
        *_*2RiskPos() - used for VAR calculations.
        Not used in *_*2delta() routines for delta vector / 
        scenario calculations.
        If not used in the actual calculation enter a NULL.

Free using Free_FXSHOCKSET().  

FXSHOCKSET is returned by FX_ShockPrep().

see also Set_FXSHOCKSET

,,EOT,,*/

typedef struct fxshockset_tag
{
    FL64ARRAY   shocked ;
    INTI        nshock ;
    RISKTOKEN   token ;
}   FXSHOCKSET ;




/*,,SOT,,

EQTYSHOCKSET: struct for defining EQTY data for scenario calculations
---------------------------------------------------------------------

This type is defined as:

        typedef struct eqtyshockset_tag
        {
            FL64ARRAY      shocked ;
            INTI           nshock ;
        }   EQTYSHOCKSET ;

The data elements have the following interpretation:

        shocked[nshock] is a list of (nshock) shocked Equity spot
        prices. These spot prices SHOULD be generated using
        FX_ShockPrep().

        nshock is the number of spot prices in shocked.
        Usually a FXSHOCKSET, a EQTYSHOCKSET, and a DELTASET is 
        used simultaneously (eg. OptEqty_Black2ScenBPV()). 
        In theses cases the nshock, the nshock of the FXSHOCKSET,
        and the nshock field of the DELTASET MUST identical.

Free using Free_EQTYSHOCKSET().  

EQTYSHOCKSET is returned by EQTY_Shock_Prep().

see also Set_EQTYSHOCKSET

,,EOT,,*/

typedef struct eqtyshockset_tag
{
    FL64ARRAY   shocked ;
    INTI        nshock ;
}   EQTYSHOCKSET ;


/*** prototypes  (scenario.c) *****************************************/


/* Public functions */

extern DELTASET Disc_ScenarioPrep(DISCFAC      *df,
                                   SCENARIOLIST *scen,
                                   HOLI_STR     *holi,
                                   IRRCONV      irr,
                                   PMTFREQ      freq,
                                   BOOLE        dom) ;


extern SCENARIOLIST Set_SCENARIOLIST(SCENARIOARRAY a, INTI n);


extern FXSHOCKSET FX_ShockPrep(FL64 fx_spot,
    FL64ARRAY shocks,
    INTI nshock,
    CCYCODE *ccy);

extern EQTYSHOCKSET EQTY_Shock_Prep(FL64 spot,
    FL64ARRAY shocks,
    INTI nshock);

extern void Free_FXSHOCKSET(FXSHOCKSET *a);
extern void Free_EQTYSHOCKSET(EQTYSHOCKSET *a);

extern SCENARIO Alloc_SCENARIO(INTI nbuck) ;
extern SCENARIOARRAY Alloc_SCENARIOARRAY(INTI nscen) ;
extern void Free_SCENARIO(SCENARIO *ds) ;
extern void Free_SCENARIOARRAY(SCENARIOARRAY ds) ;
extern void Free_SCENARIOLIST(SCENARIOLIST *ds) ;

/* Calculations: */

extern FL64ARRAY  RepoCflw_DF2ScenBPV(DATESTR  *analys,
                        DISCFAC    *df,
                        FL64       fx_spot,
                        CFLW_STR   *xcflw,
                        DATESTR    *matur,
                        PP_STR     *pp,
                        HOLI_STR   *holi,
                        DFSPREAD   *dfs,
                        DELTASET   *ds,
                        FXSHOCKSET *fxs);
extern FL64ARRAY  Cflw_DF2ScenBPV(DATESTR  *analys,
                        DISCFAC    *df,
                        FL64       fx_spot,
                        CFLW_STR   *xcflw,
                        PP_STR     *pp,
                        HOLI_STR   *holi,
                        DFSPREAD   *dfs,
                        DELTASET   *ds,
                        FXSHOCKSET *fxs);
extern FL64ARRAY  Bond_DF2ScenBPV(DATESTR  *analys,
                        DISCFAC    *df,
                        FL64       fx_spot,
                        TRADEINFO  *trade,
                        FIXPAY     *fixp,
                        HOLI_STR   *holi,
                        DFSPREAD   *dfs,
                        DELTASET   *ds,
                        FXSHOCKSET *fxs);
extern FL64ARRAY  Deposit_DF2ScenBPV(DATESTR  *analys,
                        DISCFAC    *df,
                        FL64       fx_spot,
                        DEPOSIT    *depo,
                        HOLI_STR   *holi,
                        DFSPREAD   *dfs,
                        DELTASET   *ds,
                        FXSHOCKSET *fxs);
extern FL64ARRAY IndexLoan_DF2ScenBPV(DATESTR       *analys,
                                          DISCFAC       *df,
                                          FL64          fx_spot,
                                          INDEXLOAN     *idxloan, 
                                          INDEXFAC      *debfac,
                                          INDEXFAC      *crefac,
                                          HOLI_STR      *holi,
                                          DFSPREAD      *dfs,
                                          BOOLE         indexadj,
                                          DELTASET      *ds,
                                          FXSHOCKSET    *fxs) ;
extern FL64ARRAY IndexBond_DF2ScenBPV(DATESTR       *analys,
                                          DISCFAC       *df,
                                          FL64          fx_spot,
                                          TRADEINFO     *trade,
                                          INDEXBOND     *idxbond, 
                                          INDEXFAC      *idxfac,
                                          HOLI_STR      *holi,
                                          DFSPREAD      *dfs,
                                          BOOLE         indexadj,
                                          DELTASET      *ds,
                                          FXSHOCKSET    *fxs) ;

/* Private functions */

extern FXSHOCKSET Set_FXSHOCKSET(FL64ARRAY shocked, 
  INTI nshock, 
  RISKTOKEN token);
extern EQTYSHOCKSET Set_EQTYSHOCKSET(FL64ARRAY shocked, 
  INTI nshock);

extern BOOLE FXSHOCKSET_IsEmpty(FXSHOCKSET *fxs);
extern BOOLE EQTYSHOCKSET_IsEmpty(EQTYSHOCKSET *eqtys);


#ifdef __cplusplus
}
#endif

#endif

/* SCID @(#)capio.h	1.5 (SimCorp) 99/02/19 14:09:35 */

#ifndef CAPIO_H
#define CAPIO_H

/************************************************************************
*                                                                       *
*   project     SCecon                                                  *
*                                                                       *
*   file name   str2conv.h                                              *
*                                                                       *
*   general     This file contains the header file for the example code *
*               in str2conv.c                                           *
*                                                                       *
************************************************************************/

/*** includes **********************************************************/
#include <stdio.h>
#include <string.h>
#include <cap.h>
#include <optbond.h>

#ifdef __cplusplus
extern "C" {
#endif

extern B76SM       Str2B76SM(TEXT txt) ;

extern B76SM Read_B76SM(FILE *in, FILE *out, TEXT dscr);      

extern B76SWTM   Read_B76SWTM(FILE *in, FILE *out) ;

extern FLEXICAPINF    Read_FLEXICAPINF(FILE *in, FILE *out);
extern CAP       Read_CAP(FILE *in, FILE *out) ;
extern CAPLETS   Read_CAPLETS(FILE *in, FILE *out, CALCONV cal, QOTCONV qot,
                              PMTFREQ freq, FL64 Lfix, RATEINDEX *index) ;
extern CAPTION    Read_CAPTION(FILE* in, FILE* out);
extern CAPARRAY Read_CAPARRAY(FILE* in, FILE* out, INTI* ncap);

extern SWAPTIONARRAY Read_SWAPTIONARRAY(FILE *in, FILE *out, INTI *n) ;
extern SWAPTION  Read_SWAPTION(FILE *in, FILE *out) ;

extern SWPTVOL   Read_SWPTVOL(FILE *in) ;


extern CONVTBL    Read_CONVTBL(FILE *in, FILE *out, DATESTR *settle) ;


extern SWAPCALL Read_SWAPCALL(FILE* in, 
                          FILE* out);


#ifdef __cplusplus
}
#endif


#endif



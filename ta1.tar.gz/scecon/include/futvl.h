/* SCCS @(#)futvl.h	1.2 (SimCorp) 99/02/19 14:13:33 */

#ifndef FUTVL_H
#define FUTVL_H

/************************************************************************
*                                                                       *
*    project     SCecon                                                 *
*                                                                       *
*    filename    validate.h                                             *
*                                                                       *
*    general     this file contains declarations, initializations,      *
*                type definitions and function prototyping for the      *
*                validation module of the standard library SCecon       *
*                                                                       *
************************************************************************/

/**** includes *********************************************************/
#include <future.h>
#include <swapval.h>
#include <mm.h>
#include <frn.h>
#include <validate.h>

#ifdef __cplusplus
extern "C" {
#endif

/*** typedefines *******************************************************/


/*** function prototyping *************************************/


extern BOOLE Validate_CFCONV(CFCONV r);
extern BOOLE Validate_CMADJTYPE(CMADJTYPE r) ;
extern BOOLE Validate_COMPMETHOD(COMPMETHOD c) ;
extern BOOLE Validate_QOTCONV(QOTCONV qotconv) ;

extern VALIDATE Validate_AVGFLOAT(AVGFLOAT *cm) ;
extern VALIDATE Validate_CMCONVADJ(CMCONVADJ *cm) ;
extern VALIDATE Validate_CTDRES(CTDRES *x);
extern VALIDATE Validate_DIFFSWAP(DIFFSWAP *x);
extern VALIDATE Validate_FLOATBASE(FLOATBASE *fb) ;
extern VALIDATE Validate_FLOATRATE(FLOATRATE *flt) ;
extern VALIDATE Validate_FRA_STR(FRA_STR *fra_str) ;
extern VALIDATE Validate_FRN(FRN* frn) ;
extern VALIDATE Validate_FUTBOND(FUTBOND *f) ;
extern VALIDATE Validate_FUTBONDBM(FUTBONDBM *x);
extern VALIDATE Validate_RATEINDEX(RATEINDEX *r) ;
extern VALIDATE Validate_REPOBOND(REPOBOND *r) ;
extern VALIDATE Validate_SWAPFLOAT(SWAPFLOAT *fixpay) ;

#ifdef __cplusplus
}
#endif

#endif


/* SCID @(#)bootstrp.h	1.9 (SimCorp) 99/07/06 14:31:29 */

#ifndef BOOTSTRP_H
#define BOOTSTRP_H

/************************************************************************
*                                                                       *
*    project     SCecon                                                 *
*                                                                       *
*    filename    bootstrp.h                                             *
*                                                                       *
*    general     this file contains declarations, initializations,      *
*                type definitions and function prototyping for the      *
*                bootstrappng module of the standard library SCecon     *
*                                                                       *
************************************************************************/


/**** includes *********************************************************/
#include <bond.h>
#include <swap.h>
#include <bootsec.h>
#include <f2c.h>
#include <f2proto.h>

#ifdef __cplusplus
extern "C" {
#endif

/**** defines  *********************************************************/

/*,,SOT,,

FILLTYPE: enumeration for informing on DF filling convention
------------------------------------------------------------

Defined as

        typedef enum filltype_tag
        {
            FILLNONE,
            FILLALL,
            FILLFRAIRF
        }   FILLTYPE ;

where

        FILLNONE means that no extra grid points (beyond security 
        maturities are inserted when bootstrapping DF's.

        FILLALL means that all security pay days are inserted in a DF
        being bootstrapped

        FILLFRAIRF means that only FRA / IRF paydays are inserted in
        a DF being bootstrapped

used in Boot_BSEC2DF().

,,EOT,,*/

typedef enum filltype_tag
{
    FILLTYPE_INIT = -1,
    FILLNONE,
    FILLALL,
    FILLFRAIRF
}   FILLTYPE ;

/* Newton-Raphson struct */

typedef struct
{
  FL64      pvX ;
  CFLW_STR  *cflw ;
  FL64      d1 ;
  DATESTR   *xmatur ;
  DATESTR   *ddate ;
  DISCFAC   *df ;
  DISCFAC   *tmpdisc ;
  DFSPREAD  *dfs ;
  BOOLE     ignore ;
  FL64      shock ;
} BOOTINT ;

typedef struct maxsmoothint_tag
{
  HOLI_STR  holi;
  BSECARRAY bseca;
  CFLWARRAY cflws;
  DATEARRAY settl;
  FL64ARRAY quotes;
  FL64ARRAY spread;
  FL64ARRAY madj;
  FL64ARRAY pricesX;
  FL64ARRAY terms;
  FL64      smoothness;
  DISCFAC   df;
} MAXSMOOTHINT;


/*** function prototyping (bootstrp.c) *************************************/


/* Public functions */

extern BOOLE Boot_BSEC2DF(DATESTR   *today,
                          BSECARRAY secs,
                          FL64ARRAY prices,
                          FL64ARRAY spread,
                          FL64ARRAY madj,
                          FL64ARRAY pvFL,
                          DATEARRAY settle,
                          INTI      nsec,
                          HOLI_STR  *holi,
                          FILLTYPE  ftype,
                          INTI      low,
                          INTI      up,
                          DFPARMS   *dfp,
                          DISCFAC   *df) ;

extern DELTASET Boot_DeltaPrep(DATESTR    *start,
                          BSECARRAY  secs,
                          FL64ARRAY  prices,
                          FL64ARRAY  spread,
                          FL64ARRAY  madj,
                          FL64ARRAY  pvFL,
                          DATEARRAY  settle,
                          FL64ARRAY  shock,
                          INTI       nsec,
                          HOLI_STR   *holi,
                          FILLTYPE   ftype,
                          DISCFAC    *df,
                          BOOLE      *ok) ;

extern FL64ARRAY Boot_BH2MarginAdj(DATESTR   *start,
                                   BSECARRAY bsec,
                                   DATEARRAY settle,
                                   INTI      nsec,
                                   VOL_STR   *svol,
                                   VOL_STR   *fvol,
                                   PLAN_STR  *corr,
                                   HOLI_STR  *holi) ;

extern FL64ARRAY Boot_LOG2MarginAdj(DATESTR    *start,
                                    BSECARRAY  bsec,
                                    DATEARRAY  settle,
                                    INTI       nsec,
                                    DISCFAC    *df,     
                                    VOL_STR    *vol,    
                                    FL64       corrfac, 
                                    HOLI_STR   *holi) ;

extern DISCFAC Boot_BlendDF(PLANARRAY   disc,
                      INTI        ndisc,
                      DFPARMS     *dfp,
                      PERIODARRAY period,
                      INTI        nperiod,
                      FL64MATRIX  weight,
                      DATEARRAY   dates,
                      INTI        ndates,
                      DFPARMS     *what) ;

extern FL64ARRAY Boot_GenrEquiShock(BSECARRAY bsec, 
                                       INTI      nsec, 
                                       FL64ARRAY prices, 
                                       CALCONV   cal, 
                                       PMTFREQ   freq, 
                                       FL64      delta, 
                                       DATESTR*  start, 
                                       BOOLE*    ok);

/* Private functions */
extern FL64 Boot_MM_Disc(DATESTR   *today,
                         IRRCONV   irr,
                         INTI      terms,
                         TERMUNIT  unit,
                         FL64      par_rate,
                         FL64      spread,
                         CALCONV   cal,
                         EOMCONV   eom,
                         HOLI_STR  *h,
                         BOOLE     fill,
                         DISCFAC   *d) ;

extern FL64 Boot_FRA_Disc(DATESTR   *today,
                          INTI      term1,
                          INTI      term2,
                          TERMUNIT  unit,
                          FL64      par_rate,
                          FL64      spread,
                          CALCONV   cal,
                          EOMCONV   eom,
                          HOLI_STR  *h,
                          BOOLE     fill,
                          DISCFAC  *d,
                          BOOLE     nest) ;


extern FL64 Boot_IMMFRA_Disc(DATESTR   *start,
                             INTI      term1,
                             TERMUNIT  unit,
                             FL64      par_rate,
                             FL64      spread,
                             CALCONV   cal,
                             EOMCONV   eom,
                             HOLI_STR  *h,
                             BOOLE     fill,
                             DISCFAC  *d) ;


extern FL64 Boot_IRF_Disc(DATESTR   *start,
                          DATESTR   *matur,
                          FL64      price,
                          FL64      spread,
                          FL64      madj,
                          CALCONV   cal,
                          EOMCONV   eom,
                          HOLI_STR  *h,
                          BOOLE     fill,
                          DISCFAC  *d) ;

extern FL64 Boot_AVGIRF_Disc(DATESTR   *start,
                      DATESTR   *matur,
                      INTI      term,
                      TERMUNIT  unit,
                      FL64      curr_avg,
                      FL64      price,
                      FL64      spread,
                      CALCONV   cal,
                      EOMCONV   eom,
                      HOLI_STR  *holi,
                      BOOLE     fill,
                      DISCFAC   *df) ;

extern BOOLE Boot_Parswap_Disc(FL64 pvFL,
                              DATESTR   *effect,
                              INTI      terms,
                              TERMUNIT  unit,
                              FL64      fix_rate,
                              FL64      spread,
                              PMTFREQ   freq,
                              CALCONV   cal,
                              EOMCONV   eom,
                              HOLI_STR  *h,
                              BOOLE     fill,
                              DISCFAC   *df) ;

extern BOOLE Boot_Swap_Disc(FL64      pvFL,
                            DATESTR   *PVdate,
                            SWAPFIX   *sfix,
                            FL64      spread,
                            HOLI_STR  *holi,
                            BOOLE     fill,
                            DISCFAC   *df) ;

extern BOOLE Boot_SwapFut_Disc(INTI      term,
                               TERMUNIT  unit,
                               FL64      price,
                               FL64      spread,
                               PMTFREQ   freq,
                               CALCONV   cal,
                               EOMCONV   eom,
                               DATESTR*  delivery,
                               FL64      coupon,
                               HOLI_STR* holi,
                               BOOLE     fill,
                               DISCFAC*  df);

extern BOOLE Boot_Cflw_Disc(FL64      pvX,
                            DATESTR   *PVdate,
                            CFLW_STR  *cflw,
                            FL64      spread,
                            HOLI_STR  *holi,
                            BOOLE     fill,
                            BOOLE     ignore,
                            DISCFAC   *df) ;

extern BOOTINT Boot_SetBOOTINT(FL64      pvX,
                                  CFLW_STR  *cflw,
                                  FL64      d1,
                                  DATESTR   *xmatur, 
                                  DATESTR   *ddate,
                                  DISCFAC   *df,
                                  DISCFAC   *tmpdisc,
                                  DFSPREAD  *dfs,
                                  BOOLE     ignore,
                                  FL64      shock) ;

extern void Boot_GetBOOTINT(BOOTINT  *boot_data,
                               FL64      *pvX,
                               CFLW_STR  **cflw,
                               FL64      *d1,
                               DATESTR   **xmatur, 
                               DATESTR   **ddate,
                               DISCFAC   **df,
                               DISCFAC   **tmpdisc,
                               DFSPREAD  **dfs,
                               BOOLE     *ignore,
                               FL64      *shock) ;

extern BOOLE Boot_NewtonRaphson(FL64   x, 
                                   VOIDPTR y,
                                   BOOLE  grad,
                                   FL64   *fx, 
                                   FL64   *dfx,
								   VOIDPTR holi);   	/* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */

extern BOOLE Boot_Bond_Disc(DATESTR   *today,
                            DATESTR   *end,
                            FIXPAY    *fixp,
                            FL64      clean,
                            FL64      fwd,
                            FL64      spread,
                            HOLI_STR  *holi,
                            BOOLE     fill,
                            DISCFAC   *df) ;

extern INTI Boot_Allocsize(DATESTR   *today,
                    BSECARRAY  secs,
                    DATEARRAY  settle,
                    INTI       nsec,
                    INTPOLCONV iconv,
                    FILLTYPE   ftype) ;

extern FL64 Boot_Margin_Drift_IRF(DATESTR   *start,
                           BSECARRAY bsec,
                           INTI      ix,
                           VOL_STR   *svol,
                           VOL_STR   *fvol,
                           PLAN_STR  *corr,
                           BOOLE     doall) ;


extern BOOLE Boot_Genr_Fill(BSECTYPE type, 
                               FILLTYPE  fill) ;

/*** function prototyping (maxsmoth.c) *************************************/


/* Public functions */
extern BOOLE MaxSmooth_BSEC2DF(DATESTR*    today,
                        FL64ARRAY   quotes,
                        BSECARRAY   bseca,
                        FL64        smoothness,
                        FL64ARRAY   spread,
                        FL64ARRAY   madj,
                        FL64ARRAY   pricesX,
                        DATEARRAY   settl,
                        INTI        nfixp,
                        HOLI_STR*   holi,
                        DFPARMS*    dfp,
                        DISCFAC*    df,
                        FL64*       smooth);

/* Private functions */
extern void FRA_Dates(DATESTR*  settl,
                      INTI      term1,
                      INTI      term2,
                      TERMUNIT  unit,
                      BOOLE     nest,
                      CALCONV   cal,
                      EOMCONV   eom,
                      HOLI_STR* hol,
                      DATESTR*  start,
                      DATESTR*  maturity);

extern FL64 BSEC_DF2PriceDiff(DATESTR*  settl,
                              BSEC*     bsec, 
                              CFLW_STR* cflw,
                              FL64      spread,
                              FL64      madj,
                              FL64      pricesX,
                              DISCFAC*  df, 
                              HOLI_STR* holi,
                              FL64      quote);

extern CFLW_STR* BSEC_GenrCflw(BSEC*     bsec, 
                               FL64      quote,
                               FL64      priceX,
                               HOLI_STR* holi,
                               DATESTR*  settl);

extern void MaxSmooth_ForwRate2DF(FL64ARRAY terms,
                                  FL64ARRAY forws,
                                  INTI      nterms,
                                  FL64ARRAY discfacs);

extern int MaxSmooth_Harwell(integer* ncoef, 
                                integer* nsec, 
                                double*  coefs, 
                                void*    data, 
                                double*  f);

#ifdef __cplusplus
}
#endif

#endif

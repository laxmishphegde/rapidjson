/* SCID @(#)pmt.h	1.7 (SimCorp) 99/10/27 13:03:59 */

#ifndef PMT_H
#define PMT_H

/************************************************************************
*                                                                       *
*    project    SCecon                                                  *
*                                                                       *
*    filename   pmt.h                                                   *
*                                                                       *
*    general    this file contains declarations, initialization ,       *
*               type definitions and function prototyping for the       *
*               cash flow module of the standard library SCecon         *
*                                                                       *
************************************************************************/

/* **** includes ***************************************************** */
#include <cldr.h>
#include <yld.h>

#ifdef __cplusplus
extern "C" {
#endif


/* **** defines  ***************************************************** */
#define PMT_TOL 0.0000000001


/* **** typedefs ***************************************************** */


/*,,SOT,,

BONDTYPE : data type for bond types
-----------------------------------

In SCecon the different bond types are defined using the BONDTYPE data
type. This is defined as

        typedef enum bond_tag
        {
            BULLET,
            SERIAL,
            ANNUITY,
            PERPETUAL,
            NONREGULAR,
            SERIAL_PCT,
            ANNUITY_PCT,
            ANNUITY_PREP
        }   BONDTYPE;

For bonds of type BULLET the debt is repaid at the maturity
date of the bond.

For bonds of type SERIAL the debt is repaid in equal size redemptions
throughout the life of the bond.

For bonds of type ANNUITY the total payment, i.e. redemption plus coupon
payment have equal size thoughout the life of the bond. The bonds cannot 
be partly paid issues and the coupon and redemption days should coincide.

Note that annuities with stepped coupons are implemented as the special
Scandinavian type which are standard annuities in the periods between rate
adjustments but may not necessarily have constant payments throughout the
life of the bond.

Bonds of type PERPETUAL do not repay at all. They are bullet loans with
infinite maturity; so the only payments from this bond type are coupons.
Currently NOT implemented in SCecon.

The NONREGULAR bond type is included for generality, although nothing
general can be said about its repayment schedule. This is the typical
backdoor when nothing else can be said about redemptions.

SERIAL_PCT is used for serial loans where the redemption is
a fixed percentage of the initial borrowed amount. Used for some
danish mortgage loans.
                                                   
ANNUITY_PCT is used to define annuity loans where the total payment is a
fixed percentage of the initial borrowed amount. Used for some danish mortgage 
loans.

ANNUITY_PREP defines prepaid loans that are annuities, i.e. has equal size
payments. In order to obtain equal size payments the prepaid option
on FIXRATE must be set.

,,EOT,,*/

typedef enum bond_tag
{
    BONDTYPE_INIT = -1,
    BULLET,
    SERIAL,
    ANNUITY,
    PERPETUAL,     /* Not implemented yet. */
    NONREGULAR,
    SERIAL_PCT,
    ANNUITY_PCT,
    ANNUITY_PREP
}   BONDTYPE;


/*,,SOT,,

PMT_STR and PMTARRAY : data types for payment streams
-----------------------------------------------------

The data type for holding informations on payment streams, PMT_STR, is
defined as

        typedef struct
        {
            INTI      count;
            FL64ARRAY payment;
            FL64ARRAY term;
        }   PMT_STR;


        count is the number of filled data in payment and term

        payment[count] is a list of payments

        term[count] is a list of terms in fractional years

This data type is used for pricing purposes only, and do not distinguish
between the possibly diffenrent sources of the payments, i.e. dividends,
coupons, repayments etc.

Use the data type PMTARRAY when you operate with arrays of PMT_STR's.
The definition of the PMTARRAY data structure is:

        typedef PMT_STR * PMTARRAY ;

,,EOT,,*/

typedef struct
{
    INTI      count;
    FL64ARRAY payment;
    FL64ARRAY term;
}   PMT_STR;

typedef PMT_STR * PMTARRAY ;



/* **** macros *********************************************************/

/*
..
*/

#define cflw_dirty2clean(d, a) ((d) - (a))


/*
..
*/

#define cflw_clean2dirty(c, a) ((c) + (a))


/*
..
*/

#define cflw_dirty2npv(dirty, debt) ((dirty)*(debt)/100.0)


/*
..
*/

#define cflw_npv2dirty(npv, debt) \
(fabs(debt) > PMT_TOL ? (100.0*npv)/(debt) : 0.0)




/* **** function prototyping (payments.c)  ***************************** */


/* Public functions */

extern INTI Cflw_MonthsBetweenPayments(PMTFREQ freq) ;

extern PMTFREQ Cflw_Months2PmtFreq(INTI m) ;

extern FL64 Cflw_Annuity(FL64 pr, INTI n, BOOLE prepaid) ;

/* Private functions */

extern void Cflw_Bondtype2Payments(FL64      prate,
                                   FL64ARRAY prates,
                                   INTI      n,
                                   BONDTYPE  type,
                                   BOOLE     ppann,
                                   FL64ARRAY repay,
                                   FL64ARRAY coupon) ;

extern void cflw_payments_bullet(FL64      prate,
                                 INTI      n,
                                 FL64ARRAY repay,
                                 FL64ARRAY coupon) ;

extern void cflw_payments_serial(FL64      prate,
                                 INTI      n,
                                 FL64ARRAY repay,
                                 FL64ARRAY coupon) ;

extern void cflw_payments_annuity(FL64      prate,
                                  FL64ARRAY prates,
                                  INTI      n,
                                  BOOLE     ppann,
                                  FL64ARRAY repay,
                                  FL64ARRAY coupon) ;

/* **** function prototyping (debt.c)  ********************************* */


/* Public functions */

extern FL64ARRAY Cflw_FractionDebt(FL64ARRAY repayment,
                                    INTI      n) ;

extern FL64ARRAY Cflw_RepaidDebt(FL64ARRAY repayment,
                                  INTI      n) ;


extern FL64ARRAY Cflw_OutstandingDebt(FL64ARRAY repayment,
                                       INTI      n) ;

extern FL64 Cflw_OutstandingAnnuity(FL64 cp, INTI ncflw, INTI rest) ;

extern FL64 Cflw_OutstandingSerial(INTI ncflw, INTI rest) ;



/*** routines in pmtalloc.c ********************************************/


/* Public functions */

extern PMTARRAY  Alloc_PMTARRAY(INTI jhi,
                                INTI ihi) ;

extern void      Free_PMTARRAY(PMTARRAY pmt,
                               INTI     jhi) ;




#ifdef __cplusplus
}
#endif

#endif

/* SCID @(#)yld.h	1.12 (SimCorp) 99/02/19 14:17:47 */

#ifndef YLD_H_INCLUDED

#define YLD_H_INCLUDED

/************************************************************************
*                                                                       *
*    project    SCecon                                                  *
*                                                                       *
*    filename   yld.h                                                   *
*                                                                       *
*    this file contains definitions and function prototyping for the    *
*    routines in the SCecon Yield conventions module.                   *
*                                                                       *
************************************************************************/

/***** includes  *******************************************************/
#include <math.h>
#include <stdlib.h>
#include <scutl.h>
#include <scecon.h>
#include <tvmunit.h>

#ifdef __cplusplus
extern "C" {
#endif

/***** typedefs  *******************************************************/

/*,,SOT,,

SHOCKCONV : data type for term structure shocks
-----------------------------------------------

When calculating interest sensitivities, several approaches can be used.

According to the Macauley set up - the classical one, that everybody use
to evaluate interest rate risk - a parallel shift in the term structure
is assumed.

In the Bierwag setup, the changes in interest rates are proportional to
the interest rate level. High rates are expected to have high volatility
while low rates are expected to have low volatility - the shifts in the
term structure is multiplicative.

As an alternative to these assumptions, the factor approach is founded
on explicit scenarios for the term structure changes. You can have a
steepening of the term structure, a bending of the term structure and so
on. The point is to get scenarios - of factor loadings to be more in
line with the terminology of academic litterature.

The SHOCKCONV is defined in yld.h as

        typedef enum  shock_tag
        {
            PARALLEL,
            MULTIPLICATIVE,
            FACTOR_SHOCK
        }   SHOCKCONV ;

in yld.h of the SCecon Library.

,,EOT,,*/

typedef enum  shock_tag
{
    SHOCKCONV_INIT = -1,
    PARALLEL,
    MULTIPLICATIVE,
    FACTOR_SHOCK
}   SHOCKCONV ;


/*,,SOT,,

TS_STR and TSARRAY : data types for term structures
---------------------------------------------------

In SCecon term structures are represented in the data type TS_STR,
defined as

        typedef struct
        {
            INTI      count ;
            INTI      qbas ;
            IRRCONV   conv ;
            FL64ARRAY term ;
            FL64ARRAY rate ;
            FL64ARRAY loading ;
        }   TS_STR ;

in yld.h of the SCecon Library.

The entities in this data type are

        count          number of elements in term, rate and loading,

        qbas           quoting basis of the interest rate convention,

        conv           interest rate convention, only used if conv is
                       one of:

                         COMPOUND
                         COMPOUNDSIMPLE
                         COMPOUNDSIMPLE_ODD
                         MOOSMULLER
                         US_TREASURY

        term[count]    terms for the rates in fractional years,

        rate[count]    term structure rates in percent,

        loading[count] factor loadings corresponding to term,

Arrays of term structures are defined as

        typedef TS_STR * TSARRAY ;

in yld.h of the SCecon Library.

,,EOT,,*/


typedef struct
{
    INTI       count;
    INTI       qbas;
    IRRCONV    conv;
    FL64ARRAY  term ;
    FL64ARRAY  rate ;
    FL64ARRAY  loading ;
}   TS_STR ;

typedef TS_STR * TSARRAY ;


/*
*************************************************************************
*                                                                       *
*               yld_compound2continuous()                               *
*                                                                       *
*   library     yld                                                     *
*                                                                       *
*   interface   #include <yld.h>                                        *
*               FL64 yld_compound2continuous(FL64 r, INTI qb) ;         *
*                                                                       *
*   general     yld_compound2continuous() is a macro that converts      *
*               annually compounded yield to continuously compounded    *
*               yield.                                                  *
*                                                                       *
*   input       FL64    r    Annually compounded yield in percent       *
*                            quoted as qb.                              *
*                                                                       *
*               INTI    qb   Quoting basis. Must be non-zero.           *
*                                                                       *
*   output                                                              *
*                                                                       *
*   returns     the continuously compounded yield in percent.           *
*                                                                       *
*   diagnostics                                                         *
*                                                                       *
*   see also    yld_continuous2compound()                               *
*                                                                       *
*************************************************************************
*/

#define yld_compound2continuous(r, qb) \
100.0 * log(1.0 + ((r)/100.0)/((FL64) (qb)))*((FL64) (qb))


/*
*************************************************************************
*                                                                       *
*               yld_continuous2compound()                               *
*                                                                       *
*   library     yld                                                     *
*                                                                       *
*   interface   #include <yld.h>                                        *
*               FL64 yld_continuous2compound(FL64 r, INTI qb) ;         *
*                                                                       *
*   general     yld_continuous2compound() is a macro that converts      *
*               continuously compounded yield to annually compounded    *
*               yield.                                                  *
*                                                                       *
*   input       FL64    r     Continuously compounded yield in          *
*                             percent.                                  *
*                                                                       *
*               INTI    qb    Quoting basis of the compounded yield.    *
*                             Must be non-zero.                         *
*                                                                       *
*   output                                                              *
*                                                                       *
*   returns     the annual compounded yield in percent.                 *
*                                                                       *
*   dianosis    none                                                    *
*                                                                       *
*   see also    yld_compound2continuous()                               *
*                                                                       *
*************************************************************************
*/

#define yld_continuous2compound(r, qb) \
100.0 * (exp( ((r)/100.0)/((FL64) (qb))) - 1.0)*((FL64) (qb))


/************************************************************************
*                                                                       *
*               yld_simple_ann2per()                                    *
*                                                                       *
*    library    yld                                                     *
*                                                                       *
*    interface  #include <yld.h>                                        *
*               FL64 yld_simple_ann2per(FL64 annualrate,                *
*                                       FL64 period) ;                  *
*                                                                       *
*    general    yld_simple_ann2per() is a macro that calculates the     *
*               simple periodic money market yield as a function of     *
*               simple annual money market yield.                       *
*                                                                       *
*    input      FL64    annualrate  Simple annual money market yield    *
*                                   in percent.                         *
*               FL64    period      The period length in fractional     *
*                                   years.                              *
*                                                                       *
*    output                                                             *
*                                                                       *
*    returns    The simple periodic money market yield in percent.      *
*                                                                       *
*    diagnostics                                                        *
*                                                                       *
*    see also   yld_compound_ann2per()                                  *
*                                                                       *
************************************************************************/

#define yld_simple_ann2per(ar, p) \
    ( (ar) * (p) )


/************************************************************************
*                                                                       *
*               yld_simple_per2ann()                                    *
*                                                                       *
*    library    yld                                                     *
*                                                                       *
*    interface  #include <yld.h>                                        *
*               FL64 yld_simple_per2ann(FL64 periodrate,                *
*                                       FL64 period) ;                  *
*                                                                       *
*    general    yld_simple_per2ann() is a macro that calculates the     *
*               simple annual money market yield as a function of       *
*               simple periodic money market yield.                     *
*                                                                       *
*    input      FL64    periodrate  The simple periodic money market    *
*                                   yield in percent.                   *
*                                                                       *
*               FL64    period      The period length in fractional     *
*                                   years.                              *
*                                                                       *
*    output                                                             *
*                                                                       *
*    returns    The simple annual money market yield in percent.        *
*                                                                       *
*    diagnostics                                                        *
*                                                                       *
*    see also   yld_compound_per2ann()                                  *
*                                                                       *
************************************************************************/

#define yld_simple_per2ann(pr, p) \
    ( (p) ? ((pr) / (p)) : 0.0 )


/************************************************************************
*                                                                       *
*               yld_discount_ann2per()                                  *
*                                                                       *
*    library    yld                                                     *
*                                                                       *
*    interface  #include <yld.h>                                        *
*               FL64 yld_discount_ann2per(FL64 annualrate,              *
*                                         FL64 period) ;                *
*                                                                       *
*    general    yld_discount_ann2per() is a macro that calculates the   *
*               periodic discount yield as a function of                *
*               annual discount yield.                                  *
*                                                                       *
*    input      FL64    annualrate  Annual discount yield               *
*                                   in percent.                         *
*               FL64    period      The period length in fractional     *
*                                   years.                              *
*                                                                       *
*    output                                                             *
*                                                                       *
*    returns    The periodic discount yield in percent.                 *
*                                                                       *
*    diagnostics                                                        *
*                                                                       *
*    see also   yld_compound_ann2per()                                  *
*                                                                       *
************************************************************************/

#define yld_discount_ann2per(ar, p) \
    ( (ar) * (p) )


/************************************************************************
*                                                                       *
*               yld_discount_per2ann()                                  *
*                                                                       *
*    library    yld                                                     *
*                                                                       *
*    interface  #include <yld.h>                                        *
*               FL64 yld_discount_per2ann(FL64 periodrate,              *
*                                         FL64 period) ;                *
*                                                                       *
*    general    yld_discount_per2ann() is a macro that calculates the   *
*               annual discount yield as a function of                  *
*               periodic discount yield.                                *
*                                                                       *
*    input      FL64    periodrate  The periodic discount               *
*                                   yield in percent.                   *
*               FL64    period      The period length in fractional     *
*                                   years.                              *
*                                                                       *
*    output                                                             *
*                                                                       *
*    returns    The annual discount yield in percent.                   *
*                                                                       *
*    diagnostics                                                        *
*                                                                       *
*    see also                                                           *
*                                                                       *
************************************************************************/

#define yld_discount_per2ann(pr, p) \
    ( (p) ? ((pr) / (p)) : 0.0 )


/************************************************************************
*                                                                       *
*               yld_compound_ann2per()                                  *
*                                                                       *
*    library    yld                                                     *
*                                                                       *
*    interface  #include <yld.h>                                        *
*               FL64 yld_compound_ann2per(FL64 annualrate,              *
*                                         FL64 period,                  *
*                                         INTI   qbas) ;                *
*                                                                       *
*    general    yld_compound_ann2per() is a macro that calculates       *
*               the periodically compounded yield as a function of      *
*               annually compounded yield.                              *
*                                                                       *
*    input      FL64    annualrate   The annually compounded yield in   *
*                                    percent. Quoted as qbas.           *
*               FL64    period       The period length in fractional    *
*                                    years.                             *
*               INTI    qbas         Quoting basis of the yield.        *
*                                                                       *
*    output                                                             *
*                                                                       *
*    returns    the periodically compounded yield in percent.           *
*                                                                       *
*    diagnostics                                                        *
*                                                                       *
*    see also   yld_simple_ann2per()                                    *
*                                                                       *
************************************************************************/

#define yld_compound_ann2per(ar, p, qb) \
(100.0*(pow(1.0 + (ar)/(100.0*(FL64) (qb)), ((FL64) (qb))*(p)) - 1.0))


/************************************************************************
*                                                                       *
*               yld_compound_per2ann()                                  *
*                                                                       *
*    library    yld                                                     *
*                                                                       *
*    interface  #include <yld.h>                                        *
*               FL64 yld_compound_per2ann(FL64 periodrate,              *
*                                         FL64 period,                  *
*                                         INTI   qbas) ;                *
*                                                                       *
*    general    yld_compound_per2ann is a macro that calculates the     *
*               annually compounded yield as a function of periodically *
*               compounded yield.                                       *
*                                                                       *
*    input      FL64    periodrate   The compounded periodic rate in    *
*                                    percent. Quoted as qbas.           *
*               FL64    period       The period length in fractional    *
*                                    years.                             *
*               INTI    qbas         Quoting basis of the rate.         *
*                                                                       *
*    output                                                             *
*                                                                       *
*    returns    The annually compounded yield in percent.               *
*                                                                       *
*    diagnostics                                                        *
*                                                                       *
*    see also   yld_simple_ann2per()                                    *
*                                                                       *
************************************************************************/

#define yld_compound_per2ann(pr, p, qb) \
(100.0*((FL64) (qb))*( pow(1.0 + (pr)/100.0, 1.0/((p)*(FL64) qb) ) - 1.0))


/************************************************************************
*                                                                       *
*               yld_continuous_ann2per()                                *
*                                                                       *
*    library    yld                                                     *
*                                                                       *
*    interface  #include <yld.h>                                        *
*               FL64 yld_continuous_ann2per(FL64 annualrate,            *
*                                           INTI   period) ;            *
*                                                                       *
*    general    yld_continuous_ann2per() is a macro that calculates     *
*               the periodical continuous yield as a function of        *
*               annual continuous yield.                                *
*                                                                       *
*    input      FL64    annualrate   The annual continuous yield in     *
*                                    percent.                           *
*               FL64    period       The period length in fractional    *
*                                    years.                             *
*                                                                       *
*    output                                                             *
*                                                                       *
*    returns    the periodical continuous yield in percent.             *
*                                                                       *
*    diagnostics                                                        *
*                                                                       *
*    see also   yld_simple_ann2per()                                    *
*                                                                       *
************************************************************************/

#define yld_continuous_ann2per(ar, p) \
(p)*(ar)


/************************************************************************
*                                                                       *
*               yld_continuous_per2ann()                                *
*                                                                       *
*    library    yld                                                     *
*                                                                       *
*    interface  #include <yld.h>                                        *
*               FL64 yld_continuous_per2ann(FL64 periodrate,            *
*                                           FL64 period) ;              *
*                                                                       *
*    general    yld_continuous_per2ann is a macro that calculates the   *
*               annual continuous yield as a function of periodical     *
*               continuous yield.                                       *
*                                                                       *
*    input      FL64    periodrate   The continuous periodic rate in    *
*                                    percent.                           *
*               FL64    period       The period length in fractional    *
*                                    years.                             *
*                                                                       *
*    output                                                             *
*                                                                       *
*    returns    The annual continuous yield in percent.                 *
*                                                                       *
*    diagnostics                                                        *
*                                                                       *
*    see also   yld_simple_ann2per()                                    *
*                                                                       *
************************************************************************/

#define yld_continuous_per2ann(pr, p) \
( (p) ? (pr)/(p) : 0.0)


/*** prototypes  (forward.c)  ******************************************/

/* Private functions */

extern FL64 Yld_ForwardRate_Compound(FL64 rate1,
                                     FL64 term1,
                                     FL64 rate3,
                                     FL64 term3,
                                     INTI   qbas) ;

extern FL64 Yld_ForwardRate_Continuous(FL64 rate1,
                                       FL64 term1,
                                       FL64 rate3,
                                       FL64 term3);

extern FL64 Yld_ForwardRate_Simple(FL64 rate1,
                                   FL64 term1,
                                   FL64 rate3,
                                   FL64 term3) ;

extern FL64 Yld_Spot2Forw_Rate(FL64 rate1,
                               FL64 term1,
                               FL64 rate3,
                               FL64 term3,
                               INTI   qbas,
                               IRRCONV irr) ;

extern TSARRAY Yld_Spot2Forw_Ts(TS_STR *tsin,
                                FL64ARRAY terms,
                                INTI nterms,
                                FL64 duration,
                                INTPOLCONV iconv) ;

/*** prototypes (ann2per.c)  *******************************************/


/* Private functions */

extern FL64 Yld_Ann2Per(FL64 annualrate,
                        FL64 basis,
                        INTI   qb,
                        IRRCONV irr) ;

extern FL64 Yld_Per2Ann(FL64 periodrate,
                        FL64 basis,
                        INTI   qb,
                        IRRCONV irr) ;



/*** prototypes (rates.c)  *********************************************/

/* Private functions */
extern void Yld_Shock_Rates(TS_STR * tsstr,
                            SHOCKCONV shocktype,
                            FL64   shocksize) ;

extern TSARRAY Yld_GetRates(TS_STR * tsin,
                            FL64ARRAY   terms,
                            INTI      n,
                            INTPOLCONV intpol);

extern FL64 Yld_Get_TsRate(TS_STR *   tsin,
                           FL64    term,
                           INTPOLCONV intpol) ;

extern void Yld_FL64ARRAY2TSARRAY(INTI n, FL64ARRAY term, FL64ARRAY rate,
                                  FL64ARRAY loading, INTI qbas,
                                  IRRCONV irr, TSARRAY ts) ;


/*** prototypes (yldalloc.c)  ******************************************/

/* Public functions */

extern TSARRAY  Alloc_TSARRAY(INTI nstr, INTI np);
extern void     Free_TSARRAY(TSARRAY s, INTI nstr);


#ifdef __cplusplus
}
#endif

#endif

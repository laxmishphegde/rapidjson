/* SCCS @(#)futio.h	1.2 (SimCorp) 99/02/19 14:13:15 */

#ifndef FUTIO_H
#define FUTIO_H

/************************************************************************
*                                                                       *
*   project     SCecon                                                  *
*                                                                       *
*   general     This file contains the header file for the example code *
*               in str2conv.c                                           *
*                                                                       *
************************************************************************/

/*** includes **********************************************************/
#include <str2conv.h>
#include <future.h>
#include <mm.h>
#include <swapval.h>
#include <frn.h>

#ifdef __cplusplus
extern "C" {
#endif

/*** prototypes  *******************************************************/

extern CFCONV      Str2CFCONV(TEXT txt) ;
extern CMADJTYPE   Str2CMADJTYPE(TEXT txt) ;
extern COMPMETHOD  Str2COMPMETHOD(TEXT txt) ;
extern CTDCONV     Str2CTDCONV(TEXT txt) ;
extern LEGTYPE     Str2LEGTYPE(TEXT txt) ;
extern QOTCONV     Str2QOTCONV(TEXT txt) ;

extern CFCONV Read_CFCONV(FILE *in, FILE *out, TEXT dscr);     
extern COMPMETHOD Read_COMPMETHOD(FILE *in, FILE *out, TEXT dscr); 
extern CTDCONV Read_CTDCONV(FILE *in, FILE *out, TEXT dscr);
extern LEGTYPE Read_LEGTYPE(FILE *in, FILE *out, TEXT dscr);    
extern QOTCONV Read_QOTCONV(FILE *in, FILE *out, TEXT dscr);
extern CMADJTYPE Read_CMADJTYPE(FILE *in, FILE *out, TEXT dscr);  

extern CMCONVADJ  Read_CMCONVADJ(FILE *in, FILE *out) ;
extern DIFFSWAP  Read_DIFFSWAP(FILE *in, FILE *out) ;
extern FLOATRATE Read_FLOATRATE(FILE *in, FILE *out) ;
extern FLOATBASE Read_FLOATBASE(FILE *in, FILE *out) ;
extern FRN       Read_FRN(FILE* in, FILE* out) ;
extern FRA_STR   Read_FRA_STR(FILE *in, FILE *out) ;
extern FUTBONDBM Read_FUTBONDBM(FILE *in, FILE *out) ;
extern FUTBOND   Read_FUTBOND(FILE *in, FILE *out, DATESTR *settle) ;
extern RATEINDEX  Read_RATEINDEX(FILE *in, FILE *out) ;
extern REPOBOND  Read_REPOBOND(FILE *in, FILE *out) ;
extern SWAPFLOAT Read_SWAPFLOAT(FILE *in, FILE *out) ;

extern INTI Write_CTDRESdiff(FILE *in, FILE *out, CTDRES *res, 
                FL64 acc) ;


#ifdef __cplusplus
}
#endif

#endif

/* @(#)swap.h	1.4 (SimCorp) 99/09/01 17:57:43 */

#ifndef SWAP_H_INCLUDED

#define SWAP_H_INCLUDED

/************************************************************************
*                                                                       *
*    project     SCecon                                                 *
*                                                                       *
*    filename    swap.h                                                 *
*                                                                       *
*    general     this file contains declarations, initializations,      *
*                type definitions and function prototyping for the      *
*                swap module of the standard library SCecon             *
*                                                                       *
************************************************************************/

/**** includes *********************************************************/
#include <stdlib.h>
#include <bond.h>
#include <vol.h>

/**** C++ convenience **************************************************/
#ifdef __cplusplus
extern "C" {
#endif


/*** typedefines ******************************************************/


/*,,SOT,,

RATECONV: Type for defining floating rate index types
-----------------------------------------------------

This type used to distinguish various index types is defined as:

        typedef enum rateconv_tag
        {
            MMRATE,
            BILLDISC,
            BILLYIELD,
            PARYIELD,
            REX
        }   RATECONV ;

The various entries have the following interpretations:

        MMRATE is the standard (*IBOR) SIMPLE_MM rate index.

        BILLDISC is a DISCOUNT rate based index (as in South African 
        Discounted Bank Bill FRA's, or Italian CCT's)

        BILLYIELD means that the rate is the yield of a bank bill
        (as in Australian 90 day bank bill futures)

        PARYIELD means that the index is the rate of an underlying 
        security (par yield of bond or swap) as used in Constant Maturity 
        Swaps and Caps.

        REX means that the index is the rate of an underlying 
        security (yield of non-par bond) as used in REX floaters.

The type is used for defining FRA, IRF, Swap (floating legs) and Cap/Floor
index types.

,,EOT,,*/

typedef enum rateconv_tag
{
    RATECONV_INIT = -1,
    MMRATE,
    BILLDISC,
    BILLYIELD,
    PARYIELD,
    REX
}   RATECONV ;



/*,,SOT,,

SWAPFIX: type for holding info on fixed swap legs
-------------------------------------------------

This type is defined as

        typedef struct swapfix_tag
        {
            REPAYMNT  repay ;
            PAYDAYDEF rday ;
            FIXRATE   fix ;
            PAYDAYDEF pday ;
            INTI      delay ;
        }   SWAPFIX ;

Use this type to define many kinds of swap fixed legs.

The data has the following interpretations:

        repay is the definition of repayments
        Use repay to define Amortising (incl. Accreting and 
        Rollercoaster) fixed swap legs.

        rday is the definition of the repay paydays

        fix is the definition of the fixed payment calculation.
        Use this to define day count conventions, stepped swaprates
        etc.

        pday is the definition of the fixed coupon paydays

        delay is as delay being superimposed on the paydays after calcu-
        lating the amounts.

See SwapFix_GenrCflw() for cashflow calculation.

see also Set_SWAPFIX ans SwapFix_Simple2SWAPFIX()

,,EOT,,*/

typedef struct swapfix_tag
{
    REPAYMNT  repay ;
    PAYDAYDEF rday ;
    FIXRATE   fix ;
    PAYDAYDEF pday ;
    INTI      delay ;
}   SWAPFIX ;


/*** function prototyping (swap.c) ***************************************/
/* Public functions */
extern CFLWARRAY SwapFix_GenrCflw(SWAPFIX    *sfix,
                                   HOLI_STR   *holi) ;   /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */

extern FL64ARRAY SwapFix_GenrCoupons(FIXRATE   *fix,
                       PLAN_STR  *amort,
                       DATEARRAY cdays,
                       INTI      nc,
					   PAYDAYSEQ *pseq, 
					   HOLI_STR  *holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */

extern void Free_SWAPFIX(SWAPFIX *x);

extern SWAPFIX Set_SWAPFIX(REPAYMNT *repay, PAYDAYDEF *rday,
                                   FIXRATE *fix, PAYDAYDEF *pday, INTI delay) ;

extern SWAPFIX SwapFix_Simple2SWAPFIX(DATESTR* effect,
                                  PERIOD* tenor,
                                  PMTFREQ freq,
                                  FL64    rate,
                                  CALCONV cal,
                                  EOMCONV eom) ;




/* Private functions */
extern FL64 Swap_DF2NPV(DATESTR  *analys,
                        CFLW_STR *cflw,
                        BOOLE    ignore,
						DISCFAC  *df, 
						HOLI_STR *holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */



#ifdef __cplusplus
}
#endif

#endif

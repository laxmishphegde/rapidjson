/* SCID @(#)futeqty.h	1.9 (SimCorp) 99/02/19 14:14:31 */

#ifndef FUTEQTY_H

#define FUTEQTY_H

/************************************************************************
*                                                                       *
*    project    SCecon                                                  *
*                                                                       *
*    filename   futeqty.h                                               *
*                                                                       *
*    this file contains definitions and function prototyping for the    *
*    routines in the SCecon Future pricing module.                      *
*                                                                       *
************************************************************************/

/*** includes **********************************************************/
#include <disc.h>

#ifdef __cplusplus
extern "C" {
#endif


/*** defines ***********************************************************/
#define SCFUTHUGE_VAL 9999.99



/*,,SOT,,

FXFORW: Data structure for holding data on FX forwards/futures
--------------------------------------------------------------

This type is defined as:

        typedef struct fxforw_tag
        {
            DATESTR matur ;
            BOOLE   inv ;
            FL64    base ;
            FL64    fwd ;
            BOOLE   margin ;
            CALCONV cal ;
        }   FXFORW ;

For holding data on FX forwards/futures

The data should be interpreted as:

        matur is the maturity date of the contract

        inv is set as True if the quoting of the FX rates is inverse - 
        meaning that fwd is foreign CCY per domestic CCY. If inv is False
        then fwd is domestic CCY per foreign CCY.

        base is the basis for the FX rate (1.0, 100.0, 1000.0 or ?). I.e.
        fwd is base domestic CCY per 1 foreign CCY (inv False).
        e.g 400 DEM / DKK means that base is 100 and 4 DEM/DKK means
        that base is 1.

        fwd is the agreed FX rate. Quoted as domestic CCY units per
        foreign CCY units (where domestic is paid, foreign is received)
        if inv is False, otherwise if inv is True.

        margin True means that the contract is margined (as when exchange
        traded). False the means no margining.

        cal is the calendar used for interpolating in the forward points
        when finding P/L. Specific for the FX cross.

see also Set_FXFORW

,,EOT,,*/

typedef struct fxforw_tag
{
    DATESTR matur ;
    BOOLE   inv ;
    FL64    base ;
    FL64    fwd ;
    BOOLE   margin ;
    CALCONV cal ;
}   FXFORW ;


/*,,SOT,,

FUTEQTY: Data type for forwards/futures contracts on equities
-------------------------------------------------------------

This type is defined as:

        typedef struct futeqty_tag
        {
            DATESTR  matur ;
            PLAN_STR *div ;
            CALCONV  cal ;
            FL64     futp ;
            BOOLE    margin ;
        }   FUTEQTY ;

for holding data on futures/forwards on equities
The data members are:

    matur is the delivery data for the equity forward

    div|NULL is a list of discrete dividend payments - quoted as a
        relative number (relative to the spot price).
        Can be NULL -- indicating no dividends

    cal is the equity calendar.

    futp is the contract price (agreed price)

    margin is True of margining is used, False if not (e.g.
        for forward contracts).

see also Set_FUTEQTY

,,EOT,,*/

typedef struct futeqty_tag
{
    DATESTR  matur ;
    PLAN_STR *div ;
    CALCONV  cal ;
    FL64     futp ;
    BOOLE    margin ;
}   FUTEQTY ;


/*,,SOT,,

FUTCMDTY: Data type for forwards/futures contracts on commodities
-----------------------------------------------------------------

This type is defined as:

        typedef struct futcmdty_tag
        {
            DATESTR  matur ;
            PLAN_STR *cy ;
            PLAN_STR *stc ;
            CALCONV  cal ;
        }   FUTCMDTY ;

for holding data on futures/forwards on commodities
The data members are:

    matur is the delivery data for the commodity forward

    cy|NULL is a list of discrete convenience yield payments - quoted as a
        relative number. Can be NULL -- indicating no payments

    stc|NULL is a list of discrete storage cost payments - quoted as a
        relative number. Can be NULL -- indicating no payments.

    cal is the commodity calendar.
see also Set_FUTCMDTY

,,EOT,,*/

typedef struct futcmdty_tag
{
    DATESTR  matur ;
    PLAN_STR *cy ;
    PLAN_STR *stc ;
    CALCONV  cal ;
}   FUTCMDTY ;

/* Newton-Raphson struct */

typedef struct
{
  DATESTR  *spotdate ;
  DATESTR  *matur ;
  FL64     spot ;
  FL64     futp ;
  DFPARMS  *dfp ;
  FUTEQTY  *fute ;
  DISCFAC  *dfrepo ;
  HOLI_STR *holi ;
  FL64     shock ;
} FUTEQTYINT ;
  
/*** prototypes  (futcmdty.c)  ****************************************/


/* Public functions */



extern FL64 FutCmdty_CC2Price(DATESTR  *analys,
                       FL64     spot,
                       FUTCMDTY *futc,
                       FL64     convyld,
                       FL64     stcost,
                       DISCFAC  *df,
					   HOLI_STR *holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */

extern FL64 FutCmdty_CC2NPV(DATESTR  *analys,
                            DATESTR  *spotdate,
                            FL64     spot,
                            FL64     futp,
                            FUTCMDTY *futc,
                            FL64     convyld,    
                            FL64     stcost,
                            DISCFAC  *df,
                            RISKSET  *risk,
                            FL64     *dp,
                            FL64     *ddp,
							HOLI_STR *holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */

extern FL64ARRAY FutCmdty_CC2Delta(DATESTR  *analys,
                                   DATESTR  *spotdate,
                                   FL64     spot,
                                   FL64     futp,
                                   FUTCMDTY *futc,
                                   FL64     convyld,    
                                   FL64     stcost,
                                   DISCFAC  *df,
                                   DELTASET *ds,
								   HOLI_STR  *holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */

extern FL64 FutCmdty_CC2Implyld(DATESTR  *analys,
                         FL64     spot,
                         FL64     futp,
                         FUTCMDTY *futc,
                         DISCFAC  *df,
						 HOLI_STR *holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */

extern FUTCMDTY Set_FUTCMDTY(DATESTR  *matur,
                           PLAN_STR *cy,
                           PLAN_STR *stc,
                           CALCONV  cal) ;


/* Private functions */


/*** prototypes  (futeqty.c)  *****************************************/


/* Public functions */
extern FL64 FutEqty_CC2Price(DATESTR  *analys,
                       FL64     spot,
                       FUTEQTY  *fute,
                       FL64     divyld,
                       DISCFAC  *df,
                       HOLI_STR *holi) ;

extern FL64 FutEqty_CC2NPV(DATESTR  *analys,
                           DATESTR  *spotdate,
                    FL64     spot,
                    FUTEQTY  *fute,
                    FL64     divyld,
                    DISCFAC  *df,
                    HOLI_STR *holi,
                    RISKSET  *risk,
                    FL64     *dp,
                    FL64     *ddp) ;

extern FL64ARRAY FutEqty_CC2Delta(DATESTR  *analys,
                                  DATESTR  *spotdate,
                                  FL64     spot,
                                  FUTEQTY  *fute,
                                  FL64     divyld,
                                  DISCFAC  *df,
                                  HOLI_STR *holi,
                                  DELTASET *ds) ;

extern BOOLE FutEqty_CC2Impl(DATESTR  *analys,
                        FL64     spot,
                        FL64     futp,
                        FUTEQTY  *fute,
                        FL64     divyld,
                        DISCFAC  *df,
                        HOLI_STR *holi,
                        KEYCONV  what,
                        ITERCTRL *ictrl,
                        FL64     *impl) ;

extern FL64 FutEqty_CC2AdjSpot(DATESTR  *today,
                         DATESTR  *matur,
                         FL64     spot,
                         CALCONV  cal,
                         FL64     div_yld,
                         PLAN_STR *div,
						 HOLI_STR *holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */

extern FUTEQTY Set_FUTEQTY(DATESTR  *matur,
                           PLAN_STR *div,
                           CALCONV  cal,
                           FL64     futp,
                           BOOLE    margin) ;

/* Private functions */

extern void futEqty_set_itervars(ITERCTRL *ictrl,
                                    ITERCTRL *ctrl,
                                    FL64     *shock) ;

extern FUTEQTYINT FutEqty_SetFUTEQTYINT(DATESTR  *spotdate,
                                           DATESTR  *matur,
                                           FL64     spot,
                                           FL64     futp,
                                           DFPARMS  *dfp,
                                           FUTEQTY  *fute,
                                           DISCFAC  *dfrepo,
                                           HOLI_STR *holi,
                                           FL64     shock) ;

extern void FutEqty_GetFUTEQTYINT(FUTEQTYINT *fut_data,
                                     DATESTR    **spotdate,
                                     DATESTR    **matur,
                                     FL64       *spot,
                                     FL64       *futp,
                                     DFPARMS    **dfp,
                                     FUTEQTY    **fute,
                                     DISCFAC    **dfrepo,
                                     HOLI_STR   **holi,
                                     FL64       *shock) ;

extern BOOLE FutEqty_NewtonRaphson(FL64   x, 
                                      void   *y,
                                      BOOLE  grad,
                                      FL64   *fx, 
                                      FL64   *dfx,
									  void   *hol);     /* PMSTA-29444 - SRIDHARA - 050318 */

extern void Free_FUTEQTY(FUTEQTY *fixp) ;
extern void Free_FUTCMDTY(FUTCMDTY *fixp) ;


/*** function prototyping (fxforw.c) *********************************/


/* Public functions */
extern FL64 FutFX_DF2FXrate(DATESTR    *spot,
                            FL64       fx,
                            FXFORW     *fxfw,
                            BOOLE      xspot,
                            HOLI_STR   *holi,
                            DISCFAC    *df_d,
                            DISCFAC    *df_f) ;

extern FL64 FutFX_DF2NPV(DATESTR    *analys,
                         DATESTR    *spot,
                         FL64       fx_spot,
                         FXFORW     *fxfw,
                         HOLI_STR   *holi,
                         DISCFAC    *df_d,
                         DISCFAC    *df_f,
                         RISKSET    *risk,
                         FL64       *dp,
                         FL64       *ddp) ;

extern FL64ARRAY FutFX_DF2Delta(DATESTR    *analys,
                                DATESTR    *spot,
                                FL64       fx_spot,
                                FXFORW     *fxfw,
                                HOLI_STR   *holi,
                                DISCFAC    *df_d,
                                DISCFAC    *df_f,
                                DELTASET  *ds) ;

extern FL64 FutFX_PL2NPV(FXFORW     *fxfw,
                         PLAN_STR   *fw_out,
                         HOLI_STR   *holi) ;

extern FXFORW Set_FXFORW(DATESTR *matur,
                            BOOLE   inv,
                            FL64    base,
                            FL64    fwd,
                            BOOLE   margin,
                            CALCONV cal) ;

#ifdef __cplusplus
}
#endif

#endif

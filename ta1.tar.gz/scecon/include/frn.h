/* @(#)frn.h	1.3 (SimCorp) 99/02/19 14:13:05 */

#ifndef FRN_H_INCLUDED

#define FRN_H_INCLUDED

/************************************************************************
*                                                                       *
*    project    SCecon                                                  *
*                                                                       *
*    filename   frn.h                                                   *
*                                                                       *
*    this file contains definitions and function prototyping for the    *
*    routines in the SCecon FRN module.                                 *
*                                                                       *
************************************************************************/


/****** includes *******************************************************/
#include <math.h>
#include <swapval.h>

#ifdef __cplusplus
extern "C" {
#endif


/*** typedefines ******************************************************/

/*,,SOT,,

FRN: type for holding info on FRN's
-----------------------------------

This type is defined as

        typedef struct frn_tag
        {
            REPAYMNT  repay ;
            PAYDAYDEF rday ;
            FLOATRATE float1 ;
            PAYDAYDEF pday ;
            INTI      delay ;
        }   FRN ;

Use this type to define many sorts of FRN's.

The data has the following interpretations:

        repay is the definition of repayments.
        repay.pp and repay.aufab are NOT used.
        Annuities are NOT supported.
        Use repay to define Amortising (incl. Accreting and 
        Rollercoaster) Swaps.

        rday is the definition of the repay paydays

        float1 is the definition of floating payment calculation.
        Use this to define Averaging, Compounding, LIBOR Factors,
        Stepped Spreads or Stepped Factors.
        Using Stepped Spreads and Factors one can creatively define various
        kinds of Inverse Floating (factor < 0), super floating (factor > 1)
        structures. This includes time-varying structures like vanilla
        for 3 years, then inverse floating for 2 years etc.

        pday is the definition of the floating coupon paydays.

        delay is as delay being superimposed on the paydays after calcu-
        lating the amounts.

Currently embedded options (capped, floored FRN's) must be handled using
a building block approach where the total FRN is the sum of a standard
FRN - Cap + Floor (etc).

See also Set_FRN

,,EOT,,*/

typedef struct frn_tag
{
    REPAYMNT  repay ;
    PAYDAYDEF rday ;
    FLOATRATE float1 ;
    PAYDAYDEF pday ;
    INTI      delay ;
/* to be augmented with accrued interest data:
   needed for TEC (EVENCOUP), ExCoupon ?? */
}   FRN ;


/*** prototyping (frn.c)  **********************************************/


/* Public functions */

extern BOOLE FRN_YTM2Price(DATESTR*  analys,
                        FL64      ytm,
                        FRN*      frn,
                        YTMCONV*  ytmc,
                        HOLI_STR* holi,
                        RISKCONV  risk,                    
                        BOOLE     modf,                    
                        FL64*     p,
                        FL64*     dp,
                        FL64*     ddp) ;

extern BOOLE FRN_YTM2Yield(DATESTR*  analys,
                       FL64      price,
                       FRN*      frn,
                       YTMCONV*  ytmc,
                       HOLI_STR* holi,
                       ITERCTRL   *ictrl,
                       FL64*     ytm) ;

extern BOOLE FRN_YTM2YV01(DATESTR    *analys,
                             FL64       price,
                             FRN        *frn,
                             YTMCONV    *ytmc,
                             HOLI_STR   *holi,
                             ITERCTRL   *ictrl,
                             FL64       pshift,
                             BOOLE      mean,
                             FL64       *yvb) ;

extern BOOLE FRN_YTM2PV01(FL64        ytm,
                             DATESTR     *analys,
                             FRN         *frn,
                             YTMCONV     *ytmc,
                             HOLI_STR    *holi,
                             FL64        yshift,
                             BOOLE       mean,
                             FL64        *pvb) ;

extern FL64 FRN_SM2SmplMrgn(DATESTR*  analys,
                               FL64      price,  
                               FRN*      frn,
                               FL64      Lnext,
                               HOLI_STR* holi,
                               BOOLE*    ok) ;                    

extern FL64 FRN_SM2Price(DATESTR*  analys,
                     FL64      sm,    
                     FRN*      frn,
                     FL64      Lnext,
                     HOLI_STR* holi,
                     BOOLE*    ok) ;                    

extern FL64 FRN_DM2Price(DATESTR*  analys,
                     FL64      dm,
                     FRN*      frn,
                     FL64      Lcurr,
                     FL64      Lasm,
                     HOLI_STR* holi,
                     BOOLE*    ok) ;

extern BOOLE FRN_DM2DiscMrgn(DATESTR*  analys,
                         FL64      price,
                         FRN*      frn,  
                         FL64      Lcurr,
                         FL64      Lasm,
                         HOLI_STR* holi,
                         FL64*     dm) ;

extern CFLWARRAY FRN_GenrCflw(DATESTR       *analys,
                                  FRN        *frn,
                               DISCFAC       *df,
                               DISCFAC       *df_dsc,
                               CMCONVADJ     *cmadj,
                               HOLI_STR      *holi) ;

extern CFLWARRAY FRN_GenrPeriod(DATESTR*   analys,
                             FRN*       frn,
                             DISCFAC*   df,
                             DISCFAC*   df_dsc,
                             CMCONVADJ* cmadj,
                             HOLI_STR*  holi) ;

extern FL64 FRN_DF2Price(DATESTR       *analys,
                         FRN           *frn,
                         DISCFAC       *df_cflw,
                         DISCFAC       *df_disc,
                         CMCONVADJ     *cmadj,
                         HOLI_STR      *holi,
                         DFSPREAD      *dfs,
                         RISKSET       *risk,
                         FL64          *dp,
                         FL64          *ddp) ;

extern AIRESULT FRN_Accruint(DATESTR*   analys,
                                FRN*       sfl,
                                HOLI_STR*  holi,
                                INDEXCONV  iConv) ; /*  FPL-PMSTA00211-100826   */

extern FL64ARRAY FRN_DF2Delta(DATESTR       *analys,
                              FRN           *frn,
                              DISCFAC       *df_cflw,
                              DISCFAC       *df_disc,
                              CMCONVADJ     *cmadj,
                              HOLI_STR      *holi,
                              DFSPREAD      *dfs,
                              DELTASET      *ds) ;

extern void Free_FRN(FRN* x) ;

extern FRN Set_FRN(REPAYMNT* repay, PAYDAYDEF* rday,
                      FLOATRATE* fl, PAYDAYDEF* pday, INTI delay) ;

/* Private functions */

extern CFLWARRAY FRN_YTM2Cflw(DATESTR*  analys,
                                 FRN*      frn,
                                 HOLI_STR* holi) ;

extern FL64 FRN_Discountmargin2Price(FL64      dmargin,
                                     FL64      *dp,
                                     FL64      *ddp,
                                     RISKCONV  risk,
                                     FL64      coupon,
                                     FL64      qmargin,
                                     INTI      n,
                                     FL64ARRAY clength,
                                     FL64ARRAY amort,
                                     FL64      index,
                                     FL64      assumed) ;

extern BOOLE FRN_Price2Discountmargin(FL64      price,
                                     FL64      coupon,
                                     FL64      qmargin,
                                     INTI      n,
                                     FL64ARRAY clength,
                                     FL64ARRAY amort,
                                     FL64      index,
                                     FL64      assumed,
                                     FL64      *res) ;

extern BOOLE FRN_root(FL64      price,
                     FL64      coupon,
                     FL64      qmargin,
                     INTI      n,
                     FL64ARRAY clength,
                     FL64ARRAY amort,
                     FL64      index,
                     FL64      assumed,
                     FL64      acc,
                     FL64      min,
                     FL64      *res) ;


#ifdef __cplusplus
}
#endif

#endif

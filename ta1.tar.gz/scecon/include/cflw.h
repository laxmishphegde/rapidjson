/* SCID @(#)cflw.h	1.11 (SimCorp) 99/11/11 10:34:00 */

#ifndef CFLW_H
#define CFLW_H

/************************************************************************
*                                                                       *
*    project    SCecon                                                  *
*                                                                       *
*    filename   cflw.h                                                  *
*                                                                       *
*    general    this file contains declarations, initialization ,       *
*               type definitions and function prototyping for the       *
*               cash flow module of the standard library SCecon         *
*                                                                       *
************************************************************************/

/* **** includes ***************************************************** */
#include <cldr.h>
#include <yld.h>
#include <pmt.h>
#include <unidef.h>

#ifdef __cplusplus
extern "C" {
#endif


/* **** defines  ***************************************************** */
#define PMT_TOL 0.0000000001


/* **** typedefs ***************************************************** */


/*,,SOT,,

ODDCONV : data type for odd payment periods
-------------------------------------------

The data type for handling odd coupon periods is defined as

        typedef enum oddconv_tag
        {
            NOODD,
            SHORTODD,
            LONGODD
        }   ODDCONV;

According to the NOODD convention, all coupon periods of the bond are of
equal length.

With SHORTODD the pay period is SHORT (compared to the normal ones).

With LONGODD the pay period is LONG (compared to the normal ones).

,,EOT,,*/

typedef enum oddconv_tag
{
    NOODD,
    SHORTODD,
    LONGODD
}   ODDCONV ;


/*,,SOT,,

COUPONBASE : data type for coupon calculation
---------------------------------------------

The coupon base specifies how the coupons and accrued interest are to be 
calculated. This data type is defined as

    typedef enum cbase_tag
    {
        ODDCOUP,
        EVENCOUP,
        EQUALCOUP,
        EVENODD
    }   COUPONBASE ;

Coupon calculation
------------------

The coupon base defines calculating method for coupons:

If EVENCOUP is chosen then all 'periodic' coupons are equal to the
annual coupon divided by the number of annual payments. The coupons are
therefore equal even though the number of days in the periods are not equal. 
When used in odd first and last periods 'pseudo' coupon days are inserted to 
make the coupon days periodic and the coupons are computed using a mixture
of the method for the regular coupons and day count fractions. This is in 
compliance with the ISMA conventions and used in most Government Bond Markets.

If ODDCOUP is chosen then the coupons are calculated as a day count 
fractions times the annual coupon -  in both regular and odd periods. 
The day count fraction is determined by the given calendar convention 
CALCONV. This in particular applies for the ACTLEAP calendar convention which 
implements the special ISDA swap rule for dealing with leap years. It also
applies for the ACTAFB calendar convention which is the recommended ISDA
convention for new euro swap denominations.

If EQUALCOUP is chosen then all coupon are equal to the annual coupon divided
by the number of annual payments - irrespective of the period lengths, odd 
periods etc. 

EVENODD is the same as EVENCOUP in regular periods. In long odd first and last 
periods 'pseudo' coupon days are inserted to make the coupon days periodic 
as for EVENCOUP. The coupon is then calculated as a 'periodic' coupon 
following the same scheme as EVENCOUP, plus a fractional coupon following 
the same scheme as ODDCOUP. This is used for Japanese government bonds in 
long periods.

Note that EVENCOUP, EQUALCOUP, and EVENODD only differ in their behaviour
in odd first and last periods. 

Accrued interest
----------------

The coupon base also defines the calculation method for accrued interest:
The accrued interest is then computed according to the same rules as the 
corresponding coupon.

The accrued interest is computed as the annual coupon times a day count
fraction. The numerator in the day count fraction is the number of accrued
days. The denominator is the number of days per year which is determined by
the coupon base.

If EVENCOUP is chosen then the number of days per year equals the number 
of days in the corresponding regular or 'pseudo' regular period times the 
number of annual payments. In long odd periods the day count fraction is a
sum over several periods. This is in compliance with the ISMA convention.

If ODDCOUP is chosen the number of days per year is inherent in the calendar
convention CALCONV. This means that the accrued interest equals the
next coupon - computed according to the ODDCOUP convention defined above - 
times the fraction consisting of the number of accrual days divided by the 
number of days in the coupon period. 

If EQUALCOUP is chosen then the number of days per year is the number of
days in the period times the number of annual payments.

EVENODD works as EVENCOUP in regular and 'pseudo' regular periods and as
ODDCOUP in the remaining fractional period.

,,EOT,,*/

typedef enum cbase_tag
{
    COUPONBASE_INIT = -1,
    ODDCOUP,
    EVENCOUP,
    EQUALCOUP,
    EVENODD
}   COUPONBASE ;


/*,,SOT,,

FIXDCOMP: data type for defining fixed rate decompounding
---------------------------------------------------------

The enumeration is defined as:

        typedef enum fixdcomp_tag
        {
            NODCOMP,
            EPR_PER,
            EPR_DF,
            EDDR
        }   FIXDCOMP ;

The type is used to define how decompounding on fixed rates is performed
in SCecon:
NODCOMP means that no decompounding is done.

EPR_PER means that periodic decompounded rates are found as:

                                  1/n
            fix  = ((1 + fix_rate)    - 1) * n

where n is the number of annual payments.

EPR_DF that the decompounded rate is

                                  d/dpy
            fix  = ((1 + fix_rate)      - 1) * dpy / d

where dpy is the number of days per year (given a CALCONV)  and d is the
number of days in the current period. This is used for FRF domestic market
TAM and TAG swaps (fixed legs in broken periods). Note that TAM/TAG's use
ACTACT.

EDDR means that the decompounded rate is:

                                            1/d
            fix  = ((1 + fix_rate * d / dpy)    - 1) * dpy

where dpy is the number of days per year (given a CALCONV)  and d is the
number of days in the current period. This is used for FRF domestic market
T4M swaps (fixed legs). Note that T4M's use ACT360.

N.B. EPR means equivalent period rate, and EDDR means equivalent day-to-day
rate.

Note that EPR_DF and EDDR are not supported for ANNUITY's and SERIAL's.

,,EOT,,*/

typedef enum fixdcomp_tag
{
    FIXDCOMP_INIT = -1,
    NODCOMP,
    EPR_PER,
    EPR_DF,
    EDDR
}   FIXDCOMP ;



/*,,SOT,,

PAYDAYSEQ: a data type for holding info on payday sequencing
------------------------------------------------------------

This type is defined as:

        typedef struct paydayseq_tag
        {
            ODDCONV   odd1 ;
            ODDCONV   oddn ;
            SEQCONV   seq ;
            INTI      term ;
            TERMUNIT  unit ;
            EOMCONV   eom ;
        }   PAYDAYSEQ ;

The data are interpreted as:

        odd1 is the odd convention for the first pay period

        oddn is the odd convention for the last pay period

        seq is the sequencing convention

        term / unit defines the 'rhythm' or frequency of the payments.
        This allows for very general payday schemes. term must be
        positive.

        eom is the end of months convention

for irregular paydays (defined as a list in a PAYDAYDEF) let term = 0, and
the other members with legal values.

This setup allows for generation of a fairly general list of 'event' dates
associated with cashflows, fixing dates and the like.

see also Set_PAYDAYSEQ

,,EOT,,*/

typedef struct paydayseq_tag
{
    ODDCONV   odd1 ;
    ODDCONV   oddn ;
    SEQCONV   seq ;
    INTI      term ;
    TERMUNIT  unit ;
    EOMCONV   eom ;
}   PAYDAYSEQ ;


/*,,SOT,,

PAYDAYDEF: a data type for holding info on payday generation
------------------------------------------------------------

This type is defined as:

        typedef struct paydaydef_tag
        {
            BOOLE     is_first ;
            DATESTR   first ;
            DATESTR   seclast ;
            DATESTR   last ;
            BOOLE     snap2 ;
            PAYDAYSEQ pseq ;
            INTI      nirreg ;
            DATEARRAY irreg_days ;
        }   PAYDAYDEF ;

The type is used to define sequences of days - to be used for fixing,
payments or similar events.

The data are interpreted as:

        if is_first is True then first is the first payday. 
        If it is False then first is assumed to be the issue date.
        The EOMCONV in pseq will automatically be relative
        to issue date or first payday depending on is_first.
        NB: When Japanese Government Bonds are entered (using the jgb 
        switch in FIXRATE) first payday must be entered.

        first is the first payday or the issue date (see is_first).
        Note that for regular paying loans the first date is not needed. 
        Only for loans with odd first periods is it really needed, otherwise 
        it can be derived from the issue date.
        So use issue date for regular loans.
        Need not be entered if irreg_days are filled. Note that if
        coupons are prepaid, then first is not the first payday
        of the coupons but the second payday (corresponding to the end
        of the first coupon period).
        
        seclast is the second last payday. Only used if pseq.oddn is
        LONGODD. seclast can be used for having VERY long final payment
        periods. If pseq.oddn is LONGODD and seclast is 0, then the
        usual finallong period is generated (i.e. only 1 extra pay
        period). So essentially seclast should only be used for extra
        long (more than 2 pay periods) final periods, or when using
        ANCHORBACK with a final odd period.
        Need not be entered if irreg_days are filled.
        Default is a value of {0, 0, 0}, in which case seclast is ignored.

        last is the maturity day. Must always be entered - even if irreg_days
        is filled with dates.

        snap2 is used if pseg.seg is IMM, CAD_BA, IMM_ZAR, TAM_T4M or LASTBUS. 
        Is snap2 is True then first/seclast/last are 'snapped' to the first 
        coming IMM etc date following the one that was originally set in 
        first/ seclast/last. If it is False no dates are adjusted.
        So in order to 'snap' correctly put in a date shortly before the
        relevant IMM/CAD_BA/IMM_ZAR/LASTBUS date (e.g. the first of the 
        relevant month). For TAM_T4M insert the transaction date.

        pseq defines the sequencing of the paydays. Not used if irreg_days
        are filled.
        Note that if final and first period is broken, then either
        first event or seclast  event days must be used.
        For JGB's (jgb in FIXRATE True) pseq.unit must be MONTHS - which
        in general is the most sensible value.

        nirreg is the number of irregular paydays. Only used if irregularly
        spaced dates are to be generated. 
        Typically nirreg is just 0, for generation of regular paydays.

        the date list irreg_days[nirreg] contains nirreg irregular
        paydays (if there is any).

Note that using PAYDAYDEF's one can define most standard 'event' flows like:

        cashflow sequences encountered in the Swap, or
        Bond / FRN markets, or 
        fixing sequences for interest rate options - like Caps, or
        exercise dates for Bermudan-Style Options etc.

See Cflw_Paydays() for a routine that generates sequences of event dates.

see also Set_PAYDAYDEF

,,EOT,,*/

typedef struct paydaydef_tag
{
    BOOLE     is_first ;
    DATESTR   first ;
    DATESTR   seclast ;
    DATESTR   last ;
    BOOLE     snap2 ;
    PAYDAYSEQ pseq ;
    INTI      nirreg ;
    DATEARRAY irreg_days ;
}   PAYDAYDEF ;


/*,,SOT,,

FIXRATE: a data type for holding info on fixed coupon generation
----------------------------------------------------------------

This type is defined as:

        typedef struct
        {
            FL64       fix_rate ;
            CALCONV    cal ;
            DATESTR    effective ;
            DATESTR    lastaccr ;
            FL64       accrfac ;
            COUPONBASE cbase ;
            COUPONBASE cbodd ;
            BOOLE      prepaid ;
            BOOLE      jgb ;
            PLAN_STR   *stepcoup ;
            BOOLE      holpre ;
            PLAN_STR   *irreg ;
            FIXDCOMP   decomp ;
        }   FIXRATE ;

The data are used to define how fixed coupons sequences are calculated.

    fix_rate is the coupon or swaprate (%)

    cal is the calendar used for coupon calculation

    effective is the date from which coupons are accrued.
        If SEQCONV for coupon paydays is defined as TAM_T4M 
        and the corresponding snap2 is True then effective is adjusted 
        to closest first in month. Thereby one can just insert the 
        transaction date as effective, and the routines will automatically
        adjust it.
        (in SwapFix_GenrCflw(), Bond_GenrCflw() and Cflw_GenrCflw()).

    lastaccr is the last date on which interest accrues, this is
        usually equal to the maturity date. If lastaccr is 0, then it
        will be ignored.
        If SEQCONV for coupon paydays is defined as TAM_T4M 
        and the corresponding snap2 is True then lastaccr is adjusted 
        to closest first in month. (Use lastaccr = 0 though).
        (in SwapFix_GenrCflw(), Bond_GenrCflw() and Cflw_GenrCflw()).

    accrfac is a factor that determines how much interest that is paid
        out at the end of the current interest period, and how much is
        added on the notional amount to facilitate interest on interest.
        The part that earns interest on interest is being paid at maturity.
        accrfac is usually 0.0 (for standard bonds). If accrfac is 1.0
        then all interest is being paid at maturity. Sometimes accrfac
        can be between 0.0 and 1.0.
        Examples include German Bundesschatzbriefe Typ B, where accrfac
        is 1. A few ITL issues has an accrfac between 0.0 and 1.0.
        If accrfac > 0.0 then prepaid is assumed to be False.

    cbase defines how to calculate coupons in normal periods.
        If EVENCOUP then the coupon equals the annual coupon divided by 
        number of annual payments, corresponding to the ISMA standard.
        If ODDCOUP then the coupon equals the annual coupon times the
        day count fraction defined by the calendar convention corresponding
        to the ISDA standard.
        
    cbodd defines how to calculate coupons in odd first and last periods.
        If EVENCOUP then the coupons are calculated by inserting 'fictitious' 
        coupon days, corresponding to the ISMA standard.
        If ODDCOUP then the coupons are calculated as for normal periods.
        EQUALCOUP makes all coupons equal while EVENODD is a special Japanese
        method for long odd periods.

    prepaid This informs that the coupons are paid (is set to True) at the
        start of the coupon calculation periods. If prepaid is False coupons
        are paid in arrears (as it is usually the case).

    jgb If True then 2 specialties for Japanese Government Bonds are
        automatically invoked.

            1) In the first couon period 1 extra day of accrued
               interest is inserted.
            2) If the maturity day is not a good business date, then this
               day is automatically shifted, and an extra accrual day is
               used.

        note that is is assumed that this switch is invoked only when
        relevant - i.e. when the bond is a 'valid' JGB Bond.
        It is assumed that JGB's are all Bullet bonds.
        For this to work the issue date must not have been preadjusted
        elsewhere.


    stepcoup|NULL is used for informing on stepped coupon plans
        (sometimes referred to as rate adjustments).
        Stepped coupons are fairly unusual, to switch it of just put
        a zero in stepcoup->filled, or alternatively set stepcoup to NULL.
        The dates in stepcoup must be ordered ascendingly and be unique.
        The rates are effective from the first date after stepcoup->day[i].
        The last rate is in effect the rest of the life of the security.
        If the first date in stepcoup is after effective, then fix_rate is in
        effect until the first rate change. Also if stepcoup->filled is zero
        then fix_rate is used for the entire life of the security.
        If a negative rate is found, then the maturity is adjusted to the
        first amortisation date prior or equal to to the mark date, or in
        the case of bullet's the latest coupon date prior to or equal to the
        mark date.

    holpre indicates when businessday adjustments are performed (if
        specified). True means that paydays are adjusted prior to
        calculating the coupons (as for swap fix legs).
        False means that the coupons are calculated based on UNadjusted
        paydays, and the paydays are adjusted after coupon calculation (as
        for most bonds).

    irreg|NULL is a list of completely irregular coupon paydays and payments.
        If this is specified then the coupons are taken from this list
        without any daycount adjustment etc.
        Switch it of by setting irreg to NULL or let irreg->filled = 0.

    decomp indicates whether fix_rate is an effective or simple rate.
        If decomp is NODCOMP, then fix_rate is assumed to be a simple rate,
        and coupons are calculated the standard way:

             C  = fix * days(prev, next, cal)/denominator
              i

        if however decomp is EPR_PER, then fix_rate is assumed to be an
        annual effective rate. The periodic (simple) rate used for coupon
        calculation is as described under FIXDCOMP. The conversion
        is performed in SCecon. So fix_rate is assumed to be the annual 
        effective rate (as quoted in the term sheet).
        If irreg is used then decomp is ignored.

see also Set_FIXRATE

,,EOT,,*/

typedef struct
{
    FL64       fix_rate ;
    CALCONV    cal ;
    DATESTR    effective ;
    DATESTR    lastaccr ;
    FL64       accrfac ;
    COUPONBASE cbase ;
    COUPONBASE cbodd ;
    BOOLE      prepaid ;
    BOOLE      jgb ;
    PLAN_STR   *stepcoup ;
    BOOLE      holpre ;
    PLAN_STR   *irreg ;
    FIXDCOMP   decomp ;
}   FIXRATE ;


/*,,SOT,,

PP_STR: a data type for holding info on partly payments
-------------------------------------------------------

This type is defined as:

        typedef struct
        {
            FL64     pp_price ;
            PLAN_STR *ppmts ;
        }   PP_STR ;

These data items have the following meaning:

    pp_price is the minimum tender price at which the partly paid
        bond is originally purchased

    ppmts|NULL is a list of partly payments with ppmts->filled entries.
        The partly payments must sum to 100.
        To avoid entering partly payments just enter ppmts->filled as 0,
        or let ppmts be NULL.

see also Set_PP_STR

,,EOT,,*/

typedef struct
{
    FL64     pp_price ;
    PLAN_STR *ppmts ;
}   PP_STR ;


/*,,SOT,,

REPAYMNT: a data type for holding info on repayments
----------------------------------------------------

This type is defined as:

        typedef struct repaymnt_tag
        {
            BONDTYPE  type ;
            DATESTR   teomatur ;
            BOOLE     io ;
            FL64      init_exch ;
            PP_STR    pp ;
            PLAN_STR  *irreg ;
            PLAN_STR  *aufab ;
            FL64      rpct ;
            FL64      rpct_first ;
        }   REPAYMNT ;

For defining sequences of repayments for Bonds, FRN's, Swaps etc

    type is the type of amortisation

    teomatur is the theoretical maturity - if this is later than the
        maturity (defined elsewhere) then a balloon amortisation will
        happen on the maturity date (and nothing otherwise). The
        amortisations are generated from first repayday till the theoretical
        maturity, and then the balloon payment happens on the actual maturity.
        Default value (to avoid balloons) is {0, 0, 0}.

    io indicates where the amortisations are real (False) or just
        notional (True). 
        Used for swap legs.

    init_exch indicates an initial payment (possibly 0) taking place on
        the effective date (defined elsewhere) of the cashflow.
        Used for swap legs.

    pp is a definition of a partly pay issue (as known in UK Gilts).

    irreg|NULL is a list of irregular amortisations. Must be filled if type is
        NONREGULAR. The elements in irreg->f64 must sum to 100.
        If irreg is NULL it assumed to be empty.

    aufab|NULL is a list of repayment prices. If empty all redemptions are
        at 100. aufab reflects the German terminology Auf-/Abgeld.
        If aufab is NULL it assumed to be empty.

    rpct indicates a given total payment or repayment percentage.
        Only used for type SERIAL_PCT / ANNUITY_PCT.
        For ANNUITY_PCT loans it is a total payment percentage.
        For SERIAL_PCT loans it is a repayment percentage.
        These features are known in Danish Mortgage loans.

    rpct_first is used if rpct > 0.0.
        Only used for type SERIAL_PCT / ANNUITY_PCT.
        For ANNUITY_PCT loans it is the first total payment percentage.
        For SERIAL_PCT loans it is the first repayment percentage.
        If it is not used, just enter a value less than or equal to 0.0.

see also Set_REPAYMNT

,,EOT,,*/

typedef struct repaymnt_tag
{
    BONDTYPE  type ;
    DATESTR   teomatur ;
    BOOLE     io ;
    FL64      init_exch ;
    PP_STR    pp ;
    PLAN_STR  *irreg ;
    PLAN_STR  *aufab ;
    FL64      rpct ;
    FL64      rpct_first ;
}   REPAYMNT ;


/*,,SOT,,

CFLW_STR and CFLWARRAY : data types for cashflows
-------------------------------------------------

These types are defined in cflw.h as:

        typedef struct
        {
            INTI      count ;
            INTI      filled ;
            DATEARRAY days ;
            FL64ARRAY repay ;
            FL64ARRAY coupon ;
        }   CFLW_STR;

        typedef CFLW_STR * CFLWARRAY ;

CFLWARRAY represents lists of cshflows of more securities, whereas a CFLW_STR
contains the flow of a single security.

        filled is the number of entries filled (set by functions defining
        a CFLW_STR or by the user)

        count is the number of data allocted - to be set by the user.

        days[filled] is a list of paydays (with filled entries)

        repay[filled] is a list of repayments (with filled entries)

        coupon[filled] represents a list of coupon payments (with filled
        entries)

Clearly count >= filled.

See Cflw_Insert_In_Cflw() for a routine to fill in elements.

,,EOT,,*/

typedef struct
{
    INTI      count ;
    INTI      filled ;
    DATEARRAY days ;
    FL64ARRAY repay ;
    FL64ARRAY coupon ;
    FL64ARRAY ratesTab ; /* PMSTA10118 - DDV - 100623 */
}   CFLW_STR ;

typedef CFLW_STR * CFLWARRAY ;

/* CFLW_STR utilities */
#define GetCflwDays(cflw)   (cflw != NULL ? cflw->days : NULL)
#define GetCflwRepay(cflw)  (cflw != NULL ? cflw->repay : NULL)
#define GetCflwCoupon(cflw) (cflw != NULL ? cflw->coupon : NULL)
#define GetCflwFill(cflw)   (cflw != NULL ? cflw->filled : 0)
#define GetCflwCount(cflw)  (cflw != NULL ? cflw->count : 0)


/*,,SOT,,

EXDAYCONV: data type for holding info on ex-coupon/-principal principle
-----------------------------------------------------------------------

This type is defined in cflw.h as:

        typedef enum exday_tag
        {
            EX_DAYS,
            EX_DATE,
            EX_DATEARRAY,
            EX_FIX,
            EX_AUT,
            EX_OLDBRD,
            EX_UKGILT,
            EX_IRLGILT
        }   EXDAYCONV ;

This type defines how an ex-coupon, ex-dividend or ex-principal date is
calculated. The following conventions are available.

        EX_DAYS means a fixed number of days before a given date (e.g.
        30 in DK or 0 in USA etc).

        EX_DATE means that bond goes ex on a specific date (used for
        ex-principal in DK)

        EX_DATEARRAY means that the ex-date is specified as a list of
        ex-dates (one for each payment date).

        EX_FIX means that the ex-status is fised, and set anywhere.

        EX_AUT is the Austrian domestic rules.

        EX_OLDBRD means the old German rules (not in effect from 1/1/94).
        After this date Bunds do not trade ex-coupon.

        EX_UKGILT means the special UK Gilt rules (except the War Loan).
        After 1/1/-96 the original rules are changed such that the 
        ex-dividend period is 7 working days. This rule is aso implemented
        and a check is made for the date 1/1-96 to select the rule version.

        EX_IRLGILT means the special Irish Gilt rules. 
        Wednesday nearest 3 weeks before coupon.

,,EOT,,*/

typedef enum exday_tag
{
    EXDAYCONV_INIT = -1,    
    EX_DAYS,
    EX_DATE,
    EX_DATEARRAY,
    EX_FIX,
    EX_AUT,
    EX_OLDBRD,
    EX_UKGILT,
    EX_IRLGILT
}   EXDAYCONV ;


/*,,SOT,,

EXRULE: data type for holding info on ex-coupon/-principal calculation
----------------------------------------------------------------------

This type is defined in cflw.h as:

        typedef struct exrule_tag
        {
            EXDAYCONV xconv ;
            INTI      exdays ;
            BOOLE     caldays ;
            CALCONV   cal ;
            DATESTR   dex ;
            INTI      npday ;
            DATEARRAY pday ;
            DATEARRAY xpday ;
            BOOLE     xlast ;
        }   EXRULE ;

The data structure is used to handle bond data based ex-calculations.

        xconv is the convention used for ex-calculation. Can be one of:
        EX_DATE, EX_DATEARRAY, EX_DAYS, EX_AUT, EX_OLDBRD, EX_UKGILT
        or EX_IRLGILT

        exdays is the number of ex-coupon/-principal days, used only if
        xconv is EX_DAYS.

        If caldays is True then exdays is interpreted as calendar-days,
        if caldays is False then exdays is interpreted as businessdays,
        used only if xconv is EX_DAYS.

        cal is used to subtract days according to a specified daycount setup
        when caldays is set to True, used only if xconv is EX_DAYS.

        dex is a specific date used when xconv is EX_DATE.

        npday is the number of elements in pday / xpday.
        Only used ix xconv is EX_DATEARRAY.

        pday[npday] is a list of paydays.
        Only used ix xconv is EX_DATEARRAY.

        xpday[npday] is a list of ex-days. One for each pday.
        Only used ix xconv is EX_DATEARRAY.

        xlast is True if the bond can be ex in the last coupon / repayment
        period, and False if it is never ex in the last period.
        This switch overrides any other convention in the last period ONLY.

see also Set_EXRULE

,,EOT,,*/

typedef struct exrule_tag
{
    EXDAYCONV xconv ;
    INTI      exdays ;
    BOOLE     caldays ;
    CALCONV   cal ;
    DATESTR   dex ;
    INTI      npday ;
    DATEARRAY pday ;
    DATEARRAY xpday ;
    BOOLE     xlast ;
}   EXRULE ;


/*,,SOT,,

EXTRADE: data type for holding info on ex-coupon/-principal calculation
-----------------------------------------------------------------------

This type is defined in cflw.h as:

        typedef struct extrade_tag
        {
            BOOLE  spec ;
            BOOLE  ex_fix ;
        }   EXTRADE ;

        spec specifies if any special ex-rules for this particular trade
        apply. If True then the ex-status is implied in the EXTRADE data.
        If False then this is specified elsewhere (EXRULE).
        Any EXTRADE data always overrules any EXRULE data.

        ex_fix is the ex-specification (if spec is True), otherwise
        not used

see also Set_EXTRADE

,,EOT,,*/

typedef struct extrade_tag
{
    BOOLE spec ;
    BOOLE ex_fix ;
}   EXTRADE ;


/*,,SOT,,

ACCRUINT: data type for holding info on accrued interest calculation
--------------------------------------------------------------------

This type is defined as:

        typedef struct accruint_tag
        {
            CALCONV    cal ;
            COUPONBASE cb_accru ;
            COUPONBASE cbodd_accru ;
            BOOLE      incl ;
            BOOLE      pre ;
            IRRCONV    irr ;
            INTI       qbas ;
            BOOLE      schuldsch ;
            BOOLE      CGB184 ;
            BOOLE      BRDfeb ;
            EXRULE     exr ;
        }   ACCRUINT ;

This type  defines of the accrued interest calculation.

        cal determines on the calendar used for accrued interest calculation.

        cb_accru and cbodd_accru are for defining the accrued calculation
        principle in normal and odd first and last periods.

        If incl is True then the interest in the period accrues
        from, and including, last coupon payment day to, and including, the 
        valuation day. This has been used in Italy.
        If incl is False then the interest in the period accrues from, 
        and including, last coupon payment day to, but excluding, the 
        valuation day. This is the usual setting.

        pre is a switch to tell how accrued interest before interest start is
        handled. If True then interest in the period is accrued. This has been
        used in Spain.
        If False then interest in the period is NOT accrued. This is the usual
        setting.

        irr and qbas is used to indicate the interest rate convention used
        for accrued calculation, irr can be SIMPLE_MM or COMPOUND. qbas is
        only used if irr is COMPOUND.
        Default is SIMPLE_MM

        schuldsch is an indicator for a schuldschein - meaning that accrued
        interest is exchanged on the coming coupon day.

        CGB184 is a switch to indicate if the special Canadian Government
        Bond rule for calculating accrued interest on the 183'rd day in a
        semiannual period is to be invoked. True means invoke while False means
        do not invoke. This rule should only be used with data that are
        representative of the CGB setup, e.g. no amortisations on non-coupon
        days, etc. Essentially no 'events' between paydays.

        BRDfeb indicates the special BRD rule that when Zinsvaluta is
        on the last day of february and Geldvaluta is on the first day
        of march then the accrued interest is adjusted (by 1 or 2 days).

        exr determines if the trade is ex-coupon or not.

see also Set_ACCRUINT

,,EOT,,*/

typedef struct accruint_tag
{
    CALCONV    cal ;
    COUPONBASE cb_accru ;
    COUPONBASE cbodd_accru ;
    BOOLE      incl ;
    BOOLE      pre ;
    IRRCONV    irr ;
    INTI       qbas ;
    BOOLE      schuldsch ;
    BOOLE      CGB184 ;
    BOOLE      BRDfeb ;
    EXRULE     exr ;
}   ACCRUINT ;


/*,,SOT,,

TRADEINFO and TRADEINFOARRAY: struct for holding info on trade specific data
----------------------------------------------------------------------------

Defined in cflw.h as:

        typedef struct tradeinfo_tag
        {
            DATESTR trade ;
            DATESTR aisttl ;
            DATESTR settle ;
            BOOLE   brd ;
            FL64    price ;
            FL64    nom ;
            EXTRADE xctrade ;
            EXTRADE xptrade ;
        }   TRADEINFO ;

        trade is the trade date (only used if the switch brd is True).

        aisttl is the date on which accrued interest is calculated.
        ('Zinsvaluta' in BRD).

        settle is the settlement date. (Refered to as 'Geldvaluta' in
        BRD). Usually aisttl = settle outside of BRD.
        Only used in accrued interest calculation if brd is True.
        Otherwise aisttl is the date used.

        brd is a switch for BRD specialties.
        If brd is False then - trade, settle are NOT used in accrued
        interest calculation.
        If brd is True then  - trade, settle are used, and the special
                               brd rules are invoked.

        price is the settlement price (not including accrued interest)

        nom is the notional amount.

        xctrade is the definition of any special agreements concerning
        ex-coupon calculation. If brd is True the issue is never ex-coupon
        ('vermeidung von minus-stuckzinsen'), except before issue (if
        the appropriate switch is set - see ACCRUINT).

        xptrade is the definition of any special agreements concerning
        ex-principal calculation.

Lists of TRADEINFO's can be defined as:

        typedef TRADEINFO * TRADEINFOARRAY ;

see also Set_TRADEINFO

,,EOT,,*/

typedef struct tradeinfo_tag
{
    DATESTR trade ;
    DATESTR aisttl ;
    DATESTR settle ;
    BOOLE   brd ;
    FL64    price ;
    FL64    nom ;
    EXTRADE xctrade ;
    EXTRADE xptrade ;
}   TRADEINFO ;

typedef TRADEINFO * TRADEINFOARRAY ;


/*,,SOT,,

AIRESULT: struct for holding info on an accrued interest calculation
--------------------------------------------------------------------

Defined in cflw.h as:

        typedef struct airesult_tag
        {
            FL64    AI ;
            INTI    AIdays ;
            DATESTR next ;
            BOOLE   exc ;
            FL64    AI_per_day ;
	    FL64    AI_denom ; 
        }   AIRESULT ;

where the data have the following interpretation:

        AI is the accrued interest

        AIdays is the number of accrual days

        next is the next coupon day

        exc is True if the bond is ex-coupon, False if not.

        AI_per_day is AI / AIdays
   
	AI_denom is days per year used as denominator

,,EOT,,*/

typedef struct airesult_tag
{
    FL64    AI ;
    INTI    AIdays ;
    DATESTR next ;
    BOOLE   exc ;
    FL64    AI_per_day ;
    FL64    AI_denom ;	/* PMSTA-10628 - RAK - 110110 */
}   AIRESULT ;


/*,,SOT,,

EXINF: data type for holding info on ex-coupon/-principal status
----------------------------------------------------------------

This type is defined in cflw.h as:

        typedef struct exinf_tag
        {
            BOOLE  exp_start ;
            BOOLE  exc_start ;
            BOOLE  exp_end ;
            BOOLE  exc_end ;
        }   EXINF ;

        EXINF is used in Cflw_ExtractPeriod() to return output 
        information about ex-coupon/-principal status. 

        exp_start is used to signal the ex-principal status at
        the start of the period.
        True means that the next redemption (after the start of
        the period) is ex-principal. False that it is not.

        exc_start is used to signal the ex-coupon status at
        the start of the period.
        True means that the next coupon (after the start of
        the period) is ex-coupon. False that it is not.

        exp_end is used to signal the ex-principal status at
        the end of the period.
        True means that the next redemption (after the end of
        the period) is ex-principal. False that it is not.

        exc_end is used to signal the ex-coupon status at
        the end of the period.
        True means that the next coupon (after the end of
        the period) is ex-coupon. False that it is not.

,,EOT,,*/

typedef struct exinf_tag
{
    BOOLE  exp_start ;
    BOOLE  exc_start ;
    BOOLE  exp_end ;
    BOOLE  exc_end ;
}   EXINF ;


/* **** macros *********************************************************/


/* **** function prototyping (paydays.c)  ****************************** */


/* Public functions */

extern INTI  Cflw_PaydaysCount(PAYDAYDEF *pday,
                                HOLI_STR  *holi) ;

extern DATEARRAY Cflw_Paydays(PAYDAYDEF  *pday,
                              HOLI_STR   *holi,
                              INTI       *count) ;

extern PAYDAYDEF Cflw_ExtractPaydays(DATESTR *first,
                                        DATESTR *last,
                                        PAYDAYDEF *pday,
                                        HOLI_STR *holi);

extern PAYDAYSEQ Set_PAYDAYSEQ(INTI term, TERMUNIT unit,
                                  ODDCONV odd1, ODDCONV oddn, SEQCONV per,
                                  EOMCONV eom) ;

extern PAYDAYDEF Set_PAYDAYDEF(BOOLE is_first, DATESTR *first, 
                                    DATESTR *seclast, DATESTR *last,
                                    BOOLE snap2, PAYDAYSEQ *pseq, 
                                    INTI nirreg, DATEARRAY irreg_days) ;

/* Private functions */
extern INTI  Cflw_mmdd2Paydays_count(DATESTR * dstart,
                              DATESTR * dmatur,
                              MMDDARRAY mmdd,
                              INTI      n,
                              ODDCONV   odd) ;

extern DATEARRAY Cflw_mmdd2Paydays(DATESTR * dstart,
                                   DATESTR * dmatur,
                                   MMDDARRAY mmdd,
                                   INTI      n,
                                   ODDCONV   odd,
                                   INTI      *count) ;

extern PAYDAYDEF cflw_set_payday(DATESTR *first, DATESTR *seclast, 
                                 DATESTR  *last,
                                 BOOLE snap2, INTI term, 
                                 TERMUNIT unit,
                                 ODDCONV odd1, ODDCONV oddn, 
                                 SEQCONV per, EOMCONV eom) ;

extern DATESTR Cflw_Snap2(DATESTR *in, SEQCONV seq, BOOLE snap2, 
                             HOLI_STR *holi);

extern BOOLE Cflw_Is_Anchored(SEQCONV roll) ;


/* **** function prototyping (exdays.c) ******************************** */


/* Public functions */

extern BOOLE Cflw_XdayCalc(DATESTR   *dsettle,
                           DATESTR   *prev,
                           DATESTR   *next,
                           DATESTR   *last,
                           EXRULE    *exr,
                           EXTRADE   *extr,
                           HOLI_STR  *holi) ;
/* Private functions */

extern BOOLE Cflw_Is_Excoupon(DATESTR *dsettle,
                              DATESTR *dcoupon,
                              INTI    ds) ;

extern BOOLE Cflw_Is_ExcouponBRD(DATESTR *dsettle,
                                 DATESTR *dcoupon) ;

extern BOOLE Cflw_Is_Exprincipal(DATESTR *dsettle,
                                 DATESTR *dprincipal) ;

extern BOOLE Cflw_Is_Date_Ex(DATESTR   *dsettle,
                             DATEARRAY days,
                             FL64ARRAY pmts,
                             DATEARRAY xdays,
                             INTI      ncflw,
                             INTI      excdays,
                             BOOLE     xdays_ok,
                             BOOLE     BRDrule) ;

extern DATESTR Cflw_Exday(DATESTR   *dsettle,
                          DATESTR   *next,
                          EXRULE    *exr,
                          HOLI_STR  *holi) ;


/* **** function prototyping (pmtconv.c)  ****************************** */


/* Public functions */

extern PMTARRAY Cflw_Cflw2Pmt(DATESTR  *start,
                              CFLW_STR *cflw,
                              CALCONV  cal) ;

extern PMTARRAY Cflw_MergePMTARRAY(PMTARRAY  pmts,
                                    INTIARRAY indices,
                                    FL64ARRAY weight,
                                    INTI      n) ;

extern PLANARRAY Cflw_MergePLANARRAY(PLANARRAY pmts1,
                                      INTIARRAY indices1,
                                      FL64ARRAY weight1,
                                      INTI      n) ;

extern PLANARRAY Cflw_ProjectPLANARRAY(PLAN_STR  *in,
                                        DATEARRAY dates,
                                        INTI      n,
                                        CALCONV   cal,
										FL64      rate,
										HOLI_STR  *holi) ; 	/* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */

/* Private functions */
extern PMTARRAY Cflw_Cflw2Pmt_Scan(DATESTR   *start,
                                   CFLW_STR  *cflw,
                                   CALCONV   cal_per1,
                                   CALCONV   cal_per2,
                                   INTI      norig,
                                   DATEARRAY origdays) ;

extern void Cflw_FL64ARRAY2PMTARRAY(INTI      count,
                                    FL64ARRAY rates,
                                    FL64ARRAY amort,
                                    FL64ARRAY terms,
                                    PMTARRAY  pmtstr) ;

extern INTI Cflw_PMTARRAY2FL64ARRAY(FL64ARRAY pmt,
                                    FL64ARRAY terms,
                                    PMTARRAY  pmtstr) ;


/***** function prototyping (cflw.c)  **********************************/


/* Public functions */

extern INTI Cflw_Insert_In_Cflw(DATESTR *date,
                             FL64    amort, 
                             FL64    coupon,
                             CFLW_STR* cflw) ;

extern CFLWARRAY Cflw_ExtractCflw(DATESTR   *date1,
                                  DATESTR   *date2,
                                  CFLW_STR  *cflw,
                                  INTI      start,
                                  BOOLE     exc1,
                                  BOOLE     exp1,
                                  BOOLE     exc2,
                                  BOOLE     exp2,
                                  HOLI_STR *holi) ;
/*PMSTA-40263-ARUN-29102020*/

extern FL64 Cflw_DebtPerDate(DATESTR   *date1,
                               INTI      count,
                               DATEARRAY pdays,
                               FL64ARRAY amort,
                               BOOLE     exp1,
                               INTI      start) ;

extern void Cflw_NormCashflow(INTI      count,
                               FL64ARRAY rates,
                               FL64ARRAY amort);


extern FL64ARRAY Cflw_GenrCoupons(FIXRATE    *fix,
                              PLAN_STR   *amort,
                              DATEARRAY  cdays,
                              INTI       nc,
                              PLAN_STR   *pp,
							  PAYDAYSEQ  *pseq,
							  HOLI_STR   *holi,              /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */
							  FL64ARRAY   fixRate = NULL,
							  FLAG_T mktConvMethodEnblFlg = FALSE); 	 /* PMSTA-42879 - SRIDHARA - 18032021 */

extern FL64ARRAY Cflw_GenrCouponRates(FIXRATE    *fix,
                              DATEARRAY  cdays,
                              INTI       nc,
                              PAYDAYSEQ  *pseq,
							  HOLI_STR   *holi) ; 	/* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */

extern INTI Cflw_Balloon(DATEARRAY amortdays,
                         INTI      na,
                         DATESTR   *matur,
                         FL64ARRAY amort) ;

extern void Free_PAYDAYDEF(PAYDAYDEF *p);

extern EXTRADE Set_EXTRADE(BOOLE spec, BOOLE ex_fix) ;

extern TRADEINFO Set_TRADEINFO(DATESTR *trade, DATESTR *aisttl, 
                                    DATESTR *settle, BOOLE brd, FL64 price, 
                                    FL64 nom, EXTRADE *xctrade,
                                    EXTRADE *xptrade) ;

extern PP_STR Set_PP_STR(FL64 p, PLAN_STR *pp) ;

extern EXRULE Set_EXRULE(EXDAYCONV xconv,
                       INTI      exdays,
                       BOOLE     caldays,
                       CALCONV   cal,
                       DATESTR   *dex,
                       INTI      npday,
                       DATEARRAY pday,
                       DATEARRAY xpday,
                       BOOLE     xlast) ;

extern ACCRUINT Set_ACCRUINT(CALCONV    cal,
                             COUPONBASE cb_accru,
                             COUPONBASE cbodd_accru,
                             BOOLE      incl,
                             BOOLE      pre,
                             IRRCONV    irr,
                             INTI       qbas,
                             BOOLE      schuldsch,
                             BOOLE      CGB184,
                             BOOLE      BRDfeb,
                             EXRULE     *exr) ;

extern REPAYMNT Set_REPAYMNT(BONDTYPE  type,
                             DATESTR   *teomatur,
                             BOOLE     io,
                             FL64      init_exch,
                             PP_STR    *pp,
                             PLAN_STR  *irreg,
                             PLAN_STR  *aufab,
                             FL64      rpct,
                             FL64      rpct_first) ;

extern FIXRATE Set_FIXRATE(FL64       fix_rate,
                         CALCONV    cal,
                         DATESTR    *effective,
                         DATESTR    *lastaccr,
                         FL64       accrfac,
                         COUPONBASE cbase,
                         COUPONBASE cbodd,
                         BOOLE      prepaid,
                         BOOLE      jgb,
                         PLAN_STR   *stepcoup,
                         BOOLE      holpre,
                         PLAN_STR   *irreg,
                         FIXDCOMP   decomp) ;

/* Private functions */

extern void Cflw_Redemption_Price(DATEARRAY adays,
                                  FL64ARRAY amt,
                                  INTI      na,
                                  DATEARRAY rpdays,
                                  FL64ARRAY rprice,
                                  INTI      nrp) ;

extern INTI Cflw_FindNextPmt(FL64ARRAY pmt,
                             INTI      n,
                             INTI      start) ;

extern INTI Cflw_FindPrevPmt(FL64ARRAY pmt1, INTI  n, INTI  start) ;

extern BOOLE Cflw_Is_Harmonic(INTI term, TERMUNIT unit, INTI *m) ;

extern DATEARRAY Cflw_Fictcoup(DATESTR *issue, DATEARRAY cdays, INTI nc,
                               COUPONBASE cbodd, PAYDAYSEQ *pseq, INTI *nf) ;

extern FL64 Cflw_Decompound(FL64     act_coupon,
                        INTI     months,
                        BOOLE    harm,
                        FIXDCOMP decomp,
                        DATESTR  *start,
                        DATESTR  *end,
						CALCONV  cal,
						HOLI_STR *holi) ; 	/* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */

extern INTI GetPPFill(PP_STR *pp) ;

extern PLAN_STR * GetPPPlan(PP_STR *pp) ;





/*** routines in cflwaloc.c ********************************************/


/* Public functions */

extern CFLWARRAY Alloc_CFLWARRAY(INTI  ns, INTI  np) ;

extern void Free_CFLWARRAY(CFLWARRAY s, INTI ns) ;

extern void Free_EXRULE(EXRULE *ex) ;



/*** routines in cf_gener.c ********************************************/


/* Public functions */

extern CFLWARRAY Cflw_GenrCflw(REPAYMNT    *redemp,
                                PAYDAYDEF   *rday,
                                FIXRATE     *fix,
                                PAYDAYDEF   *cday,
                                HOLI_STR    *holi,
								FL64ARRAY    fixRate = NULL,
								FLAG_T		mktConvMethodEnblFlg = FALSE);    /* PMSTA-42879 - SRIDHARA - 18032021 */

/* Private functions */
extern FL64 Cflw_TermUnit2DayFrac(DATESTR *date, PAYDAYSEQ *pseq,
                                  CALCONV cal, HOLI_STR *hol,
                                  DATEARRAY days, INTI na) ;

/*** routines in cf_xtrac.c ********************************************/


/* Public functions */

extern CFLWARRAY Cflw_ExtractPeriod(TRADEINFO *start,
                                TRADEINFO   *end,
                                FIXRATE     *fix,
                                PAYDAYSEQ   *pseq,
                                ACCRUINT    *accru,
                                EXRULE      *xprule,
                                HOLI_STR    *holi,
                                BOOLE       fill,
                                CFLW_STR    *cflw,
                                PP_STR      *pp,
                                PLAN_STR    *aufab,
                                EXINF       *xinf,
	                            FLAG_T = FALSE) ;

/* Private functions */

extern BOOLE Cflw_xday(DATESTR *date, DATEARRAY dates, FL64ARRAY coup, 
                          INTI nd, EXRULE *exr, EXTRADE *xctrade, 
                          HOLI_STR *holi, DATESTR *eff) ;


/*** routines in cf_accru.c ********************************************/


/* Public functions */

extern AIRESULT Cflw_Accruint(TRADEINFO   *basis,
                          CFLW_STR    *cflw,
                          FIXRATE     *fix,
                          PAYDAYSEQ   *pseq,
                          ACCRUINT    *accru,
                          HOLI_STR    *holi,
                          PLAN_STR    *pp,
                          INDEXCONV   iConv,
	                      FLAG_T = FALSE) ;      /*  FPL-PMSTA00211-100826   */

#ifdef __cplusplus
}
#endif

#endif

/* SCID @(#)optrpos.h	1.4 (SimCorp) 99/06/04 16:27:03 */

#ifndef OPTRPOS_H
#define OPTRPOS_H

/************************************************************************
*                                                                       *
*    project    SCecon                                                  *
*                                                                       *
*    filename   riskpos.h                                               *
*                                                                       *
*    this file contains definitions and function prototyping for the    *
*    routines in the SCecon RiskPos module                              *
*                                                                       *
************************************************************************/

/***** includes ********************************************************/
#include <riskpos.h> 
#include <optscen.h> 
#include <cap.h>

/***** C++ Convenience *************************************************/
#ifdef __cplusplus
extern "C" {
#endif




extern RISKPOSLIST OptFutBond_Black2RiskPos(DATESTR   *analys,
                                     OPTFUT    *opt,
                                     FUTBOND   *futb,
                                     FL64      Notnal,
                                     DATESTR   *voldate,
                                     FL64      vol,
                                     DISCFAC   *df,
                                     INTI      noas,
                                     DFSPREADARRAY dfs,
                                     HOLI_STR  *holi,
                                     DELTASET  *ds,
                                     FXRISKSET *FXr) ;

extern RISKPOSLIST OptBond_Black2RiskPos(DATESTR   *analys,
                                  OPTFUT    *opt,
                                  FIXPAY    *fixp,
                                  FL64      spot,
                                  FL64      Notnal,
                                  DATESTR   *voldate,
                                  FL64      vol,
                                  DISCFAC   *df,
                                  DFSPREAD  *dfs,
                                  HOLI_STR  *holi,
                                  DELTASET  *ds,
                                  FXRISKSET *FXr) ;

extern RISKPOSLIST Caplets_Black2RiskPos(DATESTR    *analys,
                                             DATESTR    *voldate,
                                             CAPLETS    *cap,
                                             FL64       Notnal,
                                             DISCFAC    *df_index,
                                             DISCFAC    *df_disc,
                                             VOL_STR    *vol, 
                                             CMCONVADJ  *cmadj,
                                             HOLI_STR   *holi,
                                             DELTASET   *ds_index,
                                             DELTASET   *ds_disc,
                                             FXRISKSET  *FXr) ;

extern RISKPOSLIST Cap_Black2RiskPos(DATESTR    *analys,
                                         DATESTR    *voldate,
                                         CAP        *cap,
                                         FL64       Notnal,
                                         DISCFAC    *df_index,
                                         DISCFAC    *df_disc,
                                         VOL_STR    *vol, 
                                         CMCONVADJ  *cmadj,
                                         HOLI_STR   *holi,
                                         DELTASET   *ds_index,
                                         DELTASET   *ds_disc,
                                         FXRISKSET  *FXr) ;

extern RISKPOSLIST Swaption_Black2RiskPos(DATESTR   *analys,
                                              DATESTR   *voldate,
                                              FL64      vol, 
                                              SWAPTION  *ncsw,
                                              FL64      Notnal,
                                              DISCFAC   *df,
                                              DISCFAC   *df_cf,
                                              CMCONVADJ *cmadj,
                                              HOLI_STR  *holi,
                                              B76SWTM   *b76t,
                                              DELTASET  *ds,
                                              DELTASET  *ds_cf,
                                              FXRISKSET *FXr,
                                              BOOLE     *ok) ;

extern RISKPOSLIST Convtbl_CRR2RiskPos(DATESTR*     analys,
                                           FL64         spot,
                                           FL64         vol,
                                           INTI         nstep,
                                           CONVTBL*     cvt,
                                           FL64         Notnal,
                                           FL64         beta,
                                           RISKTOKEN*   EqtyIxToken,
                                           DISCFAC*     df,
                                           DFSPREAD*    dfs,  
                                           DISCFAC*     divdf,
                                           HOLI_STR*    holi,
                                           DELTASET*    ds,
                                           FXRISKSET*   FXr,
                                           BOOLE*       ok) ;

/* Private functions */


#ifdef __cplusplus
}
#endif

#endif

/* SCID @(#)tvmunit.h	1.25 (SimCorp) 99/02/19 14:17:30 */

#ifndef TVMUNIT_H_INCLUDED

#define TVMUNIT_H_INCLUDED



/************************************************************************
*                                                                       *
*    project    SCecon                                                  *
*                                                                       *
*    this file contains definitions and function prototyping for the    *
*    routines in the SCecon Time Value of Money UNIT module.            *
*                                                                       *
************************************************************************/

/***** includes ********************************************************/
#include <cldr.h>


/***** C++ Convenience *************************************************/
#ifdef __cplusplus
extern "C" {
#endif


/*** typedefs **********************************************************/

#ifndef FL64TOL
#define FL64TOL (FL64) 0.00000000001
#endif

/*,,SOT,,

RISKCONV : data type for risk calculation toggles
-------------------------------------------------

Virtually all the pricing routines of the SCecon Library has the
facility of calculating both price and risk ratios at the same time.

This facility can speed up the performance of your application, since
the underlying computations are more or less identical for pricing and
risk calculations.

Use the data type RISKCONV defined as

        typedef enum risk_tag
        {
            ZERO_ORDER,
            FIRST_ORDER,
            SECOND_ORDER
        }   RISKCONV ;

in tvmunit.h.

to specify whether a pricing routine should calculate price only, using
the ZERO_ORDER risk convention, price and first order derivative, using
the FIRST_ORDER risk convention or price, first- and second order
derivatives using the SECOND_ORDER risk convention.

,,EOT,,*/

typedef enum risk_tag
{
    RISKCONV_INIT = -1,
    ZERO_ORDER,
    FIRST_ORDER,
    SECOND_ORDER
}   RISKCONV ;


/*,,SOT,,

IRRCONV : data type for interest rate conventions
-------------------------------------------------

The data type IRRCONV is used for specification of the interest rate
convention used for pricing purposes.

This data type is defined as

        typedef enum irr_tag
        {
           CONTINUOUS,
           COMPOUND,
           SIMPLE_MM,
           COMPOUNDSIMPLE,
           BRAESSFANGMEYER,
           MOOSMULLER,
           MAIR,
           DISCOUNT,
           US_TREASURY,
           JGBYTM,
           SIMPLE_REPO,
           COMPOUNDSIMPLE_ODD
        }  IRRCONV ;

The CONTINUOUS interest rate convention calculates net present value as

         -rt
        e

where   r       continuously compounded yield,
        t       term to payment in fractional years,

using continuously compounded yields.

This interest rate convention is heavily used in academic litterature due
to its nice mathematical characteristics.

According the the COMPOUND interest rate convention, net present value
is calculated as

                    -t * qb
        (1 + r / qb)

where   r       compounded yield
        qb      quoting base
        t       term to payment in fractional years

The well known AIBD/ISMA convention is the special case, where qb is 1. Use
qb 2 for semiannually compounded yields etc.

The US_TREASURY convention discount payments exponentially using semiannual
compounding in 'normal' periods. Any fractional periods are discounted
linearly. In the last period linear discounting is used.

Following the SIMPLE_MM interest rate convention, net present value is
calculated as

        1 / (1 + rt)

where   r       simple money market yield
        t       term to payment in fractional years
This convention is default for money market instruments.

According to the COMPOUNDSIMPLE interest rate convention, a cashflow with
more than 1 future payment is discounted as COMPOUND, and when only the final
payment is outstanding SIMPLE_MM is used. If only one payment remains and this
falls more than 12 months into the future, COMPOUND will be used (relevant for
valuing longer zero coupon bonds).

According to the BRAESSFANGMEYER convention, present value is computed
by calculating the horizon value and discounting this value back to
evaluation date using compounded yields for whole years and simple
money market yields for fractional years.

The MOOSMULLER convention is analog to the BRAESSFANGMEYER convention
except that periods - rather than years - determine whether compounded
yields or simple money market yields are used for discounting.

According to the MAIR convention, the horizon value is determined using
a(n array of) reinvestment rate(s).

According to the DISCOUNT convention, price is computed as

        1.0 - r * t

where   r       discount yield
        t       time to payment in fractional years.
This convention is used for T-Bills, CD's etc.

JGBYTM is a special Japanese convention for finding yields. This convention
cannot be used in the tvmunit functions, but ONLY in combination with
yield calculations when using YTMCONV. The reason being that the setup is
so special that it does NOT fit into the standard PV framework. The
advantage, however, is that closed-form yields can be found, thereby avoiding
iterations. Currently JGBYTM is only allowed when using the functions:

        Bond_YTM2Yield()
        Bond_YTM2Price()
        Cflw_YTM2Yield()
        Cflw_YTM2Price()
        Bond_YTM2PV01()
        Bond_YTM2YV01()

Remember that JGBYTM yield are calculated using ACTNL365.

SIMPLE_REPO is equivalent to SIMPLE_MM except that any payment is first 
discounted to the maturity date, and thereafter back till the PV date. This
gives a slight difference in PV to the SIMPLE_MM method. This method is the
standard in the European Repo markets for calculating implied repo or the
settlement price.

According to the COMPOUNDSIMPLE_ODD interest rate convention, a cashflow that
contains payments more than 12 months into the future is discounted as COMPOUND.
Cashflows of 12 months or less are discounted as SIMPLE_MM. This convention is
used in Sweden. Refer to YTMCONV for a description of the calendar convention
used in the two situations.

Note that discounting is always combined with a calendar convention,
described elsewhere.

,,EOT,,*/

typedef enum irr_tag
{
   IRRCONV_INIT = -1,
   CONTINUOUS,
   COMPOUND,
   SIMPLE_MM,            /* Name choosen to avoid name clash with Dyadic
                            define (apl.h) when compiling with Metaware for
                            DOS */
   COMPOUNDSIMPLE,
   BRAESSFANGMEYER,
   MOOSMULLER,
   MAIR,
   DISCOUNT,
   US_TREASURY,
   JGBYTM,
   SIMPLE_REPO,
   COMPOUNDSIMPLE_ODD,
   YEAR_FRACTION
}  IRRCONV ;


/*,,SOT,,

PMTFREQ : data type for payment frequency
-----------------------------------------

The data type for holding information on the payment frequency of cash
flows or interest rate compounding, PMTFREQ, is defined as

        typedef enum pmtfreq_tag
        {
            TRIANNUALLY,
            BIANNUALLY,
            ANNUALLY,
            SEMIANNUALLY,
            FOURTHMONTHLY,
            QUARTERLY,
            BIMONTHLY,
            MONTHLY,
            NO_FREQUENCY
        }   PMTFREQ ;

According the the TRIANNUALLY and BIANNUALLY conventions, payments are
due every third and second year respectively.

A bond following ANNUALLY following pays annually, while a bond being
SEMIANNUALLY pays twice per year.

Bond following QUARTERLY pays four times per year, while bonds paying
once per month follows the MONTHLY convention.

The convention NO_FREQUENCY specifies that no regular patterns defines
the cashflow.

,,EOT,,*/

typedef enum pmtfreq_tag
{
    PMTFREQ_INIT = -1,
    TRIANNUALLY,
    BIANNUALLY,
    ANNUALLY,
    SEMIANNUALLY,
    FOURTHMONTHLY,
    QUARTERLY,
    BIMONTHLY,
    MONTHLY,
    NO_FREQUENCY
}   PMTFREQ ;


/*,,SOT,,

IRRATE : data type for interest rate conventions
------------------------------------------------

The data type IRRATE is used to hold a interest rate and specification of 
how it is quoted.

This data type is defined as

        typedef struct irrate_tag
        {
            FL64    rate ;
            IRRCONV irr ;
            PMTFREQ freq ;
        }   IRRATE ;

The data should be interpreted as:

        rate is the interest rate.

        irr is specification of the interest rate convention.

        freq is specification of the frequency.

,,EOT,,*/

typedef struct irrate_tag
{
    FL64    rate ;
    IRRCONV irr ;
    PMTFREQ freq ;
}   IRRATE ;


/*** macros ************************************************************/


/************************************************************************
*                                                                       *
*               tvmunit_continuous()                                    *
*                                                                       *
*   library     tvm                                                     *
*                                                                       *
*   interface   #include <tvmunit.h>                                    *
*               FL64 tvmunit_continuous(FL64 r, FL64 t) ;               *
*                                                                       *
*   general     tvmunit_continuous() is a macro for calculating the     *
*               present value of a unit payment using continously       *
*               compounded yield                                        *
*                                                                       *
*   input       FL64    r       Continuously compounded yield in        *
*                               percent.                                *
*               FL64    t       Time to payment in fractional years.    *
*                                                                       *
*   output                                                              *
*                                                                       *
*   returns     The present value as FL64                               *
*                                                                       *
*   diagnostics                                                         *
*                                                                       *
*   see also    tvmunit_continuous2price()                              *
*               tvmunit_price2continuous()                              *
*                                                                       *
************************************************************************/

#define tvmunit_continuous(r, t) \
exp( -((r)/100.0) * (t) )


/************************************************************************
*                                                                       *
*               tvmunit_compound()                                      *
*                                                                       *
*   library     tvm                                                     *
*                                                                       *
*   interface   #include <tvmunit.h>                                    *
*               FL64 tvmunit_compound(FL64 r, FL64 t, INTI qb) ;        *
*                                                                       *
*   general     tvmunit_compound() is a macro for calculating the       *
*               present value of a unit payment as function of          *
*               compounded yield                                        *
*                                                                       *
*   input       FL64    r       Annually compounded yield in percent.   *
*               FL64    t       Time to payment as fraction of years.   *
*               INTI    qb      Number of annual compoundings, that is  *
*                               the quoting basis of the yield.         *
*                                                                       *
*   output                                                              *
*                                                                       *
*   returns     the present value as FL64                               *
*                                                                       *
*   diagnostics                                                         *
*                                                                       *
*   se also     tvmunit_compound2price()                                *
*               tvmunit_nvp2compound()                                  *
*                                                                       *
************************************************************************/

#define tvmunit_compound(r, t, qb) \
pow(1.0 + (r)/(100.0*((FL64) qb)), -((t)*((FL64) qb)))

/* PMSTA-31276 - RAK - 180622 */
#define tvmunit_yearfraction(r, t) \
pow((1.0 + (r) / (100.0)), -((t)))

/************************************************************************
*                                                                       *
*               tvmunit_simple()                                        *
*                                                                       *
*   library     tvm                                                     *
*                                                                       *
*   interface   #include <tvmunit.h>                                    *
*               FL64 tvmunit_simple(FL64 r, FL64 t) ;                   *
*                                                                       *
*   general     tvmunit_simple() is a macro for calculating the present *
*               value of a unit payment using simple money market yield *
*                                                                       *
*   input       FL64    r       Simple money market yield in percent.   *
*               FL64    t       Time to payment as fraction of years.   *
*                                                                       *
*   output                                                              *
*                                                                       *
*   returns     The present value as FL64                               *
*                                                                       *
*   diagnostics                                                         *
*                                                                       *
*   see also    tvmunit_price2simple(),                                 *
*               tvmunit_simple2price()                                  *
*                                                                       *
************************************************************************/

/* PMSTA-46258 - JBC - 231127 */
inline FL64 tvmunit_simple(FL64 r, FL64 t)
{
    return (SCecon_fabs(r*t+100) < FL64TOL) ? 0.0 :  (1.0/(1.0 + ((r)/100.0) * (t)));
}

/*,,SOH,,
*************************************************************************
*                                                                       *
*               TVMunit_Mair()                                          *
*                                                                       *
*   library     tvm                                                     *
*                                                                       *
*   interface   #include <tvmunit.h>                                    *
*               FL64 TVMunit_Mair(FL64 r, FL64 t, FL64 g, FL64 m) ;     *
*                                                                       *
*   general     TVMunit_Mair() is a macro for calculating the present   *
*               value of a unit payment according to the Mair interest  *
*               rate convention.                                        *
*                                                                       *
*   input       FL64    r       The Mair yield in percent.              *
*                                                                       *
*               FL64    t       Time to the payment in fractional       *
*                               years.                                  *
*                                                                       *
*               FL64    g       Assumed reinvestment rate from the      *
*                               day of the payment to the maturity      *
*                               of the bond.                            *
*                                                                       *
*               FL64   m        Time to maturity in fractional years    *
*                               of the bond, that the payment comes     *
*                               from.                                   *
*                                                                       *
*   output                                                              *
*                                                                       *
*   returns     the present value as FL64.                              *
*                                                                       *
*   diagnostics                                                         *
*                                                                       *
*   see also    TVMunit_NPV()                                           *
*                                                                       *
*************************************************************************
,,EOH,,*/

#define TVMunit_Mair(r, t, g, m) \
pow(1.0 + ((g)/100.0), floor((m) - (t)))*  \
(1.0 + ((g)/100.0)*((m) - (t) - floor((m) - (t))))/pow(1.0 + ((r)/100.0), (m))


/************************************************************************
*                                                                       *
*               tvmunit_discount()                                      *
*                                                                       *
*   library     tvm                                                     *
*                                                                       *
*   interface   #include <tvmunit.h>                                    *
*               FL64 tvmunit_discount(FL64 r, FL64 t) ;                 *
*                                                                       *
*   general     tvmunit_discount() is a macro for calculating price     *
*               of a unit payment using discount yield.                 *
*                                                                       *
*   input       FL64    r       Discount yield in percent               *
*               FL64    t       Time to maturity in fractional years    *
*                                                                       *
*   output                                                              *
*                                                                       *
*   returns     The present value as FL64                               *
*                                                                       *
*   diagnostics                                                         *
*                                                                       *
*   see also                                                            *
*                                                                       *
************************************************************************/

#define tvmunit_discount(r, t) \
(1.0 - ((r)/100.0)*(t))


/************************************************************************
*                                                                       *
*               tvmunit_compound2rate()                                 *
*                                                                       *
*   library     tvm                                                     *
*                                                                       *
*   interface   #include <tvmunit.h>                                    *
*               FL64 tvmunit_compound2rate(FL64 npv, FL64 t, INTI qb) ; *
*                                                                       *
*   general     This is a macro for calculating the annually compounded *
*               rate that implies the present value (npv) of a unit     *
*               payment in t years.                                     *
*                                                                       *
*   input       FL64    npv     The present value of a unit payment in  *
*                               t years                                 *
*               FL64    t       Time to payment in fraction of basis    *
*                               periods (must be nonzero)               *
*               INTI    qb      Number of basis periods per year        *
*                                                                       *
*   output                                                              *
*                                                                       *
*   returns     The rate in percent.                                    *
*                                                                       *
*   diagnostics                                                         *
*                                                                       *
*   see also    tvmunit_compound()                                      *
*               tvmunit_compound2term()                                 *
*                                                                       *
************************************************************************/

#define tvmunit_compound2rate(npv, t, qb) \
100.0*((FL64) (qb))*(pow(npv, -1.0/((t)*((FL64) (qb)))) - 1.0)


/************************************************************************
*                                                                       *
*               tvmunit_simple2rate()                                   *
*                                                                       *
*   library     tvm                                                     *
*                                                                       *
*   interface   #include <tvmunit.h>                                    *
*               FL64 tvmunit_simple2rate(FL64 npv, FL64 t) ;            *
*                                                                       *
*   general     The macro calculates the simple rate that implies       *
*               the present value (npv) of a unit payment in t years.   *
*                                                                       *
*   input       FL64    npv     The present value of a unit payment in  *
*                               t years, must be nonzero.               *
*               FL64    t       Time to payment in fraction of basis    *
*                               periods (must be nonzero)               *
*                                                                       *
*   output                                                              *
*                                                                       *
*   returns     The rate in percent.                                    *
*                                                                       *
*   diagnostics                                                         *
*                                                                       *
*   see also    tvmunit_simple()                                        *
*               tvmunit_simple2term()                                   *
*                                                                       *
************************************************************************/

#define tvmunit_simple2rate(npv, t) \
100.0*(1.0/(npv) - 1.0)/(t)


/************************************************************************
*                                                                       *
*               tvmunit_continuous2rate()                               *
*                                                                       *
*   library     tvm                                                     *
*                                                                       *
*   interface   #include <tvmunit.h>                                    *
*               FL64 tvmunit_continuous2rate(FL64 npv, FL64 t) ;        *
*                                                                       *
*   general     The macro calculates the continuously compounded        *
*               rate that implies the present value (npv) of a unit     *
*               payment in t years.                                     *
*                                                                       *
*   input       FL64    npv     The present value of a unit payment at  *
*                               time t (must be positive).              *
*               FL64    t       Time to payment in fraction of basis    *
*                               periods (must be nonzero).              *
*                                                                       *
*   output                                                              *
*                                                                       *
*   returns     The rate in percent.                                    *
*                                                                       *
*   diagnostics                                                         *
*                                                                       *
*   see also    tvmunit_continuous()                                    *
*               tvmunit_continuous2term()                               *
*                                                                       *
************************************************************************/

#define tvmunit_continuous2rate(npv, t) \
100.0*(-log(npv))/(t)


/************************************************************************
*                                                                       *
*               tvmunit_discount2rate()                                 *
*                                                                       *
*   library     tvm                                                     *
*                                                                       *
*   interface   #include <tvmunit.h>                                    *
*               FL64 tvmunit_discount2rate(FL64 npv, FL64 t) ;          *
*                                                                       *
*   general     The macro calculates the discount rate that implies     *
*               the present value (npv) of a unit payment in t years.   *
*                                                                       *
*   input       FL64    npv     The present value of a unit payment at  *
*                               time t (must be positive).              *
*               FL64    t       Time to payment in fraction of basis    *
*                               periods (must be nonzero)               *
*                                                                       *
*   output                                                              *
*                                                                       *
*   returns     The rate in percent.                                    *
*                                                                       *
*   diagnostics                                                         *
*                                                                       *
*   see also                                                            *
*                                                                       *
************************************************************************/

#define tvmunit_discount2rate(npv, t) \
100.0*(1.0 - (npv))/(t)


/************************************************************************
*                                                                       *
*               tvmunit_continuous2term()                               *
*                                                                       *
*   library     tvm                                                     *
*                                                                       *
*   interface   #include <tvmunit.h>                                    *
*               FL64 tvmunit_continuous2term(FL64 npv, FL64 rate);      *
*                                                                       *
*   general     The macro calculates the term in fractional years       *
*               that implies the present value (npv) of a unit          *
*               payment discounted with rate.                           *
*                                                                       *
*   input       FL64    npv     The present value of a unit payment,    *
*                               must be positive.                       *
*               FL64    rate    The continuously compounded rate        *
*                               in percent, must be nonzero.            *
*                                                                       *
*   output                                                              *
*                                                                       *
*   returns     The term in fractional years.                           *
*                                                                       *
*   diagnostics                                                         *
*                                                                       *
*   see also    tvmunit_continuous()                                    *
*               tvmunit_continuous2rate()                               *
*                                                                       *
************************************************************************/

#define tvmunit_continuous2term(npv, rate) \
100.0*(-log(npv))/(rate)


/************************************************************************
*                                                                       *
*               tvmunit_simple2term()                                   *
*                                                                       *
*   library     tvm                                                     *
*                                                                       *
*   interface   #include <tvmunit.h>                                    *
*               FL64 tvmunit_simple2term(FL64 npv, FL64 rate);          *
*                                                                       *
*   general     The macro calculates the term in fractional years       *
*               that implies the present value (npv) of a unit payment  *
*               discounted with rate.                                   *
*                                                                       *
*   input       FL64    npv     The present value of a unit payment,    *
*                               must be nonzero.                        *
*               FL64    rate    The simple discounting rate in percent, *
*                               must be nonzero.                        *
*                                                                       *
*   output                                                              *
*                                                                       *
*   returns     The term in fractional years.                           *
*                                                                       *
*   diagnostics                                                         *
*                                                                       *
*   see also    tvmunit_simple()                                        *
*               tvmunit_simple2rate()                                   *
*                                                                       *
************************************************************************/

#define tvmunit_simple2term(npv, r) \
100.0*(1.0/(npv) - 1.0)/(r)


/************************************************************************
*                                                                       *
*               tvmunit_compound2term()                                 *
*                                                                       *
*   library     tvm                                                     *
*                                                                       *
*   interface   #include <tvmunit.h>                                    *
*               FL64 tvmunit_compound2term(FL64 npv, FL64 r, INTI qb) ; *
*                                                                       *
*   general     The macro calculates the term in fractional years       *
*               that implies the present value (npv) of a unit payment  *
*               discounted with the rate r quoted as qb.                *
*                                                                       *
*   input       FL64    npv     The present value of a unit payment,    *
*                               must be positive.                       *
*               FL64    r       The annually compounded rate in percent, *
*                               must be nonzero.                        *
*               INTI    qb      Number of basis periods per year.       *
*                                                                       *
*   output                                                              *
*                                                                       *
*   returns     The term in fractional basis periods.                   *
*                                                                       *
*   diagnostics                                                         *
*                                                                       *
*   see also    tvmunit_compound()                                      *
*               tvmunit_compound2rate()                                 *
*                                                                       *
************************************************************************/

#define tvmunit_compound2term(npv, r, qb) \
-log(npv)/(((FL64) (qb))*log(1.0 + (r)/(100.0*((FL64) (qb)))))


/************************************************************************
*                                                                       *
*               tvmunit_discount2term()                                 *
*                                                                       *
*   library     tvm                                                     *
*                                                                       *
*   interface   #include <tvmunit.h>                                    *
*                                                                       *
*               FL64 tvmunit_discount2term(FL64 npv, FL64 r) ;          *
*                                                                       *
*   general     The macro calculates the term in fractional years       *
*               that implies the present value (npv) of a unit payment  *
*               discounted with the discount rate.                      *
*                                                                       *
*   input       FL64    npv     The present value of a unit payment.    *
*               FL64    r       The discount rate in percent, must      *
*                               be nonzero.                             *
*                                                                       *
*   output                                                              *
*                                                                       *
*   returns     The term in fractional basis periods.                   *
*                                                                       *
*   diagnostics                                                         *
*                                                                       *
*   see also                                                            *
*                                                                       *
************************************************************************/

#define tvmunit_discount2term(npv, r) \
100.0*(1.0  - (npv))/(r)


/*** routines in tvmunit.c  ********************************************/


/* Public functions */
extern FL64 TVMunit_Yield2Yield(DATESTR* start,
                            DATESTR* end,
                            FL64     rate1,
                            IRRCONV  irr1,
                            PMTFREQ  freq1,
                            CALCONV  cal1,
                            IRRCONV  irr2,
                            PMTFREQ  freq2,
                            CALCONV  cal2) ;

extern FL64 TVMunit_NPV(FL64    t,
                        FL64    rate,
                        IRRCONV irr,
                        INTI    qb) ;

extern FL64 TVMunit_Yield(FL64    npv,
                          FL64    t,
                          IRRCONV irr,
                          INTI    qb) ;

extern FL64 TVMunit_Term(FL64    npv,
                         FL64    r,
                         IRRCONV irr,
                         INTI    qb) ;

/* Private functions */
extern FL64 tvmunit_moosmuller(FL64 r, FL64 t, FL64 dt, INTI qb) ;
extern FL64 TVMunit_USTreasury(FL64 r, FL64 t, INTI qb) ;
extern FL64 TVMunit_Braessfangmeyer(FL64 r, FL64 t, FL64 m) ;
extern FL64 TVMunit_Simplerepo(FL64 r, FL64 t, FL64 m) ;
extern FL64 TVMunit_JGBYTM(FL64 r, FL64 t, FL64 C) ;
extern FL64 TVMunit_JGBYTM2rate(FL64 npv, FL64 t, FL64 C) ;
extern FL64 TVMunit_Calc_Deriv(FL64 pDD, FL64 pD, FL64 p, FL64 pU,
                                  FL64 pUU, FL64 delta, INTI order) ;
extern INTI TVMunit_set_qbas(PMTFREQ freq) ;
extern INTI TVMunit_Months_Between_Payments(PMTFREQ freq) ;

#ifdef __cplusplus
}
#endif

#endif

/* SCID @(#)volboot.h	1.3 (SimCorp) 99/02/19 14:10:23 */

#ifndef VOLBOOT_H
#define VOLBOOT_H

/************************************************************************
*                                                                       *
*    project     SCecon                                                 *
*                                                                       *
*    filename    volboot.h                                              *
*                                                                       *
*    general     this file contains declarations, initializations,      *
*                type definitions and function prototyping for the      *
*                bootstrappng module of the standard library SCecon     *
*                                                                       *
************************************************************************/


/**** includes *********************************************************/
#include <cap.h>
#include <bootsec.h>

#ifdef __cplusplus
extern "C" {
#endif

/**** defines  *********************************************************/


/*** function prototyping (volboot.c) *************************************/


/* Public functions */

extern FL64ARRAY Boot_PCPAR2MarginAdj(DATESTR    *start,
                                      BSECARRAY  bsec,
                                      DATEARRAY  settle,
                                      FL64ARRAY  prices,
                                      INTI       nsec,
                                      DISCFAC    *df,    
                                      VOL_STR    *vol,   
                                      HOLI_STR   *holi) ;

extern BOOLE Boot_Caplets2B76Vol(CAPLETSARRAY  irg,
                          INTI      ncap,
                          FL64ARRAY prices,
                          DISCFAC *offer,
                          DISCFAC *disc,
                          CALCONV cal,
                          VOLCONV vc,
                          VOL_STR *vol) ;

extern BOOLE Boot_Cap2B76Vol(CAPARRAY cap,
                    INTI      ncap,
                    FL64ARRAY prices,
                    DISCFAC*   df_index,
                    DISCFAC*   df_disc,
                    HOLI_STR*  holi,
                    CALCONV   cal,
                    VOLCONV   vc,
                    VOL_STR*   vol);


/* Private functions */

#ifdef __cplusplus
}
#endif

#endif

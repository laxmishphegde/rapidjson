/* SCCS @(#)codestnd.h	1.4 (SimCorp) 99/01/25 09:30:47 */

/*,,SCDSTND,,
SCEcon coding & release standards 

 - a release must compile without warnings at the highest warning 
   level of development compiler (currently Microsoft Visual C++)

 - comprehensive regression testing 

 - compilation and testing performed on a number of compilers and 
   hw/sw platforms

 - ANSI C compliant
    - C++ style function prototypes
    - External names with first 32 characters significant.

 - high priority given to code reuse at the level of functions and 
   data types 

 - high frequency of comments (all comments in English)

 - stratified 'include' hierarchy (no circular 'include's) 

 - functions and data type names follow naming conventions

 - no system calls (file/data base access, system date/time, etc)

 - no static variables (using pointers instead)

 - lay-out conventions for readability:
    - all tabs are converted into spaces (a tab is equal to two 
      spaces - four in some of the older code)
    - all left and right braces ('{' and '}', respectively) are on 
      separate lines
    - code between braces is tabbed right once
    - code after conditionals ('if', 'for', 'while', 'else' etc) 
      are tabbed right once
    - the semi-colon ending a statement is preceded by a space
    - the semi-colons in 'for' clauses are not preceded by spaces
    - arithmetic operators are preceded and followed by spaces
    - relational operators are preceded and followed by spaces
    - Boolean operators are preceded and followed by spaces
    - no spaces around the parentheses of function argumentlists
    - comma separating function arguments is followed by space

 - coding style for readability 
    - all 'structs' are 'tagged'
    - no use of 'Goto'


,,ECDSTND,, */


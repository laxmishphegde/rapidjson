#ifndef TSCALIO_H
#define TSCALIO_H

#include <sccsid.h>
SCCSID(tscalio_h,
  "@(#)tscalio.h	1.7 (SimCorp) 99/06/18 16:01:23")

/************************************************************************
*                                                                       *
*   project     SCecon                                                  *
*                                                                       *
*   file name   str2conv.h                                              *
*                                                                       *
*   general     This file contains the header file for the example code *
*               in str2conv.c                                           *
*                                                                       *
************************************************************************/

/*** includes **********************************************************/
#include <stdio.h>
#include <string.h>

#include <bootstrp.h>
#include <fitzero.h>

#ifdef __cplusplus
extern "C" {
#endif


extern FILLTYPE    Str2FILLTYPE(TEXT txt) ;
extern ZEROMODEL   Str2ZEROMODEL(TEXT txt) ;
extern SMOOTHCRIT  Str2SMOOTHCRIT(TEXT txt) ;

extern FILLTYPE Read_FILLTYPE(FILE *in, FILE *out, TEXT dscr);
extern ZEROMODEL Read_ZEROMODEL(FILE *in, FILE *out, TEXT dscr);  

extern ZEROPARMS  Read_ZEROPARMS(FILE* in, FILE* out);

extern SMOOTHPARMS Read_SMOOTHPARMS(FILE*in , FILE* out, TEXT dscr) ;
extern SMOOTHCRIT Read_SMOOTHCRIT(FILE*in , FILE* out, TEXT dscr) ;
extern CRITERIONFUNC Read_CRITERIONFUNC(FILE*  in, FILE*  out) ;


#ifdef __cplusplus
}
#endif


#endif



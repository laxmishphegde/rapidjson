#ifndef OPTVAL_H
#define OPTVAL_H

#include <sccsid.h>
SCCSID(optvalid_h,
  "@(#)optvalid.h	1.8 (SimCorp) 99/02/19 14:18:09")

/************************************************************************
*                                                                       *
*    project     SCecon                                                 *
*                                                                       *
*    filename    validate.h                                             *
*                                                                       *
*    general     this file contains declarations, initializations,      *
*                type definitions and function prototyping for the      *
*                validation module of the standard library SCecon       *
*                                                                       *
************************************************************************/

/**** includes *********************************************************/
#include <option.h>
#include <validate.h>

#ifdef __cplusplus
extern "C" {
#endif

/*** typedefines *******************************************************/


/*** function prototyping (optvalid.c) *********************************/

extern BOOLE Validate_PREMIUMTYPE(PREMIUMTYPE p) ;
extern BOOLE Validate_OPTTYPE(OPTTYPE o) ;
extern BOOLE Validate_PAYOFF(PAYOFF p)    ;
extern BOOLE Validate_OPTADD(OPTADD o) ;
extern BOOLE Validate_KNOCKTYPE(KNOCKTYPE k) ;
extern BOOLE Validate_CTTYPE(CTTYPE r);

extern VALIDATE Validate_OPTCT(OPTCT *x);
extern VALIDATE Validate_OPTFUT(OPTFUT *o) ;
extern VALIDATE Validate_OPTFUTARRAY(OPTFUTARRAY cm, INTI n);


extern VALIDATE Validate_ASIANINF(ASIANINF *a, DATESTR *fix, 
                                  BOOLE val_dates) ;
extern VALIDATE Validate_BARRIERINF(BARRIERINF *b) ;
extern VALIDATE Validate_BINARYINF(BINARYINF *b) ;
extern VALIDATE Validate_CHOOSERINF(CHOOSERINF *c, DATESTR *fix, 
                                    BOOLE val_dates) ;
extern VALIDATE Validate_COMPOPTINF(COMPOPTINF *c) ;
extern VALIDATE Validate_CONTPREMINF(CONTPREMINF *c) ;
extern VALIDATE Validate_DOUBLKOINF(DOUBLKOINF *d);
extern VALIDATE Validate_LADDERINF(LADDERINF *d);
extern VALIDATE Validate_FWDSTARTINF(FWDSTARTINF *f, DATESTR *fix, 
                                     BOOLE val_dates) ;
extern VALIDATE Validate_LOOKBACKINF(LOOKBACKINF *l) ;
extern VALIDATE Validate_PAYOFFINF(PAYOFFINF *p) ;
extern VALIDATE Validate_QUANTOINF(QUANTOINF *x);
extern VALIDATE Validate_RESETINF(RESETINF *r) ;
extern VALIDATE Validate_TOUCHDIGINF(TOUCHDIGINF *tdi) ;
extern VALIDATE Validate_TSWITCHINF(TSWITCHINF *d) ;
extern VALIDATE Validate_CORRIDORINF(CORRIDORINF *d) ;



#ifdef __cplusplus
}
#endif

#endif


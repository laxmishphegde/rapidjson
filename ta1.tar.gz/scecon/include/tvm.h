/* SCID @(#)tvm.h	1.20 (SimCorp) 99/02/19 14:17:22 */

#ifndef TVM_H_INCLUDED

#define TVM_H_INCLUDED

/************************************************************************
*                                                                       *
*    project    SCecon                                                  *
*                                                                       *
*    filename   tvm.h                                                   *
*                                                                       *
*    this file contains definitions and function prototyping for the    *
*    routines in the SCecon Time Value of Money module.                 *
*                                                                       *
************************************************************************/

/***** includes ********************************************************/
#include <math.h>
#include <scecon.h>
#include <pmt.h>
#include <scalloc.h>

#ifdef __cplusplus
extern "C" {
#endif

/*** macros ************************************************************/

/*
*************************************************************************
*                                                                       *
*               tvm_modified_duration()                                 *
*                                                                       *
*   library     tvm                                                     *
*                                                                       *
*   interface   #include <tvm.h>                                        *
*               FL64 tvm_modified_duration(FL64 dp, FL64 p) ;           *
*                                                                       *
*   general     tvm_modified_duration() is a macro for calculating      *
*               modified duration as function of dollar duration and    *
*               present value                                           *
*                                                                       *
*   input       FL64    dp      Dollar duration.                        *
*                                                                       *
*               FL64    p       Present value.                          *
*                                                                       *
*   output                                                              *
*                                                                       *
*   returns     the modified duration as FL64.                          *
*                                                                       *
*   diagnostics                                                         *
*                                                                       *
*   see also    TVM_Yield2Duration()                                    *
*                                                                       *
*************************************************************************
*/

#define tvm_modified_duration(dp, p) \
(dp)/((p)/100.0)


/*
*************************************************************************
*                                                                       *
*               tvm_duration()                                          *
*                                                                       *
*   library     tvm                                                     *
*                                                                       *
*   interface   #include <tvm.h>                                        *
*               FL64 tvm_duration(FL64 dp, FL64 p, FL64 y);             *
*                                                                       *
*   general     tvm_duration() is a macro for calculating the duration  *
*               as function of dollar duration, presentvalue and yield. *
*                                                                       *
*   input       FL64    dp      Dollar duration.                        *
*                                                                       *
*               FL64    p       Present value.                          *
*                                                                       *
*               FL64    y       Annually compounded yield to maturity   *
*                               in percent.                             *
*                                                                       *
*   output                                                              *
*                                                                       *
*   returns     the duration as FL64.                                   *
*                                                                       *
*   diagnostics                                                         *
*                                                                       *
*   see also    tvm_modified_duraton()                                  *
*               tvm_correction_factor()                                 *
*               TVM_Yield2Duration()                                    *
*               TVM_Zero2Duration()                                     *
*                                                                       *
*************************************************************************
*/

#define tvm_duration(dp, p, y) \
(dp)*(1.0 + ((y)/100.0) )/((p)/100.0)

/*
*************************************************************************
*                                                                       *
*               tvm_correction_factor()                                 *
*                                                                       *
*   library     tvm                                                     *
*                                                                       *
*   interface   #include <tvm.h>                                        *
*               FL64 tvm_correction_factor(FL64 dp) ;                   *
*                                                                       *
*   general     tvm_correction_factor() is a macro for calculating      *
*               correction factor as the reciprocal of dollar duration. *
*                                                                       *
*   input       FL64    dp      Dollar duration.                        *
*                                                                       *
*   output                                                              *
*                                                                       *
*   returns     the correction factor as FL64.                          *
*                                                                       *
*   diagnostics                                                         *
*                                                                       *
*   see also    tvm_modified_duration()                                 *
*               tvm_duration()                                          *
*                                                                       *
*************************************************************************
*/

#define tvm_correction_factor(dp) \
1.0/(dp)


/*
*************************************************************************
*                                                                       *
*               tvm_current_yield()                                     *
*                                                                       *
*   library     tvm                                                     *
*                                                                       *
*   interface   #include <tvm.h>                                        *
*               FL64 tvm_current_yield(FL64 coupon,                     *
*                                      FL64 dirty) ;                    *
*                                                                       *
*   general     The macro calculates the current yield based on the     *
*               current coupon and the dirty price.                     *
*                                                                       *
*               There seems to be some disagreement about what price    *
*               to use when computing the current yield. Sometime the   *
*               dirty and some times the clean price is recommended.    *
*               We recommend the use of dirty price as a financially    *
*               more sound measure when calculating current yield.      *
*                                                                       *
*   input       FL64    npv     The current annual coupon in percent.   *
*                                                                       *
*               FL64    dirty   The dirty price per 100 outstanding.    *
*                               Must be nonzero.                        *
*                                                                       *
*   output                                                              *
*                                                                       *
*   returns     the current yield.                                      *
*                                                                       *
*   diagnostics                                                         *
*                                                                       *
*   see also    TVM_Price2Yield()                                       *
*                                                                       *
*************************************************************************
*/

#define tvm_current_yield(coupon, dirty) \
100.0*(coupon)/(dirty)


/*** prototyping *******************************************************/

/* Newton-Raphson struct */

typedef enum
{
  UNIT_TVM,
  DISC_TVM,
  STAT_TVM,
  YIELD_TVM,
  ROOT_TVM,
  ZERO_TVM
} TVMTYPE ;

typedef struct
{
  TVMTYPE   type ;
  FL64      npv ;
  FL64      t ;
  FL64      std ;
  FL64ARRAY rerate ;
  INTI      n ;
  IRRCONV   irr ;
  INTI      qb ;
  BONDTYPE  bond ;
  PMT_STR   *pmt ;
  TS_STR    *ts ;
  INTPOLCONV iconv ;
  FL64      shock ;
} TVMINT ;

/*** routines in duration.c ********************************************/


/* Public functions */

extern FL64 TVM_Yield2Duration(FL64      ytm,
                               INTI      basis,
                               IRRCONV   irr,
                               FL64ARRAY rerate,
                               PMT_STR *   paym) ;

extern FL64 TVM_Zero2Duration(TS_STR *     ts,
                              FL64       spread,
                              INTPOLCONV iconv,
                              PMT_STR *    paym) ;

extern FL64 TVM_RemainingLife(FL64ARRAY terms,
                               INTI      n) ;

extern FL64 TVM_AvgRemainingLife(FL64ARRAY amort,
                                   FL64ARRAY terms,
                                   INTI      n) ;

extern FL64 TVM_Zero2Theta(TS_STR *     ts,
                           FL64       spread,
                           INTPOLCONV iconv,
                           PMT_STR *    paym,
                           FL64       debt,
                           FL64       dirty,
                           FL64       time) ;

extern FL64 TVM_Yield2Theta(FL64      ytm,
                            INTI      qb,
                            IRRCONV   irr,
                            FL64ARRAY g,
                            PMT_STR *   paym,
                            FL64      debt,
                            FL64      dirty,
                            FL64      time) ;

/* Private functions */

extern FL64 TVM_Compound2Duration(FL64     ytm,
                                  INTI     basis,
                                  PMT_STR *  paym) ;

extern FL64 TVM_USTreasury2Duration(FL64      ytm,
                                    INTI      qb,
                                    PMT_STR   *paym) ;

extern FL64 TVM_CompoundSimple2Duration(FL64     ytm,
                                        INTI     basis,
                                        PMT_STR *  paym) ;

extern FL64 TVM_CompoundSimpleOdd2Duration(FL64     ytm,
                                           INTI     basis,
                                           PMT_STR *  paym) ;

extern FL64 TVM_Continuous2Duration(FL64     ytm,
                                    PMT_STR *  paym) ;

extern FL64 TVM_Simple2Duration(FL64     ytm,
                                PMT_STR *  paym) ;

extern FL64 TVM_Discount2Duration(FL64     ytm,
                                  PMT_STR *  paym) ;

extern FL64 TVM_Braessfangmeyer2Duration(FL64     ytm,
                                         PMT_STR *  paym) ;

extern FL64 TVM_Simplerepo2Duration(FL64      ytm,
                                    PMT_STR * paym) ;

extern FL64 TVM_Moosmuller2Duration(FL64     ytm,
                                    INTI     basis,
                                    PMT_STR *  paym) ;

extern FL64 TVM_Mair2Duration(FL64      ytm,
                              FL64ARRAY rerate,
                              PMT_STR *   paym) ;



/*** routines in tvmprice.c ********************************************/


/* Public functions */

extern FL64 TVM_Risk_Per2Ann(FL64     rp,
                             FL64     dp,
                             FL64     ddp,
                             FL64     qb,
                             RISKCONV risk) ;

extern FL64 TVM_NPVBondtype(FL64     pmt,
                             FL64     ytm,
                             FL64     term,
                             BONDTYPE type,
                             RISKCONV risk,
                             FL64     *dp,
                             FL64     *ddp) ;

extern FL64 TVM_Yield2Price(FL64      ytm,
                            RISKCONV  risk,
                            INTI      basis,
                            FL64      debt,
                            IRRCONV   irr,
                            FL64ARRAY rerates,
                            PMT_STR *   paym,
                            FL64      *dp,
                            FL64      *ddp) ;

extern FL64 TVM_Zero2Price(TS_STR *     ts,
                           RISKCONV   risk,
                           FL64       debt,
                           FL64       spread,
                           INTPOLCONV iconv,
                           PMT_STR *    paym,
                           FL64       *dp,
                           FL64       *ddp) ;

/* private functions */
extern FL64 TVM_NPV_Annuity(FL64 annuity,
                            FL64 prate,
                            FL64 term) ;

extern FL64 TVM_NPV_Bullet(FL64 coupon,
                           FL64 prate,
                           FL64 term) ;

extern FL64 TVM_NPV_Serial(FL64 coupon,
                           FL64 prate,
                           FL64 term) ;

extern FL64 TVM_Compound2Price(FL64     ytm,
                               FL64     *dprice,
                               FL64     *ddprice,
                               RISKCONV risk,
                               INTI     basis,
                               FL64     debt,
                               PMT_STR *  paym) ;

extern FL64 TVM_USTreasury2Price(FL64      ytm,
                           FL64    * dp,
                           FL64    * ddp,
                           RISKCONV  risk,
                           INTI      basis,
                           FL64      debt,
                           PMT_STR *   paym) ;

extern FL64 TVM_CompoundSimple2Price(FL64     ytm,
                                     FL64     *dprice,
                                     FL64     *ddprice,
                                     RISKCONV risk,
                                     INTI     basis,
                                     FL64     debt,
                                     PMT_STR *  paym) ;

extern FL64 TVM_CompoundSimpleOdd2Price(FL64       ytm,
                                           FL64       *dprice,
                                           FL64       *ddprice,
                                           RISKCONV   risk,
                                           INTI       basis,
                                           FL64       debt,
                                           PMT_STR *  paym) ;

extern FL64 TVM_Continuous2Price(FL64     ytm,
                                 FL64     *dprice,
                                 FL64     *ddprice,
                                 RISKCONV risk,
                                 FL64     debt,
                                 PMT_STR *  paym) ;

extern FL64 TVM_Simple2Price(FL64     ytm,
                             FL64     *dprice,
                             FL64     *ddprice,
                             RISKCONV risk,
                             FL64     debt,
                             PMT_STR *  paym) ;

extern FL64 TVM_Braessfangmeyer2Price(FL64     ytm,
                                      FL64     *dprice,
                                      FL64     *ddprice,
                                      RISKCONV risk,
                                      FL64     debt,
                                      PMT_STR *  paym) ;

extern FL64 TVM_Simplerepo2Price(FL64      ytm,
                          FL64    * dp,
                          FL64    * ddp,
                          RISKCONV  risk,
                          FL64      debt,
                          PMT_STR * paym,
                          FL64      matur) ;

extern FL64 TVM_Moosmuller2Price(FL64     ytm,
                                 FL64     *dprice,
                                 FL64     *ddprice,
                                 RISKCONV risk,
                                 INTI     basis,
                                 FL64     debt,
                                 PMT_STR *  paym) ;

extern FL64 TVM_Mair2Price(FL64      ytm,
                           FL64      *dprice,
                           FL64      *ddprice,
                           RISKCONV  risk,
                           FL64ARRAY reinvestrate,
                           FL64      debt,
                           PMT_STR *   paym) ;

extern FL64 TVM_Discount2Price(FL64     ytm,
                               FL64     *dprice,
                               FL64     *ddprice,
                               RISKCONV risk,
                               FL64     debt,
                               PMT_STR *  paym) ;

extern FL64 TVM_Value_PMTARRAY(PMT_STR *  pmtstr,
                               TS_STR *   tsstr) ;


/*** routines in tvmyield.c ********************************************/


/* Public functions */

extern BOOLE TVM_Price2Yield(FL64      price,
                            INTI      basis,
                            IRRCONV   irr,
                            FL64ARRAY rerates,
                            FL64      debt,
                            PMT_STR *   paym,
                            FL64      acc,
                            FL64      *ytm) ;

extern BOOLE TVM_Zero2Spread(TS_STR *     ts,
                            FL64       debt,
                            INTPOLCONV iconv,
                            PMT_STR *    paym,
                            FL64       dirty,
                            FL64       guess,
                            FL64       *oas) ;

extern BOOLE TVM_YieldByFormula(FL64     pv,
                                 FL64     pmt,
                                 FL64     t,
                                 BONDTYPE type,
                                 FL64     acc,
                                 FL64     *ytm) ;

/* Private functions */

extern BOOLE TVM_Root(FL64      price,
                     INTI      qb,
                     IRRCONV   irr,
                     FL64ARRAY rerate,
                     FL64      debt,
                     PMT_STR *   pmt,
                     FL64      yacc,
                     FL64      min,
                     FL64      *ytm) ;

extern TVMINT TVM_SetTVMINT(TVMTYPE   type,
                                FL64      npv,
                                FL64      t,
                                FL64      std,
                                FL64ARRAY rerate,
                                INTI      n,
                                IRRCONV   irr,
                                INTI      qb,
                                BONDTYPE  bond,
                                PMT_STR   *pmt,
                                TS_STR    *ts,
                                INTPOLCONV iconv,
                                FL64      shock) ;

extern void TVM_GetTVMINT(TVMINT    *tvm_data,
                              TVMTYPE   *type,
                              FL64      *npv,
                              FL64      *t,
                              FL64      *std,
                              FL64ARRAY *rerate,
                              INTI      *n,
                              IRRCONV   *irr,
                              INTI      *qb,
                              BONDTYPE  *bond,
                              PMT_STR   **pmt,
                              TS_STR    **ts,
                              INTPOLCONV *iconv,
                              FL64      *shock) ;

extern BOOLE TVM_NewtonRaphson(FL64   x, 
                                  void   *y,
                                  BOOLE  grad,
                                  FL64   *fx, 
                                  FL64   *dfx,
								  void   *hol) ;  /* PMSTA-29444 - SRIDHARA - 050318 */

#ifdef __cplusplus
}
#endif

#endif

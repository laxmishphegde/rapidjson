#ifndef SCANSI_H
#define SCANSI_H

#include "sccsid.h"

/*
SCCSID(scansi_h,
  "@(#)scansi.h	1.1 (SimCorp) 97/06/25 15:57:17")
*/

/*----------------------------------------------------------------------
 *
 * This file declares macros for use in function prototypes and
 * headers. The ansi type definition is used if the compiler has set
 * __STDC__ or __cplusplus OR the user has set the SCANSI flag.
 *
 * The macros Pn are used in function prototypes (n dictates the
 * number of args, 2 in this example)
 *
 *    int function P2( char *name, int type );
 *
 * which expands to
 *
 *    int function( );                                     [non ANSI]
 *    int function( char *name, int type );                [ANSI]
 *
 *
 * The macros Fn are used in the function definition itself, note that
 * we must seperate the type and name of each argument
 *
 *    int function F2( char*, name, int, type )
 *
 * which expands to
 *
 *    int function( name, type ) char* name; int type;     [non ANSI]
 *    int function( char* name, int type )                 [ANSI]
 *
 *
 * The macros FAn are used when one or more of the arguments are array
 * type, in which case we need 3 arguments for each entry
 *
 * NOTE: Preferably avoid these by use of ** or typedefs!!
 *
 *    int function FA2( char, name, [], int, type, EMPTY)
 *
 * which expands to
 *
 *    int function( name, type ) char name[]; int type;    [non ANSI]
 *    int function( char name[], int type )                [ANSI]
 *
 *
 * NOTES:
 * ******
 * - There is no opening bracket between the function name and the
 *   macros.
 *
 * - The stars for pointer must be put on the type (not the name)
 *
 * - The limit for macro arguments is 31 on SunOS cc. That's the
 *   reason why it stops at F15.
 *
 * - Preferably avoid the FA macros by use of ** or typedefs!!
 *
 * - Also define SCCONST according to compilation level. ANSI
 *   understands const unless SCNOCONST macro is defined.
 */

#if defined(SCANSI) && !defined(SCNOCONST)
#  define SCCONST const
#else
#  define SCCONST
#endif


#if defined(SCANSI)
#define P0(a)                    (a)
#define P1(a)                    (a)
#define P2(a,b)                  (a,b)
#define P3(a,b,c)                (a,b,c)
#define P4(a,b,c,d)              (a,b,c,d)
#define P5(a,b,c,d,e)            (a,b,c,d,e)
#define P6(a,b,c,d,e,f)          (a,b,c,d,e,f)
#define P7(a,b,c,d,e,f,g)        (a,b,c,d,e,f,g)
#define P8(a,b,c,d,e,f,g,h)      (a,b,c,d,e,f,g,h)
#define P9(a,b,c,d,e,f,g,h,i)    (a,b,c,d,e,f,g,h,i)
#define P10(a,b,c,d,e,f,g,h,i,j) (a,b,c,d,e,f,g,h,i,j)

#define P11(a,b,c,d,e,f,g,h,i,j,k) \
           (a,b,c,d,e,f,g,h,i,j,k)
#define P12(a,b,c,d,e,f,g,h,i,j,k,l) \
           (a,b,c,d,e,f,g,h,i,j,k,l)
#define P13(a,b,c,d,e,f,g,h,i,j,k,l,m) \
           (a,b,c,d,e,f,g,h,i,j,k,l,m)
#define P14(a,b,c,d,e,f,g,h,i,j,k,l,m,n) \
           (a,b,c,d,e,f,g,h,i,j,k,l,m,n)
#define P15(a,b,c,d,e,f,g,h,i,j,k,l,m,n,o) \
           (a,b,c,d,e,f,g,h,i,j,k,l,m,n,o)

/* NOTE: It is not healthy to break the definition header by a newline.
 *       Some compilers (like SunOS cc) do not like it. Therefore, we
 *       will violate the 72 line length rule here.
 */
#define F0(a)                           (a)
#define F1(a,A)                         (a A)
#define F2(a,A,b,B)                     (a A,b B)
#define F3(a,A,b,B,c,C)                 (a A,b B,c C)
#define F4(a,A,b,B,c,C,d,D)             (a A,b B,c C,d D)
#define F5(a,A,b,B,c,C,d,D,e,E)         (a A,b B,c C,d D,e E)
#define F6(a,A,b,B,c,C,d,D,e,E,f,F)     (a A,b B,c C,d D,e E,f F)
#define F7(a,A,b,B,c,C,d,D,e,E,f,F,g,G) (a A,b B,c C,d D,e E,f F,g G)
#define F8(a,A,b,B,c,C,d,D,e,E,f,F,g,G,h,H) \
          (a A,b B,c C,d D,e E,f F,g G,h H)
#define F9(a,A,b,B,c,C,d,D,e,E,f,F,g,G,h,H,i,I) \
          (a A,b B,c C,d D,e E,f F,g G,h H,i I)
#define F10(a,A,b,B,c,C,d,D,e,E,f,F,g,G,h,H,i,I,j,J) \
           (a A,b B,c C,d D,e E,f F,g G,h H,i I,j J)
#define F11(a,A,b,B,c,C,d,D,e,E,f,F,g,G,h,H,i,I,j,J,k,K) \
           (a A,b B,c C,d D,e E,f F,g G,h H,i I,j J,k K)
#define F12(a,A,b,B,c,C,d,D,e,E,f,F,g,G,h,H,i,I,j,J,k,K,l,L) \
           (a A,b B,c C,d D,e E,f F,g G,h H,i I,j J,k K,l L)
#define F13(a,A,b,B,c,C,d,D,e,E,f,F,g,G,h,H,i,I,j,J,k,K,l,L,m,M) \
           (a A,b B,c C,d D,e E,f F,g G,h H,i I,j J,k K,l L,m M)
#define F14(a,A,b,B,c,C,d,D,e,E,f,F,g,G,h,H,i,I,j,J,k,K,l,L,m,M,n,N) \
           (a A,b B,c C,d D,e E,f F,g G,h H,i I,j J,k K,l L,m M,n N)
#define F15(a,A,b,B,c,C,d,D,e,E,f,F,g,G,h,H,i,I,j,J,k,K,l,L,m,M,n,N,o,O) \
           (a A,b B,c C,d D,e E,f F,g G,h H,i I,j J,k K,l L,m M,n N,o O)

#define FA1(a1,n1,b1)            (a1 n1 b1)
#define FA2(a1,n1,b1,a2,n2,b2)   (a1 n1 b1, a2 n2 b2)
#define FA3(a1,n1,b1,a2,n2,b2,a3,n3,b3) \
        (a1 n1 b1, a2 n2 b2, a3 n3 b3)
#define FA4(a1,n1,b1,a2,n2,b2,a3,n3,b3,a4,n4,b4) \
        (a1 n1 b1, a2 n2 b2, a3 n3 b3, a4 n4 b4)
#define FA5(a1,n1,b1,a2,n2,b2,a3,n3,b3,a4,n4,b4,a5,n5,b5) \
        (a1 n1 b1, a2 n2 b2, a3 n3 b3, a4 n4 b4, a5 n5 b5)
#define FA6(a1,n1,b1,a2,n2,b2,a3,n3,b3,a4,n4,b4,a5,n5,b5,a6,n6,b6) \
        (a1 n1 b1, a2 n2 b2, a3 n3 b3, a4 n4 b4, a5 n5 b5, a6 n6 b6)
#define FA7(a1,n1,b1,a2,n2,b2,a3,n3,b3,a4,n4,b4,a5,n5,b5,a6,n6,b6,a7,n7,b7) \
        (a1 n1 b1, a2 n2 b2, a3 n3 b3, a4 n4 b4, a5 n5 b5, a6 n6 b6, \
        a7 n7 b7)

#else /* Old K&R style */

#define P0(a)                    ()
#define P1(a)                    ()
#define P2(a,b)                  ()
#define P3(a,b,c)                ()
#define P4(a,b,c,d)              ()
#define P5(a,b,c,d,e)            ()
#define P6(a,b,c,d,e,f)          ()
#define P7(a,b,c,d,e,f,g)        ()
#define P8(a,b,c,d,e,f,g,h)      ()
#define P9(a,b,c,d,e,f,g,h,i)    ()
#define P10(a,b,c,d,e,f,g,h,i,j) ()

#define P11(a,b,c,d,e,f,g,h,i,j,k)           ()
#define P12(a,b,c,d,e,f,g,h,i,j,k,l)         ()
#define P13(a,b,c,d,e,f,g,h,i,j,k,l,m)       ()
#define P14(a,b,c,d,e,f,g,h,i,j,k,l,m,n)     ()
#define P15(a,b,c,d,e,f,g,h,i,j,k,l,m,n,o)   ()

#define F0(a)                       ()
#define F1(a,A)                     (A)         a A;
#define F2(a,A,b,B)                 (A,B)       a A; b B;
#define F3(a,A,b,B,c,C)             (A,B,C)     a A; b B; c C;
#define F4(a,A,b,B,c,C,d,D)         (A,B,C,D)   a A; b B; c C; d D;
#define F5(a,A,b,B,c,C,d,D,e,E)     (A,B,C,D,E) a A; b B; c C; d D; e E;
#define F6(a,A,b,B,c,C,d,D,e,E,f,F) \
  (A,B,C,D,E,F)       a A; b B; c C; d D; e E; f F;
#define F7(a,A,b,B,c,C,d,D,e,E,f,F,g,G) \
  (A,B,C,D,E,F,G)     a A; b B; c C; d D; e E; f F; g G;
#define F8(a,A,b,B,c,C,d,D,e,E,f,F,g,G,h,H) \
  (A,B,C,D,E,F,G,H)   a A; b B; c C; d D; e E; f F; g G; h H;
#define F9(a,A,b,B,c,C,d,D,e,E,f,F,g,G,h,H,i,I) \
  (A,B,C,D,E,F,G,H,I) a A; b B; c C; d D; e E; f F; g G; h H; i I;
#define F10(a,A,b,B,c,C,d,D,e,E,f,F,g,G,h,H,i,I,j,J) \
  (A,B,C,D,E,F,G,H,I,J) \
  a A; b B; c C; d D; e E; f F; g G; h H; i I; j J;
#define F11(a,A,b,B,c,C,d,D,e,E,f,F,g,G,h,H,i,I,j,J,k,K) \
  (A,B,C,D,E,F,G,H,I,J,K) \
  a A; b B; c C; d D; e E; f F; g G; h H; i I; j J; k K;
#define F12(a,A,b,B,c,C,d,D,e,E,f,F,g,G,h,H,i,I,j,J,k,K,l,L) \
  (A,B,C,D,E,F,G,H,I,J,K,L) \
  a A; b B; c C; d D; e E; f F; g G; h H; i I; j J; k K; l L;
#define F13(a,A,b,B,c,C,d,D,e,E,f,F,g,G,h,H,i,I,j,J,k,K,l,L,m,M) \
  (A,B,C,D,E,F,G,H,I,J,K,L,M) \
  a A; b B; c C; d D; e E; f F; g G; h H; i I; j J; k K; l L; m M;
#define F14(a,A,b,B,c,C,d,D,e,E,f,F,g,G,h,H,i,I,j,J,k,K,l,L,m,M,n,N) \
  (A,B,C,D,E,F,G,H,I,J,K,L,M,N) \
  a A; b B; c C; d D; e E; f F; g G; h H; i I; j J; k K; l L; m M; \
  n N;
#define F15(a,A,b,B,c,C,d,D,e,E,f,F,g,G,h,H,i,I,j,J,k,K,l,L,m,M,n,N,o,O) \
  (A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) \
  a A; b B; c C; d D; e E; f F; g G; h H; i I; j J; k K; l L; m M; \
  n N; o O;


#define FA1(a1,n1,b1)            (n1) a1 n1 b1;
#define FA2(a1,n1,b1,a2,n2,b2)   (n1,n2) a1 n1 b1; a2 n2 b2;
#define FA3(a1,n1,b1,a2,n2,b2,a3,n3,b3) \
        (n1, n2, n3) \
        a1 n1 b1; a2 n2 b2; a3 n3 b3;
#define FA4(a1,n1,b1,a2,n2,b2,a3,n3,b3,a4,n4,b4) \
        (n1, n2, n3, n4) \
        a1 n1 b1; a2 n2 b2; a3 n3 b3; a4 n4 b4;
#define FA5(a1,n1,b1,a2,n2,b2,a3,n3,b3,a4,n4,b4,a5,n5,b5) \
        (n1, n2, n3, n4, n5) \
        a1 n1 b1; a2 n2 b2; a3 n3 b3; a4 n4 b4; a5 n5 b5;
#define FA6(a1,n1,b1,a2,n2,b2,a3,n3,b3,a4,n4,b4,a5,n5,b5,a6,n6,b6) \
        (n1, n2, n3, n4, n5, n6) \
        a1 n1 b1; a2 n2 b2; a3 n3 b3; a4 n4 b4; a5 n5 b5; a6 n6 b6;
#define FA7(a1,n1,b1,a2,n2,b2,a3,n3,b3,a4,n4,b4,a5,n5,b5,a6,n6,b6,a7,n7,b7) \
        (n1, n2, n3, n4, n5, n6, n7) \
        a1 n1 b1; a2 n2 b2; a3 n3 b3; a4 n4 b4; a5 n5 b5; a6 n6 b6; \
        a7 n7 b7;
#endif

/* The Microsoft and Zortech compilers doesn't like blank macro
 * arguments. In the case of the FA macros you may need this.
 */
#define EMPTY

#endif /* SCANSI_H */

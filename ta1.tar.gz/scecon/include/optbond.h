/* SCID @(#)optbond.h	1.9 (SimCorp) 99/09/29 14:19:08 */

#ifndef OPTBOND_H
#define OPTBOND_H

/************************************************************************
*                                                                       *
*    project    SCecon                                                  *
*                                                                       *
*    filename   optbond.h                                               *
*                                                                       *
*    this file contains definitions and function prototyping for the    *
*    routines in the SCecon option pricing module.                      *
*                                                                       *
************************************************************************/

/*** includes **********************************************************/
#include <option.h>
#include <bond.h>
#include <future.h>

/***** C++ Convenience *************************************************/
#ifdef __cplusplus
extern "C" {
#endif

/*** typedefs **********************************************************/

/*,,SOT,,

CONVTBL: Type for holding info on Convertible Bonds
---------------------------------------------------

This type is defined as:

        typedef struct
        {
            DATESTR  first ;
            DATESTR  last ;
            FL64     conv_price ;
            BOOLE    accr_incl ;
            FL64     call_hurdle ;
            DATESTR  hurdle_date ;
            DATESTR  call_date ;
            FL64     call_price ;
            PLAN_STR *call_plan ;
            FIXPAY   fixp ;
            PLAN_STR *div ;
        }   CONVTBL ;

The meaning of the elements are:

        first is the first potential conversion date

        last is the last potential conversion date

        conv_price is the conversion stock price

        If accr_incl is True then accrued interest is kept upon conversion.
        False the opposite meaning.

        call_hurdle is the knock-in level of the call option

        hurdle_date is the knock-in date of conditioned call

        call_date is the knock-in date of unconditioned call, >= hurdle_date

        call_price is the strike of the call option

        call_plan is the plan of (time varying) call strikes
        ---this overrides 'call_price' after call_plan->day[0]

        fixp are the data for the inconvertible (only BULLET's though).

        div are discrete-time dividends.

* To be added later:
*       put_plan is the plan of put dates and corresponding strikes.
*
*       If mat_conv is True then conversion is automaticly done
*       at maturity, otherwise redemption at par value.

,,EOT,,*/

typedef struct
{
    DATESTR  first ;
    DATESTR  last ;
    FL64     conv_price ;
    BOOLE    accr_incl ;
    FL64     call_hurdle ;
    DATESTR  hurdle_date ;
    DATESTR  call_date ;
    FL64     call_price ;
    PLAN_STR *call_plan ;
    FIXPAY   fixp ;
    PLAN_STR *div ;
/*..To be added later..
    PLAN_STR *put_plan ; 
    BOOLE    mat_conv ;   
*/
}   CONVTBL ;


/*
..Private
*/
typedef struct convtblnr_tag
{
  DATESTR   *analys;
  FL64      price;
  FL64      spot;
  FL64      vol;
  INTI      nstep;
  CONVTBL   *cvt;
  DISCFAC   *df0;
  DFSPREAD  *dfs;
  DISCFAC   *divdf;
  HOLI_STR  *holi;
  KEYCONV   key;
  FL64      shock;
} CONVTBLNR;



/*** macros ************************************************************/



/*** Prototyping   *****************************************************/



/*** routines in optfut.c   *********************************************/


/* Public functions */

FL64 OptFutBond_Black2P(DATESTR* analys,
                    DATESTR* voldate,
                    FL64    futp,
                    FL64    vol,
                    BOOLE    margin,
                    DATESTR  *delv,
                    OPTFUT*  opt,
                    DISCFAC* df,
                    HOLI_STR* holi,
                    RISKSET* risk,
                    FL64*    dp,
                    FL64*    ddp) ;

extern FL64 OptFutBond_Black2DFp(DATESTR *analys,
                    DATESTR *voldate,
                    FL64     vol,
                    INTI     noas,
                    DFSPREADARRAY dfs,
                    FUTBOND  *futb,
                    OPTFUT   *opt,
                    DISCFAC  *df,
                    HOLI_STR *holi,
                    RISKSET  *risk,
                    FL64     *dp,
                    FL64     *ddp) ;

extern FL64ARRAY OptFutBond_Black2Delta(DATESTR *analys,
                    DATESTR *voldate,
                    FL64     vol,
                    INTI     noas,
                    DFSPREADARRAY dfs,
                    FUTBOND  *futb,
                    OPTFUT   *opt,
                    DISCFAC  *df,
                    HOLI_STR *holi,
                    DELTASET  *ds) ;

extern BOOLE OptFutBond_Black2Impl(DATESTR* analys,
                    DATESTR* voldate,
                    FL64    prem,
                    BOOLE   is_p,
                    FL64    futp,
                    FL64    vol,
                    BOOLE   margin,
                    DATESTR *delv,
                    OPTFUT*  opt,
                    DISCFAC* df,
                    HOLI_STR* holi,
                    KEYCONV what,
                    ITERCTRL*  ctrl,
                    FL64*    impl) ;

extern FL64 OptFutBond_Black2YTMp(DATESTR *analys,
                    DATESTR  *voldate,
                    FL64     vol,
                    FUTBOND  *futb,
                    OPTFUT   *opt,
                    DISCFAC  *df,
                    FL64     ytm,
                    YTMCONV  *ytmc,
                    HOLI_STR *holi,
                    RISKSET  *risk,
                    FL64     *dp,
                    FL64     *ddp) ;

extern FL64 OptBond_Black2P(DATESTR  *analys,
                     DATESTR  *voldate,
                     FL64     vol,
                     FL64     spot,
                     DFSPREAD *dfs,
                     FIXPAY   *fixp,
                     OPTFUT   *opt,
                     DISCFAC  *df,
                     HOLI_STR *holi,
                     RISKSET  *risk,
                     FL64     *dp,
                     FL64     *ddp) ;

extern FL64 OptBond_B762P(DATESTR* analys,
                     DATESTR*  voldate,
                     FL64      vol,
                     FL64      spot,
                     FL64      forw,
                     OPTFUT*   opt,
                     DISCFAC*  df,
                     HOLI_STR* holi,
                     RISKSET*  risk,
                     FL64*     dp,
                     FL64*     ddp) ;

extern BOOLE OptBond_Black2Impl(DATESTR *analys,
                    DATESTR *voldate,
                    FL64    prem,
                    BOOLE   is_p,
                    FL64    vol,
                    FL64     spot,
                    DFSPREAD *dfs,
                    FIXPAY   *fixp,
                    OPTFUT  *opt,
                    DISCFAC *df,
                     HOLI_STR *holi,
                    KEYCONV what,
                    ITERCTRL *ctrl,
                    FL64    *impl) ;

extern FL64 OptBond_Black2DFp(DATESTR *analys,
                    DATESTR  *voldate,
                    FL64     vol,
                    DFSPREAD *dfs,
                    FIXPAY   *fixp,
                    OPTFUT   *opt,
                    DISCFAC  *df,
                     HOLI_STR *holi,
                    RISKSET  *risk,
                    FL64     *dp,
                    FL64     *ddp) ;

extern FL64ARRAY OptBond_Black2Delta(DATESTR *analys,
                    DATESTR  *voldate,
                    FL64     vol,
                    DFSPREAD *dfs,
                    FIXPAY   *fixp,
                    OPTFUT   *opt,
                    DISCFAC  *df,
                    HOLI_STR *holi,
                    DELTASET  *ds) ;

extern FL64 OptBond_Black2YTMp(DATESTR *analys,
                    DATESTR  *voldate,
                    FL64     vol,
                    FIXPAY   *fixp,
                    OPTFUT   *opt,
                    DISCFAC  *df,
                    FL64     ytm,
                    YTMCONV  *ytmc,
                     HOLI_STR *holi,
                    RISKSET  *risk,
                    FL64     *dp,
                    FL64     *ddp) ;

extern FL64 OptBond_VOLBOX2Vol(DATESTR  *today,
                        VOLBOX  *vb,
                        OPTFUT   *opt,
                        FIXPAY   *fixp,
                        DISCFAC  *df,
                        HOLI_STR *holi) ;

extern FL64 OptFutBond_VOLBOX2Vol(DATESTR  *today,
                       VOLBOX  *vb,
                       OPTFUT   *opt,
                       FIXPAY   *fixp,
                       DISCFAC  *df,
                       HOLI_STR *holi) ;


/* Private functions */

extern FL64 OptBond_YldVol2Pvol(FL64 yvol, FIXPAY *fixp, DISCFAC *df, 
                                   HOLI_STR *holi) ;

extern FL64 OptFutBond_YldVol2FutPvol(FL64 yvol, OPTFUT *opt, FIXPAY *fixp,
                                  DISCFAC *df, HOLI_STR *holi) ;


/*** routines in convtibl.c ***********************************************/


/* Public functions */
extern BOOLE Convtbl_CRR2Price(DATESTR* analys,
                            FL64       spot,
                            FL64       vol,
                            INTI       nstep,
                            CONVTBL*   cvt,
                            DISCFAC*   df,
                            DFSPREAD*  dfs,
                            DISCFAC*   divdf,
                            HOLI_STR*  holi,
                            RISKSET*   opt,
                            FL64*      p,
                            FL64*      dp,
                            FL64*      ddp) ;

extern BOOLE Convtbl_CRR2Impl(DATESTR*  analys,
                           FL64      price,
                           FL64      spot,
                           FL64      vol,
                           INTI      nstep,
                           CONVTBL*  cvt,
                           DISCFAC*  df,
                           DFSPREAD* dfs,
                           DISCFAC*  divdf,
                           HOLI_STR* holi,
                           KEYCONV   key,
                           ITERCTRL* ictrl,
                           FL64*     impl) ;

extern FL64ARRAY Convtbl_CRR2Delta(DATESTR*  analys,
                                FL64      spot,
                                FL64      vol,
                                INTI      nstep,
                                CONVTBL*  cvt,
                                DISCFAC*  df,
                                DFSPREAD* dfs,
                                DISCFAC*  divdf,
                                HOLI_STR* holi,
                                DELTASET* ds,
                                BOOLE*    ok) ;

extern void Free_CONVTBL(CONVTBL* convtbl);

/* Private functions */
extern BOOLE crr_convtbl_premium(DATESTR*   analys,
                              FL64       spot,
                              FL64       vol,
                              INTI       nstep,
                              CONVTBL*   cvt,
                              DISCFAC*   df0,
                              DFSPREAD*  dfs,
                              DISCFAC*   divdf,
                              HOLI_STR*  holi,
                              FL64*      p,
                              FL64*      d,
                              BOOLE      do_d) ;

extern BOOLE call_exercise(FL64 node_time,
                        FL64 hurdle_time,
                        FL64 call_time,
                        FL64 call_hurdle,
                        FL64 stock_price,
                        FL64 option_value,
                        FL64 bond_price,
                        FL64 call_price) ;

extern BOOLE fixp_to_npvarray(INTI        nlevel,
                       DATESTR     *analys,
                       FL64        *time,
                       DISCFAC     *df,
                       FIXPAYARRAY bond,
                       FL64ARRAY   bond_npv,
                       FL64ARRAY   bond_price,
                       BOOLE       do_price_only,
                       HOLI_STR    *holi) ;

extern FL64 find_call_price(DATESTR   *analys,
                               CONVTBL   *convtbl,
                               FL64      time,
                               CALCONV   cal,
                               EOMCONV   eom) ;



extern CONVTBLNR Convtbl_SetNR(DATESTR* analys, 
                                   FL64 price, 
                                   FL64 spot, 
                                   FL64 vol, 
                                   INTI nstep, 
                                   CONVTBL* cvt, 
                                   DISCFAC* df0, 
                                   DFSPREAD* dfs, 
                                   DISCFAC* divdf, 
                                   HOLI_STR* holi, 
                                   KEYCONV key, 
                                   FL64 shock);

extern void Convtbl_GetNR(DATESTR** analys, 
                              FL64* price, 
                              FL64* spot, 
                              FL64* vol, 
                              INTI* nstep, 
                              CONVTBL** cvt,                         
                              DISCFAC** df0, 
                              DFSPREAD** dfs,                         
                              DISCFAC** divdf, 
                              HOLI_STR** holi,                         
                              KEYCONV* key, 
                              FL64* shock,
                              CONVTBLNR* c);

extern BOOLE Convtbl_NewtonRaphson(FL64 x, 
                    void* y,
                    BOOLE grad,
                    FL64* fx, 
                    FL64* dfx,
					void* hol); /* PMSTA-29444 - SRIDHARA - 050318 */


#ifdef __cplusplus
}
#endif

#endif

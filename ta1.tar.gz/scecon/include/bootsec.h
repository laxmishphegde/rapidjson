/* @(#)bootsec.h	1.8 (SimCorp) 99/02/19 14:11:46 */

#ifndef BOOTSEC_H
#define BOOTSEC_H

/************************************************************************
*                                                                       *
*    project     SCecon                                                 *
*                                                                       *
*    filename    bootsec.h                                              *
*                                                                       *
*    general     this file contains declarations, initializations,      *
*                type definitions and function prototyping for the      *
*                bootstrappng module of the standard library SCecon     *
*                                                                       *
************************************************************************/


/**** includes *********************************************************/
#include <bond.h>
#include <swap.h>

#ifdef __cplusplus
extern "C" {
#endif

/**** defines  *********************************************************/


/*,,SOT,,

BSECTYPE : data type for bootstrap securities
---------------------------------------------

This type is used for identifying the securities that can be
used in bootstrapping the money market discount function. The BSECTYPE
type is defined as:

    typedef enum bsectype_tag
    {
        MM,
        FRA,
        SWAP,
        IRF,
        BOND,
        AVGIRF,
        BONDREPO,
        BONDSMPL,
        SWAPGENR,
        IMMFRA,
        SWAPFUT
    }   BSECTYPE ;

in bootstrp.h.

The securities are:

    MM       - Money market instrument - overnight, 3 month deposit etc,
    FRA      - Forward rate agreement - 3 against 6 month etc,
    SWAP     - Plain vanila interest rate par swap and
    IRF      - Interest rate future quoted as a price.
    BOND     - General bond (or bond future/forward)
    AVGIRF   - Interest rate future on some average (e.g FF for Fed Funds
               futures)
    BONDREPO - Repo on bond or bond future (using the repo cashflow)
    BONDSMPL - Simple Bond
    SWAPGENR - General fixed swap leg
    IMMFRA   - Forward rate agreement start on an IMM day,
    SWAPFUT  - Swap future (e.g. Liffe LFB).

Note that BOND's also handles bond futures/forwards by suitably defining
settlement days (see Boot_BSEC2DF()). In this way the long end of the curve
can be bootstrapped with futures. With bondrepo's the short end can be
bootstrapped.

,,EOT,,*/

typedef enum bsectype_tag
{
    BSECTYPE_INIT = -1,
    MM,
    FRA,
    SWAP,
    IRF,
    BOND,
    AVGIRF,
    BONDREPO,
    BONDSMPL,
    SWAPGENR,
    IMMFRA,
    SWAPFUT
}   BSECTYPE ;


/*,,SOT,,

BSEC and BSECARRAY : types for holding money market security info
---------------------------------------------------------------------

BSEC is a type for holding the information needed on various money
market securities for bootstrapping the discount function.
The BSEC type is defined as:

    typedef struct bsec_tag
    {
        BSECTYPE  type ;
        IRRCONV   irr ;
        CALCONV   cal ;
        CALCONV   cal_ipol ;
        EOMCONV   eom ;
        BUSCONV   bus ;
        INTI      term1 ;
        INTI      term2 ;
        TERMUNIT  unit ;
        PMTFREQ   freq ;
        DATESTR   start ;
        DATESTR   maturity ;
        FL64      curr_avg ;
        BOOLE     nest ;
        FL64      coupon ;
        INTI      excdays ;
        BOOLE     vanilla ;
        FIXPAY    fixp ;
        SWAPFIX   sfix ;
    }   BSEC ;

The following info is needed for various securities:

MM:
type, irr, cal, cal_ipol, eom, bus, term1, unit -
eg. MM, SIMPLE_MM, ACT365, ACTACT, SAME, NEXT, 3, MONTHS,

irr can be used to define standard money market instruments (using
irr = SIMPLE_MM) or discount based instruments (using DISCOUNT) like
T-Bill's etc. 
Turn-Adjustment can be included by using a forward settle
date (see Boot_BSEC2DF()) with the appropriate deposit period.
Set using Set_BSEC_MM()

FRA:
type, cal, cal_ipol, eom, bus, term1, term2, unit, nest -
eg. FRA, ACT365, ACTACT, SAME, NEXT, 3, 6, MONTHS, False,

nest signifies how the FRA maturity data are calculated.
If False we follow market standards of finding maturity as

        today + term2 * unit.

If True we follow Miron/Swannell convention, which is

        FRAstartdate + (term2 - term1) * unit.

Sometimes these dates differ depending on the holidays etc.
A FRA allows for entry of standard FRA's in bootstrapping.
Set using Set_BSEC_FRA()
  
IRF:
type, cal, cal_ipol, eom, bus, start, maturity -
eg. IRF, ACT365, ACTACT, SAME, NEXT, 19920917, 19921218 and

A special case conserns IRF's due to the fact that these futures often
mature on IMM dates. This can be handled by setting start/maturity to the
relevant IMM dates.
This facilitates incorporating Euro Dollar Futures and Bank Bill Yield 
Futures in bootstrapping. Also IMM FRA's can be handled in this setup,
simply by translating the rate to a price (100 - rate).
Set using Set_BSEC_IRF()

SWAP:
type, cal, cal_ipol, eom, bus, term1, unit, freq -
eg. SWAP, ACT365, ACTACT, SAME, NEXT, 5, YEARS, SEMIANNUALLY.

This setup handles standard par swaps with standardised maturities and
conditions (as it is almost always is the case).
Set using Set_BSEC_SWAP()

AVGIRF:
type, cal, cal_ipol, eom, bus, term1, unit, start, maturity, curr_avg -
eg. AVGIRF, ACT360, ACTACT, LAST, NEXT, 1, DAYS, 19951101, 19951130, 5.25

Here curr_avg is the current average for the first future, that is usually
priced in the middle of the period. term1 / unit describes the averaging
frequency (e.g 1 DAYS for Fed Funds futures). Notice that for Fed Funds
Futures bus should be NO_BUSADJUST since weekend's and holidays account for
the same rates as the previous businessday, and the contract may start on
a non-businessday (whenever the first day in a month is in a weekend).
This is used to enter Fed Funds Futures into the bootstrapping.
Set using Set_BSEC_AVGIRF()

Bonds can be defined in 2 ways:

The GENERAL way is to use the FIXPAY's data type:

BOND:
type, cal_ipol, bus, vanilla = False, fixp
eg. BOND, ACTACT, NEXT, False, bond-definition

To enter fixp consider using the routines BondBM_BONDBM2FIXPAY() and
Bond_Simple2FIXPAY().
Set using Set_BSEC_BOND()
The SIMPLE (and RECOMMENDED) unless special FIXPAY features are needed
is the following way:

BONDSMPL:
type, cal, cal_ipol, bus, eom, freq, start, maturity, coupon, excdays
eg. BOND, ACTACT, ACTACT, NEXT, LAST, ANNUALLY, 19951011, 
19981011, 8.875, 30

excdays is the number of ex-coupon days for bonds and start is the issue date.
In the latter case the fixp element is completely ignored! The BOND type can
be used to model BRD, US, DKK, NLG, BEF, FFR etc Government Bonds.
Set using Set_BSEC_BONDSMPL()

Note that BOND / BONDSMPL's also handles bond futures/forwards by suitably 
defining settlement days (see Boot_BSEC2DF()). In this way the long end of 
the curve can be bootstrapped with futures.

BONDREPO:
type, cal_ipol, bus, eom, maturity, vanilla = False, fixp
eg. BONDREPO, ACTACT, NEXT, LAST, 19960711, False, bond-definition

Here maturity is the repo/forward end date. The start date is entered in
Boot_BSEC2DF() as settle[i].  fixp is for the CTD bond.
To enter a fixp consider using the routines BondBM_BONDBM2FIXPAY() and
Bond_Simple2FIXPAY(). 
With bondrepo's the short end can be bootstrapped.
Bondrepo's are usually quoted on the repo rate. For the Boot_BSEC2DF()
function, the forward price (equivalent to the repo rate) must be
specified. This forward price can be computed using RepoBond_BuyBack().
Set using Set_BSEC_BONDREPO()

SWAPGENR:
type, cal_ipol, bus, vanilla = False, sfix
e.g. SWAPGENR, ACTACT, NEXT, False, swap fixed leg definition

This is used to define more general swap fix legs than what can be 
facilitated by the SWAP definition, that essentially defines very
standardised legs.
Set using Set_BSEC_SWAPGENR()

IMMFRA:
type, cal, cal_ipol, eom, bus, term1, unit, start -
eg. IMMFRA, ACT365, ACTACT, SAME, NEXT, 3, MONTHS, 19980301,

This instrument is a standard FRA with the special feature
that both FRA start date and FRA maturity date are IMM
(possibly pseudo IMM days) dates.
The starting date of the FRA is the IMM date in the month of
start date specified (March 1998 in the example above).
The maturity date of the FRA is the start date plus term1 units.
Set using Set_BSEC_IMMFRA()

SWAPFUT:
type, cal, cal_ipol, eom, bus, term1, unit, freq, maturity, coupon -
eg. SWAPFUT, EU30E360, EU30E360, SAME, NEXT, 5, YEARS, ANNUALLY, 19981216, 4.5

This handles standard futures on a fixed swapleg where maturity is the
expiry/delivery date of the future.
Set using Set_BSEC_SWAPFUT()


The distinction between calendar conventions has the following 
interpretation:

    cal is used for 'pricing' the instrument, i.e. setting payments
    (e.g. fixed rate amount on fixed legs or accrued interest for
    bonds)

    cal_ipol is used for interpolating in the discount factors


The struct member vanilla is used to indicate whether any data following 
vanilla in the struct are used. If any are used set vanilla to False 
otherwise let is be True. The rationale for using this member is to be 
found in an APL interface against SCecon. Therefore let the default value
be True.


BSECARRAY is needed for lists of BSEC's
The definition of the BSECARRAY type is:

    typedef BSEC * BSECARRAY ;

see also Set_BSEC_MM
         Set_BSEC_FRA
         Set_BSEC_IMMFRA
         Set_BSEC_IRF
         Set_BSEC_BOND
         Set_BSEC_BONDSMPL
         Set_BSEC_AVGIRF
         Set_BSEC_SWAP
         Set_BSEC_SWAPGENR
         Set_BSEC_BONDREPO
         Set_BSEC_SWAPFUT

,,EOT,,*/

typedef struct bsec_tag
{
    BSECTYPE  type ;
    IRRCONV   irr ;
    CALCONV   cal ;
    CALCONV   cal_ipol ;
    EOMCONV   eom ;
    BUSCONV   bus ;
    INTI      term1 ;
    INTI      term2 ;
    TERMUNIT  unit ;
    PMTFREQ   freq ;
    DATESTR   start ;
    DATESTR   maturity ;
    FL64      curr_avg ;
    BOOLE     nest ;
/*..change this to a SEQCONV */
    FL64      coupon ;
    INTI      excdays ;
    BOOLE     vanilla ;
    FIXPAY    fixp ;
    SWAPFIX   sfix ;
}   BSEC ;

typedef BSEC * BSECARRAY ;



/*** function prototyping (bootsec.c) *************************************/


/* Public functions */

extern INTIARRAY Boot_GenrIndex(BSECARRAY secs,
                                DATEARRAY settle,
                                INTI      nsec,
                                HOLI_STR  *holi) ;

extern BSEC Set_BSEC_SWAPGENR(CALCONV   cal_ipol,
                          BUSCONV   bus,
                          SWAPFIX*  sfix) ;

extern BSEC Set_BSEC_BONDREPO(CALCONV   cal_ipol,
                          BUSCONV   bus,
                          EOMCONV   eom,
                          DATESTR*  maturity,
                          FIXPAY*    fixp) ;

extern BSEC Set_BSEC_BONDSMPL(CALCONV   cal,
                     CALCONV   cal_ipol,
                     EOMCONV   eom,
                     BUSCONV   bus,
                     PMTFREQ   freq,
                     DATESTR*  start,
                     DATESTR*  maturity,
                     FL64       coupon,
                     INTI       excdays) ;

extern BSEC Set_BSEC_BOND(CALCONV   cal_ipol,
                      BUSCONV   bus,
                      FIXPAY*   fixp) ;

extern BSEC Set_BSEC_AVGIRF(CALCONV   cal,
                     CALCONV   cal_ipol,
                     EOMCONV   eom,
                     BUSCONV   bus,
                     INTI      term1,
                     TERMUNIT   unit,
                     DATESTR*  start,
                     DATESTR*  maturity,
                     FL64       curr_avg) ;

extern BSEC Set_BSEC_SWAP(CALCONV   cal,
                      CALCONV   cal_ipol,
                      EOMCONV   eom,
                      BUSCONV   bus,
                      INTI      term1,
                      TERMUNIT  unit,
                      PMTFREQ   freq) ;

extern BSEC Set_BSEC_IRF(CALCONV   cal,
                     CALCONV   cal_ipol,
                     EOMCONV   eom,
                     BUSCONV   bus,
                     DATESTR*  start,
                     DATESTR*  maturity) ;

extern BSEC Set_BSEC_FRA(CALCONV   cal,
                     CALCONV   cal_ipol,
                     EOMCONV   eom,
                     BUSCONV   bus,
                     INTI      term1,
                     INTI      term2,
                     TERMUNIT  unit,
                     BOOLE     nest) ;

extern BSEC Set_BSEC_IMMFRA(CALCONV   cal,
                     CALCONV   cal_ipol,
                     EOMCONV   eom,
                     BUSCONV   bus,
                     DATESTR*  start,
                     INTI      term1,
                     TERMUNIT  unit) ;


extern BSEC Set_BSEC_MM(IRRCONV   irr,
                    CALCONV   cal,
                    CALCONV   cal_ipol,
                    EOMCONV   eom,
                    BUSCONV   bus,
                    INTI      term1,
                    TERMUNIT  unit) ;

extern BSEC Set_BSEC_SWAPFUT (CALCONV   cal,
                      CALCONV   cal_ipol,
                      EOMCONV   eom,
                      BUSCONV   bus,
                      INTI      term1,
                      TERMUNIT  unit,
                      PMTFREQ   freq,
                      DATESTR*  maturity,
                      FL64      coupon);

extern BSECARRAY Alloc_BSECARRAY(INTI n) ;
extern void Free_BSECARRAY(BSECARRAY array) ;

/* Private functions */

extern DATESTR Boot_Genrmaturity(DATESTR   *today,
                                 BSECARRAY secs,
                                 HOLI_STR  *h) ;


#ifdef __cplusplus
}
#endif

#endif

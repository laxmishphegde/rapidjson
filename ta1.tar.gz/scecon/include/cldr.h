/* SCID @(#)cldr.h	1.68 (SimCorp) 99/11/11 10:30:10 */

#ifndef CLDR_H
#define CLDR_H

/************************************************************************
*                                                                       *
*    project     SCecon                                                 *
*                                                                       *
*    filename    cldr.h                                                 *
*                                                                       *
*    general     this file contains declarations, initializations,      *
*                type definitions and function prototyping for the      *
*                calendar module of the standard library SCecon         *
*                                                                       *
************************************************************************/

/**** includes *********************************************************/
#include <scecon.h>
#include <scutl.h>
#include <math.h>
#include <stdlib.h>                /* Needed for compiling with High C */

#ifdef __cplusplus
extern "C" {
#endif

/*** constants ********************************************************/

/* Model terms are always real-life terms: a year fraction
   expresses the actual number of days relative to the actual
   number of days per year. Hence, ACTACT. */
#define MODELTERMCAL       ACTACT


/*** typedefines ******************************************************/

/*,,SOT,,

DATESTR, YYYYMMDD, MMDD, DATEARRAY, YMDARRAY, MMDDARRAY : types for dates
-------------------------------------------------------------------------

Internally in SCecon, a date is represented as a special data structure
defined as

        typedef struct datestr_tag
        {
            INTI y ;
            INTI m ;
            INTI d ;
        }   DATESTR ;

In SCecon routines are provided to convert dates from the well known
format yyyymmdd to DATESTR and vise versa. The yyyymmdd format of dates
in SCecon is defined as

        typedef INTL YYYYMMDD ;

The last data type used in relation with dates is MMDD. This data type
contains information on the month and day of a specific date.
MMDD is defined as

        typedef INTI MMDD ;

Lists of these datatypes are defined as:

DATEARRAY and YMDARRAY are defined as

        typedef  DATESTR  * DATEARRAY ;
        typedef  YYYYMMDD * YMDARRAY  ;
        typedef  MMDD     * MMDDDARRAY  ;

,,EOT,,*/

typedef struct datestr_tag
{
    INTI y;
    INTI m;
    INTI d;
}   DATESTR ;


typedef INTL YYYYMMDD ;
typedef INTI MMDD ;

typedef DATESTR  * DATEARRAY ;
typedef YYYYMMDD * YMDARRAY ;
typedef MMDD     * MMDDARRAY ;



/*,,SOT,,

CALCONV : data type for calendar conventions
--------------------------------------------

Calendar conventions define how to count the number of days between two
dates and how to count the number of days per year in order to compute
day count fractions. 

In SCecon, calendar conventions must be specified as the type CALCONV,
defined as

        typedef enum cal_tag
        {
            ACTACT,
            ACTLEAP,
            ACTAFB,
            ACTEUROBOND,
            ACTFRF,
            EU30360,
            EU30E360,
            EU30E365,
            US30360,
            US30E360,
            ACT365,
            ACTNL365,
            ACT360,
            EU30EP360
        }   CALCONV ;

The main purpose of the calendar convention is to define the day count 
fraction used e.g. when computing accrued interest over a certain time period. 
The day count fraction is in general computed as

            Number of days in period / Number of days per year.

The time period in question is defined to go from, and including, the period
start date to, but excluding, the period end date. 

The definition of these are described below, followed of a short note on
the market practice.

The definitions are in accordance with the ISMA publication "Bond Markets: 
Structures and Yield Calculations" (1998) by Patrick Brown and the ISDA note 
"Emu and Market Conventions: Recent Developments" (1998).

Number of days in period
------------------------

For the ACT based conventions, ACTACT, ACTLEAP, ACTAFB, ACTEUROBOND, ACTFRF, 
ACT365, ACT360, the number of days between the two dates is computed as the 
actual number of calendar days in the period, including 29 February if it 
occurs in the period. For ACTNL365, which is used in Japan, 29 February is 
never counted.

For the 30-day month based conventions, EU30360, EU30E360, EU30E365, EU30EP360,
US30360, US30E360, the number of days between two days - written on the form 
day-month-year as d1m1y1 and d2m2y2 - is computed according to the formula:

        360 * (y2 - y1) + 30 * (m2 - m1) + (d2 - d1),

where the original dates are modified according to the rules below:

EU30360, US30360 convention (also know as the "30-day month U.S. method"):

        If d1 = 31 then d1 is set to 30.
        If d2 = 31 and modified d1 = 30 then d2 is set to 30.

EU30E365, EU30E365, US30E360 convention (also known as the "30-day European 
method"):

        If d1 = 31 then d1 is set to 30.
        If d2 = 31 then d2 is set to 30.

EU30EP360 convention:

        If d1 = 31 then d1 is set to 30.
        If d2 = 31 then d2 is set to 1, m2 (and possibly y2) is updated
        to next month.
        
Number of days per year
-----------------------          .

For the 360-days conventions, EU30360, EU30E360, EU30EP360, US30360, 
US30E360, ACT360, the number of days per year is 360. 

For the 365-days conventions, EU30E365, ACT365, ACTNL365, the number 
of days per year is 365 

For the actual-days conventions, ACTACT, ACTLEAP, ACTAFB, ACTEUROBOND, 
ACTFRF, the number of days per is the actual number of days per year, 
differing in the treatment of leap years in the following manner:

ACTACT convention: The number of days per year is the actual number of days
from the period start date and one year ahead.

ACTAFB: If the period is shorter than one year then the number of days is
366 if 29 February occurs in the period. Otherwise it is 365. 
If the period is longer than one year then the period is split into one year 
sub-periods - counting backwards from the period end date - plus the remaining 
initial stub period of length shorter than one year. The day count fraction 
is the sum over the day count fractions of the sub-periods. The stub period is 
treated in accordance with the first rule and the remaining year-long periods 
have a day count fraction of 1.

ACTEUROBOND: If the period equals a whole year then the number of days per 
year equals the actual number of days in the period. If the period is not
a whole year the the number of days per year equals the number of days in 
the calendar year of the end period date.

ACTFRF: The number of days per year is the actual number of days from
the end period date and one year back.

ACTLEAP: The period is split into the periods which are in leap
and non-leap years. In the former periods the number of days per year is 
366 while in the latter periods the number of years is 365. The day count 
fraction is the sum over the day count fractions of the sub-periods.

Market practice
---------------

The actual-actual calendar conventions, ACTACT, ACTLEAP, ACTAFB,
ACTEUROBOND, ACTFRF, are used in the swap (floating leg) and bond markets. 
The recommendation of using actual-actual in the new euro denominations has
highlighted the differences between the conventions even though they 
only differ in the number of days per year when considering leap years.

ACTACT              Original SCecon convention.
ACTLEAP             ISDA convention for swaps. It has been proposed
                    to switch to ACTAFB. 
ACTAFB              AFB convention. Recommended new ISDA convention.
ACTEUROBOND         Used in the Eurobond market.
ACTFRF              Used in the French market.

The 30-month calendar conventions, EU30360, EU30E360, EU30E365, US30360,
US30E360, EU30EP360, are used swap (fixed leg) and bond markets.

EU30360, US30360    Used in Finland
EU30E360, US30E360  Previous standard in Europe. Still used in Denmark,
                    Sweden, Holland, Belgium, and Austria. 
EU30EP360           Used in Switzerland.

The actual-360 convention, ACT360, is used in money and swap
(floating leg) markets.

The actual-365 conventions, ACT365 and ACTNL365, are used in Norway, 
Canada, and Japan

,,EOT,,*/

typedef enum cal_tag
{
    CALCONV_INIT = -1,
    ACTACT,
    ACTLEAP,
    ACTAFB,
    ACTEUROBOND,
    ACTFRF,
    EU30360,
    EU30E360,
    EU30E365,
    US30360,
    US30E360,
    ACT365,
    ACTNL365,
    ACT360,
    EU30EP360,
	BUS252    /* PMSTA-22396  - SRIDHARA - 160503 New Accrual Rule BUS252 */
}   CALCONV ;


/*,,SOT,,

EOMCONV : data type for end of month conventions
------------------------------------------------

The end of month conventions are used when finding the day some months
after a specific date.

        typedef enum eom_tag
        {
            LAST,
            SAME,
            LAST360
        }   EOMCONV ;

For a semiannually paying instrument, issued on February 28, 1992 for
instance, the first coupon day according to the SAME end of month
convention would be on August 28, 1992.

Using the LAST end of month convention, the first coupon day would have
been August 31, 1991.

In case the bond had been issued on August 31, 1991, the next coupon day
would be February 29, 1992 no matter the convention (SAME or LAST).

Using LAST360 is slightly different. Here the 31'st of any month and the
29'th of February are always ignored. Consequently the semiannual payment
following August 29 or 30 is always February 28. This is essentially the
only use of this EOMCONV value.

,,EOT,,*/

typedef enum eom_tag
{
    EOMCONV_INIT = -1,
    LAST,
    SAME,
    LAST360
}   EOMCONV ;


/*,,SOT,,

BUSCONV : data type for business day conventions
------------------------------------------------

Business day conventions are used to find the day where a payment
actually will take place in case the scheduled payment day should be
a non business day.

Business day conventions are specified in the data type BUSCONV defined
as

        typedef enum bus_tag
        {
            NEXT,
            NEXTINMONTH,
            CLOSEST,
            CLOSESTINMONTH,
            PREVIOUS,
            PREVIOUSINMONTH,
            NO_BUSADJUST
        }   BUSCONV ;

Using the NEXT business day conventions, payments are postponed to the
first business day after the scheduled payment day.
This corresponds to the Following convention.

Using the NEXTINMONTH business day convention, payments are postponed as
above, unless the resulting business day is in the following month, in
which case, payments are precipitated to the first business day before
the scheduled payment day.
This corresponds to the Modified Following convention.

Using the CLOSEST business day convention, the actual payment day is
moved to the business day closest to the scheduled payment day.

According to the CLOSESTINMONTH business day convention, the actual
payment day is found as with the CLOSEST convention, unless this day
happens to be in a month different than the month of the scheduled
payment day. In this case, the payment day is moved to the closest
business day of the same month.

Following the PREVIOUS business day convention, payments are
precipitated to the first business day before the scheduled payment day.

According to the PREVIOUSINMONTH business day convention, the actual
payment day is found as with the PREVIOUS convention, except if this day
happens to be in a month before that of the scheduled payment day. In
this case, the payment day is moved to the first business day after the
scheduled payment day.

When NO_BUSADJUST is invoked no adjustment will take place.

,,EOT,,*/

typedef enum bus_tag
{
    BUSCONV_INIT = -1,
    NEXT,
    NEXTINMONTH,
    CLOSEST,
    CLOSESTINMONTH,
    PREVIOUS,
    PREVIOUSINMONTH,
    NO_BUSADJUST
}   BUSCONV ;


/*,,SOT,,

TERMUNIT : Unit of maturity quoting
-----------------------------------

TERMUNIT is used to quote the maturity of instruments or events in a
simple manner, or in some other situation where a simple maturity quoting is
needed.
It is defined as:

        typedef enum term_tag
        {
            DAYS,
            BUSDAYS,
            WEEKS,
            MONTHS,
            YEARS
        }   TERMUNIT ;

,,EOT,,*/

typedef enum term_tag
{
    TERMUNIT_INIT = -1,
    DAYS,
    BUSDAYS,
    WEEKS,
    MONTHS,
    YEARS
}   TERMUNIT ;


/*,,SOT,,

SEQCONV : Convention for calculation of paydays
-----------------------------------------------

SEQCONV is used to specify the calculation (ROLL) of paydays.
It is defined as:

        typedef enum seqconv_tag
        {
            ANCHOR ,
            ANCHORBACK ,
            CHAIN ,
            IMM,
            CAD_BA,
            ANCHORSHIFT,
            LASTBUS,
            IMM_ZAR,
            TAM_T4M
        }   SEQCONV ;

If ANCHOR is choosen then all paydays are calculated relative to a fixed
date - typically the issuedate.

If ANCHORBACK is choosen then all paydays are calculated relative to the
last payday calculating backwards.
Note that in this case odd last periods cannot be handled (unless
second last payday are entered). NOTE that end of month conventions are
computed relative to the maturity date.

CHAIN means that the dates are calculated relative to the previous payday.
Essentially this is equal to ANCHOR if no holidays are used, and the days 
are not near end of month days.

IMM means that the paydays are meant to be on IMM days. (Real) IMM days
are the 3rd wednesday in march, june, september or december. These are
internationally recognised settlement days for many contracts (like 
interest rate futures, FRA's, swaps). Sometime pseudoIMM days are used,
meaning the 3rd wednesday in any month. This is distinguished by the
payment frequency (quarterly or monthly, or ...).

CAD_BA are Canadian BA days. These are 2 days prior to IMM  F1(or pseudo,IMM)
days. I.e. mondays in the week of the 3'rd wednesday of the month.

If ANCHORSHIFT is used the paydays are generated as when using ANCHOR, however,
the first payday in any month will automatically be the first, and the first
payday in any year will be shifted 1 day forward. This can be used to handle
Norwegian loans with paydays on (2-Jan and 1-Jul or 2-May and 1-Nov).

LASTBUS indicates the last business date of any payment month.

IMM_ZAR are South African 'IMM' dates. I.e. the 3rd thursday in 
Feb/May/Aug/Nov.

TAM_T4M defines the convention for these swap types, after which the paydays
are aligned to the 'closest' first day of a month. I.e. on the 1st through
the 15th (incl) of a month the effective date is the first of the current 
month and  the paydays relative to this, on the 16th through 31st the 
effective date i the 1st of the following month.
Remember that T4M's pay monthly and TAM's pay annually (except if a 
broken period is used).

,,EOT,,*/

typedef enum seqconv_tag
{
    SEQCONV_INIT = -1,
    ANCHOR ,
    ANCHORBACK ,
    CHAIN ,
    IMM,
    CAD_BA,
    ANCHORSHIFT,
    LASTBUS,
    IMM_ZAR,
    TAM_T4M
}   SEQCONV ;


/*,,SOT,,

PLAN_STR, PLANARRAY : Struct for holding arrays of dateinfo
-----------------------------------------------------------

PLAN_STR is a sruct for holding info on arrays of corresponding dates and
numbers, eg. dates and payments or dates and discount factors.

The type PLAN_STR is defined as

        typedef struct
        {
            INTI      count ;
            INTI      filled ;
            DATEARRAY day ;
            FL64ARRAY f64 ;
        }   PLAN_STR ;

Members are interpreted as:

        count is used to save the amount of memory allocated

        filled is used to keep track of the number of actually filled
        elements.

        day[filled] contains the date list corresponding to the events
        recorded in the f64[filled] list

In SCEcon PLAN_STR always come as a PLAN_STR*. The structure is
allocated using Alloc_PLANARRAY(1, count) which returns a PLAN_STR*
with the arrays 'f64' and 'day' allocated to hold 'count' elements each.

Use Cldr_InsertInPlanYMD() or Cldr_InsertInPlan() for inserting data 
into an already allocated structure.

        typedef  PLAN_STR * PLANARRAY ;

,,EOT,,*/

typedef struct
{
    INTI      count ;
    INTI      filled ;
    DATEARRAY day ;
    FL64ARRAY f64 ;
}   PLAN_STR ;


/* PLAN_STR utilities */
#define GetPlanDay(plan)  (plan != NULL ? plan->day : NULL)
#define GetPlanF64(plan)  (plan != NULL ? plan->f64 : NULL)
#define GetPlanFill(plan) (plan != NULL ? plan->filled : 0)
#define GetPlanCount(plan) (plan != NULL ? plan->count : 0)

typedef  PLAN_STR * PLANARRAY ;

/*,,SOT,,

BUSDATERULE : Enum used to indicate business date rule of the calender attached
----------------------------------------------

BUSDATERULE is defined as:

typedef enum cal_bus_date_rule
{
DEFAULT,
BUSSPECIFIC
} BUSDATERULE;

DEFAULT - Indicates the calender attached is Defualt.
BUSSPECIFIC - indicates the calender attached is Business Specific.

,,EOT,,*/

/* PMSTA-22396 - SRIDHARA � 160525 - enum indicates business date rule of the calender*/
typedef enum cal_bus_date_rule
{
	DEFAULT,
	BUSSPECIFIC
} BUSDATERULE;

/*,,SOT,,

BUSCONSTFACTOR : Enum used to indicate if scale factor to be applied during cash flow generation
----------------------------------------------

BUSCONSTFACTOR is defined as:

typedef enum
{
ScaleFctRequired,
ScaleFctNotRequired
} BUSCONSTFACTOR;

ScaleFctNotRequired  - Indicates the Scale factor not to be applied.
ScaleFctRequired - Indicates the Scale factor to be applied.

,,EOT,,*/

/* PMSTA-40263-ARUN�20102020 - enum indicates if scale factor to be applied during cash flow generation or not*/

typedef enum
{
    ScaleFctRequired,
    ScaleFctNotRequired
} BUSCONSTFACTOR;

/*,,SOT,,

HOLI_STR : Struct for holding info on holidays
----------------------------------------------

HOLI_STR is defined as:

        typedef struct
        {
            BUSCONV   bus ;
            INTI      nholi ;
            DATEARRAY holidays ;
			BUSDATERULE		busi_date_rule;
        }   HOLI_STR ;

    bus informs on the business days adjustment convention

    nholi informs on the number of elements in holi

    holidays[nholi]|NULL is a list of ascendingly ordered non-weekend
        holidays. Set to NULL if nholi is 0. The list may be generated
        using Cldr_GenrHolidaysByRules().

		busi_date_rule  informs on the business date rule of the calender attached.

see also Set_HOLI_STR

,,EOT,,*/

typedef struct
{
    BUSCONV   bus ;
    INTI      nholi ;
    DATEARRAY holidays ;
	BUSDATERULE		busi_date_rule;   	/* PMSTA-22396 - SRIDHARA � 160525 */
    BUSCONSTFACTOR busi_const_fact; /*PMSTA-40263-ARUN-29102020*/
}   HOLI_STR ;

/*,,SOT,,

STEP_STR and STEPARRAY: Container for holding periodisation info
----------------------------------------------------------------

This type is defined as:

        typedef struct
        {
            INTI     dur ;
            TERMUNIT unit ;
            INTI     nstep ;
        }   STEP_STR ;

this type is used to signal how date periods is to be generated, the data
are interpreted as follows:

        dur      duration of the step

        unit     unit of the step

        nstep    number of annual steps in the period, or number of steps in
                 the period (depending on the context)

For handling lists over STEP_STR's use the type STEPARRAY defined as:

         typedef STEP_STR * STEPARRAY ;

,,EOT,,*/

typedef struct
{
    INTI     dur ;
    TERMUNIT unit ;
    INTI     nstep ;     /* # of ANNUAL steps in the period */
}   STEP_STR ;

typedef STEP_STR * STEPARRAY ;


/*,,SOT,,

PERIOD and PERIODARRAY: Type for defining a temporal period
-----------------------------------------------------------

This type is defined as:

        typedef struct period_tag
        {
            INTI     num ;
            TERMUNIT unit ;
        }   PERIOD ;

The data have the following interpretations:

        num     is the number of units in the period

        unit    is the term unit

Lists of PERIOD's are defined as:

        typedef PERIOD * PERIODARRAY ;

see also Set_PERIOD

,,EOT,,*/

typedef struct period_tag
{
    INTI     num ;
    TERMUNIT unit ;
}   PERIOD ;

typedef  PERIOD * PERIODARRAY ;


/*,,SOT,,

WEEKDAY : Unit of holiday offset quoting
----------------------------------------

WEEKDAY is used to quote the offsetting of days when genericly
defining holidays.
It is defined as:

        typedef enum weekday_tag
        {
            MONDAY,
            TUESDAY,
            WEDNESDAY,
            THURSDAY,
            FRIDAY,
            SATURDAY,
            SUNDAY,
            DAY
        } WEEKDAY ;

,,EOT,,*/

typedef enum weekday_tag
{
    MONDAY,
    TUESDAY,
    WEDNESDAY,
    THURSDAY,
    FRIDAY,
    SATURDAY,
    SUNDAY,
    DAY
} WEEKDAY ;


/*,,SOT,,

ANCHORDAY : Unit of holiday anchoring
-------------------------------------

ANCHORDAY is used to define anchor days when genericly
defining holidays.
It is defined as:

      typedef enum anchorday_tag
      {
          JANUARY_1,
          FEBRUARY_1,
          MARCH_1,
          APRIL_1,
          MAY_1,
          JUNE_1,
          JULY_1,
          AUGUST_1,
          SEPTEMBER_1,
          OCTOBER_1,
          NOVEMBER_1,
          DECEMBER_1,
          EASTER_SUN,
          PENTECOST_SUN,
          ADVENT_SUN1
      } ANCHORDAY ;

,,EOT,,*/

typedef enum anchorday_tag
{
    JANUARY_1,
    FEBRUARY_1,
    MARCH_1,
    APRIL_1,
    MAY_1,
    JUNE_1,
    JULY_1,
    AUGUST_1,
    SEPTEMBER_1,
    OCTOBER_1,
    NOVEMBER_1,
    DECEMBER_1,
    EASTER_SUN,
    PENTECOST_SUN,
    ADVENT_SUN1
} ANCHORDAY ;



/*,,SOT,,
HOLIRULE, HOLIRULEARRAY: Generic Holiday rules
----------------------------------------------

HOLIRULE is a struct for holding generic rules that decides
when holidays occur.

The type HOLIRULE is defined as

    typedef struct holirule_tag
    {
        INTI      term ;   
        WEEKDAY   unit ;   
        INTI      day ;   
        ANCHORDAY anchor ; 
        INTI      offset_sat ; 
        INTI      offset_sun ;
    } HOLIRULE;


    term        No. of weekdays relative to anchorday

    unit        Weekday unit

    day         Only used if anchor is either of JANUARY_1,
                FEBRUARY_1, ..., DECEMBER_1 and holds then the
                day of the month. Using day = 10 and anchor = JUNE_1
                implies that the anchorday is the June 10th.

    anchor      Anchor day. The holiday is relative to this day.

    offset_sat  Move holiday offset holiday if it falls on a saturday.

    offset_sun  offset holiday if it falls on a saturday.

    See also Set_HOLIRULE.

    Example settings:
   
       Holiday              Arguments for Set_HOLIRULE
       ---------------------------------------------------------
       New Years Holiday    1,  DAY,      1, JANUARY_1,     0, 0
       Good Friday          -2, DAY,      1, EASTER_SUN,    0, 0
       Easter Monday        2,  DAY,      1, EASTER_SUN,    0, 0
       Ascension            6,  THURSDAY, 1, EASTER_SUN,    0, 0
       Whit Monday          2,  DAY,      1, PENTECOST_SUN, 0, 0
       Christmas Day        25, DAY,      1, DECEMBER_1,    0, 0
    or
       Christmas Day        1,  DAY,     25, DECEMBER_1,    0, 0
       Summer Bank Holiday  1,  MONDAY,  25, AUGUST_1,      0, 0

  In some countries the New Years Day holiday is moved to the 
  following monday New Years Day falls on a weekend day. This is
  set by:

       New Years Holiday    1, DAY, 1, JANUARY_1, 2, 1


Lists of HOLIRULE's can be defined as:

    typedef HOLIRULE * HOLIRULEARRAY;

,,EOT,,*/

typedef struct holirule_tag
{
    INTI      term ;   
    WEEKDAY   unit ;   
    INTI      day ;   
    ANCHORDAY anchor ; 
    INTI      offset_sat ;
    INTI      offset_sun ;
} HOLIRULE;

typedef HOLIRULE * HOLIRULEARRAY;


/*** function prototyping (dateconv.c)  *********************************/


/* Public functions */

extern MMDD     Cldr_Date2md(DATESTR *date) ;
extern DATESTR  Cldr_YMD2Datestr(YYYYMMDD ymd) ;
extern YYYYMMDD Cldr_Datestr2YMD(DATESTR *date);



/*** function prototyping (dateadd.c)  **********************************/


/* Public functions */

extern DATESTR Cldr_AddDays(DATESTR *datein,
                            INTL    days,
                            CALCONV cal,
							HOLI_STR *holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */

extern INTL Cldr_DaysBetweenDates(DATESTR *datein1,
                                  DATESTR *datein2,
                                  CALCONV cal,
								  HOLI_STR *holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */

extern INTLARRAY Cldr_DaysBetweenDatesArray(DATESTR   *d,
                                DATEARRAY d2,
                                INTI      n,
                                CALCONV   cal,
								HOLI_STR *holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */

extern DATESTR Cldr_AddMonths(DATESTR *datein,
                              INTI    ms,
                              EOMCONV eom) ;

extern DATESTR Cldr_NextWeekday(DATESTR *datein,
                                INTI    w) ;

extern FL64 Cldr_DaysPerYear(DATESTR *date,
                               DATESTR *end,
                               INTI    m,
                               CALCONV cal,
                               EOMCONV eom,
							   HOLI_STR *holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */

extern DATESTR Cldr_TermUnit2Date(DATESTR  *today,
                                      INTI     term,
                                      TERMUNIT unit,
                                      CALCONV  cal,
                                      EOMCONV  eom,
                                      HOLI_STR *holi) ;

extern INTI Cldr_29FebCount(DATESTR *date1, DATESTR *date2) ;

extern PERIOD Set_PERIOD(INTI num, TERMUNIT unit) ;

/* Private functions */

extern INTI Cldr_Genr_Dates(DATESTR   *date1,
                                DATESTR   *date2,
                                INTI      add,
                                CALCONV   cal,
                                DATEARRAY dates,
                                ALIGNCONV align,
								HOLI_STR *holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */

extern INTI Cldr_Genr_Dates_Count(DATESTR *date1,
                                      DATESTR *date2,
                                      INTI    add,
                                      CALCONV cal,
									  HOLI_STR *holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */

extern DATEARRAY Cldr_Step2Dates(STEPARRAY step,
                                 INTI      nstep,
                                 DATESTR   *today,
                                 INTI      *ndays,
                                 CALCONV cal,
                                 EOMCONV eom,
                                 BOOLE    incl_today);


extern DATEARRAY Cldr_Steps2Dates(STEPARRAY steps,
                           INTI      nstep,
                           DATESTR*  today,
                           DATESTR*  lastm,
                           CALCONV   cal,
                           INTI*     ndates,
						   HOLI_STR *holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */

/*** function prototyping (cldr2trm.c)  *********************************/


/* Public functions */

extern FL64 Cldr_TermBetweenDates(DATESTR *dateIn1,
                                  DATESTR *dateIn2,
                                  INTI    qb,
                                  CALCONV cal,
                                  EOMCONV eom,
								  HOLI_STR *holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */

extern FL64ARRAY Cldr_Ymd2Terms(YYYYMMDD  date1,
                           INTI      count,
                           YMDARRAY  date2,
                           CALCONV   cal,
                           EOMCONV   eom,
                           INTI      qbas,
						   HOLI_STR *holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */

extern FL64ARRAY Cldr_Dates2Terms(DATESTR   *date1,
                             INTI      count,
                             DATEARRAY date2,
                             CALCONV   cal,
                             EOMCONV   eom,
                             INTI      qbas,
							 HOLI_STR *holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */

extern FL64ARRAY Cldr_ComputeTerms(DATESTR   *start,
                               INTI      count,
                               DATEARRAY days,
                               INTI      norig,
                               DATEARRAY origdays,
                               INTI      freq,
                               CALCONV   cal_per1,
                               CALCONV   cal_per2,
                               EOMCONV   eom,
							   HOLI_STR *holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */

extern DATESTR Cldr_Term2Date(DATESTR  *today,
                       FL64      dur,
                       TERMUNIT  unit,
                       CALCONV   cal,
                       EOMCONV   eom) ;


/* Private functions */

extern DATESTR Cldr_Years2Date(DATESTR* today,
                       FL64     years,
                       CALCONV  cal,
                       EOMCONV  eom) ;

/*** function prototyping (dateval.c)  **********************************/


/* Public functions */
extern INTI    Cldr_LastDayInMonth(INTI y,
                                   INTI m) ;

extern BOOLE   Cldr_CheckDate(DATESTR *date) ;

extern BOOLE   Cldr_IsNullDate(DATESTR *date) ;

extern INTL    Cldr_Date2Julian(DATESTR *date) ;

extern DATESTR Cldr_Julian2Date(INTL julian) ;

extern INTI    Cldr_Weekday(DATESTR *datein) ;

extern INTI    Cldr_WeekNumber(DATESTR *date) ;



/*** function prototyping (datecomp.c)  *********************************/


/* Public functions */

extern BOOLE Cldr_DateEQ(DATESTR *d1,
                         DATESTR *d2);

extern BOOLE Cldr_DateLT(DATESTR *d1,
                         DATESTR *d2);

extern BOOLE Cldr_DateLE(DATESTR *d1,
                         DATESTR *d2);

extern BOOLE Cldr_IsLeap(INTI y);

extern DATEARRAY Cldr_MergeDates(DATEARRAY dates1,
                                 INTI      n1,
                                 DATEARRAY dates2,
                                 INTI      n2,
                                 INTI      *nm) ;

extern INTI Cldr_FindDateIndex(DATEARRAY  dates,
                                INTI       count,
                                DATESTR    *basisdate,
                                INTI       start,
                                SEARCHCONV conv,
                                INDEXCONV  iconv) ;

extern INTI Cldr_FindTermIndex(FL64ARRAY  terms,
                                INTI       count,
                                FL64       basisterm,
                                INTI       start,
                                SEARCHCONV conv,
                                INDEXCONV  iconv) ;

extern void Cldr_DateSort(INTI n, DATEARRAY dates, SORTCONV sort) ;

extern INTI Cldr_InsertDate(DATEARRAY dates, INTI n, DATESTR *d, 
                               INTI *ix) ;

extern DATESTR Cldr_FindPrevTerm(DATESTR *today,
                                 DATESTR *pday,
                                 INTI    months,
                                 EOMCONV eom) ;

extern DATESTR Cldr_FindNextTerm(DATESTR *today,
                                 DATESTR *pday,
                                 INTI    months,
                                 EOMCONV eom) ;

extern DATEARRAY Cldr_UniqueDates(INTI n, DATEARRAY dates, 
                                     INTI *count) ;

/* Private functions */

extern void Cldr_AppendDate(DATEARRAY dates, INTI* n, 
                               DATEARRAY dates1, INTI n1, INTI* ix1);


/*** function prototyping (busidays.c)  *******************************/


/* Public functions */
extern BOOLE Cldr_IsBusinessDate(DATESTR   *date,
                                INTI      number,
                                DATEARRAY holidays) ;


/* PMSTA-22396 - SRIDHARA � 160525 */
BOOLE Cldr_IsBusinessDateHoliStr(DATESTR	*date,
								 HOLI_STR	*holi);

/* PMSTA-22396 - SRIDHARA � 160525 */
BOOLE Cldr_IsHoliDate(DATESTR   *date,
					  INTI      number,
					  DATEARRAY hday);

extern DATESTR Cldr_AddBusinessdays(DATESTR   *datein,
                                    INTL      days,
                                    INTI      number,
                                    DATEARRAY holidays,
                                    CALCONV   accrRule = ACTACT);

/* PMSTA-22396 - SRIDHARA � 160525 */
extern DATESTR Cldr_AddNextBusinessdays(DATESTR    *datein,
							  		    INTL       ds,
										HOLI_STR   *holi);

extern DATESTR Cldr_NextBusinessDate(DATESTR   *datein,
                                     HOLI_STR  *holi) ;

extern DATEARRAY Cldr_NextBusinessDateArray(DATEARRAY datein,
                                            INTI      n,
                                            HOLI_STR  *holi) ;

extern void Cldr_Move2BusinessDays(DATEARRAY datein,
                                   INTI      nd,
                                   HOLI_STR  *holi) ;

extern DATESTR Cldr_LastBusinessDay(DATESTR  *date,
                                    HOLI_STR *holi) ;

extern INTL Cldr_BusDaysBetweenDates(DATESTR   *date1,
                              DATESTR   *date2,
                              HOLI_STR  *holi) ;

extern DATEARRAY Cldr_FindDelvDays(DATESTR  *first,
                             DATESTR  *last,
                             INTI     gridstep,
                             CALCONV  cal,
                             HOLI_STR *holi,
                             INTI     *ndelv);


extern HOLI_STR Set_HOLI_STR(BUSCONV   bus,
                           INTI      nholi,
                           DATEARRAY holidays) ;

/* PMSTA-22396 - SRIDHARA � 160525 */
HOLI_STR Low_Set_HOLI_STR(BUSCONV bus,
						  INTI      nholi,
						  DATEARRAY holidays,
						  BUSDATERULE calType);

/* Private functions */


/*** function prototyping (immdays.c) ***********************************/


/* Public functions */
extern DATESTR Cldr_NextIMM(DATESTR *datein, BOOLE pseudo) ;
extern BOOLE   Cldr_DateIsIMM(DATESTR *datein, BOOLE pseudo) ;
extern DATESTR Cldr_IMMInMonth(DATESTR *datein) ;

extern DATESTR Cldr_NextCAD_BA(DATESTR *datein, BOOLE realCAD_BA) ;
extern BOOLE Cldr_DateIsCAD_BA(DATESTR *datein, BOOLE realCAD_BA) ;
extern DATESTR Cldr_CAD_BAInMonth(DATESTR *datein) ;

extern DATESTR Cldr_NextIMM_ZAR(DATESTR *datein, BOOLE realIMM) ;
extern BOOLE Cldr_DateIsIMM_ZAR(DATESTR *datein, BOOLE realIMM) ;
extern DATESTR Cldr_IMM_ZARInMonth(DATESTR *datein) ;

extern DATESTR Cldr_NextROLL(DATESTR  *in, 
                             SEQCONV  roll,
                             PERIOD   *per,
                             CALCONV  cal, 
                             EOMCONV  eom,
                             HOLI_STR *holi) ;



/*** function prototyping (cldraloc.c)  *********************************/


/* Public functions */

extern DATEARRAY  Alloc_DATEARRAY(INTI n) ;

extern void       Free_DATEARRAY(DATEARRAY date) ;

extern YMDARRAY   Alloc_YMDARRAY(INTI n) ;

extern void       Free_YMDARRAY(YMDARRAY date) ;

extern STEPARRAY Alloc_STEPARRAY(INTI n) ;

extern void Free_STEPARRAY(STEPARRAY step) ;

extern void Free_HOLI_STR(HOLI_STR *h) ;

extern HOLIRULEARRAY Alloc_HOLIRULEARRAY(INTI nh);

extern void Free_HOLIRULEARRAY(HOLIRULEARRAY v);

/*** function prototyping (holidays.c)  *********************************/


/* Public functions */

extern DATESTR Cldr_EasterSunday(INTI sYear) ;

extern DATESTR Cldr_Advent(INTI sYear) ;

extern DATEARRAY Cldr_GenrHolidaysByRules(INTI       start_year,
                                 INTI       end_year,
                                 HOLIRULEARRAY rules,
                                 INTI       nrules,
                                 BOOLE      weekend_incl,
                                 INTI*  n);

extern HOLIRULE Set_HOLIRULE(INTI      term,   
                                WEEKDAY   unit,   
                                INTI      day,   
                                ANCHORDAY anchor, 
                                INTI      offset_sat,
                                INTI      offset_sun);

/* Private functions */

extern DATESTR Cldr_DateByDays(INTI days,
                          DATESTR* anchor);

extern DATESTR Cldr_DateByWeekdays(INTI   n,       
                               WEEKDAY   w,       
                               DATESTR* anchor);

extern DATESTR Cldr_WeekendOffsetDays(INTI offset_sat,
                           INTI offset_sun,
                           DATESTR* day);

extern DATESTR Cldr_Anchorday2Datestr(INTI day, 
                                  ANCHORDAY anchorday,
                                  INTI      year);

/*** function prototyping (planaloc.c)  *********************************/


/* Public functions */

extern PLANARRAY  Alloc_PLANARRAY(INTI ns, INTI np) ;
extern void       Free_PLANARRAY(PLANARRAY s, INTI ns) ;

/* Private functions */
extern PLANARRAY  Alloc_PLAN(INTI ns) ;
extern void       Free_PLAN(PLANARRAY s) ;


/*** function prototyping (plan.c)  *************************************/


/* Public functions */
extern INTI Cldr_InsertInPlan(DATESTR   *date,
                                FL64      f64,
                                PLAN_STR  *plan,
                                BOOLE     override) ;

extern INTI Cldr_InsertInPlanYMD(YYYYMMDD date,
                                FL64      f64,
                                PLAN_STR  *plan,
                                BOOLE     override) ;

extern PLAN_STR Set_PLAN_STR(INTI      count,                
                                INTI      filled,               
                                DATEARRAY day,                  
                                FL64ARRAY f64);

extern PLAN_STR* Cldr_Holding2Amort(DATESTR   *start,
                                      DATESTR   *matur,
                                      PLAN_STR  *holding);

extern FL64 Cldr_PlanLookup(FL64      def,                
                               PLAN_STR* plan,               
                               DATESTR* day,
                               INTI*    ix);
                              

/* Private functions */
extern FL64 Cldr_Plan_Intpol(DATESTR *date, PLAN_STR *d, 
                                CALCONV cal, INTPOLCONV iconv,
								HOLI_STR *holi);  /* PMSTA-22396  - SRIDHARA - 160503 � new argument holi */

/*** function prototyping (period.c) ************************************/


/* Public functions */
extern BOOLE Cldr_PeriodST(PERIOD *p1, PERIOD *p2, DATESTR *d, 
                              HOLI_STR *holi, CALCONV cal, EOMCONV eom) ;

extern BOOLE Cldr_PeriodEQ(PERIOD *p1, PERIOD *p2, DATESTR *d, 
                              HOLI_STR *holi, CALCONV cal, EOMCONV eom) ;

extern BOOLE Cldr_PeriodSE(PERIOD *p1, PERIOD *p2, DATESTR *d, 
                              HOLI_STR *holi, CALCONV cal, EOMCONV eom) ;

extern INTL Cldr_DaysInPeriod(DATESTR *date, PERIOD *p, CALCONV cal,
                              EOMCONV eom, HOLI_STR *holi) ;

extern DATESTR Cldr_AddPeriod(DATESTR  *in,
                              PERIOD   *per,
                              CALCONV  cal,
                              EOMCONV  eom,
                              HOLI_STR *holi) ;

extern INTI Cldr_PeriodsBetweenDates(DATESTR  *first,
                                     DATESTR  *last,
                                     PERIOD   *per,
                                     CALCONV  cal,
                                     EOMCONV  eom,
                                     HOLI_STR *holi) ;

extern PERIODARRAY Alloc_PERIODARRAY(INTI n) ;

extern void Free_PERIODARRAY(PERIODARRAY v) ;

/* Private functions */


#ifdef __cplusplus
}
#endif

#endif

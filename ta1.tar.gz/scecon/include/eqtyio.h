/* SCID @(#)eqtyio.h	1.3 (SimCorp) 99/02/19 14:14:19 */

#ifndef EQTYIO_H
#define EQTYIO_H

/************************************************************************
*                                                                       *
*   project     SCecon                                                  *
*                                                                       *
*   file name   eqtyio.h                                                *
*                                                                       *
*   general     This file contains the header file for the example code *
*               in eqtyio.c                                             *
*                                                                       *
************************************************************************/

/*** includes **********************************************************/
#include <str2conv.h>
#include <futeqty.h>
#include <opteqty.h>

#ifdef __cplusplus
extern "C" {
#endif

/*** prototypes  *******************************************************/
extern FUTEQTY   Read_FUTEQTY(FILE *in, FILE *out) ;
extern FUTCMDTY  Read_FUTCMDTY(FILE *in, FILE *out) ;
extern FXFORW    Read_FXFORW(FILE *in, FILE *out) ;

extern TREEOPT   Read_TREEOPT(FILE *in, FILE *out) ;

#ifdef __cplusplus
}

#endif

#endif





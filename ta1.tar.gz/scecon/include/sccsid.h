#ifndef SCCSID_H
#define SCCSID_H

/* This file sets the macros 'SCANSI' and 'SCCSID' according to the
 * type of compiler. This file can be used with ANSI as well as K&R C
 * compilers.
 */

  /* Check ANSI conformance:
   *
   * The 'SCANSI' macro is a SimCorp invention that tells us if the
   * compiler is ANSI compatible. If a compiler understands ANSI
   * prototyping and offers the ANSI library functions this define
   * should be set. It does not imply that the compiler is true ANSI nor
   * that it understands nothing but the ANSI dialect.
   *
   * So this define should be set for most of our compilers. Only the
   * few stone age K&R compilers should not have this define. If the
   * compiler is C++ or true ANSI it will be recognised by this file.
   * Otherwise compile with '-DSCANSI'.
   */

#if defined(SCANSI)
   /* Claims to be ANSI (this file is probably compiled with '-DSCANSI')
    */
#else
#  if defined(__STDC__) || defined(__cplusplus)
     /* OK it is ANSI or C++, but tell SimCorp too:
      */
#    define SCANSI
#  else
     /* This is non ANSI C:
      */
#  endif
#endif


  /* Setting SCCS IDs into include and source files without warnings
   * (whenever possible) and without polluting the global namespace
   * unnecessarily. The SCCS IDs are expanded only if 'NSCCSID' has not
   * been defined. This is important in order to save space in
   * executable files (it is most important on Windows 16-bit
   * platforms):
   */

#if defined(NSCCSID)
   /* We want no SCCS footprints:
    */
#  define SCCSID(a,b)
#else
#  if defined(SCANSI)
     /* The compiler accepts (requires) prototypes
      */
#    define SCCSID(a,b) \
  static char ** a(void); \
  static char ** a(void) { \
    static int first=1; \
    *(a())=b; \
    if(first) { first=0; return a(); } \
    return((char **)0); \
  }
    /* This sets the SCCSID string, 'b', into a file in the form of a
     * string constant inside the static function, 'a()'. A warning on
     * the unused 'a()' function with internal linkage is avoided
     * because the address of 'a()' is taken inside 'a()'. Warnings
     * for infinite loops are avoided with the 'first' variable. Kinkier
     * solutions checking for a certain bit or something to avoid the
     * declaration of 'first' were dropped - due to kink of course.
     */
#  else
     /* The compiler does not accept prototypes:
      */
#    define SCCSID(a,b) \
  static char ** a(); \
  static char ** a() { \
    static int first=1; \
    *(a())=b; \
    if(first) { first=0; return a(); } \
    return((char **)0); \
  }
#  endif
#endif

/*
SCCSID(sccsid_h,
  "@(#)sccsid.h	1.1 (SimCorp) 97/06/25 15:57:19")
*/

#endif
  /* SCCSID
   */

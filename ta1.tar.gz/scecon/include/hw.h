/* SCCS: @(#)hw.h	1.39 (SimCorp) 99/11/01 11:30:18 */

#ifndef HW_H_INCLUDED

#define HW_H_INCLUDED

/***********************************************************************
*                                                                      *
*   project    SCecon                                                  *
*                                                                      *
*   filename   hw.h                                                    *
*                                                                      *
*   this file contains definitions and function prototyping for the    *
*   routines in the SCecon Term Structure model module.                *
*                                                                      *
***********************************************************************/

/** includes **********************************************************/
#include <cap.h>
#include <tvm.h>
#include <scenario.h>

/** C++ convenience ***************************************************/
#ifdef __cplusplus
extern "C" {
#endif

/** typedefs **********************************************************/

/*,,SOT,,

HWFITVOLCTRL: Type for controling fitting vol to swaptions
----------------------------------------------------------

This type is defined as

        typedef struct hwfitvolctrl_tag
        {
            INTI  days ;
            BOOLE use_optmatur;
            BOOLE all_in_one;
            BOOLE optimize;
        }   HWFITVOLCTRL ;

Where:

        days          The band (in actual days) that defines
                      each maturity bucket. 
                      Only used if all_in_one is False.

        use_optmatur  The volatility structure is constructed
                      on option maturity dates if this is True.
                      Otherwise, the final swap maturity dates, ie
                      option maturity plus the swap period, is used

        all_in_one    All volatilities are bootstrapped in a single
                      run if this is set to True. 
                      Otherwise, each volatility is bootstrapped
                      and adjusted. This is relevant when there
                      more than one swaption with option maturity
                      (or final maturity) to each volatility date.

        optimize      This is only used if all_in_one is set to True.
                      After bootstrapping the entire volatility 
                      structure a multivariate optimisation is
                      done to fine-tune the volatilities, if 
                      optimize is set to True.
                      Otherwise, the bootstrapped volatilities
                      are simply returned.

Using swaptions a la 1x9 2x8 3x7 4x6 yields four dates when 
use_optmatur is True, but only a single date if use_optmatur is False.

Using optimize = True will increase run-time substantially, and
in most cases the fit obtained setting optimize to False will
be sufficiently good.

,,EOT,,*/

typedef struct hwfitvolctrl_tag
{
    INTI  days ;
    BOOLE use_optmatur;
    BOOLE all_in_one;
    BOOLE optimize;
}   HWFITVOLCTRL ;


/*,,SOT,,

HWCFPARMS: Type for holding info on Hull & White Closed-Form model
------------------------------------------------------------------

This type is defined as

        typedef struct hwcfparms_tag
        {
            FL64 a ;
            FL64 sigma ;
        }   HWCFPARMS ;

Where:

        a is the mean reversion parameter. The order of magnitude is
        typically 0.1.

        sigma is the standard deviation of absolute short rate changes.
        Order of magnitude is typically 0.01.

in a term structure model, where short rates evolve as:

        d(r) = (h(t) - a * r) * d(t) + sigma * dw

this model is characterized as having closed form solution for VANILLA
European-Style option's (see - sec_HWCF2*() functions).

,,EOT,,*/

typedef struct hwcfparms_tag
{
    FL64 a ;
    FL64 sigma ;
}   HWCFPARMS ;



/*,,SOT,,

HWCFDIFF: Model parameters for pricing Diff Swaps using Hull & White
--------------------------------------------------------------------

This type is defined as:

        typedef struct hwcfdiff_tag
        {
            HWCFPARMS hwc_d ;
            HWCFPARMS hwc_f ;
            FL64      vol_FX ;
            FL64      corr_df ;
            FL64      corr_FX ;
        }   HWCFDIFF ;

where
        hwc_d is the model parameters for the domestic interest rate
        proces

        hwc_f is the model parameters for the foreign interest rate
        proces

        vol_FX is the (log) volatility of the FX rate (between foreign
        and domestic currencies) - quoted as percentage (15.0 for 15%)

        corr_df is the correlation between the 2 interest rate processes
        in the 2 currencies

        corr_FX is the correlation between the foreign interest rate and
        the FX rate.

The type is used for pricing differential swaps using the Hull & White
model developed by Jason Wei.

,,EOT,,*/

typedef struct hwcfdiff_tag
{
    HWCFPARMS hwc_d ;
    HWCFPARMS hwc_f ;
    FL64      vol_FX ;
    FL64      corr_df ;
    FL64      corr_FX ;
}   HWCFDIFF ;



/*,,SOT,,

HWFUNC: Stochastic differential equation formulation
----------------------------------------------------

This type is defined as:

        typedef enum hwfunc_tag
        {
            HW_LINEAR,
            HW_SQRT,
            HW_LOG
        }   HWFUNC ;

the type is used to identify how 1-factor stochastic differential
equations are formulated.

        HW_LINEAR identifies a function f(r) = r

        HW_SQRT identifies a function f(r) = sqrt(r)

        HW_LOG identifies a function f(r) = ln(r)

,,EOT,,*/

typedef enum hwfunc_tag
{
    HW_LINEAR,
    HW_SQRT,
    HW_LOG
}   HWFUNC ;


/*,,SOT,,

HWFIXPARM: Identification of proces type
----------------------------------------

This type is defined as:

        typedef enum hwfixparm_tag
        {
            HW_BDT,
            HW_NOFIX,
            HW_AFIX,
            HW_BOTHFIX
        }   HWFIXPARM ;

the type is used to identify the 1-factor stochastic differential model
type.  HWFIXPARM relates to the definition of the drift term. Generally
the drift term can be defined as:

        drift(r, t) = ( theta(t) + phi(t) * g(r) ) * dt

here g(r) can be defined via a HWFUNC type, and

        HW_BDT identifies a BDT type proces, i.e. where phi is
        determined by the spot volatilities and theta by the
        zero-coupon discount factors.
        However, phi and the short rate volatility are linked.

        HW_NOFIX identifies a proces where neither of the 2 parts of
        the drift element are fixed - i.e. are to be determined by the
        zero-coupon discount factors (theta) and the spot volatilities
        (phi)

        HW_AFIX identifies a proces with fixed mean reversion term
        (phi), and the first part of the drift (theta) is determined
        by the zero-coupon discount factors

        HW_BOTHFIX identifies a proces with a fixed drift term, so both
        parameters (theta, phi) are given elsewhere. This is equivalent
        to handling the equilibrium type of models like the original
        CIR, Vasicek etc, where parameteres are constant.

,,EOT,,*/

typedef enum hwfixparm_tag
{
    HW_BDT,
    HW_NOFIX,
    HW_AFIX,
    HW_BOTHFIX
}   HWFIXPARM ;


/*,,SOT,,

HWPARMS: Identification of 1-factor interest rate proces parameters
-------------------------------------------------------------------

This type is defined as:

        typedef struct hwparms_tag
        {
            HWFIXPARM fixp ;
            FL64      theta ;
            FL64      phi ;
            FL64      beta ;
            FL64      sigma ;
            HWFUNC    meanrev ;
            HWFUNC    dfr ;
            BOOLE     sigma_fix ;
            BOOLE     cal_simpl ;
            FL64      chg_time ;
            CALCONV   cal ;
            STEPARRAY step ;
            INTI      nstep ;
            BOOLE     useCF ;
        }   HWPARMS ;

these parameters identify the 1-factor stochastic differential model
type. In general a proces can be defined as:

        d(f(r))     = drift(t, r) + vol(t, r)

        drift(r, t) = ( theta(t) + phi(t) * g(r) ) * dt

        vol(t, r)   = sigma * pow(r, beta) * dZ

the data in HWPARMS are used as follows:

        fixp defines the proces type

        theta is equal to theta(t) if used (i.e. steady state level)

        phi is equal to phi(t) if used (i.e mean reversion).
        Mean reversion is achieved with phi > 0 whereas mean 
        aversion is achieved with phi < 0. If phi is zero then
        cal_simple is automatically interpreted as False.

        beta is the elasticity of the forward vol wrt the interest rate

        sigma is the forward volatility, must be > 0

        meanrev is the function g(r)

        dfr is the function f(r) - for practical purposes choose the
        same as g(r)

        if sigma_fix is True then sigma is used as entered. If it is
        False then sigma is calculated from the spot volatility curve
        defined elsewhere. Often  this is the preferred (default) approach.

        if cal_simpl is True and the proces is of type HW_AFIX then a
        quick calibration routine is used. Otherwise the usual routine
        is used.  It is here needed that meanrev and dfr are HW_LINEAR
        and beta must be 0. For speed purposes always use cal_simpl as
        True.

        if cal_simpl is True then shifting from normal to non-normal
        branching is done at time chg_time. For simplicity use chg_time
        as 0.0, since branching will then automatically be changed
        whenever possible. If phi is zero then cal_simple is
        automatically interpreted as False.

        cal is the calendar convention for defining the terms / rates in
        the tree. Use the most relevant for the actual security setup,
        e.g. ACT/360 for US-Caps. However, when the tree data has been
        bootstrapped using Fit_Cap2HWVol() etc, then hw->cal should be
        the same for pricing and bootstrapping (use the most normal -
        ACT360).  Note that the calendar will influence the pricing
        since the interest rate proces is a different one. However the
        influence is usually of minor importance.

        step[nstep] is the discretization description. Steps must be increasing
        over time. In general avoid changing step sizes more often than
        needed, usually 2-3 categories are sufficient. When fixp is
        HW_BDT then steps must be constant.
        Also remember to have steps all the way out till security
        maturity (including the length of any underlying index like
        CMT).
        Note that steps smaller than 1 day is NOT allowed.
        Note that each STEP_STR in step holds the number of ANNUAL steps 
        in the period - not the number steps in the period. For daily 
        steps in one month use {1, MONTHS, 365} - this means 365 annual 
        steps implying approx. 30 steps in one month.

        nstep is the number of elements in step.

        if useCF is True then the pricing routines will try and find the
        instrument PV by using closed-formulae (e.g. the Hull & White
        solutions).

note that some limitations must be observed.

        If dfr is not HW_LINEAR then beta must be 0.

        If beta = 0, i.e. a normal proces, then g(r) must be HW_LINEAR

        If cal_simpl is True then dfr and meanrev can only be HW_LINEAR,
        and beta must be 0.

using the framework described here a large number of term structure
models can be formulated - including BDT, Vasicek, Extended Vasicek,
Ho & Lee, Ho & Lee with mean reversion (Hull & White), Black & Karasinsky,
CIR, Extended CIR, Courtadon, general 1-factor models and others yet
to be named.

The definitions for specific processes are:

        BDT:
            Data:
            fixp        HW_BDT
            theta       not used
            phi         not used
            beta        not used
            sigma       not used
            meanrev     not used
            dfr         not used
            sigma_fix   not used
            cal_simpl   not used
            chg_time    not used
            cal         'as specified'
            step        'as specified'
            nstep       should be 1 (only one constant stepsize)

        Vasicek:
            Data:
            fixp        HW_BOTHFIX
            theta       'as specified'
            phi         'as specified'
            beta        0.0 ;
            sigma       'as specified'
            meanrev     HW_LINEAR
            dfr         HW_LINEAR
            sigma_fix   'as specified'
            cal_simpl   not used
            chg_time    not used
            cal         'as specified'
            step        'as specified'
            nstep       'as specified'

        Extended Vasicek:
        Hull & White:
            Data:
            fixp        HW_AFIX
            theta       not used
            phi         'as specified'  (sometime called 'a')
            beta        0.0
            sigma       'as specified'
            meanrev     HW_LINEAR
            dfr         HW_LINEAR
            sigma_fix   'as specified'
            cal_simpl   True (as default)
            chg_time    0.0 (as default)
            cal         'as specified'
            step        'as specified'
            nstep       'as specified'
            useCF       True

        Ho/Lee:
            Data:
            fixp        HW_AFIX
            theta       not used
            phi         0.0
            beta        0.0
            sigma       'as specified'
            meanrev     HW_LINEAR
            dfr         HW_LINEAR
            sigma_fix   'as specified'
            cal_simpl   True (as default)
            chg_time    0.0 (as default)
            cal         'as specified'
            step        'as specified'
            nstep       'as specified'
            useCF       True

        Black & Karasinski:
            Data:
            fixp        HW_NOFIX
            theta       not used
            phi         not used
            beta        0.0
            sigma       'as specified'
            meanrev     HW_LOG
            dfr         HW_LOG
            sigma_fix   'as specified'
            cal_simpl   not used
            chg_time    not used
            cal         'as specified'
            step        'as specified'
            nstep       'as specified'

        CIR:
            Data:
            fixp        HW_BOTHFIX
            theta       'as specified'
            phi         'as specified'
            beta        0.5
            sigma       'as specified'
            meanrev     HW_LINEAR
            dfr         HW_LINEAR
            sigma_fix   'as specified'
            cal_simpl   not used
            chg_time    not used
            cal         'as specified'
            step        'as specified'
            nstep       'as specified'

        Extended CIR (I):
            Data:
            fixp        HW_NOFIX
            theta       not used
            phi         not used
            beta        0.5
            sigma       'as specified'
            meanrev     HW_LINEAR
            dfr         HW_LINEAR
            sigma_fix   'as specified'
            cal_simpl   not used
            chg_time    not used
            cal         'as specified'
            step        'as specified'
            nstep       'as specified'

        Extended CIR (II):
            Data:
            fixp        HW_NOFIX
            theta       not used
            phi         not used
            beta        0.0
            sigma       'as specified'
            meanrev     HW_SQRT
            dfr         HW_SQRT
            sigma_fix   'as specified'
            cal_simpl   True (as default)
            chg_time    0.0 (as default)
            cal         'as specified'
            step        'as specified'
            nstep       'as specified'

        Courtadon (Lognormal proces):
            Data:
            fixp        HW_NOFIX
            theta       not used
            phi         not used
            beta        1.0
            sigma       'as specified'
            meanrev     HW_LINEAR
            dfr         HW_LINEAR
            sigma_fix   'as specified'
            cal_simpl   not used
            chg_time    not used
            cal         'as specified'
            step        'as specified'
            nstep       'as specified'

etc...

see also Set_HWPARMS

References to the theory of trinomial trees for 1-factor interest rate
processes are (amongst many):

J. Hull & A. White:
One-factor interest rate models and the valuation of interest rate 
derivative securities.
J. of Financial and Quantitative Analysis, vol.28, 1993, pp. 235-254

J. Hull & A. White:
Numerical procedures for implementing term structure models I: Single-Factor
models.
J. of Derivatives, Fall 1994, p 7-16

,,EOT,,*/

typedef struct hwparms_tag
{
    HWFIXPARM fixp ;
    FL64      theta ;
    FL64      phi ;
    FL64      beta ;
    FL64      sigma ;
    HWFUNC    meanrev ;
    HWFUNC    dfr ;
    BOOLE     sigma_fix ;
    BOOLE     cal_simpl ;
    FL64      chg_time ;
    CALCONV   cal ;
    STEPARRAY step ;
    INTI      nstep ;
    BOOLE     useCF ;
}   HWPARMS ;


/*,,SOT,,

NODEINFO: Container for holding trinomial tree node info
--------------------------------------------------------

This type is defined as:

        typedef struct
        {
            INTI    off ;
            FL64    disc ;
            FL64    r ;
            INTI    to ;
            INTI    toix ;
            FL64    p1 ;
            FL64    p3 ;
            FL64    qu ;
            FL64    qd ;
        }   NODEINFO ;

basically this is an internal variable, set in Clb_HW2Tree(), and used
in the hw-pricers.

However, the definition is as follows:

        off      The offset of the node (from the 0 node)
        disc     The discount factor at the node til next node
        r        Annual rates are in fractions - not %
        to       Emanating to ..(middle node).. relative to 0
        toix     Emanating to ..(middle node).. as direct index
        p1       Upper branch probability
        p3       Lower branch probability
        qu       Upper branch Arrow-Debreu price
        qd       Lower branch Arrow-Debreu price - only used in
                 TSOV-model

if qd are not set then qu is to be interpreted as Arrow-Debreu prices
relative to 'today' - i.e. the first step in the trinomial tree.
Otherwise qu/qd are relative to the second step in the trinomial tree

,,EOT,,*/

typedef struct
{
    INTI    off ;    /* The offset of the node (from the 0 node) */
    FL64    disc ;   /* The discount factor at the node til next node */
    FL64    r ;      /* Annual rates are in fractions - not % - if */
                     /*  level = 0, r = r0, and if level = 1, r = ru */
             /*  or rd */
    INTI    to ;     /* Emanating to ..(middle node).. relative to 0 */
    INTI    toix ;   /* Emanating to ..(middle node).. as direct */
                     /*  index */
    FL64    p1 ;     /* Upper branch */
    FL64    p3 ;     /* Lower branch */
    FL64    qu ;
    FL64    qd ;     /* Only used in TSOV-model */
}   NODEINFO ;


/*,,SOT,,

LEVELINFO: Container for holding trinomial tree level info
----------------------------------------------------------

This type is defined as:

        typedef struct
        {
            FL64     time ;
            DATESTR  date ;
            INTI     nnode ;
            NODEINFO *node ;
        }   LEVELINFO ;

basically this is an internal variable, set in Clb_HW2Tree(), and used
in the hw-pricers.

However, the definition is as follows:

        time     Term for the level
        date     Date of the level
        nnode    Number of node at the level
        node     pointer to the nodes, that are used in a UNIT offset
                 fashion.

,,EOT,,*/

typedef struct
{
    FL64     time ;
    DATESTR  date ;
    INTI     nnode ;
    NODEINFO *node ;
}   LEVELINFO ;


/*,,SOT,,

HWTREE: Container for holding a trinomial interest rate tree
------------------------------------------------------------

This type is defined as:

        typedef struct
        {
            CALCONV   cal ;
            BOOLE     use_qd ;
            INTI      nlevel ;
            LEVELINFO *level ;
        }   HWTREE ;

this structs hold an entire trinomial tree for simulating a stochastic
proces.  The struct is set and allocated in Clb_HW2Tree() and used in
the hw-pricers.

The individual data has the following interpretation:

        cal      the calendar convention used

        use_qd   are level[i].node[j].qd set ?

        nlevel   total number of levels, the levles are counted as:
                 0, 1, 2, ...., nlevel

        level    pointer to the list of levels (0, 1, ...., nlevel)

,,EOT,,*/

typedef struct
{
    CALCONV   cal ;
    BOOLE     use_qd ;   /* True if qd is used, i.e. HW_NOFIX */
    INTI      nlevel ;   /* counted as 0, 1, ...., nlevel */
    LEVELINFO *level ;   /* Zero offset array */
}   HWTREE ;


/*,,SOT,,

HW_ERR: Trinomial tree calibration status indicator
---------------------------------------------------

This type is defined as:

        typedef enum hw_err_tag
        {
            HW_ALL_OK,
            HW_LEVEL_ALLOCERR,
            HW_NODE_ALLOCERR,
            HW_TOO_MANY_NODES,
            HW_TOO_MANY_LEVELS,
            HW_NEGATIVE_RATE,
            HW_NEGATIVE_VOL,
            HW_TOO_MANY_ITER,
            HW_SINGULAR_EQS,
            HW_BADPROB,
            HW_BOOT_ERR
        }   HW_ERR ;

when calling Clb_HW2Tree() a return code of type HW_ERR indicates how
the calibration terminated. If HW_ALL_OK is returned then the tree is
calibrated and can be used for other purposes. If not something went
wrong, all memory is freed and the HWTREE pointer cannot be used for
anything. The various error codes speak for themselves. The reason for
an error may lie in the input data, or sometimes in defines on maximum
number of levels or nodes.

Currently a maximum of 200 levels and 300 nodes are used.

,,EOT,,*/

typedef enum hw_err_tag
{
    HW_ALL_OK,
    HW_LEVEL_ALLOCERR,
    HW_NODE_ALLOCERR,
    HW_TOO_MANY_NODES,
    HW_TOO_MANY_LEVELS,
    HW_NEGATIVE_RATE,
    HW_NEGATIVE_VOL,
    HW_TOO_MANY_ITER,
    HW_SINGULAR_EQS,
    HW_BADPROB,
    HW_BOOT_ERR
}   HW_ERR ;


/*,,SOT,,

DEBTOR, DEBTORARRAY : Type for holding debtor info
--------------------------------------------------

DEBTOR is a type for holding loangroup (debtor) info, and is defined as:

        typedef struct
        {
            FL64  weight ;
            FL64  tax ;
            FL64  cost ;
            BOOLE strike_first ;
            BOOLE netpmt ;
            FL64  premium ;
            FL64  stdev ;
            FL64  maturfac ;
            FL64  mixpct ;
            FL64  krate ;
            FL64  newmix ;
            FL64  matur ;
        }   DEBTOR ;

this type is used for valuing Danish Mortgage Backed Securities (DKMBS).

        Weight is the relative weight of the debtor group - the whole
        loan is a combination of a number of loans (the weights must
        sum to 1 or less)

        Tax is the tax rate in fractions (typically 0, 0.34 or 0.5).

        cost is the fractional relative amount needed to call the loan
        (fees for intermediates). A fractional number (e.g. 0.02 for
        2%).

        strike_first indicates (by TRUE/FALSE), how the debtors call -
        first or optimally.

        netpmt indicates NPV or liquidity preferences, True means
        liquidity

        premium is the excess profit (after costs) needed to call.
        Entered in percentage terms.

        stdev is the standard deviation of premium. Assuming the Svend
        Jakobsen model. Percentage term.

        maturfac is a factor on maturity - again assuming the Svend
        Jakobsen type of prepayment model (default is 0)

        mixpct is a fractional number between 0 and 1 (1 for annuities
        and 0 for serials, indicating the annuity percentage of the old
        loan

        krate is the loan rate (cashrate) in percent of the old loan.

        newmix is the mixpercentage of the new loan - only needed if
        netpmt == True. Enter a number between 0 and 1.

        matur is the maturity of the new loan - only needed if
        netpmt == True

for a list of debtors use the type DEBTORARRAY defined as:

        typedef DEBTOR * DEBTORARRAY ;

See the routine DKmbs_KFDEBTOR2DEBTOR() for a routine that generates
this struct from KF (Copenhagen Stock Exchange) type of data.

,,EOT,,*/

typedef struct
{
    FL64 weight ;
    FL64 tax ;
    FL64 cost ;
    BOOLE strike_first ;
    BOOLE netpmt ;
    FL64 premium ;
    FL64 stdev ;
    FL64 maturfac ;
    FL64 mixpct ;
    FL64 krate ;
    FL64 newmix ;
    FL64 matur ;
}   DEBTOR ;

typedef DEBTOR * DEBTORARRAY ;


/*,,SOT,,

KFDEBTOR, KFDEBTORARRAY: Type for Copenhagen Stock Exchange Debtor data
-----------------------------------------------------------------------

The type is defined as

        typedef struct kfdebtor_tag
        {
            CH   Group ;
            INTI IntVal ;
            FL64 BondOut ;
            FL64 CashOut ;
            FL64 CashRate ;
        }   KFDEBTOR ;

where

        Group is the group type ('A', 'B', 'C')

        IntVal is the debtor interval (1, 2, 3, 4 ,5)

        BondOut is the Outstanding 'Nominal Loan' amount

        CashOut is the Outstanding 'Cash Loan' amount

        CashRate is the debtor side interest (coupon), which for
        cashloan is larger than the bond coupon.


These data (plus more) are published frequently by danish data vendors
for the whole range of Danish Mortgage-Backed Securities.


See the routine DKmbs_KFDEBTOR2DEBTOR() for a routine that generates the
DEBTOR struct from KF (Copenhagen Stock Exchange) type of data.


For a list of debtors use the type KFDEBTORARRAY defined as:

        typedef KFDEBTOR * KFDEBTORARRAY ;

,,EOT,,*/

typedef struct kfdebtor_tag
{
    CH   Group ;
    INTI IntVal ;
    FL64 BondOut ;
    FL64 CashOut ;
    FL64 CashRate ;
}   KFDEBTOR ;

typedef KFDEBTOR * KFDEBTORARRAY ;


/*,,SOT,,

NCSWAPTION : Type for holding info on Non-Concurrent Swaptions
--------------------------------------------------------------

This type is defined as:

        typedef struct ncswaption_tag
        {
            OPTTYPE   type ;
            BOOLE     berm ;
            PAYDAYDEF eday ;
            PERIOD    delay ;
            PERIOD    swapdur ;
            SWAPFIX   swapfix ;
            BOOLE     vanilla ;
            SWAPFLOAT swapfl ;
        }   NCSWAPTION ;

This data type is used to handle US/Bermudan-Style Non-Concurrent Swap
Options, i.e. options on swaps where the swap terms are fixed upon
exercise.

The data have the following interpretation:

        type defines the option type. The definitions imply that:

            CALL - Receiver Swaption - i.e. option on swap receiving
                   fixed
            PUT  - Payer Swaption    - i.e. option on swap paying fixed
            STRADDLE - Payer and Receiver

        Note that straddles are implemented as a single contract when
        dealing with US-Style options - i.e. either a PUT or a CALL.
        If it is really 2, then call the relevant routine twice, with
        PUT and CALL definitions for US-Style options.

        berm is True if the exercise dates are discretely spaced. False
        if US-Style, i.e. continuous exercising possibility. Note that
        in a tree based valuation (E.g. HW pricers), the US-Style
        exercise is only as fine as the grid spacing in the tree.

        eday defines the exercise dates. If berm is True then all data
        are used to define the days. If berm is False, then only
        eday.first and eday.last are used.

        delay defines the fixing delay - i.e. how long a period passes
        from the exercise decision till the swap is entered into (or
        cash is settled).

        swapdur is the definition of the swaps duration (upon exercise).

        swapfix is the definition of the fixed side of the swap.
        Supported features as in SwapFix_GenrCflw().
        In the repayment definition (.repay) repay.teomatur is not used.
        In the payday definitions (.rday, .pday) only the payday 
        sequencing (.rday.pseq, .pday.pseq) are used.
        In the coupon definition (.fix) .fix.effective, is not used. 
        .fix.stepcoup holds an optional stepped strike. An entry in the
        .fix.stepcoup structure indicates a strike rate from the
        specified date (inclusive) to the next entry (exclusive).
        Prior to the first date, .fix.fix_rate is the strike rate.

        vanilla defines whether the floating side is vanilla or not.
        If True then the floating leg values to 100 when the float side is
        issued, and swapfl is not used.
        If False then the floating side does not value to 100, and swapfloat
        is used to find the float value.

        swapfloat os the definition of the floating side of the swap.
        Supported features as in SwapFl_GenrCflw()
        In the repayment definition (.repay) repay.teomatur is not used.
        The amortising profile (.repay.type) has to be either BULLET, SERIAL, 
        or NONREGULAR.
        In the payday definitions (.rday, .pday) only the payday 
        sequencing (.rday.pseq, .pday.pseq) are used.
        In .float1.fbase, only .cal and .spread are used.

,,EOT,,*/

typedef struct ncswaption_tag
{
    OPTTYPE   type ;
    BOOLE     berm ;
    PAYDAYDEF eday ;
    PERIOD    delay ;
    PERIOD    swapdur ;
    SWAPFIX   swapfix ;
    BOOLE     vanilla ;
    SWAPFLOAT swapfl ;
}   NCSWAPTION ;


/*,,SOT,,

CCSWAPTION : Type for defining Bermudan-Style Concurrent Swaptions
------------------------------------------------------------------

This type is defined as:

        typedef struct ccswaption_tag
        {
            OPTTYPE   type ;
            PAYDAYDEF eday ;
            PERIOD    delay ;
            BOOLE     accrued ;
            SWAPFIX   swapfix ;
            BOOLE     vanilla ;
            SWAPFLOAT swapfl ;
        }   CCSWAPTION ;

The type is used to define the option element of cancelable or
extendible swaps. The options have Bermudan-style exercise.  
The swaps can be quite general, e.g. forward starting, or have 
stepped coupon plan. The swap terms are known in advance; hence the term
concurrent swap.

The data have the following interpretation:

        type defines the option type. The definitions imply that:

            CALL - Receiver Swaption - i.e. option on swap receiving
                   fixed. 
                   In a cancelable swap it gives the fixed side payer
                   the opportunity to switch to floating payments.
                   In an extendible swap it gives the floating side payer the
                   opportunity to extend the swap.
            PUT  - Payer Swaption - i.e. option on swap paying fixed
                   In a cancelable swap it gives the floating side payer
                   the opportunity to switch to fixed payments.
                   In an extendible swap it gives the fixed side payer the
                   opportunity to extend the swap.

            STRADDLE - Implemented as a single contract, i.e. 
                   either a PUT or a CALL. If it is really two then call the 
                   relevant routine twice using the relevant PUT and CALL 
                   definitions.

        eday defines the exercise days for the option. Typically these
        would be on the fixed side pay-days - since the fixed side payer 
        typically holds the option to cancel. However, sometimes the swap 
        can be cancelled prior to the first paydate, which should then be
        reflected in the eday settings.

        delay is the fixing delay, i.e. the period from exercising the
        option until the swap is extended/cancelled. The period is typically
        2-5 days.

        accrued should be True if the option is exercised on clean fixed and
        floating leg prices. Use False for exercise on dirty prices.
        NOTE that accrued = True should be used with care as it is very 
        time-consuming to keep tract of floating leg accrued interest.
        So accrued = True should only be used if the exercise days are
        truly different from swap paydays.

        swapfix is the definition of the fixed side of the swap.
        Supported features as in SwapFix_GenrCflw().

        If vanilla is True then the value of the floating leg is 100
        at all fixing days and the contents of swapfl is ignored.
        In this case the paydays of the floating side will be the same as the
        fixed side.
           
        swapfl is the definition of the floating side of the swap.
        Compounding, averaging, stepped factors and stepped spreads 
        (float1.method, float1.compfreq, float1.avgfl, float1.stepspr, 
        float1.stepfac) are NOT supported.

        It is recommended that the effective days of the legs are 
        similar.

,,EOT,,*/

typedef struct ccswaption_tag
{
    OPTTYPE   type ;
    PAYDAYDEF eday ;
    PERIOD    delay ;
    BOOLE     accrued ;
    SWAPFIX   swapfix ;
    BOOLE     vanilla ;
    SWAPFLOAT swapfl ;
}   CCSWAPTION ;


/*,,SOT,,

USBONDOPT: Type for defining American/Bermudan-Style Bond Options
-----------------------------------------------------------------

This type is defined as:

        typedef struct usbondopt_tag
        {
            OPTTYPE   type ;
            FL64      strike ;
            BOOLE     berm ;
            PAYDAYDEF dpay ;
            PERIOD    delay ;
            CALCONV   cal ;
            PLAN_STR  *step_strike;
        }   USBONDOPT ;

The data have the following interpretations:

    type is the option type. PUT, CALL or STRADDLE.
        Note that straddles are implemented as a single contract, i.e. 
        either a PUT or a CALL. If it is really two then call the relevant 
        routine twice using the relevant PUT and CALL definitions.

    strike is the bond clean price strike per 100 bond notional.

    berm is True if the option exercises on discretely spaced dates,
        and False if US-Style exercise, i.e. exercise on any date.

    dpay is the definition of the discrete exercise dates. If berm
        is True then all data in dpay are used, if berm is False then
        only dpay.first and dpay.last are used as first and last
        exercise date.

    delay is a fixing delay. This is delay is interpreted as the
        delay from decision-making to actually entering into the
        underlying of the option. This is typically 2-5 days.

    cal is the calendar convention for the option used for
        discounting

    step_strike|NULL is the plan of stepped strikes. Use NULL as default,
        which case strike is used all the time. If step_strike is filled
        then strike is only used before the first date in step_strike.

,,EOT,,*/

typedef struct usbondopt_tag
{
    OPTTYPE   type ;
    FL64      strike ;
    BOOLE     berm ;
    PAYDAYDEF dpay ;
    PERIOD    delay ;
    CALCONV   cal ;
    PLAN_STR  *step_strike;
}   USBONDOPT ;


/*,,SOT,,

HWBOOTRES: Result info from H&W Volatility Bootstrapping.
---------------------------------------------------------

This type is defined as:

        typedef struct hwbootres_tag
        {
            BOOLEARRAY ok ;
            FL64ARRAY  dev ;
            INTI       nsec ;
            VOL_STR    tsov ;
            FL64       sigma ;
            FL64       mad ;
        }   HWBOOTRES ;

where:

        ok[nsec] is an array of length nsec, telling whether the calculation
        of security i went well. True means yes, False no.

        dev[nsec] is an array of length nsec informing on the deviation
        between market price and calibrated price. Calculated only
        if ok for security i is True.

        nsec is the number of securituies entering into the calculation.

        tsov is the resulting term structure of volatility, calculated
        from the instruments and the market prices - given the model.
        tsov.vol is set by the routine, tsov.cal is set to the security
        specific one and tsov.vc is not relevant.

        sigma is the resulting short rate volatility (corresponding to
        sigma in HWPARMS).

        mad is the mean absolute price deviation for all instruments,
        excluding those that have ok equal to False.

This struct is returned from the routines hw_*2vol(). ok, dev and
tsov.vol are allocated in these routines as:

        ok       = Alloc_BOOLEARRAY(nsec) ;
        dev      = Alloc_FL64ARRAY(nsec) ;
        tsov.vol = Alloc_PLANARRAY(1, nsec) ;

,,EOT,,*/

typedef struct hwbootres_tag
{
    BOOLEARRAY ok ;
    FL64ARRAY  dev ;
    INTI       nsec ;
    VOL_STR    tsov ;
    FL64       sigma ;
    FL64       mad ;
}   HWBOOTRES ;


/*,,SOT,,

HWCMTMODL: Data for defining CMT indices in H&W models
------------------------------------------------------

Definition:

        typedef struct hwcmtmodl_tag
        {
            FL64 spread ;
            FL64 oas ;
        }   HWCMTMODL ;

where:

        spread is the spread between the yield curve generated in 
        the tree and the desired yield curve, i.e. it is the spread
        applied to the index fixings given by the tree. Quoted as a 
        percentage according to the same interest convention as the index.

        oas is the discounting spread. Quoted as a CONTINUOUS rate as a
        percentage.

For a CMT index using H&W models the data are:

        1) If the tree is generated from the treasury curve, e.g UST, 
           then spread is 0.0 and oas is typically > 0.0.
        2) If the tree is generated from the money marked curve, e.g.
           LIBOR, then oas is  0.0 and spread is taken from treasury swap 
           spreads with the corresponding maturity. In this case 
           spread is typically < 0.0. The spread can be found using
           SwapFl_HWTREE2Spread().
           
For a CMS index using H&W models the data are:

        1) If the tree is generated from the money marked curve, e.g.
           LIBOR, then both spread and oas are 0.0.

,,EOT,,*/

typedef struct hwcmtmodl_tag
{
    FL64 spread ;
    FL64 oas ;
}   HWCMTMODL ;


/*,,SOT,,

DKMBS: Data type for holding info on Danish Mortgage-Backed Securities
----------------------------------------------------------------------

This type is defined as:

        typedef struct dkmbs_tag
        {
            FL64        coupon ;
            PMTFREQ     freq ;
            EXRULE      excp ;
            EXRULE      expr ;
            CFLW_STR    *cflw ;
            DEBTORARRAY debtor ;
            INTI        ndebtor ;
            PLAN_STR    *xredemp ;
            PREPAYCONV  prepayc ;
            INTI        orig_matur ;
            EXRULE      expr_d ;
        }   DKMBS ;

Where each data element is defined as:

    coupon is the coupon rate of the issue (in % --  e.g. 8.0)

    freq is the payment frequency of the bond

    excp defines the ex-coupon rules (typically 30 days)

    expr defines the ex-principal rule (typically a published date)

    cflw defines the cashflow for the bond ('ydelsesraekke'). Which
        is regularly published.

    debtor[ndebtor] defines the debtor data -- with ndebtor entries

    xredemp|NULL defines extraordinary redemptions in form of dates
        and corresponding prepayments. Enter NULL if not used.

    prepayc is the convention for quoting prepayments in xredemp.

    orig_matur is the original maturity of the loan (in years), e.g.
        10, 20 or 30.

    expr_d is the period before a payday after which the debtor
        cannot call his loan (typically a day) - always before expr.


see also Set_DKMBS

,,EOT,,*/

typedef struct dkmbs_tag
{
    FL64        coupon ;
    PMTFREQ     freq ;
    EXRULE      excp ;
    EXRULE      expr ;
    CFLW_STR    *cflw ;
    DEBTORARRAY debtor ;
    INTI        ndebtor ;
    PLAN_STR    *xredemp ;
    PREPAYCONV  prepayc ;
    INTI        orig_matur ;
    EXRULE      expr_d ;
}   DKMBS ;


/*
..internal only
*/

typedef struct dkmbsint_tag
{
    FL64        coupon ;
    PMTFREQ     freq ;
    BOOLE       excp ;
    BOOLE       expr ;
    CFLW_STR    *cflw ;
    DEBTORARRAY debtor ;
    INTI        ndebtor ;
    INTI        orig_matur ;
    BOOLE       expr_d ;
}   DKMBSINT ;


/*,,SOT,,

DKMBSMODEL: Defining model data for valuing Danish MBS's using BDT
------------------------------------------------------------------

Defined as:

        typedef struct dkmbsmodel_tag
        {
            INTI  xtra ;
            FL64  last ;
            INTI  freq ;
            BOOLE lite ;
        }   DKMBSMODEL ;

where:

        xtra -- Extra number of steps in the BDT tree inserted between
        each payday in the period till last strike date (default 0).

        last -- The last strike date. It is recommended to choose last
        as smaller than (say) 6 years for performance. The potential
        strikes after this data are usually insignificant anyway.
        (default is 6).

        freq -- The interval between pricing dates after last in the
        BDT tree - used to improve performance significantly.
        A value of 4 is recommended, and must be positive.

        if lite is True then - tax, mixpct and cashrate in DEBTOR will
        not be taken into account (for speed) in DKmbs_BDT2*().
        This will speed up the price calculations significantly.

If you are in doubt about the viability of the fast settings then do a
full valuation - and compare with the numbers from a valuation based on
the 'fast' settings'

,,EOT,,*/

typedef struct dkmbsmodel_tag
{
    INTI  xtra ;
    FL64  last ;
    INTI  freq ;
    BOOLE lite ;
}   DKMBSMODEL ;


/*,,SOT,,

CHVPARMS: Holds data for Cheuk & Vorst trinomial tree calibration
-----------------------------------------------------------------

This data container defines the data needed for calibrating a trinomial
short rate tree using the Cheuk & Vorst method. This method is well suited 
for valuing barrier options.

Underlying the trinomial tree is the assumption that the short rate follows
a process:

        d(r) = (theta(t) + a * r) d(t) + sigma * d(Z)

where a is the mean reversion and sigma the short rate vol, r the short rate.
Theta is the drift derived from the zero curve.

Data definition:

        typedef struct chvparms_tag
        {
            FL64     a ;
            FL64     sigma ;
            PERIOD   step_per ;
            CALCONV  cal ;
            PLAN_STR *barr ;
        }   CHVPARMS ;

The data are interpreted as:

        a is the mean reversion (e.g 0.1)

        sigma is the short rate vol (e.g. 0.01)

        step_per is the period for a single discrete time step (cannot be
        shorter than 1 day). Short time steps may result in large trees with
        very small Arrow-Debreu prices in some nodes. This may cause an
        underflow error on some old compilers.

        cal is the calendar for tree calibration (should NOT be a 30/360
        type, since this leads to convergence problem s with daily (etc)
        steps).

        barr is the barrier (translated into equivalent short rate).
        (set in the valuation routines).

For an example of usage see Swaption_CHV2P() or Clb_CHV2Tree().

The tree generated has constant steps (step_per) all the way out to last 
option maturity. The zero curves at this date can be inferred from the short
rate distribution and the process parameters.

It is important that the sampling period of the interest rate process is 
smaller than or equal to the barrier sampling. For weekly or monthly sampling
periods this can easily be accommodated by having trees of shorter periods. 
This typically leads to good price convergence. 

If the barrier sampling is daily the tree period must be equal to the barrier
period. This will lead to a small value error (of maybe a few percent).

For details on the method we refer to:

T. Cheuk & T. Vorst
Breaking down barriers
Risk Magazine, vol. 9, n0.4, 1996, pp 64-67

,,EOT,,*/

typedef struct chvparms_tag
{
    FL64     a ;
    FL64     sigma ;
    PERIOD   step_per ;
    CALCONV  cal ;
    PLAN_STR *barr ;
}   CHVPARMS ;


/*
..Private
*/
typedef struct hwfitdata_tag
{
    DATESTR   *sANALYS ;
    DATESTR   *sVOLDATE ;
    FL64ARRAY sPRICES ;
    DISCFAC   *sDF ;
    HOLI_STR  *sHOLI ;
    INTI      sTYPE ;        /* 0 -> cap, 1 -> swaption, 2 -> optfut */
    BOOLE     sWEIGHT ;
    CAPLETSARRAY   sCAP ;
    SWAPTIONARRAY  sSWAPTION ;
    FIXPAYARRAY    sFIXPAY ;
    OPTFUTARRAY    sOPTFUT ;
} HWFITDATA;

/* Newton-Raphson structs */

typedef struct
{
    CAPLETS     *capl ;
    CAPTION     *capt ;
    HWCMTMODL   *hwcm ;
    SWAPTION    *swt ;
    CCSWAPTION  *ccswt ;
    NCSWAPTION  *ncswt ;
    MODELSTAT   *mdls ;
    USBONDOPT   *opt ;
    FIXPAY      *fixp ;
    FL64        oas ;
} HWINSTR ;

typedef enum
{
    BOOTCAPLETS_HW,
    BOOTSWAPTION_HW,
    CAPLETS_HW,
    CAPTION_HW,
    SWAPTION_HW,
    CCSWAPTION_HW,
    NCSWAPTION_HW,
    OPTBONDUS_HW,
    SWAPCALL_HW
} HWTYPE ;

typedef struct 
{
    HWTYPE    type ;
    void      *instr ;
    HWCMTMODL *hwcm ;
    MODELSTAT *mdls ;
    FIXPAY    *fixp ;
    FL64      oas ;
    FL64      price ;
    HWPARMS   *parms ;
    DISCFAC   *df ;
    VOL_STR   *tsov ;
    FL64      *vol ;
    HOLI_STR  *holi ;
    FL64      shock ;
    BOOLE     use_optmatur;
} HWINT ;

typedef enum
{
    CAPLETS_HWCF,
    IMPL_HWCF,
    GETBARR_HWCF
} HWCFTYPE ;

typedef struct
{
    HWCFTYPE      type ;
    FL64          npv ;
    DATESTR       *PVdate ;
    DATEARRAY     dates ;
    INTI          ndates ;
    PAYDAYDEF     *pday ;
    FL64ARRAY     AtT ;
    FL64ARRAY     BtT ;
    void          *instr ;
    DISCFAC       *df ;
    HWCFPARMS     *hwc ;
    HOLI_STR      *holi ;
    RISKSET       *orsk ;
    FL64          shock ;
} HWCFINT ;

typedef struct
{
    FL64          r0 ;
    FL64          delta_t0 ;
    FL64          term ;
    FL64          ri ;
    FL64          vi ;
    FL64          shock ;
} HWCALINT ;

typedef struct
{
    DATESTR     *today ;
    TS_STR      *ts ;
    TSOV_STR    *tsov ;
    INTPOLCONV  *its ;
    DKMBSMODEL  *dkm ;
    DKMBSINT    *mbsi ;
    FL64        clean ;
    FL64        oas_d ;
    BOOLE       use_oas_d ;
    PLAN_STR    *xcflw ;
    FL64        shock ;
} OASINT ;

typedef struct
{
    FL64     pv ;
    BONDTYPE type ;
    FL64     pmt ;
    FL64     t ;
    FL64     shock ;
} YIELDINT ;

typedef struct hwvolfitdata_tag
{
  SWAPTIONARRAY  swt;
  FL64ARRAY      prices;
  HWPARMS        parms;
  DISCFAC        df;
  VOL_STR        vol;
  HOLI_STR       holi;
  FL64           shock;
  INTIARRAY     index;
  INTI          nswt;
} HWVOLFITDATA ;

/* BDT struct */
typedef struct
{
  FL64       zeroyield ;
  FL64       shortrate ;
  FL64ARRAY  dt ;
  INTI       step ;
  FL64       shock ;
  FL64       scale ;
} BDTINT ;


/*** routines in bdt.c ***********************************************/

/* Public functions */
extern BOOLE Clb_BDT2Tree(DISCFAC    *disc,
                           VOL_STR    *vol,
                           STEPARRAY  step,
                           INTI       nstep,
                           CALCONV    cal,
                           HWTREE     *hw) ;

/* Private functions */
extern BOOLE BDT_genr_tree(BINTREE      *tree,
                           TS_STR       *ts,
                           TSOV_STR     *tsov,
                           INTPOLCONV   ipol) ;

extern BOOLE BDT_newton(FL64ARRAY   x,
                        INTI        step,    
                        FL64ARRAY   g1,      
                        FL64ARRAY   g2,      
                        FL64MATRIX  alpha,
                        FL64ARRAY   Pd,
                        FL64ARRAY   Pu) ;

extern void BDT_eval_eq(FL64ARRAY   x,
                        FL64ARRAY   fofx,
                        INTI        step,
                        FL64ARRAY   g1,
                        FL64ARRAY   g2,
                        FL64ARRAY   Pd,
                        FL64ARRAY   Pu) ;

extern void BDT_jac(FL64ARRAY  x,
                    FL64MATRIX y,
                    INTI       step,
                    FL64ARRAY  g1,
                    FL64ARRAY  g2) ;

extern BOOLE BDT_NewtonRaphson(FL64   x, 
                               void*  y,
                               BOOLE  grad,
                               FL64*  fx, 
                               FL64*  dfx) ;


/*** routines in hwutil.c *********************************************/


/* Public functions */
extern FL64ARRAY Clb_HW2Density(HWTREE *hw,
                            INTI level,
                            FL64ARRAY fractile,
                            INTI nfrac,
                            BOOLE cumul) ;

extern FL64ARRAY Clb_HWTREE2Level(HWTREE* hw, INTI level, 
        BOOLE asrates, FL64ARRAY fractile, INTI nfrac, 
        BOOLE cumul, INTI* nrates);

extern FL64ARRAY Clb_HW2Level(HWPARMS *parms,
        DISCFAC *disc, VOL_STR *vol, INTI level, 
        BOOLE asrates, FL64ARRAY fractile, INTI nfrac, 
        BOOLE cumul, INTI* nrates);

extern HWPARMS Set_HWPARMS(HWFIXPARM fixp,
                        FL64      theta,
                        FL64      phi,
                        FL64      beta,
                        FL64      sigma,
                        HWFUNC    meanrev,
                        HWFUNC    dfr,
                        BOOLE     sigma_fix,
                        BOOLE     cal_simpl,
                        FL64      chg_time,
                        CALCONV   cal,
                        STEPARRAY step,
                        INTI      nstep,
                        BOOLE     useCF) ;

extern USBONDOPT Set_USBONDOPT( OPTTYPE   type,
                            FL64      strike,
                            BOOLE     berm,
                            PAYDAYDEF* dpay,
                            PERIOD*    delay,
                            CALCONV    cal,
                            PLAN_STR   *step_strike) ;

extern CCSWAPTION Set_CCSWAPTION(OPTTYPE   type,
                             PAYDAYDEF* eday,
                             PERIOD*    delay,
                             BOOLE      accrued,
                             SWAPFIX*   swapfix,
                             BOOLE      vanilla,
                             SWAPFLOAT* swapfl) ;

extern NCSWAPTION Set_NCSWAPTION(OPTTYPE   type,
                             BOOLE     berm,
                             PAYDAYDEF* eday,
                             PERIOD*    delay,
                             PERIOD*    swapdur,
                             SWAPFIX*   swapfix,
                             BOOLE      vanilla,
                             SWAPFLOAT* swapfl) ;


/* Private functions */
extern void HW_step2term(DATESTR    *today,
                         STEPARRAY  step,
                         INTI       nstep,
                         FL64MATRIX times,
                         CALCONV    cal) ;

extern void HW_UpdateADPrices(LEVELINFO *level,
                                INTI      i,
                                HWFIXPARM fixparm) ;

extern INTI HW_Findtreeindex(HWTREE  *hw,
                             DATESTR *date) ;

extern INTI HW_getmaxstates(HWTREE *hw) ;

extern FL64 HW_Discount(HWTREE *hw,
                        INTI   i,
                        INTI   j,
                        FL64   expv,
                        FL64   time,
                        FL64   oas,
                        BOOLE  cheap) ;

extern FL64 HW_Discount_forw(HWTREE *hw,
                      INTI   i,
                      INTI   j,
                      FL64   forw_time,
                      FL64   oas) ;

extern FL64 HW_prob2value(HWTREE *hw,
                          INTI   i,
                          INTI   j,
                          FL64MATRIX pmat,
                          INTI   ix) ;

extern FL64 HW_AD2Pv(HWTREE    *hw,
                     INTI      level,
                     FL64ARRAY price,
                     INTI      nprice) ;

extern INTI HW_SetDates(DATESTR    *today,
                        FL64MATRIX times,
                        INTI       nstep,
                        CALCONV    cal,
                        DATESTR*   lastm,
                        DATEARRAY  dates) ;

extern FL64 HW_delayadjust(HWTREE *hw,
                    INTI   i,
                    INTI   j,
                    FL64   x,
                    FL64   ddt,
                    FL64   coupon,
                    FL64   matur,
                    FL64   forw) ;

extern FL64 HW_HWTREE2Pv(HWTREE    *hw,
                  INTI      level,
                  FL64ARRAY price,
                  FL64      oas) ;

extern FL64ARRAY HW_HWTREE2Prof(HWTREE*  hw,
                            DATESTR* matur,    
                            INTI     level,    
                            FL64ARRAY price,
                            INTI*     iprev) ;

extern FL64ARRAY HW_HWTREE2DiscPayoff(HWTREE*   hw,
                                      INTI      tolevel,    
                                      INTI      fromlevel,    
                                      FL64ARRAY price) ;
       

extern DATEARRAY HW_map_float_paydays(PAYDAYDEF *pday,
                               HOLI_STR  *holi,
                               DATEARRAY fix,
                               INTI      nfix,
                               INTI      *nres) ;

extern DATEARRAY HW_map_paydays(PAYDAYDEF  *pday,
                         HOLI_STR   *holi,
                         DATESTR    *first,
                         DATEARRAY  list,
                         INTI       nlist,
                         INTI       *count) ;

extern DATEARRAY HW_Find_swapdays(DATEARRAY flt,
                           INTI      nflt,
                           DATEARRAY fix,
                           INTI      nfix,
                           INTI      *nswap) ;

/*** routines in hwmem.c **********************************************/

/* Public functions */
extern void Free_DKMBS(DKMBS *mbs) ;
extern void Free_HWTREE(HWTREE *hw) ;

extern DEBTORARRAY Alloc_DEBTORARRAY(INTI n) ;
extern void Free_DEBTORARRAY(DEBTORARRAY loan) ;

extern KFDEBTORARRAY Alloc_KFDEBTORARRAY(INTI n) ;
extern void Free_KFDEBTORARRAY(KFDEBTORARRAY loan) ;

/* Private functions */
extern void HW_Freeall(HWTREE *hw,
                INTI   min,
                INTI   max) ;

extern NODEINFO *HW_Allocnode(INTI n,
                              HW_ERR *err) ;

extern LEVELINFO * hw_alloclevel(INTI n,
                                 HW_ERR *err) ;


/*** routines in hwprice.c ********************************************/


/* Public functions */
extern FL64ARRAY Cflw_HWTREE2Price(HWTREE    *hw,
                          DATESTR   *pday,
                          CFLW_STR  *cflw,
                          FL64      ai,
                          FL64      oas_bond,
                          INTI      *nprof) ;

extern FL64 OptCflw_HWTREE2P(HWTREE      *hw,
                             CFLWARRAY   cfix,
                             USBONDOPT   *opt,
                             FL64        oas) ;

extern FL64ARRAY Caplets_HWTREE2P(HWTREE    *hw,
                              DATESTR   *pday,
                              CAPLETS   *cap,
                              HWCMTMODL *hwcm,
                              INTI      *nprof) ;

extern FL64ARRAY FlexCap_HWTREE2P(HWTREE   *hw,
                                     CAP      *fcap,
                                     HOLI_STR *holi,
                                     INTI     *n) ;

extern FL64 SwaptionNC_HWTREE2P(HWTREE     *hw,
                                NCSWAPTION *ncsw,
                                HOLI_STR   *holi) ;

extern FL64 SwapFl_HWTREE2NPV(HWTREE        *hw,
                              SWAPFLOAT     *swapfl,
                              HOLI_STR      *holi,
                              HWCMTMODL     *hwcm) ;

extern FL64ARRAY SwapFl_HWTREE2P(HWTREE        *hw,
                                 DATESTR       *analys,
                                 SWAPFLOAT     *swapfl,
                                 HOLI_STR      *holi,
                                 HWCMTMODL     *hwcm,
                                 INTI          *nprof) ;

extern FL64 SwapFl_HWTREE2Spread(FL64      pvLIBOR,
                                 HWTREE    *hw,
                                 HWCMTMODL *hwcm,
                                 DISCFAC   *dfLIBOR,
                                 PAYDAYDEF *pdayCMT,
                                 FLOATBASE *fbCMT,
                                 RATEINDEX *indexCMT,
                                 FL64      factor,
                                 HOLI_STR  *holi) ;

extern FL64 SwaptionCC_HWTREE2P(HWTREE     *hw,
                                CCSWAPTION *ccsw,
                                HOLI_STR   *holi) ;

extern FL64 Caption_HWTREE2P(HWTREE    *hw,
                             CAPTION   *capt,
                             HOLI_STR  *holi,
                             HWCMTMODL *hwcm) ;

extern BOOLE Swaption_CHV2P(CHVPARMS* chv,     
                        DISCFAC*  df,
                        SWAPTION* swpt,
                        HOLI_STR* holi,
                        RISKSET*  risk,
                        FL64*     p,
                        FL64*     dp,
                        MODELSTAT* mdls) ;

/* Private functions */

extern FL64 HW_Cflw_Accruint(CFLWARRAY cfix,
                             DATESTR   *event,
                             DATESTR   *today,
                             CALCONV   cal,
                             INTI      *ixc_prev, 
                             INTI      *ixc_next) ;

extern FL64MATRIX HW_Genr_Index(HWTREE*     hw, 
                                INTI        i,
                                RATEINDEX*  index,
                                DATESTR*    first_fix,
                                DATESTR*    last_fix,
                                EOMCONV     eom,
                                HOLI_STR*   holi,
                                DATEARRAY*  index_days,
                                INTI*       nindex_days) ;           
             
extern FL64MATRIX HW_getDISC(HWTREE *hw, INTI level,
                             DATEARRAY dates, INTI ndates) ;

extern void HW_Price_NCfloat(HWTREE *hw, DATESTR *omatur, DATESTR* eff,
                                INTI matur, TERMUNIT unit, SWAPFLOAT *swapfl,
                                HOLI_STR *holi, FL64ARRAY price_float) ;

extern FL64ARRAY HW_Price_NCfix(HWTREE* hw,
                                DATESTR*    eventday, 
                                PERIOD*     delay,
                                PERIOD*     swapdur,
                                SWAPFIX*    swapfix,
                                HOLI_STR*   holi,
                                INTI*       nprof) ;

extern FL64 Swaption_HWTREE2P(HWTREE*   hw,
                              SWAPTION* swpt,
                              HOLI_STR* holi) ;

extern FL64 Swaption_PayOff(SWAPTION* swpt, FL64 Pfix, FL64 Pfloat) ;

extern FL64 Option_PayOff(OPTTYPE type, FL64 price, FL64 strike) ;

extern FL64 Option_PayOffBarrier(KNOCKTYPE  type,
                                    FL64       val,   
                                    FL64       barr,
                                    FL64       rate) ;

extern NCSWAPTION CAP2NCSWAPTION(CAP* cap) ;

extern void HW_Genr_Float(DATESTR    *today,
                          SWAPFLOAT  *swapfl,
                          CALCONV    cal,
                          HOLI_STR   *holi,
                          CFLWARRAY  *cflw,
                          FL64ARRAY  *terms,
                          PLANARRAY  *fix, 
                          DATEARRAY  *days) ;

extern void HW_Genr_Fixed(DATESTR    *today,
                          SWAPFIX    *swapfix,
                          CALCONV    cal,
                          HOLI_STR   *holi,
                          CFLWARRAY  *cflw,
                          FL64ARRAY  *terms) ;

extern PLANARRAY HW_Genr_FloatFixings(DATEARRAY    days,
                                      INTI         nflt,
                                      CFLWARRAY    cflw, 
                                      FLOATRATE*   float1, 
                                      EOMCONV      eom,
                                      HOLI_STR*    holi) ; 

extern DATEARRAY HW_Genr_USstrikes(HWTREE     *hw,
                                   DATESTR    *first,
                                   DATESTR    *last,
                                   INTI       *nsd) ;

extern INTI HW_Find_Events(HWTREE    *hw,
                           INTI      i,
                           DATEARRAY strdays,
                           INTI      no_events,
                           INTI      *ixs,
                           DATEARRAY event) ;

extern BOOLE HW_CheckStrike(BOOLE     berm,
                            DATESTR   *event,
                            INTI      events_left,
                            DATEARRAY strdays,
                            INTI      nsd,
                            INTI      ixs) ;

extern FL64 HW_Find_TimeBetweenEvents(HWTREE     *hw,
                                      INTI       i, 
                                      DATEARRAY  event,
                                      INTI       l) ;

extern FL64 HW_DiscountPremium(HWTREE      *hw,
                               INTI        i,
                               BOOLE       use_AD,
                               FL64MATRIX  price,
                               INTI        ix) ;

extern void HW_Price_Discount(HWTREE     *hw,
                              INTI       i,
                              FL64       time,
                              BOOLE      previous_event, 
                              BOOLE      simple_event, 
                              FL64       oas,
                              INTI       ix,
                              INTI       block,
                              FL64MATRIX prices) ;

extern BOOLE HW_Price_Discount_Cond(HWTREE     *hw,
                                    INTI       i,
                                    BOOLE      cond_old,
                                    INTI       i_cond,
                                    FL64       time,
                                    BOOLE      previous_event, 
                                    BOOLE      simple_event, 
                                    FL64       oas,
                                    INTI       ix,
                                    INTI       blocksize,
                                    FL64BOX    prices) ;

extern INTI HW_Price_Fixed(HWTREE     *hw,
                           INTI       i,
                           DATESTR    *event,
                           FL64       term,
                           CFLWARRAY  cflw,
                           FL64ARRAY  terms,
                           INTI       ixf,
                           FL64       oas,
                           INTI       ix,
                           INTI       block,
                           FL64MATRIX fix,
                           FL64       *nom) ;

extern INTI HW_Price_Fixed_Cond(HWTREE     *hw,
                                INTI       i,
                                BOOLE      cond,
                                INTI       i_cond,
                                DATESTR    *event,
                                FL64       term,
                                CFLWARRAY  cflw,
                                FL64ARRAY  terms,
                                INTI       ixf,
                                FL64       oas,
                                INTI       ix,
                                INTI       blocksize,
                                FL64BOX    fix,
                                FL64       *nom) ;

extern INTI HW_Price_Float(HWTREE     *hw,
                           INTI       i,
                           DATESTR    *event,
                           BOOLE      vanilla,
                           PLANARRAY  fix,
                           DATEARRAY  days,
                           INTI       ixf,
                           FLOATBASE  *fbase,
                           RATEINDEX  *index,
                           FL64       factor,
                           FL64       oas,
                           FL64       spread,
                           HOLI_STR   *holi,
                           INTI       ix,
                           INTI       blocksize,
                           FL64MATRIX flt) ;

extern INTI HW_Price_Float_Cond(HWTREE     *hw,
                                INTI       i,
                                DATESTR    *event,
                                BOOLE      vanilla,
                                BOOLE      accrued,
                                PLANARRAY  fix,
                                DATEARRAY  days,
                                INTI       ixf,
                                FLOATBASE  *fbase,
                                RATEINDEX  *index,
                                FL64       factor,
                                FL64       oas,
                                FL64       spread,
                                HOLI_STR   *holi,
                                INTI       ix,
                                INTI       blocksize,
                                FL64BOX    flt,
                                BOOLE      *cond,
                                INTI       *i_cond,
                                FL64ARRAY  fixing) ;

extern INTI HW_Price_Fixing(HWTREE      *hw,
                            INTI        i,
                            DATESTR     *start,
                            FL64        period,
                            FLOATBASE   *fbase,
                            BOOLE       use_fixing,
                            RATEINDEX   *index,
                            FL64        factor,
                            FL64        spread,
                            EOMCONV     eom,
                            HOLI_STR    *holi,
                            FL64ARRAY   fixing) ;

extern void HW_Float_Accruint(HWTREE     *hw,
                              DATESTR    *event,
                              DATEARRAY  days,
                              INTI       ixf,
                              INTI       ndays,
                              DATESTR    *effective,
                              CALCONV    cal,
                              INTI       i_fix,
                              FL64ARRAY  fixing,     
                              FL64ARRAY  ai) ;

extern BOOLE HW_Price_Swaption_Cond(HWTREE     *hw, 
                                    INTI       i, 
                                    BOOLE      accrued,
                                    BOOLE      cond, 
                                    INTI       i_fix,
                                    OPTTYPE    type, 
                                    FL64MATRIX fix, 
                                    FL64       fix_ai,
                                    FL64BOX    flt,
                                    FL64ARRAY  flt_ai,
                                    INTI       ix, 
                                    INTI       blocksize,
                                    FL64BOX    opt) ;

extern INTI HW_Price_Cap(HWTREE      *hw,
                         INTI        i,
                         DATESTR     *event,
                         CAPLETS     *cap, 
                         INTI        ixf,
                         BOOLE       vanilla,
                         FL64        oas,
                         FL64        spread,
                         INTI        ix,
                         FL64MATRIX  pc) ;


/*** routines in hwcalib.c ********************************************/


/* Public functions */
extern HW_ERR Clb_HW2Tree(HWPARMS    *parms,
                         DISCFAC    *disc,
                         VOL_STR    *vol,
                         DATESTR    *matur,
                         HWTREE     *hw) ;

extern HW_ERR Clb_CHV2Tree(CHVPARMS* parms,
                              DISCFAC* df,
                              DATESTR* matur,
                              BOOLE    dscr,
                              HWTREE*  hw);

/* Private functions */
extern HW_ERR HW_calibrate(HWTREE     *hw,
                           HWPARMS    *parms,
                           TS_STR     *ts,
                           INTPOLCONV ipts,
                           TSOV_STR   *tsov,
                           INTPOLCONV iptsov,
                           FL64MATRIX timespec,
                           INTI       ntimes,
                           BOOLE      restart,
                           INTI       absmax,
                           FL64       lastm) ;

extern HW_ERR HW_SetUniqueNodes(LEVELINFO *level, INTI i) ;

extern HW_ERR HW_getyld(TS_STR     *ts,
                        INTPOLCONV ipts,
                        TSOV_STR   *tsov,
                        INTPOLCONV iptsov,
                        FL64       r0,
                        FL64       *rd,
                        FL64       *ru,
                        FL64       delta_t0,
                        FL64       term) ;

extern FL64 HW_x2r(FL64   x0,
                   FL64   delta_x,
                   FL64   beta,
                   FL64   r0,
                   INTI   j,
                   HWFUNC dfr) ;

extern FL64 HW_r2x(FL64 r0,
                   FL64 r,
                   FL64 beta,
                   HWFUNC dfr) ;

extern HWCALINT HWCAL_SetHWCALINT(FL64 r0,
                                  FL64 delta_t0,
                                  FL64 term,
                                  FL64 ri,
                                  FL64 vi,
                                  FL64 shock) ;

extern void HWCAL_GetHWCALINT(HWCALINT *hw_data,
                              FL64     *r0,
                              FL64     *delta_t0,
                              FL64     *term,
                              FL64     *ri,
                              FL64     *vi,
                              FL64     *shock) ;

extern FL64 HW_func(FL64 r0, 
                       FL64 delta_t, 
                       FL64 term, 
                       FL64 rd, 
                       FL64 ri, 
                       FL64 vi) ;

extern BOOLE HWCAL_NewtonRaphson(FL64   x, 
                                    void   *y,
                                    BOOLE  grad,
                                    FL64   *fx, 
                                    FL64   *dfx) ;

extern HW_ERR HW_get_parms(LEVELINFO *level,
                           INTI      i,
                           HWFUNC    meanrev,
                           HWFUNC    dfr,
                           FL64      delta_t,
                           FL64      ru,
                           FL64      rd,
                           FL64      *theta,
                           FL64      *phi) ;

extern HW_ERR hw_set_branching(LEVELINFO *level,
                               FL64      x0,
                               FL64      delta_x,
                               HWPARMS   *parms,
                               FL64      r0,
                               INTI      i,
                               FL64      delta_t,
                               FL64      sigmx,
                               BOOLE     tchange) ;

extern HW_ERR hw_set_branching_simple(LEVELINFO *level, FL64 a,
                                  INTI i, FL64 delta_t, FL64 chg_time) ;

extern HW_ERR HW_change_steplength(LEVELINFO  *level1,
                                   INTI       i1,
                                   HWPARMS    *parms,
                                   FL64       delta_t,
                                   FL64       delta_t1,
                                   TS_STR     *ts,
                                   INTPOLCONV ipts,
                                   TSOV_STR   *tsov,
                                   INTPOLCONV iptsov) ;

extern FL64 HW_get_meanrev(HWFUNC mr, FL64 rij) ;

extern INTI HW_getnodeindex(LEVELINFO *level, INTI i, INTI to) ;

extern INTI HW_getmaxlevel(FL64MATRIX timespec, INTI ntimes) ;

extern FL64 HW_GetTheta(LEVELINFO *level, INTI i, HWFUNC meanrev,
                           HWFUNC dfr, FL64 delta_t, FL64 r, FL64 a) ;

extern FL64 HW_get_ddfr(HWFUNC dfr, FL64 rj) ;

extern INTI HW_getextralevels(FL64MATRIX timespec, INTI ntimes,
                              FL64 start, INTI *ixtime) ;

extern void HW_getforwrate(HWTREE *hw,
                           INTI level,
                           FL64 time,
                           FL64 period,
                           FL64ARRAY forw) ;

extern FL64 HW_get_alpha(HWTREE *hw, INTI i, FL64 delta_t,
                         TS_STR *ts, INTPOLCONV ipts) ;

extern HW_ERR HW_SetBranchingCHV(LEVELINFO* level,
                             INTI      i,
                             FL64      dt,
                             FL64      dr,
                             FL64      theta,
                             FL64      a,
                             FL64      sigma,
                             FL64      alphai1);

extern FL64 HW_GetBarrInteger(FL64 hi1,     
                          FL64 alphai,  
                          FL64 theta,   
                          FL64 a,
                          FL64 dr,
                          FL64 dt);

extern void HW_SetRatesCHV(LEVELINFO* level,
                       INTI       i,
                       FL64       alphai,
                       FL64       dt,
                       FL64       dr);

extern PLAN_STR * Clb_CHV2BarrRates(CHVPARMS* parms,
                                DISCFAC*  df,
                                SWPTBARRINF* barr,
                                HOLI_STR* holi,
                                BOOLE*    ok);

extern FL64 HWCF_GetBarrRate(HWCFPARMS* parms,
                          DISCFAC*  df,
                          DATESTR*  eff,
                          SWPTBARRINF* barr,                          
                          HOLI_STR* holi,
                          BOOLE*    ok);

extern FL64 HWCF_Tree2Rate(HWTREE*   hw, 
                       INTI       i,
                       INTI       j,
                       HWCFPARMS* hwc,
                       DISCFAC*   df) ;

extern FL64 HWCF_Rate2TreeRate(DATESTR* today,
                            DATESTR* start,
                            DATESTR* end,
                            DISCFAC* df,
                            HWCFPARMS* hwc,
                            FL64     r,
                            FL64     dt) ;

extern FL64 HW_GetBarr(PLAN_STR* Pbarr,
                   DATESTR* date,
                   DATESTR* Bdate) ;

extern void hw_printf(LEVELINFO *level, INTI i, FL64 theta, FL64 a,
                         FL64 sigma);


/*** routines in dkmbs.c **********************************************/


/* Public functions */
extern BOOLE DKmbs_BDT2Price(DATESTR    *analys,
                      DKMBS     *mbs,
                      DISCFAC   *df,
                      VOL_STR   *vol,
                      DKMBSMODEL *dkm,
                      DFSPREAD   *oas,
                      DFSPREAD   *oas_d,
                      RISKSET   *risk,
                      FL64      *p,
                      FL64      *dp,
                      FL64      *ddp,
                      FL64      *optprem) ;

extern FL64ARRAY DKmbs_BDT2Delta(DATESTR    *analys,
                          DKMBS      *mbs,
                          DISCFAC    *df,
                          VOL_STR    *vol,
                          DKMBSMODEL *dkm,
                          DFSPREAD   *oas,
                          DFSPREAD   *oas_d,
                          DELTASET   *ds,
                          BOOLE      *ok) ;

extern BOOLE DKmbs_BDT2OAS(DATESTR   *analys,
                    FL64         price,
                    DKMBS        *mbs,
                    DISCFAC      *df,
                    VOL_STR      *vol,
                    DKMBSMODEL   *dkm,
                    DFSPREAD     *oas_d,
                    BOOLE        use_oas_d,
                    ITERCTRL     *ictrl,
                    FL64         *spr) ;

extern BOOLE DKmbs_BDT2OAYTM(DATESTR     *analys,
                      FL64       price,
                      DKMBS      *mbs,
                      DISCFAC    *df,
                      VOL_STR    *vol,
                      DKMBSMODEL *dkm,
                      DFSPREAD   *oas,
                      DFSPREAD   *oas_d,
                      FL64       *ytm) ;

extern BOOLE DKmbs_BDT2Prepay(DATESTR     *analys,
                       DKMBS      *mbs,
                       DISCFAC    *df,
                       VOL_STR    *vol,
                       DKMBSMODEL *dkm,
                       DFSPREAD   *oas,
                       DFSPREAD   *oas_d,
                       PLANARRAY  *xpc) ;

extern BOOLE DKmbs_BDT2Hzy(DATESTR    *analys,
                    DATESTR    *horiz,
                    FL64       price,
                    FL64       hprice,
                    DKMBS      *mbs,
                    HZYCONV    *hzyc,
                    DISCFAC    *dfre,
                    DISCFAC    *dfhrz,
                    VOL_STR    *volhrz,
                    DKMBSMODEL *dkm,
                    DFSPREAD   *oas,
                    DFSPREAD   *oas_d,
                    FL64       *hzy) ;

extern CFLWARRAY DKmbs_Genr_Cflw(DATESTR *today,
                                    DKMBS   *mbs,
                                    BOOLE   *exc,
                                    BOOLE   *exp,
                                    BOOLE   *expd) ;

extern FL64 DKmbs_DF2Price(DATESTR*  today,
                              DKMBS*    mbs,
                              DISCFAC*  df,
                              DFSPREAD* dfs) ;

extern DKMBS Set_DKMBS(FL64        coupon,
                        PMTFREQ     freq,
                        EXRULE      *excp,
                        EXRULE      *expr,
                        CFLW_STR    *cflw,
                        DEBTORARRAY debtor,
                        INTI        ndebtor,
                        PLAN_STR    *xredemp,
                        PREPAYCONV  prepayc,
                        INTI        orig_matur,
                        EXRULE      *expr_d) ;

extern DEBTORARRAY DKmbs_KFDEBTOR2DEBTOR(KFDEBTORARRAY kf,
                                      FL64ARRAY     prem,
                                      FL64ARRAY     stdev,
                                      FL64ARRAY     cost,
                                      FL64ARRAY     tax,
                                      INTI          nkf,
                                      FL64          coupon,
                                      INTI          *nd) ;

/* Private functions */

extern BOOLE DKmbs_bdt2p(DATESTR     *today,
                             TS_STR      *ts,
                             TSOV_STR    *tsov,
                             INTPOLCONV  its,
                             DKMBSMODEL* dkm,
                             DKMBSINT    *mbsi,
                             FL64        oas,
                             FL64        oas_d,
                             RISKSET     *rsk,
                             FL64        *p,
                             FL64        *dp,
                             FL64        *ddp,
                             FL64        *optprice,
                             PLAN_STR    *xpc,
                             BOOLE       doxpc) ;

extern BOOLE DKmbs_bdt2oaspr(DATESTR* today,
                           TSARRAY ts,
                           TSOVARRAY tsov,
                           INTPOLCONV  its,
                           DKMBSMODEL* dkm,
                           DKMBSINT *mbsi,
                           FL64 clean,
                           FL64    oas_d,
                           BOOLE   use_oas_d,
                           FL64 guess,
                           FL64 *spread) ;

extern OASINT DKmbs_SetOASINT(DATESTR     *today,
                                  TS_STR      *ts,
                                  TSOV_STR    *tsov,
                                  INTPOLCONV  *its,
                                  DKMBSMODEL  *dkm,
                                  DKMBSINT    *mbsi,
                                  FL64        clean,
                                  FL64        oas_d,
                                  BOOLE       use_oas_d,
                                  PLAN_STR    *xcflw,
                                  FL64        shock) ;

extern void DKmbs_GetOASINT(OASINT      *dkmbs_data,
                                DATESTR     **today,
                                TS_STR      **ts,
                                TSOV_STR    **tsov,
                                INTPOLCONV  **its,
                                DKMBSMODEL  **dkm,
                                DKMBSINT    **mbsi,
                                FL64        *clean,
                                FL64        *oas_d,
                                BOOLE       *use_oas_d,
                                PLAN_STR    **xcflw,
                                FL64        *shock) ;

extern BOOLE DKmbsOAS_NewtonRaphson(FL64  x, 
                                       void   *y,
                                       BOOLE  grad,
                                       FL64   *fx, 
                                       FL64   *dfx) ;

extern BOOLE DKmbs_bdt2oay(DATESTR     *today,
                        CFLW_STR    *cflw,
                        FL64        anncoup,
                        PMTFREQ     pfreq,
                        EXRULE      *excdays,
                        EXRULE      *expdays,
                        PLAN_STR    *xredemp,
                        PREPAYCONV  prepayc,
                        FL64        clean,
                        FL64        optprem,
                        FL64        *oaytm) ;

extern FL64 DKmbs_GetYield(FL64 pv, BONDTYPE type, FL64 coupon,
                           FL64 period, FL64 maturity, FL64 guess) ;

extern YIELDINT DKmbs_SetYIELDINT(FL64     pv,
                                     BONDTYPE type,
                                     FL64     pmt,
                                     FL64     t,
                                     FL64     shock) ;

extern void DKmbs_GetYIELDINT(YIELDINT *dkmbs_data,
                                 FL64     *pv,
                                 BONDTYPE *type,
                                 FL64     *pmt,
                                 FL64     *t,
                                 FL64     *shock) ;

extern BOOLE DKmbsYIELD_NewtonRaphson(FL64  x, 
                                        void   *y,
                                        BOOLE  grad,
                                        FL64   *fx, 
                                        FL64   *dfx) ;

extern FL64 DKmbs_GetNetpmt(FL64 tax, INTI npmt, FL64 krate,
                            FL64 maturity, FL64 period, FL64 mixpct,
                            FL64 debt) ;

extern FL64 DKmbs_GetNPV(FL64 tax, FL64 yield, FL64 krate,
                         FL64 maturity, FL64 period, FL64 mixpct) ;

extern FL64 DKmbs_Ann2Per(FL64  oas,
                             FL64  period,
                             BOOLE lite) ;

extern DKMBSINT DKmbs_Set_DKMBSINT(DATESTR* analys,
                                      DKMBS*   mbs) ;

extern TSARRAY DKmbs_DF2TSfwd(DATESTR* analys,
                                 DISCFAC* df) ;

extern TSOVARRAY DKmbs_Vol2TSOV(DATESTR* analys,
                                   VOL_STR* vol) ;

extern FL64 DKmbs_OAS2AnnComp(DFSPREAD* oas) ;

extern BONDTYPE DKmbs_Cflw2BONDTYPE(CFLWARRAY cflw,
                                       PMTFREQ   pfreq) ;

/*** routines in hwboot.c *********************************************/


/* Public functions */
extern HWBOOTRES Boot_Caplets2HWVol(CAPLETSARRAY  cap,
                      FL64ARRAY prices,
                      INTI      ncap,
                      HWPARMS   *parms,
                      DISCFAC   *df,
                      ITERCTRL  *ictrl,
                      VOL_STR   *vol) ;

extern HWBOOTRES Boot_Swaption2HWVol(SWAPTIONARRAY  swt,
                           FL64ARRAY prices,
                           INTI      nswt,
                           HWPARMS   *parms,
                           DISCFAC   *df,
                           ITERCTRL  *ictrl,
                           HOLI_STR  *holi,
                           VOL_STR   *vol,
                           HWFITVOLCTRL *fitctrl) ;

extern HWBOOTRES Fit_Caplets2HWVol(CAPLETSARRAY  cap,
                             FL64ARRAY prices,
                             INTI      ncap,
                             HWPARMS   *parms,
                             DISCFAC   *df,
                             ITERCTRL  *ictrl,
                             VOL_STR   *vol,
                             INTI      days) ;

extern HWBOOTRES Fit_Cap2HWVol(CAPARRAY  cap,
                             FL64ARRAY prices,
                             INTI      ncap,
                             HWPARMS   *parms,
                             DISCFAC   *df,
                             ITERCTRL  *ictrl,
                             VOL_STR   *vol,
                             HOLI_STR  *holi,
                             INTI      days) ;

extern HWBOOTRES Fit_Swaption2HWVol(SWAPTIONARRAY swt,
                              FL64ARRAY prices,
                              INTI      nswt,
                              HWPARMS   *parms,
                              DISCFAC   *df,
                              ITERCTRL  *ictrl,
                              HOLI_STR  *holi,
                              VOL_STR   *vol,
                              HWFITVOLCTRL *fitctrl) ;

extern HWFITVOLCTRL Set_HWFITVOLCTRL(INTI days, 
                                        BOOLE use_optmatur,
                                        BOOLE all_in_one, 
                                        BOOLE optimize);

/* Private functions */
extern BOOLE SwaptionNC_HWG2P(HWPARMS *parms, DISCFAC *df,
          VOL_STR *vol, SWAPTION *swt, HOLI_STR *holi, FL64 *p) ;
extern FL64 HW_Calc_Sigma(DISCFAC *df, VOL_STR *vol, HWPARMS *p) ;

extern void HW_SetITERCTRL(ITERCTRL *ictrl, 
                              ITERCTRL *ctrl,
                              FL64     *shock) ;

extern HWINT HW_SetHWINT(HWTYPE   type,
                            void      *instr,
                            HWCMTMODL *hwcm,
                            MODELSTAT *mdls,
                            FIXPAY    *fixp,
                            FL64      oas,
                            FL64      price,
                            HWPARMS   *parms,
                            DISCFAC   *df,
                            VOL_STR   *tsov,
                            FL64      *vol,
                            HOLI_STR  *holi,
                            FL64      shock,
                            BOOLE     use_optmatur) ;

extern void HW_GetHWINT(HWINT *hw_data,
                        HWTYPE    *type,
                        void      **instr,
                        HWCMTMODL **hwcm,
                        MODELSTAT **mdls,
                        FIXPAY    **fixp,
                        FL64      *oas,
                        FL64      *price,
                        HWPARMS   **parms,
                        DISCFAC   **df,
                        VOL_STR   **tsov,
                        FL64      **vol,
                        HOLI_STR  **holi,
                        FL64      *shock,
                        BOOLE     *use_optmatur) ;

extern BOOLE HW_NewtonRaphson(FL64  x, 
                                void   *y,
                                BOOLE  grad,
                                FL64   *fx, 
                                FL64   *dfx) ;


extern INTI HWboot_Sort_caps(CAPLETSARRAY   cap,
                      INTI       ncap,
                      INTI       days,
                      INTIMATRIX index,
                      INTIARRAY  nperg,
                      DATEARRAY  last) ;

extern INTI HWboot_Sort_swaptions(SWAPTIONARRAY swt,
                           INTI       nswt,
                           HOLI_STR   *holi,
                           INTI       days,
                           INTIMATRIX index,
                           INTIARRAY  nperg,
                           DATEARRAY  last,
                           BOOLE      use_optmatur) ;

extern BOOLE HWboot_Caplist2obj(CAPLETSARRAY  cap,
                         FL64ARRAY prices,
                         INTIARRAY index,
                         INTI      nindex,
                         HWPARMS   *hwp,
                         DISCFAC   *df,
                         VOL_STR   *vol,
                         FL64      shock,
                         FL64      *obj,
                         FL64      *obj1) ;

extern BOOLE HWboot_Swtlist2obj(SWAPTIONARRAY  swt,
                         FL64ARRAY prices,
                         INTIARRAY index,
                         INTI      nindex,
                         HWPARMS   *parms,
                         DISCFAC   *df,
                         VOL_STR   *vol,
                         HOLI_STR  *holi,
                         FL64      shock,
                         FL64      *obj,
                         FL64      *obj1) ;

extern void Optimize_Swaption2HWVol(SWAPTIONARRAY swt,
                              FL64ARRAY prices,
                              INTI     nswt,
                              HWPARMS*  parms,
                              DISCFAC*  df,
                              HOLI_STR* holi,
                              HWBOOTRES*    hbr);

extern int Harwell_Fit_HWVol(int* ncoef, int* nsec, 
                                double* coefs, void* data, double* f);


/*** routines in hwcover.c *******************************************/


/* Public functions */
extern BOOLE Bond_HW2Price(HWPARMS   *parms,
                    DISCFAC   *df,
                    VOL_STR   *vol,
                    FIXPAY    *fixp,
                    FL64      oas,
                    BOOLE     mv,
                    RISKSET   *risk,
                    FL64      *p,
                    FL64      *dp) ;

extern BOOLE OptBondUS_HW2P(HWPARMS   *parms,
                          DISCFAC   *df,
                          VOL_STR   *vol,
                          USBONDOPT *opt,
                          FIXPAY    *fixp,
                          FL64      oas,
                          RISKSET   *risk,
                          FL64      *p,
                          FL64      *dp) ;

extern BOOLE Caplets_HW2P(HWPARMS   *parms,
                          DISCFAC   *df,
                          VOL_STR   *vol,
                          CAPLETS   *cap,
                          HWCMTMODL *hwcm,
                          RISKSET   *risk,
                          FL64      *p,
                          FL64      *dp,
                          MODELSTAT *mdls) ;

extern BOOLE Cap_HW2P(HWPARMS   *parms,
               DISCFAC   *df,
               VOL_STR   *vol,
               CAP       *cap,
               HOLI_STR  *holi,
               HWCMTMODL *hwcm,
               RISKSET   *risk,
               FL64      *p,
               FL64      *dp,
               MODELSTAT *mdls) ;

extern BOOLE FlexCap_HW2P(HWPARMS    *parms,
                             DISCFAC    *df,
                             VOL_STR    *vol,
                             CAP        *fcap,
                             HOLI_STR   *holi,
                             RISKSET    *risk,
                             FL64LIST   *p,
                             FL64LIST   *dp) ;

extern BOOLE SwaptionNC_HW2P(HWPARMS    *parms,
                      DISCFAC    *df,
                      VOL_STR    *vol,
                      NCSWAPTION *ncsw,
                      HOLI_STR   *holi,
                      RISKSET    *risk,
                      FL64       *p,
                      FL64       *dp) ;

extern BOOLE Swaption_HW2P(HWPARMS*  parms,
                       DISCFAC*  df,
                       VOL_STR*  vol,
                       SWAPTION* ncsw,
                       HOLI_STR* holi,
                       RISKSET*  risk,
                       FL64*     p,
                       FL64*     dp,
                       MODELSTAT *mdls) ;

extern BOOLE SwaptionCC_HW2P(HWPARMS    *parms,
                    DISCFAC    *df,
                    VOL_STR    *vol,
                    CCSWAPTION *ccsw,
                    HOLI_STR   *holi,
                    RISKSET    *risk,
                    FL64       *p,
                    FL64       *dp) ;

extern BOOLE SwapCall_HW2P(HWPARMS    *parms,
                              DISCFAC    *df,
                              VOL_STR    *vol,
                              SWAPCALL   *swap,
                              HOLI_STR   *holi,
                              FL64       *p) ;

extern BOOLE Caption_HW2P(HWPARMS   *parms,
                   DISCFAC   *df,
                   VOL_STR   *vol,
                   CAPTION   *capt,
                   HOLI_STR  *holi,
                   HWCMTMODL *hwcm,
                   RISKSET    *risk,
                   FL64       *p,
                   FL64       *dp,
                   MODELSTAT  *mdls) ;

extern BOOLE SwapFl_HW2NPV(HWPARMS*   parms,
                       DISCFAC*   df,
                       VOL_STR*   vol,
                       SWAPFLOAT* sfl,
                       HOLI_STR*  holi,
                       HWCMTMODL* hwcm,
                       RISKSET*   risk,
                       FL64*      p,
                       FL64*      dp,
                       MODELSTAT* mdls) ;

extern BOOLE SwapFl_HW2Spread(FL64       pvLEG2,
                          HWPARMS*   parms,
                          DISCFAC*   df_tree,
                          DISCFAC*   df_disc,
                          VOL_STR*   vol,
                          SWAPFLOAT* sfl,
                          HOLI_STR*  holi,
                          HWCMTMODL* hwcm,
                          FL64*      spr,
                          MODELSTAT* mdls) ;

extern BOOLE Caplets_HW2Impl(HWPARMS*  parms,
                         FL64      price,
                         CAPLETS*  cap,
                         DISCFAC*  df,
                         HWCMTMODL* hwcm,
                         ITERCTRL* ictrl,
                         FL64*     res,
                         MODELSTAT* mdls) ;

extern BOOLE Cap_HW2Impl(HWPARMS*   parms,
                     FL64       price,
                     CAP*       cap,
                     DISCFAC*   df,
                     HOLI_STR*  holi,
                     HWCMTMODL* hwcm,
                     ITERCTRL*  ictrl,
                     FL64*      res,
                     MODELSTAT* mdls) ;

extern BOOLE Caption_HW2Impl(HWPARMS*   parms,
                         FL64       price,
                         CAPTION*   capt,
                         DISCFAC*   df,
                         HOLI_STR*  holi,
                         HWCMTMODL* hwcm,
                         ITERCTRL*  ictrl,
                         FL64*      res,
                         MODELSTAT* mdls) ;

extern BOOLE Swaption_HW2Impl(HWPARMS*  parms,
                          FL64      price,
                          SWAPTION* swpt,
                          DISCFAC*  df,
                          HOLI_STR* holi,
                          ITERCTRL* ictrl,
                          FL64*     res,
                          MODELSTAT* mdls) ;

extern BOOLE SwaptionCC_HW2Impl(HWPARMS*  parms,
                            FL64      price,
                            CCSWAPTION* swpt,
                            DISCFAC*  df,
                            HOLI_STR* holi,
                            ITERCTRL* ictrl,
                            FL64*     res) ;

extern BOOLE SwaptionNC_HW2Impl(HWPARMS*  parms,
                            FL64      price,
                            NCSWAPTION* swpt,
                            DISCFAC*  df,
                            HOLI_STR* holi,
                            ITERCTRL* ictrl,
                            FL64*     res) ;

extern BOOLE SwapCall_HW2Impl(HWPARMS*  parms,
                                 FL64      price,
                                 SWAPCALL* swpt,
                                 DISCFAC*  df,
                                 VOL_STR*  vol,
                                 HOLI_STR* holi,
                                 ITERCTRL* ictrl,
                                 FL64*     res) ;

extern BOOLE OptBondUS_HW2Impl(HWPARMS*  parms,
                         FL64       price,
                         USBONDOPT* opt,
                         FIXPAY*    fixp,
                         DISCFAC*   df,
                         FL64       oas,
                         ITERCTRL*  ictrl,
                         FL64*      res) ;

extern FL64ARRAY DKmbs_BDT2ScenBPV(DATESTR  *analys,
                              DISCFAC    *df,
                              VOL_STR    *vol,
                              DKMBSMODEL *dkm,
                              FL64       fx_spot,
                              DKMBS      *mbs,
                              DFSPREAD   *oas,
                              DFSPREAD   *oas_d,
                              DELTASET   *ds,
                              FXSHOCKSET *fxs,
                              BOOLE      *ok);

extern RISKPOSLIST DKmbs_BDT2RiskPos(DATESTR    *analys,
                                         DKMBS      *mbs,
                                         FL64       Notnal,
                                         DISCFAC    *df,
                                         VOL_STR    *vol,
                                         DKMBSMODEL *dkm,
                                         DFSPREAD   *oas,
                                         DFSPREAD   *oas_d,
                                         DELTASET   *ds,
                                         FXRISKSET  *FXr, 
                                         BOOLE      *ok) ;


/* Private functions */
extern MODELSTAT Swaption_HW2ModelStat(SWAPTION *swpt) ;
extern MODELSTAT Caplets_HW2ModelStat(CAPLETS *capl) ;
extern MODELSTAT Caption_HW2ModelStat(CAPTION* capt) ;
extern MODELSTAT SwapFl_HW2ModelStat(SWAPFLOAT *sfl) ;
extern BOOLE     HW_IsClosedFormFeasible(HWPARMS* parms) ;

/*** routines in hwcf.c *******************************************/


/* Public functions */

extern FL64 SwapDiff_HWCF2NPV(DATESTR   *analys,
                       DIFFSWAP  *diff,
                       DISCFAC   *df_f,
                       DISCFAC   *df_d,
                       HWCFDIFF  *hwcd,
                       HOLI_STR  *holi,
                       RISKSET   *risk,
                       FL64      *dp,
                       FL64      *ddp) ;

extern FL64 Cap_HWCF2P(DATESTR   *analys,
                    DATESTR   *voldate,
                    CAP       *cap,
                    DISCFAC   *df,
                    HWCFPARMS *hwc,
                    HOLI_STR  *holi,
                    RISKSET   *risk,
                    FL64      *dp,
                    FL64      *ddp) ;

extern FL64 Caplets_HWCF2P(DATESTR   *analys,
                    DATESTR   *voldate,
                    CAPLETS   *cap,
                    DISCFAC   *df,
                    HWCFPARMS *hwc,
                    HOLI_STR  *holi,
                    RISKSET   *risk,
                    FL64      *dp,
                    FL64      *ddp) ;

extern BOOLE Caption_HWCF2P(DATESTR   *analys,
                     DATESTR   *voldate,
                     CAPTION   *cap,
                     DISCFAC   *df,
                     HWCFPARMS *hwc,
                     HOLI_STR  *holi,
                     RISKSET   *risk,
                     FL64      *p,
                     FL64      *dp,
                     FL64      *ddp) ;

extern BOOLE Swaption_HWCF2P(DATESTR    *analys,
                      DATESTR    *voldate,
                      SWAPTION   *ncsw,
                      DISCFAC    *df,
                      HWCFPARMS  *hwc,
                      HOLI_STR   *holi,
                      RISKSET    *risk,
                      FL64       *p,
                      FL64       *dp,
                      FL64       *ddp) ;

extern BOOLE OptFutBond_HWCF2P(DATESTR   *analys,
                   DATESTR   *voldate,
                   FIXPAY    *fixp,
                   OPTFUT    *opt,
                   DISCFAC   *df,
                   HWCFPARMS *hwc,
                   HOLI_STR  *holi,
                   RISKSET   *risk,
                   FL64      *p,
                   FL64      *dp,
                   FL64      *ddp) ;

extern BOOLE OptBond_HWCF2P(DATESTR   *analys,
                   DATESTR   *voldate,
                   FIXPAY    *fixp,
                   OPTFUT    *opt,
                   DISCFAC   *df,
                   HWCFPARMS *hwc,
                   HOLI_STR  *holi,
                   RISKSET   *risk,
                   FL64      *p,
                   FL64      *dp,
                   FL64      *ddp) ;

extern HWCFPARMS Set_HWCFPARMS(FL64 a, FL64 sigma) ;


/* Private functions */

extern FL64ARRAY Caplets_HWCF2Rstar(DATESTR   *analys,
                         DATESTR   *PVdate,
                         FL64      npv,
                         CAPLETS   *cap,
                         DISCFAC   *df,
                         HWCFPARMS *hwc,
                         HOLI_STR  *holi,
                         BOOLE     *ok,
                         FL64      *r) ;

extern FL64ARRAY Caplets_HWCF2P_Array(DATESTR   *analys,
                    DATESTR   *voldate,
                    CAPLETS   *cap,
                    DISCFAC   *df,
                    HWCFPARMS *hwc,
                    HOLI_STR  *holi) ;

extern FL64 OptZBond_HWCF2P(DATESTR *analys,
                     DATESTR *voldate,
                     DISCFAC *df,
                     FL64    a,
                     FL64    sigma,
                     DATESTR *opt_matur,
                     DATESTR *bond_matur,
                     FL64    x,
                     FL64    dsc,
                     OPTTYPE type,
                     CALCONV cal) ;

extern FL64 HWCF_Get_AtT(DATESTR   *analys,
                  DISCFAC   *df,
                  HWCFPARMS *hwc,
                  DATESTR   *date_t,
                  DATESTR   *date_T,
                  FL64      *BtT) ;

extern BOOLE HWCF_Impl_r(DATESTR   *analys,
                  FL64      npv,
                  DISCFAC   *df,
                  HWCFPARMS *hwc,
                  DATESTR   *date,
                  CFLWARRAY xcflw,
                  FL64      *r) ;

extern FL64 HWCF_Get_Sigma(FL64 sigma, FL64 a, FL64 t1, FL64 dt) ;

extern FL64 HWCF_Get_vtT(FL64 sigma, FL64 a, FL64 t1) ;

extern PLANARRAY HWCF_set_DF(DATESTR *date, DATEARRAY dates, FL64ARRAY AtT,
                             FL64ARRAY BtT, INTI n, FL64 r) ;

extern void HWCF_SetITERCTRL(ITERCTRL  *ctrl,
                                FL64      *shock) ;

extern HWCFINT HWCF_SetHWCFINT(HWCFTYPE      type,
                                   FL64          npv,
                                   DATESTR       *PVdate,
                                   DATEARRAY     dates,
                                   INTI          ndates,
                                   PAYDAYDEF     *pday,
                                   FL64ARRAY     AtT,
                                   FL64ARRAY     BtT,
                                   void          *instr,
                                   DISCFAC       *df,
                                   HWCFPARMS     *hwc,
                                   HOLI_STR      *holi,
                                   RISKSET       *orsk,
                                   FL64          shock) ;

extern void HWCF_GetHWCFINT(HWCFINT       *hwcf_data,
                                HWCFTYPE      *type,
                                FL64          *npv,
                                DATESTR       **PVdate,
                                DATEARRAY     *dates,
                                INTI          *ndates,
                                PAYDAYDEF     **pday,
                                FL64ARRAY     *AtT,
                                FL64ARRAY     *BtT,
                                void          **instr,
                                DISCFAC       **df,
                                HWCFPARMS     **hwc,
                                HOLI_STR      **holi,
                                RISKSET       **orsk,
                                FL64          *shock) ;

extern BOOLE HWCF_NewtonRaphson(FL64  x, 
                                void   *y,
                                BOOLE  grad,
                                FL64   *fx, 
                                FL64   *dfx) ;

/*** routines in hwfit.c ***********************************************/


/* Public functions */
extern BOOLE Fit_Caplets2HWCF(DATESTR   *analys,
                        DATESTR   *voldate,
                        CAPLETSARRAY  cap,
                        FL64ARRAY prices,
                        INTI      ncap,
                        DISCFAC   *df,
                        HOLI_STR  *holi,
                        BOOLE     weight,
                        HWCFPARMS *hwc,
                        FL64      *obj) ;

extern BOOLE Fit_Cap2HWCF(DATESTR*     analys,
                        DATESTR*   voldate,
                        CAPARRAY   cap,
                        FL64ARRAY  prices,
                        INTI       ncap,
                        DISCFAC*   df,
                        HOLI_STR*  holi,
                        BOOLE      weight,
                        HWCFPARMS* hwc,
                        FL64*      obj);

extern BOOLE Fit_Swaption2HWCF(DATESTR   *analys,
                        DATESTR   *voldate,
                        SWAPTIONARRAY  ncsw,
                        FL64ARRAY prices,
                        INTI      nsec,
                        DISCFAC   *df,
                        HOLI_STR  *holi,
                        BOOLE     weight,
                        HWCFPARMS *hwc,
                        FL64      *obj) ;

extern BOOLE Fit_OptBond2HWCF(DATESTR   *analys,
                        DATESTR   *voldate,
                        FIXPAYARRAY fixp,
                        OPTFUTARRAY opt,
                        FL64ARRAY prices,
                        INTI      nsec,
                        DISCFAC   *df,
                        HOLI_STR  *holi,
                        BOOLE     weight,
                        HWCFPARMS *hwc,
                        FL64      *obj) ;

/* Private functions */
extern int HWCF_abs_prices(int *ncoef,
                           int *nsec,
                           double *coefs,
                           void *data,
                           double *f) ;

extern BOOLE HWCF_sec2HWCFPARMS(INTI      nsec,
                        HWCFPARMS *hwc,
                        FL64      *obj,
                        HWFITDATA *sDATA) ;


#ifdef __cplusplus
}
#endif

#endif

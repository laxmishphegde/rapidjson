#ifndef BONDIO_H
#define BONDIO_H

#include <sccsid.h>
SCCSID(bondio_h,
  "@(#)bondio.h	1.8 (SimCorp) 99/11/15 14:04:43")

/************************************************************************
*                                                                       *
*   project     SCecon                                                  *
*                                                                       *
*   file name   str2conv.h                                              *
*                                                                       *
*   general     This file contains the header file for the example code *
*               in str2conv.c                                           *
*                                                                       *
************************************************************************/

/*** includes **********************************************************/
#include <stdio.h>
#include <string.h>
#include <bond.h>
#include <swap.h>
#include <bootsec.h>
#include <str2conv.h>
#include <idxbond.h>
#include <riskpos.h>
#include <scenario.h>

#ifdef __cplusplus
extern "C" {
#endif


extern ODDCONV     Str2ODDCONV(TEXT txt) ;
extern COUPONBASE  Str2COUPONBASE(TEXT txt) ;
extern EXDAYCONV   Str2EXDAYCONV(TEXT txt) ;
extern YTMSEG      Str2YTMSEG(TEXT txt) ;
extern BONDSEG     Str2BONDSEG(TEXT txt) ;
extern FIXDCOMP    Str2FIXDCOMP(TEXT txt) ;
extern RATECONV    Str2RATECONV(TEXT txt) ;
extern PREPAYCONV  Str2PREPAYCONV(TEXT txt) ;
extern BSECTYPE    Str2BSECTYPE(TEXT txt) ;
extern INDEXLOANTYPE Str2INDEXLOANTYPE(TEXT txt) ;

extern INDEXLOANTYPE Read_INDEXLOANTYPE(FILE* in, FILE* out, TEXT dscr) ;
extern BSECTYPE Read_BSECTYPE(FILE *in, FILE *out, TEXT dscr);
extern HZYCONV   Read_HZYCONV(FILE* in, FILE* out) ;
extern PREPAYCONV Read_PREPAYCONV(FILE *in, FILE *out, TEXT dscr);
extern YTMCONV   Read_YTMCONV(FILE *in, FILE *out) ;
extern ODDCONV Read_ODDCONV(FILE *in, FILE *out, TEXT dscr);
extern COUPONBASE Read_COUPONBASE(FILE *in, FILE *out, TEXT dscr);
extern EXDAYCONV Read_EXDAYCONV(FILE *in, FILE *out, TEXT dscr);  
extern YTMSEG Read_YTMSEG(FILE *in, FILE *out, TEXT dscr);     
extern BONDSEG Read_BONDSEG(FILE *in, FILE *out, TEXT dscr);    
extern RATECONV Read_RATECONV(FILE *in, FILE *out, TEXT dscr);   
extern FIXDCOMP Read_FIXDCOMP(FILE *in, FILE *out, TEXT dscr);


extern PAYDAYDEF Read_PAYDAYDEF(FILE *in, FILE *out) ;
extern DEPOSIT   Read_DEPOSIT(FILE *in, FILE *out) ;
extern CFLWARRAY Read_CFLWARRAY(FILE *in, FILE *out) ;
extern FIXPAY    Read_FIXPAY(FILE *in, FILE *out, DATESTR *settle) ;
extern REPAYMNT  Read_REPAYMNT(FILE *in, FILE *out) ;
extern PAYDAYSEQ Read_PAYDAYSEQ(FILE *in, FILE *out) ;
extern FIXRATE   Read_FIXRATE(FILE *in, FILE *out) ;
extern ACCRUINT  Read_ACCRUINT(FILE *in, FILE *out) ;
extern EXRULE    Read_EXRULE(FILE *in, FILE *out) ;
extern TAXINFO   Read_TAXINFO(FILE *in, FILE *out) ;
extern TRADEINFO Read_TRADEINFO(FILE *in, FILE *out) ;
extern EXTRADE   Read_EXTRADE(FILE *in, FILE *out) ;
extern SWAPFIX   Read_SWAPFIX(FILE *in, FILE *out) ;
extern PP_STR    Read_PP_STR(FILE *in, FILE *out) ;
extern BONDBM     Read_BONDBM(FILE *in, FILE *out) ;
extern AIRESULT   Read_AIRESULT(FILE *in);
extern INDEXLOAN  Read_INDEXLOAN(FILE *in, FILE *out) ;
extern INDEXFAC   Read_INDEXFAC(FILE *in, FILE *out) ;
extern INDEXBOND  Read_INDEXBOND(FILE *in, FILE *out, DATESTR *settle) ;


extern BSEC      Read_BSEC(FILE    *in, 
                       FILE    *out,
                       FL64    *price, 
                       FL64    *spr, 
                       FL64    *madj,
                       DATESTR *settle) ;

extern void Read_Boot_MM(FILE *in, FILE *out, BSEC *bsec,
                         FL64 *price, FL64 *spr) ;
extern void Read_Boot_IRF(FILE *in, FILE *out, BSEC *bsec,
                          FL64 *price, FL64 *spr, FL64 *madj) ;
extern void Read_Boot_AVGIRF(FILE *in, FILE *out, BSEC *bsec,
                             FL64 *price, FL64 *spr) ;
extern void Read_Boot_FRA(FILE *in, FILE *out, BSEC *bsec,
                          FL64 *price, FL64 *spr) ;
extern void Read_Boot_IMMFRA(FILE *in, FILE *out, BSEC *bsec,
                          FL64 *price, FL64 *spr) ;
extern void Read_Boot_SWAP(FILE *in, FILE *out, BSEC *bsec,
                           FL64 *price, FL64 *spr) ;
extern void Read_Boot_BOND(FILE *in, FILE *out, BSEC *bsec,
                           FL64 *price, FL64 *spr, DATESTR *settle) ;
extern void Read_Boot_BONDSMPL(FILE *in, FILE *out, BSEC *bsec,
                               FL64 *price, FL64 *spr, DATESTR *settle) ;
extern void Read_Boot_BONDREPO(FILE *in, FILE *out, BSEC *bsec,
                               FL64 *price, FL64 *spr, DATESTR *settle) ;
extern void Read_Boot_SWAPGENR(FILE *in, FILE *out, BSEC *bsec,
                               FL64 *price, FL64 *spr) ;
extern void Read_Boot_SWAPFUT(FILE* in, FILE* out, BSEC* bsec,
                              FL64* price, FL64* spr);


extern INTI Write_CflwDiff(CFLWARRAY exp, CFLWARRAY res, FILE *out) ;


/***********************************************************/
/* riskpos and scenario */

extern void Str2CCYCODE(TEXT txt, CCYCODE* ccy) ;
extern void CCYCODE2Str(CCYCODE ccy, TEXT txt) ;
extern void Str2RISKCLASS(TEXT txt, size_t size, RISKCLASS* rclass) ;
extern void RISKCLASS2Str(RISKCLASS rclass, TEXT txt) ;

extern FXSHOCKSET Read_FXSHOCKSET(FILE *in, FILE *out);
extern SCENARIOLIST Read_SCENARIOLIST(FILE *in, FILE *out) ;

extern void Read_CCYCODE(FILE *in, FILE *out, CCYCODE *ccy);
extern CCYCODEARRAY Read_CCYCODEARRAY(FILE* in, FILE* out, INTI* nrf) ;
extern      FXRISKSET Read_FXRISKSET(FILE *in, FILE *out) ;
extern void Read_RISKTOKEN(FILE *in, FILE *out, RISKTOKEN * rt) ;
extern      RISKTOKENARRAY Read_RISKTOKENARRAY(FILE *in, FILE *out, 
                                               INTI *nrf);
extern      RISKPOSLIST Read_RISKPOSLIST(FILE *in, FILE *out) ;

extern INTI      Write_FXSHOCKSETDiff(FXSHOCKSET *exp, FXSHOCKSET *res, 
                    FILE *out, FL64 tol) ;

extern void Write_RISKTOKEN(FILE *out, RISKTOKEN *r) ;
extern      INTI Write_riskposdiff(RISKPOSLIST exp, RISKPOSLIST res, 
                                   FILE *out, FL64 tol) ;

#ifdef __cplusplus
}
#endif


#endif



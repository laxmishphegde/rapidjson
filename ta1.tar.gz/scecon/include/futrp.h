/* SCID @(#)futrp.h	1.3 (SimCorp) 99/02/19 14:13:20 */

#ifndef FUTRP_H
#define FUTRP_H

/************************************************************************
*                                                                       *
*    project    SCecon                                                  *
*                                                                       *
*    filename   riskpos.h                                               *
*                                                                       *
*    this file contains definitions and function prototyping for the    *
*    routines in the SCecon RiskPos module                              *
*                                                                       *
************************************************************************/

/***** includes ********************************************************/
#include <frn.h>
#include <swapval.h>
#include <riskpos.h> 


/***** C++ Convenience *************************************************/
#ifdef __cplusplus
extern "C" {
#endif


extern RISKPOSLIST FutBond_DF2RiskPos(DATESTR   *analys,
                               FUTBOND   *futb,
                               INTI      noas,
                               DFSPREADARRAY dfsarr,
                               FL64      fwd,
                               FL64      Notnal,
                               DISCFAC   *df,
                               HOLI_STR  *holi,
                               DELTASET  *ds,
                               FXRISKSET *FXr) ;


extern RISKPOSLIST RepoBond_DF2RiskPos(DATESTR   *analys,
                                REPOBOND  *repo,
                                FL64      Notnal,
                                DISCFAC   *df,
                                DFSPREAD  *dfs,
                                HOLI_STR  *holi,
                                DELTASET  *ds,
                                FXRISKSET *FXr) ;

extern RISKPOSLIST FRA_DF2RiskPos(DATESTR   *analys,
                           FRA_STR   *fra,
                           FL64      Notnal,
                           DISCFAC   *df,
                           HOLI_STR  *holi,
                           DELTASET  *ds,
                           FXRISKSET *FXr) ;

extern RISKPOSLIST IRF_DF2RiskPos(DATESTR   *analys,
                           FRA_STR   *irf,
                           FL64      Notnal,
                           DISCFAC   *df,
                           HOLI_STR  *holi,
                           DELTASET  *ds,
                           FXRISKSET *FXr) ;

extern RISKPOSLIST SwapFix_DF2RiskPos(DATESTR       *analys,
                                       SWAPFIX       *sfix,
                                       FL64          Notnal,
                                       DISCFAC       *df,
                                       HOLI_STR      *holi,
                                       DELTASET      *ds,
                                       FXRISKSET     *FXr) ;

extern RISKPOSLIST SwapFl_DF2RiskPos(DATESTR       *analys,
                                      SWAPFLOAT     *sfl,
                                      FL64          Notnal,
                                      DISCFAC       *df_cflw,
                                      DISCFAC       *df_disc,
                                      CMCONVADJ     *cmadj,
                                      HOLI_STR      *holi,
                                      DELTASET      *ds_cflw,
                                      DELTASET      *ds_disc,
                                      FXRISKSET     *FXr) ;

extern RISKPOSLIST FRN_DF2RiskPos(DATESTR      *analys,
                                      FRN          *frn,
                                      FL64         Notnal,
                                      DISCFAC      *df_cflw,
                                      DISCFAC      *df_disc,
                                      CMCONVADJ    *cmadj,
                                      HOLI_STR     *holi,
                                      DFSPREAD     *dfs,
                                      DELTASET     *ds_cflw,
                                      DELTASET     *ds_disc,
                                      FXRISKSET    *FXr) ;



#ifdef __cplusplus
}
#endif

#endif

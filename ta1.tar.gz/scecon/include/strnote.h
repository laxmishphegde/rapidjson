/* @(#)strnote.h	1.9 (SimCorp) 99/02/19 14:10:30 */

#ifndef STRNOTE_H
#define STRNOTE_H

/************************************************************************
*                                                                       *
*    project     SCecon                                                 *
*                                                                       *
*    general     this file contains declarations, initializations,      *
*                type definitions and function prototyping for the      *
*                swap module of the standard library SCecon             *
*                                                                       *
************************************************************************/

/**** includes *********************************************************/
#include <disc.h>
#include <option.h>
#include <swapval.h>
#include <vol.h>
#include <riskpos.h>

/**** C++ convenience **************************************************/
#ifdef __cplusplus
extern "C" {
#endif


/*** typedefines *******************************************************/



/*,,SOT,,

ACCRNOTE: Data type for defining Accrual Notes
----------------------------------------------

This type is defined as:

        typedef struct accrnote_tag
        {
            PAYDAYDEF   pday ;
            FL64        fix_rate ;
            CALCONV     cal ;
            DATESTR     effective ;
            PLAN_STR    *stepcoup ;
            BOOLE       busonly ;
            BOOLE       io ;
            DATESTR     nextfix ;
            FL64        accru ;
            PERIOD      period ;
            RATEINDEX   index ;
            PLAN_STR    *low ;
            PLAN_STR    *up ;
        }   ACCRNOTE ;

where

    pday     defines the interest payment dates of the note

    fix_rate The coupon.

    cal      The calendar used for coupon calculation

    effective The date from which coupons are accrued.

    stepcoup|NULL is used for informing on stepped coupon plans
             (sometimes referred to as rate adjustments).

    busonly  If True interest only accru on businessdays.
             If False interest accru on any day

    io       True if interest only, False if Bullet redemption.

    nextfix  The next fixing date. Can be effective date.
             For seasoned notes it is later than effective date.
             If pricing at issue then nextfix is usually equal to
             effective date.

    accru    If nextfix is not 'today' or a payday, then accru is
             the amount accrued so far on the next coupon (undiscounted).

    period   The fixing period.

    index    The fixing index. Could be 3M LIBOR, 5Y CMT or ...

    low|NULL The lower bound (range) on the note,
             If 0 then there is no lower bound. Can be stepped.
             If low is NULL then 0 is assumed to be the boundary.

    up|NULL  The upper bound (range),
             If 'large' then there is no upper bound. Can be stepped.
             Each 'up >= low'
             If up is NULL then 'infinity' is assumed to be the boundary.


Accrual notes are securities that accrue interest with some frequency
(term / unit). Each coupon payment is the sum of interest accrued over
the entire coupon period. However, interest only accrues when the index
(LIBOR, CMT, ..) is within some range defined by low and up.
This range may vary over time.

An accrual note is essentially a portfolio of Digital IR Options, and
can therefore be priced using Black76.

The fixing frequency can be daily, weekly, monthly or any other period.

The coupon accrued is fixed a priori (as opposed to Range Floaters) where
the amount accrued is equal to the index.

CMT/CMS Indices are handled by using a convexity adjustment
(as for CMT swaps).

,,EOT,,*/

typedef struct accrnote_tag
{
    PAYDAYDEF   pday ;
    FL64        fix_rate ;
    CALCONV     cal ;
    DATESTR     effective ;
    PLAN_STR    *stepcoup ;
    BOOLE       busonly ;
    BOOLE       io ;
    DATESTR     nextfix ;
    FL64        accru ;
    PERIOD      period ;
    RATEINDEX   index ;
    PLAN_STR    *low ;
    PLAN_STR    *up ;
}   ACCRNOTE ;


/*,,SOT,,

RANGENOTE: Data type for defining Range Notes / Floaters
--------------------------------------------------------

This type is defined as:

        typedef struct rangenote_tag
        {
            PAYDAYDEF   pday ;
            FLOATBASE   fbase ;
            BOOLE       busonly ;
            BOOLE       io ;
            DATESTR     nextfix ;
            INTI        term ;
            TERMUNIT    unit ;
            RATEINDEX   index ;
            PLAN_STR    *low ;
            PLAN_STR    *up ;
        }   RANGENOTE ;

where

        pday defines the interest payment dates of the note

        fbase are the data for generating payments.
        fbase.coupon1 is the amount accrued so far for the coming coupon
        (if fbase.is_fix is True).

        busonly - If True interest only accru on businessdays.
        If False interest accru on any day

        io - True if interest only, False if Bullet redemption.

        nextfix is the next fixing date. Can be effective date.
        For seasoned notes it is later than effective date.
        If pricing at issue then nextfix is usually equal to
        effective date.

        term - The fixing period.

        unit - Unit for term (e.g 1 WEEKS, 1 DAYS)

        index - The fixing index. Could be 3M LIBOR, 5Y CMT or ...

        low - The lower bound (range) on the note,
        If 0 then there is no lower bound. Can be stepped.

        up - The upper bound (range),
        If 'large' then there is no upper bound. Can be stepped.
        Each 'up >= low'


Range notes are securities that accrue interest with some frequency
(term / unit). Each coupon payment is the sum of interest accrued over
the entire coupon period. However, interest only accrues when the index
(LIBOR, CMT, ..) is within some range defined by low and up.
This range may vary over time.

An range note is essentially a portfolio of Digital IR Options, and
can therefore be priced using Black76.

The fixing frequency can be daily, weekly, monthly or any other period.

The coupon accrued is the index prevailing for the specified period
(as opposed to Accrual Notes where the amount accrued is equal to a
fix coupon).

CMT/CMS Indices are handled by using a convexity adjustment
(as for CMT swaps).

,,EOT,,*/

typedef struct rangenote_tag
{
    PAYDAYDEF   pday ;
    FLOATBASE   fbase ;
    BOOLE       busonly ;
    BOOLE       io ;
    DATESTR     nextfix ;
    INTI        term ;
    TERMUNIT    unit ;
    RATEINDEX   index ;
    PLAN_STR    *low ;
    PLAN_STR    *up ;
}   RANGENOTE ;


/*,,SOT,,

RESETACCRNOTE: Data type for defining Resetable Accrual Notes
-------------------------------------------------------------

This type is defined as:

        typedef struct resetaccrnote_tag
        {
            PAYDAYDEF   pday ;
            DATESTR     effective ;
            CALCONV     cal ;
            FL64        spread ;     
            BOOLE       busonly ;
            BOOLE       io ;
            DATESTR     nextfix ;    
            FL64        accru ;      
            BOOLE       is_fix ;     
            FL64        currMid ;    
            FL64        resetRange ;
            PERIOD      accr_per ;   
        }   RESETACCRNOTE ;

where

        pday defines the interest payment dates of the note

        effective is interest start date

        cal is the calendar for interest accrual

        spread is the extra spread added to the payoff function

        busonly - If True interest only accru on businessdays.
        If False interest accru on any day

        io - True if interest only, False if Bullet redemption.

        nextfix is the next 'accrual' fixing date (i.e not range fixing)
        Can be effective date. For seasoned notes it is later than 
        effective date. If pricing at issue then nextfix is usually equal to
        effective date.

        accru - If nextfix is not 'PVdate' or a payday, then accru is
        the amount accrued so far in the current interest period
        (undiscounted).

        is_fix. If True then the mid point of the current period has
        been fixed (relevant for seasoned notes).

        currMid is the current mid point fixing. Only used if is_fix
        is True.

        resetRange is the band that defines the new range.

        accr_per - is the frequency with which the note accrues.
        E.g. 1 DAYS for daily accrual.

Reset Accrual Notes are securities that accrue interest with some frequency
(term / unit). Each interest payment is the sum of interest accrued over
the entire coupon period. However, interest only accrues when the index
(LIBOR, CMT, ..) is within some range. The range is RESET on every interest
payment date - at the noteholders discretion.

The accrual fixing frequency can be daily, weekly, monthly or any other period.

When pricing reset accruals one should be careful about choosing volatility 
curves. Individual periods in Reset Notes are forward starting instruments
and the vol should reflect this. One way of calculating vol for reset notes
is to take a FORWFORW vol curve and use Vol_Spot2Forw() to generate a forward 
starting vol curve. The dates for which to calculate the forward starting vol 
are the reset days. These forward starting vols are then entered in a VOL_STR 
on the fixing dates.

,,EOT,,*/

typedef struct resetaccrnote_tag
{
    PAYDAYDEF   pday ;
    DATESTR     effective ;
    CALCONV     cal ;
    FL64        spread ;     /* Over reset fixing */

    BOOLE       busonly ;
    BOOLE       io ;

    DATESTR     nextfix ;    /* Next accrual fixing - e.g. daily */
    FL64        accru ;      /* Accrued amount sofar */
    BOOLE       is_fix ;     /* Id currMid fixed ? */
    FL64        currMid ;    /* Current fixing of index for whole period */
    FL64        resetRange ;

    PERIOD      accr_per ;   /* Accrual period */
}   RESETACCRNOTE ;


/*,,SOT,,

BLACKDIFF: Model parameters for pricing Diff Swaps using Black 76
--------------------------------------------------------------------

This type is defined as:

        typedef struct blackdiff_tag
        {
          VOL_STR vol_y ;
          VOL_STR vol_d ;
          VOL_STR vol_x ;
          VOL_STR vol_f ;
          FL64    corr_xy ;
          FL64    corr_dy ;
          FL64    corr_fy ;
          CMADJTYPE cmadj ;
        } BLACKDIFF ;

where
        vol_y is the (log) volatility structure of the foreign index 
        rate. This vol is quoted as a percentage.

        vol_d is the (log) volatility structure of the domestic LIBOR 
        (disocunting) rate. This vol is quoted as a percentage.

        vol_x is the (log) volatility structure of the FX rate (between foreign
        and domestic currencies) - quoted as percentage (15.0 for 15%)

        vol_f is the (log) volatility structure of the foreign LIBOR
        (discounting) rate. This vol is quoted as a percentage.
        NOTE: MUST be equal to vol_y for LIBOR indexed swap

        corr_xy is the correlation between the FX rate and 
        the foreign index rate.

        corr_dy is the correlation between the domestic discounting rate 
        and the foreign index rate.

        corr_fy is the correlation between the foreign discounting rate 
        and the foreign index rate.
        NOTE: MUST be 1.0 for LIBOR indexed swap.

        cmadj determines the convexity adjustment to be used 
        Relevant only for non-standard index

The type is used for pricing differential swaps using a method based on
standard risk-neutral reasoning (a la Black 76). 

,,EOT,,*/

typedef struct blackdiff_tag
{
  VOL_STR   vol_y ;
  VOL_STR   vol_d ;
  VOL_STR   vol_x ;
  VOL_STR   vol_f ;
  FL64      corr_xy ;
  FL64      corr_dy ;
  FL64      corr_fy ;
  CMADJTYPE cmadj ;
} BLACKDIFF ;


/*,,SOT,,

OPTSPREAD: Spread Options
-------------------------

This type is defined as:

        typedef struct optspread_tag
        {
            OPTTYPE   type ;
            FL64      strike ;
            IRRCONV   irr ;
            PMTFREQ   freq ;
            CALCONV   cal ;
            DATESTR   dfix ;
            DATESTR   dpay ;
            RATEINDEX idx1 ;
            RATEINDEX idx2 ;
            OPTADD    oadd ;
            BINARYINF bini ;
        }   OPTSPREAD ;

Where

        type is the option type CALL, PUT or STRADDLE.

        strike is the strike spread in pct.

        irr is the interest rate convention for the quoted spread.

        freq is the compound frequency of the quoted spread.

        cal is the calendar convention for finding the term till
        fixing and payment.

        dfix is the fixing date.

        dpay is the payment date.

        idx1 is the index definition for the first index.
        Assumes that idx1.LIBORtype == MMRATE. Only idx1.LIBORdur,
        idx1.LIBORunit, and idx1.LIBORcal are used.

        idx2 is the index definition for the second index
        Assumes that idx2.LIBORtype == MMRATE. Only idx2.LIBORdur,
        idx2.LIBORunit, and idx2.LIBORcal are used.

In addition to these basic features some ADDITIONAL terms and conditions
can be invoked: (not implemented as union due to APL-Interface).

        oadd indicates whether additional features are used. Default is
        NO_OPTADD. If oadd is not NO_OPTADD some 'exotic' option features
        can be defined as follows:

        oadd = BINARY:
        bini defines a binary, asset-or-nothing, or gap option


This struct is used to value a spread option where the spread
is given by idx2 - idx1. The quoting convention of the spread
is given by irr and freq.

,,EOT,,*/

typedef struct optspread_tag
{
    OPTTYPE   type ;
    FL64      strike ;
    IRRCONV   irr ;
    PMTFREQ   freq ;
    CALCONV   cal ;
    DATESTR   dfix ;
    DATESTR   dpay ;
    RATEINDEX idx1 ;
    RATEINDEX idx2 ;
    OPTADD    oadd ;
    BINARYINF bini;
}   OPTSPREAD ;



/*** function prototyping (diffswap.c) *********************************/


/* Public functions */
extern FL64 SwapDiff_Black2NPV(DATESTR*   analys,
                                  DIFFSWAP*  diff,
                                  DISCFAC*   df_f,
                                  DISCFAC*   df_d,
                                  BLACKDIFF* blckd,
                                  HOLI_STR*  holi,
                                  RISKSET*   risk,
                                  FL64*      dp,
                                  FL64*      ddp) ;

extern FL64ARRAY SwapDiff_Black2Delta(DATESTR*      analys,
                                         DIFFSWAP*     diff,
                                         DISCFAC*      df_f,
                                         DISCFAC*      df_d,
                                         BLACKDIFF*    blckd,
                                         HOLI_STR*     holi,
                                         DELTASET*     ds) ;

extern RISKPOSLIST SwapDiff_Black2RiskPos(DATESTR*     analys,
                                              DIFFSWAP*    diff,
                                              FL64         Notnal,
                                              DISCFAC*     df_f,
                                              DISCFAC*     df_d,
                                              BLACKDIFF*   blckd,
                                              HOLI_STR*    holi,
                                              DELTASET*    ds_f,
                                              DELTASET*    ds_d,
                                              FXRISKSET*   FXr) ;

/* Private functions */
extern void      Free_BLACKDIFF(BLACKDIFF *bd) ;


/*** function prototyping (strnote.c) **********************************/


/* Public functions */
extern FL64 AccrNote_Black2P(DATESTR     *analys,
                                DATESTR     *voldate,
                                ACCRNOTE    *acrn,
                                DISCFAC     *df_index,
                                DISCFAC     *df_disc,
                                VOL_STR     *vol,
                                CMCONVADJ *cmadj,
                                HOLI_STR    *holi) ;

extern FL64 RangeNote_Black2P(DATESTR     *analys,
                     DATESTR     *voldate,
                     RANGENOTE   *rngn,
                     DISCFAC     *df_index,
                     DISCFAC     *df_disc,
                     VOL_STR     *vol,
                     CMCONVADJ *cmadj,
                     HOLI_STR    *holi) ;

extern FL64 ResetAccrNote_Black2P(DATESTR*    analys,
                          DATESTR*    voldate,
                          RESETACCRNOTE*  rn,
                          DISCFAC*    df,
                          VOL_STR*    vol,
                          HOLI_STR*   holi) ;

extern ACCRNOTE Set_ACCRNOTE(PAYDAYDEF* pday,
                          FL64       fix_rate,
                          CALCONV    cal,
                          DATESTR*   effective,
                          PLAN_STR*  stepcoup,
                          BOOLE      busonly,
                          BOOLE      io,
                          DATESTR*   nextfix,
                          FL64       accru,
                          PERIOD*    period,
                          RATEINDEX* index,
                          PLAN_STR*  low,
                          PLAN_STR*  up) ;

extern void Free_RESETACCRNOTE(RESETACCRNOTE *r) ;

extern void Free_ACCRNOTE(ACCRNOTE* ds);

extern void Free_RANGENOTE(RANGENOTE* ds);

extern FL64 OptSpread_Black2P(DATESTR*   analys,
                                  DATESTR*   voldate,
                                  OPTSPREAD* opt,
                                  DISCFAC*   df_1,
                                  DISCFAC*   df_2,
                                  DISCFAC*   df_disc,
                                  VOL_STR*   vol,
                                  HOLI_STR*  holi,
                                  RISKSET*   risk,
                                  BOOLE      Black,
                                  FL64*      dp,
                                  FL64*      ddp) ;

extern OPTSPREAD Set_OPTSPREAD(OPTTYPE    type,
                                  FL64       strike,
                                  IRRCONV    irr,
                                  PMTFREQ    freq,
                                  CALCONV    cal,
                                  DATESTR*   dfix,
                                  DATESTR*   dpay,
                                  RATEINDEX* idx1,
                                  RATEINDEX* idx2) ;


/* Private functions */
extern FL64 AccrNote_Unit_Payoff(DATESTR* analys,
                        DATESTR* voldate,
                        DATESTR* dfix,
                        FL64     fwd,
                        FL64     low,
                        FL64     up,
                        FL64     vol,
                        FL64     disc, 
                        FL64     accr,    
                        FL64     dt,      
                        CALCONV  cal) ;

extern FL64 RangeNote_Unit_Payoff(DATESTR* analys,
                               DATESTR* voldate,
                               DATESTR* dfix,
                               FL64     fwd,
                               FL64     low,
                               FL64     up,
                               FL64     vol,
                               FL64     disc,    
                               FL64     sprd,    
                               FL64     dt,      
                               CALCONV  cal) ;

extern OPTINT accrual_set_OPTINT(OPTTYPE type, FL64 x, FL64 tvol, FL64 tfix,
                                    FL64 tpay, BINARYINF *bini, CALCONV cal) ;


#ifdef __cplusplus
}
#endif

#endif

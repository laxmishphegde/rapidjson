/* SCCS: @(#)strntvl.h	1.2 (SimCorp) 99/02/19 14:10:40 */

#ifndef STRNTVL_H
#define STRNTVL_H

/************************************************************************
*                                                                       *
*    project     SCecon                                                 *
*                                                                       *
*    filename    validate.h                                             *
*                                                                       *
*    general     this file contains declarations, initializations,      *
*                type definitions and function prototyping for the      *
*                validation module of the standard library SCecon       *
*                                                                       *
************************************************************************/

/**** includes *********************************************************/
#include <strnote.h>
#include <validate.h>

#ifdef __cplusplus
extern "C" {
#endif

/*** typedefines *******************************************************/


/*** function prototyping *************************************/


extern VALIDATE Validate_ACCRNOTE(ACCRNOTE* x);

extern VALIDATE Validate_BLACKDIFF(BLACKDIFF* x);

extern VALIDATE Validate_RANGENOTE(RANGENOTE *x);
extern VALIDATE Validate_RESETACCRNOTE(RESETACCRNOTE *x);


#ifdef __cplusplus
}
#endif

#endif

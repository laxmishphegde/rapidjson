/* SCID @(#)opteqty.h	1.13 (SimCorp) 99/10/20 15:02:07 */

#ifndef OPTEQTY_H

#define OPTEQTY_H

/************************************************************************
*                                                                       *
*    project    SCecon                                                  *
*                                                                       *
*    filename   opteqty.h                                               *
*                                                                       *
*    this file contains definitions and function prototyping for the    *
*    routines in the SCecon option pricing module.                      *
*                                                                       *
************************************************************************/

/*** includes **********************************************************/
#include <option.h>
#include <futeqty.h>
#include <scenario.h> 
#include <riskpos.h> 

/***** C++ Convenience *************************************************/
#ifdef __cplusplus
extern "C" {
#endif

/*** typedefs **********************************************************/

/*,,SOT,,

TREEOPT: Type for defining American-Style Options
-------------------------------------------------

This type is defined as:

        typedef struct treeopt_tag
        {
            OPTTYPE   type ;
            FL64      strike ;
            BOOLE     berm ;
            PAYDAYDEF dpay ;
            PERIOD    pay_delay ;
            CALCONV   cal ;
        }   TREEOPT ;

The data have the following interpretations:

        type is the option type.

        strike is the strike level

        berm is True if the option exercises on discretely spaced dates,
        and False if US-Style exercise, i.e. exercise on any date.

        dpay is the definition of the discrete exercise dates. If berm is
        True then all data in dpay are used, if berm is False then only
        dpay.first and dpay.last are used as first and last exercise date.

        pay_delay is the delay from exercise to payment

        cal is the calendar convention for the option used for discounting

,,EOT,,*/

typedef struct treeopt_tag
{
    OPTTYPE   type ;
    FL64      strike ;
    BOOLE     berm ;
    PAYDAYDEF dpay ;
    PERIOD    pay_delay ;
    CALCONV   cal ;
}   TREEOPT ;


/*** macros ************************************************************/


/*** routines in crr.c  *************************************************/

/* Public functions */

extern BOOLE OptFX_CRR2P(DATESTR  *analys,
                     FL64     spot,
                     FL64     vol,
                     INTI     nstep,
                     TREEOPT  *opt,
                     DISCFAC  *df,
                     DISCFAC  *f_df,
                     HOLI_STR *holi,
                     RISKSET  *risk,
                     FL64     *p,
                     FL64     *dp,
                     FL64     *ddp) ;

extern BOOLE OptCmdty_CRR2P(DATESTR  *analys,
                     FL64     spot,
                     FL64     vol,
                     INTI     nstep,
                     TREEOPT  *opt,
                     DISCFAC  *conv_df,
                     DISCFAC  *stor_df,
                     FUTCMDTY *futc,
                     DISCFAC  *df,
                     HOLI_STR *holi,
                     RISKSET  *risk,
                     FL64     *p,
                     FL64     *dp,
                     FL64     *ddp) ;

extern BOOLE OptEqty_CRR2P(DATESTR  *analys,
                     FL64     spot,
                     FL64     vol,
                     INTI     nstep,
                     DISCFAC  *divdf,
                     FUTEQTY  *fute,
                     TREEOPT  *opt,
                     DISCFAC  *df,
                     HOLI_STR *holi,
                     RISKSET  *risk,
                     FL64     *p,
                     FL64     *dp,
                     FL64     *ddp) ;

/* WARNING: TOO MANY ARGS (>15) BELOW */
extern BOOLE OptExch_CRR2P (DATESTR  *analys,
                            FL64     spot1,
                            FL64     spot2,
                            FL64     vol1,
                            FL64     vol2,
                            FL64     corr,
                            DISCFAC  *divyld1,
                            DISCFAC  *divyld2,
                            PLAN_STR *plan1,
                            PLAN_STR *plan2,
                            INTI     nstep,
                            TREEOPT  *opt,
                            HOLI_STR *holi,
                            RISKSET  *risk,
                            FL64     *p,
                            FL64     *dp,
                            FL64     *ddp) ;

/* WARNING: TOO MANY ARGS (>15) BELOW */
extern BOOLE OptExch_CRR2Impl (DATESTR  *analys,
                               FL64     prem,
                               FL64     spot1,
                               FL64     spot2,
                               FL64     vol1,
                               FL64     vol2,
                               FL64     corr,
                               DISCFAC  *divyld1,
                               DISCFAC  *divyld2,
                               PLAN_STR *plan1,
                               PLAN_STR *plan2,
                               INTI     nstep,
                               TREEOPT  *opt,
                               HOLI_STR *holi,
                               KEYCONV  key,
                               ITERCTRL *ctrl,
                               FL64     *impl) ;

extern BOOLE OptFX_CRR2Impl(DATESTR  *analys,
                     FL64     prem,
                     FL64     spot,
                     FL64     vol,
                     INTI     nstep,
                     TREEOPT  *opt,
                     DISCFAC  *df,
                     DISCFAC  *f_df,
                     HOLI_STR *holi,
                     KEYCONV  key,
                     ITERCTRL *ctrl,
                     FL64     *impl) ;

extern BOOLE OptCmdty_CRR2Impl(DATESTR  *analys,
                     FL64     prem,
                     FL64     spot,
                     FL64     vol,
                     INTI     nstep,
                     TREEOPT  *opt,
                     DISCFAC  *conv_df,
                     DISCFAC  *stor_df,
                     FUTCMDTY *futc,
                     DISCFAC  *df,
                     HOLI_STR *holi,
                     KEYCONV  key,
                     ITERCTRL *ctrl,
                     FL64     *impl) ;

extern BOOLE OptEqty_CRR2Impl(DATESTR  *analys,
                     FL64     prem,
                     FL64     spot,
                     FL64     vol,
                     INTI     nstep,
                     DISCFAC  *divdf,
                     FUTEQTY  *fute,
                     TREEOPT  *opt,
                     DISCFAC  *df,
                     HOLI_STR *holi,
                     KEYCONV  key,
                     ITERCTRL *ctrl,
                     FL64     *impl) ;

extern FL64ARRAY OptFX_CRR2Delta(DATESTR  *analys,
                          FL64     spot,
                          FL64     vol,
                          INTI     nstep,
                          TREEOPT  *opt,
                          DISCFAC  *df_d,
                          DISCFAC  *df_f,
                          HOLI_STR *holi,
                          DELTASET  *ds,
                          BOOLE     *ok) ;

extern FL64ARRAY OptEqty_CRR2Delta(DATESTR   *analys,
                        FL64      spot,
                        FL64      vol,
                        INTI      nstep,
                        DISCFAC   *divdf,
                        FUTEQTY   *fute,
                        TREEOPT   *opt,
                        DISCFAC   *df,
                        HOLI_STR  *holi,
                        DELTASET  *ds,
                        BOOLE     *ok) ;




/*** routines in opteqty.c  *********************************************/


/* Public functions */
extern FL64 OptEqty_Black2P(DATESTR *analys,
                    DATESTR *voldate,
                    FL64    spot,
                    FL64    vol,
                    FL64     divyld,
                    FUTEQTY *fute,
                    OPTFUT  *opt,
                    DISCFAC *df,
                    HOLI_STR *holi,
                    RISKSET *risk,
                    FL64    *dp,
                    FL64    *ddp) ;

extern FL64ARRAY OptEqty_Black2Delta(DATESTR  *analys,
                              DATESTR  *voldate,
                              FL64     spot,
                              FL64     vol,
                              FL64     divyld,
                              FUTEQTY  *fute,
                              OPTFUT   *opt,
                              DISCFAC  *df,
                              HOLI_STR *holi,
                              DELTASET *ds) ;

extern BOOLE OptEqty_Black2Impl(DATESTR *analys,
                                DATESTR *voldate,
                                FL64    prem,
                                BOOLE   is_p,
                                FL64    spot,
                                FL64    vol,
                                FL64    divyld,
                                FUTEQTY *fute,
                                OPTFUT  *opt,
                                DISCFAC *df,
                                HOLI_STR *holi,
                                KEYCONV what,
                                ITERCTRL *ctrl,
                                FL64    *impl) ;

extern FL64 OptFutEqty_Black2P(DATESTR  *analys,
                               DATESTR  *voldate,
                               FL64     fwd,
                               FL64     vol,
                               BOOLE    margin,
                               DATESTR  *delv,
                               OPTFUT   *opt,
                               DISCFAC  *df,
                               HOLI_STR *holi,
                               RISKSET  *risk,
                               FL64     *dp,
                               FL64     *ddp) ;

extern FL64 OptFutEqty_Black2DFp(DATESTR *analys,
                        DATESTR *voldate,
                        DATESTR *spotdate,
                        FL64    spot,
                        FL64    vol,
                        OPTFUT  *opt,
                        FUTEQTY *fute,
                        FL64    divyld,
                        DISCFAC *df,
                        HOLI_STR *holi,
                        RISKSET *risk,
                        FL64    *dp,
                        FL64    *ddp) ;

extern FL64ARRAY OptFutEqty_Black2Delta(DATESTR  *analys,
                                 DATESTR  *voldate,
                                 DATESTR  *spotdate,
                                 FL64     spot,
                                 FL64     vol,
                                 FL64     divyld,
                                 FUTEQTY  *fute,
                                 OPTFUT   *opt,
                                 DISCFAC  *df,
                                 HOLI_STR *holi,
                                 DELTASET *ds) ;

extern BOOLE OptFutEqty_Black2Impl(DATESTR  *analys,
                                   DATESTR  *voldate,
                                   FL64     prem,
                                   BOOLE    is_p,
                                   FL64     fwd,
                                   FL64     vol,
                                   BOOLE    margin,
                                   DATESTR  *delv,
                                   OPTFUT   *opt,
                                   DISCFAC  *df,
                                   HOLI_STR *holi,
                                   KEYCONV  what,
                                   ITERCTRL *ctrl,
                                   FL64     *impl) ;

extern FL64 OptEqty_VOLBOX2Vol(DATESTR  *today,
                        VOLBOX  *vb,
                        OPTFUT   *opt,
                        HOLI_STR *holi) ;

extern FL64 OptCmdty_Black2P(DATESTR *analys,
                    DATESTR *voldate,
                    FL64    spot,
                    FL64    vol,
                    FL64     convyld,
                    FL64     stcost,
                    FUTCMDTY *futc,
                    OPTFUT  *opt,
                    DISCFAC *df,
                     HOLI_STR *holi,
                    RISKSET *risk,
                    FL64    *dp,
                    FL64    *ddp) ;

extern BOOLE OptCmdty_Black2Impl(DATESTR *analys,
                    DATESTR *voldate,
                    FL64    prem,
                    BOOLE   is_p,
                    FL64    spot,
                    FL64    vol,
                    FL64     convyld,
                    FL64     stcost,
                    FUTCMDTY *futc,
                    OPTFUT  *opt,
                    DISCFAC *df,
                     HOLI_STR *holi,
                    KEYCONV what,
                    ITERCTRL *ctrl,
                    FL64    *impl) ;

extern FL64 OptFutCmdty_Black2P(DATESTR *analys,
                    DATESTR *voldate,
                    FL64    fwd,
                    FL64    vol,
                    OPTFUT  *opt,
                    DISCFAC *df,
                     HOLI_STR *holi,
                    RISKSET *risk,
                    FL64    *dp,
                    FL64    *ddp) ;

extern FL64 OptCmdty_VOLBOX2Vol(DATESTR  *today,
                         VOLBOX  *vb,
                         OPTFUT   *opt,
                         HOLI_STR *holi) ;

extern TREEOPT Set_TREEOPT(OPTTYPE   type,
                           FL64      strike,
                           DATESTR   *first,
                           DATESTR   *last,
                           DATESTR   *dpay,
                           CALCONV   cal) ;

/* Private functions */
extern FL64 OptEqty_AdjSpot(DATESTR  *today,
                      DATESTR  *matur,
                      FL64     spot,
                      CALCONV  cal,
                      FL64     div_yld,
                      PLAN_STR *div,
                      DISCFAC  *df) ;


/*** routines in optfx.c ***********************************************/


/* Public functions */

extern FL64 OptFutFX_Black2P(DATESTR *analys,
                    DATESTR *voldate,
                    FL64    futp,
                    FL64    vol,
                    OPTFUT  *opt,
                    DISCFAC *df,
                    HOLI_STR *holi,
                    RISKSET *risk,
                    FL64    *dp,
                    FL64    *ddp) ;

extern FL64 OptFutFX_Black2DFp(DATESTR *analys,
                      DATESTR  *voldate,
                      FL64     vol,
                      FL64     fx_spot,
                      DATESTR  *spot,
                      OPTFUT   *opt,
                      DISCFAC  *df_d,
                      DISCFAC  *df_f,
                      HOLI_STR *holi,
                      RISKSET  *risk,
                      FL64     *dp,
                      FL64     *ddp) ;

extern FL64 OptFX_Black2P(DATESTR *analys,
                    DATESTR *voldate,
                    FL64     vol,
                    FL64     fx_spot,
                    DATESTR  *spot,
                    OPTFUT   *opt,
                    DISCFAC  *df_d,
                    DISCFAC  *df_f,
                     HOLI_STR *holi,
                    RISKSET  *risk,
                    FL64     *dp,
                    FL64     *ddp) ;

extern FL64ARRAY OptFutFX_Black2Delta(DATESTR *analys,
                    DATESTR  *voldate,
                    FL64     vol,
                    FL64     fx_spot,
                    DATESTR  *spot,
                    OPTFUT   *opt,
                    DISCFAC  *df_d,
                    DISCFAC  *df_f,
                    HOLI_STR *holi,
                    DELTASET  *ds) ;

extern FL64ARRAY OptFX_Black2Delta(DATESTR *analys,
                    DATESTR *voldate,
                    FL64     vol,
                    FL64     fx_spot,
                    DATESTR  *spot,
                    OPTFUT   *opt,
                    DISCFAC  *df_d,
                    DISCFAC  *df_f,
                    HOLI_STR *holi,
                    DELTASET  *ds) ;

extern BOOLE OptFutFX_Black2Impl(DATESTR *analys,
                    DATESTR *voldate,
                    FL64    prem,
                    BOOLE   is_p,
                    FL64    futp,
                    FL64    vol,
                    OPTFUT  *opt,
                    DISCFAC *df,
                     HOLI_STR *holi,
                    KEYCONV what,
                    ITERCTRL *ctrl,
                    FL64    *impl) ;

extern BOOLE OptFX_Black2Impl(DATESTR  *analys,
                      DATESTR  *voldate,
                      FL64     prem,
                      BOOLE    is_p,
                      FL64     vol,
                      FL64     fx_spot,
                      DATESTR  *spot,
                      OPTFUT   *opt,
                      DISCFAC  *df_d,
                      DISCFAC  *df_f,
                     HOLI_STR *holi,
                      KEYCONV  what,
                      ITERCTRL *ctrl,
                      FL64     *impl) ;

extern FL64 OptFX_VOLBOX2Vol(DATESTR  *today,
                      VOLBOX  *vb,
                      OPTFUT   *opt,
                      HOLI_STR *holi) ;

extern FL64 OptFX_Cross2Vol(FL64 vol1,
                            FL64 vol2,
                            FL64 corr) ;

extern FL64 OptFutFX_Cross2Vol(FL64 vol1,
                               FL64 vol2,
                               FL64 corr) ;


/* Private functions */
/* To be removed once JL is ready */
extern FL64 black_premium_fxforw(FL64 f,
                                 FL64 e,
                                 FL64 vol,
                                 FL64 t1,
                                 FL64 t,
                                 FL64 disc,
                                 OPTTYPE type,
                                 PREMIUMTYPE ptype,
                                 KEYCONV wrt,
                                 RISKCONV risk,
                                 FL64 *dp,
                                 FL64 *ddp) ;

extern BOOLE black_implied_fxforw(FL64 p, BOOLE is_p, FL64 f, FL64 e, 
                                      FL64 vol, FL64 t1, FL64 t, FL64 disc, 
                                      OPTTYPE type, PREMIUMTYPE ptype, 
                                      KEYCONV what, FL64 low,
                                      FL64 up, FL64 *res) ;

extern FL64 black_d1_fxforw(FL64 f, FL64 e, FL64 vol, FL64 t) ;

extern BOOLE black_root_fxforw(FL64 pr, BOOLE is_p, FL64 pu, FL64 e, 
                                   FL64 vol, FL64 disc, OPTTYPE type, 
                                   PREMIUMTYPE ptype, FL64 t1, FL64 to, 
                                   KEYCONV what, FL64 low, FL64 up,
                                   FL64 xacc, FL64 *res) ;

extern void black_setimpl_fxforw(FL64 x, FL64 *pu, FL64 *disc, FL64 *vol,
                                 FL64 *e, FL64 *t1, FL64 *to, KEYCONV what) ;


/*** routines in optdual.c ***********************************************/


/* Public functions */

/* WARNING: TOO MANY ARGS (>15) BELOW */
extern FL64 OptEqtyCT_Black2P(DATESTR  *analys,
                       DATESTR  *voldate,
                       FL64     spot,
                       FL64     FX,
                       FL64     vol_s,
                       FL64     vol_FX,
                       FL64     corr,
                       FL64     divyld,
                       FUTEQTY  *fute,
                       OPTCT    *opt,
                       DISCFAC  *df_d,
                       DISCFAC  *df_f,
                     HOLI_STR *holi,
                       RISKSET  *risk,
                       FL64     *dp,
                       FL64     *ddp) ;

/* Private functions */
extern OPTINT optCT_set_OPTINT(DATESTR *analys, DATESTR *vold, OPTCT *optd,
  HOLI_STR *holi) ;




/*** routines in optexch.c ***********************************************/


/* Public functions */

/* WARNING: TOO MANY ARGS (>15) BELOW */
extern FL64 OptExch_Black2P(DATESTR   *analys,
                            DATESTR   *voldate,
                            FL64      spot1,
                            FL64      spot2,
                            FL64      vol1,
                            FL64      vol2,
                            FL64      corr,
                            FL64      divyld1,
                            FL64      divyld2,
                            FUTEQTY   *fute1,
                            FUTEQTY   *fute2,
                            OPTFUT    *opt,
                            HOLI_STR  *holi,
                            RISKSET   *risk,
                            FL64      *dp,
                            FL64      *ddp);

/* WARNING: TOO MANY ARGS (>15) BELOW */
extern BOOLE OptExch_Black2Impl(DATESTR  *analys,
                               DATESTR  *voldate,
                               FL64     prem,
                               FL64     spot1,
                               FL64     spot2,
                               FL64     vol1,
                               FL64     vol2,
                               FL64     corr,
                               FL64     divyld1,
                               FL64     divyld2,
                               FUTEQTY  *fute1,
                               FUTEQTY  *fute2,
                               OPTFUT   *opt,
                               HOLI_STR *holi,
                               KEYCONV  key,
                               ITERCTRL *ictrl,
                               FL64     *impl) ;


/* Private functions */

extern OPTINT optexch_set_OPTINT(DATESTR   *analys, 
                                    DATESTR   *vold, 
                                    OPTFUT    *optf, 
                                    FL64      strike,
                                    HOLI_STR  *holi);


/*** routines in rposeqty.c *********************************************/


/* Public functions */
extern RISKPOSLIST OptEqty_Black2RiskPos(DATESTR   *analys,
                                  OPTFUT    *opt,
                                  FUTEQTY   *fute,
                                  FL64      spot,
                                  FL64      Notnal,
                                  FL64      beta,
                                  DATESTR   *voldate,
                                  FL64      vol,
                                  FL64      divyld,    
                                  RISKTOKEN *EqtyIxToken,
                                  DISCFAC   *df,
                                  HOLI_STR  *holi,
                                  DELTASET  *ds,
                                  FXRISKSET *FXr) ;

extern RISKPOSLIST OptFutEqty_Black2RiskPos(DATESTR   *analys,
                                     OPTFUT    *opt,
                                     FUTEQTY   *fute,
                                     FL64      futp,
                                     FL64      Notnal,
                                     FL64      beta,
                                     DATESTR   *voldate,
                                     FL64      vol,
                                     FL64      divyld,
                                     RISKTOKEN *EqtyIxToken,
                                     DISCFAC   *df,
                                     HOLI_STR  *holi,
                                     DELTASET  *ds,
                                     FXRISKSET *FXr) ;

extern RISKPOSLIST FutEqty_CC2RiskPos(DATESTR   *analys,
                                       FUTEQTY   *fute,
                                       DATESTR   *spotdate,
                                       FL64      spot,
                                       FL64      num,
                                       FL64      beta,
                                       FL64      divyld,    
                                       RISKTOKEN *EqtyIxToken,
                                       DISCFAC   *df,
                                       HOLI_STR  *holi,
                                       DELTASET  *ds,
                                       FXRISKSET *FXr) ;

extern RISKPOSLIST Eqty_VAR2RiskPos(FL64      spot, 
                                    FL64      num,
                                    FL64      beta,  
                                    RISKTOKEN *EqtyIxToken,
                                    FXRISKSET *FXr) ;


extern RISKPOSLIST OptEqty_CRR2RiskPos(DATESTR    *analys,
                                           FL64       spot,
                                           FL64       vol,
                                           INTI       nstep,
                                           DISCFAC    *divdf,
                                           FUTEQTY    *fute,
                                           TREEOPT    *opt,
                                           FL64       Notnal,
                                           FL64       beta,
                                           RISKTOKEN  *EqtyIxToken,
                                           DISCFAC    *df,
                                           HOLI_STR   *holi,
                                           DELTASET   *ds,
                                           FXRISKSET  *FXr,
                                           BOOLE      *ok) ;

extern RISKPOSLIST FutFX_DF2RiskPos(DATESTR      *analys,
                                        FXFORW       *fxfw,
                                        FL64         Notnal,
                                        DISCFAC      *df_p,
                                        DISCFAC      *df_r,
                                        HOLI_STR     *holi,
                                        DELTASET     *ds_p,
                                        DELTASET     *ds_r,
                                        FXRISKSET    *FX_p,
                                        FXRISKSET    *FX_r) ;

extern RISKPOSLIST OptFX_CRR2RiskPos(DATESTR    *analys,
                                         FL64       fx_spot,
                                         FL64       vol,
                                         INTI       nstep,
                                         TREEOPT    *opt,
                                         FL64       Notnal,
                                         DISCFAC    *df_p,
                                         DISCFAC    *df_r,
                                         HOLI_STR   *holi,
                                         DELTASET   *ds_p,
                                         DELTASET   *ds_r,
                                         FXRISKSET  *FX_p,
                                         FXRISKSET  *FX_r,
                                         BOOLE      *ok) ;

extern RISKPOSLIST OptFX_Black2RiskPos(DATESTR      *analys,
                                           DATESTR      *voldate,
                                           FL64         vol,
                                           FL64         fx_spot,
                                           DATESTR      *spot,
                                           OPTFUT       *opt,
                                           FL64         Notnal,
                                           DISCFAC      *df_p,
                                           DISCFAC      *df_r,
                                           HOLI_STR     *holi,
                                           DELTASET     *ds_p,
                                           DELTASET     *ds_r,
                                           FXRISKSET    *FX_p,
                                           FXRISKSET    *FX_r) ;

extern RISKPOSLIST OptFutFX_Black2RiskPos(DATESTR      *analys,
                                              DATESTR      *voldate,
                                              FL64         vol,
                                              FL64         fx_spot,
                                              DATESTR      *spot,
                                              OPTFUT       *opt,
                                              FL64         Notnal,
                                              DISCFAC      *df_p,
                                              DISCFAC      *df_r,
                                              HOLI_STR     *holi,
                                              DELTASET     *ds_p,
                                              DELTASET     *ds_r,
                                              FXRISKSET    *FX_p,
                                              FXRISKSET    *FX_r) ;


/*** routines in sceneqty.c *********************************************/

extern FL64ARRAY OptFX_Black2ScenBPV(DATESTR  *analys,
                          DATESTR    *voldate, 
                          FL64       vol,      
                          FL64       fx_spot_opt,
                          FL64       fx_spot_home,
                          DATESTR    *spotdate,
                          OPTFUT     *opt,     
                          DISCFAC    *df_d,    
                          DISCFAC    *df_f,    
                          HOLI_STR   *holi,    
                          DELTASET   *ds_d,    
                          DELTASET   *ds_f,    
                          FXSHOCKSET *fxs_opt,
                          FXSHOCKSET *fxs_home);
extern FL64ARRAY OptFutFX_Black2ScenBPV(DATESTR  *analys,
                          DATESTR    *voldate, 
                          FL64       vol,      
                          FL64       fx_spot_opt,
                          FL64       fx_spot_home,
                          DATESTR    *spotdate,
                          OPTFUT     *opt,     
                          DISCFAC    *df_d,    
                          DISCFAC    *df_f,    
                          HOLI_STR   *holi,    
                          DELTASET   *ds_d,    
                          DELTASET   *ds_f,    
                          FXSHOCKSET *fxs_opt,
                          FXSHOCKSET *fxs_home);

extern FL64ARRAY OptEqty_Black2ScenBPV(DATESTR      *analys,
                                           DATESTR      *voldate, 
                                           FL64         spot,     
                                           FL64         vol,      
                                           FL64         fx_spot,
                                           FL64         divyld,   
                                           FUTEQTY      *fute,    
                                           OPTFUT       *opt,     
                                           DISCFAC      *df,      
                                           HOLI_STR     *holi,    
                                           DELTASET     *ds,    
                                           FXSHOCKSET   *fxs,  
                                           EQTYSHOCKSET *eqtys);  
extern FL64ARRAY OptFutEqty_Black2ScenBPV(DATESTR  *analys,
                              DATESTR  *voldate, 
                              DATESTR  *spotdate,
                              FL64     spot,     
                              FL64     vol,      
                              FL64     fx_spot,
                              FL64     divyld,   
                              FUTEQTY  *fute,    
                              OPTFUT   *opt,     
                              DISCFAC  *df,      
                              HOLI_STR *holi,    
                              DELTASET   *ds,    
                              FXSHOCKSET *fxs,
                              EQTYSHOCKSET *eqtys);
extern FL64ARRAY OptFX_CRR2ScenBPV(DATESTR  *analys,
                          FL64       vol,    
                          FL64       fx_spot_opt,
                          FL64       fx_spot_home,
                          INTI       nstep,  
                          TREEOPT    *opt,   
                          DISCFAC    *df_d,    
                          DISCFAC    *df_f,    
                          HOLI_STR   *holi,    
                          DELTASET   *ds_d,    
                          DELTASET   *ds_f,    
                          FXSHOCKSET *fxs_opt,
                          FXSHOCKSET *fxs_home,
                          BOOLE      *ok);
extern FL64ARRAY OptEqty_CRR2ScenBPV(DATESTR  *analys,
                            FL64     spot,      
                            FL64     vol,       
                            FL64     fx_spot,
                            FUTEQTY  *fute,  
                            INTI     nstep,     
                            TREEOPT  *opt,      
                            DISCFAC  *df,       
                            DISCFAC  *divdf,
                            HOLI_STR *holi,     
                            DELTASET   *ds,  
                            FXSHOCKSET *fxs,
                            EQTYSHOCKSET *eqtys,
                            BOOLE      *ok);
extern FL64ARRAY FutEqty_CC2ScenBPV(DATESTR      *analys,
                                        DATESTR      *spotdate,
                                        FL64         spot,
                                        FL64         fx_spot,
                                        FL64         divyld,   
                                        FUTEQTY      *fute,    
                                        DISCFAC      *df,      
                                        HOLI_STR     *holi,    
                                        DELTASET     *ds,    
                                        FXSHOCKSET   *fxs,
                                        EQTYSHOCKSET *eqtys);


#ifdef __cplusplus
}
#endif

#endif


/* SCID @(#)ioconv.h	1.18 (SimCorp) 99/08/12 14:30:32 */

#ifndef IOCONV_H_INCLUDED

#define IOCONV_H_INCLUDED

/************************************************************************
*                                                                       *
*   project     SCecon                                                  *
*                                                                       *
*   file name   ioconv.h                                                *
*                                                                       *
*   general     This file declares file io functions for enums and      *
*               simple types                                            *
*                                                                       *
************************************************************************/

/*** includes **********************************************************/
#include <stdio.h>
#include <string.h>
#include <str2conv.h>

/* defines   ***********************************************************/
#define MAX_KEYWORD_LENGTH 50


#ifdef __cplusplus
extern "C" {
#endif

/*** prototypes  *******************************************************/
void Write_Comment(FILE* out, TEXT txt);

extern void Read_TEXT(FILE *in, INTI size, TEXT txt);

extern DATESTR Read_DATESTR(FILE *in, FILE *out, TEXT dscr);

extern FL64 Read_FL64(FILE *in, FILE *out, TEXT dscr);
extern COUNT Read_COUNT(FILE *in, FILE *out, TEXT dscr);
extern INTI Read_INTI(FILE *in, FILE *out, TEXT dscr);
extern INTL Read_INTL(FILE *in, FILE *out, TEXT dscr);
extern UN32 Read_UN32(FILE* in, FILE* out, TEXT dscr);

extern BOOLE Read_BOOLE(FILE *in, FILE *out, TEXT dscr);
extern IRRCONV Read_IRRCONV(FILE *in, FILE *out, TEXT dscr);
extern PMTFREQ Read_PMTFREQ(FILE *in, FILE *out, TEXT dscr);
extern EOMCONV Read_EOMCONV(FILE *in, FILE *out, TEXT dscr);
extern CALCONV Read_CALCONV(FILE *in, FILE *out, TEXT dscr);
extern BUSCONV Read_BUSCONV(FILE *in, FILE *out, TEXT dscr);
extern SEQCONV Read_SEQCONV(FILE *in, FILE *out, TEXT dscr);
extern BONDTYPE Read_BONDTYPE(FILE *in, FILE *out, TEXT dscr);
extern SEARCHCONV Read_SEARCHCONV(FILE *in, FILE *out, TEXT dscr);
extern INDEXCONV Read_INDEXCONV(FILE *in, FILE *out, TEXT dscr);
extern KEYCONV Read_KEYCONV(FILE *in, FILE *out, TEXT dscr);
extern INTPOLCONV Read_INTPOLCONV(FILE *in, FILE *out, TEXT dscr);
extern RISKCONV Read_RISKCONV(FILE *in, FILE *out, TEXT dscr);
extern SHOCKCONV Read_SHOCKCONV(FILE *in, FILE *out, TEXT dscr);
extern ALIGNCONV Read_ALIGNCONV(FILE *in, FILE *out, TEXT dscr);
extern SORTCONV Read_SORTCONV(FILE *in, FILE *out, TEXT dscr);
extern TERMUNIT Read_TERMUNIT(FILE *in, FILE *out, TEXT dscr);
extern VOLCONV Read_VOLCONV(FILE *in, FILE *out, TEXT dscr);    
extern DISCIPOL Read_DISCIPOL(FILE *in, FILE *out, TEXT dscr);   
extern INWHATVOL Read_INWHATVOL(FILE *in, FILE *out, TEXT dscr);  
extern VALIDATE Read_VALIDATE(FILE *in, FILE *out, TEXT dscr);   
extern DFWHICH Read_DFWHICH(FILE *in, FILE *out, TEXT dscr);   
extern ANCHORDAY Read_ANCHORDAY(FILE *in, FILE *out, TEXT dscr);
extern WEEKDAY   Read_WEEKDAY(FILE *in, FILE *out, TEXT dscr);




#ifdef __cplusplus
}

#endif

#endif


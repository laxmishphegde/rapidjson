/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef DBACURR_H
#define DBACURR_H
#endif

/************************************************************************
**      Constant & Macro definitions
*************************************************************************/

/************************************************************************
**      Structures & typedef definitions
*************************************************************************/

/************************************************************************
**      External definitions attached to : ddlgendbi.cpp
*************************************************************************/
#include <algorithm>
#include <map>

class CurrenciesIdMap
{
public:

    CurrenciesIdMap()
    {
    };
    CurrenciesIdMap(CurrenciesIdMap const&);
    void operator= (CurrenciesIdMap const&) = delete;

    void insert(ID_T, DBA_DYNFLD_STP);
    void clear();

    std::map<ID_T, DBA_DYNFLD_STP>	& getCurrenciesIdMap();

private:
    std::map<ID_T, DBA_DYNFLD_STP> currenciesIdMap;
};

class CurrenciesCdMap
{
public:

    CurrenciesCdMap()
    {
    };

    CurrenciesCdMap(CurrenciesCdMap const&);
    void operator= (CurrenciesCdMap const&) = delete;

    void insert(std::string, DBA_DYNFLD_STP);
    void clear();

    std::map<std::string, DBA_DYNFLD_STP> & getCurrenciesCdMap();

private:
    std::map<std::string, DBA_DYNFLD_STP> currenciesCdMap;
};

class CurrenciesMap
{
public :
	
    static void load();
    static CurrenciesMap& getInstance();
    static void close();

    CurrenciesMap()
    {
    };

    CurrenciesMap(CurrenciesMap const&) = delete;
    void operator=(CurrenciesMap const&) = delete;

    static DBA_DYNFLD_STP getCurrencyByBEIdMap(ID_T, ID_T);
    static DBA_DYNFLD_STP getCurrencyByBECdMap(ID_T, CODE_T);
    bool findBE(ID_T);
    void init(DBA_DYNFLD_STP*, int, ID_T);
    void add(DBA_DYNFLD_STP, ID_T);
    bool isEmpty();

    DBA_DYNFLD_STP findById(ID_T, ID_T);
    DBA_DYNFLD_STP findByCd(ID_T, CODE_T);

    std::map<ID_T, CurrenciesIdMap> & getBECurrenciesIdMap();
    std::map<ID_T, CurrenciesCdMap> & getBECurrenciesCdMap();

private:

    MemoryPool m_mp;

    static CurrenciesMap                    *m_currenciesInstancePtr;
    static std::map<ID_T, CurrenciesIdMap>	 m_BeCurrenciesIdMap;
    static std::map<ID_T, CurrenciesCdMap>	 m_BeCurrenciesCdMap;
	  
};


/************************************************************************
**      END       dbacurr.h                                   Odyssey
*************************************************************************/

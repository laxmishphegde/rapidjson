/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef COMPOUND_H
#define COMPOUND_H

/************************************************************************
**      External definitions attached to : compound.h
*************************************************************************/

extern RET_CODE FIN_CreateAllCompoundOperation(DBA_DYNFLD_STP , FLAG_T *, DBA_DYNFLD_STP **, int *); /* PMSTA-18601 - DDV - 140925 */
extern RET_CODE FIN_CheckValidCompoundOrder(DBA_DYNFLD_STP *, int);                                  /* PMSTA-18601 - DDV - 140925 */
extern RET_CODE FIN_LoadCompoundOrder(DBA_DYNFLD_STP, DBA_DYNFLD_STP **, int *, FLAG_T);             /* PMSTA-18601 - DDV - 141105 */
extern RET_CODE FIN_LoadAndDeleteCompoundOrder(DBA_DYNFLD_STP, int);                                 /* PMSTA-18601 - DDV - 141209 */
extern RET_CODE FIN_DeleteCompoundOrder(DBA_DYNFLD_STP *, int, int);                                 /* PMSTA-18601 - DDV - 141208 */
extern void FIN_CompoundLockOpCodeAccCode(FLAG_T *);                                                 /* PMSTA-18601 - DDV - 141205 */

#endif					/* ifndef COMPOUND_H */
/************************************************************************
*      END      cmp.h                                            UNICIBLE
*************************************************************************/

/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef FINLIB12_H
#define FINLIB12_H

/************************************************************************
**      BEGIN : Global variables & external definitions attached to finlib12.c
*************************************************************************/
#ifdef  EXTERN
#undef  EXTERN
#endif
#ifdef  FINLIB12_C
#define	EXTERN
#else
#define EXTERN extern
#endif

EXTERN int      FIN_InsertPosVal(ID_T, PTR, DATETIME_T, EXTPOSNAT_ENUM);

EXTERN RET_CODE FIN_GetCouponRate(ID_T, DBA_DYNFLD_STP, DBA_DYNFLD_STP, DATETIME_T, 
				  DATETIME_T, ACCRRULE_ENUM,/* REF11218 - TEB - 050627 */
				  DBA_DYNFLD_STP, DBA_HIER_HEAD_STP),
                FIN_BondNextCoupon(DBA_DYNFLD_STP, DATETIME_T, 
				                    DBA_DYNFLD_STP, DATETIME_T*),
	            FIN_InstrFlow(ID_T, DBA_DYNFLD_STP, DATETIME_T, DATETIME_T, 
							  FLAG_T,	 /* PMSTA-9032 - RAK - 091216 */
			                  TIMEDIM_ENUM, int, FLOWNAT_ENUM, FLOWSUBNAT_ENUM, 
                              EVTDATERULE_ENUM,   /* REF4075 - CSY - 991109 */
			                  DBA_DYNFLD_STP, DBA_HIER_HEAD_STP , ID_T typeId = -1, bool sumflg_f = FALSE),

		        FIN_InterestCond(DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_HIER_HEAD_STP),
		        FIN_GetDataRebateInTermEvt(DBA_DYNFLD_STP, DBA_DYNFLD_STP*,DATETIME_T,DATETIME_T,PAYOFFREBATE_STP, 
					                    DBA_HIER_HEAD_STP), /* REF1055 - AKO - 991130 */
		        FIN_ExtOpUpdGlobalOrderCd(DBA_DYNFLD_STP, DBA_DYNFLD_STP, LOGICIDRULE_ENUM*),
                FIN_CreateExchangeFlows(DBA_DYNFLD_STP, DATETIME_T, DATETIME_T*, DATETIME_T, /* REF2569 - AKO - 990708 */ 
                                        EVTDATERULE_ENUM, int*, int*, DBA_DYNFLD_STP**, DBA_HIER_HEAD_STP), /* REF4075 - CSY - 991027 */

                FIN_ManageGeneratedOperation(DBA_HIER_HEAD_STP,
                                             DBA_DYNFLD_STP,
                                             DBA_DYNFLD_STP,
                                             DBA_ACTION_ENUM,
                                             RETCODEFCT*,
                                             PTR,
                                             FLAG_T*),
                FIN_ManageGeneratedFlow(DBA_HIER_HEAD_STP,
                                        DBA_DYNFLD_STP,
                                        DBA_DYNFLD_STP,
                                        DBA_ACTION_ENUM,
                                        RETCODEFCT*,
                                        PTR,
                                        FLAG_T*),
        /* CSY001212 split CMS */
                FIN_SwapFlows(DATETIME_T, DATETIME_T, DATETIME_T,
			                FLAG_T, /* PMSTA-9032 - RAK - 091216 */
			                  DBA_DYNFLD_STP, EVTDATERULE_ENUM, GENINSTRFLOW_ENUM, DBA_DYNFLD_STP**, int*, DBA_HIER_HEAD_STP), 
                FIN_SwapLegFlows(DATETIME_T, DATETIME_T, DATETIME_T, DBA_DYNFLD_STP, DBA_DYNFLD_STP**, int*, 
                                int*, DBA_HIER_HEAD_STP),
                FIN_FloatingRateNoteFlows(DATETIME_T,DATETIME_T, DATETIME_T, DBA_DYNFLD_STP, 
                                EVTDATERULE_ENUM, ACCRRULE_ENUM,/* REF11218 - TEB - 050627 */
								DBA_DYNFLD_STP**, int*, DBA_HIER_HEAD_STP),
                FIN_MostProbableEvt(DBA_DYNFLD_STP, DBA_DYNFLD_STP**, int*, DATETIME_T, DBA_HIER_HEAD_STP),  /* REF4075 - CSY - 991028 */
                FIN_ExoticOptionFlows(DATETIME_T, DATETIME_T, DATETIME_T, 
				        DBA_DYNFLD_STP, EVTDATERULE_ENUM, DBA_DYNFLD_STP**, int*, DBA_HIER_HEAD_STP),
                FIN_ForexSwapFlows(DATETIME_T, DATETIME_T, DATETIME_T, DBA_DYNFLD_STP, 
			            DBA_DYNFLD_STP**, int*, DBA_HIER_HEAD_STP),
                FIN_OtherFlows(DATETIME_T, DATETIME_T, DATETIME_T,
			            DBA_DYNFLD_STP, EVTDATERULE_ENUM, DBA_DYNFLD_STP**, int*, DBA_HIER_HEAD_STP),

                FIN_GenrFlowInstrCflw(int*,DATETIME_T,DATETIME_T,DATETIME_T,DBA_DYNFLD_STP,EVTDATERULE_ENUM,
                        DBA_DYNFLD_STP**,int*,DBA_DYNFLD_STP,FIN_INTERRATE_ST,DBA_HIER_HEAD_STP),

                FIN_FlowInstrumentRedemptFlow( int*, DATETIME_T, DATETIME_T,DATETIME_T,DBA_DYNFLD_STP,
                                                DBA_DYNFLD_STP**,int*,DBA_HIER_HEAD_STP),
                                                
                FIN_SCEBondFlows(DATETIME_T, DATETIME_T, DATETIME_T, DBA_DYNFLD_STP,
                                    EVTDATERULE_ENUM, ACCRRULE_ENUM,	 /* REF11218 - TEB - 050627 */
									DBA_DYNFLD_STP **, int *, DBA_HIER_HEAD_STP); /* REF9085 - YST - 030521 */

EXTERN          FLOWSUBNAT_ENUM FIN_GetIoRFlowSubNat(ISSREDMNAT_ENUM);

EXTERN RET_CODE FIN_PlanFutureValue(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, AMOUNT_T, DATE_T, NUMBER_T, DATE_T, AMOUNT_T *); /* PMSTA-32209 - DDV - 181019 */

EXTERN RET_CODE FIN_STNOptionBasedCompoTermEvtInfo(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP **, int *, DBA_DYNFLD_STP **, int *, DBA_DYNFLD_STP **, int *); /* PMSTA-34288 - CHU - 190221 */

#endif /* FINLIB12_H */

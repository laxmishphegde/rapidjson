/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef DDLGENVAR_H
#define DDLGENVAR_H

/************************************************************************
**      Constant & Macro definitions
*************************************************************************/

/************************************************************************
**      Structures & typedef definitions
*************************************************************************/

/************************************************************************
**      External definitions attached to : ddlgenvar.cpp
*************************************************************************/

typedef enum
{
    VarType_Variable,
    VarType_Parameter,
    VarType_ExtraParamter,
    VarType_OverParameter
} VAR_TYPE_ENUM;

class DdlGenFromFile;

class DdlGenCursorDef
{
public:

    DdlGenCursorDef(std::string  name, int value)
        : m_name(name)
        , m_value(value)
    {
    };
    virtual ~DdlGenCursorDef()
    {
    };

    DdlGenCursorDef(const DdlGenCursorDef& ref)
    {
        this->m_name = ref.m_name;
        this->m_value = ref.m_value;
    };

    std::string  m_name;
    int          m_value;
};

class DdlGenVar :public AAAObject
{
public:

    // Constructors
    DdlGenVar(DdlGenDbi &ddlGenDbi);
    DdlGenVar(const DdlGenVar&);
    DdlGenVar& operator = (const DdlGenVar&);

    // Destructor
    virtual ~DdlGenVar();

    // Methods
    bool operator== (const DdlGenVar & a) const;
    bool operator== (const std::string & cmpSqlName) const;

    enum class KindOfPrint
    {
        Use,
        UseAsParameter,
        Assign,
        Declare,
        DeclareAsParameter,
        Name
    };

    virtual std::string getInParamCmd();
    virtual std::string getInDeclareCmd();
    virtual std::string getAssignVarCmd(bool bFirst);

    void                init();

    void                access();
    void                resetAccess();
    int                 getAccessNbr();

    int                 getPrintNbr();

    void                setDataTypeSqlName(const std::string &paramDataTypeSqlName);
    void                setDataTypeNative(const std::string &paramDataTypeSqlName);

    void                setDataType(DATATYPE_ENUM paramDataType);
    DATATYPE_ENUM       getDataType();

    std::string         getCursorName();
    void                setCursorName(std::string);

    std::string         getVarDataType();
    std::string        &getVarDataTypeStr();
    std::string         printSqlName(KindOfPrint = KindOfPrint::Use, bool = false);

    bool                isReadOnlyParam();
    virtual void        setOut(bool);
    bool                isOut();
    void                setIn(bool);
    bool                isIn();

    void                setValue(const std::string);
    const std::string  &getValue();

    // Members
    std::string         sqlName;

    bool                bNullable;
    std::string         strDefault;

    bool                m_bModify;
    DdlGenVar          *m_modifiableVar;
    DdlGenVar          *m_ReadOnlyVar;

    bool                m_bAlias;

    VAR_TYPE_ENUM       varType;

    bool                m_bTriggerCursor;

    bool                bIsPrinted;

    DATETIME_T          dateTimeValue;

    bool                bNullValue;
    bool                bRuntimeValue;
protected:
    DdlGenVar(DBA_RDBMS_ENUM rdbmEn);

    // Members
    bool                bIn;
    bool                bOut;

    DATATYPE_ENUM       dataType;
    std::string         dataTypeStr;

    std::string         m_value;

    std::string         m_cursorName;         /* PMSTA-37366 - LJE - 191212 */
    int                 m_countAccessNbr;
    int                 m_countPrintNbr;
    DBA_RDBMS_ENUM      m_rdbmsEn;
};

class DdlSprocParam:public DdlGenVar
{
public:

    // Constructors
    DdlSprocParam(DictSprocClass &procSt, DBA_RDBMS_ENUM rdbmsEn);
    DdlSprocParam(const DdlSprocParam&);
    DdlSprocParam(const DdlGenVar&) = delete;
    DdlSprocParam& operator = (const DdlGenVar&) = delete;

    // Destructor
    virtual ~DdlSprocParam();

    // Methods
    bool operator== (const DdlGenVar &) const = delete;
    bool operator== (const std::string &) const = delete;

    void                     init();
    virtual std::string      getInParamCmd(bool);
    virtual std::string      getInDeclareCmd();

    std::string              getParamDataType();

    virtual void             setOut(bool);

    DICT_ATTRIB_STP          getDictAttribStp();

    bool                     isAlwaysInParam();

protected:
    DictSprocClass           &m_procSt;
};

typedef std::list<DdlSprocParam*> DdlGenParamList;
typedef DdlGenParamList::iterator DdlGenParamIter;

typedef std::vector<DdlGenVar*> DdlGenVarVec;
typedef DdlGenVarVec::iterator DdlGenVarIter;

class DdlGenVarHelper
{
public:

    // Constructors
    DdlGenVarHelper(DdlGenDbi *ddlGenDbi, DdlGenFromFile *ddlGenFromFile);
    DdlGenVarHelper(const DdlGenVarHelper&) = delete;
    DdlGenVarHelper& operator = (const DdlGenVarHelper&) = delete;

    // Destructor
    virtual ~DdlGenVarHelper();


    std::string         rowCount;
    CALCONVWEEKDAY_ENUM dateFirstEn;

    // Methods
    void                       cleanAllVar();
    void                       setAllVarToNotPrinted();

    std::vector<DdlGenVar*>   *getVariableList();
    size_t                     getVariableNbr();

    std::list<DdlSprocParam*> *getParamList();
    size_t                     getParamNbr();

    void                       fixVariableName(std::string & varSqlName);
    DdlGenVar                 *addVariable(const std::string &varSqlName, const std::string &varDataType, const std::string &defaultValue = std::string());
    DdlGenVar                 *addVariable(const std::string &varSqlName, DATATYPE_ENUM varDataType, const std::string &defaultValue = std::string());
    DdlGenVar                 *addVariable(DdlGenVar& newVariable);
    void                       setModify(DdlGenVar &variable);
    void                       setAlias(DdlGenVar &variable);
    void                       setCursorName(DdlGenVar& variable);
    DdlGenVar*                 getNewVariable(std::string varSqlName, DATATYPE_ENUM varDataType);
    DdlGenVar*                 getNewVariable(std::string varSqlName, std::string varDataType);
    DdlGenVar                 *getVariable(std::string varSqlName, bool bCheck=true, bool bForceVar = false);
    void                       copyVariables(DdlGenVarVec *srcVariables);
    void                       copyVariables(DdlGenVarHelper *srcDdlGenVarHelper);

    RET_CODE                   setParamList(DictSprocClass &procSt);
    void                       addParameter(DdlSprocParam newParam);

    DdlSprocParam             *getParameter(std::string sqlName);

    void                       removeParameter(const std::string paramName);
    void                       setExtraParam(std::list<DdlSprocParam> extraParamList);

    std::string                printVarName(std::string varSqlName);
    void                       printVarList(DdlGenDbi &ddlGenDbi, std::stringstream &declareStream, std::stringstream & initStream, bool bSproc, const std::string &newLineStr = std::string("\n"));
    bool                       printParamList(std::stringstream  &outStream);

    void                       resetAccessVarNbr();
    void                       getAccededVarSet(std::set<std::string> &accededVarSet);


    bool                       isAddVarInCursor() const;
    void                       releaseAddInCursor();
    void                       setInCursorName(const std::string& paramInCursorName);
    const std::string&         getInCursorName(int pos = 0) const;
    int                        getInCursorValue(int pos = 0) const;
    int                        getInCursorPos() const;
    void                       clearInCursorName();

    void printMsg(RET_CODE retCode, const std::string &paramMsg, bool isNewLine = true, int sprocLine = -1);

    bool                       isAllParamKept()
    {
        return this->m_keepAllParamters;
    }

protected:

    std::vector<DdlGenVar*>      variableList;
    std::list<DdlSprocParam*>    paramList;

    std::vector<DdlGenCursorDef> inCursorNameVector;
    bool                         m_bAddVarInCursor;

    DdlGenDbi                *m_ddlGenDbiPtr;
    DdlGenFromFile           *m_ddlGenFromFilePtr;
    DdlGenVar                 invalidVar;
    MemoryPool                m_mp;

    bool                      m_keepAllParamters;
};


#endif	                               /* ifndef DDLGENVAR_H */
/************************************************************************
**      END       ddlgendvar.h                                   Odyssey
*************************************************************************/

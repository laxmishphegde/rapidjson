/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef FINFAM_H
#define FINFAM_H

/************************************************************************
**      BEGIN : Global variables & external definitions attached to finlib01.c
*************************************************************************/
#ifdef  EXTERN
#undef  EXTERN
#endif
#ifdef  FINFAM_C
#define	EXTERN
#else
#define EXTERN extern
#endif

EXTERN RET_CODE FIN_FamilyIsLeaf(DBA_DYNST_ENUM, int, int, ID_T, DBA_HIER_HEAD_STP, FLAG_T *),
                FIN_GetFamilyRoot(DBA_DYNST_ENUM, int, int, ID_T,  DBA_DYNFLD_STP *, DBA_HIER_HEAD_STP),
                FIN_GetFamilyElt(DBA_DYNST_ENUM, int, int, ID_T, DBA_HIER_HEAD_STP, DBA_DYNFLD_STP *),
                FIN_GetFamilyParentRec(DBA_DYNST_ENUM, int, int, ID_T, DBA_HIER_HEAD_STP, DBA_DYNFLD_STP *), /* PMSTA14212 - DDV - 120530 */
                FIN_CreateFamily(DBA_DYNST_ENUM, int, int, DBA_HIER_HEAD_STP),
                FIN_SelChildren(DBA_DYNST_ENUM, int, int, ID_T, int, DBA_DYNFLD_STP **, int *, DBA_HIER_HEAD_STP);

#endif /* FINFAM_H */


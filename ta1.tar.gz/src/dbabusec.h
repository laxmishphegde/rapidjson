/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#pragma once

#ifndef DBABUSEC_H
#define DBABUSEC_H

/************************************************************************
**      Constant & Macro definitions
*************************************************************************/
#include <vector>

extern RET_CODE DBA_BuildDataProfileCompo(DBA_DYNFLD_STP, DBA_ACTION_ENUM, OBJECT_ENUM = NullEntity);  /* PMSTA-45362 - SRIDHARA - 110621 */
extern RET_CODE DBA_InsUsrDSPInDataProf(DBA_DYNFLD_STP, DBA_ACTION_ENUM);  /* PMSTA-46782 - SRIDHARA - 12112021 */
extern RET_CODE DBA_BuildDataProfileCompoApplUser(DBA_DYNFLD_STP, DBA_ACTION_ENUM, DbiConnectionHelper &);
extern RET_CODE DBA_BuildPublicSharedHierDsp(DBA_DYNFLD_STP);
extern RET_CODE DBA_createPublicSharedHierDSPSecuredObj(DBA_DYNFLD_STP, DBA_DYNFLD_STP, OBJECT_ENUM); /* PMSTA-48075 */
extern RET_CODE DBA_InsBuDpCompo(OBJECT_ENUM object, DBA_DYNST_ENUM inputSt, DBA_DYNFLD_STP inputData,	DbiConnectionHelper& dbiConnHelper);
extern RET_CODE DBA_BuildBusinessUnitDpCompo(DbiConnectionHelper& dbiConnHelper);

#endif


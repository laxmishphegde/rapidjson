/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/*****************************************************************************
 ** **
 ** **  EXTENDEDSQL HEADER - ExtendedSql & OraSqlLoader
 ** **
 ** **  Created :   PMSTA-36178 - KNI - Load Service - 190716
 ** **
 ** *************************************************************************/

#ifndef EXTENDEDSQL_H
#define EXTENDEDSQL_H

/*****************************************************************************
 *  INCLUDES
 ******************************************************************************/
#include "syslib.h"

enum class ExtendedSqlExitVal {
    EXT_SQL_SUCCESS     = 0, 
    EXT_SQL_FAIL        = 1, 
    EXT_SQL_WARNING     = 2, 
    EXT_SQL_USAGE_FAIL  = 3, 
    NOT_EXT_SQL_SERVICE = 4 };

// This class is for all the new services being written for alternate services of aaa_sql like sqlloader and valo services.
class ExtendedSql : public AAAObject
{
private:
    std::string m_user;
    PasswordEncrypted m_password;
    std::string m_inputFile;
    std::string m_controlFile;
    std::string m_logFile;
    std::string m_badFile;
    std::string m_timeStamp;
    std::string m_discardFile;
    int         m_directPath;
    int         m_parallelLoad;
    std::string m_aaaHome;
    std::string m_appendMode;
    std::string m_tableName;
    ID_T        m_datasetId;

public:
    ExtendedSql();
    virtual ~ExtendedSql();

    ExtendedSql(const ExtendedSql&) = delete;
    ExtendedSql & operator=(const ExtendedSql&) = delete;

    void removeExtSqlArg(int *, char **, std::vector<std::string> &);
    ExtendedSqlExitVal mainIdentifyExecExtSql(int argc, char **);
    ExtendedSqlExitVal startup();
    void setUser(const char *);
    void setPassword(const char *);
    void setPassword(PasswordEncrypted *);
    const std::string & getUser(void);
    const PasswordEncrypted & getPassword(void);
    void setInputFile(const char*);
    void setControlFile(const char*);
    void setLogFile(const char*);
    void setBadFile(const char*);
    void setDiscardFile(const char*);
    void setDirectPath(const int);
    void setParallelLoad(const int);
    void setAaaHome(const char*);
    void setAppendMode(const char*);
    void setDatasetId(ID_T);
    void setTableName(const char*);

    const std::string& getInputFile(void);
    const std::string& getControlFile(void);
    const std::string& getLogFile(void);
    const std::string& getBadFile(void);
    const std::string& getDiscardFile(void);

    const std::string& getTimeStamp(void);
    int                getDirectPath(void);
    int                getParallelLoad(void);

    const std::string& getAaaHome(void);
    const std::string& getAppendMode(void);
    ID_T               getDatasetId();
    const std::string &getTableName(void);

    static void usage(void);

    ExtendedSqlExitVal getOption(std::vector<std::string>&);
    ExtendedSqlExitVal validateInputs();
};

class DbiSqlLoader: public AAAObject
{
public:
    DbiSqlLoader(const DbiSqlLoader&) = delete;
    DbiSqlLoader& operator=(const DbiSqlLoader&) = delete;
    DbiSqlLoader(ExtendedSql&);
    ~DbiSqlLoader();

    virtual ExtendedSqlExitVal validateInputs();
    virtual ExtendedSqlExitVal mainSqlLoad() = 0;

    DdlGenCfgFile& getCtlFileHelper();
    DdlGenContext& getDdlGenContext();

    const std::string& getInputFile(void);
    const std::string& getTableName(void);
    const std::string  getFullTableName(void);
    const std::string  getProperty(const std::string&);

    const std::string  getFieldSep(void);
    const std::string  getEnclosedBy(void);
    char               getDecimalSep(void);

    bool               isEmptyLine(const std::string&);

    bool               getNextToken(std::string&, std::string::iterator&, std::string&, char, char);


protected:

    DdlGenContext  m_ddlGenContext;
    DdlGenCfgFile  m_ctlFileHelper;

    FLAG_T          m_excludeZeroQty;
    std::string     m_fieldSep;
    std::string     m_enclosedBy;
    char            m_decimalSep;

    ExtendedSql&    m_extendedSql;
};

class OraSqlLoader: public DbiSqlLoader
{
private:
    std::string  m_oracleHome;
    std::string  m_oracleSID;
    std::string  m_command;
    bool         m_delParam;
    std::string  m_parameterFile;
    std::string  m_sqlldrControlFile;
    std::string  m_dataFile;

public:
    OraSqlLoader(const OraSqlLoader&) = delete;
    OraSqlLoader & operator=(const OraSqlLoader&) = delete;
    OraSqlLoader(ExtendedSql&);
    ~OraSqlLoader();

    ExtendedSqlExitVal validateInputs();

    const std::string& getParameterFile(void);

    const std::string& getOracleHome(void);
    const std::string & getOracleSID(void);
    ExtendedSqlExitVal loadSQL();
    inline std::string getStringParFile(const std::string &, const std::string &, bool);
    ExtendedSqlExitVal executeSQL();
    ExtendedSqlExitVal mainSqlLoad();
    inline void preExit(const std::string& fileName) { if (SYS_Access(fileName.c_str()) == TRUE && this->m_delParam == true) { SYS_DeleteFile(fileName.c_str()); } }; // preExit function is to make sure that the parameter file is deleted for sure before exiting.
    ExtendedSqlExitVal createParameterFile(void);
    ExtendedSqlExitVal createControlFile(void);
    const std::string& getSqlldrControlFile(void);

    const std::string& getDataFile(void);
    ExtendedSqlExitVal createDataFile(void);

    void createCommand(void);
  
};

class GenSqlLoader: public DbiSqlLoader
{
public:
    GenSqlLoader(const GenSqlLoader&) = delete;
    GenSqlLoader& operator=(const GenSqlLoader&) = delete;
    GenSqlLoader(ExtendedSql&);
    ~GenSqlLoader();

    ExtendedSqlExitVal         mainSqlLoad(void);
    virtual ExtendedSqlExitVal validateInputs();
    ExtendedSqlExitVal         treatDataFile(void);
    RET_CODE                   executeBatch(bool, RequestHelper&, int, DdlGenMsg&);
};

#endif /* EXTENDEDSQL_H */


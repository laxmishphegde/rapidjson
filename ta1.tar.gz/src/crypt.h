/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifdef DISCARD
/*
** Not including unidef.h anymore as it is not necessary and causes
** the dependence of "aaa_crypt" on the ICU libraries (SunOS)
*/
#ifndef UNIDEF_H
#include "unidef.h"
#endif
#endif

#define OP_SUCCEDED		    1
#define OP_FAILED		    0
#define CRYPT_VERSION		1
#define LICENSEEXPIRATION   "UNLIMITED"
#define LINE_NUMBER         4
#define MODULE_NUMBER       10
#define MAX_LINE_LENGTH     256
#define MAX_MODULE_LENGTH   5

typedef enum {
	CRYPT = 0,
	CHECK
} CRYPT_ACTION_ENUM;

/*************************
***  Extern functions  ***
*************************/
extern void     _CRYPT_HashMD5(char *, char **);
extern void  _CRYPT_HashSHA256(char *, char **);

extern void     _CRYPT_HashMD5Salted(char *, char *, char **);
extern void  _CRYPT_HashSHA256Salted(char *, char *, char **);


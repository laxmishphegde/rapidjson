/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef DBA_BCP_H
#define DBA_BCP_H
//#include <cspublic.h>
/************************************************************************
**      BEGIN External definitions attached to : dbabcp.c
*************************************************************************/
#ifdef EXTERN
#undef EXTERN
#endif
#ifdef  DBABCP_C
#define EXTERN
#else
#define EXTERN extern
#endif

/* insert options used with bulk copy method */
#define DBA_BCP_INS_ID      0x0001      /* id must be inserted  */        
#define DBA_BCP_INS_UD_FLD  0X0002      /* insert in "ud" table */
extern void		    DBA_BcpFree(void *&);
extern RET_CODE     DBA_BcpInInit(DbiConnection&, char *, SYSNAME_T*, DATATYPE_ENUM  *, int, int, int, void **);
extern RET_CODE     DBA_BcpInsert(DBA_DYNFLD_STP, void *, int*, const char*);             
extern RET_CODE     DBA_BcpEnd(void*, int*, const char*);                                  
extern RET_CODE     DBA_BcpInitEntity(OBJECT_ENUM, DBA_DYNST_ENUM, int, int, void **);
extern RET_CODE     DBA_BcpInitEntity(OBJECT_ENUM, DBA_DYNST_ENUM, int, DbiConnection&, void **);
extern int			DBA_GetBcpBlockSize(void *);

extern FLAG_T       DBA_BcpModeOPFlg();
extern FLAG_T       DBA_BcpModePerfStorageFlg();
extern FLAG_T       DBA_BcpModeRepFlg();

#endif  

/************************************************************************
**      END        dbabcp.h
*************************************************************************/

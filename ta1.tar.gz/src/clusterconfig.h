
/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/*******************************************************************************
**      Include files
*******************************************************************************/

#ifndef CLUSTERCFG_H
#define CLUSTERCFG_H

/*******************************************************************************
**      Defines
*******************************************************************************/

/*******************************************************************************
**      Struct Defintions
*******************************************************************************/

typedef enum {
    ClusterCfg_None,
    ClusterCfg_Fusion,
    ClusterCfg_TaxLot
} CLUSTERCFGTYPE_ENUM;

/* PMSTA-34827 - JBC - 190218 */
class ServiceCfgThreadArg :public ThreadArg
{
public:
    ServiceCfgThreadArg()
        : ThreadArg()
        , nature(ServiceCfgNat_SubcriptionDaemon)
        , srvcId(0)
    {
    };

    ServiceCfgThreadArg(const ServiceCfgThreadArg &) = delete;
    ServiceCfgThreadArg &operator=(const ServiceCfgThreadArg &) = delete;

    virtual ~ServiceCfgThreadArg()
    {
    };

    SERVICECFGNAT_ENUM nature;
    ID_T        srvcId;
};

/************************************************************************
**      BEGIN External definitions attached to : clusterconfig.cpp
*************************************************************************/
extern RET_CODE SERV_PingService(DbiConnectionHelper &, ID_T, const bool, DBA_DYNFLD_STP = nullptr);
extern void SERV_StopAllServiceConfig();

/*******************************************************************************
**     Classes
*******************************************************************************/


class ClusterServProperties
{
    public:
     ClusterServProperties(std::string serverNm, ID_T serverId, ENUM_T nature, ENUM_T status, int maxFusionNb, std::string busEntityCd) :
        m_serverNm(serverNm),
        m_serverId(serverId),
        m_nature(nature),
        m_status(status),
        m_maxFusionNb(maxFusionNb),
        m_busEntityCd(busEntityCd)
     {         
     }

    ~ClusterServProperties(){}

    std::string m_serverNm;
    ID_T        m_serverId;
    ENUM_T      m_nature; 
    ENUM_T      m_status;
    int         m_maxFusionNb;
    std::string m_busEntityCd;
};


/* PMSTA-26427 - 240217 - PMO 
 * Monitor the elapsed time since the fusion was launched
 * When the time is expired. If the dispatcher think that fusion running
 * A call to each fusion servers will be done to check if it is the case
 */
class FusionTimer
{
    public:

	FusionTimer() :
		m_timeOutInSeconds(600),  // The default is 10 minutes
		m_counter(0),
		m_duration(0),
		m_name(" ")
	{
		resetTimer();
	}

	FusionTimer(std::string name) :
            m_timeOutInSeconds(600),  // The default is 10 minutes
            m_counter(0),
            m_duration(0),
            m_name(name)
        {
            resetTimer();
        }
        /* reset stopwatch to zero */
        void resetTimer()
        {
            m_baseMilliSinceEpoch = DATE_currentMilliSecsSinceEpoch();
        }

        void setTimeOutInSeconds(INT_T timeOutInSeconds)
        {
            m_timeOutInSeconds = timeOutInSeconds;
        }

        bool isTimedOut()
        {
            return isExpired(m_timeOutInSeconds);
        }

        bool is30SecondsExpired()
        {
            return isExpired(30);
        }

        std::string timeElapsed()
        {
            INT64_T elapsed = secondsElapsed();
            INT64_T hours = elapsed / 3600;
            elapsed = elapsed - (hours * 3600);
            INT64_T mins = elapsed / 60;
            INT64_T secs = elapsed - (mins * 60);            
            return elapsedTimeToString(hours, mins, secs);
        }

        std::string elapsedTimeToString(INT64_T hours, INT64_T mins, INT64_T secs)
        {
            std::stringstream oss;
            oss << (hours < 10 ? "0" : "") << hours << ":" << (mins < 10 ? "0" : "") << mins << ":" << (secs < 10 ? "0" : "")  << secs;
            return oss.str();
        }

        int getCount()
        {
		return m_counter;
	}

	void incCount()
	{
		m_counter++;
	}

	std::string getName()
	{
		return m_name;
        }
    
        std::string getCumulativeString()
        {
            return SYS_Stringer(m_name,",",m_counter,",",secondsDuration());
        }


	void resetTimerStatic(bool incCounter)
	{
		if (incCounter) m_counter++;              // only inc if not done with incCounter already   
		m_duration += milliSecondsElapsed();
		resetTimer();
	}

	void resetTimerAndLogStatic(bool incCounter)
	{
		resetTimerStatic(incCounter);
		MSG_LogSrvMesg(UNUSED, UNUSED, getCumulativeString().c_str());
	}

	int getTimeout()
	{
		return m_timeOutInSeconds;
	}

private:

	INT64_T milliSecondsElapsed()
        {
            return (DATE_currentMilliSecsSinceEpoch() - m_baseMilliSinceEpoch);
        }

        INT64_T secondsElapsed()
        {
            return milliSecondsElapsed()/1000;
        }

    
        INT64_T secondsDuration()
        {
            return m_duration/1000;
        }

        bool isExpired(INT64_T timeoutInSeconds)
        {
            return secondsElapsed() >= timeoutInSeconds;
        }

        INT64_T     m_baseMilliSinceEpoch;
        INT_T       m_timeOutInSeconds;
        // static instantiation vars as stopwatch
        int         m_counter; // for static usage - times timer closed
        INT64_T     m_duration;// for static usage - sum of time
        std::string m_name;

};


/*  PMSTA-34827 - JBC - 190218 
 *   Management of cluster-based independent daemons
 *   
 *   Uses random GUIDs and a keep alive thread to unlocking and cleanup.
 *   Expects a procedure to exist to cleanup a specificed lock table that takes a
 *   single Adm_Arg_Code argumment  
 *   
 */
class ServiceCfg
{
    public:
        ServiceCfg(DBA_DYNFLD_STP,const bool);
        ServiceCfg(const ID_T, const bool);
        ~ServiceCfg();

        ServiceCfg             (const ServiceCfg &) = delete;
        ServiceCfg & operator= (const ServiceCfg &) = delete;

        ID_T                    getServiceId();
        std::string             getServiceCd();
        SERVICECFGNAT_ENUM      getNature();
        int                     getTimeoutSec();
        void                    stopAdminThread();
        void                    stopService(bool);
        bool                    isRunning();
        bool                    isTimedOut();
        bool                    isStopping();
        bool                    isStopped();
        bool                    isAsync();
        void                    setStatus(SERVICECFGTSTATUS_ENUM);
        SERVICECFGTSTATUS_ENUM  getStatus();
        ID_T                    getTslJobId();
        INT_T                   getTslChunk();
        EVENTSCHEDNAT_ENUM      getWorkerEventSchedNat();
        const char *            getWorkerEventSchedName();
        bool                    isManagedByFusion();
        bool                    isServiceValid();
        OBJECT_ENUM             getLockTblEn();
        OBJECT_ENUM             getMainTblEn();
        DBA_DYNFLD_STP          getServiceConfig();
        void                    cleanupServiceLocks(DbiConnectionHelper & connHelper);

    private:
        void                    createServiceConfig();
        void                    initServiceCleanup(DbiConnectionHelper & connHelper);
        void                    startThreadStandaloneSvcAdmin();
        bool                    isServiceCfgFldNotNull(FIELD_IDX_T);
        
        DBA_DYNFLD_STP          m_aServiceConfig;
        bool                    m_keepAlive;
};

/* PMSTA-33371 - JBC - 181211
 *  Class to manage server collections
 */
class ClusterServerCfg
{
public:
    ClusterServerCfg(DbiConnectionHelper &, const std::string &, const int, CLUSTERCFGTYPE_ENUM, AtomicInt &, FusionTimer &,  AtomicBool &, FusionTimer &);
    ~ClusterServerCfg();

    ClusterServerCfg             (const ClusterServerCfg &) = delete;
    ClusterServerCfg & operator= (const ClusterServerCfg &) = delete;

    void                                        DBA_RefreshFusServers(DbiConnectionHelper &);
    ID_T                                        getSrvId() const;
    std::string &                               getSrvName();
    int                                         getThreadRank() const;
    int                                         getModRank() const;
    int                                         getSrvThreadCount() const;
    int                                         getMaxRankThreadCount() const;  
    bool                                        isObjSrvRankEqual(ID_T objectId) const;
    bool                                        isPrimeThread();
    bool                                        isPrimeServer() const;
    bool                                        isServAdminDelegate();
    bool                                        isAdminDelayTimedOut();
    std::string                                 getSrvThreadInfo();    
    std::string &                               getPrimeSrvNm();
    bool                                        isFusSrvRunning(std::string & srvNm) const;
    void                                        getRunningSrvIds(std::vector<ID_T> &);
    bool                                        isLockedBusEntity();
    std::string &                               getLockedBusEntity();
    void                                        setDelegateValidity(const bool);
private:
    int                                         getRunningSrvCount() const;
    void                                        getRunningSrvNames(std::vector<std::string> &);
    std::string                                 getClusterTypeName();
    bool                                        isLogged();

    std::string                                 m_serverNm;
    int                                         m_threadRank;           // thread rank within the server
    int                                         m_srvThreadCount;       // thread count within the server
    ID_T                                        m_serverId;
    int                                         m_modRank;              // thread rank across all fus servers
    int                                         m_maxRankThreadCount;   // thread count across all fus servers
    std::map<std::string,ID_T>                  m_runServers;
    std::string                                 m_primeSrvNm;
    std::string                                 m_lockedBusEntityCd;
    CLUSTERCFGTYPE_ENUM                         m_configType;
    AtomicInt &                                 m_delegateThreadRank;
    FusionTimer &                               m_delegateTimer;
    AtomicBool &                                m_isDelegateValid; /* PMSTA-53744 */
    FusionTimer &                               m_adminDelayTimer; /* PMSTA-48143 - JBC - 220222 */
    Lock                                        m_lock;
   
};



/*******************************************************************************
 **      END  clusterconfig.h
 *******************************************************************************/

#endif // !CLUSTERCFG_H

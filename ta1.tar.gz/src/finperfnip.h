/************************************************************************
**
**              Copyright (C) Temenos Software Luxembourg SA 1995-2021.
**                       All Rights Reserved
**
**                   Portfolio Management System
**
*************************************************************************/

#ifndef FINPERFNIP_H
#define FINPERFNIP_H

#ifdef  EXTERN
#undef  EXTERN
#endif
#ifdef  FINPERFNIP_H
#define	EXTERN
#else
#define EXTERN extern 
#endif


/************************************************************************
**      BEGIN : Global definitions attached to finperfnip.c
*************************************************************************/
EXTERN RET_CODE FIN_AddNIPDates(DBA_DYNFLD_STP domainPtr, DBA_HIER_HEAD_STP synthHierHead, DBA_DYNFLD_STP ptfPtr,
                                PA_DATEINFO_STP paDateInfoStp,  DATETIME_ST** crystalDates, int * crystalNbr, bool bRecomputeFlowInfo),
				FIN_AddPtfNIPDates(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, PA_DATEINFO_STP, DATETIME_T **, int *);

EXTERN bool FIN_IsInstrInNIPPeriod(const ID_T instrId, const DATETIME_T & initialDate, const DATETIME_T & finalDate, const PA_DATEINFO_ST & paDateInfoStp, 
                                   PerfCalcResultPeriodNatEn & periodNatEn , NUMBER_T & initialNotInvestedDaysNbr, NUMBER_T & finalNotInvestedDaysNbr, FLAG_T & intradayNIPFlg, DBA_HIER_HEAD_STP synthHierHead);

/* PMSTA -52569- Lalby - 29092023- Manage Ptf in and out using PCP */
PerfCalcResultPeriodNatEn FIN_GetPADatePeriodNature(const DATETIME_T& initialDate, const DATETIME_T& finalDate, const PA_DATEINFO_ST& paDateInfoStp);
std::string FIN_GetPeriodNatureString(PerfCalcResultPeriodNatEn const&);
#endif /* FINPERFNIP_H */

/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define DYNLIB_C

/************************************************************************
**      Include files
*************************************************************************/
#define STDIO_H
#define STRING_H
#define TIME_H
#define STDLIB_H

#include "unidef.h"     /* Mandatory */
#include "dba.h"
#include "conv.h"
#include "date.h"
#include "scpt.h"       /* REF6956 - DDV - 020104 */
#include "scptyl.h"
#include <math.h>
#include "hier.h"

#include <iomanip>
#include <iostream>
#include <fstream>


/* DLA - PMSTA25031 - 161123 */
static char SV_ErrConvertToASCII[] = "ASCII conversion error";

/************************************************************************
**      External entry points
**
**  DBA_CmpDynFld()         Compare two dynamic structures fields.
**  DBA_CmpDynFldSyb()      Compare two dynamic structures fields.
**  DBA_CopyCustSt()        Copy all customer fields from src dyn struct to dest dyn struct.
**  DBA_CopyDynFld()        Copy source dynamic structure field on dest dynamic structure field.
**  DBA_CopyDynSt()         Copy source dynamic structure on dest dynamic structure.
**  DBA_CopyDynStNoNoDbF()  Copy source dynamic structure on destination dynamic structure.
**  DBA_CopyDynStNoUDF()    Copy source dynamic structure on destination dynamic structure.
**  DBA_CopyDynStruct()     Copy source dynamic structure on destination dynamic structure.
**  DBA_CopyDynStSupplFld() Copy source dynamic structure on destination dynamic structure.
**  DBA_DispDynFld()        Display a dynamic structure field value.
**  DBA_DispDynSt()         Display a dynamic structure.
**  DBA_DispDynStF()        Display a dynamic structure.
**  DBA_DispDynStFH()       Display a dynamic structure in a file.
**  DBA_DispDynStStr()      Display a dynamic structure in a file.
**  DBA_DispDynStStrF()     Display a dynamic structure in a file.
**  DBA_FldToStr()          Convert a field to a string.
**  DBA_FreeDynSt()         Deallocate a dynamic structure.
**  DBA_FreeDynStSupplFld() Deallocate content of dynamic structure with supplementary fields.
**  DBA_StrCmp()            Compare string in dynfld.
**  DBA_StrToData()         Convert a string to a field.
**  DBA_GetVarStringASCII   Get variable string (unicode or not) as an ASCII string
**  DBA_SetVarStringASCII   Set into a variable string (unicode or not) with an ASCII string
**  DBA_GetDynStFldStr()	Get a dynamic structure fields sql names in a char array
*************************************************************************/

/************************************************************************
**      Static definitions & data
*************************************************************************/

/* REF8844 - LJE - 030221 */
typedef struct {
        DBA_DYNST_ENUM dynStEnum;
        int            index;
        const char*    cName;
} DBA_DESCDYN_ST;


/* BEGIN REF3871 - SSO - 990803 */
/*  FPL-PMSTA12314-110818 move and rewrite in hier.h (macros duplicated in hierlib1.c
#define AAA_TRACE0(buf, str) { char tmpBuf[256]; \
	    sprintf(tmpBuf, str); \
	    strcat(buf, tmpBuf);}

#define AAA_TRACE1(buf, str, p1) { char tmpBuf[256]; \
	    sprintf(tmpBuf, str, p1); \
	    strcat(buf, tmpBuf); }


#define AAA_TRACE2(buf, str, p1, p2)  { char tmpBuf[256]; \
	    sprintf(tmpBuf, str,  p1, p2); \
	    strcat(buf, tmpBuf); }


#define AAA_TRACE3(buf, str, p1, p2, p3) { char tmpBuf[256]; \
	    sprintf(tmpBuf, str,  p1, p2, p3); \
	    strcat(buf, tmpBuf);}*/

/* END REF3871 - SSO - 990803 */

/************************************************************************
**
**  Function    :   DBA_CmpDynFld()
**
**  Description :   Compare two dynamic structures fields.
**
**  Arguments   :   dynst1   first structure pointer
**                  dynst2   second structure pointer
**                  fld1     field position in first structure
**                  fld2     field position in second structure
**                  dt       datatype (Two fields must have same datatype)
**                  caseFlg  used for alphanumerical sort,
**			     when TRUE comparison is case sensitive
**
** 		    WARNING: Do not use with ExtensionType (return always 0)
**
**  Return      :   -1   first < second
**                   1   first > second
**                   0   first = second
**
**  Last Modif  :	29.04.96 - PEC
**  Modif.      :   ROI - 980213 - REF872
**              :   HFI-PMSTA-46330-211005  comparaison without taking account of precision for double
**
*************************************************************************/
int DBA_CmpDynFld ( DBA_DYNFLD_STP dynst1,
                    DBA_DYNFLD_STP dynst2,
                    int            fld1,
                    int            fld2,
                    DATATYPE_ENUM  dt,
                    char           caseFlg)
{
    return DBA_CmpDynFld(dynst1,
                         dynst2,
                         fld1,
                         fld2,
                         dt,
                         caseFlg,
                         true);
}

/************************************************************************
**
**  Function    :   DBA_CmpDynFld()
**
**  Description :   Compare two dynamic structures fields.
**
**  Arguments   :   dynst1          first structure pointer
**                  dynst2          second structure pointer
**                  fld1            field position in first structure
**                  fld2            field position in second structure
**                  dt              datatype (Two fields must have same datatype)
**                  caseFlg         used for alphanumerical sort when TRUE comparison is case sensitive
**                  bUsePrecision   if true then comparison with precision for double else comparison without precision
**
** 		    WARNING: Do not use with ExtensionType (return always 0)
**
**  Return      :   -1   first < second
**                   1   first > second
**                   0   first = second
**
**  Last Modif  :	29.04.96 - PEC
**  Modif.      :   ROI - 980213 - REF872
**              :   HFI-PMSTA-46330-211005  comparaison without taking account of precision for double
**
*************************************************************************/
int DBA_CmpDynFld(DBA_DYNFLD_STP dynst1,
		          DBA_DYNFLD_STP dynst2,
		          int            fld1,
		          int            fld2,
		          DATATYPE_ENUM  dt,
		          char           caseFlg,
                  bool           bUsePrecision)
{
    int             val=0;
    double          value=0;

	/* Special case when NULL ptr */
	if (dynst1 == NULL)
	{
	  if (dynst2 == NULL) return 0;
	  else return 1;
	}
	else if (dynst2 == NULL) return -1;

        /* Special case when NULL */
        if (IS_NULLFLD(dynst1, fld1) == TRUE)
        {
          if (IS_NULLFLD(dynst2, fld2) == TRUE) return 0;
          else return 1;
        }
        else if (IS_NULLFLD(dynst2, fld2) == TRUE) return -1;

        /* REF9922 - LJE - 040319 */
#ifdef AAATRACEDYNFLD
        if (dynst1[fld1].dynStEnum > InvalidDynSt)
        {
            DICT_TestDynfld(dynst1,fld1,(unsigned char)dt);
        }
        if (dynst2[fld2].dynStEnum > InvalidDynSt)
        {
            DICT_TestDynfld(dynst2,fld2,(unsigned char)dt);
        }
#endif
        /*  Manage precision for double datatype                */  /*  HFI-PMSTA-46330-211005  */
        double  dPrecision = 0.0;
        if (bUsePrecision == true)
        {
            switch(dt)
            {
                case AmountType     : dPrecision = SV_AmountPrecision;  break;          /* PMSTA-36302 - DDV - 190624 - Make 6 digits amount optional */
                case ExchangeType   : dPrecision = EXCHANGE_T_PREC;     break;
                case LongamountType : dPrecision = LONGAMOUNT_T_PREC;   break;
                case NumberType     : dPrecision = NUMBER_T_PREC;       break;
                case PercentType    : dPrecision = PERCENT_T_PREC;      break;
            }
        }

        switch(dt)
        {
        case AmountType     : value = TLS_Cmp(GET_AMOUNT(dynst1, fld1),     GET_AMOUNT(dynst2, fld2),       dPrecision);    break;
        case PercentType    : value = TLS_Cmp(GET_PERCENT(dynst1, fld1),    GET_PERCENT(dynst2, fld2),      dPrecision);    break;
        case ExchangeType   : value = TLS_Cmp(GET_EXCHANGE(dynst1, fld1),   GET_EXCHANGE(dynst2, fld2),     dPrecision);    break;
        case LongamountType : value = TLS_Cmp(GET_LONGAMOUNT(dynst1, fld1), GET_LONGAMOUNT(dynst2, fld2),   dPrecision);    break;
        case NumberType     : value = TLS_Cmp(GET_NUMBER(dynst1, fld1),     GET_NUMBER(dynst2, fld2),       dPrecision);    break;

        case DictType       : value   = CMP_ID(GET_DICT(dynst1, fld1)       , GET_DICT(dynst2, fld2));             break; /* DLA - REF9089 - 030508 */
        case EnumType       : value   = (double)GET_ENUM(dynst1, fld1)       - (double)GET_ENUM(dynst2, fld2);                     break;

        case FlagType       : value = (double)GET_FLAG(dynst1, fld1)       - (double)GET_FLAG(dynst2, fld2);                     break;

        case IdType         : value = CMP_ID( GET_ID(dynst1, fld1)         , GET_ID(dynst2, fld2));               break; /* DLA - REF9089 - 030508 */
        case IntType        : value = GET_INT(dynst1, fld1)        - GET_INT(dynst2, fld2);                       break;

        case MaskType       : value = static_cast<double>(static_cast<unsigned int>(GET_MASK(dynst1, fld1)) - static_cast<unsigned int>(GET_MASK(dynst2, fld2))); break;

        case EnumMaskType   : value = (double)CMP_MASK64(GET_MASK64(dynst1, fld1),GET_MASK64(dynst2, fld2));                 break; /* PMSTA-17133 - 051113 - PMO / PMSTA13460 - TGU - 120420 */

        case MethodType     : value = (double)GET_METHOD(dynst1, fld1)     - (double)GET_METHOD(dynst2, fld2);                   break;

        case PeriodType     : value = GET_PERIOD(dynst1, fld1)     - GET_PERIOD(dynst2, fld2);                   break;
        case PriceType      : value = CMP_PRICE(GET_PRICE(dynst1, fld1), GET_PRICE(dynst2, fld2));       break; /* PMSTA-41768 - JPR - 201006 */
        case SmallintType   : value = GET_SMALLINT(dynst1, fld1)   - GET_SMALLINT(dynst2, fld2);                 break;
        case TinyintType    : value = (double)GET_TINYINT(dynst1, fld1)    - (double)GET_TINYINT(dynst2, fld2);                  break;
        case LongintType    : value = CMP_ID(GET_LONGINT(dynst1, fld1), GET_LONGINT(dynst2, fld2));             break; /* PMSTA-20887 - LJE - 150909 */

        /* AlphaNumerical Sort */
        case CodeType :
        case InfoType :
        case LongnameType :
        case NameType :
        case NoteType :
        case PhoneType :
        case ShortinfoType :
        case SysnameType :
        case LongSysnameType :  /* PMSTA-14086 - LJE - 121008 */
        case TextType :
        case UrlType :
        case String1000Type : /* DLA - PMSTA07121 - 090210 */
        case String2000Type :
        case String3000Type :
        case String4000Type :
        case String7000Type :
        case String15000Type :

		if (caseFlg == FALSE)
		    value = strcmp(GET_STRING(dynst1, fld1), GET_STRING(dynst2, fld2));
		else
		    value = strcasecmp(GET_STRING(dynst1, fld1), GET_STRING(dynst2, fld2));
		break;

        /* MRA - 030826 - REF9303 */
        case UniCodeType :
        case UniInfoType :
        case UniLongnameType :
        case UniNameType :
        case UniNoteType :
        case UniPhoneType :
        case UniShortinfoType :
        case UniSysnameType :
        case UniTextType :
        case UniUrlType :
        case UniString1000Type : /* DLA - PMSTA07121 - 090210 */
        case UniString2000Type :
        case UniString3000Type :
        case UniString4000Type :
        case UniString7000Type :
        case UniString15000Type :
            if (caseFlg == FALSE)
		        value = u_strcmp(GET_USTRING(dynst1, fld1), GET_USTRING(dynst2, fld2));
		    else
		        value = u_strcasecmp(GET_USTRING(dynst1, fld1), GET_USTRING(dynst2, fld2), 0);
		    break;


        /* Date, time Sort */
        case DateType :	value = (double)GET_DATE(dynst1, fld1) - (double)GET_DATE(dynst2, fld2); break; /* REF872 */
        case TimeType : value = (double)GET_TIME(dynst1, fld1) - (double)GET_TIME(dynst2, fld2); break; /* REF872 */
        case YearType : value = (double)GET_YEAR(dynst1, fld1) - (double)GET_YEAR(dynst2, fld2); break; /* REF872 */
        case DatetimeType :
			value = DATETIME_CMP(GET_DATETIME(dynst1, fld1), GET_DATETIME(dynst2, fld2));
			break;

	case ArrayType :
		value = GET_ARRAY_ELTNBR(dynst1, fld1) -
		        GET_ARRAY_ELTNBR(dynst2, fld2);
		if (value == 0)
		{
		    value = GET_ARRAY_ELTSZ(dynst1, fld1) -
		            GET_ARRAY_ELTSZ(dynst2, fld2);
		    if (value == 0)
		    {
			value = memcmp(GET_ARRAY_PTR(dynst1, fld1),
				       GET_ARRAY_PTR(dynst2, fld2),
				       (GET_ARRAY_ELTSZ(dynst1, fld1) *
				        GET_ARRAY_ELTNBR(dynst1, fld1)));
		    }
		}
        break;

        case TzOffsetType   : value = GET_TZOFFSET(dynst1, fld1)   - GET_TZOFFSET(dynst2, fld2);                break;    /*  HFI-PMSTA-30817-180515  */
        }


		if (value < 0) val = -1;
		if (value > 0) val = 1;
		if (value == 0) val = 0;

        return val;
}

/************************************************************************
**
**  Function    :   DBA_CmpDynFldSyb()
**
**  Description :   Compare two dynamic structures fields.
**		            REF3810 - SSO - 990715 : consider NULL < non-NULL value, cf Sybase order by
**
**  Arguments   :   dynst1   first structure pointer
**                  dynst2   second structure pointer
**                  fld1     field position in first structure
**                  fld2     field position in second structure
**                  dt       datatype (Two fields must have same datatype)
**
** 		    WARNING: Do not use with ExtensionType (return always 0)
**
**  Return      :   -1   first < second
**                   1   first > second
**                   0   first = second
**
**  Last Modif  :	REF3810 - SSO - 990715
**
*************************************************************************/
int DBA_CmpDynFldSyb(DBA_DYNFLD_STP dynst1,
		              DBA_DYNFLD_STP dynst2,
		              int            fld1,
		              int            fld2,
		              DATATYPE_ENUM  dt)
{
    if (IS_NULLFLD(dynst1, fld1) == TRUE)
    {
	    if (IS_NULLFLD(dynst2,fld2) == TRUE)
	        return 0;
	    else
            return -1;
    }
    else if (IS_NULLFLD(dynst2, fld2) == TRUE)
	    return 1;

    return (CMP_DYNFLD(dynst1, dynst2, fld1, fld2, dt));
}

/************************************************************************
**
**  Function    :   DBA_CmpDynSt2()
**
**  Description :   Compare two dynamic structures.
**
**  Arguments   :   dynst1   first structure pointer
**                  dynst2   second structure pointer
**                  dynsStEnum DBA_DYNST_ENUM of dynst
**
**
**  Return      :   -1   first < second
**                   1   first > second
**                   0   first = second
**
**  Last Modif  :	REF10175 - DDV - 041015
**  Modif.      :   FPL-REF10596-041020     add parameter metaFldFlg to
**                                          know if no Meta Fld must be
**                                          compare or not
**
*************************************************************************/
int DBA_CmpDynSt2(DBA_DYNFLD_STP dynst1,
		          DBA_DYNFLD_STP dynst2,
		          DBA_DYNST_ENUM dynStEnum,
                  FLAG_T         custFldFlg,
                  FLAG_T         metaFldFlg)
{
    int        minFldNbr=0, maxFldNbr=0, fldNbr=0, custFldNbr=0, noMDFldNbr=0, cmp=0, i;

	/* Special case when NULL ptr */
	if (dynst1 == NULL)
	{
	  if (dynst2 == NULL) return 0;
	  else return 1;
	}
	else if (dynst2 == NULL) return -1;

    maxFldNbr = GET_FLD_NBR(dynStEnum);
    custFldNbr = GET_CUST_NBR(dynStEnum);
    noMDFldNbr = GET_NOMD_NBR(dynStEnum);

    if (metaFldFlg == FALSE)                                /*  FPL-REF10596-041020 */
        minFldNbr =  maxFldNbr - custFldNbr - noMDFldNbr ;  /*  normal case         */
    else
        minFldNbr =  maxFldNbr - custFldNbr ;               /*  new case            */

    if (custFldFlg == TRUE)
        fldNbr = maxFldNbr;
    else
        fldNbr = minFldNbr;


    for (i=0; i < fldNbr && cmp==0; i++)
    {
        if (i < minFldNbr ||
            i > (maxFldNbr - custFldNbr))
        {
            cmp=CMP_DYNFLD(dynst1,dynst2,i,i, GET_FLD_TYPE(dynStEnum,i));
        }
    }

    return(cmp);
}


/************************************************************************
**
**  Function    :   DBA_CmpDynRelevantFields
**
**  Description :   Compare the relevant fields of two dynamic structures.
**                  Relevant meanly means not dependant of id generation, of time creation/update ...
**                  The given structure of the data must be All.
**
**  Arguments   :   dynst1      first structure pointer
**                  dynst2      second structure pointer
**                  enObject    OBJECT_ENUM of dynst
**
**
**  Return      :   -1   first < second
**                   1   first > second
**                   0   first = second
**
**  Creation     :   HFI-PMSTA-38206-201128
**
*************************************************************************/
int DBA_CmpDynRelevantFields (  DBA_DYNFLD_STP    dynst1,
                                DBA_DYNFLD_STP    dynst2,
                                OBJECT_ENUM       enObject)
{
    DICT_ENTITY_STP pdictent = DBA_GetDictEntitySt(enObject);
    DBA_DYNST_ENUM  enDynStEnum = GET_EDITGUIST(enObject);
    int             iCmp = 0;

    /* Special case when NULL ptr */
    if (dynst1 == NULL)
    {
        if (dynst2 == NULL)
        {
            iCmp = 0;
        }
        else
        {
            iCmp = 1;
        }
    }
    else if (dynst2 == NULL)
    {
        iCmp = -1;
    }
    else
    {
        DICT_ATTRIB_STP pdictattr;
        for (auto attribIt = pdictent->attr.begin(); (attribIt != pdictent->attr.end()) && (iCmp == 0); ++attribIt)
        {
            pdictattr = (*attribIt);
            if ((pdictattr->primFlg == false) &&                            /*  primary key                     */
                (pdictattr != pdictent->parentAttrStp) &&                   /*  parent attribute                */
                (pdictattr->logicalFlg == false) &&                         /*  logical attribute               */
                (pdictattr->calcEn != DictAttr_NoMD) &&                     /*  Attribute added in C code       */
                (pdictattr->featureEn != XdEntityFeatureFeatureEn::Creation) &&               /*  creation user and creation date */
                (pdictattr->featureEn != XdEntityFeatureFeatureEn::LastModification) &&       /*  last user and last date         */
                (pdictattr->featureEn != XdEntityFeatureFeatureEn::ExternalSequencing) &&     /*  external sequencing             */
                (pdictattr->featureEn != XdEntityFeatureFeatureEn::UpdateFunction))           /*  right to run attribute          */      
            {
                iCmp = CMP_DYNFLD(dynst1,dynst2,pdictattr->progN, pdictattr->progN, GET_FLD_TYPE(enDynStEnum,pdictattr->progN));
            }
        }
    }
    return iCmp;
}

/************************************************************************
**
**  Function    :   DBA_CopyCustSt()
**
**  Description :   Copy all customer fields from source dynamic structure to
**		            destination dynamic structure.
**		            Both structures must have the same number and the same order
**		            of customer fields.
**		            All dynamic structures must have been allocated !!
**
**                  Macro COPY_CUSTST use this function.
**
**  Arguments   :   dest     destination structure pointer
**                  destDef  destination dynamic structure definition
**                           (DBA_DYNST_ENUM)
**		            src      source structure pointer
**                  srcDef   source dynamic structure definition
**                           (DBA_DYNST_ENUM)
**
**  Return      :   RET_CODE			if ok
**		            RET_GEN_ERR_INVARG		error in arguments
**
**  Creation D. :   DVP029 - 960503 - DED
**  Last modif. :
**
*************************************************************************/
RET_CODE DBA_CopyCustSt(DBA_DYNFLD_STP dest,
                        DBA_DYNST_ENUM destDef,
		                DBA_DYNFLD_STP src,
                        DBA_DYNST_ENUM srcDef)
{
    int srcCustNbr = 0,
        destCustNbr = 0, i,
        srcPrecompNbr = 0,
        destPrecompNbr = 0,
        srcFirstCustNbr = 0,
        destFirstCustNbr = 0;

	/* Check arguments */
	if (src == NULL || dest == NULL ||
	    srcDef == NullDynSt || destDef == NullDynSt)
	{
		MSG_RETURN(RET_GEN_ERR_INVARG);
	}

	/* Initialization of local variables */
    srcCustNbr = GET_CUST_NBR(srcDef);
    srcPrecompNbr = GET_PRECOMP_NBR(srcDef); /* PMSTA-11505 - LJE - 110622 */
    srcFirstCustNbr = GET_FIX_NBR(srcDef);
    destCustNbr = GET_CUST_NBR(destDef);
    destPrecompNbr = GET_PRECOMP_NBR(destDef); /* PMSTA-11505 - LJE - 110622 */
    destFirstCustNbr = GET_FIX_NBR(destDef);


	/* Check if same number of customer fields */
	if (srcCustNbr != destCustNbr || srcPrecompNbr != destPrecompNbr)
	{
		char buffer[400];

		sprintf(buffer, "Structures don't have the same number of customer (precomputed) fields (dest entity : %s, src entity : %s)",
                                       DBA_GetDictEntitySqlName(GET_CUST_ENTITY(destDef)), DBA_GetDictEntitySqlName(GET_CUST_ENTITY(srcDef)));

		MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, buffer);
		return(RET_GEN_ERR_PERSONAL);
	}

	/* Loop on all customer fields */
	for (i=0; i<srcCustNbr+srcPrecompNbr; i++)
	{
		/* Copy customer fields */
		COPY_DYNFLD(dest, destDef, destFirstCustNbr+i,
			    src, srcDef, srcFirstCustNbr+i);
	}

	return(RET_SUCCEED);
}


/************************************************************************
**
**  Function    :   DBA_CopyCustStFlagNoImpact()
**
**  Description :   Copy all customer fields from source dynamic structure to
**		            destination dynamic structure.
**		            Both structures must have the same number and the same order
**		            of customer fields.
**		            All dynamic structures must have been allocated !!
**
**                  Macro COPY_CUSTST use this function.
**
**  Arguments   :   dest     destination structure pointer
**                  destDef  destination dynamic structure definition (DBA_DYNST_ENUM)
**		            src      source structure pointer
**                  srcDef   source dynamic structure definition (DBA_DYNST_ENUM)
**
**  Return      :   RET_CODE			if ok
**		            RET_GEN_ERR_INVARG		error in arguments
**
**  Creation D. :   FPL-REF9215-030811
**
*************************************************************************/
RET_CODE DBA_CopyCustStFlagNoImpact(DBA_DYNFLD_STP dest,
                                    DBA_DYNST_ENUM destDef,
		                            DBA_DYNFLD_STP src,
                                    DBA_DYNST_ENUM srcDef)
{
    /* Check arguments */
    if (src == NULL || dest == NULL ||
        srcDef == NullDynSt || destDef == NullDynSt)
    {
        MSG_RETURN(RET_GEN_ERR_INVARG);
    }

    /* Initialization of local variables */
    int srcCustNbr       = GET_CUST_NBR(srcDef);
    int srcPrecompNbr    = GET_PRECOMP_NBR(srcDef); /* PMSTA-11505 - LJE - 110622 */
    int srcFirstCustNbr  = GET_FIX_NBR(srcDef);
    int destCustNbr      = GET_CUST_NBR(destDef);
    int destPrecompNbr   = GET_PRECOMP_NBR(destDef); /* PMSTA-11505 - LJE - 110622 */
    int destFirstCustNbr = GET_FIX_NBR(destDef);

    /* Check if same number of customer fields */
    if (srcCustNbr != destCustNbr || srcPrecompNbr != destPrecompNbr)
    {
        char buffer[400];
        sprintf(buffer, "Structures don't have the same number of customer (precomputed) fields (dest entity : %s, src entity : %s)",
                DBA_GetDictEntitySqlName(GET_CUST_ENTITY(destDef)), DBA_GetDictEntitySqlName(GET_CUST_ENTITY(srcDef)));
        MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, buffer);
        return(RET_GEN_ERR_PERSONAL);
    }

    /* Loop on all customer fields */
    for (int i=0; i<srcCustNbr+srcPrecompNbr; i++)
    {
        /* Copy customer fields */
        COPY_DYNFLD_FLAG_NO_IMPACT(dest, destDef, destFirstCustNbr+i, src, srcDef, srcFirstCustNbr+i);
    }

    return(RET_SUCCEED);
}



/************************************************************************
**
**  Function    :   DBA_CopyDynFld()
**
**  Description :   Copy source dynamic structure field on destination
**                  dynamic structure field .
**
**                  Macro COPY_DYNFLD use this function.
**
**  Arguments   :   dest     destination structure pointer
**                  destDef  destination dynamic structure definition
**                           (DBA_DYNST_ENUM)
**                  destFld  destination dynamic structure field number
**                  src      source structure pointer
**                  srcDef   source dynamic structure definition
**                           (DBA_DYNST_ENUM)
**                  srcFld   destination dynamic structure field number
**
**  Return      :   TRUE if success, FALSE elsewhere.
**
**  Modif.      :   ROI - 960826 - DVP172
**                  PMSTA-30826 - 110418 - PMO : SERV_UpdateFieldAutomaticWithCollection: Source and destination overlap in memcpy
**
*************************************************************************/
int DBA_CopyDynFld(DBA_DYNFLD_STP   dest,
                   DBA_DYNST_ENUM   destDef,
                   int              destFld,
		           DBA_DYNFLD_STP   src,
                   DBA_DYNST_ENUM   srcDef,
                   int              srcFld)
{
    const bool sameAddress = nullptr != dest && nullptr != src && dest + destFld == src + srcFld;   /* PMSTA-30826 - 110418 - PMO */

    if (false == sameAddress)
    {
/* REF9956 - CHU - 040330 */
#ifdef AAATRACEDYNFLD
        DICT_TestDynSt(dest, destDef);
        DICT_TestDynSt(src, srcDef);
#endif

        /* For string, allocate new space if necessary */
        if (IS_STRINGFLD(destDef,destFld) == TRUE)
        {
            /* PMSTA-28633 - DDV - 170929 - Manage copy from unicode string fld to string fld */
            if (IS_STRINGFLD(srcDef,srcFld) == TRUE)
            {
                SET_STRING(dest, destFld, GET_STRING(src, srcFld));
            }
            else if (IS_USTRINGFLD(srcDef,srcFld) == TRUE)
            {
                char *ptr = NULL;
                ICU4AAA_ConvertToDefaultCharSet(GET_USTRING(src, srcFld), -1, &ptr, NULL);
                SET_STRING(dest, destFld, ptr);
                FREE(ptr);
            }
        }
        else if (IS_USTRINGFLD(destDef,destFld) == TRUE)
        {
            /* PMSTA-28633 - DDV - 170929 - Manage copy from string fld to unicode string fld */
            if (IS_USTRINGFLD(srcDef,srcFld) == TRUE)
            {
                SET_USTRING(dest, destFld, GET_USTRING(src, srcFld));
            }
            else if (IS_STRINGFLD(srcDef,srcFld) == TRUE)
            {
                const int strInLen = SYS_StrLen(GET_STRING(src, srcFld));

                if (strInLen > 0)
                {
                    UChar *uStr= (UChar *) CALLOC(strInLen+1, sizeof(UChar));
                    if (nullptr != uStr)
                    {
                        ICU4AAA_ConvertFromDefaultCharSet(GET_STRING(src, srcFld), -1, uStr, strInLen, NULL);
                        SET_USTRING(dest, destFld, uStr);
                        FREE(uStr);
                    }
                }
            }
        }
        else
        {
            if (IS_ARRAYFLD(destDef, destFld) == TRUE)
            {
                SET_ARRAY(dest, destFld, GET_ARRAY_PTR(src, srcFld),
                             GET_ARRAY_ELTNBR(src, srcFld),
                             GET_ARRAY_ELTSZ(src, srcFld));
            }
            else
            {
                /* Force extension to NULL */
                if (IS_EXTFLD(destDef, destFld) == TRUE)
                {
                    SET_NULL_EXTENSION(dest, destFld);
                }
                else
                {
                         /* REF8844 - LJE - 030828 */
#ifdef AAATRACEDYNFLD
                    if (src[srcFld].dynStEnum != InvalidDynSt)
                    {
                        DICT_TestDynfld(dest,destFld,src[srcFld].dataType);
                    }
#endif

                    memcpy(&dest[destFld].data, &src[srcFld].data, sizeof(DBA_DYNFLDDATA_UN));

                    if (_IS_NULLFLD(src, srcFld) == FALSE)  /* PMSTA13244 - DDV - 120120 - Trace DynFld usage */
                    {
                        SET_NOTNULLFLG_T(dest, destFld);
                    }
                    else
                    {
                        SET_NOTNULLFLG_F(dest, destFld);
                    }

                    if (IS_FLAGFLD(destDef, destFld) == TRUE)
                    {
                        SET_NOTNULLFLG_T(dest, destFld);
                    }
                }
            }
        }
    }

    return(TRUE);
}

/************************************************************************
**
**  Function    :   DBA_CopyDynFld()
**
**  Description :   Copy source dynamic structure field on destination
**                  dynamic structure field .
**
**                  Macro COPY_DYNFLD use this function.
**
**  Arguments   :   dest     destination structure pointer
**                  destDef  destination dynamic structure definition
**                           (DBA_DYNST_ENUM)
**                  destFld  destination dynamic structure field number
**                  src      source structure pointer
**                  srcDef   source dynamic structure definition
**                           (DBA_DYNST_ENUM)
**                  srcFld   destination dynamic structure field number
**
**  Return      :   TRUE if success, FALSE elsewhere.
**
**  Modif.      :   PMSTA-34344 - LJE - 210223
**
*************************************************************************/
int DBA_CopyDynFld(DBA_DYNFLD_STP   dest,
                   int              destFld,
                   DBA_DYNFLD_STP   src,
                   int              srcFld)
{
    const bool sameAddress = nullptr != dest && nullptr != src && dest + destFld == src + srcFld;

    if (false == sameAddress)
    {
        DATATYPE_ENUM destDataTypeEn = GET_FLD_DTP(dest, destFld);
        DATATYPE_ENUM srcDataTypeEn = GET_FLD_DTP(src, srcFld);

        /* For string, allocate new space if necessary */
        if (IS_STRING_TYPE(destDataTypeEn) == TRUE)
        {
            /* PMSTA-28633 - DDV - 170929 - Manage copy from unicode string fld to string fld */
            if (IS_STRING_TYPE(srcDataTypeEn) == TRUE)
            {
                SET_STRING(dest, destFld, GET_STRING(src, srcFld));
            }
            else if (IS_USTRING_TYPE(srcDataTypeEn) == TRUE)
            {
                char *ptr = NULL;
                ICU4AAA_ConvertToDefaultCharSet(GET_USTRING(src, srcFld), -1, &ptr, NULL);
                SET_STRING(dest, destFld, ptr);
                FREE(ptr);
            }
        }
        else if (IS_USTRING_TYPE(destDataTypeEn) == TRUE)
        {
            /* PMSTA-28633 - DDV - 170929 - Manage copy from string fld to unicode string fld */
            if (IS_USTRING_TYPE(srcDataTypeEn) == TRUE)
            {
                SET_USTRING(dest, destFld, GET_USTRING(src, srcFld));
            }
            else if (IS_STRING_TYPE(srcDataTypeEn) == TRUE)
            {
                const int strInLen = SYS_StrLen(GET_STRING(src, srcFld));

                if (strInLen > 0)
                {
                    UChar *uStr = (UChar *)CALLOC(strInLen + 1, sizeof(UChar));
                    if (nullptr != uStr)
                    {
                        ICU4AAA_ConvertFromDefaultCharSet(GET_STRING(src, srcFld), -1, uStr, strInLen, NULL);
                        SET_USTRING(dest, destFld, uStr);
                        FREE(uStr);
                    }
                }
            }
        }
        else
        {
            if (GET_CTYPE(destDataTypeEn) == ArrayPtrCType)
            {
                SET_ARRAY(dest, destFld, GET_ARRAY_PTR(src, srcFld),
                          GET_ARRAY_ELTNBR(src, srcFld),
                          GET_ARRAY_ELTSZ(src, srcFld));
            }
            else
            {
                /* Force extension to NULL */
                if (GET_CTYPE(destDataTypeEn) == ExtPtrCType)
                {
                    SET_NULL_EXTENSION(dest, destFld);
                }
                else if (destDataTypeEn != ChainedTypeType)
                {
                    /* REF8844 - LJE - 030828 */
#ifdef AAATRACEDYNFLD
                    if (src[srcFld].dynStEnum != InvalidDynSt)
                    {
                        DICT_TestDynfld(dest, destFld, src[srcFld].dataType);
                    }
#endif

                    memcpy(&dest[destFld].data, &src[srcFld].data, sizeof(DBA_DYNFLDDATA_UN));

                    if (_IS_NULLFLD(src, srcFld) == FALSE)  /* PMSTA13244 - DDV - 120120 - Trace DynFld usage */
                    {
                        SET_NOTNULLFLG_T(dest, destFld);
                    }
                    else
                    {
                        SET_NOTNULLFLG_F(dest, destFld);
                    }

                    if (destDataTypeEn == FlagType)
                    {
                        SET_NOTNULLFLG_T(dest, destFld);
                    }
                }
            }
        }
    }

    return(TRUE);
}

/************************************************************************
**
**  Function    :   DBA_CopyDynFldFlagNoImpact()
**
**  Description :   Copy source dynamic structure field on destination dynamic structure field .
**                  But do not overwrite flgMask of Flag field if field is NULL
**
**                  Macro COPY_DYNFLD_FLAG_NO_IMPACT use this function.
**
**  Arguments   :   dest     destination structure pointer
**                  destDef  destination dynamic structure definition (DBA_DYNST_ENUM)
**                  destFld  destination dynamic structure field number
**                  src      source structure pointer
**                  srcDef   source dynamic structure definition (DBA_DYNST_ENUM)
**                  srcFld   destination dynamic structure field number
**
**  Return      :   TRUE if success, FALSE elsewhere.
**
**  Creation    :   FPL-REF9215-030811
**
*************************************************************************/
int DBA_CopyDynFldFlagNoImpact(DBA_DYNFLD_STP   dest,
                               DBA_DYNST_ENUM   destDef,
                               int              destFld,
		                       DBA_DYNFLD_STP   src,
                               DBA_DYNST_ENUM   srcDef,
                               int              srcFld)
{
	/* For string, allocate new space if necessary */
	if (IS_STRINGFLD(destDef,destFld) == TRUE)
	{
	    SET_STRING(dest, destFld, GET_STRING(src, srcFld));
	}
    else
	if (IS_USTRINGFLD(destDef,destFld) == TRUE)
	{
	    SET_USTRING(dest, destFld, GET_USTRING(src, srcFld));
	}
	else
	{
	    if (IS_ARRAYFLD(destDef, destFld) == TRUE)
	    {
		SET_ARRAY(dest, destFld, GET_ARRAY_PTR(src, srcFld),
				         GET_ARRAY_ELTNBR(src, srcFld),
				         GET_ARRAY_ELTSZ(src, srcFld));
	    }
	    else
	    {
			/* Force extension to NULL */
			if (IS_EXTFLD(destDef, destFld) == TRUE)
			{
				SET_NULL_EXTENSION(dest, destFld);
			}
			else if (IS_CHAINFLD(destDef, destFld) == FALSE)
			{
				memcpy(&dest[destFld].data, &src[srcFld].data, sizeof(DBA_DYNFLDDATA_UN));
/*				dest[destFld].notNullFlg = src[srcFld].notNullFlg;  FIH-REF4029-991105  */
                                if (_IS_NULLFLD(src,srcFld) == FALSE)  /* PMSTA13244 - DDV - 120120 - Trace DynFld usage */
                                {SET_NOTNULLFLG_T(dest, destFld);}
                                else
                                {SET_NOTNULLFLG_F(dest, destFld);}

/*      FPL-REF9215-030811  This is the differnce between DBA_CopyDynFld and DBA_CopyDynFldFlagNoImpact
				if (IS_FLAGFLD(destDef, destFld) == TRUE)
				{SET_NOTNULLFLG_T(dest, destFld);}
*/
			}
	    }
	}

    if (IS_SETFLD(src, srcFld) == FALSE)
    {
        SET_SETFLG_F(dest, destFld);
    }

	return(TRUE);
}

/************************************************************************
**
**  Function    :   DBA_CopyDynFldNoImpact()
**
**  Description :   Copy source dynamic structure field on destination dynamic structure field .
**                  But do not overwrite special flag mask values
**
**  Arguments   :   dest     destination structure pointer
**                  destDef  destination dynamic structure definition (DBA_DYNST_ENUM)
**                  destFld  destination dynamic structure field number
**                  src      source structure pointer
**                  srcDef   source dynamic structure definition (DBA_DYNST_ENUM)
**                  srcFld   destination dynamic structure field number
**
**  Creation    :   PMSTA-46681 - LJE - 230913
**
*************************************************************************/
void DBA_CopyDynFldNoImpact(DBA_DYNFLD_STP   dest,
                            int              destFld,
                            DBA_DYNFLD_STP   src,
                            int              srcFld)
{
    DBA_DYNST_ENUM   destDef = dest->getDynStEn();

    /* For string, allocate new space if necessary */
    if (IS_STRINGFLD(destDef, destFld) == TRUE)
    {
        if (_IS_NULLFLD(src, srcFld))
        {
            _SET_NOTNULLFLG_F(dest, destFld);
        }
        else
        {
            _SET_STRING(dest, destFld, GET_STRING(src, srcFld));
        }
    }
    else if (IS_USTRINGFLD(destDef, destFld) == TRUE)
    {
        if (_IS_NULLFLD(src, srcFld))
        {
            _SET_NOTNULLFLG_F(dest, destFld);
        }
        else
        {
            _SET_USTRING(dest, destFld, GET_USTRING(src, srcFld));
        }
    }
    else
    {
        if (IS_ARRAYFLD(destDef, destFld) == TRUE)
        {
            _SET_ARRAY(dest,
                       destFld,
                       GET_ARRAY_PTR(src, srcFld),
                       GET_ARRAY_ELTNBR(src, srcFld),
                       GET_ARRAY_ELTSZ(src, srcFld));
        }
        else
        {
            /* Force extension to NULL */
            if (IS_EXTFLD(destDef, destFld) == TRUE)
            {
                _SET_NULL_EXTENSION(dest, destFld);
            }
            else if (IS_CHAINFLD(destDef, destFld) == FALSE)
            {
                memcpy(&dest[destFld].data, &src[srcFld].data, sizeof(DBA_DYNFLDDATA_UN));
                if (_IS_NULLFLD(src, srcFld) == FALSE)
                {
                    _SET_NOTNULLFLG_T(dest, destFld);
                }
                else
                {
                    _SET_NOTNULLFLG_F(dest, destFld);
                }
            }
        }
    }
}

/************************************************************************
**
**  Function    :   DBA_CopyDynStFlagNoImpact()
**
**  Description :   Copy source dynamic structure on destination
**                  dynamic structure.
**                  Two structures must have same definition which
**                  is received too.
**
**                  Extension field are set to NULL in destination structure
**
**                  Macro COPY_DYNST_FLAG_NO_IMPACT use this function.
**
**  Arguments   :   dest     destination structure pointer
**                  src      source structure pointer
**                  st       dynamic structure description
**
**  Return      :   TRUE if success, FALSE elsewhere.
**
**	Creation    :	FIH-REF9215-030617
**
*************************************************************************/
int DBA_CopyDynStFlagNoImpact (DBA_DYNFLD_STP dest, DBA_DYNFLD_STP src, DBA_DYNST_ENUM st)
{
    return(DBA_CopyDynStruct(dest, src, st, TRUE, TRUE, FALSE, FALSE, false));
}

/************************************************************************
**
**  Function    :   DBA_CopyDynSt()
**
**  Description :   Copy source dynamic structure on destination
**                  dynamic structure.
**                  Two structures must have same definition which
**                  is received too.
**
**                  Extension field are set to NULL in destination structure
**
**                  Macro COPY_DYNST use this function.
**
**  Arguments   :   dest     destination structure pointer
**                  src      source structure pointer
**                  st       dynamic structure description
**
**  Return      :   TRUE if success, FALSE elsewhere.
**
**	Modif		:	OCE - 980810 - REF2418
**	Modif		:	ROI - 981028 - REF2837
**	Modif		:	ROI - 990625 - REF3537
**					REF4329 - SSO - 000204: code moved in DBA_CopyDynStruct
**                  FIH-REF9215-030617  Add one parameter to DBA_CopyDynStruct
**
*************************************************************************/
int DBA_CopyDynSt(DBA_DYNFLD_STP dest, DBA_DYNFLD_STP src, DBA_DYNST_ENUM st)
{
    return(DBA_CopyDynStruct(dest, src, st, TRUE, TRUE, TRUE, FALSE, false));/* copy non-database fields */
}

/************************************************************************
**
**  Function    :   DBA_CopyDynStNoNoDbF()
**
**  Description :   Copy source dynamic structure on destination
**                  dynamic structure.
**                  Two structures must have same definition which
**                  is received too.
**
**                  Extension field are set to NULL in destination structure
**
**					FIELDS WHICH ARE NOT DATABASE ONES ARE NOT COPIED !!!!
**
**  Arguments   :   dest     destination structure pointer
**                  src      source structure pointer
**                  st       dynamic structure description
**
**  Return      :   TRUE if success, FALSE elsewhere.
**					created REF4329 - SSO - 000204
**                  FIH-REF9215-030617  Add one parameter to DBA_CopyDynStruct
**
*************************************************************************/
int DBA_CopyDynStNoNoDbF(DBA_DYNFLD_STP dest, DBA_DYNFLD_STP src, DBA_DYNST_ENUM st)
{
	return(DBA_CopyDynStruct(dest, src, st, FALSE, TRUE, TRUE, FALSE, false));
}

/************************************************************************
**
**  Function    :   DBA_CopyDynStNoUDF()
**
**  Description :   Copy source dynamic structure on destination
**                  dynamic structure.
**                  Two structures must have same definition which
**                  is received too.
**
**                  FIELDS WHICH ARE USER DEFINED ARE NOT COPIED !!!!
**
**  Arguments   :   dest     destination structure pointer
**                  src      source structure pointer
**                  st       dynamic structure description
**
**  Return      :   TRUE if success, FALSE elsewhere.
**					REF5031 SKE 000728
**                  FIH-REF9215-030617  Add one parameter to DBA_CopyDynStruct
**
*************************************************************************/
int DBA_CopyDynStNoUDF(DBA_DYNFLD_STP dest, DBA_DYNFLD_STP src, DBA_DYNST_ENUM st)
{
	return(DBA_CopyDynStruct(dest, src, st, TRUE, FALSE, TRUE, FALSE, false));
}

/************************************************************************
**
**  Function    :   DBA_CopyDynStWithSetFld()
**
**  Description :   Copy source dynamic structure on destination
**                  dynamic structure.
**                  Two structures must have same definition which
**                  is received too.
**
**                  Extension field are set to NULL in destination structure
**
**                  Macro COPY_DYNST use this function.
**
**  Arguments   :   dest     destination structure pointer
**                  src      source structure pointer
**                  st       dynamic structure description
**
**  Return      :   TRUE if success, FALSE elsewhere.
**
**	Create		:	PMSTA-46681 - LJE - 231109
**
*************************************************************************/
int DBA_CopyDynStWithSetFld(DBA_DYNFLD_STP dest, DBA_DYNFLD_STP src)
{
    return(DBA_CopyDynStruct(dest, src, NullDynSt, TRUE, TRUE, TRUE, FALSE, true));
}

/************************************************************************
**
**  Function    :   DBA_CopyDynStDisableDomainTrace()
**
**  Description :   Copy source dynamic structure on destination
**                  dynamic structure.
**                  Two structures must have same definition which
**                  is received too.
**
**                  Extension field are set to NULL in destination structure
**
**                  Macro COPY_DYNST_DISDOMTRACE use this function.
**
**  Arguments   :   dest     destination structure pointer
**                  src      source structure pointer
**                  st       dynamic structure description
**
**  Return      :   TRUE if success, FALSE elsewhere.
**
**	Creation    :   PMSTA-23209 - DDV - 160622
**	Modif		:
**
**
*************************************************************************/
int DBA_CopyDynStDisableDomainTrace(DBA_DYNFLD_STP dest, DBA_DYNFLD_STP src, DBA_DYNST_ENUM st)
{
		return(DBA_CopyDynStruct(dest, src, st, TRUE, TRUE, TRUE, TRUE, false));
}

/************************************************************************
**
**  Function    :   DBA_CopyDynStruct()
**
**  Description :   Copy source dynamic structure on destination
**                  dynamic structure.
**                  Two structures must have same definition which
**                  is received too.
**
**                  Extension field are set to NULL in destination structure
**
**                  Macro COPY_DYNST use this function.
**
**  Arguments   :   dest     destination structure pointer
**                  src      source structure pointer
**                  st       dynamic structure description
**                  flagModifFlagIfNull : if TRUE set flag field to FALSE if NULL
**
**  Return      :   TRUE if success, FALSE elsewhere.
**
**	Modif		:	OCE - 980810 - REF2418
**	Modif		:	ROI - 981028 - REF2837
**	Modif		:	ROI - 990625 - REF3537
**					REF4329 - SSO - 000204: code moved from DBA_CopyDynSt
**                  REF8844 - LJE - 030327 : Add dynst indirection
**                  FIH-REF9215-030617  : Add flagModifFlagIfNull
**                  PMSTA-16443 - 230713 - PMO : Add confirmation-to-continue messages in case not enough free memory is available for the GUI when loading data from a financial server
**                  PMSTA-23209 - DDV - 160622 - Add disableDomainTraceFlg parameter.
**
*************************************************************************/
int DBA_CopyDynStruct(DBA_DYNFLD_STP dest,
                      DBA_DYNFLD_STP src,
                      DBA_DYNST_ENUM st,
                      FLAG_T         copyNonDBFieldsFlg,
                      FLAG_T         copyUDFieldsFlg,
                      FLAG_T         flagModifFlagIfNull,
                      FLAG_T         disableDomainTraceFlg, /* PMSTA-23179 - DDV - 160428 */
                      bool           bWithSetFld)
{
    int         ret = TRUE;

    /* DVP172 */
    if (dest == NULL || src == NULL)
    {
        return(FALSE);
    }

    /*PMSTA-34810 - AiswaryaM -20190218 dont perform copy if source and destination are pointing to the same location*/
    if (dest == src)
    {
        return TRUE;
    }

    /* PMSTA-46681 - LJE - 231017 */
    if (dest->getDynStEn() > InvalidDynSt)
    {
        if (dest->getDynStEn() != src->getDynStEn())
        {
            return (DBA_ConvertDynSt(dest, src, bWithSetFld) == RET_SUCCEED ? TRUE : FALSE);
        }
        st = dest->getDynStEn();
    }

    /* PMSTA13244 - DDV - 120120 - Trace DynFld usage */ /* PMSTA-23209 - DDV - 160622 */
    if (st != InvalidDynSt && st == A_Domain && disableDomainTraceFlg == FALSE)
    {
        DBA_TraceDomainCopy(src, dest);
    }

    int fieldNbr = 0;
    if (copyUDFieldsFlg == TRUE)
    {
        fieldNbr = GET_FLD_NBR(st);
    }
    else
    {
        fieldNbr = GET_FIX_NBR(st);
    }

    bool bSetNullExt = (IS_REFDYNST(dest) == FALSE);

    int from   = 0;
    int i      = 0;
    for (; i < fieldNbr; i++)
    {
        if (flagModifFlagIfNull == TRUE)        /*  FIH-REF9215-030617  */
        {
            /* Un flag n'est jamais null - REF2837 */
            if ((IS_FLAGFLD(st, i) == TRUE) && (_IS_NULLFLD(src, i) == TRUE))  /* PMSTA13244 - DDV - 120120 - Trace DynFld usage */
            {
                if (_IS_NULLFLD(dest, i) == TRUE)  /* PMSTA13244 - DDV - 120120 - Trace DynFld usage */
                {
                    SET_NOTNULLFLG_T(src, i);
                }
                else	/* REF3537 */
                {
                    memcpy(&src[i], &dest[i], sizeof(DBA_DYNFLD_ST));
                }
            }
        }

        if (copyNonDBFieldsFlg == FALSE && IS_DBFLD(st, i) == FALSE)  /* REF4329 - SSO - 000204 */
        {
            if (i - from > 0)  /* for 1st non-database field, copy until preceding field */
            {
                memcpy(&dest[from], &src[from], sizeof(DBA_DYNFLD_ST) * (i - from));
            }

            /* Force extension to NULL */
            if (IS_EXTFLD(st, i) == TRUE)
            {
                SET_NULL_EXTENSION(dest, i);
            }

            from = i + 1; /* update copy range */
            continue;
        }

        /* Gestion par bloc : les STRING. ARRAY et EXT ne sont pas copi� */
        if (IS_STRINGFLD(st, i) == TRUE || 
            IS_USTRINGFLD(st, i) == TRUE || 
            IS_ARRAYFLD(st, i) == TRUE || 
            (IS_EXTFLD(st, i) == TRUE) ||
            (IS_CHAINFLD(st, i) == TRUE) || 
            IS_MULTIARRAYFLD(st, i) == TRUE)
        {
            if ((i - from) > 0)
            {
                memcpy(&dest[from], &src[from], sizeof(DBA_DYNFLD_ST) * (i - from));
            }
            from = i + 1;

            /* PMSTA-Memory - LJE - 181204 */
            dest[i].dynStEnum = src[i].dynStEnum;
            dest[i].dataType  = src[i].dataType;
            dest[i].index     = src[i].index;

            /* For string, allocate new space if necessary */
            if (IS_STRINGFLD(st, i) == TRUE)
            {
                if (GET_STRING_LEN(src, i) > 0 && _IS_NULLFLD(src, i) == FALSE) /* PMSTA16119 - DDV - 130326 - If src field is null, set null in dest field */
                {
                    /* ROI - 001010 - REF5274 */
                    /* SET_STRING(dest, i, GET_STRING(src, i)); */
                    int ret2 = _SET_STRING(dest, i, (src[i].data.strData.ptr)); /* PMSTA13244 - DDV - 120123 - Trace DynFld usage */

                    /* PMSTA-16443 - 230713 - PMO */
                    if (FALSE == ret2)
                    {
                        ret = ret2;
                    }
                }
                else
                {
                    _SET_NULL_STRING(dest, i); /* PMSTA13244 - DDV - 120123 - Trace DynFld usage */
                }
            }
            else if (IS_USTRINGFLD(st, i) == TRUE)
            {
                if (GET_USTRING_LEN(src, i) > 0 && _IS_NULLFLD(src, i) == FALSE) /* PMSTA-18466 - DDV - 140819 */ /* PMSTA16119 - DDV - 130326 - If src field is null, set null in dest field */
                {
                    /* ROI - 001010 - REF5274 */
                    /* SET_STRING(dest, i, GET_STRING(src, i)); */
                    int ret2 = _SET_USTRING(dest, i, (src[i].data.ustrData.ptr)); /* PMSTA13244 - DDV - 120123 - Trace DynFld usage */

                    /* PMSTA-16443 - 230713 - PMO */
                    if (FALSE == ret2)
                    {
                        ret = ret2;
                    }
                }
                else
                {
                    _SET_NULL_USTRING(dest, i); /* PMSTA13244 - DDV - 120123 - Trace DynFld usage */
                }
            }
            else if (IS_ARRAYFLD(st, i) == TRUE)
            {
                if (_IS_NULLFLD(src, i) == FALSE) /* PMSTA-18466 - DDV - 140819 */ /* PMSTA16119 - DDV - 130326 - If src field is null, set null in dest field */
                {
                    _SET_ARRAY(dest, i, GET_ARRAY_PTR(src, i), /* PMSTA13244 - DDV - 120123 - Trace DynFld usage */
                               GET_ARRAY_ELTNBR(src, i),
                               GET_ARRAY_ELTSZ(src, i));
                }
                else
                {
                    _SET_NULL_ARRAY(dest, i); /* PMSTA13244 - DDV - 120123 - Trace DynFld usage */
                }
            }
            else if (IS_MULTIARRAYFLD(st, i) == TRUE)
            {
                if (_IS_NULLFLD(src, i) == FALSE) 
                {
                    _SET_MULTIARRAY(dest, i, GET_MULTIARRAY_PTR(src, i),
				                     GET_MULTIARRAY_DIM1(src, i),
				                     GET_MULTIARRAY_DIM2(src, i));
                }
                else
                {
                    _SET_NULL_MULTIARRAY(dest, i);
                }
            }
            else if (IS_EXTFLD(st, i) == TRUE && bSetNullExt)
            {
                if (dest[i].data.ptr != nullptr)
                {
                    SYS_BreakOnDebug();
                }
                /* Force extension to NULL */
                _SET_NULL_EXTENSION(dest, i); /* PMSTA13244 - DDV - 120123 - Trace DynFld usage */
            }
        }

        /* PMSTA-46681 - LJE - 231109 */
        if (bWithSetFld && IS_SETFLD(src, i) == TRUE)
        {
            SET_SETFLG_T(dest, i);
        }
        else
        {
            SET_SETFLG_F(dest, i);
        }
    }
    if (i - from > 0)
        memcpy(&dest[from], &src[from], sizeof(DBA_DYNFLD_ST) * (i - from));

    if (bSetNullExt == false)
    {
        SCPT_SET_REFFLG_T(dest);
    }

    return(ret);
}

/************************************************************************
**
**  Function    :   DBA_ResetGetSetFlg()
**
**  Description :
**
**
**
**  Arguments   :   rec     structure pointer to reset
**                  dynSt   dynamic structure description
**
**  Return      :
**
**	Creation    : PMSTA13244 - DDV - 120120 - Trace DynFld usage
**	Modif		:
**
**
*************************************************************************/
void DBA_ResetGetSetFlg(DBA_DYNFLD_STP rec, DBA_DYNST_ENUM dynSt)
{
    if (rec == NULL)
    {
        return;
    }

#ifdef AAATRACEDYNFLD
    DICT_TestDynSt(rec, dynSt);
#endif

    int fieldNbr = GET_FLD_NBR(dynSt);

    for (int i=0; i<fieldNbr; i++)
    {
        SET_GETFLG_F(rec, i);
        SET_SETFLG_F(rec, i);
    }
}

/************************************************************************
**
**  Function    :   DBA_ResetGetSetFlg()
**
**  Description :
**
**
**
**  Arguments   :   rec     structure pointer to reset
**                  dynSt   dynamic structure description
**
**  Return      :
**
**	Creation    : PMSTA-46681 - LJE - 240301
**	Modif		:
**
**
*************************************************************************/
void DBA_ResetGetSetFlg(DBA_DYNFLD_STP rec)
{
    DBA_ResetGetSetFlg(rec, rec->getDynStEn());
}

/************************************************************************
**
**  Function    :   DBA_LogDomainUsage()
**
**  Description :
**
**
**
**  Arguments   :   domainPtrf    structure pointer to log
**                  subFctFlg     Flag to define if filked must be logged fior parent function (FALSE) or sub-function (TRUE)
**
**  Return      :
**
**	Creation    : PMSTA13244 - DDV - 120120 - Trace DynFld usage
**
**	Modif	:  PMSTA-17133 - 051113 - PMO : Many compilation warnings in C code especially " Converting a 64-bit type value to "int" causes truncation."
**
*************************************************************************/
void DBA_LogDomainUsage(DBA_DYNFLD_STP domainPtr, FLAG_T subFctFlg, ID_T fmtId, CODE_T fmtCd)
{
    int                i=0, j=0, fieldNbr=0, dictFctAttribNbr=0, logFldNbr=0;
    DBA_DYNFLD_STP     *dictFctAttribTab = NULLDYNSTPTR;
    DBA_DYNFLD_STP     sDictFctAttrib = NULLDYNST;
    DBA_DYNFLD_STP     newDictFctAttrib = NULLDYNST;
    DICT_T             dictFct=0;
    FLAG_T             foundFlg=FALSE, logFlg=FALSE;
	DICT_ATTRIB_STP    attribSt=NULL;
	SYSNAME_T          *fctName=NULL;
	char               *buffer=NULL;
	DICT_ENTITY_STP    domainEntitySt= (DICT_ENTITY_STP)DBA_GetDictEntitySt(Domain);

    if (domainPtr == NULL)
        return;

    /* do it only for TSL output */
	if ((FIN_FCT_OUTPUT_ENUM)GET_ENUM(domainPtr, A_Domain_OutputTpEn) != TASCTableOutput)
        return;

    if ((sDictFctAttrib = ALLOC_DYNST(S_DictFctAttrib)) == NULL)
        return;

    if (subFctFlg == TRUE)
        dictFct=GET_DICT(domainPtr, A_Domain_RpcFctDictId);

    if (dictFct <= 0)
        dictFct=GET_DICT(domainPtr, A_Domain_FctDictId);

    SET_DICT(sDictFctAttrib, S_DictFctAttrib_FctDictId, dictFct);

    if (fmtId != ZERO_ID)    /* PMSTA-17133 - 051113 - PMO */
    {
        SET_ID(sDictFctAttrib, S_DictFctAttrib_FmtId, fmtId);
    }

    /* Load all existing dict_function_attribute for current dict_function */
    if (DBA_Select2(DictFctAttrib, UNUSED, S_DictFctAttrib, sDictFctAttrib,
		   		    A_DictFctAttrib, &dictFctAttribTab, UNUSED, UNUSED, &dictFctAttribNbr,
		 		    UNUSED, UNUSED) != RET_SUCCEED)
    {
        FREE_DYNST(sDictFctAttrib, S_DictFctAttrib);
        return;
    }

    FREE_DYNST(sDictFctAttrib, S_DictFctAttrib);
    fieldNbr = GET_FLD_NBR(A_Domain);

    for (i=0; i<fieldNbr; i++)
    {
        /* PMSTA-13655 - DDV - 120308 - skip all no MD fields and remove check on db field */
        if (i == GET_FIX_NBR(A_Domain)-GET_NOMD_NBR(A_Domain)-1)
        {
            i += GET_NOMD_NBR(A_Domain);

            if (i >= fieldNbr)
                break;
        }

        if (IS_GETFLD(domainPtr, i))
        {
      	    if ((attribSt = (DICT_ATTRIB_STP)DBA_GetDictAttribSt(Domain, i)) != NULL)
            {
                foundFlg=FALSE;
                logFlg = FALSE;
                for (j=0; j<dictFctAttribNbr && foundFlg == FALSE; j++)
                {
                    if (strcmp(GET_SYSNAME(dictFctAttribTab[j], A_DictFctAttrib_EntitySqlName), domainEntitySt->mdSqlName) == 0 &&
                        strcmp(GET_SYSNAME(dictFctAttribTab[j], A_DictFctAttrib_AttributeSqlName),attribSt->sqlName) == 0)
                    {
                        foundFlg = TRUE;

                        if (GET_ENUM(dictFctAttribTab[j], A_DictFctAttrib_KeyEncodingEn) == DicFctAttrKeyEncoding_Undefine)
                        {
                            logFlg = TRUE;
                        }
                    }
                }

                /* if not found, insert new record in DB and write message in log file */
                if (foundFlg == FALSE)
                {
                    if (newDictFctAttrib == NULL)
                        newDictFctAttrib = ALLOC_DYNST(A_DictFctAttrib);

                    if (newDictFctAttrib != NULL)
                    {
                        logFlg = TRUE;

                        SET_NULL_ID(newDictFctAttrib, A_DictFctAttrib_DictId);
                        SET_DICT(newDictFctAttrib, A_DictFctAttrib_FctDictId, dictFct);
                        SET_SYSNAME(newDictFctAttrib, A_DictFctAttrib_EntitySqlName, domainEntitySt->mdSqlName);
                        SET_SYSNAME(newDictFctAttrib, A_DictFctAttrib_AttributeSqlName, attribSt->sqlName);
                        SET_ENUM(newDictFctAttrib, A_DictFctAttrib_KeyEncodingEn, DicFctAttrKeyEncoding_Undefine);

                        if (fmtId != ZERO_ID)    /* PMSTA-17133 - 051113 - PMO */
                        {
                            SET_ID(newDictFctAttrib, A_DictFctAttrib_FmtId, fmtId);
                        }

                	    DBA_Insert2(DictFctAttrib, UNUSED, A_DictFctAttrib, newDictFctAttrib, UNUSED, NULL, NULL);;
                    }
                }

                /* if not found or undefine, write message in log file */
                if (logFlg == TRUE)
                {
                    if (logFldNbr == 0)
                    {
                        if ((buffer = (char *) CALLOC(11*(GET_MAXDATALEN(SysnameType)+1), sizeof(char))) != NULL)   /* PMSTA-33077 - DLA - 181012 */
                            sprintf(buffer,"%s", attribSt->sqlName);
                    }
                    else if (logFldNbr < 10 && buffer != NULL)
                    {
                        sprintf(&(buffer[strlen(buffer)]),",%s", attribSt->sqlName);
                    }
                    else if (logFldNbr == 10 && buffer != NULL)
                    {
                        strcat(buffer,", . . .");
                    }

                    logFldNbr++;
                }
            }
        }
	}

    FREE_DYNST(newDictFctAttrib, A_DictFctAttrib);
    DBA_FreeDynStTab(dictFctAttribTab, dictFctAttribNbr, A_DictFctAttrib);

    if (logFldNbr > 0&& buffer != NULL)
    {
        if (fmtId != ZERO_ID)    /* PMSTA-17133 - 051113 - PMO */
        {
            if (fmtCd != NULL && fmtCd[0] != END_OF_STRING)
    	        MSG_SendMesg(RET_FIN_ERR_TSL_KEY_FIELD, 1, FILEINFO, logFldNbr, fmtCd, buffer);
    	    else
	            MSG_SendMesg(RET_FIN_ERR_TSL_KEY_FIELD, 1, FILEINFO, logFldNbr, "unknown", buffer);
		}
		else
		{
            if (DBA_GetDictFctInfo(dictFct, DictFctInfo_ProcName, &fctName) == RET_SUCCEED)
		        MSG_SendMesg(RET_FIN_ERR_TSL_KEY_FIELD, 0, FILEINFO, logFldNbr, fctName, buffer);
		    else
		        MSG_SendMesg(RET_FIN_ERR_TSL_KEY_FIELD, 0, FILEINFO, logFldNbr, "unknown", buffer);
		}
    }

    if (buffer != NULL)
        FREE(buffer);

    return;
}

/************************************************************************
**
**  Function    :   DBA_CopyDynStSupplFld()
**
**  Description :   Copy source dynamic structure on destination
**                  dynamic structure.
**                  Two structures must have same definition which
**                  is received too.
**
**                  Extension field are set to NULL in destination structure
**
**                  Macro COPY_DYNST_SUPPLFLD use this function.
**
**  Arguments   :   dest     destination structure pointer
**                  src      source structure pointer
**                  st       dynamic structure description
**
**  Return      :   TRUE if success, FALSE elsewhere.
**
**  Creation	:   REF3729 - RAK - 020699
**
**  Last Modif. :  GRD - 000204 - REF4204.
**
*************************************************************************/
int DBA_CopyDynStSupplFld(DBA_DYNFLD_STP dest, DBA_DYNFLD_STP src, int fldNbr)
{
        FIELD_IDX_T M_i, from;
    	CTYPE_ENUM	ctp;

        /* DVP172 */
        if (dest == NULL || src == NULL)
                return(FALSE);

        from = 0;
        for (M_i=0; M_i<fldNbr; M_i++)
        {
	    /* Un flag n'est jamais null - REF2837 */
	    if ((GET_FLD_DTP(src,M_i) == FlagType) && (_IS_NULLFLD(src, M_i) == TRUE))  /* PMSTA13244 - DDV - 120120 - Trace DynFld usage */
	    {
		SET_NOTNULLFLG_T(src, M_i);
	    }

	    /* Gestion par bloc : les STRING. ARRAY et EXT ne sont pas copi� */
	    ctp = GET_CTYPE(GET_FLD_DTP(src,M_i));

	    if (ctp == CharPtrCType || ctp == TextPtrCType ||
                ctp == UniCharPtrCType || ctp == UniTextPtrCType ||
                    ctp == ArrayPtrCType || ctp == ExtPtrCType)
            {
                if ((M_i-from)>0)
                {
                    memcpy(&dest[from], &src[from], sizeof(DBA_DYNFLD_ST) * (M_i-from));
                }
/*              from= (unsigned char) (M_i+1);  FIH-REF4029-991129  */
                from= M_i+1;

                /* For string, allocate new space if necessary */
                if (ctp == CharPtrCType  || ctp == TextPtrCType)
                {
                    if(GET_STRING_LEN(src, M_i) > 0)
                    {
                        /* ROI - 001010 - REF5274 */
                        /* SET_STRING(dest, M_i, GET_STRING(src, M_i)); */
                        SET_STRING(dest, M_i, (src[M_i].data.strData.ptr));
                    }
                    else
                    {
                        SET_NULL_STRING(dest, M_i);
                    }
                }
                else if (ctp == UniCharPtrCType  || ctp == UniTextPtrCType)
                {
                    if(GET_USTRING_LEN(src, M_i) > 0)
                    {
                        /* ROI - 001010 - REF5274 */
                        /* SET_STRING(dest, M_i, GET_STRING(src, M_i)); */
                        SET_USTRING(dest, M_i, (src[M_i].data.ustrData.ptr));
                    }
                    else
                    {
                        SET_NULL_USTRING(dest, M_i);
                    }
                }
                else
                {
                    if (ctp == ArrayPtrCType)
                    {
                        SET_ARRAY(dest, M_i, GET_ARRAY_PTR(src, M_i),
                                           GET_ARRAY_ELTNBR(src, M_i),
                                           GET_ARRAY_ELTSZ(src, M_i));
                    }
                    else
                    {
                        /* Force extension to NULL */
                        if (ctp == ExtPtrCType)
			{
                            SET_NULL_EXTENSION(dest, M_i);
			}
                    }
                }
	    }
        }
        if (M_i-from>0)
            memcpy(&dest[from], &src[from], sizeof(DBA_DYNFLD_ST) * (M_i-from));

        return(TRUE);
}

/************************************************************************
**
**  Function    :   DBA_CopyExtension()
**
**  Description :   Copy an extension field from one dynamic structure to another
**			OLD://All dynamic structures must have been allocated !!
**			OLD://This function only copies the extension pointer.
**			OLD://No allocations are done !!
**
**		    SSO 981105: real copy is done!
**
**                  Macro COPY_EXTENSION uses this function.
**
**  Arguments   :   dest     destination structure pointer
**                  df       destination dynamic structure field number
**		    src      source structure pointer
**                  sf       source dynamic structure field number
**
**  Return      :   RET_CODE			if ok
**		    RET_GEN_ERR_INVARG		error in arguments
**
**  Creation D. :   REF347 - 971020 - DED
**  Last modif. :   REF8705 - LJE - 030127 : reactive and modify for use in perf attrib.
**
*************************************************************************/
RET_CODE DBA_CopyExtension(DBA_DYNFLD_STP dest, int df, DBA_DYNFLD_STP src, int sf)
{
	int             nbElt=0;
	DBA_DYNFLD_STP* eltTab=NULL;

	/* Check arguments */
	if (src == NULL || dest == NULL)
	{
		MSG_RETURN(RET_GEN_ERR_INVARG);
	}

	/* Copy extension info */
	 /* OLD CODE dest[df].data.extData = src[sf].data.extData; */

	/* 981105 - SSO real copy... */
	nbElt = GET_EXTENSION_NBR(src,sf);
	if (nbElt != 0)
	{
	    if ((eltTab = (DBA_DYNFLD_STP *)CALLOC(nbElt, sizeof(DBA_DYNFLD_STP))) == NULL)
		    return(RET_MEM_ERR_ALLOC);

	    /* copy the pointers array */
	    memcpy(eltTab, GET_EXTENSION_PTR(src,sf), nbElt*sizeof(DBA_DYNFLD_STP));

        SET_EXTENSION(dest, df, eltTab, GET_EXTENSION_TP(src, sf), nbElt); /* REF8705 - LJE - 030127 */

	}
    else
    {
        SET_NULL_EXTENSION(dest, df);
    }

	return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   DBA_DispDynFld()
**
**  Description :   Display a dynamic structure field value
**
**  Arguments   :   str	      string to display before field display
**		            p         string pointer
**                  dataType  field datatype
**
**  Return      :   none
**  Modifs      :   PMSTA13244 - DDV - 120120 - Trace DynFld usage
**                  PMSTA-16124 - 250413 - PMO : Ensure coherence of printf / scanf formats with 32bits / 64 bits datatypes
**
*************************************************************************/
void DBA_DispDynFld(char *str, DBA_DYNFLD_STP p, DATATYPE_ENUM dataType)
{
	int fld;

	printf("%s ... ",str);

	switch (dataType)
	{
       	case NullDataType:	    printf("NullDataType      )"); break;
       	case AmountType	 :	    printf("AmountType        )"); break;
       	case CodeType	 :	    printf("CodeType          )"); break;
       	case DateType	 :	    printf("DateType          )"); break;
       	case DatetimeType:	    printf("DatetimeType      )"); break;
       	case DictType	 :	    printf("DictType          )"); break;
       	case EnumType	 :	    printf("EnumType          )"); break;
       	case ExchangeType:	    printf("ExchangeType      )"); break;
	    case ExtensionType:     printf("ExtensionType     )"); break;
        case ChainedTypeType:   printf("ChainedTypeType     )"); break; /* PMSTA-34537 - LJE - 190129 */
       	case FlagType	:	    printf("FlagType          )"); break;
       	case IdType		:       printf("IdType            )"); break;
       	case InfoType	:	    printf("InfoType          )"); break;
       	case IntType	:	    printf("IntType           )"); break;
       	case LongamountType:    printf("LongamountType    )"); break;
       	case MaskType	:	    printf("MaskType          )"); break;
		case EnumMaskType:	    printf("EnumMaskType      )"); break;	/* PMSTA13460 - TGU - 120420 */
       	case MethodType :	    printf("MethodType        )"); break;
       	case NameType	:	    printf("NameType          )"); break;
       	case NoteType	:	    printf("NoteType          )"); break;
       	case NumberType :	    printf("NumberType        )"); break;
       	case PercentType:	    printf("PercentType       )"); break;
       	case PeriodType :	    printf("PeriodType        )"); break;
       	case PhoneType  :	    printf("PhoneType         )"); break;
       	case ShortinfoType:	    printf("ShortinfoType     )"); break;
       	case SmallintType:	    printf("SmallintType      )"); break;
       	case SysnameType:	    printf("SysnameType       )"); break;
        case LongSysnameType:	printf("LongSysnameType   )"); break; /* PMSTA-14086 - LJE - 121008 */
	    case TinyintType :      printf("TinyintType       )"); break;
	    case LongintType :      printf("LongintType       )"); break; /* PMSTA-20887 - LJE - 150909 */
       	case TextType   :	    printf("TextType          )"); break;
       	case UrlType   :	    printf("UrlType           )"); break;   /*  FIH-REF8832-030218  */
       	case TimeType   :	    printf("TimeType !        )"); break;
       	case YearType   :	    printf("YearType !        )"); break;
       	case LongnameType:	    printf("LongnameType      )"); break;
        case String1000Type :   printf("String1000Type    )"); break;/* DLA - PMSTA07121 - 090210 */
        case String2000Type :   printf("String2000Type    )"); break;
        case String3000Type :   printf("String3000Type    )"); break;
        case String4000Type :   printf("String4000Type    )"); break;
        case String7000Type :   printf("String7000Type    )"); break;
        case String15000Type:   printf("String15000Type   )"); break;

       	case ArrayType:		printf("ArrayType         )"); break;   /* REF7475 - 021008 - DDB */
       	case MultiArrayType:printf("MultiArrayType    )"); break;   /* REF7475 - 021008 - DDB */
       	case TzOffsetType:	    printf("TzOffsetType      )"); break;   /*  HFI-PMSTA-30817-180515  */
    	case PriceType  :	    printf("PriceType         )"); break; /* PMSTA-41768 - JPR - 201006 */
        default :           printf("Unknown           )");          /* REF7475 - 021008 - DDB */
	}

	fld = 0;

	if (_IS_NULLFLD(p, fld)==TRUE)
	{
		printf("= NULL");
	}
	else
	{
	    printf ("= ");

	    switch (dataType)
	    {
       	    case NullDataType:	printf(" ??? "); break;
       	    case AmountType	 :	printf("%f", _GET_AMOUNT(p,fld)); break;
       	    case CodeType	 :	printf("\"%s\"", _GET_CODE(p,fld)); break;
       	    case DateType	 :	{
				     YEAR_T y; MONTH_T m; DAY_T d;
                                            DATE_Get(_GET_DATE(p,fld),&y,&m,&d);
				     printf("%02d/%02d/%04d",d,m,y);
				    }
				    break;
       	    case DatetimeType:	{
				     YEAR_T y; MONTH_T m; DAY_T d;
                                            DATE_Get(_GET_DATE(p,fld),&y,&m,&d);
				     printf("%02d/%02d/%04d",d,m,y);
				    }
				    break;
       	    case DictType	 :	printf("%" szFormatId,	_GET_DICT(p,fld)); break; /* DLA - PMSTA08801 - 100209 */
       	    case EnumType	 :	printf("%d",	(int) _GET_ENUM(p,fld)); break;
       	    case ExchangeType:	printf("%f",	_GET_EXCHANGE(p,fld)); break;
            case ExtensionType :
                    {
				        int dynStNbr = GET_EXTENSION_NBR(p, fld);

				        printf("ptr=0x" szFormatPointer ", dynStp=%d, nbr=%d",      /* PMSTA-16124 - 250413 - PMO */
			                GET_EXTENSION_PTR(p, fld),
			                (DBA_DYNST_ENUM)GET_EXTENSION_TP(p, fld),
		        	        dynStNbr);
				    }
				    break;

       	    case FlagType	:   printf("%d",	_GET_FLAG(p,fld)); break;
       	    case IdType		:   printf("%" szFormatId,	_GET_ID(p,fld)); break; /* DLA - PMSTA08801 - 100209 */
       	    case InfoType	:	printf("\"%s\"",	_GET_INFO(p,fld)); break;
       	    case IntType	:	printf("%d",	_GET_INT(p,fld)); break;
       	    case LongamountType :   printf("%f",    _GET_LONGAMOUNT(p,fld)); break;
       	    case MaskType	:	printf("%d",	_GET_MASK(p,fld)); break;
       	    case MethodType :	printf("%d",	_GET_METHOD(p,fld)); break;
       	    case NameType	:	printf("\"%s\"",	_GET_NAME(p,fld)); break;
            case NoteType   :	printf("\"%-30s\"", _GET_INFO(p, fld)); break;
       	    case NumberType :	printf("%f",	_GET_NUMBER(p,fld)); break;
       	    case PercentType:	printf("%f",	_GET_PERCENT(p,fld)); break;
       	    case PeriodType :	printf("%d",	_GET_PERIOD(p,fld)); break;
       	    case PhoneType  :	printf("\"%s\"",	_GET_PHONE(p,fld)); break;
       	    case ShortinfoType:	printf("\"%s\"",	_GET_SHORTINFO(p,fld)); break;
       	    case SmallintType:	printf("%d",_GET_SMALLINT(p,fld)); break;
       	    case SysnameType:	printf("\"%s\"",_GET_SYSNAME(p,fld)); break;
       	    case TextType   :	printf("\"%s\"",_GET_TEXT(p,fld)); break;
       	    case UrlType   :	printf("\"%s\"",_GET_URL(p,fld)); break;     /*  FIH-REF8832-030218  */
       	    case TimeType   :	printf("time !"); break;
       	    case TinyintType:	printf("%d",_GET_TINYINT(p,fld)); break;
            case LongintType:   printf("%" szFormatId,	_GET_LONGINT(p,fld)); break; /* PMSTA-20887 - LJE - 150909 */
       	    case YearType   :	printf("year !"); break;
    /*       	case LongnameType:	printf("\"%s\"",GET_LONGNAME(p,fld)); break; DLA - PMSTA-9887 - 110411 */
            case String1000Type :printf("\"%s\"",_GET_VARSTRING2000(p,fld)); break;
            case String2000Type :printf("\"%s\"",_GET_VARSTRING3000(p,fld)); break;
            case String3000Type :printf("\"%s\"",_GET_VARSTRING4000(p,fld)); break;
            case String4000Type :printf("\"%s\"",_GET_VARSTRING7000(p,fld)); break;
            case String7000Type :printf("\"%s\"",_GET_VARSTRING1000(p,fld)); break;
            case String15000Type:printf("\"%s\"",_GET_VARSTRING1000(p,fld)); break;
            case PriceType  :	printf("%f", _GET_PRICE(p, fld)); break; /* PMSTA-41768 - JPR - 201006 */

            case ArrayType :
                {
	        	    int     eltNbr, eltSz;
	        	    eltNbr = GET_ARRAY_ELTNBR(p, fld);
	        	    eltSz = GET_ARRAY_ELTSZ(p, fld);

	        	    printf("ptr=0x" szFormatPointer ", eltNbr=%d eltSz=%d",     /* PMSTA-16124 - 250413 - PMO */
	                           GET_ARRAY_PTR(p, fld), eltNbr, eltSz);
                    break;                                                      /* REF7475 - 021008 - DDB */
        	    }
            case MultiArrayType :
		                    {
				    printf("dim1= %d rec, dim2= %d rec",
				            GET_MULTIARRAY_DIM1(p, fld),
                           GET_MULTIARRAY_DIM2(p, fld));
				    }
                    break;                                                      /* REF7475 - 021008 - DDB */
       	    case TzOffsetType:	printf("%d",	(int) _GET_TZOFFSET(p,fld)); break; /*  HFI-PMSTA-30817-180515  */
	    }
	}

#if 0
	if (IS_GETFLD(p, fld)==TRUE)
    {
	    printf(" <GET> ");
    }

	if (IS_SETFLD(p, fld)==TRUE)
    {
	    printf(" <SET> ");
    }
#endif

	printf("\n");
}


/* #if (defined AAADEBUG) || (defined AAADEBUGMSG) REF4111 - SSO - 991220 comment */
#ifdef NT
#pragma warning(disable:4127)
#endif

/************************************************************************
**
**  Function    :   DBA_DispDynSt()
**
**  Description :   Display a dynamic structure
**
**  Arguments   :   p	   dynamic structure pointer
**		            s      dynamic structure enum
**                  object entity enum attached to the structure
**
**		            REF3871 - SSO - 990803: call DBA_DispDynStF
**
*************************************************************************/
void DBA_DispDynSt(DBA_DYNFLD_STP p, DBA_DYNST_ENUM s, OBJECT_ENUM object)
{
    DBA_DispDynStF(p, s, object, NULL);
}


/************************************************************************
**
**  Function    :   DBA_DispDynStF()
**
**  Description :   Display a dynamic structure
**
**  Arguments   :   p	        dynamic structure pointer
**		            s           dynamic structure enum
**                  object      entity enum attached to the structure
**                  outputStream    the stream to output on (if any)
**
**  Last modif. :   REF7264 - 011212 - PMO : Compilation errors and warnings with C++ compiler
**
*************************************************************************/
STATIC void DBA_DispDynStH(DBA_DYNFLD_STP p, DBA_DYNST_ENUM s, OBJECT_ENUM object, std::ostream * outputStream)
{
    /* 030402 - PMO */
    if (outputStream != nullptr)
    {
        *outputStream <<  SYS_GetFormatedTime();
    }

	/* REF4111 - SSO - 991220 */
	DBA_DispDynStFH(p, s, object, outputStream);
}


/************************************************************************
**
**  Function    :   DBA_DispDynStF()
**
**  Description :   Display a dynamic structure
**
**  Arguments   :   p	        dynamic structure pointer
**		            s           dynamic structure enum
**                  object      entity enum attached to the structure
**                  fileName    File name. Can be NULL
**
**  Last modif. :   REF3871 - SSO - 990803 : added fileName parameter to output in a file
**                  030402 - PMO           : Bug Fix
**                  REF10421 - 040622 - PMO : Several operations are not accessible through the GUI
**
*************************************************************************/
void DBA_DispDynStF(DBA_DYNFLD_STP p, DBA_DYNST_ENUM s, OBJECT_ENUM object, char* fileName)
{
    std::ofstream * fout = nullptr;

	if (fileName != NULL)
	{
        fout = new std::ofstream (fileName,std::ios::out | std::ios::app);
	}

    /* REF10421 - 040701 - PMO */
    DBA_DispDynStH(p, s, object, fout);

	if (fout != nullptr)
	{
        fout->close();
	}
}


/************************************************************************
**
**  Function    :   DBA_DispDynStFHByPtr()
**
**  Last modif. :   REF7264 - 011212 - PMO : Compilation errors and warnings with C++ compiler
**
*************************************************************************/
void DBA_DispDynStFHByPtr(PTR p, DBA_DYNST_ENUM s, OBJECT_ENUM object, std::ostream * os)
{
	DBA_DispDynStFH((DBA_DYNFLD_STP) p, s, object, os);
}

/************************************************************************
**
**  Function    :   DBA_DispDynStLogFile()
**
**  Description :   Display a dynamic structure
**
**  Arguments   :   p	        dynamic structure pointer
**		            enStr       dynamic structure enum
**                  objectStr   entity enum attached to the structure
**                  fileName    File name. Can be NULL
**
**  Creation    :   REF10421 - 040622 - PMO : Several operations are not accessible through the GUI
**  Last modif. :   REF11860 - 060808 - BSA : Compilation warnings with C++ compiler
*************************************************************************/
void DBA_DispDynStLogFile(DBA_DYNFLD_STP p, const char * enStr, const	char * objectStr)
{
    std::ostringstream  myStringStream;
    DBA_DispDynStH(p,
                   (DBA_DYNST_ENUM)DBA_GetDynStByCName(enStr),
                   (OBJECT_ENUM)DBA_GetObjectByCName(enStr),
                    &myStringStream);

    fprintf(SV_msgFile, myStringStream.str().c_str());
    fflush(SV_msgFile);
}

/************************************************************************
**
**  Function    :   DBA_DispDynStFH()
**
**  Description :   Display a dynamic structure in a file
**
**  Arguments   :   p	    dynamic structure pointer
**		            s       dynamic structure enum
**                  object  entity enum attached to the structure
**		            outputStream    the stream to output on (if any)
**  Last modif. :   REF4111 - SSO - 991220: DBA_DispDynStF created with FILE* parameter, to separate file open/close
**                  REF7264 - 011212 - PMO : Compilation errors and warnings with C++ compiler
**                  REF10421 - 040622 - PMO : Several operations are not accessible through the GUI
**                  PMSTA13244 - DDV - 120120 - Trace DynFld usage
**                  PMSTA-13593 - 310112 - PMO : Following a modify currency and an allocate order, some positions are doubles and the linked operation record is missing in the database
**                  PMSTA-16124 - 250413 - PMO : Ensure coherence of printf / scanf formats with 32bits / 64 bits datatypes
**
*************************************************************************/
void DBA_DispDynStFH(DBA_DYNFLD_STP p, DBA_DYNST_ENUM s, OBJECT_ENUM object, std::ostream * outputStream)
{
	int 	fld;            /* PMSTA-16124 - 250413 - PMO */
	char 	*buf = NULL;    /* REF3871 - SSO - 990803 */

	/* WARNING TextType could now be 65535 long! REF4204 */
	if ((buf = (char*) CALLOC(70000, sizeof(char))) == NULL) /* REF7264 - PMO */
	{
		AAA_RPT0(_CRT_WARN, "Memory alloc error. No display possible. Sorry ...\n");
		return;
	}

	/* DED 000112 */
	if (p == NULL)
    {
        AAA_RPT0(_CRT_WARN, "The record pointer is NULL. No display possible. Sorry ...\n");
	    FREE(buf);
        return;
    }

	for (fld=0 ; fld<GET_FLD_NBR(s) ; fld++)
	{
		buf[0] = '\0'; /* REF3871 - SSO - 990803  reset for next line */
		AAA_TRACE2(buf, "FIELD[%2d] \"%-25s\" (",
			fld, (object==-1)?"":
			      DBA_GetDictAttribSqlName(object, fld));

		switch (GET_FLD_TYPE(s, fld))
		{
        	case NullDataType:	    AAA_TRACE0(buf, "NullDataType      )"); break;
        	case AmountType	 :	    AAA_TRACE0(buf, "AmountType        )"); break;
        	case CodeType	 :	    AAA_TRACE0(buf, "CodeType          )"); break;
        	case DateType	 :	    AAA_TRACE0(buf, "DateType          )"); break;
        	case DatetimeType:	    AAA_TRACE0(buf, "DatetimeType      )"); break;
        	case DictType	 :	    AAA_TRACE0(buf, "DictType          )"); break;
        	case EnumType	 :	    AAA_TRACE0(buf, "EnumType          )"); break;
        	case ExchangeType:	    AAA_TRACE0(buf, "ExchangeType      )"); break;
            case ExtensionType:     AAA_TRACE0(buf, "ExtensionType     )"); break;
            case ChainedTypeType:   AAA_TRACE0(buf, "ChainedTypeType   )"); break; /* PMSTA-34537 - LJE - 190129 */
        	case FlagType	:	    AAA_TRACE0(buf, "FlagType          )"); break;
        	case IdType		:       AAA_TRACE0(buf, "IdType            )"); break;
        	case InfoType	:	    AAA_TRACE0(buf, "InfoType          )"); break;
        	case IntType	:	    AAA_TRACE0(buf, "IntType           )"); break;
        	case LongamountType:    AAA_TRACE0(buf, "LongamountType    )"); break;
        	case MaskType	:	    AAA_TRACE0(buf, "MaskType          )"); break;
        	case EnumMaskType:	    AAA_TRACE0(buf, "EnumMaskType      )"); break;	/* PMSTA13460 - TGU - 120420 */
			case MethodType :	    AAA_TRACE0(buf, "MethodType        )"); break;
        	case NameType	:	    AAA_TRACE0(buf, "NameType          )"); break;
        	case NoteType	:	    AAA_TRACE0(buf, "NoteType          )"); break;
        	case NumberType :	    AAA_TRACE0(buf, "NumberType        )"); break;
        	case PercentType:	    AAA_TRACE0(buf, "PercentType       )"); break;
        	case PeriodType :	    AAA_TRACE0(buf, "PeriodType        )"); break;
        	case PhoneType  :	    AAA_TRACE0(buf, "PhoneType         )"); break;
        	case ShortinfoType:	    AAA_TRACE0(buf, "ShortinfoType     )"); break;
        	case SmallintType:	    AAA_TRACE0(buf, "SmallintType      )"); break;
        	case SysnameType:	    AAA_TRACE0(buf, "SysnameType       )"); break;
            case LongSysnameType:   AAA_TRACE0(buf, "LongSysnameType   )"); break; /* PMSTA-14086 - LJE - 121008 */
            case TinyintType :      AAA_TRACE0(buf, "TinyintType       )"); break;
            case LongintType :      AAA_TRACE0(buf, "LongintType       )"); break; /* PMSTA-20887 - LJE - 150909 */
        	case TextType   :	    AAA_TRACE0(buf, "TextType          )"); break;
        	case UrlType   :	    AAA_TRACE0(buf, "UrlType           )"); break;      /*  FIH-REF8832-030218  */
        	case TimeType   :	    AAA_TRACE0(buf, "TimeType !        )"); break;
        	case YearType   :	    AAA_TRACE0(buf, "YearType !        )"); break;
        	case LongnameType:	    AAA_TRACE0(buf, "LongnameType      )"); break;
        	case ArrayType  :	    AAA_TRACE0(buf, "ArrayType         )"); break;
        	case MultiArrayType:    AAA_TRACE0(buf, "MultiArrayType    )"); break;
            case String1000Type :   AAA_TRACE0(buf, "String1000Type    )"); break; /* DLA - PMSTA07121 - 090210 */
            case String2000Type :   AAA_TRACE0(buf, "String2000Type    )"); break;
            case String3000Type :   AAA_TRACE0(buf, "String3000Type    )"); break;
            case String4000Type :   AAA_TRACE0(buf, "String4000Type    )"); break;
            case String7000Type :   AAA_TRACE0(buf, "String7000Type    )"); break;
            case String15000Type:   AAA_TRACE0(buf, "String15000Type   )"); break;
            case TimeStampTType:    AAA_TRACE0(buf, "TimeStamp         )"); break;     /* PMSTA-20883 - TEB - 150608 */ /* PMSTA-34445 - LJE - 190401 */
			case TimeStampType:     AAA_TRACE0(buf, "TimeStamp         )"); break;      /* PMSTA-13593 - 310112 - PMO */ /* PMSTA-34445 - LJE - 190401 */
            case PtrType :          AAA_TRACE0(buf, "PtrType           )"); break;      /* PMSTA-13593 - 310112 - PMO */
            case PriceType:	        AAA_TRACE0(buf, "PriceType         )"); break;      /* PMSTA-41768 - JPR - 201006 */
            case TzOffsetType :     AAA_TRACE0(buf, "TzOffsetType      )"); break;      /* PMSTA-30818 - DLA - 180403 */

		}

		AAA_TRACE0(buf, " = ");

		if (_IS_NULLFLD(p, fld)==TRUE)
		{
			AAA_TRACE0(buf, "NULL");
		}
		else
		{

		    switch (GET_FLD_TYPE(s, fld))
		    {

        	    case NullDataType:	AAA_TRACE0(buf, " ??? "); break;
        	    case AmountType	 :	AAA_TRACE1(buf, "%f", _GET_AMOUNT(p,fld)); break;
        	    case CodeType	 :	AAA_TRACE1(buf, "\"%s\"", _GET_CODE(p,fld)); break;
        	    case DateType	 :	{
					     YEAR_T y; MONTH_T m; DAY_T d;
                                             DATE_Get(_GET_DATE(p,fld),&y,&m,&d);
					     AAA_TRACE3(buf, "%02d/%02d/%04d",d,m,y);
					    }
					    break;
        	    case DatetimeType:	{
					     YEAR_T y; MONTH_T m; DAY_T d; HOUR_T h;MINUTE_T min;SECOND_T sec;
					     DATETIME_T datetime;

					     datetime = _GET_DATETIME(p,fld);

                                             DATE_Get(datetime.date,&y,&m,&d);
                                             TIME_Get(datetime.time,&h,&min,&sec);
					     AAA_TRACE3(buf, "%02d/%02d/%04d ",d,m,y);
					     AAA_TRACE3(buf, "%02d:%02d:%02d ",h,min,sec);
					    }
					    break;
        	    case DictType	 :	AAA_TRACE1(buf, "%" szFormatId,	_GET_DICT(p,fld)); break; /* DLA - PMSTA08801 - 100209 */
        	    case EnumType	 :	AAA_TRACE1(buf, "%d",	_GET_ENUM(p,fld)); break;
        	    case ExchangeType:	AAA_TRACE1(buf, "%18.9f", _GET_EXCHANGE(p,fld)); break;
                case ExtensionType :	{
					    int     dynStNbr;

					    dynStNbr = GET_EXTENSION_NBR(p, fld);

					    AAA_TRACE3(buf, "ptr=0x" szFormatPointer ", dynStp=%d, nbr=%d",             /* PMSTA-16124 - 250413 - PMO */
				            GET_EXTENSION_PTR(p, fld),
				            (DBA_DYNST_ENUM)GET_EXTENSION_TP(p, fld),
			        	    dynStNbr);
					    }
					    break;

        	    case FlagType	:	AAA_TRACE1(buf, "%d",	_GET_FLAG(p,fld)); break;
        	    case IdType		:	AAA_TRACE1(buf, "%" szFormatId, _GET_ID(p,fld)); break; /* DLA - PMSTA08801 - 100209 */
        	    case InfoType	:	AAA_TRACE1(buf, "\"%s\"",	_GET_INFO(p,fld)); break;
        	    case IntType	:	AAA_TRACE1(buf, "%d",	_GET_INT(p,fld)); break;
        	    case LongamountType :	AAA_TRACE1(buf, "%f",    _GET_LONGAMOUNT(p,fld)); break;
        	    case MaskType	:	AAA_TRACE1(buf, "%d",	_GET_MASK(p,fld)); break;
        	    case MethodType :	AAA_TRACE1(buf, "%d",	_GET_METHOD(p,fld)); break;
        	    case NameType	:	AAA_TRACE1(buf, "\"%s\"",	_GET_NAME(p,fld)); break;
                case NoteType   :	AAA_TRACE1(buf, "\"%-30s\"", _GET_INFO(p, fld)); break;
        	    case NumberType :	AAA_TRACE1(buf, "%f",	_GET_NUMBER(p,fld)); break;
        	    case PercentType:	AAA_TRACE1(buf, "%f",	_GET_PERCENT(p,fld)); break;
        	    case PeriodType :	AAA_TRACE1(buf, "%d",	_GET_PERIOD(p,fld)); break;
        	    case PhoneType  :	AAA_TRACE1(buf, "\"%s\"",	_GET_PHONE(p,fld)); break;
        	    case ShortinfoType:	AAA_TRACE1(buf, "\"%s\"",	_GET_SHORTINFO(p,fld)); break;
        	    case SmallintType:	AAA_TRACE1(buf, "%d",_GET_SMALLINT(p,fld)); break;
        	    case SysnameType:	AAA_TRACE1(buf, "\"%s\"",_GET_SYSNAME(p,fld)); break;
        	    case TextType   :	AAA_TRACE1(buf, "\"%s\"",_GET_TEXT(p,fld)); break;
        	    case UrlType   :	AAA_TRACE1(buf, "\"%s\"",_GET_URL(p,fld)); break;            /*  FIH-REF8832-030218  */
        	    case TimeType   :	AAA_TRACE0(buf, "time !"); break;
        	    case TinyintType:	AAA_TRACE1(buf, "%d",_GET_TINYINT(p,fld)); break;
                case LongintType  :	AAA_TRACE1(buf, "%" szFormatId, _GET_LONGINT(p, fld)); break; /* PMSTA-20887 - LJE - 150909 */
        	    case YearType   :	AAA_TRACE0(buf, "year !"); break;
        	    case LongnameType:	AAA_TRACE1(buf, "\"%s\"",_GET_NAME(p,fld)); break;
                case String1000Type :   AAA_TRACE1(buf, "\"%s\"",_GET_VARSTRING1000(p,fld)); break; /* DLA - PMSTA07121 - 090210 */
                case String2000Type :   AAA_TRACE1(buf, "\"%s\"",_GET_VARSTRING2000(p,fld)); break;
                case String3000Type :   AAA_TRACE1(buf, "\"%s\"",_GET_VARSTRING3000(p,fld)); break;
                case String4000Type :   AAA_TRACE1(buf, "\"%s\"",_GET_VARSTRING4000(p,fld)); break;
                case String7000Type :   AAA_TRACE1(buf, "\"%s\"",_GET_VARSTRING7000(p,fld)); break;
                case String15000Type:   AAA_TRACE1(buf, "\"%s\"",_GET_VARSTRING15000(p,fld)); break;
                case PriceType  :	AAA_TRACE1(buf, "%23.14f", _GET_PRICE(p, fld)); break; /* PMSTA-41768 - JPR - 201006 */
                case ArrayType : 	{
		        		    int     eltNbr, eltSz;
		        		    eltNbr = GET_ARRAY_ELTNBR(p, fld);
		        		    eltSz = GET_ARRAY_ELTSZ(p, fld);

		        		    AAA_TRACE3(buf, "ptr=0x" szFormatPointer ", eltNbr=%d eltSz=%d",            /* PMSTA-16124 - 250413 - PMO */
		                                   GET_ARRAY_PTR(p, fld), eltNbr, eltSz);
	                		    }
                                            break;
                case MultiArrayType :
			                    {
					    AAA_TRACE2(buf, "dim1= %d rec, dim2= %d rec",
                                GET_MULTIARRAY_DIM1(p, fld),
                                GET_MULTIARRAY_DIM2(p, fld));
					    }
                                            break;
				case TimeStampTType: /* PMSTA-20883 - TEB - 150608 */
				case TimeStampType: AAA_TRACE1(buf, szFormatTimeStamp, GET_TIMESTAMP(p, fld));  break;  /* PMSTA-13593 - 310112 - PMO */
                case PtrType       : AAA_TRACE1(buf, "%p",GET_PTR(p,fld)); break;                       /* PMSTA-13593 - 310112 - PMO */
                case TzOffsetType  : AAA_TRACE1(buf, "%d",GET_TZOFFSET(p,fld)); break;                  /* PMSTA-30818 - DLA - 180403 */

		    }
        }
		AAA_TRACE0(buf, "\n");

		if (outputStream != NULL)
		{
            *outputStream << buf;
		}
        else
        {
            /* Code moved here REF10421 - 040701 - PMO */
            AAA_RPT0(_CRT_WARN, buf);
        }
	}

	FREE(buf);	/* REF4204 */
}


/************************************************************************
**
**  Function    :   DBA_GetFieldDataType()
**
**  Description :
**
**  Arguments   :
**
**  Last modif. :   REF9751-EFE-050120
**                  REF11780 - 100406 - PMO : Implementation of the Sybase timestamp field
**                  PMSTA-11193 - 120111 - PMO : Input control warning/error messages must not be truncated after 254 characters in the WUI
**
*************************************************************************/
void DBA_GetFieldDataType(char *buf, DBA_DYNFLD_STP p, FIELD_IDX_T fld, DBA_CFIELDDEF_STP   fieldStp, FLAG_T)
{
	if (buf != NULL)
	{
		DBA_GetDataTypeEnumToStr(buf, GET_FLD_DTP(p, fld));	 /* PMSTA-11193 - 120111 - PMO */
	}
}


/************************************************************************
**
**  Function    :   DBA_GetDataTypeEnumToStr()
**
**  Description : switch statment to convert DATATYPE_ENUM to string.
**
**  Arguments   :
**
**  Last modif. :   PMSTA-16395 - TGU - 150720
**
*************************************************************************/
void 	DBA_GetDataTypeEnumToStr(char* buf, DATATYPE_ENUM dataTypeEnum)
{
	if (buf != NULL)
	{
		switch (dataTypeEnum) /* PMSTA-11193 - 120111 - PMO */
		{
            case NullDataType:	    strcpy(buf, "NullDataType"); break;
			case AmountType:	    strcpy(buf, "AmountType"); break;
			case CodeType:	    strcpy(buf, "CodeType"); break;
			case DateType:	    strcpy(buf, "DateType"); break;
			case DatetimeType:	    strcpy(buf, "DatetimeType"); break;
			case DictType:	    strcpy(buf, "DictType"); break;
			case EnumType:	    strcpy(buf, "EnumType"); break;
			case ExchangeType:	    strcpy(buf, "ExchangeType"); break;
			case ExtensionType:     strcpy(buf, "ExtensionType"); break;
            case ChainedTypeType:     strcpy(buf, "ChainedTypeType"); break; /* PMSTA-34537 - LJE - 190129 */
			case FlagType:	    strcpy(buf, "FlagType"); break;
			case IdType:       strcpy(buf, "IdType"); break;
			case InfoType:	    strcpy(buf, "InfoType"); break;
			case IntType:	    strcpy(buf, "IntType"); break;
			case LongamountType:    strcpy(buf, "LongamountType"); break;
			case MaskType:	    strcpy(buf, "MaskType"); break;
			case EnumMaskType:	    strcpy(buf, "EnumMaskType"); break;     /* PMSTA13460 - TGU - 120420 */
			case MethodType:	    strcpy(buf, "MethodType"); break;
			case NameType:	    strcpy(buf, "NameType"); break;
			case NoteType:	    strcpy(buf, "NoteType"); break;
			case NumberType:	    strcpy(buf, "NumberType"); break;
			case PercentType:	    strcpy(buf, "PercentType"); break;
			case PeriodType:	    strcpy(buf, "PeriodType"); break;
			case PhoneType:	    strcpy(buf, "PhoneType"); break;
			case ShortinfoType:	    strcpy(buf, "ShortinfoType"); break;
			case SmallintType:	    strcpy(buf, "SmallintType"); break;
			case SysnameType:	    strcpy(buf, "SysnameType"); break;
			case LongSysnameType:   strcpy(buf, "LongSysnameType"); break; /* PMSTA-14086 - LJE - 121008 */
			case TinyintType:      strcpy(buf, "TinyintType"); break;
            case LongintType:      strcpy(buf, "LongintType"); break; /* PMSTA-20887 - LJE - 150909 */
			case TextType:	    strcpy(buf, "TextType"); break;
			case UrlType:	    strcpy(buf, "UrlType"); break;
			case TimeType:	    strcpy(buf, "TimeType !"); break;
			case YearType:	    strcpy(buf, "YearType !"); break;
			case LongnameType:	    strcpy(buf, "LongnameType "); break;
			case ArrayType:	    strcpy(buf, "ArrayType"); break;
			case MultiArrayType:    strcpy(buf, "MultiArrayType"); break;
			case LongStringType:    strcpy(buf, "LongStringType"); break;
			case PtrType:           strcpy(buf, "PtrType"); break;
			case VarInfoType:       strcpy(buf, "VarInfoType"); break;
			case VarNoteType:       strcpy(buf, "VarNoteType"); break;
			case VarNameType:       strcpy(buf, "VarNameType"); break;
			case VarTextType:       strcpy(buf, "VarTextType"); break;
			case VarLongnameType:   strcpy(buf, "VarLongnameType"); break;
			case VarStringType:     strcpy(buf, "VarStringType"); break;
			case UniCodeType:       strcpy(buf, "UniCodeType"); break;
			case UniInfoType:       strcpy(buf, "UniInfoType"); break;
			case UniLongnameType:   strcpy(buf, "UniLongnameType"); break;
			case UniNameType:       strcpy(buf, "UniNameType"); break;
			case UniNoteType:       strcpy(buf, "UniNoteType"); break;
			case UniPhoneType:      strcpy(buf, "UniPhoneType"); break;
			case UniShortinfoType:  strcpy(buf, "UniShortinfoType"); break;
			case UniSysnameType:    strcpy(buf, "UniSysnameType"); break;
			case UniTextType:       strcpy(buf, "UniTextType"); break;
			case UniUrlType:        strcpy(buf, "UniUrlType"); break;
			case TimeStampTType:    strcpy(buf, "TimeStampTType"); break; /* PMSTA-20883 - TEB - 150608 */ /* PMSTA-34445 - LJE - 190401 */
			case TimeStampType:     strcpy(buf, "TimeStampType"); break; /* REF11780 - 100406 - PMO */     /* PMSTA-34445 - LJE - 190401 */
			case BinaryType:        strcpy(buf, "BinaryType"); break;    /*  DLA - PMSTA05995 - 080409 */
			case String1000Type:    strcpy(buf, "String1000Type"); break;        /* PMSTA-11193 - 120111 - PMO */
			case String2000Type:    strcpy(buf, "String2000Type"); break;        /* PMSTA-11193 - 120111 - PMO */
			case String3000Type:    strcpy(buf, "String3000Type"); break;        /* PMSTA-11193 - 120111 - PMO */
			case String4000Type:    strcpy(buf, "String4000Type"); break;        /* PMSTA-11193 - 120111 - PMO */
			case UniString1000Type: strcpy(buf, "UniString1000Type"); break;     /* PMSTA-11193 - 120111 - PMO */
			case UniString2000Type: strcpy(buf, "UniString2000Type"); break;     /* PMSTA-11193 - 120111 - PMO */
			case String7000Type:    strcpy(buf, "String7000Type"); break;        /* PMSTA-11193 - 120111 - PMO */
			case String15000Type:   strcpy(buf, "String15000Type"); break;       /* PMSTA-11193 - 120111 - PMO */
			case UniString3000Type: strcpy(buf, "UniString3000Type"); break;     /* PMSTA-11193 - 120111 - PMO */
			case UniString4000Type: strcpy(buf, "UniString4000Type"); break;     /* PMSTA-11193 - 120111 - PMO */
			case UniString7000Type: strcpy(buf, "UniString7000Type"); break;     /* PMSTA-11193 - 120111 - PMO */
			case UniString15000Type:strcpy(buf, "UniString15000Type"); break;    /* PMSTA-11193 - 120111 - PMO */
			case VarString1000Type: strcpy(buf, "VarString1000Type"); break; /*  DLA - PMSTA07121 - 081212 */
			case VarString2000Type: strcpy(buf, "VarString2000Type"); break; /*  DLA - PMSTA07121 - 081212 */
			case VarString3000Type: strcpy(buf, "VarString3000Type"); break; /*  DLA - PMSTA07121 - 081212 */
			case VarString4000Type: strcpy(buf, "VarString4000Type"); break; /*  DLA - PMSTA07121 - 081212 */
			case VarString7000Type: strcpy(buf, "VarString7000Type"); break; /*  DLA - PMSTA07121 - 081212 */
			case VarString15000Type:strcpy(buf, "VarString15000Type"); break;/*  DLA - PMSTA07121 - 081212 */
            case PriceType:	        strcpy(buf, "PriceType"); break; /* PMSTA-41768 - JPR - 201006 */
           	case TzOffsetType:	    strcpy(buf, "TzOffsetType      "); break;   /*  HFI-PMSTA-30817-180515  */
            case BlobType:          strcpy(buf, "BlobType          "); break;   /*  PMSTA-50418 - DDV - 221018 */
			default:               strcpy(buf, "UnknownType"); break;
		}
	}
 }

/************************************************************************
**
**  Function    :   DBA_GetFieldName()
**
**  Description :
**
**  Arguments   :
**
**  Last modif. :   REF9751-EFE-050120
**
*************************************************************************/
void DBA_GetFieldName(  char *buf, DBA_CFIELDDEF_STP   fieldStp)
{
    sprintf ( buf, "%s", fieldStp->sqlName);
}

/************************************************************************
**
**  Function    :   DBA_SafeStrncpy()
**
**  Description :   safe copy  of a string
**
**  Arguments   :   dest      : string destination
**                  taille
**                  src
**
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation
**       REF11571-EFE-051130
**
*************************************************************************/
void DBA_SafeStrncpy(char *dest, size_t taille, const char *src )
{
    if ( src == NULL )
    {
        dest[0]= '\0';
    }
    else
    {
        size_t lgr = strlen ( src );

        strncpy ( dest, src, taille);
        if ( lgr >= taille )
        {
            dest [taille -1]= '\0';
        }
        else
        {
            dest [lgr] = '\0';
        }
    }
}

/************************************************************************
**
**  Function    :   DBA_GetFieldValue()
**
**  Description :
**
**  Arguments   :
**
**  Last modif. :   REF9751-EFE-050120
**                  PMSTA-9175 - 050110 - PMO : TDDJ can crash if the exchange gain P&L is no more generated
**                  PMSTA13244 - DDV - 120120 - Trace DynFld usage
**                  PMSTA-13729 - 040412 - PMO : Full support of 64bit on Unix platforms
**                  PMSTA-14731 - 020812 - PMO : Avoid infinite loop when reposting new fusion requests and when generating fusion xml trace files by fusion servers
**                  PMSTA-17133 - 051113 - PMO : Many compilation warnings in C code especially " Converting a 64-bit type value to "int" causes truncation."
**                  PMSTA-30823 - 050418 - PMO : SCPT_FmtEltAnalyse: Source and destination overlap in mempcpy
**
*************************************************************************/
void DBA_GetFieldValue(char *buf, size_t taille, DBA_DYNFLD_STP p, FIELD_IDX_T fld, FLAG_T)
{

	if (NULL == p || _IS_NULLFLD(p, fld)==TRUE)
	{
		snprintf(buf, taille , "NULL");
	}
    else
    {
		switch (GET_FLD_DTP(p, fld))
		{

        	case NullDataType:	snprintf(buf, taille,  " ??? "); break;
        	case AmountType	 :	snprintf(buf, taille,  "%f", _GET_AMOUNT(p,fld)); break;
        	case CodeType	 :	DBA_SafeStrncpy(buf, taille, (char*) _GET_CODE(p,fld)); break;
        	case DateType	 :	{
					 YEAR_T y; MONTH_T m; DAY_T d;
                                         DATE_Get(_GET_DATE(p,fld),&y,&m,&d);
					 snprintf(buf, taille,  "%02d/%02d/%04d",d,m,y);
					}
					break;
        	case DatetimeType:	{
					 YEAR_T y; MONTH_T m; DAY_T d; HOUR_T h;MINUTE_T min;SECOND_T s;

                     DATETIME_T datetime = _GET_DATETIME(p,fld);
                                         DATE_Get(datetime.date,&y,&m,&d);
                                         TIME_Get(datetime.time,&h,&min,&s);
					 snprintf(buf, taille,  "%02d/%02d/%04d %02d:%02d:%02d ",d,m,y, h,min,s );
					}
					break;
        	case DictType	 :	snprintf(buf, taille,  "%" szFormatId,	_GET_DICT(p,fld)); break; /* DLA - PMSTA08801 - 100209 */
        	case EnumType	 :	snprintf(buf, taille,  "%d",    int(_GET_ENUM(p,fld))); break;
        	case ExchangeType:	snprintf(buf, taille,  "%18.9f", _GET_EXCHANGE(p,fld)); break;
            case ExtensionType :
                    {
                        /* REF10195 - LJE - 040413 : Add Ids */
                        int                 dynStNbr = GET_EXTENSION_NBR(p, fld);
                        DBA_DYNFLD_STP *    dynStTab = GET_EXTENSION_PTR(p, fld);

                        if (GET_EXTENSION_TP(p, fld) == NullDynSt)
                        {
                            snprintf(buf, taille,  "dynStp=NullDynSt: nbr=%d", dynStNbr);
                        }
                        else
                        {
                            snprintf(buf, taille,  "dynStp=%s: nbr=%d",
                                    DYN_V2N((DBA_DYNST_ENUM)GET_EXTENSION_TP(p, fld)),
                                    dynStNbr);
                        }

                        if (dynStNbr > 0 && dynStTab[0][0].dataType == IdType)
                        {
                            strncat(buf, ": id(", taille);                                                          /* PMSTA-30823 - 050418 - PMO */

                            if (dynStNbr >= 1000)
                            {
                                strncat(buf, "Too Many:" , taille);                                                 /* PMSTA-30823 - 050418 - PMO */
                            }

                            for (int dynStPos=0; dynStPos<dynStNbr && dynStPos<1000; dynStPos++)
                            {
                                char szId[32];

                                snprintf(szId, sizeof(szId), "%" szFormatId ":",  _GET_ID(dynStTab[dynStPos], 0));  /* PMSTA-30823 - 050418 - PMO / DLA - PMSTA08801 - 100209 */
                                strncat(buf, szId, taille);                                                         /* PMSTA-30823 - 050418 - PMO */
                            }

                            strncat(buf, ")", taille);                                                              /* PMSTA-30823 - 050418 - PMO */
                        }
                    }
                    break;

        	case FlagType	:	snprintf(buf, taille,  "%d",    int(_GET_FLAG(p,fld))); break;
        	case IdType		:	snprintf(buf, taille,  "%" szFormatId,	_GET_ID(p,fld)); break;  /* DLA - PMSTA08801 - 100209 */
        	case InfoType	:	DBA_SafeStrncpy(buf, taille,	_GET_INFO(p,fld)); break;
        	case IntType	:	snprintf(buf, taille,  "%d",	_GET_INT(p,fld)); break;
        	case LongamountType :	snprintf(buf, taille,  "%f",    _GET_LONGAMOUNT(p,fld)); break;
        	case MaskType	:
                {
                    int i=(sizeof(MASK_T)*8)-1;

                    snprintf(buf, taille,  "(%d)->", _GET_MASK(p,fld));

                    for (;i>=0; i--)
                    {
                        if ((_GET_MASK(p,fld) >= pow(2., i)) || i==0) /* PMO Change the first argument type */
                        {
                            char szMask[32];

                            snprintf(szMask, sizeof(szMask), "%d", _GET_MASKBIT(p,fld,i));
                            strncat(buf, szMask, taille);                                                           /* PMSTA-30823 - 050418 - PMO */

                            if (i%4 == 0)
                            {
                                strncat(buf, " ", taille);                                                          /* PMSTA-30823 - 050418 - PMO */
                            }
                        }
                    }
                    break;
                }
			case EnumMaskType:				 /* PMSTA13460 - TGU - 120420*/
				snprintf(buf, taille,  "%" szFormatId,	_GET_MASK64(p,fld)); break;
				break;
        	case MethodType :	snprintf(buf, taille,  "%d",	_GET_METHOD(p,fld)); break;
        	case NameType	:	DBA_SafeStrncpy(buf, taille,  _GET_NAME(p,fld)); break;
            case NoteType   :	DBA_SafeStrncpy(buf, taille,  _GET_INFO(p, fld)); break;
        	case NumberType :	snprintf(buf, taille,  "%f",	_GET_NUMBER(p,fld)); break;
        	case PercentType:	snprintf(buf, taille,  "%f",	_GET_PERCENT(p,fld)); break;
        	case PeriodType :	snprintf(buf, taille,  "%d",	_GET_PERIOD(p,fld)); break;
        	case PhoneType  :	DBA_SafeStrncpy(buf, taille,  _GET_PHONE(p,fld)); break;
            case PriceType  :	snprintf(buf, taille, "%23.14f", _GET_PRICE(p, fld)); break; /* PMSTA-41768 - JPR - 201006 */
        	case ShortinfoType:	snprintf(buf, taille,  "%s", _GET_SHORTINFO(p,fld)); break; /* PMSTA-13729 - 040412 - PMO / BSA - REF11817 - 060531 */
        	case SmallintType:	snprintf(buf, taille,  "%d", int(_GET_SMALLINT(p,fld))); break;
        	case SysnameType:	DBA_SafeStrncpy(buf, taille, _GET_SYSNAME(p,fld)); break;
            case LongSysnameType:	DBA_SafeStrncpy(buf, taille, _GET_LONGSYSNAME(p,fld)); break; /* PMSTA-14086 - LJE - 121008 */
        	case TextType   :	DBA_SafeStrncpy(buf, taille, _GET_TEXT(p,fld)); break;
        	case UrlType   :	DBA_SafeStrncpy(buf, taille, _GET_URL(p,fld)); break;            /*  FIH-REF8832-030218  */
        	case TimeType   :	snprintf(buf, taille,  "time !"); break;
        	case TinyintType:	snprintf(buf, taille,  "%d", int(_GET_TINYINT(p,fld))); break;
            case LongintType:	snprintf(buf, taille, "%" szFormatId, _GET_LONGINT(p, fld)); break;  /* PMSTA-20887 - LJE - 150909 */
        	case YearType   :	snprintf(buf, taille,  "year !"); break;
			case TimeStampTType: /* PMSTA-20883 - TEB - 150608 */
			case TimeStampType: snprintf(buf, taille, szFormatTimeStamp, _GET_TIMESTAMP(p, fld));  break;   /* PMSTA-14731 - 020812 - PMO */
            case TzOffsetType:  snprintf(buf, taille, "%d", _GET_TZOFFSET(p, fld));  break;   /* PMSTA-30818 - DLA - 180403 */
			case LongnameType:	DBA_SafeStrncpy(buf, taille, _GET_NAME(p, fld)); break;
            case String1000Type :DBA_SafeStrncpy(buf, taille, _GET_VARSTRING1000(p,fld)); break;/* DLA - PMSTA07121 - 090210 */
            case String2000Type :DBA_SafeStrncpy(buf, taille, _GET_VARSTRING2000(p,fld)); break;
            case String3000Type :DBA_SafeStrncpy(buf, taille, _GET_VARSTRING3000(p,fld)); break;
            case String4000Type :DBA_SafeStrncpy(buf, taille, _GET_VARSTRING4000(p,fld)); break;
            case String7000Type :DBA_SafeStrncpy(buf, taille, _GET_VARSTRING7000(p,fld)); break;
            case String15000Type:DBA_SafeStrncpy(buf, taille, _GET_VARSTRING15000(p,fld)); break;
            case UniString1000Type : /* DLA - PMSTA07121 - 090210 */
            case UniString2000Type :
            case UniString3000Type :
            case UniString4000Type :
            case UniString7000Type :
            case UniString15000Type:
            case UniCodeType :
            case UniInfoType :
            case UniLongnameType :
            case UniNameType :
            case UniNoteType :
            case UniPhoneType :
            case UniShortinfoType :
            case UniSysnameType :
            case UniTextType :
            case UniUrlType :   DBA_SafeStrncpy(buf, taille, DBA_GetVarStringASCII(p,fld)); break;
            case ArrayType : 	{
                                    int eltNbr = GET_ARRAY_ELTNBR(p, fld);
                                    int eltSz  = GET_ARRAY_ELTSZ(p,  fld);

                                    snprintf(buf, taille,  "ptr=0x" szFormatPointer ", eltNbr=%hd eltSz=%hd", GET_ARRAY_PTR(p, fld), eltNbr, eltSz);    /* PMSTA-17133 - 051113 - PMO */
                                }
                                break;
            case MultiArrayType :
                                sprintf (buf, "dim1= %d rec, dim2= %d rec",
                                         GET_MULTIARRAY_DIM1(p, fld),
                                         GET_MULTIARRAY_DIM2(p, fld));
                                break;
		}
    }
}




/************************************************************************
**
**  Function    :   DBA_DispFieldName()
**
**  Description :
**
**  Arguments   :
**
**  Last modif. :
**
**               REF9751-EFE-050120
**
*************************************************************************/
STATIC void DBA_DispFieldName(std::stringstream &bufStream, int fld, DBA_CFIELDDEF_STP   fieldStp, FLAG_T csvFlg)
{
    char fieldName[50];

    DBA_GetFieldName( fieldName, fieldStp) ;

    if (csvFlg == FALSE)
    {
        bufStream << "FIELD[" << std::setw(2) << std::right << std::setfill('0') << fld << "] \"" << std::setfill(' ') << std::setw(25) << std::left << fieldName << "\" (";
    }
    else
    {
        if (fieldStp->sqlName[0] == 0)
        {
            bufStream << "FIELD[" << fld << "] \",";
        }
        else
        {
            bufStream << "\"" << fieldName << "\",";
        }
    }
}




/************************************************************************
**
**  Function    :   DBA_DispFieldDataType()
**
**  Description :
**
**  Arguments   :
**
**  Last modif. :
**               REF9751-EFE-050120
**
*************************************************************************/
STATIC void DBA_DispFieldDataType(std::stringstream &bufStream, DBA_DYNFLD_STP p, FIELD_IDX_T fld, DBA_CFIELDDEF_STP   fieldStp, FLAG_T csvFlg)
{
    char fieldDataType[50];
    DBA_GetFieldDataType(fieldDataType, p, fld, fieldStp, csvFlg);

    if (csvFlg == FALSE)
    {
        bufStream << std::setw(20) << std::left << std::setfill(' ') << fieldDataType << " )" << " = ";
    }
    else
    {
        bufStream << fieldDataType << ",";
    }
}

/************************************************************************
**
**  Function    :   DBA_DispFieldValue()
**
**  Description :
**
**  Arguments   :
**
**  Last modif. :   REF11780 - 100406 - PMO : Implementation of the Sybase timestamp field
**                  PMSTA13244 - DDV - 120120 - Trace DynFld usage
**                  PMSTA-16124 - 250413 - PMO : Ensure coherence of printf / scanf formats with 32bits / 64 bits datatypes
**
*************************************************************************/
void DBA_DispFieldValue(std::stringstream &bufStream, DBA_DYNFLD_STP p, FIELD_IDX_T fld, std::string stringSurround)
{
    char tmpStr[255];

    /* < PMSTA-26791 - CHU - 170327 */
    int             res = 0;
    CURRENTCHARSETCODE_ENUM   CharSet = CurrentCharsetCode_IsNull;
    GEN_GetApplInfo(ApplCurrentCharsetCodeEnum, &CharSet);
    /* > PMSTA-26791 - CHU - 170327 */

    if (_IS_NULLFLD(p, fld) == TRUE)
	{
        bufStream << "NULL";
	}
    else
    {
		switch (GET_FLD_DTP(p, fld))
		{

            case NullDataType:	bufStream << " ??? "; break;
            case AmountType:	/* bufStream << _GET_AMOUNT(p, fld); break; */ /* PMSTA-31607 - CHU - 180605 : use length & precision definitions */
                bufStream << std::setw(LONGAMOUNT_T_LEN) << std::setprecision(LONGAMOUNT_T_DEC) << _GET_LONGAMOUNT(p, fld);
                break;
            case CodeType:	bufStream << stringSurround << _GET_CODE(p, fld) << stringSurround; break;
            case DateType:	{
					 YEAR_T y; MONTH_T m; DAY_T d;
                DATE_Get(_GET_DATE(p, fld), &y, &m, &d);
                sprintf(tmpStr, "%02d/%02d/%04d", d, m, y);
                bufStream << tmpStr;
					}
					break;
        	case DatetimeType:	{
                YEAR_T y; MONTH_T m; DAY_T d; HOUR_T h; MINUTE_T min; SECOND_T s; MICROSECOND_T ms;
					 DATETIME_T datetime;

                datetime = _GET_DATETIME(p, fld);

                DATE_Get(datetime.date, &y, &m, &d);
                TIME_Get(datetime.time, &h, &min, &s, &ms);
                sprintf(tmpStr, "%02d/%02d/%04d ", d, m, y);
                bufStream << tmpStr;
                sprintf(tmpStr, "%02d:%02d:%02d:%06d ", h, min, s, ms);  /* PMSTA-42593 - DPT - 210218 */
                bufStream << tmpStr;
					}
					break;
            case DictType:	bufStream << _GET_DICT(p, fld); break; /* DLA - PMSTA08801 - 100209 */
            case EnumType:	bufStream << (int)_GET_ENUM(p, fld); break;
            case ExchangeType: /* PMSTA-31607 - CHU - 180605 : use length & precision definitions */
                bufStream << std::setw(EXCHANGE_T_LEN) << std::setprecision(EXCHANGE_T_DEC) << _GET_EXCHANGE(p, fld) << std::setfill(' ');
                break;
            case ExtensionType:	{
                    /* REF10195 - LJE - 040413 : Add Ids */
                    int     dynStNbr, dynStPos = 0;
                    DBA_DYNFLD_STP  *dynStTab;

					dynStNbr = GET_EXTENSION_NBR(p, fld);
                    dynStTab = GET_EXTENSION_PTR(p, fld);

					if (GET_EXTENSION_TP(p, fld) == NullDynSt)
					{
                    sprintf(tmpStr, "dynStp=NullDynSt: nbr=%d", dynStNbr);
					}
					else
					{
                    sprintf(tmpStr, "dynStp=%s: nbr=%d",
							       DYN_V2N((DBA_DYNST_ENUM)GET_EXTENSION_TP(p, fld)),
			        		       dynStNbr);
					}
                bufStream << tmpStr;

                    if (dynStNbr > 0 && dynStTab[0][0].dataType == IdType)
                    {
                    bufStream << ": id(";

                        if (dynStNbr >= 1000)
                        {
                        bufStream << "Too Many:";
                        }

                    for (dynStPos = 0; dynStPos < dynStNbr && dynStPos < 1000; dynStPos++)
                        {
                        sprintf(tmpStr, "%" szFormatId":", _GET_ID(dynStTab[dynStPos], 0)); /* DLA - PMSTA08801 - 100209 */
                        bufStream << tmpStr;
                        }

                    bufStream << ")";
                    }

					}
					break;

            case FlagType:	bufStream << (int)_GET_FLAG(p, fld); break;
            case IdType: bufStream << _GET_ID(p, fld); break;
            case InfoType:	bufStream << stringSurround << _GET_INFO(p, fld) << stringSurround; break;
            case IntType:	bufStream << _GET_INT(p, fld); break;
            case LongamountType: /* bufStream << _GET_LONGAMOUNT(p, fld); break; */ /* PMSTA-31607 - CHU - 180605 : use length & precision definitions */
                bufStream << std::setw(LONGAMOUNT_T_LEN) << std::setprecision(LONGAMOUNT_T_DEC) << _GET_LONGAMOUNT(p, fld);
                break;
            case MaskType:
                {
                int i = (sizeof(MASK_T) * 8) - 1;

                bufStream << "(" << _GET_MASK(p, fld) << ")->";

                for (; i >= 0; i--)
                    {
                    if ((_GET_MASK(p, fld) >= pow(2., i)) || i == 0) /* PMO Change the first argument type */
                        {
                        bufStream << _GET_MASKBIT(p, fld, i);

                        if (i % 4 == 0)
                            {
                            bufStream << " ";
                            }
                        }
                    }
                    break;
                }
			case EnumMaskType:
                bufStream << _GET_MASK64(p, fld); break;
						break;
            case MethodType:	bufStream << (int)_GET_METHOD(p, fld); break;
            case NameType:	bufStream << stringSurround << _GET_NAME(p, fld) << stringSurround; break;
            case NoteType:	bufStream << stringSurround << std::setw(30) << std::left << _GET_INFO(p, fld) << stringSurround; break;
            case NumberType: /*	bufStream << _GET_NUMBER(p, fld); break; */ /* PMSTA-31607 - CHU - 180605 : use length & precision definitions */
                bufStream << std::setw(NUMBER_T_LEN) << std::setprecision(NUMBER_T_DEC) << _GET_NUMBER(p, fld);
                break;
            case PercentType:	/* bufStream << _GET_PERCENT(p, fld); break; */ /* PMSTA-31607 - CHU - 180605 : use length & precision definitions */
                bufStream << std::setw(PERCENT_T_LEN) << std::setprecision(PERCENT_T_DEC) << _GET_PERCENT(p, fld);
                break;
            case PeriodType:	bufStream << _GET_PERIOD(p, fld); break;
            case PhoneType:	bufStream << stringSurround << _GET_PHONE(p, fld) << stringSurround; break;
            case PriceType: /* PMSTA-41768 - JPR - 201006 */
                bufStream << std::setw(PRICE_T_LEN) << std::setprecision(PRICE_T_DEC) << std::setfill('0') << _GET_PRICE(p, fld) << std::setfill(' ');
                break;
            case ShortinfoType:	bufStream << stringSurround << _GET_SHORTINFO(p, fld) << stringSurround; break;
            case SmallintType:	bufStream << (int)_GET_SMALLINT(p, fld); break;
            case SysnameType:	bufStream << stringSurround << _GET_SYSNAME(p, fld) << stringSurround; break;
            case LongSysnameType:	bufStream << stringSurround << _GET_LONGSYSNAME(p, fld) << stringSurround; break; /* PMSTA-14086 - LJE - 121008 */
            case TextType:	bufStream << stringSurround << _GET_TEXT(p, fld) << stringSurround; break;
            case UrlType:	bufStream << stringSurround << _GET_URL(p, fld) << stringSurround; break;            /*  FIH-REF8832-030218  */
            case TimeType:	bufStream << "time !"; break;
            case TinyintType:	bufStream << (int)_GET_TINYINT(p, fld); break;
            case LongintType:	bufStream << _GET_LONGINT(p, fld); break;  /* PMSTA-20887 - LJE - 150909 */
            case YearType:	bufStream << "year !"; break;
            case LongnameType:	bufStream << stringSurround << _GET_NAME(p, fld) << stringSurround; break;
            case String1000Type:   bufStream << stringSurround << _GET_VARSTRING1000(p, fld) << stringSurround; break; /* DLA - PMSTA07121 - 090210 */
            case String2000Type:   bufStream << stringSurround << _GET_VARSTRING2000(p, fld) << stringSurround; break;
            case String3000Type:   bufStream << stringSurround << _GET_VARSTRING3000(p, fld) << stringSurround; break;
            case String4000Type:   bufStream << stringSurround << _GET_VARSTRING4000(p, fld) << stringSurround; break;
            case String7000Type:   bufStream << stringSurround << _GET_VARSTRING7000(p, fld) << stringSurround; break;
            case String15000Type:   bufStream << stringSurround << _GET_VARSTRING15000(p, fld) << stringSurround; break;
            case LongStringType:   bufStream << stringSurround << _GET_LONGSTRING(p, fld) << stringSurround; break;
            case TzOffsetType:     bufStream << _GET_TZOFFSET(p, fld); break;   /* PMSTA-30818 - DLA - 180403 */
            case UniString1000Type: /* DLA - PMSTA07121 - 090210 */
            case UniString2000Type:
            case UniString3000Type:
            case UniString4000Type:
            case UniString7000Type:
            case UniString15000Type:
            case UniCodeType:
            case UniInfoType:
            case UniLongnameType:
            case UniNameType:
            case UniNoteType:
            case UniPhoneType:
            case UniShortinfoType:
            case UniSysnameType:
            case UniTextType:
            case UniUrlType:
            {
                /* < PMSTA-26791 - CHU - 170327 */
                int   iSizeBuffer = 2 * u_strlen(GET_USTRING(p, fld)) + 1;
                char* uString = (char*)CALLOC(iSizeBuffer, sizeof(char));

                switch (CharSet)
                {
                    case CurrentCharsetCode_Iso_1:
                        res = ICU4AAA_ConvertToISO1(GET_USTRING(p, fld), -1, uString, iSizeBuffer, NULL);
                        break;

                    case CurrentCharsetCode_Iso_8:
                        res = ICU4AAA_ConvertToISO8(GET_USTRING(p, fld), -1, uString, iSizeBuffer, NULL);
                        break;

                    case CurrentCharsetCode_UTF8:
                        res = ICU4AAA_ConvertToUTF8(GET_USTRING(p, fld), -1, uString, iSizeBuffer, NULL);
                        break;

                    default:
                        res = ICU4AAA_ConvertToASCII(GET_USTRING(p, fld), -1, uString, iSizeBuffer, NULL);
                        break;

                }
                bufStream << stringSurround << uString << stringSurround;
                FREE(uString);
                /* > PMSTA-26791 - CHU - 170327 */
                break;
            }

			case TimeStampTType: /* PMSTA-20883 - TEB - 150608 */
            case TimeStampType:
                sprintf(tmpStr, szFormatTimeStamp, _GET_TIMESTAMP(p, fld));
                bufStream << tmpStr;
                break;  /* REF11780 - 100406 - PMO */
            case ArrayType: 	{
		        		int     eltNbr, eltSz;
		        		eltNbr = GET_ARRAY_ELTNBR(p, fld);
		        		eltSz = GET_ARRAY_ELTSZ(p, fld);

                sprintf(tmpStr, "ptr=0x" szFormatPointer ", eltNbr=%d eltSz=%d",            /* PMSTA-16124 - 250413 - PMO */
		                               GET_ARRAY_PTR(p, fld), eltNbr, eltSz);
                bufStream << tmpStr;
	                		}
                                        break;
            case MultiArrayType:
			                {
                sprintf(tmpStr, "dim1= %d rec, dim2= %d rec",
                        GET_MULTIARRAY_DIM1(p, fld),
                        GET_MULTIARRAY_DIM2(p, fld));
                bufStream << tmpStr;
					}
                                        break;
		}
    }
}

/************************************************************************
**
**  Function    :   DBA_NewDispDynStFH()
**
**  Description :   Display a dynamic structure in a file
**
**  Arguments   :   p	    dynamic structure pointer
**		            s       dynamic structure enum
**                  object  entity enum attached to the structure
**		            FILE*   logFile file Handle
**
**  Last modif. :   PMSTA-15184 - 151012 - PMO : Some warnings during TA build process
**
*************************************************************************/
void DBA_NewDispDynStFH(const DBA_DYNFLD_STP p, FILE* logFile, int csvLevel, const char *title, FLAG_T delFlg)    /* PMSTA-15184 - 151012 - PMO */
{
    FIELD_IDX_T          fld;
    OBJECT_ENUM         object;
    DBA_CFIELDDEF_STP   fieldStp;
    DBA_DYNST_ENUM      dynStEn;
    FLAG_T              allocFlg=FALSE;
    std::stringstream  	bufStream;

	if (p == NULL)
    {
        AAA_RPT0(_CRT_WARN, "The record pointer is NULL. No display possible. Sorry ...\n");
        return;
    }
    bufStream.clear();
    bufStream.str(std::string());

    if (p[0].dynStEnum == 0 &&
        p[0].dataType  == 0 &&
        p[0].index     == 0)
    {
        AAA_RPT0(_CRT_WARN, "The record was not correctly initialized. No display possible. Sorry ...\n");
        return;
    }

    dynStEn = p[0].dynStEnum;
    object = GET_OBJ_DYNST(p[0].dynStEnum);

    if (csvLevel > 0)
    {
        if (csvLevel == 1 || csvLevel == 4)
        {
        	if (logFile != NULL && csvLevel != 4)
        	{
        		fprintf(logFile, "$BEGIN$\n"); /* REF10195 - LJE - 040409 */
        	}

            bufStream.clear();
            bufStream.str(std::string());

            bufStream
                << "$OBJECT$," << (object >= 0 ? OBJ_V2N(object) : "NullEntity")
                << ",$DYNST$," << (dynStEn >= 0 ? DYN_V2N(dynStEn) : "NullDynSt") << " ";

            if (title != NULL)
            {
                bufStream << "{" << title << "}";
            }
            bufStream << std::endl;

		    if (logFile != NULL)
		    {
                fprintf(logFile, "%s", bufStream.str().c_str()); /* PMSTA02478-CHU-070613 */
		    }
            else
            {
                AAA_RPT0(_CRT_WARN, bufStream.str().c_str());
            }

            /* reset for next line */
            bufStream.clear();
            bufStream.str(std::string());

            bufStream << "HierInfo,";

	        for (fld=0 ; (fieldStp = DBA_GetCFieldDef(dynStEn, fld, &allocFlg)) != NULL ; fld++)
	        {
                DBA_DispFieldDataType(bufStream, p, fld, fieldStp, TRUE);

                if (allocFlg==TRUE)
                    FREE(fieldStp);
            }

            bufStream << std::endl;
		    if (logFile != NULL)
		    {
                fprintf(logFile, "%s", bufStream.str().c_str()); /* PMSTA02478-CHU-070613 */
		    }
            else
            {
                AAA_RPT0(_CRT_WARN, bufStream.str().c_str());
            }

            /* reset for next line */
            bufStream.clear();
            bufStream.str(std::string());

            bufStream << "deleted,";
	        for (fld=0 ; (fieldStp = DBA_GetCFieldDef(dynStEn, fld, &allocFlg)) != NULL ; fld++)
	        {
                DBA_DispFieldName(bufStream, fld, fieldStp, TRUE);

                if (allocFlg==TRUE)
                    FREE(fieldStp);
            }

            bufStream << std::endl;
		    if (logFile != NULL)
		    {
                fprintf(logFile, "%s", bufStream.str().c_str()); /* PMSTA02478-CHU-070613 */
		    }
            else
            {
                AAA_RPT0(_CRT_WARN, bufStream.str().c_str());
            }

        }

        /* reset for next line */
        bufStream.clear();
        bufStream.str(std::string());

        bufStream << (int)delFlg;
	    for (fld=0 ; (fieldStp = DBA_GetCFieldDef(dynStEn, fld, &allocFlg)) != NULL ; fld++)
	    {
            bufStream << ",";
            DBA_DispFieldValue(bufStream, p, fld);

            if (allocFlg==TRUE)
                FREE(fieldStp);
        }

        bufStream << std::endl;
		if (logFile != NULL)
		{
            fprintf(logFile, "%s", bufStream.str().c_str()); /* PMSTA02478-CHU-070613 */
		}
        else
        {
            AAA_RPT0(_CRT_WARN, bufStream.str().c_str());
        }

        /* REF10195 - LJE - 040409 */
        if (csvLevel == 3 && logFile != NULL)
        {
            fprintf(logFile, "$END$\n");
        }
    }
    else
    {
        /* reset for next line */
        bufStream.clear();
        bufStream.str(std::string());

        bufStream
            << "Object : " << (object >= 0 ? OBJ_V2N(object) : "NullEntity")
            << " \t dynSt : " << (dynStEn >= 0 ? DYN_V2N(dynStEn) : "NullDynSt") << " \n";

		if (logFile != NULL)
		{
            fprintf(logFile, "%s", bufStream.str().c_str()); /* PMSTA02478-CHU-070613 */
		}
        else
        {
            AAA_RPT0(_CRT_WARN, bufStream.str().c_str());
        }


	    for (fld=0 ; (fieldStp = DBA_GetCFieldDef(dynStEn, fld, &allocFlg)) != NULL; fld++)
	    {
            /* reset for next line */
            bufStream.clear();
            bufStream.str(std::string());

            DBA_DispFieldName(bufStream, fld, fieldStp, FALSE);

            DBA_DispFieldDataType(bufStream, p, fld, fieldStp, FALSE);

            DBA_DispFieldValue(bufStream, p, fld);

            bufStream << std::endl;

		    if (logFile != NULL)
		    {
                fprintf(logFile, "%s", bufStream.str().c_str()); /* PMSTA02478-CHU-070613 */
		    }
            else
            {
                AAA_RPT0(_CRT_WARN, bufStream.str().c_str());
            }

            if (allocFlg==TRUE)
                FREE(fieldStp);
	    }
    }

    /* LJE - 031117 */
    if (logFile != NULL)
    {
        fflush(logFile);
    }
}

/************************************************************************
**
**  Function    :   DBA_DynStToString()
**
**  Description :   Display a dynamic structure in String
**
**  Arguments   :   p	    dynamic structure pointer
**
** return       : std::string
**
**  Last modif. :
**
*************************************************************************/
std::string DBA_DynStToString(DBA_DYNFLD_STP p)
{
    FIELD_IDX_T          fld;
    OBJECT_ENUM         object;
    DBA_CFIELDDEF_STP   fieldStp;
    DBA_DYNST_ENUM      dynStEn;
    FLAG_T              allocFlg = FALSE;
    std::stringstream  	bufStream;

    if (p == NULL)
    {
        AAA_RPT0(_CRT_WARN, "The record pointer is NULL. No display possible. Sorry ...\n");
        return NULL;
    }
    bufStream.clear();
    bufStream.str(std::string());

    if (p[0].dynStEnum == 0 &&
        p[0].dataType == 0 &&
        p[0].index == 0)
    {
        AAA_RPT0(_CRT_WARN, "The record was not correctly initialized. No display possible. Sorry ...\n");
        return NULL;
    }

    dynStEn = p[0].dynStEnum;
    object = GET_OBJ_DYNST(p[0].dynStEnum);

    bufStream
        << "Object : " << (object >= 0 ? OBJ_V2N(object) : "NullEntity")
        << " \t dynSt : " << (dynStEn >= 0 ? DYN_V2N(dynStEn) : "NullDynSt") << " \n";

    for (fld = 0; (fieldStp = DBA_GetCFieldDef(dynStEn, fld, &allocFlg)) != NULL; fld++)
    {
        DBA_DispFieldName(bufStream, fld, fieldStp, FALSE);

        DBA_DispFieldDataType(bufStream, p, fld, fieldStp, FALSE);

        DBA_DispFieldValue(bufStream, p, fld);

        bufStream << std::endl;

        if (allocFlg == TRUE)
            FREE(fieldStp);
    }

    return bufStream.str();
}

/************************************************************************
**
**  Function    :   DISP()
**
**  Description :   Display a dynamic structure
**                  This function is used for debugging
**
**  Arguments   :
**
*************************************************************************/
void DISP(const void *p)
{
    DBA_NewDispDynStFH((DBA_DYNFLD_STP)p, NULL, FALSE, NULL, FALSE);
}

/************************************************************************
**
**  Function    :   LOG()
**
**  Description :   Display a dynamic structure
**                  This function is used for debugging
**
**  Arguments   :
**
*************************************************************************/
void LOG(const void *p)
{
    DBA_NewDispDynStFH((DBA_DYNFLD_STP)p, SV_msgFile, FALSE, NULL, FALSE);
}

/************************************************************************
**
**  Function    :   DISP_TAB
**
**  Description :   Display a "all" dynamic structure
**                  This function is used for debugging
**
**  Arguments   :
**
*************************************************************************/
void DISP_TAB(const void** p, const int from, const int till)
{
    int i;
    for (i=from; i<=till; i++)
    {
        DBA_NewDispDynStFH(((DBA_DYNFLD_STP*)p)[i], NULL, FALSE, NULL, FALSE);
    }
}

/************************************************************************
**
**  Function    :   DISP_TAB_CSV()
**
**  Description :   Display a dynamic structure
**                  This function is used for debugging
**
**  Arguments   : appendCsv = true to append to generic csv. note that file
**                          can only be open in notepad++. File open excel 
**                          or other programs will block updates
**
*************************************************************************/
void DISP_TAB_CSV(const DBA_DYNFLD_STP *p, const int from, const int till, bool appendCsv)
{
    int     i;
	FILE*	logFile=NULL;
    char    filename[256];
    YEAR_T y; MONTH_T m; DAY_T d; HOUR_T h;MINUTE_T min;SECOND_T s;
    DATETIME_T datetime;
    
    if(appendCsv == false)
    {
        DATE_CurrentDateTime(&datetime);

        DATE_Get(datetime.date,&y,&m,&d);
        TIME_Get(datetime.time,&h,&min,&s);

            sprintf(filename,
                    "%s%s%s_%04d%02d%02d%02d%02d%02d.csv",
                    GEN_GetPath(MsgDir),
			        FILE_SEPARATOR, /* PMSTA-12966 - LJE - 120322 */
                    DYN_V2N(p[from][0].dynStEnum),
                    y,
                    m,
                    d,
                    h,
                    min,
                    s);
    }
    else
    {
        sprintf(filename,
                "%s%s%s.csv",
                GEN_GetPath(MsgDir),
			    FILE_SEPARATOR,
                DYN_V2N(p[from][0].dynStEnum));
    }

    logFile = fopen(filename, "a+");

    AAA_RPT1(_CRT_WARN, "%s\n", filename); /* REF9586 - LJE - 031029 */

    for (i=from; i<=till; i++)
    {
        DBA_NewDispDynStFH(p[i], logFile, i==from?1:(i==till?3:2), NULL, FALSE); /* REF10195 - LJE - 040409 */
    }

	if (logFile != NULL)
	{
	    fclose(logFile);
	}

}

/************************************************************************
**
**  Function    :   DISP_TAB_CSV()
**
**  Description :   Display a dynamic structure
**                  This function is used for debugging
**
**  Arguments   :
**
*************************************************************************/
void DISP_TAB_CSV(const std::vector<DBA_DYNFLD_STP> &p)
{
    FILE*	logFile = NULL;
    char    filename[256];
    YEAR_T y; MONTH_T m; DAY_T d; HOUR_T h; MINUTE_T min; SECOND_T s;
    DATETIME_T datetime;

    DATE_CurrentDateTime(&datetime);

    DATE_Get(datetime.date, &y, &m, &d);
    TIME_Get(datetime.time, &h, &min, &s);

    sprintf(filename,
            "%s%s%s_%04d%02d%02d%02d%02d%02d.csv",
            GEN_GetPath(MsgDir),
            FILE_SEPARATOR, /* PMSTA-12966 - LJE - 120322 */
            DYN_V2N(p[0][0].dynStEnum),
            y,
            m,
            d,
            h,
            min,
            s);

    logFile = fopen(filename, "a+");

    AAA_RPT1(_CRT_WARN, "%s\n", filename); /* REF9586 - LJE - 031029 */

    size_t i = 0;
    for (auto it = p.begin(); it != p.end(); ++it, i++)
    {
        DBA_NewDispDynStFH((*it), logFile, it == p.begin() ? 1 : (i == p.size() ? 3 : 2), NULL, FALSE);
    }

    if (logFile != NULL)
    {
        fclose(logFile);
    }

}

/************************************************************************
**
**  Function    :   DISP_TAB()
**
**  Description :   Display an array of dynamic structures
**                  This function is used for debugging, on Immediate Window
**
**  Arguments   :
**
*************************************************************************/
void DISP_TAB(DBA_DYNFLD_STP *p, int from, int till)
{
    for (int index = from; index < till; index++)
    {
        DISP(p[index]);
    }
}

/************************************************************************
**
**  Function    :   DISP_CSV()
**
**  Description :   Display a dynamic structure
**                  This function is used for debugging
**
**  Arguments   :
**
*************************************************************************/
void DISP_CSV(const DBA_DYNFLD_STP p)
{
    DISP_TAB_CSV(&p, 0, 1);
}

#ifdef AAADEBUGMSG
/************************************************************************
**
**  Function    :   DUMP_HIER()
**
**  Description :   Dump a hierarchy
**                  This function is used for debugging
**
**  Arguments   :
**
*************************************************************************/
void DUMP_HIER(DBA_HIER_HEAD_STP hierHead)
{
    DBA_HierDump(hierHead, NullDynSt, FALSE, NULL);
}

/************************************************************************
**
**  Function    :   DUMP_HIER_DEL()
**
**  Description :   Dump a hierarchy
**                  This function is used for debugging
**
**  Arguments   :
**
*************************************************************************/
void DUMP_HIER_DEL(DBA_HIER_HEAD_STP hierHead)
{
    DBA_HierDump(hierHead, NullDynSt, TRUE, NULL);
}

/************************************************************************
**
**  Function    :   DUMP_HIER()
**
**  Description :   Dump a hierarchy
**                  This function is used for debugging
**
**  Arguments   :
**
*************************************************************************/
void DUMP_HIER_DYNST(DBA_HIER_HEAD_STP hierHead, DBA_DYNST_ENUM dynStEnum)
{
    DBA_HierDump(hierHead, dynStEnum, FALSE, NULL);
}

/************************************************************************
**
**  Function    :   DUMP_TAB_CSV()
**
**  Description :   Display a dynamic structure table in generic CSV file
**                  The file is created on first call and close with NULL in
**                  dynamic structure pointer
**                  This function is used for debugging
**
**  Arguments   :   p       : Pointer of dynamic struture table
**                  from    : the first element
**                  till    : the last element
**
**  Created     :   REF9586 - LJE - 031029
**
*************************************************************************/
void DUMP_TAB_CSV(DBA_DYNFLD_STP *p, int from, int till)
{
    int           i;
	static FILE*  logFile=NULL;
    char          filename[256];


    if (logFile==NULL)
    {
        YEAR_T y; MONTH_T m; DAY_T d; HOUR_T h;MINUTE_T min;SECOND_T s;
        DATETIME_T datetime;

        DATE_CurrentDateTime(&datetime);

        DATE_Get(datetime.date,&y,&m,&d);
        TIME_Get(datetime.time,&h,&min,&s);

        sprintf(filename,
                "%s%sdump_dyn_%04d%02d%02d%02d%02d%02d.csv",
                GEN_GetPath(MsgDir),
				FILE_SEPARATOR,
                y,
                m,
                d,
                h,
                min,
                s);

        logFile = fopen(filename, "a+");

        AAA_RPT1(_CRT_WARN, "%s\n", filename);

    }
    else if (p == NULL && from == -1)
    {
        fclose(logFile);
        logFile=NULL;
        return;
    }

    if (till >= from)
    {
        for (i=from; i<=till; i++)
        {
            DBA_NewDispDynStFH(p[i], logFile, i==from?1:(i==till?3:2), NULL, FALSE);
        }
    }
    else
    {
        fprintf(logFile, "$BEGIN$\n");
        fprintf(logFile, "Empty block\n");
	    fprintf(logFile, "$END$\n");
    }

    return;
}

/************************************************************************
**
**  Function    :   DUMP_CSV()
**
**  Description :   Display a dynamic structure in generic CSV file
**                  The file is created on first call and close with NULL in
**                  dynamic structure pointer
**                  This function is used for debugging
**
**  Arguments   :   p       : Pointer of dynamic struture
**
**  Created     :   REF9586 - LJE - 031029
**
*************************************************************************/
void DUMP_CSV(DBA_DYNFLD_STP p)
{
    DUMP_TAB_CSV(&p, 0, 1);
}

/************************************************************************
**
**  Function    :   DUMP_MULTI_CSV()
**
**  Description :   Display a dynamic structure table in generic CSV file
**                  The file is created on first call and close with NULL in
**                  dynamic structure pointer
**                  This function is used for debugging
**
**  Arguments   :   data
**                  rows
**                  blockNbr
**
**  Created     :   REF9586 - LJE - 031029
**
*************************************************************************/
void DUMP_MULTI_CSV(DBA_DYNFLD_STP **data, int *rows, int blockNbr)
{
    int i;

    for (i=0; i<blockNbr; i++)
    {
        DUMP_TAB_CSV(data[i], 0, rows[i]-1);
    }
}

/************************************************************************
**
**  Function    :   CLOSE_DUMP_CSV()
**
**  Description :   Close dump csv file
**                  This function is used for debugging
**
**  Arguments   :
**
**  Created     :   REF9586 - LJE - 031029
**
*************************************************************************/
void CLOSE_DUMP_CSV()
{
    DUMP_TAB_CSV(NULL, -1, -1);
}

/************************************************************************
**
**  Function    :   DISP_MULTI_CSV()
**
**  Description :   Display a dynamic structure table in generic CSV file
**                  The file is created on first call and close with NULL in
**                  dynamic structure pointer
**                  This function is used for debugging
**
**  Arguments   :   data
**                  rows
**                  blockNbr
**
**  Created     :   REF9586 - LJE - 031029
**
*************************************************************************/
void DISP_MULTI_CSV(DBA_DYNFLD_STP **data, int *rows, int blockNbr)
{
    DUMP_MULTI_CSV(data, rows, blockNbr);
    CLOSE_DUMP_CSV();
}
#endif

/************************************************************************
**
**  Function    :   FIELD()
**
**  Description :   Display a field of dynamic structure
**                  This function is used for debugging
**
**  Arguments   :
**
*************************************************************************/
const char *FIELD(DBA_DYNFLD_STP p, FIELD_IDX_T fld)
{
    static char *buf;

    if (buf == NULL)
    {
        /* WARNING TextType could now be 65535 long! */
        if ((buf = (char*)CALLOC(70000, sizeof(char))) == NULL)
        {
            AAA_RPT0(_CRT_WARN, "Memory alloc error. No display possible. Sorry ...\n");
            return (NULL);
        }
    }

    buf[0] = 0;

    std::stringstream bufStream;

    if (p == NULL)
    {
        bufStream << "NULL pointer";
    }
    else
    {
        DBA_DispFieldValue(bufStream, p, fld);
    }

    strcpy(buf, bufStream.str().c_str());

    return buf;
}

const char * P(DBA_DYNFLD_STP p, FIELD_IDX_T fld)
{
    return FIELD(p, fld);
}

/************************************************************************
**
**  Function    :   DBA_DispDynStStr()
**
**  Description :   Display a dynamic structure
**
**  Arguments   :   p	        dynamic structure pointer
**		            enStr       dynamic structure enum
**                  objectStr   entity enum attached to the structure
**
*************************************************************************/
void DBA_DispDynStStr(DBA_DYNFLD_STP p, char* enStr, char* objectStr)
{
    DBA_DispDynStStrF(p, enStr, objectStr, NULL);
}

/************************************************************************
**
**  Function    :   N2V()
**
**  Description :   Display the enum value for a given name OBJECT_ENUM or DYNST_ENUM
**                  This function is used for debugging
**
**  Arguments   :   char        *enStr pointer on name
**
*************************************************************************/
int N2V(char* enStr)
{
    DBA_DYNST_ENUM i;

    i = DBA_GetDynStByCName(enStr);

    if (i>0)
        return((int) i);

    return ((int) DBA_GetObjectByCName(enStr));
}

/************************************************************************
**
**  Function    :   DYN_V2N()
**
**  Description :   Display the name for a value of DYNST_ENUM
**                  This function is used for debugging
**
**  Arguments   :   int value  value to translate
**
*************************************************************************/
const char *DYN_V2N(DBA_DYNST_ENUM value) /* DLA - REF8728 */
{
    return (DBA_GetDynStCName(value));
}

/************************************************************************
**
**  Function    :   OBJ_V2N()
**
**  Description :   Display the name for a value of OBJECT_ENUM
**                  This function is used for debugging
**
**  Arguments   :   int value  value to translate
**
*************************************************************************/
const char *OBJ_V2N(OBJECT_ENUM value) /* DLA - REF8728 */
{
    return (DBA_GetObjectCName(value));
}

/************************************************************************
**
**  Function    :   DBA_DispDynStStrF()
**
**  Description :   Display a dynamic structure in a file
**
**  Arguments   :   p	        dynamic structure pointer
**		            enStr       dynamic structure enum
**                  objectStr   entity enum attached to the structure
**  Last modif. : REF7264 - 011212 - PMO : Compilation errors and warnings with C++ compiler
**             	: REF11860 - 060808 - BSA : Compilation warnings with C++ compiler
**
*************************************************************************/
void DBA_DispDynStStrF(DBA_DYNFLD_STP p, const char* enStr, const char* objectStr, char* filename)
{
    DBA_DYNST_ENUM en = NullDynSt;
    OBJECT_ENUM object = NullEntity;

    en = DBA_GetDynStByCName(enStr);

    object = DBA_GetObjectByCName(objectStr);


    DBA_DispDynStF(p, en, object, filename);
}


/************************************************************************
**
**  Function    :   DBA_DispDynStToString()
**
**  Description :   Store the display a dynamic structure into dispOutput
**
**  Arguments   :   p	        dynamic structure pointer
**		            dispOutput  Where to store the output
**                  indentSize  # of space indent
**
**  Created     :   PMSTA-24985 - 111016 - PMO : Connection crash
**
**  Last modif. :
**
*************************************************************************/
void DBA_DispDynStToString(DBA_DYNFLD_STP p, std::string & dispOutput, const int indentSize)
{
    if (nullptr != p                                                    &&
        !(p[0].dynStEnum == 0 && p[0].dataType == 0 && p[0].index == 0))
    {
        DBA_CFIELDDEF_STP   fieldStp;
        DBA_DYNST_ENUM      dynStEn     = p[0].dynStEnum;
        FLAG_T              allocFlg    = FALSE;

	    for (FIELD_IDX_T fld=0 ; (fieldStp = DBA_GetCFieldDef(dynStEn, fld, &allocFlg)) != nullptr; fld++)
	    {
            std::stringstream bufStream;

            DBA_DispFieldName(bufStream, fld, fieldStp, FALSE);

            DBA_DispFieldDataType(bufStream, p, fld, fieldStp, FALSE);

            DBA_DispFieldValue(bufStream, p, fld);

            for (int idx = 0 ; idx < indentSize; idx++)
            {
                dispOutput += " ";
            }

            dispOutput += bufStream.str();
            dispOutput += "\n";

            if (allocFlg==TRUE)
            {
                FREE(fieldStp);
            }
	    }
    }
}

#ifdef NT
#pragma warning(default:4127)
#endif
/* #endif REF4111 - SSO - 991220 comment */

/************************************************************************
**
**  Function    :   DBA_FldToStr()
**
**  Description :   Convert a field to a string.
**                  If destination pointer is egal to UNUSED, function
**                  allocate space for destination string.
**                  !!  Call function must deallocate memory. !!
**
**  Arguments   :   dest	destination string pointer, or UNUSED
**                              if function must allocate space.
**          t	dynamic structure definition (DBA_DYNST_ENUM)
**                  dynStPtr	dynamic structure pointer (DBA_DYNFLD_STP)
**                  fld		field number
**                  editFlag    edition flag
**
**  Return      :   destination string pointer, NULL if error.
**
**                  REF9770 - LJE - 040126
**
*************************************************************************/
char *DBA_FldToStr( char            *dest,
                    DBA_DYNST_ENUM  dynSt,
		            DBA_DYNFLD_STP  dynStPtr,
                    int             fld,
                    char            editFlag)
{
	DATATYPE_ENUM dataType;
	CONVFMT_ENUM  format;
    int           strLen;


    /*  particular case: not metadictionary structure   */  /*  HFI-PMSTA-28501-170914  */
    if (dynSt == InvalidDynSt)
        dataType = (DATATYPE_ENUM) dynStPtr[fld].dataType;
    else
    	dataType = GET_FLD_TYPE(dynSt,fld);
	format   = (editFlag==0)? GET_DFLTCONVFMT(dataType):
				GET_DFLTCONVEDITFMT(dataType);

    strLen   = GET_CONV_MAXLEN(format)+1;

	/* allocate space if dest is NULL */
	if (dest == NULL)
		if ((dest = (char *) CALLOC((strLen),
					     sizeof(char))) == NULL)
			return(NULL);

	if (_IS_NULLFLD(dynStPtr, fld)== TRUE)  /* PMSTA13244 - DDV - 120120 - Trace DynFld usage */
	{
		switch(dataType)
		{
		case DateType:
		case DatetimeType:
             CONV_DataToStr(dest,
                            strLen,
					        dataType,
		                    GET_CONV_MASK(format),
					        NULL,
                            FALSE,
                            TextConversion_None);
			 break;
		default:
			 *dest=END_OF_STRING;
		}
	}
	else
         CONV_DataToStr(dest,
                        strLen,
				        dataType,
		                GET_CONV_MASK(format),
		                GET_FLDPTR_BY_DTP(dataType, dynStPtr, fld),
                        FALSE,
                        TextConversion_None);

	return(dest);
}

/************************************************************************
**
**  Function    :   DBA_FreeDynSt()
**
**  Description :   Deallocate a dynamic structure
**
**  Arguments   :   p	source string pointer
**		    s	dynamic structure definition (DBA_DYNST_ENUM)
**
**  Return      :   none
**
**  Modif       :   ROI - 980323 - REF1367
**  Modif       :   RAK - 981104 - REF1036
**                  REF8844 - LJE - 030408 : Add newIndex
**
*************************************************************************/
void DBA_FreeDynSt(DBA_DYNFLD_STP p, DBA_DYNST_ENUM s)
{
    if (p == NULL || s == NullDynSt)
        return;


#ifdef AAATRACEDYNFLD
    DICT_TestDynSt(p, s);
#endif

    /* PMSTA13244 - DDV - 120120 - Trace DynFld usage */
    if (s == A_Domain)
    {
        DBA_ReflectDomainUsage(p);
    }

    s = p[0].dynStEnum;
    for (int M_i = 0; M_i < GET_FLD_NBR(s); M_i++)
    {
        if (IS_STRINGFLD(s, M_i) == TRUE)
        {
            /* DLA - PMSTA00222 - 060831 */
            FREE_STRFLD(p[M_i]);
        }
        else if (IS_USTRINGFLD(s, M_i) == TRUE)
        {
            /* DLA - PMSTA00222 - 060831 */
            FREE_USTRFLD(p[M_i]);
        }
        else if (IS_ARRAYFLD(s, M_i) == TRUE)
        {
            FREE(GET_ARRAY_PTR(p, M_i));
        }
        else if (IS_MULTIARRAYFLD(s, M_i) == TRUE)
        {
            if (GET_MULTIARRAY_PTR(p, M_i) != NULL)
            {
                FREE(GET_MULTIARRAY_NOTNULLTAB(p, M_i));
                FREE(GET_MULTIARRAY_DATATAB(p, M_i));
                FREE(GET_MULTIARRAY_PTR(p, M_i));
            }
        }
        else if (IS_EXTFLD(s, M_i) == TRUE)
        {
            FREE_EXTENSION(p, M_i);
        }
    }

    /* REF6956 - DDV - 020104 - Remove all records created for this record in autocreate stack */
    SCPT_AUTOCREATE_ST searchKey;   /* REF6956 - DDV - 020104 */
    memset(&searchKey, 0, sizeof(SCPT_AUTOCREATE_ST));
    searchKey.mainRec = p;
    SCPT_FreeAutocreateElts(&searchKey);

}

/************************************************************************
**
**  Function    :   DBA_FreeDynStSupplFld()
**
**  Description :   Deallocate content of dynamic structure with supplementary fields
**
**  Arguments   :   p		source string pointer
**		            fldNbr	fields number
**
**  Return      :   none
**
**  Creation	:   REF3729 - RAK - 990603
**
**  Last Modif. :  GRD - 000204 - REF4204.
**  Last Modif. :  HFI-PMSTA-41297-200804   Management of one allocation containing several dyn structure (mainly GUI copy/paste)
**
*************************************************************************/
void DBA_FreeDynStSupplFld(DBA_DYNFLD_STP pTofree, int fldNbr)
{
    FIELD_IDX_T     M_i, iField;
    CTYPE_ENUM	    ctp;
    DBA_DYNFLD_STP  p = pTofree;

    if (p == NULL || fldNbr == 0)
        return;

    for (iField = 0, M_i = 0; iField < fldNbr; iField++, M_i++)
    {
        /*  In case of a big allocation containing several complete dynamic structure (ExtOp for GUI copy/paste)    */      /*  HFI-PMSTA-41297-200804  */
        /*  The variable M_i must remain below the size of the complete dynamic structure                           */
        /*  Else the management of field like extension, array ... field will be wrong                              */
        /*  because the value accessed by GET_INFO_FLD in FREE_EXTENSION ... is not the rigth one                   */
        if (pTofree[iField].index == 0)
        {
            M_i = 0;
            p = &pTofree[iField];
        }

	    ctp = GET_CTYPE(GET_FLD_DTP(p, M_i));

	    if (ctp == CharPtrCType || ctp == TextPtrCType)
        {
            /* DLA - PMSTA00222 - 060831 */
            FREE_STRFLD(p[M_i]);
        }
	    else if (ctp == UniCharPtrCType || ctp == UniTextPtrCType)
        {
            /* DLA - PMSTA00222 - 060831 */
            FREE_USTRFLD(p[M_i]);
        }
        else if (ctp == ArrayPtrCType)
        {
            FREE(GET_ARRAY_PTR(p, M_i)); /* test of NULL pointer */
        }
        else if (ctp == MultiArrayPtrCType)
        {
            if (GET_MULTIARRAY_PTR(p, M_i) != NULL)
            {
                FREE(GET_MULTIARRAY_NOTNULLTAB(p, M_i));
                FREE(GET_MULTIARRAY_DATATAB(p, M_i));
                FREE(GET_MULTIARRAY_PTR(p, M_i));
            }
        }
	    else if (ctp == ExtPtrCType)	/* REF1036 - RAK - 981104 */
	    {
            if (GET_EXTENSION_PTR(p, M_i) != NULL)
            {
                FREE_EXTENSION(p, M_i);
            }
	    }
    }
}


/************************************************************************
**
**  Function    :   DBA_SetNullDynSt()
**
**  Description :   Set to null a dynamic structure
**
**  Arguments   :   p	source string pointer
**		            s	dynamic structure definition (DBA_DYNST_ENUM)
**
**  Return      :   none
**
**
*************************************************************************/
void DBA_SetNullDynSt(DBA_DYNFLD_STP p, DBA_DYNST_ENUM s)
{
    int M_i;
    SCPT_AUTOCREATE_ST searchKey;

    for (M_i=0; M_i<(int)GET_FLD_NBR(s); M_i++)
    {
        if (IS_STRINGFLD(s,M_i)==TRUE)
        {
            FREE_STRFLD(p[M_i]);
        }
        else if (IS_USTRINGFLD(s,M_i)==TRUE)
        {
            FREE_USTRFLD(p[M_i]);
        }
        p[M_i].flgMask = (unsigned char) 0;
        p[M_i].data.datetime64St.reset();
    }

    memset(&searchKey, 0, sizeof(SCPT_AUTOCREATE_ST));
    searchKey.mainRec = p;
    SCPT_FreeAutocreateElts(&searchKey);
}

/************************************************************************
**
**  Function    :   DBA_StrCmp()
**
**  Description :   Compare string in dynfld
**
**  Arguments   :   ptr1    first element pointer
**		    fld1    first element field
**                  prt2    second element pointer
**		    fld2    second element field
**
**  Return      :   strcmp() return
**
**  Creation	:   RAK - BUG268 - 970129
**
*************************************************************************/
int DBA_StrCmp(DBA_DYNFLD_STP ptr1, int fld1, DBA_DYNFLD_STP ptr2, int fld2)
{
	int ret;

	if (IS_NULLFLD(ptr1, fld1) == TRUE)
	{
	    if (IS_NULLFLD(ptr2, fld2) == TRUE)		/* Both are NULL */
		    ret = 0;
	    else						/* First is NULL */
		    ret = -1;
	}
	else
	{
	     if (IS_NULLFLD(ptr2, fld2) == TRUE)	/* Second is NULL */
		    ret = 1;
	     else 					/* String compare */
		    ret =  strcmp(GET_STRING(ptr1, fld1), GET_STRING(ptr2, fld2));
	}
	return(ret);
}

/************************************************************************
**
**  Function    :   DBA_StrToData()
**
**  Description :   Convert a string to a field.
**
**  Arguments   :   src		    source string pointer.
**		            dynSt	    dynamic structure definition (DBA_DYNST_ENUM)
**                  dynStPtr	dynamic structure pointer (DBA_DYNFLD_STP)
**                  fld		    field number
**
**  Return      :   nothing
**
*************************************************************************/
int DBA_StrToData(const char    *src,
		          DBA_DYNFLD_STP dynStPtr,
                  int            fld)
{
	CONVFMT_ENUM  format;
	double	      buf=0.;
	PTR           data;

    DATATYPE_ENUM dataType = GET_FLD_DTP(dynStPtr, fld);

	/***** STRING MANAGEMENT *****/
	if (IS_STRING_TYPE(dataType) == TRUE)
	{
		/***** CHECK VALIDITY *****/

		/***** UPDATE DATA *****/
		SET_STRING(dynStPtr,fld,src);
	}
    else if (IS_USTRING_TYPE(dataType) == TRUE)
    {
        int iStrInLen = 0;
        if (src != nullptr)
        {
            iStrInLen = SYS_StrLen(src);
        }
        if (iStrInLen > 0)
        {
            UChar*  uStr = (UChar*)CALLOC(iStrInLen + 1, sizeof(UChar));
            if (uStr != nullptr)
            {
                ICU4AAA_ConvertFromDefaultCharSet(src, -1, uStr, iStrInLen, NULL);
                SET_USTRING(dynStPtr, fld, uStr);
                FREE(uStr);
            }
        }
    }
    else
    {
		data = (PTR)&buf;

		format = GET_DFLTCONVFMT(dataType);

		/***** CHECK VALIDITY FOR PROPOSED CONVERTION *****/
		if (CONV_StrToData(src, dataType,
				   GET_CONV_MASK(format), data, FALSE) == NULL)		/* ROI - 010225 - REF5635 */
		{
			/***** KEEP OLD DATA *****/
			return(FALSE);
		}
		else
		{
			/***** UPDATE DATA *****/
			if (dataType==DateType ||
		            dataType==DatetimeType)
			{
				if ( (*(DATE_T *) data) == BAD_DATE)
				{
					SET_NOTNULLFLG_F(dynStPtr, fld);
				}
				else
				{
					SET_NOTNULLFLG_T(dynStPtr, fld);
				}
			}
			else
			{
				if (src[0] == END_OF_STRING)
				{
					SET_NOTNULLFLG_F(dynStPtr, fld);
				}
				else
				{
					SET_NOTNULLFLG_T(dynStPtr, fld);
				}
			}
			memcpy(&dynStPtr[fld].data, (PTR)data, 8);
		}
	}

	return(TRUE);
}


/************************************************************************
**
**  Function    :   DBA_GetVarStringASCII()
**
**  Description :
**
**  Arguments   :
**
**
**
**
**  Return      :
**
**  Last modif. :   PMSTA-12583 - 190811 - PMO : Array bounds write in ICU4AAA_ConvertStdEndProcessing
**
*************************************************************************/
char *DBA_GetVarStringASCII(DBA_DYNFLD_STP dynSt, int fld)
{
    static const char *SV_stringNA="n/a";
    char *stringASCII=NULL;
    int asciiFldPos;

    SET_GETFLG_T(dynSt, fld); /* PMSTA13244 - DDV - 120120 - Trace DynFld usage */

    if (GET_CTYPE(dynSt[fld].dataType) == UniCharPtrCType ||
        GET_CTYPE(dynSt[fld].dataType) == UniTextPtrCType )
    {
        const int maxlen = GET_MAXLEN(dynSt[fld].dataType) + 1;     /* PMSTA-12583 - 190811 - PMO */
        if (GET_DYNSTENUM(dynSt) > InvalidDynSt)
        {
            stringASCII = (char*)CALLOC(maxlen, sizeof(char));

            ICU4AAA_ConvertToASCII(GET_USTRING(dynSt, fld), -1, stringASCII, maxlen, NULL);

            asciiFldPos=GET_ASCII_FLD(dynSt, fld);
            if (asciiFldPos > 0 && asciiFldPos != fld)  /* DLA - PMSTA-25031 - 161123 */
            {
                SET_STRING(dynSt, asciiFldPos, stringASCII);

                FREE(stringASCII);

                stringASCII = GET_STRING(dynSt, asciiFldPos);
            }
            else
            {
                FREE(stringASCII);
                stringASCII = SV_ErrConvertToASCII; /* DLA - PMSTA-25031 - 161123 */
                SYS_BreakOnDebug(); /* PMSTA-28633 - DDV - 170929 */
            }
        }
        else
        {
            stringASCII = (char*)SV_stringNA;
        }
    }
    else if (GET_CTYPE(dynSt[fld].dataType) == CharPtrCType ||
             GET_CTYPE(dynSt[fld].dataType) == TextPtrCType )
    {
        stringASCII = GET_STRING(dynSt, fld);

    }
    else
    {
#ifdef AAATRACEDYNFLD
        DICT_TestDynfld(dynSt,fld,VarStringType);
#endif
    }

    return (stringASCII);

}

/************************************************************************
**
**  Function    :   DBA_SetVarStringASCII()
**
**  Description :
**
**  Arguments   :
**
**
**
**
**  Return      :
**
*************************************************************************/
void DBA_SetVarStringASCII(DBA_DYNFLD_STP dynSt, int fld, const char *string)
{
    if (GET_CTYPE(dynSt[fld].dataType) == UniCharPtrCType ||
        GET_CTYPE(dynSt[fld].dataType) == UniTextPtrCType )
    {
        UChar *uniString=NULL;

        uniString = (UChar*)CALLOC(GET_MAXLEN(dynSt[fld].dataType), sizeof(UChar));
		/* <DLA - PMSTA-13053 - 111101 */
		if(ICU4AAA_SQLServerUTF8 == TRUE)
			if ( strstr(string, "&#x") != NULL )
				ICU4AAA_ConvertFromHTML(string, -1, uniString, GET_MAXLEN(dynSt[fld].dataType), NULL);
			else
				ICU4AAA_ConvertFromUTF8(string, -1, uniString, GET_MAXLEN(dynSt[fld].dataType), NULL);
		else
	        ICU4AAA_ConvertFromASCII(string, -1, uniString, GET_MAXLEN(dynSt[fld].dataType), NULL);
		/* DLA - PMSTA-13053 - 111101 > */
        SET_USTRING(dynSt, fld, uniString);

        FREE(uniString);
    }
    else if (GET_CTYPE(dynSt[fld].dataType) == CharPtrCType ||
             GET_CTYPE(dynSt[fld].dataType) == TextPtrCType )
    {
        SET_STRING(dynSt, fld, string);
    }
    else
    {
#ifdef AAATRACEDYNFLD
        DICT_TestDynfld(dynSt,fld,VarStringType);
#endif
    }

}


/************************************************************************
**
**  Function    :   DBA_SetVarStringXML()
**
**  Description :   Transform an XML string into a UNICODE string
**
**  Arguments   :   DBA_DYNFLD_STP  dynSt   : dynamic structure
**                  int             fld     : field to modify
**                  char*           string  : original XML string
**
**
**  Creation    :   HFI-PMSTA-12258-110621
**
**  Return      :   None
**
*************************************************************************/
void DBA_SetVarStringXML(DBA_DYNFLD_STP dynSt, int fld, const char *string)
{
    if (GET_CTYPE(dynSt[fld].dataType) == UniCharPtrCType ||
        GET_CTYPE(dynSt[fld].dataType) == UniTextPtrCType )
    {
        UChar *uniString=NULL;

        uniString = (UChar*)CALLOC(GET_MAXLEN(dynSt[fld].dataType), sizeof(UChar));

        ICU4AAA_ConvertFromHTML(string, -1, uniString, GET_MAXLEN(dynSt[fld].dataType), NULL);

        SET_USTRING(dynSt, fld, uniString);

        FREE(uniString);
    }
    else if (GET_CTYPE(dynSt[fld].dataType) == CharPtrCType ||
             GET_CTYPE(dynSt[fld].dataType) == TextPtrCType )
    {
        SET_STRING(dynSt, fld, string);
    }
    else
    {
#ifdef AAATRACEDYNFLD
        DICT_TestDynfld(dynSt,fld,VarStringType);
#endif
    }

}

std::string DBA_DYNFLD::disp()
{
    return DBA_DynStToString(this);
}

/* PMSTA-45413 - LJE - 210802 */
OBJECT_ENUM     DBA_DYNFLD::getObjectEn() const
{
    return GET_OBJ_DYNST(this->getDynStEn());
}

int             DBA_DYNFLD::getObjectCst() const
{
    return GET_OBJECT_CST(this->getObjectEn());
}

DBA_DYNTYPE_ENUM DBA_DYNFLD::getDynTypeEn() const
{
    return GET_DYNST_TYPE(this->getDynStEn());
}

DICT_ENTITY_STP DBA_DYNFLD::getDictEntityStp() const
{
    return DBA_GetDictEntityStSafe(this->getObjectEn());
}

FIELD_IDX_T DBA_DYNFLD::getIdIdx() const
{
    return this->getDictEntityStp()->getIdIdx(this->getDynTypeEn());
}

bool DBA_DYNFLD::isAllDynSt() const
{
    return (GET_DYNST_TYPE(this->getDynStEn()) == DynType_All);
}

bool DBA_DYNFLD::isShortDynSt() const
{
    return (GET_DYNST_TYPE(this->getDynStEn()) == DynType_Short);
}

DICT_ATTRIB_STP DBA_DYNFLD::getDictAttribStp() const
{
    DICT_ENTITY_STP dictEntityStp = this->getDictEntityStp();

    if (dictEntityStp != nullptr)
    {
        switch (this->getDynTypeEn())
        {
            case DynType_All:
            {
                auto criteriabIt = dictEntityStp->allDictCriteriaMap.find(this->index);
                if (criteriabIt != dictEntityStp->allDictCriteriaMap.end())
                {
                    return criteriabIt->second->attrPtr;
                }
                if (dictEntityStp->attr.empty() == false)
                {
                    for (auto& dictAttribStp : dictEntityStp->attr)
                    {
                        if (dictAttribStp->progN == this->index)
                        {
                            return dictAttribStp;
                        }
                    }
                }
                break;
            }

            case DynType_Short:
            {
                auto criteriabIt = dictEntityStp->shortDictCriteriaMap.find(this->index);
                if (criteriabIt != dictEntityStp->shortDictCriteriaMap.end())
                {
                    return criteriabIt->second->attrPtr;
                }
                if (dictEntityStp->attr.empty() == false)
                {
                    for (auto& dictAttribStp : dictEntityStp->attr)
                    {
                        if (dictAttribStp->isNullShortIdx == false &&
                            dictAttribStp->shortIdx == this->index)
                        {
                            return dictAttribStp;
                        }
                    }
                }
                break;
            }

            default:
                return nullptr;
        }
    }

    return nullptr;
}

/************************************************************************
**
**  Function    :   DBA_SetFldToDefaultCharSet()
**
**  Description :   Convert a string Field into a default character set type string
**
**  Arguments   :   DBA_DYNFLD_STP  dynSt   : dynamic structure
**                  int             fld     : field to modify
**
**  Creation    :   PMSTA-27969 - CMILOS - 290817
**
**  Return      :   The converted field or SV_ErrConversionToDefault
**
*************************************************************************/
char *DBA_SetFldToDefaultCharSet(DBA_DYNFLD_STP dynSt, int fld)
{
	static const char *SV_stringNA = "n/a";
	char *stringDefault = NULL;
	int asciiFldPos;

	if (GET_DYNSTENUM(dynSt) > InvalidDynSt)
	{
		if (GET_CTYPE(dynSt[fld].dataType) == UniCharPtrCType ||
			GET_CTYPE(dynSt[fld].dataType) == UniTextPtrCType)
		{
			char *ptr = NULL;
			asciiFldPos = GET_ASCII_FLD(dynSt, fld);
			if (asciiFldPos > 0 && asciiFldPos != fld)
			{
				ICU4AAA_ConvertToDefaultCharSet(GET_USTRING(dynSt, fld), -1, &ptr, NULL);
				SET_STRING(dynSt, asciiFldPos, ptr);
				FREE(ptr);
				stringDefault = GET_STRING(dynSt, asciiFldPos);
			}
            else
                SYS_BreakOnDebug(); /* PMSTA-28633 - DDV - 170929 */
		}
		else if (GET_CTYPE(dynSt[fld].dataType) == CharPtrCType ||
			GET_CTYPE(dynSt[fld].dataType) == TextPtrCType)
		{
			stringDefault = GET_STRING(dynSt, fld);
		}
		else
		{
#ifdef AAATRACEDYNFLD
			DICT_TestDynfld(dynSt, fld, VarStringType);
#endif
		}

	}
	else
	{
		stringDefault = (char*)SV_stringNA;
	}

	return stringDefault;

}


/************************************************************************
**      END          dynlib.c
*************************************************************************/


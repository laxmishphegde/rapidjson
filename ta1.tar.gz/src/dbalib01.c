/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/**************************************************************************
*        Local Functions
*
* DBA_AddTableTruncate              : Add a sql command for truncate or delete a table
* DBA_CheckConnectNbCoherence       : Check if a given connection number is valid or not.
* DBA_ConvertCTypeDataToFld         : Convert a data and store it in a DBA_DYNFLD_ST structure in the right format.
* DBA_CreateOneTempTable            : Create one temporary table
* DBA_CreateTempTables              : Create temporary tables
* DBA_EndConnection                 : Set the connection state to Free, cancel all pending results and free allocated arrays.
* DBA_FilterMsgInfos                : Filter the messages stack associated to a connection after a call to a server.
* DBA_FreeNullFlagsAndLength        : Free null Flags array and field length array associated to a connection.
* DBA_GetAsyncConnection            : Search an available async. connection for a server and connection mode.
* DBA_GetConnServerType             : Return the connection server type (FinServer or SqlServer).
* DBA_GetConnStructPtr              : Return a pointer on a DBA_CONNECT_INFO_ST.
* DBA_GetConnection                 : Search for an available connection for a server type and connection mode and return a number.
* DBA_GetConnectionSt               : Retrieve the CONNECTION structure of a connection.
* DBA_GetMaxAvailConn               : Return the max available connections to SQL Server and Financial Server.
* DBA_InitConnect                   : Open 1 connection whith the SQL Server and another with the Open Server.
* DBA_ReinitDeadConn                : Reinitialize one connection after an unexpected disconnection from an OS or SQL Server.
* DBA_ReviveAllDeadConn             : Revive one or many connections after an unexpected disconnection from an OS or SQL Server.
* DBA_SetAsyncInfos                 : Save many informations at the connection level before beginning asynchronous.
* DBA_SetConnBindSt                 : Save bind structure pointer and dynamic struct format for a specified connection.
* DBA_SetConnMaxRows                : Save maximum returned rows for a request associated to a connection.
* DBA_SetNullFlagsAndLength         : Save null Flags array and field length array in the connection list.
* DBA_SetRequestStateAndStatus      : Save current async fct called and the status (should be PENDING) in connection.
* DBA_UpdTableModifStat             : Given an object, modify Modif_stat. DVP306.
* DBA_GimmeNetRunning               : Retrieve running processes corresponding to the given string from sybase. DVP404.
* DBA_CheckPasswdHistory            : Check if the new password was used before REF4170
* DBA_InsertPasswdHistory           : Insert the new password in appl_password_history REF4170
*****************************************************************************/

/************************************************************************
**      Include files
*************************************************************************/
#define	STDIO_H
#define STRING_H
#define STDLIB_H
#include "unidef.h"     /* Mandatory */
#include "gen.h"
#include "dba.h"


#ifndef MSG_H
#include "msg.h"
#endif

#include "conv.h"
#include "crypt.h"
#include "date.h"
#include "ddlgentable.h"    /* ORACLE - LJE - 141016 */
#include "ddlgenindex.h"    /* ORACLE - LJE - 141016 */
#include "json.h"
#include "conprovider.h"    /* DLA - PMSTA-20062 - 150311 */
#include "dbiconnection.h"
#include "conlocprovider.h"
#include "httpclient.h"
#include "cstypes.h"

#include    <fcntl.h>
#include <sys/stat.h>

#include <assert.h>         /* DLA - REF9303 - 030825 */
#include <conexcept.h>


#ifdef UNIX
#include   <unistd.h>
#else
#include        <io.h>
#endif


#include <QDateTime>
#include <map>

using namespace std;

/************************************************************************
**      External definitions & data
*************************************************************************/
extern FLAG_T SV_IsSubdApplFlg;	  /* REF4204 - 000414 - GRD */
extern int EV_AAAInstallLevel;
extern unsigned int EV_RunSysKitInstall;
extern CODE_T EV_DbTimeZoneCd;    /* PMSTA-43454 - DDV - 210128 */
extern bool EV_EnableMicrosecTime;


/************************************************************************
**      Static definitions & data
*************************************************************************/

//static DBA_CONNECT_INFO_STP   SV_ConnectionList = NULL; /* array of connection structure */

static int            SV_TotalAvailConn = 0;
static int            SV_NmbConOpenSrv = 0;
FLAG_T		          SV_ActiveConFlg = FALSE;

static  long          SV_DiffDbSysDateDate=MAGIC_END_DATE;   /* REF4521 - RAK - 000412 */
static  long          SV_DiffDbSysDateTime=0;                /* REF4521 - RAK - 000412 */

static bool SV_TempTableAvaible = false;
static vector<map<string, string>> SV_TempTableCreateVector; /* PMSTA-18593 - LJE - 150520 */
static vector < map<string, string>> SV_TempTableDeleteVector; /* PMSTA-18593 - LJE - 150520 */
static vector < map<string, string>> SV_TempTableTruncateVector; /* PMSTA-18593 - LJE - 150520 */

static vector<AAAConnectionPoolConfiguration> SV_ConnectionPoolConfig;

DBA_RDBMS_ENUM EV_RdbmsVendor           = Sybase;

/* PMSTA-37374 - LJE - 210409 */
DBA_RDBMS_ENUM      EV_SourceRdbmsVendor = Sybase;
std::string         EV_SourceDataSource;
std::string         EV_SourceApplOwner;
PasswordEncrypted   EV_SourceEncryptedPassword;
DdlGenContext      *EV_SourceContext = nullptr;
DdlGenCfgFile      *EV_SourceCfgFile = nullptr;

DBA_RDBMS_ENUM      EV_TargetRdbmsVendor = Sybase;
std::string         EV_TargetDataSource;
std::string         EV_TargetApplOwner;
PasswordEncrypted   EV_TargetEncryptedPassword;
DdlGenContext      *EV_TargetContext = nullptr;
DdlGenCfgFile      *EV_TargetCfgFile = nullptr;

bool                EV_UseAlternativeDataSource = false;

/* REF1784 - 980420 - GRD */
#define CHECK_CONNECTCOHERENCY(c) ((c < 0)?FALSE:TRUE)

static unsigned SV_AllTempTablesTab[] = {
      DOM_OPER
    , DOM_POSITION_INSTR_PORT
    , OBJ_ID
    , DOM_STRAT
    , TMP_OPER
    , DOM_THIRD_CURR
    , DOM_LISTCOMPO
    , GRID_VECTOR
    , STRAT_MARKET
    , DOM_PARENT_STRAT
    , TMP_STRAT_HIST
    , STRATEGY
    , BUILD_LIST /* PMSTA-24012 - DDV - 160902 */
    , TCT_VECTOR_ID
    , TCT_DOM_PORT_FUS
    , TCT_FUS_TAB
    , DOM_PSP
    , IN_OBJECT
    , ARCHIVE_DELOP_LISTOPENOPER
    , SUBD_DOM_OPE
    , EXT_OP_LIST
    , PORT_SYNTH
    , SCRIPT_DEF /* PMSTA-18601 - DDV - 141021 */
    , WORK_HIER_LIST
    , WORK_BLOCK_OP
    , TT_TAXLOT_PROCESS /* PMSTA-34973 - 040319 - SGO */
    , TT_FORMAT         /* PMSTA-38117 - 090320 - KNI */
    , TT_HC_PTF_LIST    /* PMSTA-39010 - 070520 - JJN */
	, TT_BUS_UNIT       /* PMSTA - 46366 - SRIDHARA - 13102021 */
    , TT_LIST_STRAT_LINK /* PMSTA-46575 - 211214 - DDV */
    , ALL_TEMP_TABLES
};

/************************************************************************
*   Function             : DBA_GetTimeStamp()
*
*   Description          : Return the timestamp field of a dynamic structure
*
*   Arguments            : dynStp   Dynamic structure
*                          fldIdx   Index of the field
*
*   Return               : the timestamp value
*
*   Creation Date        : REF11780 - 100406 - PMO : Implementation of the Sybase timestamp field
*
*   Last Modif           :
*
*************************************************************************/
TIMESTAMP_T DBA_GetTimeStamp(const DBA_DYNFLD_STP dynStp, const int fldIdx)
{
    return dynStp[fldIdx].data.timeStampValue;
}


/************************************************************************
*   Function             : DBA_SetTimeStamp()
*
*   Description          : Set the timestamp field of a dynamic structure
*
*   Arguments            : dynStp       Dynamic structure
*                          fldIdx       Index of the field
*                          timeStamp    Value of the timestamp
*
*   Return               : None
*
*   Creation Date        : REF11780 - 100406 - PMO : Implementation of the Sybase timestamp field
*
*   Last Modif           :
*
*************************************************************************/
void DBA_SetTimeStamp(DBA_DYNFLD_STP dynStp, const int fldIdx, const TIMESTAMP_T timeStamp)
{
    dynStp[fldIdx].data.timeStampValue = timeStamp;
    SET_NOTNULLFLG_T(dynStp, fldIdx);
}


/************************************************************************
*   Function             : DBA_SetNullTimeStamp()
*
*   Description          : Set the timestamp field of a dynamic structure to NULL
*
*   Arguments            : dynStp   Dynamic structure
*                          fldIdx   Index of the field
*
*   Return               : None
*
*   Creation Date        : REF11780 - 100406 - PMO : Implementation of the Sybase timestamp field
*
*   Last Modif           :
*
*************************************************************************/
void DBA_SetNullTimeStamp(DBA_DYNFLD_STP dynStp, const int fldIdx)
{
    dynStp[fldIdx].data.timeStampValue = 0L;
    SET_NOTNULLFLG_F(dynStp, fldIdx);
}


/************************************************************************
*   Function             : DBA_GetBinary()
*
*   Description          : Return the binary field of a dynamic structure
*
*   Arguments            : dynStp   Dynamic structure
*                          fldIdx   Index of the field
*
*   Return               : the binary value
*
*   Creation Date        : DLA - PMSTA05995 - 080410
*
*   Last Modif           :
*
*************************************************************************/
BINARY_T DBA_GetBinary(const DBA_DYNFLD_STP dynStp, const int fldIdx)
{
    return dynStp[fldIdx].data.binaryValue;
}


/************************************************************************
*   Function             : DBA_SetBinary()
*
*   Description          : Set the Binary field of a dynamic structure
*
*   Arguments            : dynStp       Dynamic structure
*                          fldIdx       Index of the field
*                          Binary       Value of the Binary
*
*   Return               : None
*
*   Creation Date        : DLA - PMSTA05995 - 080410
*
*   Last Modif           :
*
*************************************************************************/
void DBA_SetBinary(DBA_DYNFLD_STP dynStp, const int fldIdx, const BINARY_T binary)
{
    dynStp[fldIdx].data.binaryValue = binary;
    SET_NOTNULLFLG_T(dynStp, fldIdx);
}


/************************************************************************
*   Function             : DBA_SetNullBinary()
*
*   Description          : Set the Binary field of a dynamic structure to NULL
*
*   Arguments            : dynStp   Dynamic structure
*                          fldIdx   Index of the field
*
*   Return               : None
*
*   Creation Date        : DLA - PMSTA05995 - 080410
*
*   Last Modif           :
*
*************************************************************************/
void DBA_SetNullBinary(DBA_DYNFLD_STP dynStp, const int fldIdx)
{
    dynStp[fldIdx].data.binaryValue = 0L;
    SET_NOTNULLFLG_F(dynStp, fldIdx);
}

/************************************************************************
*   Function             : DBA_CopyNullFlagsAndLengthDynFld()
*
*   Description          : For one field, copy the null flag and string
*                          length informations in the bind structure.
*
*   Arguments            :
*                          bindData  : the structure array used for binding
*                          dynStEnum : the dynamic structure enum
*
*   Functions call       : None
*
*   Global var. modified : None
*
*   Return               :
*
*   Creation date        : PMSTA08801 - DDV - 091209
*   Last Modif. Date     :
*
*************************************************************************/
void DBA_CopyNullFlagsAndLengthDynFld(DBA_DYNFLD_STP bindData, DBA_DYNST_ENUM dynStEnum, INT_T fieldIdx, short nullFlag, int fieldLength)
{
    if (nullFlag != -1)
    {
        SET_NOTNULLFLG_T(bindData, fieldIdx);
    }
    else
    {
        SET_NOTNULLFLG_F(bindData, fieldIdx);
    }
}

/************************************************************************
*   Function             : DBA_GetMaxAvailConn()
*
*   Description          : Return the max available connections to SQL Server
*                          and Financial Server
*
*   Arguments            : None
*
*   Return               : the max available connections
*
*   Creation Date        : 07.12.95 - PEC
*   Last Modif           :
*************************************************************************/
int DBA_GetMaxAvailConn()
{
    return(SV_TotalAvailConn);
}

/************************************************************************
*   Function             : DBA_InitConnect()
*
*   Description          : Open 1 connection whith the SQL Server and
*                          another with the Open Server and initialize
*                          the list of available asynchronous and synchronous connections
*
*                          Following is a description of the connections to initialize:
*
*                          maxSqlSyncConn     : reserved for sybase. (stored procedures, usually 2 times the number of clients).
*                          maxFinSyncConn     : reserved for connecting financial servers. (Remote Procedure Calls).
*                          maxSqlAsyncConn    : not used. (asynchronous mode only).
*                          maxFinAsyncConn    : not used. (asynchronous mode only).
*                          maxFixFinSyncConn  : reserved for fixed connections to open-servers. Each should never be closed.
*                                               Allow connected servers to detect a client crash or stop.
*
*   Arguments            : None
*
*   Global var. modified : None
*
*   Return               : RET_SUCCEED                 : if ok
*                          RET_DBA_ERR_CANNOTCONNECT   : if connection failed
*                          RET_GEN_ERR_NOACTION        : if action is impossible
*                          RET_DBA_ERR_NOAVAILCONNINDB : no available connections
*                          RET_MEM_ERR_ALLOC           : if memory allocation failed
*
*   Creation Date        : June  94 - PEC
*   Last Modif           : 25.08.95 - PEC
*                          23.05.96 - PEC - Ref.: DVP066.
*                          11.06.96 - PEC - Ref.: DVP137.
*                          17.10.96 - PEC - Ref.: BUG186.
*                          01.11.96 - PEC - Ref.: DVP237.
*                          12.11.98 - GRD - Ref.: REF3016.
*                          24.11.98 - GRD - Ref.: REF3063. Allocate enough connections for fusion servers. (dispatch mode).
*                           FIH - 990416 - REF2236
*                          27.09.99 - GRD - Ref.: REF3847.
*                          02.05.00 - GRD - Ref.: REF4520.
*                          02.05.00 - GRD - Ref.: REF1698. Take care of using the correct database for the primary conn.
*                          REF7264 - 0201225 - PMO : Compilation errors and warnings with C++ compiler
*                          PMSTA-18094 - 130514 - PMO : Avoid extracting the user credentials from the GUI running on Windows (via dump, etc.)
*                          PMSTA-21907 - 281215 - PMO : cleanup PoolException
*
*************************************************************************/
RET_CODE DBA_InitConnect(void)
{
	/* DLA-PMSTA18583-141105 convert the ASYNC connections in ORACLE connections */
	int                  maxSqlSyncConn    = 0,
						 maxFinSyncConn    = 0,
						 maxFixFinSyncConn = 0,
						 maxSqlSourceConn  = 0,
						 maxFinAsyncConn   = 0,
						 totalAvailConn    = 0;
	int                  nmbServers        = 0;
	FLAG_T               servDispFlg       = FALSE;
	FLAG_T               servFusFlg        = FALSE;
	DbiConnection *		 dbiConn           = nullptr;

	SV_TotalAvailConn = 1;			  /* DLA - PMSTA-11512 - 110321 */

        try
        {
            dbiConn = DBA_GetDbiConnection(SqlServer, ROLE_INIT);
        }
        catch (AAAPoolUsageException& e)
        {
            MSG_SendExceptionMesg(FILEINFO, e.getCallStack(), e.what());                       /* PMSTA-21907 - 281215 - PMO */
        }

        if (dbiConn == nullptr)
        {
            return RET_GEN_ERR_NOACTION;
        }

        RET_CODE ret;
        ID_T     userId = ZERO_ID;
        GEN_GetUserInfo(UserId, &userId);

        dbiConn->setReadOnly(true);

        ret = DBA_LoadApplParam(*dbiConn, userId);
        if (ret == RET_GEN_ERR_WRONG_VERSION)
        {
            return ret;
        }

		/*
		* TEMPORARY : If we are initializing an Open Server,
		* No connection is yet established with another Open Server.
		*/

        GEN_SetApplInfo(ApplFixFinSync, &nmbServers);				/* REF3063 */

        if (SERVER_MODE())
        {
            if (!SYS_IsUnitTest())
            {
                if ((ret = DBI_SetServerConnectApplInfo(*dbiConn, &nmbServers, &servDispFlg, &servFusFlg)) != RET_SUCCEED)
                {
                    return ret;
                }
            }
        }

        /* Retrieve the max. available connections for each connection type */
		if (GEN_GetApplInfo(ApplSqlSync, &maxSqlSyncConn) != TRUE ||
			GEN_GetApplInfo(ApplFinSync, &maxFinSyncConn) != TRUE ||
			GEN_GetApplInfo(ApplSqlAsync, &maxSqlSourceConn) != TRUE || /* DLA - Remove the Async connection and replace with source RDBMS*/
			GEN_GetApplInfo(ApplFinAsync, &maxFinAsyncConn) != TRUE ||
			GEN_GetApplInfo(ApplFixFinSync, &maxFixFinSyncConn) != TRUE)			/* REF3063 */
		{
			return(RET_GEN_ERR_NOACTION);
		}

		/*
		* If the client is importation we need one more financial synchronous connection.
		* Because it will have to connect to the dispatch server for synchronization.
		* GRD - 1998.11.13 - REF3016.
		*/

		if(EV_AAAInstallLevel > 5 && maxSqlSyncConn == 0)
		{
			maxSqlSyncConn = 5;
			if (GEN_SetApplInfo(ApplSqlSync, &maxSqlSyncConn) != TRUE)
			{
				return(RET_GEN_ERR_NOACTION);
			}
		}

		if (SYS_IsBatchMode() == TRUE)
		{
			maxFixFinSyncConn += 1;

			if (GEN_SetApplInfo(ApplFixFinSync, &maxFixFinSyncConn) != TRUE)
			{
				return(RET_GEN_ERR_NOACTION);
			}
		}

		/*
		* If this process is a server we need two more financial synchronous connection
		* else one is enough
		* PCL - 2002.05.07 - REF4333.3.
		* PCL - 2002.06.36 - REF4333.5.
		*/

		if (SYS_IsSrvMode() == TRUE)
			maxFixFinSyncConn += 2;
		else
			maxFixFinSyncConn += 1;


		if (GEN_SetApplInfo(ApplFixFinSync, &maxFixFinSyncConn) != TRUE)
		{
			return(RET_GEN_ERR_NOACTION);
		}

		/*
		* If this process is a dispatcher, we need to allocate space for its permanent connections
		* to all the fusion servers it is going to manage.
		* GRD - 1998.11.30 - REF3063.
		*/

		if (servDispFlg == 1)
		{
			maxFixFinSyncConn += nmbServers;

			if (GEN_SetApplInfo(ApplFixFinSync, &maxFixFinSyncConn) != TRUE)
			{
				return(RET_GEN_ERR_NOACTION);
			}
		}

		/*
		* If this process is a fusion server, we need to allocate space for its permanent connections
		* the the dispatch server.
		* GRD - 1999.12.11 - REF3063.
		*/

		if (servFusFlg == 1)
		{
			maxFixFinSyncConn += 1;

			if (GEN_SetApplInfo(ApplFixFinSync, &maxFixFinSyncConn) != TRUE)
			{
				return(RET_GEN_ERR_NOACTION);
			}
		}

		/*
		* Total number of connections to initialize.
		*/

		/* PMSTA1570 - DDV - 070207 - Add 20% more connection as a default connection is always used for each RPC */
		totalAvailConn = (int)(1.2 * maxSqlSyncConn + maxFinSyncConn + maxSqlSourceConn + maxFinAsyncConn + maxFixFinSyncConn);

		/* Allocate internal (application specific) connections structures */
		if (totalAvailConn == 0)
		{
			MSG_DispMsgText(RET_DBA_ERR_NOAVAILCONNINDB,
				"Connections number to financial and data servers is 0."
				" See configuration table \"appl_param\"");                 /*  FIH-REF8683-030708  Add retCode */

			return(RET_DBA_ERR_NOAVAILCONNINDB);
		}

		/* Memorize the total of available connections */
		SV_TotalAvailConn = totalAvailConn;

        DBA_EndConnection(&dbiConn);

	return(RET_SUCCEED);
}


/************************************************************************
*   Function             : DBA_EndConnection()
*
*   Description          : Set the connection state to Free, cancel
*                          all pending results for the command and free
*                          allocated arrays.
*
*   Arguments            : connectNo : the connection number in the list
*
*   Functions call       : SYB_CtCancel
*                          DBA_SetConnMaxRows
*
*   Global var. modified : SV_ConnectionList
*
*   Return               : RET_SUCCEED        : if ok
*                          RET_GEN_ERR_INVARG : if argument problem
*
*   Creation Date        : PMSTA1570 - 070207 - DDV - Treat default connection
*   Last Modif           :
*
*************************************************************************/
RET_CODE DBA_EndConnection(int connectNo)
{
	DbiConnection* dbiConn = DBA_GetDbiConnFromConnectNo(connectNo);
    RET_CODE ret = RET_SUCCEED;

	if (dbiConn == nullptr)
    {
		ret = RET_DBA_ERR_CONNOTFOUND;
	}
	else
    {
        if (dbiConn->statmentAllocatedNb > 0)
        {
            /* !!!! a DBI_ReleaseCommand(*dbiConn) is missing */
            SYS_BreakOnDebug();
        }

		ret = DBA_EndConnection(&dbiConn);
	}
	return(ret);
}

/************************************************************************
*   Function             : DBA_EndConnection()
*
*   Description          : Set the connection state to Free, cancel
*                          all pending results for the command and free
*                          allocated arrays.
*
*   Arguments            : dbiConnection : the connection object
*
*   Functions call       : SYB_CtCancel
*                          DBA_SetConnMaxRows
*
*   Global var. modified : SV_ConnectionList
*
*   Return               : RET_SUCCEED        : if ok
*                          RET_GEN_ERR_INVARG : if argument problem
*
*   Creation Date        : PMSTA1570 - 070207 - DDV - Treat default connection
*
*   Last Modif           : PMSTA-21907 - 281215 - PMO : cleanup PoolException
*
*************************************************************************/
RET_CODE DBA_EndConnection(DbiConnection** dbiConnInOut, bool isInError)
{
	if (dbiConnInOut == nullptr)
    {
		return RET_DBA_ERR_ARGNOMATCH;
	}

	if (*dbiConnInOut == nullptr)
	{
		return RET_DBA_ERR_CONNOTFOUND;
	}

	DbiConnection* dbiConn    = *dbiConnInOut;

    dbiConn->endConnection(isInError);

	*dbiConnInOut = nullptr;

	return(RET_SUCCEED);
}

/************************************************************************
*   Function             : DBA_SetConnMaxRows()
*
*   Description          : Save maximum returned rows for a request
*                          associated to a connection.
*
*   Arguments            : DbiConnection : the connection object
*                          maxRows       : the maximum rows to return
*
*   Functions call       : SYB_SetMaxRowcount
*
*   Global var. modified : SV_ConnectionList
*
*   Return               : RET_SUCCEED          : if ok
*                          RET_GEN_ERR_INVARG   : if an argument is invalid
*                          RET_GEN_ERR_NOACTION : if action impossible
*
*   Creation Date        : Juil. 94 - PEC
*   Last Modif           : 25.08.95 - PEC
*                          21.04.98 - GRD - REF1784.
*
*************************************************************************/
RET_CODE DBA_SetConnMaxRows(DbiConnection &dbiConn, int maxRows)
{
	if (dbiConn.getDescription().getType() == FinServer ||
        dbiConn.getDescription().getType() == DispatchServer) /* PMSTA-24563 - LJE - 160908 */
	{
		return(RET_GEN_ERR_NOACTION);
	}

	if (maxRows != dbiConn.getConnStructPtr()->maxRows)
	{
		if (dbiConn.setConnMaxRows(maxRows) != RET_SUCCEED) /* DLA - PMSTA-26898 - 170426 */
		{
			return(RET_GEN_ERR_NOACTION);
		}
		dbiConn.getConnStructPtr()->maxRows = maxRows;
	}
	return(RET_SUCCEED);
}

/************************************************************************
*   Function             : DBA_SetConnBindSt()
*
*   Description          : Save bind structure pointer and dynamic struct
*                          format for a specified connection in the conn.
*                          structure.
*
*   Arguments            : DbiConnection : the connection object
*                          stFmt         : the struct format
*                          bindStEn        : the struct pointer
*
*   Functions call       : none
*
*   Global var. modified : SV_ConnectionList
*
*   Return               : RET_SUCCEED        : if ok
*                          RET_GEN_ERR_INVARG : if an argument is invalid
*
*   Creation Date        : Juil. 94 - PEC
*   Last Modif           : 25.08.95 - PEC
*                          21.04.98 - GRD - REF1784.
*************************************************************************/
RET_CODE DBA_SetConnBindSt(DbiConnection * dbiConn, DBA_DYNST_ENUM stFmt, DBA_DYNFLD_STP bindSt)
{
    dbiConn->m_bindDynStEn = stFmt;
    dbiConn->m_bindDynStp  = bindSt;

	return(RET_SUCCEED);
}

/************************************************************************
*   Function             : DBA_SetNullFlagsAndLength()
*
*   Description          : Save null Flags array and field length array in
*                          the connection list
*
*   Arguments            : DbiConnection  : the connection object
*                          flagsPtr       : the null flags array pointer
*                          fieldLengthPtr : the field length array pointer
*
*   Functions call       : none
*
*   Global var. modified : SV_ConnectionList
*
*   Return               : RET_SUCCEED        : if ok
*                          RET_GEN_ERR_INVARG : if an argument is invalid
*
*   Creation Date        : Juil. 94 - PEC
*   Last Modif           : 25.08.95 - PEC
*                          21.04.98 - GRD - REF1784.
*************************************************************************/
RET_CODE DBA_SetNullFlagsAndLength(DbiConnection& dbiConn, DBI_SMALLINT *flagsPtr, DBI_INT *fieldLengthPtr, DBI_SMALLINT *bindFlagsPtr)
{
    FREE(dbiConn.m_bindNullFlags);
    FREE(dbiConn.m_bindFieldLength);
    FREE(dbiConn.m_bindFlags);

    dbiConn.m_bindNullFlags   = flagsPtr;
    dbiConn.m_bindFieldLength = fieldLengthPtr;
    dbiConn.m_bindFlags       = bindFlagsPtr; /* PMSTA-17490 - DDV - 140124 - Set and keep default_c on fields not returned by database */

	return(RET_SUCCEED);
}

/************************************************************************
*   Function             : DBA_FreeNullFlagsAndLength()
*
*   Description          : Free null Flags array and field length array
*                          associated to a connection
*
*   Arguments            : DbiConnection : the connection object
*
*   Functions call       : none
*
*   Global var. modified : SV_ConnectionList
*
*   Return               : RET_SUCCEED         : if ok
*                          RET_GEN_ERR_INVARG  : if an arg. is invalid
*
*   Creation Date        : Juil. 94 - PEC
*   Last Modif           : 25.08.95 - PEC
*                          20.04.98 - GRD - REF1784.
*************************************************************************/
RET_CODE DBA_FreeNullFlagsAndLength(DbiConnection& dbiConn)
{
	FREE(dbiConn.m_bindNullFlags);
	FREE(dbiConn.m_bindFieldLength);
	FREE(dbiConn.m_bindFlags); /* PMSTA-17490 - DDV - 140124 - Set and keep default_c on fields not returned by database */

	return(RET_SUCCEED);
}

/************************************************************************
*   Function             : DBA_GetConnServerType()
*
*   Description          : Return the connection server type (FinServer or
*                          SqlServer).
*
*   Arguments            : connectNo : a connection number
*
*   Return               : DBA_SERVER_TYPE_ENUM member
*
*   Creation Date        : 16.11.95 - PEC
*   Last Modif           : 20.04.98 - GRD - REF1784.
*                          PMSTA-19735 - 020415 - PMO : OpenServer / P1 / Thread handling
*************************************************************************/
DBA_SERVER_TYPE_ENUM DBA_GetConnServerType(int connectNo)
{
    DbiConnection* dbiConn = DBA_GetDbiConnFromConnectNo(connectNo);         /* PMSTA-19735 - 020415 - PMO */

	return nullptr == dbiConn ? NullServer : dbiConn->getDescription().getType();           /* PMSTA-19735 - 020415 - PMO */
}

/************************************************************************
*   Function             : DBA_GetConnection()
*
*   Description          : Search an available connection for a server type
*                          and connection mode and return a number corres-
*                          ponding to a connection in the connection list.
*                          This function works only for connections to SQL
*                          servers and official financial servers.
*
*   Arguments            : server : SqlServer or FinServer (enum)
*						 : role Optional param
*
*   Functions call       : AAALocalConnectionProvider::get().getConnection
*
*   Return               : a connection number : if ok
*                          DBA_CONN_NOT_FOUND  : if no connection is available
*
*  !!!!!!! In new implementation use of DBA_GetDbiConnnection instead of this one
*
*************************************************************************/
int DBA_GetConnection(DBA_SERVER_TYPE_ENUM server, AAAConnectionRole role)
{
    int ret = DBA_CONN_NOT_FOUND;
    DbiConnection * dbiConn = DBA_GetDbiConnection(server, role);

    if (dbiConn != nullptr)
    {
        ret = dbiConn->getId();
    }
    else
    {
        ret = DBA_CONN_NOT_FOUND;
    }
    return ret;
}

/************************************************************************
*   Function             : DBA_GetDbiConnectionCore()
*
*   Description          : Search an available connection for a server type
*                          and connection mode and return a number corres-
*                          ponding to a connection in the connection list.
*                          This function works only for connections to SQL
*                          servers and official financial servers.
*
*   Arguments            : desc                             A reference on AAAConnectionDescription
*                          Connection kind                  Special case for fusion server
*
*   Functions call       : AAALocalConnectionProvider::get().getConnection()
*
*   Return               : a pointer on DbiConnection object
*                          nullptr : if no connection is available
*
*   Last modif.          : PMSTA-21215 - 271015 - PMO : RPC with code has input parameters
*                          PMSTA-26427 - 240217 - PMO : Dispatcher must run faster
*                          PMSTA-32327 - 260718 - PMO : Improve error management in the fusion process regarding connection error
*
*************************************************************************/
STATIC DbiConnection * DBA_GetDbiConnectionCore(const AAAConnectionDescription & desc, const AAAConnectionKind & connectionKind)
{
    DbiConnection * conn = nullptr;

    try
    {
        if (SYS_GetTlsThread() != nullptr && DispatchServer != desc.getType() && AAAConnectionKind::StandardConnection == connectionKind)       /* PMSTA-26427 - 240217 - PMO */
        {
            conn = AAALocalConnectionProvider::get().getConnection(desc);
        }
        else
        {
            conn = AAAConnectionProvider::getConnectionProviderInstance().getConnection(desc);
        }

        if (conn != nullptr)
        {
            if (conn->mustCreateTempTables() && AAAConnectionKind::StandardConnection == connectionKind)
            {
                const RET_CODE ret = DBA_CreateTempTables(*conn, ALL_TEMP_TABLES);

                conn->resetReadOnly();   /* PMSTA-29027 - LJE - 190111 */

                if (ret != RET_SUCCEED)
                {
                    if (ret != RET_GEN_INFO_NOACTION)
                    {
                        std::stringstream msg;
                        msg << "An error occurs while creating/deleting temporary tables for description " << conn->getDescription();

                        if ((SYS_IsGuiMode() == TRUE) || (SERVER_IS_INIT() == TRUE))
                        {
                            MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, msg.str().c_str());
                        }
                        else
                        {
                            MSG_SendStrToLog(msg.str().c_str());
                        }

                        /* PMSTA-32327 - 260718 - PMO */
                        DBA_EndConnection(&conn, true);
                    }
                }
            }
            else if (desc.getRole() == ROLE_INIT)
            {
                conn->setReadOnly(true);        /* PMSTA-25371 - LJE - 161130 */
            }
            else
            {
                conn->resetReadOnly();  /* PMSTA-29027 - LJE - 190111 */
            }
        }
    }
    catch (AAACannotConnectException &e)
    {
            // In import process no error if we cannot connect the dispatcher
        if (desc.getType() != DispatchServer || SYS_IsBatchMode() == FALSE)
        {
            if ((SYS_IsGuiMode() == FALSE && SYS_IsSqlMode() == FALSE) || SYS_GetEnvBoolOrDefValue("AAAPRINTCONNECTFAILED", false)) /* PMSTA-26255 - 100118 - CMILOS */ /* PMSTA-26255 - LJE - 180710 */
            {
                MSG_SendExceptionMesg(FILEINFO, e.getCallStack(), e.what());                         /* PMSTA-21907 - 281215 - PMO */
            }
        }
        conn = nullptr;
    }
    catch (AAAPoolUsageException &e )
    {
        MSG_SendExceptionMesg(FILEINFO, e.getCallStack(), e.what());                            /* PMSTA-21907 - 281215 - PMO */

        conn = nullptr;
    }

    if (conn != nullptr)
    {
        conn->assertThreadConnectionCoherence();
    }

    return conn;
}

/************************************************************************
*   Function             : DBA_GetDbiConnection()
*
*   Description          : Search an available connection for a server type
*                          and connection mode and return a number corres-
*                          ponding to a connection in the connection list.
*                          This function works only for connections to SQL
*                          servers and official financial servers.
*
*   Arguments            : a reference on AAAConnectionDescription
*                          Connection kind    Special case for fusion server
*
*   Functions call       : AAALocalConnectionProvider::get().getConnection()
*
*   Return               : a pointer on DbiConnection object
*                          nullptr : if no connection is available
*
*   Creation             : PMSTA-24985 - 111016 - PMO : Connection crash
*
*   Last modif.          : PMSTA-25644 - 141216 - PMO : When dispatch Server configuration change (host or port) => need to restart all fin & fusion servers
*                          PMSTA-26427 - 240217 - PMO : Dispatcher must run faster
*
*************************************************************************/
DbiConnection * DBA_GetDbiConnection(const AAAConnectionDescription & desc, const AAAConnectionKind & connectionKind)   /* PMSTA-26427 - 240217 - PMO */
{
    return DBA_GetDbiConnectionCore(desc, connectionKind);
}

/************************************************************************
*   Function             : DBA_GetDbiConnection()
*
*   Description          : Search an available connection for a server type
*                          and connection mode and return a number corres-
*                          ponding to a connection in the connection list.
*                          This function works only for connections to SQL
*                          servers and official financial servers.
*
*   Arguments            : a reference on AAAConnectionDescription
*
*   Functions call       : AAALocalConnectionProvider::get().getConnection()
*
*   Return               : a pointer on DbiConnection object
*                          nullptr : if no connection is available
*
*  Last modif.           : PMSTA-24510 - 220816 - PMO : Fusion & Dispatcher in HTTP
*                          PMSTA-25644 - 141216 - PMO : When dispatch Server configuration change (host or port) => need to restart all fin & fusion servers
*
*************************************************************************/
DbiConnection * DBA_GetDbiConnection(DBA_SERVER_TYPE_ENUM server, AAAConnectionRole role)
{
    AAAConnectionDescription desc(server, string(), role);
    DbiConnection *conn = DBA_GetDbiConnection(desc);

    /* Maybe the configuration has changed PMSTA-25644 - 141216 - PMO */
    if (nullptr == conn && (FinServer == desc.getType() || DispatchServer == desc.getType()))
    {
        ClientConfig                clientConfig;
        const ServerClientConfig &  serverClientConfig = clientConfig.getServerClientConfig(desc.getServerName());

        if (0 != desc.getUrl().compare(serverClientConfig.getUrl()) || true == desc.getUrl().empty())
        { // Configuration has changed

            if (true == desc.getUrl().empty() && DispatchServer == server)
            {
                /* validates and updates dispatcher info*/
                GEN_IsDispatcherChanged();
            }

            desc.reload();

            // Try again
            if (true == SYS_GetThreadRetryPrefixMessage().empty())
            {
                // Retry only one time
                ThreadRetryPrefixMessage    threadRetryPrefixMessage("Retrying");   /* PMSTA-25644 - 141216 - PMO */
                threadRetryPrefixMessage.setCounter(1);

                conn = DBA_GetDbiConnection(desc);
            }
            else
            {
                // The retry loop is on the caller
                conn = DBA_GetDbiConnection(desc);
            }
        }
    }

    return conn;
}
/************************************************************************
*   Function             : DBA_GetDbiConnection()
*
*   Description          : Search an available connection for a server type
*                          and connection mode and return a number corres-
*                          ponding to a connection in the connection list.
*                          This function works only for connections to SQL
*                          servers and official financial servers.
*
*   Arguments            : a reference on AAAConnectionDescription
*
*   Functions call       : AAALocalConnectionProvider::get().getConnection()
*
*   Return               : a pointer on DbiConnection object
*                          nullptr : if no connection is available
*
*   Last modif.          : PMSTA-21215 - 271015 - PMO : RPC with code has input parameters
*                          PMSTA-21907 - 281215 - PMO : cleanup PoolException
*
*************************************************************************/
DbiConnection * DBA_GetDbiConnFromConnectNo(int connectNo)
{
	DbiConnection *conn = nullptr;

    /* PMSTA-37366 - LJE - 200619 */
    if (connectNo == NO_VALUE)
    {
        return conn;
    }

	try
    {
        if (SYS_GetTlsThread() != nullptr)
        {
            conn = AAALocalConnectionProvider::get().getConnection(connectNo);
        }
        else
        {
            conn = AAAConnectionProvider::getConnectionProviderInstance().getConnection(connectNo);
        }
	}
	catch (AAACannotConnectException &e)
    {
        MSG_SendExceptionMesg(FILEINFO, e.getCallStack(), e.what());                            /* PMSTA-21907 - 281215 - PMO */
		conn = nullptr;
	}
	catch (AAAPoolUsageException &e)
    {
        MSG_SendExceptionMesg(FILEINFO, e.getCallStack(), e.what());                            /* PMSTA-21907 - 281215 - PMO */
		conn = nullptr;
	}

    /* PMSTA-21215 - 271015 - PMO */
    if (nullptr != conn)
    {
        conn->assertThreadConnectionCoherence();
    }

	return conn;
}

/************************************************************************
*   Function             : DBA_CheckConnectNbCoherence()
*
*   Description          : Check if a given connection number is valid or
*                          not, according to available connections.
*
*   Arguments            : None
*
*   Functions call       : None
*
*   Global var. modified : None
*
*   Return               : RET_SUCCEED             : if ok
*                          RET_DBA_ERR_CONNOTFOUND : if problem with connection
*                                                    handling
*                          RET_GEN_ERR_INVARG      : if argument problem
*
*   Creation Date        : Jan. 095 - PEC
*   Last Modif           : 25.08.95 - PEC
*                          01.12.95 - PEC - Added global variable SV_TotalAvailConn
*                                           which contain availables connections. This
*                                           variable avoid to call GEN_GetApplInfo four
*                                           times each time DBA_CheckConnectNbCoherence
*                                           is called.
*                          29.09.99 - GRD - Ref.: REF3847.
*                          PMSTA-13294 - 281111 - PMO : Avoid the error message "DBA_CheckConnectNbCoherence Invalid argument (connectNo)" when importing
*************************************************************************/
RET_CODE DBA_CheckConnectNbCoherence(int connectNo)
{
	RET_CODE ret = RET_SUCCEED;

	if (connectNo < 0)
	{
		char errMsg[80];
		snprintf(errMsg, sizeof(errMsg), "%d", connectNo);
		MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "DBA_CheckConnectNbCoherence connectNo.", errMsg);
		ret = RET_GEN_ERR_INVARG;
	}
	return ret;
}

/************************************************************************
*   Function             : DBA_GetConnStructPtr()
*
*   Description          : Return a pointer on a DBA_CONNECT_INFO_ST
*
*   Arguments            : connectNo : a connection number in the conn. list
*
*   Functions call       : None
*
*   Global var. modified : None
*
*   Return               : a DBA_CONNECT_INFO_ST pointer
*
*   Creation Date        : Dec. 94 - PEC
*
*   Last Modif           : 25.8.95 - PEC
*                          PMSTA-19735 - 020415 - PMO : OpenServer / P1 / Thread handling
*
*************************************************************************/
// #pragma deprecated(DBA_GetConnStructPtr)
DBA_CONNECT_INFO_STP DBA_GetConnStructPtr(int connectNo)
{
	DBA_CONNECT_INFO_STP ret = nullptr;
	if (DBA_CheckConnectNbCoherence(connectNo) == RET_SUCCEED)
	{
		try{
            DbiConnection * pConnection = AAALocalConnectionProvider::get().getConnection(connectNo);       /* PMSTA-19735 - 020415 - PMO */

            if(nullptr != pConnection)                                                                      /* PMSTA-19735 - 020415 - PMO */
            {
                ret = pConnection->getConnStructPtr();                                                      /* PMSTA-19735 - 020415 - PMO */
            }
		}
		catch (std::logic_error e){
			MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, e.what());
			MSG_SendMesg(RET_DBA_ERR_CANNOTCONNECT, 0, FILEINFO);
		}
	}
	return ret;
}

/************************************************************************
*   Function             : DBA_ConvertCTypeDataToFld()
*
*   Description          : Convert a data (dataPtr is the pointer on the data) and store it
*                          in a DBA_DYNFLD_ST structure in the right format, according to
*                          fldDataType.
*
*   Arguments            : dataPtr           : pointer on a data (number, string, date)
*                          cType             : CTYPE_ENUM member (DoubleCType, ...)
*                          fldPtr            : pointer on a dynamic field
*                          fldDataType       : datatype of the dynamic field
*
*   Functions call       :
*
*   Global var. modified : SV_ConnectionList
*
*   Return               : RET_SUCCEED             : if ok
*
*   Creation Date        : Dec. 94 - PEC
*
*   Last Modif           : 25.8.95 - PEC
*                          REF8844 - LJE - 030404 : Add fld parameter
*                          PMSTA-16124 - 250413 - PMO : Ensure coherence of printf / scanf formats with 32bits / 64 bits datatypes
*
*************************************************************************/
RET_CODE DBA_ConvertCTypeDataToFld( PTR dataPtr, CTYPE_ENUM cType,
                    DBA_DYNFLD_STP dynStp, int fld, DATATYPE_ENUM fldDataType)
{
    char	buffer[50];
    UChar * Ustr;  /* DLA - REF9303 - 030822 */
    int     Clen;  /* DLA - REF9303 - 030822 */
    int     Ulen;  /* DLA - REF9303 - 030822 */
    CURRENTCHARSETCODE_ENUM CharSet = CurrentCharsetCode_IsNull; /* DLA - REF9303 - 030825 */

    switch(cType)
    {
        case DoubleCType :
        switch(GET_CTYPE(fldDataType))
        {
            case DoubleCType :
            SET_DOUBLE(dynStp, fld, *((double *)dataPtr));
            break;

        case CharPtrCType :
        case TextPtrCType :  /* REF4204 - SSO - 000211 */
            sprintf(buffer, "%f", *((double *)dataPtr));
            SET_STRING(dynStp, fld, buffer);
            break;

        case IntCType :
            SET_INT(dynStp, fld, (int) (*((double *)dataPtr)));
            break;

        case LongLongCType :
            SET_LONGLONG(dynStp, fld, (INT64_T) (*((double *)dataPtr)));    /* DLA - PMSTA08801 - 101026 */
            break;

        case UIntCType :
            SET_UINT(dynStp, fld, (unsigned int) (*((double *)dataPtr)));
            break;

        case ShortCType :
            SET_SHORT(dynStp, fld, (short) (*((double *)dataPtr)));
            break;

        case UCharCType :
            SET_UCHAR(dynStp, fld, (unsigned char) (*((double *)dataPtr)));
            break;

        case UShortCType :
            SET_USHORT(dynStp, fld, (unsigned short) (*((double *)dataPtr)));
            break;

        case DateTimeStCType :
            SET_NULL_DATETIMEST(dynStp, fld);
            break;

        default:
            break;
        }
        break;

    case CharPtrCType    :
    case TextPtrCType    :  /* REF4204 - SSO - 000211 */
    case UniCharPtrCType :  /* DLA - REF9303 - 030821 */
    case UniTextPtrCType :  /* DLA - REF9303 - 030821 */

        switch(GET_CTYPE(fldDataType))
        {
        case DoubleCType :
            SET_DOUBLE(dynStp, fld, (double) atof((char *)dataPtr));
            break;

        case CharPtrCType :
        case TextPtrCType :  /* REF4204 - SSO - 000211 */
            SET_STRING(dynStp, fld, (char *)dataPtr);
            break;

        case UniCharPtrCType : /* DLA - REF9303 - 030821 */
        case UniTextPtrCType : /* DLA - REF9303 - 030821 */

            GEN_GetApplInfo(ApplCurrentCharsetCodeEnum, &CharSet);

            switch(CharSet)
            {
            case CurrentCharsetCode_UTF8:
                Clen = SYS_StrLen((char *)dataPtr);
                Ustr = (UChar*)CALLOC(Clen+1,sizeof(UChar));
                ICU4AAA_ConvertFromUTF8((char *)dataPtr,Clen, Ustr, Clen, &Ulen);
                SET_USTRING(dynStp, fld, (UChar *)Ustr);
                FREE(Ustr); /* DLA - REF8712 - 031124 - Memory leak */
                break;
            default :
                assert (1==0);
                break;
            }
            break;

        case IntCType :
            SET_INT(dynStp, fld, (int) atol((char *)dataPtr));
            break;

        case LongLongCType :
            SET_LONGLONG(dynStp, fld, (INT64_T) ATOLL((char *)dataPtr));    /* DLA - PMSTA08801 - 101026 */
            break;

        case UIntCType :
            SET_UINT(dynStp, fld, (unsigned int)  atol((char *)dataPtr));
            break;

        case ShortCType :
            SET_SHORT(dynStp, fld, (short)  atol((char *)dataPtr));
            break;

        case UCharCType :
            SET_UCHAR(dynStp, fld, (unsigned char)  atol((char *)dataPtr));
            break;

        case UShortCType :
            SET_USHORT(dynStp, fld, (unsigned short)  atol((char *)dataPtr));
            break;

        case DateTimeStCType :
            SET_NULL_DATETIMEST(dynStp, fld);
            break;

        default:
            break;
        }
        break;

    case IntCType :
        switch(GET_CTYPE(fldDataType))
        {
            case DoubleCType :
            SET_DOUBLE(dynStp, fld, (double) *((long *)dataPtr));
            break;

        case CharPtrCType :
        case TextPtrCType :  /* REF4204 - SSO - 000211 */
            sprintf(buffer, "%ld", *((long *)dataPtr));                                                                                                                 /* PMSTA-16124 - 250413 - PMO */
            SET_STRING(dynStp, fld, buffer);
            break;

        case IntCType :
            SET_INT(dynStp, fld, (int) (*((int *)dataPtr)));
            break;

        case UIntCType :
            SET_UINT(dynStp, fld, (unsigned int) (*((int *)dataPtr)));
            break;

        case ShortCType :
            SET_SHORT(dynStp, fld, (short) (*((long *)dataPtr)));
            break;

        case UCharCType :
            SET_UCHAR(dynStp, fld, (unsigned char) (*((long *)dataPtr)));
            break;

        case UShortCType :
            SET_USHORT(dynStp, fld, (unsigned short) (*((long *)dataPtr)));
            break;

        case DateTimeStCType :
            SET_NULL_DATETIMEST(dynStp, fld);
            break;

        default:
            break;
        }
        break;

    case UIntCType :
        switch(GET_CTYPE(fldDataType))
        {
            case DoubleCType :
            SET_DOUBLE(dynStp, fld, (double) *((unsigned long *)dataPtr));
            break;

        case CharPtrCType :
        case TextPtrCType :  /* REF4204 - SSO - 000211 */
            sprintf(buffer, "%ld", *((unsigned long *)dataPtr));                                                                                                        /* PMSTA-16124 - 250413 - PMO */
            SET_STRING(dynStp, fld, buffer);
            break;

        case IntCType :
            SET_INT(dynStp, fld, (int) (*((unsigned int *)dataPtr)));
            break;

        case UIntCType :
            SET_UINT(dynStp, fld, (unsigned int) (*((unsigned int *)dataPtr)));
            break;

        case ShortCType :
            SET_SHORT(dynStp, fld, (short) (*((unsigned long *)dataPtr)));
            break;

        case UCharCType :
            SET_UCHAR(dynStp, fld, (unsigned char) (*((unsigned long *)dataPtr)));
            break;

        case UShortCType :
            SET_USHORT(dynStp, fld, (unsigned short) (*((unsigned long *)dataPtr)));
            break;

        case DateTimeStCType :
            SET_NULL_DATETIMEST(dynStp, fld);
            break;

        default:
            break;
        }
        break;

    case ShortCType :
        switch(GET_CTYPE(fldDataType))
        {
            case DoubleCType :
            SET_DOUBLE(dynStp, fld, (double) *((short *)dataPtr));
            break;

        case CharPtrCType :
        case TextPtrCType :  /* REF4204 - SSO - 000211 */
            sprintf(buffer, "%d", *((short *)dataPtr));
            SET_STRING(dynStp, fld, buffer);
            break;

        case IntCType :
            SET_INT(dynStp, fld, (int) (*((short *)dataPtr)));
            break;

        case UIntCType :
            SET_UINT(dynStp, fld, (unsigned int) (*((short *)dataPtr)));
            break;

        case ShortCType :
            SET_SHORT(dynStp, fld, (short) (*((short *)dataPtr)));
            break;

        case UCharCType :
            SET_UCHAR(dynStp, fld, (unsigned char) (*((short *)dataPtr)));
            break;

        case UShortCType :
            SET_USHORT(dynStp, fld, (unsigned short) (*((short *)dataPtr)));
            break;

        case DateTimeStCType :
            SET_NULL_DATETIMEST(dynStp, fld);
            break;

        default:
            break;
        }
        break;

    case UCharCType :
        switch(GET_CTYPE(fldDataType))
        {
            case DoubleCType :
            SET_DOUBLE(dynStp, fld, (double) *((unsigned char *)dataPtr));
            break;

        case CharPtrCType :
        case TextPtrCType :  /* REF4204 - SSO - 000211 */
            sprintf(buffer, "%d", *((unsigned char *)dataPtr));
            SET_STRING(dynStp, fld, buffer);
            break;

        case IntCType :
            SET_INT(dynStp, fld, (int) (*((unsigned char *)dataPtr)));
            break;

        case UIntCType :
            SET_UINT(dynStp, fld, (unsigned int) (*((unsigned char *)dataPtr)));
            break;

        case ShortCType :
            SET_SHORT(dynStp, fld, (short) (*((unsigned char *)dataPtr)));
            break;

        case UCharCType :
            SET_UCHAR(dynStp, fld, (unsigned char) (*((unsigned char *)dataPtr)));
            break;

        case UShortCType :
            SET_USHORT(dynStp, fld, (unsigned short) (*((unsigned char *)dataPtr)));
            break;

        case DateTimeStCType :
            SET_NULL_DATETIMEST(dynStp, fld);
            break;

        default:
            break;
        }
        break;

    case UShortCType :
        switch(GET_CTYPE(fldDataType))
        {
            case DoubleCType :
            SET_DOUBLE(dynStp, fld, (double) *((unsigned short *)dataPtr));
            break;

        case CharPtrCType :
        case TextPtrCType :  /* REF4204 - SSO - 000211 */
            sprintf(buffer, "%d", *((unsigned short *)dataPtr));
            SET_STRING(dynStp, fld, buffer);
            break;

        case IntCType :
            SET_INT(dynStp, fld, (int) (*((unsigned short *)dataPtr)));
            break;

        case UIntCType :
            SET_UINT(dynStp, fld, (unsigned int) (*((unsigned short *)dataPtr)));
            break;

        case ShortCType :
            SET_SHORT(dynStp, fld, (short) (*((unsigned short *)dataPtr)));
            break;

        case UCharCType :
            SET_UCHAR(dynStp, fld, (unsigned char) (*((unsigned short *)dataPtr)));
            break;

        case UShortCType :
            SET_USHORT(dynStp, fld, (unsigned short) (*((unsigned short *)dataPtr)));
            break;

        case DateTimeStCType :
            SET_NULL_DATETIMEST(dynStp, fld);
            break;

        default:
            break;
        }
        break;

    case DateTimeStCType :
        switch(GET_CTYPE(fldDataType))
        {
            case DoubleCType :
            SET_NULL_DATETIMEST(dynStp, fld);
            break;

        case CharPtrCType :
        case TextPtrCType :  /* REF4204 - SSO - 000211 */
            SET_NULL_DATETIMEST(dynStp, fld);
            break;

        case IntCType :
            SET_NULL_DATETIMEST(dynStp, fld);
            break;

        case UIntCType :
            SET_NULL_DATETIMEST(dynStp, fld);
            break;

        case ShortCType :
            SET_NULL_DATETIMEST(dynStp, fld);
            break;

        case UCharCType :
            SET_NULL_DATETIMEST(dynStp, fld);
            break;

        case UShortCType :
            SET_NULL_DATETIMEST(dynStp, fld);
            break;

        case DateTimeStCType :
            SET_DATETIME(dynStp, fld, *((DATETIME_STP) dataPtr));
            break;

        default:
            break;
        }
        break; /* DLA - REF9089 - 030727 */

    case LongLongCType : /* DLA - REF9089 - 030727 */  /* PMSTA08801 - DDV - 091126 */
        switch(GET_CTYPE(fldDataType))
        {
        case  LongLongCType:  /* PMSTA08801 - DDV - 091126 */
               SET_DICT (dynStp, fld, (ID_T) (*((ID_T *)dataPtr)));
               break;

        case DoubleCType :
            SET_DOUBLE(dynStp, fld, (double) *((INT64_T *)dataPtr));
            break;

        case CharPtrCType :    /* DLA - PMSTA08801 - 101026 */
        case TextPtrCType :
            sprintf(buffer, "%" szFormatId, *((INT64_T *)dataPtr));
            SET_STRING(dynStp, fld, buffer);
            break;

        default:
            break;
        }
        break;

    default:
        break;
    }

    return(RET_SUCCEED);
}

/************************************************************************
*   Function             : DBA_FilterMsgInfos()
*
*   Description          : Filter the messages stack associated to a connection
*                          after a call to a server.
*
*   Arguments            : connectNo    : the connection number in the list
*                          retCode      : the final result code
*
*   Functions call       :
*
*
*   Global var. modified : None
*
*   Return               : RET_SUCCEED
*
*   Creation Date        : 03.11.95 - PEC
*   Last Modification    : 20.04.98 - GRD - REF1784.
*                          30.06.98 - SME - REF2455
*************************************************************************/
RET_CODE DBA_FilterMsgInfos(DbiConnection& dbiConn, RET_CODE *retCode)
{
    int	 abort  = FALSE;
		*retCode = RET_SUCCEED;

	int msgNbr = dbiConn.m_msgStack.size();

    for (int i = 0; i < msgNbr; i++)
    {
        DbaMsgStackMemberClass &msgMember = dbiConn.m_msgStack.getMember(i);

		switch (msgMember.msgOrigin)
        {
        case ServerHandler :

            /* If the message is generated by the database (with a GUI message) */
			if (strstr(msgMember.msgString.c_str(), "lev=") != NULL)
            {
				const char *msgBeg = strchr(msgMember.msgString.c_str(), ':') + 2;

                MSG_DispMsgText(RET_SUCCEED,msgBeg);        /*  FIH-REF8683-030708  Add retCode */
                *retCode = msgMember.retCode;
                break;
            }

            *retCode = msgMember.retCode;

			switch (*retCode)
            {
            case RET_SRV_LIB_ERR_PARAMNOTSUPPLIED :      /* A mandatory column has not been supplied */
            case RET_SRV_LIB_ERR_NULLCOLVALUE :      /* Not Null constraints */
            case RET_SRV_LIB_ERR_FOREIGNKEY :      /* Foreign key constraint */
            case RET_SRV_LIB_ERR_CHECKCONSTRAINT :      /* Check constraint */
            case RET_SRV_LIB_ERR_DUPLICATEKEY:
            case RET_SRV_LIB_ERR_DIVIDE_BY_ZERO:
            case RET_SRV_LIB_ERR_DB_OVERFLOW:
                MSG_DispMesg(*retCode, NULL, NULL);
                continue;

            case RET_SRV_LIB_ERR_PERM_DENIED:
            case RET_SRV_LIB_ERR_COMMAND_ABORTED:
            case RET_SRV_INFO_NO_POSITIONS:
            case RET_SRV_INFO_POS_LOADING_FAILED:
            case RET_SRV_INFO_CLOSING_SUCCEED:
            case RET_SRV_LIB_ERR_DEADLOCK:
            case RET_SRV_LIB_ERR_INV_PARAM_VALUE:
                continue;

            case RET_SRV_LIB_ERR_CONNFAILED :     /* Can't open a connection on financial server */
                MSG_DispMesg(RET_SRV_LIB_ERR_CONNFAILED, NULL, NULL, NameType, dbiConn.getSpecification().getServerName().c_str());
                continue;

            case RET_SRV_LIB_ERR_PROC_CACHE_MEMORY: /* REF2455 not enough procedure cache memory */
                MSG_DispMesg(RET_SRV_LIB_ERR_PROC_CACHE_MEMORY, NULL, NULL);
                abort=TRUE;
                continue;
                /* *retCode = RET_SRV_LIB_ERR_PROC_CACHE_MEMORY;*/

            case RET_SRV_LIB_ERR_INVALID_USER_IN_DB:       /* Server user id ... is not a valid user in database ... */
            {
                MSG_DispMesg(RET_SRV_LIB_ERR_INVALID_USER_IN_DB, NULL, NULL, dbiConn.getDescription().getUser().c_str()); /* PMSTA-nuodb - LJE - 190411 */
                continue;
            }

            default:
                *retCode = RET_SRV_LIB_ERR_UNKNOWN_MSG;
                continue;
            }

            break;

        case ClientHandler :

			switch (msgMember.severity)
            {
            case CS_SV_INFORM :
                break;
            case CS_SV_API_FAIL :
                break;
            case CS_SV_RETRY_FAIL :
                break;
            case CS_SV_RESOURCE_FAIL :
                break;
            case CS_SV_CONFIG_FAIL :
                break;
            case CS_SV_COMM_FAIL :
                break;
            case CS_SV_INTERNAL_FAIL :
                break;
            case CS_SV_FATAL :
                break;
            }

            break;

        case NullHandler:
            break;
        }
    }

    /* REF2455 - not enough memory in sybase , only solution abort the application */
    if (abort)
    {
        DBA_DeleteApplSessionOnExit(AppSessionInvalidationNat_Unexpected_exit, &dbiConn); /* PMSTA-22549 - CHU - 160603 */

        /* REF3488 - SSO - 990322: be more explicit in log file */
        MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "!!! FATAL error: EXITING process !!!");
        SYS_Shutdown(EXIT_FAILURE);    /* DLA - PMSTA-26546 - 170314 */
    }
    return(RET_SUCCEED);
}

/************************************************************************
*   Function             : DBA_GetDbDate()
*
*   Description          :
*
*   Arguments            : date         : the user login
*                          password     : the user password
*                          connectNo    : the pointer on the conn number
*
*
*   Return               : RET_SUCCEED               : if ok
*                          RET_DBA_ERR_CONNOTFOUND   : if no free connection found
*
*   Creation Date        :
*   Last Modification    :
*************************************************************************/
RET_CODE DBA_GetDbDate(DATETIME_STP datetimeStp)
{
    DATETIME_ST     sysDateTime;
    RET_CODE        ret=RET_SUCCEED;
    long            diffDay=0;

    memset(datetimeStp, 0, sizeof(DATETIME_ST));
    memset(&sysDateTime, 0, sizeof(DATETIME_ST));

    if (EV_EnableMicrosecTime)
    {
        DATE_CurrentDateTime(&sysDateTime, true);
    }
    else
    {
        DATE_CurrentDateTime(&sysDateTime);
    }
  

    if (SV_DiffDbSysDateDate == MAGIC_END_DATE)
    {
        DbiConnectionHelper     dbiConnHelper;

        /* And datetimeStp is initialized and returned */
        if (dbiConnHelper.isValidAndInit() &&
            (ret = DBA_GetDbDateOnServer(datetimeStp, *(dbiConnHelper.getConnection()))) == RET_SUCCEED)
        {
            SV_DiffDbSysDateTime = TIME_Diff(datetimeStp->time, sysDateTime.time);
            DATE_DaysBetween(sysDateTime.date, datetimeStp->date,
                             AccrRule_Actual_Actual, &SV_DiffDbSysDateDate, 0); /* PMSTA-22396  - SRIDHARA – 160430 */
        }
    }
    else
    {
        /* Compute by difference */
        datetimeStp->time = TIME_Add(sysDateTime.time, SV_DiffDbSysDateTime, &diffDay);
        datetimeStp->date = DATE_Move(sysDateTime.date, SV_DiffDbSysDateDate + diffDay, Day);
    }

    return(ret);
}

/************************************************************************
*   Function             : DBA_GetDbDateOnServer()
*
*   Description          :
*
*   Arguments            : date         : the user login
*                          password     : the user password
*                          connectNo    : the pointer on the conn number
*
*
*   Return               : RET_SUCCEED               : if ok
*                          RET_DBA_ERR_CONNOTFOUND   : if no free connection found
*
*   Creation Date        :
*   Last Modification    :
*************************************************************************/
RET_CODE DBA_GetDbDateOnServer(DATETIME_STP datetimeStp, DbiConnection& dbiConn)
{
	return DBI_GetDbDateOnServer(datetimeStp, dbiConn);
}

/************************************************************************
*   Function             : DBA_UpdTableModifStat()
*
*   Description          : Given an object, update table Modif_stat.
*
*   Arguments            : object         : an object.
*
*   Return               : void
*
*   Creation Date        : 11.12.96 - GRD - Ref.: DVP306.
*
*   Last modif.          : REF4218 - SSO - 991217
*                          PMSTA-15184 - 151012 - PMO : Some warnings during TA build process
*
*************************************************************************/
void DBA_UpdTableModifStat(DbiConnection& dbiConn, OBJECT_ENUM    object)
{
    DBA_DYNFLD_STP  admArg = NULL;
    DICT_T          entDictId;
    DATETIME_T      databaseDate;
    RET_CODE        retSybaseDate;
    int             entDictIdExists = FALSE;

    /* First of all, verify object integrity. */
    if ((entDictIdExists = DBA_GetDictId(object, &entDictId)) == FALSE)
    {
        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "DBA_UpdTableModifStat", SYS_Stringer("invalid object (", SYS_ToString(object), ")").c_str());
        return;
    }

        /* Take the Sybase current date/time. */    /* REF4521 - RAK - 000413 - Use database date */
    if ((retSybaseDate = DBA_GetDbDateOnServer(&databaseDate, dbiConn)) != RET_SUCCEED)
    {
        MSG_SendMesg(RET_DBA_ERR_NODATA, 0, FILEINFO);
        return;
    }

    if ((admArg = ALLOC_DYNST(Adm_Arg)) == NULL)
    {
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "UpdTableModifStat");
        return;
    }


    SET_DICT(admArg,     Adm_Arg_EntDictId, entDictId);
    SET_DATETIME(admArg, Adm_Arg_Date,      databaseDate);

    if (DBA_Notif(TabModifStat, UNUSED, Adm_Arg, admArg, dbiConn, DBA_SET_CONN | DBA_NO_CLOSE) != RET_SUCCEED) /* REF4218 - SSO - 991217 */
    {
        MSG_SendMesg(RET_GEN_ERR_NOACTION, 0, FILEINFO);
    }

    FREE_DYNST(admArg, Adm_Arg);
    return;
}

/************************************************************************
*   Function             : DBA_GetUmnountedConn()
*
*   Description          : Return the first unmounted connection founded
*                          in connection list, -1 elsewhere
*
*   Arguments            : None
*
*   Return               : a connection number or -1
*
*   Creation Date        : 08.02.97 - PEC - Ref.: DVP196
*************************************************************************/
// #pragma deprecated(DBA_GetUmnountedConn)
int DBA_GetUmnountedConn()
{
    return (DBA_GetMaxAvailConn());
}

/************************************************************************
*   Function             : DBA_GimmeNetRunning()
*
*   Description          : Retrieve running processes correponding to
*                          the given string from sybase.
*
*   Arguments            : An application name.
*                          Modules.
*
*   Functions call       :
*
*   Return               : RET_SUCCEED           : if ok.
*                          DBA_CONN_NOT_FOUND    : if connection failed.
*                          RET_DBA_ERR_DBPROBLEM : if problem with sybase.
*                          RET_GEN_ERR_INVARG    : if application name null.
*
*   Creation Date        : 01.04.1997: GRD - DVP404.
*   Last Modif           : 14.12.1998: GRD - REF3073.
*                          REF7264 - 0201225 - PMO : Compilation errors and warnings with C++ compiler
*                          PMSTA-17133 - 051113 - PMO : Many compilation warnings in C code especially " Converting a 64-bit type value to "int" causes truncation."
*
*************************************************************************/
// #pragma deprecated(DBA_GimmeNetRunning)
/*DLA TODO*/
RET_CODE DBA_GimmeNetRunning(const char	*appName,		/* Application name to spy. *//* REF8728 - YST - 030218 */
                 short	*netCoreNb,
                 short	*netProdModNb,
                 short	*netAttribModNb,
                 short	*netRiskModNb,
                 short	*netAccModNb,
                 short	*netFundModNb,
                 short	*netCorpActionsModNb,
                 short	*netAdvAnalyticsModNb,
                 short	*netCompManagementModNb,
                 short	*netExcelReportModNb,
                 short	*netRAModNb,
                 short	*netACMModNb,
                 short	*netOMModNb)
{
	return DBI_GimmeNetRunning(appName,
		netCoreNb,
		netProdModNb,
		netAttribModNb,
		netRiskModNb,
		netAccModNb,
		netFundModNb,
		netCorpActionsModNb,
		netAdvAnalyticsModNb,
		netCompManagementModNb,
		netExcelReportModNb,
		netRAModNb,
		netACMModNb,
		netOMModNb);
}

/************************************************************************
*   Function             : DBA_GetSrvConnection()
*
*   Description          : Search an available connection to a server.
*                          Select only Unmounted connections then connect
*                          to the given server and return a number
*                          corresponding to a connection in the
*                          connection list. Used to allow a client to
*                          establish a connection to any type of server.
*                          This connection will be flagged as permanent.
*
*   Arguments            : server name.
*
*   Functions call       :
*
*   Global var. modified : SV_ConnectionList
*
*   Return               : a connection number : if ok
*                          DBA_CONN_NOT_FOUND  : if no connection is available
*
*   Creation Date        : 10.11.1998 - GRD - REF3016.
*
*   Last Modif           : PMSTA-18094 - 130514 - PMO : Avoid extracting the user credentials from the GUI running on Windows (via dump, etc.)
*                          PMSTA-21215 - 271015 - PMO : RPC with code has input parameters
*                          PMSTA-21907 - 281215 - PMO : cleanup PoolException
*                          PMSTA-24510 - 220816 - PMO : Fusion & Dispatcher in HTTP
*                          PMSTA-26427 - 240217 - PMO : Dispatcher must run faster
*                          PMSTA-26837 - 170411 - DLA : Change the description when server has moved
*
*************************************************************************/
DbiConnection * DBA_GetDbiSrvConnection(AAAConnectionDescription &desc, const AAAConnectionKind & connectionKind, int level) /* PMSTA-26427 - 240217 - PMO */
{
	DbiConnection * dbiConn = nullptr;
 	try
    {
        if (SYS_GetTlsThread() != nullptr && DispatchServer != desc.getType() && AAAConnectionKind::StandardConnection == connectionKind) /* Dispatcher connections are shared between different threads PMSTA-21215 - 271015 - PMO */
        {
            dbiConn = AAALocalConnectionProvider::get().getConnection(desc);
        }
        else
        {
            dbiConn = AAAConnectionProvider::getConnectionProviderInstance().getConnection(desc);
        }

        if (dbiConn == nullptr)
        {
            if (desc.getModel() == UnknownRdbms)
            {
                if (desc.getSilentMode())
                {
                    return nullptr;
                }
                else
                {
					throw AAACannotConnectException("Connection error for user " + desc.getUser() + " to server " + desc.getServerName(),
							desc,
							0);
	            }
            }
            return DBA_GetDbiSrvConnection(desc);
        }
	}
    catch (AAACannotConnectException &e)
    {
        /* DLA - PMSTA-26837 - 170411 */
        /* The server has maybe change of host -> try to reload the from server_running an recall DBA_GetDbiSrvConnection */
        if (level == 0 && dbiConn == nullptr)
        {
			desc.reload();
			if (desc.isFinServerPool())
			{
				if (desc.isLastServer())
				{
					level++;
				}
			}
			else
			{
				level++;
			}
			dbiConn = DBA_GetDbiSrvConnection(desc, connectionKind, level); /* PMSTA-26427 - 240217 - PMO */
        }
        else
        {
			if (desc.getSilentMode() == false)
			{
				MSG_SendExceptionMesg(FILEINFO, e.getCallStack(), e.what());                        /* PMSTA-21907 - 281215 - PMO */
			}
		}
    }
    catch (AAAPoolUsageException &e)
    {
        MSG_SendExceptionMesg(FILEINFO, e.getCallStack(), e.what());                        /* PMSTA-21907 - 281215 - PMO */
		MSG_SendMesg(RET_DBA_ERR_CANNOTCONNECT, 0, FILEINFO);
	}

	if (dbiConn != nullptr && SV_ActiveConFlg == TRUE)
	{
		char	buf[255];

		int nmbConn = ++SV_NmbConOpenSrv;
		sprintf(buf,
			"DBA_GetConnection: Number of connections opened to Fin server [%d], opening connection [%d]\n",
			nmbConn, dbiConn->getId());

		AAA_RPT0(_CRT_WARN, buf);
	}

    /* PMSTA-24510 - 220816 - PMO */
    if (dbiConn != nullptr && QtHttp == dbiConn->m_connectToRDBMS)
    {
        DbiConnectionHelper dbi(dbiConn, false);
        dbi.setConnectionKind(connectionKind);              /* PMSTA-26427 - 240217 - PMO */
        (void)dbi.reopenHttpOnThreadChange();
    }

	return(dbiConn);
}

/************************************************************************
*   Function             : DBA_CheckPasswdHistory()
*
*   Description          :
*
*   Arguments            :
*
*   Functions call       :
*
*   Global var. modified :
*
*   Return               :
*
*
*   Creation Date        : 08.12.1999 - VST - REF4170.
*   Last Modif           :
*************************************************************************/
RET_CODE DBA_CheckPasswdHistory(SYSNAME_T user_code, PasswordEncrypted& password)
{
    int found = 0;

    DbiConnectionHelper dbiConnHelper(AAATransactionEnum::NotTransactionnal, SqlServer, ROLE_ADMIN);

    char          *pMD5Password = NULL;
    char       *pSHA256Password = NULL;
    char    *pMD5SaltedPassword = NULL;
    char           *pSHA256User = NULL;
    char *pSHA256SaltedPassword = NULL;

	DBA_DYNFLD_STP admArg;

	DBA_DYNFLD_STP *outputData;
	int            resultRows;
	RET_CODE                 ret = RET_SUCCEED;
		
	admArg = ALLOC_DYNST(Adm_Arg);
	if (admArg == NULL)
	{
		ret = RET_MEM_ERR_ALLOC;
		MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
	}

    DbiConnection* dbiConn = nullptr;
    if (dbiConnHelper.isValidAndInit() == false ||
        (dbiConn = dbiConnHelper.getConnection()) == nullptr)
    {
        return RET_DBA_ERR_CANNOTCONNECT;
    }

    RequestHelper requestHelper(dbiConn);
    requestHelper.setReadOnly(true);

    const AAALogger& sqlTraceLog = AAALogger::get(AAALogger::Logger::SqlTrace);
    if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
    {
        auto &sqlTrace = dbiConnHelper.getConnection()->getSqlTrace();
        sqlTrace.m_procedure = "DynSql.CheckExpiredHistory";
        sqlTrace.m_mode = DbiSqlTrace::Mode::Lang;
    }

	SET_SYSNAME(admArg, Adm_Arg_Sysname, user_code);

	if ((ret = dbiConnHelper.dbaSelect(ApplPswdHist, UNUSED, admArg, Io_Info, &outputData, &resultRows)) != RET_SUCCEED)
	{
		MSG_LogMesg(ret, 1, FILEINFO, "Select for recent passwords failed"); /*PMSTA-61464 - VPN - Previously used passwords are not validated*/
	}

    {
        SYSNAME_T szPassword; /* DLA - PMSTA-21596 - 160519 */
        AUTO_PASSWORD_CLEAR(szPassword, sizeof(szPassword));

        strcpy(szPassword, password.getClearPassword().getPassword());

        _CRYPT_HashMD5(szPassword, &pMD5Password);
        _CRYPT_HashSHA256(szPassword, &pSHA256Password);
        _CRYPT_HashMD5Salted(szPassword, pSHA256Password, &pMD5SaltedPassword);
        _CRYPT_HashSHA256(user_code, &pSHA256User);
        _CRYPT_HashSHA256Salted(szPassword, pSHA256User, &pSHA256SaltedPassword);
    }

	if(ret == 1 ) /*PMSTA-61464 - VPN - Previously used passwords are not validated*/
	{
		for (int i = 0; i < resultRows; i++)
		{
			switch ((PREFIX_ALGO_USED_ENUM)outputData[i]->data.strData.ptr[0])
			{
			case PREFIX_ALGO_USED_ENUM::SALTED_MD5:
				if (strcmp(pMD5SaltedPassword, outputData[i]->data.strData.ptr + 1) == 0)
				{
					found = 1;
				}
				break;

			case PREFIX_ALGO_USED_ENUM::SHA256:
				if (strcmp(pSHA256Password, outputData[i]->data.strData.ptr + 1) == 0)
				{
					found = 1;
				}
				break;

			case PREFIX_ALGO_USED_ENUM::SALTED_SHA256:                                         /* PMSTA-18081 - 021214 - PMO */
				if (strcmp(pSHA256SaltedPassword, outputData[i]->data.strData.ptr + 1) == 0)
				{
					found = 1;
				}
				break;

			default:
				if (strcmp(pMD5Password, outputData[i]->data.strData.ptr) == 0)
				{
					found = 1;
				}
				break;
			}
			if (found == 1)
				break;
		}
	}

    FREE(pMD5Password);
    FREE(pSHA256Password);
    FREE(pMD5SaltedPassword);
    FREE(pSHA256User);
    FREE(pSHA256SaltedPassword);

    if (found == 1)
        return RET_DBA_ERR_PASSWD_TOO_RECENT;
    else
        return RET_SUCCEED;
}


/************************************************************************
*   Function             : DBA_InsertPasswdHistory()
*
*   Description          :
*
*   Arguments            :
*
*   Functions call       :
*
*   Global var. modified :
*
*   Return               :
*
*
*   Creation Date        : 08.12.1999 - VST - REF4170.
*
*   Last Modif           : PMSTA-10235 - 190710 - PMO : Upgrade MD5 with new Salted H MD5 for password encryption for OCS and Triple'A
*                          PMSTA-18081 - 021214 - PMO : Support Salted SHA256 password encryption
*
*************************************************************************/
int DBA_InsertPasswdHistory(SYSNAME_T user_code, PasswordEncrypted& password, DbiConnectionHelper& dbiConnHelper) /* DLA - PMSTA09887 - 101115 */
{
    return DBI_InsertPasswdHistory(user_code, password, dbiConnHelper);

}

/************************************************************************
*   Function             : DBA_InsertPasswdHistory()
*
*   Description          :
*
*   Arguments            :
*
*   Functions call       :
*
*   Global var. modified :
*
*   Return               :
*
*
*   Creation Date        : 08.12.1999 - VST - REF4170.
*   Last Modif           : REF5010 - SSO - 000828
*************************************************************************/
int DBA_CheckExpiredPassword()
{
    return DBI_CheckExpiredPassword();
}

/************************************************************************
*   Function             : DBA_CheckMaxRunningGui()
*
*   Description          :
*
*   Arguments            :
*
*   Functions call       :
*
*   Global var. modified :
*
*   Return               :
*
*
*   Creation Date        : 08.12.1999 - VST - REF4170.
*   Last Modif           :
*************************************************************************/
int DBA_CheckMaxRunningGui()
{
    return DBI_CheckMaxRunningGui();
}

/************************************************************************
*   Function             : DBA_CleanLoginFailed()
*
*   Description          :
*
*   Arguments            :
*
*   Functions call       :
*
*   Global var. modified :
*
*   Return               :
*
*
*   Creation Date        : 08.12.1999 - VST - REF4170.
*   Last Modif           :
*************************************************************************/
int DBA_CleanLoginFailed()
{
    return DBI_CleanLoginFailed();
}

/************************************************************************
*   Function        : DBA_CreateOneTempTable()
*
*   Description     : Create one temporary tables
*                     Each tables are created if it's missing in the connection
*                     The table is truncate if it's already exist
*
*   Arguments       :   connectNo       pointer on connection number to use
*                       tmpTableMask    Mask of tables to create or truncate
*                                       if mask value is 0, no tables are created.
*
*   Return          :
*
*   Creation Date   : LJE - 140508
*
*   Last modif.     : PMSTA-21017 - 251015 - PMO : General small fix
*
*************************************************************************/
RET_CODE DBA_CreateOneTempTable(DbiConnection & dbiConn, int tmpTablesMask, unsigned int currTmpTable, vector<string>  &vCreateTempTableSql, bool &bExecute)
{
    RET_CODE           retCode             = RET_SUCCEED;
	const unsigned int connTempTablesMask  = dbiConn.m_tempTablesMask;

    bExecute = false;
    if ((tmpTablesMask & currTmpTable) == currTmpTable)
    {
        std::vector<std::string> tempTableNameVector;

        /* PMSTA-34344 - TEB - 190805 - generate for underlying database */
        switch (currTmpTable)
        {
            case WORK_HIER_LIST:
                tempTableNameVector.push_back("work_hier_list");
                break;

            case WORK_BLOCK_OP:
                tempTableNameVector.push_back("work_block_op");
                break;

            case DOM_OPER:
                tempTableNameVector.push_back("dom_oper");
                break;
            case DOM_POSITION_INSTR_PORT:
                tempTableNameVector.push_back("dom_position");
                tempTableNameVector.push_back("dom_pos");
                tempTableNameVector.push_back("dom_instr");
                tempTableNameVector.push_back("dom_port");

                tempTableNameVector.push_back("dom_port_nodup"); /* PMSTA-52924 - DDV - 230502 */
 				break;

            case OBJ_ID:
                tempTableNameVector.push_back("obj_id");
                break;


            case DOM_STRAT:
                tempTableNameVector.push_back("dom_strat");
                break;

            case TMP_OPER:
                tempTableNameVector.push_back("tmp_oper");
                break;

            case DOM_THIRD_CURR:
                tempTableNameVector.push_back("dom_third");
                tempTableNameVector.push_back("dom_curr");
                break;

            case DOM_LISTCOMPO:
                tempTableNameVector.push_back("dom_list_compo");
                break;

            case GRID_VECTOR:
                tempTableNameVector.push_back("grid_vector");
                break;

            case STRAT_MARKET:
                tempTableNameVector.push_back("strat_mark");
                break;

            case DOM_PARENT_STRAT:
                tempTableNameVector.push_back("dom_parent_strat");
                break;

            case TMP_STRAT_HIST:
                tempTableNameVector.push_back("tmp_strat_hist");
                break;

            case STRATEGY:
                tempTableNameVector.push_back("tmp_strategy");
                break;

            case ARCHIVE_DELOP_LISTOPENOPER:
                tempTableNameVector.push_back("tmp_archive");
                tempTableNameVector.push_back("delete_op");
                tempTableNameVector.push_back("list_open_oper_id");
                break;

            case SUBD_DOM_OPE:
                tempTableNameVector.push_back("dom_ope");
                break;

            case PORT_SYNTH:
                tempTableNameVector.push_back("port_synth");
                break;

            case TCT_VECTOR_ID:
                tempTableNameVector.push_back("vector_id");
                break;

            case TCT_DOM_PORT_FUS:
                tempTableNameVector.push_back("dom_port_fus");
                break;

            case TCT_FUS_TAB:
                tempTableNameVector.push_back("fus_tab");
                break;

            case DOM_PSP:
                tempTableNameVector.push_back("dom_psp");
                break;

            case IN_OBJECT:
                tempTableNameVector.push_back("in_object");
                break;

            case EXT_OP_LIST:
                tempTableNameVector.push_back("ext_op_list");
                break;

            case SCRIPT_DEF:
                tempTableNameVector.push_back("tmp_script_definition");
                break;

            case BUILD_LIST:
                tempTableNameVector.push_back("current_compo");
                tempTableNameVector.push_back("new_compo");
                break;

            case TT_TAXLOT_PROCESS:
                tempTableNameVector.push_back("taxlot_process");  /* PMSTA-34973 - 040319 - SGO */
                break;

            case TT_FORMAT:
                tempTableNameVector.push_back("tmp_format"); /* PMSTA-38117 - 090320 - KNI */
                break;

            case TT_HC_PTF_LIST:
                tempTableNameVector.push_back("hc_ptf_list"); /* PMSTA-39010 - 070520 - JJN */
                break;

			case TT_BUS_UNIT:    /* PMSTA-46366 - SRIDHARA - 13102021 */
                tempTableNameVector.push_back("bus_unit_links");
                tempTableNameVector.push_back("linked_hier_bus_units");
                tempTableNameVector.push_back("bus_units_data_profile");
				break;

            case TT_LIST_STRAT_LINK:
                tempTableNameVector.push_back("list_strat_link"); /* PMSTA-39010 - 070520 - JJN */
                break;

            default:
                assert(currTmpTable == ALL_TEMP_TABLES);
                return retCode;
        }

        for (auto& tempTableName : tempTableNameVector)
        {
            auto dictEntityStp = DBA_GetEntityBySqlName(tempTableName);

            string(*tempTblManagementFctPtr)(string, DBA_RDBMS_ENUM);

            if (DdlGenDbi::isTempTableRuntime(dbiConn.m_connectToRDBMS, dictEntityStp) &&
                (connTempTablesMask & currTmpTable) != currTmpTable)
            {
                tempTblManagementFctPtr = DBA_GetCreateTempTables;
            }
            else if (dbiConn.isInTransaction() ||
                     EV_AAAInstallLevel > 3 ||
                     dbiConn.getDescription().getModel() == QtHttp) /* PMSTA-34344 - TEB - 190319 */
            {
                tempTblManagementFctPtr = DBA_GetDeleteTempTables;
            }
            else
            {
                tempTblManagementFctPtr = DBA_GetTruncateTempTables;
            }

            vCreateTempTableSql.push_back(tempTblManagementFctPtr(tempTableName, dbiConn.m_connectToRDBMS));
        }

        if (vCreateTempTableSql.empty())
        {
            return retCode;
        }
    }
    return retCode;
}

/************************************************************************
*   Function        : DBA_InitCreateTempTables()
*
*   Description     : Create one or more temporary tables
*                     Each tables are created if it's missing in the connection
*                     The table is truncate if it's already exist
*                     See also DBA_CreateTempTables
*
*   Arguments       :
*
*   Return          :
*
*   Creation Date   : ORACLE - LJE - 141016
*
*   Last modif.     :
*
*************************************************************************/
RET_CODE DBA_InitCreateTempTables()
{
    RET_CODE                ret = RET_SUCCEED;

    if (SV_TempTableAvaible == false && EV_RdbmsDdlGen != QtHttp)       /* PMSTA-34344 - LJE - 201001 */
    {
        DBA_DYNFLD_STP 	       *data[] = { NULL, NULL };
        int            	        rows[] = { 0, 0, };

        DBA_RDBMS_ENUM saveRdbmsDdlGen = EV_RdbmsDdlGen;

        /* PMSTA-nuodb - LJE - 190411 */
        std::set<DBA_RDBMS_ENUM> rdbmsToLoad;
        rdbmsToLoad.insert(EV_RdbmsVendor);
        rdbmsToLoad.insert(EV_SourceRdbmsVendor);
        rdbmsToLoad.insert(EV_TargetRdbmsVendor);

        SV_TempTableCreateVector.resize(UnknownRdbms + 1);
        SV_TempTableDeleteVector.resize(UnknownRdbms + 1);
        SV_TempTableTruncateVector.resize(UnknownRdbms + 1);

        DbiConnectionHelper dbiConnHelper(AAATransactionEnum::NotTransactionnal, SqlServer, ROLE_INIT);

        if (dbiConnHelper.dbaMultiSelect(XdIndex,
                                         UNUSED,
                                         nullptr,
                                         data,
                                         rows) != RET_SUCCEED)
        {
            MSG_SendMesg(RET_DBA_ERR_SELECT_FAILED, 0, FILEINFO);
        }

        std::map<ID_T, std::map<ID_T, DBA_DYNFLD_STP>> xdIndexMapByXdEntity;
        std::map<ID_T, std::vector<DBA_DYNFLD_STP>>    xdIndexAttribMap;

        for (int i = 0; i < rows[0]; ++i)
        {
            xdIndexMapByXdEntity[GET_ID(data[0][i], A_XdIndex_XdEntityId)][GET_ID(data[0][i], A_XdIndex_Id)] = data[0][i];
        }
        for (int i = 0; i < rows[1]; ++i)
        {
            xdIndexAttribMap[GET_ID(data[1][i], A_XdIndexAttrib_XdIdxId)].push_back(data[1][i]);
        }

        for (OBJECT_ENUM objEn = 0; objEn < LASTOBJECT; objEn++)
        {
            DICT_ENTITY_STP         dictEntityStp = DBA_GetDictEntitySt(objEn);

            if (dictEntityStp != nullptr &&
                dictEntityStp->entNatEn == EntityNat_TempTable)
            {
               
                for (auto &rdbmsEn : rdbmsToLoad)
                {
                    auto tempTableSpec = DdlGenDbi::getTempTableSpec(rdbmsEn, dictEntityStp);
                    if (tempTableSpec == DdlGenDbi::TempTableSpec::Type)
                    {
                        continue;
                    }

                    EV_RdbmsDdlGen = rdbmsEn;

                    string createTableStr;
                    DdlGenContext ddlGenContext(rdbmsEn, true);
                    DdlGenTable ddlGenTable(objEn, TargetTable_Main, ddlGenContext, NULL, NULL);

                    if (DdlGenDbi::isTempTableRuntime(rdbmsEn, dictEntityStp))
                    {
                        createTableStr = ddlGenTable.getCreateCmd(true) + DdlGenDbi::endOfCmd(rdbmsEn);

                        auto xdIndexMap = xdIndexMapByXdEntity.find(dictEntityStp->xdEntityId);
                        if (xdIndexMap != xdIndexMapByXdEntity.end())
                        {
                            DdlGenEntity ddlGenEntity(dictEntityStp->mdSqlName, ddlGenContext);

                            ddlGenEntity.setExdIndexInfo(xdIndexMap->second, xdIndexAttribMap);
                            DdlGenIndex ddlGenIndex(objEn, ddlGenContext, &ddlGenEntity, TargetTable_Temp);

                            createTableStr += ddlGenIndex.getCreateCmd(true) + DdlGenDbi::endOfCmd(rdbmsEn);
                        }
                        SV_TempTableCreateVector[rdbmsEn].insert(pair<string, string>(dictEntityStp->mdSqlName, createTableStr));
                    }

                    createTableStr = ddlGenTable.getDeleteCmd();
                    SV_TempTableDeleteVector[rdbmsEn].insert(pair<string, string>(dictEntityStp->mdSqlName, createTableStr));

                    /* PMSTA-58084 - LJE - 240729 */
                    if (tempTableSpec != DdlGenDbi::TempTableSpec::MemoryOptimzed && SYS_GetEnvBoolOrDefValue("AAATRUNCATETEMPTB", true))
                    {
                        createTableStr = ddlGenTable.getTruncateCmd();
                    }
                    SV_TempTableTruncateVector[rdbmsEn].insert(pair<string, string>(dictEntityStp->mdSqlName, createTableStr));
                }
            }
        }

        DBA_FreeDynStTab(data[0], rows[0], A_XdIndex);
        DBA_FreeDynStTab(data[1], rows[1], A_XdIndexAttrib);

        EV_RdbmsDdlGen = saveRdbmsDdlGen;
        SV_TempTableAvaible = true;
    }
    return ret;
}


/************************************************************************
*   Function        : DBA_AddCreateTempTables()
*
*   Description     : Create one temporary tables
*
*   Arguments       :
*
*   Return          :
*
*   Creation Date   : PMSTA-49178 - LJE - 221017
*
*   Last modif.     :
*
*************************************************************************/
RET_CODE DBA_AddCreateTempTables(DICT_ENTITY_STP dictEntityStp, DBA_RDBMS_ENUM rdbmsDdlGen, const std::string &tempTableSqlName)
{
    RET_CODE               ret = RET_SUCCEED;

    DBA_RDBMS_ENUM saveRdbmsDdlGen = EV_RdbmsDdlGen;

    EV_RdbmsDdlGen = rdbmsDdlGen;

    DdlGenContextPtr ddlGenContextPtr(new DdlGenContext(rdbmsDdlGen, true));
    DdlGenTable::Ptr ddlGenTablePtr(new DdlGenTable(dictEntityStp->objectEn, TargetTable_Main, *ddlGenContextPtr, NULL, NULL));

    ddlGenTablePtr->realSqlName       = tempTableSqlName;
    ddlGenTablePtr->realDictEntityStp = dictEntityStp;
    ddlGenTablePtr->m_bForceTempTable = true;

    string createTableStr = ddlGenTablePtr->getCreateCmd(true) + DdlGenDbi::endOfCmd(rdbmsDdlGen);

    if (SV_TempTableCreateVector.size() < static_cast<size_t>(rdbmsDdlGen))
    {
        SV_TempTableCreateVector.resize(static_cast<size_t>(rdbmsDdlGen) + 1);
        SV_TempTableDeleteVector.resize(static_cast<size_t>(rdbmsDdlGen) + 1);
        SV_TempTableTruncateVector.resize(static_cast<size_t>(rdbmsDdlGen) + 1);
    }

    SV_TempTableCreateVector[rdbmsDdlGen].insert(pair<string, string>(dictEntityStp->mdSqlName, createTableStr));

    createTableStr = ddlGenTablePtr->getDeleteCmd();
    SV_TempTableDeleteVector[rdbmsDdlGen].insert(pair<string, string>(dictEntityStp->mdSqlName, createTableStr));

    createTableStr = ddlGenTablePtr->getTruncateCmd();
    SV_TempTableTruncateVector[rdbmsDdlGen].insert(pair<string, string>(dictEntityStp->mdSqlName, createTableStr));

    EV_RdbmsDdlGen = saveRdbmsDdlGen;
    return ret;
}

/************************************************************************
*   Function        : DBA_GetCreateTempTables()
*
*   Description     :
*
*   Arguments       :
*
*   Return          :
*
*   Creation Date   : ORACLE - LJE - 141016
*
*   Last modif.     :
*
*************************************************************************/
string DBA_GetCreateTempTables(string sqlName, DBA_RDBMS_ENUM rdbmsEn)
{
    map<string, string>::iterator it;
    it = SV_TempTableCreateVector[rdbmsEn].find(sqlName);

    if (it != SV_TempTableCreateVector[rdbmsEn].end())
    {
        return it->second;
    }
    return string();
}

/************************************************************************
*   Function        : DBA_GetDeleteTempTables()
*
*   Description     :
*
*   Arguments       :
*
*   Return          :
*
*   Creation Date   : PMSTA-18593 - LJE - 150520
*
*   Last modif.     :
*
*************************************************************************/
string DBA_GetDeleteTempTables(string sqlName, DBA_RDBMS_ENUM rdbmsEn)
{
    map<string, string>::iterator it;
    it = SV_TempTableDeleteVector[rdbmsEn].find(sqlName);

    if (it != SV_TempTableDeleteVector[rdbmsEn].end())
    {
        return it->second;
    }
    return string();
}

/************************************************************************
*   Function        : DBA_GetTruncateTempTables()
*
*   Description     :
*
*   Arguments       :
*
*   Return          :
*
*   Creation Date   : PMSTA-18593 - LJE - 150520
*
*   Last modif.     :
*
*************************************************************************/
string DBA_GetTruncateTempTables(string sqlName, DBA_RDBMS_ENUM rdbmsEn)
{
    map<string, string>::iterator it;
    it = SV_TempTableTruncateVector[rdbmsEn].find(sqlName);

    if (it != SV_TempTableTruncateVector[rdbmsEn].end())
    {
        return it->second;
    }
    return string();
}

/************************************************************************
*   Function        : DBA_CreateTempTables()
*
*   Description     : Create one or more temporary tables
*                     Each tables are created if it's missing in the connection
*                     The table is truncate if it's already exist
*                     See also DBA_CreateTempTables
*
*   Arguments       :   connectNo       pointer on connection number to use
*                       tmpTableMask    Mask of tables to create or truncate
*                                       if mask value is 0, no tables are created.
*                                       Valid bits mask values:
*                                           DOM_OPER
*                                           DOM_POSITION_INSTR_PORT
*                                           OBJ_ID
*                                           DOM_STRAT
*                                           TMP_OPER
*                                           DOM_THIRD_CURR
*                                           DOM_LISTCOMPO
*                                           GRID_VECTOR
*                                           STRAT_MARKET
*                                           DOM_PARENT_STRAT
*                                           TMP_STRAT_HIST
*                                           STRATEGY
*                                           TCT_VECTOR_ID       Processing of the temporary table #vector_id
*                                           TCT_DOM_PORT_FUS    Processing of the temporary table #dom_port_fus
*                                           TCT_FUS_TAB         Processing of the temporary table #fus_tab
*                                           DOM_PSP             Processing of the temporary table #dom_psp
*                                           IN_OBJECT           Processing of the temporary table #in_object
*
*   Return          :
*
*   Creation Date   : 000124 - DDV - REF2467
*
*   Last modif.     : REF7560 - 020712 - PMO : Order Management Entity light project: database infrastructure
*                     REF9686 - TEB - 040220
*                     PMSTA-16327 - 060513 - PMO : F2B - Global Order. Impossible to Detach/Delete Child Order when selecting more than one Child Order
*
*************************************************************************/
RET_CODE DBA_CreateTempTables(int * connectNo, int tmpTablesMask)
{
	DbiConnection* dbiConn = DBA_GetDbiConnFromConnectNo(*connectNo);
	if (dbiConn == nullptr){
		return RET_DBA_ERR_CONNOTFOUND;
	}
	return DBA_CreateTempTables(*dbiConn, tmpTablesMask);
}

/************************************************************************
*   Function        : DBA_CreateTempTables()
*
*   Description     : Create one or more temporary tables
*                     Each tables are created if it's missing in the connection
*                     The table is truncate if it's already exist
*                     See also DBA_CreateTempTables
*
*   Arguments       :   connectNo       pointer on connection number to use
*                       tmpTableMask    Mask of tables to create or truncate
*                                       if mask value is 0, no tables are created.
*                                       Valid bits mask values:
*                                           DOM_OPER
*                                           DOM_POSITION_INSTR_PORT
*                                           OBJ_ID
*                                           DOM_STRAT
*                                           TMP_OPER
*                                           DOM_THIRD_CURR
*                                           DOM_LISTCOMPO
*                                           GRID_VECTOR
*                                           STRAT_MARKET
*                                           DOM_PARENT_STRAT
*                                           TMP_STRAT_HIST
*                                           STRATEGY
*                                           TCT_VECTOR_ID       Processing of the temporary table #vector_id
*                                           TCT_DOM_PORT_FUS    Processing of the temporary table #dom_port_fus
*                                           TCT_FUS_TAB         Processing of the temporary table #fus_tab
*                                           DOM_PSP             Processing of the temporary table #dom_psp
*                                           IN_OBJECT           Processing of the temporary table #in_object
*
*   Return          :
*
*   Creation Date   : 000124 - DDV - REF2467
*
*   Last modif.     : REF7560 - 020712 - PMO : Order Management Entity light project: database infrastructure
*                     REF9686 - TEB - 040220
*                     PMSTA-16327 - 060513 - PMO : F2B - Global Order. Impossible to Detach/Delete Child Order when selecting more than one Child Order
*                     PMSTA-21017 - 251015 - PMO : General small fix
*
*************************************************************************/
RET_CODE DBA_CreateTempTables(DbiConnection & dbiConn, int tmpTablesMask)
{
    RET_CODE    retCode = RET_SUCCEED,
                ret;
    int         currTempTable = 0;

    if (SV_TempTableAvaible)
    {
        unsigned int newTempTablesMask = dbiConn.m_tempTablesMask;
        DBI_INT      status = 0;

        vector<string>  vCreateTempTableSql;

        RequestHelper requestHelper(&dbiConn);
        requestHelper.setReadOnly(true);

        const AAALogger& sqlTraceLog = AAALogger::get(AAALogger::Logger::SqlTrace);
        while (SV_AllTempTablesTab[currTempTable] != ALL_TEMP_TABLES)
        {
            bool            bExecute = false;
            ret = DBA_CreateOneTempTable(dbiConn, tmpTablesMask, SV_AllTempTablesTab[currTempTable], vCreateTempTableSql, bExecute);

            if (ret != RET_SUCCEED)
            {
                retCode = ret;
            }
            else if (bExecute)
            {
                for (vector<string>::iterator it = vCreateTempTableSql.begin(); it != vCreateTempTableSql.end(); ++it)
                {
                    if (it->empty() == false)
                    {
                        if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
                        {
                            auto &sqlTrace = dbiConn.getSqlTrace();
                            sqlTrace.m_procedure = "DynSql.CreateTempTables";
                        }

                        retCode = dbiConn.sqlExecSt(it->c_str(), &status);
                    }
                }
                vCreateTempTableSql.clear();
            }
            newTempTablesMask |= SV_AllTempTablesTab[currTempTable];

            currTempTable++;
        }

        if (vCreateTempTableSql.empty() == false)
        {
            DdlGenSqlBlock cmdCreateTmpTb;

            for (vector<string>::iterator it = vCreateTempTableSql.begin(); it != vCreateTempTableSql.end(); ++it)
            {
                if (it->empty() == false)
                {
                    cmdCreateTmpTb << *it;
                }
            }
            DdlGenDbi::finishSqlBlock(cmdCreateTmpTb, dbiConn.m_connectToRDBMS, DdlObj_TempTable);                /* PMSTA-34344 - TEB - 190805 */

            if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
            {
                auto &sqlTrace = dbiConn.getSqlTrace();
                sqlTrace.m_procedure = "DynSql.CreateTempTables";
            }

	        retCode = dbiConn.sqlExecSt(cmdCreateTmpTb.str().c_str(), &status);

	        if (retCode == RET_SUCCEED)
	        {
	            dbiConn.m_tempTablesMask = newTempTablesMask;
	        }
        }
    }
    else if (dbiConn.getDbaRDBMS() != QtHttp)
    {
        retCode = RET_GEN_INFO_NOACTION;
    }

    return retCode;
}

/************************************************************************
*   Function        : DBA_InitDictUserMap()
*
*   Description     :
*
*   Arguments       :
*
*   Return          :
*
*   Creation Date   : PMSTA-28698 - LJE - 180523
*
*   Last modif.     :
*
*************************************************************************/
RET_CODE DBA_InitDictUserMap()
{
    RET_CODE                ret = RET_SUCCEED;

    DbiConnectionHelper     connHelper;
    DBA_DYNFLD_STP         *dictUserTab;
    int                     dictUserNbr;

    if (connHelper.dbaSelect(DictUser, UNUSED, nullptr, A_DictUser, &dictUserTab, &dictUserNbr) != RET_SUCCEED)
    {
        ret = RET_DBA_ERR_SELECT_FAILED;
        MSG_SendMesg(ret, 0, FILEINFO);
        return ret;
    }

    for (int i = 0; i < dictUserNbr; ++i)
    {
        AaaMetaDict::getDictUserMap().insert(make_pair(GET_SYSNAME(dictUserTab[i], A_DictUser_UserName), dictUserTab[i]));
    }

    FREE(dictUserTab);

    return ret;
}

/************************************************************************
**
**  Function    :   DBA_IsDboUser()
**
**  Description :   Verify that the given user is a database owner
**
**  Arguments   :
**
**  Return      :   RET_SUCCEED                   If the user is DBO.
**                  RET_MEM_ERR_ALLOC             Memory allocation problems.
**                  RET_GEN_INFO_NOACTION         Not a DBO user
**
**  Creation    :   PMSTA-28698 - LJE - 180523
**
**  Last modif. :   PMSTA-46404 - DDV - 211005 - Remove status parameter in dbaCheck
**
*************************************************************************/
bool DBA_IsDboUser(DbiConnection *dbiConn)
{
    RET_CODE ret = RET_GEN_INFO_NOACTION;

    if (AaaMetaDict::getDictUserMap().empty())
    {
        MemoryPool     mp;
        DBA_DYNFLD_STP userArg      = mp.allocDynst(FILEINFO, Chk_Arg);

        if (dbiConn != nullptr)
        {
            DbiConnectionHelper connHelper(dbiConn, false);

            if (connHelper.dbaCheck(DictUser, UNUSED, userArg) == RET_SUCCEED && GET_INT(userArg, Chk_Arg_ReturnStatus) == 0) /* PMSTA-46404 - DDV - 211005 */
            {
                ret = RET_SUCCEED;
            }
        }
        else
        {
            DbiConnectionHelper connHelper(AAATransactionEnum::NotTransactionnal, DBA_SERVER_TYPE_ENUM::SqlServer, ROLE_ADMIN);

            if (connHelper.dbaCheck(DictUser, UNUSED, userArg) == RET_SUCCEED && GET_INT(userArg, Chk_Arg_ReturnStatus) == 0) /* PMSTA-46404 - DDV - 211005 */
            {
                ret = RET_SUCCEED;
            }
        }
    }
    else
    {
        return DBA_IsDboUser(dbiConn ? dbiConn->getDescription().getUser() : SYS_GetThreadUser());
    }

    return (ret == RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   DBA_IsTascTechUser()
**
**  Description :   Verify that the given user is a tasc tech group
**
**  Arguments   :
**
**  Return      :   TRUE     If the user belong tasc tech group.
**                  FALSE    The user don't belong tasc tech group.
**
**  Creation    :   PMSTA-28698 - LJE - 180523
**
**  Last modif. :
**
*************************************************************************/
bool DBA_IsTascTechUser()
{
    return DBA_IsTascTechUser(SYS_GetThreadUser());
}

/************************************************************************
**
**  Function    :   DBA_IsDboUser()
**
**  Description :   Verify that the given user is a database owner
**
**  Arguments   :
**
**  Return      :   RET_SUCCEED                   If the user is DBO.
**                  RET_MEM_ERR_ALLOC             Memory allocation problems.
**                  RET_GEN_INFO_NOACTION         Not a DBO user
**
**  Creation    :   PMSTA-37366 - LJE - 200429
**
**  Last modif. :
**
*************************************************************************/
bool DBA_IsDboUser(const std::string &user)
{
    auto dictUserIt = AaaMetaDict::getDictUserMap().find(user);

    if (dictUserIt != AaaMetaDict::getDictUserMap().end() &&
        GET_FLAG(dictUserIt->second, A_DictUser_ApplOwnerFlg) == TRUE)
    {
        return true;
    }
    return false;
}

/************************************************************************
**
**  Function    :   DBA_IsTascTechUser()
**
**  Description :   Verify that the given user is a tasc tech group
**
**  Arguments   :
**
**  Return      :   TRUE     If the user belong tasc tech group.
**                  FALSE    The user don't belong tasc tech group.
**
**  Creation    :   PMSTA-37366 - LJE - 200429
**
**  Last modif. :
**
*************************************************************************/
bool DBA_IsTascTechUser(const std::string &user)
{
    auto dictUserIt = AaaMetaDict::getDictUserMap().find(user);

    if (dictUserIt != AaaMetaDict::getDictUserMap().end() &&
        GET_FLAG(dictUserIt->second, A_DictUser_TechnicalFlg) == TRUE)
    {
        return true;
    }

    return false;
}

/************************************************************************
**
**  Function    :   DBA_GetDboUser()
**
**  Description :   Get the user database owner
**
**  Arguments   :
**
**  Return      :   
**
**  Creation    :   PMSTA-34344 - LJE - 201218
**
**  Last modif. :
**
*************************************************************************/
void DBA_GetDboUser(std::string &user)
{
    for (auto dictUserIt = AaaMetaDict::getDictUserMap().begin(); dictUserIt != AaaMetaDict::getDictUserMap().end(); ++dictUserIt)
    {
        if (GET_FLAG(dictUserIt->second, A_DictUser_ApplOwnerFlg) == TRUE)
        {
            user = GET_SYSNAME(dictUserIt->second, A_DictUser_UserName);
            return;
        }
    }
    return;
}

/************************************************************************
**
**  Function    :   DBA_GetTascTechUser()
**
**  Description :   Get the user the tasc tech group
**
**  Arguments   :
**
**  Return      :   
**
**  Creation    :   PMSTA-34344 - LJE - 201218
**
**  Last modif. :
**
*************************************************************************/
void DBA_GetTascTechUser(std::string &user)
{
    for (auto dictUserIt = AaaMetaDict::getDictUserMap().begin(); dictUserIt != AaaMetaDict::getDictUserMap().end(); ++dictUserIt)
    {
        if (GET_FLAG(dictUserIt->second, A_DictUser_TechnicalFlg) == TRUE &&
            strcmp(GET_SYSNAME(dictUserIt->second, A_DictUser_GroupName), "tasc_tech") == 0)
        {
            user = GET_SYSNAME(dictUserIt->second, A_DictUser_UserName);
            return;
        }
    }
    return;
}

/************************************************************************
**
**  Function    :   DBA_GetProxyUser()
**
**  Description :   Get the user the proxy group
**
**  Arguments   :
**
**  Return      :
**
**  Creation    :   PMSTA-34344 - LJE - 201218
**
**  Last modif. :
**
*************************************************************************/
void DBA_GetProxyUser(std::string &user)
{
    for (auto dictUserIt = AaaMetaDict::getDictUserMap().begin(); dictUserIt != AaaMetaDict::getDictUserMap().end(); ++dictUserIt)
    {
        if (GET_FLAG(dictUserIt->second, A_DictUser_TechnicalFlg) == TRUE &&
            strcmp(GET_SYSNAME(dictUserIt->second, A_DictUser_GroupName), "triplea") == 0)
        {
            user = GET_SYSNAME(dictUserIt->second, A_DictUser_UserName);
            return;
        }
    }
    return;
}

/************************************************************************
*   Function             : DBA_IsSubscriptionActive()
*
*   Description          : Replace DBA_IsTrustedObject and get information
*                          about subscription in MD (dict_entity.audit_e)
*
*   Arguments            : object to check
*
*
*   Return               :
*
*   Creation Date        : 121128 - DDV - PMSTA-15199
*   Last Modif           :
*************************************************************************/
FLAG_T DBA_IsSubscriptionActive(OBJECT_ENUM object)
{
    DICT_ENTITY_STP dictEntityStp = NULL;

    if ((dictEntityStp = DBA_GetDictEntitySt(object)) != NULL &&
        dictEntityStp->auditAuthEn == FeatureAuth_Enable)
        return(TRUE);
    else
        return(FALSE);
}

/************************************************************************
*   Function             : DBA_GetFinancialServerVersion()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        : 020327 - PCL - REF4333.1
*
*   Last modif.          : PMSTA-24510 - 220816 - PMO : Fusion & Dispatcher in HTTP
*
*************************************************************************/
RET_CODE DBA_GetFinancialServerVersion(DBA_DYNFLD_STP getVersionSt)
{
    return DBI_GetFinancialServerVersionEx(getVersionSt);  /* PMSTA-24510 - 220816 - PMO / PMSTA15386-JPP-121128*/
}


/************************************************************************
*   Function             : DBA_GetFinancialServerFileEx()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        : 020626 - PCL - REF4333.5
*************************************************************************/
#ifdef NT
#pragma warning(disable:4554)   /* avoid stupid compiler issuing stupid message */
#endif

RET_CODE DBA_GetFinancialServerFileEx(DbiConnectionHelper & dbiConnHelper,
    const char *name, LogModeEn enTextMode, int size,
        int (*callback)(int, void *, void *), void *pointer, char *server)
{
    /*lint --e{644} avoid stupid tool issuing stupid message */

    RET_CODE
        status = RET_SUCCEED;

    int count;

    DBA_DYNFLD_STP   input = NULL;
    DBA_DYNFLD_STP *output = NULL;

    if ((input = ALLOC_DYNST(GetFile_I)) != NULL)
    {
        SET_NOTE(
            input, GetFile_I_Name, name);

        SET_FLAG(
            input, GetFile_I_Text, enTextMode == LogModeEn::Text ? TRUE : FALSE);

        SET_INT(
            input, GetFile_I_Size, size);

        /*
        OBJECT_ENUM    object,
                                    int            role,
                                    DBA_DYNFLD_STP inputData,
                                    DBA_DYNST_ENUM outputDynStEnum,
                                    DBA_DYNFLD_STP **outputData,
                                    int            *resultRows)*/
        if ((status = dbiConnHelper.dbaSelect(Technical,
                                                    UNUSED,
                                                    input,
                                                    GetFile_O,
                                                    &output,
                                                    &count)) == RET_SUCCEED)
        {
            char *buffer = NULL;

            int i;
            int j;

            int offset = 0;
            int abort  = 0;

            int ascii = 0;
            int level = 0;

            i = 0;

            if ((buffer = (char *)
                        REALLOC(buffer, 4096)) != NULL)
            {
                int buffSize = 4096;

                memset(
                    buffer, 0, 4096);

                while (i < count && !abort)
                {
                    int length =
                        GET_INT (output[i], GetFile_O_Size);

                    char *data =
                        GET_INFO(output[i], GetFile_O_Data);

                    j = 0;

                    while (j < length && !abort)
                    {
                        int character = data[j];

                        if (enTextMode == LogModeEn::Text)
                        {
                            switch (level)
                            {
                                    case 0:

                                        if (character != '\\')
                                            ascii = character;
                                        else
                                            level++;

                                        break;

                                    case 1:

                                        if (character == '\\')
                                        {
                                            ascii =
                                                character;

                                            level = 0;
                                        }
                                        else
                                        {
                                            ascii =
                                                character - 48 << 6;

                                            level++;
                                        }

                                        break;

                                    case 2:

                                        ascii +=
                                            character - 48 << 3;

                                        level++;

                                        break;

                                    case 3:

                                        ascii +=
                                            character - 48 << 0;

                                        level = 0;

                                    break;
                            }
                        }
                        else
                        {
                            if (!level)
                            {
                                ascii =
                                    character < 'A' ?
                                        character - 48 << 4 : character - 55 << 4;

                                level = 1;
                            }
                            else
                            {
                                ascii +=
                                    character < 'A' ?
                                        character - 48 << 0 : character - 55 << 0;

                                level = 0;
                            }
                        }

                        if (!level)
                        {
                            if (enTextMode == LogModeEn::Text && offset + 1 == buffSize)
                            {
                                char *transient;

                                if ((transient = (char *)
                                            REALLOC(buffer, buffSize += 4096)) != NULL)
                                {
                                    buffer = transient;

                                    memset(
                                        buffer + (offset + 1), 0, 4096);
                                }
                                else
                                {
                                    FREE(
                                        buffer);

                                    abort = 1;
                                }
                            }

                            if (!abort)
                            {
                                buffer[offset++] = (char)ascii;

                                if (enTextMode == LogModeEn::Text && ascii == '\n' ||
                                        i == count - 1 && j == length - 1)
                                {
                                    if (!callback(offset, buffer, pointer))
                                    {
                                        memset(
                                            buffer, 0, buffSize);

                                        offset = 0;
                                    }
                                    else
                                    {
                                        FREE(
                                            buffer);

                                        abort = 1;
                                    }
                                }
                                else
                                if (enTextMode == LogModeEn::Binary && offset == 4096 ||
                                        i == count - 1 && j == length - 1)
                                {
                                    if (!callback(offset, buffer, pointer))
                                    {
                                        memset(
                                            buffer, 0, buffSize);

                                        offset = 0;
                                    }
                                    else
                                    {
                                        FREE(
                                            buffer);

                                        abort = 1;
                                    }
                                }

                            }
                            else
                                status = RET_MEM_ERR_ALLOC;
                        }

                        j++;
                    }

                    i++;
                }

                if (!abort)
                    FREE(buffer);
            }
            else
                status = RET_MEM_ERR_ALLOC;

            DBA_FreeDynStTab(output, count, GetFile_O);
        }
        else
            status = RET_DBA_ERR_DIALOG;
        FREE_DYNST(input, GetFile_I);		/* MRA - 021129 - REF8405 */
    }
    else
        status = RET_MEM_ERR_ALLOC;

    return status;
}


/************************************************************************
*   Function             : DBA_GetFinancialServerFile()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        : 020417 - PCL - REF4333.2
*************************************************************************/
RET_CODE DBA_GetFinancialServerFile(DbiConnectionHelper & dbiConnHelper,
                                    const char *name, LogModeEn enTextMode, int size,
                                    int (*callback)(int, void *, void *), void *pointer)
{
    return
        DBA_GetFinancialServerFileEx(dbiConnHelper,
            name, enTextMode, size, callback, pointer, NULL);
}

/************************************************************************
*   Function             : DBA_DispatcherRecoveringFusionConnection()
*
*   Description          : Avoid leaks of connections in a bad state
*
*   Arguments            : The server name
*
*   Return               : None
*
*   Creation Date        : PMSTA-10140 - 041110 - PMO : When they launch the first fusion after a start of the financial server, they have this error message in log file
*************************************************************************/
void DBA_DispatcherRecoveringFusionConnection(const char *)
{
}

/************************************************************************
*   Function             : DBA_CloseDbiSrvConnection()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        : 020626 - PCL - REF4333.5
*************************************************************************/
int DBA_CloseDbiSrvConnection(DbiConnection * dbiConn)
{
	AAALocalConnectionProvider::get().release(dbiConn);
	return RET_SUCCEED;
}



/************************************************************************
*   Function             : DBA_GetLocalFile()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        : 020723 - PCL - REF4333.2
*************************************************************************/
RET_CODE DBA_GetLocalFile(
    char *name, LogModeEn enTextMode, int size,
        int (*callback)(int, void *, void *), void *pointer)
{
        /*lint --e{644} avoid stupid tool issuing stupid message */

    int status = RET_SUCCEED;
    int handle;

#ifdef NT
    if ((handle = open(name, O_RDONLY | O_BINARY)) != -1)
#else
    if ((handle = open(name, O_RDONLY           )) != -1)
#endif
    {
        struct stat informations;

        if (fstat(handle, &informations) != -1 &&
                (informations.st_mode & S_IFMT) == S_IFREG)
        {
            long offset = 0L;
            long length = lseek(handle, 0 , SEEK_END);

            if (size)
            {
                if (enTextMode == LogModeEn::Binary)
                {
                    if (size > 0)
                    {
                        if (size < length)
                            length = size;
                    }
                    else
                    {
                        size = -size;

                        if (size < length)
                        {
                            offset =
                                length - size;

                            length = size;
                        }
                    }
                }
                else
                {
                    char buffer[4096];
                    long index          = 0L;

                    if (size > 0)
                    {
                        while (size && index < length)
                        {
                            const long locOffset = index % 4096;

                            if (locOffset == 0)
                            {
                                const long count = length - index < 4096 ? length - index : 4096;

                                if (lseek(handle, index, SEEK_SET) == -1)
                                    break;

                                if (read(handle, buffer, count) != count)
                                    break;
                            }

                            if (buffer[locOffset] == '\n')
                                size--;

                            index++;
                        }

                        if (!size || index == length)
                        {
                            if (!size)
                                length = index;
                        }
                        else
                            status = RET_FILE_ERR_IO;
                    }
                    else
                    {
                        size  = -size;
                        index = length - 1;

                        while (size && index >= 0)
                        {
                            const long locOffset = index % 4096;

                            if (locOffset == 4095 || index == length - 1)
                            {
                                const long  base    = index - locOffset;
                                const long  count   = length - base < 4096 ? length - base : 4096;

                                if (lseek(handle, base, SEEK_SET) == -1)
                                    break;

                                if (read(handle, buffer, count) != count)
                                    break;
                            }

                            if (buffer[locOffset] == '\n' && index != length - 1)
                                size--;

                            index--;
                        }

                        if (!size || index < 0)
                        {
                            if (!size)
                            {
                                offset = index + 2;

                                length -= offset;
                            }
                        }
                        else
                            status = RET_FILE_ERR_IO;
                    }
                }
            }

            if (status == RET_SUCCEED)
            {
                if (lseek(handle, offset, SEEK_SET) != -1)
                {
                    char    buffer[4096];
                    long    index   = 0L;
                    int     abort   = 0;
                    long    count;
                    char *  line    = nullptr;
                    int     buffSize = 0;

                    while (index < length && status == RET_SUCCEED && !abort)
                    {
                        char *  transient;
                        int     n;

                        count =
                            length - index < 4096 ?
                                length - index : 4096;

                        if (read(handle, buffer, count) == count)
                        {
                            if (enTextMode == LogModeEn::Text)
                            {
                                for (n = 0; n < count && status == RET_SUCCEED && !abort ; n++)
                                {
                                    if (line == NULL || (buffSize + 1) % 4096 == 0)
                                    {
                                        int locLength = ((buffSize + 1) / 4096 + 1) * 4096;

                                        if ((transient = (char *)
                                                    REALLOC(line, locLength)) != NULL)
                                        {
                                            line = transient;

                                            memset(
                                                line + locLength - 4096, 0, 4096);
                                        }
                                        else
                                            status =
                                                RET_MEM_ERR_ALLOC;
                                    }

                                    if (status == RET_SUCCEED)
                                    {
                                        if (buffer[n] == '\n')
                                        {
                                            if (buffSize && line[buffSize - 1 ] == '\r' )
                                                line[buffSize - 1] = '\n';
                                            else
                                                line[buffSize++  ] = '\n';

                                            if (callback(buffSize, line, pointer))
                                                abort = 1;

                                            FREE(line);

                                            buffSize = 0   ;
                                            line = NULL;
                                        }
                                        else
                                            line[buffSize++] = buffer[n];
                                    }
                                }
                            }
                            else
                            {
                                if (callback(count, buffer, pointer))
                                    abort = 1;
                            }

                            index += count;
                        }
                        else
                            status = RET_FILE_ERR_IO;
                    }

                    if (index == length)
                    {
                        if (enTextMode == LogModeEn::Text && status == RET_SUCCEED && !abort)
                        {
                            if (buffSize)
                                callback(buffSize, line, pointer);
                        }
                    }

                    if (line != NULL)
                        FREE(line);
                }
                else
                    status = RET_FILE_ERR_IO;
            }
            else
                status = RET_FILE_ERR_IO;
        }
        else
            status = RET_FILE_ERR_IO;

        close(handle);
    }
    else
        status = RET_FILE_ERR_IO;

    return status;
}

/************************************************************************
**
** Function    : DBA_FillLogData
**
** Description : Fill A_Log_Text
**
** Arguments   :
**
** Return      :
**
** Creation    : MRA - 020711 - REF4333.2
**
** Last modif  : PMSTA-33762 - DLA - 181123
**
************************************************************************/
RET_CODE   DBA_FillLogData(int size, char *data, DBA_DYNFLD_ST *aLog)
{
    if((data == NULL) || (aLog == NULL))
        MSG_RETURN(RET_GEN_ERR_INVARG);

    if (IS_NULLFLD(aLog, A_Log_Text) == FALSE)
    {
        std::string text(GET_TEXT(aLog, A_Log_Text));
        text.append(data);
        SET_TEXT(aLog, A_Log_Text, text.c_str());
    }
    else
    {
        SET_TEXT(aLog, A_Log_Text, data);
    }

    return 0;

}

STATIC RET_CODE DBI_GetFinancialServerEnvironmentEx(DbiConnectionHelper & dbiConnHelper, std::map<std::string, std::string> &environmentMap, const char * server)
{
    RET_CODE              ret = RET_ENV_ERR_VARUNDEF;
    DBA_DYNFLD_STP        *getEnvArgTab = nullptr;
    int                   rowNbr = 0;

    ret = dbiConnHelper.dbaSelect(Technical, DBA_ROLE_GETENV, nullptr, GetSrvEnv_Arg, &getEnvArgTab, &rowNbr);
    for (int i = 0; i < rowNbr; i++)
    {
        string envVar = GET_NOTE(getEnvArgTab[i], GetSrvEnv_Arg_Environment);
        string envKey = envVar.substr(0, envVar.find("="));
        string envVal = envVar.substr(envKey.size()+1);

        environmentMap.insert(make_pair(envKey, envVal));
    }
    return ret;
}

/************************************************************************
**
** Function    : DBA_GetAllLog
**
** Description : Get All Log
**
** Arguments   :
**
** Return      :
**
** Creation    : MRA - 020709 - REF4333.2
**
** Last modif  : PMSTA-33762 - DLA - 181123
**
************************************************************************/
RET_CODE   DBA_GetAllLog(OBJECT_ENUM            ,
                        DBA_DYNFLD_STP          aLog,
                        DBA_DYNFLD_STP*         ,
                        DbiConnectionHelper &   )
{
    RET_CODE    ret = RET_SUCCEED;
    const       LogTypeEn         type_e = static_cast <LogTypeEn> (GET_ENUM(aLog, A_Log_TypeEn));
    const       LogSelectedLineEn selectedLine_e = static_cast <LogSelectedLineEn> (GET_ENUM(aLog, A_Log_SelectedLineEn));
    NUMBER_T    lineNb = GET_NUMBER(aLog, A_Log_Line);

    SET_NULL_TEXT(aLog, A_Log_Text);

    switch (selectedLine_e)
    {
        case LogSelectedLineEn::All :
            SET_NUMBER(aLog, A_Log_Line, 0);
            lineNb = 0;
            break;
        case LogSelectedLineEn::First :
            break;
        case LogSelectedLineEn::Last :
            lineNb = 0 - lineNb;
            break;
    }

    if (type_e == LogTypeEn::GUI)
    {
        char *aaaLogPtr = getenv("AAALOG");
        SET_NOTE(aLog, A_Log_FileName, aaaLogPtr);

        if (EV_WarningMsg == TRUE)
        {
            SET_ENUM(aLog, A_Log_WarningLevelEn, static_cast <ENUM_T> (LogWarningLevelEn::WarningAndError));
        }
        else
        {
            SET_ENUM(aLog, A_Log_WarningLevelEn, static_cast <ENUM_T> (LogWarningLevelEn::Error));
        }
        if ((ret = DBA_GetLocalFile(aaaLogPtr, LogModeEn::Text, (int) lineNb, (int (*)(int,void*,void*))DBA_FillLogData, aLog)) != RET_SUCCEED)
            return(ret);
    }
    else
    {
        std::map<std::string, std::string>  environmentMap;
        char                               *servName = NULL;

        string                              aaalogthreshold;
        string                              aaalog;
        string                              aaalogKey;

        if (IS_NULLFLD(aLog, A_Log_ServerName) == FALSE)
        {
            servName = GET_SYSNAME(aLog, A_Log_ServerName);
        }

        DbiConnectionHelper * dbiConnHelperPtr = nullptr;

        if (servName == nullptr)
        {
            dbiConnHelperPtr = new DbiConnectionHelper(FinServer);
        }
        else
        {
            dbiConnHelperPtr = new DbiConnectionHelper(servName);
        }

        if (dbiConnHelperPtr != nullptr)
        {
            if (((ret = DBI_GetFinancialServerEnvironmentEx(*dbiConnHelperPtr, environmentMap, servName)) != RET_SUCCEED) || environmentMap.empty())
            {
                MSG_DispMesg(ret, NULL, NULL);
                delete (dbiConnHelperPtr);
                return ret;
            }

            switch (type_e)
            {
                case LogTypeEn::GUI:                                            break;
                case LogTypeEn::SRV:            aaalogKey = "AAALOG";           break;
                case LogTypeEn::ServerLog:      aaalogKey = "AAASRVLOG";        break;
                case LogTypeEn::Packager:       aaalogKey = "AAAPACKAGERLOG";   break;
            }

            auto aaalogthresholdIt = environmentMap.find("AAALOGTHRESHOLD");
            if (aaalogthresholdIt != environmentMap.end())
            {
                aaalogthreshold = aaalogthresholdIt->second;
            }
            auto aaalogIt = environmentMap.find(aaalogKey);
            if (aaalogIt != environmentMap.end())
            {
                aaalog = aaalogIt->second;
                SET_NOTE(aLog, A_Log_FileName, aaalog.c_str());     /* PMSTA-43576 - JOS - 12022021 */
            }

            if (aaalogthreshold.empty())
            {
                if (EV_WarningMsg == TRUE)
                {
                    SET_ENUM(aLog, A_Log_WarningLevelEn, static_cast <ENUM_T> (LogWarningLevelEn::WarningAndError));
                }
                else
                {
                    SET_ENUM(aLog, A_Log_WarningLevelEn, static_cast <ENUM_T> (LogWarningLevelEn::Error));
                }
            }
            else
            {
                if (aaalogthreshold.compare("WARNING") == 0)
                {
                    SET_ENUM(aLog, A_Log_WarningLevelEn, static_cast <ENUM_T> (LogWarningLevelEn::WarningAndError));
                }
                else if (aaalogthreshold.compare("ERROR") == 0)
                {
                    SET_ENUM(aLog, A_Log_WarningLevelEn, static_cast <ENUM_T> (LogWarningLevelEn::Error));
                }
            }

            ret = DBA_GetFinancialServerFileEx(*dbiConnHelperPtr,aaalog.c_str(), LogModeEn::Text, (int)lineNb,
                                               (int(*)(int, void*, void*))DBA_FillLogData, aLog, servName);

            delete (dbiConnHelperPtr);
        }
        else
        {
            ret = RET_MEM_ERR_ALLOC;
        }
    }
    return(ret);
}


/************************************************************************
**
** Function    : DBA_GetOpIdFromExtOp
**
** Description : Return the id of database id or operation id or draft order id from extOp
**               See also OPE_GetOpIdFromExtOpPriorityOperation, OPE_GetOpIdFromDynFld
**               They are only two possibles case :
**                  1) the field draft order id is present
**                  2) field dbid or operation id. If no one is present, return 0
**
** Arguments   : extOp      ExtOp used to extract the correct id
**
** Return      : draft order id     if draft order id is present
**               database id        if database id is present
**               operation id       if database id is null
**               0                  if database id is null and operation id is null and draft order id is null
**
** Creation    : REF7560 - 020725 - PMO : Order Managament Entity light project: database infrastructure
** Last modif. : REF8500 - 040510 - PMO : Add a draft_order_id in extended operation to distinguish
**                                        the id from extended orders and the one from extended operation
**
************************************************************************/
ID_T DBA_GetOpIdFromExtOp(const DBA_DYNFLD_STP extOp)
{
    ID_T operationId;   /* Return value, Operation id or db id */

    /* Check for draft order id */
    if (TRUE == IS_NULLFLD(extOp, ExtOp_DraftOrderId))
    { /* database id or operation id*/

        /* Check for database id */
        if (FALSE == IS_NULLFLD(extOp, ExtOp_DbId))
        { /* Yes */
            /* Set the id of operation with the database_id of extOp */
            operationId = GET_ID(extOp, ExtOp_DbId);
        }
        else
        { /* No */

            /* Check for operation id */
            if (FALSE == IS_NULLFLD(extOp, ExtOp_OpId))
            { /* Yes */
                /* Set the id of operation with the operation_id of extOp */
                operationId = GET_ID(extOp, ExtOp_OpId);
            }
            else
            { /* No */
                /* Set the id of operation with 0 */
                operationId = 0;
            }
        }
    }
    else
    { /* draft order id */
        operationId = GET_ID(extOp, ExtOp_DraftOrderId);
    }

    return operationId;
}


/************************************************************************
**
** Function    : IS_EXTOP_DATABASE_ID_MISSING
**
** Description : Return true if id fields are missing
**               (Fields ExtOp_DbId and ExtOp_DraftOrderId)
**
** Arguments   : extOp      ExtOp used to test ids
**
** Return      : TRUE       All id is missing (NULL)
**               FALSE      One id is present (not NULL)
**
** Creation    : REF8500 - 040510 - PMO : Add a draft_order_id in extended operation to distinguish
**                                        the id from extended orders and the one from extended operation
** Last modif. :
**
************************************************************************/
FLAG_T IS_EXTOP_DATABASE_ID_MISSING(const DBA_DYNFLD_STP extOpPtr)
{
    /* Only one ID at a time must be present */
    assert (!(IS_NULLFLD(extOpPtr, ExtOp_DbId) == FALSE && IS_NULLFLD(extOpPtr, ExtOp_DraftOrderId) == FALSE));

    return IS_NULLFLD(extOpPtr, ExtOp_DbId) == TRUE && IS_NULLFLD(extOpPtr, ExtOp_DraftOrderId) == TRUE;
}


/************************************************************************
**
** Function    : IS_EXTOP_DATABASE_ID_PRESENT
**
** Description : Return true if an id field is present
**               (Fields ExtOp_DbId and ExtOp_DraftOrderId)
**
** Arguments   : extOp      ExtOp used to test ids
**
** Return      : TRUE       One id is present (not NULL)
**               FALSE      All id is missing (NULL)
**
** Creation    : REF8500 - 040510 - PMO : Add a draft_order_id in extended operation to distinguish
**                                        the id from extended orders and the one from extended operation
** Last modif. :
**
************************************************************************/
FLAG_T IS_EXTOP_DATABASE_ID_PRESENT(const DBA_DYNFLD_STP extOpPtr)
{
    /* Only one ID at a time must be present */
    assert (!(IS_NULLFLD(extOpPtr, ExtOp_DbId) == FALSE && IS_NULLFLD(extOpPtr, ExtOp_DraftOrderId) == FALSE));

    return IS_NULLFLD(extOpPtr, ExtOp_DbId) == FALSE || IS_NULLFLD(extOpPtr, ExtOp_DraftOrderId) == FALSE;
}


/************************************************************************
**
** Function    : GET_EXTOP_DATABASE_ID
**
** Description : Return the database id
**               (Fields ExtOp_DbId or ExtOp_DraftOrderId)
**
** Arguments   : extOp      ExtOp used to return the id
**
** Return      : The id of the database
**
** Creation    : REF8500 - 040510 - PMO : Add a draft_order_id in extended operation to distinguish
**                                        the id from extended orders and the one from extended operation
** Last modif. :
**
************************************************************************/
ID_T GET_EXTOP_DATABASE_ID(const DBA_DYNFLD_STP extOpPtr)
{
    ID_T operationId;   /* Return value, Operation id or db id */

    /* Only one ID at a time must be present */
    assert (!(IS_NULLFLD(extOpPtr, ExtOp_DbId) == FALSE && IS_NULLFLD(extOpPtr, ExtOp_DraftOrderId) == FALSE));

    /* Check for draft order id */
    if (TRUE == IS_NULLFLD(extOpPtr, ExtOp_DraftOrderId))
    { /* database id or operation id*/
        operationId = GET_ID(extOpPtr, ExtOp_DbId);
    }
    else
    { /* draft order id */
        operationId = GET_ID(extOpPtr, ExtOp_DraftOrderId);
    }

    return operationId;
}

/************************************************************************
**
** Function    : DBA_GetServiceNameFromDB
**
** Description : Get the DB Service Name from DB using the default DB Serveice Name 
**                set in DSQUERY/AAATNSNAME
**
** Arguments   : dbiConn      DB Connection Details
**               server       Server Name
**               pServer      Fetched Server Name
**               pDBService   Fetched DB Service Name
**
** Return      : 
**
** Creation    : KNI - 310820 - PMSTA-41113 - Multiple DB Connections
**
** Last modif. :
**
************************************************************************/
int DBA_GetServiceNameBEFromDB(DbiConnection& dbiConn
                             , const std::string &server
                             , std::string       &pServer
                             , std::string       &pDBService
                             , std::string       &pBECd
                             , ID_T              &pBEId
)
{
    int found = 0;
    char *sserver = nullptr;
    char *dBService = nullptr;
    char *businessEntityCd = nullptr;
    ID_T *businessEntityId = nullptr;

    RequestHelper requestHelper(&dbiConn);
    requestHelper.setReadOnly(true);

    const AAALogger& sqlTraceLog = AAALogger::get(AAALogger::Logger::SqlTrace);
    if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
    {
        auto &sqlTrace = dbiConn.getSqlTrace();
        sqlTrace.m_procedure = "DynSql.GetDBServiceByName";
        sqlTrace.m_mode = DbiSqlTrace::Mode::Lang;
    }

    requestHelper.addNewParamCharPtr(server, NameType);
    requestHelper.setCommand("#EXEC #AAALOGIN_DB.get_dbservice_by_nm ?");

    requestHelper.addNewOutputData(NameType);
    requestHelper.getBindVariablePtr(sserver);
    requestHelper.addNewOutputData(NameType);
    requestHelper.getBindVariablePtr(dBService);
    requestHelper.addNewOutputData(CodeType);
    requestHelper.getBindVariablePtr(businessEntityCd);
    requestHelper.addNewOutputData(IdType);
    requestHelper.getBindVariablePtr(businessEntityId);

    DATE_START_TIMER(1, TIMER_MASK_SQLC);

    RET_CODE ret = requestHelper.sendAndGetCommand();

    if (ret != RET_SUCCEED)
    {
        string buffer = SYS_Stringer("Cannot connect to login database: ", SYS_GetLoginDb());
        MSG_DispMsgText(RET_SUCCEED, buffer.c_str());
        return FALSE;
    }

    pServer = sserver;

    if (*dBService != END_OF_STRING)
        pDBService = dBService;

    if (*businessEntityCd != END_OF_STRING)
    {
        pBECd = businessEntityCd;
        pBEId = *businessEntityId;
    }

    found++;

    DATE_STOP_TIMER(1, TIMER_MASK_SQLC);

    return found;
}

/************************************************************************
**
**  Function    : DBA_GetExdClientConnectByCd
**
**  Description :
**
**  Arguments   :   (server) or (user and display)
**
**  Return      :   serverId, server, sql, sqr, audit
**
**  Creation    :   FPL-PMSTA08761-091005
**
**  Last modif. :   PMSTA-25194 - 041116 - PMO : Stack overflow when DISPLAY > 29
**
*************************************************************************/
int DBA_GetExdClientConnectByCd(DbiConnection& dbiConn
                                , const char           *server
                                , const char           *user
                                , const std::string    &display   /* PMSTA-25194 - 041116 - PMO */
                                , ID_T                 *pServerId
                                , std::string          &pServer
                                , std::string          &pSql
                                , std::string          &pSqr
                                , std::string          &pAudit
                                , std::string          &pPermTsl /* DLA - PMSTA-12296 - 110706 */
                                , std::string          &pTempTsl /* DLA - PMSTA-12296 - 110706 */
)
{
    int             found = 0;
    ID_T* serverId = nullptr;
    char* sserver = nullptr;
    char* sql = nullptr;
    char* sqr = nullptr;
    char* audit = nullptr;
    char* permtsl = nullptr;
    char* temptsl = nullptr;
    char* dbName = nullptr;
    char* dbTimeZoneCd = nullptr;

    RequestHelper requestHelper(&dbiConn);
    requestHelper.setReadOnly(true);

    const AAALogger& sqlTraceLog = AAALogger::get(AAALogger::Logger::SqlTrace);
    if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
    {
        auto &sqlTrace = dbiConn.getSqlTrace();
        sqlTrace.m_procedure = "DynSql.GetConnectInfo";
        sqlTrace.m_mode = DbiSqlTrace::Mode::Lang;
    }

    if (EV_AAAInstallLevel > 9)
    {
        *pServerId = 0;
        pAudit.clear();

        DdlGenContextPtr ddlGenContextPtr(new DdlGenContext(dbiConn.getDbaRDBMS()));
        auto &ddlGenCfgFile = ddlGenContextPtr->getCfgFileHelper(true);
        
        for (auto it = ddlGenCfgFile.dbSectionMap.begin(); it != ddlGenCfgFile.dbSectionMap.end(); ++it)
        {
            if (it->first == "AAAMAIN_DB")
            {
                pSql = it->second.dbSqlName;
                found++;
            }
            else if (it->first == "AAAREP_DB")
            {
                pSqr = it->second.dbSqlName;
                found++;
            }
            else if (it->first == "TSL_PERM_DB")
            {
                pPermTsl = it->second.dbSqlName;
                found++;
            }
            else if (it->first == "TSL_TEMP_DB")
            {
                pTempTsl = it->second.dbSqlName;
                found++;
            }
        }
        pServer = "AAAMAIN_DB";

        return found;
    }
    else if (EV_AAAInstallLevel > 0 || SYS_IsDdlGenMode() == TRUE)
    {
        dbName = SYS_GetEnv("AAAMAINDB");

        stringstream getDatabseStream;
        getDatabseStream
            << "select" << endl
            << "se.dict_id," << endl
            << "NULL," << endl
            << "se.sqlname_c," << endl
            << "(select dd.sqlname_c from dict_database dd where dd.code = 'AAAREP_DB')," << endl
            << "(select dd.sqlname_c from dict_database dd where dd.code = 'AAAUDIT_DB')," << endl
            << "(select dd.sqlname_c from dict_database dd where dd.code = 'TSL_PERM_DB')," << endl
            << "(select dd.sqlname_c from dict_database dd where dd.code = 'TSL_TEMP_DB')," << endl
            << "NULL" << endl
            << "from dict_database se" << endl
            << "where se.code = 'AAAMAIN_DB'" << endl;

        requestHelper.setCommand(getDatabseStream.str());
    }
    else if (server != NULL)
    {
        requestHelper.addNewParamCharPtr(server, String1000Type);
        requestHelper.setCommand("#EXEC #AAALOGIN_DB.get_exd_server_connect_by_nm ?");
    }
    else
    {
        requestHelper.addNewParamCharPtr(user, String1000Type);
        requestHelper.addNewParamString(display, String1000Type);

        requestHelper.setCommand("#EXEC #AAALOGIN_DB.get_exd_client_connect_by_cd ?, ?");
    }

    requestHelper.addNewOutputData(IdType);
    requestHelper.getBindVariablePtr(serverId);
    requestHelper.addNewOutputData(NameType);
    requestHelper.getBindVariablePtr(sserver);
    requestHelper.addNewOutputData(SysnameType);
    requestHelper.getBindVariablePtr(sql);
    requestHelper.addNewOutputData(SysnameType);
    requestHelper.getBindVariablePtr(sqr);
    requestHelper.addNewOutputData(SysnameType);
    requestHelper.getBindVariablePtr(audit);
    requestHelper.addNewOutputData(SysnameType);
    requestHelper.getBindVariablePtr(permtsl);
    requestHelper.addNewOutputData(SysnameType);
    requestHelper.getBindVariablePtr(temptsl);
    requestHelper.addNewOutputData(CodeType);          /* PMSTA-43454 - DDV - 210128 */
    requestHelper.getBindVariablePtr(dbTimeZoneCd);    /* PMSTA-43454 - DDV - 210128 */

    if (dbName && dbName[0] != 0)
    {
        requestHelper.useDb(dbName);
    }

    /* PMSTA-43454 - DDV - 210128 */
    if (dbTimeZoneCd && dbTimeZoneCd[0] != 0)
    {
        strncpy(EV_DbTimeZoneCd, dbTimeZoneCd, CODE_T_LEN);
    }

    DATE_START_TIMER(1, TIMER_MASK_SQLC);

    RET_CODE ret = requestHelper.sendAndGetCommand();

    if (ret != RET_SUCCEED)
    {
        return FALSE;
    }

    *pServerId = *serverId;
    pServer    = sserver;
    pSql       = sql;
    pSqr       = sqr;
    pPermTsl   = permtsl;
    pTempTsl   = temptsl;

    if (*audit != END_OF_STRING)
    {
        pAudit = audit;
    }
    else
    {
        pAudit.clear();
    }

    dbiConn.getTargetSessionProperties().setDbName(sql);

    found++;

    DATE_STOP_TIMER(1, TIMER_MASK_SQLC);

    if (ret != RET_SUCCEED)
    {
        string buffer = SYS_Stringer("Cannot connect to login database: ", dbName);
        MSG_DispMsgText(RET_SUCCEED, buffer.c_str());
        return FALSE;
    }

    /* PMSTA-27179 - LJE - 170522 */
    if (found == 0 && EV_AAAInstallLevel == 0)
    {
        EV_AAAInstallLevel = 1;
        found = DBA_GetExdClientConnectByCd(dbiConn, server, user, display, pServerId, pServer, pSql, pSqr, pAudit, pPermTsl, pTempTsl);
        EV_AAAInstallLevel = 0;
    }

    return found;
}

/************************************************************************
**
**  Function    :   DICT_SetDynfld
**
**  Description :   Set the field with the standard macro according to his type
**
**  Arguments   :   p               Dynamic structure
**                  fld             Field index
**                  dataType        Datatype that define which MACRO to use
**                  value           Native type used for storing the value
**
**  Return      :   true            if ok
**                  false           if error
**
**  Last modif. :   PMSTA-18479 - 130814 - PMO : Integrate communication layer at financial server level
**
*************************************************************************/
bool DICT_SetDynfld(DBA_DYNFLD_STP p, const FIELD_IDX_T fld, const DATATYPE_ENUM dataType, const INT64_T & value)
{
    bool ret = true;

    switch (dataType)
    {
    case DictType:
    case IdType:
        SET_ID(p, fld, value);
        break;

    case EnumMaskType:
        SET_MASK64(p, fld, value);
        break;

        /* PMSTA-20887 - LJE - 150909 */
    case LongintType:
        SET_LONGINT(p, fld, value);
        break;

    case BinaryType:                     /* PMSTA-24564 - LJE - 161122 */
    case TimeStampTType:                 /* PMSTA-25117 - DDV - 161025 */
    case TimeStampType:                  /* PMSTA-25117 - DDV - 161025 */
        SET_TIMESTAMP(p, fld, value);
        break;

    default:
        ret = false;
        break;
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DICT_SetDynfld
**
**  Description :   Set the field with the standard macro according to his type
**
**  Arguments   :   p               Dynamic structure
**                  fld             Field index
**                  dataType        Datatype that define which MACRO to use
**                  value           Native type used for storing the value
**
**  Return      :   true            if ok
**                  false           if error
**
**  Last modif. :   PMSTA-24564 - LJE - 161122
**
*************************************************************************/
bool DICT_SetDynfld(DBA_DYNFLD_STP p, const FIELD_IDX_T fld, const DATATYPE_ENUM dataType, const UINT64_T & value)
{
    bool ret = true;

    switch (dataType)
    {
        case DictType:
        case IdType:
            SET_ID(p, fld, value);
            break;

        case EnumMaskType:
            SET_MASK64(p, fld, value);
            break;

        case LongintType:
            SET_LONGINT(p, fld, value);
            break;

        case BinaryType:
        case TimeStampTType:
        case TimeStampType:
            SET_TIMESTAMP(p, fld, value);
            break;

        default:
            ret = false;
            break;
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DICT_SetDynfld
**
**  Description :   Set the field with the standard macro according to his type
**
**  Arguments   :   p               Dynamic structure
**                  fld             Field index
**                  dataType        Datatype that define which MACRO to use
**                  value           Native type used for storing the value
**
**  Return      :   true            if ok
**                  false           if error
**
**  Last modif. :   PMSTA-18479 - 130814 - PMO : Integrate communication layer at financial server level
**
*************************************************************************/
bool DICT_SetDynfld(DBA_DYNFLD_STP p, const FIELD_IDX_T fld, const DATATYPE_ENUM dataType, const int & value)
{
    bool ret = true;

    switch (dataType)
    {
    case IntType:
    case MaskType:    /* PMSTA-25117 - DDV - 161025 */
        SET_INT(p, fld, value);
        break;

    default:
        ret = false;
        break;
    }

    return ret;
}


/************************************************************************
**
**  Function    :   DICT_SetDynfld
**
**  Description :   Set the field with the standard macro according to his type
**
**  Arguments   :   p               Dynamic structure
**                  fld             Field index
**                  dataType        Datatype that define which MACRO to use
**                  value           Native type used for storing the value
**
**  Return      :   true            if ok
**                  false           if error
**
**  Last modif. :   PMSTA-18479 - 130814 - PMO : Integrate communication layer at financial server level
**
*************************************************************************/
bool DICT_SetDynfld(DBA_DYNFLD_STP p, const FIELD_IDX_T fld, const DATATYPE_ENUM dataType, const DATE_T & value)
{
    bool ret = true;

    switch (dataType)
    {
    case DateType:
        SET_DATE(p, fld, value);
        break;

    default:
        ret = false;
        break;
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DICT_SetDynfld
**
**  Description :   Set the field with the standard macro according to his type
**
**  Arguments   :   p               Dynamic structure
**                  fld             Field index
**                  dataType        Datatype that define which MACRO to use
**                  value           Native type used for storing the value
**
**  Return      :   true            if ok
**                  false           if error
**
**  Last modif. :   PMSTA-18479 - 130814 - PMO : Integrate communication layer at financial server level
**
*************************************************************************/
bool DICT_SetDynfld(DBA_DYNFLD_STP p, const FIELD_IDX_T fld, const DATATYPE_ENUM dataType, const DATETIME64_ST & value)
{
    bool ret = true;

    switch (dataType)
    {
    case DatetimeType:
        SET_DATETIMEST(p, fld, value);
        break;

    case DateType:
        SET_DATE(p, fld, value.date());
        break;

    case TimeType:
        SET_TIME(p, fld, value.time());
        break;

    default:
        ret = false;
        break;
    }

    return ret;
}


/************************************************************************
**
**  Function    :   DICT_SetDynfld
**
**  Description :   Set the field with the standard macro according to his type
**
**  Arguments   :   p               Dynamic structure
**                  fld             Field index
**                  dataType        Datatype that define which MACRO to use
**                  value           Native type used for storing the value
**
**  Return      :   true            if ok
**                  false           if error
**
**  Last modif. :   PMSTA-18479 - 130814 - PMO : Integrate communication layer at financial server level
**
*************************************************************************/
bool DICT_SetDynfld(DBA_DYNFLD_STP p, const FIELD_IDX_T fld, const DATATYPE_ENUM dataType, const short & value)
{
    bool ret = true;

    switch (dataType)
    {
    case SmallintType:
        SET_SMALLINT(p, fld, value);
        break;

    default:
        ret = false;
        break;
    }

    return ret;
}


/************************************************************************
**
**  Function    :   DICT_SetDynfld
**
**  Description :   Set the field with the standard macro according to his type
**
**  Arguments   :   p               Dynamic structure
**                  fld             Field index
**                  dataType        Datatype that define which MACRO to use
**                  value           Native type used for storing the value
**
**  Return      :   true            if ok
**                  false           if error
**
**  Last modif. :   PMSTA-18479 - 130814 - PMO : Integrate communication layer at financial server level
**
*************************************************************************/
bool DICT_SetDynfld(DBA_DYNFLD_STP p, const FIELD_IDX_T fld, const DATATYPE_ENUM dataType, const unsigned char & value)
{
    bool ret = true;

    switch (dataType)
    {
    case EnumType:
        SET_ENUM(p, fld, value);
        break;

    case FlagType:
        SET_FLAG(p, fld, value);
        break;

    case TinyintType:
        SET_TINYINT(p, fld, value);
        break;

    default:
        ret = false;
        break;
    }
    return ret;
}


/************************************************************************
**
**  Function    :   DICT_SetDynfld
**
**  Description :   Set the field with the standard macro according to his type
**
**  Arguments   :   p               Dynamic structure
**                  fld             Field index
**                  dataType        Datatype that define which MACRO to use
**                  value           Native type used for storing the value
**
**  Return      :   true            if ok
**                  false           if error
**
**  Last modif. :   PMSTA-18479 - 130814 - PMO : Integrate communication layer at financial server level
**
*************************************************************************/
bool DICT_SetDynfld(DBA_DYNFLD_STP p, const FIELD_IDX_T fld, const DATATYPE_ENUM dataType, const double & value)
{
    bool ret = true;

    switch (dataType)
    {
    case ExchangeType:
        SET_EXCHANGE(p, fld, value);
        break;

    case NumberType:
        SET_NUMBER(p, fld, value);
        break;

    case AmountType:
        SET_AMOUNT(p, fld, value);
        break;

    case LongamountType:
        SET_LONGAMOUNT(p, fld, value);
        break;

    case PercentType:
        SET_PERCENT(p, fld, value);
        break;

    case PriceType:
        SET_PRICE(p, fld, value);
        break;

    default:
        ret = false;
        break;
    }

    return ret;
}


/************************************************************************
**
**  Function    :   DICT_SetDynfld
**
**  Description :   Set the field with the standard macro according to his type
**
**  Arguments   :   p               Dynamic structure
**                  fld             Field index
**                  dataType        Datatype that define which MACRO to use
**                  value           Native type used for storing the value
**
**  Return      :   true            if ok
**                  false           if error
**
**  Last modif. :   PMSTA-18479 - 130814 - PMO : Integrate communication layer at financial server level
**                  PMSTA-30965 - 120418 - PMO : Double processing of the date when processing a field of type datetime
**
*************************************************************************/
bool DICT_SetDynfld(DBA_DYNFLD_STP p, const FIELD_IDX_T fld, const DATATYPE_ENUM dataType, const char * value)
{
    bool ret = true;

    switch (dataType)
    {
    case CodeType:
        ret = TRUE == SET_CODE(p, fld, value);
        break;

    case InfoType:
        SET_INFO(p, fld, value);
        break;

    /* PMSTA-19737 - LJE - 160621 */
        case LongnameType:
    case String1000Type:
    case String2000Type:
    case String3000Type:
    case String4000Type:
    case String7000Type:
    case String15000Type:
        SET_STRING(p, fld, value);
        break;

    case NameType:
        SET_NAME(p, fld, value);
        break;

    case NoteType:
        SET_NOTE(p, fld, value);
        break;

    case PhoneType:
        SET_PHONE(p, fld, value);
        break;

    case ShortinfoType:
        SET_SHORTINFO(p, fld, value);
        break;

    case SysnameType:
        SET_SYSNAME(p, fld, value);
        break;

    case LongSysnameType:
        SET_LONGSYSNAME(p, fld, value);
        break;

    case TextType:
        SET_TEXT(p, fld, value);
        break;

    case LongStringType:
        SET_LONGSTRING(p, fld, value);
        break;

    case UrlType:
        SET_URL(p, fld, value);
        break;

    case DatetimeType:
        {
            const QDateTime     qDateTime = QDateTime::fromString(value, Qt::ISODate);
            const QDate         qDate(qDateTime.date());
            const QTime         qTime(qDateTime.time());
            const DATETIME_T    dateTime = { DATE_Put(qDate.year(), qDate.month(), qDate.day()), TIME_Put(qTime.hour(), qTime.minute(), qTime.second()) };
            SET_DATETIME(p, fld, dateTime);
        }
        break;                                                                          /* PMSTA-30965 - 120418 - PMO */

    case DateType:
        {
            const QDate     qDate = QDate::fromString(value, Qt::ISODate);
            const DATE_T    date = DATE_Put(qDate.year(), qDate.month(), qDate.day());
            SET_DATE(p, fld, date);
        break;
        }
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DICT_SetDynfld
**
**  Description :   Set the field with the standard macro according to his type
**
**  Arguments   :   p               Dynamic structure
**                  fld             Field index
**                  dataType        Datatype that define which MACRO to use
**                  value           Native type used for storing the value
**
**  Return      :   true            if ok
**                  false           if error
**
**  Last modif. :   PMSTA-18479 - 130814 - PMO : Integrate communication layer at financial server level
**
*************************************************************************/
bool DICT_SetDynfld(DBA_DYNFLD_STP p, const FIELD_IDX_T fld, const DATATYPE_ENUM dataType, const UChar * value)
{
    bool ret = true;

    switch (dataType)
    {
    case UniCodeType:
        SET_UCODE(p, fld, value);
        break;

    case UniInfoType:
        SET_UINFO(p, fld, value);
        break;

    /* PMSTA-19737 - LJE - 160621 */
    case UniLongnameType:
    case UniString1000Type:
    case UniString2000Type:
    case UniString3000Type:
    case UniString4000Type:
    case UniString7000Type:
    case UniString15000Type:
        SET_USTRING(p, fld, value);
        break;

    case UniNameType:
        SET_UNAME(p, fld, value);
        break;

    case UniNoteType:
        SET_UNOTE(p, fld, value);
        break;

    case UniPhoneType:
        SET_UPHONE(p, fld, value);
        break;

    case UniShortinfoType:
        SET_USHORTINFO(p, fld, value);
        break;

    case UniSysnameType:
        SET_USYSNAME(p, fld, value);
        break;

    case UniTextType:
        SET_UTEXT(p, fld, value);
        break;

    case UniUrlType:
        SET_UURL(p, fld, value);
        break;

    default:
        ret = false;
        break;
    }

    return ret;
}

/************************************************************************
*   Function             : DBI_CompareCtConnect()
*
*   Description          : Function
*
*
*   Arguments            : AAAConnection  : a reference on a connection.
*                          csConnection   : a pointer on a connection(Oracle or Sybase) struct.
*
*   Return               : true if found
*************************************************************************/
static bool CompareConnectSt(DbiConnection & dbiConnect, void * connectionSt)
{
    return dbiConnect.getConnectionPtr() == connectionSt ? true : false;
}

/************************************************************************
*   Function             : DBI_CompareCtCommand()
*
*   Description          : Function
*
*
*   Arguments            : AAAConnection  : a reference on a connection.
*                          csConnection   : a pointer on a command(Oracle or Sybase) struct.
*
*   Return               : true if found
*************************************************************************/
static bool CompareCommandSt(DbiConnection & dbiConnect, void * commandSt)
{
    return dbiConnect.getCommandPtr() == commandSt ? true : false;
}

/************************************************************************
*   Function             : DBA_GetDbiConnFromCommandSt()
*
*   Description          : Get connection number in the connection list whith
*                          the command structure pointer associated with the
*                          connection.
*
*   Arguments            : csCommand      : the connection command pointer
*                          connectNo      : pointer on a connection number
*
*   Functions call       : None
*
*   Global var. modified : None
*
*   Return               : RET_SUCCEED             : if ok
*                          RET_GEN_ERR_INVARG      : if problem whith arguments
*                          DBA_CONN_NOT_FOUND      : if an arg is invalid or
*                                                    no connection was found
*
*   Creation Date        : June 94  - PEC
*   Last Modif           : 29.08.95 - PEC - Added RET_CODE
*                          20.04.98 - GRD - REF1784.
*************************************************************************/
DbiConnection * DBA_GetDbiConnFromCommandSt(PTR commandSt)
{
    if (SYS_GetTlsThread() != nullptr)
    {
        return(AAALocalConnectionProvider::get().find(nullptr, nullptr, nullptr ,CompareCommandSt, (void *)commandSt));
    }
    else
    {
        return(AAAConnectionProvider::getConnectionProviderInstance().find(nullptr, nullptr, nullptr, CompareCommandSt, (void *)commandSt));
    }
}

/************************************************************************
*   Function             : DBA_GetDbiConnFromConnectionSt()
*
*   Description          : Get connection number in the connection list whith
*                          the command structure pointer associated with the
*                          connection.
*
*   Arguments            : csCommand      : the connection command pointer
*                          connectNo      : pointer on a connection number
*
*   Functions call       : None
*
*   Global var. modified : None
*
*   Return               : RET_SUCCEED             : if ok
*                          RET_GEN_ERR_INVARG      : if problem whith arguments
*                          DBA_CONN_NOT_FOUND      : if an arg is invalid or
*                                                    no connection was found
*
*   Creation Date        : June 94  - PEC
*   Last Modif           : 29.08.95 - PEC - Added RET_CODE
*                          20.04.98 - GRD - REF1784.
*************************************************************************/
DbiConnection * DBA_GetDbiConnFromConnectionSt(PTR connectionSt)
{
    if (SYS_GetTlsThread() != nullptr)
    {
        return(AAALocalConnectionProvider::get().find(nullptr, nullptr, nullptr, CompareConnectSt, (void *)connectionSt));
    }
    else
    {
        return(AAAConnectionProvider::getConnectionProviderInstance().find(nullptr, nullptr, nullptr, CompareConnectSt, (void *)connectionSt));
    }
}

/************************************************************************
*
*   Function           : DBA_LoadApplParam
*
*   Description        :
*
*   Arguments          :
*
*   Return             :
*
*  Creation Date       :
*
*  Last modif.         : PMSTA-33209 - 091018 - PMO : Bad handling of useless business entity provided by command line
*
*************************************************************************/
RET_CODE DBA_LoadApplParam(DbiConnection& dbiConn, ID_T userId)
{
	RET_CODE	                      retCode = RET_SUCCEED;
    std::map<std::string,std::string> map_param_bootstrap;

    /* PMSTA-30036 - DLA - 180606 */
    /* init the default value for boot_strap*/
    map_param_bootstrap.insert(make_pair("SQL_SYNC", "25"));
    map_param_bootstrap.insert(make_pair("SQL_ASYNC", "4"));
    map_param_bootstrap.insert(make_pair("FIN_SYNC", "0"));
    map_param_bootstrap.insert(make_pair("FIN_ASYNC", "0"));
    map_param_bootstrap.insert(make_pair("SUBSCRIPTION_ACTIVE_FLAG", "0"));
    map_param_bootstrap.insert(make_pair("MASTER_BUSINESS_ENTITY", ""));

    if (SYS_GetEnv("AAA_FORCE_ENCRYPTION_LEVEL_NONE") == nullptr)
    {
        map_param_bootstrap.insert(make_pair("ENCRYPTION_LEVEL", "1")); /* PMSTA-50363 - FME - 2022-09-28- support for net password encryption reqd = 2 */
    }
    else
    {
        map_param_bootstrap.insert(make_pair("ENCRYPTION_LEVEL", "0"));
    }
    map_param_bootstrap.insert(make_pair("ENCRYPTION_LEVEL", "0"));
	map_param_bootstrap.insert(make_pair("ACTIVATE_ORG_SECURITY", "0"));
	map_param_bootstrap.insert(make_pair("ENTITLEMENT_SERVICE", "0"));

    if (SYS_IsDdlGenMode() == FALSE && EV_AAAInstallLevel <= 2)
    {
        map_param_bootstrap.insert(make_pair("LICENSEE_NAME", ""));
        map_param_bootstrap.insert(make_pair("LOGIN_MESSAGE", ""));
        map_param_bootstrap.insert(make_pair("AAA_VERSION", ""));

        retCode = DBI_LoadApplParam(dbiConn, userId, map_param_bootstrap);
        FLAG_T statusFlag = retCode == RET_SUCCEED ? TRUE : FALSE;
        GEN_SetApplInfo(ApplParamStatusFlg, &statusFlag);
    }

    for (auto it = map_param_bootstrap.begin(); it != map_param_bootstrap.end() && RET_GEN_ERR_WRONG_VERSION != retCode; ++it)
    {
        if ((*it).first.compare("MASTER_BUSINESS_ENTITY") == 0)                      /*  HFI-PMSTA-26560-170906  */
        {
            if ((*it).second.empty() == false)
            {
                DdlGenDbi::getMasterBusinessEntityInfo(&dbiConn);
            }
            else
            {
                /* PMSTA-33209 - 091018 - PMO */
                SYS_SetThreadCurrBusinessEntity("");
            }
        }
        /* PMSTA-28916 - LJE - 171219 */
        else if ((*it).first.compare("AAA_VERSION") == 0)
        {
            retCode = GEN_VerifVersion((*it).second);
        }
        else
        {
            retCode = GEN_SetApplParam((*it).first, (*it).second);
        }
    }
	return(retCode);
}

/************************************************************************
*
*   Function           : DBA_GetConnProviderSessionProperties
*
*   Description        : AAAConnectionDescription& desc (optional)
*
*   Arguments          :
*
*   Return             :
*
*  Creation Date       : PMSTA-29812 - DLA - 180115
*
*************************************************************************/
SessionProperties &DBA_GetConnProviderSessionProperties(const AAAConnectionDescription& desc)
{
    return AAALocalConnectionProvider::get().getSessionProperties(desc.getRole());
}

/************************************************************************
*
*   Function           : DBA_GetConnSessionProperties
*
*   Description        :
*
*   Arguments          :
*
*   Return             :
*
*  Creation Date       : PMSTA-28916 - LJE - 171214
*
*************************************************************************/
const SessionProperties &DBA_GetConnSessionProperties(DbiConnection &connection)
{
    return connection.getConnSessionProperties();
}

/************************************************************************
*   Function             : DBA_GetDbUTCOffset
*
*   Description          : Get UTC offset for database time
*
*   Arguments            :
*
*   Functions call       : None
*
*   Global var. modified : None
*
*   Return               : RET_SUCCEED             : if ok
*
*   Creation Date        : PMSTA-30817 - DDV - 180502
*   Last Modif           :
*
*************************************************************************/
RET_CODE DBA_GetDbUTCOffset(DbiConnectionHelper &dbiConnHelper, TZ_OFFSET_T *dbUTCOffset)
{
    RET_CODE         ret=RET_SUCCEED;
    MemoryPool       memPool;

    if (dbUTCOffset == NULL)
    {
        return(RET_GEN_ERR_INVARG);
    }

    DBA_DYNFLD_STP   sTimezoneStp = memPool.allocDynst(FILEINFO, S_Timezone);

    if (dbiConnHelper.dbaGet(Timezone, DBA_ROLE_LOAD_UTCOFFSET, NULLDYNST, &sTimezoneStp) == RET_SUCCEED)
    {
        *dbUTCOffset = GET_TZOFFSET(sTimezoneStp, S_Timezone_UtcOffset);
    }
    return(ret);
}

/************************************************************************
**   END  dbalib01.c                                          Odyssey **
*************************************************************************/

/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef FINLIB11_H
#define FINLIB11_H

/************************************************************************
**      BEGIN : Global variables & external definitions attached to finlib11.c
*************************************************************************/
#ifdef  EXTERN
    #undef  EXTERN
#endif
#ifdef  FINLIB11_C
    #define	EXTERN
#else
    #define EXTERN extern
#endif

EXTERN RET_CODE FIN_StratNewModel(DBA_HIER_HEAD_STP ,int, DBA_DYNFLD_STP, int, int*);
EXTERN int FIN_StratFilterDispESL(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP); /* REF7264 - LJE - 020131 */
EXTERN int FIN_StratFilterRefStratEltByStratId(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP);
EXTERN int FIN_StratFilterCrtESL(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP);
EXTERN int FIN_StratFilterParESE(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP); /* REF7264 - LJE - 020131 */

#endif /* FINLIB11_H */


/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define AAASQL_C


/************************************************************************
**      Includes
*************************************************************************/
#ifdef NTWIN
#pragma warning (push)
#include <windows.h>
#endif

#include "unidef.h" /* Mandatory */
#include "os.h"
#include "itfc.h"
#include "syslib.h"
#include "gen.h"
#include "dba.h"
#include "dbi.h"
#include "date.h"
#include "csrv.h"
#include "sig.h"

#include "crypto.h"
#include "crypto-openssl.h"
#include "password.h"

#ifndef CALLSTACK_H
#include "callstack.h"
#endif


#include "ddlgenfromfile.h"
#include "ddlgenvar.h"

#include <iostream>

#include "aaasql.h"

#ifdef NTWIN
#pragma warning(disable:4512)
#include "shaddup_compiler.h"
#endif
#include "QCoreApplication"
#include "QSettings"
#include "qstringlist.h"
#include "httplib.h"
#include "aaalogger.h"
#include "aaatelemetry.h"
#include "fussync.h"
#include "masterkeymanager.h"
#include "passstorerecord.h"
#include "passstorefilemanager.h"

#include "extendedsql.h" /* PMSTA-36178 - KNI - Load Service - 190716*/

#ifdef NTWIN
#pragma warning (pop)
#endif

using namespace std;

/************************************************************************
**      Constants
*************************************************************************/

#define SEGMENT 64
#define MAX_EINTR 10

/************************************************************************
**      Static Data Definitions
*************************************************************************/

static int  SV_ServerMode = FALSE; /* from import.c */
static int  SV_ServerInitFlg = TRUE;  /* from import.c */


/************************************************************************
**      Global Data Definitions
*************************************************************************/
int  EV_GuiActivatedFlg = 0;
int  EV_TestNewScpt = 1;
int  EV_OptiMemFlg = FALSE;
int *EV_ServerMode = &SV_ServerMode;
int *EV_ServerInitFlg = &SV_ServerInitFlg;
QCoreApplication *app;
CODE_T      EV_DbTimeZoneCd = "";       /* PMSTA-30817 - DDV - 180501 */

extern AtomicInt EV_SigEvent;

static string             SV_argSeparator;
static int                SV_argOptimLevel    = 1;
bool                      SV_bArgPrintHeader  = true;
bool                      SV_bArgPrintAllign  = true;
bool                      SV_bArgPrintEcho    = false;
bool                      SV_bArgRunServer    = false;
bool                      SV_bHeaderLowerCase = false;
int                       SV_argColWidth      = 0;

extern VERBOSE_LEVEL_ENUM EV_argVerboseLevel;

/************************************************************************
**      Macro Definitions
*************************************************************************/

#define STRDUP(x) strcpy((char *)CALLOC(1, strlen(x) + 1), x)

/************************************************************************
**      Type  Definitions
*************************************************************************/

#ifdef NTWIN
#include "sysnt.h"

static  char    SV_KeywordNT[64];
#endif


/************************************************************************
**      External Data Definitions
*************************************************************************/

extern char                 SV_User[MAX_USERINFO_LEN + 1];
extern TIMER_STP            EV_ExtractFileTimerPtr;
extern bool                 EV_UseAlternativeDataSource;
extern DBA_RDBMS_ENUM       EV_SourceRdbmsVendor;
extern std::string          EV_SourceApplOwner;

/************************************************************************
**      Global Functions
**
**  main()              Triple'A SQL tools Entry Point
**
*************************************************************************/

/************************************************************************
**      Static Functions
**
**  AAASQL_GetOption()
**
**  AAASQL_Handler()
**
**  AAASQL_Startup()
**
*************************************************************************/

STATIC int  AAASQL_GetOption(int, char **);

STATIC int  AAASQL_Startup(char *user, AAASQL_CONTEXT_ST &context);
STATIC RET_CODE AAASQL_TreatLine(AAASQL_CONTEXT_ST &context, string &line, std::set<std::string> &endOfCommands, AAALogger& log);
STATIC void AAASQL_Done(AAASQL_CONTEXT_STP &context);
STATIC void AAASQL_AfterMain(AAASQL_CONTEXT_STP &context);

STATIC void usage();

/************************************************************************
**      Static Data Definitions
*************************************************************************/

static char *SV_InputFilename = NULL;
static char *SV_InitFilename = NULL;

static AtomicBool firstExit;

static string SV_DefDbName;

/************************************************************************
**      Global Data Definitions
*************************************************************************/



/************************************************************************
**      Static Function Definitions
*************************************************************************/

/************************************************************************
**
**  Function    :   AAASQL_GetOption()
**
**  Description :
**
**  Argument    :   argc
**                  argv
**
**  Return      :   0 on success, -1 elsewhere
**
**  Last modif. :   PMSTA-24510 - 220816 - PMO : Fusion & Dispatcher in HTTP
**                  PMSTA-25793 - 281216 - PMO : Dispatcher might crash on AIX into putProperty
**
*************************************************************************/
STATIC int AAASQL_GetOption(int argc, char **argv)
{
    int c;
    char *argStr;
    CURRENTCHARSETCODE_ENUM  charsetCode = CurrentCharsetCode_UTF8;
    bool                     bForcePassword = false;

    GEN_SetApplInfo(ApplCurrentCharsetInputEnum, &charsetCode);
    GEN_SetApplInfo(ApplCurrentCharsetOutputEnum, &charsetCode);

    while ((c = SYS_Getopt(argc, argv, "S:U:P:s:M:B:C:F:E:L:J:K:O:IWvmVX:c:i:h:t:D:w:bep:Rr:n:")) != EOF) /* PMSTA-30135 CMILOS 140219 */ /* PMSTA-41113 - KNI - 310820 */
    {
        switch (c)
        {
            case 'U':
                strcpy(SV_User, SYS_GetoptArg());
                SYS_SetThreadUser(SV_User);
                break;

            case 'P':
            {
                PasswordEncrypted pE;
                pE.setClearPassword(PasswordClear(SYS_GetoptArg()));
                GEN_SetUserInfo(UserPasswd, (const void*)&pE);
            }
            break;

            case 'S':
            {
                char *server = SYS_GetoptArg();

                if (server != NULL &&
                    strcmp(server, "NULL") != 0)
                {
                    EV_Server = server;                         /* PMSTA-24510 - 220816 - PMO */
                }
                else
                {
                    EV_Server = "";                             /* PMSTA-24510 - 220816 - PMO */
                }
                GEN_SetUserInfo(ForcedServerName, EV_Server.c_str());    /* DLA - PMSTA-29105 - 171114 */
            }
            break;

            case 's':
                argStr = SYS_GetoptArg();
                SV_argSeparator = argStr;

                if (SV_argSeparator.compare("\\t") == 0)
                {
                    SV_argSeparator = "\t";
                }
                break;

            case 'C':
                SYS_LoadCfgFile(SYS_GetoptArg());
                break;

            case 'E':
                EV_TimerMask = TIMER_MASK_GEN;

                EV_ExtractFile =
                    SYS_Fopen(SYS_GetoptArg(), "a");

                DATE_ResetTimer(EV_ExtractFileTimerPtr, TIMER_MASK_GEN);
                DATE_StartTimer(EV_ExtractFileTimerPtr, TIMER_MASK_GEN);
                break;

            case 'O':
                argStr = SYS_GetoptArg();
                if (argStr != NULL)
                {
                    SV_argOptimLevel = atoi(argStr);
                }
                break;

            case 'W': /* (DVP273 GRD) */
                if (EV_WarningMsg == TRUE)
                    return -1;

                EV_WarningMsg = TRUE;
                break;

            case 'i':
                SV_InputFilename = SYS_GetoptArg();
                break;

            case 'I': /* PMSTA-30135 CMILOS 140219 */
                EV_InternalAddress = TRUE;
                break;

            case 'J':
                if (GEN_SetCurCharset(SYS_GetoptArg(), CharsetCodeType_Rdbms, CharsetCodeNoCtx, EV_RdbmsVendor) != RET_SUCCEED)
                    return -1;
                break;

            case 'K':
                if (GEN_SetCurCharset(SYS_GetoptArg(), CharsetCodeType_Icu, CharsetCodeCtx_Output, EV_RdbmsVendor) != RET_SUCCEED)
                    return -1;
                break;

            case 'L':
                if (GEN_SetCurCharset(SYS_GetoptArg(), CharsetCodeType_Icu, CharsetCodeCtx_Input, EV_RdbmsVendor) != RET_SUCCEED)
                    return -1;
                break;

            case 'h':
                argStr = SYS_GetoptArg();
                EV_argVerboseLevel = static_cast<VERBOSE_LEVEL_ENUM>(atoi(argStr));
                break;

            case 'b':
                SV_bArgPrintHeader = false;
                break;

            case 'e':
                SV_bArgPrintEcho = true;
                break;

            case 'p':
                bForcePassword = true;
                break;

            case 'V':
                GEN_AnalyseVersion((char)c);
                break;

            case 'v':
                GEN_AnalyseVersion((char)c);
                SYS_Shutdown(EXIT_SUCCESS);        /* DLA - PMSTA-26546 - 170314 */
                break;

            case 'X':
                argStr = SYS_GetoptArg();

                if (argStr != nullptr)
                {
                    if (strstr(argStr, "t") != nullptr)
                    {
                        GEN_AnalyseVersion('t');
                        SYS_Shutdown(EXIT_SUCCESS);        /* DLA - PMSTA-26546 - 170314 */
                    }
                    else if (strstr(argStr, "l") != nullptr)
                    {
                        SV_bHeaderLowerCase = true;
                    }
                }
                break;

            case 't':
            {
                char   cmdBuf[255];
                int    timeOut;
                argStr = SYS_GetoptArg();

                if (argStr != nullptr &&
                    (timeOut = atoi(argStr)) >= 0)
                {
                    sprintf(cmdBuf, "%ld", timeOut);
                    SYS_PutEnv("AAATIMEOUT", cmdBuf);  /* PMSTA-25793 - 281216 - PMO */ /* PMSTA-45665 - LJE - 210709 */
                }
                else
                {
                    return -1;
                }
                break;
            }

            case 'D':
                argStr = SYS_GetoptArg();

                if (argStr != nullptr)
                {
                    SV_DefDbName = argStr;
                }
                break;

            case 'w':
                argStr = SYS_GetoptArg();

                if (argStr != nullptr)
                {
                    SV_argColWidth = atoi(argStr);
                }
                break;

            case 'r':
                SV_InitFilename = SYS_GetoptArg();
                break;

            case 'R':
                SV_bArgRunServer = true;
                break;

            case 'c':  /*  Business Entity as input parameter  */  /*  PMSTA-26108-DDV-171102 */
                SYS_GetThread().setCurrBusinessEntity(SYS_GetoptArg());
                break;

            case 'n': /* PMSTA-41113 - KNI - 310820 */
            {
                std::string serviceName = DBI_GetSqlServerName(std::string(SYS_GetoptArg()));
                break;
            }

            default:
                return -1;
        }
    }

    /* Nothing to do if user has not been provided  */
    if (!*SV_User)
    {
        return -1;
    }

    PasswordEncrypted * pE = nullptr;
    GEN_GetUserInfo(UserPasswd, &pE);
    if (*SV_User && (pE->isValidPassword() == false))
    {
        RET_CODE ret_code = SYS_AutoLogin(SV_User, *pE);

        if (RET_SUCCEED == ret_code && bForcePassword == false) /*PMSTA-24624-EFE-160901*/
        {
            GEN_SetUserInfo(UserPasswd, pE);
        }
        else
        {
            SYSNAME_T pwd;
            AUTO_PASSWORD_CLEAR(pwd, sizeof(pwd));
            SYS_GetPassword("Password", pwd, MAX_USERINFO_LEN + 1, 0);
            pE->setClearPassword(PasswordClear(pwd));
            GEN_SetUserInfo(UserPasswd, pE);
        }
    }

#ifdef AIX
    if (argc > 1)
        *argv[1] = '\0';
#endif

    return 0;
}

STATIC bool AAASQL_CreateRunSrvFile(AAASQL_CONTEXT_ST &context)
{
    bool  bRet = false;
    string line;
    HttpServerFileConfiguration srvConfig;
    string fullFileName;
    string adminDir;
    QStringList serverList;
    bool  serverCanBeRunned = true;

    app->setApplicationName("aaa_srv");
    adminDir = context.ddlGenContext.getAdminPath();

    if (adminDir.empty() == false)
    {
        fullFileName = adminDir;
        fullFileName.append("/scripts/opensrv.lis");
        ifstream inFile(fullFileName.c_str());
        if (inFile.is_open())
        {
            while (getline(inFile, line))
            {
                serverList.push_back(QString(line.c_str()));
            }
            inFile.close();
        }

        if (serverList.size() > 0)
        {
            bRet = true;
            fullFileName = adminDir;
            fullFileName.append("/scripts/newopensrv.lis");
            ofstream outFile(fullFileName.c_str());
            //QCoreApplication::setApplicationName("aaa_srv");
            srvConfig.load();
            //QCoreApplication::setApplicationName("aaa_sql64");
            QSettings  serverSettings(srvConfig.getRefConfigFileName(), QSettings::IniFormat, app);
            QStringList groups = serverSettings.childGroups();
            QString hostInterface;
            QString hostInterfaceToCheck;
            //bool validInterface = true;
            for (auto x = serverList.begin(); x != serverList.end(); ++x)
            {
                serverCanBeRunned = true;
                if (groups.contains((*x)))
                {
                    serverSettings.beginGroup((*x));
                    if ((serverCanBeRunned = !serverSettings.value("listener.disabled", false).toBool()) == true)
                    {
                        hostInterfaceToCheck = serverSettings.value("listener.host").toString();
                        if (hostInterfaceToCheck.isEmpty() == true)
                        {
                            string localHost;
                            SYS_GetFullQualifiedName(localHost);
                            hostInterfaceToCheck = localHost.c_str();
                        }
                        if (hostInterfaceToCheck != "localhost") /* PMSTA-30135 CMILOS 140219 */
                            if ((serverCanBeRunned = HTTP_CheckValidInterface(hostInterfaceToCheck, hostInterface)) == false)
                            {
                                MSG_LogMesg(RET_GEN_ERR_PERSONAL, 7, FILEINFO, "Unable to start server", (*x).toLocal8Bit().constData(), ": no interfaces for this server/hostname on this computer");
                            }
                    }
                    else
                    {
                        MSG_LogMesg(RET_GEN_ERR_PERSONAL, 7, FILEINFO, "Unable to start server", (*x).toLocal8Bit().constData(), ": listener is disabled in aaa_srv.ini");
                    }
                    serverSettings.endGroup();
                }

                if (serverCanBeRunned == true)
                {
                    if (outFile.is_open())
                    {
                        outFile << (*x).toLocal8Bit().constData();
                        if (x + 1 != serverList.end())
                        {
                            outFile << '\n';
                        }
                    }
                }
            }
            outFile.close();
        }
    }
    app->setApplicationName("aaa_sql64");
    return bRet;
}

/*************************************
**
**  Function    :   AAASQL_Init()
**
**  Description :
**
**  Argument : context
**
*************************************************************************/
STATIC bool AAASQL_Init(AAASQL_CONTEXT_ST &context)
{
    context.separator        = SV_argSeparator;
    context.optimLevel       = SV_argOptimLevel;
    context.verboseLevel     = EV_argVerboseLevel;
    context.bPrintHeader     = SV_bArgPrintHeader;
    context.bPrintAllign     = SV_bArgPrintAllign;
    context.bPrintEcho       = SV_bArgPrintEcho;
    context.bHeaderLowerCase = SV_bHeaderLowerCase;
    context.colWidth         = SV_argColWidth;

    if (context.verboseLevel == VerboseLevel_None)
    {
        context.bPrintAllign   = false;
        context.bPrintHeader   = false;
        context.bPrintRowCount = false;
    }
    else if (context.verboseLevel == VerboseLevel_Light)
    {
        context.bPrintHeader = true;
    }
    else if (context.verboseLevel == VerboseLevel_All)
    {
        context.bPrintEcho = true;
    }
    else if (context.verboseLevel == VerboseLevel_Align)
    {
        context.bPrintAllign   = false;
        context.bPrintRowCount = false;
    }

    if (context.ddlGenContext.getDdlGenPath().empty())
    {
        context.scriptDdlGenPtr     = NULL;
        context.sqlConnHelperPtr    = NULL;
        context.finSrvConnHelperPtr = NULL;

        context.ddlGenPtr->printMsg(RET_GEN_ERR_INVARG, "Please set the variable AAAHOME!");
        return false;
    }

    if (context.verboseLevel == VerboseLevel_All)
    {
        if (context.ddlGenContext.getAaaHomePath().empty() == false)
        {
            cout << "AAAHOME is " << context.ddlGenContext.getAaaHomePath() << endl;
        }
        else
        {
            cout << "AAADDLPATH is " << context.ddlGenContext.getDdlGenPath() << endl;
        }
    }

    context.scriptDdlGenPtr = new DdlGenFromFile(DdlObjFromFile_Sql,
                                                 NullEntity,
                                                 context.ddlGenContext,
                                                 nullptr,
                                                 nullptr,
                                                 true,
                                                 nullptr,
                                                 nullptr);

    context.scriptDdlGenPtr->setAvoidSecurity(true);

    context.ddlGenPtr = new DdlGen(NullEntity,
                                    TargetTable_Undefined,
                                    *context.scriptDdlGenPtr);
    context.ddlGenVarHelperPtr = context.scriptDdlGenPtr->varHelperPtr;

    if (context.separator.empty())
    {
        context.separator = " ";
    }

    context.defEndOfCommands.insert("go");
    context.defEndOfCommands.insert("/");

    return true;
}

/************************************************************************
**
**  Function    :   AAASQL_Startup()
**
**  Description :
**
**  Argument    :   user
**                  password
**
**  Return      :   0 on success, -1 elsewhere
**
**  Last modif. :   PMSTA-18094 - 130514 - PMO : Avoid extracting the user credentials from the GUI running on Windows (via dump, etc.)
**
*************************************************************************/
STATIC int AAASQL_Startup(char *user, AAASQL_CONTEXT_ST &context)
{
    int status = 0;

    if (context.bStartUp == false)
    {
        if (CSRV_Init(false) == RET_SUCCEED)
        {
            if (SYS_GetEnv("SYB_PRINTVERSION") != NULL)
            {
                /* print client version */
                DBI_PrintVersion();
            }

            PasswordEncrypted* pE = nullptr;
            GEN_GetUserInfo(UserPasswd, &pE);

            extern int EV_AAAInstallLevel;      /* Only here ! */
            if (context.optimLevel == 9)
            {
                EV_AAAInstallLevel = 10;

                /* PMSTA-43914 - LJE - 210315 */
                if (SV_DefDbName.empty())
                {
                    const char* saUser = getenv("SA_USER");
                    if (saUser != nullptr && SV_User != nullptr && strcmp(SV_User, saUser) == 0)
                    {
                        EV_AAAInstallLevel = 20;
                    }
                }

                context.scriptDdlGenPtr->bKeepConnection = true;
            }

            if (SV_DefDbName.empty() && EV_AAAInstallLevel < 10)
            {
                char* env = SYS_GetEnv("AAAMAINDB");
                if (env != nullptr)
                {
                    SV_DefDbName = env;
                }
            }
            context.ddlGenContext.setDefDdlDestDbName(SV_DefDbName);

            if (GEN_AppLogin(user, *pE) == RET_SUCCEED)
            {
                context.ddlGenContext.ddlGenAction.m_installLevel = EV_AAAInstallLevel;

                if (context.optimLevel == 0)
                {
                    if (DBA_InitDictInfo() != RET_SUCCEED)
                    {
                        status = -1;
                    }
                }
                else if (context.ddlGenContext.ddlGenAction.m_installLevel < 4 && context.optimLevel < 2)
                {
                    if (DBA_InitDictInfo(FALSE, TRUE) != RET_SUCCEED)
                    {
                        status = -1;
                    }
                }
                else
                {
                    DICT_AddNewDictEntity(0, InvalidEntity, "invalid_entity", "invalid_entity");

                    DICT_DATATP_ST dictDataTypeSt;

                    DBA_GetDictDataTpTab().resize(LastType);

                    dictDataTypeSt.dictId = 1;
                    strcpy(dictDataTypeSt.name, "code_t");
                    strcpy(dictDataTypeSt.label, "code_t");
                    u_strcpy(dictDataTypeSt.uniLabel, u"code_t");
                    strcpy(dictDataTypeSt.sqlName, "code_t");
                    strcpy(dictDataTypeSt.equivType, "varchar2(255 char)");
                    strcpy(dictDataTypeSt.equivTypeSyb, "varchar(255)");
                    strcpy(dictDataTypeSt.equivTypeOra, "varchar2(255 char)");
                    strcpy(dictDataTypeSt.equivTypeNuoDB, "character(255)");
                    strcpy(dictDataTypeSt.equivTypeMsSql, "nvarchar(255)");
                    strcpy(dictDataTypeSt.equivTypePgs, "varchar(255)");
                    dictDataTypeSt.progN = static_cast<SMALLINT_T>(dictDataTypeSt.dictId - 1);
                    dictDataTypeSt.custAuthFlg = 1;
                    dictDataTypeSt.defMaxDbLenN = 60;
                    dictDataTypeSt.defDefaultDisplayLenN = 60;

                    DBA_GetDictDataTpTab()[dictDataTypeSt.progN] = dictDataTypeSt;

                    dictDataTypeSt.dictId = 3;
                    strcpy(dictDataTypeSt.name, "datetime_t");
                    strcpy(dictDataTypeSt.label, "datetime_t");
                    u_strcpy(dictDataTypeSt.uniLabel, u"datetime_t");
                    strcpy(dictDataTypeSt.sqlName, "datetime_t");
                    strcpy(dictDataTypeSt.equivType, "datetime");
                    strcpy(dictDataTypeSt.equivTypeSyb, "datetime");
                    strcpy(dictDataTypeSt.equivTypeOra, "timestamp");
                    strcpy(dictDataTypeSt.equivTypeNuoDB, "timestamp");
                    strcpy(dictDataTypeSt.equivTypeMsSql, "datetime");
                    dictDataTypeSt.progN = static_cast<SMALLINT_T>(dictDataTypeSt.dictId - 1);
                    dictDataTypeSt.custAuthFlg = 1;
                    dictDataTypeSt.defMaxDbLenN = 0;
                    dictDataTypeSt.defDefaultDisplayLenN = 0;

                    DBA_GetDictDataTpTab()[dictDataTypeSt.progN] = dictDataTypeSt;

                    dictDataTypeSt.dictId = 4;
                    strcpy(dictDataTypeSt.name, "dict_t");
                    strcpy(dictDataTypeSt.label, "dict_t");
                    u_strcpy(dictDataTypeSt.uniLabel, u"dict_t");
                    strcpy(dictDataTypeSt.sqlName, "dict_t");
                    strcpy(dictDataTypeSt.equivType, "numeric(14,0)");
                    strcpy(dictDataTypeSt.equivTypeSyb, "numeric(14,0)");
                    strcpy(dictDataTypeSt.equivTypeOra, "number(14,0)");
                    strcpy(dictDataTypeSt.equivTypeNuoDB, "bigint");
                    strcpy(dictDataTypeSt.equivTypeMsSql, "numeric(14,0)");
                    strcpy(dictDataTypeSt.equivTypePgs, "numeric(14,0)");
                    dictDataTypeSt.progN = static_cast<SMALLINT_T>(dictDataTypeSt.dictId - 1);
                    dictDataTypeSt.custAuthFlg = 1;
                    dictDataTypeSt.defMaxDbLenN = 0;
                    dictDataTypeSt.defDefaultDisplayLenN = 0;

                    DBA_GetDictDataTpTab()[dictDataTypeSt.progN] = dictDataTypeSt;

                    dictDataTypeSt.dictId = 5;
                    strcpy(dictDataTypeSt.name, "enum_t");
                    strcpy(dictDataTypeSt.label, "enum_t");
                    u_strcpy(dictDataTypeSt.uniLabel, u"enum_t");
                    strcpy(dictDataTypeSt.sqlName, "enum_t");
                    strcpy(dictDataTypeSt.equivType, "tinyint");
                    strcpy(dictDataTypeSt.equivTypeSyb, "tinyint");
                    strcpy(dictDataTypeSt.equivTypeOra, "number(3,0)");
                    strcpy(dictDataTypeSt.equivTypeNuoDB, "numeric(3,0)");
                    strcpy(dictDataTypeSt.equivTypeMsSql, "tinyint");
                    strcpy(dictDataTypeSt.equivTypePgs, "smallint");
                    dictDataTypeSt.progN = static_cast<SMALLINT_T>(dictDataTypeSt.dictId - 1);
                    dictDataTypeSt.custAuthFlg = 1;
                    dictDataTypeSt.defMaxDbLenN = 0;
                    dictDataTypeSt.defDefaultDisplayLenN = 0;

                    DBA_GetDictDataTpTab()[dictDataTypeSt.progN] = dictDataTypeSt;

                    dictDataTypeSt.dictId = 7;
                    strcpy(dictDataTypeSt.name, "flag_t");
                    strcpy(dictDataTypeSt.label, "flag_t");
                    u_strcpy(dictDataTypeSt.uniLabel, u"flag_t");
                    strcpy(dictDataTypeSt.sqlName, "flag_t");
                    strcpy(dictDataTypeSt.equivType, "tinyint");
                    strcpy(dictDataTypeSt.equivTypeSyb, "tinyint");
                    strcpy(dictDataTypeSt.equivTypeOra, "number(3,0)");
                    strcpy(dictDataTypeSt.equivTypeNuoDB, "numeric(3,0)");
                    strcpy(dictDataTypeSt.equivTypeMsSql, "tinyint");
                    strcpy(dictDataTypeSt.equivTypePgs, "smallint");
                    dictDataTypeSt.progN = static_cast<SMALLINT_T>(dictDataTypeSt.dictId - 1);
                    dictDataTypeSt.custAuthFlg = 1;
                    dictDataTypeSt.defMaxDbLenN = 0;
                    dictDataTypeSt.defDefaultDisplayLenN = 0;

                    DBA_GetDictDataTpTab()[dictDataTypeSt.progN] = dictDataTypeSt;

                    dictDataTypeSt.dictId = 8;
                    strcpy(dictDataTypeSt.name, "id_t");
                    strcpy(dictDataTypeSt.label, "id_t");
                    u_strcpy(dictDataTypeSt.uniLabel, u"id_t");
                    strcpy(dictDataTypeSt.sqlName, "id_t");
                    strcpy(dictDataTypeSt.equivType, "numeric(14,0)");
                    strcpy(dictDataTypeSt.equivTypeSyb, "numeric(14,0)");
                    strcpy(dictDataTypeSt.equivTypeOra, "number(14,0)");
                    strcpy(dictDataTypeSt.equivTypeNuoDB, "bigint");
                    strcpy(dictDataTypeSt.equivTypeMsSql, "numeric(14,0)");
                    strcpy(dictDataTypeSt.equivTypePgs, "bigint");
                    dictDataTypeSt.progN = static_cast<SMALLINT_T>(dictDataTypeSt.dictId - 1);
                    dictDataTypeSt.custAuthFlg = 1;
                    dictDataTypeSt.defMaxDbLenN = 0;
                    dictDataTypeSt.defDefaultDisplayLenN = 0;

                    DBA_GetDictDataTpTab()[dictDataTypeSt.progN] = dictDataTypeSt;

                    dictDataTypeSt.dictId = 9;
                    strcpy(dictDataTypeSt.name, "info_t");
                    strcpy(dictDataTypeSt.label, "info_t");
                    u_strcpy(dictDataTypeSt.uniLabel, u"info_t");
                    strcpy(dictDataTypeSt.sqlName, "info_t");
                    strcpy(dictDataTypeSt.equivType, "varchar2(255 char)");
                    strcpy(dictDataTypeSt.equivTypeSyb, "varchar(255)");
                    strcpy(dictDataTypeSt.equivTypeOra, "varchar2(255 char)");
                    strcpy(dictDataTypeSt.equivTypeNuoDB, "character(255)");
                    strcpy(dictDataTypeSt.equivTypeMsSql, "nvarchar(255)");
                    strcpy(dictDataTypeSt.equivTypePgs, "varchar(255)");
                    dictDataTypeSt.progN = static_cast<SMALLINT_T>(dictDataTypeSt.dictId - 1);
                    dictDataTypeSt.custAuthFlg = 1;
                    dictDataTypeSt.defMaxDbLenN = 80;
                    dictDataTypeSt.defDefaultDisplayLenN = 80;

                    DBA_GetDictDataTpTab()[dictDataTypeSt.progN] = dictDataTypeSt;

                    dictDataTypeSt.dictId = 12;
                    strcpy(dictDataTypeSt.name, "mask_t");
                    strcpy(dictDataTypeSt.label, "mask_t");
                    u_strcpy(dictDataTypeSt.uniLabel, u"mask_t");
                    strcpy(dictDataTypeSt.sqlName, "mask_t");
                    strcpy(dictDataTypeSt.equivType, "int");
                    strcpy(dictDataTypeSt.equivTypeSyb, "int");
                    strcpy(dictDataTypeSt.equivTypeOra, "number(10,0)");
                    strcpy(dictDataTypeSt.equivTypeNuoDB, "numeric(10,0)");
                    strcpy(dictDataTypeSt.equivTypeMsSql, "int");
                    strcpy(dictDataTypeSt.equivTypePgs, "integer");
                    dictDataTypeSt.progN = static_cast<SMALLINT_T>(dictDataTypeSt.dictId - 1);
                    dictDataTypeSt.custAuthFlg = 1;
                    dictDataTypeSt.defMaxDbLenN = 0;
                    dictDataTypeSt.defDefaultDisplayLenN = 0;

                    DBA_GetDictDataTpTab()[dictDataTypeSt.progN] = dictDataTypeSt;

                    dictDataTypeSt.dictId = 14;
                    strcpy(dictDataTypeSt.name, "name_t");
                    strcpy(dictDataTypeSt.label, "name_t");
                    u_strcpy(dictDataTypeSt.uniLabel, u"name_t");
                    strcpy(dictDataTypeSt.sqlName, "name_t");
                    strcpy(dictDataTypeSt.equivType, "varchar2(60 char)");
                    strcpy(dictDataTypeSt.equivTypeSyb, "varchar(60)");
                    strcpy(dictDataTypeSt.equivTypeOra, "varchar2(60 char)");
                    strcpy(dictDataTypeSt.equivTypeNuoDB, "character(60)");
                    strcpy(dictDataTypeSt.equivTypeMsSql, "nvarchar(60)");
                    strcpy(dictDataTypeSt.equivTypePgs, "varchar(60)");
                    dictDataTypeSt.progN = static_cast<SMALLINT_T>(dictDataTypeSt.dictId - 1);
                    dictDataTypeSt.custAuthFlg = 1;
                    dictDataTypeSt.defMaxDbLenN = 60;
                    dictDataTypeSt.defDefaultDisplayLenN = 60;

                    DBA_GetDictDataTpTab()[dictDataTypeSt.progN] = dictDataTypeSt;

                    dictDataTypeSt.dictId = 15;
                    strcpy(dictDataTypeSt.name, "note_t");
                    strcpy(dictDataTypeSt.label, "note_t");
                    u_strcpy(dictDataTypeSt.uniLabel, u"note_t");
                    strcpy(dictDataTypeSt.sqlName, "note_t");
                    strcpy(dictDataTypeSt.equivType, "varchar2(255 char)");
                    strcpy(dictDataTypeSt.equivTypeSyb, "varchar(255)");
                    strcpy(dictDataTypeSt.equivTypeOra, "varchar2(255 char)");
                    strcpy(dictDataTypeSt.equivTypeNuoDB, "character(255)");
                    strcpy(dictDataTypeSt.equivTypeMsSql, "nvarchar(255)");
                    strcpy(dictDataTypeSt.equivTypePgs, "varchar(255)");
                    dictDataTypeSt.progN = static_cast<SMALLINT_T>(dictDataTypeSt.dictId - 1);
                    dictDataTypeSt.custAuthFlg = 1;
                    dictDataTypeSt.defMaxDbLenN = 255;
                    dictDataTypeSt.defDefaultDisplayLenN = 255;

                    DBA_GetDictDataTpTab()[dictDataTypeSt.progN] = dictDataTypeSt;

                    dictDataTypeSt.dictId = 16;
                    strcpy(dictDataTypeSt.name, "number_t");
                    strcpy(dictDataTypeSt.label, "number_t");
                    u_strcpy(dictDataTypeSt.uniLabel, u"number_t");
                    strcpy(dictDataTypeSt.sqlName, "number_t");
                    strcpy(dictDataTypeSt.equivType, "numeric(29,9)");
                    strcpy(dictDataTypeSt.equivTypeSyb, "numeric(29,9)");
                    strcpy(dictDataTypeSt.equivTypeOra, "number(29,9)");
                    strcpy(dictDataTypeSt.equivTypeNuoDB, "numeric(29,9)");
                    strcpy(dictDataTypeSt.equivTypeMsSql, "numeric(29,9)");
                    dictDataTypeSt.progN = static_cast<SMALLINT_T>(dictDataTypeSt.dictId - 1);
                    dictDataTypeSt.custAuthFlg = 1;
                    dictDataTypeSt.defMaxDbLenN = 0;
                    dictDataTypeSt.defDefaultDisplayLenN = 0;

                    DBA_GetDictDataTpTab()[dictDataTypeSt.progN] = dictDataTypeSt;

                    dictDataTypeSt.dictId = 20;
                    strcpy(dictDataTypeSt.name, "smallint_t");
                    strcpy(dictDataTypeSt.label, "smallint_t");
                    u_strcpy(dictDataTypeSt.uniLabel, u"smallint_t");
                    strcpy(dictDataTypeSt.sqlName, "smallint_t");
                    strcpy(dictDataTypeSt.equivType, "smallint");
                    strcpy(dictDataTypeSt.equivTypeSyb, "smallint");
                    strcpy(dictDataTypeSt.equivTypeOra, "number(5,0)");
                    strcpy(dictDataTypeSt.equivTypeNuoDB, "numeric(5,0)");
                    strcpy(dictDataTypeSt.equivTypeMsSql, "smallint");
                    strcpy(dictDataTypeSt.equivTypePgs, "smallint");
                    dictDataTypeSt.progN = static_cast<SMALLINT_T>(dictDataTypeSt.dictId - 1);
                    dictDataTypeSt.custAuthFlg = 1;
                    dictDataTypeSt.defMaxDbLenN = 0;
                    dictDataTypeSt.defDefaultDisplayLenN = 0;

                    DBA_GetDictDataTpTab()[dictDataTypeSt.progN] = dictDataTypeSt;

                    dictDataTypeSt.dictId = 21;
                    strcpy(dictDataTypeSt.name, "sysname_t");
                    strcpy(dictDataTypeSt.label, "sysname_t");
                    u_strcpy(dictDataTypeSt.uniLabel, u"sysname_t");
                    strcpy(dictDataTypeSt.sqlName, "sysname_t");
                    strcpy(dictDataTypeSt.equivType, "varchar2(30 char)");
                    strcpy(dictDataTypeSt.equivTypeSyb, "varchar(30)");
                    strcpy(dictDataTypeSt.equivTypeOra, "varchar2(30 char)");
                    strcpy(dictDataTypeSt.equivTypeNuoDB, "character(30)");
                    strcpy(dictDataTypeSt.equivTypeMsSql, "nvarchar(30)");
                    strcpy(dictDataTypeSt.equivTypePgs, "varchar(30)");
                    dictDataTypeSt.progN = static_cast<SMALLINT_T>(dictDataTypeSt.dictId - 1);
                    dictDataTypeSt.custAuthFlg = 1;
                    dictDataTypeSt.defMaxDbLenN = 30;
                    dictDataTypeSt.defDefaultDisplayLenN = 30;

                    DBA_GetDictDataTpTab()[dictDataTypeSt.progN] = dictDataTypeSt;

                    dictDataTypeSt.dictId = 44;
                    strcpy(dictDataTypeSt.name, "string1000_t");
                    strcpy(dictDataTypeSt.label, "string1000_t");
                    u_strcpy(dictDataTypeSt.uniLabel, u"string1000_t");
                    strcpy(dictDataTypeSt.sqlName, "string1000_t");
                    strcpy(dictDataTypeSt.equivType, "varchar2(1000 char)");
                    strcpy(dictDataTypeSt.equivTypeSyb, "varchar(1000)");
                    strcpy(dictDataTypeSt.equivTypeOra, "varchar2(1000 char)");
                    strcpy(dictDataTypeSt.equivTypeNuoDB, "character(1000)");
                    strcpy(dictDataTypeSt.equivTypeMsSql, "nvarchar(1000)");
                    strcpy(dictDataTypeSt.equivTypePgs, "varchar(1000)");
                    dictDataTypeSt.progN = static_cast<SMALLINT_T>(dictDataTypeSt.dictId - 1);
                    dictDataTypeSt.custAuthFlg = 1;
                    dictDataTypeSt.defMaxDbLenN = 30;
                    dictDataTypeSt.defDefaultDisplayLenN = 30;

                    DBA_GetDictDataTpTab()[dictDataTypeSt.progN] = dictDataTypeSt;
                }
            }
            else
            {
                status = -1;
	        }
        }
        else
        {
            status = -1;
        }

        if (status == 0)
        {
            if (context.optimLevel < 2 && context.ddlGenContext.ddlGenAction.m_installLevel < 4)
            {
                string           server;
                string           sqlserver;
                GEN_GetApplInfo(ApplSqlServerName, sqlserver);
                GEN_GetApplInfo(ApplServerName, server);

                if (context.serverName.empty())
                {
                    context.serverName = server;
                }
                else if (context.serverName.compare(sqlserver) != 0 &&
                         context.serverName.compare(server) != 0)
                {
                    server = context.serverName;
                    GEN_SetApplInfo(ApplServerName, server);
                }

                if (context.serverName.empty() == false && context.serverName.compare(sqlserver) != 0)
                {
                    context.serverName = server;
                }
            }

            DBA_LoadAndCheckDbTimeZone(false);   /* PMSTA-43454 - DDV - 210120 */
            if (GEN_InitPoolConnectionFinal() != RET_SUCCEED)
            {
                status = 1;
            }

            if (context.serverName.empty() == false)
            {
                context.finSrvConnHelperPtr = new DbiConnectionHelper(AAATransactionEnum::NotTransactionnal, FinServer);
                context.currServerName = context.serverName;
                context.finSrvConnHelperPtr->setSilentMode(true);
            }

            context.sqlConnHelperPtr = new DbiConnectionHelper(AAATransactionEnum::NotTransactionnal, SqlServer);
        }

        if (status == 0)
        {
            context.bStartUp = true;
        }
    }

    if (context.bStartUp &&
        GEN_IsMultiEntity() &&
        context.ddlGenContext.connBusinessEntity.empty() == false &&
        context.ddlGenContext.connBusinessEntity.compare(SYS_GetThreadApplSessionCd()) != 0)
    {
        SYS_SetThreadCurrBusinessEntity(context.ddlGenContext.connBusinessEntity);
    }

    return status;
}

/************************************************************************
**      Global Function Definitions
*************************************************************************/

/************************************************************************
**
**  Function    :   AAASQL_Done()
**
**  Description :
**
**  Argument    :   context
**
** Last Modify  :
*************************************************************************/
STATIC void AAASQL_Done(AAASQL_CONTEXT_STP &context)
{
    if (context->istream.level)
    {
        int n;

        for (n = 0; n < context->istream.level; n++)
            if (context->istream.streams[n].fp != stdin)
            {
                fclose(context->istream.streams[n].fp);
                FREE(context->istream.streams[n].path);
            }

        FREE(context->istream.streams);
    }

    /* cleaning ostream */
    if (context->ostream.fp != stdout)
    {
        fclose(context->ostream.fp);
        FREE(context->ostream.path);
    }

    /* cleaning estream */
    if (context->estream.fp != stderr)
    {
        fclose(context->estream.fp);
        FREE(context->estream.path);
    }

    delete context->scriptDdlGenPtr;
    delete context->ddlGenPtr;
    delete context->sqlConnHelperPtr;
    delete context->finSrvConnHelperPtr;

    if (context->bStartUp == true)  /* PMSTA-26255 - LJE - 180710 */
    {
        delete context;
        context = nullptr;
        SYS_Shutdown(APP_EXIT);
    }
    else
    {
        delete context;
        context = nullptr;
    }
}

/************************************************************************
**
**  Function    :   AAASQL_Expand()
**
**  Description :
**
**  Argument    :   source
**                  target
**
*************************************************************************/
STATIC void AAASQL_Expand(char *source, char **target)
{
    char *head = NULL;
    char *tail = NULL;

    char *scan = NULL;

    *target = STRDUP(source);

    while ((scan = strchr(*target, '$')) != NULL)
    {
        char *string, *variable;

        int length;

        char *p = NULL;
        char *q = NULL;

        head = *target;

        *scan = '\0';

        if (*(scan + 1) == '{')
        {
            p = q = scan + 2;
            q = q + strcspn(q, "}");

            tail = *q ? q + 1 : q;
        }
        else
        {
            p = q = scan + 1;
            while (isalnum(*q) || *q == '_')
                q++;

            tail = q;
        }

        string = (char*)REALLOC(NULL, q - p + 1);

        memcpy(string, p, q - p);
        string[q - p] = '\0';

        variable = getenv(string);

        FREE(string);

        length = SYS_StrLen(head) + SYS_StrLen(tail);
        if (variable != NULL)
            length += SYS_StrLen(variable);

        *target = (char*)REALLOC(target, length + 1);

        strcpy(*target, head);
        if (variable != NULL)
            strcat(*target, variable);
        strcat(*target, tail);

        FREE(head);
    }
}

/************************************************************************
**
**  Function    :   AAASQL_AddIStream()
**
**  Description :
**
**  Argument    :   context
**                  path
**
**  Return      :   0 on success, -1 elsewhere
**
*************************************************************************/
STATIC int AAASQL_AddIStream(AAASQL_CONTEXT_ST &context, char *path)
{
    AAASQL_ISTREAM_STP istream = &context.istream;  FILE *fp;
    CURRENTCHARSETCODE_ENUM  charsetCode = CurrentCharsetCode_IsNull; /* DLA - REF9303 - 030926 */
    char *file = NULL;

    if (path == NULL)
    {
        fp = stdin;
    }
    else
    {
        char *targetPath = nullptr;

        AAASQL_Expand(path, &targetPath);

        if ((fp = fopen(targetPath, "r")) != NULL)
        {
            file = strrchr(targetPath, '/');

            if (file++ != NULL)
                file = STRDUP(file);
            else
                file = STRDUP(path);
        }
        else
        {
            context.ddlGenPtr->printMsg(RET_FILE_ERR_NOTEXIST, string("Cannot open the file: ").append(targetPath).c_str());
            FREE(targetPath);

            return -1;
        }

        FREE(targetPath);
    }

    istream->streams =
        (AAASQL_STREAM_STP)REALLOC(
            istream->streams,
            ++istream->level * sizeof(AAASQL_STREAM_ST));

    istream->streams[istream->level - 1].fp = fp;
    istream->streams[istream->level - 1].path = file;
    istream->streams[istream->level - 1].line = 0;

    GEN_GetApplInfo(ApplCurrentCharsetInputEnum, &charsetCode);

    if (charsetCode == CurrentCharsetCode_IsNull)
        GEN_GetApplInfo(ApplCurrentCharsetCodeEnum, &charsetCode);


    istream->streams[istream->level - 1].CharSet = charsetCode;

    return 0;
}

/************************************************************************
**
**  Function    :   AAASQL_GetLine()
**
**  Description :
**
**  Argument    :   stream
**                  line
**
**  Return      :   0 on success, 1 on EOF
**
*************************************************************************/
STATIC char *AAASQL_GetString(char *string, int size, FILE *stream)
{
    char *status;

    int n = 0;

    while ((status = fgets(string, size, stream)) == NULL && !feof(stream)
           && errno == EINTR && n < MAX_EINTR)
    {
        SYS_MilliSleep(50); n++;
    }

    return status;
}

/************************************************************************
**
**  Function    :   AAASQL_GetLine()
**
**  Description :
**
**  Argument    :   stream
**                  line
**
**  Return      :   0 on success, 1 on EOF
**
*************************************************************************/
STATIC bool AAASQL_GetLine(AAASQL_STREAM_STP stream, char **line)
{
    char    *segment;
    unsigned    size;
    unsigned  length;

    segment = *line = (char *)REALLOC(*line, size = SEGMENT);

    if (AAASQL_GetString(segment, SEGMENT, stream->fp) != NULL)
    {
        char *eol = NULL;

        do
        {
            if (((eol = strchr(segment, '\r')) != NULL) || ((eol = strchr(segment, '\n')) != NULL))
            {
                stream->line++;

                if (eol == *line || eol[-1] != '\\')
                    break;

                *(segment = &eol[-1]) = '\0';

                length = size - (unsigned int)(segment - *line);
            }
            else
            {
                *line =
                    (char *)REALLOC(*line, size += SEGMENT);

                segment = *line + size - (length = SEGMENT + 1);
            }
        } while (AAASQL_GetString(segment, length, stream->fp) != NULL);

        if (eol != NULL)
            *eol = '\0';
    }
    else
        return  false;

    return true;
}

/************************************************************************
**
**  Function    :   AAASQL_LoadILine()
**
**  Description :
**
**  Argument    :   context
**                  line
**  Return      :   true if line returned
**
*************************************************************************/
bool AAASQL_LoadILine(AAASQL_CONTEXT_ST &context, char **line, AAALogger& log)
{
    AAASQL_ISTREAM_STP istream = &context.istream;

    while (istream->level > 0)
    {
        AAASQL_STREAM_STP stream = &istream->streams[istream->level - 1];

        stream = &istream->streams[istream->level - 1];

        if (AAASQL_GetLine(stream, line) && EV_SigEvent.load() != SIGTERM && EV_SigEvent.load() != SIGINT)
        {
            if (log.isDebugEnabled())
            {
                std::ostringstream oss;
                oss << "Input= " << (*line);
                log.debug(oss.str());
            }

            return true;
        }

        if (stream->fp != stdin)
        {
            fclose(stream->fp);
            FREE(stream->path);
        }

        --istream->level;

        if (istream->level == 0)
        {
            FREE(istream->streams);
        }
        else
        {
            istream->streams =
                (AAASQL_STREAM_STP)REALLOC(
                    istream->streams,
                    istream->level * sizeof(AAASQL_STREAM_ST));
        }
    }
    return false;
}

/************************************************************************
**
**  Function    :   AAASQL_ReadAndTreatLines()
**
**  Description :
**
**  Argument    :   context
**                  line
**  Return      :   0 on success, 1 on empty, -1 on error
**
*************************************************************************/
int AAASQL_ReadAndTreatLines(AAASQL_CONTEXT_ST &context, AAALogger &log, std::vector<std::string> &toTreatVector)
{
    int   gblRet       = 0;
    char *line         = nullptr;
    bool  bExitByExit  = false;
    bool  bToRepeat    = false;
    bool  bGenIf       = false;

    string toTreatLine;

    std::vector<std::string> toExecVector;

    auto toTreatIt = toTreatVector.begin();

    bool bContinue = true;
    if (toTreatVector.empty())
    {
        bContinue = AAASQL_LoadILine(context, &line, log);
        if (bContinue)
        {
            toTreatLine = line;
        }
    }
    else
    {
        bContinue = toTreatIt != toTreatVector.end();
        if (bContinue)
        {
            toTreatLine = (*toTreatIt);
        }
    }

    std::set<std::string> currEndOfCommands;

    while (bContinue)
    {
        RET_CODE ret = RET_SUCCEED;

        size_t   begPos = toTreatLine.find_first_not_of(" \t");
        if (begPos == string::npos)
        {
            begPos = 0;
        }

        if (toTreatLine.c_str()[0] != 0 &&
            (strncasecmp(toTreatLine.substr(begPos).c_str(), "quit", 4) == 0 ||
             strncasecmp(toTreatLine.substr(begPos).c_str(), "exit", 4) == 0))
        {
            bExitByExit = true;
            break;
        }

        if (bToRepeat)
        {
            if (toTreatLine.find("#END_FOR_EACH_DATA") == begPos)
            {
                if (context.scriptDdlGenPtr->getResultSetDataPtr() != nullptr)
                {
                    DdlGenData *resultSetDataPtr = context.scriptDdlGenPtr->getResultSetDataPtr();
                    bool savedBKeepResultSetData = context.scriptDdlGenPtr->bKeepResultSetData;

                    context.scriptDdlGenPtr->bKeepResultSetData = true;
                    for (context.dataIdx = 0; context.dataIdx < resultSetDataPtr->getResultSetDataNbr(0); ++context.dataIdx)
                    {
                        if ((ret = AAASQL_ReadAndTreatLines(context, log, toExecVector)) != RET_SUCCEED)
                        {
                            gblRet = ret;
                        }
                    }
                    context.scriptDdlGenPtr->bKeepResultSetData = savedBKeepResultSetData;
                }

                toExecVector.clear();
                bToRepeat = false;
                context.dataIdx = 0;
            }
            else
            {
                toExecVector.push_back(toTreatLine);
            }
        }
        else if (bGenIf)
        {
            if (toTreatLine.find("#GEN_IF_END") == begPos)
            {
                toExecVector.push_back(toTreatLine);

                if ((ret = AAASQL_ReadAndTreatLines(context, log, toExecVector)) != RET_SUCCEED)
                {
                    gblRet = ret;
                }

                toExecVector.clear();
                bGenIf = false;

                context.bSkipNextBloc = false;
            }
            else
            {
                toExecVector.push_back(toTreatLine);
            }
        }
        else if (toTreatLine.find("#FOR_EACH_DATA") == begPos)
        {
            bToRepeat = true;
        }
        else if (toTreatLine.find("#GEN_IF_BEGIN") == begPos &&
                 (toTreatVector.empty() || toTreatIt != toTreatVector.begin()))
        {
            if (context.currBlock.str().empty() == false)
            {
                string goStr("go");
                if ((ret = AAASQL_TreatLine(context, goStr, currEndOfCommands, log)) != RET_SUCCEED)
                {
                    gblRet = ret;
                }
            }

            toExecVector.push_back(toTreatLine);
            bGenIf = true;
        }
        else if (toTreatLine.find("#EXEC_SQL_QUERY") == begPos)
        {
            vector<string>  tokens;
            DdlGen::tokenizeStr(tokens, toTreatLine);

            if (tokens.size() > 1 && tokens[1][0] == '@')
            {
                auto queryVar = context.ddlGenVarHelperPtr->getVariable(tokens[1]);
                std::string query;
                if (queryVar != nullptr)
                {
                    query = queryVar->getValue();
                }

                AAAValueGuardBool bForceSingleCmd(context.scriptDdlGenPtr->context->m_bForceSingleCmd, true);
                string goStr("go");
                if (query.empty() ||
                    (ret = AAASQL_TreatLine(context, query, currEndOfCommands, log)) != RET_SUCCEED ||
                    (ret = AAASQL_TreatLine(context, goStr, currEndOfCommands, log)) != RET_SUCCEED)
                {
                    gblRet = ret;

                    /* PMSTA-32111 - LJE - 180710 */
                    if (gblRet == RET_ITFC_ERR_STARTUP)
                    {
                        bExitByExit = true;
                        break;
                    }
                }
            }
        }
        else
        {
            if ((ret = AAASQL_TreatLine(context, toTreatLine, currEndOfCommands, log)) != RET_SUCCEED)
            {
                gblRet = ret;

                /* PMSTA-32111 - LJE - 180710 */
                if (gblRet == RET_ITFC_ERR_STARTUP)
                {
                    bExitByExit = true;
                    break;
                }
            }
        }

        if (toTreatVector.empty())
        {
            bContinue = AAASQL_LoadILine(context, &line, log);
            if (bContinue)
            {
                toTreatLine = line;
            }
        }
        else
        {
            bContinue = (++toTreatIt) != toTreatVector.end();
            if (bContinue)
            {
                toTreatLine = (*toTreatIt);
            }
        }
    }

    if (bExitByExit == false &&
        context.currBlock.str().empty() == false)
    {
        RET_CODE ret = RET_SUCCEED;

        string goStr("go");
        if ((ret = AAASQL_TreatLine(context, goStr, currEndOfCommands, log)) != RET_SUCCEED)
        {
            gblRet = ret;
        }
    }
    else if (context.bStartUp == false &&
             context.currBlock.str().empty() == true)
    {
        /* PMSTA-32111 - LJE - 180710 */
        RET_CODE ret = RET_SUCCEED;

        context.lastBlockStr = "check";

        string goStr("/");
        if ((ret = AAASQL_TreatLine(context, goStr, currEndOfCommands, log)) != RET_SUCCEED)
        {
            gblRet = ret;
        }
    }
    FREE(line);

    return gblRet;
}


/************************************************************************
**
**  Function    :   main()
**
**  Description :   SQL Interface Entry Point
**
**  Arguments   :
**
**  Return      :
**
**  Last modif. :    PMSTA-24510 - 220816 - PMO : Fusion & Dispatcher in HTTP
**                   PMSTA-25236 - 231116 - PMO : Remove AAACORE environment variable handling
**
*************************************************************************/
int mainAaaSql(int argc, char **argv)
{
    AAALogger::Initializer loggerInitialiser;                /* PMSTA-32895 - 140918 - FME Cluster Logger */
    AaaMetaDict::load();

#ifdef NTWIN
    SetConsoleCtrlHandler(NULL, true);   /* PMSTA-31097 - DLA - 180425 */
#endif
    int gblRet = 0;
    MemoryPool mp;

    SV_msgFile = stderr;

    CURRENTCHARSETCODE_ENUM charsetCode = CurrentCharsetCode_IsNull;
    GEN_SetApplInfo(ApplCurrentCharsetCodeEnum, &charsetCode);

    SYSNAME_T initName = "";
    GEN_SetApplInfo(ApplSqrDbName, initName);
    GEN_SetApplInfo(ApplPermTslDbName, initName);
    GEN_SetApplInfo(ApplTempTslDbName, initName);

    char *hideArgsFlg = NULL, *startupParam = NULL;
    firstExit.store(true);

    /* PMSTA-46966 - FME- 2021-11-12 - restore initialisation to produce LF instead of CRLF */
#ifdef NTWIN 
    NT_Init(AAAVersion::getVersion().getVersionCode().c_str(), AAAVersion::getVersion().getFixCode().c_str(), SV_KeywordNT);
#endif

    if (SYS_InitLockTable() != TRUE)
    {
        MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "SYS_InitLockTable() failed");
        return(1);
    }

    EV_WarningMsg = FALSE;

    /* Read arguments in environment variable according to HIDE_ARGS value */
    if ((hideArgsFlg = SYS_GetEnv("HIDE_ARGS")) != NULL &&
        strcmp(hideArgsFlg, "1") == 0 &&
        (startupParam = SYS_GetEnv("AAA_STARTUP_PARAMS")) != NULL)
    {
        int		argNbr = 0;
        char	**argTab = NULL;

        /* Cut startupParam in argNbr and copy in argTab */
        if (GEN_TreatStartupParams(startupParam, argv, &argNbr, &argTab, mp) == FALSE)
            return(0);

        /* Send created argTab to GetOption */
        if (AAASQL_GetOption(argNbr, argTab))
        {
            usage();
            return 1;
        }
    }
    else if (AAASQL_GetOption(argc, argv))
    {
        usage();
        return 1;
    }

    GEN_InitApplName();                                                 /* PMSTA-32895 - 140119 - FME Cluster Logger */

    // Telemetry Init after appl name initialisation
    AAATelemetry::Initializer telemetryInitializer(/*startByDefault*/false); ;             /* PMSTA-54809 - 20231102 - FME Opentelemetry Log4cplus log appender */

    loggerInitialiser.configure(false /*startWatcherThread*/);          /* PMSTA-32895 - 140119 - FME Cluster Logger */
    telemetryInitializer.configure();

    if (GEN_Initial() != RET_SUCCEED)
    {
        MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "GEN_Initial() failed");
        return(1);
    }

    AAASQL_CONTEXT_STP context = new  AAASQL_CONTEXT_ST(EV_RdbmsVendor);

    SYS_InitCallStack();
    atexit(SYS_RemoveCallStack);

    GEN_DisplayEnv();

    if (AAASQL_Init(*context) == false)
    {
        return 1;
    }
#ifndef SANITIZER_BUILD
    /* PMSTA-31097 - DLA - 180426 */
    INSTALL_SIGTERM;
#ifndef NTWIN
    INSTALL_SIGINT;
#endif
#endif
     
    AAASQL_AddIStream(*context, SV_InputFilename);

    /* PMSTA-26554 - LJE - 181127 */
    if (SV_InitFilename)
    {
        AAASQL_AddIStream(*context, SV_InitFilename);
    }

    AAALocalConnectionProvider::get().reset(SqlServer); /* DLA - PMSTA-27559 - 170615 */

    if (SV_bArgRunServer)
    {
        if (AAASQL_CreateRunSrvFile(*context) == false)
        {
            gblRet = 255;
        }
    }
    else
    {
        AAALogger log = AAALogger::get(AAALogger::Logger::SqlApplication);
        if (log.isDebugEnabled())
        {
            log.debug(SYS_Stringer("Start (optim.=", context->optimLevel, 
                                   ", verbose=", static_cast<int>(context->verboseLevel),
                                   ", install=", SYS_GetEnvIntOrDefValue("RUN_AAA_INSTALL", 0),
                                   ")"));
        }

        std::vector<std::string> emptyVector;

        gblRet = AAASQL_ReadAndTreatLines(*context, log, emptyVector);

        if (context->sqlConnHelperPtr != nullptr &&
            context->sqlConnHelperPtr->isConnected())
        {
            if (context->scriptDdlGenPtr->bAutoCommit == true)
            {
                context->sqlConnHelperPtr->getConnection()->endTransaction(RET_GET_LEVEL(gblRet) != RET_LEV_ERROR);
            }
            else
            {
                context->sqlConnHelperPtr->getConnection()->endTransaction(FALSE);
            }
        }

        if (log.isDebugEnabled())
        {
            log.debug("Exit");
        }
    }

    if (gblRet == RET_ITFC_ERR_STARTUP)
    {
        char * logFilePath = SYS_GetEnv("AAALOG");
        if (logFilePath != NULL)
        {
            fprintf(stderr, "aaa_sql: initialisation error (see log file: \"%s\")\n", logFilePath);
        }
        else
        {
            fprintf(stderr, "aaa_sql: initialisation error.\n");
        }
    }

    AAASQL_AfterMain(context);
    return gblRet;
}


/************************************************************************
*   Function             : initCallback()
*
*   Description          : No special initialization at this level for the GUI
*
*   Arguments            : None
*
*   Functions call       : None
*
*   Return               : None
*
*   Creation Date        : PMSTA-19735 - 020415 - PMO : OpenServer / P1 / Thread handling
*
*   Last Modif.          :
*
*************************************************************************/
void initCallback()
{
    SYS_SetCallBackThreadDataCtxGeneric(GEN_ThreadDataCtxGenericCreate
                                        , GEN_ThreadDataCtxGenericAllocate
                                        , GEN_ThreadDataCtxGenericInit
                                        , GEN_ThreadDataCtxGenericPrepareApplicationData      /* PMSTA-24076 - 180716 - PMO */
                                        , GEN_ThreadDataCtxGenericCleaningApplicationData     /* PMSTA-24076 - 180716 - PMO */
                                        , GEN_ThreadDataCtxGenericDestroy);
}


/************************************************************************
**
**  Function    :   MAIN_AnalyseParam()
**
**  Description :   Application entry point and exception intercepting
**
**  Arguments   :   argc  parameters number
**                  argv  parameters list (first is application)
**
**  Return      :   0 if ok
**                  >0 if error
**
**  Last modif. :
**
*************************************************************************/
int main(int argc, char *argv[])
{
    int ret = 0;
    int argc1 = 1;
    app = new QCoreApplication(argc1, argv);
    AaaMetaDict::load();

#ifndef _DEBUG
    try
    {
#endif
        initCallback();

        if (true == SYS_CreateMainThreadDataStorage())
        {
            OpenSSLProvider::setup();
            PasswordEncrypted::setup(SYS_GetIt);

            /* PMSTA-36178 - KNI - Load Service - 190716 */
            ExtendedSql  extsql;
            if (ExtendedSqlExitVal::NOT_EXT_SQL_SERVICE == extsql.mainIdentifyExecExtSql(argc, argv))
            {
                ret = mainAaaSql(argc, argv);
            }

            SYS_Shutdown(APP_EXIT);
        }
        else
        {
            ret = 1;
        }
#ifndef _DEBUG
    }
    catch (...)
    {
        ret = RET_GEN_ERR_INVARG;

        if (SYS_IsStateLoggingAllowed())                    /* PMSTA-36212 - 160719 - PMO */
        {
            exceptionHandler(FILEINFO, MSG_SendMesg);
        }
        else
        {
            exceptionHandler(FILEINFO, MSG_SendStderr);     /* PMSTA-36212 - 160719 - PMO */
        }
    }
#endif

    delete app;

    return ret;

}

STATIC void AAASQL_AfterMain(AAASQL_CONTEXT_STP &context) /* DLA - REF7264 - 020326 */
{
    bool valueExpected = true;
    if (firstExit.compare_exchange_strong(valueExpected, false))
    {
        fflush(stdout);
        fflush(stderr);
#ifdef NTWIN
        NT_Done();
#endif

        AAASQL_Done(context);
    }
}

STATIC void usage()
{
    fprintf(stderr,
        "usage: aaa_sql  -U <user> -P <password> [-W] [-S <srv>] [ -I] [-O <level>] [-v] [-V] [-J <database charset>] [-K <charset>] [-L <charset>] [-i <inputfile>] \n"
        "               [-s <separator>] [-h <level>] [-t <timeout> ] [-D <database> ] [-X <options>] [-w <column_width> ] [-b] [-e] [-n <db service name>] [-c <business entity>]\n"
        "       with  <-U>       : SQL Server Username                                              \n"
        "             <-P>       : SQL Server Password                                              \n"
        "             <-W>       : turn on warning messages logging                                 \n"
        "             <-R>       : create a file for run financial servers                          \n"
        "             <-S>       : specifies the name of the financial server to use                \n"
        "                          <srv>      : Financial Server Name                               \n"
        "             <-O>       : Optimisation level:                                              \n"
        "                          0 : Load the full meta-dictionary                                \n"
        "                          1 : Load the minimal meta-dictionary (default)                   \n"
        "                          2 : The meta-dictionary is not loaded,                           \n"
        "                              and no automatic transaction is done                         \n"
        "                          9 : No Triple'A stored procedure is required                     \n"
        "             <-v>       : display the application version                                  \n"
        "             <-V>       : display environment variables                                    \n"
        "             <-J>       : a valid character set. (utf8, iso_1, roman_8, ...).              \n"
        "             <-K>       : output file (console) charset (UTF-8,ISO_8859-8,...)             \n"
        "             <-L>       : input file charset (UTF-8,ISO_8859-8,...)                        \n"
        "             <-i>       : specifies the name of the file to use for input to aaa_sql       \n"
        "             <-r>       : specifies a run command file to initialize aaa_sql               \n"
        "             <-I>       : specifies that connectivity uses the internal address            \n"
        "             <-s>       : resets the column separator character, which is blank by default \n"
        "             <-h>       : verbose level                                                    \n"
        "                          0 : display like isql                                            \n"
        "                          1 : display all information,                                     \n"
        "                              the generated SQL command after Generator process is printed \n"
        "                          2 : display light information (-b)                               \n"
        "                          3 : display only returned data (-b + 'set nocount on')           \n"
        "                          4 : Hide empty result-sets                                       \n"
        "                          5 : display only returned data aligned                           \n"
        "             <-t>       : Specifies the number of seconds before a SQL command times out.  \n"
        "                          (>=0, 0=no limit)                                                \n"
        "             <-D>       : Selects the database/schema in which the aaa_sql session begins. \n"
        "             <-X>       : Set special options                                              \n"
        "                          t : display the application technical version                    \n"
        "                          l : display the header line always in lower case                 \n"
        "             <-w>       : Sets the screen width for output. (not yet implemented, no limit)\n"
        "             <-b>       : Disables the display of the table headers output.                \n"
        "             <-e>       : Echoes input.                                                    \n"
        "             <-n>       : DB Service Name for connecting to DB                             \n"
        "             <-c>       : Business Entity (only use with multi-entity configuration)       \n"
        "                          <business entity> : Business entity to use                       \n"
        );
}


void rebuildPassStoreFile(const std::string & newRandomFileName)
{
    PassStoreFileManager passStoreFile = PassStoreFileManager();

    if (newRandomFileName.empty() == false)
    {
        /*if new masterkey is given then set it in the masterkey*/
        MasterKeyManager::getInstance().m_newRandomFileName = newRandomFileName;
    }

    PassStoreRecord::m_writeToFile = true;

    passStoreFile.processPassStoreFile(); 

    if (passStoreFile.fileUpated() == true)
    {
        cout << "Encryption Successful" << endl;
    }
}

/************************************************************************
**
**  Function    :   AAASQL_TreatLine()
**
**  Description :
**
**  Argument    :   context
**                  line
**  Return      :   0 on success, 1 on empty, -1 on error
**
*************************************************************************/
STATIC RET_CODE AAASQL_TreatLine(AAASQL_CONTEXT_ST &context, string &line, std::set<std::string> &endOfCommands, AAALogger& log)
{
    RET_CODE          ret                 = RET_SUCCEED;
    bool              bExecute            = false;
    bool              bReDo               = false;
    bool              bConfigTask         = false;
    string::size_type pos                 = 0;
    string::size_type endOfCmdRemovedPos  = string::npos;
    VERBOSE_LEVEL_ENUM savedVerboseLeveEn = context.verboseLevel;

    if (endOfCommands.empty())
    {
        endOfCommands = context.defEndOfCommands;
    }

    if (line.empty())
    {
        context.currBlock << endl;
        return ret;
    }

    while ((pos = line.find_first_of("@", pos)) != string::npos)
    {
        pos++;
        string varStr = line.substr(pos, line.find_first_not_of("ABCDEFGHIJKLMNOPQRSTUVWXYZ_0123456789", pos) - pos);
        if (varStr.compare("TASCLOGIN") == 0 ||
            varStr.compare("AAAMAINDB") == 0 ||
            varStr.compare("BASE") == 0 ||
            varStr.compare("AAALOGINDB") == 0 ||
            varStr.compare("TSLPERMDB") == 0 ||
            varStr.compare("TSLTEMPDB") == 0 ||
            varStr.compare("AAAREPDB") == 0 ||
            varStr.compare("AAAREP_DB") == 0 ||
            varStr.compare("SEGMENT") == 0 ||
            varStr.compare("IDX_SEGMENT") == 0 ||
            varStr.compare("TSL_PERM_DATA_SEG") == 0 ||
            varStr.compare("TSL_PERM_IDX_SEG") == 0 ||
            varStr.compare("TSL_TEMP_DATA_SEG") == 0 ||
            varStr.compare("TSL_TEMP_IDX_SEG") == 0)
        {
            line.replace(pos - 1, 1, "$");
        }
    }


    /* PMSTA-42859 - JBC - 201207 : Active Fusion map RPC to SQL*/
    string::size_type fusPos = 0;
    if ((fusPos = line.find("start_manual_fusion_by")) != string::npos)
    {   /* start to get appl_param */
        if (AAASQL_Startup(SV_User, context))
        {
            return RET_ITFC_ERR_STARTUP;
        }
        if (GEN_UseDispatcher() == false)
        {
            if (line.find("#EXEC") == string::npos)
            {
                context.ddlGenPtr->printMsg(RET_DBA_ERR_INVDATA, "aaa_sql: #EXEC prefix is required for start manual fusion in active mode");
            }
            else
            {
                const auto syncServerId = FUS_GetSyncServOrRequestId();
                string newParamSqlName;
                string paramStr = line.substr(fusPos + 26);
                if (DdlGen::find_word(paramStr, "=") != string::npos)
                {
                    newParamSqlName = " @server_id = ";
                }

                if ((fusPos = line.find("start_manual_fusion_by_cd")) != string::npos)
                {
                    line = SYS_Stringer(line.substr(0, fusPos), "start_active_fusion_by_cd ", newParamSqlName, syncServerId, ", " + paramStr);
                }
                else if ((fusPos = line.find("start_manual_fusion_by_id")) != string::npos)
                {
                    line = SYS_Stringer(line.substr(0, fusPos), "start_active_fusion_by_id ", newParamSqlName, syncServerId, ", " + paramStr);
                }
            }
        }
    }

    size_t   beginCmd = line.find_first_not_of(" \t");
    if (beginCmd == string::npos)
    {
        context.currBlock << line << endl;
        return ret;
    }

    size_t   endCmd = line.find_last_not_of(" \t");
    if (endCmd != string::npos)
    {
        endCmd++;
    }
    string   currLine = line.substr(beginCmd, endCmd);

    /* PMSTA-43914 - LJE - 210315 */
    if (beginCmd > 0)
    {
        beginCmd--;
    }
    string   firstCmd = DdlGen::getNextKeyWord(line, beginCmd);     /* PMSTA-43914 - LJE - 210315 */

    /* PMSTA-26252 - LJE - 170210 - Manage comments */
    if (context.bComment == false &&
        (pos = DdlGen::find_first_of(currLine, "-")) != string::npos &&
        pos + 1 < currLine.length() &&
        currLine[pos + 1] == '-')
    {
        currLine = currLine.substr(0, pos);
    }

    pos = 0;
    while (context.bComment || (pos = currLine.find("/*", pos)) != string::npos)
    {
        pos = currLine.find("*/", pos);

        if (pos == string::npos)
        {
            context.currBlock << line << endl;

            context.bComment = true;
            return RET_SUCCEED;
        }
        context.bComment = false;
        currLine = currLine.substr(pos + 2, endCmd - pos - 2);
    }

    if (currLine.empty())
    {
        context.currBlock << line << endl;
        return ret;
    }

    context.bFinSrvMode = false;

    if (endOfCommands.find(firstCmd) != endOfCommands.end())
    {
        endOfCommands.clear();

        if (context.currBlock.str().empty())
        {
            if (currLine.compare("/") == 0 && context.lastBlockStr.empty() == false)
            {
                bReDo = true;
                context.currBlock << context.lastBlockStr;
            }
            else
            {
                return RET_SUCCEED;
            }
        }

        if (firstCmd[0] == '#')
        {
            context.currBlock << line << endl;
        }

        bExecute = true;
    }

    if (bReDo == false)
    {
        if (context.firstCmd.empty() && firstCmd.empty() == false)
        {
            size_t begPos = 0;

            context.firstCmd = firstCmd;

            if (strcasecmp(context.firstCmd.c_str(), "use") == 0)
            {
                currLine.replace(begPos, context.firstCmd.length(), "#USE");
                context.currBlock << currLine << endl;

                line.clear();

                bExecute = true;
            }
            else if (strcasecmp(context.firstCmd.c_str(), "set") == 0)
            {
                currLine.replace(begPos, context.firstCmd.length(), "#SET");
                context.currBlock << currLine << endl;

                line.clear();

                bExecute = true;
                bConfigTask = true;
            }
            else if (context.firstCmd.compare("#SET") == 0)
            {
                context.currBlock << currLine << endl;

                line.clear();

                bExecute = true;
                bConfigTask = true;
            }
            else if (strcasecmp(context.firstCmd.c_str(), "passwordEncrypt") == 0)
            {
                std::string newRandomFileName;
                if (currLine.find("-n") != std::string::npos)
                {
                    if (strstr(currLine.c_str(), "-n") != NULL)
                    {
                        newRandomFileName = strstr(currLine.c_str(), "-n");
                        newRandomFileName.erase(0, 2);
                    }
                }
                ltrim(newRandomFileName);
                rebuildPassStoreFile(newRandomFileName);
                return RET_SUCCEED;
            }
            else if (strcasecmp(context.firstCmd.c_str(), "show") == 0)
            {
                if (context.bStartUp)
                {
                    begPos += context.firstCmd.length();
                    string nextKeyWord = DdlGen::getNextKeyWord(currLine, begPos);

                    context.firstCmd.clear();

                    if (strcasecmp(nextKeyWord.c_str(), "errors") == 0 ||
                        strcasecmp(nextKeyWord.c_str(), "error") == 0)
                    {
                        if (context.connHelperPtr != nullptr &&
                            context.connHelperPtr->getConnection() != nullptr &&
                            context.connHelperPtr->getConnection()->m_msgStructHeaderSt.msgStructTab.empty() == false)
                        {
                            int    firstErrLine = 0;
                            string errorMsg = context.ddlGenPtr->getErrorMessages(context.lastRetCode,
                                                                                  context.connHelperPtr->getConnection()->m_msgStructHeaderSt,
                                                                                  DdlObj_Sql,
                                                                                  context.ddlObjSqlName,
                                                                                  context.lastBlockStr,
                                                                                  firstErrLine);
                            cout << errorMsg << endl;
                        }

                        context.lastBlockStr.clear();
                        return RET_SUCCEED;
                    }
                }
            }
            else if (strcasecmp(context.firstCmd.c_str(), "prompt") == 0 ||
                     strcasecmp(context.firstCmd.c_str(), "print") == 0)
            {
                string textToPrint;

                begPos = DdlGen::find_first_of(currLine, "'\"");
                if (begPos != string::npos)
                {
                    string::size_type endPos = DdlGen::find_first_of(currLine, "'\"", begPos + 1);

                    if (endPos != string::npos)
                    {
                        textToPrint = currLine.substr(begPos + 1, endPos - begPos - 1);
                    }
                }
                else
                {
                    begPos = DdlGen::find_first_not_of(currLine, " \t", context.firstCmd.length() + 1);
                    if (begPos != string::npos)
                    {
                        textToPrint = currLine.substr(begPos);
                    }
                }

                context.firstCmd.clear();

                if (textToPrint.empty() == false)
                {
                    cout << context.scriptDdlGenPtr->buildScript(textToPrint, DdlObj_Sql) << endl;
                }
                else
                {
                    cout << endl;
                }

                return RET_SUCCEED;
            }
            else if (strcasecmp(context.firstCmd.c_str(), "alter") == 0)
            {
                begPos++;
                if (strcasecmp(DdlGen::getNextKeyWord(line, begPos).c_str(), "session") == 0 &&
                    strcasecmp(DdlGen::getNextKeyWord(line, begPos).c_str(), "set") == 0 &&
                    strcasecmp(DdlGen::getNextKeyWord(line, begPos).c_str(), "current_schema") == 0 &&
                    strcasecmp(DdlGen::getNextKeyWord(line, begPos).c_str(), "=") == 0)
                {
                    string schemaStr = DdlGen::getNextKeyWord(line, ++begPos);
                    line.replace(0, begPos, "#USE ");
                }
            }
            else if (strcasecmp(context.firstCmd.c_str(), "exec") == 0 ||
                     strcasecmp(context.firstCmd.c_str(), "execute") == 0)
            {
                begPos = DdlGen::find_first_not_of(line, " \t\n");

                string::size_type sporcPos = begPos;
                string sprocStr = DdlGen::getNextKeyWord(line, ++sporcPos);

                if (strcasecmp(sprocStr.c_str(), "immediate") != 0 &&
                    (pos = DdlGen::find_first_not_of(line, " \t", ++sporcPos)) == string::npos || line[pos] != '(')
                {
                    context.bWaitGo = true;
                }
            }
            /* PMSTA-26108 - LJE - 171111 */
            else if (strcasecmp(context.firstCmd.c_str(), "setuser") == 0)
            {
                /* To avoid the begin transaction */
                context.scriptDdlGenPtr->bKeepConnection = true;
            }
            else if (context.bWaitGo &&
                (strcasecmp(context.firstCmd.c_str(), "insert") == 0 ||
                 strcasecmp(context.firstCmd.c_str(), "update") == 0 ||
                 strcasecmp(context.firstCmd.c_str(), "delete") == 0 ||
                 strcasecmp(context.firstCmd.c_str(), "select") == 0))
            {
                context.bWaitGo = false;
            }
            else if (firstCmd[0] == '#')
            {
                if (firstCmd == "#SPROC_BEGIN")
                {
                    endOfCommands.insert("#SPROC_END");
                }
                else if (firstCmd == "#FUNC_BEGIN")
                {
                    endOfCommands.insert("#FUNC_END");
                }
                else if (firstCmd == "#VIEW_BEGIN")
                {
                    endOfCommands.insert("#VIEW_END");
                }
            }
        }

        if (context.bWaitGo == false && context.bWaitEndOfCmd == true && context.firstCmd.empty() == false)
        {
            string::size_type begPos, endPos = string::npos;

            string sqlCmdStr(context.currBlock.str() + "\n" + line);

            context.ddlObjDbSqlName.clear();
            context.ddlObjSqlName.clear();

            if (strcasecmp(context.firstCmd.c_str(), "create") == 0 ||
                strcasecmp(context.firstCmd.c_str(), "replace") == 0)
            {
                vector<string> keyWordsTab;

                begPos = DdlGen::find_first_not_of(sqlCmdStr, " \t\n");
                endPos = DdlGen::find_first_of(sqlCmdStr, " \t\n", begPos);

                while (context.ddlObjSqlName.empty() && begPos != string::npos && bExecute == false)
                {
                    keyWordsTab.push_back(sqlCmdStr.substr(begPos, endPos - begPos));

                    string &lastKeyWord = keyWordsTab.at(keyWordsTab.size() - 1);

                    begPos = DdlGen::find_first_not_of(sqlCmdStr, " \t\n;", endPos);
                    if (begPos != string::npos)
                    {
                        endPos = DdlGen::find_first_of(sqlCmdStr, " \t\n;", begPos);
                    }

                    if (strcasecmp(lastKeyWord.c_str(), "procedure") == 0 ||
                        strcasecmp(lastKeyWord.c_str(), "proc") == 0 ||
                        strcasecmp(lastKeyWord.c_str(), "function") == 0 ||
                        strcasecmp(lastKeyWord.c_str(), "trigger") == 0 ||
                        strcasecmp(lastKeyWord.c_str(), "package") == 0 ||
                        strcasecmp(lastKeyWord.c_str(), "body") == 0)
                    {
                        string currKeyWord = sqlCmdStr.substr(begPos, endPos - begPos);

                        if (strcasecmp(currKeyWord.c_str(), "body") != 0)
                        {
                            if ((pos = currKeyWord.find(".")) != string::npos)
                            {
                                context.ddlObjDbSqlName = currKeyWord.substr(0, pos);
                                context.ddlObjSqlName = currKeyWord.substr(pos + 1);
                            }
                            else
                            {
                                context.ddlObjSqlName = currKeyWord;
                            }
                            context.ddlGenPtr->standardize(context.ddlObjSqlName);
                        }

                        context.bWaitEndOfCmd = false;
                    }
                }
            }
            else if (strcasecmp(context.firstCmd.c_str(), "declare") == 0 ||
                     strcasecmp(context.firstCmd.c_str(), "begin") == 0 ||
                     strcasecmp(context.firstCmd.c_str(), "if") == 0 ||
                     strcasecmp(context.firstCmd.c_str(), "do") == 0)
            {
                context.bWaitEndOfCmd = false;
            }

            if (context.bWaitEndOfCmd)
            {
                endOfCmdRemovedPos = DdlGen::find_first_of(sqlCmdStr, ";");
                if (endOfCmdRemovedPos != string::npos)
                {
                    sqlCmdStr.erase(endOfCmdRemovedPos, 1);
                    context.currBlock.str(sqlCmdStr);

                    bExecute = true;
                }
            }
            else
            {
                context.bWaitGo = true;
            }
        }

        if (context.bWaitGo && context.bWaitEndOfCmd)
        {
            if ((strcasecmp(firstCmd.c_str(), "exec") == 0 ||
                 strcasecmp(firstCmd.c_str(), "execute") == 0) &&
                strcasecmp(context.firstCmd.c_str(), "create") != 0 &&
                strcasecmp(context.firstCmd.c_str(), "if") != 0 &&
                strcasecmp(context.firstCmd.c_str(), "replace") != 0)
            {
                line.replace(beginCmd, firstCmd.length(), "#EXEC");
            }
        }

    }

    if (bExecute)
    {
        int                 status;
        string              scptToTreat;

        context.lastRetCode = RET_SUCCEED;
        context.bWaitGo = context.bDefWaitGo;
        context.bWaitEndOfCmd = true;

        if (bConfigTask == false)
        {
            /* SUPPORT-8925 - LJE - 180829 */
            if (AAASQL_Startup(SV_User, context) != 0 &&
                strcasecmp(context.firstCmd.c_str(), "check") != 0) /* PMSTA-45665 - LJE - 210719 */
            {
                return RET_ITFC_ERR_STARTUP;
            }
        }

        if (context.currBlock.str().empty() == false)
        {
            string currFirstCmd;
            stringstream sqlCmdStream;
            size_t begPos, endPos = string::npos, tmpPos;

            /* PMSTA-34445 - LJE - 190204 */
            if (bReDo == false)
            {
                context.convert();
            }

            context.scriptDdlGenPtr->removeComments(context.currBlock, sqlCmdStream);

            if (sqlCmdStream.str().empty())
            {
                context.currBlock.clear();
                context.currBlock.str(string());

                bExecute = false;
            }

            begPos = sqlCmdStream.str().find_first_not_of(" \t\n");
            if (begPos != string::npos)
            {
                endPos = sqlCmdStream.str().find_first_of(" \t\n", begPos);

                currFirstCmd = sqlCmdStream.str().substr(begPos, endPos - begPos);
            }

            if ((tmpPos = currFirstCmd.find("...")) != string::npos)
            {
                context.serverName = currFirstCmd.substr(0, tmpPos);
                if (context.serverName[0] == '$')
                {
                    context.serverName = context.ddlGenContext.getPropFileHelper().getProperty(context.serverName);
                }
                currFirstCmd = currFirstCmd.substr(tmpPos + 3);
            }

            if (strcasecmp(currFirstCmd.c_str(), "select") == 0)
            {
                bool bFrom = false;
                while (bFrom == false &&
                    (begPos = DdlGen::find_first_of(sqlCmdStream.str(), "fF", begPos + 1)) != string::npos)
                {
                    if (strcasecmp(sqlCmdStream.str().substr(begPos, 4).c_str(), "from") == 0)
                    {
                        bFrom = true;
                    }
                }

                if (bFrom == false)
                {
                    sqlCmdStream << context.ddlGenPtr->getEmptyFrom();
                    context.currBlock.clear();
                    context.currBlock.str(sqlCmdStream.str());
                }
            }
            else if (strcasecmp(currFirstCmd.c_str(), "sp_default_charset") == 0)
            {
                if (EV_RdbmsVendor == Oracle)
                {
                    context.currBlock.clear();
                    context.currBlock.str(string());
                    context.currBlock << "select lower(value) as DEFAULT_CHARSET from nls_database_parameters where parameter = 'NLS_CHARACTERSET'";
                }
                else if (EV_RdbmsVendor == Nuodb)
                {
                    context.currBlock.clear();
                    context.currBlock.str(string());
                    context.currBlock << "select 'utf8' from dual";
                }
                else if (EV_RdbmsVendor == PostgreSQL)
                {
                    context.currBlock.clear();
                    context.currBlock.str(string());
                    context.currBlock << "select lower(setting) from pg_settings where name = 'server_encoding'";
                }
            }
            else if (currFirstCmd.empty() == false && currFirstCmd[0] != '#')
            {
                if (strcasecmp(currFirstCmd.c_str(), "check") == 0 &&
                    sqlCmdStream.str().find_first_not_of(" \t\n", endPos) == string::npos)
                {
                    context.currBlock.clear();
                    context.currBlock.str(string());

                    if (context.sqlConnHelperPtr == nullptr ||
                        context.sqlConnHelperPtr->isValidAndInit() == false)
                    {
                        AAAConnectionDescription desc = context.sqlConnHelperPtr != nullptr ? context.sqlConnHelperPtr->getDescription() : AAAConnectionDescription(SqlServer);
                        context.ddlGenPtr->printMsg(RET_DBA_ERR_CONNOTFOUND, "Cannot connect to the data server (" + desc.getUser() + "@" + desc.getUrl() + ")");
                        MSG_DispMesg(RET_DBA_ERR_CONNOTFOUND, NULL, NULL);
                        return(RET_DBA_ERR_CONNOTFOUND);
                    }

                    /* PMSTA-45665 - LJE - 210719 */
                    if (EV_UseAlternativeDataSource)
                    {
                        bool bConnOk = false;
                        AAAConnectionDescription desc(SqlServer, DBI_GetSqlServerNameByRdbms(EV_SourceRdbmsVendor, false), ROLE_ADMIN, EV_SourceRdbmsVendor);
                        desc.setUser(EV_SourceApplOwner);
                        DbiConnection *srcDbiConn = DBA_GetDbiConnection(desc);
                        if (srcDbiConn != nullptr)
                        {
                            DbiConnectionHelper      srcDbiConnHelper(srcDbiConn, true);
                            if (srcDbiConnHelper.isValidAndInit())
                            {
                                bConnOk = true;
                            }
                        }

                        if (bConnOk == false)
                        {
                            context.ddlGenPtr->printMsg(RET_DBA_ERR_CONNOTFOUND, "Cannot connect to the alternative data server (" + desc.getUser() + "@" + desc.getUrl() + ")");
                            MSG_DispMesg(RET_DBA_ERR_CONNOTFOUND, NULL, NULL);
                            return(RET_DBA_ERR_CONNOTFOUND);
                        }
                    }
                }
                else if (context.optimLevel < 2 &&
                         DBI_IsRpcProc(currFirstCmd) == TRUE)
                {
                    string toChange(sqlCmdStream.str());
                    toChange.replace(begPos, endPos, "#EXEC " + currFirstCmd);

                    context.currBlock.clear();
                    context.currBlock.str(toChange);
                }
                else if (strcasecmp(currFirstCmd.c_str(), "check_srv") == 0 &&
                         sqlCmdStream.str().find_first_not_of(" \t\n", endPos) == string::npos)
                {
                    context.currBlock.clear();
                    context.currBlock.str(string());

                    if (context.finSrvConnHelperPtr &&
                        context.finSrvConnHelperPtr->isValidAndInit() == false)
                    {
                        context.ddlGenPtr->printMsg(RET_DBA_ERR_CONNOTFOUND, "Cannot connect to the financial server: " + context.currServerName);
                        MSG_DispMesg(RET_DBA_ERR_CONNOTFOUND, NULL, NULL);
                        return(RET_DBA_ERR_CONNOTFOUND);
                    }
                }
            }
        }
        else
        {
            bExecute = false;
        }

        if (bExecute)
        {
            context.scriptDdlGenPtr->outDateTimeStyleEn = context.outDateTimeStyleEn;
            context.scriptDdlGenPtr->inDateTimeStyleEn  = context.inDateTimeStyleEn;
            context.scriptDdlGenPtr->bPrintRowCount     = context.bPrintRowCount;
            context.scriptDdlGenPtr->optimLevel         = context.optimLevel;
            context.scriptDdlGenPtr->maxScale           = context.maxScale;
            context.scriptDdlGenPtr->rowCount           = context.rowCount;
            context.scriptDdlGenPtr->m_dataIdx          = context.dataIdx;
            context.scriptDdlGenPtr->m_bSkipNextBloc    = context.bSkipNextBloc;

            if (context.bSkipNextBloc == false)
            {
                scptToTreat = context.scriptDdlGenPtr->buildScript(context.currBlock.str(), DdlObj_Sql);

                context.outDateTimeStyleEn = context.scriptDdlGenPtr->outDateTimeStyleEn;
                context.inDateTimeStyleEn  = context.scriptDdlGenPtr->inDateTimeStyleEn;
                context.bPrintRowCount     = context.scriptDdlGenPtr->bPrintRowCount;
                context.bSkipNextBloc      = context.scriptDdlGenPtr->m_bSkipNextBloc;
            }

            if (context.optimLevel != context.scriptDdlGenPtr->optimLevel)
            {
                context.optimLevel = context.scriptDdlGenPtr->optimLevel;
            }
            else if (context.maxScale != context.scriptDdlGenPtr->maxScale)
            {
                context.maxScale = context.scriptDdlGenPtr->maxScale;
            }
            else if (context.rowCount != context.scriptDdlGenPtr->rowCount)
            {
                context.rowCount = context.scriptDdlGenPtr->rowCount;
            }
            else if (scptToTreat.find_first_not_of(" \t\n") != string::npos &&
                     context.bSkipNextBloc == false)
            {
                /* SUPPORT-8925 - LJE - 180829 */
                if (AAASQL_Startup(SV_User, context))
                {
                    return RET_ITFC_ERR_STARTUP;
                }

                if (context.sqlConnHelperPtr->isValidAndInit() == false)
                {
                    context.ddlGenPtr->printMsg(RET_DBA_ERR_CONNOTFOUND, "Cannot connect to the data server");
                    MSG_DispMesg(RET_DBA_ERR_CONNOTFOUND, NULL, NULL);
                    return(RET_DBA_ERR_CONNOTFOUND);
                }

                context.connHelperPtr = context.sqlConnHelperPtr;

                if (context.inDateTimeStyleEn != context.dbInDateTimeStyleEn)
                {
                    context.dbInDateTimeStyleEn = context.inDateTimeStyleEn;
                    context.bInDateTimeStyleChange = true;
                    context.sqlConnHelperPtr->getConnection()->setDateTimeFormat(context.inDateTimeStyleEn);
                }

                if (context.ddlGenContext.getDdlDestDbName().empty() == false)
                {
                    context.sqlConnHelperPtr->getConnection()->setDbName(context.ddlGenContext.getDdlDestDbName());
                }

                if (context.optimLevel != 9 || context.scriptDdlGenPtr->bServerOutput) /* PMSTA-43914 - LJE - 210315 */
                {
                    context.sqlConnHelperPtr->getConnection()->enableOutput();
                }

                if (context.scriptDdlGenPtr->getFinSrvCall().find_first_not_of(" \t\n") != string::npos)
                {
                    context.verboseLevel = VerboseLevel_None;
                }

                context.sqlCmd = scptToTreat;

                if (context.verboseLevel == VerboseLevel_All)
                {
                    cout << "SQL BEGIN:" << endl << context.sqlCmd << "SQL END" << endl;
                    context.ddlGenPtr->printMsg(RET_SUCCEED, "SQL Execution:");
                }
                /* PMSTA-24102 - LJE - 160720 */
                if (context.bPrintEcho)
                {
                    cout << endl << context.sqlCmd << endl;
                }

                if (log.isTraceEnabled())
                {
                    std::ostringstream oss;
                    oss << "Exec= " << context.sqlCmd;
                    log.trace(oss.str());
                }

                context.connHelperPtr->getConnection()->setExternalMsgManagement(true);
                ret = DBA_ManagedSqlExec(&context, &status);
                context.connHelperPtr->getConnection()->setExternalMsgManagement(false);

                if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
                {
                    bool bErrorPrinted = false;

                    if (context.connHelperPtr != nullptr &&
                        context.connHelperPtr->getConnection() != nullptr)
                    {
                        for (auto& msgStructIt : context.connHelperPtr->getConnection()->m_msgStructHeaderSt.msgStructTab)
                        {
                            string msgTxt;

                            if (context.connHelperPtr->getConnection()->isWarningMsgToHide(msgStructIt))
                            {
                                ret = RET_SUCCEED;
                                msgTxt = msgStructIt.getMsgString();
                            }
                            else if (msgStructIt.rdbmsMsgNb > 30000)
                            {
                                SYS_StringFormat(msgTxt,
                                                 "Msg Error (SQL) 0x%x: %s",
                                                 msgStructIt.rdbmsMsgNb,
                                                 msgStructIt.getMsgString().c_str());
                            }
                            else
                            {
                                SYS_StringFormat(msgTxt,
                                                 "Msg Error (SQL) %d: %s",
                                                 msgStructIt.rdbmsMsgNb,
                                                 msgStructIt.getMsgString().c_str());
                            }

                            context.lastRetCode = ret;

                            if (msgTxt.empty() == false)
                            {
                                bErrorPrinted = true;
                                msgTxt += "\n";
                                context.ddlGenPtr->printMsg(ret, msgTxt);
                            }
                        }
                    }

                    if (bErrorPrinted == false)
                    {
                        context.ddlGenPtr->printMsg(ret, "Error in SQL request: " + scptToTreat);
                    }
                }

                if (RET_GET_LEVEL(ret) != RET_LEV_ERROR && context.verboseLevel == VerboseLevel_All)
                {
                    context.ddlGenPtr->printMsg(RET_SUCCEED, "SQL Executed\n");
                }
            }

            if (context.scriptDdlGenPtr->getFinSrvCall().find_first_not_of(" \t\n") != string::npos &&
                context.bSkipNextBloc == false)
            {
                DdlGenVar *repSrvVar;
                context.verboseLevel = savedVerboseLeveEn;

                if ((repSrvVar = context.ddlGenVarHelperPtr->getParameter("report_server")) != NULL ||
                    (repSrvVar = context.ddlGenVarHelperPtr->getParameter("report_server_c")) != NULL)
                {
                    if (repSrvVar->getValue().empty())
                    {
                        GEN_GetApplInfo(ApplDefReportServerId, context.serverName);
                    }
                    else
                    {
                        context.serverName = repSrvVar->getValue();
                    }
                }

                if (context.serverName.compare(context.currServerName) != 0)
                {
                    delete context.finSrvConnHelperPtr;

                    GEN_SetServerPoolConnection(false, nullptr, false);
                    context.finSrvConnHelperPtr = new DbiConnectionHelper(context.serverName);
                    context.currServerName = context.serverName;
                }

                if (GEN_IsMultiEntity() &&
                    context.ddlGenContext.connBusinessEntity.empty() == false &&
                    context.ddlGenContext.connBusinessEntity.compare(SYS_GetThread().getCurrBusinessEntity()) != 0)
                {
                    SYS_GetThread().setCurrBusinessEntity(context.ddlGenContext.connBusinessEntity);
                }

                if (context.finSrvConnHelperPtr == nullptr ||
                    context.finSrvConnHelperPtr->isValidAndInit() == false)
                {
                    if (context.scriptDdlGenPtr->getFinSrvCall().find("get_version") == string::npos)
                    {
                        ret = RET_DBA_ERR_CANNOTCONNECT;
                    }
                    else
                    {
                        /* Only on standard output */
                        ret = RET_DBA_INFO_NODATA;
                    }

                    if (context.serverName.empty())
                    {
                        context.ddlGenPtr->printMsg(ret, "Unknown/Unspecified financial server");
                    }
                    else
                    {
                        context.ddlGenPtr->printMsg(ret, "Unable to connect to the financial server " + context.serverName);
                    }
                    ret = RET_DBA_ERR_CANNOTCONNECT;
                }
                else
                {
                    context.connHelperPtr = context.finSrvConnHelperPtr;
                    context.bFinSrvMode = true;

                    context.sqlCmd = context.scriptDdlGenPtr->getFinSrvCall();

                    if (context.verboseLevel == VerboseLevel_All)
                    {
                        cout << "FinSrv BEGIN:" << endl << context.sqlCmd << "FinSrv END" << endl;

                        context.ddlGenPtr->printMsg(RET_SUCCEED, "FinSrv Execution:");
                    }

                    ret = DBA_ManagedSqlExec(&context, &status);

                    context.lastRetCode = ret;

                    if (ret != RET_SUCCEED)
                    {
                        bool bErrorPrinted = false;

                        if (context.connHelperPtr != nullptr &&
                            context.connHelperPtr->getConnection() != nullptr)
                        {
                            for (auto& msgStructIt : context.connHelperPtr->getConnection()->m_msgStructHeaderSt.msgStructTab)
                            {
                                string msgTxt;
                                if (msgStructIt.rdbmsMsgNb == 0)
                                {
                                    SYS_StringFormat(msgTxt,
                                                     "Msg Error (FinSrv:%s) Unknown message: See financial server log file",
                                                     context.currServerName.c_str());
                                }
                                else if (msgStructIt.rdbmsMsgNb > 30000)
                                {
                                    SYS_StringFormat(msgTxt,
                                                     "Msg Error (FinSrv:%s) 0x%x: %s",
                                                     context.currServerName.c_str(),
                                                     msgStructIt.rdbmsMsgNb,
                                                     msgStructIt.getMsgString().c_str());
                                }
                                else
                                {
                                    SYS_StringFormat(msgTxt,
                                                     "Msg Error (FinSrv:%s) %d: %s",
                                                     context.currServerName.c_str(),
                                                     msgStructIt.rdbmsMsgNb,
                                                     msgStructIt.getMsgString().c_str());
                                }
                                msgTxt += "\n";
                                context.ddlGenPtr->printMsg(ret, msgTxt);
                                bErrorPrinted = true;
                            }
                        }

                        if (bErrorPrinted == false)
                        {
                            context.ddlGenPtr->printMsg(ret, "Error in SQL request: " + scptToTreat);
                        }
                    }
                    else if (context.verboseLevel == VerboseLevel_All)
                    {
                        context.ddlGenPtr->printMsg(RET_SUCCEED, "FinSrv Executed");
                    }
                }
            }

            context.lastBlockStr = context.currBlock.str();

            context.currBlock.clear();
            context.currBlock.str(string());

            context.connHelperPtr = NULL;

            if (context.sqlConnHelperPtr != nullptr &&
                (context.scriptDdlGenPtr->bEndTransaction ||
                 (context.scriptDdlGenPtr->bKeepConnection == false &&
                  context.scriptDdlGenPtr->bAutoCommit == true)) &&
                 context.sqlConnHelperPtr->isConnected())
            {
                if (context.lastBlockStr.empty() == false ||
                    context.scriptDdlGenPtr->bEndTransaction)
                {
                    context.sqlConnHelperPtr->getConnection()->endTransaction(RET_GET_LEVEL(ret) != RET_LEV_ERROR);
                    context.scriptDdlGenPtr->bEndTransaction = false;
                }

                if (context.scriptDdlGenPtr->bKeepConnection == false)
                {
                    context.sqlConnHelperPtr->getConnection()->disconnect();
                }
            }
        }

        context.firstCmd.clear();
    }
    else if (currLine.compare("nogo") == 0)
    {
        context.currBlock.clear();
        context.currBlock.str(context.lastBlockStr);
    }
    else
    {
        context.currBlock << line << endl;
    }

    return ret;
}

/************************************************************************
**
**  Function    :   GEN_GetProgramType()
**
**  Description :   Return AAA programm type
**
**  Arguments   :
**
**  Return      :   AAAProgramType
**
**  Creation    :   PMSTA-54990 - DDV - 231201
**  Last modif. :
**
*************************************************************************/
AAAProgramType GEN_GetProgramType()
{
    return(AAAProgramType::Sql);
}

/************************************************************************
**      END  aaasql.c
*************************************************************************/

/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/*******************************************************************************
**      Defines      
*******************************************************************************/
#define FIN_REFERENCEPOS_C

/*******************************************************************************
**      Include files
*******************************************************************************/
#define STDIO_H
#define MATH_H
#define STRING_H
#define STDLIB_H

#include "unidef.h"
#include "dba.h"
#include "gen.h"
#include "hier.h"
#include "fin.h"
#include "finsrv.h"
#include "tls.h"
#include "conv.h"
#include "ope.h"
#include "fus.h"

/*******************************************************************************
**      Local declarations
*******************************************************************************/
STATIC void FIN_CumulateAmounts(DBA_DYNFLD_STP, const DBA_DYNFLD_STP, const bool, const bool);

/*******************************************************************************
**
**  Function    :   FIN_DefineInitAndFinPos
**
**  Description :   Define the initPos and the FinPos
**
**  Arguments   :   finPos      The financial position
**                  initPos     Initial position
**                  pos1        First position
**                  pos2        Second position
**
**  Return      :   None
**
**  Last modif. :   PMSTA-9072 - 050510 - PMO : Future instrument with Fees&Taxes at opening position: exchange rate at opening position are not saved after adjustment operation
*******************************************************************************/
void FIN_DefineInitAndFinPos(DBA_DYNFLD_STP *      finPos
                            ,DBA_DYNFLD_STP *      initPos
                            ,const DBA_DYNFLD_STP  pos1
                            ,const DBA_DYNFLD_STP  pos2
                            )
{
    const DATETIME_T    date1 = GET_DATETIME(pos1, ExtPos_BegDate);
    const DATETIME_T    date2 = GET_DATETIME(pos2, ExtPos_BegDate);
    const int           comp  = DATETIME_CMP(date1, date2);

    if (comp > 0)
    {
        *initPos = pos2;
        *finPos  = pos1;
    }
    else if (comp < 0)
    {
        *initPos = pos1;
        *finPos  = pos2;
    }
    /* Positions start at same date, take smaller lexical op. code for initPos */
    else if (CMP_DYNFLD(pos1, pos2, ExtPos_OpenOpCd, ExtPos_OpenOpCd, GET_FLD_TYPE(ExtPos, ExtPos_OpenOpCd)) > 0)
    {
        *initPos = pos2;
        *finPos  = pos1;
    }
    else
    {
        *initPos = pos1;
        *finPos  = pos2;
    }
}


/*******************************************************************************
**
**  Function    : FIN_RoundAmount
**
**  Description : Round an amount
**
**  Arguments   : pos1              Record where to add an amount
**                fieldIdx          Index field
**                fieldCurrIdIdx    Index field of the currency id
**
**  Return      : None
**
**  Last modif. : PMSTA08746 - 061009 - PMO : Performance on futures in foreign currency
*******************************************************************************/
STATIC void FIN_RoundAmount(DBA_DYNFLD_STP pos1, const FIELD_IDX_T fieldIdx, const FIELD_IDX_T fieldCurrIdIdx)
{
    SET_AMOUNT(pos1, fieldIdx, CAST_AMOUNT(GET_AMOUNT(pos1, fieldIdx), GET_ID(pos1, fieldCurrIdIdx)));
}


/*******************************************************************************
**
**  Function    : FIN_RoundAmount
**
**  Description : Round an amount
**
**  Arguments   : pos1              Record where to add an amount
**                fieldIdx          Index field
**                fieldCurrIdIdx    Index field of the currency id
**
**  Return      : None
**
**  Last modif. : PMSTA08746 - 061009 - PMO : Performance on futures in foreign currency
*******************************************************************************/
STATIC void FIN_RoundAmount(DBA_DYNFLD_STP pos1, const FIELD_IDX_T fieldIdx, const ID_T currencyId)
{
    SET_AMOUNT(pos1, fieldIdx, CAST_AMOUNT(GET_AMOUNT(pos1, fieldIdx), currencyId));
}


/*******************************************************************************
**
**  Function    : FIN_RoundAmountsPosition
**
**  Description : Round all amounts of the given position
**
**  Arguments   : ctx               Fusion context for the sysCurrId
**                pos1              Record where to round amounts
**
**  Return      : None
**
**  Last modif. : PMSTA08746 - 061009 - PMO : Performance on futures in foreign currency
*******************************************************************************/
STATIC void FIN_RoundAmountsPosition(const FIN_FUS_CONTEXT_STP ctx, DBA_DYNFLD_STP pos1)
{
    FIN_RoundAmount(pos1, ExtPos_PosGrossAmt,      ExtPos_PosCurrId);
    FIN_RoundAmount(pos1, ExtPos_PosNetAmt,        ExtPos_PosCurrId);
    FIN_RoundAmount(pos1, ExtPos_InstrGrossAmt,    ExtPos_InstrCurrId);
    FIN_RoundAmount(pos1, ExtPos_InstrNetAmt,      ExtPos_InstrCurrId);
    FIN_RoundAmount(pos1, ExtPos_RefGrossAmt,      ExtPos_RefCurrId);
    FIN_RoundAmount(pos1, ExtPos_RefNetAmt,        ExtPos_RefCurrId);
    FIN_RoundAmount(pos1, ExtPos_SysGrossAmt,      ctx->currPtfInfo->sysCurrId);
    FIN_RoundAmount(pos1, ExtPos_SysNetAmt,        ctx->currPtfInfo->sysCurrId);
    FIN_RoundAmount(pos1, ExtPos_BookPosNetAmt,    ExtPos_PosCurrId);
    FIN_RoundAmount(pos1, ExtPos_BookInstrNetAmt,  ExtPos_InstrCurrId);
    FIN_RoundAmount(pos1, ExtPos_BookRefNetAmt,    ExtPos_RefCurrId);
    FIN_RoundAmount(pos1, ExtPos_BookSysNetAmt,    ctx->currPtfInfo->sysCurrId);
}




/*******************************************************************************
**
**  Function    : FIN_CopyAmountsPosition
**
**  Description : Copy all amounts of the given position
**
**  Arguments   : dest  Record where to copy all amounts
**                src   Record where are all amounts
**
**  Return      : None
**
**  Last modif. : PMSTA-9072 - 050510 - PMO : Future instrument with Fees&Taxes at opening position: exchange rate at opening position are not saved after adjustment operation
*******************************************************************************/
void FIN_CopyAmountsPosition(DBA_DYNFLD_STP dest, const DBA_DYNFLD_STP src)
{
    COPY_DYNFLD(dest, ExtPos,  ExtPos_PosGrossAmt,      src, ExtPos, ExtPos_PosGrossAmt);
    COPY_DYNFLD(dest, ExtPos,  ExtPos_PosNetAmt,        src, ExtPos, ExtPos_PosNetAmt);
    COPY_DYNFLD(dest, ExtPos,  ExtPos_InstrGrossAmt,    src, ExtPos, ExtPos_InstrGrossAmt);
    COPY_DYNFLD(dest, ExtPos,  ExtPos_InstrNetAmt,      src, ExtPos, ExtPos_InstrNetAmt);
    COPY_DYNFLD(dest, ExtPos,  ExtPos_RefGrossAmt,      src, ExtPos, ExtPos_RefGrossAmt);
    COPY_DYNFLD(dest, ExtPos,  ExtPos_RefNetAmt,        src, ExtPos, ExtPos_RefNetAmt);
    COPY_DYNFLD(dest, ExtPos,  ExtPos_SysGrossAmt,      src, ExtPos, ExtPos_SysGrossAmt);
    COPY_DYNFLD(dest, ExtPos,  ExtPos_SysNetAmt,        src, ExtPos, ExtPos_SysNetAmt);
    COPY_DYNFLD(dest, ExtPos,  ExtPos_BookPosNetAmt,    src, ExtPos, ExtPos_BookPosNetAmt);
    COPY_DYNFLD(dest, ExtPos,  ExtPos_BookInstrNetAmt,  src, ExtPos, ExtPos_BookInstrNetAmt);
    COPY_DYNFLD(dest, ExtPos,  ExtPos_BookRefNetAmt,    src, ExtPos, ExtPos_BookRefNetAmt);
    COPY_DYNFLD(dest, ExtPos,  ExtPos_BookSysNetAmt,    src, ExtPos, ExtPos_BookSysNetAmt);
}




/*******************************************************************************
**
**  Function    : SetevalExtPosCd 
**
**  Description : inline function which only purpose is to avoid a warning when compiling
**
**  Return      : true 
**  Last modif. :
**  REF11433-050927-EFE+PMO 
**
** 
********************************************************************************/
inline bool SetevalExtPosCd (bool &evalExtPosCd )
{
    return  evalExtPosCd = true;
}


/*******************************************************************************
**
**  Function    : IsCash2MustBeUsed
**
**  Description : Check if the cash 2 must be used
**
**  Return      : true  if Yes
**
**  Last modif. :
**
**  PMSTA-3257 - 170707 - PMO : P&L computation problem with Future FIFO and partial sell
**  PMSTA-230 - 051107 - PMO : Margin Call does not work with Future FIFO in a FIFO portfolio
** 
********************************************************************************/
inline bool IsCash2MustBeUsed (const DBA_DYNFLD_STP position )
{
    return ( position != NULL                                           
           &&(  GET_ENUM( position , ExtPos_OpenOpNatEn ) == OpNat_Sell 
             || GET_ENUM( position , ExtPos_OpenOpNatEn ) == OpNat_Buy  
             || (  GET_ENUM( position , ExtPos_OpenOpNatEn ) == OpNat_Adjust
                && GET_ENUM( position , ExtPos_AdjustNatEn ) == OpAdjustNat_MarginCall
                )
             || GET_AMOUNT( position , ExtPos_PosNetAmt ) != 0.0          
             )
           );
}


/*******************************************************************************
**
**  Function    : FIN_AddPositiveNegativePosition 
**
**  Description : Add a positive and negative cash positions
**
**  Arguments   : ctx                           Pointer on context-structure
**                mainPos                       Pointer on closing position (main) (can also be term open position)
**                resPos                        Reference cash position
**                bGeneratePositivePosition     Flag if the cash position must be saved
**                bAdjustment                   Update positive and negative positions fields (posnat and adjustnat)
**                bSetPositiveSecondary         If the positive position must be set to secondary
**
**  Return      : RET_SUCCEED           if ok
**                RET_MEM_ERR_ALLOC     if memory error
**                RET_XXX               if there is a problem on FIN_PosFusion
**
**  Last modif. : PMSTA-5595 - 250608 - PMO : Margin call on Future / Wrong Cash account sign in Stock flow analysis
**                PMSTA-6924 - 280109 - PMO : Cash Portfolio on Forwards
**                PMSTA-9072 - 050510 - PMO : Future instrument with Fees&Taxes at opening position: exchange rate at opening position are not saved after adjustment operation
*******************************************************************************/
STATIC RET_CODE  FIN_AddPositiveNegativePosition(FIN_FUS_CONTEXT_STP   ctx 
                                                ,const DBA_DYNFLD_STP  mainPos
                                                ,DBA_DYNFLD_STP        resPos
                                                ,const DBA_DYNFLD_STP  capGLBPos
                                                ,const bool            bGeneratePositivePosition
                                                ,const bool            bUseAcc2Flag
                                                ,const bool            bAdjustment)
{ /* Yes */
    DBA_DYNFLD_STP  negativeResPos   = FUS_DynStDup(resPos, ctx);   /* PMSTA-5615 - 040208 - PMO */ /*PMSTA6280-EFE-080421*/
    DBA_DYNFLD_STP  positiveResPos   = FUS_DynStDup(resPos, ctx);   /* PMSTA6280-EFE-080421 */
    DBA_DYNFLD_STP  accResPosOpenPos = NULL;
    RET_CODE        ret              = RET_SUCCEED;
    double          fact;


    /* Memory allocation error? */
    if (positiveResPos == NULL || negativeResPos == NULL)
    { /* Yes */
        (void)MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "ExtPos");
        FREE_DYNST(negativeResPos, ExtPos);
        FREE_DYNST(positiveResPos, ExtPos);
        return(RET_MEM_ERR_ALLOC);
    }

    DBA_InverseSign(negativeResPos);

    if (true == bAdjustment)
    {
        SET_ENUM(positiveResPos, ExtPos_PosNatEn,    PosNat_AdjPos);
        SET_ENUM(negativeResPos, ExtPos_PosNatEn,    PosNat_AdjPos);
        SET_ENUM(positiveResPos, ExtPos_AdjustNatEn, OpAdjustNat_MarginCall);
        SET_ENUM(negativeResPos, ExtPos_AdjustNatEn, OpAdjustNat_MarginCall);
    }

    if (true == bGeneratePositivePosition)  /* PMSTA-6924 - 280109 - PMO */
    {
        /* Set to secondary */
        SET_ENUM(negativeResPos, ExtPos_PrimaryEn, PosPrimary_Second);
    }

    if (GET_ENUM(mainPos, ExtPos_AdjustNatEn) == OpAdjustNat_MarginCall)    /* PMSTA-5595 - 250608 - PMO */
    {
        /* Set to secondary */
        SET_ENUM(positiveResPos, ExtPos_PrimaryEn, PosPrimary_Second);
    }

    /* PMSTA-6540 - 040708 - PMO */
    if (true == bUseAcc2Flag)
    {
        SET_ENUM(negativeResPos, ExtPos_PosNatEn, PosNat_AdjTransAcct);
    }


    fact = .0;
    if ( (ret = FIN_PosFusion(ctx, positiveResPos, negativeResPos, NO_VALUE, NULL, &fact,
                              NULL, NULL, NULL, NULL,
                              &accResPosOpenPos, NULL, FALSE)) != RET_SUCCEED)
    {
        FREE_DYNST(positiveResPos, ExtPos);
        FREE_DYNST(negativeResPos, ExtPos);
        return ret;
    }

    /* Sometimes this line is need for a final stock with a zero quantity SET_ENUM(accResPosOpenPos, ExtPos_FusStateEn, FusState_Untreated); Remove this zero position PMSTA-6540 - 040708 - PMO */

    /* Insert new account 1 "negative balance" position */
    if ((ret = FIN_InsertPos(ctx, negativeResPos, NO_VALUE, FALSE,FALSE, NULL)) != RET_SUCCEED)
    {
        FREE_DYNST(positiveResPos,   ExtPos);
        FREE_DYNST(negativeResPos,   ExtPos);
        FREE_DYNST(accResPosOpenPos, ExtPos);
        return ret;
    }

    /* Insert new account 1 resulting position */
    if ((ret = FIN_InsertPos(ctx, positiveResPos, NO_VALUE, FALSE,FALSE, NULL)) != RET_SUCCEED)
    {
        FREE_DYNST(accResPosOpenPos, ExtPos);
    }
    else
    {
        /* PMSTA-9072 - 050510 - PMO */
        if(NULL != capGLBPos)
        {
            FIN_CumulateAmounts(positiveResPos, capGLBPos, false, true);
            FIN_CumulateAmounts(negativeResPos, capGLBPos, true,  true);
        }
    }

    return ret;
}



/*******************************************************************************
**
**  Function    : FIN_AddEntryInPosLogTypesTabPosCashPtf
**
**  Description : Add an entry in the array posCashPtf
**
**  Arguments   : ctx               Pointer on context-structure
**                PosLogTypesIdx    Index for PosLogTypes
**                posCash           Position to add in posCashPtf
**
**  Return      : None
**
**  Last modif. : PMSTA-5595 - 250608 - PMO : Margin call on Future / Wrong Cash account sign in Stock flow analysis
*******************************************************************************/
STATIC RET_CODE FIN_AddEntryInPosLogTypesTabPosCashPtf(FIN_FUS_CONTEXT_STP ctx, const int PosLogTypesIdx, DBA_DYNFLD_STP posCash)
{
    RET_CODE        ret;
    DBA_DYNFLD_STP *newTab = ctx->posLogTypesTab[PosLogTypesIdx].portfolioInfo->posCashPtf;

    REALLOCBLOCK(DBA_DYNFLD_STP *,
                 newTab,
                 sizeof(DBA_DYNFLD_STP),
                 ctx->posLogTypesTab[PosLogTypesIdx].portfolioInfo->posCashNb+1,
                 ctx->posLogTypesTab[PosLogTypesIdx].portfolioInfo->posCashNbMax,
                 100);

    if (newTab != NULL) 
    {
        newTab[ctx->posLogTypesTab[PosLogTypesIdx].portfolioInfo->posCashNb++] = posCash;
        ctx->posLogTypesTab[PosLogTypesIdx].portfolioInfo->posCashPtf= newTab;
        ret = RET_SUCCEED;
    }
    else
    {
        ret = RET_MEM_ERR_ALLOC;
    }

    return ret;
}


/*******************************************************************************
**
**  Function    : FIN_GetInvestWithDrawlBalPosTpId
**
**  Description : Set the Invest Withdrawl balance position type according of the kind of operation
**
**  Arguments   : ctx                   Pointer on context-structure
**                mainPos               Main instrument position
**                resPos                Reference cash position
**                mergeCaseFusFlag      Flag if the instrument was fusioned in merge (mode)
**                pInvestBalPosTpId     Invest or Withdrawl bp type id regarding the resPos quantity 
**                pWithDrawlBalPosTpId  Withdrawl or Invest bp type id regarding the resPos quantity
**
**  Return      : None
**
**  Last modif. : PMSTA-6921 - 311008 - PMO : Closing of Future with cash portfolio
**                PMSTA-17898 - 160414 - PMO : New Fusion Criteria to manage the contract dates for margin calls after partial closing
**
*******************************************************************************/
STATIC void FIN_GetInvestWithDrawlBalPosTpId(const FIN_FUS_CONTEXT_STP  ctx,                                             
                                             const DBA_DYNFLD_STP       mainPos, 
                                             const DBA_DYNFLD_STP       resPos,
                                             const bool                 mergeCaseFusFlag, 
                                             ID_T *                     pInvestBalPosTpId, 
                                             ID_T *                     pWithDrawlBalPosTpId,
											 bool *						pbInvestHasBpTypeInvest)
{
    ID_T investID               = 0;
    ID_T withDrawlID            = 0;
    bool bISForwardShortClose   = false;    /* Forward short case */
    bool bTestFuture            = false;

    if (true == mergeCaseFusFlag)
    { /* Merge case */
        switch(GET_ENUM(mainPos, ExtPos_RefNatEn))
        {
            case PosRefNat_FwdOpen  :
            case PosRefNat_FwdClose :
                investID        = ctx->applFwdMergeInvestBpTypeId;
                withDrawlID     = ctx->applFwdMergeWithdrBpTypeId;
                bISForwardShortClose =  PosRefNat_FwdClose == GET_POSREFNAT(mainPos, ExtPos_RefNatEn)
                                     && CMP_NUMBER(GET_NUMBER(mainPos, ExtPos_Qty), 0.0) >= 0;
                break;

            case PosRefNat_FutOpen      :
            case PosRefNat_FutClose     :
            case PosRefNat_FutFifo      :
            case PosRefNat_FutWMP       :
            case PosRefNat_FutContract  :   /* PMSTA-17898 - 160414 - PMO */
                investID    = ctx->applFutMergeInvestBpTypeId;
                withDrawlID = ctx->applFutMergeWithdrBpTypeId;
                bTestFuture = true;
                break;
        }
    }
    else
    { /* Close case */
        switch(GET_ENUM(mainPos, ExtPos_RefNatEn))
        {
            case PosRefNat_FwdOpen  :
            case PosRefNat_FwdClose :
                investID    = ctx->applFwdCloseInvestBpTypeId;
                withDrawlID = ctx->applFwdCloseWithdrBpTypeId;
                bISForwardShortClose =  PosRefNat_FwdClose == GET_POSREFNAT(mainPos, ExtPos_RefNatEn)
                                     && CMP_NUMBER(GET_NUMBER(mainPos, ExtPos_Qty), 0.0) >= 0;
                break;

            case PosRefNat_FutOpen      :
            case PosRefNat_FutClose     :
            case PosRefNat_FutFifo      :
            case PosRefNat_FutWMP       :
            case PosRefNat_FutContract  :   /* PMSTA-17898 - 160414 - PMO */
                investID = ctx->applFutCloseInvestBpTypeId;
                withDrawlID = ctx->applFutCloseWithdrBpTypeId;
                bTestFuture = true;
                break;
        }
    }

    bool bResult;
    if (true == bTestFuture)
    { /* Future test */
        bResult = CMP_NUMBER(GET_NUMBER(resPos, ExtPos_Qty), 0.0) >= 0;
    }
    else
    { /* Forward test */
        bResult = CMP_NUMBER(GET_NUMBER(mainPos, ExtPos_Qty), 0.0) < 0  && false == bISForwardShortClose;
    }

    /* Define which is the invest and the withdrawl */
    if (true == bResult)
    {
		*pbInvestHasBpTypeInvest	= true;
        *pInvestBalPosTpId			= investID;
        *pWithDrawlBalPosTpId		= withDrawlID;
    }
    else
    {
		*pbInvestHasBpTypeInvest	= false;
        *pInvestBalPosTpId			= withDrawlID;
        *pWithDrawlBalPosTpId		= investID;
    }
}





/*******************************************************************************
**
**  Function    : FIN_AddEntryInCtxTabPosCashPtfToDelete
**
**  Description : Add an entry in the context array TabPosCashPtfToDelete
**
**  Arguments   : ctx       Pointer on context-structure
**                delArg    Data to store
**
**  Return      : None
**
**  Last modif. : PMSTA-6921 - 311008 - PMO : Closing of Future with cash portfolio
*******************************************************************************/
STATIC RET_CODE FIN_AddEntryInCtxTabPosCashPtfToDelete(FIN_FUS_CONTEXT_STP ctx, const DBA_DYNFLD_STP delArg)
{
    RET_CODE        ret;
    DBA_DYNFLD_STP *newTab = ctx->posCashPtfToDeleteTab;

    REALLOCBLOCK(DBA_DYNFLD_STP *,
                 newTab,
                 sizeof(DBA_DYNFLD_STP),
                 ctx->posCashPtfToDeleteNb+1,
                 ctx->posCashPtfToDeleteNbMax,
                 100);

    if (newTab != NULL) 
    {
        newTab[ctx->posCashPtfToDeleteNb++] = delArg;
        ctx->posCashPtfToDeleteTab = newTab;
        ret = RET_SUCCEED;
    }
    else
    {
        ret = RET_MEM_ERR_ALLOC;
    }

    return ret;
}


/*******************************************************************************
**
**  Function    : FIN_CashPortfolioCleanupOldPosition
**
**  Description : Add entries for the cleanup of old cash portfolio positions and balance positions
**
**  Arguments   : ctx                           Pointer on context-structure
**                 
**  Return      : RET_SUCCEED           if ok
**                RET_MEM_ERR_ALLOC     if memory error
**                RET_XXX               if there is a problem on FIN_PosFusion
**
**  Last modif. : PMSTA-6921 - 311008 - PMO : Closing of Future with cash portfolio
**                PMSTA-34425 - 240219 - PMO : Fusion synchronized processing of a group of big portfolios
**
*******************************************************************************/
STATIC RET_CODE FIN_CashPortfolioCleanupOldPosition(FusionContext & ctx, const DBA_DYNFLD_STP posCash)
{
    RET_CODE ret = RET_SUCCEED;

    DBA_DYNFLD_STP delArg = ALLOC_DYNST(Del_Arg);

    /* Allocate memory */
    if (nullptr != delArg)
    {
        /* Prepare cash portfolio positions that must be deleted.
         * One entry for one position and balance position
         */
        COPY_DYNFLD(delArg, Del_Arg, Del_Arg_Id,     posCash, ExtPos, ExtPos_OpenOpId);
        COPY_DYNFLD(delArg, Del_Arg, Del_Arg_PtfId,  posCash, ExtPos, ExtPos_CashPortfolioId);

        ret = FIN_AddEntryInCtxTabPosCashPtfToDelete(&ctx, delArg);
    }
    else
    {
        (void)MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "Del_Arg");
        ret = RET_MEM_ERR_ALLOC;
    }
    return ret;
}


/*******************************************************************************
**
**  Function    : FIN_IsCashFlagDisabled
**
**  Description : Check if the cash flag is disabled
**
**  Arguments   : ctx                           Pointer on context-structure
**                PosLogTypesIdx                Index for PosLogTypes
**                 
**  Return      : true  if the cash flag is disabled
**                false if the cash flag is enabled
**
**  Last modif. : PMSTA08471 - 280709 - PMO : When the system parameter CASH_ADJUSTMENT is set to 0 or the cash adjustment flag of portfolio is set to 0, Fusion process always moves cash flows of P&L in cash portfolio
*******************************************************************************/
STATIC bool FIN_IsCashFlagDisabled(const FIN_FUS_CONTEXT_STP ctx, const int PosLogTypesIdx)
{
    bool bPtfTestCashFlagDisbaled = false;
    
    /* Avoid a segmentation fault */
    if(  NO_VALUE != PosLogTypesIdx
      && NULL     != ctx->posLogTypesTab[PosLogTypesIdx].portfolioInfo
      && NULL     != ctx->posLogTypesTab[PosLogTypesIdx].portfolioInfo->portfolioPtr)
    {
        bPtfTestCashFlagDisbaled = FALSE == GET_FLAG((ctx->posLogTypesTab[PosLogTypesIdx].portfolioInfo->portfolioPtr), A_Ptf_CashAdjFlg);
    }

    return FALSE == ctx->applCashAdjFlag || true == bPtfTestCashFlagDisbaled;
}
                                   
                                   
/*******************************************************************************
**
**  Function    : FIN_ForwardCashPortfolioProcessing
**
**  Description : Add all necessary positions when there is a forward with a cash portfolio
**
**  Arguments   : ctx                           Pointer on context-structure
**                mainPos                       Main instrument position
**                freeAccOpenPos                Accounting position
**                freeAccClosePos               Accounting position
**                finPos                        Financial position
**                resPos                        Reference cash position
**                PosLogTypesIdx                Index for PosLogTypes
**                mergeCaseFusFlag              Flag if the fusion of the instrument was a merge
**                 
**  Return      : RET_SUCCEED           if ok
**                RET_MEM_ERR_ALLOC     if memory error
**                RET_XXX               if there is a problem on FIN_PosFusion
**
**  Last modif. : PMSTA-6924 - 280109 - PMO : Cash Portfolio on Forwards
**                PMSTA08471 - 280709 - PMO : When the system parameter CASH_ADJUSTMENT is set to 0 or the cash adjustment flag of portfolio is set to 0, Fusion process always moves cash flows of P&L in cash portfolio
**                PMSTA08644 - 070909 - PMO : FUSION process doesn't always take into account a cash portfolio
*******************************************************************************/
STATIC RET_CODE FIN_ForwardCashPortfolioProcessing(FIN_FUS_CONTEXT_STP      ctx, 
                                                   const DBA_DYNFLD_STP     mainPos,
                                                   const DBA_DYNFLD_STP     freeAccOpenPos,
                                                   DBA_DYNFLD_STP           freeAccClosePos,
                                                   const DBA_DYNFLD_STP     resPos,
                                                   const int                PosLogTypesIdx,
                                                   const bool               mergeCaseFusFlag
                                                   )
{
    DBA_DYNFLD_STP  accountPosInvest            = FUS_DynStDup(freeAccOpenPos,  ctx);
    DBA_DYNFLD_STP  accountPosWithDrawl         = FUS_DynStDup(freeAccClosePos, ctx);
    DBA_DYNFLD_STP  accountPosInvestCashPtf     = FUS_DynStDup(freeAccOpenPos,  ctx);
    DBA_DYNFLD_STP  accountPosWithDrawlCashPtf  = FUS_DynStDup(freeAccClosePos, ctx);
    DBA_DYNFLD_STP  freeAccOpenPosCashPtf       = FUS_DynStDup(freeAccOpenPos,  ctx);
    DBA_DYNFLD_STP  freeAccClosePosCashPtf      = FUS_DynStDup(freeAccClosePos, ctx);
    DBA_DYNFLD_STP  negativefreeAccClosePos     = FUS_DynStDup(freeAccClosePos, ctx);
    DBA_DYNFLD_STP  negativeResPos              = FUS_DynStDup(freeAccOpenPos,  ctx);
    RET_CODE        ret                         = RET_SUCCEED;

    FUS_TRACE_INC_FUNCTION_ENTRY(ctx, FIN_ForwardCashPortfolioProcessing);  /* PMSTA08644 - 070909 - PMO */

    /* Memory allocation error? */
    if (NULL == accountPosInvest            || 
        NULL == accountPosWithDrawl         || 
        NULL == accountPosInvestCashPtf     || 
        NULL == accountPosWithDrawlCashPtf  || 
        NULL == freeAccOpenPosCashPtf       || 
        NULL == freeAccClosePosCashPtf      || 
        NULL == negativefreeAccClosePos     ||
        NULL == negativeResPos)
    { /* Yes */
        (void)MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "ExtPos");
        FREE_DYNST(negativeResPos,              ExtPos);
        FREE_DYNST(negativefreeAccClosePos,     ExtPos);
        FREE_DYNST(freeAccClosePosCashPtf,      ExtPos);
        FREE_DYNST(freeAccOpenPosCashPtf,       ExtPos);
        FREE_DYNST(accountPosWithDrawlCashPtf,  ExtPos);
        FREE_DYNST(accountPosInvestCashPtf,     ExtPos);
        FREE_DYNST(accountPosWithDrawl,         ExtPos);
        FREE_DYNST(accountPosInvest,            ExtPos);
        ret = RET_MEM_ERR_ALLOC;
    }

    if (RET_SUCCEED == ret)
    {
        ret = FIN_AddEntryInPosLogTypesTabPosCashPtf(ctx, PosLogTypesIdx, accountPosInvestCashPtf);
    }

    if (RET_SUCCEED == ret)
    {
        ret = FIN_AddEntryInPosLogTypesTabPosCashPtf(ctx, PosLogTypesIdx, accountPosWithDrawlCashPtf);
    }
    else
    { /* Memory allocation error */
        FREE_DYNST(freeAccClosePosCashPtf,      ExtPos);
        FREE_DYNST(freeAccOpenPosCashPtf,       ExtPos);
        FREE_DYNST(accountPosWithDrawlCashPtf,  ExtPos);
        FREE_DYNST(accountPosInvestCashPtf,     ExtPos);
    }

    if (RET_SUCCEED == ret)
    {
        ret = FIN_AddEntryInPosLogTypesTabPosCashPtf(ctx, PosLogTypesIdx, freeAccOpenPosCashPtf);
    }
    else
    { /* Memory allocation error */
        FREE_DYNST(freeAccClosePosCashPtf,      ExtPos);
        FREE_DYNST(freeAccOpenPosCashPtf,       ExtPos);
        FREE_DYNST(accountPosWithDrawlCashPtf,  ExtPos);
        FREE_DYNST(accountPosInvestCashPtf,     ExtPos);
    }

    if (RET_SUCCEED == ret)
    {
        ret = FIN_AddEntryInPosLogTypesTabPosCashPtf(ctx, PosLogTypesIdx, freeAccClosePosCashPtf);
    }
    else
    { /* Memory allocation error */
        FREE_DYNST(freeAccClosePosCashPtf,      ExtPos);
        FREE_DYNST(freeAccOpenPosCashPtf,       ExtPos);
        FREE_DYNST(accountPosWithDrawlCashPtf,  ExtPos);
        FREE_DYNST(accountPosInvestCashPtf,     ExtPos);
    }

    if (RET_SUCCEED == ret)
    {
        SET_ENUM(accountPosInvest,             ExtPos_PrimaryEn,    PosPrimary_Second);
        SET_ENUM(accountPosWithDrawl,          ExtPos_PrimaryEn,    PosPrimary_Second);
        SET_ENUM(accountPosInvestCashPtf,      ExtPos_PrimaryEn,    PosPrimary_Second);
        SET_ENUM(accountPosWithDrawlCashPtf,   ExtPos_PrimaryEn,    PosPrimary_Second);
        SET_ENUM(freeAccOpenPosCashPtf,        ExtPos_PrimaryEn,    PosPrimary_Second);
        SET_ENUM(freeAccClosePosCashPtf,       ExtPos_PrimaryEn,    PosPrimary_Second);
        SET_ENUM(freeAccOpenPos,               ExtPos_PosNatEn,     PosNat_AdjTransAcct);
        SET_ENUM(freeAccClosePos,              ExtPos_PosNatEn,     PosNat_AdjTransAcct);
        SET_ENUM(negativefreeAccClosePos,      ExtPos_PosNatEn,     PosNat_AdjTransAcct);


        /*
         *  Set position to the cash portfolio
         */
        COPY_DYNFLD(accountPosInvestCashPtf,    ExtPos, ExtPos_PtfId, mainPos, ExtPos, ExtPos_CashPortfolioId);
        COPY_DYNFLD(accountPosWithDrawlCashPtf, ExtPos, ExtPos_PtfId, mainPos, ExtPos, ExtPos_CashPortfolioId);
        COPY_DYNFLD(freeAccOpenPosCashPtf,      ExtPos, ExtPos_PtfId, mainPos, ExtPos, ExtPos_CashPortfolioId);
        COPY_DYNFLD(freeAccClosePosCashPtf,     ExtPos, ExtPos_PtfId, mainPos, ExtPos, ExtPos_CashPortfolioId);

        SET_ENUM(freeAccOpenPosCashPtf,  ExtPos_PosNatEn, PosNat_AdjTransAcct);
        SET_ENUM(freeAccClosePosCashPtf, ExtPos_PosNatEn, PosNat_AdjTransAcct);

        if (true == FIN_IsCashFlagDisabled(ctx, PosLogTypesIdx))  /* PMSTA08471 - 280709 - PMO */
        { /* The system parameter disallow a standard processing (Operations are filled with a cash portfolio but there is no processing) */
            SET_ENUM(accountPosInvestCashPtf,       ExtPos_FusStateEn, FusState_Untreated);
            SET_ENUM(accountPosWithDrawlCashPtf,    ExtPos_FusStateEn, FusState_Untreated);
            SET_ENUM(freeAccOpenPosCashPtf,         ExtPos_FusStateEn, FusState_Untreated);
            SET_ENUM(freeAccClosePosCashPtf,        ExtPos_FusStateEn, FusState_Untreated);
            SET_ENUM(negativefreeAccClosePos,       ExtPos_FusStateEn, FusState_Untreated);
        }


        /*
         *  Set the Invest Withdrawl balance position type according of the kind of operation
         */
        ID_T	InvestBalPosTpId;
        ID_T	WithDrawlBalPosTpId;
		bool	bInvestHasBpTypeInvest;	/* Flag if invest is invest (else withdrawl) */

        FIN_GetInvestWithDrawlBalPosTpId(ctx, mainPos, resPos, mergeCaseFusFlag, &InvestBalPosTpId, &WithDrawlBalPosTpId, &bInvestHasBpTypeInvest);
        SET_ID(accountPosInvest,            ExtPos_BalPosTpId, InvestBalPosTpId);
        SET_ID(accountPosWithDrawl,         ExtPos_BalPosTpId, WithDrawlBalPosTpId);
        SET_ID(accountPosWithDrawlCashPtf,  ExtPos_BalPosTpId, InvestBalPosTpId);
        SET_ID(accountPosInvestCashPtf,     ExtPos_BalPosTpId, WithDrawlBalPosTpId);

		/*
         * Update the sign: Withdrawl and Invest must be positive
		 */
		if (CMP_NUMBER(GET_NUMBER(accountPosInvest, ExtPos_Qty), 0.0) < 0)
		{ /* Negative position. Turn it to positive */
			DBA_InverseSign(accountPosInvest);
		}

		if (CMP_NUMBER(GET_NUMBER(accountPosWithDrawl, ExtPos_Qty), 0.0) < 0)
		{ /* Negative position. Turn it to positive */
			DBA_InverseSign(accountPosWithDrawl);
		}

		if (CMP_NUMBER(GET_NUMBER(accountPosInvestCashPtf, ExtPos_Qty), 0.0) < 0)
		{ /* Negative position. Turn it to positive */
			DBA_InverseSign(accountPosInvestCashPtf);
		}

		if (CMP_NUMBER(GET_NUMBER(accountPosWithDrawlCashPtf, ExtPos_Qty), 0.0) < 0)
		{ /* Negative position. Turn it to positive */
			DBA_InverseSign(accountPosWithDrawlCashPtf);
		}

		if(true == bInvestHasBpTypeInvest)
		{
			DBA_InversePriceSign(accountPosInvest);
			DBA_InversePriceSign(accountPosWithDrawlCashPtf);
        }
		else
		{
			DBA_InversePriceSign(accountPosWithDrawl);
			DBA_InversePriceSign(accountPosInvestCashPtf);
		}

        /*
         *  Negative resPos processing
         */
        DBA_InverseSign(negativeResPos);
        SET_ENUM(negativeResPos, ExtPos_PrimaryEn, PosPrimary_Second);
        SET_ENUM(negativeResPos, ExtPos_PosNatEn,  PosNat_AdjTransAcct);


        bool bAddAccountPosition    = true;
        bool bFreeAccClosePosFusion = true;
        bool bRemoveNegativeResPos  = true;                                                     /* PMSTA08471 - 280709 - PMO */

        switch(ctx->applAdjCashNeutEnum)
        {
            case CashAdjNeut_FullInvestWithNatOp:
                bRemoveNegativeResPos = false == FIN_IsCashFlagDisabled(ctx, PosLogTypesIdx);   /* PMSTA08471 - 280709 - PMO */
		        if(true == bInvestHasBpTypeInvest)
		        {
                    SET_ENUM(accountPosInvest,              ExtPos_OpenOpNatEn, OpNat_Invest);
                    SET_ENUM(accountPosWithDrawl,           ExtPos_OpenOpNatEn, OpNat_Withdr);
                    SET_ENUM(accountPosWithDrawlCashPtf,    ExtPos_OpenOpNatEn, OpNat_Invest);
                    SET_ENUM(accountPosInvestCashPtf,       ExtPos_OpenOpNatEn, OpNat_Withdr);
                    SET_ENUM(freeAccClosePos,               ExtPos_OpenOpNatEn, OpNat_Withdr);
                    SET_ENUM(negativeResPos,                ExtPos_OpenOpNatEn, OpNat_Invest);
                    SET_ENUM(freeAccOpenPosCashPtf,         ExtPos_OpenOpNatEn, OpNat_Withdr);
                    SET_ENUM(freeAccClosePosCashPtf,        ExtPos_OpenOpNatEn, OpNat_Invest);
                }
                else
                {
                    SET_ENUM(accountPosWithDrawl,           ExtPos_OpenOpNatEn, OpNat_Invest);
                    SET_ENUM(accountPosInvest,              ExtPos_OpenOpNatEn, OpNat_Withdr);
                    SET_ENUM(accountPosInvestCashPtf,       ExtPos_OpenOpNatEn, OpNat_Invest);
                    SET_ENUM(accountPosWithDrawlCashPtf,    ExtPos_OpenOpNatEn, OpNat_Withdr);
                    SET_ENUM(freeAccClosePos,               ExtPos_OpenOpNatEn, OpNat_Invest);
                    SET_ENUM(negativeResPos,                ExtPos_OpenOpNatEn, OpNat_Withdr);
                    SET_ENUM(freeAccOpenPosCashPtf,         ExtPos_OpenOpNatEn, OpNat_Invest);
                    SET_ENUM(freeAccClosePosCashPtf,        ExtPos_OpenOpNatEn, OpNat_Withdr);
                }

                switch(ctx->applCashPtfFwdAccountEnum)
                {
                    case CashPtfFwdAccountFull:
                        break;

                    case CashPtfFwdAccountClose:
                    case CashPtfFwdAccountOpen:
                        /* PMSTA08471 - 280709 - PMO */
                        if (true == FIN_IsCashFlagDisabled(ctx, PosLogTypesIdx))
                        {
                            SET_ENUM(negativeResPos, ExtPos_FusStateEn,  FusState_Untreated);
                        }
                        break;

                    default:
                        break;
                }

                /* No break */

            case CashAdjNeut_Full:
                switch(ctx->applCashPtfFwdAccountEnum)
                {
                    case CashPtfFwdAccountFull:
                        /* PMSTA08471 - 280709 - PMO */
                        if (true == FIN_IsCashFlagDisabled(ctx, PosLogTypesIdx))
                        {
                            bAddAccountPosition    = false;
                            bFreeAccClosePosFusion = true;
                            SET_ENUM(negativeResPos,        ExtPos_FusStateEn, FusState_Untreated);
                            SET_ENUM(accountPosInvest,      ExtPos_FusStateEn, FusState_Untreated);
                            SET_ENUM(accountPosWithDrawl,   ExtPos_FusStateEn, FusState_Untreated);
                        }
                        break;

                    case CashPtfFwdAccountOpen:
                        bAddAccountPosition    = false;
                        bFreeAccClosePosFusion = false;
                        SET_ENUM(freeAccClosePosCashPtf,        ExtPos_FusStateEn, FusState_Untreated);
                        SET_ENUM(accountPosWithDrawl,           ExtPos_FusStateEn, FusState_Untreated);
                        SET_ENUM(accountPosWithDrawlCashPtf,    ExtPos_FusStateEn, FusState_Untreated);
                        SET_ENUM(negativefreeAccClosePos,       ExtPos_FusStateEn, FusState_Untreated);

                        /* PMSTA08471 - 280709 - PMO */
                        if (true == FIN_IsCashFlagDisabled(ctx, PosLogTypesIdx))
                        {
                            SET_ENUM(accountPosInvest, ExtPos_FusStateEn, FusState_Untreated);
                            SET_ENUM(negativeResPos,   ExtPos_FusStateEn, FusState_Untreated);
                        }
                        break;

                    case CashPtfFwdAccountClose:
                        bAddAccountPosition    = true;
                        bFreeAccClosePosFusion = true;
                        SET_ENUM(freeAccOpenPosCashPtf,     ExtPos_FusStateEn, FusState_Untreated);
                        SET_ENUM(accountPosInvest,          ExtPos_FusStateEn, FusState_Untreated);
                        SET_ENUM(accountPosInvestCashPtf,   ExtPos_FusStateEn, FusState_Untreated);

                        /* PMSTA08471 - 280709 - PMO */
                        if (true == bRemoveNegativeResPos)
                        {
                            SET_ENUM(negativeResPos, ExtPos_FusStateEn, FusState_Untreated);
                        }

                        if (false == FIN_IsCashFlagDisabled(ctx, PosLogTypesIdx))
                        {
                            SET_ENUM(freeAccClosePos, ExtPos_FusStateEn, FusState_Untreated);
                        }
                        else
                        {
                            SET_ENUM(accountPosWithDrawl,   ExtPos_FusStateEn, FusState_Untreated);
                        }
                        break;

                    default:
                        break;
                }
                break;

            case CashAdjNeut_Pos:
                bAddAccountPosition    = false;
                bFreeAccClosePosFusion = false;
                SET_ENUM(negativefreeAccClosePos, ExtPos_FusStateEn, FusState_Untreated);

                switch(ctx->applCashPtfFwdAccountEnum)
                {
                    case CashPtfFwdAccountFull:
                        /* PMSTA08471 - 280709 - PMO */
                        if (false == FIN_IsCashFlagDisabled(ctx, PosLogTypesIdx))
                        {
                            SET_ENUM(freeAccClosePos, ExtPos_FusStateEn, FusState_Untreated);
                        }
                        else
                        {
                            bFreeAccClosePosFusion = true;
                            SET_ENUM(negativeResPos, ExtPos_FusStateEn,  FusState_Untreated);
                        }
                        break;

                    case CashPtfFwdAccountOpen:
                        SET_ENUM(freeAccClosePosCashPtf,        ExtPos_FusStateEn, FusState_Untreated);
                        SET_ENUM(accountPosWithDrawl,           ExtPos_FusStateEn, FusState_Untreated);
                        SET_ENUM(accountPosWithDrawlCashPtf,    ExtPos_FusStateEn, FusState_Untreated);
                        /* PMSTA08471 - 280709 - PMO */
                        if (false == FIN_IsCashFlagDisabled(ctx, PosLogTypesIdx))
                        {
                            SET_ENUM(freeAccClosePos, ExtPos_PrimaryEn,  PosPrimary_Second);
                        }
                        else
                        {
                            SET_ENUM(negativeResPos, ExtPos_FusStateEn,  FusState_Untreated);
                        }
                        break;

                    case CashPtfFwdAccountClose:
                        SET_ENUM(freeAccOpenPosCashPtf,     ExtPos_FusStateEn, FusState_Untreated);
                        SET_ENUM(negativeResPos,            ExtPos_FusStateEn, FusState_Untreated);
                        SET_ENUM(accountPosInvest,          ExtPos_FusStateEn, FusState_Untreated);
                        SET_ENUM(accountPosInvestCashPtf,   ExtPos_FusStateEn, FusState_Untreated);
                        /* PMSTA08471 - 280709 - PMO */
                        if (false == FIN_IsCashFlagDisabled(ctx, PosLogTypesIdx))
                        {
                            SET_ENUM(freeAccClosePos, ExtPos_FusStateEn, FusState_Untreated);
                        }
                        break;

                    default:
                        break;
                }

                /* PMSTA08471 - 280709 - PMO */
                if (true == FIN_IsCashFlagDisabled(ctx, PosLogTypesIdx))
                {
                    SET_ENUM(accountPosInvest,      ExtPos_FusStateEn, FusState_Untreated);
                    SET_ENUM(accountPosWithDrawl,   ExtPos_FusStateEn, FusState_Untreated);
                }
                break;

            case CashAdjNeut_None:
                bAddAccountPosition    = false;
                bFreeAccClosePosFusion = false;
                SET_ENUM(negativefreeAccClosePos,    ExtPos_FusStateEn, FusState_Untreated);
                SET_ENUM(accountPosInvest,           ExtPos_FusStateEn, FusState_Untreated);
                SET_ENUM(accountPosWithDrawl,        ExtPos_FusStateEn, FusState_Untreated);
                SET_ENUM(accountPosInvestCashPtf,    ExtPos_FusStateEn, FusState_Untreated);
                SET_ENUM(accountPosWithDrawlCashPtf, ExtPos_FusStateEn, FusState_Untreated);

                switch(ctx->applCashPtfFwdAccountEnum)
                {
                    case CashPtfFwdAccountFull:
                        /* PMSTA08471 - 280709 - PMO */
                        if (false == FIN_IsCashFlagDisabled(ctx, PosLogTypesIdx))
                        {
                            SET_ENUM(freeAccClosePos, ExtPos_FusStateEn, FusState_Untreated);
                        }
                        else
                        {
                            bFreeAccClosePosFusion = true;
                            SET_ENUM(negativeResPos,  ExtPos_FusStateEn,  FusState_Untreated);
                            SET_ENUM(freeAccClosePos, ExtPos_PrimaryEn,   PosPrimary_Second);
                        }
                        break;

                    case CashPtfFwdAccountOpen:
                        SET_ENUM(freeAccClosePosCashPtf,    ExtPos_FusStateEn, FusState_Untreated);
                        SET_ENUM(freeAccClosePos,           ExtPos_PrimaryEn,  PosPrimary_Second);
                        /* PMSTA08471 - 280709 - PMO */
                        if (true == FIN_IsCashFlagDisabled(ctx, PosLogTypesIdx))
                        {
                            SET_ENUM(negativeResPos, ExtPos_FusStateEn, FusState_Untreated);
                        }
                        break;

                    case CashPtfFwdAccountClose:
                        SET_ENUM(freeAccOpenPosCashPtf,     ExtPos_FusStateEn, FusState_Untreated);
                        SET_ENUM(negativeResPos,            ExtPos_FusStateEn, FusState_Untreated);
                        /* PMSTA08471 - 280709 - PMO */
                        if (false == FIN_IsCashFlagDisabled(ctx, PosLogTypesIdx))
                        {
                            SET_ENUM(freeAccClosePos, ExtPos_FusStateEn, FusState_Untreated);
                        }
                        else
                        {
                            SET_ENUM(freeAccClosePos, ExtPos_PrimaryEn,  PosPrimary_Second);
                        }
                        break;

                    default:
                        break;
                }
                break;

            default:
                break;
        }

        if (true == bAddAccountPosition)
        {
            ret = FIN_AddPositiveNegativePosition(ctx, mainPos, freeAccClosePos, NULL, false == FIN_IsCashFlagDisabled(ctx, PosLogTypesIdx), false, false);   /* PMSTA-9072 - 050510 - PMO / PMSTA08471 - 280709 - PMO */  
        }

        if (RET_SUCCEED == ret && true == bFreeAccClosePosFusion && false == FIN_IsCashFlagDisabled(ctx, PosLogTypesIdx))   /* PMSTA08471 - 280709 - PMO */
        {
            double  fact = .0;

			DBA_InverseSign(negativefreeAccClosePos);

            ret = FIN_PosFusion(ctx, 
                                freeAccClosePos, 
                                negativefreeAccClosePos, 
                                NO_VALUE, 
                                NULL, 
                                &fact,
                                NULL, 
                                NULL, 
                                NULL, 
                                NULL,
                                NULL, 
                                NULL, 
                                FALSE);
        }


    }
    else
    { /* Memory allocation error */
        FREE_DYNST(freeAccClosePosCashPtf,      ExtPos);
        FREE_DYNST(freeAccOpenPosCashPtf,       ExtPos);
        FREE_DYNST(accountPosWithDrawlCashPtf,  ExtPos);
        FREE_DYNST(accountPosInvestCashPtf,     ExtPos);
    }

    if (RET_SUCCEED == ret && RET_SUCCEED != (ret = FIN_InsertPos(ctx, negativefreeAccClosePos, NO_VALUE, FALSE,FALSE, NULL)))
    {
        FREE_DYNST(negativeResPos, ExtPos);
        FREE_DYNST(accountPosWithDrawl, ExtPos);
        FREE_DYNST(accountPosInvest,    ExtPos);
    }

    if (RET_SUCCEED == ret && RET_SUCCEED != (ret = FIN_InsertPos(ctx, accountPosWithDrawl, NO_VALUE, FALSE,FALSE, NULL)))
    {
        FREE_DYNST(negativeResPos, ExtPos);
        FREE_DYNST(accountPosWithDrawl, ExtPos);
        FREE_DYNST(accountPosInvest,    ExtPos);
    }


    if (RET_SUCCEED == ret && RET_SUCCEED != (ret = FIN_InsertPos(ctx, accountPosInvest, NO_VALUE, FALSE,FALSE, NULL)))
    {
        FREE_DYNST(negativeResPos, ExtPos);
        FREE_DYNST(accountPosInvest, ExtPos);
    }

    if (RET_SUCCEED == ret && RET_SUCCEED != (ret = FIN_InsertPos(ctx, negativeResPos, NO_VALUE, FALSE,FALSE, NULL)))
    {
        FREE_DYNST(negativeResPos, ExtPos);
    }

    /* PMSTA08644 - 070909 - PMO */
    FUS_TraceForwardCashPtfPos(ctx, accountPosInvestCashPtf, accountPosWithDrawlCashPtf, freeAccOpenPosCashPtf, freeAccClosePosCashPtf);

    return ret;
}


/*******************************************************************************
**
**  Function    : FIN_CashPortfolioProcessing
**
**  Description : Add all necessary positions when there is a cash portfolio
**
**  Arguments   : ctx                           Pointer on context-structure
**                mainPos                       Main instrument position
**                finPos                        Financial position
**                resPos                        Reference cash position
**                PosLogTypesIdx                Index for PosLogTypes
**                mergeCaseFusFlag              Flag if the fusion of the instrument was a merge
**                useAcc2Flag                   If the account 2 is used
**                pbAddAccountPosition          Flag if we do the account position
**                cashPtfPosInvest              Invest/Withdrawl position generated
**                cashPtfPosWithDrawl           Invest/Withdrawl position generated
**                 
**  Return      : RET_SUCCEED           if ok
**                RET_MEM_ERR_ALLOC     if memory error
**                RET_XXX               if there is a problem on FIN_PosFusion
**
**  Last modif. : PMSTA-6921 - 311008 - PMO : Closing of Future with cash portfolio
**                PMSTA08471 - 280709 - PMO : When the system parameter CASH_ADJUSTMENT is set to 0 or the cash adjustment flag of portfolio is set to 0, Fusion process always moves cash flows of P&L in cash portfolio
**                PMSTA08644 - 070909 - PMO : FUSION process doesn't always take into account a cash portfolio
**                PMSTA-9072 - 050510 - PMO : Future instrument with Fees&Taxes at opening position: exchange rate at opening position are not saved after adjustment operation
**                PMSTA-10139 - 041010 - PMO : The amount of the cash position in the portfolio is not correct as a result of margin call.
*******************************************************************************/
STATIC RET_CODE FIN_CashPortfolioProcessing(FIN_FUS_CONTEXT_STP     ctx, 
                                            const DBA_DYNFLD_STP    mainPos, 
                                            DBA_DYNFLD_STP          resPos, 
                                            const int               PosLogTypesIdx,
                                            const bool              mergeCaseFusFlag,
                                            const bool              useAcc2Flag,
                                            bool *                  pbAddAccountPosition, 
											DBA_DYNFLD_STP *		cashPtfPosInvest,
											DBA_DYNFLD_STP *		cashPtfPosWithDrawl
											)
{
    DBA_DYNFLD_STP  accountPosInvest    = FUS_DynStDup(resPos, ctx);
    DBA_DYNFLD_STP  accountPosWithDrawl = FUS_DynStDup(resPos, ctx);
    DBA_DYNFLD_STP  negativeResPos      = FUS_DynStDup(resPos, ctx);
    DBA_DYNFLD_STP  resPosCashPtf       = FUS_DynStDup(resPos, ctx);
    RET_CODE        ret                 = RET_SUCCEED;

    /*
     *  Initialization
     */
    *pbAddAccountPosition = true;

    FUS_TRACE_INC_FUNCTION_ENTRY(ctx, FIN_CashPortfolioProcessing);  /* PMSTA08644 - 070909 - PMO */

    /* Memory allocation error? */
    if (NULL == accountPosWithDrawl || NULL == accountPosInvest || NULL == negativeResPos || NULL == resPosCashPtf)
    { /* Yes */
        (void)MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "ExtPos");
        FREE_DYNST(resPosCashPtf,       ExtPos);
        FREE_DYNST(negativeResPos,      ExtPos);
        FREE_DYNST(accountPosWithDrawl, ExtPos);
        FREE_DYNST(accountPosInvest,    ExtPos);
        ret = RET_MEM_ERR_ALLOC;
    }

    if (RET_SUCCEED == ret && (RET_SUCCEED == (ret = FIN_AddEntryInPosLogTypesTabPosCashPtf(ctx, PosLogTypesIdx, resPosCashPtf))))
    {
        SET_ENUM(accountPosInvest,      ExtPos_FusStateEn,  FusState_Opened);
        SET_ENUM(accountPosWithDrawl,   ExtPos_FusStateEn,  FusState_Opened);
        SET_ENUM(negativeResPos,        ExtPos_FusStateEn,  FusState_Opened);
        SET_ENUM(accountPosInvest,      ExtPos_PrimaryEn,   PosPrimary_Second);
        SET_ENUM(accountPosWithDrawl,   ExtPos_PrimaryEn,   PosPrimary_Second);
        SET_ENUM(resPosCashPtf,         ExtPos_PrimaryEn,   PosPrimary_Second);
        SET_ENUM(accountPosInvest,      ExtPos_PosNatEn,    PosNat_None);
        SET_ENUM(accountPosWithDrawl,   ExtPos_PosNatEn,    PosNat_None);

        /*
         *  P&L in the cash portfolio
         */
        COPY_DYNFLD(resPosCashPtf, ExtPos, ExtPos_PtfId, resPosCashPtf, ExtPos, ExtPos_CashPortfolioId);

        if (false == useAcc2Flag)
        {
            SET_ENUM(resPosCashPtf, ExtPos_PosNatEn, PosNat_AdjTransAcct);
        }

        /*
         *  Set the Invest Withdrawl balance position type according of the kind of operation
         */
        ID_T	InvestBalPosTpId;
        ID_T	WithDrawlBalPosTpId;
		bool	bInvestHasBpTypeInvest;	/* Flag if invest is invest (else withdrawl) */

        FIN_GetInvestWithDrawlBalPosTpId(ctx, mainPos, resPos, mergeCaseFusFlag, &InvestBalPosTpId, &WithDrawlBalPosTpId, &bInvestHasBpTypeInvest);
        SET_ID(accountPosInvest,    ExtPos_BalPosTpId, InvestBalPosTpId);
        SET_ID(accountPosWithDrawl, ExtPos_BalPosTpId, WithDrawlBalPosTpId);

		/* Update the sign:
		 * - Withdrawl is positive
		 * - Invest is negative and the Price must be negative. So the Quantity must be positive
		 */
		if (CMP_NUMBER(GET_NUMBER(accountPosInvest, ExtPos_Qty), 0.0) < 0)
		{ /* Negative position. Turn them to positive */
			DBA_InverseSign(accountPosInvest);
			DBA_InverseSign(accountPosWithDrawl);
		}
			
		if(true == bInvestHasBpTypeInvest)
		{
			DBA_InversePriceSign(accountPosInvest);
		}
		else
		{
			DBA_InversePriceSign(accountPosWithDrawl);
		}

        /*
         *  Negative resPos processing
         */
        DBA_InverseSign(negativeResPos);
        SET_ENUM(negativeResPos, ExtPos_PrimaryEn, PosPrimary_Second);
        if (false == useAcc2Flag)
        {
            SET_ENUM(negativeResPos, ExtPos_PosNatEn, PosNat_AdjTransAcct);
        }

        COPY_DYNFLD(accountPosInvest, ExtPos, ExtPos_PtfId, accountPosInvest, ExtPos, ExtPos_CashPortfolioId);
        *cashPtfPosInvest	 = accountPosInvest;
		*cashPtfPosWithDrawl = accountPosWithDrawl;

        const bool marginCallFlag    = OpAdjustNat_MarginCall == GET_OPADJUSTNAT(mainPos, ExtPos_AdjustNatEn);                          /* PMSTA-9072 - 050510 - PMO */
        const bool marginCallPlAcct2 =  true == marginCallFlag 
                                     && DATE_Cmp(ctx->applFutPlAcct2MarginCall.date, GET_DATETIME(mainPos, ExtPos_BegDate).date) <= 0;   /* PMSTA-10139 - 041010 - PMO */

        switch(ctx->applAdjCashNeutEnum)
        {
            case CashAdjNeut_Full:
                /* PMSTA08471 - 280709 - PMO */
                if (true == FIN_IsCashFlagDisabled(ctx, PosLogTypesIdx))
                {
                    SET_ENUM(accountPosInvest,    ExtPos_FusStateEn, FusState_Untreated);
                    SET_ENUM(accountPosWithDrawl, ExtPos_FusStateEn, FusState_Untreated);
                    SET_ENUM(negativeResPos,      ExtPos_FusStateEn, FusState_Untreated);
                    SET_ENUM(resPosCashPtf,       ExtPos_FusStateEn, FusState_Untreated);
                }
                else
                {   /* PMSTA-10139 - 041010 - PMO */
                    if (true == marginCallPlAcct2)
                    {
                        SET_ENUM(accountPosInvest,    ExtPos_FusStateEn, FusState_Untreated);
                        SET_ENUM(accountPosWithDrawl, ExtPos_FusStateEn, FusState_Untreated);
                        SET_ENUM(negativeResPos,      ExtPos_FusStateEn, FusState_Untreated);
                    }
                }
                break;

            case CashAdjNeut_Pos:
                /* PMSTA08471 - 280709 - PMO */
                if (true == FIN_IsCashFlagDisabled(ctx, PosLogTypesIdx))
                {
                    SET_ENUM(accountPosInvest,    ExtPos_FusStateEn, FusState_Untreated);
                    SET_ENUM(accountPosWithDrawl, ExtPos_FusStateEn, FusState_Untreated);
                    SET_ENUM(resPosCashPtf,       ExtPos_FusStateEn, FusState_Untreated);
                }
                else
                {   /* PMSTA-10139 - 041010 - PMO */
                    if (true == marginCallPlAcct2)
                    {
                        SET_ENUM(accountPosInvest,    ExtPos_FusStateEn, FusState_Untreated);
                        SET_ENUM(accountPosWithDrawl, ExtPos_FusStateEn, FusState_Untreated);
                    }
                }

                if (true == useAcc2Flag ) /* DLA - PMSTA06921 - 090126 */
                {
                    SET_ENUM(negativeResPos, ExtPos_FusStateEn, FusState_Untreated);
                    /* PMSTA08471 - 280709 - PMO */
                    if (false == FIN_IsCashFlagDisabled(ctx, PosLogTypesIdx))
                    {
                        SET_ENUM(resPos, ExtPos_FusStateEn, FusState_Untreated);
                    }
                }
                else
                {
                    /* PMSTA08471 - 280709 - PMO */
                    if (true == FIN_IsCashFlagDisabled(ctx, PosLogTypesIdx))
                    {
                        SET_ENUM(negativeResPos, ExtPos_FusStateEn, FusState_Untreated);
                    }
                }

                *pbAddAccountPosition = ! (false == useAcc2Flag && true == marginCallFlag);
                break;

            case CashAdjNeut_None:
                /* PMSTA08471 - 280709 - PMO */
                if (true == FIN_IsCashFlagDisabled(ctx, PosLogTypesIdx))
                {
                    SET_ENUM(resPosCashPtf, ExtPos_FusStateEn, FusState_Untreated);
                }

                if (true == useAcc2Flag )
                {
                    SET_ENUM(negativeResPos, ExtPos_FusStateEn, FusState_Untreated);
                    /* PMSTA08471 - 280709 - PMO */
                    if (false == FIN_IsCashFlagDisabled(ctx, PosLogTypesIdx))
                    {
                        SET_ENUM(resPos, ExtPos_FusStateEn, FusState_Untreated);
                    }
                }
                else
                {
                    /* PMSTA08471 - 280709 - PMO */
                    if (true == FIN_IsCashFlagDisabled(ctx, PosLogTypesIdx))
                    {
                        SET_ENUM(negativeResPos, ExtPos_FusStateEn, FusState_Untreated);
                    }
                }

                SET_ENUM(accountPosInvest,    ExtPos_FusStateEn, FusState_Untreated);
                SET_ENUM(accountPosWithDrawl, ExtPos_FusStateEn, FusState_Untreated);
                break;

            case CashAdjNeut_FullInvestWithNatOp:
                /* PMSTA08471 - 280709 - PMO */
                if (false == FIN_IsCashFlagDisabled(ctx, PosLogTypesIdx))
                {
		            if(true == bInvestHasBpTypeInvest)
		            {
                        SET_ENUM(accountPosInvest,    ExtPos_OpenOpNatEn, OpNat_Invest);
                        SET_ENUM(accountPosWithDrawl, ExtPos_OpenOpNatEn, OpNat_Withdr);
                        SET_ENUM(negativeResPos,      ExtPos_OpenOpNatEn, OpNat_Withdr);
                        SET_ENUM(resPosCashPtf,       ExtPos_OpenOpNatEn, OpNat_Invest);
                    }
                    else
                    {
                        SET_ENUM(accountPosWithDrawl, ExtPos_OpenOpNatEn, OpNat_Invest);
                        SET_ENUM(accountPosInvest,    ExtPos_OpenOpNatEn, OpNat_Withdr);
                        SET_ENUM(negativeResPos,      ExtPos_OpenOpNatEn, OpNat_Invest);
                        SET_ENUM(resPosCashPtf,       ExtPos_OpenOpNatEn, OpNat_Withdr);
                    }

                    /* PMSTA-10139 - 041010 - PMO */
                    if (true == marginCallPlAcct2)
                    {
                        SET_ENUM(accountPosInvest,    ExtPos_FusStateEn, FusState_Untreated);
                        SET_ENUM(accountPosWithDrawl, ExtPos_FusStateEn, FusState_Untreated);
                        SET_ENUM(negativeResPos,      ExtPos_FusStateEn, FusState_Untreated);
                    }
                }
                else
                {
                    SET_ENUM(accountPosInvest,    ExtPos_FusStateEn, FusState_Untreated);
                    SET_ENUM(accountPosWithDrawl, ExtPos_FusStateEn, FusState_Untreated);
                    SET_ENUM(negativeResPos,      ExtPos_FusStateEn, FusState_Untreated);
                    SET_ENUM(resPosCashPtf,       ExtPos_FusStateEn, FusState_Untreated);
                }
                break;

            default:
                break;
        }

        /* Store the position in memory */
        if (RET_SUCCEED != (ret = FIN_AddEntryInPosLogTypesTabPosCashPtf(ctx, PosLogTypesIdx, accountPosInvest))) 
        { /* Error */
            FREE_DYNST(negativeResPos,      ExtPos);
            FREE_DYNST(accountPosWithDrawl, ExtPos);
            FREE_DYNST(accountPosInvest,    ExtPos);
        }
    }

    if (RET_SUCCEED == ret && RET_SUCCEED != (ret = FIN_InsertPos(ctx, accountPosWithDrawl, NO_VALUE, FALSE,FALSE, NULL)))
    {
        FREE_DYNST(negativeResPos,      ExtPos);
        FREE_DYNST(accountPosWithDrawl, ExtPos);
    }

    if (RET_SUCCEED == ret && RET_SUCCEED != (ret = FIN_InsertPos(ctx, negativeResPos, NO_VALUE, FALSE,FALSE, NULL)))
    {
        FREE_DYNST(negativeResPos, ExtPos);
    }

    return ret;
}


/*******************************************************************************
**
**  Function    :   FUS_ComparePosMarginCallMain
**
**  Description :   Compare a position with the reference position
**                  Checks:
**                  - if the position is not deleted
**                  - Same code than the reference position. ID may change (rare case)
**                  - It is a primary position
**                  - It is a main position
**                  - It is an adjustment and the nature is margin call
**                  - Same Ptf and PPS if exist
**
**  Arguments   :   refPos      Reference position
**                  currPos     Position to compare
**
**  Return      :   true    if found
**                  false   if not found
**
**  Last modif. :   PMSTA-15747 - 311212 - PMO : Amounts are wrong after update an margin call operation with a cash portfolio
**
*******************************************************************************/
STATIC bool FUS_ComparePosMarginCallMain(const DBA_DYNFLD_STP refPos, const DBA_DYNFLD_STP currPos)
{
    return     OpFusion_ToDelete        != GET_OPFUSION(    currPos, ExtPos_Fus)
            && PosPrimary_Primary       == GET_POSPRIMARY(  currPos, ExtPos_PrimaryEn)
            && OpNat_Adjust             == GET_OPNAT(       currPos, ExtPos_OpenOpNatEn)
            && OpAdjustNat_MarginCall   == GET_OPADJUSTNAT( currPos, ExtPos_AdjustNatEn)
            && PosNat_MainPos           == GET_POSNAT(      currPos, ExtPos_PosNatEn)
            && TRUE                     == GET_FLAG(        currPos, ExtPos_MainFlg)
            && 0                        == CMP_DYNFLD(currPos, refPos, ExtPos_OpenOpCd, ExtPos_OpenOpCd, GET_FLD_TYPE(ExtPos, ExtPos_OpenOpCd))
            && 0 == FIN_CommonLogIdCmp(currPos, refPos)
            ;
}


/*******************************************************************************
**
**  Function    : FIN_OpPurgeOldSecondaryPosition
**
**  Description : All old secondary positions are flagged to delete
**
**  Arguments   : ctx                           Pointer on context-structure
**                finPos                        Financial position
**                 
**  Return      : None
**
**  Last modif. : PMSTA-6921 - 311008 - PMO : Closing of Future with cash portfolio
**                PMSTA-15747 - 311212 - PMO : Amounts are wrong after update an margin call operation with a cash portfolio
**                PMSTA-35491 - 180419 - PMO : PositionKeeping\CashPortfolio test cases still retrieve random results despite TC refactoring - heavy impact on 0 tolerance policy
**
*******************************************************************************/
STATIC void FIN_OpPurgeOldSecondaryPosition(FIN_FUS_CONTEXT_STP ctx, const DBA_DYNFLD_STP finPos)
{
    if (SOURCEDATAPOSITION == GET_INT(finPos, ExtPos_DataSource))
    {
        for (int posLogTypesIdx = 0; posLogTypesIdx < ctx->posLogTypesNb; posLogTypesIdx++)
        {         
            for (int posIdx = 0; posIdx < ctx->posLogTypesTab[posLogTypesIdx].posNb; posIdx++)
            {
                DBA_DYNFLD_STP currPos = ctx->posLogTypesTab[posLogTypesIdx].posTab[posIdx];

                if(  GET_ID(        currPos, ExtPos_PosObjId)   >  ZERO_ID
                  && GET_POSPRIMARY(currPos, ExtPos_PrimaryEn)  == PosPrimary_Second
                  && GET_FUSSTATE(  currPos, ExtPos_FusStateEn) != FusState_Untreated
                  && CMP_ID(GET_ID( currPos, ExtPos_CashPortfolioId), GET_ID(finPos, ExtPos_CashPortfolioId)) == 0  /* PMSTA-35491 - 180419 - PMO */
                  )
                {
                    /* Keep some derived margin call position PMSTA-15747 - 311212 - PMO */
                    if (  GET_POSPRIMARY(currPos, ExtPos_PrimaryEn)    == PosPrimary_Second
                       && GET_OPNAT(     currPos, ExtPos_OpenOpNatEn)  == OpNat_Adjust
                       && GET_FLAG(      currPos, ExtPos_MainFlg)      == FALSE
                       && (  GET_POSNAT( currPos, ExtPos_PosNatEn)     == PosNat_None
                          || GET_POSNAT( currPos, ExtPos_PosNatEn)     == PosNat_BPCurrencyFuture
                          )
                       && GET_OPFUSION(  currPos, ExtPos_Fus)          == OpFusion_Treated
                       )
                    {
                        if (NULL != FUS_SearchPosition(ctx, currPos, FUS_ComparePosMarginCallMain))
                        { /* This position will be created */
                            SET_ENUM(currPos, ExtPos_FusStateEn, FusState_Untreated);
                        }
                    }
                    else
                    {
                        SET_ENUM(currPos, ExtPos_FusStateEn, FusState_Untreated);
                    }
                }
            }
        }
    }
}


/*******************************************************************************
**
**  Function    : FIN_CumulateAmounts 
**
**  Description : Cumulate the amounts of delatPL into pos1 
**
**  Arguments   : pos1      Where to add amounts
**                deltaPL   Source of amounts
**                bAdd      true:add or false:remove
**                bComputeQty   true for recomputing the field quantity
**                 
**  Return      : RET_SUCCEED           if ok
**
**  Last modif. : PMSTA08607 - 280909 - PMO : Wrong treatment of future positions when booking margin amount
**                PMSTA-9072 - 050510 - PMO : Future instrument with Fees&Taxes at opening position: exchange rate at opening position are not saved after adjustment operation
*******************************************************************************/
STATIC void FIN_CumulateAmounts(DBA_DYNFLD_STP pos1, const DBA_DYNFLD_STP deltaPL, const bool bAdd, const bool bComputeQty)
{
    if (true == bAdd)
    {
        OPE_ADD_AMOUNT(pos1, ExtPos_PosGrossAmt,    GET_AMOUNT(deltaPL, ExtPos_PosGrossAmt));       /* PMSTA-9072 - 050510 - PMO */
        OPE_ADD_AMOUNT(pos1, ExtPos_PosNetAmt,      GET_AMOUNT(deltaPL, ExtPos_PosNetAmt));         /* PMSTA-9072 - 050510 - PMO */
        OPE_ADD_AMOUNT(pos1, ExtPos_InstrGrossAmt,  GET_AMOUNT(deltaPL, ExtPos_InstrGrossAmt));     /* PMSTA-9072 - 050510 - PMO */
        OPE_ADD_AMOUNT(pos1, ExtPos_InstrNetAmt,    GET_AMOUNT(deltaPL, ExtPos_InstrNetAmt));       /* PMSTA-9072 - 050510 - PMO */
        OPE_ADD_AMOUNT(pos1, ExtPos_RefGrossAmt,    GET_AMOUNT(deltaPL, ExtPos_RefGrossAmt));        
        OPE_ADD_AMOUNT(pos1, ExtPos_RefNetAmt,      GET_AMOUNT(deltaPL, ExtPos_RefNetAmt));
        OPE_ADD_AMOUNT(pos1, ExtPos_SysNetAmt,      GET_AMOUNT(deltaPL, ExtPos_SysNetAmt));         /* PMSTA-9072 - 050510 - PMO */
        OPE_ADD_AMOUNT(pos1, ExtPos_SysGrossAmt,    GET_AMOUNT(deltaPL, ExtPos_SysGrossAmt));       /* PMSTA-9072 - 050510 - PMO */
    }
    else
    {
        OPE_ADD_AMOUNT(pos1, ExtPos_PosGrossAmt,    -GET_AMOUNT(deltaPL, ExtPos_PosGrossAmt));      /* PMSTA-9072 - 050510 - PMO */
        OPE_ADD_AMOUNT(pos1, ExtPos_PosNetAmt,      -GET_AMOUNT(deltaPL, ExtPos_PosNetAmt));        /* PMSTA-9072 - 050510 - PMO */
        OPE_ADD_AMOUNT(pos1, ExtPos_InstrGrossAmt,  -GET_AMOUNT(deltaPL, ExtPos_InstrGrossAmt));    /* PMSTA-9072 - 050510 - PMO */
        OPE_ADD_AMOUNT(pos1, ExtPos_InstrNetAmt,    -GET_AMOUNT(deltaPL, ExtPos_InstrNetAmt));      /* PMSTA-9072 - 050510 - PMO */
        OPE_ADD_AMOUNT(pos1, ExtPos_RefGrossAmt,    -GET_AMOUNT(deltaPL, ExtPos_RefGrossAmt));        
        OPE_ADD_AMOUNT(pos1, ExtPos_RefNetAmt,      -GET_AMOUNT(deltaPL, ExtPos_RefNetAmt));
        OPE_ADD_AMOUNT(pos1, ExtPos_SysNetAmt,      -GET_AMOUNT(deltaPL, ExtPos_SysNetAmt));        /* PMSTA-9072 - 050510 - PMO */
        OPE_ADD_AMOUNT(pos1, ExtPos_SysGrossAmt,    -GET_AMOUNT(deltaPL, ExtPos_SysGrossAmt));      /* PMSTA-9072 - 050510 - PMO */
    }

    if (true == bComputeQty)
    {
        SET_NUMBER(pos1, ExtPos_Qty, ( GET_AMOUNT(pos1, ExtPos_PosGrossAmt) /  GET_PRICE(pos1, ExtPos_Price)));
    }
}


/*******************************************************************************
**
**  Function    : FIN_PLInCpt2ForMarginCall 
**
**  Description : Processing of the P&L when it was given in the account 2 
**
**  Arguments   : ctx               Pointer on context-structure
**                newMainPos        Can be NULL
**                newAccClosePos    Can be NULL
**                instrCapGLBPos    Can be NULL
**                .... lot of variables inherited from calling 
**                     function FIN_ReferencePos
**
**                 
**  Return      : RET_SUCCEED           if ok
**
**  Last modif. : PMSTA08607 - 280909 - PMO : Wrong treatment of future positions when booking margin amount
**                PMSTA-9072 - 050510 - PMO : Future instrument with Fees&Taxes at opening position: exchange rate at opening position are not saved after adjustment operation
**                PMSTA-10139 - 041010 - PMO : The amount of the cash position in the portfolio is not correct as a result of margin call.
*******************************************************************************/
STATIC RET_CODE FIN_PLInCpt2ForMarginCall(FIN_FUS_CONTEXT_STP   ctx,
                                          DBA_DYNFLD_STP        mainPos,
                                          DBA_DYNFLD_STP        newMainPos,
                                          DBA_DYNFLD_STP        freeAccClosePos,
                                          const DBA_DYNFLD_STP  newAccClosePos,
                                          const DBA_DYNFLD_STP  acc2ClosePosDerived,
                                          const DBA_DYNFLD_STP  acc2ClosePos,
                                          DBA_DYNFLD_STP        instrResPos,
                                          DBA_DYNFLD_STP        instrCapGLBPos,
                                          const bool            useAcc2Flag,
                                          const bool            bCashPortfolio,             /* PMSTA-10139 - 041010 - PMO */
                                          bool *                pbPLInCpt2ForMarginCall,
                                          DBA_DYNFLD_STP *      pCapGLBPos                  /* PMSTA-9072 - 050510 - PMO */
                                         )
{
    RET_CODE                ret         = RET_SUCCEED;
    const DBA_DYNFLD_STP    acc2Used    = NULL != acc2ClosePos ? acc2ClosePos : acc2ClosePosDerived;
    double                  fact        = .0;

    if (  true == useAcc2Flag 
       && NULL != acc2Used 
       && 0    != CMP_AMOUNT(GET_AMOUNT(acc2Used, ExtPos_PosNetAmt), 0.0, GET_ID(acc2Used, ExtPos_RefCurrId))
       && DATE_Cmp(ctx->applFutPlAcct2MarginCall.date, GET_DATETIME(mainPos, ExtPos_BegDate).date) <= 0
       )
    {
        if (NULL != instrCapGLBPos)
        {
            /*
             * Standard case
             */
            DBA_DYNFLD_STP  acc2Copy            = FUS_DynStDup(acc2Used,       ctx);
            DBA_DYNFLD_STP  instrCapGLBPosCopy  = FUS_DynStDup(instrCapGLBPos, ctx);
            DBA_DYNFLD_STP  newAccClosePosRound = FUS_DynStDup(newAccClosePos, ctx);
            DBA_DYNFLD_STP  deltaPL             = NULL;

            if (NULL != acc2Copy && NULL != instrCapGLBPosCopy && (NULL != newAccClosePosRound || NULL == newAccClosePos))
            { /* Ok */

                /*
                 *  Create position for computing the difference of the P&L computed and the P&L
                 *  provided in the account 2
                 */

                SET_NULL_ID(instrCapGLBPosCopy, ExtPos_BalPosTpId);
                SET_ENUM(instrCapGLBPosCopy   , ExtPos_LockNatEn,    OpLockNat_None);
                SET_ENUM(instrCapGLBPosCopy   , ExtPos_SubPosNatEn,  PosSubPosNat_None);
                SET_ENUM(instrCapGLBPosCopy   , ExtPos_SubPosNat2En, PosSubPosNat_None);
                SET_ENUM(instrCapGLBPosCopy   , ExtPos_SubPosNat3En, PosSubPosNat_None);

                COPY_DYNFLD(instrCapGLBPosCopy, ExtPos, ExtPos_InstrId, acc2Copy, ExtPos, ExtPos_InstrId);
                COPY_DYNFLD(instrCapGLBPosCopy, ExtPos, ExtPos_Price,   acc2Copy, ExtPos, ExtPos_Price);
                COPY_DYNFLD(instrCapGLBPosCopy, ExtPos, ExtPos_Quote,   acc2Copy, ExtPos, ExtPos_Quote);

                SET_AMOUNT(instrCapGLBPosCopy, ExtPos_RefNetAmt, CAST_AMOUNT(GET_AMOUNT(instrCapGLBPosCopy,  ExtPos_InstrNetAmt) * GET_EXCHANGE(acc2Copy, ExtPos_PosExchRate)
                                                                            ,GET_ID(instrCapGLBPosCopy, ExtPos_RefCurrId))); /* PMSTA-9072 - 050510 - PMO */  /* PMSTA-31831 - DDV - 180912 - Change currency */

                COPY_DYNFLD(instrCapGLBPosCopy, ExtPos, ExtPos_PosGrossAmt, instrCapGLBPosCopy, ExtPos, ExtPos_InstrNetAmt);                                        /* PMSTA-9072 - 050510 - PMO */
                COPY_DYNFLD(instrCapGLBPosCopy, ExtPos, ExtPos_PosNetAmt,   instrCapGLBPosCopy, ExtPos, ExtPos_InstrNetAmt);                                        /* PMSTA-9072 - 050510 - PMO */
                COPY_DYNFLD(instrCapGLBPosCopy, ExtPos, ExtPos_SysNetAmt,   instrCapGLBPosCopy, ExtPos, ExtPos_InstrNetAmt);                                        /* PMSTA-9072 - 050510 - PMO */
                COPY_DYNFLD(instrCapGLBPosCopy, ExtPos, ExtPos_SysGrossAmt, instrCapGLBPosCopy, ExtPos, ExtPos_InstrNetAmt);                                        /* PMSTA-9072 - 050510 - PMO */
                SET_NUMBER(instrCapGLBPosCopy, ExtPos_Qty, (GET_AMOUNT(instrCapGLBPosCopy, ExtPos_InstrNetAmt) / GET_PRICE(instrCapGLBPosCopy, ExtPos_Price)));    /* PMSTA-9072 - 050510 - PMO */

                COPY_DYNFLD(acc2Copy, ExtPos, ExtPos_SysNetAmt,   acc2Copy, ExtPos, ExtPos_RefNetAmt);
                COPY_DYNFLD(acc2Copy, ExtPos, ExtPos_SysGrossAmt, acc2Copy, ExtPos, ExtPos_RefNetAmt);

                /*
                 * Compute the difference between the computed P&L and the P&L provided.
                 * Result will be added to the "output" adjustment position and some other positions
                 */
                if ( (ret = FIN_PosFusion(ctx, acc2Copy, instrCapGLBPosCopy, NO_VALUE, NULL, &fact,
                                          NULL, NULL, NULL, NULL, &deltaPL, NULL, FALSE)) == RET_SUCCEED)
                { /* Ok */
                    if (0 != CMP_AMOUNT(GET_AMOUNT(deltaPL, ExtPos_PosNetAmt), 0.0, GET_ID(deltaPL, ExtPos_RefCurrId)))
                    { /* There is a difference. Add it to some positions */

                        if (NULL != newMainPos)
                        {
                            FIN_CumulateAmounts(newMainPos, deltaPL, true, false);
                        }

                        FIN_CumulateAmounts(freeAccClosePos, deltaPL, true, false);
                        SET_NUMBER(freeAccClosePos, ExtPos_Qty, (GET_AMOUNT(freeAccClosePos, ExtPos_PosNetAmt) / GET_PRICE(freeAccClosePos, ExtPos_Price)));

                        if (NULL != newAccClosePos)
                        {
                            FIN_CumulateAmounts(newAccClosePos, deltaPL, false, false);
                            SET_NUMBER(newAccClosePos, ExtPos_Qty, (GET_AMOUNT(newAccClosePos, ExtPos_PosNetAmt) / GET_PRICE(newAccClosePos, ExtPos_Price)));

                            FUS_ZeroAmounts(newAccClosePosRound);
                            FIN_CumulateAmounts(newAccClosePosRound, deltaPL, false, false);
                            SET_NUMBER(newAccClosePosRound, ExtPos_Qty, -GET_NUMBER(deltaPL, ExtPos_Qty));                                                        /* PMSTA-9072 - 050510 - PMO */
                            SET_ENUM(newAccClosePosRound,   ExtPos_PrimaryEn, PosPrimary_Second);
                        }

                        FIN_CumulateAmounts(instrCapGLBPos, deltaPL, false, false);
                        FUS_SetBPCapitalPL(ctx, instrCapGLBPos);
                    }

                    if (NULL != newAccClosePosRound)
                    {
                        SET_ENUM(newAccClosePosRound, ExtPos_PosNatEn, PosNat_None);
                        FIN_ClosePosItself(newAccClosePosRound);
                    }

                    SET_ENUM(acc2Copy,              ExtPos_FusStateEn, FusState_Untreated);
                    SET_ENUM(instrCapGLBPosCopy,    ExtPos_FusStateEn, FusState_Untreated);
                    SET_ENUM(deltaPL,               ExtPos_FusStateEn, FusState_Untreated);
                    *pbPLInCpt2ForMarginCall = true;

                    if (RET_SUCCEED == (ret = FIN_InsertPos(ctx, acc2Copy, NO_VALUE, FALSE, FALSE, NULL)))
                    { /* Ok */
                        if (RET_SUCCEED == (ret = FIN_InsertPos(ctx, instrCapGLBPosCopy, NO_VALUE, FALSE, FALSE, NULL)))
                        { /* Ok */
                            if (NULL != newAccClosePosRound
                               && RET_SUCCEED != (ret = FIN_InsertPos(ctx, newAccClosePosRound, NO_VALUE, FALSE, FALSE, NULL))
                               )
                            { /* Error */
                                FREE_DYNST(newAccClosePosRound, ExtPos);
                            }
                        }
                        else
                        { /* Error */
                            FREE_DYNST(instrCapGLBPosCopy, ExtPos);
                            FREE_DYNST(newAccClosePosRound, ExtPos);
                        }
                    }
                    else
                    { /* Error */
                        FREE_DYNST(acc2Copy, ExtPos);
                        FREE_DYNST(instrCapGLBPosCopy, ExtPos);
                        FREE_DYNST(newAccClosePosRound, ExtPos);
                    }
                }
                else
                { /* Error */
                    FREE_DYNST(acc2Copy,            ExtPos);
                    FREE_DYNST(instrCapGLBPosCopy,  ExtPos);
                    FREE_DYNST(newAccClosePosRound, ExtPos);
                }
            }
            else
            { /* Error */
                (void)MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "ExtPos");
                ret = RET_MEM_ERR_ALLOC;

                FREE_DYNST(acc2Copy,            ExtPos);
                FREE_DYNST(instrCapGLBPosCopy,  ExtPos);
                FREE_DYNST(newAccClosePosRound, ExtPos);
            }
        }
        else
        {
            /*
             * When there is no capital P&L
             */
            DBA_DYNFLD_STP  acc2Copy  = FUS_DynStDup(acc2Used, ctx);
            DBA_DYNFLD_STP  capitalPL = FUS_DynStDup(acc2Used, ctx);
            DBA_DYNFLD_STP  zeroPos   = FUS_DynStDup(acc2Used, ctx);

            if (NULL != acc2Copy && NULL != capitalPL && NULL != zeroPos)
            {
                SET_ENUM(acc2Copy,      ExtPos_AdjustNatEn, OpAdjustNat_None);
                SET_ENUM(acc2Copy,      ExtPos_RefNatEn,    PosRefNat_None);
                SET_ENUM(acc2Copy,      ExtPos_PrimaryEn,   PosPrimary_Derived);
                SET_ENUM(acc2Copy,      ExtPos_PosNatEn,    PosNat_None);
                SET_ENUM(acc2Copy,      ExtPos_FusRuleEn,   PosFusRule_None);
                SET_NULL_CODE(acc2Copy, ExtPos_RefOpCd);

                FIN_CumulateAmounts(NULL != newMainPos ? newMainPos : instrResPos, acc2Copy, true, false);
                FIN_CumulateAmounts(newAccClosePos, acc2Copy, false, true);

                if (RET_SUCCEED != (ret = FIN_InsertPos(ctx, acc2Copy, NO_VALUE, FALSE, FALSE, NULL)))
                { /* Error */
                    FREE_DYNST(acc2Copy, ExtPos);
                }

                /* PMSTA-10139 - 041010 - PMO */
                if(true == bCashPortfolio)
                {
                    switch(ctx->applAdjCashNeutEnum)
                    {
                        case CashAdjNeut_Pos:
                        case CashAdjNeut_None:
                            SET_ENUM(acc2Copy, ExtPos_FusStateEn, FusState_Untreated);
                            break;

                        case CashAdjNeut_Full:
                        case CashAdjNeut_FullInvestWithNatOp:
                        default:
                            break;
                    }
                }

                FIN_ClosePosItself(acc2Used);

                /*
                 * Generate a BP capital P&L 
                 */
                FUS_ZeroAmounts(zeroPos);
                SET_NUMBER(zeroPos,     ExtPos_Qty, (GET_NUMBER(capitalPL, ExtPos_Qty) >=  0. ? 1. : -1. ));
                SET_NULL_CODE(zeroPos,  ExtPos_RefOpCd);
                SET_ENUM(zeroPos,       ExtPos_PrimaryEn,   PosPrimary_Derived);
                SET_ENUM(zeroPos,       ExtPos_RefNatEn,    PosRefNat_None);

                DBA_InverseSign(capitalPL);
                SET_NULL_CODE(capitalPL,    ExtPos_RefOpCd);
                SET_ENUM(capitalPL,         ExtPos_PrimaryEn,   PosPrimary_Derived);
                SET_ENUM(capitalPL,         ExtPos_RefNatEn,    PosRefNat_None);
                COPY_DYNFLD(capitalPL, ExtPos, ExtPos_InstrId, mainPos, ExtPos, ExtPos_InstrId);

                DBA_DYNFLD_STP  resPL       = NULL;

                if ( (ret = FIN_PosFusion(ctx, zeroPos, capitalPL, NO_VALUE, NULL, &fact,
                                          pCapGLBPos, NULL, NULL, NULL, &resPL, NULL, FALSE)) == RET_SUCCEED)
                { /* Ok */
                    SET_ENUM(capitalPL, ExtPos_FusStateEn, FusState_Untreated);
                    SET_ENUM(zeroPos,   ExtPos_FusStateEn, FusState_Untreated);
                    SET_ENUM(resPL,     ExtPos_FusStateEn, FusState_Untreated);

                    /* PMSTA-9072 - 050510 - PMO */
                    if (NULL != *pCapGLBPos)
                    {
                        SET_NUMBER((*pCapGLBPos),  ExtPos_Qty, fabs (GET_NUMBER(mainPos, ExtPos_Qty)));
                        COPY_DYNFLD((*pCapGLBPos), ExtPos, ExtPos_PosNetAmt,    mainPos, ExtPos, ExtPos_PosNetAmt);
                        COPY_DYNFLD((*pCapGLBPos), ExtPos, ExtPos_PosGrossAmt,  mainPos, ExtPos, ExtPos_PosGrossAmt);
                    }

                    if (RET_SUCCEED != (ret = FIN_InsertPos(ctx, capitalPL, NO_VALUE, FALSE, FALSE, NULL)))
                    { /* Error */
                        FREE_DYNST(capitalPL, ExtPos);
                        FREE_DYNST(zeroPos,   ExtPos);
                    }
                    else
                    {
                        if (RET_SUCCEED != (ret = FIN_InsertPos(ctx, zeroPos, NO_VALUE, FALSE, FALSE, NULL)))
                        { /* Error */
                            FREE_DYNST(zeroPos,   ExtPos);
                        }
                    }
                }
            }
            else
            { /* Error */
                (void)MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "ExtPos");
                ret = RET_MEM_ERR_ALLOC;

                FREE_DYNST(acc2Copy,    ExtPos);
                FREE_DYNST(capitalPL,   ExtPos);
                FREE_DYNST(zeroPos,     ExtPos);
            }
        }
    }
    
    return ret;
}


/*******************************************************************************
**
**  Function    : FIN_SetBalancePositionType 
**
**  Description :  Set balance position type (gain or loss) 
**
**  Arguments   : ctx   Pointer on context-structure
**                pos   Position to treat
**                 
**  Return      : void
**
**  Last modif. : PMSTA08607 - 280909 - PMO : Wrong treatment of future positions when booking margin amount
*******************************************************************************/
STATIC void FIN_SetBalancePositionType(const FIN_FUS_CONTEXT_STP ctx, DBA_DYNFLD_STP pos)
{
    if (CMP_AMOUNT(GET_AMOUNT(pos, ExtPos_RefNetAmt), 0.0, GET_ID(pos, ExtPos_RefCurrId)) == 1)
    { /* Loss (>0) */
        FUS_SetCapCurBalPosTypeId(ctx, pos, ctx->curLBalPosTypeId);
    }
    else
    { /* Gain */
        FUS_SetCapCurBalPosTypeId(ctx, pos, ctx->curPBalPosTypeId);
    }
}


/*******************************************************************************
**
**  Function    : FIN_OpWithAnotherCurrencyThanPtf 
**
**  Description :  When we have this kind of situation, we must generate one more balance position 
**
**  Arguments   : ctx           pointer on context-structure
**                .... lot of variables inherited from calling 
**                     function FIN_ReferencePos
**                currPL        Set the computed currency P&L
**
**                 
**  Return      : RET_SUCCEED           if ok
**
**  Last modif. : PMSTA08746 - 061009 - PMO : Performance on futures in foreign currency
**                PMSTA-9120 - 161209 - PMO : Too many bp final stock when dealing with futures in foreign currency
**                PMSTA-9072 - 050510 - PMO : Future instrument with Fees&Taxes at opening position: exchange rate at opening position are not saved after adjustment operation
**                PMSTA-15298 - 040213 - PMO : Future WMP with fees & taxes: When a position in a foreign currency is closed by 2 operations, the portfolio becomes unbalanced.
**
*******************************************************************************/
STATIC RET_CODE FIN_OpWithAnotherCurrencyThanPtf( FIN_FUS_CONTEXT_STP   ctx             ,
                                                  DBA_DYNFLD_STP        currPL          ,
                                                  const DBA_DYNFLD_STP  mainPos         ,
                                                  const DBA_DYNFLD_STP  pos2            ,   /* PMSTA-15298 - 040213 - PMO */
                                                  const DBA_DYNFLD_STP  initPos         ,
                                                  const DBA_DYNFLD_STP  finPos          ,
                                                  const DBA_DYNFLD_STP  resPos          ,
                                                  const DBA_DYNFLD_STP  instrResPos     ,
                                                  const DBA_DYNFLD_STP  instrCapGLBPos  ,   /* PMSTA-15298 - 040213 - PMO */
                                                  const DBA_DYNFLD_STP  instrExchGLBPos ,   /* PMSTA-15298 - 040213 - PMO */
                                                  const DBA_DYNFLD_STP  freeAccOpenPos  ,   /* PMSTA-15298 - 040213 - PMO */
                                                  const double          fact                /* PMSTA-15298 - 040213 - PMO */
                                                )
{
    RET_CODE ret;

    /* Memory allocation error? */
    if (currPL != NULL)
    { /* No */
        NUMBER_T    currPLQty;
        AMOUNT_T    currPLNetAmt;
        AMOUNT_T    totFeesFinAmt   = ZERO_AMOUNT;
        AMOUNT_T    totFeesAmt      = ZERO_AMOUNT;
        AMOUNT_T    totFeesPos2Amt  = ZERO_AMOUNT;                                          /* PMSTA-15298 - 040213 - PMO */
        double      txFeesInit      = ZERO_AMOUNT;                                          /* PMSTA-15298 - 040213 - PMO */

        for (int i = 0; i < ExtPos_BpPosAmtNb; i++)
        {
            totFeesFinAmt   += GET_AMOUNT(finPos,   ExtPos_Bp1PosAmt + i);
            totFeesAmt      += GET_AMOUNT(initPos,  ExtPos_Bp1PosAmt + i) - GET_AMOUNT(instrResPos, ExtPos_Bp1PosAmt + i);
            totFeesPos2Amt  += GET_AMOUNT(pos2,     ExtPos_Bp1PosAmt + i);                  /* PMSTA-15298 - 040213 - PMO */
        }

        AMOUNT_T totFeesFinAmtTx = totFeesFinAmt;                                           /* PMSTA-15298 - 040213 - PMO */

        if (GET_OPADJUSTNAT(mainPos, ExtPos_AdjustNatEn) != OpAdjustNat_MarginCall)         /* PMSTA-15298 - 040213 - PMO */
        {

            if (0 != CMP_ID(GET_ID(initPos,ExtPos_RefCurrId), GET_ID(initPos,ExtPos_PosCurrId)))
            { /* Different currency, applying exchange rate */
                DBA_DYNFLD_STP initFeesPos = FUS_SearchFeesRatePos(ctx, GET_ID(initPos, ExtPos_OpenOpId));

                if (NULL != initFeesPos)
                {
                    /* PMSTA-9072 - 050510 - PMO */

                    const bool bComputed = FUS_ComputeFees(ctx, initPos, finPos, totFeesAmt, true, &totFeesAmt);

                    txFeesInit = GET_EXCHANGE(initFeesPos,  ExtPos_PosExchRate);

                    if (false == bComputed)
                    {
                        totFeesAmt *= txFeesInit;
                    }

                    
                }
                else
                {
                    totFeesAmt *= GET_EXCHANGE(currPL,  ExtPos_PosExchRate);
                }

                totFeesFinAmtTx *= GET_EXCHANGE(finPos, ExtPos_PosExchRate);
            }
        }


        const AMOUNT_T  closeFees               = totFeesPos2Amt * (1. - fact);                                                 /* PMSTA-15298 - 040213 - PMO */
        const AMOUNT_T  totFeesAmtRounded       = CAST_AMOUNT( totFeesAmt     , GET_ID(initPos, ExtPos_RefCurrId));   /* PMSTA-9072  - 050510 - PMO */ /* PMSTA-31831 - DDV - 180912 - Change currency */
        const AMOUNT_T  totInitFeesAmtRounded   = CAST_AMOUNT( totFeesFinAmtTx  , GET_ID(initPos, ExtPos_RefCurrId)); /* PMSTA-9072  - 050510 - PMO */ /* PMSTA-31831 - DDV - 180912 - Change currency */
        const AMOUNT_T  tmpRefCashCap           = NULL != instrCapGLBPos  ? GET_AMOUNT(instrCapGLBPos,  ExtPos_RefNetAmt) : 0.;
        const AMOUNT_T  tmpRefCashExch          = NULL != instrExchGLBPos ? GET_AMOUNT(instrExchGLBPos, ExtPos_RefNetAmt) : 0.;
        const AMOUNT_T  interactionEffectFees   = ZERO_AMOUNT;                                                                  /* PMSTA-15298 - 040213 - PMO */           
        AMOUNT_T        refNet                  = ZERO_AMOUNT;


        switch (ctx->portPLCompRule)
        {
            case PortPlCompRule_Final: /** With final exchange rate **/
            case PortPlCompRule_Init: /** With initial exchange rate **/
                /* PMSTA-9072 - 050510 - PMO */
                if (true == FUS_IsBuyOrSell(finPos) && NULL != instrCapGLBPos && NULL != instrExchGLBPos)
                {
                    if (0. != GET_NUMBER(instrResPos, ExtPos_Qty))
                    { /* Partial sell or Buy / PMSTA-15298 - 040213 - PMO */
                        const double    txInit  = GET_EXCHANGE(initPos, ExtPos_PosExchRate);
                        const bool      bLong   = GET_NUMBER(initPos,   ExtPos_Qty) >= ZERO_NUMBER;

                        refNet = CAST_AMOUNT((GET_EXCHANGE(finPos, ExtPos_PosExchRate) - txInit) * fabs (GET_NUMBER(freeAccOpenPos, ExtPos_Qty)), GET_ID(freeAccOpenPos, ExtPos_RefCurrId)); /* PMSTA-31831 - DDV - 180912 - Change currency */

                        if (false == bLong)
                        {
                            refNet = -refNet;
                        }
                    }
                    else
                    { /* Closing of the operation */
                        refNet = -GET_AMOUNT(resPos, ExtPos_RefNetAmt) 
                               - GET_AMOUNT(instrCapGLBPos, ExtPos_RefGrossAmt) 
                               - tmpRefCashExch 
                               + (GET_AMOUNT(instrExchGLBPos, ExtPos_RefNetAmt) - GET_AMOUNT(instrExchGLBPos, ExtPos_RefGrossAmt));
                    }
                }
                else
                {
                    const bool marginCallFlag    = OpAdjustNat_MarginCall == GET_OPADJUSTNAT(finPos, ExtPos_AdjustNatEn);

                    /* PMSTA-15298 - 040213 - PMO */
                    if (true == marginCallFlag && NULL != instrCapGLBPos && NULL != instrExchGLBPos)
                    {
                        refNet = -GET_AMOUNT(resPos, ExtPos_RefNetAmt) 
                               - GET_AMOUNT(instrCapGLBPos, ExtPos_RefGrossAmt) 
                               - tmpRefCashExch 
                               + (GET_AMOUNT(instrExchGLBPos, ExtPos_RefNetAmt) - GET_AMOUNT(instrExchGLBPos, ExtPos_RefGrossAmt));
                    }
                    else
                    {
                        refNet = -GET_AMOUNT(resPos, ExtPos_RefNetAmt) - tmpRefCashCap - tmpRefCashExch + totFeesAmtRounded + totInitFeesAmtRounded;
                    }
                }
                break;

            case PortPlCompRule_Mean: /** With average exchange rate **/
                /* PMSTA-15298 - 040213 - PMO */
                if (true == FUS_IsBuyOrSell(finPos) && NULL != instrCapGLBPos && NULL != instrExchGLBPos)
                {
                    refNet = -GET_AMOUNT(resPos,        ExtPos_RefNetAmt) 
                           - GET_AMOUNT(instrCapGLBPos, ExtPos_RefGrossAmt) 
                           - tmpRefCashExch 
                           + ( GET_AMOUNT(instrExchGLBPos, ExtPos_RefNetAmt) 
                             - GET_AMOUNT(instrExchGLBPos, ExtPos_RefGrossAmt)
                             )
                           - interactionEffectFees;                                                                                                                             
                }
                else
                {
                    refNet = -GET_AMOUNT(resPos, ExtPos_RefNetAmt) - tmpRefCashCap - tmpRefCashExch + totFeesAmtRounded + totInitFeesAmtRounded - closeFees;
                }
                break;

            default:
                (void)MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "FIN_PosFusion", "portfolio P&L computation rule");
                break;
        }






        if (GET_ENUM(initPos, ExtPos_AdjustNatEn) == OpAdjustNat_MarginCall)
        {
            currPLQty       = GET_NUMBER(currPL,  ExtPos_Qty);
            currPLNetAmt    = GET_AMOUNT(initPos, ExtPos_PosNetAmt);
        }
        else
        {
            currPLQty       = -GET_NUMBER(currPL,  ExtPos_Qty);
            currPLNetAmt    = -GET_AMOUNT(initPos, ExtPos_PosNetAmt);
        }

        SET_NUMBER(currPL,  ExtPos_Qty,             currPLQty);
        SET_ENUM(currPL,    ExtPos_RefNatEn,        PosRefNat_None);            /* PMSTA-9120 - 161209 - PMO */
        SET_ENUM(currPL,    ExtPos_PosNatEn,        PosNat_BPCurrencyFuture);   /* PMSTA-9120 - 161209 - PMO */
        SET_ENUM(currPL,    ExtPos_PrimaryEn,       PosPrimary_Second);
        SET_AMOUNT(currPL,  ExtPos_PosNetAmt,       currPLNetAmt);
        SET_AMOUNT(currPL,  ExtPos_RefGrossAmt,     refNet);
        SET_AMOUNT(currPL,  ExtPos_RefNetAmt,       refNet);
        SET_AMOUNT(currPL,  ExtPos_SysGrossAmt,     refNet);
        SET_AMOUNT(currPL,  ExtPos_SysNetAmt,       refNet);
        SET_AMOUNT(currPL,  ExtPos_InstrGrossAmt,   ZERO_AMOUNT);
        SET_AMOUNT(currPL,  ExtPos_InstrNetAmt,     ZERO_AMOUNT);

        FIN_RoundAmountsPosition(ctx, currPL);   

        /* Set balance position type (gain or loss) */
        FIN_SetBalancePositionType(ctx, currPL);

        if (RET_SUCCEED == (ret = FIN_InsertPos(ctx, currPL, NO_VALUE, FALSE, FALSE, NULL)))
        { /* Ok */
            FUS_TracePos(ctx, currPL, "currPL");
        }
        else
        { /* Error */
            FREE_DYNST(currPL, ExtPos);
        }
    }
    else
    { /* Yes, Memory allocation error */
        (void)MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "ExtPos");
        ret = RET_MEM_ERR_ALLOC;
    }

    return ret;
}


/*******************************************************************************
**
**  Function    : FIN_FixTxPositionRoundingProblems
**
**  Description :  Fix rounding problems to insure a balanced position
**
**  Arguments   :
**
**  Return      : None
**
**  Last modif. : PMSTA-9072 - 050510 - PMO : Future instrument with Fees&Taxes at opening position: exchange rate at opening position are not saved after adjustment operation
**                PMSTA-10139 - 041010 - PMO : The amount of the cash position in the portfolio is not correct as a result of margin call.
**                PMSTA-15298 - 040213 - PMO : Future WMP with fees & taxes: When a position in a foreign currency is closed by 2 operations, the portfolio becomes unbalanced.
**
*************************************** ****************************************/
STATIC void FIN_FixTxPositionRoundingProblems( const FIN_FUS_CONTEXT_STP  ctx                           ,
                                               const DBA_DYNFLD_STP       mainPos                       ,
                                                     DBA_DYNFLD_STP       newMainPos                    ,
                                               const DBA_DYNFLD_STP       pos2                          ,
                                               const DBA_DYNFLD_STP       newAccOpenPos                 ,
                                               const DBA_DYNFLD_STP       freeAccClosePos               ,
                                               const DBA_DYNFLD_STP       highPos                       ,   /* PMSTA-10139 - 041010 - PMO */
                                               const DBA_DYNFLD_STP       finPos                        ,
                                               const DBA_DYNFLD_STP       initPos                       ,
                                                     DBA_DYNFLD_STP       instrResPos                   ,
                                               const DBA_DYNFLD_STP       resPos                        ,
                                                     DBA_DYNFLD_STP       instrCapGLBPos                ,
                                               const DBA_DYNFLD_STP       instrExchGLBPos               ,
                                               const DBA_DYNFLD_STP       instrExchGLBPos2              ,   /* PMSTA-15298 - 040213 - PMO */
                                               const AMOUNT_T             computedRefNetCashExchGLBPos  ,   /* PMSTA-15298 - 040213 - PMO */
                                               const double               fact
                                             )
{ 
    /*        \|||/
               (o o)
        +--ooO--(_)-------+
        |                 |
        |   Rounding Fix  |
        |                 |
        +------------Ooo--+
              |__|__|
               || ||
              ooO Ooo
     */


    DBA_DYNFLD_STP  initFeesPos = FUS_SearchFeesRatePos(ctx, GET_ID(initPos, ExtPos_OpenOpId));
    AMOUNT_T        totFeesAmt  = .0;
    int             idx;

    if (NULL != newMainPos)
    {   /*
         * Margin call
         */

        for (idx = 0; idx < ExtPos_BpPosAmtNb; idx++)
        {
            totFeesAmt += GET_AMOUNT(newMainPos, ExtPos_Bp1PosAmt + idx);
        }

        if (NULL != initFeesPos)
        {
            totFeesAmt = CAST_AMOUNT(totFeesAmt * GET_EXCHANGE(initFeesPos, ExtPos_PosExchRate), GET_ID(freeAccClosePos, ExtPos_RefCurrId)); /* PMSTA-31831 - DDV - 180912 - Change currency */

            const AMOUNT_T deltaInstr = CAST_AMOUNT((GET_AMOUNT(newMainPos, ExtPos_RefNetAmt) + GET_AMOUNT(freeAccClosePos, ExtPos_RefNetAmt) - totFeesAmt), GET_ID(freeAccClosePos, ExtPos_RefCurrId)); /* PMSTA-31831 - DDV - 180912 - Change currency */

            if (true == OPE_AllowRounding(deltaInstr, GET_ID(freeAccClosePos, ExtPos_RefCurrId))) /* PMSTA-15298 - 040213 - PMO */ /* PMSTA-31831 - DDV - 180912 - Change currency */
            {
                OPE_ADD_AMOUNT(newMainPos, ExtPos_RefNetAmt,  deltaInstr);
            }
        }

        const AMOUNT_T instrExchGLAmt = NULL != instrExchGLBPos ? GET_AMOUNT(instrExchGLBPos, ExtPos_RefNetAmt) : 0.;

        if (NULL != instrCapGLBPos && NULL != instrExchGLBPos2)
        {
            const double interactionEffect     = GET_AMOUNT(instrExchGLBPos2, ExtPos_RefNetAmt)
                                               + computedRefNetCashExchGLBPos;                                      /* PMSTA-15298 - 040213 - PMO */

            const AMOUNT_T deltaCash = CAST_AMOUNT((GET_AMOUNT(instrCapGLBPos, ExtPos_RefNetAmt) + instrExchGLAmt - interactionEffect + GET_AMOUNT(resPos, ExtPos_RefNetAmt)), GET_ID(instrCapGLBPos, ExtPos_RefCurrId));  /* PMSTA-31831 - DDV - 180912 - Change currency */

            if (true == OPE_AllowRounding(deltaCash, GET_ID(instrCapGLBPos, ExtPos_RefCurrId))) /* PMSTA-15298 - 040213 - PMO */ /* PMSTA-31831 - DDV - 180912 - Change currency */
            {
                OPE_ADD_AMOUNT(instrCapGLBPos, ExtPos_RefNetAmt, deltaCash);
            }
        }
    }
    else
    {
        AMOUNT_T totFeesInstrResPosAmt  = .0;
        AMOUNT_T totFeesPos2Amt         = .0;

        for (idx = 0; idx < ExtPos_BpPosAmtNb; idx++)
        {
            totFeesInstrResPosAmt += GET_AMOUNT(instrResPos, ExtPos_Bp1PosAmt + idx);
            totFeesPos2Amt        += GET_AMOUNT(pos2,        ExtPos_Bp1PosAmt + idx);
        }


        if (0 == CMP_NUMBER(GET_NUMBER(instrResPos, ExtPos_Qty), 0.))
        {   /*
             * Position close
             */

            /*
             * Compute fees of the initPos
             */

            if (NULL != initFeesPos)
            {
                totFeesAmt = fabs(GET_AMOUNT(initFeesPos, ExtPos_RefGrossAmt));
            }
            else
            {
                for (idx = 0; idx < ExtPos_BpPosAmtNb; idx++)
                {
                    totFeesAmt += GET_AMOUNT(initPos, ExtPos_Bp1PosAmt + idx);
                }
            }

            /*
             * Compute fees of the finPos
             */
            AMOUNT_T totFeesFinAmt  = .0;
            for (idx = 0; idx < ExtPos_BpPosAmtNb; idx++)
            {
                totFeesFinAmt += GET_AMOUNT(finPos, ExtPos_Bp1PosAmt + idx);
            }

            totFeesFinAmt = CAST_AMOUNT(totFeesFinAmt * GET_EXCHANGE(finPos, ExtPos_PosExchRate), GET_ID(finPos, ExtPos_RefCurrId));  /* PMSTA-31831 - DDV - 180912 - Change currency */

            if (NULL != instrCapGLBPos && NULL != instrExchGLBPos)
            {
                const AMOUNT_T deltaCash    = CAST_AMOUNT((GET_AMOUNT(instrCapGLBPos, ExtPos_RefNetAmt) + GET_AMOUNT(instrExchGLBPos, ExtPos_RefNetAmt) + GET_AMOUNT(resPos, ExtPos_RefNetAmt)), GET_ID(instrExchGLBPos, ExtPos_RefCurrId)); /* PMSTA-31831 - DDV - 180912 - Change currency */
                const AMOUNT_T deltaOp      = CAST_AMOUNT(deltaCash - totFeesAmt - totFeesFinAmt, GET_ID(instrExchGLBPos, ExtPos_RefCurrId)); /* PMSTA-31831 - DDV - 180912 - Change currency */

                if (true == OPE_AllowRounding(deltaOp, GET_ID(instrExchGLBPos, ExtPos_RefCurrId))) /* PMSTA-15298 - 040213 - PMO */ /* PMSTA-31831 - DDV - 180912 - Add currency */
                {
                    OPE_ADD_AMOUNT(instrCapGLBPos, ExtPos_RefNetAmt, -deltaOp);
                }
            }
        }
        else
        {   /*
             * Partial position close
             */
            AMOUNT_T totFeesFinAmt  = .0;

            for (idx = 0; idx < ExtPos_BpPosAmtNb; idx++)
            {
                totFeesFinAmt += GET_AMOUNT(finPos, ExtPos_Bp1PosAmt + idx);
            }

            AMOUNT_T closeFees  = totFeesPos2Amt * ( 1. - fact);
            AMOUNT_T closeFees2 = totFeesPos2Amt;
            totFeesFinAmt = CAST_AMOUNT(totFeesFinAmt * GET_EXCHANGE(finPos, ExtPos_PosExchRate), GET_ID(finPos, ExtPos_RefCurrId)); /* PMSTA-31831 - DDV - 180912 - Change currency */

            if (NULL != initFeesPos)
            {
                totFeesAmt = CAST_AMOUNT(totFeesInstrResPosAmt * GET_EXCHANGE(initFeesPos, ExtPos_PosExchRate), GET_ID(freeAccClosePos, ExtPos_RefCurrId)); /* PMSTA-31831 - DDV - 180912 - Change currency */

                const AMOUNT_T deltaInstr = CAST_AMOUNT(GET_AMOUNT(instrResPos, ExtPos_RefNetAmt) + GET_AMOUNT(newAccOpenPos, ExtPos_RefNetAmt) - totFeesAmt, GET_ID(instrResPos, ExtPos_RefCurrId)); /* PMSTA-31831 - DDV - 180912 - Change currency */

                if (true == OPE_AllowRounding(deltaInstr, GET_ID(instrResPos, ExtPos_RefCurrId))) /* PMSTA-15298 - 040213 - PMO */ /* PMSTA-31831 - DDV - 180912 - Add currency */
                {
                    OPE_ADD_AMOUNT(instrResPos, ExtPos_RefNetAmt, deltaInstr);
                }

                AMOUNT_T        closeFeesTx     = ZERO_AMOUNT;
                AMOUNT_T        closeFeesTx2    = ZERO_AMOUNT;
                const AMOUNT_T  instrExchGLAmt  = NULL != instrExchGLBPos ? GET_AMOUNT(instrExchGLBPos, ExtPos_RefNetAmt) : ZERO_AMOUNT;
                const bool      bComputedFees   =  FUS_ComputeFees(ctx, initPos, finPos, closeFees,  true, &closeFeesTx)
                                                && FUS_ComputeFees(ctx, initPos, finPos, closeFees2, true, &closeFeesTx2);

                if (NULL != instrCapGLBPos && NULL != instrExchGLBPos2 && true == bComputedFees)                                /* PMSTA-15298 - 040213 - PMO */
                {
                    closeFeesTx  = CAST_AMOUNT(closeFeesTx,  GET_ID(instrResPos, ExtPos_InstrCurrId));
                    closeFeesTx2 = CAST_AMOUNT(closeFeesTx2, GET_ID(instrResPos, ExtPos_InstrCurrId));
                    AMOUNT_T deltaCash;

                    /* PMSTA-10139 - 041010 - PMO */
                    if (highPos == finPos)
                    { /* initPos < finPos */
                        deltaCash = CAST_AMOUNT(( GET_AMOUNT(instrCapGLBPos, ExtPos_RefNetAmt)
                                                + GET_AMOUNT(resPos,         ExtPos_RefNetAmt) 
                                                + instrExchGLAmt
                                                ) - (CAST_AMOUNT(totFeesFinAmt * ( 1. - fact), GET_ID(instrResPos, ExtPos_RefCurrId))) /* PMSTA-31831 - DDV - 180912 - Change currency */
                                                  - closeFeesTx2
                                               , GET_ID(instrCapGLBPos, ExtPos_InstrCurrId));
                    }
                    else
                    { /* initPos > finPos */
                        const double interactionEffect     = -GET_AMOUNT(instrExchGLBPos2, ExtPos_RefNetAmt)
                                                           - computedRefNetCashExchGLBPos;                                      /* PMSTA-15298 - 040213 - PMO */
                        const double interactionEffectFees = CAST_AMOUNT( closeFees 
                                                                          * ( GET_EXCHANGE(finPos,      ExtPos_PosExchRate) 
                                                                            - GET_EXCHANGE(initFeesPos, ExtPos_PosExchRate)
                                                                            ) / 2.   
                                                                        , GET_ID(instrCapGLBPos, ExtPos_RefCurrId)); /* PMSTA-15298 - 040213 - PMO */ /* PMSTA-31831 - DDV - 180912 - Change currency */

                        deltaCash = CAST_AMOUNT(( GET_AMOUNT(instrCapGLBPos, ExtPos_RefNetAmt) 
                                                + GET_AMOUNT(resPos,         ExtPos_RefNetAmt) 
                                                + instrExchGLAmt 
                                                - interactionEffect 
                                                + interactionEffectFees
                                                ) - totFeesFinAmt - closeFeesTx
                                               , GET_ID(instrCapGLBPos, ExtPos_RefCurrId)); /* PMSTA-15298 - 040213 - PMO */ /* PMSTA-31831 - DDV - 180912 - Change currency */
                    }

                    if (true == OPE_AllowRounding(deltaCash, GET_ID(instrCapGLBPos, ExtPos_RefCurrId))) /* PMSTA-15298 - 040213 - PMO */ /* PMSTA-31831 - DDV - 180912 - Add currency */
                    {
                        OPE_ADD_AMOUNT(instrCapGLBPos, ExtPos_RefNetAmt, -deltaCash);
                    }
                }
            }
        }


        if (NULL != initFeesPos)
        {
            DBA_DYNFLD_STP  initPos2;
            DBA_DYNFLD_STP  finPos2;

            FIN_DefineInitAndFinPos(&finPos2, &initPos2, mainPos, pos2);

            if (PosPrimary_Derived == GET_POSPRIMARY(initPos2, ExtPos_PrimaryEn))
            {
                if (0 == CMP_NUMBER(GET_NUMBER(instrResPos, ExtPos_Qty), 0.))
                {   /*
                     * Position close
                     */
                    const AMOUNT_T feesSubstractedTxAmt = fabs(GET_AMOUNT(initFeesPos, ExtPos_RefGrossAmt));
                    const AMOUNT_T feesSubstractedAmt   = totFeesPos2Amt - totFeesInstrResPosAmt;

                    /*
                     * Keep up to date remaining fees
                     */
                    OPE_ADD_AMOUNT(initFeesPos, ExtPos_PosGrossAmt, feesSubstractedAmt);
                    OPE_ADD_AMOUNT(initFeesPos, ExtPos_RefGrossAmt, feesSubstractedTxAmt);
                }
                else
                {  /*
                    * Partial position close
                    */
                    const AMOUNT_T feesRef = CAST_AMOUNT(GET_AMOUNT(instrResPos, ExtPos_RefGrossAmt) - GET_AMOUNT(instrResPos, ExtPos_RefNetAmt), GET_ID(instrResPos, ExtPos_RefCurrId)); /* PMSTA-31831 - DDV - 180912 - Change currency */
                    const AMOUNT_T feesPos = CAST_AMOUNT(GET_AMOUNT(instrResPos, ExtPos_PosGrossAmt) - GET_AMOUNT(instrResPos, ExtPos_PosNetAmt), GET_ID(instrResPos, ExtPos_PosCurrId)); /* PMSTA-31831 - DDV - 180912 - Change currency */

                    /* PMSTA-10139 - 041010 - PMO
                     * Keep up to date remaining fees
                     */
                    if (highPos == finPos2)
                    {
                        DBA_DYNFLD_STP  finFeesPos = FUS_SearchFeesRatePos(ctx, GET_ID(finPos2, ExtPos_OpenOpId));

                        if (NULL != finFeesPos)
                        {
                            SET_AMOUNT(finFeesPos, ExtPos_PosGrossAmt, feesPos);
                            SET_AMOUNT(finFeesPos, ExtPos_RefGrossAmt, feesRef);
                        }
                    }
                    else
                    {
                        SET_AMOUNT(initFeesPos, ExtPos_PosGrossAmt, feesPos);
                        SET_AMOUNT(initFeesPos, ExtPos_RefGrossAmt, feesRef);
                    }
                }


                switch (FIN_GetKindOfFusion(mainPos, pos2, instrResPos))
                {
                    case FusionReduce:
                        break;

                    case FusionClose:
                        /*
                         * It is possible that each partial close are balanced but a rounding error remaind
                         */
                        if (NULL != instrCapGLBPos)
                        {
                            const AMOUNT_T deltaCash = GET_AMOUNT(initFeesPos, ExtPos_RefGrossAmt);

                            if (true == OPE_AllowRounding(deltaCash, GET_ID(initFeesPos, ExtPos_RefCurrId))) /* PMSTA-15298 - 040213 - PMO */ /* PMSTA-31831 - DDV - 180912 - Change currency */
                            {
                                OPE_ADD_AMOUNT(instrCapGLBPos, ExtPos_RefNetAmt, -deltaCash);
                            }
                        }
                        break;

                    case FusionSwitchLongShortFirst:
                    case FusionSwitchLongShortNext:
                        break;

                    case FusionMergeBuySell:
                        break;

                    default:
                        break;
                }
            }
        }
        else
        {
            /* PMSTA-10139 - 041010 - PMO
             * Keep up to date remaining fees
             */
            if (highPos == finPos)
            {
                const AMOUNT_T feesRef = CAST_AMOUNT(GET_AMOUNT(instrResPos, ExtPos_RefGrossAmt) - GET_AMOUNT(instrResPos, ExtPos_RefNetAmt), GET_ID(instrResPos, ExtPos_RefCurrId)); /* PMSTA-31831 - DDV - 180912 - Change currency */
                const AMOUNT_T feesPos = CAST_AMOUNT(GET_AMOUNT(instrResPos, ExtPos_PosGrossAmt) - GET_AMOUNT(instrResPos, ExtPos_PosNetAmt), GET_ID(instrResPos, ExtPos_PosCurrId)); /* PMSTA-31831 - DDV - 180912 - Change currency */
                DBA_DYNFLD_STP  finFeesPos = FUS_SearchFeesRatePos(ctx, GET_ID(finPos, ExtPos_OpenOpId));

                if (NULL != finFeesPos)
                {
                    SET_AMOUNT(finFeesPos, ExtPos_PosGrossAmt, feesPos);
                    SET_AMOUNT(finFeesPos, ExtPos_RefGrossAmt, feesRef);
                }
            }
        }
    }
}


/*******************************************************************************
**
**  Function    : FIN_FixPositionRoundingProblems
**
**  Description :  Fix rounding problems to insure a balanced position
**
**  Arguments   :
**
**  Return      : None
**
**  Last modif. : PMSTA-9072 - 050510 - PMO : Future instrument with Fees&Taxes at opening position: exchange rate at opening position are not saved after adjustment operation
**                PMSTA-10139 - 041010 - PMO : The amount of the cash position in the portfolio is not correct as a result of margin call.
**                PMSTA-18005 - 200414 - PMO : Fusion may crash while processing future
**
*************************************** ****************************************/
STATIC void FIN_FixPositionRoundingProblems(       DBA_DYNFLD_STP       newMainPos          ,
                                             const DBA_DYNFLD_STP       pos2                ,
                                             const DBA_DYNFLD_STP       newAccOpenPos       ,
                                             const DBA_DYNFLD_STP       highPos             ,   /* PMSTA-10139 - 041010 - PMO */
                                             const DBA_DYNFLD_STP       finPos              ,
                                                   DBA_DYNFLD_STP       instrResPos         ,
                                             const DBA_DYNFLD_STP       resPos              ,
                                                   DBA_DYNFLD_STP       instrCapGLBPos      ,
                                             const double               fact
                                             )
{
    int             idx;

    if (NULL != newMainPos)
    {   /*
         * Margin call
         */
    }
    else
    {
        AMOUNT_T totFeesInstrResPosAmt  = .0;
        AMOUNT_T totFeesPos2Amt         = .0;

        for (idx = 0; idx < ExtPos_BpPosAmtNb; idx++)
        {
            totFeesInstrResPosAmt += GET_AMOUNT(instrResPos, ExtPos_Bp1PosAmt + idx);
        }

        for (idx = 0; idx < ExtPos_BpPosAmtNb; idx++)
        {
            totFeesPos2Amt += GET_AMOUNT(pos2, ExtPos_Bp1PosAmt + idx);
        }


        if (0 == CMP_NUMBER(GET_NUMBER(instrResPos, ExtPos_Qty), 0.))
        {   /*
             * Position close
             */
        }
        else
        {   /*
             * Partial position close
             */
            AMOUNT_T totFeesFinAmt  = .0;
            for (idx = 0; idx < ExtPos_BpPosAmtNb; idx++)
            {
                totFeesFinAmt += GET_AMOUNT(finPos, ExtPos_Bp1PosAmt + idx);
            }

            /* PMSTA-18005 - 200414 - PMO */
            if (NULL != newAccOpenPos)
            {
                const AMOUNT_T deltaInstr = CAST_AMOUNT(GET_AMOUNT(instrResPos, ExtPos_RefNetAmt) + GET_AMOUNT(newAccOpenPos, ExtPos_RefNetAmt) - totFeesInstrResPosAmt, GET_ID(instrResPos, ExtPos_RefCurrId)); /* PMSTA-31831 - DDV - 180912 - Change currency */

                OPE_ADD_AMOUNT(instrResPos, ExtPos_RefNetAmt, -deltaInstr);
            }

            if (NULL != instrCapGLBPos)
            {
                AMOUNT_T deltaCash;

                /* PMSTA-10139 - 041010 - PMO */
                if (highPos == finPos)
                { /* initPos < finPos */
                    deltaCash = CAST_AMOUNT((GET_AMOUNT(instrCapGLBPos, ExtPos_RefNetAmt) + GET_AMOUNT(resPos, ExtPos_RefNetAmt)) - (CAST_AMOUNT(totFeesFinAmt * ( 1. - fact), GET_ID(instrResPos, ExtPos_RefCurrId))) - totFeesPos2Amt, GET_ID(instrCapGLBPos, ExtPos_RefCurrId)); /* PMSTA-31831 - DDV - 180912 - Change currency */
                }
                else
                { /* initPos > finPos */
                    const AMOUNT_T closeFees  = CAST_AMOUNT(totFeesPos2Amt * ( 1. - fact), GET_ID(instrResPos, ExtPos_RefCurrId)); /* PMSTA-31831 - DDV - 180912 - Change currency */
                    deltaCash = CAST_AMOUNT((GET_AMOUNT(instrCapGLBPos, ExtPos_RefNetAmt) + GET_AMOUNT(resPos, ExtPos_RefNetAmt)) - totFeesFinAmt - closeFees, GET_ID(instrCapGLBPos, ExtPos_RefCurrId)); /* PMSTA-31831 - DDV - 180912 - Change currency */
                }

                OPE_ADD_AMOUNT(instrCapGLBPos, ExtPos_RefNetAmt,  -deltaCash);
            }
        }
    }
}


/*******************************************************************************
**
**  Function    :   FUS_CompareAcc2
**
**  Description :   Compare a position with the reference position
**                  Checks:
**                  - if the position is opened
**                  - It is an account 2
**                  - It is a cash account
**                  - There is no quantity
**                  - Same open oper id than in the reference position
**
**  Arguments   :   ctx         Pointer to a fusion context structure
**                  refPos      Reference position
**                  fnCmp       Comparison function
**
**  Return      :   Pointer to the position
**                  NULL if not found
**
**  Last modif. :   PMSTA-10139 - 041010 - PMO : The amount of the cash position in the portfolio is not correct as a result of margin call.
**
*******************************************************************************/
bool FUS_CompareAcc2(const DBA_DYNFLD_STP refPos, const DBA_DYNFLD_STP currPos)
{
    return     FusState_Opened   == GET_ENUM(currPos,               ExtPos_FusStateEn)
            && PosNat_Acct2Pos   == GET_POSNAT(currPos,             ExtPos_PosNatEn)
            && InstrNat_CashAcct == GET_INSTRNAT(currPos,           ExtPos_InstrNat)
            &&  0                == CMP_NUMBER(GET_NUMBER(currPos,  ExtPos_Qty), ZERO_NUMBER)
            &&  0                == CMP_ID(GET_ID(currPos,          ExtPos_OpenOpId), GET_ID(refPos, ExtPos_OpenOpId));
}


/*******************************************************************************
**
**  Function    : FIN_FusFreeCashPos 
**
**  Description :  cut the FIN_ReferencePos function. This part can be called 
**                 with different values of ctx->today . 
**
**  Arguments   : ctx           pointer on context-structure
**                .... lot of variables inherited from calling 
**                     function FIN_ReferencePos
**
**                 
**  Return      : RET_SUCCEED           if ok
**
**  Last modif. : PMSTA02926 - EFE - 070703
**                PMSTA-3257 - 170707 - PMO : P&L computation problem with Future FIFO and partial sell
**                PMSTA-5615 - 040208 - PMO : On future closing operation (Future FIFO) , the final stock is wrongly computed on the cash account1
**                PMSTA-5595 - 250608 - PMO : Margin call on Future / Wrong Cash account sign in Stock flow analysis
**                PMSTA-6540 - 040708 - PMO : Return calculation wrong for future instrument (with adjustment operation)
**                PMSTA-6328 - 060808 - PMO : Cash account incorrectly affected when entering variation margin adjustment
**                PMSTA-6921 - 311008 - PMO : Closing of Future with cash portfolio
**                PMSTA08471 - 280709 - PMO : When the system parameter CASH_ADJUSTMENT is set to 0 or the cash adjustment flag of portfolio is set to 0, Fusion process always moves cash flows of P&L in cash portfolio
**                PMSTA08746 - 061009 - PMO : Performance on futures in foreign currency
**                PMSTA08607 - 280909 - PMO : Wrong treatment of future positions when booking margin amount
**                PMSTA-9072 - 050510 - PMO : Future instrument with Fees&Taxes at opening position: exchange rate at opening position are not saved after adjustment operation
**                PMSTA-10139 - 041010 - PMO : The amount of the cash position in the portfolio is not correct as a result of margin call.
**                PMSTA-15298 - 040213 - PMO : Future WMP with fees & taxes: When a position in a foreign currency is closed by 2 operations, the portfolio becomes unbalanced.
**                PMSTA-17020 - 021013 - PMO : Handling of futures operations without account
**                PMSTA-17616 - 120214 - PMO : Fusion server crashes in case no currency P&L are generated for partial sell of Futures
**                PMSTA-17898 - 160414 - PMO : New Fusion Criteria to manage the contract dates for margin calls after partial closing
**
*******************************************************************************/
STATIC RET_CODE  FIN_FusFreeCashPos ( FIN_FUS_CONTEXT_STP      ctx                    , 
                                      const DBA_DYNFLD_STP     mainPos                , 
                                      const DBA_DYNFLD_STP     newMainPos             ,         /* PMSTA08607 - 280909 - PMO */        
                                      const DBA_DYNFLD_STP     freeAccOpenPos         ,
                                      const DBA_DYNFLD_STP     freeAccClosePos        , 
                                      const DBA_DYNFLD_STP     newAccClosePos         ,         /* PMSTA08607 - 280909 - PMO */
                                      DBA_DYNFLD_STP           cashCapGLBPos          , 
                                      DBA_DYNFLD_STP           cashExchGLBPos         ,
                                      const DBA_DYNFLD_STP     accOpenPos             ,
                                      const DBA_DYNFLD_STP     newAccOpenPos          ,         /* PMSTA-9072 - 050510 - PMO */
                                      const DBA_DYNFLD_STP     accClosePos            ,
                                      const DBA_DYNFLD_STP     acc2ClosePosDerived    ,
                                      DBA_DYNFLD_STP           acc2ClosePos           , 
                                      DBA_DYNFLD_STP           newAcc2ClosePos        ,
                                      const DBA_DYNFLD_STP     highPos                ,         /* PMSTA08746 - 061009 - PMO */
                                      const DBA_DYNFLD_STP     finPos                 ,
                                      const DBA_DYNFLD_STP     adjPos                 ,
                                      const DBA_DYNFLD_STP     initPos                ,
                                      const DBA_DYNFLD_STP *   pos2                   ,
                                      DBA_DYNFLD_STP           instrResPos            ,
                                      const DBA_DYNFLD_STP     lowPos                 ,
                                      DBA_DYNFLD_STP           instrCapGLBPos         ,
                                      DBA_DYNFLD_STP           instrExchGLBPos        , 
                                      const int                acc2ClosePosDerivedIdx ,
                                      const double             fact                   , 
                                      const ID_T               saveResPosOpenOperId   ,
                                      const DATETIME_T         saveResPosBeginDate    ,
                                      const CODE_T             saveResPosOpenOperCode ,
                                      const int                PosLogTypesIdx         ,
                                      int                      acc2CloseIdx           ,
                                      const bool               fusInFutureFlg         ,
                                      const FLAG_T             cashValueDateFlg       ,
                                      const bool               mergeCaseFusFlag       ,
                                      const bool               bOpWithAnotherCurrencyThanPtf	/* PMSTA08746 - 061009 - PMO */
                                    )
{
    DBA_DYNFLD_STP  resPos=NULL, resGLBPos=NULL, newCashExchGLBPos=NULL, newCashCapGLBPos=NULL;
    DBA_DYNFLD_STP  capGLBPos       = NULL;
    double          fact2       = .0;    /* REF11075 - 050407 - PMO */
    bool            useAcc2Flag = true; 
    RET_CODE        ret;
    ID_T            saveCashBalPosTpId, saveInstrBalPosTpId;
    AMOUNT_T        refNet, refGross;
    bool            bCashPortfolio  = IS_NULLFLD(finPos, ExtPos_CashPortfolioId) == FALSE;      /* PMSTA-6921 - 311008 - PMO */
    DBA_DYNFLD_STP  currPL          = NULL;                                                     /* PMSTA08746 - 061009 - PMO */
    bool            bPLInCpt2ForMarginCall = false;                                             /* PMSTA08607 - 280909 - PMO */
    const bool  bOpWithAnotherCurrencyThanPtfSplitPL	=  NULL            != ctx->posLogTypesTab[PosLogTypesIdx].ptrInstrument   /* PMSTA08746 - 061009 - PMO */
														&& InstrNat_Future == GET_ENUM(ctx->posLogTypesTab[PosLogTypesIdx].ptrInstrument, A_Instr_NatEn)
														&& 0               != CMP_ID(GET_ID(mainPos,ExtPos_RefCurrId), GET_ID(mainPos,ExtPos_PosCurrId))
														&& TRUE            == ctx->applFusionFutSplitCurrPl;
    
    if (true == bOpWithAnotherCurrencyThanPtf)                                                  /* PMSTA08746 - 061009 - PMO */
    {
        currPL = FUS_DynStDup(freeAccOpenPos, ctx);

        /* Memory allocation error? */
        if (currPL == NULL)
        { /* Yes */
            (void)MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "ExtPos");
            return RET_MEM_ERR_ALLOC;
        }
    }


    /***** If flag explfusion is on, fuse two "free" cash positions *****/
    /* If Margin Call, we must inverse all signs of the "freeAccClose" position to force a Close Case */
    if (GET_ENUM(mainPos, ExtPos_AdjustNatEn) == OpAdjustNat_MarginCall)
    {
        DBA_InverseSign(freeAccClosePos);
    }


    /* REF11265 - 051021 - EFE (PMO) */
    if (  (POSPRIMARY_ENUM) GET_ENUM(accClosePos, ExtPos_PrimaryEn) == PosPrimary_Primary
       || (POSPRIMARY_ENUM) GET_ENUM(accClosePos, ExtPos_PrimaryEn) == PosPrimary_Derived
       )
    { 
        if (( GET_POSREFNAT(accOpenPos,  ExtPos_RefNatEn) == PosRefNat_FutOpen &&
              GET_POSREFNAT(accClosePos, ExtPos_RefNatEn) == PosRefNat_FutClose
             )
           || /* REF11417 - 4.20 - Margin Calls and Fees wrongly computed when Future=FIFO is used */
           ( GET_POSREFNAT(accOpenPos,  ExtPos_RefNatEn) == PosRefNat_FutFifo &&
             GET_POSREFNAT(accClosePos, ExtPos_RefNatEn) == PosRefNat_FutFifo
             ) 
           || /* PMSTA-4559 - 011107 - PMO */
           ( GET_POSREFNAT(accOpenPos,  ExtPos_RefNatEn) == PosRefNat_FutWMP &&
             GET_POSREFNAT(accClosePos, ExtPos_RefNatEn) == PosRefNat_FutWMP
             ) 
           || /* PMSTA-17898 - 160414 - PMO */
           ( GET_POSREFNAT(accOpenPos,  ExtPos_RefNatEn) == PosRefNat_FutContract &&
             GET_POSREFNAT(accClosePos, ExtPos_RefNatEn) == PosRefNat_FutContract
             )
           )
        { /* Don't use Acc2 for the P&L */

            /* PMSTA02926-EFE-070705 / PMSTA-3257 - 170707 - PMO */
            if (FALSE == IsCash2MustBeUsed(acc2ClosePos) && FALSE == IsCash2MustBeUsed(acc2ClosePosDerived))
            {
                useAcc2Flag = false;
            }
        }
    }


    /* PMSTA08607 - 280909 - PMO 
     * Processing of the P&L when it was given in the account 2
     */
    if (GET_ENUM(mainPos, ExtPos_AdjustNatEn) == OpAdjustNat_MarginCall)    /* PMSTA-10715 - 211010 - PMO */
    {
        ret = FIN_PLInCpt2ForMarginCall(ctx,
                                        mainPos,
                                        newMainPos,
                                        freeAccClosePos,
                                        newAccClosePos,
                                        acc2ClosePosDerived,
                                        acc2ClosePos,
                                        instrResPos,
                                        instrCapGLBPos,
                                        useAcc2Flag,
                                        bCashPortfolio,                     /* PMSTA-10139 - 041010 - PMO */
                                        &bPLInCpt2ForMarginCall,
                                        &capGLBPos
                                       );
        if (RET_SUCCEED != ret)
        { /* Error */
            FREE_DYNST(currPL, ExtPos);
            return ret;
        }
    }

    /*
     * Fusion of two "free" cash positions
     * - When we have a cash portfolio, we don't insert the resulting position into the context     PMSTA-6921 - 311008 - PMO
     */
    if ( (ret = FIN_PosFusion(ctx, freeAccOpenPos, freeAccClosePos, FIN_GetPosLogTypeIdx(ctx, freeAccOpenPos), NULL, &fact2,
                              &cashCapGLBPos, &cashExchGLBPos, NULL, NULL,
                              &resPos, NULL, FALSE)) != RET_SUCCEED)
    { /* Error */
        FREE_DYNST(currPL, ExtPos); /* PMSTA08746 - 061009 - PMO */
        return ret;
    }

    FIN_RoundAmount(resPos, ExtPos_Qty, ExtPos_PosCurrId);  /* PMSTA08607 - 280909 - PMO */


    if (NULL != instrCapGLBPos && FUS_IsBuyOrSell(mainPos))
    {
        /*  PMSTA08607 - 280909 - PMO
         *  Synchronization of the rounding of bp between instrument and cash
         *  Problem comes when dealing with a values like 
         *  -> 0.045 in the capital profit. Rounded to 0.04
         *  -> 0.025 in the resulting position. Rounded to 0.03
         *  In this case we check the difference between instrument and cash.
         *  Regarding the difference, for example 0.05, we can change the rounding values.
         *  0.025 becomes 0.02 for the resulting position and 0.045 becomes 0.05
         *  This insure a balanced portfolio
         */
        const double    deltaAmount     = fabs(fabs(GET_AMOUNT(resPos, ExtPos_PosNetAmt)) - fabs (GET_AMOUNT(instrCapGLBPos, ExtPos_RefNetAmt)));
        const AMOUNT_T  totFeesInstrAmt = FUS_ComputeBPSumPos(instrCapGLBPos);              /* Sum of all bp instrument / PMSTA-17020 - 021013 - PMO */

        if (0 != CMP_AMOUNT(deltaAmount, totFeesInstrAmt, GET_ID(resPos, ExtPos_RefCurrId)))
        {
            double          precision;
            DBA_DYNFLD_STP  currPtr     = NULL;
            FLAG_T          freeFlag    = FALSE;

			/* PMSTA16847 - DDV - 130924 - Add freeFlag parameter */
            if (DBA_GetCurrById(GET_ID(resPos, ExtPos_RefCurrId), &currPtr, &freeFlag) == RET_SUCCEED)
            {
                precision = DBA_GetCurrPrecision(currPtr) / 10.;
                if (freeFlag == TRUE) {FREE_DYNST(currPtr, A_Curr);}
            }
            else
            {   /* take default value for precision and rule */
                precision = 0.001;
	        }

            double      bpInstr1;                                           /* BP in capital instrument */
            double      bpInstr2;                                           /* bpInstr1 rounded         */
            FIELD_IDX_T fieldIdx        = ExtPos_Bp1PosAmt;                 /* BP filed index           */
            AMOUNT_T    totFeesToPatch  = deltaAmount - totFeesInstrAmt;    /* Rounding total to move   */

            /* Check all bp */
            for (FIELD_IDX_T i = 0; i < ExtPos_BpPosAmtNb; i++, fieldIdx++)
            {
                if (0 != CMP_AMOUNT(GET_AMOUNT(instrCapGLBPos, fieldIdx), .0, GET_ID(resPos, ExtPos_RefCurrId)))
                {
                    bpInstr1 = fabs(precision + fabs((GET_AMOUNT((*pos2), fieldIdx) / GET_NUMBER((*pos2), ExtPos_Qty)) * GET_NUMBER(instrCapGLBPos, ExtPos_Qty)));
                    bpInstr2 = CAST_AMOUNT(bpInstr1, GET_ID(instrCapGLBPos, ExtPos_RefCurrId));

                    if (bpInstr2 > bpInstr1)
                    {
                        /* We need to patch this BP */
                        const double bpDelta = fabs((bpInstr2 + GET_AMOUNT(mainPos, fieldIdx)) - GET_AMOUNT(instrCapGLBPos, fieldIdx));

                        /* PMSTA-15298 - 040213 - PMO */
                        if (true == OPE_AllowRounding(bpDelta, GET_ID(instrCapGLBPos, ExtPos_RefCurrId))) /* PMSTA-31831 - DDV - 180912 - Add currency */
                        {
                            OPE_ADD_AMOUNT(instrCapGLBPos, fieldIdx,  bpDelta);
                            OPE_ADD_AMOUNT(instrResPos,    fieldIdx, -bpDelta);
                            totFeesToPatch -= bpDelta;

                            if (0 == CMP_AMOUNT(totFeesToPatch, .0, GET_ID(resPos, ExtPos_RefCurrId)))
                            {
                                break;
                            }
                        }
                    }
                }
            }
        }
    }


    /* PMSTA08746 - 061009 - PMO
     * For an operation with a future instrument and a currency different than the portfolio's currency,
     * execute the following block of code
     */
    AMOUNT_T        refNetAdjusted  = .0;
    DBA_DYNFLD_STP  instrExchResPos = NULL;

    if (true == bOpWithAnotherCurrencyThanPtf)
    {
        /* PMSTA-15298 - 040213 - PMO */
        if (true == FUS_IsBuyOrSell(finPos) && 0. != GET_NUMBER(instrResPos, ExtPos_Qty))
        { /* Partial sell or Buy */

            switch (ctx->portPLCompRule)
            {
                case PortPlCompRule_Final:  /** With final exchange rate    **/
                    {
                        const double    qty         = fabs (GET_NUMBER(freeAccOpenPos, ExtPos_Qty));
                        const double    delatTx     = GET_EXCHANGE(finPos, ExtPos_PosExchRate) - GET_EXCHANGE(initPos, ExtPos_PosExchRate);
                        const AMOUNT_T  refGross2   = CAST_AMOUNT(delatTx * qty, GET_ID(freeAccOpenPos, ExtPos_RefCurrId)); /* PMSTA-15298 - 040213 - PMO */ /* PMSTA-31831 - DDV - 180912 - Change currency */
                        const bool      bLong       = GET_NUMBER(initPos,   ExtPos_Qty) >= ZERO_NUMBER;                                         /* PMSTA-15298 - 040213 - PMO */

                        /* PMSTA-17616 - 120214 - PMO */
                        if (NULL != instrExchGLBPos)
                        {
                            if (true == bLong)
                            {
                                SET_AMOUNT(instrExchGLBPos, ExtPos_RefGrossAmt, -refGross2);
                            }
                            else
                            {
                                SET_AMOUNT(instrExchGLBPos, ExtPos_RefGrossAmt, refGross2);
                            }
                        }
                    }
                    break;

                case PortPlCompRule_Init:   /** With initial exchange rate  **/
                    { /* PMSTA-15298 - 040213 - PMO */
                        const double    qty                 = fabs (GET_NUMBER(finPos, ExtPos_Qty));
                        const double    pqr                 = fabs (GET_PRICE(finPos, ExtPos_Quote) / GET_PRICE(finPos, ExtPos_Price));
                        const double    qtyRef              = (qty / pqr);
                        const double    delatTx             = GET_EXCHANGE(finPos, ExtPos_PosExchRate) - GET_EXCHANGE(initPos, ExtPos_PosExchRate);
                        const double    deltaQuote          = GET_PRICE(finPos, ExtPos_Quote) - GET_PRICE(initPos, ExtPos_Quote);
                        const double    interactionEffect   = qtyRef * delatTx * deltaQuote;
                        const AMOUNT_T  refGross2           = CAST_AMOUNT((delatTx * qtyRef * GET_PRICE(initPos, ExtPos_Quote)) + interactionEffect, GET_ID(finPos, ExtPos_RefCurrId)); /* PMSTA-31831 - DDV - 180912 - Change currency */
                        const bool      bLong               = GET_NUMBER(initPos,   ExtPos_Qty) >= ZERO_NUMBER;

                        /* PMSTA-17616 - 120214 - PMO */
                        if (NULL != instrExchGLBPos)
                        {
                            if (true == bLong)
                            {
                                SET_AMOUNT(instrExchGLBPos, ExtPos_RefGrossAmt, -refGross2);
                                SET_AMOUNT(instrExchGLBPos, ExtPos_RefNetAmt,   -refGross2);
                            }
                            else
                            {
                                SET_AMOUNT(instrExchGLBPos, ExtPos_RefGrossAmt, refGross2);
                                SET_AMOUNT(instrExchGLBPos, ExtPos_RefNetAmt,   refGross2);
                            }
                        }

                        /* PMSTA-17616 - 120214 - PMO */
                        if (NULL != instrCapGLBPos)
                        {
                            if (highPos == initPos && FUS_IsBuyOrSell(finPos))
                            {
                                AMOUNT_T totFeesInitAmt = 0.;
                                AMOUNT_T totFeesFinAmt  = 0.;
                                AMOUNT_T totFeesResAmt  = 0.;

                                for (int idx = 0; idx < ExtPos_BpPosAmtNb; idx++)
                                {
                                    totFeesInitAmt += GET_AMOUNT(initPos,     ExtPos_Bp1PosAmt + idx);
                                    totFeesFinAmt  += GET_AMOUNT(finPos,      ExtPos_Bp1PosAmt + idx);
                                    totFeesResAmt  += GET_AMOUNT(instrResPos, ExtPos_Bp1PosAmt + idx);
                                }


                                DBA_DYNFLD_STP  initFeesPos = FUS_SearchFeesRatePos(ctx, GET_ID(initPos, ExtPos_OpenOpId));
                                const double    feesTx      = NULL != initFeesPos ? GET_EXCHANGE(initFeesPos, ExtPos_PosExchRate) : GET_EXCHANGE(initPos, ExtPos_PosExchRate);
                                const AMOUNT_T  finFees     = CAST_AMOUNT(totFeesFinAmt, GET_ID(initPos, ExtPos_RefCurrId));
                                const double    finFeesTx   = CAST_AMOUNT(finFees * GET_EXCHANGE(finPos, ExtPos_PosExchRate), GET_ID(initPos, ExtPos_RefCurrId));
                                const AMOUNT_T  capRefGross = GET_AMOUNT(instrCapGLBPos, ExtPos_RefGrossAmt);
                                const double    finInitFees = totFeesInitAmt - totFeesResAmt;
                                const double    partFeesInit= CAST_AMOUNT(finInitFees * feesTx, GET_ID(initPos, ExtPos_RefCurrId));
                                const AMOUNT_T  capRefNet   = CAST_AMOUNT(partFeesInit + finFeesTx + capRefGross, GET_ID(initPos, ExtPos_RefCurrId));

                                SET_AMOUNT(instrCapGLBPos, ExtPos_RefNetAmt, capRefNet);
                            }
                        }
                    }
                    break;

                case PortPlCompRule_Mean:   /** With average exchange rate  **/
                    break;

            }
        }

		DBA_DYNFLD_STP srcExchRate = finPos == highPos && FUS_IsBuyOrSell(finPos) ? accOpenPos : accClosePos;

		/* Insure the right (old) exchange rate */
		COPY_DYNFLD(resPos, ExtPos, ExtPos_PosExchRate,   srcExchRate, ExtPos, ExtPos_PosExchRate);
		COPY_DYNFLD(resPos, ExtPos, ExtPos_SysExchRate,   srcExchRate, ExtPos, ExtPos_SysExchRate);
		COPY_DYNFLD(resPos, ExtPos, ExtPos_InstrExchRate, srcExchRate, ExtPos, ExtPos_InstrExchRate);

		SET_AMOUNT(resPos,  ExtPos_RefNetAmt,   CAST_AMOUNT((GET_AMOUNT(resPos, ExtPos_PosNetAmt)   * GET_EXCHANGE(resPos, ExtPos_PosExchRate)), GET_ID(resPos, ExtPos_RefCurrId)));
		SET_AMOUNT(resPos,  ExtPos_RefGrossAmt, CAST_AMOUNT((GET_AMOUNT(resPos, ExtPos_PosGrossAmt) * GET_EXCHANGE(resPos, ExtPos_PosExchRate)), GET_ID(resPos, ExtPos_RefCurrId)));

		COPY_DYNFLD(resPos, ExtPos, ExtPos_SysGrossAmt, resPos, ExtPos, ExtPos_RefGrossAmt);
		COPY_DYNFLD(resPos, ExtPos, ExtPos_SysNetAmt,   resPos, ExtPos, ExtPos_RefNetAmt);

		/* No fix this time, we continue to use wrong values in these columns.....
		SET_AMOUNT(resPos,  ExtPos_SysGrossAmt, (GET_AMOUNT(resPos, ExtPos_PosGrossAmt) * GET_EXCHANGE(resPos, ExtPos_SysExchRate)));
		SET_AMOUNT(resPos,  ExtPos_SysNetAmt,   (GET_AMOUNT(resPos, ExtPos_PosNetAmt)   * GET_EXCHANGE(resPos, ExtPos_SysExchRate)));
		 */

        /* Build currPL position */
		if (RET_SUCCEED != (ret = FIN_OpWithAnotherCurrencyThanPtf(ctx, currPL, mainPos, *pos2, initPos, finPos, resPos, instrResPos, instrCapGLBPos, instrExchGLBPos, freeAccOpenPos, fact)))
		{ /* Error */
			return ret;
		}
        
		if (NULL != instrCapGLBPos && 0 != CMP_AMOUNT(GET_AMOUNT(instrCapGLBPos, ExtPos_RefNetAmt), 0.0, GET_ID(instrCapGLBPos, ExtPos_RefCurrId)))
		{
			refNetAdjusted = CAST_AMOUNT( GET_AMOUNT(mainPos, ExtPos_RefNetAmt) - GET_AMOUNT((*pos2), ExtPos_RefNetAmt) + GET_AMOUNT(instrCapGLBPos, ExtPos_RefNetAmt), GET_ID(instrCapGLBPos, ExtPos_RefCurrId));
		}

		if (  false == bOpWithAnotherCurrencyThanPtfSplitPL 
           && true  == bOpWithAnotherCurrencyThanPtf
           && NULL  != instrExchGLBPos 
           && NULL  != cashExchGLBPos)          
		{
            if (RET_SUCCEED != (ret = FIN_ChangeInstrument(ctx, PosLogTypesIdx, currPL, instrExchGLBPos)))
		    { /* Error */
			    return ret;
		    }

            DBA_DYNFLD_STP instrExchGLBPos2 = FUS_DynStDup(instrExchGLBPos, ctx);

            if (NULL == instrExchGLBPos2)
            { /* Error */
                return ret;
            }

            if (RET_SUCCEED != (ret = FIN_InsertPos(ctx, instrExchGLBPos2, NO_VALUE, FALSE, FALSE, NULL)))
            { /* Error */
                FREE_DYNST(instrExchGLBPos2, ExtPos);
                return ret;
            }

            /* Compute the difference */
            if (RET_SUCCEED != (ret = FIN_BalPosFusion(ctx, instrExchGLBPos2, currPL, NO_VALUE, &instrExchResPos)))
            { /* Error */
                return ret;
            }

            /* Store the difference */
            COPY_DYNFLD(instrExchGLBPos, ExtPos, ExtPos_RefGrossAmt, instrExchResPos, ExtPos, ExtPos_RefGrossAmt);
            COPY_DYNFLD(instrExchGLBPos, ExtPos, ExtPos_RefNetAmt,   instrExchResPos, ExtPos, ExtPos_RefNetAmt);

            /* Set balance position type (gain or loss) */
            FIN_SetBalancePositionType(ctx, instrExchGLBPos);

            /* Remove temporaries positions */
            SET_ENUM(cashExchGLBPos,   ExtPos_FusStateEn, FusState_Untreated);
            SET_ENUM(currPL,           ExtPos_FusStateEn, FusState_Untreated);
            SET_ENUM(instrExchResPos,  ExtPos_FusStateEn, FusState_Untreated);
            SET_ENUM(instrExchGLBPos2, ExtPos_FusStateEn, FusState_Untreated);

            /* These positions musn't be used anymore */
            instrExchGLBPos = NULL;
            cashExchGLBPos  = NULL;
		}
	}

    /* PMSTA-6540 - 040708 - PMO */
    if (  GET_ENUM( freeAccOpenPos , ExtPos_OpenOpNatEn ) == OpNat_Sell 
       || GET_ENUM( freeAccOpenPos , ExtPos_OpenOpNatEn ) == OpNat_Buy)
    { /* Resulting cash position must be buy or sell. Useful for the return financial function */
        COPY_DYNFLD(resPos, ExtPos, ExtPos_OpenOpNatEn, freeAccOpenPos, ExtPos, ExtPos_OpenOpNatEn);
        COPY_DYNFLD(resPos, ExtPos, ExtPos_AdjustNatEn, freeAccOpenPos, ExtPos, ExtPos_AdjustNatEn);
    }

    
    /* If Margin Call, we must inverse all signs of the "freeAccOpenPos" position / PMSTA-5595 - 250608 - PMO */
    if (GET_ENUM(mainPos, ExtPos_AdjustNatEn) == OpAdjustNat_MarginCall)
    {
        DBA_InverseSign(freeAccOpenPos);
    }


    /* PMSTA-5595 - 250608 - PMO */
    DBA_DYNFLD_STP  newResPos   = NULL;
    DBA_DYNFLD_STP  saveResPos  = FUS_DynStDup(resPos, ctx);
    bool            bGeneratePositivePosition = true;

    /* Memory allocation error? */
    if (saveResPos == NULL)
    { /* Yes */
        (void)MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "ExtPos");
        return(RET_MEM_ERR_ALLOC);
    }


    /***** Resulting position must be affected to the instrument of account 2 if it exists *****/
    if (resPos != NULL && true == useAcc2Flag && (acc2ClosePos != NULL || acc2ClosePosDerived != NULL))
    {
        /* PMSTA-6540 - 040708 - PMO */
        SET_ENUM(resPos, ExtPos_PosNatEn, PosNat_AdjTransAcct);

        /* REF11075 - 050407 - PMO */
        if (NULL !=  acc2ClosePosDerived
           &&  (  GET_POSREFNAT(acc2ClosePosDerived, ExtPos_RefNatEn) == PosRefNat_FutFifo
               || GET_POSREFNAT(acc2ClosePosDerived, ExtPos_RefNatEn) == PosRefNat_FutWMP
               || GET_POSREFNAT(acc2ClosePosDerived, ExtPos_RefNatEn) == PosRefNat_FutContract      /* PMSTA-17898 - 160414 - PMO */
               )
           )
        { /* We use this derived function */
            acc2ClosePos = acc2ClosePosDerived;
            acc2CloseIdx = acc2ClosePosDerivedIdx;
        }


        /* PMSTA-10139 - 041010 - PMO */
        if (  OpAdjustNat_MarginCall == GET_ENUM(mainPos,   ExtPos_AdjustNatEn)
           && InstrNat_Future == GET_INSTRNAT(mainPos,      ExtPos_InstrNat)
           )
        {
            /* Search for an account 2 */
            DBA_DYNFLD_STP acc2Pos2 = FUS_SearchPosition(ctx, *pos2, FUS_CompareAcc2);

            if (NULL != acc2Pos2)
            {
                ret = FIN_CloseExtPos(ctx, acc2Pos2, mainPos, GET_DATETIME(mainPos, ExtPos_BegDate));

                if (ret != RET_SUCCEED)
                {
                    FREE_DYNST(saveResPos, ExtPos);
                    return ret;
                }
            }
        }

        if ( 0 != CMP_NUMBER(fact, 0.0)
            && ( (GET_POSREFNAT(mainPos, ExtPos_RefNatEn) == PosRefNat_FutFifo
               && mainPos == highPos                                                    /* PMSTA-10139 - 041010 - PMO */
                 )
                 || GET_POSREFNAT(mainPos, ExtPos_RefNatEn) == PosRefNat_FutWMP
                 || GET_POSREFNAT(mainPos, ExtPos_RefNatEn) == PosRefNat_FutContract)   /* PMSTA-17898 - 160414 - PMO */
           )
        {
            /*
             *  In future fifo mode, we need to keep open an account 2 position if
             *  the current flow remained "open" to insure the P&L to be puted into
             *  the account 2 
             *  
             *  Simple case
             *  - Buy   5
             *  - Buy   5
             *  - Sell 10
             */

            /* Duplicate the account 2 position */
            DBA_DYNFLD_STP acc2ClosePosDerived2 = FUS_DynStDup(acc2ClosePos, ctx);
    
            /* Check for memory error */
            if (NULL == acc2ClosePosDerived2)
            { /* Error */
                FREE_DYNST(saveResPos, ExtPos); /* PMSTA-5595 - 250608 - PMO */
                (void)MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);

                return RET_MEM_ERR_ALLOC;
            }

            /* Clear a lot of fields */
            FUS_ClearExtPos(acc2ClosePosDerived2);

            /* Set the cash future fifo */
            COPY_DYNFLD(acc2ClosePosDerived2, ExtPos, ExtPos_RefNatEn,   mainPos, ExtPos, ExtPos_RefNatEn);  /* PMSTA-4559 - 011107 - PMO */
            SET_ENUM(acc2ClosePosDerived2, ExtPos_PrimaryEn, PosPrimary_Derived);

            /* Set values according to the resPos */
            SET_ID(acc2ClosePosDerived2,       ExtPos_OpenOpId, saveResPosOpenOperId);
            SET_DATETIME(acc2ClosePosDerived2, ExtPos_BegDate,  saveResPosBeginDate);
            SET_CODE(acc2ClosePosDerived2,     ExtPos_OpenOpCd, saveResPosOpenOperCode);

            /* Insert new account 2 position */
            FUS_TracePos( ctx, acc2ClosePosDerived2, "acc2ClosePosDerived");   /* PMSTA-4559 - 011107 - PMO */
            if ((ret = FIN_InsertPos(ctx, acc2ClosePosDerived2, acc2CloseIdx, FALSE,FALSE, NULL)) != RET_SUCCEED)
            { /* Error */
                FREE_DYNST(saveResPos, ExtPos); /* PMSTA-5595 - 250608 - PMO */
                FREE_DYNST(acc2ClosePosDerived2, ExtPos);

                return ret;
            }
        }

        /* Set to secondary */
        SET_ENUM(resPos, ExtPos_PrimaryEn, PosPrimary_Second);         /* REF2038 - 980610 - DED */

        ret = FIN_ChangeInstrument(ctx, PosLogTypesIdx,resPos, acc2ClosePos);
        if (ret != RET_SUCCEED)
        {
            FREE_DYNST(saveResPos, ExtPos); /* PMSTA-5595 - 250608 - PMO */
            return(ret);
        }

        /* Is the resulting's position have a different instrument PMSTA-5615 - 040208 - PMO */
        if (  GET_ID(resPos, ExtPos_InstrId) != GET_ID(saveResPos, ExtPos_InstrId)
           && GET_ENUM(mainPos,  ExtPos_AdjustNatEn)  != OpAdjustNat_MarginCall
           && GET_ENUM(mainPos , ExtPos_OpenOpNatEn ) != OpNat_Sell 
           && GET_ENUM(mainPos , ExtPos_OpenOpNatEn ) != OpNat_Buy)
        { /* Yes */
            bGeneratePositivePosition = false;
        }

        /* Re-insert resulting position in correct logical type (filter fields have changed !!) */
        ret = FIN_CopyExtPos(ctx, resPos, &newResPos);
        if (ret != RET_SUCCEED)
        {
            FREE_DYNST(saveResPos, ExtPos); /* PMSTA-5595 - 250608 - PMO */
            return(ret);
        }

        /* PMSTA08607 - 061009 - PMO */
        if (true == bPLInCpt2ForMarginCall)
        {
            SET_ENUM(newResPos, ExtPos_FusStateEn, FusState_Untreated);

            /* PMSTA-10139 - 041010 - PMO */
            bool closeAcc2 = false;

            switch(ctx->applAdjCashNeutEnum)
            {
                case CashAdjNeut_Pos:
                case CashAdjNeut_None:
                    closeAcc2 = bCashPortfolio;
                    break;

                case CashAdjNeut_Full:
                case CashAdjNeut_FullInvestWithNatOp:
                default:
                    break;
            }

            if (true == closeAcc2)
            { /* Cash portfolio and Acc2 must be closed here */
                FIN_ClosePosItself(acc2ClosePos);
            }
            else
            { /* Standard processing */

                /*
                 *  Create a zero position to close the initial account 2.
                 *  This avoid to have several account 2 finals positions
                 */
                DBA_DYNFLD_STP newAcc2ClosePos2 = FUS_DynStDup(acc2ClosePos, ctx);   /* To allow the fusion of this P&L provided */
                DBA_DYNFLD_STP resAcc2ClosePos;

                if (NULL == newAcc2ClosePos2)
                { /* Error */
                    FREE_DYNST(saveResPos, ExtPos);
                    return(ret);
                }

                FUS_ClearExtPos(newAcc2ClosePos2);
                SET_ENUM(newAcc2ClosePos2, ExtPos_PrimaryEn, PosPrimary_Derived);

                if ( (ret = FIN_PosFusion(ctx, newAcc2ClosePos2, acc2ClosePos, NO_VALUE, NULL, &fact2,
                                          NULL, NULL, NULL, NULL, &resAcc2ClosePos, NULL, FALSE)) != RET_SUCCEED)
                { /* Error */
                    FREE_DYNST(newAcc2ClosePos2, ExtPos);
                    FREE_DYNST(saveResPos,       ExtPos);
                    return ret;
                }

                SET_ENUM(resAcc2ClosePos, ExtPos_RefNatEn, PosRefNat_None);

                if ((ret = FIN_InsertPos(ctx, newAcc2ClosePos2, acc2CloseIdx, FALSE,FALSE, NULL)) != RET_SUCCEED)
                {
                    FREE_DYNST(newAcc2ClosePos2, ExtPos);
                    FREE_DYNST(saveResPos,       ExtPos);
                    return ret;
                }
            }
        }

        FIN_RoundAmountsPosition(ctx, newResPos);    /* PMSTA08746 - 061009 - PMO */

        FUS_TracePos(ctx, newResPos, "newResPos");  /* PMSTA08746 - 061009 - PMO */

        /* Close only zero position REF11075 - 050407 - PMO */
        if (CMP_NUMBER(GET_AMOUNT(acc2ClosePos, ExtPos_RefNetAmt), 0.0) == 0)
        {
            /* Close account2-close position */             /* BUG504 - 970910 - DED */
            if ((ret = FIN_CloseExtPos(ctx, acc2ClosePos, finPos, GET_DATETIME(acc2ClosePos, ExtPos_BegDate))) != RET_SUCCEED)      /* REF4122 - 000406 - DED */
            {
                FREE_DYNST(saveResPos, ExtPos); /* PMSTA-5595 - 250608 - PMO */
                return(ret);
            }
        }

        /* REF4122 -000406 - DED : replaced by function */
    }
    else
    {
        /* Is the resulting's position have a different instrument PMSTA-5615 - 040208 - PMO */
        if (GET_ENUM(mainPos, ExtPos_AdjustNatEn) == OpAdjustNat_MarginCall)
        { /* Yes */
            bGeneratePositivePosition = false;
        }
    }

    bool bAddAccountPosition = true;    /* Positive and negative account position */

    if (true == bCashPortfolio)
    { /* Copy the resulting position into the cash ptf array of the current ptf PMSTA-6921 - 311008 - PMO */
        DBA_DYNFLD_STP cashPtfPosInvest    = NULL; /* Invest/Withdrawl regarding the amount of the resPos */
        DBA_DYNFLD_STP cashPtfPosWithDrawl = NULL; /* Invest/Withdrawl regarding the amount of the resPos */
        DBA_DYNFLD_STP resPosToUse         = newResPos != NULL ? newResPos : resPos;

        ret = FIN_CashPortfolioProcessing(ctx, 
										  mainPos, 
                                          resPosToUse, 
										  PosLogTypesIdx, 
										  mergeCaseFusFlag,
                                          useAcc2Flag,
										  &bAddAccountPosition, 
										  &cashPtfPosInvest,
										  &cashPtfPosWithDrawl);

        if (RET_SUCCEED == ret) 
        {
            FIN_OpPurgeOldSecondaryPosition(ctx, finPos);
            ret = FIN_CashPortfolioCleanupOldPosition(*ctx, finPos);
        }

        if (RET_SUCCEED != ret) 
        {
            FREE_DYNST(saveResPos, ExtPos);

            return ret;
        }

        switch(ctx->applAdjCashNeutEnum)
        {
            case CashAdjNeut_None:
            case CashAdjNeut_Full:
            case CashAdjNeut_FullInvestWithNatOp:
                if (true == useAcc2Flag)
                {
                    SET_ENUM(resPos, ExtPos_PrimaryEn, PosPrimary_Second); /* When there is no account 2 */

                }
                else /* DLA - PMSTA06921 - 090126 */
                {
                    SET_ENUM(resPosToUse, ExtPos_PosNatEn, PosNat_AdjTransAcct);
                }

                break;
            case CashAdjNeut_Pos: /* DLA - PMSTA06921 - 090126 */
                {
                    const bool marginCallFlag = OpAdjustNat_MarginCall == GET_OPADJUSTNAT(mainPos, ExtPos_AdjustNatEn); /* PMSTA-9072 - 050510 - PMO */
                    if ( marginCallFlag == true )
                    {
                        SET_ENUM(resPos, ExtPos_PrimaryEn, PosPrimary_Second); /* When there is no account 2 */
                    }
                }
                break;
            default:
                if (false == useAcc2Flag) /* DLA - PMSTA06921 - 090126 */
                {
                    SET_ENUM(resPosToUse, ExtPos_PosNatEn, PosNat_AdjTransAcct);
                }

                SET_ENUM(resPos, ExtPos_PrimaryEn, PosPrimary_Second); /* When there is no account 2 */
                break;
        }

        FUS_TraceCashPtfPos(ctx, resPos, newResPos, cashPtfPosInvest, cashPtfPosWithDrawl);
    }



    if (true == bAddAccountPosition) /* PMSTA-6921 - 311008 - PMO */
    {
        /* PMSTA-5595 - 250608 - PMO */
        if (true == useAcc2Flag
            || (  GET_ENUM(mainPos , ExtPos_OpenOpNatEn ) != OpNat_Sell 
               && GET_ENUM(mainPos , ExtPos_OpenOpNatEn ) != OpNat_Buy
               )
           )
        {
            /*
             *  Take care about fusion cash at value date when the system parameter is enabled
             */

            /* PMSTA-6328 - 060808 - PMO */
            if (true == fusInFutureFlg)
            {
                ctx->cashValueDateFlg = cashValueDateFlg;
            }
    
            ret = FIN_AddPositiveNegativePosition(ctx, mainPos, saveResPos, capGLBPos, bGeneratePositivePosition, useAcc2Flag, true);   /* PMSTA-9072 - 050510 - PMO */

            /* PMSTA-6328 - 060808 - PMO */
            if (true == fusInFutureFlg)
            {
                ctx->cashValueDateFlg = FALSE;
            }
        }
    }

    FREE_DYNST(saveResPos, ExtPos); /* PMSTA-5595 - 250608 - PMO */

    if (ret != RET_SUCCEED)
    {
        return ret;
    }


    /* Special treatment for Margin Calls */
    if (GET_ENUM(mainPos, ExtPos_AdjustNatEn) == OpAdjustNat_MarginCall)
    {
        /* Set all signs of "freeAccClose" positions to their original state */
        DBA_InverseSign(freeAccClosePos);
    }

    /*** Eventually generated capital G/L must be affected to the forward or adjustment instrument ***/
    /* Initialization of local variables */
    saveInstrBalPosTpId = ZERO_ID;
    saveCashBalPosTpId  = ZERO_ID;

    /* Change capital G/L */
    if (cashCapGLBPos != NULL)
    {
        /* If Margin Call, G/L must be affected to the adjustment position */
        if (GET_ENUM(mainPos, ExtPos_AdjustNatEn) == OpAdjustNat_MarginCall)
        {
            ret = FIN_ChangeInstrument(ctx, PosLogTypesIdx,cashCapGLBPos, adjPos);
        }
        else
        {
            ret = FIN_ChangeInstrument(ctx, PosLogTypesIdx,cashCapGLBPos, mainPos);
        }
        if (ret != RET_SUCCEED)
        {
            return(ret);
        }

        /* Reset 7 fields of cash G&L with initial instrument position info (eg. FwdOpen) */    /* REF3819 - 000106 - DED */
        if (CMP_NUMBER(GET_NUMBER(initPos, ExtPos_Qty), 0.0) != 0)                              /* REF3819 - 000112 - DED */
        {
            SET_AMOUNT(cashCapGLBPos, ExtPos_PosNetAmt,
                       CAST_AMOUNT(GET_AMOUNT((*pos2), ExtPos_PosNetAmt) *
                                   (GET_NUMBER(lowPos, ExtPos_Qty)/GET_NUMBER(initPos, ExtPos_Qty)),
                                   GET_ID((*pos2), ExtPos_PosCurrId)));
            SET_AMOUNT(cashCapGLBPos, ExtPos_PosGrossAmt,
                       CAST_AMOUNT(GET_AMOUNT((*pos2), ExtPos_PosGrossAmt) *
                                   (GET_NUMBER(lowPos, ExtPos_Qty)/GET_NUMBER(initPos, ExtPos_Qty)),
                                   GET_ID((*pos2), ExtPos_PosCurrId)));
        }
        else
        {
            SET_AMOUNT(cashCapGLBPos, ExtPos_PosNetAmt, 0.0);
            SET_AMOUNT(cashCapGLBPos, ExtPos_PosGrossAmt, 0.0);
        }
        COPY_DYNFLD(cashCapGLBPos, ExtPos, ExtPos_PosExchRate, *pos2, ExtPos, ExtPos_PosExchRate);
        COPY_DYNFLD(cashCapGLBPos, ExtPos, ExtPos_PosCurrId,   *pos2, ExtPos, ExtPos_PosCurrId);
        COPY_DYNFLD(cashCapGLBPos, ExtPos, ExtPos_Price,       *pos2, ExtPos, ExtPos_Price);
        COPY_DYNFLD(cashCapGLBPos, ExtPos, ExtPos_Quote,       cashCapGLBPos, ExtPos, ExtPos_Price);
        SET_ENUM(cashCapGLBPos, ExtPos_PriceCalcRuleEn, PriceCalcRule_Quote);
        SET_NUMBER(cashCapGLBPos, ExtPos_Qty, fabs(GET_NUMBER(lowPos, ExtPos_Qty)));

        /* Change balance position type Id so that we can fuse the two balance positions */
        if (instrCapGLBPos != NULL)
        {
            /* Save balance position type id for later use */
            saveInstrBalPosTpId = GET_ID(instrCapGLBPos, ExtPos_BalPosTpId);
            saveCashBalPosTpId = GET_ID(cashCapGLBPos, ExtPos_BalPosTpId);

            /* Determine if Gain or Loss */
            refGross = GET_AMOUNT(cashCapGLBPos, ExtPos_RefGrossAmt) + GET_AMOUNT(instrCapGLBPos, ExtPos_RefGrossAmt); /* REF3819 - 000107 - DED */
            refNet =  GET_AMOUNT(cashCapGLBPos, ExtPos_RefNetAmt) + GET_AMOUNT(instrCapGLBPos, ExtPos_RefNetAmt); /* REF3819 - 000107 - DED */

            /* Set balance position type (gain or loss) */    
            if (CMP_AMOUNT(refNet, 0.0, GET_ID(instrCapGLBPos, ExtPos_RefCurrId)) == 1) /* REF3819 - 000107 - DED */
            {
                /* Loss (>0) */
                FUS_SetCapCurBalPosTypeId(ctx, cashCapGLBPos, ctx->capLBalPosTypeId);
                FUS_SetCapCurBalPosTypeId(ctx, instrCapGLBPos, ctx->capLBalPosTypeId);
            }
            else if (CMP_AMOUNT(refNet, 0.0, GET_ID(instrCapGLBPos, ExtPos_RefCurrId)) == 0 && /* REF3819 - 000107 - DED */
                     CMP_AMOUNT(refGross, 0.0, GET_ID(instrCapGLBPos, ExtPos_RefCurrId)) == 1) /* REF3819 - 000107 - DED */
            {
                /* Loss (>0) */
                FUS_SetCapCurBalPosTypeId(ctx, cashCapGLBPos, ctx->capLBalPosTypeId);
                FUS_SetCapCurBalPosTypeId(ctx, instrCapGLBPos, ctx->capLBalPosTypeId);
            }
            else
            {
                /* Gain (<0) */
                FUS_SetCapCurBalPosTypeId(ctx, cashCapGLBPos, ctx->capPBalPosTypeId);
                FUS_SetCapCurBalPosTypeId(ctx, instrCapGLBPos, ctx->capPBalPosTypeId);
            }
        }

        /* Re-insert capital G/L in correct logical type (filter fields have changed !!) */
        ret = FIN_CopyExtPos(ctx, cashCapGLBPos, &newCashCapGLBPos);    /* PMSTA-6921 - 311008 - PMO / PMSTA08746 - 061009 - PMO */
        if (ret != RET_SUCCEED)                                         /* PMSTA08746 - 061009 - PMO */
        {
            return ret;                                                 /* PMSTA08746 - 061009 - PMO */
        }

        /* If possible, fuse capital G/L of instrument and cash positions */
        if (instrCapGLBPos != NULL &&                                      /* REF2386 - 980618 - DED */
             FIN_PosFusionnable(ctx, PosLogTypesIdx, instrCapGLBPos, newCashCapGLBPos, BAL_POS, PtfFusRule_WMP) == Fin_Pos_FusOk)      /* DVP549 - 970805 - DED *//*REF10256-EFE-041116*/
        {
            if ((ret = FIN_BalPosFusion(ctx, instrCapGLBPos, newCashCapGLBPos, NO_VALUE, &resGLBPos)) != RET_SUCCEED)
            {
                return ret;
            }

            /* Reset 5 fields with initial position info */     /* REF3819 - 000106 - DED */
            COPY_DYNFLD(resGLBPos, ExtPos, ExtPos_PosNetAmt,   instrCapGLBPos, ExtPos, ExtPos_PosNetAmt);
            COPY_DYNFLD(resGLBPos, ExtPos, ExtPos_PosGrossAmt, instrCapGLBPos, ExtPos, ExtPos_PosGrossAmt);
            COPY_DYNFLD(resGLBPos, ExtPos, ExtPos_PosExchRate, instrCapGLBPos, ExtPos, ExtPos_PosExchRate);
            COPY_DYNFLD(resGLBPos, ExtPos, ExtPos_PosCurrId,   instrCapGLBPos, ExtPos, ExtPos_PosCurrId);
            COPY_DYNFLD(resGLBPos, ExtPos, ExtPos_Price,       instrCapGLBPos, ExtPos, ExtPos_Price);
            COPY_DYNFLD(resGLBPos, ExtPos, ExtPos_Quote,       resGLBPos, ExtPos, ExtPos_Price);
            SET_ENUM(resGLBPos, ExtPos_PriceCalcRuleEn, PriceCalcRule_Quote);
            SET_NUMBER(resGLBPos, ExtPos_Qty, fabs(GET_NUMBER(lowPos, ExtPos_Qty)));

            /* If fusion succeeded, we have to delete the two capital G/L, because we only want
               to keep the resulting capital G/L */
            SET_ENUM(instrCapGLBPos, ExtPos_FusStateEn, FusState_Untreated);
            SET_ENUM(newCashCapGLBPos, ExtPos_FusStateEn, FusState_Untreated);
        }

        /* Put original value of balance position type again in position */
        if (saveCashBalPosTpId != (ID_T)0 && newCashCapGLBPos != NULL)     /* REF4257 - 000110 - DED */
        {
            SET_ID(newCashCapGLBPos, ExtPos_BalPosTpId, saveCashBalPosTpId);
        }
        if (saveInstrBalPosTpId != (ID_T)0 && instrCapGLBPos != NULL)      /* REF4257 - 000110 - DED */
        {
            SET_ID(instrCapGLBPos, ExtPos_BalPosTpId, saveInstrBalPosTpId);
        }

        /* Change primary_e to Secondary for resulting balance position */
        if (resGLBPos != NULL)
        {
            SET_ENUM(resGLBPos, ExtPos_PrimaryEn, PosPrimary_Second);
        }
    }

    /*** Eventually generated exchange G/L must be affected to the forward or adjustment instrument ***/
    /* Initialization of local variables */     /* REF4257 - 000110 - DED */
    saveInstrBalPosTpId = ZERO_ID;
    saveCashBalPosTpId  = ZERO_ID;
    AMOUNT_T    computedRefNetCashExchGLBPos = ZERO_AMOUNT;

    /* Change exchange G/L */
    if (cashExchGLBPos != NULL)
    {
        /* PMSTA-15298 - 040213 - PMO */
        switch (ctx->portPLCompRule)
        {
            case PortPlCompRule_Final:  /** With final exchange rate    **/
            case PortPlCompRule_Init:   /** With initial exchange rate  **/
                computedRefNetCashExchGLBPos = GET_AMOUNT(cashExchGLBPos, ExtPos_RefNetAmt);            
                break;

            case PortPlCompRule_Mean:   /** With average exchange rate  **/
                if (NULL != currPL)
                {
                    computedRefNetCashExchGLBPos = GET_AMOUNT(currPL, ExtPos_RefNetAmt);
                }
                else
                {
                    computedRefNetCashExchGLBPos = GET_AMOUNT(cashExchGLBPos, ExtPos_RefNetAmt);            
                }
                break;
        } /* End switch */

        /* PMSTA08746 - 061009 - PMO */
        if (true == bOpWithAnotherCurrencyThanPtfSplitPL)
        {
            SET_AMOUNT(cashExchGLBPos, ExtPos_RefNetAmt, refNetAdjusted);
        }

        /* If Margin Call, G/L must be affected to the adjustment position */
        if (GET_ENUM(mainPos, ExtPos_AdjustNatEn) == OpAdjustNat_MarginCall)
        {
            ret = FIN_ChangeInstrument(ctx, PosLogTypesIdx,cashExchGLBPos, adjPos);
        }
        else
        {
            ret = FIN_ChangeInstrument(ctx, PosLogTypesIdx,cashExchGLBPos, mainPos);
        }
        if (ret != RET_SUCCEED)
        {
            return ret;
        }

        /* Reset 7 fields of cash G&L with initial instrument position info (eg. FwdOpen) */    /* REF3819 - 000106 - DED */
        if (CMP_NUMBER(GET_NUMBER(initPos, ExtPos_Qty), 0.0) != 0)                              /* REF3819 - 000112 - DED */
        {
            SET_AMOUNT(cashExchGLBPos, ExtPos_PosNetAmt,
                       CAST_AMOUNT(GET_AMOUNT((*pos2), ExtPos_PosNetAmt) *
                                   (GET_NUMBER(lowPos, ExtPos_Qty)/GET_NUMBER(initPos, ExtPos_Qty)),
                                   GET_ID((*pos2), ExtPos_PosCurrId)));
            SET_AMOUNT(cashExchGLBPos, ExtPos_PosGrossAmt,
                       CAST_AMOUNT(GET_AMOUNT((*pos2), ExtPos_PosGrossAmt) *
                                   (GET_NUMBER(lowPos, ExtPos_Qty)/GET_NUMBER(initPos, ExtPos_Qty)),
                                   GET_ID((*pos2), ExtPos_PosCurrId)));
        }
        else
        {
            SET_AMOUNT(cashExchGLBPos, ExtPos_PosNetAmt, 0.0);
            SET_AMOUNT(cashExchGLBPos, ExtPos_PosGrossAmt, 0.0);
        }
        COPY_DYNFLD(cashExchGLBPos, ExtPos, ExtPos_PosExchRate, *pos2, ExtPos, ExtPos_PosExchRate);
        COPY_DYNFLD(cashExchGLBPos, ExtPos, ExtPos_PosCurrId,   *pos2, ExtPos, ExtPos_PosCurrId);
        COPY_DYNFLD(cashExchGLBPos, ExtPos, ExtPos_Price,       *pos2, ExtPos, ExtPos_Price);
        COPY_DYNFLD(cashExchGLBPos, ExtPos, ExtPos_Quote,       cashExchGLBPos, ExtPos, ExtPos_Price);
        SET_ENUM(cashExchGLBPos, ExtPos_PriceCalcRuleEn, PriceCalcRule_Quote);
        SET_NUMBER(cashExchGLBPos, ExtPos_Qty, fabs(GET_NUMBER(lowPos, ExtPos_Qty)));

        /* Change balance position type Id so that we can fuse the two balance positions */
        if (instrExchGLBPos != NULL)
        {
            /* Save balance position type id for later use */
            saveInstrBalPosTpId = GET_ID(instrExchGLBPos, ExtPos_BalPosTpId);
            saveCashBalPosTpId = GET_ID(cashExchGLBPos, ExtPos_BalPosTpId);

            /* Determine if Gain or Loss */
            refGross = GET_AMOUNT(cashExchGLBPos, ExtPos_RefGrossAmt) + GET_AMOUNT(instrExchGLBPos, ExtPos_RefGrossAmt); /* REF3819 - 000107 - DED */
            refNet =  GET_AMOUNT(cashExchGLBPos, ExtPos_RefNetAmt) + GET_AMOUNT(instrExchGLBPos, ExtPos_RefNetAmt); /* REF3819 - 000107 - DED */

            /* Set balance position type (gain or loss) */   
            if (CMP_AMOUNT(refNet, 0.0, GET_ID(instrExchGLBPos, ExtPos_RefCurrId)) == 1) /* REF3819 - 000107 - DED */
            {
                /* Loss (>0) */
               FUS_SetCapCurBalPosTypeId(ctx, cashExchGLBPos, ctx->curLBalPosTypeId);
               FUS_SetCapCurBalPosTypeId(ctx, instrExchGLBPos, ctx->curLBalPosTypeId);
            }
            else if (CMP_AMOUNT(refNet, 0.0, GET_ID(instrExchGLBPos, ExtPos_RefCurrId)) == 0 && /* REF3819 - 000107 - DED */
                     CMP_AMOUNT(refGross, 0.0, GET_ID(instrExchGLBPos, ExtPos_RefCurrId)) == 1) /* REF3819 - 000107 - DED */
            {
                /* Loss (>0) */
                FUS_SetCapCurBalPosTypeId(ctx, cashExchGLBPos, ctx->curLBalPosTypeId);
                FUS_SetCapCurBalPosTypeId(ctx, instrExchGLBPos, ctx->curLBalPosTypeId);
            }
            else
            {
                /* Gain (<0) */
                FUS_SetCapCurBalPosTypeId(ctx, cashExchGLBPos, ctx->curPBalPosTypeId);
                FUS_SetCapCurBalPosTypeId(ctx, instrExchGLBPos, ctx->curPBalPosTypeId);
            }
        }

        /* PMSTA08746 - 061009 - PMO */
        if (false == bOpWithAnotherCurrencyThanPtfSplitPL)
        {
            /* Re-insert exchange G/L in correct logical type (filter fields have changed !!) */
            ret = FIN_CopyExtPos(ctx, cashExchGLBPos, &newCashExchGLBPos);  /* PMSTA-6921 - 311008 - PMO / PMSTA08746 - 061009 - PMO */
            if (ret != RET_SUCCEED)                                         /* PMSTA08746 - 061009 - PMO */
            {
                return ret;                                                 /* PMSTA08746 - 061009 - PMO */
            }

            /* If possible, fuse exchange G/L of instrument and cash positions */
            if (instrExchGLBPos != NULL &&                                                                  /* REF2386 - 980618 - DED */
                FIN_PosFusionnable(ctx, PosLogTypesIdx, instrExchGLBPos, newCashExchGLBPos, BAL_POS, PtfFusRule_WMP) == Fin_Pos_FusOk)    /* DVP549 - 970805 - DED *//*REF10256-EFE-041116*/
            {               
                if ((ret = FIN_BalPosFusion(ctx, instrExchGLBPos, newCashExchGLBPos, NO_VALUE, &resGLBPos)) != RET_SUCCEED)
                {
                    return ret;
                }

                /* Reset 5 fields with initial position info */     /* REF3819 - 000106 - DED */
                COPY_DYNFLD(resGLBPos, ExtPos, ExtPos_PosNetAmt,   instrExchGLBPos, ExtPos, ExtPos_PosNetAmt);
                COPY_DYNFLD(resGLBPos, ExtPos, ExtPos_PosGrossAmt, instrExchGLBPos, ExtPos, ExtPos_PosGrossAmt);
                COPY_DYNFLD(resGLBPos, ExtPos, ExtPos_PosExchRate, instrExchGLBPos, ExtPos, ExtPos_PosExchRate);
                COPY_DYNFLD(resGLBPos, ExtPos, ExtPos_PosCurrId,   instrExchGLBPos, ExtPos, ExtPos_PosCurrId);
                COPY_DYNFLD(resGLBPos, ExtPos, ExtPos_Price,       instrExchGLBPos, ExtPos, ExtPos_Price);
                COPY_DYNFLD(resGLBPos, ExtPos, ExtPos_Quote,       resGLBPos, ExtPos, ExtPos_Price);
                SET_ENUM(resGLBPos, ExtPos_PriceCalcRuleEn, PriceCalcRule_Quote);
                SET_NUMBER(resGLBPos, ExtPos_Qty, fabs(GET_NUMBER(lowPos, ExtPos_Qty)));

                /* If fusion succeeded, we have to delete the two exchange G/L, because we only want
                   to keep the resulting exchange G/L */
                SET_ENUM(instrExchGLBPos,   ExtPos_FusStateEn, FusState_Untreated);
                SET_ENUM(newCashExchGLBPos, ExtPos_FusStateEn, FusState_Untreated);
            }
        }
        else
        {
            SET_ENUM(cashExchGLBPos, ExtPos_FusStateEn, FusState_Untreated);
        }

        /* Put original value of balance position type again in position */
        if (saveCashBalPosTpId != (ID_T)0 && newCashExchGLBPos != NULL)        /* REF4257 - 000110 - DED */
        {
            SET_ID(newCashExchGLBPos, ExtPos_BalPosTpId, saveCashBalPosTpId);
        }
        if (saveInstrBalPosTpId != (ID_T)0 && instrExchGLBPos != NULL)     /* REF4257 - 000110 - DED */
        {
            SET_ID(instrExchGLBPos, ExtPos_BalPosTpId, saveInstrBalPosTpId);
        }

        /* Change primary_e to Secondary for resulting balance position */
        if (resGLBPos != NULL)
        {
            SET_ENUM(resGLBPos, ExtPos_PrimaryEn, PosPrimary_Second);
        }
    }

    /* PMSTA-9072 - 050510 - PMO */
    if (true == bOpWithAnotherCurrencyThanPtf)
    {
        FIN_FixTxPositionRoundingProblems(ctx, mainPos, newMainPos, *pos2, newAccOpenPos, freeAccClosePos, highPos, finPos, initPos, instrResPos, resPos, instrCapGLBPos, instrExchResPos, instrExchGLBPos, computedRefNetCashExchGLBPos, fact);
    }
    else
    {
        FIN_FixPositionRoundingProblems(newMainPos, *pos2, newAccOpenPos, highPos, finPos, instrResPos, resPos, instrCapGLBPos, fact);
    }

    return RET_SUCCEED;
}




/*******************************************************************************
**
**  Function    :   FIN_AddAccClosePos
**
**  Description :   Copy of the main cash position and insert it in the fusion context
**
**  Arguments   : 
**                 
**  Return      :   RET_SUCCEED           if ok
**                  RET_GEN_ERR_INVARG        error in arguments
**                  RET_FIN_ERR_POSITIONS     no "open" position found
**                  RET_FIN_ERR_NOACCTPOS     no open/close account positions found 
**                  RET_FIN_ERR_NOADJPOS      no adjustment position for Margin Calls
**                  RET_MEM_ERR_ALLOC     error in memory allocations
**
**  Last modif. :   PMSTA-4559 - 011107 - PMO : Futures Management (margin calls)
**                  PMSTA08746 - 061009 - PMO : Performance on futures in foreign currency
**                  PMSTA-17898 - 160414 - PMO : New Fusion Criteria to manage the contract dates for margin calls after partial closing
**
*******************************************************************************/
STATIC RET_CODE FIN_AddAccClosePos(FIN_FUS_CONTEXT_STP  ctx, 
                                   DBA_DYNFLD_STP *     pNewAccClosePos,
                                   const int            accCloseIdx, 
                                   const DBA_DYNFLD_STP accClosePos, 
                                   const DBA_DYNFLD_STP mainPos, 
                                   const DBA_DYNFLD_STP pos2)
{
    DBA_DYNFLD_STP  newAccClosePos = NULL;
    RET_CODE        ret;

    /* Copy of main cash position */
    if ((newAccClosePos = FUS_DynStDup(accClosePos, ctx)) != NULL)    /* PMSTA08746 - 061009 - PMO */
    {
        /* Set copy of Account Pos to "open", Main, not primary and no Margin Call */
        SET_NULL_ID(newAccClosePos, ExtPos_Id);
        SET_NULL_ID(newAccClosePos, ExtPos_PosObjId);

        if (PosRefNat_FutContract != GET_POSREFNAT(mainPos, ExtPos_RefNatEn))   /* PMSTA-17898 - 160414 - PMO */
        {
            SET_NULL_CODE(newAccClosePos, ExtPos_RefOpCd);
        }

        SET_NULL_ID(newAccClosePos, ExtPos_CloseOpId);
        SET_NULL_CODE(newAccClosePos, ExtPos_CloseOpCd);
        SET_NULL_DATETIME(newAccClosePos, ExtPos_EndDate);
        SET_ENUM(newAccClosePos, ExtPos_AdjustNatEn, OpAdjustNat_None);
        SET_ENUM(newAccClosePos, ExtPos_PrimaryEn, PosPrimary_Derived);
        SET_NULL_CODE(newAccClosePos, ExtPos_RevOpCd);				/* REF5614 - 010209 - DED */
        SET_ENUM(newAccClosePos, ExtPos_RevNatEn, PosRevNat_None);	/* REF5614 - 010209 - DED */

        /* PMSTA-4559 - 011107 - PMO */
        if (GET_POSREFNAT(mainPos, ExtPos_RefNatEn) == PosRefNat_FutWMP)
        {
            SET_ENUM(newAccClosePos, ExtPos_RefNatEn, PosRefNat_FutWMP);
        }
        else
        {
            COPY_DYNFLD(newAccClosePos, ExtPos, ExtPos_RefNatEn, pos2, ExtPos, ExtPos_RefNatEn);
        }

        /* REF4452 sme */
        if ((GET_ENUM(mainPos, ExtPos_AdjustNatEn) == OpAdjustNat_MarginCall) &&
            (ctx->margInheritPosDate == MargInheritPosDate_Copy))
        {        
            COPY_DYNFLD(newAccClosePos, ExtPos, ExtPos_AcctDate, pos2, ExtPos, ExtPos_AcctDate);
            COPY_DYNFLD(newAccClosePos, ExtPos, ExtPos_OpDate,   pos2, ExtPos, ExtPos_OpDate);
            COPY_DYNFLD(newAccClosePos, ExtPos, ExtPos_ValDate,  pos2, ExtPos, ExtPos_ValDate);
        }

        /* Insert new main position */
        FUS_TracePos( ctx, newAccClosePos, "newAccClosePos");   /* PMSTA-4559 - 011107 - PMO */
        if ((ret = FIN_InsertPos(ctx, newAccClosePos, accCloseIdx, FALSE, FALSE, NULL)) != RET_SUCCEED)
        {
            FREE_DYNST(newAccClosePos, ExtPos);
        }
    }
    else
    {
       (void)MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "ExtPos");
        ret = RET_MEM_ERR_ALLOC;
    }

    *pNewAccClosePos = newAccClosePos;  /* PMSTA08607 - 280909 - PMO */

    return ret;
}



/*******************************************************************************
**
**  Function    :   FIN_GetKindOfFusion
**
**  Description :
**
**  Arguments   : pos1      First position
**                pos2      Second position
**                resPos    Resulting position
**
**  Return      : Sees FUS_KINDOFFUSION_ENUM
**
**  Last modif. :   PMSTA-9072 - 050510 - PMO : Future instrument with Fees&Taxes at opening position: exchange rate at opening position are not saved after adjustment operation
*******************************************************************************/
FUS_KINDOFFUSION_ENUM FIN_GetKindOfFusion(const DBA_DYNFLD_STP pos1
                                         ,const DBA_DYNFLD_STP pos2
                                         ,const DBA_DYNFLD_STP resPos
                                         )
{
    FUS_KINDOFFUSION_ENUM ret = FusionUnknown;

    if (  OpAdjustNat_MarginCall == GET_OPADJUSTNAT(pos1, ExtPos_AdjustNatEn)
       || OpAdjustNat_MarginCall == GET_OPADJUSTNAT(pos2, ExtPos_AdjustNatEn)
       )
    {
        ret = FusionMarginCall;
    }
    else
    {
        DBA_DYNFLD_STP      initPos;
        DBA_DYNFLD_STP      finPos;

        FIN_DefineInitAndFinPos(&finPos, &initPos, pos1, pos2);

        double initAbsQtt = fabs(GET_NUMBER(initPos, ExtPos_Qty));
        double finAbsQtt  = fabs(GET_NUMBER(finPos,  ExtPos_Qty));
        double resAbsQtt  = fabs(GET_NUMBER(resPos,  ExtPos_Qty));

        if( initAbsQtt > 0. && initAbsQtt > resAbsQtt)
        {
            if( resAbsQtt > 0. )
            {
                if(PosPrimary_Derived == GET_POSPRIMARY(finPos, ExtPos_PrimaryEn))
                {
                    ret = FusionSwitchLongShortNext;
                }
                else
                {
                    ret = FusionReduce;
                }
            }
            else
            {
                ret = FusionClose;
            }
        }
        else
        {
            if (0 == CMP_NUMBER(initAbsQtt + finAbsQtt, resAbsQtt))
            {
                ret = FusionMergeBuySell;
            }
            else
            {
                if (finAbsQtt > initAbsQtt && resAbsQtt > 0.)
                {
                    ret = FusionSwitchLongShortFirst;
                }
            }
        }
    }

    return ret;
}


/*******************************************************************************
**
**  Function    : FIN_FeesInOpWithAnotherCurrencyThanPtf
**
**  Description :
**
**  Arguments   :
**
**  Return      :   RET_SUCCEED                 if ok
**                  RET_GEN_ERR_INVARG          error in arguments
**                  RET_FIN_ERR_POSITIONS       no "open" position found
**                  RET_FIN_ERR_NOACCTPOS       no open/close account positions found
**                  RET_FIN_ERR_NOADJPOS        no adjustment position for Margin Calls
**                  RET_MEM_ERR_ALLOC           error in memory allocations
**
**  Last modif. :   PMSTA-9072 - 050510 - PMO : Future instrument with Fees&Taxes at opening position: exchange rate at opening position are not saved after adjustment operation
**                  PMSTA-10139 - 041010 - PMO : The amount of the cash position in the portfolio is not correct as a result of margin call.
**                  PMSTA-13124 - 021111 - PMO : Fusion error with buy/sell of future, operations in another currency and with fees
**                  PMSTA-16824 - 220813 - PMO : Performance issue on fusion process when handling futures
**                  PMSTA-16991 - 260913 - PMO : The fusion of futures operations in another currency than the portfolio might finish in error
**
*******************************************************************************/
STATIC RET_CODE FIN_FeesInOpWithAnotherCurrencyThanPtf( FIN_FUS_CONTEXT_STP     ctx
                                                      , DBA_DYNFLD_STP &        mainPos
                                                      , DBA_DYNFLD_STP &        newMainPos
                                                      , DBA_DYNFLD_STP *        pos2
                                                      , DBA_DYNFLD_STP &        resPos
                                                      , const bool              bOpWithAnotherCurrencyThanPtf)
{
    RET_CODE ret = RET_SUCCEED;

    if (true == bOpWithAnotherCurrencyThanPtf)
    {
        /*
         * Handling of the fees exchange rate position
         */
        DBA_DYNFLD_STP      pos2FeesRate    = NULL;
        DBA_DYNFLD_STP      mainFeesRate    = NULL;
        DBA_DYNFLD_STP      currPos         = NULL;
        FIN_LOG_TYPE_STP    pPosLogTypes;
        int                 posNb;

        /***** Search the position *****/
        for (int i = 0 ; i < ctx->posLogTypesNb ; i++)                                      /* PMSTA-16824 - 220813 - PMO */
        {
            pPosLogTypes = &ctx->posLogTypesTab[i];
            posNb        = pPosLogTypes->posNb;

            if (posNb > 0 )
            {
                for (int j = 0; j < posNb; j++)
                {
                    currPos = pPosLogTypes->posTab[j];

                    if (PosNat_FeesRatePos == GET_POSNAT(currPos,      ExtPos_PosNatEn)
                       && FusState_Opened  == GET_POSFUSSTATE(currPos, ExtPos_FusStateEn)
                       && 0 == FIN_CommonLogIdCmp(currPos, mainPos)                         /* PMSTA-10139 - 041010 - PMO */
                       )
                    {
                        if (0 == CMP_ID(GET_ID(currPos, ExtPos_OpenOpId), GET_ID(mainPos, ExtPos_OpenOpId)))
                        {
                            mainFeesRate = currPos;

                            if (NULL != pos2FeesRate)
                            { /* Stop the search */
                                break;
                            }
                        }

                        if (0 == CMP_ID(GET_ID(currPos, ExtPos_OpenOpId), GET_ID(*pos2, ExtPos_OpenOpId)))
                        {
                           pos2FeesRate = currPos;

                            if (NULL != mainFeesRate)
                            { /* Stop the search */
                                break;
                            }
                        }
                    }
                }
            }

            /* PMSTA-16824 - 220813 - PMO */
            if (NULL != pos2FeesRate && NULL != mainFeesRate)
            { /* Stop the search */
                break;
            }
        }

        const FUS_KINDOFFUSION_ENUM kindOfFusion    = FIN_GetKindOfFusion(mainPos, *pos2, resPos);
        DBA_DYNFLD_STP              newPos2FeesRate = NULL;
        DBA_DYNFLD_STP              srcOpenPos      = NULL;
        DBA_DYNFLD_STP              srcClosePos     = NULL;

        /* A margin call without fees */
        if (kindOfFusion == FusionMarginCall && NULL == mainFeesRate && NULL != pos2FeesRate)
        {
            srcOpenPos  = newMainPos;
            srcClosePos = mainPos;
        }
        else
        {
            switch (kindOfFusion)
            {
                case FusionClose:
                    srcClosePos = mainPos;
                    break;

                case FusionReduce:
                    srcOpenPos  = resPos;       /* PMSTA-10139 - 041010 - PMO */
                    srcClosePos = mainPos;
                    break;

                case FusionSwitchLongShortFirst:
                case FusionSwitchLongShortNext:
                    srcOpenPos  = mainPos;
                    srcClosePos = mainPos;
                    break;

                case FusionMergeBuySell:
                    if (NULL != mainFeesRate && NULL != pos2FeesRate)
                    {
                        double          fact = 0.;
                        DBA_DYNFLD_STP  feesResPos;

                        ret = FIN_PosFusion(ctx,
                                            mainFeesRate,
                                            pos2FeesRate,
                                            NO_VALUE,
                                            NULL,
                                            &fact,
                                            NULL,
                                            NULL,
                                            NULL,
                                            NULL,
                                            &feesResPos,
                                            NULL,
                                            FALSE);

                        if (ret == RET_SUCCEED)
                        {
                            FIN_CopyOpenOpCdIdTimingRule(feesResPos,resPos);
                            COPY_DYNFLD(feesResPos, ExtPos, ExtPos_SortCd,   resPos, ExtPos, ExtPos_SortCd);
                            SET_ENUM(feesResPos, ExtPos_PosNatEn , PosNat_FeesRatePos);
                            newPos2FeesRate = feesResPos;   /* PMSTA-10139 - 041010 - PMO */
                        }
                    }
                    break;

                default:
                    break;
            }
        }

        if (ret == RET_SUCCEED)
        {
            if (NULL != srcOpenPos && NULL != srcClosePos)
            {
                bool bFees; /* Flag if we have any fees */

                switch (kindOfFusion)
                {
                    case FusionSwitchLongShortFirst:
                    case FusionSwitchLongShortNext:
                        bFees           = NULL != mainFeesRate;
                        newPos2FeesRate = FUS_DynStDup(mainFeesRate, ctx);

                        if (NULL != newPos2FeesRate)
                        { /* Ok */
                            ret = FIN_CloseExtPos(ctx, mainFeesRate, srcClosePos, GET_DATETIME(srcClosePos, ExtPos_EndDate));
                        }
                        else
                        {
                            ret = NULL == mainFeesRate ? RET_SUCCEED : RET_MEM_ERR_ALLOC;
                        }
                        break;

                    case FusionReduce:  /* PMSTA-10139 - 041010 - PMO */
                        bFees = NULL != pos2FeesRate;
                        newPos2FeesRate = FUS_DynStDup(pos2FeesRate, ctx);

                        if (NULL != newPos2FeesRate)
                        { /* Ok */
                            ret = FIN_CloseExtPos(ctx, pos2FeesRate, srcClosePos, GET_DATETIME(srcClosePos, ExtPos_EndDate));   /* PMSTA-13124 - 021111 - PMO */

                            /* PMSTA-16824 - 220813 - PMO */
                            if (RET_SUCCEED == ret && NULL != mainFeesRate)                                                     /* PMSTA-16991 - 260913 - PMO */
                            {
                               ret = FIN_CloseExtPos(ctx, mainFeesRate, srcClosePos, GET_DATETIME(srcClosePos, ExtPos_EndDate));
                            }
                        }
                        break;

                    default:
                        bFees = NULL != pos2FeesRate;
                        newPos2FeesRate = FUS_DynStDup(pos2FeesRate, ctx);
                        break;
                }

                if (RET_SUCCEED == ret && true == bFees)
                {
                    if (NULL != newPos2FeesRate)
                    { /* Ok */
                        if (NULL != pos2FeesRate)
                        {
                            ret = FIN_CloseExtPos(ctx, pos2FeesRate, srcClosePos, GET_DATETIME(srcClosePos, ExtPos_EndDate));
                        }

                        if (RET_SUCCEED == ret)
                        {
                            FIN_CopyOpenOpCdIdTimingRule(newPos2FeesRate,srcOpenPos);
                            COPY_DYNFLD(newPos2FeesRate, ExtPos, ExtPos_BegDate , srcOpenPos, ExtPos, ExtPos_BegDate);
                            COPY_DYNFLD(newPos2FeesRate, ExtPos, ExtPos_SortCd,   srcOpenPos, ExtPos, ExtPos_SortCd);
                            SET_ENUM(newPos2FeesRate, ExtPos_PrimaryEn, PosPrimary_Derived);
                            SET_NULL_DATETIME(newPos2FeesRate, ExtPos_EndDate);

                            ret = FIN_InsertPos(ctx, newPos2FeesRate, NO_VALUE, FALSE, FALSE, NULL);
                        }

                        if (RET_SUCCEED != ret)
                        {
                            FREE_DYNST(newPos2FeesRate, ExtPos);
                        }
                    }
                    else
                    { /* Error */
                        ret = RET_MEM_ERR_ALLOC;
                       (void)MSG_SendMesg(ret, 2, FILEINFO, "ExtPos");
                    }
                }
            }
            else
            {
                if (NULL != srcClosePos && NULL != pos2FeesRate)
                {
                    ret = FIN_CloseExtPos(ctx, pos2FeesRate, srcClosePos, GET_DATETIME(srcClosePos, ExtPos_EndDate));
                }
            }
        }

        FUS_TracePosFeesRate(ctx, mainFeesRate, pos2FeesRate, newPos2FeesRate);
    }

    return ret;
}


/*******************************************************************************
**
**  Function    :   FIN_ProcessingMarginCall
**
**  Description :   Special treatment for margin call operations
**
**  Arguments   :   .... lot of variables inherited from the caller
**                     function FIN_ReferencePos
**
**
**  Return      :   RET_SUCCEED           if ok
**                  RET_GEN_ERR_INVARG        error in arguments
**                  RET_FIN_ERR_POSITIONS     no "open" position found
**                  RET_FIN_ERR_NOACCTPOS     no open/close account positions found
**                  RET_FIN_ERR_NOADJPOS      no adjustment position for Margin Calls
**                  RET_MEM_ERR_ALLOC     error in memory allocations
**
**  Last modif. :   DVP464 - 970521 - DED
**                  PMSTA08746 - 061009 - PMO : Performance on futures in foreign currency
**                  PMSTA08607 - 280909 - PMO : Wrong treatment of future positions when booking margin amount
**                  PMSTA-17898 - 160414 - PMO : New Fusion Criteria to manage the contract dates for margin calls after partial closing
**
*******************************************************************************/
STATIC RET_CODE FIN_ProcessingMarginCall(   FIN_FUS_CONTEXT_STP     ctx,
                                            const int               PosLogTypesIdx,
                                            DBA_DYNFLD_STP &        mainPos,
                                            DBA_DYNFLD_STP &        newMainPos,
                                            const DBA_DYNFLD_STP    finPos,
                                            DBA_DYNFLD_STP &        adjPos,
                                            const int               adjPosIdx,
                                            DBA_DYNFLD_STP *        pos2,
                                            DBA_DYNFLD_STP &        instrCapGLBPos,
                                            DBA_DYNFLD_STP &        instrExchGLBPos,
                                            DBA_DYNFLD_STP &        resPos,
                                            const bool              MC_NoSplit,
                                            const int               accCloseIdx,
                                            const DBA_DYNFLD_STP    accClosePos,
                                            const bool              bOpWithAnotherCurrencyThanPtf,
                                            EXTRACTED_BP &          extractedBp,
                                            DBA_DYNFLD_STP *        pNewAccClosePos)    /* PMSTA08607 - 280909 - PMO */
{
    RET_CODE ret = RET_SUCCEED;

    if (GET_ENUM(mainPos, ExtPos_AdjustNatEn) == OpAdjustNat_MarginCall)
    {
        /* Delete resulting position if resulting quantity = 0 */
        if (CMP_NUMBER(GET_NUMBER(resPos, ExtPos_Qty), 0.0) == 0)
        {
            SET_ENUM(resPos, ExtPos_FusStateEn, FusState_Untreated);
        }

        /********************************* Main Position ****************************************/

        /* Set all signs of closing positions to their original state */
        DBA_InverseSign(mainPos);

        /* Copy main instrument position */
        SET_NULL_ID(newMainPos, ExtPos_Id);
        SET_NULL_ID(newMainPos, ExtPos_PosObjId);

        if (PosRefNat_FutContract != GET_POSREFNAT(newMainPos, ExtPos_RefNatEn))    /* PMSTA-17898 - 160414 - PMO */
        {
            SET_NULL_CODE(newMainPos, ExtPos_RefOpCd);
        }

        SET_NULL_ID(newMainPos, ExtPos_CloseOpId);
        SET_NULL_CODE(newMainPos, ExtPos_CloseOpCd);
        SET_NULL_DATETIME(newMainPos, ExtPos_EndDate);
        SET_ENUM(newMainPos, ExtPos_AdjustNatEn, OpAdjustNat_None);
        SET_ENUM(newMainPos, ExtPos_PrimaryEn, PosPrimary_Derived);
        SET_NULL_CODE(newMainPos, ExtPos_RevOpCd);				/* REF5614 - 010209 - DED */
        SET_ENUM(newMainPos, ExtPos_RevNatEn, PosRevNat_None);	/* REF5614 - 010209 - DED */

        /* PMSTA-5215 - 160408 - PMO */
        FUS_PositionInjectBP (ctx, newMainPos, PosLogTypesIdx, &extractedBp, false, false, true, false);    /* PMSTA-9072 - 050510 - PMO / Add all bp to the resulting's margin call position */
        FUS_PositionInjectBP (ctx, *pos2,      PosLogTypesIdx, &extractedBp, true,  false, true, false);    /* PMSTA-9072 - 050510 - PMO / Restore initial state */

        COPY_DYNFLD(newMainPos, ExtPos, ExtPos_HistQuote, *pos2, ExtPos, ExtPos_HistQuote);                 /* PMSTA-4559 - 011107 - PMO */
        COPY_DYNFLD(newMainPos, ExtPos, ExtPos_SortCd,  resPos, ExtPos, ExtPos_SortCd);                     /* PMSTA-8062 - 190509 - PMO */

        /* PMSTA-5207 - 050208 - PMO */
        if ((    OpNat_Buy    == GET_OPNAT(*pos2, ExtPos_OpenOpNatEn)
             ||  OpNat_Sell   == GET_OPNAT(*pos2, ExtPos_OpenOpNatEn)
             || (OpNat_Adjust == GET_OPNAT(*pos2, ExtPos_OpenOpNatEn)
                && PosPrimary_Derived == GET_POSPRIMARY(*pos2, ExtPos_PrimaryEn)
                )
            )
            && OpNat_Adjust == GET_OPNAT(mainPos, ExtPos_OpenOpNatEn))
        {
            if(FUS_GetFusionRulePosLogType(ctx, PosLogTypesIdx) == PtfFusRule_WMP && GET_NUMBER(resPos, ExtPos_HistQuoteQty) == 0.)
            {
                COPY_DYNFLD(newMainPos, ExtPos, ExtPos_HistQuoteQty,  mainPos , ExtPos, ExtPos_HistQuoteQty);
                if (OpNat_Adjust == GET_OPNAT(mainPos, ExtPos_OpenOpNatEn))
                {
                    COPY_DYNFLD(newMainPos, ExtPos, ExtPos_HistQuoteAver, resPos , ExtPos, ExtPos_HistQuoteAver);
                    COPY_DYNFLD(newMainPos, ExtPos, ExtPos_HistQuote,     resPos , ExtPos, ExtPos_HistQuoteAver);
                }
                else
                {
                    COPY_DYNFLD(newMainPos, ExtPos, ExtPos_HistQuoteAver, mainPos , ExtPos, ExtPos_HistQuoteAver);
                    COPY_DYNFLD(newMainPos, ExtPos, ExtPos_HistQuote, mainPos , ExtPos, ExtPos_HistQuoteAver);
                }
            }
            else
            {
                COPY_DYNFLD(newMainPos, ExtPos, ExtPos_HistQuoteAver, resPos , ExtPos, ExtPos_HistQuoteAver);
                COPY_DYNFLD(newMainPos, ExtPos, ExtPos_HistQuoteQty,  resPos , ExtPos, ExtPos_HistQuoteQty);
            }
        }

        /* PMSTA-4559 - 011107 - PMO */
        if (GET_POSREFNAT(mainPos, ExtPos_RefNatEn) == PosRefNat_FutWMP)
        {
            SET_ENUM(newMainPos, ExtPos_RefNatEn, PosRefNat_FutWMP);
        }
        else
        {
            COPY_DYNFLD(newMainPos, ExtPos, ExtPos_RefNatEn, *pos2, ExtPos, ExtPos_RefNatEn);
        }

        /* REF4452 sme */
        if (ctx->margInheritPosDate == MargInheritPosDate_Copy)
        {
            COPY_DYNFLD(newMainPos, ExtPos, ExtPos_AcctDate, *pos2, ExtPos, ExtPos_AcctDate);
            COPY_DYNFLD(newMainPos, ExtPos, ExtPos_OpDate,   *pos2, ExtPos, ExtPos_OpDate);
            COPY_DYNFLD(newMainPos, ExtPos, ExtPos_ValDate,  *pos2, ExtPos, ExtPos_ValDate);
        }
    
        /* Insert new main position */
        FUS_TracePos( ctx, newMainPos, "newMainPos");   /* PMSTA-4559 - 011107 - PMO */
        if ((ret = FIN_InsertPos(ctx, newMainPos, PosLogTypesIdx, FALSE, FALSE, NULL)) != RET_SUCCEED)
        {
            FREE_DYNST(newMainPos, ExtPos);                       /* PMSTA-4559 - 011107 - PMO */
            return ret;
        }

        /* Don't free newMainPos !! Will be freed by fin_freefuscontext */

        /* Except in case of no-splitting, eventually generated capital/exchange G/L
           must be affected to the adjustment instrument */
        /* Capital G/L */
        if (instrCapGLBPos != NULL)
        {
            if (MC_NoSplit == false)
            {
                /* Replace balance position type if specified */
                if (IS_NULLFLD(adjPos, ExtPos_BalPosTpId) != TRUE)
                {
                    COPY_DYNFLD(instrCapGLBPos, ExtPos, ExtPos_BalPosTpId,
                                adjPos, ExtPos, ExtPos_BalPosTpId);
                }

                /* Copy instrument and currencies */
                ret = FIN_ChangeInstrument(ctx,PosLogTypesIdx, instrCapGLBPos, adjPos);
                if (ret != RET_SUCCEED)
                {
                    return(ret);
                }

                DBA_DYNFLD_STP newInstrCapGLBPos = NULL;

                /* Re-insert capital G/L in correct logical type (filter fields have changed) */
                ret = FIN_CopyExtPos(ctx, instrCapGLBPos, &newInstrCapGLBPos);   /* PMSTA-6921 - 311008 - PMO */
                if (ret != RET_SUCCEED)
                {
                    return(ret);
                }

                /* Always point on new capital G/L */
                instrCapGLBPos = newInstrCapGLBPos;
            }
            else
            {
                /* Generated capital G/L must be deleted from fusion context */
                SET_ENUM(instrCapGLBPos, ExtPos_FusStateEn, FusState_Untreated);
            }
        }

        /* Exchange G/L */
        if (instrExchGLBPos != NULL)
        {
            if (MC_NoSplit == false)
            {
                /* Replace balance position type if specified */
                if (IS_NULLFLD(adjPos, ExtPos_BalPosTpId) != TRUE)
                {
                    COPY_DYNFLD(instrExchGLBPos, ExtPos, ExtPos_BalPosTpId,
                                adjPos, ExtPos, ExtPos_BalPosTpId);
                }

                /* Copy instrument and currencies */
                ret = FIN_ChangeInstrument(ctx, PosLogTypesIdx,instrExchGLBPos, adjPos);
                if (ret != RET_SUCCEED)
                {
                    return(ret);
                }

                /* PMSTA08746 - 061009 - PMO */
                if (  true == bOpWithAnotherCurrencyThanPtf
                   && 0 == CMP_AMOUNT(fabs(GET_AMOUNT(instrExchGLBPos, ExtPos_RefNetAmt)), 0.01, GET_ID(instrExchGLBPos, ExtPos_RefCurrId)) /* PMSTA-31831 - DDV - 180912 - Change 0.01 to 0.000001 ?!!?! To analyse!*/
                   )
                {
                    SET_AMOUNT(instrExchGLBPos, ExtPos_RefNetAmt,   -GET_AMOUNT(instrExchGLBPos, ExtPos_RefNetAmt));
                    SET_AMOUNT(instrExchGLBPos, ExtPos_RefGrossAmt, -GET_AMOUNT(instrExchGLBPos, ExtPos_RefGrossAmt));

                    /* Set balance position type (gain or loss) */
                    FIN_SetBalancePositionType(ctx, instrExchGLBPos);
                }

                DBA_DYNFLD_STP newInstrExchGLBPos = NULL;

                /* Re-insert exchange G/L in correct logical type (filter fields have changed) */
                ret = FIN_CopyExtPos(ctx, instrExchGLBPos, &newInstrExchGLBPos); /* PMSTA-6921 - 311008 - PMO */
                if (ret != RET_SUCCEED)
                {
                    return(ret);
                }

                /* Always point on new exchange G/L */
                instrExchGLBPos = newInstrExchGLBPos;
            }
            else
            {
                /* Generated exchange G/L must be deleted from fusion context */
                SET_ENUM(instrExchGLBPos, ExtPos_FusStateEn, FusState_Untreated);
            }
        }

        /********************************* Account Position ***************************************/
        /* PMSTA-4559 - 011107 - PMO */
        ret = FIN_AddAccClosePos(ctx, pNewAccClosePos, accCloseIdx, accClosePos, mainPos, *pos2);
        if (ret != RET_SUCCEED)
        {
            return(ret);
        }

        /********************************* Adjustment Position *************************************/

        /* If no-splitting, user's P&L are already stored in adjustment position. */
        if (MC_NoSplit == true)
        {
            DBA_DYNFLD_STP newAdjPos = FUS_DynStDup(adjPos, ctx);   /* Copy of adjusted position */

            /* Memory allocation */
            if (newAdjPos == NULL)
            {
                (void)MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "ExtPos");
                return(RET_MEM_ERR_ALLOC);
            }

            /* Set copy of adjusted Pos to "open" and no Margin Call */
            SET_NULL_ID(newAdjPos, ExtPos_Id);
            SET_NULL_ID(newAdjPos, ExtPos_PosObjId);
            SET_NULL_CODE(newAdjPos, ExtPos_RefOpCd);
            SET_ENUM(newAdjPos, ExtPos_RefNatEn, PosRefNat_None);
            SET_NULL_ID(newAdjPos, ExtPos_CloseOpId);
            SET_NULL_CODE(newAdjPos, ExtPos_CloseOpCd);
            SET_NULL_DATETIME(newAdjPos, ExtPos_EndDate);
            SET_ENUM(newAdjPos, ExtPos_AdjustNatEn, OpAdjustNat_None);
            SET_ENUM(newAdjPos, ExtPos_PrimaryEn, PosPrimary_Derived);
            SET_NULL_CODE(newAdjPos, ExtPos_RevOpCd);				/* REF5614 - 010209 - DED */
            SET_ENUM(newAdjPos, ExtPos_RevNatEn, PosRevNat_None);	/* REF5614 - 010209 - DED */

            /* Insert new adjusted position */
            FUS_TracePos( ctx, newAdjPos, "newAdjPos");   /* PMSTA-4559 - 011107 - PMO */
            if ((ret = FIN_InsertPos(ctx, newAdjPos, adjPosIdx, FALSE, FALSE, NULL)) != RET_SUCCEED)
            {
                FREE_DYNST(newAdjPos, ExtPos);
                return ret;
            }
        }

        /* Close adjustment position */             /* BUG504 - 970910 - DED */
        ret = FIN_CloseExtPos(ctx, adjPos, finPos, GET_DATETIME(adjPos, ExtPos_BegDate)); /* REF4122 - 000406 - DED */
    }

    return ret;
}


/*******************************************************************************
**
**  Function    :   FIN_SearchAccounts
**
**  Description :   Search accounts positions
**
**  Arguments   :   pOperationAccounts  Structure used for passing arguments
**
**  Return      :   None
**
**  Last modif. :   PMSTA-17020 - 021013 - PMO : Handling of futures operations without account
**                  PMSTA-17898 - 160414 - PMO : New Fusion Criteria to manage the contract dates for margin calls after partial closing
**
*******************************************************************************/
STATIC void FIN_SearchAccounts(OPERATION_ACCOUNTS_STP pOperationAccounts)
{
    int                 nullSurQuatre           = 4; /* optim to remove the 4 tests on xxxPos == NULL */
    int                 posNb;
    FIN_LOG_TYPE_STP    pPosLogTypes;
    DBA_DYNFLD_STP      currPos;
    FIN_FUS_CONTEXT_STP ctx                     = pOperationAccounts->m_ctx;
    DBA_DYNFLD_STP      pos2                    = pOperationAccounts->m_pos2;
    DBA_DYNFLD_STP      mainPos                 = pOperationAccounts->m_mainPos;
    DBA_DYNFLD_STP      accOpenPos              = pOperationAccounts->m_accOpenPos;
    DBA_DYNFLD_STP      accClosePos             = pOperationAccounts->m_accClosePos;
    DBA_DYNFLD_STP      acc2ClosePos            = pOperationAccounts->m_acc2ClosePos;
    DBA_DYNFLD_STP      acc2ClosePosDerived     = pOperationAccounts->m_acc2ClosePosDerived;
    DBA_DYNFLD_STP      adjPos                  = pOperationAccounts->m_adjPos;
    int                 accOpenIdx              = pOperationAccounts->m_accOpenIdx;
    int                 accCloseIdx             = pOperationAccounts->m_accCloseIdx;
    int                 acc2CloseIdx            = pOperationAccounts->m_acc2CloseIdx;
    int                 acc2ClosePosDerivedIdx  = pOperationAccounts->m_acc2ClosePosDerivedIdx;
    int                 adjPosIdx               = pOperationAccounts->m_adjPosIdx;
    bool                evalExtPosCd;
    bool                stateExtPosCd           = false;
    const DATATYPE_ENUM ExtPos_OpenOpCd_Type    = GET_FLD_TYPE(ExtPos, ExtPos_OpenOpCd);
    const DATATYPE_ENUM ExtPos_RefOpCd_Type     = GET_FLD_TYPE(ExtPos, ExtPos_RefOpCd);


    /***** Look for other to use positions in fusion context *****/
    for (int i = 0; i < ctx->posLogTypesNb && nullSurQuatre > 0 ; i++)
    {
        pPosLogTypes = &ctx->posLogTypesTab[i];
        posNb        = pPosLogTypes->posNb;

        if (posNb && FIN_CommonLogIdCmp(pos2, pPosLogTypes->posTab[0]) != 0)
            continue;   /* change logical type OPTIM SME */

        for (int j = 0; j < posNb && nullSurQuatre > 0 ; j++)
        {
            currPos = pPosLogTypes->posTab[j];

            if (GET_ENUM(currPos, ExtPos_FusStateEn) == FusState_Opened )
            {
                const ENUM_T currPos_RefNatEn = GET_ENUM(currPos, ExtPos_RefNatEn) ;
                const ENUM_T currPos_PosNatEn = GET_ENUM(currPos, ExtPos_PosNatEn) ;

                evalExtPosCd = false;

                 /* Check account-open position
                    - forward/future/term open
                    - position nature = Main Account
                    - fusion_state = opened
                    - open_oper_code = open_oper_code
                    - operation status = operation status
                    - same portfolio and portfolio position set Id's
                 */
                 if(  accOpenPos == NULL
                   && currPos_PosNatEn  == PosNat_MainAcctPos
                   && (currPos_RefNatEn  == PosRefNat_FwdOpen       ||
                       currPos_RefNatEn  == PosRefNat_FutOpen       ||
                       currPos_RefNatEn  == PosRefNat_FRAOpen       ||  /* DVP440 */
                       currPos_RefNatEn  == PosRefNat_FutFifo       ||
                       currPos_RefNatEn  == PosRefNat_FutWMP        ||  /* PMSTA-4559 - 011107 - PMO */
                       currPos_RefNatEn  == PosRefNat_FutContract   ||  /* PMSTA-17898 - 160414 - PMO */
                       currPos_RefNatEn  == PosRefNat_TermOpen) 
                   && GET_ENUM(pos2, ExtPos_StatEn) == GET_ENUM(currPos, ExtPos_StatEn) 
                   && (CMP_DYNFLD(pos2, currPos, ExtPos_OpenOpCd, ExtPos_OpenOpCd,ExtPos_OpenOpCd_Type ) == 0) 
                  )
                {
                    accOpenPos = currPos;
                    accOpenIdx = i;
                    nullSurQuatre -- ;
                    continue;
                }

                if ( GET_ENUM(currPos, ExtPos_StatEn) == GET_ENUM(mainPos, ExtPos_StatEn) )
                {    
                    /* Check account2-close position
                       - position nature = Account2
                       - fusion_state = opened
                       - open_oper_code = oper_oper_code
                       - operation status = operation status
                       - primary_e = 1 or (derided if future fifo)
                       - same portfolio and portfolio position set Id's
                    */
                    if( currPos_PosNatEn  == PosNat_Acct2Pos  &&
                        CMP_DYNFLD(mainPos, currPos, ExtPos_OpenOpCd, ExtPos_OpenOpCd,ExtPos_OpenOpCd_Type ) == 0 )
                    {
                        /* REF11075 - 050407 - PMO */
                        switch (GET_ENUM(currPos, ExtPos_PrimaryEn))
                        {
                            case PosPrimary_Derived:
                                if (NULL == acc2ClosePosDerived
                                    && (  currPos_RefNatEn == PosRefNat_FutFifo
                                       || currPos_RefNatEn == PosRefNat_FutWMP          /* PMSTA-4559 - 011107 - PMO */
                                       || currPos_RefNatEn == PosRefNat_FutContract     /* PMSTA-17898 - 160414 - PMO */
                                       )
                                   )
                                {
                                    acc2ClosePosDerived     = currPos;
                                    acc2ClosePosDerivedIdx  = i;   
                                }
                                break;

                            case PosPrimary_Primary:    /* Standard case */
                                if (acc2ClosePos == NULL)
                                {
                                    acc2ClosePos = currPos;
                                    acc2CloseIdx = i;
                                    nullSurQuatre --;
                                }
                                break;

                            default:
                            case PosPrimary_Second:
                                /* No code */
                                break;
                        }
                    }
                
                     /* Check account-close position 
                       - forward/future/term close
                       - position nature = Main Account 
                       - fusion_state = opened 
                       - reference code = reference code
                       - open_oper_code = oper_oper_code
                       - operation status = operation status
                       - same portfolio and portfolio position set Id's
                    */
                    if(  accClosePos         == NULL
                      && currPos_PosNatEn    == PosNat_MainAcctPos
                      &&  (currPos_RefNatEn  == PosRefNat_FwdClose      ||
                           currPos_RefNatEn  == PosRefNat_FutClose      ||
                           currPos_RefNatEn  == PosRefNat_FRAClose      ||  /* DVP440 */
                           currPos_RefNatEn  == PosRefNat_FutFifo       ||
                           currPos_RefNatEn  == PosRefNat_FutWMP        ||  /* PMSTA-4559 - 011107 - PMO */
                           currPos_RefNatEn  == PosRefNat_FutContract   ||  /* PMSTA-17898 - 160414 - PMO */
                           currPos_RefNatEn  == PosRefNat_TermClose ) 
                      && ( true == SetevalExtPosCd (evalExtPosCd )   /* optim to avoid a second evaluation at the next block EFE+PMO REF11433 */
                           && 
                           (stateExtPosCd= (  CMP_DYNFLD(mainPos, currPos, ExtPos_RefOpCd,  ExtPos_RefOpCd, ExtPos_RefOpCd_Type)  == 0 
                                           && CMP_DYNFLD(mainPos, currPos, ExtPos_OpenOpCd, ExtPos_OpenOpCd,ExtPos_OpenOpCd_Type) == 0 )) == true
                         )
                      )
                    {
                        accClosePos = currPos;
                        accCloseIdx = i;
                        nullSurQuatre --;
                    }


                    /* Check adjustment position for Margin Call 
                       - adjustment nature 
                       - position nature = AdjPos
                       - fusion_state = opened
                       - reference code = reference code
                       - reference nature = reference nature
                       - open_oper_code = oper_oper_code
                       - operation status = operation status
                       - same portfolio and portfolio position set Id's
                    */
                    if(  adjPos            == NULL
                      && currPos_PosNatEn  == PosNat_AdjPos 
                      && GET_ENUM(mainPos, ExtPos_AdjustNatEn) == OpAdjustNat_MarginCall 
                      && GET_ENUM(currPos, ExtPos_AdjustNatEn) == OpAdjustNat_MarginCall 
                      && GET_ENUM(mainPos, ExtPos_RefNatEn) == currPos_RefNatEn 
                      && ( ( evalExtPosCd == true && stateExtPosCd == true ) 
                           || 
                           (  CMP_DYNFLD(mainPos, currPos, ExtPos_RefOpCd,  ExtPos_RefOpCd, ExtPos_RefOpCd_Type)  == 0 
                           && CMP_DYNFLD(mainPos, currPos, ExtPos_OpenOpCd, ExtPos_OpenOpCd,ExtPos_OpenOpCd_Type) == 0
                           )
                         )
                      )
                    {
                        adjPos = currPos;
                        adjPosIdx = i;
                        nullSurQuatre --;
                    }
                }
            }
        }
    }

    /* PMSTA-4559 - 011107 - PMO */
    /* If no account positions found and we use the FuturWMP */
    if (accOpenPos == NULL && true == FIN_IsFutWMPUsed(mainPos,pos2)) 
    {
        /* PMSTA08809 - 151009 - PMO */
        if (FALSE == IS_NULLFLD(pos2,ExtPos_Acct1IdFus))
        { /* Lookup based on the value on the field ExtPos_Acct1IdFus */
            const ID_T idInstr = GET_ID(pos2,ExtPos_Acct1IdFus);

            /***** Search the position *****/
            for (int i = 0; i < ctx->posLogTypesNb; i++) 
            {
                pPosLogTypes = &ctx->posLogTypesTab[i];
                posNb        = pPosLogTypes->posNb;

                if (  posNb > 0 
                   && 0 == CMP_ID(GET_ID(pPosLogTypes->posTab[0], ExtPos_InstrId), idInstr )
                   && 0 == FIN_CommonLogIdCmp(pos2, pPosLogTypes->posTab[0]))                       /* PMSTA-10139 - 041010 - PMO */
                {
                    for (int j = 0; j < posNb; j++)
                    {
                        currPos = pPosLogTypes->posTab[j];

                        if (GET_ENUM(currPos, ExtPos_FusStateEn) == FusState_Opened )
                        {
                            const ENUM_T currPos_RefNatEn = GET_ENUM(currPos, ExtPos_RefNatEn) ;
                            const ENUM_T currPos_PosNatEn = GET_ENUM(currPos, ExtPos_PosNatEn) ;

                            /* Check account-open position 
                               - forward/future/term open
                               - position nature = Main Account 
                               - fusion_state = opened 
                               - operation status = operation status
                               - same portfolio and portfolio position set Id's
                            */
                            if(    currPos_PosNatEn  == PosNat_MainAcctPos
                               && (currPos_RefNatEn  == PosRefNat_FutFifo       ||
                                   currPos_RefNatEn  == PosRefNat_FutWMP        ||
                                   currPos_RefNatEn  == PosRefNat_FutContract)                      /* PMSTA-17898 - 160414 - PMO */
                                   && GET_ENUM(pos2, ExtPos_StatEn) == GET_ENUM(currPos, ExtPos_StatEn)
                               )
                            {
                                accOpenPos = currPos;
                                accOpenIdx = i;
                                break;
                            }
                        }
                    }
                    break;
                }
            }
        }

        /* PMSTA-11758 - 250311 - PMO */
        if (accOpenPos == NULL)
        { /* Lookup based on the value on the field ExtPos_OpenOpId */
            const ID_T  idOperation = GET_ID(pos2,ExtPos_OpenOpId);

            /***** Search the position *****/
            for (int i = 0; i < ctx->posLogTypesNb; i++) 
            {
                pPosLogTypes = &ctx->posLogTypesTab[i];
                posNb        = pPosLogTypes->posNb;

                if (  NULL !=  pPosLogTypes->ptrInstrument
                   && GET_ENUM(pPosLogTypes->ptrInstrument, A_Instr_NatEn) == InstrNat_CashAcct
                   && posNb > 0
                   && 0 == FIN_CommonLogIdCmp(pos2, pPosLogTypes->posTab[0])                        /* PMSTA-10139 - 041010 - PMO */
                   )
                {
                    for (int j = 0; j < posNb; j++)
                    {
                        currPos = pPosLogTypes->posTab[j];

                        if (0 == CMP_ID(idOperation,  GET_ID(currPos, ExtPos_OpenOpId))
                           && OpFusion_ToDelete  != GET_ENUM(currPos, ExtPos_Fus)
                           && FusState_Opened    == GET_ENUM(currPos, ExtPos_FusStateEn)
                           && PosRefNat_None     == GET_ENUM(currPos, ExtPos_RefNatEn)
                           && PosPrimary_Derived == GET_ENUM(currPos, ExtPos_PrimaryEn)
                           && GET_ENUM(pos2, ExtPos_StatEn) == GET_ENUM(currPos, ExtPos_StatEn) 
                           )
                        {
                            accOpenPos = currPos;
                            accOpenIdx = i;
                            break;
                        }
                    }

                    if (NULL != accOpenPos)
                    {
                        break;
                    }
                }
            }
        }

        /* PMSTA-15795 - 150113 - PMO */
        if (accOpenPos == NULL)
        { /* Lookup based on a free position */

            /***** Search the position *****/
            for (int i = 0; i < ctx->posLogTypesNb; i++) 
            {
                pPosLogTypes = &ctx->posLogTypesTab[i];
                posNb        = pPosLogTypes->posNb;

                if (  NULL !=  pPosLogTypes->ptrInstrument
                   && GET_ENUM(pPosLogTypes->ptrInstrument, A_Instr_NatEn) == InstrNat_CashAcct
                   && posNb > 0
                   && 0 == FIN_CommonLogIdCmp(pos2, pPosLogTypes->posTab[0])
                   )
                {
                    for (int j = 0; j < posNb; j++)
                    {
                        currPos = pPosLogTypes->posTab[j];
                        if (  OpFusion_ToDelete  != GET_ENUM(currPos,       ExtPos_Fus)
                           && FusState_Opened    == GET_FUSSTATE(currPos,   ExtPos_FusStateEn)
                           && OpNat_Adjust       == GET_OPNAT(currPos ,     ExtPos_OpenOpNatEn)
                           && (  PosRefNat_FutWMP      == GET_POSREFNAT(currPos, ExtPos_RefNatEn)
                              || PosRefNat_FutContract == GET_POSREFNAT(currPos, ExtPos_RefNatEn)       /* PMSTA-17898 - 160414 - PMO */
                              )
                           && PosNat_MainAcctPos == GET_POSNAT(currPos,     ExtPos_PosNatEn)
                           && PosPrimary_Derived == GET_POSPRIMARY(currPos, ExtPos_PrimaryEn)
                           && GET_ENUM(pos2, ExtPos_StatEn) == GET_ENUM(currPos, ExtPos_StatEn) 
                           )
                        { /* Found */
                            accOpenPos = currPos;
                            accOpenIdx = i;
                            break;
                        }
                    }

                    if (NULL != accOpenPos)
                    {
                        break;
                    }
                }
            } /* End for */
        } /* End if */
    } /* End if */

    pOperationAccounts->m_accOpenPos                = accOpenPos;
    pOperationAccounts->m_accClosePos               = accClosePos;
    pOperationAccounts->m_acc2ClosePos              = acc2ClosePos;
    pOperationAccounts->m_acc2ClosePosDerived       = acc2ClosePosDerived;
    pOperationAccounts->m_adjPos                    = adjPos;
    pOperationAccounts->m_accOpenIdx                = accOpenIdx;
    pOperationAccounts->m_accCloseIdx               = accCloseIdx;
    pOperationAccounts->m_acc2CloseIdx              = acc2CloseIdx;
    pOperationAccounts->m_acc2ClosePosDerivedIdx    = acc2ClosePosDerivedIdx;
    pOperationAccounts->m_adjPosIdx                 = adjPosIdx;
}



/*******************************************************************************
**
**  Function    :   FIN_FormatedDate
**
**  Description :   Format a date
**
**  Arguments   :   formatedDate    Resulting formatted date
**                  pos             Position that contains the date
**                  field           Field that contains the date
**                  accClosePos     Accouting of mainPos
**
**  Return      :   formatedDate
**
**  Last modif. :   PMSTA-17020 - 021013 - PMO : Handling of futures operations without account
**
*******************************************************************************/
char * FIN_FormatedDate(char * formatedDate, const size_t sizeFormatedDate, DBA_DYNFLD * pos, const FIELD_IDX_T field)
{
    char dateFmt[32];

    DATETIME64_ST  date = GET_DATETIMEST(pos, field);
    if (RET_SUCCEED == CONV_GetDfltDateFmt(DatetimeType, dateFmt, NULL))
    {
        (void)CONV_DataToStr(formatedDate, sizeFormatedDate, DatetimeType, dateFmt, &date, FALSE, TextConversion_None);
    }
    else
    { /* Error */
        formatedDate[0] = 0;
    }

    return formatedDate;
}


/*******************************************************************************
**
**  Function    :   FIN_ExistMandatoryAccoutingPosition
**
**  Description :   Check if mandatory account are found. If not write, an error message
**
**  Arguments   :   ctx             Pointer on context-structure
**                  functionName    Name of the function caller
**                  mainPos         Closing position (main)
**                  pos2            Second position
**                  accOpenPos      Accouting of pos2
**                  accClosePos     Accouting of mainPos
**
**  Return      :   true           if ok
**                  false          if error
**
**  Last modif. :   PMSTA-17020 - 021013 - PMO : Handling of futures operations without account
**                  PMSTA-51476 - DDV - 230112 - For SubNat_FXFwd_TwoLegsAgainsPtfCurr accClosePos is optional
**
*******************************************************************************/
bool FIN_ExistMandatoryAccoutingPosition(FIN_FUS_CONTEXT_STP ctx, const char * functionName, const DBA_DYNFLD_STP mainPos, const DBA_DYNFLD_STP pos2, const DBA_DYNFLD_STP accOpenPos, const DBA_DYNFLD_STP accClosePos, bool bClosePosIsOptional)
{
    bool ret = true;

    if (accOpenPos == NULL) 
    {
        char szDate[32];                                                                    /* PMSTA-17020 - 021013 - PMO */

        (void)MSG_SendMesg(RET_FIN_ERR_NOACCTPOS, 0, FILEINFO, functionName,
                        GET_CODE(pos2, ExtPos_OpenOpCd),
                        ctx->currPtfInfo->portfolioCd,
                        FIN_FormatedDate(szDate, sizeof(szDate), pos2, ExtPos_BegDate));    /* PMSTA-17020 - 021013 - PMO */

        /* PMSTA-11242 - 020211 - PMO */
        char szMsg[256];
        (void)snprintf(szMsg, 
                 sizeof(szMsg), 
                 "Warning: %s no acc position mainPos:%s, ptf:%s, date:%s",                 /* PMSTA-17020 - 021013 - PMO */
                 functionName,
                 GET_CODE(pos2, ExtPos_OpenOpCd),
                 ctx->currPtfInfo->portfolioCd,
                 szDate);                                                                   /* PMSTA-17020 - 021013 - PMO */
        FUS_TraceMessage(ctx, szMsg);

        ret = false;
    }

	/* PMSTA-51476 - DDV - 230112 - For SubNat_FXFwd_TwoLegsAgainsPtfCurr accClosePos is optional */
    if (accClosePos == NULL && !bClosePosIsOptional)
    {
        char szDate[32];                                                                    /* PMSTA-17020 - 021013 - PMO */

        (void)MSG_SendMesg(RET_FIN_ERR_NOACCTPOS, 0, FILEINFO, functionName,
                        GET_CODE(mainPos, ExtPos_OpenOpCd),
                        ctx->currPtfInfo->portfolioCd,
                        FIN_FormatedDate(szDate, sizeof(szDate), mainPos, ExtPos_BegDate)); /* PMSTA-17020 - 021013 - PMO */

        /* PMSTA-11242 - 020211 - PMO */
        char szMsg[256];
        (void)snprintf(szMsg, 
                sizeof(szMsg), 
                "Warning: %s no close position mainPos:%s, ptf:%s, date:%s",                /* PMSTA-17020 - 021013 - PMO */
                functionName,
                GET_CODE(mainPos, ExtPos_OpenOpCd),
                ctx->currPtfInfo->portfolioCd,
                szDate);                                                                    /* PMSTA-17020 - 021013 - PMO */
        FUS_TraceMessage(ctx, szMsg);

        ret = false;
    }

    return ret;
}


/*******************************************************************************
**
**  Function    : FIN_ReferencePos
**
**  Description : Special treatment operations with a reference nature
**        (cfr. document analysis by S. Andrieux (05/02/1995))
**
**  Arguments   : ctx           pointer on context-structure
**        PosLogTypesIdx    index of logical type
**        mainPos       pointer on closing position (main)
**                  (can also be term open position)
**        extPosType        record type of closing position : pos/balpos
**                pos2                  position to fuse with
**                freeAccClose          new position no ref_nat - account close
**                freeAccOpen           new position no ref_nat - account open
**                forceFlg              force create of newAccOpen position + compute fact (default=FLAG)
**
**  Return      : RET_SUCCEED           if ok
**        RET_GEN_ERR_INVARG        error in arguments
**        RET_FIN_ERR_POSITIONS     no "open" position found
**        RET_FIN_ERR_NOACCTPOS     no open/close account positions found
**        RET_FIN_ERR_NOADJPOS      no adjustment position for Margin Calls
**        RET_MEM_ERR_ALLOC     error in memory allocations
**
**  Last modif. : DVP029 - 960507 - DED : change test on account_pos : use pos_nat_e
**        BUG051 - 960708 - DED : reference nature = None if quantity = 0
**        DVP464 - 970520 - DED : Add Margin Calls
**        DVP354 - 970623 - DED : Add test on portfolio position set
**                BUG403 - 970708 - DED : SubPosNat must NOT be set to 'none'
**                BUG446 - 970729 - DED : - Account Open must be closed by finPos
**                    - newAccOpen and freeAccOpen must have correct dates
**        BUG504 - 970910 - DED : Always repeat close of extended position
**                REF906 - 971113 - DED : Compute freeAccOpenPos amounts by difference
**        REF1134 - 980128 - DED : function can be called by a TermOpen position.
**                REF1315 - 980216 - DED : Add operation status as search criteria
**                REF1328 - 980224 - SME : add a test newAccOpenPos != NULL for compute amounts by difference
**        REF1712 - 980428 - DED : Wrong nature for free account positions
**        REF2038 - 980610 - DED : new account 2 position must be secondary instead of derived
**        REF2386 - 980618 - DED : Server crash if instrExchGLBPos is NULL
**                REF2661 - 980908 - SME : FutFifo
**                REF11075 - 050407 - PMO : P&L computation problem with future FIFO
**        REF11265 - 051021- EFE(PMO): Margin Calls and Fees wrongly computed when account 2 is used
**        REF11433- 050927 - EFE : optimization : cf LN :
**                                    tests if regrouped,
**                                    tests on codes put at the end of if
**                                    CMPDYNFLD replaced by GETENUM==GETENUM when possible
**                                    test accOpenPos == NULL || accClosePos == NULL ||
**                                    acc2ClosePos == NULL || adjPos == NULL replaced by the test on nullSurQuatre
**        PMSTA02926 - 070703 - EFE : problem on cash on value date for futures FIFO.
**        PMSTA-3257 - 170707 - PMO : P&L computation problem with Future FIFO and partial sell
**        PMSTA-4559 - 011107 - PMO : Futures Management (margin calls)
**        PMSTA-5207 - 110308 - PMO : Historical cost price wrong in closing position on operations with nature reference "future FIFO"
**        PMSTA-6328 - 060808 - PMO : Cash account incorrectly affected when entering variation margin adjustment
**        PMSTA-6921 - 311008 - PMO : Closing of Future with cash portfolio
**        PMSTA-6924 - 280109 - PMO : Cash Portfolio on Forwards
**        PMSTA-8062 - 190509 - PMO : Unexpected fusion results when computing several adjustment operations in the same day (no reference code or reference nature)
**        PMSTA08471 - 280709 - PMO : When the system parameter CASH_ADJUSTMENT is set to 0 or the cash adjustment flag of portfolio is set to 0, Fusion process always moves cash flows of P&L in cash portfolio
**        PMSTA08644 - 070909 - PMO : FUSION process doesn't always take into account a cash portfolio
**        PMSTA08809 - 151009 - PMO : Wrong cash amount after buying a futures on a portfolio that had a position in the same future before. And fusion processing error after updating an operation
**        PMSTA08746 - 061009 - PMO : Performance on futures in foreign currency
**        PMSTA08607 - 280909 - PMO : Wrong treatment of future positions when booking margin amount
**        PMSTA-9072 - 050510 - PMO : Future instrument with Fees&Taxes at opening position: exchange rate at opening position are not saved after adjustment operation
**        PMSTA-11242 - 020211 - PMO : Loses of operations while updating the remark through the GUI
**        PMSTA-11758 - 250311 - PMO : Account 2 is not found with Future WMP when launching a Fusion ALL but works fine in Fusion New
**        PMSTA-15795 - 150113 - PMO : Fusion engine problems with Future instrument while using fusion criteria sub position nature
**        PMSTA-17020 - 021013 - PMO : Handling of futures operations without account
**        PMSTA-17898 - 160414 - PMO : New Fusion Criteria to manage the contract dates for margin calls after partial closing
**        PMSTA-21380 - 070915 - PMO : Forward closing : no cash flow on reference currency to justify the impact on cash account
**
*******************************************************************************/
RET_CODE FIN_ReferencePos(FIN_FUS_CONTEXT_STP   ctx,
	const int             posLogTypesIdx,
	DBA_DYNFLD_STP        mainPos,
	const EXTPOSTYPE_ENUM extPosType,
	int *                 newLogTypeIdx,
	DBA_DYNFLD_STP *      pos2,
	DBA_DYNFLD_STP *      freeAccClose,
	DBA_DYNFLD_STP *      freeAccOpen,
	FLAG_T                forceFlg)
{
    const char functionName[]="FIN_ReferencePos"; /* PMSTA-4559 - 011107 - PMO */

    int         i, j, accCloseIdx=NO_VALUE, accOpenIdx=NO_VALUE,
        acc2CloseIdx=NO_VALUE, adjPosIdx=NO_VALUE;
    double      fact=0.0, qtyDiff=0.0;
    DBA_DYNFLD_STP  currPos=NULL,
        accOpenPos=NULL, accClosePos=NULL, acc2ClosePos=NULL,
        freeAccClosePos=NULL, newAccOpenPos=NULL,
        freeAccOpenPos=NULL, finPos=NULL,
        instrCapGLBPos=NULL, instrExchGLBPos=NULL,
        cashCapGLBPos=NULL, cashExchGLBPos=NULL,
        newMainPos=NULL,
        initPos=NULL,
        resPos=NULL,
        newAcc2ClosePos=NULL,
        adjPos=NULL,
        highPos=NULL, lowPos=NULL,
        swap=NULL;
    RET_CODE                ret;
    bool                    MC_NoSplit              = false;
    ID_T                    saveResPosOpenOperId;           /* REF11075 - 050407 - PMO */
    DATETIME_T              saveResPosBeginDate;            /* REF11075 - 050407 - PMO */
    CODE_T                  saveResPosOpenOperCode;         /* REF11075 - 050407 - PMO */
    DBA_DYNFLD_STP          acc2ClosePosDerived     = NULL; /* REF11075 - 050407 - PMO */
    int                     acc2ClosePosDerivedIdx  = 0;    /* REF11075 - 050407 - PMO */
    OPERATION_ACCOUNTS_ST   operationAccounts;              /* PMSTA-17020 - 021013 - PMO */

	/* Check arguments */
	if (ctx == NULL || mainPos == NULL)
	{
		(void)MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, functionName, "context or position");
		return(RET_GEN_ERR_INVARG);
	}


	/* Search for position to fuse with if not already known */                                 /* REF3929 - 990902 - DED */
	if (*pos2 == NULL)
	{
		int secPosIdx;

        if (  GET_POSREFNAT(mainPos, ExtPos_RefNatEn) == PosRefNat_FutFifo
           || GET_POSREFNAT(mainPos, ExtPos_RefNatEn) == PosRefNat_FutWMP
           || GET_POSREFNAT(mainPos, ExtPos_RefNatEn) == PosRefNat_FutContract                  /* PMSTA-17898 - 160414 - PMO */
           )
        {
            operationAccounts.fnSearch  = FIN_SearchAccounts;
            operationAccounts.m_mainPos = mainPos;
            operationAccounts.m_ctx     = ctx;

			/* PMSTA-17020 - 021013 - PMO */
			if (RET_SUCCEED != FIN_FindSecPos(ctx, posLogTypesIdx, mainPos, extPosType, pos2, &secPosIdx, NULL, &operationAccounts))
			{ /* Error */
				return RET_FIN_ERR_POSITIONS;
			}
		}
		else
		{
			FIN_FindOpenClosePos(ctx, posLogTypesIdx, mainPos, extPosType, pos2, &secPosIdx);   /* REF3929 - 990902 - DED */
		}

		/* If no second position found, don't go further */
		if (*pos2 == NULL)
		{
			return(RET_FIN_ERR_POSITIONS);
		}
	}

	FUS_TraceBeginFunction(ctx, functionName, FALSE );      /* PMSTA-4559 - 011107 - PMO */
	FUS_TRACE_INC_FUNCTION_ENTRY(ctx, FIN_ReferencePos);    /* PMSTA08644 - 070909 - PMO */

	/* Inverse pointers if term open/close positions
	   - mainPos = term close
	   - pos2    = term open
	*/                                          /* REF1134 - 980127 - DED */
	if (GET_ENUM(mainPos, ExtPos_RefNatEn) == PosRefNat_TermOpen)
	{
		DBA_DYNFLD_STP swap2 = *pos2;           /* REF3929 - 990902 - DED */
		*pos2 = mainPos;
		mainPos = swap2;
	}


    operationAccounts.m_mainPos = mainPos;
    operationAccounts.m_pos2    = *pos2;
    operationAccounts.m_ctx     = ctx;

    FIN_SearchAccounts(&operationAccounts);

    accOpenPos              = operationAccounts.m_accOpenPos;
    accClosePos             = operationAccounts.m_accClosePos;
    acc2ClosePos            = operationAccounts.m_acc2ClosePos;
    acc2ClosePosDerived     = operationAccounts.m_acc2ClosePosDerived;
    adjPos                  = operationAccounts.m_adjPos;
    accOpenIdx              = operationAccounts.m_accOpenIdx;
    accCloseIdx             = operationAccounts.m_accCloseIdx;
    acc2CloseIdx            = operationAccounts.m_acc2CloseIdx;
    acc2ClosePosDerivedIdx  = operationAccounts.m_acc2ClosePosDerivedIdx;
    adjPosIdx               = operationAccounts.m_adjPosIdx;

	/* PMSTA-51476 - DDV - 230112 - For SubNat_FXFwd_TwoLegsAgainsPtfCurr accClosePos is optional */
	bool bClosePosIsOptional = GET_ENUM(ctx->posLogTypesTab[posLogTypesIdx].ptrInstrument, A_Instr_SubNatEn) == SubNat_FXFwd_TwoLegsAgainsPtfCurr;

	/* If no account positions found, don't go further (account 2 not necessary) */
	if (false == FIN_ExistMandatoryAccoutingPosition(ctx, functionName, mainPos, *pos2, accOpenPos, accClosePos, bClosePosIsOptional))
	{
		FUS_TraceEndFunction(ctx, functionName, TRUE, FALSE); /* PMSTA-4559 - 011107 - PMO */

		return(RET_FIN_ERR_NOACCTPOS);
	}

	/* PMSTA-4559 - 011107 - PMO */
	COPY_DYNFLD(mainPos, ExtPos, ExtPos_Acct1IdFus, accOpenPos, ExtPos, ExtPos_InstrId);

	if (NULL != acc2ClosePos)
	{
		COPY_DYNFLD(mainPos, ExtPos, ExtPos_Acct2IdFus, acc2ClosePos, ExtPos, ExtPos_InstrId);
	}
	else
	{
		if (NULL != acc2ClosePosDerived)
		{
			COPY_DYNFLD(mainPos, ExtPos, ExtPos_Acct2IdFus, acc2ClosePosDerived, ExtPos, ExtPos_InstrId);
		}
	}

	FUS_TraceReferencedPos(ctx, accOpenPos, acc2ClosePos, acc2ClosePosDerived, accClosePos, adjPos);

	/* Tests for adjustment Margin Calls */
	if (GET_ENUM(mainPos, ExtPos_AdjustNatEn) == OpAdjustNat_MarginCall)
	{
		/* Adjustment position must exist */
		if (adjPos == NULL)
		{
			(void)MSG_SendMesg(RET_FIN_ERR_NOADJPOS, 0, FILEINFO, functionName,
				GET_CODE(mainPos, ExtPos_OpenOpCd),
				ctx->currPtfInfo->portfolioCd);

			/* PMSTA-11242 - 020211 - PMO */
			char szMsg[256];
			(void)snprintf(szMsg,
				sizeof(szMsg),
				"Warning: %s no adj position mainPos:%s, ptf:%s",
				functionName,
				GET_CODE(mainPos, ExtPos_OpenOpCd),
				ctx->currPtfInfo->portfolioCd);
			FUS_TraceMessage(ctx, szMsg);

			FUS_TraceEndFunction(ctx, functionName, TRUE, FALSE); /* PMSTA-4559 - 011107 - PMO */
			return(RET_FIN_ERR_NOADJPOS);
		}

		/* Check if acount2 is used with MarginCall .In that case no
		   splitting of cash positions. REF1734 / PMSTA08607 - 280909 - PMO */
        MC_NoSplit =  DATE_Cmp(ctx->applFutPlAcct2MarginCall.date, GET_DATETIME(mainPos, ExtPos_BegDate).date) > 0
                   && acc2ClosePos != NULL 
                   && GET_AMOUNT(acc2ClosePos,ExtPos_PosNetAmt) != 0;
	}

    /***** Find finPos (latest position) and initPos (oldest position, will close finPos)  *****/
    const DATETIME_T  date1 = GET_DATETIME(mainPos, ExtPos_BegDate);
    const DATETIME_T  date2 = GET_DATETIME((*pos2), ExtPos_BegDate);
    const int comp = DATETIME_CMP(date1, date2);
    if (comp > 0)
    {
        initPos = *pos2;
        finPos  = mainPos;
    }
    else if (comp < 0)
    {
        initPos = mainPos;
        finPos  = *pos2;
    }
	/* PMSTA-39328 - VSW - 200519 - Code Added to consider the Open operation Id rather than the Code as a First Level Check */
	/* This is to ensure that User defined Operation Codes are also considered correctly while accessing Relevant Open Positions */
	else if ((GET_ID(mainPos, ExtPos_OpenOpId)   >  ZERO_ID) && (GET_ID(*pos2, ExtPos_OpenOpId)   >  ZERO_ID))
	{
		if (CMP_DYNFLD(mainPos, *pos2, ExtPos_OpenOpId, ExtPos_OpenOpId, GET_FLD_TYPE(ExtPos, ExtPos_OpenOpId)) > 0)
		{
			initPos = *pos2;
			finPos = mainPos;
		}
		else
		{
			initPos = mainPos;
			finPos = *pos2;
		}
	}
	/* Positions start at same date, take smaller lexical op. code for initPos */
    else if (CMP_DYNFLD(mainPos, *pos2, ExtPos_OpenOpCd, ExtPos_OpenOpCd, GET_FLD_TYPE(ExtPos, ExtPos_OpenOpCd)) > 0)
    {
        initPos = *pos2;
        finPos  = mainPos;
    }
    else
    {
        initPos = mainPos;
        finPos  = *pos2;
    }

    /* REF3819 - 000112 - DED : determine lowpos/highpos */
    qtyDiff = fabs(GET_NUMBER(finPos, ExtPos_Qty)) - fabs(GET_NUMBER(initPos, ExtPos_Qty));
    if (CMP_NUMBER(qtyDiff, 0.0) > 0)
    {
        highPos = finPos;
        lowPos  = initPos;
    }
    else    /* PMSTA-8062 - 190509 - PMO */
    {
        highPos = initPos; 
        lowPos  = finPos;
    }

    EXTRACTED_BP extractedBp;   /* Extracted BP from a margin call position / PMSTA-5215 - 160408 - PMO */

    /***** Special treatment for Margin Calls *****/                                                /* DVP464 - 970521 - DED */
    bool bMarginCallAmountsInversed = false;                                                        /* PMSTA-15795 - 150113 - PMO */
    if (GET_ENUM(mainPos, ExtPos_AdjustNatEn) == OpAdjustNat_MarginCall)
    {
        /* Save original main position */
        /* Memory allocation */
        if ((newMainPos = FUS_DynStDup(mainPos, ctx)) == NULL)                                      /* PMSTA08746 - 061009 - PMO */
        {
           (void)MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "ExtPos");
            FUS_TraceEndFunction(ctx, functionName, TRUE, FALSE);                                   /* PMSTA-4559 - 011107 - PMO */
            return(RET_MEM_ERR_ALLOC);
        }

        /* For Margin Calls, we must inverse all signs of the closing position to force a Close Case */
        DBA_InverseSign(mainPos);
        bMarginCallAmountsInversed = true;                                                          /* PMSTA-15795 - 150113 - PMO */

        FUS_PositionExtractBP(ctx, *pos2, posLogTypesIdx, &extractedBp, true, true);                /* PMSTA-9072 - 050510 - PMO / PMSTA-5215 - 160408 - PMO */
    }

    /***** Fusion of instrument positions *****/
    if ((ret = FIN_PosFusion(ctx, mainPos, *pos2, posLogTypesIdx, NULL, &fact, 
                             &instrCapGLBPos, &instrExchGLBPos, NULL, NULL,
                             &resPos, NULL, FALSE)) != RET_SUCCEED)
    {
        FREE_DYNST(newMainPos, ExtPos);                                                             /* PMSTA-4559 - 011107 - PMO */

        FUS_PositionInjectBP (ctx, *pos2, posLogTypesIdx, &extractedBp, true, false, true, false);  /* PMSTA-9072 - 050510 - PMO / PMSTA-5215 - 160408 - PMO */

		FUS_TraceEndFunction(ctx, functionName, TRUE, FALSE);                                       /* PMSTA-4559 - 011107 - PMO */

		/* PMSTA-15795 - 150113 - PMO */
		if (true == bMarginCallAmountsInversed)
		{
			DBA_InverseSign(mainPos);
		}

		return ret;
	}

	const bool mergeCaseFusFlag = TRUE == FIN_IsMergeCaseFus(initPos, finPos);                      /* PMSTA-6921 - 311008 - PMO */

	{ /* Compute the hist_quote  PMSTA-4559 - 011107 - PMO */
		const bool bLong = GET_NUMBER(resPos, ExtPos_Qty) >= 0;
		const bool bZero = CMP_NUMBER(GET_NUMBER(resPos, ExtPos_Qty), 0.0) == 0;

		switch ( GET_ENUM(mainPos, ExtPos_OpenOpNatEn))
		{
		case OpNat_Buy:
			if (false == bLong || true == bZero)
			{
				COPY_DYNFLD(mainPos, ExtPos, ExtPos_HistQuote, resPos, ExtPos, ExtPos_HistQuoteAver);
				COPY_DYNFLD(resPos,  ExtPos, ExtPos_HistQuote, resPos, ExtPos, ExtPos_HistQuoteAver);
			}
			break;

		case OpNat_Sell:
			if (true == bLong || true == bZero)
			{
				COPY_DYNFLD(mainPos, ExtPos, ExtPos_HistQuote, resPos, ExtPos, ExtPos_HistQuoteAver);
				COPY_DYNFLD(resPos,  ExtPos, ExtPos_HistQuote, resPos, ExtPos, ExtPos_HistQuoteAver);
			}
			break;

		case OpNat_Adjust:
			if(FUS_GetFusionRulePosLogType(ctx, posLogTypesIdx) != PtfFusRule_WMP)  /* PMSTA-5207 - 110308 - PMO */
			{
				COPY_DYNFLD(mainPos, ExtPos, ExtPos_HistQuote, *pos2, ExtPos, ExtPos_HistQuote);
			}
			break;
		}
	}


	const bool  bOpWithAnotherCurrencyThanPtf = FUS_IsFutureOpWithAnotherCurrencyThanPtf(ctx, posLogTypesIdx, mainPos);     /* PMSTA-9072 - 050510 - PMO */

	/* Future WMP and merge case ? / PMSTA-17898 - 160414 - PMO / PMSTA - 4559 - 011107 - PMO */
	if (  (   true == FIN_IsFutWMPUsed(mainPos, *pos2)
		 || (  PosRefNat_FutContract == GET_POSREFNAT(mainPos, ExtPos_RefNatEn)
			|| PosRefNat_FutContract == GET_POSREFNAT(*pos2,   ExtPos_RefNatEn)
			)
		)
		&& TRUE == FIN_IsMergeCaseFus(initPos, finPos))
	{ /* Yes */
		FIN_LOG_TYPE_STP    pPosLogTypes;                                                                                   /* PMSTA-17020 - 021013 - PMO */
		DBA_DYNFLD_STP      accOpenPos2             = NULL;
		const ID_T          idInstr                 = GET_ID(mainPos,ExtPos_Acct1IdFus);
		int                 posNb;                                                                                          /* PMSTA-17020 - 021013 - PMO */
		const DATATYPE_ENUM ExtPos_OpenOpCd_Type    = GET_FLD_TYPE(ExtPos, ExtPos_OpenOpCd);                                /* PMSTA-17020 - 021013 - PMO */

		/***** Search the position *****/
		for (i = 0; i < ctx->posLogTypesNb && accOpenPos2 == NULL; i++)
		{
			pPosLogTypes = &ctx->posLogTypesTab[i];
			posNb        = pPosLogTypes->posNb;

			if (  posNb > 0
				&& 0 == CMP_ID(GET_ID(pPosLogTypes->posTab[0], ExtPos_InstrId), idInstr )
				&& 0 == FIN_CommonLogIdCmp(*pos2, pPosLogTypes->posTab[0]))                                                  /* PMSTA-10139 - 041010 - PMO */
			{
				for (j = 0; j < posNb; j++)
				{
					currPos = pPosLogTypes->posTab[j];

					if (GET_ENUM(currPos, ExtPos_FusStateEn) == FusState_Opened )
					{
						const ENUM_T currPos_RefNatEn = GET_ENUM(currPos, ExtPos_RefNatEn) ;
						const ENUM_T currPos_PosNatEn = GET_ENUM(currPos, ExtPos_PosNatEn) ;

						/* Check account-open position
						   - forward/future/term open
						   - position nature = Main Account
						   - fusion_state = opened
						   - operation status = operation status
						   - same portfolio and portfolio position set Id's
						*/
						if(    currPos_PosNatEn  == PosNat_MainAcctPos
						   && (currPos_RefNatEn  == PosRefNat_FutFifo       ||
							   currPos_RefNatEn  == PosRefNat_FutWMP        ||
							   currPos_RefNatEn  == PosRefNat_FutContract)          /* PMSTA-17898 - 160414 - PMO */
							&& GET_ENUM(mainPos, ExtPos_StatEn) == GET_ENUM(currPos, ExtPos_StatEn)
							&& 0 == CMP_DYNFLD(mainPos, currPos, ExtPos_OpenOpCd, ExtPos_OpenOpCd,ExtPos_OpenOpCd_Type)
							)
						{
							accOpenPos2 = currPos;
							break;
						}
					}
				}
			}
		}

		/* PMSTA08809 - 151009 - PMO */
		if (accOpenPos2 != accOpenPos && CMP_NUMBER(GET_AMOUNT((*pos2), ExtPos_Qty), 0.0) != 0)
		{
			if (NULL != accOpenPos2)
			{ /* Fusion of cash positions */
				double          fact3      = 0.0;
				DBA_DYNFLD_STP  resPosCash = NULL;

				ret = FIN_PosFusion(ctx, accOpenPos2, accOpenPos, accOpenIdx, NULL, &fact3,
					NULL, NULL, NULL, NULL, &resPosCash, NULL, FALSE);
			}
			else
			{ /* Error */
				char szDate[32];                                                                        /* PMSTA-17020 - 021013 - PMO */

				(void)MSG_SendMesg(RET_FIN_ERR_NOACCTPOS, 0, FILEINFO, functionName,
					GET_CODE(mainPos, ExtPos_OpenOpCd),
					ctx->currPtfInfo->portfolioCd,
					FIN_FormatedDate(szDate, sizeof(szDate), mainPos, ExtPos_BegDate));         /* PMSTA-17020 - 021013 - PMO */
				ret = RET_FIN_ERR_NOACCTPOS;
			}
		}

		if ( RET_SUCCEED == ret )
		{
			ret = FIN_FeesInOpWithAnotherCurrencyThanPtf(ctx, mainPos, newMainPos, pos2, resPos, bOpWithAnotherCurrencyThanPtf);
		}

		FREE_DYNST(newMainPos, ExtPos);                                                                 /* PMSTA-4559 - 011107 - PMO */
		FUS_PositionInjectBP(ctx, *pos2, posLogTypesIdx, &extractedBp, true, false, true, false);       /* PMSTA-9072 - 050510 - PMO / PMSTA-5215 - 160408 - PMO */
		FUS_TraceEndFunction(ctx, functionName, TRUE, FALSE);

		/* PMSTA-15795 - 150113 - PMO */
		if (true == bMarginCallAmountsInversed)
		{
			DBA_InverseSign(mainPos);
		}

		return ret;
	}

    /* Save these fields for later use REF11075 - 050407 - PMO */
    saveResPosOpenOperId    = GET_ID(resPos,        ExtPos_OpenOpId);
    saveResPosBeginDate     = GET_DATETIME(resPos,  ExtPos_BegDate);
    if (GET_CODE(resPos, ExtPos_OpenOpCd) != NULL)  /*PMSTA-47492 - VSW - 13012022 */
    {
        strcpy(saveResPosOpenOperCode, GET_CODE(resPos, ExtPos_OpenOpCd));
    }

	/* REF2661 SME FutFifo */
	if (GET_ENUM(resPos,ExtPos_RefNatEn) == PosRefNat_FutFifo)
	{
		ret = FIN_GetExtPosIdx(ctx, posLogTypesIdx,resPos, newLogTypeIdx);  /* REF4121 - 991108 - DED */
		if (ret != RET_SUCCEED)
		{
			FREE_DYNST(newMainPos, ExtPos);                                                             /* PMSTA-4559 - 011107 - PMO */
			FUS_PositionInjectBP(ctx, *pos2, posLogTypesIdx, &extractedBp, true, false, true, false);   /* PMSTA-9072 - 050510 - PMO / PMSTA-5215 - 160408 - PMO */
			FUS_TraceEndFunction(ctx, functionName, TRUE, FALSE);                                       /* PMSTA-4559 - 011107 - PMO */

			/* PMSTA-15795 - 150113 - PMO */
			if (true == bMarginCallAmountsInversed)
			{
				DBA_InverseSign(mainPos);
			}

			return(ret);
		}
	}

	DBA_DYNFLD_STP  newAccClosePos = NULL;	/* PMSTA08607 - 280909 - PMO */

	/***** Special treatment for Margin Calls *****/
    ret = FIN_ProcessingMarginCall( ctx,
                                    posLogTypesIdx,
                                    mainPos,
                                    newMainPos,
                                    finPos,
                                    adjPos,
                                    adjPosIdx, 
                                    pos2,
                                    instrCapGLBPos,
                                    instrExchGLBPos,
                                    resPos,
                                    MC_NoSplit,
                                    accCloseIdx, 
                                    accClosePos,
                                    bOpWithAnotherCurrencyThanPtf,	/* PMSTA08746 - 061009 - PMO */
                                    extractedBp,
                                    &newAccClosePos	                /* PMSTA08607 - 280909 - PMO */
                                    );

	if (ret != RET_SUCCEED)
	{
		FUS_TraceEndFunction(ctx, functionName, TRUE, FALSE);       /* PMSTA-4559 - 011107 - PMO */
		return ret;
	}

	/* PMSTA-51476 - DDV - 230112 - Do it only if accClosePos exist */
	if (accClosePos != NULL)
	{
		if (CMP_NUMBER(fabs(GET_NUMBER(finPos, ExtPos_Qty)), fabs(GET_NUMBER(initPos, ExtPos_Qty))) > 0)
		{
			/* Record pointers */
			swap        = accOpenPos;
			accOpenPos  = accClosePos;
			accClosePos = swap;

			/* Index pointers */
			int swapIdx = accOpenIdx;       /* REF5316 - 001017 - DED */
			accOpenIdx  = accCloseIdx;      /* REF5316 - 001017 - DED */
			accCloseIdx = swapIdx;          /* REF5316 - 001017 - DED */
		}

        /***** If splitting, "Free" account-close position by closing it and creating *****/
        /***** another without a reference.                           *****/
        if (MC_NoSplit == false)
        {
            /* Memory allocation */
            if ((freeAccClosePos = FUS_DynStDup(accClosePos, ctx)) == NULL)     /* PMSTA08746 - 061009 - PMO */
            {
                (void)MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "ExtPos");
                FUS_TraceEndFunction(ctx, functionName, TRUE, FALSE);           /* PMSTA-4559 - 011107 - PMO */
                return(RET_MEM_ERR_ALLOC);
            }

            /* Set various fields */
            SET_NULL_ID(freeAccClosePos, ExtPos_Id);
            SET_NULL_ID(freeAccClosePos, ExtPos_PosObjId);
            SET_NULL_CODE(freeAccClosePos, ExtPos_RefOpCd);
            SET_ENUM(freeAccClosePos, ExtPos_RefNatEn, PosRefNat_None);
            SET_ENUM(freeAccClosePos, ExtPos_PrimaryEn, PosPrimary_Derived);
        FIN_CopyOpenOpCdIdTimingRule(freeAccClosePos,finPos);
            SET_NULL_CODE(freeAccClosePos, ExtPos_RevOpCd);				/* REF5614 - 010209 - DED */
            SET_ENUM(freeAccClosePos, ExtPos_RevNatEn, PosRevNat_None);	/* REF5614 - 010209 - DED */
            SET_ENUM(freeAccClosePos, ExtPos_AdjustNatEn, OpAdjustNat_None);
            SET_NULL_ID(freeAccClosePos, ExtPos_CloseOpId);
            SET_NULL_CODE(freeAccClosePos, ExtPos_CloseOpCd);
            SET_NULL_DATETIME(freeAccClosePos, ExtPos_EndDate);
    
            /* REF3253 SME */
            if (swap)
            {
                SET_DATETIME(freeAccClosePos, ExtPos_BegDate, GET_DATETIME(mainPos, ExtPos_BegDate));
                SET_DATETIME(freeAccClosePos, ExtPos_OpDate,  GET_DATETIME(mainPos, ExtPos_OpDate));
                SET_DATETIME(freeAccClosePos, ExtPos_ValDate, GET_DATETIME(mainPos, ExtPos_ValDate));
                SET_DATETIME(freeAccClosePos, ExtPos_AcctDate,GET_DATETIME(mainPos, ExtPos_AcctDate));
                if (GET_INSTRNAT(freeAccClosePos, ExtPos_InstrNat) != InstrNat_CashAcct)              /* PMSTA-49587 - AIS - 220825 */
                {
                    SET_DATETIME(freeAccClosePos, ExtPos_AcquisitionDate, GET_DATETIME(mainPos, ExtPos_AcquisitionDate));
                    SET_DATETIME(freeAccClosePos, ExtPos_BusinessAcquisitionDate, GET_DATETIME(mainPos, ExtPos_BusinessAcquisitionDate));
                    SET_ID(freeAccClosePos, ExtPos_AcquisitionOpenOpId, GET_ID(mainPos, ExtPos_AcquisitionOpenOpId));
                }
            }

			/* Insert "free" position */
			FUS_TracePos( ctx, freeAccClosePos, "freeAccClosePos");   /* PMSTA-4559 - 011107 - PMO */
			if ((ret = FIN_InsertPos(ctx, freeAccClosePos, accCloseIdx, FALSE, FALSE, NULL)) != RET_SUCCEED)
			{
				FREE_DYNST(freeAccClosePos, ExtPos);
				FUS_TraceEndFunction(ctx, functionName, TRUE, FALSE); /* PMSTA-4559 - 011107 - PMO */
				return ret;
			}

			/* Save record pointer for later use */                         /* REF3929 - 990906 - DED */
			if (freeAccClose != NULL)
			{
				*freeAccClose = freeAccClosePos;
			}
		}

		/***** Close account-close position *****/              /* BUG504 - 970910 - DED */
		/* REF3253 SME */
		if (swap)
		{
			if ((ret = FIN_CloseExtPos(ctx, accClosePos, finPos, GET_DATETIME(finPos, ExtPos_BegDate))) != RET_SUCCEED)      /* REF4122 - 000406 - DED */
			{
				FUS_TraceEndFunction(ctx, functionName, TRUE, FALSE); /* PMSTA-4559 - 011107 - PMO */
				return(ret);
			}
		}
		else
		{
			if ((ret = FIN_CloseExtPos(ctx, accClosePos, finPos, GET_DATETIME(accClosePos, ExtPos_BegDate))) != RET_SUCCEED)      /* REF4122 - 000406 - DED */
			{
				FUS_TraceEndFunction(ctx, functionName, TRUE, FALSE); /* PMSTA-4559 - 011107 - PMO */
				return(ret);
			}
		}
		/* REF4122 -000406 - DED */
	}

    /* If force flag = TRUE and fact = 0, then compute fact between two instrument positions */
    if (forceFlg == TRUE && fact == 0.0)            /* REF3929 - 990908 - DED */    /* REF3819 - 000112 - DED */
    {
        if (CMP_NUMBER(qtyDiff, 0.0) > 0)
        {
            fact = 1 - fabs(GET_NUMBER(lowPos, ExtPos_Qty)/GET_NUMBER(highPos, ExtPos_Qty));
        }
        else if (CMP_NUMBER(qtyDiff, 0.0) < 0)
        {
            fact = 1 - fabs(GET_NUMBER(lowPos, ExtPos_Qty))/fabs(GET_NUMBER(highPos, ExtPos_Qty));
        }
        else
        {
            fact = 0.0;
        }
    }

    /***** Split account-open position into a account-open position (%) and the rest
           in a "free" account position.  If Margin Call and resulting quantity = 0, don't
           create a new extended position. *****/
    if (fact != 0.0)
    {
        /* Memory allocation */
        if ((newAccOpenPos = FUS_DynStDup(accOpenPos, ctx)) == NULL)    /* PMSTA08746 - 061009 - PMO */
        {
            (void)MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "ExtPos");
            FUS_TraceEndFunction(ctx, functionName, TRUE, FALSE);       /* PMSTA-4559 - 011107 - PMO */
            return(RET_MEM_ERR_ALLOC);
        }

        /* Set various fields */
        SET_NULL_ID(newAccOpenPos, ExtPos_Id);
        SET_NULL_ID(newAccOpenPos, ExtPos_PosObjId);

        if (  GET_POSREFNAT(newAccOpenPos, ExtPos_RefNatEn) == PosRefNat_FutFifo
           || GET_POSREFNAT(newAccOpenPos, ExtPos_RefNatEn) == PosRefNat_FutWMP
           || GET_POSREFNAT(newAccOpenPos, ExtPos_RefNatEn) == PosRefNat_FutContract                /* PMSTA-17898 - 160414 - PMO */
           )
        {
            /* code of highPos */
            FIN_CopyOpenOpCdIdTimingRule(newAccOpenPos,resPos);
        }
        else
        {
            FIN_CopyOpenOpCdIdTimingRule(newAccOpenPos,initPos);
        }

        /* PMSTA-4559 - 011107 - PMO */
        if (GET_POSREFNAT(mainPos, ExtPos_RefNatEn) == PosRefNat_FutWMP)
        {
            SET_ENUM(newAccOpenPos, ExtPos_RefNatEn, PosRefNat_FutWMP);
        }

        SET_NULL_ID(newAccOpenPos, ExtPos_CloseOpId);
        SET_NULL_CODE(newAccOpenPos, ExtPos_CloseOpCd);
        SET_NULL_DATETIME(newAccOpenPos, ExtPos_EndDate);
        SET_ENUM(newAccOpenPos, ExtPos_PrimaryEn, PosPrimary_Derived);
        SET_NULL_CODE(newAccOpenPos, ExtPos_RevOpCd);				/* REF5614 - 010209 - DED */
        SET_ENUM(newAccOpenPos, ExtPos_RevNatEn, PosRevNat_None);	/* REF5614 - 010209 - DED */
        SET_FLAG_FALSE(newAccOpenPos, ExtPos_MainFlg);
        SET_DATETIME(newAccOpenPos, ExtPos_BegDate, GET_DATETIME(mainPos, ExtPos_BegDate));
        SET_DATETIME(newAccOpenPos, ExtPos_OpDate,  GET_DATETIME(mainPos, ExtPos_OpDate));     /* BUG446 - 970729 - DED */
        SET_DATETIME(newAccOpenPos, ExtPos_ValDate, GET_DATETIME(mainPos, ExtPos_ValDate));    /* BUG446 - 970729 - DED */
        SET_DATETIME(newAccOpenPos, ExtPos_AcctDate,GET_DATETIME(mainPos, ExtPos_AcctDate));   /* BUG446 - 970729 - DED */
        SET_NUMBER(newAccOpenPos, ExtPos_Qty, CAST_NUMBER(fact * GET_NUMBER(accOpenPos, ExtPos_Qty)));
        SET_AMOUNT(newAccOpenPos, ExtPos_InstrGrossAmt,
                   CAST_AMOUNT(fact *
                               GET_AMOUNT(accOpenPos, ExtPos_InstrGrossAmt),
                               GET_ID(accOpenPos, ExtPos_InstrCurrId)));
        SET_AMOUNT(newAccOpenPos, ExtPos_InstrNetAmt,
                   CAST_AMOUNT(fact *
                               GET_AMOUNT(accOpenPos, ExtPos_InstrNetAmt),
                               GET_ID(accOpenPos, ExtPos_InstrCurrId)));
        SET_AMOUNT(newAccOpenPos, ExtPos_RefGrossAmt,
                   CAST_AMOUNT(fact *
                               GET_AMOUNT(accOpenPos, ExtPos_RefGrossAmt),
                               GET_ID(accOpenPos, ExtPos_RefCurrId)));
        SET_AMOUNT(newAccOpenPos, ExtPos_RefNetAmt,
                   CAST_AMOUNT(fact *
                               GET_AMOUNT(accOpenPos, ExtPos_RefNetAmt),
                               GET_ID(accOpenPos, ExtPos_RefCurrId)));
        SET_AMOUNT(newAccOpenPos, ExtPos_SysGrossAmt,
                   CAST_AMOUNT(fact *
                               GET_AMOUNT(accOpenPos, ExtPos_SysGrossAmt),
                               ctx->currPtfInfo->sysCurrId));
        SET_AMOUNT(newAccOpenPos, ExtPos_SysNetAmt,
                   CAST_AMOUNT(fact *
                               GET_AMOUNT(accOpenPos, ExtPos_SysNetAmt),
                               ctx->currPtfInfo->sysCurrId));
        SET_AMOUNT(newAccOpenPos, ExtPos_PosGrossAmt,
                   CAST_AMOUNT(fact *
                               GET_AMOUNT(accOpenPos, ExtPos_PosGrossAmt),
                               GET_ID(accOpenPos, ExtPos_PosCurrId)));
        SET_AMOUNT(newAccOpenPos, ExtPos_PosNetAmt,
                   CAST_AMOUNT(fact *
                               GET_AMOUNT(accOpenPos, ExtPos_PosNetAmt),
                               GET_ID(accOpenPos, ExtPos_PosCurrId)));
        for (i=0; i<ExtPos_BpPosAmtNb; i++)
        {
            SET_AMOUNT(newAccOpenPos, ExtPos_Bp1PosAmt+i,
                       CAST_AMOUNT(fact * GET_AMOUNT(accOpenPos,ExtPos_Bp1PosAmt+i),
                                   GET_ID(accOpenPos, ExtPos_PosCurrId)));
        }

        FIN_RoundAmount(newAccOpenPos, ExtPos_Qty, ExtPos_PosCurrId);   /* PMSTA08607 - 280909 - PMO */

        /* Insert new account-open position */
        FUS_TracePos( ctx, newAccOpenPos, "newAccOpenPos");   /* PMSTA-4559 - 011107 - PMO */
        if ((ret = FIN_InsertPos(ctx, newAccOpenPos, accOpenIdx, FALSE, FALSE, NULL)) != RET_SUCCEED)
        {
            FREE_DYNST(newAccOpenPos, ExtPos);
            FUS_TraceEndFunction(ctx, functionName, TRUE, FALSE); /* PMSTA-4559 - 011107 - PMO */
            return ret;
        }
    }

	/* PMSTA-51476 - DDV - 220112 - don't create freeAccOpenPos for SubNat_FXFwd_TwoLegsAgainsPtfCurr, accOpenPos will fuse in normal fusion process */
	if (GET_ENUM(ctx->posLogTypesTab[posLogTypesIdx].ptrInstrument, A_Instr_SubNatEn) != SubNat_FXFwd_TwoLegsAgainsPtfCurr)
	{
		if (MC_NoSplit == false)
		{
			/***** Create "free" position with rest of account-open position *****/
			/* Memory allocation */
			if ((freeAccOpenPos = FUS_DynStDup(accOpenPos, ctx)) == NULL)   /* PMSTA08746 - 061009 - PMO */
			{
				(void)MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "ExtPos");
				FUS_TraceEndFunction(ctx, functionName, TRUE, FALSE);       /* PMSTA-4559 - 011107 - PMO */
				return(RET_MEM_ERR_ALLOC);
			}

			SET_ENUM(freeAccOpenPos, ExtPos_RefNatEn, PosRefNat_None);
			/* Set various fields */
			SET_NULL_ID(freeAccOpenPos, ExtPos_Id);
			SET_NULL_ID(freeAccOpenPos, ExtPos_PosObjId);
			SET_NULL_CODE(freeAccOpenPos, ExtPos_RefOpCd);
			SET_NULL_CODE(freeAccOpenPos, ExtPos_RevOpCd);				/* REF5614 - 010209 - DED */
			SET_ENUM(freeAccOpenPos, ExtPos_RevNatEn, PosRevNat_None);	/* REF5614 - 010209 - DED */
                        FIN_CopyOpenOpCdIdTimingRule(freeAccOpenPos,finPos);
			COPY_DYNFLD(freeAccOpenPos, ExtPos, ExtPos_OpenOpNatEn, finPos, ExtPos, ExtPos_OpenOpNatEn);    /* REF1712 - 980428 - DED */
			SET_NULL_ID(freeAccOpenPos, ExtPos_CloseOpId);
			SET_NULL_CODE(freeAccOpenPos, ExtPos_CloseOpCd);
			SET_NULL_DATETIME(freeAccOpenPos, ExtPos_EndDate);
			if (GET_ENUM(mainPos, ExtPos_AdjustNatEn) == OpAdjustNat_MarginCall)
			{
				SET_ENUM(freeAccOpenPos, ExtPos_PrimaryEn, PosPrimary_Second);
			}
			else
			{
				SET_ENUM(freeAccOpenPos, ExtPos_PrimaryEn, PosPrimary_Derived);
			}
			SET_FLAG_FALSE(freeAccOpenPos, ExtPos_MainFlg);
			SET_ENUM(freeAccOpenPos, ExtPos_PosNatEn, PosNat_None);

			/* BUG403 - 970708 - DED / DVP355 - 970311 - PEC / DVP355 - 970311 - PEC */

			SET_DATETIME(freeAccOpenPos, ExtPos_BegDate, GET_DATETIME(mainPos, ExtPos_BegDate));
			SET_DATETIME(freeAccOpenPos, ExtPos_OpDate,  GET_DATETIME(mainPos, ExtPos_OpDate));     /* BUG446 - 970729 - DED */
			SET_DATETIME(freeAccOpenPos, ExtPos_ValDate, GET_DATETIME(mainPos, ExtPos_ValDate));    /* BUG446 - 970729 - DED */
			SET_DATETIME(freeAccOpenPos, ExtPos_AcctDate,GET_DATETIME(mainPos, ExtPos_AcctDate));   /* BUG446 - 970729 - DED */

			/* Compute amounts by difference */             /* REF906 - 971113 - DED */

			if (newAccOpenPos != NULL)                                 /* REF1328 - 980224 - SME  */
			{
				SET_NUMBER(freeAccOpenPos, ExtPos_Qty,
					CAST_NUMBER(GET_NUMBER(accOpenPos, ExtPos_Qty) - GET_NUMBER(newAccOpenPos, ExtPos_Qty)));
				SET_AMOUNT(freeAccOpenPos, ExtPos_InstrGrossAmt,
					CAST_AMOUNT(GET_AMOUNT(accOpenPos, ExtPos_InstrGrossAmt) - GET_AMOUNT(newAccOpenPos, ExtPos_InstrGrossAmt),
						GET_ID(accOpenPos, ExtPos_InstrCurrId)));
				SET_AMOUNT(freeAccOpenPos, ExtPos_InstrNetAmt,
					CAST_AMOUNT(GET_AMOUNT(accOpenPos, ExtPos_InstrNetAmt) - GET_AMOUNT(newAccOpenPos, ExtPos_InstrNetAmt),
						GET_ID(accOpenPos, ExtPos_InstrCurrId)));
				SET_AMOUNT(freeAccOpenPos, ExtPos_RefGrossAmt,
					CAST_AMOUNT(GET_AMOUNT(accOpenPos, ExtPos_RefGrossAmt) - GET_AMOUNT(newAccOpenPos, ExtPos_RefGrossAmt),
						GET_ID(accOpenPos, ExtPos_RefCurrId)));
				SET_AMOUNT(freeAccOpenPos, ExtPos_RefNetAmt,
					CAST_AMOUNT(GET_AMOUNT(accOpenPos, ExtPos_RefNetAmt) - GET_AMOUNT(newAccOpenPos, ExtPos_RefNetAmt),
						GET_ID(accOpenPos, ExtPos_RefCurrId)));
				SET_AMOUNT(freeAccOpenPos, ExtPos_SysGrossAmt,
					CAST_AMOUNT(GET_AMOUNT(accOpenPos, ExtPos_SysGrossAmt) - GET_AMOUNT(newAccOpenPos, ExtPos_SysGrossAmt),
						ctx->currPtfInfo->sysCurrId));
				SET_AMOUNT(freeAccOpenPos, ExtPos_SysNetAmt,
					CAST_AMOUNT(GET_AMOUNT(accOpenPos, ExtPos_SysNetAmt) - GET_AMOUNT(newAccOpenPos, ExtPos_SysNetAmt),
						ctx->currPtfInfo->sysCurrId));
				SET_AMOUNT(freeAccOpenPos, ExtPos_PosGrossAmt,
					CAST_AMOUNT(GET_AMOUNT(accOpenPos, ExtPos_PosGrossAmt) - GET_AMOUNT(newAccOpenPos, ExtPos_PosGrossAmt),
						GET_ID(accOpenPos, ExtPos_PosCurrId)));
				SET_AMOUNT(freeAccOpenPos, ExtPos_PosNetAmt,
					CAST_AMOUNT(GET_AMOUNT(accOpenPos, ExtPos_PosNetAmt) - GET_AMOUNT(newAccOpenPos, ExtPos_PosNetAmt),
						GET_ID(accOpenPos, ExtPos_PosCurrId)));
				for (i=0; i<ExtPos_BpPosAmtNb; i++)
				{
					SET_AMOUNT(freeAccOpenPos, ExtPos_Bp1PosAmt+i,
						CAST_AMOUNT(GET_AMOUNT(accOpenPos,ExtPos_Bp1PosAmt+i) - GET_AMOUNT(newAccOpenPos,ExtPos_Bp1PosAmt+i),
							GET_ID(accOpenPos, ExtPos_PosCurrId)));
				}

				FIN_RoundAmount(freeAccOpenPos, ExtPos_Qty, ExtPos_PosCurrId);  /* PMSTA08607 - 280909 - PMO */
			}

			/* Insert "free" position */
			FUS_TracePos( ctx, freeAccOpenPos, "freeAccOpenPos");   /* PMSTA-4559 - 011107 - PMO */
			if ((ret = FIN_InsertPos(ctx, freeAccOpenPos, accOpenIdx, FALSE, FALSE, NULL)) != RET_SUCCEED)
			{
				FREE_DYNST(freeAccOpenPos, ExtPos);
				FUS_TraceEndFunction(ctx, functionName, TRUE, FALSE); /* PMSTA-4559 - 011107 - PMO */
				return ret;
			}

			/* Save record pointer for later use */                         /* REF3929 - 990906 - DED */
			if (freeAccOpen != NULL)
			{
				*freeAccOpen = freeAccOpenPos;
			}
		}

		/***** Close account-open position *****/   /* BUG446 - 970729 - DED */ /* BUG504 - 970910 - DED */
		if ((ret = FIN_CloseExtPos(ctx, accOpenPos, finPos, GET_DATETIME(finPos, ExtPos_BegDate))) != RET_SUCCEED)      /* REF4122 - 000406 - DED */
		{
			FUS_TraceEndFunction(ctx, functionName, TRUE, FALSE); /* PMSTA-4559 - 011107 - PMO */
			return(ret);
		}
		/* REF4122 -000406 - DED : replaced by function */
	}

    /* Don't free freeAccOpenPos !! Will be freed by fin_freefuscontext */

    /************************************************************************************************/
    /* Because the following part is a little complicated, these are the following steps performed: */
    /*                                                                                              */
    /*  1. check if we must fuse the two "free" cash positions (check system parameters             */
    /*     FORWARD_CLOSE_FLAG, ...). For Margin Calls, we always fuse if fusionnable.               */
    /*  2. if so, fuse two cash positions and save the eventually generated G/L bal. position       */
    /*  3. affect generated capital G/L to the instrument (change instrId and instrCurrId)          */
    /*  4. if an instrument G/L balance positions exists (due to fusion of two instrument           */
    /*     positions), we have to fuse the instrument and the cash G/L balance position.            */
    /*  5. determine the balance position type (gain or loss) of future resulting bal. position     */
    /*  6. force the bal. position type to the founded type in order to fuse the two G/L.           */
    /*     So even two G/L with a different type (gain and loss) will fuse together.                */
    /*  7. Create a copy of the changed capital G/L into context's correct logical type.   This     */
    /*     is necessary because the instrument has changed and the record doesn't belong any-       */
    /*     more to the correct logical type                                                         */
    /*  8. if fusionnable, fuse instrument and cash G/L balance positions                           */
    /*  9. restore original balance position types (gain or loss) (cfr. step 6)                     */
    /*     10. set primary_n of resulting G/L to 2 (=secondary).                                    */
    /*     11. repeat the steps 3-10 for the exchange G/L                                           */
    /*                                                                                              */
    /* By performing these steps, there remains only ONE capital and ONE exchange G/L balance       */
    /* position for the whole forward-fusion process.                                               */
    /************************************************************************************************/

    /* If no splitting, there is no fusion of the free cash positions.  Just copy the account 2
       close position and exit the function. */
    if (MC_NoSplit == true)
    {
        /* Copy of account 2 position */
        /* Memory allocation */
        if ((newAcc2ClosePos = FUS_DynStDup(acc2ClosePos, ctx)) == NULL)    /* PMSTA08746 - 061009 - PMO */
        {
           (void)MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "ExtPos");
            FUS_TraceEndFunction(ctx, functionName, TRUE, FALSE);           /* PMSTA-4559 - 011107 - PMO */
            return(RET_MEM_ERR_ALLOC);
        }

        /* Set copy of account 2 Pos to "open" and no Margin Call */
        SET_NULL_ID(newAcc2ClosePos, ExtPos_Id);
        SET_NULL_ID(newAcc2ClosePos, ExtPos_PosObjId);
        SET_NULL_CODE(newAcc2ClosePos, ExtPos_RefOpCd);
        SET_ENUM(newAcc2ClosePos, ExtPos_RefNatEn, PosRefNat_None);
        SET_NULL_ID(newAcc2ClosePos, ExtPos_CloseOpId);
        SET_NULL_CODE(newAcc2ClosePos, ExtPos_CloseOpCd);
        SET_NULL_DATETIME(newAcc2ClosePos, ExtPos_EndDate);
        SET_ENUM(newAcc2ClosePos, ExtPos_AdjustNatEn, OpAdjustNat_None);
        SET_ENUM(newAcc2ClosePos, ExtPos_PrimaryEn, PosPrimary_Second);     /* REF2038 - 980610 - DED */
        SET_NULL_CODE(newAcc2ClosePos, ExtPos_RevOpCd);				/* REF5614 - 010209 - DED */
        SET_ENUM(newAcc2ClosePos, ExtPos_RevNatEn, PosRevNat_None);	/* REF5614 - 010209 - DED */

        /* Insert new account 2 position */
        FUS_TracePos( ctx, newAcc2ClosePos, "newAcc2ClosePos");   /* PMSTA-4559 - 011107 - PMO */
        if ((ret = FIN_InsertPos(ctx, newAcc2ClosePos, acc2CloseIdx, FALSE,FALSE, NULL)) == RET_SUCCEED)
        {
            /* Close account2-close position */         /* BUG504 - 970910 - DED */
            ret = FIN_CloseExtPos(ctx, acc2ClosePos, finPos, GET_DATETIME(acc2ClosePos, ExtPos_BegDate));
        }
        else
        {
            FREE_DYNST(newAcc2ClosePos, ExtPos);
        }
    }
    else
    {
        /***** Check if we have to fuse the two "free" cash-positions *****/
        /* Initializations */

        DATETIME_T  maxDateTime         = {0,0};
        DATETIME_T  savedCtxTodayDate   = {0,0};
        FLAG_T      cashValueDateFlg    = FALSE;    /* PMSTA-6328 - 060808 - PMO */
        bool        fusInFutureFlg      = false;
        bool        bProcessing         = false;    /* Standard processing PMSTA-5595 - 250608 - PMO */
        bool        explfusion          = false;

        switch(GET_ENUM(mainPos, ExtPos_RefNatEn))
        {
            case PosRefNat_FwdClose :
                {
                    /* If system parameter fwdCloseFlg is on, check if we can fuse the two positions */
                    bProcessing = (ctx->fwdCloseFlg == TRUE || GET_ENUM(mainPos, ExtPos_AdjustNatEn) == OpAdjustNat_MarginCall);

                    DBA_DYNFLD_STP  cashPos = FUS_DynStDup(accOpenPos, ctx);    /* PMSTA-21380 - 070915 - PMO */
                    if(NULL != cashPos)
                    {
                        SET_ENUM(cashPos, ExtPos_PrimaryEn, PosPrimary_Second);
                        SET_ENUM(cashPos, ExtPos_RefNatEn,  PosRefNat_None);

                        COPY_DYNFLD(cashPos, ExtPos, ExtPos_BegDate , mainPos, ExtPos, ExtPos_BegDate);
                        COPY_DYNFLD(cashPos, ExtPos, ExtPos_EndDate , mainPos, ExtPos, ExtPos_EndDate);
                        COPY_DYNFLD(cashPos, ExtPos, ExtPos_OpDate  , mainPos, ExtPos, ExtPos_OpDate);
                        COPY_DYNFLD(cashPos, ExtPos, ExtPos_AcctDate, mainPos, ExtPos, ExtPos_AcctDate);
                        COPY_DYNFLD(cashPos, ExtPos, ExtPos_ValDate , mainPos, ExtPos, ExtPos_ValDate);

                        FIN_CopyOpenOpCdIdTimingRule(cashPos,mainPos);
                        COPY_DYNFLD(cashPos, ExtPos, ExtPos_OpenOpNatEn, mainPos, ExtPos, ExtPos_OpenOpNatEn);

						/* PMSTA_51476 - DDV - 221214 - Create two new Secondary positions */
						if (GET_ENUM(ctx->posLogTypesTab[posLogTypesIdx].ptrInstrument, A_Instr_SubNatEn) == SubNat_FXFwd_TwoLegsAgainsPtfCurr)
						{
                            SET_ENUM(cashPos, ExtPos_PosNatEn, PosNat_FXFwd_TwoLegsAgainsPtfCurr);
							SET_ENUM(cashPos, ExtPos_RefNatEn, PosRefNat_FwdClose);
							SET_ENUM(cashPos, ExtPos_FusStateEn, FusState_Opened);
							COPY_DYNFLD(cashPos, ExtPos, ExtPos_RefOpCd, accOpenPos, ExtPos, ExtPos_OpenOpCd);

							PRICE_T            price = 0.0;

							price = GET_EXCHANGE(mainPos, ExtPos_InstrExchRate);

							SET_PRICE(cashPos, ExtPos_Price, price);
							SET_PRICE(cashPos, ExtPos_SpotPrice, price);
							SET_PRICE(cashPos, ExtPos_Quote, price);
							SET_PRICE(cashPos, ExtPos_SpotQuote, price);

							NUMBER_T   qty = -1.0 * GET_NUMBER(accOpenPos, ExtPos_Qty);

							SET_NUMBER(cashPos, ExtPos_Qty, qty);

							AMOUNT_T  amt = 0.0, posAmt = 0.0, instrAmt = 0.0, ptfAmt = 0.0, sysAmt = 0.0;

							amt = GET_PRICE(cashPos, ExtPos_Price) * GET_NUMBER(cashPos, ExtPos_Qty);

							posAmt = CAST_AMOUNT(amt, GET_ID(cashPos, ExtPos_PosCurrId));

							SET_AMOUNT(cashPos, ExtPos_PosNetAmt, posAmt);
							SET_AMOUNT(cashPos, ExtPos_PosGrossAmt, posAmt);

							SET_EXCHANGE(cashPos, ExtPos_PosExchRate, 1.0);

							ptfAmt = posAmt;

							SET_AMOUNT(cashPos, ExtPos_RefNetAmt, ptfAmt);
							SET_AMOUNT(cashPos, ExtPos_RefGrossAmt, ptfAmt);

							COPY_DYNFLD(cashPos, ExtPos, ExtPos_InstrExchRate, mainPos, ExtPos, ExtPos_InstrExchRate);

							instrAmt = amt * GET_EXCHANGE(cashPos, ExtPos_PosExchRate);
							instrAmt /= GET_EXCHANGE(cashPos, ExtPos_InstrExchRate);
							instrAmt = CAST_AMOUNT(instrAmt, GET_ID(cashPos, ExtPos_InstrCurrId));

							SET_AMOUNT(cashPos, ExtPos_InstrNetAmt, instrAmt);
							SET_AMOUNT(cashPos, ExtPos_InstrGrossAmt, instrAmt);

                            COPY_DYNFLD(cashPos, ExtPos, ExtPos_SysExchRate, mainPos, ExtPos, ExtPos_SysExchRate);

                            sysAmt = amt * GET_EXCHANGE(cashPos, ExtPos_PosExchRate);
                            sysAmt /= GET_EXCHANGE(cashPos, ExtPos_SysExchRate);
                            sysAmt = CAST_AMOUNT(sysAmt, ctx->currPtfInfo->sysCurrId);

                            SET_AMOUNT(cashPos, ExtPos_SysNetAmt, sysAmt);
                            SET_AMOUNT(cashPos, ExtPos_SysGrossAmt, sysAmt);

                            DBA_DYNFLD_STP  cashPos2 = FUS_DynStDup(cashPos, ctx);

							if (NULL != cashPos2)
							{
								/* set instrument and pos currency Id*/
								{
                                    if (GET_ID(mainPos, ExtPos_OpenOpId) > 0)
                                    {
                                        MemoryPool mp;
                                        DBA_DYNFLD_STP sOp = mp.allocDynst(FILEINFO, S_Op);
                                        DBA_DYNFLD_STP aOp = mp.allocDynst(FILEINFO, A_Op);

                                        SET_ID(sOp, S_Op_Id, GET_ID(mainPos, ExtPos_OpenOpId));


                                        if (ctx->getDbiConnectionHelper().dbaGet(Op, UNUSED, sOp, &aOp) == RET_SUCCEED)
                                        {
                                            COPY_DYNFLD(cashPos2, ExtPos, ExtPos_InstrId, aOp, A_Op, A_Op_Acc2InstrId);
                                        }
                                    }
                                    else
                                    {
                                        DBA_DYNFLD_STP aOp = NULLDYNST;

                                        /* PMSTA-52091 - 230227 - DDV - If operation id is negative, fusion is call by journal. Then search op in hierarchy */
                                        DBA_GetRecPtrFromHierById(ctx->extposHier, GET_ID(mainPos, ExtPos_OpenOpId), A_Op, &aOp);

                                        if (aOp != NULLDYNST)
                                        {
                                            COPY_DYNFLD(cashPos2, ExtPos, ExtPos_InstrId, aOp, A_Op, A_Op_Acc2InstrId);
                                        }
                                    }

                                    /* PMSTA-65162 - JBC - 20250122 */
                                    if(IS_NULLFLD(cashPos,ExtPos_InstrId) || IS_NULLFLD(cashPos2,ExtPos_InstrId))
                                    {   
	                                    (void)MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, SYS_Stringer("Forward operation ",GET_CODE(cashPos,ExtPos_OpenOpCd)," requires two accounts.").c_str());
                                        FREE_DYNST(cashPos, ExtPos);
	                                    FREE_DYNST(cashPos2, ExtPos);
										FUS_TraceEndFunction(ctx, functionName, TRUE, FALSE);
										return RET_GEN_ERR_PERSONAL;
                                    }
                                   
								}

								SET_ENUM(cashPos2, ExtPos_RefNatEn, PosRefNat_None);

								COPY_DYNFLD(cashPos2, ExtPos, ExtPos_PosCurrId, mainPos, ExtPos, ExtPos_InstrCurrId);

								SET_NUMBER(cashPos2, ExtPos_Qty, -1.0 * GET_NUMBER(cashPos, ExtPos_Qty));

								price = 1.0;

								SET_PRICE(cashPos2, ExtPos_Price, price);
								SET_PRICE(cashPos2, ExtPos_SpotPrice, price);
								SET_PRICE(cashPos2, ExtPos_Quote, price);
								SET_PRICE(cashPos2, ExtPos_SpotQuote, price);

								amt = posAmt = instrAmt = ptfAmt = 0.0;

								amt = GET_PRICE(cashPos2, ExtPos_Price) * GET_NUMBER(cashPos2, ExtPos_Qty);

								posAmt = CAST_AMOUNT(amt, GET_ID(cashPos2, ExtPos_PosCurrId));

								SET_AMOUNT(cashPos2, ExtPos_PosNetAmt, posAmt);
								SET_AMOUNT(cashPos2, ExtPos_PosGrossAmt, posAmt);

								COPY_DYNFLD(cashPos2, ExtPos, ExtPos_PosExchRate, mainPos, ExtPos, ExtPos_InstrExchRate);

								amt *= GET_EXCHANGE(cashPos2, ExtPos_PosExchRate);
								ptfAmt = CAST_AMOUNT(amt, GET_ID(cashPos2, ExtPos_RefCurrId));

								SET_AMOUNT(cashPos2, ExtPos_RefNetAmt, ptfAmt);
								SET_AMOUNT(cashPos2, ExtPos_RefGrossAmt, ptfAmt);

								COPY_DYNFLD(cashPos2, ExtPos, ExtPos_InstrExchRate, mainPos, ExtPos, ExtPos_InstrExchRate);

								amt /= GET_EXCHANGE(cashPos2, ExtPos_InstrExchRate);
								instrAmt = CAST_AMOUNT(amt, GET_ID(cashPos2, ExtPos_InstrCurrId));

								SET_AMOUNT(cashPos2, ExtPos_InstrNetAmt, instrAmt);
								SET_AMOUNT(cashPos2, ExtPos_InstrGrossAmt, instrAmt);

								/* insert both positions */
								if ((ret = FIN_InsertPos(ctx, cashPos, NO_VALUE, FALSE, FALSE, NULL)) != RET_SUCCEED)
								{ /* Error */
									FREE_DYNST(cashPos, ExtPos);
                                    FREE_DYNST(cashPos2, ExtPos);
									FUS_TraceEndFunction(ctx, functionName, TRUE, FALSE);
									return ret;
								}

								if ((ret = FIN_InsertPos(ctx, cashPos2, NO_VALUE, FALSE, FALSE, NULL)) != RET_SUCCEED)
								{ /* Error */
									FREE_DYNST(cashPos2, ExtPos);
									FUS_TraceEndFunction(ctx, functionName, TRUE, FALSE);
									return ret;
								}

								/* For SubNat_FXFwd_TwoLegsAgainsPtfCurr, everything is done, standard fusion process will handle them */
								FUS_TraceEndFunction(ctx, functionName, TRUE, FALSE); 
								return(RET_SUCCEED);
							}
						}

						FIN_ClosePosItself(cashPos);

                        /* Insert new account 1 "negative balance" position */
                        if ((ret = FIN_InsertPos(ctx, cashPos, NO_VALUE, FALSE,FALSE, NULL)) != RET_SUCCEED)
                        { /* Error */
                            FREE_DYNST(cashPos, ExtPos);
                            FUS_TraceEndFunction(ctx, functionName, TRUE, FALSE);
                            return ret;
                        }
                    }
                    else
                    { /* Error */
                       (void)MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "ExtPos");
                        FUS_TraceEndFunction(ctx, functionName, TRUE, FALSE);
                        return(RET_MEM_ERR_ALLOC);
                    }
                }
                break;

            case PosRefNat_TermClose :
                /* If system parameter termCloseFlg is on, check if we can fuse the two positions */
                bProcessing = (ctx->termCloseFlg == TRUE || GET_ENUM(mainPos, ExtPos_AdjustNatEn) == OpAdjustNat_MarginCall);
                break;

            case PosRefNat_FRAClose :   /* DVP440 */
            case PosRefNat_SwapClose:
            case PosRefNat_FXSwapClose:
            case PosRefNat_FutClose :   /* PMSTA-4973 - 220108 - PMO */
            case PosRefNat_FutFifo :
            case PosRefNat_FutWMP  :    /* PMSTA-4559 - 011107 - PMO */
            case PosRefNat_FutContract: /* PMSTA-17898 - 160414 - PMO */
                /* If system parameter futCloseFlg is on, check if we can fuse the two positions */
                bProcessing = (ctx->futCloseFlg == TRUE || GET_ENUM(mainPos, ExtPos_AdjustNatEn) == OpAdjustNat_MarginCall);
        }

        if (true == bProcessing)
        {
            if (FIN_PosFusionnable(ctx, posLogTypesIdx, freeAccOpenPos, freeAccClosePos, extPosType, PtfFusRule_WMP) == Fin_Pos_FusOk)    /* DVP549 - 970805 - DED *//*REF10256-EFE-041116*/
            {
                explfusion = true;
            }
            else
            {
                /* PMSTA02926 : special case op date is different from val date.
                    We try to fuse in the future
                    then after we put back the right value into the context.*/
                if ( DATE_Cmp(GET_DATE(freeAccOpenPos,  ExtPos_ValDate),ctx->today.date) > 0 ||
                     DATE_Cmp(GET_DATE(freeAccClosePos, ExtPos_ValDate),ctx->today.date) > 0 )
                {
                    maxDateTime = DATE_GetMaxDatetime( GET_DATETIME(freeAccOpenPos,  ExtPos_ValDate),
                                                       GET_DATETIME(freeAccClosePos, ExtPos_ValDate) );
                    savedCtxTodayDate       = ctx->today ;
                    ctx->today              = maxDateTime;
                    cashValueDateFlg        = ctx->cashValueDateFlg;
                    ctx->cashValueDateFlg   = FALSE;  /* This system parameter create side effect in this case */
                    fusInFutureFlg          = true;   /* PMSTA-3257 - 170707 - PMO */

                    if (FIN_PosFusionnable(ctx, posLogTypesIdx, freeAccOpenPos, freeAccClosePos, extPosType, PtfFusRule_WMP) == Fin_Pos_FusOk)    /* DVP549 - 970805 - DED *//*REF10256-EFE-041116*/
                    {
                        explfusion = true;
                    }
                }
            } /* else FIN_PosFusionnable */
        }


        DBA_DYNFLD_STP initFeesPosSaved = NULL; /* PMSTA-9072 - 050510 - PMO */
        DBA_DYNFLD_STP initFeesPos      = NULL; /* PMSTA-9072 - 050510 - PMO */

        /***** If fusion requested, go on processing *****/
        /*<PMSTA02926-EFE-070703*/
        if (explfusion == true)
        {
            if (true == bOpWithAnotherCurrencyThanPtf)
            {
                initFeesPos = FUS_SearchFeesRatePos(ctx, GET_ID(initPos, ExtPos_OpenOpId));     /* PMSTA-9072 - 050510 - PMO */
            }

            if (NULL != initFeesPos)
            { /* PMSTA-9072 - 050510 - PMO */
                initFeesPosSaved = FUS_DynStDup(initFeesPos, ctx);
            }

            ret = FIN_FusFreeCashPos (
              ctx                    ,
              mainPos                ,
              newMainPos             ,				/* PMSTA08607 - 280909 - PMO */
              freeAccOpenPos         ,
              freeAccClosePos        ,
              newAccClosePos         ,				/* PMSTA08607 - 280909 - PMO */
              cashCapGLBPos          ,
              cashExchGLBPos         ,
              accOpenPos             ,
              newAccOpenPos          ,              /* PMSTA-9072 - 050510 - PMO */
              accClosePos            ,
              acc2ClosePosDerived    ,
              acc2ClosePos           ,
              newAcc2ClosePos        ,
              highPos                ,				/* PMSTA08746 - 061009 - PMO */
              finPos                 ,
              adjPos                 ,
              initPos                ,
              pos2                   ,
              resPos                 ,				/* PMSTA08746 - 061009 - PMO */
              lowPos                 ,
              instrCapGLBPos         ,
              instrExchGLBPos        ,
              acc2ClosePosDerivedIdx ,
              fact                   ,
              saveResPosOpenOperId   ,
              saveResPosBeginDate    ,
              saveResPosOpenOperCode ,
              posLogTypesIdx         ,
              acc2CloseIdx           ,				/* PMSTA-3257 - 170707 - PMO */
              fusInFutureFlg         ,				/* PMSTA-6328 - 060808 - PMO */
              cashValueDateFlg       ,				/* PMSTA-6328 - 060808 - PMO */
              mergeCaseFusFlag       ,				/* PMSTA-6921 - 311008 - PMO */
              bOpWithAnotherCurrencyThanPtf			/* PMSTA08746 - 061009 - PMO */
              );
        }
        else
        {
            bool closePos2Account2Flag = false;

            /* PMSTA-6924 - 280109 - PMO */
            if (PosRefNat_FwdClose == GET_POSREFNAT(mainPos, ExtPos_RefNatEn) &&
                FALSE == IS_NULLFLD(mainPos, ExtPos_CashPortfolioId))
            {
                ret = FIN_ForwardCashPortfolioProcessing(ctx,
                                                         mainPos,
                                                         freeAccOpenPos,
                                                         freeAccClosePos,
                                                         resPos,
                                                         posLogTypesIdx,
                                                         mergeCaseFusFlag
                                                         );

                if (RET_SUCCEED == ret)
                {
                    FIN_OpPurgeOldSecondaryPosition(ctx, finPos);
                    ret = FIN_CashPortfolioCleanupOldPosition(*ctx, finPos);
                }

                if (RET_SUCCEED == ret && false == FIN_IsCashFlagDisabled(ctx, posLogTypesIdx))
                {
                    switch(ctx->applAdjCashNeutEnum)
                    {
                        case CashAdjNeut_Pos:
                        case CashAdjNeut_None:
                            /* Close also the acc2 of the mainPos */
                            FIN_ClosePosItself(acc2ClosePos);

                            if (FALSE == IS_NULLFLD((*pos2), ExtPos_CashPortfolioId))
                            {
                                /* Close also the acc2 of the finPos */
                                closePos2Account2Flag = true;
                            }
                            break;

                        default:
                            break;
                    }
                }
            }
            else
            {
                /* When only the forward open operation have a cash portfolio */
                if (PosRefNat_FwdOpen == GET_POSREFNAT(*pos2, ExtPos_RefNatEn) &&
                    FALSE == IS_NULLFLD(*pos2, ExtPos_CashPortfolioId))
                {
                    switch(ctx->applAdjCashNeutEnum)
                    {
                        case CashAdjNeut_Pos:
                            /* PMSTA08471 - 280709 - PMO */
                            if (false == FIN_IsCashFlagDisabled(ctx, posLogTypesIdx))
                            {
                                /* Close also the acc2 of the finPos */
                                closePos2Account2Flag = true;
                            }
                            break;

                        case CashAdjNeut_None:
                            /* Close also the acc2 of the finPos */
                            closePos2Account2Flag = true;
                            break;

                        default:
                            break;
                    }
                }
            }

            if (true == closePos2Account2Flag)
            {
                /*
                 * Close also the acc2 of the finPos
                 */
                if (PosPrimary_Primary == GET_POSPRIMARY(mainPos, ExtPos_PrimaryEn))                            /* PMSTA-9072 - 050510 - PMO */
                {
                    FIN_LOG_TYPE_STP    pPosLogTypes;                                                           /* PMSTA-17020 - 021013 - PMO */
                    int                 posNb;                                                                  /* PMSTA-17020 - 021013 - PMO */
                    bool                bLoop                = true;
                    const DATATYPE_ENUM ExtPos_OpenOpCd_Type = GET_FLD_TYPE(ExtPos, ExtPos_OpenOpCd);           /* PMSTA-17020 - 021013 - PMO */

                    for (i = 0; i < ctx->posLogTypesNb && true == bLoop; i++)
                    {
                        pPosLogTypes = &ctx->posLogTypesTab[i];
                        posNb        = pPosLogTypes->posNb;

                        if (posNb && FIN_CommonLogIdCmp(*pos2, pPosLogTypes->posTab[0]) != 0)
                            continue;

                        for (j = 0; j < posNb && true == bLoop; j++)
                        {
                            currPos = pPosLogTypes->posTab[j];

                            if (FusState_Opened     == (POSFUSSTATE_ENUM)GET_ENUM(currPos, ExtPos_FusStateEn)
                               &&PosPrimary_Primary == GET_POSPRIMARY(currPos, ExtPos_PrimaryEn)                /* PMSTA-9072 - 050510 - PMO */
                               &&PosNat_Acct2Pos    == (POSNAT_ENUM)GET_ENUM(currPos, ExtPos_PosNatEn)
                               &&0                  == CMP_DYNFLD((*pos2),   currPos, ExtPos_OpenOpCd, ExtPos_OpenOpCd, ExtPos_OpenOpCd_Type)
                               )
                            {
                                FIN_ClosePosItself(currPos);
                                bLoop = false;
                            }
                        }
                    }
                }
            }
        }

        if ( RET_SUCCEED == ret )
        {
            ret = FIN_FeesInOpWithAnotherCurrencyThanPtf(ctx, mainPos, newMainPos, pos2, resPos, bOpWithAnotherCurrencyThanPtf);

            if (NULL != initFeesPosSaved)
            { /* PMSTA-9072 - 050510 - PMO */
                FIN_CopyAmountsPosition(initFeesPos, initFeesPosSaved);
            }
        }

        FREE_DYNST(initFeesPosSaved, ExtPos);

        if (true  == fusInFutureFlg)
        {
            /* restore ctx->today's and cashValueDateFlg value */
            ctx->today            = savedCtxTodayDate ;
            ctx->cashValueDateFlg = cashValueDateFlg  ;
        }
        /*>PMSTA02926-EFE-070703*/

        /* Tests for adjustment Margin Calls / PMSTA-9072 - 050510 - PMO / PMSTA-5595 - 250608 - PMO */
        if (RET_SUCCEED == ret && GET_OPADJUSTNAT(mainPos, ExtPos_AdjustNatEn) == OpAdjustNat_MarginCall)
        { /* In this case some fields of adjPos must be updated */
            DBA_InverseSign(*pos2);     /* Change the sign */

            COPY_DYNFLD(adjPos, ExtPos, ExtPos_Qty,   *pos2, ExtPos, ExtPos_Qty);

            DBA_InverseSign(*pos2);     /* Restore the sign */

            DBA_InverseSign(mainPos);   /* Change the sign  */

            COPY_DYNFLD(adjPos, ExtPos, ExtPos_PosNetAmt       , mainPos, ExtPos, ExtPos_PosNetAmt);
            COPY_DYNFLD(adjPos, ExtPos, ExtPos_PosGrossAmt     , mainPos, ExtPos, ExtPos_PosGrossAmt);
            COPY_DYNFLD(adjPos, ExtPos, ExtPos_InstrGrossAmt   , mainPos, ExtPos, ExtPos_InstrGrossAmt);
            COPY_DYNFLD(adjPos, ExtPos, ExtPos_InstrNetAmt     , mainPos, ExtPos, ExtPos_InstrNetAmt);
            COPY_DYNFLD(adjPos, ExtPos, ExtPos_RefGrossAmt     , mainPos, ExtPos, ExtPos_RefGrossAmt);
            COPY_DYNFLD(adjPos, ExtPos, ExtPos_RefNetAmt       , mainPos, ExtPos, ExtPos_RefNetAmt);
            COPY_DYNFLD(adjPos, ExtPos, ExtPos_SysGrossAmt     , mainPos, ExtPos, ExtPos_SysGrossAmt);
            COPY_DYNFLD(adjPos, ExtPos, ExtPos_SysNetAmt       , mainPos, ExtPos, ExtPos_SysNetAmt);
            COPY_DYNFLD(adjPos, ExtPos, ExtPos_BookPosNetAmt   , mainPos, ExtPos, ExtPos_BookPosNetAmt);
            COPY_DYNFLD(adjPos, ExtPos, ExtPos_BookInstrNetAmt , mainPos, ExtPos, ExtPos_BookInstrNetAmt);
            COPY_DYNFLD(adjPos, ExtPos, ExtPos_BookRefNetAmt   , mainPos, ExtPos, ExtPos_BookRefNetAmt);
            COPY_DYNFLD(adjPos, ExtPos, ExtPos_BookSysNetAmt   , mainPos, ExtPos, ExtPos_BookSysNetAmt);
            COPY_DYNFLD(adjPos, ExtPos, ExtPos_SupplAmt        , mainPos, ExtPos, ExtPos_SupplAmt);
            COPY_DYNFLD(adjPos, ExtPos, ExtPos_Price           , mainPos, ExtPos, ExtPos_Price);
            COPY_DYNFLD(adjPos, ExtPos, ExtPos_Quote           , mainPos, ExtPos, ExtPos_Quote);

            DBA_InverseSign(mainPos);    /* Restore the sign */

            COPY_DYNFLD(adjPos, ExtPos, ExtPos_HistQuote       , resPos,  ExtPos, ExtPos_HistQuote);
        }
    }

    FUS_TraceEndFunction(ctx, functionName, TRUE, FALSE); /* PMSTA-4559 - 011107 - PMO */

    return ret ;
}

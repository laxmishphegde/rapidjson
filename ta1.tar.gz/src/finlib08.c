/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define FINLIB08_C

#define STDIO_H
#define STRING_H
#define STDLIB_H

/************************************************************************
**      Includes
*************************************************************************/
#include "unidef.h"        /* Mandatory */
#include "fin.h"
#include "scptyl.h"

/************************************************************************
**
**      Functions Description
** Ex	FIN_InsUpdStratData				Update extended strategy element (+ strategy element(s)) and parent(s).
** Ex	FIN_StratNewStratHist			Insert new strategy history and update A_StratElt, ExtStratElt and ExtStratLnk
**      FIN_StratHistGetDate            Verify if there is strategy history attach to link.
**		FIN_StratCreateESERecomList		Create recommendation list elements.
**		FIN_StratCreateESERecomListTot	Create recommendation list total element.
**		FIN_StratAddESEInHier			Init extended strategy element and add it in strategy hierarchy.
**      FIN_StratCheckDelModel          Check if the current ESE can be deleted.
**      FIN_SelDispStratElt
** Ex	FIN_StratHistCheckDate          Get most recent date in strategy history list.
**		FIN_MCECheckUpd					Check if the current Modelling Constraint Element field can be updated.
**      FIN_StratCheckUpd               Check if the current ESE field can be updated.
**      FIN_StratCheckInsModel          Check if the current ESE can be inserted.
*************************************************************************/

/************************************************************************
**      Constants
*************************************************************************/

/************************************************************************
**      Macro Definitions
*************************************************************************/

/************************************************************************
**      Type  Definitions
*************************************************************************/

/************************************************************************
**      Global Functions
**
*************************************************************************/

/************************************************************************
**      Static Functions
**
*************************************************************************/


STATIC RET_CODE FIN_StratCreateESERecomListTot(DBA_HIER_HEAD_STP, int, DBA_DYNFLD_STP);
STATIC int		FIN_StratCmpESLStratId(DBA_DYNFLD_STP*, DBA_DYNFLD_STP*);

/* REF9584 - RAK - 040128 */
typedef enum {
	stratEltState_Insert,
	stratEltState_InsertAndNoDelete,
	stratEltState_KeepState
} STRATELT_STATE_ENUM;


/************************************************************************
**
**  Function    :   FIN_StratNewStratHist
**
**  Description :   Insert new strategy history and update A_StratElt, ExtStratElt and ExtStratLnk
**
**  Arguments   :   stratHierPtr	strategy header pointer
**
**  Return      :   RET_CODE
**
**  Cr�ation	:   RAK - 990915 - REF3729
**  Modif.      :   MRA - 000911 - REF5218
**                  CSY - 010713 - REF6163
**
*************************************************************************/
RET_CODE FIN_StratNewStratHist(DbiConnectionHelper &dbiConnHelper,
                               DBA_HIER_HEAD_STP    stratHierPtr,
                               DBA_DYNFLD_STP       modStratHistPtr,
							   DBA_DYNFLD_STP		searchLnkPtr)
{
    RET_CODE			ret                 = RET_SUCCEED;
	DBA_DYNFLD_STP		stratHistPtr        = NULLDYNST;
	DBA_DYNFLD_STP		aStratPtr           = NULLDYNST;
    DBA_DYNFLD_STP      *stratEltTab         = NULLDYNSTPTR;
    DBA_DYNFLD_STP      *ESLTab              = NULLDYNSTPTR;
	DBA_DYNFLD_STP		getStratHistPtr=NULLDYNST, dbStratHistPtr=NULLDYNST, admArgPtr=NULLDYNST;
	DBA_HIER_UPDDB_ST	hierUpdDbSt;
    DBA_HIER_MODIF_ENUM state;  /* REF6163 - CSY - 010713 */
    ID_T                oldStratId          = -1;
    ID_T                newStratHistId      = -1;
    int					i;
    int					j;
    int					stratEltNbr         = 0;
    int					ESLNbr              = 0;
	STRATELT_STATE_ENUM	stratEltState=stratEltState_Insert;

	/* Get all extended strategy link */
    if ((ret = DBA_ExtractHierEltRec(stratHierPtr,
			                         ExtStratLnk,
			                         FALSE,
                                     FIN_StratFilterDispESL,
                                     /*FIN_StratCmpESLLevel,*/	/* REF4047 - 991222 - SKE */
									 FIN_StratCmpESLStratId,	/* REF7420 - RAK - 021024 */
			                         &ESLNbr,
                                     &ESLTab)) != RET_SUCCEED)
	{
		return(ret);
	}

	/* REF9584 - RAK - 040128 - Allocate */
	if ((getStratHistPtr = ALLOC_DYNST(S_StratHist)) == NULLDYNST)
	{
		FREE(ESLTab);
		MSG_RETURN(RET_MEM_ERR_ALLOC);
	}

    if ((dbStratHistPtr = ALLOC_DYNST(A_StratHist)) == NULLDYNST)
	{
		FREE(ESLTab);
        FREE_DYNST(getStratHistPtr, S_StratHist);
	   	MSG_RETURN(RET_MEM_ERR_ALLOC);
	}

	if ((admArgPtr = ALLOC_DYNST(Adm_Arg)) == NULLDYNST)
	{
		FREE(ESLTab);
        FREE_DYNST(getStratHistPtr, S_StratHist);
		FREE_DYNST(admArgPtr, Adm_Arg);
	   	MSG_RETURN(RET_MEM_ERR_ALLOC);
	}


    /* Open transaction mode */
    if ((ret = dbiConnHelper.beginTransaction()) != RET_SUCCEED)
    {
		FREE(ESLTab);
        FREE_DYNST(getStratHistPtr, S_StratHist);
		FREE_DYNST(dbStratHistPtr, A_StratHist);
		FREE_DYNST(admArgPtr, Adm_Arg);
        return(ret);
    }

	for (i=0; i < ESLNbr && ret == RET_SUCCEED ; i++)
	{
        /* REF4047 - 000126 - SKE : Test strategy rights */
        if (IS_NULLFLD(ESLTab[i], ExtStratLnk_A_Strat_Ext) == FALSE         &&
            GET_EXTENSION_PTR(ESLTab[i], ExtStratLnk_A_Strat_Ext) != NULL   &&
            (aStratPtr = *(GET_EXTENSION_PTR(ESLTab[i], ExtStratLnk_A_Strat_Ext))) != NULLDYNST)
        {
            if (IS_NULLFLD(aStratPtr, GET_FLD_AUTH_UPD(A_Strat)) == FALSE  &&
                GET_FLAG(aStratPtr, GET_FLD_AUTH_UPD(A_Strat)) == FALSE)
            {
                continue;
            }
        }

		/* Get history and element(s) */
		if (GET_EXTENSION_PTR(ESLTab[i], ExtStratLnk_A_StratHist_Ext) != NULL &&
			(stratHistPtr = *(GET_EXTENSION_PTR(ESLTab[i], ExtStratLnk_A_StratHist_Ext))) != NULLDYNST)
		{
			stratEltTab = GET_EXTENSION_PTR(stratHistPtr, A_StratHist_A_StratElt_Ext);
			stratEltNbr = GET_EXTENSION_NBR(stratHistPtr, A_StratHist_A_StratElt_Ext);
        }

        /* Only one history by strategy...  */
        if (oldStratId != GET_ID(ESLTab[i], ExtStratLnk_StratId))
        {
			/* REF9584 - RAK - 040128 - In case of list ... */
			SET_DATETIME(getStratHistPtr, S_StratHist_BegDate, GET_DATETIME(modStratHistPtr, A_StratHist_BegDate));
			SET_ID(getStratHistPtr, S_StratHist_StratId, GET_ID(ESLTab[i], ExtStratLnk_StratId));

			newStratHistId = GET_ID(stratHistPtr, A_StratHist_Id);

			/* If save date isn't selection date, and if a StratHist exist on the save date */
			if (ESLNbr > 1 &&
				DATETIME_CMP(GET_DATETIME(searchLnkPtr, A_SearchLnk_BeginDate),
				             GET_DATETIME(modStratHistPtr, A_StratHist_BegDate)) != 0 &&
                dbiConnHelper.dbaGet(StratHist, UNUSED, getStratHistPtr, &dbStratHistPtr) == RET_SUCCEED)
			{
				/* Delete old StratElt (they will be replaced by StratElt of the screen) */
				SET_ID(admArgPtr, Adm_Arg_Id, GET_ID(dbStratHistPtr, A_StratHist_Id));
				SET_FLAG(admArgPtr, Adm_Arg_Flag, TRUE);

				ret = DBA_Delete2(StratElt, DBA_ROLE_UPDATE_MODEL,
			                      Adm_Arg, admArgPtr,
								  DBA_SET_CONN | DBA_NO_CLOSE | DBA_NO_OLD_DATA_AUDIT,          /*  FIH-REF9952-041021  Use of DBA_NO_OLD_DATA_AUDIT    */
								  &dbiConnHelper.getId());

				if (ret == RET_SUCCEED)
				{
					/* Update denom and end date in StratHist */
					COPY_DYNFLD(stratHistPtr,    A_StratHist, A_StratHist_Denom,
								modStratHistPtr, A_StratHist, A_StratHist_Denom);

					COPY_DYNFLD(stratHistPtr,    A_StratHist, A_StratHist_EndDate,
								modStratHistPtr, A_StratHist, A_StratHist_EndDate);

					ret = DBA_Update2(StratHist, UNUSED,
								      A_StratHist, dbStratHistPtr,
                                      dbiConnHelper);
				}

				newStratHistId = GET_ID(dbStratHistPtr, A_StratHist_Id);

				/* Insert all the StratElt, except deleted StratElt for which won't be inserted, won't be deleted */
				stratEltState = stratEltState_InsertAndNoDelete;
			}
			/* If loaded history have the same date as save date, update history */
			else if (ESLNbr > 1 &&
				     DATETIME_CMP(GET_DATETIME(modStratHistPtr, A_StratHist_BegDate),
				                  GET_DATETIME(stratHistPtr, A_StratHist_BegDate)) == 0)
			{
				/* Update denom and end date in StratHist */
				COPY_DYNFLD(stratHistPtr,    A_StratHist, A_StratHist_Denom,
		                    modStratHistPtr, A_StratHist, A_StratHist_Denom);

				COPY_DYNFLD(stratHistPtr,    A_StratHist, A_StratHist_EndDate,
		                    modStratHistPtr, A_StratHist, A_StratHist_EndDate);

				ret = DBA_Update2(StratHist,
								  UNUSED,
								  A_StratHist,
								  stratHistPtr,
                                  dbiConnHelper);

				/* don't change status of the StratElt */
				stratEltState = stratEltState_KeepState;
			}
            /* Standard case : insert new history */
			else if (GET_A_Strat_SubNatEn(aStratPtr) != StratSubNatEn::DummyPortfolio)	    /* MRA + RAK - 040325 - REF9769 in case of a dummy we don't save a history */
			{
				SET_NULL_ID(stratHistPtr, A_StratHist_Id);

				COPY_DYNFLD(stratHistPtr, A_StratHist, A_StratHist_Denom,
		                modStratHistPtr, A_StratHist, A_StratHist_Denom);

				COPY_DYNFLD(stratHistPtr, A_StratHist, A_StratHist_BegDate,
		                (DBA_DYNFLD_STP) modStratHistPtr, A_StratHist, A_StratHist_BegDate);

				COPY_DYNFLD(stratHistPtr, A_StratHist, A_StratHist_EndDate,
		                (DBA_DYNFLD_STP) modStratHistPtr, A_StratHist, A_StratHist_EndDate);

				ret = DBA_Insert2(StratHist,
								  UNUSED,
								  A_StratHist,
								  stratHistPtr,
                                  dbiConnHelper);

				if (ret == RET_SUCCEED)
				{
					newStratHistId = GET_ID(stratHistPtr, A_StratHist_Id);
					oldStratId = GET_ID(ESLTab[i], ExtStratLnk_StratId);
				}

				stratEltState = stratEltState_Insert;
			}

			/* REF9584 - RAK - 040128 - test on stratEltState and      */
			/* don'tupdate status in case of StratHist is only updated */
			if (stratHistPtr != NULLDYNST && stratEltState != stratEltState_KeepState)
			{
				for (j=0; j<stratEltNbr && ret == RET_SUCCEED ; j++)
				{
					/* REF11559 - CHU - 051124 : check validity of Strategy element */
					if (GET_ID(stratEltTab[j], A_StratElt_Id) < (ID_T)0 &&
						IS_NULLFLD(stratEltTab[j], A_StratElt_PtfIdForMissingPM) == FALSE &&
						CMP_ID(GET_ID(ESLTab[i], ExtStratLnk_PtfId), GET_ID(stratEltTab[j], A_StratElt_PtfIdForMissingPM))!=0)
					{
						continue;
					}

					/* Set new history identifier to strategy elements */
					SET_ID(stratEltTab[j], A_StratElt_StratHistId, newStratHistId);

                    ret = DBA_GetHierEltRecState(stratHierPtr,
                                                 A_StratElt,
                                                 stratEltTab[j],
                                                 &state);

					if (ret != RET_SUCCEED)
					{ break;}

					/* REF6163 - CSY - 010713: do not treat elements with delete mode */
					if (state == HierModDel)
					{
						/* REF9584 - RAK - 040128 - Don't delete record in new history */
						if (stratEltState == stratEltState_InsertAndNoDelete)
						{
							ret = DBA_SetRecHierDelDbFlg(stratHierPtr, A_StratElt, stratEltTab[j], FALSE);
						}

						DBA_DelHierEltRec(stratHierPtr, A_StratElt, stratEltTab[j]);
						continue;
					}

					/* Signal that A_StratElt must be inserted ... */
					ret = DBA_SetStatusHierModInsert(stratHierPtr, A_StratElt, stratEltTab[j]);
				}
		    }
		}
	}

	FREE(ESLTab);
	/* REF9584 - RAK - 040129 */
	FREE_DYNST(getStratHistPtr, S_StratHist);
	FREE_DYNST(dbStratHistPtr, A_StratHist);
	FREE_DYNST(admArgPtr, Adm_Arg);

    if (ret == RET_SUCCEED)
    {
	    memset(&hierUpdDbSt, 0, sizeof(DBA_HIER_UPDDB_ST));
	    hierUpdDbSt.hierHead        = stratHierPtr;
	    hierUpdDbSt.hierDynStEn      = A_StratElt;   /* PMSTA-13295 - JPP - 20111219 */
	    hierUpdDbSt.entity          = StratElt;
	    hierUpdDbSt.type            = FALSE;		/* Don't use link  */
	    hierUpdDbSt.insFct          = FIN_StratInsDbStratElt;
        /* REF4047 - 000125 - SKE : keep inside the same transaction
	    hierUpdDbSt.transFlag  = TRUE; MDE - 991129 - REF4047 */
        hierUpdDbSt.transFlag       = FALSE;
        hierUpdDbSt.connectNo       = dbiConnHelper.getId();                    /* REF4047 - 000125 - SKE */
        hierUpdDbSt.modifOptions    = DBA_SET_CONN | DBA_NO_CLOSE;  /* REF4047 - 000125 - SKE */
        /*
            Insert Strategy Element into database
        */
	    ret = DBA_HierUpdateDatabase(&hierUpdDbSt);
    }

    /* Close transaction */
    dbiConnHelper.endTransaction(ret == RET_SUCCEED ? TRUE : FALSE);

    /* MRA - 000911 - REF5218 */
    if(SYS_IsGuiMode() == TRUE)
	{
	    DBA_ForceVerifOptiTab();
	}

	return(ret);
}

/************************************************************************
**
**  Function    :   FIN_SelDispStratElt
**
**  Description :
**
**  Arguments   :   stratHierPtr	strategy header pointer
**
**  Return      :   RET_CODE
**
**  Cr�ation	:   ROI - 990915 - REF3729
**	Modif.		:   RAK - 990924 - REF3729
**
*************************************************************************/
RET_CODE FIN_SelDispStratElt(DBA_HIER_HEAD_STP stratHierPtr, DBA_DYNFLD_STP**stratEltTab, int *stratEltNbr)
{
    RET_CODE	ret=RET_SUCCEED;
    int		i, j, k, ESLNbr=0, crtStratEltNbr=0, allocSz=0;
    DBA_DYNFLD_STP *ESLTab=NULLDYNSTPTR, stratHistPtr=NULLDYNST, *crtStratEltTab=NULLDYNSTPTR;
    DBA_HIER_MODIF_ENUM state;

    *stratEltNbr = 0;
    *stratEltTab = NULLDYNSTPTR;


    if ((ret = DBA_ExtractHierEltRec(stratHierPtr,
			                         ExtStratLnk,
			                         FALSE,
                                     FIN_StratFilterDispESL,
                                     NULLFCT,
			                         &ESLNbr,
                                     &ESLTab)) != RET_SUCCEED)
	return(ret);

    for (i=0; i<ESLNbr; i++)
    {
	    /* Get history and element(s) */
	    if (GET_EXTENSION_PTR(ESLTab[i], ExtStratLnk_A_StratHist_Ext) != NULL &&
	        (stratHistPtr = *(GET_EXTENSION_PTR(ESLTab[i], ExtStratLnk_A_StratHist_Ext))) != NULLDYNST)
	    {
	        crtStratEltTab = GET_EXTENSION_PTR(stratHistPtr, A_StratHist_A_StratElt_Ext);
	        crtStratEltNbr = GET_EXTENSION_NBR(stratHistPtr, A_StratHist_A_StratElt_Ext);

            /* <REF4656 SKE - 000502 - */
            if (crtStratEltNbr == 0)
            {
                continue;
            }
            /* REF4656 SKE - 000502>*/

	        /* Allocate memory */
	        if ((*stratEltNbr) + crtStratEltNbr >= allocSz)
	        {
		        allocSz += crtStratEltNbr;
		        *stratEltTab = (DBA_DYNFLD_STP*) REALLOC((*stratEltTab), allocSz*sizeof(DBA_DYNFLD_STP));

		        if ((*stratEltTab) == NULLDYNSTPTR)
		        {
		            FREE(ESLTab);
		            MSG_SendMesg(RET_MEM_ERR_ALLOC, 1, FILEINFO, allocSz);
		            return(RET_MEM_ERR_ALLOC);
		        }
	        }

	        for (j=0, k=(*stratEltNbr); j<crtStratEltNbr; j++)
	        {
				/* REF11559 - CHU - 051124 : check validity of Strategy element */
				if (GET_ID(crtStratEltTab[j], A_StratElt_Id) < (ID_T)0 &&
					IS_NULLFLD(crtStratEltTab[j], A_StratElt_PtfIdForMissingPM) == FALSE &&
					CMP_ID(GET_ID(ESLTab[i], ExtStratLnk_PtfId), GET_ID(crtStratEltTab[j], A_StratElt_PtfIdForMissingPM))!=0)
				{
					continue;
				}

		        if ((ret = DBA_GetHierEltRecState(stratHierPtr, A_StratElt,
			                crtStratEltTab[j], &state)) != RET_SUCCEED)
		        {
		            FREE(ESLTab);
		            FREE((*stratEltTab));
		            *stratEltNbr = 0;
		            return(ret);
		        }

		        switch(state)
                {
		            case HierModIns :
		            case HierModUpd :
		                (*stratEltTab)[k] = crtStratEltTab[j];
		                k++;
			            break;
		        }
	        }
	        *stratEltNbr = k;
	    }
    }

    FREE(ESLTab);
    return(RET_SUCCEED);
}


/************************************************************************
**
**  Function    :   FIN_StratHistGetDate
**
**  Description :   Verify if there is strategy history attach to link.
**
**  Arguments   :   stratHierPtr	strategy header pointer
**                  flagPtr         pointer on flag
**                                  - flagPtr == TRUE if at least one history
**                                    is not found
**                                  - flagPtr == FALSE elsewhere
**                  authFlgPtr      pointer on flag
**                                  - authFlgPtr == TRUE if the user has the
**                                    update right on at least one strategy.
**                                  - authFlgPtr == FALSE elsewhere
**
**
**
**  Return      :   RET_CODE
**
**  Cr�ation	:   ROI - 990915 - REF3729
**	Modif.		:   RAK - 990924 - REF3729
**
**
*************************************************************************/
RET_CODE FIN_StratHistCheckDate(DBA_HIER_HEAD_STP stratHierPtr, FLAG_T* flagPtr, FLAG_T* authFlgPtr)
{
    RET_CODE			retCode         = RET_SUCCEED;
	DBA_DYNFLD_STP		stratHistPtr    = NULLDYNST;
	DBA_DYNFLD_STP		aStratPtr       = NULLDYNST;
    DBA_DYNFLD_STP     *ESLTab          = NULLDYNSTPTR;
    int					i;
    int                 ESLNbr          = 0;

	/* V�rification des param�tres transmis */
	if (stratHierPtr    == NULL             ||
		flagPtr         == (FLAG_T*) NULL   ||
        authFlgPtr      == (FLAG_T*) NULL)
    {
        MSG_RETURN(RET_GEN_ERR_INVARG);
    }
	*flagPtr = FALSE;
    *authFlgPtr = FALSE;

	retCode = DBA_ExtractHierEltRecWithFilterSt(stratHierPtr,
			                                    ExtStratLnk,
			                                    FALSE,
												NULLFCT,
					                            NULLDYNST,
												NULLFCT,
			                                    &ESLNbr,
												&ESLTab);

    if (retCode != RET_SUCCEED)
    {
        FREE(ESLTab);
        *flagPtr = TRUE;
        *authFlgPtr = FALSE;
        return(retCode);
    }
    if (ESLNbr == 0)
    {
        FREE(ESLTab);
        *flagPtr = TRUE;
        *authFlgPtr = FALSE;
        return(retCode);
    }

    if (ESLTab == NULLDYNSTPTR)
    {
        *flagPtr = TRUE;
        *authFlgPtr = FALSE;
        return(retCode);
    }

	for (i=0 ; i<ESLNbr; i++)
	{
		stratHistPtr = NULLDYNST;
        aStratPtr = NULLDYNST;

		if (GET_EXTENSION_PTR(ESLTab[i], ExtStratLnk_A_StratHist_Ext) != NULL)
        {
			stratHistPtr = *(GET_EXTENSION_PTR(ESLTab[i], ExtStratLnk_A_StratHist_Ext));
        }

		if (stratHistPtr == NULLDYNST   ||
            /* REF4047 - 991222 - SKE : or if the link is "virtual" */
            GET_ID(stratHistPtr, A_StratHist_Id) < 0)
        {
             /* MRA - 040127 - REF9769 */
            /* A Strategy of DummyPtf Nature has never a history */
            if (GET_EXTENSION_PTR(ESLTab[i], ExtStratLnk_A_Strat_Ext) != NULL)
            {
                aStratPtr = *(GET_EXTENSION_PTR(ESLTab[i], ExtStratLnk_A_Strat_Ext));
            }
            if (aStratPtr == NULLDYNST)
            {
                MSG_SendMesg(RET_DBA_ERR_NODATA, 7, FILEINFO, GET_ID(ESLTab[i], ExtStratLnk_StratId));
                FREE(ESLTab);
                return(RET_DBA_ERR_NODATA);
            }
            if (IS_NULLFLD(aStratPtr, A_Strat_SubNatEn) == FALSE   &&
                GET_A_Strat_SubNatEn(aStratPtr) != StratSubNatEn::DummyPortfolio)
                *flagPtr = TRUE;
        }
        /* REF4047 - 991222 - SKE */
        /* Test rights */

        /* parent strategy is skipped */
        if (GET_TINYINT(ESLTab[i], ExtStratLnk_Level) == 0)
        {
            continue;
        }

        if (GET_EXTENSION_PTR(ESLTab[i], ExtStratLnk_A_Strat_Ext) != NULL)
        {
            aStratPtr = *(GET_EXTENSION_PTR(ESLTab[i], ExtStratLnk_A_Strat_Ext));
        }
        if (aStratPtr == NULLDYNST)
        {
            /* SKE 001003 : Beurk !!! moved below
            FREE(ESLTab);
            */
            MSG_SendMesg(RET_DBA_ERR_NODATA, 7, FILEINFO, GET_ID(ESLTab[i], ExtStratLnk_StratId));
            FREE(ESLTab);
            return(RET_DBA_ERR_NODATA);
        }
        if (IS_NULLFLD(aStratPtr, GET_FLD_AUTH_UPD(A_Strat)) == FALSE   &&
            GET_FLAG(aStratPtr, GET_FLD_AUTH_UPD(A_Strat)) == TRUE)
        {
            *authFlgPtr = TRUE;
        }
    }
    FREE(ESLTab);

	return(retCode);
}


/*************************************************************************************
*   Function             : FIN_StratCreateESERecomList()
*
*   Description          : Create recommendation list elements.
*
*   Arguments            :
*
*   Return               : RET_SUCCEED or error code
*
*   Creation Date        : 15.07.99 - REF3729
*
**************************************************************************************/
RET_CODE FIN_StratCreateESERecomList(DBA_HIER_HEAD_STP stratHierPtr,
                                            int               ESEFldNbr,
                                            DBA_DYNFLD_STP    ESLPtr)
{
    RET_CODE	            ret             = RET_SUCCEED;
	DBA_DYNFLD_STP          stratHistPtr    = NULLDYNST;
    DBA_DYNFLD_STP          aInstrPtr       = NULLDYNST;
    DBA_DYNFLD_STP          targetESLPtr    = NULLDYNST;
    DBA_DYNFLD_STP         *stratEltTab     = NULLDYNSTPTR;
    SCPT_CLASSIFSTACK_STP	classifStack    = (SCPT_CLASSIFSTACK_STP)NULL;
    ID_T                    targetMktSegtId = 0;
    FLAG_T                  allocFlg        = FALSE;
    int                     stratEltNbr     = 0;
    int                     i;

    /* Read recommendation list element */
    if (GET_EXTENSION_PTR(ESLPtr, ExtStratLnk_A_StratHist_Ext) != NULL &&
	   (stratHistPtr = *(GET_EXTENSION_PTR(ESLPtr, ExtStratLnk_A_StratHist_Ext))) != NULLDYNST)
    {
		stratEltTab = GET_EXTENSION_PTR(stratHistPtr, A_StratHist_A_StratElt_Ext);
		stratEltNbr = GET_EXTENSION_NBR(stratHistPtr, A_StratHist_A_StratElt_Ext);
    }

    if (IS_NULLFLD(ESLPtr, ExtStratLnk_GridId) == FALSE)
    {
        /*
            The instruments are dispatched only from the top strategy ie the
            strategy with level equal to 1.
        */
        if (GET_TINYINT(ESLPtr, ExtStratLnk_Level) != 1) return(ret);

        if (stratEltNbr > 0)
        {
	        if ((classifStack = (SCPT_CLASSIFSTACK_STP) CALLOC(20, sizeof(SCPT_CLASSIFSTACK_ST))) == (SCPT_CLASSIFSTACK_STP)NULL)
	        {
                MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "classifStack");
	            return(RET_MEM_ERR_ALLOC);
	        }
		    for (i=0; i<stratEltNbr; i++)
		    {
                if (IS_NULLFLD(stratEltTab[i], A_StratElt_InstrId) == TRUE) continue;

				/* REF11559 - CHU - 051124 : check validity of Strategy element */
				if (GET_ID(stratEltTab[i], A_StratElt_Id) < (ID_T)0 &&
					IS_NULLFLD(stratEltTab[i], A_StratElt_PtfIdForMissingPM) == FALSE &&
					CMP_ID(GET_ID(ESLPtr, ExtStratLnk_PtfId), GET_ID(stratEltTab[i], A_StratElt_PtfIdForMissingPM))!=0)
				{
					continue;
				}

                targetESLPtr = NULLDYNST;
                targetMktSegtId = (ID_T)0;
                /* Extract the instrument */
                ret = DBA_GetInstrById(GET_ID(stratEltTab[i], A_StratElt_InstrId),
                                       FALSE,
                                       &allocFlg,
	                                   &aInstrPtr,
       			                       stratHierPtr,
                                       UNUSED,
                                       UNUSED);
                if (ret != RET_SUCCEED)
                {
                    SCPT_FreeClassifStack(&classifStack);
                    return(ret);
                }
                /*
                    Retrieve the market segment where the instrument
                    takes place.
                */
				/* REF9003 - RAK - 030930 */
				/* Don't call FIN_SetInstrInStratHier() */
				/* for Notional Instrument ... use stored market segment */
				if (GET_ENUM(aInstrPtr, A_Instr_NatEn) == InstrNat_NotionalInstr)
				{
					targetESLPtr = ESLPtr;
					targetMktSegtId = GET_ID(stratEltTab[i], A_StratElt_MktSegtId);
				}
				else
				{
					targetESLPtr = FIN_SetInstrInStratHier(stratHierPtr,
                                                       NULLDYNST,
                                                       ESLPtr,
                                                       NULLDYNST,
                                                       aInstrPtr,
                                                       &targetMktSegtId,
                                                       classifStack,
                                                       UNUSED,
                                                       UNUSED,
													   0); /* REF8834 - CHU - 031119 */
				}

                if (allocFlg == TRUE) FREE_DYNST(aInstrPtr, A_Instr);
                if (targetMktSegtId != 0)
                {
                    SET_ID(stratEltTab[i], A_StratElt_MktSegtId, targetMktSegtId);
			        if ((ret = FIN_StratCreateESEModelDet(stratHierPtr,
                                                          ESEFldNbr,
							                              targetESLPtr,
                                                          stratEltTab[i],
                                                          NULLDYNST,
                                                          ExtStratEltNat_RecommList)) != RET_SUCCEED)
                    {
                        SCPT_FreeClassifStack(&classifStack);
			            return(ret);
                    }
                }
            }
            SCPT_FreeClassifStack(&classifStack);
        }
    }
    else
    {
	    if ((ret = FIN_StratCreateESERecomListTot(stratHierPtr,
						                          ESEFldNbr,
                                                  ESLPtr)) != RET_SUCCEED)
        {
		    return(ret);
        }

		for (i=0; i<stratEltNbr; i++)
		{
			/* REF11559 - CHU - 051124 : check validity of Strategy element */
			if (GET_ID(stratEltTab[i], A_StratElt_Id) < (ID_T)0 &&
				IS_NULLFLD(stratEltTab[i], A_StratElt_PtfIdForMissingPM) == FALSE &&
				CMP_ID(GET_ID(ESLPtr, ExtStratLnk_PtfId), GET_ID(stratEltTab[i], A_StratElt_PtfIdForMissingPM))!=0)
			{
				continue;
			}

			if ((ret = FIN_StratCreateESEModelDet(stratHierPtr,
                                                  ESEFldNbr,
							                      ESLPtr,
                                                  stratEltTab[i],
                                                  NULLDYNST,
                                                  ExtStratEltNat_RecommList)) != RET_SUCCEED)
            {
			    return(ret);
            }
		}
    }

	return(RET_SUCCEED);
}

/*************************************************************************************
*   Function             : FIN_StratCreateESERecomListTot()
*
*   Description          : Create recommendation list total element.
*
*   Arguments            :
*
*   Return               : RET_SUCCEED or error code
*
*   Creation Date        : 15.07.99 - REF3729
*
**************************************************************************************/
STATIC RET_CODE FIN_StratCreateESERecomListTot(DBA_HIER_HEAD_STP stratHierPtr,
                                               int               ESEFldNbr,
					                           DBA_DYNFLD_STP    ESLPtr)
{
	RET_CODE        ret     = RET_SUCCEED;
	DBA_DYNFLD_STP  ESEPtr  = NULLDYNST;


	if (ESEFldNbr > 0)
	{
	    ESEPtr = ALLOC_DYNST_SUPPLFLD(ExtStratElt, ESEFldNbr);
	    if (ESEPtr == NULLDYNST)
	    {
		    MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "ExtStratElt suppl. fld");
		    return(RET_MEM_ERR_ALLOC);
	    }
	}
	else
	{
	    ESEPtr = ALLOC_DYNST(ExtStratElt);
	    if (ESEPtr == NULLDYNST)
	    {
		    MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "ExtStratElt");
		    return(RET_MEM_ERR_ALLOC);
	    }
	}

	/* LEVEL */
	SET_TINYINT(ESEPtr, ExtStratElt_Level, 1);

	/* INIT COMMON FIELDS AND ADD EXTENDED STRATEGY ELEMENT IN HIERARCHY */
	if ((ret = FIN_StratAddESEInHier(stratHierPtr,
                                     ESEPtr,
                                     ESEFldNbr,
                                     ESLPtr,
				                     ExtStratEltNat_RecommList)) != RET_SUCCEED)
	{
		return(ret);
	}

	/* Prepare link ExtStratElt_DispPar_ExtStratElt_Ext */
	if (IS_NULLFLD(ESEPtr, ExtStratElt_ParExtStratEltId) == FALSE)
	{
        SET_ID(ESEPtr, ExtStratElt_DispParExtStratEltId, GET_ID(ESEPtr, ExtStratElt_ParExtStratEltId));
    }

	return(RET_SUCCEED);
}

/*************************************************************************************
*   Function             : FIN_StratCreateESERisk()
*
*   Description          : Create risk strategy elements.
*
*   Arguments            :
*
*   Return               : RET_SUCCEED or error code
*
*   Creation Date        : PMSTA05345-CHU-080505
*
**************************************************************************************/
RET_CODE FIN_StratCreateESERisk(DBA_HIER_HEAD_STP stratHierPtr,
								int               ESEFldNbr,
								DBA_DYNFLD_STP    ESLPtr,
                                int                     selOptions,
                                int                    *connectNo)
{
    RET_CODE	            ret             = RET_SUCCEED;
	DBA_DYNFLD_STP			missingStratElt	= NULLDYNST;
	DBA_DYNFLD_STP          stratHistPtr    = NULLDYNST;
    DBA_DYNFLD_STP         *stratEltTab     = NULLDYNSTPTR, *initialStratEltTab=NULLDYNSTPTR;
    int                     stratEltNbr     = 0;
    int						i, compChronoNatNbr;
	FLAG_T					*scptFlagTab, noStratEltFlg = FALSE; /* PMSTA-18426 - CHU - 141022 */
	int						code;

    if (GET_EXTENSION_PTR(ESLPtr, ExtStratLnk_A_StratHist_Ext) != NULL &&
	   (stratHistPtr = *(GET_EXTENSION_PTR(ESLPtr, ExtStratLnk_A_StratHist_Ext))) != NULLDYNST)
    {
		stratEltTab = GET_EXTENSION_PTR(stratHistPtr, A_StratHist_A_StratElt_Ext);
		stratEltNbr = GET_EXTENSION_NBR(stratHistPtr, A_StratHist_A_StratElt_Ext);
    }
    if (stratEltNbr != 0)   /* PMSTA15722-JPP-230110 */
    {
	    /* PMSTA08416 - RAK - 090723 */
	    if (((initialStratEltTab) = (DBA_DYNFLD_STP*)CALLOC(stratEltNbr, sizeof(DBA_DYNFLD_STP))) == NULLDYNSTPTR)
	    {
		    MSG_RETURN(RET_MEM_ERR_ALLOC);
	    }
	}
	else
	{
		noStratEltFlg = TRUE; /* ranks will inherit from COMPCHRONONAT_ENUM */
	}

	for (i=0; i<stratEltNbr; i++)
	{	initialStratEltTab[i] = stratEltTab[i]; }


	for (i=0; i<stratEltNbr; i++)
	{
		if ((ret = FIN_StratCreateESERiskDet(stratHierPtr,
											  ESEFldNbr,
											  ESLPtr,
											  initialStratEltTab[i],
											  NULLDYNST,
											  ExtStratEltNat_Risk)) != RET_SUCCEED)
		{
			FREE(initialStratEltTab);	/* PMSTA08416 - RAK - 090723 */
			return(ret);
		}
	}



	/* Treat missing Compliance Chrono Natures */
	for (compChronoNatNbr=1; compChronoNatNbr < CompChronoNat_Last; compChronoNatNbr++)
	{
		FLAG_T foundFlg = FALSE;

		for (i=0; i < stratEltNbr; i++)
		{	/* PMSTA08416 - RAK - 090723 */
			if (GET_ENUM(initialStratEltTab[i], A_StratElt_CompChronoNat) == (ENUM_T)compChronoNatNbr)
			{
				foundFlg = TRUE;
			}
		}

		if (foundFlg == FALSE)
		{
			/* Create A_StratElt and add it in hierarchy (and do A_StratHist link if exist) */
			if ((missingStratElt = ALLOC_DYNST(A_StratElt)) == NULLDYNST)
			{
				MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "A_StratElt");
				FREE(initialStratEltTab);	/* PMSTA08416 - RAK - 090723 */
				return(RET_MEM_ERR_ALLOC);
			}

			/* Set Default Values described in MD */
			DBA_SetDfltEntityFld(StratElt, A_StratElt, missingStratElt);

			SET_ENUM(missingStratElt,   A_StratElt_NatEn,				(ENUM_T)StratEltNat_Risk);
			SET_ENUM(missingStratElt,   A_StratElt_CompChronoNat,		(ENUM_T)compChronoNatNbr);
			SET_ENUM(missingStratElt,   A_StratElt_CompChronoCompNat,	(ENUM_T)CompChronoCompNat_Measure);

			SET_SMALLINT(missingStratElt, A_StratElt_Rank, (SMALLINT_T)compChronoNatNbr); /* ranks will inherit from COMPCHRONONAT_ENUM */  /* PMSTA-35306- CHANDRASEKAR - 10042020 */
			
			/*SET_NUMBER(missingStratElt, A_StratElt_Value,				0.0); */

			scptFlagTab = (FLAG_T *)CALLOC(GET_FLD_NBR(A_StratElt), sizeof(FLAG_T));
			scptFlagTab[A_StratElt_NatEn]				= TRUE;
			scptFlagTab[A_StratElt_Value]				= TRUE;
			scptFlagTab[A_StratElt_CompChronoNat]		= TRUE;
			scptFlagTab[A_StratElt_CompChronoCompNat]	= TRUE;

			if ((selOptions & DBA_IN_TRAN) != DBA_IN_TRAN)
			{
				/* Set Default Values described in script REF4047*/
				if((code = SCPT_ComputeScreenDV(StratElt,
												DictFct_0,
												scptFlagTab,
                                                NULL,              /* HFI-PMSTA-25327-171023  Dedicated flag tab for filter    */
												missingStratElt,
												NULL,
												NULL,
                                                NULLDYNST,   /* PMSTA13283 - DDV - 120117 */
												TRUE,
												TRUE,
												EvalType_DefValAndFilter,   /* FPL-REF9507-030930 */
												-1,
												connectNo,
												NULL,
												stratHierPtr,
												0,
												DictScreen,                 /*  FIH-REF9789-040209  */
												NULL,
												NULL,
												NULL,
												NULL,
												NULL,
												NullEntity,
												FALSE,
												FALSE,
                                                0)) != 0)   /*  FPL-REF9215-030811  Flag Impact */
				{
					FREE(initialStratEltTab);	/* PMSTA08416 - RAK - 090723 */
					return(RET_GEN_ERR_INVARG);
				}
			}

			ret = DBA_AddHierRecord(stratHierPtr, missingStratElt, A_StratElt, FALSE,
									HierAddRec_TestMandatLnk);

			if (stratHistPtr != NULLDYNST)
			{
				SET_ID(missingStratElt,	A_StratElt_StratHistId,  GET_ID(stratHistPtr, A_StratHist_Id));

				/* Link extended strategy link to extended strategy element */
				ret = DBA_ForceLink(stratHierPtr,
									A_StratHist,
									A_StratHist_A_StratElt_Ext,
									stratHistPtr, missingStratElt);
			}

			if ((ret = FIN_StratCreateESERiskDet(stratHierPtr,
												  ESEFldNbr,
												  ESLPtr,
												  missingStratElt,
												  NULLDYNST,
												  ExtStratEltNat_Risk)) != RET_SUCCEED)
			{
				FREE(initialStratEltTab);	/* PMSTA08416 - RAK - 090723 */
				return(ret);
			}
		}
	}

	FREE(initialStratEltTab);	/* PMSTA08416 - RAK - 090723 */
	return(RET_SUCCEED);
}

/*************************************************************************************
*   Function             : FIN_StratAddESEInHier()
*
*   Description          : Init extended strategy element and add it in strategy hierarchy.
*
*   Arguments            : stratHierPtr   : strategy hierarchy header
*                          ESEPtr          : extended strategy element pointer
*                          ESLPtr          : extended strategy link pointer
*                          eseNatEn        : element nature
*
*   Return               : RET_SUCCEED or error code
*
*   Creation Date        : 23.06.99 - REF3729
*
**************************************************************************************/
RET_CODE FIN_StratAddESEInHier(DBA_HIER_HEAD_STP     stratHierPtr,
                              DBA_DYNFLD_STP        ESEPtr,
                              int                   ESEFldNbr,
                              DBA_DYNFLD_STP        ESLPtr,
                              EXTSTRATELTNAT_ENUM   eseNatEn)
{
    RET_CODE	    ret         = RET_SUCCEED;
    DBA_DYNFLD_STP  aStratPtr   = NULLDYNST;


    /* Init fields */
    SET_ID(ESEPtr,      ExtStratElt_PtfId,         GET_ID(ESLPtr, ExtStratLnk_PtfId));
    SET_ID(ESEPtr,      ExtStratElt_ExtStratLnkId, GET_ID(ESLPtr, ExtStratLnk_Id));
    SET_ID(ESEPtr,      ExtStratElt_StratId,       GET_ID(ESLPtr, ExtStratLnk_StratId));

    /* REF7420 - RAK - 020613 */
    if (IS_NULLFLD(ESEPtr, ExtStratElt_ParMktSegtId) == TRUE)
    { SET_ID(ESEPtr, ExtStratElt_ParMktSegtId, GET_ID(ESLPtr, ExtStratLnk_MktSegId));}

    SET_ID(ESEPtr,      ExtStratElt_GridId,        GET_ID(ESLPtr, ExtStratLnk_GridId));
    SET_ID(ESEPtr,      ExtStratElt_ParStratId,    GET_ID(ESLPtr, ExtStratLnk_LnkParStratId));
    SET_TINYINT(ESEPtr, ExtStratElt_StratLevel,    GET_TINYINT(ESLPtr, ExtStratLnk_Level));
    SET_ENUM(ESEPtr,    ExtStratElt_StratNatEn,    GET_ENUM(ESLPtr, ExtStratLnk_StratNatEn));
    SET_ENUM(ESEPtr,    ExtStratElt_CalcEn,        GET_ENUM(ESLPtr, ExtStratLnk_CalcEn));
    SET_ENUM(ESEPtr,    ExtStratElt_NatEn,         eseNatEn);
    SET_ENUM(ESEPtr,    ExtStratElt_NodeNatEn,     ExtStratEltNodeNat_Node);

	if(GET_ENUM(ESEPtr, ExtStratElt_StratNatEn) == (ENUM_T) StratNat_ModelPtf)
	{
		if(GET_TINYINT(ESEPtr, ExtStratElt_Level) == 1) /* VST - 090301 - PMSTA7387 */
		{
	        COPY_DYNFLD(ESEPtr, ExtStratElt,  ExtStratElt_WeightNatEn,
		                  ESLPtr, ExtStratLnk, ExtStratLnk_WeightNatEn);
			COPY_DYNFLD(ESEPtr, ExtStratElt,  ExtStratElt_Weight,
				          ESLPtr, ExtStratLnk, ExtStratLnk_Weight);
		}
	}
	if(IS_NULLFLD(ESLPtr, ExtStratLnk_Priority) == FALSE)
	{
		SET_SMALLINT(ESEPtr, ExtStratElt_Priority, GET_TINYINT(ESLPtr, ExtStratLnk_Priority));
	}


    if (GET_EXTENSION_PTR(ESLPtr, ExtStratLnk_A_StratHist_Ext) != NULL)
    {
	    SET_ID(ESEPtr, ExtStratElt_StratHistId,
	           GET_ID((*(GET_EXTENSION_PTR(ESLPtr, ExtStratLnk_A_StratHist_Ext))), A_StratHist_Id));
    }

    /* <SKE - 010208 - REF5599 */
	if (GET_EXTENSION_PTR(ESLPtr, ExtStratLnk_A_Strat_Ext) != NULL &&
        (aStratPtr = *(GET_EXTENSION_PTR(ESLPtr, ExtStratLnk_A_Strat_Ext))) != NULLDYNST)
    {
        SET_ENUM(ESEPtr, ExtStratElt_ForecastFlg, GET_ENUM(aStratPtr, A_Strat_RelativeMarginFlg)); /* REF8844 - LJE - 030327 */
    }
    /* SKE - 010208 - REF5599> */

    /* ADD RECORD, update links */
    if (ESEFldNbr > 0)
    {
	    ret = DBA_AddHierRecordSupplFld(stratHierPtr,
			                            ESEPtr,
                                        ExtStratElt,
                                        FALSE,
				                        ESEFldNbr,
                                        HierAddRec_TestMandatLnk);
        /* SKE 991206 : Use FREE_DYNST_SUPPLFLD and not FREE_DYNST */
        if (ret != RET_SUCCEED)
        {
            FREE_DYNST_SUPPLFLD(ESEPtr, ESEFldNbr);
            return(ret);
        }
    }
    else
    {
	    ret = DBA_AddHierRecord(stratHierPtr,
			                    ESEPtr,
                                ExtStratElt,
                                FALSE,
			                    HierAddRec_TestMandatLnk);
        if (ret != RET_SUCCEED)
        {
            FREE_DYNST(ESEPtr, ExtStratElt);
            return(ret);
       }
    }

    /* Link extended strategy link to extended strategy element */
    if ((ret = DBA_ForceLink(stratHierPtr,
			                 ExtStratLnk,
                             ExtStratLnk_ExtStratElt_Ext,
			                 ESLPtr,
                             ESEPtr)) != RET_SUCCEED)
    {
	    return(ret);
    }

    return(RET_SUCCEED);
}

/*************************************************************************************
*   Function             : FIN_StratCheckInsModel()
*
*   Description          : Check if the current ESE can be inserted.
*
*   Arguments            : stratHierPtr     : Strategy hierarchy header.
*                          ESEPtr           : Extended strategy element pointer
*                                             where the insert operation take place.
*                          enableFlg        : Flag pointer
*                                             - TRUE if the insert operation is allowed
*                                             - FALSE elsewhere
*
*   Return               : RET_SUCCEED or error code
*
*   Creation Date        : REF4047 - 000103 - SKE
*
**************************************************************************************/
RET_CODE FIN_StratCheckInsModel(DBA_HIER_HEAD_STP      stratHierPtr,
                                DBA_DYNFLD_STP         ESEPtr,
                                FLAG_T                *enableFlg)
{
    RET_CODE        ret     = RET_SUCCEED;
    DBA_DYNFLD_STP  gridPtr = NULLDYNST;
    DBA_DYNFLD_STP *ESETab  = NULLDYNSTPTR;
    int             ESENbr  = 0;
    int             i;

    if (stratHierPtr == (DBA_HIER_HEAD_STP)NULL     ||
        enableFlg == (FLAG_T*)NULL                  ||
        ESEPtr    == NULLDYNST)
    {
        MSG_RETURN(RET_GEN_ERR_INVARG);
    }

    *enableFlg = FALSE;

	if (IS_NULLFLD(ESEPtr, ExtStratElt_Level) == TRUE)
        return(ret);

    if (GET_TINYINT(ESEPtr, ExtStratElt_Level) == 0)
        return(ret);

    /* Case of a model/recommendation with a grid */
    if (IS_NULLFLD(ESEPtr, ExtStratElt_MktSegtId) == FALSE)
    {
        /* Insert not allowed on total market segment */
        if (GET_TINYINT(ESEPtr, ExtStratElt_Level) == 1)
            return(ret);

        if ((ret = DBA_ExtractHierEltRec(stratHierPtr,
                                         ExtStratElt,
                                         FALSE,
				                         NULLFCT,
                                         NULLFCT,
				                         &ESENbr,
                                         &ESETab)) != RET_SUCCEED)
        {
            return(ret);
        }
        /* Insert not allowed on an intermediate level */
        for (i=0 ; i < ESENbr ; i++)
        {
            if (IS_NULLFLD(ESETab[i], ExtStratElt_ParExtStratEltId) == TRUE) continue;
            if (GET_ID(ESEPtr, ExtStratElt_Id) == GET_ID(ESETab[i], ExtStratElt_ParExtStratEltId))
            {
                if (GET_ENUM(ESETab[i], ExtStratElt_NatEn) == ExtStratEltNat_BreakCriteria)
                {
                    FREE(ESETab);
                    return(ret);
                }
            }
        }
        FREE(ESETab);

        if (GET_TINYINT(ESEPtr, ExtStratElt_Level) == 2)
        {
            if (GET_ENUM(ESEPtr, ExtStratElt_NatEn) == ExtStratEltNat_Alloc ||
                GET_ENUM(ESEPtr, ExtStratElt_NatEn) == ExtStratEltNat_BreakCriteria)
            {
				if (IS_NULLFLD(ESEPtr, ExtStratElt_GridId) == FALSE)
				{
					/* Let's find the grid definition */
					gridPtr = DBA_SearchHierRecById(stratHierPtr,
													A_Grid,
													A_Grid_Id,
													GET_ID(ESEPtr, ExtStratElt_GridId));
					if (gridPtr == NULLDYNST)
					{
						/* < REF8472 - CHU - 030110 */
						/* Retrieve Grid from Database before returning error message */
						DBA_DYNFLD_STP sGridSt = NULLDYNST;

						if ((sGridSt = ALLOC_DYNST(S_Grid)) == NULLDYNST)
						{
							MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
							return(RET_MEM_ERR_ALLOC);
						}

						if ((gridPtr = ALLOC_DYNST(A_Grid)) == NULLDYNST)
						{
							FREE_DYNST(sGridSt, S_Grid);
							MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
							return(RET_MEM_ERR_ALLOC);
						}

						/* Get GRID record */
						SET_ID(sGridSt, S_Grid_Id, GET_ID(ESEPtr, ExtStratElt_GridId));
						if (DBA_Get2(Grid,
									UNUSED,
									S_Grid,
									sGridSt,
									A_Grid,
									&gridPtr,
									UNUSED,
									UNUSED,
									UNUSED) != RET_SUCCEED)
						{
							/* If Grid is still not found, log error message */
							FREE_DYNST(sGridSt, S_Grid);
							MSG_SendMesg(RET_DBA_ERR_NODATA, 8, FILEINFO, GET_ID(ESEPtr, ExtStratElt_GridId));
							return(RET_DBA_ERR_NODATA);
						}
						FREE_DYNST(sGridSt, S_Grid);
						/* Store Grid into Hierarchy */
						DBA_AddHierRecord(stratHierPtr, gridPtr, A_Grid, TRUE,
		                          HierAddRec_ForceInsert);
						/* REF8472 - CHU - 030110 > */
					}
					/* Case of a two dimension grid */
					/* Insert not allowed on abcissa/ordinate market segment */
					if (IS_NULLFLD(gridPtr, A_Grid_OrdinateClassifId) == FALSE)
						return(ret);
				}
				else
				{
					MSG_SendMesg(RET_DBA_ERR_NODATA, 8, FILEINFO, 0);
					return(RET_DBA_ERR_NODATA);
				}

            }
        }
    }
    *enableFlg = TRUE;

    return(ret);
}

/*************************************************************************************
*   Function             : FIN_StratCheckDelModel()
*
*   Description          : Check if the current ESE can be deleted.
*
*   Arguments            : stratHierPtr     : Strategy hierarchy header.
*                          ESEPtr           : Extended strategy element pointer
*                                             where the delete operation take place.
*                          enableFlg        : Flag pointer
*                                             - TRUE if the delete operation is allowed
*                                             - FALSE elsewhere
*
*   Return               : RET_SUCCEED or error code
*
*   Creation Date        : REF4047 - 000103 - SKE
*	Modif.				 : REF4047 - 000218 - MRA
*
**************************************************************************************/
RET_CODE FIN_StratCheckDelModel(DBA_HIER_HEAD_STP      stratHierPtr,
                                DBA_DYNFLD_STP         ESEPtr,
                                FLAG_T                *enableFlg)
{
    RET_CODE    ret = RET_SUCCEED;

    if (stratHierPtr == (DBA_HIER_HEAD_STP)NULL     ||
        enableFlg == (FLAG_T*)NULL                  ||
        ESEPtr    == NULLDYNST)
    {
        MSG_RETURN(RET_GEN_ERR_INVARG);
    }

    *enableFlg = FALSE;

	if (IS_NULLFLD(ESEPtr, ExtStratElt_Level) == TRUE)
        return(ret);
    if (GET_TINYINT(ESEPtr, ExtStratElt_Level) != 2)
        return(ret);
	/* MRA - 000218 - REF4047 */
  /*  if (GET_ENUM(ESEPtr, ExtStratElt_NatEn) != ExtStratEltNat_ModelDetail)
        return(ret);*/
	if (GET_ENUM(ESEPtr, ExtStratElt_NatEn) == ExtStratEltNat_BreakCriteria)
		return(ret);

    *enableFlg = TRUE;

    return(ret);
}

/*************************************************************************************
*   Function        : FIN_MCECheckUpd()
*
*   Description		: Check if the current MCE (Modelling Constraint Element) field can be updated
*
*   Arguments       : stratHierPtr     : Strategy hierarchy header.
*                     ESEPtr           : Extended strategy element pointer
*                                        selected.
*                     enableFlg        : Flag pointer
*                                        - TRUE if the update operation is allowed
*                                        - FALSE elsewhere
*
*   Return               : RET_SUCCEED or error code
*
*   Creation Date        : MDE - REF7190 - 2002 02 20
*
**************************************************************************************/
RET_CODE FIN_MCECheckUpd(DBA_HIER_HEAD_STP    stratHierPtr,
                           DBA_DYNFLD_STP       ESEPtr,
                           int                  field,
                           FLAG_T              *enableFlg)
{
    RET_CODE        ret     = RET_SUCCEED;

    if (stratHierPtr    == (DBA_HIER_HEAD_STP)NULL  ||
        enableFlg       == (FLAG_T*)NULL            ||
        ESEPtr          == NULLDYNST)
    {
        MSG_RETURN(RET_GEN_ERR_INVARG);
    }

    *enableFlg = FALSE;

	if (GET_TINYINT(ESEPtr, ExtStratElt_Level) == 1 &&
		GET_TINYINT(ESEPtr, ExtStratElt_StratLevel) == 1
		)
        return(ret);

    /*  Currency is not editable with fixed cell    */  /*  FIH-REF11350-PMSTA00236-060203 */
	if (((field == ExtStratElt_RefCurrId) ||
	     (field == ExtStratElt_MaxWeightContrib) ||
	     (field == ExtStratElt_MinWeightContrib) ||
	     (field == ExtStratElt_ConstrBoundNatEn)) &&
		(GET_ENUM(ESEPtr, ExtStratElt_NatEn) == ModelConstr_AllocConstr) &&
		(GET_FLAG(ESEPtr, ExtStratElt_FixedCellFlg) == TRUE))
        return(ret);

    /*  Currency is only editable for amount        */  /*  FIH-REF11350-PMSTA00236-060203 */
	if ((field == ExtStratElt_RefCurrId) &&
		(GET_ENUM(ESEPtr, ExtStratElt_ConstrBoundNatEn) != ModelConstrEltBoundNat_Amt))
        return(ret);

    *enableFlg = TRUE;

    return(ret);
}

/*************************************************************************************
*   Function             : FIN_StratCheckUpd()
*
*   Description          : Check if the current ESE field can be updated
*
*   Arguments            : stratHierPtr     : Strategy hierarchy header.
*                          ESEPtr           : Extended strategy element pointer
*                                             selected.
*                          enableFlg        : Flag pointer
*                                             - TRUE if the update operation is allowed
*                                             - FALSE elsewhere
*
*   Return               : RET_SUCCEED or error code
*
*   Creation Date        : REF4047 - 000103 - SKE
*
**************************************************************************************/
RET_CODE FIN_StratCheckUpd(DBA_HIER_HEAD_STP    stratHierPtr,
                           DBA_DYNFLD_STP       ESEPtr,
                           int                  field,
                           FLAG_T              *enableFlg)
{
    RET_CODE        ret     = RET_SUCCEED;
    DBA_DYNFLD_STP *ESETab  = NULLDYNSTPTR;
    int             ESENbr  = 0;
    int             i;

    if (stratHierPtr    == (DBA_HIER_HEAD_STP)NULL  ||
        enableFlg       == (FLAG_T*)NULL            ||
        ESEPtr          == NULLDYNST)
    {
        MSG_RETURN(RET_GEN_ERR_INVARG);
    }

    *enableFlg = FALSE;

    if (IS_NULLFLD(ESEPtr, ExtStratElt_Level) == TRUE)
        return(ret);

    if (GET_TINYINT(ESEPtr, ExtStratElt_Level) <= 0)
        return(ret);

    if (GET_ENUM(ESEPtr, ExtStratElt_StratNatEn) == (ENUM_T) StratNat_Alloc)
    {
        /*
            In case of Allocation, the following fields can't
            be updated
        */
        if (field == ExtStratElt_InstrId    ||
            field == ExtStratElt_Rank       ||
            field == ExtStratElt_ObjWeightContribMarg)
        {
            return(ret);
        }
    }

    /* <REF4864 SKE 000605 */
    if (GET_ENUM(ESEPtr, ExtStratElt_StratNatEn) == (ENUM_T) StratNat_ModelPtf)
    {
        if (field == ExtStratElt_BenchEntDictId ||
            field == ExtStratElt_BenchObjId)
        {
            if (GET_ENUM(ESEPtr, ExtStratElt_NatEn) != (ENUM_T)ExtStratEltNat_BreakCriteria)
            {
                return(ret);
            }
        }
        if (field == ExtStratElt_ActualWeight       ||  /* SKE 000913 REF5192 */
            field == ExtStratElt_ActualWeightContrib)   /* SKE 000913 REF5192 */
        {
            return(ret);
        }
    }

    if (GET_ENUM(ESEPtr, ExtStratElt_StratNatEn) == (ENUM_T) StratNat_RecomList)
    {
        if (field == ExtStratElt_RecomNatEn)
        {
            if (GET_ENUM(ESEPtr, ExtStratElt_NatEn) == (ENUM_T)ExtStratEltNat_BreakCriteria)
            {
                return(ret);
            }
        }
        if (field == ExtStratElt_BenchEntDictId ||
            field == ExtStratElt_BenchObjId     ||
            field == ExtStratElt_ActualWeight   ||      /* SKE 000913 REF5192 */
            field == ExtStratElt_ActualWeightContrib)   /* SKE 000913 REF5192 */
        {
            return(ret);
        }
    }
    /* REF4864 SKE 000605> */

    if (GET_TINYINT(ESEPtr, ExtStratElt_Level) == 1)
    {
        /* <REF4584 - 000425 - SKE */
        if (GET_ENUM(ESEPtr, ExtStratElt_StratNatEn) == StratNat_RecomList)
        {
            return(ret);
        }
        /* REF4584 - 000425 - SKE> */
        /*  In case of level 1 the following columns can't be updated,
            wathever the nature.
        */
        if (field == ExtStratElt_ObjWeight          ||
            field == ExtStratElt_ObjWeightContrib   ||
            field == ExtStratElt_ObjBetaContrib     ||
            field == ExtStratElt_ObjDuraContrib     ||
            field == ExtStratElt_ObjCrtYieldContrib ||
            /* SKE 001214
            field == ExtStratElt_BenchEntDictId     ||
            */
            field == ExtStratElt_ActualWeight       ||  /* SKE 000913 REF5192 */
            field == ExtStratElt_ActualWeightContrib ||	/* SKE 000913 REF5192 */
			field == ExtStratElt_InstrId)				/* MRA - 021105 - REF8302 */
        {
            return(ret);
        }
    }
    else
    {
        /* The following columns can't be updated on an intermediate level */
        if (field == ExtStratElt_ObjWeight          ||
            field == ExtStratElt_ObjWeightContrib   ||
            field == ExtStratElt_ObjBetaContrib     ||
            field == ExtStratElt_ObjDuraContrib     ||
            field == ExtStratElt_InstrId            ||
            field == ExtStratElt_ObjCrtYieldContrib ||
			field == ExtStratElt_Rank               ||
            field == ExtStratElt_MaxWeightContrib   ||
            field == ExtStratElt_ActualWeight       ||  /* SKE 000913 REF5192 */
            field == ExtStratElt_ActualWeightContrib)   /* SKE 000913 REF5192 */
        {
            /* A break criteria is always an intermediate level */
            if(GET_ENUM(ESEPtr, ExtStratElt_NatEn) == ExtStratEltNat_BreakCriteria)
            {
                return(ret);
            }

            if ((ret = DBA_ExtractHierEltRec(stratHierPtr,
                                             ExtStratElt,
                                             FALSE,
				                             NULLFCT,
                                             NULLFCT,
				                             &ESENbr,
                                             &ESETab)) != RET_SUCCEED)
            {
                return(ret);
            }
            for (i=0 ; i < ESENbr ; i++)
            {
                if (IS_NULLFLD(ESETab[i], ExtStratElt_ParExtStratEltId) == TRUE) continue;
                if (GET_ID(ESEPtr, ExtStratElt_Id) == GET_ID(ESETab[i], ExtStratElt_ParExtStratEltId)&&
                    GET_ID(ESEPtr, ExtStratElt_StratId) == GET_ID(ESETab[i], ExtStratElt_StratId))
                {
                    FREE(ESETab);
                    return(ret);
                }
            }
            FREE(ESETab);
        }
    }

    *enableFlg = TRUE;

    return(ret);
}

/************************************************************************
*************** INSERT UPDATE DELETE ************************************
*************************************************************************/
/************************************************************************
**
**  Function    :   FIN_InsUpdStratData
**
**  Description :   Update extended strategy element (+ strategy element(s)) and parent(s).
**
**  Arguments   :   stratHierPtr	strategy hierarchy eader pointer
**					ESEPtr			extended strategy element to update
**					action          action to perfome with given ExtStratElt.
**                  field			modified field (update A_StratElt according to is value)
**					fct				Function to be called for each updated line
**					context			Context to transmit with given fct
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation	:	RAK - 990719 - REF3729
**  Modif.		:   ROI - 990909 - REF3729
**
*************************************************************************/
RET_CODE FIN_InsUpdStratData(DBA_HIER_HEAD_STP      stratHierPtr,
                             DBA_DYNFLD_STP         ESEPtr,
                             DBA_ACTION_ENUM        action,
                             int                    field,
                             int                    (*fct)(PTR , DBA_DYNFLD_STP, FLAG_T*),
                             PTR                    context,
                             FLAG_T                *dfltValTab,
                             FLAG_T                 keepAllStratEltFlg) /* PMSTA-27076 - CHU - 170626 */
{
    RET_CODE ret = RET_SUCCEED;


    switch(action)
    {
        case Insert:
            ret = FIN_StratInsStratElt(stratHierPtr,
                                       ESEPtr,
                                       (ID_T*) context);
            if (ret != RET_SUCCEED)
                return(ret);
            break;
        case Update:
            ret = FIN_StratUpdRecAndParent(stratHierPtr,
                                           ESEPtr,
                                           action,
                                           field,
                                           UNUSED,
                                           UNUSED,
                                           fct,
                                           context,
                                           dfltValTab,
                                           keepAllStratEltFlg); /* PMSTA-27076 - CHU - 170626 */
            if (ret != RET_SUCCEED)
                return(ret);
	        ret = FIN_StratUpdHierAndValue(stratHierPtr,
                                           ESEPtr,
                                           action,
                                           field,
                                           UNUSED,
                                           UNUSED,
                                           keepAllStratEltFlg); /* PMSTA-27076 - CHU - 170626 */
            if (ret != RET_SUCCEED)
                return(ret);
            /*
                REF4047 - 20000207 - SKE :
                Update children contribution
            */
            ret = FIN_StratUpdAllSubStratContrib(stratHierPtr,
                                                 ESEPtr,
                                                 field,
                                                 UNUSED,
                                                 UNUSED,
                                                 fct,
                                                 context);
            if (ret != RET_SUCCEED)
                return(ret);
            break;
        case Delete:
            /* Update hierarchy information and A_StratElt value for database update */
            ret = FIN_StratUpdRecAndParent(stratHierPtr,
                                           ESEPtr,
                                           action,
                                           field,
                                           UNUSED,
                                           UNUSED,
                                           fct,
                                           context,
                                           dfltValTab,
                                           FALSE);
            if (ret != RET_SUCCEED)
                return(ret);
	        ret = FIN_StratUpdHierAndValue(stratHierPtr,
                                           ESEPtr,
                                           action,
                                           field,
                                           UNUSED,
                                           UNUSED,
                                           FALSE); /* PMSTA-27076 - CHU - 170626 */

            if (ret != RET_SUCCEED)
                return(ret);
            break;
	}
    return(ret);
}

/************************************************************************
**
**  Function    :   FIN_StratCmpESLStratId()
**
**  Description :   Extended strategy link table is sort by strategy and
**                  level
**
**  Arguments   :   ptr1   pointer on dynamic structure type ExtPos
**                  ptr2   pointer on dynamic structure type ExtPos
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation Date : REF7420 - RAK - 021024
**
*************************************************************************/
STATIC int FIN_StratCmpESLStratId(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
    int cmp;

    if (( cmp = CMP_DYNFLD((*ptr1), (*ptr2), ExtStratLnk_StratId, ExtStratLnk_StratId, IdType)) != 0)
    {
        return(cmp);
    }

    return (GET_TINYINT((*ptr1), ExtStratLnk_Level) - GET_TINYINT((*ptr2), ExtStratLnk_Level));

}

/************************************************************************
**      END  finlib08.c
*************************************************************************/

/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef CALLSTACK_H
#define CALLSTACK_H

#include <string>

#define FORMAT_NOADDRESS 1

/************************************************************************
**
** Independent operating system interfaces for the callstack
**
*************************************************************************/

extern void SYS_InitCallStack(void);
extern void SYS_RemoveCallStack(void);

extern void SYS_SetCallStackFormat(int value);  /* DLA - PMSTA-27649 - 170705 */
extern int  SYS_GetCallStackFormat();           /* DLA - PMSTA-27649 - 170705 */

extern void SYS_EnableCallStack(void);          /* PMSTA-25852 - 110117 - PMO */
extern void SYS_DisableCallStack(void);         /* PMSTA-25852 - 110117 - PMO */

extern bool        SYS_IsCallStackEnable(void);
extern std::string SYS_GetCallStack(int = 0, bool = false);      /* PMSTA-21983 - 181215 - PMO */

extern bool   OS_InitCallStack(void);
extern void   OS_InitializationCallStack(void);
extern void   OS_RemoveCallStack(void);

#endif	 /* ifndef CALLSTACK_H */

/************************************************************************
**      END        callstack.h                                    
*************************************************************************/

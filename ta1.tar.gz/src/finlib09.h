/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef FINLIB09_H
#define FINLIB09_H

/************************************************************************
**      BEGIN : Global variables & external definitions attached to finlib09.c
*************************************************************************/
#ifdef  EXTERN
    #undef  EXTERN
#endif
#ifdef  FINLIB09_C
    #define	EXTERN
#else
    #define EXTERN extern
#endif

EXTERN RET_CODE FIN_StratUpdRecAndParent(DBA_HIER_HEAD_STP,
										 DBA_DYNFLD_STP,
										 DBA_ACTION_ENUM,
										 int,
										 int,
										 int*,
										 int (*)(PTR , DBA_DYNFLD_STP, FLAG_T*),  /* REF7264 - LJE - 020130 */
										 PTR,
										 FLAG_T*,
                                         FLAG_T); /* PMSTA-27076 - CHU - 170626 */

EXTERN RET_CODE FIN_StratUpdHierAndValue(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, DBA_ACTION_ENUM, int, int, int*, FLAG_T); /* PMSTA-27076 - CHU - 170626 */
EXTERN RET_CODE FIN_StratUpdAllSubStratContrib(DBA_HIER_HEAD_STP,
											   DBA_DYNFLD_STP,
											   int,
											   int,
											   int*,
											   int (*)(PTR , DBA_DYNFLD_STP, FLAG_T*),  /* REF7264 - LJE - 020130 */
											   PTR);

#endif /* FINLIB09_H */


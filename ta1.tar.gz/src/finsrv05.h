/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef FINSRV05_H
#define FINSRV05_H

/************************************************************************
**      BEGIN : Global definitions attached to finsrv05.c
*************************************************************************/
#ifdef  EXTERN
#undef  EXTERN
#endif
#ifdef  FINSRV05_C
#define	EXTERN
#else
#define EXTERN extern
#endif

EXTERN RET_CODE FIN_NewAnalysisReturn(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP);	/* DVP261 */
EXTERN RET_CODE FIN_SynthAdmin(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP,
                               PA_INFO_STP);  /* REF7395 - CSY - 020315 used in portfolio storage */

/* PMSTA02013 - RAK - 071112 */
EXTERN RETURNINPARENTPTFRULE_ENUM FIN_GetPtfReturnInParentRule(DBA_DYNFLD_STP, DBA_DYNFLD_STP);
EXTERN RETURNINPARENTPTFRULE_ENUM FIN_GetPtfReturnInParentRuleUsingPSP(DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP);

#endif /* FINSRV05_H */


/************************************************************************
**
**           Copyright (C) 1995-2024 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/
#ifdef NTWIN
#pragma warning (push)
#endif

#include "unidef.h"
#include "dba.h"

#include "ddlgen.h"
#include "dbibinddatadef.h"

#include "ZipFile.h"
#include "QDir"

#ifdef NTWIN
#pragma warning (pop)
#endif


class EntityProfileHelper
{
    /**
     * The EntityProfileHelper's constructor/destructor should always be private to
     * prevent direct construction/destruction calls with the `new`/`delete`
     * operator.
     */
private:
    static EntityProfileHelper* m_pinstance;
    static Lock m_lock;

protected:

    EntityProfileHelper()
    {
    }
    ~EntityProfileHelper()
    {
    }

public:
    EntityProfileHelper(EntityProfileHelper& other) = delete;
    void operator=(const EntityProfileHelper&) = delete;

    static EntityProfileHelper* getInstance();

    DBA_DYNFLD_STP getEntityProfileStp(std::string entityProfileCd, MemoryPool& mp)
    {
        LockGuard lockGuard(m_lock);

        DBA_DYNFLD_STP entityProfileStp = nullptr;
        auto it = this->m_entityProfileByCdMap.find(entityProfileCd);
        if (it == this->m_entityProfileByCdMap.end())
        {
            entityProfileStp = this->m_mp.allocDynst(FILEINFO, A_EntityProfile);
            SET_CODE(entityProfileStp, A_EntityProfile_Cd, entityProfileCd.c_str());
            this->getEntityProfileStp(entityProfileStp);
                
        }
        else
        {
            entityProfileStp = it->second;
        }

        return EntityProfileHelper::getCopyDynStFull(entityProfileStp, mp);
    }

    DBA_DYNFLD_STP getEntityProfileStp(ID_T entityProfileId, MemoryPool& mp)
    {
        LockGuard lockGuard(m_lock);
        
        DBA_DYNFLD_STP entityProfileStp = nullptr;
        auto it = this->m_entityProfileByIdMap.find(entityProfileId);
        if (it == this->m_entityProfileByIdMap.end())
        {
            entityProfileStp = this->m_mp.allocDynst(FILEINFO, A_EntityProfile);
            SET_ID(entityProfileStp, A_EntityProfile_Id, entityProfileId);
            this->getEntityProfileStp(entityProfileStp);
        }
        else
        {
            entityProfileStp = it->second;
        }

        return EntityProfileHelper::getCopyDynStFull(entityProfileStp, mp);
    }

    static DBA_DYNFLD_STP getCopyDynStFull(DBA_DYNFLD_STP recordStp, MemoryPool &mp)
    {
        auto copyRecordStp = mp.duplicate(FILEINFO, recordStp);

        auto dictEntityStp = recordStp->getDictEntityStp();

        for (auto& dictAttribStp : dictEntityStp->logicalTab)
        {
            if (IS_NOTNULL(recordStp, dictAttribStp->progN) &&
                GET_EXTENSION_PTR(recordStp, dictAttribStp->progN) != nullptr &&
                GET_EXTENSION_NBR(recordStp, dictAttribStp->progN) > 0)
            {
                auto recordTab = GET_EXTENSION_PTR(recordStp, dictAttribStp->progN);
                auto recordNbr = GET_EXTENSION_NBR(recordStp, dictAttribStp->progN);

                auto copyRecordTab = static_cast<DBA_DYNFLD_STP*>(CALLOC(recordNbr, sizeof(DBA_DYNFLD_STP)));
                DBA_DYNST_ENUM  subRecordsDynStEn = NullDynSt;

                for (int i = 0; i < recordNbr; ++i)
                {
                    if (recordTab[i] != nullptr)
                    {
                        copyRecordTab[i] = EntityProfileHelper::getCopyDynStFull(recordTab[i], mp);

                        if (subRecordsDynStEn == NullDynSt)
                        {
                            if (dictAttribStp->progN != GET_FLD_FK(recordTab[i]->getDynStEn()))
                            {
                                subRecordsDynStEn = recordTab[i]->getDynStEn();
                            }
                            else
                            {
                                subRecordsDynStEn = Io_Ext;
                            }
                        }
                    }
                }

                SET_EXTENSION(copyRecordStp, dictAttribStp->progN, copyRecordTab, subRecordsDynStEn, recordNbr);
            }
        }

        return copyRecordStp;
    }

protected:

    void getEntityProfileStp(DBA_DYNFLD_STP entityProfileStp)
    {
        DbiConnectionHelper   dbiConnHelper;

        if (dbiConnHelper.isValidAndInit())
        {
            BuildBindOption buildBindOption;
            buildBindOption = BuildBindOption::Categ::ExportFullObject;
            buildBindOption.setConfig("entity_profile", "parent_profile_id", "all", EntityConfigElementRuleEn::Keep);
            subQueryMapType subQueryMap;

            DBA_FillFullRecord(entityProfileStp,
                               buildBindOption,
                               this->m_mp,
                               dbiConnHelper,
                               subQueryMap);

            if (IS_NOTNULL(entityProfileStp, A_EntityProfile_Cd))
            {
                this->m_entityProfileByCdMap[GET_CODE(entityProfileStp, A_EntityProfile_Cd)] = entityProfileStp;
            }
            this->m_entityProfileByIdMap[GET_ID(entityProfileStp, A_EntityProfile_Id)] = entityProfileStp;
        }
    }

    std::map<std::string, DBA_DYNFLD_STP> m_entityProfileByCdMap;
    std::map<ID_T, DBA_DYNFLD_STP>        m_entityProfileByIdMap;
    MemoryPool                            m_mp;
};

/**
 * Static methods should be defined outside the class.
 */

EntityProfileHelper* EntityProfileHelper::m_pinstance{ nullptr };
Lock EntityProfileHelper::m_lock;

EntityProfileHelper* EntityProfileHelper::getInstance()
{
    LockGuard lockGuard(m_lock);
    if (m_pinstance == nullptr)
    {
        m_pinstance = new EntityProfileHelper();
    }
    return m_pinstance;
}


/************************************************************************
**
**  Function    :   BuildBindOption::~BuildBindOption
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**
**  Last modif. :   PMSTA-46681 - LJE - 240918
**
*************************************************************************/
BuildBindOption::~BuildBindOption()
{
    if (this->m_bProcessingResultLevel &&
        this->m_processingResultStp != nullptr)
    {
        DBA_DYNFLD_STP* msgTab = GET_EXTENSION_PTR(this->m_processingResultStp, A_ProcessingResult_ProcessingMessage);
        int             msgNbr = GET_EXTENSION_NBR(this->m_processingResultStp, A_ProcessingResult_ProcessingMessage);

        for (int i = 0; i < msgNbr; ++i)
        {
            FREE_DYNST(msgTab[i],  A_ProcessingMessage);
        }
    }
}

/************************************************************************
**
**  Function    :   BuildBindOption::setObjectEn
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**
**  Last modif. :   PMSTA-46681 - LJE - 230913
**
*************************************************************************/
void BuildBindOption::setObjectEn(OBJECT_ENUM objectEn, DbiBindDataDef *dbiBindDataDefPtr)
{
    this->m_currentObjectEn = objectEn;

    if (dbiBindDataDefPtr != nullptr &&
        dbiBindDataDefPtr->m_dictEntityStp != nullptr)
    {
        this->m_dictEntityStp = dbiBindDataDefPtr->m_dictEntityStp;
    }
    else
    {
        this->m_dictEntityStp = DBA_GetDictEntitySt(this->m_currentObjectEn);
    }

    this->setDynStEn(GET_EDITGUIST(this->m_currentObjectEn));
}


/************************************************************************
**
**  Function    :   BuildBindOption::setDynStEn
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**
**  Last modif. :   PMSTA-46681 - LJE - 230913
**
*************************************************************************/
void BuildBindOption::setDynStEn(DBA_DYNST_ENUM dynStEn)
{
    if (dynStEn != this->m_currentDynStEn)
    {
        auto objecEn = GET_OBJ_DYNST(dynStEn);
        if (objecEn != this->m_currentObjectEn)
        {
            this->setObjectEn(objecEn);
        }

        this->m_currentDynStEn = dynStEn;
    }
}

/************************************************************************
**
**  Function    :   BuildBindOption::fixOutputMode
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**
**  Last modif. :   PMSTA-46681 - LJE - 240708
**
*************************************************************************/
void BuildBindOption::fixExportCateg(Categ& optionCategory) const
{
    if (optionCategory == Categ::ExportFullObject)
    {
        auto currOutputModeEn = this->getOutputMode();
        switch (currOutputModeEn)
        {
            case EntityConfigOutputModeEn::FirstLevel:
                optionCategory = Categ::MdAttributeBk;
                break;

            case EntityConfigOutputModeEn::BusinessKey:
                optionCategory = this->getBusinessKeyOnlyCateg();
                break;

            case EntityConfigOutputModeEn::FullLevel:
                break;

            case EntityConfigOutputModeEn::FullForNew:
                if (this->m_currentRecordStp != nullptr)
                {
                    auto idIdx = (this->getFieldIdx() == Null_Dynfld ? this->m_currentRecordStp->getIdIdx() : this->getFieldIdx());

                    if (idIdx != Null_Dynfld &&
                        IS_NOTNULL(this->m_currentRecordStp, idIdx) &&
                        GET_ID(this->m_currentRecordStp, idIdx) > 0)
                    {
                        optionCategory = this->getBusinessKeyOnlyCateg();
                    }
                }
                break;
        }
    }
}

/************************************************************************
**
**  Function    :   BuildBindOption::setRecordStp
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**
**  Last modif. :   PMSTA-46681 - LJE - 240409
**
*************************************************************************/
void BuildBindOption::setRecordStp(DBA_DYNFLD_STP recordStp)
{
    if (recordStp == nullptr)
    {
        this->m_currentRecordStp = nullptr;
        this->m_currentDynStEn   = NullDynSt;
        this->m_currentObjectEn  = NullEntity;
        this->m_dictEntityStp    = nullptr;
    }
    else if (this->m_currentRecordStp != recordStp)
    {
        this->m_currentRecordStp = recordStp;

        this->setDynStEn(this->m_currentRecordStp->getDynStEn());

        if (this->m_currentRecordStp->getIdIdx() != Null_Dynfld)
        {
            this->m_objectPathMap[this->m_currentRecordStp->getObjectEn()].insert(GET_ID(this->m_currentRecordStp, this->m_currentRecordStp->getIdIdx()));
        }

        this->fixExportCateg(this->m_optionCategory);
    }
}

/************************************************************************
**
**  Function    :   BuildBindOption::setPckDefStp
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**
**  Last modif. :   PMSTA-46681 - LJE - 240812
**
*************************************************************************/
void BuildBindOption::setPckDefStp(DBA_DYNFLD_STP pckDefStp)
{
    this->m_currentPckDefStp = pckDefStp;
}


/************************************************************************
**
**  Function    :   BuildBindOption::setInitialDVDynStp
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**
**  Last modif. :   PMSTA-46259 - LJE - 211004
**
*************************************************************************/
void BuildBindOption::setInitialDVDynStp(DBA_DYNFLD_STP recordStp)
{
    this->m_currentInitialDVDynStp = nullptr;

    if (recordStp != nullptr &&
        ((this->getExportMode() == EntityConfigExportModeEn::NotInitialValue ||
          this->getExportMode() == EntityConfigExportModeEn::NotNull ||
          this->getExportMode() == EntityConfigExportModeEn::NotNullOnly) &&
         this->getCateg() != Categ::ExportCopyObject &&
         this->isBusinessKey() == false &&
         recordStp->isAllDynSt()))
    {
        DBA_DYNST_ENUM  dynStEn       = GET_DYNSTENUM(recordStp);
        OBJECT_ENUM     objectEn      = GET_DYNST_ENTITY(dynStEn);
        DICT_ENTITY_STP dictEntityStp = DBA_GetDictEntitySt(objectEn);

        if (dictEntityStp != nullptr)
        {
            this->setObjectEn(objectEn);

            std::stringstream    ivKey;
            ivKey << dictEntityStp->mdSqlName << "~";
            if (dictEntityStp->isNullNatIndex == false)
            {
                ivKey << static_cast<int>(GET_ENUM(recordStp, dictEntityStp->natIndex)) << "~";
            }
            else if (dynStEn == A_XdAttrib)
            {
                ivKey << GET_DICT(recordStp, A_XdAttrib_DataTpDictId) << "~";
            }

            auto& initialDVDynStp = this->m_initialDVDynMap[ivKey.str()];

            if (initialDVDynStp != nullptr &&
                initialDVDynStp->getDynStEn() != recordStp->getDynStEn())
            {
                this->m_mp.freeDynStp(initialDVDynStp);
            }

            if (initialDVDynStp == nullptr)
            {
                initialDVDynStp = this->m_mp.allocDynst(FILEINFO, GET_DYNSTENUM(recordStp));

                if (dictEntityStp->isNullNatIndex == false)
                {
                    COPY_DYNFLD(initialDVDynStp, dynStEn, dictEntityStp->natIndex, recordStp, dynStEn, dictEntityStp->natIndex);
                }
                else if (dynStEn == A_XdAttrib)
                {
                    COPY_DYNFLD(initialDVDynStp, dynStEn, A_XdAttrib_DataTpDictId, recordStp, dynStEn, A_XdAttrib_DataTpDictId);
                }

                if (this->getExportMode() != EntityConfigExportModeEn::NotNullOnly)
                {
                    DBA_SetDfltEntityFld(objectEn, dynStEn, initialDVDynStp);

                    if (this->getExportMode() == EntityConfigExportModeEn::NotInitialValue)
                    {
                        DbiConnectionHelper dbiConnHelper;
                        if (dbiConnHelper.isValidAndInit())
                        {
                            RequestHelper requestHelper(dbiConnHelper);
                            requestHelper.computeDV(initialDVDynStp);
                        }
                    }
                }

                /* Define all fields as set */
                for (int fldPos = 0; fldPos < GET_FLD_NBR(dynStEn); ++fldPos)
                {
                    this->setFieldIdx(fldPos);

                    if (this->isVisible(initialDVDynStp, false))
                    {
                        SET_SETFLG_T(initialDVDynStp, fldPos);
                    }
                }
            }

            this->m_currentInitialDVDynStp = initialDVDynStp;

            if (dictEntityStp->isNullNatIndex == false &&
                CMP_DYNFLD(recordStp,
                           initialDVDynStp,
                           dictEntityStp->natIndex,
                           dictEntityStp->natIndex,
                           GET_FLD_DTP(recordStp, dictEntityStp->natIndex)) != 0)
            {
                this->setInitialDVDynStp(initialDVDynStp);
            }
        }
    }
}

/************************************************************************
**
**  Function    :   BuildBindOption::isForceStringOnArray
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**
**  Last modif. :   PMSTA-46681 - LJE - 230913
**
*************************************************************************/
const bool BuildBindOption::isForceStringOnArray() const
{
    if (this->m_bForceStringOnArray)
    {
        return true;
    }
    return false;
}

/************************************************************************
**
**  Function    :   BuildBindOption::showIdentity
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**
**  Last modif. :   PMSTA-46681 - LJE - 230913
**
*************************************************************************/
const bool BuildBindOption::showIdentity() const
{
    if (this->m_showIdentityMap.empty() == false)
    {
        auto it = this->m_showIdentityMap.find(this->getObjectEn());

        if (it == this->m_showIdentityMap.end() &&
            this->getObjectEn() != NullEntity)
        {
            it = this->m_showIdentityMap.find(NullEntity);
        }

        if (it != this->m_showIdentityMap.end())
        {
            switch (it->second)
            {
                case Config::Enable:
                    return true;
                    break;

                case Config::Disable:
                case Config::Null:
                default:
                    return false;
                    break;
            }
        }
    }

    return false;
}

/************************************************************************
**
**  Function    :   BuildBindOption::fixJSonString
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**
**  Last modif. :   PMSTA-46681 - LJE - 230913
**
*************************************************************************/
void BuildBindOption::fixJSonString(std::string &jsonString)
{
    std::map<std::string, std::string> convertMap;

    convertMap["`"]      = "\"";
    convertMap["&quot;"] = "\"";

    for (auto &it : convertMap)
    {
        std::string::size_type pos = 0;
        while ((pos = jsonString.find(it.first)) != std::string::npos)
        {
            jsonString.replace(pos, it.first.length(), it.second);
        }
    }
}

/************************************************************************
**
**  Function    :   BuildBindOption::getBusinessKeyOnlyCateg
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**
**  Last modif. :   PMSTA-46259 - LJE - 211004
**
*************************************************************************/
BuildBindOption::Categ BuildBindOption::getBusinessKeyOnlyCateg() const
{
    if (this->m_optionCategory == Categ::OutboxEvent)
    {
        return Categ::OutboxEventBusinessKeyOnly;
    }

    return Categ::BusinessKeyOnlyShort;
}

/************************************************************************
**
**  Function    :   BuildBindOption::getExportFullCateg
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**
**  Last modif. :   PMSTA-46259 - LJE - 211004
**
*************************************************************************/
BuildBindOption::Categ BuildBindOption::getExportFullCateg() const
{
    if (this->m_rootBuildBindOption == Categ::ExportCopyObject)
    {
        return Categ::ExportCopyObject;
    }

    return Categ::ExportFullObject;
}

/************************************************************************
**
**  Function    :   BuildBindOption::printBkOfReference
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**
**  Last modif. :   PMSTA-46259 - LJE - 211004
**
*************************************************************************/
bool BuildBindOption::printBkOfReference() const
{
    if (this->m_optionCategory == Categ::AllMdAttributeBk ||
        this->m_optionCategory == Categ::MdAttributeBk ||
        this->m_optionCategory == Categ::OutboxEvent ||
        this->isBusinessKey() ||
        (this->isImportExport() &&
         (this->getOutputMode() == EntityConfigOutputModeEn::BusinessKey ||
          this->getOutputMode() == EntityConfigOutputModeEn::Standard)))
    {
        return true;
    }
    return false;
}

/************************************************************************
**
**  Function    :   BuildBindOption::printAllRecord
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**
**  Last modif. :   PMSTA-46259 - LJE - 211004
**
*************************************************************************/
bool BuildBindOption::printAllRecord() const
{
    if (this->isImportExport() &&
        (this->getOutputMode() == EntityConfigOutputModeEn::FullLevel ||
         this->getOutputMode() == EntityConfigOutputModeEn::FirstLevel ||
         (this->getOutputMode() == EntityConfigOutputModeEn::FullForNew &&
          this->m_currentRecordStp != nullptr &&
          this->m_currentRecordStp->getIdIdx() > Null_Dynfld &&
          (IS_NULLFLD(this->m_currentRecordStp, this->m_currentRecordStp->getIdIdx()) ||
           GET_ID(this->m_currentRecordStp, this->m_currentRecordStp->getIdIdx()) < 0))))
    {
        return true;
    }
    return false;
}


/************************************************************************
**
**  Function    :   BuildBindOption::isVisible
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**
**  Last modif. :   PMSTA-46259 - LJE - 211004
**
*************************************************************************/
bool BuildBindOption::isVisible(DBA_DYNFLD_STP recordStp, bool bCheckNull)
{
    if (this->m_dictEntityStp != nullptr &&
        CAST_INT(this->m_dictEntityStp->attr.size()) > this->getFieldIdx())
    {
        auto dictAttribStp = this->m_dictEntityStp->attr[this->getFieldIdx()];

        if (dictAttribStp != nullptr)
        {
            if (recordStp != nullptr &&
                bCheckNull &&
                dictAttribStp->logicalFlg == FALSE &&
                *this != Categ::CleanUpFullObject &&
                _IS_NULLFLD(recordStp, this->getFieldIdx()) &&
                (IS_VALID_FLD_FK(recordStp) == false ||
                 GET_EXTENSION_PTR(recordStp, GET_FLD_FK(recordStp->getDynStEn()))[this->getFieldIdx()] == nullptr) &&
                (this->m_optionCategory == Categ::MdAttributeBk ||
                 this->isPrintNull() == false))
            {
                return false;
            }

            bool bVisible = true;

            if (this->isImportExport())
            {
                if (dictAttribStp->exportEn == Export_NotExported ||
                    dictAttribStp->calcEn   == DictAttr_PhysSpecUpd ||
                    (dictAttribStp->primFlg == TRUE && dictAttribStp->dictEntityStp->pkRuleEn != PkRule_NoIdentity &&  this->showIdentity() == false))
                {
                    bVisible = false;
                }

                if (dictAttribStp->custFlg == TRUE &&
                    this->showCustomAttributes() == false)
                {
                    bVisible = false;
                }

                if (dictAttribStp->precompFlg == TRUE &&
                    this->showPrecompAttributes() == false)
                {
                    bVisible = false;
                }
            }

            if (this->m_optionCategory == Categ::OutboxEvent)
            {
                return bVisible;
            }
            else
            {
                if (bVisible &&
                    (this->getExportMode() == EntityConfigExportModeEn::NotInitialValue ||
                     this->getExportMode() == EntityConfigExportModeEn::NotNull) &&
                    this->getInitialDVDynStp() != nullptr &&
                    recordStp != nullptr &&
                    CMP_DYNFLD(recordStp, this->getInitialDVDynStp(), this->getFieldIdx(), this->getFieldIdx(), GET_FLD_DTP(recordStp, this->getFieldIdx())) == 0)
                {
                    if ((dictAttribStp->primFlg == TRUE ||
                         dictAttribStp->busKeyFlg == TRUE ||
                         (this->m_dictEntityStp->isNullNatIndex == false &&
                          dictAttribStp->progN == this->m_dictEntityStp->natIndex)))
                    {
                        bVisible = true;
                    }
                    else
                    {
                        bVisible = false;
                    }
                }

                std::string keepScpt;
                if ((bVisible == false &&
                     this->getKeep(this->m_dictEntityStp->mdSqlName, dictAttribStp->sqlName, keepScpt) == false) ||
                    this->getSkip(this->m_dictEntityStp->mdSqlName, dictAttribStp->sqlName, keepScpt))
                {
                    return false;
                }
            }
        }
    }

    return true;
}

/************************************************************************
**
**  Function    :   BuildBindOption::isToDelete
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**
**  Last modif. :   PMSTA-46259 - LJE - 211004
**
*************************************************************************/
bool BuildBindOption::isToDelete(DBA_DYNFLD_STP recordStp, bool bUseCurrEntity) const
{
    if (DBA_isScriptObject(recordStp->getObjectEn()))
    {
        return false;
    }

    if (DBA_IsAnExtOperationObject(recordStp->getObjectEn()))
    {
        return false;
    }

    bool bToDelete = true;

    auto dictEntityStp = (bUseCurrEntity ? this->m_dictEntityStp : recordStp->getDictEntityStp());

    if (dictEntityStp != nullptr)
    {
        DICT_ATTRIB_STP dictAttribStp = nullptr;

        if (bUseCurrEntity &&
            this->getFieldIdx() != Null_Dynfld &&
            CAST_INT(dictEntityStp->attr.size()) > this->getFieldIdx())
        {
            dictAttribStp = dictEntityStp->attr[this->getFieldIdx()];
        }

        std::string attribSqlName("all");
        if (dictAttribStp != nullptr)
        {
            attribSqlName = dictAttribStp->sqlName;
        }

        std::string cleanUpScript;
        if (this->getCleanUp(dictEntityStp->mdSqlName, attribSqlName, cleanUpScript))
        {
            if (cleanUpScript.empty() || cleanUpScript == "all" || cleanUpScript == "provided")
            {
                bToDelete = true;
            }
            else if (cleanUpScript == "none" || cleanUpScript == "auto")
            {
                bToDelete = false;
            }
            else
            {
                bToDelete = DBA_EvalCheckScript(cleanUpScript.c_str(), recordStp);
            }
        }
        else if (dictAttribStp != nullptr &&
                 dictAttribStp->refDeleteRuleEn == RefDelRule_CascadeDelete)
        {
            bToDelete = true;
        }

        std::string skipScpt;
        if (dictEntityStp != nullptr &&
            dictAttribStp != nullptr &&
            this->getSkip(dictEntityStp->mdSqlName, dictAttribStp->sqlName, skipScpt))
        {
            if (skipScpt.empty() || skipScpt == "all")
            {
                bToDelete = false;
            }
            else if (skipScpt == "none")
            {
                bToDelete = true;
            }
            else
            {
                bToDelete = DBA_EvalCheckScript(skipScpt.c_str(), recordStp) == false;
            }
        }

        if (bToDelete && bUseCurrEntity)
        {
            bToDelete = this->isToModify(recordStp);

            if (bToDelete)
            {
                bToDelete = this->isToDelete(recordStp, false);
            }
        }
    }
    return bToDelete;
}

/************************************************************************
**
**  Function    :   BuildBindOption::isToModify
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**
**  Last modif. :   PMSTA-46681 - LJE - 240226
**
*************************************************************************/
bool BuildBindOption::isToModify(DBA_DYNFLD_STP recordStp) const
{
    bool bToModify = true;

    std::string skipScpt;
    auto dictEntityStp = recordStp->getDictEntityStp();

    if (dictEntityStp != nullptr &&
        this->getSkip(dictEntityStp->mdSqlName, "all", skipScpt))
    {
        if (skipScpt.empty() || skipScpt == "all")
        {
            bToModify = false;
        }
        else if (skipScpt == "none")
        {
            bToModify = true;
        }
        if (dictEntityStp->isId() == false ||
            GET_ID(recordStp, recordStp->getIdIdx()) > 0)
        {
            if (skipScpt != "exists")
            {
                bToModify = DBA_EvalCheckScript(skipScpt.c_str(), recordStp) == false;
            }
        }
    }
    return bToModify;
}

/************************************************************************
**
**  Function    :   BuildBindOption::fillConfig
**
**  Description :
**
**  Arguments   :
**
**
**
**
**  Return      :
**
**
**  Last modif. :   PMSTA-46681 - LJE - 211208
**
*************************************************************************/
void BuildBindOption::fillConfig(DBA_DYNFLD_STP recordStp)
{
    if (recordStp != nullptr)
    {
        auto dynStEn = recordStp->getDynStEn();

        switch (recordStp->getObjectCst())
        {
            case ExportQueryCst:
            case CopyArgCst:
            {
                this->clearConfig();

                auto dictEntityStp = recordStp->getDictEntityStp();
                if (dictEntityStp != nullptr)
                {
                    this->setConfig(dictEntityStp->mdSqlName, "entity_profile_id", "all", EntityConfigElementRuleEn::Keep);
                    this->setConfig(dictEntityStp->mdSqlName, "entity_profile_id", "Full For New", EntityConfigElementRuleEn::OutputMode);

                    this->setConfig("entity_profile", "parent_profile_id", "all", EntityConfigElementRuleEn::Keep);
                    this->setConfig("entity_profile", "parent_profile_id", "Full For New", EntityConfigElementRuleEn::OutputMode);

                    auto entityProfileIdIdx = (dynStEn == A_ExportQuery ? A_ExportQuery_EntityProfileId : A_CopyArg_EntityProfileId);

                    if (dynStEn == A_CopyArg)
                    {
                        this->setConfig(dictEntityStp->mdSqlName, "from_id", "all", EntityConfigElementRuleEn::Keep);
                        this->setConfig(dictEntityStp->mdSqlName, "to_id", "all", EntityConfigElementRuleEn::Keep);
                    }
                    else
                    {
                        this->setConfig(dictEntityStp->mdSqlName, "export_object", "all", EntityConfigElementRuleEn::Keep);
                    }

                    this->setConfig("entity_profile", "Identity", "", EntityConfigElementRuleEn::Skip);
                    this->setConfig("entity_config", "Identity", "", EntityConfigElementRuleEn::Skip);
                    this->setConfig("entity_config_element", "Identity", "", EntityConfigElementRuleEn::Skip);

                    if (GET_EXTENSION_PTR(recordStp, GET_FLD_FK(dynStEn)) == nullptr)
                    {
                        int             subRecordsNbr = static_cast<int>(dictEntityStp->attr.size());
                        DBA_DYNFLD_STP *subRecordsTab = static_cast<DBA_DYNFLD_STP *>(CALLOC(subRecordsNbr, sizeof(DBA_DYNFLD_STP)));
                        DBA_DYNST_ENUM  subRecordsDynStEn = Io_Ext;
                        SET_EXTENSION(recordStp, GET_FLD_FK(dynStEn), subRecordsTab, subRecordsDynStEn, subRecordsNbr);
                    }

                    if (IS_NULLFLD(recordStp, entityProfileIdIdx) == false &&
                        GET_EXTENSION_PTR(recordStp, GET_FLD_FK(dynStEn)) != nullptr &&
                        GET_EXTENSION_PTR(recordStp, GET_FLD_FK(dynStEn))[entityProfileIdIdx] == nullptr)
                    {
                        auto &entityProfileStp = this->m_entityProfileMap[GET_ID(recordStp, entityProfileIdIdx)];

                        if (entityProfileStp == nullptr)
                        {
                            this->printMsg(ProcessingMessageNatEn::Debug, RET_SUCCEED, SYS_Stringer("Load profile ", GET_ID(recordStp, entityProfileIdIdx)));

                            entityProfileStp = EntityProfileHelper::getInstance()->getEntityProfileStp(GET_ID(recordStp, entityProfileIdIdx), this->m_mp);

                            if (entityProfileStp != nullptr)
                            {
                                GET_EXTENSION_PTR(recordStp, GET_FLD_FK(dynStEn))[entityProfileIdIdx] = entityProfileStp;
                            }
                        }
                    }

                    if (IS_VALID_FLD_FK(recordStp) &&
                        GET_EXTENSION_PTR(recordStp, GET_FLD_FK(dynStEn)) != nullptr &&
                        GET_EXTENSION_NBR(recordStp, GET_FLD_FK(dynStEn)) != 0)
                    {
                        if (GET_EXTENSION_PTR(recordStp, GET_FLD_FK(dynStEn))[entityProfileIdIdx] != nullptr)
                        {
                            if (IS_NULLFLD(GET_EXTENSION_PTR(recordStp, GET_FLD_FK(dynStEn))[entityProfileIdIdx], A_EntityProfile_Cd))
                            {
                                SET_CODE(GET_EXTENSION_PTR(recordStp, GET_FLD_FK(dynStEn))[entityProfileIdIdx], A_EntityProfile_Cd, "Custom");
                            }

                            this->printMsg(ProcessingMessageNatEn::Debug,
                                           RET_SUCCEED,
                                           SYS_Stringer("Fill config ", GET_CODE(GET_EXTENSION_PTR(recordStp, GET_FLD_FK(dynStEn))[entityProfileIdIdx], A_EntityProfile_Cd)));

                            this->fillConfig(GET_EXTENSION_PTR(recordStp, GET_FLD_FK(dynStEn))[entityProfileIdIdx]);
                        }
                    }

                    if (IS_NULLFLD(recordStp, entityProfileIdIdx))
                    {
                        MemoryPool mp;

                        if (this->getDefaultEntityProfileCode().empty())
                        {
                            this->setDefaultEntityProfileCode("SYS_PCK_CUSTO");
                        }
                        this->fillConfig(mp.allocDynst(FILEINFO, A_Empty));
                    }
                }
                break;
            }

            case EntityProfileCst:
            {
                std::string entityProfCd(IS_NOTNULL(recordStp, A_EntityProfile_Cd) ? GET_CODE(recordStp, A_EntityProfile_Cd) : "N/A");
                this->printMsg(ProcessingMessageNatEn::Debug, RET_SUCCEED, SYS_Stringer("EntityProfile ", entityProfCd));

                if (IS_NULLFLD(recordStp, A_EntityProfile_ParentProfileId) == false &&
                    IS_VALID_FLD_FK(recordStp) &&
                    GET_EXTENSION_PTR(recordStp, GET_FLD_FK(dynStEn)) != nullptr &&
                    GET_EXTENSION_PTR(recordStp, GET_FLD_FK(dynStEn))[A_EntityProfile_ParentProfileId] != nullptr)
                {
                    this->fillConfig(GET_EXTENSION_PTR(recordStp, GET_FLD_FK(dynStEn))[A_EntityProfile_ParentProfileId]);
                }

                if (IS_NULLFLD(recordStp, A_EntityProfile_EntityConfig) == FALSE &&
                    GET_EXTENSION_PTR(recordStp, A_EntityProfile_EntityConfig) != nullptr)
                {
                    DBA_DYNFLD_STP* configTab = GET_EXTENSION_PTR(recordStp, A_EntityProfile_EntityConfig);
                    int             configNbr = GET_EXTENSION_NBR(recordStp, A_EntityProfile_EntityConfig);

                    for (int i = 0; i < configNbr; ++i)
                    {
                        auto dictEntityStp = DBA_GetDictEntityByDictIdSafe(GET_DICT(configTab[i], A_EntityConfig_EntityDictId));

                        this->printMsg(ProcessingMessageNatEn::Debug, RET_SUCCEED, SYS_Stringer("Fill config ", dictEntityStp->mdSqlName));
                        this->fillConfig(configTab[i]);
                    }
                }

                this->printMsg(ProcessingMessageNatEn::Debug, RET_SUCCEED, SYS_Stringer("End EntityProfile ", entityProfCd));
                break;
            }

            case EntityConfigCst:
            {
                std::string entity;
                if (IS_NULLFLD(recordStp, A_EntityConfig_EntityDictId) == false)
                {
                    auto dictEntityStp = DBA_GetDictEntityByDictId(GET_DICT(recordStp, A_EntityConfig_EntityDictId));
                    if (dictEntityStp != nullptr)
                    {
                        entity = dictEntityStp->mdSqlName;

                        if (IS_NULLFLD(recordStp, A_EntityConfig_ExportModeEn) == false &&
                            GET_A_EntityConfig_ExportModeEn(recordStp) != EntityConfigExportModeEn::None)
                        {
                            this->setExportMode(dictEntityStp->objectEn, GET_A_EntityConfig_ExportModeEn(recordStp));
                        }

                        if (IS_NULLFLD(recordStp, A_EntityConfig_OutputModeEn) == false &&
                            GET_A_EntityConfig_OutputModeEn(recordStp) != EntityConfigOutputModeEn::None)
                        {
                            this->setOutputMode(dictEntityStp->objectEn, Null_Dynfld, GET_A_EntityConfig_OutputModeEn(recordStp));
                        }
                    }
                }
                else
                {
                    if (IS_NULLFLD(recordStp, A_EntityConfig_ExportModeEn) == false &&
                        GET_A_EntityConfig_ExportModeEn(recordStp) != EntityConfigExportModeEn::None)
                    {
                        this->setExportMode(NullEntity, GET_A_EntityConfig_ExportModeEn(recordStp));
                    }
                    if (IS_NULLFLD(recordStp, A_EntityConfig_OutputModeEn) == false &&
                        GET_A_EntityConfig_OutputModeEn(recordStp) != EntityConfigOutputModeEn::None)
                    {
                        this->setOutputMode(NullEntity, Null_Dynfld, GET_A_EntityConfig_OutputModeEn(recordStp));
                    }
                }

                this->printMsg(ProcessingMessageNatEn::Debug, RET_SUCCEED,
                               SYS_Stringer("Config modes "
                                            , DBA_GetDictEntityByDictIdSafe(GET_DICT(recordStp, A_EntityConfig_EntityDictId))->mdSqlName, "-"
                                            , static_cast<int>(this->getExportMode()), "-"
                                            , static_cast<int>(this->getOutputMode())));

                if (IS_NULLFLD(recordStp, A_EntityConfig_EntityConfigElement) == FALSE)
                {
                    DBA_DYNFLD_STP* filterTab = GET_EXTENSION_PTR(recordStp, A_EntityConfig_EntityConfigElement);
                    int              filterNbr = GET_EXTENSION_NBR(recordStp, A_EntityConfig_EntityConfigElement);

                    for (int i = 0; i < filterNbr; ++i)
                    {
                        this->setConfig(entity,
                                        GET_STRING(filterTab[i], A_EntityConfigElement_Key),
                                        IS_NULLFLD(filterTab[i], A_EntityConfigElement_Value) ? std::string() : GET_STRING(filterTab[i], A_EntityConfigElement_Value),
                                        GET_A_EntityConfigElement_RuleEn(filterTab[i]));
                    }
                }
                break;
            }

            default:
            {
                auto & entityProfileStp = this->m_entityProfileMap[0];

                if (entityProfileStp == nullptr)
                {
                    if (recordStp->getDynStEn() == O_PackageDefinition ||
                        recordStp->getDynStEn() == A_PackageDefinition ||
                        recordStp->getDynStEn() == A_PackageComposition)
                    {
                        this->setPackager();
                    }

                    entityProfileStp = EntityProfileHelper::getInstance()->getEntityProfileStp((this->getDefaultEntityProfileCode().empty() ?
                                                                                                (this->isPackager() ? "SYS_PCK_ALL" : "SYS_STD_ALL") :
                                                                                                this->getDefaultEntityProfileCode()), 
                                                                                               this->m_mp);

                    if (entityProfileStp != nullptr)
                    {
                        this->printMsg(ProcessingMessageNatEn::Debug, RET_SUCCEED, SYS_Stringer("Fill config ", GET_CODE(entityProfileStp, A_EntityProfile_Cd)));
                        this->fillConfig(entityProfileStp);
                    }
                }
            }
        }
    }
}

/************************************************************************
**
**  Function    :   BuildBindOption::clearConfig
**
**  Description :
**
**  Arguments   :
**
**
**
**
**  Return      :
**
**
**  Last modif. :   PMSTA-46681 - LJE - 211208
**
*************************************************************************/
void BuildBindOption::clearConfig()
{
    this->m_exportCleanUpMap.clear();
    this->m_exportFiltersMap.clear();
    this->m_exportKeepMap.clear();
    this->m_exportModeMap.clear();
    this->m_exportSkipMap.clear();
    this->m_exportAutoMap.clear();

    this->m_currentObjectEn = NullEntity;
    this->m_currentDynStEn  = NullDynSt;
    this->m_currentFieldIdx = Null_Dynfld;
}

/************************************************************************
**
**  Function    :   BuildBindOption::generateEntityConfig
**
**  Description :
**
**  Arguments   :
**
**
**
**
**  Return      :
**
**
**  Last modif. :   PMSTA-55800 - LJE - 240416
**
*************************************************************************/
void BuildBindOption::generateEntityConfig(DICT_T entityDictId, DBA_DYNFLD_STP entityProfileStp)
{
    auto dictEntityStp = DBA_GetDictEntityByDictId(entityDictId);

    if (dictEntityStp != nullptr)
    {
        auto keepMap = this->m_exportKeepMap[dictEntityStp->mdSqlName];
        auto skipMap = this->m_exportSkipMap[dictEntityStp->mdSqlName];

        for (auto &dictAttribStp : dictEntityStp->attr)
        {
            if (dictAttribStp->logicalFlg == TRUE)
            {
                std::string filter;
                auto        exportCateg = this->getExportFullCateg();
                bool        bToExportField = this->isExportedLogicalAttrib(dictAttribStp, nullptr, filter, exportCateg);

                if (exportCateg != BuildBindOption::Categ::Denied &&
                    exportCateg != BuildBindOption::Categ::NotExported)
                {
                    if (bToExportField &&
                        exportCateg == this->getExportFullCateg())
                    {
                        keepMap[dictAttribStp->sqlName] = (filter.empty() ? "all" : filter);
                    }
                    else
                    {
                        skipMap[dictAttribStp->sqlName] = (filter.empty() ? "all" : filter);
                    }
                }
            }
            else
            {
                std::string filter;
                auto        exportCateg = this->getExportFullCateg();
                bool        bToExportField = this->isExportedAttrib(dictAttribStp, nullptr, exportCateg);

                if (bToExportField &&
                    exportCateg == this->getExportFullCateg())
                {
                    keepMap[dictAttribStp->sqlName] = (filter.empty() ? "all" : filter);
                }
            }
        }

        if (entityProfileStp != nullptr)
        {
            auto entityConfigTab = GET_EXTENSION_PTR(entityProfileStp, A_EntityProfile_EntityConfig);
            auto entityConfigNbr = GET_EXTENSION_NBR(entityProfileStp, A_EntityProfile_EntityConfig);

            DBA_DYNFLD_STP entityConfigStp = nullptr;
            for (int i = 0; i < entityConfigNbr; ++i)
            {
                if (entityConfigTab[i] != nullptr &&
                    GET_DICT(entityConfigTab[i], A_EntityConfig_EntityDictId) == dictEntityStp->entDictId)
                {
                    entityConfigStp = entityConfigTab[i];
                    break;
                }
            }

            if (entityConfigStp == nullptr)
            { 
                entityConfigNbr = entityConfigNbr + 1;
                entityConfigTab = static_cast<DBA_DYNFLD_STP*>(REALLOC(entityConfigTab, entityConfigNbr * sizeof(DBA_DYNFLD_STP)));
                entityConfigStp = this->m_mp.allocDynst(FILEINFO, A_EntityConfig);
                entityConfigTab[entityConfigNbr - 1] = entityConfigStp;
                SET_DICT(entityConfigStp, A_EntityConfig_EntityDictId, entityDictId);

                SET_EXTENSION(entityProfileStp, A_EntityProfile_EntityConfig, entityConfigTab, A_EntityConfig, entityConfigNbr);
            }

            std::vector<DBA_DYNFLD_STP> entityConfEltVector;
            for (auto& it : keepMap)
            {
                auto entityConfEltStp = this->m_mp.allocDynst(FILEINFO, A_EntityConfigElement);
                entityConfEltVector.push_back(entityConfEltStp);

                SET_A_EntityConfigElement_RuleEn(entityConfEltStp, EntityConfigElementRuleEn::Keep);
                SET_STRING(entityConfEltStp, A_EntityConfigElement_Key, it.first.c_str());
                SET_STRING(entityConfEltStp, A_EntityConfigElement_Value, it.second.c_str());
            }
            for (auto& it : skipMap)
            {
                auto entityConfEltStp = this->m_mp.allocDynst(FILEINFO, A_EntityConfigElement);
                entityConfEltVector.push_back(entityConfEltStp);

                SET_A_EntityConfigElement_RuleEn(entityConfEltStp, EntityConfigElementRuleEn::Skip);
                SET_STRING(entityConfEltStp, A_EntityConfigElement_Key, it.first.c_str());
                SET_STRING(entityConfEltStp, A_EntityConfigElement_Value, it.second.c_str());
            }

            DBA_DYNFLD_STP *entityConfigEltTab = static_cast<DBA_DYNFLD_STP *>(CALLOC(entityConfEltVector.size(), sizeof(DBA_DYNFLD_STP)));
            int             entityConfigEltNbr = 0;

            for (auto& entityConfEltStp : entityConfEltVector)
            {
                entityConfigEltTab[entityConfigEltNbr++] = entityConfEltStp;
            }

            FREE_EXTENSION(entityConfigStp, A_EntityConfig_EntityConfigElement);
            SET_EXTENSION(entityConfigStp, A_EntityConfig_EntityConfigElement, entityConfigEltTab, A_EntityConfigElement, entityConfigEltNbr);
        }
    }
}

/************************************************************************
**
**  Function    :   BuildBindOption::rootStartByArray
**
**  Description :
**
**  Arguments   :
**
**
**
**
**  Return      :
**
**
**  Last modif. :   PMSTA-46681 - LJE - 230915
**
*************************************************************************/
const bool BuildBindOption::rootStartByArray() const
{
    return (this->isBusinessKeyOnly() == false && this->isImportExport() == false);
}


/************************************************************************
**
**  Function    :   BuildBindOption::rootStartByArray
**
**  Description :
**
**  Arguments   :
**
**
**
**
**  Return      :
**
**
**  Last modif. :   PMSTA-46681 - LJE - 230915
**
*************************************************************************/
const bool BuildBindOption::forceArrayFirstObject() const
{
    return (this->isBusinessKeyOnly() == false && this->isImportExport() == false);
}

/************************************************************************
**
**  Function    :   BuildBindOption::usePrettyWritter
**
**  Description :
**
**  Arguments   :
**
**
**
**
**  Return      :
**
**
**  Last modif. :   PMSTA-46681 - LJE - 230915
**
*************************************************************************/
const bool BuildBindOption::usePrettyWritter() const
{
    return (this->m_optionCategory == BuildBindOption::Categ::ExportFullObject);
}


/************************************************************************
**
**  Function    :   BuildBindOption::getFilter
**
**  Description :
**
**  Arguments   :
**
**
**
**
**  Return      :
**
**
**  Last modif. :   PMSTA-46681 - LJE - 211208
**
*************************************************************************/
std::string BuildBindOption::getFilter(const std::string &entity, const std::string &attribute) const
{
    auto entityMapIt = this->m_exportFiltersMap.find(entity);
    if (entityMapIt != this->m_exportFiltersMap.end())
    {
        auto attribMapIt = entityMapIt->second.find(attribute);
        if (attribMapIt != entityMapIt->second.end())
        {
            return attribMapIt->second;
        }
    }
    return std::string();
}

/************************************************************************
**
**  Function    :   BuildBindOption::getSkip
**
**  Description :
**
**  Arguments   :
**
**
**
**
**  Return      :
**
**
**  Last modif. :   PMSTA-46681 - LJE - 211208
**
*************************************************************************/
bool BuildBindOption::getSkip(const std::string &entity, const std::string &attribute, std::string &skipScpt) const
{
    auto entityMapIt = this->m_exportSkipMap.find(entity);
    if (entityMapIt != this->m_exportSkipMap.end())
    {
        auto attribMapIt = entityMapIt->second.find(attribute);
        if (attribMapIt != entityMapIt->second.end())
        {
            skipScpt = attribMapIt->second;
            return true;
        }
    }
    return false;
}

/************************************************************************
**
**  Function    :   BuildBindOption::getKeep
**
**  Description :
**
**  Arguments   :
**
**
**
**
**  Return      :
**
**
**  Last modif. :   PMSTA-46681 - LJE - 211208
**
*************************************************************************/
bool BuildBindOption::getKeep(const std::string &entity, const std::string &attribute, std::string &keepScpt) const
{
    auto entityMapIt = this->m_exportKeepMap.find(entity);
    if (entityMapIt != this->m_exportKeepMap.end())
    {
        if (attribute.empty())
        {
            return true;
        }

        auto attribMapIt = entityMapIt->second.find(attribute);
        if (attribMapIt != entityMapIt->second.end())
        {
            keepScpt = attribMapIt->second;
            return true;
        }
    }
    return false;
}

/************************************************************************
**
**  Function    :   BuildBindOption::getCleanUp
**
**  Description :
**
**  Arguments   :
**
**
**
**
**  Return      :
**
**
**  Last modif. :   PMSTA-46681 - LJE - 211208
**
*************************************************************************/
bool BuildBindOption::getCleanUp(const std::string &entity, const std::string &attribute, std::string &cleanUpScpt) const
{
    auto entityMapIt = this->m_exportCleanUpMap.find(entity);
    if (entityMapIt != this->m_exportCleanUpMap.end())
    {
        auto attribMapIt = entityMapIt->second.find(attribute);
        if (attribMapIt != entityMapIt->second.end())
        {
            cleanUpScpt = attribMapIt->second;
            return true;
        }
    }
    return false;
}

/************************************************************************
**
**  Function    :   BuildBindOption::isAuto
**
**  Description :
**
**  Arguments   :
**
**
**
**
**  Return      :
**
**
**  Last modif. :   PMSTA-46681 - LJE - 211208
**
*************************************************************************/
bool BuildBindOption::isAuto(const std::string& entity, const std::string& attribute) const
{
    if (this->getCateg() == BuildBindOption::Categ::ImportFullObject)
    {
        auto entityMapIt = this->m_exportAutoMap.find(entity);
        if (entityMapIt != this->m_exportAutoMap.end())
        {
            auto attribMapIt = entityMapIt->second.find(attribute);
            if (attribMapIt != entityMapIt->second.end())
            {
                return true;
            }
        }
    }
    return false;
}

/************************************************************************
**
**  Function    :   BuildBindOption::getCleanUp
**
**  Description :
**
**  Arguments   :
**
**
**
**
**  Return      :
**
**
**  Last modif. :   PMSTA-46681 - LJE - 240206
**
*************************************************************************/
bool BuildBindOption::isCleanUpProvidedOnly(OBJECT_ENUM objectEn)
{
    return (this->m_cleanUpProvidedOnlyObjectSet.find(objectEn) != this->m_cleanUpProvidedOnlyObjectSet.end());
}

/************************************************************************
**
**  Function    :   BuildBindOption::setOutputArtefact
**
**  Description :
**
**  Arguments   :
**
**
**
**
**  Return      :
**
**
**  Last modif. :   PMSTA-46681 - LJE - 231009
**
*************************************************************************/
void BuildBindOption::setOutputArtefact(OutputArtefact outputArtefact)
{
    this->m_outputArtefact = outputArtefact;
}

/************************************************************************
**
**  Function    :   BuildBindOption::setFilePathInfo
**
**  Description :
**
**  Arguments   :
**
**
**
**
**  Return      :
**
**
**  Last modif. :   PMSTA-46681 - LJE - 231009
**
*************************************************************************/
void BuildBindOption::setFilePathInfo(const std::string &rootPath, const std::string &fileName, int zipEntryPos)
{
    if (rootPath.empty())
    {
        if (QDir::isRelativePath(fileName.c_str()) == false)
        {
            this->m_rootPath.clear();
        }
    }
    else
    {
        this->m_rootPath = QDir::toNativeSeparators(rootPath.c_str()).toLocal8Bit().constData();

        if (zipEntryPos < 0 &&
            this->m_rootPath.empty() == false &&
            this->m_rootPath.back() != FILE_SEPARATOR[0])
        {
            this->m_rootPath += FILE_SEPARATOR;
        }
    }

    if (zipEntryPos == -1)
    {
        if (fileName.empty() == false)
        {
            this->m_fileName = QDir::toNativeSeparators(fileName.c_str()).toLocal8Bit().constData();

            auto extPos = this->m_fileName.find_last_of(".");
            if (extPos == std::string::npos)
            {
                this->m_rootPath += this->m_fileName += FILE_SEPARATOR;
                this->m_fileName.clear();
            }
            else
            {
                auto fileInfo = QFileInfo(this->m_fileName.c_str());
                if (fileInfo.isAbsolute())
                {
                    this->m_rootPath.clear();
                }

                auto extStr = this->m_fileName.substr(extPos);
                if (extStr == ".imp")
                {
                    this->m_fileName.replace(extPos, extStr.length(), ".json");
                }
            }
        }
        else
        {
            this->m_fileName.clear();
        }
    }
    else if (zipEntryPos == -2)
    {
        this->m_rootPath = rootPath;
        this->m_fileName = fileName;
    }
    else
    {
        this->m_fileName.clear();
        this->m_zipEntryPos = zipEntryPos;
    }
}

/************************************************************************
**
**  Function    :   BuildBindOption::isZipFileType
**
**  Description :
**
**  Arguments   :
**
**
**
**
**  Return      :
**
**
**  Last modif. :   PMSTA-46681 - LJE - 240502
**
*************************************************************************/
bool BuildBindOption::isZipFileType(std::string fileName)
{
    auto extPos = fileName.find_last_of(".");
    if (extPos != std::string::npos)
    {
        auto extStr = fileName.substr(extPos);
        if (extStr == ".zip" || extStr == ".gz" || extStr == ".bz2" )
        {
            return true;
        }
    }
    return false;
}

/************************************************************************
**
**  Function    :   BuildBindOption::isZipFile
**
**  Description :
**
**  Arguments   :
**
**
**
**
**  Return      :
**
**
**  Last modif. :   PMSTA-46681 - LJE - 231009
**
*************************************************************************/
bool BuildBindOption::isZipFile()
{
    if (this->m_zipEntryPos >= 0)
    {
        return true;
    }

    return BuildBindOption::isZipFileType(this->m_fileName);
}

/************************************************************************
**
**  Function    :   BuildBindOption::isZipZipFile
**
**  Description :
**
**  Arguments   :
**
**
**
**
**  Return      :
**
**
**  Last modif. :   PMSTA-46681 - LJE - 240502
**
*************************************************************************/
bool BuildBindOption::isZipZipFile()
{
    if (this->m_zipEntryPos >= 0)
    {
        return true;
    }

    return BuildBindOption::isZipFileType(this->m_fileName);
}

/************************************************************************
**
**  Function    :   BuildBindOption::isExportedAttrib
**
**  Description :
**
**  Arguments   :
**
**
**
**
**  Return      :
**
**
**  Last modif. :   PMSTA-46681 - LJE - 231009
**
*************************************************************************/
bool BuildBindOption::isExportedAttrib(DictAttribClass        *dictAttribStp,
                                       DBA_DYNFLD_STP          recordStp,
                                       BuildBindOption::Categ &exportCateg) const
{
    if (dictAttribStp == nullptr ||
        dictAttribStp->logicalFlg == TRUE ||
        (recordStp != nullptr &&
         recordStp->getObjectEn() == dictAttribStp->dictEntityStp->objectEn &&
         IS_NULLFLD(recordStp, dictAttribStp->progN) &&
         GET_FK_RECORD(recordStp, dictAttribStp->progN) == nullptr))
    {
        return false;
    }

    bool bToExportField = (dictAttribStp->exportEn != Export_NotExported) && dictAttribStp->isSpecialAttribute() == false;

    if (this->isBusinessKeyOnly() &&
        dictAttribStp->busKeyFlg == FALSE &&
        dictAttribStp->primFlg   == FALSE)
    {
        return false;
    }

    exportCateg = dictAttribStp->isCompostion() ? this->getExportFullCateg() : Categ::BusinessKeyOnlyShort;

    if (bToExportField &&
        dictAttribStp->custFlg == TRUE &&
        this->showCustomAttributes() == false)
    {
        bToExportField = false;
    }

    if (bToExportField &&
        dictAttribStp->precompFlg == TRUE &&
        this->showPrecompAttributes() == false)
    {
        bToExportField = false;
    }

    auto dictEntityStp = dictAttribStp->dictEntityStp;
    std::string filter = this->getFilter(dictEntityStp->mdSqlName, dictAttribStp->sqlName);

    if (bToExportField == false && filter.empty() == false)
    {
        bToExportField = true;
    }

    if (bToExportField)
    {
        std::string skipScpt;
        bool   bSkip = this->getSkip(dictEntityStp->mdSqlName, dictAttribStp->sqlName, skipScpt);

        if (bToExportField && bSkip && recordStp != nullptr)
        {
            if (skipScpt.empty() == false && skipScpt != "all")
            {
                if (DBA_EvalCheckScript(skipScpt.c_str(), recordStp))
                {
                    bToExportField = false;
                }
            }
            else
            {
                bToExportField = false;
            }
        }
    }

    if (this->isExport() || bToExportField == false)
    {
        std::string keepScpt;
        bool   bKeep = this->getKeep(dictEntityStp->mdSqlName, dictAttribStp->sqlName, keepScpt);
        if (bKeep)
        {
            if (recordStp == nullptr)
            {
                bToExportField = true;
            }
            else if (keepScpt.empty() == false && keepScpt != "all")
            {
                if (DBA_EvalCheckScript(keepScpt.c_str(), recordStp))
                {
                    bToExportField = true;
                }
            }
            else
            {
                if (keepScpt == "all" &&
                    this->getOutputMode() != EntityConfigOutputModeEn::BusinessKey)
                {
                    exportCateg = this->getExportFullCateg();
                }
                bToExportField = true;
            }
        }
    }

    if (bToExportField)
    {
        this->fixExportCateg(exportCateg);
    }

    return bToExportField;
}


/************************************************************************
**
**  Function    :   BuildBindOption::isExportedLogicalAttrib
**
**  Description :
**
**  Arguments   :
**
**
**
**
**  Return      :
**
**
**  Last modif. :   PMSTA-46681 - LJE - 231009
**
*************************************************************************/
bool BuildBindOption::isExportedLogicalAttrib(DictAttribClass       *dictAttribStp, 
                                              DBA_DYNFLD_STP         recordStp,
                                              std::string            &filter,
                                              BuildBindOption::Categ &exportCateg)
{
    if (dictAttribStp == nullptr)
    {
        exportCateg = BuildBindOption::Categ::MdAttribute;
        return true;
    }

    if (dictAttribStp->logicalFlg == FALSE ||
        dictAttribStp->featureEn == XdEntityFeatureFeatureEn::ScriptControl)
    {
        exportCateg = BuildBindOption::Categ::Denied;
        return false;
    }

    if (dictAttribStp->isCompostion())
    {
        exportCateg = this->getExportFullCateg();
    }
    else
    {
        exportCateg = BuildBindOption::Categ::BusinessKeyOnlyShort;
    }

    auto dictEntityStp  = dictAttribStp->dictEntityStp;
    bool bToExportField = (dictAttribStp->exportEn != Export_NotExported);

    if (this->isExport() == false)
    {
        bToExportField = false;
    }

    if (exportCateg == Categ::ExportFullObject)
    {
        if (this->getOutputMode() == EntityConfigOutputModeEn::FirstLevel)
        {
            bToExportField = false;
        }
    }

    if (*this == BuildBindOption::Categ::ExportCopyObject &&
        dictAttribStp->refDictEntityStp != nullptr)
    {
        if (dictAttribStp->refDictEntityStp->copyRightEn != DICT_ATTRCOPY_ENUM::DictAttrCopyNat_Copy)
        {
            if (dictAttribStp->refDictEntityStp->copyRightEn == DICT_ATTRCOPY_ENUM::DictAttrCopyNat_Denied)
            {
                exportCateg = BuildBindOption::Categ::Denied;
                return false;
            }

            bToExportField = false;
        }
    }

    if (*this != Categ::CleanUpFullObject ||
        this->getCleanUp(dictEntityStp->mdSqlName, dictAttribStp->sqlName, filter) == false)
    {
        filter = this->getFilter(dictEntityStp->mdSqlName, dictAttribStp->sqlName);
    }

    if (filter == "auto")
    {
        filter.clear();
    }

    if (filter == "none")
    {
        bToExportField = false;
    }
    else if (bToExportField == false && filter.empty() == false)
    {
        bToExportField = true;
    }

    if (bToExportField)
    {
        std::string skipScpt;
        bool   bSkip = this->getSkip(dictEntityStp->mdSqlName, dictAttribStp->sqlName, skipScpt);

        if (bSkip)
        {
            if (skipScpt.empty() == false && skipScpt != "all")
            {
                if (recordStp != nullptr &&
                    DBA_EvalCheckScript(skipScpt.c_str(), recordStp))
                {
                    bToExportField = false;
                }
            }
            else
            {
                bToExportField = false;
            }
        }
    }

    std::string keepScpt;
    bool   bKeep = this->getKeep(dictEntityStp->mdSqlName, dictAttribStp->sqlName, keepScpt);
    if (bKeep)
    {
        if (keepScpt.empty() == false && keepScpt != "all")
        {
            if (recordStp == nullptr ||
                DBA_EvalCheckScript(keepScpt.c_str(), recordStp))
            {
                bToExportField = true;
            }
        }
        else
        {
            bToExportField = true;
        }

        if (keepScpt == "all" && 
            this->m_rootBuildBindOption.isBusinessKey() == false)
        {
            exportCateg = this->getExportFullCateg();
        }
    }

    if (dictAttribStp->exportEn == Export_NotExported && bToExportField == false)
    { 
        exportCateg = BuildBindOption::Categ::NotExported;
    }

    return bToExportField;
}


/************************************************************************
**
**  Function    :   BuildBindOption::setFilter
**
**  Description :
**
**  Arguments   :
**
**
**
**
**  Return      :
**
**
**  Last modif. :   PMSTA-46681 - LJE - 211208
**
*************************************************************************/
void BuildBindOption::setFilter(const std::string &entity, const std::string &attribute, const std::string &filter)
{
    this->m_exportFiltersMap[entity][attribute] = filter;
    BuildBindOption::fixJSonString(this->m_exportFiltersMap[entity][attribute]);
}

/************************************************************************
**
**  Function    :   BuildBindOption::setKeep
**
**  Description :
**
**  Arguments   :
**
**
**
**
**  Return      :
**
**
**  Last modif. :   PMSTA-46681 - LJE - 211208
**
*************************************************************************/
void BuildBindOption::setKeep(const std::string &entity, const std::string &attribute, const std::string &filter)
{
    this->m_exportKeepMap[entity][attribute] = filter;
    if (filter.empty() == false)
    {
        BuildBindOption::fixJSonString(this->m_exportFiltersMap[entity][attribute]);
    }
}

/************************************************************************
**
**  Function    :   BuildBindOption::setSkip
**
**  Description :
**
**  Arguments   :
**
**
**
**
**  Return      :
**
**
**  Last modif. :   PMSTA-46681 - LJE - 211208
**
*************************************************************************/
void BuildBindOption::setSkip(const std::string &entity, const std::string &attribute, const std::string &filter)
{
    this->m_exportSkipMap[entity][attribute] = filter;
    if (filter.empty() == false)
    {
        BuildBindOption::fixJSonString(this->m_exportFiltersMap[entity][attribute]);
    }
}

/************************************************************************
**
**  Function    :   BuildBindOption::setCleanUp
**
**  Description :
**
**  Arguments   :
**
**
**
**
**  Return      :
**
**
**  Last modif. :   PMSTA-46681 - LJE - 211208
**
*************************************************************************/
void BuildBindOption::setCleanUp(const std::string &entity, const std::string &attribute, const std::string &filter)
{
    this->m_exportCleanUpMap[entity][attribute] = filter;

    if (filter == "provided")
    {
        auto dictEntityStp = DBA_GetEntityBySqlName(entity);
        if (dictEntityStp != nullptr)
        {
            auto dictAttributeStp = dictEntityStp->getDictAttribBySqlName(attribute);
            if (dictAttributeStp != nullptr &&
                dictAttributeStp->refDictEntityStp != nullptr)
            {
                this->m_cleanUpProvidedOnlyObjectSet.insert(dictAttributeStp->refDictEntityStp->objectEn);
            }
        }
    }
    else if (filter == "auto")
    {
        this->m_exportAutoMap[entity].insert(attribute);
    }
}

/************************************************************************
**
**  Function    :   BuildBindOption::setConfig
**
**  Description :
**
**  Arguments   :
**
**
**
**
**  Return      :
**
**
**  Last modif. :   PMSTA-46681 - LJE - 211208
**
*************************************************************************/
void BuildBindOption::setConfig(const std::string& entity, const std::string &key, const std::string &value, EntityConfigElementRuleEn ruleEn)
{
    this->printMsg(ProcessingMessageNatEn::Debug, RET_SUCCEED, SYS_Stringer("MSG Set config ", (entity.empty() ? "all" : entity), "-", key, "-", value, "-", static_cast<int>(ruleEn)));

    std::vector<std::string>  attribTokensStr;
    DdlGen::tokenizeStr(attribTokensStr, key, ".");
    if (attribTokensStr.size() == 2)
    {
        this->setConfig(attribTokensStr[0], attribTokensStr[1], value, ruleEn);
    }
    else if (entity.empty() == false)
    {
        switch (ruleEn)
        {
            case EntityConfigElementRuleEn::Filter:
                this->setFilter(entity, key, value);
                break;

            case EntityConfigElementRuleEn::Keep:
                this->setKeep(entity, key, value);

                if (key == "Identity")
                {
                    auto dictEntityStp = DBA_GetEntityBySqlName(entity);

                    switch (ruleEn)
                    {
                        case EntityConfigElementRuleEn::Keep:
                            this->m_showIdentityMap[dictEntityStp->objectEn] = Config::Enable;
                            break;

                        case EntityConfigElementRuleEn::Skip:
                            this->m_showIdentityMap[dictEntityStp->objectEn] = Config::Disable;
                            break;
                    }
                }
                else if (value != "all" && value.empty() == false)
                {
                    this->setConfig(entity, key, value, EntityConfigElementRuleEn::OutputMode);
                }
                break;

            case EntityConfigElementRuleEn::Skip:
                this->setSkip(entity, key, value);
                break;

            case EntityConfigElementRuleEn::CleanUp:
                this->setCleanUp(entity, key, value);
                break;

            case EntityConfigElementRuleEn::OutputMode:
            {
                auto dictEntityStp = DBA_GetEntityBySqlName(entity);
                auto dictPermValStp = DBA_GetDictPermValByName(EntityConfig, A_EntityConfig_OutputModeEn, value.c_str());

                if (dictEntityStp != nullptr && dictPermValStp != nullptr)
                {
                    auto dictAttribStp = dictEntityStp->getDictAttribBySqlName(key);

                    if (dictAttribStp != nullptr)
                    {
                        this->setOutputMode(dictEntityStp->objectEn,
                                            dictAttribStp->progN,
                                            static_cast<EntityConfigOutputModeEn>(dictPermValStp->permVal));
                    }
                }
                break;
            }
        }
    }
    else if (key == "custom" || key == "UserDefinedField")
    {
        switch (ruleEn)
        {
            case EntityConfigElementRuleEn::Keep:
                this->m_showCustom = Config::Enable;
                break;

            case EntityConfigElementRuleEn::Skip:
                this->m_showCustom = Config::Disable;
                break;
        }
    }
    else if (key == "precomputed" || key == "ExtensionField")
    {
        switch (ruleEn)
        {
            case EntityConfigElementRuleEn::Keep:
                this->m_showPrecomp = Config::Enable;
                break;

            case EntityConfigElementRuleEn::Skip:
                this->m_showPrecomp = Config::Disable;
                break;
        }
    }
    else if (key == "Identity")
    {
        switch (ruleEn)
        {
            case EntityConfigElementRuleEn::Keep:
                this->m_showIdentityMap[NullEntity] = Config::Enable;
                break;

            case EntityConfigElementRuleEn::Skip:
                this->m_showIdentityMap[NullEntity] = Config::Disable;
                break;
        }
    }
    else
    {
        switch (ruleEn)
        {
            case EntityConfigElementRuleEn::CleanUp:
                this->setCleanUp(key, "", value);
                break;
        }
    }
}

/************************************************************************
**
**  Function    :   BuildBindOption::start
**
**  Description :
**
**  Arguments   :
**
**
**
**
**  Return      :
**
**
**  Last modif. :   PMSTA-46681 - LJE - 240130
**
*************************************************************************/
void BuildBindOption::start()
{
    this->m_processingResultStp    = this->m_mp.allocDynst(FILEINFO, A_ProcessingResult);
    this->m_bProcessingResultLevel = true;

    DATE_CurrentDateTime(&this->m_startDateTime, true);
    SET_DATETIME(this->m_processingResultStp, A_ProcessingResult_StartDate, this->m_startDateTime);
}

/************************************************************************
**
**  Function    :   BuildBindOption::finish
**
**  Description :
**
**  Arguments   :
**
**
**
**
**  Return      :
**
**
**  Last modif. :   PMSTA-46681 - LJE - 240130
**
*************************************************************************/
DBA_DYNFLD_STP BuildBindOption::finish(RET_CODE retCode)
{
    if (this->m_processingResultStp != nullptr)
    {
        DATETIME_T currDateTimeSt = { 0, 0 };
        DATE_CurrentDateTime(&currDateTimeSt, true);
        SET_DATETIME(this->m_processingResultStp, A_ProcessingResult_EndDate, currDateTimeSt);
        SET_INT(this->m_processingResultStp, A_ProcessingResult_Result, retCode);
        SET_A_ProcessingResult_ResultLevelEn(this->m_processingResultStp, (RET_GET_LEVEL(retCode) == RET_LEV_ERROR ? ProcessingMessageNatEn::Error : ProcessingMessageNatEn::Success));
    }
    return this->m_processingResultStp;
}

/************************************************************************
**
**  Function    :   BuildBindOption::printMsg
**
**  Description :
**
**  Arguments   :
**
**
**
**
**  Return      :
**
**
**  Last modif. :   PMSTA-46681 - LJE - 240130
**
*************************************************************************/
void BuildBindOption::printMsg(ProcessingMessageNatEn msgNatEn, INT_T messageNumber, const std::string &message, bool bStdErr)
{
    if (message.empty() == false)
    {
        bool bShowMessage = (msgNatEn >= this->m_logLevelEn);

        if (bShowMessage)
        {
            if (this->m_processingResultStp != nullptr)
            {
                auto importMessageStp = ALLOC_DYNST(A_ProcessingMessage);

                SET_A_ProcessingMessage_NatEn(importMessageStp, msgNatEn);
                SET_STRING(importMessageStp, A_ProcessingMessage_Message, message.c_str());
                SET_INT(importMessageStp, A_ProcessingMessage_MessageNumber, messageNumber);

                DBA_DYNFLD_STP* msgTab = GET_EXTENSION_PTR(this->m_processingResultStp, A_ProcessingResult_ProcessingMessage);
                int             msgNbr = GET_EXTENSION_NBR(this->m_processingResultStp, A_ProcessingResult_ProcessingMessage);

                msgTab = static_cast<DBA_DYNFLD_STP*>(REALLOC(msgTab, ((msgNbr + 1) * sizeof(DBA_DYNFLD_STP))));
                msgTab[msgNbr++] = importMessageStp;

                SET_EXTENSION(this->m_processingResultStp, A_ProcessingResult_ProcessingMessage, msgTab, A_ProcessingMessage, msgNbr);
            }

            const AAALogger& logger = AAALogger::getApplicationLogger();

            std::string headerStr;
            switch (msgNatEn)
            {
                case ProcessingMessageNatEn::Error:
                case ProcessingMessageNatEn::Fail:
                    headerStr = "ERR ";
                    logger.error(message);
                    break;

                case ProcessingMessageNatEn::Success:
                    headerStr = "SUC ";
                    logger.warn(message);
                    break;

                default:
                    headerStr = "MSG ";
                    logger.info(message);
            }

            if (SYS_IsBatchMode() == TRUE)
            {
                if (bStdErr ||
                    msgNatEn == ProcessingMessageNatEn::Error ||
                    msgNatEn == ProcessingMessageNatEn::Fail)
                {
                    std::cerr << std::endl << headerStr << message;
                }
                else
                {
                    if (msgNatEn == ProcessingMessageNatEn::Success || 
                        logger.isDebugEnabled())
                    {
                        std::cout << std::endl << headerStr << message;
                    }
                    else if (msgNatEn == ProcessingMessageNatEn::Info && 
                             logger.isInfoEnabled())
                    {
                        std::cout << std::endl << headerStr << message;
                    }
                }
            }
        }
    }
}

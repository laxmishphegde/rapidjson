/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define DDLGEN01_C

/************************************************************************
**      Include files
*************************************************************************/
#ifdef NTWIN
#pragma warning (push)
#endif


#include   <limits.h>

#include   "unidef.h"     /* Mandatory */
#include      "gen.h"
#include      "dba.h"
#include   "dbafmt.h"
#include      "fin.h"
#include     "date.h"
#include      "cmp.h"
#include      "tls.h"
#include     "json.h"
#include   "ddlgen.h"
#include   "ddlgenfulltable.h"
#include   "sqliteconnection.h"

#include    <QCoreApplication>
#include    <QSettings>

#include  "dbaperf.h" /* REF9187 - LJE - 030527 */
#include "dbaperfa.h" /* REF9187 - LJE - 030527 */

#if ((defined AAAPURIFY) || (defined AAAQUANTIFY)) && (defined NT)
#include "pure.h"
#endif

#ifdef NTWIN
#pragma warning (pop)
#endif

/************************************************************************
**      External entry points
**
*************************************************************************/
extern bool               EV_UseAlternativeDataSource;
extern DdlGenCfgFile*     EV_SourceCfgFile;
extern DdlGenCfgFile*     EV_TargetCfgFile;
extern DdlGenContext*     EV_TargetContext;

extern int                EV_AAAInstallLevel;

/************************************************************************
**      Local functions
**
*************************************************************************/

/************************************************************************
**      Static definitions & data
**
*************************************************************************/
class DdlGenBuildInfo: public ThreadArg
{
public:
    DdlGenBuildInfo(DdlGenContext *ddlGenContextPtr)
        : m_ddlGenContextPtr(ddlGenContextPtr)
        , ddlGenFullTable(nullptr)
        , retCode(RET_GEN_INFO_NOACTION)
        , m_shXdEntityStp(nullptr)
        , m_dictEntityStp(nullptr)
        , m_targetTableEn(TargetTable_Undefined)
    {
        this->m_mp.ownerObject(ddlGenContextPtr);
        this->m_ownedByCaller = true;
    }

    DdlGenBuildInfo(DdlGenContext& ddlGenContextPtr)
        : m_ddlGenContextPtr(&ddlGenContextPtr)
        , ddlGenFullTable(nullptr)
        , retCode(RET_GEN_INFO_NOACTION)
        , m_shXdEntityStp(nullptr)
        , m_dictEntityStp(nullptr)
        , m_targetTableEn(TargetTable_Undefined)
    {
        this->m_ownedByCaller = true;
    }

    DdlGenBuildInfo(const DdlGenBuildInfo& ref)
        : m_ddlGenContextPtr(ref.m_ddlGenContextPtr)
        , ddlGenFullTable(ref.ddlGenFullTable)
        , retCode(ref.retCode)
        , m_shXdEntityStp(ref.m_shXdEntityStp)
        , m_dictEntityStp(ref.m_dictEntityStp)
        , m_targetTableEn(ref.m_targetTableEn)
    {
        this->m_ownedByCaller = true;
    }

    virtual ~DdlGenBuildInfo()
    {
        delete this->ddlGenFullTable;
    }

    DdlGenBuildInfo& operator=(const DdlGenBuildInfo& ref)
    {
        this->m_ddlGenContextPtr             = ref.m_ddlGenContextPtr;
        this->ddlGenFullTable                = ref.ddlGenFullTable;
        this->retCode                        = ref.retCode;
        this->m_shXdEntityStp                = ref.m_shXdEntityStp;
        this->m_dictEntityStp                = ref.m_dictEntityStp;
        this->m_targetTableEn                = ref.m_targetTableEn;
        return *this;
    }

    DICT_ENTITY_STP   getDictEntityStp()
    {
        return this->m_dictEntityStp;
    }

    void              setDictEntityStp(DICT_ENTITY_STP dictEntityStp)
    {
        this->m_dictEntityStp = dictEntityStp;

        if (this->m_dictEntityStp != nullptr)
        {
            this->setMdSqlName(this->m_dictEntityStp->mdSqlName);
        }
    }

    DBA_DYNFLD_STP   getShXdEntityStp() const
    {
        return this->m_shXdEntityStp;
    }

    void              setShXdEntityStp(DBA_DYNFLD_STP shXdEntityStp)
    {
        this->m_shXdEntityStp = shXdEntityStp;

        if (this->m_shXdEntityStp != nullptr &&
            IS_NULLFLD(this->m_shXdEntityStp, S_XdEntity_SqlName) == false)
        {
            this->setMdSqlName(GET_SYSNAME(this->m_shXdEntityStp, S_XdEntity_SqlName));
        }
    }

    const std::string& getMdSqlName()
    {
        return this->m_mdSqlName;
    }

    DdlGenMsg& getDdlGenMsg()
    {
        return *this->m_ddlGenContextPtr;
    }

    DdlGenContext* m_ddlGenContextPtr;
    DdlGenFullTable* ddlGenFullTable;
    RET_CODE          retCode;
    TARGET_TABLE_ENUM m_targetTableEn;
    int               m_objectDefPos;

protected:

    void              setMdSqlName(const std::string& mdSqlName)
    {
        if (this->m_mdSqlName.empty())
        {
            this->m_mdSqlName = mdSqlName;

            auto cfgObjSectionStp = this->m_ddlGenContextPtr->getCfgFileHelper().getCfgObjectSectonStp(this->m_mdSqlName, EntityNat_All);
            if (cfgObjSectionStp != nullptr)
            {
                this->m_objectDefPos = cfgObjSectionStp->objectDefPos;
            }
            else
            {
                this->m_objectDefPos = this->m_ddlGenContextPtr->m_parentContext->m_lastUnkownObjDefPos++;
            }
        }
    }

    DICT_ENTITY_STP   m_dictEntityStp;
    DBA_DYNFLD_STP    m_shXdEntityStp;
    std::string            m_mdSqlName;
};

/************************************************************************
**      FONCTIONS
**
************************************************************************/
STATIC RET_CODE DDL_BuildDdlObject(DdlGenContext& ddlGenContext, DdlGenAction& ddlGenAction); /* PMSTA-11505 - LJE - 110519 */
STATIC RET_CODE DDL_BuildTable(DdlGenContext& ddlGenContext, int level = 0);
STATIC RET_CODE DDL_BuildOneDdlObject(DdlGenAction& ddlGenAction,
                                          DdlGenBuildInfo& ddlGenBuildInfo,
                                          ThreadPool* ddlGenThreadPoolPtr);
STATIC RET_CODE DBA_BuildAllDdlObject(DdlGenAction& ddlGenAction,
                                      DdlGenContext& ddlGenContext,
                                      std::map<std::string, DdlGenBuildInfo*>& xdEntityIdxMap,
                                      std::vector<DdlGenBuildInfo*>& genDdlTab,
                                      MemoryPool& mp);

/************************************************************************
**
**  Function    :   DDL_CopyCustoData()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-37366 - LJE - 200224
**
*************************************************************************/
STATIC RET_CODE DDL_CopyCustoData(DdlGenContext& ddlGenContext)
{
    RET_CODE   ret = RET_SUCCEED;
    DdlGenMsg  stdMsg(ddlGenContext);

    auto& aaaHomePath       = ddlGenContext.getAaaHomePath();
    auto  targetAaaHomePath = (EV_TargetContext != nullptr ? EV_TargetContext->getAaaHomePath() : std::string());

    if (aaaHomePath.empty() == false && targetAaaHomePath.empty() == false)
    {
        targetAaaHomePath += "/aaahome";
        SYS_DeleteDirectoryTree(targetAaaHomePath.c_str());

        std::vector<std::pair<std::string, std::pair<std::string, bool>>> toCopyDirMap;
        toCopyDirMap.push_back(std::make_pair("", std::make_pair("gwp_*.sh", true)));
        toCopyDirMap.push_back(std::make_pair("", std::make_pair("*.usr.*", true)));
        toCopyDirMap.push_back(std::make_pair("", std::make_pair("*.usr", true)));

        std::vector<std::string>      keepFileNames;

        keepFileNames.push_back(aaaHomePath + "/install/keep_files.cfg");
        keepFileNames.push_back(aaaHomePath + "/install/keep_files.usr.cfg");

        for (auto& it : keepFileNames)
        {
            std::fstream      keepFilesFile;
            keepFilesFile.open(it, std::ifstream::in);

            if (keepFilesFile.good())
            {
                std::string keepFileLine;
                while (getline(keepFilesFile, keepFileLine))
                {
                    if (keepFileLine != "./ddl/gen/*")
                    {
                        toCopyDirMap.push_back(std::make_pair(keepFileLine, std::make_pair(std::string(), true)));
                    }
                }
            }
        }

        stdMsg.printMsg(RET_SRV_INFO_RUNNING, SYS_Stringer("Copy files from directory ", aaaHomePath, " to ", targetAaaHomePath));
        for (auto& it : toCopyDirMap)
        {
            stdMsg.printMsg(RET_SRV_INFO_RUNNING, SYS_Stringer("Copy files with the following pattern: ", it.first, " - ", it.second.first, " - ", it.second.second));
            SYS_CopyPath(aaaHomePath + it.first, targetAaaHomePath + it.first, it.second.first, it.second.second);
            stdMsg.printMsg(RET_SUCCEED, "Done");
        }

        SYS_DeleteDirectoryTree(std::string(targetAaaHomePath + "/ddl/log").c_str());
        SYS_DeleteDirectoryTree(std::string(targetAaaHomePath + "/pck/log").c_str());

        DdlGenCfgFile cfgFileHelper(ddlGenContext, CfgFileType_InstallCfg);
        cfgFileHelper.keepFileInMemory();
        cfgFileHelper.setFileName(targetAaaHomePath + "/install/aaa_install.cfg");
        cfgFileHelper.loadCfgFile();
        cfgFileHelper.modifyFile("V", "AAA_RDBMS", "SQLITE");
        cfgFileHelper.modifyFile("V", "DSQUERY", "../db");
        cfgFileHelper.write();
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DDL_BuildInvalidSproc()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-37366 - LJE - 200224
**
*************************************************************************/
STATIC RET_CODE DDL_BuildInvalidSproc(DdlGenContext &ddlGenContext,
                                      std::vector<DdlGenBuildInfo *> &genDdlTab)
{
    RET_CODE ret = RET_SUCCEED;

    if (ddlGenContext.m_invalidDdlObjMap.empty() == false)
    {
        ddlGenContext.depSprocSqlNameSet.clear();

        for (auto it = ddlGenContext.m_invalidDdlObjMap.begin(); it != ddlGenContext.m_invalidDdlObjMap.end(); ++it)
        {
            ddlGenContext.depSprocSqlNameSet.insert(it->second.getObjName());
            ddlGenContext.depEntityPscSqlNameSet.insert(it->second.getEntitySqlName());
        }
        ddlGenContext.m_invalidDdlObjMap.clear();

        std::set<std::string> depEntityPscSqlNameSet = ddlGenContext.depEntityPscSqlNameSet;

        for (auto & ddlGenBuildInfo : genDdlTab)
        {
            if (ddlGenBuildInfo->ddlGenFullTable == nullptr ||
                ddlGenContext.depEntityPscSqlNameSet.empty() == true ||
                ddlGenContext.depEntityPscSqlNameSet.find(ddlGenBuildInfo->getMdSqlName()) == ddlGenContext.depEntityPscSqlNameSet.end())
                continue;

            depEntityPscSqlNameSet.erase(ddlGenBuildInfo->getMdSqlName());

            if (RET_GET_LEVEL(ddlGenBuildInfo->retCode) != RET_LEV_ERROR)
            {
                ddlGenBuildInfo->getDdlGenMsg().startTimer();
                ddlGenBuildInfo->retCode = ddlGenBuildInfo->ddlGenFullTable->buildStoredProceduresInDB();
                ddlGenBuildInfo->getDdlGenMsg().stopTimer();
            }
        }

        ddlGenContext.m_invalidDdlObjMap.clear();

        if (ddlGenContext.ddlGenAction.m_paramEntitySqlnameStr != "to_insert")
        {
            for (auto &it : depEntityPscSqlNameSet)
            {
                DdlGenAction procDdlGenAction;

                procDdlGenAction.m_ddlObjNatEn = DbObjDdlObjNat_StoredProc;
                procDdlGenAction.m_execModeEn = DbObjExecMod_DBBuildWFiles;
                procDdlGenAction.m_subRequest = true;
                procDdlGenAction.m_entitySqlnameStr = it;

                DDL_BuildDdlObject(ddlGenContext, procDdlGenAction);
            }
        }

        ddlGenContext.depSprocSqlNameSet.clear();
        ddlGenContext.depEntityPscSqlNameSet.clear();
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DDL_ExtractDataForBuild()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-46681 - LJE - 231103
**
*************************************************************************/
STATIC RET_CODE DDL_ExtractDataForBuild(DdlGenContext                       &ddlGenContext,
                                        DdlGenConnGuard                     &ddlGenConnGuard,
                                        MemoryPool                          &mp,
                                        std::map<std::string, std::vector<DBA_DYNFLD_STP>> &currPackageInstallationCompoMap,
                                        bool                                &bNewImport,
                                        DdlGenMsg                           &stdMsg)
{
    RET_CODE ret = RET_SUCCEED;

    DdlGenAction   &ddlGenAction        = ddlGenContext.ddlGenAction;
    auto           &shXdEntityVector    = ddlGenAction.m_shXdEntityVector;
    DBA_DYNFLD_STP  searchShXdEntityStp = ddlGenAction.getSearchShXdEntityStp();

    std::map<OBJECT_ENUM, std::set<DBA_DYNFLD_STP>> toTreatMap;

    if (ddlGenAction.m_mainDdlObjNatEn == DbObjDdlObjNat_TslExtension &&
        ddlGenAction.m_bSingleEntity == false)
    {
        DBA_DYNFLD_STP *shXdEntityTab = nullptr;
        int             shXdEntityNbr = 0;

        ret = DBA_Select2(XdEntity,
                          DBA_ROLE_UDT,
                          NullDynSt,
                          nullptr,
                          S_XdEntity,
                          &shXdEntityTab,
                          UNUSED,
                          UNUSED,
                          &shXdEntityNbr,
                          ddlGenConnGuard.getDbiConn());

        for (int i = 0; i < shXdEntityNbr; ++i)
        {
            shXdEntityVector.push_back(shXdEntityTab[i]);
            mp.ownerDynStp(shXdEntityTab[i]);
        }
        FREE(shXdEntityTab);
    }
    else
    {
        if (ddlGenAction.m_fromImport)
        {
            DdlGenDbaAccessGuard ddlGenDbaAccessGuard(ddlGenContext);
            auto &ddlGenDbaAccess = ddlGenDbaAccessGuard.getDdlGenDbaAccess();

            auto &xdEntityfMap        = ddlGenDbaAccess.selAllRecords(XdEntity, false, false);
            auto &xdAttribMap         = ddlGenDbaAccess.selAllRecords(XdAttrib, false, false);
            auto &xdAttributeCustoMap = ddlGenDbaAccess.selAllRecords(XdAttributeCusto, false, false);
            auto &xdPermValMap        = ddlGenDbaAccess.selAllRecords(XdPermVal, false, false);

            std::set<ID_T>                                    xdEntityIdSet;
            std::set<DICT_T>                                  entityDictIdSet;
            std::set<std::pair<std::string, DictEntityNatEn>> xdEntitySqlNameSet;
            std::set<ID_T>                                    xdAttributeIdSet;

            /* sel_sh_xd_entity_for_build */
            for (auto &it : xdEntityfMap)
            {
                if (GET_A_XdEntity_XdActionEn(it.second) == XdEntityXdActionEn::ToInsert)
                {
                    xdEntityIdSet.insert(GET_ID(it.second, A_XdEntity_Id));
                }
            }
            for (auto &it : xdAttribMap)
            {
                if (GET_A_XdAttrib_XdActionEn(it.second) == XdEntityXdActionEn::ToInsert)
                {
                    xdEntityIdSet.insert(GET_ID(it.second, A_XdAttrib_XdEntityId));
                }
            }
            for (auto &it : xdAttributeCustoMap)
            {
                if (GET_A_XdAttributeCusto_XdActionEn(it.second) == XdEntityXdActionEn::ToInsert)
                {
                    xdAttributeIdSet.insert(GET_ID(it.second, A_XdAttributeCusto_XdAttribId));
                }
            }
            for (auto &it : xdPermValMap)
            {
                if (GET_A_XdPermVal_XdActionEn(it.second) == XdEntityXdActionEn::ToInsert)
                {
                    xdAttributeIdSet.insert(GET_ID(it.second, A_XdPermVal_XdAttribId));
                }
            }
            for (auto &it : xdAttributeIdSet)
            {
                auto xdAttribStp = ddlGenDbaAccess.getRecordById(XdAttrib, it, true);
                if (xdAttribStp != nullptr)
                {
                    xdEntityIdSet.insert(GET_ID(xdAttribStp, A_XdAttrib_XdEntityId));
                }
            }

            /* get_sh_xd_entity_by_fmt */
            auto &fmtMap = ddlGenDbaAccess.selAllRecords(Fmt, false, false);
            if (fmtMap.empty() == false)
            {
                DbiConnectionHelper dbiConnectionHelper(&ddlGenConnGuard.getDbiConn());

                std::set<std::string> fmtCodeToTreat;
                for (auto &fmtIt : fmtMap)
                {
                    if (IS_NULLFLD(fmtIt.second, A_Fmt_ReferenceFmtId) == FALSE)
                    {
                        RET_CODE retCode = DBA_GenerateFormatElement(GenerateFmteltScopeEn::ChildFormats,
                                                                     GET_ID(fmtIt.second, A_Fmt_Id),
                                                                     0,
                                                                     0,
                                                                     0,
                                                                     FALSE,
                                                                     GenerateFmteltCheckApplParamEn::No,
                                                                     &fmtCodeToTreat);

                        if (RET_GET_LEVEL(retCode) == RET_LEV_ERROR)
                        {
                            stdMsg.printMsg(retCode, SYS_Stringer("Unable to generate format element from reference format ", GET_CODE(fmtIt.second, A_Fmt_Cd)));
                        }
                    }
                }

                for (auto &fmtIt : fmtMap)
                {
                    /* nature_e in (13, 14) */
                    if (GET_A_Fmt_NatEn(fmtIt.second) == FmtNatEn::PersistedData)
                    {
                        xdEntitySqlNameSet.insert(std::make_pair(GET_SYSNAME(fmtIt.second, A_Fmt_Cd), DictEntityNatEn::PersistedDataFormat));
                    }
                    else if (GET_A_Fmt_NatEn(fmtIt.second) == FmtNatEn::SearchData)
                    {
                        xdEntitySqlNameSet.insert(std::make_pair(GET_SYSNAME(fmtIt.second, A_Fmt_Cd), DictEntityNatEn::SearchData));
                    }
                    else
                    {
                        auto& rptFinServiceFmtMap = ddlGenDbaAccess.selAllRecords(ReportFinServiceFormat, true, false);
                        /* report_fin_service_format */
                        for (auto& tpjecIt : rptFinServiceFmtMap)
                        {
                            if (CMP_DYNFLD(tpjecIt.second, fmtIt.second, A_ReportFinServiceFormat_FmtId, A_Fmt_Id, IdType) == 0)
                            {
                                xdEntitySqlNameSet.insert(std::make_pair(GET_SYSNAME(fmtIt.second, A_Fmt_Cd), DictEntityNatEn::ReportFormat));
                                break;
                            }
                        }

                        /*
                            inner join tsl_prec_job_element_compo tpjec on fmt.id = tpjec.format_id
                            inner join tsl_prec_job_element tpje on tpjec.tsl_prec_job_element_id = tpje.id
                            inner join tsl_prec_job tpj on tpje.tsl_prec_job_id = tpj.id
                        */
                        auto& tslPrecJobEltCompoMap = ddlGenDbaAccess.selAllRecords(TslPrecJobElementCompo, true, false);
                        for (auto& tpjecIt : tslPrecJobEltCompoMap)
                        {
                            if (CMP_DYNFLD(tpjecIt.second, fmtIt.second, A_TslPrecJobElementCompo_FmtId, A_Fmt_Id, IdType) == 0)
                            {
                                auto& tslPrecJobEltMap = ddlGenDbaAccess.selAllRecords(TslPrecJobElement, true, false);
                                for (auto& tpjeIt : tslPrecJobEltMap)
                                {
                                    if (CMP_DYNFLD(tpjecIt.second, tpjeIt.second, A_TslPrecJobElementCompo_TslPrecJobElementId, A_TslPrecJobElement_Id, IdType) == 0)
                                    {
                                        auto& tslPrecJobMap = ddlGenDbaAccess.selAllRecords(TslPrecJob, true, false);
                                        for (auto& tpjIt : tslPrecJobMap)
                                        {
                                            if (CMP_DYNFLD(tpjeIt.second, tpjIt.second, A_TslPrecJobElement_TslPrecJobId, A_TslPrecJob_Id, IdType) == 0)
                                            {
                                                entityDictIdSet.insert(GET_DICT(tpjIt.second, A_TslPrecJob_EntityDictId));
                                                break;
                                            }
                                        }
                                        break;
                                    }
                                }
                                break;
                            }
                        }
                    }

                    SET_INTERNAL(fmtIt.second, (GET_INTERNAL(fmtIt.second) | INTERNAL_TREATED));
                }
            }

            for (auto &it : xdEntitySqlNameSet)
            {
                auto xdEntityStp = ddlGenDbaAccess.getRecordByCode(XdEntity, it.first);
                if (xdEntityStp == nullptr)
                {
                    xdEntityStp = ddlGenDbaAccess.allocDynSt(FILEINFO, A_XdEntity);

                    SET_SYSNAME(xdEntityStp, A_XdEntity_SqlName, it.first.c_str());
                    SET_SYSNAME(xdEntityStp, A_XdEntity_Name, it.first.c_str());
                    SET_A_XdEntity_NatEn(xdEntityStp, it.second);
                    SET_ENUM(xdEntityStp, A_XdEntity_XdStatusEn, ExpUpdStatus_None);
                    SET_ENUM(xdEntityStp, A_XdEntity_XdActionEn, XdAction_ToInsert);

                    ddlGenDbaAccess.insUpdDelRecord(Insert, XdEntity, UNUSED, xdEntityStp, false);
                }

                toTreatMap[XdEntity].insert(xdEntityStp);
            }

            for (auto &it : entityDictIdSet)
            {
                auto dictEntityStp = ddlGenDbaAccess.getDictEntityById(it);
                if (dictEntityStp != nullptr)
                {
                    auto xdEntityStp = ddlGenDbaAccess.getRecordByCode(XdEntity, GET_SYSNAME(dictEntityStp, A_DictEntity_SqlName));

                    if (xdEntityStp != nullptr)
                    {
                        xdEntityIdSet.insert(GET_ID(xdEntityStp, A_XdEntity_Id));
                    }
                }
            }

            for (auto &it : xdEntityIdSet)
            {
                auto xdEntityStp = ddlGenDbaAccess.getRecordById(XdEntity, it, true);
                if (xdEntityStp != nullptr)
                {
                    toTreatMap[XdEntity].insert(xdEntityStp);
                }
            }

            /* Questionnaire */
            auto &questDefMap = ddlGenDbaAccess.selAllRecords(QuestDef, false, false);
            for (auto &questDefIt : questDefMap)
            {
                toTreatMap[QuestDef].insert(questDefIt.second);
                SET_INTERNAL(questDefIt.second, (GET_INTERNAL(questDefIt.second) | INTERNAL_TREATED));
            }

            if (toTreatMap.empty() == false)
            {
                ddlGenContext.loadMetaDictData();
                ddlGenContext.loadExtendedData();
            }
        }
        else
        {
            DBA_DYNFLD_STP *shXdEntityTab = nullptr;
            int             shXdEntityNbr = 0;

            ret = DBA_Select2(XdEntity,
                              (ddlGenAction.m_bSingleEntity ? DBA_ROLE_UDT : UNUSED),
                              S_XdEntity,
                              searchShXdEntityStp,
                              S_XdEntity,
                              &shXdEntityTab,
                              UNUSED,
                              UNUSED,
                              &shXdEntityNbr,
                              ddlGenConnGuard.getDbiConn());

            for (int i = 0; i < shXdEntityNbr; ++i)
            {
                shXdEntityVector.push_back(shXdEntityTab[i]);
                mp.ownerDynStp(shXdEntityTab[i]);
            }
            FREE(shXdEntityTab);
        }

        if (ddlGenAction.m_bSingleEntity == false)
        {
            for (auto &shXdEntityIt : shXdEntityVector)
            {
                if (GET_ENUM(shXdEntityIt, S_XdEntity_XdActionEn) != XdAction_None &&
                    GET_ENUM(shXdEntityIt, S_XdEntity_XdStatusEn) != XdStatus_Failed)
                {
                    bNewImport = true;
                    break;
                }
            }
        }
        else
        {
            for (auto &shXdEntityIt : shXdEntityVector)
            {
                if (GET_ENUM(shXdEntityIt, S_XdEntity_XdActionEn) == XdAction_ToInsert)
                {
                    ddlGenContext.toInsertEntitySqlNameSet.insert(GET_SYSNAME(shXdEntityIt, S_XdEntity_SqlName));
                }
            }
        }
    }

    /* PMSTA-43367 - LJE - 210420 */
    if (ddlGenAction.m_bSingleEntity &&
        ddlGenAction.m_bInitEntityOnly == false &&
        ddlGenAction.m_entitySqlnameStr.empty())
    {
        std::map<std::string, DBA_DYNFLD_STP> shXdEntityMap;
        for (auto& shXdEntityIt : shXdEntityVector)
        {
            shXdEntityMap[GET_SYSNAME(shXdEntityIt, S_XdEntity_SqlName)] = shXdEntityIt;
        }

        ddlGenContext.initConnection(nullptr, true);

        if (ddlGenAction.m_fromImport == false)
        {
            DBA_DYNFLD_STP* allPackageInstallationCompoTab = NULL;
            int             allPackageInstallationCompoNbr = 0;

            ret = DBA_Select2(PackageInstallationCompo,
                              DBA_ROLE_UDT,
                              NullDynSt,
                              nullptr,
                              A_PackageInstallationCompo,
                              &allPackageInstallationCompoTab,
                              UNUSED,
                              UNUSED,
                              &allPackageInstallationCompoNbr,
                              ddlGenConnGuard.getDbiConn());

            if (allPackageInstallationCompoNbr > 0)
            {
                DbiConnectionHelper         dbiConnHelper(&ddlGenConnGuard.getDbiConn());
                RequestHelper               requestHelper(dbiConnHelper);
                std::set<std::string>       fmtSet;

                DICT_T formatEntityDictId = 0;
                DBA_GetDictId(Fmt, &formatEntityDictId);
                DICT_T questEntityDictId = 0;
                DBA_GetDictId(QuestDef, &questEntityDictId);
                DICT_T tslPrecJobEntityDictId = 0;
                DBA_GetDictId(TslPrecJob, &tslPrecJobEntityDictId);

                for (int i = 0; i < allPackageInstallationCompoNbr; i++)
                {
                    bool bToTreat = false;

                    if (IS_NULLFLD(allPackageInstallationCompoTab[i], A_PackageInstallationCompo_Key) == FALSE)
                    {
                        if (GET_DICT(allPackageInstallationCompoTab[i], A_PackageInstallationCompo_EntityDictId) == formatEntityDictId)
                        {
                            std::stringstream     fullKey;
                            BuildBindOption       buildBindOption(BuildBindOption::Categ::MdAttribute);
                            ReaderParserRapidJson jsonParser(buildBindOption, nullptr);

                            fullKey << "{\"S_Fmt\": [" << GET_STRING(allPackageInstallationCompoTab[i], A_PackageInstallationCompo_Key) << "]}";

                            jsonParser.parse(fullKey.str());
                            if (jsonParser.setNextResultSet())
                            {
                                auto currentDynStPtr = jsonParser.getNextDynStp(ReaderParser::MEMORY_OWNED_BY::ReaderParser);

                                if (currentDynStPtr != nullptr &&
                                    fmtSet.insert(GET_CODE(currentDynStPtr, S_Fmt_Cd)).second &&
                                    dbiConnHelper.dbaGet(Fmt, UNUSED, currentDynStPtr, &currentDynStPtr) == RET_SUCCEED)
                                {
                                    std::set<std::string> fmtCodeToTreat;

                                    fmtCodeToTreat.insert(GET_CODE(currentDynStPtr, S_Fmt_Cd));

                                    if (IS_NULLFLD(currentDynStPtr, S_Fmt_ReferenceFmtId) == FALSE)
                                    {
                                        RET_CODE retCode = DBA_GenerateFormatElement(GenerateFmteltScopeEn::ChildFormats,
                                                                                     GET_ID(currentDynStPtr, S_Fmt_Id),
                                                                                     0,
                                                                                     0,
                                                                                     0,
                                                                                     FALSE,
                                                                                     GenerateFmteltCheckApplParamEn::No,
                                                                                     &fmtCodeToTreat);

                                        if (RET_GET_LEVEL(retCode) == RET_LEV_ERROR)
                                        {
                                            stdMsg.printMsg(retCode, SYS_Stringer("Unable to generate format element from reference format ", GET_CODE(currentDynStPtr, S_Fmt_Cd)));

                                            SET_ENUM(allPackageInstallationCompoTab[i], A_PackageInstallationCompo_XdStatusEn, XdStatus_Failed);
                                        }
                                        else
                                        {
                                            SET_ENUM(allPackageInstallationCompoTab[i], A_PackageInstallationCompo_XdStatusEn, XdStatus_Inserted);
                                        }
                                    }

                                    for (auto it = fmtCodeToTreat.begin(); it != fmtCodeToTreat.end(); ++it)
                                    {
                                        auto shXdEntityStp = mp.allocDynst(FILEINFO, S_XdEntity);

                                        SET_CODE(currentDynStPtr, S_Fmt_Cd, it->c_str());

                                        if (dbiConnHelper.dbaGet(XdEntity, UNUSED, currentDynStPtr, &shXdEntityStp) == RET_SUCCEED &&
                                            IS_NULLFLD(shXdEntityStp, S_XdEntity_SqlName) == FALSE)
                                        {
                                            if (GET_ENUM(shXdEntityStp, S_XdEntity_NatEn) != EntityNat_All)
                                            {
                                                auto existsShXdEntity = shXdEntityMap.find(GET_SYSNAME(shXdEntityStp, S_XdEntity_SqlName));
                                                if (existsShXdEntity == shXdEntityMap.end())
                                                {
                                                    shXdEntityVector.push_back(shXdEntityStp);
                                                    shXdEntityMap[GET_SYSNAME(shXdEntityStp, S_XdEntity_SqlName)] = shXdEntityStp;
                                                }
                                                else
                                                {
                                                    shXdEntityStp = existsShXdEntity->second;
                                                }
                                                currPackageInstallationCompoMap[GET_SYSNAME(shXdEntityStp, S_XdEntity_SqlName)].push_back(allPackageInstallationCompoTab[i]);
                                                bToTreat = true;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        else if (GET_DICT(allPackageInstallationCompoTab[i], A_PackageInstallationCompo_EntityDictId) == questEntityDictId)
                        {
                            std::stringstream     fullKey;
                            BuildBindOption       buildBindOption(BuildBindOption::Categ::MdAttribute);
                            ReaderParserRapidJson jsonParser(buildBindOption, nullptr);

                            fullKey << "{\"S_QuestDef\": [" << GET_STRING(allPackageInstallationCompoTab[i], A_PackageInstallationCompo_Key) << "]}";

                            jsonParser.parse(fullKey.str());
                            if (jsonParser.setNextResultSet())
                            {
                                auto currentDynStPtr = jsonParser.getNextDynStp(ReaderParser::MEMORY_OWNED_BY::ReaderParser);

                                if (currentDynStPtr != nullptr)
                                {
                                    auto shXdEntityStp = mp.allocDynst(FILEINFO, S_XdEntity);

                                    std::string quesDefStr(SYS_Stringer("qu_", GET_CODE(currentDynStPtr, S_QuestDef_Cd)));
                                    if (IS_NULLFLD(currentDynStPtr, S_QuestDef_Revision) == false)
                                    {
                                        quesDefStr += SYS_Stringer("_", GET_INT(currentDynStPtr, S_QuestDef_Revision));
                                    }

                                    SET_SYSNAME(shXdEntityStp, S_XdEntity_SqlName, quesDefStr.c_str());
                                    SET_ENUM(shXdEntityStp, S_XdEntity_NatEn, EntityNat_Questionnaire);

                                    if (DBA_CreateXdModelForQuestByCd(quesDefStr, ddlGenContext) == RET_SUCCEED)
                                    {
                                        dbiConnHelper.dbaGet(XdEntity, UNUSED, shXdEntityStp, &shXdEntityStp);

                                        auto existsShXdEntity = shXdEntityMap.find(GET_SYSNAME(shXdEntityStp, S_XdEntity_SqlName));
                                        if (existsShXdEntity == shXdEntityMap.end())
                                        {
                                            SET_ENUM(shXdEntityStp, S_XdEntity_XdActionEn, XdAction_ToInsert);

                                            shXdEntityVector.push_back(shXdEntityStp);
                                            shXdEntityMap[GET_SYSNAME(shXdEntityStp, S_XdEntity_SqlName)] = shXdEntityStp;
                                        }
                                        else
                                        {
                                            shXdEntityStp = existsShXdEntity->second;
                                        }

                                        currPackageInstallationCompoMap[GET_SYSNAME(shXdEntityStp, S_XdEntity_SqlName)].push_back(allPackageInstallationCompoTab[i]);
                                        bToTreat = true;
                                    }
                                    else
                                    {
                                        stdMsg.printMsg(RET_DBA_ERR_INVDATA, SYS_Stringer("Unable to generate the questionnaire ", GET_CODE(currentDynStPtr, S_QuestDef_Cd)));

                                        SET_ENUM(allPackageInstallationCompoTab[i], A_PackageInstallationCompo_XdStatusEn, XdStatus_Failed);
                                    }
                                }
                            }
                        }
                        else if (GET_DICT(allPackageInstallationCompoTab[i], A_PackageInstallationCompo_EntityDictId) == tslPrecJobEntityDictId)
                        {
                            std::stringstream     fullKey;
                            BuildBindOption       buildBindOption(BuildBindOption::Categ::MdAttribute);
                            ReaderParserRapidJson jsonParser(buildBindOption, nullptr);

                            fullKey << "{\"S_TslPrecJob\": [" << GET_STRING(allPackageInstallationCompoTab[i], A_PackageInstallationCompo_Key) << "]}";

                            jsonParser.parse(fullKey.str());
                            if (jsonParser.setNextResultSet())
                            {
                                auto currentDynStPtr = jsonParser.getNextDynStp(ReaderParser::MEMORY_OWNED_BY::ReaderParser);

                                if (currentDynStPtr != nullptr &&
                                    dbiConnHelper.dbaGet(TslPrecJob, UNUSED, currentDynStPtr, &currentDynStPtr) == RET_SUCCEED)
                                {
                                    auto shXdEntityStp = mp.allocDynst(FILEINFO, S_XdEntity);

                                    COPY_DYNFLD(shXdEntityStp, S_XdEntity, S_XdEntity_SqlName, currentDynStPtr, S_TslPrecJob, S_TslPrecJob_EntitySqlName);

                                    dbiConnHelper.dbaGet(XdEntity, UNUSED, shXdEntityStp, &shXdEntityStp);

                                    if (GET_ENUM(shXdEntityStp, S_XdEntity_NatEn) != EntityNat_All)
                                    {
                                        auto existsShXdEntity = shXdEntityMap.find(GET_SYSNAME(shXdEntityStp, S_XdEntity_SqlName));
                                        if (existsShXdEntity == shXdEntityMap.end())
                                        {
                                            shXdEntityVector.push_back(shXdEntityStp);
                                            shXdEntityMap[GET_SYSNAME(shXdEntityStp, S_XdEntity_SqlName)] = shXdEntityStp;

                                            SET_ENUM(shXdEntityStp, S_XdEntity_XdActionEn, XdAction_ToInsert);
                                        }
                                        else
                                        {
                                            shXdEntityStp = existsShXdEntity->second;
                                        }
                                        currPackageInstallationCompoMap[GET_SYSNAME(shXdEntityStp, S_XdEntity_SqlName)].push_back(allPackageInstallationCompoTab[i]);
                                        bToTreat = true;
                                    }
                                }
                            }
                        }
                    }

                    if (bToTreat == false)
                    {
                        SET_ENUM(allPackageInstallationCompoTab[i], A_PackageInstallationCompo_XdActionEn, XdAction_None);

                        requestHelper.addProcedureCallForBatchMulti(Update,
                                                                    PackageInstallationCompo,
                                                                    DBA_ROLE_STATUS,
                                                                    allPackageInstallationCompoTab[i]);
                    }
                }

                mp.ownerDynStpTab(allPackageInstallationCompoTab, allPackageInstallationCompoNbr);

                requestHelper.executeBatchMulti();
            }
        }

        for (auto &toTreatObjIt : toTreatMap)
        {
            if (toTreatObjIt.first == QuestDef)
            {
                DbiConnectionHelper dbiConnHelper(&ddlGenConnGuard.getDbiConn());

                for (auto &recordstp : toTreatObjIt.second)
                {
                    auto shXdEntityStp = mp.allocDynst(FILEINFO, S_XdEntity);

                    std::string quesDefStr(SYS_Stringer("qu_", GET_CODE(recordstp, A_QuestDef_Cd)));
                    if (IS_NULLFLD(recordstp, A_QuestDef_Revision) == false)
                    {
                        quesDefStr += SYS_Stringer("_", GET_INT(recordstp, A_QuestDef_Revision));
                    }

                    SET_SYSNAME(shXdEntityStp, S_XdEntity_SqlName, quesDefStr.c_str());
                    SET_ENUM(shXdEntityStp, S_XdEntity_NatEn, EntityNat_Questionnaire);

                    if (DBA_CreateXdModelForQuestByCd(quesDefStr, ddlGenContext) == RET_SUCCEED)
                    {
                        dbiConnHelper.dbaGet(XdEntity, UNUSED, shXdEntityStp, &shXdEntityStp);

                        auto existsShXdEntity = shXdEntityMap.find(GET_SYSNAME(shXdEntityStp, S_XdEntity_SqlName));
                        if (existsShXdEntity == shXdEntityMap.end())
                        {
                            SET_ENUM(shXdEntityStp, S_XdEntity_XdActionEn, XdAction_ToInsert);

                            shXdEntityVector.push_back(shXdEntityStp);
                            shXdEntityMap[GET_SYSNAME(shXdEntityStp, S_XdEntity_SqlName)] = shXdEntityStp;
                        }
                    }
                }
            }
            else if (toTreatObjIt.first == XdEntity)
            {
                for (auto &recordstp : toTreatObjIt.second)
                {
                    auto existsShXdEntity = shXdEntityMap.find(GET_SYSNAME(recordstp, A_XdEntity_SqlName));
                    if (existsShXdEntity == shXdEntityMap.end())
                    {
                        auto shXdEntityStp = mp.allocDynst(FILEINFO, S_XdEntity);

                        CONVERT_DYNST(shXdEntityStp, S_XdEntity, recordstp, A_XdEntity);

                        SET_ENUM(shXdEntityStp, S_XdEntity_XdActionEn, XdAction_ToInsert);

                        shXdEntityVector.push_back(shXdEntityStp);
                        shXdEntityMap[GET_SYSNAME(shXdEntityStp, S_XdEntity_SqlName)] = shXdEntityStp;
                    }
                }
            }
        }

        ddlGenContext.commit();
        ddlGenContext.endConnection();

        /* PMSTA-48253 - LJE - 220328 - Add the linked entities */
        std::set<std::string> treatedEntitySet;
        for (auto shXdEntityIt = shXdEntityVector.begin(); shXdEntityIt != shXdEntityVector.end(); ++shXdEntityIt)
        {
            std::string sqlName = GET_SYSNAME(*shXdEntityIt, S_XdEntity_SqlName);

            if (treatedEntitySet.find(sqlName) == treatedEntitySet.end())
            {
                treatedEntitySet.insert(sqlName);

                auto dictEntityStp = DBA_GetEntityBySqlName(sqlName);

                if (dictEntityStp != nullptr &&
                    (dictEntityStp->linkEntitiesMap.empty() == false ||
                     dictEntityStp->linkedEntityStp != nullptr ||
                     dictEntityStp->physicalEntitiesMap.empty() == false ||
                     dictEntityStp->physicalEntityStp != nullptr))
                {
                    std::vector<DICT_ENTITY_STP> linkedEntitiesVector;

                    if (dictEntityStp->linkEntitiesMap.empty() == false)
                    {
                        for (auto it = dictEntityStp->linkEntitiesMap.begin(); it != dictEntityStp->linkEntitiesMap.end(); ++it)
                        {
                            linkedEntitiesVector.push_back(it->second);
                        }
                    }
                    if (dictEntityStp->linkedEntityStp != nullptr)
                    {
                        linkedEntitiesVector.push_back(dictEntityStp->linkedEntityStp);
                    }
                    if (dictEntityStp->physicalEntitiesMap.empty() == false)
                    {
                        for (auto it = dictEntityStp->physicalEntitiesMap.begin(); it != dictEntityStp->physicalEntitiesMap.end(); ++it)
                        {
                            linkedEntitiesVector.push_back(it->second);
                        }
                    }
                    if (dictEntityStp->physicalEntityStp != nullptr)
                    {
                        linkedEntitiesVector.push_back(dictEntityStp->physicalEntityStp);
                    }

                    for (auto it = linkedEntitiesVector.begin(); it != linkedEntitiesVector.end(); ++it)
                    {
                        auto existsShXdEntity = shXdEntityMap.find((*it)->mdSqlName);
                        if (existsShXdEntity == shXdEntityMap.end())
                        {
                            DBA_DYNFLD_STP shXdEntityStp = mp.allocDynst(FILEINFO, S_XdEntity);

                            SET_SYSNAME(shXdEntityStp, S_XdEntity_SqlName, (*it)->mdSqlName);
                            SET_SYSNAME(shXdEntityStp, S_XdEntity_Name, (*it)->nameStr.c_str());
                            SET_DICT(shXdEntityStp, S_XdEntity_EntityDictId, (*it)->entDictId);
                            SET_ENUM(shXdEntityStp, S_XdEntity_NatEn, (*it)->entNatEn);
                            SET_ENUM(shXdEntityStp, S_XdEntity_XdStatusEn, (*it)->xdStatusEn);
                            SET_ENUM(shXdEntityStp, S_XdEntity_XdActionEn, XdAction_None);

                            shXdEntityVector.push_back(shXdEntityStp);

                            shXdEntityMap[GET_SYSNAME(shXdEntityStp, S_XdEntity_SqlName)] = shXdEntityStp;
                        }

                        shXdEntityIt = shXdEntityVector.begin();
                    }
                }
            }
        }
    }

    /* PMSTA-49178 - LJE - 221118 - Manage the entity dependencies */
    if (ret == RET_SUCCEED &&
        shXdEntityVector.size() > 0 &&
        ((ddlGenAction.m_bSingleEntity && ddlGenAction.m_entitySqlnameStr.empty()) ||
         ddlGenAction.m_mainDdlObjNatEn == DbObjDdlObjNat_TslExtension))
    {
        std::map<std::string, std::pair<bool, DBA_DYNFLD_STP>> xdEntitySqlNameSet;
        for (auto &shXdEntityIt : shXdEntityVector)
        {
            xdEntitySqlNameSet[GET_SYSNAME(shXdEntityIt, S_XdEntity_SqlName)] = std::make_pair(false, shXdEntityIt);
        }
        shXdEntityVector.clear();

        std::map<std::string, DBA_DYNFLD_STP> shXdEntityMap;
        for (auto it = xdEntitySqlNameSet.begin(); ret == RET_SUCCEED && it != xdEntitySqlNameSet.end(); ++it)
        {
            if (it->second.first == false)
            {
                SET_SYSNAME(searchShXdEntityStp, S_XdEntity_SqlName, it->first.c_str());

                DBA_DYNFLD_STP *depXdEntityTab = NULL;
                int             depXdEntityNbr = 0;

                ret = DBA_Select2(XdEntity,
                                  DBA_ROLE_UDT,
                                  S_XdEntity,
                                  searchShXdEntityStp,
                                  S_XdEntity,
                                  &depXdEntityTab,
                                  UNUSED,
                                  UNUSED,
                                  &depXdEntityNbr,
                                  ddlGenConnGuard.getDbiConn());

                if (depXdEntityNbr > 0)
                {
                    for (int i = 0; i < depXdEntityNbr; i++)
                    {
                        auto shXdEntityIt = shXdEntityMap.find(GET_SYSNAME(depXdEntityTab[i], S_XdEntity_SqlName));
                        if (shXdEntityIt == shXdEntityMap.end())
                        {
                            mp.ownerDynStp(depXdEntityTab[i]);

                            xdEntitySqlNameSet[GET_SYSNAME(depXdEntityTab[i], S_XdEntity_SqlName)].first = false;
                            shXdEntityMap[GET_SYSNAME(depXdEntityTab[i], S_XdEntity_SqlName)] = depXdEntityTab[i];
                        }
                        else
                        {
                            FREE_DYNST(depXdEntityTab[i], S_XdEntity);
                        }
                    }
                }
                else
                {
                    shXdEntityMap[GET_SYSNAME(searchShXdEntityStp, S_XdEntity_SqlName)] = it->second.second;
                }

                FREE(depXdEntityTab);

                it->second.first = true;
                it = xdEntitySqlNameSet.begin();
            }
        }

        for (auto &it : shXdEntityMap)
        {
            shXdEntityVector.push_back(it.second);
        }
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DDL_ManageLabels()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-46681 - LJE - 231103
**
*************************************************************************/
STATIC RET_CODE DDL_ManageLabels(DdlGenContext&                            ddlGenContext,
                                 MemoryPool&                               mp,
                                 DBOBJDDLOBJNAT_ENUM                       mainDdlObjNatEn,
                                 std::map<std::string, DdlGenBuildInfo*>&  xdEntityIdxMap,
                                 std::vector<DdlGenBuildInfo*>&            genDdlTab)
{
    RET_CODE              ret = RET_SUCCEED;

    DdlGenAction& ddlGenAction = ddlGenContext.ddlGenAction;

    if (mainDdlObjNatEn != DbObjDdlObjNat_ReportFmt &&
        mainDdlObjNatEn != DbObjDdlObjNat_System)
    {
        DdlGenDbaAccessGuard ddlGenDbaAccessGuard(ddlGenContext);

        if (mainDdlObjNatEn == DbObjDdlObjNat_AllTable &&
            ddlGenAction.m_bSingleEntity == false)
        {
            ddlGenDbaAccessGuard.getDdlGenDbaAccess().importAllData();
            ddlGenDbaAccessGuard.getDdlGenDbaAccess().cleanUpDictLabels();
        }

        bool bToLoadLabels = (ddlGenAction.m_bSingleEntity == false);
        for (auto it = genDdlTab.begin(); bToLoadLabels == false && it != genDdlTab.end(); ++it)
        {
            if (GET_ENUM((*it)->getShXdEntityStp(), S_XdEntity_NatEn) != EntityNat_PersistedFmt &&
                GET_ENUM((*it)->getShXdEntityStp(), S_XdEntity_NatEn) != EntityNat_SearchFmt &&
                GET_ENUM((*it)->getShXdEntityStp(), S_XdEntity_NatEn) != EntityNat_TempTable &&
                GET_ENUM((*it)->getShXdEntityStp(), S_XdEntity_NatEn) != EntityNat_ReportFmt &&
                GET_ENUM((*it)->getShXdEntityStp(), S_XdEntity_NatEn) != EntityNat_Questionnaire &&
                GET_ENUM((*it)->getShXdEntityStp(), S_XdEntity_NatEn) != EntityNat_DerivedEntity)
            {
                bToLoadLabels = true;
            }
        }

        if (bToLoadLabels)
        {
            ddlGenDbaAccessGuard.getDdlGenDbaAccess().loadLabels();
        }
        else if (ddlGenAction.m_fromImport == false)
        {
            ret = ddlGenDbaAccessGuard.getDdlGenDbaAccess().flushData();
        }

        if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
        {
            ddlGenAction.m_ddlObjNatEn = DbObjDdlObjNat_Label;

            ret = DBA_BuildAllDdlObject(ddlGenAction,
                                        ddlGenContext,
                                        xdEntityIdxMap,
                                        genDdlTab,
                                        mp);

            if (RET_GET_LEVEL(ret) != RET_LEV_ERROR && bToLoadLabels)
            {
                ddlGenDbaAccessGuard.getDdlGenDbaAccess().processLabels();
            }
        }
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DDL_BuildTable()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13109 - LJE - 111115
**
*************************************************************************/
STATIC RET_CODE DDL_BuildTable(DdlGenContext& ddlGenContext, int level)
{
    MemoryPool            mp;

    DdlGenMsg             gblMsg(ddlGenContext);
    DdlGenMsg             stdMsg(ddlGenContext);

    RET_CODE              ret              = RET_SUCCEED;
    DdlGenAction&         ddlGenAction     = ddlGenContext.ddlGenAction;
    DBOBJDDLOBJNAT_ENUM   mainDdlObjNatEn  = ddlGenAction.m_ddlObjNatEn;
    DdlGenConnGuard       ddlGenConnGuard(ddlGenContext);
    bool                  toInsertBehavior = false;

#ifdef AAAPURIFY
#ifdef NT
    PurifyNewLeaks();
#endif
#endif

    /* PMSTA-37374 - LJE - 210407 */
    if (ddlGenAction.m_entitySqlnameStr == "init")
    {
        ddlGenAction.m_bInitEntityOnly = true;
        ddlGenAction.m_entitySqlnameStr.clear();
    }

    if (ddlGenAction.m_entitySqlnameStr.empty() == false &&
        ddlGenAction.m_entitySqlnameStr[0] != 0 &&
        ddlGenAction.m_entitySqlnameStr[1] != 0)
    {
        ddlGenContext.ddlGenAction.m_bSingleEntity = true;
    }
    else
    {
        ddlGenAction.m_entitySqlnameStr.clear();
    }
    std::string mainEntitySqlnameStr = ddlGenAction.m_entitySqlnameStr;

    if (level == 0)
    {
        /* Check parameters */
        switch (mainDdlObjNatEn)
        {
            case DbObjDdlObjNat_UserTable:
            case DbObjDdlObjNat_UserTableDS:
            case DbObjDdlObjNat_ModelBank:  /* PMSTA-27352 - LJE - 170606 */
            case DbObjDdlObjNat_TempTable:
            case DbObjDdlObjNat_PersistedFmt: /* PMSTA13876 - DDV - 130808 */
            case DbObjDdlObjNat_ReportFmt: /* PMSTA-22072 - LJE - 160108 */
            case DbObjDdlObjNat_Questionnaire: /* PMSTA-19243 - DDV - 150330 */
            case DbObjDdlObjNat_TslExtension:
                if (ddlGenAction.m_installLevel > 4 && ddlGenAction.m_installLevel < 9)
                {
                    ddlGenAction.m_installLevel = 4;
                }
                break;

            case DbObjDdlObjNat_System:
                ddlGenAction.m_installLevel = 9;
                ddlGenAction.m_bInitEntityOnly = true;
                break;

            case DbObjDdlObjNat_AllTable:
                ddlGenContext.m_bDatAll = (ddlGenAction.isBootStrapLevel() || DBA_GetEntityBySqlName("format") == nullptr);

                if (ddlGenAction.m_bSingleEntity)
                {
                    ddlGenAction.m_installLevel = 4;
                }
                else if ((ddlGenAction.m_installLevel < 4 || ddlGenAction.m_installLevel > 5) &&
                         ddlGenAction.isBootStrapLevel() == false)
                {
                    ddlGenAction.m_installLevel = 5;
                }
                break;

            default:
                std::stringstream msg;

                ret = RET_GEN_ERR_INVARG;
                msg << "ddl object nature " << (int)mainDdlObjNatEn << " not yet implemented";
                MSG_SendMesg(ret, 1, FILEINFO, "DDL_BuildUdTable", msg.str().c_str());

                stdMsg.printMsg(ret, msg.str());
                return(ret);
        }

        gblMsg.printMsg(RET_SRV_INFO_RUNNING, "Start processing...");

        MSGNAT_ENUM msgType = MsgNat_Error;
        GEN_SetApplInfo(ApplImportMessageOnStringOverflow, &msgType);

        if (ddlGenContext.m_bDatAll)
        {
            ddlGenContext.optimMask = 0;
        }
    }

    /* PMSTA-10423 - skip questionnaire entities, they are build only when mode specific to questionnaire is use */
    if (ddlGenAction.m_bSingleEntity &&
        strncmp(ddlGenAction.m_entitySqlnameStr.c_str(), "qu_", 3) == 0) /* PMSTA-19243 - DDV - 150330 */
    {
        if (mainDdlObjNatEn == DbObjDdlObjNat_Questionnaire)
        {
            std::string msg("Creation of data model for " + ddlGenAction.m_entitySqlnameStr);
            ddlGenContext.printMsg(RET_SRV_INFO_RUNNING, msg);

            ddlGenContext.loadMetaDictData();
            ddlGenContext.loadExtendedData();

            ret = DBA_CreateXdModelForQuestByCd(ddlGenAction.m_entitySqlnameStr, ddlGenContext);

            ddlGenContext.printMsg(ret, msg);
        }
        else
        {
            ret = RET_GEN_ERR_NOACTION;
        }
    }

    if (ret != RET_GEN_ERR_NOACTION)
    {
        bool bLoadFullMetaDict = false;

        if ((ddlGenAction.m_bSingleEntity == false || mainDdlObjNatEn == DbObjDdlObjNat_AllTable) &&
            mainDdlObjNatEn != DbObjDdlObjNat_Questionnaire &&
            mainDdlObjNatEn != DbObjDdlObjNat_ReportFmt)
        {
            bLoadFullMetaDict = true;
        }

        DBA_DYNFLD_STP searchShXdEntityStp = ddlGenAction.getSearchShXdEntityStp();

        DBA_DYNFLD_STP admArgStp = mp.allocDynst(FILEINFO, Adm_Arg);
        bool           bNoError = true;

        SET_ENUM(searchShXdEntityStp, S_XdEntity_NatEn, EntityNat_All);

        bool             bNewImport = false;
        auto            &shXdEntityVector = ddlGenAction.m_shXdEntityVector;
        std::map<std::string, std::vector<DBA_DYNFLD_STP>> currPackageInstallationCompoMap;

        if (ddlGenAction.m_bSingleEntity)
        {
            if (ddlGenAction.m_entitySqlnameStr.compare("to_insert") == 0)
            {
                ddlGenAction.m_entitySqlnameStr.clear();
                toInsertBehavior  = true;
            }
            else
            {
                SET_SYSNAME(searchShXdEntityStp, S_XdEntity_SqlName, ddlGenAction.m_entitySqlnameStr.c_str());

                if (mainDdlObjNatEn == DbObjDdlObjNat_ReportFmt)
                {
                    ddlGenContext.loadMetaDictData();

                    ret = DBA_CopyFmtToXd(searchShXdEntityStp, ddlGenContext);

                    if (ret != RET_SUCCEED)
                    {
                        stdMsg.printMsg(ret, "Unable to copy format " + ddlGenAction.m_entitySqlnameStr + " to extended meta-dictionary model");
                    }
                }
            }
        }
        else if (mainDdlObjNatEn == DbObjDdlObjNat_UserTableDS)
        {
            SET_ENUM(searchShXdEntityStp, S_XdEntity_NatEn, EntityNat_CustomDS);
        }
        else if (mainDdlObjNatEn == DbObjDdlObjNat_UserTable)
        {
            SET_ENUM(searchShXdEntityStp, S_XdEntity_NatEn, EntityNat_Custom);
        }
        /* PMSTA-27352 - LJE - 170606 */
        else if (mainDdlObjNatEn == DbObjDdlObjNat_ModelBank)
        {
            SET_ENUM(searchShXdEntityStp, S_XdEntity_NatEn, EntityNat_ModelBank);
        }
        else if (mainDdlObjNatEn == DbObjDdlObjNat_TempTable)
        {
            SET_ENUM(searchShXdEntityStp, S_XdEntity_NatEn, EntityNat_TempTable);
        }
        else if (mainDdlObjNatEn == DbObjDdlObjNat_System)
        {
            SET_ENUM(searchShXdEntityStp, S_XdEntity_NatEn, EntityNat_System);
        }
        else if (mainDdlObjNatEn == DbObjDdlObjNat_PersistedFmt) /* PMSTA13876 - DDV - 130808 */
        {
            SET_ENUM(searchShXdEntityStp, S_XdEntity_NatEn, EntityNat_PersistedFmt);
        }
        else if (mainDdlObjNatEn == DbObjDdlObjNat_SearchFmt) /* PMSTA13876 - DDV - 130808 */
        {
            SET_ENUM(searchShXdEntityStp, S_XdEntity_NatEn, EntityNat_SearchFmt);
        }
        else if (mainDdlObjNatEn == DbObjDdlObjNat_ReportFmt) /* PMSTA-22072 - LJE - 160108 */
        {
            SET_ENUM(searchShXdEntityStp, S_XdEntity_NatEn, EntityNat_ReportFmt);
        }
        else if (mainDdlObjNatEn == DbObjDdlObjNat_Questionnaire) /* PMSTA-19243 - DDV - 150330 */
        {
            SET_ENUM(searchShXdEntityStp, S_XdEntity_NatEn, EntityNat_Questionnaire);

            ddlGenContext.loadMetaDictData();
            ddlGenContext.loadExtendedData();

            /* PMSTA-19243 - DDV - Build xd_ model for questionnaires */
            ret = DBA_CreateAllXdModelForQuest(ddlGenContext);

            if (ret != RET_SUCCEED)
            {
                stdMsg.printMsg(ret, "Unable to copy all questionnaires to extended meta-dictionary model");
            }
        }

        if (ret == RET_SUCCEED &&
            ddlGenAction.m_bSingleEntity == false &&
            mainDdlObjNatEn != DbObjDdlObjNat_TslExtension &&
            mainDdlObjNatEn != DbObjDdlObjNat_Questionnaire &&
            mainDdlObjNatEn != DbObjDdlObjNat_ReportFmt &&
            ddlGenContext.optimLevelEn != DdlGenContext::OptimLevel::Full &&
            ddlGenAction.m_bInitEntityOnly == false)
        {
            ddlGenContext.initConnection(nullptr, true);

            ret = DBA_Copy(XdEntity,
                           UNUSED,
                           S_XdEntity,
                           searchShXdEntityStp,
                           DBA_SET_CONN | DBA_NO_CLOSE,
                           ddlGenConnGuard.getDbiConn());

            ddlGenContext.commit();
            ddlGenContext.endConnection();
        }

        if (ret == RET_SUCCEED)
        {
            if ((mainDdlObjNatEn == DbObjDdlObjNat_AllTable || mainDdlObjNatEn == DbObjDdlObjNat_System) &&
                ddlGenContext.optimLevelEn == DdlGenContext::OptimLevel::Full &&
                ddlGenAction.m_bSingleEntity == false)
            {
                ddlGenContext.loadMetaDictData();

                ddlGenContext.ddlGenAction.m_installLevel = 99;
                EV_AAAInstallLevel = ddlGenContext.ddlGenAction.m_installLevel;

                if (ddlGenContext.ddlGenAction.m_bUseNativeQuery == false &&
                    ddlGenContext.m_bDatAll)
                {
                    DdlGenAction procDdlGenAction(ddlGenAction, true);

                    procDdlGenAction.m_mainDdlObjNatEn = DbObjDdlObjNat_System;
                    procDdlGenAction.m_ddlObjNatEn = DbObjDdlObjNat_StoredProc;
                    procDdlGenAction.m_execModeEn = DbObjExecMod_DBBuildWFiles;
                    procDdlGenAction.m_subRequest = true;

                    procDdlGenAction.m_entitySqlnameStr = "script_definition";
                    DDL_BuildDdlObject(ddlGenContext, procDdlGenAction);

                    procDdlGenAction.m_entitySqlnameStr = "xd_entity";
                    DDL_BuildDdlObject(ddlGenContext, procDdlGenAction);

                    procDdlGenAction.m_entitySqlnameStr = "dict_entity";
                    DDL_BuildDdlObject(ddlGenContext, procDdlGenAction);

                    procDdlGenAction.m_entitySqlnameStr = "dict_attribute";
                    DDL_BuildDdlObject(ddlGenContext, procDdlGenAction);

                    procDdlGenAction.m_entitySqlnameStr = "dict_language";
                    DDL_BuildDdlObject(ddlGenContext, procDdlGenAction);

                    if (ddlGenContext.m_bIsInstallFromScratch == false)
                    {
                        ddlGenContext.ddlGenAction.m_installLevel = 6;
                        procDdlGenAction.m_installLevel           = 6;

                        (void)ddlGenContext.getMultiEntityLevel();

                        if (ddlGenAction.m_bInitEntityOnly || ddlGenContext.m_bDatAll)
                        {
                            procDdlGenAction.m_entitySqlnameStr = "xd_attribute";
                            DDL_BuildDdlObject(ddlGenContext, procDdlGenAction);

                            procDdlGenAction.m_entitySqlnameStr = "xd_entity_feature";
                            DDL_BuildDdlObject(ddlGenContext, procDdlGenAction);

                            procDdlGenAction.m_entitySqlnameStr = "xd_perm_value";
                            DDL_BuildDdlObject(ddlGenContext, procDdlGenAction);

                            procDdlGenAction.m_entitySqlnameStr = "xd_index";
                            DDL_BuildDdlObject(ddlGenContext, procDdlGenAction);

                            procDdlGenAction.m_entitySqlnameStr = "xd_index_attrib";
                            DDL_BuildDdlObject(ddlGenContext, procDdlGenAction);

                            procDdlGenAction.m_entitySqlnameStr = "dict_perm_value";
                            DDL_BuildDdlObject(ddlGenContext, procDdlGenAction);

                            procDdlGenAction.m_entitySqlnameStr = "dict_criteria";
                            DDL_BuildDdlObject(ddlGenContext, procDdlGenAction);

                            procDdlGenAction.m_entitySqlnameStr = "dict_user";
                            DDL_BuildDdlObject(ddlGenContext, procDdlGenAction);

                            procDdlGenAction.m_entitySqlnameStr = "dict_database";
                            DDL_BuildDdlObject(ddlGenContext, procDdlGenAction);

                            procDdlGenAction.m_entitySqlnameStr = "dict_segment";
                            DDL_BuildDdlObject(ddlGenContext, procDdlGenAction);
                        }
                    }
                }
                else if (ddlGenContext.m_bIsInstallFromScratch == false)
                {
                    (void)ddlGenContext.getMultiEntityLevel();
                }

                ddlGenContext.manageSegment();


                ddlGenContext.ddlGenAction.m_installLevel = 6;
                EV_AAAInstallLevel = ddlGenContext.ddlGenAction.m_installLevel;

                ret = ddlGenContext.importAllData();
                ddlGenContext.ddlGenAction.m_installLevel = 5;
                EV_AAAInstallLevel = ddlGenContext.ddlGenAction.m_installLevel;

                ddlGenAction.m_mainDdlObjNatEn = mainDdlObjNatEn;

                ddlGenContext.setDdlGenActionInfoOnAllEntities();
            }

            /* PMSTA-45413 - LJE - 210611 - Remove the "blocking" trigger code */
            if (level == 0 &&
                ddlGenContext.bSimulation == false &&
                ddlGenAction.m_bRestrictUpdate &&
                (mainDdlObjNatEn != DbObjDdlObjNat_AllTable || ddlGenAction.m_bSingleEntity))
            {
                DdlGenAction procDdlGenAction(ddlGenAction, true);

                procDdlGenAction.m_ddlObjNatEn = DbObjDdlObjNat_Trigger;
                procDdlGenAction.m_execModeEn = DbObjExecMod_DBBuildWFiles;
                procDdlGenAction.m_entitySqlnameStr = "dict";
                procDdlGenAction.m_subRequest = true;
                procDdlGenAction.m_installLevel = 6;

                DDL_BuildDdlObject(ddlGenContext, procDdlGenAction);
            }

            /* Custom DS management */
            if (GET_ENUM(searchShXdEntityStp, S_XdEntity_NatEn) == EntityNat_CustomDS)
            {
                DBA_DYNFLD_STP* dictEntityTab = NULL;
                int             dictEntityNbr = 0;

                ddlGenContext.initConnection(nullptr, true);

                SET_ENUM(admArgStp, Adm_Arg_NatEn, EntityNat_CustomDS);

                /* Invalid all custom DS entities */
                DBA_Select2(DictEntity,
                            UNUSED,
                            Adm_Arg,
                            admArgStp,
                            A_DictEntity,
                            &dictEntityTab,
                            DBA_SET_CONN | DBA_NO_CLOSE,
                            UNUSED,
                            &dictEntityNbr,
                            ddlGenConnGuard.getDbiConn());

                for (int i = 0; i < dictEntityNbr; i++)
                {
                    SET_ENUM(dictEntityTab[i], A_DictEntity_XdStatusEn, XdStatus_Deleted);

                    if ((ret = DBA_Update2(DictEntity,
                                           DBA_ROLE_STATUS,
                                           A_DictEntity,
                                           dictEntityTab[i],
                                           DBA_SET_CONN | DBA_NO_CLOSE,
                                           ddlGenConnGuard.getDbiConn(),
                                           UNUSED)) != RET_SUCCEED)
                    {
                        MSG_SendMesg(RET_DBA_ERR_UPDATE_FAILED, 0, FILEINFO);
                        return(RET_DBA_ERR_UPDATE_FAILED);
                    }
                }

                ddlGenContext.commit();
                ddlGenContext.endConnection();

                DBA_FreeDynStTab(dictEntityTab, dictEntityNbr, A_DictEntity);
            }
        }

        if (ret == RET_SUCCEED)
        {
            ret = DDL_ExtractDataForBuild(ddlGenContext,
                                          ddlGenConnGuard,
                                          mp,
                                          currPackageInstallationCompoMap,
                                          bNewImport,
                                          stdMsg);
        }

        if (ret == RET_SUCCEED &&
            (ddlGenAction.m_bSingleEntity == false || shXdEntityVector.size() > 0))   /* PMSTA-43367 - LJE - 210419 */
        {
            if (bLoadFullMetaDict)
            {
                ddlGenContext.loadMetaDictData();

                if (mainDdlObjNatEn != DbObjDdlObjNat_TslExtension)
                {
                    DdlGenDbaAccessGuard ddlGenDbaAccessGuard(ddlGenContext);
                    ddlGenDbaAccessGuard.getDdlGenDbaAccess().applyCusto();
                    ddlGenDbaAccessGuard.getDdlGenDbaAccess().copyXdEntityDictBuildRule();
                }
                else
                {
                    ddlGenContext.loadExtendedData();
                    ddlGenContext.manageSegment();
                }
            }

            std::map<std::string, DdlGenBuildInfo*>  xdEntityIdxMap;
            std::vector<DdlGenBuildInfo*>       genDdlTab;

            for (auto &shXdEntityStp : shXdEntityVector)
            {
                /* PMSTA-45773 - LJE - 210716 */
                if (ddlGenContext.m_bIsInstallFromScratch == false &&
                    ddlGenContext.m_bDatAll               == false &&
                    (ddlGenAction.m_bSingleEntity == false || mainDdlObjNatEn != DbObjDdlObjNat_ReportFmt) &&
                    GET_ENUM(shXdEntityStp, S_XdEntity_XdActionEn) != XdAction_ToDelete &&
                    GET_ENUM(shXdEntityStp, S_XdEntity_XdActionEn) != XdAction_ToPhysicallyDelete &&
                    GET_ENUM(shXdEntityStp, S_XdEntity_XdStatusEn) != XdStatus_Deleted &&
                    GET_ENUM(shXdEntityStp, S_XdEntity_XdStatusEn) != XdStatus_PhysicallyDeleted)
                {
                    /* PMSTA-16528 - DDV - 140704 - Complete xd model for search entities.
                    Add labels based on denom and generate multi-lingual attributes */
                    if (GET_ENUM(shXdEntityStp, S_XdEntity_NatEn) == EntityNat_SearchFmt ||
                        GET_ENUM(shXdEntityStp, S_XdEntity_NatEn) == EntityNat_PersistedFmt)
                    {
                        ret = DBA_CopyFmtToXd(shXdEntityStp, ddlGenContext);

                        if (ret == RET_SUCCEED &&
                            GET_ENUM(shXdEntityStp, S_XdEntity_XdActionEn) == XdAction_ToInsert)
                        {
                            ret = DBA_CompleteXdModelForFmt(shXdEntityStp, ddlGenContext);
                        }
                    }
                    else if (GET_ENUM(shXdEntityStp, S_XdEntity_NatEn) == EntityNat_ReportFmt &&
                             (mainDdlObjNatEn != DbObjDdlObjNat_ReportFmt || ddlGenAction.m_bSingleEntity == false))
                    {
                        ret = DBA_CopyFmtToXd(shXdEntityStp, ddlGenContext);
                    }

                    if (ret != RET_SUCCEED)
                    {
                        stdMsg.printMsg(ret, "Unable to copy format " + ddlGenAction.m_entitySqlnameStr + " to extended meta-dictionary model");
                    }
                }

                DdlGenContext* ddlGenContextPtr = new DdlGenContext(ddlGenContext);
                DdlGenBuildInfo* ddlGenBuildInfo = new DdlGenBuildInfo(ddlGenContextPtr);
                mp.ownerObject(ddlGenBuildInfo);

                ddlGenBuildInfo->setShXdEntityStp(shXdEntityStp);

                genDdlTab.push_back(ddlGenBuildInfo);
                xdEntityIdxMap.insert(std::make_pair(GET_SYSNAME(shXdEntityStp, S_XdEntity_SqlName), ddlGenBuildInfo));
                ddlGenContext.setXdEntitySqlNameById(GET_ID(shXdEntityStp, S_XdEntity_Id), GET_SYSNAME(shXdEntityStp, S_XdEntity_SqlName));

                /* PMSTA-18593 - LJE - 151201 - Persisted and Report Formats special case */
                if ((mainDdlObjNatEn == DbObjDdlObjNat_AllTable &&
                     (GET_ENUM(shXdEntityStp, S_XdEntity_NatEn) == EntityNat_SearchFmt ||
                      GET_ENUM(shXdEntityStp, S_XdEntity_NatEn) == EntityNat_PersistedFmt ||
                      GET_ENUM(shXdEntityStp, S_XdEntity_NatEn) == EntityNat_ReportFmt)) ||
                    GET_ENUM(shXdEntityStp, S_XdEntity_NatEn) == EntityNat_Questionnaire)
                {
                    if ((GET_ENUM(shXdEntityStp, S_XdEntity_XdActionEn) == XdAction_None ||
                         GET_ENUM(shXdEntityStp, S_XdEntity_XdActionEn) == XdAction_ToInsert ||
                         GET_ENUM(shXdEntityStp, S_XdEntity_XdActionEn) == XdAction_ToDeprecate) &&
                        (GET_ENUM(shXdEntityStp, S_XdEntity_XdStatusEn) == XdStatus_Inserted ||
                         GET_ENUM(shXdEntityStp, S_XdEntity_XdStatusEn) == XdStatus_Failed))
                    {
                        SET_ENUM(shXdEntityStp, S_XdEntity_XdActionEn, XdAction_ToRefresh);
                    }
                }

                ddlGenAction.m_entitySqlnameStr = GET_SYSNAME(shXdEntityStp, S_XdEntity_SqlName);

                if (GET_ENUM(shXdEntityStp, S_XdEntity_XdActionEn) == XdAction_ToInsert ||
                    GET_ENUM(shXdEntityStp, S_XdEntity_XdActionEn) == XdAction_ToRefresh ||
                    (GET_ENUM(shXdEntityStp, S_XdEntity_XdActionEn) != XdAction_ToDelete &&
                     GET_ENUM(shXdEntityStp, S_XdEntity_XdActionEn) != XdAction_ToPhysicallyDelete &&
                     bNewImport == false))
                {
                    ddlGenBuildInfo->getDdlGenMsg().setDdlObjEn(DdlObj_Table);
                    ddlGenBuildInfo->getDdlGenMsg().setMsgSqlName(ddlGenAction.m_entitySqlnameStr);
                    ddlGenBuildInfo->getDdlGenMsg().setMsgEntitySqlName(ddlGenAction.m_entitySqlnameStr);
                    ddlGenBuildInfo->getDdlGenMsg().printMsg(RET_SRV_INFO_RUNNING, "Creating");

                    DdlGenFullTable* ddlGenFullTable = new DdlGenFullTable(ddlGenAction, *ddlGenContextPtr);

                    ddlGenBuildInfo->ddlGenFullTable = ddlGenFullTable;
                    ddlGenBuildInfo->retCode = ddlGenFullTable->lastErrRetCode;

                    if (ddlGenBuildInfo->retCode == RET_SUCCEED &&
                        (bNewImport == false || GET_ENUM(shXdEntityStp, S_XdEntity_XdActionEn) == XdAction_ToRefresh))
                    {
                        DdlGenDbaAccessGuard ddlGenDbaAccessGuard(ddlGenContext);
                        ddlGenDbaAccessGuard.getDdlGenDbaAccess().getExtendedData(*ddlGenFullTable->getDdlGenEntityPtr());

                        ddlGenFullTable->pushEntityToInsert(shXdEntityStp);
                    }
                }
                else if ((GET_ENUM(shXdEntityStp, S_XdEntity_XdActionEn) == XdAction_ToDelete ||
                          GET_ENUM(shXdEntityStp, S_XdEntity_XdActionEn) == XdAction_ToPhysicallyDelete ||
                          bNewImport) &&
                         GET_ENUM(shXdEntityStp, S_XdEntity_XdStatusEn) == XdStatus_Inserted)
                {
                    std::string           actionStr;

                    if (GET_ENUM(shXdEntityStp, S_XdEntity_XdActionEn) == XdAction_None)
                    {
                        SET_ENUM(shXdEntityStp, S_XdEntity_XdActionEn, XdAction_ToDelete);
                    }

                    switch (GET_ENUM(shXdEntityStp, S_XdEntity_XdActionEn))
                    {
                        case XdAction_ToDelete:
                            actionStr = "Deleting";
                            break;
                        case XdAction_ToPhysicallyDelete:
                            actionStr = "Physical Deleting";
                            break;
                        case XdAction_ToDeprecate:
                            actionStr = "Deprecating";
                            break;
                        default:
                            actionStr = "Unknown";
                            break;
                    }

                    ddlGenBuildInfo->getDdlGenMsg().setDdlObjEn(DdlObj_Table);
                    ddlGenBuildInfo->getDdlGenMsg().setMsgSqlName(ddlGenAction.m_entitySqlnameStr);
                    ddlGenBuildInfo->getDdlGenMsg().setMsgEntitySqlName(ddlGenAction.m_entitySqlnameStr);
                    ddlGenBuildInfo->getDdlGenMsg().printMsg(RET_SRV_INFO_RUNNING, actionStr);

                    DdlGenFullTable* ddlGenFullTable = new DdlGenFullTable(ddlGenAction, *ddlGenContextPtr);

                    ddlGenBuildInfo->ddlGenFullTable = ddlGenFullTable;
                    ddlGenBuildInfo->retCode = RET_SUCCEED;
                }

                /* PMSTA-43367 - LJE - 210420 */
                if (ddlGenBuildInfo->ddlGenFullTable != nullptr)
                {
                    auto pckInstallCompoIt = currPackageInstallationCompoMap.find(GET_SYSNAME(shXdEntityStp, S_XdEntity_SqlName));
                    if (pckInstallCompoIt != currPackageInstallationCompoMap.end())
                    {
                        ddlGenBuildInfo->ddlGenFullTable->m_packageInstallationCompoVector = pckInstallCompoIt->second;
                    }
                }

                ddlGenAction.m_entitySqlnameStr = mainEntitySqlnameStr;

                ddlGenContext.syncContext(*ddlGenContextPtr);
                ddlGenBuildInfo->getDdlGenMsg().printMsg(RET_SRV_INFO_DONE, "Done");
            }

            std::sort(genDdlTab.begin(), genDdlTab.end(), [](const auto& lhs, const auto& rhs)
                      {
                          if (lhs->m_objectDefPos > MAX_SHORT && rhs->m_objectDefPos > MAX_SHORT)
                          {
                              if (GET_ID(lhs->getShXdEntityStp(), S_XdEntity_Id) < 0 &&
                                  GET_ID(rhs->getShXdEntityStp(), S_XdEntity_Id) < 0)
                              {
                                  return (CMP_DYNFLD(rhs->getShXdEntityStp(), lhs->getShXdEntityStp(), S_XdEntity_Id, S_XdEntity_Id, IdType) < 0);
                              }

                              if (GET_ID(lhs->getShXdEntityStp(), S_XdEntity_Id) > 0 &&
                                  GET_ID(rhs->getShXdEntityStp(), S_XdEntity_Id) < 0)
                              {
                                  return (true);
                              }

                              if (GET_ID(lhs->getShXdEntityStp(), S_XdEntity_Id) < 0 &&
                                  GET_ID(rhs->getShXdEntityStp(), S_XdEntity_Id) > 0)
                              {
                                  return (false);
                              }

                              return (CMP_DYNFLD(lhs->getShXdEntityStp(), rhs->getShXdEntityStp(), S_XdEntity_Id, S_XdEntity_Id, IdType) < 0);
                          }

                          return (lhs->m_objectDefPos < rhs->m_objectDefPos);
                      });

            auto scptDefEntity = xdEntityIdxMap.find("script_definition");
            if (scptDefEntity == xdEntityIdxMap.end())
            {
                DICT_ENTITY_STP scptDictEntityStp = DBA_GetDictEntitySt(ScriptDef);

                if (scptDictEntityStp != nullptr)
                {
                    ddlGenContext.scriptControlXdEntId = scptDictEntityStp->xdEntityId;
                }
            }
            else
            {
                ddlGenContext.scriptControlXdEntId = GET_ID(scptDefEntity->second->getShXdEntityStp(), S_XdEntity_Id);
            }

            ddlGenAction.m_ddlObjNatEn = DbObjDdlObjNat_CheckAndFix;

            ret = DBA_BuildAllDdlObject(ddlGenAction,
                                        ddlGenContext,
                                        xdEntityIdxMap,
                                        genDdlTab,
                                        mp);

            if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
            {
                bNoError = false;
            }

            ddlGenAction.m_ddlObjNatEn = DbObjDdlObjNat_BuildInMemory;

            ret = DBA_BuildAllDdlObject(ddlGenAction,
                                        ddlGenContext,
                                        xdEntityIdxMap,
                                        genDdlTab,
                                        mp);

            if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
            {
                bNoError = false;
            }

            ddlGenContext.fillDictEntityFromXdIdMap();

            DICT_LinkFieldsToEntity(DBA_GetDictEntitySt(DictEntity),
                                    DBA_GetDictEntitySt(XdEntity),
                                    Null_Dynfld,
                                    Null_Dynfld,
                                    FALSE,
                                    FALSE,
                                    FALSE);
            DICT_LinkFieldsToEntity(DBA_GetDictEntitySt(DictAttr),
                                    DBA_GetDictEntitySt(XdAttrib),
                                    Null_Dynfld,
                                    Null_Dynfld,
                                    FALSE,
                                    FALSE,
                                    FALSE);
            DICT_LinkFieldsToEntity(DBA_GetDictEntitySt(DictPermVal),
                                    DBA_GetDictEntitySt(XdPermVal),
                                    Null_Dynfld,
                                    Null_Dynfld,
                                    FALSE,
                                    FALSE,
                                    FALSE);
            DICT_LinkFieldsToEntity(DBA_GetDictEntitySt(DictLabel),
                                    DBA_GetDictEntitySt(XdLabel),
                                    Null_Dynfld,
                                    Null_Dynfld,
                                    FALSE,
                                    FALSE,
                                    FALSE);

            std::vector< DBOBJDDLOBJNAT_ENUM> ddlObjNatToDoVector;
            ddlObjNatToDoVector.push_back(DbObjDdlObjNat_BuildInMetaDict1);
            ddlObjNatToDoVector.push_back(DbObjDdlObjNat_BuildInMetaDict2);
            ddlObjNatToDoVector.push_back(DbObjDdlObjNat_BuildInMetaDict3);
            ddlObjNatToDoVector.push_back(DbObjDdlObjNat_BuildInMetaDict4);
            ddlObjNatToDoVector.push_back(DbObjDdlObjNat_BuildInMetaDict5);

            std::vector<DdlGenBuildInfo*>       sysGenDdlTab;
            for (auto it = genDdlTab.begin(); it != genDdlTab.end(); ++it)
            {
                DdlGenBuildInfo* ddlGenBuildInfo = *it;

                if (ddlGenBuildInfo->ddlGenFullTable == nullptr ||
                    ddlGenBuildInfo->retCode == RET_GEN_INFO_NOACTION)
                    continue;

                DICT_ENTITY_STP currDictEntityStp = DBA_GetDictEntitySt(ddlGenBuildInfo->ddlGenFullTable->getObjectEn());

                if (currDictEntityStp != nullptr &&
                    currDictEntityStp->entNatEn == EntityNat_System)
                {
                    ddlGenBuildInfo->setDictEntityStp(currDictEntityStp);
                    sysGenDdlTab.push_back(*it);
                }
            }

            if (mainDdlObjNatEn != DbObjDdlObjNat_Questionnaire &&
                mainDdlObjNatEn != DbObjDdlObjNat_ReportFmt)
            {
                {
                    AAAValueGuard<bool> bInitEntityOnly(ddlGenAction.m_bInitEntityOnly);
                    ddlGenAction.m_bInitEntityOnly = true;

                    for (auto &ddlObjNatToDoIt : ddlObjNatToDoVector)
                    {
                        ddlGenAction.m_ddlObjNatEn = ddlObjNatToDoIt;

                        for (auto &it : sysGenDdlTab)
                        {
                            ret = DDL_BuildOneDdlObject(ddlGenAction,
                                                            *it,
                                                            nullptr);
                        }
                    }
                }

                /* Refresh memory meta-dictionary informations */
                for (auto it = sysGenDdlTab.begin(); it != sysGenDdlTab.end(); ++it)
                {
                    DdlGenBuildInfo* ddlGenBuildInfo = *it;

                    ddlGenBuildInfo->getDdlGenMsg().printMsg(RET_SRV_INFO_RUNNING, "Refreshing memory...");
                    DBA_UpdDictCriteria(ddlGenBuildInfo->ddlGenFullTable->getObjectEn(), false);
                    DBA_CreateDynStDef(ddlGenBuildInfo->ddlGenFullTable->getObjectEn(), ddlGenAction.m_fromImport);
                    ddlGenBuildInfo->getDdlGenMsg().printMsg(RET_SUCCEED, "Done");
                }

                ddlGenAction.m_ddlObjNatEn = DbObjDdlObjNat_BuildTableInDb;
                for (auto it = sysGenDdlTab.begin(); it != sysGenDdlTab.end(); ++it)
                {
                    AAAValueGuard<DDLGEN_BUILD_RULE_ENUM> buildRuleEn(ddlGenAction.m_buildRuleEn);
                    if (ddlGenContext.m_bDatAll &&
                        (*it)->getDictEntityStp()->objectEn == DictDepends)
                    {
                        ddlGenAction.m_buildRuleEn = DdlGenBuildRule_Truncate;
                    }
                    ret = DDL_BuildOneDdlObject(ddlGenAction,
                                                    *(*it),
                                                    nullptr);
                }

                ddlGenContext.loadExtendedData();
            }

            for (auto it = genDdlTab.begin(); it != genDdlTab.end(); ++it)
            {
                DdlGenBuildInfo* ddlGenBuildInfo = *it;

                if (ddlGenBuildInfo->ddlGenFullTable == nullptr ||
                    ddlGenBuildInfo->retCode == RET_GEN_INFO_NOACTION)
                    continue;

                if (RET_GET_LEVEL(ddlGenBuildInfo->retCode) == RET_LEV_ERROR)
                {
                    bNoError = false;

                    ret = ddlGenBuildInfo->retCode;
                    ddlGenBuildInfo->getDdlGenMsg().printMsg(ddlGenBuildInfo->retCode, "Applying modifications on table failed (see $AAAHOME/msg/log file) ");
                }
                else
                {
                    DdlGenDbaAccessGuard ddlGenDbaAccessGuard(ddlGenContext);
                    ddlGenDbaAccessGuard.getDdlGenDbaAccess().getExtendedData(*ddlGenBuildInfo->ddlGenFullTable->getDdlGenEntityPtr());
                }
            }

            if (bNoError)
            {
                if (mainDdlObjNatEn != DbObjDdlObjNat_TslExtension)
                {
                    for (auto it = genDdlTab.begin(); it != genDdlTab.end(); ++it)
                    {
                        DdlGenBuildInfo* ddlGenBuildInfo = *it;

                        if (ddlGenBuildInfo->ddlGenFullTable == nullptr ||
                            ddlGenBuildInfo->retCode == RET_GEN_INFO_NOACTION)
                            continue;

                        if (GET_ENUM(ddlGenBuildInfo->getShXdEntityStp(), S_XdEntity_XdActionEn) == XdAction_ToInsert &&
                            RET_GET_LEVEL(ddlGenBuildInfo->retCode) != RET_LEV_ERROR)
                        {
                            ddlGenBuildInfo->getDdlGenMsg().startTimer();
                            ddlGenBuildInfo->retCode = ddlGenBuildInfo->ddlGenFullTable->updateCrossLinks();
                            ddlGenBuildInfo->getDdlGenMsg().stopTimer();
                        }
                    }

                    DBA_UpdCrossLinkAttr();

                    if (ddlGenContext.getMultiEntityLevel() == MultiEntityLevel_Active ||                        /* PMSTA-34445 - LJE - 190326 */
                        /* PMSTA-36919 - LJE - 191004 - If no definition in me_data_orga table, do the old method */
                        (ddlGenContext.getMultiEntityLevel() == MultiEntityLevel_NoActive &&
                         ddlGenContext.m_parentContext->m_bHaveMultiEntityCateg &&              /* PMSTA-49178 - LJE - 220907 */
                         ddlGenContext.isEntityMtmFirstLevel(NullEntity) == true))
                    {
                        bool bRetry = false;
                        int  lastToRetryNbr = 0;
                        int  toRetryNbr = 0;
                        do
                        {
                            bRetry = false;
                            lastToRetryNbr = toRetryNbr;
                            toRetryNbr = 0;

                            for (auto it = genDdlTab.begin(); it != genDdlTab.end(); ++it)
                            {
                                DdlGenBuildInfo& ddlGenBuildInfo = *(*it);

                                if (ddlGenBuildInfo.ddlGenFullTable == nullptr)
                                    continue;

                                if (GET_ENUM(ddlGenBuildInfo.getShXdEntityStp(), S_XdEntity_XdActionEn) == XdAction_ToInsert &&
                                    RET_GET_LEVEL(ddlGenBuildInfo.retCode) != RET_LEV_ERROR)
                                {
                                    ddlGenBuildInfo.getDdlGenMsg().startTimer();
                                    ddlGenBuildInfo.retCode = ddlGenBuildInfo.ddlGenFullTable->manageMultiEntityCategory(true);
                                    if (ddlGenBuildInfo.retCode == RET_GEN_INFO_NOACTION)
                                    {
                                        toRetryNbr++;
                                        bRetry = true;
                                    }
                                    ddlGenBuildInfo.getDdlGenMsg().stopTimer();
                                }
                            }
                        } while (bRetry && toRetryNbr != lastToRetryNbr);

                        do
                        {
                            bRetry = false;
                            lastToRetryNbr = toRetryNbr;
                            toRetryNbr = 0;

                            for (auto it = genDdlTab.begin(); it != genDdlTab.end(); ++it)
                            {
                                DdlGenBuildInfo& ddlGenBuildInfo = *(*it);

                                if (ddlGenBuildInfo.ddlGenFullTable == nullptr)
                                    continue;

                                if (GET_ENUM(ddlGenBuildInfo.getShXdEntityStp(), S_XdEntity_XdActionEn) == XdAction_ToInsert &&
                                    RET_GET_LEVEL(ddlGenBuildInfo.retCode) != RET_LEV_ERROR)
                                {
                                    ddlGenBuildInfo.getDdlGenMsg().startTimer();
                                    ddlGenBuildInfo.retCode = ddlGenBuildInfo.ddlGenFullTable->manageMultiEntityCategory(false);
                                    if (ddlGenBuildInfo.retCode == RET_GEN_INFO_NOACTION)
                                    {
                                        toRetryNbr++;
                                        bRetry = true;
                                    }
                                    ddlGenBuildInfo.getDdlGenMsg().stopTimer();
                                }
                            }
                        } while (bRetry && toRetryNbr != lastToRetryNbr);

                        for (auto it = genDdlTab.begin(); it != genDdlTab.end(); ++it)
                        {
                            DdlGenBuildInfo* ddlGenBuildInfo = *it;

                            if (ddlGenBuildInfo->ddlGenFullTable == nullptr)
                                continue;

                            if (GET_ENUM(ddlGenBuildInfo->getShXdEntityStp(), S_XdEntity_XdActionEn) == XdAction_ToInsert &&
                                RET_GET_LEVEL(ddlGenBuildInfo->retCode) != RET_LEV_ERROR)
                            {
                                ddlGenBuildInfo->getDdlGenMsg().startTimer();
                                ddlGenBuildInfo->retCode = ddlGenBuildInfo->ddlGenFullTable->manageDerivedMultiEntityCategory();
                                ddlGenBuildInfo->getDdlGenMsg().stopTimer();
                            }
                        }

                        DBA_UpdCrossLinkAttr();
                    }
                }

                for (auto it = genDdlTab.begin(); it != genDdlTab.end(); ++it)
                {
                    DdlGenBuildInfo* ddlGenBuildInfo = *it;

                    if (ddlGenBuildInfo->ddlGenFullTable == nullptr ||
                        ddlGenBuildInfo->retCode == RET_GEN_INFO_NOACTION)
                        continue;

                    if (GET_ENUM(ddlGenBuildInfo->getShXdEntityStp(), S_XdEntity_XdActionEn) == XdAction_ToInsert &&
                        RET_GET_LEVEL(ddlGenBuildInfo->retCode) != RET_LEV_ERROR)
                    {
                        ddlGenBuildInfo->getDdlGenMsg().startTimer();
                        ddlGenBuildInfo->retCode = ddlGenBuildInfo->ddlGenFullTable->updateCrossProgN();
                        ddlGenBuildInfo->getDdlGenMsg().stopTimer();
                    }
                }

                for (auto &ddlObjNatToDoIt : ddlObjNatToDoVector)
                {
                    ddlGenAction.m_ddlObjNatEn = ddlObjNatToDoIt;

                    ret = DBA_BuildAllDdlObject(ddlGenAction,
                                                ddlGenContext,
                                                xdEntityIdxMap,
                                                genDdlTab,
                                                mp);

                    if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
                    {
                        bNoError = false;
                        break;
                    }
                }


                if (bNoError)
                {
                    /* Refresh memory meta-dictionary informations */
                    for (auto it = genDdlTab.begin(); it != genDdlTab.end(); ++it)
                    {
                        DdlGenBuildInfo* ddlGenBuildInfo = *it;

                        if (ddlGenBuildInfo->ddlGenFullTable == nullptr ||
                            ddlGenBuildInfo->retCode == RET_GEN_INFO_NOACTION ||
                            GET_ENUM(ddlGenBuildInfo->getShXdEntityStp(), S_XdEntity_XdActionEn) != XdAction_ToInsert ||
                            RET_GET_LEVEL(ddlGenBuildInfo->retCode) == RET_LEV_ERROR)
                        {
                            continue;
                        }

                        ddlGenBuildInfo->getDdlGenMsg().printMsg(RET_SRV_INFO_RUNNING, "Refreshing memory...");
                        DBA_UpdDictCriteria(ddlGenBuildInfo->ddlGenFullTable->getObjectEn(), false);
                        if (DBA_CreateDynStDef(ddlGenBuildInfo->ddlGenFullTable->getObjectEn(), ddlGenAction.m_fromImport) == RET_SUCCEED)
                        {
                            DBA_GenerateAllAttrib(ddlGenBuildInfo->ddlGenFullTable->getObjectEn());
                        }
                        ddlGenBuildInfo->getDdlGenMsg().printMsg(RET_SUCCEED, "Done");
                    }
                    DBA_UpdCrossLinkAttr();
                    DBA_InitProcLstPtr(InvalidEntity);

                    for (auto it = genDdlTab.begin(); it != genDdlTab.end(); ++it)
                    {
                        DdlGenBuildInfo* ddlGenBuildInfo = *it;

                        if (ddlGenBuildInfo->ddlGenFullTable == nullptr ||
                            ddlGenBuildInfo->retCode == RET_GEN_INFO_NOACTION ||
                            GET_ENUM(ddlGenBuildInfo->getShXdEntityStp(), S_XdEntity_XdActionEn) != XdAction_ToInsert ||
                            RET_GET_LEVEL(ddlGenBuildInfo->retCode) == RET_LEV_ERROR)
                        {
                            continue;
                        }

                        ddlGenBuildInfo->getDdlGenMsg().startTimer();
                        DBA_UpdCrossLinkAttr(ddlGenBuildInfo->ddlGenFullTable->getObjectEn());
                        ddlGenBuildInfo->getDdlGenMsg().stopTimer();
                    }

                    for (auto it = genDdlTab.begin(); it != genDdlTab.end(); ++it)
                    {
                        DdlGenBuildInfo* ddlGenBuildInfo = *it;

                        if (ddlGenBuildInfo->ddlGenFullTable == nullptr ||
                            ddlGenBuildInfo->retCode == RET_GEN_INFO_NOACTION)
                            continue;

                        if (GET_ENUM(ddlGenBuildInfo->getShXdEntityStp(), S_XdEntity_XdActionEn) == XdAction_ToInsert &&
                            RET_GET_LEVEL(ddlGenBuildInfo->retCode) != RET_LEV_ERROR)
                        {
                            ddlGenBuildInfo->getDdlGenMsg().startTimer();
                            ddlGenBuildInfo->retCode = ddlGenBuildInfo->ddlGenFullTable->checkMetaDict();
                            ddlGenBuildInfo->getDdlGenMsg().stopTimer();
                        }
                    }
                }

                if (ddlGenAction.m_fromImport)
                {
                    ret = DDL_ManageLabels(ddlGenContext,
                                           mp,
                                           mainDdlObjNatEn,
                                           xdEntityIdxMap,
                                           genDdlTab);
                    if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
                    {
                        bNoError = false;
                    }
                }

                for (auto it = genDdlTab.begin(); it != genDdlTab.end(); ++it)
                {
                    DdlGenBuildInfo* ddlGenBuildInfo = *it;

                    if (ddlGenBuildInfo->ddlGenFullTable == nullptr ||
                        ddlGenBuildInfo->retCode == RET_GEN_INFO_NOACTION)
                        continue;

                    if (RET_GET_LEVEL(ddlGenBuildInfo->retCode) == RET_LEV_ERROR)
                    {
                        bNoError = false;

                        ret = ddlGenBuildInfo->retCode;

                        ddlGenBuildInfo->getDdlGenMsg().printMsg(ddlGenBuildInfo->retCode, "Applying meta-dictionary modifications on table failed (see $AAAHOME/msg/log file)");
                    }
                }

                bool bDataModelChange = true;

                if (ddlGenAction.m_bInitEntityOnly == false)
                {
                    if (bNoError)
                    {
                        /* PMSTA-19243 - DDV - 150417 - Build Questionnaire's label when questionnaire mode is used (-Gq) */
                        if (mainDdlObjNatEn == DbObjDdlObjNat_Questionnaire ||
                            (mainDdlObjNatEn == DbObjDdlObjNat_AllTable && ddlGenAction.m_bSingleEntity && ddlGenAction.m_entitySqlnameStr.empty() == false))    /* PMSTA-43367 - LJE - 210421 */
                        {
                            AAAValueGuardBool fromImport(ddlGenAction.m_fromImport);
                            ddlGenAction.m_fromImport = true;

                            for (auto it = genDdlTab.begin(); it != genDdlTab.end(); ++it)
                            {
                                DdlGenBuildInfo* ddlGenBuildInfo = *it;

                                if (ddlGenBuildInfo->ddlGenFullTable == nullptr ||
                                    ddlGenBuildInfo->retCode == RET_GEN_INFO_NOACTION)
                                    continue;

                                if (GET_ENUM(ddlGenBuildInfo->getShXdEntityStp(), S_XdEntity_XdActionEn) == XdAction_ToInsert &&
                                    RET_GET_LEVEL(ddlGenBuildInfo->retCode) != RET_LEV_ERROR &&
                                    GET_ENUM(ddlGenBuildInfo->getShXdEntityStp(), S_XdEntity_NatEn) == EntityNat_Questionnaire)
                                {
                                    ddlGenBuildInfo->getDdlGenMsg().startTimer();
                                    ddlGenBuildInfo->retCode = ddlGenBuildInfo->ddlGenFullTable->buildCommentsInMetaDict();
                                    ddlGenBuildInfo->getDdlGenMsg().stopTimer();
                                }
                            }

                            for (auto it = genDdlTab.begin(); it != genDdlTab.end(); ++it)
                            {
                                DdlGenBuildInfo* ddlGenBuildInfo = *it;

                                if (ddlGenBuildInfo->ddlGenFullTable == nullptr ||
                                    ddlGenBuildInfo->retCode == RET_GEN_INFO_NOACTION)
                                    continue;

                                if (GET_ENUM(ddlGenBuildInfo->getShXdEntityStp(), S_XdEntity_XdActionEn) == XdAction_ToInsert &&
                                    RET_GET_LEVEL(ddlGenBuildInfo->retCode) != RET_LEV_ERROR &&
                                    GET_ENUM(ddlGenBuildInfo->getShXdEntityStp(), S_XdEntity_NatEn) == EntityNat_Questionnaire)
                                {
                                    ddlGenBuildInfo->getDdlGenMsg().startTimer();
                                    ddlGenBuildInfo->retCode = ddlGenBuildInfo->ddlGenFullTable->questionnairePostUpdate();
                                    ddlGenBuildInfo->getDdlGenMsg().stopTimer();
                                }
                            }
                        }

                        ddlGenAction.m_ddlObjNatEn = DbObjDdlObjNat_SetEntityStatus;

                        ret = DBA_BuildAllDdlObject(ddlGenAction,
                                                    ddlGenContext,
                                                    xdEntityIdxMap,
                                                    genDdlTab,
                                                    mp);

                        if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
                        {
                            bNoError = false;
                        }

                        if (ddlGenAction.m_fromImport)
                        {
                            DdlGenDbaAccessGuard ddlGenDbaAccessGuard(ddlGenContext);

                            bDataModelChange = ddlGenDbaAccessGuard.getDdlGenDbaAccess().isDataModelChanged();

                            if (bDataModelChange)
                            {
                                ret = ddlGenDbaAccessGuard.getDdlGenDbaAccess().flushData();

                                if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
                                {
                                    bDataModelChange = false;
                                    bNoError         = false;
                                }
                            }
                        }

                        if (bDataModelChange)
                        {
                            ddlGenAction.m_ddlObjNatEn = DbObjDdlObjNat_BuildTableInDb;

                            ret = DBA_BuildAllDdlObject(ddlGenAction,
                                                        ddlGenContext,
                                                        xdEntityIdxMap,
                                                        genDdlTab,
                                                        mp);

                            if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
                            {
                                bNoError = false;
                            }

                            if ((mainDdlObjNatEn == DbObjDdlObjNat_AllTable || mainDdlObjNatEn == DbObjDdlObjNat_System) &&
                                ddlGenContext.optimLevelEn == DdlGenContext::OptimLevel::Full)
                            {
                                DdlGenAction procDdlGenAction(ddlGenAction, true);

                                procDdlGenAction.m_mainDdlObjNatEn = mainDdlObjNatEn;
                                procDdlGenAction.m_ddlObjNatEn = DbObjDdlObjNat_StoredProc;
                                procDdlGenAction.m_execModeEn = DbObjExecMod_DBBuildWFiles;
                                procDdlGenAction.m_subRequest = true;

                                procDdlGenAction.m_entitySqlnameStr = "xd_index";
                                DDL_BuildDdlObject(ddlGenContext, procDdlGenAction);
                            }

                            ddlGenAction.m_ddlObjNatEn = DbObjDdlObjNat_BuildIndexInDb;

                            ret = DBA_BuildAllDdlObject(ddlGenAction,
                                                        ddlGenContext,
                                                        xdEntityIdxMap,
                                                        genDdlTab,
                                                        mp);

                            if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
                            {
                                bNoError = false;
                            }

                            ddlGenAction.m_ddlObjNatEn = DbObjDdlObjNat_BuildPrimaryKey;

                            ret = DBA_BuildAllDdlObject(ddlGenAction,
                                                        ddlGenContext,
                                                        xdEntityIdxMap,
                                                        genDdlTab,
                                                        mp);

                            if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
                            {
                                bNoError = false;
                            }

                            if (mainDdlObjNatEn == DbObjDdlObjNat_AllTable &&
                                (ddlGenContext.optimLevelEn == DdlGenContext::OptimLevel::None || ddlGenContext.m_bDatAll) &&
                                ddlGenAction.m_bSingleEntity == false)
                            {
                                if (ddlGenContext.ddlGenAction.m_bUseNativeQuery == false)
                                {
                                    DdlGenAction procDdlGenAction(ddlGenAction, true);

                                    procDdlGenAction.m_mainDdlObjNatEn = DbObjDdlObjNat_System;
                                    procDdlGenAction.m_execModeEn = DbObjExecMod_DBBuildWFiles;
                                    procDdlGenAction.m_subRequest = true;
                                    procDdlGenAction.m_installLevel = 6;

                                    std::vector<std::string> entityToDoVector;
                                    entityToDoVector.push_back("dict_err_msg");
                                    entityToDoVector.push_back("dict_user");
                                    entityToDoVector.push_back("dict_entity");
                                    entityToDoVector.push_back("xd_entity");
                                    entityToDoVector.push_back("dict_attribute");
                                    entityToDoVector.push_back("xd_attribute");
                                    entityToDoVector.push_back("xd_attribute_custo");
                                    entityToDoVector.push_back("xd_entity_feature");
                                    entityToDoVector.push_back("xd_perm_value");
                                    entityToDoVector.push_back("xd_index");
                                    entityToDoVector.push_back("xd_index_attrib");
                                    entityToDoVector.push_back("dict_perm_value");
                                    entityToDoVector.push_back("dict_criteria");
                                    entityToDoVector.push_back("dict_database");
                                    entityToDoVector.push_back("dict_segment");
                                    entityToDoVector.push_back("script_definition");
                                    entityToDoVector.push_back("xd_label");
                                    entityToDoVector.push_back("dict_label");
                                    entityToDoVector.push_back("table_modif_stat");

                                    procDdlGenAction.m_ddlObjNatEn = DbObjDdlObjNat_SpecialStoredProc;
                                    for (auto it = entityToDoVector.begin(); it != entityToDoVector.end(); ++it)
                                    {
                                        procDdlGenAction.m_entitySqlnameStr = (*it);
                                        DDL_BuildDdlObject(ddlGenContext, procDdlGenAction);
                                    }

                                    procDdlGenAction.m_ddlObjNatEn = DbObjDdlObjNat_StoredProc;
                                    for (auto it = entityToDoVector.begin(); it != entityToDoVector.end(); ++it)
                                    {
                                        procDdlGenAction.m_entitySqlnameStr = (*it);
                                        DDL_BuildDdlObject(ddlGenContext, procDdlGenAction);
                                    }

                                    procDdlGenAction.m_ddlObjNatEn = DbObjDdlObjNat_Trigger;
                                    for (auto it = entityToDoVector.begin(); it != entityToDoVector.end(); ++it)
                                    {
                                        procDdlGenAction.m_entitySqlnameStr = (*it);
                                        DDL_BuildDdlObject(ddlGenContext, procDdlGenAction);
                                    }
                                }

                                DdlGenDbaAccessGuard ddlGenDbaAccessGuard(ddlGenContext);
                                ret = ddlGenDbaAccessGuard.getDdlGenDbaAccess().flushData();

                                if (ddlGenContext.m_bIsInstallFromScratch == false)
                                {
                                    DbiConnectionHelper         dbiConnHelper(&ddlGenConnGuard.getDbiConn());
                                    dbiConnHelper.dbaNotif(DictSproc, UNUSED, nullptr);
                                }
                            }

                            if (mainDdlObjNatEn != DbObjDdlObjNat_TslExtension)
                            {
                                ddlGenAction.m_ddlObjNatEn = DbObjDdlObjNat_BuildForeignKey;

                                ret = DBA_BuildAllDdlObject(ddlGenAction,
                                                            ddlGenContext,
                                                            xdEntityIdxMap,
                                                            genDdlTab,
                                                            mp);

                                if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
                                {
                                    bNoError = false;
                                }
                            }

                            {
                                /* Build system stored procedure, system view and foreign keys for before migration */
                                ddlGenAction.m_bSystemFuncOnly = true;
                                for (auto it = genDdlTab.begin(); it != genDdlTab.end(); ++it)
                                {
                                    DdlGenBuildInfo* ddlGenBuildInfo = *it;

                                    if (ddlGenBuildInfo->ddlGenFullTable == nullptr ||
                                        ddlGenBuildInfo->retCode == RET_GEN_INFO_NOACTION)
                                        continue;

                                    if (GET_ENUM(ddlGenBuildInfo->getShXdEntityStp(), S_XdEntity_XdActionEn) == XdAction_ToInsert &&
                                        RET_GET_LEVEL(ddlGenBuildInfo->retCode) != RET_LEV_ERROR)
                                    {
                                        DICT_ENTITY_STP currDictEntityStp = DBA_GetDictEntitySt(ddlGenBuildInfo->ddlGenFullTable->getObjectEn());

                                        if (currDictEntityStp != nullptr &&
                                            currDictEntityStp->bIsInitEntity == true)
                                        {
                                            ddlGenBuildInfo->getDdlGenMsg().startTimer();
                                            ddlGenBuildInfo->ddlGenFullTable->getDdlGenAction().m_bSystemFuncOnly = ddlGenAction.m_bSystemFuncOnly;
                                            ddlGenBuildInfo->retCode = ddlGenBuildInfo->ddlGenFullTable->buildStoredProceduresInDB();
                                            ddlGenBuildInfo->getDdlGenMsg().stopTimer();
                                        }
                                    }
                                }
                                ddlGenAction.m_bSystemFuncOnly = false;

                                ddlGenAction.m_ddlObjNatEn = DbObjDdlObjNat_SystemView;

                                ret = DBA_BuildAllDdlObject(ddlGenAction,
                                                            ddlGenContext,
                                                            xdEntityIdxMap,
                                                            genDdlTab,
                                                            mp);

                                if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
                                {
                                    bNoError = false;
                                }

                                ddlGenAction.m_ddlObjNatEn = DbObjDdlObjNat_UtilsView;

                                ret = DBA_BuildAllDdlObject(ddlGenAction,
                                                            ddlGenContext,
                                                            xdEntityIdxMap,
                                                            genDdlTab,
                                                            mp);

                                if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
                                {
                                    bNoError = false;
                                }

                                if (mainDdlObjNatEn != DbObjDdlObjNat_TslExtension)
                                {
                                    /* PMSTA-32145 - LJE - 180730 */
                                    do
                                    {
                                        ddlGenContext.upgDoneCpt = 0;
                                        ddlGenContext.upgToDoCpt = 0;

                                        for (auto it = genDdlTab.begin(); it != genDdlTab.end(); ++it)
                                        {
                                            DdlGenBuildInfo* ddlGenBuildInfo = *it;

                                            if (ddlGenBuildInfo->ddlGenFullTable == nullptr ||
                                                ddlGenBuildInfo->retCode == RET_GEN_INFO_NOACTION)
                                                continue;

                                            if (GET_ENUM(ddlGenBuildInfo->getShXdEntityStp(), S_XdEntity_XdActionEn) == XdAction_ToInsert &&
                                                RET_GET_LEVEL(ddlGenBuildInfo->retCode) != RET_LEV_ERROR)
                                            {
                                                ddlGenBuildInfo->getDdlGenMsg().setDdlObjEn(DdlObj_Table);
                                                ddlGenBuildInfo->getDdlGenMsg().setMsgObjType("Migration");
                                                ddlGenBuildInfo->getDdlGenMsg().startTimer();
                                                ddlGenBuildInfo->retCode = ddlGenBuildInfo->ddlGenFullTable->manageMigration(DdlGenFullTable::MigrationStep::MultiEntityFirst);
                                                ddlGenBuildInfo->getDdlGenMsg().stopTimer();
                                            }
                                        }
                                    } while (ddlGenContext.upgDoneCpt != 0 && ddlGenContext.upgToDoCpt != 0);

                                    for (auto it = genDdlTab.begin(); it != genDdlTab.end(); ++it)
                                    {
                                        DdlGenBuildInfo* ddlGenBuildInfo = *it;

                                        if (ddlGenBuildInfo->ddlGenFullTable == nullptr ||
                                            ddlGenBuildInfo->retCode == RET_GEN_INFO_NOACTION)
                                            continue;

                                        if (GET_ENUM(ddlGenBuildInfo->getShXdEntityStp(), S_XdEntity_XdActionEn) == XdAction_ToInsert &&
                                            RET_GET_LEVEL(ddlGenBuildInfo->retCode) != RET_LEV_ERROR)
                                        {
                                            ddlGenBuildInfo->getDdlGenMsg().setDdlObjEn(DdlObj_Table);
                                            ddlGenBuildInfo->getDdlGenMsg().setMsgObjType("Migration");
                                            ddlGenBuildInfo->getDdlGenMsg().startTimer();
                                            ddlGenBuildInfo->retCode = ddlGenBuildInfo->ddlGenFullTable->manageMigration(DdlGenFullTable::MigrationStep::MultiEntitySecond);
                                            ddlGenBuildInfo->getDdlGenMsg().stopTimer();
                                        }
                                    }
                                }

                                if (mainDdlObjNatEn != DbObjDdlObjNat_ReportFmt &&
                                    mainDdlObjNatEn != DbObjDdlObjNat_System)
                                {
                                    ddlGenAction.m_ddlObjNatEn = DbObjDdlObjNat_VerticalSearchPattern;

                                    ret = DBA_BuildAllDdlObject(ddlGenAction,
                                                                ddlGenContext,
                                                                xdEntityIdxMap,
                                                                genDdlTab,
                                                                mp);

                                    if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
                                    {
                                        bNoError = false;
                                    }
                                }

                                ddlGenAction.m_ddlObjNatEn = DbObjDdlObjNat_SpecialStoredProc;

                                ret = DBA_BuildAllDdlObject(ddlGenAction,
                                                            ddlGenContext,
                                                            xdEntityIdxMap,
                                                            genDdlTab,
                                                            mp);

                                if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
                                {
                                    bNoError = false;
                                }

                                if (mainDdlObjNatEn != DbObjDdlObjNat_System)
                                {
                                    DBA_InitCreateTempTables();
                                }

                                ddlGenAction.m_ddlObjNatEn = DbObjDdlObjNat_StoredProc;

                                ret = DBA_BuildAllDdlObject(ddlGenAction,
                                                            ddlGenContext,
                                                            xdEntityIdxMap,
                                                            genDdlTab,
                                                            mp);

                                if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
                                {
                                    bNoError = false;
                                }

                                if (ddlGenContext.depEntityPscSqlNameSet.empty() == false)
                                {
                                    std::set<std::string> depEntityPscSqlNameSet = ddlGenContext.depEntityPscSqlNameSet;

                                    for (auto & ddlGenBuildInfo : genDdlTab)
                                    {
                                        depEntityPscSqlNameSet.erase(ddlGenBuildInfo->getMdSqlName());
                                    }

                                    for (auto &it : depEntityPscSqlNameSet)
                                    {
                                        DdlGenAction procDdlGenAction;

                                        procDdlGenAction.m_mainDdlObjNatEn  = mainDdlObjNatEn;
                                        procDdlGenAction.m_ddlObjNatEn      = DbObjDdlObjNat_StoredProc;
                                        procDdlGenAction.m_execModeEn       = DbObjExecMod_DBBuildWFiles;
                                        procDdlGenAction.m_subRequest       = true;
                                        procDdlGenAction.m_installLevel     = ddlGenAction.m_installLevel;
                                        procDdlGenAction.m_entitySqlnameStr = it;

                                        DDL_BuildDdlObject(ddlGenContext, procDdlGenAction);
                                    }
                                }

                                if (mainDdlObjNatEn != DbObjDdlObjNat_TslExtension)
                                {
                                    ddlGenAction.m_ddlObjNatEn = DbObjDdlObjNat_Trigger;

                                    ret = DBA_BuildAllDdlObject(ddlGenAction,
                                                                ddlGenContext,
                                                                xdEntityIdxMap,
                                                                genDdlTab,
                                                                mp);
                                }
                            }

                            if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
                            {
                                DdlGenDbaAccessGuard ddlGenDbaAccessGuard(ddlGenContext);
                                DbiConnectionHelper dbiConnHelper(&ddlGenConnGuard.getDbiConn(), false);
                                ddlGenDbaAccessGuard.getDdlGenDbaAccess().load("dict_entity_constraints", dbiConnHelper);

                                ddlGenAction.m_ddlObjNatEn = DbObjDdlObjNat_References;

                                ret = DBA_BuildAllDdlObject(ddlGenAction,
                                                            ddlGenContext,
                                                            xdEntityIdxMap,
                                                            genDdlTab,
                                                            mp);
                            }

                            if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
                            {
                                bNoError = false;
                            }
                            else if (mainDdlObjNatEn != DbObjDdlObjNat_TslExtension)
                            {
                                if (ddlGenAction.m_bSingleEntity == false)
                                {
                                    ret = ddlGenContext.saveDependenciesInDB();
                                }

                                /* PMSTA-26108 - LJE - 171002 */
                                if (bNoError)
                                {
                                    ddlGenAction.m_ddlObjNatEn = DbObjDdlObjNat_References;

                                    ret = DBA_BuildAllDdlObject(ddlGenAction,
                                                                ddlGenContext,
                                                                xdEntityIdxMap,
                                                                genDdlTab,
                                                                mp);
                                }
                            }
                        }

                        if (ddlGenAction.m_fromImport == false)
                        {
                            ret = DDL_ManageLabels(ddlGenContext,
                                                   mp,
                                                   mainDdlObjNatEn,
                                                   xdEntityIdxMap,
                                                   genDdlTab);
                            if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
                            {
                                bNoError = false;
                            }
                        }

                    }

                    for (auto it = genDdlTab.begin(); it != genDdlTab.end(); ++it)
                    {
                        DdlGenBuildInfo* ddlGenBuildInfo = *it;

                        if (ddlGenBuildInfo->ddlGenFullTable == nullptr)
                            continue;

                        ddlGenBuildInfo->getDdlGenMsg().setMsgObjType("Creating ddl objects");
                        ddlGenBuildInfo->getDdlGenMsg().startTimer();

                        if (GET_ENUM(ddlGenBuildInfo->getShXdEntityStp(), S_XdEntity_XdActionEn) != XdAction_None ||
                            ddlGenBuildInfo->retCode == RET_GEN_INFO_NOACTION)
                        {
                            if (RET_GET_LEVEL(ddlGenBuildInfo->retCode) != RET_LEV_ERROR)
                            {
                                ddlGenBuildInfo->getDdlGenMsg().printMsg(RET_DBA_INFO_NO_MORE_DATA, "Applying modifications on table successful");
                            }
                            else
                            {
                                ret = ddlGenBuildInfo->retCode;
                                ddlGenBuildInfo->getDdlGenMsg().printMsg(RET_DBA_ERR_MD_INVALID_VALUE, "Applying modifications on table failed (see $AAAHOME/msg/log file)");
                            }
                        }
                        else
                        {
                            ddlGenBuildInfo->getDdlGenMsg().printMsg(ddlGenBuildInfo->retCode, "No action done on table successful");
                        }
                    }

                    for (auto & ddlGenBuildInfo : genDdlTab)
                    {
                        if (ddlGenBuildInfo->ddlGenFullTable == nullptr)
                        {
                            delete (ddlGenBuildInfo->ddlGenFullTable);
                        }
                    }

                    shXdEntityVector.clear();

                    if (mainDdlObjNatEn == DbObjDdlObjNat_UserTableDS ||
                        mainDdlObjNatEn == DbObjDdlObjNat_AllTable ||
                        mainDdlObjNatEn == DbObjDdlObjNat_TslExtension)
                    {
                        DBA_DYNFLD_STP* dictEntityTab = NULL;
                        int             dictEntityNbr = 0;

                        SET_ENUM(admArgStp, Adm_Arg_NatEn, EntityNat_CustomDS);

                        /* Free all unused custom DS entities */
                        DBA_Select2(DictEntity,
                                    UNUSED,
                                    Adm_Arg,
                                    admArgStp,
                                    A_DictEntity,
                                    &dictEntityTab,
                                    UNUSED,
                                    UNUSED,
                                    &dictEntityNbr,
                                    ddlGenConnGuard.getDbiConn());

                        for (int i = 0; i < dictEntityNbr; i++)
                        {
                            if (GET_ENUM(dictEntityTab[i], A_DictEntity_XdStatusEn) == XdStatus_Deleted)
                            {
                                if (DBA_Delete2(DictEntity,
                                                UNUSED,
                                                A_DictEntity,
                                                dictEntityTab[i],
                                                UNUSED,
                                                ddlGenConnGuard.getDbiConn()) != RET_SUCCEED)
                                {
                                    MSG_SendMesg(RET_DBA_ERR_DELETE_FAILED, 0, FILEINFO);
                                }

                                stdMsg.setMsgSqlName(GET_SYSNAME(dictEntityTab[i], A_DictEntity_SqlName));
                                stdMsg.printMsg(RET_SRV_INFO_RUNNING, "Deleted");
                            }
                        }

                        DBA_FreeDynStTab(dictEntityTab, dictEntityNbr, A_DictEntity);
                    }
                }
                else
                {
                    if (ddlGenContext.ddlGenAction.m_bUseNativeQuery == false)
                    {
                        DdlGenAction procDdlGenAction(ddlGenAction, true);

                        procDdlGenAction.m_mainDdlObjNatEn = DbObjDdlObjNat_System;
                        procDdlGenAction.m_execModeEn = DbObjExecMod_DBBuildWFiles;
                        procDdlGenAction.m_subRequest = true;

                        std::vector<std::string> entityToDoVector;
                        entityToDoVector.push_back("xd_attribute");
                        entityToDoVector.push_back("xd_attribute_custo");
                        entityToDoVector.push_back("xd_entity_feature");
                        entityToDoVector.push_back("xd_perm_value");
                        entityToDoVector.push_back("xd_index");
                        entityToDoVector.push_back("xd_index_attrib");
                        entityToDoVector.push_back("xd_label");
                        entityToDoVector.push_back("dict_perm_value");
                        entityToDoVector.push_back("dict_criteria");
                        entityToDoVector.push_back("dict_database");
                        entityToDoVector.push_back("dict_segment");
                        entityToDoVector.push_back("dict_user");
                        entityToDoVector.push_back("script_definition");

                        procDdlGenAction.m_ddlObjNatEn = DbObjDdlObjNat_StoredProc;
                        for (auto it = entityToDoVector.begin(); it != entityToDoVector.end(); ++it)
                        {
                            procDdlGenAction.m_entitySqlnameStr = (*it);
                            DDL_BuildDdlObject(ddlGenContext, procDdlGenAction);
                        }
                    }

                    ddlGenAction.m_ddlObjNatEn = DbObjDdlObjNat_SetEntityStatus;

                    ret = DBA_BuildAllDdlObject(ddlGenAction,
                                                ddlGenContext,
                                                xdEntityIdxMap,
                                                genDdlTab,
                                                mp);
                }

                if (RET_GET_LEVEL(ret) != RET_LEV_ERROR || 
                    ddlGenContext.m_bDatAll ||
                    ddlGenContext.m_bIsInstallFromScratch)
                {
                    if (mainDdlObjNatEn == DbObjDdlObjNat_AllTable &&
                        ddlGenAction.m_bSingleEntity == false &&
                        ddlGenContext.m_bIsInstallFromScratch == false)
                    {
                        DdlGenDbaAccessGuard ddlGenDbaAccessGuard(ddlGenContext);
                        ddlGenDbaAccessGuard.getDdlGenDbaAccess().cleanUpMetaDict();
                    }

                    std::map<DDL_OBJ_ENUM, std::map<DDL_CMD_TYPE_ENUM, size_t>> ddlObjstatMap;

                    for (auto &genDdlIt : genDdlTab)
                    {
                        for (auto &ddlObjStatIt : genDdlIt->m_ddlGenContextPtr->m_ddlObjStatMap)
                        {
                            if (ddlObjStatIt.first != DDlCmdType_Exec)
                            {
                                for (auto &it : ddlObjStatIt.second)
                                {
                                    ddlObjstatMap[ddlObjStatIt.first][it.first] += it.second;
                                }
                            }
                        }
                    }

                    if (ddlGenAction.isPrintSummary())
                    {
                        stdMsg.setDdlObjEn(DdlObj_Sql);
                        stdMsg.setMsgObjType("Summary");
                        stdMsg.printMsg(RET_DBA_INFO_MD, "");

                        if (ddlObjstatMap.empty())
                        {
                            stdMsg.printMsg(RET_DBA_INFO_MD, "No DDL object modified");
                        }
                        else
                        {
                            for (auto &ddlObjStatIt : ddlObjstatMap)
                            {
                                for (auto &actionIt : ddlObjStatIt.second)
                                {
                                    std::stringstream msgStream;
                                    std::string actionStr;
                                    switch (actionIt.first)
                                    {
                                        case DDlCmdType_None:
                                            actionStr = "None";
                                            break;

                                        case DDlCmdType_Create:
                                            actionStr = "Create";
                                            break;

                                        case DDlCmdType_Drop:
                                            actionStr = "Drop";
                                            break;

                                        case DDlCmdType_DropAll:
                                            actionStr = "DropAll";
                                            break;

                                        case DDlCmdType_Grant:
                                            actionStr = "Grant";
                                            break;

                                        case DDlCmdType_CleanUpView:
                                            actionStr = "CleanUpView";
                                            break;

                                        case DDlCmdType_Init:
                                            actionStr = "Init";
                                            break;

                                        case DDlCmdType_Exec:
                                            actionStr = "Exec";
                                            break;

                                        case DDlCmdType_DbProcess:
                                            actionStr = "DbProcess";
                                            break;

                                        case DDlCmdType_DML:
                                            actionStr = "DML";
                                            break;

                                        case DDlCmdType_AlterTable:
                                            actionStr = "AlterTable";
                                            break;

                                        case DDlCmdType_AlterColumn:
                                            actionStr = "AlterColumn";
                                            break;
                                    }

                                    msgStream
                                        << std::left << std::setw(46) << DdlGenMsg::getDdlObjEnStr(ddlObjStatIt.first)
                                        << " - action: " << std::left << std::setw(20) << actionStr
                                        << " - count: " << actionIt.second;

                                    stdMsg.printMsg(RET_DBA_INFO_MD, msgStream.str());
                                }
                            }
                        }
                        stdMsg.printMsg(RET_DBA_INFO_MD, "");
                    }

                    if (RET_GET_LEVEL(ret) != RET_LEV_ERROR &&
                        bNoError &&
                        ddlGenAction.m_fromImport == false)
                    {
                        DdlGenDbaAccessGuard ddlGenDbaAccessGuard(ddlGenContext);
                        ret = ddlGenDbaAccessGuard.getDdlGenDbaAccess().flushData();
                    }
                }

                if (ddlGenAction.m_bInitEntityOnly == false &&
                    bDataModelChange &&
                    ddlGenContext.bSimulation == false &&
                    mainDdlObjNatEn == DbObjDdlObjNat_AllTable &&
                    ddlGenAction.m_bSingleEntity == false)
                {
                    auto dictVersionStp = mp.allocDynst(FILEINFO, A_DictVersion);
                    SET_DATETIME(dictVersionStp, A_DictVersion_BuildDate, ddlGenContext.getBuildDate());
                    SET_A_DictVersion_XdStatusEn(dictVersionStp, (RET_GET_LEVEL(ret) != RET_LEV_ERROR && bNoError ? XdEntityXdStatusEn::Inserted : XdEntityXdStatusEn::Failed));
                    SET_SYSNAME(dictVersionStp, A_DictVersion_Version, AAAVersion::getVersion().getVersionCode().c_str());
                    SET_SYSNAME(dictVersionStp, A_DictVersion_FullVersion, AAAVersion::getVersion().getfullVersionInfo().c_str());

                    DbiConnectionHelper dbiConnHelper(&ddlGenConnGuard.getDbiConn());
                    dbiConnHelper.dbaInsert(DictVersion, UNUSED, dictVersionStp);
                }

                if (RET_GET_LEVEL(ret) != RET_LEV_ERROR &&
                    bNoError &&
                    ddlGenAction.m_bInitEntityOnly == false &&
                    ddlGenContext.bSimulation      == false &&
                    mainDdlObjNatEn                == DbObjDdlObjNat_AllTable &&
                    ddlGenAction.m_bSingleEntity   == false)
                {
                    std::stringstream        updApplParam;
                    DBI_INT                  status;
                    std::string              version = AAAVersion::getVersion().getVersionCode();  /* CMT-12245-FME-190430 Git Version Management*/

                    ddlGenConnGuard.getDbiConn().beginTransaction();

                    stdMsg.setDdlObjEn(DdlObj_Sql);
                    stdMsg.setMsgObjType("aaa_version");
                    stdMsg.setMsgSqlName("appl_param");
                    stdMsg.startTimer();

                    updApplParam << "update appl_param set value_n = '" << version << "' where param_name = 'AAA_VERSION'";

                    const AAALogger& sqlTraceLog = AAALogger::get(AAALogger::Logger::SqlTrace);
                    if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
                    {
                        auto& sqlTrace = ddlGenConnGuard.getDbiConn().getSqlTrace();
                        sqlTrace.m_procedure = "DynSql.ServBuildTable";
                    }

                    ret = ddlGenConnGuard.getDbiConn().sqlExecSt(updApplParam.str().c_str(), &status);
                    if (ret != RET_SUCCEED)
                    {
                        ddlGenConnGuard.getDbiConn().sendAllMsg();
                    }
                    stdMsg.printMsg(RET_SUCCEED, "Updating application parameter AAA_VERSION with the following value: " + version);

                    std::string currMasterCd;
                    if (ddlGenContext.getMultiEntityLevel() == MultiEntityLevel_Active)
                    {
                        currMasterCd = ddlGenContext.getMasterBusinessEntityCd();
                    }
                    updApplParam.clear();
                    updApplParam.str(std::string());

                    stdMsg.startTimer();
                    if (currMasterCd.empty())
                    {
                        updApplParam << "update appl_param set value_n = null where param_name = 'MASTER_BUSINESS_ENTITY'";
                    }
                    else
                    {
                        updApplParam << "update appl_param set value_n = '" << currMasterCd << "' where param_name = 'MASTER_BUSINESS_ENTITY'";
                    }

                    if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
                    {
                        auto& sqlTrace = ddlGenConnGuard.getDbiConn().getSqlTrace();
                        sqlTrace.m_procedure = "DynSql.ServBuildTable";
                    }

                    ret = ddlGenConnGuard.getDbiConn().sqlExecSt(updApplParam.str().c_str(), &status);
                    if (ret != RET_SUCCEED)
                    {
                        ddlGenConnGuard.getDbiConn().sendAllMsg();
                    }
                    stdMsg.printMsg(RET_SUCCEED, "Updating application parameter MASTER_BUSINESS_ENTITY with the following value: " + currMasterCd);

                    if (ddlGenContext.m_rdbmsEn == Oracle)
                    {
                        updApplParam.clear();
                        updApplParam.str(std::string());

                        std::string profile;
                        GEN_GetApplInfo(ApplUserOraProfile, profile);
                        if (profile.empty() == false && profile != "DEFAULT")
                        {
                            updApplParam << "update appl_param set value_n = '" << profile << "' where param_name = 'USER_ORACLE_PROFILE' and value_n <> '" << profile << "'";
                            ret = ddlGenConnGuard.getDbiConn().sqlExecSt(updApplParam.str().c_str(), &status);
                            if (ret != RET_SUCCEED)
                            {
                                ddlGenConnGuard.getDbiConn().sendAllMsg();
                            }
                            stdMsg.printMsg(RET_SUCCEED, "Updating application parameter USER_ORACLE_PROFILE with the value: " + profile);
                        }

                        updApplParam.clear();
                        updApplParam.str(std::string());

                        std::string defaultTablespace;
                        GEN_GetApplInfo(ApplUserOraDefTablespace, defaultTablespace);
                        if (defaultTablespace.empty() == false && defaultTablespace != "DEFAULT")
                        {
                            updApplParam << "update appl_param set value_n = '" << defaultTablespace << "' where param_name = 'USER_ORACLE_DEFAULT_TABLESPACE' and value_n <> '" << defaultTablespace << "'";
                            ret = ddlGenConnGuard.getDbiConn().sqlExecSt(updApplParam.str().c_str(), &status);
                            if (ret != RET_SUCCEED)
                            {
                                ddlGenConnGuard.getDbiConn().sendAllMsg();
                            }
                            stdMsg.printMsg(RET_SUCCEED, "Updating application parameter USER_ORACLE_PROFILE with the value: " + defaultTablespace);
                        }
                        updApplParam.clear();
                        updApplParam.str(std::string());

                        std::string temporaryTablespace;
                        GEN_GetApplInfo(ApplUserOraTempTablespace, temporaryTablespace);
                        if (temporaryTablespace.empty() == false && temporaryTablespace != "DEFAULT")
                        {
                            updApplParam << "update appl_param set value_n = '" << temporaryTablespace << "' where param_name = 'USER_ORACLE_TEMP_TABLESPACE' and value_n <> '" << temporaryTablespace << "'";
                            ret = ddlGenConnGuard.getDbiConn().sqlExecSt(updApplParam.str().c_str(), &status);
                            if (ret != RET_SUCCEED)
                            {
                                ddlGenConnGuard.getDbiConn().sendAllMsg();
                            }
                            stdMsg.printMsg(RET_SUCCEED, "Updating application parameter USER_ORACLE_PROFILE with the value: " + temporaryTablespace);
                        }
                    }

                    ddlGenConnGuard.getDbiConn().endTransaction(TRUE);
                }
            }
        }
        else if (ddlGenAction.isPrintSummary())
        {
            stdMsg.setDdlObjEn(DdlObj_Sql);
            stdMsg.setMsgObjType("Summary");
            stdMsg.printMsg(RET_DBA_INFO_MD, "No DDL object modified");
            if (ddlGenAction.m_fromImport == false)
            {
                stdMsg.printMsg(RET_DBA_INFO_MD, "Nothing to write");
            }
            else
            {
                ret = RET_GEN_INFO_NOACTION;
            }
        }

        /* PMSTA-45413 - LJE - 210611 - Active the blocking trigger code */
        if (level == 0 &&
            ddlGenContext.bSimulation == false &&
            ddlGenAction.m_bRestrictUpdate &&
            (mainDdlObjNatEn != DbObjDdlObjNat_AllTable || ddlGenAction.m_bSingleEntity))
        {
            DdlGenAction procDdlGenAction;

            procDdlGenAction.m_ddlObjNatEn = DbObjDdlObjNat_Trigger;
            procDdlGenAction.m_execModeEn = DbObjExecMod_DBBuildWFiles;
            procDdlGenAction.m_entitySqlnameStr = "dict";
            procDdlGenAction.m_subRequest = true;
            procDdlGenAction.m_installLevel = 1;

            DDL_BuildDdlObject(ddlGenContext, procDdlGenAction);
        }

        gblMsg.setMsgObjType(std::string());
        gblMsg.setMsgSqlName(std::string());
        gblMsg.setMsgEntitySqlName(std::string());

        if (level == 0)
        {
            {
                CurrentTime now(CurrentTime::Kind::CurrentUs);    /* Get Date and Time informations */
                gblMsg.printMsg(RET_DBA_INFO_EXIST, SYS_Stringer("End Date : ", now.formatYYYYMMDDSPHMSUS()));
            }

            if (RET_GET_LEVEL(ret) != RET_LEV_ERROR && bNoError)
            {
                gblMsg.printMsg(RET_SUCCEED, "Applying modifications on tables successful");
            }
            else
            {
                if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
                {
                    ret = RET_DBA_ERR_MD;
                }

                std::cerr << " Failed" << std::endl;

                gblMsg.printMsg(ret, "Applying modifications on tables failed (see $AAAHOME/msg/log file or Standard error stream)");
            }

            if (ddlGenAction.m_fromImport == false)
            {
                std::cout << std::endl;
            }
        }
    }

    if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
    {
        /* !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! */
        /* !!!!!! Have a look on the standard output !!!!!! */
        /* !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! */
        SYS_BreakOnDebug();
    }
    return ret;
}

/************************************************************************
**
**  Function    :   DBA_BuildAllDdlObject()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-37366 - LJE - 200323
**  Last modif. :
**
*************************************************************************/
STATIC void DBA_CreateDdlGenBuildInfo(DdlGenContext                 &ddlGenContext,
                                      std::map<std::string, DdlGenBuildInfo*> &xdEntityIdxMap,
                                      std::vector<DdlGenBuildInfo*>      &genDdlTab,
                                      MemoryPool                    &mp,
                                      DICT_ENTITY_STP               dictEntityStp,
                                      TARGET_TABLE_ENUM             targetTableEn = TargetTable_Undefined)
{
    DdlGenContext* ddlGenContextPtr = new DdlGenContext(ddlGenContext);
    ddlGenContextPtr->m_parentContext = &ddlGenContext;

    DdlGenBuildInfo* ddlGenBuildInfo = new DdlGenBuildInfo(ddlGenContextPtr);
    mp.ownerObject(ddlGenBuildInfo);

    DBA_DYNFLD_STP   shXdEntityStp = mp.allocDynst(FILEINFO, S_XdEntity);
    SET_SYSNAME(shXdEntityStp, S_XdEntity_SqlName, dictEntityStp->mdSqlName);
    SET_ENUM(shXdEntityStp, S_XdEntity_XdActionEn, XdAction_ToInsert);
    ddlGenContextPtr->ddlGenAction.m_entitySqlnameStr = dictEntityStp->mdSqlName;

    if (targetTableEn == TargetTable_UserDefinedFields)
    {
        ddlGenContextPtr->ddlGenAction.m_targetSqlnameStr = dictEntityStp->custSqlName;
    }

    ddlGenContextPtr->setMsgObjType(ddlGenContextPtr->ddlGenAction.getDdlObjNatStr());
    ddlGenContextPtr->setMsgEntitySqlName(dictEntityStp->mdSqlName);
    ddlGenBuildInfo->setShXdEntityStp(shXdEntityStp);
    ddlGenBuildInfo->setDictEntityStp(dictEntityStp);
    ddlGenBuildInfo->m_targetTableEn = targetTableEn;

    genDdlTab.push_back(ddlGenBuildInfo);

    DdlGenFullTable* ddlGenFullTable = new DdlGenFullTable(ddlGenContextPtr->ddlGenAction, *ddlGenContextPtr, dictEntityStp);

    ddlGenBuildInfo->ddlGenFullTable = ddlGenFullTable;
    ddlGenBuildInfo->retCode = RET_SUCCEED;

    xdEntityIdxMap.insert(std::make_pair(GET_SYSNAME(shXdEntityStp, S_XdEntity_SqlName), ddlGenBuildInfo));
}

/************************************************************************
**
**  Function    :   DBA_BuildAllDdlObject()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-37366 - LJE - 200323
**  Last modif. :
**
*************************************************************************/
STATIC RET_CODE DBA_BuildAllDdlObject(DdlGenAction& ddlGenAction,
                                      DdlGenContext& ddlGenContext,
                                      std::map<std::string, DdlGenBuildInfo*>& xdEntityIdxMap,
                                      std::vector<DdlGenBuildInfo*>& genDdlTab,
                                      MemoryPool& mp)
{
    RET_CODE              ret = RET_SUCCEED, gblRet = RET_SUCCEED;
    DBOBJDDLOBJNAT_ENUM   ddlObjNatEn = ddlGenAction.m_ddlObjNatEn;

    if (genDdlTab.empty() == true)
    {
        bool bTreatAll = ddlGenContext.isEntityToMigrate("all");
        TARGET_TABLE_ENUM targetTableEn = (ddlGenContext.migrationMode == DdlGenContext::MigrationMode::None ? TargetTable_Undefined : TargetTable_Main);

        for (OBJECT_ENUM currObj = 0; currObj <= LASTENTITYOBJECT; currObj++)
        {
            DICT_ENTITY_STP dictEntityStp = DBA_GetDictEntitySt(currObj);
            if (dictEntityStp != NULL &&
                (ddlGenAction.m_bInitEntityOnly == false || dictEntityStp->bIsInitEntity == true) &&
                dictEntityStp->isMetaDict() &&
                (bTreatAll || ddlGenContext.isEntityToMigrate(dictEntityStp->mdSqlName)) &&
                (ddlGenAction.m_entitySqlnameStr.empty() ||
                 std::string(dictEntityStp->mdSqlName).find(ddlGenAction.m_entitySqlnameStr) == 0))
            {
                DBA_CreateDdlGenBuildInfo(ddlGenContext,
                                          xdEntityIdxMap,
                                          genDdlTab,
                                          mp,
                                          dictEntityStp,
                                          targetTableEn);

                if (targetTableEn == TargetTable_Main && dictEntityStp->custAuthFlg == TRUE)
                {
                    DBA_CreateDdlGenBuildInfo(ddlGenContext,
                                              xdEntityIdxMap,
                                              genDdlTab,
                                              mp,
                                              dictEntityStp,
                                              TargetTable_UserDefinedFields);
                }
            }
        }

        /* PMSTA-48744 - LJE - 220406 */
        if (ddlGenContext.migrationMode != DdlGenContext::MigrationMode::None &&
            ddlGenAction.m_bInitEntityOnly == false)
        {
            DdlGenDbi localDdlGenDbi(DdlObj_Sql, ddlGenContext, nullptr, nullptr, TargetTable_Main);

            for (auto dbIt = ddlGenContext.tablesFromSrcSysMap.begin(); dbIt != ddlGenContext.tablesFromSrcSysMap.end(); ++dbIt)
            {
                for (auto tblIt = dbIt->second.begin(); tblIt != dbIt->second.end(); ++tblIt)
                {
                    std::string searchTblName = tblIt->first;

                    if (searchTblName.find("ud_") == 0)
                    {
                        searchTblName.erase(0, 3);
                    }
                    else if (searchTblName.find("x_") == 0)
                    {
                        searchTblName.erase(0, 2);
                    }

                    auto xdEntityIdIt = xdEntityIdxMap.find(searchTblName);
                    if (xdEntityIdIt == xdEntityIdxMap.end() &&
                        (bTreatAll || ddlGenContext.isEntityToMigrate(searchTblName)))
                    {
                        bool bForceTarget = false;
                        auto dictEntityStp = localDdlGenDbi.buildDictEntityFromSys(tblIt->first, std::string(), bForceTarget);

                        if (dictEntityStp == nullptr)
                        {
                            std::stringstream msg;
                            msg << "Unknown table description in the source environment: " << dbIt->first << DdlGen::getCmdDbAccess(EV_SourceRdbmsVendor) << tblIt->first;
                            ddlGenContext.printMsg(RET_DBA_INFO_EXIST, msg.str());
                        }
                        else
                        {
                            if (bForceTarget == false)
                            {
                                bForceTarget = true;
                                dictEntityStp = localDdlGenDbi.buildDictEntityFromSys(tblIt->first, std::string(), bForceTarget);
                            }

                            DBA_CreateDdlGenBuildInfo(ddlGenContext,
                                                      xdEntityIdxMap,
                                                      genDdlTab,
                                                      mp,
                                                      dictEntityStp);
                        }
                    }
                }
            }
        }

        if (EV_SourceCfgFile != nullptr)
        {
            for (auto it = genDdlTab.begin(); it != genDdlTab.end(); ++it)
            {
                if ((*it)->getDictEntityStp() != nullptr &&
                    DBA_GetEntityBySqlName((*it)->getDictEntityStp()->mdSqlName, true, true) == nullptr)
                {
                    DdlGen localDdlGen((*it)->getDictEntityStp()->objectEn,
                                       DdlObj_Sql,
                                       ddlGenContext,
                                       nullptr,
                                       nullptr,
                                       nullptr,
                                       TargetTable_Main);
                    (void)localDdlGen.getDictEntityStp(true);
                }
            }
        }
    }

    bool bMultiThreadAllowed = ddlGenAction.m_multiThreadSize > 1 && genDdlTab.size() > 1;

    if (ddlGenContext.getRequestHelper() != nullptr ||                          /* PMSTA-45413 - LJE - 210707 */
        ddlGenAction.m_ddlObjNatEn == DbObjDdlObjNat_BuildInMemory ||
        ddlGenAction.m_ddlObjNatEn == DbObjDdlObjNat_BuildInMetaDict1 ||
        ddlGenAction.m_ddlObjNatEn == DbObjDdlObjNat_BuildInMetaDict2 ||
        ddlGenAction.m_ddlObjNatEn == DbObjDdlObjNat_BuildInMetaDict3 ||
        ddlGenAction.m_ddlObjNatEn == DbObjDdlObjNat_BuildInMetaDict4 ||
        ddlGenAction.m_ddlObjNatEn == DbObjDdlObjNat_BuildInMetaDict5 ||
        ddlGenAction.m_ddlObjNatEn == DbObjDdlObjNat_SetEntityStatus ||
        ddlGenAction.m_ddlObjNatEn == DbObjDdlObjNat_References ||
        ddlGenAction.m_ddlObjNatEn == DbObjDdlObjNat_Label ||
        ddlGenAction.m_ddlObjNatEn == DbObjDdlObjNat_VerticalSearchPattern ||
        ddlGenAction.m_ddlObjNatEn == DbObjDdlObjNat_CheckAndFix ||
        ddlGenAction.m_execModeEn  == DbObjExecMod_BuildVirtualFromFmt ||
        ddlGenAction.m_execModeEn  == DbObjExecMod_BuildFromTemplate ||
        ddlGenAction.m_execModeEn  == DbObjExecMod_RemoveFromTemplate)
    {
        bMultiThreadAllowed = false;
    }
    else
    {
        switch (ddlGenContext.m_rdbmsEn)
        {
            case Nuodb:
                if (ddlGenAction.m_ddlObjNatEn == DbObjDdlObjNat_BuildForeignKey ||
                    ddlGenAction.m_ddlObjNatEn == DbObjDdlObjNat_View ||
                    ddlGenAction.m_ddlObjNatEn == DbObjDdlObjNat_Table ||
                    ddlGenAction.m_ddlObjNatEn == DbObjDdlObjNat_SaveStoredProcInfo)
                {
                    bMultiThreadAllowed = false;
                }
                break;

            case Oracle:
                if (ddlGenAction.m_ddlObjNatEn == DbObjDdlObjNat_BuildForeignKey ||
                    ddlGenAction.m_ddlObjNatEn == DbObjDdlObjNat_Trigger ||
                    ddlGenAction.m_ddlObjNatEn == DbObjDdlObjNat_StoredProc ||
                    (ddlGenAction.m_ddlObjNatEn == DbObjDdlObjNat_Index && ddlGenAction.m_bOraCreateIdxHint))
                {
                    bMultiThreadAllowed = false;
                }
                break;

            case MSSql:
                if (ddlGenAction.m_ddlObjNatEn == DbObjDdlObjNat_Trigger ||
                    ddlGenAction.m_ddlObjNatEn == DbObjDdlObjNat_StoredProc)
                {
                    bMultiThreadAllowed = false;
                }
                break;
                
            case PostgreSQL:
                if (ddlGenAction.m_ddlObjNatEn == DbObjDdlObjNat_BuildForeignKey)
                {
                    bMultiThreadAllowed = false;
                }
                break;
        }
    }
    ddlGenContext.m_parentContext->m_bMultiThreadMode = bMultiThreadAllowed;

    ThreadPool* ddlGenThreadPoolPtr = (bMultiThreadAllowed ? new ThreadPool() : nullptr);

    if (ddlGenThreadPoolPtr != nullptr)
    {
        ddlGenThreadPoolPtr->setStackSize(SYS_GetStackSize());
        ddlGenThreadPoolPtr->setThreadParallelSize(ddlGenAction.m_multiThreadSize);
    }

    if (ddlGenAction.m_ddlObjNatEn == DbObjDdlObjNat_StoredProc &&
        ddlGenAction.m_mainDdlObjNatEn != DbObjDdlObjNat_TslExtension &&
        ddlGenAction.m_mainDdlObjNatEn != DbObjDdlObjNat_System &&
        ddlGenAction.m_installLevel < 9 &&
        ddlGenAction.m_installLevel > 5)
    {
        ddlGenAction.m_installLevel = 5;
    }

    if (ddlGenAction.m_ddlObjNatEn == DbObjDdlObjNat_StoredProc)
    {
        ddlGenAction.m_bSystemFuncOnly = true;
        for (auto it = genDdlTab.begin(); it != genDdlTab.end(); ++it)
        {
            ret = DDL_BuildOneDdlObject(ddlGenAction,
                                            *(*it),
                                            ddlGenThreadPoolPtr);

            if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
            {
                gblRet = ret;
            }
        }
        ddlGenAction.m_bSystemFuncOnly = false;

        if (ddlGenThreadPoolPtr != nullptr)
        {
            ddlGenThreadPoolPtr->waitForDone(100);
        }

        ddlGenAction.m_ddlObjNatEn = DbObjDdlObjNat_SystemView;
        for (auto it = genDdlTab.begin(); it != genDdlTab.end(); ++it)
        {
            ret = DDL_BuildOneDdlObject(ddlGenAction,
                                            *(*it),
                                            ddlGenThreadPoolPtr);

            if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
            {
                gblRet = ret;
            }
        }

        if (ddlGenThreadPoolPtr != nullptr)
        {
            ddlGenThreadPoolPtr->waitForDone(100);
        }
        ddlGenAction.m_ddlObjNatEn = ddlObjNatEn;

        ddlGenAction.m_ddlObjNatEn = DbObjDdlObjNat_UtilsView;
        for (auto it = genDdlTab.begin(); it != genDdlTab.end(); ++it)
        {
            ret = DDL_BuildOneDdlObject(ddlGenAction,
                                            *(*it),
                                            ddlGenThreadPoolPtr);

            if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
            {
                gblRet = ret;
            }
        }

        if (ddlGenThreadPoolPtr != nullptr)
        {
            ddlGenThreadPoolPtr->waitForDone(100);
        }
        ddlGenAction.m_ddlObjNatEn = ddlObjNatEn;

        for (auto it = genDdlTab.begin(); it != genDdlTab.end(); ++it)
        {
            if ((*it)->getDictEntityStp() != nullptr &&
                (*it)->getDictEntityStp()->objectEn == DictErrMsg)
            {
                (*it)->m_ddlGenContextPtr->bBuildDbi = true;
                ret = DDL_BuildOneDdlObject(ddlGenAction,
                                                *(*it),
                                                nullptr);
                (*it)->m_ddlGenContextPtr->bBuildDbi = false;

                if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
                {
                    gblRet = ret;
                }
                break;
            }
        }

        for (auto it = genDdlTab.begin(); it != genDdlTab.end(); ++it)
        {
            if ((*it)->getDictEntityStp() != nullptr &&
                (*it)->getDictEntityStp()->objectEn != DictErrMsg)
            {
                (*it)->m_ddlGenContextPtr->bBuildDbi = true;
                ret = DDL_BuildOneDdlObject(ddlGenAction,
                                                *(*it),
                                                ddlGenThreadPoolPtr);
                (*it)->m_ddlGenContextPtr->bBuildDbi = false;

                if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
                {
                    gblRet = ret;
                }
            }
        }

        if (ddlGenThreadPoolPtr != nullptr)
        {
            ddlGenThreadPoolPtr->waitForDone(100);
        }

        ddlGenAction.m_ddlObjNatEn = DbObjDdlObjNat_View;
        for (auto it = genDdlTab.begin(); it != genDdlTab.end(); ++it)
        {
            ret = DDL_BuildOneDdlObject(ddlGenAction,
                                            *(*it),
                                            ddlGenThreadPoolPtr);

            if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
            {
                gblRet = ret;
            }
        }

        if (ddlGenThreadPoolPtr != nullptr)
        {
            ddlGenThreadPoolPtr->waitForDone(100);
        }
        ddlGenAction.m_ddlObjNatEn = ddlObjNatEn;

        for (auto it = genDdlTab.begin(); it != genDdlTab.end(); ++it)
        {
            if ((*it)->getDictEntityStp() != nullptr &&
                ((*it)->getDictEntityStp()->bIsInitEntity == true ||
                 (*it)->getDictEntityStp()->objectEn == Technical ||
                 (*it)->getDictEntityStp()->objectEn == TabModifStat))
            {
                ret = DDL_BuildOneDdlObject(ddlGenAction,
                                                *(*it),
                                                ddlGenThreadPoolPtr);

                if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
                {
                    gblRet = ret;
                }
            }
        }

        if (ddlGenThreadPoolPtr != nullptr)
        {
            ddlGenThreadPoolPtr->waitForDone(100);
        }
        ddlGenAction.m_ddlObjNatEn = ddlObjNatEn;
    }

    if (ddlGenAction.m_ddlObjNatEn == DbObjDdlObjNat_Table &&
        ddlGenContext.migrationMode != DdlGenContext::MigrationMode::None)
    {
        if (ddlGenContext.m_rdbmsEn == Oracle)
        {
            auto oraProfileIt = ddlGenContext.getCfgFileHelper().profileSectionMap.find("<gui_users>");
            if (oraProfileIt != ddlGenContext.getCfgFileHelper().profileSectionMap.end())
            {
                GEN_SetApplInfo(ApplUserOraProfile, oraProfileIt->second.profile);
                GEN_SetApplInfo(ApplUserOraDefTablespace, oraProfileIt->second.defaultTablespace);
                GEN_SetApplInfo(ApplUserOraTempTablespace, oraProfileIt->second.temporaryTablespace);
            }
        }

        ddlGenAction.m_ddlObjNatEn = DbObjDdlObjNat_Statistics;
        for (auto it = genDdlTab.begin(); it != genDdlTab.end(); ++it)
        {
            (void)DDL_BuildOneDdlObject(ddlGenAction,
                                            *(*it),
                                            ddlGenThreadPoolPtr);
        }

        if (ddlGenThreadPoolPtr != nullptr)
        {
            ddlGenThreadPoolPtr->waitForDone(100);
        }

        struct more_than_key
        {
            inline bool operator() (DdlGenBuildInfo* struct1, DdlGenBuildInfo* struct2)
            {
                if (struct1->getDictEntityStp()->objectEn == Technical &&
                    struct2->getDictEntityStp()->objectEn != Technical)
                {
                    return false;
                }
                if (struct1->getDictEntityStp()->objectEn != Technical &&
                    struct2->getDictEntityStp()->objectEn == Technical)
                {
                    return true;
                }

                if (struct1->getDictEntityStp()->bIsInitEntity == true &&
                    struct2->getDictEntityStp()->bIsInitEntity == false)
                {
                    return false;
                }
                if (struct1->getDictEntityStp()->bIsInitEntity == false &&
                    struct2->getDictEntityStp()->bIsInitEntity == true)
                {
                    return true;
                }

                return (struct1->ddlGenFullTable->getDdlGenEntityPtr()->m_statisticsMap[struct1->m_targetTableEn].m_transfertSize > 
                        struct2->ddlGenFullTable->getDdlGenEntityPtr()->m_statisticsMap[struct2->m_targetTableEn].m_transfertSize);
            }
        };

        sort(genDdlTab.begin(), genDdlTab.end(), more_than_key());

        ddlGenAction.m_ddlObjNatEn = DbObjDdlObjNat_Table;
        for (auto it = genDdlTab.begin(); it != genDdlTab.end(); ++it)
        {
            if ((*it)->getDictEntityStp() != nullptr &&
                ((*it)->getDictEntityStp()->bIsInitEntity == true ||
                 (EV_TargetRdbmsVendor == Sqlite &&
                  SqliteConnection::isMainDb((*it)->getDictEntityStp()->mdSqlName))))
            {
                continue;
            }

            ret = DDL_BuildOneDdlObject(ddlGenAction,
                                        *(*it),
                                        ddlGenThreadPoolPtr);

            if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
            {
                gblRet = ret;
            }
        }

        if (ddlGenThreadPoolPtr != nullptr)
        {
            ddlGenThreadPoolPtr->waitForDone(100);

            for (auto it = genDdlTab.begin(); it != genDdlTab.end(); ++it)
            {
                if (RET_GET_LEVEL((*it)->retCode) == RET_LEV_ERROR)
                {
                    gblRet = (*it)->retCode;
                }
            }
        }

        if (RET_GET_LEVEL(gblRet) != RET_LEV_ERROR)
        {
            for (auto it = genDdlTab.begin(); it != genDdlTab.end(); ++it)
            {
                if ((*it)->getDictEntityStp() == nullptr ||
                    ((*it)->getDictEntityStp()->bIsInitEntity == false &&
                     (EV_TargetRdbmsVendor != Sqlite ||
                      SqliteConnection::isMainDb((*it)->getDictEntityStp()->mdSqlName) == false)))
                {
                    continue;
                }

                ret = DDL_BuildOneDdlObject(ddlGenAction,
                                            *(*it),
                                            nullptr);

                if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
                {
                    gblRet = ret;
                }
            }
        }

        if (RET_GET_LEVEL(gblRet) != RET_LEV_ERROR)
        {
            ddlGenAction.m_ddlObjNatEn = DbObjDdlObjNat_CheckIdentity;

            for (auto it = genDdlTab.begin(); it != genDdlTab.end(); ++it)
            {
                if ((*it)->getDictEntityStp() == nullptr ||
                    (*it)->getDictEntityStp()->bIsInitEntity == false)
                {
                    continue;
                }

                ret = DDL_BuildOneDdlObject(ddlGenAction,
                                            *(*it),
                                            nullptr);

                if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
                {
                    gblRet = ret;
                }
            }
        }

        if (ddlGenAction.m_bInitEntityOnly == false)
        {
            bool bPrintAll = ddlGenContext.isEntityToMigrate("all");

            for (auto dbIt = ddlGenContext.tablesFromSrcSysMap.begin(); dbIt != ddlGenContext.tablesFromSrcSysMap.end(); ++dbIt)
            {
                for (auto tblIt = dbIt->second.begin(); tblIt != dbIt->second.end(); ++tblIt)
                {
                    if (tblIt->first.find("ud_") == 0 ||
                        tblIt->first.find("x_") == 0)
                    {
                        continue;
                    }

                    std::stringstream msg;
                    msg << "Statistic for " << dbIt->first << "." << tblIt->first << ": ";

                    auto entityIt = xdEntityIdxMap.find(tblIt->first);
                    if (entityIt != xdEntityIdxMap.end())
                    {
                        auto ddlGenEntityPtr = entityIt->second->ddlGenFullTable->getDdlGenEntityPtr();
                        auto& statistics = ddlGenEntityPtr->m_statisticsMap[entityIt->second->m_targetTableEn];

                        msg << "source row number " << statistics.m_sourceTotRows
                            << " - target row number " << statistics.m_targetTotRows;
                    }
                    else if (bPrintAll == false)
                    {
                        continue;
                    }
                    else
                    {
                        msg << "Not transfered";
                    }

                    ddlGenContext.printMsg(RET_DBA_INFO_EXIST, msg.str());
                }
            }
        }
    }
    else
    {
        for (auto it = genDdlTab.begin(); it != genDdlTab.end(); ++it)
        {
            /* PMSTA-45413 - LJE - 210611 - Avoid the blocking trigger code */
            if (ddlGenAction.m_ddlObjNatEn == DbObjDdlObjNat_Trigger &&
                ddlGenAction.m_subRequest == false &&
                ddlGenAction.m_bRestrictUpdate &&
                (*it)->getDictEntityStp() != nullptr &&
                (*it)->getDictEntityStp()->entNatEn == EntityNat_System &&
                strstr((*it)->getDictEntityStp()->mdSqlName, "dict_") == (*it)->getDictEntityStp()->mdSqlName)
            {
                continue;
            }

            if (ddlGenAction.m_ddlObjNatEn != DbObjDdlObjNat_StoredProc ||
                (*it)->getDictEntityStp() == nullptr ||
                ((*it)->getDictEntityStp()->bIsInitEntity == false &&
                 (*it)->getDictEntityStp()->objectEn != Technical &&
                 (*it)->getDictEntityStp()->objectEn != TabModifStat))
            {
                ret = DDL_BuildOneDdlObject(ddlGenAction,
                                            *(*it),
                                            ddlGenThreadPoolPtr);

                if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
                {
                    gblRet = ret;
                }
            }
        }
    }

    if (ddlGenAction.m_ddlObjNatEn == DbObjDdlObjNat_StoredProc)
    {
        if (ddlGenThreadPoolPtr != nullptr)
        {
            ddlGenThreadPoolPtr->waitForDone(100);
        }

        /* First pass of try to build invalid procedures */
        for (auto it = genDdlTab.begin(); it != genDdlTab.end(); ++it)
        {
            if ((*it)->ddlGenFullTable != nullptr)
            {
                std::vector<DdlGenBuildInfo*>  tmpGenDdlTab;
                tmpGenDdlTab.push_back((*it));

                DDL_BuildInvalidSproc(*(*it)->ddlGenFullTable->getDdlGenContextPtr(), tmpGenDdlTab);
            }
        }

        if (ddlGenAction.m_installLevel < 9 &&
            ddlGenAction.m_mainDdlObjNatEn != DbObjDdlObjNat_System)
        {
            ddlGenAction.m_installLevel = 4;
        }

        /* Second pass of try to build invalid procedures, with error if failed */
        for (auto it = genDdlTab.begin(); it != genDdlTab.end(); ++it)
        {
            if ((*it)->ddlGenFullTable != nullptr)
            {
                std::vector<DdlGenBuildInfo*>  tmpGenDdlTab;
                tmpGenDdlTab.push_back((*it));
                (*it)->ddlGenFullTable->getDdlGenContextPtr()->ddlGenAction.m_installLevel = ddlGenAction.m_installLevel;

                DDL_BuildInvalidSproc(*(*it)->ddlGenFullTable->getDdlGenContextPtr(), tmpGenDdlTab);
            }
        }

        ddlGenAction.m_ddlObjNatEn = DbObjDdlObjNat_SpecialStoredProc;
        for (auto it = genDdlTab.begin(); it != genDdlTab.end(); ++it)
        {
            ret = DDL_BuildOneDdlObject(ddlGenAction,
                                            *(*it),
                                            ddlGenThreadPoolPtr);

            if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
            {
                gblRet = ret;
            }
        }
        ddlGenAction.m_ddlObjNatEn = ddlObjNatEn;

        if (ddlGenThreadPoolPtr != nullptr)
        {
            ddlGenThreadPoolPtr->waitForDone(100);
        }

        for (auto it = genDdlTab.begin(); it != genDdlTab.end(); ++it)
        {
            if ((*it)->ddlGenFullTable != nullptr)
            {
                std::vector<DdlGenBuildInfo*>  tmpGenDdlTab;
                tmpGenDdlTab.push_back((*it));
                DDL_BuildInvalidSproc(*(*it)->ddlGenFullTable->getDdlGenContextPtr(), tmpGenDdlTab);
            }
        }

        ddlGenAction.m_ddlObjNatEn = DbObjDdlObjNat_SaveStoredProcInfo;
        for (auto it = genDdlTab.begin(); it != genDdlTab.end(); ++it)
        {
            ret = DDL_BuildOneDdlObject(ddlGenAction,
                                            *(*it),
                                            nullptr);

            if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
            {
                gblRet = ret;
            }
        }
        ddlGenAction.m_ddlObjNatEn = ddlObjNatEn;

        if (ddlGenAction.m_bInitEntityOnly == true)
        {
            if (ddlGenThreadPoolPtr != nullptr)
            {
                ddlGenThreadPoolPtr->waitForDone(100);
            }

            ddlGenAction.m_ddlObjNatEn = DbObjDdlObjNat_Trigger;
            for (auto it = genDdlTab.begin(); it != genDdlTab.end(); ++it)
            {
                ret = DDL_BuildOneDdlObject(ddlGenAction,
                                                *(*it),
                                                ddlGenThreadPoolPtr);

                if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
                {
                    gblRet = ret;
                }
            }
            ddlGenAction.m_ddlObjNatEn = ddlObjNatEn;
        }
    }

    DdlGenMsg             stdMsg(ddlGenContext);
    stdMsg.setDdlObjEn(DdlObj_Sql);
    stdMsg.setMsgObjType("Summary");

    for (auto genDdlIt = genDdlTab.begin(); genDdlIt != genDdlTab.end(); ++genDdlIt)
    {
        for (auto migDataStatIt = (*genDdlIt)->m_ddlGenContextPtr->m_migDataStatVector.begin(); migDataStatIt != (*genDdlIt)->m_ddlGenContextPtr->m_migDataStatVector.end(); ++migDataStatIt)
        {
            stdMsg.printMsg(RET_DBA_INFO_MD, *migDataStatIt);
        }
    }

    if (ddlGenThreadPoolPtr != nullptr)
    {
        ddlGenThreadPoolPtr->waitForDone(100);
        delete ddlGenThreadPoolPtr;
    }

    ddlGenContext.m_parentContext->m_bMultiThreadMode = false;
    return gblRet;
}

/************************************************************************
**
**  Function    :   DBA_BuildOneDdlObjectFromFullTable()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**  Last modif. :   PMSTA-13130 - 191211 - PMO : TSL precomputation - Rule engine - TA Part
**
*************************************************************************/
void DBA_BuildOneDdlObjectFromFullTable(ThreadArg* paramDdlGenBuildInfo)
{
    DdlGenBuildInfo* ddlGenBuildInfo = dynamic_cast<DdlGenBuildInfo*>(paramDdlGenBuildInfo);
    DdlGenFullTable* ddlGenFullTable = ddlGenBuildInfo->ddlGenFullTable;
    DdlGenAction& ddlGenAction = ddlGenFullTable->getDdlGenAction();

    RET_CODE ret = ddlGenFullTable->lastErrRetCode;

    if (ddlGenAction.m_execModeEn == DbObjExecMod_BuildFromTemplate)
    {
        ddlGenFullTable->msgObjTypeStr = "Creating ddl objects from template";
    }
    else if (ddlGenAction.m_execModeEn == DbObjExecMod_RemoveFromTemplate)
    {
        ddlGenFullTable->msgObjTypeStr = "Removing ddl objects from template";
    }
    else if (ddlGenAction.m_ddlObjNatEn == DbObjDdlObjNat_SampleImportFile)
    {
        ddlGenFullTable->msgObjTypeStr = "Creating sample import file";
    }
    else if (ddlGenAction.m_ddlObjNatEn == DbObjDdlObjNat_TslExtension)
    {
        ddlGenFullTable->msgObjTypeStr = "Creating of TSL extension";
    }
    else
    {
        ddlGenFullTable->msgObjTypeStr = "Creating ddl objects";
    }

    ddlGenBuildInfo->getDdlGenMsg().setMsgEntitySqlName(ddlGenBuildInfo->getMdSqlName());
    ddlGenBuildInfo->getDdlGenMsg().setMsgObjType(ddlGenFullTable->msgObjTypeStr);

    switch (ddlGenAction.m_ddlObjNatEn)
    {
        case DbObjDdlObjNat_CheckAndFix:
            if (ddlGenBuildInfo->ddlGenFullTable->getXdEntityStp() != nullptr)
            {
                ddlGenBuildInfo->getDdlGenMsg().setMsgInfo(*ddlGenBuildInfo->ddlGenFullTable);
                COPY_DYNFLD(ddlGenBuildInfo->ddlGenFullTable->getXdEntityStp(), A_XdEntity, A_XdEntity_XdStatusEn,
                            ddlGenBuildInfo->getShXdEntityStp(), S_XdEntity, S_XdEntity_XdStatusEn);
                COPY_DYNFLD(ddlGenBuildInfo->ddlGenFullTable->getXdEntityStp(), A_XdEntity, A_XdEntity_XdActionEn,
                            ddlGenBuildInfo->getShXdEntityStp(), S_XdEntity, S_XdEntity_XdActionEn);

                if (GET_ENUM(ddlGenBuildInfo->getShXdEntityStp(), S_XdEntity_XdActionEn) == XdAction_ToInsert ||
                    GET_ENUM(ddlGenBuildInfo->getShXdEntityStp(), S_XdEntity_XdActionEn) == XdAction_ToRefresh)
                {
                    if (RET_GET_LEVEL(ddlGenBuildInfo->retCode) != RET_LEV_ERROR)
                    {
                        ret = ddlGenBuildInfo->ddlGenFullTable->checkAndFix();

                        if (GET_ENUM(ddlGenBuildInfo->ddlGenFullTable->getXdEntityStp(), A_XdEntity_XdActionEn) == XdAction_ToDelete ||
                            GET_ENUM(ddlGenBuildInfo->ddlGenFullTable->getXdEntityStp(), A_XdEntity_XdActionEn) == XdAction_ToPhysicallyDelete)
                        {
                            COPY_DYNFLD(ddlGenBuildInfo->getShXdEntityStp(), S_XdEntity, S_XdEntity_XdActionEn,
                                        ddlGenBuildInfo->ddlGenFullTable->getXdEntityStp(), A_XdEntity, A_XdEntity_XdActionEn);

                            ret = ddlGenBuildInfo->ddlGenFullTable->memoryDeleteEntity();
                        }
                    }
                }
                else
                {
                    ret = ddlGenBuildInfo->ddlGenFullTable->memoryDeleteEntity();
                }

                if (GET_ENUM(ddlGenBuildInfo->getShXdEntityStp(), S_XdEntity_XdActionEn) == XdAction_ToRefresh)
                {
                    SET_ENUM(ddlGenBuildInfo->getShXdEntityStp(), S_XdEntity_XdActionEn, XdAction_ToInsert);
                }
            }
            break;

        case DbObjDdlObjNat_BuildInMemory:
            ret = ddlGenBuildInfo->ddlGenFullTable->buildInMemory();
            ddlGenBuildInfo->setDictEntityStp(ddlGenBuildInfo->ddlGenFullTable->getDictEntityStp());
            break;

        case DbObjDdlObjNat_BuildInMetaDict1:
            ret = ddlGenBuildInfo->ddlGenFullTable->buildInMetaDict1();
            break;

        case DbObjDdlObjNat_BuildInMetaDict2:
            ret = ddlGenBuildInfo->ddlGenFullTable->buildInMetaDict2();
            break;

        case DbObjDdlObjNat_BuildInMetaDict3:
            ret = ddlGenBuildInfo->ddlGenFullTable->buildInMetaDict3();
            break;

        case DbObjDdlObjNat_BuildInMetaDict4:
            ret = ddlGenBuildInfo->ddlGenFullTable->buildInMetaDict4();
            break;

        case DbObjDdlObjNat_BuildInMetaDict5:
            ret = ddlGenBuildInfo->ddlGenFullTable->buildInMetaDict5();
            break;

        case DbObjDdlObjNat_BuildTableInDb:
            if (GET_ENUM(ddlGenBuildInfo->getShXdEntityStp(), S_XdEntity_XdActionEn) == XdAction_ToInsert)
            {
                ret = ddlGenBuildInfo->ddlGenFullTable->buildTablesInDB(ddlGenBuildInfo->m_targetTableEn);
            }
            else if (GET_ENUM(ddlGenBuildInfo->getShXdEntityStp(), S_XdEntity_XdActionEn) == XdAction_ToPhysicallyDelete)
            {
                ret = ddlGenBuildInfo->ddlGenFullTable->deleteTablesInDB();
            }
            break;

        case DbObjDdlObjNat_BuildIndexInDb:
            ret = ddlGenBuildInfo->ddlGenFullTable->buildIndexesInDB();
            break;

        case DbObjDdlObjNat_BuildPrimaryKey:
            ret = ddlGenBuildInfo->ddlGenFullTable->buildPrimaryKeyInDB();
            break;

        case DbObjDdlObjNat_BuildForeignKey:
            ret = ddlGenBuildInfo->ddlGenFullTable->buildForeignKeysInDB();
            break;

        case DbObjDdlObjNat_SetEntityStatus:
            if (GET_ENUM(ddlGenBuildInfo->getShXdEntityStp(), S_XdEntity_XdActionEn) != XdAction_None)
            {
                if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
                {
                    if (GET_ENUM(ddlGenBuildInfo->getShXdEntityStp(), S_XdEntity_XdActionEn) == XdAction_ToInsert)
                    {
                        ret = ddlGenBuildInfo->ddlGenFullTable->setEntityStatus(XdStatus_Inserted);
                    }
                    else if (GET_ENUM(ddlGenBuildInfo->getShXdEntityStp(), S_XdEntity_XdActionEn) == XdAction_ToDelete)
                    {
                        ret = ddlGenBuildInfo->ddlGenFullTable->setEntityStatus(XdStatus_Deleted);
                    }
                    else if (GET_ENUM(ddlGenBuildInfo->getShXdEntityStp(), S_XdEntity_XdActionEn) == XdAction_ToPhysicallyDelete)
                    {
                        ret = ddlGenBuildInfo->ddlGenFullTable->setEntityStatus(XdStatus_PhysicallyDeleted);
                    }
                }
                else
                {
                    ddlGenBuildInfo->ddlGenFullTable->setEntityStatus(XdStatus_Failed);
                }
            }
            break;

        case DbObjDdlObjNat_StoredProc:
            ret = ddlGenFullTable->buildStoredProceduresInDB();

            if (RET_GET_LEVEL(ret) != RET_LEV_ERROR &&
                ddlGenAction.m_mainDdlObjNatEn == DbObjDdlObjNat_StoredProc)
            {
                ret = ddlGenFullTable->buildSpecialSProcsInDB();
            }

            /* PMSTA-45577 - LJE - 210628 */
            if (ddlGenBuildInfo->ddlGenFullTable->getDdlGenContextPtr()->bForceReBuild)
            {
                ret = ddlGenBuildInfo->ddlGenFullTable->getDdlGenContextPtr()->saveDependenciesInDB();
            }

            break;

        case DbObjDdlObjNat_SaveStoredProcInfo:
            /* PMSTA-45413 - LJE - 210614 */
            if (ddlGenBuildInfo->ddlGenFullTable->getDdlGenContextPtr()->bSimulation == false &&
                RET_GET_LEVEL(ddlGenBuildInfo->ddlGenFullTable->getDdlGenContextPtr()->saveStoredProcInfo()) == RET_LEV_ERROR)
            {
                ddlGenBuildInfo->ddlGenFullTable->getDdlGenContextPtr()->endConnection();
                ddlGenBuildInfo->ddlGenFullTable->getDdlGenContextPtr()->initConnection(nullptr, false);
                ddlGenBuildInfo->ddlGenFullTable->getDdlGenContextPtr()->saveStoredProcInfo(false);
            }
            break;

        case DbObjDdlObjNat_SpecialStoredProc:
            ret = ddlGenFullTable->buildSpecialSProcsInDB();
            break;

        case DbObjDdlObjNat_SystemView:
            ret = ddlGenFullTable->buildSysViewsInDB();
            break;

        case DbObjDdlObjNat_UtilsView:
            ret = ddlGenFullTable->buildUtilsViewsInDB();
            break;

        case DbObjDdlObjNat_View:
            ret = ddlGenFullTable->buildViewsInDB();
            break;

            /* PMSTA-13109 - LJE - 111115 */
        case DbObjDdlObjNat_Table:
            ret = ddlGenFullTable->buildTablesInDB(ddlGenBuildInfo->m_targetTableEn);
            break;

        case DbObjDdlObjNat_Statistics:
            ret = ddlGenFullTable->setTablesStatistics(ddlGenBuildInfo->m_targetTableEn);
            break;

        case DbObjDdlObjNat_VerticalSearchPattern:
            ret = ddlGenFullTable->buildVerticalTablesInDB();
            break;

        case DbObjDdlObjNat_Index:
            ret = ddlGenFullTable->buildIndexesInDB(ddlGenAction.m_sqlnameOptStr.empty() ? std::string() : ddlGenAction.m_sqlnameOptStr);
            break;

        case DbObjDdlObjNat_ForeignKey:
            ret = ddlGenFullTable->buildForeignKeysInDB();
            break;

        case DbObjDdlObjNat_Trigger:
            ret = ddlGenFullTable->buildTriggersInDB();
            break;

        case DbObjDdlObjNat_Label:
            ret = ddlGenFullTable->buildLabelsInMetaDict();
            break;

        case DbObjDdlObjNat_XDDict:		/* PMSTA-16395 - TGU - 150721 */
            ret = ddlGenFullTable->buildXDCNameInMetaDict();
            break;

        case DbObjDdlObjNat_BuildCDS:		/* PMSTA-16395 - TGU - 150721 */
            ret = ddlGenFullTable->buildCDynSTfromMD();
            break;

            /* PMSTA-37366 - LJE - 191210 */
        case DbObjDdlObjNat_SampleImportFile:
            ret = ddlGenFullTable->genSampleImportFile();
            break;

        case DbObjDdlObjNat_References:
            if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
            {
                ret = ddlGenFullTable->saveReferencesInDb();
            }
            break;

        case DbObjDdlObjNat_CheckIdentity:
            ret = ddlGenFullTable->checkIdentityValues();
            break;

        case DbObjDdlObjNat_OnlineHelpDocument:
            ret = ddlGenFullTable->processHelpDocument();
            break;

        default:
            ddlGenFullTable->lastErrRetCode = RET_GEN_ERR_INVARG;
            return;
    }

    ddlGenBuildInfo->getDdlGenMsg().setMsgSqlName(std::string());

    ddlGenAction.m_bSystemFuncOnly = false;

    if (RET_GET_LEVEL(ret) == RET_LEV_ERROR &&
        RET_GET_LEVEL(ddlGenBuildInfo->retCode) != RET_LEV_ERROR)
    {
        ddlGenBuildInfo->retCode = ret;
    }
    ddlGenFullTable->lastErrRetCode = ret;

    ddlGenFullTable->getDdlGenContextPtr()->m_bMultiThreadMode = false;
}

/************************************************************************
**
**  Function    :   DDL_BuildOneDdlObject()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**  Last modif. :   PMSTA-13130 - 191211 - PMO : TSL precomputation - Rule engine - TA Part
**
*************************************************************************/
STATIC RET_CODE DDL_BuildOneDdlObject(DdlGenAction& ddlGenAction,
                                          DdlGenBuildInfo& ddlGenBuildInfo,
                                          ThreadPool* ddlGenThreadPoolPtr)
{
    if (ddlGenBuildInfo.ddlGenFullTable == nullptr ||
        ddlGenBuildInfo.retCode == RET_GEN_INFO_NOACTION ||
        (RET_GET_LEVEL(ddlGenBuildInfo.retCode) == RET_LEV_ERROR && ddlGenAction.m_ddlObjNatEn != DbObjDdlObjNat_SetEntityStatus))
    {
        return ddlGenBuildInfo.retCode;
    }

    if (GET_ENUM(ddlGenBuildInfo.getShXdEntityStp(), S_XdEntity_XdActionEn) != XdAction_ToInsert &&
        GET_ENUM(ddlGenBuildInfo.getShXdEntityStp(), S_XdEntity_XdActionEn) != XdAction_ToRefresh &&
        (GET_ENUM(ddlGenBuildInfo.getShXdEntityStp(), S_XdEntity_XdActionEn) != XdAction_ToPhysicallyDelete ||
         (ddlGenAction.m_ddlObjNatEn != DbObjDdlObjNat_BuildTableInDb &&
          ddlGenAction.m_ddlObjNatEn != DbObjDdlObjNat_CheckAndFix &&
          ddlGenAction.m_ddlObjNatEn != DbObjDdlObjNat_SetEntityStatus)))
    {
        return ddlGenBuildInfo.retCode;
    }

    DdlGenFullTable* ddlGenFullTable = ddlGenBuildInfo.ddlGenFullTable;
    ddlGenFullTable->getDdlGenAction() = ddlGenAction;
    ddlGenFullTable->getDdlGenAction().m_entitySqlnameStr = ddlGenBuildInfo.getMdSqlName();

    if (ddlGenThreadPoolPtr != nullptr)
    {
        ddlGenFullTable->getDdlGenContextPtr()->m_bMultiThreadMode = true;
        ddlGenThreadPoolPtr->add(true,
                                 &DBA_BuildOneDdlObjectFromFullTable,
                                 &ddlGenBuildInfo,
                                 SYS_Stringer("DdlGenThread-", ddlGenFullTable->getDdlGenAction().getDdlObjNatStr(), "-", ddlGenFullTable->getDdlGenAction().m_entitySqlnameStr).c_str(),
                                 nullptr,
                                 ThreadFunctionalType::UNKNOWN,
                                 nullptr);
    }
    else
    {
        DBA_BuildOneDdlObjectFromFullTable(&ddlGenBuildInfo);
    }

    return ddlGenFullTable->lastErrRetCode;
}

/************************************************************************
**
**  Function    :   DDL_InstallDdlObjectByParam()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
RET_CODE DDL_InstallDdlObjectByParam()
{
    RET_CODE        ret = RET_SUCCEED;
    DdlGenContext   ddlGenContext(EV_TargetRdbmsVendor);
    DdlGenAction    ddlGenAction;

    switch (EV_GenDdlContext.infoPtr[0])
    {
        case 'd':
            switch (EV_GenDdlContext.infoPtr[1])
            {
                case 's':
                    ddlGenAction.m_ddlObjNatEn = DbObjDdlObjNat_UserTableDS;
                    break;
                case 'a':
                    ddlGenAction.m_ddlObjNatEn = DbObjDdlObjNat_AllTable;
                    break;
                case 'e':
                    ddlGenAction.m_ddlObjNatEn = DbObjDdlObjNat_TslExtension;
                    break;
                case 't':
                    ddlGenAction.m_ddlObjNatEn = DbObjDdlObjNat_TempTable;
                    break;
                case 'i':
                    ddlGenAction.m_ddlObjNatEn = DbObjDdlObjNat_System;
                    break;
                case 'u':
                    ddlGenAction.m_ddlObjNatEn = DbObjDdlObjNat_UserTable;
                    break;
                    /* PMSTA-27352 - LJE - 170606 */
                case 'm':
                    ddlGenAction.m_ddlObjNatEn = DbObjDdlObjNat_ModelBank;
                    break;
            }
            break;

        case 'f': /* fk */
            ddlGenAction.m_ddlObjNatEn = DbObjDdlObjNat_ForeignKey;

            break;

        case 'i': /* idx */
            ddlGenAction.m_ddlObjNatEn = DbObjDdlObjNat_Index;
            break;

        case 'p':
            /* PMSTA13876 - DDV - 130730 - Add new case -Gpf (persisted format) to create xd_model and table for persisted formats */
            if (EV_GenDdlContext.infoPtr[1] == 'f')
            {
                ddlGenAction.m_ddlObjNatEn = DbObjDdlObjNat_PersistedFmt;
            }
            else
            {
                ddlGenAction.m_ddlObjNatEn = DbObjDdlObjNat_StoredProc;
            }
            break;

        case 'q':
            /* PMSTA-19243 - DDV - 150330 - Add new case -Gq (questionnaire) to create xd_model and table for questionnaires */
            ddlGenAction.m_ddlObjNatEn = DbObjDdlObjNat_Questionnaire;
            break;

            /* PMSTA-22072 - LJE - 160108 */
        case 'r':
            ddlGenAction.m_ddlObjNatEn = DbObjDdlObjNat_ReportFmt;
            break;

        case 't':
            switch (EV_GenDdlContext.infoPtr[1])
            {
                case 'r':
                    ddlGenAction.m_ddlObjNatEn = DbObjDdlObjNat_Trigger;
                    break;

                case 'b':
                default:
                    ddlGenAction.m_ddlObjNatEn = DbObjDdlObjNat_Table;
            }
            break;

        case 'u':
            ddlGenAction.m_ddlObjNatEn = DbObjDdlObjNat_UserTable;
            break;

        case 'l':
            ddlGenAction.m_ddlObjNatEn = DbObjDdlObjNat_Label;
            break;

        case 'v':
            ddlGenAction.m_ddlObjNatEn = DbObjDdlObjNat_View;
            break;

        case 'c':
            switch (EV_GenDdlContext.infoPtr[1])
            {
                case 'n':
                    ddlGenAction.m_ddlObjNatEn = DbObjDdlObjNat_XDDict;
                    break;

                case 'd':
                    ddlGenAction.m_ddlObjNatEn = DbObjDdlObjNat_BuildCDS;
                    break;

                case 's':
                    ddlGenAction.m_ddlObjNatEn = DbObjDdlObjNat_BuildStaticDS;
                    break;

                case 'i':
                    ddlGenAction.m_ddlObjNatEn = DbObjDdlObjNat_CheckIdentity;
                    break;

                case '\0':
                    ddlGenAction.m_ddlObjNatEn = DbObjDdlObjNat_InstallCfg;
                    break;
            }
            break;

        case 's':
            ddlGenAction.m_ddlObjNatEn = DbObjDdlObjNat_SampleImportFile;
            break;

        case 'h':
            ddlGenAction.m_ddlObjNatEn = DbObjDdlObjNat_OnlineHelpDocument;
            break;
    }


    EV_TimerMask = TIMER_MASK_GEN;
    ddlGenContext.optimMask = SYS_GetEnvIntOrDefValue("AAADDLGENOPTIM", 3);

    /* PMSTA-14452 - LJE - 121120 */
    if (EV_GenDdlContext.optionPtr != NULL)
    {
        int i = 0;
        while (EV_GenDdlContext.optionPtr[i] != 0)
        {
            switch (EV_GenDdlContext.optionPtr[i])
            {
                case 'f':
                    ddlGenContext.bForceReBuild = true;
                    ddlGenContext.optimMask     = 0;
                    break;

                case 'c':
                    ddlGenContext.bCheck = true;
                    break;

                case 'u':
                    ddlGenContext.bUniqueOnly = true;
                    break;

                case 's':
                    ddlGenContext.bSimulation = true;
                    break;

                case 'i':
                    ddlGenContext.bIgnoreCheck = true;
                    break;

                case 'd':
                    ddlGenContext.bDisable = true;
                    break;

                case 'g':
                    ddlGenContext.bBuildDbi = true;
                    ddlGenContext.bGenFromDbi = true;
                    ddlGenContext.bSimulation = true;
                    ddlGenContext.setDdlDestDbName(ddlGenContext.getMainDbName(), nullptr);

                    ddlGenAction.m_execModeEn = DbObjExecMod_BuildFilesOnly;

                    EV_GenDdlContext.bSqlFileOnly = true;

                    break;

                case 'M':
                    ddlGenContext.migrationMode = DdlGenContext::MigrationMode::CfgAndData;
                    break;

                case 'm':
                    ddlGenContext.migrationMode = DdlGenContext::MigrationMode::Data;
                    break;

                case 'o':
                    ddlGenContext.optimLevelEn = DdlGenContext::OptimLevel::Full;
                    break;

                case 'E':
                    ddlGenAction.m_bExtractData    = true;
                    ddlGenAction.m_bUseNativeQuery = true;
                    ddlGenAction.m_installLevel    = 99;
                    ddlGenContext.migrationMode    = DdlGenContext::MigrationMode::Data;

                    EV_AAAInstallLevel = ddlGenAction.m_installLevel;
                    break;
            }
            i++;
        }
    }

    if (ddlGenAction.m_ddlObjNatEn  == DbObjDdlObjNat_StoredProc &&
        (ddlGenAction.m_installLevel <= 1 || 
         (ddlGenAction.m_installLevel > 4 && ddlGenAction.m_installLevel != 19)))
    {
        if (EV_GenDdlContext.objPtr == nullptr)
        {
            ddlGenAction.m_installLevel = 5;
        }
        else
        {
            ddlGenAction.m_installLevel = 4;
        }
        EV_AAAInstallLevel = ddlGenAction.m_installLevel;
    }

    if (ddlGenAction.m_ddlObjNatEn == DbObjDdlObjNat_None)
    {
        std::stringstream msg;

        ret = RET_ENV_ERR_WRONGCONFIG;

        msg << "ddl object nature '" << EV_GenDdlContext.infoPtr << "' not yet implemented";
        ddlGenContext.printMsg(ret, msg.str());
        return(ret);
    }
    ddlGenAction.m_mainDdlObjNatEn = ddlGenAction.m_ddlObjNatEn;

    SYS_SetGetThreadICUContext(SYS_GetThreadICUContext);  /* PMSTA-48207 - LJE - 220314 */
    ddlGenContext.initFromIniFile();

    if (ddlGenContext.checkSourceDbConnection() == false)
    {
        ret = RET_DBA_ERR_CANNOTCONNECT;
        ddlGenContext.printMsg(ret, "Cannot connect to the target database!");
        return ret;
    }

    if (ddlGenContext.migrationMode != DdlGenContext::MigrationMode::None)
    {
        /* PMSTA-48744 - LJE - 220407 */
        DdlGenDbi localDdlGenDbi(DdlObj_Sql, ddlGenContext, nullptr, nullptr, TargetTable_Main);
        ddlGenContext.tablesFromSrcSysMap = localDdlGenDbi.getAllTablesFromSys();

        /* PMSTA-37374 - LJE - 210416 - Init the exceptions */
        ddlGenContext.initEntityToMigrate();
    }

    if (EV_GenDdlContext.objPtr != NULL)
    {
        ddlGenAction.m_entitySqlnameStr = EV_GenDdlContext.objPtr;
    }
    ddlGenAction.m_paramEntitySqlnameStr = ddlGenAction.m_entitySqlnameStr;
    ret = DDL_InstallDdlObject(ddlGenAction, ddlGenContext);

    if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
    {
        ret = RET_SUCCEED;
    }
    return ret;
}

/************************************************************************
**
**  Function    :   DDL_InstallDdlObject()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
RET_CODE DDL_InstallDdlObject(DdlGenAction& ddlGenAction, DdlGenContext& ddlGenContext)
{
    RET_CODE        ret = RET_SUCCEED;
    bool            bLoadCfFiles = false;
    DdlGenMsg       ddlGenMsg(&ddlGenContext);

    ddlGenContext.ddlGenAction = ddlGenAction;

    if (ddlGenAction.m_installLevel < 3 &&
        ddlGenAction.m_execModeEn != DbObjExecMod_BuildFilesOnly &&
        DBA_IsDboUser() == false &&
        (ddlGenAction.m_ddlObjNatEn == DbObjDdlObjNat_AllTable || DBA_IsTascTechUser() == false))
    {
        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "DDL_InstallDdlObject", "The user must be DBO or along tasc_tech role");
        return(RET_GEN_ERR_INVARG);
    }

    /* PMSTA-28704 - LJE - 180403 */
    switch (ddlGenAction.m_ddlObjNatEn)
    {
        case DbObjDdlObjNat_XDDict:
        case DbObjDdlObjNat_BuildCDS:
        case DbObjDdlObjNat_BuildStaticDS:
        case DbObjDdlObjNat_SampleImportFile:
            break;

        default:
            if (&ddlGenContext == ddlGenContext.m_parentContext &&
                ddlGenContext.ddlGenAction.m_execModeEn != DbObjExecMod_BuildFromTemplate)
            {
                bLoadCfFiles = true;
            }
    }

    switch (ddlGenAction.m_execModeEn)
    {
        case DbObjExecMod_Check:
            ddlGenContext.bCheck = true;
        case DbObjExecMod_BuildFilesOnly:
            ddlGenContext.bSendInDb = false;
            break;

        case DbObjExecMod_DBBuildWOFiles:
            ddlGenContext.bWriteFile = false;
            ddlGenContext.bSendInDb = true;
            break;

        case DbObjExecMod_BuildFromTemplate:
        case DbObjExecMod_RemoveFromTemplate:
            if (ddlGenAction.m_mainDdlObjNatEn == ddlGenAction.m_ddlObjNatEn)
            {
                ddlGenContext.bWriteFile = false;
                ddlGenContext.bSendInDb = true;
            }
            break;

        case DbObjExecMod_DBBuildWFiles:
            ddlGenContext.bSendInDb = true;
            break;

        default:
            char msg[255];
            ret = RET_ENV_ERR_WRONGCONFIG;

            sprintf(msg, "ddl execution mode %d not yet implemented", ddlGenAction.m_execModeEn);
            ddlGenMsg.printMsg(ret, msg);
            return(ret);
    }

    if (ddlGenContext.bSimulation == true)
    {
        ddlGenContext.bSendInDb = false;
    }

    if (bLoadCfFiles && ddlGenContext.getDdlGenPath().empty())
    {
        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "DDL_InstallDdlObject", "Missing DDL path! (please set AAADDLPATH)");
        return RET_GEN_ERR_INVARG;
    }

    if (bLoadCfFiles && ddlGenContext.getAaaHomePath().empty() == false)
    {
        if (ddlGenContext.ddlGenAction.m_mainDdlObjNatEn == DbObjDdlObjNat_InstallCfg ||
            ddlGenContext.migrationMode == DdlGenContext::MigrationMode::CfgAndData)
        {
            ddlGenContext.getCfgFileHelper(false).keepFileInMemory();
        }

        if (ddlGenContext.getCfgFileHelper().loadCfgFile() != RET_SUCCEED)
        {
            ret = RET_ENV_ERR_WRONGCONFIG;
            return(ret);
        }

        /* PMSTA-37374 - LJE - 210427 */
        if (ddlGenContext.ddlGenAction.m_mainDdlObjNatEn == DbObjDdlObjNat_InstallCfg)
        {
            if (ddlGenContext.migrationMode == DdlGenContext::MigrationMode::CfgAndData &&
                EV_SourceCfgFile != nullptr &&
                EV_TargetCfgFile != nullptr)
            {
                EV_TargetCfgFile->syncFiles(*EV_SourceCfgFile, true);
                EV_TargetCfgFile->write();
            }
            else
            {
                ddlGenContext.getCfgFileHelper().upgradeFile();
            }

            return ret;
        }

        /* PMSTA-32673 - LJE - 180831 */
        if ((ddlGenAction.m_ddlObjNatEn == DbObjDdlObjNat_AllTable || ddlGenAction.m_ddlObjNatEn == DbObjDdlObjNat_TslExtension) &&
            ddlGenAction.m_entitySqlnameStr.empty() &&
            ddlGenContext.getCfgFileHelper().checkCfgFile() != RET_SUCCEED)
        {
            ret = RET_ENV_ERR_WRONGCONFIG;
            return(ret);
        }

        if (ddlGenContext.getTemplateFileHelper().loadCfgFile() != RET_SUCCEED)
        {
            ret = RET_ENV_ERR_WRONGCONFIG;
            return(ret);
        }
        if (ddlGenContext.getUpgradeFileHelper().loadCfgFile() != RET_SUCCEED)
        {
            ret = RET_ENV_ERR_WRONGCONFIG;
            return(ret);
        }
        if (ddlGenContext.getPropFileHelper().loadCfgFile() != RET_SUCCEED)
        {
            ret = RET_ENV_ERR_WRONGCONFIG;
            return(ret);
        }

        /* PMSTA-43625 - LJE - 210308 - Check configuration */
        if (ddlGenContext.isEnableMultiTascLogin() == true && ddlGenContext.isEnableSecuOnFkView() == false)
        {
            std::string msg("If the configuration variable ENABLE_MULTI_TASC_LOGIN is define to 1, the variable ENABLE_SECU_ON_FK_VIEW cannot be set to 0");

            ddlGenMsg.printMsg(RET_ENV_ERR_WRONGCONFIG, msg);
            MSG_SendMesg(RET_ENV_ERR_WRONGCONFIG, 1, FILEINFO, "DDL_InstallDdlObject", msg.c_str());

            return RET_ENV_ERR_WRONGCONFIG;
        }
    }

    if (bLoadCfFiles &&
        ddlGenContext.ddlGenAction.m_subRequest == false &&
        ddlGenContext.ddlGenAction.m_execModeEn != DbObjExecMod_BuildFilesOnly &&
        ddlGenContext.getAaaHomePath().empty() == false &&
        ddlGenAction.m_ddlObjNatEn != DbObjDdlObjNat_System &&
        (ddlGenAction.m_ddlObjNatEn == DbObjDdlObjNat_Trigger ||
         ddlGenAction.m_entitySqlnameStr.empty() ||
         ddlGenAction.m_entitySqlnameStr == "init" ||
         ddlGenAction.m_installLevel < 9))
    {
        if (ddlGenContext.ddlGenAction.m_installLevel < 99 &&
            ddlGenAction.m_ddlObjNatEn == DbObjDdlObjNat_AllTable &&
            ddlGenAction.m_fromImport == false)
        {
            ddlGenContext.initConnection(nullptr, false);

            DdlGenDbi ddlGenDbi(DdlObj_Sql, ddlGenContext, nullptr, nullptr, TargetTable_Main);
            std::map<DdlObjDefKey, DdlObjDef>    ddlObjDefMap;

            ddlGenDbi.getAllDdlObjListFromDb(ddlObjDefMap, ddlGenContext.getMainDbName(), "appl_param", "appl_param", DdlObj_Table);
            if (ddlObjDefMap.empty())
            {
                ddlGenContext.m_bIsInstallFromScratch = true;
                ddlGenContext.optimMask = 0;
            }
            ddlGenContext.endConnection();
        }

        if (ddlGenContext.m_bIsInstallFromScratch == false &&
            ddlGenContext.optimLevelEn != DdlGenContext::OptimLevel::Full &&
            ddlGenContext.migrationMode == DdlGenContext::MigrationMode::None)
        {
            ddlGenContext.manageSegment();
        }

        ddlGenContext.identityCacheSize = ddlGenContext.getCfgFileHelper().getPropertyUnsignedOrDefValue("IDENTITY_CACHE_SIZE", 1000);

        if (ddlGenContext.m_rdbmsEn == Oracle)
        {
            ddlGenAction.m_bOraCreateIdxHint = ddlGenContext.getCfgFileHelper().getPropertyBoolOrDefValue("ORACLE_CREATE_INDEX_HINT", true); /* PMSTA-48555 - JBC - 220323 */
            ddlGenContext.ddlGenAction.m_bOraCreateIdxHint = ddlGenAction.m_bOraCreateIdxHint;
            ddlGenAction.m_bOraNologgingHint = ddlGenContext.getCfgFileHelper().getPropertyBoolOrDefValue("ORACLE_NOLOGGING_HINT", false); /* PMSTA-49523 - LJE - 220719 */
            ddlGenContext.ddlGenAction.m_bOraNologgingHint = ddlGenAction.m_bOraNologgingHint;
        }
        /* PMSTA-58084 - LJE - 240729 */
        else if (ddlGenContext.m_rdbmsEn == MSSql)
        {
        	/*  
        	 *  PMSTA-61914 - JBC - 20241203 
        	 * 
        	 *	Based on further client testing and proc refactoring this feature is off by default.
        	 *	It was found that memory opti temp tables clearly share resources and under heavy concurrency.
        	 *	There is some garbage collection activity, and some sort of mutexing going on. In concurrent user
        	 *	testing one big function (large order list for example) can slow down other independent functions.
        	 *	This is not acceptable for an OTLP system that must support many concurrent needs and has heavy
        	 *	use of temp tables.
        	 *	
        	 *	Consultations with MS were not convincing, and their recommendations had no noticeable effects. 
        	 *	Memory Optimized tables seem to be best for reading, and not great for consistent DML.
        	 *	More testing is needed to determine if/where mem opti tables are effective enough to enable, 
        	 *	and if only for a specific funciton or need.
        	 *	
        	 *	Refactoring TAP Core product and procedures is a more favourable option.
			 */
            ddlGenAction.m_useMemoryOptizedTempTable = ddlGenContext.getCfgFileHelper().getPropertyBoolOrDefValue("USE_MEMORY_OPTIMIZED_DATA", false);
            ddlGenContext.ddlGenAction.m_useMemoryOptizedTempTable = ddlGenAction.m_useMemoryOptizedTempTable;

            ddlGenContext.bUseClusterIdx = ddlGenContext.getCfgFileHelper().getPropertyBoolOrDefValue("AAAUSECLUSTERIDX", true);
            ddlGenContext.bCreatePK      = ddlGenContext.getCfgFileHelper().getPropertyBoolOrDefValue("AAACREATEPRIMARYKEY", true);
        }
    }

    if (bLoadCfFiles &&
        ddlGenContext.ddlGenAction.m_subRequest == false)
    {
        ddlGenAction.m_multiThreadSize = SYS_GetEnvUnsignedOrDefValue("AAADDLGENMTSIZE", 0);
        if (ddlGenAction.m_multiThreadSize == 0)
        {
            ddlGenAction.m_multiThreadSize = ddlGenContext.getCfgFileHelper().getPropertyUnsignedOrDefValue("AAADDLGENMTSIZE", 1);
        }
        ddlGenContext.ddlGenAction.m_multiThreadSize = ddlGenAction.m_multiThreadSize;

        ddlGenAction.m_parallelLoad = SYS_GetEnvUnsignedOrDefValue("AAAPARALLELLOAD", 0);
        if (ddlGenAction.m_parallelLoad == 0)
        {
            ddlGenAction.m_parallelLoad = ddlGenContext.getCfgFileHelper().getPropertyUnsignedOrDefValue("AAAPARALLELLOAD", 0);
        }
        ddlGenContext.ddlGenAction.m_parallelLoad = ddlGenAction.m_parallelLoad;
    }

    ddlGenMsg.printConfig();

    if (ddlGenAction.m_ddlObjNatEn != DbObjDdlObjNat_UserTableDS &&
        ddlGenAction.m_ddlObjNatEn != DbObjDdlObjNat_UserTable &&
        ddlGenAction.m_ddlObjNatEn != DbObjDdlObjNat_ModelBank &&    /* PMSTA-27352 - LJE - 170606 */
        ddlGenAction.m_ddlObjNatEn != DbObjDdlObjNat_AllTable &&
        ddlGenAction.m_ddlObjNatEn != DbObjDdlObjNat_TslExtension &&
        ddlGenAction.m_ddlObjNatEn != DbObjDdlObjNat_TempTable &&
        ddlGenAction.m_ddlObjNatEn != DbObjDdlObjNat_System &&
        ddlGenAction.m_ddlObjNatEn != DbObjDdlObjNat_PersistedFmt &&
        ddlGenAction.m_ddlObjNatEn != DbObjDdlObjNat_ReportFmt &&    /* PMSTA-22072 - LJE - 160108 */
        ddlGenAction.m_ddlObjNatEn != DbObjDdlObjNat_Questionnaire && /* PMSTA-19243 - DDV - 150330 */
        ddlGenAction.m_ddlObjNatEn != DbObjDdlObjNat_SearchFmt) /* PMSTA13876 - DDV - 130808 */
    {
        if (ddlGenAction.m_ddlObjNatEn == DbObjDdlObjNat_View &&
            ddlGenAction.m_execModeEn != DbObjExecMod_BuildFromTemplate)
        {
            DdlGenAction sysDdlGenAction(ddlGenAction, true);

            sysDdlGenAction.m_ddlObjNatEn = DbObjDdlObjNat_SystemView;
            ret = DDL_BuildDdlObject(ddlGenContext, sysDdlGenAction);

            sysDdlGenAction.m_ddlObjNatEn = DbObjDdlObjNat_UtilsView;
            ret = DDL_BuildDdlObject(ddlGenContext, sysDdlGenAction);
        }

        if (ret == RET_SUCCEED)
        {
            ret = DDL_BuildDdlObject(ddlGenContext, ddlGenAction);
        }
    }
    else /* PMSTA-13109 - LJE - 111115 */
    {
        ret = DDL_BuildTable(ddlGenContext);
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DDL_BuildDdlObject()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
STATIC RET_CODE DDL_BuildDdlObject(DdlGenContext& ddlGenContext, DdlGenAction& ddlGenAction)
{
    RET_CODE        ret = RET_SUCCEED;
    RET_CODE        gblRet = RET_SUCCEED;
    OBJECT_ENUM     objectEn = NullEntity;
    DICT_ENTITY_STP dictEntityStp = NULL;
    std::string          locStr;
    std::string          grpEntityStr = std::string();
    MemoryPool      mp;
    DdlGenMsg       gblMsg(ddlGenContext);

#ifdef AAAPURIFY
#ifdef NT
    PurifyNewLeaks();
#endif
#endif

    /* Check parameters */
    switch (ddlGenAction.m_ddlObjNatEn)
    {
        case DbObjDdlObjNat_StoredProc:
        case DbObjDdlObjNat_SpecialStoredProc:
        case DbObjDdlObjNat_View:
        case DbObjDdlObjNat_SystemView:
        case DbObjDdlObjNat_UtilsView:
        case DbObjDdlObjNat_Index: /* PMSTA-14086 - LJE - 121005 */
        case DbObjDdlObjNat_Table:
        case DbObjDdlObjNat_Trigger: /* PMSTA-14452 - LJE - 130116 */
        case DbObjDdlObjNat_Label: /* PMSTA-14452 - LJE - 130306 */
        case DbObjDdlObjNat_ForeignKey:
        case DbObjDdlObjNat_XDDict:			/* PMSTA-16395 - TGU - 150721 */
        case DbObjDdlObjNat_BuildCDS:		/* PMSTA-16395 - TGU - 150721 */
        case DbObjDdlObjNat_SampleImportFile: /* PMSTA-37366 - LJE - 191210 */
        case DbObjDdlObjNat_CheckIdentity: /* PMSTA-37374 - LJE - 201214 */
        case DbObjDdlObjNat_OnlineHelpDocument:
            break;

        default:
            char msg[255];
            sprintf(msg, "ddl object nature %d not yet implemented", ddlGenAction.m_ddlObjNatEn);
            MSG_SendMesg(RET_GEN_ERR_INVARG, 4, FILEINFO, "DDL_BuildDdlObject", msg);
            return(RET_GEN_ERR_INVARG);
    }

    if (ddlGenAction.m_subRequest == false)
    {
        gblMsg.printMsg(RET_SRV_INFO_RUNNING, "Start processing...");
    }

    if (ddlGenAction.m_entitySqlnameStr.empty() ||
        ddlGenAction.m_entitySqlnameStr[0] == 0 ||
        ddlGenAction.m_entitySqlnameStr[1] == 0)
    {
        objectEn = NullEntity;
    }
    else if (strcmp(ddlGenAction.m_entitySqlnameStr.c_str(), "dict") == 0 ||
             strcmp(ddlGenAction.m_entitySqlnameStr.c_str(), "xd") == 0)
    {
        objectEn = NullEntity;
        grpEntityStr = ddlGenAction.m_entitySqlnameStr + "_";
    }
    else if (strcmp(ddlGenAction.m_entitySqlnameStr.c_str(), "init") == 0)
    {
        objectEn = NullEntity;
        grpEntityStr = "init";
    }
    else
    {
        ddlGenAction.m_bSingleEntity = true;
        ddlGenContext.ddlGenAction.m_bSingleEntity = true;

        dictEntityStp = DBA_GetEntityBySqlName(ddlGenAction.m_entitySqlnameStr);

        /* PMSTA-48744 - LJE - 220406 */
        if (dictEntityStp == nullptr &&
            ddlGenContext.migrationMode != DdlGenContext::MigrationMode::None)
        {
            bool      bForceTarget = true;
            DdlGenDbi localDdlGenDbi(DdlObj_Sql, ddlGenContext, nullptr, nullptr, TargetTable_Main);

            dictEntityStp = localDdlGenDbi.buildDictEntityFromSys(ddlGenAction.m_entitySqlnameStr, std::string(), bForceTarget);

            if (dictEntityStp != nullptr)
            {
                bForceTarget = false;
                (void)localDdlGenDbi.buildDictEntityFromSys(ddlGenAction.m_entitySqlnameStr, std::string(), bForceTarget);
            }
        }

        if (dictEntityStp != nullptr)
        {
            DBA_GetObjectEnum(dictEntityStp->entDictId, &objectEn);
        }
        /* PMSTA-14086 - LJE - 121009 */
        else if (ddlGenAction.m_ddlObjNatEn == DbObjDdlObjNat_Index)
        {
            DBA_DYNFLD_STP shXdIndexStp = mp.allocDynst(FILEINFO, S_XdIndex);
            DBA_DYNFLD_STP shXdEntityStp = mp.allocDynst(FILEINFO, S_XdEntity);

            SET_SYSNAME(shXdIndexStp, S_XdIndex_SqlName, ddlGenAction.m_entitySqlnameStr.c_str());

            if (DBA_Get2(XdIndex,
                         UNUSED,
                         S_XdIndex,
                         shXdIndexStp,
                         S_XdIndex,
                         &shXdIndexStp,
                         UNUSED,
                         UNUSED,
                         UNUSED) != RET_SUCCEED)
            {
                /* PMSTA-14452 - LJE - 130204 - The message should be managed by the caller */
                return(RET_GEN_INFO_NOACTION);
            }

            COPY_DYNFLD(shXdEntityStp, S_XdEntity, S_XdIndex_Id,
                        shXdIndexStp, S_XdIndex, S_XdIndex_XdEntityId);

            if (DBA_Get2(XdEntity,
                         UNUSED,
                         S_XdEntity,
                         shXdEntityStp,
                         S_XdEntity,
                         &shXdEntityStp,
                         UNUSED,
                         UNUSED,
                         UNUSED) != RET_SUCCEED)
            {
                std::stringstream msg;
                msg << "Unknown extended entity for index: " << ddlGenAction.m_entitySqlnameStr;
                MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "DDL_BuildDdlObject", msg.str().c_str());
                FREE_DYNST(shXdIndexStp, S_XdIndex);
                return(RET_GEN_ERR_INVARG);
            }

            ddlGenAction.m_entitySqlnameStr = GET_SYSNAME(shXdEntityStp, S_XdEntity_SqlName);
            ddlGenAction.m_sqlnameOptStr = GET_LONGSYSNAME(shXdIndexStp, S_XdIndex_SqlName);

            DBA_GetObjectEnum(GET_DICT(shXdEntityStp, S_XdEntity_EntityDictId), &objectEn);

            dictEntityStp = DBA_GetDictEntitySt(objectEn);
        }

        if (objectEn == NullEntity)
        {
            /* PMSTA-14452 - LJE - 130204 - The message should be managed by the caller */
            return(RET_GEN_INFO_NOACTION);
        }
    }

    if (grpEntityStr.compare("init") == 0)
    {
        std::map<std::string, DdlGenBuildInfo*> xdEntityIdxMap;
        std::vector<DdlGenBuildInfo*>      genDdlTab;

        ddlGenAction.m_bInitEntityOnly = true;

        ddlGenAction.m_entitySqlnameStr.clear();

        gblRet = DBA_BuildAllDdlObject(ddlGenAction,
                                       ddlGenContext,
                                       xdEntityIdxMap,
                                       genDdlTab,
                                       mp);
    }
    else if (ddlGenAction.m_ddlObjNatEn == DbObjDdlObjNat_OnlineHelpDocument)
    {
        DdlGenDbaAccessGuard ddlGenDbaAccessGuard(ddlGenContext);

        ddlGenDbaAccessGuard.getDdlGenDbaAccess().loadMetaDict();
        ddlGenDbaAccessGuard.getDdlGenDbaAccess().loadExtended();

        ddlGenDbaAccessGuard.getDdlGenDbaAccess().loadHelpDoc();

        std::map<std::string, DdlGenBuildInfo*> xdEntityIdxMap;
        std::vector<DdlGenBuildInfo*>      genDdlTab;

        ret = DBA_BuildAllDdlObject(ddlGenAction,
            ddlGenContext,
            xdEntityIdxMap,
            genDdlTab,
            mp);

        if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
        {
            gblRet = ret;
        }

        ret = ddlGenDbaAccessGuard.getDdlGenDbaAccess().flushData();

        if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
        {
            gblRet = ret;
        }
    }
    else if (ddlGenAction.m_ddlObjNatEn == DbObjDdlObjNat_Label)
    {
        DdlGenDbaAccessGuard ddlGenDbaAccessGuard(ddlGenContext);

        ddlGenDbaAccessGuard.getDdlGenDbaAccess().loadMetaDict();
        ddlGenDbaAccessGuard.getDdlGenDbaAccess().loadExtended();

        if (ddlGenAction.m_bSingleEntity == false)
        {
            ddlGenDbaAccessGuard.getDdlGenDbaAccess().cleanUpDictLabels();
        }

        ddlGenDbaAccessGuard.getDdlGenDbaAccess().loadLabels();

        std::map<std::string, DdlGenBuildInfo*> xdEntityIdxMap;
        std::vector<DdlGenBuildInfo*>      genDdlTab;

        ret = DBA_BuildAllDdlObject(ddlGenAction,
                                       ddlGenContext,
                                       xdEntityIdxMap,
                                       genDdlTab,
                                       mp);

        if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
        {
            gblRet = ret;
        }

        ddlGenDbaAccessGuard.getDdlGenDbaAccess().processLabels();

        ret = ddlGenDbaAccessGuard.getDdlGenDbaAccess().flushData();

        if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
        {
            gblRet = ret;
        }
    }
    else
    {
        if (ddlGenAction.m_installLevel >= 5 &&
            ddlGenAction.m_installLevel < 9 &&
            ddlGenContext.optimLevelEn != DdlGenContext::OptimLevel::Full &&
            ddlGenAction.m_ddlObjNatEn == DbObjDdlObjNat_StoredProc &&
            ddlGenAction.m_execModeEn != DbObjExecMod_BuildFilesOnly)
        {
            DBA_InitCreateTempTables();
        }

        if (objectEn == NullEntity)
        {
            std::map<std::string, DdlGenBuildInfo*> xdEntityIdxMap;
            std::vector<DdlGenBuildInfo*>      genDdlTab;

            ddlGenAction.m_entitySqlnameStr = grpEntityStr;

            if (ddlGenAction.m_bExtractData)
            {
                DDL_CopyCustoData(ddlGenContext);
            }

            gblRet = DBA_BuildAllDdlObject(ddlGenAction,
                                           ddlGenContext,
                                           xdEntityIdxMap,
                                           genDdlTab,
                                           mp);

            if (ddlGenAction.m_ddlObjNatEn == DbObjDdlObjNat_StoredProc)
            {
                ret = DBA_CheckProcLst();
            }
        }
        else if (dictEntityStp != NULL)
        {
            DdlGenBuildInfo ddlGenBuildInfo(ddlGenContext);
            DdlGenAction    saveDdlGenAction(ddlGenContext.ddlGenAction, true);

            DBA_DYNFLD_STP   shXdEntityStp = mp.allocDynst(FILEINFO, S_XdEntity);
            SET_SYSNAME(shXdEntityStp, S_XdEntity_SqlName, dictEntityStp->mdSqlName);
            SET_ENUM(shXdEntityStp, S_XdEntity_XdActionEn, XdAction_ToInsert);

            ddlGenContext.ddlGenAction.m_entitySqlnameStr = dictEntityStp->mdSqlName;
            ddlGenContext.ddlGenAction.m_subRequest = ddlGenAction.m_subRequest;

            ddlGenContext.setMsgObjType(ddlGenAction.getDdlObjNatStr());
            ddlGenContext.setMsgEntitySqlName(dictEntityStp->mdSqlName);

            ddlGenBuildInfo.setShXdEntityStp(shXdEntityStp);
            ddlGenBuildInfo.ddlGenFullTable = new DdlGenFullTable(ddlGenBuildInfo.m_ddlGenContextPtr->ddlGenAction, ddlGenContext);
            ddlGenBuildInfo.retCode = RET_SUCCEED;
            ddlGenBuildInfo.setDictEntityStp(dictEntityStp);

            if (dictEntityStp->bIsInitEntity == true &&
                ddlGenContext.bGenFromDbi == false &&
                ddlGenAction.m_ddlObjNatEn == DbObjDdlObjNat_StoredProc)
            {
                ddlGenAction.m_bSystemFuncOnly = true;
                ret = DDL_BuildOneDdlObject(ddlGenAction,
                                                ddlGenBuildInfo,
                                                nullptr);
                ddlGenAction.m_bSystemFuncOnly = false;

                if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
                {
                    gblRet = ret;
                }
            }

            // ThreadPool *ddlGenThreadPoolPtr = new ThreadPool();
            ThreadPool* ddlGenThreadPoolPtr = nullptr;

            if (ddlGenThreadPoolPtr != nullptr)
            {
                ddlGenThreadPoolPtr->setStackSize(SYS_GetStackSize());
                ddlGenThreadPoolPtr->setThreadParallelSize(ddlGenAction.m_multiThreadSize);
            }

            /* Build one */
            ret = DDL_BuildOneDdlObject(ddlGenAction,
                                        ddlGenBuildInfo,
                                        nullptr);

            if (ddlGenAction.m_ddlObjNatEn == DbObjDdlObjNat_StoredProc)
            {
                std::vector<DdlGenBuildInfo *> genDdlTab;
                genDdlTab.push_back(&ddlGenBuildInfo);

                ret = DDL_BuildInvalidSproc(ddlGenContext, genDdlTab);

                if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
                {
                    gblRet = ret;
                }
            }
        }

        if (RET_GET_LEVEL(gblRet) != RET_LEV_ERROR &&
            ret != RET_GEN_ERR_NOACTION)
        {
            if (ddlGenAction.m_ddlObjNatEn == DbObjDdlObjNat_StoredProc &&
                ddlGenAction.m_installLevel < 9 &&
                ddlGenAction.m_subRequest == false)
            {
                ret = ddlGenContext.saveStoredProcInfo();
                if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
                {
                    gblRet = ret;
                }

                if (objectEn != NullEntity)
                {
                    ret = DBA_CheckProcLst(objectEn);
                    if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
                    {
                        gblRet = ret;
                    }
                }
            }
        }
    }

    if (ddlGenAction.m_subRequest == false)
    {
        {
            CurrentTime now(CurrentTime::Kind::CurrentUs);    /* Get Date and Time informations */
            gblMsg.printMsg(RET_DBA_INFO_EXIST, SYS_Stringer("End Date : ", now.formatYYYYMMDDSPHMSUS()));
        }

        if (RET_GET_LEVEL(gblRet) != RET_LEV_ERROR)
        {
            gblMsg.printMsg(RET_SUCCEED, "Applying modifications on tables successful");
        }
        else
        {
            std::cerr << " Failed" << std::endl;
            gblMsg.printMsg(gblRet, "Applying modifications on tables failed (see $AAAHOME/msg/log file or Standard error stream)");
        }
    }

    if (SYS_IsDdlGenMode() == TRUE &&
        ddlGenAction.m_subRequest == false)
    {
        std::cout << std::endl;
    }

    return gblRet;
}

/*************************************************************************
**   END  ddlgen01.c                                            Odyssey **
*************************************************************************/
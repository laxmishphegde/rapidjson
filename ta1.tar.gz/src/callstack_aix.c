/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**  callstack_aix.c
**  Produce a stack trace for AIX systems.
************************************************************************/

/************************************************************************
**      Include files
*************************************************************************/
#include <string>
#include <set>

#include <unistd.h>
#include <string.h>
#include <stdlib.h>

#include <pthread.h>

#ifdef __open_xl__
#include <cxxabi.h>
#else

#if __cplusplus < 201402L
#include <demangle.h>
#else
#include <ibmdemangle.h>
#endif

#endif
#include "syslib.h"

// AIX is too poor to have an include file for that
extern "C" void mt__trce( int, int, struct sigcontext *, int);

/*******************************************************************************
**      Global variables
*******************************************************************************/

static std::set<std::string> SV_SetBannedFunction;

/************************************************************************
**
**  Function    :   OS_InitializationCallStack()
**
**  Description :   This create a set of function to not display on the callstack to have a "light" stack trace 
**
**  Arguments   :
**
**
**  Return      :
**
**  Last modif. :  PMSTA-22000 - 231215 - PMO : Finish, test and integrate the stack trace on Windows
**
*************************************************************************/
void OS_InitializationCallStack()
{
    SV_SetBannedFunction.insert("getcallstackCpp");
    SV_SetBannedFunction.insert("getcallstack");
    SV_SetBannedFunction.insert("OS_GetCallStack");
    SV_SetBannedFunction.insert("SYS_GetCallStack");
    SV_SetBannedFunction.insert("ct__api_call_cb");
    SV_SetBannedFunction.insert("np_abortchk_io");
    SV_SetBannedFunction.insert("np_io_read");
    SV_SetBannedFunction.insert("ct__tds_recvpkt");
    SV_SetBannedFunction.insert("ct__tds_get_bytes");
    SV_SetBannedFunction.insert("ct__tds_read_token");
    SV_SetBannedFunction.insert("ct__tds_resproc");
    SV_SetBannedFunction.insert("ct__chkpt_results");
    SV_SetBannedFunction.insert("ct_async_exec_stack");
    SV_SetBannedFunction.insert("ct__api_async");
    SV_SetBannedFunction.insert("srv__exechandler");
    SV_SetBannedFunction.insert("srv__runclient");
    SV_SetBannedFunction.insert("srv__start_function");
    SV_SetBannedFunction.insert("_pthread_body");
}


/************************************************************************
**
**  Function    :   OS_RemoveCallStack()
**
**  Description :   Memory cleanup
**
**  Arguments   :
**
**
**  Return      :
**
**  Last modif. :   PMSTA-25852 - 110117 - PMO : Integrate getcallstack as a standard TripleA library
**
*************************************************************************/
void OS_RemoveCallStack()
{
    SV_SetBannedFunction.clear();
}


/************************************************************************
**
**  Function    :   moveAddressToLeft()
**
**  Description :   Move the address of function to left
**                  The line:
**                    main : 0x0000006c
**                  Become:
**                    0x0000006c : main
**
**  Arguments   :   callstack  Current call stack
**
**  Return      :   None
**
**  Last modif. :   PMSTA-21983 - 181215 - PMO : Finish, test and integrate the stack trace on AIX
**
*************************************************************************/
void moveAddressToLeft(std::string & callstack, const bool printAddress)
{
    std::string line;           // Current line
    std::string newCallstack;   // New call stack
    size_t      posLeft  = 0;   // Begin of the line
    size_t      posRight = 0;   // End of line

    while (std::string::npos != (posRight = callstack.find("\n", posLeft)))
    {
        line = callstack.substr(posLeft, posRight - posLeft);

        // Look for the address separator
        size_t addrTag = line.rfind(" : 0x");

        if (std::string::npos != addrTag)
        {
            addrTag += 3; // Skip " : "
	    std::string newLine;
            if(printAddress)
	    {
                newLine = line.substr(addrTag, line.length() - addrTag);
                newLine += " : ";
            }
            newLine += line.substr(0, addrTag - 3);

            newCallstack += newLine;
        }
        else
        {
            newCallstack += line;
        }

        newCallstack += "\n";

        posLeft = posRight + 1;
    }

    if (newCallstack.length() > 0)
    {
        callstack = newCallstack;
    }
}


/************************************************************************
**
**  Function    :   demangling()
**
**  Description :   Move the address of function to left
**                  The line:
**                    main : 0x0000006c
**                  Become:
**                    0x0000006c : main
**
**  Arguments   :   callstack  Current call stack
**
**  Return      :   None
**
**  Last modif. :   PMSTA-21983 - 181215 - PMO : Finish, test and integrate the stack trace on AIX
**
*************************************************************************/
void demangling(std::string & callstack)
{
    std::string line;
    std::string newCallstack;
    size_t      posLeft  = 0;
    size_t      posRight = 0;

    while (std::string::npos != (posRight = callstack.find("\n", posLeft)))
    {
        line = callstack.substr(posLeft, posRight - posLeft);

        // Look for the address separator
        size_t      addrTag         = line.rfind(" : ");
        std::string newLine;
        bool        bannedFunction  = false;

        if (std::string::npos != addrTag)
        {
            char *      rest;
            std::string function = line.substr(0, addrTag);
            std::string functName;
#ifdef __open_xl__
            int status = 0;
            char * functionNameDemangled = abi::__cxa_demangle(function.c_str(), nullptr, nullptr, &status);

            if (nullptr != functionNameDemangled)
            {
                std::string functionDemangled = functionNameDemangled;

                free(functionNameDemangled);

                { // Remove [abi:cxx11] if any
                    size_t beginTag = functionDemangled.find("[abi:cxx11]");

                    if (std::string::npos != beginTag)
                    {
                        functionDemangled.erase(beginTag, 11); // 11 is "[abi:cxx11]"
                    }
                }

                functName = functionDemangled;

#else
            Name *      name     = demangle((char *)function.c_str(), &rest, RegularNames);    // Badly documented. delete or free of name and rest lead to crash.
            if (NULL != name)
            { // Demangled function
                char * fn = functionName(name);
                functName = fn;

                { // Remove argument(s): "MSG_SendMesg(int, int, char const*, int, ...)" -> "MSG_SendMesg"
                    size_t endTag = functName.rfind("(");

                    if (std::string::npos != endTag)
                    {
                        functName.erase(endTag, functName.length() - endTag);
                    }
                }
#endif

                // Look for a banned function
                std::set<std::string>::iterator it = SV_SetBannedFunction.find(functName);
                bannedFunction = it != SV_SetBannedFunction.end();

                if (false == bannedFunction)
                {
                    newLine = functName;
                }
            }
            else
            { // No processing

                // Look for a banned function
                std::set<std::string>::iterator it = SV_SetBannedFunction.find(function);
                bannedFunction = it != SV_SetBannedFunction.end();

                if (false == bannedFunction)
                {
                    newLine = function;
                }
            }

            if (false == bannedFunction)
            {
                newLine      += line.substr(addrTag, line.length() - addrTag);
                newLine      += "\n";
                newCallstack += newLine;
            }
        }

        posLeft = posRight + 1;
    }

    if (newCallstack.length() > 0)
    {
        callstack = newCallstack;
    }
}


/************************************************************************
**
**  Function    :   getcallstack()
**
**  Description :   function walks up call stack,once for each stack frame
**
**  Arguments   :   binaryDebug  bool    If the binary is compiled in debug mode
**
**  Return      :   NULL    Malloc Failed
**                  Pointer on a buffer that contain the stacktrace and that can be freed with free
**
**  Last modif. :   PMSTA-21983 - 181215 - PMO : Finish, test and integrate the stack trace on AIX
**                  PMSTA-25793 - 281216 - PMO : Dispatcher might crash on AIX into putProperty
**
*************************************************************************/
char * OS_GetCallStack(const bool printAddress)              /* PMSTA-25793 - 281216 - PMO */
{
    pthread_t   self = pthread_self();

    std::string fileName = std::string("stacktrace_")
                         + SYS_ToString(getpid())
                         + std::string("_")
                         + SYS_ToString(self)
                         + std::string(".log");
    int         fd       = open(fileName.c_str(), O_RDWR|O_CREAT|O_APPEND, 0600);
    ssize_t     status   = 0;
    std::string callstack;

    if (fd >= 0)
    {
        mt__trce(fd, 0, NULL, 0);

        const off_t length = lseek(fd, 0, SEEK_CUR);

        callstack.reserve(length + 1);
        callstack.resize(length);

        (void)lseek(fd, 0, SEEK_SET);
        status = read(fd, &callstack[0], length);

        close(fd);
    }

    if (status > 0)
    {
        int tid  = 0;

        if (0 ==  pthread_getunique_np(&self, &tid))
        {
            std::string threadSeq = std::string(" Thread ") + SYS_ToString(tid) + std::string("\n");

            { // Keep only thread data

                { // Remove data before
                    size_t beginTag = callstack.find(threadSeq);

                    if (std::string::npos != beginTag)
                    {
                        callstack.erase(0, beginTag + 2); /* 2 for # and \n */
                    }
                }
                { // Remove data after
                    size_t endTag = callstack.rfind(threadSeq);

                    if (std::string::npos != endTag)
                    {
                        callstack.erase(endTag, callstack.length() - endTag);
                    }
                }
                {   // Remove useless header:

                    size_t beginTag = callstack.find("STACK");

                    if (std::string::npos != beginTag)
                    {
                        callstack.erase(0, beginTag + 6); /* 5 for STACK and \n */
                    }
                }
                { // Remove useless footer
                    size_t endTag = callstack.rfind("STACK");

                    if (std::string::npos != endTag)
                    {
                        callstack.erase(endTag - 4, callstack.length() - endTag + 4);
                    }
                }
            }
        }

        callstack += "\n";

        demangling(callstack);
        moveAddressToLeft(callstack, printAddress);
    }

    unlink(fileName.c_str());

    return strdup(callstack.c_str());                       /* PMSTA-25793 - 281216 - PMO */
}


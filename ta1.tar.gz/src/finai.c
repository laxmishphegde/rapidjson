/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines      
*************************************************************************/
#define FINAI_C

/************************************************************************
**      Include files
*************************************************************************/
#define STDIO_H
#define STRING_H
#define TIME_H
#define STDLIB_H
#define MATH_H

#include "unidef.h"     /* Mandatory */
#include "gen.h"
#include "date.h"
#include "dba.h"
#include "syslib.h"     /* PMO - Rename our sys.h to syslib.h and use it */
#include "tls.h"
#include "hier.h"
#include "fin.h"
#include "scptyl.h"     /* REF1457 */
#include "scelib.h"     /* REF1055 - AKO - 000214 */
#include "sce.h"

/************************************************************************
**      External entry points
**
**  FIN_AccrInter() 		    Returns the instrument interest. 
**  FIN_ComputeInterFloatRate()	Compute floating rate condition value. 
**  FIN_PeriodUnitAccrInter()	Compute a period unitary interest.
**  FIN_SearchInterRate() 	    Retrieve the interest rates applicable over the accrual period. 
**  FIN_UnitAccrInter() 	    Compute unitary accrued interest.
**
*************************************************************************/

/************************************************************************
**      Local functions
**
**  FIN_CalcUnitAccrInter() 	Having obtained the rate and quantity structure, compute AI.
**  FIN_CompoundInter()		    Compute compounded interest.
**  FIN_GetBegAccrPeriod()	    Returns the date from which interest has been accruing.
**  FIN_SearchBegAccrPeriod()	Search the date from which interest has been accruing.
**  FIN_SearchCurrentIncEvt()	Search income event applicable at the reference date.
**  FIN_SearchFirstAccrDate() 	Determine date from which interest has been accruing 
**  FIN_TaxRateUnitAccrInter() 	Compute tax rate on unitary accrued interest.
**  FIN_AccrVal() 		        Returns the instrument interest compoted with accrued valuation method.
** 
*************************************************************************/

/************************************************************************
**      Static definitions & data
*************************************************************************/

#define FIN_REALLOC 5

/**** INTERNAL STRUCTURES ****/

/**** ACCRUAL PERIOD INFORMATIONS ****/
typedef struct {
        DATE_T              fromDate;         /* accrual period begin date     */
        ID_T                currId;           /* currency identifier           */
        EXCHANGE_T          fxdExch;          /* exchange rate                 */
        PERIOD_T            payFreq;          /* payment frequency in month    */
        ACCRRULE_ENUM       accrRule;         /* date difference rule          */
        DATE_T              workDate;         /* working date (payment date)   */
        DATE_T              exDate;           /* ex date                       */
        DATE_T              lastPayDate;      /* last payment date             */
        DATE_T              firstCoupDate;    /* first period can be different */
	    FLAG_T	            fixedDateFlg;	  /* REF1079 - TRUE if from date is fixed */
        ACCRINTERMETHOD_ENUM    accrInterMethod; /* accrued interests calculation method - REF7265 */
        /*DATE_T              accrValFromDate;  * from date for accrued valuation method - REF7265 */    
} FIN_ACCR_PERIOD_ST, *FIN_ACCR_PERIOD_STP;

/**** INTEREST QUANTITY INFORMATIONS ****/
typedef struct {
        DATE_T     fromDate;            /* quantity begin date */
        DATE_T     tillDate;            /* quantity end date   */
        AMOUNT_T   quant;               /* quantity            */
} FIN_QUANT_INFO_ST, *FIN_QUANT_INFO_STP;

typedef struct {
        int                quantNbr;    /* number of quantities */
        FIN_QUANT_INFO_STP infoPtr;     /* quantities array     */
} FIN_QUANT_ST, *FIN_QUANT_STP;

STATIC RET_CODE FIN_GetBegAccrPeriod(DATETIME_T, FUSDATERULE_ENUM, char, DBA_DYNFLD_STP, 
				                    DBA_DYNFLD_STP, FIN_ACCR_PERIOD_STP, DBA_HIER_HEAD_STP, FIN_AIARG_STP), /* PMSTA08308 - 090609 - PMO / REF7265 - YST - 020315 - add hierHead */
		        FIN_SearchBegAccrPeriod(DATETIME_T, FUSDATERULE_ENUM, char, DBA_DYNFLD_STP, 
			                            FIN_ACCR_PERIOD_STP, DBA_HIER_HEAD_STP), /* REF7265 - YST - 020315 - add hierHead */
		        FIN_SearchCurrentIncEvt(DATETIME_T, FUSDATERULE_ENUM, char, DBA_DYNFLD_STP, 
			                            DBA_DYNFLD_STP, FIN_ACCR_PERIOD_STP, DBA_HIER_HEAD_STP), /* REF7265 - YST - 020315 - add hierHead */
		        FIN_SearchFirstAccrDate(DATETIME_T, char, FIN_ACCR_PERIOD_STP, DBA_DYNFLD_STP = NULLDYNST, DBA_HIER_HEAD_STP = NULLDYNST),
                FIN_SearchFirstAccrDateBusDay(DBA_DYNFLD_STP, DATETIME_T, char, FIN_ACCR_PERIOD_STP, DBA_HIER_HEAD_STP = NULLDYNST), /* REF7287 - YST - 020128 */
                FIN_AccrVal(DATETIME_T, ID_T, DBA_DYNFLD_STP, ID_T, FIN_AIARG_STP, DBA_DYNFLD_STP, 
                            FIN_MKTVAL_STP, DBA_DYNFLD_STP *, int, FLAG_T, DBA_HIER_HEAD_STP); /* REF 7265 - YST - 020226 */

STATIC FLAG_T	FIN_CalcUnitAccrInter(FIN_ACCR_PERIOD_STP, FIN_INTERRATE_STP, FIN_QUANT_STP, 
				                        NUMBER_T*, DATE_T, DATE_T, DBA_DYNFLD_STP, DBA_DYNFLD_STP,
										DBA_HIER_HEAD_STP, /* REF5937 - AKO - 010608 : add hierHead */ 
										DBA_DYNFLD_STP, FLAG_T *); /* PMSTA1512-CHU-070430 : added posPtr */

STATIC void	    FIN_TaxRateUnitAccrInter(NUMBER_T*, DBA_DYNFLD_STP);

/************************************************************************
**      Functions
*************************************************************************/


/************************************************************************
**
**  Function    :   FIN_AccrInter()
**
**  Description :   This function returns the interest in the accrued interest 
**                  currency and in the reference currency according to the 
**                  input quantity. It uses the "calculation of unitary accrued
**                  interest function". This unitary amount may be adjusted by 
**                  a tax reate. It is then multipled by a quantity and 
**                  converted into the reference currency.
**                  
**  Arguments   :   refDateTime     reference date
**                  instrId         instrument identification
**                  inputInstrPtr   pointer on instrument structure or NULL
**                  refCurrId       reference currency identification
**                  fusDateRule     fusion date rule 
**                  fullCoupFlg     parameter which determine if accrued 
**                                  interest on the first interest accrual date 
**                                  is equal to 0 or to a full interest period.
**                  calcAccrInterFlg  flag which is TRUE if interest 
**                                  must be calculated, FALSE if stored data 
**                                  can be used.
**                  txdInterFlg     flag which indicates wheter he process should
**                                  return after tax accrued interest
**                  qty             quantity of instrument to be valued
**                  mktPtr          pointer on net value structure to fill 
**                                  (accrued interest informations only)
**                  accrInterMethod Enum which defines the method to use to compute accrued interests
**                  accrValBegDate  date from which interests accrues 
**                                  (!!! only used for method AccrInterMethod_AccrVal !!!)
**
**  Return      :   RET_SUCCEED or error code
**                  values of structure mktPtr will be modified, it will be 
**                  - accrInterRefCurr interest in reference currency 
**                  - accrInter        interest in accrued interest currency
**                  - accrInterCurrId  accrued interest currency identifier
**                  - accrInterPeriod  accrued interest days (num, denom) 
**                  - accrInterRefExch exchange rate between accrued interest
**                  All field are initialised to 0 or NULL 
**
** Modif : DVP081 - RAK - 960603
**         DVP125 - RAK - 960620
**         BUG053 - RAK - 960709
**         BUG058 - RAK - 960711
**         BUG193 - RAK - 961105
**         DVP308 - RAK - 961213
**         BUG376 - RAK - 970522
**         DVP125+- GRD - 970710
**         REF1079 - RAK - 971219
**         REF1210 - RAK - 980128
**         REF1457 - RAK/DDV - 980324
**  	   REF2313 - RAK - 980910
**  	   REF2580 - SSO - 980727
**	       REF3779 - RAK - 990701
** Modif : REF5248 - RAK - 001005
** Modif : REF7265 - YST - 020312
** Modif : REF7251 - YST - 020501
**         REF11218 - TEB - 050627
**         REF11163 - TEB - 050713
**         PMSTA-1512 - 4.20.2.2 - Money Market & Bond Fund Accruals (US market)
**         PMSTA08308 - 090609 - PMO : Calculation of accrued interests on cash account is wrong after closing a futures' contract
**         PMSTA-18314 - 010714 - PMO : New Reference Nature "Reference Code": Accrued Interests are not calculated for MM position
**         PMSTA-25190 - 061116 - PMO : Fixes of some errors founded by AddressSanitizer
**
*************************************************************************/
RET_CODE FIN_AccrInter(DATETIME_T               refDateTime, 
		                ID_T                    instrId, 
		                DBA_DYNFLD_STP          inputInstrPtr, 
		                ID_T                    refCurrId, 
		                FIN_AIARG_STP           aiArgStp,
		                NUMBER_T                qty, 
		                DBA_DYNFLD_STP          posPtr, /* DVP125 - RAK - 960620 */
		                FIN_MKTVAL_STP          mktPtr,
                        DBA_HIER_HEAD_STP       hierHead) 
{
	DBA_DYNFLD_STP  unitAccrInter=NULL, instrPtr=NULL, posValPtr=NULL, *posAccrVal=NULL;
	RNDRULE_ENUM    rndRuleEn;
	RNDUNIT_ENUM    rndUnitEn;
	INSTRNAT_ENUM   instrNat;
	SUBNAT_ENUM		instrSubNat;
	FLAG_T          allocOk;
	char            calcAccrInterFlg=aiArgStp->calcAccrInterFlg;
	RET_CODE        ret;
	DBA_DYNFLD_ST   scptResult;
	FIN_EXCHARG_ST  exchArgSt;			/* REF2313 */
	FLAG_T		    applUnitAccrIntAllDecFlag=FALSE; /* REF3779 - RAK - 990701 */
	FLAG_T			is_MM_or_FI_FundShareFlg = FALSE; /* PMSTA01512-CHU-070430 */
	ID_T			calendarId = 0; 				  /* PMSTA-22396  - SRIDHARA � 160430 */
    DATETIME_T      lastCouponBeginDate, lastCouponEndDate;     /* PMSTA-37777 - Silpakal - 191106 */
	bool TapComputesIntAccr = true; /*PMSTA-42064-ARUN-08102020*/
    EXCHANGE_T accrInterExchg = 0.0;

    memset(&lastCouponBeginDate, 0, sizeof(DATETIME_T));
    memset(&lastCouponEndDate, 0, sizeof(DATETIME_T));
 
    /* REF7265 - YST - 020312 - different method for computing accrued interest */
    if (aiArgStp->accrInterMethod == AccrInterMethod_AccrVal)
    {
        return(FIN_AccrVal(refDateTime, instrId, inputInstrPtr, refCurrId, aiArgStp,
                            posPtr, mktPtr, posAccrVal, 0, TRUE, hierHead));
    }

    /* normal method for computing accrued interest */
    else 
    {
    memset(&exchArgSt, 0, sizeof(FIN_EXCHARG_ST));	/* REF2313 */
	/*DBA_SetConnectNoToExchArg(&exchArgSt, DBA_GetConnectNoFromHier(hierHead));*/ /* REF2580 - SSO - 980727 */
	DBA_InitConnectNoToExchArg(&exchArgSt, hierHead); /* REF4213 - SSO - 991221 */

	/* REF3779 - RAK - 990701 - In case of TRUE, don't truncate to 9th decimal */
	GEN_GetApplInfo(ApplUnitAccrIntAllDecFlag, &applUnitAccrIntAllDecFlag);

	/* Init at null values */
	mktPtr->accrInter             = 0.0; 
	mktPtr->accrInterRefCurr      = 0.0;
	mktPtr->accrInterCurrId       = 0;
	mktPtr->accrInterPeriod.num   = 0;
	mktPtr->accrInterPeriod.denom = 0;
	mktPtr->accrInterRefExch      = 0.0;

	/* PMSTA07849 - LJE - 090204 */
	memset(&scptResult, 0, sizeof(DBA_DYNFLD_ST));

    /* REF1457 - DDV - 980324 */
	/* Developer Information Not Obsolete Serious And Useful Recommendation � DINOSAUR � KRA � 110831 */
	/* in case of customer doesn't agree with our way to compute AI he can write his specific script to do it better */
     if (posPtr != NULL &&
         GET_EXTENSION_PTR(posPtr, ExtPos_PosVal_Ext) != NULL &&
         (posValPtr = *(GET_EXTENSION_PTR(posPtr, ExtPos_PosVal_Ext))) != NULL &&
         aiArgStp->scptAIStp != (PTR)NULL)
     {
         COPY_DYNFLD(posValPtr, PosVal, PosVal_ExtPosId,
             posPtr, ExtPos, ExtPos_Id);

         if (SCPT_ExecScptTree((SCPT_ARG_STP)aiArgStp->scptAIStp,
             DBA_GetDomainPtr(DBA_GetConnectNoFromHier((DBA_HIER_HEAD_STP)hierHead)), /* REF2580 - SSO - 980727 */
             hierHead,
             posValPtr,
             NumberType,
             &scptResult,
             posPtr) == RET_SUCCEED) /* PMSTA14443 - DDV - 120709 */
         {
             mktPtr->accrInterRefCurr = GET_NUMBER((&scptResult), 0);
             TapComputesIntAccr = false;/*PMSTA-42064-ARUN-08102020*/
             /*Instead of retruning from here , let the TAP compute the other mkt val attributes such as accr in number period and denom period*/
         }
     }

    /**** LOAD INSTRUMENT ****/ /* DVP081 - RAK - 960603 */
	/* If instrument structure was load upper, his pointer is given */
	/* in parameters list. So function use it and don't free it.    */
	if (inputInstrPtr != NULL)
	{
		instrPtr = inputInstrPtr;
		allocOk = FALSE;
	}
	else
	{
        /* REF3913 - 990820 - DDV */
        if ((ret = DBA_GetInstrById(instrId, FALSE, &allocOk, 
                                    &instrPtr, hierHead, UNUSED, UNUSED)) != RET_SUCCEED)
        {
   			return(ret); 
		}
	}

	instrNat = (INSTRNAT_ENUM) GET_ENUM(instrPtr, A_Instr_NatEn);

	/* PMSTA01512-CHU-070430 */
	instrSubNat = (SUBNAT_ENUM) GET_ENUM(instrPtr, A_Instr_SubNatEn);
	is_MM_or_FI_FundShareFlg = (FLAG_T) (instrNat == InstrNat_FundShare  &&
									(instrSubNat == SubNat_MoneyMarketFundShare ||
									 instrSubNat == SubNat_FixedIncomeFundShare));

	/* REF11218 - TEB - 050627 */
	/* If nature different of Bond or Convert Bond only use accrual rule of instrument */
	if (instrNat != InstrNat_Bond && instrNat != InstrNat_ConvertBond)
	{
		if (is_MM_or_FI_FundShareFlg == FALSE)
			aiArgStp->accrRule = (ACCRRULE_ENUM) AccrRule_None;
		else
			aiArgStp->accrRule = (ACCRRULE_ENUM) AccrRule_Actual_365;
	}

	/* No accrued interest in instrument for non treated money market: so do now */
	if (instrNat == InstrNat_Discount || instrNat == InstrNat_MoneyMkt)
	{
	    if (GET_ID(instrPtr, A_Instr_Id) > 0)
	    {
		    DATETIME_T tmpDate;

		    /* REF1210 - Use position only fon generic and incompleted generic */
		    if ((GET_FLAG(instrPtr, A_Instr_GenericFlg) == TRUE ||
		        (GET_FLAG(instrPtr, A_Instr_GenericFlg) == FALSE &&
		        IS_NULLFLD(instrPtr, A_Instr_BeginDate) == TRUE)) && posPtr == NULL)
		    {
		        if (allocOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
		        return(RET_SUCCEED); 
		    }

		    if (GET_FLAG(instrPtr, A_Instr_GenericFlg) == TRUE)
		    {
		        /* BUG376 - RAK - 970522 */
                /* REF7251 - YST - 020501 - copy ExtPos_Rate only if no IRC table is defined */
		        if (IS_NULLFLD(posPtr, ExtPos_Rate) == FALSE && 
                    (INTERCD_ENUM)GET_ENUM(instrPtr, A_Instr_InterestCdEn) == InterCd_Instr)
		        {
                    /* REF7251 - YST - 020501 */
			        if ((SUBNAT_ENUM)GET_ENUM(instrPtr, A_Instr_SubNatEn) == SubNat_AvrgRate ||
                        IS_NULLFLD(instrPtr, A_Instr_FloatInstrId) != TRUE)
			        {
			            SET_PERCENT(instrPtr, A_Instr_AddMarginP, GET_PERCENT(posPtr, ExtPos_Rate)); 
			        }
                    else
                    {
	                    SET_PERCENT(instrPtr, A_Instr_InterestRateP, GET_PERCENT(posPtr, ExtPos_Rate)); 
		                /* SET_ENUM(instrPtr, A_Instr_InterestCdEn, (ENUM_T) InterCd_Instr);*/ /* REF7251 - YST - 020501 */
                    }
		        }

		        AMOUNT_T uAInter = ZERO_AMOUNT;

                if (0. != GET_NUMBER(posPtr, ExtPos_Qty))   /* Avoid division by 0 PMSTA-25190 - 061116 - PMO */
                {        
		            uAInter = GET_AMOUNT(posPtr, ExtPos_AccrAmt) / GET_NUMBER(posPtr, ExtPos_Qty);
                }

		        SET_NUMBER(instrPtr, A_Instr_UnitAccrInter, CAST_NUMBER(uAInter)); /* REF3288 - SSO - 990205 */

	    	    /* New end date */
		        if (IS_NULLFLD(posPtr, ExtPos_ExpirDate) == TRUE)
		        {
	    		    SET_DATE(instrPtr, A_Instr_EndDate, MAGIC_END_DATE);	/* BUG208 */
		        }
		        else
		        {     
	    		    tmpDate = GET_DATETIME(posPtr, ExtPos_ExpirDate);
	    		    SET_DATE(instrPtr, A_Instr_EndDate, tmpDate.date);
		        }

		        /* REF1210 - Update instrument begin date only for generic money market */
	    	    if (IS_NULLFLD(posPtr, ExtPos_ValDate) == TRUE)
		            tmpDate = GET_DATETIME(posPtr, ExtPos_BegDate);
	    	    else
		            tmpDate = GET_DATETIME(posPtr, ExtPos_ValDate);

	    	    SET_DATE(instrPtr, A_Instr_BeginDate, tmpDate.date);
		    }
		    /* REF1210 - Ensure that non-generic money market have begin date */
		    else if (IS_NULLFLD(instrPtr, A_Instr_BeginDate) == TRUE)	
		    {
	    	    if (IS_NULLFLD(posPtr, ExtPos_ValDate) == TRUE)
			        tmpDate = GET_DATETIME(posPtr, ExtPos_BegDate);
	    	    else
			        tmpDate = GET_DATETIME(posPtr, ExtPos_ValDate);

	    	    SET_DATE(instrPtr, A_Instr_BeginDate, tmpDate.date);
		    }
	    }
	}

	/* Accrued interest can't be compute without        */
	/* position information (accrAmt) for cash accounts */
	if (instrNat == InstrNat_CashAcct && posPtr == NULL)
	{
	    if (allocOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
	    return(RET_SUCCEED);
	}

	/* No accrued interest with position reference nature "none" or "open" */
	if (instrNat == InstrNat_CashAcct || 
	    instrNat == InstrNat_Discount || instrNat == InstrNat_MoneyMkt)
	{
	    if (posPtr != NULL)
	    {
		    if (GET_ENUM(posPtr, ExtPos_RefNatEn) != PosRefNat_None &&
		        GET_ENUM(posPtr, ExtPos_RefNatEn) != PosRefNat_Open &&
                GET_ENUM(posPtr, ExtPos_RefNatEn) != PosRefNat_ReferenceCode    &&  /* PMSTA-18314 - 010714 - PMO */
		        GET_ENUM(posPtr, ExtPos_RefNatEn) != PosRefNat_RepoOpen && /* DVP125+ - 970710 - GRD */
		        GET_ENUM(posPtr, ExtPos_RefNatEn) != PosRefNat_RemereOpen)
		    {
		        if (allocOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
		        return(RET_SUCCEED);
		    }
	    }
	}
	
	if (instrNat == InstrNat_CashAcct && calcAccrInterFlg == FALSE)
	{
	    DBA_DYNFLD_STP 	        instrChrono=NULL, dimChronoPtr=NULL;
	    ID_T		            getInstrId;
	    ACCRINTERCHRONO_ENUM    accrInterChronoEn;
        FLAG_T                  cashValueDateFlg;                       /*  FPL-PMSTA12114-110601   */
        GEN_GetApplInfo(ApplAccrInterChrono, &accrInterChronoEn);
        GEN_GetApplInfo(ApplFusionCashValueDateFlg, &cashValueDateFlg); /*  FPL-PMSTA12114-110601   */

		/* PMSTA-11089 - RAK - 101214 - Check that value date is before computing date */
	    if (accrInterChronoEn != AccrInterChrono_NeverStored && 
			((posPtr !=NULL && DATETIME_CMP(GET_DATETIME(posPtr,ExtPos_ValDate), GET_DATETIME(posPtr,ExtPos_ExtPosDate)) <= 0)
            ||
            (cashValueDateFlg == FALSE)))                              /*  FPL-PMSTA12114-110601   */ /* PMSTA17103 - DDV - 131101 - Condition change to avoid instr_chrono acess when parameter is NeverStored */
	    {
		    if (GET_FLAG(instrPtr, A_Instr_AccruedIntFlg) == FALSE)
		    {
			    if (allocOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
			    return(RET_SUCCEED);
		    }

		    if ((instrChrono = ALLOC_DYNST(A_InstrChrono)) == NULL)
		    {
			    if (allocOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
			    MSG_RETURN(RET_MEM_ERR_ALLOC);
		    }

	       	if (GET_ID(instrPtr, A_Instr_Id) < 0)
			    getInstrId = GET_ID(instrPtr, A_Instr_ParentInstrId);
	       	else
			    getInstrId = GET_ID(instrPtr, A_Instr_Id);

		    if ((dimChronoPtr = ALLOC_DYNST(Dim_InstrChrono)) == NULL)
		    {
			    FREE_DYNST(instrChrono, A_InstrChrono);
			    if (allocOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
			    MSG_RETURN(RET_MEM_ERR_ALLOC);
		    }

		    SET_ID(dimChronoPtr,       Dim_InstrChrono_InstrId,     getInstrId);
            if (aiArgStp->domainRefDateTime.date > 0)                                               /*  FPL-PMSTA12114-110601   */
            {
                SET_DATETIME(dimChronoPtr, Dim_InstrChrono_RefDate, aiArgStp->domainRefDateTime);   /*  FPL-PMSTA12114-110601   */
            }
            else
            {
		        SET_DATETIME(dimChronoPtr, Dim_InstrChrono_RefDate,     refDateTime);
            }
		    SET_ENUM(dimChronoPtr,     Dim_InstrChrono_NatEn,       ChronoNat_AccrInter);
		    SET_FLAG(dimChronoPtr,     Dim_InstrChrono_ComputeFlg,  FALSE);
		    SET_FLAG(dimChronoPtr,     Dim_InstrChrono_SubNatFlg,   FALSE); /* PMSTA12914 - DDV - 111010 - Set it to FALSE to avoid unmatching of input args in optimisation */

		    ret = FIN_InstrChrono(dimChronoPtr, instrPtr, instrChrono, hierHead);
		    FREE_DYNST(dimChronoPtr, Dim_InstrChrono);

		    if (ret == RET_SUCCEED)
		    {
			    DATE_PERIOD_ST      interPeriod;
			    FIN_ACCR_PERIOD_ST  accrPeriod;

			    memset(&accrPeriod, 0, sizeof(FIN_ACCR_PERIOD_ST));	/* REF1079 */

			    /* Days number in this period */
				/* REF11218 - TEB - 050627 */
				if (aiArgStp->accrRule == AccrRule_None)
				{
					accrPeriod.accrRule = (ACCRRULE_ENUM)GET_ENUM(instrPtr, A_Instr_AccrualRuleEn);
				}
				else
				{
					accrPeriod.accrRule = (ACCRRULE_ENUM) aiArgStp->accrRule;
				}

                /* REF7265 - YST - 020315 - add hierHead */
			    if ((ret = FIN_GetBegAccrPeriod(refDateTime, aiArgStp->fusDateRule, 
							                    aiArgStp->fullCoupFlg, instrPtr, posPtr, 
							                    &accrPeriod, hierHead, NULL)) != RET_SUCCEED)   /* PMSTA08308 - 090609 - PMO */
			    {
				    FREE_DYNST(instrChrono, A_InstrChrono);
				    if (allocOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
				    return(ret);  
			    }

				/* PMSTA-22396  - SRIDHARA � 160430 */
				DBA_GetCalendarFromInstr(instrPtr, &calendarId);
			    DATE_AccrPeriod(accrPeriod.fromDate, refDateTime.date, 
					            accrPeriod.accrRule, accrPeriod.payFreq, &interPeriod, calendarId);

				/* PMSTA-24603 - SRIDHARA � 160914 */
				if (IS_NULLFLD(instrChrono, A_InstrChrono_CurrId) == TRUE)
				{
					SET_ID(instrChrono, A_InstrChrono_CurrId, GET_ID(instrPtr, A_Instr_RefCurrId));
				}

			    mktPtr->accrInterCurrId       = GET_ID(instrChrono, A_InstrChrono_CurrId);
			    mktPtr->accrInterPeriod.num   = interPeriod.num;
			    mktPtr->accrInterPeriod.denom = interPeriod.denom;

			    /* calculate and apply tax rate */
			    if (aiArgStp->txdInterFlg == TRUE)
			    {
			        NUMBER_T unitAccrInterNbr = GET_NUMBER(unitAccrInter, UnitInter_UnitAccrInter);
			        FIN_TaxRateUnitAccrInter(&unitAccrInterNbr, instrPtr);

			        /* REF3779 - RAK - 990701 - In case of TRUE, don't truncate to 9th decimal */
			        if (applUnitAccrIntAllDecFlag == TRUE)
			        { SET_NUMBER(unitAccrInter, UnitInter_UnitAccrInter, unitAccrInterNbr);}
			        else
			        { SET_NUMBER(unitAccrInter, UnitInter_UnitAccrInter, CAST_NUMBER(unitAccrInterNbr));} /* REF3288 - SSO - 990205 */
			    }
	
				/*PMSTA-27729 - Smitha - 180115*/
				if (IS_NULLFLD(instrPtr, A_Instr_PtfId) == FALSE)
				{
					if (GET_FLAG(posPtr, ExtPos_AccrIntChronoFlg) == TRUE)
					{
						mktPtr->accrInter = GET_LONGAMOUNT(instrChrono, A_InstrChrono_Val);
					}
				}
				else
				{
					/*
					** TGU-REF11704-060413-Use GET_LONGAMOUNT since data type for field
					** instr_chrono.value_n has been changed from NUMBER to LONGAMOUNT.
					*/

					mktPtr->accrInter = GET_LONGAMOUNT(instrChrono, A_InstrChrono_Val);
				}

			    /* If accrued interest is not in reference currency, */
			    /* convert into the reference currency.              */
    if (TapComputesIntAccr == true) /*PMSTA-42064-ARUN-08102020*/
    {
            if (mktPtr->accrInterCurrId != refCurrId)
            {
                /* REF2313 */
                exchArgSt.srcAmt = mktPtr->accrInter;
                if ((ret = FIN_ExchAmt(refDateTime, mktPtr->accrInterCurrId,
                    refCurrId, 0, NULL, posPtr, &exchArgSt,
                    NULL,
                    &(mktPtr->accrInterRefCurr),
                    &(mktPtr->accrInterRefExch))) != RET_SUCCEED)	/* PMSTA01649 - TGU - 070405 */
                {
                    FREE_DYNST(instrChrono, A_InstrChrono);
                    if (allocOk == TRUE) { FREE_DYNST(instrPtr, A_Instr); }
                    return(ret);
                }
            }
            else
            {
                mktPtr->accrInterRefCurr = mktPtr->accrInter;
                mktPtr->accrInterRefExch = 1.0;
            }
    }
    else
    {
        /* let the  mktPtr->accrInterRefCurr be as per the default value script computation provided */
        if (mktPtr->accrInterCurrId != refCurrId)
        {
            exchArgSt.srcAmt = mktPtr->accrInterRefCurr;
            if ((ret = FIN_ExchAmt(refDateTime, refCurrId, mktPtr->accrInterCurrId,
                0, NULL, posPtr, &exchArgSt, NULL,
                &(mktPtr->accrInter),
                &accrInterExchg)) != RET_SUCCEED)
            {
                FREE_DYNST(unitAccrInter, UnitInter);
                if (allocOk == TRUE) { FREE_DYNST(instrPtr, A_Instr); }
                return(ret);
            }
            if (CMP_EXCHANGE(accrInterExchg, 0.0) != 0)
            {
                mktPtr->accrInterRefExch = 1 / accrInterExchg;
            }
        }
        else
        {
            mktPtr->accrInter = mktPtr->accrInterRefCurr;
            mktPtr->accrInterRefExch = 1.0;
        }
    }
       
			    FREE_DYNST(instrChrono, A_InstrChrono);
			    if (allocOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
			    return(RET_SUCCEED);                /* found and end */
		    }

		    FREE_DYNST(instrChrono, A_InstrChrono);	
	    }

	    calcAccrInterFlg = TRUE;	        /* Skip read chrono in UnitAccrInter() */
						                    /* in case of no AI in chrono or no chrono for */
						                    /* this instr (no succeed for FIN_InstrChrono) */
	}
	
	if ((unitAccrInter = ALLOC_DYNST(UnitInter)) == NULL)
	{
		if (allocOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
		MSG_RETURN(RET_MEM_ERR_ALLOC);
	}

	/* DVP125 - RAK - 960620 */
    /* REF7265 - YST - 020320 - add two new arguments */
	/* Developer Information Not Obsolete Serious And Useful Recommendation � DINOSAUR � KRA � 110831 */
	/* after some verification, let's go to the function which do something to compute AI */

    /*PMSTA-42064-ARUN-20102020*/
    if (TapComputesIntAccr == false)
    {
        SET_FLAG_FALSE(instrPtr, A_Instr_BoForcedAiFlg);
    }
	ret = FIN_UnitAccrInter(refDateTime, instrId, instrPtr, aiArgStp->fusDateRule, 
				            aiArgStp->fullCoupFlg, calcAccrInterFlg, AccrInterMethod_Default, refDateTime, 
							aiArgStp->accrRule, /* REF11218 - TEB - 050627 */
				            posPtr, unitAccrInter, hierHead, FALSE, aiArgStp); /* PMSTA08308 - 090609 - PMO / PMSTA05389-CHU-080131*/

	/* ?? */
	/* Stop in case of memory error only   */
	/* (no accrued interest isn't a error) */
    if (RET_GET_LEVEL(ret) == RET_LEV_ERROR && RET_GET_CATEG(ret) == RET_CATEG_MEM)
	{
		FREE_DYNST(unitAccrInter, UnitInter);
		if (allocOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
		return(ret);
	}

	/* In case of minor error, return null accrued interest */
   	if (ret == RET_SUCCEED) 
	{
		mktPtr->accrInterCurrId       = GET_ID(unitAccrInter,  UnitInter_CurrId);
		mktPtr->accrInterPeriod.num   = GET_INT(unitAccrInter, UnitInter_NumPeriod);
		mktPtr->accrInterPeriod.denom = GET_INT(unitAccrInter, UnitInter_DenomPeriod);

		/* calculate and apply tax rate */
		if (aiArgStp->txdInterFlg == TRUE)	/* BUG193 */
		{
		    NUMBER_T unitAccrInterNbr = GET_NUMBER(unitAccrInter, UnitInter_UnitAccrInter);
		    FIN_TaxRateUnitAccrInter(&unitAccrInterNbr, instrPtr);
		    /* REF3779 - RAK - 990701 - In case of TRUE, don't truncate to 9th decimal */
		    if (applUnitAccrIntAllDecFlag == TRUE)
		    { SET_NUMBER(unitAccrInter, UnitInter_UnitAccrInter, unitAccrInterNbr); }
		    else
		    { SET_NUMBER(unitAccrInter, UnitInter_UnitAccrInter, CAST_NUMBER(unitAccrInterNbr)); } /* REF3288 - SSO - 990205 */
		}

        /* PMSTA-37777 - Silpakal - 191106 */ /* Get the Last Coupon begin and end date only for Canadian Bonds */
        if (instrNat == InstrNat_Bond &&
           (instrSubNat == SubNat_Canadian || instrSubNat == SubNat_CanadianBoc))
        {
                ret = FIN_GetLastCouponPeriod(refDateTime, 
                                              refDateTime, 
                                              refDateTime,
                                              instrPtr,                    
                                              (ACCRRULE_ENUM)GET_ENUM(instrPtr, A_Instr_AccrualRuleEn),                                         
                                              hierHead,
                                              &lastCouponBeginDate,
                                              &lastCouponEndDate);
        }

		/* SSO - 990208 mktPtr->accrInter = FIN_Qty(instrPtr, qty) *  */
        /* REF5767 - RAK - 010313 - qty don't change sign of accrued interest for swap */
  if (GET_FLAG(instrPtr, A_Instr_BoForcedAiFlg) == TRUE)
  {
      if ((BORULE_ENUM)GET_ENUM(instrPtr, A_Instr_BoAccruedIntRuleEn) == BORule_Amount)
      {
          mktPtr->accrInter = GET_NUMBER(unitAccrInter, UnitInter_UnitAccrInter);
      }
      else if ((BORULE_ENUM)GET_ENUM(instrPtr, A_Instr_BoAccruedIntRuleEn) == BORule_Unitary)
      {
          if (instrNat == InstrNat_Swap)
          {
              mktPtr->accrInter = fabs(qty) * GET_NUMBER(unitAccrInter, UnitInter_UnitAccrInter);
          }
          else
              mktPtr->accrInter = qty * GET_NUMBER(unitAccrInter, UnitInter_UnitAccrInter);
      }
  }
  else
  {
      if (instrNat == InstrNat_Swap)
      {
          mktPtr->accrInter = fabs(qty) * GET_NUMBER(unitAccrInter, UnitInter_UnitAccrInter);
      }
      else if ((instrNat == InstrNat_Bond ||
          instrNat == InstrNat_ConvertBond) &&
          PriceCalcRule_QuoteInUnit == (PRICECALCRULE_ENUM)GET_ENUM(instrPtr, A_Instr_PriceCalcRuleEn))
      { /* REF11163 - TEB - 050713 */
          mktPtr->accrInter = qty * GET_NUMBER(unitAccrInter, UnitInter_UnitAccrInter)
              * GET_PRICE(instrPtr, A_Instr_FaceValue);
      }
      else if (is_MM_or_FI_FundShareFlg == TRUE) /* PMSTA01512-CHU-070430 */
      {
          mktPtr->accrInter = GET_NUMBER(unitAccrInter, UnitInter_UnitAccrInter);
      }
      else
      {
          mktPtr->accrInter = qty * GET_NUMBER(unitAccrInter, UnitInter_UnitAccrInter);
      }
  }

		if (instrNat == InstrNat_Discount || 
		    instrNat == InstrNat_MoneyMkt ||
		    instrNat == InstrNat_CashAcct ||
            TRUE     == is_MM_or_FI_FundShareFlg    /* PMSTA-1512 - 070507 - PMO */
           )
		{
		    /* No position for money market or discounted instr : AccrAmt = 0 */
		    /* Position is obligatory present for cash account (test before)  */
		    if (posPtr != NULL) 
		    { 
			    mktPtr->accrInter += GET_AMOUNT(posPtr, ExtPos_AccrAmt);
		    }
		}

		/* PMSTA-48782 - ankita - 16052022 */
		AppIncDivAccrualPos applIncludeDivAccrualPos = AppIncDivAccrualPos::includeInCashPos;

		GEN_GetApplInfo(ApplIncludeDivAccrualPosEnum, &applIncludeDivAccrualPos);


		if (instrNat == InstrNat_Stock && applIncludeDivAccrualPos == AppIncDivAccrualPos::includeInStockPos && 
			posPtr != NULL && DATETIME_CMP(GET_DATETIME(posPtr, ExtPos_ExtPosDate),GET_DATETIME(posPtr, ExtPos_IncEvtBegDate)) >= 0 &&
			DATETIME_CMP(GET_DATETIME(posPtr, ExtPos_ExtPosDate), GET_DATETIME(posPtr, ExtPos_IncEvtEndDate)) < 0)
		{
			mktPtr->accrInter += GET_AMOUNT(posPtr, ExtPos_AccrAmt);
		}

		/* Rounding of accrued interest - RAK - 960603 */ 
		/* If the rounding unit is different from "default" OR the rounding rule is      */
		/* different from "default" AND the unit accrued interest round flag is set to   */
		/* FALSE, the rounding of accrued interest amounts circumvents the std rounding. */
		if (GET_FLAG(instrPtr, A_Instr_UnitAiRoundFlg) == FALSE &&
		    (GET_ENUM(instrPtr, A_Instr_AiRoundRuleEn) != RndRule_None ||
		     GET_ENUM(instrPtr, A_Instr_AiRoundUnitEn) != RndUnit_None))
	  	{
		    DBA_DYNFLD_STP currPtr=NULL;
		    double         round;
            FLAG_T         freeFlag=FALSE;

		    /* If the rounded rule or the rouding unit are set to "default", then the   */
		    /* rule or unit specified at the currency of the accrued interest are used. */
		    if (GET_ENUM(instrPtr, A_Instr_AiRoundRuleEn) == RndRule_None ||
			    GET_ENUM(instrPtr, A_Instr_AiRoundUnitEn) == RndUnit_None)
		    {
                /* REF5248 - RAK - 001005 */
                /* Suppress DBA_Get2(Curr) and FREE_DYNST for currPtr */ 
				/* PMSTA16847 - DDV - 130924 - Add freeFlag parameter */
                if ((ret = DBA_GetCurrById(GET_ID(unitAccrInter, UnitInter_CurrId), 
                                           &currPtr, &freeFlag)) != RET_SUCCEED)
			    {
				    FREE_DYNST(unitAccrInter, UnitInter);
				    if (allocOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
				    return(ret);
			    }
		    }

		    if (GET_ENUM(instrPtr, A_Instr_AiRoundRuleEn) == RndRule_None)
		    {   
			    rndRuleEn = (RNDRULE_ENUM) GET_ENUM(currPtr, A_Curr_RoundRuleEn); 
		    }
		    else
		    {   
			    rndRuleEn = (RNDRULE_ENUM) GET_ENUM(instrPtr,A_Instr_AiRoundRuleEn);
		    }

		    if (GET_ENUM(instrPtr, A_Instr_AiRoundUnitEn) == RndUnit_None)
		    {
			    rndUnitEn = (RNDUNIT_ENUM) GET_ENUM(currPtr, A_Curr_RoundUnitEn);
		    }
		    else
		    {
			    rndUnitEn = (RNDUNIT_ENUM) GET_ENUM(instrPtr, A_Instr_AiRoundUnitEn);
		    }

            if (freeFlag == TRUE) {FREE_DYNST(currPtr, A_Curr);}

		    round = TLS_RoundEnum(mktPtr->accrInter, rndUnitEn, rndRuleEn);
		    mktPtr->accrInter = round;
		}
		else
		{
		    /* In all cases the amount should be rounded */
		    mktPtr->accrInter = CAST_AMOUNT(mktPtr->accrInter, mktPtr->accrInterCurrId); 
		}
		

		/* If accrued interest is not in reference currency, */
		/* convert into the reference currency.              */
  if (TapComputesIntAccr == true) /*PMSTA-42064-ARUN-08102020*/
  {
        if (mktPtr->accrInterCurrId != refCurrId)
        {
            /* REF2313 */
            exchArgSt.srcAmt = mktPtr->accrInter;
            if ((ret = FIN_ExchAmt(refDateTime, mktPtr->accrInterCurrId, refCurrId,
                 0, NULL, posPtr, &exchArgSt, NULL,
                &(mktPtr->accrInterRefCurr),
                &(mktPtr->accrInterRefExch))) != RET_SUCCEED)	/* PMSTA01649 - TGU - 070405 */
            {
                FREE_DYNST(unitAccrInter, UnitInter);
                if (allocOk == TRUE) { FREE_DYNST(instrPtr, A_Instr); }
                return(ret);
            }
        }
        else
        {
            mktPtr->accrInterRefCurr = mktPtr->accrInter;
            mktPtr->accrInterRefExch = 1.0;
        }
  }
  else
  {
      /* let the  mktPtr->accrInterRefCurr be as per the default value script computation provided */
      if (mktPtr->accrInterCurrId != refCurrId)
      {
          exchArgSt.srcAmt = mktPtr->accrInterRefCurr;
          if ((ret = FIN_ExchAmt(refDateTime, refCurrId, mktPtr->accrInterCurrId,
              0, NULL, posPtr, &exchArgSt, NULL,
              &(mktPtr->accrInter),
              &accrInterExchg)) != RET_SUCCEED)
          {
              FREE_DYNST(unitAccrInter, UnitInter);
              if (allocOk == TRUE) { FREE_DYNST(instrPtr, A_Instr); }
              return(ret);
          }
          if (CMP_EXCHANGE(accrInterExchg, 0.0) != 0)
          {
              mktPtr->accrInterRefExch = 1 / accrInterExchg;
          }
      }
      else
      {
          mktPtr->accrInter = mktPtr->accrInterRefCurr;
          mktPtr->accrInterRefExch = 1.0;
      }
  }
	}

	if (allocOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
	FREE_DYNST(unitAccrInter, UnitInter);
    }
	return(RET_SUCCEED);  
}

/************************************************************************
**
**  Function    :   FIN_GetInstrAccrRule()
**
**  Description :   return the Instr_AccrRuleEn for the instrument at the given date
**		            this function has been introduced to manage particulare case for
**		            Euro Bonds: if refDateTime is AFTER the begin date of the 1st coupon
**		            after A_Instr_EuroConvDate, then the rule is taken from an appl param..
**                 
**  Arguments   :   DATE_T		refDate,
**		            DBA_DYNFLD_STP	inputInstrPtr
**		            DBA_HIER_HEAD_STP	hierHead
**		            INSTRNAT_ENUM*	instrAccRule (out)
**
**  Return      :   RET_CODE
**
**  Modif       :   REF3410 - SSO - 990315
**                  REF4075 - CSY - 991109 parameter EvtDateRule_Term to FIN_InstrFlows
**                  REF7264 - 020129 - PMO : Compilation errors and warnings with C++ compiler
**                  REF10523 - TEB - 040804
**
*************************************************************************/
RET_CODE FIN_GetInstrAccrRule(DATE_T refDate, DBA_DYNFLD_STP inputInstrPtr, 
			                  DBA_HIER_HEAD_STP hierHead, ACCRRULE_ENUM* instrAccRule)
{
	RET_CODE	    ret = RET_SUCCEED;
	DATETIME_T	    euroConvDate, firstCouponBeginDate;
	DBA_DYNFLD_STP	outputFlow;
	ACCRRULE_ENUM	applInstrAccrRule = AccrRule_None;
	ENUM_T		    instrNatEn; /* REF3874 - SSO - 990803 */
	
	*instrAccRule = (ACCRRULE_ENUM) GET_ENUM(inputInstrPtr, A_Instr_AccrualRuleEn); /* by default / REF7264 - PMO */

	GEN_GetApplInfo(ApplEuroBondAccrIntEn, &applInstrAccrRule);

	if (applInstrAccrRule == AccrRule_None)
	{
	    /* not active */
	    return(RET_SUCCEED);
	}

	instrNatEn = GET_ENUM(inputInstrPtr, A_Instr_NatEn); /* REF3874 - SSO - 990803 */
	if (instrNatEn != InstrNat_Bond 
	    && instrNatEn != InstrNat_CumOption		/* REF3874 - SSO - 990803 */
	    && instrNatEn != InstrNat_ConvertBond)	/* REF3874 - SSO - 990803 */
	{
	    return(RET_SUCCEED);
	}

	if (IS_NULLFLD(inputInstrPtr, A_Instr_EuroConvDate) == TRUE)
	{
	    return(RET_SUCCEED);
	}

	/* particular case at this point */
	if (IS_NULLFLD(inputInstrPtr, A_Instr_FirstCoupBegDateEuro) == FALSE)
	{
	    /* already computed or currently computing */
	    if (GET_DATE(inputInstrPtr, A_Instr_FirstCoupBegDateEuro) != MAGIC_END_DATE)
	    {
		    /* compare dates */
		    if (refDate >= GET_DATE(inputInstrPtr, A_Instr_FirstCoupBegDateEuro))
		    {
		        /* take sys param */
		        *instrAccRule = applInstrAccrRule;
		    }
	    }
	    /* if MAGIC_END_DATE: currently computing, so use default from instr */
	    return(RET_SUCCEED);
	}
	
	euroConvDate = GET_DATETIME(inputInstrPtr, A_Instr_EuroConvDate);

	/*** SEARCH 1st coupon after euroConvDate. Problem: FIN_PeriodUnitAccrInter is called from FIN_InstrFlow ***/
	if ((outputFlow = ALLOC_DYNST(Flow)) == NULL)
	{
	    MSG_RETURN(RET_MEM_ERR_ALLOC);
	}

	/* set A_Instr_PartAccrInterRule to avoid loops */
	SET_DATE(inputInstrPtr, A_Instr_FirstCoupBegDateEuro, MAGIC_END_DATE);

	if ((ret = FIN_InstrFlow(GET_ID(inputInstrPtr, A_Instr_Id), inputInstrPtr, 
		                     euroConvDate, euroConvDate, 
							 TRUE, /* PMSTA-9032 - RAK - 091216 - Don't use dom ref date */
							 TimeDim_Next, 2, 
		                     FlowNat_Inc, FlowSubNat_Any, EvtDateRule_Term, /* REF4075 - CSY - 991109 */
                             outputFlow, hierHead)) != RET_SUCCEED)
	{
	    FREE_DYNST(outputFlow, Flow);
	    SET_NULL_DATE(inputInstrPtr, A_Instr_FirstCoupBegDateEuro);

		/* REF10523 - TEB - 040804 */
		if (ret == RET_DBA_ERR_NODATA ||
			ret == RET_DBA_INFO_NODATA)
			ret = RET_SUCCEED;

	    return(ret);
	}

	firstCouponBeginDate = GET_DATETIME(outputFlow, Flow_BegPayDate);

	FREE_DYNST(outputFlow, Flow);

	/* store value for next call */
	SET_DATE(inputInstrPtr, A_Instr_FirstCoupBegDateEuro, firstCouponBeginDate.date);

	/* compare dates */
	if (refDate >= firstCouponBeginDate.date)
	{
	    /* take sys param */
	    *instrAccRule = applInstrAccrRule;
	}

    return(RET_SUCCEED);
}

/* PMSTA-35434 - RAK - 190408 - Use simcorp computation and correct period (semestrial, quarterly, monthly) */
STATIC RET_CODE FIN_STNNbrOfDaysInCouponPeriod(DBA_DYNFLD_STP instrPtr,
											  DATE_T fromDate,
											  DATE_T tillDate,
											  DBA_HIER_HEAD_STP hierHead,
											  long* nbrOfDaysInCouponPeriod)
{
	double	freq = 0;
	long	maxDaysInYear;
	DATE_T	perDate;
	RET_CODE ret = RET_SUCCEED;
	char	endMFlg;
	DAY_T	lastDay;
	bool	debugFlg = false;

	*nbrOfDaysInCouponPeriod = 0;

	if ((ret = FIN_PeriodUnitNbr((FREQUNIT_ENUM)GET_ENUM(instrPtr, A_Instr_PayFreqUnitEn),
		GET_TINYINT(instrPtr, A_Instr_PayFreq),
		FreqUnit_Month, &freq)) == RET_SUCCEED)
	{
		endMFlg = (char)DATE_IsLastInMonth(fromDate);
		DATE_Get(fromDate, NULL, NULL, &lastDay);

		/* one coupon period */
		perDate = DATE_Move(fromDate, (int)freq, Month);

		/* Short month can corrupt day number */
		DATE_VerifyEndMonth(&perDate, lastDay, endMFlg);
		DATE_DaysBetween(fromDate, perDate,
						 (ACCRRULE_ENUM)GET_ENUM(instrPtr, A_Instr_AccrualRuleEn), 
						 nbrOfDaysInCouponPeriod, 0); 

		/* PMSTA-35314 - RAK - 190408 - Don't return 365 for Actual/360 */
		if (*nbrOfDaysInCouponPeriod > 360 && DATE_AccrMaxDaysInYear2(fromDate, perDate, (ACCRRULE_ENUM)GET_ENUM(instrPtr, A_Instr_AccrualRuleEn),
			FreqUnit_None, &maxDaysInYear) == TRUE && maxDaysInYear == 360)
		{
			*nbrOfDaysInCouponPeriod = 360;
		}
		/* PMSTA-35626 - RAK - 190430 - Use MaxDays for some accrual rule */
		else if (CMP_NUMBER(freq, 12) == 0 && DATE_AccrMaxDaysInYear2(fromDate, perDate, (ACCRRULE_ENUM)GET_ENUM(instrPtr, A_Instr_AccrualRuleEn),
			FreqUnit_None, &maxDaysInYear) == TRUE)
		{
			*nbrOfDaysInCouponPeriod = maxDaysInYear;
		}

		/* PMSTA-35458 - RAK - 190416 */
		if (freq < 12 && GET_ENUM(instrPtr, A_Instr_AccrualRuleEn) == AccrRule_30E_360 ||
			GET_ENUM(instrPtr, A_Instr_AccrualRuleEn) == AccrRule_30_360_FebAdj ||
			GET_ENUM(instrPtr, A_Instr_AccrualRuleEn) == AccrRule_30_360_Def ||
			GET_ENUM(instrPtr, A_Instr_AccrualRuleEn) == AccrRule_30_360_US ||
			GET_ENUM(instrPtr, A_Instr_AccrualRuleEn) == AccrRule_Actual_360 ||
			GET_ENUM(instrPtr, A_Instr_AccrualRuleEn) == AccrRule_30_360 ||
			GET_ENUM(instrPtr, A_Instr_AccrualRuleEn) == AccrRule_Actual_1_360 ||
			GET_ENUM(instrPtr, A_Instr_AccrualRuleEn) == AccrRule_SceEu30360 ||
			GET_ENUM(instrPtr, A_Instr_AccrualRuleEn) == AccrRule_SceEu30E360 ||
			GET_ENUM(instrPtr, A_Instr_AccrualRuleEn) == AccrRule_SceUs30360 ||
			GET_ENUM(instrPtr, A_Instr_AccrualRuleEn) == AccrRule_SceUs30E360 ||
			GET_ENUM(instrPtr, A_Instr_AccrualRuleEn) == AccrRule_SceAct360)
			*nbrOfDaysInCouponPeriod = (long) (30 * freq);

		if (debugFlg)
		{
			YEAR_T eyear;
			MONTH_T emonth;
			DAY_T eday;

			DATE_Get(fromDate, &eyear, &emonth, &eday);

			printf("\n FIN_STNNbrOfDaysInCouponPeriod : %02d/%02d/%04d, %ld", eday, emonth, eyear, *nbrOfDaysInCouponPeriod);
		}
	}

	return(ret);
}

/************************************************************************
**
**  Function    : FIN_STNInterestNbrOfDaysInside()
**
**  Description : Computes the number of days the benchmark values were
**				  inside the defined boundaries in the concerned coupon period.
**
**  Return      : RET_CODE
**
**  Creation	: PMSTA-34866 - RAK - 190225
**
*************************************************************************/
/* note that I don't have lot of time for this impelmentation, anyway I think we have to load all prices in one select but ... */
STATIC RET_CODE FIN_STNInterestNbrOfDaysInside(DBA_DYNFLD_STP instrPtr,
                                            DBA_DYNFLD_STP instrCondPtr,  /* PMSTA-36699  - Silpakal - 191121 */
											DATE_T fromDate, 
											DATE_T tillDate, 
											DBA_HIER_HEAD_STP hierHead, 
											double *nbrOfDaysInside)
{
	RET_CODE		ret = RET_SUCCEED;
	FIN_PRICEARG_ST	priceArgSt;
	MemoryPool		mp;
	DbiConnectionHelper dbiConnHelper;
	
	bool			flg30 = false, begM = true;
	MONTH_T			month;
	YEAR_T			year;
	DAY_T			day;

	bool			debugFlg = false;

	DBA_DYNFLD_STP pricePtr		= mp.allocDynst(FILEINFO, A_InstrPrice);
	DBA_DYNFLD_STP getInstrPtr	= mp.allocDynst(FILEINFO, S_Instr);
	DBA_DYNFLD_STP benchPtr		= mp.allocDynst(FILEINFO, A_Instr);
	DATE_T		   currentDate = DATE_CurrentDate();

	DATETIME_T fromDateTime;
	fromDateTime.date = fromDate;
	fromDateTime.time = 0;

	DATETIME_T tillDateTime;
	tillDateTime.date = tillDate;
	tillDateTime.time = 0;

	memset(&priceArgSt, 0, sizeof(FIN_PRICEARG_ST));

	/* PMSTA-35458 - RAK - 190416 */
	if (GET_ENUM(instrPtr, A_Instr_AccrualRuleEn) == AccrRule_30E_360 ||
		GET_ENUM(instrPtr, A_Instr_AccrualRuleEn) == AccrRule_30_360_FebAdj ||
		GET_ENUM(instrPtr, A_Instr_AccrualRuleEn) == AccrRule_30_360_Def ||
		GET_ENUM(instrPtr, A_Instr_AccrualRuleEn) == AccrRule_30_360_US ||
		GET_ENUM(instrPtr, A_Instr_AccrualRuleEn) == AccrRule_30E_365 ||
		GET_ENUM(instrPtr, A_Instr_AccrualRuleEn) == AccrRule_30_360 ||
		GET_ENUM(instrPtr, A_Instr_AccrualRuleEn) == AccrRule_30E_Actual ||
		GET_ENUM(instrPtr, A_Instr_AccrualRuleEn) == AccrRule_30_365_US ||
		GET_ENUM(instrPtr, A_Instr_AccrualRuleEn) == AccrRule_30_Actual_US ||
		GET_ENUM(instrPtr, A_Instr_AccrualRuleEn) == AccrRule_30_360_1 ||
		GET_ENUM(instrPtr, A_Instr_AccrualRuleEn) == AccrRule_SceEu30360 ||
		GET_ENUM(instrPtr, A_Instr_AccrualRuleEn) == AccrRule_SceEu30E360 ||
		GET_ENUM(instrPtr, A_Instr_AccrualRuleEn) == AccrRule_SceEu30E365 ||
		GET_ENUM(instrPtr, A_Instr_AccrualRuleEn) == AccrRule_SceUs30360 ||
		GET_ENUM(instrPtr, A_Instr_AccrualRuleEn) == AccrRule_SceUs30E360 ||
		GET_ENUM(instrPtr, A_Instr_AccrualRuleEn) == AccrRule_SceEu30Ep360)
		flg30 = true;
	
	/* We can't find price in future (dixit IRMA) */
	*nbrOfDaysInside = 0.0;
	if (fromDate > currentDate)
		return(ret);

    SET_ID(getInstrPtr, S_Instr_Id, GET_ID(instrCondPtr, A_InterCond_BenchInstrId));   /* PMSTA-36699  - Silpakal - 191121 */

	if (dbiConnHelper.dbaGet(Instr, UNUSED, getInstrPtr, &benchPtr) != RET_SUCCEED)
		return(RET_DBA_ERR_NODATA);

	/* PMSTA-35262 - RAK - 190708 - Load benchmark prices in hier before the loop to avoid multiple db access */
	DBA_DYNFLD_STP domainPtr = DBA_GetDomainPtr(DBA_GetConnectNoFromHier(hierHead));
	if (domainPtr != NULLDYNST) /* import */
	{
		DBA_SelectUnderlyingPrices(hierHead, domainPtr, benchPtr, &fromDateTime, &tillDateTime);	/* PMSTA-35262 - RAK - 190708 - Use default domain dates */
	}

	/* PMSTA-35315 - RAK - 190412 - Compute month by month because of the 30/360 Accrual rules */
	/* move fromDate day by day, verifying business date */
	if (debugFlg)
	{
		YEAR_T fy, qy;
		MONTH_T fm, qm;
		DAY_T fd, qd;

		DATE_Get(fromDateTime.date, &fy, &fm, &fd);
		printf("\n from date %02d/%02d/%04d ", fd, fm, fy);
		DATE_Get(tillDate, &qy, &qm, &qd);
		printf(" till date %02d/%02d/%04d ", qd, qm, qy);
	}

	/* PMSTA-35458 - RAK - 190516 - Modify verification of the future (you are welcome IRMA) */
	while (fromDateTime.date < tillDate && fromDateTime.date < currentDate && ret==RET_SUCCEED)
	{
		fromDateTime.date = DATE_Move(fromDateTime.date, 1, Day);

		if ((ret = FIN_InstrPrice(GET_ID(instrCondPtr, A_InterCond_BenchInstrId), benchPtr,   /* PMSTA-36699  - Silpakal - 191121 */
										fromDateTime, NULLDYNST, (ID_T)0, &priceArgSt, NULLDYNST,
										NULLDYNST, hierHead, pricePtr, FALSE)) == RET_SUCCEED) 
		{
			/* PMSTA-35458 - RAK - 190416 */
			if (CMP_NUMBER(CAST_NUMBER(GET_PRICE(pricePtr, A_InstrPrice_Quote)), GET_NUMBER(instrCondPtr, A_InterCond_MinIntP)) >= 0 && /* PMSTA-36699  - Silpakal - 191121 */
				CMP_NUMBER(CAST_NUMBER(GET_PRICE(pricePtr, A_InstrPrice_Quote)), GET_NUMBER(instrCondPtr, A_InterCond_MaxIntP)) <= 0 &&
				DATETIME_CMP(GET_DATETIME(pricePtr, A_InstrPrice_QuoteDate), fromDateTime) <= 0)
			{
				(*nbrOfDaysInside) += 1.0; /* std */

				if (flg30 == true && begM==false)
				{
					DATE_Get(fromDateTime.date, &year, &month, &day);

					if (day == 31)
					{
						(*nbrOfDaysInside) -= 1.0;
					}

					if (month == 2) /* and so #*! pretty february */
					{
						if (day == 29 && (LEAP_YEAR(year)))
						{
							(*nbrOfDaysInside) += 1.0;
						}
						else if (day == 28 && (!(LEAP_YEAR(year))))
						{
							(*nbrOfDaysInside) += 2.0;
						}
					}
				}
			}

			if (debugFlg)
			{
				YEAR_T fy, qy;
				MONTH_T fm, qm;
				DAY_T fd, qd;

				DATE_Get(fromDateTime.date, &fy, &fm, &fd);
				DATE_Get(GET_DATETIME(pricePtr, A_InstrPrice_QuoteDate).date, &qy, &qm, &qd);
				printf("\n%f quoted date %02d/%02d/%04d date %02d/%02d/%04d quote %f min %f max %f", *nbrOfDaysInside, qd, qm, qy, fd, fm, fy, GET_PRICE(pricePtr, A_InstrPrice_Quote),
                       GET_NUMBER(instrCondPtr, A_InterCond_MinIntP), GET_NUMBER(instrCondPtr, A_InterCond_MaxIntP));  /* PMSTA-36699  - Silpakal - 191121 */
			}
			begM = false;
		}
	}

	/* PMSTA-35621 - RAK - 190514 - forget */
	if (GET_ENUM(instrPtr, A_Instr_AccrualRuleEn) == AccrRule_Actual_1_Actual ||
		GET_ENUM(instrPtr, A_Instr_AccrualRuleEn) == AccrRule_Actual_1_360 ||
		GET_ENUM(instrPtr, A_Instr_AccrualRuleEn) == AccrRule_Actual_1_365)
		(*nbrOfDaysInside) += 1.0;

	if (debugFlg)
	{
		printf(" nbrOfDaysInside %f ", *nbrOfDaysInside);
	}
				
	return(ret);
}

/************************************************************************
**
**  Function    :   FIN_MCBenchmarkDate()
**
**  Description :   Return all benchmark date for the received instrument 
**					according to the payment frequency.
**
**  Arguments   :
**
**  Return      :   
**
**  Creation    : PMSTA-34866 - RAK - 190222
**  Modif       : PMSTA-35460 - RAK - 190412
**  Modif       : PMSTA-36699 - Silpakal - 191127
**
*************************************************************************/
STATIC RET_CODE FIN_MCBenchmarkDate(DBA_DYNFLD_STP instrPtr, DBA_DYNFLD_STP interCondPtr, DATE_T fromDate, DATE_T tillDate, DATE_T **benchmarkDate, int *benchmarkNbr)
{
	RET_CODE		ret = RET_SUCCEED;
    DATE_T			firstBenchmarkDate, currentDate = DATE_CurrentDate();
	double			freq=0.0;
	char			endMFlg = FALSE;
	DAY_T			lastDay;
	
	/* PMSTA-35460 - 190412 - Keep current benchmark date in loop */
    *benchmarkNbr = 0;
    *benchmarkDate = nullptr;

	if (fromDate > currentDate)
		return(RET_SUCCEED); /* PMSTA-35320 - RAK - 190401 - do nothing but generate flows */
	
    if (!IS_NULLFLD(interCondPtr, A_InterCond_FirstBenchDate) && GET_DATE(interCondPtr, A_InterCond_FirstBenchDate) > 0)
	{
        firstBenchmarkDate = GET_DATE(interCondPtr, A_InterCond_FirstBenchDate);
		endMFlg = FALSE; /* keep 28 even if we are on february (eom) */
        DATE_Get(firstBenchmarkDate, NULL, NULL, &lastDay);

		if ((ret = FIN_PeriodUnitNbr((FREQUNIT_ENUM)GET_ENUM(instrPtr, A_Instr_PayFreqUnitEn),
			                         GET_TINYINT(instrPtr, A_Instr_PayFreq), FreqUnit_Month, &freq)) == RET_SUCCEED)
		{
			/* go to benchmark date juste before the valorisation date */
			while (firstBenchmarkDate <= GET_DATE(instrPtr, A_Instr_EndDate))
			{
                *benchmarkDate = (DATE_T*)REALLOC((*benchmarkDate), ((*benchmarkNbr) + 1) * sizeof(DATE_T));
				if ((*benchmarkDate) == nullptr) { MSG_RETURN(RET_MEM_ERR_ALLOC); }

                (*benchmarkDate)[(*benchmarkNbr)] = firstBenchmarkDate;
                ++(*benchmarkNbr);
				
				/* next */
                firstBenchmarkDate = DATE_Move(firstBenchmarkDate, (int)freq, Month);
				/* Short month can corrupt day number */
				DATE_VerifyEndMonth(&firstBenchmarkDate, lastDay, endMFlg);
			}
		}
	}
	else
		ret = RET_GEN_ERR_INVARG;

	return(ret);
}

/************************************************************************
**
**  Function    :   FIN_STNInterestCalculationRule()
**
**  Description :   Compute new structued notes accrued interest methods
**
**  Arguments   :
**
**  Return      :   fill accrInterPtr and return RET_SUCCEED or error code
**
**  Creation    :   PMSTA-34866 - RAK - 190222
**  Modif       :   PMSTA-36699 - Silpakal - 191121 - Use Interest Rate Condition instead of instrument table
**
*************************************************************************/
STATIC RET_CODE FIN_STNInterestCalculationRule(DATE_T              interFromDate,
											   DATE_T              interTillDate,
											   DBA_DYNFLD_STP      accrInterPtr,
											   DBA_DYNFLD_STP      instrPtr, 
											   DBA_HIER_HEAD_STP   hierHead)
{
	RET_CODE	ret = RET_SUCCEED;
	bool		debugFlg = false;

    /* PMSTA-36699  - Silpakal - 191121 */
    DBA_DYNFLD_STP          inputData = NULLDYNST;
    DBA_DYNFLD_STP          *selInterTab = NULLDYNSTPTR;
    int                     selInterNbr = 0;
    FLAG_T		            interCondRecFlg = FALSE;
    MemoryPool              mp;	

	/* Init to zero */
	SET_NUMBER(accrInterPtr, UnitInter_UnitAccrInter, 0.0);
	SET_INT(accrInterPtr,    UnitInter_NumPeriod,     0);
	SET_INT(accrInterPtr,    UnitInter_DenomPeriod,   0);
	SET_ID(accrInterPtr,     UnitInter_CurrId, GET_ID(instrPtr, A_Instr_RefCurrId)); /* PMSTA-34985 - RAK - 190321 - flow won't create operation elsewhere  */
	
     /* PMSTA-36699  - Silpakal - 191121 */
    /* Fetch the benchmark details from interest rate condition table instead of instrument table */
    inputData = mp.allocDynst(FILEINFO, A_InterCond);

    if (GET_ID(instrPtr, A_Instr_Id) < 0)
    {
        SET_ID(inputData, A_InterCond_InstrId, GET_ID(instrPtr, A_Instr_ParentInstrId));
    }
    else
    {
        SET_ID(inputData, A_InterCond_InstrId, GET_ID(instrPtr, A_Instr_Id));
    }

    SET_DATE(inputData, A_InterCond_BeginDate, interFromDate);
    SET_DATE(inputData, A_InterCond_EndDate, interTillDate);
    SET_ENUM(inputData, A_InterCond_NatEn, InterCondNat_None);

    /* Fill valid_date for Fund Share instruments */
    if (instrPtr != NULLDYNST &&
        (INSTRNAT_ENUM)GET_ENUM(instrPtr, A_Instr_NatEn) == InstrNat_FundShare &&
        ((SUBNAT_ENUM)GET_ENUM(instrPtr, A_Instr_SubNatEn) == SubNat_MoneyMarketFundShare ||
        (SUBNAT_ENUM)GET_ENUM(instrPtr, A_Instr_SubNatEn) == SubNat_FixedIncomeFundShare))
    {
        SET_DATE(inputData, A_InterCond_ValidDate, interFromDate);
    }

    if ((ret = DBA_SelAllInterCond(InterCond_ByIdDt, hierHead, instrPtr, inputData,
        &selInterTab, &selInterNbr, &interCondRecFlg)) != RET_SUCCEED)
    {
        ret = RET_DBA_ERR_NODATA;
        MSG_SendMesg(ret, 3, FILEINFO, "DBA_SelectInterCond", GET_CODE(instrPtr, A_Instr_Cd), "interest condition");
        FREE(selInterTab);
        return ret;
    }

    mp.ownerDynStpTab(selInterTab,selInterNbr);

    INTERCALCRULE_ENUM interCondCalcRuleEn = (INTERCALCRULE_ENUM)GET_ENUM(selInterTab[0], A_InterCond_IntCalcRuleEn);

	switch (interCondCalcRuleEn)
	{
		case InterCalcRule_RangeAccrual:
		{
			/* -------------------------------------------------------------------------- */
			/* Accrued interest on the valuation date for the concerned coupon period =   */
			/* (Fixed interest rate / n) * (No.of days inside / No.of days in the period) */
			/* -------------------------------------------------------------------------- */
			double nbrOfDaysInside = 0.0, n = 1.0;
			long   nbrOfDaysInPeriod = 0;
			/* where n = number of coupon periods in a year */
			ret = FIN_PeriodUnitNbr((FREQUNIT_ENUM)GET_ENUM(instrPtr, A_Instr_PayFreqUnitEn),
				                    GET_TINYINT(instrPtr, A_Instr_PayFreq), FreqUnit_Year, &n);
			if (ret == RET_SUCCEED && CMP_NUMBER(n, 0.0) != 0)
				n = 1 / n;

			/* Computes nbr of days inside */ /*PMSTA-36699  - Silpakal - 191121 - Change to instr Condition instead of instr */
            if (selInterNbr > 0 &&
                (!IS_NULLFLD(selInterTab[0], A_InterCond_BenchInstrId) &&
                 !IS_NULLFLD(selInterTab[0], A_InterCond_MinIntP) &&
                 !IS_NULLFLD(selInterTab[0], A_InterCond_MaxIntP)))
                ret = FIN_STNInterestNbrOfDaysInside(instrPtr, selInterTab[0], interFromDate, interTillDate, hierHead, &nbrOfDaysInside);
			else
			{
				MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
					"FIN_STNInterestCalculationRule", "benchmark, miminum or maximum rate");
				return(RET_GEN_ERR_INVARG);
			}

			/* Computes nbr of days in the coupon period */
			ret = FIN_STNNbrOfDaysInCouponPeriod(instrPtr, interFromDate, interTillDate, hierHead, &nbrOfDaysInPeriod);
			
			/* PMSTA-35034 - RAK - 190322 - Divide by percent */
			SET_NUMBER(accrInterPtr, UnitInter_UnitAccrInter,
				((GET_PERCENT(selInterTab[0], A_InterCond_InterestRateP)/100.0 / n) * (nbrOfDaysInside / (double) nbrOfDaysInPeriod))); /* PMSTA-36699  - Silpakal - 191121  */
			SET_INT(accrInterPtr, UnitInter_NumPeriod, (int)nbrOfDaysInside);
			SET_INT(accrInterPtr, UnitInter_DenomPeriod, (int)nbrOfDaysInPeriod);

			break;
		}

        case InterCalcRule_Digital:
        case InterCalcRule_Floating:
		{
			/* ------------------------------------------------------------------------------------ */
			/* InterCalcRule_Digital                                                        */
			/* IF(bench(i) is available and >= Minimum Value) and Initial Date >= benchmark date  */
			/* Accrued interest  = (Fixed interest rate / n) * (NbrDays accrued / Total no.of days) */
			/* Else 0.0                                                                             */

			/* InterCalcRule_Floating(FlooredFloater):                                                */
			/* If Initial Date >= benchmark Date and Bench(i) is available,                       */
			/* If (Bench(i) > Minimum Value)                                                        */
			/*     Accrued interest = (Bench(i) / n) *  (NbrDays accrued / Total no.of days)        */
			/* Else                                                                                 */
			/*     Accrued interest  = (Minimum Value / n) * (NbrDays accrued / Total no.of days)   */
			/* Else 0.                                                                              */
			
			/* InterCalcRule_Floating (CollaredFloater):                                               */
		    /* If Initial Date >= benchmark Date and Bench(i) is available,                       */
			/* If (Maximum Value >= Bench(i)  > Minimum Value)                                      */
			/* Accrued interest  = (Bench(i) / n) * Quantity * (NbrDays accrued / Total no.of days) */
			/* If (Bench(i) > Maximum Value > Minimum Value)                                        */
			/* Accrued interest  = (Maximum Value / n) * (NbrDays accrued / Total no.of days)       */
			/* If (Maximum Value > Minimum Value >= Bench(i))                                       */
			/* Accrued interest = (Minimum Value / n)  * (NbrDays accrued / Total no.of days)       */
			/* Else �0�.                                                                            */

			/* InterCalcRule_Floating (CappedFloater):
			/* If Initial Date >= benchmark Date and Bench(i) is available,                       */
			/* If Bench(i) > Maximum Value                                                          */
            /* Accrued interest for the coupon period =                                             */
			/* (Maximum Value/n) * Quantity * (NbrDays accrued / Total no.of days)                  */
	        /* Else = (Bench(i)/n) * Quantity * (NbrDays accrued / Total no.of days)                */
			/* ------------------------------------------------------------------------------------ */
				
			FIN_PRICEARG_ST	priceArgSt;
			DBA_DYNFLD_STP	pricePtr	= mp.allocDynst(FILEINFO, A_InstrPrice);
			DBA_DYNFLD_STP	getInstrPtr	= mp.allocDynst(FILEINFO, S_Instr);
			DBA_DYNFLD_STP	benchPtr	= mp.allocDynst(FILEINFO, A_Instr);
            DATETIME_T		benchMarkDate, prevBenchMarkDate;
			double			freq=0;
			DbiConnectionHelper dbiConnHelper;
			double			n = 1.0;
			long			nbrOfDaysInCouponPeriod = 0, nbrOfDaysInPeriod = 0;
			PERCENT_T		rate = 0.0;
			DATE_T			currentDate = DATE_CurrentDate();
			char			endMFlg;
			DAY_T			day;

			memset(&priceArgSt, 0, sizeof(FIN_PRICEARG_ST));
            benchMarkDate.date = GET_DATE(selInterTab[0], A_InterCond_FirstBenchDate);
            benchMarkDate.time = 0;
            prevBenchMarkDate.date = benchMarkDate.date;
            prevBenchMarkDate.time = 0;

			/* PMSTA-35520 - RAK - 190430 */
            endMFlg = (char)DATE_IsLastInMonth(prevBenchMarkDate.date);
            DATE_Get(prevBenchMarkDate.date, NULL, NULL, &day);

			if (IS_NULLFLD(selInterTab[0], A_InterCond_BenchInstrId))
			{
				MSG_SendMesg(RET_DBA_ERR_NODATA, 3, FILEINFO, "FIN_STNInterestCalculationRule", GET_CODE(instrPtr, A_Instr_Cd), "Benchmark must be specified");
				return(RET_DBA_ERR_NODATA);
			}

			SET_ID(getInstrPtr, S_Instr_Id, GET_ID(selInterTab[0], A_InterCond_BenchInstrId));
			if (dbiConnHelper.dbaGet(Instr, UNUSED, getInstrPtr, &benchPtr) != RET_SUCCEED)
				return(RET_DBA_ERR_NODATA);

			/* where n = number of coupon periods in a year */
			ret = FIN_PeriodUnitNbr((FREQUNIT_ENUM)GET_ENUM(instrPtr, A_Instr_PayFreqUnitEn),
				                    GET_TINYINT(instrPtr, A_Instr_PayFreq), FreqUnit_Year, &n);
			if (ret == RET_SUCCEED && CMP_NUMBER(n, 0.0) != 0)
				n = 1 / n;

			/* Computes nbr of days in the period */
			DATE_DaysBetween(interFromDate, interTillDate, (ACCRRULE_ENUM)GET_ENUM(instrPtr, A_Instr_AccrualRuleEn), &nbrOfDaysInPeriod, 0);

			if (debugFlg) printf("\n\n\n");

			if (FIN_PeriodUnitNbr((FREQUNIT_ENUM)GET_ENUM(instrPtr, A_Instr_PayFreqUnitEn),
								  GET_TINYINT(instrPtr, A_Instr_PayFreq),
								  FreqUnit_Month, &freq) == RET_SUCCEED)
			{
				/* PMSTA-35038 - RAK - 190325 - Don't compute AI before benchmark date */
				bool benchMarkFlg = false;

				/* go to previous benchmark date just before the valorisation date */
				while (benchMarkDate.date <= interTillDate)
				{
                    prevBenchMarkDate.date = benchMarkDate.date;

					/* next */
                    benchMarkDate.date = DATE_Move(benchMarkDate.date, (int)freq, Month);
					/* PMSTA-35520 - RAK - 190430 - Short month can corrupt day number */
                    DATE_VerifyEndMonth(&benchMarkDate.date, day, endMFlg);
				}

				if (prevBenchMarkDate.date > interFromDate && prevBenchMarkDate.date  <= interTillDate)
                    benchMarkFlg = true;
				else
                    benchMarkFlg = false;
 
				/* PMSTA-35038 - RAK - 190325 - Don't compute AI before benchmark date */
				if (benchMarkFlg == true && prevBenchMarkDate.date  <= currentDate)	/* Not usefull to get a price in future */
				{
					if (debugFlg)
					{
						YEAR_T eyear;
						MONTH_T emonth;
						DAY_T eday;

						DATE_Get(prevBenchMarkDate.date, &eyear, &emonth, &eday);

						printf("\n instrPriceDate : %02d/%02d/%04d", eday, emonth, eyear);
					}

					if ((ret = FIN_InstrPrice(GET_ID(selInterTab[0], A_InterCond_BenchInstrId), benchPtr,
                                            prevBenchMarkDate, NULLDYNST, (ID_T)0, &priceArgSt, NULLDYNST,
						                    NULLDYNST, hierHead, pricePtr, FALSE)) == RET_SUCCEED)
					{
						if (debugFlg)
							printf("\nbench price %lf bench quote %lf minimum %lf maximum %lf",
								GET_PRICE(pricePtr, A_InstrPrice_Price),
								GET_PRICE(pricePtr, A_InstrPrice_Quote),
                                GET_NUMBER(selInterTab[0], A_InterCond_MinIntP),
                                GET_NUMBER(selInterTab[0], A_InterCond_MaxIntP));

						/* PMSTA-35034 - RAK - 190322 - Divide by percent */
						if (interCondCalcRuleEn == InterCalcRule_Digital)
						{
							/* IF(bench(i) is available and >= Minimum Value), rate = instr condition interest rate */
							if (CMP_NUMBER(CAST_NUMBER(GET_PRICE(pricePtr, A_InstrPrice_Quote)), GET_NUMBER(selInterTab[0], A_InterCond_MinIntP)) >= 0)
							{
								rate = GET_PERCENT(selInterTab[0], A_InterCond_InterestRateP) / 100.0;
								if (debugFlg) printf(" Digital Quote >= Minimum  %f", rate);
							}
						}
						else if (interCondCalcRuleEn == InterCalcRule_Floating)
						{
                            /*FlooredFloater*/
                            if ((IS_NULLFLD(selInterTab[0], A_InterCond_MinIntP) == FALSE) &&
                                (IS_NULLFLD(selInterTab[0], A_InterCond_MaxIntP) == TRUE))
                            {
                                //If (Bench(i) > Minimum Value) AI = Bench(i) Else AI  = Minimum Value *//*
                                if (CMP_NUMBER(CAST_NUMBER(GET_PRICE(pricePtr, A_InstrPrice_Quote)), GET_NUMBER(selInterTab[0], A_InterCond_MinIntP)) > 0)
                                    rate = CAST_NUMBER(GET_PRICE(pricePtr, A_InstrPrice_Quote)) / 100.0;
                                else
                                    rate = GET_NUMBER(selInterTab[0], A_InterCond_MinIntP) / 100.0;

                                if (debugFlg) printf(" Floored Quote > Minim rate = Quote else rate = minimum %f", rate);
                            }
                            /* CollaredFloater */
                            else if ((IS_NULLFLD(selInterTab[0], A_InterCond_MinIntP) == FALSE) &&
                                (IS_NULLFLD(selInterTab[0], A_InterCond_MaxIntP) == FALSE))
                            {
                                /* If (Maximum Value >= Bench(i)  > Minimum Value) AI = Bench(i) */
                                /* PMSTA-35043 - RAK - 190322 - add test for minimum */
                                if (CMP_NUMBER(GET_NUMBER(selInterTab[0], A_InterCond_MaxIntP), CAST_NUMBER(GET_PRICE(pricePtr, A_InstrPrice_Quote))) >= 0 &&
                                    CMP_NUMBER(CAST_NUMBER(GET_PRICE(pricePtr, A_InstrPrice_Quote)), GET_NUMBER(selInterTab[0], A_InterCond_MinIntP)) > 0)
                                    rate = CAST_NUMBER(GET_PRICE(pricePtr, A_InstrPrice_Quote)) / 100.0;
                                /* If (Bench(i) > Maximum Value > Minimum Value) AI = Maximum Value */
                                else if (CMP_NUMBER(CAST_NUMBER(GET_PRICE(pricePtr, A_InstrPrice_Quote)), GET_NUMBER(selInterTab[0], A_InterCond_MaxIntP)) > 0 &&
                                    CMP_NUMBER(GET_NUMBER(selInterTab[0], A_InterCond_MaxIntP), GET_NUMBER(selInterTab[0], A_InterCond_MinIntP)) > 0)
                                    rate = GET_NUMBER(selInterTab[0], A_InterCond_MaxIntP) / 100.0;
                                /* If (Maximum Value > Minimum Value >= Bench(i)) AI = Minimum Value */
                                else if (CMP_NUMBER(GET_NUMBER(selInterTab[0], A_InterCond_MaxIntP), GET_NUMBER(selInterTab[0], A_InterCond_MinIntP)) > 0 &&
                                    CMP_NUMBER(GET_NUMBER(selInterTab[0], A_InterCond_MinIntP), CAST_NUMBER(GET_PRICE(pricePtr, A_InstrPrice_Quote))) >= 0)
                                    rate = GET_NUMBER(selInterTab[0], A_InterCond_MinIntP) / 100.0;
                                else
                                    rate = 0.0;

                                if (debugFlg) printf(" Collaro Max >= Quote rate = Quote, else Quote > Maxim rate = max else min > quote rate = min else rate=0 rate %f", rate);
                            }
                            /* CappedFloater */
                            else if ((IS_NULLFLD(selInterTab[0], A_InterCond_MaxIntP) == FALSE) &&
                                (IS_NULLFLD(selInterTab[0], A_InterCond_MinIntP) == TRUE))
                            {
                                /* If (Bench(i) > Maximum Value) AI = Maximum Value Else AI  = Bench(i) */
                                if (CMP_NUMBER(CAST_NUMBER(GET_PRICE(pricePtr, A_InstrPrice_Quote)), GET_NUMBER(selInterTab[0], A_InterCond_MaxIntP)) > 0)
                                    rate = GET_NUMBER(selInterTab[0], A_InterCond_MaxIntP) / 100.0;
                                else
                                    rate = CAST_NUMBER(GET_PRICE(pricePtr, A_InstrPrice_Quote)) / 100.0;

                                if (debugFlg) printf(" Capped Quote  %f", rate);
                            }
						}
					}

					if (CMP_NUMBER(rate, 0.0) != 0)
					{
						/* Computes nbr of days in the coupon period */
						ret = FIN_STNNbrOfDaysInCouponPeriod(instrPtr, interFromDate, interTillDate, hierHead, &nbrOfDaysInCouponPeriod);
					
						if (debugFlg)
						{
							YEAR_T eyear, syear;
							MONTH_T emonth, smonth;
							DAY_T eday, sday;

							DATE_Get(interTillDate, &eyear, &emonth, &eday);
							DATE_Get(interFromDate, &syear, &smonth, &sday);
							printf("\ndiff %02d/%02d/%04d -  %02d/%02d/%04d  %ld coupon period %ld", eday, emonth, eyear, sday, smonth, syear, nbrOfDaysInPeriod, nbrOfDaysInCouponPeriod);
						}

						if (nbrOfDaysInCouponPeriod != 0)
						{
							SET_NUMBER(accrInterPtr, UnitInter_UnitAccrInter, ((rate / n) * (nbrOfDaysInPeriod / (double)nbrOfDaysInCouponPeriod)));
						}
						SET_INT(accrInterPtr, UnitInter_NumPeriod, (int)nbrOfDaysInPeriod);
						SET_INT(accrInterPtr, UnitInter_DenomPeriod, nbrOfDaysInCouponPeriod);
					}
				}
			}
			break;
		}

		case InterCalcRule_Memory:
		{	
			/* ------------------------------------------------------------------------------------------- */
			/* Retrieve the coupon period of the instrument to which the �Initial Date� belongs to.        */
			/* This is the coupon period for which accrued interest is being calculated.                   */
			/* Consider this coupon period as �Di�.                                                        */
			/* Also, retrieve all the coupon period(s) which occur before the above retrieved              */
			/* coupon period. Then, for each of these coupon periods,                                      */ 
			/* calculate Coupont(starting from the first coupon period of the concerned instrument)        */
			/* and proceeding in that sequence :                                                           */
			/* Coupont =  t * interest rate / n - somme(coupons)                                           */
			/* t = It is the coupon period number of the instrument (ex: While calculating �Coupont�       */
			/* for the first coupon period of the instrument t = 1 and for second period t = 2 and so on). */
			/* n = number of coupon periods in a year.                                                     */
			/* ------------------------------------------------------------------------------------------- */
			
			double			n = 1.0;
			long			nbrOfDaysInCouponPeriod = 0, nbrOfDaysInPeriod = 0;
			NUMBER_T		strikeLevel = 0.0;
			FIN_PRICEARG_ST	priceArgSt;
            DATE_T			*benchmarkDate;
            int				benchmarkNbr = 0;
            DATETIME_T		benchmarkDT;
			
            benchmarkDT.date = 0;
            benchmarkDT.time = 0;
			
			NUMBER_T		coupon = 0.0;

            /* PMSTA-35536 - Silpakal - 191224 */
            DBA_DYNFLD_STP      *selInstrCompoTab = NULLDYNSTPTR;
            int                  selInstrCompoNbr = 0, worstInstrNbr = 0;
            DATETIME_T           fromDate;
            INSTR_UNDERLYING_CATEGORY_ENUM instrUnderlyingCategory = INSTR_UNDERLYING_CATEGORY_ENUM::None;
            PRICE_T              price = 0;
            DBA_DYNFLD_STP       compWorstInstr = mp.allocDynst(FILEINFO, A_InstrCompo);

            fromDate.time = (TIME_T)0;
            fromDate.date = interFromDate;

			DATE_T currentDate = DATE_CurrentDate();

			memset(&priceArgSt, 0, sizeof(FIN_PRICEARG_ST));

            /* PMSTA-35536 - Silpakal - 191224 */
            ret = FIN_SelectUnderlyingCompo(hierHead, fromDate, instrPtr, &selInstrCompoTab, &selInstrCompoNbr);

            if (ret == RET_SUCCEED)
            {
                mp.ownerDynStpTab(selInstrCompoTab,selInstrCompoNbr);

                if (selInstrCompoNbr == 1) /* Single Instrument */
                {
                    instrUnderlyingCategory = static_cast<INSTR_UNDERLYING_CATEGORY_ENUM>(GET_ENUM(instrPtr, A_Instr_UnderlyCatEn));
                    if (IS_NULLFLD(instrPtr, A_Instr_UnderlyInstrId))
                    {
                        MSG_SendMesg(RET_DBA_ERR_NODATA, 3, FILEINFO, "FIN_STNInterestCalculationRule", GET_CODE(instrPtr, A_Instr_Cd), "no underlying");
                        return(RET_DBA_ERR_NODATA);
                    }
                }
                else if (selInstrCompoNbr > 1)  /* Average and Worst of the Instrument*/
                {
                    instrUnderlyingCategory = static_cast<INSTR_UNDERLYING_CATEGORY_ENUM>(GET_ENUM(instrPtr, A_Instr_UnderlyCatEn));
                }
                else
                {
                    MSG_SendMesg(RET_DBA_ERR_NODATA, 3, FILEINFO, "FIN_STNInterestCalculationRule", GET_CODE(instrPtr, A_Instr_Cd), "no underlying");
                    return(RET_DBA_ERR_NODATA);
                }
            }

			if (IS_NULLFLD(selInterTab[0], A_InterCond_FirstBenchDate)) /* PMSTA-35019 - RAK - 190311 */
			{
				MSG_SendMesg(RET_DBA_ERR_NODATA, 3, FILEINFO, "FIN_STNInterestCalculationRule", GET_CODE(instrPtr, A_Instr_Cd), "FirstBenchMarkDate empty");
				return(RET_DBA_ERR_NODATA);
			}

			if (GET_DATE(selInterTab[0], A_InterCond_FirstBenchDate) > interTillDate)
			{
				/* AI will be 0.0 before first benchmark date */
				return(ret);
			}
			
			/* Coupon Strike Level = this can be fetched from either coupon_strike_level_p) */
			/* attribute or coupon_strike_level_n attribute.                                */
			/* If it is defined only in percentage, then, the amount has to be calculated   */
			/* to compare with the price.                                                   */
			/* Coupon Strike Level(%) / 100 * Exercise Quote(exer_quote_n - Instrument table) */
            
            /* PMSTA-35536 - Silpakal - 191224 */
            if ((instrUnderlyingCategory == INSTR_UNDERLYING_CATEGORY_ENUM::SingleInstrument) ||
                (instrUnderlyingCategory == INSTR_UNDERLYING_CATEGORY_ENUM::AverageBasket))
            {
                if (IS_NULLFLD(instrPtr, A_Instr_CouponStrikeLevel))
                {
                    strikeLevel = GET_PERCENT(instrPtr, A_Instr_CouponStrikeLevelP) / 100.0 * CAST_NUMBER(GET_PRICE(instrPtr, A_Instr_ExerQuote));
                }
                else
                {
                    strikeLevel = GET_NUMBER(instrPtr, A_Instr_CouponStrikeLevel);
                }
            }
            else if (instrUnderlyingCategory == INSTR_UNDERLYING_CATEGORY_ENUM::WorstOfBasket)
            {
                benchmarkDT.date = GET_DATE(selInterTab[0], A_InterCond_FirstBenchDate);
                InstrumentSTNComputation computation(hierHead, NULL, instrPtr, benchmarkDT);
                ret = computation.computeInstrumentPriceUnderlyingCategory();

                if (ret == RET_SUCCEED)
                {
                    FIN_WorstInstrumentsFromSTN(&selInstrCompoTab, &selInstrCompoNbr, computation.getInstrumentSTNComputationResult(), &worstInstrNbr);
                }

                if (worstInstrNbr >= 1)
                {
                    for (int i = 0; i < selInstrCompoNbr; i++)
                    {
                        if (FIN_InstrumentSTNIsWorstFlg(GET_ID(selInstrCompoTab[i], A_InstrCompo_InstrId), computation.getInstrumentSTNComputationResult()))
                        {
                            COPY_DYNST(compWorstInstr, selInstrCompoTab[i], A_InstrCompo);
                            price = GET_PRICE(selInstrCompoTab[i], A_InstrCompo_BasketExerPrice);
                            break;
                        }
                    }
                }
                if (IS_NULLFLD(instrPtr, A_Instr_CouponStrikeLevel))
                {
                    strikeLevel = GET_PERCENT(instrPtr, A_Instr_CouponStrikeLevelP) / 100.0 * price;
                }
            }

			if (debugFlg)
			{
				YEAR_T fyear, tyear;
				MONTH_T fmonth, tmonth;
				DAY_T fday, tday;

				DATE_Get(interFromDate, &fyear, &fmonth, &fday);
				DATE_Get(interTillDate, &tyear, &tmonth, &tday);
				printf("\n\n from %02d/%02d/%04d till %02d/%02d/%04d", fday, fmonth, fyear, tday, tmonth, tyear);

				printf(" strikeLevel = %f ", strikeLevel);
			}

			/* where n = number of coupon periods in a year */
			ret = FIN_PeriodUnitNbr((FREQUNIT_ENUM)GET_ENUM(instrPtr, A_Instr_PayFreqUnitEn),
				                    GET_TINYINT(instrPtr, A_Instr_PayFreq), FreqUnit_Year, &n);
			
			if (ret == RET_SUCCEED && CMP_NUMBER(n, 0.0) != 0)
				n = 1 / n;

			/* Computes nbr of days in the coupon period */
			if ((ret = FIN_STNNbrOfDaysInCouponPeriod(instrPtr, interFromDate, interTillDate, hierHead, &nbrOfDaysInCouponPeriod)) == RET_SUCCEED)
			{
				/* PMSTA-35460 - RAK - 190412 - Keep current benchmark date */
				/* computes benchmark date array */
                if ((ret = FIN_MCBenchmarkDate(instrPtr, selInterTab[0], interFromDate, interTillDate, &benchmarkDate, &benchmarkNbr)) == RET_SUCCEED && benchmarkNbr > 0)
				{
					/* stop on current period */
					int crt = 0;
                    while (benchmarkDate[crt] < interFromDate && crt < benchmarkNbr)
						crt++;
					
                    benchmarkDT.date = benchmarkDate[crt];

					/* PMSTA-35460 - RAK - 190412 */
					/* is current coupon paid ? (not in future) only after benchmark date */
					if (benchmarkDT.date <= currentDate && benchmarkDT.date <= interTillDate)
					{
                        price = 0;
						/* perhaps a trouble in case of underlying and instrument currencies aren't same, to verify arguments */
                        if ((ret = FIN_InstrPriceAtBenchmarkDate(instrPtr, benchmarkDT, hierHead,
                                                                 instrUnderlyingCategory, &price, compWorstInstr)) == RET_SUCCEED)
						{
							if (debugFlg)
							{
								YEAR_T year;
								MONTH_T month;
								DAY_T day;

								DATE_Get(benchmarkDT.date, &year, &month, &day);
								printf(" benchmark date %02d/%02d/%04d price %f", day, month, year, price);
							}

                            if (CMP_NUMBER(price, strikeLevel) >= 0)
							{
								/* PMSTA-35128 - RAK - 190325 - why */
								DATETIME_T fromDateTime;
								fromDateTime.date = interFromDate;
								fromDateTime.time = 0;
								/* PMSTA-35394 - RAK - 190408 -  why not */
								/*DATE_DatetimeMove(&fromDateTime, -1, Day, FALSE);*/
								DATE_DaysBetween(fromDateTime.date, interTillDate, (ACCRRULE_ENUM)GET_ENUM(instrPtr, A_Instr_AccrualRuleEn), &nbrOfDaysInPeriod, 0);

								coupon = GET_PERCENT(selInterTab[0], A_InterCond_InterestRateP) / 100.0 / n * (nbrOfDaysInPeriod / (double)nbrOfDaysInCouponPeriod);

								/* add previous no-paid coupon */
								int		i;
								bool	stop = false;
								for (i = crt - 1; i >= 0 && stop == false; i--)
								{
                                    benchmarkDT.date = benchmarkDate[i];
									/* Are previous paid ? */
                                    price = 0;
                                    if ((ret = FIN_InstrPriceAtBenchmarkDate(instrPtr, benchmarkDT, hierHead,
                                                                             instrUnderlyingCategory, &price, compWorstInstr)) == RET_SUCCEED)
									{
										if (debugFlg)
										{
											YEAR_T year;
											MONTH_T month;
											DAY_T day;

											DATE_Get(benchmarkDT.date, &year, &month, &day);
											printf("\n previous benchmark date %02d/%02d/%04d price %f ", day, month, year, price);
										}

										/* If not, add previous coupon(s) to paid coupon */
                                        if (CMP_NUMBER(price, strikeLevel) < 0)
										{
											/* PMSTA-35128 - RAK - 190402 - Add one full coupon */
											coupon += (GET_PERCENT(selInterTab[0], A_InterCond_InterestRateP) / 100.0 / n);
										}
										else /* stop because a paid coupon had paid previous non-paid coupon ! sure */
											stop = true;
									}
									else
										stop = false;
								}
							}
						}
					}

					if (debugFlg) printf("\n coupon %f", coupon);

					FREE(benchmarkDate);

					/* PMSTA-35034 - RAK - 190322 - Divide by percent */
					SET_NUMBER(accrInterPtr, UnitInter_UnitAccrInter, coupon);
					SET_INT(accrInterPtr, UnitInter_NumPeriod, (int)nbrOfDaysInPeriod);
					SET_INT(accrInterPtr, UnitInter_DenomPeriod, nbrOfDaysInCouponPeriod);
				}
			}
			break;
		}
	}

	return(ret);
}


/************************************************************************
**
**  Function    :   FIN_CalcUnitAccrInter()
**
**  Description :   Having obtained the rate structure and the quantity
**                  structure, (that can be one period, one rate) these
**                  two should be combined. Then for each combination 
**                  quantity / rate the number of day should be calculated 
**                  depending on accrual basis rule. 
**                  Thereafter, accrued interest can be calculated for each
**                  determined sub period. Total accrued interest is the
**                  sum of all these sub-periods according to the unpaid 
**                  percentage if exist.
**                 
**  Arguments   :   accrPerPtr    pointer on accrual period structure
**                                (use payment frequency, fixed exchange for
**                                computing and currency identifier, unitary 
**                                nature for init accrinterPtr)
**                  interRateTab  pointer on interest rate condition table
**                  quantTab      pointer on quantity(ies) table
**                  unpaidPtr     pointer on unpaid percentage to apply or NULL
**                  interFromDate accrued interest begin date                  
**                  interTillDate accrued interest end date                  
**                  accrInterPtr  pointer on interest rate structure to fill
**                  complexRateFlg set to TRUE if rate is complex (multi rate during period or compound interest)
**
**  Return      :   TRUE or FALSE
**
*************************************************************************/
STATIC FLAG_T FIN_CalcUnitAccrInter(FIN_ACCR_PERIOD_STP accrPerPtr, 
		                            FIN_INTERRATE_STP   interRateTab, 
		                            FIN_QUANT_STP       quantTab, 
			                        NUMBER_T           *instrChronoValPtr,
				                    DATE_T              interFromDate,
				                    DATE_T              interTillDate,
		                            DBA_DYNFLD_STP      accrInterPtr,
				                    DBA_DYNFLD_STP      instrPtr,  /* REF3693 - SSO - 990517 */
                                    DBA_HIER_HEAD_STP   hierHead, /* REF5937 - AKO - 010608 : add hierHead */
 									DBA_DYNFLD_STP		posPtr,		/* PMSTA01512-CHU-070430 */
                                    FLAG_T              *complexRateFlg) /* PMSTA05739 - DDV - 080227 - Set to TRUE if rate is complex (multi rate during period or compound interest) */
{
	DATE_PERIOD_ST period;
	DATE_T         fromDate, tillDate, tDate, tmpTillDate;
	PERCENT_T      rate  = 0.0;
	NUMBER_T       inter = 0; /* REF6004 - AKO - 011218 */
	char	       denomFlg;
	long	       daysActual, globDenom=0, usedDenom=0, maxDaysInYear;
	int            i, j, rateIndex, quantIndex, usedRateNbr=0;
	/* REF3779 - RAK - 990701 - In case of TRUE, don't truncate to 9th decimal */
	FLAG_T	       applUnitAccrIntAllDecFlag=FALSE, bCont, bFirst, bigPerFlg;
    SUBNAT_ENUM     instrSubNatEn = SubNat_None;
	INSTRNAT_ENUM	instrNat = InstrNat_None;
	FLAG_T			is_MM_or_FI_FundShareFlg = FALSE;
	NUMBER_T		posQty = 0.0;
	ID_T			calendarId = 0; /* PMSTA-22396  - SRIDHARA – 160430 */
    SUBNAT_ENUM     instrSubNat = (SUBNAT_ENUM)GET_ENUM(instrPtr, A_Instr_SubNatEn);

    memset(&period, 0, sizeof(DATE_PERIOD_ST)); /* REF6004 - AKO - 011218 */
	GEN_GetApplInfo(ApplUnitAccrIntAllDecFlag, &applUnitAccrIntAllDecFlag);

	/* PMSTA-34866 - RAK - 190222 */
    if (instrPtr != nullptr && interRateTab != nullptr && 
            interRateTab[0].interCalcRuleEn != InterCalcRule_Fixed && 
            interRateTab[0].interCalcRuleEn != InterCalcRule_GrossRate && 
            (instrSubNat == SubNat_CapProtectNotesWCoupon || instrSubNat == SubNat_ReverseConvNotesEquity ||
            instrSubNat == SubNat_ReverseConvNotesBonds || instrSubNat == SubNat_ReverseConvNotesCredit ||
            instrSubNat == SubNat_MemoryCouponNotes || instrSubNat == SubNat_EquityLinkedNotes ||
            instrSubNat == SubNat_BondsLinkedNotes || instrSubNat == SubNat_CreditLinkedNotes))  /* PMSTA-36699  - Silpakal - 191121  */
	{
		RET_CODE ret = FIN_STNInterestCalculationRule(interFromDate, interTillDate, accrInterPtr, instrPtr, hierHead);

		if (ret == RET_SUCCEED)
			return(TRUE);
		else
			return(FALSE);
	}

	/* PMSTA01512-CHU-070430 */
	if (instrPtr != NULL)
	{
		instrNat = (INSTRNAT_ENUM) GET_ENUM(instrPtr, A_Instr_NatEn);
		instrSubNatEn = (SUBNAT_ENUM) GET_ENUM(instrPtr, A_Instr_SubNatEn);
		is_MM_or_FI_FundShareFlg = (FLAG_T) (instrNat == InstrNat_FundShare  &&
									(instrSubNatEn == SubNat_MoneyMarketFundShare ||
									 instrSubNatEn == SubNat_FixedIncomeFundShare));
	}

    /* ------------------------------------------------------------------ */
    /* REF5306 - AKO - 000111                                             */
    /* use in this function compound interest method for some instruments */
    /* instrument Swap, Bond, Money Market                                */
    /* ------------------------------------------------------------------ */
	SET_NUMBER(accrInterPtr, UnitInter_UnitAccrInter, 0);
	SET_INT(accrInterPtr,    UnitInter_NumPeriod,     0);
	SET_INT(accrInterPtr,    UnitInter_DenomPeriod,   0);

	if (accrPerPtr->accrRule == AccrRule_None)
	{
		/* MSG_SendMesg(RET_GEN_ERR_INVARG, 2, FILEINFO, 
			     "FIN_CalcUnitAccrInter", "accrual rule"); */
		accrPerPtr->accrRule = AccrRule_30E_360;
	}

	/* REF3705 - SSO - 990604 if fromDate is greater than tillDate, AI is ZERO */
	if ((GET_ENUM(instrPtr, A_Instr_SubNatEn) == SubNat_AvrgRate)
	    && (interFromDate > interTillDate) )
	{
	    SET_NUMBER(accrInterPtr, UnitInter_UnitAccrInter, 0.0);
	    return(TRUE);
	}

	denomFlg = FALSE;

	/* PMSTA01512-CHU-070430 */
	if (is_MM_or_FI_FundShareFlg == TRUE && posPtr != NULL)
		posQty = GET_NUMBER(posPtr, ExtPos_Qty);

	/* REF10945 - TEB - 050316 */
#if 0
*	if ((accrPerPtr->accrRule == AccrRule_Actual_Actual ||
*	     accrPerPtr->accrRule == AccrRule_Actual_Actual_US ||
*	     accrPerPtr->accrRule == AccrRule_30E_Actual ||
*	     accrPerPtr->accrRule == AccrRule_30_Actual_US ||
*	     accrPerPtr->accrRule == AccrRule_Actual_1_Actual) &&
*	     accrPerPtr->payFreq != 0)
*	{
*       /* REF4334 - RAK - 990208 - Use current period */
*       /* for ex-date calculation and not next period !*/
*       if (interFromDate > interTillDate)
*       {
*           tDate = DATE_Move(interFromDate, ((accrPerPtr->payFreq)*-1), Month);
*	        DATE_DaysBetween(tDate, interFromDate, AccrRule_Actual_Actual, &daysActual, 0); /* PMSTA-22396  - SRIDHARA � 160430 */
*       }
*       else
*       {
*	        /* BUG376 - RAK - 970526 */
*	        tDate = DATE_Move(interFromDate, accrPerPtr->payFreq, Month);
*	        DATE_DaysBetween(interFromDate, tDate, AccrRule_Actual_Actual, &daysActual, 0); /* PMSTA-22396  - SRIDHARA � 160430 */
*       }
*
*	    denomFlg = TRUE;
*	    globDenom = daysActual * (12 / accrPerPtr->payFreq);
*	}
#endif

	/* REF11277 - TEB - 050719 - Begin */
	/* Check if period is <= 1 year or not for ACT rules */
	bigPerFlg = TRUE;

	if ( accrPerPtr->accrRule == AccrRule_Actual_Actual ||
		 accrPerPtr->accrRule == AccrRule_Actual_Actual_US ||
		 accrPerPtr->accrRule == AccrRule_30E_Actual ||
		 accrPerPtr->accrRule == AccrRule_30_Actual_US ||
		 accrPerPtr->accrRule == AccrRule_Actual_1_Actual)
	{
		/* REF11794 - TEB - 060427 - 
		   Use the old method for payment frequency less than a year */
		if (accrPerPtr->payFreq != 0 && 
			accrPerPtr->payFreq < 12)
		{
		    if (interFromDate > interTillDate)
			{
			    tDate = DATE_Move(interFromDate, ((accrPerPtr->payFreq)*-1), Month);
				DATE_DaysBetween(tDate, interFromDate, AccrRule_Actual_Actual, &daysActual, 0); /* PMSTA-22396  - SRIDHARA � 160430 */
			}
		    else
			{
				tDate = DATE_Move(interFromDate, accrPerPtr->payFreq, Month);
				DATE_DaysBetween(interFromDate, tDate, AccrRule_Actual_Actual, &daysActual, 0); /* PMSTA-22396  - SRIDHARA � 160430 */
			}

			denomFlg = TRUE;
			globDenom = daysActual * (12 / accrPerPtr->payFreq);
			bigPerFlg = FALSE;
		}
		else
		{
			/* Add one year to fromDate */
			tmpTillDate = DATE_Move(interFromDate, 1, Year);

			/* Check if it is after the tillDate */
			if (interFromDate < interTillDate &&
				DATE_Cmp(tmpTillDate, interTillDate) >= 0)
			{
				bigPerFlg = FALSE;
				denomFlg = TRUE;
				/* PMSTA02419 - RAK - 070522 - For all _Actual methods compute the same denominator */
				/* which will be 366 (for leap year) or 365 */
				/* PMSTA08777 - 091021 - RAK - Use from date ... seems to reconcile 8503 and 8726 */
				/* PMSTA-22396  - SRIDHARA � 160430 */
				DBA_GetCalendarFromInstr(instrPtr, &calendarId);
				DATE_AccrPeriod(interFromDate, interFromDate, accrPerPtr->accrRule, 12, &period, calendarId);
                globDenom = period.denom;
			}
		}
	}
	/* REF11277 - TEB - 050719 - End */

	/* Find sub-periods and compute accrued interest on each this periods */
	i=j=usedRateNbr=0;
	while (i < interRateTab->interRateNbr && j < quantTab->quantNbr)
	{
		/* BUG183 - Skip terminated interest rate condition */
		while (i < interRateTab->interRateNbr &&
               interRateTab->infoPtr[i].tillDate < interFromDate)   /* PURIFY - RAK - 000407 */
		{
			++i;
		}

		/* BUG183 - By security if all interest rate condition are terminated */
		if (i == interRateTab->interRateNbr)
			continue;

		rateIndex  = i;
		quantIndex = j;

		if (interRateTab->infoPtr[i].fromDate > quantTab->infoPtr[j].fromDate)
			fromDate = interRateTab->infoPtr[i].fromDate;
		else
			fromDate = quantTab->infoPtr[j].fromDate;

		if (interRateTab->infoPtr[i].tillDate < quantTab->infoPtr[j].tillDate)
		{
			tillDate = interRateTab->infoPtr[i].tillDate;
			++i;
		}
		else
		{
			tillDate = quantTab->infoPtr[j].tillDate;
			++j;
		}

		/* PMSTA08773 - RAK - 091021 */
		/* move code after from and till dates initialisation    */
		/* and verify if there is really a period using the rate */
		if (fromDate != tillDate)
		{
			usedRateNbr++;
		}

		if (complexRateFlg != NULL && usedRateNbr > 1)
			*complexRateFlg = TRUE;

		/* Rate depend on amount */
		if (quantTab->infoPtr[quantIndex].quant < 0.0)
			rate = interRateTab->infoPtr[rateIndex].negRate;
		else
			rate = interRateTab->infoPtr[rateIndex].posRate;

		/* REF11163 - TEB - 050616 */
		/* REF11163 - TEB - 050713 - 
		if ( (GET_ENUM(instrPtr, A_Instr_NatEn)==InstrNat_Bond ||
			  GET_ENUM(instrPtr, A_Instr_NatEn)==InstrNat_ConvertBond) &&
			 PriceCalcRule_QuoteInUnit==(PRICECALCRULE_ENUM) GET_ENUM(instrPtr, A_Instr_PriceCalcRuleEn))
		{
			rate = rate * GET_PRICE(instrPtr, A_Instr_FaceValue);
		}
		*/

		/* REF10982 - TEB - 050316 - Moved here */
		rate  = rate / 100.0; /* ?? */

		/* ------------------------------------------------------------------ */
		/* Explanation : On coupon payment date, bonds have a coupon equal to */
		/* the input coupon divided by frequency and not accrued interest on  */
		/* coupon date, except when the coupon period is long.                */
		/* ------------------------------------------------------------------ */

        /* Days number in this period */
		/* REF10945 - TEB - 050316 - Begin */
		/* REF10982 - TEB - 050316 - Begin */
		/* TEB - Explainations :
		 * I add this loop because if the accrual rule is *_act, we have to compute the denom
		 * for every year, specially if the from and till date are not in the same year,
		 * of course because of the leap years.
		 * For exemple : if fromDate is 2003/07/01 and and date is 2005/02/25 we have 
		 * to decompose the computation in following periods : 
		 * 2003/07/01 to 2003/12/31 (denom=365) to 2004/12/31 (denom=366) to 2005/02/25 (denom=365)
		 * and cumule the different AI 
		*/
		tmpTillDate = tillDate;
		bCont = TRUE;
		bFirst = TRUE;
		while (bCont==TRUE)
		{
			if ((accrPerPtr->accrRule == AccrRule_Actual_Actual ||
				 accrPerPtr->accrRule == AccrRule_Actual_Actual_US ||
				 accrPerPtr->accrRule == AccrRule_30E_Actual ||
				 accrPerPtr->accrRule == AccrRule_30_Actual_US ||
				 accrPerPtr->accrRule == AccrRule_Actual_1_Actual) &&
				 bigPerFlg == TRUE) /* REF11277 - TEB - 050719 */
			{
				if (DATE_GetYear(fromDate) != DATE_GetYear(tmpTillDate))
				{
					if (bFirst == TRUE)
					{
						tillDate = DATE_Put(DATE_GetYear(fromDate), 12, 31);
						bFirst = FALSE;
					}
					else
					{
						tillDate = DATE_Put((YEAR_T)(DATE_GetYear(fromDate)+1), 12, 31);
					}

					if(DATE_GetYear(tillDate) == DATE_GetYear(tmpTillDate))
					{
						tillDate = tmpTillDate;
						bCont = FALSE;
					}
				}
				else
				{
					tillDate = tmpTillDate;
					bCont = FALSE;
				}
			}
			else
			{
				bCont = FALSE;
			}

			/* PMSTA-22396  - SRIDHARA � 160430 */
			DBA_GetCalendarFromInstr(instrPtr, &calendarId);
			if ((accrPerPtr->accrRule == AccrRule_Actual_Actual ||
				 accrPerPtr->accrRule == AccrRule_Actual_Actual_US ||
				 accrPerPtr->accrRule == AccrRule_30E_Actual ||
				 accrPerPtr->accrRule == AccrRule_30_Actual_US ||
				 accrPerPtr->accrRule == AccrRule_Actual_1_Actual) &&
				 bigPerFlg == TRUE) /* REF11277 - TEB - 050719 */
			{
				if (fromDate > tillDate &&
					accrPerPtr->payFreq != 0)
				{
					tDate = DATE_Move(fromDate, ((accrPerPtr->payFreq)*-1), Month);
					DATE_DaysBetween(tDate, fromDate, AccrRule_Actual_Actual, &daysActual, 0); /* PMSTA-22396  - SRIDHARA � 160430 */
					denomFlg = TRUE;
					globDenom = daysActual * (12 / accrPerPtr->payFreq);
				}
				else
				{
					/* C est con, mais a cause des annees bisextiles 
					   Si on decoupe en annee on va du 31/12/A au 31/12/A+1 et 
					   on aura 2 fois de suite une annee bisex...
					   En faisant comme ca ben je l evite... Pas top, mais ca marche...
					 */
					/* REF11277 - TEB - 050719 */
					/* Eh oui ! Eric a dit : sur le plus d'un an, le denom est le nombre de jours de l'ann�e */
					DATE_AccrPeriod(tillDate, tillDate, AccrRule_Actual_Actual, accrPerPtr->payFreq, &period, calendarId); /* PMSTA-22396  - SRIDHARA � 160430 */
					denomFlg = TRUE;
					globDenom = period.denom;
				}
			}
			/* REF10945 - TEB - 050316 - End */
			/* REF10982 - TEB - 050316 - End */
			AppIncDivAccrualPos applIncludeDivAccrualPos = AppIncDivAccrualPos::includeInCashPos;

			GEN_GetApplInfo(ApplIncludeDivAccrualPosEnum, &applIncludeDivAccrualPos);

			if (!(applIncludeDivAccrualPos == AppIncDivAccrualPos::includeInStockPos &&
				GET_ENUM(instrPtr, A_Instr_NatEn) == (ENUM_T)InstrNat_Stock))
			{
				DATE_AccrPeriod(fromDate, tillDate, accrPerPtr->accrRule, accrPerPtr->payFreq, &period, calendarId); /* PMSTA-22396  - SRIDHARA � 160430 */
			}

			/* following ajustments only necessary for old accrual rules */ /* REF9085 - YST - 030612 */
			if (SCE_CheckAccrRule(accrPerPtr->accrRule) != TRUE)
			{
				/* BUG472 */
				DATE_AccrMaxDaysInYear(fromDate, tillDate, accrPerPtr->accrRule, accrPerPtr->payFreq, &maxDaysInYear);
				
				/* REF7265 - YST - 020412 - period.num should not change for swap legs (composite and non-comp.) and FRN. */
				/* It seems that the code below applies only if Actual/360, but I am not sure. */
				instrSubNatEn = (SUBNAT_ENUM) GET_ENUM(instrPtr, A_Instr_SubNatEn);

				if ((accrPerPtr->workDate == tillDate) && 			                /* BUG376 - RAK - 970526 */
					(accrPerPtr->payFreq > 0) &&                                    /* BUG441 - GRD - 970718 */
					(period.num <= (maxDaysInYear*accrPerPtr->payFreq/12)) &&       /* BUG472 - RAK - 970827 */
					(period.num > (period.denom*accrPerPtr->payFreq/12)) &&         /* BUG307 - XDI - 970319 */
					instrSubNatEn != SubNat_RecSwapFloatLeg && instrSubNatEn != SubNat_PaidSwapFloatLeg && /* REF7265 - YST - 020412 */
					instrSubNatEn != SubNat_RecSwapFixedLeg && instrSubNatEn != SubNat_PaidSwapFixedLeg && /* REF7265 - YST - 020412 */ 
					(!(FIN_IsBondOfSwap (instrPtr, hierHead))) &&                    /* REF5937 - AKO - 010608 : add hierHead */
                    (!(instrNat == InstrNat_Bond && instrSubNatEn == SubNat_None)))  /* BSA - PMSTA02087 - 080220 */
				{
					period.num = (period.denom*accrPerPtr->payFreq/12); 	        /* BUG307 - XDI - 970319 */
				}
			}

			/* Compute total accrued interest and total days in period */
			if (denomFlg == TRUE)
				usedDenom = globDenom;
			else
				usedDenom = period.denom;
         

			/* REF1079 - RAK - 971219 */
			/* Exchange rate is expressed as one unit of the income event */
			/* currency expressed in the instrument reference currency    */
			if (usedDenom != 0.0) /* ?? */
			{
				/* REF10982 - TEB - 050316 - Moved higher, before loop on years */
				/* rate  = rate / 100.0; */ /* ?? */

				if (CMP_NUMBER(accrPerPtr->fxdExch, 0.0) != 0)
				{
#if 0 /* PMSTA05739 - DDV - coumpoud instrument treated below */
					if ((  GET_ENUM(instrPtr, A_Instr_NatEn)==InstrNat_Bond ||
						   GET_ENUM(instrPtr, A_Instr_NatEn)==InstrNat_MoneyMkt || 
						   (GET_ENUM(instrPtr, A_Instr_NatEn)==InstrNat_Swap && SubNat_None!=GET_ENUM(instrPtr, A_Instr_SubNatEn))
						) 
						&&
						(InstrIrrConv_Compound == GET_ENUM(instrPtr, A_Instr_InterestRateConvEn))
					   )
					{
					   double  rateUsed=0.0, x=0.0, y=0.0, qbas=1.0;
 
					   /* REF5306 - RAK - 010214 */
					   FIN_CalcQbas((FREQUNIT_ENUM) GET_ENUM(instrPtr, A_Instr_PayFreqUnitEn), /* REF7264 - PMO */
									GET_TINYINT(instrPtr, A_Instr_PayFreq), &qbas);

					   /* REF5306 - AKO : ATTENTION, le type Long boggue la fct pow() */
					   x=(double)period.num; y=(double)usedDenom; 

					   rateUsed   = (double)(1+rate/(accrPerPtr->fxdExch*qbas));
					   inter      =  pow(rateUsed, ((x/y)*qbas)) - 1;
					}
					else
#endif
					{
						/* PMSTA1512-CHU-070430 */
						if (is_MM_or_FI_FundShareFlg == FALSE)
		    				inter = rate / accrPerPtr->fxdExch * period.num / usedDenom;
						else
							inter = rate / accrPerPtr->fxdExch * period.num * posQty;
					}
				}
				else
				{
					inter = 0.0;
				}
			}
			else
				inter = 0.0;

            /* PMSTA05739 - 080221 - DDV - coumpoud instrument treatment */
			if (GET_ENUM(instrPtr, A_Instr_InterestRateConvEn) == InstrIrrConv_Compound)
			{
				/* REF3722 - SSO - 000302 rounding with 14 significants digits */
				if (applUnitAccrIntAllDecFlag == TRUE)
				{
					inter = ((1.0 + inter) * (1.0 + GET_NUMBER(accrInterPtr, UnitInter_UnitAccrInter))) - 1;
				}
				else 
				{
					inter = AAA_TIME((1.0 + inter), (1 + GET_NUMBER(accrInterPtr, UnitInter_UnitAccrInter)), 14) - 1;
				}
			}
			else
			{
				/* REF3722 - SSO - 000302 rounding with 14 significants digits */
				if (applUnitAccrIntAllDecFlag == TRUE)
				{
					inter = inter + GET_NUMBER(accrInterPtr, UnitInter_UnitAccrInter);
				}
				else 
				{
					inter = AAA_PLUS(inter, GET_NUMBER(accrInterPtr, UnitInter_UnitAccrInter), 14);
				}
			}

			
			/*SET_NUMBER(accrInterPtr, UnitInter_UnitAccrInter, CAST_NUMBER(inter)); */ /* REF3288 - SSO - 990205 */
			SET_NUMBER(accrInterPtr, UnitInter_UnitAccrInter, inter); /* REF3693 - SSO - 990517: cast at the end */

			period.num = period.num + GET_INT(accrInterPtr, UnitInter_NumPeriod);
			SET_INT(accrInterPtr, UnitInter_NumPeriod, period.num);

			/* REF10982 - TEB - 050316 */
			if (bCont == TRUE)
			{
				/* fromDate = DATE_Put((YEAR_T)(DATE_GET_Y(fromDate)+1), 1, 1); */
				/* fromDate = DATE_Put(DATE_GET_Y(fromDate), 12, 31); */
				fromDate = tillDate;
			}
			
		} /* End while */
	}

	if ( ((GET_ENUM(instrPtr, A_Instr_SubNatEn) == SubNat_AvrgRate) /* REF3693 - SSO - 990517 */
		 || is_MM_or_FI_FundShareFlg == TRUE)
	    && (interTillDate < GET_DATE(instrPtr, A_Instr_EndDate)) )
	{
	    /* add last day AI one more time */

	    if (usedDenom != 0.0) /* ?? */
	    {
			/* PMSTA01512-CHU-070502 : retrieve last rate */
			if (is_MM_or_FI_FundShareFlg == TRUE &&
				i+1 < interRateTab->interRateNbr)
			{
				rate = interRateTab->infoPtr[i+1].posRate;
				rate = rate / 100.0;
			}
		    /* REF3693 - SSO - 990517 : WARNING: rate is already divided by 100 */
		    /* REF1079 - RAK - 971219 */
		    /* Exchange rate is expressed as one unit of the income event */
		    /* currency expressed in the instrument reference currency    */
		    if (CMP_NUMBER(accrPerPtr->fxdExch, 0.0) != 0)
			{
				if (is_MM_or_FI_FundShareFlg == FALSE)
					inter = rate / accrPerPtr->fxdExch * 1 / usedDenom;
				else
					inter = rate / accrPerPtr->fxdExch * 1 * posQty;
			}
		    else
		        inter = 0.0;

		    inter = inter + GET_NUMBER(accrInterPtr, UnitInter_UnitAccrInter);
		    /*SET_NUMBER(accrInterPtr, UnitInter_UnitAccrInter, CAST_NUMBER(inter)); */ /* REF3288 - SSO - 990205 */
		    SET_NUMBER(accrInterPtr, UnitInter_UnitAccrInter, inter); /* REF3693 - SSO - 990517: cast at the end */

		    period.num = GET_INT(accrInterPtr, UnitInter_NumPeriod) + 1; /* one day more */
		    SET_INT(accrInterPtr, UnitInter_NumPeriod, period.num);
	    }
	}

	/* REF7280 - YST - 020404 - apply instrument chrono value if necessary - for better understanding some old, unused code was deleted */
	if (instrChronoValPtr != NULL && *instrChronoValPtr != 0.0)
	{
        /* REF4269 - SSO - 000117  (100 - *unpaidPtr) instead of (*unpaidPtr) */
	    /* inter = GET_NUMBER(accrInterPtr, UnitInter_UnitAccrInter) * (100 - (*unpaidPtr)) / 100;*/ /* REF5922.3511 - AKO - 010702 */

        switch ((PRICECALCRULE_ENUM) GET_ENUM(instrPtr, A_Instr_PriceCalcRuleEn))
        {
        /*case PriceCalcRule_PartiallyPaidStocks :*/ /* REF7280 - YST/PLO - 020404 - stock never pays accrued interests */
        /* instrChronoVal = unpaid percentage for PriceCalcRule_PartiallyPaidBonds */
        case PriceCalcRule_PartiallyPaidBonds :
            /* REF5922 - AKO - 010702 : Calculation-Rule for accrued interest of partial repaid Bond         */
            /*                                                                                               */
            /* Quantity * (100 - Repaid Faktor) * Interestrate                                               */
            /* ------------------------------------------------------------------  *  b = accruedinterest    */
            /*                        100  *  a                                                              */
            /*                                                                                               */
            /*     a = number of days in the year according accrual rule                                     */
            /*     b = number of days from last payment date or issue date, till valuationdate               */
            if (usedDenom != 0.0)
            {
                inter = (  (((100.0 - (*instrChronoValPtr)) * rate) / (100.0 * usedDenom)) * period.num);
            }
        break;
        /* instrChronoVal = price calculation factor for PriceCalcRule_PriceCalculationFactor */
        case PriceCalcRule_PriceCalculationFactor :   
            /* REF7280 - YST/PLO - 020404                                                                   */
            /* we assume that bond standard calculation ruls is quote/100                                   */    
            /* otherwise the formula hereunder should be modified for each non-standard calculation rule    */
            inter = inter * (*instrChronoValPtr) * 100.0; 

        break;

        }
		/*SET_NUMBER(accrInterPtr, UnitInter_UnitAccrInter, CAST_NUMBER(inter)); */ /* REF3288 - SSO - 990205 */
	    SET_NUMBER(accrInterPtr, UnitInter_UnitAccrInter, inter); /* REF3693 - SSO - 990517: cast at the end */
	}

	SET_INT(accrInterPtr, UnitInter_DenomPeriod, usedDenom);	/* BUG184 */
	SET_ID(accrInterPtr,  UnitInter_CurrId,      accrPerPtr->currId);
	
	/* REF3779 - RAK - 990701 - In case of TRUE, don't truncate to 9th decimal */
	if (applUnitAccrIntAllDecFlag == TRUE)
	{
	    SET_NUMBER(accrInterPtr, UnitInter_UnitAccrInter, 
		GET_NUMBER(accrInterPtr, UnitInter_UnitAccrInter));
	}
	else
	{
	    /* REF3722 - SSO - 000302 rounding with 14 significants digits */
	    /* truncate the non-guaranted digits, with max precision (14) */
	    SET_NUMBER(accrInterPtr, UnitInter_UnitAccrInter, 
		CAST_MAXPREC(GET_NUMBER(accrInterPtr, UnitInter_UnitAccrInter)));
	}

	return(TRUE);
}

/************************************************************************
**
**  Function    :   FIN_CompoundInter()
**
**  Description :   Compute compounded interest.
**                 
**  Arguments   :   fromDate       
**                  tillDate    
**                  compound    compound period
**                  payFreq     payement period
**                  accrRule	accrual rule  
**                  ratePtr     rate to fill
**
**  Return      :   RET_SUCCEED or error code
**
**  Modif :  PMSTA05739 - 080221 - DDV - all the function has been rewrite for compound interest
**
*************************************************************************/
STATIC RET_CODE FIN_CompoundInter(DBA_DYNFLD_STP instrPtr,
                                  DATE_T         fromDate, 
 			                      DATE_T         tillDate, 
 			                      DATE_T         interCondBeginDate, 
                                  TINYINT_T      compoundUnitN, 
                                  FREQUNIT_ENUM  compoundUnitFreqE, 
								  PERIOD_T       payFreq,
			                      ACCRRULE_ENUM  accrRule,
								  FLAG_T		 allowCompoundFlg, /* PMSTA05878 - RAK - 080424 */
			                      PERCENT_T      *ratePtr)	
{
	DATE_PERIOD_ST  periodYearDay;
	long            compoundPeriodNbrInYear;
    double          compoundFreq;   /* REF7574 - YST - 020620 - change type long to double */
	double          freq = 0;
	DATE_T          tmpFromDate=0, tmpTillDate;
	PERCENT_T       compoundRate=1;
	long            nbAIDays=0;
	ID_T			calendarId = 0;

	/* PMSTA-42879 - SRIDHARA - 18032021 */
	YEAR_T		   tillYear;
	bool           nonLeapYear = false;
	DATE_Get(tillDate, &tillYear, NULL, NULL);
	if ((accrRule != AccrRule_SceAct365) || (payFreq != 12) || (!Cldr_IsLeap(tillYear)))
	{
		nonLeapYear = true;
	}

	periodYearDay.num = 0;
	periodYearDay.denom = 0;

	/* PMSTA05878 - RAK - 080411 */
	/* ----------------------------------------------------------------------------------- */
	/*		  | SCE AccrRule                       |  No Sce AccrRule                      */
	/* ----------------------------------------------------------------------------------- */
	/*   AI   |  Compound  (PMSTA05878)            |  Compound  (PMSTA05739)               */
	/* ----------------------------------------------------------------------------------- */
	/*   YTM  |      No   keep old YTM computation |      No                               */
	/*                                             | Since PMSTA05739 - YTM are wrong for  */
	/*                                             | "standard" instr because of YTM       */
	/*                                             | computation call SCE_FixRate() which  */
	/*                                             | call SearchInterRate() with valuation */
	/*                                             | date - end date of instrument         */
	/*                                             | and that give a BIG coupon.           */
	/* ----------------------------------------------------------------------------------- */
	/* if (SCE_CheckAccrRule(accrRule) == TRUE)
		return(RET_SUCCEED); */
	if (allowCompoundFlg == FALSE)
	{
		return(RET_SUCCEED);
	}
	
	if (compoundUnitFreqE == FreqUnit_Day)
	{
		*ratePtr /= 100.0;

		tmpFromDate=fromDate;

		if (fromDate < interCondBeginDate)
			tmpFromDate=interCondBeginDate;
		else
			tmpFromDate=fromDate;


		/* Obtain days number in year and days between from and till date */
		/* PMSTA-22396  - SRIDHARA � 160430 */
		DBA_GetCalendarFromInstr(instrPtr, &calendarId);
		DATE_AccrPeriod(tmpFromDate, tillDate, accrRule, payFreq, &periodYearDay, calendarId);

		/* Divide days number in year by compound frequency */
		compoundPeriodNbrInYear = (long) (periodYearDay.denom/compoundUnitN);	

		if (periodYearDay.num == 0)
		{
			MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO, 
					 "FIN_CompoundInter", GET_CODE(instrPtr, A_Instr_Cd), "compound days (num)");
			return(RET_FIN_ERR_INVDATA); 
		}

		if (periodYearDay.denom == 0)
		{
			MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO, 
					 "FIN_CompoundInter", GET_CODE(instrPtr, A_Instr_Cd), "compound days (denom)");
			return(RET_FIN_ERR_INVDATA); 
		}

		/* Obtain the compounding frequency in the period */
		compoundFreq = (double) periodYearDay.num / (double) compoundUnitN;

		if (compoundFreq == 0)
		{
			MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO, 
						 "FIN_CompoundInter", GET_CODE(instrPtr, A_Instr_Cd), "compound frequency");
			return(RET_FIN_ERR_INVDATA); 
		}

		/* Formula */
		*ratePtr = (pow(1.0 + (*ratePtr / compoundPeriodNbrInYear), compoundFreq)) - 1.0; 
		*ratePtr *= 100.0;

		/* PMSTA-42879 - SRIDHARA - 18032021 - Need to check the leap year for the till date as Interest Rate was wrong for ACT365*/
		if (nonLeapYear)
		{
			*ratePtr *= ((PERCENT_T)periodYearDay.denom / (PERCENT_T)periodYearDay.num); /* rate annulalisation */
		}
	}
	else
	{

		/* PMSTA-42879 - SRIDHARA - 18032021 - while Iterating through the number compounding frequencies, dpy for individual Compound units
		were wrong resulting with wrong compoundRate. So need to calculate dpy for entire payFreq */
		DBA_GetCalendarFromInstr(instrPtr, &calendarId);
		DATE_AccrPeriod(fromDate, tillDate, accrRule, payFreq, &periodYearDay, calendarId);
		compoundPeriodNbrInYear = periodYearDay.denom;

		*ratePtr /= 100;

		/* Test compound for fixed condition */ 
		FIN_PeriodUnitNbr(compoundUnitFreqE, compoundUnitN, 
						  FreqUnit_Month, &freq);


		if (freq <= 0)
		{
			MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO, 
						 "FIN_CompoundInter", GET_CODE(instrPtr, A_Instr_Cd), 
						 "compound period");
			return(RET_FIN_ERR_INVDATA);
		}

		tmpTillDate = interCondBeginDate;
		tmpFromDate=tmpTillDate;

		while (tmpTillDate <= fromDate)
		{
			tmpFromDate = tmpTillDate;
			tmpTillDate=DATE_Move(tmpTillDate, (int) freq, Month);
		}

		tmpTillDate = tmpFromDate;

		while(tmpTillDate < tillDate)
		{
			tmpFromDate = tmpTillDate;
			tmpTillDate = DATE_Move(tmpFromDate, (int) freq, Month);
			if (tmpFromDate < fromDate)
				tmpFromDate = fromDate;

			if (tmpTillDate > tillDate)
				tmpTillDate = tillDate;

			/* Obtain days number in year and days between from and till date */

			/* PMSTA-22396  - SRIDHARA � 160430 */
			DBA_GetCalendarFromInstr(instrPtr, &calendarId);
			DATE_AccrPeriod(tmpFromDate, tmpTillDate, accrRule, payFreq, &periodYearDay, calendarId);

			if (periodYearDay.num == 0)
			{
				MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO, 
						 "FIN_CompoundInter", GET_CODE(instrPtr, A_Instr_Cd), "compound days (num)");
				return(RET_FIN_ERR_INVDATA); 
			}

			if (periodYearDay.denom == 0)
			{
				MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO, 
						 "FIN_CompoundInter", GET_CODE(instrPtr, A_Instr_Cd), "compound days (denom)");
				return(RET_FIN_ERR_INVDATA); 
			}

			/* Formula */
			compoundRate *= (1.0 + (*ratePtr) * ((PERCENT_T) periodYearDay.num / (PERCENT_T)compoundPeriodNbrInYear));   /* PMSTA-42879 - SRIDHARA - 18032021 */
			nbAIDays += periodYearDay.num;
		}

		*ratePtr = (compoundRate - 1 );
		*ratePtr *= 100.0;

		/* PMSTA-42879 - SRIDHARA - 18032021 - Need to check the leap year for the till date as Interest Rate was wrong for ACT365 */
		if(nonLeapYear)
		{
            if (nbAIDays == 0)
		    {
			    MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO, 
					     "FIN_CompoundInter", GET_CODE(instrPtr, A_Instr_Cd), "compound days (AI Days)");
			    return(RET_FIN_ERR_INVDATA); 
		    }
			*ratePtr *= ((PERCENT_T)compoundPeriodNbrInYear / (PERCENT_T)nbAIDays);
		}
	}
	return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_ComputeInterFloatRate()
**
**  Description :   Compute floating rate condition value. 
**                 
**  Arguments   :   fromDate
**                  tillDate
**                  payFreq      payment frequency
**                  accrRule     accrual rule
**                  interCondPtr interest condition
**                  ratePtr      rate to fill
**
**  Return      :   RET_SUCCEED or error code
**
**  Modif       :   BUG141  - RAK - 960927 
**                  BUG387  - RAK - 970603 
**                  REF1055 - AKO - 000216 : moving busness date function created 
**                  REF7264 - 020129 - PMO : Compilation errors and warnings with C++ compiler
**                  PMSTA-43096 - Kramadevi - 10032021 : Libor Transition changes
**
*************************************************************************/
RET_CODE FIN_ComputeInterFloatRate(DBA_DYNFLD_STP    instrPtr,
                                    DATE_T            fromDate, 
			                        DATE_T            tillDate,
			                        PERIOD_T          payFreq,
			                        ACCRRULE_ENUM     accrRule,
			                        DBA_DYNFLD_STP    interCondPtr, 
			                        PERCENT_T         *ratePtr,
                                    DBA_HIER_HEAD_STP hierHead)
{
	RET_CODE       ret;
	DATETIME_T     fromShiftedDateTime;
    MemoryPool     mp;

	if (IS_NULLFLD(interCondPtr, A_InterCond_BenchInstrId))
	{
		MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO, 
			         "FIN_ComputeInterFloatRate", GET_CODE(instrPtr, A_Instr_Cd), 
			         "benchmark instrument");
		return(RET_FIN_ERR_INVDATA); 
	}

	
	DBA_DYNFLD_STP pricePtr = mp.allocDynst(FILEINFO,A_InstrPrice);

	/* -------------------------------------------------------------------------------------- */
	/* REF1055 - AKO - 000211 : we will price instrument with fromDateTime instead of	  */
	/* refDateTime. We will shift fromDate according to calendar business days.		  */
	/* fromDate shifted becomes fromShiftedDateTime, computed by advanced analytics functions */
	/* -------------------------------------------------------------------------------------- */
	fromShiftedDateTime.date = fromDate;
	fromShiftedDateTime.time = 0;

	/* REF1055 - AKO : call new function to shift price calculation date */
	if ((ret=SCE_MoveBusnessDates((SCE_ADVA_ARG_STP)NULL, /* SCE_ADVA_ARG_STP advance analytics structure */
					hierHead,
					GET_ID(interCondPtr, A_InterCond_BenchInstrId),
					interCondPtr, 
					instrPtr,
					fromShiftedDateTime,
					&fromShiftedDateTime))==RET_SUCCEED)
	{
		DATETIME_T	   FromDateTime;
		DATETIME_T     TillDateTime;
		FromDateTime.date = fromDate;
		FromDateTime.time = 0;
		TillDateTime.date = tillDate;
		TillDateTime.time = 0;

		DATE_PERIOD_ST  periodYearDayObsShift;
		periodYearDayObsShift.num = 0;
		periodYearDayObsShift.denom = 0;
		bool IRCBegDInstrBegD = FALSE; 
		YEAR_T      yr1, yr2;
		MONTH_T     mth1, mth2;
		DAY_T       dy1, dy2;
		DATE_Get(fromDate, &yr1, &mth1, &dy1);
		DATE_Get(tillDate, &yr2, &mth2, &dy2);
		int numb_of_years = yr2 - yr1;

        /*PMSTA-43096 - Kramadevi - 10032021 : Libor Transition changes*/
        if (IS_NULLFLD(interCondPtr, A_InterCond_MktConvMethodEn) == FALSE && 
            static_cast<InstrMktConvMethodEn>GET_ENUM(interCondPtr, A_InterCond_MktConvMethodEn) != InstrMktConvMethodEn::None && numb_of_years < PERP_BOND_TENURE)
        {
			DBA_DYNFLD_STP  *instrPriceTab = NULLDYNSTPTR;
			int	            instrPriceNbr = 0;
			DATETIME_T	   refFromDate;
			DATETIME_T     refTillDate;

			int validity;
			GEN_GetApplInfo(ApplPricePeriodValidity, &validity);
			refFromDate.date = DATE_Move(fromDate, (-1) * validity, Day);
			refFromDate.time = 0;
			refTillDate.date = tillDate;
			refTillDate.time = 0;

			DBA_DYNFLD_STP  	selArgPtr = NULLDYNST;
			selArgPtr = mp.allocDynst(FILEINFO, Sel_Arg);

			SET_ID(selArgPtr, Sel_Arg_Id1, GET_ID(interCondPtr, A_InterCond_BenchInstrId));
			SET_FLAG(selArgPtr, Sel_Arg_DistinctFlg, FALSE);
			SET_DATETIME(selArgPtr, Sel_Arg_TillDate, refTillDate);
			SET_DATETIME(selArgPtr, Sel_Arg_FromDate, refFromDate);

			DBA_Select2(InstrPrice, UNUSED, Sel_Arg, selArgPtr,
				A_InstrPrice, &instrPriceTab, UNUSED, UNUSED,
				&instrPriceNbr, UNUSED, UNUSED);

			std::map<DATE_T, NUMBER_T> dailyInstrPriceMap;
			if (instrPriceTab != NULL)
			{
				for (int i_price = 0; i_price < instrPriceNbr; i_price++)
				{
					dailyInstrPriceMap.insert(std::pair<DATE_T, PRICE_T>(GET_DATETIME(instrPriceTab[i_price], A_InstrPrice_QuoteDate).date, GET_PRICE(instrPriceTab[i_price], A_InstrPrice_Price)));
				}
			}
			if (instrPriceNbr > 0 && instrPriceTab != nullptr)
				DBA_FreeDynStTab(instrPriceTab, instrPriceNbr, A_InstrPrice);

            double          compFreq = 0;
            DATETIME_T      nextDate, shiftDate, locTillDate;
            nextDate.date = fromShiftedDateTime.date;
			/*PMSTA-45806 - Senthil Kumar - 13-Aug-2021 For Moneymarket, as there is no payment frequency defined, tilldate is always considered 
			to be instrument end date - PMSTA-45806*/

			if (GET_ENUM(instrPtr, A_Instr_NatEn) == InstrNat_MoneyMkt)
			{
				locTillDate.date = GET_DATE(instrPtr, A_Instr_EndDate);
			}
			else
			{
				locTillDate.date = tillDate;
			}
            locTillDate.time = 0;
            DATE_PERIOD_ST  periodYearDay, daysInYear; /*PMSTA-45702 - Kramadevi - 26082021*/
            DATE_T          tmpFromDate = 0, tmpTillDate;
            PERCENT_T       compoundRate = 1, locRate = 0;
            long            nbAIDays = 0, extraDays = 0; /*PMSTA-46082 - Kramadevi - 31082021*/
            ID_T			calendarId = 0;
            FLAG_T          simpleInterestFlg = 0, isAccrRule_30_360Flg = 0, isNarrowDefinitionFlg = 0, lockOutDayFlg = 0;
            YEAR_T          y1,y2;
            MONTH_T         m1,m2;
            DAY_T           d1,d2;
            int             lockOutDays = 0, lookBackDays = 0, resetFreq = 1;
            DATETIME_T      locFromShiftedDate = fromShiftedDateTime;/*PMSTA-46091 - Kramadevi - 19082021*/

            periodYearDay.num = 0;
            periodYearDay.denom = 0;

            /*PMSTA-45702 - Kramadevi - 26082021*/
            daysInYear.num = 0;
            daysInYear.denom = 0;
			
			int onebusinessday = 1;
			FLAG_T     isBusinessDateFlg;

			/*When the begin date is a holiday and the business day convention is NextInMonth, move to next business day*/
			DBA_GetCalendarFromInstr(instrPtr, &calendarId);
			SCE_CldrIsBusinessDate(fromShiftedDateTime, calendarId, &isBusinessDateFlg);
			if (isBusinessDateFlg == FALSE && (CALNEXTBUSDATERULE_ENUM)GET_ENUM(instrPtr, A_Instr_BusDayConvEn) == CalNextBusDateRule_NextInMonth && (static_cast<InstrLookbackConvEn> GET_ENUM(interCondPtr, A_InterCond_LookbackConvEn)
				!= InstrLookbackConvEn::ObservationShift))/*PMSTA-46787 - SENTHILKUMAR - 29102021*/
			{
				/*PMSTA-46783 - SENTHILKUMAR - 03112021*/
				DAY_T date_30360 = 0;
				DATETIME_T busconvTillDate;
				CALNEXTBUSDATERULE_ENUM	nextBusDateEn = (CALNEXTBUSDATERULE_ENUM)GET_ENUM(instrPtr, A_Instr_BusDayConvEn);
				SCE_CldrNextBusinessDate(instrPtr, calendarId, &nextBusDateEn, fromShiftedDateTime, &busconvTillDate);
				DATE_Get((DATE_T)busconvTillDate.date, (YEAR_T *)NULL, (MONTH_T *)NULL, (DAY_T *)&date_30360);
				if (date_30360 == 31 && ((ACCRRULE_ENUM)GET_ENUM(instrPtr, A_Instr_AccrualRuleEn) == AccrRule_30_360 ||
					(ACCRRULE_ENUM)GET_ENUM(instrPtr, A_Instr_AccrualRuleEn) == AccrRule_30E_360 ||
					(ACCRRULE_ENUM)GET_ENUM(instrPtr, A_Instr_AccrualRuleEn) == AccrRule_30_360_1 ||
					(ACCRRULE_ENUM)GET_ENUM(instrPtr, A_Instr_AccrualRuleEn) == AccrRule_30_360_US ||
					(ACCRRULE_ENUM)GET_ENUM(instrPtr, A_Instr_AccrualRuleEn) == AccrRule_30_360_FebAdj ||
					(ACCRRULE_ENUM)GET_ENUM(instrPtr, A_Instr_AccrualRuleEn) == AccrRule_30_360_Def))
				{
					onebusinessday = -1;
					SCE_CldrAddBusinessDays(instrPtr, calendarId, &onebusinessday, fromShiftedDateTime, &locFromShiftedDate, GET_ENUM(interCondPtr, A_InterCond_MktConvMethodEn));
				}
				else
				{
					fromShiftedDateTime = busconvTillDate;
					if (static_cast<InstrLookbackConvEn> GET_ENUM(interCondPtr, A_InterCond_LookbackConvEn)
						== InstrLookbackConvEn::NarrowDefinition)
						locFromShiftedDate = busconvTillDate;
				}
			}
            else if (isBusinessDateFlg == FALSE) /*PMSTA-46091 - Kramadevi - 19082021*//*PMSTA-46261 - SENTHILKUMAR - 07092021*/
            {
                /*If interest period start date falls on holiday then, the shifting should start from the previous day,
                as we will be using previous day's interest rate*/
                onebusinessday = -1;
                SCE_CldrAddBusinessDays(instrPtr, calendarId, &onebusinessday, fromShiftedDateTime, &locFromShiftedDate, GET_ENUM(interCondPtr, A_InterCond_MktConvMethodEn));
            }

            /*Get the Compound Frequency Unit*/
            FIN_PeriodUnitNbr((FREQUNIT_ENUM)GET_ENUM(interCondPtr, A_InterCond_CompoundFreqUnitEn),
                GET_TINYINT(interCondPtr, A_InterCond_CompoundFreq),
                FreqUnit_Day, &compFreq);

            if (compFreq < 0)
            {
                MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO,
                    "FIN_ComputeInterFloatRate", GET_CODE(instrPtr, A_Instr_Cd),
                    "compound period");
                return(RET_FIN_ERR_INVDATA);
            } 

            if ((GET_ENUM(interCondPtr, A_InterCond_MktConvMethodEn) == (int)InstrMktConvMethodEn::LookBack ||
                GET_ENUM(interCondPtr, A_InterCond_MktConvMethodEn) == (int)InstrMktConvMethodEn::LookbackWithLockout) &&
                GET_TINYINT(interCondPtr, A_InterCond_LookbackDays) > 0)
            {
                if (static_cast<InstrLookbackConvEn> GET_ENUM(interCondPtr, A_InterCond_LookbackConvEn)
                    == InstrLookbackConvEn::None)
                    return(RET_SUCCEED);

                lookBackDays = (-1)*(int)GET_TINYINT(interCondPtr, A_InterCond_LookbackDays);

                /*Obtain the number days between from date and end date*/
                /*PMSTA-46091 - Kramadevi - 17082021*/
                DATE_AccrPeriod(fromShiftedDateTime.date, tillDate, accrRule, Day, &periodYearDay, calendarId);

                if (static_cast<InstrLookbackConvEn> GET_ENUM(interCondPtr, A_InterCond_LookbackConvEn)
                    == InstrLookbackConvEn::NarrowDefinition)
                {
                    isNarrowDefinitionFlg = TRUE;
                }
                else if (static_cast<InstrLookbackConvEn> GET_ENUM(interCondPtr, A_InterCond_LookbackConvEn)
                    == InstrLookbackConvEn::ObservationShift)
                {
					DATE_T previous_pay_date, next_pay_date;
					previous_pay_date = DATE_Move(fromShiftedDateTime.date, -1 * payFreq, Month);
					next_pay_date = DATE_Move(GET_DATE(instrPtr, A_Instr_BeginDate), payFreq, Month);
					if (DATE_Cmp(fromShiftedDateTime.date, next_pay_date) < 0 && GET_DATE(interCondPtr, A_InterCond_BeginDate) != GET_DATE(instrPtr, A_Instr_BeginDate) && DATE_Between(previous_pay_date, GET_DATE(instrPtr, A_Instr_BeginDate), GET_DATE(interCondPtr, A_InterCond_BeginDate)) == TRUE)
					{
						DATE_AccrPeriod(fromShiftedDateTime.date, GET_DATE(interCondPtr, A_InterCond_BeginDate), accrRule, Day, &periodYearDayObsShift, calendarId);
						fromShiftedDateTime.date = GET_DATE(interCondPtr, A_InterCond_BeginDate);
						IRCBegDInstrBegD = TRUE;
						periodYearDay.num = periodYearDay.num - periodYearDayObsShift.num;
					}
                    /*Shift the from date and end date backwards by lookback days */
                    if (isBusinessDateFlg == FALSE) /*PMSTA-46091 - Kramadevi - 19082021*/
                    {
                        SCE_CldrAddBusinessDays(instrPtr, calendarId, &lookBackDays, locFromShiftedDate, &fromShiftedDateTime, GET_ENUM(interCondPtr, A_InterCond_MktConvMethodEn));
                    }
                    else
                    {
                        SCE_CldrAddBusinessDays(instrPtr, calendarId, &lookBackDays, fromShiftedDateTime, &fromShiftedDateTime, GET_ENUM(interCondPtr, A_InterCond_MktConvMethodEn));
                    }
                    /*PMSTA-46082 - Kramadevi - 19082021*/
                    if (accrRule == AccrRule_30_360 || accrRule == AccrRule_30E_360 || accrRule == AccrRule_30_360_1 || accrRule == AccrRule_30_360_US ||
                        accrRule == AccrRule_30_360_FebAdj || accrRule == AccrRule_30_360_Def || accrRule == AccrRule_None)
                    {
                        DATE_Get(fromShiftedDateTime.date, &y1, &m1, &d1);

                        int     inc = 0, calConv = 0;
                        long    i, ds1;
                        DATESTR tillShiftedDate;

                        tillShiftedDate.d = (INTI)d1;
                        tillShiftedDate.m = (INTI)m1;
                        tillShiftedDate.y = (INTI)y1;

                        inc = (periodYearDay.num > (0 ? 1 : -1));
                        ds1 = (periodYearDay.num > 0 ? periodYearDay.num : -periodYearDay.num);

                        if ((SCE_Convert_CALCONV(accrRule, &calConv)) != TRUE)
                        {
                            MSG_SEND_ERR_SCE2("SCE_Convert_CALCONV", GET_CODE(instrPtr, A_Instr_Cd));
                        }
                        for (i = 1; i <= ds1; i++)
                        {
                            /*PMSTA-46082 - Kramadevi - 31082021: while adding total number of days to be accrued to the 
                            shifted from date, feb 29 and feb 30 will be considered for 30/360 accrual rule */
                            if (tillShiftedDate.m == 2 && tillShiftedDate.d == 28 && Cldr_IsLeap(tillShiftedDate.y) == FALSE)
                            {
                                for (int j = 0; j < 2; j++)
                                {
                                    if (i < ds1)  /*PMSTA-46260 SENTHILKUMAR - 06092021*/
                                    {
                                        i++;
                                        extraDays++;
                                    }
                                }
                            }
							else if (tillShiftedDate.m == 2 && tillShiftedDate.d == 29 && Cldr_IsLeap(tillShiftedDate.y) == TRUE)
							{
								if (i < ds1) /*PMSTA-46260 SENTHILKUMAR - 06092021*/
								{
									i++;
									extraDays++;
								}
							}
                            tillShiftedDate = Cldr_AddDays(&tillShiftedDate, (INTL)inc, (CALCONV)calConv, NULL);                            
                        }
                        ret = SCE_SCEDate2Date(&tillShiftedDate, &(tillDate));
                    }
                    else
                    {
                        tillDate = DATE_Move(fromShiftedDateTime.date, (int)periodYearDay.num, Day);
                    }
                    tmpFromDate = fromShiftedDateTime.date;
                }
            }

            if ((GET_ENUM(interCondPtr, A_InterCond_MktConvMethodEn) == (int)InstrMktConvMethodEn::Lockout ||
                GET_ENUM(interCondPtr, A_InterCond_MktConvMethodEn) == (int)InstrMktConvMethodEn::LookbackWithLockout) &&
                GET_TINYINT(interCondPtr, A_InterCond_LockoutDays) > 0)
            {
                /*Lockout will be applied only if the valuation date is in maturity period. Else it will work
                similar to Plain Arrears*/
				/*PMSTA-45806 - Senthil Kumar - 13-Aug-2021 For Moneymarket, as there is no payment frequency defined, this should be skipped */
				if (GET_ENUM(instrPtr, A_Instr_NatEn) != InstrNat_MoneyMkt)
				{
					locTillDate.date = DATE_Move(fromDate, payFreq, Month);
				}
				/*PMSTA-46600 SENTHILKUMAR - 20102021*/
				if (GET_TINYINT(interCondPtr, A_InterCond_LockoutDays) > 0)
				{
					if (static_cast<InstrLookbackConvEn> GET_ENUM(interCondPtr, A_InterCond_LookbackConvEn)
						== InstrLookbackConvEn::ObservationShift)
					{
						long numdaysshifted = 0;
						SCE_CldrDaysBetweenDates(fromShiftedDateTime.date, fromDate, ((ACCRRULE_ENUM)GET_ENUM(instrPtr, A_Instr_AccrualRuleEn)), &numdaysshifted, calendarId);
						lockOutDays = 2*numdaysshifted;
					}
					/*PMSTA-46600 SENTHILKUMAR - 17102021*/
					if (IS_NULLFLD(instrPtr, A_Instr_LastCoupDate) == FALSE && DATE_Cmp(locTillDate.date, GET_DATE(instrPtr, A_Instr_LastCoupDate)) >= 0)
					{
						locTillDate.date = GET_DATE(instrPtr, A_Instr_LastCoupDate);
					}
					else if (IS_NULLFLD(instrPtr, A_Instr_EndDate) == FALSE && DATE_Between(DATE_Move(DATE_Move(GET_DATE(instrPtr, A_Instr_EndDate), (-1)*payFreq, Month), lockOutDays, Day), locTillDate.date, GET_DATE(instrPtr, A_Instr_EndDate)) || DATE_Between(GET_DATE(instrPtr, A_Instr_EndDate), locTillDate.date, DATE_Move(GET_DATE(instrPtr, A_Instr_EndDate), payFreq, Month)))
					{
						locTillDate.date = GET_DATE(instrPtr, A_Instr_EndDate);
					}
					locTillDate.time = 0;
					if ((locTillDate.date == GET_DATE(instrPtr, A_Instr_EndDate)) || (locTillDate.date == GET_DATE(instrPtr, A_Instr_LastCoupDate)))
					{
						if ((CALNEXTBUSDATERULE_ENUM)GET_ENUM(instrPtr, A_Instr_BusDayConvEn) != CalNextBusDateRule_Default)
						{
							CALNEXTBUSDATERULE_ENUM	nextBusDateEn = (CALNEXTBUSDATERULE_ENUM)GET_ENUM(instrPtr, A_Instr_BusDayConvEn);
							SCE_CldrNextBusinessDate(instrPtr, calendarId, &nextBusDateEn, locTillDate, &locTillDate);
						}
						/*PMSTA-46356 SENTHILKUMAR - 24092021 To apply lookback and lockout properly for observation shift*/
						if (static_cast<InstrLookbackConvEn> GET_ENUM(interCondPtr, A_InterCond_LookbackConvEn)
							== InstrLookbackConvEn::ObservationShift)
						{
							long numdaysshifted = 0, numdaysshifted_count = 0;
							int onedaycount = -1;
							DATETIME_T lockshifteddate;
							lockshifteddate = locTillDate;
							lockOutDays = SCE_CldrDaysBetweenDates(fromShiftedDateTime.date, fromDate, ((ACCRRULE_ENUM)GET_ENUM(instrPtr, A_Instr_AccrualRuleEn)), &numdaysshifted, calendarId);
							while (numdaysshifted_count < numdaysshifted)
							{
								lockshifteddate.date = DATE_Move(lockshifteddate.date, onedaycount, Day);
								SCE_CldrDaysBetweenDates(lockshifteddate.date, locTillDate.date, ((ACCRRULE_ENUM)GET_ENUM(instrPtr, A_Instr_AccrualRuleEn)), &numdaysshifted_count, calendarId);
							}
							locTillDate = lockshifteddate;
						}
						lockOutDays = (-1)*(int)GET_TINYINT(interCondPtr, A_InterCond_LockoutDays);
						SCE_CldrAddBusinessDays(instrPtr, calendarId, &lockOutDays, locTillDate, &locTillDate, GET_ENUM(interCondPtr, A_InterCond_MktConvMethodEn));
						if (tillDate >= locTillDate.date)
							lockOutDayFlg = TRUE;
					}
				}
                if (lockOutDayFlg == TRUE)
                {
                    shiftDate = locTillDate;

                    if (isNarrowDefinitionFlg == TRUE)
                    {
                        /*Obtain the intrument price from the shiftDate*/
                        SCE_CldrAddBusinessDays(instrPtr, calendarId, &lookBackDays, locTillDate, &locTillDate, GET_ENUM(interCondPtr, A_InterCond_MktConvMethodEn));
                    }

					std::map<DATE_T, NUMBER_T>::iterator itr = dailyInstrPriceMap.find(locTillDate.date);
					if (itr != dailyInstrPriceMap.end())
					{
						SET_PRICE(pricePtr, A_InstrPrice_Price, CAST_PRICE((*itr).second));
					}
					else
					{
						itr = dailyInstrPriceMap.upper_bound(locTillDate.date);
						if (itr != dailyInstrPriceMap.begin())
							itr--;
						if (itr != dailyInstrPriceMap.end())
						{
							SET_PRICE(pricePtr, A_InstrPrice_Price, CAST_PRICE((*itr).second));
						}
					}
                    locRate = GET_PRICE(pricePtr, A_InstrPrice_Price);
                    /*Restoring the locked date*/
                    locTillDate = shiftDate;
                }
            }

            /*if compounding frequency is 0, do simple interest calculation*/
            if (compFreq == 0)
            {
                simpleInterestFlg = TRUE;
                compoundRate = 1; /*later we subract with one*/
                compFreq = resetFreq; /*As compFreq is 0 for simple interest. assign with resetFreq to execute the same code without much duplicate code*/
            }

            /*PMSTA-45702 - Kramadevi - 26082021*/
            DATE_T      nextPayDate = DATE_Move(fromShiftedDateTime.date, payFreq, Month);
            DATE_AccrPeriod(fromShiftedDateTime.date, nextPayDate, accrRule, Day, &daysInYear, calendarId);

            /*The interest rate is picked based on the Reset Frequency Unit,
                so get the next Reset frequency date on which the interest rate has to be picked  */          
            SCE_CldrAddBusinessDays(instrPtr, calendarId, &resetFreq, fromShiftedDateTime, &nextDate, GET_ENUM(interCondPtr, A_InterCond_MktConvMethodEn));
            
            /*In the process of getting the next business day we might end up getting a date which is greater 
            than till date sometimes. So in such cases we need to make sure the next date is not going beyond tilldate*/
            while (nextDate.date > tillDate) //PMSTA-45681
                nextDate.date = DATE_Move(nextDate.date, -1, Day);

            while (fromShiftedDateTime.date < tillDate)
            {                
                tmpTillDate = GET_DATE(interCondPtr, A_InterCond_BeginDate);
                tmpFromDate = tmpTillDate;

				/*PMSTA-45257 - SENTHILKUMAR - 27102021*/
				if (tmpTillDate > fromDate && (fromShiftedDateTime.date == GET_DATE(instrPtr, A_Instr_BeginDate)|| fromShiftedDateTime.date == GET_DATE(instrPtr, A_Instr_DatedDate)) && (static_cast<InstrLookbackConvEn> GET_ENUM(interCondPtr, A_InterCond_LookbackConvEn)
					!= InstrLookbackConvEn::ObservationShift))
				{
					DATE_AccrPeriod(fromDate, tmpTillDate, accrRule, Day, &periodYearDay, calendarId);
					nbAIDays += periodYearDay.num;
				}

				if (IRCBegDInstrBegD == TRUE)
				{
					IRCBegDInstrBegD = FALSE;
					nbAIDays += periodYearDayObsShift.num;
				}
                if ((static_cast<InstrMktConvMethodEn>GET_ENUM(interCondPtr, A_InterCond_MktConvMethodEn)
                    == InstrMktConvMethodEn::LookBack ||
                    static_cast<InstrMktConvMethodEn>GET_ENUM(interCondPtr, A_InterCond_MktConvMethodEn)
                    == InstrMktConvMethodEn::LookbackWithLockout) &&
                    static_cast<InstrLookbackConvEn> GET_ENUM(interCondPtr, A_InterCond_LookbackConvEn)
                    == InstrLookbackConvEn::ObservationShift)
                {
                    /*In case of observation shift the from date might be prior to instrument begin date
                    So overriding it with backward shifted from date*/
                    tmpTillDate = fromShiftedDateTime.date;
                    tmpFromDate = tmpTillDate;                   
                }
                while (tmpTillDate <= fromShiftedDateTime.date)
                {
                    tmpFromDate = tmpTillDate;
                    tmpTillDate = DATE_Move(tmpTillDate, (int)compFreq, Day);
                }

                tmpTillDate = tmpFromDate;

                /*if the SCE_CldrAddBusinessDays function results a date greater than till date, then keep reducing 
                the date by 1 day to make sure we are not going beyond the end date*/
                while (nextDate.date > tillDate)
                    nextDate.date = DATE_Move(nextDate.date, -1, Day);

				long d_febholidaycnt = -1;
                while (tmpTillDate < nextDate.date)
                {
                    tmpFromDate = tmpTillDate;

                    tmpTillDate = DATE_Move(tmpFromDate, (int)compFreq, Day);
                    if (tmpFromDate < fromShiftedDateTime.date)
                        tmpFromDate = fromShiftedDateTime.date;

                    if (tmpTillDate > nextDate.date)
                        tmpTillDate = nextDate.date;

                    /* Obtain days number in year and days between from and till date */
                    DBA_GetCalendarFromInstr(instrPtr, &calendarId);
                    DATE_AccrPeriod(tmpFromDate, tmpTillDate, accrRule, Day, &periodYearDay, calendarId);

                    /*For daily Reset Frequency, when the tmpFromDate is 30 and tmpTillDate is 31 and the accrual rule is 30/360
                    the periodYearDay.num value is 0. that time we should not return from here instead skip 31 adn get the next date */
                    if (((ACCRRULE_ENUM)GET_ENUM(instrPtr, A_Instr_AccrualRuleEn) == AccrRule_30_360 ||
                        (ACCRRULE_ENUM)GET_ENUM(instrPtr, A_Instr_AccrualRuleEn) == AccrRule_30E_360 ||
                        (ACCRRULE_ENUM)GET_ENUM(instrPtr, A_Instr_AccrualRuleEn) == AccrRule_30_360_1 ||
                        (ACCRRULE_ENUM)GET_ENUM(instrPtr, A_Instr_AccrualRuleEn) == AccrRule_Actual_1_360 ||
                        (ACCRRULE_ENUM)GET_ENUM(instrPtr, A_Instr_AccrualRuleEn) == AccrRule_Actual_360 ||
                        (ACCRRULE_ENUM)GET_ENUM(instrPtr, A_Instr_AccrualRuleEn) == AccrRule_30_360_US ||
                        (ACCRRULE_ENUM)GET_ENUM(instrPtr, A_Instr_AccrualRuleEn) == AccrRule_30_360_FebAdj ||
                        (ACCRRULE_ENUM)GET_ENUM(instrPtr, A_Instr_AccrualRuleEn) == AccrRule_30_360_Def ||
                        (ACCRRULE_ENUM)GET_ENUM(instrPtr, A_Instr_AccrualRuleEn) == AccrRule_None) &&
                        (periodYearDay.num == 0 || periodYearDay.num == 3))
                    {
                        isAccrRule_30_360Flg = true;
                        DATE_Get(tmpFromDate, &y1, &m1, &d1);
                        DATE_Get(tmpTillDate, &y2, &m2, &d2);
                        if (d1 == 31 || d2 == 31)
                        {
                            if (d1 == 30 && d2 == 31 && tmpTillDate < tillDate)
                            {   
                                /* Each months have 30 days, 31st is assumed to be the 30th. */
                                continue;
                            }
                            else
                            {
                                /* Each months have 30 days, 31st is assumed to be the 30th. */
                                nextDate.date = DATE_Move(tmpTillDate, resetFreq, Day);
                                tmpTillDate = nextDate.date;                                
                                continue;
                            }
                        }
                    }
                    else if (periodYearDay.num == 0)
                    {
                        MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO,
                            "FIN_CompoundInter", GET_CODE(instrPtr, A_Instr_Cd), "compound days (num)");
                        return(RET_FIN_ERR_INVDATA);
                    }

                    if (periodYearDay.denom == 0)
                    {
                        MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO,
                            "FIN_CompoundInter", GET_CODE(instrPtr, A_Instr_Cd), "compound days (denom)");
                        return(RET_FIN_ERR_INVDATA);
                    }
                    
                    if (isAccrRule_30_360Flg == TRUE)
                    {
                        DATE_Get(fromShiftedDateTime.date, &y1, &m1, &d1);
                        fromShiftedDateTime.date = (d1 == 31) ? DATE_Move(fromShiftedDateTime.date, -1, Day) : fromShiftedDateTime.date;

						if (static_cast<InstrLookbackConvEn> GET_ENUM(interCondPtr, A_InterCond_LookbackConvEn)
							== InstrLookbackConvEn::ObservationShift)
						{
							if (m1 == 2)
							{
								DATE_Get(fromShiftedDateTime.date, &y2, &m2, &d2);
								DATESTR tmpdate2searchstr;
								DATE_T tmpdate2search;
								if (Cldr_IsLeap(y2) == FALSE)
									d2 = 28;
								else
									d2 = 29;
								tmpdate2searchstr.y = y2;
								tmpdate2searchstr.m = m2;
								tmpdate2searchstr.d = d2;
								SCE_SCEDate2Date(&tmpdate2searchstr, &tmpdate2search);
								if (DATE_Between(fromShiftedDateTime.date, tmpdate2search, nextDate.date) && d_febholidaycnt == -1)
								{
									DATE_DaysBetween(fromShiftedDateTime.date, tmpdate2search, AccrRule_None, &d_febholidaycnt,0);
								}
								/*PMSTA-46082 - Kramadevi - 31082021 : Use the 28th Feb interest rate for 29th Feb and 30th Feb*/
								if ((d1 == 28 && Cldr_IsLeap(y1) == FALSE) || (d1 == 29 && Cldr_IsLeap(y1) == TRUE) || d_febholidaycnt == 0)
								{
									DATE_Get(tillDate, &y1, &m1, &d1);
									if (m1 == 3 && d1 == 1)
									{
										/*PMSTA-46260 SENTHILKUMAR - 06092021*/
										if (extraDays == 0)
										{
											periodYearDay.num = 1;
										}
										else if (extraDays == 1)
										{
											periodYearDay.num = 2;
										}
										else
										{
											periodYearDay.num = periodYearDay.num;
										}
									}
								}
								if(d_febholidaycnt>-1)
									d_febholidaycnt--;
							}
						}
                    }

                    if (((isNarrowDefinitionFlg == TRUE && lockOutDayFlg == TRUE) || lockOutDayFlg == TRUE)
                        && DATE_Cmp(fromShiftedDateTime.date, locTillDate.date) >= 0)
                    {
                        /*if the date is equal or after lockout date apply the locRate */
                        SET_PRICE(pricePtr, A_InstrPrice_Price, CAST_PRICE(locRate));
                    }
                    else if (isNarrowDefinitionFlg == TRUE)
                    {
                        if (isBusinessDateFlg == FALSE) /*PMSTA-46091 - Kramadevi - 19082021*/
                        {
                            SCE_CldrAddBusinessDays(instrPtr, calendarId, &lookBackDays, locFromShiftedDate, &shiftDate, GET_ENUM(interCondPtr, A_InterCond_MktConvMethodEn));
                        }
                        else
                        {
                            /*Obtain the intrument price from the shiftDate*/
                            SCE_CldrAddBusinessDays(instrPtr, calendarId, &lookBackDays, fromShiftedDateTime, &shiftDate, GET_ENUM(interCondPtr, A_InterCond_MktConvMethodEn));
                        }
						std::map<DATE_T, NUMBER_T>::iterator itr = dailyInstrPriceMap.find(shiftDate.date);
						if (itr != dailyInstrPriceMap.end())
						{
							SET_PRICE(pricePtr, A_InstrPrice_Price, CAST_PRICE((*itr).second));
						}
						else
						{
							itr = dailyInstrPriceMap.upper_bound(shiftDate.date);
							if (itr != dailyInstrPriceMap.begin())
								itr--;
							if (itr != dailyInstrPriceMap.end())
							{
								SET_PRICE(pricePtr, A_InstrPrice_Price, CAST_PRICE((*itr).second));
							}
						}

                    }
                    else  if (lockOutDayFlg == TRUE && DATE_Cmp(fromShiftedDateTime.date, locTillDate.date) >= 0)
                    {
                        /*if the date is equal or after lockout date apply the locRate */
                        SET_PRICE(pricePtr, A_InstrPrice_Price, CAST_PRICE(locRate));
                    }
                    else
                    {
						/*PMSTA-46261 - SENTHILKUMAR - 07092021*/
						if (isBusinessDateFlg == FALSE && (GET_ENUM(interCondPtr, A_InterCond_MktConvMethodEn) == (int)InstrMktConvMethodEn::PlainArrears ||
							GET_ENUM(interCondPtr, A_InterCond_MktConvMethodEn) == (int)InstrMktConvMethodEn::Lockout))
						{
							std::map<DATE_T, NUMBER_T>::iterator itr = dailyInstrPriceMap.find(locFromShiftedDate.date);
							if (itr != dailyInstrPriceMap.end())
							{
								SET_PRICE(pricePtr, A_InstrPrice_Price, CAST_PRICE((*itr).second));
							}
							else
							{
								itr = dailyInstrPriceMap.upper_bound(locFromShiftedDate.date);
								if (itr != dailyInstrPriceMap.begin())
									itr--;
								if (itr != dailyInstrPriceMap.end())
								{
									SET_PRICE(pricePtr, A_InstrPrice_Price, CAST_PRICE((*itr).second));
								}
							}

						}
						else
						{
							/*Obtain the interest rate for fromShiftedDateTime*/
							std::map<DATE_T, NUMBER_T>::iterator itr = dailyInstrPriceMap.find(fromShiftedDateTime.date);
							if (itr != dailyInstrPriceMap.end())

							{
								SET_PRICE(pricePtr, A_InstrPrice_Price, CAST_PRICE((*itr).second));
							}
							else
							{
								itr = dailyInstrPriceMap.upper_bound(fromShiftedDateTime.date);
								if (itr != dailyInstrPriceMap.begin())
									itr--;
								if (itr != dailyInstrPriceMap.end())
								{
									*ratePtr = (*itr).second;
									SET_PRICE(pricePtr, A_InstrPrice_Price, CAST_PRICE((*itr).second));
								}
							}

						}
                    }

                    if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
                    {
                        *ratePtr = GET_PRICE(pricePtr, A_InstrPrice_Price);

                        /* it's important that multiplicative margin */
                        /* is apply before additive margin           */
                        if (IS_NULLFLD(interCondPtr, A_InterCond_MultMargin) == FALSE)
                            *ratePtr *= GET_NUMBER(interCondPtr, A_InterCond_MultMargin);

                        if (IS_NULLFLD(interCondPtr, A_InterCond_AddMarginP) == FALSE && GET_FLAG(interCondPtr, A_InterCond_SpreadInclusiveFlg) == TRUE)
                            *ratePtr += (GET_PERCENT(interCondPtr, A_InterCond_AddMarginP) / 100.0);
						
                        /* Stored like 0.08 for 8 % */
                        *ratePtr *= 100.0;
                    }
                    else
                    {
                        *ratePtr = 0.0;
                    }

                    /* Verify minumum and maximum rates. Check minimum rate only when it is not NULL*/
                    if (IS_NULLFLD(interCondPtr, A_InterCond_MinIntP) == FALSE)
                    {
                        /* If the floating rate is higher or equal than the minimum rate,
                        the fixed rate value is applied Otherwise it is 0. */
                        if ((INTERCALCRULE_ENUM)GET_ENUM(interCondPtr, A_InterCond_IntCalcRuleEn) == InterCalcRule_Digital)
                        {
                            if ((*ratePtr) < GET_PERCENT(interCondPtr, A_InterCond_MinIntP))
                                *ratePtr = 0.0;
                            else
                                *ratePtr = GET_PERCENT(interCondPtr, A_InterCond_InterestRateP);
                        }
                        else
                        {
                            if ((*ratePtr) < GET_PERCENT(interCondPtr, A_InterCond_MinIntP))
                                *ratePtr = GET_PERCENT(interCondPtr, A_InterCond_MinIntP);
                        }
                    }

                    if (IS_NULLFLD(interCondPtr, A_InterCond_MaxIntP) == FALSE)
                    {
                        if ((*ratePtr) > GET_PERCENT(interCondPtr, A_InterCond_MaxIntP))
                            *ratePtr = GET_PERCENT(interCondPtr, A_InterCond_MaxIntP);
                    }

                    /*compound interest calculation*/
                    *ratePtr /= 100;

                    /* Simple interest calculation when compound freq details are not provided*/
                    if (simpleInterestFlg == TRUE)
                    {
                        compoundRate += ((*ratePtr) * ((PERCENT_T)periodYearDay.num / (PERCENT_T)daysInYear.denom));
                    }
                    else 
                    {
                        /* Formula */
                        compoundRate *= (1.0 + (*ratePtr) * ((PERCENT_T)periodYearDay.num / (PERCENT_T)daysInYear.denom));
                    }
                    nbAIDays += periodYearDay.num;
                }

                /*PMSTA-46091 - Kramadevi - 19082021*/
                if (isBusinessDateFlg == FALSE)
                    isBusinessDateFlg = TRUE;

                fromShiftedDateTime.date = nextDate.date;
                
                SCE_CldrAddBusinessDays(instrPtr, calendarId, &resetFreq, fromShiftedDateTime, &nextDate, GET_ENUM(interCondPtr, A_InterCond_MktConvMethodEn));
            }
            *ratePtr = (compoundRate - 1);
            *ratePtr *= 100.0;

            if (nbAIDays == 0)
		    {
			    MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO, 
					     "FIN_ComputeInterFloatRate", GET_CODE(instrPtr, A_Instr_Cd), "compound days (AI Days)");
			    return(RET_FIN_ERR_INVDATA); 
		    }

            *ratePtr *= ((PERCENT_T)daysInYear.denom / (PERCENT_T)nbAIDays);
			if (GET_FLAG(interCondPtr, A_InterCond_SpreadInclusiveFlg) == FALSE)
				*ratePtr += GET_PERCENT(interCondPtr, A_InterCond_AddMarginP);
            return(ret);
        }/*End of Reset Frequency and compound interest calculation*/
        
	    ret = FIN_InstrPrice(GET_ID(interCondPtr, A_InterCond_BenchInstrId),
		                 NULL, fromShiftedDateTime, NULL, 0, NULL, NULL, 
			         NULL, hierHead, pricePtr, FALSE); /* PMSTA14876 - DDV - 120911 - Add a new parameter, no impact for this call */
	}

	if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
	{
		*ratePtr = GET_PRICE(pricePtr, A_InstrPrice_Price);

		/* it's important that multiplicative margin */
		/* is apply before additive margin           */
		if (IS_NULLFLD(interCondPtr, A_InterCond_MultMargin) == FALSE)
			*ratePtr *= GET_NUMBER(interCondPtr, A_InterCond_MultMargin);

		/* BUG141 */
		if (IS_NULLFLD(interCondPtr, A_InterCond_AddMarginP) == FALSE)
			*ratePtr += (GET_PERCENT(interCondPtr, A_InterCond_AddMarginP)/100.0);

		/* Stored like 0.08 for 8 % */
		*ratePtr *= 100.0;
	}
	else
	{
		*ratePtr = 0.0;
	}

	/* Verify minumum and maximum rates */ /* PMSTA-20445 - Cashwini - 150923 - Check minimum rate only when it is not NULL*/
	if (IS_NULLFLD(interCondPtr, A_InterCond_MinIntP) == FALSE)
		{
		/* PMSTA-21906 - SHR - 151218 - If the floating rate is higher or equal than the minimum rate,
		the fixed rate value is applied Otherwise it is 0. */
		if ((INTERCALCRULE_ENUM)GET_ENUM(interCondPtr, A_InterCond_IntCalcRuleEn) == InterCalcRule_Digital)
			{
			if ((*ratePtr) < GET_PERCENT(interCondPtr, A_InterCond_MinIntP))
				*ratePtr = 0.0;
			else
				*ratePtr = GET_PERCENT(interCondPtr, A_InterCond_InterestRateP);
			}
		else
			{
			if ((*ratePtr) < GET_PERCENT(interCondPtr, A_InterCond_MinIntP))
				*ratePtr = GET_PERCENT(interCondPtr, A_InterCond_MinIntP);
			}
		}

	if (IS_NULLFLD(interCondPtr, A_InterCond_MaxIntP) == FALSE)
	{
	    if ((*ratePtr)>GET_PERCENT(interCondPtr, A_InterCond_MaxIntP))
		*ratePtr = GET_PERCENT(interCondPtr, A_InterCond_MaxIntP);
	}

    /* PMSTA-42879 - Silpakal - 210203 - Compound Interest Treatment for Floating  - Start*/
    if (IS_NULLFLD(interCondPtr, A_InterCond_CompoundFreqUnitEn) == FALSE &&
        (FREQUNIT_ENUM)GET_ENUM(interCondPtr, A_InterCond_CompoundFreqUnitEn) != FreqUnit_None &&
        IS_NULLFLD(interCondPtr, A_InterCond_CompoundFreq) == FALSE &&
        GET_TINYINT(interCondPtr, A_InterCond_CompoundFreq) != 0)
    {
        FIN_CompoundInter(instrPtr, fromDate, tillDate,
                          GET_DATE(interCondPtr, A_InterCond_BeginDate),
                          GET_TINYINT(interCondPtr, A_InterCond_CompoundFreq),
                          (FREQUNIT_ENUM)GET_ENUM(interCondPtr, A_InterCond_CompoundFreqUnitEn),
                          payFreq, accrRule, TRUE, ratePtr);
    }
    else if (GET_ENUM(instrPtr, A_Instr_NatEn) == InstrNat_MoneyMkt &&
        GET_ENUM(instrPtr, A_Instr_InterestRateConvEn) == InstrIrrConv_Compound)
    {
        FIN_CompoundInter(instrPtr, fromDate, tillDate,
                          GET_DATE(interCondPtr, A_InterCond_BeginDate),
                          1, FreqUnit_Day,
                          payFreq, accrRule, TRUE, ratePtr);
    }
    /* PMSTA-42879 - Silpakal - 210203 - Compound Interest Treatment for Floating - End */

	return(ret);
}

/************************************************************************
**
**  Function    :   FIN_GetBegAccrPeriod()
**
**  Description :   Determine if interest should be calculated and if so
**                  return the date from which interest has been accruing.
**		            Verify if informations are in position or must be computed.
**                  
**  Arguments   :   refDateTime reference date
**                  fusDateRule fusion date rule 
**                  fullCoupFlg parameter which determine if accrued interest 
**                              on the first interest accrual date is equal 
**                              to 0 or to a full interest period.
**                  instrPtr    pointer on instrument dynamic structure 
**                  posPtr      pointer on position dynamic structure or NULL
**                  accrPerPtr  pointer on accrual period structure to fill
**                  aiArgStp    Pointer to AI arguments. Can be NULL
**
**  Return      :   TRUE if success,
**                  FALSE if one error occurs,
**                  NO_VALUE if accrued interest cannot be computed
**                  depending on received data.
**
**  Creation    :   BUG143 - RAK - 960930
**  Modif.      :   BUG360 - RAK - 970501
**                  REF7264 - 020129 - PMO : Compilation errors and warnings with C++ compiler
**                  REF7265 - YST - 020315 : add hierHead in argument list
**                  PMSTA-16431 - 190713 - PMO : Accrued Interest computation of Non Generic Money market instrument does not take into account the Reset AI Operation
**                  PMSTA-22235 - 280116 - PMO : The fusion rule "Amendment" is not taken into account when reducing the quantity of the Money Market position
**                  PMSTA-23996 - 080716 - PMO : Calculation of accrued interest on cash account is incorrect for valuation
**
*************************************************************************/
STATIC RET_CODE FIN_GetBegAccrPeriod(DATETIME_T          refDateTime, 
			                         FUSDATERULE_ENUM    fusDateRule, 
			                         char                fullCoupFlg, 
			                         DBA_DYNFLD_STP      instrPtr, 
			                         DBA_DYNFLD_STP      posPtr, 
			                         FIN_ACCR_PERIOD_STP accrPerPtr,
                                     DBA_HIER_HEAD_STP   hierHead,
                                     FIN_AIARG_STP       aiArgStp)          /* PMSTA08308 - 090609 - PMO */
{
	char                        usePos = FALSE;
	RET_CODE                    ret;
	ACCACCRINTERDATERULE_ENUM   accAIDateRule;        /* BUG360 - RAK - 970501 */
	SUBNAT_ENUM					instrSubNat = (SUBNAT_ENUM) GET_ENUM(instrPtr, A_Instr_SubNatEn);
	bool						is_MM_or_FI_FundShareFlg = false;

	const INSTRNAT_ENUM instrNat = (INSTRNAT_ENUM)GET_ENUM(instrPtr, A_Instr_NatEn);    /* PMSTA-23996 - 080716 - PMO */

    /* PMSTA-48782 - ankita - 16052022 */
	AppIncDivAccrualPos applIncludeDivAccrualPos = AppIncDivAccrualPos::includeInCashPos;

	GEN_GetApplInfo(ApplIncludeDivAccrualPosEnum, &applIncludeDivAccrualPos);

	if (GET_ENUM(instrPtr, A_Instr_NatEn) == InstrNat_CashAcct ||
		(instrNat == InstrNat_Stock && applIncludeDivAccrualPos == AppIncDivAccrualPos::includeInStockPos))
    {
        if (posPtr == NULL)
            return(RET_GEN_INFO_NOACTION);
        else
            usePos = TRUE;
    }
	else
	{
		is_MM_or_FI_FundShareFlg =  (instrNat    == InstrNat_FundShare  &&
									(instrSubNat == SubNat_MoneyMarketFundShare ||
									 instrSubNat == SubNat_FixedIncomeFundShare));

	    /* REF1210 - Use position only for generic instrument */
		/* PMSTA-1512-CHU-070326 : also for FundShares */
	    if (posPtr != NULL)
		{
            /* PMSTA-16431 - 190713 - PMO */
			/* PMSTA-22235 - CHU - 160405 : Undo PMSTA-16431 regression */
            /* Undo the undo :-)
             * Problem is that we have some issues with money market.
             * We need an improvement to cover clients needs
             */
            if (NULL != SYS_GetEnv("AAAMMGENERICMETHOD1"))
            {
                usePos = (  instrNat == InstrNat_Discount && GET_FLAG(instrPtr, A_Instr_GenericFlg) == TRUE)
                         || instrNat == InstrNat_MoneyMkt 
                         || is_MM_or_FI_FundShareFlg == true;
            }
            else
            {
                usePos = (( instrNat == InstrNat_Discount || instrNat == InstrNat_MoneyMkt)
                         && GET_FLAG(instrPtr, A_Instr_GenericFlg)    == TRUE
                         )
                         || is_MM_or_FI_FundShareFlg == true;
            }
		}
	}

	if (usePos == TRUE)
	{
	    DATETIME_T valDate;
	    double     freq;

        /* Use specified date. PMSTA08308 - 090609 - PMO */
        if (aiArgStp != NULL && aiArgStp->useDefinedDateFlg == TRUE)
        { /* Yes */
            valDate = aiArgStp->accrValFromDate;
        }
        else
        { /* No */
	        /* BUG360 - RAK - 970501 */
	        GEN_GetApplInfo(ApplAccAccrInterDateRule, &accAIDateRule);

            if ((accAIDateRule == AccAccrInterDateRule_BegDate &&
			    instrNat       == InstrNat_CashAcct)
			    ||
			    is_MM_or_FI_FundShareFlg == true) /* PMSTA1512-CHU-070501 : Always BegDate for FundShares ?? */
	        {
			    /* PMSTA05435-CHU-080128 : Process position BegDate for FundShares */
			    if (is_MM_or_FI_FundShareFlg == true &&
				    GET_ENUM(posPtr, ExtPos_FusRuleEn) == (ENUM_T)PosFusRule_AmendmentPostAIReset)
			    {
				    valDate = GET_DATETIME(posPtr, ExtPos_BegDate);
                    valDate.date = DATE_Move(valDate.date, 1, Day);
			    }
			    else
			    {
				    valDate = GET_DATETIME(posPtr, ExtPos_BegDate);
			    }
		    }
	        else
	        {
				/* generating core since dereferencing the NULL pointer(aiArgStp) - PMSTA-28861 - SRIDHARA - 191017 */
				if (aiArgStp == NULL || false == aiArgStp->fusionProcessing)
                { /* Standard financial processing */
                    if (instrNat                                             == InstrNat_CashAcct               && 
                        accAIDateRule                                        != AccAccrInterDateRule_ValDate    &&
                       (POSPRIMARY_ENUM)GET_ENUM(posPtr, ExtPos_DBPrimaryEn) == PosPrimary_Derived)
                    { /* For this case, we take the begin date. / PMSTA-23996 - 080716 - PMO */
                        valDate = GET_DATETIME(posPtr, ExtPos_BegDate);
                    }
                    else
                    {
			            valDate = GET_DATETIME(posPtr, ExtPos_ValDate);
                    }
                }
                else
                { /* Fusion processing */
                    if (instrNat                                            == InstrNat_CashAcct            && 
                        accAIDateRule                                       == AccAccrInterDateRule_ValDate &&
                       (POSPRIMARY_ENUM)GET_ENUM(posPtr, ExtPos_PrimaryEn)  == PosPrimary_Derived)
                    { /* A computed cash position must use the begin date. Fusion use position has his while financial function change some fields of the position / PMSTA-23996 - 080716 - PMO */
				        valDate = GET_DATETIME(posPtr, ExtPos_BegDate);
                    }
                    else
                    {
                        valDate = GET_DATETIME(posPtr, ExtPos_ValDate);
                    }
                }
		    }
        }

	    accrPerPtr->fromDate =  valDate.date;
	    accrPerPtr->fxdExch  = 1.0;
	    accrPerPtr->currId   = GET_ID(instrPtr, A_Instr_RefCurrId);

	    FIN_PeriodUnitNbr((FREQUNIT_ENUM) GET_ENUM(instrPtr,A_Instr_PayFreqUnitEn), /* REF7264 - PMO */
			              GET_TINYINT(instrPtr, A_Instr_PayFreq), FreqUnit_Month, &freq);
	    accrPerPtr->payFreq     = (PERIOD_T) freq;
	    accrPerPtr->workDate    = 0;
	    accrPerPtr->lastPayDate = 0;
	    accrPerPtr->exDate      = 0;

	    ret = RET_SUCCEED;
	}
	else
	{
        /* REF7265 - YST - 020315 - add hierHead */
	    ret = FIN_SearchBegAccrPeriod(refDateTime, fusDateRule, fullCoupFlg, instrPtr, accrPerPtr, hierHead);
    }

	return(ret);
}

/************************************************************************
**
**  Function    :   FIN_PeriodUnitAccrInter()
**
**  Description :   Compute a period unitary interest
**                 
**  Arguments   :   instrPtr  pointer on instrument
**                  fromDate  begin date from the period
**                  tillDate  end date from the period
**                  rate      pointer on rate or NULL (in case of, interest
**                            rate condition will be read in database)
**                  accrInter pointer on accrued interest dynamic structure
**                  complexRateFlg set to TRUE if rate is complex (multi rate during period or compound interest)
**
**  Return      :   RET_SUCCEED or error code
**
**  Modif	    :   REF1079 - RAK - 971219
**		        :   REF3542 - AKO - 990409 - Purify free memory unused
**              :   REF7264 - 020129 - PMO : Compilation errors and warnings with C++ compiler
**              :   REF11218 - TEB - 050627
**                  PMSTA05739 - DDV - 080227 - new parameter (complexRateFlg)
**
*************************************************************************/
RET_CODE FIN_PeriodUnitAccrInter(DBA_DYNFLD_STP     instrPtr, 
				                 DATE_T             fromDate,
			                     DATE_T             tillDate, 
				                 PERCENT_T          *rate, 
				                 DBA_DYNFLD_STP     incPtr,
								 ACCRRULE_ENUM      accrRule,	 /* REF11218 - TEB - 050627 */
				                 DBA_DYNFLD_STP     accrInter,
	                             DBA_HIER_HEAD_STP  hierHead,
								 FLAG_T             *complexRateFlg) /* PMSTA05739 - DDV - 080227 - Set to TRUE if rate is complex (multi rate during period or compound interest) */
{
	FIN_INTERRATE_ST   interRate;
	FIN_QUANT_ST       quant;
	FIN_ACCR_PERIOD_ST accrPeriod;
	double             freq;
	FLAG_T             flg;
	RET_CODE           ret;

	memset(&accrPeriod, 0, sizeof(FIN_ACCR_PERIOD_ST));  /* REF1079 */
    memset(&interRate,  0, sizeof(FIN_INTERRATE_ST));    /*  LJE-PMSTA-23725-160628  */

    quant.quantNbr = 1;
	if ((quant.infoPtr = (FIN_QUANT_INFO_STP) 
     	               CALLOC(quant.quantNbr, sizeof(FIN_QUANT_INFO_ST)))==(FIN_QUANT_INFO_STP)NULL)
		MSG_RETURN(RET_MEM_ERR_ALLOC);

	/* Init quantity and interest rate structure at received */
	/* dates (only 1 period) and rate, force flags           */
	quant.infoPtr[0].fromDate = fromDate;
	quant.infoPtr[0].tillDate = tillDate;
	quant.infoPtr[0].quant    = 1.0; 

	if (complexRateFlg != NULL)
		*complexRateFlg = FALSE;

	/* Compute unitary accrued interest */
	FIN_PeriodUnitNbr((FREQUNIT_ENUM) GET_ENUM(instrPtr, A_Instr_PayFreqUnitEn),    /* REF7264 - PMO */
			          GET_TINYINT(instrPtr, A_Instr_PayFreq), 
                      FreqUnit_Month, 
                      &freq);

	/* REF1079 - Read income currency and fixed exchange rate */
	if (incPtr != NULL)
	{
		DATETIME_T	refDateTime;

		refDateTime.date = fromDate;
		refDateTime.time = 0;
		accrPeriod.fixedDateFlg = TRUE;
        /* REF7265 - YST - 020315 - add hierHead */
        ret = FIN_SearchCurrentIncEvt(refDateTime, FusDateRule_None, FALSE, 
				                      incPtr, instrPtr, &accrPeriod, hierHead);
	}
	else
	{
       	accrPeriod.currId  = GET_ID(instrPtr, A_Instr_RefCurrId); 
       	accrPeriod.fxdExch = 1.0; 
	}

	accrPeriod.fromDate  = fromDate; /* BUG307 - XDI - 970319 */
	accrPeriod.payFreq  = (PERIOD_T) freq;

	/* REF11218 - TEB - 050627 */
	if (accrRule == AccrRule_None)
	{
		if ((ret = FIN_GetInstrAccrRule(fromDate, instrPtr, hierHead, /* REF3410 - SSO - 990315 */
										&accrPeriod.accrRule)) != RET_SUCCEED)
		{
			FREE(quant.infoPtr);
			return(ret); 
		}
	}
	else
	{
		accrPeriod.accrRule = accrRule;
	}

    accrPeriod.workDate = tillDate; /* BUG307 - XDI - 970319 */

	if (rate != NULL)
	{
		interRate.interRateNbr = 1;
		if ((interRate.infoPtr = (FIN_RATE_INFO_STP) CALLOC(interRate.interRateNbr, 
			                     sizeof(FIN_RATE_INFO_ST)))==(FIN_RATE_INFO_STP)NULL)
		{
			FREE(quant.infoPtr);
			MSG_RETURN(RET_MEM_ERR_ALLOC);
		}

		interRate.infoPtr[0].fromDate = fromDate;
		interRate.infoPtr[0].tillDate = tillDate;
  		interRate.infoPtr[0].posRate  = *rate;
  		interRate.infoPtr[0].negRate  = *rate;
	}
	else
	{
		/**** SEARCH INTEREST RATE(S) APPLICABLE OVER THE PERIOD ****/
		/* Read interest rate condition */
        /* REF7475 - YST - 020516 - new argument */
		if ((ret = FIN_SearchInterRate(fromDate, tillDate, 
					                   accrPeriod.payFreq, accrPeriod.accrRule,
			                           instrPtr, &interRate, hierHead, (INTERCONDNAT_ENUM)InterCondNat_None, 
									   FALSE, /* PMSTA05878 - RAK - 080424 */
									   complexRateFlg)) != RET_SUCCEED)
		{
			FREE(quant.infoPtr);
			FREE(interRate.infoPtr); /* REF3542 - AKO - 990409 */
			return(ret); 
		}
	}

	/* REF3693 - SSO - 990517 */
	flg = FIN_CalcUnitAccrInter(&accrPeriod, &interRate, &quant, NULL, 
                                fromDate, tillDate, accrInter, instrPtr, hierHead, NULL, complexRateFlg); /* REF5937 - AKO - 010608 : add hierHead */

	SET_ENUM(accrInter, UnitInter_InterCalcRuleEn, (ENUM_T) interRate.interCalcRuleEn);

	FREE(quant.infoPtr);
	FREE(interRate.infoPtr);

	if (flg == FALSE)
		return(RET_GEN_ERR_INVARG); /* RET_FIN_ERR_CALC ?? */
	else
		return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_SearchBegAccrPeriod()
**
**  Description :   Determine if interest should be calculated and if so
**                  return the date from which interest has been accruing.
**                  This date may be greater than the reference date, 
**                  in which case we will have negative interest. 
**                  Additional data from the event is returned.      
**                  
**  Arguments   :   refDateTime reference date
**                  fusDateRule fusion date rule 
**                  fullCoupFlg parameter which determine if accrued interest 
**                              on the first interest accrual date is equal 
**                              to 0 or to a full interest period.
**                  instrPtr    pointer on instrument dynamic structure 
**                  accrPerPtr  pointer on accrual period structure to fill
**
**  Return      :   TRUE if success,
**                  FALSE if one error occurs,
**                  NO_VALUE if accrued interest cannot be computed
**                  depending on received data.
**
**  Modif	    REF3693 - SSO - 990517
**              REF7264 - 020129 - PMO : Compilation errors and warnings with C++ compiler
**              REF7265 - YST - 020315 : add hierHead in argument list
**
*************************************************************************/
STATIC RET_CODE FIN_SearchBegAccrPeriod(DATETIME_T          refDateTime, 
			                            FUSDATERULE_ENUM    fusDateRule, 
			                            char                fullCoupFlg, 
			                            DBA_DYNFLD_STP      instrPtr, 
			                            FIN_ACCR_PERIOD_STP accrPerPtr,
                                        DBA_HIER_HEAD_STP   hierHead)
{
	double  freq;
	FLAG_T	avrgRateFlg=FALSE;	    /* REF3693 - SSO - 990517 */

	/* Developer Information Not Obsolete Serious And Useful Recommendation � DINOSAUR � KRA � 110831 */
	/* here some potential problem with the move of the first coupon date, begin date, end of month, ...*/
	/* and I'm not sure they are all corrected ... good luck */

	/**** SEARCH IN TABLE INSTRUMENT (DENORMALISED DATA) ***/
	if (GET_ENUM(instrPtr, A_Instr_NatEn) == InstrNat_MoneyMkt ||
	    GET_ENUM(instrPtr, A_Instr_NatEn) == InstrNat_Discount)
	{
	    /* REF3693 - SSO - 990517 part. cas added: if Average Rate, interest is active at the beg. date */
	    avrgRateFlg = (FLAG_T)(GET_ENUM(instrPtr, A_Instr_SubNatEn) == SubNat_AvrgRate);

	    if (((GET_DATE(instrPtr,A_Instr_BeginDate) < refDateTime.date) 
		    || (avrgRateFlg == TRUE && GET_DATE(instrPtr,A_Instr_BeginDate) == refDateTime.date))
		    && (refDateTime.date <= GET_DATE(instrPtr, A_Instr_EndDate))) 
	    {	
		    /* same currency when denormalised */
		    accrPerPtr->fxdExch  = 1.0;
		    accrPerPtr->currId   = GET_ID(instrPtr, A_Instr_RefCurrId);

		    /* First accrual date is knowed and is stored  */
		    /* in a working date for determine date from   */
		    /* which interest has been accruing, frequency */
		    /* is stored in month unit.                    */
		    FIN_PeriodUnitNbr((FREQUNIT_ENUM) GET_ENUM(instrPtr,A_Instr_PayFreqUnitEn),     /* REF7264 - PMO */
			                  GET_TINYINT(instrPtr, A_Instr_PayFreq), FreqUnit_Month, &freq);
		    accrPerPtr->payFreq     = (PERIOD_T) freq;
		    accrPerPtr->workDate    = 0;
		    accrPerPtr->lastPayDate = GET_DATE(instrPtr, A_Instr_EndDate);

		    /* In case of denormalisation, ex-date is NULL */
		    accrPerPtr->exDate = 0;

		    /* Discounted money market */
            if (GET_ENUM(instrPtr, A_Instr_PriceCalcRuleEn) == PriceCalcRule_Discounted)
		    { accrPerPtr->fromDate = GET_DATE(instrPtr, A_Instr_EndDate); }
		    else
		    { accrPerPtr->fromDate = GET_DATE(instrPtr, A_Instr_BeginDate); }

		    return(RET_SUCCEED);
	    }
	    else
		    return(RET_GEN_ERR_INVARG); /* ?? RET_FIN_ERR_WRONGDATA */
	}
    /* Search current income event and determine from date */
	else
	{
	    /* REF7265 - YST - 020315 - add hierHead */
	    return(FIN_SearchCurrentIncEvt(refDateTime, fusDateRule,		/* REF1079 */
				                       fullCoupFlg, NULL, instrPtr, accrPerPtr, hierHead));
	}
}

/************************************************************************
**
**  Function    :   FIN_SearchCurrentIncEvt()
**
**  Description :   Search income event applicable at the reference date.
**                 
**  Arguments   :   refDateTime  reference date
**                  fusDateRule  fusion date rule 
**                  fullCoupFlg  parameter which determine if accrued interest 
**                               on the first interest accrual date is equal to
**                               0 or to a full interest period.
**                  instrPtr	 structure instrument pointer
**                  accrPerPtr   pointer on accrual period structure to fill
**
**  Return      :   RET_SUCCEED or RET_NOVALUE or error code
**
**  Modif       :   REF1079 - RAK - 971219
**                  REF2313 - RAK - 980610
**                  REF7264 - 020129 - PMO : Compilation errors and warnings with C++ compiler
**                  REF7265 - YST - 020315 : add hierHead in argument list
**                  REF8609 - YST - 030110
**
*************************************************************************/
STATIC RET_CODE FIN_SearchCurrentIncEvt(DATETIME_T          refDateTime, 
			                            FUSDATERULE_ENUM    fusDateRule, 
			                            char                fullCoupFlg, 
					                    DBA_DYNFLD_STP	    inIcEvPtr,
			                            DBA_DYNFLD_STP      instrPtr, 
			                            FIN_ACCR_PERIOD_STP accrPerPtr,
                                        DBA_HIER_HEAD_STP   hierHead)
{
	DBA_DYNFLD_STP  icEvPtr=NULL; 
	double          freq;
	char	        allocIcEvFlg;
    INSTRNAT_ENUM   instrNatEn = InstrNat_None;
    SUBNAT_ENUM     instrSubNatEn = SubNat_None;
	RET_CODE        ret;

	if (inIcEvPtr == NULL)
	{
	    if ((icEvPtr = ALLOC_DYNST(A_IncEvt)) == NULL)
		    MSG_RETURN(RET_MEM_ERR_ALLOC);

	    if ((ret = DBA_GetIncEvt(instrPtr, refDateTime, icEvPtr)) != RET_SUCCEED)
	    {
		    FREE_DYNST(icEvPtr, A_IncEvt);
		    return(ret);
	    }

	    allocIcEvFlg = TRUE;
	}
	else
	{
	    icEvPtr = inIcEvPtr;
	    allocIcEvFlg = FALSE;
	}

	accrPerPtr->currId   = GET_ID(icEvPtr,   A_IncEvt_CurrId);
	accrPerPtr->workDate = GET_DATE(icEvPtr, A_IncEvt_BeginDate); 

	/* If fusion date rule is value date, don't count ex-date */
	/* ?? comparaison ptf and domain rule */
	if (fusDateRule == FusDateRule_ValDate)
		accrPerPtr->exDate = 0;
	else
	{
		/* first ex-date is optional, it will be initial */
		/* to first payment date if it isn't set.        */
		if (IS_NULLFLD(icEvPtr, A_IncEvt_FirstExDate))
			accrPerPtr->exDate = 0;
		else
			accrPerPtr->exDate = GET_DATE(icEvPtr, A_IncEvt_FirstExDate);
	}

	accrPerPtr->lastPayDate   = GET_DATE(icEvPtr, A_IncEvt_LastPayDate);
	accrPerPtr->firstCoupDate = GET_DATE(icEvPtr, A_IncEvt_FirstCoupDate);
    
    /* REF7265 - YST - 020315/REF7782 - YST - 020904 
    set first coupon date of fixed and floating leg of swap bris� */
    instrNatEn = (INSTRNAT_ENUM) GET_ENUM(instrPtr, A_Instr_NatEn);
    instrSubNatEn = (SUBNAT_ENUM) GET_ENUM(instrPtr, A_Instr_SubNatEn);

    if (((COMPLEXINSTR_ENUM)GET_ENUM(instrPtr, A_Instr_ComplexInstrEn) == ComplexInstr_BrokSwap ||
        (COMPLEXINSTR_ENUM)GET_ENUM(instrPtr, A_Instr_ComplexInstrEn) == ComplexInstr_BrokSwapHedgFix) && 
        InstrNat_Bond == instrNatEn && 
        (SubNat_PaidSwapFloatLeg == instrSubNatEn || SubNat_RecSwapFloatLeg == instrSubNatEn ||
         SubNat_PaidSwapFixedLeg == instrSubNatEn || SubNat_RecSwapFixedLeg == instrSubNatEn))
    {
        DBA_DYNFLD_STP	*iCond=NULL;
        DATETIME_ST     fromDate, tillDate;
        int             interCondNbr=0;
        FLAG_T		    freeInterCondRecFlg=FALSE;
        
        fromDate.date = GET_DATE(instrPtr, A_Instr_BeginDate);
        fromDate.time = 0;
        if (IS_NULLFLD(instrPtr, A_Instr_EndDate) == TRUE)
            tillDate.date = DATE_Move(refDateTime.date, 50, Year);
        else
            tillDate.date = GET_DATE(instrPtr, A_Instr_EndDate);
        tillDate.time = 0;

        if (DBA_SelectInterCond2(instrPtr, fromDate, tillDate, &iCond, &interCondNbr, &freeInterCondRecFlg, 
                        hierHead, (INTERCONDNAT_ENUM)GET_ENUM(instrPtr, A_Instr_InterCondNatEn)) == RET_SUCCEED
                        && interCondNbr > 0)
        {  
            /* DBA_SelectInterCond2 sorts conditions:                                           */
            /* 1. InterCalcRule_Fixed 2. InterCalcRule_Floating 3. Date=fromDate ascending order */
            if (interCondNbr == 1)
            {
                if (IS_NULLFLD(iCond[0], A_InterCond_FirstResetDate) != TRUE)
                    accrPerPtr->firstCoupDate = GET_DATE(iCond[0], A_InterCond_FirstResetDate);
            }
            else
            {
                /* fixed - float - fixed */
                if ((INTERCALCRULE_ENUM)GET_ENUM(iCond[0], A_InterCond_IntCalcRuleEn) == InterCalcRule_Fixed &&
                    (INTERCALCRULE_ENUM)GET_ENUM(iCond[1], A_InterCond_IntCalcRuleEn) == InterCalcRule_Fixed)
                {
                    accrPerPtr->firstCoupDate = GET_DATE(iCond[0], A_InterCond_EndDate);            
                }
                /* swap bris� with period fixed calculation rule befor period floating */
                else if ((INTERCALCRULE_ENUM)GET_ENUM(iCond[0], A_InterCond_IntCalcRuleEn) == InterCalcRule_Fixed &&
                         (INTERCALCRULE_ENUM)GET_ENUM(iCond[1], A_InterCond_IntCalcRuleEn) == InterCalcRule_Floating &&
                         (GET_DATE(iCond[0], A_InterCond_BeginDate) < GET_DATE(iCond[1], A_InterCond_BeginDate)))
                {
                    accrPerPtr->firstCoupDate = GET_DATE(iCond[0], A_InterCond_EndDate);
                }        
            }
            if (freeInterCondRecFlg == TRUE)
            { DBA_FreeDynStTab(iCond, interCondNbr, A_InterCond); }
            else
            { FREE(iCond); }
       }
    }

	FIN_PeriodUnitNbr((FREQUNIT_ENUM) GET_ENUM(icEvPtr, A_IncEvt_PayFreqUnitEn),    /* REF7264 - PMO */
		              GET_TINYINT(icEvPtr, A_IncEvt_PayFreq), FreqUnit_Month, &freq);
	accrPerPtr->payFreq = (PERIOD_T) freq;

	/* Apply fixed exchange only if currency are different */
	if (accrPerPtr->currId == GET_ID(instrPtr, A_Instr_RefCurrId))
		accrPerPtr->fxdExch = 1.0;
	else
	{
		accrPerPtr->fxdExch = GET_EXCHANGE(icEvPtr, A_IncEvt_FixedExchRate);

		/* REF1079 - Use day exchange rate */
		if (CMP_NUMBER(accrPerPtr->fxdExch, 0.0) == 0) 
		{
			FIN_EXCHARG_ST  exchArgSt;			/* REF2313 */
			memset(&exchArgSt, 0, sizeof(FIN_EXCHARG_ST));

	   		FIN_GetExchRate(refDateTime, accrPerPtr->currId, 
					        GET_ID(instrPtr, A_Instr_RefCurrId), 
					        0, NULL, NULL, &exchArgSt, &(accrPerPtr->fxdExch));	/* PMSTA01649 - TGU - 070402 */
		}
	}

	if (allocIcEvFlg == TRUE) { FREE_DYNST(icEvPtr, A_IncEvt); }

      /* REF1079 - Search from date only if it isn't fixed */
	if (accrPerPtr->fixedDateFlg == FALSE)
    {
        /* REF7287 - YST - 020121 and REF7265 - 020315 and REF8609 - 030110 */
        /* accrPerPtr->fromDate must be a business day for instrument FRN and fixed and floating legs of swap */
        if ((InstrNat_Bond == instrNatEn && (SubNat_FRN == instrSubNatEn ||
            SubNat_RecSwapFloatLeg == instrSubNatEn || SubNat_PaidSwapFloatLeg == instrSubNatEn ||
            SubNat_RecSwapFixedLeg == instrSubNatEn || SubNat_PaidSwapFixedLeg == instrSubNatEn)) ||
            FIN_IsBondOfSwap(instrPtr, hierHead) == TRUE)
            return(FIN_SearchFirstAccrDateBusDay(instrPtr, refDateTime, fullCoupFlg, accrPerPtr, hierHead));
        else
            return(FIN_SearchFirstAccrDate(refDateTime, fullCoupFlg, accrPerPtr, instrPtr, hierHead));/*PMSTA-46121 - SENTHILKUMAR - 29092021*/
    }
	else
		return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_SearchFirstAccrDate()
**
**  Description :   Determine date from which interest has been accruing 
**                 
**  Arguments   :   refDateTime    reference date
**                  fullCoupFlg    parameter which determine if accrued 
**                                 interest on the first interest accrual date 
**                                 is equal to 0 or to a full interest period.
**                  accrPerPtr     pointer on accrual period structure to fill
**
**  Return      :   TRUE or FALSE
**
**  Modif       :   BUG091 - RAK - 960808
**  Modif       :   BUG400 - RAK - 970613
**                  REF6075 - DDV - 020104 - server locked if fullCoupFlg is not TRUE nor FALSE
**
*************************************************************************/
STATIC RET_CODE FIN_SearchFirstAccrDate(DATETIME_T          refDateTime, 
			                            char                fullCoupFlg, 
			                            FIN_ACCR_PERIOD_STP accrPerPtr,
										DBA_DYNFLD_STP instrPtr,
										DBA_HIER_HEAD_STP   hierHead)
{
	DATE_T oldWork=0;
	DAY_T  saveD, saveExD;
	char   found, endMonth, endExMonth;

	/**** SEARCH FROM DATE ****/
	DATE_Get(accrPerPtr->workDate, NULL, NULL, &saveD);
		endMonth = (char) DATE_IsLastInMonth(accrPerPtr->workDate);

	DATE_Get(accrPerPtr->exDate, NULL, NULL, &saveExD);
	endExMonth = (char) DATE_IsLastInMonth(accrPerPtr->exDate);

	found = FALSE;

	if (accrPerPtr->payFreq == 0 && accrPerPtr->lastPayDate == 0)
	{
		accrPerPtr->fromDate = accrPerPtr->workDate;
		return(RET_SUCCEED);
	}

	/* Don't compute accrued interest if it begins after report date */
	if (accrPerPtr->workDate > refDateTime.date)
	{
		return(RET_GEN_INFO_NOACTION);
	}		

	if (fullCoupFlg == TRUE)
    {
        if (accrPerPtr->lastPayDate < refDateTime.date)
    		return(RET_GEN_INFO_NOACTION);
    }
    else
    {
    	if (accrPerPtr->lastPayDate <= refDateTime.date)
    		return(RET_GEN_INFO_NOACTION);
    }

	/*PMSTA-46121 - SENTHILKUMAR - 29092021*/

	FLAG_T mktConvMethodEnblFlg = FALSE;
	if (instrPtr != nullptr)
	{

		DBA_DYNFLD_STP      *selInterTab = NULLDYNSTPTR;
		int                 selInterNbr = 0;

		if ((INSTRNAT_ENUM)GET_ENUM(instrPtr, A_Instr_NatEn) != InstrNat_CashAcct &&
			IS_NULLFLD(instrPtr, A_Instr_BeginDate) == false)
		{
			MemoryPool mp;

			DBA_DYNFLD_STP      intRateCondPtr = NULLDYNST;

			FLAG_T		        interCondRecFlg = FALSE;

			RET_CODE            ret;

			intRateCondPtr = mp.allocDynst(FILEINFO, A_InterCond);

			if (GET_ID(instrPtr, A_Instr_Id) < 0)
			{
				SET_ID(intRateCondPtr, A_InterCond_InstrId, GET_ID(instrPtr, A_Instr_ParentInstrId));
			}
			else
			{
				SET_ID(intRateCondPtr, A_InterCond_InstrId, GET_ID(instrPtr, A_Instr_Id));
			}
			SET_DATE(intRateCondPtr, A_InterCond_BeginDate, GET_DATE(instrPtr, A_Instr_BeginDate));
			SET_DATE(intRateCondPtr, A_InterCond_EndDate, refDateTime.date);
			SET_ENUM(intRateCondPtr, A_InterCond_NatEn, InterCondNat_None);

			if ((CMP_ENUM((INSTRNAT_ENUM)GET_ENUM(instrPtr, A_Instr_NatEn),InstrNat_FundShare)==0) &&
				((CMP_ENUM((SUBNAT_ENUM)GET_ENUM(instrPtr, A_Instr_SubNatEn),SubNat_MoneyMarketFundShare)==0) ||
				 (CMP_ENUM((SUBNAT_ENUM)GET_ENUM(instrPtr, A_Instr_SubNatEn),SubNat_FixedIncomeFundShare)==0)))
			{
				SET_DATE(intRateCondPtr, A_InterCond_ValidDate, accrPerPtr->fromDate);
			}

			if ((ret = DBA_SelAllInterCond(InterCond_ByIdDt, hierHead, instrPtr, intRateCondPtr,
				&selInterTab, &selInterNbr, &interCondRecFlg)) != RET_SUCCEED)
			{
				ret = RET_DBA_ERR_NODATA;
				MSG_SendMesg(ret, 3, FILEINFO, "DBA_SelectInterCond", GET_CODE(instrPtr, A_Instr_Cd), "interest condition");
				return ret;
			}
		}

		if (selInterNbr > 0 &&
			static_cast<InstrMktConvMethodEn>GET_ENUM(selInterTab[0], A_InterCond_MktConvMethodEn) != InstrMktConvMethodEn::None)
		{
			mktConvMethodEnblFlg = TRUE;
		}
		DBA_FreeDynStTab(selInterTab, selInterNbr, A_InterCond);
	}

	FLAG_T Paymentstartdate_f = TRUE;
	DATE_T tmpFromDate=0;
    while (found == FALSE && accrPerPtr->workDate != BAD_DATE)
	{	
		/* Save current working date */
		oldWork = accrPerPtr->workDate;

		if (Paymentstartdate_f)
			tmpFromDate = accrPerPtr->workDate;
		else
			accrPerPtr->workDate = tmpFromDate;

		/* Move dates period by period */
		if (accrPerPtr->firstCoupDate > accrPerPtr->workDate)
		{
			accrPerPtr->workDate = accrPerPtr->firstCoupDate;
			accrPerPtr->firstCoupDate = 0; /* only 1 time */

			/* BUG400 - RAK - 970613 */
			DATE_Get(accrPerPtr->workDate, NULL, NULL, &saveD);
			endMonth = (char) DATE_IsLastInMonth(accrPerPtr->workDate);
		}
		else
		{
		    /* For null frequency there is only one accrual period in */
		    /* instrument life so go to last payment date.            */
		    if (accrPerPtr->payFreq == 0)
		    {
			    accrPerPtr->workDate = accrPerPtr->lastPayDate;
		    }
		    else
		    {
				/*PMSTA - 45824 - SENTHILKUMAR - 30092021*/
				if (mktConvMethodEnblFlg == TRUE && Paymentstartdate_f == TRUE && IS_NULLFLD(instrPtr, A_Instr_DatedDate) == FALSE)
				{
					accrPerPtr->workDate = DATE_Move(GET_DATE(instrPtr, A_Instr_BeginDate),
						accrPerPtr->payFreq, Month);
				}
				else
					accrPerPtr->workDate = DATE_Move(accrPerPtr->workDate,
						accrPerPtr->payFreq, Month);
		    }
		}

		Paymentstartdate_f = FALSE;
		/*PMSTA-46121 - SENTHILKUMAR - 29092021 - This code added to handle business day convention*/
		if(mktConvMethodEnblFlg == TRUE)
		{
			DATETIME_T fDateTime;
			fDateTime.date = accrPerPtr->workDate;
			fDateTime.time = 0;
			FLAG_T     isBusinessDateFlg = FALSE;

			ID_T			calendarId = 0;
			DBA_GetCalendarFromInstr(instrPtr, &calendarId);

			CALNEXTBUSDATERULE_ENUM	nextBusDateEn = (CALNEXTBUSDATERULE_ENUM)GET_ENUM(instrPtr, A_Instr_BusDayConvEn);

			SCE_CldrIsBusinessDate(fDateTime, calendarId, &isBusinessDateFlg);

			if (isBusinessDateFlg == FALSE && nextBusDateEn != CalNextBusDateRule_Default)
			{
				mktConvMethodEnblFlg = TRUE;
				tmpFromDate = accrPerPtr->workDate;
				SCE_CldrNextBusinessDate(instrPtr, calendarId, &nextBusDateEn, fDateTime, &fDateTime);
				if (mktConvMethodEnblFlg == TRUE && ((ACCRRULE_ENUM)GET_ENUM(instrPtr, A_Instr_AccrualRuleEn) == AccrRule_30_360 ||
					(ACCRRULE_ENUM)GET_ENUM(instrPtr, A_Instr_AccrualRuleEn) == AccrRule_30E_360 ||
					(ACCRRULE_ENUM)GET_ENUM(instrPtr, A_Instr_AccrualRuleEn) == AccrRule_30_360_1 ||
					(ACCRRULE_ENUM)GET_ENUM(instrPtr, A_Instr_AccrualRuleEn) == AccrRule_30_360_US ||
					(ACCRRULE_ENUM)GET_ENUM(instrPtr, A_Instr_AccrualRuleEn) == AccrRule_30_360_FebAdj ||
					(ACCRRULE_ENUM)GET_ENUM(instrPtr, A_Instr_AccrualRuleEn) == AccrRule_30_360_Def) && (CALNEXTBUSDATERULE_ENUM)GET_ENUM(instrPtr, A_Instr_BusDayConvEn) != CalNextBusDateRule_Default)
				{
					DAY_T date_30360 = 0;
					DATE_Get((DATE_T)fDateTime.date, (YEAR_T *)NULL, (MONTH_T *)NULL, (DAY_T *)&date_30360);
					if (date_30360 == 31)
					{
						fDateTime.date = tmpFromDate;
					}
				}
				accrPerPtr->workDate = fDateTime.date;
			}
			else
				tmpFromDate = accrPerPtr->workDate;
		}
		else
			tmpFromDate = accrPerPtr->workDate;

		DATE_Get(accrPerPtr->workDate, NULL, NULL, &saveD);

		if (accrPerPtr->exDate == 0)
		{
			accrPerPtr->exDate = accrPerPtr->workDate;
			saveExD = saveD;
		}

		/* ex-date must be between two payment date */
		if (accrPerPtr->exDate < oldWork || 
		    accrPerPtr->exDate > accrPerPtr->workDate || mktConvMethodEnblFlg == TRUE)
		{
			accrPerPtr->exDate = accrPerPtr->workDate;
			saveExD = saveD;
		}

		/* Short month can corrupt day number */
		DATE_VerifyEndMonth(&(accrPerPtr->workDate), saveD, endMonth);
		DATE_VerifyEndMonth(&(accrPerPtr->exDate), saveExD,endExMonth);

		/* From date is working date or old working date */
		/* depending on ex-date */
        /* REF6075 - DDV - 020104 - change algo, if fullCoupFlg is not TRUE nor FALSE, treat it as FALSE.
		if (fullCoupFlg == FALSE && refDateTime.date < accrPerPtr->workDate)
			found = TRUE;

		if (fullCoupFlg == TRUE && refDateTime.date <= accrPerPtr->workDate)
			found = TRUE;

		if (found == FALSE)
	   	    	accrPerPtr->exDate =
	   	    	    DATE_Move(accrPerPtr->exDate, accrPerPtr->payFreq, Month); 
        */

		if (fullCoupFlg == TRUE)
        {
            if (refDateTime.date <= accrPerPtr->workDate)
    			found = TRUE;
        }
        else
        {
    		if (refDateTime.date < accrPerPtr->workDate)
    			found = TRUE;
        }

		if (found == FALSE)
	   	    	accrPerPtr->exDate =
	   	    	    DATE_Move(accrPerPtr->exDate, accrPerPtr->payFreq, Month);
	}

	if (found == TRUE)
	{
		if (fullCoupFlg == TRUE)
		{
			if (refDateTime.date > accrPerPtr->exDate)
				accrPerPtr->fromDate = accrPerPtr->workDate;
			else
				accrPerPtr->fromDate = oldWork;
		}
		else
		{
			if (refDateTime.date >= accrPerPtr->exDate)
				accrPerPtr->fromDate = accrPerPtr->workDate;
			else
				accrPerPtr->fromDate = oldWork;
		}
		return(RET_SUCCEED);
	}
	else
	{
		accrPerPtr->fromDate = BAD_DATE;
		return(RET_GEN_ERR_INVARG);
	}
}

/********************************************************************************************
**
**  Function    :   FIN_SearchInterRate()
**
**  Description :   Retrieve the interest rates applicable over the accrual period. 
**                 
**  Arguments   :   fromDate       
**                  tillDate       
**                  payFreq       payment frequency
**                  accrRule      accrual rule
**                  instrPtr      instrument dynamic structure pointer
**                  interRatePtr  pointer on interest rate structure to fill
**                  intercondNat  interate rate condition nature - is none here
**                  complexRateFlg set to TRUE if rate is complex (multi rate during period or compound interest)
**
**  Return      :   RET_SUCCEED or error code
**
**  Modif       :   DVP125 - RAK - 960621 
**  Modif       :   BUG146 - RAK - 960930  
**  Modif       :   BUG426 - RAK - 970608  
**  Modif       :   BUG485 - RAK - 970901  
**  Modif       :   REF1152 - RAK - 980119  
**  Modif       :   REF3693 - SSO - 990517
**  Modif       :   REF6004 - AKO - 011218 : create FIN_SearchInterRate2() with new argument
**  Last modif. :   REF7264 - 020129 - PMO : Compilation errors and warnings with C++ compiler
**  Modif       :   REF7475 - YST - 020516 - FIN_SearchInterRate2() -> FIN_SearchInterRate()
**  MOdif       :   REF7597 - YST - 020530
**                  PMSTA05739 - DDV - 080227 - new parameter (complexRateFlg)
**
*************************************************************************************************/
/* BUG043 - RAK - 960627 static */
RET_CODE FIN_SearchInterRate(       DATE_T            fromDate, 
    			                    DATE_T            tillDate, 
	                                PERIOD_T          payFreq, 
			                        ACCRRULE_ENUM     accrRule, 
			                        DBA_DYNFLD_STP    instrPtr, 
			                        FIN_INTERRATE_STP interRatePtr,
                                    DBA_HIER_HEAD_STP hierHead,
                                    INTERCONDNAT_ENUM intercondNat,
									FLAG_T			  allowCompoundFlg, /* PMSTA05878 - RAK - 080424 */
                                    FLAG_T            *complexRateFlg,
			                        FLAG_T multipleIRCFlg)  /* PMSTA05739 - DDV - 080227 - Set to TRUE if rate is complex (multi rate during period or compound interest) */
									
{
	DBA_DYNFLD_STP      *iCond=NULL, array=NULL;/* REF3693 - SSO - 990517 */
	int                 interCondNbr, i, j, k, crtFloat, allocSz;
    long                reading = 0;            /* REF7597 - YST - 020530 */
	DATE_T              sv=BAD_DATE, oldTill, begD, fixFrom=BAD_DATE, instrEndDate=BAD_DATE, tmpTillDate;/* REF3696 - SSO - 990518 */ 
	DATETIME_T          fDateTime, tDateTime;
	RET_CODE            ret;
	FLAG_T	            avrgRateFlg=FALSE;	    /* REF3693 - SSO - 990517 */
	DBA_ARRAY_DATA_STP  arrayData=NULL;	    /* REF3693 - SSO - 990517 */
	FLAG_T		        freeInterCondRecFlg=FALSE;  /* REF3678 - RAK - 990819 */
	FLAG_T				is_MM_or_FI_FundShareFlg = FALSE; /* PMSTA01512-CHU-070502 */
	PERCENT_T           interRate=0.0;

	interRatePtr->interRateNbr = 0;
	interRatePtr->infoPtr = NULL;  /* REF3693 - SSO - 990517 */
    interRatePtr->interCalcRuleEn = InterCalcRule_Fixed; /* PMSTA-22626 - CHU - 160302 : Init and avoid bad cast on enum in upper calling function(s) */

	is_MM_or_FI_FundShareFlg = (FLAG_T) (GET_ENUM(instrPtr, A_Instr_NatEn) == InstrNat_FundShare  &&
									(GET_ENUM(instrPtr, A_Instr_SubNatEn) == SubNat_MoneyMarketFundShare ||
									 GET_ENUM(instrPtr, A_Instr_SubNatEn) == SubNat_FixedIncomeFundShare));

	/* DVP125 - RAK - 960618 */
	/* In generic treatment force A_Instr_InterestCdEn to InterCd_Instr */
	/* So test on instrument nature (InstrNat_MoneyMkt, InstrNat_Discount) is suppressed */

	/*** DENORMALISED DATA ***/
	if ((INTERCD_ENUM) GET_ENUM(instrPtr, A_Instr_InterestCdEn) == InterCd_Instr
	     && IS_NULLFLD(instrPtr, A_Instr_InterestRateP) == FALSE)  /* REF3693 - SSO - 990517 case if no intercond in db */
	{
		if ((interRatePtr->infoPtr = (FIN_RATE_INFO_STP) 
			           CALLOC(1, sizeof(FIN_RATE_INFO_ST))) == (FIN_RATE_INFO_STP)NULL)
		{
			MSG_RETURN(RET_MEM_ERR_ALLOC);
		}
		else
		{
			DATETIME_T tmpDate;

			interRatePtr->interRateNbr    = 1;
			interRatePtr->interCalcRuleEn = InterCalcRule_Fixed;

			/* REF1152 - Don't use dated date for cash and money market */
			if ((INSTRNAT_ENUM)GET_ENUM(instrPtr, A_Instr_NatEn)!=InstrNat_MoneyMkt &&
			    (INSTRNAT_ENUM)GET_ENUM(instrPtr, A_Instr_NatEn)!=InstrNat_CashAcct &&
			    IS_NULLFLD(instrPtr, A_Instr_DatedDate) == FALSE)
			{
			    tmpDate = GET_DATETIME(instrPtr, A_Instr_DatedDate);
			}
			else
			{
			    tmpDate.date = GET_DATE(instrPtr, A_Instr_BeginDate);
			}
			interRatePtr->infoPtr[0].fromDate = tmpDate.date;

			if (IS_NULLFLD(instrPtr, A_Instr_EndDate) == FALSE &&
			    GET_DATE(instrPtr, A_Instr_EndDate) != MAGIC_END_DATE)	/*BUG208*/
				interRatePtr->infoPtr[0].tillDate = GET_DATE(instrPtr, A_Instr_EndDate);	
			else
				interRatePtr->infoPtr[0].tillDate = tillDate;

			interRate = GET_PERCENT(instrPtr, A_Instr_InterestRateP);
            /* PMSTA5739 - 080222 - DDV - coumpoud instrument treatment */
			if (IS_NULLFLD(instrPtr, A_Instr_CompFreqUnitEn) == FALSE &&
				(FREQUNIT_ENUM) GET_ENUM(instrPtr, A_Instr_CompFreqUnitEn) != FreqUnit_None &&
				IS_NULLFLD(instrPtr, A_Instr_CompFreq) == FALSE &&
				GET_TINYINT(instrPtr, A_Instr_CompFreq) != 0)
			{
				if (complexRateFlg != NULL)
					*complexRateFlg = TRUE;

                /* Enable the compound interest flag for the compound instrument treatment */
                allowCompoundFlg = TRUE;  /* PMSTA-42879 - Silpakal - 210203 */

				FIN_CompoundInter(instrPtr, fromDate, tillDate, 
								  tmpDate.date,    
								  GET_TINYINT(instrPtr, A_Instr_CompFreq),
								  (FREQUNIT_ENUM) GET_ENUM(instrPtr, A_Instr_CompFreqUnitEn),
								  payFreq, accrRule, allowCompoundFlg, /* PMSTA05878 - RAK - 080424 */
								  &interRate);
			}
			else if (GET_ENUM(instrPtr, A_Instr_NatEn) == InstrNat_MoneyMkt &&
			         GET_ENUM(instrPtr, A_Instr_InterestRateConvEn) == InstrIrrConv_Compound)
			{
				if (complexRateFlg != NULL)
					*complexRateFlg = TRUE;

                /* Enable the compound interest flag for the compound instrument treatment */
                allowCompoundFlg = TRUE;   /* PMSTA-42879 - Silpakal - 210203 */

				FIN_CompoundInter(instrPtr, fromDate, tillDate, 
								  tmpDate.date,    
								  1, FreqUnit_Day,
								  payFreq, accrRule, allowCompoundFlg, /* PMSTA05878 - RAK - 080424 */
								  &interRate);
			}

			interRatePtr->infoPtr[0].posRate = interRate;

			interRatePtr->infoPtr[0].negRate = interRate;
		}
	}
	else
	{
	    /* REF3696 - SSO - 990518 */
	    if (IS_NULLFLD(instrPtr, A_Instr_EndDate) == FALSE &&
		    GET_DATE(instrPtr, A_Instr_EndDate) != MAGIC_END_DATE)
	    {
		    instrEndDate = GET_DATE(instrPtr, A_Instr_EndDate);
	    }
	    else
	    {
		    instrEndDate = MAGIC_END_DATE;
	    }

	    /* REF3693 - SSO - 990517: for avrge rate, if bench in instr, use its daily prices as inter conds */
	    if ((GET_ENUM(instrPtr, A_Instr_SubNatEn) == SubNat_AvrgRate)
		    && (IS_NULLFLD(instrPtr, A_Instr_FloatInstrId) == FALSE) )
	    {
		    /* utiliser FIN_InstrPriceArray et FIN_ComputeInterFloatRate sur les quote 
		       prendre entre fromDate-7 et tillDate */	
		    if ((array = ALLOC_DYNST(Array_X)) == NULL)
		    {
		        MSG_RETURN(RET_MEM_ERR_ALLOC);
		    }

		    /* REF3705 - SSO - 990604 if fromDate is greater than tillDate, inverse for data search. */
		    if (fromDate > tillDate)
		    {
		        sv       = tillDate;
		        tillDate = fromDate;
		        fromDate = sv;
		    }

		    tDateTime.date = tillDate;
		    if (tDateTime.date > instrEndDate) /* no more interest after instr end date */
		        tDateTime.date = instrEndDate;
		    tDateTime.time = 0;

            /* REF7597 - YST - 020530 - compute the actual number of days for call FIN_InstrPriceArray */
			DATE_DaysBetween(fromDate, tDateTime.date, AccrRule_Actual_Actual, &reading, 0); /* PMSTA-22396  - SRIDHARA � 160430 */

		    /* retrieve prices between fromDate and tillDate. A week is added (7days) to be sure the
		       price for fromDate is loaded from database */
		    ret = FIN_InstrPriceArray(tDateTime,  1, FreqUnit_Day, (int)reading+8 /*tDateTime.date-fromDate+8*/, /* REF7597 - YST */
			                          GET_ID(instrPtr, A_Instr_FloatInstrId), NULL, 
                                      GET_ID(instrPtr, A_Instr_RefCurrId), 
                                      0, NULL, NULL, array, hierHead);

		    if (ret != RET_SUCCEED)
		    {
		        FREE_DYNST(array, Array_X);
		        return(ret);
		    }


		    j = GET_MULTIARRAY_DIM1(array, 0);
		    arrayData = GET_MULTIARRAY_PTR(array, 0);

		    allocSz = j;
		    if ((interRatePtr->infoPtr = (FIN_RATE_INFO_STP) 
				            CALLOC(allocSz, sizeof(FIN_RATE_INFO_ST)))==(FIN_RATE_INFO_STP)NULL)
		    {
		        FREE_DYNST(array, Array_X);
		        MSG_RETURN(RET_MEM_ERR_ALLOC);
		    }

		    /* Build rates. rate must be the quote of the day before */
		    for (i=7; i<j ;i++)
		    {
		        if (arrayData->notNullFlgTab[i] == TRUE)
		        {
			        ++(interRatePtr->interRateNbr);
			        if (interRatePtr->interRateNbr > allocSz)
			        {
			            allocSz += FIN_REALLOC;
			            if ((interRatePtr->infoPtr = (FIN_RATE_INFO_STP)
				                    REALLOC(interRatePtr->infoPtr, (allocSz*sizeof(FIN_RATE_INFO_ST))))
				            == (FIN_RATE_INFO_STP)NULL)
			        {
				        FREE_DYNST(array, Array_X);
				        MSG_RETURN(RET_MEM_ERR_ALLOC);
			        }
			    }
                /* REF7597 - YST - 020530 - use DATE_Move() to compute dates */
			    interRatePtr->infoPtr[interRatePtr->interRateNbr-1].fromDate = DATE_Move(fromDate, i-8, Day);/*fromDate+i-8*/
			    interRatePtr->infoPtr[interRatePtr->interRateNbr-1].tillDate = DATE_Move(fromDate, i-7, Day);/*fromDate+i-7*/
			    /* use day before quote for rate (multiplied by 100 because in %) */
			    interRatePtr->infoPtr[interRatePtr->interRateNbr-1].posRate  = (GET_NUMBER(arrayData->dataTab, i-1))*100;  /* REF7296 - LJE - 020501 */
			    /* add margin if filled */

			    if (IS_NULLFLD(instrPtr, A_Instr_AddMarginP) == FALSE)
			    {
			        interRatePtr->infoPtr[interRatePtr->interRateNbr-1].posRate += GET_PERCENT(instrPtr, A_Instr_AddMarginP);
			    }
			    interRatePtr->infoPtr[interRatePtr->interRateNbr-1].negRate  = 0;
		    }
		}
		FREE_DYNST(array, Array_X);
	    }
	    else
	    {
		    /* Read table interest condition */
		    /* if fromDate is greater than tillDate, inverse for data search. */
		    if (fromDate > tillDate &&
				is_MM_or_FI_FundShareFlg == FALSE) /* PMSTA05902-CHU-080306 - avoid negative AI if fd > td */
		    {
		        sv       = tillDate;
		        tillDate = fromDate;
		        fromDate = sv;
		    }

		    fDateTime.date = fromDate;
		    fDateTime.time = 0;

		    tDateTime.date = tillDate;
		    tDateTime.time = 0;

		    /* REF3678 - RAK - 990819 - new parameters ... */
		    ret = DBA_SelectInterCond2(instrPtr, fDateTime, tDateTime, &iCond, &interCondNbr, 
					                  &freeInterCondRecFlg, hierHead, intercondNat);

		    if (interCondNbr == 0 || ret != RET_SUCCEED)
		    {
				/* Free result of the select */		/* REF10304 - RAK - 041215 */
		        if (freeInterCondRecFlg == TRUE)	    
		        {
			        for (i=0; i<interCondNbr; i++)
			            FREE_DYNST(iCond[i], A_InterCond);
		        }
		        FREE(iCond);

		        MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO, 
				             "FIN_SearchInterRate", GET_CODE(instrPtr, A_Instr_Cd), 
				             "interest condition parameters");
		        return(RET_FIN_ERR_INVDATA); /* ?? retour select */
		    }

		    allocSz = interCondNbr;

		    if ((interRatePtr->infoPtr = (FIN_RATE_INFO_STP) 
				   CALLOC(allocSz, sizeof(FIN_RATE_INFO_ST)))==(FIN_RATE_INFO_STP)NULL)
		    {
		        /* Free result of the select */
		        if (freeInterCondRecFlg == TRUE)	    /* REF3678 - RAK - 990819 */
		        {
			        for (i=0; i<interCondNbr; i++)
			            FREE_DYNST(iCond[i], A_InterCond);
		        }
		        FREE(iCond);
		        MSG_RETURN(RET_MEM_ERR_ALLOC);
		    }

		    /* REF3693 - SSO - 990517 part. cas added: if Average Rate, */
            /* we need the condition when computing the beg. date */
		    avrgRateFlg = (FLAG_T)(GET_ENUM(instrPtr, A_Instr_SubNatEn) == SubNat_AvrgRate);

		    /* Interest condition selected are order by calculation */
		    /* rule (fixed and floating) and begin date.            */
		    oldTill = fromDate;
		    i = j = k = crtFloat = 0;

		    /* Read all fixed conditions until end period */
		    while (((oldTill <= tillDate) ||  /*PMSTA 23459 - Naveen - 01062016 - Ensuring AI is calculated for coupon date+1*/
				((avrgRateFlg == TRUE || is_MM_or_FI_FundShareFlg == TRUE) && oldTill == tillDate) )  /* REF3693 - SSO - 990517 */
		           && i < interCondNbr)	/* BUG426 */ 
		    {
		        /* Terminate with last fixed condition */
		        if (i == interCondNbr-1 || 			/* BUG426 */
			        GET_ENUM(iCond[i], A_InterCond_IntCalcRuleEn) != InterCalcRule_Fixed) /* PMSTA-21816 - DDV - 151127 */
		        { fixFrom = tillDate; }
		        else
		        { fixFrom = GET_DATE(iCond[i], A_InterCond_BeginDate); }
		    
		        /* Treat blank periods, search floating condition(s) */
		        if ((fixFrom > oldTill) ||
					((avrgRateFlg == TRUE || is_MM_or_FI_FundShareFlg == TRUE) && fixFrom == oldTill) )  /* REF3693 - SSO - 990517 */
		        {
			        /* Advance on next valid floating condition */
			        k = crtFloat;
			        while (k < interCondNbr && 
						((GET_ENUM(iCond[k], A_InterCond_IntCalcRuleEn) != InterCalcRule_Floating &&
						GET_ENUM(iCond[k], A_InterCond_IntCalcRuleEn) != InterCalcRule_Digital &&   /* PMSTA-21816 - DDV - 151127 */ /* PMSTA-21906 - SHR - 151218 */
                        GET_ENUM(iCond[k], A_InterCond_IntCalcRuleEn) != InterCalcRule_RangeAccrual && /* PMSTA-36699  - Silpakal - 191121  */
                        GET_ENUM(iCond[k], A_InterCond_IntCalcRuleEn) != InterCalcRule_Memory) ||
			            GET_DATE(iCond[k], A_InterCond_EndDate) <= oldTill))
			            ++k;
			
			        crtFloat = k;  /* keep current floating condition */
					double IRC_posrate = 0;
					long IRC_numdays = 0;
			
			        /* Read valid floating condition(s) */
			        while (oldTill < fixFrom && k < interCondNbr)	/* BUG426 */
			        {
			            if (k == interCondNbr-1)			/* BUG426 */
				            begD = fixFrom;
			            else
			            {
				            begD = GET_DATE(iCond[k], A_InterCond_BeginDate);
				
				            /* Blank period */				/* BUG485 */
				            if (begD > oldTill) 
				            {
				                /* Test if allocated new memory is necessary */
				                /* floating rate, new condition is created   */
				                ++(interRatePtr->interRateNbr);
				                if (interRatePtr->interRateNbr > allocSz)
				                {
					                allocSz += FIN_REALLOC;
					                if ((interRatePtr->infoPtr = (FIN_RATE_INFO_STP)
					                    REALLOC(interRatePtr->infoPtr, 
					                            (allocSz*sizeof(FIN_RATE_INFO_ST))))
					                        == (FIN_RATE_INFO_STP)NULL)
					                {
					                    /* Free result of the select */
					                    if (freeInterCondRecFlg == TRUE)	/* REF3678 - RAK - 990819 */
					                    {
						                    for (i=0; i<interCondNbr; i++)
                                            { FREE_DYNST(iCond[i], A_InterCond);}
					                    }
					                    FREE(iCond);
					                    MSG_RETURN(RET_MEM_ERR_ALLOC);
					                }
				                }
				    
				                interRatePtr->infoPtr[j].fromDate = oldTill;
				                interRatePtr->infoPtr[j].tillDate = begD;
				                /* REF3696 - SSO - 990518. NB: we know that begD<=tillDate (see DBA_SelectInterCond) */
				                interRatePtr->infoPtr[j].posRate  = 0.0;
				                interRatePtr->infoPtr[j].negRate  = 0.0;
				    
				                /* advance to the next till date */
				                oldTill = interRatePtr->infoPtr[j].tillDate;
				    
				                ++j;  /* interest rate structure index */
				            }
			            }
			    
			            if (k < interCondNbr)  
			            {
				            /* Test if allocated new memory is necessary */
				            /* floating rate, new condition is created   */
				            ++(interRatePtr->interRateNbr);
				            if (interRatePtr->interRateNbr > allocSz)
				            {
				                allocSz += FIN_REALLOC;
				                if ((interRatePtr->infoPtr = (FIN_RATE_INFO_STP)
					                 REALLOC(interRatePtr->infoPtr, (allocSz*sizeof(FIN_RATE_INFO_ST))))
					                    == (FIN_RATE_INFO_STP) NULL)
				                {
					                /* Free result of the select */
					                if (freeInterCondRecFlg == TRUE)	/* REF3678 - RAK - 990819 */
					                {
					                    for (i=0; i<interCondNbr; i++)
                                        { FREE_DYNST(iCond[i], A_InterCond);}
					                }
					                FREE(iCond);
					                MSG_RETURN(RET_MEM_ERR_ALLOC);
				                }
				            }
				
				            interRatePtr->infoPtr[j].fromDate = oldTill;
				
				            if (IS_NULLFLD(iCond[k], A_InterCond_EndDate) == FALSE)
				            {
				                if (GET_DATE(iCond[k], A_InterCond_EndDate) == MAGIC_END_DATE)
				                {
					                if (k+1 < interCondNbr)
					                    interRatePtr->infoPtr[j].tillDate = 
					                                    GET_DATE(iCond[k+1], A_InterCond_BeginDate);
					                else
					                    interRatePtr->infoPtr[j].tillDate = fixFrom;
				                }
				                else
				                {
					                if (GET_DATE(iCond[k], A_InterCond_EndDate) > fixFrom)
					                    interRatePtr->infoPtr[j].tillDate = fixFrom;
					                else
					                    interRatePtr->infoPtr[j].tillDate =  
					                                    GET_DATE(iCond[k], A_InterCond_EndDate);
				                }
				            }
				            else
				            {
				                interRatePtr->infoPtr[j].tillDate = fixFrom;
				            }

				            /* REF3696 - SSO - 990518. Here the .tillDate could be after instrEndDate */
				            if (interRatePtr->infoPtr[j].tillDate > instrEndDate)
				                interRatePtr->infoPtr[j].tillDate = instrEndDate;
				
				            /* Compute floating rate */
				            FIN_ComputeInterFloatRate(instrPtr, interRatePtr->infoPtr[j].fromDate, 
				                                      interRatePtr->infoPtr[j].tillDate, 
				                                      payFreq, accrRule, iCond[k], 
				                                      &interRatePtr->infoPtr[j].posRate, hierHead);
							/*PMSTA-46466 SENTHILKUMAR - 20102021*/
							if (multipleIRCFlg == TRUE && (static_cast<InstrMktConvMethodEn>GET_ENUM(iCond[0], A_InterCond_MktConvMethodEn) != InstrMktConvMethodEn::None))
							{
								DATE_PERIOD_ST  periodYearDay;
								ID_T			calendarId = 0;
								DBA_GetCalendarFromInstr(instrPtr, &calendarId);
								DATE_AccrPeriod(interRatePtr->infoPtr[j].fromDate, interRatePtr->infoPtr[j].tillDate, accrRule, Day, &periodYearDay, calendarId);
								if (interCondNbr > 1)
								{
									IRC_posrate += interRatePtr->infoPtr[j].posRate*periodYearDay.num;
									IRC_numdays += periodYearDay.num;
								}
							}
				            interRatePtr->infoPtr[j].negRate = interRatePtr->infoPtr[j].posRate;
				
				            /* advance to the next till date */
				            oldTill = interRatePtr->infoPtr[j].tillDate;
				
				            ++j;  /* interest rate structure index */
				            ++k;  /* floating condition index */
			            }		
			        }
					if (multipleIRCFlg == TRUE && interCondNbr > 1 && (static_cast<InstrMktConvMethodEn>GET_ENUM(iCond[0], A_InterCond_MktConvMethodEn) != InstrMktConvMethodEn::None))
						interRatePtr->infoPtr[0].posRate = interRatePtr->infoPtr[0].negRate = (PERCENT_T)IRC_posrate / IRC_numdays;
		        }
		    
		        /*** New condition ***/
		        if ((oldTill <= tillDate  ||    /*PMSTA 23459 - Naveen - 01062016 - Ensuring AI is calculated for coupon date+1*/
					((avrgRateFlg == TRUE || is_MM_or_FI_FundShareFlg == TRUE) && oldTill == tillDate) )  /* REF3693 - SSO - 990517 */
			        && i < interCondNbr &&		/* BUG485 */
			        GET_ENUM(iCond[i], A_InterCond_IntCalcRuleEn) == InterCalcRule_Fixed)  /* PMSTA-21816 - DDV - 151127 */
		        {
			        /* Test if allocated new memory is necessary because if */
			        /* one blank period exist without floating rate, new    */
			        /* condition is created                                 */
			        ++(interRatePtr->interRateNbr);
			
                    if (interRatePtr->interRateNbr > allocSz)
			        {
			            allocSz += FIN_REALLOC;
			            if ((interRatePtr->infoPtr = (FIN_RATE_INFO_STP)
				                REALLOC(interRatePtr->infoPtr, (allocSz*sizeof(FIN_RATE_INFO_ST)))) 
				                        == (FIN_RATE_INFO_STP) NULL)
			            {
				            /* Free result of the select */
				            if (freeInterCondRecFlg == TRUE)	/* REF3678 - RAK - 990819 */
				            {
				                for (i=0; i<interCondNbr; i++)
				                {
					                FREE_DYNST(iCond[i], A_InterCond);
				                }
				            }
				            FREE(iCond);
				            MSG_RETURN(RET_MEM_ERR_ALLOC);
			            }
			        }
			
			        interRatePtr->infoPtr[j].fromDate = GET_DATE(iCond[i], A_InterCond_BeginDate);
			
			        if (IS_NULLFLD(iCond[i], A_InterCond_EndDate) == FALSE)
			        {
			            if (GET_DATE(iCond[i], A_InterCond_EndDate) == MAGIC_END_DATE)
			            {
				            if (i+1 < interCondNbr)
				                interRatePtr->infoPtr[j].tillDate = 
				                                GET_DATE(iCond[i+1], A_InterCond_BeginDate);
				            else
				                interRatePtr->infoPtr[j].tillDate = tillDate;
			            }
			            else
			            {
				            if (GET_DATE(iCond[i], A_InterCond_EndDate) > tillDate)
				                interRatePtr->infoPtr[j].tillDate = tillDate;
				            else
				            { interRatePtr->infoPtr[j].tillDate = 
                                                        GET_DATE(iCond[i], A_InterCond_EndDate); }
			            }
			        }
			        else
			        {
			            interRatePtr->infoPtr[j].tillDate =  tillDate;
			        }
			
			        /* REF3696 - SSO - 990518. Here the .tillDate could be after instrEndDate */
			        if (interRatePtr->infoPtr[j].tillDate > instrEndDate)
			            interRatePtr->infoPtr[j].tillDate = instrEndDate;

 					/* PMSTA-21816 - DDV - 151127 - Always true */
					/* if (GET_ENUM(iCond[i], A_InterCond_InterCalcRuleEn) == InterCalcRule_Fixed)
			        {*/
			        interRatePtr->infoPtr[j].posRate = 
				                    GET_PERCENT(iCond[i], A_InterCond_InterestRateP);
			    
			        interRatePtr->infoPtr[j].negRate = 
				                    GET_PERCENT(iCond[i], A_InterCond_NegBalRateP);

					tmpTillDate=tillDate;
					if (i < interCondNbr-1)
						tmpTillDate=GET_DATE(iCond[i+1], A_InterCond_BeginDate);

                    /* PMSTA05739 - 080221 - DDV - coumpoud instrument treatment */
				   	if (IS_NULLFLD(iCond[i], A_InterCond_CompoundFreqUnitEn) == FALSE &&
						(FREQUNIT_ENUM) GET_ENUM(iCond[i], A_InterCond_CompoundFreqUnitEn) != FreqUnit_None &&
						IS_NULLFLD(iCond[i], A_InterCond_CompoundFreq) == FALSE &&
						GET_TINYINT(iCond[i], A_InterCond_CompoundFreq) != 0)
			        {                        
                        if (IS_NULLFLD(iCond[i], A_InterCond_MktConvMethodEn) == FALSE && /*PMSTA-43096 - Kramadevi - 10032021 : Libor Transition changes*/
                            static_cast<InstrMktConvMethodEn>GET_ENUM(iCond[i], A_InterCond_MktConvMethodEn) != InstrMktConvMethodEn::None)
                        {
                            /*daily compounding with daily rates and  Libor transition changes are handled in FIN_ComputeInterFloatRate*/
                            continue;
                        }

						if (complexRateFlg != NULL)
							*complexRateFlg = TRUE;

						/* Enable the compound interest flag for the compound instrument treatment */
						allowCompoundFlg = TRUE;  /* PMSTA-42879 - SRIDHARA - 18032021 */

						FIN_CompoundInter(instrPtr, fromDate, tmpTillDate, 
								            GET_DATE(iCond[i], A_InterCond_BeginDate),
											GET_TINYINT(iCond[i], A_InterCond_CompoundFreq),
											(FREQUNIT_ENUM) GET_ENUM(iCond[i], A_InterCond_CompoundFreqUnitEn),
											payFreq, accrRule, allowCompoundFlg, /* PMSTA05878 - RAK - 080424 */
											&interRatePtr->infoPtr[j].posRate);
			        }
					else if (GET_ENUM(instrPtr, A_Instr_NatEn) == InstrNat_MoneyMkt &&
						        GET_ENUM(instrPtr, A_Instr_InterestRateConvEn) == InstrIrrConv_Compound)
					{
						if (complexRateFlg != NULL)
							*complexRateFlg = TRUE;

						/* Enable the compound interest flag for the compound instrument treatment */
						allowCompoundFlg = TRUE;  /* PMSTA-42879 - SRIDHARA - 18032021 */

						FIN_CompoundInter(instrPtr, fromDate, tmpTillDate, 
											GET_DATE(iCond[i], A_InterCond_BeginDate),
											1, FreqUnit_Day,
											payFreq, accrRule, allowCompoundFlg, /* PMSTA05878 - RAK - 080424 */
											&interRatePtr->infoPtr[j].posRate);
					}
				    /* PMSTA-21816 - DDV - 151127 - impossible case */
			        /* }
			        else
			        {
			             Compute floating rate 
			            FIN_ComputeInterFloatRate(instrPtr, interRatePtr->infoPtr[j].fromDate, 
				                                  interRatePtr->infoPtr[j].tillDate, 
				                                  payFreq, accrRule, iCond[k], 
				                                  &interRatePtr->infoPtr[j].posRate, hierHead);
			    
			            interRatePtr->infoPtr[j].negRate = interRatePtr->infoPtr[j].posRate;
			        }*/
			
			        /* advance to the next till date */
			        oldTill = interRatePtr->infoPtr[j].tillDate;
			
			        ++j;    /* interest rate structure index */
		        }
		    
		        interRatePtr->interCalcRuleEn = (INTERCALCRULE_ENUM) GET_ENUM(iCond[i], A_InterCond_IntCalcRuleEn); /* REF7264 - PMO */
		    
		        ++i;    /* interest condition index */
		    } /* while */

		    /* reverse date */
		    if (sv != BAD_DATE)
		    {
		        fromDate = tillDate;
		        tillDate = sv;
		    }

		    /* Free result of the select */
		    if (freeInterCondRecFlg == TRUE)	/* REF3678 - RAK - 990819 */
		    {
		        for (i=0; i<interCondNbr; i++)
		        {FREE_DYNST(iCond[i], A_InterCond);}
		    }
		    FREE(iCond);
	    }
	}

	return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_TaxRateUnitAccrInter()
**
**  Description :   Compute tax rate on unitary accrued interest
**                  
**  Arguments   :   unitAccrInter : pointer on accrued interest number
**                  instrPtr      : pointer on instrument structure
**
**  Return      :   none, unitAccrInter contents can be modified
**
**  Creation    :   DVP152 - RAK - 960628
**  Modif.      :   BUG193 - RAK - 961107
**
*************************************************************************/
STATIC void FIN_TaxRateUnitAccrInter(NUMBER_T *unitAccrInter, DBA_DYNFLD_STP instrPtr)
{
	if (IS_NULLFLD(instrPtr, A_Instr_TaxRateP) == FALSE)
	{
	    if (GET_PERCENT(instrPtr, A_Instr_TaxRateP) >= 0.0 &&
		    GET_PERCENT(instrPtr, A_Instr_TaxRateP) <= 100.0)
	    {
	    	PERCENT_T tax;
		    tax = GET_PERCENT(instrPtr, A_Instr_TaxRateP) / 100.0;
		    *unitAccrInter = (*unitAccrInter) * (1 - tax);
	    }
	}
	return;
}

/************************************************************************
**
**  Function    :   FIN_UnitAccrInter()
**
**  Description :   The computation of accrued interest needs first to know
**                  when interest has been accrueing by analysing income
**                  events. 
**                  Having obtained this date, one has to determine whether 
**                  accrued interest is calculated on a quantity at the
**                  reference date or whether it should be computed according to
**                  all past quantities since the accrual period begining.
**                  It is then required to obtain the interest rate(s) 
**                  applicable over the period. This rates may either be fixed 
**                  or calculated according to a benchmark rate.
**                  For each change in quantity or rate, one calculates 
**                  accrued interest. 
**                  
**  Arguments   :   refDateTime   reference date
**                  instrId       instrument identification
**                  inputInstrPtr pointer on instrument structure or NULL
**                  fusDateRule   fusion date rule 
**                  fullCoupFlg   parameter which determine if accrued 
**                                interest on the first interest accrual date 
**                                is equal to 0 or to a full interest period.
**                  calcAccrInterFlg  flag which is TRUE if interest must 
**                                be calculated, FALSE if stored data can 
**                                be used.
**                  accrInterPtr pointer on interest structure to fill
**                  aiArgStp        Pointer to AI arguments. Can be NULL
**
**  Return      :   RET_SUCCEED           if accrued interest was computed
**                  RET_GEN_INFO_NOACTION if no accrued interest for instrument
**                  or error code 
*************************************************************************/
RET_CODE FIN_UnitAccrInter(DATETIME_T           refDateTime, 
		                   ID_T                 instrId, 
		                   DBA_DYNFLD_STP       inputInstrPtr, 
		                   FUSDATERULE_ENUM     fusDateRule, 
		                   char                 fullCoupFlg, 
		                   char                 calcAccrInterFlg, 
                           ACCRINTERMETHOD_ENUM accrInterMethod,
                           DATETIME_T           accrValFromDate,
						   ACCRRULE_ENUM        accrRule, /* REF11218 - TEB - 050627 */
			               DBA_DYNFLD_STP       posPtr,
		                   DBA_DYNFLD_STP       accrInterPtr,
		                   DBA_HIER_HEAD_STP    hierHead,
						   FLAG_T				calledFromFinQuoteToPriceFlg,
                           FIN_AIARG_STP        aiArgStp)   /* PMSTA08308 - 090609 - PMO */
{
	DBA_DYNFLD_STP      instrPtr=NULL, 
			            instrChrono=NULL, getUnitInter=NULL,
			            bondPtr=NULL, dimChronoPtr=NULL; 
	INSTRNAT_ENUM       instrNat = InstrNat_None;
    SUBNAT_ENUM         instrSubNat = SubNat_None;
	RNDRULE_ENUM        rndRuleEn;
	FIN_ACCR_PERIOD_ST  accrPeriod;
	FIN_INTERRATE_ST    interRate;
	FIN_QUANT_ST        quant;    
    DATETIME_T          chronoDate;   /* REF4637 - RAK - 000502 */
	NUMBER_T            instrChronoVal = 0.0; /* PERCENT_T unpaidPrct; */ /*REF7280 - YST - 020404 */
	ID_T                getInstrId;
	FLAG_T              allocOk, foundIR;
	double              round;
	PRICECALCRULE_ENUM  priceCalc;
	RET_CODE            ret;
	FLAG_T				is_MM_or_FI_FundShareFlg = FALSE; /* PMSTA01512-CHU-070503 */
	DATE_T				firstCoupDate = (DATE_T)0; /* PMSTA02642-CHU-070725 */
	NUMBER_T			longCoupVal = 0.0; /* PMSTA02642-CHU-070725 */
	INT_T				longNumPeriod = 0; /* PMSTA02642-CHU-070725 */
	FLAG_T				updateAccrRuleFlg=FALSE;
	ID_T				calendarId = 0; 	/* PMSTA-22396  - SRIDHARA - 160430 */
    DATE_T boForceAiDate = 0;
    bool BoForceChrono = false; /*PMSTA-42064-ARUN-20102020*/

    /* PMSTA-36699  - Silpakal - 191121  */
    DBA_DYNFLD_STP      inputData = NULLDYNST;
    DBA_DYNFLD_STP      *selInterTab = NULLDYNSTPTR;
    int                 selInterNbr = 0;
    FLAG_T		        interCondRecFlg = FALSE;
    INTERCALCRULE_ENUM  instrCondCalcRuleEn = InterCalcRule_Fixed;
    MemoryPool mp;
 
	memset(&accrPeriod, 0, sizeof(FIN_ACCR_PERIOD_ST));	/* REF1079 */
	memset(&interRate, 0, sizeof(FIN_INTERRATE_ST));	

	/**** LOAD INSTRUMENT ****/
	/* If instrument structure was load upper, his pointer is given */
	/* in parameters list. So function use it and don't free it.    */
	if (inputInstrPtr != NULL)
	{
		instrPtr = inputInstrPtr;
		allocOk = FALSE;
	}
	else
	{
        /* REF3913 - 990820 - DDV */
        if ((ret = DBA_GetInstrById(instrId, FALSE, &allocOk, 
                                    &instrPtr, hierHead, UNUSED, UNUSED)) != RET_SUCCEED)
        {
			SYSNAME_T entSqlName;
			strcpy(entSqlName, DBA_GetDictEntitySqlName(Instr));
			MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO, entSqlName, instrId);
   			return(RET_DBA_ERR_NODATA); /* ?? */
		}
	}

	/* PMSTA-10443 - RAK - 101022 */
	/* Developer Information Not Obsolete Serious And Useful Recommendation � DINOSAUR � KRA � 110831 */
	/* here we do want we want (and not what customer want) and in some cases, use SimCorp computation */
	/* (it does is so perfectly) instead of "home" computation */
	FIN_SetSceActActRule(instrPtr, &updateAccrRuleFlg);

	instrNat = (INSTRNAT_ENUM) GET_ENUM(instrPtr, A_Instr_NatEn);
    instrSubNat = (SUBNAT_ENUM) GET_ENUM(instrPtr, A_Instr_SubNatEn);

	/* PMSTA01512-CHU-070503 */
	is_MM_or_FI_FundShareFlg = (FLAG_T)(instrNat == InstrNat_FundShare &&
									(instrSubNat == SubNat_MoneyMarketFundShare ||
									 instrSubNat == SubNat_FixedIncomeFundShare));

	/* PMSTA02642-CHU-070725 */
	if (IS_NULLFLD(instrPtr, A_Instr_FirstCoupDate) == FALSE)
		firstCoupDate = GET_DATE(instrPtr, A_Instr_FirstCoupDate); 

    /* REF5306 - RAK - 010208 - Swap AI is the summ of legs AI */
    if (instrNat == InstrNat_Swap)
    {
        DBA_DYNFLD_STP  *swapLegTab=NULL, legAccrInterPtr=NULL;
        NUMBER_T        swapUnitAI=0.0;
        int             i, swapLegNbr=0;
        FLAG_T          freeInstrFlg=FALSE;

        SET_ID(accrInterPtr,       UnitInter_InstrId,       GET_ID(instrPtr, A_Instr_Id));
	    SET_ID(accrInterPtr,       UnitInter_CurrId,        GET_ID(instrPtr, A_Instr_RefCurrId));
	    SET_DATETIME(accrInterPtr, UnitInter_ValidDate,     refDateTime);
	    SET_FLAG(accrInterPtr,     UnitInter_ExCouponFlg,   TRUE); 
	    SET_FLAG(accrInterPtr,     UnitInter_CalcFlg,       (FLAG_T) calcAccrInterFlg);
	    SET_FLAG(accrInterPtr,     UnitInter_FullCoupFlg,   (FLAG_T) fullCoupFlg);
	    SET_ENUM(accrInterPtr,     UnitInter_FusDateRuleEn, (ENUM_T) fusDateRule);    

        if ((ret = FIN_SwapLegInstr(instrPtr, hierHead, refDateTime, 
		                            &swapLegTab, &swapLegNbr, &freeInstrFlg)) != RET_SUCCEED)
	    {
			/* PMSTA-10443 - RAK - 101022 */
	        if (allocOk == TRUE) 
			{FREE_DYNST(instrPtr, A_Instr);}
			else 
			{FIN_ResetSceActActRule(instrPtr, updateAccrRuleFlg);}
            return(ret);
	    }


        if ((legAccrInterPtr = ALLOC_DYNST(UnitInter)) == NULL)
	    {
		    /* PMSTA-10443 - RAK - 101022 */
	        if (allocOk == TRUE) 
			{FREE_DYNST(instrPtr, A_Instr);}
			else 
			{FIN_ResetSceActActRule(instrPtr, updateAccrRuleFlg);}
            if (freeInstrFlg == TRUE)
            { DBA_FreeDynStTab(swapLegTab, swapLegNbr, A_Instr);}
            FREE(swapLegTab);
		    MSG_RETURN(RET_MEM_ERR_ALLOC);
	    }

        for (i=0; i<swapLegNbr; i++)
        {
            /* REF7265 - YST - 020320 - add two new arguments */
            ret = FIN_UnitAccrInter(refDateTime, GET_ID(swapLegTab[i], A_Instr_Id), swapLegTab[i],
		                            fusDateRule, fullCoupFlg, calcAccrInterFlg, AccrInterMethod_Default, refDateTime,
									accrRule, /* REF11218 - TEB - 050627 */
                                    posPtr, legAccrInterPtr, hierHead, FALSE, NULL); /* PMSTA08308 - 090609 - PMO / PMSTA05389-CHU-080131*/
            if (ret == RET_SUCCEED)
            {
                /* REF5979 - RAK - 010508 */
                /* In case of composite swap use compo qty for summ or substract ai */
                /* REF7782 - YST - 020904 - add SubNat_FixFltSwapHedgFix */
                if (instrSubNat != SubNat_FixFloatStdSwap && instrSubNat != SubNat_FixFixStdSwap &&
	                instrSubNat != SubNat_FltFltStdSwap && instrSubNat != SubNat_FixFltSwapHedgFix)	/*REF1485*/
                {
                    swapUnitAI += (GET_NUMBER(legAccrInterPtr, UnitInter_UnitAccrInter) *
                                   GET_NUMBER(swapLegTab[i], A_Instr_CompoQuantity));
                }
                else
                {
                    /* REF5767 - RAK - 010313 Missing SubNat_RecSwapFloatLeg */
                    if ((SUBNAT_ENUM) GET_ENUM(swapLegTab[i], A_Instr_SubNatEn) == SubNat_RecSwapFixedLeg || 
                        (SUBNAT_ENUM) GET_ENUM(swapLegTab[i], A_Instr_SubNatEn) == SubNat_RecSwapFloatLeg) 
                    { swapUnitAI = swapUnitAI + 
                                    GET_NUMBER(legAccrInterPtr, UnitInter_UnitAccrInter);}
                    else
                    { swapUnitAI = swapUnitAI - 
                                    GET_NUMBER(legAccrInterPtr, UnitInter_UnitAccrInter);}
                }
            }
        }

        /* REF5767 - RAK - 010313 */
        /* if (ret == RET_SUCCEED) */
        SET_NUMBER(accrInterPtr, UnitInter_UnitAccrInter, swapUnitAI);

        /* keep last value */
        COPY_DYNFLD(accrInterPtr,    UnitInter, UnitInter_NumPeriod,
                    legAccrInterPtr, UnitInter, UnitInter_NumPeriod);
        COPY_DYNFLD(accrInterPtr,    UnitInter, UnitInter_DenomPeriod,
                    legAccrInterPtr, UnitInter, UnitInter_DenomPeriod);
        COPY_DYNFLD(accrInterPtr,    UnitInter, UnitInter_UnitFlg,
                    legAccrInterPtr, UnitInter, UnitInter_UnitFlg);
        COPY_DYNFLD(accrInterPtr,    UnitInter, UnitInter_InterCalcRuleEn,
                    legAccrInterPtr, UnitInter, UnitInter_InterCalcRuleEn);
        COPY_DYNFLD(accrInterPtr,    UnitInter, UnitInter_BegDate,
                    legAccrInterPtr, UnitInter, UnitInter_BegDate);

        FREE_DYNST(legAccrInterPtr, UnitInter);  
        if (freeInstrFlg == TRUE)
        { DBA_FreeDynStTab(swapLegTab, swapLegNbr, A_Instr);}
        FREE(swapLegTab);

		/* PMSTA-10443 - RAK - 101022 */
        if (allocOk == TRUE) 
		{FREE_DYNST(instrPtr, A_Instr);}
		else 
		{FIN_ResetSceActActRule(instrPtr, updateAccrRuleFlg);}
        return(RET_SUCCEED);    /* REF5767 - Always succeed */
    }

	/* PMSTA-48782 - ankita - 220622 */
	AppIncDivAccrualPos applIncludeDivAccrualPos = AppIncDivAccrualPos::includeInCashPos;
	GEN_GetApplInfo(ApplIncludeDivAccrualPosEnum, &applIncludeDivAccrualPos);

    /**** CHECK NATURE ****/ 
	if (instrNat != InstrNat_Bond        && instrNat != InstrNat_CumOption &&
	    instrNat != InstrNat_ConvertBond && instrNat != InstrNat_Discount &&
	    instrNat != InstrNat_CashAcct    && instrNat != InstrNat_MoneyMkt && 
	    instrNat != InstrNat_Other       && instrNat != InstrNat_MortBackSecu && /* GRD - 970711 - DVP539 */
        instrNat != InstrNat_FlowInstr   && /* REF6004 - AKO - 020122 */
		(instrNat != InstrNat_FundShare  &&				/* PMSTA-1512-CHU-070326 */
		 instrSubNat != SubNat_MoneyMarketFundShare &&	/* PMSTA-1512-CHU-070326 */
		 instrSubNat != SubNat_FixedIncomeFundShare) && /* PMSTA-1512-CHU-070326 */
		!(applIncludeDivAccrualPos == AppIncDivAccrualPos::includeInStockPos &&   /* PMSTA-48782 - ankita - 220622 */
			GET_ENUM(instrPtr, A_Instr_NatEn) == (ENUM_T)InstrNat_Stock)) 
	{
		/* PMSTA-10443 - RAK - 101022 */
        if (allocOk == TRUE) 
		{FREE_DYNST(instrPtr, A_Instr);}
		else 
		{FIN_ResetSceActActRule(instrPtr, updateAccrRuleFlg);}
		return(RET_GEN_INFO_NOACTION);
	}

	/* REF1055 - RAK - 991130 */
	/* Accrued interest is computed by SCECON in price for this kind of bond */
    /* REF7265 - YST - 020312 */
    /* Compute accrued interests for swap legs if accrInterMethod = AccrInterMethod_AccrVal */
	if (instrNat == InstrNat_Bond) 
	{
        /* REF5306 - RAK - 010208 - For fixed leg, AI is now computed */
	    /* if (GET_ENUM(instrPtr, A_Instr_SubNatEn) == SubNat_RecSwapFloatLeg ||
		GET_ENUM(instrPtr, A_Instr_SubNatEn) == SubNat_RecSwapFixedLeg ||
		GET_ENUM(instrPtr, A_Instr_SubNatEn) == SubNat_PaidSwapFloatLeg ||
		GET_ENUM(instrPtr, A_Instr_SubNatEn) == SubNat_PaidSwapFixedLeg) */
        
        if (instrSubNat == SubNat_RecSwapFloatLeg || instrSubNat == SubNat_PaidSwapFloatLeg)
	    {
            /* REF9110.4001B - YST - 030520 */
		    if (GET_ENUM(instrPtr, A_Instr_InterestRateConvEn) == InstrIrrConv_None &&
                accrInterMethod != AccrInterMethod_AccrVal)
            {
                /* PMSTA-10443 - RAK - 101022 */
				if (allocOk == TRUE) 
				{FREE_DYNST(instrPtr, A_Instr);}
				else 
				{FIN_ResetSceActActRule(instrPtr, updateAccrRuleFlg);}
		        return(RET_GEN_INFO_NOACTION);
            }
            /* REF7251 - YST - 020501 - copy ExtPos_Rate only if no IRC table is defined */
            else if (GET_FLAG(instrPtr, A_Instr_GenericFlg) == TRUE &&
                    IS_NULLFLD(posPtr, ExtPos_Rate) != TRUE &&
                    (INTERCD_ENUM)GET_ENUM(instrPtr, A_Instr_InterestCdEn) == InterCd_Instr)
		    {
                SET_PERCENT(instrPtr, A_Instr_AddMarginP, GET_PERCENT(posPtr, ExtPos_Rate)); 
            }
	    }
        /* REF5785 - RAK - 010313 - Test interest rate convention for fixed legs */
        else if ((instrSubNat == SubNat_RecSwapFixedLeg || instrSubNat == SubNat_PaidSwapFixedLeg) &&
                  GET_ENUM(instrPtr, A_Instr_InterestRateConvEn) == InstrIrrConv_None &&
                  accrInterMethod != AccrInterMethod_AccrVal)
        {
		    /* PMSTA-10443 - RAK - 101022 */
	        if (allocOk == TRUE) 
			{FREE_DYNST(instrPtr, A_Instr);}
			else 
			{FIN_ResetSceActActRule(instrPtr, updateAccrRuleFlg);}
		    return(RET_GEN_INFO_NOACTION);
	    }
	}

	/* Replace cum option by ex bond */
	if (instrNat == InstrNat_CumOption)
	{
		if ((bondPtr = ALLOC_DYNST(A_Instr)) == NULL)
		{
			/* PMSTA-10443 - RAK - 101022 */
	        if (allocOk == TRUE) 
			{FREE_DYNST(instrPtr, A_Instr);}
			else 
			{FIN_ResetSceActActRule(instrPtr, updateAccrRuleFlg);}
			MSG_RETURN(RET_MEM_ERR_ALLOC);
		}

		if ((ret = FIN_TreatCumOption(instrPtr, refDateTime, bondPtr, hierHead)) != RET_SUCCEED)
		{
			/* PMSTA-10443 - RAK - 101022 */
	        if (allocOk == TRUE) 
			{FREE_DYNST(instrPtr, A_Instr);}
			else 
			{FIN_ResetSceActActRule(instrPtr, updateAccrRuleFlg);}
			FREE_DYNST(bondPtr, A_Instr);
			return(ret);
		}

		/* cum option was loaded in this function */
		/* PMSTA-10443 - RAK - 101022 */
        if (allocOk == TRUE) 
		{FREE_DYNST(instrPtr, A_Instr);}
		else 
		{FIN_ResetSceActActRule(instrPtr, updateAccrRuleFlg);}

		/* replace and remember allocation */
		instrPtr = bondPtr;
		allocOk  = TRUE; /* bondPtr will be free */
	}

	/**** TEST ACCRUED INTEREST FLAG ****/
	if (GET_FLAG(instrPtr, A_Instr_AccruedIntFlg) == FALSE)
	{
		/* REF11842 - RAK - 060807 */
		if ((PRICECALCRULE_ENUM)GET_ENUM(instrPtr, A_Instr_PriceCalcRuleEn) != PriceCalcRule_QuoteInUnit ||
			calledFromFinQuoteToPriceFlg == FALSE)
		{
			/* PMSTA-10443 - RAK - 101022 */
	        if (allocOk == TRUE) 
			{FREE_DYNST(instrPtr, A_Instr);}
			else 
			{FIN_ResetSceActActRule(instrPtr, updateAccrRuleFlg);}
			return(RET_GEN_INFO_NOACTION);
		}
	}

	/* No accrued interest for non treated money market */
	if (instrNat == InstrNat_Discount || instrNat == InstrNat_MoneyMkt)
	{
	    if (GET_ID(instrPtr, A_Instr_Id) > 0)
	    {
		    DATETIME_T tmpDate;

		    /* REF1210 - Use position only fon generic and incompleted generic */
		    if ((GET_FLAG(instrPtr, A_Instr_GenericFlg) == TRUE ||
		        (GET_FLAG(instrPtr, A_Instr_GenericFlg) == FALSE &&
		        IS_NULLFLD(instrPtr, A_Instr_BeginDate) == TRUE)) && posPtr == NULL)
		    {
	            /* PMSTA-10443 - RAK - 101022 */
				if (allocOk == TRUE) 
				{FREE_DYNST(instrPtr, A_Instr);}
				else 
				{FIN_ResetSceActActRule(instrPtr, updateAccrRuleFlg);}
	            return(RET_SUCCEED); 
		    }

		    if (GET_FLAG(instrPtr, A_Instr_GenericFlg) == TRUE)
		    {
		        /* BUG376 - RAK - 970522 */
                /* REF7251 - YST - 020501 - copy ExtPos_Rate only if no IRC table is defined */
		        if (IS_NULLFLD(posPtr, ExtPos_Rate) == FALSE &&
                    (INTERCD_ENUM)GET_ENUM(instrPtr, A_Instr_InterestCdEn) == InterCd_Instr)
		        {
                    /* REF7251 - YST - 020501 */
			        if ((SUBNAT_ENUM)GET_ENUM(instrPtr, A_Instr_SubNatEn) == SubNat_AvrgRate ||
                        IS_NULLFLD(instrPtr, A_Instr_FloatInstrId) != TRUE)
			        {
			            SET_PERCENT(instrPtr, A_Instr_AddMarginP, GET_PERCENT(posPtr, ExtPos_Rate)); 
			        }
			        else
			        {
	                    SET_PERCENT(instrPtr, A_Instr_InterestRateP, GET_PERCENT(posPtr, ExtPos_Rate)); 
 		                /* SET_ENUM(instrPtr, A_Instr_InterestCdEn, (ENUM_T) InterCd_Instr); */ /* REF7251 - YST - 020501 */
                    }
		        }

                AMOUNT_T   unitAccrInter = ZERO_AMOUNT;

                if (0. != GET_NUMBER(posPtr, ExtPos_Qty))   /* Avoid division by 0 PMSTA-25190 - 061116 - PMO */
                {
		            unitAccrInter = GET_AMOUNT(posPtr, ExtPos_AccrAmt) / GET_NUMBER(posPtr, ExtPos_Qty);
                }

		        SET_NUMBER(instrPtr,  A_Instr_UnitAccrInter, CAST_NUMBER(unitAccrInter)); /* REF3288 - SSO - 990205 */

	    	    /* New end date */
		        if (IS_NULLFLD(posPtr, ExtPos_ExpirDate) == TRUE)
		        {
	    		    SET_DATE(instrPtr, A_Instr_EndDate, MAGIC_END_DATE);	/* BUG208 */
		        }
		        else
		        {     
	    		    tmpDate = GET_DATETIME(posPtr, ExtPos_ExpirDate);
	    		    SET_DATE(instrPtr, A_Instr_EndDate, tmpDate.date);
		        }

		        /* REF1210 - Update instrument begin date only for generic money market */
	    	    if (IS_NULLFLD(posPtr, ExtPos_ValDate) == TRUE)
			        tmpDate = GET_DATETIME(posPtr, ExtPos_BegDate);
	    	    else
			        tmpDate = GET_DATETIME(posPtr, ExtPos_ValDate);

	    	    SET_DATE(instrPtr, A_Instr_BeginDate, tmpDate.date);
		    }
		    /* REF1210 - Ensure that non-generic money market have begin date */
		    else if (IS_NULLFLD(instrPtr, A_Instr_BeginDate) == TRUE)	
		    {
	    	    if (IS_NULLFLD(posPtr, ExtPos_ValDate) == TRUE)
			        tmpDate = GET_DATETIME(posPtr, ExtPos_BegDate);
	    	    else
			        tmpDate = GET_DATETIME(posPtr, ExtPos_ValDate);

	    	    SET_DATE(instrPtr, A_Instr_BeginDate, tmpDate.date);
		    }
	    }
	}

	SET_ID(accrInterPtr,       UnitInter_InstrId,       GET_ID(instrPtr, A_Instr_Id));
	SET_ID(accrInterPtr,       UnitInter_CurrId,        GET_ID(instrPtr, A_Instr_RefCurrId));
	SET_DATETIME(accrInterPtr, UnitInter_ValidDate,     refDateTime);
	SET_FLAG(accrInterPtr,     UnitInter_ExCouponFlg,   TRUE);                      /* ?? */
	SET_FLAG(accrInterPtr,     UnitInter_CalcFlg,       (FLAG_T) calcAccrInterFlg); /*REF661*/
	SET_FLAG(accrInterPtr,     UnitInter_FullCoupFlg,   (FLAG_T) fullCoupFlg);      /*REF661*/
	SET_ENUM(accrInterPtr,     UnitInter_FusDateRuleEn, (ENUM_T) fusDateRule);      /*REF661*/

	if (instrNat == InstrNat_CashAcct || is_MM_or_FI_FundShareFlg == TRUE  /* PMSTA01512-CHU-070503 : Do not Optimize */
		|| (instrNat == InstrNat_Stock && applIncludeDivAccrualPos == AppIncDivAccrualPos::includeInStockPos))
	{ 	SET_FLAG(accrInterPtr, UnitInter_UnitFlg, FALSE); }
	else
	{ 	SET_FLAG(accrInterPtr, UnitInter_UnitFlg, TRUE); }

	/*** SEARCH A CALCULATED ACCRUED INTEREST IN MEMORY ***/		/* REF661 */
	if (GET_FLAG(accrInterPtr, UnitInter_UnitFlg) == TRUE)	/* BUG143 */
	{
	    if ((getUnitInter = ALLOC_DYNST(UnitInter)) == NULL)
	    {
		    /* PMSTA-10443 - RAK - 101022 */
	        if (allocOk == TRUE) 
			{FREE_DYNST(instrPtr, A_Instr);}
			else 
			{FIN_ResetSceActActRule(instrPtr, updateAccrRuleFlg);}
		    MSG_RETURN(RET_MEM_ERR_ALLOC);
	    }

	    SET_ID(getUnitInter,       UnitInter_InstrId,     GET_ID(instrPtr, A_Instr_Id));
	    SET_DATETIME(getUnitInter, UnitInter_ValidDate,   refDateTime);
	    SET_FLAG(getUnitInter,     UnitInter_ExCouponFlg, TRUE);                      /* ?? */
	    SET_FLAG(getUnitInter,     UnitInter_CalcFlg,     (FLAG_T) calcAccrInterFlg); /*REF661*/
	    SET_FLAG(getUnitInter,     UnitInter_FullCoupFlg, (FLAG_T) fullCoupFlg);      /*REF661*/
	    SET_ENUM(getUnitInter,     UnitInter_FusDateRuleEn, (ENUM_T) fusDateRule);    /*REF661*/
        /* REF5757 - RAK - 010308 */
        /* Compute compound and simple accrued interest on same instrument */
        SET_ENUM(getUnitInter,     UnitInter_InterCalcRuleEn, GET_ENUM(instrPtr, A_Instr_InterestRateConvEn));
	    
        /* REF1252 - Set begin date for money market. */
	    if (instrNat == InstrNat_Discount || instrNat == InstrNat_MoneyMkt)
	    {
		    DATETIME_T tmpDate;
		    tmpDate.time = 0;
		    tmpDate.date = GET_DATE(instrPtr, A_Instr_BeginDate);
		    SET_DATETIME(getUnitInter, UnitInter_BegDate, tmpDate);
	    }

		/* REF11218 - TEB - 050627 */
		if (accrRule != AccrRule_None)
		{
			SET_ENUM(getUnitInter, UnitInter_AccrRuleEn, (ENUM_T)accrRule );
		}

		/* PMSTA06529-CHU-080508 : no optimization for generic instrument during fusion, recompute everytime */
		if (GET_ID(instrPtr, A_Instr_Id) < 0 || GET_FLAG(instrPtr, A_Instr_GenericFlg)==FALSE)
		{
			if (DBA_GetMemory(OptiFct, UNUSED, UnitInter, getUnitInter, UnitInter, 
							 accrInterPtr, NULL, Opti_Local) == RET_SUCCEED)
			{
				/* PMSTA-10443 - RAK - 101022 */
				if (allocOk == TRUE) 
				{FREE_DYNST(instrPtr, A_Instr);}
				else 
				{FIN_ResetSceActActRule(instrPtr, updateAccrRuleFlg);}
				FREE_DYNST(getUnitInter, UnitInter); /* REF11218 - TEB - 050627 */
				return(RET_SUCCEED);              /* found and end */
			}
		}

	    /* FREE_DYNST(getUnitInter, UnitInter); */ /* REF11218 - TEB - 050627 - Optimisation non optimisee */
	}

    /* REF7265 - YST - 020321 *//* REF9085 - YST - 030703 - delete again */
	/* REF9451 - CHU - 031113 - Restore again ;-)) */
    accrPeriod.accrInterMethod = accrInterMethod;
    if (accrInterMethod == AccrInterMethod_AccrVal)
        /* accrPeriod.accrValFromDate = accrValFromDate.date; */
		accrPeriod.fromDate = accrValFromDate.date;

	/*** SEARCH STORED ACCRUED INTEREST IF NOT FORCED CALCULATION ***/
	if (calcAccrInterFlg == FALSE)
	{
	    ACCRINTERCHRONO_ENUM accrInterChronoEn;
	    GEN_GetApplInfo(ApplAccrInterChrono, &accrInterChronoEn);

	    /* Read chrono in case of AI are stored in chrono for all  */
	    /* instr or only for cash and current instrument is a cash */
	    if (accrInterChronoEn != AccrInterChrono_NeverStored &&
		    ((accrInterChronoEn == AccrInterChrono_FoundCashAcc &&
	          instrNat == InstrNat_CashAcct) || 
		      accrInterChronoEn == AccrInterChrono_FoundAllInst))
	    {
		    if ((instrChrono = ALLOC_DYNST(A_InstrChrono)) == NULL)
			{
				/* PMSTA-10443 - RAK - 101022 */
				if (allocOk == TRUE) 
				{FREE_DYNST(instrPtr, A_Instr);}
				else 
				{FIN_ResetSceActActRule(instrPtr, updateAccrRuleFlg);}
			    MSG_RETURN(RET_MEM_ERR_ALLOC);
			}

	        if (GET_ID(instrPtr, A_Instr_Id) < 0)
			    getInstrId = GET_ID(instrPtr, A_Instr_ParentInstrId);
	        else
			    getInstrId = GET_ID(instrPtr, A_Instr_Id);

		    if ((dimChronoPtr = ALLOC_DYNST(Dim_InstrChrono)) == NULL)
		    {
			    FREE_DYNST(instrChrono, A_InstrChrono);
				/* PMSTA-10443 - RAK - 101022 */
				if (allocOk == TRUE) 
				{FREE_DYNST(instrPtr, A_Instr);}
				else 
				{FIN_ResetSceActActRule(instrPtr, updateAccrRuleFlg);}
			    MSG_RETURN(RET_MEM_ERR_ALLOC);
		    }

		    SET_ID(dimChronoPtr,       Dim_InstrChrono_InstrId,     getInstrId);
		    SET_DATETIME(dimChronoPtr, Dim_InstrChrono_RefDate,     refDateTime);
        if (GET_FLAG(inputInstrPtr, A_Instr_BoForcedAiFlg) == TRUE && (boForceAiDate = GET_DATE(inputInstrPtr, A_Instr_BoAccruedIntRuleDate)) !=0
            && DATE_Cmp(boForceAiDate, refDateTime.date)<=0)/*PMSTA-42064-ARUN-13102020*/
        {
            BoForceChrono = true;
            SET_ENUM(dimChronoPtr, Dim_InstrChrono_NatEn, ChronoNat_BOForcedAI);
        }
        else
        {
            SET_ENUM(dimChronoPtr, Dim_InstrChrono_NatEn, ChronoNat_AccrInter);
        }

		    SET_FLAG(dimChronoPtr,     Dim_InstrChrono_ComputeFlg,  FALSE);
		    SET_FLAG(dimChronoPtr,     Dim_InstrChrono_SubNatFlg,   FALSE); /* PMSTA12914 - DDV - 111010 - Set it to FALSE to avoid unmatching of input args in optimisation */
		    
		    ret = FIN_InstrChrono(dimChronoPtr, instrPtr, instrChrono, hierHead);
		    FREE_DYNST(dimChronoPtr, Dim_InstrChrono);

		    if (ret == RET_SUCCEED)
		    {
			    DATE_PERIOD_ST interPeriod;

			    SET_NUMBER(accrInterPtr, UnitInter_UnitAccrInter,
			        GET_LONGAMOUNT(instrChrono, A_InstrChrono_Val)); /* REF11704 - TGU - 060419 - Change datatype */

			    SET_ID(accrInterPtr, UnitInter_CurrId,
			        GET_ID(instrChrono, A_InstrChrono_CurrId));

			    /* BUG143 - RAK - 960930 */ /* REF7265 - YST - 020315 - add hierHead */
			    if ((ret = FIN_GetBegAccrPeriod(refDateTime, fusDateRule, fullCoupFlg, 
				                                instrPtr, posPtr, &accrPeriod, hierHead, NULL)) != RET_SUCCEED) /* PMSTA08308 - 090609 - PMO */
			    {
			        FREE_DYNST(instrChrono, A_InstrChrono);
			        /* PMSTA-10443 - RAK - 101022 */
					if (allocOk == TRUE) 
					{FREE_DYNST(instrPtr, A_Instr);}
					else 
					{FIN_ResetSceActActRule(instrPtr, updateAccrRuleFlg);}
					/* REF11218 - TEB - 050627 */
					if (GET_FLAG(accrInterPtr, UnitInter_UnitFlg) == TRUE)
					{
						FREE_DYNST(getUnitInter, UnitInter);
					}
			        return(ret);  
			    }

			    /* Days number in this period */
			    /* REF3410 - SSO - 990315: moved after FIN_GetBegAccrPeriod (accrPeriod.accrRule not needed for it) */
				/* REF11218 - TEB - 050627 : use Script (ACCR_INTER) accrual rule if inputed (!= AccrRule_None) */
				if (accrRule == AccrRule_None)
				{
					if ((ret = FIN_GetInstrAccrRule(accrPeriod.fromDate, instrPtr, hierHead, 
													&accrPeriod.accrRule)) != RET_SUCCEED)
					{
						FREE_DYNST(instrChrono, A_InstrChrono);
						/* PMSTA-10443 - RAK - 101022 */
						if (allocOk == TRUE) 
						{FREE_DYNST(instrPtr, A_Instr);}
						else 
						{FIN_ResetSceActActRule(instrPtr, updateAccrRuleFlg);}
						/* REF11218 - TEB - 050627 */
						if (GET_FLAG(accrInterPtr, UnitInter_UnitFlg) == TRUE)
						{
							FREE_DYNST(getUnitInter, UnitInter);
						}
						return(ret);  
					}
				}
				else
				{
					accrPeriod.accrRule = accrRule;
				}

				/* PMSTA-22396  - SRIDHARA � 160430 */
				DBA_GetCalendarFromInstr(instrPtr, &calendarId);
			    DATE_AccrPeriod(accrPeriod.fromDate, refDateTime.date, 
					            accrPeriod.accrRule, accrPeriod.payFreq, &interPeriod, calendarId);

			    SET_INT(accrInterPtr, UnitInter_NumPeriod,   interPeriod.num);
			    SET_INT(accrInterPtr, UnitInter_DenomPeriod, interPeriod.denom);

			    /* Save founded unitary accrued interest in memory */
			    if (GET_FLAG(accrInterPtr, UnitInter_UnitFlg) == TRUE)
			    {
			        /* REF1252 - Set begin date for money market. */
			        if (instrNat == InstrNat_Discount || instrNat == InstrNat_MoneyMkt)
			        {
				        DATETIME_T tmpDate;
				        tmpDate.time = 0;
				        tmpDate.date = GET_DATE(instrPtr, A_Instr_BeginDate);
				        SET_DATETIME(accrInterPtr, UnitInter_BegDate, tmpDate);
			        }
			        else
			        {
				        SET_NULL_DATETIME(accrInterPtr, UnitInter_BegDate);
			        }

					/* REF11218 - TEB - 050627 */
					if (accrRule != AccrRule_None)
					{
						SET_ENUM(accrInterPtr, UnitInter_AccrRuleEn, (ENUM_T)accrRule );
					}

					/* PMSTA06529-CHU-080508 : no optimization for generic instrument during fusion, recompute everytime */
					if (GET_ID(instrPtr, A_Instr_Id) < 0 || GET_FLAG(instrPtr, A_Instr_GenericFlg)==FALSE)
					{
						ret = DBA_SetMemory(OptiFct, UNUSED, UnitInter, /*accrInterPtr*/ getUnitInter, /* REF11218 - TEB - 050627 - Optimisation non optimisee */
											UnitInter, accrInterPtr, Opti_Local);
					}

					FREE_DYNST(getUnitInter, UnitInter); /* REF11218 - TEB - 050627 */
			    }

			    FREE_DYNST(instrChrono, A_InstrChrono);
			    /* PMSTA-10443 - RAK - 101022 */
				if (allocOk == TRUE) 
				{FREE_DYNST(instrPtr, A_Instr);}
				else 
				{FIN_ResetSceActActRule(instrPtr, updateAccrRuleFlg);}
				/* REF11218 - TEB - 050627 */
				if (GET_FLAG(accrInterPtr, UnitInter_UnitFlg) == TRUE)
				{
					FREE_DYNST(getUnitInter, UnitInter);
				}
			    return(RET_SUCCEED);                /* found and end */
		    }
        else if (BoForceChrono == true) /*PMSTA-42064-ARUN-13102020*/
        {
            return(RET_SUCCEED);
        }

		    FREE_DYNST(instrChrono, A_InstrChrono);
	    }
	}

	/* REF661 - Move Search accrued interest in memory before calcAccrInterFlg test */
	/**** COMPUTE ACCRUED INTEREST ****/
	/**** Search when interest has been accrueing ****/
    /* REF7265 - YST - 020315 - add hierHead */

	/* Developer Information Not Obsolete Serious And Useful Recommendation � DINOSAUR � KRA � 110831 */
	/* An important thing to know : date from which coupons are accrued. */
	if ((ret = FIN_GetBegAccrPeriod(refDateTime, fusDateRule, fullCoupFlg, instrPtr, posPtr, 
			                        &accrPeriod, hierHead, aiArgStp)) != RET_SUCCEED)
	{
	    /* PMSTA-10443 - RAK - 101022 */
        if (allocOk == TRUE) 
		{FREE_DYNST(instrPtr, A_Instr);}
		else 
		{FIN_ResetSceActActRule(instrPtr, updateAccrRuleFlg);}
		/* REF11218 - TEB - 050627 */
		if (GET_FLAG(accrInterPtr, UnitInter_UnitFlg) == TRUE)
		{
			FREE_DYNST(getUnitInter, UnitInter);
		}
	    return(ret);
	}

	/* REF3410 - SSO - 990315: moved after FIN_GetBegAccrPeriod (accrPeriod.accrRule not needed for it) */
	/* REF11218 - TEB - 050627 : use Script (ACCR_INTER) accrual rule if inputed (!= AccrRule_None) */
	if (accrRule == AccrRule_None)
	{
		if ((ret = FIN_GetInstrAccrRule(accrPeriod.fromDate, instrPtr, hierHead, /* REF3410 - SSO - 990315 */
										&accrPeriod.accrRule)) != RET_SUCCEED)
		{
			/* PMSTA-10443 - RAK - 101022 */
	        if (allocOk == TRUE) 
			{FREE_DYNST(instrPtr, A_Instr);}
			else 
			{FIN_ResetSceActActRule(instrPtr, updateAccrRuleFlg);}
			/* REF11218 - TEB - 050627 */
			if (GET_FLAG(accrInterPtr, UnitInter_UnitFlg) == TRUE)
			{
				FREE_DYNST(getUnitInter, UnitInter);
			}
			return(ret);
		}
	}
	else
	{
		accrPeriod.accrRule = accrRule;
	}

	/* PMSTA02367-CHU-070618 - Price Calculation Rule should also be retrieved for SimCorp - code moved here */
    /* search instrChronoVal generic variable used for unpaid percentage or price calc. factor */
	priceCalc = (PRICECALCRULE_ENUM) GET_ENUM(instrPtr, A_Instr_PriceCalcRuleEn);

    switch(priceCalc)
    {
    case PriceCalcRule_PartiallyPaidStocks :
    case PriceCalcRule_PartiallyPaidBonds :
    /* REF7280 - YST - 020404 - new treatement to compute instrChronoVal */
    case PriceCalcRule_PriceCalculationFactor :	

        /*chronoDate.date = accrPeriod.fromDate;*/  /* REF5922 - AKO - 010704 */
        chronoDate.date = refDateTime.date;

        chronoDate.time = 0;

		if ((instrChrono = ALLOC_DYNST(A_InstrChrono)) == NULLDYNST)
		{
			/* PMSTA-10443 - RAK - 101022 */
	        if (allocOk == TRUE) 
			{FREE_DYNST(instrPtr, A_Instr);}
			else 
			{FIN_ResetSceActActRule(instrPtr, updateAccrRuleFlg);}
			MSG_RETURN(RET_MEM_ERR_ALLOC);
		}

	    if (GET_ID(instrPtr, A_Instr_Id) < 0)
			instrId = GET_ID(instrPtr, A_Instr_ParentInstrId);
	    else
			instrId = GET_ID(instrPtr, A_Instr_Id);

		if ((dimChronoPtr = ALLOC_DYNST(Dim_InstrChrono)) == NULLDYNST)
		{
			/* PMSTA-10443 - RAK - 101022 */
	        if (allocOk == TRUE) 
			{FREE_DYNST(instrPtr, A_Instr);}
			else 
			{FIN_ResetSceActActRule(instrPtr, updateAccrRuleFlg);}

			FREE_DYNST(instrChrono, A_InstrChrono);
			MSG_RETURN(RET_MEM_ERR_ALLOC);
		}
    
		SET_ID(dimChronoPtr,       Dim_InstrChrono_InstrId,     instrId);
        SET_FLAG(dimChronoPtr,     Dim_InstrChrono_ComputeFlg,  FALSE);
        /* REF7280 - YST - 020409 */
        switch(priceCalc)
        {
        case PriceCalcRule_PartiallyPaidStocks :
        case PriceCalcRule_PartiallyPaidBonds :
           SET_ENUM(dimChronoPtr, Dim_InstrChrono_NatEn,  ChronoNat_UnpPrct);
        break;
        case PriceCalcRule_PriceCalculationFactor :	
            SET_ENUM(dimChronoPtr, Dim_InstrChrono_NatEn, ChronoNat_PriceCalculationFactor);
        break;
        }

        /* REF4637 - RAK - 000502 */
        /* chronoDate (begin of the accrued period) instead of refDate */
		SET_DATETIME(dimChronoPtr, Dim_InstrChrono_RefDate,     chronoDate);

		ret = FIN_InstrChrono(dimChronoPtr, instrPtr, instrChrono, hierHead);

		FREE_DYNST(dimChronoPtr, Dim_InstrChrono);
	
        /* REF7280 - YST - 020403 - instrChronoVal is a generic name, used for unpaid percentage or price calculation factor */
		if (ret != RET_SUCCEED)
		{
			instrChronoVal = 0.0; 
			/* In log file, missing chrono is signaled */
		}
		else  
		{	 
			instrChronoVal = GET_NUMBER(instrChrono, A_InstrChrono_Val);
		}
		FREE_DYNST(instrChrono, A_InstrChrono);
	break;

    default :
		instrChronoVal = 0.0;
	break;
    }

    /* PMSTA-36699  - Silpakal - 191121  */
    if (instrNat != InstrNat_CashAcct)
    {
        /* Fetch the benchmark details from interest rate condition table instead of instrument table */
        inputData = mp.allocDynst(FILEINFO, A_InterCond);

        if (GET_ID(instrPtr, A_Instr_Id) < 0)
        {
            SET_ID(inputData, A_InterCond_InstrId, GET_ID(instrPtr, A_Instr_ParentInstrId));
        }
        else
        {
            SET_ID(inputData, A_InterCond_InstrId, GET_ID(instrPtr, A_Instr_Id));
        }

        SET_DATE(inputData, A_InterCond_BeginDate, accrPeriod.fromDate);
        SET_DATE(inputData, A_InterCond_EndDate, refDateTime.date);
        SET_ENUM(inputData, A_InterCond_NatEn, InterCondNat_None);

        /* Special treatment for Fund Shares */
        if (instrPtr != NULLDYNST &&
            (INSTRNAT_ENUM)GET_ENUM(instrPtr, A_Instr_NatEn) == InstrNat_FundShare &&
            ((SUBNAT_ENUM)GET_ENUM(instrPtr, A_Instr_SubNatEn) == SubNat_MoneyMarketFundShare ||
            (SUBNAT_ENUM)GET_ENUM(instrPtr, A_Instr_SubNatEn) == SubNat_FixedIncomeFundShare))
        {
            SET_DATE(inputData, A_InterCond_ValidDate, accrPeriod.fromDate);
        }

        if ((ret = DBA_SelAllInterCond(InterCond_ByIdDt, hierHead, instrPtr, inputData,
                                       &selInterTab, &selInterNbr, &interCondRecFlg)) != RET_SUCCEED)
        {
            ret = RET_DBA_ERR_NODATA;
            MSG_SendMesg(ret, 3, FILEINFO, "DBA_SelectInterCond", GET_CODE(instrPtr, A_Instr_Cd), "interest condition");
            return ret;
        }

        if (selInterNbr > 0)
            instrCondCalcRuleEn = (INTERCALCRULE_ENUM)GET_ENUM(selInterTab[0], A_InterCond_IntCalcRuleEn);
       // DBA_FreeDynStTab(selInterTab, selInterNbr, A_InterCond);
    }

    /* REF9085 - TEB - 030520 */
    /* If new accrual rule for simcorp, except for cash account */

	/* Developer Information Not Obsolete Serious And Useful Recommendation � DINOSAUR � KRA � 110831 */
	/* I know the call to the SceCon libraries is really well hidden. */
	/* PMSTA-35434 - RAK - 190408 - For InterestCalculationRule don't compute with simCorp as there is specific treatment (but use simcorp for denominator computation) */
    /* PMSTA-36699  - Silpakal - 191121 */
    if (SCE_CheckAccrRule(accrPeriod.accrRule) == TRUE &&
        instrNat != InstrNat_CashAcct && 
        ((instrCondCalcRuleEn == InterCalcRule_Fixed) ||
        (instrCondCalcRuleEn == InterCalcRule_GrossRate) ||
         (instrCondCalcRuleEn == InterCalcRule_Floating && 
                (instrSubNat != SubNat_CapProtectNotesWCoupon && instrSubNat != SubNat_ReverseConvNotesEquity &&                
                instrSubNat != SubNat_ReverseConvNotesBonds && instrSubNat != SubNat_ReverseConvNotesCredit &&
                instrSubNat != SubNat_MemoryCouponNotes && instrSubNat != SubNat_EquityLinkedNotes &&
                instrSubNat != SubNat_BondsLinkedNotes && instrSubNat != SubNat_CreditLinkedNotes)
            )))
    {
        /*PMSTA-45658 - Kramadevi - 05082021*/
        FLAG_T mktConvMethodEnblFlg = FALSE;
        if(selInterNbr > 0 &&
            static_cast<InstrMktConvMethodEn>GET_ENUM(selInterTab[0], A_InterCond_MktConvMethodEn) != InstrMktConvMethodEn::None)
        {
            mktConvMethodEnblFlg = TRUE;
        }

        /*PMSTA-43096 - Kramadevi - 10032021 : Libor Transition changes*/
        DBA_FreeDynStTab(selInterTab, selInterNbr, A_InterCond);

        /* Test the nature and subnature of instrument */
	    if ( (instrNat == InstrNat_Bond     && instrSubNat != SubNat_FRN ) ||
             (instrNat == InstrNat_MoneyMkt && instrSubNat != SubNat_FRN ) ||
             instrNat == InstrNat_ConvertBond ||
             instrNat == InstrNat_Option ||
             instrNat == InstrNat_MortBackSecu ||
			 instrNat == InstrNat_CumOption ||      /* PMSTA12795 - PRS - 110921 */
            (mktConvMethodEnblFlg == TRUE && ((instrNat == InstrNat_Bond || instrNat == InstrNat_MoneyMkt) &&
            instrSubNat == SubNat_FRN)))/*PMSTA-45658 - Kramadevi - 05082021*/
        {
            /* We have got a bond :-) */
			DATETIME_T	fromDate;
			fromDate.time = 0;
			fromDate.date = accrPeriod.fromDate;

            if ( (ret = SCE_CallBond_Accruint(instrId,
                                              instrPtr,
                                              hierHead,
											  fromDate,
                                              refDateTime,
                                              accrInterPtr,
                                              fusDateRule,
											  accrRule, /* REF11218 - TEB - 050606 */
											  &instrChronoVal)) != RET_SUCCEED) /* PMSTA02367-CHU-070618 */
            {
                MSG_SendMesg(RET_FIN_ERR_SCE_FCT_FAIL, 1, FILEINFO,"FIN_UnitAccrInter", /* REF10332 - TEB - 040601 */
                             GET_CODE(instrPtr, A_Instr_Cd),"Scecon SCE_CallBond_Accruint failed");
            }

        }
        else if ((instrNat == InstrNat_Bond || instrNat == InstrNat_MoneyMkt) && 
                  instrSubNat == SubNat_FRN)
        {
            /* We have got a FRN :-) */
            if ( (ret = SCE_CallFRN_Accruint(instrId,
                                             instrPtr,
                                             hierHead,
                                             refDateTime,
                                             accrInterPtr,
                                             fusDateRule,
											 accrRule)) != RET_SUCCEED) /* REF11218 - TEB - 050627 */
            {
                MSG_SendMesg(RET_FIN_ERR_SCE_FCT_FAIL, 1, FILEINFO,"FIN_UnitAccrInter", /* REF10332 - TEB - 040601 */
                             GET_CODE(instrPtr, A_Instr_Cd),"Scecon SCE_CallFRN_Accruint failed");
            }

        }
        else
        {
            MSG_SendMesg(RET_FIN_ERR_SCE_FCT_FAIL, 1, FILEINFO,"FIN_UnitAccrInter",
                         GET_CODE(instrPtr, A_Instr_Cd),"No accrued interest possible for this instrument nature");
        }
    }
    else
    {
        /*PMSTA-43096 - Kramadevi - 10032021 : Libor Transition changes*/
        DBA_FreeDynStTab(selInterTab, selInterNbr, A_InterCond);

        /* REF9085 - TEB - 030520 */
        /* Else use old method */


	    /* full coupon flag is forced to 0.      */
	    if (refDateTime.date == accrPeriod.exDate)
		    fullCoupFlg = FALSE;

	    /* If from date is equal to the till date and payment day full */
	    /* coupon flag is equal to 0, accrued interest is equal to 0.  */
	    /* REF1284 - Compute 1 day accrued interest at coupon payment  */
	    /*           date for method AccrRule_30_360_1 (BTP).          */
	    if (accrPeriod.accrRule ==  AccrRule_30_360_1)	/* REF1477 */
		    refDateTime.date = DATE_Move(refDateTime.date, 1, Day);

	    if (fullCoupFlg == FALSE && accrPeriod.fromDate == refDateTime.date
		    /* REF3693 - SSO - 990517 if avrg rate, interest active 1st day even if no full coupon,
		       because interest is computed with day before rate */
		    && instrSubNat != SubNat_AvrgRate
			&& is_MM_or_FI_FundShareFlg == FALSE)
	    {
		    /* PMSTA-10443 - RAK - 101022 */
	        if (allocOk == TRUE) 
			{FREE_DYNST(instrPtr, A_Instr);}
			else 
			{FIN_ResetSceActActRule(instrPtr, updateAccrRuleFlg);}

			/* REF11218 - TEB - 050627 */
			if (GET_FLAG(accrInterPtr, UnitInter_UnitFlg) == TRUE)
			{
				FREE_DYNST(getUnitInter, UnitInter);
			}

			/* PMSTA01815-CHU-070723 : reset AI value if structure already initialized */
			if (accrInterPtr != NULL)
				SET_NULL_NUMBER(accrInterPtr, UnitInter_UnitAccrInter);

		    return(RET_SUCCEED);
	    }		

	    /**** SEARCH INTEREST RATE(S) APPLICABLE OVER THE PERIOD ****/
	    /* DVP286 - RAK - 961216 */
	    foundIR = FALSE;
	    if (instrNat == InstrNat_CashAcct)
	    {
	        if (posPtr != NULL && IS_NULLFLD(posPtr, ExtPos_Rate) == FALSE)
	        {
		        foundIR = TRUE;
		        if ((interRate.infoPtr = (FIN_RATE_INFO_STP) 
			                 CALLOC(1,sizeof(FIN_RATE_INFO_ST))) == (FIN_RATE_INFO_STP)NULL)
		        {
			        /* PMSTA-10443 - RAK - 101022 */
					if (allocOk == TRUE) 
					{FREE_DYNST(instrPtr, A_Instr);}
					else 
					{FIN_ResetSceActActRule(instrPtr, updateAccrRuleFlg);}

			        MSG_RETURN(RET_MEM_ERR_ALLOC);
		        }
		        else
		        {
			        DATETIME_T tmpDate;

			        interRate.interRateNbr        = 1;
			        interRate.interCalcRuleEn     = InterCalcRule_Fixed;
			        interRate.infoPtr[0].posRate  = GET_PERCENT(posPtr, ExtPos_Rate);
			        interRate.infoPtr[0].negRate  = GET_PERCENT(posPtr, ExtPos_Rate);

			        /* BUG146 */
			        if (IS_NULLFLD(instrPtr, A_Instr_DatedDate) == FALSE)
			        { tmpDate = GET_DATETIME(instrPtr, A_Instr_DatedDate); }
			        else
			        { tmpDate.date = GET_DATE(instrPtr, A_Instr_BeginDate); }

			        interRate.infoPtr[0].fromDate = tmpDate.date;

			        if (IS_NULLFLD(instrPtr, A_Instr_EndDate) == FALSE &&
			            GET_DATE(instrPtr, A_Instr_EndDate) != MAGIC_END_DATE)	/*BUG208*/
				        interRate.infoPtr[0].tillDate = GET_DATE(instrPtr, A_Instr_EndDate);
			        else
				        interRate.infoPtr[0].tillDate = refDateTime.date;
		        }
	        }
	    }

	    /* Read interest rate condition */
	    if (foundIR == FALSE)
	    {
            /* REF7265 - YST - 020315 - set nature of interest rate condition */
	        if ((ret = FIN_SearchInterRate(accrPeriod.fromDate, refDateTime.date, accrPeriod.payFreq, accrPeriod.accrRule, 
					       instrPtr, &interRate, hierHead, (INTERCONDNAT_ENUM)GET_ENUM(instrPtr, A_Instr_InterCondNatEn), 
						   TRUE, /* PMSTA05878 - RAK - 080424 */ NULL)) != RET_SUCCEED)
	        {
		        /* PMSTA-10443 - RAK - 101022 */
				if (allocOk == TRUE) 
				{FREE_DYNST(instrPtr, A_Instr);}
				else 
				{FIN_ResetSceActActRule(instrPtr, updateAccrRuleFlg);}

		        FREE(interRate.infoPtr);	/* REF3542 - AKO - 990409 */
				/* REF11218 - TEB - 050627 */
				if (GET_FLAG(accrInterPtr, UnitInter_UnitFlg) == TRUE)
				{
					FREE_DYNST(getUnitInter, UnitInter);
				}
		        return(ret); 
	        }
	    }

        /* REF7265 - YST - 020506 - if method accrued valuation is used, check date from which interests accrues */
        /* REF9085 - YST - 030703 - delete again */
		/* REF9451 - CHU - 031113 - Restore again ;-)) */
        if (accrPeriod.accrInterMethod == AccrInterMethod_AccrVal &&
            /* DATE_Cmp(accrPeriod.fromDate, accrPeriod.accrValFromDate) < 0) */
			DATE_Cmp(accrPeriod.fromDate, accrValFromDate.date) < 0)
        /* {accrPeriod.fromDate = accrPeriod.accrValFromDate;} */
		{
			accrPeriod.fromDate = accrValFromDate.date;
		}

	    /* DVP125 - RAK - 960620 */
	    /* Suppress SearchQuantity() for cash, quantity variation is stored in positions */
	    if ((quant.infoPtr = (FIN_QUANT_INFO_STP) 
		                 CALLOC(1, sizeof(FIN_QUANT_INFO_ST)))==(FIN_QUANT_INFO_STP)NULL)
	    {
	        FREE(interRate.infoPtr);
	        /* PMSTA-10443 - RAK - 101022 */
	        if (allocOk == TRUE) 
			{FREE_DYNST(instrPtr, A_Instr);}
			else 
			{FIN_ResetSceActActRule(instrPtr, updateAccrRuleFlg);}
   	        MSG_RETURN(RET_MEM_ERR_ALLOC);
	    }

	    quant.quantNbr = 1;

	    quant.infoPtr[0].fromDate = accrPeriod.fromDate;
	    quant.infoPtr[0].tillDate = refDateTime.date;

	    /* BUG482 - RAK - 970901 */
	    /* For cash : negative quantity in position -> use "negativ rate" */
	    /* quant.infoPtr[0].quant = 1.0; */
	    if (instrNat == InstrNat_CashAcct && 
	        posPtr != NULL && CMP_NUMBER(GET_NUMBER(posPtr, ExtPos_Qty), 0.0) < 0)		/* REF4012 - 000310 - DED */
		    quant.infoPtr[0].quant = -1.0; 
		else
		    quant.infoPtr[0].quant = 1.0;

	    SET_ENUM(accrInterPtr, UnitInter_InterCalcRuleEn, (ENUM_T) interRate.interCalcRuleEn);

		/* PMSTA02642-CHU-070725 - Special case if first coupon date is set */
		/* PMSTA-34978 - RAK - 190308 - To be sure that it won't corrupt the new AI computation */
		if (firstCoupDate > (DATE_T)0 && 
			(instrPtr != nullptr && GET_ENUM(instrPtr, A_Instr_InterestCalculationRuleEn) == (ENUM_T)InstrInterestCalcRule_None))
		{
			DATE_T tmpTillDate = DATE_Move(firstCoupDate, ((accrPeriod.payFreq)*-1), Month);
			DBA_DYNFLD_STP longCoupAccrInterPtr = NULL;

			/*
			Begin date Instrument	: interFromDate
			1st coupon date - freq	: tmpTillDate
			1st coupon date			: firstCoupDate
			Date de valorisation	: refDateTime.date
			*/
			if (DATE_Cmp(accrPeriod.fromDate, tmpTillDate) < 0   &&     /* long coupon : instr begdate < (1stCoupDate - 1Year) ? */
				DATE_Cmp(refDateTime.date, firstCoupDate) < 0    &&     /* valuation before 1stCoupDate */
				DATE_Cmp(refDateTime.date, accrPeriod.fromDate) >= 0 && /* valuation after or equal to instr begdate */
				DATE_Cmp(tmpTillDate, refDateTime.date) <=0)			/* PMSTA-8911 - RAK - 091109 */
			{
				if ((longCoupAccrInterPtr = ALLOC_DYNST(UnitInter)) == NULL)
				{
					/* PMSTA-10443 - RAK - 101022 */
					if (allocOk == TRUE) 
					{FREE_DYNST(instrPtr, A_Instr);}
					else 
					{FIN_ResetSceActActRule(instrPtr, updateAccrRuleFlg);}
					MSG_RETURN(RET_MEM_ERR_ALLOC);
				}

				/* Above conditions may be presented as follows
				  ***|****************|*********|****************|************|*******
				     ^                ^         ^                ^            ^
				    instr        *Valuation*  1stCoup        Valuation      1stCoup
					begDate	       *here*     - 1Year         or here
				*
				* In this case, we need to split this period in two parts :
				* 1. InstrBegDate -> 1stCoup -1Year
				* 2. 1stCoup -1 Year -> 1stCoup
				*/
				quant.infoPtr[0].tillDate = tmpTillDate;
				if (FIN_CalcUnitAccrInter(&accrPeriod, &interRate, &quant, &instrChronoVal, 
										  accrPeriod.fromDate, tmpTillDate, longCoupAccrInterPtr,
										  instrPtr, hierHead,
										  posPtr, NULL) == FALSE)
				{
						/* REF11218 - TEB - 050627 */
					if (GET_FLAG(accrInterPtr, UnitInter_UnitFlg) == TRUE)
					{
						FREE_DYNST(longCoupAccrInterPtr, UnitInter);
						FREE_DYNST(getUnitInter, UnitInter);
					}

					/* PMSTA-10443 - RAK - 101022 */
					if (allocOk == TRUE) 
					{FREE_DYNST(instrPtr, A_Instr);}
					else 
					{FIN_ResetSceActActRule(instrPtr, updateAccrRuleFlg);}

					return(RET_GEN_ERR_INVARG);
				}
				longCoupVal = GET_NUMBER(longCoupAccrInterPtr, UnitInter_UnitAccrInter);
				longNumPeriod = GET_INT(longCoupAccrInterPtr, UnitInter_NumPeriod);
				FREE_DYNST(longCoupAccrInterPtr, UnitInter);
				/* Prepare next period */
				accrPeriod.fromDate = tmpTillDate;
				quant.infoPtr[0].fromDate = accrPeriod.fromDate;
				quant.infoPtr[0].tillDate = refDateTime.date;
			}
		}

		if (FIN_CalcUnitAccrInter(&accrPeriod, &interRate, &quant, &instrChronoVal, 
								  accrPeriod.fromDate, refDateTime.date, accrInterPtr,
								  instrPtr, hierHead,    /* REF5937 - AKO - 010608 : add hierHead */
								  posPtr, NULL) == FALSE)		/* PMSTA01512-CHU-070430 */
																  /* REF3693 - SSO - 990517 */
		{
				/* REF11218 - TEB - 050627 */
				if (GET_FLAG(accrInterPtr, UnitInter_UnitFlg) == TRUE)
				{
					FREE_DYNST(getUnitInter, UnitInter);
				}

				/* PMSTA-10443 - RAK - 101022 */
				if (allocOk == TRUE) 
				{FREE_DYNST(instrPtr, A_Instr);}
				else 
				{FIN_ResetSceActActRule(instrPtr, updateAccrRuleFlg);}

				return(RET_GEN_ERR_INVARG);  /* ?? */
		}
		/* PMSTA02642-CHU-070726 : retrieve eventual first period value in case of long coupon */
		SET_INT(accrInterPtr, UnitInter_NumPeriod,
					GET_INT(accrInterPtr, UnitInter_NumPeriod) +longNumPeriod);
		SET_NUMBER(accrInterPtr, UnitInter_UnitAccrInter,
					GET_NUMBER(accrInterPtr, UnitInter_UnitAccrInter) + longCoupVal);

		FREE(quant.infoPtr);             /* REF9085 - TEB - 030520 */ /* Moving the Free */
     }  /* End else SCE_CheckAccrRule */ /* REF9085 - TEB - 030520 */

	/* Rounding of accrued interest  */ 
	/* If the round unit is different from "default" AND the unit accrued interest round */
	/* flag is set to TRUE, then rounding of unitary accrued interest should occur.      */
	if (GET_FLAG(instrPtr, A_Instr_UnitAiRoundFlg) == TRUE &&
	    GET_ENUM(instrPtr, A_Instr_AiRoundUnitEn) != RndUnit_None)
	{
	    /* If the rounding rule is set to "default", then the rule    */
	    /* specified at the currency of the accrued interest is used. */
	    if (GET_ENUM(instrPtr, A_Instr_AiRoundRuleEn) == RndRule_None)
	    {
		    DBA_DYNFLD_STP currPtr=NULL;
            FLAG_T         freeFlag = FALSE;

            /* REF5248 - RAK - 001005 */
            /* Suppress DBA_Get2(Curr) and FREE_DYNST for currPtr */ 
			/* PMSTA16847 - DDV - 130924 - Add freeFlag parameter */
            if ((ret = DBA_GetCurrById(GET_ID(accrInterPtr, UnitInter_CurrId), 
                                       &currPtr, &freeFlag)) != RET_SUCCEED)
		    {
				/* PMSTA-10443 - RAK - 101022 */
				if (allocOk == TRUE) 
				{FREE_DYNST(instrPtr, A_Instr);}
				else 
				{FIN_ResetSceActActRule(instrPtr, updateAccrRuleFlg);}

				/* REF11218 - TEB - 050627 */
				if (GET_FLAG(accrInterPtr, UnitInter_UnitFlg) == TRUE)
				{
					FREE_DYNST(getUnitInter, UnitInter);
				}
			    return(ret);
		    }

		    rndRuleEn = (RNDRULE_ENUM) GET_ENUM(currPtr, A_Curr_RoundRuleEn);

            if (freeFlag == TRUE) {FREE_DYNST(currPtr, A_Curr);}
	    }
	    else
	    {
		    rndRuleEn = (RNDRULE_ENUM) GET_ENUM(instrPtr, A_Instr_AiRoundRuleEn);
	    }

	    round = TLS_RoundEnum((double) GET_NUMBER(accrInterPtr, UnitInter_UnitAccrInter), 
		                      (RNDUNIT_ENUM) GET_ENUM(instrPtr, A_Instr_AiRoundUnitEn), 
                              rndRuleEn);
	    SET_NUMBER(accrInterPtr, UnitInter_UnitAccrInter, round);
	}

	/* Save calculated unitary accrued interest in memory */
	if (GET_FLAG(accrInterPtr, UnitInter_UnitFlg) == TRUE)	/* BUG143 */
	{
	    /* REF1252 - Set begin date for money market. */
	    if (instrNat == InstrNat_Discount || instrNat == InstrNat_MoneyMkt)
	    {
		    DATETIME_T tmpDate;
		    tmpDate.time = 0;
		    tmpDate.date = GET_DATE(instrPtr, A_Instr_BeginDate);
		    SET_DATETIME(accrInterPtr, UnitInter_BegDate, tmpDate);
	    }
	    else
	    {
		    SET_NULL_DATETIME(accrInterPtr, UnitInter_BegDate);
	    }

		/* REF11218 - TEB - 050627 */
		if (accrRule != AccrRule_None)
		{
			SET_ENUM(accrInterPtr, UnitInter_AccrRuleEn, (ENUM_T)accrRule );
		}

		/* PMSTA06529-CHU-080508 : no optimization for generic instrument during fusion, recompute everytime */
		if (GET_ID(instrPtr, A_Instr_Id) < 0 || GET_FLAG(instrPtr, A_Instr_GenericFlg)==FALSE)
		{
			ret = DBA_SetMemory(OptiFct, UNUSED, UnitInter, /*accrInterPtr*/ getUnitInter, /* REF11218 - TEB - 050627 - Optimisation non optimisee */
								UnitInter, accrInterPtr, Opti_Local);
		}

		FREE_DYNST(getUnitInter, UnitInter); /* REF11218 - TEB - 050627 */
	}

	FREE(interRate.infoPtr);

	/* PMSTA-10443 - RAK - 101022 */
    if (allocOk == TRUE) 
	{FREE_DYNST(instrPtr, A_Instr);}
	else 
	{FIN_ResetSceActActRule(instrPtr, updateAccrRuleFlg);}
	return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_SetSceActActRule()
**
**  Description :   
**
**  Arguments   :   
**
**  Return      :   
**
**  Creation    :   PMSTA-10443 - RAK - 101022
**
*************************************************************************/
RET_CODE FIN_SetSceActActRule(DBA_DYNFLD_STP instrPtr, FLAG_T *updateAccrRuleFlg)
{
	RET_CODE ret=RET_SUCCEED;

	*updateAccrRuleFlg = FALSE;

	if (SYS_GetEnv("AAA_OLD_ACTUAL_AI") == NULL)	/* to keep old computation */
	{
		if ((ACCRRULE_ENUM) GET_ENUM(instrPtr, A_Instr_AccrualRuleEn) == AccrRule_Actual_Actual)
		{
			SET_ENUM(instrPtr, A_Instr_AccrualRuleEn, AccrRule_SceActAct);

			/* perhaps init some SCE fields */

			*updateAccrRuleFlg = TRUE;
		}
	}

	return(ret);
}

/************************************************************************
**
**  Function    :   FIN_ResetSceActActRule()
**
**  Description :   
**
**  Arguments   :   
**
**  Return      :   
**
**  Creation    :   PMSTA-10443 - RAK - 101022
**
*************************************************************************/
RET_CODE FIN_ResetSceActActRule(DBA_DYNFLD_STP instrPtr, FLAG_T updateAccrRuleFlg)
{
	RET_CODE ret=RET_SUCCEED;

	if (updateAccrRuleFlg == TRUE)
	{
		SET_ENUM(instrPtr, A_Instr_AccrualRuleEn, AccrRule_Actual_Actual);
	}

	return(ret);
}

/************************************************************************
**
**  Function    :   FIN_SearchFirstAccrDateBusDay()
**
**  Description :   Determine date from which interest has been accruing.
**                  The returned 'from date' is a business day, determined 
**                  by the business day convention of the instrument.
**                  The function is used for FRN and swap legs.
**                 
**  Arguments   :   refDateTime    reference date
**                  fullCoupFlg    parameter which determine if accrued 
**                                 interest on the first interest accrual date 
**                                 is equal to 0 or to a full interest period.
**                  accrPerPtr     pointer on accrual period structure to fill
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   REF7287 - YST - 020128
**  Modification:   REF7996 - YST - 021001
**
*************************************************************************/
STATIC RET_CODE FIN_SearchFirstAccrDateBusDay(DBA_DYNFLD_STP    instrPtr,
                                            DATETIME_T          refDateTime, 
			                                char                fullCoupFlg, 
			                                FIN_ACCR_PERIOD_STP accrPerPtr,
											DBA_HIER_HEAD_STP hierHead)
{
	DATE_T      oldWork = 0, tmpWorkDate = 0, tmpExDate = 0;
    ID_T        calendarId = 0; 
	char        found = FALSE;
    RET_CODE    ret = RET_SUCCEED;

	if (accrPerPtr->payFreq == 0 && accrPerPtr->lastPayDate == 0)
	{
		accrPerPtr->fromDate = accrPerPtr->workDate;
		return(RET_SUCCEED);
	}

	/* Don't compute accrued interest if it begins after report date */
	if (accrPerPtr->workDate > refDateTime.date)
	{
		return(RET_GEN_INFO_NOACTION);
	}		

	/* Don't compute accrued interest if it finishes before report date */
	if (fullCoupFlg == FALSE && accrPerPtr->lastPayDate <= refDateTime.date) 
	{
		return(RET_GEN_INFO_NOACTION);
	}		

	if (fullCoupFlg == TRUE && accrPerPtr->lastPayDate < refDateTime.date)
	{
		return(RET_GEN_INFO_NOACTION);
	}		

    /* REF7996 - YST - 021001 - no business day adjustement for the begin date of instrument */
    if (DATE_Cmp(accrPerPtr->workDate, GET_DATE(instrPtr, A_Instr_BeginDate)) == 0)
        tmpWorkDate = accrPerPtr->workDate;
    else
        ret = SCE_CldrNextBusinessDateInstrConv(instrPtr, calendarId, accrPerPtr->workDate, &tmpWorkDate);
    if (ret == RET_SUCCEED) 
    {
        if (0 == accrPerPtr->exDate)   
            tmpExDate = accrPerPtr->exDate;
        else
            ret = SCE_CldrNextBusinessDateInstrConv(instrPtr, calendarId, accrPerPtr->exDate, &tmpExDate);
    }

	/*PMSTA-46590 - SENTHILKUMAR - 25102021*/

	FLAG_T mktConvMethodEnblFlg = FALSE;
	if (instrPtr != nullptr)
	{

		DBA_DYNFLD_STP      *selInterTab = NULLDYNSTPTR;
		int                 selInterNbr = 0;

		if ((INSTRNAT_ENUM)GET_ENUM(instrPtr, A_Instr_NatEn) != InstrNat_CashAcct)
		{
			MemoryPool mp;

			DBA_DYNFLD_STP      intRateCondPtr = NULLDYNST;

			FLAG_T		        interCondRecFlg = FALSE;

			intRateCondPtr = mp.allocDynst(FILEINFO, A_InterCond);

			if (GET_ID(instrPtr, A_Instr_Id) < 0)
			{
				SET_ID(intRateCondPtr, A_InterCond_InstrId, GET_ID(instrPtr, A_Instr_ParentInstrId));
			}
			else
			{
				SET_ID(intRateCondPtr, A_InterCond_InstrId, GET_ID(instrPtr, A_Instr_Id));
			}
			SET_DATE(intRateCondPtr, A_InterCond_BeginDate, GET_DATE(instrPtr, A_Instr_BeginDate));
			SET_DATE(intRateCondPtr, A_InterCond_EndDate, refDateTime.date);
			SET_ENUM(intRateCondPtr, A_InterCond_NatEn, InterCondNat_None);

			if (instrPtr != NULLDYNST &&
				(CMP_ENUM((INSTRNAT_ENUM)GET_ENUM(instrPtr, A_Instr_NatEn), InstrNat_FundShare) == 0) &&
				((CMP_ENUM((SUBNAT_ENUM)GET_ENUM(instrPtr, A_Instr_SubNatEn), SubNat_MoneyMarketFundShare) == 0) ||
				(CMP_ENUM((SUBNAT_ENUM)GET_ENUM(instrPtr, A_Instr_SubNatEn), SubNat_FixedIncomeFundShare) == 0)))
			{
				SET_DATE(intRateCondPtr, A_InterCond_ValidDate, accrPerPtr->fromDate);
			}

			if ((ret = DBA_SelAllInterCond(InterCond_ByIdDt, hierHead, instrPtr, intRateCondPtr,
				&selInterTab, &selInterNbr, &interCondRecFlg)) != RET_SUCCEED)
			{
				ret = RET_DBA_ERR_NODATA;
				MSG_SendMesg(ret, 3, FILEINFO, "DBA_SelectInterCond", GET_CODE(instrPtr, A_Instr_Cd), "interest condition");
				return ret;
			}
		}

		if (selInterNbr > 0 &&
			static_cast<InstrMktConvMethodEn>GET_ENUM(selInterTab[0], A_InterCond_MktConvMethodEn) != InstrMktConvMethodEn::None)
		{
			mktConvMethodEnblFlg = TRUE;
		}
		DBA_FreeDynStTab(selInterTab, selInterNbr, A_InterCond);
	}
	FLAG_T Paymentstartdate_f = TRUE;
	while (found == FALSE && accrPerPtr->workDate != BAD_DATE && ret == RET_SUCCEED)
	{	
		/* Save current working date */
		oldWork = tmpWorkDate;

		/* Move dates period by period */
		if (accrPerPtr->firstCoupDate > accrPerPtr->workDate)
		{
			accrPerPtr->workDate = accrPerPtr->firstCoupDate;
			accrPerPtr->firstCoupDate = 0; /* only 1 time */
		}
		else
		{
		    /* For null frequency there is only one accrual period in */
		    /* instrument life so go to last payment date.            */
		    if (accrPerPtr->payFreq == 0)
		    {
			    accrPerPtr->workDate = accrPerPtr->lastPayDate;
		    }
		    else
		    {
				/*PMSTA-46590 - SENTHILKUMAR - 25102021*/
				if (mktConvMethodEnblFlg == TRUE && Paymentstartdate_f == TRUE && IS_NULLFLD(instrPtr, A_Instr_DatedDate) == FALSE)
				{
					accrPerPtr->workDate = DATE_Move(GET_DATE(instrPtr, A_Instr_BeginDate),
						accrPerPtr->payFreq, Month);
				}
				else
					accrPerPtr->workDate = DATE_Move(accrPerPtr->workDate, accrPerPtr->payFreq, Month);
		    }
		}

		Paymentstartdate_f = FALSE;
        ret = SCE_CldrNextBusinessDateInstrConv(instrPtr, calendarId, accrPerPtr->workDate, &tmpWorkDate);

		/*PMSTA-46783 - SENTHILKUMAR - 28102021*/
		if (mktConvMethodEnblFlg == TRUE && ((ACCRRULE_ENUM)GET_ENUM(instrPtr, A_Instr_AccrualRuleEn) == AccrRule_30_360 ||
			(ACCRRULE_ENUM)GET_ENUM(instrPtr, A_Instr_AccrualRuleEn) == AccrRule_30E_360 ||
			(ACCRRULE_ENUM)GET_ENUM(instrPtr, A_Instr_AccrualRuleEn) == AccrRule_30_360_1 ||
			(ACCRRULE_ENUM)GET_ENUM(instrPtr, A_Instr_AccrualRuleEn) == AccrRule_30_360_US ||
			(ACCRRULE_ENUM)GET_ENUM(instrPtr, A_Instr_AccrualRuleEn) == AccrRule_30_360_FebAdj ||
			(ACCRRULE_ENUM)GET_ENUM(instrPtr, A_Instr_AccrualRuleEn) == AccrRule_30_360_Def) && (CALNEXTBUSDATERULE_ENUM)GET_ENUM(instrPtr, A_Instr_BusDayConvEn) != CalNextBusDateRule_Default)
		{
			DAY_T date_30360 = 0;
			DATE_Get((DATE_T)tmpWorkDate, (YEAR_T *)NULL, (MONTH_T *)NULL, (DAY_T *)&date_30360);
			if (date_30360 == 31)
			{
				tmpWorkDate = accrPerPtr->workDate;
			}
		}
        if (ret == RET_SUCCEED) 
        {
            if (0 == accrPerPtr->exDate)   
                tmpExDate = accrPerPtr->exDate;
            else
                ret = SCE_CldrNextBusinessDateInstrConv(instrPtr, calendarId, accrPerPtr->exDate, &tmpExDate);
        }

        if (ret == RET_SUCCEED) 
        {
		    if (tmpExDate == 0)
		    {
			    accrPerPtr->exDate = accrPerPtr->workDate;
                tmpExDate = tmpWorkDate;
		    }

		    /* tmp ex-date must be between two payment date */
		    if (tmpExDate < oldWork || 
		        tmpExDate > tmpWorkDate)
		    {
			    accrPerPtr->exDate = accrPerPtr->workDate;
                tmpExDate = tmpWorkDate;
		    }
	    
		    
		    if (fullCoupFlg == FALSE && refDateTime.date < tmpWorkDate)
			    found = TRUE;

		    if (fullCoupFlg == TRUE && refDateTime.date <= tmpWorkDate)
			    found = TRUE;

		    if (found == FALSE)
	   	    	accrPerPtr->exDate = DATE_Move(accrPerPtr->exDate, accrPerPtr->payFreq, Month);
	    }
    }

	if (found == TRUE && ret == RET_SUCCEED)
	{
        /* From date is tmp working date or old working date depending on tmp ex-date */
		if (fullCoupFlg == TRUE)
		{
			if (refDateTime.date > tmpExDate)
				accrPerPtr->fromDate = tmpWorkDate;
			else
				accrPerPtr->fromDate = oldWork;
		}
		else
		{
			if (refDateTime.date >= tmpExDate)
				accrPerPtr->fromDate = tmpWorkDate;
			else
				accrPerPtr->fromDate = oldWork;
		}
		return(RET_SUCCEED);
	}
	else
	{
		accrPerPtr->fromDate = BAD_DATE;
		return(RET_GEN_ERR_INVARG);
	}
}

/************************************************************************
**
**  Function    :   FIN_AccrVal()
**
**  Description :   This function returns the accrued interests computed with the accrued valuation method
**                  in the reference currency according to the input quantity. 
**                  ! Initialy only enabled for instruments of nature bond (fixed income) and swap.
**
**                  If instrument is of nature swap, the swap is decomposed in its legs and 
**                  FIN_AccrVal() is called a second time for the swap legs. 
**                  
**                  It uses the "calculation of unitary accrued
**                  interest function". This unitary amount may be adjusted by 
**                  a tax rate. It is then multipled by a quantity and 
**                  converted into the reference currency.
**                  
**  Arguments   :   accrValEndDate  reference date
**                  instrId         instrument identification
**                  inputInstrPtr   pointer on instrument structure or NULL
**                  refCurrId       reference currency identification
**                  aiArgStp               
**                  qty             quantity of instrument to be valued
**                  mktPtr          pointer on net value structure to fill 
**                                  (accrued interest informations only)
**                  *selPosTab      pointer on positions selected in FIN_AccrVal()            
**                  selPosNbr       number of records in selPosTab
**                  firstCallFlg    - TRUE  if FIN_AccrVal() is called from FIN_AccrInter()
**                                  - FALSE if FIN_AccrVal() is called from FIN_AccrVal()
**                  hierHead        pointer on hierarchy      
**
**  Return      :   RET_SUCCEED or error code
**                  values of structure mktPtr will be modified, it will be 
**                  - accrInterRefCurr interest in reference currency 
**                  All field are initialised to 0 or NULL 
**
** Creation     :   REF7265 - YST - 020318
** Modification :   REF7782 - YST - 020904
**                  REF9118.4001B - YST - 030520
**                  REF9085 - YST - 030624 - new algo
**					REF9415 - RAK - 030826 - exchange on historical date
**					REF9451 - CHU - 030912 : Changed select stored proc and filter 
**                  REF9267 - TEB - 031106 : Add copy of position's val date
**					REF9451 - CHU - 031114 : Code report from R4.00.3 - removed YST's new algo
**                  REF11163 - TEB - 050713
**
*************************************************************************/
STATIC RET_CODE FIN_AccrVal(DATETIME_T         accrValEndDate,
	    	                 ID_T               instrId, 
		                     DBA_DYNFLD_STP     inputInstrPtr, 
		                     ID_T               refCurrId, 
		                     FIN_AIARG_STP      aiArgStp,
        		             DBA_DYNFLD_STP     posPtr, 
	        	             FIN_MKTVAL_STP     mktPtr,
                             DBA_DYNFLD_STP     *selPosTab,
                             int                selPosNbr,
                             FLAG_T             firstCallFlg,
                             DBA_HIER_HEAD_STP  hierHead) 
{
    DBA_DYNFLD_STP  instrPtr=NULL, unitAccrInter=NULL, *flowTab=NULL, 
                    domainPtr=NULL, getArg=NULL;
	FIN_EXCHARG_ST  exchArgSt;	
    DATETIME_T      flowOptDate, accrValFromDate, posBegDate;
	FLAG_T		    allocOk = FALSE, applUnitAccrIntAllDecFlag = FALSE, 
                    nextFlowFlg = FALSE, firstFlg = TRUE, instrSwapCompFlg= FALSE; 
    ENUMMASK_T          mask=0;
    NUMBER_T        posQty = 0, tmpQty = 0, sign = 1;	/* REF9946 - RAK - 040519 - declare as NUMBER_T */
    int             connectNo = -1, posIdx = 0, flowNbr = 0, totalFlowNbr = 0, flowIdx = 0;
    RNDRULE_ENUM    rndRuleEn;
	RNDUNIT_ENUM    rndUnitEn;
    INSTRNAT_ENUM   instrNat = InstrNat_None, tmpInstrNat = InstrNat_None;
    SUBNAT_ENUM     instrSubNat = SubNat_None;   
    RET_CODE        ret = RET_SUCCEED;

	/* REF9415 - RAK - 030821 */
	NUMBER_T		accrInter=0.0, accrInterRefCurr=0.0;
	EXCHANGE_T		exchRate=0.0;

	memset(&exchArgSt, 0, sizeof(FIN_EXCHARG_ST));	

	DBA_InitConnectNoToExchArg(&exchArgSt, hierHead); 

	/* If TRUE, don't truncate to 9th decimal */
	GEN_GetApplInfo(ApplUnitAccrIntAllDecFlag, &applUnitAccrIntAllDecFlag);
  
	/* If instrument structure was load upper, his pointer is given in parameters list. So function use it and don't free it. */
	if (inputInstrPtr != NULL)
	{
		instrPtr = inputInstrPtr;
		allocOk = FALSE;
	}
	else
	{
        if ((ret = DBA_GetInstrById(instrId, FALSE, &allocOk, &instrPtr, hierHead, UNUSED, UNUSED)) != RET_SUCCEED)
        {
            /*lint --e{429} - REF7475 - YST - 020620 - no free needed for selPosTab */
            return(ret); 
        }
	}

    instrNat = (INSTRNAT_ENUM) GET_ENUM(instrPtr, A_Instr_NatEn);
    instrSubNat = (SUBNAT_ENUM) GET_ENUM(instrPtr, A_Instr_SubNatEn);
    instrSwapCompFlg = FIN_IsBondOfSwap (instrPtr, hierHead);

    /* set tmpInstrNat, which is either swap for swap and swap legs or bond for bond (fixed income) */
    if (instrNat == InstrNat_Swap || instrSwapCompFlg == TRUE ||
        (instrNat == InstrNat_Bond && 
        (instrSubNat == SubNat_RecSwapFloatLeg || instrSubNat == SubNat_PaidSwapFloatLeg ||
         instrSubNat == SubNat_RecSwapFixedLeg || instrSubNat == SubNat_PaidSwapFixedLeg)))
    {
        tmpInstrNat = InstrNat_Swap;
    }
    /* REF9429 - RAK - 030828 */
    else if (instrNat == InstrNat_Bond || instrNat == InstrNat_ConvertBond)
    {
        tmpInstrNat = InstrNat_Bond;
    }

    /* method accrued interests is only enabled for instruments of nature bond (fixed income) and swap */
    if (tmpInstrNat != InstrNat_Bond && tmpInstrNat != InstrNat_Swap)
    {
        if (allocOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
        return(RET_GEN_INFO_NOACTION);
    }

	/* REF11218 - TEB - 050627 */
	/* If nature different of Bond or Convert Bond only use accrual rule of instrument */
	if (tmpInstrNat != InstrNat_Bond)
	{
		aiArgStp->accrRule = (ACCRRULE_ENUM) AccrRule_None;
	}

    /* from date should be bigger or equal to begin date of instrument */
    if (DATE_Cmp(aiArgStp->accrValFromDate.date, GET_DATE(instrPtr, A_Instr_BeginDate)) < 0)
        aiArgStp->accrValFromDate.date = GET_DATE(instrPtr, A_Instr_BeginDate);

    if (DATE_Cmp(aiArgStp->accrValFromDate.date, accrValEndDate.date) >= 0)
    {
        MSG_SendMesg(RET_FIN_ERR_INVDATA, 2, FILEINFO, "FIN_AccrVal()", "from date for accrued valuation");
        if (allocOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
        /*lint --e{429} - REF7475 - YST - 020620 - no free needed for selPosTab */
        return(RET_FIN_ERR_INVDATA);
    }

    /* Check if positions are already loaded. (This is the case when FIN_AccrVal() calls FIN_AccrVal(). ) */
    if (selPosNbr == 0)
    {
		DBA_DYNFLD_STP	*tmpSelPosTab = NULL;
		FLAG_T			*keepPos = NULL;

		int				i, tmpSelPosNbr = 0;
		FLAG_T			suppressFlg = FALSE;
		FLAG_T			imNotAlone = FALSE;

        /* If derived position, select all the positions from database valid in the accrued valuation period. */
        /* Test on ExtPos_DBPrimaryEn (= value in database), because value in ExtPos_PrimaryEn is changed by some function. */
        if (GET_ENUM(posPtr, ExtPos_DBPrimaryEn) != PosPrimary_Primary)
        {
            if ((domainPtr = DBA_GetDomainPtr(DBA_GetConnectNoFromHier(hierHead)))==NULL)
            {
                if (allocOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
                /*lint --e{429} - REF7475 - YST - 020620 - no free needed for selPosTab */
                return(RET_GEN_ERR_INVARG);
            }

            if ((getArg = ALLOC_DYNST(Get_Arg)) == NULL)
            {
		        if (allocOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
                /*lint --e{429} - REF7475 - YST - 020620 - no free needed for selPosTab */
                MSG_RETURN(RET_MEM_ERR_ALLOC);
	        }

			/* REF9946 - RAK - 040427 - for legs of swap, use positions of the swap */
			/*          (swap id is set in A_Instr_RefInstrId by FIN_SwapLegInstr())*/ 
			if (instrSwapCompFlg == TRUE)
			{ 
				SET_ID(getArg, Get_Arg_InstrId, GET_ID(instrPtr, A_Instr_RefInstrId));
			}
			else if (GET_ID(instrPtr, A_Instr_Id) > 0)
            {
				SET_ID(getArg, Get_Arg_InstrId, GET_ID(instrPtr, A_Instr_Id));
			}
            else
            {
				SET_ID(getArg, Get_Arg_InstrId, GET_ID(instrPtr, A_Instr_ParentInstrId));
			}

            SET_ID(getArg,       Get_Arg_PtfId,         GET_ID(posPtr, ExtPos_PtfId)); 
            SET_ID(getArg,       Get_Arg_PtfPosSetId,   GET_ID(domainPtr, A_Domain_PortPosSetId));
            SET_DATETIME(getArg, Get_Arg_DateTime,      aiArgStp->accrValFromDate);  
            SET_DATETIME(getArg, Get_Arg_DateTime2,     accrValEndDate);
            SET_ENUM(getArg,     Get_Arg_Enum1,         GET_ENUM(domainPtr, A_Domain_MinStatEn));
            SET_ENUM(getArg,     Get_Arg_Enum2,         GET_ENUM(domainPtr, A_Domain_MaxStatEn));
			SET_FLAG(getArg,     Get_Arg_DerivedFlg,    TRUE); /* REF9451 - CHU - 030912 : Load derived positions */

	        if ((ret = DBA_Select2(Pos, UNUSED, Get_Arg, getArg, A_Pos, &selPosTab,  
	                          UNUSED, UNUSED, &selPosNbr, &connectNo, UNUSED)) != RET_SUCCEED || selPosNbr == 0)
            {
                MSG_SendMesg(RET_DBA_ERR_NODATA, 3, FILEINFO, "FIN_AccrVal", GET_CODE(instrPtr, A_Instr_Cd), "Positions");
		        if (allocOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
                FREE_DYNST(getArg, Get_Arg);
		        return(ret);
            }
           
            FREE_DYNST(getArg, Get_Arg);

            if (selPosNbr > 1)
			{
                TLS_Sort((char *) selPosTab, selPosNbr, sizeof(DBA_DYNFLD_STP),  
			            (TLS_CMPFCT *) FIN_CmpPosForAccrVal, NULL, SortRtnTp_None);
			}

			/* < REF9451 - CHU - 030910 : Begin */
			/* Allocate space for positions temporary table */
			if((tmpSelPosTab = (DBA_DYNFLD_STP *)CALLOC(selPosNbr, sizeof(DBA_DYNFLD_STP))) == NULL)
			{
				if (allocOk == TRUE)
				{
					FREE_DYNST(instrPtr, A_Instr);
				}
				FREE(selPosTab);
				MSG_RETURN(RET_MEM_ERR_ALLOC);
			}

			/* REF9416 - RAK - 040107 - For swap, suppress position with value date after computation date */
			if (tmpInstrNat == InstrNat_Swap)
			{
				for (suppressFlg=FALSE, tmpSelPosNbr=0, i=0; i<selPosNbr; i++)
				{
					/* keep position */
					if (DATETIME_CMP(GET_DATETIME(selPosTab[i], A_Pos_ValDate), accrValEndDate) <= 0)
					{
						tmpSelPosTab[tmpSelPosNbr] = selPosTab[i];
						tmpSelPosNbr++;
					}
					else
						suppressFlg = TRUE;
				}

				if (suppressFlg == TRUE)
				{
					/* Update position table */
					FREE(selPosTab);
					selPosTab = tmpSelPosTab;
					selPosNbr = tmpSelPosNbr;

					/* realloc for next treatment */
					if((tmpSelPosTab = (DBA_DYNFLD_STP *)CALLOC(selPosNbr, sizeof(DBA_DYNFLD_STP))) == NULL)
					{
						if (allocOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
						FREE(selPosTab);
						MSG_RETURN(RET_MEM_ERR_ALLOC);
					}
				}
			
				tmpSelPosNbr = 0;
				suppressFlg = FALSE;
			}

			/* Allocate space for table to store flags that indicate position keeping or removal */
			if((keepPos = (FLAG_T *)CALLOC(selPosNbr, sizeof(FLAG_T))) == NULL)
			{
				if (allocOk == TRUE)
				{
					FREE_DYNST(instrPtr, A_Instr);
				}
				FREE(selPosTab);
				FREE(tmpSelPosTab);
				MSG_RETURN(RET_MEM_ERR_ALLOC);
			}

			/* REF10326 - CHU - 040720 : Removed part of the algorithm processing differently    */
			/* positions with quantity==0 or not - CMS #46690 - finai.c version 32 TA4.20.Alpha0 */
			/* if (CMP_NUMBER(GET_NUMBER(posPtr, ExtPos_Qty), 0.0) != 0)                         */
			/* Keep positions linked to posPtr */
			for (i=0; i<selPosNbr; i++)
			{
				/* init all fields with FALSE by default (don't keep position) */
				keepPos[i] = FALSE;

				if ((IS_NULLFLD(posPtr, ExtPos_OpenOpCd) == FALSE) &&
					(IS_NULLFLD(selPosTab[i], A_Pos_CloseOpCd) == FALSE) &&
					(strcmp(GET_CODE(posPtr, ExtPos_OpenOpCd),GET_CODE(selPosTab[i], A_Pos_CloseOpCd)) == 0))
				{
					keepPos[i] = TRUE;
					imNotAlone = TRUE;
				}
			}

			if (imNotAlone)
			{
				/* Keep positions linked to any selected derived position */
				for (i=0; i<selPosNbr; i++)
				{
					if ((keepPos[i] == TRUE) &&
						(GET_ENUM(selPosTab[i], A_Pos_PrimaryEn) != PosPrimary_Primary))
					{
						int j = 0;

						for (; j < selPosNbr; j++)
						{
							if ((IS_NULLFLD(selPosTab[i], A_Pos_OpenOpCd) == FALSE) &&
								(IS_NULLFLD(selPosTab[j], A_Pos_CloseOpCd) == FALSE) &&
								(strcmp(GET_CODE(selPosTab[i], A_Pos_OpenOpCd), GET_CODE(selPosTab[j], A_Pos_CloseOpCd)) == 0))
							{
								/* REF9417 - CHU - 031020 */
								if ((keepPos[j] == FALSE) &&
									(GET_ENUM(selPosTab[j], A_Pos_PrimaryEn) != PosPrimary_Primary))
								{
									/* If a new derived pos is kept, relaunch this loop */
									keepPos[j] = TRUE;
									i = 0;
									break;
								}
								keepPos[j] = TRUE;
							}
						}
					}
				}
				/* Remove all derived position except first one in list */
				for (i=0; i<selPosNbr; i++)
				{
					if (GET_ENUM(selPosTab[i], A_Pos_PrimaryEn) != PosPrimary_Primary)
					{
						if (keepPos[i] == TRUE)
						{
							if((DATETIME_CMP(GET_DATETIME(selPosTab[i], A_Pos_BegDate), aiArgStp->accrValFromDate) <= 0) &&
							   (DATETIME_CMP(GET_DATETIME(selPosTab[i], A_Pos_EndDate), aiArgStp->accrValFromDate) > 0))
							{
								keepPos[i] = TRUE;
							}
							else
								keepPos[i] = FALSE;
						}
					}
				}

				/* Check position table */
				for (i=0; i<selPosNbr; i++)
				{
					if (keepPos[i] == TRUE)
					{
						tmpSelPosTab[tmpSelPosNbr] = selPosTab[i];
						tmpSelPosNbr++;
					}
					else
						suppressFlg = TRUE;
				}

				if (suppressFlg == TRUE)
				{
					/* Update position table */
					FREE(selPosTab);
					selPosTab = tmpSelPosTab;
					selPosNbr = tmpSelPosNbr;
				}
				else
				{
					FREE(tmpSelPosTab);
				}
				tmpSelPosNbr = 0;
					
			}
			else
			{
				selPosNbr = 1;
				/* if bond then take value date, else begin date of position */
				if (tmpInstrNat == InstrNat_Bond)
				{ COPY_DYNFLD(selPosTab[0], A_Pos, A_Pos_ValDate, posPtr, ExtPos, ExtPos_ValDate);}
				else
				{ COPY_DYNFLD(selPosTab[0], A_Pos, A_Pos_BegDate, posPtr, ExtPos, ExtPos_BegDate);}
				COPY_DYNFLD(selPosTab[0], A_Pos, A_Pos_Qty, posPtr, ExtPos, ExtPos_Qty);

				FREE(tmpSelPosTab);
			}

			/* REF10326 - CHU - 040624 : Moved sign change here... */
			/* If paid leg, change sign */
			if (instrSubNat == SubNat_PaidSwapFixedLeg || instrSubNat == SubNat_PaidSwapFloatLeg)
			{
				sign = -1;
			}
			/* REF9946 - RAK - 040513 - use the InstrCompo qty (updated in FIN_SwapLegInstr) */
			/* REF10326 - CHU - 040720 - only if position quantity == 0 */
			else if (instrSwapCompFlg == TRUE && CMP_NUMBER(GET_NUMBER(posPtr, ExtPos_Qty), 0.0) == 0)
			{
				sign = GET_NUMBER(instrPtr, A_Instr_CompoQuantity);
			}

			FREE(keepPos);
        }
        /* If primary position, copy the used fields from posPtr to selPosTab. */
        else
        {
            selPosNbr = 1;
            if ((selPosTab = (DBA_DYNFLD_STP*) CALLOC(selPosNbr, sizeof(DBA_DYNFLD_STP))) == NULL)
            {
                if (allocOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
    		    MSG_RETURN(RET_MEM_ERR_ALLOC);
            }
	        if ((selPosTab[0] = ALLOC_DYNST(A_Pos)) == NULL)
	        {
		        FREE(selPosTab);
                if (allocOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
    		    MSG_RETURN(RET_MEM_ERR_ALLOC);
	        }
            
            /* if bond then take value date, else begin date of position */
            if (tmpInstrNat == InstrNat_Bond)
            { COPY_DYNFLD(selPosTab[0], A_Pos, A_Pos_ValDate, posPtr, ExtPos, ExtPos_ValDate);}
            else
            { COPY_DYNFLD(selPosTab[0], A_Pos, A_Pos_BegDate, posPtr, ExtPos, ExtPos_BegDate);}
            COPY_DYNFLD(selPosTab[0], A_Pos, A_Pos_Qty, posPtr, ExtPos, ExtPos_Qty);
        }   
    }
    

    /* Init at null values */ 
	mktPtr->accrInter             = 0.0; 
	mktPtr->accrInterRefCurr      = 0.0;
	mktPtr->accrInterCurrId       = 0;
	mktPtr->accrInterPeriod.num   = 0;
	mktPtr->accrInterPeriod.denom = 0;
	mktPtr->accrInterRefExch      = 0.0;

    /* Swap AI is the sum of legs AI */
    if (instrNat == InstrNat_Swap)
    { 
        DBA_DYNFLD_STP  *swapLegTab = NULL;
        FIN_MKTVAL_ST   swapLegMktPtr;       
        NUMBER_T        swapAI = 0.0;
        int             swapLegNbr = 0, swapLegIdx = 0;
        FLAG_T          freeswapLegFlg = FALSE;

        if ((ret = FIN_SwapLegInstr(instrPtr, hierHead, accrValEndDate, 
		                            &swapLegTab, &swapLegNbr, &freeswapLegFlg)) != RET_SUCCEED)
	    {
	        if (allocOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
            DBA_FreeDynStTab(selPosTab, selPosNbr, A_Pos);
            return(ret);
	    }

        /* If sell, then change sign */
        if ((OPNAT_ENUM) GET_ENUM(posPtr, ExtPos_OpenOpNatEn) == OpNat_Sell &&
            (POSREFNAT_ENUM) GET_ENUM(posPtr, ExtPos_RefNatEn) == PosRefNat_SwapOpen)
        {   
            sign = -1;
        }
        /* Init at null values */  
        swapLegMktPtr.accrInter             = 0.0; 
	    swapLegMktPtr.accrInterRefCurr      = 0.0;
	    swapLegMktPtr.accrInterCurrId       = 0;
	    swapLegMktPtr.accrInterPeriod.num   = 0;
	    swapLegMktPtr.accrInterPeriod.denom = 0;
	    swapLegMktPtr.accrInterRefExch      = 0.0;

        for (swapLegIdx=0 && ret == RET_SUCCEED; swapLegIdx<swapLegNbr; swapLegIdx++)
        {   
            ret = FIN_AccrVal(accrValEndDate, GET_ID(swapLegTab[swapLegIdx], A_Instr_Id), swapLegTab[swapLegIdx],
		                        refCurrId, aiArgStp, posPtr, &swapLegMktPtr, selPosTab, selPosNbr, FALSE, hierHead);

            if (ret == RET_SUCCEED)
            {
                /* In case of composite swap use compo qty for sum or substract ai */
                /* REF7782 - YST - 020904 - add SubNat_FixFltSwapHedgFix */
                if (instrSubNat != SubNat_FixFloatStdSwap && instrSubNat != SubNat_FixFixStdSwap &&
	                instrSubNat != SubNat_FltFltStdSwap && instrSubNat != SubNat_FixFltSwapHedgFix)
                {
                    if (GET_NUMBER(swapLegTab[swapLegIdx], A_Instr_CompoQuantity)  > 0)
                        swapAI += swapLegMktPtr.accrInterRefCurr;
                    else
                        swapAI -= swapLegMktPtr.accrInterRefCurr;
                }
                else
                {
                    if ((SUBNAT_ENUM) GET_ENUM(swapLegTab[swapLegIdx], A_Instr_SubNatEn) == SubNat_RecSwapFixedLeg || 
                        (SUBNAT_ENUM) GET_ENUM(swapLegTab[swapLegIdx], A_Instr_SubNatEn) == SubNat_RecSwapFloatLeg)
                        swapAI += sign * swapLegMktPtr.accrInterRefCurr;
                    else
                        swapAI -= sign * swapLegMktPtr.accrInterRefCurr;
                }
            }
        }

        if (ret == RET_SUCCEED) 
        {
            mktPtr->accrInterRefCurr = swapAI;

            /* keep last value */
            mktPtr->accrInterRefExch      = swapLegMktPtr.accrInterRefExch;
            mktPtr->accrInterCurrId       = swapLegMktPtr.accrInterCurrId;
		    mktPtr->accrInterPeriod.num   = swapLegMktPtr.accrInterPeriod.num;
		    mktPtr->accrInterPeriod.denom = swapLegMktPtr.accrInterPeriod.denom;
        }

        if (freeswapLegFlg == TRUE)
        { DBA_FreeDynStTab(swapLegTab, swapLegNbr, A_Instr);}
        FREE(swapLegTab);
        if (allocOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
        DBA_FreeDynStTab(selPosTab, selPosNbr, A_Pos);
        return(RET_SUCCEED);    /* Always succeed */
    }
    
    /* REF9946 - RAK - 040526 - Can't continue without position (crash) */
	  if (selPosNbr == 0)
	  {
		    if (allocOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
		    return(RET_SUCCEED);
	  }

    SET_BIT64(mask, FlowSubNat_Any, TRUE);

    ret = FIN_GenerateInstrFlows(aiArgStp->accrValFromDate, accrValEndDate, aiArgStp->accrValFromDate, 
                                FALSE,	/* PMSTA-9032 - RAK - 091216 */
                                instrId, instrPtr, mask, EvtGen_Automatic, EvtDateRule_Term, TRUE, 
                                GenInstrFlow_InstrFlow, aiArgStp->accrRule,		/* REF11218 - TEB - 050627 */
								&flowTab, &flowNbr, hierHead);/* REF8866.4002 - YST - 030311 */

    if (ret == RET_SUCCEED || ret == RET_FIN_ERR_SCE_ZEROFLOW)
    {
        ret = RET_SUCCEED;

        if ((unitAccrInter = ALLOC_DYNST(UnitInter)) == NULL)
	    {
		    if (allocOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
            if (firstCallFlg == TRUE) {DBA_FreeDynStTab(selPosTab, selPosNbr, A_Pos);}
            DBA_FreeDynStTab(flowTab, flowNbr, Flow);
            /*lint --e{429} - REF7475 - YST - 020620 - free only needed for selPosTab when first call */
		    MSG_RETURN(RET_MEM_ERR_ALLOC);
	    }
        
        posIdx = 0;
        tmpQty = GET_NUMBER(selPosTab[posIdx], A_Pos_Qty);

        /* if bond then take value date, else begin date of position */
        if (tmpInstrNat == InstrNat_Bond)
        { 
			posBegDate = GET_DATETIME(selPosTab[posIdx], A_Pos_ValDate);
		}
        else
        { 
			/* REF9416 - RAK - 040107 */
			if (GET_ENUM(selPosTab[posIdx], A_Pos_RefNatEn) == PosRefNat_SwapClose)
			{
				posBegDate = GET_DATETIME(selPosTab[posIdx], A_Pos_ValDate);
			}
			else
			{
				posBegDate = GET_DATETIME(selPosTab[posIdx], A_Pos_BegDate);
			}
		}

        if (DATE_Cmp(aiArgStp->accrValFromDate.date, posBegDate.date) < 0)
            aiArgStp->accrValFromDate = posBegDate;

        accrValFromDate = aiArgStp->accrValFromDate;

        totalFlowNbr = flowNbr;
        if (0 == flowNbr || DATE_Cmp(GET_DATE(flowTab[flowNbr-1], Flow_OptimalDate), accrValEndDate.date) < 0)
            totalFlowNbr += 1;

        /* compute accrued interests for each sub-period (=flow) */
        for (flowIdx=0 && ret == RET_SUCCEED; flowIdx<totalFlowNbr; flowIdx++)
        {
            if (flowIdx < flowNbr)
                flowOptDate = GET_DATETIME(flowTab[flowIdx], Flow_OptimalDate);
            else 
                flowOptDate = accrValEndDate;

            firstFlg = TRUE;     
            nextFlowFlg = FALSE;

            /* REF9118.4002 - YST - 030516 - if final redemption, dont'take it */
            if (flowIdx < flowNbr && FlowNat_Redm == (FLOWNAT_ENUM)GET_ENUM(flowTab[flowIdx], Flow_NatEn))
                nextFlowFlg = TRUE;

            /* begin treatment for positions for current flow */
            while (nextFlowFlg == FALSE && ret == RET_SUCCEED)
            {
                /* for each flow a special treatment when passing the first time in the loop */
                if (firstFlg == TRUE) 
                {
                    accrValFromDate = aiArgStp->accrValFromDate;
                    posQty = tmpQty;
                    firstFlg = FALSE;    
                }
                else 
                {  
                    if (posIdx == 0 && selPosNbr > 1)
                    {                           
                        if (tmpInstrNat == InstrNat_Bond)
                        {   
                            /*lint --e(661) - REF7475 - YST - 020620 - test 1 < selPosNbr included in if */
                            posBegDate = GET_DATETIME(selPosTab[1], A_Pos_ValDate);
                        } 
                        else
                        {   
							/* REF9416 - RAK - 040107 */
							/*lint --e(661) - REF7475 - YST - 020620 - test 1 < selPosNbr included in if */
							/* posBegDate = GET_DATETIME(selPosTab[1], A_Pos_BegDate); */
							if (GET_ENUM(selPosTab[1], A_Pos_RefNatEn) == PosRefNat_SwapClose)
							{
								posBegDate = GET_DATETIME(selPosTab[1], A_Pos_ValDate);
							}
							else
							{
								posBegDate = GET_DATETIME(selPosTab[1], A_Pos_BegDate);
							}
                        }  
                        
                        /* first position is closed, so go to second position */
                        if (DATE_Cmp(posBegDate.date, flowOptDate.date) <= 0)
                        {   posIdx++;  }
                        /* first position is not closed, so go to next flow */
                        else
                        {   nextFlowFlg = TRUE;}
                    }
                    /* only one position, so go to next flow */
                    else if (posIdx == 0 && selPosNbr == 1)
                    {   nextFlowFlg = TRUE;}
                
                    /* test if position should be taken for computing accrued interests */
                    if (posIdx > 0 && nextFlowFlg == FALSE && posIdx < selPosNbr)
                    {
                        /* if bond then take value date, else begin date of position */
                        if (tmpInstrNat == InstrNat_Bond)
                        { 
                            /*lint --e(661) - REF7475 - YST - 020620 - test posIdx < selPosNbr included in if */
                            posBegDate = GET_DATETIME(selPosTab[posIdx], A_Pos_ValDate);
                        }
                        else
                        {   
							/* REF9416 - RAK - 040107 */
                            /*lint --e(661) - REF7475 - YST - 020620 - test posIdx < selPosNbr included in if */
                            /* posBegDate = GET_DATETIME(selPosTab[posIdx], A_Pos_BegDate); */
							
							if (GET_ENUM(selPosTab[posIdx], A_Pos_RefNatEn) == PosRefNat_SwapClose)
							{
								posBegDate = GET_DATETIME(selPosTab[posIdx], A_Pos_ValDate);
							}
							else
							{
								posBegDate = GET_DATETIME(selPosTab[posIdx], A_Pos_BegDate);
							}
                        }

                        /* position starts, so get begin date and quantity, and increment posIdx for next loop. */
                        if(DATE_Cmp(posBegDate.date, flowOptDate.date) < 0)
                        {       
                            /* REF9417 - RAK - 030827 - We are on a second open position (which is closed) */
							if (IS_NULLFLD(selPosTab[posIdx], A_Pos_CloseOpCd) == FALSE  && 
								(GET_ENUM(selPosTab[posIdx], A_Pos_RefNatEn) == PosRefNat_Open))
							{
								accrValFromDate = accrValFromDate;
							}
							else
							{
								accrValFromDate = posBegDate;
							}

                            /*lint --e(661) - REF7475 - YST - 020620 - test posIdx < selPosNbr included in if */
                            posQty = GET_NUMBER(selPosTab[posIdx], A_Pos_Qty);
                            tmpQty += posQty;
                            posIdx++;   
                        }
                        /* position did not start, so go to next flow */
                        else 
                        {   
                            /* position starts at optimal flow date, so get quantity and go to next flow */
                            if (DATE_Cmp(posBegDate.date, flowOptDate.date) == 0)
                            {
                                /*lint --e(661) - REF7475 - YST - 020620 - test posIdx < selPosNbr included in if */
                                posQty = GET_NUMBER(selPosTab[posIdx], A_Pos_Qty);
                                tmpQty += posQty;
                                posIdx++;
                            }
                            nextFlowFlg = TRUE;
                        }
                    }
                }

                /* compute accrued interests for current flow, (else: go to next flow) */
                if (nextFlowFlg == FALSE)
                {
                    if (posIdx >= selPosNbr)
                        nextFlowFlg = TRUE;

                    /* REF7265 - YST - 020320 - add two new arguments */
                    if ((ret = FIN_UnitAccrInter(flowOptDate, instrId, instrPtr, aiArgStp->fusDateRule, aiArgStp->fullCoupFlg, 
                                        aiArgStp->calcAccrInterFlg, aiArgStp->accrInterMethod, accrValFromDate,
										aiArgStp->accrRule, /* REF11218 - TEB - 050627 */
                                        posPtr, unitAccrInter, hierHead, FALSE, NULL)) == RET_SUCCEED) /* PMSTA08308 - 090609 - PMO / PMSTA05389-CHU-080131*/
                    {
                        /* calculate and apply tax rate */
		                if (aiArgStp->txdInterFlg == TRUE)	
		                {
		                    NUMBER_T unitAccrInterNbr = GET_NUMBER(unitAccrInter, UnitInter_UnitAccrInter);
                            FIN_TaxRateUnitAccrInter(&unitAccrInterNbr, instrPtr);

		                    /* In case of TRUE, don't truncate to 9th decimal */
		                    if (applUnitAccrIntAllDecFlag == TRUE)
		                    { 
                                SET_NUMBER(unitAccrInter, UnitInter_UnitAccrInter, unitAccrInterNbr); 
                            }
		                    else
		                    { 
                                SET_NUMBER(unitAccrInter, UnitInter_UnitAccrInter, CAST_NUMBER(unitAccrInterNbr)); 
                            }
		                }

						/* REF9415 - RAK - 030821 - Convert in reference currency on op date */
                        /* mktPtr->accrInter += sign * posQty * GET_NUMBER(unitAccrInter, UnitInter_UnitAccrInter); */
						
						accrInter = sign * posQty * GET_NUMBER(unitAccrInter, UnitInter_UnitAccrInter);

						/* REF11163 - TEB - 050713 */
						if ( (instrNat==InstrNat_Bond ||
							  instrNat==InstrNat_ConvertBond) &&
							 PriceCalcRule_QuoteInUnit==(PRICECALCRULE_ENUM) GET_ENUM(instrPtr, A_Instr_PriceCalcRuleEn))
						{
							accrInter =  accrInter * CAST_NUMBER(GET_PRICE(instrPtr, A_Instr_FaceValue));
						}

						accrInterRefCurr = accrInter;	/* same if accrInter currency is reference currency, elsewhere will be exchange */
						exchRate = 1.0;
						if (GET_ID(unitAccrInter, UnitInter_CurrId) != refCurrId)
						{
							exchArgSt.srcAmt = accrInter;
							if ((ret = FIN_ExchAmt(flowOptDate, GET_ID(unitAccrInter, UnitInter_CurrId), refCurrId,
				                  0, NULL, posPtr, &exchArgSt,NULL, 
		                          &accrInterRefCurr, 
			                      &exchRate)) != RET_SUCCEED)	/* PMSTA01649 - TGU - 070405 */
							{
								FREE_DYNST(unitAccrInter, UnitInter);
								if (allocOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
								if (firstCallFlg == TRUE) {DBA_FreeDynStTab(selPosTab, selPosNbr, A_Pos);}
								DBA_FreeDynStTab(flowTab, flowNbr, Flow);
								return(ret);
							}

							/* change unitAccrInter currency because is used below */
							SET_ID(unitAccrInter, UnitInter_CurrId, refCurrId);

						}
						/* add exchange amount (accrInter and accrInterRefCurr are same and in reference currency) */
						mktPtr->accrInter += accrInterRefCurr;
						mktPtr->accrInterRefCurr = mktPtr->accrInter;
                    }
                }
            } /* end while nextFlowFlg */

        }/* end for flowIdx */
    }

    /* Stop in case of memory error only (no accrued interest isn't a error) */
    if (RET_GET_LEVEL(ret) == RET_LEV_ERROR && RET_GET_CATEG(ret) == RET_CATEG_MEM)
	{
        FREE_DYNST(unitAccrInter, UnitInter);
		if (allocOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
        if (firstCallFlg == TRUE) {DBA_FreeDynStTab(selPosTab, selPosNbr, A_Pos);}
        DBA_FreeDynStTab(flowTab, flowNbr, Flow);
        /*lint --e{429} - REF7475 - YST - 020620 - free only needed for selPosTab when first call */
		return(ret);
	}

	/* In case of minor error, return null accrued interest */
   	if (ret == RET_SUCCEED) 
	{
        mktPtr->accrInterCurrId = GET_ID(unitAccrInter,  UnitInter_CurrId);
        mktPtr->accrInterPeriod.num   = GET_INT(unitAccrInter, UnitInter_NumPeriod);
		mktPtr->accrInterPeriod.denom = GET_INT(unitAccrInter, UnitInter_DenomPeriod);

		/* Rounding of accrued interest - RAK - 960603 */ 
		/* If the rounding unit is different from "default" OR the rounding rule is      */
		/* different from "default" AND the unit accrued interest round flag is set to   */
		/* FALSE, the rounding of accrued interest amounts circumvents the std rounding. */
		if (GET_FLAG(instrPtr, A_Instr_UnitAiRoundFlg) == FALSE &&
		    (GET_ENUM(instrPtr, A_Instr_AiRoundRuleEn) != RndRule_None ||
		     GET_ENUM(instrPtr, A_Instr_AiRoundUnitEn) != RndUnit_None))
	  	{
		    DBA_DYNFLD_STP currPtr=NULL;
		    double         round;
            FLAG_T         freeFlag=FALSE;

		    /* If the rounded rule or the rouding unit are set to "default", then the   */
		    /* rule or unit specified at the currency of the accrued interest are used. */
		    if (GET_ENUM(instrPtr, A_Instr_AiRoundRuleEn) == RndRule_None ||
			    GET_ENUM(instrPtr, A_Instr_AiRoundUnitEn) == RndUnit_None)
		    {
                /* Suppress DBA_Get2(Curr) and FREE_DYNST for currPtr */ 
				/* PMSTA16847 - DDV - 130924 - Add freeFlag parameter */
                if ((ret = DBA_GetCurrById(GET_ID(unitAccrInter, UnitInter_CurrId), 
                                           &currPtr, &freeFlag)) != RET_SUCCEED)
			    {
                    FREE_DYNST(unitAccrInter, UnitInter);
				    if (allocOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
                    if (firstCallFlg == TRUE) {DBA_FreeDynStTab(selPosTab, selPosNbr, A_Pos);}
                    DBA_FreeDynStTab(flowTab, flowNbr, Flow);
                    /*lint --e{429} - REF7475 - YST - 020620 - free only needed for selPosTab when first call */
				    return(ret);
			    }
		    }

		    if (GET_ENUM(instrPtr, A_Instr_AiRoundRuleEn) == RndRule_None)
		    {   
			    rndRuleEn = (RNDRULE_ENUM) GET_ENUM(currPtr, A_Curr_RoundRuleEn); 
		    }
		    else
		    {   
			    rndRuleEn = (RNDRULE_ENUM) GET_ENUM(instrPtr,A_Instr_AiRoundRuleEn);
		    }

		    if (GET_ENUM(instrPtr, A_Instr_AiRoundUnitEn) == RndUnit_None)
		    {
			    rndUnitEn = (RNDUNIT_ENUM) GET_ENUM(currPtr, A_Curr_RoundUnitEn);
		    }
		    else
		    {
			    rndUnitEn = (RNDUNIT_ENUM) GET_ENUM(instrPtr, A_Instr_AiRoundUnitEn);
		    }

            if (freeFlag == TRUE) {FREE_DYNST(currPtr, A_Curr);}

		    round = TLS_RoundEnum(mktPtr->accrInter, rndUnitEn, rndRuleEn);
		    mktPtr->accrInter = round;

			/* REF9415 - RAK - 030821 - accrInter and accrInterRefCurr are same and in reference currency */
			round = TLS_RoundEnum(mktPtr->accrInterRefCurr, rndUnitEn, rndRuleEn);
		    mktPtr->accrInterRefCurr = round;
		}
		else
		{
		    /* In all cases the amount should be rounded */
		    mktPtr->accrInter = CAST_AMOUNT(mktPtr->accrInter, mktPtr->accrInterCurrId); 

			/* REF9415 - RAK - 030821 - accrInter and accrInterRefCurr are same and in reference currency */
		    mktPtr->accrInterRefCurr = CAST_AMOUNT(mktPtr->accrInterRefCurr, mktPtr->accrInterCurrId);
		}
		
		/* If accrued interest is not in reference currency, convert into the reference currency. */
		/* REF9415 - RAK - 030821 - Convert in reference currency on op date */
		/* if (mktPtr->accrInterCurrId != refCurrId)
		{
		   exchArgSt.srcAmt = mktPtr->accrInter;
		   if ((ret = FIN_ExchAmt(accrValEndDate,  mktPtr->accrInterCurrId, refCurrId,
				                  0, NULL, &exchArgSt,NULL, 
		                          &(mktPtr->accrInterRefCurr), 
			                      &(mktPtr->accrInterRefExch))) != RET_SUCCEED)
		   {
               FREE_DYNST(unitAccrInter, UnitInter);
	           if (allocOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
               if (firstCallFlg == TRUE) {DBA_FreeDynStTab(selPosTab, selPosNbr, A_Pos);}
               DBA_FreeDynStTab(flowTab, flowNbr, Flow);
			   return(ret);
		   }
		}
		else
		{
		    mktPtr->accrInterRefCurr = mktPtr->accrInter;
		    mktPtr->accrInterRefExch = 1.0;
		} */
	}

    FREE_DYNST(unitAccrInter, UnitInter);
    if (allocOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
    if (firstCallFlg == TRUE) {DBA_FreeDynStTab(selPosTab, selPosNbr, A_Pos);}
    DBA_FreeDynStTab(flowTab, flowNbr, Flow);
    /*lint --e{429} - REF7475 - YST - 020620 - free only needed for selPosTab when first call */
    return(RET_SUCCEED);  
}

/************************************************************************
**
**  Function    :   FIN_CmpPosForAccrVal()
**
**  Description :   Order positions for accrued valuation computation by ascending date
**                 
**  Arguments   :   ptr1 and ptr2 for comparison
**
**  Return      :   
**     a negative value if first element < second element
**     a null value     if first element = second element
**     a positive value if first element > second element
**
**  Creation    :   REF7265 - YST - 020529
**
*************************************************************************/
int FIN_CmpPosForAccrVal(void *arg1, void *arg2)
{
    DBA_DYNFLD_STP *ptr1 = (DBA_DYNFLD_STP *)arg1, *ptr2 = (DBA_DYNFLD_STP *)arg2;
    
    return(DATE_Cmp(GET_DATE((*ptr1), A_Pos_BegDate), GET_DATE((*ptr2), A_Pos_BegDate)));	
}

/************************************************************************
**
**  Function    :   FIN_GetLastCouponPeriod()
**
**  Description :   Get the Last Coupon period dates based on the last coupon date or 
**                  end date of the instrument.
**
**  Arguments   :   fromDateTime        refDateTime from Valuation
**                  tillDateTime        last_coupon_date or end_date of the instrument  
**                  valDateTime         valuation date                  
**                  instrPtr            pointer on instrument structure or NULL                  
**                  accrRule            accurRule from the instrument                
**                  hierHead            pointer on hierarchy
                    lastCouponBeginDate last coupon begin date from the cash flow
                    lastCouponEndDate   last coupon end date from the cash flow
**
**  Return      :   RET_SUCCEED            
**                  RET_GEN_INFO_NOACTION if no flows for the instrument
**                  or error code
**
**  Creation    :   PMSTA-37777 - Silpakal  - 191106
**
*************************************************************************/
RET_CODE FIN_GetLastCouponPeriod(DATETIME_T          fromDateTime,
                                 DATETIME_T          tillDateTime,
                                 DATETIME_T          valDateTime,
                                 DBA_DYNFLD_STP      instrPtr,
                                 ACCRRULE_ENUM       accrRule,                           
                                 DBA_HIER_HEAD_STP   hierHead,
                                 DATETIME_T          *lastCouponBeginDate,
                                 DATETIME_T          *lastCouponEndDate
)
{
    RET_CODE 	        ret = RET_SUCCEED;
    int		            currentPeriod = 0, allocSz = 0, i = 0;    
    DBA_DYNFLD_STP      *flowTab = NULL;
    int                 flowNbr = 0;

    if (IS_NULLFLD(instrPtr, A_Instr_LastCoupDate) == FALSE)
    {
        tillDateTime = GET_DATETIME(instrPtr, A_Instr_LastCoupDate);
    }
    else 
    {
        /*If the end_date of instrument is NULL then MAGIC_DATE is considered as a default end date */
        tillDateTime = GET_DATETIME(instrPtr, A_Instr_EndDate);
    } 

    /* Generate Income and Redemption flows for Bond */
    ret = SCE_CallBond_GenrCflw(fromDateTime, tillDateTime, instrPtr, accrRule,
                                &flowTab, &flowNbr, allocSz, &currentPeriod, (PTR)hierHead, FALSE);

    if (ret == RET_SUCCEED && flowNbr > 0)
    {
        for ( i = flowNbr-1; i >= 0; i--)
        {
            /* Check for the last income flow to fill last coupon begin and end date */
            if (FlowNat_Inc == (FLOWNAT_ENUM)GET_ENUM(flowTab[i], Flow_NatEn))
            {
                *lastCouponBeginDate = GET_DATETIME(flowTab[i], Flow_BegPayDate);
                *lastCouponEndDate = GET_DATETIME(flowTab[i], Flow_EndPayDate);
                break;
            }
        }
    }

    if (flowNbr > 0)
    {
        DBA_FreeDynStTab(flowTab, flowNbr, Flow);
        flowNbr = 0;
    }
    return ret;
}

/************************************************************************
**
**  Function    :   FIN_InstrPriceAtBenchmarkDate()
**
**  Description :   Get the instr price at benchmark date for Structure Products instrument category-
**                  Single, Average and Worst of the Instrument
**
**  Arguments   :   underlyInstrPtr                 underlying instrument
**                  benchmarkDT                     benchmark date
**                  hierHead                        pointer on hierarchy
**                  INSTR_UNDERLYING_CATEGORY_ENUM  instrument category
**                  posPtr                          position pointer
**                  price                           price of the Single, Average and Worst Instrument price
**                  compWorstInstr                  worst instrument
**
**  Return      :   RET_SUCCEED
**                  RET_GEN_INFO_NOACTION if no flows for the instrument
**                  or error code
**
**  Creation    :   PMSTA-35536 - Silpakal  - 191224
**
*************************************************************************/
RET_CODE FIN_InstrPriceAtBenchmarkDate(DBA_DYNFLD_STP       instrPtr,
                                       DATETIME_T           benchmarkDT,
                                       DBA_HIER_HEAD_STP    hierHead,
                                       INSTR_UNDERLYING_CATEGORY_ENUM instrUnderlyingCategory,
                                       PRICE_T              *price,
                                       DBA_DYNFLD_STP        compWorstInstr)
{
    int                 selInstrCompoNbr = 0, ret = RET_SUCCEED;
    DBA_DYNFLD_STP      *selInstrCompoTab = NULLDYNSTPTR, underPtr = nullptr, prPtr = nullptr;
    FIN_PRICEARG_ST	    priceArgSt;
    FLAG_T			    hierFlg;
    DbiConnectionHelper dbiConnHelper;
    MemoryPool          mp; 

    prPtr = mp.allocDynst(FILEINFO, A_InstrPrice);

    if (instrUnderlyingCategory == INSTR_UNDERLYING_CATEGORY_ENUM::SingleInstrument)
    {
        DBA_DYNFLD_STP	    getInstrPtr = mp.allocDynst(FILEINFO, S_Instr);
        DBA_DYNFLD_STP	    underlyInstrPtr = mp.allocDynst(FILEINFO, A_Instr);

        SET_ID(getInstrPtr, S_Instr_Id, GET_ID(instrPtr, A_Instr_UnderlyInstrId));
        if (dbiConnHelper.dbaGet(Instr, UNUSED, getInstrPtr, &underlyInstrPtr) != RET_SUCCEED)
            return(RET_DBA_ERR_NODATA);

        if ((ret = FIN_InstrPrice(GET_ID(underlyInstrPtr, A_Instr_Id), underlyInstrPtr,
                                  benchmarkDT, NULLDYNST, (ID_T)0, &priceArgSt, NULLDYNST,
                                  NULLDYNST, hierHead, prPtr, FALSE)) == RET_SUCCEED)
        {
            *price = GET_PRICE(prPtr, A_InstrPrice_Quote);
        }
    }
    else if (instrUnderlyingCategory == INSTR_UNDERLYING_CATEGORY_ENUM::AverageBasket)
    {
        PRICE_T initialBasketPrice = 0, averageBasketPrice = 0;

        ret = FIN_SelectUnderlyingCompo(hierHead, benchmarkDT, instrPtr, &selInstrCompoTab, &selInstrCompoNbr);

        if (ret == RET_SUCCEED)
        {
            mp.owner(selInstrCompoTab, selInstrCompoNbr);

            /* Get the Initial average price of the basket */
            for (int i = 0; i < selInstrCompoNbr; i++)
            {
                initialBasketPrice = initialBasketPrice + (GET_PRICE(selInstrCompoTab[i], A_InstrCompo_BasketExerPrice)*
                                     (GET_PERCENT(selInstrCompoTab[i], A_InstrCompo_BasketWeightP) / 100));
            }

            /* Get the average price of the basket on benchmark date */
            for (int i = 0; i < selInstrCompoNbr; i++)
            {
                ret = FIN_GetHierInstr(hierHead, GET_ID(selInstrCompoTab[i], A_InstrCompo_InstrId), (char*)&hierFlg, &underPtr);

                if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
                {
                    return(ret);
                }                

                if ((ret = FIN_InstrPrice(GET_ID(underPtr, A_Instr_Id), underPtr,
                                          benchmarkDT, NULLDYNST, (ID_T)0, &priceArgSt, NULLDYNST,
                                          NULLDYNST, hierHead, prPtr, FALSE)) == RET_SUCCEED)

                if (ret == RET_SUCCEED)
                    averageBasketPrice = averageBasketPrice + (GET_PRICE(prPtr, A_InstrPrice_Quote)* (GET_PERCENT(selInstrCompoTab[i], A_InstrCompo_BasketWeightP) / 100));
            }

            *price = GET_PRICE(instrPtr, A_Instr_ExerQuote) * (averageBasketPrice / initialBasketPrice);
        }
    }
    else if (instrUnderlyingCategory == INSTR_UNDERLYING_CATEGORY_ENUM::WorstOfBasket)
    {
        DBA_DYNFLD_STP  worstInstrPtr = NULL;
        FLAG_T          allocOk = FALSE;

        if ((ret = DBA_GetInstrById(GET_ID(compWorstInstr, A_InstrCompo_InstrId), FALSE, &allocOk,
                                    &worstInstrPtr, hierHead, UNUSED, UNUSED)) != RET_SUCCEED)
        {            
            if (allocOk == TRUE) 
            { 
                FREE_DYNST(worstInstrPtr, A_Instr);
            }
            return(FALSE);
        }
        
        if ((ret = FIN_InstrPrice(GET_ID(worstInstrPtr, A_Instr_Id), worstInstrPtr,
                                  benchmarkDT, NULLDYNST, (ID_T)0, &priceArgSt, NULLDYNST,
                                  NULLDYNST, hierHead, prPtr, FALSE)) == RET_SUCCEED)            
        {
            *price = GET_PRICE(prPtr, A_InstrPrice_Quote);
        }

        if (allocOk == TRUE) 
        { 
            FREE_DYNST(worstInstrPtr, A_Instr);
        }  
    }
    return ret;
}

/************************************************************************
**      END  finai.c                                            UNICIBLE
*************************************************************************/

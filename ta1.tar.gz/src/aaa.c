/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/* Added to test new version of advgetln and advdeltaln  */

/************************************************************************
**      Warning set disable
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define AAA_C

#define STDIO_H
#define STRING_H
#define TIME_H
#define STDLIB_H

#ifdef NTWIN
#pragma warning(disable:4512)   /* To remove warning C4512: 'QMutexData' : assignment operator could not be generated / PMSTA-23902 - 290616 - PMO */
#endif

/************************************************************************
**      Include files
*************************************************************************/
#ifdef NTWIN
#define PSAPI_VERSION 1     /* PMSTA-16443 - 230713 - PMO */
#include <windows.h>        /* REF8728 - 030311 - PMO */
#include <psapi.h>          /* PMSTA-16443 - 230713 - PMO */
#include "sysnt.h"          /* REF7264 - PMO */
#endif

#include "QCoreApplication" /* PMSTA-20235 - CHU - 150421 */

#include "unidef.h"     /* Mandatory */
#include "main.h"

#ifndef DBA_H
#include "dba.h"
#endif

#ifndef SYSLIB_H
#include "syslib.h"     /* Necessary for FREE  PMO - Rename our sys.h to syslib.h and use it */
#endif

#include "sig.h"

#include "ddlgen.h" /* PMSTA-13122 - LJE - 120516 */
#include "crypto-openssl.h"
#include "passstorefilemanager.h"


#ifndef CALLSTACK_H
#include "callstack.h"
#endif

#ifdef AAAPURIFY
#ifdef SOLARIS
#include /**/ <pure_threads.h>
#endif
#endif

#ifdef AAAPURIFY
#include "pure.h"
#endif

#include "aaalogger.h"
#include "aaatelemetry.h"

#ifdef NTWIN
char    SV_KeywordNT[64];
char    SV_UserPrefix[MAX_USERINFO_LEN + 1];         /* HFI-PMSTA-27422-170531   */
char    SV_Display[50];
#pragma warning(default:4512)
#endif

extern TIMER_STP EV_ExtractFileTimerPtr;    /* REF7264 - PMO */

extern char    SV_FlgLoginPassed; /* PMSTA-CARG - DDV - 130426 - No more static, they can be during cfg file load */
extern char    SV_User       [MAX_USERINFO_LEN +1];

char     SV_ServerLogFileName[256];

extern	void	MSG_InitLogFileName(const char*);
extern	bool    EV_ICUContextStatic; /* PMSTA-13122 - LJE - 120604 */
extern  int     EV_AAAInstallLevel;

int     SV_ServerMode,
        SV_ServerInitFlg = 0;

CODE_T          EV_DbTimeZoneCd="";

#ifdef NTWIN
/************************************************************************
**
**  Function    :   WIN_GetDataSegmentSize()
**
**  Description :   Return the total memory allocated in kb for Windows
**                  I put the function here in place of the expected
**                  os_win.c because the call of GetProcessMemoryInfo
**                  involve the library psapi.lib.
**                  Since the function is called only by the server and the GUI,
**                  it is pitty to link all projects with this library
**
**  Argument    :
**
**  Return      :   Memory allocated in kb
**
**  Last modif. :   PMSTA-16443 - 230713 - PMO : Add confirmation-to-continue messages in case not enough free memory is available for the GUI when loading data from a financial server
**
*************************************************************************/
size_t WIN_GetDataSegmentSize()
{
    PROCESS_MEMORY_COUNTERS_EX  psmemCountersEx;
    size_t                      size                = 0;

    if (TRUE == GetProcessMemoryInfo(GetCurrentProcess(), (PPROCESS_MEMORY_COUNTERS)&psmemCountersEx, sizeof(psmemCountersEx)))
    {
        size = psmemCountersEx.PrivateUsage >> 10;
    }

    return size;
}

#endif

/************************************************************************
**
**  Function    :   mainExceptionHandling()
**
**  Description :   Called by application entry point. Low level initialization and Exception intercepting
**
**  Arguments   :   argc  parameters number
**                  argv  parameters list (first is application)
**
**  Return      :   0 if ok
**                  >0 if error
**
**  Last modif. :   PMSTA-19735 - 020415 - PMO : OpenServer / P1 / Thread handling
**
*************************************************************************/
int mainExceptionHandling(int argc, char *argv[])
{
    int ret = EXIT_SUCCESS;

#ifndef _DEBUG
    try
    {
#endif
        initCallback();

		if (true == SYS_CreateMainThreadDataStorage())
        {
            ret = mainTripleA(argc, argv);
        }
        else
        {
            ret = EXIT_FAILURE;
        }
#ifndef _DEBUG
    }
    catch (...)
    {
        if (SYS_IsStateLoggingAllowed())                    /* PMSTA-36212 - 160719 - PMO */
        {
            exceptionHandler(FILEINFO, MSG_SendMesg);
        }
        else
        {
            exceptionHandler(FILEINFO, MSG_SendStderr);     /* PMSTA-36212 - 160719 - PMO */
        }
    }
#endif

    return ret;
}

/************************************************************************
**
**  Function    :   MAIN_AnalyseParam()
**
**  Description :   Analyze parameters received on application call
**
**  Arguments   :   argc  parameters number
**                  argv  parameters list (first is application)
**
**  Return      :   RET_SUCCEED or error code
**
**  Last modif. :   PMSTA-7003 - 080808 - PMO : Fusion test like TDDJ
**                  PMSTA-18094 - 130514 - PMO : Avoid extracting the user credentials from the GUI running on Windows (via dump, etc.)
**                  PMSTA-21017 - 251015 - PMO : General small fix
**                  PMSTA-24510 - 220816 - PMO : Fusion & Dispatcher in HTTP
**
*************************************************************************/
FLAG_T MAIN_AnalyseParam(int argc, char *argv[])
{
    char    *p = NULL, nextArgv=0;

    *SV_User  = END_OF_STRING;                      /* PMSTA-18094 - 130514 - PMO */
#ifdef NTWIN
    SV_KeywordNT[0]  = END_OF_STRING;               /*  HFI-PMSTA-26560-171001  */
#endif
    EV_Server = "";                                 /* PMSTA-24510 - 220816 - PMO */

    SV_ServerLogFileName[0] = END_OF_STRING;	/* REF1038 - GRD - 971103. */

    /* For all parameters */
    for (int i=1; i<argc ; i++)
    {
        if (!nextArgv && *argv[i] == '-')
        {
            if(argv[i][2] == END_OF_STRING)
            {
                nextArgv = argv[i][1];

                    /* 2 possibilities: (DVP273 GRD).
                       The parameter is incomplete.
                       The parameter is stand alone. */
                if (nextArgv == 'W')
                    EV_WarningMsg = TRUE;   /* Display warning messages. */
                else if (nextArgv == 'I') /* PMSTA-30135 CMILOS 140219 */
                {
                    if (SYS_IsGuiMode())
                        EV_InternalAddress = TRUE;
                    break;
                }
                /*  FIH-990413-REF2336  */
                else if (nextArgv == 'v')
                {
                    GEN_AnalyseVersion(nextArgv);		/* REF3824 - 990719 - DED */
                    SYS_Shutdown(EXIT_SUCCESS);
                }
                else if (nextArgv == 'V')
                    GEN_AnalyseVersion(nextArgv);		/* REF3824 - 990719 - DED */
                else if (nextArgv == 'S')
                {
                    p = NULL;
                    GEN_SetApplInfo(ApplServerName, EV_Server); /* PMSTA-24510 - 220816 - PMO */
                }
                else
                    continue;               /* Incomplete parameter. */
            }
            else    p = &argv[i][2];
        }
        else
        {
            p = argv[i];

            /* Avoid to read outside the memory with *(p-1)   PMSTA-21017 - 251015 - PMO */
            if (0 == nextArgv)
            {
                continue;
            }
        }

        switch((nextArgv)?nextArgv:*(p-1))
        {
        /* PMSTA-CARG - DDV - 130426 - New argument to load information from cfg file (DSQUERY/AAALOGINDB/user/password/ . . . ) */
        case 'C':
                SYS_LoadCfgFile(p);
                break;

		case 'U' :
                SV_FlgLoginPassed = TRUE;
                strcpy(SV_User, p);
                SYS_SetThreadUser(SV_User);
                break;

		case 'P':
			{
				PasswordEncrypted pE;
				pE.setClearPassword(PasswordClear(p));
				GEN_SetUserInfo(UserPasswd, &pE);
                SYS_SetThreadPassword(pE);
				break;
			}

		case 'S' :
                if (p)
                {
                    EV_Server = p;  /* PMSTA-24510 - 220816 - PMO */
                }

                break;
        case 'L' :
                strcpy(SV_ServerLogFileName, p);
                break;
#ifdef NTWIN
        case 'K' :
                strcpy(SV_KeywordNT, p);  // FME Used only in the GUI (Registery key lookup addition) (can never be set in import or aaa_sql
                break;
#endif
        case 'E' :
                EV_TimerMask = TIMER_MASK_GEN;
                strcpy(EV_ExtractFileName, p);
                EV_ExtractFile = SYS_Fopen(EV_ExtractFileName, "a");
                DATE_ResetTimer(EV_ExtractFileTimerPtr, TIMER_MASK_GEN);
                DATE_StartTimer(EV_ExtractFileTimerPtr, TIMER_MASK_GEN);
                break;
#ifdef NTWIN
        case 'd' :
                if(strcmp(p,"isplay")==0 && (i+1)<argc)
                    sprintf(SV_Display,"%s",argv[i+1]);
                break;
#endif

        /* Le nom du fichier log est fourni */
        case 'O' :
                MSG_InitLogFileName(p);
                break;

        /* REF11026 - LJE - 050211 */
        case 'D' :
                printf("%s\n- SQL Dump server do not exists anymore... ", Console::ColorizeError("ko").c_str());
                exit(2);

                break;

        case 'G':  /* PMSTA-11505 - LJE - 110611 - Generate DDL objects */
            EV_GenDdlContext.infoPtr = (char*)CALLOC(strlen(p) + 1, sizeof(char));
            strcpy(EV_GenDdlContext.infoPtr, p);

            if (strcmp(p, "c") == 0)
            {
                EV_AAAInstallLevel = 100;
            }
            else if (strcmp(p, "q") == 0)
            {
                EV_AAAInstallLevel = 2;
            }
            break;

        case 'o':  /* PMSTA-11505 - LJE - 110611 - Generate DDL objects */
            EV_GenDdlContext.objPtr = (char*)CALLOC(strlen(p) + 1, sizeof(char));
            strcpy(EV_GenDdlContext.objPtr, p);
            break;

        case 'i':  /* PMSTA-11505 - LJE - 110611 - Generate DDL objects */
            EV_GenDdlContext.inputPtr = (char*)CALLOC(strlen(p) + 1, sizeof(char));
            strcpy(EV_GenDdlContext.inputPtr, p);
            break;

        case 'X':  /* PMSTA-14086 - LJE - 121003 */
            EV_GenDdlContext.optionPtr = (char*)CALLOC(strlen(p) + 1, sizeof(char));
            strcpy(EV_GenDdlContext.optionPtr, p);

            for (size_t j = 0; j < strlen(EV_GenDdlContext.optionPtr); j++)
            {
                if (EV_GenDdlContext.optionPtr[j] == 'c')
                {
                    EV_GenDdlContext.bCheck = true;
                }
            }

            break;
#ifdef NTWIN
        case 'B' :  /*  Masked Prefix for GUI logging       */  /*  HFI-PMSTA-27422-170531  */
                strcpy(SV_UserPrefix, p);
                break;
#endif
        case 'c' :  /*  Business Entity as input parameter  */  /*  HFI-PMSTA-26560-170806  */
                SYS_GetThread().setCurrBusinessEntity(p);
                break;

        case 'n':  /* PMSTA-41113 - KNI - 310820 */
        {
            if (!SERVER_MODE())
            {
                std::string dbServiceName = DBI_GetSqlServerName(std::string(SYS_GetoptArg()));
            }
            break;
        }
        }

        nextArgv = 0;
    }
#ifdef AIX
    if (argc > 1)
        *argv[1] = '\0';
#endif

    if (EV_WarningMsg == TRUE)
    {
        SYS_PutEnv("AAALOGTHRESHOLD", "WARNING");
    }
    else
    {
        SYS_PutEnv("AAALOGTHRESHOLD", "ERROR");
    }

    PasswordEncrypted * pE = nullptr;
    GEN_GetUserInfo(UserPasswd, &pE);


    if (SYS_IsSrvMode() || SYS_IsDdlGenMode())
    {
        EV_OptiMemFlg = TRUE; /* PMSTA-51666 - DDV - 240122 - Reactivate optimizations */

        if (*SV_User && (pE->isValidPassword() == false))
        {
            RET_CODE retCode=SYS_AutoLogin(SV_User, *pE);

            if(retCode != RET_SUCCEED &&
                retCode != RET_SRV_LIB_ERR_INVALID_PASSWORD)
                return FALSE;

            if (retCode == RET_SUCCEED && 
                strlen(pE->getPassword()) != 0)
            {
                GEN_SetUserInfo(UserPasswd, pE);
            }
            else
            {
                SYSNAME_T pwd;
                AUTO_PASSWORD_CLEAR(pwd, sizeof(pwd));
                SYS_GetPassword("Password", pwd, MAX_USERINFO_LEN + 1, 0);
                pE->setClearPassword(PasswordClear(pwd));
                GEN_SetUserInfo(UserPasswd, pE);
            }
        }
    }

    SYS_SetThreadPassword(*pE);

    if (SYS_IsDdlGenMode() && EV_GenDdlContext.infoPtr == nullptr)
    {
        fprintf(stderr, "Msg Error - Wrong parameters, the parameter \"-G\" is mandatory for DDL generator\n");
        return FALSE;
    }

    return TRUE;
}

#ifdef NTWIN
#pragma warning(disable:4189)
#endif

/************************************************************************
**
**  Function    :   mainTripleA
**
**  Description :   application entrypoint
**                  executable accepts parameters
**                  -Uusername or -U username
**                  -Ppassword or -P Password
**                  -Sserver or -S Server
**                  -display DISPLAY
**                  -W
**
**  Arguments   :   argc   arguments number
**                  argv   arguments list
**
**  Return      :   none
**
**  Modif.      :   ROI - 970318 - DVP388
**                  GRD - 971103 - REF1038.
**                  FIH - 980306 - REF064
**                  ROI - 980317 - REF1447
**                  REF9165 - 030610  - PMO : Display the call stack
**                  REF10380 - 041124 - EFE : Stack size problem with HPUX when creating threads
**                                            the new stck size value must be multiple of 8192
**                  PMSTA-9107 -141209 - PMO : Fix visual C++ 2008 issues
**                  PMSTA-16443 - 230713 - PMO : Add confirmation-to-continue messages in case not enough free memory is available for the GUI when loading data from a financial server
**                  PMSTA-18094 - 130514 - PMO : Avoid extracting the user credentials from the GUI running on Windows (via dump, etc.)
**                  PMSTA-18893 - 101114 - PMO : Core dump during precomp on instrument
**                  PMSTA-19736 - 030315 - PMO : OpenServer, Client / P1 / Locking
**                  PMSTA-19735 - 020415 - PMO : OpenServer / P1 / Thread handling
**                  PMSTA-20089 - 120515 - PMO : Unification of code for mono-threaded (static variable context) and multi-threaded (thread local variable).
**                  PMSTA-19737 - 270516 - PMO : OpenServer HTTP & HTTPS server (include POC already done)
**                  PMSTA-24510 - 220816 - PMO : Fusion & Dispatcher in HTTP
**                  PMSTA-25236 - 231116 - PMO : Remove AAACORE environment variable handling
**                  PMSTA-30823 - 050418 - PMO : SCPT_FmtEltAnalyse: Source and destination overlap in mempcpy
**                  PRO-7103 - 280818 - PMO : Provide libraries log4cplus on different platforms
**                  PMSTA-34824 - 210219 - PMO : Regression: several core file generated while running the TaAutomator night batch (HttpConnectionHandler)
**
*************************************************************************/
int mainTripleA(int argc, char *argv[])
{
    AAALogger::Initializer loggerInitialiser;                /* PMSTA-32895 - 140918 - FME Cluster Logger */

    AaaMetaDict::load();

    /* PMSTA-26108 - LJE - 171028 - Init */
    CURRENTCHARSETCODE_ENUM defCurrCharSetEn = CurrentCharsetCode_IsNull;
    GEN_SetApplInfo(ApplCurrentCharsetCodeEnum, &defCurrCharSetEn);

    GEN_SetApplInfo(ApplSqlServerName, "");
    GEN_SetApplInfo(ApplSqlDbName, "");

    char *      noBufParam = NULL;
    int         noBufValue;
    MemoryPool  mp;

    OpenSSLProvider::setup();
    PasswordEncrypted::setup(SYS_GetIt);

    if ((noBufParam = SYS_GetEnv("AAANOSTDOUTBUF")) != NULL)
    {
        noBufValue = atoi(noBufParam);
        if (noBufValue == 1)
            setbuf(stdout, NULL);
    }

#ifdef AAAPURIFY
#ifdef NTWIN

    PurifyPrintf("Starting...");
#endif
#endif

#ifdef AAAQUANTIFY
#ifdef NTWIN
    QuantifyAddAnnotation("Starting...");
#endif
#endif

    EV_ServerMode = &SV_ServerMode;
    EV_ServerInitFlg = &SV_ServerInitFlg;
    EV_OptiMemFlg = FALSE;
    EV_TestNewScpt = 1;
    EV_GuiActivatedFlg = 0;
    SV_ServerMode = FALSE;
    EV_WarningMsg = FALSE;  /* By default, do not display warning messages. (GRD). */

    /* REF9165 - 030610 - PMO */
    SYS_InitCallStack();
    atexit(SYS_RemoveCallStack);

    /* Initialize the locks table
    * PMSTA-19736 - 030315 - PMO
    */
    if (SYS_InitLockTable() != TRUE)
    {
        MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "SYS_InitLockTable() failed");
        return(1);
    }

    /* PMSTA00450 - RAK - 060914 - TRACE AAACHECKSTRATLIGHTTRACE */
    if (SYS_GetEnv("AAACHECKSTRATLIGHTTRACE") != NULL)
    {
        EV_CheckStratFlg = TRUE;
    }
    else
    {
        EV_CheckStratFlg = FALSE;
    }

    /* PMSTA-16443 - 230713 - PMO */
#ifdef NTWIN
    OS_SetDataSegmentSize(WIN_GetDataSegmentSize);
#endif
    DBA_SetGetDataSegmentSize(OS_GetDataSegmentSize);

    /* Parameter Analyse */
    char *hideArgsFlg = NULL, *startupParam = NULL;

    /* REF9136 - RAK - 030605 */
    /* Read arguments in environment variable according to HIDE_ARGS value */
    if ((hideArgsFlg = SYS_GetEnv("HIDE_ARGS")) != NULL &&
        strcmp(hideArgsFlg, "1") == 0 &&
        (startupParam = SYS_GetEnv("AAA_STARTUP_PARAMS")) != NULL)
    {
        int		argNbr = 0;
        char	**argTab = NULL;

        /* Cut startupParam in argNbr and copy in argTab */
        int ok = GEN_TreatStartupParams(startupParam, argv, &argNbr, &argTab, mp);  /* PMSTA-21017 - 251015 - PMO */

        /* Send created argTab to AnalyseParam */
        if (TRUE == ok)
        {
            ok = MAIN_AnalyseParam(argNbr, argTab);
        }

        if (FALSE == ok)
        {
            return(1);
        }
    }
    else if (MAIN_AnalyseParam(argc, argv) == FALSE)
        return(1);

#ifdef NTWIN
    NT_Init(AAAVersion::getVersion().getVersionCode().c_str(), AAAVersion::getVersion().getFixCode().c_str(), SV_KeywordNT);
#endif

    GEN_InitApplName();                                         /* PMSTA-32895 - 140918 - FME Cluster Logger */
    
    // Telemetry Init after appl name initialisation
    AAATelemetry::Initializer telemetryInitializer(/*startByDefault*/false);   /* PMSTA-54809 - 20231023 - FME Opentelemetry Log4cplus log appender */

    bool startWatcherThread = false;
    if (SYS_IsSrvMode())
        startWatcherThread = true;

    loggerInitialiser.configure(startWatcherThread);             /* PMSTA-32895 - 140918 - FME Cluster Logger */
    telemetryInitializer.configure();                            // @TODO FME verify if this is the correct place

    GEN_DisplayEnv(); /* PMSTA08801 - DDV -100219 - Improve loading of environment from registry */

    if (SYS_IsSrvMode() || SYS_IsDdlGenMode())
    {
        SV_ServerMode = TRUE;
        GEN_SetApplInfo(ApplServerMode, &SV_ServerMode);
    }

    int appRetCode = mainTripleAProgram(argc, argv);

    SYS_Shutdown(APP_EXIT);

    return appRetCode;
}

#ifdef NTWIN
#pragma warning(default:4189)
#endif

/************************************************************************
**      END          aaa.c
*************************************************************************/

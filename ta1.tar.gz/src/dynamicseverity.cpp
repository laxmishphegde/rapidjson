﻿
/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/
#ifndef DYNAMICSEVERITY_H
#include "dynamicseverity.h"
#endif
#include <cmath>
#include "descdyn.h"
#include "dbiconnection.h"
#include <utility>

/************************************************************************
*
*   Function      :  FIN_AddPortfolioProcessHistory
**  Description   :  store checkStrat data in portfolio_process_history
                    to find the case

**  Arguments     : DBA_DYNFLD_STP domainPtr, DBA_DYNFLD_STP ptfPtr
**
*
*   Return        :  TRUE or FALSE
*
*   Creation Date :   PMSTA-47502-Lalby-18042022
*************************************************************************/

RET_CODE FIN_AddPortfolioProcessHistory(DBA_DYNFLD_STP domainPtr, DBA_DYNFLD_STP ptfPtr)
{
    RET_CODE ret = RET_SUCCEED;

    DbiConnectionHelper  dbiConnHelper;
    if (dbiConnHelper.isValidAndInit() == false)
    {
        return RET_DBA_ERR_CONNOTFOUND;
    }

    DBA_DYNFLD_STP portfProcessHisPtr = NULLDYNST;
    MemoryPool      mp;
 
    if ((portfProcessHisPtr = mp.allocDynst(FILEINFO, A_PortfolioProcessHistory)) != NULLDYNST)
    {
        COPY_DYNFLD(portfProcessHisPtr, A_PortfolioProcessHistory, A_PortfolioProcessHistory_BeginDate,
            domainPtr, A_Domain, A_Domain_InterpFromDate);

        COPY_DYNFLD(portfProcessHisPtr, A_PortfolioProcessHistory, A_PortfolioProcessHistory_EndDate,
            domainPtr, A_Domain, A_Domain_InterpTillDate);

        COPY_DYNFLD(portfProcessHisPtr, A_PortfolioProcessHistory, A_PortfolioProcessHistory_SessionId,
            domainPtr, A_Domain, A_Domain_FctResultId);

        COPY_DYNFLD(portfProcessHisPtr, A_PortfolioProcessHistory, A_PortfolioProcessHistory_PtfId,
            ptfPtr, A_Ptf, A_Ptf_Id);

        //update with correct status?
        SET_ENUM(portfProcessHisPtr, A_PortfolioProcessHistory_StatusEn, FCTRESULTSTATUS_ENUM::FctResultStatus_Final);

        COPY_DYNFLD(portfProcessHisPtr, A_PortfolioProcessHistory, A_PortfolioProcessHistory_LoadHierFlg,
            domainPtr, A_Domain, A_Domain_LoadHierFlg);

        ret = dbiConnHelper.dbaInsert(PortfolioProcessHistory, UNUSED, portfProcessHisPtr);
    }

    return ret;
}

/************************************************************************
*   Function       : FIN_Filter Functions
*   Description    : Filter function for to get the caselink for the ESE
*  Arguments       : dynSt         link record
*                    dynStTp       dySt type
*                    inEsePtr      ESE  
*   Return         : true if record match
*   Creation       :  06072022
*************************************************************************/
STATIC int FIN_FilterForCaseLink(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP inEsePtr)
{
    if ( (IS_NULLFLD(inEsePtr, ExtStratElt_Id)== FALSE) && 
         GET_ID(dynSt, A_CaseLink_EntDictId) == EStratEltCst &&
         GET_ID(dynSt, A_CaseLink_Id) <0 &&
         CMP_DYNFLD(dynSt, inEsePtr, A_CaseLink_ObjId, ExtStratElt_Id, IdType) == 0)
    {
        return TRUE;
    }
    return FALSE;
}

/************************************************************************
*   Function       : FIN_Filter Functions
*   Description    : Filter function for to get the old case for the caseLink
*  Arguments       : dynSt         link record
*                    dynStTp       dySt type
*                    inEsePtr      ESE
*   Return         : true if record match
*   Creation       :  06072022
*************************************************************************/
STATIC int FIN_FilterForCase(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP inCasePtr)
{
    if ((IS_NULLFLD(inCasePtr, A_CaseManagement_BusIdentifier) == FALSE) &&
        GET_ID(dynSt, A_CaseManagement_Id) > 0 && // get old case only from the hierarchy
        CMP_DYNFLD(dynSt, inCasePtr, A_CaseManagement_BusIdentifier, A_CaseManagement_BusIdentifier, String2000Type) == 0)
    {
        return TRUE;
    }
    return FALSE;
}

/************************************************************************
*
*   Function      : FIN_getCaseFromCaseManagement
**  Description   : By matching on the below attributes and the business identifier field
                    identify the corresponding case in the case_management entity
                    portfolio_process_history	case_management
                    session_id,portfolio_id,load_hierarchy_f ( filter applied in the proc)

**  Arguments     : DBA_DYNFLD_STP domainPtr, DBA_DYNFLD_STP ptfPtr
**                  Out - ptfProcessHistory
*
*   Return        :  TRUE or FALSE
*
*   Creation Date :   PMSTA-47502-Lalby-18042022
*************************************************************************/
RET_CODE FIN_GetCaseFromCaseManagement(DBA_HIER_HEAD_STP stratHierPtr, DBA_DYNFLD_STP domainPtr,
    DBA_DYNFLD_STP ptfPtr, DBA_DYNFLD_STP extStratElt, DBA_DYNFLD_STP *oldCasePtr,
    DBA_DYNFLD_STP *curentCasePtr)
{
    RET_CODE	ret = RET_SUCCEED;
    DBA_DYNFLD_STP    *caseManagementTab;
    int               caseManagementNbr = 0;
    DBA_DYNFLD_STP    *caseLinkTab;
    int               caseLinkNbr = 0;

    /* 1: get the current flow caselink for the current ESE */
    if ((ret = DBA_ExtractHierEltRecWithFilterSt(stratHierPtr, A_CaseLink, FALSE,
        FIN_FilterForCaseLink, extStratElt, NULLFCT, &caseLinkNbr, &caseLinkTab)) != RET_SUCCEED ||
        caseLinkNbr <= 0)
    {
        return(ret);
    }

    MemoryPool   mp;
    mp.owner(static_cast<void *> (caseLinkTab));

    /* 2: Get case record for the corresponding case link - caseId */
    DBA_DYNFLD_STP   caseManagementPtr = NULLDYNSTPTR;
    if (DBA_GetRecPtrFromHierById(stratHierPtr,
        GET_ID(caseLinkTab[0], A_CaseLink_CaseId),
        A_CaseManagement,
        &caseManagementPtr) != RET_SUCCEED && caseManagementPtr == NULLDYNSTPTR)
    {
        return ret;
    }

    /* 3 : Get old generated case from case management , by comparing business identifier field*/
    if ((ret = DBA_ExtractHierEltRecWithFilterSt(stratHierPtr, A_CaseManagement, FALSE,
        FIN_FilterForCase, caseManagementPtr, NULLFCT, &caseManagementNbr, &caseManagementTab)) != RET_SUCCEED ||
        caseManagementNbr <= 0)
    {
        return(ret);
    }

     mp.owner(static_cast<void *> (caseManagementTab));

    *oldCasePtr = caseManagementTab[0];
    *curentCasePtr = caseManagementPtr;

    return ret;
}

/************************************************************************
*
*   Function      :  FIN_SeverityRuleMakeHierLnk
**  Description   :  create link for the
                    severity_rule_link->severityrule
                    severity_rule -> severity_rule_element

**  Arguments     : DBA_HIER_HEAD_STP stratHierPtr
**
*
*   Return        :  TRUE or FALSE
*
*   Creation Date :   PMSTA-47502-Lalby-04032022
*************************************************************************/

RET_CODE FIN_SeverityRuleMakeHierLnk(DBA_HIER_HEAD_STP stratHierPtr)
{
    RET_CODE	ret = RET_SUCCEED;
    if ((ret = DBA_SetHierLnkUsed(stratHierPtr, A_SeverityRule,
        A_SeverityRule_SeverityRuleElem_Ext)) != RET_SUCCEED)
        return(ret);

    DBA_MakeSpecRecLinks(stratHierPtr, A_SeverityRule,
        A_SeverityRule_SeverityRuleElem_Ext);

    if ((ret = DBA_SetHierLnkUsed(stratHierPtr, A_SeverityRuleLink,
        A_SeverityRuleLink_SeverityRule_Ext)) != RET_SUCCEED)
        return(ret);

    DBA_MakeSpecRecLinks(stratHierPtr, A_SeverityRuleLink,
        A_SeverityRuleLink_SeverityRule_Ext);

    return  RET_SUCCEED;
}

/************************************************************************
*
*   Function      :  FIN_MarkLinkedRules
**  Description   :  mark A_SeverityRule_linkedRuleFlag in severity rule 
                     by refering the severity rule link
                     this will help to rule identification

**  Arguments     : DBA_HIER_HEAD_STP stratHierPtr
**
*
*   Return        :  TRUE or FALSE
*
*   Creation Date :   PMSTA-47502-Lalby-04062022
*************************************************************************/

RET_CODE FIN_MarkLinkedRules(DBA_HIER_HEAD_STP stratHierPtr)
{
    RET_CODE	ret = RET_SUCCEED;
    DBA_DYNFLD_STP    *linkedseveRuleTab;
    int               linkedseveRuleTabNbr = 0;
    MemoryPool      mp;

    if ((ret = DBA_ExtractHierEltRec(stratHierPtr, A_SeverityRuleLink, FALSE, NULLDYNST, NULLDYNST,
        &linkedseveRuleTabNbr, &linkedseveRuleTab)) != RET_SUCCEED || linkedseveRuleTabNbr <=0 )
    {
        return(ret);
    }

    mp.owner(static_cast<void *> (linkedseveRuleTab));

    for (int i = 0; i < linkedseveRuleTabNbr; ++i)
    {
        DBA_DYNFLD_STP severityRulePtr = NULLDYNST;
        if (GET_EXTENSION_PTR(linkedseveRuleTab[i], A_SeverityRuleLink_SeverityRule_Ext) != NULL &&
            (severityRulePtr = *(GET_EXTENSION_PTR(linkedseveRuleTab[i], A_SeverityRuleLink_SeverityRule_Ext))) != NULLDYNST)
        {
            DBA_DYNFLD_STP    *severityRuleTab;
            int               severityRuleNbr = 0;

            severityRuleTab = GET_EXTENSION_PTR(linkedseveRuleTab[i], A_SeverityRuleLink_SeverityRule_Ext);
            severityRuleNbr = GET_EXTENSION_NBR(linkedseveRuleTab[i], A_SeverityRuleLink_SeverityRule_Ext);

            if (severityRuleNbr > 0 && NULLDYNST != severityRuleTab[0])
            {
                SET_FLAG(severityRuleTab[0], A_SeverityRule_linkedRuleFlag, TRUE);
            }
        }
    }

    return ret;
}


/************************************************************************
*
*   Function     :  FIN_IsComplaint()
*
**  Description  :  check strat element is complaint or not    
*                    ext_strategy_element.strat_check_e = 2 {at least one Objective or Constraint is not compliant
                    ext_strategy_element.substrat_check_e =2 {at least one Objective or Constraint is not compliant
*
**  Arguments     :  stratHierHead,FIN_PTFINFO_STP,domainPtr
**                  
*
*   Return        :   RET_SUCCEED or FALSE (if non complaint)
*
*   Creation Date :   PMSTA-47502-Lalby-04032022 
*************************************************************************/

RET_CODE FIN_IsComplaint(DBA_HIER_HEAD_STP  stratHierHead, FIN_PTFINFO_STP  ptfInfoStp, DBA_DYNFLD_STP  domainPtr)
{
    RET_CODE ret = RET_SUCCEED;

    if (ptfInfoStp == NULLDYNST || ptfInfoStp->ptfPtr == NULLDYNST)
    {
        return ret;
    }
    DBA_DYNFLD_STP    *extStratEltTab = NULL;
    int extStratEltNbr;
    MemoryPool      mp;

    if ((ret = DBA_ExtractHierEltRecByIndexKey(stratHierHead,
        ExtStratElt,
        ExtStratElt_PtfId,
        *(ptfInfoStp->ptfPtr),
        FALSE,
        NULL,
        NULL,
        NULL,
        FALSE,
        &extStratEltNbr,
        &extStratEltTab)) != RET_SUCCEED)
    {
        FREE(extStratEltTab);
        return(ret);
    }

    mp.owner(static_cast<void *>(extStratEltTab));

    for (int i = 0; i < extStratEltNbr; i++)
    {
        if (GET_ENUM(extStratEltTab[i], ExtStratElt_StratCheckEn) == StratCheck_NotChecked ||
            GET_ENUM(extStratEltTab[i], ExtStratElt_SubstratCheckEn) == StratCheck_NotChecked)
        {
            return (ret = FALSE);
        }
        else if (FIN_GetFirstCheckEnNotNone(extStratEltTab[i]) == StratCheck_NotChecked)  //parent 
        {
            return (ret = FALSE);
        }
    }
    return ret;
}

/************************************************************************
*
*   Function       : FIN_Filter Functions
*
*   Description    : Filter function
*
*  Arguments       : dynSt         link record
*                    dynStTp       dySt type
*                    inPtfPtr
*
*   Return         :
*
*   Creation       :
*
*************************************************************************/

STATIC int FIN_FilterForPtf(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP inPtfPtr)
{
    if (GET_ID(dynSt, A_SeverityRuleLink_LinkedEntityDictId) == PtfCst &&
        CMP_DYNFLD(dynSt, inPtfPtr, A_SeverityRuleLink_ObjId, A_Ptf_Id, IdType) == 0)
    {
        return TRUE;
    }
    return FALSE;
}

STATIC int FIN_FilterForPtfList(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP inPtfPtr)
{
    if (GET_ID(dynSt, A_SeverityRuleLink_LinkedEntityDictId) == ListCst &&
        CMP_DYNFLD(dynSt, inPtfPtr, A_SeverityRuleLink_ObjId, A_Domain_PtfObjId, IdType) == 0)
    {
        return TRUE;
    }
    return FALSE;
}


STATIC int FIN_FilterForBusinessEnity(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP inPtfPtr)
{
    if (GET_ID(dynSt, A_SeverityRuleLink_LinkedEntityDictId) == BusEntityCst &&
        CMP_DYNFLD(dynSt, inPtfPtr, A_SeverityRuleLink_ObjId, A_Ptf_MainBusEntityId, IdType) == 0)
    {
        return TRUE;
    }
    return FALSE;
}

STATIC int FIN_FilterForBusinessUnit(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP inPtfPtr)
{
    if (GET_ID(dynSt, A_SeverityRuleLink_LinkedEntityDictId) == BusinessUnitCst)
    {
        return TRUE;
    }
    return FALSE;
}

STATIC int FIN_FilterForDefaultRule(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP inPtfPtr)
{
    if (GET_FLAG(dynSt, A_SeverityRule_linkedRuleFlag) == TRUE )
    {
        return FALSE;
    }
    return TRUE;
}

/************************************************************************
**
**  Function    :   FIN_CmpRuleDictId()
**
**  Description :   Sort element by given id
**
**  Arguments   :   ptr1         pointer on dynamic structure
**                  ptr2         pointer on dynamic structure
**  
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element

                    sort order  : Instrument-900 , Market Segment -404 , Strategy- 500
**
**  Creation    :   PMSTA-47502-Lalby-04032022
**  Modif       :
*************************************************************************/
STATIC int FIN_CmpRuleDictId(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
    DICT_T ptr1DictId = GET_DICT(*ptr1, A_SeverityRule_ObjDictId);
    DICT_T ptr2DictId = GET_DICT(*ptr2, A_SeverityRule_ObjDictId);

    if (ptr1DictId == ptr2DictId)
        return 0;

    if ((ptr1DictId == InstrCst) || ((ptr1DictId == MktSegtCst) && (ptr2DictId == StratCst)) ||
        (ptr1DictId == StratEltCst) && (ptr2DictId == StratCst))
        return -1;
    else
        return 1;
}

/************************************************************************
**
**  Function    :   FIN_CmpLinkedRuleDictId()
**
**  Description :   Sort element by given id
**
**  Arguments   :   ptr1         pointer on dynamic structure
**                  ptr2         pointer on dynamic structure
**                  parentFldIdx index of the parent field in the structure
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element

                    sort order  : Instrument-900 , Market Segment -404 , Strategy- 500
**
**  Creation    :   PMSTA-48749-Lalby-08042022
**  Modif       :
*************************************************************************/
STATIC int FIN_CmpLinkedRuleDictId(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
  
    DBA_DYNFLD_STP severityRuleElePtr;

    if (GET_EXTENSION_PTR(*ptr1, A_SeverityRuleLink_SeverityRule_Ext) == NULL ||
        GET_EXTENSION_PTR(*ptr2, A_SeverityRuleLink_SeverityRule_Ext) == NULL ||
        (severityRuleElePtr = *(GET_EXTENSION_PTR(*ptr1, A_SeverityRuleLink_SeverityRule_Ext))) == NULLDYNST ||
        (severityRuleElePtr = *(GET_EXTENSION_PTR(*ptr2, A_SeverityRuleLink_SeverityRule_Ext))) == NULLDYNST)
    {
        return 0;
    }

    DBA_DYNFLD_STP   *severityRuleTab1 = (DBA_DYNFLD_STP*)NULLDYNST;
    DBA_DYNFLD_STP   *severityRuleTab2 = (DBA_DYNFLD_STP*)NULLDYNST;
    int severityRuleNbr1 = 0, severityRuleNbr2 = 0;

    severityRuleTab1 = GET_EXTENSION_PTR(*ptr1, A_SeverityRuleLink_SeverityRule_Ext);
    severityRuleNbr1 = GET_EXTENSION_NBR(*ptr1, A_SeverityRuleLink_SeverityRule_Ext);

    severityRuleTab2 = GET_EXTENSION_PTR(*ptr2, A_SeverityRuleLink_SeverityRule_Ext);
    severityRuleNbr2 = GET_EXTENSION_NBR(*ptr2, A_SeverityRuleLink_SeverityRule_Ext);

    if (severityRuleNbr1 > 0 && severityRuleNbr2 > 0)
    {
        DICT_T ptr1DictId = GET_DICT(severityRuleTab1[0], A_SeverityRule_ObjDictId);
        DICT_T ptr2DictId = GET_DICT(severityRuleTab2[0], A_SeverityRule_ObjDictId);

        if (ptr1DictId == ptr2DictId)
            return 0;

        if ((ptr1DictId == InstrCst) || ((ptr1DictId == MktSegtCst) && (ptr2DictId == StratCst)))
            return -1;
        else
            return 1;
    }
    return 0;
}

/************************************************************************
*
*   Function      :   getLinkedRules()
*
**  Description   :  
**  Arguments     :   
**
*
*   Return        :   TRUE or FALSE
*
*   Creation Date :   PMSTA-47502-Lalby-04032022
*************************************************************************/

RET_CODE DynamicSeverity::getLinkedRules()
{
    RET_CODE ret = RET_SUCCEED;

    /*1: check for Portfolio -Link*/
    if ((ret = DBA_ExtractHierEltRecWithFilterSt(m_stratHierHead, A_SeverityRuleLink, FALSE, FIN_FilterForPtf,
        m_ptfInfoStp->ptfPtr, FIN_CmpLinkedRuleDictId, &m_portfolioLinkedseveRuleNbr, &m_portfolioLinkedseveRuleTab)) != RET_SUCCEED )
    {
        return ret;
    }

    m_ruleTabMemeoryPool.owner(m_portfolioLinkedseveRuleTab);

    /*2: check for Portfolio -List*/
    if ((ret = DBA_ExtractHierEltRecWithFilterSt(m_stratHierHead, A_SeverityRuleLink, FALSE, FIN_FilterForPtfList,
        m_domain, NULLFCT, &m_portfolioListLinkedseveRuleNbr, &m_portfolioListLinkedseveRuleTab)) != RET_SUCCEED )
    {
        return ret;
    }

    m_ruleTabMemeoryPool.owner(m_portfolioListLinkedseveRuleTab);

    /*3: check for Business Entity*/
    if ((ret = DBA_ExtractHierEltRecWithFilterSt(m_stratHierHead, A_SeverityRuleLink, FALSE, FIN_FilterForBusinessEnity,
        m_ptfInfoStp->ptfPtr, FIN_CmpLinkedRuleDictId, &m_businessEntityLinkedseveRuleNbr, &m_businessEntityLinkedseveRuleTab)) != RET_SUCCEED )
    {
        return ret;
    }

    m_ruleTabMemeoryPool.owner(m_businessUnitLinkedseveRuleTab);

    /*4: check for Business Unit*/
    if ((ret = DBA_ExtractHierEltRecWithFilterSt(m_stratHierHead, A_SeverityRuleLink, FALSE, FIN_FilterForBusinessUnit,
        m_ptfInfoStp->ptfPtr, FIN_CmpLinkedRuleDictId, &m_businessUnitLinkedseveRuleNbr , &m_businessUnitLinkedseveRuleTab)) != RET_SUCCEED )
    {
        return ret;
    }

    m_ruleTabMemeoryPool.owner(m_businessEntityLinkedseveRuleTab);

    /*5 : get default rules */
    if ((ret = DBA_ExtractHierEltRec(m_stratHierHead, A_SeverityRule, FALSE, FIN_FilterForDefaultRule, FIN_CmpRuleDictId,
                     &m_defaultseveRuleTabNbr, &m_defaultseveRuleTab)) != RET_SUCCEED)
    {
        return(ret);
    }

    m_ruleTabMemeoryPool.owner(m_defaultseveRuleTab);

    return ret;
}


/************************************************************************
*
*   Function      :   initialiseDynamicSeverity()
*
**  Description   :   load severity_rule_link, severity_rule,severity_rule_element into the hiearachy for the domain- 
                        (loaded along with strategy-SEL_EXD_STRATEGY_BY_DOMAIN)
 
**  Arguments     :   stratHierHead,FIN_PTFINFO_STP,domainPtr
**
*
*   Return        :   TRUE or FALSE (if non complaint)
*
*   Creation Date :   PMSTA-47502-Lalby-04032022
*************************************************************************/

RET_CODE DynamicSeverity::initialiseDynamicSeverity()
{
    RET_CODE ret = RET_SUCCEED;

    if (m_stratHierHead == NULLDYNST || m_ptfInfoStp == NULLDYNST || m_domain == NULLDYNST)
    {
        return ret;
    }

    if ((ret = getLinkedRules()) != RET_SUCCEED)
    {
        return ret;
    }

    return ret;
}

/************************************************************************
*
*   Function      :   getSeverityRuleElement()
*
**  Description   :  return the severityEn in the deviationGap range
                       Rnage 0 to 3  should consider as   0 to 2.99
                             3 to 15
                             15 to 100 ( 15 t0 99.999) specify max as NULL
**  Arguments     :  deviationGap
**
*
*   Return        :   SeverityRuleElementDeviationSeverityEn
*
*   Creation Date :   PMSTA-47502-Lalby-04032022
*************************************************************************/

RET_CODE DynamicSeverity::getSeverityRuleElement(DeviationType enDeviationType, DBA_DYNFLD_STP svRrule, NUMBER_T deviationValue,
                            DBA_DYNFLD_STP *svRruleElem)
{
    DBA_DYNFLD_STP severityRuleElePtr = NULLDYNST;
    DBA_DYNFLD_STP  *severityRuleEltTab = NULLDYNST;
    int severityRuleEltNbr=0;

    if (svRrule != NULLDYNST && GET_EXTENSION_PTR(svRrule, A_SeverityRule_SeverityRuleElem_Ext) != NULL &&
            (severityRuleElePtr = *(GET_EXTENSION_PTR(svRrule, A_SeverityRule_SeverityRuleElem_Ext))) != NULLDYNST)
    {
        severityRuleEltTab = GET_EXTENSION_PTR(svRrule, A_SeverityRule_SeverityRuleElem_Ext);
        severityRuleEltNbr = GET_EXTENSION_NBR(svRrule, A_SeverityRule_SeverityRuleElem_Ext);
 
        for (int i = 0; i < severityRuleEltNbr ; ++i)
        {
            if (enDeviationType == DeviationType::DeviationGap)
            {
                if (IS_NULLFLD(severityRuleEltTab[i], A_SeverityRuleElement_DeviationGapMin))
                {
                    SET_NUMBER(severityRuleEltTab[i], A_SeverityRuleElement_DeviationGapMin, 0);
                }
                /*more than max and max is not specified*/
                if (IS_NULLFLD(severityRuleEltTab[i], A_SeverityRuleElement_DeviationGapMax) == TRUE &&
                    (CMP_NUMBER(GET_NUMBER(severityRuleEltTab[i], A_SeverityRuleElement_DeviationGapMin),deviationValue) <= 0))
                {
                    *svRruleElem = severityRuleEltTab[i];
                    return RET_SUCCEED;
                }
                else if (CMP_NUMBER(GET_NUMBER(severityRuleEltTab[i], A_SeverityRuleElement_DeviationGapMin),deviationValue) <= 0 &&
                         (CMP_NUMBER(GET_NUMBER(severityRuleEltTab[i], A_SeverityRuleElement_DeviationGapMax),deviationValue ) > 0)) 
                {
                    *svRruleElem = severityRuleEltTab[i];
                    return RET_SUCCEED;
                }
            }

            else if (enDeviationType == DeviationType::DeviationDuration)
            {
                if (IS_NULLFLD(severityRuleEltTab[i], A_SeverityRuleElement_DeviationDurationMin))
                {
                    SET_INT(severityRuleEltTab[i], A_SeverityRuleElement_DeviationDurationMin, 0);
                }
                /*more than max and max is not specified*/
                if (IS_NULLFLD(severityRuleEltTab[i], A_SeverityRuleElement_DeviationDurationMax) == TRUE &&
                    (GET_INT(severityRuleEltTab[i], A_SeverityRuleElement_DeviationDurationMin) <= deviationValue))
                {
                    *svRruleElem = severityRuleEltTab[i];
                    return RET_SUCCEED;
                }

                else if (GET_INT(severityRuleEltTab[i], A_SeverityRuleElement_DeviationDurationMin) <= deviationValue &&
                    GET_INT(severityRuleEltTab[i], A_SeverityRuleElement_DeviationDurationMax) > deviationValue)
                {
                    *svRruleElem = severityRuleEltTab[i];
                    return RET_SUCCEED;
                }
            }
        }
    }
    return FALSE;
 }


/************************************************************************
*
*   Function      :  computeDeviationDuration
**  Description   : The deviation duration is computed using case management data
                    DeviationDuration = EndDate/domain date  - CaseBeginDate
                    cases are loaded in hierarchy using strategy.psc
                    This function find the matched case data and compute
                    deviation duration

**  Arguments     :  seveRuleRec,extStratElt
**
*
*   Return        :   deviation gap
*
*   Creation Date :   PMSTA-47502-Lalby-04032022
*************************************************************************/
NUMBER_T DynamicSeverity::computeDeviationDuration(DBA_DYNFLD_STP extStratElt, DBA_DYNFLD_STP *curentCasePtr)
{
    DBA_DYNFLD_STP oldCasePtr = NULLDYNSTPTR;

    /*The severity rule will be applicable for the following strategy natures :
    •Tactical Asset Allocation – The severity rule can be set on any market segment level of a tactical asset allocation(applicable for node and leaf)
    •Model Portfolio – The severity rule can be set on any instrument part of the model portfolio and also on any model portfolio strategy */
    STRATNAT_ENUM eseStratNatEn = static_cast<STRATNAT_ENUM> GET_ENUM(extStratElt, ExtStratElt_StratNatEn);
    if (eseStratNatEn == StratNat_Alloc ||
        eseStratNatEn == StratNat_ModelPtf ||
        eseStratNatEn == StratNat_ConstraintSet ||
        eseStratNatEn == StratNat_SecurityConstr )
    {
        if (FIN_GetCaseFromCaseManagement(m_stratHierHead, m_domain, m_ptfInfoStp->ptfPtr, extStratElt, &oldCasePtr,
            curentCasePtr) == RET_SUCCEED)
        {
            if (oldCasePtr != NULLDYNSTPTR &&
                IS_NULLFLD(oldCasePtr, A_CaseManagement_CaseBeginDate) == FALSE &&
                IS_NULLFLD(m_domain, A_Domain_InterpTillDate) == FALSE)
            {
                return(DATE_Diff(GET_DATE(oldCasePtr, A_CaseManagement_CaseBeginDate),
                    GET_DATE(m_domain, A_Domain_InterpTillDate),
                    Day, AccrRule_Actual_365, ZERO_ID)); /*AccrRule_Actual_365 - consider 31 also*/
            }

        }
    }
    return 0;
}

/************************************************************************
*
*   Function      :  computeDeviationGap
**  Description   :  computeDeviationGap

**  Arguments     :  seveRuleRec,extStratElt
**
*
*   Return        :   deviation gap
*
*   Creation Date :   PMSTA-47502-Lalby-04032022
*************************************************************************/
NUMBER_T DynamicSeverity::computeDeviationGap(DBA_DYNFLD_STP extStratElt, DBA_DYNFLD_STP seveRuleRec)
{
    NUMBER_T deviation = 0;

    if (extStratElt == NULLDYNST || seveRuleRec == NULLDYNST)
        return FALSE;
 
    STRATNAT_ENUM stratNatEn = static_cast<STRATNAT_ENUM> GET_ENUM(extStratElt, ExtStratElt_StratNatEn);
    if (stratNatEn == StratNat_Alloc || stratNatEn == StratNat_ModelPtf)
    {
        if (static_cast<SeverityRuleScopeEn> GET_ENUM(seveRuleRec, A_SeverityRule_ScopeEn) == SeverityRuleScopeEn::InvestmentObjective)
        {
            SeverityRuleDeviationGapMethodEn deviationGapMethod = static_cast<SeverityRuleDeviationGapMethodEn>
                GET_ENUM(seveRuleRec, A_SeverityRule_DeviationGapMethodEn);

            if (deviationGapMethod == SeverityRuleDeviationGapMethodEn::AbsoluteDeviationToTarget)
            {
                if (IS_NULLFLD(extStratElt, ExtStratElt_ActualWeightContrib) == FALSE && IS_NULLFLD(extStratElt, ExtStratElt_ObjWeightContrib) == FALSE)
                    deviation = std::abs(GET_NUMBER(extStratElt, ExtStratElt_ActualWeightContrib) - GET_NUMBER(extStratElt, ExtStratElt_ObjWeightContrib));
            }
            else if (deviationGapMethod == SeverityRuleDeviationGapMethodEn::AbsoluteDeviationToRange)
            {
                NUMBER_T marginUp = 0, marginDown = 0;
                if (IS_NULLFLD(extStratElt, ExtStratElt_ObjWeightMarg) == FALSE)
                {
                    marginDown = GET_NUMBER(extStratElt, ExtStratElt_ObjWeightMarg);
                    marginUp = marginDown;
                }
                else
                {
                    if (IS_NULLFLD(extStratElt, ExtStratElt_ObjLowerMarg) == FALSE)
                    {
                        marginDown = GET_NUMBER(extStratElt, ExtStratElt_ObjLowerMarg);
                    }
                    if (IS_NULLFLD(extStratElt, ExtStratElt_ObjUpperMarg) == FALSE)
                    {
                        marginUp = GET_NUMBER(extStratElt, ExtStratElt_ObjUpperMarg);
                    }
                }
                if (GET_NUMBER(extStratElt, ExtStratElt_ActualWeightContrib) < (GET_NUMBER(extStratElt, ExtStratElt_ObjWeightContrib) - marginDown))
                {
                    deviation = std::abs(GET_NUMBER(extStratElt, ExtStratElt_ActualWeightContrib) - (GET_NUMBER(extStratElt, ExtStratElt_ObjWeightContrib) - marginDown));
                }
                if (GET_NUMBER(extStratElt, ExtStratElt_ActualWeightContrib) > (GET_NUMBER(extStratElt, ExtStratElt_ObjWeightContrib) + marginUp))
                {
                    deviation = std::abs(GET_NUMBER(extStratElt, ExtStratElt_ActualWeightContrib) - GET_NUMBER(extStratElt, ExtStratElt_ObjWeightContrib) - marginUp);
                }
            }
            else if (deviationGapMethod == SeverityRuleDeviationGapMethodEn::RelativeDeviationToTarget)
            {
                if (IS_NULLFLD(extStratElt, ExtStratElt_ActualWeightContrib) == FALSE )
                {
                    deviation = 100 * FIN_DIV(std::abs(GET_NUMBER(extStratElt, ExtStratElt_ActualWeightContrib) - GET_NUMBER(extStratElt, ExtStratElt_ObjWeightContrib))
                        , std::abs(GET_NUMBER(extStratElt, ExtStratElt_ObjWeightContrib)));
                }
            }
            else if (deviationGapMethod == SeverityRuleDeviationGapMethodEn::RelativeDeviationToRange)
            {
                NUMBER_T marginUp = 0, marginDown = 0;
				if (IS_NULLFLD(extStratElt, ExtStratElt_ObjWeightMarg) == FALSE)
				{
					marginDown = GET_NUMBER(extStratElt, ExtStratElt_ObjWeightMarg);
					marginUp = marginDown;
				}
				else
				{
					if (IS_NULLFLD(extStratElt, ExtStratElt_ObjLowerMarg) == FALSE)
					{
						marginDown = GET_NUMBER(extStratElt, ExtStratElt_ObjLowerMarg);
					}
					if (IS_NULLFLD(extStratElt, ExtStratElt_ObjUpperMarg) == FALSE)
					{
						marginUp = GET_NUMBER(extStratElt, ExtStratElt_ObjUpperMarg);
					}
				}
                if (GET_NUMBER(extStratElt, ExtStratElt_ActualWeightContrib) < (GET_NUMBER(extStratElt, ExtStratElt_ObjWeightContrib) - marginDown))
                {
                    deviation = 100 * FIN_DIV(std::abs(GET_NUMBER(extStratElt, ExtStratElt_ActualWeightContrib) - (GET_NUMBER(extStratElt, ExtStratElt_ObjWeightContrib) - marginDown))
                        , std::abs(GET_NUMBER(extStratElt, ExtStratElt_ObjWeightContrib)));
                }
                if (GET_NUMBER(extStratElt, ExtStratElt_ActualWeightContrib) > (GET_NUMBER(extStratElt, ExtStratElt_ObjWeightContrib) + marginUp))
                {
					deviation = 100 * FIN_DIV(std::abs(GET_NUMBER(extStratElt, ExtStratElt_ActualWeightContrib) - GET_NUMBER(extStratElt, ExtStratElt_ObjWeightContrib) - marginUp)
                        , std::abs(GET_NUMBER(extStratElt, ExtStratElt_ObjWeightContrib)));
                }
            }
        }
    }
    else if (stratNatEn == StratNat_SecurityConstr)
    {
        /*Deviation Gap & Modelling Constraints(model_constr_elem)
        Method - If maximum set only
            Deviation=ABS├ (Current-Maximum)┤
        Method - If minimum set only
            Deviation=ABS├ (Current-Minimum)┤
        Method - If minimum and maximum set
                 If current weight < Minimum
                                     Deviation=ABS(├ Current-Minimum)┤
                Else if current weight > Maximum
                                    Deviation=ABS(├ Current-Maximum┤)


        ext_strategy_element.strat_nat_e IN(21) { Security Constraint }
        If the constraint nature is ‘Quantity’, (constr_bound_nat_e) it has to be converted to weight by:
         a.	Get the price of the instrument.
         b.	Add possible accrued interests.
         c.	Multiply by the quantity of the constraint.
         d.	Convert this amount from the instrument price currency to the portfolio currency.
         e.	Divide this amount by the market value of the portfolio.

         If the constraint nature is ‘Amount’, it has to be converted to weight by:
         a.	Convert the amount of the constraint from the constraint currency to the portfolio currency.
         b.	Divide this amount by the market value of the portfolio.  */

        if (static_cast<SeverityRuleScopeEn> GET_ENUM(seveRuleRec, A_SeverityRule_ScopeEn) == SeverityRuleScopeEn::ModellingConstraint)
        {
            if (IS_NULLFLD(extStratElt, ExtStratElt_MaxWeightContrib) == FALSE && IS_NULLFLD(extStratElt, ExtStratElt_MinWeightContrib) == FALSE)
            {
                NUMBER_T currentWeight = GET_NUMBER(extStratElt, ExtStratElt_ActualWeightContrib);
                NUMBER_T minWeight = GET_NUMBER(extStratElt, ExtStratElt_MinWeightContrib);
                NUMBER_T maxWeight = GET_NUMBER(extStratElt, ExtStratElt_MaxWeightContrib);

                if (currentWeight < minWeight)
                {
                    deviation = std::abs(currentWeight - minWeight);
                }
                else if (currentWeight > maxWeight)
                {
                    deviation = std::abs(currentWeight - maxWeight);
                }
            }
            else if (IS_NULLFLD(extStratElt, ExtStratElt_MaxWeightContrib) == FALSE)
            {
                deviation = std::abs(GET_NUMBER(extStratElt, ExtStratElt_ActualWeightContrib) - GET_NUMBER(extStratElt, ExtStratElt_MaxWeightContrib));
            }
            else if (IS_NULLFLD(extStratElt, ExtStratElt_MinWeightContrib) == FALSE)
            {
                deviation = std::abs(GET_NUMBER(extStratElt, ExtStratElt_ActualWeightContrib) - GET_NUMBER(extStratElt, ExtStratElt_MinWeightContrib));
            }
        }
    }
    /*for modeling trading constraint and concentration distribution - only deviation duration is applicable*/
    return deviation;
}


/************************************************************************
*
*   Function      :  isMatchedRuleObject
**  Description   :  compare rule object with ESE and return the status
                     also set ExtStratElt_SeverityRuleId for the priority rules to avoid further check the rule 
                     for the same ESE

**  Arguments     :  seveRuleRec,extStratElt
**
*
*   Return        :   true - if rule match with ese . else false

*
*   Creation Date :   PMSTA-47502-Lalby-04032022
*************************************************************************/

bool  DynamicSeverity::isMatchedRuleObject(DBA_DYNFLD_STP   severityRule, DBA_DYNFLD_STP extStratElt)
{
    if (static_cast<SeverityRuleScopeEn> GET_ENUM(severityRule, A_SeverityRule_ScopeEn) == SeverityRuleScopeEn::InvestmentObjective)
    {
        SeverityRuleSubNatEn svRuleSubNat = static_cast<SeverityRuleSubNatEn> GET_ENUM(severityRule, A_SeverityRule_SubNatEn);
        if (SeverityRuleSubNatEn::None == svRuleSubNat)
        {
            if (CMP_DYNFLD(severityRule, extStratElt, A_SeverityRule_ObjId, ExtStratElt_StratId, IdType) == 0)
            {
                /* ExtStratElt_SeverityRuleId - is not assigned - to continue search of best fit */
                return TRUE;
            }
        }
        else if (SeverityRuleSubNatEn::Instrument == svRuleSubNat)
        {
            if (CMP_DYNFLD(severityRule, extStratElt, A_SeverityRule_ObjId, ExtStratElt_InstrId, IdType) == 0)
            {
                if (IS_NULLFLD(severityRule, A_SeverityRule_ParentObjDictId) == TRUE)
                {
                    SET_ID(extStratElt, ExtStratElt_SeverityRuleId, GET_ID(severityRule, A_SeverityRule_Id));
                    return TRUE;
                }
                else if ((IS_NULLFLD(severityRule, A_SeverityRule_ParentObjId) == FALSE)
                    && (GET_ID(severityRule, A_SeverityRule_ParentObjDictId) == StratCst))
                {
                    if (CMP_DYNFLD(severityRule, extStratElt, A_SeverityRule_ParentObjId, ExtStratElt_StratId, IdType) == 0)
                    {
                        SET_ID(extStratElt, ExtStratElt_SeverityRuleId, GET_ID(severityRule, A_SeverityRule_Id));
                        return TRUE;
                    }
                }
            }
        }
        else if (SeverityRuleSubNatEn::MarketSegment == svRuleSubNat)
        {
            if (CMP_DYNFLD(severityRule, extStratElt, A_SeverityRule_ObjId, ExtStratElt_MktSegtId, IdType) == 0)
            {
                if (IS_NULLFLD(severityRule, A_SeverityRule_ParentObjDictId) == TRUE)
                {
                    /* ExtStratElt_SeverityRuleId - is not assigned - to continue search of best fit */
                    return TRUE;
                }
                else if ((IS_NULLFLD(severityRule, A_SeverityRule_ParentObjId) == FALSE)
                    && (GET_ID(severityRule, A_SeverityRule_ParentObjDictId) == StratCst))
                {
                    if (CMP_DYNFLD(severityRule, extStratElt, A_SeverityRule_ParentObjId, ExtStratElt_StratId, IdType) == 0)
                    {
                        SET_ID(extStratElt, ExtStratElt_SeverityRuleId, GET_ID(severityRule, A_SeverityRule_Id));
                        return TRUE;
                    }
                }
            }
        }
    }
    else if (static_cast<SeverityRuleScopeEn> GET_ENUM(severityRule, A_SeverityRule_ScopeEn) == SeverityRuleScopeEn::ModellingConstraint)
    {
        if (static_cast<STRATNAT_ENUM>GET_ENUM(extStratElt, ExtStratElt_StratNatEn) == StratNat_SecurityConstr)
        {
            if (CMP_DYNFLD(severityRule, extStratElt, A_SeverityRule_ObjId, ExtStratElt_InstrId, IdType) == 0)
            {
                SET_ID(extStratElt, ExtStratElt_SeverityRuleId, GET_ID(severityRule, A_SeverityRule_Id));
                return TRUE;
            }
        }
    }
    else if (static_cast<SeverityRuleScopeEn> GET_ENUM(severityRule, A_SeverityRule_ScopeEn) == SeverityRuleScopeEn::ModellingTradingConstraint &&
        GET_ENUM(extStratElt, ExtStratElt_NatEn) == ExtStratEltNat_ModellingTradingConstr)
    {
        if (CMP_DYNFLD(severityRule, extStratElt, A_SeverityRule_ObjId, ExtStratElt_InstrId, IdType) == 0)
        {
            SET_ID(extStratElt, ExtStratElt_SeverityRuleId, GET_ID(severityRule, A_SeverityRule_Id));
            return TRUE;
        }
    }
    else if (static_cast<SeverityRuleScopeEn> GET_ENUM(severityRule, A_SeverityRule_ScopeEn) == SeverityRuleScopeEn::ConcentrationDistribution &&
        (GET_ENUM(extStratElt, ExtStratElt_StratNatEn) == StratNat_ConstraintSet))
    {
        /*check rule exist in strategy element level - strategy_elt_id*/
        if (IS_NULLFLD(extStratElt, ExtStratElt_StratEltId) == FALSE &&
            GET_ID(severityRule, A_SeverityRule_ObjDictId) == StratEltCst &&
            CMP_DYNFLD(severityRule, extStratElt, A_SeverityRule_ParentObjId, ExtStratElt_StratId, IdType) == 0 &&
            CMP_DYNFLD(severityRule, extStratElt, A_SeverityRule_ObjId, ExtStratElt_StratEltId, IdType) == 0)
        {
            SET_ID(extStratElt, ExtStratElt_SeverityRuleId, GET_ID(severityRule, A_SeverityRule_Id));
            return TRUE;
        }
        else if (GET_ID(severityRule, A_SeverityRule_ObjDictId) == StratCst &&
            CMP_DYNFLD(severityRule, extStratElt, A_SeverityRule_ObjId, ExtStratElt_StratId, IdType) == 0)
        {
            /*rule id not set in ese here , holding constarints dont have subnature ..so we need to find best fit
            need to check rules -element level for this ESE
            ExtStratElt_SeverityRuleId - is not assigned - to continue search of best fit */
            return TRUE;
        }
    }

    return FALSE;
}


/************************************************************************
*
*   Function      :  getRuleByNature
**  Description   :  get the rule , validate scope_e,sub_nature_e,objcet_id

**  Arguments     : extStratElt , output parameter :severityRule
**
*
*   Return        :  TRUE or FALSE
*
*   Creation Date :   PMSTA-47502-Lalby-04032022
*************************************************************************/

RET_CODE DynamicSeverity::getRuleByNature(DBA_DYNFLD_STP severityRuleLink,DBA_DYNFLD_STP extStratElt,
                                              DBA_DYNFLD_STP *severityRule)
{
    DBA_DYNFLD_STP   severityRulePtr = NULLDYNST;

    if (severityRuleLink != NULLDYNST && extStratElt != NULLDYNST &&
        GET_EXTENSION_PTR(severityRuleLink, A_SeverityRuleLink_SeverityRule_Ext) != NULLDYNST &&
        (severityRulePtr = *(GET_EXTENSION_PTR(severityRuleLink, A_SeverityRuleLink_SeverityRule_Ext))) != NULLDYNST)
    {
        DBA_DYNFLD_STP   *severityRuleTab = (DBA_DYNFLD_STP*)NULLDYNST;
        int severityRuleNbr = 0;

        severityRuleTab = GET_EXTENSION_PTR(severityRuleLink, A_SeverityRuleLink_SeverityRule_Ext);
        severityRuleNbr = GET_EXTENSION_NBR(severityRuleLink, A_SeverityRuleLink_SeverityRule_Ext);

        if(severityRuleNbr > 0)
        {
            if (severityRuleTab[0] != NULLDYNST)
            {
                if (isMatchedSeverityRuleScope(severityRuleTab[0]) == FALSE)
                    return FALSE;

                if (isMatchedRuleObject(severityRuleTab[0], extStratElt) == TRUE)
                {
                    *severityRule = severityRuleTab[0];
                    return TRUE;
                }
            }
        }
    }

    return FALSE;
}


/************************************************************************
**
**  Function    :   isMatchedSeverityRuleScope()
**
**  Description :   compliance_func_scope_e	
                    0 – None
                    1 – Check Strategy (Default)
                    2 – PTCC
                    3 – Both Check Strategy and PTCC
**  Arguments   :
**
**  Return      :   TRUE/FALSE
**
*************************************************************************/

RET_CODE DynamicSeverity::isMatchedSeverityRuleScope (DBA_DYNFLD_STP seveRule)
{
    RET_CODE ret = FALSE;

    SeverityRuleComplianceFuncScopeEn severityScope = static_cast<SeverityRuleComplianceFuncScopeEn> GET_ENUM(seveRule, A_SeverityRule_ComplianceFuncScopeEn);

    if (severityScope == SeverityRuleComplianceFuncScopeEn::CheckStrategy ||
        severityScope == SeverityRuleComplianceFuncScopeEn::BothCheckStrategyAndPTCC)
    {
        if (GET_ID(m_domain, A_Domain_FctDictId) == DictFct_CheckStrat)
        {
            return TRUE;
        }
    }
 
    if (severityScope == SeverityRuleComplianceFuncScopeEn::PTCC ||
        severityScope == SeverityRuleComplianceFuncScopeEn::BothCheckStrategyAndPTCC)
    {
        if (GET_ID(m_domain, A_Domain_FctDictId) == DictFct_PreTradeCheckStrat)
        {
            return TRUE;
        }
    }

    return ret;
}

/************************************************************************
*
*   Function      :  getSeverityRuleByPriority
**  Description   :  Priority - linked entity dict 
                    1) 800 : portfolio 
                    2) 400 : pf list
                    3) 606 : business entity
                    4) 2580: business unit 

                    If not matched with any linked rule ,apply the default rule
 
**  Arguments     :DBA_DYNFLD_STP extStratElt,   out : DBA_DYNFLD_STP *sevRule
*
*   Return        :   RET_SUCCEED
*
*   Creation Date :   PMSTA-47502-Lalby-04032022
*************************************************************************/

RET_CODE DynamicSeverity::getSeverityRuleByPriority( DBA_DYNFLD_STP extStratElt,  DBA_DYNFLD_STP *sevRule)
{
     
    /*1: check for Portfolio -Link*/
    if(m_portfolioLinkedseveRuleTab != NULLDYNST  && m_portfolioLinkedseveRuleNbr >0)
    {
        for (int i = 0; i < m_portfolioLinkedseveRuleNbr; i++)
        {
            getRuleByNature(m_portfolioLinkedseveRuleTab[i], extStratElt, sevRule);

            if (IS_NULLFLD(extStratElt, ExtStratElt_SeverityRuleId) == FALSE && *sevRule != NULLDYNSTPTR)
                return RET_SUCCEED;
        }

        if (*sevRule != NULLDYNSTPTR)
            return RET_SUCCEED;
    }

    /*2: check for Portfolio -List*/
    if (m_portfolioListLinkedseveRuleTab != NULLDYNST && m_portfolioListLinkedseveRuleNbr > 0)
    {
        for (int i = 0; i < m_portfolioListLinkedseveRuleNbr; i++)
        {
            getRuleByNature(m_portfolioListLinkedseveRuleTab[i], extStratElt, sevRule);
            if (IS_NULLFLD(extStratElt, ExtStratElt_SeverityRuleId) == FALSE && *sevRule != NULLDYNSTPTR)
                return RET_SUCCEED;
        }

        if (*sevRule != NULLDYNSTPTR)
            return RET_SUCCEED;
    }

    /*3: check for Business Unit*/
    if (m_businessUnitLinkedseveRuleTab != NULLDYNST && m_businessUnitLinkedseveRuleNbr > 0)
    {
        for (int i = 0; i < m_businessUnitLinkedseveRuleNbr; i++)
        {
            getRuleByNature(m_businessUnitLinkedseveRuleTab[i], extStratElt, sevRule);
            if (IS_NULLFLD(extStratElt, ExtStratElt_SeverityRuleId) == FALSE && *sevRule != NULLDYNSTPTR)
                return RET_SUCCEED;
        }
        if (*sevRule != NULLDYNSTPTR)
            return RET_SUCCEED;
    }

    /*4: check for Business Entity*/
    if (m_businessEntityLinkedseveRuleTab != NULLDYNST && m_businessEntityLinkedseveRuleNbr > 0)
    {
        for (int i = 0; i < m_businessEntityLinkedseveRuleNbr; i++)
        {
            getRuleByNature(m_businessEntityLinkedseveRuleTab[i], extStratElt, sevRule);
            if (IS_NULLFLD(extStratElt, ExtStratElt_SeverityRuleId) == FALSE && *sevRule != NULLDYNSTPTR)
                return RET_SUCCEED;
        }

        if (*sevRule != NULLDYNSTPTR)
            return RET_SUCCEED;
    }

    /*Not found any linked rule - check for Default rule */
    if (m_defaultseveRuleTab != NULLDYNST && m_defaultseveRuleTabNbr > 0)
    {
        for (int i = 0; i < m_defaultseveRuleTabNbr; i++)
        {
            if (isMatchedSeverityRuleScope(m_defaultseveRuleTab[i]) == FALSE)
                continue;

            if (GET_FLAG(m_defaultseveRuleTab[i], A_SeverityRule_linkedRuleFlag) == TRUE)
                continue; //linked rule

            if (isMatchedRuleObject(m_defaultseveRuleTab[i], extStratElt) == TRUE)
            {
                *sevRule = m_defaultseveRuleTab[i];
                if (IS_NULLFLD(extStratElt, ExtStratElt_SeverityRuleId) == FALSE)
                {
                     return TRUE;
                }
            }
        }

        if (*sevRule != NULLDYNSTPTR)
            return RET_SUCCEED;
    }

    return RET_SUCCEED;
 }

/************************************************************************
**
**  Function    :   FIN_CmpESEId()
**
**  Description :   Sort extended strategy element by strategy elt id
**
**  Arguments   :   ptr1    first element pointer
**                  prt2    second element pointer
**
**  Return      :   TLS_Sort() comparison function return
**
*************************************************************************/
STATIC int FIN_CmpESEId(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
    /* positive in the first place */
    return (CMP_ID(GET_ID((*ptr2), ExtStratElt_Id), GET_ID((*ptr1), ExtStratElt_Id)));
}

/************************************************************************
**
**  Function    :   FIN_FilterESEbyNature()
**
**  Description :   Filter ESE for the below nature
                    If the ext_strategy_element.strat_nat_e IN (1, 2) {Asset Allocation, Model Portfolio} 
                    If the ext_strategy_element.strat_nat_e IN (21) {Security Constraint}
**
**  Arguments   :   
**
**  Return      :   TRUE/FALSE
**
*************************************************************************/

STATIC int FIN_FilterESEbyNature(DBA_DYNFLD_STP dynSt,
    DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP paramSt)
{
    STRATNAT_ENUM stratNatEn =  static_cast<STRATNAT_ENUM> GET_ENUM(dynSt, ExtStratElt_StratNatEn);

    if (stratNatEn == StratNat_Alloc ||  stratNatEn == StratNat_ModelPtf || stratNatEn == StratNat_SecurityConstr 
        || stratNatEn ==  StratNat_ConstraintSet)
        return(TRUE);
    else
        return(FALSE);
}

/************************************************************************
**
**  Function    :   FIN_FilterESEbyNatureAndRule()
**
**  Description :   Filter ESE for the below nature
                    If the ext_strategy_element.strat_nat_e IN (1, 2) {Asset Allocation, Model Portfolio}
                    If the ext_strategy_element.strat_nat_e IN (21) {Security Constraint}
                    and severity rule id exists one.
**
**  Arguments   :
**
**  Return      :   TRUE/FALSE
**
*************************************************************************/

STATIC int FIN_FilterESEbyNatureAndRule(DBA_DYNFLD_STP dynSt,
    DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP paramSt)
{
    STRATNAT_ENUM stratNatEn = static_cast<STRATNAT_ENUM> GET_ENUM(dynSt, ExtStratElt_StratNatEn);

    if ((IS_NULLFLD(dynSt, ExtStratElt_SeverityRuleId) == FALSE &&
        GET_ID(dynSt, ExtStratElt_SeverityRuleId) > 0 )&& (stratNatEn == StratNat_Alloc || stratNatEn == StratNat_ModelPtf 
        || stratNatEn == StratNat_SecurityConstr
        || stratNatEn == StratNat_ConstraintSet))
        return(TRUE);
    else
        return(FALSE);
}

/************************************************************************
*
*   Function      :  setRuleAndComputeDeviationGap
**  Description   :  get rule for the ese and
                    compute devaiation gap and update extstrategy
                    set rule id in the ese for deviation duration

**  Arguments     :  
*
*   Return        :   RET_SUCCEED
*
*   Creation Date :   PMSTA-47502-Lalby-04032022
*************************************************************************/

RET_CODE DynamicSeverity::setRuleAndComputeDeviationGap()
{
    RET_CODE ret = RET_SUCCEED;

    DBA_DYNFLD_STP    *extStratEltTab = NULL;
    int extStratEltNbr = 0;
    MemoryPool      mp;

    DBA_DYNFLD_ST     ptfIdDynSt;
    SET_ID((&ptfIdDynSt), 0, m_ptfInfoStp->ptfId);

    MSG_LogSrvMesg(FALSE, UNUSED, "Dynamic severity setRuleAndComputeDeviationGap -started");
 
    if ((ret = DBA_ExtractHierEltRecByIndexKey(m_stratHierHead,
        ExtStratElt,
        ExtStratElt_PtfId,
        ptfIdDynSt,
        FALSE,
        FIN_FilterESEbyNature,
        NULL,
        FIN_CmpESEId,
        FALSE,
        &extStratEltNbr,
        &extStratEltTab)) != RET_SUCCEED)
    {
        FREE(extStratEltTab);
        return(ret);
    }
    
    mp.owner(static_cast<void *>(extStratEltTab));

    for (int i = 0; i < extStratEltNbr; i++)
    {
        CONSTRCRITICALNESS_ENUM staticCriticalnessEn = static_cast<CONSTRCRITICALNESS_ENUM> GET_ENUM(extStratEltTab[i], ExtStratElt_CriticalnessEn);

        /*If the Static severity is ‘High’, then we needn’t calculate the dynamic severity in that case.*/
        if (staticCriticalnessEn == ConstrCriticalness_High)
            continue;

        DBA_DYNFLD_STP sevRule = NULLDYNSTPTR;

        if (getSeverityRuleByPriority(extStratEltTab[i], &sevRule) == RET_SUCCEED)
        {
            if (sevRule != NULLDYNSTPTR && IS_NULLFLD(sevRule, A_SeverityRule_Id) == FALSE)
            {
                CONSTRCRITICALNESS_ENUM deviationGapCritEn = ConstrCriticalness_None;
                NUMBER_T deviationGap = 0;
                DBA_DYNFLD_STP sevRuleElemForGap = NULLDYNSTPTR;

                /* Rule id set will help to compute deviation duration later*/
                SET_ID(extStratEltTab[i], ExtStratElt_SeverityRuleId, GET_ID(sevRule, A_SeverityRule_Id));
 
                /*Deviation gap not applicable for - Concentration-Distribution (Holding Constraints) */
                if (StratNat_ConstraintSet != static_cast<STRATNAT_ENUM> GET_ENUM(extStratEltTab[i], ExtStratElt_StratNatEn))
                {
                    deviationGap = computeDeviationGap(extStratEltTab[i], sevRule);

                    if (CMP_NUMBER(deviationGap, 0) <= 0)
                        continue;

                    if (getSeverityRuleElement(DeviationType::DeviationGap, sevRule, deviationGap, &sevRuleElemForGap) == RET_SUCCEED &&
                        sevRuleElemForGap != NULLDYNSTPTR)
                    {
                        deviationGapCritEn = static_cast<CONSTRCRITICALNESS_ENUM>
                            GET_ENUM(sevRuleElemForGap, A_SeverityRuleElement_DeviationSeverityEn);

                        if (deviationGapCritEn >= staticCriticalnessEn)
                        {
                            SET_ID(extStratEltTab[i], ExtStratElt_SeverityRuleElementId, GET_ID(sevRuleElemForGap, A_SeverityRuleElement_Id));
                            SET_NUMBER(extStratEltTab[i], ExtStratElt_DeviationGapN, deviationGap);
                            SET_ENUM(extStratEltTab[i], ExtStratElt_CriticalnessEn, deviationGapCritEn);
                            SET_ENUM(extStratEltTab[i], ExtStratElt_ObjWeightCheckEn, StratCheck_NotChecked);
                        }
                    }

                    if (sevRuleElemForGap == NULLDYNSTPTR)
                    {
                        MSG_LogSrvMesg(FALSE, UNUSED, "processDynamicSeverity: Failed to get the severity rule element for rule: %1.",
                            CodeType, GET_CODE(sevRule, A_SeverityRule_Cd));
                    }
                }
            }
        }
    }

    MSG_LogSrvMesg(FALSE, UNUSED, "Dynamic severity setRuleAndComputeDeviationGap - end");

    return ret;
}

/************************************************************************
*
*   Function      :  processDeviationDerivation
**  Description   :  compute devaiation duration and update ese

**  Arguments     :
*
*   Return        :   RET_SUCCEED
*
*   Creation Date :   PMSTA-47502-Lalby-04032022
*************************************************************************/

RET_CODE DynamicSeverity::processDeviationDerivation()
{
    RET_CODE ret = RET_SUCCEED;

    DBA_DYNFLD_STP    *extStratEltTab = NULLDYNSTPTR;
    int extStratEltNbr;
    MemoryPool      mp;

    DBA_DYNFLD_ST     ptfIdDynSt;
    SET_ID((&ptfIdDynSt), 0, m_ptfInfoStp->ptfId);

    MSG_LogSrvMesg(FALSE, UNUSED, "Dynamic severity processDeviationDerivation -started");

    //Get the ESE having the rule set 
    if ((ret = DBA_ExtractHierEltRecByIndexKey(m_stratHierHead,
        ExtStratElt,
        ExtStratElt_PtfId,
        ptfIdDynSt,
        FALSE,
        FIN_FilterESEbyNatureAndRule,
        NULL,
        FIN_CmpESEId,
        FALSE,
        &extStratEltNbr,
        &extStratEltTab)) != RET_SUCCEED)
    {
        FREE(extStratEltTab);
        return(ret);
    }

    mp.owner(static_cast<void *>(extStratEltTab));
  
    for (int i = 0; i < extStratEltNbr; i++)
    {
        CONSTRCRITICALNESS_ENUM criticalnessEn = static_cast<CONSTRCRITICALNESS_ENUM> GET_ENUM(extStratEltTab[i], ExtStratElt_CriticalnessEn);

        /*Apply highest severity - if already high .continue and save computation time*/
        if (criticalnessEn == ConstrCriticalness_High)
            continue;

         if (IS_NULLFLD(extStratEltTab[i], ExtStratElt_SeverityRuleId) == FALSE)
         {  
             /*Get severity rule from the hierarchy for the severity rule id */

             DBA_DYNFLD_STP   sevRulePtr = NULLDYNSTPTR;
             if (DBA_GetRecPtrFromHierById(m_stratHierHead,
                 GET_ID(extStratEltTab[i], ExtStratElt_SeverityRuleId),
                 A_SeverityRule,
                 &sevRulePtr) != RET_SUCCEED && sevRulePtr == NULLDYNSTPTR)
             {
                 continue;
             }
 
              DBA_DYNFLD_STP sevRuleElemForDuration = NULLDYNSTPTR;
              CONSTRCRITICALNESS_ENUM deviationDurationCritEn = ConstrCriticalness_None;

              DBA_DYNFLD_STP curentCasePtr = NULLDYNSTPTR;
              NUMBER_T deviationDuration = computeDeviationDuration(extStratEltTab[i],&curentCasePtr);

              if (CMP_NUMBER(deviationDuration, 0) <= 0)
              {
                  /*PMSTA-50330 - Lalby - 29082022*/
                  if (IS_NULLFLD(extStratEltTab[i], ExtStratElt_SeverityRuleElementId) == TRUE)
                  {
                      /*reset rule id to NULL - dynamic severity not applied here */
                      SET_NULL_ID(extStratEltTab[i], ExtStratElt_SeverityRuleId);
                  }

                  continue;
              }
              if ( getSeverityRuleElement(DeviationType::DeviationDuration, sevRulePtr,
                        deviationDuration, &sevRuleElemForDuration) == RET_SUCCEED &&
                        sevRuleElemForDuration != NULLDYNSTPTR)
              {
                   deviationDurationCritEn = static_cast<CONSTRCRITICALNESS_ENUM>
                         GET_ENUM(sevRuleElemForDuration, A_SeverityRuleElement_DurationSeverityEn);
                   /*The compliance function will only apply the highest severity */
                   if (criticalnessEn > deviationDurationCritEn)
                   {
                       /*PMSTA-50330 - Lalby - 29082022*/
                       if (IS_NULLFLD(extStratEltTab[i], ExtStratElt_SeverityRuleElementId) == TRUE)
                       {
                           /*reset rule id to NULL - dynamic severity not applied here */
                           SET_NULL_ID(extStratEltTab[i], ExtStratElt_SeverityRuleId);
                       }
                       continue;
                   }
              }

              if (sevRuleElemForDuration == NULLDYNSTPTR)
              {
                  /*PMSTA-50330 - Lalby - 29082022*/
                  if (IS_NULLFLD(extStratEltTab[i], ExtStratElt_SeverityRuleElementId) == TRUE)
                  {
                      /*reset rule id to NULL - dynamic severity not applied here */
                      SET_NULL_ID(extStratEltTab[i], ExtStratElt_SeverityRuleId);
                  }
                  MSG_LogSrvMesg(FALSE, UNUSED, "processDynamicSeverity: Failed to get the severity rule element for rule: %1.",
                      CodeType, GET_CODE(sevRulePtr, A_SeverityRule_Cd));
                  continue;  // skip and process next ESE
              }
 
              SET_ID(extStratEltTab[i], ExtStratElt_SeverityRuleElementId, GET_ID(sevRuleElemForDuration, A_SeverityRuleElement_Id));
              SET_SMALLINT(extStratEltTab[i], ExtStratElt_DeviationDurationN, static_cast<SMALLINT_T> (deviationDuration));
              SET_ENUM(extStratEltTab[i], ExtStratElt_CriticalnessEn, deviationDurationCritEn);

              /*set highest criticalness of the dynamic severity to case created*/
              if (curentCasePtr != NULLDYNSTPTR)
              {
                  SET_ENUM(curentCasePtr, A_CaseManagement_CriticalnessEn, deviationDurationCritEn);
              }
         }
    }

    MSG_LogSrvMesg(FALSE, UNUSED, "Dynamic severity processDeviationDerivation -end");
    return ret;
}




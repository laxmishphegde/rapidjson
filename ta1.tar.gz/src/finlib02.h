/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef FINLIB02_H
#define FINLIB02_H

/************************************************************************
**      BEGIN : Global variables & external definitions attached to finlib02.c
*************************************************************************/
#ifdef  EXTERN
#undef  EXTERN
#endif
#ifdef  FINLIB02_C
#define	EXTERN
#else
#define EXTERN extern
#endif

/************************************************************************
**      Structure definitions
*************************************************************************/
/* PMSTA08895 - LJE - 091102 - Move here from srvperf1.c */
typedef struct {
	ID_T   instrId;
	FLAG_T isInListFlg;
} INSTR_IN_LIST_ST, *INSTR_IN_LIST_STP;

typedef struct {
	ID_T              listId;

	FLAG_T            sortedFlg;
	INSTR_IN_LIST_STP instrTab;
	int			      instrNbr;
	int			      instrAlloc;
} BENCH_INSTR_IN_LIST_ST, *BENCH_INSTR_IN_LIST_STP;

typedef struct {	
	ID_T		    benchId;
    DBA_DYNFLD_STP  benchPtr;
	DBA_DYNFLD_STP  pspPtr;    /*REF9125 - MCA - 050822 necessary for psp */
	FREQUNIT_ENUM   freqUnit; /*REF9125 - MCA - 030822 necessary for psp */
    DATETIME_T	    fromDate;
	DATETIME_T	    tillDate;
	DATETIME_T	    delFromDate;
	DATETIME_T	    delTillDate;
    int			    paDateNbr; /* PMSTA08737 - LJE - 091113 */
    PA_DATETIME_STP paDateTab; /* PMSTA08737 - LJE - 091113 */

	DATETIME_T	            classifDate;

	SCPT_CLASSIFSTACK_STP	classifStack;

	FLAG_T				    toSortedFlg;
	BENCH_INSTR_IN_LIST_STP instrInListTab;
	int                     instrInListNbr;

    /* PMSTA08736 - LJE - 100624 */
    FLAG_T                  computeDuraFlg;
    ID_T                    priceValRuleId;

    /* PMSTA-10070 - LJE - 101026 */
    DATETIME_T	            rebalDate;

} BENCH_OBJ_DATE_ST, *BENCH_OBJ_DATE_STP; 

/* REF6025 - CSY - 010613 */
typedef struct {
    ID_T        currId;
    RETURNTP_ENUM   returnTpEn;
    RETURNNAT_ENUM  returnNatEn;
    NUMBER_T        capGainTax;
    NUMBER_T        incGainTax;
    FLAG_T          taxAccrInterFlg;
    PORTPLCOMPRULE_ENUM PlCompRuleEn;
    FLAG_T          returnCurrEffectFlg;
    BENCH_OBJ_DATE_STP	pspBenchDateStp; /* PMSTA08895 - LJE - 091102 */
} FIN_RETURNPARAM_ST, *FIN_RETURNPARAM_STP;

typedef struct {
    FLAG_T  checkStratFlg;
    FLAG_T  adjWeightFlg;
    DATETIME_T  date1;
    DATETIME_T  date2;
} FIN_BENCHRETPARAM_ST,  *FIN_BENCHRETPARAM_STP;


EXTERN RET_CODE FIN_Return(DATETIME_T, DATETIME_T, RETURNMET_ENUM, FLAG_T, 
			   FLAG_T, FLAG_T, FLAG_T, FLAG_T, ANNUALISERULE_ENUM, 
               FLAG_T, FLAG_T, FLAG_T, FLAG_T, FLAG_T, DBA_DYNFLD_STP, DBA_DYNFLD_STP, /* REF11269 - LJE - 051220 */
               ID_T, ID_T, ID_T,
			   ID_T, PTR, DBA_DYNFLD_STP, DBA_DYNFLD_STP), /* DVP165 - DVP232 */
		FIN_ComputeBookValue(DBA_DYNFLD_STP, DBA_DYNFLD_STP, EVALRULE_ENUM, EVALRULE_ENUM, 
                                     DATETIME_T, EXCHANGE_T, EXCHANGE_T, EXCHANGE_T, 
                                     DBA_HIER_HEAD_STP, DBA_DYNFLD_STP),
                FIN_BookValueByValRule(DBA_DYNFLD_STP, DBA_DYNFLD_STP, ID_T, DBA_DYNFLD_STP, 
                                       DATETIME_T, NUMBER_T, NUMBER_T, NUMBER_T, 
                                       DBA_HIER_HEAD_STP, DBA_DYNFLD_STP),
                FIN_GetBookValueEltByValRuleHist(DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, DATETIME_STP),
                FIN_CalcBookUnrealPL(DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, DBA_DYNFLD_STP),
                FIN_BenchReturn(ID_T, DBA_DYNFLD_STP, OBJECT_ENUM, DATETIME_T, 
			      DATETIME_T, 
                  FIN_RETURNPARAM_STP,  /* REF6025 - CSY - 010613 */
                  IDXTIMERULE_ENUM,
                  TINYINT_T, FREQUNIT_ENUM, /* REF5358 - CSY - 001114 */
                  DATETIME_T, 
                  ID_T,
                  CONTRIBRULE_ENUM,
                  ID_T,
                  ID_T,
                  FLAG_T, /* REF6025 - CSY - 010530 */
                  FLAG_T, /* REF6025 - CSY - 010530 */
                  FLAG_T,   /* REF7422 - CSY - 020405 */
                  FLAG_T,    /* REF7422 - CSY - 020605: anaBenchFlg */
                  double*, /* REF6025 - CSY - 010530 */
                  FLAG_T*, /* REF6025 - CSY - 010531 */
                  double*,
                  ID_T**,   /* REF6025 - CSY - 010607 */
                  int*,     /* REF6025 - CSY - 010607 */
				  DBA_DYNFLD_STP,	/* REF10274 - RAK - 040506 */
                  DBA_HIER_HEAD_STP),
                /* REF6025 - CSY - 010613 */
                FIN_InitReturnParam(ID_T, RETURNTP_ENUM, RETURNNAT_ENUM, NUMBER_T, NUMBER_T, FLAG_T,
                    PORTPLCOMPRULE_ENUM,FIN_RETURNPARAM_STP);
/* REF7422 - CSY - 020405 : for used in financial funcion benchmark storage */
EXTERN  RET_CODE    FIN_SetStratEltReturn(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP,
                                          DBA_DYNFLD_STP, DBA_DYNFLD_STP, DATETIME_T, DATETIME_T, 
										  DATETIME_T, IDXTIMERULE_ENUM, FLAG_T, FLAG_T, 
                                          BENCH_OBJ_DATE_STP, double*);/* REF7422 MCA 020722 */ 

/* REF9658 - CHU - 040209 : Merged Repercution functions */
EXTERN  RET_CODE   FIN_RepercuteUp(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, double, double, double, DBA_DYNFLD_STP, FLAG_T, FLAG_T, int),
                   FIN_RepercuteDown(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, double, int);

EXTERN double FIN_RetDiff_2del(DATETIME_T, NUMBER_T, int, ID_T, PTR, DBA_DYNST_ENUM),
	          FIN_UnrealPL(DBA_DYNFLD_STP, PLNAT_ENUM, char, PORTPLCOMPRULE_ENUM*,
		           CURRPLCOMPRULE_ENUM*), /* DVP186 */
              FIN_RealisedPL(DBA_DYNFLD_STP, PLNAT_ENUM, FLAG_T,
                  RealisedPLCalcRuleEn, DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, DATETIME_ST);  /* PMSTA-49587 - AIS - 220926 */
EXTERN void   FIN_CalcUnrealPL(DBA_DYNFLD_STP, DBA_DYNFLD_STP, PORTPLCOMPRULE_ENUM, 
		             CURRPLCOMPRULE_ENUM, ID_T, PLNAT_ENUM, FIN_PL_STP); /* DVP186 */

/* REF4263 - CSY - 000127: function shifted from finsrv05.c to
finlib02.c and STATIC replaced with EXTERN */
EXTERN  void FIN_CumulPtfSynth(DBA_DYNFLD_STP, DBA_DYNFLD_STP, char); 

/* REF6912 - CSY - 010810 */
EXTERN  void  FIN_CumulPtfSynthCurrField(DBA_DYNFLD_STP, 
			      DBA_DYNFLD_STP, FLAG_T);

/* REF5662 - DDV - 010209 */
EXTERN RET_CODE FIN_DelNoAcctExtPosFromHier(DBA_HIER_HEAD_STP);
EXTERN RET_CODE FIN_DelNoAcctNoRiskExtPosFromHier(DBA_HIER_HEAD_STP);	/* PMSTA-8736 - RAK - 100205 */

/* REF7395 - CSY - 020402: STATIC to EXTERN */
EXTERN  int FIN_CmpStratHistByAscBegDate(DBA_DYNFLD_STP*, DBA_DYNFLD_STP*); /* REF5358 - CSY - 001123 */
EXTERN	int	FIN_CmpInstrCompoByAscBegDate(DBA_DYNFLD_STP*, DBA_DYNFLD_STP*); /* PMSTA01435 - RAK - 070327 */

/* REF7422 - CSY - 020402 */
EXTERN  int FIN_FilterStratEltByStratHistId(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP);   
EXTERN  int FIN_FilterStratElt(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP);
EXTERN  int FIN_FilterStratElt2(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP);/* REF7422 - CSY - 020605 */

/* REF9658 - CHU - 040209 */
EXTERN  int FIN_FilterDerivedStratElt (DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP),
            FIN_FilterDerivedStratElt3(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP),
            FIN_FilterDerivedStratElt4(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP); /* REF6082 - CSY - 030225 */

EXTERN  int FIN_FilterGridByParMktSegtId(DBA_DYNFLD_STP ,  /* REF6025 - CSY - 010628 */
		                 		        DBA_DYNST_ENUM, 
		                 		        DBA_DYNFLD_STP);
EXTERN int FIN_FilterMktSegtByGridId(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP);

/* REF7395 - CSY - 020412: STATIC to EXTERN */
EXTERN int FIN_CmpPtfSynthPtfDate(DBA_DYNFLD_STP*, DBA_DYNFLD_STP*);		/* DVP261 */



/* REF5358 - CSY - 001123 */
EXTERN RET_CODE FIN_MergeIrregDates(DATETIME_T, DATETIME_T**, int*, TLS_CMPFCT*, int, DBA_DYNFLD_STP*, int); /* REF7264 - LJE - 020131 */

/* REF9658 - CHU - 040206 */
EXTERN RET_CODE FIN_GetStratEltFromStratIdTab(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, int, ID_T *, int *, DBA_DYNFLD_STP **);
EXTERN int		FIN_CmpSEByMktSegt(DBA_DYNFLD_STP *, DBA_DYNFLD_STP *);

/* PMSTA08737 - LJE - 091109 */
EXTERN double FIN_InstrBenchReturn(DBA_DYNFLD_STP, DATETIME_T, DATETIME_T,
		                           ID_T, RETURNTP_ENUM, RETURNNAT_ENUM,
		                           NUMBER_T, NUMBER_T, FLAG_T, 
                                   ID_T, ID_T,
                                   FIN_RETURNPARAM_STP, /* PMSTA08895 - LJE - 091102 */
                                   DBA_HIER_HEAD_STP);

/* PMSTA-16215 - LJE - 130423 */
extern RET_CODE FIN_InstrCompositeBenchReturn(DBA_HIER_HEAD_STP       hierHead,
                                      ID_T                    instrId,
                                      DBA_DYNFLD_STP          instrStp,
                                      FIN_BENCHRETPARAM_STP   benchRetParamStp,
                                      FIN_RETURNPARAM_STP     returnParamStp,
                                      TINYINT_T               freq,
                                      FREQUNIT_ENUM           freqUnit,
                                      ID_T                    contribObjectId,
                                      CONTRIBRULE_ENUM        contribRule,
                                      ID_T                    priceValRuleId,
                                      ID_T                    exchValRuleId,
                                      FLAG_T                  checkStratFlg,
                                      FLAG_T                  anaBenchFlg,
                                      ID_T                  **stratIdTabPtr,
                                      int                    *stratIdNbrPtr,
				                      DBA_DYNFLD_STP		  ESLPtr,		
                                      IDXTIMERULE_ENUM        rebalRule,
                                      DATETIME_T              rebalDate,
			                          DATETIME_T              begDate,
			                          DATETIME_T              endDate,
                                      double                 *benchRetPtr,
                                      double                 *adjWeight,
                                      FLAG_T                 *foundFlg);

extern FLAG_T FIN_IsEmptyPtfSynth(DBA_DYNFLD_STP ptfSynthStp); /* PMSTA-18200 - LJE - 140605 */

EXTERN RET_CODE FIN_FindParentPortfolioByDt(DBA_DYNFLD_STP domainPtr, ID_T ptfId, DBA_DYNFLD_STP ptfStpParam, DATE_T histDate, DBA_HIER_HEAD_STP hierHead,
	                                        ID_T& parentPtfId, DATE_T& validTillDate);
EXTERN RET_CODE FIN_FindHierPortfolioByDt(DBA_DYNFLD_STP domainPtr, ID_T ptfId, DBA_DYNFLD_STP ptfStpParam, DATE_T histDate, DBA_HIER_HEAD_STP hierHead,
	                                      ID_T& parentPtfId, DATE_T& validTillDate);
EXTERN RET_CODE FIN_FindChildrenPortfolioByDt(DBA_DYNFLD_STP domainPtr, ID_T ptfId, DBA_DYNFLD_STP ptfStpParam, DATE_T histDate, DBA_HIER_HEAD_STP hierHead,
	                                          DBA_DYNFLD_STP** childrenTab, int* childrenNbr);
EXTERN RET_CODE FIN_FindHierChildrenPortfolioByDt(DBA_DYNFLD_STP domainPtr, ID_T ptfId, DBA_DYNFLD_STP ptfStpParam, DATE_T histDate, DBA_HIER_HEAD_STP hierHead,
	                                              DBA_DYNFLD_STP** childrenTab, int* childrenNbr);
EXTERN bool FIN_IsHeadPortfolioByDt(DBA_DYNFLD_STP domainPtr, ID_T ptfId, DBA_DYNFLD_STP ptfStp, DATE_T histDate, DBA_HIER_HEAD_STP hierHead);
EXTERN RET_CODE FIN_FindHierParentPortfolio(DBA_DYNFLD_STP domainPtr, ID_T ptfId, DBA_DYNFLD_STP ptfStpParam, DBA_HIER_HEAD_STP   hierHead, DBA_DYNFLD_STP** hierParentPtfTab, int* hierParentPtfNbr);


#endif /* FINLIB02_H */

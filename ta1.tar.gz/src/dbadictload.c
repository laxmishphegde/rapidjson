/************************************************************************
**
**           Copyright (C) 1995-2024 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define DBADICTLOAD_C

/************************************************************************
**      Include files
*************************************************************************/
#define STDIO_H
#define STRING_H
#define TIME_H
#define STDLIB_H
#define MATH_H

#include <assert.h>

#include "unidef.h"     /* Mandatory */
#include "gen.h"
#include "dba.h"
#include "msg.h"
#include "csrv.h"
#include "ope.h"
#include "fmtlib01.h"   /* For GUI structures and for the FAMOUS function */
#include "ddlgen.h"  /* PMSTA-13122 - LJE - 120516 */
#include "date.h"

#include "dbi.h"
#include "rpclib.h"

using namespace std;

/************************************************************************
**      External entry points
**
**
**
*************************************************************************/
extern TIMER_ST EV_ExtractFileTimer;
extern FLAG_T   EV_IsSubscriptionActive;
extern bool     EV_UseAlternativeDataSource;

FLAG_T  EV_DictInitFlg = FALSE; /* PMSTA-22549 - CHU - 160106 */

DICT_FCT_STP*   EV_DictFctMainWithFinTab;   /*  FIH_REF5578-010115  */
DICT_FCT_STP**  EV_DictFctSubWithFinTab;    /*  FIH_REF5578-010115  */

extern int DBA_TestMDDef();
extern RET_CODE DBA_CheckCopyRights (void);


/************************************************************************
**      Local functions
**
**
** DBA_CheckDataType	Check if Sybase datatypes matchs to C datatypes
** DBA_UpdFctTab		Updating table EV_DictFctTab
** DBA_CmpDictFct		Sort DictFct tab.
**
*************************************************************************/
STATIC RET_CODE DBA_LoadDictFromFile(void);
STATIC RET_CODE	DBA_CheckDataType(void); /* REF11704 - TEB - 060502  */

STATIC void	    DBA_UpdParAttrPtr(void);
STATIC RET_CODE	DBA_UpdFctTab(void);
STATIC RET_CODE DICT_AddModifySpecialEntity(void);                               /* REF9789 - LJE - 040105 */
STATIC RET_CODE DICT_LinkFieldsToEntity(OBJECT_ENUM, OBJECT_ENUM, FIELD_IDX_T, FIELD_IDX_T, FLAG_T, FLAG_T, FLAG_T);
STATIC void     DBA_LimitMetaDictWithUserType (void);
STATIC void     DBA_CompleteMetaDict(void);
STATIC bool     DBA_CmpDictFct(const DICT_FCT_ST &, const DICT_FCT_ST &);
STATIC void     DBA_CompleteMetaDictWithDimObjLink(OBJECT_ENUM, int, int, OBJECT_ENUM);
STATIC void     DBA_CompleteMetaDictEditionMask (OBJECT_ENUM, int, ENUM_T, FLAG_T);     /*  HFI-PMSTA-38117-200202  */
STATIC RET_CODE DBA_SetNullWhileCopyFlag (DICT_ATTRIB_STP);
STATIC RET_CODE DBA_SetDictScreenRights(DICT_ENTITY_STP);
STATIC DICT_ATTRIB_STP DICT_GetExistingFieldInEntity(OBJECT_ENUM, DICT_ATTRIB_STP);
STATIC RET_CODE	DBA_UpdFctTabAdm(DICT_FCT_ENUM, DICT_T, bool);
#ifdef NEXUS
STATIC RET_CODE DBA_CreateFnSecuProf(DICT_FCT_ENUM, DICT_T, ENUM_T, ENUM_T, FLAG_T, FLAG_T, FLAG_T, FLAG_T, FLAG_T);
#endif

/************************************************************************
**      Static definitions & data
*************************************************************************/

/* DLA - REF12241 - 050610 */
#ifdef UNIX
#define _MAX_PATH  260
#define _MAX_FNAME 256
#endif

/************
** Free all meta dictionary data set
**************/
#define FREE_MD() {DBA_GetDictLangTab().clear();\
                   EV_DictFctTab.clear();\
                   DBA_GetDictDataTpTab().clear();}

/************************************************************************
**      Static definitions & data
*************************************************************************/
int EV_AAAInstallLevel = 0; /* PMSTA-14452 - LJE - 130109 */
unsigned int EV_RunSysKitInstall = 0; /* PMSTA-22549 - DDV - 160606 */
bool         EV_UseMultiAccessByBatch = false;                 /* PMSTA-37366 - LJE - 191205 */

/************************************************************************
**      Functions
************************************************************************/
/************************************************************************
*  Function             : DBA_LoadDictLabels()
*
*  Description          : Send the MD (Meta Dictionary) load request to
*
*  Arguments            : None
*
*  Return               : retCode
*
*  Creation date        :
*
*************************************************************************/
STATIC RET_CODE DBA_LoadDictLabels()
{
    DBA_DYNFLD_STP  pdbbadynShort,      /*  Short structure                 */
                    pdbbadynAll;        /*  All structure                   */
    RET_CODE        retCode;            /*  Returned value                  */
    const char      *pszLabel;          /*  Label returned by DICT_GetLabel */
    int             iOptiMem;           /*  Memorize current opti mode      */
    DICT_T          dictServerLanguage; /*  Memorize current svr language   */
    DbiConnectionHelper  dbiConnHelper(AAATransactionEnum::NotTransactionnal, SqlServer, ROLE_INIT);

    /*  initiate variable                                                   */
    retCode = RET_SUCCEED;
    pdbbadynShort = NULL;
    pdbbadynAll = NULL;
    pszLabel = NULL;

    /*  manage optimitisation                                               */
    iOptiMem = EV_OptiMemFlg;
    EV_OptiMemFlg = FALSE;

    /*  Memorize current server language                                    */
    dictServerLanguage = EV_ServerLanguageID;
    EV_ServerLanguageID = -1;

    /*  Only for server, not for GUI, not for Import                        */
    if (SYS_IsSrvMode() == TRUE)        /* code port of PMSTA-23340 - DDV - 160607 */
    {
        /*  Allocate Dynamic Structure                                      */
        if (((pdbbadynShort = ALLOC_DYNST(S_DictLang)) == NULL) ||
            ((pdbbadynAll = ALLOC_DYNST(A_DictLang)) == NULL))
            retCode = RET_MEM_ERR_ALLOC;

        if (retCode == RET_SUCCEED)
        {
            /*  Loop on dict_lang table                                         */
            /*  It was decided to only load dict_label of languages with Tsl    */
            /*  Multilingual Flag set to TRUE                                   */
            for (size_t i = 0; i < DBA_GetDictLangTab().size(); i++)
            {
                SET_DICT(pdbbadynShort,S_DictLang_Id, DBA_GetDictLangTab()[i].dictId);
                if ((dbiConnHelper.dbaGet(DictLang,
                              UNUSED,
                              pdbbadynShort,
                              &(pdbbadynAll)) == RET_SUCCEED) &&
                    (GET_FLAG(pdbbadynAll,A_DictLang_TslMultilingualFlg) == TRUE))
                {
                    DICT_GetLabel(DBA_GetDictLangTab()[i].dictId, 1101, 100, &pszLabel, dbiConnHelper);
                }
            }

            /*  Liberate allocated memory                                       */
            FREE_DYNST(pdbbadynShort, S_DictLang);
            FREE_DYNST(pdbbadynAll, A_DictLang);
        }
    }


    /*  Reinit global variable with initial value                               */
    EV_OptiMemFlg = iOptiMem;
    EV_ServerLanguageID = dictServerLanguage;

    return retCode;
}


/************************************************************************
*  Function             : DBA_LoadDict2()
*
*  Description          : Try to load MD using local file (only GUI on NT)
*                         if error or file is not up to date,
*                         load it from database
*
*  Arguments            : None
*
*
*  Return               : RET_SUCCEED             : if ok
*                         RET_DBA_ERR_DBPROBLEM   : if problem with DB
*                         RET_DBA_ERR_SYBBIND     : if error while
*                                                   binding fields
*                         RET_DBA_ERR_SETPARAM    : if error while setting
*                                                   proc parameters.
*                         RET_DBA_ERR_MD          : if meta-dictionary
*                                                   is inconsistent
*                         RET_DBA_ERR_CONNOTFOUND : if no conn. found
*                         RET_MEM_ERR_ALLOC       : if memory alloc. failed
*
*  Creation date        : REF2744 - 990202 - DDV
*  Last modification    :
*
*************************************************************************/
STATIC RET_CODE DBA_LoadDict2(FLAG_T tryGetFromFileFlg, FLAG_T lightLoadFlg)
{
    RET_CODE retCode = RET_DBA_ERR_MD;

    if (lightLoadFlg == TRUE)
    {
        retCode = DBI_LoadDictForSql(DBA_GetDictLangTab(), DBA_GetDictDataTpTab());

        if (retCode != RET_SUCCEED)
        {
            FREE_MD();
        }
    }
    /* PMSTA-37374 - LJE - 210408 */
    else if (SYS_IsDdlGenMode() == TRUE &&
             EV_UseAlternativeDataSource &&
             EV_GenDdlContext.optionPtr != nullptr &&
             (strstr(EV_GenDdlContext.optionPtr, "M") != nullptr ||
              strstr(EV_GenDdlContext.optionPtr, "m") != nullptr))
    {
        retCode = DBI_LoadDictForMig();

        if (retCode == RET_SUCCEED)
        {
            retCode = DBI_LoadDict(DBA_GetDictLangTab(), DBA_GetDictDataTpTab());
            if (retCode != RET_SUCCEED)
            {
                FREE_MD();
            }
        }
    }
    else if (EV_AAAInstallLevel < 100)
    {

        if (tryGetFromFileFlg == TRUE)
        {
            retCode = DBA_LoadDictFromFile();

            if (retCode != RET_SUCCEED)
            {
                FREE_MD();
            }
        }

        /* if load from file failed or not NT, load MD from database */
        if (retCode != RET_SUCCEED && retCode != RET_DBA_INFO_DUMP_MD_FAILED)
        {
            retCode = DBI_LoadDict(DBA_GetDictLangTab(), DBA_GetDictDataTpTab());

            if (retCode != RET_SUCCEED)
            {
                FREE_MD();
            }
        }

    }
    else
    {
        retCode = RET_SUCCEED;
    }
    return(retCode);
}


/************************************************************************
*  Function             : DBA_LoadDictFromFile()
*
*  Description          : Try to load MD using local file (only GUI on NT)
*                         if error or file is not up to date,
*                         load it from database
*
*  Arguments            : None
*
*
*  Return               : RET_SUCCEED             : if ok
*                         RET_DBA_ERR_DBPROBLEM   : if problem with DB
*                         RET_DBA_ERR_SYBBIND     : if error while
*                                                   binding fields
*                         RET_DBA_ERR_SETPARAM    : if error while setting
*                                                   proc parameters.
*                         RET_DBA_ERR_MD          : if meta-dictionary
*                                                   is inconsistant
*                         RET_DBA_ERR_CONNOTFOUND : if no conn. found
*                         RET_MEM_ERR_ALLOC       : if memory alloc. failed
*
*  Creation date        : REF2744 - 990203 - DDV
*  Last modification    : PMSTA-13729 - 040412 - PMO : Full support of 64bit on Unix platforms
*
*************************************************************************/
STATIC RET_CODE DBA_LoadDictFromFile()
{
    RET_CODE retCode = RET_DBA_ERR_MD;

#if 0

    FLAG_T   retryToOpenFile = FALSE, updateFile = FALSE;

    char     *fileName = (char *) CALLOC(_MAX_PATH+_MAX_FNAME, sizeof(char));
    unsigned char *bufferMD = NULL;
    FILEDES hFile;            /* PMSTA-13729 - 040412 - PMO */

    if (fileName == NULL)
    {
        MSG_RETURN(RET_MEM_ERR_ALLOC);
    }

    memset(fileName, 0, _MAX_PATH+_MAX_FNAME);

    /* check parameters to know if file is used and where it is stored */
    if ((retCode = DBA_GetMDFileName(fileName)) != RET_SUCCEED)
    {
        FREE(fileName);
        return(retCode);
    }

    do
    {
        /*  FIH-REF7320-020122  Possible infinite loop without next statement   */
        retryToOpenFile = FALSE;

        /* try to open file in read mode */
        if ((retCode = DBA_MDLoadFile(fileName, &bufferMD)) == RET_FILE_ERR_NOTEXIST)
        {
            updateFile = TRUE;
        }
        else if (retCode == RET_DBA_ERR_MD_CHECKSUM_FAILED)
        {
            /* Message Error Checksum */
            MSG_SendMesg(RET_DBA_ERR_MD_CHECKSUM_FAILED, 0,
                         FILEINFO, fileName);
            updateFile = TRUE;
        }
        else if (retCode != RET_SUCCEED)
        {
            FREE(fileName);
            FREE(bufferMD); /* PMSTA-memory leak - LJE - 110204 */
            return(retCode);
        }
        else
        {
            /* load date and check it with table modif stat value */
            if ((retCode = DBA_MDCheckDate(bufferMD)) == RET_DBA_INFO_MD_FILE_TOO_OLD)
            {
                updateFile = TRUE;
            }
            else if (retCode == RET_DBA_ERR_MD_WRONG_DB)
            {
                MSG_SendMesg(RET_DBA_ERR_MD_WRONG_DB, 0, FILEINFO);
                updateFile = TRUE;
            }
            else if (retCode != RET_SUCCEED)
            {
                MSG_SendMesg(RET_DBA_ERR_MD_READ_FILE_FAILED, 0,
                             FILEINFO, fileName);
                FREE(fileName);
                FREE(bufferMD); /* PMSTA-memory leak - LJE - 110204 */
                return(retCode);
            }
            else
            {
                int loadDictEntityRows;
                int loadDictAttribRows;
                int loadDictCriterRows;
                int loadDictPermValRows;

                /* read block size */
                if ((retCode = DBA_MDReadSize(bufferMD,
                                  &loadDictEntityRows,
                                  &loadDictAttribRows,
                                  &loadDictCriterRows,
                                  &loadDictPermValRows)) != RET_SUCCEED)
                {
                    updateFile = TRUE;
                }
                else
                {
                    /*****************************************************************/
                    /* Allocate memory for data set */

                    if ((SV_LoadDictLangTab = (DICT_LANG_STP)
                        CALLOC(SV_LoadDictLangRows, sizeof(DICT_LANG_ST))) == NULL)
                    {
                        FREE(fileName);
                        FREE(bufferMD); /* PMSTA-memory leak - LJE - 110204 */
                        MSG_RETURN(RET_MEM_ERR_ALLOC);
                    }

                    if ((DBA_GetDictDataTpTab() = (DICT_DATATP_STP)
                        CALLOC(SV_LoadDictDataTpRows, sizeof(DICT_DATATP_ST))) == NULL)
                    {
                        FREE(fileName);
                        FREE(bufferMD); /* PMSTA-memory leak - LJE - 110204 */
                        MSG_RETURN(RET_MEM_ERR_ALLOC);
                    }

                    /* read file */
                    if ((retCode = DBA_MDReadBlock(bufferMD,
                                       SV_LoadDictLangTab,
                                                   DBA_GetDictDataTpTab())) != RET_SUCCEED)
                    {
                        /* Message Error reading file */
                        MSG_SendMesg(RET_DBA_ERR_MD_READ_FILE_FAILED, 0,
                                             FILEINFO, fileName);
                        updateFile = TRUE;
                    }

                    if (retCode == RET_SUCCEED)
                    {
                        FREE(fileName);
                        FREE(bufferMD); /* PMSTA-memory leak - LJE - 110204 */
                        return(retCode);
                    }
                }
            }
            FREE(bufferMD); /* PMSTA-memory leak - LJE - 110204 */
        }

        if (updateFile == TRUE)
        {
            /* GetDbDate */

            /* load MD from DB and store it in file */
            if ((retCode = DBA_MDOpenWriteFile(fileName,&hFile)) == RET_DBA_INFO_MD_UPD_IN_PROGRESS)
                retryToOpenFile = TRUE;
            else if (retCode != RET_SUCCEED)
            {
                MSG_SendMesg(RET_DBA_ERR_MD_WRITE_FILE_FAILED, 0,
                                     FILEINFO, fileName);
                FREE(fileName);
                return(retCode);
            }
            else
            {
                if ((retCode = DBI_LoadDict(
                    &SV_LoadDictLangTab,
                    &DBA_GetDictDataTpTab(),
                    &SV_LoadDictLangRows,
                    &SV_LoadDictDataTpRows)) != RET_SUCCEED)
                {
                    FREE(fileName);
                    return(RET_DBA_INFO_DUMP_MD_FAILED);
                }

                retCode = DBA_MDWriteFile(
                              SV_LoadDictLangTab,
                    DBA_GetDictDataTpTab(),
                              SV_LoadDictLangRows,
                              SV_LoadDictDataTpRows,
                              hFile);

                if (retCode != RET_SUCCEED)
                {
                    MSG_SendMesg(RET_DBA_ERR_MD_WRITE_FILE_FAILED, 0,
                                     FILEINFO, fileName);
                }

                DBA_MDCloseWriteFile(fileName,hFile);
                retCode = RET_SUCCEED;
            }
        }

    } while (retryToOpenFile == TRUE);

    FREE(fileName);
#endif
    return(retCode);
}

/************************************************************************
**  Function             : DBA_InitDictInfo()
**
**  Description          : Init meta-dictionary informations
**  - SV_LoadDictEntityTab     informations about all entities order by entity
**                         dict id. For each entity pointers on her attributes
**                         and criteria lists are created.
**    SV_LoadDictEntityRows    rows in table SV_LoadDictEntityTable
**
**  - SV_LoadDictAttribTab     informations about all entities attributes order
**                         by entity dict id and attribute progN.
**                         If necessary, pointer on attributes permitted
**                         values is created.
**                         Create for each entity an attributes table with
**                         SV_LoadDictAttribTab entity part and internal fields
**
**    SV_LoadDictAttribRows    rows in table SV_LoadDictAttribTable
**
**  - SV_LoadDictCriterTab     informations about all entities criteria order by
**                         entity dict id and attribute progN.
**    SV_LoadDictCriterRows    rows in table SV_LoadDictCriterTable
**
**  - SV_LoadDictPermValTab    informations about all attributes permitted values
**                         order by entity dict id, attribute progN and
**                         permitted values rank.
**    SV_LoadDictPermValRows   rows in table SV_LoadDictPermValTable
**
**  Arguments            : None
**
**  Return               : RET_SUCCEED or error code
**
**  Modification         : DVP037 - 960429 - DED : Delete line with change of datatype
**                       : ROI - 961108 - DVP245
**                       : XFH - 970902 - DVP580 : Manage use screen flag
**                       : ROI - 970916 - DVP587 : Manage inputCtrlFlg
**                       : RAK - 980402 - REF1357 : Manage parent permitted value on flag
**                         PMSTA-30889 - 100418 - PMO : SYBASE VS ORACLE: financial server crash while running the PVN_PMSTA_9790 TaAutomator test case
**
*************************************************************************/
RET_CODE DBA_InitDictInfo(FLAG_T tryGetFromFileFlg, FLAG_T lightLoadFlg)
{
    RET_CODE        ret;
    int             saveOptiMemFlg;

    if (SYS_IsBatchMode() || SYS_IsSqlMode()) /* PMSTA-26108 - LJE - 170821 - Only for import and aaa_sql tools */
    {
        EV_RunSysKitInstall = SYS_GetEnvIntOrDefValue("RUN_SYS_KIT_INSTALL", 0); /* PMSTA-22496 - DDV - 160606 */
    }
    EV_UseMultiAccessByBatch = SYS_GetEnvBoolOrDefValue("AAAMULTIACCESSBYBATCH", (EV_RdbmsVendor != Sybase));    /* PMSTA-37366 - LJE - 191205 */

    bool bEnableAdditionalDSP = SYS_GetEnvBoolOrDefValue("ENABLE_ADDITIONAL_DSP", true);    /* PMSTA-nuodb - LJE - 190724 */

    /* REF8844 - LJE - 030428 */
    saveOptiMemFlg = EV_OptiMemFlg;
    EV_OptiMemFlg  = FALSE;
    DICT_AddNewDictEntity(0, InvalidEntity, "invalid_entity", "invalid_entity");

    if ((ret = DBA_LoadDict2(tryGetFromFileFlg, lightLoadFlg)) == RET_SUCCEED)
    {

        EV_OptiMemFlg = saveOptiMemFlg;

        /* ------------------------------------------------------- */
        /* Init SV_LoadDictEntityTab attributes and criteria pointers */
        /*                                                         */
        /* Table SV_LoadDictAttribTab is order by                      */
        /* entity dict id and database attribute progN.            */
        /* This pointer will be modified because of logical and    */
        /* customer fields.                                        */
        /*                                                         */
        /* Table SV_LoadDictCriterTab is order by entity dict id       */
        /* and attribute progN. In entities table the attributes   */
        /* and criteria number are known. So, we can read just    */
        /* on time the entities, attributes and criteria tables.  */
        /* ------------------------------------------------------- */
        for (auto it = DICT_GetDictEntityVector().begin(); it != DICT_GetDictEntityVector().end(); ++it)
        {
            DICT_ENTITY_STP dictEntityStp = *it;

            /* PMSTA-16575 - LJE - 130626 */
            if (bEnableAdditionalDSP == false &&
                dictEntityStp->securityLevelEn == EntSecuLevel_Secured2ndLevel &&
                SYS_IsDdlGenMode() == FALSE &&
                EV_AAAInstallLevel == 0)
            {
                MSG_SendMesg(RET_DBA_ERR_MD, 6, FILEINFO, "Please refresh the environment (install_ddl ... dat dict ...) after change the variable ENABLE_ADDITIONAL_DSP");
                return(RET_DBA_ERR_MD);
            }

            dictEntityStp->finish();
        }

        /* REF8844 - LJE - 030404 */
        CSRV_Init2();
        DBA_InitObjectAndDynSt();
        DBA_UpdDictCriteria(NullEntity, lightLoadFlg == TRUE);
        DBA_InitDynStPtr();
        DBA_CreateDynStDef();

        /* Check MD data-types en C data-types */
        if ((EV_GenDdlContext.bCheck || EV_AAAInstallLevel > 0) &&
            (ret = DBA_CheckDataType()) != RET_SUCCEED)
        {
            MSG_SendMesg(RET_DBA_ERR_MD, 0, FILEINFO);
            FREE_MD();
            return(ret);
        }

        /* ---------------------------------------------------------- */
        /* Create for each entity an attributes table with fixed      */
        /* fields, internal fields, customer fields and logical       */
        /* fields order by new progN.                                 */
        /* ---------------------------------------------------------- */
        if ((ret = DBA_GenerateAllAttrib()) != RET_SUCCEED)
        {
            MSG_SendMesg(RET_DBA_ERR_MD, 0, FILEINFO);
            FREE_MD();
            return(ret);
        }
        DBA_UpdCrossLinkAttr();

        DBA_TestMDDef();

        /* ---------------------------------------------------------- */
        /* Init parent attribute entity and progN, so it will be      */
        /* possible to get all parent attribute informations          */
        /*                                                            */
        /* Init table SV_LoadDictAttribTab pointers (on permitted values)  */
        /* using parent attribute because of permitted values          */
        /* (for enum) are once in SV_LoadDictPermValTab table.            */
        /*                                                            */
        /* Update pointer on parent attribute                         */
        /* (access on parent will be direct ) + unique visual key idx */
        /* ---------------------------------------------------------- */
        DBA_UpdParAttrPtr();

        if (ret == RET_SUCCEED)
        {
            CSRV_Init3();   /*  FPL-081114-PMSTA07223-PMSTA07427 move code here from lower  */

            ret = EV_CheckErrorLevel; /* PMSTA-14452 - LJE - 121023 */
        }

        /* ---------------------------------------------------------- */
        /* Update all maximum length information - PMSTA07121 - DDV - 090309 */
        /* ---------------------------------------------------------- */
        if ((ret = DBA_UpdateDynStMaxLength()) != RET_SUCCEED)
        {
            MSG_SendMesg(RET_DBA_ERR_MD, 0, FILEINFO);
            return(ret);
        }

        if (ret == RET_SUCCEED)
        {
            DATE_FillDayMonthName();
        }

        if (ret == RET_SUCCEED)
        {
            if (SYS_IsSqlMode() == FALSE)
            {
                ret = DICT_AddModifySpecialEntity();

                /*  FIH-REF10778-041123 */
                if ((ret == RET_SUCCEED) && (SYS_IsGuiMode() == TRUE))
                {
                    DBA_LimitMetaDictWithUserType();
                }

                /*  FIH-REF11457-051005 */
                DBA_CompleteMetaDict();

                /*  Check that the copy process can be applied ... without problem  */  /*  HFI-PMSTA-51611-2023-01-24  */
                DBA_CheckCopyRights();

                if (EV_AAAInstallLevel < 5)
                {
                    ret = DBA_InitCreateTempTables();
                }

                if (ret == RET_SUCCEED && EV_AAAInstallLevel <= 2) /* PMSTA-26966 - LJE - 170412 */
                {
                    /*  FPL-PMSTA08877-091029 Fill arrays of conversion for operations  */
                    ret = OPE_FillConvOpArray();

                    if (ret == RET_SUCCEED)
                    {
                        /*  HFI-PMSTA-20754-150706  Load dict_label only tsl_multilingual_f = TRUE language */
                        ret = DBA_LoadDictLabels();
                    }
                }
            }
            else if (EV_AAAInstallLevel < 5)
            {
                ret = DBA_InitCreateTempTables();
                if (lightLoadFlg == FALSE)
                {
                    ret = DICT_AddModifySpecialEntity();
                }
            }
            else if (EV_AAAInstallLevel == 6)
            {
                ret = DICT_AddModifySpecialEntity();
            }

            /* PMSTA-46681 - LJE - 230125 */
            if (ret == RET_SUCCEED && EV_AAAInstallLevel == 0)
            {
                ret = DBA_InitDictUserMap();
            }
        }
        else
        {
            ret = DBA_InitCreateTempTables();
        }

        EV_DictInitFlg = TRUE; /* PMSTA-22549 - CHU - 160106 */ /* PMSTA-26108 - LJE - 171029- Move here */

        /*  Proxy mode: ensure the business entity info is well initialized in the thread properties            */  /*  HFI-PMSTA-50583-221014  */
        /*  This is copy of the code present in SYS_SetAllThreadContextPropertiesGEN_InitPoolConnectionFinal    */
        if (EV_RdbmsVendor == QtHttp)
        {
            CODE_T       currentApplSessionCode;
            currentApplSessionCode[0] = END_OF_STRING;
            DBA_GetApplSessionCode(&currentApplSessionCode, ROLE_INIT);

            DbiConnectionHelper dbiConnHelper;
            if (dbiConnHelper.isValidAndInit())
            {
                SYS_SetAllThreadContextProperties(*dbiConnHelper.getConnection(), currentApplSessionCode, ROLE_INIT);
            }
        }


        if (EV_AAAInstallLevel == 0 && SYS_IsSqlMode() == FALSE) /* PMSTA-11505 - LJE - 110711 */
        {
            /* ---------------------------------------------------------- */
            /* load dict function from database                           */
            /* Updating table EV_DictFctTab         ROI - 961108 - DVP245 */
            /* ---------------------------------------------------------- */
            if ((ret = DBI_LoadDictFct()) != RET_SUCCEED ||
                (ret = DBA_UpdFctTab()) != RET_SUCCEED)
            {
                /* PMSTA-29256 - 050418 - CMILOS */
                if ((SYS_IsGuiMode() == TRUE) && ((ret == RET_DBA_ERR_CONNOTFOUND) || (ret == RET_DBA_ERR_DBPROBLEM)))
                {
                    char buffer[256];
                    sprintf(buffer, "Cannot connect to Data server %s", DBI_GetSqlServerName().c_str());
                    MSG_DispMsgText(RET_SUCCEED, buffer);
                }
                else
                {
                    MSG_SendMesg(ret, 0, FILEINFO);
                }
                return(ret);
            }

        }

        /* ---------------------------------------------------------------- */
        /*  FIH-REF6135-010716                                              */
        /*  Manage and test the different client type                       */
        /* ---------------------------------------------------------------- */
        if ((ret == RET_SUCCEED) && (SYS_IsGuiMode() == TRUE))
        {
            /*  FIH-REF6135-010713  Manage and test the different client type   */
            INFO_T              info;
            GEN_USERTYPE_ENUM   userType = UserNormal;
            FLAG_T              superUserFlg;
            std::string         userLogin;
            DICT_FCT_STP        fctStp;
            OBJECT_ENUM         objectEn;

            /* ---------------------------------------------------------------- */
            /*  Detect user type                                                */
            /* ---------------------------------------------------------------- */
            info[0] = END_OF_STRING;
            GEN_GetApplInfo(ApplLicensePack, info);
            if (info[0] != END_OF_STRING)
            {
                if ((ret = DBA_GetUserInfo(A_ApplUser_SuperuserFlg, (PTR)&superUserFlg)) != RET_SUCCEED)
                {
                    MSG_SendMesg(RET_DBA_ERR_MD, 0, FILEINFO);
                    return ret;
                }
                if (superUserFlg == FALSE)
                    userType = UserPackEndUser;
                else
                {
                    GEN_GetUserInfo(UserLogin, userLogin);
                    if (SYS_GetEnv("AAAOAMSDVPALLRIGHT") != NULL)
                        userType = UserNormal;
                    else if ((strncasecmp(userLogin.c_str(), "oly", 3) == 0) &&   /*  FIH-REF6203-010806  */
                             ((userLogin.length() == 3) ||
                             ((userLogin.length() == 5) &&
                             (userLogin[3] == '_') &&
                             (userLogin[4] >= '0') &&
                             (userLogin[4] <= '9'))))
                             userType = UserPackConsultant;
                    else
                        userType = UserPackSuperUser;
                }
            }
            else
                userType = UserNormal;
            GEN_SetUserInfo(UserType, &userType);

            /* ---------------------------------------------------------------- */
            /*  Suppress some part of meta-dictionary according to user type    */
            /* ---------------------------------------------------------------- */
            if ((userType == UserPackEndUser) ||
                (userType == UserPackSuperUser))
            {
                for (auto it = DICT_GetDictEntityVector().begin(); it != DICT_GetDictEntityVector().end(); ++it)
                {
                    DICT_ENTITY_STP dictEntityStp = *it;

                    /*  Suppress possibility to access input control                */
                    dictEntityStp->inputCtrlFlg = FALSE;

                    /*  Suppress  all access to invisible entity                       */
                    for (auto& dictAttribStp : dictEntityStp->attr)
                    {
                        if (dictAttribStp->logicalFlg == TRUE)
                        {
                            DBA_GetObjectEnum(dictAttribStp->refEntDictId, &objectEn);
                            if ((DBA_GetDictFctAdmAuth(DictFct_Admin, objectEn, DictFctInfo_Stp, &fctStp) != RET_SUCCEED) ||
                                (fctStp->accesStatus != DictFctAuth_Ok))
                            {
                                dictAttribStp->refEntDictId = 0;
                            }
                        }
                    }
                }
            }

            /* ---------------------------------------------------------------- */
            /*  Test coherence between user type and func_secu_profile          */
            /* ---------------------------------------------------------------- */
            if (ret == RET_SUCCEED)
            {
                /*  Test func:screen_profile access          */
                if (((userType == UserPackEndUser) ||
                    (userType == UserPackSuperUser) ||
                    (userType == UserPackConsultant)) &&
                    ((DBA_GetDictFctInfo(DictFct_EventGeneration, DictFctInfo_Stp, (PTR)&fctStp) != RET_SUCCEED) ||
                    (fctStp->visibleFlag == TRUE)))
                    ret = RET_ENV_ERR_WRONGLICENSEKEY;

                /*  Test scrip_definition access             */
                if (((userType == UserPackEndUser) ||
                    (userType == UserPackSuperUser)) &&
                    ((DBA_GetDictFctAdmAuth(DictFct_Admin, ScriptDef, DictFctInfo_Stp, &fctStp) != RET_SUCCEED) ||
                    (fctStp->visibleFlag == TRUE)))
                    ret = RET_ENV_ERR_WRONGLICENSEKEY;

                /*  Test func:secu_profile access            */
                if ((userType == UserPackSuperUser) &&
                    ((DBA_GetDictFctAdmAuth(DictFct_Admin, FctSecuProf, DictFctInfo_Stp, &fctStp) != RET_SUCCEED) ||
                    (fctStp->visibleFlag == TRUE)))
                    ret = RET_ENV_ERR_WRONGLICENSEKEY;

                /*  Test func:screen_profile access          */
                if ((userType == UserPackSuperUser) &&
                    ((DBA_GetDictFctAdmAuth(DictFct_Admin, ScreenProf, DictFctInfo_Stp, &fctStp) != RET_SUCCEED) ||
                    (fctStp->visibleFlag == TRUE)))
                    ret = RET_ENV_ERR_WRONGLICENSEKEY;
            }
        }

        /* PMSTA-45413 - LJE - 210611 */
        if (ret == RET_SUCCEED)
        {
            DbiConnectionHelper dbiConnHelper(AAATransactionEnum::NotTransactionnal, SqlServer, ROLE_INIT);
            ret = DBA_InitOptiTab(dbiConnHelper);
        }

        /* PMSTA-20350 - DDV - 150427 */
        if (ret == RET_SUCCEED && SYS_IsDdlGenMode() == FALSE) /* code port of PMSTA-23340 - DDV - 160607 */
        {
            if (EV_AAAInstallLevel <= 1)
            {
                EV_RpcCollection.getListRpcProperties(); /* PMSTA-24563 - LJE - 160905 - Init RPC parameters */
            }

            bool debug = false;
            if (debug)
            {
                RpcCollection::DISP(EV_RpcCollection); /* PMSTA-27710 - FME - 170706 - All (not internal) RPC must have an appl_session_code parameter */
            }
        }
    }

    /* PMSTA-14452 - LJE - 121023 */
    if (ret != RET_SUCCEED)
    {
        printf("%s\n","Error while loading meta dictionary (see $AAAHOME/msg/log file)");

        /* !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! */
        /* !!!!!! Have a look on the standard output !!!!!! */
        /* !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! */
        SYS_BreakOnDebug();
    }

    if (EV_AAAInstallLevel <= 1 && lightLoadFlg == FALSE)
    {
        /* Verify if the subscription is activated. REF4204 */
        GEN_GetApplInfo(ApplSubscriptionActiveFlag, &EV_IsSubscriptionActive);

        /* PMSTA-26108 - LJE - 171028 - Init some appl param */
        QUESTIONNAIRE_LICENSEE_ENUM questLevelEn = QuestionnaireLicensee_NoValue;
        GEN_SetApplInfo(ApplQuestionnaireLicence, &questLevelEn);
    }

    return(ret);
}

/************************************************************************
**
**  Function    :   DBA_UnsetFctAuth
**
**  Description :   Unset all function security authorization except for administration.
**
**  Argument    :   None
**
**  Return      :   RET_CODE
**
**  Creation    :   FIH - 980506 - REF2037
**  Modified    :   FPL-REF8080-021015
**
*************************************************************************/
RET_CODE    DBA_UnsetFctAuth (void)
{
    OPNAT_ENUM      opNatEn;
    OBJECT_ENUM     objEn;
    DICT_T          dictId;

    DBA_GetDictId(Op, &dictId);
    for (auto fctStp = EV_DictFctTab.begin(); fctStp != EV_DictFctTab.end(); fctStp++)
    {
        if (fctStp->dictId == DictFct_Admin)
        {
            /* FPL-REF8080-021016 */
            DBA_GetObjectEnum(fctStp->entityDictId, &objEn);
            if ((OPE_DictEnumToOperNat(objEn, &opNatEn) == RET_SUCCEED) ||
                (fctStp->entityDictId == dictId))
            {
                fctStp->createFlag = FALSE ;
                fctStp->updateFlag = FALSE ;
                fctStp->deleteFlag = FALSE ;
            }
        }
        else
            fctStp->accesStatus = DictFctAuth_None;
    }

    /* FPL-REF8080-021016 */
    if (DBA_GetDictId(Op, &dictId) == TRUE)
        DBA_UpdFctTabAdm(DictFct_Admin, dictId, false);

    return RET_SUCCEED;
}

#ifdef NEXUS
/************************************************************************
**
**  Function    :   DBA_SetFnSecuProfNexus
**
**  Description :   Updating table EV_DictFctTab
**
**  Argument    :
**
**  Return      :
**
**  Creation    :   FPL-REF10260-040519
**
************************************************************************/
STATIC RET_CODE    DBA_SetFnSecuProfNexus()
{
    DICT_FCT_STP    fctStp       ;
    int             iCpt         ;
    int             iFctNb       ;
    OBJECT_ENUM     entityRef    ;
    DICT_T          entityDictId ;
    OBJECT_ENUM     *entityAdminTab[] = { &Archive
                                        , &ExecutionEnt
                                        , &GlExecFeeEnt
                                        , &UnMatchedExecution
                                        , &UnMatchedGlExecFee
                                        , &Op
                                        , &PtfChrono
                                        , &Ptf
                                        , &PtfThirdCompo
                                        , &NullEntity
                                        };

    iFctNb = EV_DictFctTab.size();

    /***    Step 1  :   Disable right on certain lines  ***/
    for (iCpt = 0 ; iCpt < iFctNb ; iCpt++)
    {
        fctStp = &(EV_DictFctTab[iCpt]);
        DBA_GetObjectEnum(fctStp->entityDictId, &entityRef);

        if (((fctStp->parFctDictId != DictFct_ExternalFunction ) &&
             (fctStp->parFctDictId != DictFct_Report               ) &&
             (fctStp->parFctDictId != DictFct_DisplayChrono        ) &&
             (fctStp->parFctDictId != DictFct_YieldCurve           ) &&
             (fctStp->parFctDictId != DictFct_Admin                )) ||
             (fctStp->dictId == DictFct_ExternalFunction     ) ||
            ((fctStp->parFctDictId == DictFct_Admin   ) &&
             ((entityRef == Archive              ) ||
              (entityRef == ExecutionEnt         ) ||
              (entityRef == GlExecFeeEnt         ) ||
              (entityRef == UnMatchedExecution   ) ||
              (entityRef == UnMatchedGlExecFee   ) ||
              (entityRef == Op                   ) ||
              (entityRef == PtfChrono            ) ||
              (entityRef == Ptf                  ) ||
              (entityRef == PtfThirdCompo        )
             )
            )
           )
        {
            fctStp->createFlag  = FALSE ;
            fctStp->deleteFlag  = FALSE ;
            fctStp->updateFlag  = FALSE ;
            fctStp->viewFlag    = FALSE ;
            fctStp->visibleFlag = FALSE ;
        }
    }


    /***    Step 2  :   Create new lines  ***/

    /*  if admin at least one flag with true, we need to add security on certain entity */
    DBA_GetDictId(NullEntity, &entityDictId);
    if ((DBA_GetDictFctAdmAuth(DictFct_Admin, NullEntity, DictFctInfo_Stp, &fctStp) == RET_SUCCEED) &&
        (fctStp->dictId == DictFct_Admin) &&
        (fctStp->entityDictId == entityDictId) &&
        ((fctStp->createFlag  == TRUE) ||
         (fctStp->updateFlag  == TRUE) ||
         (fctStp->deleteFlag  == TRUE) ||
         (fctStp->viewFlag    == TRUE) ||
         (fctStp->visibleFlag == TRUE)
        )
       )
    {

        iCpt = 0 ;
        while (*entityAdminTab[iCpt] != NullEntity)
        {
            DBA_GetDictId(*entityAdminTab[iCpt], &entityDictId);
            if ((DBA_GetDictFctAdmAuth(DictFct_Admin, *entityAdminTab[iCpt], DictFctInfo_Stp, &fctStp) == RET_SUCCEED) &&
                ((fctStp->dictId != DictFct_Admin) &&
                 (fctStp->entityDictId != entityDictId)
                )
               )
            {
                DBA_CreateFnSecuProf ( DictFct_Admin        /*  fn              */
                                     , entityDictId         /*  entity          */
                                     , 0                    /*  min status      */
                                     , 0                    /*  max status      */
                                     , FALSE                /*  create flag     */
                                     , FALSE                /*  update flag     */
                                     , FALSE                /*  delete flag     */
                                     , FALSE                /*  view flag       */
                                     , FALSE                /*  visible flag    */
                                     );
            }

            iCpt++ ;
        }

    }

    return RET_SUCCEED ;
}
#endif

/************************************************************************
**
**  Function    :   DBA_AdaptMetaDictToMaster
**
**  Description :   Adapt MetaDict To Master Environment
**                  Some function cannot be run on master environment
**                  Some entities cannot be created, modifed or deleted
**
**  Argument    :   none
**
**  Return      :   RET_CODE
**
**  Creation	:   HFI-PMSTA-33431-191027
**
*************************************************************************/
RET_CODE DBA_AdaptMetaDictToMaster (void)
{
    DICT_ENTITY_STP pdictent;
    DICT_FCT_STP    fctStp, parFctStp;
    DICT_T          dictParFct;
    RET_CODE        retCode = RET_SUCCEED;

    /*  Adapt functions list */
    for (auto it = EV_DictFctTab.begin(); it != EV_DictFctTab.end(); ++it)
    {
        /* Init loop variable */
        fctStp = &(*it);

        parFctStp = NULL;

        if (fctStp->parFctDictId == 0)
        {
            fctStp->parFctDictId = fctStp->dictId;
            dictParFct =  fctStp->dictId;
        }
        else
        {
            /*  Manage sub function of sub function     */
            if ((dictParFct = fctStp->parFctDictId) >= DictFct_LastFromMetadictionary)
            {
                size_t s = 0;
                for (;(s < EV_DictFctTab.size()) && (EV_DictFctTab[s].dictId != fctStp->parFctDictId); s++);
                if (s < EV_DictFctTab.size())
                {
                    dictParFct = EV_DictFctTab[s].parFctDictId;
                }
            }

            if (dictParFct < DictFct_LastFromMetadictionary)
                retCode = DBA_GetDictFctInfo(dictParFct, DictFctInfo_Stp, (PTR) &(parFctStp));
            else
            {
                MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, fctStp->procName, "parent_function");
                retCode = RET_GEN_ERR_INVARG;
            }
            if (retCode != RET_SUCCEED)
                return retCode;
        }

        switch (dictParFct)
        {
            /*  Authorised functions            */
            case DictFct_Zoom:
            case DictFct_QuickSearch:
            case DictFct_Search:
            case DictFct_UpdateField:
            case DictFct_UpdateDraft:
            case DictFct_EditStrategyObjectives:
            case DictFct_YieldCurve:
            case DictFct_ExternalFunction:
            case DictFct_UpdateData:
            case DictFct_WuiMenuSecurity:
            case DictFct_DisplayComplianceChrono:
            case DictFct_SelectGridMktSgt:
            case DictFct_DispChangeSet:
            case DictFct_MenuSecurity:
            case DictFct_CurrencyModify:
            case DictFct_ComputeInstrumentChrono:
            case DictFct_ComputeComplianceChrono:
                break;

            /*  administration functions        */
            case DictFct_Admin:
            case DictFct_StratAdmin:
            case DictFct_ConstraintAdministration:
                /*  remove rights on existing compo in the function security profile composition    */
                /*  linked to business only entities                                                */
                if ((fctStp->entityDictId != 0) &&
                    ((pdictent = DBA_GetDictEntityByDictId(fctStp->entityDictId)) != NULL) &&
                    ((pdictent->multiEntityCateg.get() == MultiEntityCategory_BusinessEntityOnly) ||
                     (pdictent->multiEntityCateg.get() == MultiEntityCategory_DerivedBusinessEntityOnly)))
                {
                    fctStp->createFlag = FALSE;
                    fctStp->updateFlag = FALSE;
                    fctStp->deleteFlag = FALSE;
                }
                break;

            /*  Forbiden functions              */
            default:
                fctStp->accesStatus = DictFctAuth_Master;
        }
    }
    /*  Add a compo in the function security profile composition for business only entities         */
    int iNbMasterEnt = 0;
    for (OBJECT_ENUM enObj = 0; enObj < LASTOBJECT; enObj++)
    {
        pdictent = DBA_GetDictEntitySt(enObj);
        if ((pdictent != NULL) &&
            ((pdictent->multiEntityCateg.get() == MultiEntityCategory_BusinessEntityOnly) ||
             (pdictent->multiEntityCateg.get() == MultiEntityCategory_DerivedBusinessEntityOnly)))
        {
            iNbMasterEnt++;
        }
    }
    if (iNbMasterEnt != 0)
    {
        PERMITED_VALUES_STP permValTab = nullptr;
        int                 iNbPermVal = 0;

        DBA_FillPermValTab(OpDomainEnt,OpDomain_StatusEn,(PTR) &permValTab, &iNbPermVal, 0);
        EV_DictFctTab.reserve(EV_DictFctTab.size() + iNbMasterEnt);

        int i = 0;
        for (OBJECT_ENUM enObj = 0; (enObj < LASTOBJECT) && (i < iNbMasterEnt); enObj++)
        {
            pdictent = DBA_GetDictEntitySt(enObj);
            if ((pdictent != NULL) &&
                ((pdictent->multiEntityCateg.get() == MultiEntityCategory_BusinessEntityOnly) ||
                    (pdictent->multiEntityCateg.get() == MultiEntityCategory_DerivedBusinessEntityOnly)))
            {
                DICT_T  dictAdminFunction;
                DBA_GetAdmDictFct(pdictent->objectEn,NULL,&dictAdminFunction);
                EV_DictFctTab.resize(EV_DictFctTab.size() + 1);

                fctStp = &EV_DictFctTab.back();
                fctStp->dictId = dictAdminFunction;
                fctStp->entityDictId = pdictent->entDictId;
                fctStp->createFlag = FALSE;
                fctStp->updateFlag = FALSE;
                fctStp->deleteFlag = FALSE;
                fctStp->viewFlag = TRUE;
                fctStp->visibleFlag = TRUE;
                if (permValTab != NULL)
                {
                    fctStp->minOpStatus = (ENUM_T) permValTab[0].value;
                    fctStp->maxOpStatus = (ENUM_T) permValTab[iNbPermVal - 1].value;
                }
                i++;
            }
        }
        if (permValTab != nullptr)
        {
            delete [] permValTab;
        }
        permValTab = nullptr;
    }

    return retCode;
}

/************************************************************************
**
**  Function    :   DBA_UpdFctTab
**
**  Description :   Updating table EV_DictFctTab
**
**  Argument    :   none
**
**  Return      :   RET_CODE
**
**  Cr�ation	:   ROI - 961111 - DVP245
**  Modif.	:   ROI - 961121 - DVP260
**  Modif.      :   ROI - 961122 - DVP261
**  Modif.      :   RAK - 970204 - DVP339
**  Modif.      :   ROI - 970213 - DVP342
**  Modif.      :   ROI - 970303 - DVP367
**  Modif.      :   ROI - 970617 - DVP505
**  Modif.      :   ROI - 980320 - REF1476
**  Modif.      :   ROI - 980423 - REF1769
**  Modif.      :   FIH - 980505 - REF1479
**  Modif.      :   ROI - 981007 - REF2891
**  Modif.      :   ROI - 990112 - REF2644
**  Modif.		:   ROI - 990414 - REF3476
**	Modif.		:	ROI - 990608 - REF3729
**	Modif.		:	ROI - 990816 - REF3899
**  Modif.      :   FPL-REF7423-020321
**
*************************************************************************/
STATIC RET_CODE	DBA_UpdFctTab()
{
    FLAG_T          adminFmtFlag;
    DICT_T          parFctEn;   /*  FPL-PMSTA08801-100714 DICT_FCT_ENUM */
    RET_CODE        retCode;
    DICT_T          dictId;
    DICT_FCT_STP    fctStp, parFctStp;
    INFO_T          info;


#ifdef NEXUS    /*  FPL-REF10260-040519 */
    DBA_SetFnSecuProfNexus();
#endif

    /*  Is the user logged on a master entity: reduce access to functions and entities      */
    /*  Code moved from GUI_MainWinMenuConstruct                                            */  /*  HFI-PMSTA-41458-200814  */
    if (SYS_IsGuiMode() == TRUE)
    {
        std::string stringConnectedEntity = SYS_GetThread().getCurrBusinessEntity();
        if (GEN_IsMultiEntity() &&
            (stringConnectedEntity != NULL) &&
            (stringConnectedEntity.empty() == false) &&
            (EV_MasterBusinessEntity.compare(stringConnectedEntity) == 0))
        {
            DBA_AdaptMetaDictToMaster();
        }
    }

    /* Updating table EV_DictFctTab for administration. */
    DBA_UpdFctTabAdm(DictFct_Admin,0, false);
    DBA_UpdFctTabAdm(DictFct_StratAdmin,0, false);
    DBA_UpdFctTabAdm(DictFct_ConstraintAdministration,0, false);
    DBA_GetDictId(ShareIssOpEnt,&dictId);
    DBA_UpdFctTabAdm(DictFct_Admin, dictId, false);
    DBA_GetDictId(ShareRedmOpEnt, &dictId);
    DBA_UpdFctTabAdm(DictFct_Admin, dictId, false);

    /*  Create fake records to continue to allow direct acces for functions < 100       */  /*  HFI-PMSTA-54808-2023-10-30  */
    DBA_UpdFctTabAdm(DictFct_FREE3, 0, true);
    DBA_UpdFctTabAdm(DictFct_FREE4, 0, true);
    DBA_UpdFctTabAdm(DictFct_FREE5, 0, true);
    DBA_UpdFctTabAdm(DictFct_FREE6, 0, true);
    DBA_UpdFctTabAdm(DictFct_FREE7, 0, true);
    DBA_UpdFctTabAdm(DictFct_FREE8, 0, true);

    /* Sort EV_DictFctTab tab */
    std::sort(EV_DictFctTab.begin(), EV_DictFctTab.end(), DBA_CmpDictFct);  /* PMSTA-nuodb - LJE - 190507 */

    /* Make direct acces tabs to functions to speed up */
    /* Test allocations */
    EV_DictFctWithFmtTab = (DICT_FCT_STP*) CALLOC(EV_DictFctTab.size(), sizeof(DICT_FCT_STP));
    EV_DictFctWithDocTab = (DICT_FCT_STP*) CALLOC(EV_DictFctTab.size(), sizeof(DICT_FCT_STP));
    EV_DictFctMainWithFinTab = (DICT_FCT_STP*) CALLOC(EV_DictFctTab.size(), sizeof(DICT_FCT_STP));
    EV_DictFctSubWithFinTab = (DICT_FCT_STP**) CALLOC(EV_DictFctTab.size(), sizeof(DICT_FCT_STP*));

    if ((EV_DictFctWithFmtTab     == NULL) ||
        (EV_DictFctWithDocTab     == NULL) ||
        (EV_DictFctMainWithFinTab == NULL) ||
        (EV_DictFctSubWithFinTab  == NULL))
    {
      FREE(EV_DictFctWithFmtTab);
      FREE(EV_DictFctWithDocTab);
      FREE(EV_DictFctMainWithFinTab);
      FREE(EV_DictFctSubWithFinTab);
      MSG_RETURN(RET_MEM_ERR_ALLOC);
    }

    /* Init variables */
    EV_DictFctNb = (short)EV_DictFctTab.size();
    EV_DictFctWithFmtNb = 0;
    EV_DictFctWithDocNb = 0;
    EV_DictFctWithFinNb = 0;
    EV_DictFctMainWithFinNb = 0;
    adminFmtFlag = FALSE;					/* ROI - 990608 - REF3729 */

    /*  FIH-REF6116-010618  Manage pack case                */
    info[0] = END_OF_STRING;
    GEN_GetApplInfo(ApplLicensePack,info);

    /* Main loop on EV_DictFctTab */
    for (size_t i = 0; i < EV_DictFctTab.size(); i++)
    {
        /* Init loop variable */
        fctStp = &(EV_DictFctTab[i]);
        parFctStp = NULL;
        if (fctStp->parFctDictId == 0)
        {
            fctStp->parFctDictId = fctStp->dictId;      /*  FIH-REF4281-000301  */
            parFctEn =  fctStp->dictId; /*  FPL-PMSTA08801-100714 cast  */
        }
        else
        {
            /*  FIH-REF7323-020530  Manage sub function of sub function     */
            if ((parFctEn = fctStp->parFctDictId) >= DictFct_LastFromMetadictionary)	/* REF11686 - TEB - 060206 */   /*  FPL-PMSTA08801-100714 cast  */
            {
                size_t s = 0;
                for (;(s < EV_DictFctTab.size()) && (EV_DictFctTab[s].dictId != fctStp->parFctDictId); s++);
                if (s < EV_DictFctTab.size())
                    parFctEn = EV_DictFctTab[s].parFctDictId;   /*  FPL-PMSTA08801-100714 cast  */
            }

            if (parFctEn < DictFct_LastFromMetadictionary)	/* REF11686 - TEB - 060206 */
                retCode = DBA_GetDictFctInfo(parFctEn, DictFctInfo_Stp, (PTR) &(parFctStp));
            else        /*  FIH-REF7323-020530  This case is not managed    */
            {
                MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, fctStp->procName, "parent_function");
                retCode = RET_GEN_ERR_INVARG;
            }
            if (retCode != RET_SUCCEED)
                return retCode;
        }

        /*  Update module, two cases : Normal and Pack module   */
        /*  FIH-REF6116-010618  Manage pack case                */
        if (info[0] != END_OF_STRING)
        {
            switch (parFctEn)
            {
                case DictFct_Admin :
                case DictFct_Valo :
                case DictFct_OpHist :
                case DictFct_Journal :
                case DictFct_Report :
                case DictFct_OpList :
                case DictFct_Return :
                case DictFct_MultiValo :
                case DictFct_CurrencyModify :
                case DictFct_SynthAdmin :
                case DictFct_OrderEntry :
                case DictFct_ReconcStrat :
                case DictFct_CheckStrat :
                case DictFct_CheckStratValo :
                case DictFct_StratAdmin :
                case DictFct_AllocateOrder :
                case DictFct_ForexHedging :   /* PMSTA-44959 - LIK - 210429 */
                case DictFct_OrderList :
                case DictFct_PurgeOrder :           /* FPL-REF8723-040218 */

                case DictFct_PreTradeCheckStrat :
                case DictFct_OrderAllocation :      /*  FIH-REF7228-011204  */
                case DictFct_RunOrderAllocation:    /*  FIH-REF7228-011204  */
                case DictFct_CreateChildOrder :     /*  FIH-REF7338-020212  */
                case DictFct_OrderGrouping :        /*  FIH-REF7174-020213  */
                case DictFct_GroupingIndex :        /*  FIH-REF7174-020213  */
                case DictFct_DetachOrder :          /*  FIH-REF8182-021031  */
                case DictFct_UpdateDraft :
                case DictFct_UpdateField :
                case DictFct_UpdateData :           /*  FIH-REF11457-051006 */
                case DictFct_InitiateOrder :        /*  FIH-REF7323-020522  */
                case DictFct_InitiateCompoundOrder :    /*  HFI-PMSTA-19105-141122  */
                case DictFct_Reversal :
                case DictFct_Fusion :
                case DictFct_FusionStat :
                case DictFct_YieldCurve :           /*  FIH-REF7126-011017  */
                case DictFct_BenchStorage :         /* FPL-REF7423-020321 */
                case DictFct_PtfStorage :           /* FPL-REF7423-020321 */
                case DictFct_ExternalFunction :     /* MRA - 031006 - REF9510 */
                case DictFct_InitiateExecution :    /*  FIH-PMSTA2553-070711    */
                case DictFct_CaseInquiry :          /*  FPL-PMSTA07121-090203   */
                case DictFct_DispChangeSet :        /* PMSTA-26250 - DDV - 170321 */
                case DictFct_InstrRecommLevelStorage: /* PMSTA-28705 - DDV - 180206 */
				case DictFct_SessionsMonitoring:	/* PMSTA-30900 - RAK - 180514 */
                case DictFct_OrderNetting:        /* PMSTA-38314 - sanand - 29012020 */
                case DictFct_HierarchyGrouping:   /* PMSTA-40208 - sanand - 24092020 */
                case DictFct_DetachHierGrouping:    /* PMSTA-40208 - adarshn - 13102020 */
                    fctStp->module = (DICT_FCTMOD_ENUM)DictFctModPack_Core; /* REF7264 - LJE - 020205 */
                    break;

                case DictFct_CompositeMgr :
                    fctStp->module = (DICT_FCTMOD_ENUM)DictFctModPack_CompositeManagement; /* REF7264 - LJE - 020205 */
                    break;

                case DictFct_ConstraintAdministration :
                case DictFct_Perfo :
                case DictFct_Zoom :
                case DictFct_EventGeneration :
                case DictFct_DisplayChrono :
				case DictFct_DisplayComplianceChrono:  /* PMSTA-18759 - CHU - 150401 */
                case DictFct_PLRestart :

                case DictFct_StrategyDerivation :	/* MDE - REF6082 - 010925 */
                case DictFct_ViewDerivedStrategyObjectives :
                case DictFct_PerformanceAnalysis :                          /* FPL-REF7758-020910 */
                    fctStp->module = (DICT_FCTMOD_ENUM)DictFctModPack_No; /* REF7264 - LJE - 020205 */
                    break;
            }
            /*  Particular case for sub fucntion in TOP packaging       */
            if (strcmp(fctStp->procName,"perf_attrib") == 0)
                fctStp->module = (DICT_FCTMOD_ENUM)DictFctModPack_PerformanceAttribution; /* REF7264 - LJE - 020205 */
        }
        else
        {
            switch (parFctEn)
            {
                case DictFct_Admin :
                case DictFct_Valo :
                case DictFct_OpHist :
                case DictFct_Journal :
                case DictFct_Perfo :
                case DictFct_Report :
                case DictFct_Zoom :
                case DictFct_OpList :
                case DictFct_Return :
                case DictFct_MultiValo :
                case DictFct_CurrencyModify :
                case DictFct_Fusion :
                case DictFct_FusionStat :
                case DictFct_SynthAdmin :
                case DictFct_PLRestart :
               /* case DictFct_OrderEntry :        */   /* REF2644 - 980921 - DDV */	/* FPL - 020822 - REF7291 */
                case DictFct_DisplayChrono :        /* DRI - 20000216 - REF4305 */
				case DictFct_DisplayComplianceChrono:  /* PMSTA-18759 - CHU - 150401 */
                case DictFct_BenchStorage :         /* FPL-REF7423-020321 */
                case DictFct_PtfStorage :           /* FPL-REF7423-020321 */
                case DictFct_PerformanceAnalysis :                          /* FPL-REF7758-020910 */
                case DictFct_CheckStrat :           /*  FIH-REFXXXX-021107  Move from order management to core  */
                case DictFct_CheckStratValo :       /*  FIH-REFXXXX-021107  Move from order management to core  */
                case DictFct_ExternalFunction :     /* MRA - 031006 - REF9510 */
                case DictFct_PurgeOrder :           /* FPL-REF8723-040218 */
                case DictFct_UpdateData :           /*  FIH-REF11457-051006 */
                case DictFct_CaseInquiry :          /*  FPL-PMSTA07121-090203   */

                case DictFct_StratAdmin :                   /*  PMSTA-12969-HFI-110930  Move to core module */
                case DictFct_EditAllocConstr :              /*  PMSTA-12969-HFI-110930  Move to core module */
                case DictFct_StrategyDerivation :           /*  PMSTA-12969-HFI-110930  Move to core module */
                case DictFct_ConstraintAdministration :     /*  PMSTA-12969-HFI-110930  Move to core module */
                case DictFct_InvestConstrHistory :          /*  PMSTA-12969-HFI-110930  Move to core module */
                case DictFct_DispChangeSet :            /* PMSTA-26250 - DDV - 170321 */
                case DictFct_InstrRecommLevelStorage:   /* PMSTA-28705 - DDV - 180206 */

                case DictFct_ComputeInstrumentChrono:
                case DictFct_ComputeComplianceChrono:
                    fctStp->module = DictFctMod_Core;
                    break;

                case DictFct_OrderAllocation :      /*  FIH-REF7228-011204  */
                case DictFct_RunOrderAllocation :   /*  FIH-REF7228-011204  */
                case DictFct_CreateChildOrder :     /*  FIH-REF7338-020211  */
                case DictFct_OrderGrouping :        /*  FIH-REF7174-020213  */
                case DictFct_OrderNetting:          /* PMSTA-38314 - sanand - 29012020 */
                case DictFct_HierarchyGrouping:     /* PMSTA-40208 - sanand - 24092020 */
                case DictFct_GroupingIndex :        /*  FIH-REF7174-020213  */
                case DictFct_DetachOrder :          /*  FIH-REF8182-021031  */
                case DictFct_DetachHierGrouping:    /* PMSTA-40208 - adarshn - 13102020 */
                case DictFct_InitiateOrder :        /*  FIH-REF7323-020522  */
                case DictFct_InitiateCompoundOrder: /*  HFI-PMSTA-19105-141122  */
                case DictFct_OrderList :			/* MDE - REF2467 - 000308 */ /* PMSTA-24777 - DDV - 160915 - Fct move from Productivity module to Order Management */
				case DictFct_OrderEntry :			/* FPL - 020822 - REF7291 */ /* PMSTA-24777 - DDV - 160915 - Fct move from Productivity module to Order Management */
				case DictFct_SessionsMonitoring:	/* PMSTA-30900 - RAK - 180514 */
				case DictFct_UpdateField: 		    /*  FIH-REF4281-000225  */   /* PMSTA-45235 - KOR - 020821 - Fct move from Productivity module to Order Management */
                    fctStp->module = DictFctMod_OrderManagement ;           /* FPL-020926 set the 6 function in this module */
                    break;
                case DictFct_UpdateDraft : 		    /*  FIH-REF5199-000907  */
                case DictFct_Reversal : 		    /*  FIH-REF4217-000211  */
                case DictFct_ReconcStrat : 		    /* DVP339 - RAK - 970204 */
                /*case DictFct_StratAdmin :                 PMSTA-12969-HFI-110930  Move to core module */
                /*case DictFct_ConstraintAdministration :  FPL-REF7291 not this module !  */
                case DictFct_AllocateOrder :	    /* DVP460 - RAK - 970502 */
                case DictFct_ForexHedging:    /* PMSTA-44959 - LIK - 210429 */
                case DictFct_PreTradeCheckStrat :	/* REF3371 - RAK - 991221 */
                case DictFct_ViewDerivedStrategyObjectives :	/* FPL - 020822 - REF7291 */

                case DictFct_UnmatchedExecutionList :       /*  FIH-REF9764-031223  */  /*  FIH-REF10468-040720 Suppress DictFctMod_MatchingExecution   */
                case DictFct_SearchMatchingOrder :          /*  FIH-REF9764-031223  */  /*  FIH-REF10468-040720 Suppress DictFctMod_MatchingExecution   */
                case DictFct_SearchUnmatchedExecution :     /*  FIH-REF9764-031223  */  /*  FIH-REF10468-040720 Suppress DictFctMod_MatchingExecution   */
                case DictFct_InitiateExecution :            /*  FIH-PMSTA2553-070711    */
				case DictFct_SelectGridMktSgt:				/* 81 PMSTA-20843 - CHU - 150724 */
                    fctStp->module = DictFctMod_Productivity;
                    break;

                case DictFct_EventGeneration :
                    fctStp->module = DictFctMod_CorporateActions; /* DRI - 20000407 - REF4306 */
                    break;
/*
                case  :
                    fctStp->module = DictFctMod_AdvancedAnalytics;
                    break;
*/
                case DictFct_CompositeMgr :
                    fctStp->module = DictFctMod_CompositeManagement;
                    break;
/*
                case  :
                    fctStp->module = DictFctMod_Web;
                    break;
*/
                /* FPL-REF7291-020814 */
/*  PMSTA-12969-HFI-110930  Move to core module
                case DictFct_EditAllocConstr :
                case DictFct_StrategyDerivation :
                case DictFct_ConstraintAdministration :
                case DictFct_InvestConstrHistory :
                    fctStp->module = DictFctMod_AdvancedConstraintManagement;
                    break;
*/
            }
        }

        /* Update iconName */
        if (*(fctStp->iconName) == END_OF_STRING)
        {
            switch(fctStp->dictId)
            {
                case DictFct_Valo :
                    strcpy(fctStp->iconName, "FctValo");
                    break;
                case DictFct_OpHist :
                    strcpy(fctStp->iconName, "FctOpHist");
                    break;
                case DictFct_Journal :
                    strcpy(fctStp->iconName, "FctJournal");
                    break;
                case DictFct_Perfo :
                    strcpy(fctStp->iconName, "FctPosHist");
                    break;
                case DictFct_Report :
                    strcpy(fctStp->iconName, "FctReport");
                    break;
                case DictFct_Zoom :
                    strcpy(fctStp->iconName, "FctZoom");
                    break;
                case DictFct_OpList :
                    strcpy(fctStp->iconName, "FctOpList");
                    break;
                case DictFct_Return :
                    strcpy(fctStp->iconName, "FctRtnAn");
                    break;
                case DictFct_ReconcStrat :	/* DVP339 - RAK - 970204 */
                    strcpy(fctStp->iconName, "FctReconcStrat");
                    break;
                case DictFct_CheckStrat :
                    strcpy(fctStp->iconName, "FctCheckStrat");
                    break;
                case DictFct_AllocateOrder :	/* DVP460 - RAK - 970502 */
                    strcpy(fctStp->iconName, "FctAllocateOrder");
                    break;
                case DictFct_EventGeneration :
                    strcpy(fctStp->iconName, "FctEventGeneration");
                    break;
                case DictFct_SynthAdmin :
                    strcpy(fctStp->iconName, "FctRtnAn");
                    break;
                case DictFct_ExecutionList :                    /*  FPL-REF8332-030909  */
                    strcpy(fctStp->iconName, "FctExecutionList");
                    break;
                case DictFct_OrderAllocation :                  /*  FIH-REF7228-011210  */
                case DictFct_OrderList :
                    strcpy(fctStp->iconName, "FctOrderList");   /*  FIH-REF87-994020    */
                    break;
                case DictFct_PurgeOrder :                       /* FPL-REF8723-040218 */
                    strcpy(fctStp->iconName, "FctPurgeOrder");
                    break;
                case DictFct_OrderEntry :  /* REF2644 - 980921 - DDV */
                    strcpy(fctStp->iconName, "FctOrderEntry");
                    break;
                case DictFct_DisplayChrono :           /* DRI - 20000216 - REF4305 */
                    strcpy(fctStp->iconName, "FctDisplayChrono");
                    break;
				case DictFct_DisplayComplianceChrono:  /* PMSTA-18759 - CHU - 150401 */
					strcpy(fctStp->iconName, "FctDisplayComplChrono");
					break;
                case DictFct_CompositeMgr :           /* DRI - 20000322 - REF4306 */
                    strcpy(fctStp->iconName, "FctCompositeMgr");
                    break;
                case DictFct_Fusion :           /*  FIH-REF1618-010409  */
                    strcpy(fctStp->iconName, "FctFusion");
                    break;
                case DictFct_CurrencyModify :           /*  FIH-REF1618-010409  */
                    strcpy(fctStp->iconName, "FctModifyCurrency");
                    break;
                case DictFct_StrategyDerivation :	/* MDE - REF6082 - 010925 */
                    strcpy(fctStp->iconName, "FctStrategyDerivation");
                    break;
                case DictFct_ViewDerivedStrategyObjectives :	/* MDE - REF6082 - 010925 */
                    strcpy(fctStp->iconName, "FctViewDerivedStrategyObjectives");
                    break;
                case DictFct_EditStrategyObjectives :	/* MDE - REF6082 - 010925 */
                    strcpy(fctStp->iconName, "FctEditStrategyObjectives");
                    break;
                case DictFct_YieldCurve :       /*  FIH-REF7126-011017  */
                    strcpy(fctStp->iconName, "FctYieldCurve");
                    break;
                case DictFct_BenchStorage :             /* FPL-REF7423-020321 */
                    strcpy(fctStp->iconName, "FctBenchStorage");
                    break;
                case DictFct_PtfStorage :               /* FPL-REF7423-020321 */
                    strcpy(fctStp->iconName, "FctPtfStorage");
                    break;
                case DictFct_PerformanceAnalysis :      /* FPL-REF7423-020321 */
                    strcpy(fctStp->iconName, "FctPerformanaceAnalysis");
                    break;
                case DictFct_CopyOperation :            /* FPL-REF7445-020328 */
                    strcpy(fctStp->iconName, "FctCopyOp");
                    break;
                case DictFct_FusionStat:                /* FPL-REF7445-020328 */
                    strcpy(fctStp->iconName, "FctEventScheduler");
                    break;
                case DictFct_Admin:                     /* FPL-REF7445-020328 */
                    strcpy(fctStp->iconName, "AdmAdministration");
                    break;
                case DictFct_Archive:                   /* FPL-REF7445-021018 */
                    strcpy(fctStp->iconName, "FctArchive");
                    break;
                case DictFct_ConstraintAdministration : /* FPL-REF7445-030120 */
                    strcpy(fctStp->iconName, "FctEditConstr");
                    break;
                case DictFct_ExternalFunction :     /* MRA - 031006 - REF9510 */
                    strcpy(fctStp->iconName, "FctExternalFct");
                    break;
                case DictFct_UnmatchedExecutionList :       /*  FIH-REF9764-031223  */
                    strcpy(fctStp->iconName, "FctUnmatchExecList");
                    break;
                case DictFct_SearchMatchingOrder :          /*  FIH-REF9764-031223  */
                    strcpy(fctStp->iconName, "FctSearchMatchOrder");
                    break;
                case DictFct_SearchUnmatchedExecution :     /*  FIH-REF9764-031223  */
                    strcpy(fctStp->iconName, "FctSearchUnmatchExec");
                    break;
                case DictFct_CaseInquiry :          /*  FPL-PMSTA07121-090203   */
                    strcpy(fctStp->iconName, "FctCaseInquiry");
                    break;
                case DictFct_DispChangeSet :          /* PMSTA-26250 - DDV - 170321 */
                    strcpy(fctStp->iconName, "FctDispChangeSet");
                    break;
                case DictFct_InstrRecommLevelStorage: /* PMSTA-28705 - DDV - 180206 */
                    strcpy(fctStp->iconName, "FctInstrRecommLevelStorage");
                    break;
                case DictFct_ForexHedging:    /* PMSTA-44959 - LIK - 210429 */
                    strcpy(fctStp->iconName, "FctForexHedging");
                    break;
            }
        }

        /*  FIH-REF9867-040206  */
        switch (parFctEn)
        {
            case DictFct_OrderList :
            case DictFct_UnmatchedExecutionList :
            case DictFct_SearchMatchingOrder :
            case DictFct_SearchUnmatchedExecution :
            case DictFct_PurgeOrder :           /* FPL-REF8723-040218 */
            case DictFct_CaseInquiry :          /*  FPL-PMSTA07121-090203   */
                fctStp->flagQuickSearch = TRUE;
                break;
        }

        /* Update entityDictId */
        switch(parFctEn)
        {
            case DictFct_FREE3:
            case DictFct_FREE4:
            case DictFct_FREE5:
            case DictFct_FREE6:
            case DictFct_FREE7:
            case DictFct_FREE8:
                fctStp->entityDictId = NullEntityCst;
                break;

            case DictFct_OrderAllocation :      /*  FIH-REF7228-011204  */
            case DictFct_RunOrderAllocation :   /*  FIH-REF7228-011204  */
            case DictFct_CreateChildOrder :     /*  FIH-REF7338-020211  */
            case DictFct_OrderGrouping :        /*  FIH-REF7174-020213  */
            case DictFct_GroupingIndex :        /*  FIH-REF7174-020213  */
            case DictFct_DetachOrder :          /*  FIH-REF8182-021031  */
            case DictFct_UpdateData :           /*  FIH-REF11457-051006 */
            case DictFct_UpdateDraft : 		    /*  FIH-REF5199-000907  */
            case DictFct_UpdateField : 		    /*  FIH-REF4281-000225  */
            case DictFct_Reversal : 		    /*  FIH-REF4217-000211  */
            case DictFct_InitiateOrder :        /*  FIH-REF7323-020522  */
            case DictFct_InitiateCompoundOrder: /*  HFI-PMSTA-19105-141122  */
            case DictFct_AllocateOrder :        /*  FIH-REF4035-000121  */
            case DictFct_ForexHedging:          /* PMSTA-44959 - LIK - 210429 */
            case DictFct_ReconcStrat :          /*  FIH-REF4035-000121  */
            case DictFct_OrderEntry :           /*  FIH-REF4035-000121  */
			case DictFct_SessionsMonitoring:	/* PMSTA-30900 - RAK - 180514 */
            case DictFct_OrderList :            /*  FIH-REF4035-991025  */
            case DictFct_OpList :               /*  FIH-REF4035-991025  */
            case DictFct_EventGeneration :	    /* ROI : Alors FIH t'as oubli� cette fct lors de ton dvp REF4281 , Ou bien ? */
            case DictFct_Admin :
            case DictFct_StratAdmin :
            case DictFct_ConstraintAdministration :
            case DictFct_PerformanceAnalysis :  /* FPL-REF7758-020910 */
            case DictFct_UnmatchedExecutionList:/*  FIH-REF10265-040526 */
            case DictFct_SearchMatchingOrder:   /*  FIH-REF10265-040526 */
            case DictFct_InitiateExecution :    /*  FIH-PMSTA2553-070711    */
            case DictFct_CaseInquiry :          /*  FPL-PMSTA07121-090203   */
            case DictFct_OrderNetting :         /* PMSTA-38314 - sanand - 29012020 */
            case DictFct_HierarchyGrouping:     /* PMSTA-40208 - sanand - 24092020 */
            case DictFct_DetachHierGrouping:    /* PMSTA-40208 - adarshn - 13102020 */
                break;
            default : fctStp->entityDictId = 0;
        }

        /* Update minOpStatus */
        switch(parFctEn)
        {
            case DictFct_OrderAllocation :      /*  FIH-REF7228-011204  */
            case DictFct_RunOrderAllocation :   /*  FIH-REF7228-011204  */
            case DictFct_CreateChildOrder :     /*  FIH-REF7338-020211  */
            case DictFct_OrderGrouping :        /*  FIH-REF7174-020213  */
            case DictFct_GroupingIndex :        /*  FIH-REF7174-020213  */
            case DictFct_DetachOrder :          /*  FIH-REF8182-021031  */
            case DictFct_UpdateData :           /*  FIH-REF11457-051006 */
            case DictFct_UpdateDraft : 		    /*  FIH-REF5199-000907  */
            case DictFct_UpdateField : 		    /*  FIH-REF4281-000225  */
            case DictFct_InitiateOrder :        /*  FIH-REF7323-020522  */
            case DictFct_InitiateCompoundOrder: /*  HFI-PMSTA-19105-141122  */
            case DictFct_Reversal : 		    /*  FIH-REF4217-000211  */
            case DictFct_AllocateOrder :        /*  FIH-REF4035-000121  */
            case DictFct_ForexHedging :         /* PMSTA-44959 - LIK - 210429 */
            case DictFct_ReconcStrat :          /*  FIH-REF4035-000121  */
            case DictFct_OrderEntry :           /*  FIH-REF4035-000121  */
			case DictFct_SessionsMonitoring:	/* PMSTA-30900 - RAK - 180514 */
            case DictFct_OrderList :            /*  FIH-REF4035-991025  */
            case DictFct_PurgeOrder :           /* FPL-REF8723-040218 */
            case DictFct_OpList :               /*  FIH-REF4035-991025  */
            case DictFct_Admin :
            case DictFct_EventGeneration :	    /*  FIH-REF4281-000322  */
            case DictFct_StrategyDerivation :				/* MDE - REF6082 - 010925 */
            case DictFct_ViewDerivedStrategyObjectives :	/* MDE - REF6082 - 010925 */
            case DictFct_UnmatchedExecutionList:/*  FIH-REF10265-040526 */
            case DictFct_SearchMatchingOrder:   /*  FIH-REF10265-040526 */
            case DictFct_InitiateExecution :    /*  FIH-PMSTA2553-070711    */
            case DictFct_CaseInquiry :          /*  FPL-PMSTA07121-090203   */
            case DictFct_OrderNetting:          /* PMSTA-38314 - sanand - 29012020 */
            case DictFct_HierarchyGrouping:   /* PMSTA-40208 - sanand - 24092020 */
            case DictFct_DetachHierGrouping:    /* PMSTA-40208 - adarshn - 13102020 */
                break;
            default : fctStp->minOpStatus = (ENUM_T)-1;
        }

        /* Update maxOpStatus */
        switch(parFctEn)
        {
            case DictFct_OrderAllocation :      /*  FIH-REF7228-011204  */
            case DictFct_RunOrderAllocation :   /*  FIH-REF7228-011204  */
            case DictFct_CreateChildOrder :     /*  FIH-REF7338-020211  */
            case DictFct_OrderGrouping :        /*  FIH-REF7174-020213  */
            case DictFct_GroupingIndex :        /*  FIH-REF7174-020213  */
            case DictFct_DetachOrder :          /*  FIH-REF8182-021031  */
            case DictFct_UpdateData :           /*  FIH-REF11457-051006 */
            case DictFct_UpdateDraft : 		    /*  FIH-REF5199-000907  */
            case DictFct_UpdateField : 		    /*  FIH-REF4281-000225  */
            case DictFct_Reversal : 		    /*  FIH-REF4217-000211  */
            case DictFct_InitiateOrder :        /*  FIH-REF7323-020522  */
            case DictFct_InitiateCompoundOrder: /*  HFI-PMSTA-19105-141122  */
            case DictFct_AllocateOrder :        /*  FIH-REF4035-000121  */
            case DictFct_ForexHedging :         /* PMSTA-44959 - LIK - 210429 */
            case DictFct_ReconcStrat :          /*  FIH-REF4035-000121  */
            case DictFct_OrderEntry :           /*  FIH-REF4035-000121  */
			case DictFct_SessionsMonitoring:	/* PMSTA-30900 - RAK - 180514 */
            case DictFct_OrderList :            /*  FIH-REF4035-991025  */
            case DictFct_PurgeOrder :           /* FPL-REF8723-040218 */
            case DictFct_OpList :               /*  FIH-REF4035-991025  */
            case DictFct_Admin :
            case DictFct_EventGeneration :	    /*  FIH-REF4281-000322  */
            case DictFct_StrategyDerivation :				/* MDE - REF6082 - 010925 */
            case DictFct_ViewDerivedStrategyObjectives :	/* MDE - REF6082 - 010925 */
            case DictFct_UnmatchedExecutionList:/*  FIH-REF10265-040526 */
            case DictFct_SearchMatchingOrder:   /*  FIH-REF10265-040526 */
            case DictFct_InitiateExecution :    /*  FIH-PMSTA2553-070711    */
            case DictFct_CaseInquiry :          /*  FPL-PMSTA07121-090203   */
            case DictFct_OrderNetting:          /* PMSTA-38314 - sanand - 29012020 */
            case DictFct_HierarchyGrouping:   /* PMSTA-40208 - sanand - 24092020 */
            case DictFct_DetachHierGrouping:    /* PMSTA-40208 - adarshn - 13102020 */
                break;
            default : fctStp->maxOpStatus = (ENUM_T)-1;
        }

        /* Update securityLevel */
        switch(parFctEn)
        {
            case DictFct_OrderAllocation :                  /*  FIH-REF7228-011204  */
            case DictFct_RunOrderAllocation:                /*  FIH-REF7228-011204  */
            case DictFct_OrderEntry :                       /*  FIH-REF4035-000121  */
			case DictFct_SessionsMonitoring:	/* PMSTA-30900 - RAK - 180514 */
            case DictFct_UnmatchedExecutionList :           /*  FIH-REF9764-031223  */
            case DictFct_SearchMatchingOrder :              /*  FIH-REF9764-031223  */
            case DictFct_OpList :                           /*  FIH-REF4035-991025  */
            case DictFct_Admin :		                    /*  FIH-REF1479-980505  */
            case DictFct_StratAdmin :
            case DictFct_ConstraintAdministration :
            case DictFct_SynthAdmin :
            case DictFct_EventGeneration :	                /*  FIH-REF4281-000322  */
            case DictFct_UpdateField : 		                /*  FIH-REF4281-000225  */
            case DictFct_StrategyDerivation :				/* MDE - REF6082 - 010925 */
            case DictFct_ViewDerivedStrategyObjectives :	/* MDE - REF6082 - 010925 */
            case DictFct_BenchStorage :                     /* FPL-REF7423-020321 */
            case DictFct_PtfStorage :                       /* FPL-REF7423-020321 */
            case DictFct_OrderList :                        /*  FIH-REF4035-991025  */
            case DictFct_CaseInquiry :                      /*  FPL-PMSTA07121-090203   */
            case DictFct_PerformanceAnalysis :              /*  HFI-PMSTA-38770-200129  */
            case DictFct_CompositeMgr :                     /*  HFI-PMSTA-38770-200129  */
            case DictFct_PLRestart :                        /*  HFI-PMSTA-38770-200129  */
            case DictFct_InstrRecommLevelStorage :          /*  HFI-PMSTA-38770-200129  */
                break;
            case DictFct_Valo :                             /*  FIH-REF9752-040921  */
            case DictFct_CheckStrat :                       /*  FIH-REF9752-040921  */
            case DictFct_CreateChildOrder :                 /*  FIH-REF7338-020211  */
            case DictFct_OrderGrouping :                    /*  FIH-REF7174-020213  */
            case DictFct_GroupingIndex:                     /*  FIH-REF7174-020213  */
            case DictFct_DetachOrder :                      /*  FIH-REF8182-021031  */
            case DictFct_UpdateData :                       /*  FIH-REF11457-051006 */
            case DictFct_UpdateDraft : 		                /*  FIH-REF5199-000907  */
            case DictFct_InitiateOrder :                    /*  FIH-REF7323-020522  */
            case DictFct_InitiateCompoundOrder:             /*  HFI-PMSTA-19105-141122  */
            case DictFct_ExternalFunction :                 /* MRA - 031006 - REF9510 */
            case DictFct_SearchUnmatchedExecution :         /*  FIH-REF9764-031223  */
            case DictFct_InitiateExecution :                /*  FIH-PMSTA2553-070711    */
            case DictFct_OrderNetting:                      /* PMSTA-38314 - sanand - 29012020 */
            case DictFct_HierarchyGrouping:                 /* PMSTA-40208 - sanand - 24092020 */
            case DictFct_DetachHierGrouping:                /* PMSTA-40208 - adarshn - 13102020 */
                fctStp->updateFlag = FALSE;
                fctStp->deleteFlag = FALSE;
                break;
            case DictFct_Reversal : 		/*  FIH-REF4217-000211  */
                fctStp->createFlag = FALSE;
                fctStp->deleteFlag = FALSE;
                break;
            case DictFct_ReconcStrat :	    /*  REF3476 + REF3899 */
            case DictFct_AllocateOrder :
            case DictFct_ForexHedging :    /* PMSTA-44959 - LIK - 210429 */
                fctStp->securityLevel = (ENUM_T)-1;
                fctStp->deleteFlag = FALSE;
                break;
            case DictFct_PurgeOrder :           /* FPL-REF8723-040218 */
                fctStp->createFlag = FALSE;
                fctStp->updateFlag = FALSE;
                fctStp->deleteFlag = FALSE;
                break;
            default :
                fctStp->securityLevel = (ENUM_T)-1;
                fctStp->createFlag = FALSE;
                fctStp->updateFlag = FALSE;
                fctStp->deleteFlag = FALSE;
                break;                      /* FPL-REF9956-040224 add break */
        }

        /* Update riskViewFlag */
        switch (parFctEn)
        {
            case DictFct_Valo :
            case DictFct_Perfo :
            case DictFct_Report :
            case DictFct_Return :
            case DictFct_MultiValo :
            case DictFct_ReconcStrat :		/* DVP339 - RAK - 970204 */
            case DictFct_CheckStrat :
            case DictFct_CheckStratValo :
            case DictFct_AllocateOrder :	/* DVP460 - RAK - 970507 */
            case DictFct_PreTradeCheckStrat :	/* REF3371 - RAK - 991221 */
            case DictFct_SynthAdmin :
            case DictFct_StrategyDerivation :				/* MDE - REF6082 - 010925 */
            case DictFct_ViewDerivedStrategyObjectives :	/* MDE - REF6082 - 010925 */
            case DictFct_BenchStorage :     /* FPL-REF7423-020321 */
            case DictFct_PtfStorage :       /* FPL-REF7423-020321 */
            case DictFct_PerformanceAnalysis :  /*  FPL-PMSTA09378-100622   */
            case DictFct_ForexHedging:          /* WEALTH-758 - KKM - 03072023 */
                break;
            default : fctStp->riskViewFlag = FALSE;
        }

        /* Update realTimeFlag */
        switch(parFctEn)
        {
            case DictFct_Valo :
            case DictFct_SearchMatchingOrder :  /*  FIH-REF9764-040302  */
                break;
            default : fctStp->realTimeFlag = FALSE;
        }

        /* Update accesStatus */
        if ((fctStp->funcSecuProfId > 0) &&
            (fctStp->viewFlag == TRUE) &&               /*  FIH-REF6135-010702  */
            (fctStp->visibleFlag == TRUE) &&            /*  FIH-REF6135-010702  */
            (fctStp->accesStatus == DictFctAuth_None))  /*  HFI-PMSTA-41458-200814  */
            fctStp->accesStatus = DictFctAuth_Ok;

        /* Update finaFlag */
        switch(parFctEn)
        {
            case DictFct_Valo :
            case DictFct_OpHist :
            case DictFct_Journal :
            case DictFct_Perfo :
            case DictFct_OpList :
            case DictFct_Return :
            case DictFct_ReconcStrat :		/* DVP339 - RAK - 970204 */
            case DictFct_CheckStrat :
            case DictFct_AllocateOrder :	/* DVP460 - RAK - 970507 */
            case DictFct_ForexHedging :     /* PMSTA-44959 - LIK - 210429 */
            case DictFct_PreTradeCheckStrat :	/* REF3371 - RAK - 991221 */
            case DictFct_EventGeneration :
            case DictFct_SynthAdmin :
            case DictFct_OrderList :
            case DictFct_PurgeOrder :           /* FPL-REF8723-040218 */
            case DictFct_OrderAllocation:       /*  FIH-REF7228-011210  */
            case DictFct_OrderEntry :           /* REF2644 - 980921 - DDV */
			case DictFct_SessionsMonitoring:	/* PMSTA-30900 - RAK - 180514 */
            case DictFct_DisplayChrono :        /* DRI - 20000216 - REF4305 */
			case DictFct_DisplayComplianceChrono:  /* PMSTA-18759 - CHU - 150401 */
            case DictFct_CompositeMgr :			/* DRI - 20000322 - REF4306 */
            case DictFct_StrategyDerivation :				/* MDE - REF6082 - 010925 */
            case DictFct_ViewDerivedStrategyObjectives :	/* MDE - REF6082 - 010925 */
            case DictFct_BenchStorage :         /* FPL-REF7423-020321 */
            case DictFct_PtfStorage :           /* FPL-REF7423-020321 */
            case DictFct_PerformanceAnalysis :  /* FPL-REF7758-020909 */
            case DictFct_UnmatchedExecutionList :       /*  FIH-REF9764-031223  */
            case DictFct_SearchMatchingOrder :          /*  FIH-REF9764-031223  */
            case DictFct_SearchUnmatchedExecution :     /*  FIH-REF9764-031223  */
            case DictFct_CheckHoldingConstraints :      /*  REF10684 - CHU - 041022  */
            case DictFct_CaseInquiry :                  /*  FPL-PMSTA07121-090203   */
            case DictFct_VerifySessionIC :              /*  FPL-PMSTA10166-100628   */
			case DictFct_EditDomainPtfCompo:			/*  PMSTA-21256 - chandrak - 150925 */
            case DictFct_DispChangeSet :            /* PMSTA-26250 - DDV - 170321 */
            case DictFct_InstrRecommLevelStorage:   /* PMSTA-28705 - DDV - 180206 */
            case DictFct_ManageSession :            /* 86  PMSTA-30897 - CHU - 180502 */ /* Robo-Advisor (Fully automated offer for discretionary clients : AR1 - Automatic Rebalancing - Split, Group & Publish) */
            case DictFct_ManagePayout:              /* 89  PMSTA-30894 - CHU - 180711 */ /* Robo-Advisor (Fully automated offer for discretionary clients : WR1 - Withdrawal Request) */
                fctStp->finaFlag = TRUE;
                break;
            default : fctStp->finaFlag = FALSE;
        }

        /* Update domEn */
        switch (parFctEn)
        {
            case DictFct_Valo :
            case DictFct_OpHist :
            case DictFct_Journal :
            case DictFct_Perfo :
            case DictFct_Report :
            case DictFct_InitiateOrder :                /* FPL-080129-PMSTA04685    For test facilities */
            case DictFct_InitiateCompoundOrder:         /*  HFI-PMSTA-19105-141122  */
            case DictFct_OpList :
            case DictFct_Return :
            case DictFct_ReconcStrat :		/* DVP339 - RAK - 970204 */
            case DictFct_CheckStrat :
            case DictFct_AllocateOrder :        /* DVP460 - RAK - 970507 */
            case DictFct_PreTradeCheckStrat :	/* REF3371 - RAK - 991221 */
            case DictFct_SynthAdmin :
            case DictFct_PLRestart :
/*	        case DictFct_OrderList :*/
            case DictFct_OrderEntry :           /* REF2644 - 980921 - DDV */
			case DictFct_SessionsMonitoring:	/* PMSTA-30900 - RAK - 180514 */
            case DictFct_OrderAllocation :      /*  FIH-REF7228-011205  */
            case DictFct_DisplayChrono :        /* DRI - 20000216 - REF4305 */
			case DictFct_DisplayComplianceChrono:  /* PMSTA-18759 - CHU - 150401 */
            case DictFct_CompositeMgr :			/* DRI - 20000322 - REF4306 */
            case DictFct_StrategyDerivation :				/* MDE - REF6082 - 010925 */
            case DictFct_ViewDerivedStrategyObjectives :	/* MDE - REF6082 - 010925 */
            case DictFct_BenchStorage :         /* FPL-REF7423-020321 */
            case DictFct_PtfStorage :           /* FPL-REF7423-020321 */
            case DictFct_PerformanceAnalysis :  /* FPL-REF7758-020909 */
            case DictFct_ExternalFunction :     /* MRA - 031006 - REF9510 */
            case DictFct_DispChangeSet :    /* PMSTA-26250 - DDV - 170321 */
            case DictFct_InstrRecommLevelStorage: /* PMSTA-28705 - DDV - 180206 */
            case DictFct_ForexHedging: /* PMSTA-XXXXX - sanand - 31032021 */
                fctStp->domEn = DictFctDom_Dom;
                break;
            case DictFct_UnmatchedExecutionList :       /*  FIH-REF9764-031223  */
            case DictFct_SearchMatchingOrder :          /*  FIH-REF9764-031223  */
            case DictFct_SearchUnmatchedExecution :     /*  FIH-REF9764-031223  */
            case DictFct_OrderList :
            case DictFct_PurgeOrder :                   /* FPL-REF8723-040218 */
            case DictFct_OrderGrouping :                /* FIH-REF11764-060405  For test facilities */
            case DictFct_HierarchyGrouping:
            case DictFct_UpdateField :                  /*  HFI-PMSTA-35324-190328  Also test facilities    */
            case DictFct_UpdateData:                    /*  HFI-PMSTA-35324-190328  Also test facilities    */
            case DictFct_CaseInquiry :          /*  FPL-PMSTA07121-090203   */
                fctStp->domEn = DictFctDom_OpSearch;
                break;			/* MDE - REF2467 - 000308 */
            case DictFct_EventGeneration : fctStp->domEn = DictFctDom_EDom; break;
            default : fctStp->domEn = DictFctDom_None;
        }

        /* Update fmtFlag */
        switch (parFctEn)
        {
            case DictFct_Admin :				/*  ROI - 990608 - REF3729 */
                if (adminFmtFlag == FALSE)
                {
                    adminFmtFlag = TRUE;
                    fctStp->fmtFlag = TRUE;
                    fctStp->fmtTabIdx = EV_DictFctWithFmtNb;
                    EV_DictFctWithFmtTab[EV_DictFctWithFmtNb] = fctStp;
                    EV_DictFctWithFmtNb++;
                }
                break;
            case DictFct_Valo :
            case DictFct_OpHist :
            case DictFct_Journal :
            case DictFct_Perfo :
            case DictFct_Report :
            case DictFct_Zoom :
            case DictFct_OpList :
            case DictFct_Return :
            case DictFct_ReconcStrat :			/* DVP339 - RAK - 970204 */
            case DictFct_CheckStrat :
            case DictFct_AllocateOrder :        /* DVP460 - RAK - 970507 */
            case DictFct_ForexHedging :         /* PMSTA-44959 - LIK - 210429 */
            case DictFct_PreTradeCheckStrat :	/* REF3371 - RAK - 991221 */
            case DictFct_EventGeneration :
            case DictFct_SynthAdmin :
            case DictFct_OrderList :
            case DictFct_PurgeOrder :           /* FPL-REF8723-040218 */
            case DictFct_OrderEntry :           /* REF2644 - 980921 - DDV */
			case DictFct_SessionsMonitoring:	/* PMSTA-30900 - RAK - 180514 */
            case DictFct_OrderAllocation :      /*  FIH-REF7228-011210  */
            case DictFct_DisplayChrono :           /* DRI - 20000216 - REF4305 */
			case DictFct_DisplayComplianceChrono:  /* PMSTA-18759 - CHU - 150401 */
            case DictFct_CompositeMgr :			/* DRI - 20000322 - REF4306 */
            case DictFct_StrategyDerivation :				/* MDE - REF6082 - 010925 */
            case DictFct_ViewDerivedStrategyObjectives :	/* MDE - REF6082 - 010925 */
            case DictFct_ConstraintAdministration :         /*  FIH-REF6082-011127  */
            case DictFct_BenchStorage :         /* FPL-REF7423-020321 */
            case DictFct_PtfStorage :           /* FPL-REF7423-020321 */
            case DictFct_PerformanceAnalysis :  /* FPL-REF7758-020909 */
            case DictFct_UnmatchedExecutionList :       /*  FIH-REF9764-031223  */
            case DictFct_SearchMatchingOrder :          /*  FIH-REF9764-031223  */
            case DictFct_SearchUnmatchedExecution :     /*  FIH-REF9764-031223  */
            case DictFct_CheckHoldingConstraints :      /*  REF10684 - CHU - 041022  */
            case DictFct_CaseInquiry :                  /*  FPL-PMSTA07121-090203   */
            case DictFct_VerifySessionIC :              /*  FPL-PMSTA10166-100628   */
            case DictFct_EditStrategyObjectives :       /*  HFI-PMSTA-14380-120605  */
			case DictFct_SelectGridMktSgt:				/* 81 PMSTA-20843 - CHU - 150724 */
			case DictFct_EditDomainPtfCompo:			/*  PMSTA-21256 - chandrak - 150925 */
            case DictFct_DispChangeSet :            /* PMSTA-26250 - DDV - 170321 */
            case DictFct_InstrRecommLevelStorage:   /* PMSTA-28705 - DDV - 180206 */
            case DictFct_ManageSession :            /* PMSTA-30897 - CHU - 180502 */ /* Robo-Advisor (Fully automated offer for discretionary clients : AR1 - Automatic Rebalancing - Split, Group & Publish) */
            case DictFct_ManagePayout:              /* 89  PMSTA-30894 - CHU - 180711 */ /* Robo-Advisor (Fully automated offer for discretionary clients : WR1 - Withdrawal Request) */
            case DictFct_CurrChangeReq:             /* PMSTA-39723 - LIK 10042020*/
			case DictFct_PtfTransfFees:             /* PMSTA-39717 - KNI - 15062020 */
                fctStp->fmtFlag = TRUE;
				fctStp->fmtTabIdx = EV_DictFctWithFmtNb;
				EV_DictFctWithFmtTab[EV_DictFctWithFmtNb] = fctStp;
				EV_DictFctWithFmtNb++;

                break;
            default : fctStp->fmtFlag = FALSE;
        }

        /* Update docFlag */
        switch (parFctEn)
        {
            case DictFct_Valo :
            case DictFct_OpHist :
            case DictFct_Journal :
            case DictFct_Perfo :			/* REF2918 - BMA - 981112 */
            case DictFct_Report :
            case DictFct_OpList :
            case DictFct_Return :
            case DictFct_ReconcStrat :		/* DVP339 - RAK - 970204 */
            case DictFct_CheckStrat :
            case DictFct_AllocateOrder :	/* DVP460 - RAK - 970507 */
            case DictFct_ForexHedging :     /* PMSTA-44959 - LIK - 210429 */
            case DictFct_SynthAdmin :
            case DictFct_OrderList :
            case DictFct_PurgeOrder :       /* FPL-REF8723-040218 */
            case DictFct_DisplayChrono :           /* DRI - 20000216 - REF4305 */
			case DictFct_DisplayComplianceChrono:  /* PMSTA-18759 - CHU - 150401 */
            case DictFct_CompositeMgr :			/* DRI - 20000322 - REF4306 */
            case DictFct_StrategyDerivation :				/* MDE - REF6082 - 010925 */
            case DictFct_ViewDerivedStrategyObjectives :	/* MDE - REF6082 - 010925 */
            case DictFct_BenchStorage :     /* FPL-REF7423-020321 */
            case DictFct_PtfStorage :       /* FPL-REF7423-020321 */
            case DictFct_PerformanceAnalysis :  /* FPL-REF7758-020909 */
            case DictFct_UnmatchedExecutionList :       /*  FIH-REF9764-031223  */
            case DictFct_CaseInquiry :                  /*  FPL-PMSTA07121-090203   */
            case DictFct_DispChangeSet :            /* PMSTA-26250 - DDV - 170321 */
                fctStp->docFlag = TRUE;
                fctStp->docTabIdx = EV_DictFctWithDocNb;
                EV_DictFctWithDocTab[EV_DictFctWithDocNb] = fctStp;
                EV_DictFctWithDocNb++;
                break;
            default :
/* REF2918 - 981112
                if ((SYS_GetEnv("AAAUNICIBLE") != NULL) &&
                    (parFctEn == DictFct_Perfo))
                {
                    fctStp->docFlag = TRUE;
                    fctStp->docTabIdx = EV_DictFctWithDocNb;
                    EV_DictFctWithDocTab[EV_DictFctWithDocNb] = fctStp;
                    EV_DictFctWithDocNb++;
                }
                else
*/
                fctStp->docFlag = FALSE;
                break;
        }

        /* Update finFlag : short cut */
        switch (parFctEn)
        {
            case DictFct_Valo :
            case DictFct_OpList :
            case DictFct_OpHist :
            case DictFct_Journal :
            case DictFct_Return :
            case DictFct_DisplayChrono :        /*  DRI-20000216-REF4305    */
			case DictFct_DisplayComplianceChrono:  /* PMSTA-18759 - CHU - 150401 */
            case DictFct_CompositeMgr :			/*  DRI-20000322-REF4306    */
            case DictFct_PerformanceAnalysis :  /*  FPL-PMSTA01667-070306   */
                if (fctStp->entityDictId == 0)  /*  FIH-REF5152-000821      */
                {
                    fctStp->finFlag = TRUE;
                    fctStp->finTabIdx = EV_DictFctWithFinNb;
/*  FIH-REF5578-010115  No more used
                    EV_DictFctWithFinTab[EV_DictFctWithFinNb] = fctStp;
*/
                    EV_DictFctWithFinNb++;
                    if ((fctStp->dictId > DictFct_0) && (fctStp->dictId <= LASTDICTFCT))
                    {
                        EV_DictFctMainWithFinTab[EV_DictFctMainWithFinNb] = fctStp;
                        EV_DictFctSubWithFinTab[EV_DictFctMainWithFinNb] = (DICT_FCT_STP*) CALLOC(EV_DictFctTab.size(), sizeof(DICT_FCT_STP));
                        EV_DictFctSubWithFinTab[EV_DictFctMainWithFinNb][0] = fctStp;
                        EV_DictFctMainWithFinNb++;
                    }
                    else
                    {
                        int s = 0;
                        for (;(s < EV_DictFctMainWithFinNb) &&
                                   (EV_DictFctMainWithFinTab[s]->dictId != fctStp->parFctDictId); s++);
                        if ((s < EV_DictFctMainWithFinNb) &&
                            (EV_DictFctSubWithFinTab[s] != NULL))
                            EV_DictFctSubWithFinTab[s][EV_DictFctMainWithFinTab[s]->childNb+1] = fctStp;
                    }
                }
                break;

            default :
                fctStp->finFlag = FALSE;
        }

        /*  FIH-REF5578-010111  */
        switch(parFctEn)
        {
            case DictFct_OrderEntry :
			case DictFct_SessionsMonitoring:	/* PMSTA-30900 - RAK - 180514 */
            case DictFct_InitiateOrder :        /*  FIH-REF7323-020522  */
            case DictFct_InitiateCompoundOrder: /*  HFI-PMSTA-19105-141122  */
                if (fctStp->entityDictId == 0)
                {
                    if ((fctStp->dictId > DictFct_0) && (fctStp->dictId <= LASTDICTFCT))
                    {
                        EV_DictFctMainWithFinTab[EV_DictFctMainWithFinNb] = fctStp;
                        EV_DictFctSubWithFinTab[EV_DictFctMainWithFinNb] = (DICT_FCT_STP*) CALLOC(EV_DictFctTab.size(), sizeof(DICT_FCT_STP));
                        EV_DictFctSubWithFinTab[EV_DictFctMainWithFinNb][0] = fctStp;
                        EV_DictFctMainWithFinNb++;
                    }
                    else if (fctStp->parFctDictId == parFctEn)      /*  FIH-REF7323-020522  Only consider the child and not the grand children  */
                    {
                        int s = 0;
                        for (;(s < EV_DictFctMainWithFinNb) &&
                                   (EV_DictFctMainWithFinTab[s]->dictId != fctStp->parFctDictId); s++);
                        if ((s < EV_DictFctMainWithFinNb) &&
                            (EV_DictFctSubWithFinTab[s] != NULL))
                            EV_DictFctSubWithFinTab[s][EV_DictFctMainWithFinTab[s]->childNb+1] = fctStp;
                    }
                }
                break;
        }

        /* Update functions guiMenuId */
        if ((fctStp->dictId > DictFct_0) && (fctStp->dictId <= LASTDICTFCT))
        {
            switch (fctStp->dictId)
            {
                case DictFct_Admin :
                case DictFct_StratAdmin :
                case DictFct_ConstraintAdministration :
                    if (fctStp->entityDictId == 0)
                        fctStp->guiMenuId = (short)(BASEGUIID + i*ADDGUIID);
                    else
                        fctStp->guiMenuId = (short)(BASEGUIID *2 + fctStp->entityDictId);
                    break;
                default :
                    fctStp->guiMenuId = (short)(BASEGUIID + i*ADDGUIID);
            }
        }
        else if (parFctStp != NULL)
        {
            /* Subfunctions guiMenuId */
            switch (parFctEn)
            {
                case DictFct_Valo :
                case DictFct_OpHist :
                case DictFct_Journal :
                case DictFct_Perfo :
                case DictFct_OpList :
                case DictFct_Return :
                case DictFct_CheckStrat :
                case DictFct_OrderList :
                case DictFct_PurgeOrder :       /* FPL-REF8723-040218 */
                case DictFct_OrderEntry :       /*  FIH-REF5436-001121      */
				case DictFct_SessionsMonitoring:	/* PMSTA-30900 - RAK - 180514 */
                case DictFct_OrderAllocation :  /*  FIH-REF7228-011210      */
                case DictFct_DisplayChrono :    /* DRI - 20000407 - REF4306 */
				case DictFct_DisplayComplianceChrono:  /* PMSTA-18759 - CHU - 150401 */
                case DictFct_CompositeMgr :     /* DRI - 20000407 - REF4306 */
                case DictFct_StrategyDerivation :				/* MDE - REF6082 - 010925 */
                case DictFct_ViewDerivedStrategyObjectives :	/* MDE - REF6082 - 010925 */
                case DictFct_PerformanceAnalysis :  /* FPL-REF7758-020909 */
                case DictFct_ExternalFunction :     /* MRA - 031006 - REF9510 */
                case DictFct_UnmatchedExecutionList :       /*  FIH-REF9764-031223  */
                case DictFct_ReconcStrat :          /*  FIH-REF10616-040910 */
                case DictFct_OrderGrouping :        /*  FIH-REF11764-060411 */
                case DictFct_UpdateField :          /*  HFI-PMSTA-35324-190328  Also test facilities    */
                case DictFct_UpdateData :           /*  HFI-PMSTA-35324-190328  Also test facilities    */
                case DictFct_InitiateOrder :        /*  FPL-080129-PMSTA04685   */
                case DictFct_InitiateCompoundOrder: /*  HFI-PMSTA-19105-141122  */
                case DictFct_CaseInquiry :          /*  FPL-PMSTA07121-090203   */
                case DictFct_OrderNetting :         /* PMSTA-38314 - sanand - 29012020 */
                case DictFct_HierarchyGrouping:   /* PMSTA-40208 - sanand - 24092020 */
                    if ((parFctEn == DictFct_InitiateOrder) &&  /*  FPL-080129-PMSTA04685 we don't add children of children !   */
                        (fctStp->parFctDictId != DictFct_InitiateOrder))
                    {
                        fctStp->guiMenuId = -1;
                        break;
                    }
                    if (fctStp->entityDictId == 0)  /*  FIH-REF5578-010111  */
                        (parFctStp->childNb)++;
                    fctStp->guiMenuId = (short)(parFctStp->guiMenuId + parFctStp->childNb);
                    break;
                default :
                    /* Subfunctions not allowed */
                    fctStp->guiMenuId = -1;
            }
        }

        /*  FIH-REF7207-011126  */
        fctStp->oriX = -1;
        fctStp->oriY = -1;
        fctStp->extX = -1;
        fctStp->extY = -1;
        fctStp->maximizeFlg = FALSE;
        fctStp->bViewDomain  = TRUE;    /* FPL-REF7542-020605 view domain in function screen */
        fctStp->bViewToolsBar = TRUE;   /* FPL-REF7542-020605 view tools bar in function screen */
        fctStp->bViewAdminBut = TRUE;   /*  FPL-REF10712-041022 view admin button in order list */
    }

    /* Make direct acces to speed up */
    /* Test allocations */
    EV_DictFctWithFmtTab = (DICT_FCT_STP*) REALLOC(EV_DictFctWithFmtTab,EV_DictFctWithFmtNb*sizeof(DICT_FCT_STP));
    EV_DictFctWithDocTab = (DICT_FCT_STP*) REALLOC(EV_DictFctWithDocTab,EV_DictFctWithDocNb*sizeof(DICT_FCT_STP));
    EV_DictFctWithDocTab = (DICT_FCT_STP*) REALLOC(EV_DictFctWithDocTab,EV_DictFctWithDocNb*sizeof(DICT_FCT_STP));
    EV_DictFctMainWithFinTab = (DICT_FCT_STP*) REALLOC(EV_DictFctMainWithFinTab,EV_DictFctMainWithFinNb*sizeof(DICT_FCT_STP));
    EV_DictFctSubWithFinTab = (DICT_FCT_STP**) REALLOC(EV_DictFctSubWithFinTab,EV_DictFctMainWithFinNb*sizeof(DICT_FCT_STP*));

/*  FIH-REF5578-010115  No more used
    EV_DictFctWithFinTab = (DICT_FCT_STP*) REALLOC(EV_DictFctWithFinTab,EV_DictFctWithFinNb*sizeof(DICT_FCT_STP));
*/
    if ((EV_DictFctWithFmtTab == NULL) ||
        (EV_DictFctWithDocTab == NULL) ||
        (EV_DictFctMainWithFinTab == NULL) ||
        (EV_DictFctSubWithFinTab == NULL))
    {
        FREE(EV_DictFctWithFmtTab);
        FREE(EV_DictFctWithDocTab);
        FREE(EV_DictFctMainWithFinTab);
        FREE(EV_DictFctSubWithFinTab);
        MSG_RETURN(RET_MEM_ERR_REALLOC);
    }
    return RET_SUCCEED;
}


/************************************************************************
**  Function             : DBA_UpdParAttrPtr()
**
**  Description          : For all attribute which have a parent attribute
**                         init pointer on this parent attribute
**
**  Arguments            : none
**
**  Return               : none
**
**  Last modif           : DLA - CSC16664 - 041013
**                         Rewrite function (memory error)
**
*************************************************************************/
STATIC void DBA_UpdParAttrPtr()
{
    for (auto it = DICT_GetDictEntityVector().begin(); it != DICT_GetDictEntityVector().end(); ++it)
    {
        DICT_ENTITY_STP dictEntityStp = *it;

        /* PMSTA-13122 - LJE - 120516 */
        if (dictEntityStp->xdStatusEn == XdStatus_Deleted ||
            dictEntityStp->xdStatusEn == XdStatus_Failed ||
            dictEntityStp->xdStatusEn == XdStatus_Untreated)
        {
            continue;
        }

        for (auto attribIt = dictEntityStp->attribMap.begin(); attribIt != dictEntityStp->attribMap.end(); ++attribIt)
        {
            if (attribIt->second->parAttrDictId != 0)
            {
                DICT_ATTRIB_STP attribStp = attribIt->second;
                DICT_ATTRIB_STP parentAttribStp = DBA_GetAttributeById(attribStp->parAttrDictId);

                if (parentAttribStp != nullptr)
                {
                    /* Parent attribute entity, progN and pointer */
                    attribStp->parAttrEntDictId = parentAttribStp->entDictId;
                    attribStp->parAttrProgN = parentAttribStp->progN;

                    /* For enum, get permitted value pointer. */
                    /* REF1357 - RAK - 980402 - On flag too. */
                    if ((attribStp->dataTpProgN == EnumType ||
                        attribStp->dataTpProgN == FlagType) &&
                        parentAttribStp->permValMap.empty() == false)
                    {
                        /* Keep permitted value list address */
                        attribStp->permValMap = parentAttribStp->permValMap;

                        /* Update default value */
                        if (attribStp->dfltVal.empty())
                        {
                            attribStp->dfltVal = parentAttribStp->dfltVal;
                        }
                    }
                }
            }
        }
    }
}

/************************************************************************
**
**  Function    :   DBA_CheckDataType
**
**  Description :   Check the datatypes between MD (Sybase) and the C definitions.
**
**  Argument    :   none
**
**  Return      :   RET_CODE
**
**  Cr�ation	:   REF11704 - TEB - 060502
**
**  Modif.		:
**
*************************************************************************/
STATIC RET_CODE	DBA_CheckDataType()
{
    char	*badTypeMsg = nullptr;

    for (size_t i=0; i< DBA_GetDictDataTpTab().size(); i++)
    {
        /* Compare DBA_GetDictDataTpTab().sqlName with EV_DataTypePtr[DBA_GetDictDataTpTab().progN].sqlName */
        if (i != static_cast<size_t>(DBA_GetDictDataTpTab()[i].progN) ||
            strcmp((DBA_GetDictDataTpTab()[i].sqlName), GET_SQLNAME(DBA_GetDictDataTpTab()[i].progN)) != 0)
        {
            if (badTypeMsg == nullptr &&
                (badTypeMsg = (char*)CALLOC(255, sizeof(char))) == NULL)
            {
                MSG_RETURN(RET_MEM_ERR_ALLOC);
            }

            /* Put a message in the log file */
            sprintf(badTypeMsg,
                    "Datatype mismatch for prog_n = %d between DB: sqlname = %s, and SRV: sqlname = %s !",
                    DBA_GetDictDataTpTab()[i].progN,
                    DBA_GetDictDataTpTab()[i].sqlName,
                    GET_SQLNAME(DBA_GetDictDataTpTab()[i].progN));

            MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, badTypeMsg);

            /* Stop if debug mode */
            SYS_BreakOnDebug();
        }

        if (GET_CTYPE(i) == CharPtrCType ||
            GET_CTYPE(i) == TextPtrCType ||
            GET_CTYPE(i) == UniCharPtrCType ||
            GET_CTYPE(i) == UniTextPtrCType ||
            GET_CTYPE(i) == VarCharPtrCType ||
            GET_CTYPE(i) == VarTextPtrCType)
        {
            char *startLength = strstr(DBA_GetDictDataTpTab()[i].equivType, "(");
            if (startLength && strcmp(startLength, "(max)") != 0)
            {
                unsigned int length = atoi(&startLength[1]);

                if (length != GET_MAXLEN(i))
                {
                    stringstream msg;
                    msg << "Mismatch length for data-type " << DBA_GetDictDataTpTab()[i].sqlName << ", in database: " << length << " but defined in C: " << GET_MAXLEN(i);

                    MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, msg.str().c_str());

                    /* Stop if debug mode */
                    SYS_BreakOnDebug();
                }
            }
        }
    }

    FREE(badTypeMsg);

    return (RET_SUCCEED);
}

/************************************************************************
**
**  Function        : DBA_CheckLicenseInfo
**
**  Description     : Check license entity information
**                    Centralize this analysis in this function
**
**  Arguments       : None
**
**  Return          : None
**
**  Creation		: HFI-PMSTA-35838-190515
**
************************************************************************/
void DBA_CheckLicenseInfo  (INFO_T  infoLicenceUser,
                            short   *psCoreNumber,
                            short   *psProductivityNumber,
                            short   *psAttributionLevel,
                            short   *psRiskNumber,
                            short   *psAccountingNumber,
                            short   *psFundNumber,
                            short   *psCorporateActioniNumber,
                            short   *psAdvancedAnalyticsLevel,
                            short   *psCompositeManagementNumber,
                            short   *psExcelReportNumber,
                            short   *psReturnAnalysisLevel,
                            short   *psAdvancedConstraintManagementNumber,
                            short   *psOrderManagementNumber,
                            short   *psCompoundOrderLevel,
                            short   *psRiskComplaianceLevel,
                            short   *psQuestionnaireLevel,
                            short   *psFinancialPlanningLevel,
                            short   *psDataFrameworkLevel,
                            short   *psCRMLevel)
{
    (void) sscanf ( infoLicenceUser,
                    "%hd,%hd,%hd,%hd,%hd,%hd,%hd,%hd,%hd,%hd,%hd,%hd,%hd,%hd,%hd,%hd,%hd,%hd,%hd",
                    psCoreNumber,
                    psProductivityNumber,
                    psAttributionLevel,
                    psRiskNumber,
                    psAccountingNumber,
                    psFundNumber,
                    psCorporateActioniNumber,
                    psAdvancedAnalyticsLevel,
                    psCompositeManagementNumber,
                    psExcelReportNumber,
                    psReturnAnalysisLevel,
                    psAdvancedConstraintManagementNumber,
                    psOrderManagementNumber,
                    psCompoundOrderLevel,
                    psRiskComplaianceLevel,
                    psQuestionnaireLevel,
                    psFinancialPlanningLevel,
                    psDataFrameworkLevel,
                    psCRMLevel);
}


/************************************************************************
**
**  Function        : DBA_CheckLicenseInfoEntity
**
**  Description     : Check license entity information
**
**  Arguments       : None
**
**  Return          : None
**
**  Creation		: HFI-PMSTA-35838-190515
**  Modif           : HFI-PMSTA-37951-201119    Manage logical attributes
**
************************************************************************/
void DBA_CheckLicenseInfoEntity (void)
{
    INFO_T  pszInfoLicenceUser;
    short   sCoreNumber,
            sProductivityNumber,
            sAttributionLevel,
            sRiskNumber,
            sAccountingNumber,
            sFundNumber,
            sCorporateActioniNumber,
            sAdvancedAnalyticsLevel,
            sCompositeManagementNumber,
            sExcelReportNumber,
            sReturnAnalysisLevel,
            sAdvancedConstraintManagementNumber,
            sOrderManagementNumber,
            sCompoundOrderLevel,
            sRiskComplaianceLevel,
            sQuestionnaireLevel,
            sFinancialPlanningLevel,
            sDataFrameworkLevel,
            sCRMLevel;

    GEN_GetApplInfo(ApplLicenseUsers, pszInfoLicenceUser);
    DBA_CheckLicenseInfo  ( pszInfoLicenceUser,
                            &sCoreNumber,
                            &sProductivityNumber,
                            &sAttributionLevel,
                            &sRiskNumber,
                            &sAccountingNumber,
                            &sFundNumber,
                            &sCorporateActioniNumber,
                            &sAdvancedAnalyticsLevel,
                            &sCompositeManagementNumber,
                            &sExcelReportNumber,
                            &sReturnAnalysisLevel,
                            &sAdvancedConstraintManagementNumber,
                            &sOrderManagementNumber,
                            &sCompoundOrderLevel,
                            &sRiskComplaianceLevel,
                            &sQuestionnaireLevel,
                            &sFinancialPlanningLevel,
                            &sDataFrameworkLevel,
                            &sCRMLevel);

    for (auto it = DICT_GetDictEntityVector().begin(); it != DICT_GetDictEntityVector().end(); ++it)
    {
        DICT_ENTITY_STP dictEntityStp = *it;

        if ((dictEntityStp != NULL) &&
            (dictEntityStp->licenseKeyEn != DictLicenseKey_None))
        {
            GEN_APPLINFO_ENUM   applParamLicenseEn = ApplLast;
            short               sNumber = 0;
            ENUM_T              licenseEn = 0;

            switch (dictEntityStp->licenseKeyEn)
            {
                case DictLicenseKey_CoreNumber:                         sNumber            = sCoreNumber;                         break;
                case DictLicenseKey_ProductivityNumber:                 sNumber            = sProductivityNumber;                 break;
                case DictLicenseKey_AttributionLevel:                   applParamLicenseEn = ApplPALicense;                       break;
                case DictLicenseKey_RiskNumber:                         sNumber            = sRiskNumber;                         break;
                case DictLicenseKey_AccountingNumber:                   sNumber            = sAccountingNumber;                   break;
                case DictLicenseKey_FundNumber:                         sNumber            = sFundNumber;                         break;
                case DictLicenseKey_CorporateActionsNumber:             sNumber            = sCorporateActioniNumber;             break;
                case DictLicenseKey_AdvancedAnalyticsLevel:             applParamLicenseEn = ApplAALicense;                       break;
                case DictLicenseKey_CompositeManagementNumber:          sNumber            = sCompositeManagementNumber;          break;
                case DictLicenseKey_ExcelReportNumber:                  sNumber            = sExcelReportNumber;                  break;
                case DictLicenseKey_ReturnAnalysisLevel:                applParamLicenseEn = ApplRALicense;                       break;
                case DictLicenseKey_AdvancedConstraintManagementNumber: sNumber            = sAdvancedConstraintManagementNumber; break;
                case DictLicenseKey_OrderManagementNumber:              sNumber            = sOrderManagementNumber;              break;
                case DictLicenseKey_CompoundOrderLevel:                 applParamLicenseEn = ApplCompOrderLicense;                break;
                case DictLicenseKey_RiskComplianceLevel:                applParamLicenseEn = ApplRiskComplianceLicense;           break;
                case DictLicenseKey_QuestionnaireLevel:                 applParamLicenseEn = ApplQuestionnaireLicence;            break;
                case DictLicenseKey_FinancialPlanningLevel:             applParamLicenseEn = ApplFinPlanningLicence;              break;
                case DictLicenseKey_DataFrameworkLevel:                 applParamLicenseEn = ApplDataFrameworkLicence;            break;
                case DictLicenseKey_CRMLevel:                           applParamLicenseEn = ApplCRMLicence;                      break;
            }
            if (applParamLicenseEn != ApplLast)
                GEN_GetApplInfo(applParamLicenseEn, &licenseEn);
            if ((licenseEn == 0) && (sNumber == 0))
                dictEntityStp->licenseAccessStatusEn = DictFctAuth_None;
            else
                dictEntityStp->licenseAccessStatusEn = DictFctAuth_Ok;
        }
    }

    /*  Logical Attribute linked to secured entity may be not visible       */  /*  HFI-PMSTA-37951-201119  */
    for (auto it = DICT_GetDictEntityVector().begin(); it != DICT_GetDictEntityVector().end(); ++it)
    {
        DICT_ENTITY_STP dictEntityStp = (*it);

        if (dictEntityStp != NULL)
        {
            for (auto& dictAttribStp : dictEntityStp->attr)
            {
                if ((dictAttribStp->logicalFlg != NULL) &&
                    (dictAttribStp->refDictEntityStp != NULL) &&
                    (dictAttribStp->refDictEntityStp->licenseKeyEn != DictLicenseKey_None) &&
                    (dictAttribStp->refDictEntityStp->licenseAccessStatusEn != DictFctAuth_Ok))
                {
                    dictAttribStp->subTypeMask = 0;
                }
            }
        }
    }
}


/************************************************************************
**
**  Function        : DBA_CheckLicenseInfoEntity
**
**  Description     : Check license entity information
**
**  Arguments       : None
**
**  Return          : None
**
**  Creation		: HFI-PMSTA-35838-190515
**
************************************************************************/
void DBA_CheckLicenseInfoFunction(std::vector<DICT_FCT_ST> &fctTab)        /*  Function security profile compo table */
{
    INFO_T  pszInfoLicenceUser;
    short   sCoreNumber,
            sProductivityNumber,
            sAttributionLevel,
            sRiskNumber,
            sAccountingNumber,
            sFundNumber,
            sCorporateActioniNumber,
            sAdvancedAnalyticsLevel,
            sCompositeManagementNumber,
            sExcelReportNumber,
            sReturnAnalysisLevel,
            sAdvancedConstraintManagementNumber,
            sOrderManagementNumber,
            sCompoundOrderLevel,
            sRiskComplaianceLevel,
            sQuestionnaireLevel,
            sFinancialPlanningLevel,
            sDataFrameworkLevel,
            sCRMLevel;

    GEN_GetApplInfo(ApplLicenseUsers, pszInfoLicenceUser);
    DBA_CheckLicenseInfo  ( pszInfoLicenceUser,
                            &sCoreNumber,
                            &sProductivityNumber,
                            &sAttributionLevel,
                            &sRiskNumber,
                            &sAccountingNumber,
                            &sFundNumber,
                            &sCorporateActioniNumber,
                            &sAdvancedAnalyticsLevel,
                            &sCompositeManagementNumber,
                            &sExcelReportNumber,
                            &sReturnAnalysisLevel,
                            &sAdvancedConstraintManagementNumber,
                            &sOrderManagementNumber,
                            &sCompoundOrderLevel,
                            &sRiskComplaianceLevel,
                            &sQuestionnaireLevel,
                            &sFinancialPlanningLevel,
                            &sDataFrameworkLevel,
                            &sCRMLevel);

    DICT_ENTITY_STP             pdictent = nullptr;
    for (auto it = fctTab.begin(); it != fctTab.end(); ++it)
    {
        if ((it->entityDictId > 0) &&
            ((pdictent = DBA_GetDictEntityByDictId(it->entityDictId)) != NULL) &&
            (pdictent->licenseKeyEn != DictLicenseKey_None) &&
            (pdictent->licenseAccessStatusEn != DictFctAuth_Ok))
        {
            it->accesStatus = DictFctAuth_None;
        }

        if (it->licenseKeyEn != DictLicenseKey_None)
        {
            GEN_APPLINFO_ENUM   applParamLicenseEn = ApplLast;
            short               sNumber = 0;
            ENUM_T              licenseEn = 0;

            switch (it->licenseKeyEn)
            {
                case DictLicenseKey_CoreNumber:                         sNumber = sCoreNumber;                          break;
                case DictLicenseKey_ProductivityNumber:                 sNumber = sProductivityNumber;                  break;
                case DictLicenseKey_AttributionLevel:                   applParamLicenseEn = ApplPALicense;             break;
                case DictLicenseKey_RiskNumber:                         sNumber = sRiskNumber;                          break;
                case DictLicenseKey_AccountingNumber:                   sNumber = sAccountingNumber;                    break;
                case DictLicenseKey_FundNumber:                         sNumber = sFundNumber;                          break;
                case DictLicenseKey_CorporateActionsNumber:             sNumber = sCorporateActioniNumber;              break;
                case DictLicenseKey_AdvancedAnalyticsLevel:             applParamLicenseEn = ApplAALicense;             break;
                case DictLicenseKey_CompositeManagementNumber:          sNumber = sCompositeManagementNumber;           break;
                case DictLicenseKey_ExcelReportNumber:                  sNumber = sExcelReportNumber;                   break;
                case DictLicenseKey_ReturnAnalysisLevel:                applParamLicenseEn = ApplRALicense;             break;
                case DictLicenseKey_AdvancedConstraintManagementNumber: sNumber = sAdvancedConstraintManagementNumber;  break;
                case DictLicenseKey_OrderManagementNumber:              sNumber = sOrderManagementNumber;               break;
                case DictLicenseKey_CompoundOrderLevel:                 applParamLicenseEn = ApplCompOrderLicense;      break;
                case DictLicenseKey_RiskComplianceLevel:                applParamLicenseEn = ApplRiskComplianceLicense; break;
                case DictLicenseKey_QuestionnaireLevel:                 applParamLicenseEn = ApplQuestionnaireLicence;  break;
                case DictLicenseKey_FinancialPlanningLevel:             applParamLicenseEn = ApplFinPlanningLicence;    break;
                case DictLicenseKey_DataFrameworkLevel:                 applParamLicenseEn = ApplDataFrameworkLicence;  break;
                case DictLicenseKey_CRMLevel:                           applParamLicenseEn = ApplCRMLicence;            break;
            }
            if (applParamLicenseEn != ApplLast)
                GEN_GetApplInfo(applParamLicenseEn, &licenseEn);
            if ((licenseEn == 0) && (sNumber == 0))
                it->accesStatus = DictFctAuth_None;
        }
    }
}

/************************************************************************
**
**  Function        : DBA_FillLicenseInfoEntity
**
**  Description     : Fill licence entity information
**
**  Arguments       : None
**
**  Return          : None
**
**  Creation		: HFI-PMSTA-35838-190515
**
************************************************************************/
STATIC void DBA_FillLicenseInfoEntity (DICT_T dictEntity, SYSNAME_T pszSqlname, DICT_LICENSEKEY_ENUM licenseKeyEn)
{
    DICT_ENTITY_STP     dictEntityStp = NULL;

    if (dictEntity != NullEntityCst)
        dictEntityStp = DBA_GetDictEntityByDictId(dictEntity);
    else if (pszSqlname != NULL)
        dictEntityStp = DBA_GetEntityBySqlName(pszSqlname);
    if (dictEntityStp != NULL)
    {
        dictEntityStp->licenseKeyEn = licenseKeyEn;
        dictEntityStp->licenseAccessStatusEn = DictFctAuth_None;
    }
}

/************************************************************************
**
**  Function        : DBA_FillLicenseInfo
**
**  Description     : Fill license entity information
**
**  Arguments       : None
**
**  Return          : None
**
**  Creation		: HFI-PMSTA-35838-190515
**  Modif           : HFI-PMSTA-37951-201119    Manage third Party sub_entities + add AccPer and FunDVal
**
************************************************************************/
void DBA_FillLicenseInfo (void)
{
    DBA_FillLicenseInfoEntity(AccPerCst,NULL,DictLicenseKey_FundNumber);
    DBA_FillLicenseInfoEntity(FundValCst,NULL,DictLicenseKey_FundNumber);
    DBA_FillLicenseInfoEntity(QuestDefCst,NULL,DictLicenseKey_QuestionnaireLevel);
    DBA_FillLicenseInfoEntity(QuestHistoCst,NULL,DictLicenseKey_QuestionnaireLevel);
    DBA_FillLicenseInfoEntity(PlanRuleCst,NULL,DictLicenseKey_FinancialPlanningLevel);
    DBA_FillLicenseInfoEntity(PlanDefinitionCst,NULL,DictLicenseKey_FinancialPlanningLevel);
}


/************************************************************************
**
**  Function        : DBA_FillEntitySecuritySuperUser
**
**  Description     : Add information concerning the entity security access for super user only
**
**  Arguments       : None
**
**  Return          : None
**
**  Creation		: HFI-PMSTA-54127-2024-02-06
**
************************************************************************/
void DBA_FillEntitySecuritySuperUser (void)
{
    DICT_ENTITY_STP pdictent = nullptr;

    for (auto it = DICT_GetDictEntityVector().begin(); it != DICT_GetDictEntityVector().end(); ++it)
    {
        pdictent = *it;
        switch (pdictent->entDictId)
        {
            case ApplUserCst:
            case ApplUserPreferenceCst:
            case LoginHistCst:
            case ClientConnectCst:
            case ServConnectCst:
            case ServiceConfigCst:
            case AuthenticationMechanismCst:
            case ApplParamCst:
            case ApplChannelCst:
            case DictLangCst:
            case DictEntityCst:
            case XdEntityCst:
            case DictDataTpCst:
            case DictDatabaseCst:
            case DictFctCst:
            case DictFctAttribCst:
            case ApplSessionCst:
            case ApplSessionHistoCst:
            case DataProfCst:
            case DataSecuProfCst:
            case ApplChannelProfCst:
            case FctSecuProfCst:
            case FmtProfCst:
            case ScreenProfCst:
            case ReportProfCst:
            case PrinterProfCst:
            case OptiProfCst:
            case ExtServiceProfCst:
            case SearchCritCst:
            case SearchProfCst:
            case MenuProfileCst:

            case FmtCst:
            case ApplMsgCst:
            case TabCntCst:
            case DictScreenCst:
            case ConstrTemplateCst:
            case CaseMsgTemplateCst:
            case MeDataOrgaCst:
            case GaugeDisplayCst:
            case SubscriptionCst:
            case EventCst:
            case EventStatusCst:
            case MapCst:
            case DataDependencyCst:
            case OutboxSchemaCst:
            case OutboxCst:
            case TascConfigCst:
            case TascAccentConvCst:
            case TslPrecJobCst:
            case EntityConfigCst:
            case EntityProfileCst:
            case ExportQueryCst:
            case ApplRuleCst:
            case ScriptDefCst:
            case CorporateActionCst:
                pdictent->bSecuredBySuperUser = true;
                break;
        }
    }
}

    
/************************************************************************
**
**  Function        : DBA_FillEntityPackageInfo
**
**  Description     : Fill information concerning the possibility to insert occurrences of an entity in a package
**
**  Arguments       : None
**
**  Return          : None
**
**  Creation		: HFI-PMSTA-41842-200916
**
************************************************************************/
void DBA_FillEntityPackageInfo (void)
{
    DICT_ENTITY_STP pdictent = nullptr;
    DBA_DYNFLD_STP  *pdbadyntab;
    int             iNbPckEnt;

    if ((EV_AAAInstallLevel == 0) &&
        ((SYS_IsGuiMode() == TRUE) ||
         (SYS_IsBatchMode() == TRUE) ||
         (SYS_IsSrvMode() == TRUE)) &&
        (DBA_Select2(PackageEntity,
                    UNUSED,
                    NullDynSt,
                    NULL,
                    S_PackageEntity,
                    &pdbadyntab,
                    UNUSED,
                    UNUSED,
                    &iNbPckEnt,
                    UNUSED,
                    NULL) == RET_SUCCEED) &&
        (iNbPckEnt > 0))
    {
        for (auto it = DICT_GetDictEntityVector().begin(); it != DICT_GetDictEntityVector().end(); ++it)
        {
            pdictent = *it;
            pdictent->enIsPackage = DictEntityClass::IsPackageEn::No;
        }
        for (int i = 0; i < iNbPckEnt; i++)
        {
            if ((IS_NULLFLD(pdbadyntab[i], S_PackageEntity_EntityDictId) == FALSE) &&
                ((pdictent = DBA_GetDictEntityByDictId(GET_DICT(pdbadyntab[i], S_PackageEntity_EntityDictId))) != NULL))
            {
                OBJECT_ENUM     enObject;
                DBA_GetObjectEnum(pdictent->entDictId, &enObject);
                pdictent->enIsPackage = DictEntityClass::IsPackageEn::Record;
            }
        }
        DBA_FreeDynStTab(pdbadyntab, iNbPckEnt, S_PackageEntity);
    }
}


/************************************************************************
**
**  Function        : DBA_CompleteMetaDict
**
**  Description     : Complete loaded meta dictionary with missing info
**                    Add link between dimension and object attributes
**
**  Arguments       : None
**
**  Return          : RET_SUCCEED or error code
**
**  Creation		: FIH-REF11457-051005
**
************************************************************************/
STATIC void DBA_CompleteMetaDict(void)
{
    DICT_T      typeDictId, dictEntDictId;

    DBA_GetDictId(Tp, &typeDictId);
    DBA_GetDictId(DictEntity, &dictEntDictId); /* OCS-43062 - LJE - 130911 */

    /* PMSTA-11505 - LJE - 110720 */
    std::string dbName;
    GEN_GetApplInfo(ApplSqlDbName, dbName);

    /*  FIH-REF11563-051209 */
    for (auto it = DICT_GetDictEntityVector().begin(); it != DICT_GetDictEntityVector().end(); ++it)
    {
        DICT_ENTITY_STP dictEntityStp = *it;

        /* PMSTA-13122 - LJE - 120516 */
        if (dictEntityStp->xdStatusEn == XdStatus_Deleted ||
            dictEntityStp->xdStatusEn == XdStatus_Failed ||
            dictEntityStp->xdStatusEn == XdStatus_Untreated)
        {
            continue;
        }

        for (auto& dictAttribStp : dictEntityStp->attr)
        {
            if (dictAttribStp == nullptr)
            {
                continue;
            }

            dictAttribStp->iDimIndex = -1;
            dictAttribStp->iObjIndex = -1;
            dictAttribStp->enDefListObject = NullEntity;
            dictAttribStp->copyRightEn = DictAttrCopyNat_NoCopy;

            if ((dictAttribStp->dataTpProgN == IdType ||
                 dictAttribStp->dataTpProgN == DictType) &&
                dictAttribStp->refEntDictId == 0 &&
                dictAttribStp->linkedAttrDictStp != NULL &&
                dictAttribStp->linkedAttrDictStp->refEntDictId == dictEntDictId)
            {
                dictAttribStp->iDimIndex = dictAttribStp->linkedAttrDictStp->progN;
                dictAttribStp->linkedAttrDictStp->iObjIndex = dictAttribStp->progN;
            }

            

            /* PMSTA-28916 - LJE - 171219 */
            if ((dictAttribStp->dataTpProgN == DictType) ||
                (dictAttribStp->dataTpProgN == IdType))
            {
                if ((dictAttribStp->logicalFlg == FALSE) &&         /* PMSTA-11505 - LJE - 110616 */
                    (dictAttribStp->linkedAttrDictStp != NULL))     /* PMSTA-13122 - LJE - 120612 */
                {
                    if (dictAttribStp->refEntDictId == 0)
                    {
                        if (dictAttribStp->linkedAttrDictStp->entDictId != dictAttribStp->entDictId)
                        {
                            if (EV_AAAInstallLevel == 0 || dictEntityStp->bIsInitEntity == true)
                            {
                                MSG_SendMesg(RET_DBA_ERR_MD, 5, FILEINFO,
                                             dictEntityStp->mdSqlName,
                                             dictAttribStp->sqlName,
                                             "Linked attribute cannot be on other entity");
                            }
                        }
                        else
                        {
                            OBJECT_ENUM objEn;
                            int         idx;
                            DBA_GetObjectEnum(dictEntityStp->entDictId, &objEn);
                            idx = dictAttribStp->linkedAttrDictStp->progN; /* PMSTA-13122 - LJE - 120612 */
                            DBA_CompleteMetaDictWithDimObjLink(objEn, idx, dictAttribStp->progN, NullEntity);
                        }
                    }
                }
                /*  Manage the rights to copy at attribute level    */  /*  HFI-PMSTA-39490-190520  */
                else if (dictAttribStp->logicalFlg == TRUE)
                {
                    if ((strcmp(dictAttribStp->sqlName,"script_control") == 0) ||
                        ((strcmp(dictAttribStp->sqlName,"script_definition") == 0) && (dictAttribStp->dictEntityStp->objectEn == XdAttrib)) ||
                        (strcmp(dictAttribStp->sqlName,"parent_reference_format") == 0) ||
                        (strcmp(dictAttribStp->sqlName,"child_reference_format") == 0) ||
                        (strcmp(dictAttribStp->sqlName,"parent_reference_dict_screen") == 0) ||
                        (strcmp(dictAttribStp->sqlName,"child_reference_dict_screen") == 0) ||
                        (strcmp(dictAttribStp->sqlName,"package_def_installation_id") == 0) ||          /*  HFI-PMSTA-41842-200916  */
                        (strcmp(dictAttribStp->sqlName,"dict_function_attribute") == 0) ||              /*  HFI-PMSTA-46648-211011  */
                        (dictAttribStp->refDictEntityStp != nullptr && dictAttribStp->refDictEntityStp->objectEn == Empty))
                    {
                        dictAttribStp->copyRightEn = DictAttrCopyNat_Denied;
                    }
                    else if (dictAttribStp->refEntDictId != 0)
                    {
                        DICT_ENTITY_STP dictEntityLogicalStp;
                        dictEntityLogicalStp = DBA_GetDictEntityByDictId(dictAttribStp->refEntDictId);
                        if (dictEntityLogicalStp != nullptr)
                        {
                            dictAttribStp->copyRightEn = dictEntityLogicalStp->copyRightEn;

                            /*  the copy business unit membership from business unit is not allowed */  /*  HFI-PMSTA-51611-20230213    */
                            /*  the copy is only allowed from appl_user                             */
                            if ((dictAttribStp->dictEntityStp->objectEn == BusinessUnit) &&
                                (dictEntityLogicalStp->objectEn == BusinessUnitMembership))
                            {
                                dictAttribStp->copyRightEn = DictAttrCopyNat_Denied;
                            }
                        }
                    }
                }
            }
        }

        dictEntityStp->iNbLinkedDimObj = 0 ;

        /*  Get the nature used of select all: it is the default value in FRont     */  /*  HFI-PMSTA-55081-2023-11-24  */
        if (dictEntityStp->tpNatEn != NoTyping)
        {
            dictEntityStp->enSelectNature = DBA_GetNatureForSelectAll(dictEntityStp->objectEn);
        }
    }

    DBA_CompleteMetaDictWithDimObjLink(SearchLnk     , A_SearchLnk_DimPortDictId           , A_SearchLnk_PortObjId           , Ptf       );
    DBA_CompleteMetaDictWithDimObjLink(SearchLnk     , A_SearchLnk_DimStratDictId          , A_SearchLnk_StratObjId          , Strat     );
    /*  FPL-REF11563-051124 */
    DBA_CompleteMetaDictWithDimObjLink(ConstraintParameter  , A_ConstraintParameter_DimConstraintDictId , A_ConstraintParameter_ConstrObjId , TradConstr);
    DBA_CompleteMetaDictWithDimObjLink(Notepad          , A_Notepad_EntDictId               , A_Notepad_ObjId               , NullEntity);
    DBA_CompleteMetaDictWithDimObjLink(Archive          , A_Archive_DimEntDictId            , A_Archive_ObjectId            , Ptf       );
    DBA_CompleteMetaDictWithDimObjLink(Denom            , A_Denom_EntDictId                 , A_Denom_ObjId                 , NullEntity);
    DBA_CompleteMetaDictWithDimObjLink(Synon            , A_Synon_EntityDictId                 , A_Synon_ObjId                 , NullEntity);
    DBA_CompleteMetaDictWithDimObjLink(List             , A_List_EntityDictId               , A_List_ParentObjId            , NullEntity);
    DBA_CompleteMetaDictWithDimObjLink(ListCompo        , A_ListCompo_EntDictId             , A_ListCompo_ObjId             , NullEntity);
    DBA_CompleteMetaDictWithDimObjLink(ReturnGridLnk    , A_ReturnGridLnk_EntDictId         , A_ReturnGridLnk_ObjId         , NullEntity);
    DBA_CompleteMetaDictWithDimObjLink(Strat            , A_Strat_DimGridDictId             , A_Strat_GridObjId             , Grid      );
    DBA_CompleteMetaDictWithDimObjLink(Strat            , A_Strat_BenchEntityDictId            , A_Strat_BenchObjId            , Instr     );  /*  FIH-REF11457-060123 Put Instr instaed of NullEntity */
    DBA_CompleteMetaDictWithDimObjLink(StratElt         , A_StratElt_BenchEntDictId         , A_StratElt_BenchObjId         , Ptf       );
    DBA_CompleteMetaDictWithDimObjLink(StratElt         , A_StratElt_AnaBenchEntDictId      , A_StratElt_AnaBenchObjId      , Ptf       );
    DBA_CompleteMetaDictWithDimObjLink(StratLnk         , A_StratLnk_EntDictId              , A_StratLnk_ObjId              , Ptf       );
    DBA_CompleteMetaDictWithDimObjLink(StratLnk         , A_StratLnk_FromEntDictId          , A_StratLnk_FromObjId          , NullEntity);
    DBA_CompleteMetaDictWithDimObjLink(StratLnk         , A_StratLnk_ToEntDictId            , A_StratLnk_ToObjId            , NullEntity);
    DBA_CompleteMetaDictWithDimObjLink(EStratLnk        , ExtStratLnk_LnkObjDictId          , ExtStratLnk_ObjId             , Ptf       );
    DBA_CompleteMetaDictWithDimObjLink(EStratElt        , ExtStratElt_BenchEntDictId        , ExtStratElt_BenchObjId        , Ptf       );
    DBA_CompleteMetaDictWithDimObjLink(EStratElt        , ExtStratElt_AnaBenchEntDictId     , ExtStratElt_AnaBenchObjId     , Ptf       );
    DBA_CompleteMetaDictWithDimObjLink(ModelConstr      , A_ModelConstr_DimPortDictId        , A_ModelConstr_PortObjId        , Ptf       );
    DBA_CompleteMetaDictWithDimObjLink(ModelConstrElt   , A_ModelConstrElt_DimInstrDictId   , A_ModelConstrElt_InstrObjId   , Instr     );
    DBA_CompleteMetaDictWithDimObjLink(DerivedStratElt  , A_DerivedStratElt_BenchEntDictId  , A_DerivedStratElt_BenchObjId  , NullEntity);
    DBA_CompleteMetaDictWithDimObjLink(TradConstr       , A_TradConstr_DimPortDictId         , A_TradConstr_PortObjId         , Ptf       );
    DBA_CompleteMetaDictWithDimObjLink(StratCompo       , A_StratCompo_EntDictId            , A_StratCompo_ObjId            , Strat     );
    DBA_CompleteMetaDictWithDimObjLink(ScenaElt         , A_ScenaElt_DictId                 , A_ScenaElt_ObjId              , NullEntity);
    DBA_CompleteMetaDictWithDimObjLink(SectAttr         , A_SectAttr_EntDictId              , A_SectAttr_ObjId              , NullEntity);
    DBA_CompleteMetaDictWithDimObjLink(RatingAttr       , A_RatingAttr_EntDictId            , A_RatingAttr_ObjId            , NullEntity);
    DBA_CompleteMetaDictWithDimObjLink(PerfStorageParam , A_PerfStorageParam_EntityDictId      , A_PerfStorageParam_ObjId      , Ptf       );
    DBA_CompleteMetaDictWithDimObjLink(PerfAttribData   , A_PerfAttribData_BenchEntDictId   , A_PerfAttribData_BenchObjId   , NullEntity);
    DBA_CompleteMetaDictWithDimObjLink(EventSched       , A_EventSched_EntityDictId         , A_EventSched_ObjId         , Ptf       );
    DBA_CompleteMetaDictWithDimObjLink(DictLabel        , A_DictLabel_EntDictId             , A_DictLabel_ObjDictId         , NullEntity);
    DBA_CompleteMetaDictWithDimObjLink(Domain           , A_Domain_DimPtfDictId             , A_Domain_PtfObjId             , InvalidEntity);       /*  HFI-PMSTA-21521-151030  remove information present in metadictionnary   */
    DBA_CompleteMetaDictWithDimObjLink(Domain           , A_Domain_DimInstrDictId           , A_Domain_InstrObjId           , Instr);
    DBA_CompleteMetaDictWithDimObjLink(Domain           , A_Domain_DimStratDictId           , A_Domain_StratObjId           , Strat);
    DBA_CompleteMetaDictWithDimObjLink(Domain           , A_Domain_Bench1EntityDictId       , A_Domain_Bench1ObjectId       , Ptf       );
    DBA_CompleteMetaDictWithDimObjLink(Domain           , A_Domain_Bench2EntityDictId       , A_Domain_Bench2ObjectId       , Ptf       );
    DBA_CompleteMetaDictWithDimObjLink(Domain           , A_Domain_Bench3EntityDictId       , A_Domain_Bench3ObjectId       , Ptf       );
    DBA_CompleteMetaDictWithDimObjLink(ScriptDef        , A_ScriptDef_DimEntityDictId       , A_ScriptDef_ObjId             , NullEntity);
    DBA_CompleteMetaDictWithDimObjLink(HoldingConstraintScript, A_HoldingConstraintScript_DimEntityDictId, A_HoldingConstraintScript_ObjId, NullEntity);  /* PMSTA-28970 / PMSTA-30161 - CHU - 180103 */
    DBA_CompleteMetaDictWithDimObjLink(TradingConstraintScript, A_TradingConstraintScript_DimEntityDictId, A_TradingConstraintScript_ObjId, NullEntity);  /* PMSTA-28970 / PMSTA-30161 - CHU - 180103 */
    DBA_CompleteMetaDictWithDimObjLink(CompInstrChrono  , A_CompInstrChrono_EntDictId       , A_CompInstrChrono_ObjId       , Instr     );
    DBA_CompleteMetaDictWithDimObjLink(CheckList        , A_CheckList_EntDictId             , A_CheckList_ObjId             , NullEntity);
    DBA_CompleteMetaDictWithDimObjLink(CurrModif        , Curr_Modif_EntDictId              , Curr_Modif_ObjId              , NullEntity);
    DBA_CompleteMetaDictWithDimObjLink(ExtRetAnalysis   , A_ExtRetAnalysis_EntDictId        , A_ExtRetAnalysis_ObjId        , Ptf       );
    DBA_CompleteMetaDictWithDimObjLink(ExtTransaction   , A_ExtTransaction_SrcEntityDictId  , A_ExtTransaction_SrcObjectId  , NullEntity);
    DBA_CompleteMetaDictWithDimObjLink(FctResult        , A_FctResult_DimPtfDictId          , A_FctResult_PtfObjId          , Ptf       );
    DBA_CompleteMetaDictWithDimObjLink(FctResult        , A_FctResult_DimInstrDictId        , A_FctResult_InstrObjId        , Instr     );
    DBA_CompleteMetaDictWithDimObjLink(FctResult        , A_FctResult_DimStratDictId        , A_FctResult_StratObjId        , Strat     );
    DBA_CompleteMetaDictWithDimObjLink(PerfAttrib       , A_PerfAttrib_EntDictId            , A_PerfAttrib_ObjId            , NullEntity);
    DBA_CompleteMetaDictWithDimObjLink(PerfAttrib       , A_PerfAttrib_BenchEntDictId       , A_PerfAttrib_BenchObjId       , NullEntity);
    DBA_CompleteMetaDictWithDimObjLink(PtfFusionEnt     , PtfFusion_DimPortDictId           , PtfFusion_PortObjectId        , Ptf       );
    DBA_CompleteMetaDictWithDimObjLink(StandardPerf     , A_StandardPerf_EntDictId          , A_StandardPerf_ObjId          , NullEntity);
    DBA_CompleteMetaDictWithDimObjLink(CaseManagement   , A_CaseManagement_MainEntityDictId , A_CaseManagement_MainObjId    , NullEntity);
    DBA_CompleteMetaDictWithDimObjLink(CaseLink         , A_CaseLink_EntDictId              , A_CaseLink_ObjId              , NullEntity);
    DBA_CompleteMetaDictWithDimObjLink(StratSynth       , A_StratSynth_BenchEntDictId       , A_StratSynth_BenchObjId       , Instr);
    DBA_CompleteMetaDictWithDimObjLink(ApplComment      , A_ApplComment_EntityDictId        , A_ApplComment_ObjectId        , NullEntity);      /*  HFI-PMSTA10733-101217   */
    DBA_CompleteMetaDictWithDimObjLink(ObjectModifStat	, A_ObjectModifStat_ImpactedEntityDictId , A_ObjectModifStat_ImpactedObjId , NullEntity);	/* PMSTA-13130 - 191211 - PMO */
    DBA_CompleteMetaDictWithDimObjLink(CompComplChrono  , A_CompComplChrono_EntDictId       , A_CompComplChrono_ObjId       , Ptf       );      /*  HFI-PMSTA-18426-141015  */
    DBA_CompleteMetaDictWithDimObjLink(RiskValueElt     , A_RiskValueElt_EntityDictId       , A_RiskValueElt_ObjId          , NullEntity);      /* PMSTA-18426 - CHU - 141020 */
    DBA_CompleteMetaDictWithDimObjLink(QuestHisto       , A_QuestHisto_AnswerEntityDictId   , A_QuestHisto_AnswerObjId      , NullEntity);      /* PMSTA-19243 - DDV - 150507 */
    DBA_CompleteMetaDictWithDimObjLink(ListBuildHistoryCompo , A_ListBuildHistoryCompo_EntityDictId   , A_ListBuildHistoryCompo_ObjId   , NullEntity);
    DBA_CompleteMetaDictWithDimObjLink(SmartRoundingRuleCompo, A_SmartRoundingRuleCompo_DimInstrDictId, A_SmartRoundingRuleCompo_InstrObjId, Instr); /* PMSTA-40493-badhri-08252020: smart rounding rule  */
    DBA_CompleteMetaDictWithDimObjLink(UserEntityAccessRight, A_UserEntityAccessRight_EntityDictId,  A_UserEntityAccessRight_ObjId,  Ptf); /*PMSTA-45362 -Kramadevi - 21062021*/
    DBA_CompleteMetaDictWithDimObjLink(PerfCalcResult   , A_PerfCalcResult_EntityDictId     , A_PerfCalcResult_ObjId        , Ptf);        /* PMSTA-47578 - DDV - 220316 */

    /*  Manage edition mask particular case             */  /*  HFI-PMSTA-38117-200109  */
    for (auto it = DICT_GetDictEntityVector().begin(); it != DICT_GetDictEntityVector().end(); ++it)
    {
        DICT_ENTITY_STP dictEntityStp = *it;

        for (auto& dictAttribStp : dictEntityStp->attr)
        {
            dictAttribStp->editionMask = dictAttribStp->subTypeMask;
        }
    }
    DBA_CompleteMetaDictEditionMask(ReferenceFormatElement, A_ReferenceFormatElement_SqlName ,      (ENUM_T) ReferenceFormatElementReferenceNatEn::Modified,FALSE);
    DBA_CompleteMetaDictEditionMask(ReferenceFormatElement, A_ReferenceFormatElement_SqlName ,      (ENUM_T) ReferenceFormatElementReferenceNatEn::Deleted, FALSE);
    DBA_CompleteMetaDictEditionMask(ReferenceFormatElement, A_ReferenceFormatElement_Rank ,         (ENUM_T) ReferenceFormatElementReferenceNatEn::Modified,FALSE);
    DBA_CompleteMetaDictEditionMask(ReferenceFormatElement, A_ReferenceFormatElement_Rank ,         (ENUM_T) ReferenceFormatElementReferenceNatEn::Deleted, FALSE);
    DBA_CompleteMetaDictEditionMask(ReferenceFormatElement, A_ReferenceFormatElement_DataTpDictId , (ENUM_T) ReferenceFormatElementReferenceNatEn::Modified,FALSE);
    DBA_CompleteMetaDictEditionMask(ReferenceFormatElement, A_ReferenceFormatElement_DataTpDictId , (ENUM_T) ReferenceFormatElementReferenceNatEn::Deleted, FALSE);

    if (EV_AAAInstallLevel == 0)
    {
    /*  TO BE ACTIVATED ASAP    HFI                         */
        for (auto it = DICT_GetDictEntityVector().begin(); it != DICT_GetDictEntityVector().end(); ++it)
        {
            DICT_ENTITY_STP dictEntityStp = *it;

            for (auto& dictAttribStp : dictEntityStp->attr)
            {
                if ((dictEntityStp->logicalFlg == FALSE) &&
                    ((dictAttribStp->dataTpProgN == IdType) ||
                     (dictAttribStp->dataTpProgN == DictType)) &&
                    (dictAttribStp->refEntDictId <= 0) &&
                    (dictAttribStp->linkedAttrDictId <= 0) && /* PMSTA-13122 - LJE - 120531 */
                    (dictAttribStp->calcEn != DictAttr_Virtual) &&
                    (dictAttribStp->calcEn != DictAttr_NoMD) &&
                    (dictAttribStp->custFlg == FALSE) &&
                    (dictAttribStp->iDimIndex == -1) &&
                    (dictAttribStp->primFlg == FALSE) &&
                    (strcmp(dictAttribStp->sqlName,"id") != 0) &&
                    (strcmp(dictAttribStp->sqlName,"dict_id") != 0) &&
                    dictAttribStp->featureEn != XdEntityFeatureFeatureEn::TSLExtensions)
                {
                    /* Special cases that must not stop the program */
                    if (dictEntityStp->objectEn == Domain && dictAttribStp->progN == A_Domain_PtfObjId)
                        continue;

                    if ((SYS_StringCompareInsensitive(dictEntityStp->databaseName,dbName)) == false)
                        continue;

                    MSG_SendMesg(RET_DBA_ERR_MD, 5, FILEINFO,
                            dictEntityStp->mdSqlName,
                            dictAttribStp->sqlName,
                            "Ref. entity dict id is missing");
                }
            }
        }
    }
    DBA_FillLicenseInfo();
    /*  Add information concerning the possibility to insert occurrences of an entity in a package  */  /*  HFI-PMSTA-41842-200916  */
    DBA_FillEntityPackageInfo();
    /*  Add information concerning the entity security access for super user only                   */  /*  HFI-PMSTA-54127-2024-02-06  */
    DBA_FillEntitySecuritySuperUser();
}

/************************************************************************
**
**  Function        : DBA_CompleteMetaDictEditionMask
**
**  Description     : Complete loaded meta dictionary with missing info
**                    Indicate how the attribute is editable for the given nature
**
**  Arguments       : OBJECT_ENUM   enObject        : entity ref
**                    int           iAttributeIndex : attribute index
**                    ENUM_T        enNature        : nature
**                    FLAG_T        flagEditable    : TRUE the attribute is editable for the nature
**
**  Return          : None
**
**  Creation		: HFI-PMSTA-38117-200202
**
************************************************************************/
STATIC void DBA_CompleteMetaDictEditionMask (   OBJECT_ENUM enObject,
                                                int         iAttributeIndex,
                                                ENUM_T      enNature,
                                                FLAG_T      flagEditable)
{
    DICT_ATTRIB_STP         pdictattr;
    if (DICT_GetAttribInfo( enObject,
                            (short) iAttributeIndex,
                            0,
                            NULL,
                            GET_FIX_NBR(A_DictAttr),
                            &pdictattr) == RET_SUCCEED)
    {
        if (flagEditable == TRUE)
        {
            pdictattr->editionMask |= (1 << enNature);
        }
        else
        {
            pdictattr->editionMask &= ~(1 << enNature);
        }
    }
}


/************************************************************************
**
**  Function        : DBA_CompleteMetaDictWithDimObjLink
**
**  Description     : Complete loaded meta dictionary with missing info
**                    Add link between dimension and object attributes
**
**  Arguments       : OBJECT_ENUM   enObject    : entity ref
**                    int           iDimIndex   : index
**
**  Return          : None
**
**  Creation		: FIH-REF11457-051005
**
************************************************************************/
STATIC void DBA_CompleteMetaDictWithDimObjLink  (OBJECT_ENUM enObject,
                                                int         iDimIndex,
                                                int         iObjIndex,
                                                OBJECT_ENUM enDefListObject)
{
    DICT_ATTRIB_STP     pdictattrDim,       /*  Dict attribute dimension    */
                        pdictattrObj;       /*  Dict attribute Object       */

    if ((DICT_GetAttribInfo(enObject,
                            (short) iDimIndex,
                            0,
                            NULL,
                            GET_FIX_NBR(A_DictAttr),
                            &pdictattrDim) == RET_SUCCEED) &&
        (DICT_GetAttribInfo (enObject,
                            (short) iObjIndex,
                            0,
                            NULL,
                            GET_FIX_NBR(A_DictAttr),
                            &pdictattrObj) == RET_SUCCEED))
    {
        if (InvalidEntity == enDefListObject)               /*  HFI-PMSTA-21521-151030  remove information present in meta-dictionary   */
        {
            pdictattrDim->iObjIndex = -1;
            pdictattrDim->enDefListObject = -1;
            pdictattrObj->iDimIndex = -1;
        }
        else
        {
            pdictattrDim->iObjIndex = iObjIndex;
            pdictattrDim->enDefListObject = enDefListObject;
            pdictattrObj->iDimIndex = iDimIndex;
            DICT_ENTITY_STP dictEntityStp = DBA_GetDictEntitySt(enObject);
            if (dictEntityStp)
            {
                dictEntityStp->iNbLinkedDimObj++;  /*  FPL-REF11563-051209 */
            }
        }
    }
}

/************************************************************************
**  Function             : DBA_GenerateAllAttrib()
**
**  Description          : Database meta-dictionary return information on
**                         1. fixed fields +
**                            some calculated fields (no-database but
**                            referenced in meta-dictionary)
**                         2. logical fields
**                         3. customer fields
**                         order by database progN
**
**                         This function construct for each entity a new
**                         attribute table which will contain information on
**                         1. fixed fields + some calculated fields
**                         2. internal fields like extension
**                         3. customer fields
**                         4. logical fields
**                         order by new progN
**
**                         The progN in this table will be
**                         - #define value in descdyn.h for fixed fields
**                             and internal fields
**                            (equal to database progN for fixed fields)
**
**                         - #define fixFldNbr + x for customer fields
**                             and logical fields
**
**                         The attributes number in entity structure will be
**                         modified too.
**
**  Arguments            : none
**
**  Return               : RET_SUCCEED or error code
**  Last modif.          : REF8014 - 020930 - PMO : BoundsChecker message
**                         OCS-45323 - 031014 - PMO : F2B - Single Order. Entity ext_strategy_element Field : short index error
**
*************************************************************************/
RET_CODE DBA_GenerateAllAttrib(OBJECT_ENUM objectEn)
{
    extern OBJECT_ENUM SV_EntityGuiStTabSize;

    if (objectEn == NullEntity)
    {
        assert(SV_EntityGuiStTabSize == (OBJECT_ENUM) DICT_GetDictEntityVector().size());
    }

    for (auto &dictEntityStp : DICT_GetDictEntityVector())
    {
        OBJECT_ENUM     entityP = dictEntityStp->objectEn;

        if (objectEn == NullEntity || objectEn == entityP)
        {
            FLAG_T             updShortIdxFlg = FALSE;

            /* PMSTA-13122 - LJE - 120516 */
            if (entityP == InvalidEntity ||
                dictEntityStp->xdStatusEn == XdStatus_Deleted ||
                dictEntityStp->xdStatusEn == XdStatus_Failed)
            {
                continue;
            }

            while (dictEntityStp->attribMap.begin() != dictEntityStp->attribMap.end() &&
                   dictEntityStp->attribMap.begin()->first < 0)
            {
                dictEntityStp->attribMap.erase(dictEntityStp->attribMap.begin());
            }

            DBA_DYNST_ENUM     dynSt = GET_EDITGUIST(entityP);

            DBA_DYNST_STP dynStStp = &(EV_DynStPtr[dynSt]);

            /* PMSTA-17656 - DDV - 140312 */
            if (GET_ADMINGUIST(entityP) == GET_EDITGUIST(entityP) &&
                (objectEn == NullEntity || dictEntityStp->shortDictCriteriaMap.empty() == true))
            {
                updShortIdxFlg = TRUE;
            }

            if (dynStStp->noMDFldNbr > 0)
            {
                auto attrVector = dictEntityStp->attr;
                auto attrIt = attrVector.begin();

                dictEntityStp->attr.clear();

                FIELD_IDX_T fixedPos = 0;

                while (attrIt != attrVector.end() &&
                       (*attrIt)->logicalFlg == FALSE &&
                       (*attrIt)->custFlg    == FALSE &&
                       (*attrIt)->precompFlg == FALSE &&
                       (*attrIt)->calcEn     != DictAttr_NoMD)
                {
                    assert((*attrIt)->progN == static_cast<INT_T>(dictEntityStp->attr.size()));
                    dictEntityStp->attr.push_back(*attrIt);
                    ++fixedPos;
                    ++attrIt;
                }

                /* Fill informations for no meta-dictionary fields */
                for (int i = fixedPos; i < dynStStp->fldNbr; i++, fixedPos++)
                {
                    DBA_DYNSTDEF_STP fieldStp = &(dynStStp->dynStDefPtr[fixedPos]);

                    if (fieldStp->dictAttribStp != nullptr)
                    {
                        if (fieldStp->dictAttribStp->entDictId == dictEntityStp->entDictId)
                        {
                            fieldStp->dictAttribStp->progN = fixedPos;
                            assert(fieldStp->dictAttribStp->progN == static_cast<INT_T>(dictEntityStp->attr.size()));
                            dictEntityStp->attr.push_back(fieldStp->dictAttribStp);
                            continue;
                        }
                        else
                        {
                            auto attribIt = dictEntityStp->sortedAttr.find(fieldStp->sqlName);
                            if (attribIt != dictEntityStp->sortedAttr.end())
                            {
                                attribIt->second->progN = fixedPos;
                                assert(attribIt->second->progN == static_cast<INT_T>(dictEntityStp->attr.size()));
                                dictEntityStp->attr.push_back(attribIt->second);
                                continue;
                            }
                        }
                    }

                    DICT_T attribDictId = -1 * ((dictEntityStp->entDictId * 1000) + i + 1);

                    DICT_ATTRIB_ST& attribSt = dictEntityStp->addDictAttrib(attribDictId, -1, fieldStp->sqlName);

                    attribSt.progN = fixedPos;
                    attribSt.entDictId = dictEntityStp->entDictId;
                    attribSt.dictEntityStp = dictEntityStp;

                    assert(attribSt.progN == static_cast<INT_T>(dictEntityStp->attr.size()));
                    dictEntityStp->attr.push_back(&attribSt);

                    if (fieldStp != nullptr)
                    {
                        strcpy(attribSt.sqlName, fieldStp->sqlName);
                        strcpy(attribSt.name, fieldStp->sqlName);
                        attribSt.dataTpProgN = fieldStp->dataType;

                        if (fieldStp->cFieldDefStp == nullptr ||
                            fieldStp->cFieldDefStp->subFeatureEn == SubFeature::Tech)
                        {
                            attribSt.subFeatureEn = SubFeature::Tech;
                        }
                    }
                    else
                    {
                        attribSt.subFeatureEn = SubFeature::Tech;
                    }

                    attribSt.SET_daLabel(EMPTY_STR);/* PMSTA-22278 - 160203 - DDV - Use char* and UChar* instead of STRING1000_T and UNI_STRING1000_T */
                    attribSt.SET_daUniLabel(EMPTY_USTR); /* REF9303 - LJE - 030912 *//* PMSTA-22278 - 160203 - DDV - Use char* and UChar* instead of STRING1000_T and UNI_STRING1000_T */

                    attribSt.refEntDictId = 0;
                    attribSt.parAttrDictId = 0;
                    attribSt.progPkN = 0;
                    attribSt.isNullProgPkN = true;
                    attribSt.dispRank = 0;
                    attribSt.primFlg = FALSE;
                    attribSt.mandatoryFlg = FALSE;
                    attribSt.dbMandatoryFlg = FALSE;
                    attribSt.dfltVal.clear();
                    attribSt.busKeyFlg = FALSE;
                    attribSt.progBkN = 0;
                    attribSt.isNullProgBkN = true;
                    attribSt.logicalFlg = FALSE;
                    attribSt.custFlg = FALSE;
                    attribSt.calcEn = DictAttr_NoMD;
                    attribSt.permAuthEn = PermAuth_No;
                    attribSt.editionEn = DictAttrib_EditInsUpd;
                    attribSt.qSearchMask = 0;
                    attribSt.searchMask = 0;
                    attribSt.subTypeMask = 0;
                    attribSt.editionMask = 0;               /*  HFI-PMSTA-38117-200109  */
                    attribSt.parAttrEntDictId = 0;
                    attribSt.parAttrProgN = 0;
                    attribSt.shortIdx = 0;
                    attribSt.isNullShortIdx = true;
                    attribSt.xdStatusEn = XdStatus_Inserted;
                }
            }

            /* Force new progN */
            for (auto attribIt = dictEntityStp->attr.begin(); attribIt != dictEntityStp->attr.end(); ++attribIt)
            {
                /* PMSTA-17656 - DDV - 140312 */
                if (updShortIdxFlg == TRUE &&
                    (*attribIt)->precompFlg == FALSE &&
                    (*attribIt)->custFlg == FALSE &&
                    (*attribIt)->logicalFlg == FALSE &&
                    (*attribIt)->calcEn != DictAttr_NoMD)
                {
                    (*attribIt)->shortIdx = (SMALLINT_T)(*attribIt)->progN;
                    (*attribIt)->isNullShortIdx = false;
                }

                /*  FPL-REF10305-040908 set the flag flagSetNullWhileCoping */
                DBA_SetNullWhileCopyFlag(*attribIt);

                /* PMSTA-13727 - LJE - 120224 - The time_stamp attributes must be invisible */
                if ((*attribIt)->dataTpProgN == TimeStampType)
                {
                    (*attribIt)->searchMask = 0;
                    (*attribIt)->subTypeMask = 0;
                    (*attribIt)->qSearchMask = 0;
                }

                (*attribIt)->linkAttrDictTab.clear();
            }

            /* Store new attributes number for the current entity */
            DBA_SetDictScreenRights(dictEntityStp);         /*  HFI-PMSTA-51777-2022-01-06  */
        }
    }
    return(RET_SUCCEED);
}


/************************************************************************
**
**  Function        : DBA_SetNullWhileCopyFlag
**
**  Description     : fill the flagSetNullWhileCopying
**
**  Arguments       : attribStp     : the attrib where the flag need to be set
**                    entityRef     : the entity of the attribute
**
**  Return          : RET_SUCCEED
**
**	Creation        : FPL-REF10305-040908
**  Last modif      : BSA-PMSTA-339-060922
**                  : Removed the source code condition from IF case for each operation
**
*************************************************************************/
STATIC RET_CODE    DBA_SetNullWhileCopyFlag (DICT_ATTRIB_STP  dictAttribStp)
{
    if (dictAttribStp->calcEn == DictAttr_LastModifManagment)
    {
        dictAttribStp->enSetNullWhileCopying = DictNullCopy_SetToNullAndDV;
    }
    else
    {
        OBJECT_ENUM     entityRef;
        dictAttribStp->enSetNullWhileCopying = DictNullCopy_NotSetToNull;  /*  FPL-REF10603-041229 */
        DBA_GetObjectEnum(dictAttribStp->entDictId, &entityRef);
        switch (GET_OBJECT_CST(entityRef))
        {
        /***    Operation entities      ***/

            case BuyOpEntCst :
                if ((dictAttribStp->progN == BuyOp_Id                   ) ||
                    (dictAttribStp->progN == BuyOp_ExtOpDbId            ) ||
                    (dictAttribStp->progN == BuyOp_Cd                   ) ||
                    (dictAttribStp->progN == BuyOp_LastUserId           ) ||
                    (dictAttribStp->progN == BuyOp_LastModifDate        ) ||
                    (dictAttribStp->progN == BuyOp_CreationTime         ) ||
                    (dictAttribStp->progN == BuyOp_EndDate              ) ||
                    (dictAttribStp->progN == BuyOp_BeginDate            ) ||
                    (dictAttribStp->progN == BuyOp_ExtOpId              ))      /*  FPL-REF10705-041021 */
                {
                    dictAttribStp->enSetNullWhileCopying = DictNullCopy_SetToNull ; /*  FPL-REF10603-041229 */
                }
                break;

            case SellOpEntCst :
                if ((dictAttribStp->progN == SellOp_Id                  ) ||
                    (dictAttribStp->progN == SellOp_ExtOpDbId           ) ||
                    (dictAttribStp->progN == SellOp_Cd                  ) ||
                    (dictAttribStp->progN == SellOp_LastUserId          ) ||
                    (dictAttribStp->progN == SellOp_LastModifDate       ) ||
                    (dictAttribStp->progN == SellOp_CreationTime        ) ||
                    (dictAttribStp->progN == SellOp_EndDate             ) ||
                    (dictAttribStp->progN == SellOp_BeginDate           ) ||
                    (dictAttribStp->progN == SellOp_ExtOpId             ))      /*  FPL-REF10705-041021 */
                {
                    dictAttribStp->enSetNullWhileCopying = DictNullCopy_SetToNull ; /*  FPL-REF10603-041229 */
                }
                break;

            case IncOpEntCst :
                if ((dictAttribStp->progN == IncOp_Id                   ) ||
                    (dictAttribStp->progN == IncOp_ExtOpDbId            ) ||
                    (dictAttribStp->progN == IncOp_Cd                   ) ||
                    (dictAttribStp->progN == IncOp_LastUserId           ) ||
                    (dictAttribStp->progN == IncOp_LastModifDate        ) ||
                    (dictAttribStp->progN == IncOp_CreationTime         ) ||
                    (dictAttribStp->progN == IncOp_EndDate              ) ||
                    (dictAttribStp->progN == IncOp_BeginDate            ) ||
                    (dictAttribStp->progN == IncOp_ExtOpId              ))      /*  FPL-REF10705-041021 */
                {
                    dictAttribStp->enSetNullWhileCopying = DictNullCopy_SetToNull ; /*  FPL-REF10603-041229 */
                }
                break;

            case InvestOpEntCst :
                if ((dictAttribStp->progN == InvestOp_Id                ) ||
                    (dictAttribStp->progN == InvestOp_ExtOpDbId         ) ||
                    (dictAttribStp->progN == InvestOp_Cd                ) ||
                    (dictAttribStp->progN == InvestOp_LastUserId        ) ||
                    (dictAttribStp->progN == InvestOp_LastModifDate     ) ||
                    (dictAttribStp->progN == InvestOp_CreationTime      ) ||
                    (dictAttribStp->progN == InvestOp_EndDate           ) ||
                    (dictAttribStp->progN == InvestOp_BeginDate         ) ||
                    (dictAttribStp->progN == InvestOp_ExtOpId           ))      /*  FPL-REF10705-041021 */
                {
                    dictAttribStp->enSetNullWhileCopying = DictNullCopy_SetToNull ;/*  FPL-REF10603-041229 */
                }
                break;

            case WithdrOpEntCst :
                if ((dictAttribStp->progN == WithdrOp_Id                ) ||
                    (dictAttribStp->progN == WithdrOp_ExtOpDbId         ) ||
                    (dictAttribStp->progN == WithdrOp_Cd                ) ||
                    (dictAttribStp->progN == WithdrOp_LastUserId        ) ||
                    (dictAttribStp->progN == WithdrOp_LastModifDate     ) ||
                    (dictAttribStp->progN == WithdrOp_CreationTime      ) ||
                    (dictAttribStp->progN == WithdrOp_EndDate           ) ||
                    (dictAttribStp->progN == WithdrOp_BeginDate         ) ||
                    (dictAttribStp->progN == WithdrOp_ExtOpId           ))      /*  FPL-REF10705-041021 */
                {
                    dictAttribStp->enSetNullWhileCopying = DictNullCopy_SetToNull ; /*  FPL-REF10603-041229 */
                }
                break;

            case FtOpEntCst :
                if ((dictAttribStp->progN == FtOp_Id                    ) ||
                    (dictAttribStp->progN == FtOp_ExtOpDbId             ) ||
                    (dictAttribStp->progN == FtOp_Cd                    ) ||
                    (dictAttribStp->progN == FtOp_LastUserId            ) ||
                    (dictAttribStp->progN == FtOp_LastModifDate         ) ||
                    (dictAttribStp->progN == FtOp_CreationTime          ) ||
                    (dictAttribStp->progN == FtOp_EndDate               ) ||
                    (dictAttribStp->progN == FtOp_BeginDate             ) ||
                    (dictAttribStp->progN == FtOp_ExtOpId               ))      /*  FPL-REF10705-041021 */
                {
                   dictAttribStp->enSetNullWhileCopying = DictNullCopy_SetToNull ;  /*  FPL-REF10603-041229 */
                }
                break;

            case AdjustOpEntCst :
                if ((dictAttribStp->progN == AdjustOp_Id                ) ||
                    (dictAttribStp->progN == AdjustOp_ExtOpDbId         ) ||
                    (dictAttribStp->progN == AdjustOp_Cd                ) ||
                    (dictAttribStp->progN == AdjustOp_LastUserId        ) ||
                    (dictAttribStp->progN == AdjustOp_LastModifDate     ) ||
                    (dictAttribStp->progN == AdjustOp_CreationTime      ) ||
                    (dictAttribStp->progN == AdjustOp_EndDate           ) ||
                    (dictAttribStp->progN == AdjustOp_BeginDate         ) ||
                    (dictAttribStp->progN == AdjustOp_ExtOpId           ))      /*  FPL-REF10705-041021 */
                {
                    dictAttribStp->enSetNullWhileCopying = DictNullCopy_SetToNull ; /*  FPL-REF10603-041229 */
                }
                break;

            case ShareIssOpEntCst :
                if ((dictAttribStp->progN == ShareIssOp_Id              ) ||
                    (dictAttribStp->progN == ShareIssOp_ExtOpDbId       ) ||
                    (dictAttribStp->progN == ShareIssOp_Cd              ) ||
                    (dictAttribStp->progN == ShareIssOp_LastUserId      ) ||
                    (dictAttribStp->progN == ShareIssOp_LastModifDate   ) ||
                    (dictAttribStp->progN == ShareIssOp_CreationTime    ) ||
                    (dictAttribStp->progN == ShareIssOp_EndDate         ) ||
                    (dictAttribStp->progN == ShareIssOp_BeginDate       ) ||
                    (dictAttribStp->progN == ShareIssOp_ExtOpId         ))      /*  FPL-REF10705-041021 */
                {
                    dictAttribStp->enSetNullWhileCopying = DictNullCopy_SetToNull ; /*  FPL-REF10603-041229 */
                }
                break;

            case ShareRedmOpEntCst :
                if ((dictAttribStp->progN == ShareRedmOp_Id             ) ||
                    (dictAttribStp->progN == ShareRedmOp_ExtOpDbId      ) ||
                    (dictAttribStp->progN == ShareRedmOp_Cd             ) ||
                    (dictAttribStp->progN == ShareRedmOp_LastUserId     ) ||
                    (dictAttribStp->progN == ShareRedmOp_LastModifDate  ) ||
                    (dictAttribStp->progN == ShareRedmOp_CreationTime   ) ||
                    (dictAttribStp->progN == ShareRedmOp_EndDate        ) ||
                    (dictAttribStp->progN == ShareRedmOp_BeginDate      ) ||
                    (dictAttribStp->progN == ShareRedmOp_ExtOpId        ))      /*  FPL-REF10705-041021 */
                {
                    dictAttribStp->enSetNullWhileCopying = DictNullCopy_SetToNull ; /*  FPL-REF10603-041229 */
                }
                break;

            case TransfOpEntCst :
                if ((dictAttribStp->progN == TransfOp_Id                ) ||
                    (dictAttribStp->progN == TransfOp_ExtOpDbId         ) ||
                    (dictAttribStp->progN == TransfOp_Cd                ) ||
                    (dictAttribStp->progN == TransfOp_LastUserId        ) ||
                    (dictAttribStp->progN == TransfOp_LastModifDate     ) ||
                    (dictAttribStp->progN == TransfOp_CreationTime      ) ||
                    (dictAttribStp->progN == TransfOp_EndDate           ) ||
                    (dictAttribStp->progN == TransfOp_BeginDate         ) ||
                    (dictAttribStp->progN == TransfOp_ExtOpId           ))      /*  FPL-REF10705-041021 */
                {
                    dictAttribStp->enSetNullWhileCopying = DictNullCopy_SetToNull ; /*  FPL-REF10603-041229 */
                }
                break;

            case BpTransfOpEntCst :
                if ((dictAttribStp->progN == BpTransfOp_Id              ) ||
                    (dictAttribStp->progN == BpTransfOp_ExtOpDbId       ) ||
                    (dictAttribStp->progN == BpTransfOp_Cd              ) ||
                    (dictAttribStp->progN == BpTransfOp_LastUserId      ) ||
                    (dictAttribStp->progN == BpTransfOp_LastModifDate   ) ||
                    (dictAttribStp->progN == BpTransfOp_CreationTime    ) ||
                    (dictAttribStp->progN == BpTransfOp_EndDate         ) ||
                    (dictAttribStp->progN == BpTransfOp_BeginDate       ) ||
                    (dictAttribStp->progN == BpTransfOp_ExtOpId         ))      /*  FPL-REF10705-041021 */
                {
                    dictAttribStp->enSetNullWhileCopying = DictNullCopy_SetToNull ; /*  FPL-REF10603-041229 */
                }
                break;

            case LockOpEntCst :
                if ((dictAttribStp->progN == LockOp_Id                  ) ||
                    (dictAttribStp->progN == LockOp_ExtOpDbId           ) ||
                    (dictAttribStp->progN == LockOp_Cd                  ) ||
                    (dictAttribStp->progN == LockOp_LastUserId          ) ||
                    (dictAttribStp->progN == LockOp_LastModifDate       ) ||
                    (dictAttribStp->progN == LockOp_CreationTime        ) ||
                    (dictAttribStp->progN == LockOp_EndDate             ) ||
                    (dictAttribStp->progN == LockOp_BeginDate           ) ||
                    (dictAttribStp->progN == LockOp_ExtOpId             ))      /*  FPL-REF10705-041021 */
                {
                    dictAttribStp->enSetNullWhileCopying = DictNullCopy_SetToNull ; /*  FPL-REF10603-041229 */
                }
                break;

            case PtfTransfOpEntCst :
                if ((dictAttribStp->progN == PtfTransfOp_Id             ) ||
                    (dictAttribStp->progN == PtfTransfOp_ExtOpDbId      ) ||
                    (dictAttribStp->progN == PtfTransfOp_Cd             ) ||
                    (dictAttribStp->progN == PtfTransfOp_LastUserId     ) ||
                    (dictAttribStp->progN == PtfTransfOp_LastModifDate  ) ||
                    (dictAttribStp->progN == PtfTransfOp_CreationTime   ) ||
                    (dictAttribStp->progN == PtfTransfOp_EndDate        ) ||
                    (dictAttribStp->progN == PtfTransfOp_BeginDate      ) ||
                    (dictAttribStp->progN == PtfTransfOp_ExtOpId        ))      /*  FPL-REF10705-041021 */
                {
                    dictAttribStp->enSetNullWhileCopying = DictNullCopy_SetToNull ; /*  FPL-REF10603-041229 */
                }
                break;

            case BookAdjOpEntCst :
                if ((dictAttribStp->progN == BookAdjOp_Id               ) ||
                    (dictAttribStp->progN == BookAdjOp_ExtOpDbId        ) ||
                    (dictAttribStp->progN == BookAdjOp_Cd               ) ||
                    (dictAttribStp->progN == BookAdjOp_LastUserId       ) ||
                    (dictAttribStp->progN == BookAdjOp_LastModifDate    ) ||
                    (dictAttribStp->progN == BookAdjOp_CreationTime     ) ||
                    (dictAttribStp->progN == BookAdjOp_EndDate          ) ||
                    (dictAttribStp->progN == BookAdjOp_BeginDate        ) ||
                    (dictAttribStp->progN == BookAdjOp_ExtOpId          ))      /*  FPL-REF10705-041021 */
                {
                    dictAttribStp->enSetNullWhileCopying = DictNullCopy_SetToNull ; /*  FPL-REF10603-041229 */
                }
                break;

            case InitOpEntCst :
                if ((dictAttribStp->progN == InitOp_Id                  ) ||
                    (dictAttribStp->progN == InitOp_ExtOpDbId           ) ||
                    (dictAttribStp->progN == InitOp_Cd                  ) ||
                    (dictAttribStp->progN == InitOp_LastUserId          ) ||
                    (dictAttribStp->progN == InitOp_LastModifDate       ) ||
                    (dictAttribStp->progN == InitOp_CreationTime        ) ||
                    (dictAttribStp->progN == InitOp_EndDate             ) ||
                    (dictAttribStp->progN == InitOp_BeginDate           ) ||
                    (dictAttribStp->progN == InitOp_ExtOpId             ))      /*  FPL-REF10705-041021 */
                {
                    dictAttribStp->enSetNullWhileCopying = DictNullCopy_SetToNull ; /*  FPL-REF10603-041229 */
                }
                break;

        /***    Other entities          ***/

            case PerfStorageParamCst :
                if ((dictAttribStp->progN == A_PerfStorageParam_StdPerfFirstStoredDate  ) ||
                    (dictAttribStp->progN == A_PerfStorageParam_StdPerfLastStoredDate   ) ||
                    (dictAttribStp->progN == A_PerfStorageParam_RetFirstStoredDate      ) ||
                    (dictAttribStp->progN == A_PerfStorageParam_RetLastStoredDate       ) ||
                    (dictAttribStp->progN == A_PerfStorageParam_PerfFirstStoredDate     ) ||
                    (dictAttribStp->progN == A_PerfStorageParam_PerfLastStoredDate      ) ||
                    (dictAttribStp->progN == A_PerfStorageParam_PerfCalcFirstStoredDate) ||
                    (dictAttribStp->progN == A_PerfStorageParam_PerfCalcLastStoredDate))/*WEALTH-2092-SENTHIL-230928*/
                {
                    dictAttribStp->enSetNullWhileCopying = DictNullCopy_SetToNull ; /*  FPL-REF10603-041229 */
                }
                break ;

            case PtfCst :
                if ((dictAttribStp->progN == A_Ptf_SynthLastFinalDate   ) ||
                    (dictAttribStp->progN == A_Ptf_SynthRecalcDate      ) ||
                    (dictAttribStp->progN == A_Ptf_PerfLastFinalDate    ) ||
                    (dictAttribStp->progN == A_Ptf_ArchiveDate          ) ||    /*  FPL-REF10305-041022 */
                    (dictAttribStp->progN == A_Ptf_PerfFirstOpDate      ))      /* PMSTA-48227 - JBC - 220418 */
                {
                    dictAttribStp->enSetNullWhileCopying = DictNullCopy_SetToNull ; /*  FPL-REF10603-041229 */
                }
                break ;

            case InstrCst :
                if ((dictAttribStp->progN == A_Instr_LastUserId         ) ||
                    (dictAttribStp->progN == A_Instr_LastModifDate      ))
                {
                    dictAttribStp->enSetNullWhileCopying = DictNullCopy_SetToNull ; /*  FPL-REF10603-041229 */
                }
                break ;

            /*  FPL-REF10603-050104 */
            case CorpActionDetailCst :
			    if (dictAttribStp->progN == A_CorpActionDetail_SeqNumber)
                {
                    dictAttribStp->enSetNullWhileCopying = DictNullCopy_SetToNullAndDV ;
                }
                break ;

            /*  HFI-PMSTA-16954-130917  */
            case MgrCst :
                if (dictAttribStp->progN == A_Mgr_UserId)
                {
                    dictAttribStp->enSetNullWhileCopying = DictNullCopy_SetToNullAndDV ;
                }
                break ;

            /*  HFI-PMSTA-16954-130917  */
            case ApplUserCst :
                if (dictAttribStp->progN == A_ApplUser_ManagerId)
                {
                    dictAttribStp->enSetNullWhileCopying = DictNullCopy_SetToNullAndDV ;
                }
                break ;

            /*  HFI-PMSTA-41842-200916  */
            case XdAttribCst :
                if ((dictAttribStp->progN == A_XdAttrib_Id) ||
                    (dictAttribStp->progN == A_XdAttrib_BuildDate) ||
                    (dictAttribStp->progN == A_XdAttrib_XdActionEn) ||
                    (dictAttribStp->progN == A_XdAttrib_XdStatusEn) ||
                    (dictAttribStp->progN == A_XdAttrib_CustomFlg) ||
                    (dictAttribStp->progN == A_XdAttrib_PermAuthEn))
                {
                    dictAttribStp->enSetNullWhileCopying = DictNullCopy_SetToNullAndDV ;
                }
                else if ((dictAttribStp->progN == A_XdAttrib_AttribDictId) ||
                         (dictAttribStp->progN == A_XdAttrib_OldProg) ||
                         (dictAttribStp->progN == A_XdAttrib_DbProg) ||
                         (dictAttribStp->progN == A_XdAttrib_OldShortIdx) ||         /* PMSTA-45413 - LJE - 220114 */
                         (dictAttribStp->progN == A_XdAttrib_OldDispRank) ||         /* PMSTA-45413 - LJE - 220114 */
                         (dictAttribStp->progN == A_XdAttrib_ProgPk) ||
                         (dictAttribStp->progN == A_XdAttrib_DispRank) ||
                         (dictAttribStp->progN == A_XdAttrib_ProgBk) ||
                         (dictAttribStp->progN == A_XdAttrib_ShortDispRank) ||
                         (dictAttribStp->progN == A_XdAttrib_ShortIdx) ||
                         (dictAttribStp->progN == A_XdAttrib_PrimaryFlg) ||
                         (dictAttribStp->progN == A_XdAttrib_BusKeyFlg))
                {
                    dictAttribStp->enSetNullWhileCopying = DictNullCopy_One_SetToNullAndDV ;
                }
                else if (dictAttribStp->progN == A_XdAttrib_ParentXdAttribId)
                {
                    dictAttribStp->enSetNullWhileCopying = DictNullCopy_One_HardCoded;
                }
                break ;
            case XdEntityCst :
                if ((dictAttribStp->progN == A_XdEntity_Id) ||
                    (dictAttribStp->progN == A_XdEntity_ParentXdAttribId) ||
                    (dictAttribStp->progN == A_XdEntity_DictEntityValue) ||
                    (dictAttribStp->progN == A_XdEntity_BuildDate) ||
                    (dictAttribStp->progN == A_XdEntity_LastUserId) ||
                    (dictAttribStp->progN == A_XdEntity_LastModifDate) ||
                    (dictAttribStp->progN == A_XdEntity_CustSqlName) ||
                    (dictAttribStp->progN == A_XdEntity_DbSqlName) ||
                    (dictAttribStp->progN == A_XdEntity_CustAuthFlg) ||
                    (dictAttribStp->progN == A_XdEntity_XdActionEn) ||
                    (dictAttribStp->progN == A_XdEntity_XdStatusEn) ||
                    (dictAttribStp->progN == A_XdEntity_TypingNat))
                {
                    dictAttribStp->enSetNullWhileCopying = DictNullCopy_SetToNullAndDV ;
                }
                else if ((dictAttribStp->progN == A_XdEntity_NatEn) ||
                         (dictAttribStp->progN == A_XdEntity_AutomaticMask))
                {
                    dictAttribStp->enSetNullWhileCopying = DictNullCopy_HardCoded;
                }
                break ;
            case XdPermValCst :
                if ((dictAttribStp->progN == A_XdPermVal_XdActionEn) ||
                    (dictAttribStp->progN == A_XdPermVal_XdStatusEn) ||
                    (dictAttribStp->progN == A_XdPermVal_PermValRuleEn))
                {
                    dictAttribStp->enSetNullWhileCopying = DictNullCopy_SetToNullAndDV ;
                }
                break ;
            case XdEntityFeatureCst :
                if ((dictAttribStp->progN == A_XdEntityFeature_XdActionEn) ||
                    (dictAttribStp->progN == A_XdEntityFeature_XdStatusEn))
                {
                    dictAttribStp->enSetNullWhileCopying = DictNullCopy_SetToNullAndDV ;
                }
                break ;
            case XdLabelCst :
                if ((dictAttribStp->progN == A_XdLabel_XdActionEn) ||
                    (dictAttribStp->progN == A_XdLabel_XdStatusEn) ||
                    (dictAttribStp->progN == A_XdLabel_NatEn))
                {
                    dictAttribStp->enSetNullWhileCopying = DictNullCopy_SetToNullAndDV ;
                }
                break ;
        }
    }
    return RET_SUCCEED;
}

/************************************************************************
**
**  Function    : DICT_LinkFieldsToEntity
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**                 REF9789 - LJE - 040105
**                 PMSTA-30823 - 050418 - PMO : SCPT_FmtEltAnalyse: Source and destination overlap in mempcpy
**
*************************************************************************/
RET_CODE DICT_LinkFieldsToEntity(DICT_ENTITY_STP   dstDictEntityStp,
                                 DICT_ENTITY_STP   srcDictEntityStp,
                                 FIELD_IDX_T       srcEntityDictIdIdx,
                                 FIELD_IDX_T       srcObjectIdIdx,
                                 FLAG_T            createShortFlg,
                                 FLAG_T            createNewFieldFlg,
                                 FLAG_T            allFieldMandatoryFlg)
{
    RET_CODE ret = RET_SUCCEED;

    DICT_ATTRIB_STP existsAttribStp;
    FIELD_IDX_T     newAttrib;

    if (srcDictEntityStp == NULL ||
        dstDictEntityStp == NULL)
    {
        MSG_RETURN(RET_GEN_ERR_INVARG);
    }

    for (auto attribIt = srcDictEntityStp->attr.begin(); attribIt != srcDictEntityStp->attr.end(); ++attribIt)
    {
        DICT_ATTRIB_STP srcAttribStp = (*attribIt);

        if (srcAttribStp->logicalFlg == FALSE &&
            /* Custom fields only if the destination entity can have this type of fields */
            (srcAttribStp->custFlg == FALSE ||
            dstDictEntityStp->custAuthFlg == TRUE))
        {
            existsAttribStp = NULL;

            if (srcAttribStp->primFlg == TRUE && srcObjectIdIdx >= 0)
            {
                existsAttribStp = srcDictEntityStp->attr[srcObjectIdIdx];
            }
            else if ((existsAttribStp = DICT_GetExistingFieldInEntity(dstDictEntityStp->objectEn, srcAttribStp)) == NULL &&
                createNewFieldFlg == TRUE)
            {
                newAttrib = (FIELD_IDX_T)dstDictEntityStp->attr.size();
                DICT_T attribDictId = (dstDictEntityStp->entDictId * 1000) + newAttrib + 1;

                DICT_ATTRIB_ST &dstAttribSt = dstDictEntityStp->addDictAttrib(attribDictId, newAttrib, srcAttribStp->sqlName);
                dstDictEntityStp->attr.push_back(&dstAttribSt);
                dstDictEntityStp->sortedAttr.insert(make_pair(dstAttribSt.sqlName, &dstAttribSt));

                dstAttribSt = *srcAttribStp;

                dstAttribSt.progN = newAttrib;
                dstAttribSt.entDictId = dstDictEntityStp->entDictId;
                dstAttribSt.dispRank = (short)(newAttrib + 1);
                dstAttribSt.calcEn = DictAttr_Virtual;

                DBA_AddFieldToVirtualObject(dstDictEntityStp->objectEn,
                                            (INT_T*)&(dstAttribSt.progN),
                                            dstAttribSt.dataTpProgN,
                                            TRUE,
                                            FALSE,
                                            NULL);

                if (createShortFlg == TRUE &&
                    dstAttribSt.isNullShortIdx == false)
                {
                    DBA_AddFieldToVirtualObject(dstDictEntityStp->objectEn,
                                                &(dstAttribSt.shortIdx),
                                                dstAttribSt.dataTpProgN,
                                                FALSE,
                                                FALSE,
                                                NULL);
                }

                existsAttribStp = dstDictEntityStp->attr[newAttrib];
            }

            if (existsAttribStp != NULL)
            {
                existsAttribStp->orgAttrNbr++;
                if ((existsAttribStp->orgAttrTab = (DICT_ATTRIB_STP*)existsAttribStp->m_mp.realloc(existsAttribStp->orgAttrTab, existsAttribStp->orgAttrNbr * sizeof(DICT_ATTRIB_STP))) == NULL)
                {
                    MSG_RETURN(RET_MEM_ERR_ALLOC);
                }

                existsAttribStp->orgAttrTab[existsAttribStp->orgAttrNbr - 1] = srcAttribStp;

                srcAttribStp->useAttrNbr++;
                if ((srcAttribStp->useAttrTab = (DICT_ATTRIB_STP*)srcAttribStp->m_mp.realloc(srcAttribStp->useAttrTab, srcAttribStp->useAttrNbr * sizeof(DICT_ATTRIB_STP))) == NULL)
                {
                    MSG_RETURN(RET_MEM_ERR_ALLOC);
                }

                srcAttribStp->useAttrTab[srcAttribStp->useAttrNbr - 1] = existsAttribStp;
            }
            /* REF9764 - LJE - 040209 */
            else if (allFieldMandatoryFlg == TRUE &&
                     srcAttribStp->attrDictId > -1 &&
                     /* code port of PMSTA-23340 - DDV - 160607 */
                     EV_AAAInstallLevel == 0)
            {
                char *buffer = (char*)CALLOC(512, sizeof(char));

                /* PMSTA-30823 - 050418 - PMO */
                sprintf(buffer,
                        "DICT_LinkFieldsToEntity (%s->%s) Error :  attribute %s does not exist in destination entity",
                        OBJ_V2N(srcDictEntityStp->objectEn),
                        OBJ_V2N(dstDictEntityStp->objectEn),
                        srcAttribStp->sqlName);

                MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, buffer);

                FREE(buffer);

            }

        }
    }

    dstDictEntityStp->orgEntityNbr++;
    if ((dstDictEntityStp->orgEntityTab = (DICT_ENTREF_STP)dstDictEntityStp->m_mp.realloc(dstDictEntityStp->orgEntityTab, dstDictEntityStp->orgEntityNbr * sizeof(DICT_ENTREF_ST))) == NULL)
    {
        MSG_RETURN(RET_MEM_ERR_ALLOC);
    }

    dstDictEntityStp->orgEntityTab[dstDictEntityStp->orgEntityNbr - 1].entDictId = srcDictEntityStp->entDictId;
    dstDictEntityStp->orgEntityTab[dstDictEntityStp->orgEntityNbr - 1].objectEn = srcDictEntityStp->objectEn;


    srcDictEntityStp->useEntityNbr++;
    if ((srcDictEntityStp->useEntityTab = (DICT_ENTREF_STP)srcDictEntityStp->m_mp.realloc(srcDictEntityStp->useEntityTab,
        srcDictEntityStp->useEntityNbr * sizeof(DICT_ENTREF_ST))) == NULL)
    {
        MSG_RETURN(RET_MEM_ERR_ALLOC);
    }

    srcDictEntityStp->useEntityTab[srcDictEntityStp->useEntityNbr - 1].entDictId = dstDictEntityStp->entDictId;
    srcDictEntityStp->useEntityTab[srcDictEntityStp->useEntityNbr - 1].objectEn = dstDictEntityStp->objectEn;

    if (dstDictEntityStp->srcEntDictIdIdx <= 0)
    {
        dstDictEntityStp->srcEntDictIdIdx = srcEntityDictIdIdx;
    }

    dstDictEntityStp->virtualAttrFlg = TRUE;

    return ret;

}

/************************************************************************
**
**  Function    : DICT_LinkFieldsToEntity
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**                 REF9789 - LJE - 040105
**
*************************************************************************/
STATIC RET_CODE DICT_LinkFieldsToEntity(OBJECT_ENUM   dstObjectEn,
                                        OBJECT_ENUM   srcObjectEn,
                                        FIELD_IDX_T   srcEntityDictIdIdx,
                                        FIELD_IDX_T   srcObjectIdIdx,
                                        FLAG_T        createShortFlg,
                                        FLAG_T        createNewFieldFlg,
                                        FLAG_T        allFieldMandatoryFlg)
{
    RET_CODE ret = RET_SUCCEED;

    DICT_ENTITY_STP
        srcDictEntityStp = DBA_GetDictEntitySt(srcObjectEn),
        dstDictEntityStp = DBA_GetDictEntitySt(dstObjectEn);

    if (srcObjectEn < 0					||
        srcObjectEn >= LASTENTITYOBJECT ||
        dstObjectEn < 0					||
        dstObjectEn >= LASTENTITYOBJECT)
    {
        if (SYS_IsDdlGenMode())
        {
            return RET_GEN_ERR_INVARG;
        }

        MSG_RETURN(RET_GEN_ERR_INVARG);
    }

    ret = DICT_LinkFieldsToEntity(dstDictEntityStp,
                                  srcDictEntityStp,
                                  srcEntityDictIdIdx,
                                  srcObjectIdIdx,
                                  createShortFlg,
                                  createNewFieldFlg,
                                  allFieldMandatoryFlg);
    return (ret);
}

/************************************************************************
**
**  Function    : DICT_GetExistingFieldInEntity
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**                 REF9789 - LJE - 040113
**                 PMSTA-28349 - 221017 - PMO : 9.1 - Fusion Process
**
*************************************************************************/
STATIC DICT_ATTRIB_STP DICT_GetExistingFieldInEntity(OBJECT_ENUM dstObjectEn, DICT_ATTRIB_STP addAttribStp)
{
    DICT_ATTRIB_STP existsAttribStp=NULL;
    OBJECT_ENUM     srcObjectEn;
    const char           *sqlName=NULL; /* BSA-REF11860-060808 */
    int             i;

    /* Manage exceptions cases */
    if (DBA_GetObjectEnum(addAttribStp->entDictId, &srcObjectEn) &&
        strcmp(addAttribStp->sqlName, "_HierIdxFld") != 0)
    {
        sqlName = addAttribStp->sqlName;

        switch (GET_OBJECT_CST(dstObjectEn))
        {
        case ExtTransactionCst:

            switch (GET_OBJECT_CST(srcObjectEn))
            {
            case EOpCst:
                if (strcmp(addAttribStp->sqlName, "execut_set_criteria") == 0)
                {
                    sqlName = "execution_set_criteria";
                }
                else if (strcmp(addAttribStp->sqlName, "nature_e") == 0)
                {
                    sqlName = "operation_nature_e";
                }
                break;

            case UnMatchedExecutionCst:
                if (strcmp(addAttribStp->sqlName, "nature_e") == 0)
                {
                    sqlName = "exec_nature_e";
                }
                break;

            case UnMatchedGlExecFeeCst:         /* FPL-REF10232-040504 */
                if (strcmp(addAttribStp->sqlName, "nature_e") == 0)
                {
                    sqlName = "exec_nature_e";
                }
                break;


            case ExecutionEntCst:
                if (strcmp(addAttribStp->sqlName, "nature_e") == 0)
                {
                    sqlName = "exec_nature_e";
                }
                break;

            case GlExecFeeEntCst:
                if (strcmp(addAttribStp->sqlName, "nature_e") == 0)
                {
                    sqlName = "exec_nature_e";
                }
                break;

            default :
                /* Nothing to do */
                break;
            }
            break;      /* FPL-REF9956-040224 add break */

        case DomainCst:                         /*  FIH-REF11457-051007 */

            switch (GET_OBJECT_CST(srcObjectEn))
            {
            case SearchLnkEntCst:
                if (strcmp(addAttribStp->sqlName, "begin_d") == 0)
                {
                    sqlName = "calc_from_d";
                }
                else if (strcmp(addAttribStp->sqlName, "end_d") == 0)
                {
                    sqlName = "calc_till_d";
                }
                break;

            default :
                /* Nothing to do : it is cool   */
                break;
            }
            break;

        /* REF11435 - TEB - 051012 */
        case SearchLnkEntCst:

            switch (GET_OBJECT_CST(srcObjectEn))
            {
            case DomainCst:
                if (strcmp(addAttribStp->sqlName, "calc_strat_d") == 0)
                {
                    sqlName = "begin_d";
                }
                else if (strcmp(addAttribStp->sqlName, "strat_link_nat_e") == 0)
                {
                    sqlName = "link_nat_e";
                }
                else if (strcmp(addAttribStp->sqlName, "check_trading_f") == 0)
                {
                    sqlName = "_check_trading_f";
                }

                break;

            default :
                /* Nothing to do : it is cool   */
                break;
            }
            break;

        case ModelConstrEltCst:                 /*  FIH-REF11350-PMSTA00236-060203 */

            switch (GET_OBJECT_CST(srcObjectEn))
            {
            case EStratEltCst:
                if ((strcmp(addAttribStp->sqlName, "id") == 0) ||
                    (strcmp(addAttribStp->sqlName, "min_weight_n") == 0) ||
                    (strcmp(addAttribStp->sqlName, "max_weight_n") == 0) ||
                    (strcmp(addAttribStp->sqlName, "nature_e") == 0)
                   )
                    sqlName = NULL;
                else if (strcmp(addAttribStp->sqlName, "min_weight_cont_n") == 0)
                {
                    sqlName = "min_weight_n";
                }
                else if (strcmp(addAttribStp->sqlName, "max_weight_cont_n") == 0)
                {
                    sqlName = "max_weight_n";
                }
                else if (strcmp(addAttribStp->sqlName, "ref_curr_id") == 0)
                {
                    sqlName = "constr_bound_curr_id";
                }
                else if (strcmp(addAttribStp->sqlName, "model_constr_elt_id") == 0)
                {
                    sqlName = "id";
                }
                break;

            default :
                /* Nothing to do : it is cool   */
                break;
            }
            break;

        case EStratEltCst:                 /*  FIH-REF11350-PMSTA00236-060203 */

            switch (GET_OBJECT_CST(srcObjectEn))
            {
            case ModelConstrEltCst:
                if (strcmp(addAttribStp->sqlName, "nature_e") == 0)
                {
                    sqlName = NULL;
                }
                else if (strcmp(addAttribStp->sqlName, "min_weight_n") == 0)
                {
                    sqlName = "min_weight_cont_n";
                }
                else if (strcmp(addAttribStp->sqlName, "max_weight_n") == 0)
                {
                    sqlName = "max_weight_cont_n";
                }
                else if (strcmp(addAttribStp->sqlName, "constr_bound_curr_id") == 0)
                {
                    sqlName = "ref_curr_id";
                }
                else if (strcmp(addAttribStp->sqlName, "id") == 0)
                {
                    sqlName = "model_constr_elt_id";
                }
                break;

            default :
                /* Nothing to do : it is cool   */
                break;
            }
            break;

        case StandardPerfCst:
            switch (GET_OBJECT_CST(srcObjectEn))
            {
                case ExtRetAnalysisCst:
                    /* PMSTA07393 - LJE - 081209 - Don't link internal links */
                    if (strcmp(addAttribStp->sqlName, "previous_id") == 0)
                    {
                        sqlName = "";
                    }
                    else if (strcmp(addAttribStp->sqlName, "next_id") == 0)
                    {
                        sqlName = "";
                    }
                    else if (strcmp(addAttribStp->sqlName, "over_period_id") == 0)
                    {
                        sqlName = "";
                    }
                    else if (strcmp(addAttribStp->sqlName, "parent_object_id") == 0)
                    {
                        sqlName = "";
                    }
                    break;
                case PerfStorageParamCst:
                    if (strcmp(addAttribStp->sqlName, "id") == 0)
                    {
                        sqlName = "perf_storage_param_id";
                    }
                    break;
            }
            break;

        case PerfAttribCst:
            switch (GET_OBJECT_CST(srcObjectEn))
            {
                case PerfStorageParamCst:
                    if (strcmp(addAttribStp->sqlName, "id") == 0)
                    {
                        sqlName = "perf_storage_param_id";
                    }
                    break;
            }

        case ExtRetAnalysisCst:
            switch (GET_OBJECT_CST(srcObjectEn))
            {
                case StandardPerfCst:
                    /* PMSTA07393 - LJE - 081209 - Don't link internal links */
                    if (strcmp(addAttribStp->sqlName, "previous_id") == 0)
                    {
                        sqlName = "";
                    }
                    else if (strcmp(addAttribStp->sqlName, "next_id") == 0)
                    {
                        sqlName = "";
                    }
                    else if (strcmp(addAttribStp->sqlName, "over_period_id") == 0)
                    {
                        sqlName = "";
                    }
                    else if (strcmp(addAttribStp->sqlName, "parent_object_id") == 0)
                    {
                        sqlName = "";
                    }
                    break;
                case PerfStorageParamCst:
                    if (strcmp(addAttribStp->sqlName, "id") == 0)
                    {
                        sqlName = "perf_storage_param_id";
                    }
                    break;
            }
            break;

        /* PMSTA-13109 - LJE - 111116 */
        case DictEntityCst:
            switch (GET_OBJECT_CST(srcObjectEn))
            {
            case XdEntityCst:
                if (strcmp(addAttribStp->sqlName, "entity_dict_id") == 0)
                {
                    sqlName = "dict_id";
                }
                break;
            }
            break;

        /* PMSTA-13109 - LJE - 111116 */
        case DictAttrCst:
            switch (GET_OBJECT_CST(srcObjectEn))
            {
            case XdAttribCst:
                if (strcmp(addAttribStp->sqlName, "perm_auth_e") == 0)
                {
                    sqlName = "perm_auth_f";
                }
                if (strcmp(addAttribStp->sqlName, "attrib_dict_id") == 0)
                {
                    sqlName = "dict_id";
                }
                /* PMSTA-14452 - LJE - 121107 */
                if (strcmp(addAttribStp->sqlName, "custom_f") == 0)
                {
                    sqlName = "";
                }
                break;
            }
            break;

        /* PMSTA-28349 - 221017 - PMO */
        case EPosCst:
            switch (GET_OBJECT_CST(srcObjectEn))
            {
                case BalancePosDetailCst:
                case PositionDetailCst:
                    if (strcmp(addAttribStp->sqlName, "pf_currency_id") == 0)
                    {
                        sqlName = "ref_currency_id";
                    }
                    else if (strcmp(addAttribStp->sqlName, "revers_oper_nat_e") == 0)
                    {
                        sqlName = "rev_oper_nat_e";
                    }
                    else if (strcmp(addAttribStp->sqlName, "revers_oper_code") == 0)
                    {
                        sqlName = "rev_oper_code";
                    }
                    else if (strcmp(addAttribStp->sqlName, "pf_gross_amount_m") == 0)
                    {
                        sqlName = "ref_gross_amount_m";
                    }
                    else if (strcmp(addAttribStp->sqlName, "pf_net_amount_m") == 0)
                    {
                        sqlName = "ref_net_amount_m";
                    }
                    break;

                default :
                    /* Nothing to do : it is cool   */
                    break;
            }
            break;

        default :
            /* Nothing to do */
            break;
        }

        if (sqlName != NULL && sqlName[0] != 0)
        {
            existsAttribStp = DBA_GetAttributeBySqlName(dstObjectEn, sqlName);
        }
    }


    /* Test validity of attribute */
    if (existsAttribStp != NULL)
    {
        FLAG_T        dispMsgFlg = FALSE;
        std::string   msgStr;

        msgStr = "DICT_LinkFieldsToEntity (";
        msgStr += OBJ_V2N(srcObjectEn);
        msgStr += "->";
        msgStr += OBJ_V2N(dstObjectEn);
        msgStr += ") Error : ";

		if (existsAttribStp->dataTpProgN != addAttribStp->dataTpProgN &&
			existsAttribStp->dataTpProgN != DatetimeType && existsAttribStp->dataTpProgN != DateType &&
			addAttribStp->dataTpProgN    != DatetimeType && addAttribStp->dataTpProgN    != DateType)
        {
            msgStr += "bad datatype";
            dispMsgFlg = TRUE;
        }
        else if ((existsAttribStp->refEntDictId != addAttribStp->refEntDictId) &&
                 ((existsAttribStp->dataTpProgN != IdType) ||               /*  FIH-REF11350-PMSTA00236-060203 */  /*  Special case with the attribute id : refEntDictId = 0 and  dataTpProgN = IdType */
                  ((existsAttribStp->refEntDictId != 0) &&                  /*  FIH-REF11350-PMSTA00236-060203 */
                   (addAttribStp->refEntDictId != 0))) &&                     /*  FIH-REF11350-PMSTA00236-060203 */
                 ((existsAttribStp->dataTpProgN != DictType) ||
                 (existsAttribStp->entDictId != addAttribStp->refEntDictId)) &&
                 (srcObjectEn != PerfCalcResult || addAttribStp->entDictId != addAttribStp->refEntDictId) &&  /* PMSTA-49930 - LJE - 230531 */
                 (srcObjectEn != BiValueTemplate || strcmp(addAttribStp->sqlName, "obj_id") !=0) &&                           /* PMSTA-50418 - DDV - 210825 - Exception for bi_value_template.obj_id */
            ((srcObjectEn != XdEntityDoc && srcObjectEn != XdAttributeDoc && srcObjectEn != XdPermValDoc) || strcmp(addAttribStp->sqlName, "obj_id") != 0))
        {
            msgStr += "Mismatch ref entity";
            dispMsgFlg = TRUE;
        }
        else if (existsAttribStp->dataTpProgN == EnumType ||
                 (existsAttribStp->dataTpProgN == IdType && existsAttribStp->refEntDictId == TpCst))
        {
            DICT_T        srcParAttrDictId=0, destParAttrDictId=0;

            if (addAttribStp->parAttrDictId != 0)
                srcParAttrDictId = addAttribStp->parAttrDictId;
            else
                srcParAttrDictId = addAttribStp->attrDictId;

            if (existsAttribStp->parAttrDictId != 0)
                destParAttrDictId = existsAttribStp->parAttrDictId;
            else
                destParAttrDictId = existsAttribStp->attrDictId;

            if (srcParAttrDictId != destParAttrDictId)
            {
                if (existsAttribStp->dataTpProgN == EnumType)
                {

                    /* Don't display message for link_nat_e attribute, it has been identify, but not yet fixed (PMSTA-30729 created to fix it) */
                    if (strcmp(addAttribStp->sqlName, "link_nat_e") != 0 &&
                        strcmp(addAttribStp->sqlName, "strat_link_nat_e") != 0 && addAttribStp->custFlg != TRUE)   /* PMSTA-39238 - AIS - 210217 */
                    {
                        msgStr += "different enumeration";
                        dispMsgFlg = TRUE;
                    }
                }
                else if (existsAttribStp->dataTpProgN == IdType && existsAttribStp->refEntDictId == TpCst)
                {
                    DICT_T          srcTpEntDictId = NullEntity, destTpEntDictId = NullEntity;
                    DICT_ATTRIB_STP parentAttribStp = NULL;

                    /* Don't display message for lock_type_id attribute, it has been identify, but not yet fixed.
                       For copied entity parent attribute is not copied for FK on type */
                    if (strcmp(addAttribStp->sqlName, "lock_type_id") != 0)
                    {
                        msgStr += "different reference on table type";
                        dispMsgFlg = TRUE;
                    }

                        if (addAttribStp->parAttrDictId != 0 &&
                            ((parentAttribStp = DBA_GetAttributeById(addAttribStp->parAttrDictId)) != NULL ))
                            srcTpEntDictId = parentAttribStp->entDictId;
                        else
                            srcTpEntDictId = addAttribStp->entDictId;

                        if (existsAttribStp->parAttrDictId != 0 &&
                            ((parentAttribStp = DBA_GetAttributeById(existsAttribStp->parAttrDictId)) != NULL ))
                            destTpEntDictId = parentAttribStp->entDictId;
                        else
                            destTpEntDictId = existsAttribStp->entDictId;

                    /* PMSTA-32037 - DDV - 180925 - remove message to avoid log pollution ("DICT_LinkFieldsToEntity" referenced 32000 times) */
                    if (srcTpEntDictId == EOpCst)
                    {
                        dispMsgFlg = FALSE;
                    }

                    if (strcmp(addAttribStp->sqlName, "type_id") == 0 ||
                        strcmp(addAttribStp->sqlName, "subtype_id") == 0 || addAttribStp->custFlg == TRUE) /* PMSTA-36751 - Aiswarya -190731 */

                    {
                        /* copy beetween operation type/subtype and execution type/subtype into ExtOp is not clean.
                           It is known don't display the error message. It can be fix by adding exec_type_id and exec_subtype_id in ExtOp (PMSTA-30730 created to fix it) */
                        if ((srcTpEntDictId == OpCst && destTpEntDictId == ExecutionEntCst) ||
                            (srcTpEntDictId == ExecutionEntCst && destTpEntDictId == OpCst))
                        {
                            dispMsgFlg = FALSE;
                        }
                    }
                }
            }
        }

        if (dispMsgFlg == TRUE && EV_AAAInstallLevel != 99) /* PMSTA-37374 - LJE - 210409 */
        {
            std::string            fullMsgStr;

            fullMsgStr = msgStr + " for attribute " + existsAttribStp->sqlName + " ";

            if (existsAttribStp->orgAttrNbr > 0)
            {
                fullMsgStr += "(org :";

                for (i=0; i<existsAttribStp->orgAttrNbr; i++)
                {
                    DBA_GetObjectEnum(existsAttribStp->orgAttrTab[i]->entDictId, &srcObjectEn);

                    fullMsgStr += OBJ_V2N(srcObjectEn);
                }

                fullMsgStr += ")";
            }

            MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, fullMsgStr.c_str());

        }

    }

    return (existsAttribStp);
}

/************************************************************************
**
**  Function    : DICT_AddModifySpecialEntity
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**                 REF9789 - LJE - 040105
**                 PMSTA-28349 - 221017 - PMO : 9.1 - Fusion Process
**
*************************************************************************/
STATIC RET_CODE DICT_AddModifySpecialEntity()
{

    /* PMSTA-18593 - LJE - 141210 - Not all links on install from scratch mode */
    if (EV_AAAInstallLevel <= 2)
    {
        /* Copy for entity Ext Transaction */
        DICT_LinkFieldsToEntity(ExtTransaction,
                                UnMatchedExecution,
                                A_ExtTransaction_SrcEntityDictId,
                                A_ExtTransaction_SrcObjectId,
                                FALSE,
                                FALSE,
                                TRUE);
        DICT_LinkFieldsToEntity(ExtTransaction,                     /* FPL-REF10232-040503 */
                                UnMatchedGlExecFee,
                                A_ExtTransaction_SrcEntityDictId,
                                A_ExtTransaction_SrcObjectId,
                                FALSE,
                                FALSE,
                                TRUE);
        DICT_LinkFieldsToEntity(ExtTransaction,
                                ExecutionEnt,
                                A_ExtTransaction_SrcEntityDictId,
                                A_ExtTransaction_SrcObjectId,
                                FALSE,
                                FALSE,
                                TRUE);
        DICT_LinkFieldsToEntity(ExtTransaction,
                                GlExecFeeEnt,
                                A_ExtTransaction_SrcEntityDictId,
                                A_ExtTransaction_SrcObjectId,
                                FALSE,
                                FALSE,
                                TRUE);
        DICT_LinkFieldsToEntity(ExtTransaction,
                                EOp,
                                A_ExtTransaction_SrcEntityDictId,
                                A_ExtTransaction_SrcObjectId,
                                FALSE,
                                FALSE,
                                TRUE);

        /* Copy for entity Ext Execution */
        DICT_LinkFieldsToEntity(ExtExecutionEnt,
                                ExecutionEnt,
                                Null_Dynfld,
                                A_ExtExecution_ExecutionId,
                                FALSE,
                                FALSE,
                                FALSE);
        DICT_LinkFieldsToEntity(ExtExecutionEnt,
                                GlExecFeeEnt,
                                Null_Dynfld,
                                A_ExtExecution_GlobalExecutionFeeId,
                                FALSE,
                                FALSE,
                                FALSE);

        /* Copy for entity UnMatched Execution */
        DICT_LinkFieldsToEntity(UnMatchedExecution,
                                ExecutionEnt,
                                Null_Dynfld,
                                A_UnMatchedExecution_ExecutionId,
                                FALSE,
                                FALSE,
                                FALSE);

        /* Copy for entity UnMatched Global Execution Execution */
        DICT_LinkFieldsToEntity(UnMatchedGlExecFee,                 /* FPL-REF10232-040503 */
                                GlExecFeeEnt,
                                Null_Dynfld,
                                A_UnMatchedGlExecFee_ExecutionId,
                                FALSE,
                                FALSE,
                                FALSE);

        /* Copy for entity Ext Return Analysis */
        DICT_LinkFieldsToEntity(ExtRetAnalysis,
                                PerfStorageParam,
                                Null_Dynfld,
                                Null_Dynfld,
                                FALSE,
                                FALSE,
                                FALSE);
        DICT_LinkFieldsToEntity(ExtRetAnalysis,
                                StandardPerf,
                                Null_Dynfld,
                                Null_Dynfld,
                                FALSE,
                                FALSE,
                                FALSE);
        DICT_LinkFieldsToEntity(ExtRetAnalysis,
                                StdPerfData,
                                Null_Dynfld,
                                Null_Dynfld,
                                FALSE,
                                FALSE,
                                FALSE);
        DICT_LinkFieldsToEntity(ExtRetAnalysis,
                                RetAnaGlobal,
                                Null_Dynfld,
                                Null_Dynfld,
                                FALSE,
                                FALSE,
                                FALSE);
        DICT_LinkFieldsToEntity(ExtRetAnalysis,
                                RetAnaDetailed,
                                Null_Dynfld,
                                Null_Dynfld,
                                FALSE,
                                FALSE,
                                FALSE);
        DICT_LinkFieldsToEntity(ExtRetAnalysis,
                                PerfCalcResult,
                                Null_Dynfld,
                                Null_Dynfld,
                                FALSE,
                                FALSE,
                                FALSE);

        /* Copy for entity Perf Attrib */
        DICT_LinkFieldsToEntity(PerfAttrib,
                                PerfStorageParam,
                                Null_Dynfld,
                                Null_Dynfld,
                                FALSE,
                                FALSE,
                                FALSE);
        DICT_LinkFieldsToEntity(PerfAttrib,
                                PerfAttribData,
                                Null_Dynfld,
                                Null_Dynfld,
                                FALSE,
                                FALSE,
                                FALSE);

        /* Copy for entity Standard Perf */
        DICT_LinkFieldsToEntity(StandardPerf,
                                PerfStorageParam,
                                Null_Dynfld,
                                Null_Dynfld,
                                FALSE,
                                FALSE,
                                FALSE);
        DICT_LinkFieldsToEntity(StandardPerf,
                                StdPerfData,
                                Null_Dynfld,
                                Null_Dynfld,
                                FALSE,
                                FALSE,
                                FALSE);
        DICT_LinkFieldsToEntity(StandardPerf,
                                PerfCalcResult,
                                Null_Dynfld,
                                Null_Dynfld,
                                FALSE,
                                FALSE,
                                FALSE);

        /* REF11435 - TEB - 051012 */
        /* Copy for entity Domain  */
        DICT_LinkFieldsToEntity(SearchLnk,
                                Domain,
                                Null_Dynfld,
                                Null_Dynfld,
                                FALSE,
                                FALSE,
                                FALSE);

        /* Copy for entity Modelling Constraint Element */  /*  FIH-REF11350-PMSTA00236-060203 */
        DICT_LinkFieldsToEntity(EStratElt,
                                ModelConstrElt,
                                Null_Dynfld,
                                Null_Dynfld,
                                FALSE,
                                FALSE,
                                FALSE);

        /* Copy for entity Extended Strategy Element    */  /*  FIH-REF11350-PMSTA00236-060203 */
        DICT_LinkFieldsToEntity(ModelConstrElt,
                                EStratElt,
                                Null_Dynfld,
                                Null_Dynfld,
                                FALSE,
                                FALSE,
                                FALSE);

        /* PMSTA-13109 - LJE - 111116 - Link Xd modele with Dict modele */
        DICT_LinkFieldsToEntity(DictEntity,
                                XdEntity,
                                Null_Dynfld,
                                Null_Dynfld,
                                FALSE,
                                FALSE,
                                FALSE);
        DICT_LinkFieldsToEntity(DictAttr,
                                XdAttrib,
                                Null_Dynfld,
                                Null_Dynfld,
                                FALSE,
                                FALSE,
                                FALSE);
        DICT_LinkFieldsToEntity(DictPermVal,
                                XdPermVal,
                                Null_Dynfld,
                                Null_Dynfld,
                                FALSE,
                                FALSE,
                                FALSE);
        DICT_LinkFieldsToEntity(DictLabel,
                                XdLabel,
                                Null_Dynfld,
                                Null_Dynfld,
                                FALSE,
                                FALSE,
                                FALSE);

        /* Position & Position detail PMSTA-28349 - 221017 - PMO */
        DICT_LinkFieldsToEntity(EPos,
                                PositionDetail,
                                Null_Dynfld,
                                Null_Dynfld,
                                FALSE,
                                FALSE,
                                FALSE);

        /* Balance Position & Balance Position detail PMSTA-28349 - 221017 - PMO */
        DICT_LinkFieldsToEntity(EPos,
                                BalancePosDetail,
                                Null_Dynfld,
                                Null_Dynfld,
                                FALSE,
                                FALSE,
                                FALSE);

        /*  Reference format element & format element   HFI-PMSTA-38117-191202  */
        DICT_LinkFieldsToEntity(ReferenceFormatElement,
                                FmtElt,
                                Null_Dynfld,
                                Null_Dynfld,
                                FALSE,
                                FALSE,
                                FALSE);

        /*  Create all links for tables derived from bi_value_template table */
        DICT_LinkFieldsToEntity(PortBiValue,
                                BiValueTemplate,
                                Null_Dynfld,
                                Null_Dynfld,
                                FALSE,
                                FALSE,
                                FALSE);
        DICT_LinkFieldsToEntity(InstrBiValue,
                                BiValueTemplate,
                                Null_Dynfld,
                                Null_Dynfld,
                                FALSE,
                                FALSE,
                                FALSE);
        DICT_LinkFieldsToEntity(ThirdBiValue,
                                BiValueTemplate,
                                Null_Dynfld,
                                Null_Dynfld,
                                FALSE,
                                FALSE,
                                FALSE);
        DICT_LinkFieldsToEntity(StratBiValue,
                                BiValueTemplate,
                                Null_Dynfld,
                                Null_Dynfld,
                                FALSE,
                                FALSE,
                                FALSE);

        DICT_LinkFieldsToEntity(DictEntityDoc,
                                XdEntityDoc,
                                Null_Dynfld,
                                Null_Dynfld,
                                FALSE,
                                FALSE,
                                FALSE);

        DICT_LinkFieldsToEntity(DictAttributeDoc,
                                XdAttributeDoc,
                                Null_Dynfld,
                                Null_Dynfld,
                                FALSE,
                                FALSE,
                                FALSE);

        DICT_LinkFieldsToEntity(DictPermValDoc,
                                XdPermValDoc,
                                Null_Dynfld,
                                Null_Dynfld,
                                FALSE,
                                FALSE,
                                FALSE);
    }
    else if (EV_AAAInstallLevel < 100)
    {
        /* PMSTA-13109 - LJE - 111116 - Link Xd modele with Dict modele */
        DICT_LinkFieldsToEntity(DictEntity,
                                XdEntity,
                                Null_Dynfld,
                                Null_Dynfld,
                                FALSE,
                                FALSE,
                                FALSE);
    }

    return RET_SUCCEED;
}

/************************************************************************
**
**  Function      : DBA_LimitMetaDictAttribWithUserType
**
**  Description   : Suppress, modify loaded meta dictionary according to
**                  ApplParam USER_TYPE
**
**  Arguments     : OBJECT_ENUM enObject     : Object enum of the search attribute
**                  short       sFieldIndex  : ProgN of the search attribute
**                  FLAG_T      flagDispRank : if FALSE dispRank is set to 0
**                  SMALLINT_T  sSubTypeMask : New edition type mask
**                  OBJECT_ENUM enEntityRef  : New reference entity
**                  MASK_T      lQuickSearch : New quick Search mask
**
**  Return        : RET_SUCCEED or error code
**
**  Creation      : FIH-REF10778-041123
**
************************************************************************/
STATIC void DBA_LimitMetaDictAttribWithUserType(OBJECT_ENUM enObject,
                                                SYSNAME_T   pszSqlName,
                                                SMALLINT_T  sDispRank,
                                                MASK_T      iSubTypeMask,
                                                OBJECT_ENUM enEntityRef,
                                                MASK_T      lQuickSearch,
                                                FLAG_T      flagChangeLabel)
{
    DICT_ATTRIB_STP     pdictattr;
    if (DICT_GetAttribInfo( enObject,
                            -1,
                            0,
                            pszSqlName,
                            GET_FIX_NBR(A_DictAttr),
                            &pdictattr) == RET_SUCCEED)
    {
        if (iSubTypeMask != -1)
        {
            pdictattr->subTypeMask = iSubTypeMask;
        }
        if (sDispRank != -1)
        {
            pdictattr->dispRank = sDispRank;
        }
        if (enEntityRef == InvalidEntity)
        {
            pdictattr->refEntDictId = InvalidEntityCst;
        }
        else if (enEntityRef != NullEntity)
        {
            
            DICT_ENTITY_STP refDictEntityStp = DBA_GetDictEntitySt(enEntityRef);
            if (refDictEntityStp != nullptr)
            {
                pdictattr->refEntDictId = refDictEntityStp->entDictId;
                if (flagChangeLabel == TRUE)
                {
                    pdictattr->SET_daLabel(refDictEntityStp->labelStr.c_str());/* PMSTA-22278 - 160203 - DDV - Use char* and UChar* instead of STRING1000_T and UNI_STRING1000_T */
                }
            }
        }
        if (lQuickSearch != -1)             /*  FIH-REF10864-050107 */
        {
            pdictattr->qSearchMask = lQuickSearch;
        }
    }
}

/************************************************************************
**
**  Function        : DBA_LimitMetaDictWithUserType
**
**  Description     : Suppress, modify loaded meta-dictionary according to
**                    ApplParam USER_TYPE
**
**  Arguments       : None
**
**  Return          : RET_SUCCEED or error code
**
**  Creation		: FIH-REF10778-041123
**  Modif           : HFI-WEALTH-7201-2024-05-24    Rewrite the function: invert the test
**
************************************************************************/
STATIC void DBA_LimitMetaDictWithUserType (void)
{
    APPL_USERTYPE_ENUM      enUserType = UserType_AAA;

    /*  Get current user type                                           */
    GEN_GetApplInfo(ApplUserType, &enUserType);

    if (enUserType == UserType_Componant)
    {
        DBA_LimitMetaDictAttribWithUserType(Instr,          "min_account_bal_amount_n",  153,      17,    NullEntity, -1, FALSE);
        DBA_LimitMetaDictAttribWithUserType(Instr,          "min_account_bal_percent_p", 154,      17,    NullEntity, -1, FALSE);

        DBA_LimitMetaDictAttribWithUserType(ModelConstr,    "dim_port_dict_id",            3,      31,    NullEntity, 31, FALSE);
        DBA_LimitMetaDictAttribWithUserType(ModelConstr,    "port_object_id",             -1,      -1, InvalidEntity, 31, TRUE);

        DBA_LimitMetaDictAttribWithUserType(ModelConstrElt, "fixed_cell_f",               -1,      23,    NullEntity, -1, FALSE);
        DBA_LimitMetaDictAttribWithUserType(ModelConstrElt, "constr_treat_e",             -1,      31,    NullEntity, -1, FALSE);
        DBA_LimitMetaDictAttribWithUserType(ModelConstrElt, "priority_n",                 14,      23,    NullEntity, -1, FALSE);

        DBA_LimitMetaDictAttribWithUserType(Strat,          "rebalancing_strategy_id",    14, 4194305,    NullEntity, -1, FALSE);
        DBA_LimitMetaDictAttribWithUserType(Strat,          "heart_upload_e",             29,     -33,    NullEntity, -1, FALSE);

        DBA_LimitMetaDictAttribWithUserType(StratCompo,     "min_buy_amount_n",            7,       1,    NullEntity, -1, FALSE);
        DBA_LimitMetaDictAttribWithUserType(StratCompo,     "min_buy_percentage_p",        8,       1,    NullEntity, -1, FALSE);
        DBA_LimitMetaDictAttribWithUserType(StratCompo,     "min_sell_amount_n",           9,       1,    NullEntity, -1, FALSE);
        DBA_LimitMetaDictAttribWithUserType(StratCompo,     "min_sell_percentage_p",      10,       1,    NullEntity, -1, FALSE);

        DBA_LimitMetaDictAttribWithUserType(List,           "model_constraint",           21,     127,    NullEntity, -1, FALSE);
    }
}

/************************************************************************
*   Function	:	DBA_CmpDictFct
*
*   Description	:	Sort entities list by dictId and EntityDictId.
*					Function call by TLS_Sort()
*
*   Arguments	:	DICT_FCT_STP ptr1, DICT_FCT_STP ptr2
*
*   Return 		:	int
*
**  Cr�ation	:	ROI - 961120 - DVP245
**  Modif.      :   ROI - 980320 - REF1476
**
*************************************************************************/
STATIC bool DBA_CmpDictFct(const DICT_FCT_ST &ptr1, const DICT_FCT_ST &ptr2)
{
    int	val;

    val = CMP_ID(ptr1.entityDictId,ptr2.entityDictId);
    if (val == 0)
    {
        val = CMP_ID(ptr1.idx ,ptr2.idx);
        if (val == 0)
            val = CMP_ID(ptr1.dictId ,ptr2.dictId);
    }

    return val<0;
}


/************************************************************************
**
**  Function        : DBA_SetDictScreenRights
**
**  Description     : fill the bDictScreenRights
**
**  Arguments       : DICT_ENTITY_STP  pdictent: the entity to be referenced
**
**  Return          : RET_SUCCEED
**
**	Creation        : HFI-PMSTA-51777-2022-01-06
**
*************************************************************************/
STATIC RET_CODE DBA_SetDictScreenRights (DICT_ENTITY_STP    pdictent)
{
    RET_CODE    retCode = RET_SUCCEED;

    if (pdictent == nullptr)
    {
        retCode = RET_GEN_ERR_INVARG;
    }
    else
    {
        switch (pdictent->entNatEn)
        {
            case EntityNat_Standard :
            case EntityNat_Packaging :
            case EntityNat_Custom :
            case EntityNat_ModelBank :
            case EntityNat_CustomDS :
            case EntityNat_Questionnaire :
            {
                OBJECT_ENUM enObject;
                if ((DBA_GetObjectEnum(pdictent->entDictId, &enObject) == FALSE))
                {
                    retCode = RET_GEN_ERR_INVARG;
                }
                else
                {
                    switch (GET_OBJECT_CST(enObject))
                    {
                        case ApplParamCst:
                        case CurrModifCst:
                        case BuildListCompoCst:
                        case CheckListCst:
                        case ReturnGridLnkCst:
                        case EStratLnkCst:
                        case StratEltDetailCst:
                        case FctResultCst:
                        case StatCst:
                        case RegrCst:
                        case AccPerParamCst:
                        case PtfSynthCst:
                        case PtfFusionEntCst:
                        case PtfReturnCst:
                        case AccPerCst:
                        case AccPlanEltCst:
                        case FundValCst:
                        case FundValEltCst:
                        case AccPlanCst:
                        case CompInstrChronoCst:
                        case PosCst:
                        case OpCst:
                        case EventSchedCst:
                        case EPosCst:
                        case PValCst:
                        case OpDomainEntCst:
                        case ShareOpInfoCst:
                        case PrintParamCst:
                        case ReportGenCst:
                        case QuickSearchCst:
                        case LogCst:
                        case OneCst:
                        case EmptyCst:
                        case TabCntCst:
                        case StandardPerfCst:
                        case ArchiveCst:
                        case BenchWeightCst:
                        case ConstraintBreachCst:
                        case ConstraintParameterCst:
                        case AdminMgrCst:
                        case DataDescCst:
                        case DataDispCst:
                        case ScenaCst:
                        case ScenaCompoCst:
                        case ScenaEltCst:
                        case DerivedStratCst:
                        case DerivedStratEltCst:
                        case CurrFreqCst:
                        case ThirdFreqCst:
                        case DocIndexCst:
                        case DocCst:
                        case FolderCst:
                        case ExtRetAnalysisCst:
                        case ExtExecutionEntCst:
                        case ExtOrderCst:
                        case EventUpdateCst:
                        case PtfFreqCst:
                        case InstrFreqCst:
                        case AdvACst:
                        case OpCompoCst:
                        case PerfAttribCst:
                        case WarningMsgEntCst:
                        case UInterCst:
                        case EvtExclCst:
                            pdictent->bDictScreenRights = false;
                            break;
                        default :
                            if (((pdictent->virtualEntFlg == TRUE)  &&
                                 (pdictent->entNatEn != EntityNat_Questionnaire)) ||
                                (pdictent->validEntFlg == FALSE))
                            {
                                pdictent->bDictScreenRights = false;
                            }
                            else
                            {
                                pdictent->bDictScreenRights = true;
                            }
                    }
                }
                break;
            }
        }
    }
    return retCode;
}

/************************************************************************
**
**  Function    :   DBA_UpdFctTabAdm
**
**  Description :   Updating table EV_DictFctTab for administration.
**
**  Argument    :   DICT_FCT_ENUM fctEn
**
**  Return      :   RET_CODE
**
**  Cr�ation    :   ROI - 961121 - DVP260
**  Modif.      :   ROI - 961216 - DVP260
**  Modif.      :   ROI - 980320 - REF1476
**  Modif.      :   ROI - 990113 - REF3213
**  Modif.      :   FIH - 990408 - REF3162
**
*************************************************************************/
STATIC RET_CODE	DBA_UpdFctTabAdm (DICT_FCT_ENUM fctEn, DICT_T entityDictId, bool bFreeFunction)
{
    DICT_FCT_STP        fctStp,
                        parFctStp;
    FLAG_T              found;
    int                 permValNb;
    PERMITED_VALUES_STP permValTab = NULL;
    DICT_T              opDictId;

    /* Special case for Administration function without NullEntity */
    size_t idx = 0;
    short fctNb = 0;
    size_t iAdmIndex = 0;
    size_t iOpIndex = 0;
    found = FALSE;
    DBA_GetDictId(Op, &opDictId);
    for (size_t i = 0; i < EV_DictFctTab.size(); i++)
    {
        /* Init loop variable */
        fctStp = &(EV_DictFctTab[i]);

        /* Check fctEn */
        if (fctStp->dictId == fctEn)
        {
            idx = i;
            if (fctStp->entityDictId != 0)			/* REF3213 */
                fctStp->idx = fctNb++;
            if (fctStp->entityDictId == entityDictId)
                found = TRUE;
            /*  FIH-REF3162-990408  */
            if (fctStp->entityDictId == 0)
                iAdmIndex = i;
            else if (fctStp->entityDictId == opDictId)
                iOpIndex = i;
        }
    }

    /* Adding a line if not found */
    if (found == FALSE)
    {
        /* Test allocation */
        EV_DictFctTab.push_back(DICT_FCT_ST());

        /* Setup added line */
        fctStp = &(EV_DictFctTab.back());
        memset(fctStp, 0, sizeof(DICT_FCT_ST));

        if (bFreeFunction == true)
        {
            fctStp->dictId = fctEn;
            strcpy(fctStp->procName, "FREE_TO_BE_REMOVED");
            strcpy(fctStp->name, "FREE_TO_BE_REMOVED");
        }
        else
        {
            parFctStp = &(EV_DictFctTab[idx]);
            fctStp->dictId = parFctStp->dictId;
            fctStp->entityDictId = entityDictId;
            strcpy(fctStp->name, parFctStp->name);
            strcpy(fctStp->label, parFctStp->label);
            u_strcpy(fctStp->uniLabel, parFctStp->uniLabel); /* REF9303 - LJE - 030912 */
            strcpy(fctStp->procName, parFctStp->procName);
            strcpy(fctStp->helpNode, parFctStp->helpNode);
            strcpy(fctStp->iconName, parFctStp->iconName);
            /*  FIH-REF3143-981215  Neccessary for unit issue and isuue redemption  */
            if ((fctEn == DictFct_Admin) &&
                (DBA_FillPermValTab(OpDomainEnt,OpDomain_StatusEn,(PTR) &permValTab, &permValNb, 0) == RET_SUCCEED) &&
                (permValTab != NULL))
            {
                fctStp->minOpStatus = (ENUM_T) permValTab[0].value;
                fctStp->maxOpStatus = (ENUM_T) permValTab[permValNb - 1].value;

                delete [] permValTab;
                permValTab = nullptr;

                /*  FIH-REF3162-990408  */
                parFctStp = NULL;
                if (iOpIndex != 0)
                    parFctStp = &(EV_DictFctTab[iOpIndex]);
                else if (iAdmIndex != 0)
                    parFctStp = &(EV_DictFctTab[iAdmIndex]);
                if (parFctStp != NULL)
                {
                    fctStp->createFlag = parFctStp->createFlag;
                    fctStp->updateFlag = parFctStp->updateFlag;
                    fctStp->deleteFlag = parFctStp->deleteFlag;
                }
            }
        }
    }
    return RET_SUCCEED;
}

#ifdef NEXUS
/************************************************************************
**
**  Function    :   DBA_CreateFnSecuProf
**
**  Description :   Updating table EV_DictFctTab
**
**  Argument    :
**
**  Return      :
**
**  Cr�ation    :   FPL-REF10260-040521
**
************************************************************************/
STATIC RET_CODE    DBA_CreateFnSecuProf  ( DICT_FCT_ENUM    fctEn       /*  fn              */
                                         , DICT_T           entDictId   /*  entity          */
                                         , ENUM_T           minStatus   /*  min status      */
                                         , ENUM_T           maxStatus   /*  max status      */
                                         , FLAG_T           bCreate     /*  create flag     */
                                         , FLAG_T           bUpdate     /*  update flag     */
                                         , FLAG_T           bDelete     /*  delete flag     */
                                         , FLAG_T           bView       /*  view flag       */
                                         , FLAG_T           bVisible    /*  visible flag    */
                                         )
{
    OBJECT_ENUM     entityRef   ;
    DICT_FCT_STP    fctStp      ;


    if (fctEn <= 0)
        return RET_GEN_ERR_INVARG ;

    DBA_GetObjectEnum(entDictId, &entityRef);

    DBA_UpdFctTabAdm(fctEn, entDictId, false);

    if ((DBA_GetDictFctAdmAuth(fctEn, entityRef, DictFctInfo_Stp, &fctStp) == RET_SUCCEED) &&
    ((fctStp->dictId == DictFct_Admin) &&
     (fctStp->entityDictId == entDictId)
    )
   )
    {
        fctStp->minOpStatus = minStatus ;
        fctStp->maxOpStatus = maxStatus ;
        fctStp->createFlag  = bCreate   ;
        fctStp->updateFlag  = bUpdate   ;
        fctStp->deleteFlag  = bDelete   ;
        fctStp->viewFlag    = bView     ;
        fctStp->visibleFlag = bVisible  ;
    }

    return RET_SUCCEED ;

}
#endif

/************************************************************************
 **   END  dbadictload.c
 *************************************************************************/


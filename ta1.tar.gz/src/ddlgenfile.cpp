/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define DdlGenFile_CPP

/************************************************************************
**      Include files
*************************************************************************/
#include       <iomanip>
#include       <string.h>

#include      "unidef.h"     /* Mandatory */
#include      "ddlgen.h"
#include      "ddlgenfile.h"
#include	  <limits.h>

#ifdef NTWIN
#include <direct.h>
#else
#include <sys/stat.h>
#endif

#ifdef _WINDOWS
#include <sys/stat.h>
#include <io.h>
#endif

using namespace std;

/************************************************************************
**      External entry points
**
*************************************************************************/

/************************************************************************
**      Local functions
**
*************************************************************************/

/************************************************************************
**      Static definitions & data
**
*************************************************************************/

/************************************************************************
**      FONCTIONS
**
************************************************************************/
/************************************************************************
**
**  Function    :   DdlGenFile()
**
**  Description :   Constructor
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-ORACLE - LJE - 140910
**
*************************************************************************/
DdlGenFile::DdlGenFile(DdlGenContext &paramDdlGenContext, 
                       OBJECT_ENUM    paramObjectEn, 
                       DDL_OBJ_ENUM   paramDdlObjEn, 
                       bool           bAppendFile, 
                       bool           bOpenCheckFile)
    : DdlGenMsg(&paramDdlGenContext)
{
    this->ddlObjEn            = paramDdlObjEn;
    this->objectEn            = paramObjectEn;
    this->outFileLinePos      = 0;
    this->fixedOutFileLineNbr = 0;

    this->dictEntityStp = DBA_GetDictEntitySt(this->objectEn);
    if (this->dictEntityStp != NULL)
    {
        this->entitySqlName = this->dictEntityStp->mdSqlName;
    }
    else
    {
        this->entitySqlName = "unknown_entity";
    }

    if (this->ddlGenContextPtr->bWriteFile)
    {
        this->createOutputDdlFile(bAppendFile, bOpenCheckFile);
    }
}

/************************************************************************
**
**  Function    :   ~DdlGenFile()
**
**  Description :   Destructor
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-ORACLE - LJE - 140910
**
*************************************************************************/
DdlGenFile::~DdlGenFile()
{
    if (this->outputFile.is_open() == true)
    {
        if (this->outFileLinePos == 0)
        {
            this->outputFile.close();
            remove(this->outputFileStr.c_str());
        }
    }
    this->closeAllFiles();
}

/************************************************************************
**
**  Function    :   operator<<()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-37366 - LJE - 200611
**
*************************************************************************/
DdlGenFile &DdlGenFile::operator<<(const std::string& str)
{
    if (this->outputFile.is_open())
    {
        this->outputFile << str;

        std::string::size_type pos = 0;
        while ((pos = str.find("\n", pos)) != std::string::npos)
        {
            pos++;
            this->outFileLinePos++;
        }
    }
    return *this;
}

/************************************************************************
**
**  Function    :   operator<<()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-37366 - LJE - 200611
**
*************************************************************************/
DdlGenFile &DdlGenFile::operator<<(std::stringstream& os)
{
    if (this->outputFile.is_open())
    {
        string lineStr;
        os.clear();
        os.seekg(0, ios::beg);
        while (getline(os, lineStr))
        {
            this->outputFile << lineStr << "\n";
            ++(this->outFileLinePos);
        }
    }
    return *this;
}

/************************************************************************
**
**  Function    :   operator<<()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-37366 - LJE - 200611
**
*************************************************************************/
DdlGenFile &DdlGenFile::operator<<(int i)
{
    if (this->outputFile.is_open())
    {
        this->outputFile << i;
    }
    return *this;
}

/************************************************************************
**
**  Function    :   flush()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-37366 - LJE - 200611
**
*************************************************************************/
void DdlGenFile::flush()
{
    if (this->outputFile.is_open())
    {
        this->outputFile.flush();
    }
}

/************************************************************************
**
**  Function    :   flush()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-37366 - LJE - 200611
**
*************************************************************************/
void DdlGenFile::getFileHeader(std::stringstream &outputStream, unsigned &linePos)
{
    outputStream
        << "/************************************************************************" << endl
        << "**" << endl
        << "**           Copyright (C) 1995-2023 Temenos Headquarters SA" << endl
        << "**                         All Rights Reserved" << endl
        << "**" << endl
        << "**                     Portfolio Management System" << endl
        << "**" << endl
        << "*************************************************************************/" << endl << endl;

    linePos += 9;
}

/************************************************************************
**
**  Function    :  DdlGenFile::createOutputDdlFile()
**
**  Description :  Open file $AAAMSG/...gen_ddl.sql
**
**  Arguments   :  path
**
**  Return      :
**
** Creation     :  PMSTA-11505 - LJE - 110404
**
*************************************************************************/
RET_CODE DdlGenFile::createOutputDdlFile(bool bAppendFile, bool bOpenCheckFile)
{
    if (this->outputFile.is_open() == false)
    {
        stringstream       fileStream;
        ifstream           inputFile;
        ios_base::openmode openMode;
        string             fileSufStr, targetStr;

        fileStream << this->entitySqlName << "_";

        switch (this->ddlObjEn)
        {
            case DdlObj_SProc:
                fileSufStr = "p";
                targetStr = "all procedures";
                break;
            case DdlObj_SpecSProc:
                fileSufStr = "spec_p";
                targetStr = "special procedures";
                break;
            case DdlObj_View:
                fileSufStr = "vw";
                targetStr = "all views";
                break;
            case DdlObj_Trigger:
                fileSufStr = "tr";
                targetStr = "all triggers";
                break;
            case DdlObj_Table:
            case DdlObj_TempTable:
                fileSufStr = "tb";
                targetStr = "table";
                break;
            case DdlObj_Index:
            case DdlObj_TempTableIndex:
                fileSufStr = "idx";
                targetStr = "all indexes";
                break;
            case DdlObj_ForeignKey:
                fileSufStr = "fk";
                targetStr = "foreign key";
                break;
            case DdlObj_Constraint:
                fileSufStr = "constr";
                targetStr = "constraints";
                break;
            case DdlObj_Migration:
                fileSufStr = "mig";
                targetStr = "migration";
                break;
            default:
                fileSufStr = "na";
                targetStr = "Unknown";
                break;
        }

        if (this->ddlGenContextPtr->bGenFromDbi)
        {
            fileStream << fileSufStr << "." << DdlGenDbi::getRdbmsShortName(this->ddlGenContextPtr->m_rdbmsEn);
        }
        else
        {
            fileStream << fileSufStr << ".gen";
        }
        fileStream << ".sql";

        this->outputFileStr = this->ddlGenContextPtr->getDdlGenPath() + FILE_SEPARATOR;

        if (this->ddlGenContextPtr->bGenFromDbi)
        {
            this->outputFileStr += "src" FILE_SEPARATOR;
        }
        else
        {
            this->outputFileStr += "gen" FILE_SEPARATOR;
        }

        this->outputFileStr += fileStream.str();

        this->outFileLinePos = 1;
        if (bAppendFile)
        {
            openMode = ios_base::in | ios_base::binary;
            inputFile.open(this->outputFileStr.c_str(), openMode);
            if (inputFile.is_open() == true)
            {
                /*
                this->outFileLinePos = std::count(std::istreambuf_iterator<char>(inputFile),
                std::istreambuf_iterator<char>(), '\n') + 1;
                */
                this->outFileLinePos = 0;
                while (inputFile.ignore(INT_MAX, '\n'))
                {
                    ++(this->outFileLinePos);
                }
            }
        }

        openMode = ios_base::out | ios_base::binary;
        if (bAppendFile)
            openMode |= ios_base::app;

#ifdef _WINDOWS
        if (this->ddlGenContextPtr->bGenFromDbi)
        {
            (void)_chmod(this->outputFileStr.c_str(), _S_IREAD | _S_IWRITE);
        }
#endif

        this->outputFile.open(this->outputFileStr.c_str(), openMode);

        if (this->outputFile.is_open() == false)
        {
            this->printMsg(RET_FILE_ERR_OPEN, "Cannot open the output file " + this->outputFileStr);
            return RET_FILE_ERR_OPEN;
        }

        if (bAppendFile == false && this->ddlGenContextPtr->bGenFromDbi)
        {
            stringstream header;
            DdlGenFile::getFileHeader(header, this->outFileLinePos);
            
            this->outputFile << header.str();
            this->outputFile << DdlGenDbi::beginOfBlock(this->ddlGenContextPtr->m_rdbmsEn);
            this->outputFile << DdlGenDbi::getCmdPrintMsg("About to drop and create " + targetStr + " for entity "
                                                               + this->entitySqlName
                                                               + " on "
                                                               + DdlGenDbi::getRdbmsName(this->ddlGenContextPtr->m_rdbmsEn) + " database ($AAAMAIN_DB)", false, this->ddlGenContextPtr) << endl;
            this->outputFile << DdlGenDbi::getCmdPrintMsg("===================================================================", false, this->ddlGenContextPtr) << endl
                << DdlGenDbi::getCmdGo(this->ddlGenContextPtr->m_rdbmsEn) << endl << endl;
            this->outFileLinePos += 4;
            this->fixedOutFileLineNbr = this->outFileLinePos;
        }

        if (bOpenCheckFile)
        {
            fileStream.clear();
            fileStream.str(string());
            fileStream << this->ddlGenContextPtr->getDdlGenPath() << FILE_SEPARATOR << "log" << FILE_SEPARATOR << this->entitySqlName << "_" << fileSufStr << ".diff";
            this->toChkStr = fileStream.str();

            fileStream.clear();
            fileStream.str(string());
            fileStream << this->ddlGenContextPtr->getDdlGenPath() << FILE_SEPARATOR << "log" << FILE_SEPARATOR << "before";
#if (defined NTWIN || defined INCGNU)
            (void)mkdir(fileStream.str().c_str());
#else
            mkdir(fileStream.str().c_str(), S_IRUSR | S_IWUSR | S_IXUSR);
#endif
            fileStream << FILE_SEPARATOR << this->entitySqlName << "_" << fileSufStr << ".sql";
            this->chk1Str = fileStream.str();

            fileStream.clear();
            fileStream.str(string());
            fileStream << this->ddlGenContextPtr->getDdlGenPath() << FILE_SEPARATOR << "log" << FILE_SEPARATOR << "after";
#if (defined NTWIN || defined INCGNU)
            (void)mkdir(fileStream.str().c_str());
#else
            mkdir(fileStream.str().c_str(), S_IRUSR | S_IWUSR | S_IXUSR);
#endif
            fileStream << FILE_SEPARATOR << this->entitySqlName << "_" << fileSufStr << ".sql";
            this->chk2Str = fileStream.str();

            if (bOpenCheckFile && bAppendFile == false)
            {
                remove(this->chk1Str.c_str());
                remove(this->chk2Str.c_str());
                remove(this->toChkStr.c_str());
            }
        }
    }

    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   DdlGenFile::closeAllFiles()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13109 - LJE - 111124
**
*************************************************************************/
void DdlGenFile::closeAllFiles()
{
    if (this->outputFile.is_open() == true)
    {
        if (this->ddlGenContextPtr->bGenFromDbi)
        {
            this->outputFile << DdlGenDbi::endOfBlock(this->ddlGenContextPtr->m_rdbmsEn);
        }

        this->outputFile.close();

        /* Remove empty files */
        if (this->fixedOutFileLineNbr > 0 &&
            this->outFileLinePos == this->fixedOutFileLineNbr)
        {
            remove(this->outputFileStr.c_str());
        }
    }
    if (this->chkFile1.is_open() == true)
    {
        this->chkFile1.close();
    }
    if (this->chkFile2.is_open() == true)
    {
        this->chkFile2.close();
    }
    if (this->procDiffFile.is_open() == true)
    {
        this->procDiffFile.close();
    }
}



/*************************************************************************
**   END  DdlGenFile.cpp                                        Odyssey **
*************************************************************************/


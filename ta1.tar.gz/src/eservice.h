/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef ESERVICE_H
#define ESERVICE_H

typedef enum {
	ExtServiceDirection_None,		/* 0 */
	ExtServiceDirection_Out,		/* 1 */
	ExtServiceDirection_In,			/* 2 */

	ExtServiceDirection_Last
} ESERVICE_DIRECTION_ENUM;

typedef enum {
	ExtServiceNat_None,		/* 0 */
	ExtServiceNat_Risk,		/* 1 */
	ExtServiceNat_Lombard,  /* 2 */  /*PMSTA-21251 - Cashwini - 150928 */
	ExtServiceNat_Search,   /* 3 */	 /*PMSTA-38542 - kramadevi - 16012020 */
	ExtServiceNat_BuyingPower,  /* 4 */  /*PMSTA-34546 - kramadevi - 290119 */
	ExtServiceNat_Compliance,   /* 5 */  /*PMSTA-37528 - kramadevi - 11102019*/
	ExtServiceNat_ComplianceExAntePostOrders,   /* 6 */ /*PMSTA-37528 - kramadevi - 11102019*/
	ExtServiceNat_PtfTransfFees,				/* 7 */ /* PMSTA-39717 - KNI - 09062020 */

	ExtServiceNat_Last
} ESERVICE_NATURE_ENUM;

typedef enum {
	ExtServiceProtocol_None,	/* 0 */
	ExtServiceProtocol_HTTP,	/* 1 */
	ExtServiceProtocol_HTTPS,	/* 2 */

	ExtServiceProtocol_Last
} ESERVICE_PROTOCOL_ENUM;

/* PMSTA-22496 - DDV - 160511 */
typedef enum {
	ExtServiceProfCompoNat_RiskCheck=1,      /* 1 */
	ExtServiceProfCompoNat_LombardCheck,     /* 2 */
	ExtServiceProfCompoNat_FinFct,           /* 3 */
	ExtServiceProfCompoNat_BuyingPower,       /* 4 */ /*PMSTA-34546 - kramadevi - 290119 */
	ExtServiceProfCompoNat_Compliance,		 /* 5 */ /*PMSTA-37528 - kramadevi - 11102019*/
	ExtServiceProfCompoNat_PtfTransfFees     /* 6 */ /* PMSTA-39717 - KNI - 09062020 */

} ESERVPROFCOMPO_NAT_ENUM;

/*PMSTA-37528 - kramadevi - 11102019*/
typedef enum {
    ExtServiceBreakCriteriaEn_None,
    ExtServiceBreakCriteriaEn_Session,
    ExtServiceBreakCriteriaEn_Portfolio,
    ExtServiceBreakCriteriaEn_Client
} ESERVICE_BREAKCRITERIA_ENUM;

/************************************************************************
**      Structure definitions
*************************************************************************/
typedef struct {
	DBA_DYNFLD_STP	esCompoStp;
	DBA_DYNST_ENUM	sourceDynStEnum;
	OBJECT_ENUM		sourceObjectEnum;
	DBA_DYNFLD_STP	*sourceDataTab;
	int				sourceDataNbr;
	DBA_DYNST_ENUM	targetDynStEnum;
	OBJECT_ENUM		targetObjectEnum;
	DBA_DYNFLD_STP	*targetDataTab;
	int				targetDataNbr;
} EXT_SERVICE_ELT_ST, *EXT_SERVICE_ELT_STP;

typedef struct {
    char                *extSvcTraceFilename;
    RET_CODE            extSvcTraceStatus;
} ESRV_TRACEFILE_ST, *ESRV_TRACEFILE_STP;

typedef struct {
	DBA_DYNFLD_STP		esPtr;
	FLAG_T              esFreeFlg;
	int				    requestESEltNbr;
	EXT_SERVICE_ELT_STP	requestESEltTab;
	int				    responseESEltNbr;
	EXT_SERVICE_ELT_STP	responseESEltTab;
    ESRV_TRACEFILE_ST   extSvcTraceFileSt;
} EXT_SERVICE_DATA_ST, *EXT_SERVICE_DATA_STP;

typedef struct {
    int                   esDataTabAllocSz;
    int                   esDataNbr;
    EXT_SERVICE_DATA_STP *esDataTab;
} ESRV_OPTI_ST, *ESRV_OPTI_STP;

typedef struct {
    int                   eSRVOptiTabAllocSz;
    int                   eSRVOptiTabNbr;
    ESRV_OPTI_STP        *eSRVOptiTabTab;
} ESRV_OPTIHEAD_ST, *ESRV_OPTIHEAD_STP;

/************************************************************************
**  BEGIN : Global variables & external definitions attached to eservice.c
*************************************************************************/
extern RET_CODE FIN_CallRiskExtService(PTR, DBA_DYNFLD_STP, FLAG_T);
extern RET_CODE FIN_CallLombardExtService(PTR, DBA_DYNFLD_STP); /*PMSTA - 21251 - Cashwini - 150928*/
extern RET_CODE ESRV_CallAllExtServiceByNat(ID_T, ESERVPROFCOMPO_NAT_ENUM, DICT_T, DBA_HIER_HEAD_STP, DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, FLAG_T); /* PMSTA-22496 - DDV - 160504 */
extern RET_CODE ESRV_CallOneExtService(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, FLAG_T);                             /* PMSTA-22496 - DDV - 160504 */
extern void     ESRV_FreeOpti();                                                                                                                  /* PMSTA-22496 - DDV - 160621 */
extern RET_CODE FIN_CallBuyingPowerExtService(PTR, DBA_DYNFLD_STP); /*PMSTA-34546 - kramadevi - 300119*/                                                                                                                 /* PMSTA-22496 - DDV - 160621 */
extern RET_CODE FIN_CallComplianceExtService(PTR, DBA_DYNFLD_STP, OBJECT_ENUM*); /*PMSTA-37528 - kramadevi - 11102019*/ /* PMSTA-64470 - Deepthi - 20250122 */
extern RET_CODE FIN_CallPtfTransfExtService(PTR, DBA_DYNFLD_STP);   /* PMSTA-39717 - KNI - 09062020 */
extern RET_CODE FIN_CreateCaseForExtSErviceFailure(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, DBA_DYNFLD_STP); /*PMSTA-39985 -NRAO -28-APR-2020*/
extern RET_CODE FIN_DelCaseMgtRecordByNature(DBA_DYNFLD_STP, ENUM_T); /*PMSTA-39985 -NRAO -28-APR-2020*/
extern RET_CODE FIN_CallOAuthServiceJWKSEndPoint();
extern bool resolveEnvVariableToValueInURL(std::string& url);

#endif /* ESERVICE_H */

/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define FINLIB04_C

/************************************************************************
**      Include files
*************************************************************************/
#define STDIO_H
#define STRING_H
#define STDLIB_H
#define MATH_H
#define CTYPE_H

#include "unidef.h"     /* Mandatory */
#include "gen.h"
#include "dba.h"
#include "proc.h"
#include "fin.h"
#include "tls.h"
#include "syslib.h"     /* PMO - Rename our sys.h to syslib.h and use it */
#include "scpt.h"
#include "scptyl.h"
#include "scelib.h"     /* REF9082 - TEB - 030528 */
#include "sce.h"        /* REF9082 - TEB - 030528 */
#include "dbiconnection.h"

/************************************************************************
**      External entry points
**
** FIN_EstVol()				  Computes the estimated volatility (REF10531 - TEB - 040806)
** FIN_Conv()                 Computes convexity (REF9082 - TEB - 030530)
** FIN_MDura()                Computes mod. duration (REF9082 - TEB - 030528)
** FIN_Dura()                 Computes duration (REF9082 - TEB - 030528)
** FIN_Classify()
** FIN_CrtYield()             Calculates the current yield of an instrument
** FIN_InstrChrono()          Read chrono data or compute it (if none and asked)
** FIN_InstrChronoArray()     Construct an instrument chronological data array
** FIN_InstrPriceArray()      Construct an instrument prices array
** FIN_InstrPriceArray2()     Construct an instrument prices array with method selection
** FIN_ExchRateArray()        Construct an exchange rate array
** FIN_PtfChronoArray()       Construct an portfolio chronological data array
** FIN_ListChronoArray()      Construct an list chronological data array       (REF7292 - LJE - 020130)
** FIN_Regr() 	              Computes alpha, beta, covariance, ...
** FIN_SearchInstrInGrid()    Determine if an instr. belongs to a grid, and return the market sgt
** FIN_SearchInstrInMktSegt() Determine if an instrument belongs to a market segment.
** FIN_Stat() 		          Computes mean, standard deviation, variance
** FIN_CalcStat()             Receives one array of data and compute statistics
** FIN_ThirdChronoArray()     Construct an third chronological data array
** FIN_SetInstrInStratHier    Positioning an instrument in a strategy hierarchy
**
*************************************************************************/

/************************************************************************
**      Local functions
**
** FIN_CalcRegr() Receives two arrays of data and computes regression
** FIN_CmpEClassifCompoPtr()
** FIN_SearchInstrChronoEltInTab() Searching chrono at a date in an array REF7061 - TEB - 030123
** FIN_SearchPtfChronoEltInTab()   Searching chrono at a date in an array REF7061 - TEB - 030123
** FIN_SearchListChronoEltInTab()  Searching chrono at a date in an array REF7061 - TEB - 030123
** FIN_SearchThirdChronoEltInTab() Searching chrono at a date in an array REF7061 - TEB - 030123
**
*************************************************************************/

/************************************************************************
**      Static definitions & data
*************************************************************************/
STATIC RET_CODE	FIN_CalcRegr(double*, double*, int, DBA_DYNFLD_STP);

STATIC int FIN_CmpEClassifCompoPtr(DBA_DYNFLD_STP *, DBA_DYNFLD_STP *),
/* REF2544 - SSO - 980717 - FIN_CmpInstrPriceDate and FIN_CmpExchRateDate moved to dbainstr.c, dbaexch.c */
/*           FIN_CmpInstrPriceDate(DBA_DYNFLD_STP *, DBA_DYNFLD_STP *), */
/*           FIN_CmpExchRateDate(DBA_DYNFLD_STP *, DBA_DYNFLD_STP *), */
           FIN_CmpInstrChronoDate(DBA_DYNFLD_STP *, DBA_DYNFLD_STP *),
           FIN_CmpPtfChronoDate(DBA_DYNFLD_STP *, DBA_DYNFLD_STP *),
		   FIN_CmpListChronoDate(DBA_DYNFLD_STP *, DBA_DYNFLD_STP *), /* REF7292 - LJE - 020130 */
           FIN_CmpThirdChronoDate(DBA_DYNFLD_STP *, DBA_DYNFLD_STP *);

STATIC int FIN_FilterSMktSegtByLid(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP);
STATIC int FIN_FilterSMktSSubSetByLid(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP); /* REF7420 - LJE - 020903 */
STATIC int FIN_FilterSMktStructByLid(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP); /* REF7420 - LJE - 020903 */

/* REF7420 - LJE - 020523 */
STATIC RET_CODE FIN_GetMktSegtByLid  (DBA_HIER_HEAD_STP, ID_T, ID_T, ID_T, ID_T, DBA_DYNFLD_STP*, int, int*),
				FIN_GetMktStructInTab(DBA_DYNFLD_STP, DBA_DYNFLD_STP*, int, DBA_DYNFLD_STP*);

/* REF7061 - TEB - 030123*/
STATIC int FIN_SearchInstrChronoEltInTab(DBA_DYNFLD_STP *, int, DATETIME_T, DBA_DYNFLD_STP);
STATIC int FIN_SearchPtfChronoEltInTab(  DBA_DYNFLD_STP *, int, DATETIME_T, DBA_DYNFLD_STP);
STATIC int FIN_SearchListChronoEltInTab( DBA_DYNFLD_STP *, int, DATETIME_T, DBA_DYNFLD_STP);
STATIC int FIN_SearchThirdChronoEltInTab(DBA_DYNFLD_STP *, int, DATETIME_T, DBA_DYNFLD_STP);

STATIC RET_CODE FIN_UnderExchRateList(ID_T,ID_T,DBA_DYNFLD_STP,DBA_DYNFLD_STP **,int *);        /* REF10531 - TEB - 040806 */
STATIC RET_CODE FIN_UnderPriceList(DBA_DYNFLD_STP,DBA_DYNFLD_STP,DBA_DYNFLD_STP **,int *, DBA_HIER_HEAD_STP); /* REF10531 - TEB - 040806 */
STATIC int		FIN_CompEstVol(double *,int,double*);
/*PMSTA7387*/
STATIC int FIN_CmpESLReconcOK(DBA_DYNFLD_STP *, DBA_DYNFLD_STP *);
/* REF10531 - TEB - 040806 */

STATIC FLAG_T FIN_ForceComputeInstrChrono(DBA_DYNFLD_STP, CHRONONAT_ENUM); /* PMSTA14879 - DDV - 120920 */

#define NO_COMPUTE 2 /* PMSTA14879 - DDV - 120920 - special flag value to add a new mode without adding a parameter */

/* PMSTA-60069 - Deepthi - 20240911 */
#define FX_CLASSIFY_RISKCASH 1
#define FX_CLASSIFY_RISKORIG 0

/************************************************************************
**      Functions
*************************************************************************/


/************************************************************************
**
**  Function    : FIN_IsTotaliser()
**
**  Description : determines if the market segment of a strategy element
**                is a totaliser or not.
**
**
**
**  Arguments   : hierHead: hierarchy pointer
**                eltPtr    (short) market segment pointer or strategy element pointer
**                objEn     object enum of the eltPtr
**                isTotFlg:     set to TRUE if market segment is a totaliser, FALSE elsewhere.
**
**
**
**
**  Return      : RET_SUCCEED or error code
**
**  Creation    : REF6082 - CSY - 010905
**  Modification  REF7395 - CSY - 020620: add argument mktStructPtr for market structure
**
*************************************************************************/
FLAG_T FIN_IsTotaliser(DBA_HIER_HEAD_STP   hierHead,
                                DBA_DYNFLD_STP      eltPtr, /* A_StratElt or S_MktSegt */
                                OBJECT_ENUM         objEn,  /* StratElt or MktSegt */
                                DBA_DYNFLD_STP      mktStructPtr)  /* REF7395 - CSY - 020620 */
{
    RET_CODE        ret = RET_SUCCEED;
    DBA_DYNFLD_STP  aGridSt     = NULLDYNST,
                    sMktSegtSt  = NULLDYNST;
    FLAG_T          aGridStAllocFlg=FALSE;
    ID_T            gridId=0;

    if(objEn == StratElt)
    {
        /* get from hierarchy the market segment of the strategy element */
        if ((ret = DBA_GetRecPtrFromHierById(hierHead,
                                                     GET_ID(eltPtr, A_StratElt_MktSegtId),
			                                         S_MktSegt,
                                                     &sMktSegtSt)) != RET_SUCCEED)
        {
            sMktSegtSt = NULLDYNST;
            return(FALSE);
        }
    }
    else if(objEn == DerivedStratElt)
    {
        /* get from hierarchy the market segment of the derived strategy element */
        if ((ret = DBA_GetRecPtrFromHierById(hierHead,
                                                     GET_ID(eltPtr, A_DerivedStratElt_MktSgtId),
			                                         S_MktSegt,
                                                     &sMktSegtSt)) != RET_SUCCEED)
        {
            sMktSegtSt = NULLDYNST;
            return(FALSE);
        }
    }
    else if(objEn == MktSegt)
    {
        sMktSegtSt = eltPtr;
    }



    if(objEn == MktSegt && mktStructPtr != NULL)
    {
        gridId = GET_ID(mktStructPtr, A_MktStruct_GridId);
    }
    else
    {
        if(sMktSegtSt != NULLDYNST)
        {
            if(IS_NULLFLD(sMktSegtSt, S_MktSegt_MktStructId) == TRUE)
            {
                /* standard grid */
                gridId = GET_ID(sMktSegtSt, S_MktSegt_GridId);
            }
            else
            {
                /* take the standard grid instead of the meta-grid (ref-grid) */
                if(mktStructPtr == NULLDYNST)
                {
                    if ((ret = DBA_GetRecPtrFromHierById(hierHead,
                                                             GET_ID(sMktSegtSt, S_MktSegt_MktStructId),
			                                                 A_MktStruct,
                                                             &mktStructPtr)) != RET_SUCCEED)
                    {
                        mktStructPtr = NULLDYNST;
                        return(FALSE);
                    }
                    gridId = GET_ID(mktStructPtr, A_MktStruct_GridId);
                }
            }
        }
    }

    /* REF7395 - CSY - 020620: get grid by id: from hier or by a DBA_Get2 */
	/* REF7420 - RAK - 021031 - New fct DBA_GetGridById */
	if (DBA_GetGridById(gridId,
						TRUE,
						&aGridStAllocFlg,
						&aGridSt,
						hierHead,
						UNUSED,
						UNUSED,
						UNUSED) != RET_SUCCEED)
	{
        aGridSt = NULLDYNST;
        return(FALSE);
	}

    if(aGridSt != NULLDYNST)
    {

        /* is the market segment a totaliser ? */
        if (sMktSegtSt != NULLDYNST &&
            (
            (IS_NULLFLD(aGridSt, A_Grid_OrdinateClassifId) == TRUE  && /* 1D grid */
            IS_NULLFLD(sMktSegtSt, S_MktSegt_AbcissaListId) == TRUE &&    /* totaliser of a 1D grid */
            IS_NULLFLD(sMktSegtSt, S_MktSegt_OrdinateListId) == TRUE)
                                    ||
            (IS_NULLFLD(aGridSt, A_Grid_OrdinateClassifId) == FALSE  && /* 2D grid */
             (IS_NULLFLD(sMktSegtSt, S_MktSegt_AbcissaListId) == TRUE ||    /* totaliser row (or column, or both) of a 2D grid */
             IS_NULLFLD(sMktSegtSt, S_MktSegt_OrdinateListId) == TRUE))
            ))
        {
            /* REF7395 - CSY - 020702: purify  */
            if (aGridStAllocFlg == TRUE)  { FREE_DYNST(aGridSt, A_Grid); }
            return (TRUE);
        }

        /* REF7395 - CSY - 020702: purify  */
        if (aGridStAllocFlg == TRUE) { FREE_DYNST(aGridSt, A_Grid);}
    }

    return (FALSE);
}

/************************************************************************
**
**  Function    :   FIN_EstVol()
**
**  Description :   This function calculates the estimated volatility of an instrument.
**                  (Inspiration from TECH_EstVol()
**
**  Arguments   :   advAVolaStp    pointer on arguments structure (AdvA_Vola)
**                  inputInstrPtr  pointer on instrument struct (or NULLDYNST)
**		        :   estVol         pointer to output estmated volatility
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   REF10531 - TEB - 040806
**
**  Modif       :
**
*************************************************************************/
RET_CODE FIN_EstVol(DBA_DYNFLD_STP advAVolaStp,
					DBA_DYNFLD_STP inputInstrPtr,
					PTR			   argHierHead,
					double         *estVol)
{
	double          *prices=(double*)NULL , num=1.0, denom=1.0;
	DATETIME_T      refDateTime;
	RET_CODE        ret=RET_SUCCEED,
					ret_code=RET_SUCCEED;
	DBA_DYNFLD_STP  instrChrono=NULLDYNST,
					currChrono=NULLDYNST,
		            underPtr=NULLDYNST,
					dimChronoPtr=NULLDYNST,
                    instrPtr=NULLDYNST,
		            termEvt=NULLDYNST,
					*priceTab=(DBA_DYNFLD_STP*)NULL,
		            *exchTab=(DBA_DYNFLD_STP*)NULL;
	char            found, annOk=FALSE;
	int             status=FALSE, priceNbr, exchNbr, volatPriceNbr,
		            i, j, min;
	ID_T            sysCurrId;
	ID_T	        instrId;
	FLAG_T	        allocOk=FALSE, allocUnderFlg=FALSE;
	CHRONO_ENUM     chrono;
	TINYINT_T		histoFreq;
	FREQUNIT_ENUM	histoFreqUnit;
	INT_T			histoReading;
	HISTOVOLARULE_ENUM	histoRule;


	DBA_HIER_HEAD_STP hierHead=(DBA_HIER_HEAD_STP)argHierHead;

	GEN_GetApplInfo(ApplSysCurrId, &sysCurrId);

	/*** Intrument ***/
	if (inputInstrPtr == NULLDYNST)
	{
		if (IS_NULLFLD(advAVolaStp, AdvA_Vola_InstrId) == TRUE ||
	        (ret = DBA_GetInstrById(GET_ID(advAVolaStp, AdvA_Vola_InstrId), FALSE, (FLAG_T*) &allocOk,
									&instrPtr, hierHead, UNUSED, UNUSED)) != RET_SUCCEED ||
		     GET_ID(advAVolaStp, AdvA_Vola_InstrId) <= 0 && instrPtr == NULLDYNST)
	    {
		    return(RET_FIN_ERR_INVDATA);
	    }
	}
	else
	{
	    instrPtr = inputInstrPtr;
	    allocOk = FALSE;
	}

	if (InstrNat_Option != (INSTRNAT_ENUM)GET_ENUM(instrPtr, A_Instr_NatEn))
	{
		if (allocOk == TRUE)
			FREE_DYNST(instrPtr, A_Instr);

		return(RET_SUCCEED);
	}

	/*** Reference date ***/
	if (IS_NULLFLD(advAVolaStp, AdvA_Vola_RefDate) == TRUE)
	{
		SET_DATE(advAVolaStp, AdvA_Vola_RefDate, DATE_CurrentDate());
	}

	refDateTime.date = GET_DATE(advAVolaStp, AdvA_Vola_RefDate);
	refDateTime.time = 0;

	if ((termEvt = ALLOC_DYNST(A_TermEvt)) == NULLDYNST)
	{
		if (allocOk == TRUE)
			FREE_DYNST(instrPtr, A_Instr);
	    MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
		return(RET_MEM_ERR_ALLOC);
	}

	if (DBA_GetTermEvt(instrPtr, refDateTime.date, termEvt) == RET_SUCCEED)
	{
		if ((ret = DBA_GetInstrById(GET_ID(termEvt, A_TermEvt_UnderlyInstrId), FALSE,
					                &allocUnderFlg, &underPtr, hierHead,
                                    UNUSED, UNUSED)) == RET_SUCCEED)
	    {
		    if ((INSTRNAT_ENUM) GET_ENUM(underPtr, A_Instr_NatEn) == InstrNat_CashAcct)
				chrono = Chrono_Curr;
		    else
				chrono = Chrono_Instr;
		}
		else
		{
			chrono = Chrono_None;
		}
	}
	else
		chrono = Chrono_None;

	FREE_DYNST(termEvt, A_TermEvt);

	if (chrono == Chrono_None)
	{
		if (allocOk == TRUE)
			FREE_DYNST(instrPtr, A_Instr);
		if (allocUnderFlg == TRUE)
			FREE_DYNST(underPtr, A_Instr);
		return(RET_FIN_ERR_INVDATA);
	}

	instrId = GET_ID(underPtr, A_Instr_Id);

	/* Test if optional parameters have been specified */
	if (IS_NULLFLD(advAVolaStp, AdvA_Vola_HistoRuleEn)		== FALSE ||
	    IS_NULLFLD(advAVolaStp, AdvA_Vola_HistoFreq)		== FALSE ||
	    IS_NULLFLD(advAVolaStp, AdvA_Vola_HistoFreqUnitEn)	== FALSE ||
	    IS_NULLFLD(advAVolaStp, AdvA_Vola_HistoReading)		== FALSE)
	{
		SET_FLAG(advAVolaStp, AdvA_Vola_OptioArgFlg, TRUE);
	}
	else
	{
		SET_FLAG(advAVolaStp, AdvA_Vola_OptioArgFlg, FALSE);
	}

	if (GET_FLAG(advAVolaStp, AdvA_Vola_OptioArgFlg) == TRUE)
	{
		SET_FLAG(advAVolaStp, AdvA_Vola_ForceCalcFlg, TRUE);
	}

	/*** Chronological data ***/
	if (GET_FLAG(advAVolaStp, AdvA_Vola_ForceCalcFlg) == FALSE)
	{
	    found = FALSE;

	    if (chrono == Chrono_Instr)
	    {
		    if ((instrChrono = ALLOC_DYNST(A_InstrChrono)) == NULLDYNST)
		    {
			    if (allocUnderFlg == TRUE)
					FREE_DYNST(underPtr, A_Instr);
			    if (allocOk == TRUE)
					FREE_DYNST(instrPtr, A_Instr);
	    		MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
			    return(RET_MEM_ERR_ALLOC);
		    }

		    /* Underly is received by database */
		    /* ------------------------------------------------- */
		    if ((dimChronoPtr = ALLOC_DYNST(Dim_InstrChrono)) == NULLDYNST)
		    {
			    FREE_DYNST(instrChrono, A_InstrChrono);
			    if (allocUnderFlg == TRUE)
					FREE_DYNST(underPtr, A_Instr);
			    if (allocOk == TRUE)
					FREE_DYNST(instrPtr, A_Instr);
	    	    MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
			    return(RET_MEM_ERR_ALLOC);
		    }

		    SET_ID(dimChronoPtr,       Dim_InstrChrono_InstrId,		instrId);
		    SET_DATETIME(dimChronoPtr, Dim_InstrChrono_RefDate,     refDateTime);
		    SET_ENUM(dimChronoPtr,     Dim_InstrChrono_NatEn,       ChronoNat_Volatility);
		    SET_FLAG(dimChronoPtr,     Dim_InstrChrono_ComputeFlg,  FALSE);

		    ret = FIN_InstrChrono(dimChronoPtr, underPtr, instrChrono, hierHead);

		    FREE_DYNST(dimChronoPtr, Dim_InstrChrono);

		    if (ret == RET_SUCCEED)
		    {
				/*
				** TGU-REF11704-060414-Use GET/SET_LONGAMOUNT since data type for field
				** instr_chrono.value_n has been changed from NUMBER to LONGAMOUNT.
				*/
		     	*estVol = GET_LONGAMOUNT(instrChrono, A_InstrChrono_Val);
			    found = TRUE;
		    }

			/* We did optimized an aborted calculation. */
		    if (ret == RET_DBA_ERR_DURING_FIN_CALC)
		    {
			    *estVol = 0.0;
			    found = TRUE;
		    }

		    FREE_DYNST(instrChrono, A_InstrChrono);
	    }
	    else if (chrono == Chrono_Curr)
	    {
		    if ((currChrono = ALLOC_DYNST(A_CurrChrono)) == NULLDYNST)
		    {
			    if (allocOk == TRUE)
					FREE_DYNST(instrPtr, A_Instr);
			    if (allocUnderFlg == TRUE)
					FREE_DYNST(underPtr, A_Instr);
	    	    MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
			    return(RET_MEM_ERR_ALLOC);
		    }

		    if ((ret=DBA_GetCurrChrono(GET_ID(underPtr, A_Instr_RefCurrId),
									   GET_ID(instrPtr, A_Instr_RefCurrId),
									   refDateTime,
									   CurrChronoNat_Volatility,
									   TimeDim_Last,
									   TRUE,
									   currChrono)) == RET_SUCCEED)
		    {
		     	*estVol = GET_NUMBER(currChrono, A_CurrChrono_Val);
			    found = TRUE;
		    }

		    FREE_DYNST(currChrono, A_CurrChrono);
	    }

	    if (found == TRUE) /* Else (not found) compute value */
	    {
		    if (allocOk == TRUE)
				FREE_DYNST(instrPtr, A_Instr);
		    if (allocUnderFlg == TRUE)
				FREE_DYNST(underPtr, A_Instr);
		    return(RET_SUCCEED);
	    }
	}

	/*** Currency ***/
	/* TEB : This test wasn't performed before, but it seems me strange !
	   I prefer to add the test */
	 if (IS_NULLFLD(advAVolaStp, AdvA_Vola_InstrCurrId) == TRUE)
	 {
		 COPY_DYNFLD(advAVolaStp, AdvA_Vola, AdvA_Vola_InstrCurrId,
					 instrPtr,	  A_Instr,	 A_Instr_RefCurrId);
	 }

	/*** Historical rule ***/
	if (IS_NULLFLD(advAVolaStp, AdvA_Vola_HistoRuleEn) == TRUE)
	{
		GEN_GetApplInfo(ApplHistoVolaRule, &histoRule);
		SET_ENUM(advAVolaStp, AdvA_Vola_HistoRuleEn, histoRule);
	}

	/*** Historical frequency ***/
	if (IS_NULLFLD(advAVolaStp, AdvA_Vola_HistoFreq) == TRUE)
	{
		GEN_GetApplInfo(ApplHistoVolaFreq, &histoFreq);
		SET_TINYINT(advAVolaStp, AdvA_Vola_HistoFreq, histoFreq);
	}

	/*** Historical frequency unit ***/
	if (IS_NULLFLD(advAVolaStp, AdvA_Vola_HistoFreqUnitEn) == TRUE)
	{
		GEN_GetApplInfo(ApplHistoVolaFreqUnit, &histoFreqUnit);
		SET_ENUM(advAVolaStp, AdvA_Vola_HistoFreqUnitEn, histoFreqUnit);
	}

	/*** Historical number of reading ***/
	if (IS_NULLFLD(advAVolaStp, AdvA_Vola_HistoReading) == TRUE)
	{
		GEN_GetApplInfo(ApplHistoVolaReading, &histoReading);
		SET_INT(advAVolaStp, AdvA_Vola_HistoReading, histoReading);
	}

	if (GET_INT(advAVolaStp, AdvA_Vola_HistoReading) < 3)
	{
	    MSG_SendMesg(RET_FIN_ERR_SCE_INVDATA, 1, FILEINFO,
		             "FIN_EstVol", GET_CODE(instrPtr, A_Instr_Cd), "Number of reading");
		ret_code = RET_FIN_ERR_SCE_INVDATA;
	}


	if (ret_code == RET_SUCCEED)
	{
		priceNbr = 0;
		exchNbr  = 0;

		/* Read prices according to parameters */
		ret = FIN_UnderPriceList(underPtr, advAVolaStp, &priceTab, &priceNbr, hierHead);

		/* error or less than 3 prices */
		if (ret != RET_SUCCEED && RET_GET_LEVEL(ret) == RET_LEV_ERROR)
		{
			if (allocOk == TRUE)
				FREE_DYNST(instrPtr, A_Instr);
			if (allocUnderFlg == TRUE)
				FREE_DYNST(underPtr, A_Instr);

			/* An error occured, so optimize its result. */
			if ((GET_FLAG(advAVolaStp, AdvA_Vola_ForceCalcFlg) == FALSE) &&
				(chrono == Chrono_Instr))
			{
				/* Memorize the error in data cache. */
				DBA_SetDimChrono((ID_T)instrId,				            /* InstrId */
						         refDateTime,				            /* RefDate */
						         (NUMBER_T)0,				            /* ValidPeriod */
						         (FLAG_T)TRUE,				            /* ValidPeriod IS NULL */
                                 (ID_T)0,                               /* Third party */ /* REF10598 - LJE - 041011 */
						         (CHRONONAT_ENUM)ChronoNat_Volatility,	/* Nature */
                                 (ID_T)0,                               /* Sub nature type */ /* REF10598 - LJE - 041011 */
						         (ID_T)0,				                /* CurrId */
						         (NUMBER_T)0,				            /* Val */
						         (int)RET_DBA_ERR_DURING_FIN_CALC,	    /* Return error number */
						         (char*)NULL);				            /* Error msg string */
			}

			return(RET_DBA_ERR_DURING_FIN_CALC);
		}

		/* Instrument value is 1, price number = 0 but it isn't error */
		if (priceNbr == 0 ||
		    GET_ID(underPtr, A_Instr_RefCurrId) != sysCurrId ||
		    GET_ID(instrPtr, A_Instr_RefCurrId) != sysCurrId)
		{
			/* Read exchange rates according to parameters */
		    if ((ret=FIN_UnderExchRateList(GET_ID(underPtr, A_Instr_RefCurrId),
										   GET_ID(instrPtr, A_Instr_RefCurrId),
										   advAVolaStp,
										   &exchTab,
										   &exchNbr)) != RET_SUCCEED)
			{
			    if (allocOk == TRUE)
					FREE_DYNST(instrPtr, A_Instr);
			    if (allocUnderFlg == TRUE)
					FREE_DYNST(underPtr, A_Instr);

				/* An error occured, so optimize its result. */
			    if ((GET_FLAG(advAVolaStp, AdvA_Vola_ForceCalcFlg) == FALSE) &&
				    (chrono == Chrono_Instr))
			    {
					/* Memorize the error in data cache. */
				    DBA_SetDimChrono((ID_T)instrId,				        /* InstrId */
						             refDateTime,				        /* RefDate */
						            (NUMBER_T)0,				        /* ValidPeriod */
						            (FLAG_T)TRUE,				        /* ValidPeriod IS NULL */
                                    (ID_T)0,                            /* Third party */ /* REF10598 - LJE - 041011 */
						            (CHRONONAT_ENUM)ChronoNat_Volatility,/* Nature */
                                    (ID_T)0,                            /* Sub nature type */ /* REF10598 - LJE - 041011 */
						            (ID_T)0,			                /* CurrId */
						            (NUMBER_T)0,				        /* Val */
						            (int)RET_DBA_ERR_DURING_FIN_CALC,	/* Return error number */
						            (char*)NULL);				        /* Error msg string */
			    }

			    return(RET_DBA_ERR_DURING_FIN_CALC);
			}

		}

		/* Instrument value is 1, price nbr = 0 but it isn't error */
		if (priceNbr == 0)
		{
		    /* underly, option and system currency identical */
		    if (exchNbr == 0)
		    {
			    /* Volatility is 0 */
			    if (allocOk == TRUE)
					FREE_DYNST(instrPtr, A_Instr);
			    if (allocUnderFlg == TRUE)
					FREE_DYNST(underPtr, A_Instr);

				/* An error occured, so optimize its result. */
			    if ((GET_FLAG(advAVolaStp, AdvA_Vola_ForceCalcFlg) == FALSE) &&
			        (chrono == Chrono_Instr))
			    {
					/* Memorize the error in data cache. */
				    DBA_SetDimChrono((ID_T)instrId,				            /* InstrId */
						             refDateTime,				            /* RefDate */
						             (NUMBER_T)0,				            /* ValidPeriod */
						             (FLAG_T)TRUE,				            /* ValidPeriod IS NULL */
                                     (ID_T)0,                               /* Third party */ /* REF10598 - LJE - 041011 */
						             (CHRONONAT_ENUM)ChronoNat_Volatility,	/* Nature */
                                     (ID_T)0,                               /* Sub nature type */ /* REF10598 - LJE - 041011 */
						             (ID_T)0,				                /* CurrId */
						             (NUMBER_T)0,				            /* Val */
						             (int)RET_DBA_ERR_DURING_FIN_CALC,	    /* Return error number */
						             (char*)NULL);				            /* Error msg string */
			    }

			    return(RET_DBA_ERR_DURING_FIN_CALC);
		    }
		    else
		    {
			    /* volatility is exchange rate */
			    volatPriceNbr = exchNbr;

			    /* Init prices table */
			    if ((prices = (double*) CALLOC(volatPriceNbr, sizeof(double))) == (double*)NULL)
			    {
			        DBA_FreeDynStTab(exchTab, exchNbr, Freq_ExchRate);
			        if (allocOk == TRUE)
						FREE_DYNST(instrPtr, A_Instr);
			        if (allocUnderFlg == TRUE)
						FREE_DYNST(underPtr, A_Instr);
			        MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
			        return(RET_MEM_ERR_ALLOC);
			    }

			    for (i=0; i<volatPriceNbr; i++)
			    {
			        prices[i] = GET_EXCHANGE(exchTab[i], Freq_ExchRate_ExchRate);
			    }
		    }
		}
		else /* Instrument is quoted */
		{
		    /* underly, option and system currency identical */
		    if (exchNbr == 0)
		    {
			    /* volatility is instrument price */
			    volatPriceNbr = priceNbr;

			    /* Init prices table */
			    if ((prices = (double*) CALLOC(volatPriceNbr, sizeof(double))) == (double*)NULL)
			    {
			        DBA_FreeDynStTab(priceTab,priceNbr,Freq_InstrPrice);
			        if (allocOk == TRUE)
						FREE_DYNST(instrPtr, A_Instr);
			        if (allocUnderFlg == TRUE)
						FREE_DYNST(underPtr, A_Instr);
			        MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
			        return(RET_MEM_ERR_ALLOC);
			    }

			    for (i=0; i<volatPriceNbr; i++)
			    {
			        prices[i] = GET_PRICE(priceTab[i], Freq_InstrPrice_Price);
			    }
		    }
		    else /* volatility is price and exchange combination */
		    {
	    		/* Prices number is the minimum between exchange  */
			    /* rates nbr and price nbr (if all records match) */
	    		min = (priceNbr > exchNbr) ? exchNbr : priceNbr;

	    	 	if ((prices = (double *) CALLOC(min, sizeof(double)))==(double*)NULL)
			    {
			        DBA_FreeDynStTab(priceTab,priceNbr,Freq_InstrPrice);
			        DBA_FreeDynStTab(exchTab, exchNbr, Freq_ExchRate);
			        if (allocOk == TRUE)
						FREE_DYNST(instrPtr, A_Instr);
			        if (allocUnderFlg == TRUE)
						FREE_DYNST(underPtr, A_Instr);
			        MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
			        return(RET_MEM_ERR_ALLOC);
			    }

	    	    /* Verify date matching and update prices table */
	    		for (volatPriceNbr=0, i=0, j=0; i<priceNbr && j<exchNbr; i++, j++)
	    		{
	    		    if (DATETIME_CMP(GET_DATETIME(priceTab[i],Freq_InstrPrice_RequestDate),
		       						 GET_DATETIME(exchTab[j], Freq_ExchRate_RequestDate)) == 0)
	    		    {
				        prices[volatPriceNbr] = GET_PRICE(priceTab[i], Freq_InstrPrice_Price) *
			                                    GET_EXCHANGE(exchTab[j], Freq_ExchRate_ExchRate);
		    		    ++volatPriceNbr;
			        }
			    }

			    if (volatPriceNbr < 3)
			    {
					MSG_SendMesg(RET_FIN_ERR_SCE_INVDATA, 1, FILEINFO,
								 "FIN_EstVol", GET_CODE(instrPtr, A_Instr_Cd), "price number");
			        DBA_FreeDynStTab(priceTab,priceNbr,Freq_InstrPrice);
			        DBA_FreeDynStTab(exchTab, exchNbr, Freq_ExchRate);
			        if (allocOk == TRUE)
						FREE_DYNST(instrPtr, A_Instr);
			        if (allocUnderFlg == TRUE)
						FREE_DYNST(underPtr, A_Instr);
			        FREE(prices);

				    /* An error occured, so optimize its result. */
			        if ((GET_FLAG(advAVolaStp, AdvA_Vola_ForceCalcFlg) == FALSE) &&
				        (chrono == Chrono_Instr))
			        {
					    /* Memorize the error in data cache. */
				        DBA_SetDimChrono((ID_T)instrId,				            /* InstrId */
						                 refDateTime,				            /* RefDate */
						                 (NUMBER_T)0,				            /* ValidPeriod */
						                 (FLAG_T)TRUE,				            /* ValidPeriod IS NULL */
                                         (ID_T)0,                               /* Third party */ /* REF10598 - LJE - 041011 */
						                 (CHRONONAT_ENUM)ChronoNat_Volatility,	/* Nature */
                                         (ID_T)0,                               /* Sub nature type */ /* REF10598 - LJE - 041011 */
   						                 (ID_T)0,				                /* CurrId */
						                 (NUMBER_T)0,				            /* Val */
						                 (int)RET_DBA_ERR_DURING_FIN_CALC,	    /* Return error number */
						                 (char*)NULL);				            /* Error msg string */
			        }

			        return(RET_FIN_ERR_SCE_INVDATA);
			    }
	        }
		}

		if (exchNbr != 0)
			DBA_FreeDynStTab(exchTab, exchNbr, Freq_ExchRate);

		if (priceNbr != 0)
			DBA_FreeDynStTab(priceTab, priceNbr, Freq_InstrPrice);

		status = TRUE;

		switch ((HISTOVOLARULE_ENUM) GET_ENUM(advAVolaStp, AdvA_Vola_HistoRuleEn))
		{
			case HistoVolaRule_DfltPrices :
			case HistoVolaRule_ClosePrices :
				status = FIN_CompEstVol(prices, volatPriceNbr, estVol);
				break;

			case HistoVolaRule_HighLowPrices :
			case HistoVolaRule_HighLowClosePrices :
				status = FALSE;
				break;
		}

	    if (status == FALSE)
	    	MSG_SendMesg(RET_FIN_ERR_SCE_INVDATA, 2, FILEINFO,
			             "FIN_EstVol", GET_CODE(instrPtr, A_Instr_Cd));
		else
		{
		    /* Annualise computed volatility */
		    switch ((FREQUNIT_ENUM) GET_ENUM(advAVolaStp, AdvA_Vola_HistoFreqUnitEn))
		    {
		    case FreqUnit_Day :
			    num   = 254.0; /* openend days in one year */
			    denom = GET_TINYINT(advAVolaStp, AdvA_Vola_HistoFreq);
			    annOk = TRUE;
			    break;

		    case FreqUnit_Week :
			    num   = 52.0;  /* openend week in one year */
			    denom = GET_TINYINT(advAVolaStp, AdvA_Vola_HistoFreq);
			    annOk = TRUE;
			    break;

		    case FreqUnit_Month :
			    if (GET_TINYINT(advAVolaStp, AdvA_Vola_HistoFreq) != 12)
			    {
			        num   = 12.0;
			        denom = GET_TINYINT(advAVolaStp, AdvA_Vola_HistoFreq);
			        annOk = TRUE;
			    }
			    else
			        annOk = FALSE;
			    break;

		    case FreqUnit_Quarter :
			    if (GET_TINYINT(advAVolaStp, AdvA_Vola_HistoFreq) != 4)
			    {
			        num   = 12.0;
			        denom = GET_TINYINT(advAVolaStp, AdvA_Vola_HistoFreq)*3;
			        annOk = TRUE;
			    }
			    else
			        annOk = FALSE;
			    break;

		    case FreqUnit_Semester :
			    if (GET_TINYINT(advAVolaStp, AdvA_Vola_HistoFreq) != 2)
			    {
			        num   = 12.0;
			        denom = GET_TINYINT(advAVolaStp, AdvA_Vola_HistoFreq)*6;
			        annOk = TRUE;
			    }
			    else
			        annOk = FALSE;
			    break;

		    case FreqUnit_Year :
			    if (GET_TINYINT(advAVolaStp, AdvA_Vola_HistoFreq) != 1)
			    {
			        num = 12.0;
			        denom = GET_TINYINT(advAVolaStp, AdvA_Vola_HistoFreq);
			        annOk = TRUE;
			    }
			    else
			        annOk = FALSE;
			    break;

		    default :
			    denom = 0;
			    num = 0.0;
			    annOk = FALSE;
		    }

		    if (annOk == TRUE)
		    {
		        (*estVol) = (*estVol) * sqrt((num/denom));

				if ((chrono == Chrono_Instr) &&
                    (GET_FLAG(advAVolaStp, AdvA_Vola_ForceCalcFlg) == FALSE))
			    {
				    DBA_SetDimChrono((ID_T)instrId,				    /* InstrId */
						             refDateTime,				    /* RefDate */
						             (NUMBER_T)0,				    /* ValidPeriod */
						             (FLAG_T)TRUE,				    /* ValidPeriod IS NULL */
                                     (ID_T)0,                       /* Third party */ /* REF10598 - LJE - 041011 */
						             (CHRONONAT_ENUM)ChronoNat_Volatility,	/* Nature */
                                     (ID_T)0,                               /* Sub nature type */ /* REF10598 - LJE - 041011 */
						             (ID_T)0,				        /* CurrId */
						             (NUMBER_T)(*estVol),			/* Val */
						             (int)0,				        /* Return error number */
						             (char*)NULL);				    /* Error msg string */
			    }
		    }
		}
	}

	/* If an error occured, lets optimize it. */
	if ((ret_code != RET_SUCCEED || status == FALSE || annOk == FALSE) &&
	    (GET_FLAG(advAVolaStp, AdvA_Vola_ForceCalcFlg) == FALSE) &&
	    (chrono == Chrono_Instr))
	{
		/* Memorize the error in data cache. */
		DBA_SetDimChrono((ID_T)instrId,				            /* InstrId */
				         refDateTime,				            /* RefDate */
				         (NUMBER_T)0,				            /* ValidPeriod */
				         (FLAG_T)TRUE,				            /* ValidPeriod IS NULL */
                         (ID_T)0,                               /* Third party */ /* REF10598 - LJE - 041011 */
				         (CHRONONAT_ENUM)ChronoNat_Volatility,	/* Nature */
                         (ID_T)0,                               /* Sub nature type */ /* REF10598 - LJE - 041011 */
				         (ID_T)0,				                /* CurrId */
				         (NUMBER_T)0,				            /* Val */
				         (int)RET_DBA_ERR_DURING_FIN_CALC,	    /* Return error number */
				         (char*)NULL);				            /* Error msg string */
	}

    if (prices != (double *) NULL)
		FREE(prices);

	if (allocUnderFlg == TRUE)
		FREE_DYNST(underPtr, A_Instr);

	if (allocOk == TRUE)
		FREE_DYNST(instrPtr, A_Instr);

	return(ret_code);
}


/************************************************************************
**
**  Function    :   FIN_Conv()
**
**  Description :   This function calculates the convexity of an instrument.
**
**  Arguments	:   argStp       - pointer to input arguments structure
**              :   forceCalcFlg - flag to force compute without chrono
**		        :   instrStp     - pointer to current instrument received
**     		    :   extPosPtr    - pointer to extpos structure
**		        :   hierHead     - pointer to hierarchy
**		        :   sceOutStp    - pointer to output data structure
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   REF9082 - TEB - 030530
**
**  Modif       :   REF9082 - TEB - 030807 : Add test on AdvA_Arg_RedemptionPrice
**                  REF10461 - TEB - 040804
**
*************************************************************************/
RET_CODE FIN_Conv(DBA_DYNFLD_STP   advArgStp,
                  FLAG_T           forceCalcFlg,
                  DBA_DYNFLD_STP   instrStp,
                  DBA_DYNFLD_STP   extPosSt,
                  PTR              hierHead,
                  DBA_DYNFLD_STP   advAStp)
{
    INSTRNAT_ENUM   instrNatInstr = InstrNat_None;
    RET_CODE        retCd = RET_SUCCEED;
    DBA_DYNFLD_STP  instrChrono=NULLDYNST, dimChronoPtr=NULLDYNST;
    DATETIME_T      refDateTime;
	FLAG_T          firstComputeFlg=FALSE;
	ID_T            domainQuoteValRuleId = 0;
	DBA_DYNFLD_STP  domainPtr=NULLDYNST;

	/* REF10529 - TEB - 040826 */
	/* Default value is current date !! */
	if (IS_NULLFLD(advArgStp, AdvA_Arg_RefDate)==TRUE)
	{
		SET_DATE(advArgStp, AdvA_Arg_RefDate, DATE_CurrentDate());
	}

    refDateTime.date = GET_DATE(advArgStp, AdvA_Arg_RefDate);
	refDateTime.time = 0;


    /* Get nature of the instrument */
    instrNatInstr = (INSTRNAT_ENUM)GET_ENUM(instrStp, A_Instr_NatEn);

	/* Check that instrument is a bond, a convertible bond, a cum option bond */
	if (instrNatInstr != InstrNat_Bond &&
	    instrNatInstr != InstrNat_ConvertBond &&
	    instrNatInstr != InstrNat_CumOption)
	{
	    return(RET_SUCCEED);
	}

    /* REF9082 - TEB - 030807 : Add test on AdvA_Arg_RedemptionPrice */
	/* REF10461 - TEB - 040804 */
	/* Compute Redemption Price in SCE functions, because of iorevent priority */
/*
    if (IS_NULLFLD(advArgStp, AdvA_Arg_RedemptionPrice)== TRUE)
    {
        if (IS_NULLFLD(instrStp, A_Instr_RedempQuote)== TRUE)
        {
            MSG_SendMesg(RET_GEN_ERR_PERSONAL, 6, FILEINFO, "No redemption quote for convexity computation !! Instrument :",
                         GET_CODE(instrStp, A_Instr_Cd));
            return(RET_SUCCEED);
        }
        else
        {
            COPY_DYNFLD(advArgStp, AdvA_Arg, AdvA_Arg_RedemptionPrice, instrStp, A_Instr, A_Instr_RedempQuote );
        }
    }
*/

    /* Only use flag3 if instrument is not generic and no further parameteres */
	if (GET_FLAG(instrStp, A_Instr_GenericFlg) == TRUE)
		forceCalcFlg = TRUE;

	/* PMSTA14879 - DDV - 120920 - Check if computation must be forced */
	if (forceCalcFlg == FALSE && FIN_ForceComputeInstrChrono(instrStp, ChronoNat_ModDura) == TRUE)
	{
		DBA_DYNFLD_STP  pricePtr = ALLOC_DYNST(A_InstrPrice);

		if (pricePtr != NULLDYNST)
		{
			/* PMSTA15697 - DDV - 121227 - But force computation only if price exists */
			if (FIN_InstrPrice(GET_ID(instrStp, A_Instr_Id),
							   instrStp,
							   refDateTime,
							   NULLDYNST,
							   (ID_T)0,
							   NULL,
							   NULLDYNST,
							   NULLDYNST,
							   (DBA_HIER_HEAD_STP)hierHead,
							   pricePtr,
							   TRUE) == RET_SUCCEED)
			{
				firstComputeFlg = TRUE;
				forceCalcFlg = TRUE;
			}
		}
		FREE_DYNST(pricePtr, A_InstrPrice);
	}

	if (forceCalcFlg == NO_COMPUTE)
	{
		firstComputeFlg = TRUE;
		forceCalcFlg = FALSE;
	}

	/* Chronological data */
    if (forceCalcFlg == FALSE)
	{
	    if ((instrChrono = ALLOC_DYNST(A_InstrChrono)) == NULLDYNST)
	    {
		    MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
		    return(RET_MEM_ERR_ALLOC);
	    }

	    if ((dimChronoPtr = ALLOC_DYNST(Dim_InstrChrono)) == NULLDYNST)
	    {
		    FREE_DYNST(instrChrono, A_InstrChrono);
	    	MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
		    return(RET_MEM_ERR_ALLOC);
	    }

	    /* Verify first in memory with negativ identifier */
	    SET_ID(dimChronoPtr,       Dim_InstrChrono_InstrId, GET_ID(instrStp, A_Instr_Id));
	    SET_DATETIME(dimChronoPtr, Dim_InstrChrono_RefDate, refDateTime);
	    SET_ENUM(dimChronoPtr,     Dim_InstrChrono_NatEn,   ChronoNat_Convexity);

		/* PMSTA14879 - DDV - 120920 - Add domain's valuation rule as criteria for cache usage */
		if ((domainPtr = DBA_GetDomainPtr(NO_VALUE)) != NULLDYNST &&
			(domainQuoteValRuleId = GET_ID(domainPtr, A_Domain_QuoteValRuleId)) != 0)
		{
			SET_ID(dimChronoPtr, Dim_InstrChrono_DomQuoteValRuleId, domainQuoteValRuleId);
		}

	    if ((retCd = DBA_GetDimChrono(dimChronoPtr, instrChrono)) == RET_SUCCEED)
	    {
            COPY_DYNFLD(advAStp, A_AdvA, A_AdvA_Conv, instrChrono, A_InstrChrono, A_InstrChrono_Val);
		    FREE_DYNST(instrChrono, A_InstrChrono);
		    FREE_DYNST(dimChronoPtr, Dim_InstrChrono);
		    return(retCd);
	    }
	    else if (retCd == RET_DBA_ERR_DURING_FIN_CALC)	/* aborted calculation. */
	    {
	       	FREE_DYNST(instrChrono, A_InstrChrono);
		    FREE_DYNST(dimChronoPtr, Dim_InstrChrono);
		    return(retCd);
	    }

	    /* FIN_InstrChrono read database too */
	    COPY_DYNFLD(dimChronoPtr, Dim_InstrChrono, Dim_InstrChrono_InstrId, instrStp, A_Instr, A_Instr_Id);
	    SET_FLAG(dimChronoPtr,     Dim_InstrChrono_ComputeFlg,  FALSE);

	    retCd = FIN_InstrChrono(dimChronoPtr, instrStp, instrChrono, (DBA_HIER_HEAD_STP) hierHead);

	    if (retCd == RET_SUCCEED)
	    {
            COPY_DYNFLD(advAStp, A_AdvA, A_AdvA_Conv, instrChrono, A_InstrChrono, A_InstrChrono_Val);
	        FREE_DYNST(instrChrono, A_InstrChrono);
	        FREE_DYNST(dimChronoPtr, Dim_InstrChrono);
		    return(retCd);
	    }

	    /* We did optimized an aborted calculation. */
	    if (retCd == RET_DBA_ERR_DURING_FIN_CALC)
	    {
	        FREE_DYNST(instrChrono, A_InstrChrono);
	        FREE_DYNST(dimChronoPtr, Dim_InstrChrono);
		    return(retCd);
	    }

	    /* Not found, compute value */
	    FREE_DYNST(instrChrono, A_InstrChrono);
	    FREE_DYNST(dimChronoPtr, Dim_InstrChrono);
	}

	/* PMSTA14879 - DDV - 120920 - If priorty is to compute and it the second call for db access, don't try to compute it a second time */
	if (firstComputeFlg == TRUE && forceCalcFlg == FALSE)
	{
		SET_NUMBER(advAStp, A_AdvA_Dura, 0.0);
	    return(retCd);
	}

    /* Compute convexity */
    retCd = SCE_ComputeCurrKeyWord(advArgStp, instrStp,
			 	    (DBA_DYNFLD_STP) extPosSt, hierHead, advAStp);

    /* If necessary, write into cach */
    if (forceCalcFlg == FALSE)
    {
	    if (retCd != RET_SUCCEED)
		    /* Memorize the error in data cache. */
		    DBA_SetDimChrono((ID_T)GET_ID(instrStp, A_Instr_Id), /* InstrId */
				             refDateTime,				         /* RefDate */
				             (NUMBER_T)0,				         /* ValidPeriod */
				             (FLAG_T)TRUE,				         /* ValidPeriod IS NULL */
                             (ID_T)0,                            /* Third party */ /* REF10598 - LJE - 041011 */
				             (CHRONONAT_ENUM)ChronoNat_Convexity,/* Nature */
                             (ID_T)0,                               /* Sub nature type */ /* REF10598 - LJE - 041011 */
				             (ID_T)0,				             /* CurrId */
				             (NUMBER_T)0,				         /* Val */
				             (int)RET_DBA_ERR_DURING_FIN_CALC,	 /* Return error number */
				             (char*)NULL);				         /* Error msg string */

        else
		    DBA_SetDimChrono((ID_T)GET_ID(instrStp, A_Instr_Id),         /* InstrId */
				             refDateTime,				                 /* RefDate */
				             (NUMBER_T)0,				                 /* ValidPeriod */
				             (FLAG_T)TRUE,				                 /* ValidPeriod IS NULL */
                             (ID_T)0,                                    /* Third party */ /* REF10598 - LJE - 041011 */
				             (CHRONONAT_ENUM)ChronoNat_Convexity,	     /* Nature */
                             (ID_T)0,                               /* Sub nature type */ /* REF10598 - LJE - 041011 */
				             (ID_T)0,				                     /* CurrId */
				             (NUMBER_T)GET_NUMBER(advAStp, A_AdvA_Conv), /* Val */
				             (int)0, 				                     /* Return error number */
				             (char*)NULL);				                 /* Error msg string */

    }

	/* PMSTA-14879 - DDV - 120920 - compute don't succeed without check in db, call back and force db access only */
	if (firstComputeFlg == TRUE && forceCalcFlg == TRUE && retCd != RET_SUCCEED)
	{
		retCd = FIN_Conv(advArgStp, NO_COMPUTE, instrStp, extPosSt, hierHead, advAStp);
	}

    return(retCd);
}

/************************************************************************
**
**  Function    :   FIN_MDura()
**
**  Description :   This function calculates the mod. duration of an instrument.
**
**  Arguments	:   argStp       - pointer to input arguments structure
**              :   forceCalcFlg - flag to force compute without chrono
**		        :   instrStp     - pointer to current instrument received
**     		    :   extPosPtr    - pointer to extpos structure
**		        :   hierHead     - pointer to hierarchy
**		        :   sceOutStp    - pointer to output data structure
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   REF9082 - TEB - 030528
**
**  Modif       :   REF9082 - TEB - 030807 : Add test on AdvA_Arg_RedemptionPrice
**                  REF9675 - TEB - 031118 : error code
**                  REF10461 - TEB - 040804
**
*************************************************************************/
RET_CODE FIN_MDura(DBA_DYNFLD_STP   advArgStp,
                   FLAG_T           forceCalcFlg,
                   DBA_DYNFLD_STP   instrStp,
                   DBA_DYNFLD_STP   extPosSt,
                   DBA_HIER_HEAD_STP hierHead,
                   DBA_DYNFLD_STP   advAStp)
{
    INSTRNAT_ENUM   instrNatInstr = InstrNat_None;
    SUBNAT_ENUM     instrSubNat   = SubNat_None;
    RET_CODE        retCd = RET_SUCCEED;
    DBA_DYNFLD_STP  instrChronoPtr=NULLDYNST, dimChronoPtr=NULLDYNST, incomePtr=NULLDYNST;
    DATETIME_T      refDateTime;
    SCE_ADVA_ARG_ST	*advaArgForYtmStp=(SCE_ADVA_ARG_ST*)NULL;
    double          ytm=0.0, mdura=0.0, freq, denom=0.0;
	FLAG_T          firstComputeFlg=FALSE;
	ID_T            domainQuoteValRuleId = 0;
	DBA_DYNFLD_STP  domainPtr=NULLDYNST;

	/* REF10529 - TEB - 040826 */
	/* Default value is current date !! */
	if (IS_NULLFLD(advArgStp, AdvA_Arg_RefDate)==TRUE)
	{
		SET_DATE(advArgStp, AdvA_Arg_RefDate, DATE_CurrentDate());
	}

    /* REF10089 - TEB - 040322 */
    /* Use the instrument's begin date if it is > than computation date */
    if (IS_NULLFLD(instrStp,  A_Instr_BeginDate)  == FALSE &&
        DATE_Cmp(GET_DATE(advArgStp, AdvA_Arg_RefDate), GET_DATE(instrStp, A_Instr_BeginDate)) < 0)
    {
        COPY_DYNFLD(advArgStp, AdvA_Arg, AdvA_Arg_RefDate, instrStp, A_Instr, A_Instr_BeginDate);
        COPY_DYNFLD(advArgStp, AdvA_Arg, AdvA_Arg_Date,    instrStp, A_Instr, A_Instr_BeginDate);
    }

    refDateTime.date = GET_DATE(advArgStp, AdvA_Arg_RefDate);
	refDateTime.time = 0;


    /* Get nature of the instrument */
    instrNatInstr = (INSTRNAT_ENUM)GET_ENUM(instrStp, A_Instr_NatEn);
    instrSubNat   = (SUBNAT_ENUM)  GET_ENUM(instrStp, A_Instr_SubNatEn);

	/* compute only these instruments */
	if ((InstrNat_FundShare     != instrNatInstr &&			/* PMSTA-11959 - RAK - 110530 - Read stored chrono */
	     InstrNat_Idx           != instrNatInstr &&			/* PMSTA-11959 - RAK - 110530 - Read stored chrono */
		 InstrNat_Bond          != instrNatInstr &&
	     InstrNat_MoneyMkt      != instrNatInstr &&
	     InstrNat_Discount      != instrNatInstr &&
	     InstrNat_CumOption     != instrNatInstr &&
         InstrNat_ConvertBond   != instrNatInstr) ||
        (SubNat_FRN             == instrSubNat)
	   )
	{
	    return(RET_SUCCEED);
	}

    /* Only use flag3 if instrument is not generic and no further parameteres */
	if (GET_FLAG(instrStp, A_Instr_GenericFlg) == TRUE)
		forceCalcFlg = TRUE;

	/* PMSTA14879 - DDV - 120920 - Check if computation must be forced */
	if (forceCalcFlg == FALSE && FIN_ForceComputeInstrChrono(instrStp, ChronoNat_ModDura) == TRUE)
	{
		DBA_DYNFLD_STP  pricePtr = ALLOC_DYNST(A_InstrPrice);

		if (pricePtr != NULLDYNST)
		{
			/* PMSTA15697 - DDV - 121227 - But force computation only if price exists */
			if (FIN_InstrPrice(GET_ID(instrStp, A_Instr_Id),
							   instrStp,
							   refDateTime,
							   NULLDYNST,
							   (ID_T)0,
							   NULL,
							   NULLDYNST,
							   NULLDYNST,
							   hierHead,
							   pricePtr,
							   TRUE) == RET_SUCCEED)
			{
				firstComputeFlg = TRUE;
				forceCalcFlg = TRUE;
			}
		}
		FREE_DYNST(pricePtr, A_InstrPrice);
	}

	if (forceCalcFlg == NO_COMPUTE)
	{
		firstComputeFlg = TRUE;
		forceCalcFlg = FALSE;
	}

	/* Chronological data */
    if (forceCalcFlg == FALSE)
	{
	    if ((instrChronoPtr = ALLOC_DYNST(A_InstrChrono)) == NULLDYNST)
	    {
		    MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
		    return(RET_MEM_ERR_ALLOC);
	    }

	    if ((dimChronoPtr = ALLOC_DYNST(Dim_InstrChrono)) == NULLDYNST)
	    {
		    FREE_DYNST(instrChronoPtr, A_InstrChrono);
	    	MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
		    return(RET_MEM_ERR_ALLOC);
	    }

	    /* Verify first in memory with negativ identifier */
	    SET_ID(dimChronoPtr,       Dim_InstrChrono_InstrId, GET_ID(instrStp, A_Instr_Id));
	    SET_DATETIME(dimChronoPtr, Dim_InstrChrono_RefDate, refDateTime);
	    SET_ENUM(dimChronoPtr,     Dim_InstrChrono_NatEn,   ChronoNat_ModDura);

		/* PMSTA14879 - DDV - 120920 - Add domain's valuation rule as criteria for cache usage */
		if ((domainPtr = DBA_GetDomainPtr(NO_VALUE)) != NULLDYNST &&
			(domainQuoteValRuleId = GET_ID(domainPtr, A_Domain_QuoteValRuleId)) != 0)
		{
			SET_ID(dimChronoPtr, Dim_InstrChrono_DomQuoteValRuleId, domainQuoteValRuleId);
		}

	    if ((retCd = DBA_GetDimChrono(dimChronoPtr, instrChronoPtr)) == RET_SUCCEED)
	    {
            COPY_DYNFLD(advAStp, A_AdvA, A_AdvA_Dura, instrChronoPtr, A_InstrChrono, A_InstrChrono_Val);
		    FREE_DYNST(instrChronoPtr, A_InstrChrono);
		    FREE_DYNST(dimChronoPtr, Dim_InstrChrono);
		    return(retCd);
	    }
	    else if (retCd == RET_DBA_ERR_DURING_FIN_CALC)	/* aborted calculation. */
	    {
	       	FREE_DYNST(instrChronoPtr, A_InstrChrono);
		    FREE_DYNST(dimChronoPtr, Dim_InstrChrono);
		    return(retCd);
	    }

	    /* FIN_InstrChrono read database too */
	    COPY_DYNFLD(dimChronoPtr, Dim_InstrChrono, Dim_InstrChrono_InstrId, instrStp, A_Instr, A_Instr_Id);
	    SET_FLAG(dimChronoPtr,     Dim_InstrChrono_ComputeFlg,  FALSE);

	    retCd = FIN_InstrChrono(dimChronoPtr, instrStp, instrChronoPtr, hierHead);

	    if (retCd == RET_SUCCEED)
	    {
            COPY_DYNFLD(advAStp, A_AdvA, A_AdvA_Dura, instrChronoPtr, A_InstrChrono, A_InstrChrono_Val);
	        FREE_DYNST(instrChronoPtr, A_InstrChrono);
	        FREE_DYNST(dimChronoPtr, Dim_InstrChrono);
		    return(retCd);
	    }

	    /* We did optimized an aborted calculation. */
	    if (retCd == RET_DBA_ERR_DURING_FIN_CALC)
	    {
	        FREE_DYNST(instrChronoPtr, A_InstrChrono);
	        FREE_DYNST(dimChronoPtr, Dim_InstrChrono);
		    return(retCd);
	    }

		/* Not found, compute value */
	    FREE_DYNST(instrChronoPtr, A_InstrChrono);
	    FREE_DYNST(dimChronoPtr, Dim_InstrChrono);
	}

	/* PMSTA-11959 - RAK - 110530 */
	/* Don't compute duration (read only stored chrono) */
	/* if nothing found, add the 0 value in for next research */
	if (InstrNat_FundShare == instrNatInstr ||
	    InstrNat_Idx  == instrNatInstr)
	{
		SET_NUMBER(advAStp, A_AdvA_Dura, 0.0);
		return(RET_SUCCEED);
	}

	/* PMSTA14879 - DDV - 120920 - If priorty is to compute and it the second call for db access, don't try to compute it a second time */
	if (firstComputeFlg == TRUE && forceCalcFlg == FALSE)
	{
		SET_NUMBER(advAStp, A_AdvA_Dura, 0.0);
	    return(retCd);
	}

    /* Compute duration */
    retCd = FIN_Dura(advArgStp, forceCalcFlg, instrStp,
			 	    (DBA_DYNFLD_STP) extPosSt, hierHead, advAStp);

    /* Compute mod. duration */
    if (retCd == RET_SUCCEED)
    {
        /* Search  ytm */
        if ((advaArgForYtmStp = (SCE_ADVA_ARG_ST*)CALLOC(1, sizeof(SCE_ADVA_ARG_ST))) == NULL)
        {
            return(RET_MEM_ERR_ALLOC /*SCE_ALLOC_ERROR*/); /* REF9675 - TEB - 031118 : error code */
        }


	    /* Create input structure. */
	    if ((advaArgForYtmStp->argStp = ALLOC_DYNST(AdvA_Arg)) == NULLDYNST)
        {
            FREE(advaArgForYtmStp);
		    return(RET_MEM_ERR_ALLOC /*RET_SUCCEED*/); /* REF9675 - TEB - 031118 : error code */
        }

        COPY_DYNST(advaArgForYtmStp->argStp, advArgStp, AdvA_Arg);

        /* set the type of the output structure */
	    SET_INT(advaArgForYtmStp->argStp, AdvA_Arg_SceOutEn, A_Ytm); /* REF9764 - LJE - 040113 */

        /* allocate the output structure */
	    if ((advaArgForYtmStp->outStp = ALLOC_DYNST(A_Ytm)) == NULLDYNST)
	    {
            FREE_DYNST(advaArgForYtmStp->argStp, AdvA_Arg);
            FREE(advaArgForYtmStp);
		    return(RET_MEM_ERR_ALLOC /*SCE_ALLOC_ERROR*/); /* REF9675 - TEB - 031118 : error code */
	    }


        advaArgForYtmStp->extPosStp	      = NULLDYNST;
        advaArgForYtmStp->instrStp	      = instrStp;
        advaArgForYtmStp->hierHead	      = hierHead;
        advaArgForYtmStp->underInstr	  = NULLDYNST;
        advaArgForYtmStp->underUnderInstr = NULLDYNST;
        advaArgForYtmStp->incomeStp       = NULLDYNST;
        advaArgForYtmStp->incomeYieldcurve= NULLDYNST;
        advaArgForYtmStp->currSceFct      = Sce_FctName_Bond_YTM2Yield;

		/* PMSTA01459-CHU-070312 : Make sure interCondNat is initialized before any select */
	    if (IS_NULLFLD(advaArgForYtmStp->instrStp, A_Instr_InterCondNatEn) == FALSE)
		{
			advaArgForYtmStp->interCondNat = (INTERCONDNAT_ENUM)GET_ENUM(advaArgForYtmStp->instrStp, A_Instr_InterCondNatEn);
		}

        if ( SCE_CallBond_YTM2Yield(advaArgForYtmStp)!=RET_SUCCEED)
        {
	        FREE_DYNST(advaArgForYtmStp->argStp, AdvA_Arg);
            FREE_DYNST(advaArgForYtmStp->outStp, A_Ytm);
            FREE(advaArgForYtmStp);
            return(RET_FIN_ERR_INVDATA /*RET_MEM_ERR_ALLOC*/); /* REF9675 - TEB - 031118 : error code */
        }

        ytm = GET_NUMBER(advaArgForYtmStp->outStp, A_Ytm_Ytm);

        FREE_DYNST(advaArgForYtmStp->argStp, AdvA_Arg);
        FREE_DYNST(advaArgForYtmStp->outStp, A_Ytm); /* REF8712 - LJE - 031020 */
        FREE(advaArgForYtmStp);


        if (retCd == RET_SUCCEED)
        {
			/* Computation */
			/* REF10461 - TEB - 040804 - begin */
			/* Add division by the freq execpt for InstrNat_MoneyMkt and InstrNat_Discount */
			if (InstrNat_MoneyMkt == instrNatInstr ||
				InstrNat_Discount == instrNatInstr)
			{
				mdura = (NUMBER_T)GET_NUMBER(advAStp, A_AdvA_Dura);

				if ((1.0 + ytm) != 0.0)
					mdura = mdura / (1+ytm);

				SET_NUMBER(advAStp, A_AdvA_Dura, mdura);
			}
			else
			{
				/* Search the frequence */
				if ((incomePtr = ALLOC_DYNST(A_IncEvt)) == NULLDYNST)
				{
					MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
					return(RET_MEM_ERR_ALLOC);
				}

				if ((retCd = DBA_GetIncEvt(instrStp, refDateTime, incomePtr)) != RET_SUCCEED)
				{
					FREE_DYNST(incomePtr, A_IncEvt);
					return(retCd);
				}

				FIN_PeriodUnitNbr((FREQUNIT_ENUM)GET_ENUM(incomePtr, A_IncEvt_PayFreqUnitEn), /* REF7264 - LJE - 020129 */
								  GET_TINYINT(incomePtr, A_IncEvt_PayFreq),
								  FreqUnit_Month, &freq);

				FREE_DYNST(incomePtr, A_IncEvt);

				/* Event number per year */
                if (CMP_NUMBER(freq, 0.0) != 0)
                {
                    freq = (12 / freq);
                }

                /* Formula */
                if (CMP_NUMBER(freq, 0.0) != 0)
                {
                    denom = 1 + (ytm/freq);
                }
                else /* REF10713 - TEB - 041021 */
                {
                    denom = 1 + ytm;
                }

				mdura = (NUMBER_T)GET_NUMBER(advAStp, A_AdvA_Dura);

				if (CMP_NUMBER(denom, 0.0) != 0)
					mdura = mdura / denom;

				SET_NUMBER(advAStp, A_AdvA_Dura, mdura);
			}
			/* REF10461 - TEB - 040804 - end */
        }

    }

    /* If necessary, write into cach */
    if (forceCalcFlg == FALSE)
    {
	    if (retCd != RET_SUCCEED)
		    /* Memorize the error in data cache. */
		    DBA_SetDimChrono((ID_T)GET_ID(instrStp, A_Instr_Id),/* InstrId */
				             refDateTime,				        /* RefDate */
				             (NUMBER_T)0,				        /* ValidPeriod */
				             (FLAG_T)TRUE,				        /* ValidPeriod IS NULL */
                             (ID_T)0,                           /* Third party */ /* REF10598 - LJE - 041011 */
				             (CHRONONAT_ENUM)ChronoNat_ModDura,	/* Nature */
                             (ID_T)0,                               /* Sub nature type */ /* REF10598 - LJE - 041011 */
				             (ID_T)0,				            /* CurrId */
				             (NUMBER_T)0,				        /* Val */
				             (int)RET_DBA_ERR_DURING_FIN_CALC,	/* Return error number */
				             (char*)NULL);				        /* Error msg string */

        else
		    DBA_SetDimChrono((ID_T)GET_ID(instrStp, A_Instr_Id),         /* InstrId */
				             refDateTime,				                 /* RefDate */
				             (NUMBER_T)0,				                 /* ValidPeriod */
				             (FLAG_T)TRUE,				                 /* ValidPeriod IS NULL */
                             (ID_T)0,                                    /* Third party */ /* REF10598 - LJE - 041011 */
				             (CHRONONAT_ENUM)ChronoNat_ModDura,	         /* Nature */
                             (ID_T)0,                               /* Sub nature type */ /* REF10598 - LJE - 041011 */
				             (ID_T)0,				                     /* CurrId */
				             (NUMBER_T)GET_NUMBER(advAStp, A_AdvA_Dura), /* Val */
				             (int)0, 				                     /* Return error number */
				             (char*)NULL);				                 /* Error msg string */

    }

	/* PMSTA-14879 - DDV - 120920 - compute don't succeed without check in db, call back and force db access only */
	if (firstComputeFlg == TRUE && forceCalcFlg == TRUE && retCd != RET_SUCCEED)
	{
		retCd = FIN_MDura(advArgStp, NO_COMPUTE, instrStp, extPosSt, hierHead, advAStp);
	}

    return(retCd);
}

/************************************************************************
**
**  Function    :   FIN_Dura()
**
**  Description :   This function calculates the duration of an instrument.
**
**  Arguments	:   argStp       - pointer to input arguments structure
**              :   forceCalcFlg - flag to force compute without chrono
**		        :   instrStp     - pointer to current instrument received
**     		    :   extPosPtr    - pointer to extpos structure
**		        :   hierHead     - pointer to hierarchy
**		        :   sceOutStp    - pointer to output data structure
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   REF9082 - TEB - 030528
**
**  Modif       :   REF9082 - TEB - 030807 : Add test on AdvA_Arg_RedemptionPrice
**                  REF10461 - TEB - 040804
**
*************************************************************************/
RET_CODE FIN_Dura(DBA_DYNFLD_STP   advArgStp,
                  FLAG_T           forceCalcFlg,
                  DBA_DYNFLD_STP   instrStp,
                  DBA_DYNFLD_STP   extPosSt,
                  PTR              hierHead,
                  DBA_DYNFLD_STP   advAStp)
{
    INSTRNAT_ENUM   instrNatInstr = InstrNat_None;
    SUBNAT_ENUM     instrSubNat   = SubNat_None;
    RET_CODE        retCd = RET_SUCCEED;
    DBA_DYNFLD_STP  instrChrono=NULLDYNST, dimChronoPtr=NULLDYNST;
    DATETIME_T      refDateTime;
	FLAG_T          firstComputeFlg=FALSE;
	ID_T            domainQuoteValRuleId = 0;
	DBA_DYNFLD_STP  domainPtr=NULLDYNST;

	/* REF10529 - TEB - 040826 */
	/* Default value is current date !! */
	if (IS_NULLFLD(advArgStp, AdvA_Arg_RefDate)==TRUE)
	{
		SET_DATE(advArgStp, AdvA_Arg_RefDate, DATE_CurrentDate());
	}

    /* REF10089 - TEB - 040322 */
    /* Use the instrument's begin date if it is > than computation date */
    if (IS_NULLFLD(instrStp,  A_Instr_BeginDate)  == FALSE &&
        DATE_Cmp(GET_DATE(advArgStp, AdvA_Arg_RefDate), GET_DATE(instrStp, A_Instr_BeginDate)) < 0)
    {
        COPY_DYNFLD(advArgStp, AdvA_Arg, AdvA_Arg_RefDate, instrStp, A_Instr, A_Instr_BeginDate);
        COPY_DYNFLD(advArgStp, AdvA_Arg, AdvA_Arg_Date,    instrStp, A_Instr, A_Instr_BeginDate);
    }

    refDateTime.date = GET_DATE(advArgStp, AdvA_Arg_RefDate);
	refDateTime.time = 0;


    /* Get nature of the instrument */
    instrNatInstr = (INSTRNAT_ENUM)GET_ENUM(instrStp, A_Instr_NatEn);
    instrSubNat   = (SUBNAT_ENUM)  GET_ENUM(instrStp, A_Instr_SubNatEn);

	/* compute only these instruments */
	if ((InstrNat_Bond          != instrNatInstr &&
	     InstrNat_MoneyMkt      != instrNatInstr &&
	     InstrNat_Discount      != instrNatInstr &&
	     InstrNat_CumOption     != instrNatInstr &&
         InstrNat_ConvertBond   != instrNatInstr) ||
        (SubNat_FRN             == instrSubNat)
	   )
	{
	    return(RET_SUCCEED);
	}

    /* REF9082 - TEB - 030807 : Add test on AdvA_Arg_RedemptionPrice */
	/* REF10461 - TEB - 040804 */
	/* Compute Redemption Price in SCE functions, because of iorevent priority */
/*
    if (IS_NULLFLD(advArgStp, AdvA_Arg_RedemptionPrice)== TRUE)
    {
        if (IS_NULLFLD(instrStp, A_Instr_RedempQuote)== TRUE)
        {
            MSG_SendMesg(RET_GEN_ERR_PERSONAL, 6, FILEINFO, "No redemption quote for duration computation ! Instrument :",
                         GET_CODE(instrStp, A_Instr_Cd));
            return(RET_SUCCEED);
        }
        else
        {
            COPY_DYNFLD(advArgStp, AdvA_Arg, AdvA_Arg_RedemptionPrice, instrStp, A_Instr, A_Instr_RedempQuote );
        }
    }
*/

    /* Only use flag3 if instrument is not generic and no further parameteres */
	if (GET_FLAG(instrStp, A_Instr_GenericFlg) == TRUE)
		forceCalcFlg = TRUE;

	/* PMSTA14879 - DDV - 120920 - Check if computation must be forced */
	if (forceCalcFlg == FALSE && FIN_ForceComputeInstrChrono(instrStp, ChronoNat_ModDura) == TRUE)
	{
		DBA_DYNFLD_STP  pricePtr = ALLOC_DYNST(A_InstrPrice);

		if (pricePtr != NULLDYNST)
		{
			/* PMSTA15697 - DDV - 121227 - But force computation only if price exists */
			if (FIN_InstrPrice(GET_ID(instrStp, A_Instr_Id),
							   instrStp,
							   refDateTime,
							   NULLDYNST,
							   (ID_T)0,
							   NULL,
							   NULLDYNST,
							   NULLDYNST,
							   (DBA_HIER_HEAD_STP)hierHead,
							   pricePtr,
							   TRUE) == RET_SUCCEED)
			{
				firstComputeFlg = TRUE;
				forceCalcFlg = TRUE;
			}
		}
		FREE_DYNST(pricePtr, A_InstrPrice);
	}

	if (forceCalcFlg == NO_COMPUTE)
	{
		firstComputeFlg = TRUE;
		forceCalcFlg = FALSE;
	}

	/* Chronological data */
    if (forceCalcFlg == FALSE)
	{
	    if ((instrChrono = ALLOC_DYNST(A_InstrChrono)) == NULLDYNST)
	    {
		    MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
		    return(RET_MEM_ERR_ALLOC);
	    }

	    if ((dimChronoPtr = ALLOC_DYNST(Dim_InstrChrono)) == NULLDYNST)
	    {
		    FREE_DYNST(instrChrono, A_InstrChrono);
	    	MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
		    return(RET_MEM_ERR_ALLOC);
	    }

	    /* Verify first in memory with negativ identifier */
	    SET_ID(dimChronoPtr,       Dim_InstrChrono_InstrId, GET_ID(instrStp, A_Instr_Id));
	    SET_DATETIME(dimChronoPtr, Dim_InstrChrono_RefDate, refDateTime);
	    SET_ENUM(dimChronoPtr,     Dim_InstrChrono_NatEn,   ChronoNat_Dura);

		/* PMSTA14879 - DDV - 120920 - Add domain's valuation rule as criteria for cache usage */
		if ((domainPtr = DBA_GetDomainPtr(NO_VALUE)) != NULLDYNST &&
			(domainQuoteValRuleId = GET_ID(domainPtr, A_Domain_QuoteValRuleId)) != 0)
		{
			SET_ID(dimChronoPtr, Dim_InstrChrono_DomQuoteValRuleId, domainQuoteValRuleId);
		}

	    if ((retCd = DBA_GetDimChrono(dimChronoPtr, instrChrono)) == RET_SUCCEED)
	    {
            COPY_DYNFLD(advAStp, A_AdvA, A_AdvA_Dura, instrChrono, A_InstrChrono, A_InstrChrono_Val);
		    FREE_DYNST(instrChrono, A_InstrChrono);
		    FREE_DYNST(dimChronoPtr, Dim_InstrChrono);
		    return(retCd);
	    }
	    else if (retCd == RET_DBA_ERR_DURING_FIN_CALC)	/* aborted calculation. */
	    {
	       	FREE_DYNST(instrChrono, A_InstrChrono);
		    FREE_DYNST(dimChronoPtr, Dim_InstrChrono);
		    return(retCd);
	    }

	    /* FIN_InstrChrono read database too */
	    COPY_DYNFLD(dimChronoPtr, Dim_InstrChrono, Dim_InstrChrono_InstrId, instrStp, A_Instr, A_Instr_Id);
	    SET_FLAG(dimChronoPtr,     Dim_InstrChrono_ComputeFlg,  FALSE);

	    retCd = FIN_InstrChrono(dimChronoPtr, instrStp, instrChrono, (DBA_HIER_HEAD_STP)hierHead);

	    if (retCd == RET_SUCCEED)
	    {
            COPY_DYNFLD(advAStp, A_AdvA, A_AdvA_Dura, instrChrono, A_InstrChrono, A_InstrChrono_Val);
	        FREE_DYNST(instrChrono, A_InstrChrono);
	        FREE_DYNST(dimChronoPtr, Dim_InstrChrono);
		    return(retCd);
	    }

	    /* We did optimized an aborted calculation. */
	    if (retCd == RET_DBA_ERR_DURING_FIN_CALC)
	    {
	        FREE_DYNST(instrChrono, A_InstrChrono);
	        FREE_DYNST(dimChronoPtr, Dim_InstrChrono);
		    return(retCd);
	    }

	    /* Not found, compute value */
	    FREE_DYNST(instrChrono, A_InstrChrono);
	    FREE_DYNST(dimChronoPtr, Dim_InstrChrono);
	}

	/* PMSTA14879 - DDV - 120920 - If priorty is to compute and it the second call for db access, don't try to compute it a second time */
	if (firstComputeFlg == TRUE && forceCalcFlg == FALSE)
	{
		SET_NUMBER(advAStp, A_AdvA_Dura, 0.0);
	    return(retCd);
	}

    /* Compute duration */
    retCd = SCE_ComputeCurrKeyWord(advArgStp, instrStp,
			 	    (DBA_DYNFLD_STP) extPosSt, hierHead, advAStp);

    /* If necessary, write into cach */
    if (forceCalcFlg == FALSE)
    {
	    if (retCd != RET_SUCCEED)
		    /* Memorize the error in data cache. */
		    DBA_SetDimChrono((ID_T)GET_ID(instrStp, A_Instr_Id),/* InstrId */
				             refDateTime,				        /* RefDate */
				             (NUMBER_T)0,				        /* ValidPeriod */
				             (FLAG_T)TRUE,				        /* ValidPeriod IS NULL */
                             (ID_T)0,                           /* Third party */ /* REF10598 - LJE - 041011 */
				             (CHRONONAT_ENUM)ChronoNat_Dura,	/* Nature */
                             (ID_T)0,                           /* Sub nature type */ /* REF10598 - LJE - 041011 */
				             (ID_T)0,				            /* CurrId */
				             (NUMBER_T)0,				        /* Val */
				             (int)RET_DBA_ERR_DURING_FIN_CALC,	/* Return error number */
				             (char*)NULL);				        /* Error msg string */

        else
		    DBA_SetDimChrono((ID_T)GET_ID(instrStp, A_Instr_Id),         /* InstrId */
				             refDateTime,				                 /* RefDate */
				             (NUMBER_T)0,				                 /* ValidPeriod */
				             (FLAG_T)TRUE,				                 /* ValidPeriod IS NULL */
                             (ID_T)0,                                    /* Third party */ /* REF10598 - LJE - 041011 */
				             (CHRONONAT_ENUM)ChronoNat_Dura,	         /* Nature */
                             (ID_T)0,                                    /* Sub nature type */ /* REF10598 - LJE - 041011 */
				             (ID_T)0,				                     /* CurrId */
				             (NUMBER_T)GET_NUMBER(advAStp, A_AdvA_Dura), /* Val */
				             (int)0, 				                     /* Return error number */
				             (char*)NULL);				                 /* Error msg string */

    }

	/* PMSTA-14879 - DDV - 120920 - compute don't succeed without check in db, call back and force db access only */
	if (firstComputeFlg == TRUE && forceCalcFlg == TRUE && retCd != RET_SUCCEED)
	{
		retCd = FIN_Dura(advArgStp, NO_COMPUTE, instrStp, extPosSt, hierHead, advAStp);
	}

    return(retCd);

}

/************************************************************************
**
**  Function    :   FIN_OptSens()
**
**  Description :   This function calculates the sensitivity of an option.
**
**  Arguments	:   argStp       - pointer to input arguments structure
**              :   forceCalcFlg - flag to force compute without chrono
**		        :   instrStp     - pointer to current instrument received
**     		    :   extPosPtr    - pointer to extpos structure
**		        :   hierHead     - pointer to hierarchy
**		        :   sceSens      - pointer to output sensitivity
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   REF9082 - TEB - 030610
**
**  Modif       :
**
**
*************************************************************************/
RET_CODE FIN_OptSens(DBA_DYNFLD_STP   advArgStp,
                     FLAG_T           forceCalcFlg,
                     DBA_DYNFLD_STP   instrStp,
                     DBA_DYNFLD_STP   extPosSt,
                     PTR              hierHead,
                     double           *sceSens)
{
    INSTRNAT_ENUM   instrNatInstr = InstrNat_None;
    RET_CODE        retCd = RET_SUCCEED;
    DBA_DYNFLD_STP  instrChrono=NULLDYNST, dimChronoPtr=NULLDYNST,
                    advAStp	= NULLDYNST;
    DATETIME_T      refDateTime;
    CHRONONAT_ENUM  chronoNat=ChronoNat_Alpha;
    ID_T            domainQuoteValRuleId=0;
	DBA_DYNFLD_STP  domainPtr=NULLDYNST;

	/* REF10529 - TEB - 040826 */
	/* Default value is current date !! */
	if (IS_NULLFLD(advArgStp, AdvA_Arg_RefDate)==TRUE)
	{
		SET_DATE(advArgStp, AdvA_Arg_RefDate, DATE_CurrentDate());
	}


    /* Initialisation */
    *sceSens = 0.0;
    refDateTime.date = GET_DATE(advArgStp, AdvA_Arg_RefDate);
	refDateTime.time = 0;

    /* Get nature of the instrument */
    instrNatInstr = (INSTRNAT_ENUM)GET_ENUM(instrStp, A_Instr_NatEn);

	/* compute only these instruments */
	if ((InstrNat_Option         != instrNatInstr &&
	     InstrNat_ExoticOptions  != instrNatInstr &&
	     InstrNat_SwapOptions    != instrNatInstr) ||
        IS_NULLFLD(advArgStp, AdvA_Arg_SensitivityEn) == TRUE )
	{
	    return(RET_SUCCEED);
	}

    /* Only use flag3 if instrument is not generic and no further parameteres */
	if (GET_FLAG(instrStp, A_Instr_GenericFlg) == TRUE)
		forceCalcFlg = TRUE;

	/* Chronological data */
    if (forceCalcFlg == FALSE)
	{
	    if ((instrChrono = ALLOC_DYNST(A_InstrChrono)) == NULLDYNST)
	    {
		    MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
		    return(RET_MEM_ERR_ALLOC);
	    }

	    switch ((OPTSENS_ENUM) GET_ENUM(advArgStp, AdvA_Arg_SensitivityEn))
	    {
	    case OptSens_Delta :
			chronoNat = ChronoNat_Delta;
			break;
	    case OptSens_Gamma :
			chronoNat = ChronoNat_Gamma;
			break;
	    case OptSens_Omega :
			chronoNat = ChronoNat_Omega;
			break;
	    case OptSens_Kappa :
			chronoNat = ChronoNat_Vega;
			break;
	    case OptSens_Rho :
			chronoNat = ChronoNat_Rho;
			break;
	    case OptSens_Theta :
			chronoNat = ChronoNat_Theta;
			break;
	    case OptSens_Carry :
			chronoNat = ChronoNat_SensitivityQty;
			break;
	    case OptSens_Strike :
			chronoNat = ChronoNat_SensitivityStrike;
			break;
	    default:
			return(RET_SUCCEED);
	    }

	    if ((dimChronoPtr = ALLOC_DYNST(Dim_InstrChrono)) == NULLDYNST)
	    {
		    FREE_DYNST(instrChrono, A_InstrChrono);
	    	MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
		    return(RET_MEM_ERR_ALLOC);
	    }

	    /* Verify first in memory with negativ identifier */
	    SET_ID(dimChronoPtr,       Dim_InstrChrono_InstrId,     GET_ID(instrStp, A_Instr_Id));
	    SET_DATETIME(dimChronoPtr, Dim_InstrChrono_RefDate,     refDateTime);
	    SET_ENUM(dimChronoPtr,     Dim_InstrChrono_NatEn,       chronoNat);

		/* PMSTA14879 - DDV - 120920 - Add domain's valuation rule as criteria for cache usage */
		if ((domainPtr = DBA_GetDomainPtr(NO_VALUE)) != NULLDYNST &&
			(domainQuoteValRuleId = GET_ID(domainPtr, A_Domain_QuoteValRuleId)) != 0)
		{
			SET_ID(dimChronoPtr, Dim_InstrChrono_DomQuoteValRuleId, domainQuoteValRuleId);
		}

	    if ((retCd = DBA_GetDimChrono(dimChronoPtr, instrChrono)) == RET_SUCCEED)
	    {
            *sceSens = GET_LONGAMOUNT(instrChrono, A_InstrChrono_Val);/* REF11704 - TGU - 060419 - Change datatype */
		    FREE_DYNST(instrChrono, A_InstrChrono);
		    FREE_DYNST(dimChronoPtr, Dim_InstrChrono);
		    return(retCd);
	    }
	    else if (retCd == RET_DBA_ERR_DURING_FIN_CALC)	/* aborted calculation. */
	    {
	       	FREE_DYNST(instrChrono, A_InstrChrono);
		    FREE_DYNST(dimChronoPtr, Dim_InstrChrono);
		    return(retCd);
	    }

	    /* FIN_InstrChrono read database too */
	    COPY_DYNFLD(dimChronoPtr,  Dim_InstrChrono, Dim_InstrChrono_InstrId, instrStp, A_Instr, A_Instr_Id);
	    SET_FLAG(dimChronoPtr,     Dim_InstrChrono_ComputeFlg,  FALSE);
	    retCd = FIN_InstrChrono(dimChronoPtr, instrStp, instrChrono, (DBA_HIER_HEAD_STP)hierHead);

	    if (retCd == RET_SUCCEED)
	    {
            *sceSens = GET_LONGAMOUNT(instrChrono, A_InstrChrono_Val); /* REF11704 - TGU - 060419 - Change datatype */
	        FREE_DYNST(instrChrono, A_InstrChrono);
	        FREE_DYNST(dimChronoPtr, Dim_InstrChrono);
		    return(retCd);
	    }

	    /* We did optimized an aborted calculation. */
	    if (retCd == RET_DBA_ERR_DURING_FIN_CALC)
	    {
	        FREE_DYNST(instrChrono, A_InstrChrono);
	        FREE_DYNST(dimChronoPtr, Dim_InstrChrono);
		    return(retCd);
	    }

	    /* Not found, compute value */
	    FREE_DYNST(instrChrono, A_InstrChrono);
	    FREE_DYNST(dimChronoPtr, Dim_InstrChrono);
	}

	/* DVP510 - Must be in chronological data or 0.0 */
	if (instrNatInstr == InstrNat_ExoticOptions ||
	    instrNatInstr == InstrNat_SwapOptions)
	{
		return(RET_SUCCEED);
	}

    /* Allocation */
	if ((advAStp = ALLOC_DYNST(A_AdvA)) == NULLDYNST)
	{
		return(RET_SUCCEED);
	}

    /* Compute duration */
    retCd = SCE_ComputeCurrKeyWord(advArgStp, instrStp,
			 	    (DBA_DYNFLD_STP) extPosSt, hierHead, advAStp);

    if (retCd == RET_SUCCEED)
    {
	    switch ((OPTSENS_ENUM) GET_ENUM(advArgStp, AdvA_Arg_SensitivityEn))
	    {
	    case OptSens_Delta :
		    *sceSens = GET_NUMBER(advAStp, A_AdvA_Delta);
		    break;
	    case OptSens_Gamma :
		    *sceSens = GET_NUMBER(advAStp, A_AdvA_Gamma);
		    break;
	    case OptSens_Omega :
            *sceSens = GET_NUMBER(advAStp, A_AdvA_Vega);
		    break;
	    case OptSens_Kappa :
            *sceSens = GET_NUMBER(advAStp, A_AdvA_DVegaDVol);
		    break;
	    case OptSens_Rho :
            *sceSens = GET_NUMBER(advAStp, A_AdvA_Rho);
		    break;
	    case OptSens_Theta :
            *sceSens = GET_NUMBER(advAStp, A_AdvA_Theta);
		    break;
	    case OptSens_Carry :
            *sceSens = GET_NUMBER(advAStp, A_AdvA_DpDivYield);
		    break;
	    case OptSens_Strike :
            *sceSens = GET_NUMBER(advAStp, A_AdvA_DpDc);
		    break;
	    default:
		    return(RET_SUCCEED);
	    }
    }

    /* If necessary, write into cach */
    if (forceCalcFlg == FALSE)
    {
	    if (retCd != RET_SUCCEED)
		    /* Memorize the error in data cache. */
		    DBA_SetDimChrono((ID_T)GET_ID(instrStp, A_Instr_Id),/* InstrId */
				             refDateTime,				        /* RefDate */
				             (NUMBER_T)0,				        /* ValidPeriod */
				             (FLAG_T)TRUE,				        /* ValidPeriod IS NULL */
                             (ID_T)0,                           /* Third party */ /* REF10598 - LJE - 041011 */
				             (CHRONONAT_ENUM)chronoNat,	        /* Nature */
                             (ID_T)0,                           /* Sub nature type */ /* REF10598 - LJE - 041011 */
				             (ID_T)0,				            /* CurrId */
				             (NUMBER_T)0,				        /* Val */
				             (int)RET_DBA_ERR_DURING_FIN_CALC,	/* Return error number */
				             (char*)NULL);				        /* Error msg string */

        else
		    DBA_SetDimChrono((ID_T)GET_ID(instrStp, A_Instr_Id),         /* InstrId */
				             refDateTime,				                 /* RefDate */
				             (NUMBER_T)0,				                 /* ValidPeriod */
				             (FLAG_T)TRUE,				                 /* ValidPeriod IS NULL */
                             (ID_T)0,                                    /* Third party */ /* REF10598 - LJE - 041011 */
				             (CHRONONAT_ENUM)chronoNat,	                 /* Nature */
                             (ID_T)0,                                    /* Sub nature type */ /* REF10598 - LJE - 041011 */
				             (ID_T)0,				                     /* CurrId */
				             (NUMBER_T)*sceSens,                         /* Val */
				             (int)0, 				                     /* Return error number */
				             (char*)NULL);				                 /* Error msg string */

    }

	FREE_DYNST(advAStp,   A_AdvA);
    return(retCd);
}


/************************************************************************
*
*  Function          : FIN_CalcArrayDiff()
*
*  Description       : this function computes an array by calculating the percentage
*                      change from an occurence to another in a given array.
*
*  Arguments         : array        : initial array
*                      newArrayArg  : new calculated array
*
*  Return            : RET_SUCCEED
*
*  Creation date     : 18.06.96 - PEC - Ref.: DVP143+
*
*  Last modification : 26.06.97 - GRD - Ref.: BUG408
*                      PMSTA-25190 - 061116 - PMO : Fixes of some errors founded by AddressSanitizer
*
************************************************************************/
RET_CODE FIN_CalcArrayDiff(DBA_DYNFLD_STP array, DBA_DYNFLD_STP *newArrayArg)
{
    ushort              newRecNbr   = 0;
	int                 recNbr      = GET_MULTIARRAY_DIM1(array, 0);
	DBA_ARRAY_DATA_STP  arrayData   = GET_MULTIARRAY_PTR(array, 0);
	DBA_DYNFLD_STP      newArray    = ALLOC_DYNST(Array_X);
	DBA_ARRAY_DATA_STP  newArrayData= (DBA_ARRAY_DATA_STP)CALLOC(1, sizeof(DBA_ARRAY_DATA_ST)); /* REF7264 - LJE - 020128 */

	if (recNbr < 2)
    {
		SET_MULTIARRAY(newArray, 0, newArrayData, 0, 0);
       	*newArrayArg = newArray; /* REF4196 - DDV - 991207 */
		return(RET_SUCCEED);
    }

	/*
	 * Moved allocation after the above test.
	 * (Avoid 0 byte sized calloc). BUG408.
	 */

    newArrayData->dataTab       = ALLOC_DYNST_WITHOUTDEF(recNbr-1); /* REF8844 - LJE - 030401 */
	newArrayData->notNullFlgTab = (char *)CALLOC(recNbr-1, sizeof(char)); /* REF7264 - LJE - 020128 */

	for (int i=1 ; i<recNbr ; i++)
	{
		/* If the current or the preceding data is NULL */
		if (arrayData->notNullFlgTab[i-1] == FALSE ||
		    arrayData->notNullFlgTab[i]   == FALSE)
			continue;

		/* If current data is equal to 0 */
		if (CMP_NUMBER(GET_NUMBER(arrayData->dataTab, i), 0.0) == 0) /* REF7296 - LJE - 020501 */
		{
			/* If preceding data is upper than 0 */
			if (CMP_NUMBER(GET_NUMBER(arrayData->dataTab, i-1), 0.0) > 0) /* REF7296 - LJE - 020501 */
			{
				SET_NUMBER(newArrayData->dataTab, newRecNbr, -1.0); /* 100 % loss */ /* REF7296 - LJE - 020501 */
				newArrayData->notNullFlgTab[newRecNbr] = TRUE;
			}
			else
			{       /* If preceding data is equal to 0 */
				if (CMP_NUMBER(GET_NUMBER(arrayData->dataTab, i-1), 0.0) == 0) /* REF7296 - LJE - 020501 */
				{
					SET_NUMBER(newArrayData->dataTab, newRecNbr, 0.0); /* REF7296 - LJE - 020501 */
					newArrayData->notNullFlgTab[newRecNbr] = TRUE;
				}
				else
				{       /* If preceding data is lower than 0 */
					SET_NUMBER(newArrayData->dataTab, newRecNbr, 1.0);  /* 100 % gain */ /* REF7296 - LJE - 020501 */
					newArrayData->notNullFlgTab[newRecNbr] = TRUE;
				}
			}

			newRecNbr++;
			continue;
		}

		if (CMP_NUMBER(GET_NUMBER(arrayData->dataTab, i-1), 0.0) == 0) /* REF7296 - LJE - 020501 */
		{
			SET_NUMBER(newArrayData->dataTab, newRecNbr, 1.0); /* REF7296 - LJE - 020501 */
			newArrayData->notNullFlgTab[newRecNbr] = TRUE;
		}

        const NUMBER_T tmp = GET_NUMBER(arrayData->dataTab, i - 1);

        if (ZERO_NUMBER != tmp) /* PMSTA-25190 - 061116 - PMO */
        {
		    SET_NUMBER(newArrayData->dataTab, newRecNbr, (GET_NUMBER(arrayData->dataTab, i) / tmp ) - 1. ); /* REF7296 - LJE - 020501 */
        }
        else
        {
            SET_NUMBER(newArrayData->dataTab, newRecNbr, ZERO_NUMBER - 1. );
        }

		newArrayData->notNullFlgTab[newRecNbr] = TRUE;

		newRecNbr++;
	}

	SET_MULTIARRAY(newArray, 0, newArrayData, newRecNbr, 0);

	*newArrayArg = newArray;

	return(RET_SUCCEED);
}

/************************************************************************
*
*  Function          : FIN_CalcArrayLogn()
*
*  Description       : this function computes an array by calculating the natural
*                      logarithm from an occurence divided by another in a given array.
*
*  Arguments         : array        : initial array
*                      newArrayArg  : new calculated array
*
*  Return            : RET_SUCCEED
*
*  Creation date     : 16.06.97 - PEC - Ref.: DVP500
*  Last modification :
*
************************************************************************/
RET_CODE FIN_CalcArrayLogn(DBA_DYNFLD_STP array, DBA_DYNFLD_STP *newArrayArg)
{
	int                i, recNbr;
        ushort             newRecNbr=0;
	DBA_ARRAY_DATA_STP newArrayData, arrayData;
	DBA_DYNFLD_STP     newArray=NULLDYNST;

	recNbr    = GET_MULTIARRAY_DIM1(array, 0);
	arrayData = GET_MULTIARRAY_PTR(array, 0);

	newArray                   = ALLOC_DYNST(Array_X);
	newArrayData                = (DBA_ARRAY_DATA_STP)CALLOC(1, sizeof(DBA_ARRAY_DATA_ST)); /* REF7264 - LJE - 020128 */

    newArrayData->dataTab       = ALLOC_DYNST_WITHOUTDEF(recNbr-1); /* REF8844 - LJE - 030401 */
	newArrayData->notNullFlgTab = (char *)CALLOC(recNbr-1, sizeof(char)); /* REF7264 - LJE - 020128 */

	if (recNbr < 2)
        {
		SET_MULTIARRAY(newArray, 0, newArrayData, 0, 0);
       	*newArrayArg = newArray; /* REF4196 - DDV - 000316 */
		return(RET_SUCCEED);
	}

	for (i=1 ; i<recNbr ; i++)
	{
		/* If the current or the preceding data is NULL */
		if (arrayData->notNullFlgTab[i-1] == FALSE ||
		    arrayData->notNullFlgTab[i]   == FALSE)
			continue;

		if (CMP_NUMBER(GET_NUMBER(arrayData->dataTab, i), 0.0) < 0 ||  /* REF7296 - LJE - 020501 */
			CMP_NUMBER(GET_NUMBER(arrayData->dataTab, i-1), 0.0) < 0)
		{
			newRecNbr = 0;
			break;
		}

		/* If current data is equal to 0 */
		if (CMP_NUMBER(GET_NUMBER(arrayData->dataTab, i), 0.0) == 0) /* REF7296 - LJE - 020501 */
		{
			/* If preceding data is upper than 0 */
			if (CMP_NUMBER(GET_NUMBER(arrayData->dataTab, i-1), 0.0) > 0) /* REF7296 - LJE - 020501 */
			{
				SET_NUMBER(newArrayData->dataTab, newRecNbr, 0.0);  /* REF7296 - LJE - 020501 */
				newArrayData->notNullFlgTab[newRecNbr] = TRUE;
			}
			else
			{       /* If preceding data is equal to 0 */
				if (CMP_NUMBER(GET_NUMBER(arrayData->dataTab, i-1),0.0) == 0) /* REF7296 - LJE - 020501 */
				{
					SET_NUMBER(newArrayData->dataTab,newRecNbr, 0.0); /* REF7296 - LJE - 020501 */
					newArrayData->notNullFlgTab[newRecNbr] = TRUE;
				}
				else
				{       /* If preceding data is lower than 0 */
					SET_NUMBER(newArrayData->dataTab,newRecNbr, 0.0);  /* REF7296 - LJE - 020501 */
					newArrayData->notNullFlgTab[newRecNbr] = TRUE;
				}
			}

			newRecNbr++;
			continue;
		}

		SET_NUMBER(newArrayData->dataTab, newRecNbr,  /* REF7296 - LJE - 020501 */
			       log(GET_NUMBER(arrayData->dataTab,i)/GET_NUMBER(arrayData->dataTab,i-1)));
		newArrayData->notNullFlgTab[newRecNbr] = TRUE;

		newRecNbr++;
	}

	SET_MULTIARRAY(newArray, 0, newArrayData, newRecNbr, 0);

	*newArrayArg = newArray;

	return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_CalcRegr()
**
**  Description :   Receives two arrays of numerical data each with the
**                  same number of occurrences.
**                  Computes :
**                  - number of records
**                  - alpha
**                  - beta
**                  - covariance
**                  - correlation coefficient
**                  - determination coefficient R2
**                  - chi squared                      (TO DO)
**                  - standard deviation of alpha      (TO DO)
**                  - standard deviation of beta       (TO DO)
**                  - goodness of fit probability Q    (TO DO)
**
**  Arguments   :   array1          first array
**                  array2          second array
**                  arrayNbr        arrays element number
**                  regrPtr         pointer on output structure
**
**  Return      :   RET_SUCCEED or error code, regrPtr is filled
**
** DVP005 : Added new function REGR (96/03/12)
**
**  Modif       :   BUG055 - RAK - 960709
**
*************************************************************************/
STATIC RET_CODE FIN_CalcRegr(double         *arrayX,
			     double         *arrayY,
			     int            arrayNbr,
		             DBA_DYNFLD_STP regrPtr)
{
	int    i;
	double sumX, sumY, sumXY, sumX2, sumY2, meanX, meanY,
	       sumMeanXY, sumMeanX, sumMeanY, sumMeanX2, sumMeanY2,
	       devX, devY, alpha, beta, cov, coeff, r2, n;

	/*** NUMBER OF RECORDS ***/
	SET_INT(regrPtr, A_Regr_RecNbr, arrayNbr);
	n = (double)  arrayNbr;

	/* First pass to get means and sums */
	for(i=0, sumXY=0.0, sumX=0.0, sumX2=0.0, sumY=0.0, sumY2=0.0; i<arrayNbr; i++)
	{
		sumXY += (arrayX[i] * arrayY[i]);

		sumX  += arrayX[i];
		sumX2 += (arrayX[i] * arrayX[i]);

		sumY  += arrayY[i];
		sumY2 += (arrayY[i] * arrayY[i]);
	}

	meanX = sumX / n;
	meanY = sumY / n;

	for(i=0, sumMeanXY=0.0, sumMeanX2=0.0, sumMeanX=0.0, sumMeanY2=0.0, sumMeanY=0.0;
	    i<arrayNbr; i++)
	{
		sumMeanXY += ((arrayX[i]-meanX) * (arrayY[i]-meanY));

		sumMeanX2 += ((arrayX[i]-meanX) * (arrayX[i]-meanX));
		sumMeanX  += (arrayX[i]-meanX);

		sumMeanY2 += ((arrayY[i]-meanY) * (arrayY[i]-meanY));
		sumMeanY  += (arrayY[i]-meanY);
	}

	/* Compute standard deviation for X (entire population) */
	devX = (sumMeanX2 - ((sumMeanX * sumMeanX) / n)) / n;
	devX = fabs(devX);
	devX = sqrt(devX);

	/* Compute standard deviation for Y (entire population) */
	devY = (sumMeanY2 - ((sumMeanY * sumMeanY) / n)) / n;
	devY = fabs(devY);
	devY = sqrt(devY);

	/*** BETA ***/
	if (((n * sumX2) - (sumX * sumX)) != 0.0)
	    beta = CAST_NUMBER((n * sumXY) - (sumX * sumY)) / ((n * sumX2) - (sumX * sumX)); /* REF3288 - SSO - 990205 */
	else
	    beta = 0.0;
	SET_NUMBER(regrPtr, A_Regr_Beta, beta);

	/*** ALPHA ***/
	alpha = CAST_NUMBER(meanY - beta * meanX); /* REF3288 - SSO - 990205 */
	SET_NUMBER(regrPtr, A_Regr_Alpha, alpha);

	/*** COVARIANCE ***/
	cov = CAST_NUMBER((1.0 / n) * sumMeanXY); /* REF3288 - SSO - 990205 */
	SET_NUMBER(regrPtr, A_Regr_Covariance, cov);

	/*** CORRELATION COEFFICIENT ***/
	if ((devX * devY) != 0.0)
	{
		coeff = CAST_NUMBER(cov / (devX * devY)); /* REF3288 - SSO - 990205 */
	}
	else
		coeff = 0.0;
	SET_NUMBER(regrPtr, A_Regr_CorrelationCoef, coeff);

	/*** DETERMINATION COEFFICIENT R2 ***/
	/* --------------------------- */
	/* BEGIN BUG055 - RAK - 960709 */
	r2 = coeff * coeff;
	/* END   BUG055 - RAK - 960709 */
	/* --------------------------- */
	SET_NUMBER(regrPtr, A_Regr_DetermCoefR2, r2);

	/*** CHI SQUARED ***/ /* TO DO ?? */
	SET_NUMBER(regrPtr, A_Regr_ChiSquared, 0.0);

	/*** STANDARD DEVIATION OF ALPHA ***/ /* TO DO ?? */
	SET_NUMBER(regrPtr, A_Regr_StdDeviationAlpha, 0.0);

	/*** STANDARD DEVIATION OF BETA ***/ /* TO DO ?? */
	SET_NUMBER(regrPtr, A_Regr_StdDeviationBeta, 0.0);

	/*** GOODNESS OF FIT PROBABILITY Q ***/ /* TO DO ?? */
	SET_NUMBER(regrPtr, A_Regr_GoodnessFitProbQ, 0.0);

	return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_CalcStat()
**
**  Description :   Receives one array of numerical data
**                  Computes :
**                  - number of records
**                  - mean
**                  - standard deviation
**                  - variance
**                  - median  (TO DO)
**                  - centile (TO DO)
**
**  Arguments   :   array           array pointer
**                  arrayNbr        array element number
**                  statPtr         pointer on output structure
**
**  Return      :   RET_SUCCEED or error code, statPtr is filled
**
** DVP005 : Added new function STAT (96/03/12)
** DVP133 : Added new calculations (Min value and Max value) - PEC
** REF4245 - SSO - 000117 : modified # of argument limit (3 -> 1)
** REF4494 - SSO - 000321 : removed useless code
** REF8705 - LJE - 030120 : Function is now external
**
*************************************************************************/
RET_CODE FIN_CalcStat(double *array, int arrayNbr, DBA_DYNFLD_STP statPtr)
{
	int    i;
	double mean, var, sum2, n, minimum=0., maximum=0.;

	/*** NUMBER OF RECORDS ***/
	SET_INT(statPtr, A_Stat_RecNbr, arrayNbr);
	n = (double) arrayNbr;

	/* First pass to get the mean */
	for(i=0, mean=0.0; i<arrayNbr; i++)
		mean += array[i];
	mean /= n;

	minimum = maximum = array[0];

	/* Second pass to get the first (absolute), second, third */
	/* and fourth moments of the deviation from the mean.     */
	for(i=0, sum2=0.0; i<arrayNbr; i++)
	{
		/* DVP133 */
		if (minimum > array[i])
			minimum = array[i];
		if (maximum < array[i])
			maximum = array[i];
		/* DVP133 */

		sum2 += ((array[i]-mean) * (array[i]-mean));
/* REF4494 - SSO - 000321		sum  += (array[i]-mean);*/
	}

	/*** DVP133 - MAXIMUM and MINIMUM ***/
	SET_NUMBER(statPtr, A_Stat_Min, minimum);
	SET_NUMBER(statPtr, A_Stat_Max, maximum);
	/*** DVP133  ***/

	/*** MEAN ***/
	SET_NUMBER(statPtr, A_Stat_Mean, mean);

	/* REF4245 - SSO - 000117 allow "1" argument. "2" is also ok */
	if (n == 1)
	{
	    /* force to zero */
	    SET_NUMBER(statPtr, A_Stat_Variance, 0.0);
	    SET_NUMBER(statPtr, A_Stat_StdDeviation, 0.0);
	    SET_NUMBER(statPtr, A_Stat_VarianceEntPop, 0.0);
	    SET_NUMBER(statPtr, A_Stat_StdDeviationEntPop, 0.0);
	}
	else
	{
	    /*** VARIANCE ***/
/*REF4494 - SSO - 000321	    var = (sum2 - ((sum * sum) / n)) / (n - 1.0);  */
		var = (sum2) / (n - 1.0);
	    SET_NUMBER(statPtr, A_Stat_Variance, CAST_NUMBER(var)); /* REF3288 - SSO - 990205 */

	    /*** STANDARD DEVIATION ***/
	    var = fabs(var);
	    var = sqrt(var);
	    SET_NUMBER(statPtr, A_Stat_StdDeviation, var);

	    /*** VARIANCE (ENTIRE POPULATION) ***/
/*REF4494 - SSO - 000321	    	    var = (sum2 - ((sum * sum) / n)) / n; */
		var = (sum2) / n;
	    SET_NUMBER(statPtr, A_Stat_VarianceEntPop, CAST_NUMBER(var)); /* REF3288 - SSO - 990205 */

	    /*** STANDARD DEVIATION (ENTIRE POPULATION) ***/
	    var = fabs(var);
	    var = sqrt(var);
	    SET_NUMBER(statPtr, A_Stat_StdDeviationEntPop, var);
	}

	/*** MEDIAN ***/ /* TO DO ?? */
	SET_NUMBER(statPtr, A_Stat_Median, 0.0);

	/*** CENTILE ***/ /* TO DO ?? */
	SET_NUMBER(statPtr, A_Stat_Centile, 0.0);

	return(RET_SUCCEED);
}

/************************************************************************
**
**  Function          :   FIN_GetClassifCompo()
**
**  Description       :
**
**  Arguments         :
**
**  Return            :   RET_SUCCEED or error code
**
**  Creation          :   REF8831 - LJE - 030219
**  Modification      :
**
*************************************************************************/
RET_CODE FIN_GetClassifCompo(ID_T                      classifId,
                             ID_T                      listId,
                             DBA_DYNFLD_STP            *eClassifCompoStp,
                             int*                      allocConn)
{
	DBA_CLASSIFSTACKHEAD_STP threadClassifStack      = DBA_GetClassifStackHeadPtr();
    int                      i, rowNb=0;
    DBA_DYNFLD_STP           getArgRec, sClassifCompoRec, *eClassifCompoPtrTab=NULLDYNSTPTR;
    FLAG_T                   foundFlg=FALSE, cnxToCloseFlg=FALSE;
    int                      connectNo               = DBA_CONN_NOT_FOUND;
    RET_CODE                 ret                     = RET_SUCCEED;

	if (allocConn != UNUSED)
	{
        connectNo = *allocConn;
	}

	/***** ALLOC LOCAL DYN STRUCTURES *****/
	getArgRec	     = ALLOC_DYNST(Get_Arg);
	sClassifCompoRec = ALLOC_DYNST(S_ClassifCompo);

	/***** classifStack OPTIMISATION *****/
    if(threadClassifStack != (DBA_CLASSIFSTACKHEAD_STP) NULL)
	{
	    for(i=0; i < threadClassifStack->classifNbr &&
		    threadClassifStack->classifTab[i].classifId != classifId; i++);

	    if(i < threadClassifStack->classifNbr &&
           threadClassifStack->classifTab[i].classifId != 0)
	    {
		    foundFlg = TRUE;
		    eClassifCompoPtrTab = threadClassifStack->classifTab[i].eClassifCompoPtrTab;
		    rowNb = threadClassifStack->classifTab[i].totalListNb;
	    }
	}

	if(foundFlg == FALSE)
	{
        if(connectNo == DBA_CONN_NOT_FOUND)
        {
            /* If a connection number is not given */
		    if ((connectNo = DBA_GetConnection(SqlServer)) == DBA_CONN_NOT_FOUND)
		    {
                MSG_RETURN(RET_DBA_ERR_CONNOTFOUND);
		    }

            cnxToCloseFlg = TRUE;
        }

	    /***** SELECT ALL classif_compo FROM classif_id *****/
	    SET_ID (sClassifCompoRec, S_ClassifCompo_ClassifId, classifId);

	    if (DBA_Select2( ClassifCompo,
                         UNUSED,
		                 S_ClassifCompo,
                         sClassifCompoRec,
		                 E_ClassifCompo,
                         &eClassifCompoPtrTab,
		                 DBA_SET_CONN | DBA_NO_CLOSE,
                         UNUSED,
                         &rowNb,
                         &connectNo) != RET_SUCCEED)
	    {
		    FREE_DYNST(getArgRec, Get_Arg);
		    FREE_DYNST(sClassifCompoRec, S_ClassifCompo);
		    return(RET_DBA_ERR_NODATA);
	    }

        if (cnxToCloseFlg == TRUE)
        {
            DBA_EndConnection(connectNo);
            connectNo = DBA_CONN_NOT_FOUND;
        }

        if(rowNb>0)
        {
		    TLS_Sort((char*)eClassifCompoPtrTab,
			         (unsigned)rowNb,
			         sizeof(DBA_DYNFLD_STP *),		/* size of Pointer */
			         (TLS_CMPFCT *)FIN_CmpEClassifCompoPtr,
			         (PTR **)NULL,
			         SortRtnTp_None);
        }

	    if(threadClassifStack != NULL)
	    {
            DBA_AddClassifToStack(threadClassifStack,
                                      eClassifCompoPtrTab,
                                      rowNb,
                                      classifId);
	    }
	}

    if (eClassifCompoPtrTab != NULL)
    {
	    for(i=0; i < rowNb && GET_ID(eClassifCompoPtrTab[i], E_ClassifCompo_ListId) != listId; i++);

	    if(i < rowNb && GET_ID(eClassifCompoPtrTab[i], E_ClassifCompo_ListId) == listId)
	    {
            *eClassifCompoStp = eClassifCompoPtrTab[i];
	    }
        else
        {
            *eClassifCompoStp = NULL;
        }
    }

	FREE_DYNST(getArgRec, Get_Arg);               /* REF9264 - LJE - 031003 */
	FREE_DYNST(sClassifCompoRec, S_ClassifCompo); /* REF9264 - LJE - 031003 */

    return (ret);

}

/************************************************************************
**
**  Function          :   FIN_Classify()
**
**  Description       :
**
**  Arguments         :
**
**  Return            :   RET_SUCCEED or error code
**
**  Last modification : 20.01.96 - PEC - Added test on return value of DBA_Get2()
**                                       Return RET_GEN_ERR_INVARG if no Classif founded.
**			REF4299 - SSO - 000329
**          20.07.00 - GRD/SME - REF5030.
**          REF5391 - SSO - 001107
**          PMSTA-12069 - 170511 - PMO : Connection leak when a classification is not found
**          PMSTA-17663 - 020414 - PMO : Warning message "Warning: object classification contains several other lists" is more than a warning as business results are wrong
**
*************************************************************************/
RET_CODE FIN_Classify(DICT_T                    entDictId,
		              ID_T                      objectId,
		              ID_T                      classifId,
		              DBA_DYNFLD_STP            evalRec,
		              DBA_DYNFLD_STP            outputRec,
		              PTR                       classifStackPtr,
		              DBA_HIER_HEAD_STP         hierHead,
                      DATETIME_STP              classifDateTime,
		              DBA_DYNFLD_STP            domainPtrParam,
                      FLAG_T                    buildListFlg,
                      FLAG_T                    useOptimFlg,    /* REF5621 SME */
                      int                       ,               /* SKE 000630 REF4888 */
                      int*                      allocConn,
					  FLAG_T*					OverrideApplForInstr,
					  DBA_DYNFLD_STP			InstrMktSegOverride,
					  FLAG_T					whereingridFlg)   /* SKE 000630 REF4888 */
{
	SCPT_CLASSIFSTACK_STP    classifStack            = (SCPT_CLASSIFSTACK_STP)classifStackPtr; /* REF7264 - LJE - 020128 */
	DBA_CLASSIFSTACKHEAD_STP threadClassifStack      = DBA_GetClassifStackHeadPtr();
	DBA_CLASSIFSTACK_STP     currentClassif          = (DBA_CLASSIFSTACK_STP)NULL;
	DBA_DYNFLD_STP          *eClassifCompoPtrTab     = NULLDYNSTPTR;
	DBA_DYNFLD_STP           askListCompo            = NULLDYNST;
	ID_T                     listId                  = (ID_T)0;
	int		                 rowNb                   = 0;
	int                      i=0; /* REF5391 - SSO - 001107 init to 0 */
    int                      j;  /* REF4299 - SSO - 000329 */
	char                     stopFlg;
	OBJECT_ENUM              entObjEnum;
	FLAG_T                   retFlag                 = FALSE;
	FLAG_T                   useHistoFlg             = FALSE;
/* 	int		enumListCpt;	REF4299 - SSO - 000329 */
	FLAG_T                   foundFlg                = FALSE;
    FLAG_T                   atLeastAnEnumFlg        = FALSE;
    FLAG_T                   cnxToCloseFlg           = FALSE;
	DBA_DYNFLD_STP           domainPtr               = domainPtrParam;

	/* BEGIN REF4299 - SSO - 000329 */
    char                     buffer[256]             = {0};
	OBJECT_ENUM              objectEn, dimObject	 = NullEntity;
    char                    *entitySqlName           = NULL;
	char                     unknown[]               = "Unknown";
	DBA_DYNFLD_STP           inputSt                 = NULLDYNST;
	DBA_DYNFLD_STP           sClassif                = NULLDYNST;
	/* END REF4299 - SSO - 000329 */
    int                      connectNo               = DBA_CONN_NOT_FOUND;   /* SKE 000630 REF4888 */
    MemoryPool               mp;


    if (domainPtr == NULLDYNST)
    {
        domainPtr = DBA_GetDomainPtr(NO_VALUE);
    }

	if(classifId == 0)
    {
        return(RET_SUCCEED);
    }

	if (allocConn != UNUSED)
	{
        connectNo = *allocConn;
	}

    DBA_DYNFLD_STP getOptiSt = mp.allocDynst(FILEINFO, Get_Arg);        /* REF5495 - DDV - 001205 */

	/* REF5537 - LJE - 011220 : If the instrument is generic -> get parent instr id for the test */
	DBA_GetObjectEnum(entDictId, &entObjEnum); /* REF11882 - CHU - 060828 : Moved call outside the condition for use in *else* part */
	if (objectId < 0)
	{
		if (entObjEnum == Instr)
		{
			if (evalRec == NULLDYNST)
			{
				if(hierHead == (DBA_HIER_HEAD_STP) NULL)
					hierHead = (DBA_HIER_HEAD_STP) DBA_GetHierOptiPtr();

				if(hierHead != (DBA_HIER_HEAD_STP) NULL)
				{
					DBA_GetRecPtrFromHierById(hierHead,
								  objectId,
								  GET_EDITGUIST(entObjEnum),
								  &evalRec);
				}
			}

			SET_ID(getOptiSt, Get_Arg_InstrId, objectId); /* REF11882 - CHU - 060828 */
			if (evalRec != NULL) /* PMSTA14589-CHU-120705 avoid server crash if null record */
			{
				objectId = GET_ID(evalRec, A_Instr_ParentInstrId);
			}
		}
	}
	/* < REF11882 - CHU - 060828 */
	else if (evalRec != NULLDYNST &&
			 entObjEnum == Instr &&
			 GET_ID(evalRec, A_Instr_Id) < 0)
	{
		if (CMP_ID(objectId, GET_ID(evalRec, A_Instr_ParentInstrId)) != 0)
		{
			entitySqlName = (char*)DBA_GetDictEntitySqlName(entObjEnum);
			if (entitySqlName == NULL)
			{
				entitySqlName = (char*)unknown;
			}
			sprintf(buffer, "Warning: Parent %s id (%" szFormatId") differs from the one being classified (%" szFormatId") (cannot classify object)",  /* DLA - PMSTA08801 - 100209 */
					entitySqlName,
					objectId,
					GET_ID(evalRec, A_Instr_ParentInstrId));
			MSG_SendMesg(RET_SRV_LIB_ERR_GENERAL, 0, FILEINFO, (char*)&buffer);
		}
		SET_ID(getOptiSt, Get_Arg_InstrId, GET_ID(evalRec, A_Instr_Id));
	}
	/* > REF11882 - CHU - 060828 */

    /***** memory optimisation (moved from script / REF5495 - DDV - 001205) *****/
	SET_DICT(getOptiSt, Get_Arg_EntDictId, entDictId);
	SET_ID(getOptiSt, Get_Arg_ObjId,     objectId);
	SET_ID(getOptiSt, Get_Arg_Id, 	    classifId);

    /* REF7395 - CSY - 020513 */
    /* REF7411 - LJE - 020813 : Move to SYB_FinAnalysisInitDomain
    if(domainPtr != NULLDYNST)
    {
        if(GET_DICT(domainPtr, A_Domain_InitialFctDictId) == DictFct_PtfStorage)
            SET_FLAG(domainPtr, A_Domain_HistListFlg, TRUE);
    }
    */

    if (buildListFlg == TRUE ||
        (domainPtr != NULLDYNST &&
         GET_FLAG(domainPtr, A_Domain_HistListFlg) == TRUE))
    {
        useHistoFlg = TRUE;
        askListCompo = mp.allocDynst(FILEINFO, S_ListCompo);

        SET_ID(askListCompo, S_ListCompo_ObjId, objectId);
		if(domainPtr != NULLDYNST)		/* MRA - 020913 */
			DBA_GetObjectEnum(GET_DICT(domainPtr, A_Domain_DimPtfDictId), &dimObject) ;
        /* For dislay Chrono use parameter date else use from date of domain */
        if (buildListFlg == TRUE ||
	    (domainPtr != NULLDYNST &&
	     GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_DisplayChrono ||
		 GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_DisplayComplianceChrono ||
	     GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_CompositeMgr ||
        (GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_PtfStorage &&
		 GET_ENUM(domainPtr, A_Domain_PtfConsRuleEn) == PtfConsRule_Merged && /* REF7423 - MCA - 0209010 */
		 dimObject == List)))
        {
		    if (classifDateTime != NULL &&
			    classifDateTime->date != BAD_DATE)
		    {
			    SET_DATETIME(askListCompo, S_ListCompo_ValidDt, *classifDateTime);
                SET_DATETIME(getOptiSt, Get_Arg_DateTime, *classifDateTime);
		    }
		    else
		    {
			    useHistoFlg = FALSE;
		    }
	    }
	    else
	    {
		    if ((domainPtr != NULLDYNST) &&		 /* MRA - 020913 */
				(IS_NULLFLD(domainPtr, A_Domain_InterpFromDate) == FALSE))
		    {
			    COPY_DYNFLD(askListCompo, S_ListCompo , S_ListCompo_ValidDt,
				    domainPtr,    A_Domain, A_Domain_InterpFromDate);
			    COPY_DYNFLD(getOptiSt, Get_Arg, Get_Arg_DateTime,
				    domainPtr,    A_Domain, A_Domain_InterpFromDate);
		    }
		    else
		    {
			    useHistoFlg = FALSE;
		    }
	    }
    }

    if (useOptimFlg == TRUE)    /* REF5621 SME */
    {
		/* REF11828 - RAK - 060608 - Add "businnes key" of ext_pos if not two ext_pos different can be regarded as identical */
		if (evalRec != NULLDYNST && entObjEnum == EPos) /* PMSTA-10070 - LJE - 101004 */
		{
			/* ptf_id, bp_id, open_op_id, instr_id, id */
			SET_ID(getOptiSt, Get_Arg_PtfId, GET_ID(evalRec, ExtPos_PtfId));
			SET_ID(getOptiSt, Get_Arg_InstrId, GET_ID(evalRec, ExtPos_InstrId));
			SET_ID(getOptiSt, Get_Arg_OpenOpId, GET_ID(evalRec, ExtPos_OpenOpId));
			SET_ID(getOptiSt, Get_Arg_BalPosTpId, GET_ID(evalRec, ExtPos_BalPosTpId));
		}

        /***** CHECK IN MEMORY *****/
        if(DBA_GetMemory( OptiFct,
                          UNUSED,
                          Get_Arg,
                          getOptiSt,
                          A_ClassifCompo,
                          outputRec,
                          (DBA_DYNFLD_STP *)NULL,
                          Opti_Local) == RET_SUCCEED)
        {
            return(RET_SUCCEED);
        }
    }

	/***** ALLOC LOCAL DYN STRUCTURES *****/
	DBA_DYNFLD_STP getArgRec	 = mp.allocDynst(FILEINFO,Get_Arg);
	DBA_DYNFLD_STP sClassifCompoRec = mp.allocDynst(FILEINFO,S_ClassifCompo);
	DBA_DYNFLD_STP ioIdRec 	 = mp.allocDynst(FILEINFO,Io_Id);

	/***** classifStack OPTIMISATION *****/
    if(threadClassifStack != (DBA_CLASSIFSTACKHEAD_STP) NULL)
	{
	    for(i=0; i < threadClassifStack->classifNbr &&
		    threadClassifStack->classifTab[i].classifId != classifId; i++);

	    if(i < threadClassifStack->classifNbr &&
           threadClassifStack->classifTab[i].classifId != 0)
	    {
		    foundFlg = TRUE;
		    eClassifCompoPtrTab = threadClassifStack->classifTab[i].eClassifCompoPtrTab;
		    rowNb = threadClassifStack->classifTab[i].totalListNb;
	        currentClassif = &(threadClassifStack->classifTab[i]);
	    }
	}
	else if(classifStack != (SCPT_CLASSIFSTACK_STP)NULL)
	{
	    for(i=0 ; classifStack[i].classifId != classifId &&
		      classifStack[i].classifId != 0 ; i++);

	    if(classifStack[i].classifId != 0)
	    {
		    foundFlg = TRUE;
		    eClassifCompoPtrTab = classifStack[i].eClassifCompoPtrTab;
		    rowNb = classifStack[i].totalListNb;
	    }
	    currentClassif = &(classifStack[i]);
	}

	if(foundFlg == FALSE)
	{
        /* <SKE 000630 REF4888 : to allow to use FIN_Classify() in transactional mode */
        /*
            TODO TODO TODO TODO :
            - manage the allocConn pointer argument (return the allocated connection if created
            inside FIN_Classify() ...)
            - Change DBA_Select2() to set connectNo to -1 when we do not
            set DBA_NO_CLOSE (in case of read opti find something ...)
        */

        if(connectNo == DBA_CONN_NOT_FOUND)
        {
            /* If a connection number is not given */
		    if ((connectNo = DBA_GetConnection(SqlServer)) == DBA_CONN_NOT_FOUND)
		    {
                MSG_RETURN(RET_DBA_ERR_CONNOTFOUND);
		    }

    /*
            selOptions |= DBA_SET_CONN | DBA_NO_CLOSE;
    */
            cnxToCloseFlg = TRUE;
        }
	    /***** SELECT ALL classif_compo FROM classif_id *****/
	    SET_ID (sClassifCompoRec, S_ClassifCompo_ClassifId, classifId);

	    /* REF3955 - SSO - 000112 added test */
	    if (DBA_Select2( ClassifCompo,
                         UNUSED,
		                 S_ClassifCompo,
                         sClassifCompoRec,
		                 E_ClassifCompo,
                         &eClassifCompoPtrTab,
		                 DBA_SET_CONN | DBA_NO_CLOSE,
                         UNUSED,
                         &rowNb,
                         &connectNo) != RET_SUCCEED)
	    {
            /* PMSTA-12069 - 170511 - PMO */
            if (cnxToCloseFlg == TRUE)
            {
                DBA_EndConnection(connectNo);
            }

		    return(RET_DBA_ERR_NODATA);
	    }

        /* <SKE 000630 REF4888 : to allow to use FIN_Classify() in transactional mode  */
        if (cnxToCloseFlg == TRUE)
        {
            DBA_EndConnection(connectNo);
            connectNo = DBA_CONN_NOT_FOUND;
    /*
			selOptions &= ~(DBA_SET_CONN | DBA_NO_CLOSE);
    */
        }
        /* SKE 000630 REF4888> */

        if(rowNb>0)
        {
		    TLS_Sort((char*)eClassifCompoPtrTab,
			         (unsigned)rowNb,
			         sizeof(DBA_DYNFLD_STP *),		/* size of Pointer */
			         (TLS_CMPFCT *)FIN_CmpEClassifCompoPtr, /* REF7264 - LJE - 020131 */
			         (PTR **)NULL,
			         SortRtnTp_None);
        }

	    if(threadClassifStack != (DBA_CLASSIFSTACKHEAD_STP)NULL)
	    {
            if (DBA_AddClassifToStack(threadClassifStack,
                                      eClassifCompoPtrTab,
                                      rowNb,
                                      classifId) == RET_SUCCEED)
                currentClassif = &(threadClassifStack->classifTab[threadClassifStack->classifNbr-1]);
	    }
	    else if(classifStack != (SCPT_CLASSIFSTACK_STP)NULL)
	    {
            /* YES IT'S TRUE !!!! */
			for(i=0 ; classifStack[i].classifId != 0 ; i++);
            /* YES IT'S TRUE !!!! */

			classifStack[i].classifId          = classifId;
			classifStack[i].eClassifCompoPtrTab = eClassifCompoPtrTab;
			classifStack[i].totalListNb         = rowNb;
            currentClassif = &(classifStack[i]);
	    }
	}

/* REF5391 - SSO - 001107 check empty classif ! */
    if (rowNb == 0)
    {
		inputSt = ALLOC_DYNST(Adm_Arg);
		sClassif = ALLOC_DYNST(S_Classif);
		SET_ID(inputSt, Adm_Arg_Id, classifId);
		if (DBA_Get2(Classif,
					 UNUSED,
					 Adm_Arg,
                     inputSt,
                     S_Classif,
                     &sClassif,
                     (connectNo != DBA_CONN_NOT_FOUND) ? DBA_SET_CONN | DBA_NO_CLOSE : UNUSED,
                     &connectNo) != RET_SUCCEED)
		{
			SET_CODE(sClassif, S_Classif_Cd,"Unknown");
		}

		DBA_GetObjectEnum(GET_DICT(sClassif, S_Classif_EntDictId), &objectEn);
		entitySqlName = (char*)DBA_GetDictEntitySqlName(objectEn);
		if (entitySqlName == NULL)
		{
			entitySqlName = (char*)unknown;
		}

		sprintf(buffer, "Warning: empty classification %s on entity %s (cannot classify object)",
				GET_CODE(sClassif, S_Classif_Cd), entitySqlName);
		MSG_SendMesg(RET_SRV_LIB_ERR_GENERAL, 0, FILEINFO, (char*)&buffer);

	    FREE_DYNST(inputSt, Adm_Arg);
	    FREE_DYNST(sClassif, S_Classif);
    }
    else
    {
        /* REF4299 - SSO - 000329 	enumListCpt = 0;*/
	    for(i=0; i<(rowNb-1) ; i++)
	    {
	        if ( ((LISTNAT_ENUM) GET_ENUM(eClassifCompoPtrTab[i],E_ClassifCompo_List_NatEn)==ListNat_Enum) ||
                 ((LISTNAT_ENUM) GET_ENUM(eClassifCompoPtrTab[i],E_ClassifCompo_List_NatEn)==ListNat_Query))
	        {
		        /* REF4299 - SSO - 000329 enumListCpt++; */
		        atLeastAnEnumFlg = TRUE;
		        break;
	        }
	    }

	    /***** TMP CLASSIFY ( GET list_id ) *****/
	    /* REF4299 - SSO - 000329 if(enumListCpt>0 -> atLeastAnEnumFlg == TRUE */
	    if(atLeastAnEnumFlg == TRUE && objectId != 0 && useHistoFlg == FALSE )
	    {
		    SET_ID(getArgRec, Get_Arg_Id,    classifId);
		    SET_ID(getArgRec, Get_Arg_ObjId, objectId);
		    /* REF4299 - SSO - 000329 added test */
		    if (DBA_Get2(List,     /* REF11767 - TGU - 060522 - since procedure has been moved to "List" object */
                         UNUSED,
                         Get_Arg,
                         getArgRec,
                         Io_Id,
                         &ioIdRec,
                         (connectNo != DBA_CONN_NOT_FOUND) ? DBA_SET_CONN | DBA_NO_CLOSE : UNUSED,
                         &connectNo) == RET_SUCCEED)
		    {
		        listId = GET_ID(ioIdRec, 0);
		    }
	    }

	    /***** SEARCH listId IN classif_compo LIST *****/
	    stopFlg=0;
	    for(i=0 ; i<(rowNb-1) ; i++)
	    {
	        switch((LISTNAT_ENUM) GET_ENUM(eClassifCompoPtrTab[i], E_ClassifCompo_List_NatEn))
	        {
	            case ListNat_Enum     :
	            case ListNat_Query    :
                    if (useHistoFlg == TRUE)
					{ /* REF7411 - LJE - 020318 */
                        if (DBA_CheckIfListHistorised(GET_ID(eClassifCompoPtrTab[i], E_ClassifCompo_ListId),
                                              (connectNo != DBA_CONN_NOT_FOUND) ? DBA_SET_CONN | DBA_NO_CLOSE : UNUSED, &connectNo) == TRUE)
						{

							SET_ID(askListCompo, S_ListCompo_Id,GET_ID(eClassifCompoPtrTab[i], E_ClassifCompo_ListId));
							if (DBA_Get2(ListCompo,
										 UNUSED,
										 S_ListCompo,
										 askListCompo,
										 Io_Id,
										 &ioIdRec,
										 (connectNo != DBA_CONN_NOT_FOUND) ? DBA_SET_CONN | DBA_NO_CLOSE : UNUSED,
										 &connectNo) == RET_SUCCEED)
							{
        						listId = GET_ID(eClassifCompoPtrTab[i], E_ClassifCompo_ListId);
								stopFlg = 1;
							}
						}
						else
						{
						    /* REF7411 - LJE - 020318 */
							DBA_DYNFLD_STP sListCompo=NULLDYNST, aListCompo=NULLDYNST;

						    if ((sListCompo = ALLOC_DYNST(S_ListCompo)) == NULLDYNST)
							{
								return(RET_SUCCEED);
							}

							if ((aListCompo = ALLOC_DYNST(A_ListCompo)) == NULLDYNST)
							{
								FREE_DYNST(sListCompo, S_ListCompo);
								return(RET_SUCCEED);
							}


							SET_ID(sListCompo, S_ListCompo_ObjId,     objectId);
							SET_ID(sListCompo, S_ListCompo_EntDictId, entDictId);
							SET_ID(sListCompo, S_ListCompo_Id,        GET_ID(eClassifCompoPtrTab[i], E_ClassifCompo_ListId));

							if (DBA_Get2(ListCompo,
									 UNUSED,
									 S_ListCompo,
									 sListCompo,
									 A_ListCompo,
									 &aListCompo,
									 (connectNo != DBA_CONN_NOT_FOUND) ? DBA_SET_CONN | DBA_NO_CLOSE : UNUSED,
									 &connectNo,
									 UNUSED) == RET_SUCCEED)
							{
								stopFlg=1;
							}

							FREE_DYNST(sListCompo, S_ListCompo);
							FREE_DYNST(aListCompo, A_ListCompo);
						}

                    }
                    else
                    {
	                    if(objectId !=0 && GET_ID(eClassifCompoPtrTab[i], E_ClassifCompo_ListId) == listId)
                        {
                            stopFlg = 1;
                        }
                    }
		            break;
				case ListNat_MktSegment:/* PMSTA-48148-SENTHIL-03032022 */
				{
					MemoryPool MktSegMpool;
					DBA_DYNFLD_STP           MktSegAttribRec = NULLDYNST;
					MktSegAttribRec = MktSegMpool.allocDynst(FILEINFO, S_MktSegAttribution);
					inputSt = MktSegMpool.allocDynst(FILEINFO, Adm_Arg);
					/* PMSTA-48407-SENTHIL-17032022 */
					if (hierHead == (DBA_HIER_HEAD_STP)NULL)
						hierHead = (DBA_HIER_HEAD_STP)DBA_GetHierOptiPtr();
					DBA_DYNFLD_STP MktSegmentTab = DBA_SearchHierRecById(hierHead, S_MktSegt, S_MktSegt_AbcissaListId,
						GET_ID(eClassifCompoPtrTab[i], E_ClassifCompo_ListId));
			
					DBA_DYNFLD_STP MktStructTab = NULLDYNST;
					if(MktSegmentTab!=NULL)
						MktStructTab = DBA_SearchHierRecById(hierHead, A_MktStruct, A_MktStruct_ParMktSegtId,
							GET_ID(MktSegmentTab, S_MktSegt_Id));
					DBA_DYNFLD_STP MktStructChildTab = NULLDYNST;
					MktStructChildTab = MktStructTab;
					while (MktStructChildTab !=nullptr)
					{
						MktStructTab = MktStructChildTab;
						MktStructChildTab = DBA_SearchHierRecById(hierHead, A_MktStruct, A_MktStruct_ParMktStructId,
							GET_ID(MktStructTab, A_MktStruct_Id));
					}
					SET_ID(inputSt, Adm_Arg_CodifId, (objectId));
					if (MktStructTab != NULL)
					{
						DBA_DYNFLD_STP      *dynTab = NULLDYNST;
						int                 dynNb;
						dynNb = GET_EXTENSION_NBR(MktStructTab, A_MktStruct_S_MktSegt_Ext);
						dynTab = GET_EXTENSION_PTR(MktStructTab, A_MktStruct_S_MktSegt_Ext);
						for (int d = 0; d < dynNb; d++)
						{
							SET_ID(inputSt, Adm_Arg_Id, GET_ID(dynTab[d], S_MktSegt_AbcissaListId));
							if (DBA_Get2(MktSegAttribution,
								UNUSED,
								Adm_Arg,
								inputSt,
								S_MktSegAttribution,
								&MktSegAttribRec,
								(connectNo != DBA_CONN_NOT_FOUND) ? DBA_SET_CONN | DBA_NO_CLOSE : UNUSED,
								&connectNo) == RET_SUCCEED)
							{
								listId = GET_ID(dynTab[d], S_MktSegt_AbcissaListId);
								stopFlg = 1;
								DBA_DYNFLD_STP  instrPtr = NULLDYNST;
								instrPtr = DBA_SearchHierRecById(hierHead, A_Instr,
									A_Instr_Id, objectId);
								SET_ID(instrPtr, A_Instr_StdMktSeg_Id, GET_ID(eClassifCompoPtrTab[i], E_ClassifCompo_ListId))
									break;
							}
						}
					}
					else
					{
						SET_ID(inputSt, Adm_Arg_Id, GET_ID(eClassifCompoPtrTab[i], E_ClassifCompo_ListId));
						if (DBA_Get2(MktSegAttribution,
							UNUSED,
							Adm_Arg,
							inputSt,
							S_MktSegAttribution,
							&MktSegAttribRec,
							(connectNo != DBA_CONN_NOT_FOUND) ? DBA_SET_CONN | DBA_NO_CLOSE : UNUSED,
							&connectNo) == RET_SUCCEED)
						{
							listId = GET_ID(eClassifCompoPtrTab[i], E_ClassifCompo_ListId);
							stopFlg = 1;
							/* PMSTA-48407-SENTHIL-17032022 */
							DBA_DYNFLD_STP  instrPtr = NULLDYNST;
							instrPtr = DBA_SearchHierRecById(hierHead, A_Instr,
								A_Instr_Id, objectId);
							SET_ID(instrPtr, A_Instr_StdMktSeg_Id, GET_ID(eClassifCompoPtrTab[i], E_ClassifCompo_ListId))

						}
						break;
					}
				}

	            case ListNat_Constr   :
	            case ListNat_Search   :	/* BUG150 pen 961001 */
			        if(objectId == 0)
				        break;

			        /* REF4306 - DDV - 000324 - if list is historised and hist_list_f is TRUE, check list_compo in database */
			        if (useHistoFlg == TRUE &&
				        DBA_CheckIfListHistorised(GET_ID(eClassifCompoPtrTab[i], E_ClassifCompo_ListId),
                        (connectNo != DBA_CONN_NOT_FOUND) ? DBA_SET_CONN | DBA_NO_CLOSE : UNUSED, &connectNo) == TRUE)
			        {
				        retFlag = FALSE;
				        SET_ID(askListCompo, S_ListCompo_Id,GET_ID(eClassifCompoPtrTab[i], E_ClassifCompo_ListId));
				        if (DBA_Get2(ListCompo,
                                     UNUSED,
                                     S_ListCompo,
                                     askListCompo,
							         Io_Id,
                                     &ioIdRec,
                                     (connectNo != DBA_CONN_NOT_FOUND) ? DBA_SET_CONN | DBA_NO_CLOSE : UNUSED,
                                     &connectNo) == RET_SUCCEED)
                        {
                            retFlag = TRUE;
                        }
			        }
			        else
			        {
                        FLAG_T flg; /* REF7411 - LJE - 020814 */

				        DBA_GetObjectEnum(GET_DICT(eClassifCompoPtrTab[i], E_ClassifCompo_List_EntDictId), &entObjEnum);

                        if (evalRec == NULLDYNST)
                        {
					        if(hierHead == (DBA_HIER_HEAD_STP) NULL)
						        hierHead = (DBA_HIER_HEAD_STP) DBA_GetHierOptiPtr();

					        if(hierHead != (DBA_HIER_HEAD_STP) NULL)
					        {
						        DBA_GetRecPtrFromHierById(hierHead,
									          objectId,
									          GET_EDITGUIST(entObjEnum),
									          &evalRec);
                            }
                        }

                        flg = (FLAG_T)(GET_FLAG(eClassifCompoPtrTab[i], E_ClassifCompo_List_HistoricalListFlg) && useHistoFlg==TRUE); /* REF9303 - LJE - 030910 */

				        SCPT_EvalConstList(GET_ID(eClassifCompoPtrTab[i], E_ClassifCompo_ListId),
								           entObjEnum,
								           objectId,
								           evalRec,
								           currentClassif,
								           &retFlag,
								           hierHead,
                                           classifDateTime,  /* REF7411 - LJE - 020806 */
                                           &flg,             /* REF7411 - LJE - 020814 */
                                           (connectNo != DBA_CONN_NOT_FOUND) ? DBA_SET_CONN | DBA_NO_CLOSE : UNUSED,
                                           &connectNo);
			        }

			        if(retFlag == TRUE)
			        {
				        listId = GET_ID(eClassifCompoPtrTab[i], E_ClassifCompo_ListId);
				        stopFlg = 1;
			        }
			        break;

	            case ListNat_Hierarch :
			        break;

	            case ListNat_Other    :
		        /* REF4299 - SSO - 000329 removed test : 1st encountered "other" is choosen */
        /*	        if(GET_ID(eClassifCompoPtrTab[i], E_ClassifCompo_ListId) == listId)
		        {*/
		            stopFlg = 1;
        /*		} */
			        break;
            }

	        if(stopFlg) break;
	    }

	    /***** IF NOT FOUND ... SET TO THE LAST list_id *****/
	    /* REF4299 - SSO - 000329 verify it's an "other" list
	      (i==rowNb) test was bad!  */
	    if (stopFlg == 0)
	    {
	        /* REF4299 - SSO - 000329  i--; commented out*/
	        if (GET_ENUM(eClassifCompoPtrTab[i], E_ClassifCompo_List_NatEn) != ListNat_Other)
	        {
			    inputSt = ALLOC_DYNST(Adm_Arg);
			    sClassif = ALLOC_DYNST(S_Classif);
			    SET_ID(inputSt, Adm_Arg_Id, classifId);
			    if (DBA_Get2(Classif,
					         UNUSED,
                             Adm_Arg,
                             inputSt,
                             S_Classif,
                             &sClassif,
                             (connectNo != DBA_CONN_NOT_FOUND) ? DBA_SET_CONN | DBA_NO_CLOSE : UNUSED,
                             &connectNo) != RET_SUCCEED)
			    {
				    SET_CODE(sClassif, S_Classif_Cd,"Unknown");
			    }

	            DBA_GetObjectEnum(GET_DICT(sClassif, S_Classif_EntDictId), &objectEn);
			    entitySqlName = (char*)DBA_GetDictEntitySqlName(objectEn);
			    if (entitySqlName == NULL)
			    {
			        entitySqlName = (char*)unknown;
			    }

			    sprintf(buffer, "Warning: object classified by default in a non-other list (Check classification %s on entity %s)",
					    GET_CODE(sClassif, S_Classif_Cd), entitySqlName);
			    MSG_SendMesg(RET_SRV_LIB_ERR_GENERAL, 0, FILEINFO, (char*)&buffer);

                /* REF5391 - SSO - 001107 fixed mem leak */
	            FREE_DYNST(inputSt, Adm_Arg);
	            FREE_DYNST(sClassif, S_Classif);
            }
	    }
	    else if (GET_ENUM(eClassifCompoPtrTab[i], E_ClassifCompo_List_NatEn) == ListNat_Other)
	    {
	        /* REF4299 - SSO - 000329 check there's an unique "other" list */
	        for (j=i+1; j<rowNb; j++)			/* PMSTA-18239 - CHANDRAKANT(chandrak) - 150817 */
	        {
			    if (GET_ENUM(eClassifCompoPtrTab[j], E_ClassifCompo_List_NatEn) == ListNat_Other)
			    {
				    inputSt = ALLOC_DYNST(Adm_Arg);
				    sClassif = ALLOC_DYNST(S_Classif);
				    SET_ID(inputSt, Adm_Arg_Id, classifId);
				    if (DBA_Get2(Classif,
						         UNUSED,
						         Adm_Arg,
                                 inputSt,
                                 S_Classif,
                                 &sClassif,
                                 (connectNo != DBA_CONN_NOT_FOUND) ? DBA_SET_CONN | DBA_NO_CLOSE : UNUSED,
                                 &connectNo) != RET_SUCCEED)
				    {
					    SET_CODE(sClassif, S_Classif_Cd,"Unknown");
				    }

				    DBA_GetObjectEnum(GET_DICT(sClassif, S_Classif_EntDictId), &objectEn);
				    entitySqlName = (char*)DBA_GetDictEntitySqlName(objectEn);
				    if (entitySqlName == NULL)
				    {
					    entitySqlName = (char*)unknown;
				    }

                    /* PMSTA-17663 - 020414 - PMO */
				    sprintf(buffer, "Error: object classification contains several other lists (Check classification %s on entity %s)",
					    GET_CODE(sClassif, S_Classif_Cd), entitySqlName);
				    MSG_SendMesg(RET_SRV_LIB_ERR_GENERAL, 0, FILEINFO, (char*)&buffer);

                    /* REF5391 - SSO - 001107 fixed mem leak */
	                FREE_DYNST(inputSt, Adm_Arg);
	                FREE_DYNST(sClassif, S_Classif);
			    }
	        }
	    }
    } /* REF5391 - SSO - 001107 */

	/* Temporary added by PEC - 20.05.96 */
	if (eClassifCompoPtrTab)
	{
		/* PMSTA-48148-SENTHIL-03032022 */
		DBA_DYNFLD_STP OvrMktSegPtr = NULLDYNST;
		FLAG_T OvrSegParentOfStdMktSegFlg = FALSE;
		if (GET_ENUM(eClassifCompoPtrTab[i], E_ClassifCompo_List_NatEn) == ListNat_MktSegment && whereingridFlg == FALSE)
		{
			int StratEltNbr = 0;
			DBA_DYNFLD_STP *StratEltTab = NULLDYNSTPTR;
			if (hierHead == (DBA_HIER_HEAD_STP)NULL)
				hierHead = (DBA_HIER_HEAD_STP)DBA_GetHierOptiPtr();
			if ((DBA_ExtractHierEltRec(hierHead, A_StratElt,
				FALSE, NULL, NULL, &StratEltNbr, &StratEltTab)) == RET_SUCCEED)
			{
				for (int k = 0; k < StratEltNbr; k++)
				{
					if (CMP_ID(GET_ID(StratEltTab[k], A_StratElt_InstrId), objectId) == 0)
					{
						DBA_DYNFLD_STP StdMktSegPtr;
						StdMktSegPtr = DBA_SearchHierRecById(hierHead, S_MktSegt, S_MktSegt_Id,
							GET_ID(StratEltTab[k], A_StratElt_StdMktSeg_Id));
						OvrMktSegPtr = DBA_SearchHierRecById(hierHead, S_MktSegt, S_MktSegt_Id,
							GET_ID(StratEltTab[k], A_StratElt_OverrideMktSeg_Id));
						/* PMSTA-48407-SENTHIL-17032022 */
						/*To handle the scenario where instrument override is defined from child market structure to parent market structure*/
						/*----------------------------------------------------------------------------------------------------*/
						DBA_DYNFLD_STP MktStructTab = NULLDYNST;
						if (OvrMktSegPtr != NULL)
							MktStructTab = DBA_SearchHierRecById(hierHead, A_MktStruct, A_MktStruct_ParMktStructId,
								GET_ID(OvrMktSegPtr, S_MktSegt_MktStructId));
						while (OvrSegParentOfStdMktSegFlg == FALSE && MktStructTab != NULL)
						{
							if (MktStructTab != NULL && StdMktSegPtr != NULL && CMP_ID(GET_ID(MktStructTab, A_MktStruct_Id), GET_ID(StdMktSegPtr, S_MktSegt_MktStructId)) == 0)
							{
								MemoryPool MktSegMemPool;
								DBA_DYNFLD_STP           MktSegAttribRec = NULLDYNST;
								MktSegAttribRec = MktSegMemPool.allocDynst(FILEINFO, S_MktSegAttribution);
								inputSt = MktSegMemPool.allocDynst(FILEINFO, Adm_Arg);
								SET_ID(inputSt, Adm_Arg_CodifId, (objectId));
								SET_ID(inputSt, Adm_Arg_Id, GET_ID(StdMktSegPtr, S_MktSegt_AbcissaListId));
								if (DBA_Get2(MktSegAttribution,
									UNUSED,
									Adm_Arg,
									inputSt,
									S_MktSegAttribution,
									&MktSegAttribRec,
									(connectNo != DBA_CONN_NOT_FOUND) ? DBA_SET_CONN | DBA_NO_CLOSE : UNUSED,
									&connectNo) == RET_SUCCEED)
								{
									OvrSegParentOfStdMktSegFlg = TRUE;
								}
								break;
							}
							else
								MktStructTab = DBA_SearchHierRecById(hierHead, A_MktStruct, A_MktStruct_ParMktStructId,
									GET_ID(MktStructTab, A_MktStruct_Id));
						}
						/*----------------------------------------------------------------------------------------------------*/
						/*To handle the scenario where instrument override is defined from parent market structure to child market structure*/
						DBA_DYNFLD_STP Override_ParentOvrMktSeg = NULLDYNST;
						if (OvrMktSegPtr != nullptr)
							Override_ParentOvrMktSeg = DBA_SearchHierRecById(hierHead, S_MktSegt, S_MktSegt_Id,
								GET_ID(OvrMktSegPtr, S_MktSegt_ParMktSegtId));
						/*----------------------------------------------------------------------------------------------------*/
						DBA_DYNFLD_STP  instrPtr = NULLDYNST;
						instrPtr = DBA_SearchHierRecById(hierHead, A_Instr,
							A_Instr_Id, objectId);
						DBA_DYNFLD_STP Instr_StdMktSeg;
						Instr_StdMktSeg = DBA_SearchHierRecById(hierHead, S_MktSegt, S_MktSegt_AbcissaListId,
							GET_ID(instrPtr, A_Instr_StdMktSeg_Id));

						if (StdMktSegPtr != NULL && OvrMktSegPtr != NULL && Instr_StdMktSeg != NULL && (CMP_ID(GET_ID(StdMktSegPtr, S_MktSegt_AbcissaListId), GET_ID(Instr_StdMktSeg, S_MktSegt_AbcissaListId)) == 0 || OvrSegParentOfStdMktSegFlg == TRUE))
						{
							FLAG_T Classiffound = FALSE;
							for (i = 0; i < (rowNb - 1); i++)
							{
								if ((Override_ParentOvrMktSeg != nullptr && CMP_ID(GET_ID(Override_ParentOvrMktSeg, S_MktSegt_AbcissaListId), GET_ID(eClassifCompoPtrTab[i], E_ClassifCompo_ListId)) == 0) || (CMP_ID(GET_ID(OvrMktSegPtr, S_MktSegt_AbcissaListId), GET_ID(eClassifCompoPtrTab[i], E_ClassifCompo_ListId)) == 0) || OvrSegParentOfStdMktSegFlg == TRUE)
								{
									if (OverrideApplForInstr != nullptr)
										*OverrideApplForInstr = TRUE;
									Classiffound = TRUE;
									break;
								}
							}
							if (Classiffound == TRUE)
								break;
						}
					}
				}
			}
			if(StratEltTab != NULLDYNSTPTR)
				FREE(StratEltTab);
		}
		SET_ID(outputRec, A_ClassifCompo_ClassifId, classifId);
		SET_ID(outputRec, A_ClassifCompo_ListId, GET_ID(eClassifCompoPtrTab[i], E_ClassifCompo_ListId));
		SET_SMALLINT(outputRec, A_ClassifCompo_Rank, GET_SMALLINT(eClassifCompoPtrTab[i], E_ClassifCompo_Rank));
		SET_SMALLINT(outputRec, A_ClassifCompo_Priority, GET_SMALLINT(eClassifCompoPtrTab[i], E_ClassifCompo_Priority));
		
		/* PMSTA-48407-SENTHIL-17032022 */
		if (OvrSegParentOfStdMktSegFlg == TRUE && *OverrideApplForInstr == TRUE)
			SET_ID(outputRec, A_ClassifCompo_ListId, GET_ID(OvrMktSegPtr, S_MktSegt_AbcissaListId));
	}

	/***** FREE LOCAL DYN STRUCTURES *****/
	if(threadClassifStack == (DBA_CLASSIFSTACKHEAD_STP)NULL &&
	   classifStack == (SCPT_CLASSIFSTACK_STP)NULL)
	    DBA_FreeDynStTab(eClassifCompoPtrTab, rowNb, E_ClassifCompo);

    if (useOptimFlg == TRUE)    /* REF5621 SME */
    {
        DBA_SetMemory(OptiFct,
                      UNUSED,
                      Get_Arg,
                      getOptiSt,
                      A_ClassifCompo,
                      outputRec,
                      Opti_Local);
    }

    /* <SKE 000630 : to allow to use FIN_Classify() in transactional mode */
	/* Free the connection if it must be closed
	if((selOptions & DBA_NO_CLOSE) != DBA_NO_CLOSE)
    {
        if (connectNo != DBA_CONN_NOT_FOUND)
        {
		    DBA_EndConnection(connectNo);
            connectNo = DBA_CONN_NOT_FOUND;
        }
    }
	if (allocConn != UNUSED)
	{
		*allocConn = connectNo;
	}
    SKE 000630> */

	return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    : FIN_IsInList
**
**  Description : test if an object belongs to a list
**
**
**
**
**  Arguments   : hierHead: hierarchy pointer
**                instrId:  id of an instrument
**                listId:   id of a list
**
**  Return      : RET_SUCCEED or error code
**
**  Creation    : REF6082 - CSY - 010905
**  Modification: REF7506 - DDV - 020606 - Modify to centralise code for functions SCPT_ExecIsInListFct and FIN_CehckInstrDim
**
*************************************************************************/
RET_CODE FIN_IsInList(DBA_HIER_HEAD_STP  hierHead,
                      ID_T               objectId,
                      DBA_DYNFLD_STP     record,
                      OBJECT_ENUM	     objectEnum,
                      ID_T               listId,
                      DBA_DYNFLD_STP     *listPtr,
                      int                *connectNoParam,
                      FLAG_T             listHistoFlgParam,
                      DATETIME_STP       dateHisto,
                      FLAG_T             *resultFlg,
                      DBA_DYNFLD_STP     aPtfStp)
{
    RET_CODE ret = RET_SUCCEED;
	LISTNAT_ENUM	listNatEnum;
    DBA_DYNFLD_STP	hierFoundRec = NULLDYNST;
    DBA_DYNFLD_STP	sListCompo = NULLDYNST;
	DBA_DYNFLD_STP	aListCompo = NULLDYNST;
    DBA_DYNFLD_STP	sList = NULLDYNST;
	DBA_DYNFLD_STP	aList = NULLDYNST;
	DBA_DYNFLD_STP	ioIdRec = NULLDYNST;
    DICT_T		entDictId = 0;
    int		connectNo    = NO_VALUE, getOptions = UNUSED;    /* REF3751 - SSO - 990625 */
    FLAG_T          listHistoFlg=listHistoFlgParam;
    FLAG_T          histListFlg=FALSE; /* REF7411 - LJE - 020807 */


	if (resultFlg == NULL)
	{
		return(RET_SUCCEED);
	}

	*resultFlg = FALSE;

	if (connectNoParam != NULL && *connectNoParam != NO_VALUE)
	{
		getOptions = DBA_SET_CONN | DBA_NO_CLOSE;
        connectNo = *connectNoParam;
	}
	else
	{
		getOptions = UNUSED;
	}

    if (listPtr == NULL ||
        (*listPtr) == NULLDYNST ||
        GET_ID((*listPtr), A_List_Id) != listId)
    {
        if ((sList = ALLOC_DYNST(S_List)) == NULLDYNST)
	    {
		    return(RET_SUCCEED);
	    }

	    if ((aList = ALLOC_DYNST(A_List)) == NULLDYNST)
	    {
		    FREE_DYNST(sList, S_List);
		    return(RET_SUCCEED);
	    }

	    SET_ID(sList, S_List_Id, listId);

	    /* Retrieve the list. */
	    if (DBA_Get2(List, UNUSED, S_List, sList, A_List, &aList, getOptions, &connectNo, UNUSED) != RET_SUCCEED)
	    {
		    FREE_DYNST(sList, S_List);
		    FREE_DYNST(aList, A_List);
		    return(RET_SUCCEED);
	    }

        if (listPtr != NULL)
        {
            if ((*listPtr) == NULLDYNST)
            {
	            if (((*listPtr) = ALLOC_DYNST(A_List)) == NULLDYNST)
	            {
		            FREE_DYNST(sList, S_List);
    		        FREE_DYNST(aList, A_List);
		            return(RET_SUCCEED);
	            }
	        }

            if (GET_ID((*listPtr), A_List_Id) != listId)
            {
                COPY_DYNST((*listPtr), aList, A_List);
            }
        }

        listNatEnum = (LISTNAT_ENUM)GET_ENUM(aList, A_List_NatEn);
	    entDictId   = GET_DICT(aList, A_List_EntityDictId);	    /* REF5537 - LJE - 011220 */
        histListFlg = GET_FLAG(aList, A_List_HistoricalListFlg); /* REF7411 - LJE - 020807 */
    }
    else /* REF7411 - LJE - 020806 */
    {
        listNatEnum = (LISTNAT_ENUM)GET_ENUM((*listPtr), A_List_NatEn);
	    entDictId   = GET_DICT((*listPtr),   A_List_EntityDictId);
        histListFlg = GET_FLAG((*listPtr), A_List_HistoricalListFlg); /* REF7411 - LJE - 020807 */
    }


	FREE_DYNST(sList, S_List);
	FREE_DYNST(aList, A_List);

    if (record == NULLDYNST)
    {
	    if(DBA_GetRecPtrFromHierById(hierHead, objectId, GET_EDITGUIST(objectEnum), &hierFoundRec) != RET_SUCCEED)
	    {
    		if (objectId <= 0)
		    {
    			return(RET_SUCCEED);
	    	}
	    }
    }
    else
    {
        hierFoundRec = record;
    }

	if(listHistoFlg == TRUE)
	{
		listHistoFlg = FALSE;

    	if ((sListCompo = ALLOC_DYNST(S_ListCompo)) == NULLDYNST)
	    {
   		    MSG_RETURN(RET_MEM_ERR_ALLOC);
	    }

        if ((ioIdRec = ALLOC_DYNST(Io_Id)) == NULLDYNST)
	    {
            FREE_DYNST(sListCompo, S_ListCompo);
   		    MSG_RETURN(RET_MEM_ERR_ALLOC);
	    }

        SET_ID(sListCompo, S_ListCompo_Id, listId);
        if (DBA_Get2(ListCompo, UNUSED, S_ListCompo, sListCompo,
                             Io_Id, &ioIdRec, getOptions, &connectNo, UNUSED) == RET_SUCCEED)
		{
            listHistoFlg = TRUE;
		}
        else
        {
            FREE_DYNST(ioIdRec, Io_Id);
            FREE_DYNST(sListCompo, S_ListCompo);
        }
    }

    if (listHistoFlg == TRUE)
    {
		/* REF8621 - DDV - 040225 - If the instrument is generic -> get parent instr id for the test */
		if (objectEnum == Instr && objectId < 0)
		{
			objectId = GET_ID(hierFoundRec, A_Instr_ParentInstrId);
		}

        SET_ID(sListCompo, S_ListCompo_ObjId, objectId);
        SET_DATETIME(sListCompo, S_ListCompo_ValidDt, *dateHisto );

        if (DBA_Get2(ListCompo, UNUSED, S_ListCompo, sListCompo,
                     Io_Id, &ioIdRec, getOptions, &connectNo, UNUSED) == RET_SUCCEED)
    	    (*resultFlg) = TRUE;

        FREE_DYNST(ioIdRec, Io_Id);
        FREE_DYNST(sListCompo, S_ListCompo);
    }
    else
    {
        FLAG_T flg;

        /* Verify if the object belongs to the list */
	    switch((LISTNAT_ENUM)listNatEnum)
	    {
		    case ListNat_Constr:
		    case ListNat_Search:

                flg = (FLAG_T)(histListFlg==TRUE && listHistoFlgParam==TRUE); /* REF7411 - LJE - 020814 */

                SCPT_EvalConstList(listId,
                                   objectEnum,
                                   objectId,
                                   hierFoundRec,
                                   NULL,
                                   resultFlg,
                                   hierHead,
                                   dateHisto, /* REF7411 - LJE - 020806 */
                                   &flg, /* REF7411 - LJE - 020814 */
                                   getOptions,
                                   &connectNo, 
                                   aPtfStp);
			    break;

		    case ListNat_Hierarch:
		    case ListNat_Enum:
		    case ListNat_Query:
			    if ((sListCompo = ALLOC_DYNST(S_ListCompo)) == NULLDYNST)
			    {
				    return(RET_SUCCEED);
			    }

			    if ((aListCompo = ALLOC_DYNST(A_ListCompo)) == NULLDYNST)
			    {
				    FREE_DYNST(sListCompo, S_ListCompo);
				    return(RET_SUCCEED);
			    }

			    /* REF5537 - LJE - 011220 : If the instrument is generic -> get parent instr id for the test */
			    if (objectEnum == Instr && objectId < 0)
			    {
				    objectId = GET_ID(hierFoundRec, A_Instr_ParentInstrId);
			    }

			    SET_DICT(sListCompo, S_ListCompo_EntDictId, entDictId);
			    SET_ID(sListCompo, S_ListCompo_Id,        listId);
			    SET_ID(sListCompo, S_ListCompo_ObjId,     objectId);

                /* REF6082 - CSY - 011016: code coming from SCPT_ExecIsInListFct,
                but here, we don't have genContext argument */
			    /* REF3751 - SSO - 990625 : if coming from SCPT_EvalCstList, must use the transaction conn. ! */


			    if (DBA_Get2(ListCompo,
				         UNUSED,
				         S_ListCompo,
				         sListCompo,
				         A_ListCompo,
				         &aListCompo,
				         getOptions, /* REF3751 - SSO - 990625 */
				         &connectNo, /* REF3751 - SSO - 990625 */
				         UNUSED) != RET_SUCCEED)
			    {
				    FREE_DYNST(sListCompo, S_ListCompo);
				    FREE_DYNST(aListCompo, A_ListCompo);
                    *resultFlg = FALSE;
				    return(RET_SUCCEED);
			    }

			    FREE_DYNST(sListCompo, S_ListCompo);
			    FREE_DYNST(aListCompo, A_ListCompo);
			    *resultFlg = TRUE;
			    break;
    	}
	}
    return(ret);
}

/************************************************************************
**
**  Function    :   FIN_CmpEClassifCompoPtr()
**
**  Description :
**
**  Arguments   :
**
**  Return      :   RET_SUCCEED or error code
**
*************************************************************************/
STATIC int FIN_CmpEClassifCompoPtr(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
	/* E_ClassifCompo */

	if(GET_SMALLINT((*ptr1), E_ClassifCompo_Priority) ==
		GET_SMALLINT((*ptr2), E_ClassifCompo_Priority))
		return(0);

	else
		if(GET_SMALLINT((*ptr1), E_ClassifCompo_Priority) <
			GET_SMALLINT((*ptr2), E_ClassifCompo_Priority))
			return(-1);
		else
			return(1);
}

/************************************************************************
*
*  Function          : FIN_CompInstrChrono()
*
*  Description       : this function computes chronological data
*
*  Arguments         : compInstrChronoSt : dynamic structure A_CompInstrChrono
*
*  Return            : RET_SUCCEED
*
*  Creation date     : 26.11.96 - PEC - Ref.: DVP268
*  Last modification :
*
************************************************************************/
RET_CODE FIN_CompInstrChrono(DBA_DYNFLD_STP compInstrChronoSt)
{
	OBJECT_ENUM         dimObject;
	DBA_DYNFLD_STP      aInstrChrono;
	DBA_DYNFLD_STP      *ioIdTab;
	DBA_DYNFLD_STP      sInstrChrono;
	DBA_DYNFLD_STP      admArg;
	DBA_ACCESS_STP      accessTab;
	int                 cpt, i, dataNbr;
	DBA_ACTION_ENUM     action=NullAction;
    SCPT_DFLTVAL_STP    dfltValStPtr;
	FLAG_T              *forcedFlgTab;
	RET_CODE            ret;
    DbiConnectionHelper dbiConnHelper;

    if (!dbiConnHelper.isValidAndInit())
    {
        return RET_DBA_ERR_CONNOTFOUND;
    }

	DBA_GetObjectEnum(GET_DICT(compInstrChronoSt, A_CompInstrChrono_EntDictId),
	                  &dimObject);

	if (dimObject != List && dimObject != Instr)
		return(RET_GEN_ERR_INVARG);

	switch(GET_FLAG(compInstrChronoSt, A_CompInstrChrono_DeleteFlg))
	{
	case FALSE:                     /* Chronological data must be inserted/updated */
        /* REF8844 - LJE - 030415 */
		if (dimObject == Instr)
        {
			aInstrChrono = ALLOC_DYNST(A_InstrChrono);

			SET_ID(aInstrChrono, A_InstrChrono_InstrId,
			             GET_ID(compInstrChronoSt, A_CompInstrChrono_ObjId));
			SET_ENUM(aInstrChrono, A_InstrChrono_NatEn,
			             GET_ENUM(compInstrChronoSt, A_CompInstrChrono_NatEn));
			SET_DATETIME(aInstrChrono, A_InstrChrono_ValidDate,
			             GET_DATETIME(compInstrChronoSt, A_CompInstrChrono_CalcDate));

			forcedFlgTab = (unsigned char *)CALLOC(GET_FLD_NBR(A_InstrChrono), sizeof(FLAG_T)); /* REF7264 - LJE - 020128 */

			SCPT_InitEntityDefVal(InstrChrono, &dfltValStPtr, FALSE, 0);

			/* Fix the values of forced fields */
			forcedFlgTab[A_InstrChrono_InstrId]   = TRUE;
			forcedFlgTab[A_InstrChrono_NatEn]     = TRUE;
			forcedFlgTab[A_InstrChrono_ValidDate] = TRUE;

			SCPT_AnalyseEntityDefVal(dfltValStPtr,
									 forcedFlgTab,
                                     NULL,              /* HFI-PMSTA-25327-171023  Dedicated flag tab for filter    */
									 aInstrChrono,
									 TRUE,
                                     EvalType_DefVal, /* ROI - 000328 - REF4497 */    /*  FPL-REF9507-030930  Replace FALSE by EvalType_DefVal    */
                                     NULL,
                                     NULL,
                                     FALSE  /* FPL-REF9215-030811 */
									);

			SCPT_FreeEntityDefVal(dfltValStPtr);

			if (IS_NULLFLD(aInstrChrono, A_InstrChrono_Val) == TRUE)
			{
				FREE(forcedFlgTab);
				FREE_DYNST(aInstrChrono, A_InstrChrono);
				return(RET_SUCCEED);
			}

			switch(GET_FLAG(compInstrChronoSt, A_CompInstrChrono_ForceFlg))
			{
			case FALSE:               /* An Insert action must be executed */
				DBA_Insert2(InstrChrono,
				            UNUSED,
				            A_InstrChrono,
				            aInstrChrono,
				            UNUSED,
                            *dbiConnHelper.getConnection(),
				            UNUSED);
				break;

			case TRUE:                        /* An Insert/Update action must be executed */
				ret = DBA_Insert2(InstrChrono,
				                  UNUSED,
				                  A_InstrChrono,
				                  aInstrChrono,
				                  UNUSED,
				                  *dbiConnHelper.getConnection(),
				                  UNUSED);

				if (ret == RET_SRV_LIB_ERR_DUPLICATEKEY)
					DBA_Update2(InstrChrono,
				                  UNUSED,
				                  A_InstrChrono,
				                  aInstrChrono,
				                  UNUSED,
                                  *dbiConnHelper.getConnection(),
				                  UNUSED);

				break;
			}

			FREE_DYNST(aInstrChrono, A_InstrChrono);
			FREE(forcedFlgTab);

        }
        else if (dimObject == List)
        {

			admArg = ALLOC_DYNST(Adm_Arg);

            DBA_SelectByListId(GET_ID(compInstrChronoSt, A_CompInstrChrono_ObjId),
                Instr,
                UNUSED,
                Adm_Arg, admArg,
                Io_Id, &ioIdTab,
                DBA_SET_CONN | DBA_NO_CLOSE,
                UNUSED,
                &dataNbr,
                (int*)&dbiConnHelper.getConnection()->getId());

			FREE_DYNST(admArg, Adm_Arg);

			if (dataNbr <= 0)
				return(RET_SUCCEED);

			accessTab = (DBA_ACCESS_STP)CALLOC(dataNbr, sizeof(DBA_ACCESS_ST)); /* REF7264 - LJE - 020128 */

			switch(GET_FLAG(compInstrChronoSt, A_CompInstrChrono_ForceFlg))
			{
			case FALSE:
				action = Insert;
				break;
			case TRUE:
				action = InsUpd;
				break;
			}

			forcedFlgTab = (unsigned char *)CALLOC(GET_FLD_NBR(A_InstrChrono), sizeof(FLAG_T)); /* REF7264 - LJE - 020128 */
			SCPT_InitEntityDefVal(InstrChrono, &dfltValStPtr, FALSE, 0);
			cpt = 0;

			aInstrChrono = ALLOC_DYNST(A_InstrChrono);

			/* Fix the values of forced fields */
			forcedFlgTab[A_InstrChrono_InstrId]   = TRUE;
			forcedFlgTab[A_InstrChrono_NatEn]     = TRUE;
			forcedFlgTab[A_InstrChrono_ValidDate] = TRUE;

			for (i=0 ; i<dataNbr ; i++)
			{
				SET_ID(aInstrChrono, A_InstrChrono_InstrId,
				         GET_ID(ioIdTab[i], Io_Id_Id));
				SET_ENUM(aInstrChrono, A_InstrChrono_NatEn,
				         GET_ENUM(compInstrChronoSt, A_CompInstrChrono_NatEn));
				SET_DATETIME(aInstrChrono, A_InstrChrono_ValidDate,
				         GET_DATETIME(compInstrChronoSt, A_CompInstrChrono_CalcDate));

				SCPT_AnalyseEntityDefVal(dfltValStPtr,
				                         forcedFlgTab,
                                         NULL,              /* HFI-PMSTA-25327-171023  Dedicated flag tab for filter    */
				                         aInstrChrono,
				                         TRUE,
                                         EvalType_DefVal, /* ROI - 000328 - REF4497 */    /*  FPL-REF9507-030930  Replace FALSE by EvalType_DefVal    */
                                         NULL,
                                         NULL,
                                         FALSE  /* FPL-REF9215-030811 */
										);

				if (IS_NULLFLD(aInstrChrono, A_InstrChrono_Val) == FALSE)
				{
					accessTab[cpt].action = action;
					accessTab[cpt].role   = UNUSED;
					accessTab[cpt].object = InstrChrono;
					accessTab[cpt].entity = A_InstrChrono;
					accessTab[cpt].data   = aInstrChrono;
					aInstrChrono          = ALLOC_DYNST(A_InstrChrono);
					cpt++;
				}

				FREE_DYNST(ioIdTab[i], Io_Id);
			}

			SCPT_FreeEntityDefVal(dfltValStPtr);
			FREE(ioIdTab);
			FREE(forcedFlgTab);

            {
                DbaMultiAccessHelper       multiAccessHelper(accessTab, cpt);

                if (multiAccessHelper.callMultiAccess(200, UNUSED, *dbiConnHelper.getConnection(), true) != RET_SUCCEED)
                {
                    multiAccessHelper.sendAllMultiAccessMsg();
                }
            }

            for (i=0 ; i<cpt ; i++)
			{
				FREE_DYNST(accessTab[i].data, A_InstrChrono);
			}
			FREE(accessTab);

		}

		break;

	case TRUE:                    /* Chronological data must be deleted */
        /* REF8844 - LJE - 030415 */
		if (dimObject == Instr)
        {


			sInstrChrono = ALLOC_DYNST(A_InstrChrono);

			SET_ID(sInstrChrono, A_InstrChrono_InstrId,
			             GET_ID(compInstrChronoSt, A_CompInstrChrono_ObjId));
			SET_ENUM(sInstrChrono, A_InstrChrono_NatEn,
			             GET_ENUM(compInstrChronoSt, A_CompInstrChrono_NatEn));
			SET_DATETIME(sInstrChrono, A_InstrChrono_ValidDate,
			             GET_DATETIME(compInstrChronoSt, A_CompInstrChrono_CalcDate));

			DBA_Delete2(InstrChrono,
			            UNUSED,
			            S_InstrChrono,
			            sInstrChrono,
			            UNUSED,
                        *dbiConnHelper.getConnection(),
			            UNUSED);

			FREE_DYNST(sInstrChrono, S_InstrChrono);


        }
        else if (dimObject == List)
        {


			admArg = ALLOC_DYNST(Adm_Arg);

			SET_ID(admArg, Adm_Arg_Id, GET_ID(compInstrChronoSt, A_CompInstrChrono_ObjId));

			DBA_SelectByListId(GET_ID(compInstrChronoSt, A_CompInstrChrono_ObjId),
			                   Instr,
			                   UNUSED,
			                   Adm_Arg, admArg,
			                   Io_Id,   &ioIdTab,
			                   DBA_SET_CONN | DBA_NO_CLOSE,
			                   UNUSED,
			                   &dataNbr,
                               (int*)&dbiConnHelper.getConnection()->getId());

			FREE_DYNST(admArg, Adm_Arg);

			if (dataNbr <= 0)
				return(RET_SUCCEED);

			accessTab = (DBA_ACCESS_STP)CALLOC(dataNbr, sizeof(DBA_ACCESS_ST));	/* REF7264 - LJE - 020128 */

			for (i=0 ; i<dataNbr ; i++)
			{
				accessTab[i].action = Delete;
				accessTab[i].role   = UNUSED;
				accessTab[i].object = InstrChrono;
				accessTab[i].entity = S_InstrChrono;
				accessTab[i].data   = ALLOC_DYNST(S_InstrChrono);

				SET_ID(accessTab[i].data, S_InstrChrono_InstrId,
				         GET_ID(ioIdTab[i], Io_Id_Id));
				SET_ENUM(accessTab[i].data, S_InstrChrono_NatEn,
				         GET_ENUM(compInstrChronoSt, A_CompInstrChrono_NatEn));
				SET_DATETIME(accessTab[i].data, S_InstrChrono_ValidDate,
				         GET_DATETIME(compInstrChronoSt, A_CompInstrChrono_CalcDate));

				FREE_DYNST(ioIdTab[i], Io_Id);
			}

			FREE(ioIdTab);

            {
                DbaMultiAccessHelper       multiAccessHelper(accessTab, dataNbr);

                if (multiAccessHelper.callMultiAccess(200, UNUSED, *dbiConnHelper.getConnection(), true) != RET_SUCCEED)
                {
                    multiAccessHelper.sendAllMultiAccessMsg();
                }
            }

            for (i=0 ; i<dataNbr ; i++)
			{
				FREE_DYNST(accessTab[i].data, S_InstrChrono);
			}
			FREE(accessTab);
			FREE_DYNST(admArg, Adm_Arg);


        }

        break;
	}

	return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_CrtYield()
**
**  Description :   This function calculates the current yield (or return)
**                  of an instrument. The current yield is the ratio of
**                  the annualised current income to the current price.
**
**  Arguments   :   instrId       instrument identifier
**                  inputInstrPtr ptr on instrument structure or NULL
**                  refDate       reference date
**                  divProjFlg    dividend projection flag
**
**  Return      :   TLS_Sort() comparison function return
**
**  Creation    :   DVP050 - RAK - 960408
**
**  Modif       :   BUG049 - RAK - 960708
**                  BUG056 - RAK - 960710
**                  BUG387 - RAK - 970602
**                  REF1384 - RAK - 980313
**  Modif.	    :   REF2580 - SSO - 980727
**                  REF4075 - CSY - 991109 new argument EVTDATERULE_ENUM in call of FIN_InstrFlow
**                  REF10256 - TEB - 040615
**
*************************************************************************/
RET_CODE FIN_CrtYield(ID_T              instrId,
		      DBA_DYNFLD_STP    inputInstrPtr,
		      DATETIME_T        refDate,
		      FIN_CRTYIELD_STP  crtYieldPtr,
		      NUMBER_T          *crtYield,
		      DBA_HIER_HEAD_STP hierHead)
{
	DBA_DYNFLD_STP   instrPtr       = NULLDYNST,
					 outputFlow     = NULLDYNST,
					 pricePtr       = NULLDYNST,
					 uInterPtr      = NULLDYNST;
	INSTRNAT_ENUM    instrNat       = InstrNat_None;
	TIMEDIM_ENUM     timeDimEn      = TimeDim_Next;
	FLOWSUBNAT_ENUM  flowSubNatEn   = FlowSubNat_Any;
	FLOWNAT_ENUM     flowNatEn      = FlowNat_Any;
	FUSDATERULE_ENUM sysFusDateRule = FusDateRule_None;
	FLAG_T			 fullCoupFlg    = FALSE;
	EXCHANGE_T       exch           = 0;
	NUMBER_T         income         = 0,
					 price          = 0,
					 unitInter      = 0;
	FLAG_T           allocOk        = FALSE,
					 flowOk         = FALSE;
	double           period         = 0;
	RET_CODE         ret            = RET_SUCCEED;
	FIN_EXCHARG_ST   exchArgSt;			/* REFXZ */
	DATE_T			 fusionSwitchDate;  /* REF10256 - TEB - 040615 */

	memset(&exchArgSt, 0, sizeof(FIN_EXCHARG_ST));	/* REFXZ */
	/*DBA_SetConnectNoToExchArg(&exchArgSt, DBA_GetConnectNoFromHier(hierHead));*/ /* REF2580 - SSO - 980727 */
	DBA_InitConnectNoToExchArg(&exchArgSt, hierHead); /* REF4213 - SSO - 991221 */

	if (inputInstrPtr == NULLDYNST)
        {
                /* REF3913 - 990820 - DDV */
                if ((ret = DBA_GetInstrById(instrId, FALSE, &allocOk,
                                            &instrPtr, hierHead, UNUSED, UNUSED)) != RET_SUCCEED)
                {
                        SYSNAME_T entSqlName;
                        strcpy(entSqlName, DBA_GetDictEntitySqlName(Instr));
                        MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO,
                                     entSqlName, instrId);
                        return(ret);
                }
        }
        else
        {
		instrPtr = inputInstrPtr;
                allocOk = FALSE;
	}

	if (GET_ID(instrPtr, A_Instr_Id) < 0)
	{ instrId = GET_ID(instrPtr, A_Instr_ParentInstrId); }
	else
	{ instrId = GET_ID(instrPtr, A_Instr_Id); }

	*crtYield = 0.0;

	instrNat = (INSTRNAT_ENUM) GET_ENUM(instrPtr, A_Instr_NatEn);
	if (instrNat != InstrNat_Stock &&
	    instrNat != InstrNat_FundShare &&
	    instrNat != InstrNat_Bond &&
	    instrNat != InstrNat_MoneyMkt &&
	    instrNat != InstrNat_CashAcct &&
	    instrNat != InstrNat_CumOption &&
	    instrNat != InstrNat_ConvertBond)
	{
		if (allocOk == TRUE) { FREE_DYNST(instrPtr, A_Instr); }
		return(RET_SUCCEED);
	}

	switch(instrNat)
	{
	case InstrNat_Stock :
	case InstrNat_FundShare :
		flowNatEn = FlowNat_Any;
		if (crtYieldPtr->divProjFlg == FALSE)
		{
			/* --------------------------- */
			/* BEGIN BUG056 - RAK - 960710 */
			/* timeDimEn    = TimeDim_Crt; */
			timeDimEn    = TimeDim_Previous;
			/* END   BUG056 - RAK - 960710 */
			/* --------------------------- */
			flowSubNatEn = FlowSubNat_PaidDiv;
		}
		else
		{
			timeDimEn = TimeDim_Last;
			flowSubNatEn = FlowSubNat_ProjectDiv;
		}
		/* BUG049 - RAK - 960708 */
		flowOk = TRUE;
		break;

	/* BUG387 */
	case InstrNat_Bond :
	case InstrNat_MoneyMkt :
	case InstrNat_CumOption :
	case InstrNat_ConvertBond :
	/* BUG049 - RAK - 960708 */
	case InstrNat_CashAcct :
		flowOk = FALSE;
	}

	/* BUG049 - RAK - 960708 */
	if (flowOk == TRUE)
	{
	    /*** SEARCH DIVIDEND (or COUPON RATE) ***/
	    if ((outputFlow = ALLOC_DYNST(Flow)) == NULLDYNST)
	    {
		if (allocOk == TRUE) { FREE_DYNST(instrPtr, A_Instr); }
		MSG_RETURN(RET_MEM_ERR_ALLOC);
	    }

	    if ((ret = FIN_InstrFlow(instrId, instrPtr, refDate, refDate,
								 FALSE,	 /* PMSTA-9032 - RAK - 091216 */
								 timeDimEn, 1,
								 flowNatEn, flowSubNatEn, EvtDateRule_Term, /* REF4075 - CSY - 991109 */
								 outputFlow, hierHead)) != RET_SUCCEED)
	    {
		if (allocOk == TRUE) { FREE_DYNST(instrPtr, A_Instr); }
		FREE_DYNST(outputFlow, Flow);
		return(ret);
	    }

	    switch(instrNat)
	    {
	    case InstrNat_Stock :
	    case InstrNat_FundShare :
		/*** CONVERT IN INSTRUMENT REFERENCE CURRENCY */
		if (GET_ID(instrPtr, A_Instr_RefCurrId) !=
		    GET_ID(outputFlow, Flow_AmtCurrId))
		{
		    FIN_GetExchRate(refDate, GET_ID(outputFlow, Flow_AmtCurrId),
		        GET_ID(instrPtr, A_Instr_RefCurrId), (ID_T)0, NULLDYNST,
				NULLDYNST, &exchArgSt, &exch);	/* PMSTA01649 - TGU - 070405 */
		}
		else
		    exch = 1.0;

		income = GET_PRICE(outputFlow, Flow_AmtUnit) * exch;

		/*** ANNUALISE ***/
		ret = FIN_PeriodUnitNbr((FREQUNIT_ENUM)GET_ENUM(outputFlow, Flow_FreqUnitEn),  /* REF7264 - LJE - 020128 */
		                        GET_TINYINT(outputFlow, Flow_Freq), FreqUnit_Year, &period);
		if (ret == RET_SUCCEED && period != 0)
			income *= period;
		break;

	    case InstrNat_Bond :
	    case InstrNat_MoneyMkt :
	    case InstrNat_CumOption :
	    case InstrNat_ConvertBond :
	    /* case InstrNat_CashAcct : BUG049 - RAK - 960708 */
		income = GET_PRICE(outputFlow, Flow_AmtUnit);
		break;
	    }

	    FREE_DYNST(outputFlow, Flow);
	}
	/* BUG049 - RAK - 960708 - cash account */
	/* BUG387 - RAK - 970602 - and bonds = use new function FIN_InterestCond() */
	else 	/* REF222 - XDI - 971014 */
	{
		/* REF1079 - New return argument (uInterPtr) for FIN_GetCouponRate() */

		if ((uInterPtr = ALLOC_DYNST(UnitInter)) == NULLDYNST)
		{
			if (allocOk == TRUE) { FREE_DYNST(instrPtr, A_Instr); }
	   		MSG_RETURN(RET_MEM_ERR_ALLOC);
		}

		/* REF1058 - New argument (validity date) for FIN_GetCouponRate() */
		/* REF3678 - RAK - 990819 - Add hierHead parameter */
        FIN_GetCouponRate(instrId, instrPtr, NULLDYNST, refDate, refDate, AccrRule_None, /* REF11218 - TEB - 050627 */
						  uInterPtr, hierHead); 

		income = GET_NUMBER(uInterPtr, UnitInter_UnitAccrInter);

		/* REF1079 - If rate isn't expressed in instrument currency, convert it */
		if (CMP_NUMBER(income, 0.0) != 0 &&
		    GET_ID(uInterPtr, UnitInter_CurrId) != GET_ID(instrPtr, A_Instr_RefCurrId))
		{
			FIN_GetExchRate(refDate, GET_ID(uInterPtr, UnitInter_CurrId),
		                        GET_ID(instrPtr, A_Instr_RefCurrId), (ID_T)0, NULLDYNST,
								NULLDYNST, &exchArgSt, &exch);	/* PMSTA01649 - TGU - 070405 */

			if (CMP_NUMBER(exch, 0.0) != 0)
				income /= exch;
		}

		FREE_DYNST(uInterPtr, UnitInter);
	}

	/*** SEARCH PRICE ***/
	if ((pricePtr = ALLOC_DYNST(A_InstrPrice)) == NULLDYNST)
	{
		if (allocOk == TRUE) { FREE_DYNST(instrPtr, A_Instr); }
	   	MSG_RETURN(RET_MEM_ERR_ALLOC);
	}

	if ((ret = FIN_InstrPrice(instrId, instrPtr, refDate, NULLDYNST, (ID_T)0, NULL, NULLDYNST,
                                  NULLDYNST, hierHead, pricePtr, FALSE)) != RET_SUCCEED)	/*DVP440*/ /* PMSTA14876 - DDV - 120911 - Add a new parameter, no impact for this call */
	{
		if (allocOk == TRUE) { FREE_DYNST(instrPtr, A_Instr); }
		FREE_DYNST(pricePtr, A_InstrPrice);
		*crtYield = 0.0;                    /* BUG311 - XDI - 970320 */
		return(RET_SUCCEED);                /* BUG311 - XDI - 970320 */
	}

	if (GET_ID(instrPtr, A_Instr_RefCurrId) != GET_ID(pricePtr, A_InstrPrice_CurrId))
	{
		FIN_GetExchRate(refDate, GET_ID(pricePtr, A_InstrPrice_CurrId),
		                GET_ID(instrPtr, A_Instr_RefCurrId), (ID_T)0, NULLDYNST,
						NULLDYNST, &exchArgSt, &exch);	/* PMSTA01649 - TGU - 070405 */
	}
	else
		exch = 1.0;

	price = GET_PRICE(pricePtr, A_InstrPrice_Price) * exch;

	FREE_DYNST(pricePtr, A_InstrPrice);

	/* REF1384 - Multiply income by 1-income tax rate */
	income *= (1-(crtYieldPtr->incTax/100.0));

	/* REF1384 - If clean price flag is YES : denominator is the price          */
	/*         - If it is NO : denominator is the price + any AI (taxed or not) */
	if (crtYieldPtr->cleanPriceFlg == FALSE)
	{
	    if (instrNat == InstrNat_Bond ||
		    instrNat == InstrNat_CumOption ||
		    instrNat == InstrNat_ConvertBond)
	    {
			/* REF10256 - TEB - 040615 - Begin */
			/* If system parameter is set, and date is before switch date, use  OldFusionDateRule */
			if (GEN_GetApplInfo(ApplFusionSwitchDate, &fusionSwitchDate) == FALSE ||
				fusionSwitchDate == MAGIC_END_DATE )
			{
				GEN_GetApplInfo(ApplFusDateRule, &sysFusDateRule);
			}
			else
			{
				if (DATE_Cmp(refDate.date, fusionSwitchDate) < 0)
				{
					GEN_GetApplInfo(ApplOldFusionDateRule, &sysFusDateRule);
				}
				else
				{
					GEN_GetApplInfo(ApplFusDateRule, &sysFusDateRule);
				}
			}
			/* REF10256 - TEB - 040615 - End */

			GEN_GetApplInfo(FullCouponFlag, &fullCoupFlg);

		if ((uInterPtr = ALLOC_DYNST(UnitInter)) == NULLDYNST)
		{
			if (allocOk == TRUE) { FREE_DYNST(instrPtr, A_Instr); }
			return(RET_MEM_ERR_ALLOC);
		}

		unitInter = 0.0;
        /* REF7265 - YST - 020320 - add two new arguments */
		ret = FIN_UnitAccrInter(refDate, instrId, instrPtr, sysFusDateRule, fullCoupFlg,
					FALSE, AccrInterMethod_Default, refDate,
					AccrRule_None, /* REF11218 - TEB - 050627 */
					NULLDYNST, uInterPtr, hierHead, FALSE, NULL); /* PMSTA08308 - 090609 - PMO / PMSTA05389-CHU-080131*/

		if (RET_GET_LEVEL(ret) != RET_LEV_ERROR && ret != RET_GEN_INFO_NOACTION)
		{
			if (GET_NUMBER(uInterPtr, UnitInter_UnitAccrInter) != 0.0 &&
                            GET_ID(uInterPtr, UnitInter_CurrId) !=
                            GET_ID(instrPtr, A_Instr_RefCurrId))
			{
			    FIN_GetExchRate(refDate, GET_ID(uInterPtr, UnitInter_CurrId),
                                            GET_ID(instrPtr, A_Instr_RefCurrId),
                                            0,NULLDYNST, NULLDYNST, &exchArgSt, &exch);	/* PMSTA01649 - TGU - 070405 */

			    unitInter = GET_NUMBER(uInterPtr, UnitInter_UnitAccrInter) * exch;
			}
                       	else
			{ unitInter = GET_NUMBER(uInterPtr, UnitInter_UnitAccrInter); }
		}

		FREE_DYNST(uInterPtr, UnitInter);

		price += unitInter;
	    }
	}

	/*** COMPUTE CURRENT YIELD ***/
	if (CMP_NUMBER(price, 0.0) != 0)
		*crtYield = income / price;

	if (allocOk == TRUE) { FREE_DYNST(instrPtr, A_Instr); }
	return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_InstrChrono()
**
**  Description :   Read chrono data or compute it (if none and asked)
**
**  Arguments   :   inputArgPtr   input argument strucutre ptr (instrId, date,
**                                validity period, nature, compute flag)
**                  inputInstrPtr instrument structure pointer or NULL
**                  chronoPtr     pointer on allocated chrono structure which will be filled
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   DVP051 : New function (96/05/09) used in keyword INSTR_CHRONO(),
**                  replace DBA_GetInstrChrono()
**
**  Modif       :   DVP141 - RAK - 960611
**  Modif       :   BUG131 - RAK - 960920
**  Modif       :   BUG195 - RAK - 961107
**  Modif       :   REF1384 - RAK - 980313
**  Modif       :   REF099 - RAK - 980728
**                  REF9082 - TEB - 030619
**                  REF9082 - TEB - 030807 : Add test on AdvA_Arg_RedemptionPrice
**                  REF10461 - TEB - 040804
**
*************************************************************************/
RET_CODE FIN_InstrChrono(DBA_DYNFLD_STP     inputArgPtr,
                         DBA_DYNFLD_STP     inputInstrPtr,
                         DBA_DYNFLD_STP     chronoPtr,
                         DBA_HIER_HEAD_STP  hierHead)
{
	DBA_DYNFLD_STP  instrPtr=NULLDYNST,
                    advAStp	    = NULLDYNST,  /* REF9082 - TEB - 030619 */
                    advArgStp   = NULLDYNST;  /* REF9082 - TEB - 030619 */
	DBA_PROC_STP    procedure=(DBA_PROC_STP)NULL;
	CHRONONAT_ENUM  chronoNat;
	DATETIME_T      refDate;
	ID_T            instrId;
	FLAG_T          allocOk;
	RET_CODE        ret=RET_SUCCEED, checkRet, optiRet = RET_SUCCEED;
    int             posIndexLocal= -1,posIndexGlobal= -1;
	FLAG_T          genericInstrFlg = FALSE;
	FLAG_T          firstComputeFlg = FALSE;
    ID_T            domainQuoteValRuleId=0;
	DBA_DYNFLD_STP  domainPtr=NULLDYNST;
	FIN_EXCHARG_ST     exchArgSt;
	EXCHANGE_T         exch;

	memset(&exchArgSt, 0, sizeof(FIN_EXCHARG_ST));	/* REFXZ */

	DBA_InitConnectNoToExchArg(&exchArgSt, NULL);

	if (inputInstrPtr == NULLDYNST)
    {
        /* REF3913 - 990820 - DDV */
        if ((ret = DBA_GetInstrById(GET_ID(inputArgPtr, Dim_InstrChrono_InstrId), FALSE, &allocOk,
                                    &instrPtr, hierHead, UNUSED, UNUSED)) != RET_SUCCEED)
        {
            SYSNAME_T entSqlName;
            strcpy(entSqlName, DBA_GetDictEntitySqlName(Instr));
            MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO,
                         entSqlName, GET_ID(inputArgPtr, Dim_InstrChrono_InstrId));
            return(ret);
        }
    }
    else
    {
        instrPtr = inputInstrPtr;
        allocOk = FALSE;
	}

	instrId = GET_ID(instrPtr, A_Instr_Id);

    /*  FPL-PMSTA09270-100128   */
    if (instrId == 0)
    {
        return RET_DBA_ERR_DURING_FIN_CALC ;
    }

	chronoNat = (CHRONONAT_ENUM) GET_ENUM(inputArgPtr, Dim_InstrChrono_NatEn);
	refDate   = GET_DATETIME(inputArgPtr, Dim_InstrChrono_RefDate);

    /* PMSTA-30776 - CHU - 180404 : flag now handled at stored proc level */
	/* PMSTA-36552 - JBC - 190723 : must set to avoid inconsistent opti storage */
	SET_FLAG_FALSE(inputArgPtr, Dim_InstrChrono_ThirdPartyFlg); 

    /* PMSTA12914 - DDV - 111010 - Set it to FALSE to avoid unmatching of input args in optimisation */
    if (IS_NULLFLD(inputArgPtr, Dim_InstrChrono_SubNatFlg) == TRUE)
    {
        SET_FLAG(inputArgPtr, Dim_InstrChrono_SubNatFlg, FALSE);
    }

	/* PMSTA14879 - DDV - 120920 - Add domain's valuation rule as criteria for cache usage */
	if ((domainPtr = DBA_GetDomainPtr(NO_VALUE)) != NULLDYNST &&
		(domainQuoteValRuleId = GET_ID(domainPtr, A_Domain_QuoteValRuleId)) != 0)
	{
		SET_ID(inputArgPtr, Dim_InstrChrono_DomQuoteValRuleId, domainQuoteValRuleId);
	}

	/* PMSTA14879 - DDV - 120920 - Check if computation must be forced */
	if (GET_FLAG(inputArgPtr, Dim_InstrChrono_ComputeFlg) == TRUE && FIN_ForceComputeInstrChrono(instrPtr, chronoNat) == TRUE)
	{
		firstComputeFlg = TRUE;
	}

	/* If valid period is 0 days, always compute chronological data */
	if (firstComputeFlg == FALSE &&
		(IS_NULLFLD(inputArgPtr, Dim_InstrChrono_ValidPeriod) == TRUE ||
	     GET_NUMBER(inputArgPtr, Dim_InstrChrono_ValidPeriod) != 0))

	{
		if (GET_ID(instrPtr, A_Instr_Id) < 0)
		{
			genericInstrFlg = TRUE;
			instrId = GET_ID(instrPtr, A_Instr_ParentInstrId);

			if (inputArgPtr != NULLDYNST &&			/* BUG195 */
				GET_ID(inputArgPtr, Dim_InstrChrono_InstrId) ==
				GET_ID(instrPtr, A_Instr_Id))
			{
				SET_ID(inputArgPtr, Dim_InstrChrono_InstrId, instrId);
			}
		}

		if ((ret = DBA_GetInstrChronoInHier(hierHead, inputArgPtr, &chronoPtr)) == RET_SUCCEED ||
            (ret = DBA_Get2(InstrChrono, UNUSED, Dim_InstrChrono, inputArgPtr,
                            A_InstrChrono, &chronoPtr, UNUSED, UNUSED, UNUSED)) == RET_SUCCEED)
		{
				/* Did it previously fail ? */
			if (IS_NULLFLD(chronoPtr, A_InstrChrono_Val) == TRUE)
			{
				optiRet = GET_INT (chronoPtr, A_InstrChrono_RetCd);
/*
				MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO,
						"FIN_InstrChrono",
						GET_CODE(instrPtr, A_Instr_Cd),
						GET_NAME(instrPtr, A_Instr_Name));
*/
			}

			if (allocOk == TRUE)
			{
				FREE_DYNST(instrPtr, A_Instr);
			}

			if ((IS_NULLFLD(chronoPtr, A_InstrChrono_CurrId) == FALSE) &&  /* cashwini-PMSTA-17571-150616 */
				(IS_NULLFLD(inputArgPtr, Dim_InstrChrono_CurrId) == FALSE) &&
				GET_ID(chronoPtr, A_InstrChrono_CurrId) != GET_ID(inputArgPtr, Dim_InstrChrono_CurrId))
			{
				FIN_GetExchRate(GET_DATETIME(inputArgPtr, Dim_InstrChrono_RefDate),
					GET_ID(chronoPtr, A_InstrChrono_CurrId), GET_ID(inputArgPtr, Dim_InstrChrono_CurrId),
					0, NULLDYNST, NULLDYNST, &exchArgSt, &exch);
				SET_ID(chronoPtr, A_InstrChrono_CurrId, GET_ID(inputArgPtr, Dim_InstrChrono_CurrId));
				SET_LONGAMOUNT(chronoPtr, A_InstrChrono_Val, (GET_LONGAMOUNT(chronoPtr, A_InstrChrono_Val) * exch));
			}

			return(optiRet);
		}

        /* PMSTA-30776 - CHU - 180404 : Optim : if no data, insert a record at refDate to avoid subsequent DB calls for same instrument */
        if (ret == RET_DBA_INFO_NODATA || ret == RET_DBA_INFO_NODATAWITHOPTI)
        {
            COPY_DYNFLD(chronoPtr, A_InstrChrono, A_InstrChrono_ValidDate,
                        inputArgPtr,   Dim_InstrChrono,      Dim_InstrChrono_RefDate);
            COPY_DYNFLD(chronoPtr, A_InstrChrono, A_InstrChrono_OptiDate,
                        inputArgPtr,   Dim_InstrChrono,      Dim_InstrChrono_RefDate);

        }
/* PMSTA-30776 - CHU - 180404 : flag now handled at stored proc level */
#if 0
		/* PMSTA-12398-CHU-111101 : if no data without third, try loading one with a third */
		if ((ret == RET_DBA_INFO_NODATA || ret == RET_DBA_INFO_NODATAWITHOPTI) && /* PMSTA16192-CHU-130416 : also consider RET_DBA_INFO_NODATAWITHOPTI */
			IS_NULLFLD(inputArgPtr, Dim_InstrChrono_ThirdPartyId) == TRUE)
		{
			SET_FLAG_FALSE(inputArgPtr, Dim_InstrChrono_ThirdPartyFlg);

			if ((ret = DBA_Get2(InstrChrono, UNUSED, Dim_InstrChrono, inputArgPtr,
								A_InstrChrono, &chronoPtr, UNUSED, UNUSED, UNUSED)) == RET_SUCCEED)
			{
				/* Did it previously fail ? */
				if (IS_NULLFLD(chronoPtr, A_InstrChrono_Val) == TRUE)
				{
					optiRet = GET_INT (chronoPtr, A_InstrChrono_RetCd);
				}

				if (allocOk == TRUE)
				{
					FREE_DYNST(instrPtr, A_Instr);
				}

				return(optiRet);
			}
		}
#endif
	}

	/* PMSTA14879 - DDV - 120920 - Set back generic instrument to use it during compute */
	if (genericInstrFlg == TRUE)
	{
		instrId = GET_ID(instrPtr, A_Instr_Id);
		SET_ID(inputArgPtr, Dim_InstrChrono_InstrId, instrId);
	}

	/* If valid period is 0 days, always compute chronological data */
	if (firstComputeFlg == FALSE &&
		IS_NULLFLD(inputArgPtr, Dim_InstrChrono_ValidPeriod) == FALSE &&
	    GET_NUMBER(inputArgPtr, Dim_InstrChrono_ValidPeriod) == 0)
	{
		if ((procedure = DBA_GetStoredProcs (Get, InstrChrono, UNUSED, Dim_InstrChrono,
							inputArgPtr, A_InstrChrono)) != NULL)
		{
			checkRet = DBA_ReadOpti(procedure, Opti_LocalGlobal, inputArgPtr, chronoPtr,
						(DBA_DYNFLD_STP *) NULL, &posIndexLocal, &posIndexGlobal);

			switch (checkRet)
			{
				case RET_SUCCEED:
						/* Did it previously fail ? */
					if (IS_NULLFLD(chronoPtr, A_InstrChrono_Val) == TRUE)
					{
						optiRet = GET_INT (chronoPtr, A_InstrChrono_RetCd);
/*
						MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO,
								"FIN_InstrChrono",
								GET_CODE(instrPtr, A_Instr_Cd),
								GET_NAME(instrPtr, A_Instr_Name));
*/
					}

					if (allocOk == TRUE)
					{
						FREE_DYNST(instrPtr, A_Instr);
					}

					return(optiRet);
					break;

				case RET_DBA_INFO_NODATA:
					break;
			}
		}
	}

	/* compute flag indicates that if no valid data is found the function should */
	/* attempt to calculate the data. Input arguments are defined as default     */
	/* values in the application parameter table                                 */
	/* If valid period is 0 days, always compute chronological data */
	if (GET_FLAG(inputArgPtr, Dim_InstrChrono_ComputeFlg) == TRUE ||
	    (IS_NULLFLD(inputArgPtr, Dim_InstrChrono_ValidPeriod) == FALSE &&
	     GET_NUMBER(inputArgPtr, Dim_InstrChrono_ValidPeriod) == 0))
	{
		switch (chronoNat)
	    {
	    case ChronoNat_Alpha :
	    case ChronoNat_Beta :
	    case ChronoNat_CoeffR2 :
	    case ChronoNat_CorrelCoeff :
	    case ChronoNat_Covariance :
	    {
		    DBA_DYNFLD_STP array1=NULLDYNST, array2=NULLDYNST, idxInstrPtr=NULLDYNST,
			           array1Diff=NULLDYNST, array2Diff=NULLDYNST, regrPtr=NULLDYNST,
			           getChrono=NULLDYNST;
		    FREQUNIT_ENUM  freqUnit;
		    TINYINT_T      freq;
		    SMALLINT_T     reading;
		    /* BUG452 - 970815 - XMT : set initial values */
		    RET_CODE       retMem1 = RET_SUCCEED, retMem2 = RET_SUCCEED;
                    FLAG_T         allocIdxInstrFlg;

		    /* Index instrument must be specified */
		    if (IS_NULLFLD(instrPtr, A_Instr_IdxInstrId) == TRUE)
		    {
		        if (allocOk == TRUE)
		        {
			        FREE_DYNST(instrPtr, A_Instr);
		        }

		        /* MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO, "FIN_InstrChrono",
				    GET_CODE(instrPtr, A_Instr_Cd), "index instrument"); */

			    /* Memorize the error in data cache. */
		        DBA_SetDimChrono((ID_T) GET_ID(inputArgPtr, Dim_InstrChrono_InstrId),		/* InstrId */
				                 GET_DATETIME(inputArgPtr, Dim_InstrChrono_RefDate),			/* RefDate */	/* ROI - 000930 - REF5274 */
				                 GET_NUMBER(inputArgPtr, Dim_InstrChrono_ValidPeriod),	/* ValidPeriod */
				                 (FLAG_T) IS_NULLFLD(inputArgPtr, Dim_InstrChrono_ValidPeriod),	/* ValidPeriod IS NULL */
                                 GET_ID(inputArgPtr, Dim_InstrChrono_ThirdPartyId),             /* REF10598 - LJE - 041011 */
				                 (CHRONONAT_ENUM)GET_ENUM(inputArgPtr, Dim_InstrChrono_NatEn),		/* Nature */ /* REF7264 - LJE - 020128 */
                                 GET_ID(inputArgPtr, Dim_InstrChrono_SubNatTypeId),             /* REF10598 - LJE - 041011 */
				                 (ID_T)0,							/* CurrId */
				                 (NUMBER_T)0,						/* Val */
				                 (int)RET_FIN_ERR_INVDATA,	/* RETURN ERROR NUMBER */
				                 (char *)NULL);		/* ERROR MSG STRING */

		        return(RET_FIN_ERR_INVDATA);
		    }

        	/* Read index instrument */
            /* REF3913 - 990820 - DDV */
            if ((ret = DBA_GetInstrById(GET_ID(instrPtr, A_Instr_IdxInstrId), FALSE, &allocIdxInstrFlg,
                                        &idxInstrPtr, hierHead, UNUSED, UNUSED)) != RET_SUCCEED)
            {
		        /* Memorize the error in data cache. */
		        DBA_SetDimChrono((ID_T) GET_ID(inputArgPtr, Dim_InstrChrono_InstrId),		/* InstrId */
				                 GET_DATETIME(inputArgPtr, Dim_InstrChrono_RefDate),	/* RefDate */	/* ROI - 000930 - REF5274 */
				                 GET_NUMBER(inputArgPtr, Dim_InstrChrono_ValidPeriod),	/* ValidPeriod */
				                 (FLAG_T) IS_NULLFLD(inputArgPtr, Dim_InstrChrono_ValidPeriod),	/* ValidPeriod IS NULL */
                                 GET_ID(inputArgPtr, Dim_InstrChrono_ThirdPartyId),             /* REF10598 - LJE - 041011 */
                                 (CHRONONAT_ENUM)GET_ENUM(inputArgPtr, Dim_InstrChrono_NatEn),		/* Nature */ /* REF7264 - LJE - 020128 */
                                 GET_ID(inputArgPtr, Dim_InstrChrono_SubNatTypeId),             /* REF10598 - LJE - 041011 */
				                 (ID_T)0,							/* CurrId */
				                 (NUMBER_T)0,						/* Val */
				                 (int)ret,			/* RETURN ERROR NUMBER */
				                 (char *)NULL);		/* ERROR MSG STRING */

                /* SKE - 000303 - Memory Leak */
	            if (allocOk == TRUE) FREE_DYNST(instrPtr, A_Instr);
                return(ret);
		    }

		    /* Compute arrays */
		    if ((array1 = ALLOC_DYNST(Array_X)) == NULLDYNST)
		    {
		        if (allocOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
                if (allocIdxInstrFlg == TRUE) {FREE_DYNST(idxInstrPtr, A_Instr);}
		        MSG_RETURN(RET_MEM_ERR_ALLOC);
		    }

		    if ((array2 = ALLOC_DYNST(Array_X)) == NULLDYNST)
		    {
		        if (allocOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
                if (allocIdxInstrFlg == TRUE) {FREE_DYNST(idxInstrPtr, A_Instr);}
                FREE_DYNST(array1, Array_X);
		        MSG_RETURN(RET_MEM_ERR_ALLOC);
		    }

		    /* BUG131 */
		    if ((getChrono = ALLOC_DYNST(Chrono_FreqArg)) == NULLDYNST)
		    {
		        if (allocOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
                if (allocIdxInstrFlg == TRUE) {FREE_DYNST(idxInstrPtr, A_Instr);}
		        FREE_DYNST(array1, Array_X);
		        FREE_DYNST(array2, Array_X);
		        MSG_RETURN(RET_MEM_ERR_ALLOC);
		    }

		    GEN_GetApplInfo(ApplRegrFreq,       &freq);
		    GEN_GetApplInfo(ApplRegrFreqUnit,   &freqUnit);
		    GEN_GetApplInfo(ApplRegrNbrReading, &reading);

		    /*** INPUT INSTRUMENT ***/

		    /* BUG131 - Verify in memory */
		    SET_ID(getChrono,       Chrono_FreqArg_ObjId,      instrId);
		    SET_ID(getChrono,       Chrono_FreqArg_CurrId, GET_ID(instrPtr, A_Instr_RefCurrId));
		    SET_DATETIME(getChrono, Chrono_FreqArg_TillDate,   refDate);
		    SET_ENUM(getChrono,     Chrono_FreqArg_ObjEn,      (ENUM_T)InstrPrice);
		    SET_ENUM(getChrono,     Chrono_FreqArg_NatEn,      0);
		    SET_INT(getChrono,      Chrono_FreqArg_Reading,    (int)reading);
		    SET_TINYINT(getChrono,  Chrono_FreqArg_Freq,       freq);
		    SET_ENUM(getChrono,     Chrono_FreqArg_FreqUnitEn, freqUnit);

		    if ((ret = DBA_GetMemory(OptiFct, UNUSED, Chrono_FreqArg, getChrono,
					     Array_X, array1, (DBA_DYNFLD_STP*)NULL,
					     Opti_Local)) != RET_SUCCEED)
		    {
		        ret = FIN_InstrPriceArray(refDate, freq, (ENUM_T) freqUnit, (int) reading,
			          instrId, instrPtr, GET_ID(instrPtr, A_Instr_RefCurrId),
                                  0, NULLDYNST, NULLDYNST, array1, hierHead);

		        retMem1 = DBA_SetMemory(OptiFct, UNUSED, Chrono_FreqArg, getChrono,
				               Array_X, array1, Opti_Local);

		        if (ret != RET_SUCCEED)
		        {
                    if (allocOk == TRUE) FREE_DYNST(instrPtr, A_Instr);
                    if (allocIdxInstrFlg == TRUE) FREE_DYNST(idxInstrPtr, A_Instr);
                    if (retMem1 == RET_DBA_INFO_NODATAOPTI)
                    {
                        FREE_DYNST(array1, Array_X);
                    }
                    else
                    {
                        FREE(array1); /* PMSTA-41612 - LJE - 201006 */
                    }
                    if (retMem2 == RET_DBA_INFO_NODATAOPTI)
                    {
                        FREE_DYNST(array2, Array_X);
                    }
                    else
                    {
                        FREE(array2); /* PMSTA-41612 - LJE - 201006 */
                    }

                    FREE_DYNST(getChrono, Chrono_FreqArg);

                    /* Memorize the error in data cache. */
                    DBA_SetDimChrono((ID_T) GET_ID(inputArgPtr, Dim_InstrChrono_InstrId),		/* InstrId */
		                              GET_DATETIME(inputArgPtr, Dim_InstrChrono_RefDate),/* RefDate */	/* ROI - 000930 - REF5274 */
		                              GET_NUMBER(inputArgPtr, Dim_InstrChrono_ValidPeriod),	/* ValidPeriod */
		                              (FLAG_T) IS_NULLFLD(inputArgPtr, Dim_InstrChrono_ValidPeriod),	/* ValidPeriod IS NULL */
                                      GET_ID(inputArgPtr, Dim_InstrChrono_ThirdPartyId),             /* REF10598 - LJE - 041011 */
		                              (CHRONONAT_ENUM)GET_ENUM(inputArgPtr, Dim_InstrChrono_NatEn),		/* Nature */ /* REF7264 - LJE - 020128 */
                                      GET_ID(inputArgPtr, Dim_InstrChrono_SubNatTypeId),             /* REF10598 - LJE - 041011 */
		                              (ID_T)0,						/* CurrId */
		                              (NUMBER_T)0,						/* Val */
		                              (int)ret,			/* RETURN ERROR NUMBER */
		                              (char *)NULL);		/* ERROR MSG STRING */

                    return(ret);
		        }
		    }

		    /*** INDEX INSTRUMENT ***/

		    /* BUG131 - Verify in memory */
		    SET_ID(getChrono, Chrono_FreqArg_ObjId,  GET_ID(idxInstrPtr, A_Instr_Id));
		    SET_ID(getChrono, Chrono_FreqArg_CurrId, GET_ID(idxInstrPtr, A_Instr_RefCurrId));
		    /* other arguments are identique */

		    if ((ret = DBA_GetMemory(OptiFct, UNUSED, Chrono_FreqArg, getChrono,
					     Array_X, array2, (DBA_DYNFLD_STP*)NULL,
					     Opti_Local)) != RET_SUCCEED)
		    {
		        ret = FIN_InstrPriceArray(refDate, freq, (ENUM_T) freqUnit, (int) reading,
			          GET_ID(idxInstrPtr, A_Instr_Id), idxInstrPtr,
			          GET_ID(idxInstrPtr, A_Instr_RefCurrId),
                                  0, NULLDYNST, NULLDYNST, array2, hierHead);

		        retMem2 = DBA_SetMemory(OptiFct, UNUSED, Chrono_FreqArg, getChrono,
				               Array_X, array2, Opti_Local);

		        if (ret != RET_SUCCEED)
		        {
                    if (allocOk == TRUE) FREE_DYNST(instrPtr, A_Instr);
                    if (allocIdxInstrFlg == TRUE) FREE_DYNST(idxInstrPtr, A_Instr);

			        /* BUG452 - 970815 - XMT : remove also first allocated array, if needed */
                    if (retMem1 == RET_DBA_INFO_NODATAOPTI)
                    {
                        FREE_DYNST(array1, Array_X);
                    }
                    else
                    {
                        FREE(array1); /* PMSTA-41612 - LJE - 201006 */
                    }

                    if (retMem2 == RET_DBA_INFO_NODATAOPTI)
                    {
                        FREE_DYNST(array2, Array_X);
                    }
                    else
                    {
                        FREE(array2); /* PMSTA-41612 - LJE - 201006 */
                    }
                    FREE_DYNST(getChrono, Chrono_FreqArg);

                    /* Memorize the error in data cache. */
                    DBA_SetDimChrono((ID_T) GET_ID(inputArgPtr, Dim_InstrChrono_InstrId),		/* InstrId */
		                             GET_DATETIME(inputArgPtr, Dim_InstrChrono_RefDate),	/* RefDate */	/* ROI - 000930 - REF5274 */
		                             GET_NUMBER(inputArgPtr, Dim_InstrChrono_ValidPeriod),	/* ValidPeriod */
		                             (FLAG_T) IS_NULLFLD(inputArgPtr, Dim_InstrChrono_ValidPeriod),	/* ValidPeriod IS NULL */
                                     GET_ID(inputArgPtr, Dim_InstrChrono_ThirdPartyId),             /* REF10598 - LJE - 041011 */
		                             (CHRONONAT_ENUM)GET_ENUM(inputArgPtr, Dim_InstrChrono_NatEn),		/* Nature */ /* REF7264 - LJE - 020128 */
                                     GET_ID(inputArgPtr, Dim_InstrChrono_SubNatTypeId),             /* REF10598 - LJE - 041011 */
		                             (ID_T)0,						/* CurrId */
		                             (NUMBER_T)0,						/* Val */
		                             (int)ret,			/* RETURN ERROR NUMBER */
		                             (char *)NULL);	   		/* ERROR MSG STRING */

		    	    return(ret);
		        }
		    }

		    FREE_DYNST(getChrono, Chrono_FreqArg);
            if (allocIdxInstrFlg == TRUE) {FREE_DYNST(idxInstrPtr, A_Instr);}

		    /* --------------------------- */
		    /* BEGIN DVP141 - RAK - 960619 */
		    if ((ret = FIN_CalcArrayDiff(array1, &array1Diff)) != RET_SUCCEED)
		    {
		        if (allocOk == TRUE)
		        {
			        FREE_DYNST(instrPtr, A_Instr);
		        }

                if (retMem1 == RET_DBA_INFO_NODATAOPTI)
                {
                    FREE_DYNST(array1, Array_X);
                }
                else
                {
                    FREE(array1); /* PMSTA-41612 - LJE - 201006 */
                }

                if (retMem2 == RET_DBA_INFO_NODATAOPTI)
                {
                    FREE_DYNST(array2, Array_X);
                }
                else
                {
                    FREE(array2); /* PMSTA-41612 - LJE - 201006 */
                }

			    /* Memorize the error in data cache. */
		        DBA_SetDimChrono((ID_T) GET_ID(inputArgPtr, Dim_InstrChrono_InstrId),		/* InstrId */
				                 GET_DATETIME(inputArgPtr, Dim_InstrChrono_RefDate),	/* RefDate */	/* ROI - 000930 - REF5274 */
				                 GET_NUMBER(inputArgPtr, Dim_InstrChrono_ValidPeriod),	/* ValidPeriod */
				                 (FLAG_T) IS_NULLFLD(inputArgPtr, Dim_InstrChrono_ValidPeriod),	/* ValidPeriod IS NULL */
                                 GET_ID(inputArgPtr, Dim_InstrChrono_ThirdPartyId),             /* REF10598 - LJE - 041011 */
				                 (CHRONONAT_ENUM)GET_ENUM(inputArgPtr, Dim_InstrChrono_NatEn),		/* Nature */ /* REF7264 - LJE - 020128 */
                                 GET_ID(inputArgPtr, Dim_InstrChrono_SubNatTypeId),             /* REF10598 - LJE - 041011 */
				                 (ID_T)0,							/* CurrId */
				                 (NUMBER_T)0,						/* Val */
				                 (int)ret,			/* RETURN ERROR NUMBER */
				                 (char *)NULL);		/* ERROR MSG STRING */

		        return(ret);
		    }

            if (retMem1 == RET_DBA_INFO_NODATAOPTI)
            {
                FREE_DYNST(array1, Array_X);
            }
            else
            {
                FREE(array1); /* PMSTA-41612 - LJE - 201006 */
            }
                

            if ((ret = FIN_CalcArrayDiff(array2, &array2Diff)) != RET_SUCCEED)
            {
	            if (allocOk == TRUE)
	            {
		            FREE_DYNST(instrPtr, A_Instr);
	            }

	            FREE_DYNST(array1Diff, Array_X);
                if (retMem2 == RET_DBA_INFO_NODATAOPTI)
                {
                    FREE_DYNST(array2, Array_X);
                }
                else
                {
                    FREE(array2); /* PMSTA-41612 - LJE - 201006 */
                }

	            /* Memorize the error in data cache. */
	            DBA_SetDimChrono((ID_T) GET_ID(inputArgPtr, Dim_InstrChrono_InstrId),		/* InstrId */
			                     GET_DATETIME(inputArgPtr, Dim_InstrChrono_RefDate),	/* RefDate */	/* ROI - 000930 - REF5274 */
			                     GET_NUMBER(inputArgPtr, Dim_InstrChrono_ValidPeriod),	/* ValidPeriod */
			                     (FLAG_T) IS_NULLFLD(inputArgPtr, Dim_InstrChrono_ValidPeriod),	/* ValidPeriod IS NULL */
                                 GET_ID(inputArgPtr, Dim_InstrChrono_ThirdPartyId),             /* REF10598 - LJE - 041011 */
			                     (CHRONONAT_ENUM)GET_ENUM(inputArgPtr, Dim_InstrChrono_NatEn),		/* Nature */ /* REF7264 - LJE - 020128 */
                                 GET_ID(inputArgPtr, Dim_InstrChrono_SubNatTypeId),             /* REF10598 - LJE - 041011 */
			                     (ID_T)0,							/* CurrId */
			                     (NUMBER_T)0,						/* Val */
			                     (int)ret,			/* RETURN ERROR NUMBER */
			                     (char *)NULL);		/* ERROR MSG STRING */

	            return(ret);
            }

            if (retMem2 == RET_DBA_INFO_NODATAOPTI)
            {
                FREE_DYNST(array2, Array_X);
            }
            else
            {
                FREE(array2); /* PMSTA-41612 - LJE - 201006 */
            }
            
            /* END   DVP141 - RAK - 960619 */
		    /* --------------------------- */

		    /* Compute regression */
		    if ((regrPtr = ALLOC_DYNST(A_Regr)) == NULLDYNST)
		    {
		        if (allocOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
		        FREE_DYNST(array1Diff, Array_X);
		        FREE_DYNST(array2Diff, Array_X);
		        MSG_RETURN(RET_MEM_ERR_ALLOC);
		    }

            /* DVP141 - RAK - 960619 */
            /* if ((ret = FIN_Regr(array1, array2, regrPtr)) != RET_SUCCEED) */
            if ((ret = FIN_Regr(array1Diff, array2Diff, regrPtr)) != RET_SUCCEED)
            {
	            if (allocOk == TRUE)
	            {
		            FREE_DYNST(instrPtr, A_Instr);
	            }

	            FREE_DYNST(array1Diff, Array_X);
	            FREE_DYNST(array2Diff, Array_X);
	            FREE_DYNST(regrPtr, A_Regr);

	            /* Memorize the error in data cache. */
	            DBA_SetDimChrono((ID_T) GET_ID(inputArgPtr, Dim_InstrChrono_InstrId),		/* InstrId */
			                     GET_DATETIME(inputArgPtr, Dim_InstrChrono_RefDate),	/* RefDate */	/* ROI - 000930 - REF5274 */
			                     GET_NUMBER(inputArgPtr, Dim_InstrChrono_ValidPeriod),	/* ValidPeriod */
			                     (FLAG_T) IS_NULLFLD(inputArgPtr, Dim_InstrChrono_ValidPeriod),	/* ValidPeriod IS NULL */
                                 GET_ID(inputArgPtr, Dim_InstrChrono_ThirdPartyId),             /* REF10598 - LJE - 041011 */
			                     (CHRONONAT_ENUM)GET_ENUM(inputArgPtr, Dim_InstrChrono_NatEn),		/* Nature */ /* REF7264 - LJE - 020128 */
                                 GET_ID(inputArgPtr, Dim_InstrChrono_SubNatTypeId),             /* REF10598 - LJE - 041011 */
			                     (ID_T)0,							/* CurrId */
			                     (NUMBER_T)0,						/* Val */
			                     (int)ret,			/* RETURN ERROR NUMBER */
			                     (char *)NULL);		/* ERROR MSG STRING */

	            return(ret);
            }

		    FREE_DYNST(array1Diff, Array_X);
		    FREE_DYNST(array2Diff, Array_X);

		    /* Update chronological data */
		    SET_ID(chronoPtr, A_InstrChrono_InstrId, GET_ID(inputArgPtr, Dim_InstrChrono_InstrId));
		    SET_ID(chronoPtr, A_InstrChrono_CurrId,   GET_ID(instrPtr, A_Instr_RefCurrId));
		    SET_ENUM(chronoPtr,     A_InstrChrono_NatEn,     chronoNat);
		    SET_DATETIME(chronoPtr, A_InstrChrono_ValidDate, refDate);

		    switch (chronoNat)
		    {
		    case ChronoNat_Alpha :
				/* REF11704 - TGU - 060419 - Change datatype */
		        SET_LONGAMOUNT(chronoPtr, A_InstrChrono_Val, GET_NUMBER(regrPtr, A_Regr_Alpha));
		        break;
		    case ChronoNat_Beta :
				/* REF11704 - TGU - 060419 - Change datatype */
		        SET_LONGAMOUNT(chronoPtr, A_InstrChrono_Val, GET_NUMBER(regrPtr, A_Regr_Beta));
		        break;
		    case ChronoNat_CoeffR2 :
				/* REF11704 - TGU - 060419 - Change datatype */
		        SET_LONGAMOUNT(chronoPtr, A_InstrChrono_Val,
			    GET_NUMBER(regrPtr, A_Regr_DetermCoefR2));
		        break;
		    case ChronoNat_CorrelCoeff :
				/* REF11704 - TGU - 060419 - Change datatype */
		        SET_LONGAMOUNT(chronoPtr, A_InstrChrono_Val,
			    GET_NUMBER(regrPtr, A_Regr_CorrelationCoef));
		        break;
		    case ChronoNat_Covariance :
				/* REF11704 - TGU - 060419 - Change datatype */
		        SET_LONGAMOUNT(chronoPtr, A_InstrChrono_Val, GET_NUMBER(regrPtr,A_Regr_Covariance));
		        break;
		    }

		    FREE_DYNST(regrPtr, A_Regr);
		    ret = RET_SUCCEED;
		    break;
	    }

	    case ChronoNat_CurrentYield :
	    {
		    NUMBER_T 	crtYield;
		    FIN_CRTYIELD_ST crtYieldArg;

		    memset(&crtYieldArg, 0, sizeof(FIN_CRTYIELD_ST));

		    if ((ret = FIN_CrtYield(instrId, instrPtr, refDate,
					    &crtYieldArg, &crtYield, hierHead)) != RET_SUCCEED)
		    {
		        if (allocOk == TRUE)
		        {
			        FREE_DYNST(instrPtr, A_Instr);
		        }

			    /* Memorize the error in data cache. */
		        DBA_SetDimChrono((ID_T) GET_ID(inputArgPtr, Dim_InstrChrono_InstrId),		/* InstrId */
				                 GET_DATETIME(inputArgPtr, Dim_InstrChrono_RefDate),	/* RefDate */	/* ROI - 000930 - REF5274 */
				                 GET_NUMBER(inputArgPtr, Dim_InstrChrono_ValidPeriod),	/* ValidPeriod */
				                 (FLAG_T) IS_NULLFLD(inputArgPtr, Dim_InstrChrono_ValidPeriod),	/* ValidPeriod IS NULL */
                                 GET_ID(inputArgPtr, Dim_InstrChrono_ThirdPartyId),             /* REF10598 - LJE - 041011 */
				                 (CHRONONAT_ENUM)GET_ENUM(inputArgPtr, Dim_InstrChrono_NatEn),		/* Nature */ /* REF7264 - LJE - 020128 */
                                 GET_ID(inputArgPtr, Dim_InstrChrono_SubNatTypeId),             /* REF10598 - LJE - 041011 */
				                 (ID_T)0,							/* CurrId */
				                 (NUMBER_T)0,						/* Val */
				                 (int)ret,			/* RETURN ERROR NUMBER */
				                 (char *)NULL);		/* ERROR MSG STRING */

		        return(ret);
		    }

		    /* Update chronological data */
		    SET_ID(chronoPtr, A_InstrChrono_InstrId,
		        GET_ID(inputArgPtr, Dim_InstrChrono_InstrId));
		    SET_ID(chronoPtr, A_InstrChrono_CurrId, GET_ID(instrPtr, A_Instr_RefCurrId));
		    SET_ENUM(chronoPtr,     A_InstrChrono_NatEn,     chronoNat);
		    SET_DATETIME(chronoPtr, A_InstrChrono_ValidDate, refDate);
		    SET_LONGAMOUNT(chronoPtr,   A_InstrChrono_Val,       crtYield); /* REF11704 - TGU - 060419 - Change datatype */

		    ret = RET_SUCCEED;
		    break;
	    }

	    /* --------------------------- */
	    /* BEGIN DVP141 - RAK - 960611 */
	    case ChronoNat_YieldToMaturity :
	    {
            /* REF9082 - TEB - 030619 - Begin */
            /* Replace Tech with Simcorp */
            DBA_DYNFLD_STP ytmPtr=NULLDYNST;

	        /* Create input structure. */
	        if ((advArgStp = ALLOC_DYNST(AdvA_Arg)) == NULLDYNST)
            {
                if (allocOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
		        MSG_RETURN(RET_MEM_ERR_ALLOC);
            }

            /* Set the instrument id */
            SET_ID(advArgStp, AdvA_Arg_InstrId, instrId);

            /* Set the reference date */
            SET_DATE(advArgStp, AdvA_Arg_RefDate, refDate.date);
            COPY_DYNFLD(advArgStp, AdvA_Arg, AdvA_Arg_Date, advArgStp, AdvA_Arg, AdvA_Arg_RefDate );

            /* Set the redemption quote */
            /* REF9082 - TEB - 030807 : Add test on AdvA_Arg_RedemptionPrice */
			/* REF10461 - TEB - 040804 */
			/* Compute Redemption Price in SCE functions, because of iorevent priority */
/*
            if (IS_NULLFLD(instrPtr, A_Instr_RedempQuote)== TRUE)
            {
                MSG_SendMesg(RET_GEN_ERR_PERSONAL, 6, FILEINFO, "No redemption quote for YTM computation !! Instrument :",
                             GET_CODE(instrPtr, A_Instr_Cd));
		        FREE_DYNST(advArgStp, AdvA_Arg);
		        if (allocOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
                return(RET_FIN_ERR_INVDATA);
            }
            else
            {
                COPY_DYNFLD(advArgStp, AdvA_Arg, AdvA_Arg_RedemptionPrice, instrPtr, A_Instr, A_Instr_RedempQuote );
            }
*/

            /* Allocate the output structure */
	        if ((ytmPtr = ALLOC_DYNST(A_Ytm)) == NULLDYNST)
	        {
		        FREE_DYNST(advArgStp, AdvA_Arg);
		        if (allocOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
		        MSG_RETURN(RET_MEM_ERR_ALLOC);
	        }

            /* set the type of the output structure */
	        SET_INT(advArgStp, AdvA_Arg_SceOutEn, A_Ytm);

	        /* set the keyword nature */
	        SET_ENUM(advArgStp, AdvA_Arg_KeyWordEn, AdvAKeyWord_YTM);

            /* Compute ytm */
	        if ((ret=SCE_ComputeCurrKeyWord(advArgStp, instrPtr,
				                            NULL , hierHead, ytmPtr)) != RET_SUCCEED)
	        {
                if (allocOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
                FREE_DYNST(advArgStp, AdvA_Arg);
		        FREE_DYNST(ytmPtr,    A_Ytm);

				/* PMSTA14879 -DDV - 120920 - If priority was given to compute and it failed, call again to get data from db */
				if (firstComputeFlg == TRUE)
				{
					SET_FLAG(inputArgPtr, Dim_InstrChrono_ComputeFlg, FALSE)
					ret = FIN_InstrChrono(inputArgPtr, instrPtr, chronoPtr, hierHead);
				}
			}


			if (ret != RET_SUCCEED)
			{
			    /* Memorize the error in data cache. */
		        DBA_SetDimChrono((ID_T) GET_ID(inputArgPtr, Dim_InstrChrono_InstrId),	/* InstrId */
				                 GET_DATETIME(inputArgPtr, Dim_InstrChrono_RefDate),	        /* RefDate */	/* ROI - 000930 - REF5274 */
				                 GET_NUMBER(inputArgPtr, Dim_InstrChrono_ValidPeriod),	        /* ValidPeriod */
				                 (FLAG_T) IS_NULLFLD(inputArgPtr, Dim_InstrChrono_ValidPeriod),	/* ValidPeriod IS NULL */
                                 GET_ID(inputArgPtr, Dim_InstrChrono_ThirdPartyId),             /* REF10598 - LJE - 041011 */
				                 (CHRONONAT_ENUM)GET_ENUM(inputArgPtr, Dim_InstrChrono_NatEn),	/* Nature */ /* REF7264 - LJE - 020128 */
                                 GET_ID(inputArgPtr, Dim_InstrChrono_SubNatTypeId),             /* REF10598 - LJE - 041011 */
				                 (ID_T)0,							                            /* CurrId */
				                 (NUMBER_T)0,						                            /* Val */
				                 (int)ret,			                                            /* RETURN ERROR NUMBER */
				                 (char *)NULL);		                                            /* ERROR MSG STRING */

		        return(ret);
		    }

		    /* Update chronological data */
		    SET_ENUM(chronoPtr,     A_InstrChrono_NatEn,     chronoNat);
		    SET_ID(chronoPtr,       A_InstrChrono_InstrId,   instrId);
		    SET_DATETIME(chronoPtr, A_InstrChrono_ValidDate, refDate);
		    SET_LONGAMOUNT(chronoPtr,   A_InstrChrono_Val,       GET_NUMBER(ytmPtr, A_Ytm_Ytm));/* REF11704 - TGU - 060419 - Change datatype */
		    SET_NULL_ID(chronoPtr,  A_InstrChrono_CurrId);

            FREE_DYNST(advArgStp, AdvA_Arg);
            /* REF9082 - TEB - 030619 - End */

		    FREE_DYNST(ytmPtr, A_Ytm);
		    ret = RET_SUCCEED;
		    break;
	    }

	    case ChronoNat_Dura :
	    {
		    double         duration=0.0;
            /* REF9082 - TEB - 030619 - Begin */
            /* Replace Tech with Simcorp */

	        /* Create input structure. */
	        if ((advArgStp = ALLOC_DYNST(AdvA_Arg)) == NULLDYNST)
		    {
		        if (allocOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
		        MSG_RETURN(RET_MEM_ERR_ALLOC);
		    }


            /* Set the untrument id */
            SET_ID(advArgStp, AdvA_Arg_InstrId, instrId);

            /* Set the reference date */
            SET_DATE(advArgStp, AdvA_Arg_RefDate, refDate.date);
            COPY_DYNFLD(advArgStp, AdvA_Arg, AdvA_Arg_Date, advArgStp, AdvA_Arg, AdvA_Arg_RefDate);

            /* Allocate the output structure */
	        if ((advAStp = ALLOC_DYNST(A_AdvA)) == NULLDYNST)
	        {
		        FREE_DYNST(advArgStp, AdvA_Arg);
		        if (allocOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
		        MSG_RETURN(RET_MEM_ERR_ALLOC);
	        }

	        /* Set the keyword nature */
	        SET_ENUM(advArgStp, AdvA_Arg_KeyWordEn, AdvAKeyWord_DURA);

	        if ((ret=FIN_Dura(advArgStp, TRUE, instrPtr,NULL,
				              hierHead, advAStp)) != RET_SUCCEED)
	        {
		        FREE_DYNST(advArgStp, AdvA_Arg);
		        FREE_DYNST(advAStp,   A_AdvA);

				/* PMSTA14879 -DDV - 120920 - If priority was given to compute and it failed, call again to get data from db */
				if (firstComputeFlg == TRUE)
				{
					SET_FLAG(inputArgPtr, Dim_InstrChrono_ComputeFlg, FALSE)
					ret = FIN_InstrChrono(inputArgPtr, instrPtr, chronoPtr, hierHead);
				}

		        if (allocOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
		        return(ret);
	        }

            if (IS_NULLFLD(advAStp, A_AdvA_Dura)==FALSE)
                duration = GET_NUMBER(advAStp, A_AdvA_Dura);

	        FREE_DYNST(advArgStp, AdvA_Arg);
	        FREE_DYNST(advAStp,   A_AdvA);
            /* REF9082 - TEB - 030619 - End */

		    /* Update chronological data */
		    SET_ENUM(chronoPtr,     A_InstrChrono_NatEn,     chronoNat);
		    SET_ID(chronoPtr,       A_InstrChrono_InstrId,   instrId);
		    SET_DATETIME(chronoPtr, A_InstrChrono_ValidDate, refDate);
		    SET_LONGAMOUNT(chronoPtr,   A_InstrChrono_Val,       duration); /* REF11704 - TGU - 060419 - Change datatype */
		    SET_NULL_ID(chronoPtr,  A_InstrChrono_CurrId);


		    ret = RET_SUCCEED;
		    break;
	    }

	    case ChronoNat_ModDura :
	    {
		double         mDura=0.0;
        /* REF9082 - TEB - 030619 - Begin */
        /* Replace Tech with Simcorp */

		/* Create input structure. */
	    if ((advArgStp = ALLOC_DYNST(AdvA_Arg)) == NULLDYNST)
        {
            if (allocOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
		    MSG_RETURN(RET_MEM_ERR_ALLOC);
        }

        /* Set the intrument id */
        SET_ID(advArgStp, AdvA_Arg_InstrId, GET_ID(instrPtr, A_Instr_Id));

        /* Set the reference date */
        SET_DATE(advArgStp, AdvA_Arg_RefDate, refDate.date);
        COPY_DYNFLD(advArgStp, AdvA_Arg, AdvA_Arg_Date, advArgStp, AdvA_Arg, AdvA_Arg_RefDate );

         /* Allocate the output structure */
	    if ((advAStp = ALLOC_DYNST(A_AdvA)) == NULLDYNST)
	    {
		    FREE_DYNST(advArgStp, AdvA_Arg);
            if (allocOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
		    MSG_RETURN(RET_MEM_ERR_ALLOC);
	    }

	    /* set the keyword nature */
	    SET_ENUM(advArgStp, AdvA_Arg_KeyWordEn, AdvAKeyWord_DURA);

        /* Compute mdura */
        if ((ret=FIN_MDura(advArgStp, TRUE, instrPtr,NULL,
				           hierHead, advAStp)) != RET_SUCCEED)
	    {
		    FREE_DYNST(advArgStp, AdvA_Arg);
		    FREE_DYNST(advAStp,   A_AdvA);

			/* PMSTA14879 -DDV - 120920 - If priority was given to compute and it failed, call again to get data from db */
			if (firstComputeFlg == TRUE)
			{
				SET_FLAG(inputArgPtr, Dim_InstrChrono_ComputeFlg, FALSE)
				ret = FIN_InstrChrono(inputArgPtr, instrPtr, chronoPtr, hierHead);
			}

		    if (allocOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
		    return(ret);
	    }

        mDura = GET_NUMBER(advAStp, A_AdvA_Dura);

	    FREE_DYNST(advArgStp, AdvA_Arg);
	    FREE_DYNST(advAStp,   A_AdvA);
        /* REF9082 - TEB - 030619 - End  */

		/* Update chronological data */
		SET_ENUM(chronoPtr,     A_InstrChrono_NatEn,     chronoNat);
		SET_ID(chronoPtr,       A_InstrChrono_InstrId,   instrId);
		SET_DATETIME(chronoPtr, A_InstrChrono_ValidDate, refDate);
		SET_LONGAMOUNT(chronoPtr,   A_InstrChrono_Val,       mDura); /* REF11704 - TGU - 060419 - Change datatype */
		SET_NULL_ID(chronoPtr,  A_InstrChrono_CurrId);


		ret = RET_SUCCEED;
		break;
	    }

	    case ChronoNat_Convexity :
	    {
		double         conv=0.0;
        /* REF9082 - TEB - 030619 - Begin */
        /* Replace Tech with Simcorp */

	    /* Create input structure. */
	    if ((advArgStp = ALLOC_DYNST(AdvA_Arg)) == NULLDYNST)
        {
            if (allocOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
		    MSG_RETURN(RET_MEM_ERR_ALLOC);
        }

        /* Set the intrument id */
        SET_ID(advArgStp, AdvA_Arg_InstrId, GET_ID(instrPtr, A_Instr_Id));

        /* Set the reference date */
        SET_DATE(advArgStp, AdvA_Arg_RefDate, refDate.date);
        COPY_DYNFLD(advArgStp, AdvA_Arg, AdvA_Arg_Date, advArgStp, AdvA_Arg, AdvA_Arg_RefDate );

         /* Allocate the output structure */
	    if ((advAStp = ALLOC_DYNST(A_AdvA)) == NULLDYNST)
	    {
		    FREE_DYNST(advArgStp, AdvA_Arg);
            if (allocOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
		    MSG_RETURN(RET_MEM_ERR_ALLOC);
	    }

	    /* Set the keyword nature */
	    SET_ENUM(advArgStp, AdvA_Arg_KeyWordEn, AdvAKeyWord_CONV);

        /* Compute conv */
	    if ((ret=FIN_Conv(advArgStp, TRUE, instrPtr,NULL,
				          hierHead, advAStp)) != RET_SUCCEED)
	    {
		    FREE_DYNST(advArgStp, AdvA_Arg);
		    FREE_DYNST(advAStp,   A_AdvA);

			/* PMSTA14879 -DDV - 120920 - If priority was given to compute and it failed, call again to get data from db */
			if (firstComputeFlg == TRUE)
			{
				SET_FLAG(inputArgPtr, Dim_InstrChrono_ComputeFlg, FALSE)
				ret = FIN_InstrChrono(inputArgPtr, instrPtr, chronoPtr, hierHead);
			}

		    if (allocOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
		    return(ret);
	    }

        if (IS_NULLFLD(advAStp, A_AdvA_Conv)==FALSE)
            conv = GET_NUMBER(advAStp, A_AdvA_Conv);

	    FREE_DYNST(advArgStp, AdvA_Arg);
	    FREE_DYNST(advAStp,   A_AdvA);
        /* REF9082 - TEB - 030619 - End */

		/* Update chronological data */
		SET_ENUM(chronoPtr,     A_InstrChrono_NatEn,     chronoNat);
		SET_ID(chronoPtr,       A_InstrChrono_InstrId,   instrId);
		SET_DATETIME(chronoPtr, A_InstrChrono_ValidDate, refDate);
		SET_LONGAMOUNT(chronoPtr,   A_InstrChrono_Val,       conv); /* REF11704 - TGU - 060419 - Change datatype */
		SET_NULL_ID(chronoPtr,  A_InstrChrono_CurrId);


		ret = RET_SUCCEED;
		break;
	    }

	    case ChronoNat_Volatility :
	    {
		double         vola=0.0;

        /* REF9082 - TEB - 030619 - Begin */
        /* Replace Tech with Simcorp */

	    /* Create input structure. */
	    if ((advArgStp = ALLOC_DYNST(AdvA_Arg)) == NULLDYNST)
        {
            if (allocOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
		    MSG_RETURN(RET_MEM_ERR_ALLOC);
        }

        /* Set the intrument id */
        SET_ID(advArgStp, AdvA_Arg_InstrId, GET_ID(instrPtr, A_Instr_Id));

        /* Set the pricing model */
	    SET_ENUM(advArgStp, AdvA_Arg_PricingModelEn, OptModel_None);

        /* Set the reference date */
        SET_DATE(advArgStp, AdvA_Arg_RefDate, refDate.date);
        COPY_DYNFLD(advArgStp, AdvA_Arg, AdvA_Arg_Date, advArgStp, AdvA_Arg, AdvA_Arg_RefDate );

        /* set the keyword nature */
	    SET_ENUM(advArgStp, AdvA_Arg_KeyWordEn, AdvAKeyWord_OPT_IMPVOL);

        /* Allocate the output structure */
	    if ((advAStp = ALLOC_DYNST(A_AdvA)) == NULLDYNST)
	    {
		    FREE_DYNST(advArgStp, AdvA_Arg);
            if (allocOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
		    MSG_RETURN(RET_MEM_ERR_ALLOC);
	    }

	    /* Execute the implied volatility computation */
        if ((ret=SCE_ComputeCurrKeyWord(advArgStp, instrPtr,
				                        NULL, hierHead, advAStp)) != RET_SUCCEED)
        {
		    FREE_DYNST(advArgStp, AdvA_Arg);
		    FREE_DYNST(advAStp,   A_AdvA);
            if (allocOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
		    return(ret);
	    }

        if (IS_NULLFLD(advAStp, A_AdvA_ImpliedVol)==FALSE)
            vola = GET_NUMBER(advAStp, A_AdvA_ImpliedVol);

	    FREE_DYNST(advArgStp, AdvA_Arg);
	    FREE_DYNST(advAStp,   A_AdvA);

        /* REF9082 - TEB - 030619 - End */

		/* Update chronological data */
		SET_ENUM(chronoPtr,     A_InstrChrono_NatEn,     chronoNat);
		SET_ID(chronoPtr,       A_InstrChrono_InstrId,   instrId);
		SET_DATETIME(chronoPtr, A_InstrChrono_ValidDate, refDate);
		SET_LONGAMOUNT(chronoPtr,   A_InstrChrono_Val,       vola); /* REF11704 - TGU - 060419 - Change datatype */
		SET_NULL_ID(chronoPtr,  A_InstrChrono_CurrId);

		ret = RET_SUCCEED;
		break;
	     }

	     case ChronoNat_Delta :
	     case ChronoNat_Gamma :
	     case ChronoNat_Omega :
	     case ChronoNat_Rho :
	     case ChronoNat_Theta :
	     case ChronoNat_SensitivityQty :
	     case ChronoNat_SensitivityStrike :
	     {
		double         sens=0.0;
        /* REF9082 - TEB - 030619 - Begin */
        /* Replace Tech with Simcorp */

	    /* Create input structure. */
	    if ((advArgStp = ALLOC_DYNST(AdvA_Arg)) == NULLDYNST)
        {
		    if (allocOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
		    MSG_RETURN(RET_MEM_ERR_ALLOC);
        }

        /* Set the sensitivity */
		switch (chronoNat)
		{
		    case ChronoNat_Delta :
                 SET_ENUM(advArgStp, AdvA_Arg_SensitivityEn, (ENUM_T) OptSens_Delta);
		         break;
		    case ChronoNat_Gamma :
                 SET_ENUM(advArgStp, AdvA_Arg_SensitivityEn, (ENUM_T) OptSens_Gamma);
		         break;
		    case ChronoNat_Omega :
                 SET_ENUM(advArgStp, AdvA_Arg_SensitivityEn, (ENUM_T) OptSens_Omega);
		         break;
		    case ChronoNat_Rho :
                 SET_ENUM(advArgStp, AdvA_Arg_SensitivityEn, (ENUM_T) OptSens_Rho);
		         break;
		    case ChronoNat_Theta :
                 SET_ENUM(advArgStp, AdvA_Arg_SensitivityEn, (ENUM_T) OptSens_Theta);
		         break;
		    case ChronoNat_SensitivityQty :
                 SET_ENUM(advArgStp, AdvA_Arg_SensitivityEn, (ENUM_T) OptSens_Carry);
		         break;
		    case ChronoNat_SensitivityStrike :
                 SET_ENUM(advArgStp, AdvA_Arg_SensitivityEn, (ENUM_T) OptSens_Strike);
		         break;
		}

        /* Set the intrument id */
        SET_ID(advArgStp, AdvA_Arg_InstrId, GET_ID(instrPtr, A_Instr_Id));

        /* Set the pricing model */
	    SET_ENUM(advArgStp, AdvA_Arg_PricingModelEn, OptModel_None);

        /* Set the reference date */
        SET_DATE(advArgStp, AdvA_Arg_RefDate, refDate.date);
        COPY_DYNFLD(advArgStp, AdvA_Arg, AdvA_Arg_Date, advArgStp, AdvA_Arg, AdvA_Arg_RefDate );

        /* set the keyword nature */
	    SET_ENUM(advArgStp, AdvA_Arg_KeyWordEn, AdvAKeyWord_OPT_SENS);

	    /* Execute the sensitivity computation */
	    if ((ret=FIN_OptSens(advArgStp, TRUE, instrPtr,NULL,
				             hierHead, &sens)) != RET_SUCCEED)
        {
		    FREE_DYNST(advArgStp, AdvA_Arg);
		    if (allocOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
		    return(ret);
	    }

	    FREE_DYNST(advArgStp, AdvA_Arg);

        /* REF9082 - TEB - 030619 - End */

		/* Update chronological data */
		SET_ENUM(chronoPtr,     A_InstrChrono_NatEn,     chronoNat);
		SET_ID(chronoPtr,       A_InstrChrono_InstrId,   instrId);
		SET_DATETIME(chronoPtr, A_InstrChrono_ValidDate, refDate);
		SET_LONGAMOUNT(chronoPtr,   A_InstrChrono_Val,       sens); /* REF11704 - TGU - 060419 - Change datatype */
		SET_NULL_ID(chronoPtr,  A_InstrChrono_CurrId);

		ret = RET_SUCCEED;
		break;
	    }
	    /* END DVP141 - RAK - 960611 */
	    /* --------------------------- */

	    /* REF099 - Computes minimum rating */
	    case ChronoNat_MinRating :
	    {
		    DBA_DYNFLD_STP  getArgPtr=NULLDYNST, ratingPtr=NULLDYNST;

		    if ((getArgPtr = ALLOC_DYNST(Get_Arg)) == NULLDYNST)
            {
                /* SKE - 000303 - Memory Leak */
	            if (allocOk == TRUE) FREE_DYNST(instrPtr, A_Instr);
			    MSG_RETURN(RET_MEM_ERR_ALLOC);
            }

		    if ((ratingPtr = ALLOC_DYNST(A_Rating)) == NULLDYNST)
		    {
                /* SKE - 000303 - Memory Leak */
	            if (allocOk == TRUE) FREE_DYNST(instrPtr, A_Instr);
			    FREE_DYNST(getArgPtr, Get_Arg);
                MSG_RETURN(RET_MEM_ERR_ALLOC);
		    }

		    SET_ID(getArgPtr, Get_Arg_Id,             GET_ID(instrPtr, A_Instr_Id));
		    SET_ID(getArgPtr, Get_Arg_ThirdId,        GET_ID(instrPtr, A_Instr_IssuerThirdId));
		    SET_DATETIME(getArgPtr, Get_Arg_DateTime, refDate);

		    if ((ret = DBA_Get2(Rating, UNUSED, Get_Arg, getArgPtr, A_Rating,
			                &ratingPtr, UNUSED, UNUSED, UNUSED)) == RET_SUCCEED)
		    {
			    /* Update chronological data */
			    SET_ENUM(chronoPtr,     A_InstrChrono_NatEn,     chronoNat);
			    SET_ID(chronoPtr,       A_InstrChrono_InstrId,   instrId);
			    SET_DATETIME(chronoPtr, A_InstrChrono_ValidDate, refDate);
			    SET_NULL_ID(chronoPtr,  A_InstrChrono_CurrId);
			    SET_LONGAMOUNT(chronoPtr,   A_InstrChrono_Val,
				       (NUMBER_T) GET_SMALLINT(ratingPtr, A_Rating_Rank)); /* REF11704 - TGU - 060419 - Change datatype */
		    }

		    FREE_DYNST(getArgPtr, Get_Arg);
		    FREE_DYNST(ratingPtr, A_Rating);
		    break;
	    }

	    case ChronoNat_AverageLife :
		    ret = RET_SUCCEED;
		    break;
	    case ChronoNat_DiscountYield :
		    ret = RET_SUCCEED;
		    break;
	    case ChronoNat_TheoPrice :
		    ret = RET_SUCCEED;
		    break;
	    case ChronoNat_InFineYield :
		    ret = RET_SUCCEED;
		break;
	        case ChronoNat_Probability :
		ret = RET_SUCCEED;
		    break;
	    case ChronoNat_AccrInter :
	    case ChronoNat_AccrInterDenom :
	    case ChronoNat_AccrInterNum :
		    ret = RET_SUCCEED;
		    break;
	    case ChronoNat_Rho2 :
		    ret = RET_SUCCEED;
		    break;
	    case ChronoNat_Vega :
		    ret = RET_SUCCEED;
		    break;
	    }

		/* cashwini-PMSTA-17571-150616 */
		if ((IS_NULLFLD(chronoPtr, A_InstrChrono_CurrId) == FALSE) &&
			(IS_NULLFLD(inputArgPtr, Dim_InstrChrono_CurrId) == FALSE) &&
			GET_ID(chronoPtr, A_InstrChrono_CurrId) != GET_ID(inputArgPtr, Dim_InstrChrono_CurrId))
		{
			FIN_GetExchRate(GET_DATETIME(inputArgPtr, Dim_InstrChrono_RefDate),
				GET_ID(inputInstrPtr, A_InstrChrono_CurrId), GET_ID(inputArgPtr, Dim_InstrChrono_CurrId),
				0, NULLDYNST, NULLDYNST, &exchArgSt, &exch);
			SET_ID(chronoPtr, A_InstrChrono_CurrId, GET_ID(inputArgPtr, Dim_InstrChrono_CurrId));
			SET_LONGAMOUNT(chronoPtr, A_InstrChrono_Val, (GET_LONGAMOUNT(chronoPtr, A_InstrChrono_Val) * exch));
		}

	    /****************************************/
	    /* LOCAL and GLOBAL optimization.       */
	    /* GRD (1996/11/11)                     */
	    /****************************************/

	    /* Is there a result to optimize? */

	    if (chronoPtr != NULL && (procedure = DBA_GetStoredProcs (Get, InstrChrono, UNUSED,
							    	      Dim_InstrChrono, inputArgPtr,
							    	      A_InstrChrono)) != NULL)
	    {
		    DBA_WriteOpti(procedure, Opti_GlobalLocal, inputArgPtr, chronoPtr, TRUE, posIndexLocal, posIndexGlobal);
	    }

	}
    /* SKE - 000303 - Memory Leak */
	if (allocOk == TRUE) FREE_DYNST(instrPtr, A_Instr);

	return(ret);
}

/************************************************************************
**
**  Function    :   FIN_InstrChronoArray()
**
**  Description :   Construct an instrument chronological data array
**                  for received instrument and chronological nature in
**                  received currency
**                  Use frequency and number of reading for select
**
**  Arguments   :   date         end date of the series
**                  freq         frequency at which the data is extracted
**                  freqUnitEn   frequency at which the data is extracted
**                  reading      how many occurrences are to be selected
**                  instrId      instrument identifier
**                  instrPtr     instrument pointer (use for generic)
**                  chronoNatEn  chronological data nature
**                  inputCurrId  currency identifier, by default use instrument currency
**                  method       missing data resolution method - REF7061 - TEB - 030123
**                  array        pointer on an multiArray field
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   DVP005 : Added new function INSTR_CHRONO_ARRAY (96/03/12)
**
**  Modif    	:   BUG336 - RAK - 970410
**  Modif	    :   REF1169 - RAK - 980119
**  Modif	    :   REF3439 - RAK - 990311
**  Modif	    :   REF7061 - TEB - 030123
*************************************************************************/
RET_CODE FIN_InstrChronoArray(DATETIME_T              date,
			                  TINYINT_T               freq,
			                  ENUM_T                  freqUnit,
			                  int                     reading,
			                  ID_T                    instrId,
			                  DBA_DYNFLD_STP          inputInstrPtr,
			                  ENUM_T                  chronoNatEn,
			                  ID_T                    inputCurrId,
                              MISSINGDATA_METHOD_ENUM method,       /* REF7061 - TEB - 030123 */
                              ID_T                    thirdPartyId, /* REF10598 - LJE - 041008 */
                              ID_T                    subNatTypeId, /* REF10598 - LJE - 041008 */
                              FLAG_T                  subNatFlg,    /* REF10598 - LJE - 041011 */
			                  DBA_DYNFLD_STP          array,
                              DBA_HIER_HEAD_STP       hierHead)
{
	DBA_DYNFLD_STP     instrPtr=NULLDYNST, *chronoTab=(DBA_DYNFLD_STP*)NULL;
	DBA_ARRAY_DATA_STP chronoArrayPtr=(DBA_ARRAY_DATA_STP)NULL;	/* REF1169 */
	int                i, j, k;
    int                chronoNbr = 0;
	FLAG_T		       allocOk=FALSE;
	ID_T               currId;
	EXCHANGE_T         exch;
	RET_CODE           ret;
	FIN_EXCHARG_ST     exchArgSt;		                    /* REFXZ */
	DATE_UNIT_ENUM     dateUnit=Year;                       /* REF7061 - TEB - 030123 */
    DATETIME_T         beginDate;                           /* REF7061 - TEB - 030123 */
    DBA_DYNFLD_STP     instrChronoPtr=NULLDYNST;            /* REF7061 - TEB - 030123 */
    DBA_DYNFLD_STP     *chronoTabTmp=(DBA_DYNFLD_STP*)NULL; /* REF7061 - TEB - 030123 */
    NUMBER_T           sumValues, nextValue, prevValue;     /* REF7061 - TEB - 030123 */
    int                nbValues;                            /* REF7061 - TEB - 030123 */

    sumValues = 0;                                          /* REF7061 - TEB - 030123 */
	memset(&exchArgSt, 0, sizeof(FIN_EXCHARG_ST));	/* REFXZ */

	/*DBA_SetConnectNoToExchArg(&exchArgSt, SERV_GetThreadConnNbr()); *//* REF2580 - SSO - 980727 */
	DBA_InitConnectNoToExchArg(&exchArgSt, NULL); /* REF4213 - SSO - 991221 */

	/* BUG336 */
	if (inputInstrPtr != NULLDYNST)
	    instrPtr = inputInstrPtr;

	/* If currency isn't specified as an input, the  */
	/* instrument reference currency should be used. */
	if (inputCurrId != -1)
	{
	    currId = inputCurrId;
	}
	else
	{
	    if (inputInstrPtr != NULLDYNST)
	    {
		    currId = GET_ID(inputInstrPtr, A_Instr_RefCurrId);
	    }
	    else
	    {
            /* REF3913 - 990820 - DDV */
            if (DBA_GetInstrById(instrId, FALSE, &allocOk,
                                 &instrPtr, hierHead, UNUSED, UNUSED) != RET_SUCCEED)
            {
                SYSNAME_T entSqlName;
                strcpy(entSqlName, DBA_GetDictEntitySqlName(Instr));
                MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO,
                             entSqlName, instrId);
                return(RET_DBA_ERR_NODATA);  /* ?? */
            }

		    currId = GET_ID(instrPtr, A_Instr_RefCurrId);
	    }
	}

	/* BUG336 */
	if (instrPtr != NULLDYNST)
	{
	    if (GET_ID(instrPtr, A_Instr_Id) < 0)
	        instrId = GET_ID(instrPtr, A_Instr_ParentInstrId);
	    else
	        instrId = GET_ID(instrPtr, A_Instr_Id);
	}

	if (allocOk == TRUE)
	{ FREE_DYNST(instrPtr, A_Instr); }

	if ((ret = DBA_InstrChronoByFreq(date, freq, (FREQUNIT_ENUM) freqUnit, reading,
		       instrId, chronoNatEn, thirdPartyId, subNatTypeId, subNatFlg, &chronoTab, &chronoNbr)) != RET_SUCCEED) /* REF10598 - LJE - 041008 */
		return(ret);

	/* REF1169 - Now select don't return asked chrono nbr, but existant chrono nbr */
	/* REF3439 - chronoArrayPtr must be initialised (for 1 data too) */
	/* if (chronoNbr > 1) */
	if (chronoNbr > 0)
	{
        /* REF2387 - DDV - 980619 - Sort intrument chrono ascending by date */
	    /* REF3439 - Do sort only for at least 2 data */
	    if (chronoNbr > 1)
            TLS_Sort((char *) chronoTab, chronoNbr, sizeof(DBA_DYNFLD_STP),
                     (TLS_CMPFCT *)FIN_CmpInstrChronoDate, (PTR **) NULL, SortRtnTp_None); /* REF7264 - LJE - 020131 */

        /* REF7061 - TEB - 030123 (Begin) */
	    switch(freqUnit)
	    {
            case FreqUnit_Day:
                dateUnit = Day;
                break;

            case FreqUnit_BusDay:
                dateUnit = Day;
                break;

            case FreqUnit_Week:
                dateUnit = Week;
                break;

            case FreqUnit_Month:
                dateUnit = Month;
                break;

            case FreqUnit_Quarter:
                dateUnit = Quarter;
                break;

            case FreqUnit_Semester:
                dateUnit = Semester;
                break;

            case FreqUnit_Year:
                dateUnit = Year;
                break;
        }

	    beginDate.date = DATE_Move(date.date, (-1) * (reading - 1) * freq, dateUnit);
	    beginDate.time = 0;

        /* Alloc instrChronoPtr structure and chronoTabTmp*/
        if ((instrChronoPtr = ALLOC_DYNST(Freq_InstrChrono)) == NULLDYNST)
            MSG_RETURN(RET_MEM_ERR_ALLOC);


        if ((chronoTabTmp=(DBA_DYNFLD_STP *) CALLOC(reading,
                                                 	sizeof(DBA_DYNFLD_STP))) == NULL)
       	{
            FREE_DYNST(instrChronoPtr, Freq_InstrChrono);
           	MSG_RETURN(RET_MEM_ERR_ALLOC);
        }


        for(i=0; i< reading; i++)
        {
		    if ((chronoTabTmp[i] = ALLOC_DYNST(Freq_InstrChrono)) == NULLDYNST)
		    {
			    for (j=0; j<i; j++)
			        { FREE_DYNST(chronoTabTmp[j], Freq_InstrChrono); }
			    FREE(chronoTabTmp);
                FREE_DYNST(instrChronoPtr, Freq_InstrChrono);
	            DBA_FreeDynStTab(chronoTab, chronoNbr, Freq_InstrChrono);
			    MSG_RETURN(RET_MEM_ERR_ALLOC);
		    }

    	    beginDate.date = DATE_Move(date.date, (-1) * i * freq, dateUnit);

            /* Search right element in array */
            if ((ret = FIN_SearchInstrChronoEltInTab(chronoTab, chronoNbr, beginDate, instrChronoPtr)) == RET_SUCCEED )
            {
                COPY_DYNFLD(chronoTabTmp[i], Freq_InstrChrono, Freq_InstrChrono_InstrId,
                            instrChronoPtr,  Freq_InstrChrono, Freq_InstrChrono_InstrId);
                COPY_DYNFLD(chronoTabTmp[i], Freq_InstrChrono, Freq_InstrChrono_NatEn,
                            instrChronoPtr,  Freq_InstrChrono, Freq_InstrChrono_NatEn);
                COPY_DYNFLD(chronoTabTmp[i], Freq_InstrChrono, Freq_InstrChrono_ValidDate,
                            instrChronoPtr,  Freq_InstrChrono, Freq_InstrChrono_ValidDate);
                COPY_DYNFLD(chronoTabTmp[i], Freq_InstrChrono, Freq_InstrChrono_CurrId,
                            instrChronoPtr,  Freq_InstrChrono, Freq_InstrChrono_CurrId);
                if ( method == MissingDataMethod_LastValid ||
                     DATETIME_CMP(GET_DATETIME(instrChronoPtr, Freq_InstrChrono_ValidDate), beginDate) == 0)
                {
                    COPY_DYNFLD(chronoTabTmp[i], Freq_InstrChrono,  Freq_InstrChrono_Val,
                                instrChronoPtr,  Freq_InstrChrono,  Freq_InstrChrono_Val);

                    /* Calculate exchange on value */
                    if (IS_NULLFLD(chronoTabTmp[i], Freq_InstrChrono_Val) == FALSE &&
                        IS_NULLFLD(chronoTabTmp[i], Freq_InstrChrono_CurrId) == FALSE &&
                        GET_ID(chronoTabTmp[i], Freq_InstrChrono_CurrId) != currId)
                    {
                        FIN_GetExchRate(GET_DATETIME(chronoTabTmp[i], Freq_InstrChrono_ValidDate),
                                        GET_ID(chronoTabTmp[i], Freq_InstrChrono_CurrId), currId,
                                        0, NULLDYNST, NULLDYNST, &exchArgSt, &exch);	/* PMSTA01649 - TGU - 070405 */
	   	                SET_NUMBER(chronoTabTmp[i],
                                   Freq_InstrChrono_Val,
				                   (GET_NUMBER(chronoTabTmp[i], Freq_InstrChrono_Val) * exch));
                    }
                }
                SET_DATETIME(chronoTabTmp[i],Freq_InstrChrono_RequestDate, beginDate);
            }
            else
            {
                MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO,"FIN_InstrChronoArray",
                                GET_CODE(inputInstrPtr, A_Instr_Cd),
                                "FIN_InstrChronoArray - Chrono computing for this instrument failed !");
            }
        }

        FREE_DYNST(instrChronoPtr, Freq_InstrChrono);

        /* Now we can apply the method for missing data */
        nbValues = 0;
        if (method == MissingDataMethod_Average)
		    for (i=0; i<reading; i++)
                if (IS_NULLFLD(chronoTabTmp[i], Freq_InstrChrono_Val) == FALSE)
                {
                    sumValues += GET_NUMBER(chronoTabTmp[i], Freq_InstrChrono_Val);
                    nbValues++;
                }

		for (i=0; i<reading; i++)
		{
            if ( IS_NULLFLD(chronoTabTmp[i], Freq_InstrChrono_Val) == TRUE)
            {
                switch(method)
                {
                    case MissingDataMethod_IgnoreMissing:
                        reading--;
                        FREE_DYNST(chronoTabTmp[i], Freq_InstrChrono);
                        for(j=i; j<reading; j++)
                            chronoTabTmp[j] = chronoTabTmp[j+1];
                        chronoTabTmp[j] = NULLDYNST;
                        i--;
                        break;

                    case MissingDataMethod_Average:
                        if (nbValues!=0)
                            SET_NUMBER(chronoTabTmp[i], Freq_InstrChrono_Val, sumValues/nbValues);
                        break;

                    case MissingDataMethod_Encadrante:
                        if (i == 0)
                        {
                            reading--;
                            FREE_DYNST(chronoTabTmp[i], Freq_InstrChrono);
                            for(j=i; j<reading; j++)
                                chronoTabTmp[j] = chronoTabTmp[j+1];
                            chronoTabTmp[j] = NULLDYNST;
                            i--;
                        }
                        else
                        {
                            prevValue = GET_NUMBER(chronoTabTmp[i-1], Freq_InstrChrono_Val);

                            for (j=i;
                                 j<reading && IS_NULLFLD(chronoTabTmp[j], Freq_InstrChrono_Val) == TRUE;
                                 j++) ; /* I want it */

                            if (j<reading)
                            {
                                nextValue = GET_NUMBER(chronoTabTmp[j], Freq_InstrChrono_Val);
                                for (k=i; k<j; k++)
                                    SET_NUMBER(chronoTabTmp[k], Freq_InstrChrono_Val, (prevValue+nextValue)/2);
                            }
                            else
                            {
                                for(j=i; j<reading; j++)
                                    FREE_DYNST(chronoTabTmp[j], Freq_InstrChrono);
                                reading=i;
                            }
                        }
                        break;
                }
            }
        }
        /* REF7061 - TEB - 030123 (End) */

		if ((chronoArrayPtr = (DBA_ARRAY_DATA_STP)CALLOC(1, sizeof(DBA_ARRAY_DATA_ST))) == (DBA_ARRAY_DATA_STP)NULL) /* REF7264 - LJE - 020128 */
	    {
	    	DBA_FreeDynStTab(chronoTab,    chronoNbr, Freq_InstrChrono);
            DBA_FreeDynStTab(chronoTabTmp, reading,   Freq_InstrChrono);
		    MSG_RETURN(RET_MEM_ERR_ALLOC);
	    }

        if ((chronoArrayPtr->dataTab = ALLOC_DYNST_WITHOUTDEF(reading)) == (PTR)NULL) /* REF8844 - LJE - 030401 */
	    {
	    	DBA_FreeDynStTab(chronoTab,    chronoNbr, Freq_InstrChrono);
            DBA_FreeDynStTab(chronoTabTmp, reading,   Freq_InstrChrono);
		    MSG_RETURN(RET_MEM_ERR_ALLOC);
	    }

	    if ((chronoArrayPtr->notNullFlgTab = (char *)CALLOC(reading, sizeof(char))) == (PTR)NULL) /* REF7264 - LJE - 020128 */
	    {
	    	DBA_FreeDynStTab(chronoTab,    chronoNbr, Freq_InstrChrono);
            DBA_FreeDynStTab(chronoTabTmp, reading,   Freq_InstrChrono);
		    MSG_RETURN(RET_MEM_ERR_ALLOC);
	    }


        /* REF7061 - TEB - 030123 */
	    for (i=0; i<reading; i++)
	    {
	   	    SET_NUMBER(chronoArrayPtr->dataTab,
                       i,
				       GET_NUMBER(chronoTabTmp[i],
                       Freq_InstrChrono_Val));
		    chronoArrayPtr->notNullFlgTab[i] = TRUE;
	    }
	}
    else
    {
        reading = 0;  /* REF7061 - TEB - 030603 */
    }

	DBA_FreeDynStTab(chronoTabTmp, reading,   Freq_InstrChrono); /* REF7061 - TEB - 030123 */
	DBA_FreeDynStTab(chronoTab,    chronoNbr, Freq_InstrChrono);
	SET_MULTIARRAY(array, 0, chronoArrayPtr, (ushort) reading, 1);

	return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_InstrPriceArray()
**
**  Description :   Construct an instrument prices array for received
**                  instrument converted in received currency
**                  Use frequency and number of reading for select
**
**  Arguments   :   date         end date of the series
**                  freq         frequency at which the data is extracted
**                  freqUnitEn   frequency at which the data is extracted
**                  reading      how many occurrences are to be selected
**                  instrId      instrument identifier
**                  instrPtr     instrument pointer (use for generic)
**                  inputCurrId  currency identifier, by default use instrument currency
**                  array        pointer on an multiArray field
**
**  Return      :   RET_SUCCEED or error code
**
** DVP005 : Added new function INSTR_PRICE_ARRAY (96/03/12)
**
**  Modif	:   BUG336 - RAK - 970410
**  Modif	:   REF1894 - RAK - 980423
**  Modif	:   REF2544 - SSO - 980717
**  Modif   :   REF7061 - TEB - 030127
**
*************************************************************************/
RET_CODE FIN_InstrPriceArray(DATETIME_T     date,
			     TINYINT_T               freq,
			     ENUM_T                  freqUnit,
			     int                     reading,
			     ID_T                    instrId,
			     DBA_DYNFLD_STP          inputInstrPtr,
			     ID_T                    inputCurrId,
                 ID_T                    valRuleId,
			     DBA_DYNFLD_STP          valRulePtr,
			     DBA_DYNFLD_STP          extPos,
			     DBA_DYNFLD_STP          array,
                 DBA_HIER_HEAD_STP       hierHead )
{

    /* REF7061 - TEB - 030127 */
    /* All code is moved to new function FIN_InstrPriceArray2 */
    /* Just call it with old default method */
    return(FIN_InstrPriceArray2(date,
                                freq,
                                freqUnit,
                                reading,
                                instrId,
                                inputInstrPtr,
                                inputCurrId,
                                MissingDataMethod_LastValid,
                                valRuleId,
                                valRulePtr,
                                extPos,
                                array,
                                hierHead,
                                ZERO_ID));      /* PMSTA - 32764 - SILPA - 181010*/

}

/************************************************************************
**
**  Function    :   FIN_InstrPriceArray2()
**
**  Description :   Construct an instrument prices array for received
**                  instrument converted in received currency
**                  Use frequency and number of reading for select
**
**  Arguments   :   date         end date of the series
**                  freq         frequency at which the data is extracted
**                  freqUnitEn   frequency at which the data is extracted
**                  reading      how many occurrences are to be selected
**                  instrId      instrument identifier
**                  instrPtr     instrument pointer (use for generic)
**                  inputCurrId  currency identifier, by default use instrument currency
**                  method       missing data resolution methode
**                  array        pointer on an multiArray field
**
**  Return      :   RET_SUCCEED or error code
**
** DVP005 : Added new function INSTR_PRICE_ARRAY (96/03/12)
**
**  Modif	:   BUG336 - RAK - 970410
**  Modif	:   REF1894 - RAK - 980423
**  Modif	:   REF2544 - SSO - 980717
**  Modif   :   REF7061 - TEB - 030127
**	Modif	:   PMSTA - 32764 - SILPA - 180929
**
*************************************************************************/
RET_CODE FIN_InstrPriceArray2(DATETIME_T     date,
			     TINYINT_T               freq,
			     ENUM_T                  freqUnit,
			     int                     reading,
			     ID_T                    instrId,
			     DBA_DYNFLD_STP          inputInstrPtr,
			     ID_T                    inputCurrId,
                 MISSINGDATA_METHOD_ENUM method,       /* REF7061 - TEB - 021223 */
                 ID_T                    valRuleId,
			     DBA_DYNFLD_STP          valRulePtr,
			     DBA_DYNFLD_STP          extPos,
			     DBA_DYNFLD_STP          array,
                 DBA_HIER_HEAD_STP       hierHead,
                 ID_T                    ptfId)    /* PMSTA - 32764 - SILPA - 181010 */
{
	DBA_DYNFLD_STP     *priceTab=(DBA_DYNFLD_STP*)NULL, instrPtr=NULLDYNST;
	DBA_ARRAY_DATA_STP priceArrayPtr;
	int                priceNbr = 0;
        int                i;
	FLAG_T             allocOk;
	ID_T               currId;
	RET_CODE           ret;

	/* --------------------------- */
	/* BEGIN DVP142 - RAK - 960612 */
	if (inputInstrPtr != NULLDYNST)
		instrPtr = inputInstrPtr;
	allocOk = FALSE;

	/* If currency isn't specified as an input, the  */
	/* instrument reference currency should be used. */
	if (inputCurrId != -1)
	{
	    currId = inputCurrId;
	}
	else
	{
	    if (instrPtr != NULLDYNST)
	    {
		currId = GET_ID(instrPtr, A_Instr_RefCurrId);
	    }
	    else
	    {
                /* REF3913 - 990820 - DDV */
                if ((ret = DBA_GetInstrById(instrId, FALSE, &allocOk,
                                            &instrPtr, hierHead, UNUSED, UNUSED)) != RET_SUCCEED)
                {
                        SYSNAME_T entSqlName;
                        strcpy(entSqlName, DBA_GetDictEntitySqlName(Instr));
                        MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO,
                                     entSqlName, instrId);
                        return(ret);  /* ?? */
                }
		currId = GET_ID(instrPtr, A_Instr_RefCurrId);
	    }
	}

	/* BUG336 */
	if (instrPtr != NULLDYNST)
	{
	    if (GET_ID(instrPtr, A_Instr_Id) < 0)
	        instrId = GET_ID(instrPtr, A_Instr_ParentInstrId);
	    else
	        instrId = GET_ID(instrPtr, A_Instr_Id);
	}

	if ((ret = DBA_InstrPriceByFreq(date, freq, (FREQUNIT_ENUM)  freqUnit,
                       reading, instrId, instrPtr, currId,
                       valRuleId, valRulePtr, extPos, method, /* REF7061 - TEB - 030123 */
                       &priceTab, &priceNbr, hierHead, ptfId)) != RET_SUCCEED)  /*  PMSTA - 32764 - SILPA - 181010  */
	{
		if (allocOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
		return(ret);
	}

	if ((priceArrayPtr = (DBA_ARRAY_DATA_STP)CALLOC(1, sizeof(DBA_ARRAY_DATA_ST))) == (DBA_ARRAY_DATA_STP)NULL) /* REF7264 - LJE - 020128 */
	{
	    	DBA_FreeDynStTab(priceTab, priceNbr, Freq_InstrPrice);
		if (allocOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
		MSG_RETURN(RET_MEM_ERR_ALLOC);
	}

	/* RAK - 980423 - Don't alloc dataTab and notNullFlgTab if priceNbr = 0 */
	if (priceNbr > 0)
	{
        if ((priceArrayPtr->dataTab = ALLOC_DYNST_WITHOUTDEF(priceNbr)) == (PTR)NULL) /* REF8844 - LJE - 030401 */
	    {
	    	DBA_FreeDynStTab(priceTab, priceNbr, Freq_InstrPrice);
		if (allocOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
		MSG_RETURN(RET_MEM_ERR_ALLOC);
	    }

	    if ((priceArrayPtr->notNullFlgTab = (char *)CALLOC(priceNbr, sizeof(char))) == (PTR)NULL) /* REF7264 - LJE - 020128 */
	    {
	    	DBA_FreeDynStTab(priceTab, priceNbr, Freq_InstrPrice);
		if (allocOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
		MSG_RETURN(RET_MEM_ERR_ALLOC);
	    }

	    /* REF2544 - SSO - 980717 - TLS_Sort is moved to DBA_InstrPriceByFreq */
		    /* REF2387 - DDV - 980619 - Sort price array ascending by date */
		/* TLS_Sort((char *) priceTab, priceNbr, sizeof(DBA_DYNFLD_STP),
                     FIN_CmpInstrPriceDate, (PTR **) NULL, SortRtnTp_None);
		*/

	    for (i=0; i<priceNbr; i++)
	    {
		/* REF1894 - Don't read priceTab[i] if it's not allocated. */
		if (priceTab[i] != NULLDYNST &&
		    IS_NULLFLD(priceTab[i], Freq_InstrPrice_Price) == FALSE)
		{
			SET_PRICE(priceArrayPtr->dataTab,i,GET_PRICE(priceTab[i], Freq_InstrPrice_Price)); /* REF7296 - LJE - 020501 */
			priceArrayPtr->notNullFlgTab[i] = TRUE;
		}
	    }
	}

	DBA_FreeDynStTab(priceTab, priceNbr, Freq_InstrPrice);
	SET_MULTIARRAY(array, 0, priceArrayPtr, (ushort) priceNbr, 1);

	if (allocOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
	return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_ExchRateArray()
**
**  Description :   Construct an exchange rate array for received currencies
**                  Use frequency and number of reading for select
**                  The database is required to retrieve a series of exchange
**                  rates against the system currency. If both the input
**                  currencies are different from the system currency, the
**                  request is done in two parts. The "crossing" of exchange
**                  rates is done in C.
**
**  Arguments   :   date         end date of the series
**                  freq         frequency at which the data is extracted
**                  freqUnitEn   frequency at which the data is extracted
**                  reading      how many occurrences are to be selected
**                  currId       currency identifier
**                  underCurrId  underlying currency identifier
**                  method       missing data resolution method           - REF7061 - TEB - 030127
**                  array        pointer on an multiArray field
**
**  Return      :   RET_SUCCEED or error code
**
** DVP005 : Added new function EXCH_RATE_ARRAY (96/03/12)
**
** Modif	:   REF1894 - RAK - 980423
** Modif	:   REF2544 - SSO - 980717
**              REF7061 - TEB - 030127
**
*************************************************************************/
RET_CODE FIN_ExchRateArray(DATETIME_T     date,
			   TINYINT_T               freq,
			   ENUM_T                  freqUnit,
			   int                     reading,
			   ID_T                    currId,
			   ID_T                    underCurrId,
               MISSINGDATA_METHOD_ENUM method,      /* REF7061 - TEB - 030121 */
			   ID_T                    valRuleId,
               DBA_DYNFLD_STP          valRulePtr,
			   DBA_DYNFLD_STP          array)
{
	DBA_DYNFLD_STP     *exchTab=(DBA_DYNFLD_STP*)NULL;
	DBA_ARRAY_DATA_STP exchArrayPtr;
	int                i;
        int                exchNbr = 0;
	RET_CODE           ret;

	if ((ret = DBA_ExchRateByFreq(date, freq, (FREQUNIT_ENUM)  freqUnit, reading,
                                      currId, underCurrId, valRuleId, valRulePtr, method, &exchTab, &exchNbr)) != RET_SUCCEED) /* REF7061 - TEB - 030123*/
		return(ret);

	if ((exchArrayPtr = (DBA_ARRAY_DATA_STP)CALLOC(1, sizeof(DBA_ARRAY_DATA_ST))) == (DBA_ARRAY_DATA_STP)NULL) /* REF7264 - LJE - 020128 */
	{
	    	DBA_FreeDynStTab(exchTab, exchNbr, Freq_ExchRate);
		MSG_RETURN(RET_MEM_ERR_ALLOC);
	}

    if ((exchArrayPtr->dataTab = ALLOC_DYNST_WITHOUTDEF(exchNbr)) == (PTR)NULL) /* REF8844 - LJE - 030401 */
	{
	    	DBA_FreeDynStTab(exchTab, exchNbr, Freq_ExchRate);
		MSG_RETURN(RET_MEM_ERR_ALLOC);
	}

	if ((exchArrayPtr->notNullFlgTab = (char *)CALLOC(exchNbr, sizeof(char))) == (PTR)NULL) /* REF7264 - LJE - 020128 */
	{
	    	DBA_FreeDynStTab(exchTab, exchNbr, Freq_ExchRate);
		MSG_RETURN(RET_MEM_ERR_ALLOC);
	}

	/* REF2544 - SSO - 980717 - TLS_Sort is moved to DBA_ExchRateByFreq */
            /* REF2387 - DDV - 980619 - Sort exchange rate ascending by date */
	/* TLS_Sort((char *) exchTab, exchNbr, sizeof(DBA_DYNFLD_STP),
		     FIN_CmpExchRateDate, (PTR **) NULL, SortRtnTp_None);
	*/

	for (i=0; i<exchNbr; i++)
	{
		/* REF1894 - Don't read priceTab[i] if it's not allocated. */
		if (exchTab[i] != NULLDYNST &&
		    IS_NULLFLD(exchTab[i], Freq_ExchRate_ExchRate) == FALSE)
		{
			SET_NUMBER(exchArrayPtr->dataTab,i,GET_EXCHANGE(exchTab[i], Freq_ExchRate_ExchRate)); /* REF7296 - LJE - 020501 */
			exchArrayPtr->notNullFlgTab[i] = TRUE;
		}
	}

	DBA_FreeDynStTab(exchTab, exchNbr, Freq_ExchRate);
	SET_MULTIARRAY(array, 0, exchArrayPtr, (ushort) exchNbr, 1);

	return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_PtfChronoArray()
**
**  Description :   Construct an portfolio chronological data array
**                  for received portfolio and chronological nature in
**                  received currency
**                  Use frequency and number of reading for select
**
**  Arguments   :   date         end date of the series
**                  freq         frequency at which the data is extracted
**                  freqUnitEn   frequency at which the data is extracted
**                  reading      how many occurrences are to be selected
**                  ptfId        portfolio identifier
**                  chronoNatEn  chronological data nature
**                  currId       currency identifier
**                  method       missing data resolution method - REF7061 - TEB - 030123
**                  array        pointer on an multiArray field
**
**  Return      :   RET_SUCCEED or error code
**
** DVP005       :   Added new function PORT_CHRONO_ARRAY (96/03/12)
**  Modif	    :   REF7061 - TEB - 030123
**
*************************************************************************/
RET_CODE FIN_PtfChronoArray(DATETIME_T              date,
			                TINYINT_T               freq,
			                ENUM_T                  freqUnit,
			                int                     reading,
			                ID_T                    ptfId,
			                DBA_DYNFLD_STP          inputPtfPtr, /* DVP142 - RAK - 960612 */
			                ENUM_T                  chronoNatEn,
			                ID_T                    inputCurrId,
                            MISSINGDATA_METHOD_ENUM method,      /* REF7061 - TEB - 030123 */
                            DBA_DYNFLD_STP          array,
		                    DBA_HIER_HEAD_STP       hierHead)
{
	DBA_DYNFLD_STP     ptfPtr=NULLDYNST, *chronoTab=(DBA_DYNFLD_STP*)NULL;
	DBA_ARRAY_DATA_STP chronoArrayPtr=(DBA_ARRAY_DATA_STP)NULL; /* REF7061 - TEB - 030123 */
	EXCHANGE_T         exch;
	ID_T               currId;
	int                i, j, k;
    FLAG_T             allocFlg = FALSE;
    int                chronoNbr = 0;
	RET_CODE           ret;
	FIN_EXCHARG_ST     exchArgSt;			                /* REFXZ */
	DATE_UNIT_ENUM     dateUnit=Year;                       /* REF7061 - TEB - 030123 */
    DATETIME_T         beginDate;                           /* REF7061 - TEB - 030123 */
    DBA_DYNFLD_STP     ptfChronoPtr=NULLDYNST;              /* REF7061 - TEB - 030123 */
    DBA_DYNFLD_STP     *chronoTabTmp=(DBA_DYNFLD_STP*)NULL; /* REF7061 - TEB - 030123 */
    NUMBER_T           sumValues, nextValue, prevValue;     /* REF7061 - TEB - 030123 */
    int                nbValues;                            /* REF7061 - TEB - 030123 */

    sumValues = 0;                                          /* REF7061 - TEB - 030123 */
	memset(&exchArgSt, 0, sizeof(FIN_EXCHARG_ST));

	/* DBA_SetConnectNoToExchArg(&exchArgSt, SERV_GetThreadConnNbr());*/ /* REF2580 - SSO - 980727 */
	DBA_InitConnectNoToExchArg(&exchArgSt, NULL); /* REF4213 - SSO - 991221 */


	/* If currency isn't specified as an input, */
	/* the portfolio currency should be used.   */
	if (inputCurrId != -1)
	{
	    currId = inputCurrId;
	}
	else
	{
	    if (inputPtfPtr != NULLDYNST)
	    {
		    currId = GET_ID(inputPtfPtr, A_Ptf_CurrId);
	    }
	    else
	    {
	        /* REF3913 - DDV - 991014 */
	        if (DBA_GetPtfById(ptfId, FALSE, &allocFlg,
	                           &ptfPtr, hierHead, UNUSED, UNUSED) != RET_SUCCEED)
            {
			    SYSNAME_T entSqlName;
			    strcpy(entSqlName, DBA_GetDictEntitySqlName(Ptf));
			    MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO, entSqlName, ptfId);
	   		    return(RET_DBA_ERR_NODATA);  /* ?? */
            }

		    currId = GET_ID(ptfPtr, A_Ptf_CurrId);
            if (allocFlg == TRUE) {FREE_DYNST(ptfPtr, A_Ptf);}
	    }
	}

	if ((ret = DBA_PtfChronoByFreq(date, freq, (FREQUNIT_ENUM) freqUnit, reading,
		       ptfId, chronoNatEn, &chronoTab, &chronoNbr)) != RET_SUCCEED)
		return(ret);

    /* REF 7061 - TEB - 030124 */
	if (chronoNbr > 0)
	{
        /* REF2387 - DDV - 980619 - Sort portfolio chrono ascending by date */
	    if (chronoNbr > 1)
            TLS_Sort((char *) chronoTab, chronoNbr, sizeof(DBA_DYNFLD_STP),
                     (TLS_CMPFCT *)FIN_CmpPtfChronoDate, (PTR **) NULL, SortRtnTp_None); /* REF7264 - LJE - 020131 */

        /* REF7061 - TEB - 030123 (Begin) */
	    switch(freqUnit)
	    {
            case FreqUnit_Day:
                dateUnit = Day;
                break;

            case FreqUnit_BusDay:
                dateUnit = Day;
                break;

            case FreqUnit_Week:
                dateUnit = Week;
                break;

            case FreqUnit_Month:
                dateUnit = Month;
                break;

            case FreqUnit_Quarter:
                dateUnit = Quarter;
                break;

            case FreqUnit_Semester:
                dateUnit = Semester;
                break;

            case FreqUnit_Year:
                dateUnit = Year;
                break;
        }

	    beginDate.date = DATE_Move(date.date, (-1) * (reading - 1) * freq, dateUnit);
	    beginDate.time = 0;

        /* Alloc ptfChronoPtr structure and chronoTabTmp*/
        if ((ptfChronoPtr = ALLOC_DYNST(Freq_PtfChrono)) == NULLDYNST)
            MSG_RETURN(RET_MEM_ERR_ALLOC);

        if ((chronoTabTmp=(DBA_DYNFLD_STP *) CALLOC(reading,
                                                 	sizeof(DBA_DYNFLD_STP))) == NULL)
       	{
            FREE_DYNST(ptfChronoPtr, Freq_PtfChrono);
           	MSG_RETURN(RET_MEM_ERR_ALLOC);
        }

        for(i=0; i< reading; i++)
        {
		    if ((chronoTabTmp[i] = ALLOC_DYNST(Freq_PtfChrono)) == NULLDYNST)
		    {
			    for (j=0; j<i; j++)
			        { FREE_DYNST(chronoTabTmp[j], Freq_PtfChrono); }
			    FREE(chronoTabTmp);
                FREE_DYNST(ptfChronoPtr, Freq_PtfChrono);
	            DBA_FreeDynStTab(chronoTab, chronoNbr, Freq_PtfChrono);
			    MSG_RETURN(RET_MEM_ERR_ALLOC);
		    }

    	    beginDate.date = DATE_Move(date.date, (-1) * i * freq, dateUnit);

            /* Search right element in array */
            if ((ret = FIN_SearchPtfChronoEltInTab(chronoTab, chronoNbr, beginDate, ptfChronoPtr)) == RET_SUCCEED )
            {
                COPY_DYNFLD(chronoTabTmp[i], Freq_PtfChrono, Freq_PtfChrono_PtfId,
                            ptfChronoPtr,    Freq_PtfChrono, Freq_PtfChrono_PtfId);
                COPY_DYNFLD(chronoTabTmp[i], Freq_PtfChrono, Freq_PtfChrono_NatEn,
                            ptfChronoPtr,    Freq_PtfChrono, Freq_PtfChrono_NatEn);
                COPY_DYNFLD(chronoTabTmp[i], Freq_PtfChrono, Freq_PtfChrono_ValidDate,
                            ptfChronoPtr,    Freq_PtfChrono, Freq_PtfChrono_ValidDate);
                COPY_DYNFLD(chronoTabTmp[i], Freq_PtfChrono, Freq_PtfChrono_CurrId,
                            ptfChronoPtr,    Freq_PtfChrono, Freq_PtfChrono_CurrId);
                if ( method == MissingDataMethod_LastValid ||
                     DATETIME_CMP(GET_DATETIME(ptfChronoPtr, Freq_PtfChrono_ValidDate), beginDate) == 0)
                {
                    COPY_DYNFLD(chronoTabTmp[i], Freq_PtfChrono,  Freq_PtfChrono_Val,
                                ptfChronoPtr,  Freq_PtfChrono,  Freq_PtfChrono_Val);

                    /* Calculate exchange on value */
                    if (IS_NULLFLD(chronoTabTmp[i], Freq_PtfChrono_Val) == FALSE &&
                        IS_NULLFLD(chronoTabTmp[i], Freq_PtfChrono_CurrId) == FALSE &&
                        GET_ID(chronoTabTmp[i], Freq_PtfChrono_CurrId) != currId)
                    {
                        FIN_GetExchRate(GET_DATETIME(chronoTabTmp[i], Freq_PtfChrono_ValidDate),
                                        GET_ID(chronoTabTmp[i], Freq_PtfChrono_CurrId), currId,
                                        0, NULLDYNST, NULLDYNST, &exchArgSt, &exch);	/* PMSTA01649 - TGU - 070405 */
	   	                SET_NUMBER(chronoTabTmp[i],
                                   Freq_PtfChrono_Val,
				                   (GET_NUMBER(chronoTabTmp[i], Freq_PtfChrono_Val) * exch));
                    }
                }
                SET_DATETIME(chronoTabTmp[i],Freq_PtfChrono_RequestDate, beginDate);
            }
            else
            {
                MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO,"FIN_PtfChronoArray",
                                GET_CODE(inputPtfPtr, A_Ptf_Cd),
                                "FIN_PtfChronoArray - Chrono computing for this portfolio failed !");
            }
        }

        FREE_DYNST(ptfChronoPtr, Freq_PtfChrono);

        /* Now we can apply the method for missing data */
        nbValues = 0;
        if (method == MissingDataMethod_Average)
		    for (i=0; i<reading; i++)
                if (IS_NULLFLD(chronoTabTmp[i], Freq_PtfChrono_Val) == FALSE)
                {
                    sumValues += GET_NUMBER(chronoTabTmp[i], Freq_PtfChrono_Val);
                    nbValues++;
                }

		for (i=0; i<reading; i++)
		{
            if ( IS_NULLFLD(chronoTabTmp[i], Freq_PtfChrono_Val) == TRUE)
            {
                switch(method)
                {
                    case MissingDataMethod_IgnoreMissing:
                        reading--;
                        FREE_DYNST(chronoTabTmp[i], Freq_PtfChrono);
                        for(j=i; j<reading; j++)
                            chronoTabTmp[j] = chronoTabTmp[j+1];
                        chronoTabTmp[j] = NULLDYNST;
                        i--;
                        break;

                    case MissingDataMethod_Average:
                        if (nbValues!=0)
                            SET_NUMBER(chronoTabTmp[i], Freq_PtfChrono_Val, sumValues/nbValues);
                        break;

                    case MissingDataMethod_Encadrante:
                        if (i == 0)
                        {
                            reading--;
                            FREE_DYNST(chronoTabTmp[i], Freq_PtfChrono);
                            for(j=i; j<reading; j++)
                                chronoTabTmp[j] = chronoTabTmp[j+1];
                            chronoTabTmp[j] = NULLDYNST;
                            i--;
                        }
                        else
                        {
                            prevValue = GET_NUMBER(chronoTabTmp[i-1], Freq_PtfChrono_Val);

                            for (j=i;
                                 j<reading && IS_NULLFLD(chronoTabTmp[j], Freq_PtfChrono_Val) == TRUE;
                                 j++) ; /* I want it */

                            if (j<reading)
                            {
                                nextValue = GET_NUMBER(chronoTabTmp[j], Freq_PtfChrono_Val);
                                for (k=i; k<j; k++)
                                    SET_NUMBER(chronoTabTmp[k], Freq_PtfChrono_Val, (prevValue+nextValue)/2);
                            }
                            else
                            {
                                for(j=i; j<reading; j++)
                                    FREE_DYNST(chronoTabTmp[j], Freq_PtfChrono);
                                reading=i;
                            }
                        }
                        break;
                }
            }
        }
        /* REF7061 - TEB - 030123 (End) */

        if ((chronoArrayPtr = (DBA_ARRAY_DATA_STP)CALLOC(1, sizeof(DBA_ARRAY_DATA_ST))) == (DBA_ARRAY_DATA_STP)NULL)
	    {
	        DBA_FreeDynStTab(chronoTab,    chronoNbr, Freq_PtfChrono);
            DBA_FreeDynStTab(chronoTabTmp, reading,   Freq_PtfChrono);
		    MSG_RETURN(RET_MEM_ERR_ALLOC);
	    }

        if ((chronoArrayPtr->dataTab = ALLOC_DYNST_WITHOUTDEF(reading)) == (PTR)NULL) /* REF8844 - LJE - 030401 */
	    {
	        DBA_FreeDynStTab(chronoTab,    chronoNbr, Freq_PtfChrono);
            DBA_FreeDynStTab(chronoTabTmp, reading,   Freq_PtfChrono);
		    MSG_RETURN(RET_MEM_ERR_ALLOC);
	    }

	    if ((chronoArrayPtr->notNullFlgTab = (char *)CALLOC(reading, sizeof(char))) == (PTR)NULL)
	    {
	        DBA_FreeDynStTab(chronoTab,    chronoNbr, Freq_PtfChrono);
            DBA_FreeDynStTab(chronoTabTmp, reading,   Freq_PtfChrono);
            MSG_RETURN(RET_MEM_ERR_ALLOC);
	    }


        /* REF7061 - TEB - 030123 */
	    for (i=0; i<reading; i++)
	    {
	   	    SET_NUMBER(chronoArrayPtr->dataTab,
                       i,
                       GET_NUMBER(chronoTabTmp[i],
                       Freq_PtfChrono_Val));
		    chronoArrayPtr->notNullFlgTab[i] = TRUE;
	    }
    }
    else
    {
        reading = 0;  /* REF7061 - TEB - 030603 */
    }

	DBA_FreeDynStTab(chronoTabTmp, reading,   Freq_PtfChrono); /* REF7061 - TEB - 030123 */
    DBA_FreeDynStTab(chronoTab,    chronoNbr, Freq_PtfChrono);
	SET_MULTIARRAY(array, 0, chronoArrayPtr, (ushort) reading, 1);

	return(RET_SUCCEED);
}


/************************************************************************
**
**  Function    :   FIN_ComplChronoArray()
**
**  Description :   Construct an compliance chronological data array
**                  for received portfolio and chronological nature in
**                  received currency
**                  Use frequency and number of reading for select
**
**  Arguments   :   date         end date of the series
**                  freq         frequency at which the data is extracted
**                  freqUnitEn   frequency at which the data is extracted
**                  reading      how many occurrences are to be selected
**                  ptfId        portfolio identifier
**                  chronoNatEn  chronological data nature
**                  currId       currency identifier
**                  method       missing data resolution method - REF7061 - TEB - 030123
**                  array        pointer on an multiArray field
**
**  Return      :   RET_SUCCEED or error code
**
**  Create      :   PMSTA06646 - LJE - 080612
*************************************************************************/
RET_CODE FIN_ComplChronoArray(DBA_DYNFLD_STP          getChrono,
                              DBA_DYNFLD_STP          inputPtfPtr,
                              DBA_DYNFLD_STP          array,
		                      DBA_HIER_HEAD_STP       hierHead)
{
	DBA_DYNFLD_STP     ptfPtr=NULLDYNST, *chronoTab=(DBA_DYNFLD_STP*)NULL;
	DBA_ARRAY_DATA_STP chronoArrayPtr=(DBA_ARRAY_DATA_STP)NULL;
	EXCHANGE_T         exch;
	ID_T               currId, ptfId;
	int                i, j, k;
    FLAG_T             allocFlg = FALSE;
    int                chronoNbr = 0;
	RET_CODE           ret;
	FIN_EXCHARG_ST     exchArgSt;
	DATE_UNIT_ENUM     dateUnit=Year;
    DATETIME_T         beginDate, date;
    DBA_DYNFLD_STP     ptfChronoPtr=NULLDYNST;
    DBA_DYNFLD_STP     *chronoTabTmp=(DBA_DYNFLD_STP*)NULL;
    NUMBER_T           sumValues, nextValue, prevValue;
    int                nbValues;
	TINYINT_T          freq;
	ENUM_T             freqUnit;
	int                reading;
    MISSINGDATA_METHOD_ENUM method;

    sumValues = 0;
	memset(&exchArgSt, 0, sizeof(FIN_EXCHARG_ST));

	DBA_InitConnectNoToExchArg(&exchArgSt, NULL);

	ptfId = GET_ID(getChrono, Chrono_FreqArg_ObjId);
	date = GET_DATETIME(getChrono, Chrono_FreqArg_TillDate);
	freq = GET_TINYINT(getChrono,  Chrono_FreqArg_Freq);
	freqUnit = GET_ENUM(getChrono, Chrono_FreqArg_FreqUnitEn);
	reading = GET_INT(getChrono, Chrono_FreqArg_Reading);
	method = (MISSINGDATA_METHOD_ENUM)GET_ENUM(getChrono, Chrono_FreqArg_MethodEn);

	/* If currency isn't specified as an input, */
	/* the portfolio currency should be used.   */
	if (IS_NULLFLD(getChrono, Chrono_FreqArg_CurrId) == FALSE)
	{
	    currId = GET_ID(getChrono, Chrono_FreqArg_CurrId);
	}
	else
	{
	    if (inputPtfPtr != NULLDYNST)
	    {
		    currId = GET_ID(inputPtfPtr, A_Ptf_CurrId);
	    }
	    else
	    {
	        if (DBA_GetPtfById(ptfId, FALSE, &allocFlg,
	                           &ptfPtr, hierHead, UNUSED, UNUSED) != RET_SUCCEED)
            {
			    SYSNAME_T entSqlName;
			    strcpy(entSqlName, DBA_GetDictEntitySqlName(Ptf));
			    MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO, entSqlName, ptfId);
	   		    return(RET_DBA_ERR_NODATA);
            }

		    currId = GET_ID(ptfPtr, A_Ptf_CurrId);
            if (allocFlg == TRUE) {FREE_DYNST(ptfPtr, A_Ptf);}
	    }
	}

	if ((ret = DBA_ComplChronoByFreq(getChrono, &chronoTab, &chronoNbr)) != RET_SUCCEED)
		return(ret);

	if (chronoNbr > 0)
	{
        /* Sort portfolio chrono ascending by date */
	    if (chronoNbr > 1)
            TLS_Sort((char *) chronoTab, chronoNbr, sizeof(DBA_DYNFLD_STP),
                     (TLS_CMPFCT *)FIN_CmpPtfChronoDate, (PTR **) NULL, SortRtnTp_None);

	    switch(freqUnit)
	    {
            case FreqUnit_Day:
                dateUnit = Day;
                break;

            case FreqUnit_BusDay:
                dateUnit = Day;
                break;

            case FreqUnit_Week:
                dateUnit = Week;
                break;

            case FreqUnit_Month:
                dateUnit = Month;
                break;

            case FreqUnit_Quarter:
                dateUnit = Quarter;
                break;

            case FreqUnit_Semester:
                dateUnit = Semester;
                break;

            case FreqUnit_Year:
                dateUnit = Year;
                break;
        }

	    beginDate.date = DATE_Move(date.date, (-1) * (reading - 1) * freq, dateUnit);
	    beginDate.time = 0;

        /* Alloc ptfChronoPtr structure and chronoTabTmp*/
        if ((ptfChronoPtr = ALLOC_DYNST(Freq_PtfChrono)) == NULLDYNST)
            MSG_RETURN(RET_MEM_ERR_ALLOC);

        if ((chronoTabTmp=(DBA_DYNFLD_STP *) CALLOC(reading,
                                                 	sizeof(DBA_DYNFLD_STP))) == NULL)
       	{
            FREE_DYNST(ptfChronoPtr, Freq_PtfChrono);
           	MSG_RETURN(RET_MEM_ERR_ALLOC);
        }

        for(i=0; i< reading; i++)
        {
		    if ((chronoTabTmp[i] = ALLOC_DYNST(Freq_PtfChrono)) == NULLDYNST)
		    {
			    for (j=0; j<i; j++)
			        { FREE_DYNST(chronoTabTmp[j], Freq_PtfChrono); }
			    FREE(chronoTabTmp);
                FREE_DYNST(ptfChronoPtr, Freq_PtfChrono);
	            DBA_FreeDynStTab(chronoTab, chronoNbr, Freq_PtfChrono);
			    MSG_RETURN(RET_MEM_ERR_ALLOC);
		    }

    	    beginDate.date = DATE_Move(date.date, (-1) * i * freq, dateUnit);

            /* Search right element in array */
            if ((ret = FIN_SearchPtfChronoEltInTab(chronoTab, chronoNbr, beginDate, ptfChronoPtr)) == RET_SUCCEED )
            {
                COPY_DYNFLD(chronoTabTmp[i], Freq_PtfChrono, Freq_PtfChrono_PtfId,
                            ptfChronoPtr,    Freq_PtfChrono, Freq_PtfChrono_PtfId);
                COPY_DYNFLD(chronoTabTmp[i], Freq_PtfChrono, Freq_PtfChrono_NatEn,
                            ptfChronoPtr,    Freq_PtfChrono, Freq_PtfChrono_NatEn);
                COPY_DYNFLD(chronoTabTmp[i], Freq_PtfChrono, Freq_PtfChrono_ValidDate,
                            ptfChronoPtr,    Freq_PtfChrono, Freq_PtfChrono_ValidDate);
                COPY_DYNFLD(chronoTabTmp[i], Freq_PtfChrono, Freq_PtfChrono_CurrId,
                            ptfChronoPtr,    Freq_PtfChrono, Freq_PtfChrono_CurrId);
                if ( method == MissingDataMethod_LastValid ||
                     DATETIME_CMP(GET_DATETIME(ptfChronoPtr, Freq_PtfChrono_ValidDate), beginDate) == 0)
                {
                    COPY_DYNFLD(chronoTabTmp[i], Freq_PtfChrono,  Freq_PtfChrono_Val,
                                ptfChronoPtr,  Freq_PtfChrono,  Freq_PtfChrono_Val);

                    /* Calculate exchange on value */
                    if (IS_NULLFLD(chronoTabTmp[i], Freq_PtfChrono_Val) == FALSE &&
                        IS_NULLFLD(chronoTabTmp[i], Freq_PtfChrono_CurrId) == FALSE &&
                        GET_ID(chronoTabTmp[i], Freq_PtfChrono_CurrId) != currId)
                    {
                        FIN_GetExchRate(GET_DATETIME(chronoTabTmp[i], Freq_PtfChrono_ValidDate),
                                        GET_ID(chronoTabTmp[i], Freq_PtfChrono_CurrId), currId,
                                        0, NULLDYNST, NULLDYNST, &exchArgSt, &exch);
	   	                SET_NUMBER(chronoTabTmp[i],
                                   Freq_PtfChrono_Val,
				                   (GET_NUMBER(chronoTabTmp[i], Freq_PtfChrono_Val) * exch));
                    }
                }
                SET_DATETIME(chronoTabTmp[i],Freq_PtfChrono_RequestDate, beginDate);
            }
            else
            {
                MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO,"FIN_PtfChronoArray",
                                GET_CODE(inputPtfPtr, A_Ptf_Cd),
                                "FIN_PtfChronoArray - Chrono computing for this portfolio failed !");
            }
        }

        FREE_DYNST(ptfChronoPtr, Freq_PtfChrono);

        /* Now we can apply the method for missing data */
        nbValues = 0;
        if (method == MissingDataMethod_Average)
		    for (i=0; i<reading; i++)
                if (IS_NULLFLD(chronoTabTmp[i], Freq_PtfChrono_Val) == FALSE)
                {
                    sumValues += GET_NUMBER(chronoTabTmp[i], Freq_PtfChrono_Val);
                    nbValues++;
                }

		for (i=0; i<reading; i++)
		{
            if ( IS_NULLFLD(chronoTabTmp[i], Freq_PtfChrono_Val) == TRUE)
            {
                switch(method)
                {
                    case MissingDataMethod_IgnoreMissing:
                        reading--;
                        FREE_DYNST(chronoTabTmp[i], Freq_PtfChrono);
                        for(j=i; j<reading; j++)
                            chronoTabTmp[j] = chronoTabTmp[j+1];
                        chronoTabTmp[j] = NULLDYNST;
                        i--;
                        break;

                    case MissingDataMethod_Average:
                        if (nbValues!=0)
                            SET_NUMBER(chronoTabTmp[i], Freq_PtfChrono_Val, sumValues/nbValues);
                        break;

                    case MissingDataMethod_Encadrante:
                        if (i == 0)
                        {
                            reading--;
                            FREE_DYNST(chronoTabTmp[i], Freq_PtfChrono);
                            for(j=i; j<reading; j++)
                                chronoTabTmp[j] = chronoTabTmp[j+1];
                            chronoTabTmp[j] = NULLDYNST;
                            i--;
                        }
                        else
                        {
                            prevValue = GET_NUMBER(chronoTabTmp[i-1], Freq_PtfChrono_Val);

                            for (j=i;
                                 j<reading && IS_NULLFLD(chronoTabTmp[j], Freq_PtfChrono_Val) == TRUE;
                                 j++) ; /* I want it */

                            if (j<reading)
                            {
                                nextValue = GET_NUMBER(chronoTabTmp[j], Freq_PtfChrono_Val);
                                for (k=i; k<j; k++)
                                    SET_NUMBER(chronoTabTmp[k], Freq_PtfChrono_Val, (prevValue+nextValue)/2);
                            }
                            else
                            {
                                for(j=i; j<reading; j++)
                                    FREE_DYNST(chronoTabTmp[j], Freq_PtfChrono);
                                reading=i;
                            }
                        }
                        break;
                }
            }
        }

        if ((chronoArrayPtr = (DBA_ARRAY_DATA_STP)CALLOC(1, sizeof(DBA_ARRAY_DATA_ST))) == (DBA_ARRAY_DATA_STP)NULL)
	    {
	        DBA_FreeDynStTab(chronoTab,    chronoNbr, Freq_PtfChrono);
            DBA_FreeDynStTab(chronoTabTmp, reading,   Freq_PtfChrono);
		    MSG_RETURN(RET_MEM_ERR_ALLOC);
	    }

        if ((chronoArrayPtr->dataTab = ALLOC_DYNST_WITHOUTDEF(reading)) == (PTR)NULL)
	    {
	        DBA_FreeDynStTab(chronoTab,    chronoNbr, Freq_PtfChrono);
            DBA_FreeDynStTab(chronoTabTmp, reading,   Freq_PtfChrono);
		    MSG_RETURN(RET_MEM_ERR_ALLOC);
	    }

	    if ((chronoArrayPtr->notNullFlgTab = (char *)CALLOC(reading, sizeof(char))) == (PTR)NULL)
	    {
	        DBA_FreeDynStTab(chronoTab,    chronoNbr, Freq_PtfChrono);
            DBA_FreeDynStTab(chronoTabTmp, reading,   Freq_PtfChrono);
            MSG_RETURN(RET_MEM_ERR_ALLOC);
	    }


	    for (i=0; i<reading; i++)
	    {
	   	    SET_NUMBER(chronoArrayPtr->dataTab,
                       i,
                       GET_NUMBER(chronoTabTmp[i],
                       Freq_PtfChrono_Val));
		    chronoArrayPtr->notNullFlgTab[i] = TRUE;
	    }
    }
    else
    {
        reading = 0;
    }

	DBA_FreeDynStTab(chronoTabTmp, reading,   Freq_PtfChrono);
    DBA_FreeDynStTab(chronoTab,    chronoNbr, Freq_PtfChrono);
	SET_MULTIARRAY(array, 0, chronoArrayPtr, (ushort) reading, 1);

	return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_ListChronoArray()
**
**  Description :   Construct an list chronological data array
**                  for received list and chronological nature in
**                  received currency
**                  Use frequency and number of reading for select
**
**  Arguments   :   date         end date of the series
**                  freq         frequency at which the data is extracted
**                  freqUnitEn   frequency at which the data is extracted
**                  reading      how many occurrences are to be selected
**                  listId       list identifier
**                  chronoNatEn  chronological data nature
**                  currId       currency identifier
**                  method       missing data resolution method - REF7061 - TEB - 030123
**                  array        pointer on an multiArray field
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation date : REF7292 - LJE - 020130
**  Modif	    :   REF7061 - TEB - 030123
**
*************************************************************************/
RET_CODE FIN_ListChronoArray(DATETIME_T             date,
			                TINYINT_T               freq,
			                ENUM_T                  freqUnit,
			                int                     reading,
			                ID_T                    listId,
			                DBA_DYNFLD_STP          inputListPtr,
			                ENUM_T                  chronoNatEn,
			                ID_T                    inputCurrId,
                            MISSINGDATA_METHOD_ENUM method,      /* REF7061 - TEB - 030123 */
                            DBA_DYNFLD_STP          array,
		                    DBA_HIER_HEAD_STP       )
{
	DBA_DYNFLD_STP     listPtr=NULLDYNST, sList=NULLDYNST, *chronoTab=(DBA_DYNFLD_STP*)NULL;
	DBA_ARRAY_DATA_STP chronoArrayPtr=(DBA_ARRAY_DATA_STP)NULL; /* REF7061 - TEB - 030123 */
	EXCHANGE_T         exch;
	ID_T               currId;
	int                i, j, k;
    int                chronoNbr = 0;
	RET_CODE           ret;
	FIN_EXCHARG_ST     exchArgSt;
	DATE_UNIT_ENUM     dateUnit=Year;                       /* REF7061 - TEB - 030123 */
    DATETIME_T         beginDate;                           /* REF7061 - TEB - 030123 */
    DBA_DYNFLD_STP     listChronoPtr=NULLDYNST;             /* REF7061 - TEB - 030123 */
    DBA_DYNFLD_STP     *chronoTabTmp=(DBA_DYNFLD_STP*)NULL; /* REF7061 - TEB - 030123 */
    NUMBER_T           sumValues, nextValue, prevValue;     /* REF7061 - TEB - 030123 */
    int                nbValues;                            /* REF7061 - TEB - 030123 */

    sumValues = 0;                                          /* REF7061 - TEB - 030123 */
	memset(&exchArgSt, 0, sizeof(FIN_EXCHARG_ST));

	DBA_InitConnectNoToExchArg(&exchArgSt, NULL);


	/* If currency isn't specified as an input, */
	/* the portfolio currency should be used.   */
	if (inputCurrId != -1)
	{
	    currId = inputCurrId;
	}
	else
	{
	    if (inputListPtr != NULLDYNST)
	    {
		    currId = GET_ID(inputListPtr, A_List_CurrId);
	    }
	    else
	    {
			listPtr = ALLOC_DYNST(A_List);
			sList   = ALLOC_DYNST(S_List);

			SET_ID(sList, S_List_Id, listId);
			if (DBA_Get2(List, UNUSED, S_List, sList, A_List, &listPtr, UNUSED, UNUSED, UNUSED) != TRUE)
			{
			    SYSNAME_T entSqlName;
			    strcpy(entSqlName, DBA_GetDictEntitySqlName(List));
			    MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO, entSqlName, listId);
				FREE_DYNST(listPtr, A_List);
	   		    return(RET_DBA_ERR_NODATA);  /* ?? */
            }

		    currId = GET_ID(listPtr, A_List_CurrId);
            FREE_DYNST(listPtr, A_List);
	    }
	}

	if ((ret = DBA_ListChronoByFreq(date, freq, (FREQUNIT_ENUM) freqUnit, reading,
		       listId, chronoNatEn, &chronoTab, &chronoNbr)) != RET_SUCCEED)
		return(ret);

	if (chronoNbr > 0)
	{
	    /* Do sort only for at least 2 data */
	    if (chronoNbr > 1)
            /* Sort list chrono ascending by date */
            TLS_Sort((char *) chronoTab, chronoNbr, sizeof(DBA_DYNFLD_STP),
                     (TLS_CMPFCT *)FIN_CmpListChronoDate, (PTR **) NULL, SortRtnTp_None); /* REF7264 - LJE - 020131 */

        /* REF7061 - TEB - 030123 (Begin) */
	    switch(freqUnit)
	    {
            case FreqUnit_Day:
                dateUnit = Day;
                break;

            case FreqUnit_BusDay:
                dateUnit = Day;
                break;

            case FreqUnit_Week:
                dateUnit = Week;
                break;

            case FreqUnit_Month:
                dateUnit = Month;
                break;

            case FreqUnit_Quarter:
                dateUnit = Quarter;
                break;

            case FreqUnit_Semester:
                dateUnit = Semester;
                break;

            case FreqUnit_Year:
                dateUnit = Year;
                break;
        }

	    beginDate.date = DATE_Move(date.date, (-1) * (reading - 1) * freq, dateUnit);
	    beginDate.time = 0;

        /* Alloc listChronoPtr structure and chronoTabTmp */
        if ((listChronoPtr = ALLOC_DYNST(Freq_ListChrono)) == NULLDYNST)
            MSG_RETURN(RET_MEM_ERR_ALLOC);

        if ((chronoTabTmp=(DBA_DYNFLD_STP *) CALLOC(reading,
                                                 	sizeof(DBA_DYNFLD_STP))) == NULL)
       	{
            FREE_DYNST(listChronoPtr, Freq_ListChrono);
           	MSG_RETURN(RET_MEM_ERR_ALLOC);
        }

        for(i=0; i< reading; i++)
        {
		    if ((chronoTabTmp[i] = ALLOC_DYNST(Freq_ListChrono)) == NULLDYNST)
		    {
			    for (j=0; j<i; j++)
			        { FREE_DYNST(chronoTabTmp[j], Freq_ListChrono); }
			    FREE(chronoTabTmp);
                FREE_DYNST(listChronoPtr, Freq_ListChrono);
	            DBA_FreeDynStTab(chronoTab, chronoNbr, Freq_ListChrono);
			    MSG_RETURN(RET_MEM_ERR_ALLOC);
		    }

    	    beginDate.date = DATE_Move(date.date, (-1) * i * freq, dateUnit);

                        /* Search right element in array */

            if ((ret = FIN_SearchListChronoEltInTab(chronoTab, chronoNbr, beginDate, listChronoPtr)) == RET_SUCCEED )
            {
                COPY_DYNFLD(chronoTabTmp[i], Freq_ListChrono, Freq_ListChrono_ListId,
                            listChronoPtr,   Freq_ListChrono, Freq_ListChrono_ListId);
                COPY_DYNFLD(chronoTabTmp[i], Freq_ListChrono, Freq_ListChrono_NatEn,
                            listChronoPtr,   Freq_ListChrono, Freq_ListChrono_NatEn);
                COPY_DYNFLD(chronoTabTmp[i], Freq_ListChrono, Freq_ListChrono_ValidDate,
                            listChronoPtr,   Freq_ListChrono, Freq_ListChrono_ValidDate);
                COPY_DYNFLD(chronoTabTmp[i], Freq_ListChrono, Freq_ListChrono_CurrId,
                            listChronoPtr,   Freq_ListChrono, Freq_ListChrono_CurrId);
                if ( method == MissingDataMethod_LastValid ||
                     DATETIME_CMP(GET_DATETIME(listChronoPtr, Freq_ListChrono_ValidDate), beginDate) == 0)
                {
                    COPY_DYNFLD(chronoTabTmp[i], Freq_ListChrono,  Freq_ListChrono_Val,
                                listChronoPtr,  Freq_ListChrono,  Freq_ListChrono_Val);

                    /* Calculate exchange on value */
                    if (IS_NULLFLD(chronoTabTmp[i], Freq_ListChrono_Val) == FALSE &&
                        IS_NULLFLD(chronoTabTmp[i], Freq_ListChrono_CurrId) == FALSE &&
                        GET_ID(chronoTabTmp[i], Freq_ListChrono_CurrId) != currId)
                    {
                        FIN_GetExchRate(GET_DATETIME(chronoTabTmp[i], Freq_ListChrono_ValidDate),
                                        GET_ID(chronoTabTmp[i], Freq_ListChrono_CurrId), currId,
                                        0, NULLDYNST, NULLDYNST, &exchArgSt, &exch);				/* PMSTA01649 - TGU - 070402 */
	   	                SET_NUMBER(chronoTabTmp[i],
                                   Freq_ListChrono_Val,
				                   (GET_NUMBER(chronoTabTmp[i], Freq_ListChrono_Val) * exch));
                    }
                }
                SET_DATETIME(chronoTabTmp[i],Freq_ListChrono_RequestDate, beginDate);
            }
            else
            {
                MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO,"FIN_ListChronoArray",
                                GET_CODE(inputListPtr, A_List_Cd),
                                "FIN_ListChronoArray - Chrono computing for this list failed !");
            }
        }

        FREE_DYNST(listChronoPtr, Freq_ListChrono);

        /* Now we can apply the method for missing data */
        nbValues = 0;
        if (method == MissingDataMethod_Average)
		    for (i=0; i<reading; i++)
                if (IS_NULLFLD(chronoTabTmp[i], Freq_ListChrono_Val) == FALSE)
                {
                    sumValues += GET_NUMBER(chronoTabTmp[i], Freq_ListChrono_Val);
                    nbValues++;
                }

		for (i=0; i<reading; i++)
		{
            if ( IS_NULLFLD(chronoTabTmp[i], Freq_ListChrono_Val) == TRUE)
            {
                switch(method)
                {
                    case MissingDataMethod_IgnoreMissing:
                        reading--;
                        FREE_DYNST(chronoTabTmp[i], Freq_ListChrono);
                        for(j=i; j<reading; j++)
                            chronoTabTmp[j] = chronoTabTmp[j+1];
                        chronoTabTmp[j] = NULLDYNST;
                        i--;
                        break;

                    case MissingDataMethod_Average:
                        if (nbValues!=0)
                            SET_NUMBER(chronoTabTmp[i], Freq_ListChrono_Val, sumValues/nbValues);
                        break;

                    case MissingDataMethod_Encadrante:
                        if (i == 0)
                        {
                            reading--;
                            FREE_DYNST(chronoTabTmp[i], Freq_ListChrono);
                            for(j=i; j<reading; j++)
                                chronoTabTmp[j] = chronoTabTmp[j+1];
                            chronoTabTmp[j] = NULLDYNST;
                            i--;
                        }
                        else
                        {
                            prevValue = GET_NUMBER(chronoTabTmp[i-1], Freq_ListChrono_Val);

                            for (j=i;
                                 j<reading && IS_NULLFLD(chronoTabTmp[j], Freq_ListChrono_Val) == TRUE;
                                 j++) ; /* I want it */

                            if (j<reading)
                            {
                                nextValue = GET_NUMBER(chronoTabTmp[j], Freq_ListChrono_Val);
                                for (k=i; k<j; k++)
                                    SET_NUMBER(chronoTabTmp[k], Freq_ListChrono_Val, (prevValue+nextValue)/2);
                            }
                            else
                            {
                                for(j=i; j<reading; j++)
                                    FREE_DYNST(chronoTabTmp[j], Freq_ListChrono);
                                reading=i;
                            }
                        }
                        break;
                }
            }
        }
        /* REF7061 - TEB - 030123 (End) */


	    if ((chronoArrayPtr = (DBA_ARRAY_DATA_STP)CALLOC(1, sizeof(DBA_ARRAY_DATA_ST))) == (DBA_ARRAY_DATA_STP)NULL)
	    {
	        DBA_FreeDynStTab(chronoTab,    chronoNbr, Freq_ListChrono);
            DBA_FreeDynStTab(chronoTabTmp, reading,   Freq_ListChrono);
		    MSG_RETURN(RET_MEM_ERR_ALLOC);
	    }

        if ((chronoArrayPtr->dataTab = ALLOC_DYNST_WITHOUTDEF(reading)) == (PTR)NULL) /* REF8844 - LJE - 030401 */
	    {
	        DBA_FreeDynStTab(chronoTab,    chronoNbr, Freq_ListChrono);
            DBA_FreeDynStTab(chronoTabTmp, reading,   Freq_ListChrono);
		    MSG_RETURN(RET_MEM_ERR_ALLOC);
	    }

	    if ((chronoArrayPtr->notNullFlgTab = (char *)CALLOC(reading, sizeof(char))) == (PTR)NULL)
	    {
	        DBA_FreeDynStTab(chronoTab,    chronoNbr, Freq_ListChrono);
            DBA_FreeDynStTab(chronoTabTmp, reading,   Freq_ListChrono);
		    MSG_RETURN(RET_MEM_ERR_ALLOC);
	    }

        /* REF7061 - TEB - 030123 */
	    for (i=0; i<reading; i++)
	    {
	   	    SET_NUMBER(chronoArrayPtr->dataTab,
                       i,
                       GET_NUMBER(chronoTabTmp[i],
                       Freq_ListChrono_Val));
		    chronoArrayPtr->notNullFlgTab[i] = TRUE;

	    }
    }
    else
    {
        reading = 0;  /* REF7061 - TEB - 030603 */
    }

	DBA_FreeDynStTab(chronoTabTmp, reading,   Freq_ListChrono); /* REF7061 - TEB - 030123 */
    DBA_FreeDynStTab(chronoTab,    chronoNbr, Freq_ListChrono);
	SET_MULTIARRAY(array, 0, chronoArrayPtr, (ushort) reading, 1);

	return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_Regr()
**
**  Description :   Receives two arrays of numerical data each with the
**                  same number of occurrences.
**                  Computes :
**                  - number of records
**                  - alpha
**                  - beta
**                  - covariance
**                  - correlation coefficient
**                  - determination coefficient R2
**                  - chi squared                      (TO DO)
**                  - standard deviation of alpha      (TO DO)
**                  - standard deviation of beta       (TO DO)
**                  - goodness of fit probability Q    (TO DO)
**
**  Arguments   :   array1          first array
**                  array2          second array
**                  regrPtr         pointer on output structure
**
**  Return      :   RET_SUCCEED or error code, regrPtr is filled
**
** DVP005 : Added new function REGR (96/03/12)
**
*************************************************************************/
RET_CODE FIN_Regr(DBA_DYNFLD_STP array1,
		  DBA_DYNFLD_STP array2,
		  DBA_DYNFLD_STP regrPtr)
{
	double             *array1Arg, *array2Arg;
	int                i, data1Nbr, data2Nbr, argNbr, dataNbr;
	DBA_ARRAY_DATA_STP array1Data, array2Data;
	RET_CODE           ret;

	if (array1 == NULLDYNST)
	{
	    MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
		         "FIN_Regr", "array 1 pointer");
	    return(RET_GEN_ERR_INVARG);
	}

	if (array2 == NULLDYNST)
	{
	    MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
		         "FIN_Regr", "array 2 pointer");
	    return(RET_GEN_ERR_INVARG);
	}

	if (regrPtr == NULLDYNST)
	{
	    MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
		         "FIN_Regr", "regression pointer");
	    return(RET_GEN_ERR_INVARG);
	}

	array1Data = GET_MULTIARRAY_PTR(array1, 0);
	data1Nbr   = GET_MULTIARRAY_DIM1(array1, 0);

	array2Data = GET_MULTIARRAY_PTR(array2, 0);
	data2Nbr   = GET_MULTIARRAY_DIM1(array2, 0);

	dataNbr = (data1Nbr > data2Nbr) ? data2Nbr : data1Nbr;

	if (dataNbr == 0)
	{
		ret = RET_FIN_ERR_INVDATA;
		/* MSG_SendMesg(ret, 2, FILEINFO, "FIN_Regr", "array size"); */
		return(ret);
	}

	if ((array1Arg = (double *)CALLOC(dataNbr, sizeof(double))) == (double*)NULL) /* REF7264 - LJE - 020128 */
	{
		MSG_RETURN(RET_MEM_ERR_ALLOC);
	}

	if ((array2Arg = (double *)CALLOC(dataNbr, sizeof(double))) == (double*)NULL) /* REF7264 - LJE - 020128 */
	{
		FREE(array1Arg);
		MSG_RETURN(RET_MEM_ERR_ALLOC);
	}

	for (i=0, argNbr=0; i<dataNbr; i++)
	{
		/* Exclude lines where the value is */
		/* NULL and verify pairs of data    */
		if (array1Data->notNullFlgTab[i] == TRUE &&
		    array2Data->notNullFlgTab[i] == TRUE)
		{
			array1Arg[argNbr] = GET_NUMBER(array1Data->dataTab,i); /* REF7296 - LJE - 020501 */
			array2Arg[argNbr] = GET_NUMBER(array2Data->dataTab,i); /* REF7296 - LJE - 020501 */
			++argNbr;
		}
	}

	if (argNbr >= 3)
	{
		ret = FIN_CalcRegr(array1Arg, array2Arg, argNbr, regrPtr);
	}
	else
	{
		ret = RET_FIN_ERR_INVDATA;
		/* MSG_SendMesg(ret, 2, FILEINFO, "FIN_Regr", "array size"); */
	}

	FREE(array1Arg);
	FREE(array2Arg);
	return(ret);
}

/************************************************************************
*   Function             : FIN_SearchInstrInGrid()
*
*   Description          : Determine if an instrument belongs to a grid, and
*                          then return the referenced market_segment, or not.
*
*   WARNING              : This function can be called by FIN_SearchInstrInMktSegt(), which
*                          can be itself called by FIN_SearchInstrInGrid(). To avoid infinite
*                          process, a test is made on the given gridId and the last grid id
*                          handled. If they are the same, stop the processus and return NULL
*
*   Arguments            : gridId     : a grid id
*                          instrId    : an instrument id
*                          aInstrSt   : pointer on a A_Instr dyn. structure
*                          lastGridId : last grid handled
*						   classifStack
*                          refDateTimePtr
*                          buildListFlg
*                          depthLevel   :
*                          *aMktSegtStp : pointer to "all" market segment struct (can be NULL)
*                          selOptions
*                          connectNo
*                          msgStructPtr
*
*   Return               : RET_SUCCEED             : if ok
*
*   Creation Date        : 13.11.95 - PEC
*   Last Modif           : 15.11.95 - PEC - Added argument lastGridId
*                          16.04.96 - PEC - Ref.: DVP023+
*                          REF7420 - LJE - 020527
*************************************************************************/
ID_T FIN_SearchInstrInGrid(PTR                      argHierHead,   /* REF3678 - RAK - 990817 - Add hierHead ptr */
                           ID_T                     gridId,
                           ID_T                     instrId,
                           DBA_DYNFLD_STP           aInstrSt,
                           ID_T                     lastGridId,
                           FLAG_T                   verifFlg,
                           SCPT_CLASSIFSTACK_STP    classifStack,
                           DATETIME_STP             refDateTimePtr,
                           FLAG_T                   buildListFlg,
						   int                      depthLevel,    /* REF7420 - LJE - 020523 */
						   FLAG_T                   allowOtherSgtFlg, /* PMSTA08737 - LJE - 091223 */
						   DBA_DYNFLD_STP          *aMktSegtStp,    /* REF7420 - LJE - 020523 */
                           int                      selOptions,
                           int*                     connectNo,
						   FLAG_T*					OverrideApplForInstr,
						   DBA_DYNFLD_STP	        InstrMktSegOverride,
						   FLAG_T			        whereingridFlg)
{
    DBA_DYNFLD_STP  aClassifCompoSt      = NULLDYNST;
    DBA_DYNFLD_STP  sMktSegtSt           = NULLDYNST;
    DBA_DYNFLD_STP  aGridSt              = NULLDYNST;
    DICT_T          instrDictId          = 0;
    ID_T            abcissaListId        = 0;
    ID_T            ordinateListId       = 0;
    ID_T            mktSegtId            = 0;
    int             retCode;
	FLAG_T          aGridStAllocFlg      = FALSE;
	DBA_HIER_HEAD_STP hierHead=(DBA_HIER_HEAD_STP)argHierHead; /* REF7264 - LJE - 020128 */
	INFO_T          denomComputed;
	NAME_T          *nameAbcissaTab=NULL, *nameOrdinateTab=NULL;
	int             denomNb=0;

    /* REF7420 - LJE - 020527 : BEGIN */
	FLAG_T         exitFlg;
	DBA_DYNFLD_STP sMktStructSt=NULLDYNST, aMktStructSt=NULLDYNST, *aMktStructTab=NULLDYNSTPTR;
	DBA_DYNFLD_STP sMktSSubSetSt=NULLDYNST, *aMktSSubSetTab=NULLDYNSTPTR;
	DBA_DYNFLD_STP aListSt=NULLDYNST;
	int            mktStructNb=0,mktSSubSetNb=0;
	int            cptLoop=0;
	ID_T           currGridId=gridId;
	int            i, j, headSSubSet;
    FLAG_T         mktSSubSetInHier=FALSE, mktStructInHier=FALSE, aMktStructStAllocFlg=TRUE;
    /* REF7420 - LJE - 020527 : END */
	FLAG_T         excludeInstrFlg=FALSE; /* PMSTA08737 - LJE - 091223 */
    MemoryPool     mp;

    /* compare the given grid with the last grid handled (used in a recursive process) */
    if (gridId == lastGridId)
            return(FALSE);

    lastGridId = gridId;

	/* REF7420 - RAK - 021031 - New fct which verify in hier, get and add in hier */
	/* REF7420 - LJE - 020523 */
	/* if (FIN_GetGridById(hierHead,
						gridId,
						&aGridSt,
						&aGridStAllocFlg,
						selOptions,
						connectNo,
						msgStructPtr)!=RET_SUCCEED)
	{
        lastGridId = 0;
        return(FALSE);
	}
	*/
	if (DBA_GetGridById(gridId, TRUE,
						&aGridStAllocFlg,
						&aGridSt,
						hierHead,
						selOptions,
						connectNo) != RET_SUCCEED)
	{
		lastGridId = 0;
		return(FALSE);
	}

    /* If the grid depends itself on a market_segment */  /**** DVP023+ ****/
    if (IS_NULLFLD(aGridSt, A_Grid_ParMktSegtId) == FALSE && verifFlg == TRUE)
    {
        retCode = FIN_SearchInstrInMktSegt(hierHead,
                                           GET_ID(aGridSt, A_Grid_ParMktSegtId),
                                           instrId,
                                           aInstrSt,
                                           lastGridId,
                                           verifFlg,
                                           classifStack,
                                           selOptions,
                                           connectNo,
                                           depthLevel,
                                           nullptr); /* REF8834 - CHU - 031119 */

        if (retCode == FALSE)
        {
		    if (aGridStAllocFlg == TRUE) { FREE_DYNST(aGridSt, A_Grid); }
            lastGridId = 0;
            return(FALSE);
        }
    }

    DBA_GetDictId(Instr, &instrDictId);

	if ((aClassifCompoSt = mp.allocDynst(FILEINFO,A_ClassifCompo)) == NULLDYNST)
	{
		MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
		if (aGridStAllocFlg == TRUE) { FREE_DYNST(aGridSt, A_Grid); }
		lastGridId = 0;
		return(FALSE);
	}

	if (IS_NULLFLD(aGridSt, A_Grid_NatEn) == TRUE ||
		GET_ENUM(aGridSt, A_Grid_NatEn) == GridNat_Std )
	{
		if (allowOtherSgtFlg == FALSE &&
			(aListSt = ALLOC_DYNST(A_List)) == NULLDYNST)
		{
			MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
			if (aGridStAllocFlg == TRUE) { FREE_DYNST(aGridSt, A_Grid); }
			lastGridId = 0;
			return(FALSE);
		}

		/* Get Abcissa CLASSIFICATION record */
		if (IS_NULLFLD(aGridSt, A_Grid_AbcissaClassifId) == FALSE)
		{
			/* Classify the instrument in a classification and return the composant of the
			   classification which is concerned */
			FIN_Classify(instrDictId,
						 instrId,
						 GET_ID(aGridSt, A_Grid_AbcissaClassifId),
						 aInstrSt,
						 aClassifCompoSt,
						 classifStack,
						 (DBA_HIER_HEAD_STP) NULL,
						 refDateTimePtr,
						 NULLDYNST,
						 buildListFlg,
						 TRUE,
						 selOptions,
						 connectNo,
						 OverrideApplForInstr,
						 NULLDYNST,
						 whereingridFlg);

			abcissaListId = GET_ID(aClassifCompoSt, A_ClassifCompo_ListId);

			/* PMSTA08737 - LJE - 091223 */
			if (allowOtherSgtFlg == FALSE &&
				abcissaListId > 0)
			{
				SET_ID(aListSt, A_List_Id, abcissaListId);

				if (DBA_Get2(List,
							 UNUSED,
							 A_List,
							 aListSt,
							 A_List,
							 &aListSt,
							 selOptions,
							 connectNo) == RET_SUCCEED &&
					GET_ENUM(aListSt, A_List_NatEn) == ListNat_Other)
				{
					excludeInstrFlg = TRUE;
				}
			}
		}

		/* Get Ordinate CLASSIFICATION record */
		if (excludeInstrFlg == FALSE &&
			IS_NULLFLD(aGridSt, A_Grid_OrdinateClassifId) == FALSE)
		{
			/* Classify the instrument in a classification and return the composant of the
			   classification which is concerned */
			FIN_Classify(instrDictId,
						 instrId,
						 GET_ID(aGridSt, A_Grid_OrdinateClassifId),
						 aInstrSt,
						 aClassifCompoSt,
						 classifStack,
						 (DBA_HIER_HEAD_STP) NULL,
						 refDateTimePtr, /* BAD_DATE, REF7411 - LJE - 020318 */
						 NULLDYNST,
						 buildListFlg,
						 TRUE,
						 selOptions,
						 connectNo);

			ordinateListId = GET_ID(aClassifCompoSt, A_ClassifCompo_ListId);

			/* PMSTA08737 - LJE - 091223 */
			if (allowOtherSgtFlg == FALSE &&
				ordinateListId > 0)
			{
				SET_ID(aListSt, A_List_Id, ordinateListId);

				if (DBA_Get2(List,
							 UNUSED,
							 A_List,
							 aListSt,
							 A_List,
							 &aListSt,
							 selOptions,
							 connectNo) == RET_SUCCEED &&
					GET_ENUM(aListSt, A_List_NatEn) == ListNat_Other)
				{
					excludeInstrFlg = TRUE;
				}
			}

		}

		/* REF7420 - LJE - 020523 */
		if (excludeInstrFlg == FALSE &&
			FIN_GetMktSegtByLid(hierHead,
								gridId,
								0,
								abcissaListId,
								ordinateListId,
								&sMktSegtSt,
								selOptions,
								connectNo) != RET_SUCCEED)
		{
            /* REF<TASC> - LJE - 040123 */
            if (aInstrSt != NULL && aGridSt != NULL)
            {
			    MSG_SendMesg(RET_FIN_ERR_INSTR_CLASSIFY, 1, FILEINFO,
                             GET_CODE(aInstrSt, A_Instr_Cd),
                             GET_CODE(aGridSt, A_Grid_Cd));
            }
            else
            {
			    MSG_SendMesg(RET_FIN_ERR_INSTR_CLASSIFY, 0, FILEINFO);
            }

			if (aGridStAllocFlg == TRUE) { FREE_DYNST(aGridSt, A_Grid); }
			lastGridId = 0;
			return(FALSE);
		}

		if (allowOtherSgtFlg == FALSE)
		{
			FREE_DYNST(aListSt, A_List);
		}
	}
    /* REF7420 - LJE - 020523 : P.A.A. */
	else
	{
		if ((sMktStructSt = ALLOC_DYNST(S_MktStruct)) == NULLDYNST ||
		    (aListSt      = ALLOC_DYNST(A_List))      == NULLDYNST )
	    {
			FREE_DYNST(sMktStructSt, S_MktStruct);
			FREE_DYNST(sMktSegtSt  , S_MktSegt);
			FREE_DYNST(aListSt  , A_List);
			if (aGridStAllocFlg == TRUE) { FREE_DYNST(aGridSt, A_Grid); }
            MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
			lastGridId = 0;
            return(FALSE);
	    }

		if (GET_ENUM(aGridSt, A_Grid_NatEn) == GridNat_MktSSubSet)
		{
			if ((sMktSSubSetSt = ALLOC_DYNST(S_MktSSubSet)) == NULLDYNST)
			{
				FREE_DYNST(sMktStructSt, S_MktStruct);
				FREE_DYNST(sMktSegtSt  , S_MktSegt);
				FREE_DYNST(aListSt  , A_List);
				if (aGridStAllocFlg == TRUE) { FREE_DYNST(aGridSt, A_Grid); }
				MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
				lastGridId = 0;
				return(FALSE);
			}

			/* Prepare the select of the market struct subset */
			SET_ID(sMktSSubSetSt, S_MktSSubSet_RefGridId, currGridId);

            /* Search all market structure subset in hierarchy */
	        mktSSubSetInHier = FALSE;
	        if (hierHead != NULL /* && DBA_GetHierEltPosByDynSt(hierHead, A_MktSSubSet, &mktSSubSetHierEltPos)  == RET_SUCCEED  *PMSTA-13295 - JPP - 20120411*/)
	        {
		        if (DBA_ExtractHierEltRecWithFilterSt(hierHead,
		                                          A_MktSSubSet,  /* PMSTA-13295 - JPP - 20120207 */
			                                          FALSE,
		                                              FIN_FilterSMktSSubSetByLid,
						                              sMktSSubSetSt,
		                                              NULLFCT,
						                              &mktSSubSetNb,
		                                              &aMktSSubSetTab) == RET_SUCCEED &&
		            mktSSubSetNb > 0 )
		        {
		            mktSSubSetInHier = TRUE;
		        }
	        }

	        if (mktSSubSetInHier == FALSE)
	        {

			    /* Select all market structure subset in DB */
			    if (DBA_Select2(MktSSubSet,
							    UNUSED,
							    S_MktSSubSet,
							    sMktSSubSetSt,
							    A_MktSSubSet,
							    &aMktSSubSetTab,
							    selOptions,
							    UNUSED,
							    &mktSSubSetNb,
							    connectNo) != RET_SUCCEED ||
				    mktSSubSetNb == 0 )
			    {
                    /* REF<TASC> - LJE - 040123 */
                    if (aInstrSt != NULL && aGridSt != NULL)
                    {
			            MSG_SendMesg(RET_FIN_ERR_INSTR_CLASSIFY, 1, FILEINFO,
                                     GET_CODE(aInstrSt, A_Instr_Cd),
                                     GET_CODE(aGridSt, A_Grid_Cd));
                    }
                    else
                    {
			            MSG_SendMesg(RET_FIN_ERR_INSTR_CLASSIFY, 0, FILEINFO);
                    }

				    FREE_DYNST(sMktSSubSetSt,S_MktSSubSet);
				    FREE_DYNST(sMktStructSt, S_MktStruct);
				    FREE_DYNST(sMktSegtSt  , S_MktSegt);
				    FREE_DYNST(aListSt     , A_List);
				    if (aGridStAllocFlg == TRUE) { FREE_DYNST(aGridSt, A_Grid); }
				    lastGridId = 0;
				    return(FALSE);
			    }
           	}

			FREE_DYNST(sMktSSubSetSt,  S_MktSSubSet);

			/* Search the head of market structure */
			/* Search the first market structure subset which reference a market structure where
			 * the parent market structure does not exist in market structure subset
			 */
			headSSubSet = -1;
			i=0;
			while (i < mktSSubSetNb && headSSubSet < 0)
			{
				if (IS_NULLFLD(aMktSSubSetTab[i], A_MktSSubSet_MktStructId) == TRUE)
				{
					/* REF11231 - CHU - 050706 - avoid error on D.B.A._.G.e.t.2() call - dots are for C.A.S.T ;o) */
					i++;
					continue;
				}

                aMktStructStAllocFlg = FALSE;

               	/* Search market segment, then market segment grid in hierarchy */ /* REF7420 - LJE - 020904 */
	            if (hierHead != NULL)
	            {
	                if (DBA_GetRecPtrFromHierById(hierHead,
                                                  GET_ID(aMktSSubSetTab[i], A_MktSSubSet_MktStructId),
			                                      A_MktStruct,
                                                  &aMktStructSt) != RET_SUCCEED)
                    {
                        aMktStructSt = NULLDYNST;

                    }
	            }

                if (aMktStructSt == NULLDYNST)
                {
                    aMktStructStAllocFlg = TRUE;

           			if ((aMktStructSt  = ALLOC_DYNST(A_MktStruct)) == NULLDYNST )
			        {
				        FREE_DYNST(sMktStructSt, S_MktStruct);
				        FREE_DYNST(sMktSegtSt  , S_MktSegt);
				        FREE_DYNST(aListSt  , A_List);
						/* REF10304 - RAK - 041216 */
						if (mktSSubSetNb > 0 && mktSSubSetInHier == FALSE)
						{ DBA_FreeDynStTab(aMktSSubSetTab, mktSSubSetNb, A_MktSSubSet); }
						else if (aMktSSubSetTab != NULL) { FREE(aMktSSubSetTab); }
                        /* FREE_DYNST(sMktSSubSetSt,  S_MktSSubSet); alread done */
				        if (aGridStAllocFlg == TRUE) { FREE_DYNST(aGridSt, A_Grid); }
				        MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
				        lastGridId = 0;
				        return(FALSE);
			        }

				    /* Get the new gridId */
				    COPY_DYNFLD(sMktStructSt, S_MktStruct, S_MktStruct_Id,
							    aMktSSubSetTab[i], A_MktSSubSet, A_MktSSubSet_MktStructId);

				    if (DBA_Get2(MktStruct,
							     UNUSED,
							     S_MktStruct,
							     sMktStructSt,
							     A_MktStruct,
							     &aMktStructSt,
							     selOptions,
							     connectNo) != RET_SUCCEED)
				    {
                        /* REF<TASC> - LJE - 040123 */
                        if (aInstrSt != NULL && aGridSt != NULL)
                        {
			                MSG_SendMesg(RET_FIN_ERR_INSTR_CLASSIFY, 1, FILEINFO,
                                         GET_CODE(aInstrSt, A_Instr_Cd),
                                         GET_CODE(aGridSt, A_Grid_Cd));
                        }
                        else
                        {
			                MSG_SendMesg(RET_FIN_ERR_INSTR_CLASSIFY, 0, FILEINFO);
                        }

					    FREE_DYNST(sMktStructSt, S_MktStruct);
					    FREE_DYNST(sMktSegtSt  , S_MktSegt);
					    FREE_DYNST(aMktStructSt, A_MktStruct);
					    FREE_DYNST(aListSt  , A_List);
					    if (aGridStAllocFlg == TRUE) { FREE_DYNST(aGridSt, A_Grid); }
					    lastGridId = 0;
						/* REF10304 - RAK - 041216 */
						if (mktSSubSetNb > 0 && mktSSubSetInHier == FALSE)
						{ DBA_FreeDynStTab(aMktSSubSetTab, mktSSubSetNb, A_MktSSubSet); }
						else if (aMktSSubSetTab != NULL) { FREE(aMktSSubSetTab); }
					    return(FALSE);
				    }
                }

				j=0;
				while (j<mktSSubSetNb &&
					   CMP_DYNFLD(aMktStructSt, aMktSSubSetTab[j], A_MktStruct_ParMktStructId,
					              A_MktSSubSet_MktStructId, IdType) != 0)
				{
					j++;
				}

				if (j==mktSSubSetNb)
				{
					headSSubSet = i;
				}

				i++; /* REF7420 - LJE - 020702 */
			}

			if (headSSubSet == -1)
			{
                /* REF<TASC> - LJE - 040123 */
                if (aInstrSt != NULL && aGridSt != NULL)
                {
			        MSG_SendMesg(RET_FIN_ERR_INSTR_CLASSIFY, 1, FILEINFO,
                                 GET_CODE(aInstrSt, A_Instr_Cd),
                                 GET_CODE(aGridSt, A_Grid_Cd));
                }
                else
                {
			        MSG_SendMesg(RET_FIN_ERR_INSTR_CLASSIFY, 0, FILEINFO);
                }

				FREE_DYNST(sMktStructSt, S_MktStruct);
				FREE_DYNST(sMktSegtSt  , S_MktSegt);
				FREE_DYNST(aListSt  , A_List);
				if (aGridStAllocFlg == TRUE) { FREE_DYNST(aGridSt, A_Grid); }
				lastGridId = 0;
				/* REF10304 - RAK - 041216 */
				if (mktSSubSetNb > 0 && mktSSubSetInHier == FALSE)
				{ DBA_FreeDynStTab(aMktSSubSetTab, mktSSubSetNb, A_MktSSubSet); }
				else if (aMktSSubSetTab != NULL) { FREE(aMktSSubSetTab); }
				return(FALSE);
			}

			currGridId = GET_ID(aMktStructSt, A_MktStruct_RefGridId);
		}

		/* Prepare the select of the market struct */
		SET_ID(     sMktStructSt, S_MktStruct_RefGridId, currGridId);
		SET_NULL_ID(sMktStructSt, S_MktStruct_Id);

        /* Search all market structure in hierarchy */
	    mktStructInHier = FALSE;
	    if (hierHead != NULL /* && DBA_GetHierEltPosByDynSt(hierHead, A_MktStruct, &mktStructHierEltPos) == RET_SUCCEED*PMSTA-13295 - JPP - 20120411*/)
	    {
			/* REF7420 - RAK - 020918 */
			/* Extract with a copy because of elimination done below
			   (SET_NULL_ID(aMktStructTab[i], A_MktStruct_GridId);)
			*/
	        if (DBA_ExtractHierEltRecWithFilterSt(hierHead,
	                                              A_MktStruct,
			                                      TRUE,
	                                              FIN_FilterSMktStructByLid,
						                          sMktStructSt,
	                                              NULLFCT,
						                          &mktStructNb,
	                                              &aMktStructTab) == RET_SUCCEED &&
	            mktStructNb > 0)

	        {
	            mktStructInHier = TRUE;
	        }
	    }
	    if (mktStructInHier == FALSE)
	    {
		    /* Select all market structure in DB */
	        if (DBA_Select2(MktStruct,
						    UNUSED,
						    S_MktStruct,
						    sMktStructSt,
						    A_MktStruct,
						    &aMktStructTab,
						    selOptions,
						    UNUSED,
						    &mktStructNb,
						    connectNo) != RET_SUCCEED ||
			    mktStructNb == 0)
	        {
                /* REF<TASC> - LJE - 040123 */
                if (aInstrSt != NULL && aGridSt != NULL)
                {
			        MSG_SendMesg(RET_FIN_ERR_INSTR_CLASSIFY, 1, FILEINFO,
                                 GET_CODE(aInstrSt, A_Instr_Cd),
                                 GET_CODE(aGridSt, A_Grid_Cd));
                }
                else
                {
			        MSG_SendMesg(RET_FIN_ERR_INSTR_CLASSIFY, 0, FILEINFO);
                }

			    FREE_DYNST(sMktStructSt, S_MktStruct);
			    FREE_DYNST(sMktSegtSt  , S_MktSegt);
			    FREE_DYNST(aMktStructSt, A_MktStruct);
			    FREE_DYNST(aListSt  , A_List);
			    if (aGridStAllocFlg == TRUE) { FREE_DYNST(aGridSt, A_Grid); }
			    lastGridId = 0;
				/* REF10304 - RAK - 041216 */
				if (mktSSubSetNb > 0 && mktSSubSetInHier == FALSE)
				{ DBA_FreeDynStTab(aMktSSubSetTab, mktSSubSetNb, A_MktSSubSet); }
				else if (aMktSSubSetTab != NULL) { FREE(aMktSSubSetTab); }
                return(FALSE);
	        }

        }

		exitFlg = FALSE;

		if (GET_ENUM(aGridSt, A_Grid_NatEn) == GridNat_MktSSubSet )
		{
			SET_ID(sMktStructSt, S_MktStruct_ParMktSegtId, GET_ID(aMktStructSt, A_MktStruct_ParMktSegtId));

			if (mktStructNb > 1)
			{
				/* Elimintate market structure not in market structure subset */
				for (i=0; i<mktStructNb; i++)
				{
					/* search in market structure subset */
					j=0;
					while (j<mktSSubSetNb &&
						   CMP_DYNFLD(aMktStructTab[i], aMktSSubSetTab[j],
									  A_MktStruct_Id, A_MktSSubSet_MktStructId, IdType) != 0)
					{
						j++;
					}

					if (j==mktSSubSetNb)
					{
					    /* Elimination */
						SET_NULL_ID(aMktStructTab[i], A_MktStruct_GridId);
					}

				}
			}

			if (aMktStructStAllocFlg==TRUE ) FREE_DYNST(aMktStructSt, A_MktStruct);
			/* REF10304 - RAK - 041216 */
			if (mktSSubSetNb > 0 && mktSSubSetInHier == FALSE)
			{ DBA_FreeDynStTab(aMktSSubSetTab, mktSSubSetNb, A_MktSSubSet); }
			else if (aMktSSubSetTab != NULL) { FREE(aMktSSubSetTab); }
		}
		else
		{
			/* REF9314 - CHU - 040826 : Search matching MktSegt directly in Parent MktSegt of MS */
			if ((IS_NULLFLD(sMktStructSt, S_MktStruct_ParMktSegtId) == TRUE) &&
				(GET_ENUM(aGridSt, A_Grid_NatEn) == GridNat_MktStruct))
			{
				for (j=0; j < mktStructNb; j++)
				{
					if ((CMP_ID(GET_ID(aGridSt, A_Grid_Id), GET_ID(aMktStructTab[j], A_MktStruct_RefGridId))==0) &&
						(GET_TINYINT(aMktStructTab[j], A_MktStruct_Level)==1) &&
						(IS_NULLFLD(aMktStructTab[j], A_MktStruct_ParMktSegtId)==FALSE))
					{
						mktSegtId = GET_ID(aMktStructTab[j], A_MktStruct_ParMktSegtId);
						if (aGridStAllocFlg == TRUE) { FREE_DYNST(aGridSt, A_Grid); }
						lastGridId = 0;
						return(mktSegtId);
					}
				}
			}
		}

		while (exitFlg == FALSE && (depthLevel <= 0 || cptLoop < depthLevel))
		{
			if (aGridStAllocFlg == TRUE) { FREE_DYNST(aGridSt, A_Grid); }
			aGridStAllocFlg = FALSE;
			aGridSt = NULLDYNST;

			cptLoop++;

			if (FIN_GetMktStructInTab(sMktStructSt,
				                      aMktStructTab,
									  mktStructNb,
									  &aMktStructSt) == RET_SUCCEED &&
				/* Get the new GRID record */
				DBA_GetGridById(GET_ID(aMktStructSt, A_MktStruct_GridId), TRUE,
										&aGridStAllocFlg,
										&aGridSt,
										hierHead,
										selOptions,
										connectNo) == RET_SUCCEED)
			{

				if (denomNb % 10 == 0)
				{
					nameAbcissaTab  = (NAME_T *)REALLOC(nameAbcissaTab, (denomNb+10)*(sizeof(NAME_T)));
					nameOrdinateTab = (NAME_T *)REALLOC(nameOrdinateTab, (denomNb+10)*(sizeof(NAME_T)));
				}


				/* Get Abcissa CLASSIFICATION record */
				if (IS_NULLFLD(aGridSt, A_Grid_AbcissaClassifId) == FALSE)
				{
					/* Classify the instrument in a classification and return the composant of the
					   classification which is concerned */
					FIN_Classify(instrDictId,
								 instrId,
								 GET_ID(aGridSt, A_Grid_AbcissaClassifId),
								 aInstrSt,
								 aClassifCompoSt,
								 classifStack,
								 hierHead, /* PMSTA-10748 - LJE - 110211 */
								 refDateTimePtr,
								 NULLDYNST,
								 buildListFlg,
								 TRUE,
								 selOptions,
								 connectNo,
								 OverrideApplForInstr,
								 NULLDYNST,
								 whereingridFlg);

					abcissaListId = GET_ID(aClassifCompoSt, A_ClassifCompo_ListId);

					SET_ID(aListSt, A_List_Id, abcissaListId);
					ENUM_T          applMarketstructEnum;
					GEN_GetApplInfo(ApplMarketStructureattribEnum, &applMarketstructEnum);
					if (applMarketstructEnum == 1 && whereingridFlg == TRUE)
					{
						MemoryPool MktSegMpool;
						DBA_DYNFLD_STP           MktSegOverride = NULLDYNST;
						if ((MktSegOverride = MktSegMpool.allocDynst(FILEINFO, S_InstrMktsegOverride)) == NULLDYNST)
						{
							return(RET_SUCCEED);
						}
						DBA_DYNFLD_STP           MktSegOverride_out = NULLDYNST;
						if ((MktSegOverride_out = MktSegMpool.allocDynst(FILEINFO, S_InstrMktsegOverride)) == NULLDYNST)
						{
							return(RET_SUCCEED);
						}
						SET_ID(MktSegOverride, S_InstrMktsegOverride_InstrId, (instrId));

						if (static_cast<InstrMktsegOverrideOverrideScopeEn>GET_ENUM(InstrMktSegOverride, S_InstrMktsegOverride_OverrideScopeEn) != InstrMktsegOverrideOverrideScopeEn::None)
						{
							SET_ENUM(MktSegOverride, S_InstrMktsegOverride_OverrideScopeEn, GET_ENUM(InstrMktSegOverride, S_InstrMktsegOverride_OverrideScopeEn));
						}
						if (GET_ID(InstrMktSegOverride, S_InstrMktsegOverride_PtfId) != NULL)
						{
							SET_ID(MktSegOverride, S_InstrMktsegOverride_PtfId, GET_ID(InstrMktSegOverride, S_InstrMktsegOverride_PtfId));
						}
						if (GET_ID(InstrMktSegOverride, S_InstrMktsegOverride_ManagerId) != NULL)
						{
							SET_ID(MktSegOverride, S_InstrMktsegOverride_ManagerId, GET_ID(InstrMktSegOverride, S_InstrMktsegOverride_ManagerId));
						}
						if (GET_ID(InstrMktSegOverride, S_InstrMktsegOverride_BusEntityId) != NULL)
						{
							SET_ID(MktSegOverride, S_InstrMktsegOverride_PtfId, GET_ID(InstrMktSegOverride, S_InstrMktsegOverride_BusEntityId));
						}
						DBA_DYNFLD_STP  * MktSegOverrideout = nullptr;
						if (applMarketstructEnum == 1)
						{
							int iNboverride = 0;
							DBA_Select2(InstrMktsegOverride,
								UNUSED,
								S_InstrMktsegOverride,
								MktSegOverride,
								S_InstrMktsegOverride,
								&MktSegOverrideout,
								UNUSED,
								UNUSED,
								&iNboverride,
								NULL,
								NULL);

						}
						DBA_DYNFLD_STP			getMktSgt = NULL;
						DBA_DYNFLD_STP			MktSgtPtr = NULL;
						DBA_DYNFLD_STP			StdMktSgtPtr = NULL;
						if ((getMktSgt = MktSegMpool.allocDynst(FILEINFO, S_MktSegt)) == NULLDYNST)
						{
							MSG_RETURN(RET_MEM_ERR_ALLOC);
						}
						if (MktSegOverrideout != nullptr)
						{
							SET_ID(getMktSgt, S_MktSegt_Id, GET_ID(MktSegOverrideout[0], S_InstrMktsegOverride_StdMktSegId));
							if ((StdMktSgtPtr = MktSegMpool.allocDynst(FILEINFO, A_MktSegt)) == NULLDYNST)
							{
								FREE_DYNST(getMktSgt, S_MktSegt);
								MSG_RETURN(RET_MEM_ERR_ALLOC);
							}
							if ((MktSgtPtr = MktSegMpool.allocDynst(FILEINFO, A_MktSegt)) == NULLDYNST)
							{
								FREE_DYNST(getMktSgt, S_MktSegt);
								MSG_RETURN(RET_MEM_ERR_ALLOC);
							}
							if (DBA_Get2(MktSegt, UNUSED, S_MktSegt, getMktSgt, A_MktSegt, &StdMktSgtPtr,
								UNUSED, UNUSED, UNUSED) == RET_SUCCEED)
							{
								SET_ID(getMktSgt, S_MktSegt_Id, GET_ID(MktSegOverrideout[0], S_InstrMktsegOverride_OverrideMktSegId));
								if (DBA_Get2(MktSegt, UNUSED, S_MktSegt, getMktSgt, A_MktSegt, &MktSgtPtr,
									UNUSED, UNUSED, UNUSED) == RET_SUCCEED)
								{
									if (GET_ID(StdMktSgtPtr, S_MktSegt_AbcissaListId) == abcissaListId)
										abcissaListId = GET_ID(StdMktSgtPtr, S_MktSegt_AbcissaListId);
								}
							}

						}




					}

					/* Save the name */
					if (abcissaListId <= 0 || /* PMSTA08610 - DDV - 090903 - Get the list only if id is valid. */
                        DBA_Get2(List,
						         UNUSED,
								 A_List,
								 aListSt,
								 A_List,
								 &aListSt,
								 selOptions,
								 connectNo) != RET_SUCCEED)
					{
                        /* REF<TASC> - LJE - 040123 */
                        if (aInstrSt != NULL && aGridSt != NULL)
                        {
			                MSG_SendMesg(RET_FIN_ERR_INSTR_CLASSIFY, 1, FILEINFO,
                                         GET_CODE(aInstrSt, A_Instr_Cd),
                                         GET_CODE(aGridSt, A_Grid_Cd));
                        }
                        else
                        {
			                MSG_SendMesg(RET_FIN_ERR_INSTR_CLASSIFY, 0, FILEINFO);
                        }

						FREE_DYNST(sMktStructSt, S_MktStruct);
						FREE_DYNST(sMktSegtSt  , S_MktSegt);
						FREE_DYNST(aListSt     , A_List);

						/* REF7420 - RAK - 020918 */
						DBA_FreeDynStTab(aMktStructTab, mktStructNb, A_MktStruct);
						if (aGridStAllocFlg == TRUE) { FREE_DYNST(aGridSt, A_Grid); }

						return(FALSE);
					}

					/* PMSTA08737 - LJE - 091223 */
					if (allowOtherSgtFlg == FALSE &&
						GET_ENUM(aListSt, A_List_NatEn) == ListNat_Other)
					{
						excludeInstrFlg = TRUE;
					}

					strcpy(nameAbcissaTab[denomNb], GET_STRING(aListSt, A_List_Name));
				}
				else
				{
					nameAbcissaTab[denomNb][0] = 0;
					abcissaListId = 0;
				}

				/* Get Ordinate CLASSIFICATION record */
				if (excludeInstrFlg == FALSE &&
					IS_NULLFLD(aGridSt, A_Grid_OrdinateClassifId) == FALSE)
				{
					/* Classify the instrument in a classification and return the composant of the
					   classification which is concerned */
					FIN_Classify(instrDictId,
								 instrId,
								 GET_ID(aGridSt, A_Grid_OrdinateClassifId),
								 aInstrSt,
								 aClassifCompoSt,
								 classifStack,
								 hierHead, /* PMSTA-10748 - LJE - 110211 */
								 refDateTimePtr,
								 NULLDYNST,
								 buildListFlg,
								 TRUE,
								 selOptions,
								 connectNo);

					ordinateListId = GET_ID(aClassifCompoSt, A_ClassifCompo_ListId);

					SET_ID(aListSt, A_List_Id, ordinateListId);

					/* Save the name */
					if (ordinateListId <= 0 || /* PMSTA08610 - DDV - 090903 - Get the list only if id is valid. */
                        DBA_Get2(List,
						         UNUSED,
								 A_List,
								 aListSt,
								 A_List,
								 &aListSt,
								 selOptions,
								 connectNo) != RET_SUCCEED)
					{
                        /* REF<TASC> - LJE - 040123 */
                        if (aInstrSt != NULL && aGridSt != NULL)
                        {
			                MSG_SendMesg(RET_FIN_ERR_INSTR_CLASSIFY, 1, FILEINFO,
                                         GET_CODE(aInstrSt, A_Instr_Cd),
                                         GET_CODE(aGridSt, A_Grid_Cd));
                        }
                        else
                        {
			                MSG_SendMesg(RET_FIN_ERR_INSTR_CLASSIFY, 0, FILEINFO);
                        }

						FREE_DYNST(sMktStructSt, S_MktStruct);
						FREE_DYNST(sMktSegtSt  , S_MktSegt);
						FREE_DYNST(aListSt     , A_List);
						/* REF7420 - RAK - 020918 */
						DBA_FreeDynStTab(aMktStructTab, mktStructNb, A_MktStruct);
						if (aGridStAllocFlg == TRUE) { FREE_DYNST(aGridSt, A_Grid); }
						return(FALSE);
					}

					/* PMSTA08737 - LJE - 091223 */
					if (allowOtherSgtFlg == FALSE &&
						GET_ENUM(aListSt, A_List_NatEn) == ListNat_Other)
					{
						excludeInstrFlg = TRUE;
					}

					strcpy(nameOrdinateTab[denomNb], GET_STRING(aListSt, A_List_Name));
				}
				else
				{
					nameOrdinateTab[denomNb][0] = 0;
					ordinateListId = 0;
				}

				denomNb++;


				/* Search the market segment */
				if (excludeInstrFlg == FALSE && /* PMSTA08737 - LJE - 091223 */
					FIN_GetMktSegtByLid(hierHead,
										currGridId,
										GET_ID(aMktStructSt, A_MktStruct_Id),
										abcissaListId,
										ordinateListId,
										&sMktSegtSt,
										selOptions,
										connectNo) == RET_SUCCEED)
				{
					SET_ID(sMktStructSt, S_MktStruct_ParMktSegtId, GET_ID(sMktSegtSt, S_MktSegt_Id));
				}
				else
				{
					exitFlg = TRUE;
				}
			}
			else
			{
				exitFlg = TRUE;
			}
		}

        FREE_DYNST(sMktStructSt, S_MktStruct);
		FREE_DYNST(aListSt     , A_List);
		/* REF7420 - RAK - 020918 */
		DBA_FreeDynStTab(aMktStructTab, mktStructNb, A_MktStruct);

	}

	if (excludeInstrFlg == FALSE && /* PMSTA08737 - LJE - 091223 */
		aMktSegtStp != NULL)
	{
        DBA_DYNFLD_STP aMktSegtSt = NULLDYNST;

		if (*aMktSegtStp == NULLDYNST)
		{
			if ((*aMktSegtStp = ALLOC_DYNST(A_MktSegt)) == NULLDYNST)
			{
				FREE_DYNST(sMktSegtSt, S_MktSegt);
				lastGridId = 0;
				return(FALSE);
			}
		}

        if (sMktSegtSt!=NULL)
        {
            /* Search market segment in hierarchy */ /* REF7420 - LJE - 020904 */
	        if (hierHead != NULL &&
                DBA_GetRecPtrFromHierById(hierHead,
                                          GET_ID(sMktSegtSt, S_MktSegt_Id),
			                              A_MktSegt,
                                          &aMktSegtSt) == RET_SUCCEED &&
										  aMktSegtSt != NULL)
            {
                COPY_DYNST(*aMktSegtStp, aMktSegtSt, A_MktSegt);
	        }
            else
            {
	            /* Get "all" MARKET_SEGMENT record */
	            if (DBA_Get2(MktSegt,
                             UNUSED,
                             S_MktSegt,
                             sMktSegtSt,
                             A_MktSegt,
                             aMktSegtStp,
			                 selOptions,
                             connectNo) != RET_SUCCEED)
	            {
                    /* REF<TASC> - LJE - 040123 */
                    if (aInstrSt != NULL && aGridSt != NULL)
                    {
			            MSG_SendMesg(RET_FIN_ERR_INSTR_CLASSIFY, 1, FILEINFO,
                                     GET_CODE(aInstrSt, A_Instr_Cd),
                                     GET_CODE(aGridSt, A_Grid_Cd));
                    }
                    else
                    {
			            MSG_SendMesg(RET_FIN_ERR_INSTR_CLASSIFY, 0, FILEINFO);
                    }

                    FREE_DYNST(sMktSegtSt, S_MktSegt);
			        FREE_DYNST((*aMktSegtStp), A_MktSegt);
                    return(FALSE);
	            }
            }
        }

		/* REF7420 - LJE - 020524 */
		/* Compute the new denom */
		if (denomNb > 0)
		{
			int  sizeOfName=0, sizeTotal=0;
			char *newDenom=denomComputed;
			int  totalNb=0;

			for (i=0; i<denomNb; i++)
			{
				if(nameAbcissaTab[i][0]!=0)
				{
					sizeTotal += SYS_StrLen(nameAbcissaTab[i])+1;
					totalNb++;
				}
				if(nameOrdinateTab[i][0]!=0)
				{
					sizeTotal += SYS_StrLen(nameOrdinateTab[i])+1;
					totalNb++;
				}
				sizeTotal++;
			}

			if (sizeTotal > sizeof(denomComputed))
			{
				sizeOfName = sizeof(denomComputed) / (totalNb+2);
			}
			else
			{
				sizeOfName = sizeof(NAME_T);
			}

			for (i=0; i<denomNb; i++)
			{
				if(i!=0)
				{
					strcat(newDenom, "//");
					newDenom+=2;
				}

				if(nameAbcissaTab[i][0]!=0)
				{
					sprintf(newDenom, "%.*s", sizeOfName, nameAbcissaTab[i]);
					newDenom += strlen(newDenom);
				}

				if(nameOrdinateTab[i][0]!=0)
				{
					if(nameAbcissaTab[i][0]!=0)
					{
						strcat(newDenom, "/");
						newDenom+=1;
					}

					sprintf(newDenom, "%.*s", sizeOfName, nameOrdinateTab[i]);
					newDenom += strlen(newDenom);
				}
			}

			SET_VINFO_ASCII((*aMktSegtStp), A_MktSegt_Denom, denomComputed); /* REF9303 - LJE - 030904 */

			/*FREE(nameAbcissaTab);
			FREE(nameOrdinateTab);
			denomNb=0;*/ /* REF8712 - YST - 030807 - free moved */
		}
	}
	FREE(nameAbcissaTab); /* REF8712 - YST - 030807 - free moved */
	FREE(nameOrdinateTab);
	denomNb=0;

	if (excludeInstrFlg == FALSE && /* PMSTA08737 - LJE - 091223 */
		sMktSegtSt!=NULL)
	{
        mktSegtId = GET_ID(sMktSegtSt, S_MktSegt_Id);
	}

    if (aGridStAllocFlg == TRUE) { FREE_DYNST(aGridSt, A_Grid); }
    FREE_DYNST(sMktSegtSt, S_MktSegt);
    lastGridId = 0;
    return(mktSegtId);
}


/* REF7420 - LJE - 020903 */
STATIC int FIN_FilterSMktSSubSetByLid(DBA_DYNFLD_STP   dynSt,
                                      DBA_DYNST_ENUM   ,
                                      DBA_DYNFLD_STP   paramSt)
{
    if (CMP_DYNFLD(dynSt, paramSt, A_MktSSubSet_RefGridId, S_MktSSubSet_RefGridId, IdType) == 0)
	    return(TRUE);
    else
	    return(FALSE);
}

/* REF7420 - LJE - 020905 */
STATIC int FIN_FilterSMktStructByLid (DBA_DYNFLD_STP   dynSt,
                                      DBA_DYNST_ENUM   ,
                                      DBA_DYNFLD_STP   paramSt)
{
    if (CMP_DYNFLD(dynSt, paramSt, A_MktStruct_RefGridId, S_MktStruct_RefGridId, IdType) == 0)
	    return(TRUE);
    else
	    return(FALSE);
}


/************************************************************************
*   Function             : FIN_GetMktStructInTab()
*
*   Description          : Get a market structure in tab of market structure
*
*   Arguments            :
*
*   Return               : RET_SUCCEED             : if ok
*
*   Creation Date        : REF7420 - LJE - 020523
*   Last Modif           :
*
*************************************************************************/
STATIC RET_CODE FIN_GetMktStructInTab(DBA_DYNFLD_STP sMktStructSt,
									  DBA_DYNFLD_STP *aMktStructTab,
									  int            mktStructNb,
									  DBA_DYNFLD_STP *aMktStructOutStp)
{

	int i=0;

	while (i<mktStructNb &&
		   (IS_NULLFLD(aMktStructTab[i], A_MktStruct_GridId) == TRUE || /* for ignore eliminate rows */
		    CMP_DYNFLD(sMktStructSt, aMktStructTab[i], S_MktStruct_ParMktSegtId, A_MktStruct_ParMktSegtId, IdType) != 0))

	{
		i++;
	}

	if (i==mktStructNb)
	{
		*aMktStructOutStp = NULLDYNST;
		return(RET_GEN_INFO_NODATA);
	}
	else
	{
		*aMktStructOutStp = aMktStructTab[i];
		return(RET_SUCCEED);
	}

}

/************************************************************************
*   Function             : FIN_GetMktSegtByLid()
*
*   Description          : Get a market segment by GridId, MktStructId, OrdinateListId
*                          and AbcissaListId in a hierarchy or in database
*
*   Arguments            :
*
*   Return               : RET_SUCCEED             : if ok
*
*   Creation Date        : REF7420 - LJE - 020523
*   Last Modif           :
*
*************************************************************************/
STATIC RET_CODE FIN_GetMktSegtByLid(DBA_HIER_HEAD_STP      hierHead,
									ID_T                   gridId,
									ID_T                   mktStructId,
									ID_T                   abcissaListId,
									ID_T                   ordinateListId,
									DBA_DYNFLD_STP        *sMktSegtStp,
									int                    selOptions,
									int*                   connectNo)
{

	DBA_DYNFLD_STP  sMktSegtStTmp = NULLDYNST;
	FLAG_T          foundInHier;

    DBA_DYNFLD_STP *sMktSegtTab = NULLDYNSTPTR;
    int             sMktSegtNbr;
    MemoryPool      mp;

	if (*sMktSegtStp == NULLDYNST)
	{
		sMktSegtStTmp =  mp.allocDynst(FILEINFO,S_MktSegt);
		*sMktSegtStp = sMktSegtStTmp;
	}
	else
	{
		sMktSegtStTmp = *sMktSegtStp;
	}

	if (mktStructId > 0)
	{
		SET_ID(sMktSegtStTmp, S_MktSegt_MktStructId, mktStructId);
	}
	else
	{
		SET_NULL_ID(sMktSegtStTmp, S_MktSegt_MktStructId );
	}

    if (abcissaListId > 0)
    {
        SET_ID(sMktSegtStTmp, S_MktSegt_AbcissaListId, abcissaListId);
    }
	else
	{
		SET_NULL_ID(sMktSegtStTmp, S_MktSegt_AbcissaListId );
	}

    if (ordinateListId > 0)
    {
        SET_ID(sMktSegtStTmp, S_MktSegt_OrdinateListId, ordinateListId);
    }
	else
	{
		SET_NULL_ID(sMktSegtStTmp, S_MktSegt_OrdinateListId );
	}

    SET_ID(sMktSegtStTmp, S_MktSegt_GridId, gridId);

	/* REF3678 - RAK - 990817 - Search market segment in hierarchy */
	foundInHier = FALSE;
	if (hierHead != NULL)
	{
	    if (DBA_ExtractHierEltRecWithFilterSt(hierHead,
                                              S_MktSegt, /* PMSTA-13295 - JPP - 20120207 */
			                                  FALSE,
                                              FIN_FilterSMktSegtByLid,
						                      sMktSegtStTmp,
                                              NULLFCT,
						                      &sMktSegtNbr,
                                              &sMktSegtTab) == RET_SUCCEED)
	    {
		    if (sMktSegtNbr == 1)
		    {
		        COPY_DYNST(sMktSegtStTmp, sMktSegtTab[0], S_MktSegt);
		        foundInHier = TRUE;
		    }
		    FREE(sMktSegtTab);
	    }
	}

	if (foundInHier == FALSE)
	{
	    /* Get MARKET_SEGMENT record */
	    if (DBA_Get2(MktSegt,
                     UNUSED,
                     S_MktSegt,
                     sMktSegtStTmp,
                     S_MktSegt,
                     &sMktSegtStTmp,
			         selOptions,
                     connectNo) != RET_SUCCEED)
	    {
            /* FREE_DYNST(sMktSegtSt, S_MktSegt); */
            return(RET_GEN_INFO_NODATA);
	    }
	}

	*sMktSegtStp = sMktSegtStTmp;
    mp.remove(sMktSegtStTmp);

	return(RET_SUCCEED);

}

STATIC int FIN_FilterSMktSegtByLid(DBA_DYNFLD_STP   dynSt,
                                   DBA_DYNST_ENUM   ,
                                   DBA_DYNFLD_STP   paramSt)
{
    if (CMP_DYNFLD(dynSt, paramSt, S_MktSegt_GridId,         S_MktSegt_GridId, IdType) == 0 &&
		CMP_DYNFLD(dynSt, paramSt, S_MktSegt_MktStructId,    S_MktSegt_MktStructId, IdType) == 0 && /* REF7420 - LJE - 020523 */
	    CMP_DYNFLD(dynSt, paramSt, S_MktSegt_OrdinateListId, S_MktSegt_OrdinateListId, IdType) == 0 &&
	    CMP_DYNFLD(dynSt, paramSt, S_MktSegt_AbcissaListId,  S_MktSegt_AbcissaListId, IdType) == 0)
	    return(TRUE);
    else
	    return(FALSE);
}

/************************************************************************
*   Function             : FIN_SearchInstrInMktSegt()
*
*   Description          : Determine if an instrument belongs to a market segment, and
*                          then return TRUE, FALSE elswhere.
*
*   WARNING              : This function can be called by DBA_SearchInstrInGrid(), which
*                          can be itself called by DBA_SearchInstrInGrid().
*
*   Arguments            : mktSegtId  : a market_segment id
*                          instrId    : an instrument id
*                          aInstrSt   : pointer on a A_Instr dyn. structure
*                          lastGridId : last grid handled
*
*   Return               : RET_SUCCEED             : if ok
*
*   Creation Date        : 13.11.95 - PEC
*   Last Modif           : 15.11.95 - PEC - Added argument lastGridId
*                          16.04.96 - PEC - Ref.: DVP023+
*					     : REF8023 - CHU - 021004 : stop recursivity to upper level
*													if instr doesn't belong to current mktsegtId
*************************************************************************/
int FIN_SearchInstrInMktSegt(PTR                    argHierHead,	/* REF3678 - RAK - 990817 - Add hierHead ptr */
                             ID_T                   mktSegtId,
                             ID_T                   instrId,
                             DBA_DYNFLD_STP         aInstrSt,
                             ID_T                   lastGridId,
                             FLAG_T                 verifFlg,
                             SCPT_CLASSIFSTACK_STP  classifStack,
                             int                    selOptions,
                             int*                   connectNo,
							 int					m3SDepthLevel,	/* REF8834 - CHU - 031119 */
							 DBA_DYNFLD_STP         *instrMktSgtPtr)/* REF9715 - CHU - 041124 */
{
    RET_CODE	    ret;
    ID_T            resMktSegtId    = 0;
    DBA_DYNFLD_STP	aGridSt         = NULLDYNST;
	FLAG_T          aGridStAllocFlg = FALSE;
	DBA_HIER_HEAD_STP hierHead=(DBA_HIER_HEAD_STP)argHierHead; /* REF7264 - LJE - 020128 */
	DBA_DYNFLD_STP  mktSegtPtr=NULLDYNST;

    /* Get GRID record */
	/* REF3678 - RAK - 990817 - Search market segment, then market segment grid in hierarchy */
	if (hierHead != NULL)
	{
	    if ((ret = DBA_GetRecPtrFromHierById(hierHead,
                                             mktSegtId,
                                             S_MktSegt,
			                                 &mktSegtPtr)) == RET_SUCCEED && mktSegtPtr != NULLDYNST)
	    {
		    if ((ret = DBA_GetRecPtrFromHierById(hierHead,
                                                 GET_ID(mktSegtPtr, S_MktSegt_GridId),
			                                     A_Grid,
                                                 &aGridSt)) != RET_SUCCEED)
            {
			    aGridSt = NULLDYNST;
            }
	    }
	}

	/* REF3678 - No hierarchy or not found in hierarchy */
	if (aGridSt == NULLDYNST)
	{
	    aGridStAllocFlg = TRUE;

	    if ((aGridSt = ALLOC_DYNST(A_Grid)) == NULLDYNST)
	    {
                MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
                return(FALSE);
	    }

	    SET_ID(aGridSt, A_Grid_ParMktSegtId,  mktSegtId);
	    if (DBA_Get2(Grid,
                     UNUSED,
                     A_Grid,
                     aGridSt,
                     A_Grid,
                     &aGridSt,
	                 selOptions,
                     connectNo) != RET_SUCCEED)
	    {
                FREE_DYNST(aGridSt, A_Grid);
                return(FALSE);
	    }
	}

	/* < REF8023 - CHU - 021004 */
	if (mktSegtPtr != NULLDYNST)
	{
		resMktSegtId = FIN_SearchInstrInGrid(hierHead,
											GET_ID(mktSegtPtr, S_MktSegt_GridId),
											instrId,
											aInstrSt,
											lastGridId,
											verifFlg,
											classifStack,
											NULL,
											FALSE,
											m3SDepthLevel, /* REF8834 - CHU - 031119 */
											TRUE, /* PMSTA08737 - LJE - 091223 */
											NULL,
											selOptions,
											connectNo);

			if (instrMktSgtPtr != NULL)
			{
				DBA_GetRecPtrFromHierById(hierHead, resMktSegtId, S_MktSegt, instrMktSgtPtr);
			}

            if (resMktSegtId != mktSegtId)
			{
				if (aGridStAllocFlg == TRUE) { FREE_DYNST(aGridSt, A_Grid); }
				return(FALSE);
			}
	}
	/* REF8023 - CHU - 021004 > */

    /* If the Grid didn't depend itself on a Market Segment */
    if (IS_NULLFLD(aGridSt, A_Grid_ParMktSegtId) == TRUE)
    {
            resMktSegtId = FIN_SearchInstrInGrid(hierHead,	/* REF3678 - RAK - 990817 - Add hierHead ptr */
						                         GET_ID(aGridSt, A_Grid_Id),
                                                 instrId,
                                                 aInstrSt,
                                                 lastGridId,
                                                 verifFlg,
                                                 classifStack,
                                                 NULL,
                                                 FALSE,
												 m3SDepthLevel, /* REF8834 - CHU - 031119 */
												 TRUE, /* PMSTA08737 - LJE - 091223 */
												 NULL,
                                                 selOptions,
                                                 connectNo);     /* DVP023+ */

			if (instrMktSgtPtr != NULL)
			{
				DBA_GetRecPtrFromHierById(hierHead, resMktSegtId, S_MktSegt, instrMktSgtPtr);
			}

            if (aGridStAllocFlg == TRUE) { FREE_DYNST(aGridSt, A_Grid); }

            if (resMktSegtId == mktSegtId)
                    return(TRUE);
            else
                    return(FALSE);
    }
    else /* the grid is a sub-grid */
    {
            resMktSegtId = GET_ID(aGridSt, A_Grid_ParMktSegtId);

            if (aGridStAllocFlg == TRUE)
            {
                FREE_DYNST(aGridSt, A_Grid);
            }

            if (resMktSegtId == mktSegtId)
            {
                return(TRUE);
            }

            return(FIN_SearchInstrInMktSegt(hierHead,
                                            resMktSegtId,
                                            instrId,
                                            aInstrSt,
                                            lastGridId,
                                            verifFlg,
                                            classifStack,
                                            selOptions,
                                            connectNo,
											m3SDepthLevel,	/* REF8834 - CHU - 031119 */
											instrMktSgtPtr));
    }
}

/************************************************************************
**
**  Function    :   FIN_Stat()
**
**  Description :   Receives one array of numerical data
**                  Computes :
**                  - number of records
**                  - mean
**                  - standard deviation
**                  - variance
**                  - median  (TO DO)
**                  - centile (TO DO)
**
**  Arguments   :   array           array pointer
**                  statPtr         pointer on output structure
**
**  Return      :   RET_SUCCEED or error code, statPtr is filled
**
** DVP005 : Added new function STAT (96/03/12)
**
*************************************************************************/
RET_CODE FIN_Stat(DBA_DYNFLD_STP array,
		  DBA_DYNFLD_STP statPtr)
{
	double             *arrayArg;
	int                i, dataNbr, argNbr;
	DBA_ARRAY_DATA_STP arrayData;
	RET_CODE           ret;

	if (array == NULLDYNST)
	{
	    MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
		         "FIN_Stat", "array pointer");
	    return(RET_GEN_ERR_INVARG);
	}

	if (statPtr == NULLDYNST)
	{
	    MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
		         "FIN_Stat", "statistics pointer");
	    return(RET_GEN_ERR_INVARG);
	}

	arrayData = GET_MULTIARRAY_PTR(array, 0);
	dataNbr   = GET_MULTIARRAY_DIM1(array, 0);

	if (dataNbr == 0)
	{
		ret = RET_FIN_ERR_INVDATA;
		/* MSG_SendMesg(ret, 2, FILEINFO, "FIN_Stat", "array size"); */
		return(ret);
	}

	if ((arrayArg = (double *)CALLOC(dataNbr, sizeof(double))) == (double*)NULL)
	{
		MSG_RETURN(RET_MEM_ERR_ALLOC);
	}

	for (i=0, argNbr=0; i<dataNbr; i++)
	{
		/* Exclude lines where the value is NULL */
		if (arrayData->notNullFlgTab[i] == TRUE)
		{
            /* REF8844 - LJE - 031013 */
            if (arrayData->dataTab[i].dynStEnum != 0 ||
                arrayData->dataTab[i].index     != 0 ||
                arrayData->dataTab[i].dataType  != 0)
            {
                switch (arrayData->dataTab[i].dataType)
                {
                case NumberType :
        	        arrayArg[argNbr] = GET_NUMBER(arrayData->dataTab,i);
                    break;

                case DictType :
        	        arrayArg[argNbr] = (double)GET_DICT(arrayData->dataTab,i);
                    break;

                case EnumType :
        	        arrayArg[argNbr] = (double)GET_ENUM(arrayData->dataTab,i);
                    break;

                case ExchangeType :
        	        arrayArg[argNbr] = (double)GET_EXCHANGE(arrayData->dataTab,i);
                    break;

                case FlagType :
        	        arrayArg[argNbr] = (double)GET_FLAG(arrayData->dataTab,i);
                    break;

                case IdType :
        	        arrayArg[argNbr] = (double)GET_ID(arrayData->dataTab,i);
                    break;

                case IntType :
        	        arrayArg[argNbr] = (double)GET_INT(arrayData->dataTab,i);
                    break;

                case MaskType :
        	        arrayArg[argNbr] = (double)GET_MASK(arrayData->dataTab,i);
                    break;

 	            case EnumMaskType :
        	        arrayArg[argNbr] = (double)GET_MASK64(arrayData->dataTab,i);
                    break;

                case MethodType :
        	        arrayArg[argNbr] = (double)GET_METHOD(arrayData->dataTab,i);
                    break;

                case PercentType :
        	        arrayArg[argNbr] = (double)GET_PERCENT(arrayData->dataTab,i);
                    break;

                case PeriodType :
        	        arrayArg[argNbr] = (double)GET_PERIOD(arrayData->dataTab,i);
                    break;

                case SmallintType :
        	        arrayArg[argNbr] = (double)GET_SMALLINT(arrayData->dataTab,i);
                    break;

                case TinyintType :
        	        arrayArg[argNbr] = (double)GET_TINYINT(arrayData->dataTab,i);
                    break;

                /* PMSTA-20887 - LJE - 150909 */
                case LongintType:
                    arrayArg[argNbr] = (double)GET_LONGINT(arrayData->dataTab, i);
                    break;

                case YearType:
        	        arrayArg[argNbr] = (double)GET_YEAR(arrayData->dataTab,i);
                    break;

                case AmountType :
        	        arrayArg[argNbr] = (double)GET_AMOUNT(arrayData->dataTab,i);
                    break;

                case LongamountType :
        	        arrayArg[argNbr] = (double)GET_LONGAMOUNT(arrayData->dataTab,i);
                    break;

                default :
        	        arrayArg[argNbr] = 0.0; /* REF7296 - LJE - 020501 */
                }
            }
            else
            {
        	    arrayArg[argNbr] = GET_NUMBER(arrayData->dataTab,i); /* REF7296 - LJE - 020501 */
            }

            ++argNbr; /* REF8712 - LJE - 031022 */
		}
	}

	if (argNbr >= 1) /* REF4245 - SSO - 000117 "3" -> "1"*/
	{
		ret = FIN_CalcStat(arrayArg, argNbr, statPtr);
	}
	else
	{
		ret = RET_FIN_ERR_INVDATA;
		/* MSG_SendMesg(ret, 2, FILEINFO, "FIN_Stat", "array size"); */
	}

	FREE(arrayArg);
	return(ret);
}

/************************************************************************
**
**  Function    :   FIN_ThirdChronoArray()
**
**  Description :   Construct an third chronological data array
**                  for received third and chronological nature in
**                  received currency
**                  Use frequency and number of reading for select
**
**  Arguments   :   date         end date of the series
**                  freq         frequency at which the data is extracted
**                  freqUnitEn   frequency at which the data is extracted
**                  reading      how many occurrences are to be selected
**                  thirdId      third identifier
**                  chronoNatEn  chronological data nature
**                  method       missing data resolution method - REF7061 - TEB - 030123
**                  currId       currency identifier
**                  array        pointer on an multiArray field
**
**  Return      :   RET_SUCCEED or error code
**
** DVP005 : Added new function THIRD_CHRONO_ARRAY (96/03/12)
**  Modif	    :   REF7061 - TEB - 030123
**
*************************************************************************/
RET_CODE FIN_ThirdChronoArray(DATETIME_T  date,
			      TINYINT_T               freq,
			      ENUM_T                  freqUnit,
			      int                     reading,
			      ID_T                    thirdId,
			      ENUM_T                  chronoNatEn,
			      ID_T                    inputCurrId,
                  MISSINGDATA_METHOD_ENUM method,      /* REF7061 - TEB - 030123 */
                  DBA_DYNFLD_STP          array)
{
	DBA_DYNFLD_STP     getThird=NULLDYNST, thirdPtr=NULLDYNST, *chronoTab=(DBA_DYNFLD_STP*)NULL;
	DBA_ARRAY_DATA_STP chronoArrayPtr=(DBA_ARRAY_DATA_STP)NULL;
	EXCHANGE_T         exch;
	ID_T               currId;
	int                i, j, k;
    int                chronoNbr = 0;
	RET_CODE           ret;
	FIN_EXCHARG_ST     exchArgSt;			/* REFXZ */
	DATE_UNIT_ENUM     dateUnit=Year;                       /* REF7061 - TEB - 030123 */
    DATETIME_T         beginDate;                           /* REF7061 - TEB - 030123 */
    DBA_DYNFLD_STP     thirdChronoPtr=NULLDYNST;            /* REF7061 - TEB - 030123 */
    DBA_DYNFLD_STP     *chronoTabTmp=(DBA_DYNFLD_STP*)NULL; /* REF7061 - TEB - 030123 */
    NUMBER_T           sumValues, nextValue, prevValue;     /* REF7061 - TEB - 030123 */
    int                nbValues;                            /* REF7061 - TEB - 030123 */

    sumValues = 0;                                          /* REF7061 - TEB - 030123 */
	memset(&exchArgSt, 0, sizeof(FIN_EXCHARG_ST));

	/*DBA_SetConnectNoToExchArg(&exchArgSt, SERV_GetThreadConnNbr()); */ /* REF2580 - SSO - 980727 */
	DBA_InitConnectNoToExchArg(&exchArgSt, NULL); /* REF4213 - SSO - 991221 */

	/* If currency isn't specified as an input, */
	/* the portfolio currency should be used.   */
	if (inputCurrId != -1)
	{
	    currId = inputCurrId;
	}
	else
	{
	    /*
	    if (inputThirdPtr != NULLDYNST)
	    {
		currId = GET_ID(inputThirdPtr, A_Third_CurrId);
	    }
	    else
	    {
	    */
        if ((getThird = ALLOC_DYNST(S_Third)) == NULLDYNST)
	   		MSG_RETURN(RET_MEM_ERR_ALLOC);

        if ((thirdPtr = ALLOC_DYNST(A_Third)) == NULLDYNST)
        {
            FREE_DYNST(getThird, S_Third);
	   		MSG_RETURN(RET_MEM_ERR_ALLOC);
        }

        SET_ID(getThird, S_Third_Id, thirdId);

        if ((ret = DBA_Get2(Third, UNUSED, S_Third, getThird, A_Third,
		            &thirdPtr, UNUSED, UNUSED, UNUSED)) != RET_SUCCEED)
        {
			SYSNAME_T entSqlName;
			strcpy(entSqlName, DBA_GetDictEntitySqlName(Third));
			MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO, entSqlName, thirdId);
                        FREE_DYNST(getThird, S_Third);
                        FREE_DYNST(thirdPtr, A_Third);
	   		return(RET_DBA_ERR_NODATA);  /* ?? */
        }

		currId = GET_ID(thirdPtr, A_Third_CurrId);
        FREE_DYNST(getThird, S_Third);
        FREE_DYNST(thirdPtr, A_Third);
	    /* } */
	}

	if ((ret = DBA_ThirdChronoByFreq(date, freq, (FREQUNIT_ENUM) freqUnit, reading,
		       thirdId, chronoNatEn, &chronoTab, &chronoNbr)) != RET_SUCCEED)
		return(ret);


    /* REF7061 - TEB - 030123 */
	if (chronoNbr > 0)
	{
        /* Sort intrument chrono ascending by date */
	    /* Do sort only for at least 2 data */
        /* REF7061 - TEB - 030123 */
	    if (chronoNbr > 1)
            TLS_Sort((char *) chronoTab, chronoNbr, sizeof(DBA_DYNFLD_STP),
                     (TLS_CMPFCT *)FIN_CmpThirdChronoDate, (PTR **) NULL, SortRtnTp_None); /* REF7264 - LJE - 020131 */

        /* REF7061 - TEB - 030123 (Begin) */
	    switch(freqUnit)
	    {
            case FreqUnit_Day:
                dateUnit = Day;
                break;

            case FreqUnit_BusDay:
                dateUnit = Day;
                break;

            case FreqUnit_Week:
                dateUnit = Week;
                break;

            case FreqUnit_Month:
                dateUnit = Month;
                break;

            case FreqUnit_Quarter:
                dateUnit = Quarter;
                break;

            case FreqUnit_Semester:
                dateUnit = Semester;
                break;

            case FreqUnit_Year:
                dateUnit = Year;
                break;
        }

	    beginDate.date = DATE_Move(date.date, (-1) * (reading - 1) * freq, dateUnit);
	    beginDate.time = 0;

        /* Alloc thirdChronoPtr structure and chronoTabTmp */
        if ((thirdChronoPtr = ALLOC_DYNST(Freq_ThirdChrono)) == NULLDYNST)
            MSG_RETURN(RET_MEM_ERR_ALLOC);

        if ((chronoTabTmp=(DBA_DYNFLD_STP *) CALLOC(reading,
                                                 	sizeof(DBA_DYNFLD_STP))) == NULL)
       	{
            FREE_DYNST(thirdChronoPtr, Freq_ThirdChrono);
           	MSG_RETURN(RET_MEM_ERR_ALLOC);
        }

        for(i=0; i< reading; i++)
        {
		    if ((chronoTabTmp[i] = ALLOC_DYNST(Freq_ThirdChrono)) == NULLDYNST)
		    {
			    for (j=0; j<i; j++)
			        { FREE_DYNST(chronoTabTmp[j], Freq_ThirdChrono); }
			    FREE(chronoTabTmp);
                FREE_DYNST(thirdChronoPtr, Freq_ThirdChrono);
	            DBA_FreeDynStTab(chronoTab, chronoNbr, Freq_ThirdChrono);
			    MSG_RETURN(RET_MEM_ERR_ALLOC);
		    }

    	    beginDate.date = DATE_Move(date.date, (-1) * i * freq, dateUnit);

            /* Search right element in array */
            if ((ret = FIN_SearchThirdChronoEltInTab(chronoTab, chronoNbr, beginDate, thirdChronoPtr)) == RET_SUCCEED )
            {
                COPY_DYNFLD(chronoTabTmp[i], Freq_ThirdChrono, Freq_ThirdChrono_ThirdId,
                            thirdChronoPtr,  Freq_ThirdChrono, Freq_ThirdChrono_ThirdId);
                COPY_DYNFLD(chronoTabTmp[i], Freq_ThirdChrono, Freq_ThirdChrono_NatEn,
                            thirdChronoPtr,  Freq_ThirdChrono, Freq_ThirdChrono_NatEn);
                COPY_DYNFLD(chronoTabTmp[i], Freq_ThirdChrono, Freq_ThirdChrono_ValidDate,
                            thirdChronoPtr,  Freq_ThirdChrono, Freq_ThirdChrono_ValidDate);
                COPY_DYNFLD(chronoTabTmp[i], Freq_ThirdChrono, Freq_ThirdChrono_CurrId,
                            thirdChronoPtr,  Freq_ThirdChrono, Freq_ThirdChrono_CurrId);
                if ( method == MissingDataMethod_LastValid ||
                     DATETIME_CMP(GET_DATETIME(thirdChronoPtr, Freq_ThirdChrono_ValidDate), beginDate) == 0)
                {
                    COPY_DYNFLD(chronoTabTmp[i], Freq_ThirdChrono,  Freq_ThirdChrono_Val,
                                thirdChronoPtr,  Freq_ThirdChrono,  Freq_ThirdChrono_Val);

                    /* Calculate exchange on value */
                    if (IS_NULLFLD(chronoTabTmp[i], Freq_ThirdChrono_Val) == FALSE &&
                        IS_NULLFLD(chronoTabTmp[i], Freq_ThirdChrono_CurrId) == FALSE &&
                        GET_ID(chronoTabTmp[i], Freq_ThirdChrono_CurrId) != currId)
                    {
                        FIN_GetExchRate(GET_DATETIME(chronoTabTmp[i], Freq_ThirdChrono_ValidDate),
                                        GET_ID(chronoTabTmp[i], Freq_ThirdChrono_CurrId), currId,
                                        0, NULLDYNST, NULLDYNST, &exchArgSt, &exch);				/* PMSTA01649 - TGU - 070405 */
	   	                SET_NUMBER(chronoTabTmp[i],
                                   Freq_ThirdChrono_Val,
				                   (GET_NUMBER(chronoTabTmp[i], Freq_ThirdChrono_Val) * exch));
                    }
                }
                SET_DATETIME(chronoTabTmp[i],Freq_ThirdChrono_RequestDate, beginDate);
            }
            else
            {
                MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO,"FIN_ThirdChronoArray",
                                currId,
                                "FIN_ThirdChronoArray - Chrono computing for this third party failed !");
            }
        }

        FREE_DYNST(thirdChronoPtr, Freq_ThirdChrono);

        /* Now we can apply the method for missing data */
        nbValues = 0;
        if (method == MissingDataMethod_Average)
		    for (i=0; i<reading; i++)
                if (IS_NULLFLD(chronoTabTmp[i], Freq_ThirdChrono_Val) == FALSE)
                {
                    sumValues += GET_NUMBER(chronoTabTmp[i], Freq_ThirdChrono_Val);
                    nbValues++;
                }

		for (i=0; i<reading; i++)
		{
            if ( IS_NULLFLD(chronoTabTmp[i], Freq_ThirdChrono_Val) == TRUE)
            {
                switch(method)
                {
                    case MissingDataMethod_IgnoreMissing:
                        reading--;
                        FREE_DYNST(chronoTabTmp[i], Freq_ThirdChrono);
                        for(j=i; j<reading; j++)
                            chronoTabTmp[j] = chronoTabTmp[j+1];
                        chronoTabTmp[j] = NULLDYNST;
                        i--;
                        break;

                    case MissingDataMethod_Average:
                        if (nbValues!=0)
                            SET_NUMBER(chronoTabTmp[i], Freq_ThirdChrono_Val, sumValues/nbValues);
                        break;

                    case MissingDataMethod_Encadrante:
                        if (i == 0)
                        {
                            reading--;
                            FREE_DYNST(chronoTabTmp[i], Freq_ThirdChrono);
                            for(j=i; j<reading; j++)
                                chronoTabTmp[j] = chronoTabTmp[j+1];
                            chronoTabTmp[j] = NULLDYNST;
                            i--;
                        }
                        else
                        {
                            prevValue = GET_NUMBER(chronoTabTmp[i-1], Freq_ThirdChrono_Val);

                            for (j=i;
                                 j<reading && IS_NULLFLD(chronoTabTmp[j], Freq_ThirdChrono_Val) == TRUE;
                                 j++) ; /* I want it */

                            if (j<reading)
                            {
                                nextValue = GET_NUMBER(chronoTabTmp[j], Freq_ThirdChrono_Val);
                                for (k=i; k<j; k++)
                                    SET_NUMBER(chronoTabTmp[k], Freq_ThirdChrono_Val, (prevValue+nextValue)/2);
                            }
                            else
                            {
                                for(j=i; j<reading; j++)
                                    FREE_DYNST(chronoTabTmp[j], Freq_ThirdChrono);
                                reading=i;
                            }
                        }
                        break;
                }
            }
        }
        /* REF7061 - TEB - 030123 (End) */


	    if ((chronoArrayPtr = (DBA_ARRAY_DATA_STP)CALLOC(1, sizeof(DBA_ARRAY_DATA_ST))) == (DBA_ARRAY_DATA_STP)NULL)  /* REF7264 - LJE - 020128 */
	    {
	    	DBA_FreeDynStTab(chronoTab,    chronoNbr, Freq_ThirdChrono);
            DBA_FreeDynStTab(chronoTabTmp, reading,   Freq_ThirdChrono);
		    MSG_RETURN(RET_MEM_ERR_ALLOC);
	    }

        if ((chronoArrayPtr->dataTab = ALLOC_DYNST_WITHOUTDEF(reading)) == (PTR)NULL) /* REF8844 - LJE - 030401 */
	    {
	    	DBA_FreeDynStTab(chronoTab,    chronoNbr, Freq_ThirdChrono);
            DBA_FreeDynStTab(chronoTabTmp, reading,   Freq_ThirdChrono);
            MSG_RETURN(RET_MEM_ERR_ALLOC);
	    }

	    if ((chronoArrayPtr->notNullFlgTab = (char *)CALLOC(reading, sizeof(char))) == (PTR)NULL) /* REF7264 - LJE - 020128 */
	    {
	    	DBA_FreeDynStTab(chronoTab,    chronoNbr, Freq_ThirdChrono);
            DBA_FreeDynStTab(chronoTabTmp, reading,   Freq_ThirdChrono);
            MSG_RETURN(RET_MEM_ERR_ALLOC);
	    }

        /* REF7061 - TEB - 030123 */
	    for (i=0; i<reading; i++)
	    {
	   	    SET_NUMBER(chronoArrayPtr->dataTab,
                       i,
                       GET_NUMBER(chronoTabTmp[i], Freq_ThirdChrono_Val)); /* REF7296 - LJE - 020501 */
		    chronoArrayPtr->notNullFlgTab[i] = TRUE;
	    }
    }
    else
    {
        reading = 0;  /* REF7061 - TEB - 030603 */
    }

	DBA_FreeDynStTab(chronoTabTmp, reading,   Freq_ThirdChrono); /* REF7061 - TEB - 030123 */
	DBA_FreeDynStTab(chronoTab,    chronoNbr, Freq_ThirdChrono);
	SET_MULTIARRAY(array, 0, chronoArrayPtr, (ushort) reading, 1);

	return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_CmpInstrPriceDate()
**
**  Description :   Compare intrument price date
**
**  Arguments   :   instrPrice1 and instrPrice2 for comparison
**
**  Return      :
**     a negative value if first element < second element
**     a null value     if first element = second element
**     a positive value if first element > second element
**
**  Modif:	REF2544 - SSO - 980717 - TLS_Sort is done in DBA_InstrPriceByFreq
**		    Thus, this function is moved to dbainstr.c
**
*************************************************************************/
/*
STATIC int FIN_CmpInstrPriceDate(DBA_DYNFLD_STP  *instrPrice1,
                                 DBA_DYNFLD_STP  *instrPrice2)
{
	return(CMP_DYNFLD((*instrPrice1), (*instrPrice2),
                          A_InstrPrice_QuoteDate, A_InstrPrice_QuoteDate,
                          DatetimeType));
}
*/

/************************************************************************
**
**  Function    :   FIN_CmpExchRateDate()
**
**  Description :   Compare exchange rate date
**
**  Arguments   :   two records to compare
**
**  Return      :
**     a negative value if first element < second element
**     a null value     if first element = second element
**     a positive value if first element > second element
**
**  REF2544 - SSO - 980717 - FIN_CmpInstrPriceDate and FIN_CmpExchRateDate moved to dbainstr.c, dbaexch.c
**
*************************************************************************/
/* STATIC int FIN_CmpExchRateDate(DBA_DYNFLD_STP  *exchRate1,
				   DBA_DYNFLD_STP  *exchRate2)
    {
	    return(CMP_DYNFLD((*exchRate1), (*exchRate2),
			      Freq_ExchRate_ExchDate, Freq_ExchRate_ExchDate,
			      DatetimeType));
    }
*/

/************************************************************************
**
**  Function    :   FIN_CmpInstrChronoDate()
**
**  Description :   Compare instrument chrono date
**
**  Arguments   :   two records to compare
**
**  Return      :
**     a negative value if first element < second element
**     a null value     if first element = second element
**     a positive value if first element > second element
**
*************************************************************************/
STATIC int FIN_CmpInstrChronoDate(DBA_DYNFLD_STP  *instrChrono1,
                                  DBA_DYNFLD_STP  *instrChrono2)
{
	return(CMP_DYNFLD((*instrChrono1), (*instrChrono2),
                          Freq_InstrChrono_ValidDate, Freq_InstrChrono_ValidDate,
                          DatetimeType));
}

/************************************************************************
**
**  Function    :   FIN_CmpPtfChronoDate()
**
**  Description :   Compare portfolio chrono date
**
**  Arguments   :   two records to compare
**
**  Return      :
**     a negative value if first element < second element
**     a null value     if first element = second element
**     a positive value if first element > second element
**
*************************************************************************/
STATIC int FIN_CmpPtfChronoDate(DBA_DYNFLD_STP  *ptfChrono1,
                                DBA_DYNFLD_STP  *ptfChrono2)
{
	return(CMP_DYNFLD((*ptfChrono1), (*ptfChrono2),
                          Freq_PtfChrono_ValidDate, Freq_PtfChrono_ValidDate,
                          DatetimeType));
}

/************************************************************************
**
**  Function    :   FIN_CmpListChronoDate()
**
**  Description :   Compare list chrono date
**
**  Arguments   :   two records to compare
**
**  Return      :
**     a negative value if first element < second element
**     a null value     if first element = second element
**     a positive value if first element > second element
**
**  Creation date     : REF7292 - LJE - 020130
**
*************************************************************************/
STATIC int FIN_CmpListChronoDate(DBA_DYNFLD_STP  *listChrono1,
                                 DBA_DYNFLD_STP  *listChrono2)
{
	return(CMP_DYNFLD((*listChrono1), (*listChrono2),
                          Freq_ListChrono_ValidDate, Freq_ListChrono_ValidDate,
                          DatetimeType));
}

/************************************************************************
**
**  Function    :   FIN_CmpThirdChronoDate()
**
**  Description :   Compare third chrono date
**
**  Arguments   :   two records to compare
**
**  Return      :
**     a negative value if first element < second element
**     a null value     if first element = second element
**     a positive value if first element > second element
**
*************************************************************************/
STATIC int FIN_CmpThirdChronoDate(DBA_DYNFLD_STP  *third1,
                                  DBA_DYNFLD_STP  *third2)
{
	return(CMP_DYNFLD((*third1), (*third2),
                          Freq_ThirdChrono_ValidDate, Freq_ThirdChrono_ValidDate,
                          DatetimeType));
}

/************************************************************************
**
**  Function    :   FIN_CmpESLReconcOK()
**
**  Description :   compare ExtStratLnk_CalcEn to have the ReconcOK ESL first in the array
**
**  Arguments   :   two records to compare
**
**  Return      :
**     a negative value if first element < second element
**     a null value     if first element = second element
**     a positive value if first element > second element
**
*************************************************************************/
STATIC int FIN_CmpESLReconcOK(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
	if(GET_ENUM((*ptr1), ExtStratLnk_CalcEn) == GET_ENUM((*ptr2), ExtStratLnk_CalcEn))
		return 0;
	if(GET_ENUM((*ptr1), ExtStratLnk_CalcEn) == (ENUM_T) StratCalc_ReconcOK)
		return -1;
    if(GET_ENUM((*ptr2), ExtStratLnk_CalcEn) == (ENUM_T) StratCalc_ReconcOK)
		return 1;
	return 0;
}

/************************************************************************
*
*   Function        :   FIN_SearchInstrInMPElements()
*
*   Description     :   Check Esl of submodels and see if given instr is avilable 
                        in any subMP

*   Arguments       :   stratHierHead     : a pointer on a strategy header
*
*
*   Return          :   RET_SUCCEED	or error code
*
*   Creation date   :   PMSTA-39388 -Vishnu 25032020 ModelOfModels Compliance
*
*************************************************************************/

STATIC DBA_DYNFLD_STP FIN_SearchInstrInMPElements(PTR                      stratHierHead,
                                        DBA_DYNFLD_STP           domainPtr,
                                        DBA_DYNFLD_STP           extStratLnkPtr,
                                        ID_T instrId
                                        )
{
    DBA_DYNFLD_STP  dynFldPtr = NULLDYNST, *stratEltTab = NULLDYNSTPTR, *subMPTab = NULLDYNSTPTR;
    int stratEltNbr = 0,subMPNbr = 0;

    if(instrId < 1)
        return NULLDYNST;

    if (GET_EXTENSION_PTR(extStratLnkPtr, ExtStratLnk_A_StratHist_Ext) != NULL &&
        (dynFldPtr = *(GET_EXTENSION_PTR(extStratLnkPtr, ExtStratLnk_A_StratHist_Ext))) != NULLDYNST)
    {
        stratEltTab = GET_EXTENSION_PTR(dynFldPtr, A_StratHist_A_StratElt_Ext);
        stratEltNbr = GET_EXTENSION_NBR(dynFldPtr, A_StratHist_A_StratElt_Ext);

        /*Looping Start Hist for instrument */
        for (int j = 0; j < stratEltNbr; j++)
        {
            if (GET_ID(stratEltTab[j], A_StratElt_InstrId) == instrId)
            {
                /*Found the instrument in ESL*/
                return(extStratLnkPtr);
            }
        }
    }

    /*Check if MP has any submodel and then check if instrument is available in the subMP*/
    subMPTab = GET_EXTENSION_PTR(extStratLnkPtr, ExtStratLnk_Child_ExtStratLnk_Ext);
    subMPNbr = GET_EXTENSION_NBR(extStratLnkPtr, ExtStratLnk_Child_ExtStratLnk_Ext);

    for (int subMPcnt = 0; subMPcnt < subMPNbr; subMPcnt++)
    {
        if (GET_FLAG(subMPTab[subMPcnt], ExtStratLnk_SubModelFlg) == FALSE)
            continue;

        dynFldPtr = FIN_SearchInstrInMPElements(stratHierHead, domainPtr, subMPTab[subMPcnt], instrId);
        if (dynFldPtr != NULLDYNST)
            return dynFldPtr;
    }

    return NULLDYNST;

}

/************************************************************************
**
**  Function    :   FIN_SetInstrInStratHier()
**
**  Description :   Positioning an instrument in a strategy hierarchy
**                  For a strategy hierarchy, seek if the instrument is in a
**                  model portfolio. If so, insert the occurrence and position
**                  it at the same level in the hierarchy as the lign in the
**                  model portfolio. If not seek the highest level in the
**                  hierarchy. If this is a model portfolio, insert the lign at
**                  this level. If it is an allocation, seek the market segment
**                  to which this instrument is related. If there is a substra-
**                  tegy linked to this market segment, repeat the process. If
**                  there is no substrategy, insert the lign at the level of
**                  the market segment.
**
**  Arguments   :   extStratLnkPtr  : pointer on current extended strategy link
**                  domainPtr       : domain pointer
**                  crtPos          : current position  (can be NULL if instrArgPtr is provided)
**                  instrArgPtr     : instrument pointer (can be NULL)
**                  mktSegtIdPtr    : pointer on market segment identifier to fill
**		                              classifStack
**
**  Return      :   RET_SUCCEED	 or error code
**
**  Modif.      :   DVP339 - RAK - 970310
**  Modif.      :   DVP460 - RAK - 970618
**  Modif.		:	REF3641 - RAK - 990511
**  Modif.		:	REF4047 - SKE - 000121
**  Modif.		:	PMSTA-52554 - AAKASH - 270423
**
*************************************************************************/
DBA_DYNFLD_STP FIN_SetInstrInStratHier(PTR                      stratHierHead,
                                       DBA_DYNFLD_STP           domainPtr,      /* REF3641 */
                                       DBA_DYNFLD_STP           extStratLnkPtr,
                                       DBA_DYNFLD_STP           crtPos,
                                       DBA_DYNFLD_STP           instrArgPtr,    /* REF4047 - 000121 - SKE */
                                       ID_T                     *mktSegtIdPtr,
                                       SCPT_CLASSIFSTACK_STP    classifStack,
                                       int                      selOptions,
                                       int*                     connectNo,
									   int						m3SDepthLevel) /* REF8834 - CHU - 031119 */
{
	int		i, childLnkNbr,subMPChildNbr=0, fxFwdClassifyCash = FX_CLASSIFY_RISKORIG;
	ID_T		instrId, mktSegtId, gridId;
	DBA_DYNFLD_STP	instrPtr=NULLDYNST, gridPtr=NULLDYNST, subModelEsl=NULLDYNST, *childLnkTab=NULLDYNSTPTR, *subMPChildTab=NULLDYNSTPTR;
	DBA_DYNFLD_STP  sMktSegPtr=NULLDYNST;
	FLAG_T OverrideApplForInstr = FALSE;
	MemoryPool mp;

	*mktSegtIdPtr = -1;

    /* REF4047 - 000121 - SKE */
    if (instrArgPtr != NULLDYNST)
    {
        instrPtr = instrArgPtr;
    }
    /**/
    else
    {
	    if (GET_EXTENSION_PTR(crtPos, ExtPos_A_Instr_Ext) != NULL)
        {
		    instrPtr = *(GET_EXTENSION_PTR(crtPos, ExtPos_A_Instr_Ext));
        }
    }
	if (instrPtr != NULLDYNST)
	{
	    if (GET_ID(instrPtr, A_Instr_Id) < 0)
	    {
            instrId = GET_ID(instrPtr, A_Instr_ParentInstrId);
        }
	    else
	    {
            instrId = GET_ID(instrPtr, A_Instr_Id);
        }
	}
	else
	{
        instrId = GET_ID(crtPos, ExtPos_InstrId);
    }



	/*WEALTH-3036 -Vishnu - 29-10-2023
		Check if the postion is for fx split postion by checking risk origin instrument */
	if (instrPtr != NULLDYNST &&
			IS_NULLFLD(instrPtr, A_Instr_RiskOrigInstrId) == FALSE)
	{
		FLAG_T            allocOk;
		DBA_DYNFLD_STP    riskOrigInstrStp = NULLDYNST;

		if (DBA_GetInstrById(GET_ID(instrPtr, A_Instr_RiskOrigInstrId), TRUE, &allocOk,
			&riskOrigInstrStp, (DBA_HIER_HEAD_STP)stratHierHead, UNUSED, UNUSED) == RET_SUCCEED)
		{
			if (allocOk == TRUE)
			{
				mp.owner(riskOrigInstrStp);
				SYS_BreakOnDebug(); /* this must never happend */
			}
		}

		if (riskOrigInstrStp != NULLDYNST &&
			GET_ENUM(riskOrigInstrStp, A_Instr_SubNatEn) == SubNat_FXFwd_TwoLegsAgainsPtfCurr)
		{
			GEN_GetApplInfo(ApplPckGlFxFwdClassifyCash, &fxFwdClassifyCash);

			/* PMSTA-60069 - Deepthi - 20240911 */
			/*	Parameter - PCK_GL_FX_FWD_CLASSIFY_CASH is used to classify 
				forward instruments with sub nature = 122.
				Value 0 - Forwards classified based on the risk orig instrument
				Value 1 - Forwards classified based on the risk cash instruments */

			if (fxFwdClassifyCash == FX_CLASSIFY_RISKCASH)
			{
				DBA_DYNFLD_STP riskOrigStp = mp.allocDynst(FILEINFO, A_InstrRiskOrig);

				DBA_GetRecPtrFromHierById((DBA_HIER_HEAD_STP)stratHierHead,
					GET_ID(crtPos, ExtPos_InstrId), A_InstrRiskOrig, &riskOrigStp);
				instrId = GET_ID(riskOrigStp, A_InstrRiskOrig_InstrId);
			}
			else
			{
				/*if risk origin instrument is fx fwd then use that instrument */
				instrPtr = riskOrigInstrStp;
				instrId = GET_ID(riskOrigInstrStp, A_Instr_Id);
			}
		}
	}


	/* REF7337 - RAK - 020813 */
	/* First step - verify if belong ExtStratLnk_MktSegId (parent market segment) */
	/*if (IS_NULLFLD(extStratLnkPtr, ExtStratLnk_GridId) == TRUE)
	{
	*/
	    /* --------------------------- */
	    /* BEGIN BUG047 - RAK - 960702 */
	    if (IS_NULLFLD(extStratLnkPtr, ExtStratLnk_MktSegId) == FALSE &&
			/* REF7337 - RAK - 020823 - Only for first level ESL */
			(GET_TINYINT(extStratLnkPtr, ExtStratLnk_StratLevel) <= 1	||
			/* REF10222 - CHU - 041209 - enter here anyway for Lnk without grid (reuse code commented by REF7337 above) */
			IS_NULLFLD(extStratLnkPtr, ExtStratLnk_GridId) == TRUE))
	    {
		    /* REF3678 - Get market segment and search grid by his id ... */
		    if (GET_EXTENSION_PTR(extStratLnkPtr, ExtStratLnk_S_MktSgt_Ext) != NULL &&
		        (sMktSegPtr = *(GET_EXTENSION_PTR(extStratLnkPtr, ExtStratLnk_S_MktSgt_Ext))) != NULLDYNST)
		    {
		        gridId = GET_ID(sMktSegPtr, S_MktSegt_GridId);
		    }
		    else
		    {
        	    if ((gridPtr = ALLOC_DYNST(A_Grid)) == NULLDYNST)
        	    {
			        MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
			        return(NULLDYNST);
		        }

        	    /* Get GRID record */
        	    SET_ID(gridPtr, A_Grid_ParMktSegtId, GET_ID(extStratLnkPtr, ExtStratLnk_MktSegId));
        	    if (DBA_Get2(Grid,
                             UNUSED,
                             A_Grid,
                             gridPtr,
                             A_Grid,
                             &gridPtr,
				             selOptions,
                             connectNo) != RET_SUCCEED)
        	    {
				    FREE_DYNST(gridPtr, A_Grid);
				    return(NULLDYNST);
        	    }
		        gridId = GET_ID(gridPtr, A_Grid_Id);
		        FREE_DYNST(gridPtr, A_Grid);
		    }

		    if ((mktSegtId = FIN_SearchInstrInGrid(stratHierHead,
                                                   gridId,
                                                   instrId,
                                                   instrPtr,
							                       0,
                                                   TRUE,
                                                   classifStack,
                                                   NULL,
                                                   FALSE,
												   m3SDepthLevel, /* REF8834 - CHU - 031119 */
												   TRUE, /* PMSTA08737 - LJE - 091223 */
												   NULL,
				                                   selOptions,
                                                   connectNo)) != 0)
		    {
			    if (mktSegtId == GET_ID(extStratLnkPtr, ExtStratLnk_MktSegId))
			    {
				    *mktSegtIdPtr = GET_ID(extStratLnkPtr, ExtStratLnk_MktSegId);
				    /* REF7337 - RAK - 020813 */
					/* quand m�me continuer pour v�rifer dans quel market segment de la grid on est */
					/*
					return(extStratLnkPtr);
					*/
			    }
			    else
                {
				    return(NULLDYNST);
                }
		    }
	   	    else
            {
			    return(NULLDYNST);
            }
	    }
		/* REF7337 - RAK - 020813 */
		/* quand m�me continuer pour v�rifer dans quel market segment de la grid on est */
	    /* else
	    {
	    	return(extStratLnkPtr);
	    }
		*/
	    /* END   BUG047 - RAK - 960702 */
	    /* --------------------------- */
	/*
	}
	*/

	/*** SEEK THE MARKET SEGMENT TO WHICH INSTRUMENT IS RELATED ***/
	/* BUG047 - Wrong classification - RAK - 960702 */
	if ((mktSegtId = FIN_SearchInstrInGrid(stratHierHead, /* REF3678 - RAK - 990817 - Add hierHead ptr */
					                       GET_ID(extStratLnkPtr, ExtStratLnk_GridId),
					                       instrId,
                                           instrPtr,
                                           0,
                                           TRUE,
                                           classifStack,
										   NULL,
                                           FALSE,
										   m3SDepthLevel, /* REF8834 - CHU - 031119 */
										   TRUE, /* PMSTA08737 - LJE - 091223 */
                                           NULL,
                                           selOptions,
                                           connectNo,
										   &OverrideApplForInstr)) != 0)
	{
		OBJECT_ENUM domMktSgtObject=NullEntity; /* REF7264 - LJE - 020128 */

	    /* Search a strategy link with same market segment in next level */
	    if ((childLnkTab = GET_EXTENSION_PTR(extStratLnkPtr, ExtStratLnk_Child_ExtStratLnk_Ext)) != NULL)
        {
	  		childLnkNbr = GET_EXTENSION_NBR(extStratLnkPtr, ExtStratLnk_Child_ExtStratLnk_Ext);
        }
	    else
        {
			childLnkNbr = 0;
        }

		if(childLnkNbr > 1)
		{
			/*Core Satellite */
		   TLS_Sort((char *) childLnkTab, childLnkNbr, sizeof(DBA_DYNFLD_STP),
					(TLS_CMPFCT *)FIN_CmpESLReconcOK, (PTR **) NULL, SortRtnTp_None);
		}
        /* REF4047 - 000121 - SKE */
        if (domainPtr != NULLDYNST)
        {
        /**/
	        /* REF3641 - Don't try to set cash in child, because of they will go in "other" mktSgt */
	        if (IS_NULLFLD(domainPtr, A_Domain_DimInstrDictId) == FALSE)
	        {
		        DBA_GetObjectEnum(GET_DICT(domainPtr, A_Domain_DimInstrDictId), &domMktSgtObject);

		        if (GET_ENUM(instrPtr, A_Instr_NatEn) == InstrNat_CashAcct)
                {
		            childLnkNbr = 0;
                }
	        }
        }

	    for (i=0; i<childLnkNbr; i++)
	    {
			if (GET_ID(childLnkTab[i], ExtStratLnk_MktSegId) == mktSegtId)
			{
				/* If there is a substrategy linked to this */
				/* market segment, repeat the process.      */
				if (((STRATNAT_ENUM) GET_ENUM(childLnkTab[i], ExtStratLnk_StratNatEn) == StratNat_Alloc     ||
                     /* REF4047 - 000121 - SKE : or model or recommendation */
                     (STRATNAT_ENUM) GET_ENUM(childLnkTab[i], ExtStratLnk_StratNatEn) == StratNat_ModelPtf  ||
                     (STRATNAT_ENUM) GET_ENUM(childLnkTab[i], ExtStratLnk_StratNatEn) == StratNat_RecomList) &&
					 IS_NULLFLD(childLnkTab[i], ExtStratLnk_GridId) == FALSE)
				{
					return(FIN_SetInstrInStratHier(stratHierHead,
                                                   domainPtr,
                                                   childLnkTab[i],
                                                   crtPos,
                                                   instrPtr,
                                                   mktSegtIdPtr,
                                                   classifStack,
                                                   selOptions,
                                                   connectNo,
												   m3SDepthLevel)); /* REF8834 - CHU - 031119 */
				}
				else
				{
                    /* PMSTA-40516 - vkumar - 110620 */
                    /* If overlay processing, then skip Model ESL with overlay portfolio ID as these
                       should not be considered for mapping positions belonging to a market segment
                       for TAA and Standard IP scenario */
                    if (DictFct_ReconcStrat == GET_DICT(domainPtr, A_Domain_FctDictId) &&
                        REBAL_METHOD_ENUM::Default != static_cast<REBAL_METHOD_ENUM>GET_ENUM(domainPtr, A_Domain_RebalMethodEn) &&
                        FALSE == IS_NULLFLD(childLnkTab[i], ExtStratLnk_OverlayPtfId))
                    {
                        continue;
                    }

                    /*check if there are any submodel linked to the instrument*/
                    /*should this be placed after multi level flag checking ??*/
                    if ((subMPChildTab = GET_EXTENSION_PTR(extStratLnkPtr, ExtStratLnk_Child_ExtStratLnk_Ext)) != NULL)
                    {
                        subMPChildNbr = GET_EXTENSION_NBR(extStratLnkPtr, ExtStratLnk_Child_ExtStratLnk_Ext);
                    }
                    else
                    {
                        subMPChildNbr = 0;
                    }

                    for (int childCnt = 0; childCnt < subMPChildNbr; childCnt++)
                    {
                        /* PMSTA-40516 - vkumar - 110620 */
                        /* If overlay processing, then skip Model ESL with overlay portfolio ID as these
                           should not be considered for mapping positions belonging to a market segment
                           for TAA and Standard IP scenario */
                        if (GET_ENUM(subMPChildTab[childCnt], ExtStratLnk_StratNatEn) != StratNat_ModelPtf ||
                            (DictFct_ReconcStrat == GET_DICT(domainPtr, A_Domain_FctDictId) &&
                             REBAL_METHOD_ENUM::Default != static_cast<REBAL_METHOD_ENUM>GET_ENUM(domainPtr, A_Domain_RebalMethodEn) &&
                             FALSE == IS_NULLFLD(subMPChildTab[childCnt], ExtStratLnk_OverlayPtfId)))
                            continue;

						/* PMSTA-48148-SENTHIL-03032022 */
						ENUM_T          applMarketstructEnum;
						GEN_GetApplInfo(ApplMarketStructureattribEnum, &applMarketstructEnum);
						if (applMarketstructEnum == 1 && OverrideApplForInstr==TRUE)
							continue;

                        subModelEsl = FIN_SearchInstrInMPElements(stratHierHead, domainPtr, subMPChildTab[childCnt], instrId);

                        if (subModelEsl != NULLDYNST )
                        {
                            /*if there are any submodel then try linking instrument to that ESL*/
                            return(FIN_SetInstrInStratHier(stratHierHead,
                                domainPtr,
                                subModelEsl,
                                crtPos,
                                instrPtr,
                                mktSegtIdPtr,
                                classifStack,
                                selOptions,
                                connectNo,
                                m3SDepthLevel)); /* REF8834 - CHU - 031119 */
                        }
                    }

                    if (TRUE != GET_FLAG(domainPtr, A_Domain_MultiLvlModelMgmtFlg) || GET_ENUM(childLnkTab[i], ExtStratLnk_StratNatEn) == StratNat_SwitchInstr)
                    {
                        /*Continue existing functionality of setting instrument under MP even if Instrument 
                            is not set in MP, if Multi level Model is not is not used*/
                        *mktSegtIdPtr = mktSegtId;
                        return(childLnkTab[i]);
                    }

                    /*Changes to move instrument outside MP to be linked to Allocation instead of  
                      current behavior of linking with MP*/
                    /*Find if the instrument is available in the ESL */
                    /*PMSTA-37729 - Vishnu - 24122019*/
                    DBA_DYNFLD_STP  stratHistPtr = NULLDYNSTPTR;
                    
                    *mktSegtIdPtr = mktSegtId;
                    if (GET_EXTENSION_PTR(childLnkTab[i], ExtStratLnk_A_StratHist_Ext) != NULL &&
                        (stratHistPtr = *(GET_EXTENSION_PTR(childLnkTab[i], ExtStratLnk_A_StratHist_Ext))) != NULLDYNST)
                    {
                            DBA_DYNFLD_STP *stratEltTab = GET_EXTENSION_PTR(stratHistPtr, A_StratHist_A_StratElt_Ext);
                            int             stratEltNbr = GET_EXTENSION_NBR(stratHistPtr, A_StratHist_A_StratElt_Ext);;
                            /*Looping Start Hist for instrument */
                            for (int j = 0; j < stratEltNbr; j++)
                            {
                                if (GET_ID(stratEltTab[j], A_StratElt_InstrId) == instrId)
                                {
                                    /*Found the instrument in ESL*/
                                    return(childLnkTab[i]);
                                }
                            }                           
                    }
				}
			}
			/* REF3641 - In case of domain instrument, set cash in child model */
			/*
			else if (domMktSgtObject == Instr &&
					 GET_ENUM(childLnkTab[i], ExtStratLnk_StratNatEn) == StratNat_ModelPtf &&
					 GET_ENUM(instrPtr, A_Instr_NatEn) == InstrNat_CashAcct)
			{
				*mktSegtIdPtr = mktSegtId;
				return(childLnkTab[i]);
			}
			*/
	    }

	    /* Nothing found return parent*/
	    *mktSegtIdPtr = mktSegtId;
	    return(extStratLnkPtr);
	}
	else
    {
		/* REF7337 - RAK - 020813 */
		/* No check to do ... return current ESL */
	    /* return(NULLDYNST); */
		return(extStratLnkPtr);
    }
}



/************************************************************************
**
**  Function    :   FIN_IsInListCompoAtDate()
**
**  Description :   Search in list compo if an object is present at a date
**
**  Arguments   :   domainPtr           domain structure pointer
**                  hierHead            position hierarchy header pointer
**                  extractListCompoTab list compo extract from hier.
**                  listCompoNbr        Number of list compo
**                  dimPtfObjectEnum    List, Ptf, Instr, Curr, Third
**                  testIdFld           the id of the object search
**
**  Return      :   TRUE if the object is present, else FALSE
**
**  Creation    :   REF7318 - LJE - 020122
**  Modification:
**
*************************************************************************/
FLAG_T FIN_IsInListCompoAtDate(DBA_DYNFLD_STP    domainPtr,
							   DBA_HIER_HEAD_STP hierHead,
							   ID_T              listId,
							   DICT_T            dimEntDictId,
							   DBA_DYNFLD_STP    testObj,
							   int               destIdFld,
							   DATETIME_T        *dateTestPtr,
							   DBA_DYNFLD_STP    **extractListCompoTabPtr,
							   int               *listCompoNbrPtr,
							   int		         connectNo,
							   int               selOptions)
{

	int i=0, j;
    DBA_DYNFLD_STP   aPtfSt = NULLDYNST;
	DBA_DYNFLD_STP   *ptfTab, *childrenPtfTab;
	DBA_DYNFLD_STP   admArg=NULLDYNST;
	int              ptfNbr;
	DBA_DYNFLD_ST    ptfIdDynSt;
	OBJECT_ENUM      dimObjectEnum;

	memset(&ptfIdDynSt, 0, sizeof(DBA_DYNFLD_ST)); /* REF7264 - LJE - 020128 */

	if(extractListCompoTabPtr == NULL)
		return FALSE;

	DBA_GetObjectEnum(dimEntDictId, &dimObjectEnum);

	if(*extractListCompoTabPtr == NULL)
	{
		/* Allocate memory */
        if ((admArg = ALLOC_DYNST(Adm_Arg)) == NULLDYNST)
        {
            MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "Adm_Arg");
            return(FALSE);
        }

		SET_DICT(admArg, Adm_Arg_EntDictId, dimEntDictId);
		SET_ID(admArg, Adm_Arg_Id, listId);


		if(dateTestPtr == NULL)
		{
		    SET_NULL_DATE(admArg, Adm_Arg_Date);
		}
		else
		{
		    SET_DATETIME(admArg, Adm_Arg_Date, *dateTestPtr);
		}

		/* Search lists compo valid on the dateTest */
		if(DBA_Select2(ListCompo, UNUSED, Adm_Arg, admArg,
					  S_ListCompo, extractListCompoTabPtr,
					  selOptions, UNUSED, listCompoNbrPtr, &connectNo, UNUSED) != RET_SUCCEED)
		{
			FREE_DYNST(admArg, Adm_Arg);
		    return FALSE;
		}

		FREE_DYNST(admArg, Adm_Arg);
	}


    while(i < *listCompoNbrPtr)
    {

		if ( GET_ID(testObj,destIdFld) == GET_ID((*extractListCompoTabPtr)[i], S_ListCompo_ObjId)
		  && IS_NULLFLD(testObj,destIdFld) == IS_NULLFLD((*extractListCompoTabPtr)[i], S_ListCompo_ObjId))
		{
			return (TRUE);
		}

        /* if load_hierarchy_flag has been set to true */
        if (GET_ENUM(domainPtr, A_Domain_LoadHierFlg) > LoadHierPtf_None &&
            dimObjectEnum == Ptf)
        {

            /* set the index key */
            SET_ID((&ptfIdDynSt), 0, GET_ID((*extractListCompoTabPtr)[i], S_ListCompo_ObjId));
            /* extract from hierarchy the portfolio which id is the current list compo object_id */
            if ((DBA_ExtractHierEltRecByIndexKey(hierHead, A_Ptf, A_Ptf_Id,
                                                       ptfIdDynSt, FALSE, NULL, NULLDYNST, NULL, FALSE,
                                                       &ptfNbr, &ptfTab)) != RET_SUCCEED)
	        {
                FREE(ptfTab);
		        return(FALSE);
	        }

            if (ptfNbr > 0)
            {
                aPtfSt = ptfTab[0];

                /* is it a father portfolio ? */
                childrenPtfTab = (DBA_DYNFLD_STP *)GET_EXTENSION_PTR(
                                                        aPtfSt, A_Ptf_ChildrenPtf_Ext);
                if (childrenPtfTab !=  NULLDYNSTPTR)
                {
                    /* create a A_PtfFreq for each child */
                    for (j = 0; j<GET_EXTENSION_NBR(aPtfSt, A_Ptf_ChildrenPtf_Ext); j++)
                    {
						if ( GET_ID(testObj,destIdFld) == GET_ID(childrenPtfTab[j], A_Ptf_Id)
						  && IS_NULLFLD(testObj,destIdFld) == IS_NULLFLD(childrenPtfTab[j], A_Ptf_Id))
						{
							FREE(ptfTab);
							return(TRUE);
						}
                    }
                }

                FREE(ptfTab);
            }
        }
        i++;
    }

	return(FALSE);
}


/************************************************************************
**
**  Function    :   FIN_SearchInstrChronoEltInTab()
**
**  Description :   Search an valid InstrChrono in an array.
**
**  Arguments   :   chronoTab  : array of Instrhronos (sorted by valid date asc)
**                  chronoNb   : number of element in array
**                  searchDate : date of chrono we want
**                  chronoPtr  : pointer on InstrChrono
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   REF7061 - TEB - 030123
**  Modification:
*************************************************************************/
STATIC int FIN_SearchInstrChronoEltInTab(DBA_DYNFLD_STP  *chronoTab,
                                         int             chronoNb,
                                         DATETIME_T      searchDate,
                                         DBA_DYNFLD_STP  chronoPtr)
{
    int i=0;

    if ( DATETIME_CMP(GET_DATETIME(chronoTab[0], Freq_InstrChrono_ValidDate), searchDate)>0 )
        return(RET_GEN_INFO_NODATA);

    while (i<chronoNb && DATETIME_CMP(GET_DATETIME(chronoTab[i], Freq_InstrChrono_ValidDate), searchDate)<=0 )
        i++;

    COPY_DYNST(chronoPtr, chronoTab[i-1], Freq_InstrChrono);

    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_SearchPtfChronoEltInTab()
**
**  Description :   Search an valid PtfChrono in an array.
**
**  Arguments   :   chronoTab  : array of PtfChronos (sorted by valid date asc)
**                  chronoNb   : number of element in array
**                  searchDate : date of chrono we want
**                  chronoPtr  : pointer on PtfChrono
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   REF7061 - TEB - 030123
**  Modification:
*************************************************************************/
STATIC int FIN_SearchPtfChronoEltInTab(DBA_DYNFLD_STP  *chronoTab,
                                         int            chronoNb,
                                         DATETIME_T     searchDate,
                                         DBA_DYNFLD_STP chronoPtr)
{
    int i=0;

    if ( DATETIME_CMP(GET_DATETIME(chronoTab[0], Freq_PtfChrono_ValidDate), searchDate)>0 )
        return(RET_GEN_INFO_NODATA);

    while (i<chronoNb && DATETIME_CMP(GET_DATETIME(chronoTab[i], Freq_PtfChrono_ValidDate), searchDate)<=0 )
        i++;

    COPY_DYNST(chronoPtr, chronoTab[i-1], Freq_PtfChrono);

    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_SearchListChronoEltInTab()
**
**  Description :   Search an valid ListChrono in an array.
**
**  Arguments   :   chronoTab  : array of ListChronos (sorted by valid date asc)
**                  chronoNb   : number of element in array
**                  searchDate : date of chrono we want
**                  chronoPtr  : pointer on ListChrono
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   REF7061 - TEB - 030123
**  Modification:
*************************************************************************/
STATIC int FIN_SearchListChronoEltInTab(DBA_DYNFLD_STP  *chronoTab,
                                         int             chronoNb,
                                         DATETIME_T      searchDate,
                                         DBA_DYNFLD_STP  chronoPtr)
{
    int i=0;

    if ( DATETIME_CMP(GET_DATETIME(chronoTab[0], Freq_ListChrono_ValidDate), searchDate)>0 )
        return(RET_GEN_INFO_NODATA);

    while (i<chronoNb && DATETIME_CMP(GET_DATETIME(chronoTab[i], Freq_ListChrono_ValidDate), searchDate)<=0 )
        i++;

    COPY_DYNST(chronoPtr, chronoTab[i-1], Freq_ListChrono);

    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_SearchThirdChronoEltInTab()
**
**  Description :   Search an valid ThirdChrono in an array.
**
**  Arguments   :   chronoTab  : array of ThirdChronos (sorted by valid date asc)
**                  chronoNb   : number of element in array
**                  searchDate : date of chrono we want
**                  chronoPtr  : pointer on ThirdChrono
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   REF7061 - TEB - 030123
**  Modification:
*************************************************************************/
STATIC int FIN_SearchThirdChronoEltInTab(DBA_DYNFLD_STP  *chronoTab,
                                         int             chronoNb,
                                         DATETIME_T      searchDate,
                                         DBA_DYNFLD_STP  chronoPtr)
{
    int i=0;

    if ( DATETIME_CMP(GET_DATETIME(chronoTab[0], Freq_ThirdChrono_ValidDate), searchDate)>0 )
        return(RET_GEN_INFO_NODATA);

    while (i<chronoNb && DATETIME_CMP(GET_DATETIME(chronoTab[i], Freq_ThirdChrono_ValidDate), searchDate)<=0 )
        i++;

    COPY_DYNST(chronoPtr, chronoTab[i-1], Freq_ThirdChrono);

    return(RET_SUCCEED);
}


/************************************************************************
**
**  Function    :   FIN_UnderPriceList()
**
**  Description :   Search prices at determined frequency
**
**  Arguments   :   instrPtr    pointer on instrument
**                  advAVolaStp pointer on arguments structure (AdvA_Vola)
**                  priceTab    pointer on prices array to update
**                  priceNbr    pointer on prices number to update
**
**
**  Return      :   RET_SUCCEED           valuation rule ValRule_Quote and
**                                        prices found
**		            RET_DBA_ERR_NODATA    valuation rule ValRule_Quote and
**                                        prices not found
**	                RET_GEN_INFO_NOACTION valuation rule ValRule_Quote1
**	                RET_GEN_ERR_NOACTION  valuation rule not treated (tempo)
**                                        or error code
**
**  Modif       :   BUG332 - RAK - 970410
**  Modif	    :   REF1894 - RAK - 980423
**
*************************************************************************/
STATIC RET_CODE	FIN_UnderPriceList(DBA_DYNFLD_STP instrPtr,
				                   DBA_DYNFLD_STP advAVolaStp,
				                   DBA_DYNFLD_STP **priceTab,
				                   int            *priceNbr,
                    		       DBA_HIER_HEAD_STP hierHead)
{
	DBA_DYNFLD_STP    *freqPriceTab=(DBA_DYNFLD_STP*)NULL;
	DATETIME_T        tillD;
	ID_T              instrId;
	int               i, freqPriceNbr;
	RET_CODE          ret;

	*priceNbr = 0;

	tillD.date = GET_DATE(advAVolaStp, AdvA_Vola_RefDate);
	tillD.time = 0;

	if (GET_ID(instrPtr, A_Instr_Id) < 0)
	{
		instrId = GET_ID(instrPtr, A_Instr_ParentInstrId);
	}
	else
	{
		instrId = GET_ID(instrPtr, A_Instr_Id);
	}

	/* BUG332 - RAK - 970410 */
	if ((ret = DBA_InstrPriceByFreq(tillD,
									GET_TINYINT(advAVolaStp, AdvA_Vola_HistoFreq),
					                (FREQUNIT_ENUM) GET_ENUM(advAVolaStp, AdvA_Vola_HistoFreqUnitEn),
	                                GET_INT(advAVolaStp, AdvA_Vola_HistoReading),
					                instrId,
									instrPtr,
									GET_ID(instrPtr, A_Instr_RefCurrId),
		                            0,
									NULLDYNST,
									NULLDYNST,
									MissingDataMethod_LastValid, /* REF7061 - TEB - 030123*/
		                            &freqPriceTab,
									&freqPriceNbr,
									hierHead,
                                    ZERO_ID)) != RET_SUCCEED)   /*  PMSTA - 32764 - SILPA - 181010   */
	{
		return(ret);
	}

	if ((*priceTab = (DBA_DYNFLD_STP*)CALLOC(freqPriceNbr, sizeof(DBA_DYNFLD_STP))) == (DBA_DYNFLD_STP*)NULL)
	{
		DBA_FreeDynStTab(freqPriceTab, freqPriceNbr, Freq_InstrPrice);
		MSG_RETURN(RET_MEM_ERR_ALLOC);
	}

	/* Return only valid prices (not NULL) */
	for (i=0; i<freqPriceNbr; i++)
	{
	    /* REF1894 - Don't read (*priceTab)[i] if it's not allocated. */
	    if (freqPriceTab[i] != NULLDYNST &&
		    IS_NULLFLD(freqPriceTab[i], Freq_InstrPrice_Price) == FALSE)
	    {
		    if (((*priceTab)[*priceNbr] = ALLOC_DYNST(Freq_InstrPrice)) == NULLDYNST)
		    {
		        DBA_FreeDynStTab(freqPriceTab, freqPriceNbr, Freq_InstrPrice);
		        FREE(*priceTab);
		        MSG_RETURN(RET_MEM_ERR_ALLOC);
		    }

		    COPY_DYNST((*priceTab)[*priceNbr], freqPriceTab[i], Freq_InstrPrice);
		    ++(*priceNbr);
	    }
	}

	DBA_FreeDynStTab(freqPriceTab, freqPriceNbr, Freq_InstrPrice);
	return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_UnderExchRateList()
**
**  Description :   Search rates between underly and option currencies at
**                  determined frequency
**
**  Arguments   :   sysCurrId   system curreny identifier
**                  underCurrId underlying curreny identifier
**                  optCurrId   option curreny identifier
**                  advAVolaStp pointer on arguments structure (AdvA_Vola)
**                  exchTab     pointer on rates array to update
**                  exchNbr     pointer on rates number to update
**
**  Return      :   RET_SUCCEED or error code
**
**  Modif	    :   BUG332 - RAK - 970410
**  Modif	    :   REF1894 - RAK - 980423
**
*************************************************************************/
STATIC RET_CODE FIN_UnderExchRateList(ID_T           underCurrId,
				                      ID_T           optCurrId,
				                      DBA_DYNFLD_STP advAVolaStp,
				                      DBA_DYNFLD_STP **exchTab,
				                      int            *exchNbr)
{
	DBA_DYNFLD_STP    *freqExchTab=(DBA_DYNFLD_STP*)NULL;
	DATETIME_T        tillD;
	int               i, freqExchNbr;
	RET_CODE          ret;

	*exchNbr = 0;

	tillD.date = GET_DATE(advAVolaStp, AdvA_Vola_RefDate);
	tillD.time = 0;

	/* BUG332 - RAK - 970410 */
	if ((ret = DBA_ExchRateByFreq(tillD,
								  GET_TINYINT(advAVolaStp, AdvA_Vola_HistoFreq),
				                  (FREQUNIT_ENUM) GET_ENUM(advAVolaStp, AdvA_Vola_HistoFreqUnitEn),
		                          GET_INT(advAVolaStp, AdvA_Vola_HistoReading),
								  underCurrId,
				                  optCurrId,
								  0,
								  NULLDYNST,
								  MissingDataMethod_LastValid, /* REF7061 - TEB - 030123*/
                                  &freqExchTab,
								  &freqExchNbr)) != RET_SUCCEED)
	{
		return(ret);
	}

	/* Return only valid rates (not NULL) */
	if ((*exchTab = (DBA_DYNFLD_STP*)CALLOC(freqExchNbr, sizeof(DBA_DYNFLD_STP))) == (DBA_DYNFLD_STP*)NULL)
	{
		DBA_FreeDynStTab(freqExchTab, freqExchNbr, Freq_ExchRate);
		MSG_RETURN(RET_MEM_ERR_ALLOC);
	}

	/* Return only valid prices (not NULL) */
	for (i=0; i<freqExchNbr; i++)
	{
	    /* REF1894 - Don't read (*priceTab)[i] if it's not allocated. */
	    if (freqExchTab[i] != NULLDYNST &&
		    IS_NULLFLD(freqExchTab[i], Freq_ExchRate_ExchRate) == FALSE)
	    {
		    if (((*exchTab)[*exchNbr] = ALLOC_DYNST(Freq_ExchRate)) == NULLDYNST)
		    {
		         DBA_FreeDynStTab(freqExchTab, freqExchNbr, Freq_ExchRate);
		         FREE(*exchTab);
		         MSG_RETURN(RET_MEM_ERR_ALLOC);
		    }

		    COPY_DYNST((*exchTab)[*exchNbr], freqExchTab[i], Freq_ExchRate);
		    ++(*exchNbr);
	    }
	}

	DBA_FreeDynStTab(freqExchTab, freqExchNbr, Freq_ExchRate);
	return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_CompEstVol()
**
**  Description :   This function computes the estimated volatility
**                  for a given array (priceTab) of priceNbr prices
**
**  Arguments   :   priceTab  pointer on array of prices
**                  priceNbr  number of prices
**		        :   estVol    pointer to output estmated volatility
**
**  Return      :   TRUE or FALSE
**
**  Creation    :   REF10531 - TEB - 040806
**
**  Modif       :
**
*************************************************************************/
STATIC int FIN_CompEstVol(double    *priceTab,
						  int		priceNbr,
						  double	*estVol)
{
	DBA_DYNFLD_STP statPtr;
	RET_CODE       ret=RET_SUCCEED;
	double         *lnPriceTab=(double*)NULL;
	int			   i;

	/* Coherence test */
	if (priceNbr < 3 ||
		priceTab[0] == 0.0)
	{
		return(FALSE);
	}

	/* Allocation */
	if ((statPtr = ALLOC_DYNST(A_Stat)) == NULLDYNST)
	{
		MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
		return(FALSE);
	}

	if ((lnPriceTab = (double *) CALLOC(priceNbr-1, sizeof(double)))==(double*)NULL)
	{
		MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
		FREE_DYNST(statPtr, A_Stat);
		return(FALSE);
	}

	/* Construction of ln(price[i]/price[i-1]) */
	for(i=1; i<priceNbr; i++)
	{
		if (priceTab[i] == 0 )
		{
			FREE(lnPriceTab);
			FREE_DYNST(statPtr, A_Stat);
			return(FALSE);
		}

		lnPriceTab[i-1] = log(priceTab[i]/priceTab[i-1]);
	}

	/* Computation */
	if (ret == RET_SUCCEED &&
		(ret=FIN_CalcStat(lnPriceTab, priceNbr-1, statPtr)) == RET_SUCCEED)
	{
		*estVol = GET_NUMBER(statPtr, A_Stat_Variance); /* Moi j aurais dit deviation, mais bon... c FBA le financier */
		*estVol = sqrt(*estVol);	/* REF10531 - TEB - 041209 */
	}

	FREE(lnPriceTab);
	FREE_DYNST(statPtr, A_Stat);
	return((ret==RET_SUCCEED)?TRUE:FALSE);
}

/************************************************************************
**
**  Function    :   FIN_ForceComputeInstrChrono()
**
**  Description :   This function computes check if priority must givernt to compute or to instr_chrono table.
**
**  Arguments   :   instrPtr  pointer on instrument to check
**                  chronoNat nature of chrono for which check must be done
**
**  Return      :   TRUE or FALSE
**
**  Creation    :   PMSTA14879 - DDV - 120920
**
**  Modif       :
**
*************************************************************************/
STATIC FLAG_T FIN_ForceComputeInstrChrono(DBA_DYNFLD_STP instrPtr,
										  CHRONONAT_ENUM chronoNat)
{
    INSTRNAT_ENUM   instrNatInstr = InstrNat_None;
	FLAG_T          forceComputeInstrChrono = FALSE;

	GEN_GetApplInfo(ApplForceComputeInstrChrono, &forceComputeInstrChrono);

	instrNatInstr = (INSTRNAT_ENUM)GET_ENUM(instrPtr, A_Instr_NatEn);

	if (forceComputeInstrChrono == TRUE &&
		InstrNat_FundShare != instrNatInstr && InstrNat_Idx  != instrNatInstr)
	{
		if (chronoNat == ChronoNat_ModDura ||
		    chronoNat == ChronoNat_Dura ||
		    chronoNat == ChronoNat_Convexity ||
		    chronoNat == ChronoNat_YieldToMaturity)
		{
			return(TRUE);
		}
	}

	return(FALSE);
}

/************************************************************************
*
*  Function          : FIN_CompComplChrono()
*
*  Description       : this function computes compliance chronological data
*
*  Arguments         : compComplChronoSt : dynamic structure A_CompComplChrono
*
*  Return            : RET_SUCCEED
*
*  Creation date     : PMSTA-18426 - CHU - 141028
*
************************************************************************/
RET_CODE FIN_CompComplChrono(DBA_DYNFLD_STP compComplChronoSt)
{
	OBJECT_ENUM     dimObject;
	DBA_DYNFLD_STP  aEntityChrono;
	DBA_DYNFLD_STP  *ioIdTab;
	DBA_DYNFLD_STP  sEntityChrono;
	DBA_DYNFLD_STP  admArg;
	DBA_ACCESS_STP  accessTab;
	int             cpt, i, dataNbr;
	DBA_ACTION_ENUM action=NullAction;
    SCPT_DFLTVAL_STP dfltValStPtr;
	FLAG_T          *forcedFlgTab;
	RET_CODE        ret;
	COMPCHRONONAT_ENUM currIndicator = CompChronoNat_None;
	int				indicatorIdx;
	int				firstIndicator = CompChronoNat_None + 1;
	int				lastIndicator  = CompChronoNat_Last;

	DBA_GetObjectEnum(GET_DICT(compComplChronoSt, A_CompComplChrono_EntDictId), &dimObject);
	if (dimObject != List && dimObject != Ptf && dimObject != Strat)
		return(RET_GEN_ERR_INVARG);

	if ((COMPCHRONONAT_ENUM)GET_ENUM(compComplChronoSt, A_CompComplChrono_NatEn) == CompChronoNat_None) /* All */
	{
		firstIndicator = CompChronoNat_None + 1;
		lastIndicator  = CompChronoNat_Last;
	}
	else
	{
		firstIndicator = (int)GET_ENUM(compComplChronoSt, A_CompComplChrono_NatEn);
		lastIndicator  = (int)GET_ENUM(compComplChronoSt, A_CompComplChrono_NatEn) + 1;
	}

	for (indicatorIdx = firstIndicator; indicatorIdx < lastIndicator; indicatorIdx++)
	{
		currIndicator = (COMPCHRONONAT_ENUM)indicatorIdx;

		switch(GET_FLAG(compComplChronoSt, A_CompComplChrono_DeleteFlg))
		{
		case FALSE:                     /* Chronological data must be inserted/updated */
			if (dimObject == Ptf || dimObject == Strat)
			{
				aEntityChrono = ALLOC_DYNST(A_ComplianceChrono);

				if (dimObject == Ptf)
				{
					SET_ID(aEntityChrono,		A_ComplianceChrono_PtfId,		GET_ID(compComplChronoSt,		A_CompComplChrono_ObjId));
				}
				else /* dimObject == Strat */
				{
					SET_ID(aEntityChrono,		A_ComplianceChrono_StratId,		GET_ID(compComplChronoSt,		A_CompComplChrono_ObjId));
				}

				SET_ENUM(aEntityChrono,		A_ComplianceChrono_NatEn,				currIndicator);
				SET_NUMBER(aEntityChrono,	A_ComplianceChrono_ConfidenceLevel,		GET_NUMBER(compComplChronoSt,	A_CompComplChrono_ConfidenceLevel));
				SET_TINYINT(aEntityChrono,	A_ComplianceChrono_TimeHorizon,			GET_TINYINT(compComplChronoSt,	A_CompComplChrono_TimeHorizon));
				SET_ENUM(aEntityChrono,		A_ComplianceChrono_TimeHorizonUnitEn,	GET_ENUM(compComplChronoSt,		A_CompComplChrono_TimeHorizonUnitEn));
				SET_DATETIME(aEntityChrono,	A_ComplianceChrono_ValidDate,			GET_DATETIME(compComplChronoSt,	A_CompComplChrono_CalcDate));
				SET_ENUM(aEntityChrono,		A_ComplianceChrono_CompNatEn,			CompChronoCompNat_Measure);	/* PMSTA-19135 - CHU - 141205 */
				SET_ENUM(aEntityChrono,		A_ComplianceChrono_CriticalnessEn,		ConstrCriticalness_None);		/* PMSTA-19135 - CHU - 141205 */

				forcedFlgTab = (unsigned char *)CALLOC(GET_FLD_NBR(A_ComplianceChrono), sizeof(FLAG_T)); /* REF7264 - LJE - 020128 */
				SCPT_InitEntityDefVal(ComplianceChrono, &dfltValStPtr, FALSE, 0);

				/* Fix the values of forced fields */
				forcedFlgTab[A_ComplianceChrono_PtfId]             = TRUE;
				forcedFlgTab[A_ComplianceChrono_NatEn]             = TRUE;
				forcedFlgTab[A_ComplianceChrono_ConfidenceLevel]   = TRUE;
				forcedFlgTab[A_ComplianceChrono_TimeHorizon]       = TRUE;
				forcedFlgTab[A_ComplianceChrono_TimeHorizonUnitEn] = TRUE;
				forcedFlgTab[A_ComplianceChrono_ValidDate]         = TRUE;

				SCPT_AnalyseEntityDefVal(dfltValStPtr,
										 forcedFlgTab,
                                         NULL,              /* HFI-PMSTA-25327-171023  Dedicated flag tab for filter    */
										 aEntityChrono,
										 TRUE,
										 EvalType_DefVal,
										 NULL,
										 NULL,
										 FALSE);
				SCPT_FreeEntityDefVal(dfltValStPtr);

				if (IS_NULLFLD(aEntityChrono, A_ComplianceChrono_Val) == TRUE)
				{
					FREE(forcedFlgTab);
					FREE_DYNST(aEntityChrono, A_ComplianceChrono);
					/* return(RET_SUCCEED); */
					continue; /* PMSTA-18739 - CHU - 141210 */
				}

				switch(GET_FLAG(compComplChronoSt, A_CompComplChrono_ForceFlg))
				{
				case FALSE:               /* An Insert action must be executed */
					DBA_Insert2(ComplianceChrono, UNUSED, A_ComplianceChrono, aEntityChrono, UNUSED, UNUSED, UNUSED);
					break;

				case TRUE:                        /* An Insert/Update action must be executed */
					ret = DBA_Insert2(ComplianceChrono, UNUSED, A_ComplianceChrono, aEntityChrono, UNUSED, UNUSED, UNUSED);
					if (ret == RET_SRV_LIB_ERR_DUPLICATEKEY)
						DBA_Update2(ComplianceChrono, UNUSED, A_ComplianceChrono, aEntityChrono, UNUSED, UNUSED, UNUSED);
					break;
				}
				FREE_DYNST(aEntityChrono, A_ComplianceChrono);
				FREE(forcedFlgTab);
			}
			else if (dimObject == List)
			{
				admArg = ALLOC_DYNST(Adm_Arg);
				DBA_SelectByListId(GET_ID(compComplChronoSt, A_CompComplChrono_ObjId),
								   Ptf,     UNUSED,
								   Adm_Arg, admArg,
								   Io_Id,   &ioIdTab,
								   UNUSED,  UNUSED,
								   &dataNbr,UNUSED);
				FREE_DYNST(admArg, Adm_Arg);

				if (dataNbr <= 0)
					return(RET_SUCCEED);

				accessTab = (DBA_ACCESS_STP)CALLOC(dataNbr, sizeof(DBA_ACCESS_ST));

				switch(GET_FLAG(compComplChronoSt, A_CompComplChrono_ForceFlg))
				{
				case FALSE:
					action = Insert;
					break;
				case TRUE:
					action = InsUpd;
					break;
				}

				forcedFlgTab = (unsigned char *)CALLOC(GET_FLD_NBR(A_ComplianceChrono), sizeof(FLAG_T)); /* PMSTA-20224 - CHU - 150326 : wrong entity (was A_InstrChrono) */
				SCPT_InitEntityDefVal(ComplianceChrono, &dfltValStPtr, FALSE, 0);
				cpt = 0;

				aEntityChrono = ALLOC_DYNST(A_ComplianceChrono);
				/* Fix the values of forced fields */
				forcedFlgTab[A_ComplianceChrono_PtfId]             = TRUE;
				forcedFlgTab[A_ComplianceChrono_NatEn]             = TRUE;
				forcedFlgTab[A_ComplianceChrono_ConfidenceLevel]   = TRUE;
				forcedFlgTab[A_ComplianceChrono_TimeHorizon]       = TRUE;
				forcedFlgTab[A_ComplianceChrono_TimeHorizonUnitEn] = TRUE;
				forcedFlgTab[A_ComplianceChrono_ValidDate]         = TRUE;

				for (i=0 ; i<dataNbr ; i++)
				{
					SET_ID(aEntityChrono,		A_ComplianceChrono_PtfId,				GET_ID(ioIdTab[i],				Io_Id_Id));
					SET_ENUM(aEntityChrono,		A_ComplianceChrono_NatEn,				currIndicator);
					SET_NUMBER(aEntityChrono,	A_ComplianceChrono_ConfidenceLevel,		GET_NUMBER(compComplChronoSt,	A_CompComplChrono_ConfidenceLevel));
					SET_TINYINT(aEntityChrono,	A_ComplianceChrono_TimeHorizon,			GET_TINYINT(compComplChronoSt,	A_CompComplChrono_TimeHorizon));
					SET_ENUM(aEntityChrono,		A_ComplianceChrono_TimeHorizonUnitEn,	GET_ENUM(compComplChronoSt,		A_CompComplChrono_TimeHorizonUnitEn));
					SET_DATETIME(aEntityChrono,	A_ComplianceChrono_ValidDate,			GET_DATETIME(compComplChronoSt,	A_CompComplChrono_CalcDate));
					SET_ENUM(aEntityChrono,		A_ComplianceChrono_CompNatEn,			CompChronoCompNat_Measure);	/* PMSTA-19135 - CHU - 141205 */
					SET_ENUM(aEntityChrono,		A_ComplianceChrono_CriticalnessEn,		ConstrCriticalness_None);		/* PMSTA-19135 - CHU - 141205 */

					SCPT_AnalyseEntityDefVal(dfltValStPtr,
											 forcedFlgTab,
                                             NULL,              /* HFI-PMSTA-25327-171023  Dedicated flag tab for filter    */
											 aEntityChrono,
											 TRUE,
											 EvalType_DefVal,
											 NULL,
											 NULL,
											 FALSE);

					if (IS_NULLFLD(aEntityChrono, A_ComplianceChrono_Val) == FALSE)
					{
						accessTab[cpt].action = action;
						accessTab[cpt].role   = UNUSED;
						accessTab[cpt].object = ComplianceChrono;
						accessTab[cpt].entity = A_ComplianceChrono;
						accessTab[cpt].data   = aEntityChrono;
						aEntityChrono         = ALLOC_DYNST(A_ComplianceChrono);
						cpt++;
					}
					FREE_DYNST(ioIdTab[i], Io_Id);
				}

				SCPT_FreeEntityDefVal(dfltValStPtr);
				FREE(ioIdTab);
				FREE(forcedFlgTab);

                {
                    DbaMultiAccessHelper       multiAccessHelper(accessTab, cpt);

				    ret = multiAccessHelper.callMultiAccess(200, UNUSED, UNUSED, true);

                    if (ret != RET_SUCCEED)
                    {
                        multiAccessHelper.sendAllMultiAccessMsg();
                    }
                }

                for (i=0 ; i<cpt ; i++)
				{
					FREE_DYNST(accessTab[i].data, A_ComplianceChrono);
				}
				FREE(accessTab);
			}
			break;

		case TRUE:                    /* Chronological data must be deleted */
			if (dimObject == Ptf || dimObject == Strat)
			{
				sEntityChrono = ALLOC_DYNST(S_ComplianceChrono);

				if (dimObject == Ptf)
				{
					SET_ID(sEntityChrono,		S_ComplianceChrono_PtfId,		GET_ID(compComplChronoSt,		A_CompComplChrono_ObjId));
				}
				else /* dimObject == Strat */
				{
					SET_ID(sEntityChrono,		S_ComplianceChrono_StratId,		GET_ID(compComplChronoSt,		A_CompComplChrono_ObjId));
				}

				SET_ENUM(sEntityChrono,		S_ComplianceChrono_NatEn,				currIndicator);
				SET_NUMBER(sEntityChrono,	S_ComplianceChrono_ConfidenceLevel,		GET_NUMBER(compComplChronoSt,	A_CompComplChrono_ConfidenceLevel));
				SET_TINYINT(sEntityChrono,	S_ComplianceChrono_TimeHorizon,			GET_TINYINT(compComplChronoSt,	A_CompComplChrono_TimeHorizon));
				SET_ENUM(sEntityChrono,		S_ComplianceChrono_TimeHorizonUnitEn,	GET_ENUM(compComplChronoSt,		A_CompComplChrono_TimeHorizonUnitEn));
				SET_DATETIME(sEntityChrono,	S_ComplianceChrono_ValidDate,			GET_DATETIME(compComplChronoSt,	A_CompComplChrono_CalcDate));
				SET_ENUM(sEntityChrono,		S_ComplianceChrono_CompNatEn,			CompChronoCompNat_Measure);	/* PMSTA-19135 - CHU - 141205 */

				DBA_Delete2(ComplianceChrono, UNUSED, S_ComplianceChrono, sEntityChrono, UNUSED, UNUSED, UNUSED);
				FREE_DYNST(sEntityChrono, S_ComplianceChrono);
			}
			else if (dimObject == List)
			{
				admArg = ALLOC_DYNST(Adm_Arg);
				SET_ID(admArg, Adm_Arg_Id, GET_ID(compComplChronoSt, A_CompComplChrono_ObjId));
				DBA_SelectByListId(GET_ID(compComplChronoSt, A_CompComplChrono_ObjId),
								   Ptf,     UNUSED,
								   Adm_Arg, admArg,
								   Io_Id,   &ioIdTab,
								   UNUSED,  UNUSED,
								   &dataNbr,UNUSED);
				FREE_DYNST(admArg, Adm_Arg);

				if (dataNbr <= 0)
					return(RET_SUCCEED);

				accessTab = (DBA_ACCESS_STP)CALLOC(dataNbr, sizeof(DBA_ACCESS_ST));	/* REF7264 - LJE - 020128 */
				for (i=0 ; i<dataNbr ; i++)
				{
					accessTab[i].action = Delete;
					accessTab[i].role   = UNUSED;
					accessTab[i].object = ComplianceChrono;
					accessTab[i].entity = S_ComplianceChrono;
					accessTab[i].data   = ALLOC_DYNST(S_ComplianceChrono);

					SET_ID(accessTab[i].data,		S_ComplianceChrono_PtfId,				GET_ID(ioIdTab[i],				Io_Id_Id));
					SET_ENUM(accessTab[i].data,		S_ComplianceChrono_NatEn,				currIndicator);
					SET_NUMBER(accessTab[i].data,	S_ComplianceChrono_ConfidenceLevel,		GET_NUMBER(compComplChronoSt,	A_CompComplChrono_ConfidenceLevel));
					SET_TINYINT(accessTab[i].data,	S_ComplianceChrono_TimeHorizon,			GET_TINYINT(compComplChronoSt,	A_CompComplChrono_TimeHorizon));
					SET_ENUM(accessTab[i].data,		S_ComplianceChrono_TimeHorizonUnitEn,	GET_ENUM(compComplChronoSt,		A_CompComplChrono_TimeHorizonUnitEn));
					SET_DATETIME(accessTab[i].data,	S_ComplianceChrono_ValidDate,			GET_DATETIME(compComplChronoSt,	A_CompComplChrono_CalcDate));
					SET_ENUM(accessTab[i].data,		S_ComplianceChrono_CompNatEn,			CompChronoCompNat_Measure);	/* PMSTA-19135 - CHU - 141205 */
					FREE_DYNST(ioIdTab[i], Io_Id);
				}
				FREE(ioIdTab);

                {
                    DbaMultiAccessHelper       multiAccessHelper(accessTab, dataNbr);

				    if (multiAccessHelper.callMultiAccess(200, UNUSED, UNUSED, true) != RET_SUCCEED)
                    {
                        multiAccessHelper.sendAllMultiAccessMsg();
                    }
                }

                for (i=0 ; i<dataNbr ; i++)
				{
					FREE_DYNST(accessTab[i].data, S_ComplianceChrono);
				}
				FREE(accessTab);
				FREE_DYNST(admArg, Adm_Arg);
			}
			break;
		}
	}
	return(RET_SUCCEED);
}

/************************************************************************
**      END  finlib04.c
*************************************************************************/

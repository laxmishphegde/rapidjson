/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef DATADEP_H
#define DATADEP_H

/************************************************************************
**      Constant & Macro definitions
*************************************************************************/

/************************************************************************
**      Structures & typedef definitions
*************************************************************************/

/************************************************************************
**      BEGIN External definitions attached to : datadep.c
*************************************************************************/

extern void SERV_StartThreadDataDep(std::string &);
extern void SERV_StopThreadDataDep(void);
extern bool SERV_IsThreadDataDepRunning();

extern void SERV_StartThreadSessionPurge(std::string &); /* PMSTA-22552 - CHU - 160617 */
extern void SERV_StopThreadSessionPurge(void);    /* PMSTA-22552 - CHU - 160617 */

extern void SERV_RpcShutdownWaitThreadDataDepSessionPurge();

ThreadState GET_ThreadSessionPurgeLoopState(void);
ThreadState GET_ThreadDataDepLoopState(void);

extern RET_CODE DBA_FreeObjModifStatNoSrv(DbiConnectionHelper &, DBA_DYNFLD_STP);

#endif

/************************************************************************
**      END        datadep.h                                   ODYSSEY **
*************************************************************************/

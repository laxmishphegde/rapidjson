/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef FINPERFA_H
#define FINPERFA_H

/************************************************************************
**      External Structure definitions
*************************************************************************/

/************************************************************************
**      Constant & Macro definitions
*************************************************************************/

/***********************************************************************
**      BEGIN External definitions attached to : finperfa1.c
*************************************************************************/

/* REF7758 - LJE - 020925 */
extern RET_CODE FIN_AnalysisPerfAnalysis(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP);

extern RET_CODE FIN_ComputeNewFromTillLinePAA(DBA_DYNFLD_STP,
                                              DBA_HIER_HEAD_STP,
                                              DBA_DYNST_ENUM,
                                              DBA_DYNFLD_STP,
                                              DATETIME_T,
                                              DATETIME_T,
                                              ID_T,
                                              FLAG_T, /* REF9770 - LJE - 031211 */
                                              DBA_DYNFLD_STP*);

extern RET_CODE FIN_CreateParentLinks(DBA_DYNFLD_STP,
                                      DBA_HIER_HEAD_STP,
                                      DBA_DYNST_ENUM,
                                      FIELD_IDX_T,
                                      FIELD_IDX_T, /* PMSTA08592 - LJE - 090824 */
                                      FIELD_IDX_T,
                                      FIELD_IDX_T,
                                      FIELD_IDX_T,
                                      FIELD_IDX_T,
                                      FIELD_IDX_T,
                                      int,
                                      int,
                                      DBA_DYNFLD_STP*);

/* REF10176 - LJE - 041124 */
extern RET_CODE FIN_GetDefaultCurrencyId(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, OBJECT_ENUM, ID_T, ID_T*);

/* REF11474 - LJE - 060201 */
extern int FIN_FilterGridObjectLnkPAA(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP),
           FIN_FilterStandardPerfGrid(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP);

/***********************************************************************
**      BEGIN External definitions attached to : finperfa2.c
*************************************************************************/

extern int FIN_FilterUnusedObjectLnk(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP);
extern int FIN_FilterUsedObjectLnk(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP);
extern int FIN_CmpObjectLnkToObjectId(DBA_DYNFLD_STP *, DBA_DYNFLD_STP *);
extern int FIN_CmpObjectLnkFromObjectId(DBA_DYNFLD_STP *, DBA_DYNFLD_STP *);
extern int FIN_FilterPtfFirstStoredCompPeriod(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP);
extern int FIN_FilterPtfFirstCompPeriod(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP);
extern int FIN_FilterFirstCompPeriod(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP);
extern int FIN_FilterHierFirstOpCompPeriod(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP);
extern int FIN_FilterPtfDbCompPeriod(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP);
extern int FIN_FilterDbCompPeriod(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP);
extern int FIN_FilterPtfDomainCompPeriod(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP);
extern int FIN_FilterDomainCompPeriod(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP);
extern int FIN_FilterPtfPerfCompPeriod(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP); /* PMSTA-50467 - JBC - 221112 */
extern int FIN_FilterPerfCompPeriod(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP); /* PMSTA-50467 - JBC - 221112 */
extern int FIN_FilterPerfCompPeriodForHier(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP); /* PMSTA-50467 - JBC - 221112 */
extern int FIN_FilterPerfCompPeriodForVirtual(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP); /* PMSTA-50467 - JBC - 221112 */
extern int FIN_CmpCompPeriodBeginDate(DBA_DYNFLD_STP *, DBA_DYNFLD_STP *);
extern int FIN_CmpCompPeriodByHierTechNatDt(DBA_DYNFLD_STP *, DBA_DYNFLD_STP *);    /* WEALTH-15270 - JBC - 20241023 */

extern RET_CODE FIN_RiskRatioPAA(DATETIME_T *, DBA_DYNFLD_STP*, int, FLAG_T, FREQUNIT_ENUM, DBA_DYNFLD_STP);

/* PMSTA08736 - LJE - 100603 */
extern RET_CODE FIN_GetPerfInterBench(DBA_HIER_HEAD_STP, ID_T, ID_T, DBA_DYNFLD_STP, DBA_DYNFLD_STP*);
extern RET_CODE FIN_SearchPerfEffectDef(DBA_HIER_HEAD_STP, SMALLINT_T, DBA_DYNFLD_STP, DBA_DYNFLD_STP*); /* PMSTA-15017 - LJE - 120925 */

extern RET_CODE FIN_GetDomainPerfFirstDate(DBA_DYNFLD_STP aDomain, DATE_T & perfFirstDate);
extern FLAG_T FIN_IsContribMethodBeforePtfSynthMerge(PerfCalcDefReturnMethodEn retunMethodEn);
extern FLAG_T FIN_IsContribMethod(PerfCalcDefReturnMethodEn retunMethodEn);
extern FLAG_T FIN_IsGlobalOpMethod(PerfCalcDefReturnMethodEn retunMethodEn); /* WEALTH-3330 - DDV - 240308 */

#endif	 /* ifndef FINPERFA_H */

/************************************************************************
**      END        finperfa.h                                    UNICIBLE
*************************************************************************/

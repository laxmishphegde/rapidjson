/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define DDLGENVAR_CPP

/************************************************************************
**      Include files
*************************************************************************/
#include           <string.h>

#include           "unidef.h"     /* Mandatory */
#include              "gen.h"
#include             "dba.h"
#include        "ddlgendbi.h"
#include        "ddlgenvar.h"
#include        "ddlgenfromfile.h"

#include          <algorithm>

using namespace std;

/************************************************************************
**      External entry points
**
*************************************************************************/

/************************************************************************
**      Local functions
**
*************************************************************************/

/************************************************************************
**      Static definitions & data
**
*************************************************************************/

/************************************************************************
**      METHODS
**
************************************************************************/

/************************************************************************
**
**  Function    :   DdlGenVar::DdlGenVar()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   ORACLE - LJE - 140630
**
*************************************************************************/
DdlGenVar::DdlGenVar(DBA_RDBMS_ENUM rdbmsEn)
{
    this->m_rdbmsEn = rdbmsEn;
    this->init();
}

/************************************************************************
**
**  Function    :   DdlGenVar::DdlGenVar()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-nuodb - LJE - 190522
**
*************************************************************************/
DdlGenVar::DdlGenVar(DdlGenDbi &ddlGenDbi)
    : DdlGenVar(ddlGenDbi.getDdlGenContextPtr()->m_rdbmsEn)
{
}

/************************************************************************
**
**  Function    :   DdlGenVar::DdlGenVar()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   ORACLE - LJE - 140630
**
*************************************************************************/
DdlGenVar::DdlGenVar(const DdlGenVar& toCopy)
{
    *this = toCopy;
}

/************************************************************************
**
**  Function    :   DdlGenVar::operator=
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   ORACLE - LJE - 140630
**
*************************************************************************/
DdlGenVar& DdlGenVar::operator= (const DdlGenVar& toCopy)
{
    this->bNullable                = toCopy.bNullable;
    this->m_bModify                = toCopy.m_bModify;
    this->m_modifiableVar          = toCopy.m_modifiableVar;
    this->m_ReadOnlyVar            = toCopy.m_ReadOnlyVar;
    this->m_bAlias                 = toCopy.m_bAlias;
    this->dataType                 = toCopy.dataType;
    this->varType                  = toCopy.varType;
    this->sqlName                  = toCopy.sqlName;
    this->strDefault               = toCopy.strDefault;
    this->bIsPrinted               = toCopy.bIsPrinted;
    this->bIn                      = toCopy.bIn;
    this->bOut                     = toCopy.bOut;
    this->m_bTriggerCursor         = toCopy.m_bTriggerCursor;
    this->dataTypeStr              = toCopy.dataTypeStr;
    this->m_rdbmsEn                = toCopy.m_rdbmsEn;
    this->m_value                  = toCopy.m_value;
    this->dateTimeValue            = toCopy.dateTimeValue;
    this->bNullValue               = toCopy.bNullValue;
    this->bRuntimeValue            = toCopy.bRuntimeValue;
    this->m_countAccessNbr         = 0;
    this->m_countPrintNbr          = 0;
    return *this;
}


/************************************************************************
**
**  Function    :   DdlGenVar::~DdlGenVar()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   ORACLE - LJE - 140630
**
*************************************************************************/
DdlGenVar::~DdlGenVar()
{
}

/************************************************************************
**
**  Function    :   DdlGenVar::init()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   ORACLE - LJE - 140630
**
*************************************************************************/
void DdlGenVar::init()
{
    this->bNullable          = true;
    this->m_bAlias           = false;
    this->m_bModify          = false;
    this->m_modifiableVar    = nullptr;
    this->m_ReadOnlyVar      = nullptr;
    this->dataType           = NullDataType;
    this->varType            = VarType_Variable;
    this->sqlName.clear();
    this->strDefault.clear();
    this->bIsPrinted         = false;
    this->bIn                = true;
    this->bOut               = false;
    this->m_bTriggerCursor   = false;
    this->m_countAccessNbr   = 0;
    this->m_countPrintNbr    = 0;

    this->m_value.clear();
    this->bNullValue    = true;
    this->bRuntimeValue = false;

    this->dateTimeValue.date = 0;
    this->dateTimeValue.time = 0;
}



/************************************************************************
**
**  Function    :   DdlGenVar::access()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-26956 - LJE - 180517
**
*************************************************************************/
void DdlGenVar::access()
{
    this->m_countAccessNbr++;
}

/************************************************************************
**
**  Function    :   DdlGenVar::resetAccess()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-26956 - LJE - 180517
**
*************************************************************************/
void DdlGenVar::resetAccess()
{
    this->m_countAccessNbr = 0;
}

/************************************************************************
**
**  Function    :   DdlGenVar::getAccessNbr()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-26956 - LJE - 180517
**
*************************************************************************/
int DdlGenVar::getAccessNbr()
{
    return this->m_countAccessNbr;
}

/************************************************************************
**
**  Function    :   DdlGenVar::getPrintNbr()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-26956 - LJE - 180517
**
*************************************************************************/
int DdlGenVar::getPrintNbr()
{
    return this->m_countAccessNbr;
}

/************************************************************************
**
**  Function    :   DdlGenVar::setDataTypeSqlName()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   ORACLE - LJE - 140630
**
*************************************************************************/
void DdlGenVar::setDataTypeSqlName(const string &paramDataTypeSqlName)
{
    this->dataTypeStr = paramDataTypeSqlName;
    this->dataType = DBA_GetDatatypeEnumByCode(paramDataTypeSqlName.c_str());
}

/************************************************************************
**
**  Function    :   DdlGenVar::setDataTypeNative()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   ORACLE - LJE - 140630
**
*************************************************************************/
void DdlGenVar::setDataTypeNative(const string &paramDataTypeSqlName)
{
    this->dataTypeStr = paramDataTypeSqlName;
    this->dataType = DBA_GetDatatypeEnumByEquivType(paramDataTypeSqlName.c_str());
}

/************************************************************************
**
**  Function    :   DdlGenVar::setDataType()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   ORACLE - LJE - 140630
**
*************************************************************************/
void DdlGenVar::setDataType(DATATYPE_ENUM paramDataType)
{
    this->dataType = paramDataType;
    this->dataTypeStr = DBA_GetDataTypeSQLNameC(this->dataType);
}

/************************************************************************
**
**  Function    :   DdlGenVar::getDataType()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   ORACLE - LJE - 140630
**
*************************************************************************/
DATATYPE_ENUM DdlGenVar::getDataType()
{
    return this->dataType;
}

/************************************************************************
**
**  Function    :   DdlGenVar::getVarDataType()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenVar::getVarDataType()
{
    return DdlGenDbi::getDataTypeSqlName(this->getDataType(), this->m_rdbmsEn, true, 0);
}

/************************************************************************
**
**  Function    :   DdlGenVar::getVarDataTypeStr()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string &DdlGenVar::getVarDataTypeStr()
{
    return this->dataTypeStr;
}


/************************************************************************
**
**  Function    :   DdlGenVar::getCursorName()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
std::string DdlGenVar::getCursorName()
{
    return this->m_cursorName;
}


/************************************************************************
**
**  Function    :   DdlGenVar::setCursorName()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
void DdlGenVar::setCursorName(std::string cursorName)
{
    this->m_cursorName = cursorName;
}


/************************************************************************
**
**  Function    :   DdlGenVar::printSqlName()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenVar::printSqlName(KindOfPrint kindOfPrint, bool bForceFinal)
{
    string varSqlName;
    string varPrefix;

    this->m_countPrintNbr++;

    if (kindOfPrint == DdlGenVar::KindOfPrint::Assign)
    {
        if (this->m_bModify == false)
        {
            this->m_bModify = true;
        }
    }
    else if (kindOfPrint == KindOfPrint::Use &&
             (this->varType != VarType_Variable || this->getCursorName().empty() == false) &&
             bForceFinal == false)
    {
        return "@" + this->sqlName;
    }

    if (this->m_bAlias)
    {
        varSqlName = this->sqlName;
    }
    else if ((kindOfPrint == KindOfPrint::Use || kindOfPrint == KindOfPrint::UseAsParameter) &&
             this->bRuntimeValue && 
             this->m_value.empty() == false)
    {
        if (IS_STRING_TYPE(this->dataType) == TRUE || IS_USTRING_TYPE(this->dataType) == TRUE)
        {
            varSqlName = "'" + this->m_value + "'";
        }
        else
        {
            varSqlName = this->m_value;
        }

        return varSqlName;
    }
    else if (this->varType == VarType_Variable)
    {
        varSqlName = DdlGenDbi::getVarPrefix(this->m_rdbmsEn) + this->sqlName;
    }
    else
    {
        if (this->m_bModify && 
            this->m_modifiableVar != nullptr && 
            kindOfPrint != KindOfPrint::Name &&
            kindOfPrint != KindOfPrint::Declare &&
            kindOfPrint != KindOfPrint::DeclareAsParameter)
        {
            varSqlName = this->m_modifiableVar->printSqlName(DdlGenVar::KindOfPrint::Name);
        }
        else
        {
            varSqlName = DdlGenDbi::getParamPrefix(this->m_rdbmsEn) + this->sqlName;
        }
    }

    if (this->m_rdbmsEn == PostgreSQL &&
        this->getCursorName().empty() == false &&
        this->m_bModify == false &&
        kindOfPrint != KindOfPrint::Declare &&
        kindOfPrint != KindOfPrint::DeclareAsParameter &&
        this->dataType != RecordType &&
        this->dataType != TriggerType)
    {
        if ((kindOfPrint == KindOfPrint::Use || kindOfPrint == KindOfPrint::UseAsParameter) ||
            (kindOfPrint != KindOfPrint::Assign && kindOfPrint != KindOfPrint::Name && this->varType == VarType_OverParameter))
        {
            varPrefix = DdlGenDbi::getVarPrefix(this->m_rdbmsEn) + this->getCursorName() + ".";
        }
    }

    return varPrefix + varSqlName.substr(0, DdlGenDbi::getMaxDDLObjLength(this->m_rdbmsEn));
}

/************************************************************************
**
**  Function    :   DdlGenVar::isReadOnlyParam()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
bool DdlGenVar::isReadOnlyParam()
{
    if (this->bOut == false)
    {
        if (DdlGenDbi::isReadOnlyParam(this->m_rdbmsEn) &&
            this->varType != VarType_Variable)
        {
            return true;
        }
        else if (DdlGenDbi::isReadOnlyCursorVar(this->m_rdbmsEn) &&
                 this->getCursorName().empty() == false)
        {
            return true;
        }
    }
    return false;
}

/************************************************************************
**
**  Function    :   DdlGenVar::setOut()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
void DdlGenVar::setOut(bool bNewOut)
{
    this->bOut = bNewOut;
}


/************************************************************************
**
**  Function    :   DdlGenVar::isOut()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
bool DdlGenVar::isOut()
{
    return this->bOut;
}


/************************************************************************
**
**  Function    :   DdlGenVar::setInt()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
void DdlGenVar::setIn(bool bNewIn)
{
    this->bIn = bNewIn;
}

/************************************************************************
**
**  Function    :   DdlGenVar::isIn()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
bool DdlGenVar::isIn()
{
    return this->bIn;
}

/************************************************************************
**
**  Function    :   DdlGenVar::setValue()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
void DdlGenVar::setValue(const std::string newValue)
{
    if (newValue.empty())
    {
        this->m_value.clear();
    }
    else
    {
        this->m_value = newValue;
    }
}

/************************************************************************
**
**  Function    :   DdlGenVar::getValue()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
const std::string &DdlGenVar::getValue()
{
    return this->m_value;
}

/************************************************************************
**
**  Function    :   DdlGenVar::getInParamCmd()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenVar::getInParamCmd()
{
    return (string());
}

/************************************************************************
**
**  Function    :   DdlGenVar::getInDeclareCmd()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenVar::getInDeclareCmd()
{
    stringstream      declareStream;

    if (this->m_bAlias == false)
    {
        switch (this->m_rdbmsEn)
        {
            case Sybase:
            case MSSql:
                declareStream << this->printSqlName(KindOfPrint::Declare) << " " << this->getVarDataType();
                break;

            case Oracle:
                if (this->m_bTriggerCursor)
                {
                    declareStream << "TYPE " << this->sqlName << "_TBL is table of " << this->getVarDataType() << "; ";
                    declareStream << "t_" << this->sqlName << " " << this->sqlName << "_TBL;";
                }
                else
                {
                    declareStream << this->printSqlName(KindOfPrint::Declare) << " " << this->getVarDataType();

                    if (this->strDefault.empty() == false)
                    {
                        declareStream << DdlGenDbi::getVarAssign(this->m_rdbmsEn) << this->strDefault;
                    }
                    declareStream << ";";
                }
                break;

            case Nuodb:
                declareStream << this->printSqlName(KindOfPrint::Declare) << " " << this->getVarDataType();

                if (this->strDefault.empty() == false)
                {
                    declareStream << DdlGenDbi::getVarAssign(this->m_rdbmsEn) << this->strDefault;
                }
                break;

            case PostgreSQL:
                declareStream << this->printSqlName(KindOfPrint::Declare) << " " << this->getVarDataType();

                if (this->strDefault.empty() == false &&
                    (this->m_ReadOnlyVar == nullptr || this->m_ReadOnlyVar->varType != VarType_OverParameter))
                {
                    if (strcasecmp(this->strDefault.c_str(), "null") == 0)
                    {
                        this->strDefault = DdlGenDbi::convert(this->dataType, this->strDefault, this->m_rdbmsEn, DdlObj_SProc);
                    }
                    declareStream << DdlGenDbi::getVarAssign(this->m_rdbmsEn) << this->strDefault;
                }
                break;

            default:
                SYS_BreakOnDebug();
        }
    }
    return (declareStream.str());
}

/************************************************************************
**
**  Function    :   DdlGenVar::getAssignVarCmd()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenVar::getAssignVarCmd(bool bFirst)
{
    stringstream      assignStream;

    switch (this->m_rdbmsEn)
    {
        case Sybase:
        case MSSql:
            if (this->strDefault.empty() == false)
            {
                assignStream << (bFirst ? "" : ",\n\t\t   ") << this->printSqlName(KindOfPrint::Assign)
                    << DdlGenDbi::getVarAssign(this->m_rdbmsEn) << this->strDefault;
            }
            break;

        case Oracle:
        case Nuodb:
        case PostgreSQL:
            break;

        default:
            SYS_BreakOnDebug();
    }

    return (assignStream.str());
}

/************************************************************************
**
**  Function    :   operator==()
**
**  Description :   operator
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   ORACLE - LJE - 140701
**
*************************************************************************/
bool DdlGenVar::operator==(const DdlGenVar & a) const
{
    return this->sqlName.compare(a.sqlName) == 0;
}

/************************************************************************
**
**  Function    :   operator==()
**
**  Description :   operator
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   ORACLE - LJE - 140701
**
*************************************************************************/
bool DdlGenVar::operator== (const string & cmpSqlName) const
{
    return this->sqlName.compare(cmpSqlName) == 0;
}


/************************************************************************
**
**  Function    :   DdlSprocParam::DdlSprocParam()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   ORACLE - LJE - 140630
**
*************************************************************************/
DdlSprocParam::DdlSprocParam(DictSprocClass &procSt, DBA_RDBMS_ENUM rdbmsEn)
    : DdlGenVar(rdbmsEn)
    , m_procSt(procSt)
{
    this->init();
}

/************************************************************************
**
**  Function    :   DdlSprocParam::DdlSprocParam()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   ORACLE - LJE - 140630
**
*************************************************************************/
DdlSprocParam::DdlSprocParam(const DdlSprocParam& toCopy)
    : DdlSprocParam(toCopy.m_procSt, toCopy.m_rdbmsEn)
{
    this->bIn           = toCopy.bIn;
    this->bOut          = toCopy.bOut;
    this->sqlName       = toCopy.sqlName;
    this->strDefault    = toCopy.strDefault;
    this->m_value       = toCopy.m_value;
    this->bNullValue    = toCopy.bNullValue;
    this->bRuntimeValue = toCopy.bRuntimeValue;
    this->bNullable     = toCopy.bNullable;

    this->setDataType(toCopy.dataType);
}


/************************************************************************
**
**  Function    :   DdlSprocParam::~DdlSprocParam()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   ORACLE - LJE - 140630
**
*************************************************************************/
DdlSprocParam::~DdlSprocParam()
{
}

/************************************************************************
**
**  Function    :   DdlSprocParam::init()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   ORACLE - LJE - 140630
**
*************************************************************************/
void DdlSprocParam::init()
{
    DdlGenVar::init();
    this->varType = VarType_Parameter;
}

/************************************************************************
**
**  Function    :   DdlSprocParam::getParamDataType()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlSprocParam::getParamDataType()
{
    return DdlGenDbi::getDataTypeSqlName(this->getDataType(), this->m_rdbmsEn, false, 0);
}


/************************************************************************
**
**  Function    :   DdlSprocParam::getDictAttribStp()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
DICT_ATTRIB_STP DdlSprocParam::getDictAttribStp()
{
    for (auto it = this->m_procSt.m_paramProcAttribVector.begin(); it != this->m_procSt.m_paramProcAttribVector.end(); ++it)
    {
        if (this->sqlName == it->m_sqlName)
        {
            return it->attrStp;
        }
    }

    return nullptr;
}

/************************************************************************
**
**  Function    :   DdlSprocParam::isAlwaysInParam()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
bool DdlSprocParam::isAlwaysInParam()
{
    DICT_ATTRIB_STP dictAttribStp = nullptr;

    if (this->isOut() ||
        (dictAttribStp = this->getDictAttribStp()) == nullptr ||
        dictAttribStp->dataTpProgN == TimeStampType)
    {
        return true;
    }

    if (this->m_procSt.m_storedProcAccessVector.empty() == false)
    {
        for (auto it = this->m_procSt.m_storedProcAccessVector.begin(); it != this->m_procSt.m_storedProcAccessVector.end(); ++it)
        {
            if ((*it)->procParamDefPtr != nullptr)
            {
                for (int i = 0; (*it)->procParamDefPtr[i].fldNbrPtr != nullptr; ++i)
                {
                    if (this->sqlName == &((*it)->procParamDefPtr[i].paramName[1]))
                    {
                        return true;
                    }
                }
            }
        }
    }

    return false;
}


/************************************************************************
**
**  Function    :   DdlSprocParam::setOut()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
void DdlSprocParam::setOut(bool bNewOut)
{
    if (this->bOut != bNewOut && this->sqlName.empty() == false)
    {
        auto &paramVector = this->m_procSt.m_paramProcAttribVector;
        for (auto it = paramVector.begin(); it != paramVector.end(); ++it)
        {
            if (this->sqlName == it->m_sqlName)
            {
                if (it->outputFlg == FALSE && bNewOut)
                {
                    it->outputFlg = TRUE;
                }
                else if (it->outputFlg == TRUE && bNewOut == false)
                {
                    it->outputFlg = FALSE;
                }
                break;
            }
        }
    }
    this->bOut = bNewOut;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getInParamCmd()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlSprocParam::getInParamCmd(bool bFirst)
{
    stringstream      paramStream;

    switch (this->m_rdbmsEn)
    {
        case Sybase:
        case MSSql:
            paramStream << this->printSqlName(KindOfPrint::DeclareAsParameter) << " " << this->getParamDataType();

            if (!this->strDefault.empty())
            {
                paramStream << DdlGenDbi::getParamDefaultAssign(this->m_rdbmsEn) << this->strDefault;
            }

            if (this->bOut)
            {
                paramStream << " output";
            }
            break;

        case Oracle:
            paramStream << this->printSqlName(KindOfPrint::DeclareAsParameter);
            if (this->bIn)
            {
                paramStream << " IN";
            }

            if (this->bOut)
            {
                paramStream << " OUT";
            }

            paramStream << " " << this->getParamDataType();

            if (this->strDefault.empty() == false)
            {
                paramStream << DdlGenDbi::getParamDefaultAssign(this->m_rdbmsEn);
                paramStream << this->strDefault;
            }
            break;

        case Nuodb:
            if (this->m_procSt.functionFlg == FALSE)
            {
                if (this->bIn && this->bOut)
                {
                    paramStream << "INOUT ";
                }
                else if (this->bIn)
                {
                    paramStream << "IN ";
                }
                else if (this->bOut)
                {
                    paramStream << "OUT ";
                }
            }
            paramStream << this->printSqlName(KindOfPrint::DeclareAsParameter) << " " << this->getParamDataType();
            break;

        case PostgreSQL:
            if (this->m_procSt.functionFlg == FALSE)
            {
                if (this->bIn && this->bOut)
                {
                    paramStream << "INOUT ";
                }
                else if (this->bIn)
                {
                    if (bFirst == false)
                    {
                        paramStream << " ";
                    }
                }
                else if (this->bOut)
                {
                    paramStream << "OUT ";
                }
            }
            paramStream << this->printSqlName(KindOfPrint::DeclareAsParameter) << " " << this->getParamDataType();

            if (this->strDefault.empty() == false)
            {
                if (strcasecmp(this->strDefault.c_str(), "null") == 0)
                {
                    this->strDefault = "NULL";
                }

                paramStream << DdlGenDbi::getParamDefaultAssign(this->m_rdbmsEn);
                paramStream << this->strDefault << "::" << this->getParamDataType();
            }
            break;

        default:
            SYS_BreakOnDebug();
    }

    return (paramStream.str());
}

/************************************************************************
**
**  Function    :   DdlSprocParam::getInDeclareCmd()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlSprocParam::getInDeclareCmd()
{
    return (string());
}

/************************************************************************
**
**  Function    :   DdlGenVarHelper::DdlGenVarHelper()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   ORACLE - LJE - 140630
**
*************************************************************************/
DdlGenVarHelper::DdlGenVarHelper(DdlGenDbi *ddlGenDbi, DdlGenFromFile *ddlGenFromFile)
    : m_bAddVarInCursor(false)
    , m_ddlGenDbiPtr(ddlGenDbi != nullptr ? ddlGenDbi : new DdlGenDbi(DdlObj_None, *ddlGenFromFile->getDdlGenContextPtr(), nullptr, nullptr, TargetTable_Undefined))
    , m_ddlGenFromFilePtr(ddlGenFromFile)
    , dateFirstEn(CalConvWeekday_Monday)
    , invalidVar(*this->m_ddlGenDbiPtr)
    , m_keepAllParamters(true)
{
    if (ddlGenDbi == nullptr)
    {
        this->m_mp.ownerObject(this->m_ddlGenDbiPtr);
    }
    this->rowCount.clear();

    this->inCursorNameVector.push_back(DdlGenCursorDef(string(), 0));
}

/************************************************************************
**
**  Function    :   DdlGenVarHelper::~DdlGenVarHelper()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   ORACLE - LJE - 140630
**
*************************************************************************/
DdlGenVarHelper::~DdlGenVarHelper()
{
    this->cleanAllVar();
}

/************************************************************************
**
**  Function    :  DdlGenVarHelper::getParamBySqlName()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-11505 - LJE - 110404
**
*************************************************************************/
DdlSprocParam *DdlGenVarHelper::getParameter(string paramName)
{
    DdlGenParamIter parameter;

    this->fixVariableName(paramName);

    for (parameter = this->paramList.begin(); parameter != this->paramList.end(); parameter++)
    {
        if ((*parameter)->sqlName == paramName)
        {
            break;
        }
    }

    if (parameter != this->paramList.end())
    {
        return *parameter;
    }

    return NULL;
}

/************************************************************************
**
**  Function    :  DdlGenVarHelper::removeParameter()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-11505 - LJE - 110404
**
*************************************************************************/
void DdlGenVarHelper::removeParameter(const string paramName)
{
    DdlSprocParam *sprocParamPtr = this->getParameter(paramName);
    if (sprocParamPtr)
    {
        this->paramList.remove(sprocParamPtr);
    }
    else
    {
        this->printMsg(RET_DBA_ERR_INVDATA, "Unknown attribute: " + paramName);
    }

}


/************************************************************************
**
**  Function    :   DdlGenVarHelper::getVariable()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   ORACLE - LJE - 140630
**
*************************************************************************/
DdlGenVar *DdlGenVarHelper::getVariable(string varSqlName, bool bCheck, bool bForceVar)
{
    vector<DdlGenVar*>::iterator variable;
    DdlGenVar *returnVar = nullptr;

    if (this->m_ddlGenFromFilePtr && this->getInCursorName().empty() == false)
    {
        int iCursorCpt = this->getInCursorPos();

        while (iCursorCpt > 0)
        {
            string curVarSqlName = SYS_Stringer("c", this->getInCursorValue(iCursorCpt), "_", varSqlName);
            this->fixVariableName(curVarSqlName);

            for (variable = variableList.begin(); variable != variableList.end(); ++variable)
            {
                if ((*variable)->sqlName == curVarSqlName &&
                    (*variable)->getCursorName() == this->getInCursorName(iCursorCpt))
                {
                    break;
                }
            }

            if (variable != this->variableList.end())
            {
                returnVar = *variable;
                break;
            }
            iCursorCpt--;
        }
    }

    if (returnVar == nullptr)
    {
        this->fixVariableName(varSqlName);

        if (bForceVar == false)
        {
            returnVar = (DdlGenVar*)this->getParameter(varSqlName);
        }

        if (returnVar == nullptr)
        {
            for (variable = this->variableList.begin(); variable != this->variableList.end(); ++variable)
            {
                if ((*variable)->sqlName == varSqlName)
                {
                    break;
                }
            }

            if (variable != this->variableList.end())
            {
                returnVar = *variable;
            }
            else if (bCheck == true &&
                     this->m_ddlGenDbiPtr != nullptr &&
                     this->m_ddlGenFromFilePtr != nullptr &&
                     (this->m_ddlGenFromFilePtr->getOutDdlObjEn() == DdlObj_Trigger ||
                      this->m_ddlGenFromFilePtr->getOutDdlObjEn() == DdlObj_TriggerBody))
            {
                if (varSqlName.compare("curr_modif_d") == 0)
                {
                    returnVar = this->addVariable(varSqlName, DatetimeType, this->m_ddlGenDbiPtr->getCmdGetDateTime());
                }
            }
            
            if (returnVar == nullptr &&
                bCheck &&
                (this->m_ddlGenFromFilePtr == nullptr ||
                 this->m_ddlGenFromFilePtr->getDdlObjEn() != DdlObj_RuntimeSql))
            {
                this->printMsg(RET_GEN_ERR_INVARG, "Unknown variable or parameter: " + varSqlName);
            }
        }
    }

    if (returnVar != nullptr)
    {
        returnVar->access();
    }

    return returnVar;
}

/************************************************************************
**
**  Function    :   DdlGenVarHelper::getNewVariable()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   ORACLE - LJE - 140630
**
*************************************************************************/
DdlGenVar* DdlGenVarHelper::getNewVariable(string varSqlName, DATATYPE_ENUM varDataType)
{
    DdlGenVar newVariable(*this->m_ddlGenDbiPtr), *newVariablePtr = NULL;

    this->fixVariableName(varSqlName);

    newVariablePtr = this->getVariable(varSqlName, false);

    if (newVariablePtr == NULL)
    {
        newVariable.sqlName = varSqlName;
        newVariable.setDataType(varDataType);
        this->addVariable(newVariable);

        newVariablePtr = this->getVariable(varSqlName);
    }

    if (newVariablePtr != NULL)
    {
        return newVariablePtr;
    }
    else
    {
        return &this->invalidVar;
    }
}

/************************************************************************
**
**  Function    :   DdlGenVarHelper::getNewVariable()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   ORACLE - LJE - 140630
**
*************************************************************************/
DdlGenVar* DdlGenVarHelper::getNewVariable(string varSqlName, string varDataType)
{
    DdlGenVar newVariable(*this->m_ddlGenDbiPtr), *newVariablePtr = NULL;

    this->fixVariableName(varSqlName);

    newVariablePtr = this->getVariable(varSqlName, false);

    if (newVariablePtr == NULL)
    {
        newVariable.sqlName = varSqlName;
        newVariable.setDataTypeSqlName(varDataType);
        this->addVariable(newVariable);

        newVariablePtr = this->getVariable(varSqlName);
    }

    if (newVariablePtr != NULL)
    {
        return newVariablePtr;
    }
    else
    {
        return &this->invalidVar;
    }
}

/************************************************************************
**
**  Function    :   DdlGenVarHelper::cleanAllVar()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   ORACLE - LJE - 140630
**
*************************************************************************/
void DdlGenVarHelper::cleanAllVar()
{
    this->m_keepAllParamters = true;

    for (list<DdlSprocParam*>::iterator it = paramList.begin(); it != paramList.end(); ++it)
    {
        delete *it;
        this->m_mp.removeObject((*it));
    }

    for (vector<DdlGenVar*>::iterator it = variableList.begin(); it != variableList.end(); ++it)
    {
        delete *it;
        this->m_mp.removeObject((*it));
    }

    this->variableList.clear();
    this->paramList.clear();
}

/************************************************************************
**
**  Function    :   DdlGenVarHelper::setAllVarToNotPrinted()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-18593 - LJE - 151121
**
*************************************************************************/
void DdlGenVarHelper::setAllVarToNotPrinted()
{
    for (list<DdlSprocParam*>::iterator it = paramList.begin(); it != paramList.end(); ++it)
    {
        (*it)->bIsPrinted = false;
    }

    for (vector<DdlGenVar*>::iterator it = variableList.begin(); it != variableList.end(); ++it)
    {
        (*it)->bIsPrinted = false;
    }
}

/************************************************************************
**
**  Function    :   DdlGenVarHelper::getVariableList()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   ORACLE - LJE - 140630
**
*************************************************************************/
vector<DdlGenVar*> *DdlGenVarHelper::getVariableList()
{
    return &this->variableList;
}

/************************************************************************
**
**  Function    :   DdlGenVarHelper::getVariableNbr()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   ORACLE - LJE - 140630
**
*************************************************************************/
size_t DdlGenVarHelper::getVariableNbr()
{
    return this->variableList.size();
}

/************************************************************************
**
**  Function    :   DdlGenVarHelper::getParamList()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   ORACLE - LJE - 140630
**
*************************************************************************/
list<DdlSprocParam*> *DdlGenVarHelper::getParamList()
{
    return &this->paramList;
}

/************************************************************************
**
**  Function    :   DdlGenVarHelper::getParamNbr()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   ORACLE - LJE - 140630
**
*************************************************************************/
size_t DdlGenVarHelper::getParamNbr()
{
    return this->paramList.size();
}

/************************************************************************
**
**  Function    :   DdlGenVarHelper::fixVariableName()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   ORACLE - LJE - 140630
**
*************************************************************************/
void  DdlGenVarHelper::fixVariableName(string & varSqlName)
{
    string::size_type aliasPos;

    while ((aliasPos = varSqlName.find("@")) != string::npos && varSqlName[aliasPos + 1] != '@')
    {
        varSqlName.erase(aliasPos, 1);
    }

    if (varSqlName.length() > this->m_ddlGenDbiPtr->getMaxDDLObjLength()-2)
    {
        varSqlName.erase(28, varSqlName.length() - this->m_ddlGenDbiPtr->getMaxDDLObjLength());
    }
}

/************************************************************************
**
**  Function    :   DdlGenVarHelper::addVariable()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   ORACLE - LJE - 140630
**
*************************************************************************/
DdlGenVar *DdlGenVarHelper::addVariable(const string &varSqlName, DATATYPE_ENUM varDataType, const string &defaultValue)
{
    return this->addVariable(varSqlName, DBA_GetDataTypeSQLNameC(varDataType), defaultValue);
}

/************************************************************************
**
**  Function    :   DdlGenVarHelper::addVariable()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   ORACLE - LJE - 140630
**
*************************************************************************/
DdlGenVar *DdlGenVarHelper::addVariable(const string &varSqlName, const string &varDataType, const string &defaultValue)
{
    DdlGenVar newVar(*this->m_ddlGenDbiPtr);

    newVar.sqlName = varSqlName;
    this->fixVariableName(newVar.sqlName);

    if (varDataType.empty() == false)
    {
        newVar.setDataTypeSqlName(varDataType);
    }

    newVar.strDefault = defaultValue;

    return this->addVariable(newVar);
}

/************************************************************************
**
**  Function    :   DdlGenVarHelper::addVariable()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   ORACLE - LJE - 140630
**
*************************************************************************/
DdlGenVar *DdlGenVarHelper::addVariable(DdlGenVar& newVariable)
{
    this->fixVariableName(newVariable.sqlName);

    DdlGenVar *searchVar = this->getVariable(newVariable.sqlName, false, true);

    if (searchVar == nullptr)
    {
        if (newVariable.getDataType() != NullDataType)
        {
            searchVar = new DdlGenVar(newVariable);
            this->m_mp.ownerObject(searchVar);

            searchVar->varType = VarType_Variable;
            if (this->isAddVarInCursor())
            {
                searchVar->setCursorName(this->getInCursorName());
            }

            this->variableList.push_back(searchVar);

            if (newVariable.varType != VarType_OverParameter &&
                (newVariable.m_bModify == false || DdlGenDbi::isReadOnlyParam(this->m_ddlGenDbiPtr->getDdlGenContextPtr()->m_rdbmsEn) == false))
            {
                for (auto parameter = this->paramList.begin(); parameter != this->paramList.end(); parameter++)
                {
                    if ((*parameter)->sqlName == newVariable.sqlName)
                    {
                        this->printMsg(RET_GEN_ERR_INVARG, "The variable name '" + newVariable.sqlName + "' has already been declared as parameter.");
                    }
                }
            }
        }
        else if (newVariable.getVarDataTypeStr().empty() == false)
        {
            this->printMsg(RET_GEN_ERR_INVARG, "Invalid data-type (" + newVariable.getVarDataTypeStr() + ") for variable " + newVariable.sqlName);
        }
        else
        {
            this->printMsg(RET_GEN_ERR_INVARG, "Unknown variable " + newVariable.sqlName);
        }
    }
    else
    {
        if (newVariable.strDefault.empty() == false &&
            searchVar->strDefault.compare(newVariable.strDefault) != 0)
        {
            searchVar->strDefault = newVariable.strDefault;
        }
        if (newVariable.m_bModify != searchVar->m_bModify)
        {
            searchVar->m_bModify = newVariable.m_bModify;
        }
    }

    return searchVar;
}

/************************************************************************
**
**  Function    :   DdlGenVarHelper::setModify()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   ORACLE - LJE - 140630
**
*************************************************************************/
void DdlGenVarHelper::setModify(DdlGenVar &variable)
{
    variable.m_bModify = true;

    if (variable.isReadOnlyParam() && variable.m_modifiableVar == nullptr)
    {
        variable.m_modifiableVar = this->addVariable(variable);

        if (variable.m_modifiableVar != nullptr)
        {
            variable.m_modifiableVar->m_ReadOnlyVar = &variable;
        }
        else
        {
            variable.m_modifiableVar = this->getVariable(variable.sqlName, true, true);
        }

        if (variable.m_modifiableVar != nullptr)
        {
            variable.m_modifiableVar->strDefault = variable.printSqlName(DdlGenVar::KindOfPrint::Name);
        }
    }
}

/************************************************************************
**
**  Function    :   DdlGenVarHelper::setCursorName()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-49178 - LJE - 220909
**
*************************************************************************/
void DdlGenVarHelper::setCursorName(DdlGenVar &variable)
{
    variable.setCursorName(this->getInCursorName());
}

/************************************************************************
**
**  Function    :   DdlGenVarHelper::setAlias()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-nuodb - LJE - 190812
**
*************************************************************************/
void DdlGenVarHelper::setAlias(DdlGenVar& variable)
{
    variable.m_bAlias = true;
}

/************************************************************************
**
**  Function    :   DdlGenVarHelper::copyVariables()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   ORACLE - LJE - 140630
**
*************************************************************************/
void  DdlGenVarHelper::copyVariables(DdlGenVarVec *srcVariables)
{
    for (auto it = srcVariables->begin(); it != srcVariables->end(); ++it)
    {
        this->addVariable(**it);
    }

}

/************************************************************************
**
**  Function    :   DdlGenVarHelper::copyVariables()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   ORACLE - LJE - 140630
**
*************************************************************************/
void  DdlGenVarHelper::copyVariables(DdlGenVarHelper *srcDdlGenVarHelper)
{
    for (auto it = srcDdlGenVarHelper->getVariableList()->begin(); it != srcDdlGenVarHelper->getVariableList()->end(); ++it)
    {
        this->addVariable(**it);
    }

}

/************************************************************************
**
**  Function    :   DdlGenVarHelper::setExtraParam()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-14452 - LJE - 130114
**
*************************************************************************/
void DdlGenVarHelper::setExtraParam(list<DdlSprocParam> paramExtraParamList)
{
    for (auto it = paramExtraParamList.begin(); it != paramExtraParamList.end(); ++it)
    {
        this->addParameter(*it);
    }
}

/************************************************************************
**
**  Function    :   DdlGenSProc::addParam()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   ORACLE - LJE - 140630
**
*************************************************************************/
void  DdlGenVarHelper::addParameter(DdlSprocParam newParam)
{
    this->fixVariableName(newParam.sqlName);

    DdlSprocParam *existsParam;

    if ((existsParam = this->getParameter(newParam.sqlName)) == NULL)
    {
        DdlSprocParam *newParamPtr = new DdlSprocParam(newParam);
        this->m_mp.ownerObject(newParamPtr);

        this->paramList.push_back(newParamPtr);

        if (CAST_INT(this->paramList.size()) > EV_MaxNumberArgument)
        {
            this->m_keepAllParamters = false;
        }
    }
    else
    {
        existsParam->setOut(newParam.isOut());
        existsParam->setIn(newParam.isIn());
        existsParam->bNullable = newParam.bNullable;
    }
}

/************************************************************************
**
**  Function    :   DdlGenVarHelper::printVarList()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   ORACLE - LJE - 140701
**
*************************************************************************/
void DdlGenVarHelper::printVarList(DdlGenDbi &ddlGenDbi, std::stringstream &declareStream, std::stringstream & initStream, bool bSproc, const std::string & newLineStr)
{
    if (this->paramList.empty() == false)
    {
        for (DdlGenParamIter it = this->paramList.begin(); it != this->paramList.end(); ++it)
        {
            if ((*it)->m_bModify &&
                (*it)->isOut() == false &&
                (*it)->m_modifiableVar == nullptr &&
                (*it)->isReadOnlyParam())
            {
                DdlGenVar *copyParam = new DdlGenVar(**it);
                this->m_mp.ownerObject(copyParam);

                if ((*it)->varType != VarType_OverParameter)
                {
                    copyParam->strDefault = copyParam->printSqlName(DdlGenVar::KindOfPrint::Use);
                }
                else
                {
                    copyParam->varType = VarType_Variable;
                }
                
                (*it)->m_modifiableVar = copyParam;
                copyParam->m_ReadOnlyVar = (*it);
                this->variableList.push_back(copyParam);
            }
        }
    }

    if (this->variableList.empty() == false)
    {
        bool              bFirst       = true;
        bool              bFirstAssign = true;
        stringstream      assignStream;

        for (DdlGenVarIter it = this->variableList.begin(); it != this->variableList.end(); ++it)
        {
            if ((*it)->m_bAlias)
            {
                continue;
            }

            if (bFirst)
            {
                declareStream << (bSproc ? ddlGenDbi.getProcDeclare() : ddlGenDbi.getSqlDeclare()) << newLineStr;
            }
            else
            {
                declareStream << this->m_ddlGenDbiPtr->getVarSepartor() << newLineStr;
            }
            declareStream << (*it)->getInDeclareCmd();

            if ((*it)->strDefault.empty() == false)
            {
                assignStream << (*it)->getAssignVarCmd(bFirstAssign);
                bFirstAssign = false;
            }

            if ((*it)->getValue().empty() == false)
            {
                if ((*it)->bNullValue == false && 
                    (IS_STRING_TYPE((*it)->getDataType()) == TRUE ||
                    (*it)->getDataType() == DateType || (*it)->getDataType() == DatetimeType))
                {
                    if ((*it)->dateTimeValue.date != 0)
                    {
                        char dateBuf[DATETIME_SQL_STRING_SIZE];
                        DATETIME_ToDbStr(dateBuf, (*it)->dateTimeValue.date, (*it)->dateTimeValue.time);
                        initStream << ddlGenDbi.getCmdAssignByValue(*(*it), dateBuf);
                    }
                    else
                    {
                        initStream << ddlGenDbi.getCmdAssignByValue(*(*it), "'" + (*it)->getValue() + "'");
                    }
                }
                else
                {
                    initStream << ddlGenDbi.getCmdAssignByValue(*(*it), (*it)->getValue());
                }
                (*it)->bRuntimeValue = false;
            }

            bFirst = false;
        }

        if (bFirst == false)
        {
            declareStream << this->m_ddlGenDbiPtr->getVarEnd() << endl;
        }

        if (assignStream.str().empty() == false)
        {
            declareStream << newLineStr << this->m_ddlGenDbiPtr->getVarAssignCmd() << assignStream.str() << endl;
        }
    }
}


/************************************************************************
**
**  Function    :   DdlGenVarHelper::resetAccessVarNbr()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-26956 - LJE - 180517
**
*************************************************************************/
void DdlGenVarHelper::resetAccessVarNbr()
{
    for (DdlGenVarIter it = this->variableList.begin(); it != this->variableList.end(); ++it)
    {
        (*it)->resetAccess();
    }
}


/************************************************************************
**
**  Function    :   DdlGenVarHelper::getAccededVarSet()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-26956 - LJE - 180517
**
*************************************************************************/
void DdlGenVarHelper::getAccededVarSet(std::set<std::string> &accededVarSet)
{
    for (DdlGenVarIter it = this->variableList.begin(); it != this->variableList.end(); ++it)
    {
        if ((*it)->getAccessNbr())
        {
            accededVarSet.insert((*it)->sqlName);
        }
    }
}


/************************************************************************
**
**  Function    :   DdlGenVarHelper::printVarName()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   ORACLE - LJE - 140630
**
*************************************************************************/
string DdlGenVarHelper::printVarName(string varSqlName)
{
    DdlGenVar *varPtr = this->getVariable(varSqlName);

    if (varPtr != NULL)
    {
        return varPtr->printSqlName();
    }
    else
    {
        return "<Unknown Var: " + varSqlName + ">";
    }
}

/************************************************************************
**
**  Function    :   DdlGenSProc::setParamList()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
RET_CODE DdlGenVarHelper::setParamList(DictSprocClass &procSt)
{
    RET_CODE            ret = RET_SUCCEED;
    DdlSprocParam       currSprocParam(procSt, this->m_ddlGenDbiPtr->getDdlGenContextPtr()->m_rdbmsEn);
    list<DdlSprocParam*> extraParamList=this->paramList;

    this->paramList.clear();

    /* PMSTA-26250 - LJE - 170510 */
    for (auto it = procSt.m_paramProcAttribVector.begin(); it != procSt.m_paramProcAttribVector.end(); ++it)
    {
        if (it->deletedFlg == TRUE)
        {
            continue;
        }

        currSprocParam.init();

        if (it->outputFlg == TRUE)
        {
            currSprocParam.setOut(true);
        }

        currSprocParam.sqlName = it->m_sqlName;
        if (it->attrStp != NULL)
        {
            currSprocParam.setDataType(it->attrStp->dataTpProgN);
        }
        else
        {
            currSprocParam.setDataTypeSqlName(it->getDataTypeStr());
        }

        if (it->defaultValueC[0] != 0)
        {
            currSprocParam.strDefault = it->defaultValueC;
        }

        if (it->attrStp &&
            it->attrStp->dbMandatoryFlg == TRUE)
        {
            currSprocParam.bNullable = false;
        }

        this->addParameter(currSprocParam);
    }

    for (auto itExtraParam = extraParamList.begin(); itExtraParam != extraParamList.end(); ++itExtraParam)
    {
        this->addParameter(**itExtraParam);
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenSProc::printParamList()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
bool DdlGenVarHelper::printParamList(stringstream  &outStream)
{
    bool              bFirst = true;

    /* PMSTA-49178 - LJE - 220920 - If too much parameters, print only pk/bk and output parameters */
    for (DdlGenParamIter it = this->paramList.begin(); it != this->paramList.end(); ++it)
    {
        if (this->isAllParamKept() || (*it)->isAlwaysInParam())
        {
            if (bFirst == false)
            {
                outStream << this->m_ddlGenDbiPtr->getParamSepartor();
            }
            else
            {
                outStream << this->m_ddlGenDbiPtr->getParamInit();
            }
            outStream << (*it)->getInParamCmd(bFirst);

            bFirst = false;
        }
    }

    outStream << this->m_ddlGenDbiPtr->getParamClose(bFirst);

    return this->isAllParamKept();
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::isAddVarInCursor()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-49178 - LJE - 221201
**
*************************************************************************/
bool DdlGenVarHelper::isAddVarInCursor() const
{
    return this->m_bAddVarInCursor;
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::isAddVarInCursor()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-49178 - LJE - 221201
**
*************************************************************************/
void DdlGenVarHelper::releaseAddInCursor()
{
    this->m_bAddVarInCursor = false;
}


/************************************************************************
**
**  Function    :  DdlGenFromFile::setInCursorName()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-18593 - LJE - 141215
**
*************************************************************************/
void DdlGenVarHelper::setInCursorName(const string& paramInCursorName)
{
    if (paramInCursorName.empty())
    {
        this->releaseAddInCursor();
        this->inCursorNameVector.pop_back();
    }
    else
    {
        auto ddlGenContextPtr = (this->m_ddlGenFromFilePtr != nullptr ? this->m_ddlGenFromFilePtr->getDdlGenContextPtr() : this->m_ddlGenDbiPtr->getDdlGenContextPtr());

        if (ddlGenContextPtr != nullptr)
        {
            this->m_bAddVarInCursor = true;
            this->inCursorNameVector.push_back(DdlGenCursorDef(paramInCursorName, ++ddlGenContextPtr->iCursorCpt));
        }
    }
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::getInCursorName()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-18593 - LJE - 141215
**
*************************************************************************/
const string& DdlGenVarHelper::getInCursorName(int pos) const
{
    if (pos == 0)
    {
        return this->inCursorNameVector.back().m_name;
    }

    return this->inCursorNameVector[pos].m_name;
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::getInCursorValue()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-37366 - LJE - 200401
**
*************************************************************************/
int DdlGenVarHelper::getInCursorValue(int pos) const
{
    if (pos == 0)
    {
        return this->inCursorNameVector.back().m_value;
    }

    return this->inCursorNameVector[pos].m_value;
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::getInCursorPos()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-37366 - LJE - 200401
**
*************************************************************************/
int DdlGenVarHelper::getInCursorPos() const
{
    return static_cast<int>(this->inCursorNameVector.size() - 1);
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::clearInCursorName()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-18593 - LJE - 141215
**
*************************************************************************/
void DdlGenVarHelper::clearInCursorName()
{
    this->inCursorNameVector.clear();
    this->inCursorNameVector.push_back(DdlGenCursorDef(string(), 0));
}

/************************************************************************
**
**  Function    :  DdlGenVarHelper::printMsg()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-14086 - LJE - 121005
**
*************************************************************************/
void DdlGenVarHelper::printMsg(RET_CODE retCode, const std::string &paramMsg, bool isNewLine, int sprocLine)
{
    if (this->m_ddlGenFromFilePtr != nullptr)
    {
        this->m_ddlGenFromFilePtr->printMsg(retCode, paramMsg, isNewLine, sprocLine);
    }
    else
    {
        this->m_ddlGenDbiPtr->printMsg(retCode, paramMsg, isNewLine, sprocLine);
    }
}

/*************************************************************************
**   END  ddlgendbi.cpp                                         Odyssey **
*************************************************************************/

/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define DDLGENFULLTABLE_CPP

/************************************************************************
**      Include files
*************************************************************************/
#define STDIO_H
#define STRING_H
#define TIME_H
#define STDLIB_H

#include      <iomanip>
#include     <limits.h>
#include       <random>

#include          "unidef.h"     /* Mandatory */
#include             "gen.h"
#include             "dba.h"
#include          "dbafmt.h"
#include            "date.h"
#include          "ddlgen.h"
#include     "ddlgentable.h"
#include        "ddlgenfk.h"
#include  "ddlgenfromfile.h"
#include   "ddlgentrigger.h"
#include     "ddlgenindex.h"
#include "ddlgenfulltable.h"
#include      "ddlgenfile.h"
#include            "str.h"

#ifdef _WINDOWS
#include <sys/stat.h>
#include <io.h>
#endif

using namespace std;

/************************************************************************
**      External entry points
**
*************************************************************************/

/************************************************************************
**      Local functions
**
*************************************************************************/

/************************************************************************
**      Static definitions & data
**
*************************************************************************/
#define PROG_N_TO_DELETE              SHRT_MAX
#define PROG_N_TO_PHYSICAL_DELETE     INT_MAX

#define DISP_RANK_SCPT_CTRL           (SHRT_MAX - 10)
#define PROG_N_SCPT_CTRL              DISP_RANK_SCPT_CTRL

#define PROG_N_PK                     (-900)
#define PROG_N_BK                     (-800)
#define PROG_N_PARENT_ATTR            (-700)

#define PROG_N_INIT_PHYS              (SHRT_MAX - 20000)
#define PROG_N_INIT_DENORM            (SHRT_MAX - 16000)
#define PROG_N_INIT_VIRTUAL           (SHRT_MAX - 15000)
#define PROG_N_INIT_LOGICAL           (SHRT_MAX - 14000)
#define PROG_N_START_SHORT_VIRTUAL    (SHRT_MAX - 13000)
#define PROG_N_START_SHORT_CUSTO      (SHRT_MAX - 17000)
#define PROG_N_START_SHORT_FEATURE    5000

#define PROG_N_INIT                   (PROG_N_INIT_DENORM - 10)

#define DISP_RANK_FIRST_SPEC          DISP_RANK_SCPT_CTRL
#define PROG_N_START_FEATURE          (PROG_N_INIT_PHYS + 1000)
#define PROG_N_START_MODEL_BANK       (PROG_N_INIT_PHYS + 2000)
#define PROG_N_START_UD               (PROG_N_INIT_PHYS + 3000)
#define PROG_N_START_PRECOMP          (PROG_N_INIT_PHYS + 4000)
#define PROG_N_START_LOGICAL          PROG_N_INIT_LOGICAL

/************************************************************************
**      FONCTIONS
**
************************************************************************/

class DdlGenProcessLogger
{
public:
    DdlGenProcessLogger(DdlGenFullTable& ddlGenFullTable,
                        RET_CODE& retCode,
                        const char* processStr)
        : m_ddlGenFullTable(ddlGenFullTable)
        , m_retCode(retCode)
        , m_processStr(processStr)
        , m_bStarted(false)
    {
        if (ddlGenFullTable.getDdlGenAction().m_targetSqlnameStr.empty() == false)
        {
            this->m_processStr += " (" + ddlGenFullTable.getDdlGenAction().m_targetSqlnameStr + ")";
        }
    };

    virtual ~DdlGenProcessLogger()
    {
        this->m_ddlGenFullTable.getDdlGenContextPtr()->setMsgSqlName(string());

        if (this->m_bStarted == false)
        {
            if (RET_GET_LEVEL(this->m_retCode) != RET_LEV_ERROR)
            {
                this->m_retCode = RET_SRV_INFO_NO_POSITIONS;
            }
            this->m_ddlGenFullTable.getDdlGenContextPtr()->printMsg(this->m_retCode, this->m_processStr);
        }
        else if (RET_GET_LEVEL(this->m_retCode) != RET_LEV_ERROR)
        {
            this->m_ddlGenFullTable.getDdlGenContextPtr()->printMsg(this->m_retCode, this->m_processStr.append(" done!"));
        }
        else
        {
            this->m_ddlGenFullTable.getDdlGenContextPtr()->printMsg(this->m_retCode, this->m_processStr.append(" failed!"));
        }
    };

    void start()
    {
        this->m_bStarted = true;

        this->m_ddlGenFullTable.getDdlGenContextPtr()->printMsg(RET_SRV_INFO_RUNNING, this->m_processStr);
    };

    std::string      m_processStr;

private:

    DdlGenFullTable& m_ddlGenFullTable;
    RET_CODE& m_retCode;
    bool             m_bStarted;
};

/************************************************************************
**
**  Function    :   DdlGenObj::DdlGenObj()
**
**  Description :   Constructor
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-18593 - LJE - 150609
**
*************************************************************************/
DdlGenObj::DdlGenObj()
{
    entityDictId = 0;
    objectDictId = 0;
};

DdlGenObj::DdlGenObj(const DdlGenObj& toCopy)
{
    this->entityDictId = toCopy.entityDictId;
    this->objectDictId = toCopy.objectDictId;
};

/************************************************************************
**
**  Function    :   DdlGenObj::operator==
**
**  Description :   ==
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-18593 - LJE - 150609
**
*************************************************************************/
bool DdlGenObj::operator== (const DdlGenObj& toTest) const
{
    if (toTest.entityDictId == this->entityDictId &&
        toTest.objectDictId == this->objectDictId)
    {
        return true;
    }
    return false;
};

/************************************************************************
**
**  Function    :   DdlGenObj::operator<
**
**  Description :   <
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-18593 - LJE - 150609
**
*************************************************************************/
bool DdlGenObj::operator< (const DdlGenObj& toTest) const
{
    if (this->entityDictId < toTest.entityDictId)
    {
        return true;
    }

    if (this->entityDictId == toTest.entityDictId)
    {
        if (this->objectDictId < toTest.objectDictId)
        {
            return true;
        }
    }

    return false;
};

/************************************************************************
**
**  Function    :   DdlGenFullTable::DdlGenFullTable()
**
**  Description :   Constructor
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13109 - LJE - 110311
**
*************************************************************************/
DdlGenFullTable::DdlGenFullTable(DdlGenAction& paramDdlGenAction,
                                 DdlGenContext& paramDdlGenContext,
                                 DICT_ENTITY_STP  paramDictEntityStp)
    : DdlGenMsg(&paramDdlGenContext)
    , ddlGenDbi(DdlObj_None, paramDdlGenContext, nullptr, nullptr, TargetTable_Undefined)
{
    this->getDdlGenContextPtr()->ddlGenAction = paramDdlGenAction;

    this->shXdAttribStp         = nullptr;
    this->objectEn              = NullEntity;
    this->ddlGenEntityPtr       = nullptr;
    this->shDictEntityStp       = this->m_mp.allocDynst(FILEINFO, S_DictEntity);
    this->bIdxToDo              = false;
    this->bStdIdxToDo           = false;
    this->bTrgToDo              = false;
    this->bTableToDo            = false;
    this->bUdTableToDo          = false;
    this->bExtTableToDo         = false;
    this->bSProcToDo            = false;
    this->bViewToDo             = false;
    this->bShortToDo            = false;
    this->bVerticalSearchToDo   = false;
    this->bVerticalPatternToDo  = false;
    this->bCheckAndFixDone      = false; /* PMSTA-26108 - LJE - 171007 */
    this->bbuildInMetaDict1Done = false;
    this->bbuildInMetaDict2Done = false;
    this->bHasShortDefined      = false;
    this->bPkChanged            = false;
    this->m_bTriggersDeleted    = false;
    this->m_sProcAppendFile     = false;
    this->m_dictEntityStp       = paramDictEntityStp;
    this->lastErrRetCode        = this->init();
}

/************************************************************************
**
**  Function    :   DdlGenFullTable::~DdlGenFullTable()
**
**  Description :   Destructor
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13109 - LJE - 110311
**
*************************************************************************/
DdlGenFullTable::~DdlGenFullTable()
{
    this->ddlGenContextPtr->rollback();

    for (auto it = this->derivedEntityList.begin(); it != this->derivedEntityList.end(); it++)
    {
        delete* it;
    }
}

/************************************************************************
**
**  Function    :   DdlGenFullTable::init()
**
**  Description :   Constructor
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13109 - LJE - 110311
**
*************************************************************************/
RET_CODE DdlGenFullTable::init()
{
    RET_CODE       ret = RET_SUCCEED;

    DdlGenProcessLogger    ddlGenProcessLogger(*this, ret, "Initialization");
    ddlGenProcessLogger.start();

    if ((ret = this->initConnection(nullptr, false)) != RET_SUCCEED)
    {
        return RET_DBA_INFO_NODATA;
    }

    this->msgSqlName = this->ddlGenContextPtr->ddlGenAction.m_entitySqlnameStr;

    this->ddlGenEntityPtr = this->ddlGenContextPtr->getDdlGenEntityPtr(this->msgSqlName, this->ddlGenContextPtr->ddlGenAction.m_targetSqlnameStr, false);
    this->ddlGenEntityPtr->setDdlGenActionInfo(this->getDdlGenAction());
    this->setMsgEntitySqlName(this->msgSqlName);
    this->setMsgSqlName(this->msgSqlName);

    if (this->m_dictEntityStp == nullptr)
    {
        this->m_dictEntityStp = DBA_GetEntityBySqlName(this->ddlGenContextPtr->ddlGenAction.m_entitySqlnameStr);

        if (this->m_dictEntityStp == nullptr)
        {
            this->m_dictEntityStp = DBA_GetEntityBySqlName(this->ddlGenContextPtr->ddlGenAction.m_entitySqlnameStr, true, true);
        }

        if (this->m_dictEntityStp != nullptr)
        {
            DBA_GetObjectEnum(this->m_dictEntityStp->entDictId, &this->objectEn);
        }
    }
    else
    {
        this->objectEn = this->m_dictEntityStp->objectEn;
    }

    this->shXdAttribStp = this->m_mp.allocDynst(FILEINFO, S_XdAttrib);

    bool bFullLoad = false;

    if (this->m_dictEntityStp != nullptr &&
        (this->m_dictEntityStp->entNatEn == EntityNat_Internal ||
         this->ddlGenContextPtr->ddlGenAction.m_execModeEn == DbObjExecMod_BuildFromTemplate))
    {
        this->ddlGenEntityPtr->setXdEntityFromDict(this->m_dictEntityStp);

        int    idIncrement = SYS_GetEnvUnsignedOrDefValue("IDENTITY_INCREMENT", 1);
        SET_INT(this->ddlGenEntityPtr->getXdEntityStp(), A_XdEntity_IdentityIncrement, idIncrement);
    }
    /* Install from scratch special case */
    else if (((this->getDdlGenAction().isBootStrapLevel() && this->getDdlGenAction().m_mainDdlObjNatEn != DbObjDdlObjNat_System) ||
              (ret = this->ddlGenEntityPtr->loadExdEntityInfo(true)) != RET_SUCCEED) &&
             this->m_dictEntityStp != nullptr &&
             (this->m_dictEntityStp->bIsInitEntity || this->ddlGenContextPtr->migrationMode != DdlGenContext::MigrationMode::None))
    {
        this->msgObjTypeStr = "Install table";

        this->bSProcToDo = false;
        this->bViewToDo = false;
        this->bTrgToDo = false;
        this->bTableToDo = false;
        this->bUdTableToDo = false;
        this->bExtTableToDo = false;
        this->bShortToDo = false;
        this->bVerticalSearchToDo = false;
        this->bVerticalPatternToDo = false;
        this->bCheckAndFixDone = false;

        this->ddlGenEntityPtr->setXdEntityFromDict(this->m_dictEntityStp);
    }
    else if (ret != RET_SUCCEED ||
             this->ddlGenEntityPtr->check() == false)
    {
        return RET_DBA_ERR_NODATA;
    }
    else
    {
        bFullLoad = true;
    }

    DBA_DYNFLD_STP xdEntityStp = this->getXdEntityStp();

    this->entNatureEn = static_cast<DBA_ENTITY_NAT_ENUM>(GET_ENUM(xdEntityStp, A_XdEntity_NatEn));

    if (GET_ENUM(xdEntityStp, A_XdEntity_DbRuleEn) == DbRule_Template &&
        this->m_dictEntityStp != nullptr &&
        this->getDdlGenAction().m_targetSqlnameStr.empty() == false)
    {
        SET_ENUM(xdEntityStp, A_XdEntity_DbRuleEn, DbRule_Standard);

        SET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_Table, TRUE);
        SET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_SProc, TRUE);
        SET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_Trigger, TRUE);
        SET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_Index, TRUE);

        SET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_Short, FALSE);

        SET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_ViewFullAllSecured, TRUE);
    }

    switch (this->entNatureEn)
    {
        case EntityNat_Custom:
            this->msgObjTypeStr = "User defined table";
            this->shortPrefixStr = "ude";
            break;
        case EntityNat_CustomDS:
            this->msgObjTypeStr = "Design Studio table";
            this->shortPrefixStr = "ds";
            break;
        case EntityNat_System:
            this->msgObjTypeStr = "System table";
            this->shortPrefixStr = "sys";
            break;
        case EntityNat_Standard:
            this->msgObjTypeStr = "Standard table";
            this->shortPrefixStr = "std";
            break;
        case EntityNat_Technical:
            this->msgObjTypeStr = "Technical table";
            this->shortPrefixStr = "tech";
            break;
        case EntityNat_Packaging:
            this->msgObjTypeStr = "Packaging table";
            this->shortPrefixStr = "pck";
            break;
        case EntityNat_PersistedFmt:
            this->msgObjTypeStr = "Persisted Format table";
            this->shortPrefixStr = "fmt";
            break;
        case EntityNat_SearchFmt:
            this->msgObjTypeStr = "Search Data Format table";
            this->shortPrefixStr = "srch";
            break;
        case EntityNat_ReportFmt:
            this->msgObjTypeStr = "Report Format table";
            this->shortPrefixStr = "rep";
            break;
        case EntityNat_TempTable:
            this->msgObjTypeStr = "Temporary table";
            this->shortPrefixStr = "tmp";
            break;
        case EntityNat_Tsl:
            this->msgObjTypeStr = "TSL table";
            this->shortPrefixStr = "tmp";
            break;
        case EntityNat_Questionnaire:
            this->msgObjTypeStr = "Questionnaire table";
            this->shortPrefixStr = "qu";
            break;
        case EntityNat_DerivedEntity:
            this->msgObjTypeStr = "Derived table";
            this->shortPrefixStr = "deriv";
            break;
            /* PMSTA-27352 - LJE - 170606 */
        case EntityNat_ModelBank:
            this->msgObjTypeStr = "Model Bank table";
            this->shortPrefixStr = "mb";
            break;
        case EntityNat_Internal:
            this->msgObjTypeStr = "Internal Entity";
            this->shortPrefixStr = "int";
            break;
        default:
            this->msgObjTypeStr = "Unknown table";
            this->shortPrefixStr = "na";
    }

    /* PMSTA-17813 - LJE - 140319 */
    FLAG_T showInGUIMenu = GET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_ShowInGUIMenu);
    SET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_ShowInGUIMenu, FALSE);

    MASK_T automaticMaskValue = GET_MASK(xdEntityStp, A_XdEntity_AutomaticMask);

    /* PMSTA-14452 - LJE - 121023 */
    if (automaticMaskValue == 0 ||
        GET_BIT(automaticMaskValue, Automatic_OppositeBehavior) == TRUE)
    {
        SET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_MetaDictionary, TRUE);

        if (this->ddlGenContextPtr->ddlGenAction.m_execModeEn == DbObjExecMod_BuildVirtualFromFmt)
        {
            SET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_Table, TRUE);
            SET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_Index, TRUE);
            SET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_ViewFullAllSecured, TRUE);

            SET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_SProc, FALSE);
            SET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_Trigger, FALSE);
            SET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_ViewFullAll, FALSE);
            SET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_ViewLightAll, FALSE);
            SET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_ViewFullAll4ForeignKey, FALSE);
        }
        else if (GET_FLAG(xdEntityStp, A_XdEntity_LogicalFlg) == TRUE ||
                 GET_ENUM(xdEntityStp, A_XdEntity_DbRuleEn) == DbRule_Template)
        {
            SET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_SProc, FALSE);
            SET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_Trigger, FALSE);
            SET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_Index, FALSE);
            SET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_ViewFullAllSecured, FALSE);
            SET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_ViewFullAll, FALSE);
            SET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_ViewLightAll, FALSE);
            SET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_ViewFullAll4ForeignKey, FALSE);
        }
        else
        {
            SET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_Table, TRUE);
            SET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_SProc, TRUE);
            SET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_Trigger, TRUE);
            SET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_Index, TRUE);

            SET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_ViewFullAllSecured, TRUE);
            SET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_ViewFullAll, TRUE);
            SET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_ViewFullAll4ForeignKey, TRUE);
        }

        if (GET_ENUM(xdEntityStp, A_XdEntity_DbRuleEn) == DbRule_NotMainTable &&
            IS_NULLFLD(xdEntityStp, A_XdEntity_PhysicalXdEntityId) == TRUE)
        {
            SET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_ViewFullAll, FALSE);
            SET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_ViewLightAll, FALSE);
        }
    }

    SET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_ShowInGUIMenu, showInGUIMenu);

    if (GET_BIT(automaticMaskValue, Automatic_OppositeBehavior) == FALSE)
    {
        SET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_MetaDictionary, TRUE);
    }

    if (this->entNatureEn == EntityNat_SearchFmt)
    {
        SET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_Table, TRUE);
        SET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_Index, TRUE);
        SET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_SProc, FALSE);
        SET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_Trigger, FALSE);
        SET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_ViewFullAllSecured, TRUE);
        SET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_ViewFullAll, TRUE);
        SET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_ViewLightAll, TRUE);
        SET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_ViewFullAll4ForeignKey, TRUE);
    }
    else if (this->entNatureEn == EntityNat_ReportFmt)
    {
        SET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_Table, TRUE);
        SET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_Index, TRUE);
        SET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_SProc, FALSE);
        SET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_Trigger, FALSE);
        SET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_ViewFullAllSecured, FALSE);
        SET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_ViewFullAll, FALSE);
        SET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_ViewLightAll, FALSE);
        SET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_ViewFullAll4ForeignKey, FALSE);
    }
    else if (this->entNatureEn == EntityNat_TempTable)
    {
        SET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_Table, TRUE);
        SET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_Index, TRUE);
        SET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_SProc, FALSE);
        SET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_Trigger, FALSE);
        SET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_ShowInGUIMenu, FALSE);
        SET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_ViewFullAllSecured, FALSE);
        SET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_ViewFullAll, FALSE);
        SET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_ViewLightAll, FALSE);
        SET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_ViewFullAll4ForeignKey, FALSE);
    }
    else if (this->entNatureEn == EntityNat_DerivedEntity)
    {
        SET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_Table, TRUE);
        SET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_SProc, FALSE);
        SET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_Trigger, TRUE);
        SET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_Index, TRUE);
        SET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_ViewFullAllSecured, FALSE);
        SET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_ViewFullAll, FALSE);
        SET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_ViewLightAll, FALSE);
        SET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_ViewFullAll4ForeignKey, FALSE);
    }

    /* PMSTA-30453 - LJE - 180412 */
    if (GET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_ViewFullAllSecured) == TRUE)
    {
        SET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_ViewLightAll, TRUE);
        SET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_ViewShortSecured, TRUE);
    }

    if (GET_BIT(automaticMaskValue, Automatic_OppositeBehavior) == TRUE)
    {
        SET_MASK(xdEntityStp, A_XdEntity_AutomaticMask,
                 GET_MASK(xdEntityStp, A_XdEntity_AutomaticMask) & (~automaticMaskValue));
    }

    /* PMSTA-28698 - LJE - 180516 - Rewriting */
    this->bIdxToDo      = false;
    this->bUdTableToDo  = false;
    this->bExtTableToDo = (GET_FLAG(xdEntityStp, A_XdEntity_PrecompFlg) == TRUE);
    this->bTableToDo    = false;
    this->bViewToDo     = false;

    if (GET_FLAG(xdEntityStp, A_XdEntity_LogicalFlg) == FALSE &&
        GET_ENUM(xdEntityStp, A_XdEntity_DbRuleEn) != DbRule_NotInDatabase &&
        GET_ENUM(xdEntityStp, A_XdEntity_DbRuleEn) != DbRule_TableBasedOnView &&
        GET_ENUM(xdEntityStp, A_XdEntity_DbRuleEn) != DbRule_Template &&
        GET_ENUM(xdEntityStp, A_XdEntity_DbRuleEn) != DbRule_NotMainTable)
    {
        this->bTableToDo = true;
    }
    else if (this->getDdlGenAction().m_execModeEn == DbObjExecMod_BuildVirtualFromFmt ||
             this->getDdlGenAction().m_execModeEn == DbObjExecMod_BuildFromTemplate ||
             this->getDdlGenAction().m_execModeEn == DbObjExecMod_RemoveFromTemplate)
    {
        SET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_Table, TRUE);
        SET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_ViewFullAllSecured, TRUE);
        this->bTableToDo = true;
    }

    if (GET_FLAG(xdEntityStp, A_XdEntity_LogicalFlg) == FALSE &&
        GET_FLAG(xdEntityStp, A_XdEntity_CustAuthFlg) == TRUE &&
        (GET_ENUM(xdEntityStp, A_XdEntity_DbRuleEn) == DbRule_Standard ||
         GET_ENUM(xdEntityStp, A_XdEntity_DbRuleEn) == DbRule_ShadowTable ||
         (GET_ENUM(xdEntityStp, A_XdEntity_DbRuleEn) == DbRule_NotMainTable && IS_NULLFLD(xdEntityStp, A_XdEntity_PhysicalXdEntityId))))
    {
        this->bUdTableToDo = true;
    }

    if (this->bTableToDo == false && this->bUdTableToDo == false)
    {
        SET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_Table, FALSE);
        SET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_Trigger, FALSE);
        SET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_Index, FALSE);
    }

    if (GET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_Index) == TRUE || this->bUdTableToDo)
    {
        this->bIdxToDo = true;
    }

    if (GET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_Table) == FALSE)
    {
        SET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_Trigger, FALSE);
        SET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_Index, FALSE);
    }

    if (GET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_SProc) == TRUE)
    {
        this->bSProcToDo = true;
    }
    else
    {
        this->bSProcToDo = false;
    }

    if (GET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_Trigger) == TRUE)
    {
        this->bTrgToDo = true;
    }
    else
    {
        this->bTrgToDo = false;
    }

    if (GET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_ViewFullAllSecured) == TRUE ||
        GET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_ViewFullAll) == TRUE ||
        GET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_ViewLightAll) == TRUE ||
        GET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_ViewShortSecured) == TRUE ||
        GET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_ViewShort) == TRUE ||
        GET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_ViewFullAll4ForeignKey) == TRUE)
    {
        this->bViewToDo = true;
    }

    /* PMSTA-nuodb - LJE - 190418 */
    if (GET_ENUM(xdEntityStp, A_XdEntity_DbRuleEn) == DbRule_ShadowTable)
    {
        SET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_ViewFullAll, TRUE);
    }

    if (GET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_Short) == TRUE ||
        GET_ENUM(xdEntityStp, A_XdEntity_DbRuleEn) == DbRule_ShadowTable)
    {
        this->bShortToDo = true;
    }
    else
    {
        this->bShortToDo = false;
    }

    /* Manage automatic short structure */
    if (this->bShortToDo == false &&
        GET_FLAG(xdEntityStp, A_XdEntity_LogicalFlg) == FALSE &&
        this->entNatureEn != EntityNat_PersistedFmt &&
        this->entNatureEn != EntityNat_ReportFmt &&
        this->entNatureEn != EntityNat_Questionnaire &&
        this->entNatureEn != EntityNat_SearchFmt &&
        this->entNatureEn != EntityNat_DerivedEntity)
    {
        this->bShortToDo = true;
        for (int i = 0; i < this->ddlGenEntityPtr->getXdAttribNbr(); i++)
        {
            DBA_DYNFLD_STP currXdAttribStp = this->ddlGenEntityPtr->getXdAttrib(i);

            if (IS_NULLFLD(currXdAttribStp, A_XdAttrib_ShortIdx) == FALSE &&
                GET_A_XdAttrib_FeatureEn(currXdAttribStp) == XdEntityFeatureFeatureEn::None)
            {
                this->bShortToDo = false;
                break;
            }
        }

        if (this->bShortToDo)
        {
            SET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_Short, TRUE);
        }
    }

    this->bStdIdxToDo = this->bIdxToDo;

    /* ORACLE - LJE - 141027 - No automatic indexes for temporary tables */
    if (this->entNatureEn == EntityNat_TempTable)
    {
        this->bStdIdxToDo = false;
        this->bTrgToDo = false;
    }
    else if (this->entNatureEn == EntityNat_ReportFmt)
    {
        this->bTrgToDo = false;
        this->bSProcToDo = false;
        this->bViewToDo = false;
    }
    /* PMSTA-32145 - LJE - 180718 */
    else if (this->entNatureEn == EntityNat_DerivedEntity)
    {
        this->bSProcToDo = false;
        this->bViewToDo = false;
    }

    if (bFullLoad)
    {
        DdlGenConnGuard     ddlGenConnGuard(*this->ddlGenContextPtr);
        DdlGenRequestHelper requestHelper(&ddlGenConnGuard.getDbiConn(), *this->ddlGenContextPtr);

        bool bResetAction = this->ddlGenContextPtr->ddlGenAction.m_subRequest ||
            (this->ddlGenContextPtr->ddlGenAction.m_mainDdlObjNatEn != DbObjDdlObjNat_AllTable &&
             this->ddlGenContextPtr->ddlGenAction.m_mainDdlObjNatEn != DbObjDdlObjNat_TslExtension);

        if ((FEATURE_AUTH_ENUM)GET_ENUM(xdEntityStp, A_XdEntity_UpdFctAuthEn) == FeatureAuth_Enable)
        {
            this->ddlGenEntityPtr->addXdEntityFeature(requestHelper,
                                                      XdEntityFeatureFeatureEn::UpdateFunction,
                                                      GenRule_Standard,
                                                      (FEATURE_AUTH_ENUM)GET_ENUM(xdEntityStp, A_XdEntity_UpdFctAuthEn),
                                                      bResetAction);
        }
        if ((FEATURE_AUTH_ENUM)GET_ENUM(xdEntityStp, A_XdEntity_ExternalSeqAuthEn) == FeatureAuth_Enable)
        {
            this->ddlGenEntityPtr->addXdEntityFeature(requestHelper,
                                                      XdEntityFeatureFeatureEn::ExternalSequencing,
                                                      GenRule_Standard,
                                                      (FEATURE_AUTH_ENUM)GET_ENUM(xdEntityStp, A_XdEntity_ExternalSeqAuthEn),
                                                      bResetAction);
        }
        if ((FEATURE_AUTH_ENUM)GET_ENUM(xdEntityStp, A_XdEntity_DlmAuthEn) != FeatureAuth_Forbidden)
        {
            this->ddlGenEntityPtr->addXdEntityFeature(requestHelper,
                                                      XdEntityFeatureFeatureEn::DLM,
                                                      GenRule_AlwaysButVirtual,
                                                      (FEATURE_AUTH_ENUM)GET_ENUM(xdEntityStp, A_XdEntity_DlmAuthEn),
                                                      bResetAction);
        }
        if ((DICT_BUILD_RULE_ENUM)GET_ENUM(xdEntityStp, A_XdEntity_DictBuildRuleEn) == DictBuildRule_Sh)
        {
            this->ddlGenEntityPtr->addXdEntityFeature(requestHelper,
                                                      XdEntityFeatureFeatureEn::ShadowEntity,
                                                      GenRule_Standard,
                                                      FeatureAuth_Enable,
                                                      bResetAction);
        }
        if ((DICT_BUILD_RULE_ENUM)GET_ENUM(xdEntityStp, A_XdEntity_DictBuildRuleEn) == DictBuildRule_Pk ||
            (DICT_BUILD_RULE_ENUM)GET_ENUM(xdEntityStp, A_XdEntity_DictBuildRuleEn) == DictBuildRule_Bk ||
            (DICT_BUILD_RULE_ENUM)GET_ENUM(xdEntityStp, A_XdEntity_DictBuildRuleEn) == DictBuildRule_PkBk)
        {
            this->ddlGenEntityPtr->addXdEntityFeature(requestHelper,
                                                      XdEntityFeatureFeatureEn::ExternalPkEntity,
                                                      GenRule_Standard,
                                                      FeatureAuth_Enable,
                                                      bResetAction);
        }

        /* PMSTA-29879 - LJE - 180207 */
        if ((ENTITY_SECURITY_LEVEL_ENUM)GET_ENUM(xdEntityStp, A_XdEntity_SecurityLevelEn) == EntSecuLevel_Secured ||
            (ENTITY_SECURITY_LEVEL_ENUM)GET_ENUM(xdEntityStp, A_XdEntity_SecurityLevelEn) == EntSecuLevel_Secured2ndLevel)
        {
            this->ddlGenEntityPtr->addXdEntityFeature(requestHelper,
                                                      XdEntityFeatureFeatureEn::Security,
                                                      GenRule_Standard,
                                                      FeatureAuth_Enable,
                                                      bResetAction);
            this->ddlGenEntityPtr->addXdEntityFeature(requestHelper,
                                                      XdEntityFeatureFeatureEn::AccessRightManagement,
                                                      GenRule_Standard,
                                                      FeatureAuth_Enable,
                                                      bResetAction);

            if ((ENTITY_SECURITY_LEVEL_ENUM)GET_ENUM(xdEntityStp, A_XdEntity_SecurityLevelEn) == EntSecuLevel_Secured2ndLevel)
            {
                this->ddlGenEntityPtr->addXdEntityFeature(requestHelper,
                                                          XdEntityFeatureFeatureEn::AdditionalSecurity,
                                                          GenRule_Standard,
                                                          FeatureAuth_Enable,
                                                          bResetAction);
            }
        }

        if (this->getDdlGenAction().m_mainDdlObjNatEn == DbObjDdlObjNat_TslExtension &&
            this->bExtTableToDo == false &&
            /* PMSTA-45773 - LJE - 210716 */
            this->entNatureEn != EntityNat_SearchFmt &&
            this->entNatureEn != EntityNat_PersistedFmt &&
            this->entNatureEn != EntityNat_ReportFmt)
        {
            ret = RET_GEN_INFO_NOACTION;
        }
    }

    this->finishConnection(ret);

    return (ret);
}

/************************************************************************
**
**  Function    :   DdlGenFullTable::initConnection()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:  PMSTA-14452 - LJE - 130116
**
*************************************************************************/
RET_CODE DdlGenFullTable::initConnection(DdlGenFile* localFileHeperPtr, bool paramBInTran)
{
    return this->ddlGenContextPtr->initConnection(localFileHeperPtr, paramBInTran);
}

/************************************************************************
**
**  Function    :   DdlGenFullTable::finishConnection()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:  PMSTA-14452 - LJE - 130116
**
*************************************************************************/
void DdlGenFullTable::finishConnection(RET_CODE retStatus)
{
    if (RET_GET_LEVEL(retStatus) != RET_LEV_ERROR)
    {
        this->ddlGenContextPtr->commit();
    }
    else
    {
        this->ddlGenContextPtr->rollback();
    }

    this->lastErrRetCode = retStatus;
}

/************************************************************************
**
**  Function    :   DdlGenFullTable::setAttribStatus()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13122 - LJE - 120611
**
*************************************************************************/
RET_CODE DdlGenFullTable::setAttribStatus(DdlGenRequestHelper& requestHelper, DBA_DYNFLD_STP paramXdAttribStp, DBA_DYNFLD_STP paramDictAttribStp, XD_STATUS_ENUM xdStatusEn)
{
    RET_CODE ret = RET_SUCCEED;

    SET_ENUM(paramXdAttribStp, A_XdAttrib_XdActionEn, XdAction_None);
    SET_ENUM(paramXdAttribStp, A_XdAttrib_XdStatusEn, xdStatusEn);

    requestHelper.dbaCall(Update,
                          XdAttrib,
                          DBA_ROLE_STATUS,
                          paramXdAttribStp);

    if (paramDictAttribStp != nullptr &&
        IS_NULLFLD(paramDictAttribStp, A_DictAttr_DictId) == FALSE)
    {
        SET_ENUM(paramDictAttribStp, A_DictAttr_XdStatusEn, xdStatusEn);

        requestHelper.dbaCall(Update,
                              DictAttr,
                              DBA_ROLE_STATUS,
                              paramDictAttribStp);
    }
    return (ret);
}

/************************************************************************
**
**  Function    :   DDL_CmpXdAttribById()
**
**  Description :
**
**  Arguments   :   ptr1   pointer on dynamic structure
**                  ptr2   pointer on dynamic structure
**
**  Return      :   a negative value if first element < second element
**                  a zero value     if first element = second element
**                  a positive value if first element > second element
**
*************************************************************************/
STATIC int DDL_CmpXdAttribById(DBA_DYNFLD_STP* ptr1, DBA_DYNFLD_STP* ptr2)
{
    int cmp = 0;

    if ((cmp = CMP_DYNFLD((*ptr1), (*ptr2), A_XdAttrib_Id, A_XdAttrib_Id, IdType)) != 0)
        return cmp;

    return cmp;
}

/************************************************************************
**
**  Function    :   DDL_CmpXdAttribByShortIdx()
**
**  Description :
**
**  Arguments   :   ptr1   pointer on dynamic structure
**                  ptr2   pointer on dynamic structure
**
**  Return      :   a negative value if first element < second element
**                  a zero value     if first element = second element
**                  a positive value if first element > second element
**
*************************************************************************/
STATIC int DDL_CmpXdAttribByShortIdx(DBA_DYNFLD_STP* ptr1, DBA_DYNFLD_STP* ptr2)
{
    int cmp = 0;

    if ((cmp = CMP_DYNFLD((*ptr1), (*ptr2), A_XdAttrib_ShortIdx, A_XdAttrib_ShortIdx, SmallintType)) != 0)
        return cmp;

    if ((cmp = CMP_DYNFLD((*ptr1), (*ptr2), A_XdAttrib_Prog, A_XdAttrib_Prog, IntType)) != 0)
        return cmp;

    if ((cmp = CMP_DYNFLD((*ptr1), (*ptr2), A_XdAttrib_Id, A_XdAttrib_Id, IdType)) != 0)
        return cmp;

    return cmp;
}

/************************************************************************
**
**  Function    :   DDL_CmpXdAttribByDispRank()
**
**  Description :
**
**  Arguments   :   ptr1   pointer on dynamic structure
**                  ptr2   pointer on dynamic structure
**
**  Return      :   a negative value if first element < second element
**                  a zero value     if first element = second element
**                  a positive value if first element > second element
**
*************************************************************************/
STATIC int DDL_CmpXdAttribByDispRank(DBA_DYNFLD_STP* ptr1, DBA_DYNFLD_STP* ptr2)
{
    int cmp = 0;

    if ((cmp = CMP_DYNFLD((*ptr1), (*ptr2), A_XdAttrib_DispRank, A_XdAttrib_DispRank, SmallintType)) != 0)
        return cmp;

    if ((cmp = CMP_DYNFLD((*ptr1), (*ptr2), A_XdAttrib_Prog, A_XdAttrib_Prog, IntType)) != 0)
        return cmp;

    if ((cmp = CMP_DYNFLD((*ptr1), (*ptr2), A_XdAttrib_Id, A_XdAttrib_Id, IdType)) != 0)
        return cmp;

    return cmp;
}

/************************************************************************
**
**  Function    :   DDL_CmpXdAttribByIdByKey()
**
**  Description :   Sort ESE
**
**  Arguments   :   ptr1   pointer on dynamic structure
**                  ptr2   pointer on dynamic structure
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation    :   PMSTA08737 - LJE - 091113
**
*************************************************************************/
STATIC int DDL_CmpXdAttribByIdByKey(const void* ptr1, const void* ptr2)
{
    const ID_T* key = (const ID_T*)ptr1;
    const DBA_DYNFLD_STP* p = (const DBA_DYNFLD_STP*)ptr2;

    if ((*key) > GET_ID((*p), A_XdAttrib_Id))
        return 1;
    if ((*key) < GET_ID((*p), A_XdAttrib_Id))
        return -1;

    return 0;
}

/************************************************************************
**
**  Function    :   DdlGenFullTable::checkAllAttributes()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13122 - LJE - 120502
**
*************************************************************************/
RET_CODE DdlGenFullTable::checkAllAttributes()
{
    RET_CODE  ret = RET_SUCCEED;
    int       i;

    for (i = 0; i < this->ddlGenEntityPtr->getXdAttribNbr(); i++)
    {
        DBA_DYNFLD_STP currXdAttribStp = this->ddlGenEntityPtr->getXdAttrib(i);

        if (GET_ENUM(currXdAttribStp, A_XdAttrib_XdActionEn) != XdAction_ToInsert)
        {
            continue;
        }

        /* PMSTA-43738 - LJE - 210218 - Reduce the nature list */
        if (this->entNatureEn == EntityNat_Standard ||
            this->entNatureEn == EntityNat_System ||
            this->entNatureEn == EntityNat_ModelBank ||
            this->entNatureEn == EntityNat_Custom ||
            this->entNatureEn == EntityNat_CustomDS)
        {
            /* Check denomination attribute and the logical attribute */
            if (strcmp("denom", GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName)) == 0)
            {
                if (GET_DICT(currXdAttribStp, A_XdAttrib_DataTpDictId) == DATATYPE_ENUM_TO_DICT(IdType))
                {
                    ret = RET_DBA_ERR_MD;
                    this->printMsg(ret, "Bad data-type for reserved attribute " + string(GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName)) + ", must not be id_t");
                }
                else if (GET_FLAG(currXdAttribStp, A_XdAttrib_LogicalFlg) == TRUE)
                {
                    ret = RET_DBA_ERR_MD;
                    this->printMsg(ret, "Logical attribute " + string(GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName)) + " not allowed (reserved attribute)");
                }
            }
            else if (strcmp("denomination", GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName)) == 0)
            {
                if (GET_DICT(currXdAttribStp, A_XdAttrib_DataTpDictId) != DATATYPE_ENUM_TO_DICT(IdType))
                {
                    ret = RET_DBA_ERR_MD;
                    this->printMsg(ret, "Bad data-type for reserved attribute " + string(GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName)) + ", must be id_t");
                }
                else if (GET_FLAG(currXdAttribStp, A_XdAttrib_LogicalFlg) == FALSE)
                {
                    ret = RET_DBA_ERR_MD;
                    this->printMsg(ret, "The reserved attribute " + string(GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName)) + " must be logical");
                }
            }
        }

        if (GET_ENUM(currXdAttribStp, A_XdAttrib_CustomFlg) != Custom_No)
        {
            if (GET_FLAG(this->getXdEntityStp(), A_XdEntity_CustAuthFlg) == FALSE &&
                (DB_RULE_ENUM)GET_ENUM(this->getXdEntityStp(), A_XdEntity_DbRuleEn) != DbRule_PartialSpecialization)
            {
                this->printMsg(RET_DBA_INFO_NODATA, "Attribute " + string(GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName)) + ": Custom attribute removed because the entity is not able");
                SET_ENUM(currXdAttribStp, A_XdAttrib_XdActionEn, XdAction_ToDelete);
            }
            else if (GET_FLAG(currXdAttribStp, A_XdAttrib_PrimaryFlg) == TRUE)
            {
                ret = RET_DBA_ERR_MD;
                this->printMsg(ret, "Attribute " + string(GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName)) + ": a primary key cannot be custom field");
            }
            else if (GET_FLAG(currXdAttribStp, A_XdAttrib_BusKeyFlg) == TRUE)
            {
                ret = RET_DBA_ERR_MD;
                this->printMsg(ret, "Attribute " + string(GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName)) + ": a business key cannot be custom field");
            }
        }

        if (IS_NULLFLD(currXdAttribStp, A_XdAttrib_DataTpDictId))
        {
            ret = RET_DBA_ERR_MD;
            this->printMsg(ret, "Attribute " + string(GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName)) + ": the data-type must be defined");
        }
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenFullTable::checkShortIndex()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-14452 - LJE - 121214
**				    PMSTA-23096 - EFE - 160503 : migration from 10.0.01-> 20.0.01
**							   removed test on physical field and set other restrictions in isShortDictCriteria
**
*************************************************************************/
RET_CODE DdlGenFullTable::checkShortIndex(bool bUpdShortIdx)
{
    RET_CODE         ret = RET_SUCCEED;
    int              i;

    if (this->bCheckAndFixDone)
    {
        return ret;
    }

    SMALLINT_T       shortIdxValue = 0;
    SMALLINT_T       lastVirtualShortIdx = 0;
    bool             bValidShort = false;

    MemoryPool       mp;

    DBA_DYNFLD_STP* xdAttribByShortIdxTab = this->ddlGenEntityPtr->getSortedXdAttribTab((TLS_CMPFCT*)DDL_CmpXdAttribByShortIdx);
    mp.owner(xdAttribByShortIdxTab);

    for (i = 0; i < this->ddlGenEntityPtr->getXdAttribNbr(); i++)
    {
        if (GET_ENUM(xdAttribByShortIdxTab[i], A_XdAttrib_XdActionEn) != XdAction_ToInsert)
        {
            continue;
        }

        if (IS_NULLFLD(xdAttribByShortIdxTab[i], A_XdAttrib_ShortIdx) == FALSE)
        {
            if (GET_SMALLINT(xdAttribByShortIdxTab[i], A_XdAttrib_ShortDispRank) < 0)
            {
                lastVirtualShortIdx = GET_SMALLINT(xdAttribByShortIdxTab[i], A_XdAttrib_ShortIdx) + 1;
            }

            if (shortIdxValue != GET_SMALLINT(xdAttribByShortIdxTab[i], A_XdAttrib_ShortIdx))
            {
                ret = RET_DBA_ERR_MD_INVALID_VALUE;
                stringstream msgStream;
                msgStream
                    << "Wrong values in the short index (short_index_n) for attribute " << GET_SYSNAME(xdAttribByShortIdxTab[i], A_XdAttrib_SqlName)
                    << ", expected value " << (int)shortIdxValue
                    << " but " << (int)GET_SMALLINT(xdAttribByShortIdxTab[i], A_XdAttrib_ShortIdx) << " is defined";
                this->printMsg(ret, msgStream.str());
            }
            bValidShort = true;
            shortIdxValue++;
        }
    }

    if (lastVirtualShortIdx != 0 && lastVirtualShortIdx < shortIdxValue)
    {
        ret = RET_DBA_ERR_MD_INVALID_VALUE;
        stringstream msgStream;
        msgStream
            << "The virtual short attribute (short_disp_rank_n < 0) must be placed at the end of the short_index_n definition";
        this->printMsg(ret, msgStream.str());
    }

    if (bValidShort == false &&
        (this->entNatureEn == EntityNat_Custom ||
         this->entNatureEn == EntityNat_CustomDS ||
         this->entNatureEn == EntityNat_ModelBank) &&
        GET_FLAG(this->getXdEntityStp(), A_XdEntity_LogicalFlg) == FALSE)
    {
        this->bShortToDo = true;

        if (bUpdShortIdx)
        {
            for (i = 0; i < this->ddlGenEntityPtr->getXdAttribNbr(); i++)
            {
                DBA_DYNFLD_STP currXdAttribStp = xdAttribByShortIdxTab[i];

                /* PMSTA-30294 - LJE - 180226 */
                if (GET_ENUM(currXdAttribStp, A_XdAttrib_XdActionEn) != XdAction_ToInsert)
                {
                    continue;
                }

                if (this->isShortDictCriteria(i))
                {
                    SET_SMALLINT(currXdAttribStp, A_XdAttrib_ShortIdx, shortIdxValue++);
                }
            }
        }
    }

    /* PMSTA-29789 - LJE - 180119 - Add check */
    if (bUpdShortIdx == false)
    {
        map<SMALLINT_T, string> shortDispRankMap;
        map<SMALLINT_T, string> shortIdxMap;

        for (i = 0; i < this->ddlGenEntityPtr->getXdAttribNbr(); i++)
        {
            DBA_DYNFLD_STP currXdAttribStp = this->ddlGenEntityPtr->getXdAttrib(i);

            if (GET_ENUM(currXdAttribStp, A_XdAttrib_XdActionEn) != XdAction_ToInsert)
            {
                continue;
            }

            if (IS_NULLFLD(currXdAttribStp, A_XdAttrib_ShortIdx) == FALSE)
            {
                string sqlName = GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName);

                SMALLINT_T shortIdx = GET_SMALLINT(currXdAttribStp, A_XdAttrib_ShortIdx);

                auto chkIt = shortIdxMap.find(shortIdx);
                if (chkIt == shortIdxMap.end())
                {
                    shortIdxMap.insert(make_pair(shortIdx, sqlName));
                }
                else
                {
                    stringstream msg;
                    ret = RET_DBA_ERR_MD_INVALID_VALUE;
                    msg << "Duplicate the short index values (short_index_n=" << (int)chkIt->first << ") for attributes " << chkIt->second << " and " << sqlName;
                    this->printMsg(ret, msg.str());
                }

                if (IS_NULLFLD(currXdAttribStp, A_XdAttrib_ShortDispRank) == FALSE && GET_SMALLINT(currXdAttribStp, A_XdAttrib_ShortDispRank) >= 0)
                {
                    SMALLINT_T shortDispRank = GET_SMALLINT(currXdAttribStp, A_XdAttrib_ShortDispRank);

                    auto shortChkIt = shortDispRankMap.find(shortDispRank);
                    if (shortChkIt == shortDispRankMap.end())
                    {
                        shortDispRankMap.insert(make_pair(shortDispRank, sqlName));
                    }
                    else
                    {
                        stringstream msg;
                        ret = RET_DBA_ERR_MD_INVALID_VALUE;
                        msg << "Duplicate the short display rank values (short_disp_rank_n=" << (int)shortChkIt->first << ") for attributes " << shortChkIt->second << " and " << sqlName;
                        this->printMsg(ret, msg.str());
                    }
                }
            }
        }
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenFullTable::computeProgN()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-14452 - LJE - 121105
**
*************************************************************************/
RET_CODE DdlGenFullTable::computeProgN()
{
    MemoryPool     mp;

    RET_CODE       ret = RET_SUCCEED;
    DBA_DYNFLD_STP xdEntityStp = this->getXdEntityStp();
    FIELD_IDX_T    progN = 0;
    SMALLINT_T     dispRankN = 1;
    SMALLINT_T     shortIndexN = 0;
    int            precompNbr = 0;
    int            modelBankNbr = 0;
    int            udNbr = 0;
    bool           bAllProgNIsNull = true;
    bool           bAllDbProgNIsNull = true;
    bool           bAllDispRankIsNull = true;
    int            xdAttribNbr = this->ddlGenEntityPtr->getXdAttribNbr();

    if (this->getDdlGenAction().m_mainDdlObjNatEn == DbObjDdlObjNat_TslExtension ||
        this->getDdlGenAction().m_fromImport)
    {
        for (int i = 0; i < xdAttribNbr; i++)
        {
            DBA_DYNFLD_STP currXdAttribStp = this->ddlGenEntityPtr->getXdAttrib(i);

            if (GET_FLAG(currXdAttribStp, A_XdAttrib_PrecompFlg) == FALSE &&
                GET_FLAG(currXdAttribStp, A_XdAttrib_LogicalFlg) == FALSE)
            {
                DBA_DYNFLD_STP dbXdAttribStp = this->ddlGenEntityPtr->getDbXdAttribBySqlName(GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName));

                if (dbXdAttribStp != nullptr &&
                    IS_NULLFLD(dbXdAttribStp, A_XdAttrib_Prog) == false)
                {
                    COPY_DYNFLD(currXdAttribStp, A_XdAttrib, A_XdAttrib_Prog, dbXdAttribStp, A_XdAttrib, A_XdAttrib_Prog);
                    COPY_DYNFLD(currXdAttribStp, A_XdAttrib, A_XdAttrib_OldProg, dbXdAttribStp, A_XdAttrib, A_XdAttrib_Prog);
                    COPY_DYNFLD(currXdAttribStp, A_XdAttrib, A_XdAttrib_ShortIdx, dbXdAttribStp, A_XdAttrib, A_XdAttrib_ShortIdx);
                    COPY_DYNFLD(currXdAttribStp, A_XdAttrib, A_XdAttrib_DispRank, dbXdAttribStp, A_XdAttrib, A_XdAttrib_DispRank);
                }
            }
        }
    }

    this->ddlGenEntityPtr->sortAttributes();

    /* PMSTA-26250 - LJE - 170410 */
    int logicalRankN = 0;
    for (int i = 0; i < xdAttribNbr; i++)
    {
        DBA_DYNFLD_STP currXdAttribStp = this->ddlGenEntityPtr->getXdAttrib(i);

        if (GET_FLAG(currXdAttribStp, A_XdAttrib_LogicalFlg) == TRUE)
        {
            SET_NULL_INT(currXdAttribStp, A_XdAttrib_OldProg);
            SET_NULL_INT(currXdAttribStp, A_XdAttrib_DbProg);

            if (DdlGen::getScriptControlSqlName().compare(GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName)) == 0)
            {
                SET_INT(currXdAttribStp, A_XdAttrib_Prog, PROG_N_SCPT_CTRL);
                SET_SMALLINT(currXdAttribStp, A_XdAttrib_DispRank, DISP_RANK_SCPT_CTRL);
            }
            else
            {
                SET_INT(currXdAttribStp, A_XdAttrib_Prog, PROG_N_START_LOGICAL + logicalRankN++);
            }
        }
        else if (GET_A_XdAttrib_FeatureEn(currXdAttribStp) == XdEntityFeatureFeatureEn::None &&
                 GET_FLAG(currXdAttribStp, A_XdAttrib_CustomFlg) == FALSE &&
                 GET_FLAG(currXdAttribStp, A_XdAttrib_PrecompFlg) == FALSE &&
                 GET_FLAG(currXdAttribStp, A_XdAttrib_CustomFlg) == FALSE &&
                 GET_FLAG(currXdAttribStp, A_XdAttrib_ShortOnlyFlg) == FALSE)
        {
            if (IS_NULLFLD(currXdAttribStp, A_XdAttrib_Prog) == FALSE)
            {
                bAllProgNIsNull = false;
            }
            if (IS_NULLFLD(currXdAttribStp, A_XdAttrib_DispRank) == FALSE)
            {
                bAllDispRankIsNull = false;
            }
        }

        if (IS_NULLFLD(currXdAttribStp, A_XdAttrib_ShortIdx) == FALSE)
        {
            this->bHasShortDefined = true;
        }

        if (IS_NULLFLD(currXdAttribStp, A_XdAttrib_DbProg) == false)
        {
            bAllDbProgNIsNull = false;
        }
    }

    this->bNoShortOnEntity = (this->bHasShortDefined == false &&
                              this->objectEn != NullEntity &&
                              GET_ADMINGUIST(this->objectEn) == GET_EDITGUIST(this->objectEn));

    this->ddlGenEntityPtr->sortAttributes();

    /* PMSTA-49199 - LJE - 220608 - Keep order on some cases */
    if (this->getDdlGenAction().m_mainDdlObjNatEn != DbObjDdlObjNat_TslExtension &&
        GET_ENUM(xdEntityStp, A_XdEntity_NatEn) != EntityNat_System &&
        (bAllDbProgNIsNull ||
         (GET_ENUM(xdEntityStp, A_XdEntity_SecurityLevelEn) != EntSecuLevel_InsertAllowed &&
          GET_ENUM(xdEntityStp, A_XdEntity_SecurityLevelEn) != EntSecuLevel_InsertDeleteAllowed)))
    {
        /* Define some sorting rules */
        for (int i = 0; i < xdAttribNbr; i++)
        {
            DBA_DYNFLD_STP currXdAttribStp = this->ddlGenEntityPtr->getXdAttrib(i);

            /* Define in the import file, nothing to do */
            if (GET_FLAG(currXdAttribStp, A_XdAttrib_LogicalFlg) == TRUE &&
                GET_INT(currXdAttribStp, A_XdAttrib_Prog) != PROG_N_SCPT_CTRL)
            {
                if (bAllProgNIsNull ||
                    IS_NULLFLD(currXdAttribStp, A_XdAttrib_Prog) == TRUE)
                {
                    SET_INT(currXdAttribStp, A_XdAttrib_Prog, PROG_N_INIT_LOGICAL);
                }
            }
            /* Primary key attribute at the beginning */
            else if (GET_FLAG(currXdAttribStp, A_XdAttrib_PrimaryFlg) == TRUE)
            {
                if (bAllProgNIsNull ||
                    IS_NULLFLD(currXdAttribStp, A_XdAttrib_Prog) == TRUE)
                {
                    SET_INT(currXdAttribStp, A_XdAttrib_Prog, PROG_N_PK);

                    if (CMP_DYNFLD(xdEntityStp, currXdAttribStp, A_XdEntity_ParentXdAttribId, A_XdAttrib_Id, IdType) == 0)
                    {
                        SET_INT(currXdAttribStp, A_XdAttrib_Prog, PROG_N_PK - 50);
                    }
                }
            }
            /* Business key just after */
            else if (GET_FLAG(currXdAttribStp, A_XdAttrib_BusKeyFlg) == TRUE)
            {
                if (bAllProgNIsNull ||
                    IS_NULLFLD(currXdAttribStp, A_XdAttrib_Prog) == TRUE)
                {
                    SET_INT(currXdAttribStp, A_XdAttrib_Prog, PROG_N_BK);

                    if (CMP_DYNFLD(xdEntityStp, currXdAttribStp, A_XdEntity_ParentXdAttribId, A_XdAttrib_Id, IdType) == 0)
                    {
                        SET_INT(currXdAttribStp, A_XdAttrib_Prog, PROG_N_BK - 50);
                    }
                }
            }
            /* Parent attribute before the other attributes */
            else if (CMP_DYNFLD(xdEntityStp, currXdAttribStp, A_XdEntity_ParentXdAttribId, A_XdAttrib_Id, IdType) == 0)
            {
                if (bAllProgNIsNull ||
                    IS_NULLFLD(currXdAttribStp, A_XdAttrib_Prog) == TRUE)
                {
                    SET_INT(currXdAttribStp, A_XdAttrib_Prog, PROG_N_PARENT_ATTR);
                }
            }
            else if (GET_ENUM(currXdAttribStp, A_XdAttrib_CustomFlg) != Custom_No)
            {
                if (DdlGen::getUdIdSqlName().compare(GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName)) == 0)
                {
                    SET_INT(currXdAttribStp, A_XdAttrib_Prog, PROG_N_START_UD);
                }
                else
                {
                    SET_INT(currXdAttribStp, A_XdAttrib_Prog, PROG_N_START_UD + (++udNbr));
                }
            }
            else if (GET_FLAG(currXdAttribStp, A_XdAttrib_PrecompFlg) == TRUE)
            {
                SET_INT(currXdAttribStp, A_XdAttrib_Prog, PROG_N_START_PRECOMP + (++precompNbr));
            }
            else if (static_cast<MODEL_BANK_ENUM>(GET_ENUM(currXdAttribStp, A_XdAttrib_ModelBankEn)) == ModelBank_Active)
            {
                SET_INT(currXdAttribStp, A_XdAttrib_Prog, PROG_N_START_MODEL_BANK + (++modelBankNbr));
            }
            else if (IS_NULLFLD(currXdAttribStp, A_XdAttrib_Prog) == TRUE &&
                     DictAttribClass::isPhysicalCalcEn((DICTATTR_ENUM)GET_ENUM(currXdAttribStp, A_XdAttrib_CalcEn)) == TRUE)
            {
                SET_INT(currXdAttribStp, A_XdAttrib_Prog, PROG_N_INIT_PHYS);
            }
            else if (GET_ENUM(currXdAttribStp, A_XdAttrib_CalcEn) == DictAttr_Denorm)
            {
                SET_INT(currXdAttribStp, A_XdAttrib_Prog, PROG_N_INIT_DENORM);
            }
            else if (GET_ENUM(currXdAttribStp, A_XdAttrib_CalcEn) == DictAttr_Virtual)
            {
                SET_INT(currXdAttribStp, A_XdAttrib_Prog, PROG_N_INIT_VIRTUAL);
            }

            if (IS_NULLFLD(currXdAttribStp, A_XdAttrib_Prog) == TRUE)
            {
                SET_INT(currXdAttribStp, A_XdAttrib_Prog, PROG_N_INIT);
            }
        }

        this->ddlGenEntityPtr->sortAttributes();
    }

    for (int i = 0; i < xdAttribNbr; i++)
    {
        DBA_DYNFLD_STP currXdAttribStp = this->ddlGenEntityPtr->getXdAttrib(i);

        if (IS_NULLFLD(currXdAttribStp, A_XdAttrib_OldProg) &&
            IS_NOTNULL(currXdAttribStp, A_XdAttrib_Prog))
        {
            COPY_DYNFLD(currXdAttribStp, A_XdAttrib, A_XdAttrib_OldProg,
                        currXdAttribStp, A_XdAttrib, A_XdAttrib_Prog);
        }

        /* Reset prog */
        SET_NULL_INT(currXdAttribStp, A_XdAttrib_Prog);
    }

    /* Check that the primary key is at the beginning */
    for (int i = 0; i < xdAttribNbr; i++)
    {
        DBA_DYNFLD_STP currXdAttribStp = this->ddlGenEntityPtr->getXdAttrib(i);

        if (GET_ENUM(currXdAttribStp, A_XdAttrib_XdActionEn) == XdAction_ToDelete)
        {
            SET_INT(currXdAttribStp, A_XdAttrib_Prog, PROG_N_TO_DELETE);
            SET_SMALLINT(currXdAttribStp, A_XdAttrib_DispRank, 0);
        }
        else if (GET_ENUM(currXdAttribStp, A_XdAttrib_XdActionEn) == XdAction_ToPhysicallyDelete)
        {
            SET_INT(currXdAttribStp, A_XdAttrib_Prog, PROG_N_TO_PHYSICAL_DELETE);
            SET_SMALLINT(currXdAttribStp, A_XdAttrib_DispRank, 0);
        }
        else if (GET_FLAG(currXdAttribStp, A_XdAttrib_PrimaryFlg) == TRUE ||
                 IS_NULLFLD(currXdAttribStp, A_XdAttrib_ProgPk) == FALSE)
        {
            if (IS_NULLFLD(currXdAttribStp, A_XdAttrib_OldProg) == TRUE)
            {
                SET_INT(currXdAttribStp, A_XdAttrib_Prog, progN);
                progN++;
            }
            if (GET_ENUM(xdEntityStp, A_XdEntity_PkRuleEn) != PkRule_NoIdentity)
            {
                SET_SMALLINT(currXdAttribStp, A_XdAttrib_DispRank, 0);
            }
        }
        else if (IS_NULLFLD(xdEntityStp, A_XdEntity_ParentXdAttribId) == FALSE &&
                 CMP_DYNFLD(xdEntityStp, currXdAttribStp, A_XdEntity_ParentXdAttribId, A_XdAttrib_Id, IdType) == 0)
        {
            if (IS_NULLFLD(currXdAttribStp, A_XdAttrib_OldProg) == TRUE)
            {
                SET_INT(currXdAttribStp, A_XdAttrib_Prog, progN);
                progN++;
            }
        }

        if (GET_SMALLINT(currXdAttribStp, A_XdAttrib_DispRank) >= dispRankN &&
            GET_SMALLINT(currXdAttribStp, A_XdAttrib_DispRank) < DISP_RANK_FIRST_SPEC &&
            GET_FLAG(currXdAttribStp, A_XdAttrib_PrecompFlg) == FALSE)
        {
            dispRankN = (SMALLINT_T)(GET_SMALLINT(currXdAttribStp, A_XdAttrib_DispRank) + 1);
        }
    }

    if (this->m_dictEntityStp != nullptr && this->m_dictEntityStp->bIsInitEntity)
    {
        for (int i = 0; i < this->ddlGenEntityPtr->getXdAttribNbr(); i++)
        {
            DBA_DYNFLD_STP currXdAttribStp = this->ddlGenEntityPtr->getXdAttrib(i);

            auto attribStp = this->m_dictEntityStp->getDictAttribBySqlName(GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName));

            if (attribStp != nullptr)
            {
                SET_INT(currXdAttribStp, A_XdAttrib_Prog, attribStp->progN);
                SET_DICT(currXdAttribStp, A_XdAttrib_AttribDictId, attribStp->attrDictId);

                if (attribStp->progN > progN)
                {
                    progN = attribStp->progN;
                }
            }
        }
        progN++;

        this->ddlGenEntityPtr->sortAttributes();
    }

    /* Check that the business key is just after the primary key */
    for (int i = 0; i < xdAttribNbr; i++)
    {
        DBA_DYNFLD_STP currXdAttribStp = this->ddlGenEntityPtr->getXdAttrib(i);

        if (GET_FLAG(currXdAttribStp, A_XdAttrib_BusKeyFlg) == FALSE &&
            IS_NULLFLD(currXdAttribStp, A_XdAttrib_ProgBk) == TRUE)
        {
            continue;
        }

        if (IS_NULLFLD(currXdAttribStp, A_XdAttrib_Prog) == TRUE &&
            IS_NULLFLD(currXdAttribStp, A_XdAttrib_OldProg) == TRUE)
        {
            SET_INT(currXdAttribStp, A_XdAttrib_Prog, progN++);
        }

        if (IS_NULLFLD(currXdAttribStp, A_XdAttrib_DispRank) == TRUE)
        {
            SET_SMALLINT(currXdAttribStp, A_XdAttrib_DispRank, dispRankN++);
        }
    }

    for (int i = 0; i < xdAttribNbr; i++)
    {
        DBA_DYNFLD_STP currXdAttribStp = this->ddlGenEntityPtr->getXdAttrib(i);

        if ((GET_ENUM(currXdAttribStp, A_XdAttrib_CustomFlg) != Custom_No &&
             GET_A_XdAttrib_FeatureEn(currXdAttribStp) != XdEntityFeatureFeatureEn::MultiBusinessEntityManagement) ||
            GET_FLAG(currXdAttribStp, A_XdAttrib_LogicalFlg) == TRUE ||
            (GET_FLAG(currXdAttribStp, A_XdAttrib_PrecompFlg) == TRUE &&
             GET_A_XdAttrib_FeatureEn(currXdAttribStp) != XdEntityFeatureFeatureEn::MultiBusinessEntityManagement) ||
            GET_FLAG(currXdAttribStp, A_XdAttrib_ShortOnlyFlg) == TRUE ||
            GET_ENUM(currXdAttribStp, A_XdAttrib_ModelBankEn) != ModelBank_None)
        {
            continue;
        }

        if (IS_NULLFLD(currXdAttribStp, A_XdAttrib_Prog) == TRUE &&
            (DictAttribClass::isPhysicalCalcEn(static_cast<DICTATTR_ENUM>(GET_ENUM(currXdAttribStp, A_XdAttrib_CalcEn))) ||
             GET_FLAG(currXdAttribStp, A_XdAttrib_BusKeyFlg) == TRUE ||
             GET_FLAG(currXdAttribStp, A_XdAttrib_PrimaryFlg) == TRUE)) /* PMSTA-29879 - LJE - 180212 */
        {
            SET_INT(currXdAttribStp, A_XdAttrib_Prog, progN++);
        }

        if (IS_NULLFLD(currXdAttribStp, A_XdAttrib_DispRank) == TRUE)
        {
            SET_SMALLINT(currXdAttribStp, A_XdAttrib_DispRank, dispRankN++);
        }
    }

    /* Manage model bank attributes */
    for (int i = 0; i < xdAttribNbr; i++)
    {
        DBA_DYNFLD_STP currXdAttribStp = this->ddlGenEntityPtr->getXdAttrib(i);

        if (GET_ENUM(currXdAttribStp, A_XdAttrib_ModelBankEn) != ModelBank_None &&
            IS_NULLFLD(currXdAttribStp, A_XdAttrib_Prog))
        {
            SET_INT(currXdAttribStp, A_XdAttrib_Prog, progN++);
        }
    }

    /* Manage non physical attributes */
    for (int i = 0; i < xdAttribNbr; i++)
    {
        DBA_DYNFLD_STP currXdAttribStp = this->ddlGenEntityPtr->getXdAttrib(i);

        if (GET_ENUM(currXdAttribStp, A_XdAttrib_CustomFlg) == Custom_No &&
            GET_ENUM(currXdAttribStp, A_XdAttrib_CalcEn) != DictAttr_Virtual &&
            DictAttribClass::isPhysicalCalcEn(static_cast<DICTATTR_ENUM>(GET_ENUM(currXdAttribStp, A_XdAttrib_CalcEn))) == false &&
            IS_NULLFLD(currXdAttribStp, A_XdAttrib_Prog))
        {
            if (IS_NULLFLD(currXdAttribStp, A_XdAttrib_Prog) == TRUE)
            {
                SET_INT(currXdAttribStp, A_XdAttrib_Prog, progN++);
            }
        }
    }

    /* Manage virtual attributes */
    for (int i = 0; i < xdAttribNbr; i++)
    {
        DBA_DYNFLD_STP currXdAttribStp = this->ddlGenEntityPtr->getXdAttrib(i);

        if (GET_ENUM(currXdAttribStp, A_XdAttrib_CustomFlg) == Custom_No &&
            GET_ENUM(currXdAttribStp, A_XdAttrib_CalcEn) == DictAttr_Virtual &&
            IS_NULLFLD(currXdAttribStp, A_XdAttrib_Prog))
        {
            if (IS_NULLFLD(currXdAttribStp, A_XdAttrib_Prog) == TRUE)
            {
                SET_INT(currXdAttribStp, A_XdAttrib_Prog, progN++);
            }
        }
    }

    /* Manage ud fields */
    FIELD_IDX_T udIdIdx = progN++;
    bool        bUdIdToSet = true;
    for (int i = 0; i < xdAttribNbr; i++)
    {
        DBA_DYNFLD_STP currXdAttribStp = this->ddlGenEntityPtr->getXdAttrib(i);

        if (GET_ENUM(currXdAttribStp, A_XdAttrib_CustomFlg)    == Custom_No ||
            GET_A_XdAttrib_FeatureEn(currXdAttribStp)          == XdEntityFeatureFeatureEn::MultiBusinessEntityManagement ||
            GET_ENUM(currXdAttribStp, A_XdAttrib_CalcEn)       == DictAttr_Virtual ||
            GET_FLAG(currXdAttribStp, A_XdAttrib_PrecompFlg)   == TRUE ||
            GET_FLAG(currXdAttribStp, A_XdAttrib_LogicalFlg)   == TRUE ||
            GET_FLAG(currXdAttribStp, A_XdAttrib_ShortOnlyFlg) == TRUE)
        {
            continue;
        }

        if (bUdIdToSet &&
            DdlGen::getUdIdSqlName() == GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName))
        {
            SET_INT(currXdAttribStp, A_XdAttrib_Prog, udIdIdx);
            bUdIdToSet = false;
        }
        else
        {
            if (IS_NULLFLD(currXdAttribStp, A_XdAttrib_Prog) == TRUE)
            {
                SET_INT(currXdAttribStp, A_XdAttrib_Prog, progN++);
            }
            else
            {
                SYS_BreakOnDebug();
            }

            if (IS_NULLFLD(currXdAttribStp, A_XdAttrib_DispRank) == TRUE)
            {
                SET_SMALLINT(currXdAttribStp, A_XdAttrib_DispRank, dispRankN++);
            }
        }
    }

    /* PMSTA-54168 - LJE - 230809 - Manage ud field virtual attributes*/
    for (int i = 0; i < xdAttribNbr; i++)
    {
        DBA_DYNFLD_STP currXdAttribStp = this->ddlGenEntityPtr->getXdAttrib(i);

        if (GET_ENUM(currXdAttribStp, A_XdAttrib_CustomFlg) != Custom_No &&
            GET_ENUM(currXdAttribStp, A_XdAttrib_CalcEn) == DictAttr_Virtual &&
            IS_NULLFLD(currXdAttribStp, A_XdAttrib_Prog))
        {
            SET_INT(currXdAttribStp, A_XdAttrib_Prog, progN++);
        }
    }

    /* Manage extensions attributes (precomputed fields) */
    FIELD_IDX_T xIdIdx = progN++;
    for (int i = 0; i < xdAttribNbr; i++)
    {
        DBA_DYNFLD_STP currXdAttribStp = this->ddlGenEntityPtr->getXdAttrib(i);

        if (GET_FLAG(currXdAttribStp, A_XdAttrib_PrecompFlg) == TRUE &&
            GET_A_XdAttrib_FeatureEn(currXdAttribStp) != XdEntityFeatureFeatureEn::None &&
            GET_A_XdAttrib_FeatureEn(currXdAttribStp) != XdEntityFeatureFeatureEn::MultiBusinessEntityManagement)
        {
            if (DdlGen::getXIdSqlName() == GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName))
            {
                SET_INT(currXdAttribStp, A_XdAttrib_Prog, xIdIdx);
                SET_SMALLINT(currXdAttribStp, A_XdAttrib_DispRank, 0);
            }
            else
            {
                SET_INT(currXdAttribStp, A_XdAttrib_Prog, progN++);
                SET_SMALLINT(currXdAttribStp, A_XdAttrib_DispRank, dispRankN++);
            }
        }
    }

    for (int i = 0; i < xdAttribNbr; i++)
    {
        DBA_DYNFLD_STP currXdAttribStp = this->ddlGenEntityPtr->getXdAttrib(i);

        if (GET_FLAG(currXdAttribStp, A_XdAttrib_PrecompFlg) == TRUE &&
            GET_A_XdAttrib_FeatureEn(currXdAttribStp) == XdEntityFeatureFeatureEn::None)
        {
            SET_INT(currXdAttribStp, A_XdAttrib_Prog, progN++);

            if (GET_FLAG(currXdAttribStp, A_XdAttrib_MultiLangFlg) == FALSE)
            {
                SET_SMALLINT(currXdAttribStp, A_XdAttrib_DispRank, dispRankN++);
            }
            else
            {
                SET_SMALLINT(currXdAttribStp, A_XdAttrib_DispRank, 0);
            }
        }
    }

    /* Manage logicals */
    for (int i = 0; i < xdAttribNbr; i++)
    {
        DBA_DYNFLD_STP currXdAttribStp = this->ddlGenEntityPtr->getXdAttrib(i);

        if (GET_FLAG(currXdAttribStp, A_XdAttrib_LogicalFlg) == FALSE)
            continue;

        SET_INT(currXdAttribStp, A_XdAttrib_Prog, progN++);

        if (GET_SMALLINT(currXdAttribStp, A_XdAttrib_DispRank) == DISP_RANK_SCPT_CTRL)
        {
            SET_SMALLINT(currXdAttribStp, A_XdAttrib_DispRank, 0);
        }

        if (IS_NULLFLD(currXdAttribStp, A_XdAttrib_DispRank) == TRUE)
        {
            SET_SMALLINT(currXdAttribStp, A_XdAttrib_DispRank, dispRankN++);
        }
    }

    for (int i = 0; i < xdAttribNbr; i++)
    {
        DBA_DYNFLD_STP currXdAttribStp = this->ddlGenEntityPtr->getXdAttrib(i);

        if (GET_FLAG(currXdAttribStp, A_XdAttrib_LogicalFlg) == FALSE ||
            IS_NULLFLD(currXdAttribStp, A_XdAttrib_Prog) == FALSE)
            continue;

        SET_INT(currXdAttribStp, A_XdAttrib_Prog, progN++);

        if (IS_NULLFLD(currXdAttribStp, A_XdAttrib_DispRank) == TRUE)
        {
            SET_SMALLINT(currXdAttribStp, A_XdAttrib_DispRank, dispRankN++);
        }
    }

    /* Deleted elements */
    progN = 1000;
    for (int i = 0; i < this->ddlGenEntityPtr->getXdAttribNbr(); i++)
    {
        DBA_DYNFLD_STP currXdAttribStp = this->ddlGenEntityPtr->getXdAttrib(i);

        if (GET_INT(currXdAttribStp, A_XdAttrib_Prog) == PROG_N_TO_DELETE ||
            IS_NULLFLD(currXdAttribStp, A_XdAttrib_Prog) == TRUE)
        {
            SET_INT(currXdAttribStp, A_XdAttrib_Prog, progN++);
        }

        SET_NULL_INT(currXdAttribStp, A_XdAttrib_OldProg);
    }

    this->ddlGenEntityPtr->sortAttributes();

    progN = 0;
    for (int i = 0; i < this->ddlGenEntityPtr->getXdAttribNbr(); i++)
    {
        SET_INT(this->ddlGenEntityPtr->getXdAttrib(i), A_XdAttrib_Prog, progN++);
    }

    /* PMSTA-52114 - LJE - 230221 - Check with the database order */
    if (this->ddlGenContextPtr->m_rdbmsEn == Sybase &&
        (GET_ENUM(xdEntityStp, A_XdEntity_SecurityLevelEn) == EntSecuLevel_InsertAllowed ||
         GET_ENUM(xdEntityStp, A_XdEntity_SecurityLevelEn) == EntSecuLevel_InsertDeleteAllowed))
    {
        map<INT_T, DBA_DYNFLD_STP> dbMap;
        map<INT_T, DBA_DYNFLD_STP> noDbMap;

        for (int i = 0; i < this->ddlGenEntityPtr->getXdAttribNbr(); i++)
        {
            DBA_DYNFLD_STP currXdAttribStp = this->ddlGenEntityPtr->getXdAttrib(i);

            if (IS_NULLFLD(currXdAttribStp, A_XdAttrib_DbProg) == false)
            {
                INT_T requestProgN = GET_INT(currXdAttribStp, A_XdAttrib_DbProg);

                if (GET_ENUM(currXdAttribStp, A_XdAttrib_CustomFlg) != Custom_No)
                {
                    requestProgN += udIdIdx;
                }

                dbMap[requestProgN] = currXdAttribStp;
            }
            else
            {
                noDbMap[GET_INT(currXdAttribStp, A_XdAttrib_Prog)] = currXdAttribStp;
            }
        }

        if (dbMap.empty() == false)
        {
            auto dbIt = dbMap.begin();
            auto noDbIt = noDbMap.begin();

            for (progN = 0; progN < this->ddlGenEntityPtr->getXdAttribNbr(); ++progN)
            {
                if (dbIt != dbMap.end() && progN == dbIt->first)
                {
                    SET_INT(dbIt->second, A_XdAttrib_Prog, progN);
                    ++dbIt;
                }
                else
                {
                    SET_INT(noDbIt->second, A_XdAttrib_Prog, progN);
                    ++noDbIt;
                }
            }
        }
        this->ddlGenEntityPtr->sortAttributes();
    }

    /* Set correct prg_pk_n  */
    map<SMALLINT_T, DBA_DYNFLD_STP> progPkMap;

    for (int i = 0; i < xdAttribNbr; i++)
    {
        DBA_DYNFLD_STP currXdAttribStp = this->ddlGenEntityPtr->getXdAttrib(i);

        if (GET_FLAG(currXdAttribStp, A_XdAttrib_PrimaryFlg) == TRUE ||
            IS_NULLFLD(currXdAttribStp, A_XdAttrib_ProgPk) == FALSE)
        {
            if (IS_NULLFLD(currXdAttribStp, A_XdAttrib_ProgPk) == FALSE)
            {
                progPkMap.insert(make_pair(GET_SMALLINT(currXdAttribStp, A_XdAttrib_ProgPk), currXdAttribStp));
            }
            else
            {
                progPkMap.insert(make_pair(static_cast<SMALLINT_T>(GET_INT(currXdAttribStp, A_XdAttrib_Prog)), currXdAttribStp));
            }
        }
    }

    if (progPkMap.size() == 0 &&
        GET_FLAG(xdEntityStp, A_XdEntity_LogicalFlg) == FALSE &&
        (this->entNatureEn == EntityNat_Custom || this->entNatureEn == EntityNat_CustomDS))
    {
        this->printMsg(RET_DBA_INFO_NODATA, "Primary key missing");
    }

    SMALLINT_T progPk = 0;
    for (auto it = progPkMap.begin(); it != progPkMap.end(); ++it)
    {
        SET_SMALLINT(it->second, A_XdAttrib_ProgPk, progPk++);
    }

    /* Set correct prg_bk_n  */
    map<SMALLINT_T, DBA_DYNFLD_STP> progBkMap;

    for (int i = 0; i < xdAttribNbr; i++)
    {
        DBA_DYNFLD_STP currXdAttribStp = this->ddlGenEntityPtr->getXdAttrib(i);

        if (GET_FLAG(currXdAttribStp, A_XdAttrib_BusKeyFlg) == TRUE ||
            IS_NULLFLD(currXdAttribStp, A_XdAttrib_ProgBk) == FALSE)
        {
            if (IS_NULLFLD(currXdAttribStp, A_XdAttrib_ProgBk) == FALSE)
            {
                progBkMap.insert(make_pair(GET_SMALLINT(currXdAttribStp, A_XdAttrib_ProgBk), currXdAttribStp));
            }
            else
            {
                progBkMap.insert(make_pair(static_cast<SMALLINT_T>(GET_INT(currXdAttribStp, A_XdAttrib_Prog)), currXdAttribStp));
            }
        }
    }

    SMALLINT_T progBk = 0;
    for (auto it = progBkMap.begin(); it != progBkMap.end(); ++it)
    {
        SET_SMALLINT(it->second, A_XdAttrib_ProgBk, progBk++);
    }

    /* Manage short attributes */
    shortIndexN = 0;
    for (int i = 0; i < xdAttribNbr; i++)
    {
        DBA_DYNFLD_STP currXdAttribStp = this->ddlGenEntityPtr->getXdAttrib(i);

        if (GET_FLAG(currXdAttribStp, A_XdAttrib_ShortOnlyFlg) == TRUE)
        {
            SET_NULL_SMALLINT(currXdAttribStp, A_XdAttrib_DispRank);
        }
        else if (IS_NULLFLD(currXdAttribStp, A_XdAttrib_DispRank) == TRUE)
        {
            SET_SMALLINT(currXdAttribStp, A_XdAttrib_DispRank, dispRankN++);
        }

        if (this->bNoShortOnEntity)
        {
            SET_NULL_SMALLINT(currXdAttribStp, A_XdAttrib_ShortIdx);
            SET_NULL_SMALLINT(currXdAttribStp, A_XdAttrib_ShortDispRank);
        }
        else
        {
            /* PMSTA-29879 - LJE - 180207 */
            if (this->isShortDictCriteria(i))
            {
                SET_SMALLINT(currXdAttribStp, A_XdAttrib_ShortIdx, ++shortIndexN);
            }

            if (IS_NULLFLD(currXdAttribStp, A_XdAttrib_ShortIdx) == false)
            {
                if (GET_A_XdAttrib_FeatureEn(currXdAttribStp) != XdEntityFeatureFeatureEn::None)
                {
                    SET_SMALLINT(currXdAttribStp, A_XdAttrib_ShortIdx, GET_SMALLINT(currXdAttribStp, A_XdAttrib_ShortIdx) + PROG_N_START_SHORT_FEATURE);
                }

                /* Put the virtual short attributes in the end */
                if (GET_SMALLINT(currXdAttribStp, A_XdAttrib_ShortDispRank) < 0)
                {
                    SET_SMALLINT(currXdAttribStp, A_XdAttrib_ShortIdx, GET_SMALLINT(currXdAttribStp, A_XdAttrib_ShortIdx) + PROG_N_START_SHORT_VIRTUAL);
                }
            }
        }
    }

    DBA_DYNFLD_STP* xdAttribByShortIdxTab = this->ddlGenEntityPtr->getSortedXdAttribTab((TLS_CMPFCT*)DDL_CmpXdAttribByShortIdx);
    mp.owner(xdAttribByShortIdxTab);

    shortIndexN = 0;
    for (int i = 0; i < xdAttribNbr; i++)
    {
        DBA_DYNFLD_STP currXdAttribStp = xdAttribByShortIdxTab[i];

        if (GET_ENUM(currXdAttribStp, A_XdAttrib_XdActionEn) == XdAction_ToInsert &&
            IS_NULLFLD(currXdAttribStp, A_XdAttrib_ShortIdx) == FALSE)
        {
            SET_SMALLINT(currXdAttribStp, A_XdAttrib_ShortIdx, shortIndexN++);
        }
    }

    DBA_DYNFLD_STP* xdAttribByDispRankTab = this->ddlGenEntityPtr->getSortedXdAttribTab((TLS_CMPFCT*)DDL_CmpXdAttribByDispRank);
    mp.owner(xdAttribByDispRankTab);

    dispRankN = 1;

    for (int i = 0; i < xdAttribNbr; i++)
    {
        DBA_DYNFLD_STP currXdAttribStp = xdAttribByDispRankTab[i];

        if ((GET_ENUM(currXdAttribStp, A_XdAttrib_XdActionEn) == XdAction_ToInsert ||
             GET_ENUM(currXdAttribStp, A_XdAttrib_XdActionEn) == XdAction_None &&
             GET_ENUM(currXdAttribStp, A_XdAttrib_XdStatusEn) == XdStatus_Inserted) &&
            GET_SMALLINT(currXdAttribStp, A_XdAttrib_DispRank) > 0)
        {
            SET_SMALLINT(currXdAttribStp, A_XdAttrib_DispRank, dispRankN++);
        }
    }

    /* Check and or rebuild short index */
    this->checkShortIndex(this->bShortToDo);

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenFullTable::pushEntityToInsert()
**
**  Description :
**
**  Arguments   :
**  Return      :
**
**  Creation  	:   PMSTA-29748 - LJE - 180117
**
*************************************************************************/
RET_CODE DdlGenFullTable::pushEntityToInsert(DBA_DYNFLD_STP shXdEntityStp)
{
    if (((XD_ACTION_ENUM)GET_ENUM(shXdEntityStp, S_XdEntity_XdActionEn) == XdAction_None ||
         (XD_ACTION_ENUM)GET_ENUM(shXdEntityStp, S_XdEntity_XdActionEn) == XdAction_ToRefresh) &&
        ((XD_STATUS_ENUM)GET_ENUM(shXdEntityStp, S_XdEntity_XdStatusEn) == XdStatus_Inserted ||
         (XD_STATUS_ENUM)GET_ENUM(shXdEntityStp, S_XdEntity_XdStatusEn) == XdStatus_Failed))
    {
        if ((XD_ACTION_ENUM)GET_ENUM(shXdEntityStp, S_XdEntity_XdActionEn) != XdAction_ToRefresh)
        {
            SET_ENUM(shXdEntityStp, S_XdEntity_XdActionEn, XdAction_ToInsert);
        }

        DBA_DYNFLD_STP  xdEntityStp = this->getXdEntityStp();

        COPY_DYNFLD(xdEntityStp, A_XdEntity, A_XdEntity_XdActionEn, shXdEntityStp, S_XdEntity, S_XdEntity_XdActionEn);

        for (int i = 0; i < this->ddlGenEntityPtr->getXdAttribNbr(); i++)
        {
            DBA_DYNFLD_STP currXdAttribStp = this->ddlGenEntityPtr->getXdAttrib(i);

            if ((XD_ACTION_ENUM)GET_ENUM(currXdAttribStp, A_XdAttrib_XdActionEn) == XdAction_None &&
                ((XD_STATUS_ENUM)GET_ENUM(currXdAttribStp, A_XdAttrib_XdStatusEn) == XdStatus_Inserted ||
                 (XD_STATUS_ENUM)GET_ENUM(currXdAttribStp, A_XdAttrib_XdStatusEn) == XdStatus_Failed))
            {
                SET_ENUM(currXdAttribStp, A_XdAttrib_XdActionEn, XdAction_ToInsert);
            }
            else if ((XD_ACTION_ENUM)GET_ENUM(currXdAttribStp, A_XdAttrib_XdActionEn) == XdAction_ToDeprecate &&
                     (XD_ACTION_ENUM)GET_ENUM(shXdEntityStp, S_XdEntity_XdActionEn) == XdAction_ToRefresh &&
                     (XD_STATUS_ENUM)GET_ENUM(currXdAttribStp, A_XdAttrib_XdStatusEn) == XdStatus_Inserted)
            {
                SET_ENUM(currXdAttribStp, A_XdAttrib_XdActionEn, XdAction_ToInsert);
            }

            auto xdAttribPermValMap = this->ddlGenEntityPtr->getXdPermValByAttribMap(GET_ID(currXdAttribStp, A_XdAttrib_Id));
            if (xdAttribPermValMap != nullptr)
            {
                for (auto it = xdAttribPermValMap->begin(); it != xdAttribPermValMap->end(); ++it)
                {
                    DBA_DYNFLD_STP currXdPermValStp = it->second;

                    if ((XD_ACTION_ENUM)GET_ENUM(currXdPermValStp, A_XdPermVal_XdActionEn) == XdAction_None &&
                        ((XD_STATUS_ENUM)GET_ENUM(currXdPermValStp, A_XdPermVal_XdStatusEn) == XdStatus_Inserted ||
                         (XD_STATUS_ENUM)GET_ENUM(currXdPermValStp, A_XdPermVal_XdStatusEn) == XdStatus_Failed))
                    {
                        SET_ENUM(currXdPermValStp, A_XdPermVal_XdActionEn, GET_ENUM(currXdAttribStp, A_XdAttrib_XdActionEn)); /* PMSTA-48207 - LJE - 220330 */
                    }
                    else if ((XD_ACTION_ENUM)GET_ENUM(currXdPermValStp, A_XdPermVal_XdActionEn) == XdAction_ToDeprecate &&
                             (XD_ACTION_ENUM)GET_ENUM(shXdEntityStp, S_XdEntity_XdActionEn) == XdAction_ToRefresh &&
                             (XD_STATUS_ENUM)GET_ENUM(currXdPermValStp, A_XdPermVal_XdStatusEn) == XdStatus_Inserted)
                    {
                        SET_ENUM(currXdPermValStp, A_XdPermVal_XdActionEn, GET_ENUM(currXdAttribStp, A_XdAttrib_XdActionEn)); /* PMSTA-48207 - LJE - 220330 */
                    }
                }
            }
        }

        auto& xdIndexVector = this->ddlGenEntityPtr->getXdIndexVector();

        for (auto it = xdIndexVector.begin(); it != xdIndexVector.end(); ++it)
        {
            DBA_DYNFLD_STP currXdIndexStp = *it;

            if ((XD_ACTION_ENUM)GET_ENUM(currXdIndexStp, A_XdIndex_XdActionEn) == XdAction_None &&
                ((XD_STATUS_ENUM)GET_ENUM(currXdIndexStp, A_XdIndex_XdStatusEn) == XdStatus_Inserted ||
                 (XD_STATUS_ENUM)GET_ENUM(currXdIndexStp, A_XdIndex_XdStatusEn) == XdStatus_Failed))
            {
                SET_ENUM(currXdIndexStp, A_XdIndex_XdActionEn, XdAction_ToInsert);
            }
            else if ((XD_ACTION_ENUM)GET_ENUM(currXdIndexStp, A_XdIndex_XdActionEn) == XdAction_ToDeprecate &&
                     (XD_ACTION_ENUM)GET_ENUM(shXdEntityStp, S_XdEntity_XdActionEn) == XdAction_ToRefresh &&
                     (XD_STATUS_ENUM)GET_ENUM(currXdIndexStp, A_XdIndex_XdStatusEn) == XdStatus_Inserted)
            {
                SET_ENUM(currXdIndexStp, A_XdIndex_XdActionEn, XdAction_ToInsert);
            }

            auto& xdIndexAttribMap = this->ddlGenEntityPtr->getXdIndexAttribVector(currXdIndexStp);

            for (auto it2 = xdIndexAttribMap.begin(); it2 != xdIndexAttribMap.end(); ++it2)
            {
                DBA_DYNFLD_STP currXdIndexAttribStp = (*it2);

                if ((XD_ACTION_ENUM)GET_ENUM(currXdIndexAttribStp, A_XdIndexAttrib_XdActionEn) == XdAction_None &&
                    ((XD_STATUS_ENUM)GET_ENUM(currXdIndexAttribStp, A_XdIndexAttrib_XdStatusEn) == XdStatus_Inserted ||
                     (XD_STATUS_ENUM)GET_ENUM(currXdIndexAttribStp, A_XdIndexAttrib_XdStatusEn) == XdStatus_Failed))
                {
                    SET_ENUM(currXdIndexAttribStp, A_XdIndexAttrib_XdActionEn, XdAction_ToInsert);
                }
                else if ((XD_ACTION_ENUM)GET_ENUM(currXdIndexAttribStp, A_XdIndexAttrib_XdActionEn) == XdAction_ToDeprecate &&
                         (XD_ACTION_ENUM)GET_ENUM(shXdEntityStp, S_XdEntity_XdActionEn) == XdAction_ToRefresh &&
                         (XD_STATUS_ENUM)GET_ENUM(currXdIndexAttribStp, A_XdIndexAttrib_XdStatusEn) == XdStatus_Inserted)
                {
                    SET_ENUM(currXdIndexAttribStp, A_XdIndexAttrib_XdActionEn, XdAction_ToInsert);
                }
            }
        }

        for (auto it = this->ddlGenEntityPtr->xdEntityFeatureMap.begin(); it != this->ddlGenEntityPtr->xdEntityFeatureMap.end(); it++)
        {
            DBA_DYNFLD_STP currXdEntityFeatureStp = it->second;

            if ((XD_ACTION_ENUM)GET_ENUM(currXdEntityFeatureStp, A_XdEntityFeature_XdActionEn) == XdAction_None &&
                ((XD_STATUS_ENUM)GET_ENUM(currXdEntityFeatureStp, A_XdEntityFeature_XdStatusEn) == XdStatus_Inserted ||
                 (XD_STATUS_ENUM)GET_ENUM(currXdEntityFeatureStp, A_XdEntityFeature_XdStatusEn) == XdStatus_Failed))
            {
                SET_ENUM(currXdEntityFeatureStp, A_XdEntityFeature_XdActionEn, XdAction_ToInsert);
            }
            else if ((XD_ACTION_ENUM)GET_ENUM(currXdEntityFeatureStp, A_XdEntityFeature_XdActionEn) == XdAction_ToDeprecate &&
                     (XD_ACTION_ENUM)GET_ENUM(shXdEntityStp, S_XdEntity_XdActionEn) == XdAction_ToRefresh &&
                     (XD_STATUS_ENUM)GET_ENUM(currXdEntityFeatureStp, A_XdEntityFeature_XdStatusEn) == XdStatus_Inserted)
            {
                SET_ENUM(currXdEntityFeatureStp, A_XdEntityFeature_XdActionEn, XdAction_ToInsert);
            }
        }

        for (int i = 0; i < this->ddlGenEntityPtr->getXdPartitionNbr(); i++)
        {
            DBA_DYNFLD_STP currXdPartitionStp = this->ddlGenEntityPtr->getXdPartitionTab()[i];

            if ((XD_ACTION_ENUM)GET_ENUM(currXdPartitionStp, A_XdPartition_XdActionEn) == XdAction_None &&
                ((XD_STATUS_ENUM)GET_ENUM(currXdPartitionStp, A_XdPartition_XdStatusEn) == XdStatus_Inserted ||
                 (XD_STATUS_ENUM)GET_ENUM(currXdPartitionStp, A_XdPartition_XdStatusEn) == XdStatus_Failed))
            {
                SET_ENUM(currXdPartitionStp, A_XdPartition_XdActionEn, XdAction_ToInsert);
            }
            else if ((XD_ACTION_ENUM)GET_ENUM(currXdPartitionStp, A_XdPartition_XdActionEn) == XdAction_ToDeprecate &&
                     (XD_ACTION_ENUM)GET_ENUM(shXdEntityStp, S_XdEntity_XdActionEn) == XdAction_ToRefresh &&
                     (XD_STATUS_ENUM)GET_ENUM(currXdPartitionStp, A_XdPartition_XdStatusEn) == XdStatus_Inserted)
            {
                SET_ENUM(currXdPartitionStp, A_XdPartition_XdActionEn, XdAction_ToInsert);
            }
        }

        for (int i = 0; i < this->ddlGenEntityPtr->getXdPartitionIndexNbr(); i++)
        {
            DBA_DYNFLD_STP currXdPartitionIndexStp = this->ddlGenEntityPtr->getXdPartitionIndexTab()[i];

            if ((XD_ACTION_ENUM)GET_ENUM(currXdPartitionIndexStp, A_XdPartitionIndex_XdActionEn) == XdAction_None &&
                ((XD_STATUS_ENUM)GET_ENUM(currXdPartitionIndexStp, A_XdPartitionIndex_XdStatusEn) == XdStatus_Inserted ||
                 (XD_STATUS_ENUM)GET_ENUM(currXdPartitionIndexStp, A_XdPartitionIndex_XdStatusEn) == XdStatus_Failed))
            {
                SET_ENUM(currXdPartitionIndexStp, A_XdPartitionIndex_XdActionEn, XdAction_ToInsert);
            }
            else if ((XD_ACTION_ENUM)GET_ENUM(currXdPartitionIndexStp, A_XdPartitionIndex_XdActionEn) == XdAction_ToDeprecate &&
                     (XD_ACTION_ENUM)GET_ENUM(shXdEntityStp, S_XdEntity_XdActionEn) == XdAction_ToRefresh &&
                     (XD_STATUS_ENUM)GET_ENUM(currXdPartitionIndexStp, A_XdPartitionIndex_XdStatusEn) == XdStatus_Inserted)
            {
                SET_ENUM(currXdPartitionIndexStp, A_XdPartitionIndex_XdActionEn, XdAction_ToInsert);
            }
        }
    }

    return RET_SUCCEED;
}

/************************************************************************
**
**  Function    :   DdlGenFullTable::checkAndFix()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13109 - LJE - 110311
**
*************************************************************************/
RET_CODE DdlGenFullTable::checkAndFix()
{
    RET_CODE               ret = RET_SUCCEED, gblRet = RET_SUCCEED;

    DdlGenProcessLogger    ddlGenProcessLogger(*this, gblRet, "Check and fix imported data");
    ddlGenProcessLogger.start();

    DBA_DYNFLD_STP  xdEntityStp = this->getXdEntityStp();
    if (xdEntityStp == NULL ||
        IS_NULLFLD(xdEntityStp, A_XdEntity_SqlName) == TRUE ||
        (ret = this->initConnection()) != RET_SUCCEED)
    {
        return RET_DBA_INFO_NODATA;
    }
    DdlGenConnGuard     ddlGenConnGuard(*this->ddlGenContextPtr);

    int                    i;


    try
    {
        DdlGenRequestHelper requestHelper(&ddlGenConnGuard.getDbiConn(), *this->ddlGenContextPtr);

        bool bMeSpecLocalDefined = false, bMeSpecKeyDefined = false;                /* PMSTA-26108 - LJE - 170904 */
        LAST_MODIF_ENUM enObjModifStat = LastModif_NoTracking;       /*  HFI-PMSTA-50016-2023-01-27  */

        if (GET_ENUM(xdEntityStp, A_XdEntity_NatEn) != EntityNat_CustomDS &&
            GET_ENUM(xdEntityStp, A_XdEntity_NatEn) != EntityNat_Custom &&
            GET_ENUM(xdEntityStp, A_XdEntity_NatEn) != EntityNat_ModelBank &&        /* PMSTA-27352 - LJE - 170606 */
            GET_ENUM(xdEntityStp, A_XdEntity_NatEn) != EntityNat_PersistedFmt &&
            GET_ENUM(xdEntityStp, A_XdEntity_NatEn) != EntityNat_ReportFmt &&
            GET_ENUM(xdEntityStp, A_XdEntity_NatEn) != EntityNat_Questionnaire &&
            GET_ENUM(xdEntityStp, A_XdEntity_NatEn) != EntityNat_SearchFmt &&
            GET_ENUM(xdEntityStp, A_XdEntity_NatEn) != EntityNat_Internal &&         /* PMSTA-37366 - LJE - 200313 */
            IS_NULLFLD(xdEntityStp, A_XdEntity_DictEntityValue) == TRUE)
        {
            ret = RET_DBA_INFO_NODATA;
            this->printMsg(ret, "The xd_entity.dict_entity_value is missing, please check your import files!");
        }

        if (GET_ENUM(xdEntityStp, A_XdEntity_NatEn) == EntityNat_Tsl &&
            strcmp(GET_SYSNAME(xdEntityStp, A_XdEntity_SqlName), "tsl_perm_value") == 0)
        {
            SET_ENUM(xdEntityStp, A_XdEntity_XdActionEn, XdAction_ToRefresh);
        }

        /* PMSTA-13122 - LJE - 120604 - Refresh dictEntityStp, the table can be changed */
        this->m_dictEntityStp = DBA_GetEntityBySqlName(GET_SYSNAME(xdEntityStp, A_XdEntity_SqlName));

        if (IS_NULLFLD(xdEntityStp, A_XdEntity_EntityDictId) == TRUE &&
            IS_NULLFLD(xdEntityStp, A_XdEntity_DictEntityValue) == FALSE)
        {
            OBJECT_ENUM     objEn = NullEntity;
            DICT_ENTITY_STP locEntDict = nullptr;

            if (DBA_GetObjectEnum(GET_INT(xdEntityStp, A_XdEntity_DictEntityValue), &objEn) == TRUE &&
                objEn != InvalidEntity &&
                (locEntDict = DBA_GetDictEntitySt(objEn)) != NULL &&
                (this->m_dictEntityStp == NULL ||
                 strcmp(locEntDict->mdSqlName, this->m_dictEntityStp->mdSqlName) != 0) &&
                locEntDict->entNatEn != EntityNat_All)
            {
                stringstream msg;
                string entityName;

                if (locEntDict != NULL)
                {
                    entityName = locEntDict->mdSqlName;
                }
                else
                {
                    entityName = "<unknown>";
                }

                msg << "The entity value " << GET_INT(xdEntityStp, A_XdEntity_DictEntityValue)
                    << " is already used by the entity " << entityName;

                ret = RET_DBA_ERR_NODATA;
                this->printMsg(ret, msg.str());
            }
        }

        /* PMSTA- - LJE - 220907 */
        if ((MULTI_ENTITY_CATEGORY_ENUM)GET_ENUM(xdEntityStp, A_XdEntity_MultiEntityCategoryEn) != MultiEntityCategory_None &&
            this->ddlGenContextPtr->m_parentContext->m_bHaveMultiEntityCateg == false)
        {
            this->ddlGenContextPtr->m_parentContext->m_bHaveMultiEntityCateg = true;
        }

        if (this->bCheckAndFixDone == false &&
            this->getDdlGenAction().m_mainDdlObjNatEn != DbObjDdlObjNat_TslExtension)
        {
            if (this->m_dictEntityStp != nullptr)
            {
                this->m_dictEntityStp->multiEntityCateg.set((MULTI_ENTITY_CATEGORY_ENUM)GET_ENUM(xdEntityStp, A_XdEntity_MultiEntityCategoryEn));

                if (this->m_dictEntityStp->multiEntityCateg.isDervidedCategory() == true)
                {
                    SET_ENUM(xdEntityStp, A_XdEntity_MultiEntityCategoryEn, MultiEntityCategory_None);
                    this->m_dictEntityStp->multiEntityCateg.set((MULTI_ENTITY_CATEGORY_ENUM)GET_ENUM(xdEntityStp, A_XdEntity_MultiEntityCategoryEn));
                }
            }
        }

        /* PMSTA-58084 - LJE - 240729 */
        if (this->ddlGenContextPtr->m_rdbmsEn == MSSql &&
            GET_ENUM(xdEntityStp, A_XdEntity_NatEn) == EntityNat_TempTable &&
            this->ddlGenContextPtr->ddlGenAction.m_useMemoryOptizedTempTable == false &&
            GET_ENUM(xdEntityStp, A_XdEntity_DbRuleEn) == DbRule_Standard)
        {
            SET_ENUM(xdEntityStp, A_XdEntity_DbRuleEn, DbRule_VolatileTable);
        }

        CFG_OBJECT_SECTION* cfgObjSectionStp = nullptr;

        auto tempTableSpec = DdlGenDbi::getTempTableSpec(this->ddlGenContextPtr->m_rdbmsEn, xdEntityStp);
        if (tempTableSpec != DdlGenDbi::TempTableSpec::Session &&
            tempTableSpec != DdlGenDbi::TempTableSpec::Type &&
            this->ddlGenContextPtr->m_forceTbSeg.empty())
        {
            cfgObjSectionStp = this->ddlGenContextPtr->getCfgFileHelper().getCfgObjectSectonStp(GET_SYSNAME(xdEntityStp, A_XdEntity_SqlName),
                                                                                                static_cast<DBA_ENTITY_NAT_ENUM>(GET_ENUM(xdEntityStp, A_XdEntity_NatEn)));
        }
        else if (this->ddlGenContextPtr->ddlGenAction.m_execModeEn == DbObjExecMod_BuildVirtualFromFmt &&
                 this->ddlGenContextPtr->m_forceTbDbSqlName.empty() == false)
        {
            SET_SYSNAME(xdEntityStp, A_XdEntity_Database, this->ddlGenContextPtr->m_forceTbDbSqlName.c_str());
        }
        else if (tempTableSpec == DdlGenDbi::TempTableSpec::Session ||
                 tempTableSpec == DdlGenDbi::TempTableSpec::Type)
        {
            SET_NULL_DICT(xdEntityStp, A_XdEntity_SegmentDictId);
            SET_NULL_DICT(xdEntityStp, A_XdEntity_DatabaseDictId);
            SET_NULL_STRING(xdEntityStp, A_XdEntity_Segment);
            SET_NULL_STRING(xdEntityStp, A_XdEntity_Database);
            SET_NULL_DICT(xdEntityStp, A_XdEntity_IdxSegmentDictId);
        }

        if (cfgObjSectionStp != nullptr)
        {
            SET_ENUM(xdEntityStp, A_XdEntity_AuditEn, cfgObjSectionStp->auditAuthEn);

            if ((this->bTableToDo || this->bUdTableToDo || this->bIdxToDo || GET_ENUM(xdEntityStp, A_XdEntity_DbRuleEn) == DbRule_Template))
            {
                if (IS_NULLFLD(xdEntityStp, A_XdEntity_SegmentDictId) == TRUE)
                {
                    map<string, CFG_SEG_SECTION>::iterator segIter;
                    map<string, CFG_SEG_SECTION>::iterator idxSegIter;

                    if ((segIter = this->ddlGenContextPtr->getCfgFileHelper().segSectionMap.find(cfgObjSectionStp->tbSeg)) != this->ddlGenContextPtr->getCfgFileHelper().segSectionMap.end() &&
                        (idxSegIter = this->ddlGenContextPtr->getCfgFileHelper().segSectionMap.find(cfgObjSectionStp->idxSeg)) != this->ddlGenContextPtr->getCfgFileHelper().segSectionMap.end())
                    {
                        SET_DICT(xdEntityStp, A_XdEntity_SegmentDictId, segIter->second.segDictId);
                        SET_SYSNAME(xdEntityStp, A_XdEntity_Segment, segIter->second.segSqlName.c_str());
                        SET_DICT(xdEntityStp, A_XdEntity_IdxSegmentDictId, idxSegIter->second.segDictId);
                        SET_DICT(xdEntityStp, A_XdEntity_DatabaseDictId, segIter->second.dbDictId);
                        SET_SYSNAME(xdEntityStp, A_XdEntity_Database, segIter->second.dbSqlName.c_str());
                    }
                    else if (IS_NULLFLD(xdEntityStp, A_XdEntity_SegmentDictId) == TRUE &&
                             this->ddlGenContextPtr->getCfgFileHelper().segSectionMap.empty() == false)
                    {
                        ret = RET_DBA_ERR_NODATA;
                        this->printMsg(ret, "The Entity/ Object information is missing in aaa_install.cfg under TRIPLE_A_OBJECTS_SECTION");
                    }

                    if (segIter != this->ddlGenContextPtr->getCfgFileHelper().segSectionMap.end())
                    {
                        SET_DICT(xdEntityStp, A_XdEntity_DatabaseDictId, segIter->second.dbDictId);
                        SET_SYSNAME(xdEntityStp, A_XdEntity_Database, segIter->second.dbSqlName.c_str());
                    }
                    else
                    {
                        map<string, CFG_DB_SECTION>::iterator dbIter;

                        if ((dbIter = this->ddlGenContextPtr->getCfgFileHelper().dbSectionMap.find(cfgObjSectionStp->dbFct)) != this->ddlGenContextPtr->getCfgFileHelper().dbSectionMap.end())
                        {
                            SET_DICT(xdEntityStp, A_XdEntity_DatabaseDictId, dbIter->second.dbDictId);
                            SET_SYSNAME(xdEntityStp, A_XdEntity_Database, dbIter->second.dbSqlName.c_str());
                        }
                    }
                }

                if (GET_FLAG(xdEntityStp, A_XdEntity_PrecompFlg) == TRUE &&
                    IS_NULLFLD(xdEntityStp, A_XdEntity_PrecompSegmentDictId) == TRUE)
                {
                    map<string, CFG_TSL_SECTION>::iterator tslIter;
                    map<string, CFG_SEG_SECTION>::iterator segIter;
                    map<string, CFG_SEG_SECTION>::iterator idxSegIter;

                    if ((tslIter = this->ddlGenContextPtr->getCfgFileHelper().tslSectionMap.find("permanent")) != this->ddlGenContextPtr->getCfgFileHelper().tslSectionMap.end() &&
                        (segIter = this->ddlGenContextPtr->getCfgFileHelper().segSectionMap.find(tslIter->second.tbSeg)) != this->ddlGenContextPtr->getCfgFileHelper().segSectionMap.end() &&
                        (idxSegIter = this->ddlGenContextPtr->getCfgFileHelper().segSectionMap.find(tslIter->second.idxSeg)) != this->ddlGenContextPtr->getCfgFileHelper().segSectionMap.end())
                    {
                        SET_DICT(xdEntityStp, A_XdEntity_PrecompSegmentDictId, segIter->second.segDictId);
                        SET_SYSNAME(xdEntityStp, A_XdEntity_PrecompSegment, segIter->second.segSqlName.c_str());
                    }
                    else if (IS_NULLFLD(xdEntityStp, A_XdEntity_PrecompSegmentDictId) == TRUE &&
                             this->ddlGenContextPtr->getCfgFileHelper().segSectionMap.empty() == false)
                    {
                        ret = RET_DBA_ERR_NODATA;
                        this->printMsg(ret, "The Entity/ Object information is missing in aaa_install.cfg under TRIPLE_A_OBJECTS_SECTION");
                    }

                    if (segIter != this->ddlGenContextPtr->getCfgFileHelper().segSectionMap.end())
                    {
                        SET_DICT(xdEntityStp, A_XdEntity_PrecompDatabaseDictId, segIter->second.dbDictId);
                        SET_SYSNAME(xdEntityStp, A_XdEntity_PrecompDatabase, segIter->second.dbSqlName.c_str());
                    }
                    else
                    {
                        map<string, CFG_DB_SECTION>::iterator dbIter;

                        if ((dbIter = this->ddlGenContextPtr->getCfgFileHelper().dbSectionMap.find(cfgObjSectionStp->dbFct)) != this->ddlGenContextPtr->getCfgFileHelper().dbSectionMap.end())
                        {
                            SET_DICT(xdEntityStp, A_XdEntity_DatabaseDictId, dbIter->second.dbDictId);
                            SET_SYSNAME(xdEntityStp, A_XdEntity_Database, dbIter->second.dbSqlName.c_str());
                        }
                    }
                }

                DdlGenDbaAccessGuard ddlGenDbaAccessGuard(*this->ddlGenContextPtr);

                if (IS_NULLFLD(xdEntityStp, A_XdEntity_DatabaseDictId) == TRUE &&
                    IS_NULLFLD(xdEntityStp, A_XdEntity_SegmentDictId) == FALSE)
                {
                    DBA_DYNFLD_STP dictSegmentStp = ddlGenDbaAccessGuard.getDdlGenDbaAccess().getRecordById(DictSegment, GET_DICT(xdEntityStp, A_XdEntity_SegmentDictId), true);
                    if (dictSegmentStp != nullptr)
                    {
                        this->copyDynFld(xdEntityStp, A_XdEntity_Segment, dictSegmentStp, A_DictSegment_SqlName);

                        DBA_DYNFLD_STP dictDatabaseStp = ddlGenDbaAccessGuard.getDdlGenDbaAccess().getRecordById(DictDatabase, GET_DICT(dictSegmentStp, A_DictSegment_DbDictId), true);
                        if (dictDatabaseStp != nullptr)
                        {
                            this->copyDynFld(xdEntityStp, A_XdEntity_Database, dictDatabaseStp, A_DictDatabase_SqlName);
                            this->copyDynFld(xdEntityStp, A_XdEntity_DatabaseDictId, dictDatabaseStp, A_DictDatabase_DictId);
                        }
                    }
                }

                if (IS_NULLFLD(xdEntityStp, A_XdEntity_PrecompDatabaseDictId) == TRUE &&
                    IS_NULLFLD(xdEntityStp, A_XdEntity_PrecompSegmentDictId) == FALSE)
                {
                    DBA_DYNFLD_STP dictSegmentStp = ddlGenDbaAccessGuard.getDdlGenDbaAccess().getRecordById(DictSegment, GET_DICT(xdEntityStp, A_XdEntity_PrecompSegmentDictId), true);
                    if (dictSegmentStp != nullptr)
                    {
                        this->copyDynFld(xdEntityStp, A_XdEntity_PrecompSegment, dictSegmentStp, A_DictSegment_SqlName);

                        DBA_DYNFLD_STP dictDatabaseStp = ddlGenDbaAccessGuard.getDdlGenDbaAccess().getRecordById(DictDatabase, GET_DICT(dictSegmentStp, A_DictSegment_DbDictId), true);
                        if (dictDatabaseStp != nullptr)
                        {
                            this->copyDynFld(xdEntityStp, A_XdEntity_PrecompDatabase, dictDatabaseStp, A_DictDatabase_SqlName);
                            this->copyDynFld(xdEntityStp, A_XdEntity_PrecompDatabaseDictId, dictDatabaseStp, A_DictDatabase_DictId);
                        }
                    }
                }

                if (IS_NULLFLD(xdEntityStp, A_XdEntity_DatabaseDictId) == TRUE)
                {
                    ret = RET_DBA_ERR_MD;
                    this->printMsg(ret, "The Entity/ Object information is missing in aaa_install.cfg under TRIPLE_A_OBJECTS_SECTION");
                }
            }
        }

        if (GET_ENUM(xdEntityStp, A_XdEntity_PkRuleEn) == PkRule_Identity)
        {
            if (IS_NULLFLD(xdEntityStp, A_XdEntity_IdentityIncrement) == TRUE)
            {
                int    idIncrement = this->ddlGenContextPtr->getCfgFileHelper().getPropertyUnsignedOrDefValue("IDENTITY_INCREMENT", 1);
                SET_INT(xdEntityStp, A_XdEntity_IdentityIncrement, idIncrement);
            }
        }

        /* PMSTA-18096 - LJE - 140620 */
        if (GET_FLAG(xdEntityStp, A_XdEntity_IdentityFlg) == TRUE &&
            GET_ENUM(xdEntityStp, A_XdEntity_PkRuleEn) != PkRule_Identity &&
            GET_ENUM(xdEntityStp, A_XdEntity_PkRuleEn) != PkRule_ExternalPk)
        {
            string msg = "The identity flag (xd_entity.identity_f) is not consistent with the primary key rule (xd_entity.pk_rule_e)";
            msg += ": " + string(GET_SYSNAME(xdEntityStp, A_XdEntity_SqlName));
            MSG_SendMesg(RET_DBA_ERR_MD, 6, FILEINFO, msg.c_str());
            ret = RET_DBA_ERR_MD;
            this->printMsg(ret, msg);
        }
        /* Deprecated attribute "identity_f" is derived from "pk_rule_e" */
        else if (GET_FLAG(xdEntityStp, A_XdEntity_IdentityFlg) == FALSE &&
                 GET_ENUM(xdEntityStp, A_XdEntity_PkRuleEn) == PkRule_Identity)
        {
            SET_FLAG_TRUE(xdEntityStp, A_XdEntity_IdentityFlg);
        }

        /* PMSTA-27499 - LJE - 170614 */
        if (GET_ENUM(xdEntityStp, A_XdEntity_NatEn) == EntityNat_ReportFmt)
        {
            SET_ENUM(xdEntityStp, A_XdEntity_LoadDictRuleEn, LoadDictRule_Never);
        }

        if (this->ddlGenEntityPtr->getXdAttribNbr() == 0)
        {
            ret = RET_DBA_ERR_NODATA;
            this->printMsg(ret, "No attribute");
        }

        if ((ret = this->addMandatoryAttributes(requestHelper)) != RET_SUCCEED)
        {
            gblRet = ret;
        }

        /* PMSTA-37366 - LJE - 200203 */
        if ((ret = this->manageExtAttributes(requestHelper)) != RET_SUCCEED)
        {
            gblRet = ret;
        }

        if (this->m_dictEntityStp == NULL ||
            this->m_dictEntityStp->bIsInitEntity == false)
        {
            if ((ret = this->checkAllAttributes()) != RET_SUCCEED)
            {
                gblRet = ret;
            }
        }

        /* PMSTA-16575 - LJE - 130627 */
        if (this->ddlGenContextPtr->isEnableAdditionalDSP() == false &&
            GET_ENUM(xdEntityStp, A_XdEntity_SecurityLevelEn) == EntSecuLevel_Secured2ndLevel)
        {
            SET_ENUM(xdEntityStp, A_XdEntity_SecurityLevelEn, EntSecuLevel_Secured);
        }

        if (strcmp(GET_SYSNAME(xdEntityStp, A_XdEntity_SqlName), "grid") == 0 &&
            this->ddlGenContextPtr->getCfgFileHelper().getProperty("ENABLE_SECURED_GRID").compare("0") == 0)
        {
            SET_ENUM(xdEntityStp, A_XdEntity_SecurityLevelEn, EntSecuLevel_NoSecured);
        }
        else if (strcmp(GET_SYSNAME(xdEntityStp, A_XdEntity_SqlName), "classification") == 0 &&
                 this->ddlGenContextPtr->getCfgFileHelper().getProperty("ENABLE_SECURED_CLASSIF").compare("0") == 0)
        {
            SET_ENUM(xdEntityStp, A_XdEntity_SecurityLevelEn, EntSecuLevel_NoSecured);
        }

        std::string realSqlName;
        if (this->bTableToDo && 
            this->ddlGenEntityPtr->getSysXdEntityStp(realSqlName) == nullptr)
        {
            if (this->bTableToDo)
            {
                SET_NULL_DATETIME(xdEntityStp, A_XdEntity_BuildDate);

                /* PMSTA-24007 - LJE - 170718 */
                if (this->m_dictEntityStp != nullptr)
                {
                    this->m_dictEntityStp->xdStatusEn = XdStatus_Untreated;
                }
                SET_ENUM(xdEntityStp, A_XdEntity_XdStatusEn, XdStatus_Untreated);
            }
        }
        else
        {
            SET_ENUM(xdEntityStp, A_XdEntity_XdStatusEn, XdStatus_Inserted);
        }

        std::map < FLAG_T, std::map<INT_T, string>>    progNMap;
        std::map<FLAG_T, std::map<SMALLINT_T, string>> dispRankMap;
        std::map<INT_T, string>                        shortIdxMap;
        std::map<SMALLINT_T, string>                   progPkNMap;
        std::map<SMALLINT_T, string>                   progBkNMap;

        /* PMSTA-47725 - LJE - 220118 - Manage migration of entity_dict_id */
        if (IS_NULLFLD(xdEntityStp, A_XdEntity_EntityDictId) == FALSE &&
            IS_NULLFLD(xdEntityStp, A_XdEntity_DictEntityValue) == FALSE &&
            GET_INT(xdEntityStp, A_XdEntity_DictEntityValue) != CAST_INT(GET_DICT(xdEntityStp, A_XdEntity_EntityDictId)))
        {
            /* Only allowed for temporary tables */
            if (GET_ENUM(xdEntityStp, A_XdEntity_NatEn) != EntityNat_TempTable)
            {
                stringstream msg;
                msg << "Mismatch values between entity_dict_id (" << CAST_INT(GET_DICT(xdEntityStp, A_XdEntity_EntityDictId))
                    << ") and dict_entity_value (" << GET_INT(xdEntityStp, A_XdEntity_DictEntityValue)
                    << ")";

                this->printMsg(RET_DBA_ERR_MD, msg.str());
            }
            else
            {
                SET_NULL_DICT(xdEntityStp, A_XdEntity_EntityDictId);

                for (i = 0; i < this->ddlGenEntityPtr->getXdAttribNbr(); i++)
                {
                    DBA_DYNFLD_STP     currXdAttribStp = this->ddlGenEntityPtr->getXdAttrib(i);
                    SET_NULL_DICT(currXdAttribStp, A_XdAttrib_AttribDictId);
                }
            }
        }


        map<TINYINT_T, DBA_DYNFLD_STP> sortingRankCheckMap;

        /* Check that the business key is just after the primary key */
        for (i = 0; i < this->ddlGenEntityPtr->getXdAttribNbr(); i++)
        {
            DBA_DYNFLD_STP     currXdAttribStp = this->ddlGenEntityPtr->getXdAttrib(i);
            DATATYPE_ENUM      fieldType = DATATYPE_DICT_TO_ENUM(GET_DICT(currXdAttribStp, A_XdAttrib_DataTpDictId));
            DBA_DYNFLD_STP     sysXdAttribStp = NULL;
            string             sqlName = GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName);
            TARGET_TABLE_ENUM  targetTabelEn = this->ddlGenEntityPtr->getTargetTableEnum(currXdAttribStp);
            DICT_DATATP_STP    dataTypeStp = DBA_GetDictDataTpStp(fieldType);
            auto               xdPermValMapPtr = this->ddlGenEntityPtr->getXdPermValByAttribMap(currXdAttribStp);
            auto               xdPermValAttribMapPtr = this->ddlGenEntityPtr->getXdPermValByAttribMap(GET_ID(currXdAttribStp, A_XdAttrib_Id));

            if (dataTypeStp == nullptr)
            {
                gblRet = RET_DBA_ERR_MD;
                this->printMsg(gblRet, "Invalid Data type for attribute " + sqlName);
                continue;
            }

            if ((GET_ENUM(xdEntityStp, A_XdEntity_XdActionEn) == XdAction_ToInsert ||
                 GET_ENUM(xdEntityStp, A_XdEntity_XdActionEn) == XdAction_ToRefresh) &&
                GET_ENUM(currXdAttribStp, A_XdAttrib_XdActionEn) == XdAction_None &&
                GET_ENUM(currXdAttribStp, A_XdAttrib_CustomFlg) != Custom_No &&
                GET_ENUM(currXdAttribStp, A_XdAttrib_XdStatusEn) == XdStatus_Inserted)
            {
                SET_ENUM(currXdAttribStp, A_XdAttrib_XdActionEn, XdAction_ToInsert);
            }
            /* Manage only inserted attributes for precomputed */
            else if (GET_FLAG(currXdAttribStp, A_XdAttrib_PrecompFlg) == TRUE &&
                     GET_A_XdAttrib_FeatureEn(currXdAttribStp) == XdEntityFeatureFeatureEn::None)
            {
                if ((GET_ENUM(xdEntityStp, A_XdEntity_XdActionEn) == XdAction_ToInsert ||
                     GET_ENUM(xdEntityStp, A_XdEntity_XdActionEn) == XdAction_ToRefresh) &&
                    (GET_ENUM(currXdAttribStp, A_XdAttrib_XdActionEn) == XdAction_ToDeprecate ||
                     GET_ENUM(currXdAttribStp, A_XdAttrib_XdActionEn) == XdAction_None) &&
                    GET_ENUM(currXdAttribStp, A_XdAttrib_XdStatusEn) == XdStatus_Inserted)
                {
                    SET_ENUM(currXdAttribStp, A_XdAttrib_XdActionEn, XdAction_ToInsert);
                }
            }
            else if (GET_ENUM(currXdAttribStp, A_XdAttrib_XdActionEn) == XdAction_ToDeprecate)
            {
                SET_ENUM(currXdAttribStp, A_XdAttrib_XdActionEn, XdAction_ToDelete);
            }
            else if (GET_ENUM(currXdAttribStp, A_XdAttrib_XdActionEn) == XdAction_None &&
                     GET_ENUM(currXdAttribStp, A_XdAttrib_XdStatusEn) == XdStatus_Inserted)
            {
                SET_ENUM(currXdAttribStp, A_XdAttrib_XdActionEn, XdAction_ToInsert);
            }

            /* PMSTA-37366 - LJE - 200610 - No longer physical multi-language master attribute */
            if (GET_FLAG(currXdAttribStp, A_XdAttrib_MultiLangFlg) == TRUE)
            {
                SET_ENUM(currXdAttribStp, A_XdAttrib_CalcEn, DictAttr_Virtual);
            }

            /* PMSTA-26108 - LJE - 170929 */
            if (GET_ENUM(xdEntityStp, A_XdEntity_NatEn) != EntityNat_Custom &&
                GET_ENUM(xdEntityStp, A_XdEntity_NatEn) != EntityNat_CustomDS &&
                GET_ENUM(xdEntityStp, A_XdEntity_NatEn) != EntityNat_Questionnaire &&
                GET_ENUM(xdEntityStp, A_XdEntity_NatEn) != EntityNat_ReportFmt &&
                GET_ENUM(xdEntityStp, A_XdEntity_NatEn) != EntityNat_PersistedFmt &&
                GET_ENUM(xdEntityStp, A_XdEntity_NatEn) != EntityNat_SearchFmt &&
                GET_ENUM(xdEntityStp, A_XdEntity_DictBuildRuleEn) != DictBuildRule_AllDb &&
                GET_ENUM(currXdAttribStp, A_XdAttrib_XdActionEn) == XdAction_ToInsert &&
                GET_A_XdAttrib_FeatureEn(currXdAttribStp) == XdEntityFeatureFeatureEn::None &&
                static_cast<DBA_CUSTOM_ENUM>(GET_ENUM(currXdAttribStp, A_XdAttrib_CustomFlg)) == Custom_No &&
                GET_FLAG(currXdAttribStp, A_XdAttrib_PrecompFlg) == FALSE &&
                static_cast<MODEL_BANK_ENUM>(GET_ENUM(currXdAttribStp, A_XdAttrib_ModelBankEn)) == ModelBank_None &&
                GET_FLAG(currXdAttribStp, A_XdAttrib_MultiLangFlg) == FALSE)
            {
                if (IS_NULLFLD(currXdAttribStp, A_XdAttrib_Prog) == FALSE)
                {
                    auto progNIt = progNMap[GET_FLAG(currXdAttribStp, A_XdAttrib_LogicalFlg)].find(GET_INT(currXdAttribStp, A_XdAttrib_Prog));
                    if (progNIt == progNMap[GET_FLAG(currXdAttribStp, A_XdAttrib_LogicalFlg)].end())
                    {
                        progNMap[GET_FLAG(currXdAttribStp, A_XdAttrib_LogicalFlg)].insert(make_pair(GET_INT(currXdAttribStp, A_XdAttrib_Prog), sqlName));
                    }
                    else
                    {
                        string msg = "Duplicate prog_n for attribute: " + sqlName + " and attribute " + progNIt->second;
                        ret = RET_DBA_ERR_MD;
                        this->printMsg(ret, msg);
                    }
                }
            }

            if (GET_ENUM(currXdAttribStp, A_XdAttrib_XdActionEn) == XdAction_ToInsert)
            {
                if (IS_NULLFLD(currXdAttribStp, A_XdAttrib_ProgPk) == FALSE ||
                    GET_FLAG(currXdAttribStp, A_XdAttrib_PrimaryFlg) == TRUE)
                {
                    auto progNIt = progPkNMap.find(IS_NULLFLD(currXdAttribStp, A_XdAttrib_ProgPk) == FALSE ?
                                                   GET_SMALLINT(currXdAttribStp, A_XdAttrib_ProgPk) :
                                                   static_cast<SMALLINT_T>(progPkNMap.size() + PROG_N_INIT));
                    if (progNIt == progPkNMap.end())
                    {
                        progPkNMap.insert(make_pair(GET_SMALLINT(currXdAttribStp, A_XdAttrib_ProgPk), sqlName));
                    }
                    else
                    {
                        string msg = "Duplicate prog_pk_n for attribute: " + sqlName + " and attribute " + progNIt->second;
                        ret = RET_DBA_ERR_MD;
                        this->printMsg(ret, msg);
                    }
                }

                if (IS_NULLFLD(currXdAttribStp, A_XdAttrib_ProgBk) == FALSE ||
                    GET_FLAG(currXdAttribStp, A_XdAttrib_BusKeyFlg) == TRUE)
                {
                    auto progNIt = progBkNMap.find(IS_NULLFLD(currXdAttribStp, A_XdAttrib_ProgBk) == FALSE ?
                                                   GET_SMALLINT(currXdAttribStp, A_XdAttrib_ProgBk) :
                                                   static_cast<SMALLINT_T>(progBkNMap.size() + PROG_N_INIT));
                    if (progNIt == progBkNMap.end())
                    {
                        progBkNMap.insert(make_pair(GET_SMALLINT(currXdAttribStp, A_XdAttrib_ProgBk), sqlName));
                    }
                    else
                    {
                        string msg = "Duplicate prog_bk_n for attribute: " + sqlName + " and attribute " + progNIt->second;
                        ret = RET_DBA_ERR_MD;
                        this->printMsg(ret, msg);
                    }
                }

                if (IS_NULLFLD(currXdAttribStp, A_XdAttrib_ShortIdx) == FALSE &&
                    GET_SMALLINT(currXdAttribStp, A_XdAttrib_ShortIdx) != PROG_N_START_SHORT_CUSTO &&
                    GET_A_XdAttrib_FeatureEn(currXdAttribStp) == XdEntityFeatureFeatureEn::None)
                {
                    auto progNIt = shortIdxMap.find(GET_INT(currXdAttribStp, A_XdAttrib_ShortIdx));
                    if (progNIt == shortIdxMap.end())
                    {
                        shortIdxMap.insert(make_pair(GET_INT(currXdAttribStp, A_XdAttrib_ShortIdx), sqlName));
                    }
                    else
                    {
                        string msg = "Duplicate short_index_n for attribute: " + sqlName + " and attribute " + progNIt->second;
                        ret = RET_DBA_ERR_MD;
                        this->printMsg(ret, msg);
                    }
                }
            }

            if (this->bTableToDo)
            {
                sysXdAttribStp = this->ddlGenEntityPtr->getSysXdAttribStp(targetTabelEn, sqlName);

                if (sysXdAttribStp == nullptr &&
                    DATATYPE_DICT_TO_ENUM(GET_DICT(currXdAttribStp, A_XdAttrib_DataTpDictId)) == TimeStampType)
                {
                    sysXdAttribStp = this->ddlGenEntityPtr->getSysXdAttribStp(targetTabelEn, "row_version");
                }

                if (sysXdAttribStp == NULL)
                {
                    SET_NULL_DATETIME(currXdAttribStp, A_XdAttrib_BuildDate);
                }

                if (sysXdAttribStp != NULL)
                {
                    if (GET_ENUM(currXdAttribStp, A_XdAttrib_XdStatusEn) == XdStatus_Untreated ||
                        GET_ENUM(currXdAttribStp, A_XdAttrib_XdStatusEn) == XdStatus_Failed)
                    {
                        SET_ENUM(currXdAttribStp, A_XdAttrib_XdStatusEn, XdStatus_Inserted);
                    }
                    else if (GET_ENUM(currXdAttribStp, A_XdAttrib_XdStatusEn) == XdStatus_PhysicallyDeleted)
                    {
                        SET_ENUM(currXdAttribStp, A_XdAttrib_XdStatusEn, XdStatus_Inserted);

                        if (GET_ENUM(currXdAttribStp, A_XdAttrib_XdActionEn) != XdAction_ToInsert)
                        {
                            SET_ENUM(currXdAttribStp, A_XdAttrib_XdActionEn, XdAction_ToPhysicallyDelete);
                        }
                    }

                    /* OCS-43062 - LJE - 130829 - Use the database information to sort the attributes (if not defined) */
                    if (IS_NULLFLD(sysXdAttribStp, A_XdAttrib_Prog) == FALSE &&
                        (GET_ENUM(xdEntityStp, A_XdEntity_SecurityLevelEn) == EntSecuLevel_InsertAllowed ||
                         GET_ENUM(xdEntityStp, A_XdEntity_SecurityLevelEn) == EntSecuLevel_InsertDeleteAllowed))
                    {
                        COPY_DYNFLD(currXdAttribStp, A_XdAttrib, A_XdAttrib_Prog,
                                    sysXdAttribStp, A_XdAttrib, A_XdAttrib_Prog);

                        COPY_DYNFLD(currXdAttribStp, A_XdAttrib, A_XdAttrib_DbProg,
                                    sysXdAttribStp, A_XdAttrib, A_XdAttrib_Prog);
                    }
                    else if (IS_NULLFLD(sysXdAttribStp, A_XdAttrib_Prog) == FALSE &&
                             IS_NULLFLD(currXdAttribStp, A_XdAttrib_Prog) == TRUE)
                    {
                        COPY_DYNFLD(currXdAttribStp, A_XdAttrib, A_XdAttrib_Prog,
                                    sysXdAttribStp, A_XdAttrib, A_XdAttrib_Prog);

                        COPY_DYNFLD(currXdAttribStp, A_XdAttrib, A_XdAttrib_DbProg,
                                    sysXdAttribStp, A_XdAttrib, A_XdAttrib_Prog);
                    }
                }
                else if ((GET_ENUM(currXdAttribStp, A_XdAttrib_XdStatusEn) == XdStatus_Inserted ||
                          GET_ENUM(currXdAttribStp, A_XdAttrib_XdStatusEn) == XdStatus_Deprecated) &&
                         GET_FLAG(currXdAttribStp, A_XdAttrib_LogicalFlg) == FALSE &&
                         DictAttribClass::isPhysicalCalcEn((DICTATTR_ENUM)GET_ENUM(currXdAttribStp, A_XdAttrib_CalcEn)) == TRUE)
                {
                    SET_ENUM(currXdAttribStp, A_XdAttrib_XdStatusEn, XdStatus_Untreated);
                }
                else if (GET_ENUM(currXdAttribStp, A_XdAttrib_XdStatusEn) == XdStatus_Failed)
                {
                    SET_ENUM(currXdAttribStp, A_XdAttrib_XdStatusEn, XdStatus_Untreated);
                }
                else if (GET_ENUM(currXdAttribStp, A_XdAttrib_XdActionEn) != XdAction_ToInsert &&
                         GET_FLAG(currXdAttribStp, A_XdAttrib_LogicalFlg) == FALSE &&
                         GET_ENUM(currXdAttribStp, A_XdAttrib_XdStatusEn) != XdStatus_PhysicallyDeleted)
                {
                    SET_ENUM(currXdAttribStp, A_XdAttrib_XdStatusEn, XdStatus_PhysicallyDeleted);

                    requestHelper.dbaCall(Update,
                                          XdAttrib,
                                          DBA_ROLE_STATUS,
                                          currXdAttribStp);
                }

                /* Case of reactivation of the attribute */
                if (GET_ENUM(currXdAttribStp, A_XdAttrib_XdActionEn) == XdAction_ToInsert &&
                    (GET_ENUM(currXdAttribStp, A_XdAttrib_XdStatusEn) == XdStatus_PhysicallyDeleted ||
                     GET_ENUM(currXdAttribStp, A_XdAttrib_XdStatusEn) == XdStatus_Deleted))
                {
                    if (sysXdAttribStp == NULL)
                    {
                        SET_ENUM(currXdAttribStp, A_XdAttrib_XdStatusEn, XdStatus_Untreated);
                    }
                    else
                    {
                        SET_ENUM(currXdAttribStp, A_XdAttrib_XdStatusEn, XdStatus_Inserted);
                    }
                }
            }

            /* PMSTA-24007 - LJE - 170720 */
            if (GET_ENUM(xdEntityStp, A_XdEntity_NatEn) == EntityNat_TempTable ||
                GET_ENUM(xdEntityStp, A_XdEntity_NatEn) == EntityNat_ReportFmt)
            {
                SET_ENUM(currXdAttribStp, A_XdAttrib_RefCheckRuleEn, RefChkRule_None);
                SET_ENUM(currXdAttribStp, A_XdAttrib_RefDeleteRuleEn, RefDelRule_None);
            }

            /* Force to null-able all attributes of reporting tables */
            if (GET_ENUM(xdEntityStp, A_XdEntity_NatEn) == EntityNat_ReportFmt ||
                this->ddlGenContextPtr->ddlGenAction.m_execModeEn == DbObjExecMod_BuildFromTemplate ||
                this->ddlGenContextPtr->ddlGenAction.m_execModeEn == DbObjExecMod_BuildVirtualFromFmt)
            {
                SET_FLAG_FALSE(currXdAttribStp, A_XdAttrib_DbMandatoryFlg);
                SET_FLAG_FALSE(currXdAttribStp, A_XdAttrib_MandatoryFlg);
            }

            if (ICU4AAA_SQLServerUTF8 == 0)
            {
                DATATYPE_ENUM newFieldType = DBA_ConvUniDataTypeToDataType(fieldType);
                /* Replace switch by a call to conversion function to treat all unicode datatype */
                if (fieldType != newFieldType)
                {
                    SET_DICT(currXdAttribStp, A_XdAttrib_DataTpDictId, DATATYPE_ENUM_TO_DICT(newFieldType));
                    fieldType = newFieldType;
                }
            }

            if (this->ddlGenContextPtr->m_rdbmsEn == Sqlite &&
                GET_ENUM(xdEntityStp, A_XdEntity_PkRuleEn) == PkRule_Identity &&
                GET_FLAG(currXdAttribStp, A_XdAttrib_PrimaryFlg) == TRUE &&
                fieldType != IdType &&
                fieldType != DictType)
            {
                SET_DICT(currXdAttribStp, A_XdAttrib_DataTpDictId, DATATYPE_ENUM_TO_DICT(IdType));
                fieldType = IdType;
            }

            /* PMSTA-29879 - LJE - 180208 */
            if (GET_ENUM(currXdAttribStp, A_XdAttrib_XdActionEn) != XdAction_ToInsert)
            {
                if ((fieldType == EnumType || fieldType == FlagType || fieldType == EnumMaskType) &&
                    IS_NOTNULL(currXdAttribStp, A_XdAttrib_ParentXdAttribId) &&
                    IS_NOTNULL(currXdAttribStp, A_XdAttrib_AttribDictId))
                {
                    DbiConnectionHelper dbiConnHelper(&ddlGenConnGuard.getDbiConn());

                    if (xdPermValAttribMapPtr != nullptr)
                    {
                        for (auto& permValIt : *xdPermValAttribMapPtr)
                        {
                            SET_ENUM(permValIt.second, A_XdPermVal_XdActionEn, XdAction_None);
                            SET_ENUM(permValIt.second, A_XdPermVal_XdStatusEn, XdStatus_Deleted);

                            dbiConnHelper.dbaUpdate(XdPermVal, DBA_ROLE_UDT, permValIt.second);
                        }
                    }

                    dbiConnHelper.dbaDelete(DictPermVal, UNUSED, currXdAttribStp);
                }

                /* PMSTA-38252 - LJE - 200129 */
                if (GET_A_XdAttrib_FeatureEn(currXdAttribStp) == XdEntityFeatureFeatureEn::MultiBusinessEntityManagement ||
                    GET_A_XdAttrib_FeatureEn(currXdAttribStp) == XdEntityFeatureFeatureEn::AccessRightManagement)
                {
                    SET_ENUM(currXdAttribStp, A_XdAttrib_XdActionEn, XdAction_ToPhysicallyDelete);
                }

                continue;
            }

            if (GET_ENUM(xdEntityStp, A_XdEntity_NatEn) != EntityNat_TempTable &&
                GET_ENUM(xdEntityStp, A_XdEntity_NatEn) != EntityNat_ReportFmt &&
                (fieldType == IdType || fieldType == DictType) &&
                GET_FLAG(currXdAttribStp, A_XdAttrib_PrimaryFlg) == FALSE &&
                GET_ENUM(xdEntityStp, A_XdEntity_LogicalFlg) == FALSE &&
                IS_NULLFLD(currXdAttribStp, A_XdAttrib_RefXdEntityId) == TRUE &&
                IS_NULLFLD(currXdAttribStp, A_XdAttrib_LinkedXdAttribId) == TRUE &&
                GET_FLAG(currXdAttribStp, A_XdAttrib_ShortOnlyFlg) == FALSE &&
                DdlGen::getUdIdSqlName().compare(GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName)) != 0 &&
                DdlGen::getXIdSqlName().compare(GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName)) != 0)
            {
                string msg = "Ref. entity is missing ";
                msg += string(GET_SYSNAME(xdEntityStp, A_XdEntity_SqlName)) + "." + string(GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName));
                MSG_SendMesg(RET_DBA_ERR_MD, 6, FILEINFO, msg.c_str());
                ret = RET_DBA_ERR_MD;

                if (this->ddlGenContextPtr->bIgnoreCheck)
                {
                    ret = RET_GEN_INFO_NOACTION;
                }
                this->printMsg(ret, msg);
            }

            /* PMSTA-26554 - LJE - 181108 */
            if (GET_FLAG(currXdAttribStp, A_XdAttrib_PrimaryFlg) == TRUE &&
                (DB_RULE_ENUM)GET_ENUM(xdEntityStp, A_XdEntity_DbRuleEn) == DbRule_PartialSpecialization)
            {
                this->copyDynFld(currXdAttribStp, A_XdAttrib_RefXdEntityId, xdEntityStp, A_XdEntity_LinkedXdEntityId); /* PMSTA-45413 - LJE - 210623 */

                SET_ENUM(currXdAttribStp, A_XdAttrib_RefCheckRuleEn, RefChkRule_Checked);
                SET_ENUM(currXdAttribStp, A_XdAttrib_RefDeleteRuleEn, RefDelRule_CascadeDelete);
            }

            if (fieldType == EnumType || fieldType == FlagType || fieldType == EnumMaskType)
            {
                if (GET_ENUM(xdEntityStp, A_XdEntity_NatEn) != EntityNat_TempTable &&
                    GET_ENUM(xdEntityStp, A_XdEntity_NatEn) != EntityNat_ReportFmt &&
                    GET_ENUM(xdEntityStp, A_XdEntity_NatEn) != EntityNat_Internal &&
                    GET_FLAG(currXdAttribStp, A_XdAttrib_PrecompFlg) == FALSE &&
                    GET_FLAG(currXdAttribStp, A_XdAttrib_ShortOnlyFlg) == FALSE &&
                    IS_NULLFLD(currXdAttribStp, A_XdAttrib_TemplateXdAttribId) == TRUE)
                {
                    /* PMSTA-32549 - LJE - 180823 */
                    if (IS_NULLFLD(currXdAttribStp, A_XdAttrib_Default) == FALSE)
                    {
                        string defaultValue = GET_NAME(currXdAttribStp, A_XdAttrib_Default);

                        if (defaultValue.find_first_not_of(DDLGEN_NUMERIC) != string::npos)
                        {
                            ret = RET_DBA_ERR_MD;

                            string msg = "Invalid permitted value  '" + defaultValue + "' for attribute " + GET_SYSNAME(xdEntityStp, A_XdEntity_SqlName) + "." + GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName);
                            this->printMsg(ret, msg);

                            defaultValue.clear();
                            SET_NULL_NAME(currXdAttribStp, A_XdAttrib_Default);
                        }
                    }

                    if (GET_ENUM(currXdAttribStp, A_XdAttrib_CustomFlg) == Custom_No)
                    {
                        if (IS_NULLFLD(currXdAttribStp, A_XdAttrib_ParentXdAttribId) &&
                            fieldType == FlagType &&
                            GET_ENUM(xdEntityStp, A_XdEntity_NatEn) == EntityNat_Questionnaire)
                        {
                            DdlGenEntity* tplDdlGenEntity = this->ddlGenContextPtr->getTemplateDdlGenEntityPtr();

                            if (tplDdlGenEntity != nullptr)
                            {
                                auto flagXdAttribStp = tplDdlGenEntity->getXdAttribBySqlName("active_f");

                                if (flagXdAttribStp != nullptr)
                                {
                                    COPY_DYNFLD(currXdAttribStp, A_XdAttrib, A_XdAttrib_ParentXdAttribId, flagXdAttribStp, A_XdAttrib, A_XdAttrib_Id);

                                    xdPermValMapPtr = tplDdlGenEntity->getXdPermValByAttribMap(flagXdAttribStp);
                                }
                            }
                        }

                        if (IS_NULLFLD(currXdAttribStp, A_XdAttrib_ParentXdAttribId) &&
                            (xdPermValMapPtr == nullptr || xdPermValMapPtr->empty()))
                        {
                            ret = RET_DBA_ERR_MD;

                            string msg = "Missing permitted value for attribute ";
                            msg += string(GET_SYSNAME(xdEntityStp, A_XdEntity_SqlName)) + "." + string(GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName));
                            this->printMsg(ret, msg);
                        }
                        else if (IS_NULLFLD(currXdAttribStp, A_XdAttrib_Default) == TRUE)
                        {
                            /* PMSTA-26857 - LJE - 170330 */
                            if (IS_NULLFLD(currXdAttribStp, A_XdAttrib_ParentXdAttribId))
                            {
                                ret = RET_DBA_ERR_MD;

                                string msg = "Missing default value for the attribute ";
                                msg += string(GET_SYSNAME(xdEntityStp, A_XdEntity_SqlName)) + "." + string(GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName));
                                this->printMsg(ret, msg);
                            }
                        }
                        else if (fieldType != EnumMaskType) /* Check if the default_c is contains on permitted values */
                        {
                            ENUM_T defaultEn = (ENUM_T)atoi(GET_NAME(currXdAttribStp, A_XdAttrib_Default));
                            bool   bCheckDefault = false;

                            if (defaultEn == 0 &&
                                GET_NAME(currXdAttribStp, A_XdAttrib_Default)[0] != '0')
                            {
                                if (strcmp(GET_NAME(currXdAttribStp, A_XdAttrib_Default), "true") == 0)
                                {
                                    SET_NAME(currXdAttribStp, A_XdAttrib_Default, "1");
                                    defaultEn = 1;
                                }
                                else if (strcmp(GET_NAME(currXdAttribStp, A_XdAttrib_Default), "false") != 0)
                                {
                                    ret = RET_DBA_ERR_MD;

                                    string msg = "Missing default value for the attribute ";
                                    msg += string(GET_SYSNAME(xdEntityStp, A_XdEntity_SqlName)) + "." + string(GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName));
                                    this->printMsg(ret, msg);
                                }
                                else
                                {
                                    SET_NAME(currXdAttribStp, A_XdAttrib_Default, "0");
                                }
                            }

                            if (xdPermValMapPtr != nullptr && xdPermValMapPtr->empty() == false)
                            {
                                for (auto permValIt = xdPermValMapPtr->begin(); permValIt != xdPermValMapPtr->end(); ++permValIt)
                                {
                                    if (GET_ENUM(permValIt->second, A_XdPermVal_XdActionEn) == XdAction_ToInsert ||
                                        (GET_ENUM(permValIt->second, A_XdPermVal_XdStatusEn) == XdStatus_Inserted &&
                                         GET_ENUM(permValIt->second, A_XdPermVal_XdActionEn) == XdAction_None))
                                    {
                                        if (defaultEn == GET_ENUM(permValIt->second, A_XdPermVal_PermValNatEn))
                                        {
                                            bCheckDefault = true;
                                        }
                                    }
                                }
                            }

                            if (bCheckDefault == false &&
                                this->ddlGenContextPtr->ddlGenAction.m_mainDdlObjNatEn != DbObjDdlObjNat_System)
                            {
                                string msg = "Invalid default value for attribute ";
                                msg += string(GET_SYSNAME(xdEntityStp, A_XdEntity_SqlName)) + "." + string(GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName));
                                msg += " (must be in permitted values)";
                                this->printMsg(RET_DBA_ERR_MD_INVALID_VALUE, msg);
                                ret = RET_DBA_ERR_MD;
                            }
                        }
                    }
                }
            }
            else if (fieldType == TimeStampType)
            {
                SET_ENUM(currXdAttribStp, A_XdAttrib_CalcEn, DictAttr_PhysSpecUpd);
            }

            /* PMSTA-46681 - LJE - 230310 */
            if (GET_ENUM(currXdAttribStp, A_XdAttrib_PrecompFlg) == TRUE &&
                GET_ENUM(currXdAttribStp, A_XdAttrib_CalcEn) == DictAttr_Denorm)
            {
                SET_ENUM(currXdAttribStp, A_XdAttrib_CalcEn, DictAttr_Physical);
            }

            /* PMSTA-34373 - LJE - 190219 */
            if (IS_NULLFLD(currXdAttribStp, A_XdAttrib_MaxDbLen) == TRUE ||
                GET_SMALLINT(currXdAttribStp, A_XdAttrib_MaxDbLen) == 0)
            {
                if (dataTypeStp->defMaxDbLenN > 0)
                {
                    SET_SMALLINT(currXdAttribStp, A_XdAttrib_MaxDbLen, dataTypeStp->defMaxDbLenN);
                }
                else
                {
                    SET_NULL_SMALLINT(currXdAttribStp, A_XdAttrib_MaxDbLen);
                }
            }

            /* PMSTA-34373 - LJE - 190219 */
            if (IS_NULLFLD(currXdAttribStp, A_XdAttrib_DefaultDispLen) == TRUE ||
                GET_SMALLINT(currXdAttribStp, A_XdAttrib_DefaultDispLen) == 0)
            {
                if (dataTypeStp->defDefaultDisplayLenN > 0)
                {
                    SET_SMALLINT(currXdAttribStp, A_XdAttrib_DefaultDispLen, dataTypeStp->defDefaultDisplayLenN);
                }
                else
                {
                    SET_NULL_SMALLINT(currXdAttribStp, A_XdAttrib_DefaultDispLen);
                }
            }

            if (GET_FLAG(xdEntityStp, A_XdEntity_LogicalFlg) == FALSE &&
                IS_NULLFLD(currXdAttribStp, A_XdAttrib_ProgPk) == FALSE &&
                GET_FLAG(currXdAttribStp, A_XdAttrib_DbMandatoryFlg) == FALSE)
            {
                string msg;

                SYS_StringFormat(msg, "An attribute (%s) belonging to the primary key cannot be 'null-able' !",
                                 GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName));
                ret = RET_DBA_ERR_MD;
                this->printMsg(ret, msg);
            }

            if (DdlGen::getUdIdSqlName().compare(GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName)) == 0 ||
                DdlGen::getXIdSqlName().compare(GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName)) == 0)
            {
                SET_FLAG(currXdAttribStp, A_XdAttrib_MandatoryFlg, TRUE);
                SET_FLAG(currXdAttribStp, A_XdAttrib_DbMandatoryFlg, TRUE);
                SET_SMALLINT(currXdAttribStp, A_XdAttrib_DispRank, 0);
                SET_NULL_MASK(currXdAttribStp, A_XdAttrib_SubTpMask);
                SET_NULL_MASK(currXdAttribStp, A_XdAttrib_QuickSearchMask);
                SET_NULL_MASK(currXdAttribStp, A_XdAttrib_SearchMask);
                SET_ENUM(currXdAttribStp, A_XdAttrib_EditEn, DictAttrib_EditNoEdit);
                SET_ENUM(currXdAttribStp, A_XdAttrib_RefDeleteRuleEn, RefDelRule_CascadeDelete);
                SET_ENUM(currXdAttribStp, A_XdAttrib_RefCheckRuleEn, RefChkRule_Checked);
            }
            /* Force Ud field not database mandatory */
            else if ((GET_ENUM(currXdAttribStp, A_XdAttrib_CustomFlg) != Custom_No ||
                      GET_ENUM(currXdAttribStp, A_XdAttrib_PrecompFlg) == TRUE) &&
                     GET_FLAG(currXdAttribStp, A_XdAttrib_DbMandatoryFlg) == TRUE && 
                    IS_NULLFLD(currXdAttribStp, A_XdAttrib_ProgPk) == TRUE) /*PMSTA-63176 - VPR - 20250301 */
            {
                SET_FLAG_FALSE(currXdAttribStp, A_XdAttrib_DbMandatoryFlg);
            }

            if (this->ddlGenContextPtr->bForceReBuild &&
                GET_FLAG(xdEntityStp, A_XdEntity_LogicalFlg) == FALSE &&
                (GET_ENUM(xdEntityStp, A_XdEntity_XdActionEn) == XdAction_ToInsert) &&
                GET_ENUM(xdEntityStp, A_XdEntity_XdStatusEn) != XdStatus_Untreated &&
                GET_FLAG(currXdAttribStp, A_XdAttrib_ShortOnlyFlg) == FALSE &&
                GET_ENUM(currXdAttribStp, A_XdAttrib_XdStatusEn) == XdStatus_Untreated &&
                IS_NULLFLD(xdEntityStp, A_XdEntity_BuildDate) == FALSE &&
                GET_FLAG(currXdAttribStp, A_XdAttrib_DbMandatoryFlg) == TRUE &&
                DdlGen::getUdIdSqlName().compare(GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName)) != 0)
            {
                if ((IS_NULLFLD(currXdAttribStp, A_XdAttrib_Default) == TRUE || GET_NAME(currXdAttribStp, A_XdAttrib_Default)[0] == 0))
                {
                    char msg[255];

                    sprintf(msg, "ALTER TABLE '%s' failed. Default clause is required in order to add non-NULL column '%s'.\n",
                            GET_SYSNAME(xdEntityStp, A_XdEntity_SqlName),
                            GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName));
                    ret = RET_DBA_ERR_MD;
                    this->printMsg(ret, msg);
                }
            }

            if (this->bShortToDo &&
                GET_FLAG(currXdAttribStp, A_XdAttrib_ShortOnlyFlg) == TRUE)
            {
                string msg = "It's forbidden to specify one attribute only on the short structure for entity with automatic short structure (entity:";
                msg += string(GET_SYSNAME(xdEntityStp, A_XdEntity_SqlName)) + ")";
                ret = RET_DBA_ERR_MD;
                this->printMsg(ret, msg);
            }

            if (GET_FLAG(currXdAttribStp, A_XdAttrib_ShortOnlyFlg) == TRUE &&
                GET_FLAG(currXdAttribStp, A_XdAttrib_BusKeyFlg) == TRUE)
            {
                string msg = "A business key attribute cannot be only on the short structure (attribute:";
                msg += string(GET_SYSNAME(xdEntityStp, A_XdEntity_SqlName)) + "." + string(GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName)) + ")";
                ret = RET_DBA_ERR_MD;
                this->printMsg(ret, msg);
            }

            if (GET_FLAG(currXdAttribStp, A_XdAttrib_ShortOnlyFlg) == TRUE &&
                IS_NULLFLD(currXdAttribStp, A_XdAttrib_ShortIdx) == TRUE)
            {
                string msg = "A short structure only attribute (short_only_f=1) must have a short index (attribute: ";
                msg += string(GET_SYSNAME(xdEntityStp, A_XdEntity_SqlName)) + "." + string(GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName)) + ")";
                ret = RET_DBA_ERR_MD;
                this->printMsg(ret, msg);
            }

            if (IS_NOTNULL(currXdAttribStp, A_XdAttrib_SortRank) &&
                GET_ENUM(xdEntityStp, A_XdEntity_NatEn) != EntityNat_Internal &&
                GET_ENUM(xdEntityStp, A_XdEntity_NatEn) != EntityNat_PersistedFmt &&
                GET_ENUM(xdEntityStp, A_XdEntity_NatEn) != EntityNat_SearchFmt &&
                GET_ENUM(xdEntityStp, A_XdEntity_NatEn) != EntityNat_ReportFmt)
            {
                if (GET_TINYINT(currXdAttribStp, A_XdAttrib_SortRank) == 0)
                {
                    string msg = "The sorting rank must be null or greater than 0 (attribute: ";
                    msg += string(GET_SYSNAME(xdEntityStp, A_XdEntity_SqlName)) + "." + string(GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName)) + ")";
                    ret = RET_DBA_ERR_MD;
                    this->printMsg(ret, msg);
                }

                if (sortingRankCheckMap.insert(make_pair(GET_TINYINT(currXdAttribStp, A_XdAttrib_SortRank), currXdAttribStp)).second == false)
                {
                    ret = RET_DBA_ERR_MD;
                    this->printMsg(ret, SYS_Stringer("Duplicate sorting rank value for attribute ",
                                                     GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName),
                                                     " and ",
                                                     GET_SYSNAME(sortingRankCheckMap[GET_TINYINT(currXdAttribStp, A_XdAttrib_SortRank)], A_XdAttrib_SqlName)));
                }
            }

            /* PMSTA-26252 - LJE - 170216 */
            if (IS_NOTNULL(currXdAttribStp, A_XdAttrib_ParentXdAttribId) &&
                IS_NOTNULL(currXdAttribStp, A_XdAttrib_Join1XdAttribId) &&
                IS_NULLFLD(currXdAttribStp, A_XdAttrib_PhysicalXdAttribId))
            {
                this->copyDynFld(currXdAttribStp, A_XdAttrib_PhysicalXdAttribId,
                                 currXdAttribStp, A_XdAttrib_ParentXdAttribId);
            }

            /* PMSTA-14452 - LJE - 130130 */
            if (RET_GET_LEVEL(ret) != RET_LEV_ERROR &&
                GET_FLAG(currXdAttribStp, A_XdAttrib_ShortOnlyFlg) == TRUE)
            {
                SET_NULL_DICT(currXdAttribStp, A_XdAttrib_AttribDictId);

                if (IS_NULLFLD(currXdAttribStp, A_XdAttrib_Join1XdAttribId) == FALSE)
                {
                    SET_ENUM(currXdAttribStp, A_XdAttrib_CalcEn, DictAttr_Denorm);
                }
                else if (GET_SMALLINT(currXdAttribStp, A_XdAttrib_ShortDispRank) >= 0)
                {
                    SET_ENUM(currXdAttribStp, A_XdAttrib_CalcEn, DictAttr_Calculated);
                }
                else
                {
                    SET_ENUM(currXdAttribStp, A_XdAttrib_CalcEn, DictAttr_Virtual);
                }
            }

            if (xdPermValAttribMapPtr != nullptr && xdPermValAttribMapPtr->empty() == false)
            {
                map<SMALLINT_T, DBA_DYNFLD_STP> xdPermValByRankMap;
                map<std::string, DBA_DYNFLD_STP> permValNameCheckMap;

                for (auto& permValIt : *xdPermValAttribMapPtr)
                {
                    if (GET_ENUM(permValIt.second, A_XdPermVal_XdActionEn) == XdAction_ToInsert ||
                        (GET_ENUM(permValIt.second, A_XdPermVal_XdStatusEn) == XdStatus_Inserted &&
                         GET_ENUM(permValIt.second, A_XdPermVal_XdActionEn) == XdAction_None))
                    {
                        auto findIt = xdPermValByRankMap.find(GET_SMALLINT(permValIt.second, A_XdPermVal_Rank));

                        if (findIt == xdPermValByRankMap.end())
                        {
                            xdPermValByRankMap.insert(make_pair(GET_SMALLINT(permValIt.second, A_XdPermVal_Rank), permValIt.second));
                        }
                        else
                        {
                            string msg = SYS_Stringer("Duplicate rank value for permitted values '",
                                                      GET_NAME(permValIt.second, A_XdPermVal_Name), "' and '",
                                                      GET_NAME(findIt->second, A_XdPermVal_Name), "' of attribute '",
                                                      GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName), "'");
                            ret = RET_DBA_ERR_MD;
                            this->printMsg(ret, msg);
                        }

                        if (permValNameCheckMap.insert(make_pair(GET_NAME(permValIt.second, A_XdPermVal_Name), permValIt.second)).second == false)
                        {
                            string msg = "Duplicate permitted value for attribute ";
                            msg += string(GET_SYSNAME(xdEntityStp, A_XdEntity_SqlName)) + "." + string(GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName));
                            msg += " (must be in permitted values)";
                            this->printMsg(RET_DBA_ERR_MD_INVALID_VALUE, SYS_Stringer("Duplicate permitted value for attribute '",
                                                                                      GET_SYSNAME(xdEntityStp, A_XdEntity_SqlName),
                                                                                      ".",
                                                                                      GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName),
                                                                                      "' having name '",
                                                                                      GET_NAME(permValIt.second, A_XdPermVal_Name),
                                                                                      "' on perm_val_nat_e ",
                                                                                      static_cast<int>(GET_ENUM(permValIt.second, A_XdPermVal_PermValNatEn)),
                                                                                      " and ",
                                                                                      static_cast<int>(GET_ENUM(permValNameCheckMap[GET_NAME(permValIt.second, A_XdPermVal_Name)], A_XdPermVal_PermValNatEn))));
                            ret = RET_DBA_ERR_MD;
                        }
                    }
                }

                if (GET_ENUM(currXdAttribStp, A_XdAttrib_CustomFlg) != Custom_No)
                {
                    bool bNoValid = true;
                    for (auto& permValIt : *xdPermValAttribMapPtr)
                    {
                        if (GET_ENUM(permValIt.second, A_XdPermVal_XdStatusEn) == XdStatus_Inserted ||
                            GET_ENUM(permValIt.second, A_XdPermVal_XdActionEn) == XdAction_ToInsert)
                        {
                            bNoValid = false;
                        }
                    }

                    if (bNoValid)
                    {
                        for (auto& permValIt : *xdPermValAttribMapPtr)
                        {
                            SET_ENUM(permValIt.second, A_XdPermVal_XdActionEn, XdAction_ToInsert);
                        }
                    }
                }
            }

            /* PMSTA-24238 - LJE - 160819 - Check ref_delete_rule_e value */
            if ((REF_DELETE_RULE_ENUM)GET_ENUM(currXdAttribStp, A_XdAttrib_RefDeleteRuleEn) != RefDelRule_None)
            {
                if (GET_FLAG(currXdAttribStp, A_XdAttrib_DbMandatoryFlg) == TRUE &&
                    (REF_DELETE_RULE_ENUM)GET_ENUM(currXdAttribStp, A_XdAttrib_RefDeleteRuleEn) == RefDelRule_SetNULL)
                {
                    string msg = SYS_Stringer("A mandatory attribute cannot have a ref_delete_rule = 'set to NULL' (attribute:",
                                              GET_SYSNAME(xdEntityStp, A_XdEntity_SqlName), ".", GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName), ")");
                    ret = RET_DBA_ERR_MD;
                    this->printMsg(ret, msg);
                }
            }

            if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
            {
                this->setAttribStatus(requestHelper, currXdAttribStp, nullptr, XdStatus_Failed);
                gblRet = ret;
            }
            else if (GET_ENUM(xdEntityStp, A_XdEntity_XdActionEn) == XdAction_ToRefresh)
            {
                if (xdPermValAttribMapPtr != nullptr && xdPermValAttribMapPtr->empty() == false)
                {
                    for (auto& permValIt : *xdPermValAttribMapPtr)
                    {
                        if (GET_ENUM(permValIt.second, A_XdPermVal_XdStatusEn) == XdStatus_Inserted ||
                            GET_ENUM(permValIt.second, A_XdPermVal_XdStatusEn) == XdStatus_Deprecated ||
                            GET_ENUM(permValIt.second, A_XdPermVal_XdStatusEn) == XdStatus_Failed)
                        {
                            SET_ENUM(permValIt.second, A_XdPermVal_XdActionEn, XdAction_ToInsert);
                        }
                    }
                }
            }
            else
            {
                if (xdPermValAttribMapPtr != nullptr && xdPermValAttribMapPtr->empty() == false)
                {
                    for (auto& permValIt : *xdPermValAttribMapPtr)
                    {
                        if (GET_ENUM(permValIt.second, A_XdPermVal_XdStatusEn) == XdStatus_Inserted &&
                            GET_ENUM(permValIt.second, A_XdPermVal_XdActionEn) == XdAction_None)
                        {
                            SET_ENUM(permValIt.second, A_XdPermVal_XdActionEn, XdAction_ToInsert);
                        }
                        else if (GET_ENUM(permValIt.second, A_XdPermVal_XdActionEn) != XdAction_ToInsert &&
                                 GET_ENUM(permValIt.second, A_XdPermVal_XdStatusEn) != XdStatus_Deleted &&
                                 GET_ENUM(permValIt.second, A_XdPermVal_XdStatusEn) != XdStatus_PhysicallyDeleted)
                        {
                            SET_ENUM(permValIt.second, A_XdPermVal_XdActionEn, XdAction_ToDelete);
                        }
                    }
                }
            }

            /* PMSTA-26108 - LJE - 170904 */
            if ((ME_SPECIALISATION_ENUM)GET_ENUM(currXdAttribStp, A_XdAttrib_MeSpecialisationEn) == MeSpecialisation_Key)
            {
                bMeSpecKeyDefined = true;
            }
            else if ((ME_SPECIALISATION_ENUM)GET_ENUM(currXdAttribStp, A_XdAttrib_MeSpecialisationEn) == MeSpecialisation_Applied)
            {
                bMeSpecLocalDefined = true;
            }

            if (this->bVerticalSearchToDo == false && GET_FLAG(currXdAttribStp, A_XdAttrib_VerticalSearchFlg) == TRUE)
            {
                this->bVerticalSearchToDo = true;
            }
            if (this->bVerticalPatternToDo == false && GET_FLAG(currXdAttribStp, A_XdAttrib_VerticalPatternFlg) == TRUE)
            {
                this->bVerticalPatternToDo = true;
            }

            /*  Memorize that there one attribute with obj_modif_stat equals to AUtomatic tracking  */  /*  HFI-PMSTA-50016-2023-01-27  */
            if (LastModif_TrackingAuto == (LAST_MODIF_ENUM)GET_ENUM(currXdAttribStp, A_XdAttrib_ObjModifStatEn))
            {
                enObjModifStat = LastModif_TrackingAuto;
            }
        }

        if (RET_GET_LEVEL(gblRet) != RET_LEV_ERROR &&
            (ret = this->ddlGenEntityPtr->removeDeletedAttributes()) != RET_SUCCEED)
        {
            gblRet = ret;
        }

        if (this->ddlGenEntityPtr->getXdAttribNbr() == 1 &&
            (GET_ENUM(xdEntityStp, A_XdEntity_NatEn) == EntityNat_PersistedFmt ||
             GET_ENUM(xdEntityStp, A_XdEntity_NatEn) == EntityNat_SearchFmt ||
             GET_ENUM(xdEntityStp, A_XdEntity_NatEn) == EntityNat_ReportFmt))
        {
            SET_ENUM(xdEntityStp, A_XdEntity_XdActionEn, XdAction_ToDelete);
        }

        if (RET_GET_LEVEL(gblRet) != RET_LEV_ERROR &&
            (ret = this->computeProgN()) != RET_SUCCEED)
        {
            gblRet = ret;
        }

        if (RET_GET_LEVEL(gblRet) != RET_LEV_ERROR &&
            GET_ENUM(xdEntityStp, A_XdEntity_PkRuleEn) == PkRule_Identity)
        {
            bool checkIdentity = progPkNMap.size() == 1;

            for (i = 0; checkIdentity && i < this->ddlGenEntityPtr->getXdAttribNbr(); i++)
            {
                DBA_DYNFLD_STP currXdAttribStp = this->ddlGenEntityPtr->getXdAttrib(i);

                if (GET_FLAG(currXdAttribStp, A_XdAttrib_PrimaryFlg) == TRUE &&
                    DATATYPE_DICT_TO_ENUM(GET_DICT(currXdAttribStp, A_XdAttrib_DataTpDictId)) != IntType &&
                    DATATYPE_DICT_TO_ENUM(GET_DICT(currXdAttribStp, A_XdAttrib_DataTpDictId)) != IdType &&
                    DATATYPE_DICT_TO_ENUM(GET_DICT(currXdAttribStp, A_XdAttrib_DataTpDictId)) != DictType)
                {
                    checkIdentity = false;
                }
            }

            if (checkIdentity == false)
            {
                gblRet = RET_DBA_ERR_MD;
                this->printMsg(gblRet, "Invalid identity flag");
            }
        }

        if (RET_GET_LEVEL(gblRet) != RET_LEV_ERROR &&
            progBkNMap.size() == 0 &&
            GET_FLAG(xdEntityStp, A_XdEntity_LogicalFlg) == FALSE &&
            (this->entNatureEn == EntityNat_Custom || this->entNatureEn == EntityNat_CustomDS || this->entNatureEn == EntityNat_ModelBank)) /* ORACLE - LJE - 141015 */ /* PMSTA-27352 - LJE - 170606 */
        {
            ret = RET_DBA_ERR_MD;
            this->printMsg(ret, "Business key missing");
        }

        /*  Adapt the value of entity obj modif stat based on the attribute value   */  /*  HFI-PMSTA-50016-2023-01-27  */
        if ((enObjModifStat != static_cast<LAST_MODIF_ENUM>(GET_ENUM(xdEntityStp, A_XdEntity_ObjModifStatEn))) &&
            (LastModif_TrackingManual != static_cast<LAST_MODIF_ENUM>(GET_ENUM(xdEntityStp, A_XdEntity_ObjModifStatEn))))
        {
            SET_ENUM(xdEntityStp, A_XdEntity_ObjModifStatEn, enObjModifStat);
            if (enObjModifStat == LastModif_NoTracking)
            {
                this->printMsg(RET_SUCCEED, "Obj Modif Stat updated to No Tracking");
            }
            else
            {
                this->printMsg(RET_SUCCEED, "Obj Modif Stat updated to Automatic Tracking");
            }
        }

        /* PMSTA-26108 - LJE - 170904 */
        if (GET_ENUM(xdEntityStp, A_XdEntity_MultiEntityCategoryEn) == MultiEntityCategory_OptionalSpecialisation &&
            (bMeSpecKeyDefined == false || bMeSpecLocalDefined == false))
        {
            for (i = 0; i < this->ddlGenEntityPtr->getXdAttribNbr(); i++)
            {
                DBA_DYNFLD_STP currXdAttribStp = this->ddlGenEntityPtr->getXdAttrib(i);

                if (bMeSpecKeyDefined == false &&
                    GET_FLAG(currXdAttribStp, A_XdAttrib_BusKeyFlg) == TRUE)
                {
                    SET_ENUM(currXdAttribStp, A_XdAttrib_MeSpecialisationEn, MeSpecialisation_Key);
                }
            }
        }

        this->bCheckAndFixDone = true; /* PMSTA-26108 - LJE - 171007 */
        this->m_dictEntityStp = NULL; /* Set to NULL, the dict entity tab can change before the next step... */

        this->ddlGenEntityPtr->freeNoSysRecords();  /* PMSTA-46168 - LJE - 210907 */
    }
    catch (exception& e)
    {
        gblRet = RET_GEN_ERR_PERSONAL;
        this->printCatchMsg(FILEINFO, e.what());
    }

    this->finishConnection(ret);

    return gblRet;
}

/************************************************************************
**
**  Function    :   DdlGenFullTable::insertAllAttrib()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13109 - LJE - 110311
**
*************************************************************************/
RET_CODE DdlGenFullTable::insertAllAttrib(DdlGenRequestHelper& requestHelper)
{
    RET_CODE               ret = RET_SUCCEED;
    MemoryPool             mp;

    if (this->ddlGenEntityPtr->getXdAttribNbr() == 0)
    {
        return ret;
    }

    map<string, DBA_DYNFLD_STP> attribToDeleteMap;

    for (auto it = this->ddlGenEntityPtr->getDbXdAttribMap().begin(); it != this->ddlGenEntityPtr->getDbXdAttribMap().end(); ++it)
    {
        attribToDeleteMap.insert(make_pair(it->first, it->second));
    }

    DdlGenConnGuard      ddlGenConnGuard(*this->ddlGenContextPtr);
    DdlGenDbaAccessGuard ddlGenDbaAccessGuard(*this->ddlGenContextPtr);

    auto shDictAttribStp = requestHelper.allocDynSt(FILEINFO, S_DictAttr);

    for (int i = 0; i < this->ddlGenEntityPtr->getXdAttribNbr(); i++)
    {
        DICT_ATTRIB_STP attribStp      = nullptr;
        DBA_DYNFLD_STP currXdAttribStp = this->ddlGenEntityPtr->getXdAttrib(i);

        attribToDeleteMap.erase(GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName));

        COPY_DYNFLD(shDictAttribStp, S_DictAttr, S_DictAttr_DictId, currXdAttribStp, A_XdAttrib, A_XdAttrib_AttribDictId);
        COPY_DYNFLD(shDictAttribStp, S_DictAttr, S_DictAttr_SqlName, currXdAttribStp, A_XdAttrib, A_XdAttrib_SqlName);
        SET_DICT(shDictAttribStp, S_DictAttr_EntityDictId, this->m_dictEntityStp->entDictId);
        auto existsDictAttribStp = ddlGenDbaAccessGuard.getDdlGenDbaAccess().getRecord(DictAttr, shDictAttribStp, false, false);

        if (GET_FLAG(currXdAttribStp, A_XdAttrib_ShortOnlyFlg) == FALSE &&
            IS_NULLFLD(currXdAttribStp, A_XdAttrib_Prog) == FALSE &&
            GET_ENUM(currXdAttribStp, A_XdAttrib_XdActionEn) == XdAction_ToInsert &&
            /* Treat precomputed attributes only if there are already inserted in database */
            (GET_FLAG(currXdAttribStp, A_XdAttrib_PrecompFlg) == FALSE || IS_NULLFLD(currXdAttribStp, A_XdAttrib_AttribDictId) == FALSE || this->bExtTableToDo) &&
            (attribStp = this->m_dictEntityStp->attr[GET_INT(currXdAttribStp, A_XdAttrib_Prog)]) != NULL)
        {
            attribStp->xdStatusEn = (XD_STATUS_ENUM)GET_ENUM(currXdAttribStp, A_XdAttrib_XdStatusEn);

            DBA_DYNFLD_STP currDictAttribStp = (existsDictAttribStp == nullptr ? requestHelper.allocDynSt(FILEINFO, A_DictAttr) : existsDictAttribStp);

            DBA_SetDfltEntityFld(DictAttr, A_DictAttr, currDictAttribStp);
            DBA_ConvertDynSt(currDictAttribStp, currXdAttribStp, true);
            SET_DICT(currDictAttribStp, A_DictAttr_EntityDictId, this->m_dictEntityStp->entDictId);

            SET_FLAG(currDictAttribStp, A_DictAttr_CustomFlg, attribStp->custFlg);

            SET_ENUM(currDictAttribStp, A_DictAttr_RefCheckRuleEn, attribStp->refCheckRuleEn); /* PMSTA-22868 - LJE - 160404 */

            SET_ENUM(currDictAttribStp, A_DictAttr_OutboxPublishEn, attribStp->outboxPublishEn);   /* PMSTA-45305 -Lalby- 210528 */

            if (GET_ENUM(currXdAttribStp, A_XdAttrib_XdActionEn) == XdAction_ToDelete)
            {
                SET_ENUM(currDictAttribStp, A_DictAttr_XdStatusEn, XdStatus_Deleted);
                attribStp->xdStatusEn = XdStatus_Deleted;
            }
            else if (GET_ENUM(currXdAttribStp, A_XdAttrib_XdActionEn) == XdAction_ToPhysicallyDelete)
            {
                SET_ENUM(currDictAttribStp, A_DictAttr_XdStatusEn, XdStatus_PhysicallyDeleted);
                attribStp->xdStatusEn = XdStatus_PhysicallyDeleted;
            }
            else if (GET_ENUM(currXdAttribStp, A_XdAttrib_XdActionEn) == XdAction_ToInsert &&
                     attribStp->xdStatusEn != XdStatus_Inserted)
            {
                SET_ENUM(currXdAttribStp, A_XdAttrib_XdStatusEn, XdStatus_Untreated);
                SET_ENUM(currDictAttribStp, A_DictAttr_XdStatusEn, XdStatus_Untreated);
                attribStp->xdStatusEn = XdStatus_Untreated;
            }

            if (attribStp->xdStatusEn == XdStatus_Deleted)
            {
                attribStp->calcEn = DictAttr_Virtual;
                SET_ENUM(currXdAttribStp, A_XdAttrib_CalcEn, attribStp->calcEn);
                SET_ENUM(currDictAttribStp, A_DictAttr_CalcEn, attribStp->calcEn);
            }
            else if (static_cast<DICTATTR_ENUM>(GET_ENUM(currXdAttribStp, A_XdAttrib_CalcEn)) == DictAttr_PhysicalPartition)
            {
                attribStp->calcEn = static_cast<DICTATTR_ENUM>(GET_ENUM(currXdAttribStp, A_XdAttrib_CalcEn));
            }

            if (attribStp->parAttrDictId != 0)
            {
                SET_DICT(currDictAttribStp, A_DictAttr_ParentAttribDictId, attribStp->parAttrDictId);
            }
            else
            {
                SET_NULL_DICT(currDictAttribStp, A_DictAttr_ParentAttribDictId);
            }

            if (attribStp->linkedAttrDictId != 0)
            {
                SET_DICT(currDictAttribStp, A_DictAttr_LinkedAttribDictId, attribStp->linkedAttrDictId);
            }
            else
            {
                SET_NULL_DICT(currDictAttribStp, A_DictAttr_LinkedAttribDictId);
            }

            if (attribStp->refEntDictId != 0)
            {
                SET_DICT(currDictAttribStp, A_DictAttr_RefEntityDictId, attribStp->refEntDictId);
                SET_DICT(currDictAttribStp, A_DictAttr_RefEntityAttribDictId, attribStp->refEntDictId);
            }
            else
            {
                SET_NULL_DICT(currDictAttribStp, A_DictAttr_RefEntityDictId);
                SET_NULL_DICT(currDictAttribStp, A_DictAttr_RefEntityAttribDictId);
            }

            if (attribStp->isNullShortIdx == false)
            {
                SET_SMALLINT(currDictAttribStp, A_DictAttr_ShortIdx, (SMALLINT_T)attribStp->shortIdx);
            }
            else
            {
                SET_NULL_SMALLINT(currDictAttribStp, A_DictAttr_ShortIdx);
            }

            SET_DICT(currDictAttribStp, A_DictAttr_DictId, attribStp->attrDictId);
            SET_DICT(currXdAttribStp, A_XdAttrib_AttribDictId, attribStp->attrDictId);

            SET_INT(currDictAttribStp, A_DictAttr_Prog, attribStp->progN);
            SET_INT(currXdAttribStp, A_XdAttrib_Prog, attribStp->progN);

            /* PMSTA-26108 - LJE - 171127 */
            if (GET_A_XdAttrib_FeatureEn(currXdAttribStp) == XdEntityFeatureFeatureEn::MultiBusinessEntityManagement &&
                this->m_dictEntityStp->ownerBusinessEntAttrStp == attribStp)
            {
                if (this->ddlGenEntityPtr->bMultiEntityOnCustom)
                {
                    SET_FLAG(currXdAttribStp, A_XdAttrib_CustomFlg, TRUE);
                    SET_FLAG(currDictAttribStp, A_DictAttr_CustomFlg, TRUE);
                }
                if (this->ddlGenEntityPtr->bMultiEntityOnPrecomp)
                {
                    SET_FLAG(currXdAttribStp, A_XdAttrib_PrecompFlg, TRUE);
                    SET_FLAG(currDictAttribStp, A_DictAttr_PrecompFlg, TRUE);
                }
            }

            DBA_ACTION_ENUM actionDone = NullAction;
            requestHelper.insUpdRecord(currDictAttribStp, actionDone, nullptr, true);
            requestHelper.insUpdRecord(currXdAttribStp, actionDone);

            this->aDictAttribMap[GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName)] = currDictAttribStp;

            attribStp->virtualAttrFlg = FALSE;
        }
        else if (GET_ENUM(currXdAttribStp, A_XdAttrib_XdActionEn) == XdAction_ToDelete ||
                 GET_ENUM(currXdAttribStp, A_XdAttrib_XdActionEn) == XdAction_ToPhysicallyDelete)
        {
            SET_NULL_DYNST(shDictAttribStp, S_DictAttr);
            SET_DICT(shDictAttribStp, S_DictAttr_EntityDictId, this->m_dictEntityStp->entDictId);
            this->copyDynFld(shDictAttribStp, S_DictAttr_SqlName,
                             currXdAttribStp, A_XdAttrib_SqlName);

            if (GET_ENUM(currXdAttribStp, A_XdAttrib_XdActionEn) == XdAction_ToPhysicallyDelete)
            {
                SET_ENUM(currXdAttribStp, A_XdAttrib_XdStatusEn, XdStatus_PhysicallyDeleted);
            }
            else
            {
                SET_ENUM(currXdAttribStp, A_XdAttrib_XdStatusEn, XdStatus_Deleted);
            }

            DBA_DYNFLD_STP allDictAttribStp = (existsDictAttribStp == nullptr ? requestHelper.allocDynSt(FILEINFO, A_DictAttr) : existsDictAttribStp);

            if (requestHelper.dbaGet(DictAttr, UNUSED, shDictAttribStp, allDictAttribStp) == RET_SUCCEED)
            {
                if (GET_ENUM(currXdAttribStp, A_XdAttrib_XdActionEn) == XdAction_ToPhysicallyDelete)
                {
                    SET_ENUM(allDictAttribStp, A_DictAttr_XdStatusEn, XdStatus_PhysicallyDeleted);
                }
                else
                {
                    SET_ENUM(allDictAttribStp, A_DictAttr_XdStatusEn, XdStatus_Deleted);
                }

                requestHelper.dbaCall(Delete,
                                      DictAttr,
                                      UNUSED,
                                      allDictAttribStp);
            }

            /* PMSTA-36919 - LJE - 191001 */
            if (GET_ENUM(currXdAttribStp, A_XdAttrib_XdActionEn) == XdAction_ToPhysicallyDelete)
            {
                this->ddlGenEntityPtr->xdAttribToPhysicalDeleteSet.insert(currXdAttribStp);
            }

            this->setAttribStatus(requestHelper, currXdAttribStp, allDictAttribStp, (XD_STATUS_ENUM)GET_ENUM(currXdAttribStp, A_XdAttrib_XdStatusEn));
        }
        else if (GET_FLAG(currXdAttribStp, A_XdAttrib_ShortOnlyFlg) == TRUE &&
                 GET_ENUM(currXdAttribStp, A_XdAttrib_XdActionEn) == XdAction_ToInsert)
        {
            DBA_ACTION_ENUM actionDone = NullAction;
            requestHelper.insUpdRecord(currXdAttribStp, actionDone);
        }
    }

    for (auto it = attribToDeleteMap.begin(); it != attribToDeleteMap.end(); ++it)
    {
        DBA_DYNFLD_STP currXdAttribStp = it->second;

        SET_NULL_DYNST(shDictAttribStp, S_DictAttr);
        SET_DICT(shDictAttribStp, S_DictAttr_EntityDictId, this->m_dictEntityStp->entDictId);
        this->copyDynFld(shDictAttribStp, S_DictAttr_SqlName,
                         currXdAttribStp, A_XdAttrib_SqlName);

        if (GET_ENUM(currXdAttribStp, A_XdAttrib_XdActionEn) == XdAction_ToPhysicallyDelete)
        {
            SET_ENUM(currXdAttribStp, A_XdAttrib_XdStatusEn, XdStatus_PhysicallyDeleted);
        }
        else
        {
            SET_ENUM(currXdAttribStp, A_XdAttrib_XdStatusEn, XdStatus_Deleted);
        }

        DBA_DYNFLD_STP      allDictAttribStp = requestHelper.allocDynSt(FILEINFO, A_DictAttr);

        if (requestHelper.dbaGet(DictAttr, UNUSED, shDictAttribStp, allDictAttribStp) == RET_SUCCEED)
        {
            if (GET_ENUM(currXdAttribStp, A_XdAttrib_XdActionEn) == XdAction_ToPhysicallyDelete)
            {
                SET_ENUM(allDictAttribStp, A_DictAttr_XdStatusEn, XdStatus_PhysicallyDeleted);
            }
            else
            {
                SET_ENUM(allDictAttribStp, A_DictAttr_XdStatusEn, XdStatus_Deleted);
            }

            requestHelper.dbaCall(Delete,
                                  DictAttr,
                                  UNUSED,
                                  allDictAttribStp);
        }

        /* PMSTA-36919 - LJE - 191001 */
        if (GET_ENUM(currXdAttribStp, A_XdAttrib_XdActionEn) == XdAction_ToPhysicallyDelete)
        {
            this->ddlGenEntityPtr->xdAttribToPhysicalDeleteSet.insert(currXdAttribStp);
        }

        this->setAttribStatus(requestHelper, currXdAttribStp, allDictAttribStp, (XD_STATUS_ENUM)GET_ENUM(currXdAttribStp, A_XdAttrib_XdStatusEn));
    }

    this->ddlGenEntityPtr->removeDeletedAttributes();

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenFullTable::insertAllPartition()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-24007 - LJE - 170717
**
*************************************************************************/
RET_CODE DdlGenFullTable::insertAllPartition(DdlGenRequestHelper& requestHelper)
{
    RET_CODE               ret = RET_SUCCEED;
    int                    i;

    int                    partitionNbr = this->ddlGenEntityPtr->getXdPartitionNbr();
    DBA_DYNFLD_STP* partitionTab = this->ddlGenEntityPtr->getXdPartitionTab();

    for (i = 0; i < partitionNbr; i++)
    {
        if (GET_ENUM(partitionTab[i], A_XdPartition_XdActionEn) == XdAction_ToInsert)
        {
            DBA_ACTION_ENUM actionDone = NullAction;
            requestHelper.insUpdRecord(partitionTab[i], actionDone);
        }
    }

    int                    partitionIndexNbr = this->ddlGenEntityPtr->getXdPartitionIndexNbr();
    DBA_DYNFLD_STP* partitionIndexTab = this->ddlGenEntityPtr->getXdPartitionIndexTab();

    for (i = 0; i < partitionIndexNbr; i++)
    {
        if (GET_ENUM(partitionIndexTab[i], A_XdPartitionIndex_XdActionEn) == XdAction_ToInsert)
        {
            DBA_ACTION_ENUM actionDone = NullAction;
            requestHelper.insUpdRecord(partitionIndexTab[i], actionDone);
        }
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenFullTable::setStatusToAllAttrib()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13109 - LJE - 110311
**
*************************************************************************/
RET_CODE DdlGenFullTable::setStatusToAllAttrib(DdlGenRequestHelper& requestHelper, XD_STATUS_ENUM xdStatusEn)
{
    RET_CODE               ret = RET_SUCCEED;

    for (int i = 0; i < this->ddlGenEntityPtr->getXdAttribNbr(); i++)
    {
        DBA_DYNFLD_STP currXdAttribStp = this->ddlGenEntityPtr->getXdAttrib(i);

        if (GET_ENUM(currXdAttribStp, A_XdAttrib_XdActionEn) != XdAction_None)
        {
            SET_ENUM(currXdAttribStp, A_XdAttrib_XdStatusEn, xdStatusEn);

            if (xdStatusEn == XdStatus_Inserted)
            {
                if (GET_ENUM(currXdAttribStp, A_XdAttrib_XdActionEn) == XdAction_ToDelete ||
                    GET_ENUM(currXdAttribStp, A_XdAttrib_XdActionEn) == XdAction_ToDeprecate)
                {
                    SET_ENUM(currXdAttribStp, A_XdAttrib_XdStatusEn, XdStatus_Deleted);
                }
                else if (GET_ENUM(currXdAttribStp, A_XdAttrib_XdActionEn) == XdAction_ToPhysicallyDelete)
                {
                    SET_ENUM(currXdAttribStp, A_XdAttrib_XdStatusEn, XdStatus_PhysicallyDeleted);
                }
            }

            if (GET_FLAG(currXdAttribStp, A_XdAttrib_ShortOnlyFlg) == FALSE &&
                GET_ENUM(currXdAttribStp, A_XdAttrib_XdActionEn) != XdAction_ToPhysicallyDelete &&
                IS_NULLFLD(currXdAttribStp, A_XdAttrib_AttribDictId) == FALSE)
            {
                DBA_DYNFLD_STP aDictAttribStp = this->aDictAttribMap[GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName)];

                if (aDictAttribStp != nullptr)
                {
                    SET_DICT(aDictAttribStp, A_DictAttr_DictId, GET_DICT(currXdAttribStp, A_XdAttrib_AttribDictId));
                    this->copyDynFld(aDictAttribStp, A_DictAttr_XdStatusEn,
                                     currXdAttribStp, A_XdAttrib_XdStatusEn);

                    requestHelper.dbaCall(Update,
                                          DictAttr,
                                          DBA_ROLE_STATUS,
                                          aDictAttribStp);
                }
            }

            SET_ENUM(currXdAttribStp, A_XdAttrib_XdActionEn, XdAction_None);
            SET_DATETIME(currXdAttribStp, A_XdAttrib_BuildDate, this->ddlGenContextPtr->getBuildDate());

            requestHelper.dbaCall(Update,
                                  XdAttrib,
                                  DBA_ROLE_STATUS,
                                  currXdAttribStp);
        }
    }

    for (auto &xdAttribCustoMap : this->ddlGenEntityPtr->m_xdAttribCustoMap)
    {
        for (auto &xdAttribCustoStp : xdAttribCustoMap.second)
        {
            SET_ENUM(xdAttribCustoStp, A_XdAttributeCusto_XdStatusEn, xdStatusEn);
            SET_ENUM(xdAttribCustoStp, A_XdAttributeCusto_XdActionEn, XdAction_None);

            requestHelper.dbaCall(Update,
                                  XdAttributeCusto,
                                  DBA_ROLE_STATUS,
                                  xdAttribCustoStp);
        }
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenFullTable::addAttributesFromFeature()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-23385 - LJE - 160707
**
*************************************************************************/
RET_CODE DdlGenFullTable::addAttributesFromFeature(DdlGenRequestHelper& requestHelper, DBA_DYNFLD_STP featureStp)
{
    RET_CODE        ret = RET_SUCCEED;
    DdlGenEntity* tplDdlGenEntity = this->ddlGenContextPtr->getTemplateDdlGenEntityPtr();
    DBA_DYNFLD_STP xdEntityStp = this->getXdEntityStp();

    if ((XD_ACTION_ENUM)GET_ENUM(featureStp, A_XdEntityFeature_XdActionEn) != XdAction_None)
    {
        if ((XD_ACTION_ENUM)GET_ENUM(featureStp, A_XdEntityFeature_XdActionEn) == XdAction_ToInsert)
        {
            SET_ENUM(featureStp, A_XdEntityFeature_XdStatusEn, XdStatus_Untreated);

            if (((FEATURE_AUTH_ENUM)GET_ENUM(featureStp, A_XdEntityFeature_AuthEn) == FeatureAuth_Enable ||
                 (GEN_RULE_ENUM)GET_ENUM(featureStp, A_XdEntityFeature_GenRuleEn) == GenRule_AlwaysButVirtual ||
                 (GEN_RULE_ENUM)GET_ENUM(featureStp, A_XdEntityFeature_GenRuleEn) == GenRule_AlwaysButCalculated ||
                 (GEN_RULE_ENUM)GET_ENUM(featureStp, A_XdEntityFeature_GenRuleEn) == GenRule_Always ||
                 (GEN_RULE_ENUM)GET_ENUM(featureStp, A_XdEntityFeature_GenRuleEn) == GenRule_AlwaysNotMandatory) &&
                tplDdlGenEntity != nullptr)
            {
                int             tplXdAttribPos, insertedAttribNbr = 0;
                XdEntityFeatureFeatureEn    feature = GET_A_XdEntityFeature_FeatureEn(featureStp);
                DICTATTR_ENUM   forcedCalcEn = DictAttr_NoMD;

                int             tplXdAttribNbr = tplDdlGenEntity->getXdAttribNbr();

                if ((GEN_RULE_ENUM)GET_ENUM(featureStp, A_XdEntityFeature_GenRuleEn) == GenRule_Virtual)
                {
                    forcedCalcEn = DictAttr_Virtual;
                }
                else if ((GEN_RULE_ENUM)GET_ENUM(featureStp, A_XdEntityFeature_GenRuleEn) == GenRule_Calculated)
                {
                    forcedCalcEn = DictAttr_Calculated;
                }
                else if ((GEN_RULE_ENUM)GET_ENUM(featureStp, A_XdEntityFeature_GenRuleEn) == GenRule_Denorm)
                {
                    forcedCalcEn = DictAttr_Denorm;
                }

                if ((FEATURE_AUTH_ENUM)GET_ENUM(featureStp, A_XdEntityFeature_AuthEn) != FeatureAuth_Enable)
                {
                    if ((GEN_RULE_ENUM)GET_ENUM(featureStp, A_XdEntityFeature_GenRuleEn) == GenRule_AlwaysButVirtual)
                    {
                        forcedCalcEn = DictAttr_Virtual;
                    }
                    else if ((GEN_RULE_ENUM)GET_ENUM(featureStp, A_XdEntityFeature_GenRuleEn) == GenRule_AlwaysButCalculated)
                    {
                        forcedCalcEn = DictAttr_Calculated;
                    }
                    else if ((GEN_RULE_ENUM)GET_ENUM(featureStp, A_XdEntityFeature_GenRuleEn) == GenRule_AlwaysButDenorm)
                    {
                        forcedCalcEn = DictAttr_Denorm;
                    }
                }

                for (tplXdAttribPos = 0; tplXdAttribPos < tplXdAttribNbr; tplXdAttribPos++)
                {
                    DBA_DYNFLD_STP tplXdAttribStp = tplDdlGenEntity->getXdAttrib(tplXdAttribPos);

                    if (GET_A_XdAttrib_FeatureEn(tplXdAttribStp) == feature &&
                        ((XD_STATUS_ENUM)GET_ENUM(tplXdAttribStp, A_XdAttrib_XdStatusEn) == XdStatus_Inserted ||
                         (XD_ACTION_ENUM)GET_ENUM(tplXdAttribStp, A_XdAttrib_XdActionEn) == XdAction_ToInsert) &&
                        /* PMSTA-30346 - LJE - 180301 */
                        ((GET_ENUM(xdEntityStp, A_XdEntity_DictBuildRuleEn) != DictBuildRule_AllDb ||
                          (forcedCalcEn == DictAttr_NoMD &&
                           DictAttribClass::isPhysicalCalcEn((DICTATTR_ENUM)GET_ENUM(tplXdAttribStp, A_XdAttrib_CalcEn)) == TRUE)) &&
                         (GET_ENUM(xdEntityStp, A_XdEntity_DictBuildRuleEn) != DictBuildRule_Sh ||
                          (forcedCalcEn == DictAttr_NoMD && 
                           DictAttribClass::isPhysicalCalcEn((DICTATTR_ENUM)GET_ENUM(tplXdAttribStp, A_XdAttrib_CalcEn)) == TRUE ||
                           feature == XdEntityFeatureFeatureEn::MultiBusinessEntityManagement))))
                    {
                        MemoryPool      mp;
                        string          sqlName = GET_SYSNAME(tplXdAttribStp, A_XdAttrib_SqlName);
                        ID_T            tplAttribId = 0;
                        DICT_T          tplAttribDictId = 0;
                        DBA_DYNFLD_STP  newAttribStp = this->ddlGenEntityPtr->getXdAttribBySqlName(sqlName);
                        bool            bNewAttrib = false;

                        if (newAttribStp == NULL ||
                            GET_ID(newAttribStp, A_XdAttrib_XdEntityId) != GET_ID(this->getXdEntityStp(), A_XdEntity_Id))
                        {
                            bNewAttrib = true;
                            newAttribStp = mp.allocDynst(FILEINFO, A_XdAttrib);
                        }
                        else
                        {
                            tplAttribId = GET_ID(newAttribStp, A_XdAttrib_Id);
                            tplAttribDictId = GET_ID(newAttribStp, A_XdAttrib_AttribDictId);

                            /* PMSTA-26108 - LJE - 171127 */
                            if (GET_A_XdAttrib_FeatureEn(newAttribStp) == XdEntityFeatureFeatureEn::MultiBusinessEntityManagement)
                            {
                                if (GET_FLAG(newAttribStp, A_XdAttrib_CustomFlg) == TRUE && this->ddlGenEntityPtr->isMesiPartitioned()) /* PMSTA-36919 - LJE - 191001 */
                                {
                                    SET_FLAG(newAttribStp, A_XdAttrib_CustomFlg, FALSE);
                                    this->ddlGenEntityPtr->bMultiEntityOnCustom = true;
                                }
                                if (GET_FLAG(newAttribStp, A_XdAttrib_PrecompFlg) == TRUE)
                                {
                                    SET_FLAG(newAttribStp, A_XdAttrib_PrecompFlg, FALSE);
                                    this->ddlGenEntityPtr->bMultiEntityOnPrecomp = true;
                                }
                            }
                        }

                        if (bNewAttrib ||
                            GET_ENUM(newAttribStp, A_XdAttrib_XdActionEn) != XdAction_ToInsert)
                        {
                            /* Automatic attribute */
                            DBA_SetDfltEntityFld(XdAttrib, A_XdAttrib, newAttribStp);
                            DBA_CopyDynStWithSetFld(newAttribStp, tplXdAttribStp);

                            for (int fldPos = 0; fldPos < GET_FLD_NBR(A_XdAttrib); ++fldPos)
                            {
                                SET_SETFLG_T(newAttribStp, fldPos);
                            }
                        }

                        /* PMSTA-46681 - LJE - 230412 */
                        if (feature == XdEntityFeatureFeatureEn::TSLExtensions)
                        {
                            SET_FLAG_TRUE(newAttribStp, A_XdAttrib_PrecompFlg);
                        }
                        /* PMSTA-26108 - LJE - 170728 - Special cases... */
                        else if (feature == XdEntityFeatureFeatureEn::MultiBusinessEntityManagement && insertedAttribNbr == 0)
                        {
                            MultiEntityHelper multiEntityCateg((MULTI_ENTITY_CATEGORY_ENUM)GET_ENUM(xdEntityStp, A_XdEntity_MultiEntityCategoryEn));
                            int             xdAttribNbr = this->ddlGenEntityPtr->getXdAttribNbr();
                            bool              bBkToUpd = true, bPkToUpd = true; /* (multiEntityCateg.isDervidedCategory() == false);  PMSTA-36149 - LJE - 190619 */
                            SMALLINT_T      bkNbr = 0, pkNbr = 0;

                            /* The master business entity id as default value, in all cases to be able to create the attribute "not null" */
                            SET_NAME(newAttribStp, A_XdAttrib_Default, this->ddlGenContextPtr->getMasterBusinessEntityCd().c_str());

                            /* PMSTA-36919 - LJE - 191001 */
                            if ((this->ddlGenContextPtr->getMultiEntityLevel() != MultiEntityLevel_Active || multiEntityCateg.isMultiEntityCateg() == false) &&
                                (IS_NULLFLD(xdEntityStp, A_XdEntity_EntityDictId) ||
                                 this->ddlGenContextPtr->isEntityMtmFirstLevel(GET_DICT(xdEntityStp, A_XdEntity_EntityDictId)) == false) &&
                                (GEN_RULE_ENUM)GET_ENUM(featureStp, A_XdEntityFeature_GenRuleEn) != GenRule_AlwaysNotMandatory &&
                                (GEN_RULE_ENUM)GET_ENUM(featureStp, A_XdEntityFeature_GenRuleEn) != GenRule_Always &&
                                (GEN_RULE_ENUM)GET_ENUM(featureStp, A_XdEntityFeature_GenRuleEn) != GenRule_AlwaysButCalculated &&
                                (GEN_RULE_ENUM)GET_ENUM(featureStp, A_XdEntityFeature_GenRuleEn) != GenRule_AlwaysButDenorm &&
                                (GEN_RULE_ENUM)GET_ENUM(featureStp, A_XdEntityFeature_GenRuleEn) != GenRule_AlwaysButVirtual)
                            {
                                bool bDelete = true;
                                if (GET_ENUM(xdEntityStp, A_XdEntity_DictBuildRuleEn) == DictBuildRule_Sh)
                                {
                                    string        lnkEntitySqlName = this->ddlGenContextPtr->getXdEntitySqlNameById(GET_ID(xdEntityStp, A_XdEntity_LinkedXdEntityId));
                                    DdlGenEntity *lnkDdlGenEntityPtr = this->ddlGenContextPtr->getDdlGenEntityPtr(lnkEntitySqlName);
                                    if (lnkDdlGenEntityPtr != nullptr)
                                    {
                                        bDelete = (this->ddlGenContextPtr->isEntityMtmFirstLevel(GET_ID(lnkDdlGenEntityPtr->getXdEntityStp(), A_XdEntity_EntityDictId)) == false);
                                    }
                                }

                                if (bDelete)
                                {
                                    SET_ENUM(xdEntityStp, A_XdEntity_MultiEntityCategoryEn, MultiEntityCategory_None);
                                    multiEntityCateg.set(MultiEntityCategory_None);
                                    SET_ENUM(newAttribStp, A_XdAttrib_XdActionEn, XdAction_ToPhysicallyDelete);
                                }
                            }

                            if (multiEntityCateg.isUniqueKeyAlered())
                            {
                                for (int i = 0; i < xdAttribNbr && (bBkToUpd || bPkToUpd); i++)
                                {
                                    DBA_DYNFLD_STP xdAttribStp = this->ddlGenEntityPtr->getXdAttrib(i);

                                    if (IS_NULLFLD(xdAttribStp, A_XdAttrib_ProgBk) == false || IS_NULLFLD(xdAttribStp, A_XdAttrib_ProgPk) == false ||
                                        GET_FLAG(xdAttribStp, A_XdAttrib_BusKeyFlg) == TRUE || GET_FLAG(xdAttribStp, A_XdAttrib_PrimaryFlg) == TRUE)
                                    {
                                        if (IS_NULLFLD(xdAttribStp, A_XdAttrib_ProgBk) == false || GET_FLAG(xdAttribStp, A_XdAttrib_BusKeyFlg) == TRUE)
                                        {
                                            bkNbr++;
                                        }
                                        if (IS_NULLFLD(xdAttribStp, A_XdAttrib_ProgPk) == false || GET_FLAG(xdAttribStp, A_XdAttrib_PrimaryFlg) == TRUE)
                                        {
                                            pkNbr++;
                                        }

                                        if (DATATYPE_DICT_TO_ENUM(GET_DICT(xdAttribStp, A_XdAttrib_DataTpDictId)) == IdType)
                                        {
                                            if (IS_NULLFLD(xdAttribStp, A_XdAttrib_RefXdEntityId) == false)
                                            {
                                                string refEntityStr = this->ddlGenContextPtr->getXdEntitySqlNameById(GET_ID(xdAttribStp, A_XdAttrib_RefXdEntityId));
                                                DdlGenEntity *refDdlGenEntityPtr = this->ddlGenContextPtr->getDdlGenEntityPtr(refEntityStr, string(), true);
                                                if (refDdlGenEntityPtr != nullptr)
                                                {
                                                    DBA_DYNFLD_STP refEntityStp = refDdlGenEntityPtr->getXdEntityStp();
                                                    MultiEntityHelper refMultiEntityCateg((MULTI_ENTITY_CATEGORY_ENUM)GET_ENUM(refEntityStp, A_XdEntity_MultiEntityCategoryEn));

                                                    if (refMultiEntityCateg.isBusinessEntityIsolated())
                                                    {
                                                        if (IS_NULLFLD(xdAttribStp, A_XdAttrib_ProgBk) == false || GET_FLAG(xdAttribStp, A_XdAttrib_BusKeyFlg) == TRUE)
                                                        {
                                                            bBkToUpd = false;
                                                        }
                                                        if (IS_NULLFLD(xdAttribStp, A_XdAttrib_ProgPk) == false || GET_FLAG(xdAttribStp, A_XdAttrib_PrimaryFlg) == TRUE)
                                                        {
                                                            bPkToUpd = false;
                                                        }
                                                    }
                                                }
                                            }
                                            else if (IS_NULLFLD(xdAttribStp, A_XdAttrib_LinkedXdAttribId) &&
                                                     GET_ENUM(xdEntityStp, A_XdEntity_DbRuleEn) != DbRule_PartialSpecialization)
                                            {
                                                bPkToUpd = false;
                                            }
                                        }
                                    }
                                }
                            }

                            if (bBkToUpd || bPkToUpd)
                            {
                                if (this->ddlGenContextPtr->getMultiEntityLevel() == MultiEntityLevel_Active)
                                {
                                    if (bkNbr && bBkToUpd)
                                    {
                                        /* Put the multi-entity attribute to the business key */
                                        SET_SMALLINT(newAttribStp, A_XdAttrib_ProgBk, MAX_SHORT);
                                    }

                                    if (pkNbr && bPkToUpd)
                                    {
                                        /* PMSTA-30124 - LJE - 180322 - Put te owner_business_entity_id attribute in the primary key if needed */
                                        SET_SMALLINT(newAttribStp, A_XdAttrib_ProgPk, MAX_SHORT);
                                    }
                                }
                                else if (IS_NULLFLD(newAttribStp, A_XdAttrib_Default) == TRUE ||
                                         GET_NAME(newAttribStp, A_XdAttrib_Default)[0] == 0 ||
                                         multiEntityCateg.isOwnerBusinessEntityMandatory() == false)
                                {
                                    SET_FLAG_FALSE(newAttribStp, A_XdAttrib_DbMandatoryFlg);
                                    SET_FLAG_FALSE(newAttribStp, A_XdAttrib_MandatoryFlg);
                                }
                            }

                            /* PMSTA-32145 - LJE - 180721 */
                            if (GET_FLAG(xdEntityStp, A_XdEntity_CustAuthFlg) == TRUE &&
                                this->ddlGenEntityPtr->isMesiPartitioned() &&                          /* PMSTA-36919 - LJE - 191001 */
                                GET_ENUM(xdEntityStp, A_XdEntity_DictBuildRuleEn) != DictBuildRule_Sh) /* PMSTA-36149 - LJE - 190619 */
                            {
                                this->ddlGenEntityPtr->bMultiEntityOnCustom = true;
                            }
                            if (GET_FLAG(xdEntityStp, A_XdEntity_PrecompFlg) == TRUE)
                            {
                                this->ddlGenEntityPtr->bMultiEntityOnPrecomp = true;
                            }
                        }

                        /* PMSTA-26108 - LJE - 170816 */
                        if (GET_INT(xdEntityStp, A_XdEntity_DictEntityValue) == 2508 || /* no mandatory for tasc_logger */
                            (GEN_RULE_ENUM)GET_ENUM(featureStp, A_XdEntityFeature_GenRuleEn) == GenRule_AlwaysNotMandatory)
                        {
                            SET_FLAG_FALSE(newAttribStp, A_XdAttrib_DbMandatoryFlg);
                            SET_FLAG_FALSE(newAttribStp, A_XdAttrib_MandatoryFlg);

                            if (feature == XdEntityFeatureFeatureEn::MultiBusinessEntityManagement)
                            {
                                SET_NULL_STRING(newAttribStp, A_XdAttrib_Default);
                            }
                        }
                        DATATYPE_ENUM dataTypeEn = DATATYPE_DICT_TO_ENUM(GET_DICT(newAttribStp, A_XdAttrib_DataTpDictId));
                        if (IS_NULLFLD(newAttribStp, A_XdAttrib_ParentXdAttribId) == TRUE &&                                /* PMSTA-29879 - LJE - 180214 */
                            (dataTypeEn == EnumType || dataTypeEn == FlagType || dataTypeEn == EnumMaskType))
                        {
                            this->copyDynFld(newAttribStp, A_XdAttrib_ParentXdAttribId,
                                             tplXdAttribStp, A_XdAttrib_Id);
                        }

                        this->copyDynFld(newAttribStp, A_XdAttrib_TemplateXdAttribId,
                                         tplXdAttribStp, A_XdAttrib_Id);

                        this->copyDynFld(newAttribStp, A_XdAttrib_XdEntityId,
                                         xdEntityStp, A_XdEntity_Id);

                        if (this->bShortToDo)
                        {
                            SET_NULL_SMALLINT(newAttribStp, A_XdAttrib_ShortIdx);
                        }

                        if (IS_NULLFLD(featureStp, A_XdEntityFeature_StartDispRank) == FALSE)
                        {
                            int             xdAttribNbr = this->ddlGenEntityPtr->getXdAttribNbr();
                            DBA_DYNFLD_STP  currXdAttribStp = nullptr;
                            int             i;

                            for (i = 0; i < xdAttribNbr; i++)
                            {
                                currXdAttribStp = this->ddlGenEntityPtr->getXdAttrib(i);
                                if (GET_SMALLINT(currXdAttribStp, A_XdAttrib_DispRank) > GET_SMALLINT(featureStp, A_XdEntityFeature_StartDispRank))
                                {
                                    break;
                                }
                            }

                            if (i < xdAttribNbr && currXdAttribStp)
                            {
                                currXdAttribStp = this->ddlGenEntityPtr->getXdAttrib((i == 0 ? 0 : i - 1));

                                SET_INT(newAttribStp, A_XdAttrib_Prog, GET_INT(currXdAttribStp, A_XdAttrib_Prog) + 1);
                                SET_INT(newAttribStp, A_XdAttrib_OldProg, GET_INT(currXdAttribStp, A_XdAttrib_OldProg) + 1);

                                for (; i < xdAttribNbr; i++)
                                {
                                    currXdAttribStp = this->ddlGenEntityPtr->getXdAttrib(i);

                                    if (IS_NULLFLD(currXdAttribStp, A_XdAttrib_Prog) == FALSE &&
                                        GET_INT(currXdAttribStp, A_XdAttrib_Prog) < PROG_N_START_FEATURE)
                                    {
                                        SET_INT(currXdAttribStp, A_XdAttrib_Prog, (GET_INT(currXdAttribStp, A_XdAttrib_Prog) + 1));
                                    }
                                }
                            }

                            SET_SMALLINT(newAttribStp, A_XdAttrib_DispRank, (SMALLINT_T)(GET_SMALLINT(featureStp, A_XdEntityFeature_StartDispRank) + insertedAttribNbr));
                        }
                        else
                        {
                            SET_INT(newAttribStp, A_XdAttrib_Prog, GET_INT(tplXdAttribStp, A_XdAttrib_Prog) + PROG_N_START_FEATURE);
                            SET_INT(newAttribStp, A_XdAttrib_OldProg, GET_INT(tplXdAttribStp, A_XdAttrib_Prog) + PROG_N_START_FEATURE);

                            if (feature == XdEntityFeatureFeatureEn::MultiBusinessEntityManagement)
                            {
                                SET_INT(newAttribStp, A_XdAttrib_Prog, GET_INT(newAttribStp, A_XdAttrib_Prog) + 900);
                                SET_INT(newAttribStp, A_XdAttrib_OldProg, GET_INT(newAttribStp, A_XdAttrib_Prog) + 900);
                            }
                            else if (feature == XdEntityFeatureFeatureEn::ShadowEntity)
                            {
                                SET_INT(newAttribStp, A_XdAttrib_Prog, GET_INT(newAttribStp, A_XdAttrib_Prog) + 910);
                                SET_INT(newAttribStp, A_XdAttrib_OldProg, GET_INT(newAttribStp, A_XdAttrib_Prog) + 910);
                            }

                            if (GET_SMALLINT(newAttribStp, A_XdAttrib_DispRank) > 0)
                            {
                                SET_SMALLINT(newAttribStp, A_XdAttrib_DispRank, GET_SMALLINT(newAttribStp, A_XdAttrib_DispRank) + PROG_N_START_FEATURE);
                            }
                        }

                        if (this->bShortToDo)
                        {
                            SET_NULL_SMALLINT(newAttribStp, A_XdAttrib_ShortIdx);
                            SET_NULL_SMALLINT(newAttribStp, A_XdAttrib_ShortDispRank);
                        }

                        this->ddlGenEntityPtr->fixTemplateAttributeId(newAttribStp, A_XdAttrib_Join1XdAttribId);
                        this->ddlGenEntityPtr->fixTemplateAttributeId(newAttribStp, A_XdAttrib_Join2XdAttribId);

                        if (forcedCalcEn != DictAttr_NoMD)
                        {
                            SET_ENUM(newAttribStp, A_XdAttrib_CalcEn, forcedCalcEn);
                        }

                        if (IS_NULLFLD(this->getXdEntityStp(), A_XdEntity_NatXdAttribId) == FALSE)
                        {
                            if (GET_MASK(newAttribStp, A_XdAttrib_SubTpMask) != 0)
                            {
                                SET_MASK(newAttribStp, A_XdAttrib_SubTpMask, NO_VALUE); /* PMSTA-38457 - sriharbv - 200107*/
                            }
                            if (GET_MASK(newAttribStp, A_XdAttrib_SearchMask) != 0)
                            {
                                SET_MASK(newAttribStp, A_XdAttrib_SearchMask, NO_VALUE);
                            }
                            if (GET_MASK(newAttribStp, A_XdAttrib_QuickSearchMask) != 0)
                            {
                                SET_MASK(newAttribStp, A_XdAttrib_QuickSearchMask, NO_VALUE);
                            }
                        }

                        if (GET_MASK(newAttribStp, A_XdAttrib_SubTpMask) != 0 && GET_SMALLINT(newAttribStp, A_XdAttrib_DispRank) == 0)
                        {
                            SET_NULL_SMALLINT(newAttribStp, A_XdAttrib_DispRank);
                        }

                        /* PMSTA-36919 - LJE - 191001 */
                        if (GET_ENUM(newAttribStp, A_XdAttrib_XdActionEn) != XdAction_ToPhysicallyDelete)
                        {
                            SET_ENUM(newAttribStp, A_XdAttrib_XdActionEn, XdAction_ToInsert);
                        }

                        if (bNewAttrib)
                        {
                            DBA_DYNFLD_STP  dbAttribStp = this->ddlGenEntityPtr->getDbXdAttribBySqlName(sqlName);

                            if (dbAttribStp != nullptr)
                            {
                                this->copyDynFld(newAttribStp, A_XdAttrib_Id, dbAttribStp, A_XdAttrib_Id);
                                this->copyDynFld(newAttribStp, A_XdAttrib_AttribDictId, dbAttribStp, A_XdAttrib_AttribDictId);
                                this->copyDynFld(newAttribStp, A_XdAttrib_XdStatusEn, dbAttribStp, A_XdAttrib_XdStatusEn);
                                this->copyDynFld(newAttribStp, A_XdAttrib_BuildDate, dbAttribStp, A_XdAttrib_BuildDate);
                            }
                            else
                            {
                                SET_NULL_ID(newAttribStp, A_XdAttrib_Id);
                                SET_NULL_DICT(newAttribStp, A_XdAttrib_AttribDictId);
                                SET_ENUM(newAttribStp, A_XdAttrib_XdStatusEn, XdStatus_Untreated);

                                requestHelper.dbaCall(Insert,
                                                      XdAttrib,
                                                      DBA_ROLE_UDT,
                                                      newAttribStp,
                                                      10,
                                                      xdEntityStp);
                            }

                            this->ddlGenEntityPtr->addXdAttribInTab(newAttribStp);
                            requestHelper.ownerDynStp(newAttribStp);
                            mp.remove(newAttribStp);
                        }
                        else
                        {
                            SET_ID(newAttribStp, A_XdAttrib_Id, tplAttribId);
                            if (tplAttribDictId)
                            {
                                SET_DICT(newAttribStp, A_XdAttrib_AttribDictId, tplAttribDictId);
                            }
                            else
                            {
                                SET_NULL_DICT(newAttribStp, A_XdAttrib_AttribDictId);
                            }
                            this->copyDynFld(newAttribStp, A_XdAttrib_FeatureEn, tplXdAttribStp, A_XdAttrib_FeatureEn);
                        }

                        insertedAttribNbr++;
                    }
                }

                SET_ENUM(featureStp, A_XdEntityFeature_XdStatusEn, XdStatus_Inserted);
            }
        }
        else
        {
            SET_ENUM(featureStp, A_XdEntityFeature_XdStatusEn, XdStatus_Deleted);
        }

        SET_ENUM(featureStp, A_XdEntityFeature_XdActionEn, XdAction_None);

        requestHelper.dbaCall(Update,
                              XdEntityFeature,
                              DBA_ROLE_STATUS,
                              featureStp,
                              20,
                              xdEntityStp);
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenFullTable::addMandatoryAttributes()
**
**  Description :  Check if exists mandatory attributes and create
**                 if not exists
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13109 - LJE - 110311
**
*************************************************************************/
RET_CODE DdlGenFullTable::addMandatoryAttributes(DdlGenRequestHelper& requestHelper)
{
    RET_CODE          ret = RET_SUCCEED;

    if (this->getDdlGenAction().m_mainDdlObjNatEn == DbObjDdlObjNat_TslExtension)
    {
        return ret;
    }

    DBA_DYNFLD_STP    xdEntityStp = this->getXdEntityStp();
    bool              bInsertUdId = (GET_FLAG(xdEntityStp, A_XdEntity_CustAuthFlg) == TRUE);
    bool              bReportFmt = (GET_ENUM(xdEntityStp, A_XdEntity_NatEn) == EntityNat_ReportFmt);
    bool              bInsertRepAtt = bReportFmt;
    bool              bInsertScptAttrib = (GET_ENUM(xdEntityStp, A_XdEntity_NatEn) != EntityNat_Internal);                  /* PMSTA-37366 - LJE - 200311 */
    DBA_DYNFLD_STP    newAttribStp, scptCtrlXdAttribStp = NULL, rNatureXdAttribStp = NULL, rDataSetIdXdAttribStp = NULL;
    bool              bNewInsert = false;
    string            rDataSetId = "r_dataset_id";
    string            rNature = "r_nature_e";
    DdlGenEntity* lnkDdlGenEntityPtr = nullptr;

    /* PMSTA-36919 - LJE - 191001 */
    for (int i = 0; i < this->ddlGenEntityPtr->getXdAttribNbr(); i++)
    {
        DBA_DYNFLD_STP    currXdAttribStp = this->ddlGenEntityPtr->getXdAttrib(i);

        if (GET_ENUM(currXdAttribStp, A_XdAttrib_XdActionEn) == XdAction_ToInsert &&
            GET_A_XdAttrib_FeatureEn(currXdAttribStp) == XdEntityFeatureFeatureEn::MultiBusinessEntityManagement &&
            IS_NULLFLD(currXdAttribStp, A_XdAttrib_TemplateXdAttribId) == FALSE)
        {
            SET_ENUM(currXdAttribStp, A_XdAttrib_XdActionEn, XdAction_ToPhysicallyDelete);
        }
    }

    if (IS_NULLFLD(xdEntityStp, A_XdEntity_LinkedXdEntityId) == FALSE &&
        (GET_ENUM(xdEntityStp, A_XdEntity_DictBuildRuleEn) == DictBuildRule_Ud ||
         GET_ENUM(xdEntityStp, A_XdEntity_DictBuildRuleEn) == DictBuildRule_Sh ||
         /* PMSTA-30346 - LJE - 180301 */
         GET_ENUM(xdEntityStp, A_XdEntity_DictBuildRuleEn) == DictBuildRule_All ||
         GET_ENUM(xdEntityStp, A_XdEntity_DictBuildRuleEn) == DictBuildRule_AllDb ||
         GET_ENUM(xdEntityStp, A_XdEntity_DictBuildRuleEn) == DictBuildRule_AllForcePhysical))
    {
        string lnkEntitySqlName = this->ddlGenContextPtr->getXdEntitySqlNameById(GET_ID(xdEntityStp, A_XdEntity_LinkedXdEntityId));
        lnkDdlGenEntityPtr = this->ddlGenContextPtr->getDdlGenEntityPtr(lnkEntitySqlName);

        if (lnkDdlGenEntityPtr != nullptr)
        {
            /* Copy the features of the linked entity */
            DBA_DYNFLD_STP lnkXdEntityStp = lnkDdlGenEntityPtr->getXdEntityStp();

            if (GET_ENUM(lnkXdEntityStp, A_XdEntity_PartAuthEn) == FeatureAuth_Enable)
            {
                int                    partitionNbr = lnkDdlGenEntityPtr->getXdPartitionNbr();
                DBA_DYNFLD_STP* partitionTab = lnkDdlGenEntityPtr->getXdPartitionTab();

                for (int i = 0; i < partitionNbr; i++)
                {
                    this->ddlGenEntityPtr->addXdPartition(requestHelper, partitionTab[i], lnkDdlGenEntityPtr);
                }
            }

            for (auto it = lnkDdlGenEntityPtr->xdEntityFeatureMap.begin(); it != lnkDdlGenEntityPtr->xdEntityFeatureMap.end(); it++)
            {
                DBA_DYNFLD_STP    featureStp = it->second;

                if ((GET_ENUM(xdEntityStp, A_XdEntity_DictBuildRuleEn) == DictBuildRule_Sh ||
                     GET_ENUM(xdEntityStp, A_XdEntity_DictBuildRuleEn) == DictBuildRule_AllDb ||
                     GET_ENUM(xdEntityStp, A_XdEntity_DictBuildRuleEn) == DictBuildRule_AllForcePhysical ||
                     GET_ENUM(xdEntityStp, A_XdEntity_NatEn) == EntityNat_TempTable) &&
                    (GET_A_XdEntityFeature_FeatureEn(featureStp) == XdEntityFeatureFeatureEn::ChangeSet ||
                     GET_A_XdEntityFeature_FeatureEn(featureStp) == XdEntityFeatureFeatureEn::ShadowEntity ||
                     GET_A_XdEntityFeature_FeatureEn(featureStp) == XdEntityFeatureFeatureEn::TSLExtensions))
                {
                    continue;
                }

                if ((XD_ACTION_ENUM)GET_ENUM(featureStp, A_XdEntityFeature_XdActionEn) == XdAction_ToInsert ||
                    ((XD_ACTION_ENUM)GET_ENUM(featureStp, A_XdEntityFeature_XdActionEn) == XdAction_None && (XD_STATUS_ENUM)GET_ENUM(featureStp, A_XdEntityFeature_XdStatusEn) == XdStatus_Inserted))
                {
                    this->ddlGenEntityPtr->addXdEntityFeature(requestHelper,
                                                              GET_A_XdEntityFeature_FeatureEn(featureStp),
                                                              (GEN_RULE_ENUM)GET_ENUM(featureStp, A_XdEntityFeature_GenRuleEn),
                                                              (FEATURE_AUTH_ENUM)GET_ENUM(featureStp, A_XdEntityFeature_AuthEn),
                                                              false);
                }
            }
        }
    }

    this->ddlGenEntityPtr->sortAttributes();

    /* PMSTA-26108 - LJE - 170728 */
    if (MultiEntityHelper::isMultiEntityCateg((MULTI_ENTITY_CATEGORY_ENUM)GET_ENUM(xdEntityStp, A_XdEntity_MultiEntityCategoryEn)))
    {
        this->ddlGenEntityPtr->addXdEntityFeature(requestHelper,
                                                  XdEntityFeatureFeatureEn::AccessRightManagement,
                                                  GenRule_Standard,
                                                  FeatureAuth_Enable,
                                                  false);

        if (this->ddlGenContextPtr->getMultiEntityLevel() != MultiEntityLevel_None)
        {
            if ((MULTI_ENTITY_CATEGORY_ENUM)GET_ENUM(xdEntityStp, A_XdEntity_MultiEntityCategoryEn) == MultiEntityCategory_MasterOnlyPrecOnBEOnly)
            {
                this->ddlGenEntityPtr->addXdEntityFeature(requestHelper,
                                                          XdEntityFeatureFeatureEn::MultiBusinessEntityManagement,
                                                          GenRule_Virtual,
                                                          FeatureAuth_Enable,
                                                          false);
            }
            else
            {
                this->ddlGenEntityPtr->addXdEntityFeature(requestHelper,
                                                          XdEntityFeatureFeatureEn::MultiBusinessEntityManagement,
                                                          GenRule_Standard,
                                                          FeatureAuth_Enable,
                                                          false);
            }
        }
        else
        {
            SET_ENUM(xdEntityStp, A_XdEntity_MultiEntityCategoryEn, MultiEntityCategory_None);
        }
    }

    /* PMSTA-45413 - LJE - 211103 */
    if (bInsertScptAttrib)
    {
        this->ddlGenEntityPtr->addXdEntityFeature(requestHelper,
                                                  XdEntityFeatureFeatureEn::ScriptControl,
                                                  GenRule_Standard,
                                                  FeatureAuth_Enable,
                                                  false);
    }

    /* PMSTA-26108 - LJE - 170824 */
    auto it = this->ddlGenEntityPtr->xdEntityFeatureMap.find(XdEntityFeatureFeatureEn::ChangeSet);
    if (it != this->ddlGenEntityPtr->xdEntityFeatureMap.end())
    {
        DBA_DYNFLD_STP    featureStp = it->second;

        if ((FEATURE_AUTH_ENUM)GET_ENUM(featureStp, A_XdEntityFeature_AuthEn) != FeatureAuth_Forbidden &&
            (XD_ACTION_ENUM)GET_ENUM(featureStp, A_XdEntityFeature_XdActionEn) == XdAction_ToInsert)
        {
            this->ddlGenEntityPtr->addXdEntityFeature(requestHelper,
                                                      XdEntityFeatureFeatureEn::ShadowEntity,
                                                      GenRule_Denorm,
                                                      FeatureAuth_Enable,
                                                      false);
            this->ddlGenEntityPtr->addXdEntityFeature(requestHelper,
                                                      XdEntityFeatureFeatureEn::AccessRightManagement,
                                                      GenRule_Standard,
                                                      FeatureAuth_Enable,
                                                      false);
        }
    }

    /* PMSTA-37366 - LJE - 200207 */
    if (this->bExtTableToDo)
    {
        this->ddlGenEntityPtr->addXdEntityFeature(requestHelper,
                                                  XdEntityFeatureFeatureEn::TSLExtensions,
                                                  GenRule_Standard,
                                                  FeatureAuth_Enable,
                                                  false);
    }

    for (it = this->ddlGenEntityPtr->xdEntityFeatureMap.begin(); it != this->ddlGenEntityPtr->xdEntityFeatureMap.end(); it++)
    {
        DBA_DYNFLD_STP    featureStp = it->second;

        if ((XD_ACTION_ENUM)GET_ENUM(featureStp, A_XdEntityFeature_XdActionEn) == XdAction_ToInsert)
        {
            switch (GET_A_XdEntityFeature_FeatureEn(featureStp))
            {
                case XdEntityFeatureFeatureEn::UserDefinedField:
                    if ((FEATURE_AUTH_ENUM)GET_ENUM(featureStp, A_XdEntityFeature_AuthEn) == FeatureAuth_Enable)
                    {
                        SET_FLAG(xdEntityStp, A_XdEntity_CustAuthFlg, TRUE);
                    }
                    break;
                case XdEntityFeatureFeatureEn::UpdateFunction:
                    SET_ENUM(xdEntityStp, A_XdEntity_UpdFctAuthEn, GET_ENUM(featureStp, A_XdEntityFeature_AuthEn));
                    break;
                case XdEntityFeatureFeatureEn::ExternalSequencing:
                    SET_ENUM(xdEntityStp, A_XdEntity_ExternalSeqAuthEn, GET_ENUM(featureStp, A_XdEntityFeature_AuthEn));
                    break;
                case XdEntityFeatureFeatureEn::Active:
                    SET_ENUM(xdEntityStp, A_XdEntity_ActiveAuthEn, GET_ENUM(featureStp, A_XdEntityFeature_AuthEn));
                    break;
                case XdEntityFeatureFeatureEn::Creation:
                    if ((FEATURE_AUTH_ENUM)GET_ENUM(featureStp, A_XdEntityFeature_AuthEn) == FeatureAuth_Enable)
                    {
                        SET_ENUM(xdEntityStp, A_XdEntity_DmlModifTrackEn, dmlModifTrack_InsertUpdateTracking);
                    }
                    break;
                case XdEntityFeatureFeatureEn::LastModification:
                    if ((FEATURE_AUTH_ENUM)GET_ENUM(featureStp, A_XdEntityFeature_AuthEn) == FeatureAuth_Enable &&
                        (DML_MODIF_TRACK_ENUM)GET_ENUM(xdEntityStp, A_XdEntity_DmlModifTrackEn) == dmlModifTrack_None)
                    {
                        SET_ENUM(xdEntityStp, A_XdEntity_DmlModifTrackEn, dmlModifTrack_UpdateTracking);
                    }
                    break;
                case XdEntityFeatureFeatureEn::DLM:
                    SET_ENUM(xdEntityStp, A_XdEntity_DlmAuthEn, GET_ENUM(featureStp, A_XdEntityFeature_AuthEn));

                    if ((GEN_RULE_ENUM)GET_ENUM(featureStp, A_XdEntityFeature_GenRuleEn) == GenRule_Standard)
                    {
                        SET_ENUM(featureStp, A_XdEntityFeature_GenRuleEn, GenRule_AlwaysButVirtual);
                    }
                    break;

                case XdEntityFeatureFeatureEn::ChangeSet:
                    if ((FEATURE_AUTH_ENUM)GET_ENUM(featureStp, A_XdEntityFeature_AuthEn) == FeatureAuth_Enable)
                    {
                        SET_ENUM(xdEntityStp, A_XdEntity_PkRuleEn, PkRule_ExternalPk);
                    }
                    break;
                case XdEntityFeatureFeatureEn::ExternalPkEntity:
                    if ((FEATURE_AUTH_ENUM)GET_ENUM(featureStp, A_XdEntityFeature_AuthEn) == FeatureAuth_Enable)
                    {
                        /*PMSTA-56937 - VPR - 240712*/
                        if (GET_ENUM(xdEntityStp, A_XdEntity_DbRuleEn) == DbRule_Standard) 
                        {
                            SET_ENUM(xdEntityStp, A_XdEntity_PkRuleEn, PkRule_ExternalPk);
                        }
                    }
                    break;

                case XdEntityFeatureFeatureEn::RPCEntity:
                    if ((FEATURE_AUTH_ENUM)GET_ENUM(featureStp, A_XdEntityFeature_AuthEn) == FeatureAuth_Enable &&
                        (LOAD_DICT_RULE_ENUM)GET_ENUM(xdEntityStp, A_XdEntity_LoadDictRuleEn) == LoadDictRule_Standard)
                    {
                        SET_ENUM(xdEntityStp, A_XdEntity_LoadDictRuleEn, LoadDictRule_Always);
                    }
                    break;

                case XdEntityFeatureFeatureEn::Report:
                case XdEntityFeatureFeatureEn::ScriptControl:
                default:
                    /* Nothing to do */
                    break;
            }
        }
        else if (GET_A_XdEntityFeature_XdActionEn(featureStp) == XdEntityXdActionEn::None &&
                 GET_A_XdEntityFeature_XdStatusEn(featureStp) == XdEntityXdStatusEn::Inserted)
        {
            SET_A_XdEntityFeature_XdActionEn(featureStp, XdEntityXdActionEn::ToInsert);
        }

        this->addAttributesFromFeature(requestHelper, featureStp);
    }

    /* Erase not valid features */
    for (it = this->ddlGenEntityPtr->xdEntityFeatureMap.begin(); it != this->ddlGenEntityPtr->xdEntityFeatureMap.end(); /* no increment */)
    {
        if ((XD_STATUS_ENUM)GET_ENUM(it->second, A_XdEntityFeature_XdStatusEn) != XdStatus_Inserted)
        {
            this->ddlGenEntityPtr->xdEntityFeatureMap.erase(it++);
        }
        else
        {
            ++it;
        }
    }

    if (this->ddlGenEntityPtr->getXdAttribNbr() == 0 ||
        GET_ENUM(xdEntityStp, A_XdEntity_NatEn) == EntityNat_TempTable)
    {
        return ret;
    }

    for (int i = 0; i < this->ddlGenEntityPtr->getXdAttribNbr(); i++)
    {
        DBA_DYNFLD_STP currXdAttribStp = this->ddlGenEntityPtr->getXdAttrib(i);

        if (GET_ENUM(currXdAttribStp, A_XdAttrib_CustomFlg) == Custom_No &&
            GET_ENUM(currXdAttribStp, A_XdAttrib_XdActionEn) != XdAction_None)
        {
            bNewInsert = true;
            break;
        }
    }

    for (int i = 0; i < this->ddlGenEntityPtr->getXdAttribNbr(); i++)
    {
        DBA_DYNFLD_STP currXdAttribStp = this->ddlGenEntityPtr->getXdAttrib(i);

        if (scptCtrlXdAttribStp == NULL &&
            DdlGen::getScriptControlSqlName().compare(GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName)) == 0)
        {
            SET_SMALLINT(currXdAttribStp, A_XdAttrib_DispRank, DISP_RANK_SCPT_CTRL);
            if (GET_FLAG(currXdAttribStp, A_XdAttrib_LogicalFlg) == FALSE) /* PMSTA-14800 - LJE - 120822 */
            {
                ret = RET_DBA_ERR_MD;
                this->printMsg(ret, "The attribute " + DdlGen::getScriptControlSqlName() + " must be logical");
                return (ret);
            }
            scptCtrlXdAttribStp = currXdAttribStp; /* PMSTA-16378 - LJE - 130528 */
        }

        if (bInsertUdId &&
            DdlGen::getUdIdSqlName().compare(GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName)) == 0)
        {
            bInsertUdId = false;
            if (bNewInsert)
            {
                SET_ENUM(currXdAttribStp, A_XdAttrib_XdActionEn, XdAction_ToInsert);
            }
            SET_ENUM(currXdAttribStp, A_XdAttrib_CustomFlg, Custom_Yes);
            SET_FLAG_TRUE(currXdAttribStp, A_XdAttrib_MandatoryFlg);
            SET_FLAG_TRUE(currXdAttribStp, A_XdAttrib_DbMandatoryFlg);
        }

        if (bInsertRepAtt)
        {
            if (rDataSetIdXdAttribStp == NULL &&
                rDataSetId.compare(GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName)) == 0)
            {
                rDataSetIdXdAttribStp = currXdAttribStp;
            }

            if (rNatureXdAttribStp == NULL &&
                rNature.compare(GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName)) == 0)
            {
                rNatureXdAttribStp = currXdAttribStp;
            }
        }
    }

    if (bInsertUdId && (this->m_dictEntityStp == NULL || this->m_dictEntityStp->bIsInitEntity == false))
    {
        if ((newAttribStp = ALLOC_DYNST(A_XdAttrib)) == NULL)
        {
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }

        DBA_SetDfltEntityFld(XdAttrib, A_XdAttrib, newAttribStp);

        SET_NULL_INT(newAttribStp, A_XdAttrib_Prog);
        SET_NULL_INT(newAttribStp, A_XdAttrib_DbProg);
        SET_NULL_INT(newAttribStp, A_XdAttrib_OldProg);

        this->copyDynFld(newAttribStp, A_XdAttrib_XdEntityId, this->ddlGenEntityPtr->getXdAttrib(0), A_XdAttrib_XdEntityId);
        SET_SYSNAME(newAttribStp, A_XdAttrib_SqlName, DdlGen::getUdIdSqlName().c_str());
        SET_SYSNAME(newAttribStp, A_XdAttrib_Name, DdlGen::getUdIdSqlName().c_str());
        SET_DICT(newAttribStp, A_XdAttrib_DataTpDictId, DATATYPE_ENUM_TO_DICT(IdType));
        SET_SMALLINT(newAttribStp, A_XdAttrib_DispRank, 0);
        SET_NULL_MASK(newAttribStp, A_XdAttrib_SubTpMask);
        SET_NULL_MASK(newAttribStp, A_XdAttrib_QuickSearchMask);
        SET_NULL_MASK(newAttribStp, A_XdAttrib_SearchMask);
        SET_ENUM(newAttribStp, A_XdAttrib_EditEn, DictAttrib_EditNoEdit);
        SET_NULL_ID(newAttribStp, A_XdAttrib_RefXdEntityId);
        SET_FLAG_FALSE(newAttribStp, A_XdAttrib_LogicalFlg);

        SET_FLAG_FALSE(newAttribStp, A_XdAttrib_PrimaryFlg);
        SET_FLAG_TRUE(newAttribStp, A_XdAttrib_MandatoryFlg);
        SET_FLAG_TRUE(newAttribStp, A_XdAttrib_DbMandatoryFlg);
        SET_FLAG_FALSE(newAttribStp, A_XdAttrib_PermValFlg);
        SET_FLAG_FALSE(newAttribStp, A_XdAttrib_BusKeyFlg);
        SET_ENUM(newAttribStp, A_XdAttrib_CustomFlg, Custom_Yes);
        SET_FLAG_FALSE(newAttribStp, A_XdAttrib_PrecompFlg);
        SET_FLAG_FALSE(newAttribStp, A_XdAttrib_VerticalSearchFlg);
        SET_FLAG_FALSE(newAttribStp, A_XdAttrib_VerticalPatternFlg);
        SET_FLAG_FALSE(newAttribStp, A_XdAttrib_MultiLangFlg);

        SET_ENUM(newAttribStp, A_XdAttrib_RefDeleteRuleEn, RefDelRule_CascadeDelete);
        SET_ENUM(newAttribStp, A_XdAttrib_RefCheckRuleEn, RefChkRule_Checked);
        SET_ENUM(newAttribStp, A_XdAttrib_RefSecurityRuleEn, RefSecuRule_Inherited);
        SET_ENUM(newAttribStp, A_XdAttrib_CalcEn, DictAttr_Physical);
        SET_ENUM(newAttribStp, A_XdAttrib_SecurityLevelEn, 0);
        SET_ENUM(newAttribStp, A_XdAttrib_TascViewEn, 1);
        SET_ENUM(newAttribStp, A_XdAttrib_ObjModifStatEn, LastModif_NoTracking);
        if (bNewInsert)
        {
            SET_ENUM(newAttribStp, A_XdAttrib_XdActionEn, XdAction_ToInsert);
        }
        else
        {
            SET_ENUM(newAttribStp, A_XdAttrib_XdActionEn, XdAction_None);
        }
        SET_ENUM(newAttribStp, A_XdAttrib_XdStatusEn, XdStatus_Untreated);

        if ((ret = requestHelper.dbaCall(Insert,
                                         XdAttrib,
                                         DBA_ROLE_UDT,
                                         newAttribStp,
                                         10,
                                         xdEntityStp)) != RET_SUCCEED)
        {
            requestHelper.sendAllMsg();

            this->printMsgData(RET_DBA_ERR_INSERT_FAILED, newAttribStp);
            return ret;
        }

        this->ddlGenEntityPtr->addXdAttribInTab(newAttribStp);
    }

    /* PMSTA-18593 - LJE - 160108 */
    if (bInsertRepAtt)
    {
        if (rDataSetIdXdAttribStp == NULL)
        {
            newAttribStp = requestHelper.allocDynSt(FILEINFO, A_XdAttrib);

            DBA_SetDfltEntityFld(XdAttrib, A_XdAttrib, newAttribStp);
            this->copyDynFld(newAttribStp, A_XdAttrib_XdEntityId, this->ddlGenEntityPtr->getXdAttrib(0), A_XdAttrib_XdEntityId);
            SET_ENUM(newAttribStp, A_XdAttrib_XdStatusEn, XdStatus_Untreated);
            SET_SYSNAME(newAttribStp, A_XdAttrib_SqlName, rDataSetId.c_str());
        }
        else
        {
            newAttribStp = rDataSetIdXdAttribStp;
        }

        SET_INT(newAttribStp, A_XdAttrib_Prog, 0);
        SET_INT(newAttribStp, A_XdAttrib_OldProg, 0);
        SET_NULL_INT(newAttribStp, A_XdAttrib_DbProg);

        SET_DICT(newAttribStp, A_XdAttrib_DataTpDictId, DATATYPE_ENUM_TO_DICT(IdType));
        SET_SYSNAME(newAttribStp, A_XdAttrib_Name, rDataSetId.c_str());
        SET_SMALLINT(newAttribStp, A_XdAttrib_DispRank, 0);
        SET_NULL_MASK(newAttribStp, A_XdAttrib_SubTpMask);
        SET_NULL_MASK(newAttribStp, A_XdAttrib_QuickSearchMask);
        SET_NULL_MASK(newAttribStp, A_XdAttrib_SearchMask);
        SET_ENUM(newAttribStp, A_XdAttrib_EditEn, DictAttrib_EditNoEdit);
        SET_NULL_ID(newAttribStp, A_XdAttrib_RefXdEntityId);
        SET_FLAG_FALSE(newAttribStp, A_XdAttrib_LogicalFlg);

        SET_FLAG_FALSE(newAttribStp, A_XdAttrib_PrimaryFlg);
        SET_FLAG_TRUE(newAttribStp, A_XdAttrib_MandatoryFlg);
        SET_FLAG_TRUE(newAttribStp, A_XdAttrib_DbMandatoryFlg);
        SET_FLAG_FALSE(newAttribStp, A_XdAttrib_PermValFlg);
        SET_FLAG_FALSE(newAttribStp, A_XdAttrib_BusKeyFlg);
        SET_ENUM(newAttribStp, A_XdAttrib_CustomFlg, Custom_No);
        SET_FLAG_FALSE(newAttribStp, A_XdAttrib_PrecompFlg);
        SET_FLAG_FALSE(newAttribStp, A_XdAttrib_VerticalSearchFlg);
        SET_FLAG_FALSE(newAttribStp, A_XdAttrib_VerticalPatternFlg);
        SET_FLAG_FALSE(newAttribStp, A_XdAttrib_MultiLangFlg);

        SET_ENUM(newAttribStp, A_XdAttrib_RefDeleteRuleEn, RefDelRule_NoAction);
        SET_ENUM(newAttribStp, A_XdAttrib_RefCheckRuleEn, RefChkRule_None);
        SET_ENUM(newAttribStp, A_XdAttrib_RefSecurityRuleEn, RefSecuRule_Inherited);
        SET_ENUM(newAttribStp, A_XdAttrib_CalcEn, DictAttr_Physical);
        SET_ENUM(newAttribStp, A_XdAttrib_SecurityLevelEn, 0);
        SET_ENUM(newAttribStp, A_XdAttrib_TascViewEn, 1);
        SET_ENUM(newAttribStp, A_XdAttrib_ObjModifStatEn, LastModif_NoTracking);
        SET_ENUM(newAttribStp, A_XdAttrib_XdActionEn, XdAction_ToInsert);

        if (rDataSetIdXdAttribStp == NULL)
        {
            if ((ret = requestHelper.dbaCall(Insert,
                                             XdAttrib,
                                             DBA_ROLE_UDT,
                                             newAttribStp,
                                             10,
                                             xdEntityStp)) != RET_SUCCEED)
            {
                requestHelper.sendAllMsg();

                this->printMsgData(RET_DBA_ERR_INSERT_FAILED, newAttribStp);
                return ret;
            }

            this->ddlGenEntityPtr->addXdAttribInTab(newAttribStp);
        }

        if (rNatureXdAttribStp == NULL)
        {
            newAttribStp = requestHelper.allocDynSt(FILEINFO, A_XdAttrib);

            DBA_SetDfltEntityFld(XdAttrib, A_XdAttrib, newAttribStp);
            this->copyDynFld(newAttribStp, A_XdAttrib_XdEntityId, this->ddlGenEntityPtr->getXdAttrib(0), A_XdAttrib_XdEntityId);
            SET_SYSNAME(newAttribStp, A_XdAttrib_SqlName, rNature.c_str());
            SET_ENUM(newAttribStp, A_XdAttrib_XdStatusEn, XdStatus_Untreated);
        }
        else
        {
            newAttribStp = rNatureXdAttribStp;
        }

        SET_INT(newAttribStp, A_XdAttrib_Prog, 1);
        SET_INT(newAttribStp, A_XdAttrib_OldProg, 1);
        SET_NULL_INT(newAttribStp, A_XdAttrib_DbProg);

        SET_DICT(newAttribStp, A_XdAttrib_DataTpDictId, DATATYPE_ENUM_TO_DICT(EnumType));
        SET_SYSNAME(newAttribStp, A_XdAttrib_Name, rNature.c_str());
        SET_SMALLINT(newAttribStp, A_XdAttrib_DispRank, 0);
        SET_NULL_MASK(newAttribStp, A_XdAttrib_SubTpMask);
        SET_NULL_MASK(newAttribStp, A_XdAttrib_QuickSearchMask);
        SET_NULL_MASK(newAttribStp, A_XdAttrib_SearchMask);
        SET_ENUM(newAttribStp, A_XdAttrib_EditEn, DictAttrib_EditNoEdit);
        SET_NULL_ID(newAttribStp, A_XdAttrib_RefXdEntityId);
        SET_FLAG_FALSE(newAttribStp, A_XdAttrib_LogicalFlg);

        SET_FLAG_FALSE(newAttribStp, A_XdAttrib_PrimaryFlg);
        SET_FLAG_TRUE(newAttribStp, A_XdAttrib_MandatoryFlg);
        SET_FLAG_TRUE(newAttribStp, A_XdAttrib_DbMandatoryFlg);
        SET_FLAG_FALSE(newAttribStp, A_XdAttrib_PermValFlg);
        SET_FLAG_FALSE(newAttribStp, A_XdAttrib_BusKeyFlg);
        SET_ENUM(newAttribStp, A_XdAttrib_CustomFlg, Custom_No);
        SET_FLAG_FALSE(newAttribStp, A_XdAttrib_PrecompFlg);
        SET_FLAG_FALSE(newAttribStp, A_XdAttrib_VerticalSearchFlg);
        SET_FLAG_FALSE(newAttribStp, A_XdAttrib_VerticalPatternFlg);
        SET_FLAG_FALSE(newAttribStp, A_XdAttrib_MultiLangFlg);

        SET_ENUM(newAttribStp, A_XdAttrib_RefDeleteRuleEn, RefDelRule_None);
        SET_ENUM(newAttribStp, A_XdAttrib_RefCheckRuleEn, RefChkRule_None);
        SET_ENUM(newAttribStp, A_XdAttrib_RefSecurityRuleEn, RefSecuRule_Inherited);
        SET_ENUM(newAttribStp, A_XdAttrib_CalcEn, DictAttr_Physical);
        SET_ENUM(newAttribStp, A_XdAttrib_SecurityLevelEn, 0);
        SET_ENUM(newAttribStp, A_XdAttrib_TascViewEn, 1);
        SET_ENUM(newAttribStp, A_XdAttrib_ObjModifStatEn, LastModif_NoTracking);
        SET_ENUM(newAttribStp, A_XdAttrib_XdActionEn, XdAction_ToInsert);

        if (rNatureXdAttribStp == NULL)
        {
            if ((ret = requestHelper.dbaCall(Insert,
                                             XdAttrib,
                                             DBA_ROLE_UDT,
                                             newAttribStp,
                                             10,
                                             xdEntityStp)) != RET_SUCCEED)
            {
                requestHelper.sendAllMsg();

                this->printMsgData(RET_DBA_ERR_INSERT_FAILED, newAttribStp);
                return ret;
            }

            this->ddlGenEntityPtr->addXdAttribInTab(newAttribStp);
        }
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenFullTable::manageExtAttributes()
**
**  Description :  Manage partitions definition
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-37366 - LJE - 200203
**
*************************************************************************/
RET_CODE DdlGenFullTable::manageExtAttributes(DdlGenRequestHelper& requestHelper)
{
    RET_CODE          ret = RET_SUCCEED;

    if (this->bCheckAndFixDone == false)
    {
        if (this->ddlGenEntityPtr->m_extFmtEltVector.empty() == false)
        {
            DBA_DYNFLD_STP    xdEntityStp = this->getXdEntityStp();

            for (int i = 0; i < this->ddlGenEntityPtr->getXdAttribNbr(); i++)
            {
                DBA_DYNFLD_STP currXdAttribStp = this->ddlGenEntityPtr->getXdAttrib(i);

                if (GET_FLAG(currXdAttribStp, A_XdAttrib_PrecompFlg) == TRUE)
                {
                    if (GET_A_XdAttrib_FeatureEn(currXdAttribStp) != XdEntityFeatureFeatureEn::None)
                    {
                        SET_ENUM(currXdAttribStp, A_XdAttrib_XdActionEn, XdAction_ToInsert);
                    }
                    else
                    {
                        SET_ENUM(currXdAttribStp, A_XdAttrib_XdActionEn, XdAction_ToPhysicallyDelete);
                    }
                }
            }

            DdlGenConnGuard     ddlGenConnGuard(*this->ddlGenContextPtr);
            DbiConnectionHelper dbiConnHelper(&ddlGenConnGuard.getDbiConn(), false);

            INT_T attribProgN = PROG_N_START_PRECOMP;

            DICT_T xdAttribDictId = 0;

            DBA_GetDictId(XdAttrib, &xdAttribDictId);

            DICT_LANG_STP             enDictLangStp = nullptr;
            std::vector<DICT_LANG_ST> dictLangTab = DBA_GetDictLangTab();
            for (auto &it : dictLangTab)
            {
                if (strcmp(it.code, "en") == 0)
                {
                    enDictLangStp = &it;
                    break;
                }
            }

            for (auto &extFmtEltStp : this->ddlGenEntityPtr->m_extFmtEltVector)
            {
                string           sqlName      = GET_SYSNAME(extFmtEltStp, A_FmtElt_SqlName);
                DBA_DYNFLD_STP   newAttribStp = this->ddlGenEntityPtr->getXdAttribBySqlName(sqlName);

                if (newAttribStp == nullptr)
                {
                    newAttribStp = this->m_mp.allocDynst(FILEINFO, A_XdAttrib);
                }

                if ((ret = DBA_CreateXdAttribFromFmtElt(dbiConnHelper, extFmtEltStp, newAttribStp, nullptr, xdEntityStp, attribProgN, InsUpd)) == RET_SUCCEED)
                {
                    DBA_DYNFLD_STP  dbAttribStp = this->ddlGenEntityPtr->getDbXdAttribBySqlName(sqlName);

                    SET_FLAG_TRUE(newAttribStp, A_XdAttrib_PrecompFlg);
                    SET_ENUM(newAttribStp, A_XdAttrib_XdActionEn, XdAction_ToInsert);
                    SET_ENUM(newAttribStp, A_XdAttrib_TascViewEn, 1);

                    if (dbAttribStp != nullptr)
                    {
                        COPY_DYNFLD(newAttribStp, A_XdAttrib, A_XdAttrib_Id, dbAttribStp, A_XdAttrib, A_XdAttrib_Id);
                        COPY_DYNFLD(newAttribStp, A_XdAttrib, A_XdAttrib_AttribDictId, dbAttribStp, A_XdAttrib, A_XdAttrib_AttribDictId);
                        COPY_DYNFLD(newAttribStp, A_XdAttrib, A_XdAttrib_XdStatusEn, dbAttribStp, A_XdAttrib, A_XdAttrib_XdStatusEn);
                    }
                    else
                    {
                        SET_NULL_ID(newAttribStp, A_XdAttrib_Id);
                        SET_NULL_DICT(newAttribStp, A_XdAttrib_AttribDictId);
                        SET_ENUM(newAttribStp, A_XdAttrib_XdStatusEn, XdStatus_Untreated);

                        requestHelper.dbaCall(Insert,
                                              XdAttrib,
                                              DBA_ROLE_UDT,
                                              newAttribStp);

                        this->ddlGenEntityPtr->addXdAttribInTab(newAttribStp);
                        this->m_mp.removeDynStp(newAttribStp);
                    }

                    auto denomVector = this->ddlGenEntityPtr->m_extFmtEltDenomMap.find(GET_ID(extFmtEltStp, A_FmtElt_Id));
                    if (denomVector != this->ddlGenEntityPtr->m_extFmtEltDenomMap.end())
                    {
                        for (auto &denomIt : denomVector->second)
                        {
                            DBA_DYNFLD_STP xdLabelStp = requestHelper.allocDynSt(FILEINFO, A_XdLabel);

                            DBA_SetDfltEntityFld(XdLabel, A_XdLabel, xdLabelStp);

                            SET_DICT(xdLabelStp, A_XdLabel_EntityDictId, xdAttribDictId);
                            COPY_DYNFLD(xdLabelStp, A_XdLabel, A_XdLabel_LangDictId, denomIt, A_Denom, A_Denom_LangEntDictId);
                            COPY_DYNFLD(xdLabelStp, A_XdLabel, A_XdLabel_Name, denomIt, A_Denom, A_Denom_Denom);
                            SET_ENUM(xdLabelStp, A_XdLabel_XdActionEn, XdAction_ToInsert);
                            SET_ENUM(xdLabelStp, A_XdLabel_XdStatusEn, XdStatus_Untreated);
                            SET_ID(xdLabelStp, A_XdLabel_ObjId, GET_ID(newAttribStp, A_XdAttrib_Id));

                            requestHelper.dbaCall(Insert,
                                                  XdLabel,
                                                  UNUSED,
                                                  xdLabelStp);

                            if (enDictLangStp != nullptr &&
                                enDictLangStp->dictId == GET_DICT(xdLabelStp, A_XdLabel_LangDictId) &&
                                IS_NULLFLD(xdLabelStp, A_XdLabel_Name) == false)
                            {
                                if (IS_STRINGFLD(A_XdLabel, A_XdLabel_Name) == TRUE)
                                {
                                    SET_NAME(newAttribStp, A_XdAttrib_Name, GET_STRING(xdLabelStp, A_XdLabel_Name));
                                }
                                else
                                {
                                    char* ptr = NULL;
                                    ICU4AAA_ConvertToDefaultCharSet(GET_USTRING(xdLabelStp, A_XdLabel_Name), -1, &ptr, NULL);
                                    SET_NAME(newAttribStp, A_XdAttrib_Name, ptr);
                                    FREE(ptr);
                                }

                                DBA_TruncateStringToMDLength(newAttribStp, A_XdAttrib_Name);
                            }
                        }
                    }
                }
            }
        }
        else if (this->bExtTableToDo)
        {
            for (int i = 0; i < this->ddlGenEntityPtr->getXdAttribNbr(); i++)
            {
                auto currXdAttribStp = this->ddlGenEntityPtr->getXdAttrib(i);

                if (this->ddlGenContextPtr->ddlGenAction.m_mainDdlObjNatEn == DbObjDdlObjNat_TslExtension &&
                    GET_FLAG(currXdAttribStp, A_XdAttrib_PrecompFlg) == TRUE &&
                    GET_A_XdAttrib_FeatureEn(currXdAttribStp) == XdEntityFeatureFeatureEn::None)
                {
                    SET_ENUM(currXdAttribStp, A_XdAttrib_XdActionEn, XdAction_ToPhysicallyDelete);
                }
            }
        }
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenFullTable::managePartitions()
**
**  Description :  Manage partitions definition
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13109 - LJE - 110311
**
*************************************************************************/
RET_CODE DdlGenFullTable::managePartitions(DdlGenRequestHelper& requestHelper)
{
    RET_CODE          ret = RET_SUCCEED;
    DBA_DYNFLD_STP    xdEntityStp = this->getXdEntityStp();
    bool              bMesiPartitioned = this->bTableToDo == true ? this->ddlGenEntityPtr->isMesiPartitioned() : false;

    if (this->bTableToDo == false ||
        (GET_ENUM(xdEntityStp, A_XdEntity_PartAuthEn) != FeatureAuth_Enable && bMesiPartitioned == false))
    {
        return ret;
    }

    int                    partitionNbr = this->ddlGenEntityPtr->getXdPartitionNbr();
    DBA_DYNFLD_STP* partitionTab = this->ddlGenEntityPtr->getXdPartitionTab();
    bool                   bUseTemplatePartition = true;
    MemoryPool             mp;

    for (int i = 0; i < partitionNbr; i++)
    {
        if (GET_ENUM(partitionTab[i], A_XdPartition_XdActionEn) == XdAction_ToInsert)
        {
            bUseTemplatePartition = false;
            break;
        }
    }

    DdlGenEntity* tplDdlGenEntityPtr = nullptr;

    if (bUseTemplatePartition)
    {
        tplDdlGenEntityPtr = this->ddlGenContextPtr->getTemplateDdlGenEntityPtr();

        if (tplDdlGenEntityPtr == nullptr)
        {
            return RET_DBA_ERR_MD;
        }

        DBA_DYNFLD_STP* tplXdPartionTab = tplDdlGenEntityPtr->getXdPartitionTab();
        int             tplXdPartionPos, tplXdPartionNbr = tplDdlGenEntityPtr->getXdPartitionNbr();

        /* PMSTA-34418 - LJE - 190130 */
        if (bMesiPartitioned)
        {
            DdlGen          ddlGen(this->objectEn, DdlObj_None, *this->ddlGenContextPtr, NULL, this->ddlGenEntityPtr, NULL, TargetTable_Main);
            string          tableSegment, idxSegment;
            DICT_ENTITY_STP beDictEntityStp = DBA_GetDictEntitySt(BusEntity);

            SET_ENUM(xdEntityStp, A_XdEntity_PartAuthEn, FeatureAuth_Enable);

            for (auto it = this->ddlGenContextPtr->getCfgFileHelper().segSectionMap.begin(); it != this->ddlGenContextPtr->getCfgFileHelper().segSectionMap.end(); ++it)
            {
                if (IS_NULLFLD(xdEntityStp, A_XdEntity_Segment) == TRUE)
                {
                    string msg = "Unknown segment/tablespace";
                    ret = RET_DBA_ERR_MD;
                    this->printMsg(ret, msg);
                }
                else if (strcmp(GET_SYSNAME(xdEntityStp, A_XdEntity_Segment), it->second.segSqlName.c_str()) == 0)
                {
                    tableSegment = it->second.segFct;
                }
                else if (GET_DICT(xdEntityStp, A_XdEntity_IdxSegmentDictId) == it->second.segDictId)
                {
                    idxSegment = it->second.segFct;
                }

                if (tableSegment.empty() == false && idxSegment.empty() == false)
                {
                    break;
                }
            }

            if (tableSegment.empty())
            {
                string msg = "Unknown table segment/tablespace : ";
                ret = RET_DBA_ERR_MD;
                this->printMsg(ret, msg + GET_SYSNAME(xdEntityStp, A_XdEntity_Segment));
            }
            if (idxSegment.empty())
            {
                idxSegment = tableSegment;
            }

            string masterBusinessEntityCd = this->ddlGenContextPtr->getMasterBusinessEntityCd();

            if (this->ddlGenContextPtr->allBusinessEntityIdSet.empty())
            {
                bool bMasterDefined = false;
                for (auto it = this->ddlGenContextPtr->getCfgFileHelper().mesiSectionMap.begin(); it != this->ddlGenContextPtr->getCfgFileHelper().mesiSectionMap.end(); ++it)
                {
                    if (masterBusinessEntityCd.compare(it->second.beCode) == 0)
                    {
                        bMasterDefined = true;
                        break;
                    }
                }
                if (bMasterDefined == false)
                {
                    CFG_MESI_SECTION_ST mesiSectionSt;

                    mesiSectionSt.beId = 0;
                    mesiSectionSt.beCode = masterBusinessEntityCd;
                    mesiSectionSt.beShortName = "MASTER";

                    this->ddlGenContextPtr->getCfgFileHelper().mesiSectionMap.insert(pair<string, CFG_MESI_SECTION_ST>(mesiSectionSt.beCode, mesiSectionSt));
                }

                for (auto it = this->ddlGenContextPtr->getCfgFileHelper().mesiSectionMap.begin(); it != this->ddlGenContextPtr->getCfgFileHelper().mesiSectionMap.end(); ++it)
                {
                    if (it->second.beId == 0)
                    {
                        it->second.beId = ddlGen.getIdByBk(beDictEntityStp, it->second.beCode);
                        stringstream locStream;
                        locStream << it->second.beId;
                        it->second.beIdStr = locStream.str();
                    }
                }

                ddlGen.getIdsByQuery(beDictEntityStp, "multi_entity_role_e > 0", this->ddlGenContextPtr->allBusinessEntityIdSet);
            }

            SMALLINT_T      mesiXdPartionNbr = static_cast<SMALLINT_T>(this->ddlGenContextPtr->getCfgFileHelper().mesiSectionMap.size());
            DBA_DYNFLD_STP* mesiXdPartionTab = static_cast<DBA_DYNFLD_STP*>(mp.calloc(mesiXdPartionNbr, sizeof(DBA_DYNFLD_STP)));
            SMALLINT_T      rank = 0;
            SMALLINT_T      mesiXdPartionPos = 0;

            for (auto it = this->ddlGenContextPtr->getCfgFileHelper().mesiSectionMap.begin(); it != this->ddlGenContextPtr->getCfgFileHelper().mesiSectionMap.end(); ++it)
            {
                DBA_DYNFLD_STP  mesiPartionStp = requestHelper.allocDynSt(FILEINFO, A_XdPartition);

                COPY_DYNST(mesiPartionStp, tplXdPartionTab[0], A_XdPartition);
                SET_SYSNAME(mesiPartionStp, A_XdPartition_SqlName, it->second.beShortName.c_str());

                if (it->second.beCode.compare(masterBusinessEntityCd) == 0)
                {
                    SET_DICT(mesiPartionStp, A_XdPartition_SegmentDictId, GET_DICT(xdEntityStp, A_XdEntity_SegmentDictId));
                    SET_SYSNAME(mesiPartionStp, A_XdPartition_Segment, GET_SYSNAME(xdEntityStp, A_XdEntity_Segment));
                    SET_DICT(mesiPartionStp, A_XdPartition_IdxSegmentDictId, GET_DICT(xdEntityStp, A_XdEntity_IdxSegmentDictId));

                    auto idxSegIter = this->ddlGenContextPtr->getCfgFileHelper().segSectionMap.find(idxSegment);
                    if (idxSegIter != this->ddlGenContextPtr->getCfgFileHelper().segSectionMap.end())
                    {
                        SET_SYSNAME(mesiPartionStp, A_XdPartition_IdxSegment, idxSegIter->second.segSqlName.c_str());
                    }

                    if (this->ddlGenDbi.isDefaultInListPartition())
                    {
                        SET_STRING(mesiPartionStp, A_XdPartition_Expression, "default");
                    }
                    else
                    {
                        std::set<ID_T> beIdSet = this->ddlGenContextPtr->allBusinessEntityIdSet;
                        for (auto it2 = this->ddlGenContextPtr->getCfgFileHelper().mesiSectionMap.begin(); it2 != this->ddlGenContextPtr->getCfgFileHelper().mesiSectionMap.end(); ++it2)
                        {
                            if (it2->second.beCode.compare(it->second.beCode) != 0)
                            {
                                beIdSet.erase(it2->second.beId);
                            }
                        }
                        stringstream idsStream;
                        for (auto it2 = beIdSet.begin(); it2 != beIdSet.end(); ++it2)
                        {
                            if (idsStream.str().empty() == false)
                            {
                                idsStream << ", ";
                            }
                            idsStream << *it2;
                        }

                        SET_STRING(mesiPartionStp, A_XdPartition_Expression, idsStream.str().c_str());
                    }
                    SET_SMALLINT(mesiPartionStp, A_XdPartition_Rank, mesiXdPartionNbr);
                }
                else
                {
                    string tblMesiSeg = tableSegment + "_" + it->second.beShortName;
                    auto tblSegIter = this->ddlGenContextPtr->getCfgFileHelper().segSectionMap.find(tblMesiSeg);
                    if (tblSegIter == this->ddlGenContextPtr->getCfgFileHelper().segSectionMap.end())
                    {
                        ret = RET_DBA_ERR_MD;
                        this->printMsg(ret, "Unknown table segment/tablespace : " + tblMesiSeg);
                    }

                    string idxMesiSeg = idxSegment + "_" + it->second.beShortName;
                    auto idxSegIter = this->ddlGenContextPtr->getCfgFileHelper().segSectionMap.find(idxMesiSeg);
                    if (idxSegIter == this->ddlGenContextPtr->getCfgFileHelper().segSectionMap.end())
                    {
                        ret = RET_DBA_ERR_MD;
                        this->printMsg(ret, "Unknown index segment/tablespace : " + idxMesiSeg);
                    }
                    if (it->second.beIdStr.empty())
                    {
                        ret = RET_DBA_ERR_MD;
                        this->printMsg(ret, "Unknown Business Entity having code: " + it->second.beCode);
                        it->second.beId = 1;
                    }

                    if (ret == RET_SUCCEED)
                    {
                        SET_DICT(mesiPartionStp, A_XdPartition_SegmentDictId, tblSegIter->second.segDictId);
                        SET_SYSNAME(mesiPartionStp, A_XdPartition_Segment, tblSegIter->second.segSqlName.c_str());
                        SET_DICT(mesiPartionStp, A_XdPartition_IdxSegmentDictId, idxSegIter->second.segDictId);
                        SET_SYSNAME(mesiPartionStp, A_XdPartition_IdxSegment, idxSegIter->second.segSqlName.c_str());
                        SET_STRING(mesiPartionStp, A_XdPartition_Expression, it->second.beIdStr.c_str());
                        SET_SMALLINT(mesiPartionStp, A_XdPartition_Rank, ++rank);
                    }
                }

                if (ret == RET_SUCCEED)
                {
                    mesiXdPartionTab[mesiXdPartionPos++] = mesiPartionStp;
                }
            }

            if (ret == RET_SUCCEED && mesiXdPartionNbr != mesiXdPartionPos)
            {
                ret = RET_DBA_ERR_MD;
                this->printMsg(ret, "Some Business Entities doesn't have segment/tablespace partition definition");
            }

            if (ret == RET_SUCCEED)
            {
                tplXdPartionNbr = mesiXdPartionNbr;
                tplXdPartionTab = mesiXdPartionTab;
            }
            else
            {
                this->printMsg(ret, "MESI partitioning cannot be done!, please fix the file $AAAHOME/install/aaa_install.cfg!");
                tplXdPartionNbr = 0;
                tplXdPartionTab = nullptr;
            }
        }

        for (tplXdPartionPos = 0; tplXdPartionPos < tplXdPartionNbr; tplXdPartionPos++)
        {
            if (strcmp(GET_SYSNAME(tplXdPartionTab[tplXdPartionPos], A_XdPartition_SqlName), "business_entity") == 0)
            {
                continue;
            }

            DBA_DYNFLD_STP currXdPartitionStp = this->ddlGenEntityPtr->getXdPartitionBySqlName(tplXdPartionTab[tplXdPartionPos]);
            if (currXdPartitionStp == nullptr)
            {
                this->ddlGenEntityPtr->addXdPartition(requestHelper, tplXdPartionTab[tplXdPartionPos], tplDdlGenEntityPtr);
            }
            else
            {
                this->copyDynFld(currXdPartitionStp, A_XdPartition_PartTypeEn, tplXdPartionTab[tplXdPartionPos], A_XdPartition_PartTypeEn);
                this->copyDynFld(currXdPartitionStp, A_XdPartition_Rank, tplXdPartionTab[tplXdPartionPos], A_XdPartition_Rank);
                this->copyDynFld(currXdPartitionStp, A_XdPartition_ParentXdPartitionId, tplXdPartionTab[tplXdPartionPos], A_XdPartition_ParentXdPartitionId);
                this->copyDynFld(currXdPartitionStp, A_XdPartition_Expression, tplXdPartionTab[tplXdPartionPos], A_XdPartition_Expression);
                this->copyDynFld(currXdPartitionStp, A_XdPartition_XdAttrib1Id, tplXdPartionTab[tplXdPartionPos], A_XdPartition_XdAttrib1Id);
                this->copyDynFld(currXdPartitionStp, A_XdPartition_XdAttrib2Id, tplXdPartionTab[tplXdPartionPos], A_XdPartition_XdAttrib2Id);
                /* PMSTA-34418 - LJE - 190131 */
                this->copyDynFld(currXdPartitionStp, A_XdPartition_SegmentDictId, tplXdPartionTab[tplXdPartionPos], A_XdPartition_SegmentDictId);
                this->copyDynFld(currXdPartitionStp, A_XdPartition_Segment, tplXdPartionTab[tplXdPartionPos], A_XdPartition_Segment);
                this->copyDynFld(currXdPartitionStp, A_XdPartition_IdxSegmentDictId, tplXdPartionTab[tplXdPartionPos], A_XdPartition_IdxSegmentDictId);
                this->copyDynFld(currXdPartitionStp, A_XdPartition_IdxSegment, tplXdPartionTab[tplXdPartionPos], A_XdPartition_IdxSegment);
                SET_ENUM(currXdPartitionStp, A_XdPartition_XdActionEn, XdAction_ToInsert);
            }
        }
        this->ddlGenEntityPtr->sortPartitions();

        DBA_DYNFLD_STP* tplXdPartionIndexTab = tplDdlGenEntityPtr->getXdPartitionIndexTab();
        int             tplXdPartionIndexPos, tplXdPartionIndexNbr = tplDdlGenEntityPtr->getXdPartitionIndexNbr();

        for (tplXdPartionIndexPos = 0; tplXdPartionIndexPos < tplXdPartionIndexNbr; tplXdPartionIndexPos++)
        {
            DBA_DYNFLD_STP newXdPartitionIndex = ALLOC_DYNST(A_XdPartitionIndex);

            if (newXdPartitionIndex)
            {
                COPY_DYNST(newXdPartitionIndex, tplXdPartionIndexTab[tplXdPartionIndexPos], A_XdPartitionIndex);

                this->ddlGenEntityPtr->addXdPartitionIndexInTab(newXdPartitionIndex);
            }
        }

        partitionNbr = this->ddlGenEntityPtr->getXdPartitionNbr();
        partitionTab = this->ddlGenEntityPtr->getXdPartitionTab();
    }

    bool bValidPartition = false;
    for (int i = 0; i < partitionNbr; i++)
    {
        if (GET_ENUM(partitionTab[i], A_XdPartition_XdActionEn) == XdAction_ToInsert)
        {
            bValidPartition = true;
        }

        if (IS_NULLFLD(partitionTab[i], A_XdPartition_Segment) == TRUE ||
            IS_NULLFLD(partitionTab[i], A_XdPartition_Expression) == TRUE)
        {
            string msg = "Invalid partition definition: ";
            msg += GET_SYSNAME(partitionTab[i], A_XdPartition_SqlName);
            ret = RET_DBA_ERR_MD;
            this->printMsg(ret, msg);
        }
    }

    if (bValidPartition == false || ret != RET_SUCCEED)
    {
        SET_ENUM(xdEntityStp, A_XdEntity_PartAuthEn, FeatureAuth_Disable);
    }
    else
    {
        for (int i = 0; i < partitionNbr; i++)
        {
            DBA_DYNFLD_STP partAttrib1Stp = this->ddlGenEntityPtr->fixTemplateAttributeId(partitionTab[i], A_XdPartition_XdAttrib1Id);
            if (partAttrib1Stp)
            {
                SET_ENUM(partAttrib1Stp, A_XdAttrib_CalcEn, DictAttr_PhysicalPartition);
            }

            DBA_DYNFLD_STP partAttrib2Stp = this->ddlGenEntityPtr->fixTemplateAttributeId(partitionTab[i], A_XdPartition_XdAttrib2Id);
            if (partAttrib2Stp)
            {
                SET_ENUM(partAttrib2Stp, A_XdAttrib_CalcEn, DictAttr_PhysicalPartition);
            }
        }
    }
    this->m_dictEntityStp->partAuthEn = static_cast<FEATURE_AUTH_ENUM>(GET_ENUM(xdEntityStp, A_XdEntity_PartAuthEn));

    return ret;
}

/************************************************************************
**  Function             : DdlGenFullTable::isSecuDictCriteria()
**
**  Description          : Manage dict_criteria table
**
**  Arguments            : none
**
**  Return               : none
**
**  Last modif           : PMSTA-13122 - LJE - 120430
**
*************************************************************************/
bool DdlGenFullTable::isSecuDictCriteria(int xdAttrPos)
{
    DBA_DYNFLD_STP currXdAttribStp = this->ddlGenEntityPtr->getXdAttrib(xdAttrPos);

    /* PMSTA-29879 - LJE - 180208 */
    if (GET_A_XdAttrib_FeatureEn(currXdAttribStp) == XdEntityFeatureFeatureEn::AccessRightManagement ||
        GET_A_XdAttrib_FeatureEn(currXdAttribStp) == XdEntityFeatureFeatureEn::Security)
    {
        return true;
    }
    else
    {
        return false;
    }
}

/************************************************************************
**  Function             : DdlGenFullTable::isShortDictCriteria()
**
**  Description          : Manage dict_criteria table
**
**  Arguments            : none
**
**  Return               : none
**
**  Last modif           : PMSTA-13122 - LJE - 120430
**						   PMSTA-23096 - EFE - 160503 : migration from 10.0.01-> 20.0.01
**							   added restrictions that were before in checkShortIndex
*************************************************************************/
bool DdlGenFullTable::isShortDictCriteria(int xdAttrPos)
{
    if (this->bShortToDo == false)
    {
        return false;
    }

    DBA_DYNFLD_STP currXdAttribStp = this->ddlGenEntityPtr->getXdAttrib(xdAttrPos);

    if (GET_FLAG(currXdAttribStp, A_XdAttrib_LogicalFlg) == TRUE ||
        GET_ENUM(currXdAttribStp, A_XdAttrib_CalcEn) == DictAttr_Virtual ||
        GET_ENUM(currXdAttribStp, A_XdAttrib_CustomFlg) != Custom_No ||
        GET_FLAG(currXdAttribStp, A_XdAttrib_PrecompFlg) == TRUE
        )
    {
        return false;
    }

    if (GET_FLAG(currXdAttribStp, A_XdAttrib_PrimaryFlg) == TRUE ||
        GET_FLAG(currXdAttribStp, A_XdAttrib_BusKeyFlg) == TRUE ||
        IS_NULLFLD(currXdAttribStp, A_XdAttrib_ShortIdx) == FALSE ||
        this->isSecuDictCriteria(xdAttrPos) ||
        strcmp(GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName), "name") == 0)
    {
        return true;
    }
    else
    {
        return false;
    }
}

/************************************************************************
**  Function             : DdlGenFullTable::isAllDictCriteria()
**
**  Description          : Manage dict_criteria table
**
**  Arguments            : none
**
**  Return               : none
**
**  Last modif           : PMSTA-13122 - LJE - 120430
**
*************************************************************************/
bool DdlGenFullTable::isAllDictCriteria(int xdAttrPos)
{
    DBA_DYNFLD_STP currXdAttribStp = this->ddlGenEntityPtr->getXdAttrib(xdAttrPos);

    if (GET_FLAG(currXdAttribStp, A_XdAttrib_LogicalFlg) == TRUE ||
        GET_FLAG(currXdAttribStp, A_XdAttrib_PrecompFlg) == TRUE ||
        GET_ENUM(currXdAttribStp, A_XdAttrib_CustomFlg) != Custom_No ||
        GET_ENUM(currXdAttribStp, A_XdAttrib_CalcEn) == DictAttr_Virtual ||
        GET_FLAG(currXdAttribStp, A_XdAttrib_ShortOnlyFlg) == TRUE)
    {
        return false;
    }

    if (GET_ENUM(currXdAttribStp, A_XdAttrib_CalcEn) == DictAttr_Denorm ||
        GET_A_XdAttrib_FeatureEn(currXdAttribStp) == XdEntityFeatureFeatureEn::AccessRightManagement) /* PMSTA-29879 - LJE - 180710 */
    {
        return true;
    }
    else
    {
        return false;
    }
}

/************************************************************************
**  Function             : DdlGenFullTable::getShortAttribSqlName()
**
**  Description          :
**
**  Arguments            :
**
**  Return               : none
**
**  Last modif           : PMSTA-36158 - LJE - 190627
**
*************************************************************************/
void  DdlGenFullTable::getShortAttribSqlName(std::string& attribSqlName, DICT_ATTRIB_STP dictAttribStp)
{
    attribSqlName = dictAttribStp->sqlName;
    if (attribSqlName.length() > 3 && attribSqlName.substr(attribSqlName.length() - 3).compare("_id") == 0)
    {
        attribSqlName.erase(attribSqlName.length() - 3);
    }
    if (attribSqlName.length() > 5 && attribSqlName.substr(attribSqlName.length() - 3).compare("_dict") == 0)
    {
        attribSqlName.erase(attribSqlName.length() - 5);
    }
}

/************************************************************************
**  Function             : DdlGenFullTable::getShortAttribSqlName()
**
**  Description          :
**
**  Arguments            :
**
**  Return               : none
**
**  Last modif           : PMSTA-36158 - LJE - 190627
**
*************************************************************************/
void  DdlGenFullTable::addBkDictCriteria(DBA_DYNFLD_STP currXdAttribStp, DICT_CRITER_ST& parentCriteriaSt, SMALLINT_T& criterPos, SMALLINT_T& shRank, SMALLINT_T& index)
{
    DBA_DYNFLD_STP   xdEntityStp = this->getXdEntityStp();

    if (CMP_DYNFLD(xdEntityStp, currXdAttribStp, A_XdEntity_ParentXdAttribId, A_XdAttrib_Id, IdType) != 0 &&
        (GET_FLAG(currXdAttribStp, A_XdAttrib_BusKeyFlg) == TRUE || GET_FLAG(currXdAttribStp, A_XdAttrib_CustoShortIdxFlg) == TRUE) &&
        GET_MASK(currXdAttribStp, A_XdAttrib_SubTpMask) != 0)
    {
        if (IS_NULLFLD(currXdAttribStp, A_XdAttrib_RefXdEntityId) == FALSE)
        {
            OBJECT_ENUM      refObjEn;

            DICT_ENTITY_STP   refDictEntityStp;
            INT_T             joinRank = parentCriteriaSt.progN;

            string refSqlName;
            this->getShortAttribSqlName(refSqlName, parentCriteriaSt.attrPtr);
            refSqlName += "_";

            DBA_GetObjectEnum(this->m_dictEntityStp->attr[GET_INT(currXdAttribStp, A_XdAttrib_Prog)]->refEntDictId, &refObjEn);
            if (refObjEn != NullEntity &&
                (refDictEntityStp = DBA_GetDictEntitySt(refObjEn)) != NULL)
            {
                for (int j = 0; j < refDictEntityStp->bkAttrNbr; j++)
                {
                    DICT_CRITER_STP refCriteriaStp = this->m_dictEntityStp->addDictCriteria(DynType_Short, shRank++);

                    parentCriteriaSt.bkDictCriteriaVector.push_back(refCriteriaStp);

                    refCriteriaStp->attrEntObj         = refObjEn;
                    refCriteriaStp->attrPtr            = refDictEntityStp->bkAttr[j];
                    refCriteriaStp->attrDictId         = refCriteriaStp->attrPtr->attrDictId;
                    refCriteriaStp->entAttrPtr         = nullptr;
                    refCriteriaStp->parent1ProgN       = (SMALLINT_T)joinRank;
                    refCriteriaStp->parentCriteria1Stp = &parentCriteriaSt;
                    refCriteriaStp->isNullParent1ProgN = false;
                    refCriteriaStp->index              = index++;
                    refCriteriaStp->isNullIndex        = false;

                    if (parentCriteriaSt.isNullFkIndex == false)
                    {
                        refCriteriaStp->fkIndex = (TINYINT_T)index;
                        refCriteriaStp->isNullFkIndex = false;
                    }

                    if (j == 0)
                    {
                        refCriteriaStp->labelAttribDictId = parentCriteriaSt.attrPtr->attrDictId;                 /* PMSTA-36158 - LJE - 190627 */
                        refCriteriaStp->SET_dcLabel(parentCriteriaSt.attrPtr->GET_daLabel());
                        refCriteriaStp->SET_dcUniLabel(parentCriteriaSt.attrPtr->GET_daUniLabel());
                        strcpy(refCriteriaStp->name, parentCriteriaSt.attrPtr->name);
                    }
                    else
                    {
                        refCriteriaStp->labelAttribDictId = refCriteriaStp->attrPtr->attrDictId;                 /* PMSTA-36158 - LJE - 190627 */
                        refCriteriaStp->SET_dcLabel(refCriteriaStp->attrPtr->GET_daLabel());
                        refCriteriaStp->SET_dcUniLabel(refCriteriaStp->attrPtr->GET_daUniLabel());
                        strcpy(refCriteriaStp->name, refCriteriaStp->attrPtr->name);
                    }

                    string bkSqlName;
                    this->getShortAttribSqlName(bkSqlName, refCriteriaStp->attrPtr);

                    string fullSqlName = refSqlName + refCriteriaStp->attrPtr->sqlName;

                    if (fullSqlName.length() > SYSNAME_T_LEN)
                    {
                        fullSqlName = refSqlName + SYS_ToString(refCriteriaStp->attrPtr->progBkN);
                    }

                    strcpy(refCriteriaStp->sqlName, fullSqlName.c_str());

                    criterPos++;

                    if (refDictEntityStp->objectEn == Tp)
                    {
                        break;
                    }
                }

                parentCriteriaSt.index         = 255;
                parentCriteriaSt.isNullIndex   = true;
                parentCriteriaSt.fkIndex       = 255;
                parentCriteriaSt.isNullFkIndex = true;
            }
        }
        else if ((GET_FLAG(currXdAttribStp, A_XdAttrib_PrimaryFlg) == FALSE || this->m_dictEntityStp->pkRuleEn != PkRule_Identity))
        {
            parentCriteriaSt.index = index++;
            parentCriteriaSt.isNullIndex = false;

            parentCriteriaSt.fkIndex = (TINYINT_T)index;
            parentCriteriaSt.isNullFkIndex = false;
        }
    }
}

/************************************************************************
**  Function             : DdlGenFullTable::createDictCriteria()
**
**  Description          : Manage dict_criteria table
**
**  Arguments            : none
**
**  Return               : none
**
**  Last modif           : PMSTA-13122 - LJE - 120430
**
*************************************************************************/
RET_CODE DdlGenFullTable::createDictCriteria(DdlGenRequestHelper& requestHelper)
{
    RET_CODE         ret = RET_SUCCEED;
    DBA_DYNFLD_STP   xdEntityStp = this->getXdEntityStp();

    int              i,
        fullInfoCriterNbr = 0,
        shortInfoCriterNbr = 0,
        allInfoCriterNbr = 0;
    SMALLINT_T       criterPos, shRank;
    DICT_T           criteriaDictId, entityDictId, attributeDictId;
    int              passNbr = 0;

    MemoryPool       mp;

    DBA_GetDictId(DictCriter, &criteriaDictId);
    DBA_GetDictId(DictEntity, &entityDictId);
    DBA_GetDictId(DictAttr, &attributeDictId);

    auto admArgStp = requestHelper.allocDynSt(FILEINFO, Adm_Arg);

    SET_DICT(admArgStp, Adm_Arg_EntDictId, this->m_dictEntityStp->entDictId);

    /* Delete old dict_criteria for the current entity */
    if (this->m_dictEntityStp->entDictId > 0 &&
        (ret = requestHelper.dbaCall(Delete,
                                     DictCriter,
                                     UNUSED,
                                     admArgStp)) != RET_SUCCEED)
    {
        requestHelper.sendAllMsg();

        MSG_SendMesg(RET_DBA_ERR_DELETE_FAILED, 0, FILEINFO);
        this->printMsgData(RET_DBA_ERR_DELETE_FAILED, admArgStp);
        return ret;
    }

    this->m_dictEntityStp->shortDictCriteriaMap.clear();
    this->m_dictEntityStp->allDictCriteriaMap.clear();

    if (GET_ENUM(xdEntityStp, A_XdEntity_XdActionEn) != XdAction_ToInsert &&
        this->m_dictEntityStp->xdStatusEn != XdStatus_Inserted)
    {
        return ret;
    }

    shRank = 0;

    /* Create the new dict_criteria according the definition */
    for (i = 0; i < this->ddlGenEntityPtr->getXdAttribNbr(); i++)
    {
        DBA_DYNFLD_STP currXdAttribStp = this->ddlGenEntityPtr->getXdAttrib(i);

        if ((this->bShortToDo || GET_FLAG(currXdAttribStp, A_XdAttrib_CustoShortIdxFlg) == TRUE) && 
            IS_NULLFLD(currXdAttribStp, A_XdAttrib_ShortIdx) == FALSE)
        {
            fullInfoCriterNbr++;
            shortInfoCriterNbr++;
            shRank++;

            if (CMP_DYNFLD(xdEntityStp, currXdAttribStp, A_XdEntity_ParentXdAttribId, A_XdAttrib_Id, IdType) != 0 &&
                GET_FLAG(currXdAttribStp, A_XdAttrib_BusKeyFlg) == TRUE &&
                GET_MASK(currXdAttribStp, A_XdAttrib_SubTpMask) != 0 &&
                IS_NULLFLD(currXdAttribStp, A_XdAttrib_RefXdEntityId) == FALSE)
            {
                DICT_ENTITY_STP   refDictEntityStp;
                OBJECT_ENUM      refObjEn = NullEntity;

                DBA_GetObjectEnum(this->m_dictEntityStp->attr[GET_INT(currXdAttribStp, A_XdAttrib_Prog)]->refEntDictId, &refObjEn);
                if (refObjEn != NullEntity &&
                    (refDictEntityStp = DBA_GetDictEntitySt(refObjEn)) != NULL)
                {
                    if (refObjEn == Tp)
                    {
                        fullInfoCriterNbr++;
                        shortInfoCriterNbr++;
                    }
                    else
                    {
                        fullInfoCriterNbr += refDictEntityStp->bkAttrNbr;
                        shortInfoCriterNbr += refDictEntityStp->bkAttrNbr;
                    }
                }
            }
        }
        else if (this->bShortToDo == false && IS_NULLFLD(currXdAttribStp, A_XdAttrib_ShortIdx) == FALSE)
        {
            fullInfoCriterNbr++;
            shortInfoCriterNbr++;
            shRank++;
        }

        if (this->isAllDictCriteria(i))
        {
            fullInfoCriterNbr++;
            allInfoCriterNbr++;
        }
    }

    assert((allInfoCriterNbr + shortInfoCriterNbr) == fullInfoCriterNbr);

    DBA_DYNFLD_STP* xdAttribByIdTab = this->ddlGenEntityPtr->getSortedXdAttribTab((TLS_CMPFCT*)DDL_CmpXdAttribById);
    mp.ownerPtr(xdAttribByIdTab);

    criterPos = 0;

    if (this->bShortToDo)
    {
        SMALLINT_T       index = 0;
        for (i = 0; i < this->ddlGenEntityPtr->getXdAttribNbr(); i++)
        {
            DBA_DYNFLD_STP  currXdAttribStp = this->ddlGenEntityPtr->getXdAttrib(i);

            if (IS_NULLFLD(currXdAttribStp, A_XdAttrib_ShortIdx) == FALSE)
            {
                DICT_ATTRIB_STP attrPtr = this->m_dictEntityStp->attr[i];
                DICT_CRITER_STP criteriaStp = this->m_dictEntityStp->addDictCriteria(DynType_Short, attrPtr->shortIdx);
                criteriaStp->attrPtr = attrPtr;
                criteriaStp->entAttrPtr = attrPtr;
                criteriaStp->attrPtr->isNullShortIdx = false;
                criterPos++;

                this->addBkDictCriteria(currXdAttribStp, *criteriaStp, criterPos, shRank, index);

                if (IS_NULLFLD(currXdAttribStp, A_XdAttrib_Join1XdAttribId) == TRUE)
                {
                    criteriaStp->parent1ProgN = 0;
                    criteriaStp->isNullParent1ProgN = true;
                }
                else
                {
                    DBA_DYNFLD_STP* xdJoinPtr = (DBA_DYNFLD_STP*)TLS_Search(&(GET_ID(currXdAttribStp, A_XdAttrib_Join1XdAttribId)),
                                                                            xdAttribByIdTab,
                                                                            this->ddlGenEntityPtr->getXdAttribNbr(),
                                                                            sizeof(DBA_DYNFLD_STP*),
                                                                            DDL_CmpXdAttribByIdByKey);

                    if (xdJoinPtr != NULL &&
                        *xdJoinPtr != NULL)
                    {
                        if (IS_NULLFLD((*xdJoinPtr), A_XdAttrib_ShortIdx) == FALSE)
                        {
                            criteriaStp->parent1ProgN = GET_SMALLINT((*xdJoinPtr), A_XdAttrib_ShortIdx);
                            criteriaStp->isNullParent1ProgN = false;
                        }
                    }
                }

                if (IS_NULLFLD(currXdAttribStp, A_XdAttrib_PhysicalXdAttribId) == FALSE)
                {
                    this->copyDynFld(this->shXdAttribStp, S_XdAttrib_Id,
                                     currXdAttribStp, A_XdAttrib_PhysicalXdAttribId);

                    DBA_DYNFLD_STP aXdAttribStp = nullptr;

                    if ((ret = requestHelper.dbaGet(XdAttrib, UNUSED, this->shXdAttribStp, aXdAttribStp)) != RET_SUCCEED)
                    {
                        ret = RET_DBA_ERR_NODATA;
                        MSG_SendMesg(ret, 1, FILEINFO, "xd_attribute", GET_ID(currXdAttribStp, A_XdAttrib_PhysicalXdAttribId));

                        stringstream msgStream;
                        msgStream << "Unknown physical attribute in xd_attribute: " << GET_ID(currXdAttribStp, A_XdAttrib_PhysicalXdAttribId);
                        this->printMsg(ret, msgStream.str());
                    }
                    else
                    {
                        criteriaStp->attrDictId = GET_DICT(aXdAttribStp, A_XdAttrib_AttribDictId);

                        DICT_ATTRIB_STP parentAttr = DBA_GetAttributeById(criteriaStp->attrDictId);
                        if (parentAttr == nullptr)
                        {
                            stringstream        msgStream;

                            ret = RET_DBA_ERR_NODATA;
                            msgStream << "Unknown dict_criteria attribute: " << criteriaStp->sqlName;
                            this->printMsg(ret, msgStream.str());
                        }
                        else
                        {
                            criteriaStp->attrPtr = parentAttr;
                            criteriaStp->attrEntDictId = parentAttr->entDictId;
                        }
                    }
                }
            }
        }

        for (criterPos = 0; criterPos < shortInfoCriterNbr; criterPos++)
        {
            DICT_CRITER_STP criteriaStp = this->m_dictEntityStp->getDictCriteria(DynType_Short, criterPos);
            DICT_ATTRIB_STP attribStp = (criteriaStp->entAttrPtr != nullptr ? criteriaStp->entAttrPtr : criteriaStp->attrPtr);

            i = criteriaStp->progN;
            criteriaStp->entDictId = this->m_dictEntityStp->entDictId;
            criteriaStp->attrDictId = criteriaStp->attrPtr->attrDictId;
            criteriaStp->attrEntDictId = criteriaStp->attrPtr->entDictId;

            if (criteriaStp->sqlName[0] == 0)
            {
                criteriaStp->SET_dcLabel(attribStp->GET_daLabel()); /* PMSTA-22278 - 160203 - DDV - Use char* and UChar* instead of STRING1000_T and UNI_STRING1000_T */
                strcpy(criteriaStp->name, attribStp->name);
                strcpy(criteriaStp->sqlName, attribStp->sqlName);
                criteriaStp->SET_dcUniLabel(attribStp->GET_daUniLabel()); /* PMSTA-22278 - 160203 - DDV - Use char* and UChar* instead of STRING1000_T and UNI_STRING1000_T */
            }
        }

        if (index == 0)
        {
            for (criterPos = 0; criterPos < shortInfoCriterNbr; criterPos++)
            {
                DICT_CRITER_STP criteriaStp = this->m_dictEntityStp->getDictCriteria(DynType_Short, criterPos);
                DICT_ATTRIB_STP attribStp = criteriaStp->entAttrPtr;
                if (attribStp != nullptr && attribStp->busKeyFlg == TRUE)
                {
                    criteriaStp->index = index++;
                    criteriaStp->isNullIndex = false;

                    criteriaStp->fkIndex = (TINYINT_T)index;
                    criteriaStp->isNullFkIndex = false;
                }
            }
        }

        passNbr = 1; /* Skipp the Short process */
    }

    for (; passNbr < 2; passNbr++)
    {
        DBA_DYNTYPE_ENUM dynNatEn = (passNbr == 0 ? DynType_Short : DynType_All);

        for (i = 0; i < this->ddlGenEntityPtr->getXdAttribNbr(); i++)
        {
            DBA_DYNFLD_STP   currXdAttribStp = this->ddlGenEntityPtr->getXdAttrib(i);

            if ((dynNatEn == DynType_Short && IS_NULLFLD(currXdAttribStp, A_XdAttrib_ShortIdx) == FALSE) ||
                (dynNatEn == DynType_All && this->isAllDictCriteria(i)))
            {
                OBJECT_ENUM       refObjEn = NullEntity;
                DICT_CRITER_STP criteriaStp = this->m_dictEntityStp->addDictCriteria(dynNatEn,
                                                                                     (dynNatEn == DynType_Short ?
                                                                                      GET_SMALLINT(currXdAttribStp, A_XdAttrib_ShortIdx) :
                                                                                      (SMALLINT_T)GET_INT(currXdAttribStp, A_XdAttrib_Prog)));

                if (dynNatEn == DynType_Short)
                {
                    if (IS_NULLFLD(currXdAttribStp, A_XdAttrib_ShortDispRank) == FALSE)
                    {
                        criteriaStp->index = GET_SMALLINT(currXdAttribStp, A_XdAttrib_ShortDispRank);
                        criteriaStp->isNullIndex = false;
                    }
                    else
                    {
                        criteriaStp->index = 0;
                        criteriaStp->isNullIndex = true;
                    }

                    if (IS_NULLFLD(currXdAttribStp, A_XdAttrib_FkIdx) == FALSE)
                    {
                        criteriaStp->fkIndex = GET_TINYINT(currXdAttribStp, A_XdAttrib_FkIdx);
                        criteriaStp->isNullFkIndex = false;
                    }
                    else
                    {
                        criteriaStp->fkIndex = 0;
                        criteriaStp->isNullFkIndex = true;
                    }
                }
                else
                {
                    criteriaStp->index = 0;
                    criteriaStp->isNullIndex = true;
                    criteriaStp->fkIndex = 0;
                    criteriaStp->isNullFkIndex = true;
                }

                criteriaStp->sortRank = GET_TINYINT(currXdAttribStp, A_XdAttrib_SortRank);
                criteriaStp->sortRule = (SORTRULE_ENUM)GET_ENUM(currXdAttribStp, A_XdAttrib_SortRuleEn);

                strcpy(criteriaStp->name, GET_NAME(currXdAttribStp, A_XdAttrib_Name));
                strcpy(criteriaStp->sqlName, GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName));

                criteriaStp->entAttrPtr = DBA_GetAttributeBySqlName(this->objectEn, criteriaStp->sqlName, TRUE); /* PMSTA-18593 - LJE - 150915 */

                if (IS_NULLFLD(currXdAttribStp, A_XdAttrib_PhysicalXdAttribId) == TRUE ||
                    (GET_FLAG(currXdAttribStp, A_XdAttrib_ShortOnlyFlg) == FALSE &&
                     GET_ENUM(currXdAttribStp, A_XdAttrib_CalcEn) != DictAttr_Denorm))
                {
                    if (IS_NULLFLD(currXdAttribStp, A_XdAttrib_PhysicalXdAttribId) == FALSE)
                    {
                        stringstream msg;
                        msg << "Invalid physical attribute for non-denormalized/short only attribute (" << criteriaStp->sqlName << ")";
                        this->printMsg(RET_DBA_ERR_MD, msg.str());
                    }

                    criteriaStp->attrDictId = GET_DICT(currXdAttribStp, A_XdAttrib_AttribDictId);
                    criteriaStp->attrPtr = this->m_dictEntityStp->attr[GET_INT(currXdAttribStp, A_XdAttrib_Prog)];
                    refObjEn = this->objectEn;

                    criteriaStp->attrEntDictId = criteriaStp->entDictId;
                }
                else
                {
                    this->copyDynFld(this->shXdAttribStp, S_XdAttrib_Id,
                                     currXdAttribStp, A_XdAttrib_PhysicalXdAttribId);

                    DBA_DYNFLD_STP aXdAttribStp = nullptr;
                    if ((ret = requestHelper.dbaGet(XdAttrib, UNUSED, this->shXdAttribStp, aXdAttribStp)) != RET_SUCCEED)
                    {
                        ret = RET_DBA_ERR_NODATA;
                        MSG_SendMesg(ret, 1, FILEINFO, "xd_attribute", GET_ID(currXdAttribStp, A_XdAttrib_PhysicalXdAttribId));

                        stringstream msgStream;
                        msgStream << "Unknown physical attribute in xd_attribute: " << GET_ID(currXdAttribStp, A_XdAttrib_PhysicalXdAttribId);
                        this->printMsg(ret, msgStream.str());
                    }
                    else
                    {
                        criteriaStp->attrDictId = GET_DICT(aXdAttribStp, A_XdAttrib_AttribDictId);

                        DICT_ATTRIB_STP  parentAttr = DBA_GetAttributeById(criteriaStp->attrDictId);
                        if (parentAttr == NULL)
                        {
                            if (this->ddlGenContextPtr->ddlGenAction.m_mainDdlObjNatEn != DbObjDdlObjNat_System)
                            {
                                stringstream        msgStream;
                                ret = RET_DBA_ERR_NODATA;
                                msgStream << "Unknown dict_criteria attribute: " << criteriaStp->sqlName;
                                this->printMsg(ret, msgStream.str());
                                refObjEn = InvalidEntity;
                            }
                            else
                            {
                                criteriaStp->attrDictId = GET_DICT(currXdAttribStp, A_XdAttrib_AttribDictId);
                            }
                        }
                        else
                        {
                            if (GET_DICT(aXdAttribStp, A_XdAttrib_DataTpDictId) != GET_DICT(currXdAttribStp, A_XdAttrib_DataTpDictId))
                            {
                                stringstream        msgStream;

                                ret = RET_DBA_ERR_NODATA;
                                msgStream
                                    << "Data-type mismatch between the attribute: " << GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName)
                                    << " (" << DBA_GetDataTypeSQLNameC(DATATYPE_DICT_TO_ENUM(GET_DICT(currXdAttribStp, A_XdAttrib_DataTpDictId))) << ")"
                                    << " and the physical attribute: " << GET_SYSNAME(aXdAttribStp, A_XdAttrib_SqlName)
                                    << " (" << DBA_GetDataTypeSQLNameC(DATATYPE_DICT_TO_ENUM(GET_DICT(aXdAttribStp, A_XdAttrib_DataTpDictId))) << ")";
                                this->printMsg(ret, msgStream.str());
                            }

                            DBA_GetObjectEnum(parentAttr->entDictId, &refObjEn);
                            criteriaStp->attrPtr = parentAttr;

                            criteriaStp->attrEntDictId = parentAttr->entDictId;
                        }
                    }
                }
                criteriaStp->attrEntObj = refObjEn;

                if (IS_NULLFLD(currXdAttribStp, A_XdAttrib_Join1XdAttribId) == TRUE)
                {
                    criteriaStp->parent1ProgN = 0;
                    criteriaStp->isNullParent1ProgN = true;
                    criteriaStp->parentCriteria1Stp = nullptr;
                }
                else
                {
                    DBA_DYNFLD_STP* xdJoinPtr = (DBA_DYNFLD_STP*)TLS_Search(&(GET_ID(currXdAttribStp, A_XdAttrib_Join1XdAttribId)),
                                                                            xdAttribByIdTab,
                                                                            this->ddlGenEntityPtr->getXdAttribNbr(),
                                                                            sizeof(DBA_DYNFLD_STP*),
                                                                            DDL_CmpXdAttribByIdByKey);

                    if (xdJoinPtr != NULL &&
                        *xdJoinPtr != NULL)
                    {
                        if (dynNatEn == DynType_Short)
                        {
                            if (IS_NULLFLD((*xdJoinPtr), A_XdAttrib_ShortIdx) == FALSE)
                            {
                                criteriaStp->parent1ProgN = GET_SMALLINT((*xdJoinPtr), A_XdAttrib_ShortIdx);
                                criteriaStp->isNullParent1ProgN = false;
                            }
                            else
                            {
                                stringstream        msgStream;
                                ret = RET_DBA_ERR_MD;

                                msgStream << "Invalid join (1) attribute: " << GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName)
                                    << " - The pointed attribute (" << GET_SYSNAME((*xdJoinPtr), A_XdAttrib_SqlName) << ") must be in the short structure!";
                                this->printMsg(ret, msgStream.str());
                            }
                        }
                        else
                        {
                            criteriaStp->parent1ProgN = (SMALLINT_T)GET_INT((*xdJoinPtr), A_XdAttrib_Prog);
                            criteriaStp->isNullParent1ProgN = false;
                        }
                    }
                    else if (GET_A_XdAttrib_FeatureEn(currXdAttribStp) == XdEntityFeatureFeatureEn::AccessRightManagement &&
                             this->m_dictEntityStp->securityLevelEn == EntSecuLevel_NoSecured)
                    {
                        SET_NULL_ID(currXdAttribStp, A_XdAttrib_Join1XdAttribId);
                    }
                }

                if (IS_NULLFLD(currXdAttribStp, A_XdAttrib_Join2XdAttribId) == TRUE)
                {
                    criteriaStp->parent2ProgN = 0;
                    criteriaStp->isNullParent2ProgN = true;
                }
                else
                {
                    DBA_DYNFLD_STP* xdJoinPtr = (DBA_DYNFLD_STP*)TLS_Search(&(GET_ID(currXdAttribStp, A_XdAttrib_Join2XdAttribId)),
                                                                            xdAttribByIdTab,
                                                                            this->ddlGenEntityPtr->getXdAttribNbr(),
                                                                            sizeof(DBA_DYNFLD_STP*),
                                                                            DDL_CmpXdAttribByIdByKey);

                    if (xdJoinPtr != NULL &&
                        *xdJoinPtr != NULL)
                    {
                        if (dynNatEn == DynType_Short)
                        {
                            if (IS_NULLFLD((*xdJoinPtr), A_XdAttrib_ShortIdx) == FALSE)
                            {
                                criteriaStp->parent2ProgN = GET_SMALLINT((*xdJoinPtr), A_XdAttrib_ShortIdx);
                                criteriaStp->isNullParent2ProgN = false;
                            }
                            else
                            {
                                stringstream        msgStream;
                                ret = RET_DBA_ERR_MD;

                                msgStream << "Invalid join (2) attribute: " << GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName)
                                    << " - The pointed attribute (" << GET_SYSNAME((*xdJoinPtr), A_XdAttrib_SqlName) << " must be in the short structure!";
                                this->printMsg(ret, msgStream.str());
                            }
                        }
                        else
                        {
                            criteriaStp->parent2ProgN = (SMALLINT_T)GET_INT((*xdJoinPtr), A_XdAttrib_Prog);
                            criteriaStp->isNullParent2ProgN = false;
                        }
                    }
                }

                if (criteriaStp->attrDictId == 0 && this->ddlGenContextPtr->ddlGenAction.m_mainDdlObjNatEn != DbObjDdlObjNat_System)
                {
                    stringstream        msgStream;

                    msgStream << "Unknown physical attribute on dict_criteria for attribute " << criteriaStp->sqlName << ", entity " << this->m_dictEntityStp->mdSqlName;

                    if (IS_NULLFLD(currXdAttribStp, A_XdAttrib_ParentXdAttribId) == FALSE)
                    {
                        msgStream << ", define physical_xd_attrib_id instead of parent_xd_attrib_id!";
                    }
                    this->printMsg(RET_DBA_ERR_MD, msgStream.str());
                }

                if (dynNatEn == DynType_Short &&
                    GET_FLAG(currXdAttribStp, A_XdAttrib_CustoShortIdxFlg) == TRUE)
                {
                    SMALLINT_T       index = GET_SMALLINT(currXdAttribStp, A_XdAttrib_ShortDispRank);
                    this->addBkDictCriteria(currXdAttribStp, *criteriaStp, criterPos, shRank, index);
                }

                criterPos++;
            }
        }
    }

    if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
    {
        for (auto criteriaIt = this->m_dictEntityStp->shortDictCriteriaMap.begin(); criteriaIt != this->m_dictEntityStp->shortDictCriteriaMap.end(); ++criteriaIt)
        {
            DICT_CRITER_STP criteriaStp = criteriaIt->second;
            DBA_DYNFLD_STP allDictCritStp = requestHelper.allocDynSt(FILEINFO, A_DictCriter);

            SET_NULL_ID(allDictCritStp, A_DictCriter_DictId);
            SET_SYSNAME(allDictCritStp, A_DictCriter_SqlName, criteriaStp->sqlName);
            SET_ENUM(allDictCritStp, A_DictCriter_DynNat, criteriaStp->dynNatEn);
            SET_DICT(allDictCritStp, A_DictCriter_EntDictId, criteriaStp->entDictId);
            SET_DICT(allDictCritStp, A_DictCriter_AttrDictId, criteriaStp->attrDictId);

            if (criteriaStp->attrEntDictId == 0)
            {
                SET_NULL_DICT(allDictCritStp, A_DictCriter_AttrEntDictId);
            }
            else
            {
                SET_DICT(allDictCritStp, A_DictCriter_AttrEntDictId, criteriaStp->attrEntDictId);
            }
            SET_SMALLINT(allDictCritStp, A_DictCriter_Prog, (SMALLINT_T)criteriaIt->first);
            if (criteriaStp->sortRank != 0)
            {
                SET_TINYINT(allDictCritStp, A_DictCriter_SortRank, criteriaStp->sortRank);
            }
            else
            {
                SET_NULL_TINYINT(allDictCritStp, A_DictCriter_SortRank);
            }
            SET_ENUM(allDictCritStp, A_DictCriter_SortRuleEn, criteriaStp->sortRule);

            if (criteriaStp->isNullFkIndex == false)
            {
                SET_TINYINT(allDictCritStp, A_DictCriter_FkIndex, criteriaStp->fkIndex);
            }
            else
            {
                SET_NULL_TINYINT(allDictCritStp, A_DictCriter_FkIndex);
            }
            if (criteriaStp->isNullIndex == false)
            {
                SET_SMALLINT(allDictCritStp, A_DictCriter_Index, (SMALLINT_T)criteriaStp->index);
            }
            else
            {
                SET_NULL_SMALLINT(allDictCritStp, A_DictCriter_Index);
            }
            if (criteriaStp->isNullParent1ProgN == false)
            {
                SET_SMALLINT(allDictCritStp, A_DictCriter_Par1Prog, (SMALLINT_T)criteriaStp->parent1ProgN);
            }
            else
            {
                SET_NULL_SMALLINT(allDictCritStp, A_DictCriter_Par1Prog);
            }
            if (criteriaStp->isNullParent2ProgN == false)
            {
                SET_SMALLINT(allDictCritStp, A_DictCriter_Par2Prog, (SMALLINT_T)criteriaStp->parent2ProgN);
            }
            else
            {
                SET_NULL_SMALLINT(allDictCritStp, A_DictCriter_Par2Prog);
            }

            requestHelper.dbaCall(Insert,
                                  DictCriter,
                                  UNUSED,
                                  allDictCritStp,
                                  20,
                                  this->ddlGenEntityPtr->getADictEntityStp());

            requestHelper.setCopyIdForBatchMulti(&criteriaStp->dictId, allDictCritStp, A_DictCriter_DictId);
        }

        for (auto criteriaIt = this->m_dictEntityStp->allDictCriteriaMap.begin(); criteriaIt != this->m_dictEntityStp->allDictCriteriaMap.end(); ++criteriaIt)
        {
            DICT_CRITER_STP criteriaStp = criteriaIt->second;

            DBA_DYNFLD_STP allDictCritStp = requestHelper.allocDynSt(FILEINFO, A_DictCriter);

            SET_NULL_ID(allDictCritStp, A_DictCriter_DictId);
            SET_SYSNAME(allDictCritStp, A_DictCriter_SqlName, criteriaStp->sqlName);
            SET_ENUM(allDictCritStp, A_DictCriter_DynNat, criteriaStp->dynNatEn);
            SET_DICT(allDictCritStp, A_DictCriter_EntDictId, criteriaStp->entDictId);
            SET_DICT(allDictCritStp, A_DictCriter_AttrDictId, criteriaStp->attrDictId);

            if (criteriaStp->attrEntDictId == 0)
            {
                SET_NULL_DICT(allDictCritStp, A_DictCriter_AttrEntDictId);
            }
            else
            {
                SET_DICT(allDictCritStp, A_DictCriter_AttrEntDictId, criteriaStp->attrEntDictId);
            }
            SET_SMALLINT(allDictCritStp, A_DictCriter_Prog, (SMALLINT_T)criteriaIt->first);
            if (criteriaStp->sortRank != 0)
            {
                SET_TINYINT(allDictCritStp, A_DictCriter_SortRank, criteriaStp->sortRank);
            }
            else
            {
                SET_NULL_TINYINT(allDictCritStp, A_DictCriter_SortRank);
            }
            SET_ENUM(allDictCritStp, A_DictCriter_SortRuleEn, criteriaStp->sortRule);

            if (criteriaStp->isNullFkIndex == false)
            {
                SET_TINYINT(allDictCritStp, A_DictCriter_FkIndex, criteriaStp->fkIndex);
            }
            else
            {
                SET_NULL_TINYINT(allDictCritStp, A_DictCriter_FkIndex);
            }
            if (criteriaStp->isNullIndex == false)
            {
                SET_SMALLINT(allDictCritStp, A_DictCriter_Index, (SMALLINT_T)criteriaStp->index);
            }
            else
            {
                SET_NULL_SMALLINT(allDictCritStp, A_DictCriter_Index);
            }
            if (criteriaStp->isNullParent1ProgN == false)
            {
                SET_SMALLINT(allDictCritStp, A_DictCriter_Par1Prog, (SMALLINT_T)criteriaStp->parent1ProgN);
            }
            else
            {
                SET_NULL_SMALLINT(allDictCritStp, A_DictCriter_Par1Prog);
            }
            if (criteriaStp->isNullParent2ProgN == false)
            {
                SET_SMALLINT(allDictCritStp, A_DictCriter_Par2Prog, (SMALLINT_T)criteriaStp->parent2ProgN);
            }
            else
            {
                SET_NULL_SMALLINT(allDictCritStp, A_DictCriter_Par2Prog);
            }

            requestHelper.dbaCall(Insert,
                                  DictCriter,
                                  UNUSED,
                                  allDictCritStp,
                                  20,
                                  this->ddlGenEntityPtr->getADictEntityStp());
            requestHelper.setCopyIdForBatchMulti(&criteriaStp->dictId, allDictCritStp, A_DictCriter_DictId);
        }
    }

    return (ret);
}

/************************************************************************
**
**  Function    :   DdlGenFullTable::deleteEntity()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13109 - LJE - 110311
**
*************************************************************************/
RET_CODE DdlGenFullTable::memoryDeleteEntity()
{
    RET_CODE               ret = RET_SUCCEED;
    int                    i;
    DdlGenProcessLogger    ddlGenProcessLogger(*this, ret, "Memory Delete");
    DBA_DYNFLD_STP         xdEntityStp = this->getXdEntityStp();

    ddlGenProcessLogger.start();

    if (xdEntityStp == NULL ||
        IS_NULLFLD(xdEntityStp, A_XdEntity_SqlName) == TRUE ||
        (ret = this->initConnection()) != RET_SUCCEED)
    {
        return RET_DBA_INFO_NODATA;
    }
    DdlGenConnGuard     ddlGenConnGuard(*this->ddlGenContextPtr);

    try
    {
        this->m_dictEntityStp = DBA_GetDictEntitySt(this->objectEn);

        if (this->m_dictEntityStp != NULL)
        {
            for (i = 0; i < this->ddlGenEntityPtr->getXdAttribNbr(); i++)
            {
                DBA_DYNFLD_STP currXdAttribStp = this->ddlGenEntityPtr->getXdAttrib(i);

                if (GET_ENUM(currXdAttribStp, A_XdAttrib_XdStatusEn) != XdStatus_PhysicallyDeleted &&
                    (GET_ENUM(xdEntityStp, A_XdEntity_XdActionEn) == XdAction_ToDeprecate ||
                     GET_ENUM(currXdAttribStp, A_XdAttrib_XdStatusEn) == XdStatus_Inserted ||
                     GET_ENUM(currXdAttribStp, A_XdAttrib_XdStatusEn) == XdStatus_Failed))
                {
                    SET_ENUM(currXdAttribStp, A_XdAttrib_XdActionEn, GET_ENUM(xdEntityStp, A_XdEntity_XdActionEn));
                }
            }

            if (GET_ENUM(xdEntityStp, A_XdEntity_XdActionEn) == XdAction_ToPhysicallyDelete)
            {
                ret = this->deleteDictEntity();
            }
            else if (GET_ENUM(xdEntityStp, A_XdEntity_XdActionEn) == XdAction_ToDelete)
            {
                this->m_dictEntityStp->xdStatusEn = XdStatus_Deleted;
            }
            else if (GET_ENUM(xdEntityStp, A_XdEntity_XdActionEn) == XdAction_ToDeprecate)
            {
                this->m_dictEntityStp->xdStatusEn = XdStatus_Deprecated;
            }
        }

        this->bViewToDo = false;
        this->bIdxToDo = false;
        this->bTrgToDo = false;
        this->bSProcToDo = false;

        this->m_dictEntityStp = NULL; /* Set to NULL, the dict entity tab can change before the next step... */
    }
    catch (exception& e)
    {
        ret = RET_GEN_ERR_PERSONAL;
        this->printCatchMsg(FILEINFO, e.what());
    }

    this->finishConnection(ret);
    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenFullTable::buildInMemory()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13109 - LJE - 110311
**
*************************************************************************/
RET_CODE DdlGenFullTable::buildInMemory()
{
    RET_CODE               ret = RET_SUCCEED;
    int                    i, j, currProgN;

    DdlGenProcessLogger    ddlGenProcessLogger(*this, ret, "Memory creation");
    DBA_DYNFLD_STP         xdEntityStp = this->ddlGenEntityPtr->getXdEntityStp();

    ddlGenProcessLogger.start();

    if (xdEntityStp == NULL ||
        IS_NULLFLD(xdEntityStp, A_XdEntity_SqlName) == TRUE ||
        (ret = this->initConnection()) != RET_SUCCEED)
    {
        return RET_DBA_INFO_NODATA;
    }
    DdlGenConnGuard     ddlGenConnGuard(*this->ddlGenContextPtr);

    try
    {
        this->m_dictEntityStp = this->ddlGenEntityPtr->getDictEntityStp();
        this->objectEn = this->m_dictEntityStp->objectEn;

        this->m_dictEntityStp->linkEntitiesMap.clear(); /* PMSTA-29885 - LJE - 180123 */
        this->m_dictEntityStp->physicalEntitiesMap.clear(); /* PMSTA-37374 - LJE - 201214 */
            
        this->ddlGenContextPtr->addDictEntityByXdId(GET_ID(xdEntityStp, A_XdEntity_Id), this->m_dictEntityStp);

        this->m_dictEntityStp->entNatEn = (DBA_ENTITY_NAT_ENUM)GET_ENUM(xdEntityStp, A_XdEntity_NatEn);   /* PMSTA-28698 - LJE - 180622 */

        this->m_dictEntityStp->xdEntityId = GET_ID(xdEntityStp, A_XdEntity_Id); /* ORACLE - LJE - 141027 */

        this->m_dictEntityStp->databaseName.clear();
        this->m_dictEntityStp->custDbName.clear();
        if (IS_NULLFLD(xdEntityStp, A_XdEntity_Database) == false)
        {
            this->m_dictEntityStp->databaseName = GET_SYSNAME(xdEntityStp, A_XdEntity_Database);
            this->m_dictEntityStp->custDbName = GET_SYSNAME(xdEntityStp, A_XdEntity_Database);
        }

        this->m_dictEntityStp->precompDbName[0] = 0;
        if (IS_NULLFLD(xdEntityStp, A_XdEntity_PrecompDatabase) == false)
        {
            strcpy(this->m_dictEntityStp->precompDbName, GET_SYSNAME(xdEntityStp, A_XdEntity_PrecompDatabase));
        }

        if (IS_NULLFLD(xdEntityStp, A_XdEntity_ShortSqlName) == false)
        {
            strcpy(this->m_dictEntityStp->shortSqlname, GET_SYSNAME(xdEntityStp, A_XdEntity_ShortSqlName));
        }
        else
        {
            strcpy(this->m_dictEntityStp->shortSqlname, GET_SYSNAME(xdEntityStp, A_XdEntity_SqlName));
        }

        if (strlen(this->m_dictEntityStp->shortSqlname) > 16)
        {
            if (this->m_dictEntityStp->entNatEn == EntityNat_System ||
                this->m_dictEntityStp->entNatEn == EntityNat_Standard)
            {
                this->printMsg(RET_DBA_ERR_MD, "The short name (short_sqlname_c) of the entity (" + string(this->m_dictEntityStp->shortSqlname) + ") cannot be greater than 16 characters");
            }
            sprintf(this->m_dictEntityStp->shortSqlname, "%s_%" szFormatId, this->shortPrefixStr.c_str(), this->m_dictEntityStp->entDictId);
        }
        SET_SYSNAME(xdEntityStp, A_XdEntity_ShortSqlName, this->m_dictEntityStp->shortSqlname);

        if (IS_NULLFLD(xdEntityStp, A_XdEntity_AliasSqlName) == false &&
            strcmp(this->m_dictEntityStp->mdSqlName, GET_SYSNAME(xdEntityStp, A_XdEntity_AliasSqlName)) != 0)
        {
            strcpy(this->m_dictEntityStp->aliasSqlname, GET_SYSNAME(xdEntityStp, A_XdEntity_AliasSqlName));
        }
        else
        {
            sprintf(this->m_dictEntityStp->aliasSqlname, "%s_%" szFormatId, this->shortPrefixStr.c_str(), this->m_dictEntityStp->entDictId);
            SET_SYSNAME(xdEntityStp, A_XdEntity_AliasSqlName, this->m_dictEntityStp->aliasSqlname);
        }

        if (IS_NULLFLD(xdEntityStp, A_XdEntity_PrecompSqlName) == false)
        {
            strcpy(this->m_dictEntityStp->precompSqlName, GET_SYSNAME(xdEntityStp, A_XdEntity_PrecompSqlName));
        }
        else
        {
            this->m_dictEntityStp->precompSqlName[0] = 0;
        }
        this->m_dictEntityStp->automaticMask         = GET_MASK(xdEntityStp, A_XdEntity_AutomaticMask); /* PMSTA-14452 - LJE - 121023 */
        this->m_dictEntityStp->mainFlg               = GET_FLAG(xdEntityStp, A_XdEntity_MainFlg);
        this->m_dictEntityStp->xdStatusEn            = static_cast<XD_STATUS_ENUM>(GET_FLAG(xdEntityStp, A_XdEntity_XdStatusEn));
        this->m_dictEntityStp->logicalFlg            = GET_FLAG(xdEntityStp, A_XdEntity_LogicalFlg);
        this->m_dictEntityStp->securityLevelEn       = static_cast<ENTITY_SECURITY_LEVEL_ENUM>(GET_ENUM(xdEntityStp, A_XdEntity_SecurityLevelEn));
        this->m_dictEntityStp->custAuthFlg           = GET_FLAG(xdEntityStp, A_XdEntity_CustAuthFlg); /* PMSTA-14452 - LJE - 121102 */
        this->m_dictEntityStp->precompFlg            = GET_FLAG(xdEntityStp, A_XdEntity_PrecompFlg); /* PMSTA-18593 - LJE - 160118 */
        this->m_dictEntityStp->pkRuleEn              = static_cast<PK_RULE_ENUM>(GET_ENUM(xdEntityStp, A_XdEntity_PkRuleEn));
        this->m_dictEntityStp->dbRuleEn              = static_cast<DB_RULE_ENUM>(GET_ENUM(xdEntityStp, A_XdEntity_DbRuleEn));
        this->m_dictEntityStp->deleteRuleEn          = static_cast<DELETE_RULE_ENUM>(GET_ENUM(xdEntityStp, A_XdEntity_DeleteRuleEn));
        this->m_dictEntityStp->objModifStatEn        = static_cast<LAST_MODIF_ENUM>(GET_ENUM(xdEntityStp, A_XdEntity_ObjModifStatEn));
        this->m_dictEntityStp->tableModifStatEn      = static_cast<LAST_MODIF_ENUM>(GET_ENUM(xdEntityStp, A_XdEntity_TableModifStatEn));
        this->m_dictEntityStp->auditAuthEn           = static_cast<FEATURE_AUTH_ENUM>(GET_ENUM(xdEntityStp, A_XdEntity_AuditEn));
        this->m_dictEntityStp->activeAuthEn          = static_cast<FEATURE_AUTH_ENUM>(GET_ENUM(xdEntityStp, A_XdEntity_ActiveAuthEn));
        this->m_dictEntityStp->updFctAuthEn          = static_cast<FEATURE_AUTH_ENUM>(GET_ENUM(xdEntityStp, A_XdEntity_UpdFctAuthEn));
        this->m_dictEntityStp->externalSeqAuthEn     = static_cast<FEATURE_AUTH_ENUM>(GET_ENUM(xdEntityStp, A_XdEntity_ExternalSeqAuthEn));
        this->m_dictEntityStp->loadDictRuleEn        = static_cast<LOAD_DICT_RULE_ENUM>(GET_ENUM(xdEntityStp, A_XdEntity_LoadDictRuleEn));
        this->m_dictEntityStp->copyRightEn           = static_cast<DICT_ATTRCOPY_ENUM>(GET_ENUM(xdEntityStp, A_XdEntity_CopyRightEn));
        this->m_dictEntityStp->dmlModifTrackEn       = static_cast<DML_MODIF_TRACK_ENUM>(GET_ENUM(xdEntityStp, A_XdEntity_DmlModifTrackEn));
        this->m_dictEntityStp->partAuthEn            = static_cast<FEATURE_AUTH_ENUM>(GET_ENUM(xdEntityStp, A_XdEntity_PartAuthEn));
        this->m_dictEntityStp->dlmAuthEn             = static_cast<FEATURE_AUTH_ENUM>(GET_ENUM(xdEntityStp, A_XdEntity_DlmAuthEn));
        this->m_dictEntityStp->multiEntityCateg.set(static_cast<MULTI_ENTITY_CATEGORY_ENUM>(GET_ENUM(xdEntityStp, A_XdEntity_MultiEntityCategoryEn))); /* PMSTA-26108 - LJE - 170727 */
        this->m_dictEntityStp->interf                = GET_ENUM(xdEntityStp, A_XdEntity_InterfaceEn);
        this->m_dictEntityStp->synonFlg              = GET_FLAG(xdEntityStp, A_XdEntity_SynonymFlg);
        this->m_dictEntityStp->tpNatEn               = static_cast<TYPINGNAT_ENUM>(GET_ENUM(xdEntityStp, A_XdEntity_TypingNat));
        this->m_dictEntityStp->refAuthFlg            = GET_FLAG(xdEntityStp, A_XdEntity_RefAuthFlg);
        this->m_dictEntityStp->precompNbr            = 0;
        this->m_dictEntityStp->custNbr               = 0;
        this->m_dictEntityStp->entDictIdFlg          = FALSE;
        this->m_dictEntityStp->parIndex              = 255;
        this->m_dictEntityStp->isNullParIndex        = true;
        this->m_dictEntityStp->parentAttrStp         = nullptr;
        this->m_dictEntityStp->natIndex              = 255;
        this->m_dictEntityStp->isNullNatIndex        = true;
        this->m_dictEntityStp->bMultiEntityOnCustom  = this->ddlGenEntityPtr->bMultiEntityOnCustom;
        this->m_dictEntityStp->bMultiEntityOnPrecomp = this->ddlGenEntityPtr->bMultiEntityOnPrecomp;

        if (this->bNoShortOnEntity == false &&
            GET_ADMINGUIST(this->m_dictEntityStp->objectEn) == GET_EDITGUIST(this->m_dictEntityStp->objectEn))
        {
            this->bShortToDo = false;
            this->bNoShortOnEntity = true;
        }

        if (IS_NULLFLD(xdEntityStp, A_XdEntity_DbSqlName))
        {
            SET_SYSNAME(xdEntityStp,
                        A_XdEntity_DbSqlName,
                        this->ddlGenDbi.getEntityDbSqlName(this->m_dictEntityStp, GET_SYSNAME(xdEntityStp, A_XdEntity_SqlName)).c_str());
        }
        this->m_dictEntityStp->setDbSqlName(GET_SYSNAME(xdEntityStp, A_XdEntity_DbSqlName));


        INT_T noMdAttribNbr = 0;
        for (auto & dictAttribStp :this->m_dictEntityStp->buildAttr)
        {
            if (dictAttribStp->calcEn != DictAttr_NoMD)
            {
                dictAttribStp->xdStatusEn = XdStatus_Deleted;
                dictAttribStp->progN = INT_MAX;
            }
            else
            {
                noMdAttribNbr++;
                dictAttribStp->progN = SHRT_MAX;
            }
        }

        int lastProgN = 0;
        for (currProgN = -1, i = 0; i < this->ddlGenEntityPtr->getXdAttribNbr(); i++)
        {
            DBA_DYNFLD_STP currXdAttribStp = this->ddlGenEntityPtr->getXdAttrib(i);

            if (GET_FLAG(currXdAttribStp, A_XdAttrib_ShortOnlyFlg) == TRUE)
            {
                continue;
            }

            DICT_ATTRIB_STP attribStp = DBA_GetAttributeBySqlName(this->objectEn, GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName), TRUE);

            if (attribStp == nullptr ||
                attribStp->attrDictId < 0)
            {
                if (GET_ENUM(currXdAttribStp, A_XdAttrib_XdActionEn) == XdAction_ToInsert)
                {
                    if (this->m_dictEntityStp->bIsInitEntity &&
                        (EV_DynStPtr[EV_EntityGuiStPtr[objectEn].edit].allocCpt != 0 || EV_DynStPtr[EV_EntityGuiStPtr[objectEn].admin].allocCpt != 0) &&
                        GET_FLAG(currXdAttribStp, A_XdAttrib_PrecompFlg) == FALSE &&
                        GET_FLAG(currXdAttribStp, A_XdAttrib_LogicalFlg) == FALSE)
                    {
                        ret = RET_DBA_ERR_MD;
                        this->printMsg(ret, string("It's not allowed to add new attribute on 'init' entity: ") +
                                       this->m_dictEntityStp->mdSqlName + "." +
                                       GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName));
                        continue;
                    }
                    else
                    {
                        FIELD_IDX_T newProgN;
                        DICT_AddFieldToVirtualEntity(this->objectEn,
                                                     &newProgN,
                                                     GET_NAME(currXdAttribStp, A_XdAttrib_Name),
                                                     GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName),
                                                     DATATYPE_DICT_TO_ENUM(GET_DICT(currXdAttribStp, A_XdAttrib_DataTpDictId)),
                                                     0,
                                                     GET_FLAG(currXdAttribStp, A_XdAttrib_LogicalFlg),
                                                     TRUE,
                                                     NULL,
                                                     NULL,
                                                     this->ddlGenEntityPtr->getNextAttributeDictId(currXdAttribStp));

                        attribStp = this->m_dictEntityStp->buildAttr[newProgN];

                        assert(newProgN < (int)this->m_dictEntityStp->buildAttr.size());
                    }
                }
                else /* PMSTA-23363 - LJE - 160524 */
                {
                    if (GET_ENUM(currXdAttribStp, A_XdAttrib_XdActionEn) != XdAction_ToDelete &&
                        GET_ENUM(currXdAttribStp, A_XdAttrib_XdActionEn) != XdAction_ToPhysicallyDelete)
                    {
                        if (DictAttribClass::isPhysicalCalcEn((DICTATTR_ENUM)GET_ENUM(currXdAttribStp, A_XdAttrib_CalcEn)) == TRUE)
                        {
                            SET_ENUM(currXdAttribStp, A_XdAttrib_XdActionEn, XdAction_ToDelete);
                        }
                        else
                        {
                            SET_ENUM(currXdAttribStp, A_XdAttrib_XdActionEn, XdAction_ToPhysicallyDelete);
                        }
                    }

                    if (GET_A_XdAttrib_FeatureEn(currXdAttribStp) != XdEntityFeatureFeatureEn::MultiBusinessEntityManagement ||
                        this->m_dictEntityStp->multiEntityCateg.isMultiEntityCateg())
                    {
                        this->printMsg(RET_SUCCEED, string("Attribute to delete: ") +
                                       this->m_dictEntityStp->mdSqlName + "." +
                                       GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName));
                    }
                    continue;
                }
            }
            else
            {
                if (GET_ENUM(currXdAttribStp, A_XdAttrib_XdActionEn) == XdAction_ToDelete ||
                    GET_ENUM(currXdAttribStp, A_XdAttrib_XdActionEn) == XdAction_ToPhysicallyDelete)
                {
                    continue;
                }

                attribStp->progN = static_cast<INT_T>(this->m_dictEntityStp->buildAttr.size());
                this->m_dictEntityStp->buildAttr.push_back(attribStp);

                strcpy(attribStp->name, GET_NAME(currXdAttribStp, A_XdAttrib_Name));
                attribStp->dataTpProgN = DATATYPE_DICT_TO_ENUM(GET_DICT(currXdAttribStp, A_XdAttrib_DataTpDictId));
            }

            assert(attribStp->progN == GET_INT(currXdAttribStp, A_XdAttrib_Prog));

            this->ddlGenContextPtr->addDictAttribFromXdId(GET_ID(currXdAttribStp, A_XdAttrib_Id), attribStp);

            /* PMSTA-26108 - LJE - 170913 */
            if (noMdAttribNbr > 0 &&
                (GET_FLAG(currXdAttribStp, A_XdAttrib_LogicalFlg) == TRUE ||
                 GET_FLAG(currXdAttribStp, A_XdAttrib_PrecompFlg) == TRUE ||
                 GET_ENUM(currXdAttribStp, A_XdAttrib_CustomFlg) != Custom_No))
            {
                SET_NULL_SMALLINT(currXdAttribStp, A_XdAttrib_ShortIdx);
                SET_NULL_SMALLINT(currXdAttribStp, A_XdAttrib_ShortDispRank);
            }

            currProgN++;

            if (this->m_dictEntityStp->bIsInitEntity &&
                attribStp->dbProgN != currProgN &&
                (EV_DynStPtr[EV_EntityGuiStPtr[objectEn].edit].allocCpt != 0 || EV_DynStPtr[EV_EntityGuiStPtr[objectEn].admin].allocCpt != 0) &&
                GET_FLAG(currXdAttribStp, A_XdAttrib_PrecompFlg) == FALSE &&
                GET_FLAG(currXdAttribStp, A_XdAttrib_LogicalFlg) == FALSE) /* PMSTA-26250 - LJE - 170518 */
            {
                ret = RET_DBA_ERR_MD;
                this->printMsg(ret, string("It's not allowed to update the prog_n on attribute of 'init' entity: ") +
                               this->m_dictEntityStp->mdSqlName + "." +
                               GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName));
            }

            if (lastProgN != currProgN)
            {
                SYS_BreakOnDebug();
            }
            lastProgN++;

            attribStp->progN = currProgN;
            attribStp->dbProgN = GET_INT(currXdAttribStp, A_XdAttrib_Prog);
            SET_INT(currXdAttribStp, A_XdAttrib_Prog, attribStp->progN);

            attribStp->calcEn = (DICTATTR_ENUM)GET_ENUM(currXdAttribStp, A_XdAttrib_CalcEn);
            if (attribStp->isPhysicalAttribute() &&
                attribStp->calcEn != DictAttr_Physical &&
                attribStp->calcEn != DictAttr_ExternalSeqNo &&
                attribStp->calcEn != DictAttr_PhysicalPartition) /* PMSTA-24007 - LJE - 170824 */
            {
                attribStp->setBySpecProcFlg = TRUE;
            }
            attribStp->busKeyFlg = GET_FLAG(currXdAttribStp, A_XdAttrib_BusKeyFlg);
            attribStp->dbMandatoryFlg = GET_FLAG(currXdAttribStp, A_XdAttrib_DbMandatoryFlg);
            attribStp->mandatoryFlg = GET_FLAG(currXdAttribStp, A_XdAttrib_MandatoryFlg);
            attribStp->primFlg = GET_FLAG(currXdAttribStp, A_XdAttrib_PrimaryFlg);

            attribStp->progPkN = GET_SMALLINT(currXdAttribStp, A_XdAttrib_ProgPk);
            attribStp->isNullProgPkN = IS_NULLFLD(currXdAttribStp, A_XdAttrib_ProgPk);

            attribStp->progBkN = GET_SMALLINT(currXdAttribStp, A_XdAttrib_ProgBk);
            attribStp->isNullProgBkN = IS_NULLFLD(currXdAttribStp, A_XdAttrib_ProgBk);

            if (IS_NULLFLD(currXdAttribStp, A_XdAttrib_DispRank) == TRUE &&
                attribStp->busKeyFlg == TRUE)
            {
                SET_SMALLINT(currXdAttribStp, A_XdAttrib_DispRank, (SMALLINT_T)attribStp->progN);
            }

            if (IS_NULLFLD(currXdAttribStp, A_XdAttrib_Default) == FALSE)
                attribStp->dfltVal = GET_NAME(currXdAttribStp, A_XdAttrib_Default);
            else
                attribStp->dfltVal.clear();

            attribStp->dispRank        = GET_SMALLINT(currXdAttribStp, A_XdAttrib_DispRank);
            attribStp->logicalFlg      = GET_FLAG(currXdAttribStp, A_XdAttrib_LogicalFlg);
            attribStp->custFlg         = GET_ENUM(currXdAttribStp, A_XdAttrib_CustomFlg) == Custom_No ? FALSE : TRUE; /* PMSTA-14452 - LJE - 121102 */
            attribStp->permAuthEn      = (DBA_PERMAUTH_ENUM)GET_ENUM(currXdAttribStp, A_XdAttrib_PermAuthEn);
            attribStp->editionEn       = (DICTATTRIBEDIT_ENUM)GET_TINYINT(currXdAttribStp, A_XdAttrib_EditEn);
            attribStp->subTypeMask     = GET_MASK(currXdAttribStp, A_XdAttrib_SubTpMask);
            attribStp->qSearchMask     = GET_MASK(currXdAttribStp, A_XdAttrib_QuickSearchMask);
            attribStp->searchMask      = GET_MASK(currXdAttribStp, A_XdAttrib_SearchMask);
            attribStp->securityLevelEn = GET_ENUM(currXdAttribStp, A_XdAttrib_SecurityLevelEn);
            attribStp->refDeleteRuleEn = (REF_DELETE_RULE_ENUM)GET_ENUM(currXdAttribStp, A_XdAttrib_RefDeleteRuleEn);

            /* PMSTA-22868 - LJE - 160404 - Constraint is allowed, force the reference check rule to "Checked" to create the constraint */
            if (this->ddlGenDbi.isReferenceOnFk() &&
                (REF_CHECK_RULE_ENUM)GET_ENUM(currXdAttribStp, A_XdAttrib_RefCheckRuleEn) == RefChkRule_None &&
                (REF_DELETE_RULE_ENUM)GET_ENUM(currXdAttribStp, A_XdAttrib_RefDeleteRuleEn) != RefDelRule_NoAction &&
                (REF_DELETE_RULE_ENUM)GET_ENUM(currXdAttribStp, A_XdAttrib_RefDeleteRuleEn) != RefDelRule_None)
            {
                attribStp->refCheckRuleEn = RefChkRule_Checked;
            }
            else
            {
                attribStp->refCheckRuleEn = (REF_CHECK_RULE_ENUM)GET_ENUM(currXdAttribStp, A_XdAttrib_RefCheckRuleEn);
            }

            attribStp->outboxPublishEn    = static_cast<OUTBOX_PUBLISH_ENUM> GET_ENUM(currXdAttribStp, A_XdAttrib_OutboxPublishEn); /* PMSTA-45305 -Lalby- 210528 */
            attribStp->refSecurityRuleEn  = (REF_SECURITY_RULE_ENUM)GET_ENUM(currXdAttribStp, A_XdAttrib_RefSecurityRuleEn);
            attribStp->objModifStatEn     = (LAST_MODIF_ENUM)GET_ENUM(currXdAttribStp, A_XdAttrib_ObjModifStatEn);
            attribStp->exportEn           = (EXPORT_ENUM)GET_ENUM(currXdAttribStp, A_XdAttrib_ExportEn);
            attribStp->featureEn          = GET_A_XdAttrib_FeatureEn(currXdAttribStp);
            attribStp->modelBankEn        = (MODEL_BANK_ENUM)GET_ENUM(currXdAttribStp, A_XdAttrib_ModelBankEn); /* PMSTA-27352 - LJE - 170606 */
            attribStp->meSpecialisationEn = (ME_SPECIALISATION_ENUM)GET_ENUM(currXdAttribStp, A_XdAttrib_MeSpecialisationEn); /* PMSTA-26108 - LJE - 170830 */

            if (IS_NULLFLD(currXdAttribStp, A_XdAttrib_KeyChar) == FALSE)
            {
                strcpy(attribStp->keyCharC, GET_NAME(currXdAttribStp, A_XdAttrib_KeyChar));
            }
            else
            {
                attribStp->keyCharC[0] = 0;
            }

            attribStp->maxDbLenN          = GET_SMALLINT(currXdAttribStp, A_XdAttrib_MaxDbLen);
            attribStp->defaultDisplayLenN = GET_SMALLINT(currXdAttribStp, A_XdAttrib_DefaultDispLen);
            attribStp->tascViewEn         = GET_ENUM(currXdAttribStp, A_XdAttrib_TascViewEn);
            attribStp->fkPresentationEn   = GET_ENUM(currXdAttribStp, A_XdAttrib_FkPresentationEn);
            attribStp->precompFlg         = GET_FLAG(currXdAttribStp, A_XdAttrib_PrecompFlg);
            attribStp->verticalSearchFlg  = GET_FLAG(currXdAttribStp, A_XdAttrib_VerticalSearchFlg);
            attribStp->verticalPatternFlg = GET_FLAG(currXdAttribStp, A_XdAttrib_VerticalPatternFlg);
            attribStp->multiLanguageFlg   = GET_FLAG(currXdAttribStp, A_XdAttrib_MultiLangFlg);
            attribStp->widgetEn           = (DICTATTRIBWGT_ENUM)GET_ENUM(currXdAttribStp, A_XdAttrib_WidgetEn);

            if (attribStp->featureEn == XdEntityFeatureFeatureEn::MultiBusinessEntityManagement)
            {
                if (attribStp->custFlg == TRUE)
                {
                    attribStp->custFlg = FALSE;
                    this->m_dictEntityStp->bMultiEntityOnCustom = true;
                }

                if (attribStp->precompFlg == TRUE)
                {
                    attribStp->precompFlg = FALSE;
                    this->m_dictEntityStp->bMultiEntityOnPrecomp = true;
                }
            }

            if (attribStp->dataTpProgN == IdType &&
                IS_NULLFLD(currXdAttribStp, A_XdAttrib_RefXdEntityId) == TRUE &&
                IS_NULLFLD(currXdAttribStp, A_XdAttrib_LinkedXdAttribId) == FALSE)
            {
                this->m_dictEntityStp->entDictIdFlg = TRUE;
            }

            attribStp->shortIdx = 0;
            attribStp->isNullShortIdx = true;

            if (IS_NULLFLD(currXdAttribStp, A_XdAttrib_ShortIdx) == false &&
                (IS_NULLFLD(currXdAttribStp, A_XdAttrib_ShortDispRank) || 
                 GET_SMALLINT(currXdAttribStp, A_XdAttrib_ShortDispRank) >= 0))
            {
                attribStp->shortIdx = GET_SMALLINT(currXdAttribStp, A_XdAttrib_ShortIdx);
                attribStp->isNullShortIdx = false;
            }

            /* PMSTA-14452 - LJE - 121102 */
            if (attribStp->custFlg == TRUE)
            {
                this->m_dictEntityStp->custNbr++;
            }

            /* PMSTA-37366 - LJE - 200204 */
            if (attribStp->precompFlg == TRUE)
            {
                this->m_dictEntityStp->precompNbr++;
            }

            auto xdPermValMapPtr = this->ddlGenEntityPtr->getXdPermValByAttribMap(currXdAttribStp);

            if (xdPermValMapPtr != nullptr && xdPermValMapPtr->empty() == false)
            {
                for (auto &permValIt : *xdPermValMapPtr)
                {
                    DBA_DYNFLD_STP aXdPermValStp = permValIt.second;

                    if (GET_ENUM(aXdPermValStp, A_XdPermVal_XdActionEn) == XdAction_ToInsert ||
                        (GET_ENUM(aXdPermValStp, A_XdPermVal_XdActionEn) == XdAction_None &&
                         GET_ENUM(aXdPermValStp, A_XdPermVal_XdStatusEn) == XdStatus_Inserted))
                    {
                        DICT_PERM_VAL_ST& dictPermValSt = attribStp->permValMap[GET_SMALLINT(aXdPermValStp, A_XdPermVal_Rank)];

                        dictPermValSt.dictId        = 0;
                        dictPermValSt.attDictId     = attribStp->attrDictId;
                        dictPermValSt.entDictId     = this->m_dictEntityStp->entDictId;
                        dictPermValSt.rank          = GET_SMALLINT(aXdPermValStp, A_XdPermVal_Rank);
                        dictPermValSt.permVal       = GET_ENUM(aXdPermValStp, A_XdPermVal_PermValNatEn);
                        dictPermValSt.permValRuleEn = (PERM_VAL_RULE_ENUM)GET_ENUM(aXdPermValStp, A_XdPermVal_PermValRuleEn);
                        dictPermValSt.dbRuleEn      = (PERM_VAL_DB_RULE_ENUM)GET_ENUM(aXdPermValStp, A_XdPermVal_DbRuleEn); /* PMSTA-27352 - LJE - 170606 */
                        dictPermValSt.nameStr       = GET_NAME(aXdPermValStp, A_XdPermVal_Name);
                    }
                }
            }

            if (DATATYPE_DICT_TO_ENUM(GET_DICT(currXdAttribStp, A_XdAttrib_DataTpDictId)) == FlagType ||
                DATATYPE_DICT_TO_ENUM(GET_DICT(currXdAttribStp, A_XdAttrib_DataTpDictId)) == EnumType ||
                DATATYPE_DICT_TO_ENUM(GET_DICT(currXdAttribStp, A_XdAttrib_DataTpDictId)) == EnumMaskType)
            {
                SET_FLAG_TRUE(currXdAttribStp, A_XdAttrib_PermValFlg);
            }

            /* PMSTA-26252 - LJE - 170209 */
            if (this->ddlGenDbi.getOptimisticLockingRule(attribStp) != OptimisticLocking_None)
            {
                this->m_dictEntityStp->optimisticLockingAttrStp = attribStp;

                if (this->ddlGenDbi.getOptimisticLockingRule(attribStp) == OptimisticLocking_RowVersion)
                {
                    attribStp->dbMandatoryFlg   = TRUE;
                    attribStp->dfltVal          = "0";
                    attribStp->calcEn           = DictAttr_Physical;
                    attribStp->setBySpecProcFlg = FALSE;

                    SET_FLAG(currXdAttribStp, A_XdAttrib_DbMandatoryFlg, attribStp->dbMandatoryFlg);
                    SET_STRING(currXdAttribStp, A_XdAttrib_Default, attribStp->dfltVal.c_str());
                    SET_ENUM(currXdAttribStp, A_XdAttrib_CalcEn, attribStp->calcEn);

                    if (attribStp->xdStatusEn != XdStatus_Inserted &&
                        this->ddlGenEntityPtr->getSysXdAttribStp(TargetTable_Main, this->ddlGenDbi.getOptimisticLockingSqlName(this->m_dictEntityStp)) != NULL)
                    {
                        SET_ENUM(currXdAttribStp, A_XdAttrib_XdStatusEn, XdStatus_Inserted);
                        attribStp->xdStatusEn = XdStatus_Inserted;
                    }
                }
            }
        }

        /* PMSTA-26108 - LJE - 170913 */
        if (noMdAttribNbr > 0)
        {
            for (auto & dictAttribStp : this->m_dictEntityStp->buildAttr)
            {
                if (dictAttribStp->calcEn == DictAttr_NoMD)
                {
                    dictAttribStp->progN = ++currProgN;
                }
            }
        }

        /* Reset dict_criteria information */
        this->m_dictEntityStp->shortDictCriteriaMap.clear();
        this->m_dictEntityStp->allDictCriteriaMap.clear();
        this->m_dictEntityStp->criterMap.clear();

        DICT_ActivateVirtualAttributes(this->objectEn);

        /* Check */
        j = 0;
        for (auto& dictAttribStp : this->m_dictEntityStp->attr)
        {
            if (dictAttribStp->progN != INT_MAX &&
                dictAttribStp->calcEn != DictAttr_NoMD &&
                dictAttribStp->logicalFlg == FALSE)
            {
                if (GET_ENUM(this->ddlGenEntityPtr->getXdAttrib(j), A_XdAttrib_XdActionEn) == XdAction_ToDelete ||
                    GET_ENUM(this->ddlGenEntityPtr->getXdAttrib(j), A_XdAttrib_XdActionEn) == XdAction_ToPhysicallyDelete)
                {
                    dictAttribStp->xdStatusEn = XdStatus_Deleted;
                    continue;
                }
            }

            dictAttribStp->xdStatusEn = XdStatus_Inserted;

            if (dictAttribStp->calcEn != DictAttr_NoMD)
            {
                j++;
            }
        }

        SET_DICT(this->shDictEntityStp, S_DictEntity_DictId, this->m_dictEntityStp->entDictId);

        if (GET_ENUM(xdEntityStp, A_XdEntity_XdActionEn) == XdAction_ToRefresh)
        {
            SET_ENUM(xdEntityStp, A_XdEntity_XdActionEn, XdAction_ToInsert);
        }

        /* PMSTA-37366 - LJE - 200204 */
        if (this->m_dictEntityStp->precompNbr > 0 && this->bExtTableToDo == true)
        {
            this->m_dictEntityStp->usePrecompFlg = TRUE;
        }

        this->m_dictEntityStp->init(true);
    }
    catch (exception& e)
    {
        ret = RET_GEN_ERR_PERSONAL;
        this->printCatchMsg(FILEINFO, e.what());
    }

    this->finishConnection(ret);
    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenFullTable::deleteRefRecord()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-14452 - LJE - 130508
**
*************************************************************************/
RET_CODE DdlGenFullTable::deleteRefRecord(DICT_T delEntDictId, ID_T delRefId, DdlGen& delDdlGen)
{
    RET_CODE               ret = RET_SUCCEED;
    DICT_ENTITY_STP        refDictEntityStp;
    OBJECT_ENUM            objEn;

    for (objEn = NullEntity; objEn < LASTENTITYOBJECT; objEn++)
    {
        /* Exceptions */
        if (objEn == PerfAttrib ||
            objEn == ExtRetAnalysis ||
            objEn == StandardPerf)
        {
            continue;
        }

        refDictEntityStp = DBA_GetDictEntitySt(objEn);
        if (refDictEntityStp != NULL &&
            refDictEntityStp->logicalFlg == FALSE &&
            refDictEntityStp->dbRuleEn != DbRule_Template &&
            refDictEntityStp->dbRuleEn != DbRule_NotInDatabase &&
            refDictEntityStp->dbRuleEn != DbRule_NotMainTable &&
            refDictEntityStp->entNatEn != EntityNat_Tsl &&
            refDictEntityStp->entNatEn != EntityNat_PersistedFmt &&
            refDictEntityStp->entNatEn != EntityNat_SearchFmt &&
            refDictEntityStp->entNatEn != EntityNat_ReportFmt &&
            refDictEntityStp->entNatEn != EntityNat_TempTable &&
            strstr(refDictEntityStp->mdSqlName, "dict_") != refDictEntityStp->mdSqlName &&
            strstr(refDictEntityStp->mdSqlName, "xd_") != refDictEntityStp->mdSqlName)
        {
            for (auto& attribStp : refDictEntityStp->attr)
            {
                if (attribStp->refEntDictId != delEntDictId ||
                    attribStp->attrDictId < 0 ||
                    attribStp->isPhysicalAttribute() == false)
                {
                    continue;
                }

                if (attribStp->refDeleteRuleEn != RefDelRule_CascadeDelete)
                {
                    delDdlGen.bodySqlBlock << delDdlGen.newLine()
                        << "delete from " << delDdlGen.getEntityFullSqlName(refDictEntityStp) << delDdlGen.newLine()
                        << "where " << attribStp->sqlName << " = " << delRefId << endl;

                    delDdlGen.cmdType = DDlCmdType_Exec;
                    delDdlGen.flush();
                }
            }
        }
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenFullTable::deleteDictEntity()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13109 - LJE - 110311
**
*************************************************************************/
RET_CODE DdlGenFullTable::deleteDictEntity()
{
    RET_CODE               ret = RET_SUCCEED;
    DICT_T                 dictEntityDictId, dictAttribDictId;
    DdlGen                 delDdlGen(this->objectEn, DdlObj_None, *this->ddlGenContextPtr, NULL, this->ddlGenEntityPtr, NULL, TargetTable_Main);

    DBA_GetDictId(DictAttr, &dictAttribDictId);
    DBA_GetDictId(DictEntity, &dictEntityDictId);

    if (this->m_dictEntityStp->entDictId > 0 &&
        this->ddlGenEntityPtr->getADictEntityStp() != nullptr)
    {
        SET_DICT(this->ddlGenEntityPtr->getADictEntityStp(), A_DictEntity_DictId, this->m_dictEntityStp->entDictId);

        if (this->m_dictEntityStp->entNatEn == EntityNat_Standard ||
            this->m_dictEntityStp->entNatEn == EntityNat_Custom ||
            this->m_dictEntityStp->entNatEn == EntityNat_CustomDS ||
            this->m_dictEntityStp->entNatEn == EntityNat_Packaging ||
            this->m_dictEntityStp->entNatEn == EntityNat_ModelBank)
        {
            for (auto& attribStp : this->m_dictEntityStp->attr)
            {
                if (attribStp->attrDictId < 0 ||
                    attribStp->isPhysicalAttribute() == false)
                    continue;

                this->deleteRefRecord(dictAttribDictId, attribStp->attrDictId, delDdlGen);
            }

            this->deleteRefRecord(dictEntityDictId, this->m_dictEntityStp->entDictId, delDdlGen);
        }

        /* Try to delete dict_entity */
        DdlGenDbaAccessGuard ddlGenDbaAccessGuard(*this->ddlGenContextPtr);
        ddlGenDbaAccessGuard.getDdlGenDbaAccess().insUpdDelRecord(Delete,
                                                                  DictEntity,
                                                                  UNUSED,
                                                                  this->ddlGenEntityPtr->getADictEntityStp(),
                                                                  false);
    }
    this->m_dictEntityStp->xdStatusEn = XdStatus_PhysicallyDeleted;

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenFullTable::updateCrossLinks()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-26108 - LJE - 170916
**
*************************************************************************/
RET_CODE DdlGenFullTable::updateCrossLinks()
{
    RET_CODE               ret = RET_SUCCEED;
    DdlGenProcessLogger    ddlGenProcessLogger(*this, ret, "Manage Cross Links");

    ddlGenProcessLogger.start();

    if ((this->m_dictEntityStp = DBA_GetDictEntitySt(this->objectEn)) == NULL)
    {
        ret = RET_DBA_INFO_NODATA;
        return ret;
    }

    try
    {
        DBA_DYNFLD_STP xdEntityStp = this->getXdEntityStp();

        this->m_dictEntityStp->parIndex             = 255;
        this->m_dictEntityStp->isNullParIndex       = true;
        this->m_dictEntityStp->parentAttrStp        = nullptr;
        this->m_dictEntityStp->natIndex             = 255;
        this->m_dictEntityStp->isNullNatIndex       = true;
        this->m_dictEntityStp->linkedEntityDictId   = 0;
        this->m_dictEntityStp->linkedEntityStp      = nullptr;
        this->m_dictEntityStp->physicalEntityDictId = 0;
        this->m_dictEntityStp->physicalEntityStp    = nullptr;

        if (IS_NULLFLD(xdEntityStp, A_XdEntity_NatXdAttribId) == FALSE)
        {
            DICT_ATTRIB_STP natAttribStp = this->ddlGenContextPtr->getDictAttribFromXdId(GET_ID(xdEntityStp, A_XdEntity_NatXdAttribId));
            if (natAttribStp != nullptr)
            {
                this->m_dictEntityStp->natIndex = natAttribStp->progN;
                this->m_dictEntityStp->isNullNatIndex = false;
            }
            else
            {
                SYS_BreakOnDebug();
            }
        }

        if (IS_NULLFLD(xdEntityStp, A_XdEntity_LinkedXdEntityId) == FALSE)
        {
            this->m_dictEntityStp->linkedEntityStp = this->ddlGenContextPtr->getDictEntityFromXdId(GET_ID(xdEntityStp, A_XdEntity_LinkedXdEntityId));
            if (this->m_dictEntityStp->linkedEntityStp != nullptr)
            {
                this->m_dictEntityStp->linkedEntityDictId = this->m_dictEntityStp->linkedEntityStp->entDictId;
            }
            else
            {
                SYS_BreakOnDebug();
            }
        }

        if (IS_NULLFLD(xdEntityStp, A_XdEntity_PhysicalXdEntityId) == FALSE)
        {
            this->m_dictEntityStp->physicalEntityStp = this->ddlGenContextPtr->getDictEntityFromXdId(GET_ID(xdEntityStp, A_XdEntity_PhysicalXdEntityId));
            if (this->m_dictEntityStp->physicalEntityStp != nullptr)
            {
                this->m_dictEntityStp->physicalEntityDictId = this->m_dictEntityStp->physicalEntityStp->entDictId;
            }
            else
            {
                SYS_BreakOnDebug();
            }
        }

        for (int i = 0; i < this->ddlGenEntityPtr->getXdAttribNbr(); i++)
        {
            DBA_DYNFLD_STP currXdAttribStp = this->ddlGenEntityPtr->getXdAttrib(i);

            if (GET_ENUM(currXdAttribStp, A_XdAttrib_XdActionEn) == XdAction_ToInsert)
            {
                if (GET_INT(currXdAttribStp, A_XdAttrib_Prog) < static_cast<INT_T>(this->m_dictEntityStp->attr.size()))
                {
                    auto attribStp = this->m_dictEntityStp->attr[GET_INT(currXdAttribStp, A_XdAttrib_Prog)];

                    if (IS_NULLFLD(currXdAttribStp, A_XdAttrib_RefXdEntityId) == FALSE)
                    {
                        DICT_ENTITY_STP refDictEntityStp = this->ddlGenContextPtr->getDictEntityFromXdId(GET_ID(currXdAttribStp, A_XdAttrib_RefXdEntityId));
                        if (refDictEntityStp != nullptr)
                        {
                            attribStp->refDictEntityStp         = refDictEntityStp;
                            attribStp->refEntDictId             = attribStp->refDictEntityStp->entDictId;
                            attribStp->refEntityAttributeDictId = attribStp->refEntDictId;
                        }
                    }
                    else
                    {
                        attribStp->refEntDictId             = 0;
                        attribStp->refDictEntityStp         = nullptr;
                        attribStp->refEntityAttributeDictId = 0;
                    }

                    if (IS_NULLFLD(currXdAttribStp, A_XdAttrib_ParentXdAttribId) == FALSE)
                    {
                        DICT_ATTRIB_STP parAttrPtr = this->ddlGenContextPtr->getDictAttribFromXdId(GET_ID(currXdAttribStp, A_XdAttrib_ParentXdAttribId));
                        if (parAttrPtr != nullptr)
                        {
                            attribStp->parAttrPtr       = parAttrPtr;
                            attribStp->parAttrDictId    = attribStp->parAttrPtr->attrDictId;
                            attribStp->parAttrEntDictId = attribStp->parAttrPtr->entDictId;
                            attribStp->parAttrProgN     = attribStp->parAttrPtr->progN;
                        }
                    }
                    else
                    {
                        attribStp->parAttrDictId    = 0;
                        attribStp->parAttrPtr       = nullptr;
                        attribStp->parAttrEntDictId = 0;
                        attribStp->parAttrProgN     = 0;
                    }

                    if (IS_NULLFLD(currXdAttribStp, A_XdAttrib_LinkedXdAttribId) == FALSE)
                    {
                        DICT_ATTRIB_STP linkedAttrDictStp = this->ddlGenContextPtr->getDictAttribFromXdId(GET_ID(currXdAttribStp, A_XdAttrib_LinkedXdAttribId));
                        if (linkedAttrDictStp != nullptr)
                        {
                            attribStp->linkedAttrDictStp = linkedAttrDictStp;
                            attribStp->linkedAttrDictId = attribStp->linkedAttrDictStp->attrDictId;
                        }
                    }
                    else
                    {
                        attribStp->linkedAttrDictId  = 0;
                        attribStp->linkedAttrDictStp = nullptr;
                    }
                }
            }
        }

        if (IS_NULLFLD(xdEntityStp, A_XdEntity_ParentXdAttribId) == FALSE)
        {
            this->m_dictEntityStp->parentAttrStp = this->ddlGenContextPtr->getDictAttribFromXdId(GET_ID(xdEntityStp, A_XdEntity_ParentXdAttribId));
            if (this->m_dictEntityStp->parentAttrStp != nullptr)
            {
                this->m_dictEntityStp->parIndex = this->m_dictEntityStp->parentAttrStp->progN;
                this->m_dictEntityStp->isNullParIndex = false;

                /* Hide the entity_dict_id of the child entity */
                DICT_ATTRIB_STP linkedAttrDictStp = this->m_dictEntityStp->attr[this->m_dictEntityStp->parIndex]->linkedAttrDictStp;
                if (linkedAttrDictStp != nullptr)
                {
                    linkedAttrDictStp->subTypeMask = 0;
                    SET_MASK(this->ddlGenEntityPtr->getXdAttrib(linkedAttrDictStp->progN), A_XdAttrib_SubTpMask, 0);
                }
            }
            else
            {
                SYS_BreakOnDebug();
            }
        }
    }
    catch (exception& e)
    {
        ret = RET_GEN_ERR_PERSONAL;
        this->printCatchMsg(FILEINFO, e.what());
    }

    this->m_dictEntityStp = NULL; /* Set to NULL, the dict entity tab can change before the next step... */

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenFullTable::updateCrossProgN()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-50889 - LJE - 221110
**
*************************************************************************/
RET_CODE DdlGenFullTable::updateCrossProgN()
{
    RET_CODE               ret = RET_SUCCEED;
    DBA_DYNFLD_STP xdEntityStp = this->getXdEntityStp();

    if (GET_ENUM(xdEntityStp, A_XdEntity_DictBuildRuleEn) != DictBuildRule_Ud &&
        GET_ENUM(xdEntityStp, A_XdEntity_DictBuildRuleEn) != DictBuildRule_Sh)
    {
        ret = RET_DBA_INFO_NODATA;
        return ret;
    }

    DdlGenProcessLogger    ddlGenProcessLogger(*this, ret, "Manage Cross ProgN");

    ddlGenProcessLogger.start();

    if ((this->m_dictEntityStp = DBA_GetDictEntitySt(this->objectEn)) == NULL)
    {
        ret = RET_DBA_INFO_NODATA;
        return ret;
    }

    try
    {
        if (this->m_dictEntityStp->udPKTab != nullptr &&
            this->m_dictEntityStp->linkedEntityStp != nullptr &&
            this->m_dictEntityStp->linkedEntityStp->udPKTab != nullptr)
        {
            bool bUpdated = false;

            if (GET_ENUM(xdEntityStp, A_XdEntity_DictBuildRuleEn) == DictBuildRule_Ud)
            {
                FIELD_IDX_T lnkUdIdPos = this->m_dictEntityStp->linkedEntityStp->udPKTab[0]->progN;
                FIELD_IDX_T udIdPos = this->m_dictEntityStp->udPKTab[0]->progN;

                map<string, FIELD_IDX_T> udfMap;
                for (auto &attribIt : this->m_dictEntityStp->linkedEntityStp->attribMap)
                {
                    if (attribIt.second->custFlg == TRUE)
                    {
                        udfMap[attribIt.second->sqlName] = (attribIt.second->progN - lnkUdIdPos) + udIdPos;
                    }
                }

                /* PMSTA-50889 - LJE - 221031 */
                for (int i = 0; i < this->ddlGenEntityPtr->getXdAttribNbr(); i++)
                {
                    DBA_DYNFLD_STP currXdAttribStp = this->ddlGenEntityPtr->getXdAttrib(i);

                    if (GET_ENUM(currXdAttribStp, A_XdAttrib_CustomFlg) != Custom_No &&
                        udfMap[GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName)] != GET_INT(currXdAttribStp, A_XdAttrib_Prog))
                    {
                        bUpdated = true;
                        SET_INT(currXdAttribStp, A_XdAttrib_Prog, udfMap[GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName)]);
                        this->m_dictEntityStp->sortedAttr[GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName)]->progN = GET_INT(currXdAttribStp, A_XdAttrib_Prog);
                    }
                }
            }
            else if (GET_ENUM(xdEntityStp, A_XdEntity_DictBuildRuleEn) == DictBuildRule_Sh)
            {
                map<string, FIELD_IDX_T> attribMap;
                FIELD_IDX_T offsetPos = 0;
                for (auto &attribIt : this->m_dictEntityStp->linkedEntityStp->attr)
                {
                    if (attribIt->isPhysicalAttribute() ||
                        attribIt->featureEn == XdEntityFeatureFeatureEn::ShadowEntity ||
                        attribIt->featureEn == XdEntityFeatureFeatureEn::MultiBusinessEntityManagement ||
                        (attribIt->logicalFlg == FALSE && this->m_dictEntityStp->sortedAttr.find(attribIt->sqlName) != this->m_dictEntityStp->sortedAttr.end()))
                    {
                        attribMap[attribIt->sqlName] = attribIt->progN - offsetPos;
                    }
                    else if (attribIt->attrDictId > 0)
                    {
                        offsetPos++;
                    }
                }

                for (int i = 0; i < this->ddlGenEntityPtr->getXdAttribNbr(); i++)
                {
                    DBA_DYNFLD_STP currXdAttribStp = this->ddlGenEntityPtr->getXdAttrib(i);
                    auto attribIt = attribMap.find(GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName));

                    if (attribIt != attribMap.end() &&
                        attribMap[GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName)] != GET_INT(currXdAttribStp, A_XdAttrib_Prog))
                    {
                        bUpdated = true;
                        SET_INT(currXdAttribStp, A_XdAttrib_Prog, attribMap[GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName)]);
                        this->m_dictEntityStp->sortedAttr[GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName)]->progN = GET_INT(currXdAttribStp, A_XdAttrib_Prog);
                    }
                }
            }

            auto allDynDefStp = DBA_GetDynStDefBySqlName(this->m_dictEntityStp->mdSqlName, DynType_All);
            if (allDynDefStp != nullptr &&
                GET_DYNST_ENTITY(*allDynDefStp->dynStPosPtr) != this->m_dictEntityStp->objectEn)
            {
                auto refDictEntityStp = DBA_GetDictEntitySt(GET_DYNST_ENTITY(*allDynDefStp->dynStPosPtr));

                map<string, FIELD_IDX_T> attribMap;
                for (auto &attribIt : refDictEntityStp->attr)
                {
                    if (attribIt->logicalFlg == TRUE)
                    {
                        break;
                    }
                    attribMap[attribIt->sqlName] = attribIt->progN;
                }

                for (int i = 0; i < this->ddlGenEntityPtr->getXdAttribNbr(); i++)
                {
                    DBA_DYNFLD_STP currXdAttribStp = this->ddlGenEntityPtr->getXdAttrib(i);
                    auto attribIt = attribMap.find(GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName));

                    if (attribIt != attribMap.end() &&
                        attribMap[GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName)] != GET_INT(currXdAttribStp, A_XdAttrib_Prog))
                    {
                        bUpdated = true;
                        SET_INT(currXdAttribStp, A_XdAttrib_Prog, attribMap[GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName)]);
                        this->m_dictEntityStp->sortedAttr[GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName)]->progN = GET_INT(currXdAttribStp, A_XdAttrib_Prog);
                    }
                }
            }

            if (bUpdated)
            {
                this->ddlGenEntityPtr->sortAttributes();

                this->m_dictEntityStp->attr.clear();

                map<INT_T, DictAttribClass*> sortedAttribMap;
                for (auto &attribIt : this->m_dictEntityStp->attribMap)
                {
                    if (attribIt.second->calcEn != DictAttr_NoMD)
                    {
                        sortedAttribMap[attribIt.second->progN] = attribIt.second;
                    }
                }
                for (auto& attribIt : sortedAttribMap)
                {
                    this->m_dictEntityStp->attr.push_back(attribIt.second);
                }
            }
        }
    }
    catch (exception& e)
    {
        ret = RET_GEN_ERR_PERSONAL;
        this->printCatchMsg(FILEINFO, e.what());
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenFullTable::manageDependencies()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-26108 - LJE - 170916
**
*************************************************************************/
RET_CODE DdlGenFullTable::manageDependencies(DictEntityClass* refDictEntityStp)
{
    RET_CODE               ret = RET_SUCCEED;
    DdlGenProcessLogger    ddlGenProcessLogger(*this, ret, "Manage Dependencies");

    if (refDictEntityStp)
    {
        ddlGenProcessLogger.m_processStr += " (";
        ddlGenProcessLogger.m_processStr += refDictEntityStp->mdSqlName;
        ddlGenProcessLogger.m_processStr += ")";
    }

    ddlGenProcessLogger.start();

    if ((this->m_dictEntityStp = DBA_GetDictEntitySt(this->objectEn)) == NULL)
    {
        return RET_DBA_INFO_NODATA;
    }

    try
    {
        DictEntityClass* analyseDictEntityStp = refDictEntityStp ? refDictEntityStp : this->m_dictEntityStp;

        if (analyseDictEntityStp->dbRuleEn != DbRule_ShadowTable &&
            analyseDictEntityStp->entNatEn != EntityNat_TempTable &&
            analyseDictEntityStp->entNatEn != EntityNat_PersistedFmt &&
            analyseDictEntityStp->entNatEn != EntityNat_SearchFmt &&
            analyseDictEntityStp->entNatEn != EntityNat_ReportFmt &&
            analyseDictEntityStp->entNatEn != EntityNat_Internal)
        {
            if (refDictEntityStp == nullptr)
            {
                if (analyseDictEntityStp->multiEntityCateg.get() == MultiEntityCategory_BusinessEntityOnly ||
                    analyseDictEntityStp->multiEntityCateg.get() == MultiEntityCategory_DerivedBusinessEntityOnly)
                {
                    for (auto it = analyseDictEntityStp->dictEntityConstrMap.begin(); it != analyseDictEntityStp->dictEntityConstrMap.end(); ++it)
                    {
                        DictEntityConstrClass& dictEntityConstrSt = it->second;

                        if (refDictEntityStp && this->m_dictEntityStp != it->second.refDictEntityStp)
                        {
                            continue;
                        }

                        if ((dictEntityConstrSt.refDictEntityStp->multiEntityCateg.get() == MultiEntityCategory_None ||
                             dictEntityConstrSt.refDictEntityStp->multiEntityCateg.get() == MultiEntityCategory_DerivedOptionalLocalization ||
                             dictEntityConstrSt.refDictEntityStp->multiEntityCateg.get() == MultiEntityCategory_DerivedMasterOnly) &&
                            dictEntityConstrSt.aggregationEn == Aggegation_Composition)
                        {
                            if (dictEntityConstrSt.refDictEntityStp->multiEntityCateg.get() != MultiEntityCategory_DerivedOptionalLocalization ||
                                dictEntityConstrSt.multiplicityEn != Multiplicity_ZeroToMany)
                            {
                                dictEntityConstrSt.refDictEntityStp->multiEntityCateg.set(MultiEntityCategory_DerivedBusinessEntityOnly);
                            }
                        }
                    }
                }
                else if (analyseDictEntityStp->multiEntityCateg.get() == MultiEntityCategory_OptionalLocalization ||
                         analyseDictEntityStp->multiEntityCateg.get() == MultiEntityCategory_OptionalSpecialisation ||
                         analyseDictEntityStp->multiEntityCateg.get() == MultiEntityCategory_DerivedOptionalLocalization)
                {
                    for (auto it = analyseDictEntityStp->dictEntityConstrMap.begin(); it != analyseDictEntityStp->dictEntityConstrMap.end(); ++it)
                    {
                        DictEntityConstrClass& dictEntityConstrSt = it->second;

                        if (refDictEntityStp && this->m_dictEntityStp != it->second.refDictEntityStp)
                        {
                            continue;
                        }

                        if ((dictEntityConstrSt.refDictEntityStp->multiEntityCateg.get() == MultiEntityCategory_None ||
                             dictEntityConstrSt.refDictEntityStp->multiEntityCateg.get() == MultiEntityCategory_DerivedMasterOnly) &&
                            dictEntityConstrSt.aggregationEn == Aggegation_Composition)
                        {
                            dictEntityConstrSt.refDictEntityStp->multiEntityCateg.set(MultiEntityCategory_DerivedOptionalLocalization);
                        }
                    }
                }
                else if (analyseDictEntityStp->multiEntityCateg.get() == MultiEntityCategory_MasterOnly ||
                         analyseDictEntityStp->multiEntityCateg.get() == MultiEntityCategory_MasterOnlyPrecOnBEOnly ||         /* PMSTA-30152 - LJE - 180509 */
                         analyseDictEntityStp->multiEntityCateg.get() == MultiEntityCategory_DerivedMasterOnly)               /* PMSTA-26554 - LJE - 181105 */
                {
                    for (auto it = analyseDictEntityStp->dictEntityConstrMap.begin(); it != analyseDictEntityStp->dictEntityConstrMap.end(); ++it)
                    {
                        DictEntityConstrClass& dictEntityConstrSt = it->second;

                        if (refDictEntityStp && this->m_dictEntityStp != it->second.refDictEntityStp)
                        {
                            continue;
                        }

                        if (dictEntityConstrSt.refDictEntityStp->multiEntityCateg.get() == MultiEntityCategory_None &&
                            dictEntityConstrSt.aggregationEn == Aggegation_Composition)
                        {
                            dictEntityConstrSt.refDictEntityStp->multiEntityCateg.set(MultiEntityCategory_DerivedMasterOnly);
                        }
                    }
                }
            }
            else
            {
                if (analyseDictEntityStp->multiEntityCateg.get() == MultiEntityCategory_BusinessEntityOnly ||
                    analyseDictEntityStp->multiEntityCateg.get() == MultiEntityCategory_DerivedBusinessEntityOnly)
                {
                    for (auto it = analyseDictEntityStp->dictEntityConstrMap.begin(); it != analyseDictEntityStp->dictEntityConstrMap.end(); ++it)
                    {
                        DictEntityConstrClass& dictEntityConstrSt = it->second;

                        if (refDictEntityStp && this->m_dictEntityStp != it->second.refDictEntityStp)
                        {
                            continue;
                        }

                        if ((dictEntityConstrSt.refDictEntityStp->multiEntityCateg.get() == MultiEntityCategory_None ||
                             dictEntityConstrSt.refDictEntityStp->multiEntityCateg.get() == MultiEntityCategory_DerivedMasterOnly) &&
                            dictEntityConstrSt.aggregationEn == Aggegation_Aggregation)
                        {
                            dictEntityConstrSt.refDictEntityStp->multiEntityCateg.set(MultiEntityCategory_DerivedBusinessEntityOnly);
                        }
                    }
                }
                else if (analyseDictEntityStp->multiEntityCateg.get() == MultiEntityCategory_OptionalLocalization ||
                         analyseDictEntityStp->multiEntityCateg.get() == MultiEntityCategory_OptionalSpecialisation ||
                         analyseDictEntityStp->multiEntityCateg.get() == MultiEntityCategory_DerivedOptionalLocalization)
                {
                    for (auto it = analyseDictEntityStp->dictEntityConstrMap.begin(); it != analyseDictEntityStp->dictEntityConstrMap.end(); ++it)
                    {
                        DictEntityConstrClass& dictEntityConstrSt = it->second;

                        if (refDictEntityStp && this->m_dictEntityStp != it->second.refDictEntityStp)
                        {
                            continue;
                        }

                        if ((dictEntityConstrSt.refDictEntityStp->multiEntityCateg.get() == MultiEntityCategory_None ||
                             dictEntityConstrSt.refDictEntityStp->multiEntityCateg.get() == MultiEntityCategory_DerivedBusinessEntityOnly ||
                             dictEntityConstrSt.refDictEntityStp->multiEntityCateg.get() == MultiEntityCategory_DerivedMasterOnly) &&
                            refDictEntityStp && dictEntityConstrSt.aggregationEn == Aggegation_Aggregation)
                        {
                            dictEntityConstrSt.refDictEntityStp->multiEntityCateg.set(MultiEntityCategory_DerivedOptionalLocalization);
                        }
                    }
                }
                else if (analyseDictEntityStp->multiEntityCateg.get() == MultiEntityCategory_MasterOnly ||
                         analyseDictEntityStp->multiEntityCateg.get() == MultiEntityCategory_MasterOnlyPrecOnBEOnly ||         /* PMSTA-30152 - LJE - 180509 */
                         analyseDictEntityStp->multiEntityCateg.get() == MultiEntityCategory_DerivedMasterOnly)               /* PMSTA-26554 - LJE - 181105 */
                {
                    for (auto it = analyseDictEntityStp->dictEntityConstrMap.begin(); it != analyseDictEntityStp->dictEntityConstrMap.end(); ++it)
                    {
                        DictEntityConstrClass& dictEntityConstrSt = it->second;

                        if (refDictEntityStp && this->m_dictEntityStp != it->second.refDictEntityStp)
                        {
                            continue;
                        }

                        if (dictEntityConstrSt.refDictEntityStp->multiEntityCateg.get() == MultiEntityCategory_None &&
                            refDictEntityStp && dictEntityConstrSt.aggregationEn == Aggegation_Aggregation)
                        {
                            dictEntityConstrSt.refDictEntityStp->multiEntityCateg.set(MultiEntityCategory_DerivedMasterOnly);
                        }
                    }
                }
            }
        }
    }
    catch (exception& e)
    {
        ret = RET_GEN_ERR_PERSONAL;
        this->printCatchMsg(FILEINFO, e.what());
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenFullTable::manageMultiEntityCategory()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-26554 - LJE - 181106
**
*************************************************************************/
RET_CODE DdlGenFullTable::manageMultiEntityCategory(bool bFirstPass)
{
    RET_CODE               ret = RET_SUCCEED;
    this->m_dictEntityStp = DBA_GetDictEntitySt(this->objectEn);

    if (this->m_dictEntityStp)
    {
        if (this->m_dictEntityStp->multiEntityCateg.get() == MultiEntityCategory_None)
        {
            if (this->m_dictEntityStp->entNatEn != EntityNat_TempTable &&
                this->m_dictEntityStp->entNatEn != EntityNat_PersistedFmt &&
                this->m_dictEntityStp->entNatEn != EntityNat_SearchFmt &&
                this->m_dictEntityStp->entNatEn != EntityNat_ReportFmt &&
                this->m_dictEntityStp->entNatEn != EntityNat_Internal &&
                (this->m_dictEntityStp->entNatEn != EntityNat_Tsl || bFirstPass == true) &&
                this->m_dictEntityStp->entNatEn != EntityNat_System &&
                this->m_dictEntityStp->entNatEn != EntityNat_Technical)
            {
                for (auto refEntityIt = this->m_dictEntityStp->dictEntityRefMap.begin();
                     refEntityIt != this->m_dictEntityStp->dictEntityRefMap.end();
                     ++refEntityIt)
                {
                    if (refEntityIt->first->featureEn != XdEntityFeatureFeatureEn::MultiBusinessEntityManagement &&
                        refEntityIt->first->calcEn != DictAttr_LastModifManagment &&
                        refEntityIt->first->calcEn != DictAttr_CreationManagment &&
                        this->m_dictEntityStp->entDictId != refEntityIt->second->entDictId)
                    {
                        if (refEntityIt->first->logicalFlg == TRUE)
                        {
                            if (refEntityIt->second->multiEntityCateg.get() == MultiEntityCategory_None)
                            {
                                ret = RET_GEN_INFO_NOACTION;
                            }
                            else if (this->m_dictEntityStp->multiEntityCateg.get() == MultiEntityCategory_None ||
                                     this->m_dictEntityStp->multiEntityCateg.get() == MultiEntityCategory_NoAccessibilityConstraint ||
                                     (this->m_dictEntityStp->multiEntityCateg.get() == MultiEntityCategory_DerivedBusinessEntityOnly && refEntityIt->second->multiEntityCateg.isAllowedOnlyInMaster()) ||
                                     (this->m_dictEntityStp->multiEntityCateg.isAllowedOnlyInMaster() && refEntityIt->second->multiEntityCateg.isBusinessEntityDependents()))
                            {
                                this->m_dictEntityStp->multiEntityCateg.setDerivedCategory(refEntityIt->second->multiEntityCateg, false);
                            }
                        }
                        else if (refEntityIt->first->dbMandatoryFlg == TRUE || bFirstPass == false)
                        {
                            if (refEntityIt->second->multiEntityCateg.get() == MultiEntityCategory_None)
                            {
                                ret = RET_GEN_INFO_NOACTION;
                            }
                            else
                            {
                                this->m_dictEntityStp->multiEntityCateg.setDerivedCategory(refEntityIt->second->multiEntityCateg, (refEntityIt->first->dbMandatoryFlg == TRUE));
                            }
                        }
                        else if (this->m_dictEntityStp->multiEntityCateg.get() == MultiEntityCategory_None ||
                                 this->m_dictEntityStp->multiEntityCateg.get() == MultiEntityCategory_NoAccessibilityConstraint ||
                                 this->m_dictEntityStp->multiEntityCateg.get() == MultiEntityCategory_TechnicalInfrastructure ||
                                 (refEntityIt->second->multiEntityCateg.isBusinessEntityDependents() && this->m_dictEntityStp->multiEntityCateg.isAllowedOnlyInMaster()))
                        {
                            this->m_dictEntityStp->multiEntityCateg.setDerivedCategory(refEntityIt->second->multiEntityCateg, false);
                        }

                        if (((bFirstPass && refEntityIt->first->logicalFlg == FALSE) || refEntityIt->first->dbMandatoryFlg) &&
                            this->m_dictEntityStp->multiEntityCateg.get() == MultiEntityCategory_DerivedBusinessEntityOnly)
                        {
                            if (this->m_dictEntityStp->linkedEntityStp != nullptr)
                            {
                                this->m_dictEntityStp->linkedEntityStp->multiEntityCateg.set(this->m_dictEntityStp->multiEntityCateg.get());
                            }
                            if (this->m_dictEntityStp->linkEntitiesMap.empty() == false)
                            {
                                for (auto it = this->m_dictEntityStp->linkEntitiesMap.begin(); it != this->m_dictEntityStp->linkEntitiesMap.end(); ++it)
                                {
                                    it->second->multiEntityCateg.set(this->m_dictEntityStp->multiEntityCateg.get());
                                }
                            }

                            if (ret == RET_GEN_INFO_NOACTION)
                            {
                                ret = RET_SUCCEED;
                            }
                            break;
                        }
                    }
                }
            }
            else if (this->m_dictEntityStp->dbRuleEn != DbRule_ShadowTable &&
                     this->m_dictEntityStp->dbRuleEn != DbRule_PartialSpecialization)
            {
                /* PMSTA - 38088 - LJE - 191211 */
                if (this->m_dictEntityStp->entNatEn == EntityNat_TempTable &&
                    this->m_dictEntityStp->linkedEntityStp != nullptr)
                {
                    if (this->m_dictEntityStp->linkedEntityStp->multiEntityCateg.get() != MultiEntityCategory_None)
                    {
                        this->m_dictEntityStp->multiEntityCateg.set(this->m_dictEntityStp->linkedEntityStp->multiEntityCateg.getDerivedCategory());
                    }
                    else if (bFirstPass == false)
                    {
                        ret = RET_GEN_INFO_NOACTION;
                    }
                }
                else
                {
                    this->m_dictEntityStp->multiEntityCateg.set(MultiEntityCategory_TechnicalInfrastructure);
                }
            }
        }
    }

    if (ret == RET_GEN_INFO_NOACTION)
    {
        if (bFirstPass == false && this->m_dictEntityStp->multiEntityCateg.get() == MultiEntityCategory_DerivedOptionalLocalization)
        {
            ret = RET_SUCCEED;
        }
        else
        {
            this->m_dictEntityStp->multiEntityCateg.set(MultiEntityCategory_None);
        }
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenFullTable::manageDerivedMultiEntityCategory()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-26108 - LJE - 170916
**
*************************************************************************/
RET_CODE DdlGenFullTable::manageDerivedMultiEntityCategory()
{
    RET_CODE               ret = RET_SUCCEED;
    this->m_dictEntityStp = DBA_GetDictEntitySt(this->objectEn);

    if (this->m_dictEntityStp != nullptr)
    {
        if (this->m_dictEntityStp->linkedEntityStp != nullptr &&
            (this->m_dictEntityStp->multiEntityCateg.get() == MultiEntityCategory_None ||
             (this->m_dictEntityStp->multiEntityCateg.isDervidedCategory() &&
              this->m_dictEntityStp->multiEntityCateg.get() != this->m_dictEntityStp->linkedEntityStp->multiEntityCateg.getDerivedCategory())))
        {
            this->m_dictEntityStp->multiEntityCateg.set(this->m_dictEntityStp->linkedEntityStp->multiEntityCateg.getDerivedCategory());
        }

        if (this->m_dictEntityStp->multiEntityCateg.get() == MultiEntityCategory_None)
        {
            this->m_dictEntityStp->multiEntityCateg.set(MultiEntityCategory_NoAccessibilityConstraint);
        }

        if (this->m_dictEntityStp->multiEntityCateg.get() != (MULTI_ENTITY_CATEGORY_ENUM)GET_ENUM(this->getXdEntityStp(), A_XdEntity_MultiEntityCategoryEn))
        {
            DdlGenProcessLogger    ddlGenProcessLogger(*this, ret, "Manage Derived Multi-Entity Category");
            ddlGenProcessLogger.start();

            if ((ret = this->initConnection()) != RET_SUCCEED)
            {
                return ret;
            }
            DdlGenConnGuard     ddlGenConnGuard(*this->ddlGenContextPtr);

            try
            {
                SET_ENUM(this->getXdEntityStp(), A_XdEntity_MultiEntityCategoryEn, this->m_dictEntityStp->multiEntityCateg.get());

                ret = this->checkAndFix();
                if (ret == RET_SUCCEED)
                {
                    ret = this->buildInMemory();
                }
            }
            catch (exception& e)
            {
                ret = RET_GEN_ERR_PERSONAL;
                this->printCatchMsg(FILEINFO, e.what());
            }

            this->finishConnection(ret);

            this->m_dictEntityStp = NULL; /* Set to NULL, the dict entity tab can change before the next step... */
        }
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenFullTable::buildInMetaDict1()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13109 - LJE - 110311
**
*************************************************************************/
RET_CODE DdlGenFullTable::buildInMetaDict1()
{
    RET_CODE               ret = RET_SUCCEED, gblRet = RET_SUCCEED;
    DdlGenProcessLogger    ddlGenProcessLogger(*this, gblRet, "Meta dictionary creation (1)");

    ddlGenProcessLogger.start();

    if (this->bbuildInMetaDict1Done)
    {
        return ret;
    }

    if ((this->m_dictEntityStp = DBA_GetDictEntitySt(this->objectEn)) == NULL ||
        (gblRet = this->initConnection()) != RET_SUCCEED)
    {
        return gblRet;
    }
    DdlGenConnGuard     ddlGenConnGuard(*this->ddlGenContextPtr);

    try
    {
        DBA_DYNFLD_STP xdEntityStp = this->getXdEntityStp();

        MemoryPool           mp;
        DdlGenRequestHelper* requestHelperPtr = this->ddlGenContextPtr->getRequestHelper();
        if (requestHelperPtr == nullptr)
        {
            requestHelperPtr = new DdlGenRequestHelper(&ddlGenConnGuard.getDbiConn(), *this->ddlGenContextPtr);
            mp.ownerObject(requestHelperPtr);
        }

        if ((ret = this->managePartitions(*requestHelperPtr)) != RET_SUCCEED)
        {
            gblRet = ret;
        }

        SET_DICT(this->shDictEntityStp, S_DictEntity_DictId, this->m_dictEntityStp->entDictId);
        SET_SYSNAME(this->shDictEntityStp, A_XdEntity_SqlName, this->m_dictEntityStp->mdSqlName);

        SET_DICT(xdEntityStp, A_XdEntity_EntityDictId, this->m_dictEntityStp->entDictId);

        DBA_DYNFLD_STP    allDictEntityStp = nullptr;
        bool              bToInsert = false;

        if (requestHelperPtr->dbaGet(DictEntity,
                                     UNUSED,
                                     this->shDictEntityStp,
                                     allDictEntityStp) != RET_SUCCEED)
        {
            /* PMSTA-46681 - LJE - 240215 - Try to get a temporary record having negative id */
            DdlGenDbaAccessGuard ddlGenDbaAccessGuard(*this->ddlGenContextPtr);
            allDictEntityStp = ddlGenDbaAccessGuard.getDdlGenDbaAccess().getRecord(DictEntity, this->shDictEntityStp, false, false);
            if (allDictEntityStp == nullptr)
            {
                allDictEntityStp = requestHelperPtr->allocDynSt(FILEINFO, A_DictEntity);
            }
            bToInsert = true;
        }

        this->ddlGenEntityPtr->getADictEntityStp() = allDictEntityStp;

        DBA_SetDfltEntityFld(DictEntity, A_DictEntity, allDictEntityStp);
        DBA_ConvertDynSt(allDictEntityStp, xdEntityStp, true);

        SET_DICT(allDictEntityStp, A_DictEntity_DictId, this->m_dictEntityStp->entDictId);
        SET_SYSNAME(allDictEntityStp, A_DictEntity_CustDatabase, this->m_dictEntityStp->custDbName.c_str());
        SET_FLAG(allDictEntityStp, A_DictEntity_DictEntityFlg, this->m_dictEntityStp->entDictIdFlg);
        SET_FLAG(allDictEntityStp, A_DictEntity_UsePrecompFlg, this->m_dictEntityStp->usePrecompFlg); /* PMSTA-25401 - LJE - 161227 */

        /* PMSTA-26108 - LJE - 171030 */
        if (this->m_dictEntityStp->linkedEntityDictId != 0)
        {
            SET_DICT(allDictEntityStp, A_DictEntity_LinkedEntityDictId, this->m_dictEntityStp->linkedEntityDictId);
        }
        else
        {
            SET_NULL_DICT(allDictEntityStp, A_DictEntity_LinkedEntityDictId);
        }

        if (this->m_dictEntityStp->physicalEntityDictId != 0)
        {
            SET_DICT(allDictEntityStp, A_DictEntity_PhysicalEntityDictId, this->m_dictEntityStp->physicalEntityDictId);
        }
        else
        {
            SET_NULL_DICT(allDictEntityStp, A_DictEntity_PhysicalEntityDictId);
        }

        if (this->m_dictEntityStp->isNullNatIndex == false)
        {
            SET_TINYINT(allDictEntityStp, A_DictEntity_NatIdx, (TINYINT_T)this->m_dictEntityStp->natIndex);
        }
        else
        {
            SET_NULL_TINYINT(allDictEntityStp, A_DictEntity_NatIdx);
        }

        if (this->m_dictEntityStp->isNullParIndex == false)
        {
            SET_TINYINT(allDictEntityStp, A_DictEntity_ParentIdx, (TINYINT_T)this->m_dictEntityStp->parIndex);
        }
        else
        {
            SET_NULL_TINYINT(allDictEntityStp, A_DictEntity_ParentIdx);
        }

        if (GET_FLAG(xdEntityStp, A_XdEntity_CustAuthFlg) == FALSE)
        {
            this->m_dictEntityStp->custSqlName[0] = 0;
            SET_NULL_SYSNAME(xdEntityStp, A_XdEntity_CustSqlName);
        }
        else if (IS_NULLFLD(xdEntityStp, A_XdEntity_CustSqlName) == FALSE)
        {
            strcpy(this->m_dictEntityStp->custSqlName, GET_SYSNAME(xdEntityStp, A_XdEntity_CustSqlName));
        }
        else
        {
            this->m_dictEntityStp->custSqlName[0] = 0;
            this->m_dictEntityStp->setDictEntitySqlNames();
            SET_SYSNAME(xdEntityStp, A_XdEntity_CustSqlName, this->m_dictEntityStp->custSqlName);
        }

        if (gblRet == RET_SUCCEED)
        {
            if (bToInsert)
            {
                requestHelperPtr->dbaCall(Insert,
                                          DictEntity,
                                          UNUSED,
                                          allDictEntityStp,
                                          10);
            }
            else
            {
                requestHelperPtr->dbaCall(Update,
                                          DictEntity,
                                          UNUSED,
                                          allDictEntityStp,
                                          10);
            }

            requestHelperPtr->dbaCall(Update,
                                      XdEntity,
                                      DBA_ROLE_STATUS,
                                      xdEntityStp,
                                      10);

            this->m_dictEntityStp->virtualEntFlg = FALSE;
        }

        if (ret != RET_SUCCEED)
        {
            gblRet = ret;
        }

        this->bbuildInMetaDict1Done = true;
    }
    catch (exception& e)
    {
        gblRet = RET_GEN_ERR_PERSONAL;
        this->printCatchMsg(FILEINFO, e.what());
    }

    this->finishConnection(gblRet);

    this->m_dictEntityStp = NULL; /* Set to NULL, the dict entity tab can change before the next step... */

    return gblRet;
}

/************************************************************************
**
**  Function    :   DdlGenFullTable::buildInMetaDict2()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13109 - LJE - 110311
**
*************************************************************************/
RET_CODE DdlGenFullTable::buildInMetaDict2()
{
    RET_CODE               ret = RET_SUCCEED;
    DdlGenProcessLogger    ddlGenProcessLogger(*this, ret, "Meta dictionary creation (2)");

    if (this->bbuildInMetaDict2Done)
    {
        return ret;
    }

    ddlGenProcessLogger.start();

    if ((this->m_dictEntityStp = DBA_GetDictEntitySt(this->objectEn)) == NULL ||
        this->initConnection() != RET_SUCCEED)
    {
        return RET_DBA_INFO_NODATA;
    }
    DdlGenConnGuard     ddlGenConnGuard(*this->ddlGenContextPtr);

    try
    {
        /* PMSTA-45413 - LJE - 210707 */
        MemoryPool           mp;
        DdlGenRequestHelper* requestHelperPtr = this->ddlGenContextPtr->getRequestHelper();
        if (requestHelperPtr == nullptr)
        {
            requestHelperPtr = new DdlGenRequestHelper(&ddlGenConnGuard.getDbiConn(), *this->ddlGenContextPtr);
            mp.ownerObject(requestHelperPtr);
        }

        if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
        {
            ret = this->insertAllAttrib(*requestHelperPtr);
        }

        /* PMSTA-24007 - LJE - 170717 */
        if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
        {
            ret = this->insertAllPartition(*requestHelperPtr);
        }

        this->bbuildInMetaDict2Done = true;
    }
    catch (exception& e)
    {
        ret = RET_GEN_ERR_PERSONAL;
        this->printCatchMsg(FILEINFO, e.what());
    }

    this->finishConnection(ret);

    this->m_dictEntityStp = NULL; /* Set to NULL, the dict entity tab can change before the next step... */

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenFullTable::buildXdIndexes()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:  PMSTA-14086 - LJE - 121004
**
*************************************************************************/
RET_CODE DdlGenFullTable::buildXdIndexes(DdlGenRequestHelper& requestHelper, DBA_IDX_FUNCTION_ENUM idxFctEn)
{
    RET_CODE        ret = RET_SUCCEED, gblRet = RET_SUCCEED;

    if (this->m_dictEntityStp == NULL)
    {
        return RET_GEN_ERR_INVARG;
    }

    if (idxFctEn == IdxFunction_ReportIdx ||
        idxFctEn == IdxFunction_PrimaryKey ||
        idxFctEn == IdxFunction_BusinessKey)
    {
        if (this->bTableToDo == false)
        {
            return ret;
        }
    }
    else if (idxFctEn == IdxFunction_UserDefinedFields)
    {
        if (this->bUdTableToDo == false)
        {
            return ret;
        }
    }

    DBA_DYNFLD_STP     xdEntityStp = this->getXdEntityStp();
    auto& xdIndexVector = this->ddlGenEntityPtr->getXdIndexVector();
    DBA_DYNFLD_STP     xdIndexStp = requestHelper.allocDynSt(FILEINFO, A_XdIndex);
    TARGET_TABLE_ENUM  targetTableEn = TargetTable_Main;

    bool bFromFmtEnity = false;
    if (this->ddlGenContextPtr->ddlGenAction.m_execModeEn == DbObjExecMod_BuildVirtualFromFmt ||
        this->m_dictEntityStp->entNatEn == EntityNat_SearchFmt ||
        this->m_dictEntityStp->entNatEn == EntityNat_PersistedFmt ||
        this->m_dictEntityStp->entNatEn == EntityNat_ReportFmt)
    {
        bFromFmtEnity = true;
    }

    string preIdxSqlName, postIdxSlqName, idxSqlName;

    if (idxFctEn == IdxFunction_ReportIdx)
    {
        postIdxSlqName = "_idx";
    }
    else if (idxFctEn == IdxFunction_PrimaryKey)
    {
        postIdxSlqName = "_pk_idx";

        if (this->ddlGenContextPtr->m_parentContext->bUseClusterIdx)
        {
            SET_FLAG_TRUE(xdIndexStp, A_XdIndex_ClusteredFlg);
        }
        else
        {
            SET_FLAG_FALSE(xdIndexStp, A_XdIndex_ClusteredFlg);
        }
    }
    else if (idxFctEn == IdxFunction_BusinessKey)
    {
        postIdxSlqName = "_bk_idx";

        for (auto it = xdIndexVector.begin(); it != xdIndexVector.end(); ++it)
        {
            DBA_DYNFLD_STP currXdIndexStp = *it;

            if (GET_FLAG(currXdIndexStp, A_XdIndex_ClusteredFlg) == TRUE &&
                strcasecmp(idxSqlName.c_str(), GET_SYSNAME(currXdIndexStp, A_XdIndex_SqlName)) != 0)
            {
                SET_FLAG_FALSE(xdIndexStp, A_XdIndex_ClusteredFlg);
                break;
            }
        }
    }
    else if (idxFctEn == IdxFunction_PrimaryKeyUDF) /* PMSTA-27179 - LJE - 170525 */
    {
        targetTableEn = TargetTable_UserDefinedFields;
        preIdxSqlName = "ud_";
        postIdxSlqName = "_pk_idx";
    }
    else if (idxFctEn == IdxFunction_PrimaryKeyPrecomp) /* PMSTA-37366 - LJE - 200205 */
    {
        targetTableEn = TargetTable_Precomp;
        preIdxSqlName = "x_";
        postIdxSlqName = "_pk_idx";
    }

    idxSqlName = preIdxSqlName +
        (preIdxSqlName.length() + postIdxSlqName.length() + strlen(this->m_dictEntityStp->mdSqlName) > GET_MAXCHARLEN(SysnameType) ?
         this->m_dictEntityStp->shortSqlname :
         this->m_dictEntityStp->mdSqlName) +    /* PMSTA-33077 - DLA - 181011 */
        postIdxSlqName;

    /* Check if the index doesn't exists */
    for (auto idxIt = xdIndexVector.begin(); idxIt != xdIndexVector.end(); ++idxIt)
    {
        DBA_DYNFLD_STP currXdIndexStp = *idxIt;

        if (IS_NULLFLD(currXdIndexStp, A_XdIndex_Id) == FALSE)
        {
            if (GET_ENUM(currXdIndexStp, A_XdIndex_IdxFctEn) == idxFctEn ||
                strcasecmp(idxSqlName.c_str(), GET_SYSNAME(currXdIndexStp, A_XdIndex_SqlName)) == 0)
            {
                xdIndexStp = currXdIndexStp;

                if (strcasecmp(idxSqlName.c_str(), GET_SYSNAME(currXdIndexStp, A_XdIndex_SqlName)) == 0)
                {
                    /* To fix the sensitive case behavior, we take the computed index name */
                    SET_SYSNAME(xdIndexStp, A_XdIndex_SqlName, idxSqlName.c_str());
                }
                SET_ENUM(xdIndexStp, A_XdIndex_IdxFctEn, idxFctEn);
                break;
            }
        }
    }

    if (IS_NULLFLD(xdIndexStp, A_XdIndex_ReverseFlg) == TRUE &&
        this->ddlGenEntityPtr->getDictEntityStp()->pkRuleEn == PkRule_Identity)
    {
        SET_FLAG(xdIndexStp, A_XdIndex_ReverseFlg, (this->ddlGenContextPtr->getCfgFileHelper().getPropertyBoolOrDefValue("IDENTITY_REVERSE_IDX", false) ? TRUE : FALSE));
    }
    if (IS_NULLFLD(xdIndexStp, A_XdIndex_Initrans) == TRUE)
    {
        SET_INT(xdIndexStp, A_XdIndex_Initrans, this->ddlGenContextPtr->getCfgFileHelper().getPropertyUnsignedOrDefValue("DEFAULT_INTRANS_VALUE", 1));
    }

    DBA_SetDfltEntityFld(XdIndex, A_XdIndex, xdIndexStp);

    if (IS_NULLFLD(xdIndexStp, A_XdIndex_Id) == TRUE)
    {
        SET_SYSNAME(xdIndexStp, A_XdIndex_SqlName, idxSqlName.c_str());

        this->copyDynFld(xdIndexStp, A_XdIndex_XdEntityId,
                         xdEntityStp, A_XdEntity_Id);

        SET_ENUM(xdIndexStp, A_XdIndex_IdxFctEn, idxFctEn);
        SET_FLAG_TRUE(xdIndexStp, A_XdIndex_UniqueFlg);
        SET_ENUM(xdIndexStp, A_XdIndex_XdStatusEn, XdStatus_Untreated);
    }
    SET_ENUM(xdIndexStp, A_XdIndex_XdActionEn, XdAction_ToInsert);

    /* PMSTA-18593 - LJE - 141030 - Remove the Business Key index if it's the same than the Primary Key */
    if (idxFctEn == IdxFunction_BusinessKey)
    {
        int i = 0;
        for (; i < this->ddlGenEntityPtr->getXdAttribNbr(); i++)
        {
            DBA_DYNFLD_STP currXdAttribStp = this->ddlGenEntityPtr->getXdAttrib(i);

            if (IS_NULLFLD(currXdAttribStp, A_XdAttrib_ProgPk) != IS_NULLFLD(currXdAttribStp, A_XdAttrib_ProgBk)) /* PMSTA-26108 - LJE - 171101 */
            {
                break;
            }
        }

        if (i == this->ddlGenEntityPtr->getXdAttribNbr())
        {
            bool bPkExists = (this->m_dictEntityStp->primKeyNbr == 0);

            if (GET_ENUM(xdIndexStp, A_XdIndex_XdStatusEn) != XdStatus_Untreated)
            {
                /* Drop existing BK */
                SET_ENUM(xdIndexStp, A_XdIndex_XdStatusEn, XdStatus_Untreated);

                auto sysXdIndexVector = this->ddlGenEntityPtr->getSysXdIndexVector();
                for (auto it = sysXdIndexVector.begin(); it != sysXdIndexVector.end(); ++it)
                {
                    if (GET_ENUM(*it, A_XdIndex_IdxFctEn) == IdxFunction_PrimaryKey)
                    {
                        bPkExists = true;
                    }
                    else if (strcasecmp(GET_SYSNAME(xdIndexStp, A_XdIndex_SqlName), GET_SYSNAME(*it, A_XdIndex_SqlName)) == 0)
                    {
                        SET_ENUM(xdIndexStp, A_XdIndex_XdStatusEn, XdStatus_Inserted);
                    }
                }
            }

            if (bPkExists && GET_ENUM(xdIndexStp, A_XdIndex_XdStatusEn) == XdStatus_Inserted)
            {
                SET_ENUM(xdIndexStp, A_XdIndex_XdActionEn, XdAction_ToPhysicallyDelete);
            }
            else
            {
                SET_ENUM(xdIndexStp, A_XdIndex_XdActionEn, XdAction_ToDelete);
            }
        }
    }
    else if ((idxFctEn == IdxFunction_PrimaryKey ||
              idxFctEn == IdxFunction_PrimaryKeyUDF))
    {
        /* PMSTA-45027 - LJE - 210526 */
        SET_FLAG_TRUE(xdIndexStp, A_XdIndex_UniqueFlg);

        /* PMSTA-49229 - LJE - 230120 */
        if (this->ddlGenDbi.isAutoIndexOnPK() || bFromFmtEnity)
        {
            SET_ENUM(xdIndexStp, A_XdIndex_XdActionEn, XdAction_ToPhysicallyDelete);
        }
    }

    /* PMSTA-49229 - LJE - 230120 */
    if (bFromFmtEnity)
    {
        SET_FLAG_FALSE(xdIndexStp, A_XdIndex_UniqueFlg);
    }

    if ((ret = this->ddlGenEntityPtr->insUpdXdIndex(requestHelper, xdIndexStp, xdEntityStp)) != RET_SUCCEED)
    {
        return ret;
    }

    if (GET_ENUM(xdIndexStp, A_XdIndex_XdActionEn) != XdAction_ToDelete)
    {
        SMALLINT_T xdIndexAttribNbr = 0;

        for (int i = 0; i < this->ddlGenEntityPtr->getXdAttribNbr(); i++)
        {
            DBA_DYNFLD_STP currXdAttribStp = this->ddlGenEntityPtr->getXdAttrib(i);

            if ((idxFctEn == IdxFunction_PrimaryKey && IS_NULLFLD(currXdAttribStp, A_XdAttrib_ProgPk) == FALSE) ||
                (idxFctEn == IdxFunction_BusinessKey && IS_NULLFLD(currXdAttribStp, A_XdAttrib_ProgBk) == FALSE) ||
                (idxFctEn == IdxFunction_ReportIdx && GET_INT(currXdAttribStp, A_XdAttrib_Prog) == 0) || /* PMSTA-22072 - LJE - 160108 */
                (idxFctEn == IdxFunction_PrimaryKeyUDF && DdlGen::getUdIdSqlName().compare(GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName)) == 0) ||
                (idxFctEn == IdxFunction_PrimaryKeyPrecomp && (DdlGen::getXIdSqlName().compare(GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName)) == 0 ||
                                                               (GET_A_XdAttrib_FeatureEn(currXdAttribStp) == XdEntityFeatureFeatureEn::MultiBusinessEntityManagement && 
                                                               GET_FLAG(currXdAttribStp, A_XdAttrib_PrecompFlg) == TRUE)))
                )
            {
                DBA_DYNFLD_STP     xdIndexAttribStp = requestHelper.allocDynSt(FILEINFO, A_XdIndexAttrib);

                this->copyDynFld(xdIndexAttribStp, A_XdIndexAttrib_XdIdxId, xdIndexStp, A_XdIndex_Id);
                SET_ENUM(xdIndexAttribStp, A_XdIndexAttrib_SortRuleEn, SortRule_Ascending);
                SET_ENUM(xdIndexAttribStp, A_XdIndexAttrib_XdActionEn, XdAction_ToInsert);
                SET_ENUM(xdIndexAttribStp, A_XdIndexAttrib_XdStatusEn, XdStatus_Untreated);
                SET_SMALLINT(xdIndexAttribStp, A_XdIndexAttrib_Rank, 0);

                /* PMSTA-21054 - LJE - 170330 */
                if (idxFctEn == IdxFunction_PrimaryKey)
                {
                    SET_SMALLINT(xdIndexAttribStp, A_XdIndexAttrib_Rank, GET_SMALLINT(currXdAttribStp, A_XdAttrib_ProgPk));
                }
                else if (idxFctEn == IdxFunction_BusinessKey)
                {
                    SET_SMALLINT(xdIndexAttribStp, A_XdIndexAttrib_Rank, GET_SMALLINT(currXdAttribStp, A_XdAttrib_ProgBk));
                }
                else if (idxFctEn == IdxFunction_PrimaryKeyPrecomp)
                {
                    if (DdlGen::getXIdSqlName().compare(GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName)) == 0)
                    {
                        SET_SMALLINT(xdIndexAttribStp, A_XdIndexAttrib_Rank, 0);
                    }
                    else
                    {
                        SET_SMALLINT(xdIndexAttribStp, A_XdIndexAttrib_Rank, xdIndexAttribNbr + 1);
                    }
                }
                else
                {
                    SET_SMALLINT(xdIndexAttribStp, A_XdIndexAttrib_Rank, xdIndexAttribNbr);
                }

                if ((ret = this->ddlGenEntityPtr->insXdIndexAttrib(requestHelper, currXdAttribStp, xdIndexStp, xdIndexAttribStp)) != RET_SUCCEED)
                {
                    gblRet = ret;
                }
                xdIndexAttribNbr++;
            }
        }

        /* PMSTA-16528 - DDV - 140625 - Index has no attribute, set it to delete */
        if (this->ddlGenContextPtr->ddlGenAction.m_execModeEn != DbObjExecMod_BuildVirtualFromFmt &&
            (xdIndexAttribNbr == 0 || 
             GET_ENUM(xdIndexStp, A_XdIndex_XdActionEn) == XdAction_ToDelete ||
             GET_ENUM(xdIndexStp, A_XdIndex_XdActionEn) == XdAction_ToPhysicallyDelete))
        {
            if (xdIndexAttribNbr == 0)
            {
                SET_ENUM(xdIndexStp, A_XdIndex_XdActionEn, XdAction_ToDelete);
            }

            if ((ret = this->ddlGenEntityPtr->insUpdXdIndex(requestHelper, xdIndexStp, xdEntityStp)) != RET_SUCCEED)
            {
                this->printMsg(ret, "Unable to create xd_index");
                return ret;
            }
        }
    }

    return gblRet;
}

/************************************************************************
**
**  Function    :   DdlGenFullTable::copyXdIndexesFromLinkedEntity()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:  PMSTA-26250 - LJE - 170428
**
*************************************************************************/
RET_CODE DdlGenFullTable::copyXdIndexesFromLinkedEntity(DdlGenRequestHelper& requestHelper)
{
    RET_CODE              ret = RET_SUCCEED, gblRet = RET_SUCCEED;

    DBA_DYNFLD_STP        xdEntityStp = this->getXdEntityStp();
    DBA_DYNFLD_STP        ousXdAttribStp = this->ddlGenEntityPtr->getXdAttribBySqlName("change_set_id");

    if (ousXdAttribStp == nullptr)
    {
        ret = RET_DBA_ERR_MD;
        this->printMsg(ret, "Unknown attribute 'change_set_id', mandatory for shadow entity");
        return ret;
    }

    if (this->m_dictEntityStp->linkedEntityStp == nullptr)
    {
        ret = RET_DBA_ERR_MD;
        this->printMsg(ret, "Unknown linked entity, mandatory for shadow entity");
        return ret;
    }

    DdlGenEntity* lnkDdlGenEntityPtr = this->ddlGenContextPtr->getDdlGenEntityPtr(this->m_dictEntityStp->linkedEntityStp->mdSqlName, string(), true);

    if (lnkDdlGenEntityPtr == nullptr)
    {
        ret = RET_DBA_ERR_MD;
        this->printMsg(ret, "Unknown linked entity information, mandatory for shadow entity");
        return ret;
    }

    auto lnkXdIndexVector = lnkDdlGenEntityPtr->getXdIndexVector();
    auto xdIndexVector = this->ddlGenEntityPtr->getXdIndexVector();

    for (auto it = lnkXdIndexVector.begin(); it != lnkXdIndexVector.end(); ++it)
    {
        DBA_DYNFLD_STP  lnkXdIndexStp = *it;
        DBA_DYNFLD_STP  xdIndexStp = requestHelper.allocDynSt(FILEINFO, A_XdIndex);

        /* PMSTA-36149 - LJE - 190611 */
        if (GET_ENUM(lnkXdIndexStp, A_XdIndex_XdActionEn) == XdAction_ToInsert ||
            (GET_ENUM(lnkXdIndexStp, A_XdIndex_XdActionEn) == XdAction_None && GET_ENUM(lnkXdIndexStp, A_XdIndex_XdStatusEn) == XdStatus_Inserted))
        {
            COPY_DYNST(xdIndexStp, *it, A_XdIndex);

            if (GET_ENUM(xdIndexStp, A_XdIndex_IdxFctEn) != IdxFunction_PrecompIdx &&
                GET_ENUM(xdIndexStp, A_XdIndex_IdxFctEn) != IdxFunction_PrimaryKeyPrecomp)
            {
                string         indexSqlName = lower(GET_SYSNAME(xdIndexStp, A_XdIndex_SqlName));
                size_t pos = indexSqlName.find(this->m_dictEntityStp->linkedEntityStp->mdSqlName);

                if (pos == string::npos)
                {
                    pos = indexSqlName.find(this->m_dictEntityStp->linkedEntityStp->shortSqlname);

                    if (pos != string::npos)
                    {
                        indexSqlName.replace(pos, strlen(this->m_dictEntityStp->linkedEntityStp->shortSqlname), this->m_dictEntityStp->shortSqlname);
                    }
                }
                else
                {
                    indexSqlName.replace(pos, strlen(this->m_dictEntityStp->linkedEntityStp->mdSqlName), this->m_dictEntityStp->shortSqlname);
                }
                if (pos == string::npos)
                {
                    indexSqlName += "_sh";
                }

                SET_NULL_ID(xdIndexStp, A_XdIndex_Id);

                /* Check if the index doesn't exists */
                for (auto idxIt = xdIndexVector.begin(); idxIt != xdIndexVector.end(); ++idxIt)
                {
                    DBA_DYNFLD_STP currXdIndexStp = *idxIt;

                    if (IS_NULLFLD(currXdIndexStp, A_XdIndex_Id) == FALSE)
                    {
                        if (strcasecmp(indexSqlName.c_str(), GET_SYSNAME(currXdIndexStp, A_XdIndex_SqlName)) == 0)
                        {
                            xdIndexStp = currXdIndexStp;
                            break;
                        }
                    }
                }

                SET_SYSNAME(xdIndexStp, A_XdIndex_SqlName, indexSqlName.c_str());
                this->copyDynFld(xdIndexStp, A_XdIndex_XdEntityId, xdEntityStp, A_XdEntity_Id);
                SET_ENUM(xdIndexStp, A_XdIndex_XdActionEn, XdAction_ToInsert);

                if ((ret = this->ddlGenEntityPtr->insUpdXdIndex(requestHelper, xdIndexStp, xdEntityStp)) != RET_SUCCEED)
                {
                    return ret;
                }

                auto& xdIndexAttribByRankMap = lnkDdlGenEntityPtr->getXdIndexAttribByRankMap(lnkXdIndexStp);

                if (xdIndexAttribByRankMap.size() == 0)
                {
                    if (GET_ENUM(xdIndexStp, A_XdIndex_XdStatusEn) == XdStatus_Inserted)
                    {
                        SET_ENUM(xdIndexStp, A_XdIndex_XdActionEn, XdAction_ToDelete);
                    }
                    else
                    {
                        SET_ENUM(xdIndexStp, A_XdIndex_XdActionEn, XdAction_None);
                        SET_ENUM(xdIndexStp, A_XdIndex_XdStatusEn, XdStatus_Untreated);
                    }

                    DBA_ACTION_ENUM actionDone = NullAction;
                    if ((ret = requestHelper.insUpdRecord(xdIndexStp, actionDone)) != RET_SUCCEED)
                    {
                        this->printMsg(ret, "Unable to update xd_index");
                        gblRet = ret;
                    }
                }
                else
                {
                    if (GET_ENUM(xdIndexStp, A_XdIndex_IdxFctEn) != IdxFunction_PrimaryKeyUDF &&
                        GET_ENUM(xdIndexStp, A_XdIndex_IdxFctEn) != IdxFunction_PrimaryKeyPrecomp)
                    {
                        DBA_DYNFLD_STP  xdIndexAttribOnOus = requestHelper.allocDynSt(FILEINFO, A_XdIndexAttrib);

                        SET_SMALLINT(xdIndexAttribOnOus, A_XdIndexAttrib_Rank, 0);
                        SET_ENUM(xdIndexAttribOnOus, A_XdIndexAttrib_SortRuleEn, SortRule_Ascending);
                        this->copyDynFld(xdIndexAttribOnOus, A_XdIndexAttrib_XdAttribId, ousXdAttribStp, A_XdAttrib_Id);
                        this->copyDynFld(xdIndexAttribOnOus, A_XdIndexAttrib_XdAttribSqlName, ousXdAttribStp, A_XdAttrib_SqlName);
                        SET_ENUM(xdIndexAttribOnOus, A_XdIndexAttrib_XdActionEn, XdAction_ToInsert);
                        SET_ENUM(xdIndexAttribOnOus, A_XdIndexAttrib_XdStatusEn, XdStatus_Untreated);

                        this->copyDynFld(xdIndexAttribOnOus, A_XdIndexAttrib_XdIdxId, xdIndexStp, A_XdIndex_Id);
                        SET_NULL_ID(xdIndexAttribOnOus, A_XdIndexAttrib_Id);
                        SET_ENUM(xdIndexAttribOnOus, A_XdIndexAttrib_XdActionEn, XdAction_ToInsert);

                        if ((ret = this->ddlGenEntityPtr->insXdIndexAttrib(requestHelper, nullptr, xdIndexStp, xdIndexAttribOnOus)) != RET_SUCCEED)
                        {
                            gblRet = ret;
                        }
                    }

                    for (auto it2 = xdIndexAttribByRankMap.begin(); it2 != xdIndexAttribByRankMap.end(); ++it2)
                    {
                        DBA_DYNFLD_STP  xdIndexAttribStp = requestHelper.allocDynSt(FILEINFO, A_XdIndexAttrib);

                        COPY_DYNST(xdIndexAttribStp, it2->second, A_XdIndexAttrib);

                        if (gblRet == RET_SUCCEED)
                        {
                            DBA_DYNFLD_STP idxXdAttribStp = this->ddlGenEntityPtr->getXdAttribBySqlName(GET_CODE(xdIndexAttribStp, A_XdIndexAttrib_XdAttribSqlName));

                            if (idxXdAttribStp)
                            {
                                SET_NULL_ID(xdIndexAttribStp, A_XdIndexAttrib_Id);
                                this->copyDynFld(xdIndexAttribStp, A_XdIndexAttrib_XdIdxId, xdIndexStp, A_XdIndex_Id);
                                this->copyDynFld(xdIndexAttribStp, A_XdIndexAttrib_XdAttribId, idxXdAttribStp, A_XdAttrib_Id);
                                SET_SMALLINT(xdIndexAttribStp, A_XdIndexAttrib_Rank, (SMALLINT_T)(GET_SMALLINT(xdIndexAttribStp, A_XdIndexAttrib_Rank) + 1));
                                SET_ENUM(xdIndexAttribStp, A_XdIndexAttrib_XdActionEn, XdAction_ToInsert);

                                if ((ret = this->ddlGenEntityPtr->insXdIndexAttrib(requestHelper, nullptr, xdIndexStp, xdIndexAttribStp)) != RET_SUCCEED)
                                {
                                    gblRet = ret;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    return gblRet;
}

/************************************************************************
**
**  Function    :   DdlGenFullTable::buildStdXdIndexes()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:  PMSTA-14086 - LJE - 121004
**
*************************************************************************/
RET_CODE DdlGenFullTable::buildStdXdIndexes(DdlGenRequestHelper& requestHelper)
{
    RET_CODE       ret = RET_SUCCEED;
    DBA_DYNFLD_STP xdEntityStp = this->getXdEntityStp();

    if (this->bStdIdxToDo)
    {
        if (GET_ENUM(xdEntityStp, A_XdEntity_NatEn) == EntityNat_DerivedEntity &&
            GET_ENUM(xdEntityStp, A_XdEntity_DbRuleEn) == DbRule_ShadowTable &&
            IS_NULLFLD(xdEntityStp, A_XdEntity_LinkedXdEntityId) == FALSE)
        {
            this->copyXdIndexesFromLinkedEntity(requestHelper);
        }
        else
        {
            if (this->bTableToDo)
            {
                ret = this->buildXdIndexes(requestHelper, IdxFunction_PrimaryKey);

                if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
                {
                    ret = this->buildXdIndexes(requestHelper, IdxFunction_BusinessKey);
                }
            }

            if (GET_ENUM(xdEntityStp, A_XdEntity_NatEn) == EntityNat_ReportFmt)
            {
                ret = this->buildXdIndexes(requestHelper, IdxFunction_ReportIdx);
            }

            if (this->bUdTableToDo)
            {
                ret = this->buildXdIndexes(requestHelper, IdxFunction_PrimaryKeyUDF);
            }

            if (this->bExtTableToDo)
            {
                ret = this->buildXdIndexes(requestHelper, IdxFunction_PrimaryKeyPrecomp);
            }
        }
    }

    auto xdIndexVector = this->ddlGenEntityPtr->getXdIndexVector();

    /* PMSTA-24007 - LJE - 170721 */
    if (GET_ENUM(xdEntityStp, A_XdEntity_PartAuthEn) == FeatureAuth_Enable)
    {
        for (auto xdIndexIt = xdIndexVector.begin(); xdIndexIt != xdIndexVector.end(); ++xdIndexIt)
        {
            DBA_DYNFLD_STP currXdIndexStp = *xdIndexIt;

            if (GET_ENUM(currXdIndexStp, A_XdIndex_ScopeEn) == IdxScope_Normal)
            {
                if (GET_FLAG(currXdIndexStp, A_XdIndex_UniqueFlg) == TRUE)
                {
                    SET_ENUM(currXdIndexStp, A_XdIndex_ScopeEn, IdxScope_GlobalIndex);
                }
                else
                {
                    SET_ENUM(currXdIndexStp, A_XdIndex_ScopeEn, IdxScope_LocalIndex);
                }

                DBA_ACTION_ENUM actionDone = NullAction;
                if ((ret = requestHelper.insUpdRecord(currXdIndexStp, actionDone)) != RET_SUCCEED)
                {
                    this->printMsg(ret, "Unable to create xd_index");
                    return ret;
                }
            }
        }
    }

    /* PMSTA-30128 - LJE - 180209 */
    for (auto xdIndexIt = xdIndexVector.begin(); xdIndexIt != xdIndexVector.end(); ++xdIndexIt)
    {
        DBA_DYNFLD_STP currXdIndexStp = *xdIndexIt;

        if (GET_ENUM(currXdIndexStp, A_XdIndex_XdActionEn) == XdAction_ToInsert)
        {
            vector<DBA_DYNFLD_STP>  newXdIndexAttribVector;
            auto& xdIndexAttribMap = this->ddlGenEntityPtr->getXdIndexAttribVector(currXdIndexStp);
            int                     xdAttribIdxNbr = 0;

            for (auto xdIndexAttribIt = xdIndexAttribMap.begin(); xdIndexAttribIt != xdIndexAttribMap.end(); ++xdIndexAttribIt)
            {
                DBA_DYNFLD_STP xdIndexAttribStp = (*xdIndexAttribIt);

                /* PMSTA-35945 - LJE - 190516 */
                if (GET_ENUM(xdIndexAttribStp, A_XdIndexAttrib_XdActionEn) == XdAction_None &&
                    (GET_ENUM(xdIndexAttribStp, A_XdIndexAttrib_XdStatusEn) == XdStatus_Untreated ||
                     GET_ENUM(xdIndexAttribStp, A_XdIndexAttrib_XdStatusEn) == XdStatus_Failed))
                {
                    SET_ENUM(xdIndexAttribStp, A_XdIndexAttrib_XdActionEn, XdAction_ToInsert);
                }

                if (GET_ENUM(xdIndexAttribStp, A_XdIndexAttrib_XdActionEn) == XdAction_ToInsert)
                {
                    if (GET_ENUM(xdEntityStp, A_XdEntity_DbRuleEn) == DbRule_Template)
                    {
                        if (this->ddlGenContextPtr->getMultiEntityLevel() != MultiEntityLevel_Active)
                        {
                            DBA_DYNFLD_STP locXdAttribStp = this->ddlGenEntityPtr->getXdAttribById(GET_ID(xdIndexAttribStp, A_XdIndexAttrib_XdAttribId));
                            if (locXdAttribStp == nullptr ||
                                GET_A_XdAttrib_FeatureEn(locXdAttribStp) == XdEntityFeatureFeatureEn::MultiBusinessEntityManagement)
                            {
                                SET_ENUM(xdIndexAttribStp, A_XdIndexAttrib_XdActionEn, XdAction_None);
                                SET_ENUM(xdIndexAttribStp, A_XdIndexAttrib_XdStatusEn, XdStatus_PhysicallyDeleted);

                                requestHelper.dbaCall(Update,
                                                      XdIndexAttrib,
                                                      DBA_ROLE_STATUS,
                                                      xdIndexAttribStp,
                                                      20,
                                                      currXdIndexStp);

                                continue;  /* To avoid useless next process */
                            }
                        }

                        SET_ENUM(xdIndexAttribStp, A_XdIndexAttrib_XdActionEn, XdAction_None);
                        SET_ENUM(xdIndexAttribStp, A_XdIndexAttrib_XdStatusEn, XdStatus_Inserted);

                        requestHelper.dbaCall(Update,
                                              XdIndexAttrib,
                                              DBA_ROLE_STATUS,
                                              xdIndexAttribStp,
                                              20,
                                              currXdIndexStp);
                    }

                    ID_T xdAttribId = GET_ID(xdIndexAttribStp, A_XdIndexAttrib_XdAttribId);
                    this->ddlGenEntityPtr->fixTemplateAttributeId(xdIndexAttribStp, A_XdIndexAttrib_XdAttribId);

                    if (IS_NULLFLD(xdIndexAttribStp, A_XdIndexAttrib_XdAttribId) == TRUE)
                    {
                        SET_ID(xdIndexAttribStp, A_XdIndexAttrib_XdAttribId, xdAttribId);
                    }

                    if (xdAttribId != GET_ID(xdIndexAttribStp, A_XdIndexAttrib_XdAttribId))
                    {
                        bool bAlreadyExists = false;
                        for (auto it = xdIndexAttribMap.begin(); it != xdIndexAttribMap.end(); ++it)
                        {
                            if (xdIndexAttribStp != (*it) &&
                                GET_ID((*it), A_XdIndexAttrib_XdAttribId) == GET_ID(xdIndexAttribStp, A_XdIndexAttrib_XdAttribId))
                            {
                                bAlreadyExists = true;
                                this->copyDynFld((*it), A_XdIndexAttrib_XdActionEn,
                                                 xdIndexAttribStp, A_XdIndexAttrib_XdActionEn);
                                this->copyDynFld((*it), A_XdIndexAttrib_Rank,
                                                 xdIndexAttribStp, A_XdIndexAttrib_Rank);
                                this->copyDynFld((*it), A_XdIndexAttrib_ColumnExpression,
                                                 xdIndexAttribStp, A_XdIndexAttrib_ColumnExpression);
                                this->copyDynFld((*it), A_XdIndexAttrib_XdActionEn,
                                                 xdIndexAttribStp, A_XdIndexAttrib_XdActionEn);

                                requestHelper.dbaCall(Update,
                                                      XdIndexAttrib,
                                                      UNUSED,
                                                      (*it),
                                                      10,
                                                      currXdIndexStp);

                                requestHelper.dbaCall(Update,
                                                      XdIndexAttrib,
                                                      DBA_ROLE_STATUS,
                                                      (*it),
                                                      20,
                                                      currXdIndexStp);

                                SET_ID(xdIndexAttribStp, A_XdIndexAttrib_XdAttribId, xdAttribId);
                                SET_ENUM(xdIndexAttribStp, A_XdIndexAttrib_XdStatusEn, XdStatus_PhysicallyDeleted);
                                SET_ENUM(xdIndexAttribStp, A_XdIndexAttrib_XdActionEn, XdAction_None);

                                requestHelper.dbaCall(Update,
                                                      XdIndexAttrib,
                                                      DBA_ROLE_STATUS,
                                                      xdIndexAttribStp,
                                                      20,
                                                      currXdIndexStp);
                            }
                        }

                        if (bAlreadyExists == false)
                        {
                            DBA_DYNFLD_STP xdNewIndexAttribStp = requestHelper.duplicateDynStp(FILEINFO, xdIndexAttribStp);
                            newXdIndexAttribVector.push_back(xdNewIndexAttribStp);
                            SET_NULL_ID(xdNewIndexAttribStp, A_XdIndexAttrib_Id);

                            SET_ID(xdIndexAttribStp, A_XdIndexAttrib_XdAttribId, xdAttribId);
                            SET_ENUM(xdIndexAttribStp, A_XdIndexAttrib_XdStatusEn, XdStatus_PhysicallyDeleted);
                            SET_ENUM(xdIndexAttribStp, A_XdIndexAttrib_XdActionEn, XdAction_None);

                            requestHelper.dbaCall(Update,
                                                  XdIndexAttrib,
                                                  DBA_ROLE_STATUS,
                                                  xdIndexAttribStp,
                                                  20,
                                                  currXdIndexStp);

                            requestHelper.dbaCall(Insert,
                                                  XdIndexAttrib,
                                                  UNUSED,
                                                  xdNewIndexAttribStp,
                                                  20,
                                                  currXdIndexStp);
                        }
                    }
                }
            }

            for (auto it = newXdIndexAttribVector.begin(); it != newXdIndexAttribVector.end(); ++it)
            {
                xdIndexAttribMap.push_back((*it));
            }

            if (GET_ENUM(xdEntityStp, A_XdEntity_DbRuleEn) != DbRule_Template)
            {
                bool           bNewIndexToDo = false;
                for (auto xdIndexAttribIt = xdIndexAttribMap.begin(); xdIndexAttribIt != xdIndexAttribMap.end(); ++xdIndexAttribIt)
                {
                    DBA_DYNFLD_STP xdIndexAttribStp = (*xdIndexAttribIt);

                    if (GET_ENUM(xdIndexAttribStp, A_XdIndexAttrib_XdActionEn) == XdAction_ToInsert)
                    {
                        xdAttribIdxNbr++;

                        if (IS_NULLFLD(xdIndexAttribStp, A_XdIndexAttrib_ColumnExpression) == TRUE &&
                            bNewIndexToDo == false)
                        {
                            std::string    sqlName;
                            std::string    colExpr;
                            DBA_DYNFLD_STP locXdAttribStp = this->ddlGenEntityPtr->getXdAttribById(GET_ID(xdIndexAttribStp, A_XdIndexAttrib_XdAttribId));

                            if (locXdAttribStp != nullptr)
                            {
                                this->ddlGenDbi.getIndexSqlName(locXdAttribStp, sqlName, colExpr, this->ddlGenContextPtr);

                                if (colExpr.empty() == false)
                                {
                                    bNewIndexToDo = true;
                                }

                                if (GET_ENUM(locXdAttribStp, A_XdAttrib_CustomFlg) != Custom_No &&
                                    GET_ENUM(currXdIndexStp, A_XdIndex_IdxFctEn) == IdxFunction_CustomKey)
                                {
                                    SET_ENUM(currXdIndexStp, A_XdIndex_IdxFctEn, IdxFunction_UserDefinedFields);

                                    requestHelper.dbaCall(Update,
                                                          XdIndex,
                                                          UNUSED,
                                                          currXdIndexStp);
                                }
                                else if (GET_FLAG(locXdAttribStp, A_XdAttrib_PrecompFlg) == TRUE &&
                                         GET_ENUM(currXdIndexStp, A_XdIndex_IdxFctEn)    == IdxFunction_CustomKey)
                                {
                                    SET_ENUM(currXdIndexStp, A_XdIndex_IdxFctEn, IdxFunction_PrecompIdx);

                                    requestHelper.dbaCall(Update,
                                                          XdIndex,
                                                          UNUSED,
                                                          currXdIndexStp);
                                }
                            }
                        }
                    }
                }

                /* Don't create index on SYS_OP_MAP_NOTNULL if only one attribute (like foreign key) */
                if (bNewIndexToDo)
                {
                    if (xdAttribIdxNbr == 1)
                    {
                        bNewIndexToDo = false;
                    }
                    else if (this->ddlGenEntityPtr->getDictEntityStp()->primKeyNbr == (xdAttribIdxNbr - 1))
                    {
                        /* Check primary key for cover */
                        int pkIdxAttribNbr = 0;

                        for (auto xdIndexAttribIt = xdIndexAttribMap.begin(); xdIndexAttribIt != xdIndexAttribMap.end(); ++xdIndexAttribIt)
                        {
                            DBA_DYNFLD_STP xdIndexAttribStp = (*xdIndexAttribIt);

                            if (GET_ENUM(xdIndexAttribStp, A_XdIndexAttrib_XdActionEn) == XdAction_ToInsert)
                            {
                                DBA_DYNFLD_STP locXdAttribStp = this->ddlGenEntityPtr->getXdAttribById(GET_ID(xdIndexAttribStp, A_XdIndexAttrib_XdAttribId));

                                if (IS_NULLFLD(locXdAttribStp, A_XdAttrib_ProgPk) == FALSE)
                                {
                                    pkIdxAttribNbr++;
                                }
                            }
                        }

                        if ((xdAttribIdxNbr - 1) == pkIdxAttribNbr)
                        {
                            bNewIndexToDo = false;
                        }
                    }
                }

                if (bNewIndexToDo &&
                    (GET_ENUM(xdEntityStp, A_XdEntity_NatEn) != EntityNat_DerivedEntity ||
                     GET_ENUM(xdEntityStp, A_XdEntity_DbRuleEn) != DbRule_ShadowTable ||
                     IS_NULLFLD(xdEntityStp, A_XdEntity_LinkedXdEntityId) == TRUE))
                {
                    string newXdIndexName = SYS_Stringer(GET_SYSNAME(currXdIndexStp, A_XdIndex_SqlName), "_tech");

                    if (newXdIndexName.length() > this->ddlGenDbi.getMaxDDLObjLength())
                    {
                        newXdIndexName = GET_SYSNAME(currXdIndexStp, A_XdIndex_SqlName);
                        newXdIndexName.replace(newXdIndexName.length() - 4, 4, "_tec");
                    }

                    /* Search in the existing indexes */
                    DBA_DYNFLD_STP newXdIndexStp = nullptr;

                    for (auto idxIt = xdIndexVector.begin(); idxIt != xdIndexVector.end(); ++idxIt)
                    {
                        if (newXdIndexName.compare(GET_SYSNAME(*idxIt, A_XdIndex_SqlName)) == 0)
                        {
                            newXdIndexStp = *idxIt;
                            break;
                        }
                    }

                    if (newXdIndexStp == nullptr)
                    {
                        newXdIndexStp = requestHelper.allocDynSt(FILEINFO, A_XdIndex);
                        COPY_DYNST(newXdIndexStp, currXdIndexStp, A_XdIndex);
                        SET_NULL_ID(newXdIndexStp, A_XdIndex_Id);
                        SET_SYSNAME(newXdIndexStp, A_XdIndex_SqlName, newXdIndexName.c_str());
                        SET_ENUM(newXdIndexStp, A_XdIndex_IdxFctEn, IdxFunction_CustomKey);
                    }

                    if (GET_ENUM(currXdIndexStp, A_XdIndex_IdxFctEn) == IdxFunction_PrecompIdx ||
                        GET_ENUM(currXdIndexStp, A_XdIndex_IdxFctEn) == IdxFunction_PrimaryKeyPrecomp)
                    {
                        SET_ENUM(newXdIndexStp, A_XdIndex_IdxFctEn, IdxFunction_PrecompIdx);
                    }

                    SET_ENUM(newXdIndexStp, A_XdIndex_XdActionEn, XdAction_ToInsert);

                    if ((ret = this->ddlGenEntityPtr->insUpdXdIndex(requestHelper, newXdIndexStp, xdEntityStp)) != RET_SUCCEED)
                    {
                        this->printMsg(ret, "Unable to create/update xd_index");
                    }

                    for (auto xdIndexAttribIt = xdIndexAttribMap.begin(); xdIndexAttribIt != xdIndexAttribMap.end(); ++xdIndexAttribIt)
                    {
                        DBA_DYNFLD_STP xdIndexAttribStp = (*xdIndexAttribIt);

                        if (GET_ID(xdIndexAttribStp, A_XdIndexAttrib_XdIdxId) != GET_ID(currXdIndexStp, A_XdIndex_Id))
                        {
                            continue;
                        }

                        if (GET_ENUM(xdIndexAttribStp, A_XdIndexAttrib_XdActionEn) == XdAction_ToInsert)
                        {
                            DBA_DYNFLD_STP newXdIndexAttribStp = requestHelper.allocDynSt(FILEINFO, A_XdIndexAttrib);

                            COPY_DYNST(newXdIndexAttribStp, xdIndexAttribStp, A_XdIndexAttrib);
                            SET_NULL_ID(newXdIndexAttribStp, A_XdIndexAttrib_XdIdxId);
                            SET_NULL_ID(newXdIndexAttribStp, A_XdIndexAttrib_Id);

                            ID_T xdAttribId = GET_ID(newXdIndexAttribStp, A_XdIndexAttrib_XdAttribId);

                            if (IS_NULLFLD(newXdIndexAttribStp, A_XdIndexAttrib_ColumnExpression) == TRUE)
                            {
                                std::string    sqlName;
                                std::string    colExpr;
                                DBA_DYNFLD_STP locXdAttribStp = this->ddlGenEntityPtr->getXdAttribById(xdAttribId);

                                if (locXdAttribStp)
                                {
                                    this->ddlGenDbi.getIndexSqlName(locXdAttribStp, sqlName, colExpr, this->ddlGenContextPtr);

                                    if (colExpr.empty() == false)
                                    {
                                        SET_STRING(newXdIndexAttribStp, A_XdIndexAttrib_ColumnExpression, colExpr.c_str());
                                    }
                                }
                            }

                            if ((ret = this->ddlGenEntityPtr->insXdIndexAttrib(requestHelper, nullptr, newXdIndexStp, newXdIndexAttribStp)) != RET_SUCCEED)
                            {
                                this->printMsg(ret, "Unable to create/update xd_index_attrib");
                            }
                        }
                    }
                }
            }

            if (GET_ENUM(xdEntityStp, A_XdEntity_DbRuleEn) == DbRule_Template)
            {
                SET_ENUM(currXdIndexStp, A_XdIndex_XdActionEn, XdAction_None);
                SET_ENUM(currXdIndexStp, A_XdIndex_XdStatusEn, XdStatus_Inserted);

                requestHelper.dbaCall(Update,
                                      XdIndexAttrib,
                                      DBA_ROLE_STATUS,
                                      currXdIndexStp,
                                      20);
            }
        }
    }

    if (this->ddlGenContextPtr->ddlGenAction.m_fromImport)
    {
        for (auto & currXdIndexStp : xdIndexVector)
        {
            bool bModified = false;
            auto& xdIndexAttribMap = this->ddlGenEntityPtr->getXdIndexAttribVector(currXdIndexStp);

            if ((GET_ENUM(currXdIndexStp, A_XdIndex_XdStatusEn) == XdStatus_Inserted &&
                 GET_ENUM(currXdIndexStp, A_XdIndex_XdActionEn) == XdAction_ToInsert) ||
                (GET_ENUM(currXdIndexStp, A_XdIndex_XdStatusEn) == XdStatus_PhysicallyDeleted &&
                 GET_ENUM(currXdIndexStp, A_XdIndex_XdActionEn) == XdAction_ToPhysicallyDelete))
            {
                for (auto & xdIndexAttribStp : xdIndexAttribMap)
                {
                    if (GET_ENUM(xdIndexAttribStp, A_XdIndexAttrib_XdActionEn) != XdAction_None &&
                        (GET_ENUM(xdIndexAttribStp, A_XdIndexAttrib_XdStatusEn) != XdStatus_Inserted ||
                         GET_ENUM(xdIndexAttribStp, A_XdIndexAttrib_XdActionEn) != XdAction_ToInsert) &&
                        (GET_ENUM(currXdIndexStp, A_XdIndex_XdStatusEn) != XdStatus_PhysicallyDeleted ||
                         GET_ENUM(currXdIndexStp, A_XdIndex_XdActionEn) != XdAction_ToPhysicallyDelete))
                    {
                        bModified = true;
                    }
                }
            }
            else if (GET_ENUM(currXdIndexStp, A_XdIndex_XdActionEn) != XdAction_None)
            {
                bModified = true;
            }

            if (bModified == false)
            {
                SET_ENUM(currXdIndexStp, A_XdIndex_XdActionEn, XdAction_None);
                for (auto& xdIndexAttribStp : xdIndexAttribMap)
                {
                    SET_ENUM(xdIndexAttribStp, A_XdIndexAttrib_XdActionEn, XdAction_None);
                }
            }
        }
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenFullTable::processHelpDocument()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
RET_CODE DdlGenFullTable::processHelpDocument()
{
    RET_CODE         ret = RET_SUCCEED;
    std::string helpDocSync = SYS_GetEnvStringOrDefValue("AAA_CHK_UPD_HELPDOC_SYNC", "FALSE");

    DdlGenProcessLogger    ddlGenProcessLogger(*this, ret, "Help Document creation");

    ddlGenProcessLogger.start();

    if ((this->m_dictEntityStp = DBA_GetDictEntitySt(this->objectEn)) == NULL ||
        this->initConnection() != RET_SUCCEED)
    {
        return RET_DBA_INFO_NODATA;
    }

    DdlGenConnGuard     ddlGenConnGuard(*this->ddlGenContextPtr);
    DdlGenDbaAccessGuard ddlGenDbaAccessGuard(*this->ddlGenContextPtr);

    MemoryPool           mp;
    DdlGenRequestHelper* requestHelperPtr = this->ddlGenContextPtr->getRequestHelper();
    if (requestHelperPtr == nullptr)
    {
        requestHelperPtr = new DdlGenRequestHelper(&ddlGenConnGuard.getDbiConn(), *this->ddlGenContextPtr);
        mp.ownerObject(requestHelperPtr);
    }

    ID_T xdEntityDocId = 0;
    ID_T xdAttributeDocId = 0;
    auto &xdHelpDocMap = ddlGenDbaAccessGuard.getDdlGenDbaAccess().getHelpDoc();
    auto xdEntityStp = this->getXdEntityStp();

    bool entityExcluded = (GET_ENUM(xdEntityStp, A_XdEntity_NatEn) == EntityNat_DerivedEntity || GET_ENUM(xdEntityStp, A_XdEntity_NatEn) == EntityNat_Packaging ||
        GET_ENUM(xdEntityStp, A_XdEntity_NatEn) == EntityNat_CustomDS || GET_ENUM(xdEntityStp, A_XdEntity_NatEn) == EntityNat_Custom ||
        GET_ENUM(xdEntityStp, A_XdEntity_NatEn) == EntityNat_Technical || GET_ENUM(xdEntityStp, A_XdEntity_NatEn) == EntityNat_TempTable || GET_ENUM(xdEntityStp, A_XdEntity_NatEn) == EntityNat_Questionnaire);

    if (xdEntityStp != nullptr)
    {
        auto m_xdEntityHelpDocStp = xdHelpDocMap[XdEntityDoc][GET_ID(xdEntityStp, A_XdEntity_Id)];
        /* Copy xd_entity_doc to dict_entity_doc */
        if (m_xdEntityHelpDocStp != nullptr)
        {
            if (GET_A_XdEntityDoc_StatusEn(m_xdEntityHelpDocStp) == DocumentationTemplateStatusEn::InProgress ||
                GET_A_XdEntityDoc_StatusEn(m_xdEntityHelpDocStp) == DocumentationTemplateStatusEn::Active)
            {
                if (IS_NULLFLD(xdEntityStp, A_XdEntity_EntityDictId) == FALSE &&
                    GET_ENUM(xdEntityStp, A_XdEntity_XdStatusEn) != XdStatus_Deleted)
                {
                    DBA_DYNFLD_STP   dictEntHelpDocStp = requestHelperPtr->allocDynSt(FILEINFO, A_DictEntityDoc);
                    DBA_SetDfltEntityFld(DictEntityDoc, A_DictEntityDoc, dictEntHelpDocStp);
                    CONVERT_DYNST(dictEntHelpDocStp, A_DictEntityDoc, m_xdEntityHelpDocStp, A_XdEntityDoc);
                    SET_NULL_ID(dictEntHelpDocStp, A_DictEntityDoc_Id);
                    SET_ID(dictEntHelpDocStp, A_DictEntityDoc_ObjId, GET_ID(xdEntityStp, A_XdEntity_EntityDictId));
                    SET_ENUM(dictEntHelpDocStp, A_DictEntityDoc_StatusEn, DocumentationTemplateStatusEn::Active);

                    DBA_ACTION_ENUM actionDone = NullAction;
                    requestHelperPtr->insUpdRecord(dictEntHelpDocStp, actionDone);

                    SET_ENUM(m_xdEntityHelpDocStp, A_XdEntityDoc_StatusEn, DocumentationTemplateStatusEn::Active);

                    requestHelperPtr->dbaCall(Update,
                        XdEntityDoc,
                        DBA_ROLE_STATUS,
                        m_xdEntityHelpDocStp);

                    xdEntityDocId = GET_ID(m_xdEntityHelpDocStp, A_XdEntityDoc_Id);
                }
            }
        }
        else
        {
            if (helpDocSync == "TRUE" && entityExcluded == FALSE)
            {
                DBA_DYNFLD_STP   m_xdEntityDocStp = requestHelperPtr->allocDynSt(FILEINFO, A_XdEntityDoc);
                DBA_SetDfltEntityFld(XdEntityDoc, A_XdEntityDoc, m_xdEntityDocStp);
                SET_ID(m_xdEntityDocStp, A_XdEntityDoc_ObjId, GET_ID(xdEntityStp, A_XdEntity_Id));
                SET_ENUM(m_xdEntityDocStp, A_XdEntityDoc_StatusEn, DocumentationTemplateStatusEn::NotStarted);

                DBA_DYNFLD_STP outPtr = mp.allocDynst(FILEINFO, A_XdEntityDoc);

                if ((ret = DBA_Get2(XdEntityDoc,
                    UNUSED,
                    A_XdEntityDoc,
                    m_xdEntityDocStp,
                    A_XdEntityDoc,
                    &outPtr,
                    UNUSED,
                    UNUSED,
                    UNUSED)) != RET_SUCCEED)
                {
                    if ((ret = DBA_Insert2(XdEntityDoc,
                        UNUSED,
                        A_XdEntityDoc,
                        m_xdEntityDocStp,
                        UNUSED,
                        UNUSED)) != RET_SUCCEED)
                    {
                        MSG_SendMesg(RET_DBA_ERR_INSERT_FAILED, 0, FILEINFO);
                        ret = RET_DBA_ERR_INSERT_FAILED;
                    }
                }
                
                ret = DBA_Update2(XdEntityDoc,
                    DBA_ROLE_STATUS,
                    A_XdEntityDoc,
                    m_xdEntityDocStp,
                    UNUSED,
                    UNUSED);

                xdEntityDocId = GET_ID(m_xdEntityDocStp, A_XdEntityDoc_Id);
            }
        }

        for (int i = 0; i < this->ddlGenEntityPtr->getXdAttribNbr(); i++)
        {
            /* Copy xd_attribute_doc to dict_attribute_doc */
            auto xdAttributeStp = this->ddlGenEntityPtr->getXdAttrib(i);
            auto xdAttribHelpDocStp = xdHelpDocMap[XdAttributeDoc][GET_ID(xdAttributeStp, A_XdAttrib_Id)];

            bool attributeExcluded = (GET_A_XdAttrib_FeatureEn(xdAttributeStp) == XdEntityFeatureFeatureEn::Creation || GET_A_XdAttrib_FeatureEn(xdAttributeStp) == XdEntityFeatureFeatureEn::LastModification);

            if (xdAttribHelpDocStp != nullptr)
            {
                if (GET_A_XdEntityDoc_StatusEn(xdAttribHelpDocStp) == DocumentationTemplateStatusEn::InProgress ||
                    GET_A_XdEntityDoc_StatusEn(xdAttribHelpDocStp) == DocumentationTemplateStatusEn::Active)
                {
                    if (IS_NULLFLD(xdAttributeStp, A_XdAttrib_AttribDictId) == FALSE &&
                        GET_ENUM(xdAttributeStp, A_XdAttrib_XdStatusEn) != XdStatus_Deleted)
                    {
                        DBA_DYNFLD_STP   dictAttribHelpDocStp = requestHelperPtr->allocDynSt(FILEINFO, A_DictAttributeDoc);
                        DBA_SetDfltEntityFld(DictAttributeDoc, A_DictAttributeDoc, dictAttribHelpDocStp);
                        CONVERT_DYNST(dictAttribHelpDocStp, A_DictAttributeDoc, xdAttribHelpDocStp, A_XdAttributeDoc);
                        SET_NULL_ID(dictAttribHelpDocStp, A_DictAttributeDoc_Id);
                        SET_ID(dictAttribHelpDocStp, A_DictAttributeDoc_ObjId, GET_ID(xdAttributeStp, A_XdAttrib_AttribDictId));
                        SET_ENUM(dictAttribHelpDocStp, A_DictAttributeDoc_StatusEn, DocumentationTemplateStatusEn::Active);

                        DBA_ACTION_ENUM actionDone = NullAction;
                        requestHelperPtr->insUpdRecord(dictAttribHelpDocStp, actionDone);

                        SET_ENUM(xdAttribHelpDocStp, A_XdAttributeDoc_StatusEn, DocumentationTemplateStatusEn::Active);

                        requestHelperPtr->dbaCall(Update,
                            XdAttributeDoc,
                            DBA_ROLE_STATUS,
                            xdAttribHelpDocStp);

                        xdAttributeDocId = GET_ID(xdAttribHelpDocStp, A_XdAttributeDoc_Id);
                    }
                }
            }
            else
            {
                if (xdAttributeStp != nullptr && helpDocSync == "TRUE" && attributeExcluded == FALSE)
                {
                    if (xdEntityDocId != 0)
                    {
                        DBA_DYNFLD_STP   xdAttribDocStp = requestHelperPtr->allocDynSt(FILEINFO, A_XdAttributeDoc);
                        DBA_SetDfltEntityFld(XdAttributeDoc, A_XdAttributeDoc, xdAttribDocStp);
                        SET_ID(xdAttribDocStp, A_XdAttributeDoc_ObjId, GET_ID(xdAttributeStp, A_XdAttrib_Id));
                        SET_ENUM(xdAttribDocStp, A_XdAttributeDoc_StatusEn, DocumentationTemplateStatusEn::NotStarted);
                        SET_ID(xdAttribDocStp, A_XdAttributeDoc_XdEntityDocId, xdEntityDocId);

                        DBA_DYNFLD_STP outPtr = mp.allocDynst(FILEINFO, A_XdAttributeDoc);

                        if ((ret = DBA_Get2(XdAttributeDoc,
                            UNUSED,
                            A_XdAttributeDoc,
                            xdAttribDocStp,
                            A_XdAttributeDoc,
                            &outPtr,
                            UNUSED,
                            UNUSED,
                            UNUSED)) != RET_SUCCEED)
                        {
                            if ((ret = DBA_Insert2(XdAttributeDoc,
                                UNUSED,
                                A_XdAttributeDoc,
                                xdAttribDocStp,
                                UNUSED,
                                UNUSED)) != RET_SUCCEED)
                            {
                                MSG_SendMesg(RET_DBA_ERR_INSERT_FAILED, 0, FILEINFO);
                                ret = RET_DBA_ERR_INSERT_FAILED;
                            }
                        }

                        ret = DBA_Update2(XdAttributeDoc,
                            DBA_ROLE_STATUS,
                            A_XdAttributeDoc,
                            xdAttribDocStp,
                            UNUSED,
                            UNUSED);

                        xdAttributeDocId = GET_ID(xdAttribDocStp, A_XdAttributeDoc_Id);

                    }

                }
            }

            if (IS_NULLFLD(xdAttributeStp, A_XdAttrib_ParentXdAttribId) && attributeExcluded == FALSE)
            {
                /* Copy xd_perm_val_doc to dict_perm_val_doc */
                auto xdAttribPermValMap = this->ddlGenEntityPtr->getXdPermValByAttribMap(GET_ID(xdAttributeStp, A_XdAttrib_Id));

                if (xdAttribPermValMap != nullptr)
                {
                    for (auto permValIt = xdAttribPermValMap->begin(); permValIt != xdAttribPermValMap->end(); ++permValIt)
                    {
                        auto xdPermValHelpDocStp = xdHelpDocMap[XdPermValDoc][GET_ID(permValIt->second, A_XdPermVal_Id)];

                        if (xdPermValHelpDocStp != nullptr &&
                            GET_ENUM(permValIt->second, A_XdPermVal_XdStatusEn) != XdStatus_Deleted)
                        {
                            if (GET_A_XdEntityDoc_StatusEn(xdPermValHelpDocStp) == DocumentationTemplateStatusEn::InProgress ||
                                GET_A_XdEntityDoc_StatusEn(xdPermValHelpDocStp) == DocumentationTemplateStatusEn::Active)
                            {
                                DICT_ATTRIB_STP dictAttrib = DBA_GetAttributeById(GET_DICT(xdAttributeStp, A_XdAttrib_AttribDictId));

                                auto &dictPermValStp = dictAttrib->permValMap[GET_SMALLINT(permValIt->second, A_XdPermVal_Rank)];

                                if (permValIt->second != nullptr)
                                {
                                    DBA_DYNFLD_STP   dictPermValHelpDocStp = requestHelperPtr->allocDynSt(FILEINFO, A_DictPermValDoc);
                                    DBA_SetDfltEntityFld(DictPermValDoc, A_DictPermValDoc, dictPermValHelpDocStp);
                                    CONVERT_DYNST(dictPermValHelpDocStp, A_DictPermValDoc, xdPermValHelpDocStp, A_XdPermValDoc);
                                    SET_NULL_ID(dictPermValHelpDocStp, A_DictPermValDoc_Id);
                                    SET_ID(dictPermValHelpDocStp, A_DictPermValDoc_ObjId, dictPermValStp.dictId);
                                    SET_ENUM(dictPermValHelpDocStp, A_DictPermValDoc_StatusEn, DocumentationTemplateStatusEn::Active);

                                    DBA_ACTION_ENUM actionDone = NullAction;
                                    requestHelperPtr->insUpdRecord(dictPermValHelpDocStp, actionDone);

                                    SET_ENUM(xdPermValHelpDocStp, A_XdPermValDoc_StatusEn, DocumentationTemplateStatusEn::Active);

                                    requestHelperPtr->dbaCall(Update,
                                        XdPermValDoc,
                                        DBA_ROLE_STATUS,
                                        xdPermValHelpDocStp);
                                }
                            }
                        }
                        else
                        {
                            if (permValIt->second != nullptr && helpDocSync == "TRUE")
                            {
                                if (xdAttributeDocId != 0)
                                {
                                    DBA_DYNFLD_STP   xdPermValDocStp = requestHelperPtr->allocDynSt(FILEINFO, A_XdPermValDoc);
                                    DBA_SetDfltEntityFld(XdPermValDoc, A_XdPermValDoc, xdPermValDocStp);
                                    SET_ID(xdPermValDocStp, A_XdPermValDoc_ObjId, GET_ID(permValIt->second, A_XdPermVal_Id));
                                    SET_ENUM(xdPermValDocStp, A_XdPermValDoc_StatusEn, DocumentationTemplateStatusEn::NotStarted);
                                    SET_ID(xdPermValDocStp, A_XdPermValDoc_XdAttribDocId, xdAttributeDocId);

                                    DBA_ACTION_ENUM actionDone = NullAction;
                                    requestHelperPtr->insUpdRecord(xdPermValDocStp, actionDone, permValIt->second);
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    this->finishConnection(ret);
    return ret;

}

/************************************************************************
**
**  Function    :   DdlGenFullTable::buildLabelsInMetaDict()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13109 - LJE - 110311
**
*************************************************************************/
RET_CODE DdlGenFullTable::buildLabelsInMetaDict()
{
    RET_CODE         ret = RET_SUCCEED;
    DBA_DYNFLD_STP* xdAttribByIdTab = NULL;

    DdlGenProcessLogger    ddlGenProcessLogger(*this, ret, "Labels creation");

    ddlGenProcessLogger.start();

    if ((this->m_dictEntityStp = DBA_GetDictEntitySt(this->objectEn)) == NULL ||
        this->initConnection() != RET_SUCCEED)
    {
        return RET_DBA_INFO_NODATA;
    }
    DdlGenConnGuard     ddlGenConnGuard(*this->ddlGenContextPtr);
    DdlGenDbaAccessGuard ddlGenDbaAccessGuard(*this->ddlGenContextPtr);

    if (this->getDdlGenAction().m_mainDdlObjNatEn != DbObjDdlObjNat_ReportFmt)
    {
        ddlGenDbaAccessGuard.getDdlGenDbaAccess().getLabels(*this->getDdlGenEntityPtr());
    }

    if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
    {
        MemoryPool           mp;
        DdlGenRequestHelper* requestHelperPtr = this->ddlGenContextPtr->getRequestHelper();
        if (requestHelperPtr == nullptr)
        {
            requestHelperPtr = new DdlGenRequestHelper(&ddlGenConnGuard.getDbiConn(), *this->ddlGenContextPtr);
            mp.ownerObject(requestHelperPtr);
        }

        DICT_T xdEntityDictId, xdAttribDictId, xdPermValDictId;
        DICT_T entityDictId, attribDictId, permValDictId, criteriaDictId;

        DBA_GetDictId(XdEntity, &xdEntityDictId);
        DBA_GetDictId(XdAttrib, &xdAttribDictId);
        DBA_GetDictId(XdPermVal, &xdPermValDictId);

        DBA_GetDictId(DictEntity, &entityDictId);
        DBA_GetDictId(DictAttr, &attribDictId);
        DBA_GetDictId(DictPermVal, &permValDictId);
        DBA_GetDictId(DictCriter, &criteriaDictId);

        if (this->ddlGenEntityPtr->getXdAttribNbr() > 0)
        {
            xdAttribByIdTab = this->ddlGenEntityPtr->getSortedXdAttribTab((TLS_CMPFCT*)DDL_CmpXdAttribById);
            mp.owner(xdAttribByIdTab);
        }

        for (auto& xdLabelNatIt : this->ddlGenEntityPtr->m_xdEntityLabelMap)
        {
            if (xdLabelNatIt.second.empty() == false)
            {
                for (auto xdLabelIt = xdLabelNatIt.second.end(); xdLabelIt != xdLabelNatIt.second.begin();)
                {
                    --xdLabelIt;

                    DBA_DYNFLD_STP dictEntityStp = ddlGenDbaAccessGuard.getDdlGenDbaAccess().getRecordById(DictEntity, GET_DICT(this->getXdEntityStp(), A_XdEntity_EntityDictId), true);
                    XD_STATUS_ENUM xdStatus = XdStatus_Inserted;

                    if (dictEntityStp != nullptr)
                    {
                        DBA_DYNFLD_STP   dictLabelStp = requestHelperPtr->allocDynSt(FILEINFO, A_DictLabel);
                        DBA_ConvertDynSt(dictLabelStp, xdLabelIt->second, true);

                        SET_DICT(dictLabelStp, A_DictLabel_EntDictId, entityDictId);
                        SET_DICT(dictLabelStp, A_DictLabel_ObjDictId, GET_DICT(this->getXdEntityStp(), A_XdEntity_EntityDictId));

                        if (GET_ENUM(xdLabelIt->second, A_XdLabel_XdActionEn) == XdAction_ToInsert ||
                            (GET_ENUM(xdLabelIt->second, A_XdLabel_XdActionEn) == XdAction_None &&
                             GET_ENUM(xdLabelIt->second, A_XdLabel_XdStatusEn) == XdStatus_Inserted))
                        {
                            DBA_ACTION_ENUM actionDone = NullAction;
                            requestHelperPtr->insUpdRecord(dictLabelStp, actionDone, dictEntityStp);
                        }
                        else
                        {
                            xdStatus = XdStatus_PhysicallyDeleted;

                            requestHelperPtr->dbaCall(Delete,
                                                      DictLabel,
                                                      UNUSED,
                                                      dictLabelStp);
                        }
                    }

                    SET_ENUM(xdLabelIt->second, A_XdLabel_XdActionEn, XdAction_None);
                    SET_ENUM(xdLabelIt->second, A_XdLabel_XdStatusEn, xdStatus);
                    requestHelperPtr->dbaCall(Update,
                                              XdLabel,
                                              DBA_ROLE_STATUS,
                                              xdLabelIt->second,
                                              MAX_SHORT,
                                              this->getXdEntityStp());


                    for (auto it = xdLabelNatIt.second.begin(); it != xdLabelIt; ++it)
                    {
                        SET_ENUM(it->second, A_XdLabel_XdActionEn, XdAction_None);
                        SET_ENUM(it->second, A_XdLabel_XdStatusEn, xdStatus);
                        requestHelperPtr->dbaCall(Update,
                                                  XdLabel,
                                                  DBA_ROLE_STATUS,
                                                  it->second,
                                                  MAX_SHORT,
                                                  this->getXdEntityStp());
                    }

                    if (xdStatus == XdStatus_Inserted)
                    {
                        break;
                    }
                }
            }
        }

        for (auto& xdLabelAttribIt : this->ddlGenEntityPtr->m_xdAttribLabelMap)
        {
            if (xdLabelAttribIt.second.empty() == false)
            {
                DBA_DYNFLD_STP xdAttribStp = ddlGenDbaAccessGuard.getDdlGenDbaAccess().getRecordById(XdAttrib, xdLabelAttribIt.first, true);
                DBA_DYNFLD_STP dictCriteriaStp = nullptr;

                if (xdAttribStp != nullptr &&
                    (GET_ENUM(xdAttribStp, A_XdAttrib_XdActionEn) == XdAction_ToDelete ||
                     GET_ENUM(xdAttribStp, A_XdAttrib_XdActionEn) == XdAction_ToPhysicallyDelete ||
                     GET_ENUM(xdAttribStp, A_XdAttrib_XdActionEn) == XdAction_ToInsert ||
                     (GET_ENUM(xdAttribStp, A_XdAttrib_XdActionEn) == XdAction_None &&
                      GET_ENUM(xdAttribStp, A_XdAttrib_XdStatusEn) == XdStatus_Inserted)))
                {
                    DictCriterClass *shortDictCriteriaPtr = nullptr;

                    if (IS_NULLFLD(xdAttribStp, A_XdAttrib_ShortIdx) == false)
                    {
                        auto criterIt = this->m_dictEntityStp->shortDictCriteriaMap.find(GET_INT(xdAttribStp, A_XdAttrib_ShortIdx));
                        if (criterIt != this->m_dictEntityStp->shortDictCriteriaMap.end())
                        {
                            shortDictCriteriaPtr = criterIt->second;
                            dictCriteriaStp = ddlGenDbaAccessGuard.getDdlGenDbaAccess().getRecordById(DictCriter, criterIt->second->dictId, true);
                        }
                        else
                        {
                            SYS_BreakOnDebug();
                        }
                    }

                    for (auto &xdLabelNatIt : xdLabelAttribIt.second)
                    {
                        if (xdLabelNatIt.second.empty() == false)
                        {
                            for (auto xdLabelIt = xdLabelNatIt.second.end(); xdLabelIt != xdLabelNatIt.second.begin();)
                            {
                                --xdLabelIt;

                                XD_STATUS_ENUM  xdStatus = XdStatus_Inserted;

                                if (dictCriteriaStp != nullptr)
                                {
                                    DBA_DYNFLD_STP   dictLabelStp = requestHelperPtr->allocDynSt(FILEINFO, A_DictLabel);
                                    DBA_ConvertDynSt(dictLabelStp, xdLabelIt->second, true);

                                    SET_DICT(dictLabelStp, A_DictLabel_EntDictId, criteriaDictId);
                                    SET_DICT(dictLabelStp, A_DictLabel_ObjDictId, GET_DICT(dictCriteriaStp, A_DictCriter_DictId));

                                    if (GET_ENUM(xdAttribStp, A_XdAttrib_XdActionEn) != XdAction_ToDelete &&
                                        GET_ENUM(xdAttribStp, A_XdAttrib_XdActionEn) != XdAction_ToPhysicallyDelete &&
                                        (GET_ENUM(xdLabelIt->second, A_XdLabel_XdActionEn) == XdAction_ToInsert ||
                                         (GET_ENUM(xdLabelIt->second, A_XdLabel_XdActionEn) == XdAction_None &&
                                          GET_ENUM(xdLabelIt->second, A_XdLabel_XdStatusEn) == XdStatus_Inserted)))
                                    {
                                        DBA_ACTION_ENUM actionDone = NullAction;
                                        requestHelperPtr->insUpdRecord(dictLabelStp, actionDone, dictCriteriaStp);

                                        if (shortDictCriteriaPtr != nullptr &&
                                            shortDictCriteriaPtr->bkDictCriteriaVector.empty() == false)
                                        {
                                            for (auto &criterIt : shortDictCriteriaPtr->bkDictCriteriaVector)
                                            {
                                                auto denormDictCriteriaStp = ddlGenDbaAccessGuard.getDdlGenDbaAccess().getRecordById(DictCriter, criterIt->dictId, true);

                                                DBA_DYNFLD_STP   denormDictLabelStp = requestHelperPtr->allocDynSt(FILEINFO, A_DictLabel);
                                                CONVERT_DYNST(denormDictLabelStp, A_DictLabel, xdLabelIt->second, A_XdLabel);

                                                SET_DICT(denormDictLabelStp, A_DictLabel_EntDictId, criteriaDictId);
                                                SET_DICT(denormDictLabelStp, A_DictLabel_ObjDictId, GET_DICT(denormDictCriteriaStp, A_DictCriter_DictId));

                                                requestHelperPtr->insUpdRecord(denormDictLabelStp, actionDone, denormDictCriteriaStp);
                                            }
                                        }
                                    }
                                    else
                                    {
                                        xdStatus = XdStatus_PhysicallyDeleted;

                                        requestHelperPtr->dbaCall(Delete,
                                                                  DictLabel,
                                                                  UNUSED,
                                                                  dictLabelStp);
                                    }
                                }

                                if (IS_NULLFLD(xdAttribStp, A_XdAttrib_AttribDictId) == false)
                                {
                                    DBA_DYNFLD_STP   dictLabelStp = requestHelperPtr->allocDynSt(FILEINFO, A_DictLabel);
                                    DBA_ConvertDynSt(dictLabelStp, xdLabelIt->second, true);

                                    DBA_DYNFLD_STP dictAttribStp = ddlGenDbaAccessGuard.getDdlGenDbaAccess().getRecordById(DictAttr, GET_DICT(xdAttribStp, A_XdAttrib_AttribDictId), true);

                                    if (dictAttribStp != nullptr)
                                    {
                                        SET_DICT(dictLabelStp, A_DictLabel_EntDictId, attribDictId);
                                        SET_DICT(dictLabelStp, A_DictLabel_ObjDictId, GET_DICT(xdAttribStp, A_XdAttrib_AttribDictId));

                                        if (GET_ENUM(xdLabelIt->second, A_XdLabel_XdActionEn) == XdAction_ToInsert ||
                                            (GET_ENUM(xdLabelIt->second, A_XdLabel_XdActionEn) == XdAction_None &&
                                             GET_ENUM(xdLabelIt->second, A_XdLabel_XdStatusEn) == XdStatus_Inserted))
                                        {
                                            DBA_ACTION_ENUM actionDone = NullAction;

                                            xdStatus = XdStatus_Inserted;
                                            requestHelperPtr->insUpdRecord(dictLabelStp, actionDone, dictAttribStp);
                                        }
                                        else
                                        {
                                            xdStatus = XdStatus_PhysicallyDeleted;

                                            requestHelperPtr->dbaCall(Delete,
                                                                      DictLabel,
                                                                      UNUSED,
                                                                      dictLabelStp);
                                        }
                                    }
                                }

                                SET_ENUM(xdLabelIt->second, A_XdLabel_XdActionEn, XdAction_None);
                                SET_ENUM(xdLabelIt->second, A_XdLabel_XdStatusEn, xdStatus);
                                requestHelperPtr->dbaCall(Update,
                                                          XdLabel,
                                                          DBA_ROLE_STATUS,
                                                          xdLabelIt->second,
                                                          MAX_SHORT,
                                                          xdAttribStp);


                                for (auto it = xdLabelNatIt.second.begin(); it != xdLabelIt; ++it)
                                {
                                    SET_ENUM(it->second, A_XdLabel_XdActionEn, XdAction_None);
                                    SET_ENUM(it->second, A_XdLabel_XdStatusEn, xdStatus);
                                    requestHelperPtr->dbaCall(Update,
                                                              XdLabel,
                                                              DBA_ROLE_STATUS,
                                                              it->second,
                                                              MAX_SHORT,
                                                              xdAttribStp);

                                }

                                if (xdStatus == XdStatus_Inserted)
                                {
                                    break;
                                }
                            }
                        }
                    }
                }
            }
        }

        for (auto xdLabelPermValIt = this->ddlGenEntityPtr->m_xdPermValLabelMap.begin(); xdLabelPermValIt != this->ddlGenEntityPtr->m_xdPermValLabelMap.end(); ++xdLabelPermValIt)
        {
            if (xdLabelPermValIt->second.empty() == false)
            {
                DBA_DYNFLD_STP xdPermValStp = ddlGenDbaAccessGuard.getDdlGenDbaAccess().getRecordById(XdPermVal, xdLabelPermValIt->first, true);

                if (xdPermValStp != nullptr &&
                    GET_ENUM(xdPermValStp, A_XdPermVal_XdActionEn) == XdAction_ToInsert ||
                    GET_ENUM(xdPermValStp, A_XdPermVal_XdActionEn) == XdAction_ToDelete ||
                    GET_ENUM(xdPermValStp, A_XdPermVal_XdActionEn) == XdAction_ToPhysicallyDelete ||
                    (GET_ENUM(xdPermValStp, A_XdPermVal_XdActionEn) == XdAction_None &&
                     GET_ENUM(xdPermValStp, A_XdPermVal_XdStatusEn) == XdStatus_Inserted))
                {
                    for (auto xdLabelNatIt = xdLabelPermValIt->second.begin(); xdLabelNatIt != xdLabelPermValIt->second.end(); ++xdLabelNatIt)
                    {
                        if (xdLabelNatIt->second.empty() == false)
                        {
                            for (auto xdLabelIt = xdLabelNatIt->second.end(); xdLabelIt != xdLabelNatIt->second.begin();)
                            {
                                --xdLabelIt;

                                XD_STATUS_ENUM xdStatus = XdStatus_Inserted;
                                DBA_DYNFLD_STP dictPermValStp = ddlGenDbaAccessGuard.getDdlGenDbaAccess().getRecordById(DictPermVal, GET_DICT(xdPermValStp, A_XdPermVal_DictId), true);

                                if (dictPermValStp != nullptr)
                                {
                                    DBA_DYNFLD_STP   dictLabelStp = requestHelperPtr->allocDynSt(FILEINFO, A_DictLabel);

                                    DBA_ConvertDynSt(dictLabelStp, xdLabelIt->second, true);
                                    SET_DICT(dictLabelStp, A_DictLabel_EntDictId, permValDictId);

                                    if (GET_ENUM(xdPermValStp, A_XdPermVal_XdActionEn) != XdAction_ToDelete &&
                                        GET_ENUM(xdPermValStp, A_XdPermVal_XdActionEn) != XdAction_ToPhysicallyDelete &&
                                        (GET_ENUM(xdLabelIt->second, A_XdLabel_XdActionEn) == XdAction_ToInsert ||
                                         (GET_ENUM(xdLabelIt->second, A_XdLabel_XdActionEn) == XdAction_None &&
                                          GET_ENUM(xdLabelIt->second, A_XdLabel_XdStatusEn) == XdStatus_Inserted)))
                                    {
                                        DBA_ACTION_ENUM  actionDone = NullAction;
                                        requestHelperPtr->setCopyIdForBatchMulti(99, dictLabelStp, A_DictLabel_ObjDictId, xdPermValStp, A_XdPermVal_DictId);
                                        requestHelperPtr->insUpdRecord(dictLabelStp, actionDone, dictPermValStp);
                                    }
                                    else
                                    {
                                        xdStatus = XdStatus_PhysicallyDeleted;

                                        requestHelperPtr->dbaCall(Delete,
                                                                  DictLabel,
                                                                  UNUSED,
                                                                  dictLabelStp);
                                    }
                                }

                                SET_ENUM(xdLabelIt->second, A_XdLabel_XdActionEn, XdAction_None);
                                SET_ENUM(xdLabelIt->second, A_XdLabel_XdStatusEn, xdStatus);
                                requestHelperPtr->dbaCall(Update,
                                                          XdLabel,
                                                          DBA_ROLE_STATUS,
                                                          xdLabelIt->second,
                                                          MAX_SHORT,
                                                          xdPermValStp);


                                for (auto it = xdLabelNatIt->second.begin(); it != xdLabelIt; ++it)
                                {
                                    SET_ENUM(it->second, A_XdLabel_XdActionEn, XdAction_None);
                                    SET_ENUM(it->second, A_XdLabel_XdStatusEn, xdStatus);
                                    requestHelperPtr->dbaCall(Update,
                                                              XdLabel,
                                                              DBA_ROLE_STATUS,
                                                              it->second,
                                                              MAX_SHORT,
                                                              xdPermValStp);

                                }

                                if (xdStatus == XdStatus_Inserted)
                                {
                                    break;
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    this->finishConnection(ret);

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenFullTable::buildCommentsInMetaDict()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-19243 - DDV - 150512
**
*************************************************************************/
RET_CODE DdlGenFullTable::buildCommentsInMetaDict()
{
    RET_CODE         ret = RET_SUCCEED;
    int				 xdAttribCommentNbr = 0;
    DBA_DYNFLD_STP* xdAttribByIdTab = NULL, 
        *xdAttribCommentTab,
        *xdAttribObjPtr;

    DdlGenProcessLogger    ddlGenProcessLogger(*this, ret, "Comments creation");
    DBA_DYNFLD_STP   xdEntityStp = this->getXdEntityStp();

    ddlGenProcessLogger.start();

    if ((this->m_dictEntityStp = DBA_GetDictEntitySt(this->objectEn)) == NULL ||
        this->initConnection() != RET_SUCCEED)
    {
        return RET_DBA_INFO_NODATA;
    }
    DdlGenConnGuard     ddlGenConnGuard(*this->ddlGenContextPtr);

    if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
    {
        MemoryPool           mp;
        DdlGenRequestHelper* requestHelperPtr = this->ddlGenContextPtr->getRequestHelper();
        if (requestHelperPtr == nullptr)
        {
            requestHelperPtr = new DdlGenRequestHelper(&ddlGenConnGuard.getDbiConn(), *this->ddlGenContextPtr);
            mp.ownerObject(requestHelperPtr);
        }

        auto admArgStp = requestHelperPtr->allocDynSt(FILEINFO, Adm_Arg);

        SET_ID(admArgStp, Adm_Arg_Id, GET_ID(xdEntityStp, A_XdEntity_Id));
        if ((ret = DBA_Select2(XdAttribComment,
                               UNUSED,
                               Adm_Arg,
                               admArgStp,
                               A_XdAttribComment,
                               &xdAttribCommentTab,
                               DBA_SET_CONN | DBA_NO_CLOSE,
                               UNUSED,
                               &xdAttribCommentNbr,
                               ddlGenConnGuard.getDbiConn())) != RET_SUCCEED)
        {
            ret = RET_DBA_ERR_SELECT_FAILED;
        }
        mp.owner(xdAttribCommentTab, xdAttribCommentNbr);

        if (ret == RET_SUCCEED &&
            this->ddlGenEntityPtr->getXdAttribNbr() > 0)
        {
            xdAttribByIdTab = this->ddlGenEntityPtr->getSortedXdAttribTab((TLS_CMPFCT*)DDL_CmpXdAttribById);
            mp.owner(xdAttribByIdTab);
        }

        DBA_DYNFLD_STP shDictCommentStp = mp.allocDynst(FILEINFO, S_DictAttribComment);

        if (ret == RET_SUCCEED)
        {
            for (int i = 0; i < xdAttribCommentNbr; i++)
            {
                DBA_DYNFLD_STP dictAttribCommentStp = mp.allocDynst(FILEINFO, A_DictAttribComment);

                xdAttribObjPtr = (DBA_DYNFLD_STP*)TLS_Search(&(GET_ID(xdAttribCommentTab[i], A_XdAttribComment_XdAttribId)),
                                                             xdAttribByIdTab,
                                                             this->ddlGenEntityPtr->getXdAttribNbr(),
                                                             sizeof(DBA_DYNFLD_STP*),
                                                             DDL_CmpXdAttribByIdByKey);

                this->copyDynFld(shDictCommentStp, S_DictAttribComment_AttribDictId, *xdAttribObjPtr, A_XdAttrib_AttribDictId);

                this->copyDynFld(shDictCommentStp, S_XdAttribComment_LangDictId, xdAttribCommentTab[i], A_XdAttribComment_LangDictId);

                if (DBA_Get2(DictAttribComment,
                             UNUSED,
                             S_DictAttribComment,
                             shDictCommentStp,
                             A_DictAttribComment,
                             &dictAttribCommentStp,
                             DBA_SET_CONN | DBA_NO_CLOSE,
                             ddlGenConnGuard.getDbiConn()) == RET_SUCCEED)
                {
                    this->copyDynFld(dictAttribCommentStp, A_DictAttribComment_Comment,
                                     xdAttribCommentTab[i], A_XdAttribComment_Comment);

                    if ((ret = DBA_Update2(DictAttribComment,
                                           UNUSED,
                                           A_DictAttribComment,
                                           dictAttribCommentStp,
                                           DBA_SET_CONN | DBA_NO_CLOSE,
                                           ddlGenConnGuard.getDbiConn())) != RET_SUCCEED)
                    {
                        MSG_SendMesg(RET_DBA_ERR_UPDATE_FAILED, 0, FILEINFO);
                        ret = RET_DBA_ERR_INSERT_FAILED;
                        break;
                    }
                }
                else
                {
                    this->copyDynFld(dictAttribCommentStp, A_DictAttribComment_AttribDictId,
                                     *xdAttribObjPtr, A_XdAttrib_AttribDictId);

                    this->copyDynFld(dictAttribCommentStp, A_XdAttribComment_LangDictId,
                                     xdAttribCommentTab[i], A_XdAttribComment_LangDictId);

                    this->copyDynFld(dictAttribCommentStp, A_DictAttribComment_Comment,
                                     xdAttribCommentTab[i], A_XdAttribComment_Comment);

                    SET_ENUM(dictAttribCommentStp, A_DictAttribComment_XdStatusEn, XdStatus_Inserted);

                    if ((ret = DBA_Insert2(DictAttribComment,
                                           UNUSED,
                                           A_DictAttribComment,
                                           dictAttribCommentStp,
                                           DBA_SET_CONN | DBA_NO_CLOSE,
                                           ddlGenConnGuard.getDbiConn())) != RET_SUCCEED)
                    {
                        MSG_SendMesg(RET_DBA_ERR_INSERT_FAILED, 0, FILEINFO);
                        ret = RET_DBA_ERR_INSERT_FAILED;
                        break;
                    }
                }
            }
        }
    }

    this->finishConnection(ret);

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenFullTable::questionnairePostUpdate()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13109 - LJE - 110311
**  Modif       :   HFI-PMSTA-49857-220725  Remove one IF in automatic input control
**
*************************************************************************/
RET_CODE DdlGenFullTable::questionnairePostUpdate()
{
    MemoryPool       mp;
    RET_CODE         ret = RET_SUCCEED;
    
    DdlGenProcessLogger    ddlGenProcessLogger(*this, ret, "Questionnaire Post Update");

    if ((this->m_dictEntityStp = DBA_GetDictEntitySt(this->objectEn)) == NULL ||
        this->initConnection() != RET_SUCCEED)
    {
        return RET_DBA_INFO_NODATA;
    }
    DdlGenConnGuard     ddlGenConnGuard(*this->ddlGenContextPtr);

    ddlGenProcessLogger.start();

    /* Load questionnaire_def record and update its entity_dict_id if needed */
    if (strlen(this->m_dictEntityStp->mdSqlName) > 3)
    {
        DBA_DYNFLD_STP  aQuestDefStp = nullptr;
        
        ret = DBA_GetQuestByCd(this->m_dictEntityStp->mdSqlName, *this->ddlGenContextPtr, aQuestDefStp, mp);

        if (ret == RET_SUCCEED)
        {
            if (GET_DICT(aQuestDefStp, A_QuestDef_EntityDictId) != this->m_dictEntityStp->entDictId)
            {
                SET_DICT(aQuestDefStp, A_QuestDef_EntityDictId, this->m_dictEntityStp->entDictId);
                DBA_Update2(QuestDef,
                            DBA_ROLE_UPD_ENTITY,
                            A_QuestDef,
                            aQuestDefStp,
                            DBA_SET_CONN | DBA_NO_CLOSE,
                            ddlGenConnGuard.getDbiConn());
            }
        }
    }

    DBA_DYNFLD_STP   dynScript = mp.allocDynst(FILEINFO, A_ScriptDef);
    /* add sys DV on comment elements and also sys IC */
    for (int i = 0; i < this->ddlGenEntityPtr->getXdAttribNbr(); i++)
    {
        DBA_DYNFLD_STP currXdAttribStp = this->ddlGenEntityPtr->getXdAttrib(i);
        DBA_DYNFLD_STP dictAttribDynStp = this->aDictAttribMap[GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName)];

        if (GET_ENUM(dictAttribDynStp, A_DictAttr_CalcEn) == DictAttr_Virtual &&
            GET_ENUM(dictAttribDynStp, A_DictAttr_EditEn) == DictAttrib_EditNoEdit)
        {
            NOTE_T  scptDef;

            scptDef[0] = END_OF_STRING;

            /* Save script */
            SET_NULL_SMALLINT(dynScript, A_ScriptDef_Rank);
            this->copyDynFld(dynScript, A_ScriptDef_AttrDictId,
                             dictAttribDynStp, A_DictAttr_DictId);
            SET_DICT(dynScript, A_ScriptDef_DimEntityDictId, 0);
            this->copyDynFld(dynScript, A_ScriptDef_ScriptEntRefDictId,
                             dictAttribDynStp, A_DictAttr_EntityDictId);
            SET_ENUM(dynScript, A_ScriptDef_NatEn, ScriptDef_SysGuiDefVal);

            sprintf(scptDef, "{Automatic default value}\n ATTRIBUTE_COMMENT(\"%s\",\"%s\")", this->m_dictEntityStp->mdSqlName, GET_SYSNAME(dictAttribDynStp, A_DictAttr_SqlName));

            SET_STRING(dynScript, A_ScriptDef_Def, scptDef);
            DBA_SetScptDef(dynScript, this->objectEn, NullEntity, nullptr, ddlGenConnGuard.getDbiConn());
        }
        else if (strcmp(GET_SYSNAME(dictAttribDynStp, A_DictAttr_SqlName), "script_control") == 0)
        {
            STRING1000_T  scptDef;

            scptDef[0] = END_OF_STRING;

            /* Save script */
            SET_NULL_SMALLINT(dynScript, A_ScriptDef_Rank);
            this->copyDynFld(dynScript, A_ScriptDef_AttrDictId,
                             dictAttribDynStp, A_DictAttr_DictId);
            SET_DICT(dynScript, A_ScriptDef_DimEntityDictId, 0);
            this->copyDynFld(dynScript, A_ScriptDef_ScriptEntRefDictId,
                             dictAttribDynStp, A_DictAttr_EntityDictId);
            SET_ENUM(dynScript, A_ScriptDef_NatEn, ScriptDef_SysGuiCtrlVal);

            sprintf(scptDef, "{Automatic Input Control}\n "\
                    "IF(OLD().questionnaire_histo_id.status_e IN (0,4,5,6){Canceled, Rejected, Deprecated, Expired},\n"\
                    "MSG(ERROR,\"status_e\",1,\"ERR_QUEST_STATUS_UPD\", NULL))\n");

            SET_STRING(dynScript, A_ScriptDef_Def, scptDef);
            DBA_SetScptDef(dynScript, this->objectEn, NullEntity, nullptr, ddlGenConnGuard.getDbiConn());
        }
    }

    this->finishConnection(ret);

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenFullTable::buildInMetaDict3()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13109 - LJE - 110311
**
*************************************************************************/
RET_CODE DdlGenFullTable::buildInMetaDict3()
{
    RET_CODE   ret = RET_SUCCEED;
    int        i;
    bool       bUpdDictEntity = false;
    DdlGenProcessLogger    ddlGenProcessLogger(*this, ret, "Meta dictionary creation (3)");

    ddlGenProcessLogger.start();

    if ((this->m_dictEntityStp = DBA_GetDictEntitySt(this->objectEn)) == NULL ||
        this->initConnection() != RET_SUCCEED)
    {
        return RET_DBA_INFO_NODATA;
    }
    DdlGenConnGuard     ddlGenConnGuard(*this->ddlGenContextPtr);

    try
    {
        DBA_DYNFLD_STP xdEntityStp = this->getXdEntityStp();

        /* PMSTA-45413 - LJE - 210707 */
        MemoryPool           mp;
        DdlGenRequestHelper* requestHelperPtr = this->ddlGenContextPtr->getRequestHelper();
        if (requestHelperPtr == nullptr)
        {
            requestHelperPtr = new DdlGenRequestHelper(&ddlGenConnGuard.getDbiConn(), *this->ddlGenContextPtr);
            mp.ownerObject(requestHelperPtr);
        }
        auto admArgStp = mp.allocDynst(FILEINFO, Adm_Arg);

        if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
        {
            if (IS_NULLFLD(xdEntityStp, A_XdEntity_ParentXdAttribId) == FALSE)
            {
                FIELD_IDX_T progN = 0;
                for (; progN < this->ddlGenEntityPtr->getXdAttribNbr(); progN++)
                {
                    if (CMP_DYNFLD(xdEntityStp, this->ddlGenEntityPtr->getXdAttrib(progN),
                                   A_XdEntity_ParentXdAttribId, A_XdAttrib_Id, IdType) == 0)
                    {
                        this->m_dictEntityStp->parIndex = (TINYINT_T)progN;
                        this->m_dictEntityStp->isNullParIndex = false;

                        if (IS_NULLFLD(this->ddlGenEntityPtr->getADictEntityStp(), A_DictEntity_ParentIdx) == TRUE ||
                            GET_TINYINT(this->ddlGenEntityPtr->getADictEntityStp(), A_DictEntity_ParentIdx) != this->m_dictEntityStp->parIndex)
                        {
                            bUpdDictEntity = true;
                            SET_TINYINT(this->ddlGenEntityPtr->getADictEntityStp(), A_DictEntity_ParentIdx, this->m_dictEntityStp->parIndex);
                        }
                        break;
                    }
                }

                if (progN == this->ddlGenEntityPtr->getXdAttribNbr())
                {
                    this->printMsg(RET_GEN_ERR_INVARG, "Unknown parent attribute!");
                }
            }

            /* Find the attribute that define the nature */
            if (IS_NULLFLD(xdEntityStp, A_XdEntity_NatXdAttribId) == FALSE)
            {
                MASK_T maxSubTypeMask = 0;
                FIELD_IDX_T progN = 0;

                for (; progN < this->ddlGenEntityPtr->getXdAttribNbr(); progN++)
                {
                    if (CMP_DYNFLD(xdEntityStp, this->ddlGenEntityPtr->getXdAttrib(progN),
                                   A_XdEntity_NatXdAttribId, A_XdAttrib_Id, IdType) == 0)
                    {
                        this->m_dictEntityStp->natIndex = (TINYINT_T)progN;
                        this->m_dictEntityStp->isNullNatIndex = false;

                        if (GET_TINYINT(this->ddlGenEntityPtr->getADictEntityStp(), A_DictEntity_NatIdx) != this->m_dictEntityStp->natIndex)
                        {
                            bUpdDictEntity = true;
                            SET_TINYINT(this->ddlGenEntityPtr->getADictEntityStp(), A_DictEntity_NatIdx, this->m_dictEntityStp->natIndex);
                        }
                        break;
                    }

                    if (maxSubTypeMask < GET_MASK(this->ddlGenEntityPtr->getXdAttrib(progN), A_XdAttrib_SubTpMask))
                    {
                        maxSubTypeMask = GET_MASK(this->ddlGenEntityPtr->getXdAttrib(progN), A_XdAttrib_SubTpMask);
                    }
                }

                if (progN == this->ddlGenEntityPtr->getXdAttribNbr())
                {
                    stringstream        msgStream;
                    ret = RET_DBA_ERR_MD;

                    msgStream << "Unknown nature attribute! (xd_attribute_id=" << GET_ID(xdEntityStp, A_XdEntity_NatXdAttribId) << ")";
                    this->printMsg(ret, msgStream.str());
                }
            }

            if (IS_NULLFLD(xdEntityStp, A_XdEntity_LinkedXdEntityId) == FALSE)
            {
                this->copyDynFld(admArgStp, Adm_Arg_Id, xdEntityStp, A_XdEntity_LinkedXdEntityId);

                DBA_DYNFLD_STP refXdEntityStp = nullptr;

                if (requestHelperPtr->dbaGet(XdEntity, UNUSED, admArgStp, refXdEntityStp) != RET_SUCCEED)
                {
                    this->finishConnection(ret);
                    MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO, "xd_entity", GET_ID(xdEntityStp, A_XdEntity_LinkedXdEntityId));
                    ret = RET_DBA_ERR_NODATA;
                }
                else
                {
                    if (this->m_dictEntityStp->linkedEntityDictId != GET_DICT(refXdEntityStp, A_XdEntity_EntityDictId))
                    {
                        bUpdDictEntity = true;
                        this->m_dictEntityStp->linkedEntityDictId = GET_DICT(refXdEntityStp, A_XdEntity_EntityDictId);
                        SET_DICT(this->ddlGenEntityPtr->getADictEntityStp(), A_DictEntity_LinkedEntityDictId, this->m_dictEntityStp->linkedEntityDictId);
                    }
                }
                SET_NULL_ID(admArgStp, Adm_Arg_Id);
            }

            if (IS_NULLFLD(xdEntityStp, A_XdEntity_PhysicalXdEntityId) == FALSE)
            {
                this->copyDynFld(admArgStp, Adm_Arg_Id, xdEntityStp, A_XdEntity_PhysicalXdEntityId);

                DBA_DYNFLD_STP refXdEntityStp = nullptr;

                if (requestHelperPtr->dbaGet(XdEntity, UNUSED, admArgStp, refXdEntityStp) != RET_SUCCEED)
                {
                    this->finishConnection(ret);
                    MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO, "xd_entity", GET_ID(xdEntityStp, A_XdEntity_PhysicalXdEntityId));
                    ret = RET_DBA_ERR_NODATA;
                }
                else if (this->m_dictEntityStp->physicalEntityDictId != GET_DICT(refXdEntityStp, A_XdEntity_EntityDictId))
                {
                    bUpdDictEntity = true;
                    this->m_dictEntityStp->physicalEntityDictId = GET_DICT(refXdEntityStp, A_XdEntity_EntityDictId);
                    SET_DICT(this->ddlGenEntityPtr->getADictEntityStp(), A_DictEntity_PhysicalEntityDictId, this->m_dictEntityStp->physicalEntityDictId);
                }
                SET_NULL_ID(admArgStp, Adm_Arg_Id);
            }
        }

        for (i = 0; i < this->ddlGenEntityPtr->getXdAttribNbr(); i++)
        {
            DBA_DYNFLD_STP currXdAttribStp = this->ddlGenEntityPtr->getXdAttrib(i);
            auto dictAttribIt = this->aDictAttribMap.find(GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName));

            if (dictAttribIt == this->aDictAttribMap.end())
            {
                continue;
            }

            bool     bUpdDictAttr = false;
            bool     bUpdXdAttr = false;

            DBA_DYNFLD_STP currDictAttribStp = dictAttribIt->second;

            auto progN = GET_INT(currXdAttribStp, A_XdAttrib_Prog);

            assert(progN < (int)this->m_dictEntityStp->attr.size());

            DICT_ATTRIB_STP dictAttribStp = this->m_dictEntityStp->attr[progN];

            if (IS_NULLFLD(currDictAttribStp, A_DictAttr_EntityDictId) == TRUE)
            {
                SET_DICT(currDictAttribStp, A_DictAttr_EntityDictId, this->m_dictEntityStp->entDictId);
                bUpdDictAttr = true;
            }

            if (IS_NULLFLD(currXdAttribStp, A_XdAttrib_RefXdEntityId) == FALSE)
            {
                if (CMP_DYNFLD(currXdAttribStp, currXdAttribStp, A_XdAttrib_XdEntityId, A_XdAttrib_RefXdEntityId, IdType) != 0)
                {
                    if (dictAttribStp->refEntDictId == 0)
                    {
                        DBA_DYNFLD_STP refXdEntityStp = nullptr;

                        this->copyDynFld(admArgStp, Adm_Arg_Id, currXdAttribStp, A_XdAttrib_RefXdEntityId);

                        if (requestHelperPtr->dbaGet(XdEntity, UNUSED, admArgStp, refXdEntityStp) != RET_SUCCEED)
                        {
                            this->finishConnection(ret);
                            MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO, "xd_entity", GET_ID(currXdAttribStp, A_XdAttrib_RefXdEntityId));
                            ret = RET_DBA_ERR_NODATA;
                        }
                        SET_NULL_ID(admArgStp, Adm_Arg_Id);

                        dictAttribStp->refEntDictId = GET_DICT(refXdEntityStp, A_XdEntity_EntityDictId);
                    }
                }
                else
                {
                    dictAttribStp->refEntDictId = this->m_dictEntityStp->entDictId;
                }

                if (dictAttribStp->refEntDictId != GET_DICT(currDictAttribStp, A_DictAttr_RefEntityDictId))
                {
                    bUpdDictAttr = true;
                    SET_DICT(currDictAttribStp, A_DictAttr_RefEntityDictId, dictAttribStp->refEntDictId);
                }

                if (dictAttribStp->refEntDictId != GET_DICT(currDictAttribStp, A_DictAttr_RefEntityAttribDictId))
                {
                    bUpdDictAttr = true;
                    SET_DICT(currDictAttribStp, A_DictAttr_RefEntityAttribDictId, dictAttribStp->refEntDictId);
                    dictAttribStp->refEntityAttributeDictId = dictAttribStp->refEntDictId;
                }

                if (GET_ENUM(currXdAttribStp, A_XdAttrib_CustomFlg) != Custom_No)
                {
                    auto refDictEntityStp = DBA_GetDictEntityByDictId(dictAttribStp->refEntDictId);

                    if (refDictEntityStp == nullptr ||
                        refDictEntityStp->refAuthFlg == FALSE)
                    {
                        ret = RET_DBA_ERR_INVDATA;
                        this->printMsg(ret, SYS_Stringer("The User defined field '", 
                                                         GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName), 
                                                         "' cannot be inserted because it is references on a invalid entity (",
                                                         refDictEntityStp->mdSqlName,
                                                         ")"));
                    }
                }
            }

            /* PMSTA-46681 - LJE - 230127 */
            if (CMP_DYNFLD(currXdAttribStp, currXdAttribStp, A_XdAttrib_Id, A_XdAttrib_ParentXdAttribId, IdType) == 0)
            {
                SET_NULL_ID(currXdAttribStp, A_XdAttrib_ParentXdAttribId);
                bUpdDictAttr = true;
            }

            if (IS_NULLFLD(currXdAttribStp, A_XdAttrib_ParentXdAttribId) == false)
            {
                set<ID_T>      searchParIdSet;
                DBA_DYNFLD_STP searchXdAttribStp = currXdAttribStp;
                DBA_DYNFLD_STP parentXdAttribStp = nullptr;

                searchParIdSet.insert(GET_ID(currXdAttribStp, A_XdAttrib_ParentXdAttribId));

                while (searchXdAttribStp != nullptr)
                {
                    parentXdAttribStp = this->ddlGenEntityPtr->getXdAttribById(GET_ID(searchXdAttribStp, A_XdAttrib_ParentXdAttribId));

                    if (parentXdAttribStp == nullptr)
                    {
                        this->copyDynFld(shXdAttribStp, S_XdAttrib_Id, searchXdAttribStp, A_XdAttrib_ParentXdAttribId);

                        DBA_DYNFLD_STP    allXdAttribStp = nullptr;
                        if (requestHelperPtr->dbaGet(XdAttrib, UNUSED, this->shXdAttribStp, allXdAttribStp) != RET_SUCCEED)
                        {
                            ret = RET_DBA_ERR_NODATA;
                            this->printMsg(ret, "Unknown parent xd_attribute for attribute " + string(GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName)));
                        }
                        else
                        {
                            parentXdAttribStp = allXdAttribStp;
                        }
                    }

                    if (ret == RET_SUCCEED)
                    {
                        if (CMP_DYNFLD(currXdAttribStp, parentXdAttribStp, A_XdAttrib_DataTpDictId, A_XdAttrib_DataTpDictId, DictType) != 0 &&
                            this->ddlGenContextPtr->ddlGenAction.m_mainDdlObjNatEn != DbObjDdlObjNat_System)
                        {
                            ret = RET_DBA_ERR_MD;
                            this->printMsg(ret, SYS_Stringer("Data-type mismatch between attribute (",
                                                             GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName),
                                                             ":", DBA_GetDictDataTpStp(DATATYPE_DICT_TO_ENUM(GET_DICT(currXdAttribStp, A_XdAttrib_DataTpDictId)))->sqlName, ") and his parent(",
                                                             GET_SYSNAME(parentXdAttribStp, A_XdAttrib_SqlName),
                                                             ":", DBA_GetDictDataTpStp(DATATYPE_DICT_TO_ENUM(GET_DICT(parentXdAttribStp, A_XdAttrib_DataTpDictId)))->sqlName, ")"));
                        }

                        if (IS_NULLFLD(parentXdAttribStp, A_XdAttrib_ParentXdAttribId) == false)
                        {
                            if (searchParIdSet.insert(GET_ID(parentXdAttribStp, A_XdAttrib_ParentXdAttribId)).second)
                            {
                                if (GET_ENUM(currXdAttribStp, A_XdAttrib_CustomFlg) == Custom_No)
                                {
                                    this->printMsg(RET_DBA_ERR_NODATA, "Wrong parent attribute definition of the attribute " + string(GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName)) + " (have a parent attribute)");
                                }
                                else
                                {
                                    COPY_DYNFLD(currXdAttribStp, A_XdAttrib, A_XdAttrib_ParentXdAttribId, parentXdAttribStp, A_XdAttrib, A_XdAttrib_ParentXdAttribId);
                                    bUpdDictAttr = true;

                                    /* PMSTA-46681 - LJE - 230131 - Perm value clean-up */
                                    auto xdPermValAttribMapPtr = this->ddlGenEntityPtr->getXdPermValByAttribMap(GET_ID(currXdAttribStp, A_XdAttrib_Id));
                                    if (xdPermValAttribMapPtr != nullptr && xdPermValAttribMapPtr->empty() == false)
                                    {
                                        for (auto it = xdPermValAttribMapPtr->begin(); it != xdPermValAttribMapPtr->end(); ++it)
                                        {
                                            SET_ENUM(it->second, A_XdPermVal_XdActionEn, XdAction_ToDelete);
                                        }
                                    }
                                }
                                searchXdAttribStp = parentXdAttribStp;
                            }
                            else
                            {
                                this->printMsg(ret, "Loop detected on the parent xd_attribute for attribute " + string(GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName)));
                                ret = RET_DBA_ERR_NODATA;
                                searchXdAttribStp = nullptr;
                            }
                        }
                        else
                        {
                            searchXdAttribStp = nullptr;
                        }
                    }
                    else
                    {
                        searchXdAttribStp = nullptr;
                    }
                }

                if (parentXdAttribStp != nullptr)
                {
                    if (dictAttribStp->parAttrDictId != GET_DICT(parentXdAttribStp, A_XdAttrib_AttribDictId))
                    {
                        bUpdDictAttr = true;
                        dictAttribStp->parAttrDictId = GET_DICT(parentXdAttribStp, A_XdAttrib_AttribDictId);
                        SET_DICT(currDictAttribStp, A_DictAttr_ParentAttribDictId, dictAttribStp->parAttrDictId);
                    }

                    /* PMSTA-26857 - LJE - 170330 */
                    if (CMP_DYNFLD(currXdAttribStp, parentXdAttribStp, A_XdAttrib_PermAuthEn, A_XdAttrib_PermAuthEn, EnumType) != 0)
                    {
                        bUpdDictAttr = true;
                        dictAttribStp->permAuthEn = (DBA_PERMAUTH_ENUM)GET_ENUM(parentXdAttribStp, A_XdAttrib_PermAuthEn);
                        this->copyDynFld(currDictAttribStp, A_DictAttr_PermAuthFlg, parentXdAttribStp, A_XdAttrib_PermAuthEn);

                        bUpdXdAttr = true;
                        this->copyDynFld(currXdAttribStp, A_XdAttrib_PermAuthEn, parentXdAttribStp, A_XdAttrib_PermAuthEn);
                    }

                    /* PMSTA-26857 - LJE - 170330 */
                    if (IS_NULLFLD(currXdAttribStp, A_XdAttrib_Default) == TRUE &&
                        IS_NULLFLD(parentXdAttribStp, A_XdAttrib_Default) == FALSE &&
                        CMP_DYNFLD(currXdAttribStp, parentXdAttribStp, A_XdAttrib_Default, A_XdAttrib_Default, NameType) != 0)
                    {
                        bUpdDictAttr = true;
                        dictAttribStp->dfltVal = GET_NAME(parentXdAttribStp, A_XdAttrib_Default);
                        this->copyDynFld(currDictAttribStp, A_DictAttr_Default, parentXdAttribStp, A_XdAttrib_Default);

                        bUpdXdAttr = true;
                        this->copyDynFld(currXdAttribStp, A_XdAttrib_Default, parentXdAttribStp, A_XdAttrib_Default);
                    }

                    if (GET_ENUM(currXdAttribStp, A_XdAttrib_CalcEn) != DictAttr_Denorm &&
                        (DATATYPE_DICT_TO_ENUM(GET_DICT(currXdAttribStp, A_XdAttrib_DataTpDictId)) == EnumType ||
                         DATATYPE_DICT_TO_ENUM(GET_DICT(currXdAttribStp, A_XdAttrib_DataTpDictId)) == FlagType ||
                         DATATYPE_DICT_TO_ENUM(GET_DICT(currXdAttribStp, A_XdAttrib_DataTpDictId)) == EnumMaskType))
                    {
                        DICT_ATTRIB_STP attr = DBA_GetAttributeById(dictAttribStp->parAttrDictId);
                        if (attr != NULL &&
                            attr->permValMap.empty() == false)
                        {
                            dictAttribStp->permValMap = attr->permValMap;
                        }
                        else if (GET_FLAG(currXdAttribStp, A_XdAttrib_CustomFlg) != Custom_No)
                        {
                            stringstream msg;
                            MSG_SendMesg(RET_DBA_ERR_MD, 5, FILEINFO,
                                         this->m_dictEntityStp->mdSqlName,
                                         GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName),
                                         "The parent attribute has no permitted values!");
                            ret = RET_DBA_ERR_MD;
                            msg << "The parent attribute has no permitted values : " << this->m_dictEntityStp->mdSqlName << "." << GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName);
                            this->printMsg(ret, msg.str());
                        }
                    }

                    bUpdDictAttr = true;
                    dictAttribStp->maxDbLenN = GET_SMALLINT(parentXdAttribStp, A_XdAttrib_MaxDbLen);
                    this->copyDynFld(currDictAttribStp, A_DictAttr_MaxDbLen, parentXdAttribStp, A_XdAttrib_MaxDbLen);

                    dictAttribStp->defaultDisplayLenN = GET_SMALLINT(parentXdAttribStp, A_XdAttrib_DefaultDispLen);
                    this->copyDynFld(currDictAttribStp, A_DictAttr_DefaultDispLen, parentXdAttribStp, A_XdAttrib_DefaultDispLen);

                    bUpdXdAttr = true;
                    this->copyDynFld(currXdAttribStp, A_XdAttrib_MaxDbLen, parentXdAttribStp, A_XdAttrib_MaxDbLen);
                    this->copyDynFld(currXdAttribStp, A_XdAttrib_DefaultDispLen, parentXdAttribStp, A_XdAttrib_DefaultDispLen);
                }
            }
            else if (dictAttribStp->parAttrDictId != 0)
            {
                bUpdDictAttr = true;
                SET_NULL_DICT(currDictAttribStp, A_DictAttr_ParentAttribDictId);
                dictAttribStp->parAttrDictId = 0;
            }

            if (IS_NULLFLD(currXdAttribStp, A_XdAttrib_LinkedXdAttribId) == FALSE)
            {
                DBA_DYNFLD_STP linkedXdAttribStp = this->ddlGenEntityPtr->getXdAttribById(GET_ID(currXdAttribStp, A_XdAttrib_LinkedXdAttribId));

                if (linkedXdAttribStp == nullptr)
                {
                    this->copyDynFld(shXdAttribStp, S_XdAttrib_Id, currXdAttribStp, A_XdAttrib_LinkedXdAttribId);

                    DBA_DYNFLD_STP    allXdAttribStp = nullptr;

                    if (requestHelperPtr->dbaGet(XdAttrib, UNUSED, this->shXdAttribStp, allXdAttribStp) != RET_SUCCEED)
                    {
                        this->printMsg(ret, "Unknown linked xd_attribute for attribute " + string(GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName)));
                        ret = RET_DBA_ERR_NODATA;
                    }
                    else
                    {
                        linkedXdAttribStp = allXdAttribStp;
                    }
                }

                if (linkedXdAttribStp != nullptr)
                {
                    if ((GET_ENUM(xdEntityStp, A_XdEntity_NatEn) == EntityNat_DerivedEntity ||
                         GET_ENUM(xdEntityStp, A_XdEntity_DictBuildRuleEn) == DictBuildRule_All ||
                         GET_ENUM(xdEntityStp, A_XdEntity_DictBuildRuleEn) == DictBuildRule_AllDb ||
                         GET_ENUM(xdEntityStp, A_XdEntity_DictBuildRuleEn) == DictBuildRule_AllForcePhysical) &&
                        GET_ID(linkedXdAttribStp, A_XdAttrib_XdEntityId) != GET_ID(xdEntityStp, A_XdEntity_Id))
                    {
                        if (GET_FLAG(currXdAttribStp, A_XdAttrib_LogicalFlg) == FALSE)
                        {
                            linkedXdAttribStp = this->ddlGenEntityPtr->getXdAttribBySqlName(GET_SYSNAME(linkedXdAttribStp, A_XdAttrib_SqlName));
                        }
                        else
                        {
                            string        lnkEntitySqlName = this->ddlGenContextPtr->getXdEntitySqlNameById(GET_ID(linkedXdAttribStp, A_XdAttrib_XdEntityId));
                            DdlGenEntity* lnkDdlGenEntityPtr = this->ddlGenContextPtr->getDdlGenEntityPtr(lnkEntitySqlName + "_sh");

                            if (lnkDdlGenEntityPtr != nullptr &&
                                lnkDdlGenEntityPtr->getXdEntityStp() != nullptr)
                            {
                                linkedXdAttribStp = lnkDdlGenEntityPtr->getXdAttribBySqlName(GET_SYSNAME(linkedXdAttribStp, A_XdAttrib_SqlName));
                            }
                        }
                    }
                }

                if (linkedXdAttribStp != nullptr)
                {
                    if (RET_GET_LEVEL(ret) != RET_LEV_ERROR &&
                        dictAttribStp->linkedAttrDictId != GET_DICT(linkedXdAttribStp, A_XdAttrib_AttribDictId))
                    {
                        bUpdDictAttr = true;
                        dictAttribStp->linkedAttrDictId = GET_DICT(linkedXdAttribStp, A_XdAttrib_AttribDictId);
                        SET_DICT(currDictAttribStp, A_DictAttr_LinkedAttribDictId, dictAttribStp->linkedAttrDictId);
                    }
                }
            }
            else if (dictAttribStp->linkedAttrDictId != 0)
            {
                bUpdDictAttr = true;
                SET_NULL_DICT(currDictAttribStp, A_DictAttr_LinkedAttribDictId);
                dictAttribStp->linkedAttrDictId = 0;
            }

            /* PMSTA-26108 - LJE - 170811 */
            if (dictAttribStp->dfltVal.empty() == false &&
                (dictAttribStp->dataTpProgN == IdType ||
                 dictAttribStp->dataTpProgN == DictType))
            {
                OBJECT_ENUM refObjEn;
                DICT_ENTITY_STP fkDictEntityStp;

                DBA_GetObjectEnum(dictAttribStp->refEntDictId, &refObjEn);
                fkDictEntityStp = DBA_GetDictEntitySt(refObjEn);

                if (fkDictEntityStp != NULL &&
                    fkDictEntityStp->primKeyNbr == 1 &&
                    fkDictEntityStp->bkAttrNbr == 1 &&
                    GET_CTYPE(fkDictEntityStp->bkAttr[0]->dataTpProgN) == CharPtrCType)
                {
                    /* PMSTA-26108 - LJE - 170809 */
                    DdlGen  ddlGen(this->objectEn, DdlObj_None, *this->ddlGenContextPtr, NULL, this->ddlGenEntityPtr, NULL, TargetTable_Main);

                    ID_T idValue = ddlGen.getIdByBk(fkDictEntityStp, dictAttribStp->dfltVal);

                    if (idValue > 0 || dictAttribStp->refCheckRuleEn == RefChkRule_CheckedZeroAllowed)
                    {
                        stringstream locStream;
                        locStream << idValue;
                        dictAttribStp->dfltVal = locStream.str();
                        SET_NAME(currDictAttribStp, A_DictAttr_Default, locStream.str().c_str());
                    }
                    else if (fkDictEntityStp->objectEn == DataSecuProf)
                    {
                        dictAttribStp->dfltVal = '2';
                        SET_NAME(currDictAttribStp, A_DictAttr_Default, dictAttribStp->dfltVal.c_str());
                    }
                    else
                    {
                        dictAttribStp->dfltVal.clear();
                        SET_NULL_NAME(currDictAttribStp, A_DictAttr_Default);
                    }

                    bUpdDictAttr = true;
                }
                else if (dictAttribStp->featureEn == XdEntityFeatureFeatureEn::MultiBusinessEntityManagement)
                {
                    dictAttribStp->dfltVal = this->ddlGenContextPtr->getMasterBusinessEntityId();
                    SET_NAME(currDictAttribStp, A_DictAttr_Default, this->ddlGenContextPtr->getMasterBusinessEntityId().c_str());
                }
            }

            if (bUpdDictAttr)
            {
                this->copyDynFld(currDictAttribStp, A_DictAttr_Prog, currXdAttribStp, A_XdAttrib_DbProg);

                requestHelperPtr->dbaCall(Update,
                                          DictAttr,
                                          UNUSED,
                                          currDictAttribStp,
                                          1);

                this->copyDynFld(currDictAttribStp, A_DictAttr_Prog, currXdAttribStp, A_XdAttrib_Prog);
            }

            if (bUpdXdAttr)
            {
                requestHelperPtr->dbaCall(Update,
                                          XdAttrib,
                                          DBA_ROLE_UDT,
                                          currXdAttribStp,
                                          10);
            }

            auto xdPermValAttribMapPtr = this->ddlGenEntityPtr->getXdPermValByAttribMap(GET_ID(currXdAttribStp, A_XdAttrib_Id));

            if (xdPermValAttribMapPtr != nullptr &&
                xdPermValAttribMapPtr->empty() == false)
            {
                DBA_DYNFLD_STP shDictPermValStp = requestHelperPtr->allocDynSt(FILEINFO, S_DictPermVal);
                DBA_DYNFLD_STP chkDictPermValStp = mp.allocDynst(FILEINFO, A_DictPermVal);

                if (GET_ENUM(currXdAttribStp, A_XdAttrib_XdActionEn) != XdAction_ToPhysicallyDelete &&
                    dictAttribStp->xdStatusEn != XdStatus_PhysicallyDeleted &&
                    dictAttribStp->xdStatusEn != XdStatus_Deleted &&
                    IS_NULLFLD(currXdAttribStp, A_XdAttrib_ParentXdAttribId) == true)
                {
                    for (auto permValIt = xdPermValAttribMapPtr->begin(); permValIt != xdPermValAttribMapPtr->end(); ++permValIt)
                    {
                        DBA_DYNFLD_STP aXdPermValStp = permValIt->second;

                        if (GET_ENUM(aXdPermValStp, A_XdPermVal_XdActionEn) == XdAction_None &&
                            (GET_ENUM(aXdPermValStp, A_XdPermVal_XdStatusEn) == XdStatus_PhysicallyDeleted ||
                             GET_ENUM(aXdPermValStp, A_XdPermVal_XdStatusEn) == XdStatus_Deleted ||
                             GET_ENUM(aXdPermValStp, A_XdPermVal_XdStatusEn) == XdStatus_Inserted))
                        {
                            continue;
                        }

                        DBA_DYNFLD_STP aDictPermValStp = requestHelperPtr->allocDynSt(FILEINFO, A_DictPermVal);

                        DBA_ConvertDynSt(aDictPermValStp, aXdPermValStp, true);

                        this->copyDynFld(aDictPermValStp, A_DictPermVal_AttribDictId,
                                         currDictAttribStp, A_DictAttr_DictId);
                        this->copyDynFld(aDictPermValStp, A_DictPermVal_PermValNatEn,
                                         aXdPermValStp, A_XdPermVal_PermValNatEn);

                        SET_NULL_DICT(shDictPermValStp, S_DictPermVal_DictId);

                        this->copyDynFld(shDictPermValStp, S_DictPermVal_AttribDictId,
                                         currDictAttribStp, A_DictAttr_DictId);
                        this->copyDynFld(shDictPermValStp, S_DictPermVal_PermValNatEn,
                                         aXdPermValStp, A_XdPermVal_PermValNatEn);

                        if (IS_NULLFLD(aXdPermValStp, A_XdPermVal_RefXdEntityId) == FALSE)
                        {
                            this->copyDynFld(admArgStp, Adm_Arg_Id, aXdPermValStp, A_XdPermVal_RefXdEntityId);

                            DBA_DYNFLD_STP refXdEntityStp = nullptr;
                            if (requestHelperPtr->dbaGet(XdEntity, UNUSED, admArgStp, refXdEntityStp) != RET_SUCCEED)
                            {
                                stringstream msgStream;
                                msgStream << "Unknown reference entity (" << GET_ID(aXdPermValStp, A_XdPermVal_RefXdEntityId) << ") on permitted value: "
                                    << this->m_dictEntityStp->mdSqlName << "."
                                    << GET_SYSNAME(currDictAttribStp, A_DictAttr_SqlName) << "." << GET_SYSNAME(aXdPermValStp, A_XdPermVal_Name);

                                ret = RET_DBA_ERR_NODATA;
                                this->printMsg(ret, msgStream.str());
                            }
                            else
                            {
                                dictAttribStp->permValMap[GET_SMALLINT(aXdPermValStp, A_XdPermVal_Rank)].refEntityDictId = GET_DICT(refXdEntityStp, A_XdEntity_EntityDictId);
                                SET_DICT(aDictPermValStp, A_DictPermVal_RefEntityDictId, GET_ID(refXdEntityStp, A_XdEntity_EntityDictId));
                            }
                            SET_NULL_ID(admArgStp, Adm_Arg_Id);
                        }

                        if (requestHelperPtr->dbaGet(DictPermVal, UNUSED, shDictPermValStp, chkDictPermValStp) != RET_SUCCEED)
                        {
                            if (GET_ENUM(aXdPermValStp, A_XdPermVal_XdActionEn) == XdAction_ToInsert)
                            {
                                requestHelperPtr->dbaCall(Insert,
                                                          DictPermVal,
                                                          DBA_ROLE_UDT,
                                                          aDictPermValStp,
                                                          60,
                                                          currXdAttribStp);
                            }
                        }
                        else
                        {
                            COPY_DYNFLD(aDictPermValStp, A_DictPermVal, A_DictPermVal_DictId, chkDictPermValStp, A_DictPermVal, A_DictPermVal_DictId);

                            if (GET_ENUM(aXdPermValStp, A_XdPermVal_XdActionEn) != XdAction_ToInsert ||
                                CMP_DYNFLD(aDictPermValStp, chkDictPermValStp, A_DictPermVal_Name, A_DictPermVal_Name, NameType) != 0)
                            {
                                requestHelperPtr->dbaCall(Delete,
                                                          DictPermVal,
                                                          UNUSED,
                                                          aDictPermValStp,
                                                          59);

                                if (GET_ENUM(aXdPermValStp, A_XdPermVal_XdActionEn) == XdAction_ToInsert)
                                {
                                    requestHelperPtr->dbaCall(Insert,
                                                              DictPermVal,
                                                              DBA_ROLE_UDT,
                                                              aDictPermValStp,
                                                              60,
                                                              currXdAttribStp);
                                }
                            }
                            else
                            {
                                if (GET_ENUM(aXdPermValStp, A_XdPermVal_XdActionEn) == XdAction_ToInsert)
                                {
                                    requestHelperPtr->dbaCall(Update,
                                                              DictPermVal,
                                                              DBA_ROLE_UDT,
                                                              aDictPermValStp,
                                                              60,
                                                              currXdAttribStp);
                                }
                            }

                        }

                        SET_NOTNULLFLG_T(aXdPermValStp, A_XdPermVal_DictId);
                        requestHelperPtr->setCopyIdForBatchMulti(60, aXdPermValStp, A_XdPermVal_DictId, aDictPermValStp, A_DictPermVal_DictId);

                        if (GET_ENUM(aXdPermValStp, A_XdPermVal_XdActionEn) == XdAction_ToInsert)
                        {
                            SET_ENUM(aDictPermValStp, A_DictPermVal_XdStatusEn, XdStatus_Inserted);
                            requestHelperPtr->dbaCall(Update,
                                                      DictPermVal,
                                                      DBA_ROLE_STATUS,
                                                      aDictPermValStp,
                                                      61);

                            SET_ENUM(aXdPermValStp, A_XdPermVal_XdStatusEn, XdStatus_Inserted);
                        }
                        else if (GET_ENUM(aXdPermValStp, A_XdPermVal_XdActionEn) == XdAction_ToDelete ||
                                 GET_ENUM(aXdPermValStp, A_XdPermVal_XdActionEn) == XdAction_ToPhysicallyDelete)
                        {
                            SET_ENUM(aXdPermValStp, A_XdPermVal_XdStatusEn, XdStatus_Deleted);
                        }
                        else if (GET_ENUM(aXdPermValStp, A_XdPermVal_XdStatusEn) != XdStatus_Deleted &&
                                 GET_ENUM(aXdPermValStp, A_XdPermVal_XdStatusEn) != XdStatus_PhysicallyDeleted)
                        {
                            SET_ENUM(aXdPermValStp, A_XdPermVal_XdStatusEn, XdStatus_Untreated);
                        }

                        SET_ENUM(aXdPermValStp, A_XdPermVal_XdActionEn, XdAction_None);
                        SET_DATETIME(aXdPermValStp, A_XdPermVal_BuildDate, this->ddlGenContextPtr->getBuildDate());

                        requestHelperPtr->dbaCall(Update,
                                                  XdPermVal,
                                                  DBA_ROLE_STATUS,
                                                  aXdPermValStp,
                                                  50);
                    }
                }
                else
                {
                    for (auto permValIt = xdPermValAttribMapPtr->begin(); permValIt != xdPermValAttribMapPtr->end(); ++permValIt)
                    {
                        DBA_DYNFLD_STP aXdPermValStp = permValIt->second;

                        if (GET_ENUM(aXdPermValStp, A_XdPermVal_XdActionEn) == XdAction_None &&
                            (GET_ENUM(aXdPermValStp, A_XdPermVal_XdStatusEn) == XdStatus_PhysicallyDeleted ||
                             GET_ENUM(aXdPermValStp, A_XdPermVal_XdStatusEn) == XdStatus_Deleted))
                        {
                            continue;
                        }

                        SET_ENUM(aXdPermValStp, A_XdPermVal_XdStatusEn, XdStatus_Deleted);
                        SET_ENUM(aXdPermValStp, A_XdPermVal_XdActionEn, XdAction_None);
                        SET_DATETIME(aXdPermValStp, A_XdPermVal_BuildDate, this->ddlGenContextPtr->getBuildDate());

                        requestHelperPtr->dbaCall(Update,
                                                  XdPermVal,
                                                  DBA_ROLE_STATUS,
                                                  aXdPermValStp,
                                                  50);


                        SET_NULL_DICT(shDictPermValStp, S_DictPermVal_DictId);

                        this->copyDynFld(shDictPermValStp, S_DictPermVal_AttribDictId,
                                         currDictAttribStp, A_DictAttr_DictId);
                        this->copyDynFld(shDictPermValStp, S_DictPermVal_PermValNatEn,
                                         aXdPermValStp, A_XdPermVal_PermValNatEn);

                        if (requestHelperPtr->dbaGet(DictPermVal, UNUSED, shDictPermValStp, chkDictPermValStp) == RET_SUCCEED)
                        {
                            requestHelperPtr->dbaCall(Delete,
                                                      DictPermVal,
                                                      UNUSED,
                                                      chkDictPermValStp,
                                                      59);
                        }
                    }

                }
            }
        }

        if (bUpdDictEntity)
        {
            requestHelperPtr->dbaCall(Update,
                                      DictEntity,
                                      UNUSED,
                                      this->ddlGenEntityPtr->getADictEntityStp(),
                                      100);
        }

        this->m_dictEntityStp->init(true);

        /* PMSTA-43367 - LJE - 210427 */
        if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
        {
            this->printMsg(ret, "Error while writing meta-dictionary on database");
        }
    }
    catch (exception& e)
    {
        this->lastErrRetCode = RET_GEN_ERR_PERSONAL;
        this->printCatchMsg(FILEINFO, e.what());
    }

    this->finishConnection(ret);

    return this->lastErrRetCode;
}

/************************************************************************
**
**  Function    :   DdlGenFullTable::buildInMetaDict4()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-37366 - LJE - 200522
**
*************************************************************************/
RET_CODE DdlGenFullTable::buildInMetaDict4()
{
    RET_CODE   ret = RET_SUCCEED;
    DdlGenProcessLogger    ddlGenProcessLogger(*this, ret, "Meta dictionary creation (4)");

    if ((this->m_dictEntityStp = DBA_GetDictEntitySt(this->objectEn)) == NULL)
    {
        return RET_DBA_INFO_NODATA;
    }

    if (this->m_dictEntityStp->linkedEntityStp == nullptr)
    {
        ddlGenProcessLogger.start();

        try
        {
            /* PMSTA-45413 - LJE - 210707 */
            MemoryPool           mp;
            DdlGenConnGuard     ddlGenConnGuard(*this->ddlGenContextPtr);

            DdlGenRequestHelper* requestHelperPtr = this->ddlGenContextPtr->getRequestHelper();
            if (requestHelperPtr == nullptr)
            {
                requestHelperPtr = new DdlGenRequestHelper(&ddlGenConnGuard.getDbiConn(), *this->ddlGenContextPtr);
                mp.ownerObject(requestHelperPtr);
            }

            if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
            {
                ret = this->createDictCriteria(*requestHelperPtr);
            }

            /* PMSTA-14086 - LJE - 121005 */
            if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
            {
                ret = this->buildStdXdIndexes(*requestHelperPtr);
            }
        }
        catch (exception& e)
        {
            this->lastErrRetCode = RET_GEN_ERR_PERSONAL;
            this->printCatchMsg(FILEINFO, e.what());
        }
    }

    return this->lastErrRetCode;
}

/************************************************************************
**
**  Function    :   DdlGenFullTable::buildInMetaDict5()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-46681 - LJE - 230308
**
*************************************************************************/
RET_CODE DdlGenFullTable::buildInMetaDict5()
{
    RET_CODE   ret = RET_SUCCEED;
    DdlGenProcessLogger    ddlGenProcessLogger(*this, ret, "Meta dictionary creation (4)");

    if ((this->m_dictEntityStp = DBA_GetDictEntitySt(this->objectEn)) == NULL)
    {
        return RET_DBA_INFO_NODATA;
    }
    
    if (this->m_dictEntityStp->linkedEntityStp != nullptr)
    {
        ddlGenProcessLogger.start();

        try
        {
            MemoryPool           mp;
            DdlGenConnGuard     ddlGenConnGuard(*this->ddlGenContextPtr);
            DdlGenRequestHelper* requestHelperPtr = this->ddlGenContextPtr->getRequestHelper();

            if (requestHelperPtr == nullptr)
            {
                requestHelperPtr = new DdlGenRequestHelper(&ddlGenConnGuard.getDbiConn(), *this->ddlGenContextPtr);
                mp.ownerObject(requestHelperPtr);
            }

            if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
            {
                ret = this->createDictCriteria(*requestHelperPtr);
            }

            /* PMSTA-14086 - LJE - 121005 */
            if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
            {
                ret = this->buildStdXdIndexes(*requestHelperPtr);
            }
        }
        catch (exception& e)
        {
            this->lastErrRetCode = RET_GEN_ERR_PERSONAL;
            this->printCatchMsg(FILEINFO, e.what());
        }
    }

    return this->lastErrRetCode;
}

/************************************************************************
**
**  Function    :   DdlGenFullTable::checkMetaDict()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-18593 - LJE - 160114
**
*************************************************************************/
RET_CODE DdlGenFullTable::checkMetaDict()
{
    RET_CODE   ret = RET_SUCCEED, gblRet = RET_SUCCEED;
    int        i, tstPkProgN = 0;

    DdlGenProcessLogger    ddlGenProcessLogger(*this, ret, "Check Meta dictionary");

    ddlGenProcessLogger.start();

    if ((this->m_dictEntityStp = DBA_GetDictEntitySt(this->objectEn)) == NULL ||
        this->initConnection() != RET_SUCCEED)
    {
        return RET_DBA_INFO_NODATA;
    }
    DdlGenConnGuard     ddlGenConnGuard(*this->ddlGenContextPtr);

    try
    {
        DBA_DYNST_ENUM allStructEn = GET_EDITGUIST(this->m_dictEntityStp->objectEn);
        DBA_DYNST_ENUM shortStructEn = GET_ADMINGUIST(this->m_dictEntityStp->objectEn);

        map<DICT_T, DBA_DYNFLD_STP> dictAttribMap;
        for (i = 0; i < this->ddlGenEntityPtr->getXdAttribNbr(); i++)
        {
            DBA_DYNFLD_STP currXdAttribStp = this->ddlGenEntityPtr->getXdAttrib(i);

            if (IS_NULLFLD(currXdAttribStp, A_XdAttrib_AttribDictId) == FALSE &&
                (XD_STATUS_ENUM)GET_ENUM(currXdAttribStp, A_XdAttrib_XdStatusEn) != XdStatus_Deleted &&
                (XD_STATUS_ENUM)GET_ENUM(currXdAttribStp, A_XdAttrib_XdStatusEn) != XdStatus_PhysicallyDeleted)
            {
                auto attrIt = dictAttribMap.find(GET_DICT(currXdAttribStp, A_XdAttrib_AttribDictId));

                if (attrIt != dictAttribMap.end())
                {
                    stringstream msg;
                    ret = RET_DBA_ERR_INVDATA;
                    msg << "Duplicate attribute_dict_id (" << GET_DICT(currXdAttribStp, A_XdAttrib_AttribDictId) << ") for attributes '"
                        << GET_SYSNAME(attrIt->second, A_XdAttrib_SqlName) << "' and '"
                        << GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName) << "'";
                    this->printMsg(ret, msg.str());

                    gblRet = ret;
                }
                else
                {
                    dictAttribMap.insert(make_pair(GET_DICT(currXdAttribStp, A_XdAttrib_AttribDictId), currXdAttribStp));
                }
            }
        }

        if (gblRet != RET_SUCCEED)
        {
            for (i = 0; i < this->ddlGenEntityPtr->getXdAttribNbr(); i++)
            {
                cout << endl << this->ddlGenEntityPtr->getXdAttrib(i)->disp();
            }
            cout << endl;
        }

        TARGET_TABLE_ENUM targetTableEn = TargetTable_Main;

        INT_T             dbProgN = 0;
        INT_T             udIdProgN = 0;
        for (auto attribIt = this->m_dictEntityStp->attr.begin(); attribIt != this->m_dictEntityStp->attr.end(); ++attribIt, dbProgN++)
        {
            DICT_ATTRIB_STP dictAttribStp = (*attribIt);

            if (dictAttribStp->refDeleteRuleEn == RefDelRule_Inherited)
            {
                DICT_ATTRIB_STP linkedDictAttribStp = DBA_GetLinkAttribStp(dictAttribStp);

                if (linkedDictAttribStp == NULL)
                {
                    stringstream msg;
                    ret = RET_DBA_ERR_INVDATA;
                    msg << "Attribute having inherited delete rule without referenced attribute: " << dictAttribStp->sqlName;
                    this->printMsg(ret, msg.str());

                    gblRet = ret;
                }
            }

            if (dictAttribStp->isPhysicalAttribute() &&
                ((targetTableEn == TargetTable_Main && dictAttribStp->progN != dbProgN) ||
                 (targetTableEn == TargetTable_UserDefinedFields && (dictAttribStp->progN - udIdProgN) != dbProgN)))
            {
                stringstream msg;
                ret = RET_DBA_ERR_INVDATA;
                msg << "Invalid prog_n (vs database definition) value for attribute: " << dictAttribStp->sqlName;
                this->printMsg(ret, msg.str());

                gblRet = ret;
            }

            if (dictAttribStp->logicalFlg == FALSE &&
                dictAttribStp->custFlg == FALSE &&
                dictAttribStp->precompFlg == FALSE)
            {
                if (EV_DynStPtr[allStructEn].dynStDefPtr[dictAttribStp->progN].dataType != dictAttribStp->dataTpProgN)
                {
                    stringstream msg;
                    ret = RET_DBA_ERR_INVDATA;
                    msg << "Invalid data-type for attribute: " << dictAttribStp->sqlName;
                    this->printMsg(ret, msg.str());

                    gblRet = ret;
                }
                if (dictAttribStp->isNullShortIdx == false &&
                    EV_DynStPtr[shortStructEn].dynStDefPtr[dictAttribStp->shortIdx].dataType != dictAttribStp->dataTpProgN)
                {
                    stringstream msg;
                    ret = RET_DBA_ERR_INVDATA;
                    msg << "Invalid data-type for short attribute: " << dictAttribStp->sqlName;
                    this->printMsg(ret, msg.str());

                    gblRet = ret;
                }
            }

            if (this->bTableToDo &&
                this->ddlGenContextPtr->m_rdbmsEn == Sybase &&
                this->m_dictEntityStp->entNatEn != EntityNat_System &&
                (this->m_dictEntityStp->securityLevelEn == EntSecuLevel_InsertAllowed ||
                 this->m_dictEntityStp->securityLevelEn == EntSecuLevel_InsertDeleteAllowed) &&
                dictAttribStp->precompFlg == FALSE &&
                dictAttribStp->isPhysicalAttribute())
            {
                if (dictAttribStp->custFlg == TRUE &&
                    targetTableEn != TargetTable_UserDefinedFields)
                {
                    dbProgN = 0;
                    udIdProgN     = dictAttribStp->progN;
                    targetTableEn = TargetTable_UserDefinedFields;
                }

                if (dictAttribStp->precompFlg == TRUE &&
                    targetTableEn != TargetTable_Precomp)
                {
                    targetTableEn = TargetTable_Precomp;
                }

                DBA_DYNFLD_STP sysXdAttribStp = this->ddlGenEntityPtr->getSysXdAttribStp(targetTableEn, dictAttribStp->sqlName);

                if (sysXdAttribStp != nullptr &&
                    GET_INT(sysXdAttribStp, A_XdAttrib_Prog) != dbProgN)
                {
                    ret = RET_DBA_INFO_NODATA;
                    gblRet = ret;
                    stringstream msg;
                    msg << "Invalid prog_n position for attribute "
                        << this->m_dictEntityStp->mdSqlName << "." << dictAttribStp->sqlName
                        << " " << dbProgN << " instead of " << GET_INT(sysXdAttribStp, A_XdAttrib_Prog);
                    this->printMsg(ret, msg.str());
                }
            }
        }

        for (auto criteriaIt = this->m_dictEntityStp->allDictCriteriaMap.begin(); criteriaIt != this->m_dictEntityStp->allDictCriteriaMap.end(); ++criteriaIt)
        {
            if (criteriaIt->second->entDictId == 0 ||
                criteriaIt->second->attrPtr == nullptr)
            {
                stringstream msg;
                ret = RET_DBA_ERR_INVDATA;
                msg << "Invalid criteria for position : " << criteriaIt->first;
                this->printMsg(ret, msg.str());

                gblRet = ret;
            }
        }

        for (auto criteriaIt = this->m_dictEntityStp->shortDictCriteriaMap.begin(); criteriaIt != this->m_dictEntityStp->shortDictCriteriaMap.end(); ++criteriaIt)
        {
            if (criteriaIt->second->entDictId == 0 ||
                criteriaIt->second->attrPtr == nullptr)
            {
                stringstream msg;
                ret = RET_DBA_ERR_INVDATA;
                msg << "Invalid criteria for position : " << criteriaIt->first;
                this->printMsg(ret, msg.str());

                gblRet = ret;
            }
        }

        for (i = 0; i < this->m_dictEntityStp->dbPKNbr; i++)
        {
            DICT_ATTRIB_STP dictAttribStp = this->m_dictEntityStp->dbPKTab[i];

            if (tstPkProgN != dictAttribStp->progPkN || dictAttribStp->isNullProgPkN == true)
            {
                stringstream msg;
                ret = RET_DBA_ERR_INVDATA;
                msg << "Invalid or undefined primary key order for attribute: " << dictAttribStp->sqlName;
                this->printMsg(ret, msg.str());

                gblRet = ret;
            }
            tstPkProgN++;
        }

        if (this->m_dictEntityStp->multiEntityCateg.isOwnerBusinessEntity())
        {
            if (this->m_dictEntityStp->ownerBusinessEntAttrStp == nullptr)
            {
                stringstream msg;
                ret = RET_DBA_ERR_INVDATA;
                msg << "Invalid or undefined multi-entity configuration (connected business entity attribute missing)";
                this->printMsg(ret, msg.str());

                gblRet = ret;
            }
        }
    }
    catch (exception& e)
    {
        gblRet = RET_GEN_ERR_PERSONAL;
        this->printCatchMsg(FILEINFO, e.what());
    }

    this->finishConnection(gblRet);

    return gblRet;
}

/************************************************************************
**
**  Function    :   DdlGenFullTable::checkIdentityValues()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-37374 - LJE - 201214
**
*************************************************************************/
RET_CODE DdlGenFullTable::checkIdentityValues()
{
    RET_CODE   ret = RET_SUCCEED;

    DdlGenProcessLogger    ddlGenProcessLogger(*this, ret, "Check Identity values");

    if ((this->m_dictEntityStp = DBA_GetDictEntitySt(this->objectEn)) == nullptr ||
        this->m_dictEntityStp->isPhysicalEntity(TargetTable_Main) == false ||
        this->m_dictEntityStp->dbRuleEn == DbRule_TableBasedOnView ||
        this->m_dictEntityStp->entNatEn == EntityNat_TempTable ||
        this->m_dictEntityStp->pkRuleEn != PkRule_Identity ||
        this->initConnection() != RET_SUCCEED ||
        this->ddlGenContextPtr->m_rdbmsEn == Sqlite)
    {
        return RET_DBA_INFO_NODATA;
    }

    {
        ddlGenProcessLogger.start();

        
        DdlGenFile  localFileHeper(*this->ddlGenContextPtr, this->objectEn, DdlObj_Table, true, this->ddlGenContextPtr->bCheck);
        DdlGenTable ddlGenTable(this->objectEn, TargetTable_Main, *this->ddlGenContextPtr, this->ddlGenEntityPtr, &localFileHeper);

        this->ddlGenContextPtr->setDdlDestDbName(this->m_dictEntityStp->databaseName, &ddlGenTable);

        ID_T maxIdentityValue = ddlGenTable.getIdentityStartValue(this->m_dictEntityStp, this->ddlGenEntityPtr, true);

        string       idSqlName = this->m_dictEntityStp->primKeyTab[0]->sqlName;
        stringstream getNextIdentityStream;

        if (this->ddlGenContextPtr->m_rdbmsEn == PostgreSQL)
        {
            getNextIdentityStream
                << std::endl << "#SELECT empty null"
                << std::endl << ddlGenTable.getCmdReserveIdentity(nullptr, this->m_dictEntityStp, this->m_dictEntityStp->dbSqlName, "1")  << " as nextIdValue"
                << std::endl << "#FROM"
                << std::endl << "#WHERE"
                << std::endl << "#END";
        }
        else
        {
            getNextIdentityStream
                << std::endl << "#DECLARE @nextIdValue id_t"
                << std::endl << "#RESERVE_IDENTITY " << this->m_dictEntityStp->mdSqlName << " @nextIdValue 1"
                << std::endl << "#SELECT empty null"
                << std::endl << idSqlName << " = @nextIdValue"
                << std::endl << "#FROM"
                << std::endl << "#WHERE"
                << std::endl << "#END";
        }

        DdlGenConnGuard     ddlGenConnGuard(*this->ddlGenContextPtr);
        DdlGenRequestHelper requestHelper(&ddlGenConnGuard.getDbiConnForDdl(), *this->ddlGenContextPtr);
        ID_T* nextIdentityValuePtr = nullptr;

        requestHelper.setCommand(getNextIdentityStream.str());
        requestHelper.addNewOutputData(IdType, idSqlName.c_str());
        requestHelper.getBindVariablePtr(nextIdentityValuePtr);
        requestHelper.setReadOnly(true);

        if (requestHelper.sendAndGetCommand() == RET_SUCCEED &&
            nextIdentityValuePtr != nullptr)
        {
            stringstream msg;
            msg << "Max identity value: " << maxIdentityValue << ", next identity value: " << *nextIdentityValuePtr;

            if (*nextIdentityValuePtr < maxIdentityValue)
            {
                ddlGenTable.setIdentityStartValue(this->m_dictEntityStp, maxIdentityValue);
                msg << " - Updated";
            }
            else
            {
                msg << " - Skipped";
            }

            this->ddlGenContextPtr->printMsg(RET_DBA_INFO_EXIST, msg.str());

            if (strcmp(this->m_dictEntityStp->mdSqlName, "xd_attribute") == 0)
            {
                this->ddlGenContextPtr->printMsg(RET_DBA_INFO_EXIST, "Fixing missing xd_attribute records...");

                std::stringstream fixMissingXdAttrib;
                fixMissingXdAttrib
                    << std::endl << "#INSERT xd_attribute all_db std"
                    << std::endl << "attrib_dict_id"
                    << std::endl << "#SELECT xd_attribute all_db da dict_attribute"
                    << std::endl << "xd_entity_id = xe.id"
                    << std::endl << "attrib_dict_id = da.dict_id"
                    << std::endl << "#FROM"
                    << std::endl << "inner join dict_entity de on de.dict_id = da.entity_dict_id"
                    << std::endl << "inner join xd_entity xe on de.sqlname_c = xe.sqlname_c"
                    << std::endl << "#WHERE"
                    << std::endl << "da.precomputed_f = 0"
                    << std::endl << "not exists(select * from xd_attribute xa where xe.id = xa.xd_entity_id and xa.sqlname_c = da.sqlname_c)"
                    << std::endl << "#END";

                requestHelper.finishRequest();
                requestHelper.setReadOnly(false);
                requestHelper.setCommand(fixMissingXdAttrib.str());
                if (requestHelper.sendAndGetCommand() == RET_SUCCEED)
                {
                    this->ddlGenContextPtr->printMsg(RET_DBA_INFO_EXIST, "Done");
                }
                else
                {
                    this->ddlGenContextPtr->printMsg(RET_DBA_INFO_EXIST, "Failed");
                }

                this->ddlGenContextPtr->printMsg(RET_DBA_INFO_EXIST, "Fixing xd_attribute.attribute_dict_id values...");

                std::stringstream fixXdAttribDictId;
                fixXdAttribDictId
                    << std::endl << "#DECLARE @xa_id  id_t,"
                    << std::endl << "@xa_dict_id dict_t"
                    << std::endl << ""
                    << std::endl << "#SELECT_CURSOR xd_attribute null xa"
                    << std::endl << "@xa_id = xa.id"
                    << std::endl << "@xa_dict_id = da.dict_id"
                    << std::endl << "#FROM"
                    << std::endl << "inner join xd_entity xe on xe.id = xa.xd_entity_id"
                    << std::endl << "inner join dict_entity de on de.sqlname_c = xe.sqlname_c"
                    << std::endl << "inner join dict_attribute da on de.dict_id = da.entity_dict_id and da.sqlname_c = xa.sqlname_c";
                fixXdAttribDictId
                    << std::endl << "#WHERE"
                    << std::endl << "xa.precomputed_f = 0"
                    << std::endl << "xa.attrib_dict_id != da.dict_id"
                    << std::endl << "#FETCH_CURSOR"
                    << std::endl << "#UPDATE xd_attribute null"
                    << std::endl << "attrib_dict_id = @xa_dict_id"
                    << std::endl << "#FROM"
                    << std::endl << "#WHERE"
                    << std::endl << "id = @xa_id"
                    << std::endl << "#END"
                    << std::endl << "#END_CURSOR";

                requestHelper.finishRequest();
                requestHelper.setReadOnly(false);
                requestHelper.setCommand(fixXdAttribDictId.str());
                if (requestHelper.sendAndGetCommand() == RET_SUCCEED)
                {
                    this->ddlGenContextPtr->printMsg(RET_DBA_INFO_EXIST, "Done");
                }
                else
                {
                    this->ddlGenContextPtr->printMsg(RET_DBA_INFO_EXIST, "Failed");
                }
            }
        }
    }

    this->finishConnection(ret);
    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenFullTable::saveReferencesInDb()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-26108 - LJE - 171002
**
*************************************************************************/
RET_CODE DdlGenFullTable::saveReferencesInDb()
{
    RET_CODE   ret = RET_SUCCEED, gblRet = RET_SUCCEED;
    DdlGenProcessLogger    ddlGenProcessLogger(*this, gblRet, "Save References in Database");

    if (this->ddlGenContextPtr->bSimulation)
    {
        return ret;
    }

    ddlGenProcessLogger.start();

    if ((this->m_dictEntityStp = DBA_GetDictEntitySt(this->objectEn)) == NULL ||
        this->initConnection() != RET_SUCCEED)
    {
        return RET_DBA_INFO_NODATA;
    }

    try
    {
        /* PMSTA-26108 - LJE - 171002 - Save dict_entity_constraints */
        DdlGenConnGuard     ddlGenConnGuard(*this->ddlGenContextPtr);
        DdlGenRequestHelper requestHelper(&ddlGenConnGuard.getDbiConn(), *this->ddlGenContextPtr);

        DBA_DYNFLD_STP shDictEntityConstr = requestHelper.allocDynSt(FILEINFO, S_DictEntityConstraints);
        SET_DICT(shDictEntityConstr, S_DictEntityConstraints_EntityDictId, this->m_dictEntityStp->entDictId);

        requestHelper.dbaCall(Delete,
                              DictEntityConstraints,
                              UNUSED,
                              shDictEntityConstr,
                              0);

        for (auto it = this->m_dictEntityStp->dictEntityConstrMap.begin(); it != this->m_dictEntityStp->dictEntityConstrMap.end(); it++)
        {
            DictEntityConstrClass& dictEntityConstrSt = it->second;
            DBA_DYNFLD_STP allDictEntityConstr = requestHelper.allocDynSt(FILEINFO, A_DictEntityConstraints);

            SET_DICT(allDictEntityConstr, A_DictEntityConstraints_EntityDictId, this->m_dictEntityStp->entDictId);
            SET_SYSNAME(allDictEntityConstr, A_DictEntityConstraints_EntitySqlName, this->m_dictEntityStp->dbSqlName);

            SET_DICT(allDictEntityConstr, A_DictEntityConstraints_RefEntityDictId, dictEntityConstrSt.refEntityDictId);
            SET_DICT(allDictEntityConstr, A_DictEntityConstraints_RefAttribDictId, dictEntityConstrSt.refAttribDictId);
            SET_ENUM(allDictEntityConstr, A_DictEntityConstraints_RefDeleteRuleEn, dictEntityConstrSt.refDeleteRuleEn);
            SET_ENUM(allDictEntityConstr, A_DictEntityConstraints_RefCheckRuleEn, dictEntityConstrSt.refCheckRuleEn);
            SET_ENUM(allDictEntityConstr, A_DictEntityConstraints_AggregationEn, dictEntityConstrSt.aggregationEn);
            SET_ENUM(allDictEntityConstr, A_DictEntityConstraints_MultiplicityEn, dictEntityConstrSt.multiplicityEn);
            SET_SYSNAME(allDictEntityConstr, A_DictEntityConstraints_RefEntitySqlName, dictEntityConstrSt.refEntitySqlName.c_str());
            SET_SYSNAME(allDictEntityConstr, A_DictEntityConstraints_RefAttribSqlName, dictEntityConstrSt.refAttribSqlName.c_str());

            SET_ENUM(allDictEntityConstr, A_DictEntityConstraints_MultiEntityCategoryEn, dictEntityConstrSt.refDictEntityStp->multiEntityCateg.get());

            requestHelper.dbaCall(Insert,
                                  DictEntityConstraints,
                                  UNUSED,
                                  allDictEntityConstr);
        }
    }
    catch (exception& e)
    {
        gblRet = RET_GEN_ERR_PERSONAL;
        this->printCatchMsg(FILEINFO, e.what());
    }

    this->finishConnection(gblRet);

    return gblRet;
}

/************************************************************************
**
**  Function    :   DdlGenFullTable::setTablesStatistics()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 211011
**
*************************************************************************/
RET_CODE DdlGenFullTable::setTablesStatistics(TARGET_TABLE_ENUM targetTableEn)
{
    RET_CODE               ret = RET_SUCCEED;
    DdlGenProcessLogger    ddlGenProcessLogger(*this, ret, "Set table statistics");

    if ((this->m_dictEntityStp = DBA_GetDictEntitySt(this->objectEn)) == NULL)
    {
        return RET_DBA_INFO_NODATA;
    }
  
    if (this->getDdlGenContextPtr()->isEntityToMigrate(this->m_dictEntityStp->mdSqlName) == false)
    {
        ret = RET_SRV_INFO_NO_POSITIONS;
        return ret;
    }

    if (this->bTableToDo == false &&
        this->bUdTableToDo == false)
    {
        ret = RET_SRV_INFO_NO_POSITIONS;
        return ret;
    }

    DdlGenFile  localFileHeper(*this->ddlGenContextPtr, this->objectEn, DdlObj_Table, false, this->ddlGenContextPtr->bCheck);
    DdlGenFile* localFileHeperPtr = (this->ddlGenContextPtr->m_parentFileHeper != nullptr ? this->ddlGenContextPtr->m_parentFileHeper : &localFileHeper);

    ddlGenProcessLogger.start();

    try
    {
        if (this->initConnection(localFileHeperPtr, false) != RET_SUCCEED)
        {
            return RET_DBA_INFO_NODATA;
        }

        this->ddlGenContextPtr->setMsgInfo(*this);

        this->ddlGenEntityPtr->setStatistics(targetTableEn, this->getDdlGenContextPtr());

        auto& statistics = this->ddlGenEntityPtr->m_statisticsMap[targetTableEn];
        stringstream msg;

        msg << "Statistics information - "
            << "source: " << statistics.m_sourceTotRows << " records, "
            << "target: " << statistics.m_targetTotRows << " records, ";

        if (statistics.m_sourceTotRows > 0)
        {
            msg << "record weight: " << statistics.m_transfertSize;
        }
        else if (statistics.m_statisticInfo.empty() == false)
        {
            msg << "(" << statistics.m_statisticInfo << ")";
        }
        this->printMsg(RET_DBA_INFO_EXIST, msg.str());
    }
    catch (exception& e)
    {
        ret = RET_GEN_ERR_PERSONAL;
        this->printCatchMsg(FILEINFO, e.what());
    }

    if (ret == RET_SUCCEED)
    {
        this->ddlGenContextPtr->cleanDbiConnMsg();
    }
    this->finishConnection(ret);

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenFullTable::buildTablesInDB()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13109 - LJE - 110311
**
*************************************************************************/
RET_CODE DdlGenFullTable::buildTablesInDB(TARGET_TABLE_ENUM targetTableEn)
{
    RET_CODE               ret = RET_SUCCEED;
    DdlGenProcessLogger    ddlGenProcessLogger(*this, ret, "Creation of the table");
    bool                   bAppendFile = true;

    this->ddlGenContextPtr->m_useAlternativeDataServer = false;

    if ((this->m_dictEntityStp = DBA_GetDictEntitySt(this->objectEn)) == NULL)
    {
        return RET_DBA_INFO_NODATA;
    }

    if (this->m_dictEntityStp->entNatEn == EntityNat_Internal)
    {
        auto targetDictEntityStp = DBA_GetEntityBySqlName(this->m_dictEntityStp->mdSqlName);
        if (targetDictEntityStp == nullptr)
        {
            return RET_DBA_INFO_NODATA;
        }

        auto sourceDictEntityStp = DBA_GetEntityBySqlName(this->m_dictEntityStp->mdSqlName, true, true);
        if (sourceDictEntityStp == nullptr)
        {
            return RET_DBA_INFO_NODATA;
        }
    }

    this->ddlGenContextPtr->setMsgInfo(*this);

    if (this->ddlGenContextPtr->bGenFromDbi)
    {
        if (this->bTableToDo == false)
        {
            this->bTableToDo = true;
        }
        this->ddlGenContextPtr->bSimulation = true;
        this->ddlGenContextPtr->bForceReBuild = true;
        bAppendFile = false;
    }

    if (this->m_dictEntityStp->entNatEn == EntityNat_ReportFmt)
    {
        bAppendFile = false;
    }

    string targetSqlName = this->getDdlGenAction().m_targetSqlnameStr;

    if (targetTableEn == TargetTable_Undefined || targetTableEn == TargetTable_Main)
    {
        /* PMSTA-48207 - LJE - 220330 - To manage list_compo migration */
        if (this->bTableToDo == false &&
            this->ddlGenContextPtr->migrationMode != DdlGenContext::MigrationMode::None &&
            this->m_dictEntityStp->dbRuleEn == DbRule_TableBasedOnView)
        {
            DICT_ENTITY_STP sourceDictEntityStp = DBA_GetEntityBySqlName(this->m_dictEntityStp->mdSqlName, true, true);

            if (sourceDictEntityStp != nullptr &&
                sourceDictEntityStp->dbRuleEn == DbRule_Standard &&
                sourceDictEntityStp->logicalFlg == FALSE &&
                this->ddlGenContextPtr->m_parentContext->tablesFromSrcSysMap[sourceDictEntityStp->databaseName].find(sourceDictEntityStp->dbSqlName) !=
                this->ddlGenContextPtr->m_parentContext->tablesFromSrcSysMap[sourceDictEntityStp->databaseName].end())
            {
                targetSqlName = this->m_dictEntityStp->mdSqlName;
                targetSqlName += "_bck";
                this->bTableToDo = true;
            }
        }
    }

    if (this->bTableToDo == false &&
        this->bUdTableToDo == false)
    {
        ret = RET_SRV_INFO_NO_POSITIONS;
        return ret;
    }

    DdlGenFile  localFileHeper(*this->ddlGenContextPtr, this->objectEn, DdlObj_Table, bAppendFile, this->ddlGenContextPtr->bCheck);
    DdlGenFile* localFileHeperPtr = (this->ddlGenContextPtr->m_parentFileHeper != nullptr ? this->ddlGenContextPtr->m_parentFileHeper : &localFileHeper);

    ddlGenProcessLogger.start();

    try
    {
        if (this->initConnection(localFileHeperPtr, false) != RET_SUCCEED)
        {
            return RET_DBA_INFO_NODATA;
        }
        DdlGenConnGuard     ddlGenConnGuard(*this->ddlGenContextPtr);

        /* Create table only in the first pass */
        if (RET_GET_LEVEL(ret) != RET_LEV_ERROR &&
            this->bTableToDo &&
            (targetTableEn == TargetTable_Undefined || targetTableEn == TargetTable_Main))
        {
            DdlGenTable::Ptr genDdl(new DdlGenTable(this->objectEn,
                                                    TargetTable_Main,
                                                    *this->ddlGenContextPtr,
                                                    this->ddlGenEntityPtr,
                                                    localFileHeperPtr));

            if (targetSqlName.empty() == false)
            {
                genDdl->setTableNamePatern(targetSqlName);
                genDdl->bKeepRealObject = true;
            }
            ret = genDdl->build();
        }

        if (RET_GET_LEVEL(ret) != RET_LEV_ERROR && 
            this->bUdTableToDo &&
            (targetTableEn == TargetTable_Undefined || targetTableEn == TargetTable_UserDefinedFields))
        {
            DdlGenTable::Ptr genDdl(new DdlGenTable(this->objectEn,
                                                    TargetTable_UserDefinedFields,
                                                    *this->ddlGenContextPtr,
                                                    this->ddlGenEntityPtr,
                                                    localFileHeperPtr));

            if (this->bTableToDo)
            {
                genDdl->bAppendFile = true;
            }

            if (targetSqlName.empty() == false)
            {
                genDdl->setTableNamePatern(targetSqlName);
                genDdl->bKeepRealObject = true;
            }
            ret = genDdl->build();
        }

        if (RET_GET_LEVEL(ret) != RET_LEV_ERROR && 
            this->bExtTableToDo &&
            (targetTableEn == TargetTable_Undefined || targetTableEn == TargetTable_Precomp))
        {
            DdlGenTable::Ptr genDdl(new DdlGenTable(this->objectEn,
                                                    TargetTable_Precomp,
                                                    *this->ddlGenContextPtr,
                                                    this->ddlGenEntityPtr,
                                                    localFileHeperPtr));

            if (targetSqlName.empty() == false)
            {
                genDdl->setTableNamePatern(targetSqlName);
                genDdl->bKeepRealObject = true;
            }
            ret = genDdl->build();
        }

        if (targetTableEn == TargetTable_Undefined || targetTableEn == TargetTable_Main)
        {
            if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
            {
                this->m_dictEntityStp->xdStatusEn = XdStatus_Inserted;
            }
            else
            {
                this->m_dictEntityStp->xdStatusEn = XdStatus_Failed;
            }

            int                    partitionNbr = this->ddlGenEntityPtr->getXdPartitionNbr();
            DBA_DYNFLD_STP* partitionTab = this->ddlGenEntityPtr->getXdPartitionTab();

            for (int i = 0; i < partitionNbr; i++)
            {
                if (GET_ENUM(partitionTab[i], A_XdPartition_XdActionEn) == XdAction_ToInsert &&
                    GET_ENUM(partitionTab[i], A_XdPartition_XdStatusEn) != XdStatus_Inserted)
                {
                    SET_ENUM(partitionTab[i], A_XdPartition_XdStatusEn, this->m_dictEntityStp->xdStatusEn);
                    SET_DATETIME(partitionTab[i], A_XdPartition_BuildDate, this->ddlGenContextPtr->getBuildDate());
                }
                else if (GET_ENUM(partitionTab[i], A_XdPartition_XdActionEn) != XdAction_None &&
                         GET_ENUM(partitionTab[i], A_XdPartition_XdActionEn) != XdAction_ToInsert &&
                         GET_ENUM(partitionTab[i], A_XdPartition_XdStatusEn) != XdStatus_PhysicallyDeleted)
                {
                    SET_ENUM(partitionTab[i], A_XdPartition_XdStatusEn, XdStatus_PhysicallyDeleted);
                    SET_DATETIME(partitionTab[i], A_XdPartition_BuildDate, this->ddlGenContextPtr->getBuildDate());
                }

                if (GET_ENUM(partitionTab[i], A_XdPartition_XdActionEn) != XdAction_None)
                {
                    SET_ENUM(partitionTab[i], A_XdPartition_XdActionEn, XdAction_None);

                    if ((ret = DBA_Update2(XdPartition,
                                           DBA_ROLE_STATUS,
                                           A_XdPartition,
                                           partitionTab[i],
                                           DBA_SET_CONN | DBA_NO_CLOSE,
                                           ddlGenConnGuard.getDbiConn())) != RET_SUCCEED)
                    {
                        ddlGenConnGuard.getDbiConn().sendAllMsg();
                        this->finishConnection(ret);
                        this->printMsgData(RET_DBA_ERR_UPDATE_FAILED, partitionTab[i]);
                    }
                }
            }
        }
    }
    catch (exception& e)
    {
        ret = RET_GEN_ERR_PERSONAL;
        this->printCatchMsg(FILEINFO, e.what());
    }

    if (ret == RET_SUCCEED)
    {
        this->ddlGenContextPtr->cleanDbiConnMsg();
    }
    this->finishConnection(ret);

    this->lastErrRetCode = ret;

    return this->lastErrRetCode;
}

/************************************************************************
**
**  Function    :   DdlGenFullTable::buildVerticalTablesInDB()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-40034 - LJE - 200511
**
*************************************************************************/
RET_CODE DdlGenFullTable::buildVerticalTablesInDB()
{
    RET_CODE               ret = RET_SUCCEED;
    DdlGenProcessLogger    ddlGenProcessLogger(*this, ret, "Creation of the vertical tables");

    this->ddlGenContextPtr->setMsgInfo(*this);

    if (this->bVerticalPatternToDo == false && this->bVerticalSearchToDo == false)
    {
        ret = RET_SRV_INFO_NO_POSITIONS;
        return ret;
    }

    DdlGenFile localFileHeper(*this->ddlGenContextPtr, this->objectEn, DdlObj_Table, true, this->ddlGenContextPtr->bCheck);

    ddlGenProcessLogger.start();

    try
    {
        if ((this->m_dictEntityStp = DBA_GetDictEntitySt(this->objectEn)) == NULL ||
            this->initConnection(&localFileHeper, false) != RET_SUCCEED)
        {
            return RET_DBA_INFO_NODATA;
        }

        DdlGenAction    ddlGenAction(this->getDdlGenAction(), true);

        ddlGenAction.m_entitySqlnameStr = "tsl_vertical_search";
        ddlGenAction.m_execModeEn = DbObjExecMod_BuildFromTemplate;
        ddlGenAction.m_srcDictEntityStp = this->m_dictEntityStp;                  /* PMSTA-43186 - LJE - 210203 */
        ddlGenAction.m_subRequest = true;

        auto vsDictEntityStp = DBA_GetEntityBySqlName(ddlGenAction.m_entitySqlnameStr);

        this->ddlGenContextPtr->m_parentFileHeper = &localFileHeper;

        vector<string> prefixVector;
        if (this->bVerticalPatternToDo == true)
        {
            prefixVector.push_back("ps_");
        }
        if (this->bVerticalSearchToDo == true)
        {
            prefixVector.push_back("vs_");
        }

        for (auto it = prefixVector.begin(); it != prefixVector.end(); ++it)
        {
            ddlGenAction.m_targetSqlnameStr = (*it) + this->m_dictEntityStp->mdSqlName;
            ddlGenAction.m_shortTargetSqlnameStr = (*it) + this->m_dictEntityStp->aliasSqlname + "_" + SYS_Stringer(this->m_dictEntityStp->entDictId);

            ddlGenAction.m_ddlObjNatEn = DbObjDdlObjNat_Table;
            ret = DDL_InstallDdlObject(ddlGenAction, *this->ddlGenContextPtr);

            ddlGenAction.m_ddlObjNatEn = DbObjDdlObjNat_Index;
            ret = DDL_InstallDdlObject(ddlGenAction, *this->ddlGenContextPtr);

            if (vsDictEntityStp->databaseName != this->ddlGenContextPtr->getMainDbName())
            {
                this->ddlGenContextPtr->setDefDdlDestDbName(this->ddlGenContextPtr->getMainDbName());
                ddlGenAction.m_ddlObjNatEn = DbObjDdlObjNat_View;
                ret = DDL_InstallDdlObject(ddlGenAction, *this->ddlGenContextPtr);
            }

        }

        if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
        {
            ret = RET_SUCCEED;
        }
    }
    catch (exception& e)
    {
        ret = RET_GEN_ERR_PERSONAL;
        this->printCatchMsg(FILEINFO, e.what());
    }

    this->ddlGenContextPtr->m_parentFileHeper = nullptr;
    this->finishConnection(ret);

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenFullTable::deleteTablesInDB()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13109 - LJE - 110311
**
*************************************************************************/
RET_CODE DdlGenFullTable::deleteTablesInDB()
{
    RET_CODE               ret = RET_SUCCEED;
    DdlGenTable* genDdl;
    DdlGenProcessLogger    ddlGenProcessLogger(*this, ret, "Dropping of the table");

    if (this->bTableToDo == false && this->bUdTableToDo == false)
    {
        ret = RET_SRV_INFO_NO_POSITIONS;
        return ret;
    }
    DdlGenFile             localFileHeper(*this->ddlGenContextPtr, this->objectEn, DdlObj_Table, true, this->ddlGenContextPtr->bCheck);

    ddlGenProcessLogger.start();

    if ((this->m_dictEntityStp = DBA_GetDictEntitySt(this->objectEn)) == NULL ||
        this->initConnection(&localFileHeper, false) != RET_SUCCEED)
    {
        return RET_DBA_INFO_NODATA;
    }
    DdlGenConnGuard     ddlGenConnGuard(*this->ddlGenContextPtr);

    try
    {
        /* Create table only in the first pass */
        if (RET_GET_LEVEL(ret) != RET_LEV_ERROR && this->bTableToDo)
        {
            genDdl = new DdlGenTable(this->objectEn, TargetTable_Main, *this->ddlGenContextPtr, this->ddlGenEntityPtr, &localFileHeper);
            ret = genDdl->dropTable();
            delete genDdl;

            if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
            {
                auto& xdIndexVector = this->ddlGenEntityPtr->getXdIndexVector();
                for (auto it = xdIndexVector.begin(); it != xdIndexVector.end(); ++it)
                {
                    DBA_DYNFLD_STP currXdIndexStp = *it;

                    SET_ENUM(currXdIndexStp, A_XdIndex_XdStatusEn, XdStatus_PhysicallyDeleted);
                    SET_ENUM(currXdIndexStp, A_XdIndex_XdActionEn, XdAction_None);
                    SET_DATETIME(currXdIndexStp, A_XdIndex_BuildDate, this->ddlGenContextPtr->getBuildDate());

                    if (DBA_Update2(XdIndex,
                                    DBA_ROLE_STATUS,
                                    A_XdIndex,
                                    currXdIndexStp,
                                    DBA_SET_CONN | DBA_NO_CLOSE,
                                    ddlGenConnGuard.getDbiConn()) != RET_SUCCEED)
                    {
                        ddlGenConnGuard.getDbiConn().sendAllMsg();
                        this->finishConnection(ret);
                        this->printMsgData(RET_DBA_ERR_UPDATE_FAILED, currXdIndexStp);
                        return(ret);
                    }

                    auto& xdIndexAttribMap = this->ddlGenEntityPtr->getXdIndexAttribVector(currXdIndexStp);
                    for (auto it2 = xdIndexAttribMap.begin(); it2 != xdIndexAttribMap.end(); ++it2)
                    {
                        DBA_DYNFLD_STP currXdIndexAttribStp = (*it2);

                        SET_ENUM(currXdIndexAttribStp, A_XdIndexAttrib_XdStatusEn, XdStatus_PhysicallyDeleted);
                        SET_ENUM(currXdIndexAttribStp, A_XdIndexAttrib_XdActionEn, XdAction_None);
                        SET_DATETIME(currXdIndexAttribStp, A_XdIndexAttrib_BuildDate, this->ddlGenContextPtr->getBuildDate());

                        if (DBA_Update2(XdIndexAttrib,
                                        DBA_ROLE_STATUS,
                                        A_XdIndexAttrib,
                                        currXdIndexAttribStp,
                                        DBA_SET_CONN | DBA_NO_CLOSE,
                                        ddlGenConnGuard.getDbiConn()) != RET_SUCCEED)
                        {
                            ddlGenConnGuard.getDbiConn().sendAllMsg();

                            this->finishConnection(ret);
                            this->printMsgData(RET_DBA_ERR_UPDATE_FAILED, currXdIndexAttribStp);
                            return(ret);
                        }
                    }
                }
            }
        }

        if (RET_GET_LEVEL(ret) != RET_LEV_ERROR && this->bUdTableToDo)
        {
            genDdl = new DdlGenTable(this->objectEn, TargetTable_UserDefinedFields, *this->ddlGenContextPtr, this->ddlGenEntityPtr, &localFileHeper);

            if (this->bTableToDo)
            {
                genDdl->bAppendFile = true;
            }

            ret = genDdl->dropTable();
            delete genDdl;
        }
    }
    catch (exception& e)
    {
        ret = RET_GEN_ERR_PERSONAL;
        this->printCatchMsg(FILEINFO, e.what());
    }

    this->finishConnection(ret);

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenFullTable::buildIndexesInDB()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13122 - LJE - 120413
**
*************************************************************************/
RET_CODE DdlGenFullTable::buildIndexesInDB(const string& idxSqlNameOnly)
{
    RET_CODE               ret = RET_SUCCEED;
    DdlGenProcessLogger    ddlGenProcessLogger(*this, ret, "Creation of the indexes");
    bool                   bAppendFile = true;
    DBA_DYNFLD_STP         xdEntityStp = this->getXdEntityStp();

    if (this->ddlGenContextPtr->bGenFromDbi)
    {
        if (this->bIdxToDo == false)
        {
            this->bIdxToDo = true;
        }

        this->ddlGenContextPtr->bSimulation = true;
        this->ddlGenContextPtr->bForceReBuild = true;
        bAppendFile = false;
    }

    if (GET_ENUM(xdEntityStp, A_XdEntity_NatEn) == EntityNat_ReportFmt)
    {
        bAppendFile = false;
    }

    if (!this->bIdxToDo)
    {
        return ret;
    }
    DdlGenFile  localFileHeper(*this->ddlGenContextPtr, this->objectEn, DdlObj_Index, bAppendFile, this->ddlGenContextPtr->bCheck);

    ddlGenProcessLogger.start();

    auto tempTableSpec = DdlGenDbi::getTempTableSpec(this->ddlGenContextPtr->m_rdbmsEn, this->m_dictEntityStp);
    if ((this->m_dictEntityStp = DBA_GetDictEntitySt(this->objectEn)) == NULL ||
        /* PMSTA-58084 - LJE - 240729 */
        tempTableSpec == DdlGenDbi::TempTableSpec::MemoryOptimzed ||
        tempTableSpec == DdlGenDbi::TempTableSpec::Type ||
        this->initConnection(&localFileHeper, false) != RET_SUCCEED)
    {
        return RET_DBA_INFO_NODATA;
    }
    try
    {
        if (this->m_dictEntityStp->xdStatusEn == XdStatus_Inserted)
        {
            if (RET_GET_LEVEL(ret) != RET_LEV_ERROR && this->bIdxToDo)
            {
                DdlGenIndex* genDdl = new DdlGenIndex(this->objectEn, idxSqlNameOnly, *this->ddlGenContextPtr, this->ddlGenEntityPtr, &localFileHeper, TargetTable_Main);

                if ((ret = genDdl->lastErrRetCode) == RET_SUCCEED)
                {
                    ret = genDdl->build();
                }
                delete genDdl;
            }
        }
    }
    catch (exception& e)
    {
        ret = RET_GEN_ERR_PERSONAL;
        this->printCatchMsg(FILEINFO, e.what());
    }

    this->finishConnection(ret);

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenFullTable::buildPrimaryKeyInDB()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-33263 - LJE - 181212
**
*************************************************************************/
RET_CODE DdlGenFullTable::buildPrimaryKeyInDB()
{
    RET_CODE               ret = RET_SUCCEED;
    DdlGenProcessLogger    ddlGenProcessLogger(*this, ret, "Creation of the primary key");

    if (this->bTableToDo || this->bUdTableToDo || this->bExtTableToDo)
    {
        DdlGenFile localFileHeper(*this->ddlGenContextPtr, this->objectEn, DdlObj_Constraint, true, this->ddlGenContextPtr->bCheck);

        if (this->initConnection(&localFileHeper, false) != RET_SUCCEED)
        {
            return RET_DBA_INFO_NODATA;
        }

        ddlGenProcessLogger.start();
        try
        {
            if (this->bTableToDo)
            {
                DdlGenFK ddlGenFK(this->objectEn, *this->ddlGenContextPtr, this->ddlGenEntityPtr, &localFileHeper, TargetTable_Main);
                ret = ddlGenFK.createPk();
            }
            /* PMSTA-35945 - LJE - 190516 */
            if (this->bUdTableToDo)
            {
                DdlGenFK ddlGenFK(this->objectEn, *this->ddlGenContextPtr, this->ddlGenEntityPtr, &localFileHeper, TargetTable_UserDefinedFields);
                ret = ddlGenFK.createPk();
            }

            /* PMSTA-37366 - LJE - 200205 */
            if (this->bExtTableToDo)
            {
                DdlGenFK ddlGenFK(this->objectEn, *this->ddlGenContextPtr, this->ddlGenEntityPtr, &localFileHeper, TargetTable_Precomp);
                ret = ddlGenFK.createPk();
            }
        }
        catch (exception& e)
        {
            ret = RET_GEN_ERR_PERSONAL;
            this->printCatchMsg(FILEINFO, e.what());
        }

        this->finishConnection(ret);
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenFullTable::manageMigration()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-32145 - LJE - 180730
**
*************************************************************************/
RET_CODE DdlGenFullTable::manageMigration(DdlGenFullTable::MigrationStep migrationStep)
{
    RET_CODE               ret = RET_SUCCEED;

    if (this->ddlGenEntityPtr->newXdAttribMapMap.empty() == false)
    {
        DdlGenProcessLogger    ddlGenProcessLogger(*this, ret, (string("Migration management") + (migrationStep == DdlGenFullTable::MigrationStep::UserDefinedFields ? " (ud_id)" : " (Multi-Entity)")).c_str());
        int                    attribUpgCtp = 0;
        int                    attribSkipCtp = 0;
        int                    attribErrCtp = 0;

        if ((this->m_dictEntityStp = DBA_GetDictEntitySt(this->objectEn)) == NULL)
        {
            return RET_DBA_INFO_NODATA;
        }

        DdlGenFile localFileHeper(*this->ddlGenContextPtr, this->objectEn, DdlObj_Migration, true, this->ddlGenContextPtr->bCheck);

        if (this->initConnection(&localFileHeper, false) != RET_SUCCEED)
        {
            return RET_DBA_INFO_NODATA;
        }

        ddlGenProcessLogger.start();

        try
        {
            if ((migrationStep == DdlGenFullTable::MigrationStep::MultiEntityFirst || migrationStep == DdlGenFullTable::MigrationStep::MultiEntitySecond) &&
                this->m_dictEntityStp->multiEntityCateg.isOwnerBusinessEntity() == true &&
                this->ddlGenContextPtr->isEntityMtmFirstLevel(this->m_dictEntityStp->entDictId) == false &&
                this->m_dictEntityStp->logicalFlg == 0 &&
                (this->m_dictEntityStp->dbRuleEn == DbRule_Standard || this->m_dictEntityStp->dbRuleEn == DbRule_OnlyMainTable) &&
                this->m_dictEntityStp->ownerBusinessEntAttrStp != nullptr)
            {
                auto newXdAttribMap = this->ddlGenEntityPtr->newXdAttribMapMap[TargetTable_Main];
                for (auto it = newXdAttribMap.begin(); it != newXdAttribMap.end(); ++it)
                {
                    std::vector<DICT_ATTRIB_STP>   restrictAttribVector;

                    if (GET_A_XdAttrib_FeatureEn(it->second) == XdEntityFeatureFeatureEn::MultiBusinessEntityManagement &&
                        GET_FLAG(it->second, A_XdAttrib_TreatedFlg) == FALSE)
                    {
                        if (this->m_migrateAttribVector.empty())
                        {
                            for (auto refEntIt = this->m_dictEntityStp->dictEntityRefMap.begin(); refEntIt != this->m_dictEntityStp->dictEntityRefMap.end(); ++refEntIt)
                            {
                                if (refEntIt->first->logicalFlg == FALSE &&
                                    refEntIt->first->featureEn != XdEntityFeatureFeatureEn::MultiBusinessEntityManagement &&
                                    (refEntIt->first->dataTpProgN == IdType || refEntIt->first->dataTpProgN == DictType) &&
                                    refEntIt->second != nullptr)
                                {
                                    if (refEntIt->second->multiEntityCateg.isMultiEntityCateg())
                                    {
                                        if (refEntIt->first->dbMandatoryFlg &&
                                            refEntIt->second->multiEntityCateg.isBusinessEntityIsolated())
                                        {
                                            restrictAttribVector.push_back(refEntIt->first);
                                        }

                                        if (refEntIt->second->multiEntityCateg.isBusinessEntityIsolated() ||
                                            refEntIt->second->multiEntityCateg.isOptionalLocalization())
                                        {
                                            this->m_migrateAttribVector.push_back(refEntIt->first);
                                        }
                                    }
                                    else if (refEntIt->second->objectEn == DictEntity &&
                                             refEntIt->first->linkAttrDictTab.empty() == false)
                                    {
                                        std::set<ID_T> existingEntities;
                                        DICT_ATTRIB_STP lnkRefAttr = nullptr;

                                        for (size_t i = 0; i < refEntIt->first->linkAttrDictTab.size(); ++i)
                                        {
                                            if (refEntIt->first->linkAttrDictTab[i]->permValMap.empty() == false)
                                            {
                                                for (auto permIt = refEntIt->first->linkAttrDictTab[i]->permValMap.begin(); permIt != refEntIt->first->linkAttrDictTab[i]->permValMap.end(); ++permIt)
                                                {
                                                    if (permIt->second.refEntityDictId != 0)
                                                    {
                                                        existingEntities.insert(permIt->second.refEntityDictId);
                                                    }
                                                }
                                            }
                                            else
                                            {
                                                lnkRefAttr = refEntIt->first->linkAttrDictTab[i];

                                                if ((lnkRefAttr->dataTpProgN == IdType || lnkRefAttr->dataTpProgN == DictType) &&
                                                    lnkRefAttr->linkAttrDictTab.size() > 0)
                                                {
                                                    for (size_t j = 0; j < lnkRefAttr->linkAttrDictTab.size(); ++j)
                                                    {
                                                        existingEntities.insert(lnkRefAttr->linkAttrDictTab[j]->dictEntityStp->entDictId);
                                                    }
                                                }
                                            }
                                        }

                                        if (lnkRefAttr != nullptr)
                                        {
                                            if (existingEntities.empty())
                                            {
                                                DdlGenDbi localDdlGenDbi(DdlObj_Sql, *this->ddlGenContextPtr, nullptr, nullptr, TargetTable_Main);

                                                stringstream request;

                                                request
                                                    << "select distinct " << refEntIt->first->sqlName
                                                    << " from " << localDdlGenDbi.getTableFullDbName(refEntIt->first->dictEntityStp->databaseName, string(), refEntIt->first->dictEntityStp->dbSqlName);

                                                localDdlGenDbi.getIdFromRequest(request.str(), existingEntities, true);
                                            }

                                            for (auto entIt = existingEntities.begin(); entIt != existingEntities.end(); ++entIt)
                                            {
                                                auto lnkRefEnt = DBA_GetDictEntityByDictId(*entIt);

                                                if (lnkRefEnt != nullptr &&
                                                    lnkRefEnt->logicalFlg == 0 &&
                                                    (lnkRefEnt->dbRuleEn == DbRule_Standard || lnkRefEnt->dbRuleEn == DbRule_OnlyMainTable) &&
                                                    lnkRefEnt->multiEntityCateg.isMultiEntityCateg())
                                                {
                                                    if (lnkRefEnt->multiEntityCateg.isBusinessEntityIsolated() ||
                                                        lnkRefEnt->multiEntityCateg.isOptionalLocalization())
                                                    {
                                                        DICT_ATTRIB_STP migAttrStp = new DICT_ATTRIB_ST();
                                                        *migAttrStp = *lnkRefAttr;
                                                        migAttrStp->refDictEntityStp = lnkRefEnt;
                                                        migAttrStp->refEntDictId = lnkRefEnt->entDictId;
                                                        migAttrStp->linkedAttrDictStp = refEntIt->first;
                                                        migAttrStp->linkedAttrDictId = refEntIt->first->attrDictId;

                                                        this->m_migrateAttribVector.push_back(migAttrStp);
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            if (restrictAttribVector.empty() == false)
                            {
                                this->m_migrateAttribVector = restrictAttribVector;
                            }

                            for (auto migrateAttribIt = this->m_migrateAttribVector.begin(); migrateAttribIt != this->m_migrateAttribVector.end(); ++migrateAttribIt)
                            {
                                (*migrateAttribIt)->xdStatusEn = XdStatus_Untreated;
                            }
                        }

                        for (auto migrateAttribIt = this->m_migrateAttribVector.begin(); migrateAttribIt != this->m_migrateAttribVector.end(); ++migrateAttribIt)
                        {
                            if ((*migrateAttribIt)->xdStatusEn != XdStatus_Untreated)
                            {
                                continue;
                            }

                            DICT_ATTRIB_STP refAttribStp = (*migrateAttribIt);;
                            DICT_ENTITY_STP refDictEntityStp = refAttribStp->refDictEntityStp;

                            if (refAttribStp == nullptr ||
                                refDictEntityStp->logicalFlg == 1 ||
                                (refDictEntityStp->dbRuleEn != DbRule_Standard && refDictEntityStp->dbRuleEn != DbRule_OnlyMainTable))
                            {
                                continue;
                            }

                            DdlGenEntity* refDdlGenEntityPtr = this->ddlGenContextPtr->getDdlGenEntityPtr(refDictEntityStp->mdSqlName, string(), false);
                            bool            bOwnerBeIsNew = false;

                            if (refDdlGenEntityPtr && migrationStep == DdlGenFullTable::MigrationStep::MultiEntityFirst)
                            {
                                auto refOwnerBeIt = refDdlGenEntityPtr->newXdAttribMapMap[TargetTable_Main].find(this->m_dictEntityStp->ownerBusinessEntAttrStp->sqlName);
                                if (refOwnerBeIt != refDdlGenEntityPtr->newXdAttribMapMap[TargetTable_Main].end() &&
                                    GET_FLAG(refOwnerBeIt->second, A_XdAttrib_TreatedFlg) == FALSE)
                                {
                                    bOwnerBeIsNew = true;
                                }
                            }

                            if (bOwnerBeIsNew == false)
                            {
                                stringstream migrationStream;
                                DdlGen       migDdlGen(this->getObjectEn(),
                                                       DdlObj_Migration,
                                                       *this->ddlGenContextPtr,
                                                       nullptr,
                                                       this->ddlGenEntityPtr,
                                                       &localFileHeper,
                                                       TargetTable_Main);
                                this->ddlGenContextPtr->bUserId = false;

                                migrationStream
                                    << endl << "#NO_MULTI_ENTITY"
                                    << endl << "#UPDATE " << this->m_dictEntityStp->mdSqlName << " null E"
                                    << endl << "E." << this->m_dictEntityStp->ownerBusinessEntAttrStp->sqlName << " = ref." << refDictEntityStp->ownerBusinessEntAttrStp->sqlName
                                    << endl << "#FROM";

                                string mainAlias = "E.";
                                if (refAttribStp->custFlg == TRUE)
                                {
                                    if (this->m_dictEntityStp->primKeyNbr == 1) /* PRO-12323 - LJE - 191031 */
                                    {
                                        mainAlias = "ud.";
                                        migrationStream
                                            << endl << "inner join " << this->m_dictEntityStp->custSqlName << " ud on E." << this->m_dictEntityStp->primKeyTab[0]->sqlName << " = ud.ud_id"; /* PRO-12323 - LJE - 191031 */
                                    }
                                    else
                                    {
                                        ret = RET_GEN_ERR_INVARG;
                                        this->printMsg(ret, "Unsupported upgrade, entity must have primary key");
                                    }
                                }

                                migrationStream
                                    << endl << "inner join " << refDictEntityStp->mdSqlName << " ref on ";

                                DICT_ATTRIB_STP* uniqueKeyTab = refDictEntityStp->dbPKTab ? refDictEntityStp->dbPKTab : refDictEntityStp->dbBKTab;
                                int              uniqueKeyNbr = refDictEntityStp->dbPKNbr ? refDictEntityStp->dbPKNbr : refDictEntityStp->dbBKNbr;

                                if (uniqueKeyNbr == 1)
                                {
                                    migrationStream
                                        << mainAlias << refAttribStp->sqlName << " = ref." << uniqueKeyTab[0]->sqlName;
                                }
                                else if (uniqueKeyNbr > 1)
                                {
                                    DICT_ATTRIB_STP* logUniqueKeyTab = refDictEntityStp->primKeyTab ? refDictEntityStp->primKeyTab : refDictEntityStp->bkAttr;
                                    int              logUniqueKeyNbr = refDictEntityStp->primKeyNbr ? refDictEntityStp->primKeyNbr : refDictEntityStp->bkAttrNbr;

                                    for (int i = 0; i < logUniqueKeyNbr; i++)
                                    {
                                        if (i == 0)
                                        {
                                            migrationStream
                                                << mainAlias << refAttribStp->sqlName << " = ref." << logUniqueKeyTab[i]->sqlName;
                                        }
                                        else
                                        {
                                            migrationStream
                                                << " and " << mainAlias << logUniqueKeyTab[i]->sqlName << " = ref." << logUniqueKeyTab[i]->sqlName;
                                        }
                                    }

                                    for (int i = 0; i < uniqueKeyNbr; i++)
                                    {
                                        int j = 0;
                                        for (; j < logUniqueKeyNbr; j++)
                                        {
                                            if (strcmp(logUniqueKeyTab[j]->sqlName, uniqueKeyTab[i]->sqlName) == 0)
                                            {
                                                break;
                                            }
                                        }
                                        if (j == logUniqueKeyNbr)
                                        {
                                            if (this->m_dictEntityStp->sortedAttr.find(uniqueKeyTab[i]->sqlName) != this->m_dictEntityStp->sortedAttr.end())
                                            {
                                                migrationStream
                                                    << " and " << mainAlias << uniqueKeyTab[i]->sqlName << " = ref." << uniqueKeyTab[i]->sqlName;
                                            }
                                            else
                                            {
                                                (*migrateAttribIt)->xdStatusEn = XdStatus_Inserted;

                                                attribUpgCtp++;
                                                this->ddlGenContextPtr->upgDoneCpt++;

                                                ret = RET_DBA_INFO_NODATA;
                                            }
                                        }
                                    }
                                }
                                else
                                {
                                    ret = RET_GEN_ERR_INVARG;
                                    this->printMsg(ret, "Unsupported upgrade, entity must have primary key");
                                }

                                if (refAttribStp->linkedAttrDictStp)
                                {
                                    if (refAttribStp->linkedAttrDictStp->refEntDictId == migDdlGen.scriptDdlGen->dictEntityDictId)
                                    {
                                        migrationStream
                                            << " and " << mainAlias << refAttribStp->linkedAttrDictStp->sqlName << " = " << refDictEntityStp->entDictId;
                                    }
                                    else if (refAttribStp->linkedAttrDictStp->linkedAttrDictStp &&
                                             refAttribStp->linkedAttrDictStp->linkedAttrDictStp->refEntDictId == migDdlGen.scriptDdlGen->dictEntityDictId)
                                    {
                                        migrationStream
                                            << " and " << mainAlias << refAttribStp->linkedAttrDictStp->linkedAttrDictStp->sqlName << " = " << refDictEntityStp->entDictId;
                                    }
                                    else
                                    {
                                        ret = RET_GEN_ERR_INVARG;
                                        this->printMsg(ret, "Unsupported upgrade, linked attribute is not linked on dict_entity");
                                    }
                                }
                                else
                                {
                                    for (auto pkIdx = 1; pkIdx < refDictEntityStp->dbPKNbr; pkIdx++)
                                    {
                                        migrationStream
                                            << " and " << mainAlias << refDictEntityStp->dbPKTab[pkIdx]->sqlName << " = ref." << refDictEntityStp->dbPKTab[pkIdx]->sqlName;
                                    }
                                }

                                migrationStream
                                    << " and ref." << refDictEntityStp->ownerBusinessEntAttrStp->sqlName << " <> " << this->ddlGenContextPtr->getMasterBusinessEntityId();

                                migrationStream
                                    << endl << "#WHERE"
                                    << endl << "E." << this->m_dictEntityStp->ownerBusinessEntAttrStp->sqlName << " = " << this->ddlGenContextPtr->getMasterBusinessEntityId()
                                    << endl << "#END";

                                if (ret == RET_SUCCEED)
                                {
                                    migDdlGen.bodySqlBlock << migDdlGen.scriptDdlGen->buildScript(migrationStream.str(), DdlObj_Sql);

                                    if (RET_GET_LEVEL(migDdlGen.lastErrRetCode) != RET_LEV_ERROR)
                                    {
                                        if (this->m_bTriggersDeleted == false)
                                        {
                                            DdlGenContext ddlGenContext(this->ddlGenContextPtr->m_rdbmsEn, true);
                                            DdlGenTrigger ddlGenTrigger(this->objectEn, DdlObj_Trigger, ddlGenContext, nullptr, this->ddlGenEntityPtr, &localFileHeper, TargetTable_Main);
                                            ddlGenTrigger.init(DmlEvent_All, EventPos_All, TriggerPos_None);
                                            ddlGenTrigger.build();

                                            this->m_bTriggersDeleted = true;
                                        }

                                        stringstream msg;
                                        msg << "Upgrade attribute " << this->m_dictEntityStp->ownerBusinessEntAttrStp->sqlName << " from entity " << refDictEntityStp->mdSqlName << " (link: " << refAttribStp->sqlName << ")";
                                        this->printMsg(RET_DBA_INFO_EXIST, msg.str());

                                        (*migrateAttribIt)->xdStatusEn = XdStatus_Failed;
                                        ret = migDdlGen.flush();

                                        if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
                                        {
                                            (*migrateAttribIt)->xdStatusEn = XdStatus_Inserted;

                                            attribUpgCtp++;
                                            this->ddlGenContextPtr->upgDoneCpt++;

                                            if (restrictAttribVector.empty() == false)
                                            {
                                                for (auto restrictAttribIt = this->m_migrateAttribVector.begin(); restrictAttribIt != this->m_migrateAttribVector.end(); ++restrictAttribIt)
                                                {
                                                    (*restrictAttribIt)->xdStatusEn = XdStatus_Inserted;
                                                }
                                            }
                                        }
                                        else
                                        {
                                            attribErrCtp++;
                                        }
                                    }
                                    else
                                    {
                                        ret = migDdlGen.lastErrRetCode;
                                        attribErrCtp++;
                                    }
                                }
                                else if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
                                {
                                    attribErrCtp++;
                                }
                            }
                            else
                            {
                                (*migrateAttribIt)->xdStatusEn = XdStatus_Untreated;

                                this->ddlGenContextPtr->upgToDoCpt++;
                                attribSkipCtp++;
                            }
                        }

                        if (attribSkipCtp == 0)
                        {
                            SET_FLAG_TRUE(it->second, A_XdAttrib_TreatedFlg);
                        }

                        break;
                    }
                }
            }
            else if (migrationStep == DdlGenFullTable::MigrationStep::UserDefinedFields &&
                     this->m_dictEntityStp->custAuthFlg == TRUE &&
                     (this->m_dictEntityStp->dbRuleEn == DbRule_Standard || this->m_dictEntityStp->dbRuleEn == DbRule_NotMainTable) &&
                     this->m_dictEntityStp->multiEntityCateg.isOwnerBusinessEntity() == true &&
                     this->m_dictEntityStp->udOwnerBusinessEntAttrStp != nullptr)
            {
                auto newXdAttribMap = this->ddlGenEntityPtr->newXdAttribMapMap[TargetTable_UserDefinedFields];
                for (auto it = newXdAttribMap.begin(); it != newXdAttribMap.end(); ++it)
                {
                    if (GET_A_XdAttrib_FeatureEn(it->second) == XdEntityFeatureFeatureEn::MultiBusinessEntityManagement &&
                        GET_FLAG(it->second, A_XdAttrib_TreatedFlg) == FALSE)
                    {
                        SET_FLAG_TRUE(it->second, A_XdAttrib_TreatedFlg);

                        DdlGen migDdlGen(this->getObjectEn(),
                                         DdlObj_Migration,
                                         *this->ddlGenContextPtr,
                                         nullptr,
                                         this->ddlGenEntityPtr,
                                         &localFileHeper,
                                         TargetTable_Main);

                        this->ddlGenContextPtr->bUserId = false;

                        if (this->m_dictEntityStp->dbRuleEn == DbRule_NotMainTable)
                        {
                            for (auto it2 = this->m_dictEntityStp->linkEntitiesMap.begin(); it2 != this->m_dictEntityStp->linkEntitiesMap.end(); ++it2)
                            {
                                if (it2->second->dbRuleEn == DbRule_Standard || it2->second->dbRuleEn == DbRule_OnlyMainTable)
                                {
                                    if (this->m_dictEntityStp->primKeyNbr == 1) /* PRO-12323 - LJE - 191031 */
                                    {
                                        stringstream migrationStream;

                                        migrationStream
                                            << endl << "#NO_MULTI_ENTITY"
                                            << endl << "#UPDATE " << this->m_dictEntityStp->custSqlName << " null ud"
                                            << endl << "ud." << this->m_dictEntityStp->udOwnerBusinessEntAttrStp->sqlName << " = E." << this->m_dictEntityStp->ownerBusinessEntAttrStp->sqlName
                                            << endl << "#FROM"
                                            << endl << "inner join " << it2->second->mdSqlName << " E on E." << this->m_dictEntityStp->primKeyTab[0]->sqlName << " = ud.ud_id"    /* PRO-12323 - LJE - 191031 */
                                            << endl << "#WHERE"
                                            << endl << "E." << this->m_dictEntityStp->ownerBusinessEntAttrStp->sqlName << " <> " << this->ddlGenContextPtr->getMasterBusinessEntityId()
                                            << endl << "#END";

                                        migDdlGen.bodySqlBlock << migDdlGen.scriptDdlGen->buildScript(migrationStream.str(), DdlObj_Sql);

                                        if (RET_GET_LEVEL(migDdlGen.lastErrRetCode) != RET_LEV_ERROR)
                                        {
                                            DdlGenContext ddlGenContext(this->ddlGenContextPtr->m_rdbmsEn, true);
                                            DdlGenTrigger ddlGenTrigger(this->objectEn, DdlObj_Trigger, ddlGenContext, nullptr, this->ddlGenEntityPtr, &localFileHeper, TargetTable_UserDefinedFields);
                                            ddlGenTrigger.init(DmlEvent_All, EventPos_All, TriggerPos_None);
                                            ddlGenTrigger.build();

                                            ret = migDdlGen.flush();
                                        }
                                        else
                                        {
                                            ret = migDdlGen.lastErrRetCode;
                                        }
                                    }
                                    else
                                    {
                                        ret = RET_GEN_ERR_INVARG;
                                        this->printMsg(ret, "Unsupported upgrade, entity must have primary key");
                                    }
                                }
                            }
                        }
                        else
                        {
                            if (this->m_dictEntityStp->primKeyNbr == 1) /* PRO-12323 - LJE - 191031 */
                            {
                                stringstream migrationStream;

                                migrationStream
                                    << endl << "#NO_MULTI_ENTITY"
                                    << endl << "#UPDATE " << this->m_dictEntityStp->custSqlName << " null ud"
                                    << endl << "ud." << this->m_dictEntityStp->udOwnerBusinessEntAttrStp->sqlName << " = E." << this->m_dictEntityStp->ownerBusinessEntAttrStp->sqlName
                                    << endl << "#FROM"
                                    << endl << "inner join " << this->m_dictEntityStp->mdSqlName << " E on E." << this->m_dictEntityStp->primKeyTab[0]->sqlName << " = ud.ud_id" /* PRO-12323 - LJE - 191031 */
                                    << endl << "#WHERE"
                                    << endl << "E." << this->m_dictEntityStp->ownerBusinessEntAttrStp->sqlName << " <> " << this->ddlGenContextPtr->getMasterBusinessEntityId()
                                    << endl << "#END";

                                migDdlGen.bodySqlBlock << migDdlGen.scriptDdlGen->buildScript(migrationStream.str(), DdlObj_Sql);

                                if (RET_GET_LEVEL(migDdlGen.lastErrRetCode) != RET_LEV_ERROR)
                                {
                                    DdlGenContext ddlGenContext(this->ddlGenContextPtr->m_rdbmsEn, true);
                                    DdlGenTrigger ddlGenTrigger(this->objectEn, DdlObj_Trigger, ddlGenContext, nullptr, this->ddlGenEntityPtr, &localFileHeper, TargetTable_UserDefinedFields);
                                    ddlGenTrigger.init(DmlEvent_All, EventPos_All, TriggerPos_None);
                                    ddlGenTrigger.build();

                                    ret = migDdlGen.flush();

                                    if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
                                    {
                                        attribUpgCtp++;
                                        this->ddlGenContextPtr->upgDoneCpt++;
                                    }
                                    else
                                    {
                                        attribErrCtp++;
                                    }
                                }
                                else
                                {
                                    ret = migDdlGen.lastErrRetCode;
                                    attribErrCtp++;
                                }
                            }
                            else
                            {
                                ret = RET_GEN_ERR_INVARG;
                                attribErrCtp++;
                                this->printMsg(ret, "Unsupported upgrade, entity must have primary key");
                            }
                        }
                        break;
                    }
                }
            }
        }
        catch (exception& e)
        {
            ret = RET_GEN_ERR_PERSONAL;
            this->printCatchMsg(FILEINFO, e.what());
        }

        this->finishConnection(ret);
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenFullTable::buildForeignKeysInDB()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13122 - LJE - 120413
**
*************************************************************************/
RET_CODE DdlGenFullTable::buildForeignKeysInDB()
{
    RET_CODE               ret = RET_SUCCEED;
    DdlGenProcessLogger    ddlGenProcessLogger(*this, ret, "Creation of the foreign keys");

    if (this->ddlGenDbi.isFkApplied())
    {
        if ((this->m_dictEntityStp = DBA_GetDictEntitySt(this->objectEn)) == NULL)
        {
            return RET_DBA_INFO_NODATA;
        }

        if (RET_GET_LEVEL(ret) != RET_LEV_ERROR && DdlGenFK::isFKOnEntity(this->m_dictEntityStp) && this->getDdlGenAction().m_installLevel < 9)
        {
            DdlGenFile localFileHeper(*this->ddlGenContextPtr, this->objectEn, DdlObj_ForeignKey, true, this->ddlGenContextPtr->bCheck);

            if (this->initConnection(&localFileHeper, false) != RET_SUCCEED)
            {
                return RET_DBA_INFO_NODATA;
            }

            ddlGenProcessLogger.start();

            try
            {
                DdlGenFK* genDdlFk = new DdlGenFK(this->objectEn, *this->ddlGenContextPtr, this->ddlGenEntityPtr, &localFileHeper, TargetTable_Main);
                ret = genDdlFk->build();

                if (this->bPkChanged && getDdlGenAction().m_entitySqlnameStr.empty() == false)
                {
                    genDdlFk->createByRefEntity();
                }
                delete genDdlFk;
            }
            catch (exception e)
            {
                ret = RET_GEN_ERR_PERSONAL;
                this->printCatchMsg(FILEINFO, e.what());
            }

            this->finishConnection(ret);
        }
        else
        {
            return ret;
        }
    }
    return ret;
}

/************************************************************************
**
**  Function    :   buildSpecialSProcsInDB()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-16729 - LJE - 110311
**  Last modif. :
**
*************************************************************************/
RET_CODE DdlGenFullTable::buildSpecialSProcsInDB()
{
    RET_CODE         ret = RET_SUCCEED;
    DdlGenProcessLogger    ddlGenProcessLogger(*this, ret, "Creation of the specials stored procedures");

    /* PMSTA-20644 - DDV - 151012 - Suppress error message */
    if ((this->m_dictEntityStp = DBA_GetDictEntitySt(this->objectEn)) != NULL &&
        strcmp(this->m_dictEntityStp->mdSqlName, "dict_entity") == 0)
    {
        DdlGenFile       localFileHeper(*this->ddlGenContextPtr, this->objectEn, DdlObj_SpecSProc, false, this->ddlGenContextPtr->bCheck);

        if (this->initConnection(&localFileHeper, false) != RET_SUCCEED)
        {
            return RET_DBA_INFO_NODATA;
        }

        this->setDdlObjEn(DdlObj_SProc);
        this->setMsgEntitySqlName(this->m_dictEntityStp->mdSqlName);
        this->setMsgSqlName(string());
        ddlGenProcessLogger.start();

        DictSprocClass& dictSprocSt = this->ddlGenContextPtr->getDictSprocSt();

        {
            dictSprocSt.reset();
            dictSprocSt.setObjectEn(this->getObjectEn());
            dictSprocSt.sqlName = "chk_dict_entity_object_id";
            dictSprocSt.dbName = this->ddlGenContextPtr->getMainDbName();
            dictSprocSt.setObjectEn(DictEntity);
            dictSprocSt.procAccessEn = ProcAccess_CustomKey;
            dictSprocSt.procActionEn = Special;

            DdlGenSProc ddlGenSProc(dictSprocSt.getObjectEn(), *this->ddlGenContextPtr, NULL, this->ddlGenEntityPtr, &localFileHeper, TargetTable_Main);
            ret = ddlGenSProc.build();
        }

        {
            dictSprocSt.reset();
            dictSprocSt.setObjectEn(this->getObjectEn());
            dictSprocSt.sqlName = "chk_dict_entity_object_for_upd";
            dictSprocSt.dbName = this->ddlGenContextPtr->getMainDbName();
            dictSprocSt.setObjectEn(DictEntity);
            dictSprocSt.procAccessEn = ProcAccess_CustomKey;
            dictSprocSt.procActionEn = Special;

            DdlGenSProc ddlGenSProc(dictSprocSt.getObjectEn(), *this->ddlGenContextPtr, NULL, this->ddlGenEntityPtr, &localFileHeper, TargetTable_Main);
            ret = ddlGenSProc.build();
        }

        {
            dictSprocSt.reset();
            dictSprocSt.setObjectEn(this->getObjectEn());
            dictSprocSt.sqlName = "get_dict_entity_object_id";
            dictSprocSt.dbName = this->ddlGenContextPtr->getMainDbName();
            dictSprocSt.setObjectEn(DictEntity);
            dictSprocSt.procAccessEn = ProcAccess_CustomKey;
            dictSprocSt.procActionEn = Special;

            DdlGenSProc ddlGenSProc(dictSprocSt.getObjectEn(), *this->ddlGenContextPtr, NULL, this->ddlGenEntityPtr, &localFileHeper, TargetTable_Main);
            ret = ddlGenSProc.build();
        }

        this->finishConnection(ret);
    }
    else if (this->m_dictEntityStp != nullptr)
    {
        if ((this->m_dictEntityStp->changeSetAuthEn == FeatureAuth_Enable && this->m_dictEntityStp->entNatEn != EntityNat_DerivedEntity) ||
            (this->m_dictEntityStp->entNatEn == EntityNat_TempTable &&
             DdlGenDbi::getTempTableSpec(this->ddlGenContextPtr->m_rdbmsEn, this->m_dictEntityStp) != DdlGenDbi::TempTableSpec::Type))
        {
            string           procSqlName;

            DdlGenFile        localFileHeper(*this->ddlGenContextPtr, this->objectEn, DdlObj_SpecSProc, false, this->ddlGenContextPtr->bCheck);
            DictSprocClass& dictSprocSt = this->ddlGenContextPtr->getDictSprocSt();
            DdlGenSProc       ddlGenSProc(dictSprocSt.getObjectEn(), *this->ddlGenContextPtr, NULL, this->ddlGenEntityPtr, &localFileHeper, TargetTable_Main);
            DdlGenFromFile    genDdlFromFile(DdlObjFromFile_SProc, this->objectEn, *this->ddlGenContextPtr, this->ddlGenEntityPtr, &ddlGenSProc, false, nullptr, &localFileHeper);

            if (this->initConnection(&localFileHeper, false) != RET_SUCCEED)
            {
                return RET_DBA_INFO_NODATA;
            }

            genDdlFromFile.setDdlObjEn(DdlObj_SProc);
            genDdlFromFile.setMsgEntitySqlName(this->m_dictEntityStp->mdSqlName);
            genDdlFromFile.setMsgSqlName(string());

            CFG_TEMPLATE_ENUM  cfgTemplateEn = this->m_dictEntityStp->entNatEn == EntityNat_TempTable ? CfgTemplate_TempTable : CfgTemplate_ChangeSet;
            auto& cfgTemplateMap = this->ddlGenContextPtr->getTemplateFileHelper().m_cfgTemplateMap;

            for (auto it = cfgTemplateMap.begin(); it != cfgTemplateMap.end(); it++)
            {
                if (it->first.getFeature() == cfgTemplateEn &&
                    it->first.getDdlObjEn() == DdlObj_SProc)
                {
                    dictSprocSt.reset();
                    dictSprocSt.setObjectEn(this->getObjectEn());
                    ddlGenSProc.init(false);

                    procSqlName = genDdlFromFile.buildScript(it->second->nameStr);
                    trim(procSqlName);
                    dictSprocSt.sqlName = procSqlName;
                    dictSprocSt.procActionEn = it->second->procActionEn;

                    stringstream sprocBody;

                    sprocBody
                        << "#SPROC_BEGIN " << procSqlName << endl
                        << it->second->paramStr << endl
                        << "#END" << endl
                        << it->second->bodyStr << endl
                        << "#SPROC_END " << procSqlName;

                    string lineStr;

                    while (getline(sprocBody, lineStr))
                    {
                        genDdlFromFile.context->currBlockVector.push_back(lineStr);
                    }

                    this->ddlGenContextPtr->resetContext(procSqlName);
                    ret = genDdlFromFile.buildBlock(DdlObj_SProc);
                }
            }

            this->finishConnection(ret);
        }
        else
        {
            ret = RET_GEN_INFO_NOACTION;
        }
    }
    else
    {
        ret = RET_GEN_INFO_NOACTION;
    }

    if (ret != RET_GEN_INFO_NOACTION)
    {
        if (this->ddlGenContextPtr->m_parentContext != this->ddlGenContextPtr)
        {
            this->ddlGenContextPtr->writeLock();
            for (auto &it : this->ddlGenContextPtr->m_validDdlObjMap)
            {
                this->ddlGenContextPtr->m_parentContext->m_invalidDdlObjMap.erase(it.first);
                this->ddlGenContextPtr->m_parentContext->m_validDdlObjMap.erase(it.first);
                this->ddlGenContextPtr->m_parentContext->m_validDdlObjMap.insert(std::make_pair(it.first, it.second));
            }
            for (auto &it : this->ddlGenContextPtr->m_invalidDdlObjMap)
            {
                this->ddlGenContextPtr->m_parentContext->m_invalidDdlObjMap.erase(it.first);
                this->ddlGenContextPtr->m_parentContext->m_invalidDdlObjMap.insert(std::make_pair(it.first, it.second));
            }
            this->ddlGenContextPtr->writeUnlock();
        }
    }
    else
    {
        ret = RET_SUCCEED;
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenFullTable::buildSysViewsInDB()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-26108 - LJE - 170906
**
*************************************************************************/
RET_CODE DdlGenFullTable::buildSysViewsInDB()
{
    RET_CODE               ret = RET_SUCCEED;
    DdlGenProcessLogger    ddlGenProcessLogger(*this, ret, "Creation of the system views");

    if ((this->m_dictEntityStp = DBA_GetDictEntitySt(this->objectEn)) == nullptr)
    {
        return RET_DBA_INFO_NODATA;
    }

    ddlGenProcessLogger.start();

    bool             bAppend = (this->ddlGenContextPtr->m_fileOpenSet.find(DdlObj_View) != this->ddlGenContextPtr->m_fileOpenSet.end());
    DdlGenFile       localFileHeper(*this->ddlGenContextPtr, this->objectEn, DdlObj_View, bAppend, this->ddlGenContextPtr->bCheck);

    if (this->initConnection(&localFileHeper, false) != RET_SUCCEED)
    {
        return RET_DBA_INFO_NODATA;
    }

    try
    {
        DdlGenFromFilePtr genDdlFromFile(new DdlGenFromFile(DdlObjFromFile_SystemView,
                                                            this->objectEn,
                                                            *this->ddlGenContextPtr,
                                                            this->ddlGenEntityPtr,
                                                            nullptr,
                                                            false,
                                                            nullptr,
                                                            &localFileHeper));
        genDdlFromFile->setMsgInfo(*this);
        ret = genDdlFromFile->build();

        if (ret == RET_SUCCEED)
        {
            this->ddlGenContextPtr->m_fileOpenSet.insert(DdlObj_View);
        }
    }
    catch (exception& e)
    {
        ret = RET_GEN_ERR_PERSONAL;
        this->printCatchMsg(FILEINFO, e.what());
    }

    this->finishConnection(ret);

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenFullTable::buildUtilsViewsInDB()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-26108 - LJE - 170906
**
*************************************************************************/
RET_CODE DdlGenFullTable::buildUtilsViewsInDB()
{
    RET_CODE               ret = RET_SUCCEED;
    DdlGenProcessLogger    ddlGenProcessLogger(*this, ret, "Creation of the utility views");

    if ((this->m_dictEntityStp = DBA_GetDictEntitySt(this->objectEn)) == NULL)
    {
        return RET_DBA_INFO_NODATA;
    }

    if (this->m_dictEntityStp->dbRuleEn == DbRule_NotMainTable ||
        this->m_dictEntityStp->dbRuleEn == DbRule_NotInDatabase)
    {
        return ret;
    }

    ddlGenProcessLogger.start();

    bool             bAppend = (this->ddlGenContextPtr->m_fileOpenSet.find(DdlObj_View) != this->ddlGenContextPtr->m_fileOpenSet.end());

    DdlGenFile       localFileHeper(*this->ddlGenContextPtr, this->objectEn, DdlObj_View, bAppend, this->ddlGenContextPtr->bCheck);

    if (this->initConnection(&localFileHeper, false) != RET_SUCCEED)
    {
        return RET_DBA_INFO_NODATA;
    }

    try
    {
        DdlGenFromFilePtr genDdlFromFile(new DdlGenFromFile(DdlObjFromFile_UtilsView,
                                                            this->objectEn,
                                                            *this->ddlGenContextPtr,
                                                            this->ddlGenEntityPtr,
                                                            nullptr,
                                                            false,
                                                            nullptr,
                                                            &localFileHeper));
        genDdlFromFile->setMsgInfo(*this);
        ret = genDdlFromFile->build();

        if (ret == RET_SUCCEED)
        {
            this->ddlGenContextPtr->m_fileOpenSet.insert(DdlObj_View);
        }
    }
    catch (exception& e)
    {
        ret = RET_GEN_ERR_PERSONAL;
        this->printCatchMsg(FILEINFO, e.what());
    }

    this->finishConnection(ret);

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenFullTable::buildViewsInDB()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-14452 - LJE - 121109
**
*************************************************************************/
RET_CODE DdlGenFullTable::buildViewsInDB()
{
    RET_CODE               ret = RET_SUCCEED;
    DdlGenProcessLogger    ddlGenProcessLogger(*this, ret, "Creation of the views");

    if (this->bViewToDo == false)
    {
        return ret;
    }

    ddlGenProcessLogger.start();

    if ((this->m_dictEntityStp = DBA_GetDictEntitySt(this->objectEn)) == NULL)
    {
        return RET_DBA_INFO_NODATA;
    }

    bool             bAppend = (this->ddlGenContextPtr->m_fileOpenSet.find(DdlObj_View) != this->ddlGenContextPtr->m_fileOpenSet.end());

    DdlGenFile       localFileHeper(*this->ddlGenContextPtr, this->objectEn, DdlObj_View, bAppend, this->ddlGenContextPtr->bCheck);

    if (this->initConnection(&localFileHeper, false) != RET_SUCCEED)
    {
        return RET_DBA_INFO_NODATA;
    }

    try
    {
        if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
        {
            DdlGenFromFilePtr genDdlFromFile(new DdlGenFromFile(DdlObjFromFile_View, this->objectEn, *this->ddlGenContextPtr, this->ddlGenEntityPtr, nullptr, false, nullptr, &localFileHeper));
            genDdlFromFile->setMsgInfo(*this);
            ret = genDdlFromFile->build();

            if (RET_GET_LEVEL(ret) != RET_LEV_ERROR &&
                this->ddlGenContextPtr->ddlGenAction.m_execModeEn != DbObjExecMod_BuildFromTemplate)
            {
                genDdlFromFile->getDdlGenContextPtr()->setDdlGenMode(DdlGenMode_Shadow);
                ret = genDdlFromFile->build();
                genDdlFromFile->getDdlGenContextPtr()->setDdlGenMode(DdlGenMode_Standard);
            }
        }
    }
    catch (exception& e)
    {
        ret = RET_GEN_ERR_PERSONAL;
        this->printCatchMsg(FILEINFO, e.what());
    }

    this->finishConnection(ret);

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenFullTable::buildStoredProceduresInDB()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-14452 - LJE - 121109
**
*************************************************************************/
RET_CODE DdlGenFullTable::buildStoredProceduresInDB()
{
    RET_CODE               ret = RET_SUCCEED, retDbi = RET_SUCCEED;

    if ((this->m_dictEntityStp = DBA_GetDictEntitySt(this->objectEn)) == nullptr)
    {
        return RET_DBA_INFO_NODATA;
    }

    if (this->m_dictEntityStp->bIsInitEntity == false && this->ddlGenContextPtr->ddlGenAction.m_bSystemFuncOnly == true)
    {
        return RET_SUCCEED;
    }

    DdlGenProcessLogger    ddlGenProcessLogger(*this, ret, (this->ddlGenContextPtr->ddlGenAction.m_bSystemFuncOnly ? "Creation of the system functions" : "Creation of the stored procedures"));

    if (this->bSProcToDo == false &&
        this->getDdlGenAction().m_mainDdlObjNatEn != DbObjDdlObjNat_System)
    {
        return ret;
    }

    ddlGenProcessLogger.start();

    DdlGenFile       localFileHeper(*this->ddlGenContextPtr, this->objectEn, DdlObj_SProc, this->m_sProcAppendFile, this->ddlGenContextPtr->bCheck);
    this->m_sProcAppendFile = true;

    try
    {
        if (this->initConnection(&localFileHeper, false) != RET_SUCCEED)
        {
            return RET_DBA_INFO_NODATA;
        }

        DdlGenFromFilePtr genDdlFromFile(new DdlGenFromFile(DdlObjFromFile_SProc, this->objectEn, *this->ddlGenContextPtr, this->ddlGenEntityPtr, nullptr, false, nullptr, &localFileHeper));

        if (this->getDdlGenAction().m_installLevel < 9 &&
            this->getDdlGenAction().m_bInitEntityOnly == false &&
            this->ddlGenContextPtr->ddlGenAction.m_bSystemFuncOnly == false &&
            this->getDdlGenContextPtr()->bSimulation == false &&
            this->getDdlGenAction().m_subRequest == false &&
            this->getDdlGenAction().m_mainDdlObjNatEn != DbObjDdlObjNat_TslExtension &&
            this->getDdlGenContextPtr()->m_parentContext->m_bIsInstallFromScratch == false &&
            this->getDdlGenAction().m_fromImport == false)
        {
            this->ddlGenContextPtr->resetStoredProcInfo(this->m_dictEntityStp->entDictId);
        }
        else if (this->getDdlGenAction().m_bInitEntityOnly &&
                 DdlGenDbi::getTempTableSpec(this->ddlGenContextPtr->m_rdbmsEn, this->m_dictEntityStp) == DdlGenDbi::TempTableSpec::Session &&
                 this->getDdlGenAction().m_paramEntitySqlnameStr == "to_insert")
        {
            DdlGenConnGuard     ddlGenConnGuard(*this->ddlGenContextPtr);
            ddlGenConnGuard.getDbiConnForDdl().reconnect(); /* To clean-up temporary tables */
        }


        if (RET_GET_LEVEL(ret) != RET_LEV_ERROR &&
            this->ddlGenContextPtr->bBuildDbi == false &&
            (this->m_dictEntityStp->entNatEn == EntityNat_System || this->m_dictEntityStp->entNatEn == EntityNat_Technical) && /* PMSTA-34418 - LJE - 190211 */
            (this->getDdlGenAction().m_installLevel < 99 || this->getDdlGenAction().m_bSystemFuncOnly == true))
        {
            this->ddlGenContextPtr->bBuildDbi = true;
            retDbi = genDdlFromFile->build();
            this->ddlGenContextPtr->bBuildDbi = false;
        }

        if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
        {
            ret = genDdlFromFile->build();
        }

        if (RET_GET_LEVEL(ret) != RET_LEV_ERROR &&
            RET_GET_LEVEL(retDbi) == RET_LEV_ERROR)
        {
            ret = retDbi;
        }
    }
    catch (exception &e)
    {
        ret = RET_GEN_ERR_PERSONAL;
        this->printCatchMsg(FILEINFO, e.what());
    }

    this->finishConnection(ret);

    if (this->ddlGenContextPtr->m_parentContext != this->ddlGenContextPtr)
    {
        this->ddlGenContextPtr->writeLock();
        for (auto &it : this->ddlGenContextPtr->m_validDdlObjMap)
        {
            this->ddlGenContextPtr->m_parentContext->m_invalidDdlObjMap.erase(it.first);
            this->ddlGenContextPtr->m_parentContext->m_validDdlObjMap.erase(it.first);
            this->ddlGenContextPtr->m_parentContext->m_validDdlObjMap.insert(std::make_pair(it.first, it.second));
        }
        for (auto &it : this->ddlGenContextPtr->m_invalidDdlObjMap)
        {
            this->ddlGenContextPtr->m_parentContext->m_invalidDdlObjMap.erase(it.first);
            this->ddlGenContextPtr->m_parentContext->m_invalidDdlObjMap.insert(std::make_pair(it.first, it.second));
        }
        this->ddlGenContextPtr->writeUnlock();
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenFullTable::buildTriggersInDB()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-14452 - LJE - 121109
**
*************************************************************************/
RET_CODE DdlGenFullTable::buildTriggersInDB()
{
    RET_CODE               ret = RET_SUCCEED;
    DdlGenProcessLogger    ddlGenProcessLogger(*this, ret, "Creation of the triggers");

    if ((this->m_dictEntityStp = DBA_GetDictEntitySt(this->objectEn)) == NULL)
    {
        return RET_DBA_INFO_NODATA;
    }

    if (this->m_dictEntityStp->bIsInitEntity == false &&
        this->ddlGenContextPtr->ddlGenAction.m_bInitEntityOnly == true)
    {
        return RET_SUCCEED;
    }

    DdlGenFile       localFileHeper(*this->ddlGenContextPtr, this->objectEn, DdlObj_Trigger, false, this->ddlGenContextPtr->bCheck);

    if (this->initConnection(&localFileHeper, false) != RET_SUCCEED)
    {
        return RET_DBA_INFO_NODATA;
    }

    this->ddlGenContextPtr->setDdlObjEn(DdlObj_Trigger);

    if (this->bTrgToDo == false)
    {
        if (this->ddlGenContextPtr->optimLevelEn != DdlGenContext::OptimLevel::Full &&
            this->ddlGenContextPtr->ddlGenAction.m_bSingleEntity == false)
        {
            DdlGenTriggerPtr ddlGenTrigger(new DdlGenTrigger(this->objectEn,
                                                             DdlObj_Trigger,
                                                             *this->ddlGenContextPtr,
                                                             nullptr,
                                                             this->ddlGenEntityPtr,
                                                             &localFileHeper,
                                                             TargetTable_Main));

            ddlGenTrigger->init(DmlEvent_All, EventPos_All, TriggerPos_None);
            ret = ddlGenTrigger->build();
        }
    }
    else
    {
        ddlGenProcessLogger.start();
        try
        {
            if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
            {
                this->ddlGenContextPtr->setDefDdlDestDbName(this->m_dictEntityStp->databaseName);
                DdlGenFromFilePtr genDdlFromFile(new DdlGenFromFile(DdlObjFromFile_Trigger,
                                                                    this->objectEn,
                                                                    *this->ddlGenContextPtr,
                                                                    this->ddlGenEntityPtr,
                                                                    nullptr,
                                                                    false,
                                                                    nullptr,
                                                                    &localFileHeper));

                ret = genDdlFromFile->build();
                this->ddlGenContextPtr->setDefDdlDestDbName();
            }
        }
        catch (exception& e)
        {
            ret = RET_GEN_ERR_PERSONAL;
            this->printCatchMsg(FILEINFO, e.what());
        }
    }

    this->finishConnection(ret);

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenFullTable::setEntityStatus()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13109 - LJE - 120106
**
*************************************************************************/
RET_CODE DdlGenFullTable::setEntityStatus(XD_STATUS_ENUM xdStatusEn)
{
    RET_CODE            ret = RET_SUCCEED;
    DdlGenProcessLogger    ddlGenProcessLogger(*this, ret, "Set Entity Status to ");
    DBA_DYNFLD_STP      xdEntityStp = this->getXdEntityStp();

    if (xdStatusEn == XdStatus_Inserted)
    {
        if (GET_ENUM(xdEntityStp, A_XdEntity_XdActionEn) == XdAction_ToDelete)
        {
            xdStatusEn = XdStatus_Deleted;
        }
        else if (GET_ENUM(xdEntityStp, A_XdEntity_XdActionEn) == XdAction_ToPhysicallyDelete)
        {
            xdStatusEn = XdStatus_PhysicallyDeleted;
        }
        else if (GET_ENUM(xdEntityStp, A_XdEntity_XdActionEn) == XdAction_ToDeprecate)
        {
            xdStatusEn = XdStatus_Deprecated;
        }
    }

    switch (xdStatusEn)
    {
        case XdStatus_Deleted:
            ddlGenProcessLogger.m_processStr.append("Deleted");
            break;
        case XdStatus_Deprecated:
            ddlGenProcessLogger.m_processStr.append("Deprecated");
            break;
        case XdStatus_Failed:
            ddlGenProcessLogger.m_processStr.append("Failed");
            break;
        case XdStatus_PhysicallyDeleted:
            ddlGenProcessLogger.m_processStr.append("PhysicallyDeleted");
            break;
        case XdStatus_Inserted:
            ddlGenProcessLogger.m_processStr.append("Inserted");
            break;
        case XdStatus_Untreated:
            ddlGenProcessLogger.m_processStr.append("Untreated");
            break;
        default:
            ddlGenProcessLogger.m_processStr.append("Unknown");
            break;
    }

    ddlGenProcessLogger.start();

    this->m_dictEntityStp = DBA_GetDictEntitySt(this->objectEn);
    if (this->m_dictEntityStp != nullptr &&
        (xdStatusEn != XdStatus_Inserted ||
         this->m_dictEntityStp->xdStatusEn != XdStatus_Untreated ||
         this->bTableToDo == false))
    {
        this->m_dictEntityStp->xdStatusEn = xdStatusEn;
    }

    if ((ret = this->initConnection()) != RET_SUCCEED)
    {
        return ret;
    }
    DdlGenConnGuard     ddlGenConnGuard(*this->ddlGenContextPtr);

    try
    {
        /* PMSTA-45413 - LJE - 210707 */
        MemoryPool           mp;
        DdlGenRequestHelper* requestHelperPtr = this->ddlGenContextPtr->getRequestHelper();
        if (requestHelperPtr == nullptr)
        {
            requestHelperPtr = new DdlGenRequestHelper(&ddlGenConnGuard.getDbiConn(), *this->ddlGenContextPtr);
            mp.ownerObject(requestHelperPtr);
        }

        if (this->ddlGenEntityPtr->getADictEntityStp() != NULL)
        {
            SET_ENUM(this->ddlGenEntityPtr->getADictEntityStp(), A_DictEntity_XdStatusEn, xdStatusEn);

            requestHelperPtr->dbaCall(Update,
                                      DictEntity,
                                      DBA_ROLE_STATUS,
                                      this->ddlGenEntityPtr->getADictEntityStp());
        }

        if (xdEntityStp != nullptr)
        {
            SET_ENUM(xdEntityStp, A_XdEntity_XdActionEn, XdAction_None);
            SET_ENUM(xdEntityStp, A_XdEntity_XdStatusEn, xdStatusEn);
            SET_DATETIME(xdEntityStp, A_XdEntity_BuildDate, this->ddlGenContextPtr->getBuildDate());

            requestHelperPtr->dbaCall(Update,
                                      XdEntity,
                                      DBA_ROLE_STATUS,
                                      xdEntityStp);
        }

        if (xdStatusEn == XdStatus_Inserted &&
            (ret = this->setStatusToAllAttrib(*requestHelperPtr, xdStatusEn)) != RET_SUCCEED)
        {
            ret = RET_DBA_ERR_INSERT_FAILED;
        }

        /* PMSTA-43367 - LJE - 210420 */
        for (auto it = this->m_packageInstallationCompoVector.begin(); it != this->m_packageInstallationCompoVector.end(); ++it)
        {
            SET_ENUM((*it), A_PackageInstallationCompo_XdActionEn, XdAction_None);
            SET_ENUM((*it), A_PackageInstallationCompo_XdStatusEn, xdStatusEn);

            requestHelperPtr->dbaCall(Update,
                                      PackageInstallationCompo,
                                      DBA_ROLE_STATUS,
                                      (*it));
        }
    }
    catch (exception& e)
    {
        ret = RET_GEN_ERR_PERSONAL;
        this->printCatchMsg(FILEINFO, e.what());
    }

    this->finishConnection(ret);

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenFullTable::getXdEntityStp()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   ORACLE - LJE - 141022
**
*************************************************************************/
DBA_DYNFLD_STP DdlGenFullTable::getXdEntityStp()
{
    return this->ddlGenEntityPtr->getXdEntityStp();
}

/************************************************************************
**
**  Function    :   DdlGenFullTable::getObjectEn()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-29748 - LJE - 180111
**
*************************************************************************/
OBJECT_ENUM DdlGenFullTable::getObjectEn() const
{
    return this->objectEn;
}

/************************************************************************
**
**  Function    :   DdlGenFullTable::getDdlGenAction()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-37366 - LJE - 200304
**
*************************************************************************/
DdlGenAction& DdlGenFullTable::getDdlGenAction()
{
    return this->ddlGenContextPtr->ddlGenAction;
}

/************************************************************************
**
**  Function    :   DdlGenFullTable::getDictEntityStp()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-37366 - LJE - 200521
**
*************************************************************************/
DICT_ENTITY_STP DdlGenFullTable::getDictEntityStp()
{
    if (this->m_dictEntityStp == nullptr)
    {
        this->m_dictEntityStp = this->getDdlGenEntityPtr()->getDictEntityStp();
    }
    return this->m_dictEntityStp;
}

/************************************************************************
**
**  Function    :   DdlGenFullTable::getDdlGenEntityPtr()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-37366 - LJE - 200521
**
*************************************************************************/
DdlGenEntity* DdlGenFullTable::getDdlGenEntityPtr()
{
    return this->ddlGenEntityPtr;
}

/************************************************************************
**
**  Function    :   buildXDCNameInMetaDict()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
RET_CODE DdlGenFullTable::buildXDCNameInMetaDict()
{
    RET_CODE	           ret = RET_SUCCEED;
    DdlGenProcessLogger    ddlGenProcessLogger(*this, ret, "update c_name_c field on xd_entity and xd_attribute ");

    vector<string> tokens;
    string staticObjTableStr = "SV_ObjDefStTab";
    string aStructPrefix = "SV_CFieldDef_A_";
    string dsName, dsShortName;
    string objSQLName, objCName;
    string tempString;
    map<string, string>  fieldToSqlNameMap;
    map<string, string>  objToSqlNameMap;
    map<string, string>  dsTypeToNameMap;
    int tempAttributeCount = 0;
    bool bFound = false;
    ifstream   streamSourceFile;
    std::string corePath = GEN_GetPath(Coredir);
    DBA_DYNFLD_STP xdEntityStp = this->getXdEntityStp();

    /*AAACOREPATH must be defined to point work area path */
    if (corePath == NULL || corePath.length() == 0)
    {
        this->printMsg(RET_ENV_ERR_VARUNDEF, "$CCM_PROJECT_PATH must be defined to point work area path");
        return RET_ENV_ERR_VARUNDEF;
    }

    string fileSource_dyndef = corePath;
    fileSource_dyndef.append("/src/dyndef.c");

    ddlGenProcessLogger.start();

    streamSourceFile.open(fileSource_dyndef.c_str());
    if (streamSourceFile.fail())
    {
        this->printMsg(RET_FILE_ERR_OPEN, "Cannot open the Input file: " + fileSource_dyndef);
        return RET_FILE_ERR_OPEN;
    }

    if ((this->m_dictEntityStp = DBA_GetDictEntitySt(this->objectEn)) == NULL ||
        this->initConnection() != RET_SUCCEED)
    {
        return RET_DBA_INFO_NODATA;
    }
    DdlGenConnGuard     ddlGenConnGuard(*this->ddlGenContextPtr);

    if ((this->entNatureEn != EntityNat_Standard && this->entNatureEn != EntityNat_System) ||
        IS_NULLFLD(xdEntityStp, A_XdEntity_EntityDictId) == TRUE ||
        GET_ID(xdEntityStp, A_XdEntity_EntityDictId) >= 2000)
    {
        return RET_DBA_INFO_NODATA;
    }
    objSQLName.assign(GET_SYSNAME(xdEntityStp, A_XdEntity_SqlName));

    /* Parse the dyndef.c for the object list - object name and sqlname */
    while (getline(streamSourceFile, tempString))
    {
        if (string::npos != tempString.find(staticObjTableStr))
        {
            while (getline(streamSourceFile, tempString) && bFound == false && std::string::npos == tempString.find("};"))
            {
                if (std::string::npos == tempString.find("ENTRY_OBJDEFSTTAB") && std::string::npos == tempString.find("\"\""))
                {
                    DdlGen::tokenizeStr(tokens, tempString, "\"");
                    if (tokens.size() > 3 && tokens[3].length() > 1 && tokens.at(1).length() > 1 &&
                        (string::npos != tokens[3].find(objSQLName)) &&
                        tokens[3].length() == objSQLName.length())
                    {
                        objToSqlNameMap[tokens.at(3)] = tokens.at(1);
                        bFound = true;
                    }
                    tokens.clear();
                }
                /* ENTRY_OBJDEFSTTAB(DataDependency,       "data_dependency" ) */
                else if (std::string::npos != tempString.find("ENTRY_OBJDEFSTTAB") &&
                         (std::string::npos == tempString.find("#define")))
                {
                    int curpos = int(tempString.find_first_of("(", strlen("ENTRY_OBJDEFSTTAB") + 1)) + 1;
                    tempString.assign(tempString.substr(curpos, tempString.find_first_of(")") - curpos));
                    tokens.clear();
                    DdlGen::tokenizeStr(tokens, tempString, ",");
                    tokens[1].assign(trim(tokens.at(1), " \""));
                    if (tokens.size() > 1 && tokens.at(0).length() > 1 && tokens.at(1).length() > 1 &&
                        (string::npos != tokens[1].find(objSQLName)) &&
                        tokens[1].length() == objSQLName.length())
                    {
                        objToSqlNameMap[tokens.at(1)] = trim(tokens.at(0));
                        bFound = true;
                    }
                }
            }
            if (bFound == false)
            {
                this->printMsg(RET_DBA_INFO_NODATA, "Object " + objSQLName + " not found in " + fileSource_dyndef);
                return ret = RET_DBA_INFO_NODATA;
            }
            break;
        }
    }
    streamSourceFile.clear();
    streamSourceFile.seekg(0, ios::beg);
    /* now parse for dynField Structure name  dsTypeToNameMap */
    /*  {&AccPer                        , &A_AccPer       , "A_AccPer"   , DynType_All  , SV_CFieldDef_A_AccPer            }, */

    while (RET_GET_LEVEL(ret) != RET_LEV_ERROR && getline(streamSourceFile, tempString))
    {
        if (string::npos != tempString.find("SV_DynDefStTab[]"))
        {
            while (getline(streamSourceFile, tempString) && std::string::npos == tempString.find("};"))
            {
                if (tempString.length() < 5)
                {
                    continue;
                }
                if ((std::string::npos == tempString.find("ENTRY_ALL_DYNDEFSTTAB")) &&
                    (std::string::npos == tempString.find("ENTRY_SHORT_DYNDEFSTTAB")))
                {
                    tokens.clear();
                    DdlGen::tokenizeStr(tokens, tempString, ",");
                    if (tokens.size() > 5)
                    {
                        tokens[0].assign(trim(tokens[0]));
                        tokens[0].assign(trim(tokens[0], "{"));
                        tokens[0].assign(trim(tokens[0]));
                        tokens[0].assign(trim(tokens[0], "&"));
                        if (string::npos != tokens[0].find(objToSqlNameMap[objSQLName]) &&
                            tokens[0].length() == (objToSqlNameMap[objSQLName].length()))
                        {
                            if (tokens[3].length() > 1 && tokens[4].length() > 1)
                            {
                                tokens[4].assign(tokens.at(4).substr(0, tokens.at(4).find_first_of(" }", tokens.at(4).find_first_not_of(" "))));
                                dsTypeToNameMap[trim(tokens.at(3))] = trim(tokens.at(4)) + std::string("[]");
                            }
                            else
                            {
                                this->printMsg(RET_DBA_INFO_NODATA, fileSource_dyndef + string(", Parsing failed for ") + objSQLName);
                                return RET_DBA_INFO_NODATA;
                            }
                        }
                    }
                }
                else if ((std::string::npos != tempString.find("ENTRY_ALL_DYNDEFSTTAB")) && /* ENTRY_ALL_DYNDEFSTTAB(DataDependency)  */
                         (std::string::npos == tempString.find("#define")))
                {
                    int curpos = int(tempString.find_first_of("(", strlen("ENTRY_ALL_DYNDEFSTTAB") + 1)) + 1;
                    tempString.assign(tempString.substr(curpos, tempString.find_first_of(")") - curpos));

                    if (tempString.length() > 1 &&
                        (string::npos != tempString.find(objToSqlNameMap[objSQLName])) &&
                        tempString.length() == objToSqlNameMap[objSQLName].length())
                    {
                        dsTypeToNameMap["DynType_All"] = std::string("SV_CFieldDef_A_") + trim(tempString);
                        bFound = true;
                    }
                }
                else if (std::string::npos != tempString.find("ENTRY_SHORT_DYNDEFSTTAB") &&  /* ENTRY_SHORT_DYNDEFSTTAB(DataDependency) */
                         (std::string::npos == tempString.find("#define")))
                {
                    int curpos = int(tempString.find_first_of("(", strlen("ENTRY_SHORT_DYNDEFSTTAB") + 1)) + 1;
                    tempString.assign(tempString.substr(curpos, tempString.find_first_of(")") - curpos));

                    if (tempString.length() > 1 &&
                        (string::npos != tempString.find(objToSqlNameMap[objSQLName])) &&
                        tempString.length() == objToSqlNameMap[objSQLName].length())
                    {
                        dsTypeToNameMap["DynType_Short"] = std::string("SV_CFieldDef_S_") + trim(tempString);
                        bFound = true;
                    }
                }
            }
            break;
        }
    }
    /* now updated xd_entity */
    aStructPrefix.assign("SV_CFieldDef_A_");
    if (objToSqlNameMap.find(objSQLName) == objToSqlNameMap.end() || objToSqlNameMap[objSQLName].length() < 2)
    {
        this->printMsg(RET_DBA_INFO_NODATA, objSQLName + " - not found in fileSource_dyndef");
        ret = RET_DBA_INFO_NODATA;
    }
    else
    {
        objCName.assign(objToSqlNameMap[objSQLName]);
    }

    if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
    {
        // update the xd_entity C Name.
        SET_SYSNAME(xdEntityStp, A_XdEntity_CName, objCName.c_str());

        if ((ret = DBA_Update2(XdEntity,
                               UNUSED,
                               A_XdEntity,
                               xdEntityStp,
                               DBA_SET_CONN | DBA_NO_CLOSE,
                               ddlGenConnGuard.getDbiConn())) != RET_SUCCEED)
        {
            this->finishConnection(ret);
            MSG_SendMesg(RET_DBA_ERR_UPDATE_FAILED, 0, FILEINFO);
            this->printMsgData(RET_DBA_ERR_UPDATE_FAILED, xdEntityStp);
            return(ret);
        }
        dsName.assign(aStructPrefix);
        dsName.append(objCName + "[]");

        /* read the specific structure defination from dyndef.c */
        streamSourceFile.clear();
        streamSourceFile.seekg(0, ios::beg);
        tokens.clear();
        while (getline(streamSourceFile, tempString))
        {
            if ((dsTypeToNameMap.find("DynType_All") != dsTypeToNameMap.end()) &&
                (string::npos != tempString.find(dsTypeToNameMap["DynType_All"])))
            {
                while (getline(streamSourceFile, tempString) && std::string::npos == tempString.find("};"))
                {
                    if (std::string::npos == tempString.find("\"\""))
                    {
                        DdlGen::tokenizeStr(tokens, tempString, ",");
                        if (tokens.size() > 2)
                        {
                            string sname = tokens.at(0);
                            string fieldPos = tokens.at(2);
                            string mdFlage = tokens.at(4);
                            tokens.clear();
                            DdlGen::tokenizeStr(tokens, sname, "\"");
                            if (tokens.size() > 1)
                            {
                                sname = trim(tokens.at(1));
                            }
                            tokens.clear();
                            DdlGen::tokenizeStr(tokens, fieldPos, "&");
                            if (tokens.size() > 1)
                            {
                                fieldPos = trim(tokens.at(1));
                            }
                            if (!sname.empty() && !fieldPos.empty() && (string::npos != mdFlage.find("TRUE")))
                            {
                                fieldToSqlNameMap[sname] = fieldPos;
                                ++tempAttributeCount;
                            }
                        }
                        tokens.clear();
                    }
                }
                break;
            }
        }
        /* treatment for short only fields.
        **  {&AccPer                        , &S_AccPer                      , "S_AccPer"                      , DynType_Short, SV_CFieldDef_S_AccPer            },
        **  {"_UserCd"                       ,  TRUE, &S_ApplParam_UserCd                 , SysnameType       , FALSE},
        */
        while (getline(streamSourceFile, tempString))
        {
            if ((dsTypeToNameMap.find("DynType_Short") != dsTypeToNameMap.end()) &&
                (string::npos != tempString.find(dsTypeToNameMap["DynType_Short"])))
            {
                int shortIndex = -1;
                while (getline(streamSourceFile, tempString) && std::string::npos == tempString.find("};"))
                {
                    if (std::string::npos == tempString.find("\"\""))
                    {
                        DdlGen::tokenizeStr(tokens, tempString, ",");
                        if (tokens.size() > 5)
                        {
                            string sname = tokens.at(0);
                            string dbflag = tokens.at(1);
                            string fieldPos = tokens.at(2);
                            string mdFlag = tokens.at(4);
                            tokens.clear();
                            shortIndex++;
                            DdlGen::tokenizeStr(tokens, sname, "\"");
                            if (tokens.size() > 1)
                            {
                                sname = trim(tokens.at(1));
                            }
                            tokens.clear();
                            DdlGen::tokenizeStr(tokens, fieldPos, "&");
                            if (tokens.size() > 1)
                            {
                                fieldPos = trim(tokens.at(1));
                            }

                            if (!sname.empty() && !fieldPos.empty() &&
                                fieldToSqlNameMap.find(sname) == fieldToSqlNameMap.end())

                            {
                                if (((string::npos != dbflag.find("TRUE")) &&
                                     (string::npos != mdFlag.find("FALSE"))))
                                {
                                    fieldToSqlNameMap[SYS_ToString(shortIndex)] = fieldPos;
                                    ++tempAttributeCount;
                                }
                                /*
                                ** in some short structure's element short_only_f is not true in MD and both the flage is true in C.
                                ** {"delete_right_f"                ,  TRUE, &S_List_AuthDelFlg                  , FlagType          , TRUE}, **
                                */
                                else if (((string::npos != dbflag.find("TRUE")) &&
                                          (string::npos != mdFlag.find("TRUE"))))
                                {
                                    fieldToSqlNameMap[SYS_ToString(shortIndex)] = fieldPos;
                                    ++tempAttributeCount;
                                }
                            }
                        }
                        tokens.clear();
                    }
                }
                break;
            }
        }
        streamSourceFile.close();

        /* now start to updated the xd_Attributes*/
        for (int i = 0; i < this->ddlGenEntityPtr->getXdAttribNbr(); i++)
        {
            DBA_DYNFLD_STP currXdAttribStp = this->ddlGenEntityPtr->getXdAttrib(i);

            bFound = false;
            if ((GET_ID(currXdAttribStp, A_XdAttrib_Id) > 10000) ||
                (GET_FLAG(currXdAttribStp, A_XdAttrib_LogicalFlg) == TRUE))
            {
                continue;
            }
            string xdAttrSqlName = GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName);
            if (fieldToSqlNameMap.find(xdAttrSqlName) != fieldToSqlNameMap.end())
            {
                SET_SYSNAME(currXdAttribStp, A_XdAttrib_CName, fieldToSqlNameMap[xdAttrSqlName].c_str());
                bFound = true;
            }
            else if (GET_FLAG(currXdAttribStp, A_XdAttrib_ShortOnlyFlg) == TRUE)
            {
                int shortIndex = GET_SMALLINT(currXdAttribStp, A_XdAttrib_ShortIdx);
                if (fieldToSqlNameMap.find(SYS_ToString(shortIndex)) != fieldToSqlNameMap.end())
                {
                    SET_SYSNAME(currXdAttribStp, A_XdAttrib_CName, fieldToSqlNameMap[SYS_ToString(shortIndex)].c_str());
                    bFound = true;
                }
            }
            else
            {
                int shortIndex = GET_SMALLINT(currXdAttribStp, A_XdAttrib_ShortIdx);
                if (fieldToSqlNameMap.find(SYS_ToString(shortIndex)) != fieldToSqlNameMap.end())
                {
                    SET_SYSNAME(currXdAttribStp, A_XdAttrib_CName, fieldToSqlNameMap[SYS_ToString(shortIndex)].c_str());
                    bFound = true;
                    /* log the information */
                    this->printMsg(RET_DBA_ERR_MD, xdAttrSqlName + " - exist in short structure only, though short_only_f is not TRUE in MD. ");
                }
            }

            if (bFound == true)
            {
                if ((ret = DBA_Update2(XdAttrib,
                                       DBA_ROLE_UDT,
                                       A_XdAttrib,
                                       currXdAttribStp,
                                       DBA_SET_CONN | DBA_NO_CLOSE,
                                       ddlGenConnGuard.getDbiConn())) != RET_SUCCEED)
                {
                    this->finishConnection(ret);
                    SET_ENUM(currXdAttribStp, A_XdAttrib_XdStatusEn, XdStatus_Failed);
                    MSG_SendMesg(RET_DBA_ERR_UPDATE_FAILED, 0, FILEINFO);
                    this->printMsgData(RET_DBA_ERR_UPDATE_FAILED, currXdAttribStp);
                    return(ret);
                }
                --tempAttributeCount;
            }
            else
            {
                this->printMsg(RET_DBA_ERR_MD, xdAttrSqlName + " - not found to update in db");
            }
        }
        fieldToSqlNameMap.clear();
    }
    if (RET_GET_LEVEL(ret) == RET_LEV_ERROR && tempAttributeCount != 0)
    {
        this->printMsg(RET_DBA_ERR_MD, "tempAttributeCount = " + tempAttributeCount + std::string("attributes have not been updated"));
        return RET_DBA_INFO_NODATA;
    }
    objToSqlNameMap.clear();
    dsTypeToNameMap.clear();
    fieldToSqlNameMap.clear();
    streamSourceFile.close();
    this->finishConnection(ret);

    return ret;
}

/************************************************************************
**
**  Function    :   getDynDefFullFileName()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:    PMSTA-24007 - LJE - 161213
**
*************************************************************************/
const std::string DdlGenFullTable::getDynDefFullFileName(const std::string& fileName, bool bGenFile, bool bMacFile)
{
    return this->ddlGenContextPtr->getCorePath() + FILE_SEPARATOR + "dyndef" + FILE_SEPARATOR + (bGenFile ? "gen" : "src") + FILE_SEPARATOR + (bGenFile ? bMacFile ? "mac_" : "md_" : "") + fileName;
}

/************************************************************************
**
**  Function    :   extractDynDefFile()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:    PMSTA-24007 - LJE - 161213
**
*************************************************************************/
void DdlGenFullTable::extractDynDefFile(std::string fileName, std::set<string>& incTab, std::set<string>& macTab, std::set<string>& dynDefTab, std::set<string>& objDefTab)
{
    fstream streamdyndef;
    streamdyndef.open(fileName.c_str(), ios::in);

    if (streamdyndef.fail() == true)
    {
        this->printMsg(RET_FILE_ERR_OPEN, "Cannot open the output file " + fileName);
        return;
    }

    /* Read the dyndef files */
    string line;
    bool   bDynDef = false, bObjDef = false;
    int    linePos = 0;

    while (getline(streamdyndef, line))
    {
        linePos++;

        if (bDynDef)
        {
            if (line.find("DynType_Null") == string::npos)
            {
                dynDefTab.insert(line);
            }
            else
            {
                bDynDef = false;
            }
        }
        else if (line.find("DBA_DYNDEF_DEF_ST") != string::npos)
        {
            bDynDef = true;
        }
        else if (bObjDef)
        {
            if (line.find("NullEntityCst") == string::npos)
            {
                objDefTab.insert(line);
            }
            else
            {
                bObjDef = false;
            }
        }
        else if (line.find("DBA_OBJDEF_ST") != string::npos)
        {
            bObjDef = true;
        }
        else
        {
            size_t incPos = line.find("#include");

            if (incPos != string::npos)
            {
                incPos = line.find_first_of(" \t\"", incPos);
                incPos = line.find_first_not_of(" \t\"", incPos);

                if (line.find("mac_", incPos) == incPos)
                {
                    incPos += 4;
                    macTab.insert(line.substr(incPos, line.find(".", incPos) - incPos));
                }
                else if (line.find("md_", incPos) == incPos)
                {
                    incPos += 3;
                    incTab.insert(line.substr(incPos, line.find(".", incPos) - incPos));
                }
            }
        }
    }
}

/************************************************************************
**
**  Function    :   extractDbaDynDefFile()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
void DdlGenFullTable::extractDbaDynDefFile(const std::string& fileName, const std::string& entityCName, std::map<std::string, std::string>& shortStructMap, std::map<std::string, std::string>& allStructMap)
{
    fstream streamdyndef;
    streamdyndef.open(fileName.c_str(), ios::in);

    if (streamdyndef.fail() == true)
    {
        this->printMsg(RET_FILE_ERR_OPEN, "Cannot open the output file " + fileName);
        return;
    }

    /* Read the dyndef files */
    string line;
    int    linePos = 0;

    string shortStructName = "SV_CFieldDef_S_" + entityCName + "[]";
    string allStructName = "SV_CFieldDef_A_" + entityCName;
    bool bShort = false;
    bool bAll = false;

    while (getline(streamdyndef, line))
    {
        linePos++;

        if (DdlGen::find_word(line, "DBA_CFIELDDEF_ST") != string::npos &&
            DdlGen::find_word(line, allStructName) != string::npos)
        {
            bAll = true;
        }
        else if (DdlGen::find_word(line, "DBA_CFIELDDEF_ST") != string::npos &&
                 DdlGen::find_word(line, shortStructName) != string::npos)
        {
            bShort = true;
        }
        else if ((bAll || bShort) && DdlGen::find_first_of(line, ",") != string::npos)
        {
            vector<string> tokens;
            DdlGen::tokenizeStr(tokens, line, ",");
            if (tokens.size() > 4)
            {
                string sqlName = tokens[0];
                size_t pos = sqlName.find("'");
                sqlName.erase(0, pos + 1);
                pos = sqlName.find("'");
                sqlName.erase(pos);

                if (sqlName.empty())
                {
                    bAll = false;
                    bShort = false;

                    if (shortStructMap.empty() == false && allStructMap.empty() == false)
                    {
                        break;
                    }
                }
                else
                {
                    string varName = tokens[2];
                    pos = varName.find("&");
                    varName.erase(0, pos + 1);
                    trim(varName);

                    if (bAll)
                    {
                        allStructMap[sqlName] = varName;
                    }
                    else
                    {
                        shortStructMap[sqlName] = varName;
                    }
                }
            }
        }
    }
}

/************************************************************************
**
**  Function    :   createDynDefFile()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:    PMSTA-24007 - LJE - 161213
**
*************************************************************************/
void DdlGenFullTable::createDynDefFile(const std::string& fileName,
                                       const std::string& macFileName,
                                       const std::set<std::string>& incTab,
                                       const std::set<std::string>& macTab,
                                       const std::set<std::string>& dynDefTab,
                                       const std::set<std::string>& objDefTab)
{
    fstream streamdyndef;
    fstream streamdbamac;

    bool bCFile = fileName.substr(fileName.length() - 2, 2) == ".c";

#ifdef _WINDOWS
    (void)_chmod(fileName.c_str(), _S_IREAD | _S_IWRITE);
#endif

    streamdyndef.open(fileName.c_str(), ios::out | ios::trunc);

    if (streamdyndef.fail() == true)
    {
        SYS_MilliSleep(1000);
        streamdyndef.open(fileName.c_str(), ios::out | ios::trunc);
    }

    if (streamdyndef.fail() == true)
    {
        this->printMsg(RET_FILE_ERR_OPEN, "Cannot create/truncate the output file " + fileName);
        return;
    }

    if (macFileName.empty() == false)
    {
#ifdef _WINDOWS
        (void)_chmod(macFileName.c_str(), _S_IREAD | _S_IWRITE);
#endif

        streamdbamac.open(macFileName.c_str(), ios::out | ios::trunc);

        if (streamdbamac.fail() == true)
        {
            SYS_MilliSleep(1000);
            streamdbamac.open(macFileName.c_str(), ios::out | ios::trunc);
        }

        if (streamdbamac.fail() == true)
        {
            this->printMsg(RET_FILE_ERR_OPEN, "Cannot create/truncate the output file " + macFileName);
            return;
        }
    }

    stringstream header;
    unsigned     linePos = 0;

    DdlGenFile::getFileHeader(header, linePos);

    streamdyndef << header.str() << endl;
    if (bCFile == false)
    {
        streamdbamac << header.str() << endl;
    }

    if (bCFile)
    {
        streamdyndef
            << "#include \"unidef.h\"" << endl
            << "#include \"dba.h\"" << endl;
    }

    for (auto it = incTab.begin(); it != incTab.end(); it++)
    {
        streamdyndef << "#include  " << "\"md_" << *it << (bCFile ? ".c\"" : ".h\"") << endl;
        streamdyndef << "#include  " << "\"../src/" << *it << (bCFile ? ".c\"" : ".h\"") << endl;
    }

    if (bCFile == false)
    {
        for (auto it = macTab.begin(); it != macTab.end(); it++)
        {
            streamdbamac << "#include  " << "\"mac_" << *it << ".h\"" << endl;
        }
    }

    if (bCFile)
    {
        streamdyndef << endl << "DBA_DYNDEF_DEF_ST SV_DynDefGenStTab[] = {" << endl;
        for (auto it = dynDefTab.begin(); it != dynDefTab.end(); it++)
        {
            streamdyndef << *it << endl;
        }
        streamdyndef << "{"
            << std::left << std::setw(22) << "&NullEntity" << ", "
            << std::left << std::setw(22) << "&NullDynSt" << ", "
            << std::left << std::setw(22) << ("\"\"") << ", "
            << std::left << std::setw(14) << "DynType_Null" << ", "
            << std::left << std::setw(36) << "UNUSED" << ", "
            << std::left << std::setw(36) << "UNUSED" << "}";
        streamdyndef << endl << "};" << endl;

        streamdyndef << endl << "DBA_OBJDEF_ST SV_ObjDefGenStTab[] = {" << endl;
        for (auto it = objDefTab.begin(); it != objDefTab.end(); it++)
        {
            streamdyndef << *it << endl;
        }
        streamdyndef << "{"
            << std::left << std::setw(22) << "\"\"" << ", "
            << std::left << std::setw(22) << "&NullEntity" << ", "
            << std::left << std::setw(25) << "NullEntityCst" << ", "
            << std::left << std::setw(30) << "\"\"" << ", "
            << std::left << std::setw(36) << "UNUSED" << "},";
        streamdyndef << endl << "};" << endl;
    }
    streamdyndef.close();

    if (macFileName.empty() == false)
    {
        streamdbamac.close();
    }
}

/************************************************************************
**
**  Function    :   getAttribCName()
**
**  Description :	Get c_name_c field
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-34445 - LJE - 190327
**
*************************************************************************/
void DdlGenFullTable::getAttribCName(DICT_ENTITY_STP attribDictEntityStp, std::string& attribCName, DBA_DYNFLD_STP currXdAttribStp, std::map<string, string>& convertMap)
{
    if (attribDictEntityStp == nullptr)
    {
        return;
    }

    bool            bShortOnly = GET_FLAG(currXdAttribStp, A_XdAttrib_ShortOnlyFlg) == TRUE;
    DATATYPE_ENUM   fieldType = DATATYPE_DICT_TO_ENUM(GET_DICT(currXdAttribStp, A_XdAttrib_DataTpDictId));
    DBA_DYNST_ENUM  dynStEn = bShortOnly ? GET_ADMINGUIST(attribDictEntityStp->objectEn) : GET_EDITGUIST(attribDictEntityStp->objectEn);
    FIELD_IDX_T     attProgN = bShortOnly ? GET_SMALLINT(currXdAttribStp, A_XdAttrib_ShortIdx) : GET_INT(currXdAttribStp, A_XdAttrib_Prog);

    if (IS_NULLFLD(currXdAttribStp, A_XdAttrib_CName))
    {
        FLAG_T            allocFlg = FALSE;
        DBA_CFIELDDEF_STP fieldStp = (GET_FLAG(currXdAttribStp, A_XdAttrib_LogicalFlg) == FALSE ? DBA_GetCFieldDef(dynStEn, attProgN, &allocFlg) : nullptr);

        if (fieldStp == nullptr ||
            allocFlg == TRUE ||
            strcmp(fieldStp->sqlName, GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName)) == 0)
        {
            if (allocFlg == TRUE)
            {
                FREE(fieldStp);
            }
            string mdSqlName = GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName);

            for (auto it = convertMap.begin(); it != convertMap.end(); it++)
            {
                size_t pos = mdSqlName.find(it->first);
                if (pos != string::npos)
                {
                    if (mdSqlName.length() == pos + it->first.length() || mdSqlName[pos + it->first.length()] == '_')
                    {
                        mdSqlName.replace(pos, it->first.length(), it->second);
                    }
                }
            }

            if ((fieldType == FlagType || fieldType == EnumType) && mdSqlName.substr(mdSqlName.length() - 2).compare("_f") == 0)
            {
                mdSqlName.append("lg");
            }
            else if (fieldType == EnumType && mdSqlName.substr(mdSqlName.length() - 2).compare("_e") == 0)
            {
                mdSqlName.append("n");
            }
            else if ((fieldType == DateType || fieldType == DatetimeType) && mdSqlName.substr(mdSqlName.length() - 2).compare("_d") == 0)
            {
                mdSqlName.append("ate");
            }
            else if (mdSqlName.substr(mdSqlName.length() - 2).compare("_c") == 0 ||
                     mdSqlName.substr(mdSqlName.length() - 2).compare("_n") == 0)
            {
                mdSqlName.erase(mdSqlName.length() - 1);
            }
            /* PMSTA-32197 - RAK - 180718 */
            else if ((fieldType == PercentType) && mdSqlName.length() > 9 && mdSqlName.substr(mdSqlName.length() - 9).compare("percent_p") == 0)
            {
                mdSqlName.erase(mdSqlName.length() - 1);
            }

            STRING_Capitalize(mdSqlName, attribCName);
        }
        else
        {
            attribCName = &(fieldStp->sqlName[1]);
        }
        SET_SYSNAME(currXdAttribStp, A_XdAttrib_CName, attribCName.c_str());
    }
    else
    {
        attribCName = GET_SYSNAME(currXdAttribStp, A_XdAttrib_CName);
    }
}

/************************************************************************
**
**  Function    :   buildCDynSTfromMD()
**
**  Description :	Build Dynamic Structure from MD c_name_c field
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:    PMSTA-16395 - TGU - 150720
**
*************************************************************************/
RET_CODE DdlGenFullTable::buildCDynSTfromMD()
{
    RET_CODE             ret = RET_SUCCEED;
    map<string, string>  objToSqlNameMap;	/* map for sqlname to C Object name */
    DdlGenProcessLogger  ddlGenProcessLogger(*this, ret, "Dynamic Structure generation ");
    DBA_DYNFLD_STP       xdEntityStp = this->getXdEntityStp();
    FIELD_IDX_T          maxAllIdx = 0;
    FIELD_IDX_T          maxShortIdx = 0;
    MemoryPool           mp;
    map<string, string>  convertMap;

    if (ICU4AAA_SQLServerUTF8 == 0)
    {
        ret = RET_DBA_ERR_INVDATA;
        this->printMsg(ret, "The database must be on Unicode mode to be able to generate dynamic structure files !");
        return ret;
    }

    convertMap.insert(make_pair("code", "cd"));
    convertMap.insert(make_pair("cde", "cd"));
    convertMap.insert(make_pair("currency", "curr"));
    convertMap.insert(make_pair("market", "mkt"));
    convertMap.insert(make_pair("validity", "valid"));
    convertMap.insert(make_pair("nature", "nat"));
    convertMap.insert(make_pair("object", "obj"));
    convertMap.insert(make_pair("portfolio", "ptf"));
    convertMap.insert(make_pair("strategy", "strat"));
    convertMap.insert(make_pair("link", "lnk"));
    convertMap.insert(make_pair("hierarchy", "hier"));
    convertMap.insert(make_pair("sqlname", "sql_name"));
    convertMap.insert(make_pair("index", "idx"));
    convertMap.insert(make_pair("datatype", "data_tp"));
    convertMap.insert(make_pair("sorting", "sort"));
    convertMap.insert(make_pair("language", "lang"));
    convertMap.insert(make_pair("calculated", "calc"));
    convertMap.insert(make_pair("business", "bus"));
    convertMap.insert(make_pair("precomputed", "precomp"));
    convertMap.insert(make_pair("subtype", "sub_tp"));
    convertMap.insert(make_pair("attribute", "attrib"));
    convertMap.insert(make_pair("format", "fmt"));
    convertMap.insert(make_pair("function", "fct"));
    convertMap.insert(make_pair("display", "disp"));
    convertMap.insert(make_pair("classification", "classif"));
    convertMap.insert(make_pair("amount_m", "amount"));
    convertMap.insert(make_pair("amt_m", "amt"));
    convertMap.insert(make_pair("date_d", "date"));
    convertMap.insert(make_pair("definition_t", "def"));

    stringstream header;
    header
        << "/************************************************************************" << endl
        << "**" << endl
        << "**           Copyright (C) 1995-2024 Temenos Headquarters SA" << endl
        << "**                         All Rights Reserved" << endl
        << "**" << endl
        << "**                     Portfolio Management System" << endl
        << "**" << endl
        << "*************************************************************************/" << endl << endl;

    /* to generate the dyndefmd.c and dyndefmd.h to $CCM_PROJECT_PATH/dyndef/gen/ */
    std::string dyndefmd_h = this->getDynDefFullFileName("dyndef.h");
    std::string dyndefmd_c = this->getDynDefFullFileName("dyndef.c");
    std::string dbamacmd_h = this->getDynDefFullFileName("dbamac.h");

    ddlGenProcessLogger.start();

    if ((this->m_dictEntityStp = DBA_GetDictEntitySt(this->objectEn)) == NULL)
    {
        return RET_DBA_ERR_INVDATA;
    }

    if (this->m_dictEntityStp->entNatEn != EntityNat_Standard &&
        this->m_dictEntityStp->entNatEn != EntityNat_System &&
        this->m_dictEntityStp->entNatEn != EntityNat_Technical &&
        this->m_dictEntityStp->entNatEn != EntityNat_Tsl &&
        this->m_dictEntityStp->entNatEn != EntityNat_TempTable)
    {
        if (this->getDdlGenAction().m_paramEntitySqlnameStr.empty())
        {
            /* Nothing to do */
            return RET_SUCCEED;
        }
        ret = RET_DBA_ERR_INVDATA;
        return ret;
    }

    bool bCDynDefFileToUpd = false;
    bool bHDynDefFileToUpd = false;

    std::set<string> incCTab;
    std::set<string> dynDefCTab;
    std::set<string> objDefCTab;

    std::set<string> incHTab;
    std::set<string> dynDefHTab;
    std::set<string> objDefHTab;

    std::set<string> incMTab;

    std::stringstream dyndefmd_h_Cont;
    std::stringstream dyndefmd_c_Cont;
    std::stringstream dbamacmd_h_Cont;

    this->extractDynDefFile(dyndefmd_h, incHTab, incMTab, dynDefHTab, objDefHTab);
    this->extractDynDefFile(dyndefmd_c, incCTab, incMTab, dynDefCTab, objDefCTab);
    this->extractDynDefFile(dbamacmd_h, incHTab, incMTab, dynDefHTab, objDefHTab);

    if (this->getDdlGenAction().m_paramEntitySqlnameStr.empty() &&
        incCTab.find(this->m_dictEntityStp->mdSqlName) == incCTab.end())
    {
        /* Nothing to do */
        return RET_SUCCEED;
    }

    DdlGenConnGuard     ddlGenConnGuard(*this->ddlGenContextPtr);

    string entityCName;
    if (IS_NULLFLD(xdEntityStp, A_XdEntity_CName))
    {
        entityCName = DBA_GetObjectCName(this->m_dictEntityStp->objectEn);
        SET_SYSNAME(xdEntityStp, A_XdEntity_CName, entityCName.c_str());
    }
    else
    {
        entityCName = GET_SYSNAME(xdEntityStp, A_XdEntity_CName);
    }

    string dbaDynDef_c = this->ddlGenContextPtr->getCorePath() + "/src/dbadyndef.c";
    std::map<std::string, std::string> allDefCTab;
    std::map<std::string, std::string> shortDefCTab;
    this->extractDbaDynDefFile(dbaDynDef_c, entityCName, shortDefCTab, allDefCTab);

    /* To get the header and to verify the path */
    objToSqlNameMap[GET_SYSNAME(xdEntityStp, A_XdEntity_SqlName)] = GET_SYSNAME(xdEntityStp, A_XdEntity_CName);

    map<string, string> replaceMap;

    for (auto mapiObj = objToSqlNameMap.begin(); mapiObj != objToSqlNameMap.end(); ++mapiObj)
    {
        bool           toInsertOnDef = false;

        string upSqlName = upper(mapiObj->first);

        if (incCTab.find(mapiObj->first) == incCTab.end())
        {
            bCDynDefFileToUpd = true;
            toInsertOnDef = true;
            incCTab.insert(mapiObj->first);
        }

        if (incHTab.find(mapiObj->first) == incHTab.end())
        {
            bHDynDefFileToUpd = true;
            incHTab.insert(mapiObj->first);
        }
        if (incMTab.find(mapiObj->first) == incMTab.end())
        {
            bHDynDefFileToUpd = true;
            incMTab.insert(mapiObj->first);
        }

        /* If entitySQLName.c and .h does not exist, update the src directory as well. ($AAACODEPATH/dyndef/src/) */
        std::string strStaticFile_c = this->getDynDefFullFileName(mapiObj->first + ".c", false);
        std::string strStaticFile_h = this->getDynDefFullFileName(mapiObj->first + ".h", false);

        std::string attribSqlName;
        std::string dynStAllCName = "A_" + entityCName;
        std::string dynStShortCName = "S_" + entityCName;
        std::string strDataType;

        map<int, std::string> attribAllHeaderMap_h, attribShortHeaderMap_h;
        map<int, std::string> attribAllInitMap_c, attribShortInitMap_c;
        map<int, std::string> attribAllDSMap_c, attribShortDSMap_c;
        stringstream          permValHeaderStream_h;
        stringstream          setEnumHeaderStream_h, getEnumHeaderStream_h, getEnumNoImpactHeaderStream_h;

        string aStructPrefix = "static DBA_CFIELDDEF_ST SV_GenFieldDef_" + dynStAllCName;
        string shortStructPrefix = "static DBA_CFIELDDEF_ST SV_GenFieldDef_" + dynStShortCName;
        attribAllDSMap_c[-1] = aStructPrefix + "[] = {";
        attribShortDSMap_c[-1] = shortStructPrefix + "[] = {";

        this->ddlGenEntityPtr->sortAttributes();

        for (int i = 0; i < this->ddlGenEntityPtr->getXdAttribNbr(); i++)
        {
            std::string    attribAllCName;
            std::string    attribShortCName;
            std::string    attribCName;

            DBA_DYNFLD_STP currXdAttribStp = this->ddlGenEntityPtr->getXdAttrib(i);

            if (GET_FLAG(currXdAttribStp, A_XdAttrib_CustomFlg) != Custom_No ||
                GET_FLAG(currXdAttribStp, A_XdAttrib_PrecompFlg) == TRUE ||
                GET_FLAG(currXdAttribStp, A_XdAttrib_ModelBankEn) != ModelBank_None ||
                GET_FLAG(currXdAttribStp, A_XdAttrib_XdStatusEn) != XdStatus_Inserted)
            {
                continue;
            }

            if (GET_A_XdAttrib_FeatureEn(currXdAttribStp) != XdEntityFeatureFeatureEn::None &&
                GET_A_XdAttrib_FeatureEn(currXdAttribStp) != XdEntityFeatureFeatureEn::Security &&
                GET_A_XdAttrib_FeatureEn(currXdAttribStp) != XdEntityFeatureFeatureEn::AdditionalSecurity &&
                GET_A_XdAttrib_FeatureEn(currXdAttribStp) != XdEntityFeatureFeatureEn::RPCEntity &&
                IS_NULLFLD(currXdAttribStp, A_XdAttrib_TemplateXdAttribId) == FALSE)
            {
                auto xdEntityFeatureIt = this->ddlGenEntityPtr->xdEntityFeatureMap.find(GET_A_XdAttrib_FeatureEn(currXdAttribStp));
                if (xdEntityFeatureIt == this->ddlGenEntityPtr->xdEntityFeatureMap.end() ||
                    (static_cast<GEN_RULE_ENUM>(GET_ENUM(xdEntityFeatureIt->second, A_XdEntityFeature_GenRuleEn)) != GenRule_Always &&
                     static_cast<GEN_RULE_ENUM>(GET_ENUM(xdEntityFeatureIt->second, A_XdEntityFeature_GenRuleEn)) != GenRule_AlwaysButVirtual &&
                     static_cast<GEN_RULE_ENUM>(GET_ENUM(xdEntityFeatureIt->second, A_XdEntityFeature_GenRuleEn)) != GenRule_AlwaysButCalculated &&
                     static_cast<GEN_RULE_ENUM>(GET_ENUM(xdEntityFeatureIt->second, A_XdEntityFeature_GenRuleEn)) != GenRule_AlwaysButDenorm &&
                     static_cast<GEN_RULE_ENUM>(GET_ENUM(xdEntityFeatureIt->second, A_XdEntityFeature_GenRuleEn)) != GenRule_AlwaysNotMandatory))
                {
                    continue;
                }
            }

            bool            bShortOnly = GET_FLAG(currXdAttribStp, A_XdAttrib_ShortOnlyFlg) == TRUE;
            DATATYPE_ENUM   fieldType = DATATYPE_DICT_TO_ENUM(GET_DICT(currXdAttribStp, A_XdAttrib_DataTpDictId));

            this->getAttribCName(this->m_dictEntityStp, attribCName, currXdAttribStp, convertMap);

            attribSqlName = std::string("\"") + GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName) + std::string("\"");
            if (attribSqlName.length() < 30)
            {
                attribSqlName.resize(30, ' ');
            }

            char cstrDType[256];
            DBA_GetDataTypeEnumToStr(cstrDType, fieldType);
            strDataType = cstrDType;
            strDataType.resize(20, ' ');

            if (bShortOnly == false)
            {
                attribAllCName = dynStAllCName + "_" + GET_SYSNAME(currXdAttribStp, A_XdAttrib_CName);
                if (attribAllCName.length() < 40)
                {
                    attribAllCName.resize(40, ' ');
                }

                INT_T allIndex = GET_INT(currXdAttribStp, A_XdAttrib_Prog);
                stringstream indexStream;
                indexStream << setw(4) << allIndex;

                if (allIndex > maxAllIdx)
                {
                    maxAllIdx = allIndex;
                }

                attribAllHeaderMap_h[allIndex] = "extern FIELD_IDX_T		"
                    + attribAllCName
                    + ";"
                    + "\t/* " + indexStream.str() + ": " + strDataType + "*/";
                attribAllInitMap_c[allIndex] = "FIELD_IDX_T		"
                    + attribAllCName + "		= " + indexStream.str() + ";"
                    + "\t/* " + strDataType + "*/";

                /* calculated_e = 2 means virtual not in database, not in stored procedures */
                if (GET_ENUM(currXdAttribStp, A_XdAttrib_CalcEn) == DictAttr_Virtual)
                {
                    attribAllDSMap_c[allIndex] = "	{" + attribSqlName
                        + ",FALSE "
                        + ",&" + attribAllCName
                        + "," + strDataType + ",TRUE  },";
                }
                else if (GET_FLAG(currXdAttribStp, A_XdAttrib_LogicalFlg) == TRUE)
                {
                    attribAllDSMap_c[allIndex] = "	{" + attribSqlName
                        + ",FALSE "
                        + ",&" + attribAllCName
                        + "," + strDataType + ",FALSE }, /* Logical attribute access */";
                }
                else
                {
                    attribAllDSMap_c[allIndex] = "	{" + attribSqlName
                        + ",TRUE  "
                        + ",&" + attribAllCName
                        + "," + strDataType + ",TRUE  },";
                }

                string checkAttrStr(attribAllCName);
                trim(checkAttrStr);
                auto oldCNameIt = allDefCTab.find(GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName));
                if (oldCNameIt != allDefCTab.end() &&
                    checkAttrStr.compare(oldCNameIt->second) != 0)
                {
                    stringstream msg;
                    msg
                        << "All structure C Name modified for attribute " << std::left << setw(30)
                        << GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName)
                        << " - " << std::left << setw(30) << oldCNameIt->second
                        << " -> " << std::left << setw(30) << checkAttrStr;

                    this->printMsg(RET_DBA_INFO_EXIST, msg.str());

                    replaceMap[oldCNameIt->second] = checkAttrStr;
                }
            }

            if (IS_NULLFLD(currXdAttribStp, A_XdAttrib_ShortIdx) == FALSE &&
                (IS_NULLFLD(currXdAttribStp, A_XdAttrib_ShortDispRank) == TRUE ||
                 GET_SMALLINT(currXdAttribStp, A_XdAttrib_ShortDispRank) >= 0))
            {
                attribShortCName = dynStShortCName + "_" + GET_SYSNAME(currXdAttribStp, A_XdAttrib_CName);
                if (attribShortCName.length() < 40)
                {
                    attribShortCName.resize(40, ' ');
                }

                SMALLINT_T shortIndex = GET_SMALLINT(currXdAttribStp, A_XdAttrib_ShortIdx);
                stringstream indexStream;
                indexStream << setw(4) << (int)shortIndex;

                if (shortIndex > maxShortIdx)
                {
                    maxShortIdx = shortIndex;
                }

                attribShortHeaderMap_h[shortIndex] = "extern FIELD_IDX_T		"
                    + attribShortCName + ";"
                    + "\t/* " + indexStream.str() + ": " + strDataType + "*/";
                attribShortInitMap_c[shortIndex] = "FIELD_IDX_T		"
                    + attribShortCName + "		= " + indexStream.str() + ";"
                    + "\t/* " + strDataType + "*/";

                attribShortDSMap_c[shortIndex] = "	{" + attribSqlName + ",TRUE  ,"
                    + "&" + attribShortCName
                    + "," + strDataType + "," + "TRUE " + " },";

                string checkAttrStr(attribShortCName);
                trim(checkAttrStr);
                auto oldCNameIt = shortDefCTab.find(GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName));
                if (oldCNameIt != shortDefCTab.end() &&
                    checkAttrStr.compare(oldCNameIt->second) != 0)
                {
                    stringstream msg;
                    msg
                        << "Short structure C Name modified for attribute " << std::left << setw(30)
                        << GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName)
                        << " - " << std::left << setw(30) << oldCNameIt->second
                        << " -> " << std::left << setw(30) << checkAttrStr;
                    this->printMsg(RET_DBA_INFO_EXIST, msg.str());

                    replaceMap[oldCNameIt->second] = checkAttrStr;
                }
            }

            if (fieldType == EnumType)
            {
                string enumClassName = entityCName + attribCName;

                bool bSetGetToDo = (GET_ENUM(currXdAttribStp, A_XdAttrib_PermAuthEn) != PermAtuh_Overwrite);

                if (bSetGetToDo && IS_NULLFLD(currXdAttribStp, A_XdAttrib_ParentXdAttribId) == FALSE)
                {
                    DBA_DYNFLD_STP shParXdAttribStp = mp.allocDynst(FILEINFO, S_XdAttrib);
                    DBA_DYNFLD_STP allParXdAttribStp = mp.allocDynst(FILEINFO, A_XdAttrib);
                    DBA_DYNFLD_STP shParXdEntityStp = mp.allocDynst(FILEINFO, S_XdEntity);
                    DBA_DYNFLD_STP allParXdEntityStp = mp.allocDynst(FILEINFO, A_XdEntity);
                    string         parEntityCName, parAttribCName;

                    this->copyDynFld(shParXdAttribStp, S_XdAttrib_Id, currXdAttribStp, A_XdAttrib_ParentXdAttribId);

                    if ((ret = DBA_Get2(XdAttrib,
                                        UNUSED,
                                        S_XdAttrib,
                                        shParXdAttribStp,
                                        A_XdAttrib,
                                        &allParXdAttribStp,
                                        DBA_SET_CONN | DBA_NO_CLOSE,
                                        ddlGenConnGuard.getDbiConn())) != RET_SUCCEED)
                    {
                        this->printMsg(ret, "Unknown parent xd_attribute for attribute " + string(GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName)));
                        ret = RET_DBA_ERR_NODATA;
                    }

                    if (ret == RET_SUCCEED)
                    {
                        this->copyDynFld(shParXdEntityStp, S_XdEntity_Id, allParXdAttribStp, A_XdAttrib_XdEntityId);

                        if ((ret = DBA_Get2(XdEntity,
                                            UNUSED,
                                            S_XdEntity,
                                            shParXdEntityStp,
                                            A_XdEntity,
                                            &allParXdEntityStp,
                                            DBA_SET_CONN | DBA_NO_CLOSE,
                                            ddlGenConnGuard.getDbiConn())) != RET_SUCCEED)
                        {
                            this->printMsg(ret, "Unknown parent xd_entity for attribute " + string(GET_SYSNAME(currXdAttribStp, A_XdAttrib_SqlName)));
                            ret = RET_DBA_ERR_NODATA;
                        }
                    }

                    DICT_ENTITY_STP parentDictEntityStp = DBA_GetDictEntityByDictId(GET_DICT(allParXdEntityStp, A_XdEntity_EntityDictId));

                    if (parentDictEntityStp == nullptr ||
                        incHTab.find(parentDictEntityStp->mdSqlName) == incHTab.end())
                    {
                        bSetGetToDo = false;
                    }
                    else
                    {
                        this->getAttribCName(parentDictEntityStp, parAttribCName, allParXdAttribStp, convertMap);

                        if (IS_NULLFLD(allParXdEntityStp, A_XdEntity_CName) == TRUE)
                        {
                            OBJECT_ENUM parObjectEn;
                            DBA_GetObjectEnum(GET_DICT(allParXdEntityStp, A_XdEntity_EntityDictId), &parObjectEn);
                            parEntityCName = DBA_GetObjectCName(parObjectEn);
                        }
                        else
                        {
                            parEntityCName = GET_SYSNAME(allParXdEntityStp, A_XdEntity_CName);
                        }

                        enumClassName = parEntityCName + parAttribCName;
                    }
                }

                if (bSetGetToDo &&
                    IS_NULLFLD(currXdAttribStp, A_XdAttrib_ParentXdAttribId) == TRUE &&
                    GET_ENUM(currXdAttribStp, A_XdAttrib_PermAuthEn) != PermAtuh_Overwrite)
                {
                    auto xdPermValAttribMapPtr = this->ddlGenEntityPtr->getXdPermValByAttribMap(GET_ID(currXdAttribStp, A_XdAttrib_Id));

                    if (xdPermValAttribMapPtr != nullptr && xdPermValAttribMapPtr->empty() == false)
                    {
                        permValHeaderStream_h
                            << "enum class " << enumClassName << " : ENUM_T " << endl
                            << "{" << endl;

                        for (auto permValIt = xdPermValAttribMapPtr->begin(); permValIt != xdPermValAttribMapPtr->end(); ++permValIt)
                        {
                            if (GET_ENUM(permValIt->second, A_XdPermVal_XdStatusEn) == XdStatus_Inserted &&
                                (GET_ENUM(permValIt->second, A_XdPermVal_PermValNatEn) < 100 ||
                                 GET_ENUM(currXdAttribStp, A_XdAttrib_PermAuthEn) == PermAuth_No))
                            {
                                string permValNameStr;

                                STRING_Capitalize(GET_STRING(permValIt->second, A_XdPermVal_Name), permValNameStr);

                                if (permValNameStr.find_first_of("0123456789") == 0) /* PMSTA-50418 - DDV - 221027 - Enum element cannot start with a number */
                                {
                                    permValNameStr = "en" + permValNameStr;
                                }
                                else if (permValNameStr.empty())
                                {
                                    permValNameStr = SYS_Stringer("Value", CAST_INT(GET_ENUM(permValIt->second, A_XdPermVal_PermValNatEn)));
                                }

                                if (permValIt != xdPermValAttribMapPtr->begin())
                                {
                                    permValHeaderStream_h << ",";
                                }
                                else
                                {
                                    permValHeaderStream_h << " ";
                                }

                                permValHeaderStream_h
                                    << "   " << std::left << setw(28) << permValNameStr
                                    << " = " << (int)GET_ENUM(permValIt->second, A_XdPermVal_PermValNatEn) << endl;
                            }
                        }

                        permValHeaderStream_h
                            << "};" << endl << endl;
                    }
                }

                if (bSetGetToDo)
                {
                    vector<string> allAttribVector;
                    allAttribVector.push_back(attribAllCName);
                    allAttribVector.push_back(attribShortCName);

                    for (auto it = allAttribVector.begin(); it != allAttribVector.end(); ++it)
                    {
                        string permAttribName = trim(*it);

                        if (permAttribName.empty() == false)
                        {
                            getEnumHeaderStream_h
                                << "inline " << std::left << setw(28) << enumClassName << " GET_" << permAttribName << "(DBA_DYNFLD_STP p) " << endl
                                << "{" << endl
                                << "    return  (static_cast<" << enumClassName << ">  (GET_ENUM(p, " << *it << ")));" << endl
                                << "}" << endl;

                            getEnumNoImpactHeaderStream_h
                                << "inline " << std::left << setw(28) << enumClassName << " _GET_" << permAttribName << "(DBA_DYNFLD_STP p) " << endl
                                << "{" << endl
                                << "    return  (static_cast<" << enumClassName << ">  (_GET_ENUM(p, " << *it << ")));" << endl
                                << "}" << endl;

                            setEnumHeaderStream_h
                                << "inline " << std::left << setw(28) << "void" << " SET_" << permAttribName << "(DBA_DYNFLD_STP p, " << enumClassName << " enumValue)" << endl
                                << "{" << endl
                                << "    SET_ENUM(p, " << *it << ", static_cast<unsigned char>(enumValue));" << endl
                                << "}" << endl;
                        }
                    }
                }
            }
        }

        attribSqlName = "\"\"";
        attribSqlName.resize(30, ' ');
        string attribAllCName = "NULL";
        attribAllCName.resize(41, ' ');
        strDataType = "NullDataType";
        strDataType.resize(20, ' ');

        attribAllDSMap_c[maxAllIdx + 1] =
            std::string("	{") + attribSqlName + std::string(",FALSE ,") + attribAllCName + "," + strDataType + ",FALSE }";
        attribShortDSMap_c[maxShortIdx + 1] =
            std::string("	{") + attribSqlName + std::string(",FALSE ,") + attribAllCName + "," + strDataType + ",FALSE }";

        /*Generate Dynamic Structure definitions*/
        string strFile_c = this->getDynDefFullFileName(mapiObj->first + ".c");
        string strFile_h = this->getDynDefFullFileName(mapiObj->first + ".h");
        string strFile_mac = this->getDynDefFullFileName(mapiObj->first + ".h", true, true);

#ifdef _WINDOWS
        (void)_chmod(strFile_c.c_str(), _S_IREAD | _S_IWRITE);
        (void)_chmod(strFile_h.c_str(), _S_IREAD | _S_IWRITE);
        (void)_chmod(strFile_mac.c_str(), _S_IREAD | _S_IWRITE);
#endif

		stringstream contentObj_c;
		stringstream contentObj_h;
		stringstream contentObj_mac;

        /* Generate header C file */
        contentObj_h << header.str() << endl << endl;

        contentObj_h << "#define " << std::left << std::setw(22) << (entityCName + "Cst")
            << std::left << std::setw(4) << " " << GET_DICT(xdEntityStp, A_XdEntity_EntityDictId) << endl << endl;
        contentObj_h << "extern OBJECT_ENUM " << std::left << std::setw(22) << entityCName << ";"
            << " /* "
            << std::left << std::setw(4) << GET_DICT(xdEntityStp, A_XdEntity_EntityDictId) << " : "
            << std::left << std::setw(30) << mapiObj->first
            << "*/" << endl << endl;

        contentObj_h << "extern DBA_DYNST_ENUM " << std::left << std::setw(22) << dynStAllCName << ";" << endl;
        contentObj_h << "extern DBA_DYNST_ENUM " << std::left << std::setw(22) << dynStShortCName << ";" << endl << endl;

        for (auto mapiterator = attribAllHeaderMap_h.begin(); mapiterator != attribAllHeaderMap_h.end(); ++mapiterator)
        {
            contentObj_h << mapiterator->second << endl;
        }
        contentObj_h << endl;
        for (auto mapiterator = attribShortHeaderMap_h.begin(); mapiterator != attribShortHeaderMap_h.end(); ++mapiterator)
        {
            contentObj_h << mapiterator->second << endl;
        }
        contentObj_h << endl << permValHeaderStream_h.str();

        /* Generate macro C file */
        contentObj_mac << header.str() << endl << endl;

        if (getEnumHeaderStream_h.str().empty() == false)
        {
            contentObj_mac
                << getEnumHeaderStream_h.str() << endl
                << getEnumNoImpactHeaderStream_h.str() << endl
                << setEnumHeaderStream_h.str() << endl;
        }

       
        /* Generate body C file */
        contentObj_c << header.str() << endl << endl;

        contentObj_c << "OBJECT_ENUM " << std::left << std::setw(22) << entityCName << ";"
            << " /* "
            << std::left << std::setw(4) << GET_DICT(xdEntityStp, A_XdEntity_EntityDictId) << " : "
            << std::left << std::setw(30) << mapiObj->first
            << "*/" << endl << endl;

        contentObj_c << "DBA_DYNST_ENUM " << std::left << std::setw(22) << dynStAllCName << ";" << endl;
        contentObj_c << "DBA_DYNST_ENUM " << std::left << std::setw(22) << dynStShortCName << ";" << endl << endl;

        for (auto mapiterator = attribAllInitMap_c.begin(); mapiterator != attribAllInitMap_c.end(); ++mapiterator)
        {
            contentObj_c << mapiterator->second << endl;
        }
        contentObj_c << endl;
        for (auto mapiterator = attribAllDSMap_c.begin(); mapiterator != attribAllDSMap_c.end(); ++mapiterator)
        {
            contentObj_c << mapiterator->second << endl;
        }
        contentObj_c << "	};" << endl << endl;
        for (auto mapiterator = attribShortInitMap_c.begin(); mapiterator != attribShortInitMap_c.end(); ++mapiterator)
        {
            contentObj_c << mapiterator->second << endl;
        }
        contentObj_c << endl;
        for (auto mapiterator = attribShortDSMap_c.begin(); mapiterator != attribShortDSMap_c.end(); ++mapiterator)
        {
            contentObj_c << mapiterator->second << endl;
        }
        contentObj_c << "	};" << endl << endl;

        createObjDefFile(strFile_h, contentObj_h);
        createObjDefFile(strFile_c, contentObj_c);
        createObjDefFile(strFile_mac, contentObj_mac);

        aStructPrefix = "static DBA_CFIELDDEF_ST SV_ManFieldDef_" + dynStAllCName;
        shortStructPrefix = "static DBA_CFIELDDEF_ST SV_ManFieldDef_" + dynStShortCName;

        /* generate the empty static structure if does not exist in src directory*/
        fstream fileStaticObj_c, fileStaticObj_h;

        fileStaticObj_c.open(strStaticFile_c.c_str(), ios::in);
        fileStaticObj_h.open(strStaticFile_h.c_str(), ios::in);

        if (fileStaticObj_c.fail() == true || fileStaticObj_h.fail() == true)
        {
            fileStaticObj_c.open(strStaticFile_c.c_str(), ios::out);	fileStaticObj_h.open(strStaticFile_h.c_str(), ios::out);

            if (fileStaticObj_c.fail() == true || fileStaticObj_h.fail() == true)
            {
                this->printMsg(RET_FILE_ERR_OPEN, "Cannot open the output file " + strStaticFile_c + " and/or " + strStaticFile_h);
                return RET_FILE_ERR_OPEN;
            }

            fileStaticObj_h << header.str() << endl << endl;

            fileStaticObj_c << header.str() << endl << endl;
            fileStaticObj_c << aStructPrefix + "[] = {" << endl;
            fileStaticObj_c << std::string("	{\"\",		") + std::string("FALSE,	") + "NULL,	" + "NullDataType,	" + "FALSE	}" << endl;
            fileStaticObj_c << "};" << endl << endl;

            fileStaticObj_c << shortStructPrefix + "[] = {" << endl;
            fileStaticObj_c << std::string("	{\"\",		") + std::string("FALSE,	") + "NULL,	" + "NullDataType,	" + "FALSE	}" << endl;
            fileStaticObj_c << "};" << endl << endl;

            fileStaticObj_c
                << "/*********************************************************************************" << endl
                << "**  PROCEDURES AND PARAMETERS LIST FOR : " << upSqlName << endl
                << "**********************************************************************************/" << endl
                << "static DBA_PROC_ST SV_ProcTab_" << entityCName << "[] = {" << endl;


            if (GET_MASKBIT(xdEntityStp, A_XdEntity_AutomaticMask, Automatic_SProc) == TRUE)
            {
                fileStaticObj_c
                    << "{SqlServer   , Synchronous, AllStdProcs, UNUSED        , &NullDynSt                 , &NullDynSt               , UNUSED, \"\"                            , NOFCT, UNUSED                        , NullOpti, NULL, 0, NULL /* eoparam */ }, " << endl; /* PMSTA-34344 - TEB - 190319 */
            }

            fileStaticObj_c
                << "{SqlServer   , Synchronous, NullAction , UNUSED        , &NullDynSt                 , &NullDynSt               , UNUSED, \"\"                            , NOFCT, UNUSED                        , NullOpti, NULL, 0, NULL /* eoparam */ }" << endl   /* PMSTA-34344 - TEB - 190319 */
                << "};" << endl;

        }
        fileStaticObj_c.close();
        fileStaticObj_h.close();

        if (toInsertOnDef)
        {
            stringstream allDynDefStream;
            allDynDefStream << "{"
                << std::left << std::setw(22) << ("&" + entityCName) << ", "
                << std::left << std::setw(22) << ("&" + dynStAllCName) << ", "
                << std::left << std::setw(22) << ("\"" + dynStAllCName + "\"") << ", "
                << std::left << std::setw(14) << "DynType_All" << ", "
                << std::left << std::setw(36) << ("SV_GenFieldDef_" + dynStAllCName) << ", "
                << std::left << std::setw(36) << ("SV_ManFieldDef_" + dynStAllCName) << "},";
            dynDefCTab.insert(allDynDefStream.str());

            stringstream shortDynDefStream;
            shortDynDefStream << "{"
                << std::left << std::setw(22) << ("&" + entityCName) << ", "
                << std::left << std::setw(22) << ("&" + dynStShortCName) << ", "
                << std::left << std::setw(22) << ("\"" + dynStShortCName + "\"") << ", "
                << std::left << std::setw(14) << "DynType_Short" << ", "
                << std::left << std::setw(36) << ("SV_GenFieldDef_" + dynStShortCName) << ", "
                << std::left << std::setw(36) << ("SV_ManFieldDef_" + dynStShortCName) << "},";
            dynDefCTab.insert(shortDynDefStream.str());

            stringstream objDefStream;
            objDefStream << "{"
                << std::left << std::setw(22) << ("\"" + entityCName + "\"") << ", "
                << std::left << std::setw(22) << ("&" + entityCName) << ", "
                << std::left << std::setw(25) << (entityCName + "Cst") << ", "
                << std::left << std::setw(30) << ("\"" + mapiObj->first + "\"") << ", "
                << std::left << std::setw(36) << ("SV_ProcTab_" + entityCName) << "},";
            objDefCTab.insert(objDefStream.str());
        }
    }

    if (bCDynDefFileToUpd || this->ddlGenContextPtr->bForceReBuild)
    {
        this->createDynDefFile(dyndefmd_c, string(), incCTab, incMTab, dynDefCTab, objDefCTab);
    }
    if (bHDynDefFileToUpd || this->ddlGenContextPtr->bForceReBuild)
    {
        this->createDynDefFile(dyndefmd_h, dbamacmd_h, incHTab, incMTab, dynDefHTab, objDefHTab);
    }

    if (replaceMap.empty() == false)
    {
        cout << endl
            << "**************************************************************************************************************************" << endl
            << "**************************************************************************************************************************" << endl
            << "Execute the following commands to fix the naming changes: " << endl
            << "**************************************************************************************************************************" << endl
            << "**************************************************************************************************************************" << endl;

        vector<string> fileTypes;
        fileTypes.push_back("*.h");
        fileTypes.push_back("*.c");
        fileTypes.push_back("*.cpp");

        for (auto fileType = fileTypes.begin(); fileType != fileTypes.end(); ++fileType)
        {
            cout << "find " << this->ddlGenContextPtr->getCorePath() << " -type f -name \"" << *fileType << "\" | xargs sed -i '" << endl;
            for (auto it = replaceMap.begin(); it != replaceMap.end(); ++it)
            {
                cout << "s/\\b" << it->first << "\\b/" << it->second << "/g" << endl;
            }
            cout << "'" << endl;
        }
        cout
            << "**************************************************************************************************************************" << endl
            << "**************************************************************************************************************************" << endl;
    }

    return ret;
}

/************************************************************************
**
**  Function    :   createDynDefFile()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:    PMSTA-24007 - LJE - 161213
**
*************************************************************************/
void DdlGenFullTable::createObjDefFile(const std::string &fileName, const std::stringstream &newContentStream)
{
    std::stringstream oldContentStream;

    ifstream chkFileObj;

    chkFileObj.open(fileName.c_str(), ios::in);

    if (chkFileObj.fail() == false)
    {
        string line;
        while (getline(chkFileObj, line))
        {
            oldContentStream << line << endl;
        }
        chkFileObj.close();
    }

    if (newContentStream.str() != oldContentStream.str())
    {

#ifdef _WINDOWS
        (void)_chmod(fileName.c_str(), _S_IREAD | _S_IWRITE);
#endif

        ofstream fileObj;
        fileObj.open(fileName.c_str(), ios::ate);

        if (fileObj.fail() == true)
        {
            this->printMsg(RET_FILE_ERR_OPEN, "Cannot open the output file " + fileName);
            return;
        }

        fileObj << newContentStream.str();

        fileObj.close();
    }
}

/************************************************************************
**
**  Function    :   DdlGenFullTable::genSampleImportFile()
**
**  Description :   To generate sample import file (-s -o<table>)
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:    PMSTA-37366 - LJE - 191210
**
*************************************************************************/
RET_CODE DdlGenFullTable::genSampleImportFile()
{
    RET_CODE        ret = RET_SUCCEED;
    DICT_ENTITY_STP dictEntitystp = DBA_GetDictEntitySt(this->getObjectEn());

    if (this->getObjectEn() == NullEntity || dictEntitystp == nullptr)
    {
        this->printMsg(RET_GEN_ERR_INVARG, "The generation of sample import file require valid '-o' parameter");
    }
    else
    {
        string attLineStr("ATT code name denom currency_id.code mgt_begin_d");

        ofstream impFile;
        string   impFileName = this->ddlGenContextPtr->getAaaHomePath() + "/tmp/sample_" + this->getMsgEntitySqlName() + ".imp";

        impFile.open(impFileName.c_str(), ios::ate);

#ifdef _WINDOWS
        (void)_chmod(impFileName.c_str(), _S_IREAD | _S_IWRITE);
#endif

        const char* confDir = GEN_GetPath(Confdir);
        ifstream confFile;
        string   confFileName(confDir);
        confFileName += FILE_SEPARATOR + this->getMsgEntitySqlName() + ".cfg";
        confFile.open(impFileName.c_str(), ios::in);

        if (confFile.fail() == false)
        {
            string currLineStr;
            while (getline(confFile, currLineStr))
            {
                if (currLineStr.find("ATT ") == 0)
                {
                    attLineStr = currLineStr;
                }
            }
        }

        std::random_device random_device;
        std::mt19937 random_engine(random_device());
        std::uniform_int_distribution<int> distribution_0_5(0, 5);

        auto const randomNumber = distribution_0_5(random_engine);

        std::cout << randomNumber << '\n';

        vector<string> currencyVec;
        currencyVec.push_back("EUR");
        currencyVec.push_back("CHF");
        currencyVec.push_back("USD");
        currencyVec.push_back("GBP");
        currencyVec.push_back("AUD");
        currencyVec.push_back("CAD");

        vector<string> dateVec;
        dateVec.push_back("31/12/2006");
        dateVec.push_back("31/12/2008");
        dateVec.push_back("31/12/2018");
        dateVec.push_back("31/03/2018");
        dateVec.push_back("28/02/2019");
        dateVec.push_back("NULL");

        impFile
            << endl << "SET QUOTE NONE"
            << endl << "SET SEPARATOR ;"
            << endl << "SET DECIMAL ."
            << endl << "SET THOUSAND ,"
            << endl << "SET DATAFORMAT DELIMITED"
            << endl << "SET PREFIX DATA DAT"
            << endl << "SET DATEFORMAT DD-MM-YYYY"
            << endl << ""
            << endl << "CMD INSUPD " << this->m_dictEntityStp->mdSqlName
            << endl << attLineStr;

        impFile.fill('0');

        for (int i = 0; i < 1000; i++)
        {
            impFile
                << endl << "DAT T_IFS_PTF" << setw(4) << i
                << ";N_IFS_PTF" << setw(4) << i
                << ";D_IFS_PTF" << setw(4) << i
                << ";" << currencyVec[distribution_0_5(random_engine)]
                << ";" << dateVec[distribution_0_5(random_engine)]
                << ";";
        }
        impFile << endl;

        impFile
            << endl << "CMD DELETE " << this->m_dictEntityStp->mdSqlName
            << endl << "ATT code";

        for (int i = 0; i < 1000; i++)
        {
            impFile
                << endl << "DAT T_IFS_PTF" << setw(4) << i
                << ";";
        }

        impFile << endl;
        impFile.close();

        this->printMsg(RET_SUCCEED, "The import file: " + impFileName + " has been created");
    }
    return ret;
}

/*************************************************************************
**   END  ddlgenfulltable.cpp                                        Odyssey **
*************************************************************************/
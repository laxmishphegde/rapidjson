/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef DDLGENTABLE_H
#define DDLGENTABLE_H

#include      "ddlgen.h"

/************************************************************************
**      Constant & Macro definitions
*************************************************************************/

/************************************************************************
**      Structures & typedef definitions
*************************************************************************/

/************************************************************************
**      External definitions attached to : ddlgentable.cpp
*************************************************************************/
class DdlGenUpgrade
{
public:
    // Constructors
    DdlGenUpgrade(const std::string &colSqlNameStr)
        : m_bNewAttrib(false)
        , m_bCustom(false)
        , m_colSqlNameStr(colSqlNameStr)
        , m_bTreated(false)
    {
    }
    DdlGenUpgrade(const DdlGenUpgrade &ref)
        : DdlGenUpgrade(ref.m_colSqlNameStr)
    {
        *this = ref;
    }

    // Destructor
    virtual ~DdlGenUpgrade()
    {
    }

    // Methods
    DdlGenUpgrade& operator = (const DdlGenUpgrade &ref)
    {
        this->m_colSqlNameStr = ref.m_colSqlNameStr;
        this->m_alterCmdStr   = ref.m_alterCmdStr;
        this->m_upgradeCmdStr = ref.m_upgradeCmdStr;
        this->m_bNewAttrib    = ref.m_bNewAttrib;
        this->m_bCustom       = ref.m_bCustom;
        this->m_bTreated      = ref.m_bTreated;

        return *this;
    }

    bool            m_bNewAttrib;
    bool            m_bCustom;

    std::string     m_colSqlNameStr;
    std::string     m_alterCmdStr;

    std::string     m_upgradeCmdStr;

    bool            m_bTreated;
};

class DdlGenTable :public DdlGen
{

public:
    typedef std::unique_ptr<DdlGenTable> Ptr;


    // Constructors
    DdlGenTable(OBJECT_ENUM        paramObjectEn,
                TARGET_TABLE_ENUM  paramTargetTableEn,
                DdlGenContext     &paramDdlGenContext,
                DdlGenEntity      *paramDdlGenEntityPtr,
                DdlGenFile        *paramFileHelper);

    DdlGenTable(const DdlGenTable&) = delete;
    // Destructor
    virtual ~DdlGenTable();

    // Methods
    RET_CODE          build();
    RET_CODE          dropTable();
    DdlGenTable& operator = (const DdlGenTable&) = delete;

    std::string            getCreateCmd(bool bOneLine);
    std::string            getDeleteCmd();
    std::string            getTruncateCmd();

    bool                   m_bForceTempTable;

protected:

    enum class KinOfAlterTable
    {
        AddNew,
        Modify,
        ModifyDefault
    };

    // Methods
    RET_CODE          update();
    RET_CODE          alter();
    RET_CODE          alterByIntoExistingTable(); /* PMSTA-14452 - LJE - 130205 */
    RET_CODE          getAllAttrib(bool bInString);

    RET_CODE          checkAttribToPhysicallyDelete();

    RET_CODE          printHeader();
    RET_CODE          printBody();
    RET_CODE          printFooter();

    void              fillIndexToDrop(const std::string &columnSqlName, bool bOnlyFctBased);
    RET_CODE          dropIndexToDrop();
    RET_CODE          dropViewToDrop();
    RET_CODE          dropConstraintToDrop();

    RET_CODE          create();
    RET_CODE          drop();
    RET_CODE          grant();

    RET_CODE          createConstraints();

    RET_CODE          fillUdFieldsTable(bool);
    RET_CODE          fillMultiEntityInfo();
    RET_CODE          fillPkTable();
    RET_CODE          fillTable();
    RET_CODE          executeBatch(bool, RequestHelper &, int, DdlGenMsg &);

    RET_CODE          setName();

    void              printAlteredInfo();
    DdlGenSqlBlock    getSortedAlterCmd(std::vector<DdlGenUpgrade> &alterVector);
    std::string       getAlteredAttrib(std::vector<DdlGenUpgrade> &alterVector);
    std::string       getAlterTable(std::vector<DdlGenUpgrade> &alterVector, KinOfAlterTable kindOfAlterTable);
    std::string       getCreateTable();

    bool              bNewTable;
    bool              bCreate;
    bool              bOptim;
    bool              bCheckIfExists;
    bool              bForceUpgrade;
    bool              bNewIdentity;
    bool              bJoinMainTable;

    DdlGenFile       *fileHelperTable;

private:

    int                        attribPrintedNbr;

    std::vector<DdlGenUpgrade> newAttribVector;
    std::vector<DdlGenUpgrade> dropAttribVector;
    std::vector<DdlGenUpgrade> alterAttribVector;
    std::vector<DdlGenUpgrade> alterDbMandatoryAttribVector;
    std::vector<DdlGenUpgrade> alterDbDefaultAttribVector;

    bool                       bTableDropped;
    std::string                removeIdentitySqlName;

    std::stringstream          asSelectClause;

	bool                       m_bForceDrop;
    bool                       bForceDropOnly;
    bool                       bForceTruncate;

    bool                       bToTruncate;
    bool                       bToDrop;
    bool                       bAlterInfoPrinted;

    std::set<DdlObjDef>        m_indexToDropSet;
    bool                       m_bPrimaryKey;

    std::string                           m_segNameStr;
};

#endif	                               /* ifndef DDLGENTABLE_H */
/************************************************************************
**      END       ddlgentable.h                                   Odyssey
*************************************************************************/

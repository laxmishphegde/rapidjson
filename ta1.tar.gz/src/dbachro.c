/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define DBACHRO_C

/************************************************************************
**      Include files
*************************************************************************/
#define STDIO_H
#define STRING_H
#define TIME_H
#define STDLIB_H

#include "unidef.h"     /* Mandatory */
#include "gen.h"
#include "dba.h"
#include "proc.h"
#include "date.h"
#include "scptyl.h"
#include "hier.h"       /* REF4306 - CSY - 000315 */
#include "fin.h"

/************************************************************************
**      External entry points
**
** DBA_GetChronoVal() 		Get chronological data (instrument, portfolio, currency or third) 
** DBA_GetCurrChrono()		Get a chronological record according to received nature.
** DBA_GetCurrChronoFromHier    the same, but trying to get it from hierarchy for optimisation
** DBA_GetDimChrono() 		Read optimization buffer wit received prerequisite arguments.
** DBA_GetInstrChrono()		Get instrument chronological record according to received arguments.
** DBA_GetPortChrono()		Get portfolio chronological data according to received arguments.
** DBA_GetPortChronoFromHier    the same, but trying to get it from hierarchy for optimisation
** DBA_GetThirdChrono()		Get third chronological data according to received arguments.
** DBA_GetThirdChronoFromHier   the same, but trying to get it from hierarchy for optimisation
** DBA_InstrChronoByFreq() 	Search instrument chronological data at determined frequency.
** DBA_PtfChronoByFreq() 	Search portfolio chronological data at determined frequency.
** DBA_SelectInstrChrono() 	Select instr. chronological record according to received arguments.
** DBA_SetDimChrono() 		Given some prerequisite arguments, construct chrono.
** DBA_ThirdChronoByFreq()	Search third chronological data at determined frequency.
**
*************************************************************************/

/************************************************************************
**      Local functions
**
*************************************************************************/
/* REF4306 - CSY - 000313 */
STATIC int DBA_FilterNaturePtfChrono(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP);
STATIC int DBA_FilterNatureCurrChrono(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP);
STATIC int DBA_FilterNatureThirdChrono(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP);

STATIC int DBA_FilterNatureComplChrono(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP); /* PMSTA06646 - LJE - 080530 */

/************************************************************************
**      Static definitions & data
*************************************************************************/

/************************************************************************
**      FONCTIONS
************************************************************************/

/************************************************************************
*
*  Function          : DBA_GetChronoVal()
*
*  Description       : Get chronological data (instrument, portfolio, currency or third) 
*                      according to a time position (cf TIMEDIM_ENUM), a nature and a date.
*
*  Arguments         : entDictId    : entity identifier
*                      objId        : object identifier (instrument, currency, portfolio or third)  
*                      currId       : currency identifier ?
*                      natEn        : nature of chronological data (depend on table)
*                      date         : date
*                      timeDim      : time dimension (CURRENT, NEXT, TODAY)
*                      validFlg     : 
*                      valPtr       : pointer on the value
*
*
*  Return            : RET_SUCCEED
*                      RET_GEN_ERR_INVARG : if problem with input arguments
*                      RET_MEM_ERR_ALLOC  : if memory allocation failed
*                      RET_DBA_ERR_NODATA : if no data
*
*  Creation date     : 12.03.96 - RAK
*
*************************************************************************/
RET_CODE DBA_GetChronoVal(OBJECT_ENUM  objEn, 
			              ID_T         objId, 
			              ID_T         currId,
			              ENUM_T       natEn, 
			              DATETIME_T   date,
		                  TIMEDIM_ENUM timeDim,
		                  char         validFlg,
			              NUMBER_T     *val)
{
	DBA_DYNFLD_STP chronoData=NULLDYNST;
	RET_CODE ret=RET_SUCCEED;
	*val = 0.0;

	/* CURRENCY */
	if (objEn== Curr)
    {
	    if ((chronoData = ALLOC_DYNST(A_CurrChrono)) == NULLDYNST)
	    		MSG_RETURN(RET_MEM_ERR_ALLOC);

	    /* currId = underlying */
	    if ((ret = DBA_GetCurrChrono(objId, currId, date, 
			                         (CURRCHRONONAT_ENUM) natEn, TimeDim_Last, 
			                         (FLAG_T) validFlg, /* RAK - 000407 */
                                     chronoData)) == RET_SUCCEED)
	    {
		    *val = GET_NUMBER(chronoData, A_CurrChrono_Val);
	    }

	    FREE_DYNST(chronoData, A_CurrChrono);
    }
	/* INSTRUMENT */
    else if (objEn == Instr)
    {
	    if ((chronoData = ALLOC_DYNST(A_InstrChrono)) == NULLDYNST)
	    		MSG_RETURN(RET_MEM_ERR_ALLOC);

	    if ((ret = DBA_GetInstrChrono(objId, date, (CHRONONAT_ENUM) natEn, 0,  /* REF10598 - LJE - 041011 */
		                              TimeDim_Last, (FLAG_T) validFlg, /* RAK - 000407 */
                                      chronoData)) == RET_SUCCEED)
	    {
			/* 
			** TGU-REF11704-060414-Use GET/SET_LONGAMOUNT since data type for field 
			** instr_chrono.value_n has been changed from NUMBER to LONGAMOUNT. 
			*/
		    *val = GET_LONGAMOUNT(chronoData, A_InstrChrono_Val);
	    }

	    FREE_DYNST(chronoData, A_InstrChrono);
    }
	/* PORTFOLIO */
    else if (objEn == Ptf)
    {
	    if ((chronoData = ALLOC_DYNST(A_PtfChrono)) == NULLDYNST)
	    		MSG_RETURN(RET_MEM_ERR_ALLOC);

	    /* currId ?? */
	    if ((ret = DBA_GetPortChrono(objId, currId, date, (PTFCHRONONAT_ENUM) natEn, 
		                             TimeDim_Last, (FLAG_T) validFlg, /* RAK - 000407 */
                                     chronoData)) == RET_SUCCEED)
	    {
		    *val = GET_NUMBER(chronoData, A_PtfChrono_Val);
	    }

	    FREE_DYNST(chronoData, A_PtfChrono);
    }
	/* THIRD */
    else if (objEn == Third)
    {
	    if ((chronoData = ALLOC_DYNST(A_ThirdChrono)) == NULLDYNST)
	    		MSG_RETURN(RET_MEM_ERR_ALLOC);

	    if ((ret = DBA_GetThirdChrono(objId, currId, date, (THIRDCHRONONAT_ENUM) natEn, 
		                              TimeDim_Last, (FLAG_T) validFlg, /* RAK - 000407 */
                                      chronoData)) == RET_SUCCEED)
	    {
		    *val = GET_NUMBER(chronoData, A_ThirdChrono_Value);
	    }

	    FREE_DYNST(chronoData, A_ThirdChrono);
	}

	return(ret);
}

/************************************************************************
*
*  Function          : DBA_GetThirdChrono()
*
*  Description       : Get third chronological data according to a time position
*                      (cf TIMEDIM_ENUM), a nature (cf THIRDCHRONONAT_ENUM), a currency
*                      and a date.
*
*  Arguments         : thidId       : third id
*                      currId       : currency id
*                      datetime     : date  
*                      chronoNat    : nature of chrono data of interest
*                      timeDim      : time dimension (CURRENT, NEXT, TODAY)
*                      validFlg     : 
*                      chronoPtr    : pointer on the result dyn. struct
*
*
*  Return            : RET_SUCCEED
*                      RET_GEN_ERR_INVARG : if problem with input arguments
*                      RET_MEM_ERR_ALLOC  : if memory allocation failed
*                      RET_DBA_ERR_NODATA : if no data
*
*  Creation date     : 12.03.96 - RAK
*                      000306 - REF4306 - DDV - Add new parameter currId
*
*************************************************************************/
RET_CODE DBA_GetThirdChrono(ID_T                thirdId,
                            ID_T                currId,
	                    DATETIME_T          dateTime, 
	                    THIRDCHRONONAT_ENUM chronoNat,              
		            TIMEDIM_ENUM        timeDim,
		            FLAG_T                validFlg,
	                    DBA_DYNFLD_STP      chronoPtr) 
{
	DBA_DYNFLD_STP getChrono=NULLDYNST;

	if (chronoPtr == NULLDYNST)
	{
	   MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, 
			"DBA_GetThirdChrono", "chrono pointer");
	   return(RET_GEN_ERR_INVARG);
	}
		
	if ((getChrono = ALLOC_DYNST(A_ThirdChrono)) == NULLDYNST)
		MSG_RETURN(RET_MEM_ERR_ALLOC);

	SET_ID(getChrono,       A_ThirdChrono_ThirdId,     thirdId);
    if (currId > 0) /* REF4306 - CSY - 000321 */
	    SET_ID(getChrono,       A_ThirdChrono_CurrId,      currId);
	SET_DATETIME(getChrono, A_ThirdChrono_ValidDate,   dateTime);
	SET_ENUM(getChrono,     A_ThirdChrono_NatEn,       (ENUM_T)chronoNat);
	SET_ENUM(getChrono,     A_ThirdChrono_TimeDimEn,   (ENUM_T)timeDim);
	SET_FLAG(getChrono,     A_ThirdChrono_ValidFlg,    (FLAG_T)validFlg);

	if (DBA_Get2(ThirdChrono, UNUSED, A_ThirdChrono, 
		    getChrono, A_ThirdChrono, &chronoPtr,
	            UNUSED, UNUSED, UNUSED) != RET_SUCCEED)
	{
		/*
		SYSNAME_T entSqlName;
		strcpy(entSqlName, DBA_GetDictEntitySqlName(PtfChrono));
		MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO, 
			     entSqlName, ptfId);
		*/
		FREE_DYNST(getChrono, A_ThirdChrono);
		return(RET_DBA_ERR_NODATA);
	}

	FREE_DYNST(getChrono, A_ThirdChrono);

	return(RET_SUCCEED);
}

/************************************************************************
*
*  Function          : DBA_GetThirdChronoFromHier()
*
*  Description       : Get portfolio chronological data according to a portfolio id,
*                      a time dimension (cf TIMEDIM_ENUM), a nature (cf CHRONONAT_ENUM),
*                      a date, a currency, and an optional validity flag.
*                      this function gives the same result as DBA_GetThirdChrono, but is optimised
*                      specially when used in DisplayChrono or Return  (financial functions
*                      with domain period divided in subperiods)                      
*
*  Arguments         : thirdId        : portfolio id
*                      currId       : currency id  
*                      datetime     : date  
*                      chronoNat    : nature of chrono data of interest
*                      timeDim      : time dimension (CURRENT, NEXT, TODAY)
*                      validFlg     : [optional]
*                                     if TRUE, only valid port_chrono must be retrieved
*                                     (validity depends on the validity period parameter system) 
*                      hierHead     : pointer on hierarchy
*                      chronoPtr    : pointer on the result dyn. struct
*
*
*  Return            : RET_SUCCEED
*                      RET_GEN_ERR_INVARG : if problem with input arguments
*                      RET_MEM_ERR_ALLOC  : if memory allocation failed
*                      RET_DBA_ERR_NODATA : if no data
*
*  Creation date     : 000314 - REF4306 - CSY
*  Last modification : 010123 - REF5609 - CSY: add criteria on currency id for extract from hier
*
*************************************************************************/
RET_CODE DBA_GetThirdChronoFromHier(ID_T               thirdId, 
                           ID_T               currId,
	                       DATETIME_T         dateTime, 
	                       THIRDCHRONONAT_ENUM  chronoNat,              
		                   TIMEDIM_ENUM       timeDim,
		                   FLAG_T             validFlg,
                           DBA_DYNFLD_STP     domainPtr,
                           DBA_HIER_HEAD_STP  hierHead,
	                       DBA_DYNFLD_STP     chronoPtr) 
{
    /* REF4306 - CSY - 000309 */
    DBA_DYNFLD_STP  *thirdChronoTab = NULLDYNSTPTR;
    DBA_DYNFLD_STP  *selThirdChronoTab = NULLDYNSTPTR;
    DBA_DYNFLD_STP  chronoArgSt=NULLDYNST;
    DBA_DYNFLD_STP     noChronoPtr=NULLDYNST; /* for optimisation when no data have been selected */
    int			indexFld;
    int         thirdChronoNbr = 0;
    int         selThirdChronoNbr = 0;
	DBA_DYNFLD_ST	indexDynSt;
    /* DBA_DYNFLD_ST	natureSt; */
	
    INT_T             validityPeriod = 0;  /* REF4306 - CSY - 000324.*/
    DATETIME_T     tmpDate;
    DATETIME_T     magicEndDateTime;
    RET_CODE       ret = RET_SUCCEED;
    FLAG_T         stopFlg = FALSE;
    int            iChrono = -1;
    int            i = 0;
    magicEndDateTime.date = 0;
    magicEndDateTime.time = 0;
    memset(&indexDynSt, 0,   sizeof(DBA_DYNFLD_ST));

    if (chronoPtr == NULLDYNST)
	{
	   MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, 
			"DBA_GetThirdChronoFromHier", "chrono pointer");
	   return(RET_GEN_ERR_INVARG);
	}

    /* set the index key on ThirdId for the extract */
    indexFld = A_ThirdChrono_ThirdId;
	SET_ID((&indexDynSt), 0, thirdId);
    /* set the criteria on nature for filter function used in the extract */ 
    /*SET_ENUM((&natureSt), 0, (ENUM_T)chronoNat);*/

    /* allocate a structure that will contain selection criterias */
    if ((chronoArgSt = ALLOC_DYNST(Chrono_Arg)) == NULLDYNST)
    {
		return(RET_MEM_ERR_ALLOC);
    }

    /* REF5609 - CSY - 010123 */
    if (currId > 0)
    {
        SET_ID(chronoArgSt, Chrono_Arg_CurrId, currId);
    }
    else
    {
        SET_NULL_ID(chronoArgSt, Chrono_Arg_CurrId);
    }
    SET_ENUM(chronoArgSt, Chrono_Arg_NatEn, chronoNat);


	/* first try to extract the requested port_chono from hierarchy */
    if ((ret = DBA_ExtractHierEltRecByIndexKey(hierHead, A_ThirdChrono, 
                                                           	 indexFld, indexDynSt, FALSE, 
								 DBA_FilterNatureThirdChrono,
                                 /* &natureSt, */ chronoArgSt, /* REF5609 - CSY - 010123 */
						                     NULLFCT, FALSE,
			                                             &thirdChronoNbr, &thirdChronoTab)) != RET_SUCCEED) 
    {       
        FREE(thirdChronoTab);
		return(ret);
    }

    /* if not found in hierarchy */
    if (thirdChronoNbr == 0)
    {
        FREE(thirdChronoTab);

        /* set criterias */
        SET_ID(chronoArgSt, Chrono_Arg_InstrId, thirdId);
        SET_ENUM(chronoArgSt, Chrono_Arg_NatEn, chronoNat);
        SET_DATETIME(chronoArgSt, Chrono_Arg_BegDate, 
            GET_DATETIME(domainPtr, A_Domain_InterpFromDate));
        SET_DATETIME(chronoArgSt, Chrono_Arg_EndDate,
            GET_DATETIME(domainPtr, A_Domain_InterpTillDate));
        if (currId > 0)
        {
            SET_ID(chronoArgSt, Chrono_Arg_CurrId, currId);
        }
        else
        {
            SET_NULL_ID(chronoArgSt, Chrono_Arg_CurrId);
        }
        SET_ENUM(chronoArgSt, Chrono_Arg_TimeDimEn, timeDim);
        SET_FLAG(chronoArgSt, Chrono_Arg_ValidityFlg, validFlg);
        
        /* do a big select to retrieve A_ThirdChrono by Third and by nature */
        if ((ret = DBA_Select2(ThirdChrono, UNUSED, Chrono_Arg, chronoArgSt,
                A_ThirdChrono, &selThirdChronoTab, UNUSED, UNUSED,
                &selThirdChronoNbr, UNUSED, UNUSED))!= RET_SUCCEED)
        {
            FREE_DYNST(chronoArgSt, Chrono_Arg);
            FREE(selThirdChronoTab);
            return(ret);
        }

        if (selThirdChronoNbr == 0)
        {
            if ((noChronoPtr = ALLOC_DYNST(A_ThirdChrono)) == NULLDYNST)
            {
                FREE(selThirdChronoTab);
		        return(RET_MEM_ERR_ALLOC);
            }
            SET_ID(noChronoPtr, A_ThirdChrono_ThirdId, thirdId);
            SET_ENUM(noChronoPtr, A_ThirdChrono_NatEn, chronoNat);
            magicEndDateTime.date = MAGIC_END_DATE;
            SET_DATETIME(noChronoPtr, A_ThirdChrono_ValidDate, magicEndDateTime);
            DBA_AddHierRecord(hierHead, noChronoPtr, A_ThirdChrono, FALSE, HierAddRec_NoLnk);
            FREE(selThirdChronoTab);
            return(RET_DBA_ERR_NODATA);
        }
        
        /* add the result of the select in hierarchy */
        /* sort is done on index while adding */
        DBA_AddHierRecordList(hierHead, selThirdChronoTab, selThirdChronoNbr, A_ThirdChrono, TRUE);

        /* second try to extract from hierarchy */
        if ((ret = DBA_ExtractHierEltRecByIndexKey(hierHead, A_ThirdChrono, 
                                                           	 indexFld, indexDynSt, FALSE, 
								             DBA_FilterNatureThirdChrono,
                                            /* &natureSt, */ chronoArgSt, /* REF5609 - CSY - 010123 */
						                     NULLFCT, FALSE,
			                                             &thirdChronoNbr, &thirdChronoTab)) != RET_SUCCEED) 
        {
            FREE(thirdChronoTab);
            FREE(selThirdChronoTab);
		    return(ret);
        }
        FREE(selThirdChronoTab);

    }

    FREE_DYNST(chronoArgSt, Chrono_Arg);
    
    tmpDate.date = dateTime.date; /* initialisation for compil... (avoid warnings)*/
    tmpDate.time = dateTime.time; /* initialisation for compil... (avoid warnings)*/
    if (validFlg == TRUE)
    {
        GEN_GetApplInfo(ApplThirdChronoValPeriod, &validityPeriod);
        /* tmpDate = dateTime - validityPeriod 
            dateTime = the argument date given in the script */
        tmpDate.date = DATE_Move(dateTime.date, (-1)*(validityPeriod), Day);
        tmpDate.time = dateTime.time;
    }

    /* process to retrieve the relevant third_chrono among thirdChronoTab */
    /* manage the LAST/CURRENT/PREVIOUS */ 
    switch (timeDim)
    {
    case TimeDim_Last:
        for(i=thirdChronoNbr-1; i >= 0 && stopFlg == FALSE; i--)
        {
            /* third_chrono are sorted by ascending dates */                      
            if ((DATETIME_CMP(
                    GET_DATETIME(thirdChronoTab[i], A_ThirdChrono_ValidDate),
                    dateTime) <= 0) && 
                    (currId == 0 || 
                    (GET_ID(thirdChronoTab[i], A_ThirdChrono_CurrId) == currId)))
            {                
                if (validFlg == FALSE)
                {
                    iChrono = i;
                    stopFlg = TRUE;
                }
                else if(DATETIME_CMP(
                            GET_DATETIME(thirdChronoTab[i], A_ThirdChrono_ValidDate),
                            tmpDate) > 0 &&
                    DATETIME_CMP(
                            GET_DATETIME(thirdChronoTab[i], A_ThirdChrono_ValidDate),
                            dateTime) <= 0)
                {
                    iChrono = i;
                    stopFlg = TRUE;
                }               
            }
        }
        break;
    case TimeDim_Crt:
        for(i=0; i < thirdChronoNbr && stopFlg == FALSE; i++)
        {
            if ((DATETIME_CMP(
                    GET_DATETIME(thirdChronoTab[i], A_ThirdChrono_ValidDate),
                    dateTime) == 0) && 
                    (currId == 0 || 
                    (GET_ID(thirdChronoTab[i], A_ThirdChrono_CurrId) == currId)))
            {
                iChrono = i;
                stopFlg = TRUE;
            }
        }
        break;
    case TimeDim_Next:
        /*  third_chrono are sorted by ascending dates */
        for(i=0; i < thirdChronoNbr && stopFlg == FALSE; i++)
        {
            if ((DATETIME_CMP(
                    GET_DATETIME(thirdChronoTab[i], A_ThirdChrono_ValidDate),
                    dateTime) > 0) && 
                    (currId == 0 || 
                    (GET_ID(thirdChronoTab[i], A_ThirdChrono_CurrId) == currId)))
            {
                iChrono = i;
                stopFlg = TRUE;
            }
        }
        break;
    }        

    if (stopFlg == TRUE)
        COPY_DYNST(chronoPtr, thirdChronoTab[iChrono], A_ThirdChrono);

    FREE(thirdChronoTab);
    return(RET_SUCCEED);
}

/************************************************************************
*
*  Function          : DBA_FilterNatureThirdChrono()  filter function used 
*                      in script THIRD_CHRONO
*
*  Description       : This function filters records by nature
*
*  Arguments         : dynSt   :      current record (A_ThirdChrono)
*                      dynStTp :      current record type
*                      argIn   :      input argument containing search criteria
*
*  Return            : TRUE/FALSE
*
*  Creation date     : 000315 - CSY - REF4306
*  Last modification : 010123 - CSY - REF5609
*
*************************************************************************/
STATIC int DBA_FilterNatureThirdChrono(DBA_DYNFLD_STP dynSt, 
		                 		        DBA_DYNST_ENUM dynStTp, 
		                 		        DBA_DYNFLD_STP argIn)
{
    /* compare the nature of the current record with the nature given (in argIn) */
	/* if (GET_ENUM(argIn,0) == GET_ENUM(dynSt, A_ThirdChrono_NatEn)) */
    if (GET_ENUM(argIn, Chrono_Arg_NatEn) == GET_ENUM(dynSt, A_ThirdChrono_NatEn) &&
        GET_ID(argIn, Chrono_Arg_CurrId) == GET_ID(dynSt, A_ThirdChrono_CurrId))
        return TRUE;
    else
        return FALSE;
}

/************************************************************************
**
**  Function    :   DBA_GetDimChrono()
**
**  Description :   Read optimization buffer wit received prerequisite arguments.
**                 
**  Arguments   :   instrId       instrument identifier.
**                  refDateTime   pointer on structure datetime.
**                  validPeriod   validity period.
**                  chronoNat     chrono nature (CHRONONAT_ENUM).
**                  validDateTime validity date.
**                  currentId     current instrument identifier.
**                  value         current value.
**                  msgFlag       error flag.
**                  msgCode       error code.
**                  msgTxt        message text.
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   REF1065 - RAK - 971212 
**  Modif.	:   REF3725 - RAK - 990702      
**
*************************************************************************/
RET_CODE DBA_GetDimChrono(DBA_DYNFLD_STP dimChronoPtr,
			              DBA_DYNFLD_STP instrChronoPtr)
{
	DBA_PROC_STP	procedure=(DBA_PROC_STP)NULL;
	RET_CODE	ret = RET_SUCCEED;
	DBA_OPTIMODE_ENUM optiMode;
    int posIndexLocal= -1,posIndexGlobal= -1;

	if ((procedure = DBA_GetStoredProcs(Get, InstrChrono, UNUSED, Dim_InstrChrono,
					    dimChronoPtr, A_InstrChrono)) != NULL)
	{
		optiMode = Opti_Local;
		if (GET_ID(dimChronoPtr, Dim_InstrChrono_InstrId) > 0)
			optiMode = Opti_GlobalLocal;
		ret = DBA_ReadOpti(procedure, optiMode, 
		                   dimChronoPtr, instrChronoPtr, NULLDYNSTPTR,
                           &posIndexLocal, &posIndexGlobal);

		/* REF3725 - Did it previously fail ? */
		if (IS_NULLFLD(instrChronoPtr, A_InstrChrono_Val) == TRUE)
		{
		    ret = GET_INT(instrChronoPtr, A_InstrChrono_RetCd);
		}
	}
	else
	{
		ret = RET_DBA_ERR_PROCNOTFOUND;
	}

	return(ret);
}

/************************************************************************
**
**  Function    :   DBA_SetDimChrono()
**
**  Description :   Given some prerequisite arguments, construct chrono
**                  data, then write them on the optimization buffer.
**                 
**  Arguments   :   instrId       instrument identifier.
**                  refDateTime   pointer on structure datetime.
**                  validPeriod   validity period.
**                  chronoNat     chrono nature (CHRONONAT_ENUM).
**                  validDateTime validity date.
**                  currentId     current instrument identifier.
**                  value         current value.
**                  msgFlag       error flag.
**                  msgCode       error code.
**                  msgTxt        message text.
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   (14/11/1996), DVP248 GRD.
**  Modif.	:   REF1065 - RAK - 971212
**
*************************************************************************/
RET_CODE DBA_SetDimChrono(ID_T           instrId, 
	                      DATETIME_ST    refDateTime, 
			              NUMBER_T       validPeriod,
			              FLAG_T	     isNullValidPeriodFlag, /* TRUE if validPeriod NULL */
                          ID_T           thirdId,               /* REF10598 - LJE - 041011 */
	                      CHRONONAT_ENUM chronoNat,             
                          ID_T           subNatTypeId,          /* REF10598 - LJE - 041011 */
			              ID_T           currencyId,
			              NUMBER_T	     value,
			              int		     msgCode,
			              char		    *msgTxt)
{
	DBA_PROC_STP	  procedure=(DBA_PROC_STP)NULL;
	DBA_DYNFLD_STP	  dimChronoPtr=NULLDYNST;
	DBA_DYNFLD_STP	  instrChronoPtr=NULLDYNST;
	DBA_OPTIMODE_ENUM optiMode; 
	RET_CODE	      ret = RET_SUCCEED;
	ID_T              domainQuoteValRuleId = 0;
	DBA_DYNFLD_STP    domainPtr=NULLDYNST;

	if ((instrChronoPtr = ALLOC_DYNST(A_InstrChrono)) == NULLDYNST)
		MSG_RETURN(RET_MEM_ERR_ALLOC);

	if ((dimChronoPtr = ALLOC_DYNST(Dim_InstrChrono)) == NULLDYNST)
	{
		FREE_DYNST(instrChronoPtr, A_InstrChrono);
		MSG_RETURN(RET_MEM_ERR_ALLOC);
	}

	SET_ID(dimChronoPtr,       Dim_InstrChrono_InstrId,     instrId);
	SET_DATETIME(dimChronoPtr, Dim_InstrChrono_RefDate,     refDateTime);
	SET_ENUM(dimChronoPtr,     Dim_InstrChrono_NatEn,       chronoNat);
	SET_ID(dimChronoPtr,       Dim_InstrChrono_ThirdPartyId,thirdId);      /* REF10598 - LJE - 041011 */

	/* PMSTA14879 - DDV - 120920 - Add domain's valuation rule as criteria for cache usage */
	if ((domainPtr = DBA_GetDomainPtr(NO_VALUE)) != NULLDYNST &&
		(domainQuoteValRuleId = GET_ID(domainPtr, A_Domain_QuoteValRuleId)) != 0)
	{
		SET_ID(dimChronoPtr, Dim_InstrChrono_DomQuoteValRuleId, domainQuoteValRuleId);
	}

	if (isNullValidPeriodFlag == FALSE)
		SET_NUMBER(dimChronoPtr, Dim_InstrChrono_ValidPeriod, validPeriod);

	if (msgCode == 0)
	{
		SET_ID(instrChronoPtr,       A_InstrChrono_InstrId,     instrId);
		SET_ENUM(instrChronoPtr,     A_InstrChrono_NatEn,       chronoNat);
		SET_DATETIME(instrChronoPtr, A_InstrChrono_ValidDate,   refDateTime);
    	SET_ID(instrChronoPtr,       A_InstrChrono_ThirdPartyId,thirdId);      /* REF10598 - LJE - 041011 */
    	SET_ID(instrChronoPtr,       A_InstrChrono_SubNatTypeId,subNatTypeId); /* REF10598 - LJE - 041011 */
		SET_ID(instrChronoPtr,       A_InstrChrono_CurrId,      currencyId);
		SET_LONGAMOUNT(instrChronoPtr,   A_InstrChrono_Val,         value);    /* REF11704 - TGU - 060419 - Change datatype */
	}
	else
	{
		SET_INT(instrChronoPtr,   A_InstrChrono_RetCd, msgCode);
	}

	if ((procedure = DBA_GetStoredProcs(Get, InstrChrono, UNUSED, Dim_InstrChrono,
						dimChronoPtr, A_InstrChrono)) != NULL)
	{
		/* REF1065 - Don't write in global memory negativ identifier */
		optiMode = Opti_Local;
		if (instrId > 0)
			optiMode = Opti_GlobalLocal;

		DBA_WriteOpti(procedure, optiMode, dimChronoPtr, instrChronoPtr, TRUE, -1, -1);
	}
	else
	{
		ret = RET_DBA_ERR_PROCNOTFOUND;
	}

	FREE_DYNST(instrChronoPtr, A_InstrChrono);
	FREE_DYNST(dimChronoPtr, Dim_InstrChrono);
	return(ret);
}

/************************************************************************
**
**  Function    :   DBA_GetInstrChrono()
**
**  Description :   Get instrument chronological record according to 
**                  received nature
**                 
**  Arguments   :   instrId      instrument identifier
**                  dateTime     pointer on structure datetime
**                  chronoNat    chrono nature (CHRONONAT_ENUM)
**                  timeDim      time dimension (Next, Current, Last)
**                  validFlg     validity period test flag
**                  chronoPtr    pointer on dynamic structure pointer to fill
**
**  Return      :   RET_SUCCEED or error code
**
*************************************************************************/
RET_CODE DBA_GetInstrChrono(ID_T           instrId, 
	                        DATETIME_T     dateTime,
	                        CHRONONAT_ENUM chronoNat,
                            ID_T           thirdId,    /* REF10598 - LJE - 041011 */
		                    TIMEDIM_ENUM   timeDim,
		                    FLAG_T         validFlg,
	                        DBA_DYNFLD_STP chronoPtr) 
{
	DBA_DYNFLD_STP  dimChrono=NULLDYNST, instrPtr=NULLDYNST;
    RET_CODE        ret=RET_SUCCEED;

	if (chronoPtr == NULLDYNST)
	{
	   MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, 
			"DBA_GetInstrChrono", "chrono pointer");
	   return(RET_GEN_ERR_INVARG);
	}
		
    /* REF1055 - S_InstrChrono -> Dim_InstrChrono */
	if ((dimChrono = ALLOC_DYNST(Dim_InstrChrono)) == NULLDYNST)
		MSG_RETURN(RET_MEM_ERR_ALLOC);

    /* REF1055 - RAK - 000407 */
	/* if (DBA_Get2(InstrChrono, UNUSED, Dim_InstrChrono, 
		         dimChrono, A_InstrChrono, &chronoPtr,
	             UNUSED, UNUSED, UNUSED) != RET_SUCCEED)
	{
		FREE_DYNST(dimChrono, Dim_InstrChrono);
		return(RET_DBA_ERR_NODATA);
	}*/

    if (ret == RET_SUCCEED)
    {
	    SET_ID(dimChrono,       Dim_InstrChrono_InstrId,     instrId);
	    SET_DATETIME(dimChrono, Dim_InstrChrono_RefDate,     dateTime);
	    SET_ID(dimChrono,       Dim_InstrChrono_ThirdPartyId,thirdId); /* REF10598 - LJE - 041011 */
	    SET_ENUM(dimChrono,     Dim_InstrChrono_NatEn,       (ENUM_T)chronoNat);
        SET_FLAG(dimChrono,     Dim_InstrChrono_ComputeFlg,  FALSE);

	    ret = FIN_InstrChrono(dimChrono, instrPtr, chronoPtr, NULL);
    }


	FREE_DYNST(dimChrono, Dim_InstrChrono);
	return(ret);
}

/************************************************************************
**
**  Function    :   DBA_GetCurrChrono()
**
**  Description :   Get a chronological record according to received nature
**                 
**  Arguments   :   instrId      instrument identifier
**                  dateTime     pointer on structure datetime
**                  chronoNat    chrono nature (CHRONONAT_ENUM)
**                  timeDim      time dimension (Next, Current, Last)
**                  validFlg     validity period test flag
**                  chronoPtr    pointer on dynamic structure pointer to fill
**
**  Return      :   RET_SUCCEED or error code
**
*************************************************************************/
RET_CODE DBA_GetCurrChrono(ID_T               currId, 
                           ID_T               underId,
	                       DATETIME_T         dateTime, 
	                       CURRCHRONONAT_ENUM chronoNat,              
		                   TIMEDIM_ENUM       timeDim,
		                   FLAG_T             validFlg,
	                       DBA_DYNFLD_STP     chronoPtr) 
{
	DBA_DYNFLD_STP getChrono=NULLDYNST;

	if (chronoPtr == NULLDYNST)
	{
	   MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, 
			"DBA_GetCurrChrono", "chrono pointer");
	   return(RET_GEN_ERR_INVARG);
	}
		
	if ((getChrono = ALLOC_DYNST(A_CurrChrono)) == NULLDYNST)
		MSG_RETURN(RET_MEM_ERR_ALLOC);

	SET_ID(getChrono,       A_CurrChrono_CurrId,      currId);
	SET_ID(getChrono,       A_CurrChrono_UnderCurrId, underId);
	SET_DATETIME(getChrono, A_CurrChrono_Date,        dateTime);
	SET_ENUM(getChrono,     A_CurrChrono_NatEn,       (ENUM_T)chronoNat);
	SET_ENUM(getChrono,     A_CurrChrono_TimeDimEn,   (ENUM_T)timeDim);
	SET_FLAG(getChrono,     A_CurrChrono_ValidFlg,    (FLAG_T)validFlg);

	if (DBA_Get2(CurrChrono, UNUSED, A_CurrChrono, 
		    getChrono, A_CurrChrono, &chronoPtr,
	            UNUSED, UNUSED, UNUSED) != RET_SUCCEED)
	{
		/*
		SYSNAME_T entSqlName;
		strcpy(entSqlName, DBA_GetDictEntitySqlName(CurrChrono));
		MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO, 
			     entSqlName, currId);
		*/
		FREE_DYNST(getChrono, A_CurrChrono);
		return(RET_DBA_ERR_NODATA);
	}

	FREE_DYNST(getChrono, A_CurrChrono);

	return(RET_SUCCEED);
}

/************************************************************************
*
*  Function          : DBA_GetCurrChronoFromHier()
*
*  Description       : Get currency chronological data according to a currency id,
*                      a time dimension (cf TIMEDIM_ENUM), a nature (cf CHRONONAT_ENUM),
*                      a date, an underlying currency id, and an optional validity flag.
*                      this function gives the same result as DBA_GetCurrChrono, but is optimised
*                      specially when used in DisplayChrono or Return  (financial functions
*                      with domain period divided in subperiods)                      
*
*  Arguments         : currId        : currency id
*                      underlyCurrId : underlying currency id  
*                      datetime     : date  
*                      chronoNat    : nature of chrono data of interest
*                      timeDim      : time dimension (CURRENT, NEXT, TODAY)
*                      validFlg     : [optional]
*                                     if TRUE, only valid port_chrono must be retrieved
*                                     (validity depends on the validity period parameter system) 
*                      hierHead     : pointer on hierarchy
*                      chronoPtr    : pointer on the result dyn. struct
*
*
*  Return            : RET_SUCCEED
*                      RET_GEN_ERR_INVARG : if problem with input arguments
*                      RET_MEM_ERR_ALLOC  : if memory allocation failed
*                      RET_DBA_ERR_NODATA : if no data
*
*  Creation date     : 000314 - REF4306 - CSY
*  Last modification : 010122 - REF5609 - CSY
*
*************************************************************************/
RET_CODE DBA_GetCurrChronoFromHier(ID_T               currId, 
                                   ID_T               underlyCurrId,
	                               DATETIME_T         dateTime, 
	                               CURRCHRONONAT_ENUM chronoNat,              
		                           TIMEDIM_ENUM       timeDim,
		                           FLAG_T             validFlg,
                                   DBA_DYNFLD_STP     domainPtr,
                                   DBA_HIER_HEAD_STP  hierHead,
	                               DBA_DYNFLD_STP     chronoPtr) 
{
    
    DBA_DYNFLD_STP  *currChronoTab = NULLDYNSTPTR;
    DBA_DYNFLD_STP  *selCurrChronoTab = NULLDYNSTPTR;
    DBA_DYNFLD_STP  chronoArgSt=NULLDYNST;
    DBA_DYNFLD_STP  noChronoPtr=NULLDYNST;
    int			indexFld;
    int         currChronoNbr = 0;
    int         selCurrChronoNbr = 0;
    int         i = 0;
    int         iChrono = -1;
	DBA_DYNFLD_ST	indexDynSt;
    /* DBA_DYNFLD_ST	natureSt; */
    INT_T           validityPeriod = 0; /* REF4306 - CSY - 000324 */
    DATETIME_T      tmpDate;
    DATETIME_T      magicEndDateTime;
    FLAG_T          stopFlg = FALSE;
    RET_CODE        ret = RET_SUCCEED;

    magicEndDateTime.date = 0;
    magicEndDateTime.time = 0;
    memset(&indexDynSt, 0,   sizeof(DBA_DYNFLD_ST));

    if (chronoPtr == NULLDYNST)
	{
	   MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, 
			"DBA_GetCurrChronoFromHier", "chrono pointer");
	   return(RET_GEN_ERR_INVARG);
	}

    /* set the index key on CurrId for the extract */
    indexFld = A_CurrChrono_CurrId;
	SET_ID((&indexDynSt), 0, currId);

    /* allocate a structure that will contain selection criterias */
    if ((chronoArgSt = ALLOC_DYNST(Chrono_Arg)) == NULLDYNST)
    {
		return(RET_MEM_ERR_ALLOC);
    }

    /* set the criteria on nature for filter function used in the extract */ 
    /*SET_ENUM((&natureSt), 0, (ENUM_T)chronoNat);*/
    SET_ENUM(chronoArgSt, Chrono_Arg_NatEn, (ENUM_T)chronoNat);
    SET_ID(chronoArgSt, Chrono_Arg_InstrId, (ID_T)currId);   /* REF5609 - CSY - 010122 */


	/* first try to extract the requested curr_chono from hierarchy */
    if ((ret = DBA_ExtractHierEltRecByIndexKey(hierHead, A_CurrChrono, 
                                                           	 indexFld, indexDynSt, FALSE, 
								 DBA_FilterNatureCurrChrono,
                                 /* &natureSt,*/ chronoArgSt,
						                     NULLFCT, FALSE,
			                                             &currChronoNbr, &currChronoTab)) != RET_SUCCEED) 
    {
		   FREE(currChronoTab); 
           return(ret);
    }

    /* if not found in hierarchy */
    if (currChronoNbr == 0)
    {
        FREE(currChronoTab);

        /* set criterias */
        SET_ID(chronoArgSt, Chrono_Arg_InstrId, currId);
        SET_ENUM(chronoArgSt, Chrono_Arg_NatEn, chronoNat);
        SET_DATETIME(chronoArgSt, Chrono_Arg_BegDate, 
            GET_DATETIME(domainPtr, A_Domain_InterpFromDate));
        SET_DATETIME(chronoArgSt, Chrono_Arg_EndDate,
            GET_DATETIME(domainPtr, A_Domain_InterpTillDate));
        SET_ID(chronoArgSt, Chrono_Arg_CurrId, underlyCurrId);
        SET_ENUM(chronoArgSt, Chrono_Arg_TimeDimEn, timeDim);
        SET_FLAG(chronoArgSt, Chrono_Arg_ValidityFlg, validFlg);
        
        /* do a big select to retrieve A_CurrChrono by Curr and by nature */
        if ((ret = DBA_Select2(CurrChrono, UNUSED, Chrono_Arg, chronoArgSt,
                A_CurrChrono, &selCurrChronoTab, UNUSED, UNUSED,
                &selCurrChronoNbr, UNUSED, UNUSED))!= RET_SUCCEED)
        {
            FREE_DYNST(chronoArgSt, Chrono_Arg);
            FREE(selCurrChronoTab);
            return(ret);
        }


        if (selCurrChronoNbr == 0)
        {
            if ((noChronoPtr = ALLOC_DYNST(A_CurrChrono)) == NULLDYNST)
            {
                FREE(selCurrChronoTab);
		        return(RET_MEM_ERR_ALLOC);
            }
            SET_ID(noChronoPtr, A_CurrChrono_CurrId, currId);
            SET_ENUM(noChronoPtr, A_CurrChrono_NatEn, chronoNat);
            magicEndDateTime.date = MAGIC_END_DATE;
            SET_DATETIME(noChronoPtr, A_CurrChrono_Date, magicEndDateTime);
            DBA_AddHierRecord(hierHead, noChronoPtr, A_CurrChrono, FALSE, HierAddRec_NoLnk);
            FREE(selCurrChronoTab);
            return(RET_DBA_ERR_NODATA);
        }
        
        /* add the result of the select in hierarchy */
        /* sort is done on index while adding */
        DBA_AddHierRecordList(hierHead, selCurrChronoTab, selCurrChronoNbr, A_CurrChrono, TRUE);

        /* second try to extract from hierarchy */
        if ((ret = DBA_ExtractHierEltRecByIndexKey(hierHead, A_CurrChrono, 
                                                           	 indexFld, indexDynSt, FALSE, 
								            DBA_FilterNatureCurrChrono,
                                            /* &natureSt, */   chronoArgSt, /* REF5609 - CSY - 010122 */
						                     NULLFCT, FALSE,
			                                             &currChronoNbr, &currChronoTab)) != RET_SUCCEED) 
        {   
            FREE(currChronoTab);
            FREE(selCurrChronoTab);
            return(ret);
        }
        FREE(selCurrChronoTab);

    }

    FREE_DYNST(chronoArgSt, Chrono_Arg);
    
    tmpDate.date = dateTime.date; /* init. to avoid warnings */
    tmpDate.time = dateTime.time; /* init. to avoid warnings */
    if (validFlg == TRUE)
    {
        GEN_GetApplInfo(ApplCurrChronoValPeriod, &validityPeriod);
        /* tmpDate = dateTime - validityPeriod 
            dateTime = the argument date given in the script */
        tmpDate.date = DATE_Move(dateTime.date, (-1)*(validityPeriod), Day);
        tmpDate.time = dateTime.time;
    }

    /* process to retrieve the relevant curr_chrono among currChronoTab */
    /* manage the LAST/CURRENT/PREVIOUS */ 
    switch (timeDim)
    {
    case TimeDim_Last:
        for(i=currChronoNbr-1; i >= 0 && stopFlg == FALSE; i--)
        {
            /* curr_chrono are sorted by ascending dates */                      
            if (DATETIME_CMP(
                    GET_DATETIME(currChronoTab[i], A_CurrChrono_Date),
                    dateTime) <= 0)
            {
                if (GET_ID(currChronoTab[i], A_CurrChrono_UnderCurrId) == underlyCurrId)
                {
                    if (validFlg == FALSE)
                    {
                        iChrono = i;
                        stopFlg = TRUE;
                    }
                    else if(DATETIME_CMP(
                                GET_DATETIME(currChronoTab[i], A_CurrChrono_Date),
                                tmpDate) > 0 &&
                        DATETIME_CMP(
                                GET_DATETIME(currChronoTab[i], A_CurrChrono_Date),
                                dateTime) <= 0)
                    {
                        iChrono = i;
                        stopFlg = TRUE;
                    } 
                }
            }
        }
        break;
    case TimeDim_Crt:
        for(i=0; i < currChronoNbr && stopFlg == FALSE; i++)
        {
            if (DATETIME_CMP(
                    GET_DATETIME(currChronoTab[i], A_CurrChrono_Date),
                    dateTime) == 0 && GET_ID(currChronoTab[i], A_CurrChrono_UnderCurrId) == underlyCurrId)
            {
                iChrono = i;
                stopFlg = TRUE;
            }
        }
        break;
    case TimeDim_Next:
        /*  curr_chrono are sorted by ascending dates */
        for(i=0; i < currChronoNbr && stopFlg == FALSE; i++)
        {
            if ((DATETIME_CMP(
                    GET_DATETIME(currChronoTab[i], A_CurrChrono_Date),
                    dateTime) > 0) && 
                    (GET_ID(currChronoTab[i], A_CurrChrono_UnderCurrId) == underlyCurrId))
            {
                iChrono = i;
                stopFlg = TRUE;
            }
        }
        break;
    }        

    if (stopFlg == TRUE)
        COPY_DYNST(chronoPtr, currChronoTab[iChrono], A_CurrChrono);

    FREE(currChronoTab);

    return(RET_SUCCEED);
}

/************************************************************************
*
*  Function          : DBA_FilterNatureCurrChrono()  filter function used 
*                      in script CURR_CHRONO
*
*  Description       : This function filters records by nature
*
*  Arguments         : dynSt   :      current record (A_CurrChrono)
*                      dynStTp :      current record type
*                      argIn   :      input argument containing search criteria
*
*  Return            : TRUE/FALSE
*
*  Creation date     : 000315 - CSY - REF4263
*  Last modification : 010122 - CSY - REF5609
*
*************************************************************************/
STATIC int DBA_FilterNatureCurrChrono(DBA_DYNFLD_STP dynSt, 
		                 		        DBA_DYNST_ENUM dynStTp, 
		                 		        DBA_DYNFLD_STP argIn)
{
    /* compare the nature of the current record with the nature given (in argIn) */
	/*if (GET_ENUM(argIn,0) == GET_ENUM(dynSt, A_CurrChrono_NatEn)) */
    if (GET_ENUM(argIn, Chrono_Arg_NatEn) == GET_ENUM(dynSt, A_CurrChrono_NatEn)
        && GET_ID(argIn, Chrono_Arg_InstrId) == GET_ID(dynSt, A_CurrChrono_CurrId))
        return TRUE;
    else
        return FALSE;
}

/************************************************************************
*
*  Function          : DBA_GetPortChrono()
*
*  Description       : Get portfolio chronological data according to a time position
*                      (cf TIMEDIM_ENUM), a nature (cf CHRONONAT_ENUM), a currency
*                       and a date.
*
*  Arguments         : ptfId        : portfolio id
*                      currId       : currency id  
*                      datetime     : date  
*                      chronoNat    : nature of chrono data of interest
*                      timeDim      : time dimension (CURRENT, NEXT, TODAY)
*                      validFlg     : 
*                      chronoPtr    : pointer on the result dyn. struct
*
*
*  Return            : RET_SUCCEED
*                      RET_GEN_ERR_INVARG : if problem with input arguments
*                      RET_MEM_ERR_ALLOC  : if memory allocation failed
*                      RET_DBA_ERR_NODATA : if no data
*
*  Creation date     : 23.11.95 - PEC
*  Last modification : REF4306 - CSY - 000314: management of the validFlg
*
*************************************************************************/
RET_CODE DBA_GetPortChrono(ID_T               ptfId, 
                           ID_T               currId,
	                   DATETIME_T         dateTime, 
	                   PTFCHRONONAT_ENUM  chronoNat,              
		           TIMEDIM_ENUM       timeDim,
		           FLAG_T               validFlg, 
	                   DBA_DYNFLD_STP     chronoPtr) 
{
	DBA_DYNFLD_STP getChrono=NULLDYNST;

	if (chronoPtr == NULLDYNST)
	{
	   MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, 
			"DBA_GetPortChrono", "chrono pointer");
	   return(RET_GEN_ERR_INVARG);
	}
		
	if ((getChrono = ALLOC_DYNST(A_PtfChrono)) == NULLDYNST)
		MSG_RETURN(RET_MEM_ERR_ALLOC);

	SET_ID(getChrono,       A_PtfChrono_PtfId,       ptfId);
    /* REF4306 - DDV - 000307 */
    if (currId > 0)
	    SET_ID(getChrono,       A_PtfChrono_CurrId,      currId);
	SET_DATETIME(getChrono, A_PtfChrono_ValidDate,   dateTime);
	SET_ENUM(getChrono,     A_PtfChrono_NatEn,       (ENUM_T)chronoNat);
	SET_ENUM(getChrono,     A_PtfChrono_TimeDimEn,   (ENUM_T)timeDim);
	SET_FLAG(getChrono,     A_PtfChrono_ValidFlg,    (FLAG_T)validFlg);

	if (DBA_Get2(PtfChrono, UNUSED, A_PtfChrono, 
		    getChrono, A_PtfChrono, &chronoPtr,
	            UNUSED, UNUSED, UNUSED) != RET_SUCCEED)
	{
		/*
		SYSNAME_T entSqlName;
		strcpy(entSqlName, DBA_GetDictEntitySqlName(PtfChrono));
		MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO, 
			     entSqlName, ptfId);
		*/
		FREE_DYNST(getChrono, A_PtfChrono);
		return(RET_DBA_ERR_NODATA);
	}

	FREE_DYNST(getChrono, A_PtfChrono);

	return(RET_SUCCEED);
}

/************************************************************************
*
*  Function          : DBA_GetPortChronoFromHier()
*
*  Description       : Get portfolio chronological data according to a portfolio id,
*                      a time dimension (cf TIMEDIM_ENUM), a nature (cf CHRONONAT_ENUM),
*                      a date, a currency, and an optional validity flag.
*                      this function gives the same result as DBA_GetPortChrono, but is optimised
*                      specially when used in DisplayChrono or Return  (financial functions
*                      with domain period divided in subperiods)                      
*
*  Arguments         : ptfId        : portfolio id
*                      currId       : currency id  
*                      datetime     : date  
*                      chronoNat    : nature of chrono data of interest
*                      timeDim      : time dimension (CURRENT, NEXT, TODAY)
*                      validFlg     : [optional]
*                                     if TRUE, only valid port_chrono must be retrieved
*                                     (validity depends on the validity period parameter system) 
*                      hierHead     : pointer on hierarchy
*                      chronoPtr    : pointer on the result dyn. struct
*
*
*  Return            : RET_SUCCEED
*                      RET_GEN_ERR_INVARG : if problem with input arguments
*                      RET_MEM_ERR_ALLOC  : if memory allocation failed
*                      RET_DBA_ERR_NODATA : if no data
*
*  Creation date     : 000314 - REF4306 - CSY
*  Last modification : 010123 - REF5609 - CSY
*
*************************************************************************/
RET_CODE DBA_GetPortChronoFromHier(ID_T               ptfId, 
                           ID_T               currId,
	                       DATETIME_T         dateTime, 
	                       PTFCHRONONAT_ENUM  chronoNat,              
		                   TIMEDIM_ENUM       timeDim,
		                   FLAG_T             validFlg,
                           DBA_DYNFLD_STP     domainPtr,
                           DBA_HIER_HEAD_STP  hierHead,
	                       DBA_DYNFLD_STP     chronoPtr) 
{
    /* REF4306 - CSY - 000309 */
    DBA_DYNFLD_STP  *ptfChronoTab = NULLDYNSTPTR;
    DBA_DYNFLD_STP  *selPtfChronoTab = NULLDYNSTPTR;
    DBA_DYNFLD_STP  chronoArgSt=NULLDYNST;
    DBA_DYNFLD_STP  noChronoPtr=NULLDYNST;
    int             ptfChronoNbr = 0;
    int             selPtfChronoNbr = 0;
    int			    indexFld;
    int             i = 0;
	DBA_DYNFLD_ST	indexDynSt;
    /* DBA_DYNFLD_ST	natureSt; */
    int             validityPeriod = 0; /* REF4306 - CSY - 000324 */
    int             iChrono = -1;
    DATETIME_T      tmpDate;
    DATETIME_T      magicEndDateTime;
    FLAG_T          stopFlg;
    RET_CODE        ret = RET_SUCCEED;
    magicEndDateTime.date = 0;
    magicEndDateTime.time = 0;
    memset(&indexDynSt, 0,   sizeof(DBA_DYNFLD_ST));
    stopFlg = FALSE;

    if (chronoPtr == NULLDYNST)
	{
	   MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, 
			"DBA_GetPortChronoFromHier", "chrono pointer");
	   return(RET_GEN_ERR_INVARG);
	}

    /* set the index key on PtfId for the extract */
    indexFld = A_PtfChrono_PtfId;
	SET_ID((&indexDynSt), 0, ptfId);
    /* set the criteria on nature for filter function used in the extract */ 
    /*SET_ENUM((&natureSt), 0, (ENUM_T)chronoNat);*/

    /* REF5609 - CSY - 010122 same variable
    used both for select criteria and extract criteria */
    if ((chronoArgSt = ALLOC_DYNST(Chrono_Arg)) == NULLDYNST)
    {
		return(RET_MEM_ERR_ALLOC);
    }

    SET_ENUM(chronoArgSt, Chrono_Arg_NatEn, (ENUM_T)chronoNat);
    if (currId > 0)
        SET_ID(chronoArgSt, Chrono_Arg_CurrId, currId);

	/* first try to extract the requested port_chono from hierarchy */
    if ((ret = DBA_ExtractHierEltRecByIndexKey(hierHead, A_PtfChrono, 
                                                           	 indexFld, indexDynSt, FALSE, 
								 DBA_FilterNaturePtfChrono,
                                 /* &natureSt */ chronoArgSt, /* REF5609 - CSY - 010122 */
						                     NULLFCT, FALSE,
			                                             &ptfChronoNbr, &ptfChronoTab)) != RET_SUCCEED) 
    {
            FREE_DYNST(chronoArgSt, A_PtfChrono);/* REF5609 - CSY - 010122 */
            FREE(ptfChronoTab);
		    return(ret);
    }


    /* if not found in hierarchy */
    if (ptfChronoNbr == 0)
    {

        FREE(ptfChronoTab);

        /* allocate a structure that will contain selection criterias */
        /* REF5609 - CSY - 010122: shifted above
        if ((chronoArgSt = ALLOC_DYNST(Chrono_Arg)) == NULLDYNST)
        {
		    return(RET_MEM_ERR_ALLOC);
        }*/

        /* set criterias */
        SET_ID(chronoArgSt, Chrono_Arg_InstrId, ptfId);
        SET_ENUM(chronoArgSt, Chrono_Arg_NatEn, chronoNat);
        SET_DATETIME(chronoArgSt, Chrono_Arg_BegDate, 
            GET_DATETIME(domainPtr, A_Domain_InterpFromDate));
        SET_DATETIME(chronoArgSt, Chrono_Arg_EndDate,
            GET_DATETIME(domainPtr, A_Domain_InterpTillDate));
        if (currId > 0)
            SET_ID(chronoArgSt, Chrono_Arg_CurrId, currId);

        /* REF5609 - CSY - 010122:useless now
        SET_ENUM(chronoArgSt, Chrono_Arg_TimeDimEn, timeDim);   
        SET_FLAG(chronoArgSt, Chrono_Arg_ValidityFlg, validFlg); */
        
        /* do a big select to retrieve A_PtfChrono by Ptf and by nature */
        if ((ret = DBA_Select2(PtfChrono, UNUSED, Chrono_Arg, chronoArgSt,
                A_PtfChrono, &selPtfChronoTab, UNUSED, UNUSED,
                &selPtfChronoNbr, UNUSED, UNUSED))!= RET_SUCCEED)
        {
            FREE_DYNST(chronoArgSt, Chrono_Arg);
            FREE(selPtfChronoTab);
            return(ret);
        }

        /* FREE_DYNST(chronoArgSt, Chrono_Arg); REF5609: shifted below */
        
        if (selPtfChronoNbr == 0)
        {
            if ((noChronoPtr = ALLOC_DYNST(A_PtfChrono)) == NULLDYNST)
            {
                FREE(selPtfChronoTab);
		        return(RET_MEM_ERR_ALLOC);
            }
            SET_ID(noChronoPtr, A_PtfChrono_PtfId, ptfId);
            SET_ENUM(noChronoPtr, A_PtfChrono_NatEn, chronoNat);
            magicEndDateTime.date = MAGIC_END_DATE;
            SET_DATETIME(noChronoPtr, A_PtfChrono_ValidDate, magicEndDateTime);
            DBA_AddHierRecord(hierHead, noChronoPtr, A_PtfChrono, FALSE, HierAddRec_NoLnk);
            FREE(selPtfChronoTab);
            return(RET_DBA_ERR_NODATA);
        }

        /* add the result of the select in hierarchy */
        /* sort is done on index while adding */
        DBA_AddHierRecordList(hierHead, selPtfChronoTab, selPtfChronoNbr, A_PtfChrono, TRUE);

        /* second try to extract from hierarchy */
        if ((ret = DBA_ExtractHierEltRecByIndexKey(hierHead, A_PtfChrono, 
                                                           	 indexFld, indexDynSt, FALSE, 
								 DBA_FilterNaturePtfChrono,
                                 /* &natureSt ,*/   chronoArgSt, /* REF5609 - CSY - 010122 */
						                     NULLFCT, FALSE,
			                                             &ptfChronoNbr, &ptfChronoTab)) != RET_SUCCEED) 
        {
            FREE(selPtfChronoTab);
            FREE(ptfChronoTab);
		    return(ret);
        }

        FREE(selPtfChronoTab);

    }

    FREE_DYNST(chronoArgSt, Chrono_Arg); /* REF5609 - CSY - 010122 moved here */
    
    tmpDate.date = dateTime.date; /* initialisations to avoid warnings */
    tmpDate.time = dateTime.time; /* initialisations to avoid warnings */
    if (validFlg == TRUE)
    {
        GEN_GetApplInfo(ApplPtfChronoValPeriod, &validityPeriod);
        /* tmpDate = dateTime - validityPeriod 
            dateTime = the argument date given in the script */
        tmpDate.date = DATE_Move(dateTime.date, (-1)*(validityPeriod), Day);
        tmpDate.time = dateTime.time;
    }


    /* process to retrieve the relevant port_chrono among ptfChronoTab */
    /* manage the LAST/CURRENT/PREVIOUS */ 
    switch (timeDim)
    {
    case TimeDim_Last:
        for(i=ptfChronoNbr-1; i >= 0 && stopFlg == FALSE; i--)
        {
            /* port_chrono are sorted by ascending dates */                      
            if (DATETIME_CMP(
                    GET_DATETIME(ptfChronoTab[i], A_PtfChrono_ValidDate),
                    dateTime) <= 0)
            {
                /* REF5700 - DDV - 010220 - Optional currency for PORT_CHRONO */
                if (currId == 0 || GET_ID(ptfChronoTab[i], A_PtfChrono_CurrId) == currId)
                {
                    if (validFlg == FALSE)
                    {
                        iChrono = i;
                        stopFlg = TRUE;
                    }
                    else if(DATETIME_CMP(
                                GET_DATETIME(ptfChronoTab[i], A_PtfChrono_ValidDate),
                                tmpDate) > 0 &&
                        DATETIME_CMP(
                                GET_DATETIME(ptfChronoTab[i], A_PtfChrono_ValidDate),
                                dateTime) <= 0)
                    {
                        iChrono = i;
                        stopFlg = TRUE;
                    } 
                }
            }
        }
        break;
    case TimeDim_Crt:
        for(i=0; i < ptfChronoNbr && stopFlg == FALSE; i++)
        {
            if (DATETIME_CMP(
                    GET_DATETIME(ptfChronoTab[i], A_PtfChrono_ValidDate),
                    dateTime) == 0 && 
                    (currId == 0 || GET_ID(ptfChronoTab[i], A_PtfChrono_CurrId) == currId)) /* REF5700 - DDV - 010220 - Optional currency for PORT_CHRONO */
            {
                iChrono = i;
                stopFlg = TRUE;
            }
        }
        break;
    case TimeDim_Next:
        /*  port_chrono are sorted by ascending dates */
        for(i=0; i < ptfChronoNbr && stopFlg == FALSE; i++)
        {
            if ((DATETIME_CMP(
                    GET_DATETIME(ptfChronoTab[i], A_PtfChrono_ValidDate),
                    dateTime) > 0) && 
                    (currId == 0 || GET_ID(ptfChronoTab[i], A_PtfChrono_CurrId) == currId)) /* REF5700 - DDV - 010220 - Optional currency for PORT_CHRONO */
            {
                iChrono = i;
                stopFlg = TRUE;
            }
        }
        break;
    }        

    if (stopFlg == TRUE)
        COPY_DYNST(chronoPtr, ptfChronoTab[iChrono], A_PtfChrono);

    FREE(ptfChronoTab);

    return(RET_SUCCEED);
}

/************************************************************************
*
*  Function          : DBA_FilterNaturePtfChrono()  filter function used 
*                      in script PORT_CHRONO
*
*  Description       : This function filters records by nature
*
*  Arguments         : dynSt   :      current record (A_PtfChrono)
*                      dynStTp :      current record type
*                      argIn   :      input argument containing search criteria
*
*  Return            : TRUE/FALSE
*
*  Creation date     : 000313 - CSY - REF4263
*  Last modification : 010122 - CSY - REF5609 filter also by currency id
*
*************************************************************************/
STATIC int DBA_FilterNaturePtfChrono(DBA_DYNFLD_STP dynSt, 
		                 		        DBA_DYNST_ENUM dynStTp, 
		                 		        DBA_DYNFLD_STP argIn)
{
    /* compare the nature of the current record with the nature given (in argIn) */
	/* if (GET_ENUM(argIn,0) == GET_ENUM(dynSt, A_PtfChrono_NatEn)) */
    if ((GET_ENUM(argIn, Chrono_Arg_NatEn) == GET_ENUM(dynSt, A_PtfChrono_NatEn)) &&
        (GET_ID(argIn, Chrono_Arg_CurrId) == 0 || /* REF5700 - DDV - 020223 */
         GET_ID(argIn, Chrono_Arg_CurrId) == GET_ID(dynSt, A_PtfChrono_CurrId))) /* REF5609 - CSY - 010122 */
        return TRUE;
    else
        return FALSE;
}

/************************************************************************
*
*  Function          : DBA_GetComplianceChrono()
*
*  Description       : Get compliance chronological data according to a time position
*                      (cf TIMEDIM_ENUM), a nature (cf CHRONONAT_ENUM), a currency
*                       and a date.
*
*  Arguments         : ptfId        : portfolio id
*                      currId       : currency id  
*                      datetime     : date  
*                      chronoNat    : nature of chrono data of interest
*                      timeDim      : time dimension (CURRENT, NEXT, TODAY)
*                      validFlg     : 
*                      chronoPtr    : pointer on the result dyn. struct
*
*
*  Return            : RET_SUCCEED
*                      RET_GEN_ERR_INVARG : if problem with input arguments
*                      RET_MEM_ERR_ALLOC  : if memory allocation failed
*                      RET_DBA_ERR_NODATA : if no data
*
*  Creation date     : PMSTA06646 - LJE - 080613
*  Last modification : 
*
*************************************************************************/
RET_CODE DBA_GetComplianceChrono(DBA_DYNFLD_STP         chronoNeededSt, 
								 TIMEDIM_ENUM           timeDim,
								 FLAG_T                 validFlg, 
								 DBA_DYNFLD_STP         chronoPtr) 
{
    DBA_DYNFLD_STP  *complChronoTab = NULLDYNSTPTR;
    DBA_DYNFLD_STP  chronoArgSt=NULLDYNST;
    int             complChronoNbr = 0;
    int             i = 0;
    int             validityPeriod = 0;
    int             iChrono = -1;
    DATETIME_T      tmpDate;
    FLAG_T          stopFlg;
    RET_CODE        ret = RET_SUCCEED;

    stopFlg = FALSE;

    if (chronoPtr == NULLDYNST)
	{
	   MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, 
			"DBA_GetComplianceChrono", "chrono pointer");
	   return(RET_GEN_ERR_INVARG);
	}

	if ((chronoArgSt = ALLOC_DYNST(Chrono_Arg)) == NULLDYNST)
	{
		return(RET_MEM_ERR_ALLOC);
	}

	/* set criterias */
	COPY_DYNST(chronoArgSt, chronoNeededSt, Chrono_Arg);

	tmpDate = GET_DATETIME(chronoArgSt, Chrono_Arg_BegDate);
	if (validFlg == TRUE)
	{
		GEN_GetApplInfo(ApplComplChronoValPeriod, &validityPeriod);
		tmpDate.date = DATE_Move(tmpDate.date, (-1)*(validityPeriod), Day);
	}
	SET_DATETIME(chronoArgSt, Chrono_Arg_BegDate, tmpDate);

	/* do a big select to retrieve A_ComplChrono by Ptf and by nature */
	if ((ret = DBA_Select2(ComplianceChrono, 
						   UNUSED, 
						   Chrono_Arg,
						   chronoArgSt,
						   A_ComplianceChrono, 
						   &complChronoTab,
						   UNUSED, 
						   UNUSED,
						   &complChronoNbr, 
						   UNUSED, 
						   UNUSED))!= RET_SUCCEED)
	{
		FREE_DYNST(chronoArgSt, Chrono_Arg);
		FREE(complChronoTab);
		return(ret);
	}

	FREE_DYNST(chronoArgSt, Chrono_Arg);

    /* process to retrieve the relevant port_chrono among complChronoTab */
    /* manage the LAST/CURRENT/PREVIOUS */ 
    switch (timeDim)
    {
    case TimeDim_Last:
        for(i=complChronoNbr-1; i >= 0 && stopFlg == FALSE; i--)
        {
            /* compl_chrono are sorted by ascending dates */                      
            if (DATETIME_CMP(
                    GET_DATETIME(complChronoTab[i], A_ComplianceChrono_ValidDate),
                    GET_DATETIME(chronoNeededSt, Chrono_Arg_BegDate)) <= 0)
            {
                if (validFlg == FALSE)
                {
                    iChrono = i;
                    stopFlg = TRUE;
                }
                else if(DATETIME_CMP(
                            GET_DATETIME(complChronoTab[i], A_ComplianceChrono_ValidDate),
                            tmpDate) > 0 &&
                    DATETIME_CMP(
                            GET_DATETIME(complChronoTab[i], A_ComplianceChrono_ValidDate),
                            GET_DATETIME(chronoNeededSt, Chrono_Arg_BegDate)) <= 0)
                {
                    iChrono = i;
                    stopFlg = TRUE;
                } 
            }
        }
        break;
    case TimeDim_Crt:
        for(i=0; i < complChronoNbr && stopFlg == FALSE; i++)
        {
            if (DATETIME_CMP(
                    GET_DATETIME(complChronoTab[i], A_ComplianceChrono_ValidDate),
                    GET_DATETIME(chronoNeededSt, Chrono_Arg_BegDate)) == 0)
            {
                iChrono = i;
                stopFlg = TRUE;
            }
        }
        break;
    case TimeDim_Next:
        /*  port_chrono are sorted by ascending dates */
        for(i=0; i < complChronoNbr && stopFlg == FALSE; i++)
        {
            if ((DATETIME_CMP(
                    GET_DATETIME(complChronoTab[i], A_ComplianceChrono_ValidDate),
                    GET_DATETIME(chronoNeededSt, Chrono_Arg_BegDate)) > 0))
            {
                iChrono = i;
                stopFlg = TRUE;
            }
        }
        break;
    }        

    if (stopFlg == TRUE)
        COPY_DYNST(chronoPtr, complChronoTab[iChrono], A_ComplianceChrono);

    DBA_FreeDynStTab(complChronoTab, complChronoNbr, A_ComplianceChrono);

    return(RET_SUCCEED);
}

/************************************************************************
*
*  Function          : DBA_GetComplianceChronoFromHier()
*
*  Description       : Get compliance chronological data according to a portfolio id,
*                      a time dimension (cf TIMEDIM_ENUM), a nature (cf CHRONONAT_ENUM),
*                      a date, a currency, and an optional validity flag.
*                      this function gives the same result as DBA_GetPortChrono, but is optimised
*                      specially when used in DisplayChrono or Return  (financial functions
*                      with domain period divided in subperiods)                      
*
*  Arguments         : ptfId        : portfolio id
*                      currId       : currency id  
*                      datetime     : date  
*                      chronoNat    : nature of chrono data of interest
*                      timeDim      : time dimension (CURRENT, NEXT, TODAY)
*                      validFlg     : [optional]
*                                     if TRUE, only valid port_chrono must be retrieved
*                                     (validity depends on the validity period parameter system) 
*                      hierHead     : pointer on hierarchy
*                      chronoPtr    : pointer on the result dyn. struct
*
*
*  Return            : RET_SUCCEED
*                      RET_GEN_ERR_INVARG : if problem with input arguments
*                      RET_MEM_ERR_ALLOC  : if memory allocation failed
*                      RET_DBA_ERR_NODATA : if no data
*
*  Creation date     : PMSTA06646 - LJE - 080530
*  Last modification : 
*
*************************************************************************/
RET_CODE DBA_GetComplianceChronoFromHier(DBA_DYNFLD_STP         chronoNeededSt,
									     TIMEDIM_ENUM           timeDim,
									     FLAG_T                 validFlg,
									     DBA_DYNFLD_STP         domainPtr,
									     DBA_HIER_HEAD_STP      hierHead,
									     DBA_DYNFLD_STP         chronoPtr) 
{
    DBA_DYNFLD_STP  *complChronoTab = NULLDYNSTPTR;
    DBA_DYNFLD_STP  *selComplChronoTab = NULLDYNSTPTR;
    DBA_DYNFLD_STP  chronoArgSt=NULLDYNST;
    DBA_DYNFLD_STP  noChronoPtr=NULLDYNST;
    int             complChronoNbr = 0;
    int             selComplChronoNbr = 0;
    int			    indexFld;
    int             i = 0;
    int             validityPeriod = 0;
    int             iChrono = -1;
    DATETIME_T      tmpDate;
    DATETIME_T      magicEndDateTime;
    FLAG_T          stopFlg;
    RET_CODE        ret = RET_SUCCEED;

    magicEndDateTime.date = 0;
    magicEndDateTime.time = 0;
    stopFlg = FALSE;


    if (chronoPtr == NULLDYNST)
	{
	   MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, 
			"DBA_GetComplianceChronoFromHier", "chrono pointer");
	   return(RET_GEN_ERR_INVARG);
	}

    /* set the index key on PtfId for the extract */
    indexFld = Chrono_Arg_InstrId;

	/* first try to extract the requested compliance_chono from hierarchy */
    if ((ret = DBA_ExtractHierEltRecByIndexKey(hierHead, 
											   A_ComplianceChrono, 
                                               indexFld, 
											   chronoNeededSt[indexFld], 
											   FALSE, 
											   DBA_FilterNatureComplChrono,
											   chronoNeededSt,
											   NULLFCT, 
											   FALSE,
			                                   &complChronoNbr, 
											   &complChronoTab)) != RET_SUCCEED) 
    {
        FREE(complChronoTab);
		return(ret);
    }

    /* if not found in hierarchy */
    if (complChronoNbr == 0)
    {
        FREE(complChronoTab);

		if ((chronoArgSt = ALLOC_DYNST(Chrono_Arg)) == NULLDYNST)
		{
			return(RET_MEM_ERR_ALLOC);
		}

        /* set criterias */
		COPY_DYNST(chronoArgSt, chronoNeededSt, Chrono_Arg);

		SET_DATETIME(chronoArgSt, Chrono_Arg_BegDate, 
			GET_DATETIME(domainPtr, A_Domain_InterpFromDate));
		SET_DATETIME(chronoArgSt, Chrono_Arg_EndDate,
			GET_DATETIME(domainPtr, A_Domain_InterpTillDate));

		tmpDate = GET_DATETIME(chronoArgSt, Chrono_Arg_BegDate);
		if (validFlg == TRUE)
		{
			GEN_GetApplInfo(ApplComplChronoValPeriod, &validityPeriod);
			tmpDate.date = DATE_Move(tmpDate.date, (-1)*(validityPeriod), Day);
		}
		SET_DATETIME(chronoArgSt, Chrono_Arg_BegDate, tmpDate);

        /* do a big select to retrieve A_ComplChrono by Ptf and by nature */
        if ((ret = DBA_Select2(ComplianceChrono, 
							   UNUSED, 
							   Chrono_Arg,
							   chronoArgSt,
							   A_ComplianceChrono, 
							   &selComplChronoTab,
							   UNUSED, 
							   UNUSED,
							   &selComplChronoNbr, 
							   UNUSED, 
							   UNUSED))!= RET_SUCCEED)
        {
            FREE_DYNST(chronoArgSt, Chrono_Arg);
            FREE(selComplChronoTab);
            return(ret);
        }

		FREE_DYNST(chronoArgSt, Chrono_Arg);

        if (selComplChronoNbr == 0)
        {
            if ((noChronoPtr = ALLOC_DYNST(A_ComplianceChrono)) == NULLDYNST)
            {
                FREE(selComplChronoTab);
		        return(RET_MEM_ERR_ALLOC);
            }

			COPY_DYNFLD(noChronoPtr, A_ComplianceChrono, A_ComplianceChrono_PtfId, chronoNeededSt, Chrono_Arg, Chrono_Arg_InstrId);
			COPY_DYNFLD(noChronoPtr, A_ComplianceChrono, A_ComplianceChrono_NatEn, chronoNeededSt, Chrono_Arg, Chrono_Arg_NatEn);
            magicEndDateTime.date = MAGIC_END_DATE;
            SET_DATETIME(noChronoPtr, A_ComplianceChrono_ValidDate, magicEndDateTime);
			DBA_AddHierRecord(hierHead, noChronoPtr, A_ComplianceChrono, FALSE, HierAddRec_NoLnk);
                
            FREE(selComplChronoTab);
            return(RET_DBA_ERR_NODATA);
        }

        /* add the result of the select in hierarchy */
        /* sort is done on index while adding */
		DBA_AddHierRecordList(hierHead, selComplChronoTab, selComplChronoNbr, A_ComplianceChrono, TRUE);

		/* second try to extract from hierarchy */
		if ((ret = DBA_ExtractHierEltRecByIndexKey(hierHead, 
												   A_ComplianceChrono, 
                                                   indexFld,
												   chronoNeededSt[indexFld],
												   FALSE, 
												   DBA_FilterNatureComplChrono,
												   chronoNeededSt,
												   NULLFCT,
												   FALSE,
												   &complChronoNbr, 
												   &complChronoTab)) != RET_SUCCEED) 
		{
			FREE(selComplChronoTab);
			FREE(complChronoTab);
			return(ret);
		}

        FREE(selComplChronoTab);

    }

	tmpDate = GET_DATETIME(chronoNeededSt, Chrono_Arg_BegDate);
	if (validFlg == TRUE)
	{
		GEN_GetApplInfo(ApplComplChronoValPeriod, &validityPeriod);
		tmpDate.date = DATE_Move(tmpDate.date, (-1)*(validityPeriod), Day);
	}

    /* process to retrieve the relevant port_chrono among complChronoTab */
    /* manage the LAST/CURRENT/PREVIOUS */ 
    switch (timeDim)
    {
    case TimeDim_Last:
        for(i=complChronoNbr-1; i >= 0 && stopFlg == FALSE; i--)
        {
            /* compl_chrono are sorted by ascending dates */                      
            if (DATETIME_CMP(
                    GET_DATETIME(complChronoTab[i], A_ComplianceChrono_ValidDate),
                    GET_DATETIME(chronoNeededSt, Chrono_Arg_BegDate)) <= 0)
            {
                if (validFlg == FALSE)
                {
                    iChrono = i;
                    stopFlg = TRUE;
                }
                else if(DATETIME_CMP(
                            GET_DATETIME(complChronoTab[i], A_ComplianceChrono_ValidDate),
                            tmpDate) > 0 &&
                    DATETIME_CMP(
                            GET_DATETIME(complChronoTab[i], A_ComplianceChrono_ValidDate),
                            GET_DATETIME(chronoNeededSt, Chrono_Arg_BegDate)) <= 0)
                {
                    iChrono = i;
                    stopFlg = TRUE;
                } 
            }
        }
        break;
    case TimeDim_Crt:
        for(i=0; i < complChronoNbr && stopFlg == FALSE; i++)
        {
            if (DATETIME_CMP(
                    GET_DATETIME(complChronoTab[i], A_ComplianceChrono_ValidDate),
                    GET_DATETIME(chronoNeededSt, Chrono_Arg_BegDate)) == 0)
            {
                iChrono = i;
                stopFlg = TRUE;
            }
        }
        break;
    case TimeDim_Next:
        /*  port_chrono are sorted by ascending dates */
        for(i=0; i < complChronoNbr && stopFlg == FALSE; i++)
        {
            if ((DATETIME_CMP(
                    GET_DATETIME(complChronoTab[i], A_ComplianceChrono_ValidDate),
                    GET_DATETIME(chronoNeededSt, Chrono_Arg_BegDate)) > 0))
            {
                iChrono = i;
                stopFlg = TRUE;
            }
        }
        break;
    }        

    if (stopFlg == TRUE)
        COPY_DYNST(chronoPtr, complChronoTab[iChrono], A_ComplianceChrono);

    FREE(complChronoTab);

    return(RET_SUCCEED);
}

/************************************************************************
*
*  Function          : DBA_FilterNatureComplChrono()  filter function used 
*                      in script COMPLIANCE_CHRONO
*
*  Description       : This function filters records by nature
*
*  Arguments         : dynSt   :      current record (A_ComplianceChrono)
*                      dynStTp :      current record type
*                      argIn   :      input argument containing search criteria
*
*  Return            : TRUE/FALSE
*
*  Creation date     : PMSTA06646 - LJE - 080530
*  Last modification : 
*
*************************************************************************/
STATIC int DBA_FilterNatureComplChrono(DBA_DYNFLD_STP dynSt, 
		                 		       DBA_DYNST_ENUM dynStTp, 
		                 		       DBA_DYNFLD_STP argIn)
{
    /* compare the nature of the current record with the nature given (in argIn) */
    if (GET_ENUM(argIn, Chrono_Arg_NatEn) == GET_ENUM(dynSt, A_ComplianceChrono_NatEn) &&
        (GET_FLAG(argIn, Chrono_Arg_StratFlg) == FALSE ||
         CMP_DYNFLD(argIn, dynSt, Chrono_Arg_StratId, A_ComplianceChrono_StratId, IdType) == 0) &&
        (IS_NULLFLD(argIn, Chrono_Arg_CurrId) == TRUE ||
         CMP_DYNFLD(argIn, dynSt, Chrono_Arg_CurrId, A_ComplianceChrono_CurrId, IdType) == 0) &&
        (GET_FLAG(argIn, Chrono_Arg_ThirdPartyFlg) == FALSE ||
         CMP_DYNFLD(argIn, dynSt, Chrono_Arg_ThirdPartyId, A_ComplianceChrono_ThirdPartyId, IdType) == 0) &&
        (GET_FLAG(argIn, Chrono_Arg_SubNatFlg) == FALSE ||
         CMP_DYNFLD(argIn, dynSt, Chrono_Arg_SubNatTypeId, A_ComplianceChrono_SubNatTypeId, IdType) == 0) &&
        (IS_NULLFLD(argIn, Chrono_Arg_ComplNatEn) == TRUE ||
         CMP_DYNFLD(argIn, dynSt, Chrono_Arg_ComplNatEn, A_ComplianceChrono_CompNatEn, EnumType) == 0))
		return TRUE;
    else
        return FALSE;
}

/************************************************************************
*
*  Function          : DBA_FilterOptimInstrChrono
*
*  Description       : This function filters records for optim
*
*  Arguments         : dynSt   :      current record (A_InstrChrono)
*                      dynStTp :      current record type
*                      argIn   :      input argument containing search criteria
*
*  Return            : TRUE/FALSE

*  Creation date     : PMSTA-10748 - LJE - 110210
*  Last modification : 
*
*************************************************************************/
STATIC int DBA_FilterOptimInstrChrono(DBA_DYNFLD_STP dynSt, 
		                 		      DBA_DYNST_ENUM dynStTp, 
		                 		      DBA_DYNFLD_STP argIn)
{
    if (IS_NULLFLD(dynSt, A_InstrChrono_NatEn) == TRUE &&
        IS_NULLFLD(dynSt, A_InstrChrono_OptiDate) == FALSE &&
        CMP_DYNFLD(dynSt, argIn, A_InstrChrono_ValidDate, Chrono_Arg_EndDate, DatetimeType) <= 0 &&
        CMP_DYNFLD(dynSt, argIn, A_InstrChrono_OptiDate,  Chrono_Arg_EndDate, DatetimeType) >= 0)
        return TRUE;
    else
        return FALSE;
}

/************************************************************************
**
**  Function    :   DBA_IsInstrChronoOptim()
**
**  Description :   Check if instrument chronological are optimised
**                 
**  Arguments   :   instrId      instrument identifier
**                  begDate      begin date
**                  endDate      end date
**                  chronoNat    chrono nature (CHRONONAT_ENUM)
**
**  Return      :   RET_SUCCEED or error code
**
*************************************************************************/
STATIC FLAG_T DBA_IsInstrChronoOptim(DBA_HIER_HEAD_STP  hierHead,
                                     DBA_DYNFLD_STP     chronoArgSt)
{
    DBA_DYNFLD_STP *instrChronoTab;
    int             instrChronoNbr;

    if (GET_ENUM(chronoArgSt, Chrono_Arg_NatEn) != ChronoNat_ModDura &&
        GET_ENUM(chronoArgSt, Chrono_Arg_NatEn) != ChronoNat_Dura &&
        GET_ENUM(chronoArgSt, Chrono_Arg_NatEn) != ChronoNat_PriceConvFactor)
    {
        return (FALSE);
    }

    if (DBA_ExtractHierEltRecByIndexKey(hierHead, 
                                        A_InstrChrono, 
                                        A_InstrChrono_InstrId, 
                                        chronoArgSt[Chrono_Arg_InstrId], 
                                        FALSE, 
						                DBA_FilterOptimInstrChrono,
                                        chronoArgSt,
				                        NULLFCT, 
                                        FALSE,
	                                    &instrChronoNbr, &instrChronoTab) == RET_SUCCEED &&
        instrChronoNbr > 0) 
    {       
        FREE(instrChronoTab);
		return(TRUE);
    }

    return (FALSE);
}

/************************************************************************
*
*  Function          : DBA_FilterInstrChrono
*
*  Description       : This function filters records for optim
*
*  Arguments         : dynSt   :      current record (A_InstrChrono)
*                      dynStTp :      current record type
*                      argIn   :      input argument containing search criteria
*
*  Return            : TRUE/FALSE

*  Creation date     : PMSTA-10748 - LJE - 110210
*  Last modification : 
*
*************************************************************************/
STATIC int DBA_FilterInstrChrono(DBA_DYNFLD_STP dynSt, 
		              		     DBA_DYNST_ENUM dynStTp, 
		                 		 DBA_DYNFLD_STP argIn)
{
    /* PMSTA-30776 - CHU - 180404
    and (@third_party_flg = 0
           or (@third_party_id is null and ic.third_party_id is null)
           or ic.third_party_id = @third_party_id)
    */

    /*
	and (@sub_nat_flg = 0
           or (@sub_nat_type_id is null and sub_nat_type_id is null)
           or sub_nat_type_id = @sub_nat_type_id)
     */

    if (GET_ENUM(argIn, Chrono_Arg_NatEn) == GET_ENUM(dynSt, A_InstrChrono_NatEn) &&
        IS_NULLFLD(dynSt, A_InstrChrono_OptiDate) == TRUE &&
        (GET_FLAG(argIn, Chrono_Arg_ThirdPartyFlg) == FALSE || /* PMSTA-30776 - CHU - 180404 */
         CMP_DYNFLD(argIn, dynSt, Chrono_Arg_ThirdPartyId, A_InstrChrono_ThirdPartyId, IdType) == 0) &&
        (GET_FLAG(argIn, Chrono_Arg_SubNatFlg) == FALSE ||
         CMP_DYNFLD(argIn, dynSt, Chrono_Arg_SubNatTypeId, Chrono_Arg_SubNatTypeId, IdType) == 0)  &&
        CMP_DYNFLD(argIn, dynSt, Chrono_Arg_BegDate, A_InstrChrono_ValidDate, DatetimeType) <= 0   &&
        CMP_DYNFLD(argIn, dynSt, Chrono_Arg_EndDate, A_InstrChrono_ValidDate, DatetimeType) >= 0)
        return TRUE;
    else
        return FALSE;
}

/************************************************************************
**
**  Function    :   DBA_SelectInstrChronoInHier()
**
**  Description :   Select instrument chronological in hierarchy
**                 
**  Arguments   :   instrId      instrument identifier
**                  begDate      begin date
**                  endDate      end date
**                  chronoNat    chrono nature (CHRONONAT_ENUM)
**
**  Return      :   RET_SUCCEED or error code
**
*************************************************************************/
RET_CODE DBA_SelectInstrChronoInHier(DBA_HIER_HEAD_STP  hierHead,
                                     DBA_DYNFLD_STP     chronoArgSt,
                                     int               *instrChronoNbrPtr,
                                     DBA_DYNFLD_STP   **instrChronoTabPtr)
{
    RET_CODE ret=RET_SUCCEED;

    if (hierHead == NULL ||
        DBA_IsInstrChronoOptim(hierHead, chronoArgSt) == FALSE)
    {
        return (RET_DBA_INFO_NODATAOPTI);
    }

    if ((ret = DBA_ExtractHierEltRecByIndexKey(hierHead, 
                                               A_InstrChrono, 
                                               A_InstrChrono_InstrId, 
                                               chronoArgSt[Chrono_Arg_InstrId], 
                                               TRUE, 
						                       DBA_FilterInstrChrono,
                                               chronoArgSt,
				                               NULLFCT, 
                                               FALSE,
	                                           instrChronoNbrPtr, 
                                               instrChronoTabPtr)) != RET_SUCCEED)
    {       
		return(ret);
    }

    return (ret);
}

/************************************************************************
**
**  Function    :   DBA_GetInstrChronoInHier()
**
**  Description :   Select instrument chronological in hierarchy
**                 
**  Arguments   :   instrId      instrument identifier
**                  begDate      begin date
**                  endDate      end date
**                  chronoNat    chrono nature (CHRONONAT_ENUM)
**
**  Return      :   RET_SUCCEED or error code
**
*************************************************************************/
RET_CODE DBA_GetInstrChronoInHier(DBA_HIER_HEAD_STP  hierHead,
                                  DBA_DYNFLD_STP     inputArgPtr,
                                  DBA_DYNFLD_STP    *instrChronoStpPtr)
{
    RET_CODE           ret=RET_SUCCEED;
    DBA_DYNFLD_STP     chronoArgSt;
    FLAG_T             allocFlg=FALSE;
    DBA_DYNFLD_STP    *instrChronoTab;
    int                instrChronoNbr;

    if (hierHead == NULL ||
        instrChronoStpPtr == NULL)
    {
        return (RET_DBA_INFO_NODATAOPTI);
    }

    if (GET_DYNSTENUM(inputArgPtr) == Dim_InstrChrono)
    {
        DATETIME_T dateTmp = GET_DATETIME(inputArgPtr, Dim_InstrChrono_RefDate);
        int validityPeriod;

        allocFlg=TRUE;
        if ((chronoArgSt = ALLOC_DYNST(Chrono_Arg)) == NULL)
        {
            return (RET_DBA_INFO_NODATAOPTI);
        }
	    SET_ID(chronoArgSt,       Chrono_Arg_InstrId,      GET_ID(inputArgPtr, Dim_InstrChrono_InstrId));
	    SET_ENUM(chronoArgSt,     Chrono_Arg_NatEn,        GET_ENUM(inputArgPtr, Dim_InstrChrono_NatEn));
        SET_ID(chronoArgSt,       Chrono_Arg_ThirdPartyId, GET_ID(inputArgPtr, Dim_InstrChrono_ThirdPartyId));
        SET_DATETIME(chronoArgSt, Chrono_Arg_EndDate,      GET_DATETIME(inputArgPtr, Dim_InstrChrono_RefDate));
        if (IS_NULLFLD(inputArgPtr, Dim_InstrChrono_ValidPeriod) == FALSE)
        {
            validityPeriod = (int)GET_NUMBER(inputArgPtr, Dim_InstrChrono_ValidPeriod);
        }
        else
        {
            if (GET_ENUM(chronoArgSt, Chrono_Arg_NatEn) == ChronoNat_ModDura)
            {
                GEN_GetApplInfo(ApplBondDataValPeriod, &validityPeriod);
            }
            else
            {
                GEN_GetApplInfo(ApplUserDataValPeriod, &validityPeriod);
            }
        }
        
        validityPeriod--;
        dateTmp.date = DATE_Move(dateTmp.date,
                                -validityPeriod,
                                Day);
        SET_DATETIME(chronoArgSt, Chrono_Arg_BegDate,      dateTmp);
    }
    else 
    {
        return (RET_DBA_INFO_NODATAOPTI);
    }

    if (DBA_IsInstrChronoOptim(hierHead, chronoArgSt) == FALSE)
    {
        if (allocFlg == TRUE)
            FREE_DYNST(chronoArgSt, Chrono_Arg);
        return (RET_DBA_INFO_NODATAOPTI);
    }

    if ((ret = DBA_ExtractHierEltRecByIndexKey(hierHead, 
                                               A_InstrChrono, 
                                               A_InstrChrono_InstrId, 
                                               chronoArgSt[Chrono_Arg_InstrId], 
                                               FALSE,	/* PMSTA-11959 - RAK - copy record in recevied structure */ 
						                       DBA_FilterInstrChrono,
                                               chronoArgSt,
				                               NULLFCT, 
                                               FALSE,
	                                           &instrChronoNbr,
                                               &instrChronoTab)) != RET_SUCCEED ||
        instrChronoNbr == 0)
    {
        if (allocFlg == TRUE)
            FREE_DYNST(chronoArgSt, Chrono_Arg);
		return(ret);
    }

    if (instrChronoNbr == 1)
    {
        COPY_DYNST(*instrChronoStpPtr, instrChronoTab[0], A_InstrChrono);	/* PMSTA-11959 - RAK - copy record in recevied structure */ 
        FREE(instrChronoTab);
    }
    else
    {
        FREE(instrChronoTab);
        ret = RET_DBA_INFO_NODATAOPTI;
    }

    if (allocFlg == TRUE)
        FREE_DYNST(chronoArgSt, Chrono_Arg);
    return (ret);
}

/************************************************************************
**
**  Function    :   DBA_SelectInstrChrono()
**
**  Description :   Select instrument chronological record according to 
**                  received nature between two given dates
**                 
**  Arguments   :   instrId      instrument identifier
**                  begDate      begin date
**                  endDate      end date
**                  chronoNat    chrono nature (CHRONONAT_ENUM)
**                  chronoTab    pointer on array
**                  chronoNbr    pointer on array number
**
**  Return      :   RET_SUCCEED or error code
**
*************************************************************************/
RET_CODE DBA_SelectInstrChrono(ID_T                instrId, 
    	                       DATETIME_T          begDate, 
	                           DATETIME_T          endDate, 
	                           CHRONONAT_ENUM      chronoNat,              
                               ID_T                thirdId,      /* REF10598 - LJE - 041011 */
                               DBA_HIER_HEAD_STP   hierHead,     /* PMSTA-10748 - LJE - 110210 */
			                   DBA_DYNFLD_STP    **chronoTab,
			                   int                *chronoNbr) 
{
	DBA_DYNFLD_STP    ask=NULLDYNST;
	RET_CODE          ret=RET_SUCCEED;

	*chronoNbr = 0;

	if ((ask = ALLOC_DYNST(Chrono_Arg)) == NULLDYNST)
		MSG_RETURN(RET_MEM_ERR_ALLOC);

	SET_ID(ask,       Chrono_Arg_InstrId,      instrId);
	SET_ENUM(ask,     Chrono_Arg_NatEn,        chronoNat);
    SET_ID(ask,       Chrono_Arg_ThirdPartyId, thirdId); /* REF10598 - LJE - 041011 */
	SET_DATETIME(ask, Chrono_Arg_BegDate,      begDate);
	SET_DATETIME(ask, Chrono_Arg_EndDate,      endDate);

    if ((ret = DBA_SelectInstrChronoInHier(hierHead, ask, chronoNbr, chronoTab)) != RET_SUCCEED)
    {
        /* sel_all_instr_chrono_by_dt_nat @instr_id,@from_d,@till_d,@nature_e,@third_party_id,@sub_nat_type_id */
	    ret = DBA_Select2(InstrChrono, UNUSED, Chrono_Arg, ask, 
		                  A_InstrChrono, chronoTab, UNUSED, UNUSED, 
			              chronoNbr, UNUSED, UNUSED);
    }

	if (ret != RET_SUCCEED)
	{
		/*
		SYSNAME_T entSqlName;
		strcpy(entSqlName, DBA_GetDictEntitySqlName(InstrChrono));
		MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO, 
			     entSqlName, GET_ID(ask, Chrono_Arg_InstrId));
		*/
		ret = RET_DBA_ERR_NODATA;
	}
	else
		ret = RET_SUCCEED;

	FREE_DYNST(ask, Chrono_Arg);
	return(ret);
}

/************************************************************************
**
**  Function    :   DBA_ThirdChronoByFreq()
**
**  Description :   Search third chronological data at determined frequency 
**                 
**  Arguments   :   date        end date of the series
**                  freq        frequency at which the data is extracted
**                  freqUnitEn  frequency at which the data is extracted
**                  reading     how many occurrences are to be selected
**                  thirdId     third identifier
**                  chronoNatEn chronological data nature
**                  chronoTab   pointer on prices array to update
**                  chronoNbr   pointer on prices number to update
**                  
**
**  Return      :   RET_SUCCEED 
**                  or error code
**
** DVP005 : New function (96/03/13) 
**  Last modification : 
**                  REF7061 - TEB - 030122
**
*************************************************************************/
RET_CODE DBA_ThirdChronoByFreq(DATETIME_T     date, 
			       TINYINT_T      freq, 
			       FREQUNIT_ENUM  freqUnit, 
			       int            reading, 
			       ID_T           thirdId, 
			       ENUM_T         chronoNatEn,
			       DBA_DYNFLD_STP **chronoTab,
			       int            *chronoNbr)
{
	DBA_DYNFLD_STP    ask=NULLDYNST; 
	RET_CODE          ret;
    DATETIME_T        begDate;       /* REF7061 - TEB - 030122 */
	DATE_UNIT_ENUM    dateUnit=Year; /* REF7061 - TEB - 030122 */

    /* REF7061 - TEB - 030131 - Suppression of old code, please look in CMS */

    /* REF7061 - TEB - 030122 */
    /*----------------------------------------------------*/
    /* Now, we calculate the period (begin to end)        */
    /* with the frequency and number of reading.          */
    /* Then we fetch all chronos between those dates      */
    /*----------------------------------------------------*/

	switch(freqUnit)
	{
        case FreqUnit_Day:
            dateUnit = Day;
            break;

        case FreqUnit_BusDay:
            dateUnit = Day;
            break;

        case FreqUnit_Week:
            dateUnit = Week;
            break;

        case FreqUnit_Month:
            dateUnit = Month;
            break;

        case FreqUnit_Quarter:
            dateUnit = Quarter;
            break;

        case FreqUnit_Semester:
            dateUnit = Semester;
            break;

        case FreqUnit_Year:
            dateUnit = Year;
            break;
    }

    begDate.date = DATE_Move(date.date, (-1) * (reading - 1) * freq, dateUnit);
	begDate.time = 0;

	if ((ask = ALLOC_DYNST(Chrono_Arg)) == NULLDYNST)
		MSG_RETURN(RET_MEM_ERR_ALLOC);

	SET_ID(ask,       Chrono_Arg_InstrId,    thirdId);
	SET_DATETIME(ask, Chrono_Arg_BegDate,    begDate);
	SET_DATETIME(ask, Chrono_Arg_EndDate,    date);
	SET_ENUM(ask,     Chrono_Arg_NatEn,      chronoNatEn);

	*chronoNbr = 0;

	/* sel_all_ptf_chrono_by_dt */
	ret = DBA_Select2(ThirdChrono, UNUSED, Chrono_Arg, ask, 
		  Freq_ThirdChrono, chronoTab, UNUSED, UNUSED, chronoNbr, UNUSED, UNUSED);

	FREE_DYNST(ask, Chrono_Arg);

	return(ret);
}

/************************************************************************
**
**  Function    :   DBA_PtfChronoByFreq()
**
**  Description :   Search portfolio chronological data at determined frequency 
**                 
**  Arguments   :   date        end date of the series
**                  freq        frequency at which the data is extracted
**                  freqUnitEn  frequency at which the data is extracted
**                  reading     how many occurrences are to be selected
**                  ptfId       portfolio identifier
**                  chronoNatEn chronological data nature
**                  chronoTab   pointer on prices array to update
**                  chronoNbr   pointer on prices number to update
**                  
**
**  Return      :   RET_SUCCEED 
**                  or error code
**
** DVP005 : New function (96/03/13) 
**  Last modification : 
**                  REF7061 - TEB - 030122
**
*************************************************************************/
RET_CODE DBA_PtfChronoByFreq(DATETIME_T     date, 
			     TINYINT_T      freq, 
			     FREQUNIT_ENUM  freqUnit, 
			     int            reading, 
			     ID_T           ptfId, 
			     ENUM_T         chronoNatEn,
			     DBA_DYNFLD_STP **chronoTab,
			     int            *chronoNbr)
{
	DBA_DYNFLD_STP    ask=NULLDYNST; 
	RET_CODE          ret;
    DATETIME_T        begDate;       /* REF7061 - TEB - 030122 */
	DATE_UNIT_ENUM    dateUnit=Year; /* REF7061 - TEB - 030122 */

    /* REF7061 - TEB - 030131 - Suppression of old code, please look in CMS */

    /* REF7061 - TEB - 030122 */
    /*----------------------------------------------------*/
    /* Now, we calculate the period (begin to end)        */
    /* with the frequency and number of reading.          */
    /* Then we fetch all chronos between those dates      */
    /*----------------------------------------------------*/

	switch(freqUnit)
	{
        case FreqUnit_Day:
            dateUnit = Day;
            break;

        case FreqUnit_BusDay:
            dateUnit = Day;
            break;

        case FreqUnit_Week:
            dateUnit = Week;
            break;

        case FreqUnit_Month:
            dateUnit = Month;
            break;

        case FreqUnit_Quarter:
            dateUnit = Quarter;
            break;

        case FreqUnit_Semester:
            dateUnit = Semester;
            break;

        case FreqUnit_Year:
            dateUnit = Year;
            break;
    }

    begDate.date = DATE_Move(date.date, (-1) * (reading - 1) * freq, dateUnit);
	begDate.time = 0;

	if ((ask = ALLOC_DYNST(Chrono_Arg)) == NULLDYNST)
		MSG_RETURN(RET_MEM_ERR_ALLOC);

	SET_ID(ask,       Chrono_Arg_InstrId,    ptfId);
	SET_DATETIME(ask, Chrono_Arg_BegDate,    begDate);
	SET_DATETIME(ask, Chrono_Arg_EndDate,    date);
	SET_ENUM(ask,     Chrono_Arg_NatEn,      chronoNatEn);

	*chronoNbr = 0;

	/* sel_all_ptf_chrono_by_dt */
	ret = DBA_Select2(PtfChrono, UNUSED, Chrono_Arg, ask, 
		  Freq_PtfChrono, chronoTab, UNUSED, UNUSED, chronoNbr, UNUSED, UNUSED);

	FREE_DYNST(ask, Chrono_Arg);

	return(ret);
}

/************************************************************************
**
**  Function    :   DBA_ComplChronoByFreq()
**
**  Description :   Search compliance chronological data at determined frequency 
**                 
**  Arguments   :   date        end date of the series
**                  freq        frequency at which the data is extracted
**                  freqUnitEn  frequency at which the data is extracted
**                  reading     how many occurrences are to be selected
**                  ptfId       portfolio identifier
**                  chronoNatEn chronological data nature
**                  chronoTab   pointer on prices array to update
**                  chronoNbr   pointer on prices number to update
**                  
**
**  Return      :   RET_SUCCEED 
**                  or error code
**
**  PMSTA06646 - LJE - 080612
**  Last modification : 
**                  
**
*************************************************************************/
RET_CODE DBA_ComplChronoByFreq(DBA_DYNFLD_STP chronoFreq,
							   DBA_DYNFLD_STP **chronoTab,
			                   int            *chronoNbr)
{
	DBA_DYNFLD_STP    ask=NULLDYNST; 
	RET_CODE          ret;
    DATETIME_T        begDate, date;
	DATE_UNIT_ENUM    dateUnit=Year;

    /*----------------------------------------------------*/
    /* Now, we calculate the period (begin to end)        */
    /* with the frequency and number of reading.          */
    /* Then we fetch all chronos between those dates      */
    /*----------------------------------------------------*/
	switch(GET_ENUM(chronoFreq, Chrono_FreqArg_FreqUnitEn))
	{
        case FreqUnit_Day:
            dateUnit = Day;
            break;

        case FreqUnit_BusDay:
            dateUnit = Day;
            break;

        case FreqUnit_Week:
            dateUnit = Week;
            break;

        case FreqUnit_Month:
            dateUnit = Month;
            break;

        case FreqUnit_Quarter:
            dateUnit = Quarter;
            break;

        case FreqUnit_Semester:
            dateUnit = Semester;
            break;

        case FreqUnit_Year:
            dateUnit = Year;
            break;
    }

	date = GET_DATETIME(chronoFreq, Chrono_FreqArg_TillDate);
    begDate.date = DATE_Move(date.date, (-1) * (GET_INT(chronoFreq, Chrono_FreqArg_Reading) - 1) * GET_TINYINT(chronoFreq, Chrono_FreqArg_Freq), dateUnit);
	begDate.time = 0;

	if ((ask = ALLOC_DYNST(Chrono_Arg)) == NULLDYNST)
		MSG_RETURN(RET_MEM_ERR_ALLOC);

	COPY_DYNFLD(ask, Chrono_Arg, Chrono_Arg_InstrId, chronoFreq, Chrono_FreqArg, Chrono_FreqArg_ObjId);
	SET_DATETIME(ask, Chrono_Arg_BegDate,    begDate);
	SET_DATETIME(ask, Chrono_Arg_EndDate,    date);
	COPY_DYNFLD(ask, Chrono_Arg, Chrono_Arg_NatEn, chronoFreq, Chrono_FreqArg, Chrono_FreqArg_NatEn);
	COPY_DYNFLD(ask, Chrono_Arg, Chrono_Arg_ThirdPartyId, chronoFreq, Chrono_FreqArg, Chrono_FreqArg_ThirdPartyId);
	COPY_DYNFLD(ask, Chrono_Arg, Chrono_Arg_ThirdPartyFlg, chronoFreq, Chrono_FreqArg, Chrono_FreqArg_ThirdPartyFlg);
	COPY_DYNFLD(ask, Chrono_Arg, Chrono_Arg_SubNatTypeId, chronoFreq, Chrono_FreqArg, Chrono_FreqArg_SubNatTypeId);
	COPY_DYNFLD(ask, Chrono_Arg, Chrono_Arg_SubNatFlg, chronoFreq, Chrono_FreqArg, Chrono_FreqArg_SubNatFlg);
	COPY_DYNFLD(ask, Chrono_Arg, Chrono_Arg_StratId, chronoFreq, Chrono_FreqArg, Chrono_FreqArg_StratId);
	COPY_DYNFLD(ask, Chrono_Arg, Chrono_Arg_StratFlg, chronoFreq, Chrono_FreqArg, Chrono_FreqArg_StratFlg);
	COPY_DYNFLD(ask, Chrono_Arg, Chrono_Arg_ComplNatEn, chronoFreq, Chrono_FreqArg, Chrono_FreqArg_ComplNatEn);

	*chronoNbr = 0;

	/* sel_all_ptf_chrono_by_dt */
	ret = DBA_Select2(ComplianceChrono, UNUSED, Chrono_Arg, ask, 
		  Freq_PtfChrono, chronoTab, UNUSED, UNUSED, chronoNbr, UNUSED, UNUSED);

	FREE_DYNST(ask, Chrono_Arg);

	return(ret);
}

/************************************************************************
*
*  Function          : DBA_GetListChrono()
*
*  Description       : Get list chronological data according to a time position
*                      (cf TIMEDIM_ENUM), a nature (cf CHRONONAT_ENUM), a currency
*                       and a date.
*
*  Arguments         : listId       : list id
*                      currId       : currency id  
*                      datetime     : date  
*                      chronoNat    : nature of chrono data of interest
*                      timeDim      : time dimension (CURRENT, NEXT, TODAY)
*                      validFlg     : 
*                      chronoPtr    : pointer on the result dyn. struct
*
*
*  Return            : RET_SUCCEED
*                      RET_GEN_ERR_INVARG : if problem with input arguments
*                      RET_MEM_ERR_ALLOC  : if memory allocation failed
*                      RET_DBA_ERR_NODATA : if no data
*
*  Creation date     : REF7292 - LJE - 020213
*  Last modification : 
*
*************************************************************************/
RET_CODE DBA_GetListChrono(ID_T               listId, 
                           ID_T               currId,
	                       DATETIME_T         dateTime, 
	                       LISTCHRONONAT_ENUM chronoNat,              
		                   TIMEDIM_ENUM       timeDim,
		                   FLAG_T             validFlg, 
	                       DBA_DYNFLD_STP     chronoPtr) 
{
	DBA_DYNFLD_STP getChrono=NULLDYNST;

	if (chronoPtr == NULLDYNST)
	{
	   MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, 
			"DBA_GetPortChrono", "chrono pointer");
	   return(RET_GEN_ERR_INVARG);
	}
		/*$*/
	if ((getChrono = ALLOC_DYNST(A_ListChrono)) == NULLDYNST)
		MSG_RETURN(RET_MEM_ERR_ALLOC);

	SET_ID(getChrono,       A_ListChrono_ListId,       listId);
    if (currId > 0)
	    SET_ID(getChrono,       A_ListChrono_CurrId,      currId);
	SET_DATETIME(getChrono, A_ListChrono_ValidDate,   dateTime);
	SET_ENUM(getChrono,     A_ListChrono_TimeDimEn,   (ENUM_T)timeDim);
	SET_ENUM(getChrono,     A_ListChrono_NatEn,       (ENUM_T)chronoNat);
	SET_FLAG(getChrono,     A_ListChrono_ValidFlg,    (FLAG_T)validFlg);

	if (DBA_Get2(ListChrono, UNUSED, A_ListChrono, 
		    getChrono, A_ListChrono, &chronoPtr,
	            UNUSED, UNUSED, UNUSED) != RET_SUCCEED)
	{
		FREE_DYNST(getChrono, A_ListChrono);
		return(RET_DBA_ERR_NODATA);
	}

	FREE_DYNST(getChrono, A_ListChrono);

	return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   DBA_ListChronoByFreq()
**
**  Description :   Search list chronological data at determined frequency 
**                 
**  Arguments   :   date        end date of the series
**                  freq        frequency at which the data is extracted
**                  freqUnitEn  frequency at which the data is extracted
**                  reading     how many occurrences are to be selected
**                  listId      list identifier
**                  chronoNatEn chronological data nature
**                  chronoTab   pointer on prices array to update
**                  chronoNbr   pointer on prices number to update
**                  
**
**  Return      :   RET_SUCCEED 
**                  or error code
**
** DVP005 : New function (96/03/13) 
**  Last modification : 
**                  REF7061 - TEB - 030122
**
*************************************************************************/
RET_CODE DBA_ListChronoByFreq(DATETIME_T     date, 
			     TINYINT_T      freq, 
			     FREQUNIT_ENUM  freqUnit, 
			     int            reading, 
			     ID_T           listId, 
			     ENUM_T         chronoNatEn,
			     DBA_DYNFLD_STP **chronoTab,
			     int            *chronoNbr)
{
	DBA_DYNFLD_STP    ask=NULLDYNST; 
	RET_CODE          ret;
    DATETIME_T        begDate;       /* REF7061 - TEB - 030122 */
	DATE_UNIT_ENUM    dateUnit=Year; /* REF7061 - TEB - 030122 */

    /* REF7061 - TEB - 030131 - Suppression of old code, please look in CMS */

    /* REF7061 - TEB - 030122 */
    /*----------------------------------------------------*/
    /* Now, we calculate the period (begin to end)        */
    /* with the frequency and number of reading.          */
    /* Then we fetch all chronos between those dates      */
    /*----------------------------------------------------*/

	switch(freqUnit)
	{
        case FreqUnit_Day:
            dateUnit = Day;
            break;

        case FreqUnit_BusDay:
            dateUnit = Day;
            break;

        case FreqUnit_Week:
            dateUnit = Week;
            break;

        case FreqUnit_Month:
            dateUnit = Month;
            break;

        case FreqUnit_Quarter:
            dateUnit = Quarter;
            break;

        case FreqUnit_Semester:
            dateUnit = Semester;
            break;

        case FreqUnit_Year:
            dateUnit = Year;
            break;
    }

    begDate.date = DATE_Move(date.date, (-1) * (reading - 1) * freq, dateUnit);
	begDate.time = 0;

	if ((ask = ALLOC_DYNST(Chrono_Arg)) == NULLDYNST)
		MSG_RETURN(RET_MEM_ERR_ALLOC);

	SET_ID(ask,       Chrono_Arg_InstrId,    listId);
	SET_DATETIME(ask, Chrono_Arg_BegDate,    begDate);
	SET_DATETIME(ask, Chrono_Arg_EndDate,    date);
	SET_ENUM(ask,     Chrono_Arg_NatEn,      chronoNatEn);

	*chronoNbr = 0;

	/* sel_all_instr_chrono_by_dt */
	ret = DBA_Select2(ListChrono, UNUSED, Chrono_Arg, ask, 
		  Freq_ListChrono, chronoTab, UNUSED, UNUSED, chronoNbr, UNUSED, UNUSED);

	FREE_DYNST(ask, Chrono_Arg);

	return(ret);
}

/************************************************************************
**
**  Function    :   DBA_InstrChronoByFreq()
**
**  Description :   Search instrument chronological data at determined frequency 
**                 
**  Arguments   :   date        end date of the series
**                  freq        frequency at which the data is extracted
**                  freqUnitEn  frequency at which the data is extracted
**                  reading     how many occurrences are to be selected
**                  instrId     instrument identifier
**                  chronoNatEn chronological data nature
**                  chronoTab   pointer on prices array to update
**                  chronoNbr   pointer on prices number to update
**                  
**
**  Return      :   RET_SUCCEED 
**                  or error code
**
** DVP005 : New function (96/03/13) 
**  Last modification : 
**                  REF7061 - TEB - 030122
**
**
*************************************************************************/
RET_CODE DBA_InstrChronoByFreq(DATETIME_T     date, 
			                   TINYINT_T      freq, 
			                   FREQUNIT_ENUM  freqUnit, 
			                   int            reading, 
			                   ID_T           instrId, 
			                   ENUM_T         chronoNatEn,
                               ID_T           thirdPartyId, /* REF10598 - LJE - 041008 */
                               ID_T           subNatTypeId, /* REF10598 - LJE - 041011 */
                               FLAG_T         subNatFlg,    /* REF10598 - LJE - 041011 */
			                   DBA_DYNFLD_STP **chronoTab,
			                   int            *chronoNbr)
{
	DBA_DYNFLD_STP    ask=NULLDYNST; 
	RET_CODE          ret;
    DATETIME_T        begDate;       /* REF7061 - TEB - 030122 */
	DATE_UNIT_ENUM    dateUnit=Year; /* REF7061 - TEB - 030122 */

    /* REF7061 - TEB - 030131 - Suppression of old code, please look in CMS */

    /* REF7061 - TEB - 030122 */
    /*----------------------------------------------------*/
    /* Now, we calculate the period (begin to end)        */
    /* with the frequency and number of reading.          */
    /* Then we fetch all chronos between those dates      */
    /*----------------------------------------------------*/

	switch(freqUnit)
	{
        case FreqUnit_Day:
            dateUnit = Day;
            break;

        case FreqUnit_BusDay:
            dateUnit = Day;
            break;

        case FreqUnit_Week:
            dateUnit = Week;
            break;

        case FreqUnit_Month:
            dateUnit = Month;
            break;

        case FreqUnit_Quarter:
            dateUnit = Quarter;
            break;

        case FreqUnit_Semester:
            dateUnit = Semester;
            break;

        case FreqUnit_Year:
            dateUnit = Year;
            break;
    }

    begDate.date = DATE_Move(date.date, (-1) * (reading - 1) * freq, dateUnit);
	begDate.time = 0;

	if ((ask = ALLOC_DYNST(Chrono_Arg)) == NULLDYNST)
		MSG_RETURN(RET_MEM_ERR_ALLOC);

	SET_ID(ask,       Chrono_Arg_InstrId,         instrId);
	SET_DATETIME(ask, Chrono_Arg_BegDate,         begDate);
	SET_DATETIME(ask, Chrono_Arg_EndDate,         date);
	SET_ENUM(ask,     Chrono_Arg_NatEn,           chronoNatEn);
	SET_ID(ask,       Chrono_Arg_ThirdPartyId,    thirdPartyId); /* REF10598 - LJE - 041008 */
    SET_ID(ask,       Chrono_Arg_SubNatTypeId,    subNatTypeId); /* REF10598 - LJE - 041011 */
    SET_FLAG(ask,     Chrono_Arg_SubNatFlg,       subNatFlg); /* REF10598 - LJE - 041011 */

	*chronoNbr = 0;

	/* sel_all_instr_chrono_by_vdt */
	ret = DBA_Select2(InstrChrono, UNUSED, Chrono_Arg, ask, 
		  Freq_InstrChrono, chronoTab, UNUSED, UNUSED, chronoNbr, UNUSED, UNUSED);

	FREE_DYNST(ask, Chrono_Arg);

	return(ret);
}

/************************************************************************
**   END  dbachro.c                                           UNICIBLE **
*************************************************************************/

/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Includes
*************************************************************************/
#include <stdio.h>
#include <iomanip>
#include <sstream>
#include "callstack.h"
#include "os.h"
#include "syslib.h"
#include "sysformat.h"

/************************************************************************
**      Static Data Definitions
*************************************************************************/
/* Status of the callstack interfaces. See callStackDisable and callStackEnable */
static AtomicBool M_IsCallStackEnable;   /* PMSTA-25793 - 281216 - PMO */
static AtomicInt M_CallStackFormat;


#if _DEBUG
const bool SV_DebugBinary = true;                   /* PMSTA-21983 - 181215 - PMO */
#else
const bool SV_DebugBinary = false;                  /* PMSTA-21983 - 181215 - PMO */
#endif

/************************************************************************
**
**  Function    :   SYS_InitCallStack()
**
**  Description :   Initialization of the callstack module.
**                  This function is not thread safe
**
**  Argument    :   None
**
**  Return      :   None
**
**  Last modif. :   REF9165 - 030530 - PMO : Display the call stack
**              :   REF11847 - 060622 - BSA : Display the call stack
**
*************************************************************************/
void SYS_InitCallStack(void)
{
    SYS_SetProgramState(ProgramState::InitializationCallstack);                 /* PMSTA-21983 - 181215 - PMO */

    char * envVar=nullptr;
    if ((envVar = SYS_GetEnv("AAACALLSTACKFORMAT")) != nullptr)
    {
        int callStackFormat = strtol(envVar, &envVar, 10);
        SYS_SetCallStackFormat(callStackFormat);
    }

	if(OS_InitCallStack())
    {
        SYS_EnableCallStack();
    }
    else
    {
        SYS_DisableCallStack();
    }
}

/************************************************************************
**
**  Function    :   SYS_SetCallStackFormat()
**
**  Description :   Set callback format
**
**  Argument    :   int callback format as binary value (1 = no adress displayed)
**
**  Return      :   None
**
**  Last modif. :  DLA - PMSTA-27649 - 170705 
""
*************************************************************************/
void SYS_SetCallStackFormat(int value)
{
    M_CallStackFormat.store(value);
}

/************************************************************************
**
**  Function    :   SYS_GetCallStackFormat()
**
**  Description :   Get callback format
**
**  Argument    :   none
**
**  Return      :   int callback format as binary value (1 = no adress displayed)
**
**  Last modif. :  DLA - PMSTA-27649 - 170705
""
*************************************************************************/
int SYS_GetCallStackFormat()
{
    return M_CallStackFormat.load();
}

/************************************************************************
**
**  Function    :   SYS_RemoveCallStack()
**
**  Description :   Destruction of the callstack module.
**                  Called when the program is finishing
**
**  Argument    :   None
**
**  Return      :   None
**
**  Last modif. :   REF9165 - 030530 - PMO : Display the call stack
**              :   REF11847 - 060622 - BSA : Display the call stack
**
*************************************************************************/
void SYS_RemoveCallStack(void)
{
    /* Set the status of the callstack interfaces to disable */
    SYS_DisableCallStack();
    OS_RemoveCallStack();    
}


/************************************************************************
**
**  Function    :   SYS_EnableCallStack()
**
**  Description :   Enable the callstack
**
**  Argument    :   None
**
**  Return      :   None
**
**  Last modif. :   PMSTA-25852 - 110117 - PMO : Integrate getcallstack as a standard TripleA library
**
*************************************************************************/
void SYS_EnableCallStack()
{
    M_IsCallStackEnable.store(true);
}


/************************************************************************
**
**  Function    :   SYS_DisableCallStack()
**
**  Description :   Disable the callstack
**
**  Argument    :   None
**
**  Return      :   None
**
**  Last modif. :   PMSTA-25852 - 110117 - PMO : Integrate getcallstack as a standard TripleA library
**
*************************************************************************/
void SYS_DisableCallStack()
{
    M_IsCallStackEnable.store(false);
}



/************************************************************************
**
**  Function    :   SYS_IsCallStackEnable()
**
**  Description :   Return if the callstack module is enable
**
**  Argument    :   None
**
**  Return      :   false for disable
**                  true for enable
**
**  Last modif. :   REF9165 - 030530 - PMO : Display the call stack
**
*************************************************************************/
bool SYS_IsCallStackEnable(void)
{
    return M_IsCallStackEnable.load();
}


/************************************************************************
**
**  Function    :   SYS_GetCallStack()
**
**  Description :   Return the callstack
**
**  Argument    :   None
**
**  Return      :   the string with the callstack
**                  the string length might be 0
**
**  Last modif. :   REF9165 - 030530 - PMO : Display the call stack
**                  PMSTA-21983 - 181215 - PMO : Finish, test and integrate the stack trace on AIX
**                  PMSTA-22011 - 040116 - PMO : Allow to disable the generation of call stack
**                  PMSTA-21983 - 181215 - PMO : Finish, test and integrate the stack trace on AIX
**                  PMSTA-25793 - 281216 - PMO : Dispatcher might crash on AIX into putProperty
**                  PMSTA-27310 - 160517 - PMO : Core file generated when writing an error message
**
*************************************************************************/
std::string SYS_GetCallStack(int nbIndent, bool bForceCallStack)
{
    std::string ret;
    if (SYS_IsCallStackEnable() == false)
    {
        return ret;
    }
    if ( bForceCallStack || (SYS_GetTlsThread() != nullptr &&  SYS_IsThreadCallStackGeneration() == true ) )
    { 
        /* Obtain the call stack */

#ifdef AIX
        /* PMSTA-21983 - 181215 - PMO
         * Workaround for AIX that dosen't support concurrency inside getenv and might finish in deadlock
         */
        if (ProgramState::InitializationLock != SYS_GetProgramState())
        {
            LockGuard lock(ServLock_GetEnv, true, FILEINFO);
#endif
            bool printAddress = !((SYS_GetCallStackFormat()&FORMAT_NOADDRESS) == FORMAT_NOADDRESS);
            char * p = OS_GetCallStack(printAddress);         /* PMSTA-25793 - 281216 - PMO */
            if (nullptr != p)
            {
                ret = p;
                free(p);

                /* DLA - PMSTA-27649 - 170705 */
                if (nbIndent > 0 && ret.length() > 0)
                {
                    std::string szIndent(nbIndent * 4, ' ');
                    ret = ret.insert(0, szIndent);
                    SYS_StringFindAndReplaceAll(ret, "\n", "\n" + szIndent);
                }
            }

#ifdef AIX
        }
#endif

    }

    return ret;
}


/************************************************************************
**      END        callstack.c                                   
*************************************************************************/

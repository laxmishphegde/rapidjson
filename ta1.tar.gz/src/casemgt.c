/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define CASEMGT_C

/************************************************************************
**      Include files
*************************************************************************/
#define STDIO_H
#define STRING_H
#define TIME_H
#define STDLIB_H
#define MATH_H

#include "unidef.h"     /* Mandatory */
#include "gen.h"
#include "date.h"
#include "dba.h"
#include "ope.h"        /* PMSTA-24581 - CHU - 160826 */
#include "syslib.h"     /* PMO - Rename our sys.h to syslib.h and use it */
#include "tls.h"
#include "hier.h"
#include "fin.h"
#include "scptyl.h"
#include "scelib.h"
#include "casemgt.h"
#include "compound.h"

/************************************************************************
**      External entry points
**
**  FIN_GenerateConstraintCase()	Generate and store Cases in hierarchy.
**
*************************************************************************/

/************************************************************************
**      Local functions
**
**
**
*************************************************************************/

/************************************************************************
**      Static definitions & data
*************************************************************************/

/**** INTERNAL STRUCTURES ****/


/************************************************************************
**      Functions
*************************************************************************/

/************************************************************************
*
*   Function      :   DBA_GetCasesFromHierPtfId()
*
*   Description   :   Extract all extOp's related to the whole portfolio hierarchy
*
**  Arguments     :   dynSt    element pointer
**                    dynStTp  element description enum
*
*   Return        :   TRUE or FALSE
*
*   Creation Date :   PMSTA09284-CHU-100203
*
*************************************************************************
STATIC RET_CODE DBA_GetCasesFromHierPtfId(DBA_HIER_HEAD_STP	hierHead,
										  ID_T				ptfId,
										  int				*caseMgtNbr,
										  DBA_DYNFLD_STP	**caseMgtTab)

{
	RET_CODE		ret = RET_SUCCEED;
	int				i, j= 0;
	int				localCaseMgtNbr;
	DBA_DYNFLD_STP	*localCaseMgtTab, ptfPtr;

	*caseMgtNbr = 0;
	*caseMgtTab = NULL;

	if ((ret = DBA_ExtractHierEltRec(hierHead, A_CaseManagement,
									 FALSE, NULLFCT, NULLFCT,
									 &localCaseMgtNbr, &localCaseMgtTab)) != RET_SUCCEED)
	{
		return(ret);
	}

	if (((*caseMgtTab) = (DBA_DYNFLD_STP *)CALLOC(localCaseMgtNbr, sizeof(DBA_DYNFLD_STP))) == NULLDYNSTPTR)
    {
		FREE(localCaseMgtTab);
		MSG_RETURN(RET_MEM_ERR_ALLOC);
    }

	for (i=0; i < localCaseMgtNbr; i++)
	{
		if (IS_NULLFLD(localCaseMgtTab[j], A_CaseManagement_PtfId) == FALSE)
		{
			if (DBA_GetRecPtrFromHierById(hierHead, GET_ID(localCaseMgtTab[j], A_CaseManagement_PtfId), A_Ptf, &ptfPtr) != RET_SUCCEED)
			{
				continue;
			}

			if(CMP_ID(ptfId, GET_ID(ptfPtr, A_Ptf_Id))       ==0 ||
			   CMP_ID(ptfId, GET_ID(ptfPtr, A_Ptf_ParentPortId)) ==0 ||
			   CMP_ID(ptfId, GET_ID(ptfPtr, A_Ptf_HierPortId))==0)
			{
				(*caseMgtTab)[*caseMgtNbr] = localCaseMgtTab[i];
				(*caseMgtNbr)++;
			}
		}
	}

	FREE(localCaseMgtTab);
	return(ret);
}
*/

/************************************************************************
*
*   Function      :   FIN_FilterCaseMgtFromPtf()
*
*   Description   :
*
*   Arguments     :   dynSt    element pointer
*                     dynStTp  element description enum
*
*   Return        :   TRUE or FALSE
*
*   Creation      :   PMSTA09284-CHU-100204
*
*************************************************************************/
STATIC int FIN_FilterCaseMgtFromPtf(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP ptfPtr)
{
	/* PMSTA14191-CHU-120428 : Avoid trying to get a Ptf with a NULL Id */
	if (IS_NULLFLD(dynSt, A_CaseManagement_PtfId) == TRUE)
		return (FALSE);

	/* REF3641 - strat focus elements need same treatment than reconcil elements */
	if (GET_ID(dynSt, A_CaseManagement_PtfId) == GET_ID(ptfPtr, A_Ptf_Id))
    {
		return(TRUE);
    }
	else
	{
		FLAG_T				allocFlg=FALSE;
		DBA_HIER_HEAD_STP	hierHead=(DBA_HIER_HEAD_STP)DBA_GetHierOptiPtr();
		DBA_DYNFLD_STP		cmPtfPtr=NULLDYNST;

		if (DBA_GetPtfById(GET_ID(dynSt, A_CaseManagement_PtfId), FALSE, &allocFlg,
	                           &cmPtfPtr, hierHead, UNUSED, UNUSED) == RET_SUCCEED)
		{
			if (GET_ID(cmPtfPtr, A_Ptf_HierPortId) == GET_ID(ptfPtr, A_Ptf_Id))
			{
				if (allocFlg == TRUE) { FREE_DYNST(cmPtfPtr, A_Ptf); } /* PMSTA39941 - 02052020 - HLA - If ptf record fetched from DB */
				return(TRUE);
			}
		}

		if (allocFlg == TRUE) { FREE_DYNST(cmPtfPtr, A_Ptf);}
	}

    return(FALSE);
}

/************************************************************************
**
**  Function        :   FIN_FilterCaseMgtSessionIC()
**
**  Description     :
**
**  Arguments       :
**
**  Return          :
**
**  Creation        :   FPL-PMSTA10166-100715
**
*************************************************************************/
STATIC  int FIN_FilterCaseMgtSessionIC(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP ptfPtr)
{
    if ((GET_ENUM(dynSt, A_CaseManagement_NatEn)    == CaseManagementNat_InputCtrl) /* &&
        (GET_ENUM(dynSt, A_CaseManagement_SubNatEn) == CaseManagementSubNat_SessionICStatus) */)
    {
		return(TRUE);
    }

    return(FALSE);
}

/***************************************************************************************
**
**  Function    :   FIN_CaseMakeExtensionsAndDefVal()
**
**  Description :   Generates a Case from any Constraint violation
**
**  Argument    :   domainPtr
**                  hearHead
**
**  Return      :   RET_SUCCEED or return code
**
**  creation	:   PMSTA07121-CHU-081103
**  Last modif. :
**
***************************************************************************************/
STATIC RET_CODE FIN_CaseMakeExtensionsAndDefVal(DBA_DYNFLD_STP	domainPtr,
												 PTR			argHierHead,
												 DBA_DYNFLD_STP	ptfPtr)
{
	DBA_HIER_HEAD_STP	hierHead=(DBA_HIER_HEAD_STP)argHierHead;
	FLAG_T				*scptFlagTab=NULL;
	RET_CODE			ret = RET_SUCCEED;
	DBA_DYNFLD_STP		*caseTab=NULL;
	int					i, caseNbr=0;
    HIER_FLTFCT         *fctFilter ;    /*  FPL-PMSTA10166-100715   */


    /*  FPL-PMSTA10166-100715   */
    if (ptfPtr == NULL)
        fctFilter = FIN_FilterCaseMgtSessionIC ;
    else
        fctFilter = FIN_FilterCaseMgtFromPtf ;

	/* Extract all Cases of current portfolio */
	if ((ret = DBA_ExtractHierEltRecWithFilterSt(hierHead,
                                                  A_CaseManagement,
                                                  FALSE,
                                                  fctFilter,    /*  FPL-PMSTA10166-100715 FIN_FilterCaseMgtFromPtf  */
                                                  ptfPtr,
                                                  NULLFCT,
                                                  &caseNbr,
                                                  &caseTab)) != RET_SUCCEED)
	{
		return(ret);
	}


	if (caseNbr == 0)
	{
		return(ret);
	}

	if ((scptFlagTab = (FLAG_T *)CALLOC(GET_FLD_NBR(A_CaseManagement), sizeof(FLAG_T))) == NULL)
    {
		FREE(caseTab);
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "ScriptFlag");
        return(RET_MEM_ERR_ALLOC);
    }

    if ((ret = DBA_SetHierLnkUsed(hierHead,
                                  A_CaseManagement,
                                  A_CaseManagement_A_CaseLink_Ext)) != RET_SUCCEED)
	{
		FREE(caseTab);
    	FREE(scptFlagTab);
        return(ret);
	}

	if ((ret = DBA_MakeSpecRecLinks(hierHead,
                                    A_CaseManagement,
                                    A_CaseManagement_A_CaseLink_Ext)) != RET_SUCCEED)
	{
		FREE(caseTab);
    	FREE(scptFlagTab);
        return(ret);
	}

	scptFlagTab[A_CaseManagement_NatEn]			= TRUE;
	scptFlagTab[A_CaseManagement_SubNatEn]		= TRUE;
	scptFlagTab[A_CaseManagement_PtfId]			= TRUE;
	scptFlagTab[A_CaseManagement_InstrId]		= TRUE;
	scptFlagTab[A_CaseManagement_SessionId]		= TRUE;
	scptFlagTab[A_CaseManagement_CriticalnessEn]= TRUE;
	scptFlagTab[A_CaseManagement_MainEntityDictId]= TRUE;
	scptFlagTab[A_CaseManagement_MainObjId]  	= TRUE;
	scptFlagTab[A_CaseManagement_StatusEn]		= TRUE; /* PMSTA17573-CHU-140208 */

	for (i=0; i < caseNbr; i++)
	{
        /*  FPL-PMSTA10166.100713   */
        if (GET_ENUM(caseTab[i], A_CaseManagement_NatEn) == CaseManagementNat_InputCtrl)
        {
            /*  already filed by input control      */
            scptFlagTab[A_CaseManagement_Description] = TRUE;
        }
        else
        {
            scptFlagTab[A_CaseManagement_Description] = FALSE;  /*  FPL-PMSTA10166-100929   */
        }

        /*  FPL-PMSTA10166-100929   */
        if (IS_NULLFLD(caseTab[i], A_CaseManagement_Cd) == FALSE)
        {
            scptFlagTab[A_CaseManagement_Cd] = TRUE;
        }
        else
        {
            scptFlagTab[A_CaseManagement_Cd] = FALSE;
        }

		if ((CASEMANAGEMENTSUBNAT_ENUM)GET_ENUM(caseTab[i], A_CaseManagement_SubNatEn) != CaseManagementSubNat_ModelPtf)
		{
			scptFlagTab[A_CaseManagement_InstrId]= FALSE;
		}

    /* PMSTA-30386 - DDV - 180314 - Call SCPT_ComputeScreenDV instead of SCPT_ComputeDV to use current hierarchy, not the one stored in thread */
    if (SCPT_ComputeScreenDV(CaseManagement,
                                DictFct_0,
                                scptFlagTab,
                                NULL,              /* HFI-PMSTA-25327-171023  Dedicated flag tab for filter    */
                                caseTab[i],
                                NULLDYNST,
                                domainPtr,
                                NULLDYNST,   /* PMSTA13283 - DDV - 120117 */
                                TRUE,
                                TRUE,
                                EvalType_DefValAndFilter,
                                -1,
                                NULL,
                                NULL,
                                hierHead,
                                0,
                                NullEntity, /*DictScreen,*//*PMSTA07790 - DDV - 090203 - Send NullEntity for standard case for ComputeDV */
                                NULL,
                                NULL,
                                NULL,
                                NULL,
                                NULL,
                                NullEntity,
                                FALSE,
                                FALSE,
                                0)!= 0)
		{
			MSG_SendMesg(RET_SCPT_ERR_SYNTAX, 0, FILEINFO);
		}

		/* PMSTA17573-CHU-140208 */
		/* No way that the user should apply a DV on the initial status of a Case, it has to be created as 'not clarified'
		/-* If no DV, initialize the field *-/
		if (IS_NULLFLD(caseTab[i], A_CaseManagement_StatusEn) == TRUE)
		{*/
			SET_ENUM(caseTab[i], A_CaseManagement_StatusEn, CaseManagementStatus_NotClarified);
		/*}
		*/

		/* If no user, initialize the field */
		if (IS_NULLFLD(caseTab[i], A_CaseManagement_UserId) == TRUE)
		{
			ID_T	userId = (ID_T)0;

			DBA_GetUserInfo2(A_ApplUser_Id, (PTR) &userId, TRUE);   /*  FPL-PMSTA10166-100709 replace DBA_GetUserInfo to use the wui user if exist  */
			SET_ID(caseTab[i], A_CaseManagement_UserId, userId);
		}
	}

	FREE(scptFlagTab);
	FREE(caseTab);

	return(ret);
}

/***************************************************************************************
**
**  Function    :   FIN_GenerateConstraintCase()
**
**  Description :   Generates a Case from any Constraint violation
**
**  Argument    :   domainPtr
**                  hearHead
**
**  Return      :   RET_SUCCEED or return code
**
**  creation	:   PMSTA07121-CHU-081013
**  Last modif. :
**
***************************************************************************************/
RET_CODE FIN_CreateConstraintCase(DBA_DYNFLD_STP	domainPtr,
								  PTR				hierHead,
								  DBA_DYNFLD_STP	ptfPtr)
{
	RET_CODE	ret = RET_SUCCEED;
	FLAG_T		applCaseActivationFlag = FALSE; /* PMSTA07121-CHU-090311 */

	GEN_GetApplInfo(ApplCaseActivationFlag, &applCaseActivationFlag);

	if (applCaseActivationFlag == TRUE)
	{
		if((ret = FIN_CreateConstrBreachCase(domainPtr, hierHead, ptfPtr)) != RET_SUCCEED)
		{
			return(ret);
		}

        REBAL_METHOD_ENUM   rebalMethodEn = static_cast<REBAL_METHOD_ENUM>GET_ENUM(domainPtr, A_Domain_RebalMethodEn);

        /* Objective margin case creation to be done only for non-Overlay processing */                                                /* PMSTA-40266 - 270520 - vkumar */
        if (!(GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_ReconcStrat &&
              (REBAL_METHOD_ENUM::Inter_All_Assets == rebalMethodEn ||
               REBAL_METHOD_ENUM::Inter_Cash_Only == rebalMethodEn) &&
              FALSE == IS_NULLFLD(ptfPtr, A_Ptf_OverlayFlg) &&
              TRUE == GET_FLAG(ptfPtr, A_Ptf_OverlayFlg)))
        {
            /* Objective margin case to be skipped for Overlay Inter Rebalance */
		    if((ret = FIN_CreateObjectiveMarginCase(domainPtr, hierHead, ptfPtr)) != RET_SUCCEED)
		    {
			    return(ret);
		    }
        }

		/* Apply 'case' default values */
		if((ret = FIN_CaseMakeExtensionsAndDefVal(domainPtr, hierHead, ptfPtr)) != RET_SUCCEED)
		{
			return(ret);
		}
	}

	return(ret);
}

/***************************************************************************************
**
**  Function    :   FIN_AddCaseLinkedObject()
**
**  Description :   Add Linked Object regarding Case Nature/SubNature - also give already retrieved Extop for this portfolio
**
**  Argument    :   domainPtr
**                  hierHead
**                  casePtr
**					entDictId
**					objId
**
**  Return      :   RET_SUCCEED or return code
**
**  creation	:   PMSTA07121-RAK-081020
**
**  Last modif. :
**
***************************************************************************************/
RET_CODE FIN_AddCaseLinkedObject(DBA_DYNFLD_STP		domainPtr,
								 DBA_HIER_HEAD_STP	hierHead,
								 DBA_DYNFLD_STP		casePtr,
								 DICT_T				entDictId,
								 ID_T					objId)
{
	RET_CODE		ret = RET_SUCCEED;
	DBA_DYNFLD_STP	caseLinkPtr=NULLDYNST;

	if ((caseLinkPtr = ALLOC_DYNST(A_CaseLink)) == NULL)
	{
		MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "A_CaseLink");
		return(RET_MEM_ERR_ALLOC);
	}

	SET_ID(caseLinkPtr,	 A_CaseLink_CaseId,    GET_ID(casePtr, A_CaseManagement_Id));
	SET_DICT(caseLinkPtr, A_CaseLink_EntDictId, entDictId);
	SET_ID(caseLinkPtr,   A_CaseLink_ObjId,     objId);

	ret = DBA_AddHierRecord(hierHead, caseLinkPtr, A_CaseLink,
							FALSE, HierAddRec_ForceInsert);

	if (ret != RET_SUCCEED)
		FREE_DYNST(caseLinkPtr, A_CaseLink);

	return(ret);
}

/***************************************************************************************
**
**  Function    :   FIN_GetCaseLinkedObject()
**
**  Description :   Get first Linked Object regarding received object enum
**
**  Argument    :   domainPtr
**                  hierHead
**                  casePtr
**					entDictId
**					objId
**
**  Return      :   RET_SUCCEED or return code
**
**  creation	:   PMSTA07121-RAK-081230
**
**  Last modif. :
**
***************************************************************************************/
RET_CODE FIN_GetCaseLinkedObject(DBA_HIER_HEAD_STP	hierHead,
								 DBA_DYNFLD_STP		casePtr,
								 OBJECT_ENUM		getObjectEnum,
								 DBA_DYNFLD_STP     *linkedObject,
                                 FLAG_T             *freeFlg,
                                 int                options,
                                 int			    *connectNoPtr)
{
	DBA_DYNFLD_STP	*caseLinkTab=NULLDYNSTPTR, inputData=NULLDYNST;
	int				caseLinkNbr=0, i;
	OBJECT_ENUM     objectEnum=NullEntity;
    FLAG_T          freeCaseLinkTab = FALSE;
	DBA_DYNST_ENUM  inputSt, outputSt;

	*linkedObject=NULLDYNST;
    *freeFlg=FALSE;

	if (casePtr == NULLDYNST)
		return(RET_GEN_ERR_INVARG);

    if (hierHead != NULL)
    {
	    if (GET_EXTENSION_PTR(casePtr, A_CaseManagement_A_CaseLink_Ext) != NULL &&
			    (caseLinkTab = GET_EXTENSION_PTR(casePtr, A_CaseManagement_A_CaseLink_Ext)) != NULL)
	    {
		    caseLinkNbr = GET_EXTENSION_NBR(casePtr, A_CaseManagement_A_CaseLink_Ext);
	    }
    }

    /* if no case link found, load them from database */
    if (caseLinkNbr == 0 &&
        GET_ID(casePtr, A_CaseManagement_Id) > 0)
    {
		if (DBA_Select2(CaseLink, UNUSED, A_CaseManagement, casePtr,
			            A_CaseLink, &caseLinkTab, options, UNUSED, &caseLinkNbr,
						connectNoPtr, UNUSED) != RET_SUCCEED)
        {
	        return(RET_FIN_ERR_ELTNOTFOUND);
        }
        freeCaseLinkTab=TRUE;
    }

	for (i=0; i<caseLinkNbr && (*linkedObject) == NULLDYNST; i++)
	{
		DBA_GetObjectEnum(GET_DICT(caseLinkTab[i], A_CaseLink_EntDictId), &objectEnum);
		if (objectEnum == getObjectEnum)
		{
            if (hierHead != NULL)
            {
			    DBA_GetRecPtrFromHierById(hierHead, GET_ID(caseLinkTab[i], A_CaseLink_ObjId),
				                          GET_EDITGUIST(getObjectEnum),
										  linkedObject);
            }

            if ((*linkedObject) == NULLDYNST && GET_ID(caseLinkTab[i], A_CaseLink_ObjId) > 0)
            {
		        inputSt  = GET_ADMINGUIST(objectEnum);
		        outputSt = GET_EDITGUIST(objectEnum);

		        if ((inputData = ALLOC_DYNST(inputSt)) == NULLDYNST)
                {
                    MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
                }

        		if (((*linkedObject) = ALLOC_DYNST(outputSt)) == NULLDYNST)
                {
                    FREE_DYNST(inputData, inputSt);
                    MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
                    return (RET_MEM_ERR_ALLOC);
                }

        		SET_ID(inputData, 0, GET_ID(caseLinkTab[i], A_CaseLink_ObjId));

		        if(DBA_Get2(objectEnum, UNUSED, inputSt, inputData,
		                    outputSt, linkedObject, options, connectNoPtr, UNUSED) != RET_SUCCEED)
		        {
                    FREE_DYNST((*linkedObject), inputSt);
                }
                else
                {
                    *freeFlg = TRUE;
                }

                FREE_DYNST(inputData, inputSt);
            }
		}
	}

    if (freeCaseLinkTab == TRUE)
        DBA_FreeDynStTab(caseLinkTab, caseLinkNbr, A_CaseLink);

    if ((*linkedObject) == NULLDYNST)
    	return(RET_FIN_ERR_ELTNOTFOUND);

    return(RET_SUCCEED);

}

/************************************************************************
**
**  Function      :   FIN_FilterCaseLinkByCaseId()
**
**  Description   :   Return only Case Linked Objects attached to current Case
**                    return TRUE  -> record must be extract
**                           FALSE -> record musn't be extract
**
**  Arguments     :   dynSt    element pointer
**                    dynStTp  element description enum
**
**  Return        :   TRUE or FALSE
**
**  Creation Date :   PMSTA07121-CHU-081031
*************************************************************************
STATIC int FIN_FilterCaseLinkByCaseId(DBA_DYNFLD_STP   caseLnkPtr,
									  DBA_DYNST_ENUM   dynStTp,
									  DBA_DYNFLD_STP   Io_IdPtr)
{
    if (CMP_ID(GET_ID(caseLnkPtr, A_CaseLink_CaseId),GET_ID(Io_IdPtr, Io_Id_Id)) == 0)
    {
        return(TRUE);
    }
    return(FALSE);
}
*/

/***************************************************************************************
**
**  Function    :   FIN_GetBestCaseMsgTemplate()
**
**  Description :   Search the better template to use for a specific Case
**
**  Argument    :
**
**
**  Return      :   RET_SUCCEED or return code
**
**  creation	:   PMSTA07121-DDV-081212
**  Last modif. :
**
***************************************************************************************/
RET_CODE FIN_GetBestCaseMsgTemplate(DBA_DYNFLD_STP	caseRec,
                                    SMALLINT_T      minPriority,
                                    SMALLINT_T      maxPriority,
								    DBA_DYNFLD_STP *templateRec,
                                    int             options,
                                    int             *connectNoPtr)
{
	RET_CODE		ret = RET_SUCCEED;
	DBA_DYNFLD_STP	*templateTab=NULLDYNSTPTR, getArgSt=NULLDYNST;
	int				i, templateNbr=0, best=NO_VALUE;
	int             level1=NO_VALUE, level2=NO_VALUE, level3=NO_VALUE,
	                level4=NO_VALUE, level5=NO_VALUE;
	SMALLINT_T      priority1=NO_VALUE, priority2=NO_VALUE, priority3=NO_VALUE,
	                priority4=NO_VALUE, priority5=NO_VALUE;

    /* load all case templates for the given nature and nature none */
	if ((getArgSt = ALLOC_DYNST(Get_Arg)) == NULL)
	{
		MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "Get_Arg");
		return(RET_MEM_ERR_ALLOC);
	}

    SET_ENUM(getArgSt, Get_Arg_NatEn, GET_ENUM(caseRec, A_CaseManagement_NatEn));

    if (minPriority != NO_VALUE)
    {
        SET_SMALLINT(getArgSt, Get_Arg_Smallint, minPriority);
    }
    else
    {
        SET_SMALLINT(getArgSt, Get_Arg_Smallint, 0);
    }

    if (maxPriority != NO_VALUE)
    {
        SET_SMALLINT(getArgSt, Get_Arg_Smallint2, maxPriority);
    }
    else
    {
        SET_SMALLINT(getArgSt, Get_Arg_Smallint2, MAX_SHORT);
    }

    if ((DBA_Select2(CaseMsgTemplate, UNUSED, Get_Arg, getArgSt,
                     A_CaseMsgTemplate, &templateTab, options, UNUSED,
                     &templateNbr, connectNoPtr, UNUSED)) != RET_SUCCEED)
    {
        FREE_DYNST(getArgSt, Get_Arg);
        return(RET_DBA_ERR_NODATA);
    }
    FREE_DYNST(getArgSt, Get_Arg);

    /* loop on all templates to find the best one */
    /* To determine witch record is the best matching, a hierarchy is define   */
    /* the best matching is level1 and the bad one is level8.                  */
    /* If many records match same criteria the lowest priority is choose       */
    /*                                                                         */
    /* level1 : every fields match (Nature, SubNature, Type)                   */
    /* level2 : matching fields are : Nature, SubNature,                       */
    /* level3 : matching fields are : Nature,            Type,                 */
    /* level4 : matching fields are : Nature,                                  */
    /* level5 : no matching fields. (Nature of the template is none)           */

    for (i=0; i<templateNbr; i++)
    {
        if (CMP_DYNFLD(caseRec, templateTab[i], A_CaseManagement_NatEn,    A_CaseMsgTemplate_CaseNatEn,    EnumType) == 0 &&
            CMP_DYNFLD(caseRec, templateTab[i], A_CaseManagement_SubNatEn, A_CaseMsgTemplate_CaseSubNatEn, EnumType) == 0 &&
            CMP_DYNFLD(caseRec, templateTab[i], A_CaseManagement_TypeId,     A_CaseMsgTemplate_CaseTpId,     EnumType) == 0)
        {
            if (priority1 == NO_VALUE ||
                GET_SMALLINT(templateTab[i], A_CaseMsgTemplate_Priority) < priority1)
            {
                level1=i;
                priority1 = GET_SMALLINT(templateTab[i], A_CaseMsgTemplate_Priority);
            }
        }
        else if (CMP_DYNFLD(caseRec, templateTab[i], A_CaseManagement_NatEn,    A_CaseMsgTemplate_CaseNatEn,    EnumType) == 0 &&
                 CMP_DYNFLD(caseRec, templateTab[i], A_CaseManagement_SubNatEn, A_CaseMsgTemplate_CaseSubNatEn, EnumType) == 0)
        {
            if (priority2 == NO_VALUE ||
                GET_SMALLINT(templateTab[i], A_CaseMsgTemplate_Priority) < priority2)
            {
                level2=i;
                priority2 = GET_SMALLINT(templateTab[i], A_CaseMsgTemplate_Priority);
            }
        }
        else if (CMP_DYNFLD(caseRec, templateTab[i], A_CaseManagement_NatEn,    A_CaseMsgTemplate_CaseNatEn,    EnumType) == 0 &&
                 CMP_DYNFLD(caseRec, templateTab[i], A_CaseManagement_TypeId,     A_CaseMsgTemplate_CaseTpId,     EnumType) == 0)
        {
            if (priority3 == NO_VALUE ||
                GET_SMALLINT(templateTab[i], A_CaseMsgTemplate_Priority) < priority3)
            {
                level3=i;
                priority3 = GET_SMALLINT(templateTab[i], A_CaseMsgTemplate_Priority);
            }
        }
        else if (CMP_DYNFLD(caseRec, templateTab[i], A_CaseManagement_NatEn,    A_CaseMsgTemplate_CaseNatEn,    EnumType) == 0)
        {
            if (priority4 == NO_VALUE ||
                GET_SMALLINT(templateTab[i], A_CaseMsgTemplate_Priority) < priority4)
            {
                level4=i;
                priority4 = GET_SMALLINT(templateTab[i], A_CaseMsgTemplate_Priority);
            }
        }
        else
        {
            if (priority5 == NO_VALUE ||
                GET_SMALLINT(templateTab[i], A_CaseMsgTemplate_Priority) < priority5)
            {
                level5=i;
                priority5 = GET_SMALLINT(templateTab[i], A_CaseMsgTemplate_Priority);
            }
        }
    }

    if (level1 != NO_VALUE)
        best=level1;
    else if (level2 != NO_VALUE)
	    best=level2;
    else if (level3 != NO_VALUE)
        best=level3;
    else if (level4 != NO_VALUE)
        best=level4;
    else if (level5 != NO_VALUE)
        best=level5;

    if (best != NO_VALUE)
    {
        if (((*templateRec) = ALLOC_DYNST(A_CaseMsgTemplate)) == NULLDYNST)
        {
            DBA_FreeDynStTab(templateTab, templateNbr, A_CaseMsgTemplate);
    		MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "A_CaseMsgTemplate");
	    	return(RET_MEM_ERR_ALLOC);
        }

        COPY_DYNST((*templateRec), templateTab[best], A_CaseMsgTemplate);
    }

    DBA_FreeDynStTab(templateTab, templateNbr, A_CaseMsgTemplate);

	return(ret);
}

/***************************************************************************************
**
**  Function    :   FIN_LoadCaseMsgTemplateDef()
**
**  Description :   Load the case message template for the given language
**
**  Argument    :
**
**
**  Return      :   RET_SUCCEED or return code
**
**  creation	:   PMSTA07121-DDV-081215
**  Last modif. :
**
***************************************************************************************/
RET_CODE FIN_LoadCaseMsgTemplateDef(DBA_DYNFLD_STP	templateRec,
								    DICT_T          languageId,
                                    char            **templateDef,
                                    int             options,
                                    int             *connectNoPtr)
{
	RET_CODE		 ret = RET_SUCCEED;
	DBA_DYNFLD_STP	 sTemplateDef=NULLDYNST, templateDefRec=NULLDYNST;
    DBA_DYNFLD_STP	 aScriptDef=NULLDYNST;
	DICT_ATTRIB_STP  attribStp = (DICT_ATTRIB_STP) NULL;

    (*templateDef) = NULL;

    /* load all case templates for the given nature and nature none */
	if ((sTemplateDef = ALLOC_DYNST(S_CaseMsgTemplateDef)) == NULL)
	{
		MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "S_CaseMsgTemplate");
		return(RET_MEM_ERR_ALLOC);
	}

	if ((templateDefRec = ALLOC_DYNST(A_CaseMsgTemplateDef)) == NULL)
	{
        FREE_DYNST(sTemplateDef, S_CaseMsgTemplateDef);
		MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "Get_Arg");
		return(RET_MEM_ERR_ALLOC);
	}

    SET_ID(sTemplateDef,   S_CaseMsgTemplateDef_TemplateId, GET_ID(templateRec, A_CaseMsgTemplate_Id));
    SET_DICT(sTemplateDef, S_CaseMsgTemplateDef_LangDictId, languageId);

    if ((ret = DBA_Get2(CaseMsgTemplateDef, UNUSED, S_CaseMsgTemplateDef, sTemplateDef,
                        A_CaseMsgTemplateDef, &templateDefRec,
                        options, connectNoPtr, UNUSED)) != RET_SUCCEED)
    {
        /* if the given language don't exists, try to load the default one */
        if ((ret == RET_DBA_ERR_NODATA || ret == RET_DBA_INFO_NODATA) &&
            IS_NULLFLD(templateRec, A_CaseMsgTemplate_DefaultLanguage) == FALSE &&
            languageId != GET_DICT(templateRec, A_CaseMsgTemplate_DefaultLanguage))
        {
            FREE_DYNST(sTemplateDef, S_CaseMsgTemplateDef);
            FREE_DYNST(templateDefRec, A_CaseMsgTemplateDef);
            return(FIN_LoadCaseMsgTemplateDef(templateRec, GET_DICT(templateRec, A_CaseMsgTemplate_DefaultLanguage), templateDef, options, connectNoPtr));
        }
    }

    FREE_DYNST(sTemplateDef, S_CaseMsgTemplateDef);

    if (ret != RET_SUCCEED)
    {
        FREE_DYNST(templateDefRec, A_CaseMsgTemplateDef);
        return(ret);
    }

	if ((aScriptDef = ALLOC_DYNST(A_ScriptDef)) == NULL)
	{
        FREE_DYNST(templateDefRec, A_CaseMsgTemplateDef);
		MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "Get_Arg");
		return(RET_MEM_ERR_ALLOC);
	}

	attribStp = DBA_GetAttributeBySqlName(CaseMsgTemplateDef, "script_definition");

	SET_DICT(aScriptDef, A_ScriptDef_AttrDictId, attribStp->attrDictId);
	COPY_DYNFLD(aScriptDef, A_ScriptDef, A_ScriptDef_ObjId,
	            templateDefRec, A_CaseMsgTemplateDef, A_CaseMsgTemplateDef_Id);
	SET_ENUM(aScriptDef, A_ScriptDef_NatEn, ScriptDef_ObjDefVal);

    FREE_DYNST(templateDefRec, A_CaseMsgTemplateDef);

    ret = DBA_Get2(ScriptDef, UNUSED, A_ScriptDef, aScriptDef,
                   A_ScriptDef, &aScriptDef,
                   options, connectNoPtr, UNUSED);

    if (ret == RET_SUCCEED)
    {
    	if (((*templateDef) = (char *) CALLOC(GET_STRING_LEN(aScriptDef, A_ScriptDef_Def)+1, sizeof(char))) == NULL)
	    {
            FREE_DYNST(aScriptDef, A_ScriptDef);
		    MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "A_ScriptDef");
		    return(RET_MEM_ERR_ALLOC);
	    }
        strcpy((*templateDef), GET_STRING(aScriptDef, A_ScriptDef_Def));
    }

    FREE_DYNST(aScriptDef, A_ScriptDef);
    return(ret);
}

/***************************************************************************************
**
**  Function    :   FIN_CaseSessionBlockingCheckConfirmedFlag()
**
**  Description :   Check if Case on order should block the session (confirm_f)
**
**  Argument    :   casePtr - current case
**
**  Return      :   RET_SUCCEED or return code
**
**  creation	:   PMSTA09793-CHU-100514
**
**  Last modif. :
**
***************************************************************************************/
FLAG_T FIN_CaseSessionBlockingCheckConfirmedFlag(DBA_DYNFLD_STP	casePtr)
{
	FLAG_T			applOrderConfirmedFlagMgmt=FALSE, freeFlg=FALSE;
	DBA_DYNFLD_STP	eOpLnkObjPtr = NULL;
	FLAG_T			blockSessionFlg = TRUE;

	GEN_GetApplInfo(ApplOrderConfirmedFlagMgmt, &applOrderConfirmedFlagMgmt);

	if (applOrderConfirmedFlagMgmt != FALSE)
	{
		if (FIN_GetCaseLinkedObject((DBA_HIER_HEAD_STP)NULL,
									 casePtr, EOp,
									 &eOpLnkObjPtr, &freeFlg,
									 UNUSED, UNUSED) == RET_SUCCEED)
		{
			if (eOpLnkObjPtr != NULL)
			{
				/* never block a session for an order blocking a trading Constraint
				if (GET_FLAG(eOpLnkObjPtr, ExtOp_ConfirmedFlg) == FALSE)
				{
				*/
					blockSessionFlg = FALSE;
				/*}*/
				if (freeFlg == TRUE)
				{
					FREE_DYNST(eOpLnkObjPtr, ExtOp);
				}
			}
		}
	}

	return(blockSessionFlg);
}


/************************************************************************
**
**  Function    :   FIN_FindOrdDetFromESE()
**
**  Description :   Filter out the ptf-instr combination record from ESE
**                  return TRUE  -> record must be extract
**                         FALSE -> record musn't be extract
**
**  Arguments   :   dynSt       element pointer
**                  dynStTp     element description enum
**                  parESE      parent ESE
**
**  Return      :   TRUE or FALSE
**
**  Creation Date : WEALTH-9957-Satya
**
*************************************************************************/
STATIC int FIN_FindOrdDetFromESE(DBA_DYNFLD_STP   dynSt,
    DBA_DYNST_ENUM   dynStTp,
    DBA_DYNFLD_STP   ESEArgPtr)
{
    if ((0 == CMP_DYNFLD(dynSt, ESEArgPtr, ExtStratElt_InstrId, Adm_Arg_UserId, IdType)) &&
        (GET_ENUM(dynSt, ExtStratElt_StratNatEn) == StratNat_ModelPtf) &&
        (GET_ENUM(dynSt, ExtStratElt_NatEn) == ExtStratEltNat_OrderDetail) &&
        (0 == CMP_DYNFLD(dynSt, ESEArgPtr, ExtStratElt_ChildPtfId, Adm_Arg_Id, IdType)))
    {
        return(TRUE);
    }

    return(FALSE);
}


/************************************************************************
**
**  Function    :   FIN_GenerateCasesOnMessages()
**
**  Description :   convert message from IC in cases.
**                  - msg Error     -> case High
**                  - msg Warning   -> case Medium
**                  - msg Info      -> case Low
**
**  Arguments   :
**
**  Return      :   RET_SUCCEED	or error code
**
**  Creation    :   FPL-PMSTA10166-100630
**
**  Modif.      :   PMSTA10444-CHU-110511 - removed hard coded Case codes
**                                        - set INFO msg criticalness to NotCritical
**
*************************************************************************/
RET_CODE    FIN_GenerateCasesOnMessages ( DBA_HIER_HEAD_STP     hierPtr
                                        , DBA_DYNFLD_STP        *dynEOpTab
                                        , int                   iNbEOp
                                        , DBA_DYNFLD_STP        domainPtr
                                        , DBA_DYNFLD_STP        **caseMgtTab
                                        , int                   *piNbMsg
                                        , int                   *connectNo
                                        )
{
    int                         iExtOpIdx ;
    int                         iMsgIdx             = 0 ;
    RET_CODE                    retCode             = RET_SUCCEED ;
    DBA_DYNFLD_STP              dynCase ;
    DBA_DYNFLD_STP              *msgTab             = NULL;
    int                         msgNb               = 0;
    int                         i ;
    DBA_DYNFLD_STP              dynPtf ;
    DICT_T                      entityDictId;
    CONSTRCRITICALNESS_ENUM     biggestCriticityEn  = ConstrCriticalness_None ;
    CONSTRCRITICALNESS_ENUM     applSessionBlockCriticalness ;
	CONSTRCRITICALNESS_ENUM     applICWarningCriticalness ; /* PMSTA10444-CHU-110503 */
    OPNAT_ENUM                  opnatTab[2];
    int                         iNbOpType;
    int                         z ;
    DBA_DYNFLD_STP              *extPosTab ;
    int                         iNbExtPos ;
    PTR                         ptrIc           = NULL ;    /*  timer   */
    PTR                         ptrFillExtPos   = NULL ;    /*  timer   */
    PTR                         ptrAlloc        = NULL ;    /*  timer   */
    PTR                         ptrAllocCM      = NULL ;    /*  timer   */
    PTR                         ptrGC           = NULL ;    /*  timer   */
    DBA_DYNFLD_STP              *compoundExtOpTab = NULLDYNSTPTR;
    int                         compoundExtOpNbr = 0;
    DBA_HIER_HEAD_STP           localHierPtr = NULL;
    MemoryPool                  mp;
    INT_T                       OrdDetNbr = 0;
    DBA_DYNFLD_STP              ESEArgPtr = NULLDYNST, *OrdDetESETab = nullptr;

    *piNbMsg            = 0 ;
    *caseMgtTab         = NULL ;
    opnatTab[0]         = OpNat_Sell;
    opnatTab[1]         = OpNat_Buy;
    iNbOpType           = 2;
    extPosTab           = NULL ;
    iNbExtPos           = 0 ;


	if (iNbEOp > 0) /* OCS-45596 - CHU - 150115 : avoid calloc() error if no orders in session */
	{
		if ((compoundExtOpTab = (DBA_DYNFLD_STP *)CALLOC(iNbEOp, sizeof(DBA_DYNFLD_STP))) == NULL)
			return RET_MEM_ERR_ALLOC;

		/* PMSTA-18601 - DDV - 141204 - Search all compound orders */
		for (i = 0; i < iNbEOp; i++)
		{
			if (IS_NULLFLD(dynEOpTab[i], ExtOp_CompoundOrderMasterEltId) == FALSE)
			{
				compoundExtOpTab[compoundExtOpNbr] = dynEOpTab[i];
				compoundExtOpNbr++;
			}
		}

		/* PMSTA-18601 - DDV - 141204 - If compound orders present, check their validity
		   and build links needed by GET_MASTER() GET_SLAVE and GET_SLAVEARRAY() script keywords */
		if (compoundExtOpNbr > 0)
		{
			if (FIN_CheckValidCompoundOrder(compoundExtOpTab, compoundExtOpNbr) != RET_SUCCEED)
			{
				FREE(compoundExtOpTab);
				return(RET_DBA_ERR_INVDATA);
			}

			if ((localHierPtr = DBA_CreateHier()) != NULL)
			{
				DBA_SetDoNotDeleteRecFlag(localHierPtr, ExtOp, TRUE);
				DBA_AddHierRecordList(localHierPtr, compoundExtOpTab, compoundExtOpNbr, ExtOp, FALSE);
				DBA_SetHierLnkUsed(localHierPtr, ExtOp, ExtOp_CompoundOrderMasterElt_Ext);
				DBA_SetHierLnkUsed(localHierPtr, ExtOp, ExtOp_CompoundOrderSlaveElt_Ext);
				DBA_MakeAllRecLinks(localHierPtr, ExtOp);
			}
		}
	}

    FREE(compoundExtOpTab);

    if ((dynPtf = ALLOC_DYNST(A_Ptf)) == NULL)
    {
        return RET_MEM_ERR_ALLOC;
    }

	/* PMSTA10444-CHU-110503 */
	GEN_GetApplInfo(ApplICWarningCriticalness, &applICWarningCriticalness);
	if (applICWarningCriticalness < ConstrCriticalness_Low ||
		applICWarningCriticalness > ConstrCriticalness_Medium)
	{
		/* restrict value to Low or Medium, default to Low */
		applICWarningCriticalness = ConstrCriticalness_Low;
	}

    for (z = 0; z < iNbOpType; z++)
    {
        for (iExtOpIdx = 0 ; iExtOpIdx < iNbEOp ; iExtOpIdx++ )
        {
            msgNb = 0;
            /*  first z=0 -> buy, second z=1 -> sell    */
            if ((dynEOpTab[iExtOpIdx] != NULLDYNST) &&
                (((z == 0) &&
                  (GET_ENUM(dynEOpTab[iExtOpIdx], ExtOp_NatureEn) == opnatTab[0])) ||
                 ((z != 0) &&
                  (GET_ENUM(dynEOpTab[iExtOpIdx], ExtOp_NatureEn) != opnatTab[0]))))
            {
                /* PMSTA-17695 - DDV - 140303 - Purify, moved at the end of loop to free last element
                for ( i = 0 ; i < msgNb ; i++ )
                    FREE_DYNST(msgTab[i], Msg);
                FREE(msgTab);
                */

                /* PMSTA-27395 - CHU - 170524 */
                if (DBA_IsRejectedOrder(dynEOpTab[iExtOpIdx]) == FALSE)
                {
                    MSG_StartCumulTimerPmon("SCPT_ComputeScreenIC", &ptrIc);
                    msgTab = NULL;
                    msgNb = 0;

                    if(SCPT_ComputeScreenIC (  EOp
                                             , DictFct_VerifySessionIC
                                             , dynEOpTab[iExtOpIdx]
                                             , NULL                     /*  old dyn             */
                                             , domainPtr
                                             , &msgNb
                                             , &msgTab
                                             , TRUE                     /*  gui flag TRUE       */
                                             , 0                        /*  screenId            */
                                             , DictScreen
                                             , NULL                     /*  pdbadynReference    */
                                             , NullEntity               /*  enObjectReference   */
                                             , extPosTab                /*  extPosTab           */
                                             , iNbExtPos                /*  extPosNbr           */
                                             , NULL                     /*  hierStp             */
                                             , ScptActionNone
                                             , connectNo
                                             , GET_DICT(dynEOpTab[iExtOpIdx], ExtOp_CompoundScreenDictId)
                                            ) != 0)
                    {
                        retCode = RET_GEN_ERR_INVARG;
                    }
                    MSG_StopCumulTimerPmon(&ptrIc);

                }

                if (retCode == RET_SUCCEED)
                {
                    MSG_StartCumulTimerPmon("SCPT_FinaFillExternalExtPosTab", &ptrFillExtPos);
                    retCode = SCPT_FinaFillExternalExtPosTab (dynEOpTab[iExtOpIdx], &(extPosTab), &(iNbExtPos));
                    MSG_StopCumulTimerPmon(&ptrFillExtPos);
                }

                for (iMsgIdx = 0 ; iMsgIdx < msgNb ; iMsgIdx++)
                {
                    MSG_StartCumulTimerPmon("CALLOC/REALLOC caseMgt array", &ptrAlloc);
                    /*  alloc array + 1 to add a global case management with highest criticity  */
                    if ((*caseMgtTab) == NULL)
                    {
                        if (((*caseMgtTab) = (DBA_DYNFLD_STP *)CALLOC(msgNb+1, sizeof(DBA_DYNFLD_STP))) == NULL)
                        {
                            /* PMSTA-17695 - DDV - 140303 - Purify, free msgTab */
                            for ( i = 0 ; i < msgNb ; i++ )
                                FREE_DYNST(msgTab[i], Msg);
                            FREE(msgTab);
                            msgNb = 0;
                            if (localHierPtr != NULL) { DBA_FreeHier(localHierPtr); }

                            MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "A_CaseManagement");
                            return RET_MEM_ERR_ALLOC;
                        }
                    }
                    else
                    {
                        if (((*caseMgtTab) = (DBA_DYNFLD_STP *)REALLOC((*caseMgtTab) , (msgNb+(*piNbMsg)+1) * sizeof(DBA_DYNFLD_STP))) == NULL)
                        {
                            /* PMSTA-17695 - DDV - 140303 - Purify, free msgTab */
                            for ( i = 0 ; i < msgNb ; i++ )
                                FREE_DYNST(msgTab[i], Msg);
                            FREE(msgTab);
                            msgNb = 0;

                            if (localHierPtr != NULL) { DBA_FreeHier(localHierPtr); }
                            MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "A_CaseManagement");
                            return RET_MEM_ERR_ALLOC;
                        }
                    }
                    MSG_StopCumulTimerPmon(&ptrAlloc);


                    MSG_StartCumulTimerPmon("Alloc and fill caseMgt", &ptrAllocCM);
                    if ((dynCase = ALLOC_DYNST(A_CaseManagement)) != NULL)
                    {
                        (*caseMgtTab)[*piNbMsg] = dynCase ;

                        DBA_SetDfltEntityFld(CaseManagement, A_CaseManagement, dynCase);

                        DBA_DYNFLD_STP ptfPtr = nullptr;

                        switch (GET_ENUM(msgTab[iMsgIdx], Msg_NatEn))
                        {
                            case MsgNat_Error :
                                SET_ENUM(dynCase, A_CaseManagement_CriticalnessEn,  ConstrCriticalness_High);
                                if (biggestCriticityEn < ConstrCriticalness_High)
                                    biggestCriticityEn = ConstrCriticalness_High ;
                                break;

                            case MsgNat_Warning :
								SET_ENUM(dynCase, A_CaseManagement_CriticalnessEn,  applICWarningCriticalness); /* PMSTA10444-CHU-110503 */
                                if (biggestCriticityEn < applICWarningCriticalness)
                                    biggestCriticityEn = applICWarningCriticalness ;
                                break;

                            case MsgNat_Info :
                                SET_ENUM(dynCase, A_CaseManagement_CriticalnessEn,  ConstrCriticalness_NotCritical); /* PMSTA10444-CHU-110503 */
                                if (biggestCriticityEn < ConstrCriticalness_NotCritical)
                                    biggestCriticityEn = ConstrCriticalness_NotCritical ;
                                break;

                            default :
                                break ;

                        }

                        COPY_DYNFLD ( dynCase,              A_CaseManagement,   A_CaseManagement_SessionId,
                                      domainPtr,            A_Domain,           A_Domain_FctResultId);

                        COPY_DYNFLD ( dynCase,              A_CaseManagement,   A_CaseManagement_PtfId,
                                      dynEOpTab[iExtOpIdx], ExtOp,              ExtOp_PtfId);

                        COPY_DYNFLD ( dynCase,              A_CaseManagement,   A_CaseManagement_InstrId,
                                      dynEOpTab[iExtOpIdx], ExtOp,              ExtOp_InstrId);

                        COPY_DYNFLD ( dynCase,              A_CaseManagement,   A_CaseManagement_Description,
                                      msgTab[iMsgIdx],      Msg,                Msg_String);

                        COPY_DYNFLD( dynCase,               A_CaseManagement,   A_CaseManagement_CaseManagementTypeId,
                                     msgTab[iMsgIdx],       Msg,                Msg_CaseMgtTypeId);  /* WEALTH-9976 - KKM - 24072024 */

                        SET_ENUM ( dynCase, A_CaseManagement_NatEn,    CaseManagementNat_InputCtrl);
                        SET_ENUM ( dynCase, A_CaseManagement_SubNatEn, CaseManagementSubNat_OrderIC);

                        /* session id */
                        DBA_GetDictId(FctResult, &entityDictId);
                        SET_DICT ( dynCase, A_CaseManagement_MainEntityDictId, entityDictId);
                        SET_ID   (dynCase,  A_CaseManagement_MainObjId,  GET_ID(domainPtr, A_Domain_FctResultId));

                        /*WEALTH-7147-Satya*/
                        if (DBA_GetRecPtrFromHierById(hierPtr, GET_ID(dynCase, A_CaseManagement_PtfId), A_Ptf, &ptfPtr) == RET_SUCCEED &&
                            ptfPtr != nullptr)
                        {
                            if (IS_NULLFLD(ptfPtr, A_Ptf_HierPortId) == FALSE){
                                SET_ID(dynCase, A_CaseManagement_ParentPortId, GET_ID(ptfPtr, A_Ptf_HierPortId));
                            }
                            else{
                                SET_ID(dynCase, A_CaseManagement_ParentPortId, GET_ID(dynCase, A_CaseManagement_PtfId));
                            }                                
                        }

                        if (ptfPtr == nullptr)
                        {
                            ESEArgPtr = mp.allocDynst(FILEINFO, Adm_Arg);
                            SET_ID(ESEArgPtr, Adm_Arg_Id, GET_ID(dynEOpTab[iExtOpIdx], ExtOp_PtfId));
                            SET_ID(ESEArgPtr, Adm_Arg_UserId, GET_ID(dynEOpTab[iExtOpIdx], ExtOp_InstrId));

                            if (RET_SUCCEED != (retCode = DBA_ExtractHierEltRecWithFilterSt(hierPtr,
                                ExtStratElt,
                                FALSE,
                                (HIER_FLTFCT*)FIN_FindOrdDetFromESE,
                                ESEArgPtr,
                                NULLFCT,
                                &OrdDetNbr,
                                &OrdDetESETab)))
                            {
                                MSG_SendMesg(FILEINFO, "FIN_PostTradeBuilder: Unable to extract records from Hierarchy");
                            }
                            mp.owner(OrdDetESETab);

                            if (OrdDetNbr > 0)
                            {
                                SET_ID(dynCase, A_CaseManagement_ParentPortId, GET_ID(OrdDetESETab[0], ExtStratElt_PtfId));
                            }
                            else
                            {
                                SET_ID(dynCase, A_CaseManagement_ParentPortId, GET_ID(dynEOpTab[iExtOpIdx], ExtOp_PtfId));
                            }
                        }

                        if ((retCode = DBA_AddHierRecord ( hierPtr
                                                         , dynCase
                                                         , A_CaseManagement
                                                         , TRUE
                                                         , HierAddRec_NoLnk)) != RET_SUCCEED)
                        {
                            /* PMSTA-17695 - DDV - 140303 - Purify, free msgTab */
                            for ( i = 0 ; i < msgNb ; i++ )
                                FREE_DYNST(msgTab[i], Msg);
                            FREE(msgTab);
                            msgNb = 0;

                            if (localHierPtr != NULL) { DBA_FreeHier(localHierPtr); }
                            FREE_DYNST(dynCase, A_CaseManagement);
                            return(retCode);
                        }

                        /* Add Portfolio to Case Linked Objects */
                        if (IS_NULLFLD(dynCase, A_CaseManagement_PtfId) == FALSE)
                        {
                            DBA_GetDictId(Ptf, &entityDictId);
                            if((retCode = FIN_AddCaseLinkedObject ( domainPtr
                                                                  , hierPtr
                                                                  , dynCase
                                                                  , entityDictId
                                                                  , GET_ID(dynCase, A_CaseManagement_PtfId)
                                                                  )) != RET_SUCCEED)
                            {
                                /* PMSTA-17695 - DDV - 140303 - Purify, free msgTab */
                                for ( i = 0 ; i < msgNb ; i++ )
                                    FREE_DYNST(msgTab[i], Msg);
                                FREE(msgTab);
                                msgNb = 0;

                                if (localHierPtr != NULL) { DBA_FreeHier(localHierPtr); }
                                return(retCode);
                            }
                        }


                        /* Add Instrument to Case Linked Objects */
                        if (IS_NULLFLD(dynCase, A_CaseManagement_InstrId) == FALSE)
                        {
                            DBA_GetDictId(Instr, &entityDictId);
                            if ((retCode = FIN_AddCaseLinkedObject ( domainPtr
                                                                   , hierPtr
                                                                   , dynCase
                                                                   , entityDictId
                                                                   , GET_ID(dynCase, A_CaseManagement_InstrId)
                                                                   )) != RET_SUCCEED)
                            {
                                /* PMSTA-17695 - DDV - 140303 - Purify, free msgTab */
                                for ( i = 0 ; i < msgNb ; i++ )
                                    FREE_DYNST(msgTab[i], Msg);
                                FREE(msgTab);
                                msgNb = 0;

                                if (localHierPtr != NULL) { DBA_FreeHier(localHierPtr); }
                                return(retCode);
                            }
                        }

                        /* Add order to case    */
                        if (dynEOpTab[iExtOpIdx] != NULLDYNST)
                        {
                            ID_T extOpId = OPE_GetOpIdFromExtOp(dynEOpTab[iExtOpIdx]); /* PMSTA-24581 - CHU - 160826 */
                            DBA_GetDictId(EOp, &entityDictId);
                            if ((retCode = FIN_AddCaseLinkedObject ( domainPtr
                                                                   , hierPtr
                                                                   , dynCase
                                                                   , entityDictId
                                                                   , extOpId /* GET_ID(dynEOpTab[iExtOpIdx], ExtOp_OpId) */ /* PMSTA-24581 - CHU - 160826 : 'connerie' if ExtOp_OpId is NULL */
                                                                   )) != RET_SUCCEED)
                            {
                                /* PMSTA-17695 - DDV - 140303 - Purify, free msgTab */
                                for ( i = 0 ; i < msgNb ; i++ )
                                    FREE_DYNST(msgTab[i], Msg);
                                FREE(msgTab);
                                msgNb = 0;

                                if (localHierPtr != NULL) { DBA_FreeHier(localHierPtr); }
                                return(retCode);
                            }
                        }

                    }
                    (*piNbMsg)++;
                    MSG_StopCumulTimerPmon(&ptrAllocCM);
                }

                /* PMSTA-17695 - DDV - 140303 - Purify, moved here to free last element */
                for ( i = 0 ; i < msgNb ; i++ )
                    FREE_DYNST(msgTab[i], Msg);
                FREE(msgTab);
                msgNb = 0;
            }
        }
    }

    if (localHierPtr != NULL) { DBA_FreeHier(localHierPtr); }
	DBA_FreeDynStTab(extPosTab, iNbExtPos, ExtPos); /* PMSTA14453 - DDV - 120712 - Purify */

    /***  Add a parent case for the session ***/
    if (/*((*piNbMsg) > 0) &&*/ /*  if no cases, we don't create a global one.*/    /*FPL-PMSTA10614-100924 Create a global case, even if no cases  */
        ((dynCase = ALLOC_DYNST(A_CaseManagement)) != NULL))
    {
        MSG_StartCumulTimerPmon("Global Case", &ptrGC);
        /*  FPL-PMSTA10614-100927 No cases, only a global one -> alloc the global case  */
        if ((*caseMgtTab) == NULL)
        {
            if (((*caseMgtTab) = (DBA_DYNFLD_STP *)CALLOC((*piNbMsg)+1, sizeof(DBA_DYNFLD_STP))) == NULL)
            {
                MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "A_CaseManagement");
                return RET_MEM_ERR_ALLOC;
            }
        }

        (*caseMgtTab)[*piNbMsg] = dynCase ;     /*  caseMgtTab already has the good size, no need to realloc    */
        (*piNbMsg) ++ ;

        DBA_SetDfltEntityFld(CaseManagement, A_CaseManagement, dynCase);

        SET_ENUM(dynCase, A_CaseManagement_CriticalnessEn,  biggestCriticityEn );

        COPY_DYNFLD ( dynCase,              A_CaseManagement,   A_CaseManagement_SessionId,
                      domainPtr,            A_Domain,           A_Domain_FctResultId);

        SET_ENUM ( dynCase, A_CaseManagement_NatEn,    CaseManagementNat_InputCtrl);
        SET_ENUM ( dynCase, A_CaseManagement_SubNatEn, CaseManagementSubNat_SessionICStatus);

        /* session id */
        DBA_GetDictId(FctResult, &entityDictId);
        SET_DICT ( dynCase, A_CaseManagement_MainEntityDictId, entityDictId);
        SET_ID   (dynCase,  A_CaseManagement_MainObjId,  GET_ID(domainPtr, A_Domain_FctResultId));

        if ((retCode = DBA_AddHierRecord ( hierPtr
                                         , dynCase
                                         , A_CaseManagement
                                         , TRUE
                                         , HierAddRec_NoLnk)) != RET_SUCCEED)
        {
            FREE_DYNST(dynCase, A_CaseManagement);
            return(retCode);
        }

        FIN_CaseMakeExtensionsAndDefVal(domainPtr, hierPtr, NULL);

        MSG_StopCumulTimerPmon(&ptrGC);
    }
    FREE_DYNST(dynPtf, A_Ptf);

    /*  Set flag to say if there is an error or not */
	GEN_GetApplInfo(ApplSessionBlockCriticalness, &applSessionBlockCriticalness);
    if (biggestCriticityEn >= applSessionBlockCriticalness)
    {
        SET_FLAG(domainPtr, A_Domain_SessionInErrorFlg, TRUE);
    }
    else
    {
        SET_FLAG(domainPtr, A_Domain_SessionInErrorFlg, FALSE);
    }

    return retCode ;
}



/************************************************************************
**
**  Function    :   FIN_CheckIfSessionIsClearToGo()
**
**  Description :   Set the domain fields case_to_clarify_n and session_in_error_f
**                  if there are case pending for a session
**
**  Arguments   :   An A_Domain DBA_DYNFLD_STP
**
**  Return      :   RET_SUCCEED	or error code
**
**  Creation    :   DLA - PMSTA-11605 - 110415
**
*************************************************************************/
RET_CODE FIN_CheckIfSessionIsClearToGo(DBA_DYNFLD_STP dbaDynTab)
{
	DBA_DYNFLD_STP	inputSt = NULLDYNSTPTR;
	DBA_DYNFLD_STP	*caseMgtTab=NULLDYNSTPTR;
	ENUM_T			applStratBlockConstrCriticalness ;
	ENUM_T			applSessionBlockCriticalness ;
	CASEMANAGEMENTSTATUS_ENUM applCaseClarificationStatus = CaseManagementStatus_NotClarified; /* PMSTA-17573-CHU-140208 */
	DICT_T			entityDictId;
	FLAG_T			applCaseActivationFlag;
	FLAG_T			blockCriticalnessFlg=FALSE;
	int				sumBlockingCaseNbr=0;
	int				i, caseMgtNbr=0;

	if ( dbaDynTab->dynStEnum == A_Domain &&
		 !IS_NULLFLD(dbaDynTab, A_Domain_FctResultId))
	{
		inputSt = (DBA_DYNFLD_STP) ALLOC_DYNST(S_CaseManagement);
		SET_ID(inputSt, S_CaseManagement_SessionId, GET_ID(dbaDynTab,A_Domain_FctResultId))
		SET_ENUM(inputSt, S_CaseManagement_NatEn, DomSessionNat_None ); /* All cases */
		DBA_GetDictId(FctResult, &entityDictId);
		SET_DICT(inputSt, A_CaseManagement_MainEntityDictId, entityDictId );

		if (DBA_Select2( CaseManagement,
						 UNUSED,
						 S_CaseManagement,
						 inputSt,
						 A_CaseManagement,
						 &caseMgtTab,
						 UNUSED,
						 UNUSED,
						 &caseMgtNbr,
						 UNUSED,
						 NULL) != RET_SUCCEED)
		{
			MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "An error occurs while select CaseManagement records");
		}

		if (caseMgtNbr > 0)
		{
			GEN_GetApplInfo(ApplCaseActivationFlag,				&applCaseActivationFlag);
			GEN_GetApplInfo(ApplStratBlockConstrCriticalness,   &applStratBlockConstrCriticalness);
			GEN_GetApplInfo(ApplSessionBlockCriticalness,       &applSessionBlockCriticalness);
			GEN_GetApplInfo(ApplCaseClarificationStatus,		&applCaseClarificationStatus); /* PMSTA-17573-CHU-140208 */

			for (i=0; i<caseMgtNbr ; i++)
			{
				if ((IS_NULLFLD(caseMgtTab[i], A_CaseManagement_CriticalnessEn) == FALSE) &&
					(GET_ENUM(  caseMgtTab[i], A_CaseManagement_CriticalnessEn) >= applSessionBlockCriticalness)&&
					(FIN_CaseSessionBlockingCheckConfirmedFlag(caseMgtTab[i]) == TRUE))
                {
                    blockCriticalnessFlg = TRUE;
                }


                if ((GET_ENUM( caseMgtTab[i], A_CaseManagement_NatEn) != CaseManagementNat_InputCtrl) &&
					(IS_NULLFLD(caseMgtTab[i], A_CaseManagement_CriticalnessEn) == FALSE) &&
                    (GET_ENUM( caseMgtTab[i], A_CaseManagement_CriticalnessEn) >= applStratBlockConstrCriticalness) &&
					(GET_ENUM( caseMgtTab[i], A_CaseManagement_CriticalnessEn) > ConstrCriticalness_None) &&
                    (IS_NULLFLD( caseMgtTab[i], A_CaseManagement_StatusEn) == FALSE) &&
                    (GET_ENUM( caseMgtTab[i], A_CaseManagement_StatusEn) < applCaseClarificationStatus)) /* PMSTA-17573-CHU-140208 */
				{
					sumBlockingCaseNbr++;
				}
			}
		}

		SET_INT(dbaDynTab, A_Domain_CaseToClarify, sumBlockingCaseNbr);
		SET_FLAG(dbaDynTab, A_Domain_SessionInErrorFlg, blockCriticalnessFlg);
	}
	return RET_SUCCEED;
}

/***************************************************************************************
**
**  Function    :   FIN_LoadCaseRule()
**
**  Description :   Load the case rule
**
**  Argument    :
**
**
**  Return      :   RET_SUCCEED or return code
**
**  creation	:   PMSTA- 18760 -cashwini-140205
**  Last modif. :
**
***************************************************************************************/
RET_CODE FIN_LoadCaseRule(DBA_DYNFLD_STP domainPtr, DBA_DYNFLD_STP **caseRuleTabPtr, int *caseRuleNbr)
{
	DBA_DYNFLD_STP	inputSt = NULL;
	RET_CODE			ret = RET_SUCCEED;

    if (!IS_NULLFLD(domainPtr, A_Domain_FctDictId))
	{
		if ((inputSt = ALLOC_DYNST(A_CaseRule)) == NULL)
		{
			MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "A_CaseRule");
			return(RET_MEM_ERR_ALLOC);
		}

        SET_ID(inputSt, A_CaseRule_FunctionDictId, GET_ID(domainPtr,A_Domain_FctDictId));

		if ((ret = DBA_Select2(CaseRule,
						 UNUSED,
						 A_CaseRule,
						 inputSt,
						 A_CaseRule,
						 caseRuleTabPtr,
						 UNUSED,
						 UNUSED,
						 caseRuleNbr,
						 UNUSED,
						 UNUSED)) != RET_SUCCEED)
		{
			MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "An error occurs while select CaseRule records");
			FREE_DYNST(inputSt, A_CaseRule);
			return(RET_DBA_ERR_NODATA);
		}
		FREE_DYNST(inputSt, A_CaseRule);
	}
	return ret;
}

/***************************************************************************************
**
**  Function    :   FIN_CreateCaseRuleCase()
**
**  Description :   Load the case rule
**
**  Argument    :
**
**
**  Return      :   RET_SUCCEED or return code
**
**  creation	:   PMSTA- 18760 -cashwini-140205
**  Last modif. :
**
***************************************************************************************/
RET_CODE FIN_CreateCaseRuleCase(DBA_DYNFLD_STP		domainPtr,
							        PTR            	argHierHead)
{
	RET_CODE			ret = RET_SUCCEED;
 	DBA_HIER_HEAD_STP	hierHead=(DBA_HIER_HEAD_STP)argHierHead;
	int				recordNbr=0, i = 0, recordNbr1=0;
	DBA_DYNST_ENUM  dynStEnum;
	DBA_DYNFLD_STP	*caseRuleTabPtr=NULL;
	int caseRuleNbr;
	DBA_DYNFLD_STP   aScriptDef=NULLDYNST;
	DICT_ATTRIB_STP	 filterDictAttrStp, defDictAttrStp;
	DBA_DYNFLD_STP	 *recordTab=NULL;
	SCPT_ARG_STP localFilterTree = NULL;
	OBJECT_ENUM	object=NullEntity;
	DBA_DYNFLD_STP   evalRec = (DBA_DYNFLD_STP)NULL;
    int              incrNb = 0, row=0;

	if (hierHead == NULL)
	{
		if ((hierHead=(DBA_HIER_HEAD_STP)DBA_GetHierOptiPtr())==NULL)
        {
	        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
		                 "FIN_CreateCaseRuleCase", "hierarchy is mandatory");
	        return(RET_GEN_ERR_INVARG);
        }
	}

	if ((ret = FIN_LoadCaseRule(domainPtr, &caseRuleTabPtr, &caseRuleNbr)) != RET_SUCCEED)
    {
        return(ret);
    }

    if (DBA_SearchAttribSqlName(CaseRule, "filter", &filterDictAttrStp) != RET_SUCCEED)
	{
		MSG_SendMesg(RET_DBA_ERR_MD, 1, FILEINFO, "case_rule", "filter");
		DBA_FreeDynStTab(caseRuleTabPtr,caseRuleNbr,A_CaseRule);
		return RET_DBA_ERR_MD;
	}

	if (DBA_SearchAttribSqlName(CaseRule, "definition", &defDictAttrStp) != RET_SUCCEED)
	{
		MSG_SendMesg(RET_DBA_ERR_MD, 1, FILEINFO, "case_rule", "definition");
		DBA_FreeDynStTab(caseRuleTabPtr,caseRuleNbr,A_CaseRule);
		return RET_DBA_ERR_MD;
	}

	if ((aScriptDef = ALLOC_DYNST(A_ScriptDef)) == NULLDYNST)
	{
		DBA_FreeDynStTab(caseRuleTabPtr,caseRuleNbr,A_CaseRule);
		MSG_RETURN(RET_MEM_ERR_ALLOC);
	}

	for (i=0; i<caseRuleNbr; i++)
	{
		DBA_GetObjectEnum(GET_DICT(caseRuleTabPtr[i], A_CaseRule_EntityDictId), &object);
		dynStEnum = GET_EDITGUIST(object);

		if (GET_FLAG(caseRuleTabPtr[i], A_CaseRule_ActiveFlag) != FALSE)
		{
			SET_DICT(aScriptDef, A_ScriptDef_AttrDictId, filterDictAttrStp->attrDictId);
			COPY_DYNFLD(aScriptDef,    A_ScriptDef,  A_ScriptDef_ObjId,
			            caseRuleTabPtr[i], A_CaseRule, A_CaseRule_Id);
			SET_ENUM(aScriptDef, A_ScriptDef_NatEn, ScriptDef_ObjDefVal);

			if((ret = DBA_Get2(ScriptDef, UNUSED, A_ScriptDef, aScriptDef,
			                                     A_ScriptDef, &aScriptDef,
                                        UNUSED, NULL, UNUSED)) != RET_SUCCEED )
			{
				DBA_FreeDynStTab(caseRuleTabPtr,caseRuleNbr,A_CaseRule);
				FREE_DYNST(aScriptDef, A_ScriptDef);
				return ret;
			}

			/* Extract all records according to filter and supress all NULL values */
			recordNbr1 = DBA_GetHierEltWithScptFilter(hierHead,
                                                    dynStEnum,
                                                         NULL,
                                                         NULL,
					   GET_STRING(aScriptDef,A_ScriptDef_Def),
                                                    domainPtr,
                                                        FALSE,
                                                   &recordNbr,
                                                  &recordTab);

			if (recordNbr1 != recordNbr) /* OCS-47253 - CHU - 151027 : adjust record number... else Boom! */
			{
				int pos = 0, j = 0;

				if (recordNbr1 != 0 && recordTab != NULL)
				{
					for (j = 0, pos = 0; j < recordNbr; j++)
					{
						if (recordTab[j] == NULLDYNSTPTR)
							continue;
						recordTab[pos] = recordTab[j];
						pos++;
					}
				}
				recordNbr = pos;
			}

			SET_DICT(aScriptDef, A_ScriptDef_AttrDictId, defDictAttrStp->attrDictId);
			SET_ENUM(aScriptDef, A_ScriptDef_NatEn, ScriptDef_ObjDefVal);

			if((ret = DBA_Get2(ScriptDef, UNUSED, A_ScriptDef, aScriptDef,
                                                  A_ScriptDef, &aScriptDef,
                                      UNUSED, NULL, UNUSED)) != RET_SUCCEED )
			{
				DBA_FreeDynStTab(caseRuleTabPtr,caseRuleNbr,A_CaseRule);
				FREE_DYNST(aScriptDef, A_ScriptDef);
				return ret;
			}

			if (IS_NULLFLD(aScriptDef, A_ScriptDef_Def) == TRUE &&
			    GET_STRING(aScriptDef, A_ScriptDef_Def)[0] == 0)
			{
				MSG_SendMesg(RET_SCPT_ERR_SYNTAX, 1, FILEINFO, "case_rule Script Defination is NULL", GET_STRING(aScriptDef, A_ScriptDef_Def));
			}
			else
			{
				if (SCPT_PrepTreeForFilter(GET_STRING(aScriptDef, A_ScriptDef_Def), hierHead,
					                               domainPtr, object,
                                                 &localFilterTree,0, NULLDYNSTPTR) == RET_SUCCEED)
				{
					for(row=0; row<recordNbr; row++)
					{
						if (recordTab[row] != NULLDYNSTPTR)
						{
							if(SCPT_IsRemoveWithFilterTree(hierHead,
                                                             object,
                                                   &localFilterTree,
                                                     recordTab[row],
                                                           &evalRec,
                                                   &incrNb) == TRUE)
							{
								recordTab[row] = NULL;
							}
						}
					}
					SCPT_FreeTreeForFilter(&localFilterTree);
				}
			}
			FREE(recordTab);
		}
	}
	DBA_FreeDynStTab(caseRuleTabPtr,caseRuleNbr,A_CaseRule);
	FREE_DYNST(aScriptDef, A_ScriptDef);
	return (ret);
}

/************************************************************************
      END  casemgt.c                                               OAMS
*************************************************************************/

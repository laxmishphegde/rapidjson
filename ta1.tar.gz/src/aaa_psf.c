/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/*
 Author: XCP
*/

/************************************************************************
**      Includes
*************************************************************************/
#include   <stdio.h>
#include  <stdlib.h>
#include  <string.h>

/************************************************************************
**      Constants
*************************************************************************/
#define SEGMENT 64

/************************************************************************
**      Structure & Type definitions
*************************************************************************/
typedef struct
{
    FILE   *fp;
    char *path;
    int   line;
} STREAM;

/************************************************************************
**      Static Data Definitions
*************************************************************************/
STREAM stream = { stdin, NULL, 0 };

/************************************************************************
**
**  Function    :   GetLine()
**
**  Description :
**
**  Argument    :   stream	
**                  line	
**
**  Return      :   0 on success, 1 on EOF
**
*************************************************************************/
static int GetLine(STREAM *stream, char **line)
{
    static char *string = NULL;

    char    *segment;
    unsigned    size;
    unsigned  length;
    
    segment = string = (char *)realloc(string, size = SEGMENT);

    if (fgets(segment, SEGMENT, stream->fp) != NULL)
    {
        char *eol = NULL;

        do
        {
            if ((eol = strchr(segment, '\n')) != NULL)
            {
                stream->line++;

                if (eol == string || eol[-1] != '\\')
                    break;

                *(segment = &eol[-1]) = '\0';

                length = size - (segment - string);
            }
            else
            {
                string =
                    (char *)realloc(string, size += SEGMENT);

                segment = string + size - (length = SEGMENT + 1);
            }
        }
        while (fgets(segment, length, stream->fp) != NULL);

        if (eol != NULL)
            *eol = '\0';
        
        *line = string;
    }
    else
        return  1;

    return 0;
}

/************************************************************************
**
**  Function    :   main()
**
**  Description :   Entry Point
**
**  Arguments   :
**
**  Return      :
**
*************************************************************************/
int main()
{
    unsigned discard = 0;
    unsigned counter = 0;

    char *line;

    while (!GetLine(&stream, &line))
    {
        unsigned flag = 0;

        if (!discard && !strncasecmp(line, "% after data:", 13))
            discard = !0;

        if ( discard && !strncasecmp(line, "%%endprolog"  , 11))
            flag    = !0;

        if (!discard)
        {
            if (strncasecmp(line, "%%page: ", 8))
                printf("%s\n", line);
            else
            {
                unsigned n = ++ counter;

                printf(
                   "%%%%Page: %d %d\n", n, n);
            }
        }

        if (flag)
            discard = 0;
    }

    printf("%% After data:\n");
    printf("%%%%Trailer\n");
    printf("server restore   %% Restore Postscript VM stack\n");

    return 0;
}

/************************************************************************
**      END  psf.c                                            UNICIBLE
*************************************************************************/

